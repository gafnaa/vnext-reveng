package androidx.appcompat.app;

/* JADX INFO: loaded from: classes.dex */
class AppLocalesStorageHelper {
    static final java.lang.String APPLICATION_LOCALES_RECORD_FILE = "androidx.appcompat.app.AppCompatDelegate.application_locales_record_file";
    static final java.lang.String APP_LOCALES_META_DATA_HOLDER_SERVICE_NAME = "androidx.appcompat.app.AppLocalesMetadataHolderService";
    static final java.lang.String LOCALE_RECORD_ATTRIBUTE_TAG = "application_locales";
    static final java.lang.String LOCALE_RECORD_FILE_TAG = "locales";
    static final java.lang.String TAG = "AppLocalesStorageHelper";

    static class SerialExecutor implements java.util.concurrent.Executor {
        java.lang.Runnable mActive;
        final java.util.concurrent.Executor mExecutor;
        private final java.lang.Object mLock;
        final java.util.Queue<java.lang.Runnable> mTasks;

        SerialExecutor(java.util.concurrent.Executor r2) {
                r1 = this;
                r1.<init>()
                java.lang.Object r0 = new java.lang.Object
                r0.<init>()
                r1.mLock = r0
                java.util.ArrayDeque r0 = new java.util.ArrayDeque
                r0.<init>()
                r1.mTasks = r0
                r1.mExecutor = r2
                return
        }

        @Override // java.util.concurrent.Executor
        public void execute(java.lang.Runnable r4) {
                r3 = this;
                java.lang.Object r0 = r3.mLock
                monitor-enter(r0)
                java.util.Queue<java.lang.Runnable> r1 = r3.mTasks     // Catch: java.lang.Throwable -> L16
                androidx.appcompat.app.AppLocalesStorageHelper$SerialExecutor$$ExternalSyntheticLambda0 r2 = new androidx.appcompat.app.AppLocalesStorageHelper$SerialExecutor$$ExternalSyntheticLambda0     // Catch: java.lang.Throwable -> L16
                r2.<init>(r3, r4)     // Catch: java.lang.Throwable -> L16
                r1.add(r2)     // Catch: java.lang.Throwable -> L16
                java.lang.Runnable r4 = r3.mActive     // Catch: java.lang.Throwable -> L16
                if (r4 != 0) goto L14
                r3.scheduleNext()     // Catch: java.lang.Throwable -> L16
            L14:
                monitor-exit(r0)     // Catch: java.lang.Throwable -> L16
                return
            L16:
                r4 = move-exception
                monitor-exit(r0)     // Catch: java.lang.Throwable -> L16
                throw r4
        }

        /* JADX INFO: renamed from: lambda$execute$0$androidx-appcompat-app-AppLocalesStorageHelper$SerialExecutor, reason: not valid java name */
        /* synthetic */ void m52xd188c474(java.lang.Runnable r1) {
                r0 = this;
                r1.run()     // Catch: java.lang.Throwable -> L7
                r0.scheduleNext()
                return
            L7:
                r1 = move-exception
                r0.scheduleNext()
                throw r1
        }

        protected void scheduleNext() {
                r3 = this;
                java.lang.Object r0 = r3.mLock
                monitor-enter(r0)
                java.util.Queue<java.lang.Runnable> r1 = r3.mTasks     // Catch: java.lang.Throwable -> L16
                java.lang.Object r1 = r1.poll()     // Catch: java.lang.Throwable -> L16
                java.lang.Runnable r1 = (java.lang.Runnable) r1     // Catch: java.lang.Throwable -> L16
                r3.mActive = r1     // Catch: java.lang.Throwable -> L16
                if (r1 == 0) goto L14
                java.util.concurrent.Executor r2 = r3.mExecutor     // Catch: java.lang.Throwable -> L16
                r2.execute(r1)     // Catch: java.lang.Throwable -> L16
            L14:
                monitor-exit(r0)     // Catch: java.lang.Throwable -> L16
                return
            L16:
                r1 = move-exception
                monitor-exit(r0)     // Catch: java.lang.Throwable -> L16
                throw r1
        }
    }

    static class ThreadPerTaskExecutor implements java.util.concurrent.Executor {
        ThreadPerTaskExecutor() {
                r0 = this;
                r0.<init>()
                return
        }

        @Override // java.util.concurrent.Executor
        public void execute(java.lang.Runnable r2) {
                r1 = this;
                java.lang.Thread r0 = new java.lang.Thread
                r0.<init>(r2)
                r0.start()
                return
        }
    }

    private AppLocalesStorageHelper() {
            r0 = this;
            r0.<init>()
            return
    }

    static void persistLocales(android.content.Context r8, java.lang.String r9) {
            java.lang.String r0 = "locales"
            java.lang.String r1 = "AppLocalesStorageHelper"
            java.lang.String r2 = "Storing App Locales : app-locales: "
            java.lang.String r3 = "Storing App Locales : Failed to persist app-locales: "
            java.lang.String r4 = ""
            boolean r4 = r9.equals(r4)
            java.lang.String r5 = "androidx.appcompat.app.AppCompatDelegate.application_locales_record_file"
            if (r4 == 0) goto L16
            r8.deleteFile(r5)
            return
        L16:
            r4 = 0
            java.io.FileOutputStream r8 = r8.openFileOutput(r5, r4)     // Catch: java.io.FileNotFoundException -> L73
            org.xmlpull.v1.XmlSerializer r4 = android.util.Xml.newSerializer()
            r5 = 0
            r4.setOutput(r8, r5)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            java.lang.String r6 = "UTF-8"
            r7 = 1
            java.lang.Boolean r7 = java.lang.Boolean.valueOf(r7)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            r4.startDocument(r6, r7)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            r4.startTag(r5, r0)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            java.lang.String r6 = "application_locales"
            r4.attribute(r5, r6, r9)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            r4.endTag(r5, r0)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            r4.endDocument()     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            r0.<init>(r2)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            r0.append(r9)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            java.lang.String r2 = " persisted successfully."
            r0.append(r2)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            android.util.Log.d(r1, r0)     // Catch: java.lang.Throwable -> L55 java.lang.Exception -> L57
            if (r8 == 0) goto L6c
            r8.close()     // Catch: java.io.IOException -> L6c
            return
        L55:
            r9 = move-exception
            goto L6d
        L57:
            r0 = move-exception
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L55
            r2.<init>(r3)     // Catch: java.lang.Throwable -> L55
            r2.append(r9)     // Catch: java.lang.Throwable -> L55
            java.lang.String r9 = r2.toString()     // Catch: java.lang.Throwable -> L55
            android.util.Log.w(r1, r9, r0)     // Catch: java.lang.Throwable -> L55
            if (r8 == 0) goto L6c
            r8.close()     // Catch: java.io.IOException -> L6c
        L6c:
            return
        L6d:
            if (r8 == 0) goto L72
            r8.close()     // Catch: java.io.IOException -> L72
        L72:
            throw r9
        L73:
            java.lang.String r8 = "Storing App Locales : FileNotFoundException: Cannot open file %s for writing "
            java.lang.Object[] r9 = new java.lang.Object[]{r5}
            java.lang.String r8 = java.lang.String.format(r8, r9)
            android.util.Log.w(r1, r8)
            return
    }

    static java.lang.String readLocales(android.content.Context r9) {
            java.lang.String r0 = "androidx.appcompat.app.AppCompatDelegate.application_locales_record_file"
            java.lang.String r1 = "AppLocalesStorageHelper"
            java.lang.String r2 = ""
            java.io.FileInputStream r3 = r9.openFileInput(r0)     // Catch: java.io.FileNotFoundException -> L72
            org.xmlpull.v1.XmlPullParser r4 = android.util.Xml.newPullParser()     // Catch: java.lang.Throwable -> L46 java.lang.Throwable -> L48
            java.lang.String r5 = "UTF-8"
            r4.setInput(r3, r5)     // Catch: java.lang.Throwable -> L46 java.lang.Throwable -> L48
            int r5 = r4.getDepth()     // Catch: java.lang.Throwable -> L46 java.lang.Throwable -> L48
        L17:
            int r6 = r4.next()     // Catch: java.lang.Throwable -> L46 java.lang.Throwable -> L48
            r7 = 1
            if (r6 == r7) goto L40
            r7 = 3
            if (r6 != r7) goto L27
            int r8 = r4.getDepth()     // Catch: java.lang.Throwable -> L46 java.lang.Throwable -> L48
            if (r8 <= r5) goto L40
        L27:
            if (r6 == r7) goto L17
            r7 = 4
            if (r6 != r7) goto L2d
            goto L17
        L2d:
            java.lang.String r6 = r4.getName()     // Catch: java.lang.Throwable -> L46 java.lang.Throwable -> L48
            java.lang.String r7 = "locales"
            boolean r6 = r6.equals(r7)     // Catch: java.lang.Throwable -> L46 java.lang.Throwable -> L48
            if (r6 == 0) goto L17
            java.lang.String r5 = "application_locales"
            r6 = 0
            java.lang.String r2 = r4.getAttributeValue(r6, r5)     // Catch: java.lang.Throwable -> L46 java.lang.Throwable -> L48
        L40:
            if (r3 == 0) goto L50
        L42:
            r3.close()     // Catch: java.io.IOException -> L50
            goto L50
        L46:
            r9 = move-exception
            goto L6c
        L48:
            java.lang.String r4 = "Reading app Locales : Unable to parse through file :androidx.appcompat.app.AppCompatDelegate.application_locales_record_file"
            android.util.Log.w(r1, r4)     // Catch: java.lang.Throwable -> L46
            if (r3 == 0) goto L50
            goto L42
        L50:
            boolean r3 = r2.isEmpty()
            if (r3 != 0) goto L68
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r0 = "Reading app Locales : Locales read from file: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file , appLocales: "
            r9.<init>(r0)
            r9.append(r2)
            java.lang.String r9 = r9.toString()
            android.util.Log.d(r1, r9)
            goto L6b
        L68:
            r9.deleteFile(r0)
        L6b:
            return r2
        L6c:
            if (r3 == 0) goto L71
            r3.close()     // Catch: java.io.IOException -> L71
        L71:
            throw r9
        L72:
            java.lang.String r9 = "Reading app Locales : Locales record file not found: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file"
            android.util.Log.w(r1, r9)
            return r2
    }

    static void syncLocalesToFramework(android.content.Context r4) {
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 33
            if (r0 < r1) goto L3c
            android.content.ComponentName r0 = new android.content.ComponentName
            java.lang.String r1 = "androidx.appcompat.app.AppLocalesMetadataHolderService"
            r0.<init>(r4, r1)
            android.content.pm.PackageManager r1 = r4.getPackageManager()
            int r1 = r1.getComponentEnabledSetting(r0)
            r2 = 1
            if (r1 == r2) goto L3c
            androidx.core.os.LocaleListCompat r1 = androidx.appcompat.app.AppCompatDelegate.getApplicationLocales()
            boolean r1 = r1.isEmpty()
            if (r1 == 0) goto L35
            java.lang.String r1 = readLocales(r4)
            java.lang.String r3 = "locale"
            java.lang.Object r3 = r4.getSystemService(r3)
            if (r3 == 0) goto L35
            android.os.LocaleList r1 = androidx.appcompat.app.AppCompatDelegate.Api24Impl.localeListForLanguageTags(r1)
            androidx.appcompat.app.AppCompatDelegate.Api33Impl.localeManagerSetApplicationLocales(r3, r1)
        L35:
            android.content.pm.PackageManager r4 = r4.getPackageManager()
            r4.setComponentEnabledSetting(r0, r2, r2)
        L3c:
            return
    }
}
