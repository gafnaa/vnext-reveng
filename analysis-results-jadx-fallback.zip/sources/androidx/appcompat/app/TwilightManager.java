package androidx.appcompat.app;

/* JADX INFO: loaded from: classes.dex */
class TwilightManager {
    private static final int SUNRISE = 6;
    private static final int SUNSET = 22;
    private static final java.lang.String TAG = "TwilightManager";
    private static androidx.appcompat.app.TwilightManager sInstance;
    private final android.content.Context mContext;
    private final android.location.LocationManager mLocationManager;
    private final androidx.appcompat.app.TwilightManager.TwilightState mTwilightState;

    private static class TwilightState {
        boolean isNight;
        long nextUpdate;

        TwilightState() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    TwilightManager(android.content.Context r2, android.location.LocationManager r3) {
            r1 = this;
            r1.<init>()
            androidx.appcompat.app.TwilightManager$TwilightState r0 = new androidx.appcompat.app.TwilightManager$TwilightState
            r0.<init>()
            r1.mTwilightState = r0
            r1.mContext = r2
            r1.mLocationManager = r3
            return
    }

    static androidx.appcompat.app.TwilightManager getInstance(android.content.Context r2) {
            androidx.appcompat.app.TwilightManager r0 = androidx.appcompat.app.TwilightManager.sInstance
            if (r0 != 0) goto L17
            android.content.Context r2 = r2.getApplicationContext()
            androidx.appcompat.app.TwilightManager r0 = new androidx.appcompat.app.TwilightManager
            java.lang.String r1 = "location"
            java.lang.Object r1 = r2.getSystemService(r1)
            android.location.LocationManager r1 = (android.location.LocationManager) r1
            r0.<init>(r2, r1)
            androidx.appcompat.app.TwilightManager.sInstance = r0
        L17:
            androidx.appcompat.app.TwilightManager r2 = androidx.appcompat.app.TwilightManager.sInstance
            return r2
    }

    private android.location.Location getLastKnownLocation() {
            r6 = this;
            android.content.Context r0 = r6.mContext
            java.lang.String r1 = "android.permission.ACCESS_COARSE_LOCATION"
            int r0 = androidx.core.content.PermissionChecker.checkSelfPermission(r0, r1)
            r1 = 0
            if (r0 != 0) goto L12
            java.lang.String r0 = "network"
            android.location.Location r0 = r6.getLastKnownLocationForProvider(r0)
            goto L13
        L12:
            r0 = r1
        L13:
            android.content.Context r2 = r6.mContext
            java.lang.String r3 = "android.permission.ACCESS_FINE_LOCATION"
            int r2 = androidx.core.content.PermissionChecker.checkSelfPermission(r2, r3)
            if (r2 != 0) goto L23
            java.lang.String r1 = "gps"
            android.location.Location r1 = r6.getLastKnownLocationForProvider(r1)
        L23:
            if (r1 == 0) goto L34
            if (r0 == 0) goto L34
            long r2 = r1.getTime()
            long r4 = r0.getTime()
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 <= 0) goto L37
            goto L36
        L34:
            if (r1 == 0) goto L37
        L36:
            return r1
        L37:
            return r0
    }

    private android.location.Location getLastKnownLocationForProvider(java.lang.String r3) {
            r2 = this;
            android.location.LocationManager r0 = r2.mLocationManager     // Catch: java.lang.Exception -> Lf
            boolean r0 = r0.isProviderEnabled(r3)     // Catch: java.lang.Exception -> Lf
            if (r0 == 0) goto L17
            android.location.LocationManager r0 = r2.mLocationManager     // Catch: java.lang.Exception -> Lf
            android.location.Location r3 = r0.getLastKnownLocation(r3)     // Catch: java.lang.Exception -> Lf
            return r3
        Lf:
            r3 = move-exception
            java.lang.String r0 = "TwilightManager"
            java.lang.String r1 = "Failed to get last known location"
            android.util.Log.d(r0, r1, r3)
        L17:
            r3 = 0
            return r3
    }

    private boolean isStateValid() {
            r4 = this;
            androidx.appcompat.app.TwilightManager$TwilightState r0 = r4.mTwilightState
            long r0 = r0.nextUpdate
            long r2 = java.lang.System.currentTimeMillis()
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 <= 0) goto Le
            r0 = 1
            return r0
        Le:
            r0 = 0
            return r0
    }

    static void setInstance(androidx.appcompat.app.TwilightManager r0) {
            androidx.appcompat.app.TwilightManager.sInstance = r0
            return
    }

    private void updateState(android.location.Location r19) {
            r18 = this;
            r0 = r18
            androidx.appcompat.app.TwilightManager$TwilightState r1 = r0.mTwilightState
            long r3 = java.lang.System.currentTimeMillis()
            androidx.appcompat.app.TwilightCalculator r5 = androidx.appcompat.app.TwilightCalculator.getInstance()
            r12 = 86400000(0x5265c00, double:4.2687272E-316)
            long r6 = r3 - r12
            double r8 = r19.getLatitude()
            double r10 = r19.getLongitude()
            r5.calculateTwilight(r6, r8, r10)
            double r6 = r19.getLatitude()
            r2 = r5
            r5 = r6
            double r7 = r19.getLongitude()
            r2.calculateTwilight(r3, r5, r7)
            r5 = r2
            int r2 = r5.state
            r6 = 1
            if (r2 != r6) goto L30
            goto L31
        L30:
            r6 = 0
        L31:
            r2 = r6
            long r14 = r5.sunrise
            long r6 = r5.sunset
            long r8 = r3 + r12
            r10 = r6
            r6 = r8
            double r8 = r19.getLatitude()
            double r12 = r19.getLongitude()
            r16 = r12
            r12 = r10
            r10 = r16
            r5.calculateTwilight(r6, r8, r10)
            long r5 = r5.sunrise
            r7 = -1
            int r9 = (r14 > r7 ? 1 : (r14 == r7 ? 0 : -1))
            if (r9 == 0) goto L67
            int r7 = (r12 > r7 ? 1 : (r12 == r7 ? 0 : -1))
            if (r7 != 0) goto L57
            goto L67
        L57:
            int r7 = (r3 > r12 ? 1 : (r3 == r12 ? 0 : -1))
            if (r7 <= 0) goto L5d
            r14 = r5
            goto L62
        L5d:
            int r3 = (r3 > r14 ? 1 : (r3 == r14 ? 0 : -1))
            if (r3 <= 0) goto L62
            r14 = r12
        L62:
            r3 = 60000(0xea60, double:2.9644E-319)
            long r14 = r14 + r3
            goto L6c
        L67:
            r5 = 43200000(0x2932e00, double:2.1343636E-316)
            long r14 = r3 + r5
        L6c:
            r1.isNight = r2
            r1.nextUpdate = r14
            return
    }

    boolean isNight() {
            r2 = this;
            androidx.appcompat.app.TwilightManager$TwilightState r0 = r2.mTwilightState
            boolean r1 = r2.isStateValid()
            if (r1 == 0) goto Lb
            boolean r0 = r0.isNight
            return r0
        Lb:
            android.location.Location r1 = r2.getLastKnownLocation()
            if (r1 == 0) goto L17
            r2.updateState(r1)
            boolean r0 = r0.isNight
            return r0
        L17:
            java.lang.String r0 = "TwilightManager"
            java.lang.String r1 = "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values."
            android.util.Log.i(r0, r1)
            java.util.Calendar r0 = java.util.Calendar.getInstance()
            r1 = 11
            int r0 = r0.get(r1)
            r1 = 6
            if (r0 < r1) goto L32
            r1 = 22
            if (r0 < r1) goto L30
            goto L32
        L30:
            r0 = 0
            return r0
        L32:
            r0 = 1
            return r0
    }
}
