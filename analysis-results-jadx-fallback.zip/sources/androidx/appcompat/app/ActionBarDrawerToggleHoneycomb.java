package androidx.appcompat.app;

/* JADX INFO: loaded from: classes.dex */
class ActionBarDrawerToggleHoneycomb {
    private static final java.lang.String TAG = "ActionBarDrawerToggleHC";
    private static final int[] THEME_ATTRS = null;

    static class SetIndicatorInfo {
        public java.lang.reflect.Method setHomeActionContentDescription;
        public java.lang.reflect.Method setHomeAsUpIndicator;
        public android.widget.ImageView upIndicatorView;

        SetIndicatorInfo(android.app.Activity r4) {
                r3 = this;
                r3.<init>()
                java.lang.Class<android.app.ActionBar> r0 = android.app.ActionBar.class
                java.lang.String r1 = "setHomeAsUpIndicator"
                java.lang.Class<android.graphics.drawable.Drawable> r2 = android.graphics.drawable.Drawable.class
                java.lang.Class[] r2 = new java.lang.Class[]{r2}     // Catch: java.lang.NoSuchMethodException -> L24
                java.lang.reflect.Method r0 = r0.getDeclaredMethod(r1, r2)     // Catch: java.lang.NoSuchMethodException -> L24
                r3.setHomeAsUpIndicator = r0     // Catch: java.lang.NoSuchMethodException -> L24
                java.lang.Class<android.app.ActionBar> r0 = android.app.ActionBar.class
                java.lang.String r1 = "setHomeActionContentDescription"
                java.lang.Class r2 = java.lang.Integer.TYPE     // Catch: java.lang.NoSuchMethodException -> L24
                java.lang.Class[] r2 = new java.lang.Class[]{r2}     // Catch: java.lang.NoSuchMethodException -> L24
                java.lang.reflect.Method r0 = r0.getDeclaredMethod(r1, r2)     // Catch: java.lang.NoSuchMethodException -> L24
                r3.setHomeActionContentDescription = r0     // Catch: java.lang.NoSuchMethodException -> L24
                return
            L24:
                r0 = 16908332(0x102002c, float:2.3877352E-38)
                android.view.View r4 = r4.findViewById(r0)
                if (r4 != 0) goto L2e
                goto L56
            L2e:
                android.view.ViewParent r4 = r4.getParent()
                android.view.ViewGroup r4 = (android.view.ViewGroup) r4
                int r1 = r4.getChildCount()
                r2 = 2
                if (r1 == r2) goto L3c
                goto L56
            L3c:
                r1 = 0
                android.view.View r1 = r4.getChildAt(r1)
                r2 = 1
                android.view.View r4 = r4.getChildAt(r2)
                int r2 = r1.getId()
                if (r2 != r0) goto L4d
                r1 = r4
            L4d:
                boolean r4 = r1 instanceof android.widget.ImageView
                if (r4 == 0) goto L56
                android.widget.ImageView r1 = (android.widget.ImageView) r1
                r3.upIndicatorView = r1
            L56:
                return
        }
    }

    static {
            r0 = 16843531(0x101030b, float:2.369574E-38)
            int[] r0 = new int[]{r0}
            androidx.appcompat.app.ActionBarDrawerToggleHoneycomb.THEME_ATTRS = r0
            return
    }

    private ActionBarDrawerToggleHoneycomb() {
            r0 = this;
            r0.<init>()
            return
    }

    public static android.graphics.drawable.Drawable getThemeUpIndicator(android.app.Activity r1) {
            int[] r0 = androidx.appcompat.app.ActionBarDrawerToggleHoneycomb.THEME_ATTRS
            android.content.res.TypedArray r1 = r1.obtainStyledAttributes(r0)
            r0 = 0
            android.graphics.drawable.Drawable r0 = r1.getDrawable(r0)
            r1.recycle()
            return r0
    }

    public static androidx.appcompat.app.ActionBarDrawerToggleHoneycomb.SetIndicatorInfo setActionBarDescription(androidx.appcompat.app.ActionBarDrawerToggleHoneycomb.SetIndicatorInfo r1, android.app.Activity r2, int r3) {
            if (r1 != 0) goto L7
            androidx.appcompat.app.ActionBarDrawerToggleHoneycomb$SetIndicatorInfo r1 = new androidx.appcompat.app.ActionBarDrawerToggleHoneycomb$SetIndicatorInfo
            r1.<init>(r2)
        L7:
            java.lang.reflect.Method r0 = r1.setHomeAsUpIndicator
            if (r0 == 0) goto L25
            android.app.ActionBar r2 = r2.getActionBar()     // Catch: java.lang.Exception -> L1d
            java.lang.reflect.Method r0 = r1.setHomeActionContentDescription     // Catch: java.lang.Exception -> L1d
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch: java.lang.Exception -> L1d
            java.lang.Object[] r3 = new java.lang.Object[]{r3}     // Catch: java.lang.Exception -> L1d
            r0.invoke(r2, r3)     // Catch: java.lang.Exception -> L1d
            return r1
        L1d:
            r2 = move-exception
            java.lang.String r3 = "ActionBarDrawerToggleHC"
            java.lang.String r0 = "Couldn't set content description via JB-MR2 API"
            android.util.Log.w(r3, r0, r2)
        L25:
            return r1
    }

    public static androidx.appcompat.app.ActionBarDrawerToggleHoneycomb.SetIndicatorInfo setActionBarUpIndicator(android.app.Activity r3, android.graphics.drawable.Drawable r4, int r5) {
            androidx.appcompat.app.ActionBarDrawerToggleHoneycomb$SetIndicatorInfo r0 = new androidx.appcompat.app.ActionBarDrawerToggleHoneycomb$SetIndicatorInfo
            r0.<init>(r3)
            java.lang.reflect.Method r1 = r0.setHomeAsUpIndicator
            java.lang.String r2 = "ActionBarDrawerToggleHC"
            if (r1 == 0) goto L2d
            android.app.ActionBar r3 = r3.getActionBar()     // Catch: java.lang.Exception -> L26
            java.lang.reflect.Method r1 = r0.setHomeAsUpIndicator     // Catch: java.lang.Exception -> L26
            java.lang.Object[] r4 = new java.lang.Object[]{r4}     // Catch: java.lang.Exception -> L26
            r1.invoke(r3, r4)     // Catch: java.lang.Exception -> L26
            java.lang.reflect.Method r4 = r0.setHomeActionContentDescription     // Catch: java.lang.Exception -> L26
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch: java.lang.Exception -> L26
            java.lang.Object[] r5 = new java.lang.Object[]{r5}     // Catch: java.lang.Exception -> L26
            r4.invoke(r3, r5)     // Catch: java.lang.Exception -> L26
            return r0
        L26:
            r3 = move-exception
            java.lang.String r4 = "Couldn't set home-as-up indicator via JB-MR2 API"
            android.util.Log.w(r2, r4, r3)
            return r0
        L2d:
            android.widget.ImageView r3 = r0.upIndicatorView
            if (r3 == 0) goto L37
            android.widget.ImageView r3 = r0.upIndicatorView
            r3.setImageDrawable(r4)
            return r0
        L37:
            java.lang.String r3 = "Couldn't set home-as-up indicator"
            android.util.Log.w(r2, r3)
            return r0
    }
}
