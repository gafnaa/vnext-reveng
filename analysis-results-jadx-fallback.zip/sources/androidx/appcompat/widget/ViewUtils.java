package androidx.appcompat.widget;

/* JADX INFO: loaded from: classes.dex */
public class ViewUtils {
    static final boolean SDK_LEVEL_SUPPORTS_AUTOSIZE = false;
    private static final java.lang.String TAG = "ViewUtils";
    private static java.lang.reflect.Method sComputeFitSystemWindowsMethod;

    static {
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 27
            r2 = 1
            if (r0 < r1) goto L9
            r0 = r2
            goto La
        L9:
            r0 = 0
        La:
            androidx.appcompat.widget.ViewUtils.SDK_LEVEL_SUPPORTS_AUTOSIZE = r0
            java.lang.Class<android.view.View> r0 = android.view.View.class
            java.lang.String r1 = "computeFitSystemWindows"
            java.lang.Class<android.graphics.Rect> r3 = android.graphics.Rect.class
            java.lang.Class<android.graphics.Rect> r4 = android.graphics.Rect.class
            java.lang.Class[] r3 = new java.lang.Class[]{r3, r4}     // Catch: java.lang.NoSuchMethodException -> L2a
            java.lang.reflect.Method r0 = r0.getDeclaredMethod(r1, r3)     // Catch: java.lang.NoSuchMethodException -> L2a
            androidx.appcompat.widget.ViewUtils.sComputeFitSystemWindowsMethod = r0     // Catch: java.lang.NoSuchMethodException -> L2a
            boolean r0 = r0.isAccessible()     // Catch: java.lang.NoSuchMethodException -> L2a
            if (r0 != 0) goto L29
            java.lang.reflect.Method r0 = androidx.appcompat.widget.ViewUtils.sComputeFitSystemWindowsMethod     // Catch: java.lang.NoSuchMethodException -> L2a
            r0.setAccessible(r2)     // Catch: java.lang.NoSuchMethodException -> L2a
        L29:
            return
        L2a:
            java.lang.String r0 = "ViewUtils"
            java.lang.String r1 = "Could not find method computeFitSystemWindows. Oh well."
            android.util.Log.d(r0, r1)
            return
    }

    private ViewUtils() {
            r0 = this;
            r0.<init>()
            return
    }

    public static void computeFitSystemWindows(android.view.View r1, android.graphics.Rect r2, android.graphics.Rect r3) {
            java.lang.reflect.Method r0 = androidx.appcompat.widget.ViewUtils.sComputeFitSystemWindowsMethod
            if (r0 == 0) goto L14
            java.lang.Object[] r2 = new java.lang.Object[]{r2, r3}     // Catch: java.lang.Exception -> Lc
            r0.invoke(r1, r2)     // Catch: java.lang.Exception -> Lc
            return
        Lc:
            r1 = move-exception
            java.lang.String r2 = "ViewUtils"
            java.lang.String r3 = "Could not invoke computeFitSystemWindows"
            android.util.Log.d(r2, r3, r1)
        L14:
            return
    }

    public static boolean isLayoutRtl(android.view.View r1) {
            int r1 = androidx.core.view.ViewCompat.getLayoutDirection(r1)
            r0 = 1
            if (r1 != r0) goto L8
            return r0
        L8:
            r1 = 0
            return r1
    }

    public static void makeOptionalFitsSystemWindows(android.view.View r5) {
            java.lang.String r0 = "Could not invoke makeOptionalFitsSystemWindows"
            java.lang.String r1 = "ViewUtils"
            java.lang.Class r2 = r5.getClass()     // Catch: java.lang.IllegalAccessException -> L1d java.lang.reflect.InvocationTargetException -> L22 java.lang.NoSuchMethodException -> L27
            java.lang.String r3 = "makeOptionalFitsSystemWindows"
            r4 = 0
            java.lang.reflect.Method r2 = r2.getMethod(r3, r4)     // Catch: java.lang.IllegalAccessException -> L1d java.lang.reflect.InvocationTargetException -> L22 java.lang.NoSuchMethodException -> L27
            boolean r3 = r2.isAccessible()     // Catch: java.lang.IllegalAccessException -> L1d java.lang.reflect.InvocationTargetException -> L22 java.lang.NoSuchMethodException -> L27
            if (r3 != 0) goto L19
            r3 = 1
            r2.setAccessible(r3)     // Catch: java.lang.IllegalAccessException -> L1d java.lang.reflect.InvocationTargetException -> L22 java.lang.NoSuchMethodException -> L27
        L19:
            r2.invoke(r5, r4)     // Catch: java.lang.IllegalAccessException -> L1d java.lang.reflect.InvocationTargetException -> L22 java.lang.NoSuchMethodException -> L27
            return
        L1d:
            r5 = move-exception
            android.util.Log.d(r1, r0, r5)
            goto L2c
        L22:
            r5 = move-exception
            android.util.Log.d(r1, r0, r5)
            goto L2c
        L27:
            java.lang.String r5 = "Could not find method makeOptionalFitsSystemWindows. Oh well..."
            android.util.Log.d(r1, r5)
        L2c:
            return
    }
}
