package androidx.appcompat.widget;

/* JADX INFO: loaded from: classes.dex */
class AppCompatTextHelper {
    private static final int MONOSPACE = 3;
    private static final int SANS = 1;
    private static final int SERIF = 2;
    private static final int TEXT_FONT_WEIGHT_UNSPECIFIED = -1;
    private boolean mAsyncFontPending;
    private final androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper mAutoSizeTextHelper;
    private androidx.appcompat.widget.TintInfo mDrawableBottomTint;
    private androidx.appcompat.widget.TintInfo mDrawableEndTint;
    private androidx.appcompat.widget.TintInfo mDrawableLeftTint;
    private androidx.appcompat.widget.TintInfo mDrawableRightTint;
    private androidx.appcompat.widget.TintInfo mDrawableStartTint;
    private androidx.appcompat.widget.TintInfo mDrawableTint;
    private androidx.appcompat.widget.TintInfo mDrawableTopTint;
    private android.graphics.Typeface mFontTypeface;
    private int mFontWeight;
    private int mStyle;
    private final android.widget.TextView mView;



    static class Api17Impl {
        private Api17Impl() {
                r0 = this;
                r0.<init>()
                return
        }

        static android.graphics.drawable.Drawable[] getCompoundDrawablesRelative(android.widget.TextView r0) {
                android.graphics.drawable.Drawable[] r0 = r0.getCompoundDrawablesRelative()
                return r0
        }

        static void setCompoundDrawablesRelativeWithIntrinsicBounds(android.widget.TextView r0, android.graphics.drawable.Drawable r1, android.graphics.drawable.Drawable r2, android.graphics.drawable.Drawable r3, android.graphics.drawable.Drawable r4) {
                r0.setCompoundDrawablesRelativeWithIntrinsicBounds(r1, r2, r3, r4)
                return
        }

        static void setTextLocale(android.widget.TextView r0, java.util.Locale r1) {
                r0.setTextLocale(r1)
                return
        }
    }

    static class Api21Impl {
        private Api21Impl() {
                r0 = this;
                r0.<init>()
                return
        }

        static java.util.Locale forLanguageTag(java.lang.String r0) {
                java.util.Locale r0 = java.util.Locale.forLanguageTag(r0)
                return r0
        }
    }

    static class Api24Impl {
        private Api24Impl() {
                r0 = this;
                r0.<init>()
                return
        }

        static android.os.LocaleList forLanguageTags(java.lang.String r0) {
                android.os.LocaleList r0 = android.os.LocaleList.forLanguageTags(r0)
                return r0
        }

        static void setTextLocales(android.widget.TextView r0, android.os.LocaleList r1) {
                r0.setTextLocales(r1)
                return
        }
    }

    static class Api26Impl {
        private Api26Impl() {
                r0 = this;
                r0.<init>()
                return
        }

        static int getAutoSizeStepGranularity(android.widget.TextView r0) {
                int r0 = r0.getAutoSizeStepGranularity()
                return r0
        }

        static void setAutoSizeTextTypeUniformWithConfiguration(android.widget.TextView r0, int r1, int r2, int r3, int r4) {
                r0.setAutoSizeTextTypeUniformWithConfiguration(r1, r2, r3, r4)
                return
        }

        static void setAutoSizeTextTypeUniformWithPresetSizes(android.widget.TextView r0, int[] r1, int r2) {
                r0.setAutoSizeTextTypeUniformWithPresetSizes(r1, r2)
                return
        }

        static boolean setFontVariationSettings(android.widget.TextView r0, java.lang.String r1) {
                boolean r0 = r0.setFontVariationSettings(r1)
                return r0
        }
    }

    static class Api28Impl {
        private Api28Impl() {
                r0 = this;
                r0.<init>()
                return
        }

        static android.graphics.Typeface create(android.graphics.Typeface r0, int r1, boolean r2) {
                android.graphics.Typeface r0 = android.graphics.Typeface.create(r0, r1, r2)
                return r0
        }
    }

    AppCompatTextHelper(android.widget.TextView r2) {
            r1 = this;
            r1.<init>()
            r0 = 0
            r1.mStyle = r0
            r0 = -1
            r1.mFontWeight = r0
            r1.mView = r2
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = new androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper
            r0.<init>(r2)
            r1.mAutoSizeTextHelper = r0
            return
    }

    private void applyCompoundDrawableTint(android.graphics.drawable.Drawable r2, androidx.appcompat.widget.TintInfo r3) {
            r1 = this;
            if (r2 == 0) goto Ld
            if (r3 == 0) goto Ld
            android.widget.TextView r0 = r1.mView
            int[] r0 = r0.getDrawableState()
            androidx.appcompat.widget.AppCompatDrawableManager.tintDrawable(r2, r3, r0)
        Ld:
            return
    }

    private static androidx.appcompat.widget.TintInfo createTintInfo(android.content.Context r0, androidx.appcompat.widget.AppCompatDrawableManager r1, int r2) {
            android.content.res.ColorStateList r0 = r1.getTintList(r0, r2)
            if (r0 == 0) goto L11
            androidx.appcompat.widget.TintInfo r1 = new androidx.appcompat.widget.TintInfo
            r1.<init>()
            r2 = 1
            r1.mHasTintList = r2
            r1.mTintList = r0
            return r1
        L11:
            r0 = 0
            return r0
    }

    private void setCompoundDrawables(android.graphics.drawable.Drawable r6, android.graphics.drawable.Drawable r7, android.graphics.drawable.Drawable r8, android.graphics.drawable.Drawable r9, android.graphics.drawable.Drawable r10, android.graphics.drawable.Drawable r11) {
            r5 = this;
            r0 = 3
            r1 = 1
            r2 = 0
            r3 = 2
            if (r10 != 0) goto L54
            if (r11 == 0) goto L9
            goto L54
        L9:
            if (r6 != 0) goto L13
            if (r7 != 0) goto L13
            if (r8 != 0) goto L13
            if (r9 == 0) goto L12
            goto L13
        L12:
            return
        L13:
            android.widget.TextView r10 = r5.mView
            android.graphics.drawable.Drawable[] r10 = androidx.appcompat.widget.AppCompatTextHelper.Api17Impl.getCompoundDrawablesRelative(r10)
            r11 = r10[r2]
            if (r11 != 0) goto L42
            r4 = r10[r3]
            if (r4 == 0) goto L22
            goto L42
        L22:
            android.widget.TextView r10 = r5.mView
            android.graphics.drawable.Drawable[] r10 = r10.getCompoundDrawables()
            android.widget.TextView r11 = r5.mView
            if (r6 == 0) goto L2d
            goto L2f
        L2d:
            r6 = r10[r2]
        L2f:
            if (r7 == 0) goto L32
            goto L34
        L32:
            r7 = r10[r1]
        L34:
            if (r8 == 0) goto L37
            goto L39
        L37:
            r8 = r10[r3]
        L39:
            if (r9 == 0) goto L3c
            goto L3e
        L3c:
            r9 = r10[r0]
        L3e:
            r11.setCompoundDrawablesWithIntrinsicBounds(r6, r7, r8, r9)
            return
        L42:
            android.widget.TextView r6 = r5.mView
            if (r7 == 0) goto L47
            goto L49
        L47:
            r7 = r10[r1]
        L49:
            r8 = r10[r3]
            if (r9 == 0) goto L4e
            goto L50
        L4e:
            r9 = r10[r0]
        L50:
            androidx.appcompat.widget.AppCompatTextHelper.Api17Impl.setCompoundDrawablesRelativeWithIntrinsicBounds(r6, r11, r7, r8, r9)
            return
        L54:
            android.widget.TextView r6 = r5.mView
            android.graphics.drawable.Drawable[] r6 = androidx.appcompat.widget.AppCompatTextHelper.Api17Impl.getCompoundDrawablesRelative(r6)
            android.widget.TextView r8 = r5.mView
            if (r10 == 0) goto L5f
            goto L61
        L5f:
            r10 = r6[r2]
        L61:
            if (r7 == 0) goto L64
            goto L66
        L64:
            r7 = r6[r1]
        L66:
            if (r11 == 0) goto L69
            goto L6b
        L69:
            r11 = r6[r3]
        L6b:
            if (r9 == 0) goto L6e
            goto L70
        L6e:
            r9 = r6[r0]
        L70:
            androidx.appcompat.widget.AppCompatTextHelper.Api17Impl.setCompoundDrawablesRelativeWithIntrinsicBounds(r8, r10, r7, r11, r9)
            return
    }

    private void setCompoundTints() {
            r1 = this;
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            r1.mDrawableLeftTint = r0
            r1.mDrawableTopTint = r0
            r1.mDrawableRightTint = r0
            r1.mDrawableBottomTint = r0
            r1.mDrawableStartTint = r0
            r1.mDrawableEndTint = r0
            return
    }

    private void setTextSizeInternal(int r2, float r3) {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            r0.setTextSizeInternal(r2, r3)
            return
    }

    private void updateTypefaceAndStyle(android.content.Context r10, androidx.appcompat.widget.TintTypedArray r11) {
            r9 = this;
            int r0 = androidx.appcompat.R.styleable.TextAppearance_android_textStyle
            int r1 = r9.mStyle
            int r0 = r11.getInt(r0, r1)
            r9.mStyle = r0
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 2
            r2 = -1
            r3 = 28
            if (r0 < r3) goto L21
            int r0 = androidx.appcompat.R.styleable.TextAppearance_android_textFontWeight
            int r0 = r11.getInt(r0, r2)
            r9.mFontWeight = r0
            if (r0 == r2) goto L21
            int r0 = r9.mStyle
            r0 = r0 & r1
            r9.mStyle = r0
        L21:
            int r0 = androidx.appcompat.R.styleable.TextAppearance_android_fontFamily
            boolean r0 = r11.hasValue(r0)
            r4 = 1
            r5 = 0
            if (r0 != 0) goto L5c
            int r0 = androidx.appcompat.R.styleable.TextAppearance_fontFamily
            boolean r0 = r11.hasValue(r0)
            if (r0 == 0) goto L34
            goto L5c
        L34:
            int r10 = androidx.appcompat.R.styleable.TextAppearance_android_typeface
            boolean r10 = r11.hasValue(r10)
            if (r10 == 0) goto Le0
            r9.mAsyncFontPending = r5
            int r10 = androidx.appcompat.R.styleable.TextAppearance_android_typeface
            int r10 = r11.getInt(r10, r4)
            if (r10 == r4) goto L57
            if (r10 == r1) goto L52
            r11 = 3
            if (r10 == r11) goto L4d
            goto Le0
        L4d:
            android.graphics.Typeface r10 = android.graphics.Typeface.MONOSPACE
            r9.mFontTypeface = r10
            return
        L52:
            android.graphics.Typeface r10 = android.graphics.Typeface.SERIF
            r9.mFontTypeface = r10
            return
        L57:
            android.graphics.Typeface r10 = android.graphics.Typeface.SANS_SERIF
            r9.mFontTypeface = r10
            return
        L5c:
            r0 = 0
            r9.mFontTypeface = r0
            int r0 = androidx.appcompat.R.styleable.TextAppearance_fontFamily
            boolean r0 = r11.hasValue(r0)
            if (r0 == 0) goto L6a
            int r0 = androidx.appcompat.R.styleable.TextAppearance_fontFamily
            goto L6c
        L6a:
            int r0 = androidx.appcompat.R.styleable.TextAppearance_android_fontFamily
        L6c:
            int r6 = r9.mFontWeight
            int r7 = r9.mStyle
            boolean r10 = r10.isRestricted()
            if (r10 != 0) goto Lb2
            java.lang.ref.WeakReference r10 = new java.lang.ref.WeakReference
            android.widget.TextView r8 = r9.mView
            r10.<init>(r8)
            androidx.appcompat.widget.AppCompatTextHelper$1 r8 = new androidx.appcompat.widget.AppCompatTextHelper$1
            r8.<init>(r9, r6, r7, r10)
            int r10 = r9.mStyle     // Catch: java.lang.Throwable -> Lb2
            android.graphics.Typeface r10 = r11.getFont(r0, r10, r8)     // Catch: java.lang.Throwable -> Lb2
            if (r10 == 0) goto La9
            int r6 = android.os.Build.VERSION.SDK_INT     // Catch: java.lang.Throwable -> Lb2
            if (r6 < r3) goto La7
            int r6 = r9.mFontWeight     // Catch: java.lang.Throwable -> Lb2
            if (r6 == r2) goto La7
            android.graphics.Typeface r10 = android.graphics.Typeface.create(r10, r5)     // Catch: java.lang.Throwable -> Lb2
            int r6 = r9.mFontWeight     // Catch: java.lang.Throwable -> Lb2
            int r7 = r9.mStyle     // Catch: java.lang.Throwable -> Lb2
            r7 = r7 & r1
            if (r7 == 0) goto L9f
            r7 = r4
            goto La0
        L9f:
            r7 = r5
        La0:
            android.graphics.Typeface r10 = androidx.appcompat.widget.AppCompatTextHelper.Api28Impl.create(r10, r6, r7)     // Catch: java.lang.Throwable -> Lb2
            r9.mFontTypeface = r10     // Catch: java.lang.Throwable -> Lb2
            goto La9
        La7:
            r9.mFontTypeface = r10     // Catch: java.lang.Throwable -> Lb2
        La9:
            android.graphics.Typeface r10 = r9.mFontTypeface     // Catch: java.lang.Throwable -> Lb2
            if (r10 != 0) goto Laf
            r10 = r4
            goto Lb0
        Laf:
            r10 = r5
        Lb0:
            r9.mAsyncFontPending = r10     // Catch: java.lang.Throwable -> Lb2
        Lb2:
            android.graphics.Typeface r10 = r9.mFontTypeface
            if (r10 != 0) goto Le0
            java.lang.String r10 = r11.getString(r0)
            if (r10 == 0) goto Le0
            int r11 = android.os.Build.VERSION.SDK_INT
            if (r11 < r3) goto Ld8
            int r11 = r9.mFontWeight
            if (r11 == r2) goto Ld8
            android.graphics.Typeface r10 = android.graphics.Typeface.create(r10, r5)
            int r11 = r9.mFontWeight
            int r0 = r9.mStyle
            r0 = r0 & r1
            if (r0 == 0) goto Ld0
            goto Ld1
        Ld0:
            r4 = r5
        Ld1:
            android.graphics.Typeface r10 = androidx.appcompat.widget.AppCompatTextHelper.Api28Impl.create(r10, r11, r4)
            r9.mFontTypeface = r10
            goto Le0
        Ld8:
            int r11 = r9.mStyle
            android.graphics.Typeface r10 = android.graphics.Typeface.create(r10, r11)
            r9.mFontTypeface = r10
        Le0:
            return
    }

    void applyCompoundDrawablesTints() {
            r5 = this;
            androidx.appcompat.widget.TintInfo r0 = r5.mDrawableLeftTint
            r1 = 2
            r2 = 0
            if (r0 != 0) goto L12
            androidx.appcompat.widget.TintInfo r0 = r5.mDrawableTopTint
            if (r0 != 0) goto L12
            androidx.appcompat.widget.TintInfo r0 = r5.mDrawableRightTint
            if (r0 != 0) goto L12
            androidx.appcompat.widget.TintInfo r0 = r5.mDrawableBottomTint
            if (r0 == 0) goto L36
        L12:
            android.widget.TextView r0 = r5.mView
            android.graphics.drawable.Drawable[] r0 = r0.getCompoundDrawables()
            r3 = r0[r2]
            androidx.appcompat.widget.TintInfo r4 = r5.mDrawableLeftTint
            r5.applyCompoundDrawableTint(r3, r4)
            r3 = 1
            r3 = r0[r3]
            androidx.appcompat.widget.TintInfo r4 = r5.mDrawableTopTint
            r5.applyCompoundDrawableTint(r3, r4)
            r3 = r0[r1]
            androidx.appcompat.widget.TintInfo r4 = r5.mDrawableRightTint
            r5.applyCompoundDrawableTint(r3, r4)
            r3 = 3
            r0 = r0[r3]
            androidx.appcompat.widget.TintInfo r3 = r5.mDrawableBottomTint
            r5.applyCompoundDrawableTint(r0, r3)
        L36:
            androidx.appcompat.widget.TintInfo r0 = r5.mDrawableStartTint
            if (r0 != 0) goto L40
            androidx.appcompat.widget.TintInfo r0 = r5.mDrawableEndTint
            if (r0 == 0) goto L3f
            goto L40
        L3f:
            return
        L40:
            android.widget.TextView r0 = r5.mView
            android.graphics.drawable.Drawable[] r0 = androidx.appcompat.widget.AppCompatTextHelper.Api17Impl.getCompoundDrawablesRelative(r0)
            r2 = r0[r2]
            androidx.appcompat.widget.TintInfo r3 = r5.mDrawableStartTint
            r5.applyCompoundDrawableTint(r2, r3)
            r0 = r0[r1]
            androidx.appcompat.widget.TintInfo r1 = r5.mDrawableEndTint
            r5.applyCompoundDrawableTint(r0, r1)
            return
    }

    void autoSizeText() {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            r0.autoSizeText()
            return
    }

    int getAutoSizeMaxTextSize() {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            int r0 = r0.getAutoSizeMaxTextSize()
            return r0
    }

    int getAutoSizeMinTextSize() {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            int r0 = r0.getAutoSizeMinTextSize()
            return r0
    }

    int getAutoSizeStepGranularity() {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            int r0 = r0.getAutoSizeStepGranularity()
            return r0
    }

    int[] getAutoSizeTextAvailableSizes() {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            int[] r0 = r0.getAutoSizeTextAvailableSizes()
            return r0
    }

    int getAutoSizeTextType() {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            int r0 = r0.getAutoSizeTextType()
            return r0
    }

    android.content.res.ColorStateList getCompoundDrawableTintList() {
            r1 = this;
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            if (r0 == 0) goto L7
            android.content.res.ColorStateList r0 = r0.mTintList
            return r0
        L7:
            r0 = 0
            return r0
    }

    android.graphics.PorterDuff.Mode getCompoundDrawableTintMode() {
            r1 = this;
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            if (r0 == 0) goto L7
            android.graphics.PorterDuff$Mode r0 = r0.mTintMode
            return r0
        L7:
            r0 = 0
            return r0
    }

    boolean isAutoSizeEnabled() {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            boolean r0 = r0.isAutoSizeEnabled()
            return r0
    }

    void loadFromAttributes(android.util.AttributeSet r17, int r18) {
            r16 = this;
            r0 = r16
            r4 = r17
            r6 = r18
            android.widget.TextView r1 = r0.mView
            android.content.Context r8 = r1.getContext()
            androidx.appcompat.widget.AppCompatDrawableManager r9 = androidx.appcompat.widget.AppCompatDrawableManager.get()
            int[] r1 = androidx.appcompat.R.styleable.AppCompatTextHelper
            r10 = 0
            androidx.appcompat.widget.TintTypedArray r11 = androidx.appcompat.widget.TintTypedArray.obtainStyledAttributes(r8, r4, r1, r6, r10)
            android.widget.TextView r1 = r0.mView
            android.content.Context r2 = r1.getContext()
            int[] r3 = androidx.appcompat.R.styleable.AppCompatTextHelper
            android.content.res.TypedArray r5 = r11.getWrappedTypeArray()
            r7 = 0
            androidx.core.view.ViewCompat.saveAttributeDataForStyleable(r1, r2, r3, r4, r5, r6, r7)
            int r1 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_textAppearance
            r7 = -1
            int r1 = r11.getResourceId(r1, r7)
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableLeft
            boolean r2 = r11.hasValue(r2)
            if (r2 == 0) goto L42
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableLeft
            int r2 = r11.getResourceId(r2, r10)
            androidx.appcompat.widget.TintInfo r2 = createTintInfo(r8, r9, r2)
            r0.mDrawableLeftTint = r2
        L42:
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableTop
            boolean r2 = r11.hasValue(r2)
            if (r2 == 0) goto L56
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableTop
            int r2 = r11.getResourceId(r2, r10)
            androidx.appcompat.widget.TintInfo r2 = createTintInfo(r8, r9, r2)
            r0.mDrawableTopTint = r2
        L56:
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableRight
            boolean r2 = r11.hasValue(r2)
            if (r2 == 0) goto L6a
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableRight
            int r2 = r11.getResourceId(r2, r10)
            androidx.appcompat.widget.TintInfo r2 = createTintInfo(r8, r9, r2)
            r0.mDrawableRightTint = r2
        L6a:
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableBottom
            boolean r2 = r11.hasValue(r2)
            if (r2 == 0) goto L7e
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableBottom
            int r2 = r11.getResourceId(r2, r10)
            androidx.appcompat.widget.TintInfo r2 = createTintInfo(r8, r9, r2)
            r0.mDrawableBottomTint = r2
        L7e:
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableStart
            boolean r2 = r11.hasValue(r2)
            if (r2 == 0) goto L92
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableStart
            int r2 = r11.getResourceId(r2, r10)
            androidx.appcompat.widget.TintInfo r2 = createTintInfo(r8, r9, r2)
            r0.mDrawableStartTint = r2
        L92:
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableEnd
            boolean r2 = r11.hasValue(r2)
            if (r2 == 0) goto La6
            int r2 = androidx.appcompat.R.styleable.AppCompatTextHelper_android_drawableEnd
            int r2 = r11.getResourceId(r2, r10)
            androidx.appcompat.widget.TintInfo r2 = createTintInfo(r8, r9, r2)
            r0.mDrawableEndTint = r2
        La6:
            r11.recycle()
            android.widget.TextView r2 = r0.mView
            android.text.method.TransformationMethod r2 = r2.getTransformationMethod()
            boolean r2 = r2 instanceof android.text.method.PasswordTransformationMethod
            r3 = 26
            r11 = 0
            if (r1 == r7) goto Lfb
            int[] r12 = androidx.appcompat.R.styleable.TextAppearance
            androidx.appcompat.widget.TintTypedArray r1 = androidx.appcompat.widget.TintTypedArray.obtainStyledAttributes(r8, r1, r12)
            if (r2 != 0) goto Lce
            int r12 = androidx.appcompat.R.styleable.TextAppearance_textAllCaps
            boolean r12 = r1.hasValue(r12)
            if (r12 == 0) goto Lce
            int r12 = androidx.appcompat.R.styleable.TextAppearance_textAllCaps
            boolean r12 = r1.getBoolean(r12, r10)
            r13 = 1
            goto Ld0
        Lce:
            r12 = r10
            r13 = r12
        Ld0:
            r0.updateTypefaceAndStyle(r8, r1)
            int r14 = androidx.appcompat.R.styleable.TextAppearance_textLocale
            boolean r14 = r1.hasValue(r14)
            if (r14 == 0) goto Le2
            int r14 = androidx.appcompat.R.styleable.TextAppearance_textLocale
            java.lang.String r14 = r1.getString(r14)
            goto Le3
        Le2:
            r14 = r11
        Le3:
            int r15 = android.os.Build.VERSION.SDK_INT
            if (r15 < r3) goto Lf6
            int r15 = androidx.appcompat.R.styleable.TextAppearance_fontVariationSettings
            boolean r15 = r1.hasValue(r15)
            if (r15 == 0) goto Lf6
            int r15 = androidx.appcompat.R.styleable.TextAppearance_fontVariationSettings
            java.lang.String r15 = r1.getString(r15)
            goto Lf7
        Lf6:
            r15 = r11
        Lf7:
            r1.recycle()
            goto Lff
        Lfb:
            r12 = r10
            r13 = r12
            r14 = r11
            r15 = r14
        Lff:
            int[] r1 = androidx.appcompat.R.styleable.TextAppearance
            androidx.appcompat.widget.TintTypedArray r1 = androidx.appcompat.widget.TintTypedArray.obtainStyledAttributes(r8, r4, r1, r6, r10)
            if (r2 != 0) goto L117
            int r5 = androidx.appcompat.R.styleable.TextAppearance_textAllCaps
            boolean r5 = r1.hasValue(r5)
            if (r5 == 0) goto L117
            int r5 = androidx.appcompat.R.styleable.TextAppearance_textAllCaps
            boolean r12 = r1.getBoolean(r5, r10)
            r5 = 1
            goto L118
        L117:
            r5 = r13
        L118:
            int r13 = androidx.appcompat.R.styleable.TextAppearance_textLocale
            boolean r13 = r1.hasValue(r13)
            if (r13 == 0) goto L126
            int r13 = androidx.appcompat.R.styleable.TextAppearance_textLocale
            java.lang.String r14 = r1.getString(r13)
        L126:
            int r13 = android.os.Build.VERSION.SDK_INT
            if (r13 < r3) goto L138
            int r3 = androidx.appcompat.R.styleable.TextAppearance_fontVariationSettings
            boolean r3 = r1.hasValue(r3)
            if (r3 == 0) goto L138
            int r3 = androidx.appcompat.R.styleable.TextAppearance_fontVariationSettings
            java.lang.String r15 = r1.getString(r3)
        L138:
            int r3 = android.os.Build.VERSION.SDK_INT
            r13 = 28
            if (r3 < r13) goto L154
            int r3 = androidx.appcompat.R.styleable.TextAppearance_android_textSize
            boolean r3 = r1.hasValue(r3)
            if (r3 == 0) goto L154
            int r3 = androidx.appcompat.R.styleable.TextAppearance_android_textSize
            int r3 = r1.getDimensionPixelSize(r3, r7)
            if (r3 != 0) goto L154
            android.widget.TextView r3 = r0.mView
            r13 = 0
            r3.setTextSize(r10, r13)
        L154:
            r0.updateTypefaceAndStyle(r8, r1)
            r1.recycle()
            if (r2 != 0) goto L161
            if (r5 == 0) goto L161
            r0.setAllCaps(r12)
        L161:
            android.graphics.Typeface r1 = r0.mFontTypeface
            if (r1 == 0) goto L176
            int r2 = r0.mFontWeight
            if (r2 != r7) goto L171
            android.widget.TextView r2 = r0.mView
            int r3 = r0.mStyle
            r2.setTypeface(r1, r3)
            goto L176
        L171:
            android.widget.TextView r2 = r0.mView
            r2.setTypeface(r1)
        L176:
            if (r15 == 0) goto L17d
            android.widget.TextView r1 = r0.mView
            androidx.appcompat.widget.AppCompatTextHelper.Api26Impl.setFontVariationSettings(r1, r15)
        L17d:
            if (r14 == 0) goto L188
            android.widget.TextView r1 = r0.mView
            android.os.LocaleList r2 = androidx.appcompat.widget.AppCompatTextHelper.Api24Impl.forLanguageTags(r14)
            androidx.appcompat.widget.AppCompatTextHelper.Api24Impl.setTextLocales(r1, r2)
        L188:
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r1 = r0.mAutoSizeTextHelper
            r1.loadFromAttributes(r4, r6)
            boolean r1 = androidx.appcompat.widget.ViewUtils.SDK_LEVEL_SUPPORTS_AUTOSIZE
            if (r1 == 0) goto L1cc
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r1 = r0.mAutoSizeTextHelper
            int r1 = r1.getAutoSizeTextType()
            if (r1 == 0) goto L1cc
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r1 = r0.mAutoSizeTextHelper
            int[] r1 = r1.getAutoSizeTextAvailableSizes()
            int r2 = r1.length
            if (r2 <= 0) goto L1cc
            android.widget.TextView r2 = r0.mView
            int r2 = androidx.appcompat.widget.AppCompatTextHelper.Api26Impl.getAutoSizeStepGranularity(r2)
            float r2 = (float) r2
            r3 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r2 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r2 == 0) goto L1c7
            android.widget.TextView r1 = r0.mView
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r2 = r0.mAutoSizeTextHelper
            int r2 = r2.getAutoSizeMinTextSize()
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r3 = r0.mAutoSizeTextHelper
            int r3 = r3.getAutoSizeMaxTextSize()
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r5 = r0.mAutoSizeTextHelper
            int r5 = r5.getAutoSizeStepGranularity()
            androidx.appcompat.widget.AppCompatTextHelper.Api26Impl.setAutoSizeTextTypeUniformWithConfiguration(r1, r2, r3, r5, r10)
            goto L1cc
        L1c7:
            android.widget.TextView r2 = r0.mView
            androidx.appcompat.widget.AppCompatTextHelper.Api26Impl.setAutoSizeTextTypeUniformWithPresetSizes(r2, r1, r10)
        L1cc:
            int[] r1 = androidx.appcompat.R.styleable.AppCompatTextView
            androidx.appcompat.widget.TintTypedArray r10 = androidx.appcompat.widget.TintTypedArray.obtainStyledAttributes(r8, r4, r1)
            int r1 = androidx.appcompat.R.styleable.AppCompatTextView_drawableLeftCompat
            int r1 = r10.getResourceId(r1, r7)
            if (r1 == r7) goto L1df
            android.graphics.drawable.Drawable r1 = r9.getDrawable(r8, r1)
            goto L1e0
        L1df:
            r1 = r11
        L1e0:
            int r2 = androidx.appcompat.R.styleable.AppCompatTextView_drawableTopCompat
            int r2 = r10.getResourceId(r2, r7)
            if (r2 == r7) goto L1ed
            android.graphics.drawable.Drawable r2 = r9.getDrawable(r8, r2)
            goto L1ee
        L1ed:
            r2 = r11
        L1ee:
            int r3 = androidx.appcompat.R.styleable.AppCompatTextView_drawableRightCompat
            int r3 = r10.getResourceId(r3, r7)
            if (r3 == r7) goto L1fb
            android.graphics.drawable.Drawable r3 = r9.getDrawable(r8, r3)
            goto L1fc
        L1fb:
            r3 = r11
        L1fc:
            int r4 = androidx.appcompat.R.styleable.AppCompatTextView_drawableBottomCompat
            int r4 = r10.getResourceId(r4, r7)
            if (r4 == r7) goto L209
            android.graphics.drawable.Drawable r4 = r9.getDrawable(r8, r4)
            goto L20a
        L209:
            r4 = r11
        L20a:
            int r5 = androidx.appcompat.R.styleable.AppCompatTextView_drawableStartCompat
            int r5 = r10.getResourceId(r5, r7)
            if (r5 == r7) goto L217
            android.graphics.drawable.Drawable r5 = r9.getDrawable(r8, r5)
            goto L218
        L217:
            r5 = r11
        L218:
            int r6 = androidx.appcompat.R.styleable.AppCompatTextView_drawableEndCompat
            int r6 = r10.getResourceId(r6, r7)
            if (r6 == r7) goto L225
            android.graphics.drawable.Drawable r6 = r9.getDrawable(r8, r6)
            goto L226
        L225:
            r6 = r11
        L226:
            r0.setCompoundDrawables(r1, r2, r3, r4, r5, r6)
            int r1 = androidx.appcompat.R.styleable.AppCompatTextView_drawableTint
            boolean r1 = r10.hasValue(r1)
            if (r1 == 0) goto L23c
            int r1 = androidx.appcompat.R.styleable.AppCompatTextView_drawableTint
            android.content.res.ColorStateList r1 = r10.getColorStateList(r1)
            android.widget.TextView r2 = r0.mView
            androidx.core.widget.TextViewCompat.setCompoundDrawableTintList(r2, r1)
        L23c:
            int r1 = androidx.appcompat.R.styleable.AppCompatTextView_drawableTintMode
            boolean r1 = r10.hasValue(r1)
            if (r1 == 0) goto L253
            int r1 = androidx.appcompat.R.styleable.AppCompatTextView_drawableTintMode
            int r1 = r10.getInt(r1, r7)
            android.graphics.PorterDuff$Mode r1 = androidx.appcompat.widget.DrawableUtils.parseTintMode(r1, r11)
            android.widget.TextView r2 = r0.mView
            androidx.core.widget.TextViewCompat.setCompoundDrawableTintMode(r2, r1)
        L253:
            int r1 = androidx.appcompat.R.styleable.AppCompatTextView_firstBaselineToTopHeight
            int r1 = r10.getDimensionPixelSize(r1, r7)
            int r2 = androidx.appcompat.R.styleable.AppCompatTextView_lastBaselineToBottomHeight
            int r2 = r10.getDimensionPixelSize(r2, r7)
            int r3 = androidx.appcompat.R.styleable.AppCompatTextView_lineHeight
            int r3 = r10.getDimensionPixelSize(r3, r7)
            r10.recycle()
            if (r1 == r7) goto L26f
            android.widget.TextView r4 = r0.mView
            androidx.core.widget.TextViewCompat.setFirstBaselineToTopHeight(r4, r1)
        L26f:
            if (r2 == r7) goto L276
            android.widget.TextView r1 = r0.mView
            androidx.core.widget.TextViewCompat.setLastBaselineToBottomHeight(r1, r2)
        L276:
            if (r3 == r7) goto L27d
            android.widget.TextView r1 = r0.mView
            androidx.core.widget.TextViewCompat.setLineHeight(r1, r3)
        L27d:
            return
    }

    void onAsyncTypefaceReceived(java.lang.ref.WeakReference<android.widget.TextView> r3, android.graphics.Typeface r4) {
            r2 = this;
            boolean r0 = r2.mAsyncFontPending
            if (r0 == 0) goto L24
            r2.mFontTypeface = r4
            java.lang.Object r3 = r3.get()
            android.widget.TextView r3 = (android.widget.TextView) r3
            if (r3 == 0) goto L24
            boolean r0 = androidx.core.view.ViewCompat.isAttachedToWindow(r3)
            if (r0 == 0) goto L1f
            int r0 = r2.mStyle
            androidx.appcompat.widget.AppCompatTextHelper$2 r1 = new androidx.appcompat.widget.AppCompatTextHelper$2
            r1.<init>(r2, r3, r4, r0)
            r3.post(r1)
            return
        L1f:
            int r0 = r2.mStyle
            r3.setTypeface(r4, r0)
        L24:
            return
    }

    void onLayout(boolean r1, int r2, int r3, int r4, int r5) {
            r0 = this;
            boolean r1 = androidx.appcompat.widget.ViewUtils.SDK_LEVEL_SUPPORTS_AUTOSIZE
            if (r1 != 0) goto L7
            r0.autoSizeText()
        L7:
            return
    }

    void onSetCompoundDrawables() {
            r0 = this;
            r0.applyCompoundDrawablesTints()
            return
    }

    void onSetTextAppearance(android.content.Context r4, int r5) {
            r3 = this;
            int[] r0 = androidx.appcompat.R.styleable.TextAppearance
            androidx.appcompat.widget.TintTypedArray r5 = androidx.appcompat.widget.TintTypedArray.obtainStyledAttributes(r4, r5, r0)
            int r0 = androidx.appcompat.R.styleable.TextAppearance_textAllCaps
            boolean r0 = r5.hasValue(r0)
            r1 = 0
            if (r0 == 0) goto L18
            int r0 = androidx.appcompat.R.styleable.TextAppearance_textAllCaps
            boolean r0 = r5.getBoolean(r0, r1)
            r3.setAllCaps(r0)
        L18:
            int r0 = androidx.appcompat.R.styleable.TextAppearance_android_textSize
            boolean r0 = r5.hasValue(r0)
            if (r0 == 0) goto L2f
            int r0 = androidx.appcompat.R.styleable.TextAppearance_android_textSize
            r2 = -1
            int r0 = r5.getDimensionPixelSize(r0, r2)
            if (r0 != 0) goto L2f
            android.widget.TextView r0 = r3.mView
            r2 = 0
            r0.setTextSize(r1, r2)
        L2f:
            r3.updateTypefaceAndStyle(r4, r5)
            int r4 = android.os.Build.VERSION.SDK_INT
            r0 = 26
            if (r4 < r0) goto L4d
            int r4 = androidx.appcompat.R.styleable.TextAppearance_fontVariationSettings
            boolean r4 = r5.hasValue(r4)
            if (r4 == 0) goto L4d
            int r4 = androidx.appcompat.R.styleable.TextAppearance_fontVariationSettings
            java.lang.String r4 = r5.getString(r4)
            if (r4 == 0) goto L4d
            android.widget.TextView r0 = r3.mView
            androidx.appcompat.widget.AppCompatTextHelper.Api26Impl.setFontVariationSettings(r0, r4)
        L4d:
            r5.recycle()
            android.graphics.Typeface r4 = r3.mFontTypeface
            if (r4 == 0) goto L5b
            android.widget.TextView r5 = r3.mView
            int r0 = r3.mStyle
            r5.setTypeface(r4, r0)
        L5b:
            return
    }

    void populateSurroundingTextIfNeeded(android.widget.TextView r3, android.view.inputmethod.InputConnection r4, android.view.inputmethod.EditorInfo r5) {
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 30
            if (r0 >= r1) goto Lf
            if (r4 == 0) goto Lf
            java.lang.CharSequence r3 = r3.getText()
            androidx.core.view.inputmethod.EditorInfoCompat.setInitialSurroundingText(r5, r3)
        Lf:
            return
    }

    void setAllCaps(boolean r2) {
            r1 = this;
            android.widget.TextView r0 = r1.mView
            r0.setAllCaps(r2)
            return
    }

    void setAutoSizeTextTypeUniformWithConfiguration(int r2, int r3, int r4, int r5) throws java.lang.IllegalArgumentException {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            r0.setAutoSizeTextTypeUniformWithConfiguration(r2, r3, r4, r5)
            return
    }

    void setAutoSizeTextTypeUniformWithPresetSizes(int[] r2, int r3) throws java.lang.IllegalArgumentException {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            r0.setAutoSizeTextTypeUniformWithPresetSizes(r2, r3)
            return
    }

    void setAutoSizeTextTypeWithDefaults(int r2) {
            r1 = this;
            androidx.appcompat.widget.AppCompatTextViewAutoSizeHelper r0 = r1.mAutoSizeTextHelper
            r0.setAutoSizeTextTypeWithDefaults(r2)
            return
    }

    void setCompoundDrawableTintList(android.content.res.ColorStateList r2) {
            r1 = this;
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            if (r0 != 0) goto Lb
            androidx.appcompat.widget.TintInfo r0 = new androidx.appcompat.widget.TintInfo
            r0.<init>()
            r1.mDrawableTint = r0
        Lb:
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            r0.mTintList = r2
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            if (r2 == 0) goto L15
            r2 = 1
            goto L16
        L15:
            r2 = 0
        L16:
            r0.mHasTintList = r2
            r1.setCompoundTints()
            return
    }

    void setCompoundDrawableTintMode(android.graphics.PorterDuff.Mode r2) {
            r1 = this;
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            if (r0 != 0) goto Lb
            androidx.appcompat.widget.TintInfo r0 = new androidx.appcompat.widget.TintInfo
            r0.<init>()
            r1.mDrawableTint = r0
        Lb:
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            r0.mTintMode = r2
            androidx.appcompat.widget.TintInfo r0 = r1.mDrawableTint
            if (r2 == 0) goto L15
            r2 = 1
            goto L16
        L15:
            r2 = 0
        L16:
            r0.mHasTintMode = r2
            r1.setCompoundTints()
            return
    }

    void setTextSize(int r2, float r3) {
            r1 = this;
            boolean r0 = androidx.appcompat.widget.ViewUtils.SDK_LEVEL_SUPPORTS_AUTOSIZE
            if (r0 != 0) goto Ld
            boolean r0 = r1.isAutoSizeEnabled()
            if (r0 != 0) goto Ld
            r1.setTextSizeInternal(r2, r3)
        Ld:
            return
    }
}
