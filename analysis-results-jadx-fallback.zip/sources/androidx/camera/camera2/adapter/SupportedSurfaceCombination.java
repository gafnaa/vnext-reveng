package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: SupportedSurfaceCombination.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u009c\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u001e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0010#\n\u0002\b\u001a\n\u0002\u0010\u0011\n\u0002\b\u001e\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\f\u0018\u0000 Ñ\u00012\u00020\u0001:\bÎ\u0001Ï\u0001Ð\u0001Ñ\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJV\u0010;\u001a\u00020\u001f2\u0006\u0010<\u001a\u00020\u001a2\f\u0010=\u001a\b\u0012\u0004\u0012\u00020>0\u001b2\u0014\b\u0002\u0010?\u001a\u000e\u0012\u0004\u0012\u00020>\u0012\u0004\u0012\u00020A0@2\u0012\b\u0002\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\u000e\b\u0002\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001bJR\u0010E\u001a\u00020F2\u0006\u0010<\u001a\u00020\u001a2\f\u0010=\u001a\b\u0012\u0004\u0012\u00020>0\u001b2\u0012\u0010?\u001a\u000e\u0012\u0004\u0012\u00020>\u0012\u0004\u0012\u00020A0@2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010G\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001bH\u0002JV\u0010H\u001a\n\u0012\u0004\u0012\u00020>\u0018\u00010\u001b2\u0006\u0010<\u001a\u00020\u001a2\u0010\u0010=\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010>\u0018\u00010\u001b2\u0012\u0010I\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020J0\u00192\u0016\u0010K\u001a\u0012\u0012\u0004\u0012\u00020\u000f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u0019H\u0002J\u0016\u0010L\u001a\b\u0012\u0004\u0012\u00020\u00120\u001b2\u0006\u0010<\u001a\u00020\u001aH\u0002J&\u0010M\u001a\u00020>2\u0006\u0010N\u001a\u00020\u000f2\u0006\u0010O\u001a\u00020\u000f2\u0006\u0010P\u001a\u00020Q2\u0006\u0010R\u001a\u00020SJ^\u0010T\u001a\u00020U2\u0006\u0010N\u001a\u00020\u000f2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u001c\u0010W\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0@2\b\b\u0002\u0010X\u001a\u00020Y2\b\b\u0002\u0010Z\u001a\u00020\u001f2\u0006\u0010[\u001a\u00020\u001f2\u0006\u0010\\\u001a\u00020\u001fJ\u0084\u0001\u0010]\u001a\u00020U2\u0006\u0010^\u001a\u00020_2\u0006\u0010<\u001a\u00020\u001a2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u001c\u0010`\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0@2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0016\u0010a\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\u0004\u0012\u00020A0@2\u0006\u0010\\\u001a\u00020\u001fH\u0002J|\u0010b\u001a\u00020U2\u0006\u0010<\u001a\u00020\u001a2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u001c\u0010`\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0@2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0016\u0010a\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\u0004\u0012\u00020A0@2\u0006\u0010\\\u001a\u00020\u001fH\u0002J>\u0010c\u001a\u00020_2\f\u0010d\u001a\b\u0012\u0004\u0012\u00020A0e2\u000e\u0010f\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010g2\u0006\u0010X\u001a\u00020Y2\u0006\u0010h\u001a\u00020\u001f2\u0006\u0010[\u001a\u00020\u001fH\u0002Jn\u0010i\u001a\u00020\u001a2\u0006\u0010N\u001a\u00020\u000f2\u0006\u0010Z\u001a\u00020\u001f2\u0016\u0010a\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\u0004\u0012\u00020A0@2\u0006\u0010X\u001a\u00020Y2\u0006\u0010h\u001a\u00020\u001f2\u0006\u0010j\u001a\u00020\u001f2\u0006\u0010[\u001a\u00020\u001f2\u0006\u0010k\u001a\u00020\u001f2\f\u0010l\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\u0006\u0010m\u001a\u00020\u001fH\u0002J\f\u0010n\u001a\u00020\u001a*\u00020\u001aH\u0002J<\u0010o\u001a\u00020\u001f2\u0006\u0010<\u001a\u00020\u001a2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u001c\u0010W\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0@H\u0002J\u0086\u0001\u0010p\u001a\n\u0012\u0004\u0012\u00020>\u0018\u00010\u001b2\u0012\u0010q\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0\u001b2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0006\u0010<\u001a\u00020\u001a2\u0012\u0010I\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020J0\u00192\u0016\u0010K\u001a\u0012\u0012\u0004\u0012\u00020\u000f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u0019H\u0002J\u0086\u0001\u0010r\u001a\u00020s2\u0006\u0010t\u001a\u00020u2\u000e\u0010v\u001a\n\u0012\u0004\u0012\u00020>\u0018\u00010\u001b2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u0012\u0010w\u001a\u000e\u0012\u0004\u0012\u00020J\u0012\u0004\u0012\u00020x0\u00192\u0016\u0010y\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\u0004\u0012\u00020x0\u00192\u0012\u0010I\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020J0\u00192\u0016\u0010K\u001a\u0012\u0012\u0004\u0012\u00020\u000f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u0019H\u0002JR\u0010z\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0\u001b2\u001c\u0010W\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0@2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001bH\u0002JD\u0010{\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0006\u0010m\u001a\u00020\u001fH\u0002J(\u0010m\u001a\u00020\u001f2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001bH\u0002J\u001e\u0010|\u001a\u00020\u000f2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u0006\u0010j\u001a\u00020\u001fH\u0002JS\u0010}\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0@2\u001c\u0010W\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0@2\u0006\u0010<\u001a\u00020\u001a2\b\b\u0002\u0010~\u001a\u00020\u001fH\u0001¢\u0006\u0002\b\u007fJf\u0010\u0080\u0001\u001a\u00020s2\u0006\u0010<\u001a\u00020\u001a2\u0006\u0010P\u001a\u00020Q2\u0006\u0010O\u001a\u00020\u000f2\u0007\u0010\u0081\u0001\u001a\u00020\u000f2\u0006\u0010R\u001a\u00020S2\u0006\u0010~\u001a\u00020\u001f2\u001b\u0010\u0082\u0001\u001a\u0016\u0012\u0005\u0012\u00030\u0083\u0001\u0012\u000b\u0012\t\u0012\u0004\u0012\u00020\u000f0\u0084\u00010\u00192\r\u0010\u0085\u0001\u001a\b\u0012\u0004\u0012\u00020Q0\u0011H\u0002J\u008f\u0001\u0010\u0086\u0001\u001a\u0004\u0018\u00010u2\u0012\u0010q\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0\u001b2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\u0007\u0010\u0087\u0001\u001a\u00020\u000f2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0006\u0010<\u001a\u00020\u001a2\u000e\u0010v\u001a\n\u0012\u0004\u0012\u00020>\u0018\u00010\u001b2\u0016\u0010a\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\u0004\u0012\u00020A0@2\u0007\u0010\u0088\u0001\u001a\u00020\u001fH\u0002J)\u0010\u0089\u0001\u001a\u00020\u001f2\u0007\u0010\u0087\u0001\u001a\u00020\u000f2\f\u0010l\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\u0007\u0010\u008a\u0001\u001a\u00020\u000fH\u0002Ja\u0010\u008b\u0001\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\u0004\u0012\u00020x0\u00192\u0006\u0010t\u001a\u00020u2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0016\u0010a\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\u0004\u0012\u00020A0@2\u0006\u0010<\u001a\u00020\u001aH\u0002J!\u0010\u008c\u0001\u001a\u00020\u000f2\u0016\u0010a\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0012\u0004\u0012\u00020A0@H\u0002J\u008d\u0001\u0010\u008d\u0001\u001a\b\u0012\u0004\u0012\u00020>0\u001b2\u0006\u0010N\u001a\u00020\u000f2\f\u0010V\u001a\b\u0012\u0004\u0012\u00020J0\u001b2\r\u0010\u008e\u0001\u001a\b\u0012\u0004\u0012\u00020Q0\u001b2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0014\u0010I\u001a\u0010\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020J\u0018\u00010\u00192\u0018\u0010K\u001a\u0014\u0012\u0004\u0012\u00020\u000f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C\u0018\u00010\u00192\u0007\u0010\u008f\u0001\u001a\u00020\u001fH\u0002JI\u0010\u0090\u0001\u001a\u00020\u000f2\r\u0010\u008e\u0001\u001a\b\u0012\u0004\u0012\u00020Q0\u001b2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001b2\f\u0010D\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0007\u0010\u008a\u0001\u001a\u00020\u000f2\u0006\u0010j\u001a\u00020\u001fH\u0002J*\u0010\u0091\u0001\u001a\u00020\u000f2\u0006\u0010O\u001a\u00020\u000f2\u0006\u0010P\u001a\u00020Q2\u0006\u0010j\u001a\u00020\u001f2\u0007\u0010\u0081\u0001\u001a\u00020\u000fH\u0002J\u0019\u0010\u0091\u0001\u001a\u00020\u000f2\u0006\u0010O\u001a\u00020\u000f2\u0006\u0010P\u001a\u00020QH\u0002J\u0018\u0010\u0092\u0001\u001a\u00020\u000f2\r\u0010\u0093\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0gH\u0002J'\u0010\u0094\u0001\u001a\u00020\u000f2\r\u0010\u0095\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\r\u0010\u0096\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0gH\u0002J<\u0010\u0097\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\r\u0010\u0098\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\r\u0010\u0099\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\r\u0010\u009a\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0gH\u0002JG\u0010\u009b\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\r\u0010\u009c\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\u0007\u0010\u009d\u0001\u001a\u00020\u000f2\u0018\u0010\u009e\u0001\u001a\u0013\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u00020\u000f0g\u0018\u00010\u009f\u0001H\u0002¢\u0006\u0003\u0010 \u0001J5\u0010¡\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\r\u0010¢\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\r\u0010£\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0g2\u0006\u0010m\u001a\u00020\u001fH\u0002J#\u0010¤\u0001\u001a\u00020\u001f2\u0007\u0010¥\u0001\u001a\u00020\u001f2\t\u0010¦\u0001\u001a\u0004\u0018\u00010\u001fH\u0002¢\u0006\u0003\u0010§\u0001J3\u0010¨\u0001\u001a\u00020\u000f2\u0007\u0010©\u0001\u001a\u00020\u000f2\u0006\u0010O\u001a\u00020\u000f2\u0006\u0010P\u001a\u00020Q2\u0006\u0010j\u001a\u00020\u001f2\u0007\u0010\u0081\u0001\u001a\u00020\u000fH\u0002J&\u0010ª\u0001\u001a\b\u0012\u0004\u0012\u00020Q0\u001b2\r\u0010«\u0001\u001a\b\u0012\u0004\u0012\u00020Q0\u001b2\u0006\u0010O\u001a\u00020\u000fH\u0007J\t\u0010¬\u0001\u001a\u00020sH\u0002J\t\u0010\u00ad\u0001\u001a\u00020sH\u0002J\t\u0010®\u0001\u001a\u00020sH\u0002J\t\u0010¯\u0001\u001a\u00020sH\u0002J\t\u0010°\u0001\u001a\u00020sH\u0002J\t\u0010±\u0001\u001a\u00020sH\u0002J\t\u0010²\u0001\u001a\u00020sH\u0002J\t\u0010³\u0001\u001a\u00020sH\u0002J\t\u0010´\u0001\u001a\u00020sH\u0002J\t\u0010µ\u0001\u001a\u00020sH\u0002J\t\u0010¶\u0001\u001a\u00020sH\u0002J\u0012\u0010·\u0001\u001a\u00020'2\u0007\u0010¸\u0001\u001a\u00020\u000fH\u0007J0\u0010¹\u0001\u001a\u00020s2\u0013\u0010º\u0001\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020Q0\u00192\u0007\u0010»\u0001\u001a\u00020Q2\u0007\u0010¸\u0001\u001a\u00020\u000fH\u0002J5\u0010¼\u0001\u001a\u00020s2\u0013\u0010º\u0001\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020Q0\u00192\u0007\u0010¸\u0001\u001a\u00020\u000f2\f\b\u0002\u0010½\u0001\u001a\u0005\u0018\u00010¾\u0001H\u0002J'\u0010¿\u0001\u001a\u00020s2\u0013\u0010º\u0001\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020Q0\u00192\u0007\u0010¸\u0001\u001a\u00020\u000fH\u0002J\t\u0010À\u0001\u001a\u00020QH\u0002J\t\u0010Á\u0001\u001a\u00020.H\u0002J\u000b\u0010Â\u0001\u001a\u0004\u0018\u00010QH\u0002J\u000b\u0010Ã\u0001\u001a\u0004\u0018\u00010QH\u0002J!\u0010Ä\u0001\u001a\b\u0012\u0004\u0012\u00020\u000f0\u001b2\u0010\u0010B\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030C0\u001bH\u0002J<\u0010Å\u0001\u001a\u0004\u0018\u00010Q2\n\u0010Æ\u0001\u001a\u0005\u0018\u00010Ç\u00012\u0006\u0010O\u001a\u00020\u000f2\u0007\u0010È\u0001\u001a\u00020\u001f2\f\b\u0002\u0010½\u0001\u001a\u0005\u0018\u00010¾\u0001H\u0000¢\u0006\u0003\bÉ\u0001J:\u0010Ê\u0001\u001a\u000b\u0012\u0004\u0012\u00020Q\u0018\u00010\u009f\u00012\n\u0010Æ\u0001\u001a\u0005\u0018\u00010Ç\u00012\u0006\u0010O\u001a\u00020\u000f2\f\b\u0002\u0010½\u0001\u001a\u0005\u0018\u00010¾\u0001H\u0002¢\u0006\u0003\u0010Ë\u0001J*\u0010Ì\u0001\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u00110\u001b2\u0013\u0010Í\u0001\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020Q0\u001b0\u001bH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\u0018\u001a\u0014\u0012\u0004\u0012\u00020\u001a\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u001b0\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u001fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u001a\u0010&\u001a\u00020'X\u0080.¢\u0006\u000e\n\u0000\u001a\u0004\b(\u0010)\"\u0004\b*\u0010+R\u0014\u0010,\u001a\b\u0012\u0004\u0012\u00020\u000f0\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u000200X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00101\u001a\u000202X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00103\u001a\u000204X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u000206X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u000208X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020:X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006Ò\u0001²\u0006\u000b\u0010Ó\u0001\u001a\u00020\u001fX\u008a\u0084\u0002"}, d2 = {"Landroidx/camera/camera2/adapter/SupportedSurfaceCombination;", "", "context", "Landroid/content/Context;", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "encoderProfilesProvider", "Landroidx/camera/core/impl/EncoderProfilesProvider;", "featureCombinationQuery", "Landroidx/camera/core/featuregroup/impl/FeatureCombinationQuery;", "<init>", "(Landroid/content/Context;Landroidx/camera/camera2/pipe/CameraMetadata;Landroidx/camera/core/impl/EncoderProfilesProvider;Landroidx/camera/core/featuregroup/impl/FeatureCombinationQuery;)V", "cameraId", "", "hardwareLevel", "", "concurrentSurfaceCombinations", "", "Landroidx/camera/core/impl/SurfaceCombination;", "surfaceCombinations", "surfaceCombinationsStreamUseCase", "ultraHighSurfaceCombinations", "previewStabilizationSurfaceCombinations", "highSpeedSurfaceCombinations", "featureSettingsToSupportedCombinationsMap", "", "Landroidx/camera/camera2/adapter/SupportedSurfaceCombination$FeatureSettings;", "", "surfaceCombinations10Bit", "surfaceCombinationsUltraHdr", "isRawSupported", "", "isBurstCaptureSupported", "isConcurrentCameraModeSupported", "isStreamUseCaseSupported", "isUltraHighResolutionSensorSupported", "isPreviewStabilizationSupported", "isManualSensorSupported", "surfaceSizeDefinition", "Landroidx/camera/core/impl/SurfaceSizeDefinition;", "getSurfaceSizeDefinition$camera_camera2", "()Landroidx/camera/core/impl/SurfaceSizeDefinition;", "setSurfaceSizeDefinition$camera_camera2", "(Landroidx/camera/core/impl/SurfaceSizeDefinition;)V", "surfaceSizeDefinitionFormats", "streamConfigurationMapCompat", "Landroidx/camera/camera2/compat/StreamConfigurationMapCompat;", "extraSupportedSurfaceCombinationsContainer", "Landroidx/camera/camera2/compat/workaround/ExtraSupportedSurfaceCombinationsContainer;", "displayInfoManager", "Landroidx/camera/camera2/impl/DisplayInfoManager;", "resolutionCorrector", "Landroidx/camera/camera2/compat/workaround/ResolutionCorrector;", "targetAspectRatio", "Landroidx/camera/camera2/compat/workaround/TargetAspectRatio;", "dynamicRangeResolver", "Landroidx/camera/camera2/internal/DynamicRangeResolver;", "highSpeedResolver", "Landroidx/camera/camera2/internal/HighSpeedResolver;", "checkSupported", "featureSettings", "surfaceConfigList", "Landroidx/camera/core/impl/SurfaceConfig;", "dynamicRangesBySurfaceConfig", "", "Landroidx/camera/core/DynamicRange;", "newUseCaseConfigs", "Landroidx/camera/core/impl/UseCaseConfig;", "useCasesPriorityOrder", "createFeatureComboSessionConfig", "Landroidx/camera/core/impl/SessionConfig;", "useCasePriorityOrder", "getOrderedSupportedStreamUseCaseSurfaceConfigList", "surfaceConfigIndexAttachedSurfaceInfoMap", "Landroidx/camera/core/impl/AttachedSurfaceInfo;", "surfaceConfigIndexUseCaseConfigMap", "getSurfaceCombinationsByFeatureSettings", "transformSurfaceConfig", "cameraMode", "imageFormat", "size", "Landroid/util/Size;", "streamUseCase", "Landroidx/camera/core/impl/StreamUseCase;", "getSuggestedStreamSpecifications", "Landroidx/camera/core/impl/SurfaceStreamSpecQueryResult;", "attachedSurfaces", "newUseCaseConfigsSupportedSizeMap", "videoStabilization", "Landroidx/camera/core/impl/stabilization/VideoStabilization;", "hasVideoCapture", "isFeatureComboInvocation", "findMaxSupportedFrameRate", "resolveSpecsByCheckingMethod", "checkingMethod", "Landroidx/camera/camera2/adapter/SupportedSurfaceCombination$CheckingMethod;", "filteredNewUseCaseConfigsSupportedSizeMap", "resolvedDynamicRanges", "resolveSpecsBySettings", "getCheckingMethod", "dynamicRanges", "", "fps", "Landroid/util/Range;", "isUltraHdrOn", "createFeatureSettings", "isHighSpeedOn", "requiresFeatureComboQuery", "targetFpsRange", "isStrictFpsRequired", "validateSelf", "isUseCasesCombinationSupported", "getOrderedSurfaceConfigListForStreamUseCase", "allPossibleSizeArrangements", "populateStreamUseCaseIfSameSavedSizes", "", "bestSizesAndMaxFps", "Landroidx/camera/camera2/adapter/SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs;", "orderedSurfaceConfigListForStreamUseCase", "attachedSurfaceStreamSpecMap", "Landroidx/camera/core/impl/StreamSpec;", "suggestedStreamSpecMap", "getSupportedOutputSizesList", "getTargetFpsRange", "getMaxSupportedFpsFromAttachedSurfaces", "filterSupportedSizes", "forceUniqueMaxFpsFiltering", "filterSupportedSizes$camera_camera2", "populateReducedSizeListAndUniqueMaxFpsMap", "customMaxFps", "configSizeUniqueMaxFpsMap", "Landroidx/camera/core/impl/SurfaceConfig$ConfigSize;", "", "reducedSizeList", "findBestSizesAndFps", "existingSurfaceFrameRateCeiling", "findMaxFpsForAllSizes", "isConfigFrameRateAcceptable", "currentConfigFrameRateCeiling", "generateSuggestedStreamSpecMap", "getRequiredMaxBitDepth", "getSurfaceConfigList", "possibleSizeList", "checkViaFeatureComboQuery", "getCurrentConfigFrameRateCeiling", "getMaxFrameRate", "getRangeLength", "range", "getRangeDistance", "firstRange", "secondRange", "compareIntersectingRanges", "targetFps", "storedRange", "newRange", "getClosestSupportedDeviceFrameRate", "targetFrameRate", "maxFps", "availableFpsRanges", "", "(Landroid/util/Range;I[Landroid/util/Range;)Landroid/util/Range;", "getUpdatedTargetFrameRate", "newTargetFrameRate", "storedTargetFrameRate", "getAndValidateIsStrictFpsRequired", "newIsStrictFpsRequired", "storedIsStrictFpsRequired", "(ZLjava/lang/Boolean;)Z", "getCombinedMaximumFps", "combinedMaxFps", "applyResolutionSelectionOrderRelatedWorkarounds", "sizeList", "refreshPreviewSize", "checkCapabilities", "generateSupportedCombinationList", "generateUltraHighResolutionSupportedCombinationList", "generateConcurrentSupportedCombinationList", "generatePreviewStabilizationSupportedCombinationList", "generateHighSpeedSupportedCombinationList", "generate10BitSupportedCombinationList", "generateUltraHdrSupportedCombinationList", "generateStreamUseCaseSupportedCombinationList", "generateSurfaceSizeDefinition", "getUpdatedSurfaceSizeDefinitionByFormat", "format", "updateS720pOrS1440pSizeByFormat", "sizeMap", "targetSize", "updateMaximumSizeByFormat", "aspectRatio", "Landroid/util/Rational;", "updateUltraMaximumSizeByFormat", "getRecordSize", "getStreamConfigurationMapCompat", "getRecordSizeFromStreamConfigurationMapCompat", "getRecordSizeFromCamcorderProfile", "getUseCasesPriorityOrder", "getMaxOutputSizeByFormat", "map", "Landroid/hardware/camera2/params/StreamConfigurationMap;", "highResolutionIncluded", "getMaxOutputSizeByFormat$camera_camera2", "getOutputSizes", "(Landroid/hardware/camera2/params/StreamConfigurationMap;ILandroid/util/Rational;)[Landroid/util/Size;", "getAllPossibleSizeArrangements", "supportedOutputSizesList", "FeatureSettings", "BestSizesAndMaxFpsForConfigs", "CheckingMethod", "Companion", "camera-camera2", "isSupported"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class SupportedSurfaceCombination {
    public static final androidx.camera.camera2.adapter.SupportedSurfaceCombination.Companion Companion = null;
    private final java.lang.String cameraId;
    private final androidx.camera.camera2.pipe.CameraMetadata cameraMetadata;
    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> concurrentSurfaceCombinations;
    private final androidx.camera.camera2.impl.DisplayInfoManager displayInfoManager;
    private final androidx.camera.camera2.internal.DynamicRangeResolver dynamicRangeResolver;
    private final androidx.camera.core.impl.EncoderProfilesProvider encoderProfilesProvider;
    private final androidx.camera.camera2.compat.workaround.ExtraSupportedSurfaceCombinationsContainer extraSupportedSurfaceCombinationsContainer;
    private final androidx.camera.core.featuregroup.impl.FeatureCombinationQuery featureCombinationQuery;
    private final java.util.Map<androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings, java.util.List<androidx.camera.core.impl.SurfaceCombination>> featureSettingsToSupportedCombinationsMap;
    private final int hardwareLevel;
    private final androidx.camera.camera2.internal.HighSpeedResolver highSpeedResolver;
    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> highSpeedSurfaceCombinations;
    private boolean isBurstCaptureSupported;
    private final boolean isConcurrentCameraModeSupported;
    private boolean isManualSensorSupported;
    private boolean isPreviewStabilizationSupported;
    private boolean isRawSupported;
    private final boolean isStreamUseCaseSupported;
    private boolean isUltraHighResolutionSensorSupported;
    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> previewStabilizationSurfaceCombinations;
    private final androidx.camera.camera2.compat.workaround.ResolutionCorrector resolutionCorrector;
    private final androidx.camera.camera2.compat.StreamConfigurationMapCompat streamConfigurationMapCompat;
    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> surfaceCombinations;
    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> surfaceCombinations10Bit;
    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> surfaceCombinationsStreamUseCase;
    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> surfaceCombinationsUltraHdr;
    public androidx.camera.core.impl.SurfaceSizeDefinition surfaceSizeDefinition;
    private final java.util.List<java.lang.Integer> surfaceSizeDefinitionFormats;
    private final androidx.camera.camera2.compat.workaround.TargetAspectRatio targetAspectRatio;
    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> ultraHighSurfaceCombinations;

    /* JADX INFO: compiled from: SupportedSurfaceCombination.kt */
    @kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B=\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u000e\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u0011\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0007HÆ\u0003JI\u0010\u0018\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u0010\b\u0002\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u0007HÆ\u0001J\u0014\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u001c\u001a\u00020\u0007HÖ\u0081\u0004J\n\u0010\u001d\u001a\u00020\u001eHÖ\u0081\u0004R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0019\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0011\u0010\t\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0010¨\u0006\u001f"}, d2 = {"Landroidx/camera/camera2/adapter/SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs;", "", "bestSizes", "", "Landroid/util/Size;", "bestSizesForStreamUseCase", "maxFpsForBestSizes", "", "maxFpsForStreamUseCase", "maxFpsForAllSizes", "<init>", "(Ljava/util/List;Ljava/util/List;III)V", "getBestSizes", "()Ljava/util/List;", "getBestSizesForStreamUseCase", "getMaxFpsForBestSizes", "()I", "getMaxFpsForStreamUseCase", "getMaxFpsForAllSizes", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class BestSizesAndMaxFpsForConfigs {
        private final java.util.List<android.util.Size> bestSizes;
        private final java.util.List<android.util.Size> bestSizesForStreamUseCase;
        private final int maxFpsForAllSizes;
        private final int maxFpsForBestSizes;
        private final int maxFpsForStreamUseCase;

        public BestSizesAndMaxFpsForConfigs(java.util.List<android.util.Size> r2, java.util.List<android.util.Size> r3, int r4, int r5, int r6) {
                r1 = this;
                java.lang.String r0 = "bestSizes"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                r1.<init>()
                r1.bestSizes = r2
                r1.bestSizesForStreamUseCase = r3
                r1.maxFpsForBestSizes = r4
                r1.maxFpsForStreamUseCase = r5
                r1.maxFpsForAllSizes = r6
                return
        }

        public static /* synthetic */ androidx.camera.camera2.adapter.SupportedSurfaceCombination.BestSizesAndMaxFpsForConfigs copy$default(androidx.camera.camera2.adapter.SupportedSurfaceCombination.BestSizesAndMaxFpsForConfigs r0, java.util.List r1, java.util.List r2, int r3, int r4, int r5, int r6, java.lang.Object r7) {
                r7 = r6 & 1
                if (r7 == 0) goto L6
                java.util.List<android.util.Size> r1 = r0.bestSizes
            L6:
                r7 = r6 & 2
                if (r7 == 0) goto Lc
                java.util.List<android.util.Size> r2 = r0.bestSizesForStreamUseCase
            Lc:
                r7 = r6 & 4
                if (r7 == 0) goto L12
                int r3 = r0.maxFpsForBestSizes
            L12:
                r7 = r6 & 8
                if (r7 == 0) goto L18
                int r4 = r0.maxFpsForStreamUseCase
            L18:
                r6 = r6 & 16
                if (r6 == 0) goto L1e
                int r5 = r0.maxFpsForAllSizes
            L1e:
                r6 = r4
                r7 = r5
                r4 = r2
                r5 = r3
                r2 = r0
                r3 = r1
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs r0 = r2.copy(r3, r4, r5, r6, r7)
                return r0
        }

        public final java.util.List<android.util.Size> component1() {
                r1 = this;
                java.util.List<android.util.Size> r0 = r1.bestSizes
                return r0
        }

        public final java.util.List<android.util.Size> component2() {
                r1 = this;
                java.util.List<android.util.Size> r0 = r1.bestSizesForStreamUseCase
                return r0
        }

        public final int component3() {
                r1 = this;
                int r0 = r1.maxFpsForBestSizes
                return r0
        }

        public final int component4() {
                r1 = this;
                int r0 = r1.maxFpsForStreamUseCase
                return r0
        }

        public final int component5() {
                r1 = this;
                int r0 = r1.maxFpsForAllSizes
                return r0
        }

        public final androidx.camera.camera2.adapter.SupportedSurfaceCombination.BestSizesAndMaxFpsForConfigs copy(java.util.List<android.util.Size> r8, java.util.List<android.util.Size> r9, int r10, int r11, int r12) {
                r7 = this;
                java.lang.String r0 = "bestSizes"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs r1 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs
                r2 = r8
                r3 = r9
                r4 = r10
                r5 = r11
                r6 = r12
                r1.<init>(r2, r3, r4, r5, r6)
                return r1
        }

        public boolean equals(java.lang.Object r5) {
                r4 = this;
                r0 = 1
                if (r4 != r5) goto L4
                return r0
            L4:
                boolean r1 = r5 instanceof androidx.camera.camera2.adapter.SupportedSurfaceCombination.BestSizesAndMaxFpsForConfigs
                r2 = 0
                if (r1 != 0) goto La
                return r2
            La:
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs r5 = (androidx.camera.camera2.adapter.SupportedSurfaceCombination.BestSizesAndMaxFpsForConfigs) r5
                java.util.List<android.util.Size> r1 = r4.bestSizes
                java.util.List<android.util.Size> r3 = r5.bestSizes
                boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r3)
                if (r1 != 0) goto L17
                return r2
            L17:
                java.util.List<android.util.Size> r1 = r4.bestSizesForStreamUseCase
                java.util.List<android.util.Size> r3 = r5.bestSizesForStreamUseCase
                boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r3)
                if (r1 != 0) goto L22
                return r2
            L22:
                int r1 = r4.maxFpsForBestSizes
                int r3 = r5.maxFpsForBestSizes
                if (r1 == r3) goto L29
                return r2
            L29:
                int r1 = r4.maxFpsForStreamUseCase
                int r3 = r5.maxFpsForStreamUseCase
                if (r1 == r3) goto L30
                return r2
            L30:
                int r1 = r4.maxFpsForAllSizes
                int r5 = r5.maxFpsForAllSizes
                if (r1 == r5) goto L37
                return r2
            L37:
                return r0
        }

        public final java.util.List<android.util.Size> getBestSizes() {
                r1 = this;
                java.util.List<android.util.Size> r0 = r1.bestSizes
                return r0
        }

        public final java.util.List<android.util.Size> getBestSizesForStreamUseCase() {
                r1 = this;
                java.util.List<android.util.Size> r0 = r1.bestSizesForStreamUseCase
                return r0
        }

        public final int getMaxFpsForAllSizes() {
                r1 = this;
                int r0 = r1.maxFpsForAllSizes
                return r0
        }

        public final int getMaxFpsForBestSizes() {
                r1 = this;
                int r0 = r1.maxFpsForBestSizes
                return r0
        }

        public final int getMaxFpsForStreamUseCase() {
                r1 = this;
                int r0 = r1.maxFpsForStreamUseCase
                return r0
        }

        public int hashCode() {
                r2 = this;
                java.util.List<android.util.Size> r0 = r2.bestSizes
                int r0 = r0.hashCode()
                int r0 = r0 * 31
                java.util.List<android.util.Size> r1 = r2.bestSizesForStreamUseCase
                if (r1 != 0) goto Le
                r1 = 0
                goto L12
            Le:
                int r1 = r1.hashCode()
            L12:
                int r0 = r0 + r1
                int r0 = r0 * 31
                int r1 = r2.maxFpsForBestSizes
                int r1 = java.lang.Integer.hashCode(r1)
                int r0 = r0 + r1
                int r0 = r0 * 31
                int r1 = r2.maxFpsForStreamUseCase
                int r1 = java.lang.Integer.hashCode(r1)
                int r0 = r0 + r1
                int r0 = r0 * 31
                int r1 = r2.maxFpsForAllSizes
                int r1 = java.lang.Integer.hashCode(r1)
                int r0 = r0 + r1
                return r0
        }

        public java.lang.String toString() {
                r2 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                java.lang.String r1 = "BestSizesAndMaxFpsForConfigs(bestSizes="
                r0.<init>(r1)
                java.util.List<android.util.Size> r1 = r2.bestSizes
                r0.append(r1)
                java.lang.String r1 = ", bestSizesForStreamUseCase="
                r0.append(r1)
                java.util.List<android.util.Size> r1 = r2.bestSizesForStreamUseCase
                r0.append(r1)
                java.lang.String r1 = ", maxFpsForBestSizes="
                r0.append(r1)
                int r1 = r2.maxFpsForBestSizes
                r0.append(r1)
                java.lang.String r1 = ", maxFpsForStreamUseCase="
                r0.append(r1)
                int r1 = r2.maxFpsForStreamUseCase
                r0.append(r1)
                java.lang.String r1 = ", maxFpsForAllSizes="
                r0.append(r1)
                int r1 = r2.maxFpsForAllSizes
                r0.append(r1)
                r1 = 41
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                return r0
        }
    }

    /* JADX INFO: compiled from: SupportedSurfaceCombination.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0080\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006¨\u0006\u0007"}, d2 = {"Landroidx/camera/camera2/adapter/SupportedSurfaceCombination$CheckingMethod;", "", "<init>", "(Ljava/lang/String;I)V", "WITHOUT_FEATURE_COMBO", "WITH_FEATURE_COMBO", "WITHOUT_FEATURE_COMBO_FIRST_AND_THEN_WITH_IT", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final enum CheckingMethod extends java.lang.Enum<androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod> {
        private static final /* synthetic */ kotlin.enums.EnumEntries $ENTRIES = null;
        private static final /* synthetic */ androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod[] $VALUES = null;
        public static final androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod WITHOUT_FEATURE_COMBO = null;
        public static final androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod WITHOUT_FEATURE_COMBO_FIRST_AND_THEN_WITH_IT = null;
        public static final androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod WITH_FEATURE_COMBO = null;

        private static final /* synthetic */ androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod[] $values() {
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITH_FEATURE_COMBO
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r2 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO_FIRST_AND_THEN_WITH_IT
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod[] r0 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod[]{r0, r1, r2}
                return r0
        }

        static {
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r0 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod
                java.lang.String r1 = "WITHOUT_FEATURE_COMBO"
                r2 = 0
                r0.<init>(r1, r2)
                androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO = r0
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r0 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod
                java.lang.String r1 = "WITH_FEATURE_COMBO"
                r2 = 1
                r0.<init>(r1, r2)
                androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITH_FEATURE_COMBO = r0
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r0 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod
                java.lang.String r1 = "WITHOUT_FEATURE_COMBO_FIRST_AND_THEN_WITH_IT"
                r2 = 2
                r0.<init>(r1, r2)
                androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO_FIRST_AND_THEN_WITH_IT = r0
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod[] r0 = $values()
                androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.$VALUES = r0
                java.lang.Enum[] r0 = (java.lang.Enum[]) r0
                kotlin.enums.EnumEntries r0 = kotlin.enums.EnumEntriesKt.enumEntries(r0)
                androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.$ENTRIES = r0
                return
        }

        private CheckingMethod(java.lang.String r1, int r2) {
                r0 = this;
                r0.<init>(r1, r2)
                return
        }

        public static kotlin.enums.EnumEntries<androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod> getEntries() {
                kotlin.enums.EnumEntries r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.$ENTRIES
                return r0
        }

        public static androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod valueOf(java.lang.String r1) {
                java.lang.Class<androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod> r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.class
                java.lang.Enum r1 = java.lang.Enum.valueOf(r0, r1)
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = (androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod) r1
                return r1
        }

        public static androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod[] values() {
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod[] r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.$VALUES
                java.lang.Object r0 = r0.clone()
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod[] r0 = (androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod[]) r0
                return r0
        }
    }

    /* JADX INFO: compiled from: SupportedSurfaceCombination.kt */
    @kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J4\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u001c\u0010\t\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u000b\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u00070\nH\u0002¨\u0006\r"}, d2 = {"Landroidx/camera/camera2/adapter/SupportedSurfaceCombination$Companion;", "", "<init>", "()V", "isUltraHdrOn", "", "attachedSurfaces", "", "Landroidx/camera/core/impl/AttachedSurfaceInfo;", "newUseCaseConfigsSupportedSizeMap", "", "Landroidx/camera/core/impl/UseCaseConfig;", "Landroid/util/Size;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public static final /* synthetic */ boolean access$isUltraHdrOn(androidx.camera.camera2.adapter.SupportedSurfaceCombination.Companion r0, java.util.List r1, java.util.Map r2) {
                boolean r0 = r0.isUltraHdrOn(r1, r2)
                return r0
        }

        private final boolean isUltraHdrOn(java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r4, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, ? extends java.util.List<android.util.Size>> r5) {
                r3 = this;
                java.util.Iterator r4 = r4.iterator()
            L4:
                boolean r0 = r4.hasNext()
                r1 = 1
                r2 = 4101(0x1005, float:5.747E-42)
                if (r0 == 0) goto L1a
                java.lang.Object r0 = r4.next()
                androidx.camera.core.impl.AttachedSurfaceInfo r0 = (androidx.camera.core.impl.AttachedSurfaceInfo) r0
                int r0 = r0.getImageFormat()
                if (r0 != r2) goto L4
                return r1
            L1a:
                java.util.Set r4 = r5.keySet()
                java.util.Iterator r4 = r4.iterator()
            L22:
                boolean r5 = r4.hasNext()
                if (r5 == 0) goto L35
                java.lang.Object r5 = r4.next()
                androidx.camera.core.impl.UseCaseConfig r5 = (androidx.camera.core.impl.UseCaseConfig) r5
                int r5 = r5.getInputFormat()
                if (r5 != r2) goto L22
                return r1
            L35:
                r4 = 0
                return r4
        }
    }

    /* JADX INFO: compiled from: SupportedSurfaceCombination.kt */
    @kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u001c\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001Bm\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0002\u0010\t\u001a\u00020\u0006\u0012\b\b\u0002\u0010\n\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0006\u0012\b\b\u0002\u0010\f\u001a\u00020\u0006\u0012\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00030\u000e\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0006¢\u0006\u0004\b\u0010\u0010\u0011J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0006HÆ\u0003J\t\u0010\u001f\u001a\u00020\bHÆ\u0003J\t\u0010 \u001a\u00020\u0006HÆ\u0003J\t\u0010!\u001a\u00020\u0006HÆ\u0003J\t\u0010\"\u001a\u00020\u0006HÆ\u0003J\t\u0010#\u001a\u00020\u0006HÆ\u0003J\u000f\u0010$\u001a\b\u0012\u0004\u0012\u00020\u00030\u000eHÆ\u0003J\t\u0010%\u001a\u00020\u0006HÆ\u0003Js\u0010&\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\u00062\b\b\u0002\u0010\n\u001a\u00020\u00062\b\b\u0002\u0010\u000b\u001a\u00020\u00062\b\b\u0002\u0010\f\u001a\u00020\u00062\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00030\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u0006HÆ\u0001J\u0014\u0010'\u001a\u00020\u00062\b\u0010(\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010)\u001a\u00020\u0003HÖ\u0081\u0004J\n\u0010*\u001a\u00020+HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0013R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\t\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0016R\u0011\u0010\n\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0016R\u0011\u0010\u000b\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0016R\u0011\u0010\f\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0016R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00030\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\u000f\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0016¨\u0006,"}, d2 = {"Landroidx/camera/camera2/adapter/SupportedSurfaceCombination$FeatureSettings;", "", "cameraMode", "", "requiredMaxBitDepth", "hasVideoCapture", "", "videoStabilization", "Landroidx/camera/core/impl/stabilization/VideoStabilization;", "isUltraHdrOn", "isHighSpeedOn", "isFeatureComboInvocation", "requiresFeatureComboQuery", "targetFpsRange", "Landroid/util/Range;", "isStrictFpsRequired", "<init>", "(IIZLandroidx/camera/core/impl/stabilization/VideoStabilization;ZZZZLandroid/util/Range;Z)V", "getCameraMode", "()I", "getRequiredMaxBitDepth", "getHasVideoCapture", "()Z", "getVideoStabilization", "()Landroidx/camera/core/impl/stabilization/VideoStabilization;", "getRequiresFeatureComboQuery", "getTargetFpsRange", "()Landroid/util/Range;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "equals", "other", "hashCode", "toString", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class FeatureSettings {
        private final int cameraMode;
        private final boolean hasVideoCapture;
        private final boolean isFeatureComboInvocation;
        private final boolean isHighSpeedOn;
        private final boolean isStrictFpsRequired;
        private final boolean isUltraHdrOn;
        private final int requiredMaxBitDepth;
        private final boolean requiresFeatureComboQuery;
        private final android.util.Range<java.lang.Integer> targetFpsRange;
        private final androidx.camera.core.impl.stabilization.VideoStabilization videoStabilization;

        public FeatureSettings(int r2, int r3, boolean r4, androidx.camera.core.impl.stabilization.VideoStabilization r5, boolean r6, boolean r7, boolean r8, boolean r9, android.util.Range<java.lang.Integer> r10, boolean r11) {
                r1 = this;
                java.lang.String r0 = "videoStabilization"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                java.lang.String r0 = "targetFpsRange"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
                r1.<init>()
                r1.cameraMode = r2
                r1.requiredMaxBitDepth = r3
                r1.hasVideoCapture = r4
                r1.videoStabilization = r5
                r1.isUltraHdrOn = r6
                r1.isHighSpeedOn = r7
                r1.isFeatureComboInvocation = r8
                r1.requiresFeatureComboQuery = r9
                r1.targetFpsRange = r10
                r1.isStrictFpsRequired = r11
                return
        }

        public /* synthetic */ FeatureSettings(int r2, int r3, boolean r4, androidx.camera.core.impl.stabilization.VideoStabilization r5, boolean r6, boolean r7, boolean r8, boolean r9, android.util.Range r10, boolean r11, int r12, kotlin.jvm.internal.DefaultConstructorMarker r13) {
                r1 = this;
                r13 = r12 & 4
                r0 = 0
                if (r13 == 0) goto L6
                r4 = r0
            L6:
                r13 = r12 & 8
                if (r13 == 0) goto Lc
                androidx.camera.core.impl.stabilization.VideoStabilization r5 = androidx.camera.core.impl.stabilization.VideoStabilization.UNSPECIFIED
            Lc:
                r13 = r12 & 16
                if (r13 == 0) goto L11
                r6 = r0
            L11:
                r13 = r12 & 32
                if (r13 == 0) goto L16
                r7 = r0
            L16:
                r13 = r12 & 64
                if (r13 == 0) goto L1b
                r8 = r0
            L1b:
                r13 = r12 & 128(0x80, float:1.8E-43)
                if (r13 == 0) goto L20
                r9 = r0
            L20:
                r13 = r12 & 256(0x100, float:3.59E-43)
                if (r13 == 0) goto L2b
                android.util.Range<java.lang.Integer> r10 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
                java.lang.String r13 = "FRAME_RATE_RANGE_UNSPECIFIED"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r13)
            L2b:
                r12 = r12 & 512(0x200, float:7.17E-43)
                if (r12 == 0) goto L31
                r12 = r0
                goto L32
            L31:
                r12 = r11
            L32:
                r11 = r10
                r10 = r9
                r9 = r8
                r8 = r7
                r7 = r6
                r6 = r5
                r5 = r4
                r4 = r3
                r3 = r2
                r2 = r1
                r2.<init>(r3, r4, r5, r6, r7, r8, r9, r10, r11, r12)
                return
        }

        public static /* synthetic */ androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings copy$default(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r0, int r1, int r2, boolean r3, androidx.camera.core.impl.stabilization.VideoStabilization r4, boolean r5, boolean r6, boolean r7, boolean r8, android.util.Range r9, boolean r10, int r11, java.lang.Object r12) {
                r12 = r11 & 1
                if (r12 == 0) goto L6
                int r1 = r0.cameraMode
            L6:
                r12 = r11 & 2
                if (r12 == 0) goto Lc
                int r2 = r0.requiredMaxBitDepth
            Lc:
                r12 = r11 & 4
                if (r12 == 0) goto L12
                boolean r3 = r0.hasVideoCapture
            L12:
                r12 = r11 & 8
                if (r12 == 0) goto L18
                androidx.camera.core.impl.stabilization.VideoStabilization r4 = r0.videoStabilization
            L18:
                r12 = r11 & 16
                if (r12 == 0) goto L1e
                boolean r5 = r0.isUltraHdrOn
            L1e:
                r12 = r11 & 32
                if (r12 == 0) goto L24
                boolean r6 = r0.isHighSpeedOn
            L24:
                r12 = r11 & 64
                if (r12 == 0) goto L2a
                boolean r7 = r0.isFeatureComboInvocation
            L2a:
                r12 = r11 & 128(0x80, float:1.8E-43)
                if (r12 == 0) goto L30
                boolean r8 = r0.requiresFeatureComboQuery
            L30:
                r12 = r11 & 256(0x100, float:3.59E-43)
                if (r12 == 0) goto L36
                android.util.Range<java.lang.Integer> r9 = r0.targetFpsRange
            L36:
                r11 = r11 & 512(0x200, float:7.17E-43)
                if (r11 == 0) goto L3c
                boolean r10 = r0.isStrictFpsRequired
            L3c:
                r11 = r9
                r12 = r10
                r9 = r7
                r10 = r8
                r7 = r5
                r8 = r6
                r5 = r3
                r6 = r4
                r3 = r1
                r4 = r2
                r2 = r0
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r0 = r2.copy(r3, r4, r5, r6, r7, r8, r9, r10, r11, r12)
                return r0
        }

        public final int component1() {
                r1 = this;
                int r0 = r1.cameraMode
                return r0
        }

        public final boolean component10() {
                r1 = this;
                boolean r0 = r1.isStrictFpsRequired
                return r0
        }

        public final int component2() {
                r1 = this;
                int r0 = r1.requiredMaxBitDepth
                return r0
        }

        public final boolean component3() {
                r1 = this;
                boolean r0 = r1.hasVideoCapture
                return r0
        }

        public final androidx.camera.core.impl.stabilization.VideoStabilization component4() {
                r1 = this;
                androidx.camera.core.impl.stabilization.VideoStabilization r0 = r1.videoStabilization
                return r0
        }

        public final boolean component5() {
                r1 = this;
                boolean r0 = r1.isUltraHdrOn
                return r0
        }

        public final boolean component6() {
                r1 = this;
                boolean r0 = r1.isHighSpeedOn
                return r0
        }

        public final boolean component7() {
                r1 = this;
                boolean r0 = r1.isFeatureComboInvocation
                return r0
        }

        public final boolean component8() {
                r1 = this;
                boolean r0 = r1.requiresFeatureComboQuery
                return r0
        }

        public final android.util.Range<java.lang.Integer> component9() {
                r1 = this;
                android.util.Range<java.lang.Integer> r0 = r1.targetFpsRange
                return r0
        }

        public final androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings copy(int r13, int r14, boolean r15, androidx.camera.core.impl.stabilization.VideoStabilization r16, boolean r17, boolean r18, boolean r19, boolean r20, android.util.Range<java.lang.Integer> r21, boolean r22) {
                r12 = this;
                java.lang.String r0 = "videoStabilization"
                r5 = r16
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                java.lang.String r0 = "targetFpsRange"
                r10 = r21
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r1 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings
                r2 = r13
                r3 = r14
                r4 = r15
                r6 = r17
                r7 = r18
                r8 = r19
                r9 = r20
                r11 = r22
                r1.<init>(r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
                return r1
        }

        public boolean equals(java.lang.Object r5) {
                r4 = this;
                r0 = 1
                if (r4 != r5) goto L4
                return r0
            L4:
                boolean r1 = r5 instanceof androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings
                r2 = 0
                if (r1 != 0) goto La
                return r2
            La:
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r5 = (androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings) r5
                int r1 = r4.cameraMode
                int r3 = r5.cameraMode
                if (r1 == r3) goto L13
                return r2
            L13:
                int r1 = r4.requiredMaxBitDepth
                int r3 = r5.requiredMaxBitDepth
                if (r1 == r3) goto L1a
                return r2
            L1a:
                boolean r1 = r4.hasVideoCapture
                boolean r3 = r5.hasVideoCapture
                if (r1 == r3) goto L21
                return r2
            L21:
                androidx.camera.core.impl.stabilization.VideoStabilization r1 = r4.videoStabilization
                androidx.camera.core.impl.stabilization.VideoStabilization r3 = r5.videoStabilization
                if (r1 == r3) goto L28
                return r2
            L28:
                boolean r1 = r4.isUltraHdrOn
                boolean r3 = r5.isUltraHdrOn
                if (r1 == r3) goto L2f
                return r2
            L2f:
                boolean r1 = r4.isHighSpeedOn
                boolean r3 = r5.isHighSpeedOn
                if (r1 == r3) goto L36
                return r2
            L36:
                boolean r1 = r4.isFeatureComboInvocation
                boolean r3 = r5.isFeatureComboInvocation
                if (r1 == r3) goto L3d
                return r2
            L3d:
                boolean r1 = r4.requiresFeatureComboQuery
                boolean r3 = r5.requiresFeatureComboQuery
                if (r1 == r3) goto L44
                return r2
            L44:
                android.util.Range<java.lang.Integer> r1 = r4.targetFpsRange
                android.util.Range<java.lang.Integer> r3 = r5.targetFpsRange
                boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r3)
                if (r1 != 0) goto L4f
                return r2
            L4f:
                boolean r1 = r4.isStrictFpsRequired
                boolean r5 = r5.isStrictFpsRequired
                if (r1 == r5) goto L56
                return r2
            L56:
                return r0
        }

        public final int getCameraMode() {
                r1 = this;
                int r0 = r1.cameraMode
                return r0
        }

        public final boolean getHasVideoCapture() {
                r1 = this;
                boolean r0 = r1.hasVideoCapture
                return r0
        }

        public final int getRequiredMaxBitDepth() {
                r1 = this;
                int r0 = r1.requiredMaxBitDepth
                return r0
        }

        public final boolean getRequiresFeatureComboQuery() {
                r1 = this;
                boolean r0 = r1.requiresFeatureComboQuery
                return r0
        }

        public final android.util.Range<java.lang.Integer> getTargetFpsRange() {
                r1 = this;
                android.util.Range<java.lang.Integer> r0 = r1.targetFpsRange
                return r0
        }

        public final androidx.camera.core.impl.stabilization.VideoStabilization getVideoStabilization() {
                r1 = this;
                androidx.camera.core.impl.stabilization.VideoStabilization r0 = r1.videoStabilization
                return r0
        }

        public int hashCode() {
                r2 = this;
                int r0 = r2.cameraMode
                int r0 = java.lang.Integer.hashCode(r0)
                int r0 = r0 * 31
                int r1 = r2.requiredMaxBitDepth
                int r1 = java.lang.Integer.hashCode(r1)
                int r0 = r0 + r1
                int r0 = r0 * 31
                boolean r1 = r2.hasVideoCapture
                int r1 = java.lang.Boolean.hashCode(r1)
                int r0 = r0 + r1
                int r0 = r0 * 31
                androidx.camera.core.impl.stabilization.VideoStabilization r1 = r2.videoStabilization
                int r1 = r1.hashCode()
                int r0 = r0 + r1
                int r0 = r0 * 31
                boolean r1 = r2.isUltraHdrOn
                int r1 = java.lang.Boolean.hashCode(r1)
                int r0 = r0 + r1
                int r0 = r0 * 31
                boolean r1 = r2.isHighSpeedOn
                int r1 = java.lang.Boolean.hashCode(r1)
                int r0 = r0 + r1
                int r0 = r0 * 31
                boolean r1 = r2.isFeatureComboInvocation
                int r1 = java.lang.Boolean.hashCode(r1)
                int r0 = r0 + r1
                int r0 = r0 * 31
                boolean r1 = r2.requiresFeatureComboQuery
                int r1 = java.lang.Boolean.hashCode(r1)
                int r0 = r0 + r1
                int r0 = r0 * 31
                android.util.Range<java.lang.Integer> r1 = r2.targetFpsRange
                int r1 = r1.hashCode()
                int r0 = r0 + r1
                int r0 = r0 * 31
                boolean r1 = r2.isStrictFpsRequired
                int r1 = java.lang.Boolean.hashCode(r1)
                int r0 = r0 + r1
                return r0
        }

        public final boolean isFeatureComboInvocation() {
                r1 = this;
                boolean r0 = r1.isFeatureComboInvocation
                return r0
        }

        public final boolean isHighSpeedOn() {
                r1 = this;
                boolean r0 = r1.isHighSpeedOn
                return r0
        }

        public final boolean isStrictFpsRequired() {
                r1 = this;
                boolean r0 = r1.isStrictFpsRequired
                return r0
        }

        public final boolean isUltraHdrOn() {
                r1 = this;
                boolean r0 = r1.isUltraHdrOn
                return r0
        }

        public java.lang.String toString() {
                r2 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                java.lang.String r1 = "FeatureSettings(cameraMode="
                r0.<init>(r1)
                int r1 = r2.cameraMode
                r0.append(r1)
                java.lang.String r1 = ", requiredMaxBitDepth="
                r0.append(r1)
                int r1 = r2.requiredMaxBitDepth
                r0.append(r1)
                java.lang.String r1 = ", hasVideoCapture="
                r0.append(r1)
                boolean r1 = r2.hasVideoCapture
                r0.append(r1)
                java.lang.String r1 = ", videoStabilization="
                r0.append(r1)
                androidx.camera.core.impl.stabilization.VideoStabilization r1 = r2.videoStabilization
                r0.append(r1)
                java.lang.String r1 = ", isUltraHdrOn="
                r0.append(r1)
                boolean r1 = r2.isUltraHdrOn
                r0.append(r1)
                java.lang.String r1 = ", isHighSpeedOn="
                r0.append(r1)
                boolean r1 = r2.isHighSpeedOn
                r0.append(r1)
                java.lang.String r1 = ", isFeatureComboInvocation="
                r0.append(r1)
                boolean r1 = r2.isFeatureComboInvocation
                r0.append(r1)
                java.lang.String r1 = ", requiresFeatureComboQuery="
                r0.append(r1)
                boolean r1 = r2.requiresFeatureComboQuery
                r0.append(r1)
                java.lang.String r1 = ", targetFpsRange="
                r0.append(r1)
                android.util.Range<java.lang.Integer> r1 = r2.targetFpsRange
                r0.append(r1)
                java.lang.String r1 = ", isStrictFpsRequired="
                r0.append(r1)
                boolean r1 = r2.isStrictFpsRequired
                r0.append(r1)
                r1 = 41
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                return r0
        }
    }

    /* JADX INFO: compiled from: SupportedSurfaceCombination.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0 = null;

        static {
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod[] r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO     // Catch: java.lang.NoSuchFieldError -> L10
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L10
                r2 = 1
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L10
            L10:
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITH_FEATURE_COMBO     // Catch: java.lang.NoSuchFieldError -> L19
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L19
                r2 = 2
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L19
            L19:
                androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO_FIRST_AND_THEN_WITH_IT     // Catch: java.lang.NoSuchFieldError -> L22
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L22
                r2 = 3
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L22
            L22:
                androidx.camera.camera2.adapter.SupportedSurfaceCombination.WhenMappings.$EnumSwitchMapping$0 = r0
                return
        }
    }

    /* JADX INFO: renamed from: $r8$lambda$AIKuh7GQDbRn08R1-pkBcnmI0Eg, reason: not valid java name */
    public static /* synthetic */ boolean m79$r8$lambda$AIKuh7GQDbRn08R1pkBcnmI0Eg(androidx.camera.camera2.adapter.SupportedSurfaceCombination r0, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r1, java.util.List r2, java.util.Map r3, java.util.List r4, java.util.List r5) {
            boolean r0 = findBestSizesAndFps$lambda$1(r0, r1, r2, r3, r4, r5)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$ZAyBRcPqp063M8JGaa-rqhb9m9A, reason: not valid java name */
    public static /* synthetic */ boolean m80$r8$lambda$ZAyBRcPqp063M8JGaarqhb9m9A(androidx.camera.camera2.adapter.SupportedSurfaceCombination r0, java.util.List r1) {
            boolean r0 = getOrderedSupportedStreamUseCaseSurfaceConfigList$lambda$0(r0, r1)
            return r0
    }

    static {
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$Companion r0 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.adapter.SupportedSurfaceCombination.Companion = r0
            return
    }

    public SupportedSurfaceCombination(android.content.Context r2, androidx.camera.camera2.pipe.CameraMetadata r3, androidx.camera.core.impl.EncoderProfilesProvider r4, androidx.camera.core.featuregroup.impl.FeatureCombinationQuery r5) {
            r1 = this;
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "cameraMetadata"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "encoderProfilesProvider"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "featureCombinationQuery"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            r1.<init>()
            r1.cameraMetadata = r3
            r1.encoderProfilesProvider = r4
            r1.featureCombinationQuery = r5
            java.lang.String r4 = r3.mo469getCameraDz_R5H8()
            r1.cameraId = r4
            android.hardware.camera2.CameraCharacteristics$Key r4 = android.hardware.camera2.CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL
            java.lang.String r5 = "INFO_SUPPORTED_HARDWARE_LEVEL"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r5)
            java.lang.Object r4 = r3.get(r4)
            java.lang.Integer r4 = (java.lang.Integer) r4
            if (r4 == 0) goto L37
            int r4 = r4.intValue()
            goto L38
        L37:
            r4 = 2
        L38:
            r1.hardwareLevel = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.concurrentSurfaceCombinations = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.surfaceCombinations = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.surfaceCombinationsStreamUseCase = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.ultraHighSurfaceCombinations = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.previewStabilizationSurfaceCombinations = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.highSpeedSurfaceCombinations = r4
            java.util.LinkedHashMap r4 = new java.util.LinkedHashMap
            r4.<init>()
            java.util.Map r4 = (java.util.Map) r4
            r1.featureSettingsToSupportedCombinationsMap = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.surfaceCombinations10Bit = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.surfaceCombinationsUltraHdr = r4
            androidx.camera.camera2.pipe.CameraMetadata$Companion r4 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            boolean r4 = r4.getSupportsPreviewStabilization(r3)
            r1.isPreviewStabilizationSupported = r4
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            java.util.List r4 = (java.util.List) r4
            r1.surfaceSizeDefinitionFormats = r4
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r4 = r1.getStreamConfigurationMapCompat()
            r1.streamConfigurationMapCompat = r4
            androidx.camera.camera2.compat.workaround.ExtraSupportedSurfaceCombinationsContainer r4 = new androidx.camera.camera2.compat.workaround.ExtraSupportedSurfaceCombinationsContainer
            r4.<init>()
            r1.extraSupportedSurfaceCombinationsContainer = r4
            androidx.camera.camera2.impl.DisplayInfoManager$Companion r4 = androidx.camera.camera2.impl.DisplayInfoManager.Companion
            androidx.camera.camera2.impl.DisplayInfoManager r4 = r4.getInstance(r2)
            r1.displayInfoManager = r4
            androidx.camera.camera2.compat.workaround.ResolutionCorrector r4 = new androidx.camera.camera2.compat.workaround.ResolutionCorrector
            r4.<init>()
            r1.resolutionCorrector = r4
            androidx.camera.camera2.compat.workaround.TargetAspectRatio r4 = new androidx.camera.camera2.compat.workaround.TargetAspectRatio
            r4.<init>()
            r1.targetAspectRatio = r4
            androidx.camera.camera2.internal.DynamicRangeResolver r4 = new androidx.camera.camera2.internal.DynamicRangeResolver
            r4.<init>(r3)
            r1.dynamicRangeResolver = r4
            androidx.camera.camera2.internal.HighSpeedResolver r5 = new androidx.camera.camera2.internal.HighSpeedResolver
            r5.<init>(r3)
            r1.highSpeedResolver = r5
            r1.checkCapabilities()
            r1.generateSupportedCombinationList()
            boolean r5 = r1.isUltraHighResolutionSensorSupported
            if (r5 == 0) goto Lda
            r1.generateUltraHighResolutionSupportedCombinationList()
        Lda:
            android.content.pm.PackageManager r2 = r2.getPackageManager()
            java.lang.String r5 = "android.hardware.camera.concurrent"
            boolean r2 = r2.hasSystemFeature(r5)
            r1.isConcurrentCameraModeSupported = r2
            if (r2 == 0) goto Leb
            r1.generateConcurrentSupportedCombinationList()
        Leb:
            boolean r2 = r4.is10BitDynamicRangeSupported()
            if (r2 == 0) goto Lf4
            r1.generate10BitSupportedCombinationList()
        Lf4:
            boolean r2 = r1.isPreviewStabilizationSupported
            if (r2 == 0) goto Lfb
            r1.generatePreviewStabilizationSupportedCombinationList()
        Lfb:
            androidx.camera.camera2.internal.StreamUseCaseUtil r2 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            boolean r2 = r2.isStreamUseCaseSupported(r3)
            r1.isStreamUseCaseSupported = r2
            if (r2 == 0) goto L108
            r1.generateStreamUseCaseSupportedCombinationList()
        L108:
            r1.generateSurfaceSizeDefinition()
            return
    }

    public static final /* synthetic */ boolean access$isPreviewStabilizationSupported$p(androidx.camera.camera2.adapter.SupportedSurfaceCombination r0) {
            boolean r0 = r0.isPreviewStabilizationSupported
            return r0
    }

    private final void checkCapabilities() {
            r3 = this;
            androidx.camera.camera2.pipe.CameraMetadata r0 = r3.cameraMetadata
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES
            java.lang.String r2 = "REQUEST_AVAILABLE_CAPABILITIES"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            int[] r0 = (int[]) r0
            if (r0 == 0) goto L2e
            r1 = 3
            boolean r1 = kotlin.collections.ArraysKt.contains(r0, r1)
            r3.isRawSupported = r1
            r1 = 6
            boolean r1 = kotlin.collections.ArraysKt.contains(r0, r1)
            r3.isBurstCaptureSupported = r1
            r1 = 16
            boolean r1 = kotlin.collections.ArraysKt.contains(r0, r1)
            r3.isUltraHighResolutionSensorSupported = r1
            r1 = 1
            boolean r0 = kotlin.collections.ArraysKt.contains(r0, r1)
            r3.isManualSensorSupported = r0
        L2e:
            return
    }

    public static /* synthetic */ boolean checkSupported$default(androidx.camera.camera2.adapter.SupportedSurfaceCombination r6, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r7, java.util.List r8, java.util.Map r9, java.util.List r10, java.util.List r11, int r12, java.lang.Object r13) {
            r13 = r12 & 4
            if (r13 == 0) goto L8
            java.util.Map r9 = kotlin.collections.MapsKt.emptyMap()
        L8:
            r3 = r9
            r9 = r12 & 8
            if (r9 == 0) goto L11
            java.util.List r10 = kotlin.collections.CollectionsKt.emptyList()
        L11:
            r4 = r10
            r9 = r12 & 16
            if (r9 == 0) goto L1a
            java.util.List r11 = kotlin.collections.CollectionsKt.emptyList()
        L1a:
            r0 = r6
            r1 = r7
            r2 = r8
            r5 = r11
            boolean r6 = r0.checkSupported(r1, r2, r3, r4, r5)
            return r6
    }

    private final android.util.Range<java.lang.Integer> compareIntersectingRanges(android.util.Range<java.lang.Integer> r11, android.util.Range<java.lang.Integer> r12, android.util.Range<java.lang.Integer> r13) {
            r10 = this;
            android.util.Range r0 = r12.intersect(r11)
            java.lang.String r1 = "intersect(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            int r0 = r10.getRangeLength(r0)
            double r2 = (double) r0
            android.util.Range r11 = r13.intersect(r11)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r1)
            int r11 = r10.getRangeLength(r11)
            double r0 = (double) r11
            int r11 = r10.getRangeLength(r13)
            double r4 = (double) r11
            double r4 = r0 / r4
            int r11 = r10.getRangeLength(r12)
            double r6 = (double) r11
            double r6 = r2 / r6
            int r11 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            r8 = 4602678819172646912(0x3fe0000000000000, double:0.5)
            if (r11 <= 0) goto L37
            int r11 = (r4 > r8 ? 1 : (r4 == r8 ? 0 : -1))
            if (r11 >= 0) goto L64
            int r11 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r11 < 0) goto L65
            goto L64
        L37:
            int r11 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r11 != 0) goto L5c
            int r11 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r11 <= 0) goto L40
            goto L64
        L40:
            int r11 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r11 != 0) goto L5b
            java.lang.Comparable r11 = r13.getLower()
            java.lang.Number r11 = (java.lang.Number) r11
            int r11 = r11.intValue()
            java.lang.Comparable r0 = r12.getLower()
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            if (r11 <= r0) goto L65
            goto L64
        L5b:
            return r12
        L5c:
            int r11 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r11 >= 0) goto L65
            int r11 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r11 <= 0) goto L65
        L64:
            return r13
        L65:
            return r12
    }

    private final androidx.camera.core.impl.SessionConfig createFeatureComboSessionConfig(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r10, java.util.List<androidx.camera.core.impl.SurfaceConfig> r11, java.util.Map<androidx.camera.core.impl.SurfaceConfig, androidx.camera.core.DynamicRange> r12, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r13, java.util.List<java.lang.Integer> r14) {
            r9 = this;
            androidx.camera.core.impl.SessionConfig$ValidatingBuilder r0 = new androidx.camera.core.impl.SessionConfig$ValidatingBuilder
            r0.<init>()
            r1 = r11
            java.lang.Iterable r1 = (java.lang.Iterable) r1
            java.util.Iterator r1 = r1.iterator()
            r2 = 0
        Ld:
            boolean r3 = r1.hasNext()
            if (r3 == 0) goto Ld7
            java.lang.Object r3 = r1.next()
            int r4 = r2 + 1
            if (r2 >= 0) goto L1e
            kotlin.collections.CollectionsKt.throwIndexOverflow()
        L1e:
            androidx.camera.core.impl.SurfaceConfig r3 = (androidx.camera.core.impl.SurfaceConfig) r3
            int r5 = r3.getImageFormat()
            androidx.camera.core.impl.SurfaceSizeDefinition r5 = r9.getUpdatedSurfaceSizeDefinitionByFormat(r5)
            android.util.Size r5 = r3.getResolution(r5)
            java.lang.Object r2 = r14.get(r2)
            java.lang.Number r2 = (java.lang.Number) r2
            int r2 = r2.intValue()
            java.lang.Object r2 = r13.get(r2)
            androidx.camera.core.impl.UseCaseConfig r2 = (androidx.camera.core.impl.UseCaseConfig) r2
            androidx.camera.core.featuregroup.impl.FeatureCombinationQuery$Companion r6 = androidx.camera.core.featuregroup.impl.FeatureCombinationQuery.Companion
            java.lang.Object r7 = r12.get(r3)
            if (r7 == 0) goto Lcb
            androidx.camera.core.DynamicRange r7 = (androidx.camera.core.DynamicRange) r7
            androidx.camera.core.impl.SessionConfig$Builder r5 = r6.createSessionConfigBuilder(r2, r5, r7)
            android.util.Range r6 = r10.getTargetFpsRange()
            android.util.Range<java.lang.Integer> r7 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r7 = kotlin.jvm.internal.Intrinsics.areEqual(r6, r7)
            r8 = r7 ^ 1
            java.lang.Boolean r8 = java.lang.Boolean.valueOf(r8)
            r8.getClass()
            if (r7 != 0) goto L60
            goto L61
        L60:
            r6 = 0
        L61:
            if (r6 != 0) goto L65
            android.util.Range<java.lang.Integer> r6 = androidx.camera.core.featuregroup.impl.feature.FpsRangeFeature.DEFAULT_FPS_RANGE
        L65:
            r5.setExpectedFrameRateRange(r6)
            androidx.camera.core.impl.stabilization.VideoStabilization r6 = r10.getVideoStabilization()
            androidx.camera.core.impl.stabilization.VideoStabilization r7 = androidx.camera.core.impl.stabilization.VideoStabilization.PREVIEW
            r8 = 2
            if (r6 != r7) goto L75
            r5.setPreviewStabilization(r8)
            goto L80
        L75:
            androidx.camera.core.impl.stabilization.VideoStabilization r6 = r10.getVideoStabilization()
            androidx.camera.core.impl.stabilization.VideoStabilization r7 = androidx.camera.core.impl.stabilization.VideoStabilization.ON
            if (r6 != r7) goto L80
            r5.setVideoStabilization(r8)
        L80:
            androidx.camera.core.impl.SessionConfig r5 = r5.build()
            r0.add(r5)
            boolean r5 = r0.isValid()
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            java.lang.String r7 = "Cannot create a combined SessionConfig for feature combo after adding "
            r6.<init>(r7)
            r6.append(r2)
            java.lang.String r2 = " with "
            r6.append(r2)
            r6.append(r3)
            java.lang.String r2 = " due to ["
            r6.append(r2)
            java.lang.String r2 = r0.getInvalidReason()
            r6.append(r2)
            java.lang.String r2 = "]; surfaceConfigList = "
            r6.append(r2)
            r6.append(r11)
            java.lang.String r2 = ", featureSettings = "
            r6.append(r2)
            r6.append(r10)
            java.lang.String r2 = ", newUseCaseConfigs = "
            r6.append(r2)
            r6.append(r13)
            java.lang.String r2 = r6.toString()
            androidx.core.util.Preconditions.checkState(r5, r2)
            r2 = r4
            goto Ld
        Lcb:
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException
            java.lang.String r11 = "Required value was null."
            java.lang.String r11 = r11.toString()
            r10.<init>(r11)
            throw r10
        Ld7:
            androidx.camera.core.impl.SessionConfig r10 = r0.build()
            java.lang.String r11 = "build(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r11)
            return r10
    }

    private final androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings createFeatureSettings(int r12, boolean r13, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, androidx.camera.core.DynamicRange> r14, androidx.camera.core.impl.stabilization.VideoStabilization r15, boolean r16, boolean r17, boolean r18, boolean r19, android.util.Range<java.lang.Integer> r20, boolean r21) {
            r11 = this;
            int r2 = r11.getRequiredMaxBitDepth(r14)
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r0 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings
            r1 = r12
            r3 = r13
            r4 = r15
            r5 = r16
            r6 = r17
            r7 = r18
            r8 = r19
            r9 = r20
            r10 = r21
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10)
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r12 = r11.validateSelf(r0)
            return r12
    }

    public static /* synthetic */ java.util.Map filterSupportedSizes$camera_camera2$default(androidx.camera.camera2.adapter.SupportedSurfaceCombination r0, java.util.Map r1, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r2, boolean r3, int r4, java.lang.Object r5) {
            r4 = r4 & 4
            if (r4 == 0) goto L5
            r3 = 0
        L5:
            java.util.Map r0 = r0.filterSupportedSizes$camera_camera2(r1, r2, r3)
            return r0
    }

    private final androidx.camera.camera2.adapter.SupportedSurfaceCombination.BestSizesAndMaxFpsForConfigs findBestSizesAndFps(java.util.List<? extends java.util.List<android.util.Size>> r25, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r26, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r27, int r28, java.util.List<java.lang.Integer> r29, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r30, java.util.List<androidx.camera.core.impl.SurfaceConfig> r31, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, androidx.camera.core.DynamicRange> r32, boolean r33) {
            r24 = this;
            java.util.Iterator r9 = r25.iterator()
            r0 = 2147483647(0x7fffffff, float:NaN)
            r13 = 2147483647(0x7fffffff, float:NaN)
            r14 = 2147483647(0x7fffffff, float:NaN)
            r15 = 0
            r16 = 0
            r17 = 0
            r18 = 0
        L14:
            boolean r1 = r9.hasNext()
            if (r1 == 0) goto L14a
            java.lang.Object r1 = r9.next()
            java.util.List r1 = (java.util.List) r1
            java.util.LinkedHashMap r2 = new java.util.LinkedHashMap
            r2.<init>()
            r6 = r2
            java.util.Map r6 = (java.util.Map) r6
            java.util.LinkedHashMap r2 = new java.util.LinkedHashMap
            r2.<init>()
            r7 = r2
            java.util.Map r7 = (java.util.Map) r7
            r3 = r1
            int r1 = r30.getCameraMode()
            boolean r8 = r30.getRequiresFeatureComboQuery()
            r2 = r26
            r4 = r27
            r5 = r29
            r10 = r0
            r25 = 0
            r0 = r24
            java.util.List r8 = r0.getSurfaceConfigList(r1, r2, r3, r4, r5, r6, r7, r8)
            r23 = r7
            r7 = r6
            r6 = r23
            boolean r5 = r30.isHighSpeedOn()
            r2 = r27
            r4 = r28
            r1 = r3
            r3 = r29
            int r5 = r0.getCurrentConfigFrameRateCeiling(r1, r2, r3, r4, r5)
            r19 = r1
            android.util.Range r1 = r30.getTargetFpsRange()
            r2 = r28
            boolean r20 = r0.isConfigFrameRateAcceptable(r2, r1, r5)
            java.util.LinkedHashMap r1 = new java.util.LinkedHashMap
            r1.<init>()
            r4 = r1
            java.util.Map r4 = (java.util.Map) r4
            r1 = r8
            java.lang.Iterable r1 = (java.lang.Iterable) r1
            java.util.Iterator r1 = r1.iterator()
            r3 = 0
        L78:
            boolean r21 = r1.hasNext()
            if (r21 == 0) goto Lc8
            java.lang.Object r21 = r1.next()
            int r22 = r3 + 1
            if (r3 >= 0) goto L89
            kotlin.collections.CollectionsKt.throwIndexOverflow()
        L89:
            r12 = r21
            androidx.camera.core.impl.SurfaceConfig r12 = (androidx.camera.core.impl.SurfaceConfig) r12
            java.lang.Integer r11 = java.lang.Integer.valueOf(r3)
            java.lang.Object r11 = r7.get(r11)
            androidx.camera.core.impl.AttachedSurfaceInfo r11 = (androidx.camera.core.impl.AttachedSurfaceInfo) r11
            if (r11 == 0) goto La4
            androidx.camera.core.DynamicRange r11 = r11.getDynamicRange()
            if (r11 != 0) goto La0
            goto La4
        La0:
            r3 = r11
            r11 = r32
            goto Lb6
        La4:
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            java.lang.Object r3 = r6.get(r3)
            r11 = r32
            java.lang.Object r3 = r11.get(r3)
            if (r3 == 0) goto Lbc
            androidx.camera.core.DynamicRange r3 = (androidx.camera.core.DynamicRange) r3
        Lb6:
            r4.put(r12, r3)
            r3 = r22
            goto L78
        Lbc:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "Required value was null."
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        Lc8:
            r11 = r32
            kotlin.LazyThreadSafetyMode r12 = kotlin.LazyThreadSafetyMode.NONE
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$$ExternalSyntheticLambda2 r0 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$$ExternalSyntheticLambda2
            r1 = r24
            r2 = r30
            r3 = r8
            r22 = r9
            r9 = r5
            r8 = r6
            r5 = r27
            r6 = r29
            r0.<init>(r1, r2, r3, r4, r5, r6)
            r23 = r1
            r1 = r0
            r0 = r23
            kotlin.Lazy r1 = kotlin.LazyKt.lazy(r12, r1)
            if (r33 == 0) goto Lf8
            boolean r2 = findBestSizesAndFps$lambda$2(r1)
            if (r2 == 0) goto Lf8
            r2 = 2147483647(0x7fffffff, float:NaN)
            if (r13 != r2) goto Lf5
            goto Lf7
        Lf5:
            if (r13 >= r9) goto Lf8
        Lf7:
            r13 = r9
        Lf8:
            r2 = 1
            if (r15 != 0) goto L11c
            boolean r1 = findBestSizesAndFps$lambda$2(r1)
            if (r1 == 0) goto L11c
            r1 = 2147483647(0x7fffffff, float:NaN)
            if (r14 != r1) goto L107
            goto L109
        L107:
            if (r14 >= r9) goto L10c
        L109:
            r14 = r9
            r17 = r19
        L10c:
            if (r20 == 0) goto L11c
            if (r16 == 0) goto L118
            if (r33 != 0) goto L118
            r1 = r30
            r14 = r9
            r17 = r19
            goto L151
        L118:
            r15 = r2
            r14 = r9
            r17 = r19
        L11c:
            if (r31 == 0) goto L143
            if (r16 != 0) goto L143
            r1 = r30
            java.util.List r3 = r0.getOrderedSupportedStreamUseCaseSurfaceConfigList(r1, r3, r7, r8)
            if (r3 == 0) goto L145
            r3 = 2147483647(0x7fffffff, float:NaN)
            if (r10 != r3) goto L12e
            goto L130
        L12e:
            if (r10 >= r9) goto L133
        L130:
            r10 = r9
            r18 = r19
        L133:
            if (r20 == 0) goto L145
            if (r15 == 0) goto L13d
            if (r33 != 0) goto L13d
            r10 = r9
            r18 = r19
            goto L151
        L13d:
            r16 = r2
            r0 = r9
            r18 = r19
            goto L146
        L143:
            r1 = r30
        L145:
            r0 = r10
        L146:
            r9 = r22
            goto L14
        L14a:
            r1 = r30
            r10 = r0
            r25 = 0
            r0 = r24
        L151:
            if (r17 != 0) goto L154
            return r25
        L154:
            boolean r2 = r1.isFeatureComboInvocation()
            if (r2 == 0) goto L17c
            android.util.Range r2 = r1.getTargetFpsRange()
            android.util.Range<java.lang.Integer> r3 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r3)
            if (r2 != 0) goto L17c
            r2 = 2147483647(0x7fffffff, float:NaN)
            if (r14 == r2) goto L17b
            android.util.Range r1 = r1.getTargetFpsRange()
            java.lang.Comparable r1 = r1.getUpper()
            java.lang.Number r1 = (java.lang.Number) r1
            int r1 = r1.intValue()
            if (r14 >= r1) goto L17c
        L17b:
            return r25
        L17c:
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs r1 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs
            r26 = r1
            r30 = r10
            r31 = r13
            r29 = r14
            r27 = r17
            r28 = r18
            r26.<init>(r27, r28, r29, r30, r31)
            return r1
    }

    private static final boolean findBestSizesAndFps$lambda$1(androidx.camera.camera2.adapter.SupportedSurfaceCombination r0, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r1, java.util.List r2, java.util.Map r3, java.util.List r4, java.util.List r5) {
            boolean r0 = r0.checkSupported(r1, r2, r3, r4, r5)
            return r0
    }

    private static final boolean findBestSizesAndFps$lambda$2(kotlin.Lazy<java.lang.Boolean> r0) {
            java.lang.Object r0 = r0.getValue()
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            return r0
    }

    private final void generate10BitSupportedCombinationList() {
            r2 = this;
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r2.surfaceCombinations10Bit
            java.util.List r1 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.get10BitSupportedCombinationList()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            return
    }

    private final void generateConcurrentSupportedCombinationList() {
            r2 = this;
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r2.concurrentSurfaceCombinations
            java.util.List r1 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.getConcurrentSupportedCombinationList()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            return
    }

    private final void generateHighSpeedSupportedCombinationList() {
            r3 = this;
            androidx.camera.camera2.internal.HighSpeedResolver r0 = r3.highSpeedResolver
            boolean r0 = r0.isHighSpeedSupported()
            if (r0 != 0) goto L9
            goto L27
        L9:
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r3.highSpeedSurfaceCombinations
            r0.clear()
            androidx.camera.camera2.internal.HighSpeedResolver r0 = r3.highSpeedResolver
            android.util.Size r0 = r0.getMaxSize()
            if (r0 == 0) goto L27
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r3.highSpeedSurfaceCombinations
            r2 = 34
            androidx.camera.core.impl.SurfaceSizeDefinition r2 = r3.getUpdatedSurfaceSizeDefinitionByFormat(r2)
            java.util.List r0 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.generateHighSpeedSupportedCombinationList(r0, r2)
            java.util.Collection r0 = (java.util.Collection) r0
            r1.addAll(r0)
        L27:
            return
    }

    private final void generatePreviewStabilizationSupportedCombinationList() {
            r2 = this;
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r2.previewStabilizationSurfaceCombinations
            java.util.List r1 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.getPreviewStabilizationSupportedCombinationList()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            return
    }

    private final void generateStreamUseCaseSupportedCombinationList() {
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 33
            if (r0 < r1) goto L13
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r2.surfaceCombinationsStreamUseCase
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil r1 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.INSTANCE
            java.util.List r1 = r1.getStreamUseCaseSupportedCombinationList()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
        L13:
            return
    }

    private final java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, androidx.camera.core.impl.StreamSpec> generateSuggestedStreamSpecMap(androidx.camera.camera2.adapter.SupportedSurfaceCombination.BestSizesAndMaxFpsForConfigs r7, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r8, java.util.List<java.lang.Integer> r9, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, androidx.camera.core.DynamicRange> r10, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r11) {
            r6 = this;
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            android.util.Range<java.lang.Integer> r1 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            android.util.Range r2 = r11.getTargetFpsRange()
            android.util.Range<java.lang.Integer> r3 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r3)
            if (r2 != 0) goto L9f
            boolean r1 = r11.isHighSpeedOn()
            if (r1 == 0) goto L26
            androidx.camera.camera2.internal.HighSpeedResolver r1 = r6.highSpeedResolver
            java.util.List r2 = r7.getBestSizes()
            android.util.Range[] r1 = r1.getFrameRateRangesFor(r2)
            goto L35
        L26:
            androidx.camera.camera2.pipe.CameraMetadata r1 = r6.cameraMetadata
            android.hardware.camera2.CameraCharacteristics$Key r2 = android.hardware.camera2.CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES
            java.lang.String r3 = "CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
            java.lang.Object r1 = r1.get(r2)
            android.util.Range[] r1 = (android.util.Range[]) r1
        L35:
            android.util.Range r2 = r11.getTargetFpsRange()
            int r3 = r7.getMaxFpsForBestSizes()
            android.util.Range r2 = r6.getClosestSupportedDeviceFrameRate(r2, r3, r1)
            boolean r3 = r11.isFeatureComboInvocation()
            if (r3 != 0) goto L4d
            boolean r3 = r11.isStrictFpsRequired()
            if (r3 == 0) goto L57
        L4d:
            android.util.Range r3 = r11.getTargetFpsRange()
            boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r3)
            if (r3 == 0) goto L59
        L57:
            r1 = r2
            goto Lbd
        L59:
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            java.lang.String r9 = "Target FPS range "
            r8.<init>(r9)
            android.util.Range r9 = r11.getTargetFpsRange()
            r8.append(r9)
            java.lang.String r9 = " is not supported. Max FPS supported by the calculated best combination: "
            r8.append(r9)
            int r7 = r7.getMaxFpsForBestSizes()
            r8.append(r7)
            java.lang.String r7 = ". Calculated best FPS range for device: "
            r8.append(r7)
            r8.append(r2)
            java.lang.String r7 = ". Device supported FPS ranges: "
            r8.append(r7)
            java.lang.String r7 = java.util.Arrays.toString(r1)
            java.lang.String r9 = "toString(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r9)
            r8.append(r7)
            r7 = 46
            r8.append(r7)
            java.lang.String r7 = r8.toString()
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException
            java.lang.String r7 = r7.toString()
            r8.<init>(r7)
            throw r8
        L9f:
            boolean r2 = r11.isHighSpeedOn()
            if (r2 == 0) goto Lbd
            androidx.camera.camera2.internal.HighSpeedResolver r1 = r6.highSpeedResolver
            java.util.List r2 = r7.getBestSizes()
            android.util.Range[] r1 = r1.getFrameRateRangesFor(r2)
            androidx.camera.camera2.internal.HighSpeedResolver$Companion r2 = androidx.camera.camera2.internal.HighSpeedResolver.Companion
            android.util.Range r2 = r2.getDEFAULT_FPS()
            int r3 = r7.getMaxFpsForBestSizes()
            android.util.Range r1 = r6.getClosestSupportedDeviceFrameRate(r2, r3, r1)
        Lbd:
            java.lang.Iterable r8 = (java.lang.Iterable) r8
            java.util.Iterator r8 = r8.iterator()
            r2 = 0
        Lc4:
            boolean r3 = r8.hasNext()
            if (r3 == 0) goto L135
            int r3 = r2 + 1
            java.lang.Object r4 = r8.next()
            androidx.camera.core.impl.UseCaseConfig r4 = (androidx.camera.core.impl.UseCaseConfig) r4
            java.util.List r5 = r7.getBestSizes()
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            int r2 = r9.indexOf(r2)
            java.lang.Object r2 = r5.get(r2)
            android.util.Size r2 = (android.util.Size) r2
            androidx.camera.core.impl.StreamSpec$Builder r2 = androidx.camera.core.impl.StreamSpec.builder(r2)
            boolean r5 = r11.isHighSpeedOn()
            androidx.camera.core.impl.StreamSpec$Builder r2 = r2.setSessionType(r5)
            java.lang.Object r5 = r10.get(r4)
            if (r5 == 0) goto L129
            androidx.camera.core.DynamicRange r5 = (androidx.camera.core.DynamicRange) r5
            androidx.camera.core.impl.StreamSpec$Builder r2 = r2.setDynamicRange(r5)
            androidx.camera.camera2.internal.StreamUseCaseUtil r5 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            androidx.camera.camera2.impl.Camera2ImplConfig r5 = r5.getStreamSpecImplementationOptions(r4)
            androidx.camera.core.impl.Config r5 = (androidx.camera.core.impl.Config) r5
            androidx.camera.core.impl.StreamSpec$Builder r2 = r2.setImplementationOptions(r5)
            boolean r5 = r11.getHasVideoCapture()
            androidx.camera.core.impl.StreamSpec$Builder r2 = r2.setZslDisabled(r5)
            java.lang.String r5 = "setZslDisabled(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r5)
            android.util.Range<java.lang.Integer> r5 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)
            if (r5 != 0) goto L120
            r2.setExpectedFrameRateRange(r1)
        L120:
            androidx.camera.core.impl.StreamSpec r2 = r2.build()
            r0.put(r4, r2)
            r2 = r3
            goto Lc4
        L129:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "Required value was null."
            java.lang.String r8 = r8.toString()
            r7.<init>(r8)
            throw r7
        L135:
            return r0
    }

    private final void generateSupportedCombinationList() {
            r4 = this;
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r4.surfaceCombinations
            int r1 = r4.hardwareLevel
            boolean r2 = r4.isRawSupported
            boolean r3 = r4.isBurstCaptureSupported
            java.util.List r1 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.generateSupportedCombinationList(r1, r2, r3)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r4.surfaceCombinations
            androidx.camera.camera2.compat.workaround.ExtraSupportedSurfaceCombinationsContainer r1 = r4.extraSupportedSurfaceCombinationsContainer
            java.lang.String r2 = r4.cameraId
            java.util.List r1 = r1.get(r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            return
    }

    private final void generateSurfaceSizeDefinition() {
            r10 = this;
            androidx.camera.camera2.impl.DisplayInfoManager r0 = r10.displayInfoManager
            android.util.Size r3 = r0.getPreviewSize()
            android.util.Size r5 = r10.getRecordSize()
            android.util.Size r1 = androidx.camera.core.internal.utils.SizeUtil.RESOLUTION_VGA
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            r2 = r0
            java.util.Map r2 = (java.util.Map) r2
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            r4 = r0
            java.util.Map r4 = (java.util.Map) r4
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            r6 = r0
            java.util.Map r6 = (java.util.Map) r6
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            r7 = r0
            java.util.Map r7 = (java.util.Map) r7
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            r8 = r0
            java.util.Map r8 = (java.util.Map) r8
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            r9 = r0
            java.util.Map r9 = (java.util.Map) r9
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = androidx.camera.core.impl.SurfaceSizeDefinition.create(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            java.lang.String r1 = "create(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r10.setSurfaceSizeDefinition$camera_camera2(r0)
            return
    }

    private final void generateUltraHdrSupportedCombinationList() {
            r2 = this;
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r2.surfaceCombinationsUltraHdr
            java.util.List r1 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.getUltraHdrSupportedCombinationList()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            return
    }

    private final void generateUltraHighResolutionSupportedCombinationList() {
            r2 = this;
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r2.ultraHighSurfaceCombinations
            java.util.List r1 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.getUltraHighResolutionSupportedCombinationList()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            return
    }

    private final java.util.List<java.util.List<android.util.Size>> getAllPossibleSizeArrangements(java.util.List<? extends java.util.List<android.util.Size>> r14) {
            r13 = this;
            java.util.Iterator r0 = r14.iterator()
            r1 = 1
            r2 = r1
        L6:
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L18
            java.lang.Object r3 = r0.next()
            java.util.List r3 = (java.util.List) r3
            int r3 = r3.size()
            int r2 = r2 * r3
            goto L6
        L18:
            if (r2 == 0) goto L81
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            r3 = 0
            r4 = r3
        L23:
            if (r4 >= r2) goto L32
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            java.util.List r5 = (java.util.List) r5
            r0.add(r5)
            int r4 = r4 + 1
            goto L23
        L32:
            java.lang.Object r4 = r14.get(r3)
            java.util.List r4 = (java.util.List) r4
            int r4 = r4.size()
            int r4 = r2 / r4
            r5 = r14
            java.util.Collection r5 = (java.util.Collection) r5
            int r5 = r5.size()
            r7 = r2
            r6 = r3
        L47:
            if (r6 >= r5) goto L80
            java.lang.Object r8 = r14.get(r6)
            java.util.List r8 = (java.util.List) r8
            r9 = r3
        L50:
            if (r9 >= r2) goto L65
            java.lang.Object r10 = r0.get(r9)
            java.util.List r10 = (java.util.List) r10
            int r11 = r9 % r7
            int r11 = r11 / r4
            java.lang.Object r11 = r8.get(r11)
            r10.add(r11)
            int r9 = r9 + 1
            goto L50
        L65:
            int r8 = r14.size()
            int r8 = r8 - r1
            if (r6 >= r8) goto L7d
            int r7 = r6 + 1
            java.lang.Object r7 = r14.get(r7)
            java.util.List r7 = (java.util.List) r7
            int r7 = r7.size()
            int r7 = r4 / r7
            r12 = r7
            r7 = r4
            r4 = r12
        L7d:
            int r6 = r6 + 1
            goto L47
        L80:
            return r0
        L81:
            java.lang.IllegalArgumentException r14 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Failed to find supported resolutions."
            java.lang.String r0 = r0.toString()
            r14.<init>(r0)
            throw r14
    }

    private final boolean getAndValidateIsStrictFpsRequired(boolean r2, java.lang.Boolean r3) {
            r1 = this;
            if (r3 == 0) goto L15
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r2)
            boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r3 == 0) goto Ld
            goto L15
        Ld:
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException
            java.lang.String r3 = "All isStrictFpsRequired should be the same"
            r2.<init>(r3)
            throw r2
        L15:
            return r2
    }

    private final androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod getCheckingMethod(java.util.Collection<androidx.camera.core.DynamicRange> r1, android.util.Range<java.lang.Integer> r2, androidx.camera.core.impl.stabilization.VideoStabilization r3, boolean r4, boolean r5) {
            r0 = this;
            if (r5 != 0) goto L5
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO
            return r1
        L5:
            androidx.camera.core.DynamicRange r5 = androidx.camera.core.DynamicRange.HLG_10_BIT
            boolean r1 = r1.contains(r5)
            if (r2 == 0) goto L20
            java.lang.Comparable r2 = r2.getUpper()
            java.lang.Integer r2 = (java.lang.Integer) r2
            if (r2 != 0) goto L16
            goto L20
        L16:
            int r2 = r2.intValue()
            r5 = 60
            if (r2 != r5) goto L20
            int r1 = r1 + 1
        L20:
            androidx.camera.core.impl.stabilization.VideoStabilization r2 = androidx.camera.core.impl.stabilization.VideoStabilization.ON
            if (r3 == r2) goto L28
            androidx.camera.core.impl.stabilization.VideoStabilization r2 = androidx.camera.core.impl.stabilization.VideoStabilization.PREVIEW
            if (r3 != r2) goto L2a
        L28:
            int r1 = r1 + 1
        L2a:
            if (r4 == 0) goto L2e
            int r1 = r1 + 1
        L2e:
            r2 = 1
            if (r1 <= r2) goto L34
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITH_FEATURE_COMBO
            return r1
        L34:
            if (r1 != r2) goto L39
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO_FIRST_AND_THEN_WITH_IT
            return r1
        L39:
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod.WITHOUT_FEATURE_COMBO
            return r1
    }

    private final android.util.Range<java.lang.Integer> getClosestSupportedDeviceFrameRate(android.util.Range<java.lang.Integer> r8, int r9, android.util.Range<java.lang.Integer>[] r10) {
            r7 = this;
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r8, r0)
            java.lang.String r1 = "FRAME_RATE_RANGE_UNSPECIFIED"
            if (r0 == 0) goto L10
            android.util.Range<java.lang.Integer> r8 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r1)
            return r8
        L10:
            if (r10 != 0) goto L18
            android.util.Range<java.lang.Integer> r8 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r1)
            return r8
        L18:
            android.util.Range r0 = new android.util.Range
            java.lang.Comparable r1 = r8.getLower()
            java.lang.String r2 = "getLower(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Number r1 = (java.lang.Number) r1
            int r1 = r1.intValue()
            int r1 = java.lang.Math.min(r1, r9)
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            java.lang.Comparable r8 = r8.getUpper()
            java.lang.String r2 = "getUpper(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r2)
            java.lang.Number r8 = (java.lang.Number) r8
            int r8 = r8.intValue()
            int r8 = java.lang.Math.min(r8, r9)
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)
            java.lang.Comparable r8 = (java.lang.Comparable) r8
            r0.<init>(r1, r8)
            android.util.Range<java.lang.Integer> r8 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            int r1 = r10.length
            r2 = 0
            r3 = r2
        L54:
            if (r2 >= r1) goto Le6
            r4 = r10[r2]
            java.lang.Comparable r5 = r4.getLower()
            java.lang.Number r5 = (java.lang.Number) r5
            int r5 = r5.intValue()
            if (r9 >= r5) goto L66
            goto Le2
        L66:
            android.util.Range<java.lang.Integer> r5 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r8, r5)
            if (r5 == 0) goto L6f
            r8 = r4
        L6f:
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r4, r0)
            if (r5 == 0) goto L78
            r8 = r4
            goto Le6
        L78:
            android.util.Range r5 = r4.intersect(r0)     // Catch: java.lang.IllegalArgumentException -> L9f
            kotlin.jvm.internal.Intrinsics.checkNotNull(r5)     // Catch: java.lang.IllegalArgumentException -> L9f
            int r5 = r7.getRangeLength(r5)     // Catch: java.lang.IllegalArgumentException -> L9f
            if (r3 != 0) goto L88
            r8 = r4
            r3 = r5
            goto Le2
        L88:
            if (r5 < r3) goto Le2
            kotlin.jvm.internal.Intrinsics.checkNotNull(r8)     // Catch: java.lang.IllegalArgumentException -> L9f
            android.util.Range r8 = r7.compareIntersectingRanges(r0, r8, r4)     // Catch: java.lang.IllegalArgumentException -> L9f
            android.util.Range r5 = r0.intersect(r8)     // Catch: java.lang.IllegalArgumentException -> L9f
            java.lang.String r6 = "intersect(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)     // Catch: java.lang.IllegalArgumentException -> L9f
            int r3 = r7.getRangeLength(r5)     // Catch: java.lang.IllegalArgumentException -> L9f
            goto Le2
        L9f:
            if (r3 == 0) goto La2
            goto Le2
        La2:
            int r5 = r7.getRangeDistance(r4, r0)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r8)
            int r6 = r7.getRangeDistance(r8, r0)
            if (r5 >= r6) goto Lb0
            goto Le1
        Lb0:
            int r5 = r7.getRangeDistance(r4, r0)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r8)
            int r6 = r7.getRangeDistance(r8, r0)
            if (r5 != r6) goto Le2
            java.lang.Comparable r5 = r4.getLower()
            java.lang.Number r5 = (java.lang.Number) r5
            int r5 = r5.intValue()
            java.lang.Comparable r6 = r8.getUpper()
            java.lang.Number r6 = (java.lang.Number) r6
            int r6 = r6.intValue()
            if (r5 <= r6) goto Ld4
            goto Le1
        Ld4:
            int r5 = r7.getRangeLength(r4)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r8)
            int r6 = r7.getRangeLength(r8)
            if (r5 >= r6) goto Le2
        Le1:
            r8 = r4
        Le2:
            int r2 = r2 + 1
            goto L54
        Le6:
            kotlin.jvm.internal.Intrinsics.checkNotNull(r8)
            return r8
    }

    private final int getCombinedMaximumFps(int r1, int r2, android.util.Size r3, boolean r4, int r5) {
            r0 = this;
            int r2 = r0.getMaxFrameRate(r2, r3, r4, r5)
            int r1 = java.lang.Math.min(r1, r2)
            return r1
    }

    private final int getCurrentConfigFrameRateCeiling(java.util.List<android.util.Size> r8, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r9, java.util.List<java.lang.Integer> r10, int r11, boolean r12) {
            r7 = this;
            java.lang.Iterable r8 = (java.lang.Iterable) r8
            java.util.Iterator r8 = r8.iterator()
            r0 = 0
            r2 = r11
        L8:
            boolean r11 = r8.hasNext()
            if (r11 == 0) goto L37
            int r11 = r0 + 1
            java.lang.Object r1 = r8.next()
            r4 = r1
            android.util.Size r4 = (android.util.Size) r4
            java.lang.Object r0 = r10.get(r0)
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            java.lang.Object r0 = r9.get(r0)
            androidx.camera.core.impl.UseCaseConfig r0 = (androidx.camera.core.impl.UseCaseConfig) r0
            int r3 = r0.getInputFormat()
            int r6 = r0.getCustomMaxFrameRate(r4)
            r1 = r7
            r5 = r12
            int r2 = r1.getCombinedMaximumFps(r2, r3, r4, r5, r6)
            r0 = r11
            goto L8
        L37:
            return r2
    }

    private final int getMaxFrameRate(int r6, android.util.Size r7) {
            r5 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r5.getStreamConfigurationMapCompat()
            long r0 = r0.getOutputMinFrameDuration(r6, r7)
            r2 = 0
            int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r2 > 0) goto L47
            boolean r2 = r5.isManualSensorSupported
            if (r2 == 0) goto L43
            androidx.camera.camera2.impl.Camera2Logger r2 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r2 = "CXCP"
            boolean r2 = androidx.camera.core.Logger.isWarnEnabled(r2)
            if (r2 == 0) goto L41
            java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "minFrameDuration: "
            r3.<init>(r4)
            r3.append(r0)
            java.lang.String r0 = " is invalid for imageFormat = "
            r3.append(r0)
            r3.append(r6)
            java.lang.String r6 = ", size = "
            r3.append(r6)
            r3.append(r7)
            java.lang.String r6 = r3.toString()
            android.util.Log.w(r2, r6)
        L41:
            r6 = 0
            return r6
        L43:
            r6 = 2147483647(0x7fffffff, float:NaN)
            return r6
        L47:
            r6 = 4741671816366391296(0x41cdcd6500000000, double:1.0E9)
            double r0 = (double) r0
            double r6 = r6 / r0
            int r6 = (int) r6
            return r6
    }

    private final int getMaxFrameRate(int r1, android.util.Size r2, boolean r3, int r4) {
            r0 = this;
            if (r3 == 0) goto L15
            r3 = 34
            if (r1 != r3) goto Ld
            androidx.camera.camera2.internal.HighSpeedResolver r1 = r0.highSpeedResolver
            int r1 = r1.getMaxFrameRate(r2)
            goto L19
        Ld:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "Check failed."
            r1.<init>(r2)
            throw r1
        L15:
            int r1 = r0.getMaxFrameRate(r1, r2)
        L19:
            int r1 = java.lang.Math.min(r4, r1)
            return r1
    }

    public static /* synthetic */ android.util.Size getMaxOutputSizeByFormat$camera_camera2$default(androidx.camera.camera2.adapter.SupportedSurfaceCombination r0, android.hardware.camera2.params.StreamConfigurationMap r1, int r2, boolean r3, android.util.Rational r4, int r5, java.lang.Object r6) {
            r5 = r5 & 8
            if (r5 == 0) goto L5
            r4 = 0
        L5:
            android.util.Size r0 = r0.getMaxOutputSizeByFormat$camera_camera2(r1, r2, r3, r4)
            return r0
    }

    private final int getMaxSupportedFpsFromAttachedSurfaces(java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r8, boolean r9) {
            r7 = this;
            java.util.Iterator r8 = r8.iterator()
            r0 = 2147483647(0x7fffffff, float:NaN)
            r2 = r0
        L8:
            boolean r0 = r8.hasNext()
            if (r0 == 0) goto L2c
            java.lang.Object r0 = r8.next()
            androidx.camera.core.impl.AttachedSurfaceInfo r0 = (androidx.camera.core.impl.AttachedSurfaceInfo) r0
            int r3 = r0.getImageFormat()
            android.util.Size r4 = r0.getSize()
            java.lang.String r1 = "getSize(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r1)
            int r6 = r0.getCustomMaxFrameRate()
            r1 = r7
            r5 = r9
            int r2 = r1.getCombinedMaximumFps(r2, r3, r4, r5, r6)
            goto L8
        L2c:
            return r2
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceConfig> getOrderedSupportedStreamUseCaseSurfaceConfigList(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r5, java.util.List<androidx.camera.core.impl.SurfaceConfig> r6, java.util.Map<java.lang.Integer, androidx.camera.core.impl.AttachedSurfaceInfo> r7, java.util.Map<java.lang.Integer, androidx.camera.core.impl.UseCaseConfig<?>> r8) {
            r4 = this;
            androidx.camera.camera2.internal.StreamUseCaseUtil r0 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            boolean r5 = r0.shouldUseStreamUseCase(r5)
            r0 = 0
            if (r5 != 0) goto La
            return r0
        La:
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r5 = r4.surfaceCombinationsStreamUseCase
            java.util.Iterator r5 = r5.iterator()
        L10:
            boolean r1 = r5.hasNext()
            if (r1 == 0) goto L43
            java.lang.Object r1 = r5.next()
            androidx.camera.core.impl.SurfaceCombination r1 = (androidx.camera.core.impl.SurfaceCombination) r1
            kotlin.jvm.internal.Intrinsics.checkNotNull(r6)
            java.util.List r1 = r1.getOrderedSupportedSurfaceConfigList(r6)
            if (r1 == 0) goto L10
            androidx.camera.camera2.internal.StreamUseCaseUtil r2 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            boolean r2 = r2.areCaptureTypesEligible(r7, r8, r1)
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$$ExternalSyntheticLambda1 r3 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination$$ExternalSyntheticLambda1
            r3.<init>(r4, r1)
            kotlin.Lazy r3 = kotlin.LazyKt.lazy(r3)
            if (r2 == 0) goto L10
            java.lang.Object r2 = r3.getValue()
            java.lang.Boolean r2 = (java.lang.Boolean) r2
            boolean r2 = r2.booleanValue()
            if (r2 == 0) goto L10
            return r1
        L43:
            return r0
    }

    private static final boolean getOrderedSupportedStreamUseCaseSurfaceConfigList$lambda$0(androidx.camera.camera2.adapter.SupportedSurfaceCombination r1, java.util.List r2) {
            androidx.camera.camera2.internal.StreamUseCaseUtil r0 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.cameraMetadata
            boolean r1 = r0.areStreamUseCasesAvailableForSurfaceConfigs(r1, r2)
            return r1
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceConfig> getOrderedSurfaceConfigListForStreamUseCase(java.util.List<? extends java.util.List<android.util.Size>> r11, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r12, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r13, java.util.List<java.lang.Integer> r14, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r15, java.util.Map<java.lang.Integer, androidx.camera.core.impl.AttachedSurfaceInfo> r16, java.util.Map<java.lang.Integer, androidx.camera.core.impl.UseCaseConfig<?>> r17) {
            r10 = this;
            java.util.Iterator r11 = r11.iterator()
            r0 = 0
        L5:
            boolean r1 = r11.hasNext()
            if (r1 == 0) goto L31
            java.lang.Object r0 = r11.next()
            r4 = r0
            java.util.List r4 = (java.util.List) r4
            int r2 = r15.getCameraMode()
            r9 = 0
            r1 = r10
            r3 = r12
            r5 = r13
            r6 = r14
            r7 = r16
            r8 = r17
            java.util.List r0 = r1.getSurfaceConfigList(r2, r3, r4, r5, r6, r7, r8, r9)
            java.util.List r0 = r10.getOrderedSupportedStreamUseCaseSurfaceConfigList(r15, r0, r7, r8)
            if (r0 == 0) goto L2a
            return r0
        L2a:
            r7.clear()
            r8.clear()
            goto L5
        L31:
            return r0
    }

    private final android.util.Size[] getOutputSizes(android.hardware.camera2.params.StreamConfigurationMap r6, int r7, android.util.Rational r8) {
            r5 = this;
            r0 = 0
            kotlin.Result$Companion r1 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> L20
            r1 = r5
            androidx.camera.camera2.adapter.SupportedSurfaceCombination r1 = (androidx.camera.camera2.adapter.SupportedSurfaceCombination) r1     // Catch: java.lang.Throwable -> L20
            r1 = 34
            if (r7 != r1) goto L13
            if (r6 == 0) goto L1a
            java.lang.Class<android.graphics.SurfaceTexture> r7 = android.graphics.SurfaceTexture.class
            android.util.Size[] r6 = r6.getOutputSizes(r7)     // Catch: java.lang.Throwable -> L20
            goto L1b
        L13:
            if (r6 == 0) goto L1a
            android.util.Size[] r6 = r6.getOutputSizes(r7)     // Catch: java.lang.Throwable -> L20
            goto L1b
        L1a:
            r6 = r0
        L1b:
            java.lang.Object r6 = kotlin.Result.m2181constructorimpl(r6)     // Catch: java.lang.Throwable -> L20
            goto L2b
        L20:
            r6 = move-exception
            kotlin.Result$Companion r7 = kotlin.Result.Companion
            java.lang.Object r6 = kotlin.ResultKt.createFailure(r6)
            java.lang.Object r6 = kotlin.Result.m2181constructorimpl(r6)
        L2b:
            boolean r7 = kotlin.Result.m2187isFailureimpl(r6)
            if (r7 == 0) goto L32
            r6 = r0
        L32:
            android.util.Size[] r6 = (android.util.Size[]) r6
            if (r6 == 0) goto L5f
            if (r8 == 0) goto L5e
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            java.util.Collection r7 = (java.util.Collection) r7
            int r0 = r6.length
            r1 = 0
            r2 = r1
        L42:
            if (r2 >= r0) goto L52
            r3 = r6[r2]
            boolean r4 = androidx.camera.core.impl.utils.AspectRatioUtil.hasMatchingAspectRatio(r3, r8)
            if (r4 == 0) goto L4f
            r7.add(r3)
        L4f:
            int r2 = r2 + 1
            goto L42
        L52:
            java.util.List r7 = (java.util.List) r7
            java.util.Collection r7 = (java.util.Collection) r7
            android.util.Size[] r6 = new android.util.Size[r1]
            java.lang.Object[] r6 = r7.toArray(r6)
            android.util.Size[] r6 = (android.util.Size[]) r6
        L5e:
            r0 = r6
        L5f:
            return r0
    }

    static /* synthetic */ android.util.Size[] getOutputSizes$default(androidx.camera.camera2.adapter.SupportedSurfaceCombination r0, android.hardware.camera2.params.StreamConfigurationMap r1, int r2, android.util.Rational r3, int r4, java.lang.Object r5) {
            r4 = r4 & 4
            if (r4 == 0) goto L5
            r3 = 0
        L5:
            android.util.Size[] r0 = r0.getOutputSizes(r1, r2, r3)
            return r0
    }

    private final int getRangeDistance(android.util.Range<java.lang.Integer> r4, android.util.Range<java.lang.Integer> r5) {
            r3 = this;
            java.lang.Comparable r0 = r5.getUpper()
            boolean r0 = r4.contains(r0)
            if (r0 != 0) goto L5e
            java.lang.Comparable r0 = r5.getLower()
            boolean r0 = r4.contains(r0)
            if (r0 != 0) goto L5e
            java.lang.Comparable r0 = r4.getLower()
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            java.lang.Comparable r1 = r5.getUpper()
            java.lang.Number r1 = (java.lang.Number) r1
            int r1 = r1.intValue()
            java.lang.String r2 = "getUpper(...)"
            if (r0 <= r1) goto L45
            java.lang.Comparable r4 = r4.getLower()
            java.lang.Number r4 = (java.lang.Number) r4
            int r4 = r4.intValue()
            java.lang.Comparable r5 = r5.getUpper()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r2)
            java.lang.Number r5 = (java.lang.Number) r5
            int r5 = r5.intValue()
            int r4 = r4 - r5
            return r4
        L45:
            java.lang.Comparable r5 = r5.getLower()
            java.lang.Number r5 = (java.lang.Number) r5
            int r5 = r5.intValue()
            java.lang.Comparable r4 = r4.getUpper()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r2)
            java.lang.Number r4 = (java.lang.Number) r4
            int r4 = r4.intValue()
            int r5 = r5 - r4
            return r5
        L5e:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r5 = "Ranges must not intersect"
            java.lang.String r5 = r5.toString()
            r4.<init>(r5)
            throw r4
    }

    private final int getRangeLength(android.util.Range<java.lang.Integer> r3) {
            r2 = this;
            java.lang.Comparable r0 = r3.getUpper()
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            java.lang.Comparable r3 = r3.getLower()
            java.lang.String r1 = "getLower(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r1)
            java.lang.Number r3 = (java.lang.Number) r3
            int r3 = r3.intValue()
            int r0 = r0 - r3
            int r0 = r0 + 1
            return r0
    }

    private final android.util.Size getRecordSize() {
            r2 = this;
            java.lang.String r0 = r2.cameraId     // Catch: java.lang.NumberFormatException -> Lc
            java.lang.Integer.parseInt(r0)     // Catch: java.lang.NumberFormatException -> Lc
            android.util.Size r0 = r2.getRecordSizeFromCamcorderProfile()     // Catch: java.lang.NumberFormatException -> Lc
            if (r0 == 0) goto Lc
            return r0
        Lc:
            android.util.Size r0 = r2.getRecordSizeFromStreamConfigurationMapCompat()
            if (r0 == 0) goto L13
            return r0
        L13:
            android.util.Size r0 = androidx.camera.core.internal.utils.SizeUtil.RESOLUTION_480P
            java.lang.String r1 = "RESOLUTION_480P"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            return r0
    }

    private final android.util.Size getRecordSizeFromCamcorderProfile() {
            r9 = this;
            r0 = 1
            java.lang.Integer r1 = java.lang.Integer.valueOf(r0)
            r0 = 13
            java.lang.Integer r2 = java.lang.Integer.valueOf(r0)
            r0 = 10
            java.lang.Integer r3 = java.lang.Integer.valueOf(r0)
            r0 = 8
            java.lang.Integer r4 = java.lang.Integer.valueOf(r0)
            r0 = 12
            java.lang.Integer r5 = java.lang.Integer.valueOf(r0)
            r0 = 6
            java.lang.Integer r6 = java.lang.Integer.valueOf(r0)
            r0 = 5
            java.lang.Integer r7 = java.lang.Integer.valueOf(r0)
            r0 = 4
            java.lang.Integer r8 = java.lang.Integer.valueOf(r0)
            java.lang.Integer[] r0 = new java.lang.Integer[]{r1, r2, r3, r4, r5, r6, r7, r8}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            java.util.Iterator r0 = r0.iterator()
        L38:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L7c
            java.lang.Object r1 = r0.next()
            java.lang.Number r1 = (java.lang.Number) r1
            int r1 = r1.intValue()
            androidx.camera.core.impl.EncoderProfilesProvider r2 = r9.encoderProfilesProvider
            boolean r2 = r2.hasProfile(r1)
            if (r2 == 0) goto L38
            androidx.camera.core.impl.EncoderProfilesProvider r2 = r9.encoderProfilesProvider
            androidx.camera.core.impl.EncoderProfilesProxy r1 = r2.getAll(r1)
            if (r1 == 0) goto L38
            java.util.List r2 = r1.getVideoProfiles()
            java.lang.String r3 = "getVideoProfiles(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
            java.util.Collection r2 = (java.util.Collection) r2
            boolean r2 = r2.isEmpty()
            if (r2 != 0) goto L38
            java.util.List r0 = r1.getVideoProfiles()
            r1 = 0
            java.lang.Object r0 = r0.get(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            androidx.camera.core.impl.EncoderProfilesProxy$VideoProfileProxy r0 = (androidx.camera.core.impl.EncoderProfilesProxy.VideoProfileProxy) r0
            android.util.Size r0 = r0.getResolution()
            return r0
        L7c:
            r0 = 0
            return r0
    }

    private final android.util.Size getRecordSizeFromStreamConfigurationMapCompat() {
            r7 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r7.streamConfigurationMapCompat
            android.hardware.camera2.params.StreamConfigurationMap r0 = r0.toStreamConfigurationMap()
            r1 = 0
            kotlin.Result$Companion r2 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> L1b
            r2 = r7
            androidx.camera.camera2.adapter.SupportedSurfaceCombination r2 = (androidx.camera.camera2.adapter.SupportedSurfaceCombination) r2     // Catch: java.lang.Throwable -> L1b
            if (r0 == 0) goto L15
            java.lang.Class<android.media.MediaRecorder> r2 = android.media.MediaRecorder.class
            android.util.Size[] r0 = r0.getOutputSizes(r2)     // Catch: java.lang.Throwable -> L1b
            goto L16
        L15:
            r0 = r1
        L16:
            java.lang.Object r0 = kotlin.Result.m2181constructorimpl(r0)     // Catch: java.lang.Throwable -> L1b
            goto L26
        L1b:
            r0 = move-exception
            kotlin.Result$Companion r2 = kotlin.Result.Companion
            java.lang.Object r0 = kotlin.ResultKt.createFailure(r0)
            java.lang.Object r0 = kotlin.Result.m2181constructorimpl(r0)
        L26:
            boolean r2 = kotlin.Result.m2187isFailureimpl(r0)
            if (r2 == 0) goto L2d
            r0 = r1
        L2d:
            android.util.Size[] r0 = (android.util.Size[]) r0
            if (r0 != 0) goto L32
            return r1
        L32:
            androidx.camera.core.impl.utils.CompareSizesByArea r2 = new androidx.camera.core.impl.utils.CompareSizesByArea
            r3 = 1
            r2.<init>(r3)
            java.util.Comparator r2 = (java.util.Comparator) r2
            java.util.Arrays.sort(r0, r2)
            int r2 = r0.length
            r3 = 0
        L3f:
            if (r3 >= r2) goto L5f
            r4 = r0[r3]
            int r5 = r4.getWidth()
            android.util.Size r6 = androidx.camera.core.internal.utils.SizeUtil.RESOLUTION_1080P
            int r6 = r6.getWidth()
            if (r5 > r6) goto L5c
            int r5 = r4.getHeight()
            android.util.Size r6 = androidx.camera.core.internal.utils.SizeUtil.RESOLUTION_1080P
            int r6 = r6.getHeight()
            if (r5 > r6) goto L5c
            return r4
        L5c:
            int r3 = r3 + 1
            goto L3f
        L5f:
            return r1
    }

    private final int getRequiredMaxBitDepth(java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, androidx.camera.core.DynamicRange> r3) {
            r2 = this;
            java.util.Collection r3 = r3.values()
            java.util.Iterator r3 = r3.iterator()
        L8:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L1d
            java.lang.Object r0 = r3.next()
            androidx.camera.core.DynamicRange r0 = (androidx.camera.core.DynamicRange) r0
            int r0 = r0.getBitDepth()
            r1 = 10
            if (r0 != r1) goto L8
            return r1
        L1d:
            r3 = 8
            return r3
    }

    private final androidx.camera.camera2.compat.StreamConfigurationMapCompat getStreamConfigurationMapCompat() {
            r4 = this;
            androidx.camera.camera2.pipe.CameraMetadata r0 = r4.cameraMetadata
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP
            java.lang.String r2 = "SCALER_STREAM_CONFIGURATION_MAP"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            android.hardware.camera2.params.StreamConfigurationMap r0 = (android.hardware.camera2.params.StreamConfigurationMap) r0
            if (r0 == 0) goto L1e
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r1 = new androidx.camera.camera2.compat.StreamConfigurationMapCompat
            androidx.camera.camera2.compat.workaround.OutputSizesCorrector r2 = new androidx.camera.camera2.compat.workaround.OutputSizesCorrector
            androidx.camera.camera2.pipe.CameraMetadata r3 = r4.cameraMetadata
            r2.<init>(r3, r0)
            r1.<init>(r0, r2)
            return r1
        L1e:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Cannot retrieve SCALER_STREAM_CONFIGURATION_MAP"
            r0.<init>(r1)
            throw r0
    }

    public static /* synthetic */ androidx.camera.core.impl.SurfaceStreamSpecQueryResult getSuggestedStreamSpecifications$default(androidx.camera.camera2.adapter.SupportedSurfaceCombination r8, int r9, java.util.List r10, java.util.Map r11, androidx.camera.core.impl.stabilization.VideoStabilization r12, boolean r13, boolean r14, boolean r15, int r16, java.lang.Object r17) {
            r0 = r16 & 8
            if (r0 == 0) goto L6
            androidx.camera.core.impl.stabilization.VideoStabilization r12 = androidx.camera.core.impl.stabilization.VideoStabilization.UNSPECIFIED
        L6:
            r4 = r12
            r12 = r16 & 16
            if (r12 == 0) goto Lc
            r13 = 0
        Lc:
            r0 = r8
            r1 = r9
            r2 = r10
            r3 = r11
            r5 = r13
            r6 = r14
            r7 = r15
            androidx.camera.core.impl.SurfaceStreamSpecQueryResult r8 = r0.getSuggestedStreamSpecifications(r1, r2, r3, r4, r5, r6, r7)
            return r8
    }

    private final java.util.List<java.util.List<android.util.Size>> getSupportedOutputSizesList(java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, ? extends java.util.List<android.util.Size>> r4, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r5, java.util.List<java.lang.Integer> r6) {
            r3 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            java.util.Iterator r6 = r6.iterator()
        Lb:
            boolean r1 = r6.hasNext()
            if (r1 == 0) goto L3a
            java.lang.Object r1 = r6.next()
            java.lang.Number r1 = (java.lang.Number) r1
            int r1 = r1.intValue()
            java.lang.Object r2 = r5.get(r1)
            java.lang.Object r2 = r4.get(r2)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2)
            java.util.List r2 = (java.util.List) r2
            java.lang.Object r1 = r5.get(r1)
            androidx.camera.core.impl.UseCaseConfig r1 = (androidx.camera.core.impl.UseCaseConfig) r1
            int r1 = r1.getInputFormat()
            java.util.List r1 = r3.applyResolutionSelectionOrderRelatedWorkarounds(r2, r1)
            r0.add(r1)
            goto Lb
        L3a:
            return r0
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> getSurfaceCombinationsByFeatureSettings(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r5) {
            r4 = this;
            java.util.Map<androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings, java.util.List<androidx.camera.core.impl.SurfaceCombination>> r0 = r4.featureSettingsToSupportedCombinationsMap
            boolean r0 = r0.containsKey(r5)
            if (r0 == 0) goto L14
            java.util.Map<androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings, java.util.List<androidx.camera.core.impl.SurfaceCombination>> r0 = r4.featureSettingsToSupportedCombinationsMap
            java.lang.Object r5 = r0.get(r5)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r5)
            java.util.List r5 = (java.util.List) r5
            return r5
        L14:
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            boolean r1 = r5.getRequiresFeatureComboQuery()
            if (r1 == 0) goto L34
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil r1 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.INSTANCE
            androidx.camera.camera2.pipe.CameraMetadata r2 = r4.cameraMetadata
            androidx.camera.core.impl.stabilization.VideoStabilization r3 = r5.getVideoStabilization()
            java.util.List r1 = r1.getQueryableFcqCombinations$camera_camera2(r2, r3)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            goto Lb8
        L34:
            boolean r1 = r5.isUltraHdrOn()
            if (r1 == 0) goto L53
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.surfaceCombinationsUltraHdr
            boolean r1 = r1.isEmpty()
            if (r1 == 0) goto L45
            r4.generateUltraHdrSupportedCombinationList()
        L45:
            int r1 = r5.getCameraMode()
            if (r1 != 0) goto Lb8
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.surfaceCombinationsUltraHdr
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            goto Lb8
        L53:
            boolean r1 = r5.isHighSpeedOn()
            if (r1 == 0) goto L6c
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.highSpeedSurfaceCombinations
            boolean r1 = r1.isEmpty()
            if (r1 == 0) goto L64
            r4.generateHighSpeedSupportedCombinationList()
        L64:
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.highSpeedSurfaceCombinations
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            goto Lb8
        L6c:
            int r1 = r5.getRequiredMaxBitDepth()
            r2 = 8
            if (r1 != r2) goto La3
            int r1 = r5.getCameraMode()
            r2 = 1
            if (r1 == r2) goto La0
            r2 = 2
            if (r1 == r2) goto L91
            androidx.camera.core.impl.stabilization.VideoStabilization r1 = r5.getVideoStabilization()
            androidx.camera.core.impl.stabilization.VideoStabilization r2 = androidx.camera.core.impl.stabilization.VideoStabilization.PREVIEW
            if (r1 != r2) goto L89
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.previewStabilizationSurfaceCombinations
            goto L8b
        L89:
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.surfaceCombinations
        L8b:
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            goto Lb8
        L91:
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.ultraHighSurfaceCombinations
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.surfaceCombinations
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            goto Lb8
        La0:
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r0 = r4.concurrentSurfaceCombinations
            goto Lb8
        La3:
            int r1 = r5.getRequiredMaxBitDepth()
            r2 = 10
            if (r1 != r2) goto Lb8
            int r1 = r5.getCameraMode()
            if (r1 != 0) goto Lb8
            java.util.List<androidx.camera.core.impl.SurfaceCombination> r1 = r4.surfaceCombinations10Bit
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
        Lb8:
            java.util.Map<androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings, java.util.List<androidx.camera.core.impl.SurfaceCombination>> r1 = r4.featureSettingsToSupportedCombinationsMap
            r1.put(r5, r0)
            return r0
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceConfig> getSurfaceConfigList(int r15, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r16, java.util.List<android.util.Size> r17, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r18, java.util.List<java.lang.Integer> r19, java.util.Map<java.lang.Integer, androidx.camera.core.impl.AttachedSurfaceInfo> r20, java.util.Map<java.lang.Integer, androidx.camera.core.impl.UseCaseConfig<?>> r21, boolean r22) {
            r14 = this;
            r0 = r20
            r1 = r21
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.List r2 = (java.util.List) r2
            java.util.Iterator r3 = r16.iterator()
        Lf:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L37
            java.lang.Object r4 = r3.next()
            androidx.camera.core.impl.AttachedSurfaceInfo r4 = (androidx.camera.core.impl.AttachedSurfaceInfo) r4
            androidx.camera.core.impl.SurfaceConfig r5 = r4.getSurfaceConfig()
            java.lang.String r6 = "getSurfaceConfig(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)
            r2.add(r5)
            if (r0 == 0) goto Lf
            int r5 = r2.size()
            int r5 = r5 + (-1)
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            r0.put(r5, r4)
            goto Lf
        L37:
            r0 = r17
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.Iterator r0 = r0.iterator()
            r3 = 0
        L40:
            boolean r4 = r0.hasNext()
            if (r4 == 0) goto L97
            int r4 = r3 + 1
            java.lang.Object r5 = r0.next()
            r8 = r5
            android.util.Size r8 = (android.util.Size) r8
            r5 = r19
            java.lang.Object r3 = r5.get(r3)
            java.lang.Number r3 = (java.lang.Number) r3
            int r3 = r3.intValue()
            r13 = r18
            java.lang.Object r3 = r13.get(r3)
            androidx.camera.core.impl.UseCaseConfig r3 = (androidx.camera.core.impl.UseCaseConfig) r3
            int r7 = r3.getInputFormat()
            androidx.camera.core.impl.StreamUseCase r12 = r3.getStreamUseCase()
            java.lang.String r6 = "getStreamUseCase(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r12, r6)
            androidx.camera.core.impl.SurfaceConfig$Companion r6 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceSizeDefinition r9 = r14.getUpdatedSurfaceSizeDefinitionByFormat(r7)
            if (r22 == 0) goto L7b
            androidx.camera.core.impl.SurfaceConfig$ConfigSource r10 = androidx.camera.core.impl.SurfaceConfig.ConfigSource.FEATURE_COMBINATION_TABLE
            goto L7d
        L7b:
            androidx.camera.core.impl.SurfaceConfig$ConfigSource r10 = androidx.camera.core.impl.SurfaceConfig.ConfigSource.CAPTURE_SESSION_TABLES
        L7d:
            r11 = r10
            r10 = r15
            androidx.camera.core.impl.SurfaceConfig r6 = r6.transformSurfaceConfig(r7, r8, r9, r10, r11, r12)
            r2.add(r6)
            if (r1 == 0) goto L95
            int r6 = r2.size()
            int r6 = r6 + (-1)
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r1.put(r6, r3)
        L95:
            r3 = r4
            goto L40
        L97:
            return r2
    }

    private final android.util.Range<java.lang.Integer> getTargetFpsRange(java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r4, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r5, java.util.List<java.lang.Integer> r6, boolean r7) {
            r3 = this;
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            java.lang.String r1 = "FRAME_RATE_RANGE_UNSPECIFIED"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.util.Iterator r4 = r4.iterator()
        Lb:
            boolean r1 = r4.hasNext()
            if (r1 == 0) goto L25
            java.lang.Object r1 = r4.next()
            androidx.camera.core.impl.AttachedSurfaceInfo r1 = (androidx.camera.core.impl.AttachedSurfaceInfo) r1
            android.util.Range r1 = r1.getTargetFrameRate()
            java.lang.String r2 = "getTargetFrameRate(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            android.util.Range r0 = r3.getUpdatedTargetFrameRate(r1, r0, r7)
            goto Lb
        L25:
            java.util.Iterator r4 = r6.iterator()
        L29:
            boolean r6 = r4.hasNext()
            if (r6 == 0) goto L4d
            java.lang.Object r6 = r4.next()
            java.lang.Number r6 = (java.lang.Number) r6
            int r6 = r6.intValue()
            java.lang.Object r6 = r5.get(r6)
            androidx.camera.core.impl.UseCaseConfig r6 = (androidx.camera.core.impl.UseCaseConfig) r6
            android.util.Range<java.lang.Integer> r1 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            android.util.Range r6 = r6.getTargetFrameRate(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r6)
            android.util.Range r0 = r3.getUpdatedTargetFrameRate(r6, r0, r7)
            goto L29
        L4d:
            return r0
    }

    private final android.util.Range<java.lang.Integer> getUpdatedTargetFrameRate(android.util.Range<java.lang.Integer> r2, android.util.Range<java.lang.Integer> r3, boolean r4) {
            r1 = this;
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r0 == 0) goto L18
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r0)
            if (r0 == 0) goto L18
            android.util.Range<java.lang.Integer> r2 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            java.lang.String r3 = "FRAME_RATE_RANGE_UNSPECIFIED"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
            return r2
        L18:
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r0 == 0) goto L21
            return r2
        L21:
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r0)
            if (r0 == 0) goto L2a
            goto L3e
        L2a:
            if (r4 == 0) goto L36
            boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r3)
            java.lang.String r4 = "All targetFrameRate should be the same if strict fps is required"
            androidx.core.util.Preconditions.checkState(r3, r4)
            return r2
        L36:
            android.util.Range r2 = r3.intersect(r2)     // Catch: java.lang.IllegalArgumentException -> L3e
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2)     // Catch: java.lang.IllegalArgumentException -> L3e
            return r2
        L3e:
            return r3
    }

    private final java.util.List<java.lang.Integer> getUseCasesPriorityOrder(java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r8) {
            r7 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.List r1 = (java.util.List) r1
            java.util.Iterator r2 = r8.iterator()
        L12:
            boolean r3 = r2.hasNext()
            r4 = 0
            if (r3 == 0) goto L35
            java.lang.Object r3 = r2.next()
            androidx.camera.core.impl.UseCaseConfig r3 = (androidx.camera.core.impl.UseCaseConfig) r3
            int r3 = r3.getSurfaceOccupancyPriority(r4)
            java.lang.Integer r4 = java.lang.Integer.valueOf(r3)
            boolean r4 = r1.contains(r4)
            if (r4 != 0) goto L12
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r1.add(r3)
            goto L12
        L35:
            kotlin.collections.CollectionsKt.sort(r1)
            kotlin.collections.CollectionsKt.reverse(r1)
            java.util.Iterator r1 = r1.iterator()
        L3f:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L71
            java.lang.Object r2 = r1.next()
            java.lang.Number r2 = (java.lang.Number) r2
            int r2 = r2.intValue()
            java.util.Iterator r3 = r8.iterator()
        L53:
            boolean r5 = r3.hasNext()
            if (r5 == 0) goto L3f
            java.lang.Object r5 = r3.next()
            androidx.camera.core.impl.UseCaseConfig r5 = (androidx.camera.core.impl.UseCaseConfig) r5
            int r6 = r5.getSurfaceOccupancyPriority(r4)
            if (r2 != r6) goto L53
            int r5 = r8.indexOf(r5)
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            r0.add(r5)
            goto L53
        L71:
            return r0
    }

    private final boolean isConfigFrameRateAcceptable(int r2, android.util.Range<java.lang.Integer> r3, int r4) {
            r1 = this;
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r0 != 0) goto L18
            if (r4 >= r2) goto L18
            java.lang.Comparable r2 = r3.getUpper()
            java.lang.Number r2 = (java.lang.Number) r2
            int r2 = r2.intValue()
            if (r4 >= r2) goto L18
            r2 = 0
            return r2
        L18:
            r2 = 1
            return r2
    }

    private final boolean isStrictFpsRequired(java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r3, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r4) {
            r2 = this;
            java.util.Iterator r3 = r3.iterator()
            r0 = 0
        L5:
            boolean r1 = r3.hasNext()
            if (r1 == 0) goto L1e
            java.lang.Object r1 = r3.next()
            androidx.camera.core.impl.AttachedSurfaceInfo r1 = (androidx.camera.core.impl.AttachedSurfaceInfo) r1
            boolean r1 = r1.isStrictFrameRateRequired()
            boolean r0 = r2.getAndValidateIsStrictFpsRequired(r1, r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)
            goto L5
        L1e:
            java.util.Iterator r3 = r4.iterator()
        L22:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L3b
            java.lang.Object r4 = r3.next()
            androidx.camera.core.impl.UseCaseConfig r4 = (androidx.camera.core.impl.UseCaseConfig) r4
            boolean r4 = r4.isStrictFrameRateRequired()
            boolean r4 = r2.getAndValidateIsStrictFpsRequired(r4, r0)
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r4)
            goto L22
        L3b:
            if (r0 == 0) goto L42
            boolean r3 = r0.booleanValue()
            return r3
        L42:
            r3 = 0
            return r3
    }

    private final boolean isUseCasesCombinationSupported(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r12, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r13, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, ? extends java.util.List<android.util.Size>> r14) {
            r11 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r3 = r0
            java.util.List r3 = (java.util.List) r3
            java.util.Iterator r13 = r13.iterator()
        Lc:
            boolean r0 = r13.hasNext()
            if (r0 == 0) goto L25
            java.lang.Object r0 = r13.next()
            androidx.camera.core.impl.AttachedSurfaceInfo r0 = (androidx.camera.core.impl.AttachedSurfaceInfo) r0
            androidx.camera.core.impl.SurfaceConfig r0 = r0.getSurfaceConfig()
            java.lang.String r1 = "getSurfaceConfig(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r3.add(r0)
            goto Lc
        L25:
            androidx.camera.core.impl.utils.CompareSizesByArea r13 = new androidx.camera.core.impl.utils.CompareSizesByArea
            r13.<init>()
            java.util.Set r0 = r14.keySet()
            java.util.Iterator r0 = r0.iterator()
        L32:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L9f
            java.lang.Object r1 = r0.next()
            androidx.camera.core.impl.UseCaseConfig r1 = (androidx.camera.core.impl.UseCaseConfig) r1
            java.lang.Object r2 = r14.get(r1)
            java.util.List r2 = (java.util.List) r2
            java.util.Collection r2 = (java.util.Collection) r2
            if (r2 == 0) goto L51
            boolean r4 = r2.isEmpty()
            if (r4 == 0) goto L4f
            goto L51
        L4f:
            r4 = 0
            goto L52
        L51:
            r4 = 1
        L52:
            if (r4 != 0) goto L82
            r4 = r13
            java.util.Comparator r4 = (java.util.Comparator) r4
            java.lang.Object r2 = java.util.Collections.min(r2, r4)
            r6 = r2
            android.util.Size r6 = (android.util.Size) r6
            int r5 = r1.getInputFormat()
            androidx.camera.core.impl.StreamUseCase r10 = r1.getStreamUseCase()
            java.lang.String r1 = "getStreamUseCase(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r1)
            androidx.camera.core.impl.SurfaceConfig$Companion r4 = androidx.camera.core.impl.SurfaceConfig.Companion
            kotlin.jvm.internal.Intrinsics.checkNotNull(r6)
            androidx.camera.core.impl.SurfaceSizeDefinition r7 = r11.getUpdatedSurfaceSizeDefinitionByFormat(r5)
            int r8 = r12.getCameraMode()
            androidx.camera.core.impl.SurfaceConfig$ConfigSource r9 = androidx.camera.core.impl.SurfaceConfig.ConfigSource.CAPTURE_SESSION_TABLES
            androidx.camera.core.impl.SurfaceConfig r1 = r4.transformSurfaceConfig(r5, r6, r7, r8, r9, r10)
            r3.add(r1)
            goto L32
        L82:
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            java.lang.String r13 = "No available output size is found for "
            r12.<init>(r13)
            r12.append(r1)
            r13 = 46
            r12.append(r13)
            java.lang.String r12 = r12.toString()
            java.lang.IllegalArgumentException r13 = new java.lang.IllegalArgumentException
            java.lang.String r12 = r12.toString()
            r13.<init>(r12)
            throw r13
        L9f:
            r7 = 28
            r8 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            r1 = r11
            r2 = r12
            boolean r12 = checkSupported$default(r1, r2, r3, r4, r5, r6, r7, r8)
            return r12
    }

    private final void populateReducedSizeListAndUniqueMaxFpsMap(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r8, android.util.Size r9, int r10, int r11, androidx.camera.core.impl.StreamUseCase r12, boolean r13, java.util.Map<androidx.camera.core.impl.SurfaceConfig.ConfigSize, java.util.Set<java.lang.Integer>> r14, java.util.List<android.util.Size> r15) {
            r7 = this;
            androidx.camera.core.impl.SurfaceConfig$Companion r0 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceSizeDefinition r3 = r7.getUpdatedSurfaceSizeDefinitionByFormat(r10)
            int r4 = r8.getCameraMode()
            boolean r1 = r8.getRequiresFeatureComboQuery()
            if (r1 == 0) goto L13
            androidx.camera.core.impl.SurfaceConfig$ConfigSource r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSource.FEATURE_COMBINATION_TABLE
            goto L15
        L13:
            androidx.camera.core.impl.SurfaceConfig$ConfigSource r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSource.CAPTURE_SESSION_TABLES
        L15:
            r2 = r9
            r6 = r12
            r5 = r1
            r1 = r10
            androidx.camera.core.impl.SurfaceConfig r9 = r0.transformSurfaceConfig(r1, r2, r3, r4, r5, r6)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r9 = r9.getConfigSize()
            android.util.Range r10 = r8.getTargetFpsRange()
            android.util.Range<java.lang.Integer> r12 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r10 = kotlin.jvm.internal.Intrinsics.areEqual(r10, r12)
            if (r10 == 0) goto L34
            if (r13 == 0) goto L30
            goto L34
        L30:
            r10 = 2147483647(0x7fffffff, float:NaN)
            goto L3c
        L34:
            boolean r10 = r8.isHighSpeedOn()
            int r10 = r7.getMaxFrameRate(r1, r2, r10, r11)
        L3c:
            boolean r11 = r8.isFeatureComboInvocation()
            if (r11 == 0) goto L63
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r11 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.NOT_SUPPORT
            if (r9 == r11) goto L89
            android.util.Range r11 = r8.getTargetFpsRange()
            android.util.Range<java.lang.Integer> r12 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            boolean r11 = kotlin.jvm.internal.Intrinsics.areEqual(r11, r12)
            if (r11 != 0) goto L63
            android.util.Range r8 = r8.getTargetFpsRange()
            java.lang.Comparable r8 = r8.getUpper()
            java.lang.Number r8 = (java.lang.Number) r8
            int r8 = r8.intValue()
            if (r10 >= r8) goto L63
            goto L89
        L63:
            java.lang.Object r8 = r14.get(r9)
            java.util.Set r8 = (java.util.Set) r8
            if (r8 != 0) goto L75
            java.util.LinkedHashSet r8 = new java.util.LinkedHashSet
            r8.<init>()
            java.util.Set r8 = (java.util.Set) r8
            r14.put(r9, r8)
        L75:
            java.lang.Integer r9 = java.lang.Integer.valueOf(r10)
            boolean r9 = r8.contains(r9)
            if (r9 != 0) goto L89
            r15.add(r2)
            java.lang.Integer r9 = java.lang.Integer.valueOf(r10)
            r8.add(r9)
        L89:
            return
    }

    private final void populateStreamUseCaseIfSameSavedSizes(androidx.camera.camera2.adapter.SupportedSurfaceCombination.BestSizesAndMaxFpsForConfigs r3, java.util.List<androidx.camera.core.impl.SurfaceConfig> r4, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r5, java.util.Map<androidx.camera.core.impl.AttachedSurfaceInfo, androidx.camera.core.impl.StreamSpec> r6, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, androidx.camera.core.impl.StreamSpec> r7, java.util.Map<java.lang.Integer, androidx.camera.core.impl.AttachedSurfaceInfo> r8, java.util.Map<java.lang.Integer, androidx.camera.core.impl.UseCaseConfig<?>> r9) {
            r2 = this;
            if (r4 == 0) goto L73
            int r0 = r3.getMaxFpsForBestSizes()
            int r1 = r3.getMaxFpsForStreamUseCase()
            if (r0 != r1) goto L73
            java.util.List r0 = r3.getBestSizes()
            int r0 = r0.size()
            java.util.List r1 = r3.getBestSizesForStreamUseCase()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r1)
            int r1 = r1.size()
            if (r0 != r1) goto L73
            java.util.List r0 = r3.getBestSizes()
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.List r3 = r3.getBestSizesForStreamUseCase()
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            java.util.List r3 = kotlin.collections.CollectionsKt.zip(r0, r3)
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            boolean r0 = r3 instanceof java.util.Collection
            if (r0 == 0) goto L41
            r0 = r3
            java.util.Collection r0 = (java.util.Collection) r0
            boolean r0 = r0.isEmpty()
            if (r0 == 0) goto L41
            goto L60
        L41:
            java.util.Iterator r3 = r3.iterator()
        L45:
            boolean r0 = r3.hasNext()
            if (r0 == 0) goto L60
            java.lang.Object r0 = r3.next()
            kotlin.Pair r0 = (kotlin.Pair) r0
            java.lang.Object r1 = r0.getFirst()
            java.lang.Object r0 = r0.getSecond()
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r0)
            if (r0 != 0) goto L45
            return
        L60:
            androidx.camera.camera2.internal.StreamUseCaseUtil r3 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            androidx.camera.camera2.pipe.CameraMetadata r0 = r2.cameraMetadata
            boolean r3 = r3.populateStreamUseCaseStreamSpecOptionWithInteropOverride(r0, r5, r7, r6)
            if (r3 != 0) goto L73
            r5 = r7
            r7 = r8
            r8 = r9
            r9 = r4
            androidx.camera.camera2.internal.StreamUseCaseUtil r4 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            r4.populateStreamUseCaseStreamSpecOptionWithSupportedSurfaceConfigs(r5, r6, r7, r8, r9)
        L73:
            return
    }

    private final void refreshPreviewSize() {
            r10 = this;
            androidx.camera.camera2.impl.DisplayInfoManager r0 = r10.displayInfoManager
            r0.refreshPreviewSize()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.surfaceSizeDefinition
            if (r0 != 0) goto Ld
            r10.generateSurfaceSizeDefinition()
            return
        Ld:
            androidx.camera.camera2.impl.DisplayInfoManager r0 = r10.displayInfoManager
            android.util.Size r3 = r0.getPreviewSize()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.getSurfaceSizeDefinition$camera_camera2()
            android.util.Size r1 = r0.getAnalysisSize()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r2 = r0.getS720pSizeMap()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r4 = r0.getS1440pSizeMap()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.getSurfaceSizeDefinition$camera_camera2()
            android.util.Size r5 = r0.getRecordSize()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r6 = r0.getMaximumSizeMap()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r7 = r0.getMaximum4x3SizeMap()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r8 = r0.getMaximum16x9SizeMap()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r10.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r9 = r0.getUltraMaximumSizeMap()
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = androidx.camera.core.impl.SurfaceSizeDefinition.create(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            java.lang.String r1 = "create(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r10.setSurfaceSizeDefinition$camera_camera2(r0)
            return
    }

    private final androidx.camera.core.impl.SurfaceStreamSpecQueryResult resolveSpecsByCheckingMethod(androidx.camera.camera2.adapter.SupportedSurfaceCombination.CheckingMethod r24, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r25, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r26, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, ? extends java.util.List<android.util.Size>> r27, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r28, java.util.List<java.lang.Integer> r29, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, androidx.camera.core.DynamicRange> r30, boolean r31) {
            r23 = this;
            r1 = r23
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r9 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r9)
            if (r0 == 0) goto L24
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "resolveSpecsByCheckingMethod: checkingMethod = "
            r2.<init>(r3)
            r3 = r24
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            android.util.Log.d(r0, r2)
            goto L26
        L24:
            r3 = r24
        L26:
            int[] r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.WhenMappings.$EnumSwitchMapping$0
            int r2 = r3.ordinal()
            r0 = r0[r2]
            r2 = 1
            if (r0 == r2) goto Lfb
            r2 = 2
            if (r0 == r2) goto Lad
            r2 = 3
            if (r0 != r2) goto La7
            r21 = 895(0x37f, float:1.254E-42)
            r22 = 0
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
            r17 = 0
            r18 = 0
            r19 = 0
            r20 = 0
            r10 = r25
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings.copy$default(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22)     // Catch: java.lang.IllegalArgumentException -> L65
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r2 = r1.validateSelf(r0)     // Catch: java.lang.IllegalArgumentException -> L65
            r3 = r26
            r4 = r27
            r5 = r28
            r6 = r29
            r7 = r30
            r8 = r31
            androidx.camera.core.impl.SurfaceStreamSpecQueryResult r0 = r1.resolveSpecsBySettings(r2, r3, r4, r5, r6, r7, r8)     // Catch: java.lang.IllegalArgumentException -> L65
            goto La6
        L65:
            r0 = move-exception
            androidx.camera.camera2.impl.Camera2Logger r2 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.Throwable r0 = (java.lang.Throwable) r0
            boolean r2 = androidx.camera.core.Logger.isDebugEnabled(r9)
            if (r2 == 0) goto L79
            java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r3 = "Failed to find a supported combination without feature combo, trying again with feature combo"
            android.util.Log.d(r2, r3, r0)
        L79:
            r21 = 895(0x37f, float:1.254E-42)
            r22 = 0
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
            r17 = 0
            r18 = 1
            r19 = 0
            r20 = 0
            r10 = r25
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings.copy$default(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22)
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r2 = r1.validateSelf(r0)
            r3 = r26
            r4 = r27
            r5 = r28
            r6 = r29
            r7 = r30
            r8 = r31
            androidx.camera.core.impl.SurfaceStreamSpecQueryResult r0 = r1.resolveSpecsBySettings(r2, r3, r4, r5, r6, r7, r8)
        La6:
            return r0
        La7:
            kotlin.NoWhenBranchMatchedException r0 = new kotlin.NoWhenBranchMatchedException
            r0.<init>()
            throw r0
        Lad:
            boolean r0 = r25.isFeatureComboInvocation()
            if (r0 == 0) goto Lc9
            android.util.Range r0 = r25.getTargetFpsRange()
            android.util.Range<java.lang.Integer> r2 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            if (r0 != r2) goto Lc9
            boolean r0 = r25.getRequiresFeatureComboQuery()
            if (r0 == 0) goto Lc4
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.featuregroup.impl.feature.FpsRangeFeature.DEFAULT_FPS_RANGE
            goto Lcd
        Lc4:
            android.util.Range r0 = r25.getTargetFpsRange()
            goto Lcd
        Lc9:
            android.util.Range r0 = r25.getTargetFpsRange()
        Lcd:
            r19 = r0
            r21 = 639(0x27f, float:8.95E-43)
            r22 = 0
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
            r17 = 0
            r18 = 1
            r20 = 0
            r10 = r25
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings.copy$default(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22)
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r2 = r1.validateSelf(r0)
            r3 = r26
            r4 = r27
            r5 = r28
            r6 = r29
            r7 = r30
            r8 = r31
            androidx.camera.core.impl.SurfaceStreamSpecQueryResult r0 = r1.resolveSpecsBySettings(r2, r3, r4, r5, r6, r7, r8)
            return r0
        Lfb:
            r21 = 895(0x37f, float:1.254E-42)
            r22 = 0
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
            r17 = 0
            r18 = 0
            r19 = 0
            r20 = 0
            r10 = r25
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r0 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings.copy$default(r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21, r22)
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r2 = r1.validateSelf(r0)
            r3 = r26
            r4 = r27
            r5 = r28
            r6 = r29
            r7 = r30
            r8 = r31
            androidx.camera.core.impl.SurfaceStreamSpecQueryResult r0 = r1.resolveSpecsBySettings(r2, r3, r4, r5, r6, r7, r8)
            return r0
    }

    private final androidx.camera.core.impl.SurfaceStreamSpecQueryResult resolveSpecsBySettings(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r17, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r18, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, ? extends java.util.List<android.util.Size>> r19, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r20, java.util.List<java.lang.Integer> r21, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, androidx.camera.core.DynamicRange> r22, boolean r23) {
            r16 = this;
            r0 = r16
            r5 = r17
            r2 = r18
            r3 = r20
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r10 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r10)
            if (r1 == 0) goto L27
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r6 = "resolveSpecsBySettings: featureSettings = "
            r4.<init>(r6)
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            android.util.Log.d(r1, r4)
        L27:
            boolean r1 = r5.isFeatureComboInvocation()
            r11 = 46
            java.lang.String r12 = ". New configs: "
            java.lang.String r13 = "No supported surface combination is found for camera device - Id : "
            if (r1 != 0) goto L6b
            boolean r1 = r16.isUseCasesCombinationSupported(r17, r18, r19)
            if (r1 == 0) goto L3a
            goto L6b
        L3a:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r13)
            java.lang.String r4 = r0.cameraId
            r1.append(r4)
            java.lang.String r4 = ". May be attempting to bind too many use cases. Existing surfaces: "
            r1.append(r4)
            r1.append(r2)
            r1.append(r12)
            r1.append(r3)
            java.lang.String r2 = ". GroupableFeature settings: "
            r1.append(r2)
            r1.append(r5)
            r1.append(r11)
            java.lang.String r1 = r1.toString()
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r2.<init>(r1)
            throw r2
        L6b:
            r1 = r19
            r9 = r23
            java.util.Map r1 = r0.filterSupportedSizes$camera_camera2(r1, r5, r9)
            r4 = r21
            java.util.List r1 = r0.getSupportedOutputSizesList(r1, r3, r4)
            java.util.LinkedHashMap r6 = new java.util.LinkedHashMap
            r6.<init>()
            java.util.Map r6 = (java.util.Map) r6
            java.util.LinkedHashMap r7 = new java.util.LinkedHashMap
            r7.<init>()
            java.util.Map r7 = (java.util.Map) r7
            boolean r8 = r5.isHighSpeedOn()
            if (r8 == 0) goto L94
            androidx.camera.camera2.internal.HighSpeedResolver r8 = r0.highSpeedResolver
            java.util.List r1 = r8.getSizeArrangements(r1)
            goto L98
        L94:
            java.util.List r1 = r0.getAllPossibleSizeArrangements(r1)
        L98:
            androidx.camera.camera2.internal.StreamUseCaseUtil r8 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            boolean r8 = r8.containsZslUseCase(r2, r3)
            boolean r14 = r0.isStreamUseCaseSupported
            if (r14 == 0) goto Lc8
            if (r8 != 0) goto Lc8
            java.util.List r8 = r0.getOrderedSurfaceConfigListForStreamUseCase(r1, r2, r3, r4, r5, r6, r7)
            r14 = r6
            r15 = r7
            androidx.camera.camera2.impl.Camera2Logger r3 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r3 = androidx.camera.core.Logger.isDebugEnabled(r10)
            if (r3 == 0) goto Lcb
            java.lang.String r3 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "orderedSurfaceConfigListForStreamUseCase = "
            r4.<init>(r5)
            r4.append(r8)
            java.lang.String r4 = r4.toString()
            android.util.Log.d(r3, r4)
            goto Lcb
        Lc8:
            r14 = r6
            r15 = r7
            r8 = 0
        Lcb:
            r7 = r8
            boolean r3 = r17.isHighSpeedOn()
            int r4 = r0.getMaxSupportedFpsFromAttachedSurfaces(r2, r3)
            r6 = r17
            r3 = r20
            r5 = r21
            r8 = r22
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$BestSizesAndMaxFpsForConfigs r1 = r0.findBestSizesAndFps(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            if (r1 == 0) goto L129
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r10)
            if (r0 == 0) goto Lff
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "resolveSpecsBySettings: bestSizesAndFps = "
            r2.<init>(r3)
            r2.append(r1)
            java.lang.String r2 = r2.toString()
            android.util.Log.d(r0, r2)
        Lff:
            r0 = r16
            r5 = r17
            r2 = r20
            r3 = r21
            r4 = r22
            java.util.Map r5 = r0.generateSuggestedStreamSpecMap(r1, r2, r3, r4, r5)
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            r4 = r0
            java.util.Map r4 = (java.util.Map) r4
            r0 = r16
            r3 = r18
            r2 = r7
            r6 = r14
            r7 = r15
            r0.populateStreamUseCaseIfSameSavedSizes(r1, r2, r3, r4, r5, r6, r7)
            androidx.camera.core.impl.SurfaceStreamSpecQueryResult r2 = new androidx.camera.core.impl.SurfaceStreamSpecQueryResult
            int r1 = r1.getMaxFpsForAllSizes()
            r2.<init>(r5, r4, r1)
            return r2
        L129:
            r0 = r16
            r2 = r18
            r3 = r20
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>(r13)
            java.lang.String r4 = r0.cameraId
            r1.append(r4)
            java.lang.String r4 = " and Hardware level: "
            r1.append(r4)
            int r4 = r0.hardwareLevel
            r1.append(r4)
            java.lang.String r4 = ". May be the specified resolution is too large and not supported. Existing surfaces: "
            r1.append(r4)
            r1.append(r2)
            r1.append(r12)
            r1.append(r3)
            r1.append(r11)
            java.lang.String r1 = r1.toString()
            java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
            java.lang.String r1 = r1.toString()
            r2.<init>(r1)
            throw r2
    }

    private final void updateMaximumSizeByFormat(java.util.Map<java.lang.Integer, android.util.Size> r3, int r4, android.util.Rational r5) {
            r2 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r2.streamConfigurationMapCompat
            android.hardware.camera2.params.StreamConfigurationMap r0 = r0.toStreamConfigurationMap()
            r1 = 1
            android.util.Size r5 = r2.getMaxOutputSizeByFormat$camera_camera2(r0, r4, r1, r5)
            if (r5 == 0) goto L14
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r3.put(r4, r5)
        L14:
            return
    }

    static /* synthetic */ void updateMaximumSizeByFormat$default(androidx.camera.camera2.adapter.SupportedSurfaceCombination r0, java.util.Map r1, int r2, android.util.Rational r3, int r4, java.lang.Object r5) {
            r4 = r4 & 4
            if (r4 == 0) goto L5
            r3 = 0
        L5:
            r0.updateMaximumSizeByFormat(r1, r2, r3)
            return
    }

    private final void updateS720pOrS1440pSizeByFormat(java.util.Map<java.lang.Integer, android.util.Size> r9, android.util.Size r10, int r11) {
            r8 = this;
            boolean r0 = r8.isConcurrentCameraModeSupported
            if (r0 != 0) goto L5
            return
        L5:
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r8.streamConfigurationMapCompat
            android.hardware.camera2.params.StreamConfigurationMap r2 = r0.toStreamConfigurationMap()
            r6 = 8
            r7 = 0
            r4 = 0
            r5 = 0
            r1 = r8
            r3 = r11
            android.util.Size r11 = getMaxOutputSizeByFormat$camera_camera2$default(r1, r2, r3, r4, r5, r6, r7)
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)
            if (r11 != 0) goto L1d
            goto L34
        L1d:
            android.util.Size[] r10 = new android.util.Size[]{r10, r11}
            java.util.List r10 = kotlin.collections.CollectionsKt.listOf(r10)
            java.util.Collection r10 = (java.util.Collection) r10
            androidx.camera.core.impl.utils.CompareSizesByArea r11 = new androidx.camera.core.impl.utils.CompareSizesByArea
            r11.<init>()
            java.util.Comparator r11 = (java.util.Comparator) r11
            java.lang.Object r10 = java.util.Collections.min(r10, r11)
            android.util.Size r10 = (android.util.Size) r10
        L34:
            r9.put(r0, r10)
            return
    }

    private final void updateUltraMaximumSizeByFormat(java.util.Map<java.lang.Integer, android.util.Size> r9, int r10) {
            r8 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 31
            if (r0 < r1) goto L34
            boolean r0 = r8.isUltraHighResolutionSensorSupported
            if (r0 != 0) goto Lb
            goto L34
        Lb:
            androidx.camera.camera2.pipe.CameraMetadata r0 = r8.cameraMetadata
            android.hardware.camera2.CameraCharacteristics$Key r1 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m30m$1()
            java.lang.String r2 = "SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            r2 = r0
            android.hardware.camera2.params.StreamConfigurationMap r2 = (android.hardware.camera2.params.StreamConfigurationMap) r2
            if (r2 != 0) goto L20
            goto L34
        L20:
            r6 = 8
            r7 = 0
            r4 = 1
            r5 = 0
            r1 = r8
            r3 = r10
            android.util.Size r10 = getMaxOutputSizeByFormat$camera_camera2$default(r1, r2, r3, r4, r5, r6, r7)
            if (r10 == 0) goto L34
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)
            r9.put(r0, r10)
        L34:
            return
    }

    private final androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings validateSelf(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r5) {
            r4 = this;
            int r0 = r5.getCameraMode()
            java.lang.String r1 = " camera mode."
            java.lang.String r2 = "Camera device Id is "
            if (r0 == 0) goto L3c
            boolean r0 = r5.isUltraHdrOn()
            if (r0 != 0) goto L11
            goto L3c
        L11:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>(r2)
            java.lang.String r2 = r4.cameraId
            r0.append(r2)
            java.lang.String r2 = ". Ultra HDR is not currently supported in "
            r0.append(r2)
            int r5 = r5.getCameraMode()
            java.lang.String r5 = androidx.camera.core.impl.CameraMode.toLabelString(r5)
            r0.append(r5)
            r0.append(r1)
            java.lang.String r5 = r0.toString()
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r5 = r5.toString()
            r0.<init>(r5)
            throw r0
        L3c:
            int r0 = r5.getCameraMode()
            if (r0 == 0) goto L76
            int r0 = r5.getRequiredMaxBitDepth()
            r3 = 10
            if (r0 == r3) goto L4b
            goto L76
        L4b:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>(r2)
            java.lang.String r2 = r4.cameraId
            r0.append(r2)
            java.lang.String r2 = ". 10 bit dynamic range is not currently supported in "
            r0.append(r2)
            int r5 = r5.getCameraMode()
            java.lang.String r5 = androidx.camera.core.impl.CameraMode.toLabelString(r5)
            r0.append(r5)
            r0.append(r1)
            java.lang.String r5 = r0.toString()
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r5 = r5.toString()
            r0.<init>(r5)
            throw r0
        L76:
            int r0 = r5.getCameraMode()
            if (r0 == 0) goto Lae
            boolean r0 = r5.isFeatureComboInvocation()
            if (r0 != 0) goto L83
            goto Lae
        L83:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>(r2)
            java.lang.String r2 = r4.cameraId
            r0.append(r2)
            java.lang.String r2 = ". feature combination is not currently supported in "
            r0.append(r2)
            int r5 = r5.getCameraMode()
            java.lang.String r5 = androidx.camera.core.impl.CameraMode.toLabelString(r5)
            r0.append(r5)
            r0.append(r1)
            java.lang.String r5 = r0.toString()
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r5 = r5.toString()
            r0.<init>(r5)
            throw r0
        Lae:
            boolean r0 = r5.isHighSpeedOn()
            if (r0 == 0) goto Lc7
            boolean r0 = r5.isFeatureComboInvocation()
            if (r0 != 0) goto Lbb
            goto Lc7
        Lbb:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "High-speed session is not supported with feature combination"
            java.lang.String r0 = r0.toString()
            r5.<init>(r0)
            throw r5
        Lc7:
            boolean r0 = r5.isHighSpeedOn()
            if (r0 == 0) goto Le2
            androidx.camera.camera2.internal.HighSpeedResolver r0 = r4.highSpeedResolver
            boolean r0 = r0.isHighSpeedSupported()
            if (r0 == 0) goto Ld6
            goto Le2
        Ld6:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "High-speed session is not supported on this device."
            java.lang.String r0 = r0.toString()
            r5.<init>(r0)
            throw r5
        Le2:
            return r5
    }

    public final java.util.List<android.util.Size> applyResolutionSelectionOrderRelatedWorkarounds(java.util.List<android.util.Size> r6, int r7) {
            r5 = this;
            java.lang.String r0 = "sizeList"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            androidx.camera.camera2.compat.workaround.TargetAspectRatio r0 = r5.targetAspectRatio
            androidx.camera.camera2.pipe.CameraMetadata r1 = r5.cameraMetadata
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r2 = r5.streamConfigurationMapCompat
            int r0 = r0.get(r1, r2)
            if (r0 == 0) goto L4f
            r1 = 1
            if (r0 == r1) goto L4c
            r1 = 2
            r2 = 0
            if (r0 == r1) goto L32
            r1 = 3
            if (r0 != r1) goto L1c
            goto L51
        L1c:
            java.lang.AssertionError r6 = new java.lang.AssertionError
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            java.lang.String r0 = "Undefined targetAspectRatio: "
            r7.<init>(r0)
            androidx.camera.camera2.compat.workaround.TargetAspectRatio r0 = r5.targetAspectRatio
            r7.append(r0)
            java.lang.String r7 = r7.toString()
            r6.<init>(r7)
            throw r6
        L32:
            r0 = 256(0x100, float:3.59E-43)
            androidx.camera.core.impl.SurfaceSizeDefinition r1 = r5.getUpdatedSurfaceSizeDefinitionByFormat(r0)
            android.util.Size r0 = r1.getMaximumSize(r0)
            if (r0 == 0) goto L51
            android.util.Rational r2 = new android.util.Rational
            int r1 = r0.getWidth()
            int r0 = r0.getHeight()
            r2.<init>(r1, r0)
            goto L51
        L4c:
            android.util.Rational r2 = androidx.camera.core.impl.utils.AspectRatioUtil.ASPECT_RATIO_16_9
            goto L51
        L4f:
            android.util.Rational r2 = androidx.camera.core.impl.utils.AspectRatioUtil.ASPECT_RATIO_4_3
        L51:
            if (r2 != 0) goto L5a
            java.util.Collection r6 = (java.util.Collection) r6
            java.util.List r6 = kotlin.collections.CollectionsKt.toMutableList(r6)
            goto L8d
        L5a:
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.List r1 = (java.util.List) r1
            java.util.Iterator r6 = r6.iterator()
        L6c:
            boolean r3 = r6.hasNext()
            if (r3 == 0) goto L86
            java.lang.Object r3 = r6.next()
            android.util.Size r3 = (android.util.Size) r3
            boolean r4 = androidx.camera.core.impl.utils.AspectRatioUtil.hasMatchingAspectRatio(r3, r2)
            if (r4 == 0) goto L82
            r0.add(r3)
            goto L6c
        L82:
            r1.add(r3)
            goto L6c
        L86:
            r6 = 0
            java.util.Collection r0 = (java.util.Collection) r0
            r1.addAll(r6, r0)
            r6 = r1
        L8d:
            androidx.camera.camera2.compat.workaround.ResolutionCorrector r0 = r5.resolutionCorrector
            androidx.camera.core.impl.SurfaceConfig$Companion r1 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r7 = r1.getConfigType(r7)
            java.util.List r6 = r0.insertOrPrioritize(r7, r6)
            return r6
    }

    public final boolean checkSupported(androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r4, java.util.List<androidx.camera.core.impl.SurfaceConfig> r5, java.util.Map<androidx.camera.core.impl.SurfaceConfig, androidx.camera.core.DynamicRange> r6, java.util.List<? extends androidx.camera.core.impl.UseCaseConfig<?>> r7, java.util.List<java.lang.Integer> r8) {
            r3 = this;
            java.lang.String r0 = "featureSettings"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "surfaceConfigList"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "dynamicRangesBySurfaceConfig"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.lang.String r0 = "newUseCaseConfigs"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.String r0 = "useCasesPriorityOrder"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            java.util.List r0 = r3.getSurfaceCombinationsByFeatureSettings(r4)
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            boolean r1 = r0 instanceof java.util.Collection
            r2 = 0
            if (r1 == 0) goto L2e
            r1 = r0
            java.util.Collection r1 = (java.util.Collection) r1
            boolean r1 = r1.isEmpty()
            if (r1 == 0) goto L2e
            goto L45
        L2e:
            java.util.Iterator r0 = r0.iterator()
        L32:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L45
            java.lang.Object r1 = r0.next()
            androidx.camera.core.impl.SurfaceCombination r1 = (androidx.camera.core.impl.SurfaceCombination) r1
            java.util.List r1 = r1.getOrderedSupportedSurfaceConfigList(r5)
            if (r1 == 0) goto L32
            r2 = 1
        L45:
            if (r2 == 0) goto L78
            boolean r0 = r4.getRequiresFeatureComboQuery()
            if (r0 == 0) goto L78
            androidx.camera.core.impl.SessionConfig r4 = r3.createFeatureComboSessionConfig(r4, r5, r6, r7, r8)
            r5 = r3
            androidx.camera.core.featuregroup.impl.FeatureCombinationQuery r6 = r5.featureCombinationQuery
            boolean r6 = r6.isSupported(r4)
            java.util.List r4 = r4.getSurfaces()
            java.lang.String r7 = "getSurfaces(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r7)
            java.lang.Iterable r4 = (java.lang.Iterable) r4
            java.util.Iterator r4 = r4.iterator()
        L67:
            boolean r7 = r4.hasNext()
            if (r7 == 0) goto L77
            java.lang.Object r7 = r4.next()
            androidx.camera.core.impl.DeferrableSurface r7 = (androidx.camera.core.impl.DeferrableSurface) r7
            r7.close()
            goto L67
        L77:
            return r6
        L78:
            r5 = r3
            return r2
    }

    public final java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, java.util.List<android.util.Size>> filterSupportedSizes$camera_camera2(java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, ? extends java.util.List<android.util.Size>> r14, androidx.camera.camera2.adapter.SupportedSurfaceCombination.FeatureSettings r15, boolean r16) {
            r13 = this;
            java.lang.String r0 = "newUseCaseConfigsSupportedSizeMap"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)
            java.lang.String r0 = "featureSettings"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r15, r0)
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            java.util.Set r1 = r14.keySet()
            java.util.Iterator r1 = r1.iterator()
        L19:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L6c
            java.lang.Object r2 = r1.next()
            androidx.camera.core.impl.UseCaseConfig r2 = (androidx.camera.core.impl.UseCaseConfig) r2
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r12 = r3
            java.util.List r12 = (java.util.List) r12
            java.util.LinkedHashMap r3 = new java.util.LinkedHashMap
            r3.<init>()
            r11 = r3
            java.util.Map r11 = (java.util.Map) r11
            java.lang.Object r3 = r14.get(r2)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3)
            java.util.List r3 = (java.util.List) r3
            java.util.Iterator r3 = r3.iterator()
        L42:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto L68
            java.lang.Object r4 = r3.next()
            r6 = r4
            android.util.Size r6 = (android.util.Size) r6
            int r7 = r2.getInputFormat()
            int r8 = r2.getCustomMaxFrameRate(r6)
            androidx.camera.core.impl.StreamUseCase r9 = r2.getStreamUseCase()
            java.lang.String r4 = "getStreamUseCase(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r4)
            r4 = r13
            r5 = r15
            r10 = r16
            r4.populateReducedSizeListAndUniqueMaxFpsMap(r5, r6, r7, r8, r9, r10, r11, r12)
            goto L42
        L68:
            r0.put(r2, r12)
            goto L19
        L6c:
            return r0
    }

    public final android.util.Size getMaxOutputSizeByFormat$camera_camera2(android.hardware.camera2.params.StreamConfigurationMap r4, int r5, boolean r6, android.util.Rational r7) {
            r3 = this;
            android.util.Size[] r7 = r3.getOutputSizes(r4, r5, r7)
            r0 = 0
            if (r7 == 0) goto L4c
            int r1 = r7.length
            if (r1 != 0) goto Lb
            goto L4c
        Lb:
            androidx.camera.core.impl.utils.CompareSizesByArea r1 = new androidx.camera.core.impl.utils.CompareSizesByArea
            r1.<init>()
            java.util.List r7 = kotlin.collections.ArraysKt.asList(r7)
            java.util.Collection r7 = (java.util.Collection) r7
            java.util.Comparator r1 = (java.util.Comparator) r1
            java.lang.Object r7 = java.util.Collections.max(r7, r1)
            android.util.Size r7 = (android.util.Size) r7
            android.util.Size r2 = androidx.camera.core.internal.utils.SizeUtil.RESOLUTION_ZERO
            if (r6 == 0) goto L3b
            if (r4 == 0) goto L28
            android.util.Size[] r0 = r4.getHighResolutionOutputSizes(r5)
        L28:
            if (r0 == 0) goto L3b
            int r4 = r0.length
            if (r4 != 0) goto L2e
            goto L3b
        L2e:
            java.util.List r4 = kotlin.collections.ArraysKt.asList(r0)
            java.util.Collection r4 = (java.util.Collection) r4
            java.lang.Object r4 = java.util.Collections.max(r4, r1)
            r2 = r4
            android.util.Size r2 = (android.util.Size) r2
        L3b:
            android.util.Size[] r4 = new android.util.Size[]{r7, r2}
            java.util.List r4 = kotlin.collections.CollectionsKt.listOf(r4)
            java.util.Collection r4 = (java.util.Collection) r4
            java.lang.Object r4 = java.util.Collections.max(r4, r1)
            android.util.Size r4 = (android.util.Size) r4
            return r4
        L4c:
            return r0
    }

    public final androidx.camera.core.impl.SurfaceStreamSpecQueryResult getSuggestedStreamSpecifications(int r17, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r18, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, ? extends java.util.List<android.util.Size>> r19, androidx.camera.core.impl.stabilization.VideoStabilization r20, boolean r21, boolean r22, boolean r23) {
            r16 = this;
            r0 = r16
            r11 = r18
            r1 = r19
            r3 = r20
            r5 = r22
            java.lang.String r2 = "attachedSurfaces"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r2)
            java.lang.String r2 = "newUseCaseConfigsSupportedSizeMap"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r2)
            java.lang.String r2 = "videoStabilization"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r2)
            r0.refreshPreviewSize()
            androidx.camera.camera2.internal.HighSpeedResolver$Companion r2 = androidx.camera.camera2.internal.HighSpeedResolver.Companion
            r4 = r11
            java.util.Collection r4 = (java.util.Collection) r4
            java.util.Set r6 = r1.keySet()
            java.util.Collection r6 = (java.util.Collection) r6
            boolean r6 = r2.isHighSpeedOn(r4, r6)
            if (r6 == 0) goto L33
            androidx.camera.camera2.internal.HighSpeedResolver r2 = r0.highSpeedResolver
            java.util.Map r1 = r2.filterCommonSupportedSizes(r1)
        L33:
            r12 = r1
            java.util.Set r1 = r12.keySet()
            java.lang.Iterable r1 = (java.lang.Iterable) r1
            java.util.List r13 = kotlin.collections.CollectionsKt.toList(r1)
            java.util.List r14 = r0.getUseCasesPriorityOrder(r13)
            androidx.camera.camera2.internal.DynamicRangeResolver r1 = r0.dynamicRangeResolver
            java.util.Map r7 = r1.resolveAndValidateDynamicRanges(r11, r13, r14)
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r2 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r2 == 0) goto L67
            java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r8 = "resolvedDynamicRanges = "
            r4.<init>(r8)
            r4.append(r7)
            java.lang.String r4 = r4.toString()
            android.util.Log.d(r2, r4)
        L67:
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$Companion r2 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.Companion
            boolean r4 = androidx.camera.camera2.adapter.SupportedSurfaceCombination.Companion.access$isUltraHdrOn(r2, r11, r12)
            r2 = 0
            if (r23 == 0) goto L7b
            java.lang.Boolean r8 = java.lang.Boolean.valueOf(r2)
            android.util.Range<java.lang.Integer> r9 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            kotlin.Pair r8 = kotlin.TuplesKt.to(r8, r9)
            goto L8b
        L7b:
            boolean r8 = r0.isStrictFpsRequired(r11, r13)
            android.util.Range r9 = r0.getTargetFpsRange(r11, r13, r14, r8)
            java.lang.Boolean r8 = java.lang.Boolean.valueOf(r8)
            kotlin.Pair r8 = kotlin.TuplesKt.to(r8, r9)
        L8b:
            java.lang.Object r9 = r8.component1()
            java.lang.Boolean r9 = (java.lang.Boolean) r9
            boolean r10 = r9.booleanValue()
            java.lang.Object r8 = r8.component2()
            r9 = r8
            android.util.Range r9 = (android.util.Range) r9
            androidx.camera.core.impl.stabilization.VideoStabilization r8 = androidx.camera.core.impl.stabilization.VideoStabilization.PREVIEW
            if (r3 != r8) goto La1
            r2 = 1
        La1:
            androidx.camera.camera2.impl.Camera2Logger r8 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r1 == 0) goto Lca
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            java.lang.String r15 = "getSuggestedStreamSpecifications: isPreviewStabilizationSupported = "
            r8.<init>(r15)
            boolean r15 = access$isPreviewStabilizationSupported$p(r0)
            r8.append(r15)
            java.lang.String r15 = ", isFeatureComboInvocation = "
            r8.append(r15)
            r8.append(r5)
            java.lang.String r8 = r8.toString()
            android.util.Log.d(r1, r8)
        Lca:
            if (r2 == 0) goto Ldf
            boolean r1 = r0.isPreviewStabilizationSupported
            if (r1 != 0) goto Ldf
            if (r5 != 0) goto Ld3
            goto Ldf
        Ld3:
            java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
            java.lang.String r2 = "Preview stabilization is not supported by the camera."
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        Ldf:
            kotlin.jvm.internal.Intrinsics.checkNotNull(r9)
            r8 = 0
            r1 = r4
            r4 = r3
            r3 = r7
            r7 = r5
            r5 = r1
            r1 = r17
            r2 = r21
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$FeatureSettings r6 = r0.createFeatureSettings(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10)
            r7 = r3
            r4 = r5
            java.util.Collection r1 = r7.values()
            r0 = r16
            r3 = r20
            r5 = r22
            r2 = r9
            androidx.camera.camera2.adapter.SupportedSurfaceCombination$CheckingMethod r1 = r0.getCheckingMethod(r1, r2, r3, r4, r5)
            r8 = r23
            r2 = r6
            r3 = r11
            r4 = r12
            r5 = r13
            r6 = r14
            androidx.camera.core.impl.SurfaceStreamSpecQueryResult r1 = r0.resolveSpecsByCheckingMethod(r1, r2, r3, r4, r5, r6, r7, r8)
            return r1
    }

    public final androidx.camera.core.impl.SurfaceSizeDefinition getSurfaceSizeDefinition$camera_camera2() {
            r1 = this;
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r1.surfaceSizeDefinition
            if (r0 == 0) goto L5
            return r0
        L5:
            java.lang.String r0 = "surfaceSizeDefinition"
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r0)
            r0 = 0
            return r0
    }

    public final androidx.camera.core.impl.SurfaceSizeDefinition getUpdatedSurfaceSizeDefinitionByFormat(int r8) {
            r7 = this;
            java.util.List<java.lang.Integer> r0 = r7.surfaceSizeDefinitionFormats
            java.lang.Integer r1 = java.lang.Integer.valueOf(r8)
            boolean r0 = r0.contains(r1)
            if (r0 != 0) goto L8d
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r7.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r0 = r0.getS720pSizeMap()
            java.lang.String r1 = "getS720pSizeMap(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            android.util.Size r1 = androidx.camera.core.internal.utils.SizeUtil.RESOLUTION_720P
            java.lang.String r2 = "RESOLUTION_720P"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            r7.updateS720pOrS1440pSizeByFormat(r0, r1, r8)
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r7.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r0 = r0.getS1440pSizeMap()
            java.lang.String r1 = "getS1440pSizeMap(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            android.util.Size r1 = androidx.camera.core.internal.utils.SizeUtil.RESOLUTION_1440P
            java.lang.String r2 = "RESOLUTION_1440P"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            r7.updateS720pOrS1440pSizeByFormat(r0, r1, r8)
            androidx.camera.core.impl.SurfaceSizeDefinition r0 = r7.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r2 = r0.getMaximumSizeMap()
            java.lang.String r0 = "getMaximumSizeMap(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r0)
            r5 = 4
            r6 = 0
            r4 = 0
            r1 = r7
            r3 = r8
            updateMaximumSizeByFormat$default(r1, r2, r3, r4, r5, r6)
            androidx.camera.core.impl.SurfaceSizeDefinition r8 = r7.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r8 = r8.getMaximum4x3SizeMap()
            java.lang.String r0 = "getMaximum4x3SizeMap(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0)
            android.util.Rational r0 = androidx.camera.core.impl.utils.AspectRatioUtil.ASPECT_RATIO_4_3
            r7.updateMaximumSizeByFormat(r8, r3, r0)
            androidx.camera.core.impl.SurfaceSizeDefinition r8 = r7.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r8 = r8.getMaximum16x9SizeMap()
            java.lang.String r0 = "getMaximum16x9SizeMap(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0)
            android.util.Rational r0 = androidx.camera.core.impl.utils.AspectRatioUtil.ASPECT_RATIO_16_9
            r7.updateMaximumSizeByFormat(r8, r3, r0)
            androidx.camera.core.impl.SurfaceSizeDefinition r8 = r7.getSurfaceSizeDefinition$camera_camera2()
            java.util.Map r8 = r8.getUltraMaximumSizeMap()
            java.lang.String r0 = "getUltraMaximumSizeMap(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0)
            r7.updateUltraMaximumSizeByFormat(r8, r3)
            java.util.List<java.lang.Integer> r8 = r1.surfaceSizeDefinitionFormats
            java.lang.Integer r0 = java.lang.Integer.valueOf(r3)
            r8.add(r0)
            goto L8e
        L8d:
            r1 = r7
        L8e:
            androidx.camera.core.impl.SurfaceSizeDefinition r8 = r7.getSurfaceSizeDefinition$camera_camera2()
            return r8
    }

    public final void setSurfaceSizeDefinition$camera_camera2(androidx.camera.core.impl.SurfaceSizeDefinition r2) {
            r1 = this;
            java.lang.String r0 = "<set-?>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.surfaceSizeDefinition = r2
            return
    }

    public final androidx.camera.core.impl.SurfaceConfig transformSurfaceConfig(int r9, int r10, android.util.Size r11, androidx.camera.core.impl.StreamUseCase r12) {
            r8 = this;
            java.lang.String r0 = "size"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            java.lang.String r0 = "streamUseCase"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            androidx.camera.core.impl.SurfaceConfig$Companion r1 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceSizeDefinition r4 = r8.getUpdatedSurfaceSizeDefinitionByFormat(r10)
            androidx.camera.core.impl.SurfaceConfig$ConfigSource r6 = androidx.camera.core.impl.SurfaceConfig.ConfigSource.CAPTURE_SESSION_TABLES
            r5 = r9
            r2 = r10
            r3 = r11
            r7 = r12
            androidx.camera.core.impl.SurfaceConfig r9 = r1.transformSurfaceConfig(r2, r3, r4, r5, r6, r7)
            return r9
    }
}
