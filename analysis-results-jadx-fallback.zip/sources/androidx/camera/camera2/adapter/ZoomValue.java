package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: ZoomValue.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001:\u0001\u001cB\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007B!\b\u0016\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\nJ\b\u0010\f\u001a\u00020\u0003H\u0016J\b\u0010\r\u001a\u00020\u0003H\u0016J\b\u0010\u000e\u001a\u00020\u0003H\u0016J\b\u0010\u000f\u001a\u00020\u0003H\u0016J\t\u0010\u0010\u001a\u00020\u0003HÂ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÂ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÂ\u0003J'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0003HÆ\u0001J\u0014\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017HÖ\u0083\u0004J\n\u0010\u0018\u001a\u00020\u0019HÖ\u0081\u0004J\n\u0010\u001a\u001a\u00020\u001bHÖ\u0081\u0004R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\b\u001a\u0004\u0018\u00010\u0003X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u000b¨\u0006\u001d"}, d2 = {"Landroidx/camera/camera2/adapter/ZoomValue;", "Landroidx/camera/core/ZoomState;", "zoomRatio", "", "minZoomRatio", "maxZoomRatio", "<init>", "(FFF)V", "linearZoom", "Landroidx/camera/camera2/adapter/ZoomValue$LinearZoom;", "(Landroidx/camera/camera2/adapter/ZoomValue$LinearZoom;FF)V", "Ljava/lang/Float;", "getZoomRatio", "getMaxZoomRatio", "getMinZoomRatio", "getLinearZoom", "component1", "component2", "component3", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "LinearZoom", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ZoomValue implements androidx.camera.core.ZoomState {
    private java.lang.Float linearZoom;
    private final float maxZoomRatio;
    private final float minZoomRatio;
    private final float zoomRatio;

    /* JADX INFO: compiled from: ZoomValue.kt */
    @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0014\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\r\u001a\u00020\u000eHÖ\u0081\u0004J\n\u0010\u000f\u001a\u00020\u0010HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Landroidx/camera/camera2/adapter/ZoomValue$LinearZoom;", "", "value", "", "<init>", "(F)V", "getValue", "()F", "component1", "copy", "equals", "", "other", "hashCode", "", "toString", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class LinearZoom {
        private final float value;

        public LinearZoom(float r1) {
                r0 = this;
                r0.<init>()
                r0.value = r1
                return
        }

        public static /* synthetic */ androidx.camera.camera2.adapter.ZoomValue.LinearZoom copy$default(androidx.camera.camera2.adapter.ZoomValue.LinearZoom r0, float r1, int r2, java.lang.Object r3) {
                r2 = r2 & 1
                if (r2 == 0) goto L6
                float r1 = r0.value
            L6:
                androidx.camera.camera2.adapter.ZoomValue$LinearZoom r0 = r0.copy(r1)
                return r0
        }

        public final float component1() {
                r1 = this;
                float r0 = r1.value
                return r0
        }

        public final androidx.camera.camera2.adapter.ZoomValue.LinearZoom copy(float r2) {
                r1 = this;
                androidx.camera.camera2.adapter.ZoomValue$LinearZoom r0 = new androidx.camera.camera2.adapter.ZoomValue$LinearZoom
                r0.<init>(r2)
                return r0
        }

        public boolean equals(java.lang.Object r4) {
                r3 = this;
                r0 = 1
                if (r3 != r4) goto L4
                return r0
            L4:
                boolean r1 = r4 instanceof androidx.camera.camera2.adapter.ZoomValue.LinearZoom
                r2 = 0
                if (r1 != 0) goto La
                return r2
            La:
                androidx.camera.camera2.adapter.ZoomValue$LinearZoom r4 = (androidx.camera.camera2.adapter.ZoomValue.LinearZoom) r4
                float r1 = r3.value
                float r4 = r4.value
                int r4 = java.lang.Float.compare(r1, r4)
                if (r4 == 0) goto L17
                return r2
            L17:
                return r0
        }

        public final float getValue() {
                r1 = this;
                float r0 = r1.value
                return r0
        }

        public int hashCode() {
                r1 = this;
                float r0 = r1.value
                int r0 = java.lang.Float.hashCode(r0)
                return r0
        }

        public java.lang.String toString() {
                r2 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                java.lang.String r1 = "LinearZoom(value="
                r0.<init>(r1)
                float r1 = r2.value
                r0.append(r1)
                r1 = 41
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                return r0
        }
    }

    public ZoomValue(float r1, float r2, float r3) {
            r0 = this;
            r0.<init>()
            r0.zoomRatio = r1
            r0.minZoomRatio = r2
            r0.maxZoomRatio = r3
            return
    }

    public ZoomValue(androidx.camera.camera2.adapter.ZoomValue.LinearZoom r3, float r4, float r5) {
            r2 = this;
            java.lang.String r0 = "linearZoom"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.internal.ZoomMath r0 = androidx.camera.camera2.internal.ZoomMath.INSTANCE
            float r1 = r3.getValue()
            float r0 = r0.getZoomRatioFromLinearZoom(r1, r4, r5)
            r2.<init>(r0, r4, r5)
            float r3 = r3.getValue()
            java.lang.Float r3 = java.lang.Float.valueOf(r3)
            r2.linearZoom = r3
            return
    }

    private final float component1() {
            r1 = this;
            float r0 = r1.zoomRatio
            return r0
    }

    private final float component2() {
            r1 = this;
            float r0 = r1.minZoomRatio
            return r0
    }

    private final float component3() {
            r1 = this;
            float r0 = r1.maxZoomRatio
            return r0
    }

    public static /* synthetic */ androidx.camera.camera2.adapter.ZoomValue copy$default(androidx.camera.camera2.adapter.ZoomValue r0, float r1, float r2, float r3, int r4, java.lang.Object r5) {
            r5 = r4 & 1
            if (r5 == 0) goto L6
            float r1 = r0.zoomRatio
        L6:
            r5 = r4 & 2
            if (r5 == 0) goto Lc
            float r2 = r0.minZoomRatio
        Lc:
            r4 = r4 & 4
            if (r4 == 0) goto L12
            float r3 = r0.maxZoomRatio
        L12:
            androidx.camera.camera2.adapter.ZoomValue r0 = r0.copy(r1, r2, r3)
            return r0
    }

    public final androidx.camera.camera2.adapter.ZoomValue copy(float r2, float r3, float r4) {
            r1 = this;
            androidx.camera.camera2.adapter.ZoomValue r0 = new androidx.camera.camera2.adapter.ZoomValue
            r0.<init>(r2, r3, r4)
            return r0
    }

    public boolean equals(java.lang.Object r5) {
            r4 = this;
            r0 = 1
            if (r4 != r5) goto L4
            return r0
        L4:
            boolean r1 = r5 instanceof androidx.camera.camera2.adapter.ZoomValue
            r2 = 0
            if (r1 != 0) goto La
            return r2
        La:
            androidx.camera.camera2.adapter.ZoomValue r5 = (androidx.camera.camera2.adapter.ZoomValue) r5
            float r1 = r4.zoomRatio
            float r3 = r5.zoomRatio
            int r1 = java.lang.Float.compare(r1, r3)
            if (r1 == 0) goto L17
            return r2
        L17:
            float r1 = r4.minZoomRatio
            float r3 = r5.minZoomRatio
            int r1 = java.lang.Float.compare(r1, r3)
            if (r1 == 0) goto L22
            return r2
        L22:
            float r1 = r4.maxZoomRatio
            float r5 = r5.maxZoomRatio
            int r5 = java.lang.Float.compare(r1, r5)
            if (r5 == 0) goto L2d
            return r2
        L2d:
            return r0
    }

    @Override // androidx.camera.core.ZoomState
    public float getLinearZoom() {
            r4 = this;
            java.lang.Float r0 = r4.linearZoom
            if (r0 == 0) goto L9
            float r0 = r0.floatValue()
            return r0
        L9:
            androidx.camera.camera2.internal.ZoomMath r0 = androidx.camera.camera2.internal.ZoomMath.INSTANCE
            float r1 = r4.zoomRatio
            float r2 = r4.minZoomRatio
            float r3 = r4.maxZoomRatio
            float r0 = r0.getLinearZoomFromZoomRatio(r1, r2, r3)
            return r0
    }

    @Override // androidx.camera.core.ZoomState
    public float getMaxZoomRatio() {
            r1 = this;
            float r0 = r1.maxZoomRatio
            return r0
    }

    @Override // androidx.camera.core.ZoomState
    public float getMinZoomRatio() {
            r1 = this;
            float r0 = r1.minZoomRatio
            return r0
    }

    @Override // androidx.camera.core.ZoomState
    public float getZoomRatio() {
            r1 = this;
            float r0 = r1.zoomRatio
            return r0
    }

    public int hashCode() {
            r2 = this;
            float r0 = r2.zoomRatio
            int r0 = java.lang.Float.hashCode(r0)
            int r0 = r0 * 31
            float r1 = r2.minZoomRatio
            int r1 = java.lang.Float.hashCode(r1)
            int r0 = r0 + r1
            int r0 = r0 * 31
            float r1 = r2.maxZoomRatio
            int r1 = java.lang.Float.hashCode(r1)
            int r0 = r0 + r1
            return r0
    }

    public java.lang.String toString() {
            r2 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "ZoomValue(zoomRatio="
            r0.<init>(r1)
            float r1 = r2.zoomRatio
            r0.append(r1)
            java.lang.String r1 = ", minZoomRatio="
            r0.append(r1)
            float r1 = r2.minZoomRatio
            r0.append(r1)
            java.lang.String r1 = ", maxZoomRatio="
            r0.append(r1)
            float r1 = r2.maxZoomRatio
            r0.append(r1)
            r1 = 41
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }
}
