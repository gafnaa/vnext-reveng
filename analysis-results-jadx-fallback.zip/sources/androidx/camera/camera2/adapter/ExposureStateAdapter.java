package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: ExposureStateAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\b\u0010\b\u001a\u00020\tH\u0016J\b\u0010\n\u001a\u00020\u0005H\u0016J\b\u0010\u000b\u001a\u00020\fH\u0016J\u000e\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\u000eH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Landroidx/camera/camera2/adapter/ExposureStateAdapter;", "Landroidx/camera/core/ExposureState;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "exposureCompensation", "", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;I)V", "isExposureCompensationSupported", "", "getExposureCompensationIndex", "getExposureCompensationStep", "Landroid/util/Rational;", "getExposureCompensationRange", "Landroid/util/Range;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ExposureStateAdapter implements androidx.camera.core.ExposureState {
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;
    private final int exposureCompensation;

    public ExposureStateAdapter(androidx.camera.camera2.impl.CameraProperties r2, int r3) {
            r1 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.cameraProperties = r2
            r1.exposureCompensation = r3
            return
    }

    @Override // androidx.camera.core.ExposureState
    public int getExposureCompensationIndex() {
            r1 = this;
            int r0 = r1.exposureCompensation
            return r0
    }

    @Override // androidx.camera.core.ExposureState
    public android.util.Range<java.lang.Integer> getExposureCompensationRange() {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE
            java.lang.String r2 = "CONTROL_AE_COMPENSATION_RANGE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            android.util.Range r0 = (android.util.Range) r0
            if (r0 != 0) goto L19
            android.util.Range r0 = androidx.camera.camera2.adapter.ExposureStateAdapterKt.getEMPTY_RANGE()
        L19:
            return r0
    }

    @Override // androidx.camera.core.ExposureState
    public android.util.Rational getExposureCompensationStep() {
            r3 = this;
            boolean r0 = r3.isExposureCompensationSupported()
            if (r0 != 0) goto Le
            android.util.Rational r0 = android.util.Rational.ZERO
            java.lang.String r1 = "ZERO"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            return r0
        Le:
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP
            java.lang.String r2 = "CONTROL_AE_COMPENSATION_STEP"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            android.util.Rational r0 = (android.util.Rational) r0
            return r0
    }

    @Override // androidx.camera.core.ExposureState
    public boolean isExposureCompensationSupported() {
            r2 = this;
            android.util.Range r0 = r2.getExposureCompensationRange()
            java.lang.Comparable r1 = r0.getLower()
            java.lang.Integer r1 = (java.lang.Integer) r1
            if (r1 != 0) goto Ld
            goto L13
        Ld:
            int r1 = r1.intValue()
            if (r1 == 0) goto L24
        L13:
            java.lang.Comparable r0 = r0.getUpper()
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L1c
            goto L22
        L1c:
            int r0 = r0.intValue()
            if (r0 == 0) goto L24
        L22:
            r0 = 1
            return r0
        L24:
            r0 = 0
            return r0
    }
}
