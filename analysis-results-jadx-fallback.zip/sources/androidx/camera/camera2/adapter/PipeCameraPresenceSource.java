package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: PipeCameraPresenceSource.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \u001a2\u00020\u0001:\u0001\u001aB9\u0012\u0012\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\t0\u0004\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rJ\b\u0010\u0014\u001a\u00020\u0015H\u0014J\b\u0010\u0016\u001a\u00020\u0015H\u0016J\u0014\u0010\u0017\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00190\u00040\u0018H\u0016R\u001a\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001b"}, d2 = {"Landroidx/camera/camera2/adapter/PipeCameraPresenceSource;", "Landroidx/camera/core/impl/AbstractCameraPresenceSource;", "idFlow", "Lkotlinx/coroutines/flow/Flow;", "", "Landroidx/camera/camera2/pipe/CameraId;", "coroutineScope", "Lkotlinx/coroutines/CoroutineScope;", "initialCameraIds", "", "context", "Landroid/content/Context;", "<init>", "(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/CoroutineScope;Ljava/util/List;Landroid/content/Context;)V", "isMonitoring", "Ljava/util/concurrent/atomic/AtomicBoolean;", "flowCollectionJob", "Lkotlinx/coroutines/Job;", "cameraManager", "Landroid/hardware/camera2/CameraManager;", "startMonitoring", "", "stopMonitoring", "fetchData", "Lcom/google/common/util/concurrent/ListenableFuture;", "Landroidx/camera/core/CameraIdentifier;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class PipeCameraPresenceSource extends androidx.camera.core.impl.AbstractCameraPresenceSource {
    public static final androidx.camera.camera2.adapter.PipeCameraPresenceSource.Companion Companion = null;
    private static final java.lang.String TAG = "PipePresenceSrc";
    private final android.hardware.camera2.CameraManager cameraManager;
    private final kotlinx.coroutines.CoroutineScope coroutineScope;
    private kotlinx.coroutines.Job flowCollectionJob;
    private final kotlinx.coroutines.flow.Flow<java.util.List<androidx.camera.camera2.pipe.CameraId>> idFlow;
    private final java.util.concurrent.atomic.AtomicBoolean isMonitoring;

    /* JADX INFO: compiled from: PipeCameraPresenceSource.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Landroidx/camera/camera2/adapter/PipeCameraPresenceSource$Companion;", "", "<init>", "()V", "TAG", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }
    }

    /* JADX INFO: renamed from: androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$2, reason: invalid class name */
    /* JADX INFO: compiled from: PipeCameraPresenceSource.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003H\n"}, d2 = {"<anonymous>", "", "identifiers", "", "Landroidx/camera/core/CameraIdentifier;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$2", f = "PipeCameraPresenceSource.kt", i = {}, l = {84}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<java.util.List<? extends androidx.camera.core.CameraIdentifier>, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ kotlin.jvm.internal.Ref.BooleanRef $isFirstEmission;
        /* synthetic */ java.lang.Object L$0;
        int label;
        final /* synthetic */ androidx.camera.camera2.adapter.PipeCameraPresenceSource this$0;

        AnonymousClass2(androidx.camera.camera2.adapter.PipeCameraPresenceSource r1, kotlin.jvm.internal.Ref.BooleanRef r2, kotlin.coroutines.Continuation<? super androidx.camera.camera2.adapter.PipeCameraPresenceSource.AnonymousClass2> r3) {
                r0 = this;
                r0.this$0 = r1
                r0.$isFirstEmission = r2
                r1 = 2
                r0.<init>(r1, r3)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r4, kotlin.coroutines.Continuation<?> r5) {
                r3 = this;
                androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$2 r0 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$2
                androidx.camera.camera2.adapter.PipeCameraPresenceSource r1 = r3.this$0
                kotlin.jvm.internal.Ref$BooleanRef r2 = r3.$isFirstEmission
                r0.<init>(r1, r2, r5)
                r0.L$0 = r4
                kotlin.coroutines.Continuation r0 = (kotlin.coroutines.Continuation) r0
                return r0
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ java.lang.Object invoke(java.util.List<? extends androidx.camera.core.CameraIdentifier> r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
                r0 = this;
                java.util.List r1 = (java.util.List) r1
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                java.lang.Object r1 = r0.invoke2(r1, r2)
                return r1
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final java.lang.Object invoke2(java.util.List<androidx.camera.core.CameraIdentifier> r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
                r0 = this;
                kotlin.coroutines.Continuation r1 = r0.create(r1, r2)
                androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$2 r1 = (androidx.camera.camera2.adapter.PipeCameraPresenceSource.AnonymousClass2) r1
                kotlin.Unit r2 = kotlin.Unit.INSTANCE
                java.lang.Object r1 = r1.invokeSuspend(r2)
                return r1
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r14) {
                r13 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r13.label
                r2 = 1
                if (r1 == 0) goto L17
                if (r1 != r2) goto Lf
                kotlin.ResultKt.throwOnFailure(r14)
                goto L6a
            Lf:
                java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r14.<init>(r0)
                throw r14
            L17:
                kotlin.ResultKt.throwOnFailure(r14)
                java.lang.Object r14 = r13.L$0
                java.util.List r14 = (java.util.List) r14
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                java.lang.String r3 = "Flow emitted new camera set: "
                r1.<init>(r3)
                r4 = r14
                java.lang.Iterable r4 = (java.lang.Iterable) r4
                r11 = 63
                r12 = 0
                r5 = 0
                r6 = 0
                r7 = 0
                r8 = 0
                r9 = 0
                r10 = 0
                java.lang.String r3 = kotlin.collections.CollectionsKt.joinToString$default(r4, r5, r6, r7, r8, r9, r10, r11, r12)
                r1.append(r3)
                java.lang.String r1 = r1.toString()
                java.lang.String r3 = "PipePresenceSrc"
                android.util.Log.d(r3, r1)
                androidx.camera.camera2.adapter.PipeCameraPresenceSource r1 = r13.this$0
                java.util.concurrent.atomic.AtomicBoolean r1 = androidx.camera.camera2.adapter.PipeCameraPresenceSource.access$isMonitoring$p(r1)
                boolean r1 = r1.get()
                if (r1 == 0) goto L76
                kotlin.jvm.internal.Ref$BooleanRef r1 = r13.$isFirstEmission
                boolean r1 = r1.element
                if (r1 == 0) goto L70
                java.lang.String r14 = "Handling first camera set, triggering fresh query."
                android.util.Log.i(r3, r14)
                androidx.camera.camera2.adapter.PipeCameraPresenceSource r14 = r13.this$0
                com.google.common.util.concurrent.ListenableFuture r14 = r14.fetchData()
                r1 = r13
                kotlin.coroutines.Continuation r1 = (kotlin.coroutines.Continuation) r1
                r13.label = r2
                java.lang.Object r14 = androidx.concurrent.futures.ListenableFutureKt.await(r14, r1)
                if (r14 != r0) goto L6a
                return r0
            L6a:
                kotlin.jvm.internal.Ref$BooleanRef r14 = r13.$isFirstEmission
                r0 = 0
                r14.element = r0
                goto L7f
            L70:
                androidx.camera.camera2.adapter.PipeCameraPresenceSource r0 = r13.this$0
                androidx.camera.camera2.adapter.PipeCameraPresenceSource.access$updateData(r0, r14)
                goto L7f
            L76:
                java.lang.String r14 = "Ignoring camera update because monitoring is stopped."
                int r14 = android.util.Log.d(r3, r14)
                kotlin.coroutines.jvm.internal.Boxing.boxInt(r14)
            L7f:
                kotlin.Unit r14 = kotlin.Unit.INSTANCE
                return r14
        }
    }

    /* JADX INFO: renamed from: androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$3, reason: invalid class name */
    /* JADX INFO: compiled from: PipeCameraPresenceSource.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\u0010\u0000\u001a\u00020\u0001*\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u00030\u00022\u0006\u0010\u0005\u001a\u00020\u0006H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/flow/FlowCollector;", "", "Landroidx/camera/core/CameraIdentifier;", "e", ""}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$3", f = "PipeCameraPresenceSource.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    static final class AnonymousClass3 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function3<kotlinx.coroutines.flow.FlowCollector<? super java.util.List<? extends androidx.camera.core.CameraIdentifier>>, java.lang.Throwable, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        /* synthetic */ java.lang.Object L$0;
        int label;
        final /* synthetic */ androidx.camera.camera2.adapter.PipeCameraPresenceSource this$0;

        AnonymousClass3(androidx.camera.camera2.adapter.PipeCameraPresenceSource r1, kotlin.coroutines.Continuation<? super androidx.camera.camera2.adapter.PipeCameraPresenceSource.AnonymousClass3> r2) {
                r0 = this;
                r0.this$0 = r1
                r1 = 3
                r0.<init>(r1, r2)
                return
        }

        @Override // kotlin.jvm.functions.Function3
        public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.flow.FlowCollector<? super java.util.List<? extends androidx.camera.core.CameraIdentifier>> r1, java.lang.Throwable r2, kotlin.coroutines.Continuation<? super kotlin.Unit> r3) {
                r0 = this;
                kotlinx.coroutines.flow.FlowCollector r1 = (kotlinx.coroutines.flow.FlowCollector) r1
                java.lang.Throwable r2 = (java.lang.Throwable) r2
                kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
                java.lang.Object r1 = r0.invoke2(r1, r2, r3)
                return r1
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final java.lang.Object invoke2(kotlinx.coroutines.flow.FlowCollector<? super java.util.List<androidx.camera.core.CameraIdentifier>> r2, java.lang.Throwable r3, kotlin.coroutines.Continuation<? super kotlin.Unit> r4) {
                r1 = this;
                androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$3 r2 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$3
                androidx.camera.camera2.adapter.PipeCameraPresenceSource r0 = r1.this$0
                r2.<init>(r0, r4)
                r2.L$0 = r3
                kotlin.Unit r3 = kotlin.Unit.INSTANCE
                java.lang.Object r2 = r2.invokeSuspend(r3)
                return r2
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r3) {
                r2 = this;
                kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r0 = r2.label
                if (r0 != 0) goto L33
                kotlin.ResultKt.throwOnFailure(r3)
                java.lang.Object r3 = r2.L$0
                java.lang.Throwable r3 = (java.lang.Throwable) r3
                java.lang.String r0 = "Error in camera ID flow collection."
                java.lang.String r1 = "PipePresenceSrc"
                android.util.Log.e(r1, r0, r3)
                androidx.camera.camera2.adapter.PipeCameraPresenceSource r0 = r2.this$0
                java.util.concurrent.atomic.AtomicBoolean r0 = androidx.camera.camera2.adapter.PipeCameraPresenceSource.access$isMonitoring$p(r0)
                boolean r0 = r0.get()
                if (r0 == 0) goto L27
                androidx.camera.camera2.adapter.PipeCameraPresenceSource r0 = r2.this$0
                androidx.camera.camera2.adapter.PipeCameraPresenceSource.access$updateError(r0, r3)
                goto L30
            L27:
                java.lang.String r3 = "Ignoring error because monitoring is stopped."
                int r3 = android.util.Log.d(r1, r3)
                kotlin.coroutines.jvm.internal.Boxing.boxInt(r3)
            L30:
                kotlin.Unit r3 = kotlin.Unit.INSTANCE
                return r3
            L33:
                java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r3.<init>(r0)
                throw r3
        }
    }

    public static /* synthetic */ java.lang.Object $r8$lambda$pNibnT2Ln7rKug19LH2UnicKFAs(androidx.camera.camera2.adapter.PipeCameraPresenceSource r0, androidx.concurrent.futures.CallbackToFutureAdapter.Completer r1) {
            java.lang.Object r0 = fetchData$lambda$0(r0, r1)
            return r0
    }

    static {
            androidx.camera.camera2.adapter.PipeCameraPresenceSource$Companion r0 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.adapter.PipeCameraPresenceSource.Companion = r0
            return
    }

    public PipeCameraPresenceSource(kotlinx.coroutines.flow.Flow<? extends java.util.List<androidx.camera.camera2.pipe.CameraId>> r2, kotlinx.coroutines.CoroutineScope r3, java.util.List<java.lang.String> r4, android.content.Context r5) {
            r1 = this;
            java.lang.String r0 = "idFlow"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "coroutineScope"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "initialCameraIds"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            r1.<init>(r4)
            r1.idFlow = r2
            r1.coroutineScope = r3
            java.util.concurrent.atomic.AtomicBoolean r2 = new java.util.concurrent.atomic.AtomicBoolean
            r3 = 0
            r2.<init>(r3)
            r1.isMonitoring = r2
            java.lang.String r2 = "camera"
            java.lang.Object r2 = r5.getSystemService(r2)
            java.lang.String r3 = "null cannot be cast to non-null type android.hardware.camera2.CameraManager"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2, r3)
            android.hardware.camera2.CameraManager r2 = (android.hardware.camera2.CameraManager) r2
            r1.cameraManager = r2
            return
    }

    public static final /* synthetic */ android.hardware.camera2.CameraManager access$getCameraManager$p(androidx.camera.camera2.adapter.PipeCameraPresenceSource r0) {
            android.hardware.camera2.CameraManager r0 = r0.cameraManager
            return r0
    }

    public static final /* synthetic */ java.util.concurrent.atomic.AtomicBoolean access$isMonitoring$p(androidx.camera.camera2.adapter.PipeCameraPresenceSource r0) {
            java.util.concurrent.atomic.AtomicBoolean r0 = r0.isMonitoring
            return r0
    }

    public static final /* synthetic */ void access$updateData(androidx.camera.camera2.adapter.PipeCameraPresenceSource r0, java.util.List r1) {
            r0.updateData(r1)
            return
    }

    public static final /* synthetic */ void access$updateError(androidx.camera.camera2.adapter.PipeCameraPresenceSource r0, java.lang.Throwable r1) {
            r0.updateError(r1)
            return
    }

    private static final java.lang.Object fetchData$lambda$0(androidx.camera.camera2.adapter.PipeCameraPresenceSource r7, androidx.concurrent.futures.CallbackToFutureAdapter.Completer r8) {
            java.lang.String r0 = "completer"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            kotlinx.coroutines.CoroutineScope r1 = r7.coroutineScope
            androidx.camera.camera2.adapter.PipeCameraPresenceSource$fetchData$1$1 r0 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$fetchData$1$1
            r2 = 0
            r0.<init>(r7, r8, r2)
            r4 = r0
            kotlin.jvm.functions.Function2 r4 = (kotlin.jvm.functions.Function2) r4
            r5 = 3
            r6 = 0
            r3 = 0
            kotlinx.coroutines.BuildersKt.launch$default(r1, r2, r3, r4, r5, r6)
            java.lang.String r7 = "FetchData for PipeCameraPresence0"
            return r7
    }

    @Override // androidx.camera.core.impl.AbstractCameraPresenceSource, androidx.camera.core.impl.Observable
    public com.google.common.util.concurrent.ListenableFuture<java.util.List<androidx.camera.core.CameraIdentifier>> fetchData() {
            r2 = this;
            androidx.camera.camera2.adapter.PipeCameraPresenceSource$$ExternalSyntheticLambda0 r0 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$$ExternalSyntheticLambda0
            r0.<init>(r2)
            com.google.common.util.concurrent.ListenableFuture r0 = androidx.concurrent.futures.CallbackToFutureAdapter.getFuture(r0)
            java.lang.String r1 = "getFuture(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            return r0
    }

    @Override // androidx.camera.core.impl.AbstractCameraPresenceSource
    protected void startMonitoring() {
            r4 = this;
            java.util.concurrent.atomic.AtomicBoolean r0 = r4.isMonitoring
            r1 = 0
            r2 = 1
            boolean r0 = r0.compareAndSet(r1, r2)
            java.lang.String r1 = "PipePresenceSrc"
            if (r0 != 0) goto L12
            java.lang.String r0 = "Monitoring is already active. Ignoring redundant start call."
            android.util.Log.i(r1, r0)
            return
        L12:
            java.lang.String r0 = "Starting to collect camera ID flow."
            android.util.Log.i(r1, r0)
            kotlinx.coroutines.Job r0 = r4.flowCollectionJob
            r1 = 0
            if (r0 == 0) goto L1f
            kotlinx.coroutines.Job.DefaultImpls.cancel$default(r0, r1, r2, r1)
        L1f:
            kotlin.jvm.internal.Ref$BooleanRef r0 = new kotlin.jvm.internal.Ref$BooleanRef
            r0.<init>()
            r0.element = r2
            kotlinx.coroutines.flow.Flow<java.util.List<androidx.camera.camera2.pipe.CameraId>> r2 = r4.idFlow
            androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$$inlined$map$1 r3 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$$inlined$map$1
            r3.<init>(r2)
            kotlinx.coroutines.flow.Flow r3 = (kotlinx.coroutines.flow.Flow) r3
            androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$2 r2 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$2
            r2.<init>(r4, r0, r1)
            kotlin.jvm.functions.Function2 r2 = (kotlin.jvm.functions.Function2) r2
            kotlinx.coroutines.flow.Flow r0 = kotlinx.coroutines.flow.FlowKt.onEach(r3, r2)
            androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$3 r2 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$startMonitoring$3
            r2.<init>(r4, r1)
            kotlin.jvm.functions.Function3 r2 = (kotlin.jvm.functions.Function3) r2
            kotlinx.coroutines.flow.Flow r0 = kotlinx.coroutines.flow.FlowKt.m3771catch(r0, r2)
            kotlinx.coroutines.CoroutineScope r1 = r4.coroutineScope
            kotlinx.coroutines.Job r0 = kotlinx.coroutines.flow.FlowKt.launchIn(r0, r1)
            r4.flowCollectionJob = r0
            return
    }

    @Override // androidx.camera.core.impl.AbstractCameraPresenceSource
    public void stopMonitoring() {
            r3 = this;
            java.lang.String r0 = "PipePresenceSrc"
            java.lang.String r1 = "Stopping camera ID flow collection."
            android.util.Log.i(r0, r1)
            java.util.concurrent.atomic.AtomicBoolean r0 = r3.isMonitoring
            r1 = 0
            r2 = 1
            boolean r0 = r0.compareAndSet(r2, r1)
            if (r0 != 0) goto L12
            return
        L12:
            kotlinx.coroutines.Job r0 = r3.flowCollectionJob
            r1 = 0
            if (r0 == 0) goto L1a
            kotlinx.coroutines.Job.DefaultImpls.cancel$default(r0, r1, r2, r1)
        L1a:
            r3.flowCollectionJob = r1
            return
    }
}
