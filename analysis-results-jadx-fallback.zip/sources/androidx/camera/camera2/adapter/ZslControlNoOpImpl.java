package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: ZslControl.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\t\b\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0016J\b\u0010\b\u001a\u00020\u0005H\u0016J\u0018\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\nH\u0016J\b\u0010\u0011\u001a\u00020\nH\u0016J\u0010\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\nH\u0016J\b\u0010\u0013\u001a\u00020\nH\u0016J\n\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0016¨\u0006\u0016"}, d2 = {"Landroidx/camera/camera2/adapter/ZslControlNoOpImpl;", "Landroidx/camera/camera2/adapter/ZslControl;", "<init>", "()V", "addZslConfig", "", "sessionConfigBuilder", "Landroidx/camera/core/impl/SessionConfig$Builder;", "clearZslConfig", "isZslSurface", "", "surface", "Landroidx/camera/core/impl/DeferrableSurface;", "sessionConfig", "Landroidx/camera/core/impl/SessionConfig;", "setZslDisabledByUserCaseConfig", "disabled", "isZslDisabledByUserCaseConfig", "setZslDisabledByFlashMode", "isZslDisabledByFlashMode", "dequeueImageFromBuffer", "Landroidx/camera/core/ImageProxy;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ZslControlNoOpImpl implements androidx.camera.camera2.adapter.ZslControl {
    @javax.inject.Inject
    public ZslControlNoOpImpl() {
            r0 = this;
            r0.<init>()
            return
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public void addZslConfig(androidx.camera.core.impl.SessionConfig.Builder r2) {
            r1 = this;
            java.lang.String r0 = "sessionConfigBuilder"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            return
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public void clearZslConfig() {
            r0 = this;
            return
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public androidx.camera.core.ImageProxy dequeueImageFromBuffer() {
            r1 = this;
            r0 = 0
            return r0
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public boolean isZslDisabledByFlashMode() {
            r1 = this;
            r0 = 0
            return r0
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public boolean isZslDisabledByUserCaseConfig() {
            r1 = this;
            r0 = 0
            return r0
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public boolean isZslSurface(androidx.camera.core.impl.DeferrableSurface r2, androidx.camera.core.impl.SessionConfig r3) {
            r1 = this;
            java.lang.String r0 = "surface"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r2 = "sessionConfig"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r2)
            r2 = 0
            return r2
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public void setZslDisabledByFlashMode(boolean r1) {
            r0 = this;
            return
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public void setZslDisabledByUserCaseConfig(boolean r1) {
            r0 = this;
            return
    }
}
