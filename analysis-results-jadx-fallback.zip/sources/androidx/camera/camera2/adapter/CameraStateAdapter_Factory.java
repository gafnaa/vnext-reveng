package androidx.camera.camera2.adapter;

/* JADX INFO: loaded from: classes.dex */
public final class CameraStateAdapter_Factory implements dagger.internal.Factory<androidx.camera.camera2.adapter.CameraStateAdapter> {

    private static final class InstanceHolder {
        static final androidx.camera.camera2.adapter.CameraStateAdapter_Factory INSTANCE = null;

        static {
                androidx.camera.camera2.adapter.CameraStateAdapter_Factory r0 = new androidx.camera.camera2.adapter.CameraStateAdapter_Factory
                r0.<init>()
                androidx.camera.camera2.adapter.CameraStateAdapter_Factory.InstanceHolder.INSTANCE = r0
                return
        }

        private InstanceHolder() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public CameraStateAdapter_Factory() {
            r0 = this;
            r0.<init>()
            return
    }

    public static androidx.camera.camera2.adapter.CameraStateAdapter_Factory create() {
            androidx.camera.camera2.adapter.CameraStateAdapter_Factory r0 = androidx.camera.camera2.adapter.CameraStateAdapter_Factory.InstanceHolder.INSTANCE
            return r0
    }

    public static androidx.camera.camera2.adapter.CameraStateAdapter newInstance() {
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = new androidx.camera.camera2.adapter.CameraStateAdapter
            r0.<init>()
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.adapter.CameraStateAdapter get() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = newInstance()
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r1.get()
            return r0
    }
}
