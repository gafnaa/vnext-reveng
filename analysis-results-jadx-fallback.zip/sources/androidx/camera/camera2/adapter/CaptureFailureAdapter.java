package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CaptureFailureAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0006\u001a\u00020\u0007H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/adapter/CaptureFailureAdapter;", "Landroidx/camera/core/impl/CameraCaptureFailure;", "requestFailure", "Landroidx/camera/camera2/pipe/RequestFailure;", "<init>", "(Landroidx/camera/camera2/pipe/RequestFailure;)V", "getCaptureFailure", "Landroid/hardware/camera2/CaptureFailure;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CaptureFailureAdapter extends androidx.camera.core.impl.CameraCaptureFailure {
    private final androidx.camera.camera2.pipe.RequestFailure requestFailure;

    public CaptureFailureAdapter(androidx.camera.camera2.pipe.RequestFailure r2) {
            r1 = this;
            java.lang.String r0 = "requestFailure"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.core.impl.CameraCaptureFailure$Reason r0 = androidx.camera.core.impl.CameraCaptureFailure.Reason.ERROR
            r1.<init>(r0)
            r1.requestFailure = r2
            return
    }

    @Override // androidx.camera.core.impl.CameraCaptureFailure
    public android.hardware.camera2.CaptureFailure getCaptureFailure() {
            r2 = this;
            androidx.camera.camera2.pipe.RequestFailure r0 = r2.requestFailure
            java.lang.String r1 = "null cannot be cast to non-null type androidx.camera.camera2.pipe.compat.AndroidCaptureFailure"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0, r1)
            androidx.camera.camera2.pipe.compat.AndroidCaptureFailure r0 = (androidx.camera.camera2.pipe.compat.AndroidCaptureFailure) r0
            java.lang.Class<android.hardware.camera2.CaptureFailure> r1 = android.hardware.camera2.CaptureFailure.class
            kotlin.reflect.KClass r1 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r1)
            java.lang.Object r0 = r0.unwrapAs(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            android.hardware.camera2.CaptureFailure r0 = (android.hardware.camera2.CaptureFailure) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureFailure
    public /* bridge */ /* synthetic */ java.lang.Object getCaptureFailure() {
            r1 = this;
            android.hardware.camera2.CaptureFailure r0 = r1.getCaptureFailure()
            return r0
    }
}
