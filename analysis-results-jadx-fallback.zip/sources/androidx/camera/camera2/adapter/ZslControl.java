package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: ZslControl.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0003H&J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH&J\u0010\u0010\r\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\bH&J\b\u0010\u000f\u001a\u00020\bH&J\u0010\u0010\u0010\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\bH&J\b\u0010\u0011\u001a\u00020\bH&J\n\u0010\u0012\u001a\u0004\u0018\u00010\u0013H&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0014À\u0006\u0001"}, d2 = {"Landroidx/camera/camera2/adapter/ZslControl;", "", "addZslConfig", "", "sessionConfigBuilder", "Landroidx/camera/core/impl/SessionConfig$Builder;", "clearZslConfig", "isZslSurface", "", "surface", "Landroidx/camera/core/impl/DeferrableSurface;", "sessionConfig", "Landroidx/camera/core/impl/SessionConfig;", "setZslDisabledByUserCaseConfig", "disabled", "isZslDisabledByUserCaseConfig", "setZslDisabledByFlashMode", "isZslDisabledByFlashMode", "dequeueImageFromBuffer", "Landroidx/camera/core/ImageProxy;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public interface ZslControl {
    void addZslConfig(androidx.camera.core.impl.SessionConfig.Builder r1);

    void clearZslConfig();

    androidx.camera.core.ImageProxy dequeueImageFromBuffer();

    boolean isZslDisabledByFlashMode();

    boolean isZslDisabledByUserCaseConfig();

    boolean isZslSurface(androidx.camera.core.impl.DeferrableSurface r1, androidx.camera.core.impl.SessionConfig r2);

    void setZslDisabledByFlashMode(boolean r1);

    void setZslDisabledByUserCaseConfig(boolean r1);
}
