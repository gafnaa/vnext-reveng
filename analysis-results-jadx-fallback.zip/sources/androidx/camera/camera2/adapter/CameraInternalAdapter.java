package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraInternalAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000\u0098\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u001f\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000e\n\u0000\b\u0007\u0018\u00002\u00020\u0001B9\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r¢\u0006\u0004\b\u000e\u0010\u000fJ\u0015\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001eH\u0000¢\u0006\u0002\b\u001fJ\u000f\u0010 \u001a\u0004\u0018\u00010!H\u0000¢\u0006\u0002\b\"J\u0015\u0010#\u001a\u00020\u001c2\u0006\u0010$\u001a\u00020%H\u0000¢\u0006\u0002\b&J\b\u0010'\u001a\u00020\u001cH\u0016J\b\u0010(\u001a\u00020\u001cH\u0016J\u0010\u0010)\u001a\u00020\u001c2\u0006\u0010*\u001a\u00020\u001eH\u0016J\u0010\u0010+\u001a\u00020\u001c2\u0006\u0010,\u001a\u00020\u001eH\u0016J\u000e\u0010-\u001a\b\u0012\u0004\u0012\u00020/0.H\u0016J\b\u00100\u001a\u00020\u0007H\u0016J\u000e\u00101\u001a\b\u0012\u0004\u0012\u00020302H\u0016J\b\u00104\u001a\u00020\tH\u0016J\u0016\u00105\u001a\u00020\u001c2\f\u00106\u001a\b\u0012\u0004\u0012\u00020807H\u0016J\u0016\u00109\u001a\u00020\u001c2\f\u0010:\u001a\b\u0012\u0004\u0012\u00020807H\u0016J\u0010\u0010;\u001a\u00020\u001c2\u0006\u0010<\u001a\u000208H\u0016J\u0010\u0010=\u001a\u00020\u001c2\u0006\u0010<\u001a\u000208H\u0016J\u0010\u0010>\u001a\u00020\u001c2\u0006\u0010<\u001a\u000208H\u0016J\u0010\u0010?\u001a\u00020\u001c2\u0006\u0010<\u001a\u000208H\u0016J\b\u0010@\u001a\u00020\u0014H\u0016J\u0012\u0010A\u001a\u00020\u001c2\b\u0010B\u001a\u0004\u0018\u00010\u0014H\u0016J\b\u0010C\u001a\u00020\u001cH\u0016J\b\u0010\u0019\u001a\u00020\u001eH\u0016J\b\u0010D\u001a\u00020EH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006F"}, d2 = {"Landroidx/camera/camera2/adapter/CameraInternalAdapter;", "Landroidx/camera/core/impl/CameraInternal;", "config", "Landroidx/camera/camera2/config/CameraConfig;", "useCaseManager", "Landroidx/camera/camera2/impl/UseCaseManager;", "cameraInfo", "Landroidx/camera/core/impl/CameraInfoInternal;", "cameraController", "Landroidx/camera/core/impl/CameraControlInternal;", "threads", "Landroidx/camera/camera2/impl/UseCaseThreads;", "cameraStateAdapter", "Landroidx/camera/camera2/adapter/CameraStateAdapter;", "<init>", "(Landroidx/camera/camera2/config/CameraConfig;Landroidx/camera/camera2/impl/UseCaseManager;Landroidx/camera/core/impl/CameraInfoInternal;Landroidx/camera/core/impl/CameraControlInternal;Landroidx/camera/camera2/impl/UseCaseThreads;Landroidx/camera/camera2/adapter/CameraStateAdapter;)V", "cameraId", "Landroidx/camera/camera2/pipe/CameraId;", "Ljava/lang/String;", "coreCameraConfig", "Landroidx/camera/core/impl/CameraConfig;", "debugId", "", "sessionProcessor", "Landroidx/camera/core/impl/SessionProcessor;", "isRemoved", "Lkotlinx/atomicfu/AtomicBoolean;", "setCameraGraphCreationMode", "", "createImmediately", "", "setCameraGraphCreationMode$camera_camera2", "getDeferredCameraGraphConfig", "Landroidx/camera/camera2/pipe/CameraGraph$Config;", "getDeferredCameraGraphConfig$camera_camera2", "resumeDeferredCameraGraphCreation", "cameraGraph", "Landroidx/camera/camera2/pipe/CameraGraph;", "resumeDeferredCameraGraphCreation$camera_camera2", "open", "close", "setPrimary", "isPrimary", "setActiveResumingMode", "enabled", "release", "Lcom/google/common/util/concurrent/ListenableFuture;", "Ljava/lang/Void;", "getCameraInfoInternal", "getCameraState", "Landroidx/camera/core/impl/Observable;", "Landroidx/camera/core/impl/CameraInternal$State;", "getCameraControlInternal", "attachUseCases", "useCasesToAdd", "", "Landroidx/camera/core/UseCase;", "detachUseCases", "useCasesToRemove", "onUseCaseActive", "useCase", "onUseCaseUpdated", "onUseCaseReset", "onUseCaseInactive", "getExtendedConfig", "setExtendedConfig", "cameraConfig", "onRemoved", "toString", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraInternalAdapter implements androidx.camera.core.impl.CameraInternal {
    private final androidx.camera.core.impl.CameraControlInternal cameraController;
    private final java.lang.String cameraId;
    private final androidx.camera.core.impl.CameraInfoInternal cameraInfo;
    private final androidx.camera.camera2.adapter.CameraStateAdapter cameraStateAdapter;
    private androidx.camera.core.impl.CameraConfig coreCameraConfig;
    private final int debugId;
    private final kotlinx.atomicfu.AtomicBoolean isRemoved;
    private androidx.camera.core.impl.SessionProcessor sessionProcessor;
    private final androidx.camera.camera2.impl.UseCaseThreads threads;
    private final androidx.camera.camera2.impl.UseCaseManager useCaseManager;

    /* JADX INFO: renamed from: androidx.camera.camera2.adapter.CameraInternalAdapter$onRemoved$2, reason: invalid class name */
    /* JADX INFO: compiled from: CameraInternalAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.camera.camera2.adapter.CameraInternalAdapter$onRemoved$2", f = "CameraInternalAdapter.kt", i = {}, l = {161}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;
        final /* synthetic */ androidx.camera.camera2.adapter.CameraInternalAdapter this$0;

        AnonymousClass2(androidx.camera.camera2.adapter.CameraInternalAdapter r1, kotlin.coroutines.Continuation<? super androidx.camera.camera2.adapter.CameraInternalAdapter.AnonymousClass2> r2) {
                r0 = this;
                r0.this$0 = r1
                r1 = 2
                r0.<init>(r1, r2)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r2, kotlin.coroutines.Continuation<?> r3) {
                r1 = this;
                androidx.camera.camera2.adapter.CameraInternalAdapter$onRemoved$2 r2 = new androidx.camera.camera2.adapter.CameraInternalAdapter$onRemoved$2
                androidx.camera.camera2.adapter.CameraInternalAdapter r0 = r1.this$0
                r2.<init>(r0, r3)
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                return r2
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
                r0 = this;
                kotlinx.coroutines.CoroutineScope r1 = (kotlinx.coroutines.CoroutineScope) r1
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                java.lang.Object r1 = r0.invoke2(r1, r2)
                return r1
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final java.lang.Object invoke2(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
                r0 = this;
                kotlin.coroutines.Continuation r1 = r0.create(r1, r2)
                androidx.camera.camera2.adapter.CameraInternalAdapter$onRemoved$2 r1 = (androidx.camera.camera2.adapter.CameraInternalAdapter.AnonymousClass2) r1
                kotlin.Unit r2 = kotlin.Unit.INSTANCE
                java.lang.Object r1 = r1.invokeSuspend(r2)
                return r1
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r4) {
                r3 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r3.label
                r2 = 1
                if (r1 == 0) goto L17
                if (r1 != r2) goto Lf
                kotlin.ResultKt.throwOnFailure(r4)
                goto L35
            Lf:
                java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r4.<init>(r0)
                throw r4
            L17:
                kotlin.ResultKt.throwOnFailure(r4)
                androidx.camera.camera2.adapter.CameraInternalAdapter r4 = r3.this$0
                androidx.camera.camera2.adapter.CameraStateAdapter r4 = androidx.camera.camera2.adapter.CameraInternalAdapter.access$getCameraStateAdapter$p(r4)
                r4.onRemoved()
                androidx.camera.camera2.adapter.CameraInternalAdapter r4 = r3.this$0
                androidx.camera.camera2.impl.UseCaseManager r4 = androidx.camera.camera2.adapter.CameraInternalAdapter.access$getUseCaseManager$p(r4)
                r1 = r3
                kotlin.coroutines.Continuation r1 = (kotlin.coroutines.Continuation) r1
                r3.label = r2
                java.lang.Object r4 = r4.close(r1)
                if (r4 != r0) goto L35
                return r0
            L35:
                kotlin.Unit r4 = kotlin.Unit.INSTANCE
                return r4
        }
    }

    /* JADX INFO: renamed from: androidx.camera.camera2.adapter.CameraInternalAdapter$release$1, reason: invalid class name */
    /* JADX INFO: compiled from: CameraInternalAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.camera.camera2.adapter.CameraInternalAdapter$release$1", f = "CameraInternalAdapter.kt", i = {}, l = {96}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    static final class AnonymousClass1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        int label;
        final /* synthetic */ androidx.camera.camera2.adapter.CameraInternalAdapter this$0;

        AnonymousClass1(androidx.camera.camera2.adapter.CameraInternalAdapter r1, kotlin.coroutines.Continuation<? super androidx.camera.camera2.adapter.CameraInternalAdapter.AnonymousClass1> r2) {
                r0 = this;
                r0.this$0 = r1
                r1 = 2
                r0.<init>(r1, r2)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r2, kotlin.coroutines.Continuation<?> r3) {
                r1 = this;
                androidx.camera.camera2.adapter.CameraInternalAdapter$release$1 r2 = new androidx.camera.camera2.adapter.CameraInternalAdapter$release$1
                androidx.camera.camera2.adapter.CameraInternalAdapter r0 = r1.this$0
                r2.<init>(r0, r3)
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                return r2
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
                r0 = this;
                kotlinx.coroutines.CoroutineScope r1 = (kotlinx.coroutines.CoroutineScope) r1
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                java.lang.Object r1 = r0.invoke2(r1, r2)
                return r1
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final java.lang.Object invoke2(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
                r0 = this;
                kotlin.coroutines.Continuation r1 = r0.create(r1, r2)
                androidx.camera.camera2.adapter.CameraInternalAdapter$release$1 r1 = (androidx.camera.camera2.adapter.CameraInternalAdapter.AnonymousClass1) r1
                kotlin.Unit r2 = kotlin.Unit.INSTANCE
                java.lang.Object r1 = r1.invokeSuspend(r2)
                return r1
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r4) {
                r3 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r3.label
                r2 = 1
                if (r1 == 0) goto L17
                if (r1 != r2) goto Lf
                kotlin.ResultKt.throwOnFailure(r4)
                goto L2c
            Lf:
                java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r4.<init>(r0)
                throw r4
            L17:
                kotlin.ResultKt.throwOnFailure(r4)
                androidx.camera.camera2.adapter.CameraInternalAdapter r4 = r3.this$0
                androidx.camera.camera2.impl.UseCaseManager r4 = androidx.camera.camera2.adapter.CameraInternalAdapter.access$getUseCaseManager$p(r4)
                r1 = r3
                kotlin.coroutines.Continuation r1 = (kotlin.coroutines.Continuation) r1
                r3.label = r2
                java.lang.Object r4 = r4.close(r1)
                if (r4 != r0) goto L2c
                return r0
            L2c:
                androidx.camera.camera2.adapter.CameraInternalAdapter r4 = r3.this$0
                androidx.camera.camera2.impl.UseCaseThreads r4 = androidx.camera.camera2.adapter.CameraInternalAdapter.access$getThreads$p(r4)
                kotlinx.coroutines.CoroutineScope r4 = r4.getScope()
                r0 = 0
                kotlinx.coroutines.CoroutineScopeKt.cancel$default(r4, r0, r2, r0)
                kotlin.Unit r4 = kotlin.Unit.INSTANCE
                return r4
        }
    }

    @javax.inject.Inject
    public CameraInternalAdapter(androidx.camera.camera2.config.CameraConfig r2, androidx.camera.camera2.impl.UseCaseManager r3, androidx.camera.core.impl.CameraInfoInternal r4, androidx.camera.core.impl.CameraControlInternal r5, androidx.camera.camera2.impl.UseCaseThreads r6, androidx.camera.camera2.adapter.CameraStateAdapter r7) {
            r1 = this;
            java.lang.String r0 = "config"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "useCaseManager"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "cameraInfo"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "cameraController"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "threads"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.lang.String r0 = "cameraStateAdapter"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            r1.<init>()
            r1.useCaseManager = r3
            r1.cameraInfo = r4
            r1.cameraController = r5
            r1.threads = r6
            r1.cameraStateAdapter = r7
            java.lang.String r2 = r2.m115getCameraIdDz_R5H8()
            r1.cameraId = r2
            androidx.camera.core.impl.CameraConfig r2 = androidx.camera.core.impl.CameraConfigs.defaultConfig()
            java.lang.String r3 = "defaultConfig(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
            r1.coreCameraConfig = r2
            kotlinx.atomicfu.AtomicInt r2 = androidx.camera.camera2.adapter.CameraInternalAdapterKt.getCameraAdapterIds()
            int r2 = r2.incrementAndGet()
            r1.debugId = r2
            r2 = 0
            kotlinx.atomicfu.AtomicBoolean r2 = kotlinx.atomicfu.AtomicFU.atomic(r2)
            r1.isRemoved = r2
            androidx.camera.camera2.impl.Camera2Logger r2 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r2 = "CXCP"
            boolean r2 = androidx.camera.core.Logger.isDebugEnabled(r2)
            if (r2 == 0) goto L7c
            java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "Created "
            r3.<init>(r4)
            r3.append(r1)
            java.lang.String r4 = " for "
            r3.append(r4)
            java.lang.String r4 = access$getCameraId$p(r1)
            java.lang.String r4 = androidx.camera.camera2.pipe.CameraId.m456toStringimpl(r4)
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            android.util.Log.d(r2, r3)
        L7c:
            return
    }

    public static final /* synthetic */ java.lang.String access$getCameraId$p(androidx.camera.camera2.adapter.CameraInternalAdapter r0) {
            java.lang.String r0 = r0.cameraId
            return r0
    }

    public static final /* synthetic */ androidx.camera.camera2.adapter.CameraStateAdapter access$getCameraStateAdapter$p(androidx.camera.camera2.adapter.CameraInternalAdapter r0) {
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r0.cameraStateAdapter
            return r0
    }

    public static final /* synthetic */ androidx.camera.camera2.impl.UseCaseThreads access$getThreads$p(androidx.camera.camera2.adapter.CameraInternalAdapter r0) {
            androidx.camera.camera2.impl.UseCaseThreads r0 = r0.threads
            return r0
    }

    public static final /* synthetic */ androidx.camera.camera2.impl.UseCaseManager access$getUseCaseManager$p(androidx.camera.camera2.adapter.CameraInternalAdapter r0) {
            androidx.camera.camera2.impl.UseCaseManager r0 = r0.useCaseManager
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public void attachUseCases(java.util.Collection<androidx.camera.core.UseCase> r2) {
            r1 = this;
            java.lang.String r0 = "useCasesToAdd"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            java.lang.Iterable r2 = (java.lang.Iterable) r2
            java.util.List r2 = kotlin.collections.CollectionsKt.toList(r2)
            r0.attach(r2)
            return
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public void close() {
            r3 = this;
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r0)
            if (r0 == 0) goto L22
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r3)
            java.lang.String r2 = "#close"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r0, r1)
        L22:
            return
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public void detachUseCases(java.util.Collection<androidx.camera.core.UseCase> r2) {
            r1 = this;
            java.lang.String r0 = "useCasesToRemove"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            java.lang.Iterable r2 = (java.lang.Iterable) r2
            java.util.List r2 = kotlin.collections.CollectionsKt.toList(r2)
            r0.detach(r2)
            return
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public androidx.camera.core.impl.CameraControlInternal getCameraControlInternal() {
            r1 = this;
            androidx.camera.core.impl.CameraControlInternal r0 = r1.cameraController
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public androidx.camera.core.impl.CameraInfoInternal getCameraInfoInternal() {
            r1 = this;
            androidx.camera.core.impl.CameraInfoInternal r0 = r1.cameraInfo
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public androidx.camera.core.impl.Observable<androidx.camera.core.impl.CameraInternal.State> getCameraState() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r1.cameraStateAdapter
            androidx.camera.core.impl.LiveDataObservable r0 = r0.getCameraInternalState$camera_camera2()
            androidx.camera.core.impl.Observable r0 = (androidx.camera.core.impl.Observable) r0
            return r0
    }

    public final androidx.camera.camera2.pipe.CameraGraph.Config getDeferredCameraGraphConfig$camera_camera2() {
            r1 = this;
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            androidx.camera.camera2.pipe.CameraGraph$Config r0 = r0.getDeferredCameraGraphConfig$camera_camera2()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInternal, androidx.camera.core.Camera
    public androidx.camera.core.impl.CameraConfig getExtendedConfig() {
            r1 = this;
            androidx.camera.core.impl.CameraConfig r0 = r1.coreCameraConfig
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public boolean isRemoved() {
            r1 = this;
            kotlinx.atomicfu.AtomicBoolean r0 = r1.isRemoved
            boolean r0 = r0.getValue()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public void onRemoved() {
            r7 = this;
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r0)
            if (r0 == 0) goto L22
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r7)
            java.lang.String r2 = " received removed signal. Cleaning up."
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r0, r1)
        L22:
            kotlinx.atomicfu.AtomicBoolean r0 = r7.isRemoved
            r1 = 0
            r2 = 1
            boolean r0 = r0.compareAndSet(r1, r2)
            if (r0 == 0) goto L41
            androidx.camera.camera2.impl.UseCaseThreads r0 = r7.threads
            kotlinx.coroutines.CoroutineScope r1 = r0.getScope()
            androidx.camera.camera2.adapter.CameraInternalAdapter$onRemoved$2 r0 = new androidx.camera.camera2.adapter.CameraInternalAdapter$onRemoved$2
            r2 = 0
            r0.<init>(r7, r2)
            r4 = r0
            kotlin.jvm.functions.Function2 r4 = (kotlin.jvm.functions.Function2) r4
            r5 = 3
            r6 = 0
            r3 = 0
            kotlinx.coroutines.BuildersKt.launch$default(r1, r2, r3, r4, r5, r6)
        L41:
            return
    }

    @Override // androidx.camera.core.UseCase.StateChangeCallback
    public void onUseCaseActive(androidx.camera.core.UseCase r2) {
            r1 = this;
            java.lang.String r0 = "useCase"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            r0.activate(r2)
            return
    }

    @Override // androidx.camera.core.UseCase.StateChangeCallback
    public void onUseCaseInactive(androidx.camera.core.UseCase r2) {
            r1 = this;
            java.lang.String r0 = "useCase"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            r0.deactivate(r2)
            return
    }

    @Override // androidx.camera.core.UseCase.StateChangeCallback
    public void onUseCaseReset(androidx.camera.core.UseCase r2) {
            r1 = this;
            java.lang.String r0 = "useCase"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            r0.reset(r2)
            return
    }

    @Override // androidx.camera.core.UseCase.StateChangeCallback
    public void onUseCaseUpdated(androidx.camera.core.UseCase r2) {
            r1 = this;
            java.lang.String r0 = "useCase"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            r0.update(r2)
            return
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public void open() {
            r3 = this;
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r0)
            if (r0 == 0) goto L22
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r3)
            java.lang.String r2 = "#open"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r0, r1)
        L22:
            return
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public com.google.common.util.concurrent.ListenableFuture<java.lang.Void> release() {
            r8 = this;
            androidx.camera.camera2.impl.UseCaseThreads r0 = r8.threads
            kotlinx.coroutines.CoroutineScope r1 = r0.getScope()
            androidx.camera.camera2.adapter.CameraInternalAdapter$release$1 r0 = new androidx.camera.camera2.adapter.CameraInternalAdapter$release$1
            r7 = 0
            r0.<init>(r8, r7)
            r4 = r0
            kotlin.jvm.functions.Function2 r4 = (kotlin.jvm.functions.Function2) r4
            r5 = 3
            r6 = 0
            r2 = 0
            r3 = 0
            kotlinx.coroutines.Job r0 = kotlinx.coroutines.BuildersKt.launch$default(r1, r2, r3, r4, r5, r6)
            r1 = 1
            com.google.common.util.concurrent.ListenableFuture r0 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.asListenableFuture$default(r0, r7, r1, r7)
            return r0
    }

    public final void resumeDeferredCameraGraphCreation$camera_camera2(androidx.camera.camera2.pipe.CameraGraph r2) {
            r1 = this;
            java.lang.String r0 = "cameraGraph"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            r0.resumeDeferredComponentCreation$camera_camera2(r2)
            return
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public void setActiveResumingMode(boolean r2) {
            r1 = this;
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            r0.setActiveResumeMode(r2)
            return
    }

    public final void setCameraGraphCreationMode$camera_camera2(boolean r2) {
            r1 = this;
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            r0.setCameraGraphCreationMode$camera_camera2(r2)
            return
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public void setExtendedConfig(androidx.camera.core.impl.CameraConfig r3) {
            r2 = this;
            if (r3 != 0) goto Lc
            androidx.camera.core.impl.CameraConfig r0 = androidx.camera.core.impl.CameraConfigs.defaultConfig()
            java.lang.String r1 = "defaultConfig(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            goto Ld
        Lc:
            r0 = r3
        Ld:
            r2.coreCameraConfig = r0
            r0 = 0
            if (r3 == 0) goto L16
            androidx.camera.core.impl.SessionProcessor r0 = r3.getSessionProcessor(r0)
        L16:
            r2.sessionProcessor = r0
            androidx.camera.camera2.impl.UseCaseManager r3 = r2.useCaseManager
            r3.setSessionProcessor$camera_camera2(r0)
            return
    }

    @Override // androidx.camera.core.impl.CameraInternal
    public void setPrimary(boolean r2) {
            r1 = this;
            androidx.camera.camera2.impl.UseCaseManager r0 = r1.useCaseManager
            r0.setPrimary(r2)
            return
    }

    public java.lang.String toString() {
            r2 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "CameraInternalAdapter<"
            r0.<init>(r1)
            java.lang.String r1 = r2.cameraId
            java.lang.String r1 = androidx.camera.camera2.pipe.CameraId.m456toStringimpl(r1)
            r0.append(r1)
            r1 = 40
            r0.append(r1)
            int r1 = r2.debugId
            r0.append(r1)
            java.lang.String r1 = ")>"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }
}
