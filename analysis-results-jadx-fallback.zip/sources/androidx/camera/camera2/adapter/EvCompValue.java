package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: EvCompValue.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJ\b\u0010\f\u001a\u00020\u0005H\u0016J\u000e\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007H\u0016J\b\u0010\u000e\u001a\u00020\tH\u0016J\b\u0010\u000f\u001a\u00020\u0003H\u0016J\u0015\u0010\u0010\u001a\u00020\u00002\u0006\u0010\u0011\u001a\u00020\u0005H\u0000¢\u0006\u0002\b\u0012J\t\u0010\u0013\u001a\u00020\u0003HÂ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÂ\u0003J\u000f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007HÂ\u0003J\t\u0010\u0016\u001a\u00020\tHÂ\u0003J7\u0010\u0017\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00072\b\b\u0002\u0010\b\u001a\u00020\tHÆ\u0001J\u0014\u0010\u0018\u001a\u00020\u00032\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aHÖ\u0083\u0004J\n\u0010\u001b\u001a\u00020\u0005HÖ\u0081\u0004J\n\u0010\u001c\u001a\u00020\u001dHÖ\u0081\u0004R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001e"}, d2 = {"Landroidx/camera/camera2/adapter/EvCompValue;", "Landroidx/camera/core/ExposureState;", "supported", "", "index", "", "range", "Landroid/util/Range;", "step", "Landroid/util/Rational;", "<init>", "(ZILandroid/util/Range;Landroid/util/Rational;)V", "getExposureCompensationIndex", "getExposureCompensationRange", "getExposureCompensationStep", "isExposureCompensationSupported", "updateIndex", "newIndex", "updateIndex$camera_camera2", "component1", "component2", "component3", "component4", "copy", "equals", "other", "", "hashCode", "toString", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class EvCompValue implements androidx.camera.core.ExposureState {
    private final int index;
    private final android.util.Range<java.lang.Integer> range;
    private final android.util.Rational step;
    private final boolean supported;

    public EvCompValue(boolean r2, int r3, android.util.Range<java.lang.Integer> r4, android.util.Rational r5) {
            r1 = this;
            java.lang.String r0 = "range"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "step"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            r1.<init>()
            r1.supported = r2
            r1.index = r3
            r1.range = r4
            r1.step = r5
            return
    }

    private final boolean component1() {
            r1 = this;
            boolean r0 = r1.supported
            return r0
    }

    private final int component2() {
            r1 = this;
            int r0 = r1.index
            return r0
    }

    private final android.util.Range<java.lang.Integer> component3() {
            r1 = this;
            android.util.Range<java.lang.Integer> r0 = r1.range
            return r0
    }

    private final android.util.Rational component4() {
            r1 = this;
            android.util.Rational r0 = r1.step
            return r0
    }

    public static /* synthetic */ androidx.camera.camera2.adapter.EvCompValue copy$default(androidx.camera.camera2.adapter.EvCompValue r0, boolean r1, int r2, android.util.Range r3, android.util.Rational r4, int r5, java.lang.Object r6) {
            r6 = r5 & 1
            if (r6 == 0) goto L6
            boolean r1 = r0.supported
        L6:
            r6 = r5 & 2
            if (r6 == 0) goto Lc
            int r2 = r0.index
        Lc:
            r6 = r5 & 4
            if (r6 == 0) goto L12
            android.util.Range<java.lang.Integer> r3 = r0.range
        L12:
            r5 = r5 & 8
            if (r5 == 0) goto L18
            android.util.Rational r4 = r0.step
        L18:
            androidx.camera.camera2.adapter.EvCompValue r0 = r0.copy(r1, r2, r3, r4)
            return r0
    }

    public final androidx.camera.camera2.adapter.EvCompValue copy(boolean r2, int r3, android.util.Range<java.lang.Integer> r4, android.util.Rational r5) {
            r1 = this;
            java.lang.String r0 = "range"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "step"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            androidx.camera.camera2.adapter.EvCompValue r0 = new androidx.camera.camera2.adapter.EvCompValue
            r0.<init>(r2, r3, r4, r5)
            return r0
    }

    public boolean equals(java.lang.Object r5) {
            r4 = this;
            r0 = 1
            if (r4 != r5) goto L4
            return r0
        L4:
            boolean r1 = r5 instanceof androidx.camera.camera2.adapter.EvCompValue
            r2 = 0
            if (r1 != 0) goto La
            return r2
        La:
            androidx.camera.camera2.adapter.EvCompValue r5 = (androidx.camera.camera2.adapter.EvCompValue) r5
            boolean r1 = r4.supported
            boolean r3 = r5.supported
            if (r1 == r3) goto L13
            return r2
        L13:
            int r1 = r4.index
            int r3 = r5.index
            if (r1 == r3) goto L1a
            return r2
        L1a:
            android.util.Range<java.lang.Integer> r1 = r4.range
            android.util.Range<java.lang.Integer> r3 = r5.range
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r3)
            if (r1 != 0) goto L25
            return r2
        L25:
            android.util.Rational r1 = r4.step
            android.util.Rational r5 = r5.step
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)
            if (r5 != 0) goto L30
            return r2
        L30:
            return r0
    }

    @Override // androidx.camera.core.ExposureState
    public int getExposureCompensationIndex() {
            r1 = this;
            int r0 = r1.index
            return r0
    }

    @Override // androidx.camera.core.ExposureState
    public android.util.Range<java.lang.Integer> getExposureCompensationRange() {
            r1 = this;
            android.util.Range<java.lang.Integer> r0 = r1.range
            return r0
    }

    @Override // androidx.camera.core.ExposureState
    public android.util.Rational getExposureCompensationStep() {
            r1 = this;
            android.util.Rational r0 = r1.step
            return r0
    }

    public int hashCode() {
            r2 = this;
            boolean r0 = r2.supported
            int r0 = java.lang.Boolean.hashCode(r0)
            int r0 = r0 * 31
            int r1 = r2.index
            int r1 = java.lang.Integer.hashCode(r1)
            int r0 = r0 + r1
            int r0 = r0 * 31
            android.util.Range<java.lang.Integer> r1 = r2.range
            int r1 = r1.hashCode()
            int r0 = r0 + r1
            int r0 = r0 * 31
            android.util.Rational r1 = r2.step
            int r1 = r1.hashCode()
            int r0 = r0 + r1
            return r0
    }

    @Override // androidx.camera.core.ExposureState
    public boolean isExposureCompensationSupported() {
            r1 = this;
            boolean r0 = r1.supported
            return r0
    }

    public java.lang.String toString() {
            r2 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "EvCompValue(supported="
            r0.<init>(r1)
            boolean r1 = r2.supported
            r0.append(r1)
            java.lang.String r1 = ", index="
            r0.append(r1)
            int r1 = r2.index
            r0.append(r1)
            java.lang.String r1 = ", range="
            r0.append(r1)
            android.util.Range<java.lang.Integer> r1 = r2.range
            r0.append(r1)
            java.lang.String r1 = ", step="
            r0.append(r1)
            android.util.Rational r1 = r2.step
            r0.append(r1)
            r1 = 41
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }

    public final androidx.camera.camera2.adapter.EvCompValue updateIndex$camera_camera2(int r8) {
            r7 = this;
            r5 = 13
            r6 = 0
            r1 = 0
            r3 = 0
            r4 = 0
            r0 = r7
            r2 = r8
            androidx.camera.camera2.adapter.EvCompValue r8 = copy$default(r0, r1, r2, r3, r4, r5, r6)
            return r8
    }
}
