package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraInternalAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0014\u0010\u0000\u001a\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"cameraAdapterIds", "Lkotlinx/atomicfu/AtomicInt;", "getCameraAdapterIds", "()Lkotlinx/atomicfu/AtomicInt;", "camera-camera2"}, k = 2, mv = {2, 1, 0}, xi = 48)
public final class CameraInternalAdapterKt {
    private static final kotlinx.atomicfu.AtomicInt cameraAdapterIds = null;

    static {
            r0 = 0
            kotlinx.atomicfu.AtomicInt r0 = kotlinx.atomicfu.AtomicFU.atomic(r0)
            androidx.camera.camera2.adapter.CameraInternalAdapterKt.cameraAdapterIds = r0
            return
    }

    public static final kotlinx.atomicfu.AtomicInt getCameraAdapterIds() {
            kotlinx.atomicfu.AtomicInt r0 = androidx.camera.camera2.adapter.CameraInternalAdapterKt.cameraAdapterIds
            return r0
    }
}
