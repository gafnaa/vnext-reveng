package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: ZslControl.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u0000 42\u00020\u0001:\u00014B\u0011\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0010\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020&H\u0016J\u0018\u0010'\u001a\u00020\u00152\u0006\u0010(\u001a\u00020\"2\u0006\u0010)\u001a\u00020*H\u0016J\u0010\u0010+\u001a\u00020$2\u0006\u0010,\u001a\u00020\u0015H\u0016J\b\u0010-\u001a\u00020\u0015H\u0016J\u0010\u0010.\u001a\u00020$2\u0006\u0010,\u001a\u00020\u0015H\u0016J\b\u0010\u0016\u001a\u00020\u0015H\u0016J\n\u0010/\u001a\u0004\u0018\u000100H\u0016J\b\u00101\u001a\u00020$H\u0016J\b\u00102\u001a\u00020$H\u0002J\b\u00103\u001a\u00020$H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\b\u001a\u00020\t8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\n\u0010\u000bR\u001c\u0010\u000e\u001a\u00020\u000f8\u0000X\u0081\u0004¢\u0006\u000e\n\u0000\u0012\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u0012\u0010\u0013R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R&\u0010\u0018\u001a\u0004\u0018\u00010\u00198\u0000@\u0000X\u0081\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b\u001a\u0010\u0011\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\u0010\u0010\u001f\u001a\u0004\u0018\u00010 X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010!\u001a\u0004\u0018\u00010\"X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00065"}, d2 = {"Landroidx/camera/camera2/adapter/ZslControlImpl;", "Landroidx/camera/camera2/adapter/ZslControl;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;)V", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "streamConfigurationMap", "Landroid/hardware/camera2/params/StreamConfigurationMap;", "getStreamConfigurationMap", "()Landroid/hardware/camera2/params/StreamConfigurationMap;", "streamConfigurationMap$delegate", "Lkotlin/Lazy;", "zslRingBuffer", "Landroidx/camera/core/internal/utils/ZslRingBuffer;", "getZslRingBuffer$camera_camera2$annotations", "()V", "getZslRingBuffer$camera_camera2", "()Landroidx/camera/core/internal/utils/ZslRingBuffer;", "isZslDisabledByUseCaseConfig", "", "isZslDisabledByFlashMode", "isZslDisabledByQuirks", "reprocessingImageReader", "Landroidx/camera/core/SafeCloseImageReaderProxy;", "getReprocessingImageReader$camera_camera2$annotations", "getReprocessingImageReader$camera_camera2", "()Landroidx/camera/core/SafeCloseImageReaderProxy;", "setReprocessingImageReader$camera_camera2", "(Landroidx/camera/core/SafeCloseImageReaderProxy;)V", "metadataMatchingCaptureCallback", "Landroidx/camera/core/impl/CameraCaptureCallback;", "reprocessingImageDeferrableSurface", "Landroidx/camera/core/impl/DeferrableSurface;", "addZslConfig", "", "sessionConfigBuilder", "Landroidx/camera/core/impl/SessionConfig$Builder;", "isZslSurface", "surface", "sessionConfig", "Landroidx/camera/core/impl/SessionConfig;", "setZslDisabledByUserCaseConfig", "disabled", "isZslDisabledByUserCaseConfig", "setZslDisabledByFlashMode", "dequeueImageFromBuffer", "Landroidx/camera/core/ImageProxy;", "clearZslConfig", "reset", "clearRingBuffer", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ZslControlImpl implements androidx.camera.camera2.adapter.ZslControl {
    public static final androidx.camera.camera2.adapter.ZslControlImpl.Companion Companion = null;
    private static final int FORMAT = 34;
    public static final int MAX_IMAGES = 9;
    public static final int RING_BUFFER_CAPACITY = 3;
    private final androidx.camera.camera2.pipe.CameraMetadata cameraMetadata;
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;
    private boolean isZslDisabledByFlashMode;
    private boolean isZslDisabledByQuirks;
    private boolean isZslDisabledByUseCaseConfig;
    private androidx.camera.core.impl.CameraCaptureCallback metadataMatchingCaptureCallback;
    private androidx.camera.core.impl.DeferrableSurface reprocessingImageDeferrableSurface;
    private androidx.camera.core.SafeCloseImageReaderProxy reprocessingImageReader;
    private final kotlin.Lazy streamConfigurationMap$delegate;
    private final androidx.camera.core.internal.utils.ZslRingBuffer zslRingBuffer;

    /* JADX INFO: compiled from: ZslControl.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\u00020\u00058\u0000X\u0081T¢\u0006\b\n\u0000\u0012\u0004\b\u0007\u0010\u0003R\u0016\u0010\b\u001a\u00020\u00058\u0000X\u0081T¢\u0006\b\n\u0000\u0012\u0004\b\t\u0010\u0003¨\u0006\n"}, d2 = {"Landroidx/camera/camera2/adapter/ZslControlImpl$Companion;", "", "<init>", "()V", "FORMAT", "", "RING_BUFFER_CAPACITY", "getRING_BUFFER_CAPACITY$camera_camera2$annotations", "MAX_IMAGES", "getMAX_IMAGES$camera_camera2$annotations", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public static /* synthetic */ void getMAX_IMAGES$camera_camera2$annotations() {
                return
        }

        public static /* synthetic */ void getRING_BUFFER_CAPACITY$camera_camera2$annotations() {
                return
        }
    }

    public static /* synthetic */ void $r8$lambda$7lfc5XsGJyHuvsU6TFnj5hkeOqY(androidx.camera.core.SafeCloseImageReaderProxy r0) {
            addZslConfig$lambda$6(r0)
            return
    }

    /* JADX INFO: renamed from: $r8$lambda$HjVdnBFbCz6juHI-elcMFwa4YdI, reason: not valid java name */
    public static /* synthetic */ void m81$r8$lambda$HjVdnBFbCz6juHIelcMFwa4YdI(androidx.camera.camera2.adapter.ZslControlImpl r0, androidx.camera.core.impl.ImageReaderProxy r1) {
            addZslConfig$lambda$5(r0, r1)
            return
    }

    public static /* synthetic */ void $r8$lambda$K1SuIs8xKcwXeqIjEU3appq_RmM(androidx.camera.core.SafeCloseImageReaderProxy r0) {
            reset$lambda$0(r0)
            return
    }

    public static /* synthetic */ android.hardware.camera2.params.StreamConfigurationMap $r8$lambda$LKuaWDI4O8yhkS0DoPfPSTmRaJI(androidx.camera.camera2.adapter.ZslControlImpl r0) {
            android.hardware.camera2.params.StreamConfigurationMap r0 = streamConfigurationMap_delegate$lambda$0(r0)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$i5aP0xhWzFmN8Aev1pir-7yn51c, reason: not valid java name */
    public static /* synthetic */ void m82$r8$lambda$i5aP0xhWzFmN8Aev1pir7yn51c(androidx.camera.core.ImageProxy r0) {
            zslRingBuffer$lambda$0(r0)
            return
    }

    static {
            androidx.camera.camera2.adapter.ZslControlImpl$Companion r0 = new androidx.camera.camera2.adapter.ZslControlImpl$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.adapter.ZslControlImpl.Companion = r0
            return
    }

    @javax.inject.Inject
    public ZslControlImpl(androidx.camera.camera2.impl.CameraProperties r3) {
            r2 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r2.<init>()
            r2.cameraProperties = r3
            androidx.camera.camera2.pipe.CameraMetadata r3 = r3.getMetadata()
            r2.cameraMetadata = r3
            androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda0 r3 = new androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda0
            r3.<init>(r2)
            kotlin.Lazy r3 = kotlin.LazyKt.lazy(r3)
            r2.streamConfigurationMap$delegate = r3
            androidx.camera.core.internal.utils.ZslRingBuffer r3 = new androidx.camera.core.internal.utils.ZslRingBuffer
            androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda1 r0 = new androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda1
            r0.<init>()
            r1 = 3
            r3.<init>(r1, r0)
            r2.zslRingBuffer = r3
            androidx.camera.camera2.compat.quirk.DeviceQuirks r3 = androidx.camera.camera2.compat.quirk.DeviceQuirks.INSTANCE
            java.lang.Class<androidx.camera.camera2.compat.quirk.ZslDisablerQuirk> r0 = androidx.camera.camera2.compat.quirk.ZslDisablerQuirk.class
            androidx.camera.core.impl.Quirk r3 = r3.get(r0)
            if (r3 == 0) goto L34
            r3 = 1
            goto L35
        L34:
            r3 = 0
        L35:
            r2.isZslDisabledByQuirks = r3
            return
    }

    private static final void addZslConfig$lambda$5(androidx.camera.camera2.adapter.ZslControlImpl r1, androidx.camera.core.impl.ImageReaderProxy r2) {
            java.lang.String r0 = "reader"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.core.ImageProxy r2 = r2.acquireLatestImage()     // Catch: java.lang.IllegalStateException -> L11
            if (r2 == 0) goto L24
            androidx.camera.core.internal.utils.ZslRingBuffer r1 = r1.zslRingBuffer     // Catch: java.lang.IllegalStateException -> L11
            r1.enqueue(r2)     // Catch: java.lang.IllegalStateException -> L11
            return
        L11:
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isErrorEnabled(r1)
            if (r1 == 0) goto L24
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r2 = "Failed to acquire latest image"
            android.util.Log.e(r1, r2)
        L24:
            return
    }

    private static final void addZslConfig$lambda$6(androidx.camera.core.SafeCloseImageReaderProxy r0) {
            r0.safeClose()
            return
    }

    private final void clearRingBuffer() {
            r2 = this;
            androidx.camera.core.internal.utils.ZslRingBuffer r0 = r2.zslRingBuffer
        L2:
            boolean r1 = r0.isEmpty()
            if (r1 != 0) goto L12
            java.lang.Object r1 = r0.dequeue()
            androidx.camera.core.ImageProxy r1 = (androidx.camera.core.ImageProxy) r1
            r1.close()
            goto L2
        L12:
            return
    }

    public static /* synthetic */ void getReprocessingImageReader$camera_camera2$annotations() {
            return
    }

    private final android.hardware.camera2.params.StreamConfigurationMap getStreamConfigurationMap() {
            r1 = this;
            kotlin.Lazy r0 = r1.streamConfigurationMap$delegate
            java.lang.Object r0 = r0.getValue()
            android.hardware.camera2.params.StreamConfigurationMap r0 = (android.hardware.camera2.params.StreamConfigurationMap) r0
            return r0
    }

    public static /* synthetic */ void getZslRingBuffer$camera_camera2$annotations() {
            return
    }

    private final void reset() {
            r6 = this;
            androidx.camera.core.impl.DeferrableSurface r0 = r6.reprocessingImageDeferrableSurface
            if (r0 == 0) goto L25
            androidx.camera.core.SafeCloseImageReaderProxy r1 = r6.reprocessingImageReader
            r2 = 0
            if (r1 == 0) goto L20
            com.google.common.util.concurrent.ListenableFuture r3 = r0.getTerminationFuture()
            androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda4 r4 = new androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda4
            r4.<init>(r1)
            java.util.concurrent.ScheduledExecutorService r5 = androidx.camera.core.impl.utils.executor.CameraXExecutors.mainThreadExecutor()
            java.util.concurrent.Executor r5 = (java.util.concurrent.Executor) r5
            r3.addListener(r4, r5)
            r1.clearOnImageAvailableListener()
            r6.reprocessingImageReader = r2
        L20:
            r0.close()
            r6.reprocessingImageDeferrableSurface = r2
        L25:
            r6.clearRingBuffer()
            return
    }

    private static final void reset$lambda$0(androidx.camera.core.SafeCloseImageReaderProxy r0) {
            r0.safeClose()
            return
    }

    private static final android.hardware.camera2.params.StreamConfigurationMap streamConfigurationMap_delegate$lambda$0(androidx.camera.camera2.adapter.ZslControlImpl r2) {
            androidx.camera.camera2.pipe.CameraMetadata r2 = r2.cameraMetadata
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP
            java.lang.String r1 = "SCALER_STREAM_CONFIGURATION_MAP"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r2 = r2.get(r0)
            if (r2 == 0) goto L12
            android.hardware.camera2.params.StreamConfigurationMap r2 = (android.hardware.camera2.params.StreamConfigurationMap) r2
            return r2
        L12:
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException
            java.lang.String r0 = "Required value was null."
            java.lang.String r0 = r0.toString()
            r2.<init>(r0)
            throw r2
    }

    private static final void zslRingBuffer$lambda$0(androidx.camera.core.ImageProxy r1) {
            java.lang.String r0 = "imageProxy"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            r1.close()
            return
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public void addZslConfig(androidx.camera.core.impl.SessionConfig.Builder r9) {
            r8 = this;
            java.lang.String r0 = "sessionConfigBuilder"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            r8.reset()
            boolean r0 = r8.isZslDisabledByUseCaseConfig
            r1 = 1
            if (r0 == 0) goto L11
            r9.setTemplateType(r1)
            return
        L11:
            boolean r0 = r8.isZslDisabledByQuirks
            if (r0 == 0) goto L19
            r9.setTemplateType(r1)
            return
        L19:
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.pipe.CameraMetadata r2 = r8.cameraMetadata
            boolean r0 = r0.getSupportsPrivateReprocessing(r2)
            java.lang.String r2 = "CXCP"
            if (r0 != 0) goto L3a
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r0 = androidx.camera.core.Logger.isInfoEnabled(r2)
            if (r0 == 0) goto L36
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r2 = "ZslControlImpl: Private reprocessing isn't supported"
            android.util.Log.i(r0, r2)
        L36:
            r9.setTemplateType(r1)
            return
        L3a:
            android.hardware.camera2.params.StreamConfigurationMap r0 = r8.getStreamConfigurationMap()
            r1 = 34
            android.util.Size[] r0 = r0.getInputSizes(r1)
            java.lang.String r3 = "getInputSizes(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r3)
            java.lang.Object[] r0 = (java.lang.Object[]) r0
            java.util.List r0 = kotlin.collections.ArraysKt.toList(r0)
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.Iterator r0 = r0.iterator()
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L167
            java.lang.Object r3 = r0.next()
            boolean r4 = r0.hasNext()
            if (r4 != 0) goto L66
            goto L88
        L66:
            r4 = r3
            android.util.Size r4 = (android.util.Size) r4
            kotlin.jvm.internal.Intrinsics.checkNotNull(r4)
            int r4 = androidx.camera.camera2.impl.SizesKt.area(r4)
        L70:
            java.lang.Object r5 = r0.next()
            r6 = r5
            android.util.Size r6 = (android.util.Size) r6
            kotlin.jvm.internal.Intrinsics.checkNotNull(r6)
            int r6 = androidx.camera.camera2.impl.SizesKt.area(r6)
            if (r4 >= r6) goto L82
            r3 = r5
            r4 = r6
        L82:
            boolean r5 = r0.hasNext()
            if (r5 != 0) goto L70
        L88:
            android.util.Size r3 = (android.util.Size) r3
            if (r3 != 0) goto L9e
            androidx.camera.camera2.impl.Camera2Logger r9 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r9 = androidx.camera.core.Logger.isWarnEnabled(r2)
            if (r9 == 0) goto Le1
            java.lang.String r9 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r0 = "ZslControlImpl: Unable to find a supported size for ZSL"
            android.util.Log.w(r9, r0)
            return
        L9e:
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r2)
            if (r0 == 0) goto Lbb
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r5 = "ZslControlImpl: Selected ZSL size: "
            r4.<init>(r5)
            r4.append(r3)
            java.lang.String r4 = r4.toString()
            android.util.Log.d(r0, r4)
        Lbb:
            android.hardware.camera2.params.StreamConfigurationMap r0 = r8.getStreamConfigurationMap()
            int[] r0 = r0.getValidOutputFormatsForInput(r1)
            java.lang.String r4 = "getValidOutputFormatsForInput(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r4)
            r4 = 256(0x100, float:3.59E-43)
            boolean r0 = kotlin.collections.ArraysKt.contains(r0, r4)
            if (r0 != 0) goto Le2
            androidx.camera.camera2.impl.Camera2Logger r9 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r9 = androidx.camera.core.Logger.isWarnEnabled(r2)
            if (r9 == 0) goto Le1
            java.lang.String r9 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r0 = "ZslControlImpl: JPEG isn't valid output for ZSL format"
            android.util.Log.w(r9, r0)
        Le1:
            return
        Le2:
            androidx.camera.core.MetadataImageReader r0 = new androidx.camera.core.MetadataImageReader
            int r2 = r3.getWidth()
            int r3 = r3.getHeight()
            r4 = 9
            r0.<init>(r2, r3, r1, r4)
            androidx.camera.core.impl.CameraCaptureCallback r2 = r0.getCameraCaptureCallback()
            java.lang.String r3 = "getCameraCaptureCallback(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
            androidx.camera.core.SafeCloseImageReaderProxy r3 = new androidx.camera.core.SafeCloseImageReaderProxy
            r4 = r0
            androidx.camera.core.impl.ImageReaderProxy r4 = (androidx.camera.core.impl.ImageReaderProxy) r4
            r3.<init>(r4)
            androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda2 r4 = new androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda2
            r4.<init>(r8)
            java.util.concurrent.Executor r5 = androidx.camera.core.impl.utils.executor.CameraXExecutors.ioExecutor()
            r0.setOnImageAvailableListener(r4, r5)
            androidx.camera.core.impl.ImmediateSurface r0 = new androidx.camera.core.impl.ImmediateSurface
            android.view.Surface r4 = r3.getSurface()
            if (r4 == 0) goto L15b
            android.util.Size r5 = new android.util.Size
            int r6 = r3.getWidth()
            int r7 = r3.getHeight()
            r5.<init>(r6, r7)
            r0.<init>(r4, r5, r1)
            com.google.common.util.concurrent.ListenableFuture r1 = r0.getTerminationFuture()
            androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda3 r4 = new androidx.camera.camera2.adapter.ZslControlImpl$$ExternalSyntheticLambda3
            r4.<init>(r3)
            java.util.concurrent.ScheduledExecutorService r5 = androidx.camera.core.impl.utils.executor.CameraXExecutors.mainThreadExecutor()
            java.util.concurrent.Executor r5 = (java.util.concurrent.Executor) r5
            r1.addListener(r4, r5)
            androidx.camera.core.impl.DeferrableSurface r0 = (androidx.camera.core.impl.DeferrableSurface) r0
            r9.addSurface(r0)
            r9.addCameraCaptureCallback(r2)
            android.hardware.camera2.params.InputConfiguration r1 = new android.hardware.camera2.params.InputConfiguration
            int r4 = r3.getWidth()
            int r5 = r3.getHeight()
            int r6 = r3.getImageFormat()
            r1.<init>(r4, r5, r6)
            r9.setInputConfiguration(r1)
            r8.metadataMatchingCaptureCallback = r2
            r8.reprocessingImageReader = r3
            r8.reprocessingImageDeferrableSurface = r0
            return
        L15b:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r0 = "Required value was null."
            java.lang.String r0 = r0.toString()
            r9.<init>(r0)
            throw r9
        L167:
            java.util.NoSuchElementException r9 = new java.util.NoSuchElementException
            r9.<init>()
            throw r9
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public void clearZslConfig() {
            r0 = this;
            r0.reset()
            return
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public androidx.camera.core.ImageProxy dequeueImageFromBuffer() {
            r2 = this;
            androidx.camera.core.internal.utils.ZslRingBuffer r0 = r2.zslRingBuffer     // Catch: java.util.NoSuchElementException -> L9
            java.lang.Object r0 = r0.dequeue()     // Catch: java.util.NoSuchElementException -> L9
            androidx.camera.core.ImageProxy r0 = (androidx.camera.core.ImageProxy) r0     // Catch: java.util.NoSuchElementException -> L9
            return r0
        L9:
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isWarnEnabled(r0)
            if (r0 == 0) goto L1c
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r1 = "ZslControlImpl#dequeueImageFromBuffer: No such element"
            android.util.Log.w(r0, r1)
        L1c:
            r0 = 0
            return r0
    }

    public final androidx.camera.core.SafeCloseImageReaderProxy getReprocessingImageReader$camera_camera2() {
            r1 = this;
            androidx.camera.core.SafeCloseImageReaderProxy r0 = r1.reprocessingImageReader
            return r0
    }

    public final androidx.camera.core.internal.utils.ZslRingBuffer getZslRingBuffer$camera_camera2() {
            r1 = this;
            androidx.camera.core.internal.utils.ZslRingBuffer r0 = r1.zslRingBuffer
            return r0
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public boolean isZslDisabledByFlashMode() {
            r1 = this;
            boolean r0 = r1.isZslDisabledByFlashMode
            return r0
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public boolean isZslDisabledByUserCaseConfig() {
            r1 = this;
            boolean r0 = r1.isZslDisabledByUseCaseConfig
            return r0
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public boolean isZslSurface(androidx.camera.core.impl.DeferrableSurface r3, androidx.camera.core.impl.SessionConfig r4) {
            r2 = this;
            java.lang.String r0 = "surface"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "sessionConfig"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            android.hardware.camera2.params.InputConfiguration r4 = r4.getInputConfiguration()
            if (r4 == 0) goto L38
            int r0 = r3.getPrescribedStreamFormat()
            int r1 = r4.getFormat()
            if (r0 != r1) goto L38
            android.util.Size r0 = r3.getPrescribedSize()
            int r0 = r0.getWidth()
            int r1 = r4.getWidth()
            if (r0 != r1) goto L38
            android.util.Size r3 = r3.getPrescribedSize()
            int r3 = r3.getHeight()
            int r4 = r4.getHeight()
            if (r3 != r4) goto L38
            r3 = 1
            return r3
        L38:
            r3 = 0
            return r3
    }

    public final void setReprocessingImageReader$camera_camera2(androidx.camera.core.SafeCloseImageReaderProxy r1) {
            r0 = this;
            r0.reprocessingImageReader = r1
            return
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public void setZslDisabledByFlashMode(boolean r1) {
            r0 = this;
            r0.isZslDisabledByFlashMode = r1
            return
    }

    @Override // androidx.camera.camera2.adapter.ZslControl
    public void setZslDisabledByUserCaseConfig(boolean r2) {
            r1 = this;
            boolean r0 = r1.isZslDisabledByUseCaseConfig
            if (r0 == r2) goto L9
            if (r2 == 0) goto L9
            r1.clearRingBuffer()
        L9:
            r1.isZslDisabledByUseCaseConfig = r2
            return
    }
}
