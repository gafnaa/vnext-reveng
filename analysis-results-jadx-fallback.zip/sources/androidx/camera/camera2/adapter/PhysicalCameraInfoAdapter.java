package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: PhysicalCameraInfoAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u008c\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J\b\u0010\u000f\u001a\u00020\u0010H\u0016J\u0010\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0010H\u0016J\b\u0010\u0012\u001a\u00020\u0013H\u0016J\u000e\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00100\u0015H\u0016J\u000e\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00170\u0015H\u0016J\b\u0010\u0018\u001a\u00020\u0019H\u0016J\u000e\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001b0\u0015H\u0016J\b\u0010\u001c\u001a\u00020\u001dH\u0016J\b\u0010\u001e\u001a\u00020\u001fH\u0016J\b\u0010 \u001a\u00020\u0010H\u0016J\b\u0010!\u001a\u00020\"H\u0016J\u0010\u0010#\u001a\u00020\u00132\u0006\u0010$\u001a\u00020%H\u0016J\b\u0010&\u001a\u00020\u0013H\u0017J\u0014\u0010'\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00100)0(H\u0016J\b\u0010*\u001a\u00020\u0013H\u0016J\b\u0010+\u001a\u00020\u0013H\u0016J\u001c\u0010,\u001a\b\u0012\u0004\u0012\u00020-0(2\f\u0010.\u001a\b\u0012\u0004\u0012\u00020-0(H\u0016J\u000e\u0010/\u001a\b\u0012\u0004\u0012\u00020\u00010(H\u0016J\b\u00100\u001a\u000201H\u0016J'\u00102\u001a\u0004\u0018\u0001H3\"\b\b\u0000\u00103*\u0002042\f\u00105\u001a\b\u0012\u0004\u0012\u0002H306H\u0017¢\u0006\u0002\u00107J\u0010\u00108\u001a\u00020\u00102\u0006\u00109\u001a\u00020\u0010H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R!\u0010\u0007\u001a\u00020\b8@X\u0081\u0084\u0002¢\u0006\u0012\n\u0004\b\r\u0010\u000e\u0012\u0004\b\t\u0010\n\u001a\u0004\b\u000b\u0010\f¨\u0006:"}, d2 = {"Landroidx/camera/camera2/adapter/PhysicalCameraInfoAdapter;", "Landroidx/camera/core/CameraInfo;", "Landroidx/camera/camera2/pipe/UnsafeWrapper;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;)V", "camera2CameraInfo", "Landroidx/camera/camera2/interop/Camera2CameraInfo;", "getCamera2CameraInfo$camera_camera2$annotations", "()V", "getCamera2CameraInfo$camera_camera2", "()Landroidx/camera/camera2/interop/Camera2CameraInfo;", "camera2CameraInfo$delegate", "Lkotlin/Lazy;", "getSensorRotationDegrees", "", "relativeRotation", "hasFlashUnit", "", "getTorchState", "Landroidx/lifecycle/LiveData;", "getZoomState", "Landroidx/camera/core/ZoomState;", "getExposureState", "Landroidx/camera/core/ExposureState;", "getCameraState", "Landroidx/camera/core/CameraState;", "getImplementationType", "", "getCameraSelector", "Landroidx/camera/core/CameraSelector;", "getLensFacing", "getIntrinsicZoomRatio", "", "isFocusMeteringSupported", "action", "Landroidx/camera/core/FocusMeteringAction;", "isZslSupported", "getSupportedFrameRateRanges", "", "Landroid/util/Range;", "isLogicalMultiCameraSupported", "isPrivateReprocessingSupported", "querySupportedDynamicRanges", "Landroidx/camera/core/DynamicRange;", "candidateDynamicRanges", "getPhysicalCameraInfos", "getCameraIdentifier", "Landroidx/camera/core/CameraIdentifier;", "unwrapAs", "T", "", "type", "Lkotlin/reflect/KClass;", "(Lkotlin/reflect/KClass;)Ljava/lang/Object;", "getCameraSelectorLensFacing", "lensFacingInt", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class PhysicalCameraInfoAdapter implements androidx.camera.core.CameraInfo, androidx.camera.camera2.pipe.UnsafeWrapper {
    private final kotlin.Lazy camera2CameraInfo$delegate;
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;

    public static /* synthetic */ androidx.camera.camera2.interop.Camera2CameraInfo $r8$lambda$3ILLdl5fLYeNNpKoQbn0VSgRxXw(androidx.camera.camera2.adapter.PhysicalCameraInfoAdapter r0) {
            androidx.camera.camera2.interop.Camera2CameraInfo r0 = camera2CameraInfo_delegate$lambda$0(r0)
            return r0
    }

    public PhysicalCameraInfoAdapter(androidx.camera.camera2.impl.CameraProperties r2) {
            r1 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.cameraProperties = r2
            androidx.camera.camera2.adapter.PhysicalCameraInfoAdapter$$ExternalSyntheticLambda0 r2 = new androidx.camera.camera2.adapter.PhysicalCameraInfoAdapter$$ExternalSyntheticLambda0
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.camera2CameraInfo$delegate = r2
            return
    }

    private static final androidx.camera.camera2.interop.Camera2CameraInfo camera2CameraInfo_delegate$lambda$0(androidx.camera.camera2.adapter.PhysicalCameraInfoAdapter r1) {
            androidx.camera.camera2.interop.Camera2CameraInfo$Companion r0 = androidx.camera.camera2.interop.Camera2CameraInfo.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r1.cameraProperties
            androidx.camera.camera2.interop.Camera2CameraInfo r1 = r0.create(r1)
            return r1
    }

    public static /* synthetic */ void getCamera2CameraInfo$camera_camera2$annotations() {
            return
    }

    private final int getCameraSelectorLensFacing(int r4) {
            r3 = this;
            if (r4 == 0) goto L23
            r0 = 1
            if (r4 == r0) goto L22
            r0 = 2
            if (r4 != r0) goto L9
            return r0
        L9:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "The specified lens facing integer "
            r1.<init>(r2)
            r1.append(r4)
            java.lang.String r4 = " can not be recognized."
            r1.append(r4)
            java.lang.String r4 = r1.toString()
            r0.<init>(r4)
            throw r0
        L22:
            return r0
        L23:
            r4 = 0
            return r4
    }

    public final androidx.camera.camera2.interop.Camera2CameraInfo getCamera2CameraInfo$camera_camera2() {
            r1 = this;
            kotlin.Lazy r0 = r1.camera2CameraInfo$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.camera.camera2.interop.Camera2CameraInfo r0 = (androidx.camera.camera2.interop.Camera2CameraInfo) r0
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.camera.core.CameraIdentifier getCameraIdentifier() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.camera.core.CameraSelector getCameraSelector() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.lifecycle.LiveData<androidx.camera.core.CameraState> getCameraState() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.camera.core.ExposureState getExposureState() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public java.lang.String getImplementationType() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public float getIntrinsicZoomRatio() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public int getLensFacing() {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.LENS_FACING
            java.lang.String r2 = "LENS_FACING"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            int r0 = r3.getCameraSelectorLensFacing(r0)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public java.util.Set<androidx.camera.core.CameraInfo> getPhysicalCameraInfos() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public int getSensorRotationDegrees() {
            r1 = this;
            r0 = 0
            int r0 = r1.getSensorRotationDegrees(r0)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public int getSensorRotationDegrees(int r4) {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.SENSOR_ORIENTATION
            java.lang.String r2 = "SENSOR_ORIENTATION"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            int r4 = androidx.camera.core.impl.utils.CameraOrientationUtil.surfaceRotationToDegrees(r4)
            int r1 = r3.getLensFacing()
            r2 = 1
            if (r2 != r1) goto L26
            goto L27
        L26:
            r2 = 0
        L27:
            int r4 = androidx.camera.core.impl.utils.CameraOrientationUtil.getRelativeImageRotation(r4, r0, r2)
            return r4
    }

    @Override // androidx.camera.core.CameraInfo
    public java.util.Set<android.util.Range<java.lang.Integer>> getSupportedFrameRateRanges() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.lifecycle.LiveData<java.lang.Integer> getTorchState() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.lifecycle.LiveData<androidx.camera.core.ZoomState> getZoomState() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean hasFlashUnit() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isFocusMeteringSupported(androidx.camera.core.FocusMeteringAction r2) {
            r1 = this;
            java.lang.String r0 = "action"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.UnsupportedOperationException r2 = new java.lang.UnsupportedOperationException
            java.lang.String r0 = "Physical camera doesn't support this function"
            r2.<init>(r0)
            throw r2
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isLogicalMultiCameraSupported() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isPrivateReprocessingSupported() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isZslSupported() {
            r2 = this;
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Physical camera doesn't support this function"
            r0.<init>(r1)
            throw r0
    }

    @Override // androidx.camera.core.CameraInfo
    public java.util.Set<androidx.camera.core.DynamicRange> querySupportedDynamicRanges(java.util.Set<androidx.camera.core.DynamicRange> r2) {
            r1 = this;
            java.lang.String r0 = "candidateDynamicRanges"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.UnsupportedOperationException r2 = new java.lang.UnsupportedOperationException
            java.lang.String r0 = "Physical camera doesn't support this function"
            r2.<init>(r0)
            throw r2
    }

    @Override // androidx.camera.camera2.pipe.UnsafeWrapper
    public <T> T unwrapAs(kotlin.reflect.KClass<T> r3) {
            r2 = this;
            java.lang.String r0 = "type"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.Class<androidx.camera.camera2.interop.Camera2CameraInfo> r0 = androidx.camera.camera2.interop.Camera2CameraInfo.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            java.lang.String r1 = "null cannot be cast to non-null type T of androidx.camera.camera2.adapter.PhysicalCameraInfoAdapter.unwrapAs"
            if (r0 == 0) goto L1d
            androidx.camera.camera2.interop.Camera2CameraInfo r3 = r2.getCamera2CameraInfo$camera_camera2()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r1)
            java.lang.Object r3 = (java.lang.Object) r3
            return r3
        L1d:
            java.lang.Class<androidx.camera.camera2.impl.CameraProperties> r0 = androidx.camera.camera2.impl.CameraProperties.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r0 == 0) goto L31
            androidx.camera.camera2.impl.CameraProperties r3 = r2.cameraProperties
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r1)
            java.lang.Object r3 = (java.lang.Object) r3
            return r3
        L31:
            java.lang.Class<android.hardware.camera2.CameraMetadata> r0 = android.hardware.camera2.CameraMetadata.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r0 == 0) goto L49
            androidx.camera.camera2.impl.CameraProperties r3 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r3 = r3.getMetadata()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r1)
            java.lang.Object r3 = (java.lang.Object) r3
            return r3
        L49:
            androidx.camera.camera2.impl.CameraProperties r0 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            java.lang.Object r3 = r0.unwrapAs(r3)
            return r3
    }
}
