package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\u0018\u00002\u00020\u0001:\u0004\u000e\u000f\u0010\u0011B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0018\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0017R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Landroidx/camera/camera2/adapter/CameraUseCaseAdapter;", "Landroidx/camera/core/impl/UseCaseConfigFactory;", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "displayInfoManager", "Landroidx/camera/camera2/impl/DisplayInfoManager;", "getConfig", "Landroidx/camera/core/impl/Config;", "captureType", "Landroidx/camera/core/impl/UseCaseConfigFactory$CaptureType;", "captureMode", "", "DefaultCaptureOptionsUnpacker", "ImageCaptureOptionUnpacker", "DefaultSessionOptionsUnpacker", "CaptureCallbackContainer", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraUseCaseAdapter implements androidx.camera.core.impl.UseCaseConfigFactory {
    private final androidx.camera.camera2.impl.DisplayInfoManager displayInfoManager;

    /* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0000\u0018\u0000 \b2\u00020\u0001:\u0001\bB\u0011\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\t"}, d2 = {"Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$CaptureCallbackContainer;", "Landroidx/camera/core/impl/CameraCaptureCallback;", "captureCallback", "Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;", "<init>", "(Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;)V", "getCaptureCallback", "()Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class CaptureCallbackContainer extends androidx.camera.core.impl.CameraCaptureCallback {
        public static final androidx.camera.camera2.adapter.CameraUseCaseAdapter.CaptureCallbackContainer.Companion Companion = null;
        private final android.hardware.camera2.CameraCaptureSession.CaptureCallback captureCallback;

        /* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
        @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$CaptureCallbackContainer$Companion;", "", "<init>", "()V", "create", "Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$CaptureCallbackContainer;", "captureCallback", "Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
        public static final class Companion {
            private Companion() {
                    r0 = this;
                    r0.<init>()
                    return
            }

            public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                    r0 = this;
                    r0.<init>()
                    return
            }

            public final androidx.camera.camera2.adapter.CameraUseCaseAdapter.CaptureCallbackContainer create(android.hardware.camera2.CameraCaptureSession.CaptureCallback r3) {
                    r2 = this;
                    java.lang.String r0 = "captureCallback"
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                    androidx.camera.camera2.adapter.CameraUseCaseAdapter$CaptureCallbackContainer r0 = new androidx.camera.camera2.adapter.CameraUseCaseAdapter$CaptureCallbackContainer
                    r1 = 0
                    r0.<init>(r3, r1)
                    return r0
            }
        }

        static {
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$CaptureCallbackContainer$Companion r0 = new androidx.camera.camera2.adapter.CameraUseCaseAdapter$CaptureCallbackContainer$Companion
                r1 = 0
                r0.<init>(r1)
                androidx.camera.camera2.adapter.CameraUseCaseAdapter.CaptureCallbackContainer.Companion = r0
                return
        }

        private CaptureCallbackContainer(android.hardware.camera2.CameraCaptureSession.CaptureCallback r1) {
                r0 = this;
                r0.<init>()
                r0.captureCallback = r1
                return
        }

        public /* synthetic */ CaptureCallbackContainer(android.hardware.camera2.CameraCaptureSession.CaptureCallback r1, kotlin.jvm.internal.DefaultConstructorMarker r2) {
                r0 = this;
                r0.<init>(r1)
                return
        }

        public final android.hardware.camera2.CameraCaptureSession.CaptureCallback getCaptureCallback() {
                r1 = this;
                android.hardware.camera2.CameraCaptureSession$CaptureCallback r0 = r1.captureCallback
                return r0
        }
    }

    /* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0016\u0018\u0000 \n2\u00020\u0001:\u0001\nB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u001c\u0010\u0004\u001a\u00020\u00052\n\u0010\u0006\u001a\u0006\u0012\u0002\b\u00030\u00072\u0006\u0010\b\u001a\u00020\tH\u0017¨\u0006\u000b"}, d2 = {"Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker;", "Landroidx/camera/core/impl/CaptureConfig$OptionUnpacker;", "<init>", "()V", "unpack", "", "config", "Landroidx/camera/core/impl/UseCaseConfig;", "builder", "Landroidx/camera/core/impl/CaptureConfig$Builder;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static class DefaultCaptureOptionsUnpacker implements androidx.camera.core.impl.CaptureConfig.OptionUnpacker {
        public static final androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker.Companion Companion = null;
        private static final androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker INSTANCE = null;

        /* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
        @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker$Companion;", "", "<init>", "()V", "INSTANCE", "Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker;", "getINSTANCE", "()Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
        public static final class Companion {
            private Companion() {
                    r0 = this;
                    r0.<init>()
                    return
            }

            public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                    r0 = this;
                    r0.<init>()
                    return
            }

            public final androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker getINSTANCE() {
                    r1 = this;
                    androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker r0 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker.access$getINSTANCE$cp()
                    return r0
            }
        }

        static {
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker$Companion r0 = new androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker$Companion
                r1 = 0
                r0.<init>(r1)
                androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker.Companion = r0
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker r0 = new androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker
                r0.<init>()
                androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker.INSTANCE = r0
                return
        }

        public DefaultCaptureOptionsUnpacker() {
                r0 = this;
                r0.<init>()
                return
        }

        public static final /* synthetic */ androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker access$getINSTANCE$cp() {
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker r0 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker.INSTANCE
                return r0
        }

        @Override // androidx.camera.core.impl.CaptureConfig.OptionUnpacker
        public void unpack(androidx.camera.core.impl.UseCaseConfig<?> r6, androidx.camera.core.impl.CaptureConfig.Builder r7) {
                r5 = this;
                java.lang.String r0 = "config"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
                java.lang.String r0 = "builder"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
                r0 = 0
                androidx.camera.core.impl.CaptureConfig r1 = r6.getDefaultCaptureConfig(r0)
                androidx.camera.core.impl.OptionsBundle r2 = androidx.camera.core.impl.OptionsBundle.emptyBundle()
                java.lang.String r3 = "emptyBundle(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
                androidx.camera.core.impl.Config r2 = (androidx.camera.core.impl.Config) r2
                androidx.camera.core.impl.CaptureConfig r3 = androidx.camera.core.impl.CaptureConfig.defaultEmptyCaptureConfig()
                int r3 = r3.getTemplateType()
                if (r1 == 0) goto L67
                int r3 = r1.getTemplateType()
                java.util.List r2 = r1.getCameraCaptureCallbacks()
                java.util.Collection r2 = (java.util.Collection) r2
                r7.addAllCameraCaptureCallbacks(r2)
                androidx.camera.core.impl.Config r2 = r1.getImplementationOptions()
                java.lang.String r4 = "getImplementationOptions(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r4)
                boolean r4 = r1.isUseRepeatingSurface()
                r7.setUseRepeatingSurface(r4)
                androidx.camera.core.impl.TagBundle r4 = r1.getTagBundle()
                r7.addAllTags(r4)
                java.util.List r1 = r1.getSurfaces()
                java.lang.String r4 = "getSurfaces(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r4)
                java.lang.Iterable r1 = (java.lang.Iterable) r1
                java.util.Iterator r1 = r1.iterator()
            L57:
                boolean r4 = r1.hasNext()
                if (r4 == 0) goto L67
                java.lang.Object r4 = r1.next()
                androidx.camera.core.impl.DeferrableSurface r4 = (androidx.camera.core.impl.DeferrableSurface) r4
                r7.addSurface(r4)
                goto L57
            L67:
                r7.setImplementationOptions(r2)
                androidx.camera.camera2.impl.Camera2ImplConfig r1 = new androidx.camera.camera2.impl.Camera2ImplConfig
                androidx.camera.core.impl.Config r6 = (androidx.camera.core.impl.Config) r6
                r1.<init>(r6)
                int r6 = r1.getCaptureRequestTemplate(r3)
                r7.setTemplateType(r6)
                r6 = 1
                android.hardware.camera2.CameraCaptureSession$CaptureCallback r6 = androidx.camera.camera2.impl.Camera2ImplConfig.getSessionCaptureCallback$default(r1, r0, r6, r0)
                if (r6 == 0) goto L8a
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$CaptureCallbackContainer$Companion r0 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.CaptureCallbackContainer.Companion
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$CaptureCallbackContainer r6 = r0.create(r6)
                androidx.camera.core.impl.CameraCaptureCallback r6 = (androidx.camera.core.impl.CameraCaptureCallback) r6
                r7.addCameraCaptureCallback(r6)
            L8a:
                androidx.camera.camera2.interop.CaptureRequestOptions r6 = r1.getCaptureRequestOptions()
                androidx.camera.core.impl.Config r6 = (androidx.camera.core.impl.Config) r6
                r7.addImplementationOptions(r6)
                return
        }
    }

    /* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\n\u0010\b\u001a\u0006\u0012\u0002\b\u00030\t2\u0006\u0010\n\u001a\u00020\u000bH\u0017¨\u0006\f"}, d2 = {"Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$DefaultSessionOptionsUnpacker;", "Landroidx/camera/core/impl/SessionConfig$OptionUnpacker;", "<init>", "()V", "unpack", "", "resolution", "Landroid/util/Size;", "config", "Landroidx/camera/core/impl/UseCaseConfig;", "builder", "Landroidx/camera/core/impl/SessionConfig$Builder;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class DefaultSessionOptionsUnpacker implements androidx.camera.core.impl.SessionConfig.OptionUnpacker {
        public static final androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultSessionOptionsUnpacker INSTANCE = null;

        static {
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultSessionOptionsUnpacker r0 = new androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultSessionOptionsUnpacker
                r0.<init>()
                androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultSessionOptionsUnpacker.INSTANCE = r0
                return
        }

        private DefaultSessionOptionsUnpacker() {
                r0 = this;
                r0.<init>()
                return
        }

        @Override // androidx.camera.core.impl.SessionConfig.OptionUnpacker
        public void unpack(android.util.Size r5, androidx.camera.core.impl.UseCaseConfig<?> r6, androidx.camera.core.impl.SessionConfig.Builder r7) {
                r4 = this;
                java.lang.String r0 = "resolution"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                java.lang.String r0 = "config"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
                java.lang.String r0 = "builder"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
                r0 = 0
                androidx.camera.core.impl.SessionConfig r1 = r6.getDefaultSessionConfig(r0)
                androidx.camera.core.impl.OptionsBundle r2 = androidx.camera.core.impl.OptionsBundle.emptyBundle()
                java.lang.String r3 = "emptyBundle(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
                androidx.camera.core.impl.Config r2 = (androidx.camera.core.impl.Config) r2
                androidx.camera.core.impl.SessionConfig r3 = androidx.camera.core.impl.SessionConfig.defaultEmptySessionConfig()
                int r3 = r3.getTemplateType()
                if (r1 == 0) goto L4f
                int r3 = r1.getTemplateType()
                java.util.List r2 = r1.getDeviceStateCallbacks()
                java.util.Collection r2 = (java.util.Collection) r2
                r7.addAllDeviceStateCallbacks(r2)
                java.util.List r2 = r1.getSessionStateCallbacks()
                r7.addAllSessionStateCallbacks(r2)
                java.util.List r2 = r1.getRepeatingCameraCaptureCallbacks()
                java.util.Collection r2 = (java.util.Collection) r2
                r7.addAllRepeatingCameraCaptureCallbacks(r2)
                androidx.camera.core.impl.Config r2 = r1.getImplementationOptions()
                java.lang.String r1 = "getImplementationOptions(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r1)
            L4f:
                r7.setImplementationOptions(r2)
                boolean r1 = r6 instanceof androidx.camera.core.impl.PreviewConfig
                if (r1 == 0) goto L59
                androidx.camera.camera2.compat.workaround.PreviewPixelHDRnetKt.setupHDRnet(r7, r5)
            L59:
                androidx.camera.camera2.impl.Camera2ImplConfig r5 = new androidx.camera.camera2.impl.Camera2ImplConfig
                r1 = r6
                androidx.camera.core.impl.Config r1 = (androidx.camera.core.impl.Config) r1
                r5.<init>(r1)
                int r1 = r5.getCaptureRequestTemplate(r3)
                r7.setTemplateType(r1)
                r1 = 1
                android.hardware.camera2.CameraDevice$StateCallback r2 = androidx.camera.camera2.impl.Camera2ImplConfig.getDeviceStateCallback$default(r5, r0, r1, r0)
                if (r2 == 0) goto L72
                r7.addDeviceStateCallback(r2)
            L72:
                android.hardware.camera2.CameraCaptureSession$StateCallback r2 = androidx.camera.camera2.impl.Camera2ImplConfig.getSessionStateCallback$default(r5, r0, r1, r0)
                if (r2 == 0) goto L7b
                r7.addSessionStateCallback(r2)
            L7b:
                android.hardware.camera2.CameraCaptureSession$CaptureCallback r2 = androidx.camera.camera2.impl.Camera2ImplConfig.getSessionCaptureCallback$default(r5, r0, r1, r0)
                if (r2 == 0) goto L8c
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$CaptureCallbackContainer$Companion r3 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.CaptureCallbackContainer.Companion
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$CaptureCallbackContainer r2 = r3.create(r2)
                androidx.camera.core.impl.CameraCaptureCallback r2 = (androidx.camera.core.impl.CameraCaptureCallback) r2
                r7.addCameraCaptureCallback(r2)
            L8c:
                int r2 = r6.getPreviewStabilizationMode()
                r7.setPreviewStabilization(r2)
                int r6 = r6.getVideoStabilizationMode()
                r7.setVideoStabilization(r6)
                androidx.camera.core.impl.MutableOptionsBundle r6 = androidx.camera.core.impl.MutableOptionsBundle.create()
                java.lang.String r2 = androidx.camera.camera2.impl.Camera2ImplConfig.getPhysicalCameraId$default(r5, r0, r1, r0)
                if (r2 == 0) goto La9
                androidx.camera.core.impl.Config$Option<java.lang.String> r3 = androidx.camera.camera2.impl.Camera2ImplConfig.SESSION_PHYSICAL_CAMERA_ID_OPTION
                r6.insertOption(r3, r2)
            La9:
                java.lang.Long r0 = androidx.camera.camera2.impl.Camera2ImplConfig.getStreamUseCase$default(r5, r0, r1, r0)
                if (r0 == 0) goto Lbe
                java.lang.Number r0 = (java.lang.Number) r0
                long r0 = r0.longValue()
                androidx.camera.core.impl.Config$Option<java.lang.Long> r2 = androidx.camera.camera2.impl.Camera2ImplConfig.STREAM_USE_CASE_OPTION
                java.lang.Long r0 = java.lang.Long.valueOf(r0)
                r6.insertOption(r2, r0)
            Lbe:
                java.lang.String r0 = "apply(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r6, r0)
                androidx.camera.core.impl.Config r6 = (androidx.camera.core.impl.Config) r6
                r7.addImplementationOptions(r6)
                androidx.camera.camera2.interop.CaptureRequestOptions r5 = r5.getCaptureRequestOptions()
                androidx.camera.core.impl.Config r5 = (androidx.camera.core.impl.Config) r5
                r7.addImplementationOptions(r5)
                return
        }
    }

    /* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \n2\u00020\u0001:\u0001\nB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u001c\u0010\u0004\u001a\u00020\u00052\n\u0010\u0006\u001a\u0006\u0012\u0002\b\u00030\u00072\u0006\u0010\b\u001a\u00020\tH\u0016¨\u0006\u000b"}, d2 = {"Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$ImageCaptureOptionUnpacker;", "Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker;", "<init>", "()V", "unpack", "", "config", "Landroidx/camera/core/impl/UseCaseConfig;", "builder", "Landroidx/camera/core/impl/CaptureConfig$Builder;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class ImageCaptureOptionUnpacker extends androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker {
        public static final androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker.Companion Companion = null;
        private static final androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker INSTANCE = null;

        /* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
        @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$ImageCaptureOptionUnpacker$Companion;", "", "<init>", "()V", "INSTANCE", "Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$ImageCaptureOptionUnpacker;", "getINSTANCE", "()Landroidx/camera/camera2/adapter/CameraUseCaseAdapter$ImageCaptureOptionUnpacker;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
        public static final class Companion {
            private Companion() {
                    r0 = this;
                    r0.<init>()
                    return
            }

            public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                    r0 = this;
                    r0.<init>()
                    return
            }

            public final androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker getINSTANCE() {
                    r1 = this;
                    androidx.camera.camera2.adapter.CameraUseCaseAdapter$ImageCaptureOptionUnpacker r0 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker.access$getINSTANCE$cp()
                    return r0
            }
        }

        static {
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$ImageCaptureOptionUnpacker$Companion r0 = new androidx.camera.camera2.adapter.CameraUseCaseAdapter$ImageCaptureOptionUnpacker$Companion
                r1 = 0
                r0.<init>(r1)
                androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker.Companion = r0
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$ImageCaptureOptionUnpacker r0 = new androidx.camera.camera2.adapter.CameraUseCaseAdapter$ImageCaptureOptionUnpacker
                r0.<init>()
                androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker.INSTANCE = r0
                return
        }

        public ImageCaptureOptionUnpacker() {
                r0 = this;
                r0.<init>()
                return
        }

        public static final /* synthetic */ androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker access$getINSTANCE$cp() {
                androidx.camera.camera2.adapter.CameraUseCaseAdapter$ImageCaptureOptionUnpacker r0 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker.INSTANCE
                return r0
        }

        @Override // androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker, androidx.camera.core.impl.CaptureConfig.OptionUnpacker
        public void unpack(androidx.camera.core.impl.UseCaseConfig<?> r2, androidx.camera.core.impl.CaptureConfig.Builder r3) {
                r1 = this;
                java.lang.String r0 = "config"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "builder"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                super.unpack(r2, r3)
                boolean r0 = r2 instanceof androidx.camera.core.impl.ImageCaptureConfig
                if (r0 == 0) goto L25
                androidx.camera.camera2.impl.Camera2ImplConfig$Builder r0 = new androidx.camera.camera2.impl.Camera2ImplConfig$Builder
                r0.<init>()
                androidx.camera.core.impl.ImageCaptureConfig r2 = (androidx.camera.core.impl.ImageCaptureConfig) r2
                androidx.camera.camera2.compat.workaround.ImageCapturePixelHDRPlusKt.toggleHDRPlus(r0, r2)
                androidx.camera.camera2.impl.Camera2ImplConfig r2 = r0.build()
                androidx.camera.core.impl.Config r2 = (androidx.camera.core.impl.Config) r2
                r3.addImplementationOptions(r2)
                return
            L25:
                java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
                java.lang.String r3 = "config is not ImageCaptureConfig"
                java.lang.String r3 = r3.toString()
                r2.<init>(r3)
                throw r2
        }
    }

    /* JADX INFO: compiled from: CameraUseCaseAdapter.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0 = null;

        static {
                androidx.camera.core.impl.UseCaseConfigFactory$CaptureType[] r0 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                androidx.camera.core.impl.UseCaseConfigFactory$CaptureType r1 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.IMAGE_CAPTURE     // Catch: java.lang.NoSuchFieldError -> L10
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L10
                r2 = 1
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L10
            L10:
                androidx.camera.core.impl.UseCaseConfigFactory$CaptureType r1 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.PREVIEW     // Catch: java.lang.NoSuchFieldError -> L19
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L19
                r2 = 2
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L19
            L19:
                androidx.camera.core.impl.UseCaseConfigFactory$CaptureType r1 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.STREAM_SHARING     // Catch: java.lang.NoSuchFieldError -> L22
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L22
                r2 = 3
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L22
            L22:
                androidx.camera.core.impl.UseCaseConfigFactory$CaptureType r1 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.METERING_REPEATING     // Catch: java.lang.NoSuchFieldError -> L2b
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L2b
                r2 = 4
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L2b
            L2b:
                androidx.camera.core.impl.UseCaseConfigFactory$CaptureType r1 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.IMAGE_ANALYSIS     // Catch: java.lang.NoSuchFieldError -> L34
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L34
                r2 = 5
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L34
            L34:
                androidx.camera.core.impl.UseCaseConfigFactory$CaptureType r1 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.VIDEO_CAPTURE     // Catch: java.lang.NoSuchFieldError -> L3d
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L3d
                r2 = 6
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L3d
            L3d:
                androidx.camera.camera2.adapter.CameraUseCaseAdapter.WhenMappings.$EnumSwitchMapping$0 = r0
                return
        }
    }

    public CameraUseCaseAdapter(android.content.Context r5) {
            r4 = this;
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            r4.<init>()
            androidx.camera.camera2.impl.DisplayInfoManager$Companion r0 = androidx.camera.camera2.impl.DisplayInfoManager.Companion
            androidx.camera.camera2.impl.DisplayInfoManager r0 = r0.getInstance(r5)
            r4.displayInfoManager = r0
            boolean r0 = r5 instanceof android.app.Application
            java.lang.String r1 = "CXCP"
            if (r0 == 0) goto L38
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r0 = androidx.camera.core.Logger.isInfoEnabled(r1)
            if (r0 == 0) goto L38
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "The provided context ("
            r2.<init>(r3)
            r2.append(r5)
            java.lang.String r5 = ") is application scoped and will be used to infer the default display for computing the default preview size, orientation, and default aspect ratio for UseCase outputs."
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.i(r0, r5)
        L38:
            androidx.camera.camera2.impl.Camera2Logger r5 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r5 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r5 == 0) goto L49
            java.lang.String r5 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r0 = "Created UseCaseConfigurationMap"
            android.util.Log.d(r5, r0)
        L49:
            return
    }

    @Override // androidx.camera.core.impl.UseCaseConfigFactory
    public androidx.camera.core.impl.Config getConfig(androidx.camera.core.impl.UseCaseConfigFactory.CaptureType r7, int r8) {
            r6 = this;
            java.lang.String r0 = "captureType"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r0)
            if (r0 == 0) goto L24
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Creating config for "
            r1.<init>(r2)
            r1.append(r7)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r0, r1)
        L24:
            androidx.camera.core.impl.MutableOptionsBundle r0 = androidx.camera.core.impl.MutableOptionsBundle.create()
            java.lang.String r1 = "create(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            androidx.camera.core.impl.SessionConfig$Builder r1 = new androidx.camera.core.impl.SessionConfig$Builder
            r1.<init>()
            int[] r2 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.WhenMappings.$EnumSwitchMapping$0
            int r3 = r7.ordinal()
            r2 = r2[r3]
            r3 = 3
            r4 = 1
            switch(r2) {
                case 1: goto L56;
                case 2: goto L56;
                case 3: goto L56;
                case 4: goto L56;
                case 5: goto L56;
                case 6: goto L45;
                default: goto L3f;
            }
        L3f:
            kotlin.NoWhenBranchMatchedException r7 = new kotlin.NoWhenBranchMatchedException
            r7.<init>()
            throw r7
        L45:
            androidx.camera.camera2.compat.quirk.DeviceQuirks r2 = androidx.camera.camera2.compat.quirk.DeviceQuirks.INSTANCE
            java.lang.Class<androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk> r5 = androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk.class
            androidx.camera.core.impl.Quirk r2 = r2.get(r5)
            if (r2 == 0) goto L51
            r2 = r4
            goto L52
        L51:
            r2 = r3
        L52:
            r1.setTemplateType(r2)
            goto L59
        L56:
            r1.setTemplateType(r4)
        L59:
            androidx.camera.core.impl.Config$Option<androidx.camera.core.impl.SessionConfig> r2 = androidx.camera.core.impl.UseCaseConfig.OPTION_DEFAULT_SESSION_CONFIG
            androidx.camera.core.impl.SessionConfig r1 = r1.build()
            r0.insertOption(r2, r1)
            androidx.camera.core.impl.CaptureConfig$Builder r1 = new androidx.camera.core.impl.CaptureConfig$Builder
            r1.<init>()
            int[] r2 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.WhenMappings.$EnumSwitchMapping$0
            int r5 = r7.ordinal()
            r2 = r2[r5]
            switch(r2) {
                case 1: goto L8b;
                case 2: goto L87;
                case 3: goto L87;
                case 4: goto L87;
                case 5: goto L87;
                case 6: goto L78;
                default: goto L72;
            }
        L72:
            kotlin.NoWhenBranchMatchedException r7 = new kotlin.NoWhenBranchMatchedException
            r7.<init>()
            throw r7
        L78:
            androidx.camera.camera2.compat.quirk.DeviceQuirks r8 = androidx.camera.camera2.compat.quirk.DeviceQuirks.INSTANCE
            java.lang.Class<androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk> r2 = androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk.class
            androidx.camera.core.impl.Quirk r8 = r8.get(r2)
            if (r8 == 0) goto L83
            r3 = r4
        L83:
            r1.setTemplateType(r3)
            goto L92
        L87:
            r1.setTemplateType(r4)
            goto L92
        L8b:
            r2 = 2
            if (r8 != r2) goto L8f
            r2 = 5
        L8f:
            r1.setTemplateType(r2)
        L92:
            androidx.camera.core.impl.Config$Option<androidx.camera.core.impl.CaptureConfig> r8 = androidx.camera.core.impl.UseCaseConfig.OPTION_DEFAULT_CAPTURE_CONFIG
            androidx.camera.core.impl.CaptureConfig r1 = r1.build()
            r0.insertOption(r8, r1)
            androidx.camera.core.impl.Config$Option<androidx.camera.core.impl.CaptureConfig$OptionUnpacker> r8 = androidx.camera.core.impl.UseCaseConfig.OPTION_CAPTURE_CONFIG_UNPACKER
            androidx.camera.core.impl.UseCaseConfigFactory$CaptureType r1 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.IMAGE_CAPTURE
            if (r7 != r1) goto Laa
            androidx.camera.camera2.adapter.CameraUseCaseAdapter$ImageCaptureOptionUnpacker$Companion r1 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.ImageCaptureOptionUnpacker.Companion
            androidx.camera.camera2.adapter.CameraUseCaseAdapter$ImageCaptureOptionUnpacker r1 = r1.getINSTANCE()
            androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker r1 = (androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker) r1
            goto Lb0
        Laa:
            androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker$Companion r1 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultCaptureOptionsUnpacker.Companion
            androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultCaptureOptionsUnpacker r1 = r1.getINSTANCE()
        Lb0:
            r0.insertOption(r8, r1)
            androidx.camera.core.impl.Config$Option<androidx.camera.core.impl.SessionConfig$OptionUnpacker> r8 = androidx.camera.core.impl.UseCaseConfig.OPTION_SESSION_CONFIG_UNPACKER
            androidx.camera.camera2.adapter.CameraUseCaseAdapter$DefaultSessionOptionsUnpacker r1 = androidx.camera.camera2.adapter.CameraUseCaseAdapter.DefaultSessionOptionsUnpacker.INSTANCE
            r0.insertOption(r8, r1)
            androidx.camera.core.impl.UseCaseConfigFactory$CaptureType r8 = androidx.camera.core.impl.UseCaseConfigFactory.CaptureType.PREVIEW
            if (r7 != r8) goto Lc9
            androidx.camera.camera2.impl.DisplayInfoManager r7 = r6.displayInfoManager
            android.util.Size r7 = r7.getPreviewSize()
            androidx.camera.core.impl.Config$Option<android.util.Size> r8 = androidx.camera.core.impl.ImageOutputConfig.OPTION_MAX_RESOLUTION
            r0.insertOption(r8, r7)
        Lc9:
            androidx.camera.core.impl.Config$Option<java.lang.Integer> r7 = androidx.camera.core.impl.ImageOutputConfig.OPTION_TARGET_ROTATION
            androidx.camera.camera2.impl.DisplayInfoManager r8 = r6.displayInfoManager
            r1 = 0
            r2 = 0
            android.view.Display r8 = androidx.camera.camera2.impl.DisplayInfoManager.getMaxSizeDisplay$default(r8, r1, r4, r2)
            int r8 = r8.getRotation()
            java.lang.Integer r8 = java.lang.Integer.valueOf(r8)
            r0.insertOption(r7, r8)
            androidx.camera.core.impl.Config r0 = (androidx.camera.core.impl.Config) r0
            androidx.camera.core.impl.OptionsBundle r7 = androidx.camera.core.impl.OptionsBundle.from(r0)
            java.lang.String r8 = "from(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r7, r8)
            androidx.camera.core.impl.Config r7 = (androidx.camera.core.impl.Config) r7
            return r7
    }
}
