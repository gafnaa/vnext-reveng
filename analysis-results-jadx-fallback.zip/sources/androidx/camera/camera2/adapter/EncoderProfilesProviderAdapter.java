package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: EncoderProfilesProviderAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\b\f\u0018\u0000 \u00192\u00020\u0001:\u0002\u0018\u0019B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\u000f\u001a\u00020\t2\u0006\u0010\u0010\u001a\u00020\u000bH\u0016J\u0012\u0010\u0011\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0010\u001a\u00020\u000bH\u0016J\n\u0010\u0012\u001a\u0004\u0018\u00010\u000eH\u0002J\n\u0010\u0013\u001a\u0004\u0018\u00010\u000eH\u0002J\u0012\u0010\u0014\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0010\u001a\u00020\u000bH\u0003J\u0012\u0010\u0015\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0010\u001a\u00020\u000bH\u0003J\u0010\u0010\u0016\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\u000eH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\f\u001a\u0010\u0012\u0004\u0012\u00020\u000b\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\rX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Landroidx/camera/camera2/adapter/EncoderProfilesProviderAdapter;", "Landroidx/camera/core/impl/EncoderProfilesProvider;", "cameraIdString", "", "cameraQuirks", "Landroidx/camera/core/impl/Quirks;", "<init>", "(Ljava/lang/String;Landroidx/camera/core/impl/Quirks;)V", "hasValidCameraId", "", "cameraId", "", "mEncoderProfilesCache", "", "Landroidx/camera/core/impl/EncoderProfilesProxy;", "hasProfile", "quality", "getAll", "findHighestQualityProfiles", "findLowestQualityProfiles", "getProfilesInternal", "createProfilesFromCamcorderProfile", "isEncoderProfilesResolutionValidInQuirk", "profiles", "Api31Impl", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class EncoderProfilesProviderAdapter implements androidx.camera.core.impl.EncoderProfilesProvider {
    public static final androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter.Companion Companion = null;
    private static final java.lang.String TAG = "EncoderProfilesProviderAdapter";
    private final int cameraId;
    private final java.lang.String cameraIdString;
    private final androidx.camera.core.impl.Quirks cameraQuirks;
    private final boolean hasValidCameraId;
    private final java.util.Map<java.lang.Integer, androidx.camera.core.impl.EncoderProfilesProxy> mEncoderProfilesCache;

    /* JADX INFO: compiled from: EncoderProfilesProviderAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\bÁ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t¨\u0006\n"}, d2 = {"Landroidx/camera/camera2/adapter/EncoderProfilesProviderAdapter$Api31Impl;", "", "<init>", "()V", "getAll", "Landroid/media/EncoderProfiles;", "cameraId", "", "quality", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Api31Impl {
        public static final androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter.Api31Impl INSTANCE = null;

        static {
                androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter$Api31Impl r0 = new androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter$Api31Impl
                r0.<init>()
                androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter.Api31Impl.INSTANCE = r0
                return
        }

        private Api31Impl() {
                r0 = this;
                r0.<init>()
                return
        }

        public final android.media.EncoderProfiles getAll(java.lang.String r2, int r3) {
                r1 = this;
                java.lang.String r0 = "cameraId"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                android.media.EncoderProfiles r2 = android.media.CamcorderProfile.getAll(r2, r3)
                return r2
        }
    }

    /* JADX INFO: compiled from: EncoderProfilesProviderAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Landroidx/camera/camera2/adapter/EncoderProfilesProviderAdapter$Companion;", "", "<init>", "()V", "TAG", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }
    }

    static {
            androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter$Companion r0 = new androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter.Companion = r0
            return
    }

    public EncoderProfilesProviderAdapter(java.lang.String r2, androidx.camera.core.impl.Quirks r3) {
            r1 = this;
            java.lang.String r0 = "cameraIdString"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "cameraQuirks"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r1.<init>()
            r1.cameraIdString = r2
            r1.cameraQuirks = r3
            java.util.LinkedHashMap r3 = new java.util.LinkedHashMap
            r3.<init>()
            java.util.Map r3 = (java.util.Map) r3
            r1.mEncoderProfilesCache = r3
            int r2 = java.lang.Integer.parseInt(r2)     // Catch: java.lang.NumberFormatException -> L20
            r3 = 1
            goto L3c
        L20:
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Camera id is not an integer:  "
            r2.<init>(r3)
            java.lang.String r3 = r1.cameraIdString
            r2.append(r3)
            java.lang.String r3 = ", unable to create EncoderProfilesProviderAdapter."
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            java.lang.String r3 = "EncoderProfilesProviderAdapter"
            androidx.camera.core.Logger.w(r3, r2)
            r3 = 0
            r2 = -1
        L3c:
            r1.hasValidCameraId = r3
            r1.cameraId = r2
            return
    }

    private final androidx.camera.core.impl.EncoderProfilesProxy createProfilesFromCamcorderProfile(int r5) {
            r4 = this;
            r0 = 0
            int r1 = r4.cameraId     // Catch: java.lang.RuntimeException -> L8
            android.media.CamcorderProfile r5 = android.media.CamcorderProfile.get(r1, r5)     // Catch: java.lang.RuntimeException -> L8
            goto L1f
        L8:
            r1 = move-exception
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unable to get CamcorderProfile by quality: "
            r2.<init>(r3)
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            java.lang.Throwable r1 = (java.lang.Throwable) r1
            java.lang.String r2 = "EncoderProfilesProviderAdapter"
            androidx.camera.core.Logger.w(r2, r5, r1)
            r5 = r0
        L1f:
            if (r5 == 0) goto L25
            androidx.camera.core.impl.EncoderProfilesProxy r0 = androidx.camera.core.impl.compat.EncoderProfilesProxyCompat.from(r5)
        L25:
            return r0
    }

    private final androidx.camera.core.impl.EncoderProfilesProxy findHighestQualityProfiles() {
            r2 = this;
            java.util.List<java.lang.Integer> r0 = androidx.camera.core.impl.EncoderProfilesProvider.QUALITY_HIGH_TO_LOW
            java.util.Iterator r0 = r0.iterator()
        L6:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L20
            java.lang.Object r1 = r0.next()
            java.lang.Integer r1 = (java.lang.Integer) r1
            kotlin.jvm.internal.Intrinsics.checkNotNull(r1)
            int r1 = r1.intValue()
            androidx.camera.core.impl.EncoderProfilesProxy r1 = r2.getAll(r1)
            if (r1 == 0) goto L6
            return r1
        L20:
            r0 = 0
            return r0
    }

    private final androidx.camera.core.impl.EncoderProfilesProxy findLowestQualityProfiles() {
            r3 = this;
            java.util.List<java.lang.Integer> r0 = androidx.camera.core.impl.EncoderProfilesProvider.QUALITY_HIGH_TO_LOW
            java.lang.String r1 = "QUALITY_HIGH_TO_LOW"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            int r0 = kotlin.collections.CollectionsKt.getLastIndex(r0)
        Lb:
            r1 = -1
            if (r1 >= r0) goto L29
            java.util.List<java.lang.Integer> r1 = androidx.camera.core.impl.EncoderProfilesProvider.QUALITY_HIGH_TO_LOW
            java.lang.Object r1 = r1.get(r0)
            java.lang.String r2 = "get(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Number r1 = (java.lang.Number) r1
            int r1 = r1.intValue()
            androidx.camera.core.impl.EncoderProfilesProxy r1 = r3.getAll(r1)
            if (r1 == 0) goto L26
            return r1
        L26:
            int r0 = r0 + (-1)
            goto Lb
        L29:
            r0 = 0
            return r0
    }

    private final androidx.camera.core.impl.EncoderProfilesProxy getProfilesInternal(int r4) {
            r3 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 31
            if (r0 < r1) goto L31
            androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter$Api31Impl r0 = androidx.camera.camera2.adapter.EncoderProfilesProviderAdapter.Api31Impl.INSTANCE
            java.lang.String r1 = r3.cameraIdString
            android.media.EncoderProfiles r0 = r0.getAll(r1, r4)
            if (r0 != 0) goto L12
            r4 = 0
            return r4
        L12:
            androidx.camera.camera2.compat.quirk.DeviceQuirks r1 = androidx.camera.camera2.compat.quirk.DeviceQuirks.INSTANCE
            java.lang.Class<androidx.camera.camera2.compat.quirk.InvalidVideoProfilesQuirk> r2 = androidx.camera.camera2.compat.quirk.InvalidVideoProfilesQuirk.class
            androidx.camera.core.impl.Quirk r1 = r1.get(r2)
            java.lang.String r2 = "EncoderProfilesProviderAdapter"
            if (r1 == 0) goto L24
            java.lang.String r0 = "EncoderProfiles contains invalid video profiles, use CamcorderProfile to create EncoderProfilesProxy."
            androidx.camera.core.Logger.d(r2, r0)
            goto L31
        L24:
            androidx.camera.core.impl.EncoderProfilesProxy r4 = androidx.camera.core.impl.compat.EncoderProfilesProxyCompat.from(r0)     // Catch: java.lang.NullPointerException -> L29
            return r4
        L29:
            r0 = move-exception
            java.lang.String r1 = "Failed to create EncoderProfilesProxy, EncoderProfiles might contain invalid video profiles. Use CamcorderProfile instead."
            java.lang.Throwable r0 = (java.lang.Throwable) r0
            androidx.camera.core.Logger.w(r2, r1, r0)
        L31:
            androidx.camera.core.impl.EncoderProfilesProxy r4 = r3.createProfilesFromCamcorderProfile(r4)
            return r4
    }

    private final boolean isEncoderProfilesResolutionValidInQuirk(androidx.camera.core.impl.EncoderProfilesProxy r4) {
            r3 = this;
            androidx.camera.core.impl.Quirks r0 = r3.cameraQuirks
            java.lang.Class<androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk> r1 = androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk.class
            androidx.camera.core.impl.Quirk r0 = r0.get(r1)
            androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk r0 = (androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk) r0
            r1 = 1
            if (r0 != 0) goto Le
            return r1
        Le:
            java.util.List r4 = r4.getVideoProfiles()
            java.lang.String r2 = "getVideoProfiles(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r2)
            boolean r2 = r4.isEmpty()
            if (r2 == 0) goto L1e
            return r1
        L1e:
            r1 = 0
            java.lang.Object r4 = r4.get(r1)
            androidx.camera.core.impl.EncoderProfilesProxy$VideoProfileProxy r4 = (androidx.camera.core.impl.EncoderProfilesProxy.VideoProfileProxy) r4
            java.util.List r0 = r0.getSupportedResolutions()
            android.util.Size r4 = r4.getResolution()
            boolean r4 = r0.contains(r4)
            return r4
    }

    @Override // androidx.camera.core.impl.EncoderProfilesProvider
    public androidx.camera.core.impl.EncoderProfilesProxy getAll(int r4) {
            r3 = this;
            boolean r0 = r3.hasValidCameraId
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            int r0 = r3.cameraId
            boolean r0 = android.media.CamcorderProfile.hasProfile(r0, r4)
            if (r0 != 0) goto Lf
            return r1
        Lf:
            java.util.Map<java.lang.Integer, androidx.camera.core.impl.EncoderProfilesProxy> r0 = r3.mEncoderProfilesCache
            java.lang.Integer r2 = java.lang.Integer.valueOf(r4)
            boolean r0 = r0.containsKey(r2)
            if (r0 == 0) goto L28
            java.util.Map<java.lang.Integer, androidx.camera.core.impl.EncoderProfilesProxy> r0 = r3.mEncoderProfilesCache
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            java.lang.Object r4 = r0.get(r4)
            androidx.camera.core.impl.EncoderProfilesProxy r4 = (androidx.camera.core.impl.EncoderProfilesProxy) r4
            return r4
        L28:
            androidx.camera.core.impl.EncoderProfilesProxy r0 = r3.getProfilesInternal(r4)
            if (r0 == 0) goto L44
            boolean r2 = r3.isEncoderProfilesResolutionValidInQuirk(r0)
            if (r2 != 0) goto L44
            if (r4 == 0) goto L3f
            r0 = 1
            if (r4 == r0) goto L3a
            goto L43
        L3a:
            androidx.camera.core.impl.EncoderProfilesProxy r1 = r3.findHighestQualityProfiles()
            goto L43
        L3f:
            androidx.camera.core.impl.EncoderProfilesProxy r1 = r3.findLowestQualityProfiles()
        L43:
            r0 = r1
        L44:
            java.util.Map<java.lang.Integer, androidx.camera.core.impl.EncoderProfilesProxy> r1 = r3.mEncoderProfilesCache
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r1.put(r4, r0)
            return r0
    }

    @Override // androidx.camera.core.impl.EncoderProfilesProvider
    public boolean hasProfile(int r3) {
            r2 = this;
            boolean r0 = r2.hasValidCameraId
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            androidx.camera.core.impl.EncoderProfilesProxy r3 = r2.getAll(r3)
            if (r3 == 0) goto Le
            r3 = 1
            return r3
        Le:
            return r1
    }
}
