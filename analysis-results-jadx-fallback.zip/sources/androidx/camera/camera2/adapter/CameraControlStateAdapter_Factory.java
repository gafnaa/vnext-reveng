package androidx.camera.camera2.adapter;

/* JADX INFO: loaded from: classes.dex */
public final class CameraControlStateAdapter_Factory implements dagger.internal.Factory<androidx.camera.camera2.adapter.CameraControlStateAdapter> {
    private final dagger.internal.Provider<androidx.camera.camera2.impl.EvCompControl> evCompControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.LowLightBoostControl> lowLightBoostControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.TorchControl> torchControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.ZoomControl> zoomControlProvider;

    private CameraControlStateAdapter_Factory(dagger.internal.Provider<androidx.camera.camera2.impl.ZoomControl> r1, dagger.internal.Provider<androidx.camera.camera2.impl.EvCompControl> r2, dagger.internal.Provider<androidx.camera.camera2.impl.TorchControl> r3, dagger.internal.Provider<androidx.camera.camera2.impl.LowLightBoostControl> r4) {
            r0 = this;
            r0.<init>()
            r0.zoomControlProvider = r1
            r0.evCompControlProvider = r2
            r0.torchControlProvider = r3
            r0.lowLightBoostControlProvider = r4
            return
    }

    public static androidx.camera.camera2.adapter.CameraControlStateAdapter_Factory create(dagger.internal.Provider<androidx.camera.camera2.impl.ZoomControl> r1, dagger.internal.Provider<androidx.camera.camera2.impl.EvCompControl> r2, dagger.internal.Provider<androidx.camera.camera2.impl.TorchControl> r3, dagger.internal.Provider<androidx.camera.camera2.impl.LowLightBoostControl> r4) {
            androidx.camera.camera2.adapter.CameraControlStateAdapter_Factory r0 = new androidx.camera.camera2.adapter.CameraControlStateAdapter_Factory
            r0.<init>(r1, r2, r3, r4)
            return r0
    }

    public static androidx.camera.camera2.adapter.CameraControlStateAdapter newInstance(androidx.camera.camera2.impl.ZoomControl r1, androidx.camera.camera2.impl.EvCompControl r2, androidx.camera.camera2.impl.TorchControl r3, androidx.camera.camera2.impl.LowLightBoostControl r4) {
            androidx.camera.camera2.adapter.CameraControlStateAdapter r0 = new androidx.camera.camera2.adapter.CameraControlStateAdapter
            r0.<init>(r1, r2, r3, r4)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.adapter.CameraControlStateAdapter get() {
            r4 = this;
            dagger.internal.Provider<androidx.camera.camera2.impl.ZoomControl> r0 = r4.zoomControlProvider
            java.lang.Object r0 = r0.get()
            androidx.camera.camera2.impl.ZoomControl r0 = (androidx.camera.camera2.impl.ZoomControl) r0
            dagger.internal.Provider<androidx.camera.camera2.impl.EvCompControl> r1 = r4.evCompControlProvider
            java.lang.Object r1 = r1.get()
            androidx.camera.camera2.impl.EvCompControl r1 = (androidx.camera.camera2.impl.EvCompControl) r1
            dagger.internal.Provider<androidx.camera.camera2.impl.TorchControl> r2 = r4.torchControlProvider
            java.lang.Object r2 = r2.get()
            androidx.camera.camera2.impl.TorchControl r2 = (androidx.camera.camera2.impl.TorchControl) r2
            dagger.internal.Provider<androidx.camera.camera2.impl.LowLightBoostControl> r3 = r4.lowLightBoostControlProvider
            java.lang.Object r3 = r3.get()
            androidx.camera.camera2.impl.LowLightBoostControl r3 = (androidx.camera.camera2.impl.LowLightBoostControl) r3
            androidx.camera.camera2.adapter.CameraControlStateAdapter r0 = newInstance(r0, r1, r2, r3)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraControlStateAdapter r0 = r1.get()
            return r0
    }
}
