package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: GuaranteedConfigurationsUtil.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J&\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001bH\u0007J\u000e\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u000e\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0007J\u001e\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$H\u0007J\u000e\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0002J\u000e\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H\u0002J\u001e\u0010'\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020)H\u0002J#\u0010+\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010,\u001a\u00020-2\u0006\u0010.\u001a\u00020/H\u0000¢\u0006\u0002\b0R!\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u0007\u0010\bR!\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\r\u0010\n\u001a\u0004\b\f\u0010\b¨\u00061"}, d2 = {"Landroidx/camera/camera2/adapter/GuaranteedConfigurationsUtil;", "", "<init>", "()V", "QUERYABLE_VIC_FCQ_COMBINATIONS", "", "Landroidx/camera/core/impl/SurfaceCombination;", "getQUERYABLE_VIC_FCQ_COMBINATIONS", "()Ljava/util/List;", "QUERYABLE_VIC_FCQ_COMBINATIONS$delegate", "Lkotlin/Lazy;", "QUERYABLE_BAKLAVA_FCQ_COMBINATIONS", "getQUERYABLE_BAKLAVA_FCQ_COMBINATIONS", "QUERYABLE_BAKLAVA_FCQ_COMBINATIONS$delegate", "getLegacySupportedCombinationList", "getLimitedSupportedCombinationList", "getFullSupportedCombinationList", "getRAWSupportedCombinationList", "getBurstSupportedCombinationList", "getLevel3SupportedCombinationList", "getUltraHighResolutionSupportedCombinationList", "getUltraHdrSupportedCombinationList", "getConcurrentSupportedCombinationList", "generateSupportedCombinationList", "hardwareLevel", "", "isRawSupported", "", "isBurstCaptureSupported", "get10BitSupportedCombinationList", "getStreamUseCaseSupportedCombinationList", "getPreviewStabilizationSupportedCombinationList", "generateHighSpeedSupportedCombinationList", "maxSupportedSize", "Landroid/util/Size;", "surfaceSizeDefinition", "Landroidx/camera/core/impl/SurfaceSizeDefinition;", "generateVicQueryableFcqCombinations", "generateBaklavaQueryableFcqCombinations", "createPrivJpegXCombinations", "privSize", "Landroidx/camera/core/impl/SurfaceConfig$ConfigSize;", "jpegXSize", "getQueryableFcqCombinations", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "videoStabilization", "Landroidx/camera/core/impl/stabilization/VideoStabilization;", "getQueryableFcqCombinations$camera_camera2", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class GuaranteedConfigurationsUtil {
    public static final androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil INSTANCE = null;
    private static final kotlin.Lazy QUERYABLE_BAKLAVA_FCQ_COMBINATIONS$delegate = null;
    private static final kotlin.Lazy QUERYABLE_VIC_FCQ_COMBINATIONS$delegate = null;

    /* JADX INFO: renamed from: $r8$lambda$Y8-NjHh-iVV6h-z3yrfA8qrdcx4, reason: not valid java name */
    public static /* synthetic */ java.util.List m75$r8$lambda$Y8NjHhiVV6hz3yrfA8qrdcx4() {
            java.util.List r0 = QUERYABLE_BAKLAVA_FCQ_COMBINATIONS_delegate$lambda$0()
            return r0
    }

    public static /* synthetic */ java.util.List $r8$lambda$aXIGl4MOIgYKcgTzwCnBNg4LaSo() {
            java.util.List r0 = QUERYABLE_VIC_FCQ_COMBINATIONS_delegate$lambda$0()
            return r0
    }

    static {
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil r0 = new androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil
            r0.<init>()
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.INSTANCE = r0
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil$$ExternalSyntheticLambda1 r0 = new androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil$$ExternalSyntheticLambda1
            r0.<init>()
            kotlin.Lazy r0 = kotlin.LazyKt.lazy(r0)
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.QUERYABLE_VIC_FCQ_COMBINATIONS$delegate = r0
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil$$ExternalSyntheticLambda2 r0 = new androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil$$ExternalSyntheticLambda2
            r0.<init>()
            kotlin.Lazy r0 = kotlin.LazyKt.lazy(r0)
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.QUERYABLE_BAKLAVA_FCQ_COMBINATIONS$delegate = r0
            return
    }

    private GuaranteedConfigurationsUtil() {
            r0 = this;
            r0.<init>()
            return
    }

    private static final java.util.List QUERYABLE_BAKLAVA_FCQ_COMBINATIONS_delegate$lambda$0() {
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil r0 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.INSTANCE
            java.util.List r0 = r0.generateBaklavaQueryableFcqCombinations()
            return r0
    }

    private static final java.util.List QUERYABLE_VIC_FCQ_COMBINATIONS_delegate$lambda$0() {
            androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil r0 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.INSTANCE
            java.util.List r0 = r0.generateVicQueryableFcqCombinations()
            return r0
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> createPrivJpegXCombinations(androidx.camera.core.impl.SurfaceConfig.ConfigSize r12, androidx.camera.core.impl.SurfaceConfig.ConfigSize r13) {
            r11 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            r6 = 4
            r7 = 0
            r5 = 0
            r4 = r12
            androidx.camera.core.impl.SurfaceConfig r12 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r12)
            androidx.camera.core.impl.SurfaceConfig$Companion r5 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r6 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            r9 = 4
            r10 = 0
            r8 = 0
            r7 = r13
            androidx.camera.core.impl.SurfaceConfig r12 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r5, r6, r7, r8, r9, r10)
            r1.addSurfaceConfig(r12)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r12 = new androidx.camera.core.impl.SurfaceCombination
            r12.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r12.addSurfaceConfig(r1)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG_R
            r4 = r13
            androidx.camera.core.impl.SurfaceConfig r13 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r12.addSurfaceConfig(r13)
            r0.add(r12)
            return r0
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> generateBaklavaQueryableFcqCombinations() {
            r9 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_16_9
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.UHD
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> generateHighSpeedSupportedCombinationList(android.util.Size r10, androidx.camera.core.impl.SurfaceSizeDefinition r11) {
            java.lang.String r0 = "maxSupportedSize"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.lang.String r0 = "surfaceSizeDefinition"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceConfig$Companion r1 = androidx.camera.core.impl.SurfaceConfig.Companion
            r8 = 56
            r9 = 0
            r2 = 34
            r5 = 0
            r6 = 0
            r7 = 0
            r3 = r10
            r4 = r11
            androidx.camera.core.impl.SurfaceConfig r10 = androidx.camera.core.impl.SurfaceConfig.Companion.transformSurfaceConfig$default(r1, r2, r3, r4, r5, r6, r7, r8, r9)
            androidx.camera.core.impl.SurfaceCombination r11 = new androidx.camera.core.impl.SurfaceCombination
            r11.<init>()
            r11.addSurfaceConfig(r10)
            r0.add(r11)
            androidx.camera.core.impl.SurfaceCombination r11 = new androidx.camera.core.impl.SurfaceCombination
            r11.<init>()
            r11.addSurfaceConfig(r10)
            r11.addSurfaceConfig(r10)
            r0.add(r11)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> generateSupportedCombinationList(int r4, boolean r5, boolean r6) {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            java.util.List r1 = getLegacySupportedCombinationList()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            r1 = 1
            r2 = 3
            if (r4 == 0) goto L1c
            if (r4 == r1) goto L1c
            if (r4 == r2) goto L1c
            r3 = 4
            if (r4 == r3) goto L1c
            goto L25
        L1c:
            java.util.List r3 = getLimitedSupportedCombinationList()
            java.util.Collection r3 = (java.util.Collection) r3
            r0.addAll(r3)
        L25:
            if (r4 == r1) goto L2a
            if (r4 == r2) goto L2a
            goto L33
        L2a:
            java.util.List r1 = getFullSupportedCombinationList()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
        L33:
            if (r5 == 0) goto L3e
            java.util.List r5 = getRAWSupportedCombinationList()
            java.util.Collection r5 = (java.util.Collection) r5
            r0.addAll(r5)
        L3e:
            if (r6 == 0) goto L4b
            if (r4 != 0) goto L4b
            java.util.List r5 = getBurstSupportedCombinationList()
            java.util.Collection r5 = (java.util.Collection) r5
            r0.addAll(r5)
        L4b:
            if (r4 != r2) goto L56
            java.util.List r4 = getLevel3SupportedCombinationList()
            java.util.Collection r4 = (java.util.Collection) r4
            r0.addAll(r4)
        L56:
            return r0
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> generateVicQueryableFcqCombinations() {
            r8 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM_16_9
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.UHD
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_16_9
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM_16_9
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.UHD
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_16_9
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.X_VGA
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM_4_3
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r1 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1080P_4_3
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r2 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM_4_3
            java.util.List r1 = r8.createPrivJpegXCombinations(r1, r2)
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> get10BitSupportedCombinationList() {
            r0 = 8
            androidx.camera.core.impl.SurfaceCombination[] r0 = new androidx.camera.core.impl.SurfaceCombination[r0]
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 0
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 1
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 2
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 3
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 4
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 5
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 6
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 7
            r0[r2] = r1
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getBurstSupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getConcurrentSupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S720P_16_9
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getFullSupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.VGA
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.VGA
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getLegacySupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getLevel3SupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.VGA
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.VGA
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getLimitedSupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getPreviewStabilizationSupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getRAWSupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getUltraHdrSupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG_R
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG_R
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final java.util.List<androidx.camera.core.impl.SurfaceCombination> getUltraHighResolutionSupportedCombinationList() {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r8 = 0
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.ULTRA_MAXIMUM
            r6 = 4
            r7 = 0
            r5 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            r7 = 4
            r6 = 0
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r3 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r4 = androidx.camera.core.impl.SurfaceConfig.ConfigType.RAW
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r5 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.SurfaceConfig r2 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r3, r4, r5, r6, r7, r8)
            r1.addSurfaceConfig(r2)
            r0.add(r1)
            return r0
    }

    public final java.util.List<androidx.camera.core.impl.SurfaceCombination> getQUERYABLE_BAKLAVA_FCQ_COMBINATIONS() {
            r1 = this;
            kotlin.Lazy r0 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.QUERYABLE_BAKLAVA_FCQ_COMBINATIONS$delegate
            java.lang.Object r0 = r0.getValue()
            java.util.List r0 = (java.util.List) r0
            return r0
    }

    public final java.util.List<androidx.camera.core.impl.SurfaceCombination> getQUERYABLE_VIC_FCQ_COMBINATIONS() {
            r1 = this;
            kotlin.Lazy r0 = androidx.camera.camera2.adapter.GuaranteedConfigurationsUtil.QUERYABLE_VIC_FCQ_COMBINATIONS$delegate
            java.lang.Object r0 = r0.getValue()
            java.util.List r0 = (java.util.List) r0
            return r0
    }

    public final java.util.List<androidx.camera.core.impl.SurfaceCombination> getQueryableFcqCombinations$camera_camera2(androidx.camera.camera2.pipe.CameraMetadata r5, androidx.camera.core.impl.stabilization.VideoStabilization r6) {
            r4 = this;
            java.lang.String r0 = "cameraMetadata"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "videoStabilization"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 35
            if (r1 < r2) goto L59
            android.hardware.camera2.CameraCharacteristics$Key r1 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m12m()
            java.lang.String r3 = "INFO_SESSION_CONFIGURATION_QUERY_VERSION"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r3)
            java.lang.Object r5 = r5.get(r1)
            if (r5 == 0) goto L4d
            java.lang.Number r5 = (java.lang.Number) r5
            int r5 = r5.intValue()
            if (r5 < r2) goto L3b
            androidx.camera.core.impl.stabilization.VideoStabilization r1 = androidx.camera.core.impl.stabilization.VideoStabilization.ON
            if (r6 == r1) goto L3b
            java.util.List r1 = r4.getQUERYABLE_VIC_FCQ_COMBINATIONS()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.addAll(r1)
        L3b:
            r1 = 36
            if (r5 < r1) goto L59
            androidx.camera.core.impl.stabilization.VideoStabilization r5 = androidx.camera.core.impl.stabilization.VideoStabilization.PREVIEW
            if (r6 == r5) goto L59
            java.util.List r5 = r4.getQUERYABLE_BAKLAVA_FCQ_COMBINATIONS()
            java.util.Collection r5 = (java.util.Collection) r5
            r0.addAll(r5)
            return r0
        L4d:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r6 = "Required value was null."
            java.lang.String r6 = r6.toString()
            r5.<init>(r6)
            throw r5
        L59:
            return r0
    }

    public final java.util.List<androidx.camera.core.impl.SurfaceCombination> getStreamUseCaseSupportedCombinationList() {
            r6 = this;
            r0 = 14
            androidx.camera.core.impl.SurfaceCombination[] r0 = new androidx.camera.core.impl.SurfaceCombination[r0]
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW_VIDEO_STILL
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 0
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.S1440P_4_3
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW_VIDEO_STILL
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 1
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.VIDEO_RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 2
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.VIDEO_RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 3
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.STILL_CAPTURE
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 4
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.STILL_CAPTURE
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 5
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.STILL_CAPTURE
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 6
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.STILL_CAPTURE
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 7
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.VIDEO_RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 8
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.VIDEO_RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 9
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 10
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.VIDEO_RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.STILL_CAPTURE
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 11
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.VIDEO_RECORD
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.RECORD
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.STILL_CAPTURE
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 12
            r0[r2] = r1
            androidx.camera.core.impl.SurfaceCombination r1 = new androidx.camera.core.impl.SurfaceCombination
            r1.<init>()
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.PREVIEW
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
            androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG
            androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
            androidx.camera.core.impl.StreamUseCase r5 = androidx.camera.core.impl.StreamUseCase.STILL_CAPTURE
            androidx.camera.core.impl.SurfaceConfig r2 = r2.create(r3, r4, r5)
            r1.addSurfaceConfig(r2)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            r2 = 13
            r0[r2] = r1
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            return r0
    }
}
