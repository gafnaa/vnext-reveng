package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CaptureResultAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000B\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\f\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0002\u001a\f\u0010\u0003\u001a\u00020\u0004*\u00020\u0002H\u0002\u001a\f\u0010\u0005\u001a\u00020\u0006*\u00020\u0002H\u0002\u001a\f\u0010\u0007\u001a\u00020\b*\u00020\u0002H\u0002\u001a\f\u0010\t\u001a\u00020\n*\u00020\u0002H\u0002\u001a\f\u0010\u000b\u001a\u00020\f*\u00020\u0002H\u0002\u001a\f\u0010\r\u001a\u00020\u000e*\u00020\u0002H\u0002\u001a\f\u0010\u000f\u001a\u00020\u0010*\u00020\u0002H\u0002\u001a\u0014\u0010\u0011\u001a\u00020\u0012*\u00020\u00022\u0006\u0010\u0013\u001a\u00020\u0014H\u0002¨\u0006\u0015"}, d2 = {"getAfMode", "Landroidx/camera/core/impl/CameraCaptureMetaData$AfMode;", "Landroidx/camera/camera2/pipe/FrameMetadata;", "getAfState", "Landroidx/camera/core/impl/CameraCaptureMetaData$AfState;", "getAeMode", "Landroidx/camera/core/impl/CameraCaptureMetaData$AeMode;", "getAeState", "Landroidx/camera/core/impl/CameraCaptureMetaData$AeState;", "getAwbMode", "Landroidx/camera/core/impl/CameraCaptureMetaData$AwbMode;", "getAwbState", "Landroidx/camera/core/impl/CameraCaptureMetaData$AwbState;", "getFlashState", "Landroidx/camera/core/impl/CameraCaptureMetaData$FlashState;", "getTimestamp", "", "populateExifData", "", "exifData", "Landroidx/camera/core/impl/utils/ExifData$Builder;", "camera-camera2"}, k = 2, mv = {2, 1, 0}, xi = 48)
public final class CaptureResultAdapterKt {
    public static final /* synthetic */ androidx.camera.core.impl.CameraCaptureMetaData.AeMode access$getAeMode(androidx.camera.camera2.pipe.FrameMetadata r0) {
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r0 = getAeMode(r0)
            return r0
    }

    public static final /* synthetic */ androidx.camera.core.impl.CameraCaptureMetaData.AeState access$getAeState(androidx.camera.camera2.pipe.FrameMetadata r0) {
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r0 = getAeState(r0)
            return r0
    }

    public static final /* synthetic */ androidx.camera.core.impl.CameraCaptureMetaData.AfMode access$getAfMode(androidx.camera.camera2.pipe.FrameMetadata r0) {
            androidx.camera.core.impl.CameraCaptureMetaData$AfMode r0 = getAfMode(r0)
            return r0
    }

    public static final /* synthetic */ androidx.camera.core.impl.CameraCaptureMetaData.AfState access$getAfState(androidx.camera.camera2.pipe.FrameMetadata r0) {
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r0 = getAfState(r0)
            return r0
    }

    public static final /* synthetic */ androidx.camera.core.impl.CameraCaptureMetaData.AwbMode access$getAwbMode(androidx.camera.camera2.pipe.FrameMetadata r0) {
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r0 = getAwbMode(r0)
            return r0
    }

    public static final /* synthetic */ androidx.camera.core.impl.CameraCaptureMetaData.AwbState access$getAwbState(androidx.camera.camera2.pipe.FrameMetadata r0) {
            androidx.camera.core.impl.CameraCaptureMetaData$AwbState r0 = getAwbState(r0)
            return r0
    }

    public static final /* synthetic */ androidx.camera.core.impl.CameraCaptureMetaData.FlashState access$getFlashState(androidx.camera.camera2.pipe.FrameMetadata r0) {
            androidx.camera.core.impl.CameraCaptureMetaData$FlashState r0 = getFlashState(r0)
            return r0
    }

    public static final /* synthetic */ long access$getTimestamp(androidx.camera.camera2.pipe.FrameMetadata r2) {
            long r0 = getTimestamp(r2)
            return r0
    }

    public static final /* synthetic */ void access$populateExifData(androidx.camera.camera2.pipe.FrameMetadata r0, androidx.camera.core.impl.utils.ExifData.Builder r1) {
            populateExifData(r0, r1)
            return
    }

    private static final androidx.camera.core.impl.CameraCaptureMetaData.AeMode getAeMode(androidx.camera.camera2.pipe.FrameMetadata r5) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.CONTROL_AE_MODE
            java.lang.String r1 = "CONTROL_AE_MODE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r5.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L10
            goto L19
        L10:
            int r1 = r0.intValue()
            if (r1 != 0) goto L19
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeMode.OFF
            return r5
        L19:
            if (r0 != 0) goto L1c
            goto L26
        L1c:
            int r1 = r0.intValue()
            r2 = 1
            if (r1 != r2) goto L26
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeMode.ON
            return r5
        L26:
            if (r0 != 0) goto L29
            goto L33
        L29:
            int r1 = r0.intValue()
            r2 = 2
            if (r1 != r2) goto L33
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeMode.ON_AUTO_FLASH
            return r5
        L33:
            if (r0 != 0) goto L36
            goto L40
        L36:
            int r1 = r0.intValue()
            r2 = 3
            if (r1 != r2) goto L40
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeMode.ON_ALWAYS_FLASH
            return r5
        L40:
            if (r0 != 0) goto L43
            goto L4d
        L43:
            int r1 = r0.intValue()
            r2 = 4
            if (r1 != r2) goto L4d
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeMode.ON_AUTO_FLASH_REDEYE
            return r5
        L4d:
            if (r0 != 0) goto L52
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeMode.UNKNOWN
            return r5
        L52:
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r1 == 0) goto L8a
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unknown AE mode ("
            r2.<init>(r3)
            int r0 = r0.intValue()
            r2.append(r0)
            java.lang.String r0 = ") for "
            r2.append(r0)
            long r3 = r5.mo554getFrameNumberUgla2oM()
            java.lang.String r5 = androidx.camera.camera2.pipe.FrameNumber.m560toStringimpl(r3)
            r2.append(r5)
            r5 = 33
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.d(r1, r5)
        L8a:
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeMode.UNKNOWN
            return r5
    }

    private static final androidx.camera.core.impl.CameraCaptureMetaData.AeState getAeState(androidx.camera.camera2.pipe.FrameMetadata r5) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.CONTROL_AE_STATE
            java.lang.String r1 = "CONTROL_AE_STATE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r5.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L10
            goto L19
        L10:
            int r1 = r0.intValue()
            if (r1 != 0) goto L19
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeState.INACTIVE
            return r5
        L19:
            if (r0 != 0) goto L1c
            goto L23
        L1c:
            int r1 = r0.intValue()
            r2 = 1
            if (r1 == r2) goto L95
        L23:
            if (r0 != 0) goto L26
            goto L2e
        L26:
            int r1 = r0.intValue()
            r2 = 5
            if (r1 != r2) goto L2e
            goto L95
        L2e:
            if (r0 != 0) goto L31
            goto L3b
        L31:
            int r1 = r0.intValue()
            r2 = 4
            if (r1 != r2) goto L3b
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeState.FLASH_REQUIRED
            return r5
        L3b:
            if (r0 != 0) goto L3e
            goto L48
        L3e:
            int r1 = r0.intValue()
            r2 = 2
            if (r1 != r2) goto L48
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeState.CONVERGED
            return r5
        L48:
            if (r0 != 0) goto L4b
            goto L55
        L4b:
            int r1 = r0.intValue()
            r2 = 3
            if (r1 != r2) goto L55
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeState.LOCKED
            return r5
        L55:
            if (r0 != 0) goto L5a
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeState.UNKNOWN
            return r5
        L5a:
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r1 == 0) goto L92
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unknown AE state ("
            r2.<init>(r3)
            int r0 = r0.intValue()
            r2.append(r0)
            java.lang.String r0 = ") for "
            r2.append(r0)
            long r3 = r5.mo554getFrameNumberUgla2oM()
            java.lang.String r5 = androidx.camera.camera2.pipe.FrameNumber.m560toStringimpl(r3)
            r2.append(r5)
            r5 = 33
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.d(r1, r5)
        L92:
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeState.UNKNOWN
            return r5
        L95:
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AeState.SEARCHING
            return r5
    }

    private static final androidx.camera.core.impl.CameraCaptureMetaData.AfMode getAfMode(androidx.camera.camera2.pipe.FrameMetadata r5) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.CONTROL_AF_MODE
            java.lang.String r1 = "CONTROL_AF_MODE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r5.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L10
            goto L16
        L10:
            int r1 = r0.intValue()
            if (r1 == 0) goto L92
        L16:
            if (r0 != 0) goto L19
            goto L22
        L19:
            int r1 = r0.intValue()
            r2 = 5
            if (r1 != r2) goto L22
            goto L92
        L22:
            if (r0 != 0) goto L25
            goto L2c
        L25:
            int r1 = r0.intValue()
            r2 = 1
            if (r1 == r2) goto L8f
        L2c:
            if (r0 != 0) goto L2f
            goto L37
        L2f:
            int r1 = r0.intValue()
            r2 = 2
            if (r1 != r2) goto L37
            goto L8f
        L37:
            if (r0 != 0) goto L3a
            goto L41
        L3a:
            int r1 = r0.intValue()
            r2 = 4
            if (r1 == r2) goto L8c
        L41:
            if (r0 != 0) goto L44
            goto L4c
        L44:
            int r1 = r0.intValue()
            r2 = 3
            if (r1 != r2) goto L4c
            goto L8c
        L4c:
            if (r0 != 0) goto L51
            androidx.camera.core.impl.CameraCaptureMetaData$AfMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfMode.UNKNOWN
            return r5
        L51:
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r1 == 0) goto L89
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unknown AF mode ("
            r2.<init>(r3)
            int r0 = r0.intValue()
            r2.append(r0)
            java.lang.String r0 = ") for "
            r2.append(r0)
            long r3 = r5.mo554getFrameNumberUgla2oM()
            java.lang.String r5 = androidx.camera.camera2.pipe.FrameNumber.m560toStringimpl(r3)
            r2.append(r5)
            r5 = 33
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.d(r1, r5)
        L89:
            androidx.camera.core.impl.CameraCaptureMetaData$AfMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfMode.UNKNOWN
            return r5
        L8c:
            androidx.camera.core.impl.CameraCaptureMetaData$AfMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfMode.ON_CONTINUOUS_AUTO
            return r5
        L8f:
            androidx.camera.core.impl.CameraCaptureMetaData$AfMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfMode.ON_MANUAL_AUTO
            return r5
        L92:
            androidx.camera.core.impl.CameraCaptureMetaData$AfMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfMode.OFF
            return r5
    }

    private static final androidx.camera.core.impl.CameraCaptureMetaData.AfState getAfState(androidx.camera.camera2.pipe.FrameMetadata r5) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.CONTROL_AF_STATE
            java.lang.String r1 = "CONTROL_AF_STATE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r5.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L10
            goto L19
        L10:
            int r1 = r0.intValue()
            if (r1 != 0) goto L19
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfState.INACTIVE
            return r5
        L19:
            if (r0 != 0) goto L1c
            goto L23
        L1c:
            int r1 = r0.intValue()
            r2 = 3
            if (r1 == r2) goto La3
        L23:
            if (r0 != 0) goto L26
            goto L2f
        L26:
            int r1 = r0.intValue()
            r2 = 1
            if (r1 != r2) goto L2f
            goto La3
        L2f:
            if (r0 != 0) goto L32
            goto L3c
        L32:
            int r1 = r0.intValue()
            r2 = 4
            if (r1 != r2) goto L3c
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfState.LOCKED_FOCUSED
            return r5
        L3c:
            if (r0 != 0) goto L3f
            goto L49
        L3f:
            int r1 = r0.intValue()
            r2 = 5
            if (r1 != r2) goto L49
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfState.LOCKED_NOT_FOCUSED
            return r5
        L49:
            if (r0 != 0) goto L4c
            goto L56
        L4c:
            int r1 = r0.intValue()
            r2 = 2
            if (r1 != r2) goto L56
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfState.PASSIVE_FOCUSED
            return r5
        L56:
            if (r0 != 0) goto L59
            goto L63
        L59:
            int r1 = r0.intValue()
            r2 = 6
            if (r1 != r2) goto L63
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfState.PASSIVE_NOT_FOCUSED
            return r5
        L63:
            if (r0 != 0) goto L68
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfState.UNKNOWN
            return r5
        L68:
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r1 == 0) goto La0
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unknown AF state ("
            r2.<init>(r3)
            int r0 = r0.intValue()
            r2.append(r0)
            java.lang.String r0 = ") for "
            r2.append(r0)
            long r3 = r5.mo554getFrameNumberUgla2oM()
            java.lang.String r5 = androidx.camera.camera2.pipe.FrameNumber.m560toStringimpl(r3)
            r2.append(r5)
            r5 = 33
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.d(r1, r5)
        La0:
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfState.UNKNOWN
            return r5
        La3:
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AfState.SCANNING
            return r5
    }

    private static final androidx.camera.core.impl.CameraCaptureMetaData.AwbMode getAwbMode(androidx.camera.camera2.pipe.FrameMetadata r5) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.CONTROL_AWB_MODE
            java.lang.String r1 = "CONTROL_AWB_MODE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r5.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L10
            goto L19
        L10:
            int r1 = r0.intValue()
            if (r1 != 0) goto L19
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.OFF
            return r5
        L19:
            if (r0 != 0) goto L1c
            goto L26
        L1c:
            int r1 = r0.intValue()
            r2 = 1
            if (r1 != r2) goto L26
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.AUTO
            return r5
        L26:
            if (r0 != 0) goto L29
            goto L33
        L29:
            int r1 = r0.intValue()
            r2 = 2
            if (r1 != r2) goto L33
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.INCANDESCENT
            return r5
        L33:
            if (r0 != 0) goto L36
            goto L40
        L36:
            int r1 = r0.intValue()
            r2 = 3
            if (r1 != r2) goto L40
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.FLUORESCENT
            return r5
        L40:
            if (r0 != 0) goto L43
            goto L4d
        L43:
            int r1 = r0.intValue()
            r2 = 4
            if (r1 != r2) goto L4d
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.WARM_FLUORESCENT
            return r5
        L4d:
            if (r0 != 0) goto L50
            goto L5a
        L50:
            int r1 = r0.intValue()
            r2 = 5
            if (r1 != r2) goto L5a
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.DAYLIGHT
            return r5
        L5a:
            if (r0 != 0) goto L5d
            goto L67
        L5d:
            int r1 = r0.intValue()
            r2 = 6
            if (r1 != r2) goto L67
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.CLOUDY_DAYLIGHT
            return r5
        L67:
            if (r0 != 0) goto L6a
            goto L74
        L6a:
            int r1 = r0.intValue()
            r2 = 7
            if (r1 != r2) goto L74
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.TWILIGHT
            return r5
        L74:
            if (r0 != 0) goto L77
            goto L82
        L77:
            int r1 = r0.intValue()
            r2 = 8
            if (r1 != r2) goto L82
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.SHADE
            return r5
        L82:
            if (r0 != 0) goto L87
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.UNKNOWN
            return r5
        L87:
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r1 == 0) goto Lbf
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unknown AWB mode ("
            r2.<init>(r3)
            int r0 = r0.intValue()
            r2.append(r0)
            java.lang.String r0 = ") for "
            r2.append(r0)
            long r3 = r5.mo554getFrameNumberUgla2oM()
            java.lang.String r5 = androidx.camera.camera2.pipe.FrameNumber.m560toStringimpl(r3)
            r2.append(r5)
            r5 = 33
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.d(r1, r5)
        Lbf:
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbMode.UNKNOWN
            return r5
    }

    private static final androidx.camera.core.impl.CameraCaptureMetaData.AwbState getAwbState(androidx.camera.camera2.pipe.FrameMetadata r5) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.CONTROL_AWB_STATE
            java.lang.String r1 = "CONTROL_AWB_STATE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r5.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L10
            goto L19
        L10:
            int r1 = r0.intValue()
            if (r1 != 0) goto L19
            androidx.camera.core.impl.CameraCaptureMetaData$AwbState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbState.INACTIVE
            return r5
        L19:
            if (r0 != 0) goto L1c
            goto L26
        L1c:
            int r1 = r0.intValue()
            r2 = 1
            if (r1 != r2) goto L26
            androidx.camera.core.impl.CameraCaptureMetaData$AwbState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbState.METERING
            return r5
        L26:
            if (r0 != 0) goto L29
            goto L33
        L29:
            int r1 = r0.intValue()
            r2 = 2
            if (r1 != r2) goto L33
            androidx.camera.core.impl.CameraCaptureMetaData$AwbState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbState.CONVERGED
            return r5
        L33:
            if (r0 != 0) goto L36
            goto L40
        L36:
            int r1 = r0.intValue()
            r2 = 3
            if (r1 != r2) goto L40
            androidx.camera.core.impl.CameraCaptureMetaData$AwbState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbState.LOCKED
            return r5
        L40:
            if (r0 != 0) goto L45
            androidx.camera.core.impl.CameraCaptureMetaData$AwbState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbState.UNKNOWN
            return r5
        L45:
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r1 == 0) goto L7d
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unknown AWB state ("
            r2.<init>(r3)
            int r0 = r0.intValue()
            r2.append(r0)
            java.lang.String r0 = ") for "
            r2.append(r0)
            long r3 = r5.mo554getFrameNumberUgla2oM()
            java.lang.String r5 = androidx.camera.camera2.pipe.FrameNumber.m560toStringimpl(r3)
            r2.append(r5)
            r5 = 33
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.d(r1, r5)
        L7d:
            androidx.camera.core.impl.CameraCaptureMetaData$AwbState r5 = androidx.camera.core.impl.CameraCaptureMetaData.AwbState.UNKNOWN
            return r5
    }

    private static final androidx.camera.core.impl.CameraCaptureMetaData.FlashState getFlashState(androidx.camera.camera2.pipe.FrameMetadata r5) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.FLASH_STATE
            java.lang.String r1 = "FLASH_STATE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r5.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L10
            goto L16
        L10:
            int r1 = r0.intValue()
            if (r1 == 0) goto L86
        L16:
            if (r0 != 0) goto L19
            goto L21
        L19:
            int r1 = r0.intValue()
            r2 = 1
            if (r1 != r2) goto L21
            goto L86
        L21:
            if (r0 != 0) goto L24
            goto L2e
        L24:
            int r1 = r0.intValue()
            r2 = 2
            if (r1 != r2) goto L2e
            androidx.camera.core.impl.CameraCaptureMetaData$FlashState r5 = androidx.camera.core.impl.CameraCaptureMetaData.FlashState.READY
            return r5
        L2e:
            if (r0 != 0) goto L31
            goto L38
        L31:
            int r1 = r0.intValue()
            r2 = 3
            if (r1 == r2) goto L83
        L38:
            if (r0 != 0) goto L3b
            goto L43
        L3b:
            int r1 = r0.intValue()
            r2 = 4
            if (r1 != r2) goto L43
            goto L83
        L43:
            if (r0 != 0) goto L48
            androidx.camera.core.impl.CameraCaptureMetaData$FlashState r5 = androidx.camera.core.impl.CameraCaptureMetaData.FlashState.UNKNOWN
            return r5
        L48:
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r1 == 0) goto L80
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unknown flash state ("
            r2.<init>(r3)
            int r0 = r0.intValue()
            r2.append(r0)
            java.lang.String r0 = ") for "
            r2.append(r0)
            long r3 = r5.mo554getFrameNumberUgla2oM()
            java.lang.String r5 = androidx.camera.camera2.pipe.FrameNumber.m560toStringimpl(r3)
            r2.append(r5)
            r5 = 33
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.d(r1, r5)
        L80:
            androidx.camera.core.impl.CameraCaptureMetaData$FlashState r5 = androidx.camera.core.impl.CameraCaptureMetaData.FlashState.UNKNOWN
            return r5
        L83:
            androidx.camera.core.impl.CameraCaptureMetaData$FlashState r5 = androidx.camera.core.impl.CameraCaptureMetaData.FlashState.FIRED
            return r5
        L86:
            androidx.camera.core.impl.CameraCaptureMetaData$FlashState r5 = androidx.camera.core.impl.CameraCaptureMetaData.FlashState.NONE
            return r5
    }

    private static final long getTimestamp(androidx.camera.camera2.pipe.FrameMetadata r3) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.SENSOR_TIMESTAMP
            java.lang.String r1 = "SENSOR_TIMESTAMP"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r1 = -1
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
            java.lang.Object r3 = r3.getOrDefault(r0, r1)
            java.lang.String r0 = "getOrDefault(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r0)
            java.lang.Number r3 = (java.lang.Number) r3
            long r0 = r3.longValue()
            return r0
    }

    private static final void populateExifData(androidx.camera.camera2.pipe.FrameMetadata r3, androidx.camera.core.impl.utils.ExifData.Builder r4) {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.JPEG_ORIENTATION     // Catch: java.nio.BufferUnderflowException -> L19
            java.lang.String r1 = "JPEG_ORIENTATION"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)     // Catch: java.nio.BufferUnderflowException -> L19
            java.lang.Object r0 = r3.get(r0)     // Catch: java.nio.BufferUnderflowException -> L19
            java.lang.Integer r0 = (java.lang.Integer) r0     // Catch: java.nio.BufferUnderflowException -> L19
            if (r0 == 0) goto L2c
            java.lang.Number r0 = (java.lang.Number) r0     // Catch: java.nio.BufferUnderflowException -> L19
            int r0 = r0.intValue()     // Catch: java.nio.BufferUnderflowException -> L19
            r4.setOrientationDegrees(r0)     // Catch: java.nio.BufferUnderflowException -> L19
            goto L2c
        L19:
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isWarnEnabled(r0)
            if (r0 == 0) goto L2c
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r1 = "Failed to get JPEG orientation."
            android.util.Log.w(r0, r1)
        L2c:
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.SENSOR_EXPOSURE_TIME
            java.lang.String r1 = "SENSOR_EXPOSURE_TIME"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r3.get(r0)
            java.lang.Long r0 = (java.lang.Long) r0
            if (r0 == 0) goto L44
            java.lang.Number r0 = (java.lang.Number) r0
            long r0 = r0.longValue()
            r4.setExposureTimeNanos(r0)
        L44:
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.LENS_APERTURE
            java.lang.String r1 = "LENS_APERTURE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r3.get(r0)
            java.lang.Float r0 = (java.lang.Float) r0
            if (r0 == 0) goto L5c
            java.lang.Number r0 = (java.lang.Number) r0
            float r0 = r0.floatValue()
            r4.setLensFNumber(r0)
        L5c:
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.SENSOR_SENSITIVITY
            java.lang.String r1 = "SENSOR_SENSITIVITY"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r3.get(r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 == 0) goto L92
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            r4.setIso(r0)
            android.hardware.camera2.CaptureResult$Key r1 = android.hardware.camera2.CaptureResult.CONTROL_POST_RAW_SENSITIVITY_BOOST
            java.lang.String r2 = "CONTROL_POST_RAW_SENSITIVITY_BOOST"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r1 = r3.get(r1)
            java.lang.Integer r1 = (java.lang.Integer) r1
            if (r1 == 0) goto L92
            java.lang.Number r1 = (java.lang.Number) r1
            int r1 = r1.intValue()
            float r1 = (float) r1
            r2 = 1120403456(0x42c80000, float:100.0)
            float r1 = r1 / r2
            int r1 = (int) r1
            int r0 = r0 * r1
            r4.setIso(r0)
        L92:
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.LENS_FOCAL_LENGTH
            java.lang.String r1 = "LENS_FOCAL_LENGTH"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r0 = r3.get(r0)
            java.lang.Float r0 = (java.lang.Float) r0
            if (r0 == 0) goto Laa
            java.lang.Number r0 = (java.lang.Number) r0
            float r0 = r0.floatValue()
            r4.setFocalLength(r0)
        Laa:
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.CONTROL_AWB_MODE
            java.lang.String r1 = "CONTROL_AWB_MODE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r3 = r3.get(r0)
            java.lang.Integer r3 = (java.lang.Integer) r3
            if (r3 == 0) goto Lc8
            java.lang.Number r3 = (java.lang.Number) r3
            int r3 = r3.intValue()
            androidx.camera.core.impl.utils.ExifData$WhiteBalanceMode r0 = androidx.camera.core.impl.utils.ExifData.WhiteBalanceMode.AUTO
            if (r3 != 0) goto Lc5
            androidx.camera.core.impl.utils.ExifData$WhiteBalanceMode r0 = androidx.camera.core.impl.utils.ExifData.WhiteBalanceMode.MANUAL
        Lc5:
            r4.setWhiteBalanceMode(r0)
        Lc8:
            return
    }
}
