package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraFactoryAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u0092\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u00012\u00020\u0002BG\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\b\u0010\f\u001a\u0004\u0018\u00010\r\u0012\u0006\u0010\u000e\u001a\u00020\u000f\u0012\u0006\u0010\u0010\u001a\u00020\u0011¢\u0006\u0004\b\u0012\u0010\u0013J\u0016\u0010%\u001a\u00020&2\f\u0010'\u001a\b\u0012\u0004\u0012\u00020 0(H\u0016J\u001c\u0010)\u001a\b\u0012\u0004\u0012\u00020 0(2\f\u0010'\u001a\b\u0012\u0004\u0012\u00020 0(H\u0016J\u001c\u0010*\u001a\b\u0012\u0004\u0012\u00020 0\u001f2\f\u0010'\u001a\b\u0012\u0004\u0012\u00020 0(H\u0002J\u0010\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020 H\u0016J\u000e\u0010)\u001a\b\u0012\u0004\u0012\u00020 0\u001fH\u0016J\b\u0010.\u001a\u00020/H\u0016J\b\u00100\u001a\u00020\"H\u0016J\u0014\u00101\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030(02H\u0016J\b\u00104\u001a\u00020&H\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\u0018\u001a\u00020\u00198BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001a\u0010\u001bR\u0014\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020 0\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020$X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00065"}, d2 = {"Landroidx/camera/camera2/adapter/CameraFactoryAdapter;", "Landroidx/camera/core/impl/CameraFactory;", "Landroidx/camera/core/impl/CameraFactory$Interrogator;", "lazyCameraPipe", "Lkotlin/Lazy;", "Landroidx/camera/camera2/pipe/CameraPipe;", "context", "Landroid/content/Context;", "threadConfig", "Landroidx/camera/core/impl/CameraThreadConfig;", "camera2InteropCallbacks", "Landroidx/camera/camera2/impl/CameraInteropStateCallbackRepository;", "availableCamerasSelector", "Landroidx/camera/core/CameraSelector;", "streamSpecsCalculator", "Landroidx/camera/core/internal/StreamSpecsCalculator;", "cameraXConfig", "Landroidx/camera/core/CameraXConfig;", "<init>", "(Lkotlin/Lazy;Landroid/content/Context;Landroidx/camera/core/impl/CameraThreadConfig;Landroidx/camera/camera2/impl/CameraInteropStateCallbackRepository;Landroidx/camera/core/CameraSelector;Landroidx/camera/core/internal/StreamSpecsCalculator;Landroidx/camera/core/CameraXConfig;)V", "cameraCoordinator", "Landroidx/camera/camera2/adapter/CameraCoordinatorAdapter;", "pipeCameraPresenceObservable", "Landroidx/camera/camera2/adapter/PipeCameraPresenceSource;", "appComponent", "Landroidx/camera/camera2/config/CameraAppComponent;", "getAppComponent", "()Landroidx/camera/camera2/config/CameraAppComponent;", "appComponent$delegate", "Lkotlin/Lazy;", "availableCameraIds", "", "", "lock", "", "isShutdown", "Ljava/util/concurrent/atomic/AtomicBoolean;", "onCameraIdsUpdated", "", "cameraIds", "", "getAvailableCameraIds", "calculateAvailableCameraIds", "getCamera", "Landroidx/camera/core/impl/CameraInternal;", "cameraId", "getCameraCoordinator", "Landroidx/camera/core/concurrent/CameraCoordinator;", "getCameraManager", "getCameraPresenceSource", "Landroidx/camera/core/impl/Observable;", "Landroidx/camera/core/CameraIdentifier;", "shutdown", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraFactoryAdapter implements androidx.camera.core.impl.CameraFactory, androidx.camera.core.impl.CameraFactory.Interrogator {
    private final kotlin.Lazy appComponent$delegate;
    private java.util.Set<java.lang.String> availableCameraIds;
    private final androidx.camera.core.CameraSelector availableCamerasSelector;
    private final androidx.camera.camera2.adapter.CameraCoordinatorAdapter cameraCoordinator;
    private final androidx.camera.core.CameraXConfig cameraXConfig;
    private final java.util.concurrent.atomic.AtomicBoolean isShutdown;
    private final kotlin.Lazy<androidx.camera.camera2.pipe.CameraPipe> lazyCameraPipe;
    private final java.lang.Object lock;
    private final androidx.camera.camera2.adapter.PipeCameraPresenceSource pipeCameraPresenceObservable;
    private final androidx.camera.core.internal.StreamSpecsCalculator streamSpecsCalculator;

    public static /* synthetic */ androidx.camera.camera2.config.CameraAppComponent $r8$lambda$XdM0ky82a6o_01qy6QMeRMWkwsQ(android.content.Context r0, androidx.camera.core.impl.CameraThreadConfig r1, androidx.camera.camera2.adapter.CameraFactoryAdapter r2, androidx.camera.camera2.impl.CameraInteropStateCallbackRepository r3) {
            androidx.camera.camera2.config.CameraAppComponent r0 = appComponent_delegate$lambda$0(r0, r1, r2, r3)
            return r0
    }

    public CameraFactoryAdapter(kotlin.Lazy<? extends androidx.camera.camera2.pipe.CameraPipe> r2, android.content.Context r3, androidx.camera.core.impl.CameraThreadConfig r4, androidx.camera.camera2.impl.CameraInteropStateCallbackRepository r5, androidx.camera.core.CameraSelector r6, androidx.camera.core.internal.StreamSpecsCalculator r7, androidx.camera.core.CameraXConfig r8) {
            r1 = this;
            java.lang.String r0 = "lazyCameraPipe"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "threadConfig"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "camera2InteropCallbacks"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "streamSpecsCalculator"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.String r0 = "cameraXConfig"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            r1.<init>()
            r1.lazyCameraPipe = r2
            r1.availableCamerasSelector = r6
            r1.streamSpecsCalculator = r7
            r1.cameraXConfig = r8
            androidx.camera.camera2.adapter.CameraCoordinatorAdapter r6 = new androidx.camera.camera2.adapter.CameraCoordinatorAdapter
            java.lang.Object r7 = r2.getValue()
            androidx.camera.camera2.pipe.CameraPipe r7 = (androidx.camera.camera2.pipe.CameraPipe) r7
            java.lang.Object r2 = r2.getValue()
            androidx.camera.camera2.pipe.CameraPipe r2 = (androidx.camera.camera2.pipe.CameraPipe) r2
            androidx.camera.camera2.pipe.CameraDevices r2 = r2.cameras()
            r6.<init>(r7, r2)
            r1.cameraCoordinator = r6
            androidx.camera.camera2.adapter.CameraFactoryAdapter$$ExternalSyntheticLambda0 r2 = new androidx.camera.camera2.adapter.CameraFactoryAdapter$$ExternalSyntheticLambda0
            r2.<init>(r3, r4, r1, r5)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.appComponent$delegate = r2
            java.util.Set r2 = kotlin.collections.SetsKt.emptySet()
            r1.availableCameraIds = r2
            java.lang.Object r2 = new java.lang.Object
            r2.<init>()
            r1.lock = r2
            java.util.concurrent.atomic.AtomicBoolean r2 = new java.util.concurrent.atomic.AtomicBoolean
            r5 = 0
            r2.<init>(r5)
            r1.isShutdown = r2
            androidx.camera.camera2.config.CameraAppComponent r2 = r1.getAppComponent()
            androidx.camera.camera2.pipe.CameraDevices r2 = r2.getCameraDevices()
            r5 = 0
            r6 = 1
            java.util.List r2 = androidx.camera.camera2.pipe.CameraDevices.m335awaitCameraIdsSeavPBo$default(r2, r5, r6, r5)
            if (r2 == 0) goto L9a
            java.lang.Iterable r2 = (java.lang.Iterable) r2
            java.util.ArrayList r7 = new java.util.ArrayList
            r8 = 10
            int r8 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r2, r8)
            r7.<init>(r8)
            java.util.Collection r7 = (java.util.Collection) r7
            java.util.Iterator r2 = r2.iterator()
        L83:
            boolean r8 = r2.hasNext()
            if (r8 == 0) goto L97
            java.lang.Object r8 = r2.next()
            androidx.camera.camera2.pipe.CameraId r8 = (androidx.camera.camera2.pipe.CameraId) r8
            java.lang.String r8 = r8.m457unboximpl()
            r7.add(r8)
            goto L83
        L97:
            java.util.List r7 = (java.util.List) r7
            goto L9e
        L9a:
            java.util.List r7 = kotlin.collections.CollectionsKt.emptyList()
        L9e:
            androidx.camera.camera2.adapter.PipeCameraPresenceSource r2 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource
            kotlin.Lazy<androidx.camera.camera2.pipe.CameraPipe> r8 = r1.lazyCameraPipe
            java.lang.Object r8 = r8.getValue()
            androidx.camera.camera2.pipe.CameraPipe r8 = (androidx.camera.camera2.pipe.CameraPipe) r8
            androidx.camera.camera2.pipe.CameraDevices r8 = r8.cameras()
            kotlinx.coroutines.flow.Flow r5 = androidx.camera.camera2.pipe.CameraDevices.m338cameraIdsFlowSeavPBo$default(r8, r5, r6, r5)
            java.util.concurrent.Executor r4 = r4.getCameraExecutor()
            java.lang.String r6 = "getCameraExecutor(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r6)
            kotlinx.coroutines.CoroutineDispatcher r4 = kotlinx.coroutines.ExecutorsKt.from(r4)
            kotlin.coroutines.CoroutineContext r4 = (kotlin.coroutines.CoroutineContext) r4
            kotlinx.coroutines.CoroutineScope r4 = kotlinx.coroutines.CoroutineScopeKt.CoroutineScope(r4)
            r2.<init>(r5, r4, r7, r3)
            r1.pipeCameraPresenceObservable = r2
            r1.onCameraIdsUpdated(r7)
            return
    }

    public static final /* synthetic */ java.util.Set access$getAvailableCameraIds$p(androidx.camera.camera2.adapter.CameraFactoryAdapter r0) {
            java.util.Set<java.lang.String> r0 = r0.availableCameraIds
            return r0
    }

    private static final androidx.camera.camera2.config.CameraAppComponent appComponent_delegate$lambda$0(android.content.Context r11, androidx.camera.core.impl.CameraThreadConfig r12, androidx.camera.camera2.adapter.CameraFactoryAdapter r13, androidx.camera.camera2.impl.CameraInteropStateCallbackRepository r14) {
            androidx.camera.camera2.pipe.core.Debug r0 = androidx.camera.camera2.pipe.core.Debug.INSTANCE
            java.lang.String r0 = "CameraFactoryAdapter#appComponent"
            android.os.Trace.beginSection(r0)
            androidx.camera.camera2.pipe.core.SystemTimeSource r0 = new androidx.camera.camera2.pipe.core.SystemTimeSource
            r0.<init>()
            androidx.camera.camera2.pipe.core.Timestamps r1 = androidx.camera.camera2.pipe.core.Timestamps.INSTANCE
            androidx.camera.camera2.pipe.core.TimeSource r0 = (androidx.camera.camera2.pipe.core.TimeSource) r0
            long r1 = r0.mo987nowvQl9yQU()
            androidx.camera.camera2.config.CameraAppComponent$Builder r3 = androidx.camera.camera2.config.DaggerCameraAppComponent.builder()
            androidx.camera.camera2.config.CameraAppConfig r4 = new androidx.camera.camera2.config.CameraAppConfig
            kotlin.Lazy<androidx.camera.camera2.pipe.CameraPipe> r5 = r13.lazyCameraPipe
            java.lang.Object r5 = r5.getValue()
            r7 = r5
            androidx.camera.camera2.pipe.CameraPipe r7 = (androidx.camera.camera2.pipe.CameraPipe) r7
            androidx.camera.camera2.adapter.CameraCoordinatorAdapter r5 = r13.cameraCoordinator
            r9 = r5
            androidx.camera.core.concurrent.CameraCoordinator r9 = (androidx.camera.core.concurrent.CameraCoordinator) r9
            androidx.camera.core.CameraXConfig r10 = r13.cameraXConfig
            r5 = r11
            r6 = r12
            r8 = r14
            r4.<init>(r5, r6, r7, r8, r9, r10)
            androidx.camera.camera2.config.CameraAppComponent$Builder r11 = r3.config(r4)
            androidx.camera.camera2.config.CameraAppComponent r11 = r11.build()
            androidx.camera.camera2.impl.Camera2Logger r12 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r12 = "CXCP"
            boolean r12 = androidx.camera.core.Logger.isDebugEnabled(r12)
            if (r12 == 0) goto L84
            java.lang.String r12 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            java.lang.String r14 = "Created CameraFactoryAdapter in "
            r13.<init>(r14)
            androidx.camera.camera2.pipe.core.Timestamps r14 = androidx.camera.camera2.pipe.core.Timestamps.INSTANCE
            androidx.camera.camera2.pipe.core.Timestamps r14 = androidx.camera.camera2.pipe.core.Timestamps.INSTANCE
            long r3 = r0.mo987nowvQl9yQU()
            long r3 = r3 - r1
            long r0 = androidx.camera.camera2.pipe.core.DurationNs.m974constructorimpl(r3)
            double r0 = (double) r0
            r2 = 4696837146684686336(0x412e848000000000, double:1000000.0)
            double r0 = r0 / r2
            java.lang.Double r14 = java.lang.Double.valueOf(r0)
            java.lang.Object[] r14 = new java.lang.Object[]{r14}
            r0 = 1
            java.lang.Object[] r14 = java.util.Arrays.copyOf(r14, r0)
            r0 = 0
            java.lang.String r1 = "%.3f ms"
            java.lang.String r14 = java.lang.String.format(r0, r1, r14)
            java.lang.String r0 = "format(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r14, r0)
            r13.append(r14)
            java.lang.String r13 = r13.toString()
            android.util.Log.d(r12, r13)
        L84:
            androidx.camera.camera2.pipe.core.Debug r12 = androidx.camera.camera2.pipe.core.Debug.INSTANCE
            android.os.Trace.endSection()
            return r11
    }

    private final java.util.Set<java.lang.String> calculateAvailableCameraIds(java.util.List<java.lang.String> r5) {
            r4 = this;
            androidx.camera.camera2.internal.CameraSelectionOptimizer$Companion r0 = androidx.camera.camera2.internal.CameraSelectionOptimizer.Companion
            androidx.camera.camera2.config.CameraAppComponent r1 = r4.getAppComponent()
            androidx.camera.core.CameraSelector r2 = r4.availableCamerasSelector
            java.lang.Iterable r5 = (java.lang.Iterable) r5
            java.util.List r5 = kotlin.collections.CollectionsKt.toList(r5)
            androidx.camera.core.internal.StreamSpecsCalculator r3 = r4.streamSpecsCalculator
            java.util.List r5 = r0.getSelectedAvailableCameraIds(r1, r2, r5, r3)
            java.util.LinkedHashSet r0 = new java.util.LinkedHashSet
            androidx.camera.camera2.config.CameraAppComponent r1 = r4.getAppComponent()
            androidx.camera.camera2.pipe.CameraDevices r1 = r1.getCameraDevices()
            java.util.List r5 = androidx.camera.camera2.internal.CameraCompatibilityFilter.getBackwardCompatibleCameraIds(r1, r5)
            java.util.Collection r5 = (java.util.Collection) r5
            r0.<init>(r5)
            java.util.Set r0 = (java.util.Set) r0
            return r0
    }

    private final androidx.camera.camera2.config.CameraAppComponent getAppComponent() {
            r1 = this;
            kotlin.Lazy r0 = r1.appComponent$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.camera.camera2.config.CameraAppComponent r0 = (androidx.camera.camera2.config.CameraAppComponent) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraFactory.Interrogator
    public java.util.List<java.lang.String> getAvailableCameraIds(java.util.List<java.lang.String> r2) {
            r1 = this;
            java.lang.String r0 = "cameraIds"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.util.concurrent.atomic.AtomicBoolean r0 = r1.isShutdown
            boolean r0 = r0.get()
            if (r0 == 0) goto L12
            java.util.List r2 = kotlin.collections.CollectionsKt.emptyList()
            return r2
        L12:
            java.util.Set r2 = r1.calculateAvailableCameraIds(r2)
            java.lang.Iterable r2 = (java.lang.Iterable) r2
            java.util.List r2 = kotlin.collections.CollectionsKt.toList(r2)
            return r2
    }

    @Override // androidx.camera.core.impl.CameraFactory
    public java.util.Set<java.lang.String> getAvailableCameraIds() {
            r3 = this;
            java.lang.Object r0 = r3.lock
            monitor-enter(r0)
            java.util.concurrent.atomic.AtomicBoolean r1 = r3.isShutdown     // Catch: java.lang.Throwable -> L1e
            boolean r1 = r1.get()     // Catch: java.lang.Throwable -> L1e
            if (r1 == 0) goto L11
            java.util.Set r1 = kotlin.collections.SetsKt.emptySet()     // Catch: java.lang.Throwable -> L1e
            monitor-exit(r0)
            return r1
        L11:
            java.util.LinkedHashSet r1 = new java.util.LinkedHashSet     // Catch: java.lang.Throwable -> L1e
            java.util.Set<java.lang.String> r2 = r3.availableCameraIds     // Catch: java.lang.Throwable -> L1e
            java.util.Collection r2 = (java.util.Collection) r2     // Catch: java.lang.Throwable -> L1e
            r1.<init>(r2)     // Catch: java.lang.Throwable -> L1e
            monitor-exit(r0)
            java.util.Set r1 = (java.util.Set) r1
            return r1
        L1e:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    @Override // androidx.camera.core.impl.CameraFactory
    public androidx.camera.core.impl.CameraInternal getCamera(java.lang.String r4) {
            r3 = this;
            java.lang.String r0 = "cameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.util.concurrent.atomic.AtomicBoolean r0 = r3.isShutdown
            boolean r0 = r0.get()
            if (r0 != 0) goto L32
            androidx.camera.camera2.config.CameraAppComponent r0 = r3.getAppComponent()
            androidx.camera.camera2.config.CameraComponent$Builder r0 = r0.cameraBuilder()
            androidx.camera.camera2.config.CameraConfig r1 = new androidx.camera.camera2.config.CameraConfig
            java.lang.String r4 = androidx.camera.camera2.pipe.CameraId.m451constructorimpl(r4)
            r2 = 0
            r1.<init>(r4, r2)
            androidx.camera.camera2.config.CameraComponent$Builder r4 = r0.config(r1)
            androidx.camera.core.internal.StreamSpecsCalculator r0 = r3.streamSpecsCalculator
            androidx.camera.camera2.config.CameraComponent$Builder r4 = r4.streamSpecsCalculator(r0)
            androidx.camera.camera2.config.CameraComponent r4 = r4.build()
            androidx.camera.core.impl.CameraInternal r4 = r4.getCameraInternal()
            return r4
        L32:
            androidx.camera.core.impl.CameraUpdateException r4 = new androidx.camera.core.impl.CameraUpdateException
            java.lang.String r0 = "CameraFactory has been shut down."
            r4.<init>(r0)
            throw r4
    }

    @Override // androidx.camera.core.impl.CameraFactory
    public androidx.camera.core.concurrent.CameraCoordinator getCameraCoordinator() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraCoordinatorAdapter r0 = r1.cameraCoordinator
            androidx.camera.core.concurrent.CameraCoordinator r0 = (androidx.camera.core.concurrent.CameraCoordinator) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraFactory
    public java.lang.Object getCameraManager() {
            r1 = this;
            androidx.camera.camera2.config.CameraAppComponent r0 = r1.getAppComponent()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraFactory
    public androidx.camera.core.impl.Observable<java.util.List<androidx.camera.core.CameraIdentifier>> getCameraPresenceSource() {
            r1 = this;
            androidx.camera.camera2.adapter.PipeCameraPresenceSource r0 = r1.pipeCameraPresenceObservable
            androidx.camera.core.impl.Observable r0 = (androidx.camera.core.impl.Observable) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraPresenceMonitor
    public void onCameraIdsUpdated(java.util.List<java.lang.String> r5) {
            r4 = this;
            java.lang.String r0 = "Updated available camera list: "
            java.lang.String r1 = "cameraIds"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r1)
            java.util.concurrent.atomic.AtomicBoolean r1 = r4.isShutdown
            boolean r1 = r1.get()
            if (r1 == 0) goto L10
            return
        L10:
            java.util.Set r5 = r4.calculateAvailableCameraIds(r5)
            java.lang.Object r1 = r4.lock
            monitor-enter(r1)
            java.util.concurrent.atomic.AtomicBoolean r2 = r4.isShutdown     // Catch: java.lang.Throwable -> L5a
            boolean r2 = r2.get()     // Catch: java.lang.Throwable -> L5a
            if (r2 == 0) goto L21
            monitor-exit(r1)
            return
        L21:
            java.util.Set<java.lang.String> r2 = r4.availableCameraIds     // Catch: java.lang.Throwable -> L5a
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r5)     // Catch: java.lang.Throwable -> L5a
            if (r2 == 0) goto L2b
            monitor-exit(r1)
            return
        L2b:
            androidx.camera.camera2.impl.Camera2Logger r2 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Throwable -> L5a
            java.lang.String r2 = "CXCP"
            boolean r2 = androidx.camera.core.Logger.isDebugEnabled(r2)     // Catch: java.lang.Throwable -> L5a
            if (r2 == 0) goto L54
            java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Throwable -> L5a
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L5a
            r3.<init>(r0)     // Catch: java.lang.Throwable -> L5a
            java.util.Set r0 = access$getAvailableCameraIds$p(r4)     // Catch: java.lang.Throwable -> L5a
            r3.append(r0)     // Catch: java.lang.Throwable -> L5a
            java.lang.String r0 = " -> "
            r3.append(r0)     // Catch: java.lang.Throwable -> L5a
            r3.append(r5)     // Catch: java.lang.Throwable -> L5a
            java.lang.String r0 = r3.toString()     // Catch: java.lang.Throwable -> L5a
            android.util.Log.d(r2, r0)     // Catch: java.lang.Throwable -> L5a
        L54:
            r4.availableCameraIds = r5     // Catch: java.lang.Throwable -> L5a
            kotlin.Unit r5 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L5a
            monitor-exit(r1)
            return
        L5a:
            r5 = move-exception
            monitor-exit(r1)
            throw r5
    }

    @Override // androidx.camera.core.impl.CameraFactory
    public void shutdown() {
            r2 = this;
            java.util.concurrent.atomic.AtomicBoolean r0 = r2.isShutdown
            r1 = 1
            boolean r0 = r0.getAndSet(r1)
            if (r0 == 0) goto La
            goto L27
        La:
            androidx.camera.camera2.adapter.CameraCoordinatorAdapter r0 = r2.cameraCoordinator
            r0.shutdown()
            androidx.camera.camera2.adapter.PipeCameraPresenceSource r0 = r2.pipeCameraPresenceObservable
            r0.stopMonitoring()
            kotlin.Lazy<androidx.camera.camera2.pipe.CameraPipe> r0 = r2.lazyCameraPipe
            boolean r0 = r0.isInitialized()
            if (r0 == 0) goto L27
            kotlin.Lazy<androidx.camera.camera2.pipe.CameraPipe> r0 = r2.lazyCameraPipe
            java.lang.Object r0 = r0.getValue()
            androidx.camera.camera2.pipe.CameraPipe r0 = (androidx.camera.camera2.pipe.CameraPipe) r0
            r0.shutdown()
        L27:
            return
    }
}
