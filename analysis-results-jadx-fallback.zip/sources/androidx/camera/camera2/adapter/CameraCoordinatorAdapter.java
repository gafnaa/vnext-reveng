package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraCoordinatorAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010 \n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u00012\u00020\u0002B\u0019\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bJ\u0010\u0010=\u001a\u00020>2\u0006\u0010?\u001a\u00020\fH\u0016J\u0016\u0010@\u001a\u00020>2\f\u0010A\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001eH\u0016J\u0014\u0010B\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020C0\u001e0\u001eH\u0016J\u000e\u0010D\u001a\b\u0012\u0004\u0012\u00020%0\u001eH\u0016J\u0010\u0010E\u001a\u00020>2\u0006\u0010F\u001a\u00020%H\u0016J\u0010\u0010G\u001a\u00020>2\u0006\u0010F\u001a\u00020%H\u0016J\u0016\u0010H\u001a\u00020>2\f\u0010I\u001a\b\u0012\u0004\u0012\u00020%0\u001eH\u0016J\b\u0010J\u001a\u00020>H\u0002J\u0012\u0010K\u001a\u0004\u0018\u00010\u001d2\u0006\u0010L\u001a\u00020\u001dH\u0016J\b\u0010M\u001a\u000200H\u0016J\u0010\u0010N\u001a\u00020>2\u0006\u0010O\u001a\u000200H\u0016J\u0010\u0010P\u001a\u00020>2\u0006\u0010Q\u001a\u00020RH\u0016J\u0010\u0010S\u001a\u00020>2\u0006\u0010Q\u001a\u00020RH\u0016J\b\u0010T\u001a\u00020>H\u0016R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R&\u0010\u000b\u001a\u0004\u0018\u00010\f8\u0006@\u0006X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b\r\u0010\u000e\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R0\u0010\u0013\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00150\u00140\u00148\u0006@\u0006X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b\u0016\u0010\u000e\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR6\u0010\u001b\u001a\u0014\u0012\u0004\u0012\u00020\u001d\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001d0\u001e0\u001c8\u0006@\u0006X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b\u001f\u0010\u000e\u001a\u0004\b \u0010!\"\u0004\b\"\u0010#R*\u0010$\u001a\b\u0012\u0004\u0012\u00020%0\u001e8\u0006@\u0006X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b&\u0010\u000e\u001a\u0004\b'\u0010(\"\u0004\b)\u0010*R$\u0010+\u001a\b\u0012\u0004\u0012\u00020\u001d0,8\u0006@\u0006X\u0087\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b-\u0010(\"\u0004\b.\u0010*R$\u0010/\u001a\u0002008\u0006@\u0006X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b1\u0010\u000e\u001a\u0004\b2\u00103\"\u0004\b4\u00105R$\u00106\u001a\u0002078\u0006@\u0006X\u0087\u000e¢\u0006\u0014\n\u0000\u0012\u0004\b8\u0010\u000e\u001a\u0004\b9\u0010:\"\u0004\b;\u0010<¨\u0006U"}, d2 = {"Landroidx/camera/camera2/adapter/CameraCoordinatorAdapter;", "Landroidx/camera/core/concurrent/CameraCoordinator;", "Landroidx/camera/core/impl/InternalCameraPresenceListener;", "cameraPipe", "Landroidx/camera/camera2/pipe/CameraPipe;", "cameraDevices", "Landroidx/camera/camera2/pipe/CameraDevices;", "<init>", "(Landroidx/camera/camera2/pipe/CameraPipe;Landroidx/camera/camera2/pipe/CameraDevices;)V", "lock", "", "cameraRepository", "Landroidx/camera/core/impl/CameraRepository;", "getCameraRepository$annotations", "()V", "getCameraRepository", "()Landroidx/camera/core/impl/CameraRepository;", "setCameraRepository", "(Landroidx/camera/core/impl/CameraRepository;)V", "concurrentCameraIdsSet", "", "Landroidx/camera/camera2/pipe/CameraId;", "getConcurrentCameraIdsSet$annotations", "getConcurrentCameraIdsSet", "()Ljava/util/Set;", "setConcurrentCameraIdsSet", "(Ljava/util/Set;)V", "concurrentCameraIdMap", "", "", "", "getConcurrentCameraIdMap$annotations", "getConcurrentCameraIdMap", "()Ljava/util/Map;", "setConcurrentCameraIdMap", "(Ljava/util/Map;)V", "activeConcurrentCameraInfosList", "Landroidx/camera/core/CameraInfo;", "getActiveConcurrentCameraInfosList$annotations", "getActiveConcurrentCameraInfosList", "()Ljava/util/List;", "setActiveConcurrentCameraInfosList", "(Ljava/util/List;)V", "pendingCameraIds", "", "getPendingCameraIds", "setPendingCameraIds", "concurrentMode", "", "getConcurrentMode$annotations", "getConcurrentMode", "()I", "setConcurrentMode", "(I)V", "concurrentModeOn", "", "getConcurrentModeOn$annotations", "getConcurrentModeOn", "()Z", "setConcurrentModeOn", "(Z)V", "init", "", "repository", "onCamerasUpdated", "cameraIds", "getConcurrentCameraSelectors", "Landroidx/camera/core/CameraSelector;", "getActiveConcurrentCameraInfos", "addPendingCameraInfo", "cameraInfo", "removePendingCameraInfo", "setActiveConcurrentCameraInfos", "cameraInfos", "tryStartConcurrentGraph", "getPairedConcurrentCameraId", "cameraId", "getCameraOperatingMode", "setCameraOperatingMode", "cameraOperatingMode", "addListener", "listener", "Landroidx/camera/core/concurrent/CameraCoordinator$ConcurrentCameraModeListener;", "removeListener", "shutdown", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraCoordinatorAdapter implements androidx.camera.core.concurrent.CameraCoordinator, androidx.camera.core.impl.InternalCameraPresenceListener {
    private java.util.List<? extends androidx.camera.core.CameraInfo> activeConcurrentCameraInfosList;
    private final androidx.camera.camera2.pipe.CameraDevices cameraDevices;
    private androidx.camera.camera2.pipe.CameraPipe cameraPipe;
    private androidx.camera.core.impl.CameraRepository cameraRepository;
    private java.util.Map<java.lang.String, ? extends java.util.List<java.lang.String>> concurrentCameraIdMap;
    private java.util.Set<? extends java.util.Set<androidx.camera.camera2.pipe.CameraId>> concurrentCameraIdsSet;
    private int concurrentMode;
    private boolean concurrentModeOn;
    private final java.lang.Object lock;
    private java.util.List<java.lang.String> pendingCameraIds;

    public CameraCoordinatorAdapter(androidx.camera.camera2.pipe.CameraPipe r2, androidx.camera.camera2.pipe.CameraDevices r3) {
            r1 = this;
            java.lang.String r0 = "cameraDevices"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r1.<init>()
            r1.cameraPipe = r2
            r1.cameraDevices = r3
            java.lang.Object r2 = new java.lang.Object
            r2.<init>()
            r1.lock = r2
            java.util.Set r2 = kotlin.collections.SetsKt.emptySet()
            r1.concurrentCameraIdsSet = r2
            java.util.Map r2 = kotlin.collections.MapsKt.emptyMap()
            r1.concurrentCameraIdMap = r2
            java.util.List r2 = kotlin.collections.CollectionsKt.emptyList()
            r1.activeConcurrentCameraInfosList = r2
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.List r2 = (java.util.List) r2
            r1.pendingCameraIds = r2
            return
    }

    public static /* synthetic */ void getActiveConcurrentCameraInfosList$annotations() {
            return
    }

    public static /* synthetic */ void getCameraRepository$annotations() {
            return
    }

    public static /* synthetic */ void getConcurrentCameraIdMap$annotations() {
            return
    }

    public static /* synthetic */ void getConcurrentCameraIdsSet$annotations() {
            return
    }

    public static /* synthetic */ void getConcurrentMode$annotations() {
            return
    }

    public static /* synthetic */ void getConcurrentModeOn$annotations() {
            return
    }

    private final void tryStartConcurrentGraph() {
            r8 = this;
            java.lang.Object r0 = r8.lock
            monitor-enter(r0)
            java.util.List<? extends androidx.camera.core.CameraInfo> r1 = r8.activeConcurrentCameraInfosList     // Catch: java.lang.Throwable -> L158
            boolean r1 = r1.isEmpty()     // Catch: java.lang.Throwable -> L158
            if (r1 != 0) goto L156
            java.util.List<java.lang.String> r1 = r8.pendingCameraIds     // Catch: java.lang.Throwable -> L158
            boolean r1 = r1.isEmpty()     // Catch: java.lang.Throwable -> L158
            if (r1 == 0) goto L15
            goto L156
        L15:
            java.util.List<? extends androidx.camera.core.CameraInfo> r1 = r8.activeConcurrentCameraInfosList     // Catch: java.lang.Throwable -> L158
            java.lang.Iterable r1 = (java.lang.Iterable) r1     // Catch: java.lang.Throwable -> L158
            java.util.ArrayList r2 = new java.util.ArrayList     // Catch: java.lang.Throwable -> L158
            r3 = 10
            int r4 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r1, r3)     // Catch: java.lang.Throwable -> L158
            r2.<init>(r4)     // Catch: java.lang.Throwable -> L158
            java.util.Collection r2 = (java.util.Collection) r2     // Catch: java.lang.Throwable -> L158
            java.util.Iterator r1 = r1.iterator()     // Catch: java.lang.Throwable -> L158
        L2a:
            boolean r4 = r1.hasNext()     // Catch: java.lang.Throwable -> L158
            r5 = 0
            if (r4 == 0) goto L59
            java.lang.Object r4 = r1.next()     // Catch: java.lang.Throwable -> L158
            androidx.camera.core.CameraInfo r4 = (androidx.camera.core.CameraInfo) r4     // Catch: java.lang.Throwable -> L158
            androidx.camera.camera2.adapter.CameraInfoAdapter$Companion r6 = androidx.camera.camera2.adapter.CameraInfoAdapter.Companion     // Catch: java.lang.Throwable -> L158
            java.lang.String r4 = r6.m63getCameraIdzjxgSG8(r4)     // Catch: java.lang.Throwable -> L158
            if (r4 == 0) goto L43
            androidx.camera.camera2.pipe.CameraId r5 = androidx.camera.camera2.pipe.CameraId.m450boximpl(r4)     // Catch: java.lang.Throwable -> L158
        L43:
            if (r5 == 0) goto L4d
            java.lang.String r4 = r5.m457unboximpl()     // Catch: java.lang.Throwable -> L158
            r2.add(r4)     // Catch: java.lang.Throwable -> L158
            goto L2a
        L4d:
            java.lang.String r1 = "Required value was null."
            java.lang.IllegalStateException r2 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L158
            java.lang.String r1 = r1.toString()     // Catch: java.lang.Throwable -> L158
            r2.<init>(r1)     // Catch: java.lang.Throwable -> L158
            throw r2     // Catch: java.lang.Throwable -> L158
        L59:
            java.util.List r2 = (java.util.List) r2     // Catch: java.lang.Throwable -> L158
            java.lang.Iterable r2 = (java.lang.Iterable) r2     // Catch: java.lang.Throwable -> L158
            java.util.Set r1 = kotlin.collections.CollectionsKt.toSet(r2)     // Catch: java.lang.Throwable -> L158
            java.util.List<java.lang.String> r2 = r8.pendingCameraIds     // Catch: java.lang.Throwable -> L158
            java.lang.Iterable r2 = (java.lang.Iterable) r2     // Catch: java.lang.Throwable -> L158
            java.util.Set r2 = kotlin.collections.CollectionsKt.toSet(r2)     // Catch: java.lang.Throwable -> L158
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r2)     // Catch: java.lang.Throwable -> L158
            if (r1 != 0) goto L71
            monitor-exit(r0)
            return
        L71:
            java.util.List<java.lang.String> r1 = r8.pendingCameraIds     // Catch: java.lang.Throwable -> L158
            r1.clear()     // Catch: java.lang.Throwable -> L158
            java.util.List<? extends androidx.camera.core.CameraInfo> r1 = r8.activeConcurrentCameraInfosList     // Catch: java.lang.Throwable -> L158
            monitor-exit(r0)
            java.lang.Object r0 = r8.lock
            monitor-enter(r0)
            androidx.camera.core.impl.CameraRepository r2 = r8.cameraRepository     // Catch: java.lang.Throwable -> L153
            if (r2 != 0) goto L95
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Throwable -> L153
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isErrorEnabled(r1)     // Catch: java.lang.Throwable -> L153
            if (r1 == 0) goto L93
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Throwable -> L153
            java.lang.String r2 = "Coordinator has not been initialized with a CameraRepository."
            android.util.Log.e(r1, r2)     // Catch: java.lang.Throwable -> L153
        L93:
            monitor-exit(r0)
            return
        L95:
            java.lang.Iterable r1 = (java.lang.Iterable) r1     // Catch: java.lang.Throwable -> L153
            java.util.ArrayList r4 = new java.util.ArrayList     // Catch: java.lang.Throwable -> L153
            r4.<init>()     // Catch: java.lang.Throwable -> L153
            java.util.Collection r4 = (java.util.Collection) r4     // Catch: java.lang.Throwable -> L153
            java.util.Iterator r1 = r1.iterator()     // Catch: java.lang.Throwable -> L153
        La2:
            boolean r6 = r1.hasNext()     // Catch: java.lang.Throwable -> L153
            if (r6 == 0) goto Lc9
            java.lang.Object r6 = r1.next()     // Catch: java.lang.Throwable -> L153
            androidx.camera.core.CameraInfo r6 = (androidx.camera.core.CameraInfo) r6     // Catch: java.lang.Throwable -> L153
            androidx.camera.camera2.adapter.CameraInfoAdapter$Companion r7 = androidx.camera.camera2.adapter.CameraInfoAdapter.Companion     // Catch: java.lang.IllegalArgumentException -> Lc2 java.lang.Throwable -> L153
            java.lang.String r6 = r7.m63getCameraIdzjxgSG8(r6)     // Catch: java.lang.IllegalArgumentException -> Lc2 java.lang.Throwable -> L153
            kotlin.jvm.internal.Intrinsics.checkNotNull(r6)     // Catch: java.lang.IllegalArgumentException -> Lc2 java.lang.Throwable -> L153
            androidx.camera.core.impl.CameraInternal r6 = r2.getCamera(r6)     // Catch: java.lang.IllegalArgumentException -> Lc2 java.lang.Throwable -> L153
            boolean r7 = r6 instanceof androidx.camera.camera2.adapter.CameraInternalAdapter     // Catch: java.lang.IllegalArgumentException -> Lc2 java.lang.Throwable -> L153
            if (r7 == 0) goto Lc2
            androidx.camera.camera2.adapter.CameraInternalAdapter r6 = (androidx.camera.camera2.adapter.CameraInternalAdapter) r6     // Catch: java.lang.IllegalArgumentException -> Lc2 java.lang.Throwable -> L153
            goto Lc3
        Lc2:
            r6 = r5
        Lc3:
            if (r6 == 0) goto La2
            r4.add(r6)     // Catch: java.lang.Throwable -> L153
            goto La2
        Lc9:
            java.util.List r4 = (java.util.List) r4     // Catch: java.lang.Throwable -> L153
            monitor-exit(r0)
            java.lang.Iterable r4 = (java.lang.Iterable) r4
            java.util.ArrayList r0 = new java.util.ArrayList
            int r1 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r4, r3)
            r0.<init>(r1)
            java.util.Collection r0 = (java.util.Collection) r0
            java.util.Iterator r1 = r4.iterator()
        Ldd:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto Lff
            java.lang.Object r2 = r1.next()
            androidx.camera.camera2.adapter.CameraInternalAdapter r2 = (androidx.camera.camera2.adapter.CameraInternalAdapter) r2
            androidx.camera.camera2.pipe.CameraGraph$Config r2 = r2.getDeferredCameraGraphConfig$camera_camera2()
            if (r2 == 0) goto Lf3
            r0.add(r2)
            goto Ldd
        Lf3:
            java.lang.String r0 = "Every CameraInternal instance is expected to have a deferred CameraGraph config"
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        Lff:
            java.util.List r0 = (java.util.List) r0
            androidx.camera.camera2.pipe.CameraPipe r1 = r8.cameraPipe
            if (r1 == 0) goto L147
            androidx.camera.camera2.pipe.CameraGraph$ConcurrentConfig r2 = new androidx.camera.camera2.pipe.CameraGraph$ConcurrentConfig
            r2.<init>(r0)
            java.util.List r1 = r1.createCameraGraphs(r2)
            int r2 = r1.size()
            int r0 = r0.size()
            if (r2 != r0) goto L13f
            java.lang.Iterable r1 = (java.lang.Iterable) r1
            java.util.List r0 = kotlin.collections.CollectionsKt.zip(r4, r1)
            java.util.Iterator r0 = r0.iterator()
        L122:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L13e
            java.lang.Object r1 = r0.next()
            kotlin.Pair r1 = (kotlin.Pair) r1
            java.lang.Object r2 = r1.component1()
            androidx.camera.camera2.adapter.CameraInternalAdapter r2 = (androidx.camera.camera2.adapter.CameraInternalAdapter) r2
            java.lang.Object r1 = r1.component2()
            androidx.camera.camera2.pipe.CameraGraph r1 = (androidx.camera.camera2.pipe.CameraGraph) r1
            r2.resumeDeferredCameraGraphCreation$camera_camera2(r1)
            goto L122
        L13e:
            return
        L13f:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Check failed."
            r0.<init>(r1)
            throw r0
        L147:
            java.lang.String r0 = "Required value was null."
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
        L153:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        L156:
            monitor-exit(r0)
            return
        L158:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public void addListener(androidx.camera.core.concurrent.CameraCoordinator.ConcurrentCameraModeListener r2) {
            r1 = this;
            java.lang.String r0 = "listener"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            return
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public void addPendingCameraInfo(androidx.camera.core.CameraInfo r4) {
            r3 = this;
            java.lang.String r0 = "cameraInfo"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.Object r0 = r3.lock
            monitor-enter(r0)
            boolean r1 = r3.concurrentModeOn     // Catch: java.lang.Throwable -> L39
            if (r1 == 0) goto L35
            java.util.List<java.lang.String> r1 = r3.pendingCameraIds     // Catch: java.lang.Throwable -> L39
            androidx.camera.camera2.adapter.CameraInfoAdapter$Companion r2 = androidx.camera.camera2.adapter.CameraInfoAdapter.Companion     // Catch: java.lang.Throwable -> L39
            java.lang.String r4 = r2.m63getCameraIdzjxgSG8(r4)     // Catch: java.lang.Throwable -> L39
            if (r4 == 0) goto L1b
            androidx.camera.camera2.pipe.CameraId r4 = androidx.camera.camera2.pipe.CameraId.m450boximpl(r4)     // Catch: java.lang.Throwable -> L39
            goto L1c
        L1b:
            r4 = 0
        L1c:
            if (r4 == 0) goto L29
            java.lang.String r4 = r4.m457unboximpl()     // Catch: java.lang.Throwable -> L39
            r1.add(r4)     // Catch: java.lang.Throwable -> L39
            r3.tryStartConcurrentGraph()     // Catch: java.lang.Throwable -> L39
            goto L35
        L29:
            java.lang.String r4 = "Required value was null."
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L39
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Throwable -> L39
            r1.<init>(r4)     // Catch: java.lang.Throwable -> L39
            throw r1     // Catch: java.lang.Throwable -> L39
        L35:
            kotlin.Unit r4 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L39
            monitor-exit(r0)
            return
        L39:
            r4 = move-exception
            monitor-exit(r0)
            throw r4
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public java.util.List<androidx.camera.core.CameraInfo> getActiveConcurrentCameraInfos() {
            r3 = this;
            java.lang.Object r0 = r3.lock
            monitor-enter(r0)
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch: java.lang.Throwable -> L10
            java.util.List<? extends androidx.camera.core.CameraInfo> r2 = r3.activeConcurrentCameraInfosList     // Catch: java.lang.Throwable -> L10
            java.util.Collection r2 = (java.util.Collection) r2     // Catch: java.lang.Throwable -> L10
            r1.<init>(r2)     // Catch: java.lang.Throwable -> L10
            java.util.List r1 = (java.util.List) r1     // Catch: java.lang.Throwable -> L10
            monitor-exit(r0)
            return r1
        L10:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    public final java.util.List<androidx.camera.core.CameraInfo> getActiveConcurrentCameraInfosList() {
            r1 = this;
            java.util.List<? extends androidx.camera.core.CameraInfo> r0 = r1.activeConcurrentCameraInfosList
            return r0
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public int getCameraOperatingMode() {
            r2 = this;
            java.lang.Object r0 = r2.lock
            monitor-enter(r0)
            int r1 = r2.concurrentMode     // Catch: java.lang.Throwable -> L7
            monitor-exit(r0)
            return r1
        L7:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    public final androidx.camera.core.impl.CameraRepository getCameraRepository() {
            r1 = this;
            androidx.camera.core.impl.CameraRepository r0 = r1.cameraRepository
            return r0
    }

    public final java.util.Map<java.lang.String, java.util.List<java.lang.String>> getConcurrentCameraIdMap() {
            r1 = this;
            java.util.Map<java.lang.String, ? extends java.util.List<java.lang.String>> r0 = r1.concurrentCameraIdMap
            return r0
    }

    public final java.util.Set<java.util.Set<androidx.camera.camera2.pipe.CameraId>> getConcurrentCameraIdsSet() {
            r1 = this;
            java.util.Set<? extends java.util.Set<androidx.camera.camera2.pipe.CameraId>> r0 = r1.concurrentCameraIdsSet
            return r0
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public java.util.List<java.util.List<androidx.camera.core.CameraSelector>> getConcurrentCameraSelectors() {
            r10 = this;
            java.lang.Object r0 = r10.lock
            monitor-enter(r0)
            java.util.Set<? extends java.util.Set<androidx.camera.camera2.pipe.CameraId>> r1 = r10.concurrentCameraIdsSet     // Catch: java.lang.Throwable -> L6f
            java.lang.Iterable r1 = (java.lang.Iterable) r1     // Catch: java.lang.Throwable -> L6f
            java.util.ArrayList r2 = new java.util.ArrayList     // Catch: java.lang.Throwable -> L6f
            r3 = 10
            int r4 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r1, r3)     // Catch: java.lang.Throwable -> L6f
            r2.<init>(r4)     // Catch: java.lang.Throwable -> L6f
            java.util.Collection r2 = (java.util.Collection) r2     // Catch: java.lang.Throwable -> L6f
            java.util.Iterator r1 = r1.iterator()     // Catch: java.lang.Throwable -> L6f
        L18:
            boolean r4 = r1.hasNext()     // Catch: java.lang.Throwable -> L6f
            if (r4 == 0) goto L65
            java.lang.Object r4 = r1.next()     // Catch: java.lang.Throwable -> L6f
            java.util.Set r4 = (java.util.Set) r4     // Catch: java.lang.Throwable -> L6f
            java.lang.Iterable r4 = (java.lang.Iterable) r4     // Catch: java.lang.Throwable -> L6f
            java.util.ArrayList r5 = new java.util.ArrayList     // Catch: java.lang.Throwable -> L6f
            int r6 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r4, r3)     // Catch: java.lang.Throwable -> L6f
            r5.<init>(r6)     // Catch: java.lang.Throwable -> L6f
            java.util.Collection r5 = (java.util.Collection) r5     // Catch: java.lang.Throwable -> L6f
            java.util.Iterator r4 = r4.iterator()     // Catch: java.lang.Throwable -> L6f
        L35:
            boolean r6 = r4.hasNext()     // Catch: java.lang.Throwable -> L6f
            if (r6 == 0) goto L59
            java.lang.Object r6 = r4.next()     // Catch: java.lang.Throwable -> L6f
            androidx.camera.camera2.pipe.CameraId r6 = (androidx.camera.camera2.pipe.CameraId) r6     // Catch: java.lang.Throwable -> L6f
            java.lang.String r6 = r6.m457unboximpl()     // Catch: java.lang.Throwable -> L6f
            r7 = 1
            androidx.camera.core.CameraIdentifier[] r7 = new androidx.camera.core.CameraIdentifier[r7]     // Catch: java.lang.Throwable -> L6f
            r8 = 6
            r9 = 0
            androidx.camera.core.CameraIdentifier r6 = androidx.camera.core.CameraIdentifier.Factory.create$default(r6, r9, r9, r8, r9)     // Catch: java.lang.Throwable -> L6f
            r8 = 0
            r7[r8] = r6     // Catch: java.lang.Throwable -> L6f
            androidx.camera.core.CameraSelector r6 = androidx.camera.core.CameraSelector.of(r7)     // Catch: java.lang.Throwable -> L6f
            r5.add(r6)     // Catch: java.lang.Throwable -> L6f
            goto L35
        L59:
            java.util.List r5 = (java.util.List) r5     // Catch: java.lang.Throwable -> L6f
            java.lang.Iterable r5 = (java.lang.Iterable) r5     // Catch: java.lang.Throwable -> L6f
            java.util.List r4 = kotlin.collections.CollectionsKt.toList(r5)     // Catch: java.lang.Throwable -> L6f
            r2.add(r4)     // Catch: java.lang.Throwable -> L6f
            goto L18
        L65:
            java.util.List r2 = (java.util.List) r2     // Catch: java.lang.Throwable -> L6f
            java.lang.Iterable r2 = (java.lang.Iterable) r2     // Catch: java.lang.Throwable -> L6f
            java.util.List r1 = kotlin.collections.CollectionsKt.toList(r2)     // Catch: java.lang.Throwable -> L6f
            monitor-exit(r0)
            return r1
        L6f:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    public final int getConcurrentMode() {
            r1 = this;
            int r0 = r1.concurrentMode
            return r0
    }

    public final boolean getConcurrentModeOn() {
            r1 = this;
            boolean r0 = r1.concurrentModeOn
            return r0
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public java.lang.String getPairedConcurrentCameraId(java.lang.String r7) {
            r6 = this;
            java.lang.String r0 = "cameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.Object r0 = r6.lock
            monitor-enter(r0)
            java.util.Map<java.lang.String, ? extends java.util.List<java.lang.String>> r1 = r6.concurrentCameraIdMap     // Catch: java.lang.Throwable -> L48
            java.lang.Object r7 = r1.get(r7)     // Catch: java.lang.Throwable -> L48
            java.util.List r7 = (java.util.List) r7     // Catch: java.lang.Throwable -> L48
            r1 = 0
            if (r7 != 0) goto L14
            goto L46
        L14:
            java.util.Iterator r7 = r7.iterator()     // Catch: java.lang.Throwable -> L48
        L18:
            boolean r2 = r7.hasNext()     // Catch: java.lang.Throwable -> L48
            if (r2 == 0) goto L46
            java.lang.Object r2 = r7.next()     // Catch: java.lang.Throwable -> L48
            java.lang.String r2 = (java.lang.String) r2     // Catch: java.lang.Throwable -> L48
            java.util.List<? extends androidx.camera.core.CameraInfo> r3 = r6.activeConcurrentCameraInfosList     // Catch: java.lang.Throwable -> L48
            java.util.Iterator r3 = r3.iterator()     // Catch: java.lang.Throwable -> L48
        L2a:
            boolean r4 = r3.hasNext()     // Catch: java.lang.Throwable -> L48
            if (r4 == 0) goto L18
            java.lang.Object r4 = r3.next()     // Catch: java.lang.Throwable -> L48
            androidx.camera.core.CameraInfo r4 = (androidx.camera.core.CameraInfo) r4     // Catch: java.lang.Throwable -> L48
            androidx.camera.camera2.adapter.CameraInfoAdapter$Companion r5 = androidx.camera.camera2.adapter.CameraInfoAdapter.Companion     // Catch: java.lang.Throwable -> L48
            java.lang.String r4 = r5.m63getCameraIdzjxgSG8(r4)     // Catch: java.lang.Throwable -> L48
            if (r4 != 0) goto L3f
            r4 = r1
        L3f:
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r4)     // Catch: java.lang.Throwable -> L48
            if (r4 == 0) goto L2a
            r1 = r2
        L46:
            monitor-exit(r0)
            return r1
        L48:
            r7 = move-exception
            monitor-exit(r0)
            throw r7
    }

    public final java.util.List<java.lang.String> getPendingCameraIds() {
            r1 = this;
            java.util.List<java.lang.String> r0 = r1.pendingCameraIds
            return r0
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public void init(androidx.camera.core.impl.CameraRepository r3) {
            r2 = this;
            java.lang.String r0 = "repository"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.Object r0 = r2.lock
            monitor-enter(r0)
            r2.cameraRepository = r3     // Catch: java.lang.Throwable -> L49
            kotlin.Unit r3 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L49
            monitor-exit(r0)
            androidx.camera.camera2.pipe.CameraDevices r3 = r2.cameraDevices
            r0 = 1
            r1 = 0
            java.util.List r3 = androidx.camera.camera2.pipe.CameraDevices.m335awaitCameraIdsSeavPBo$default(r3, r1, r0, r1)
            if (r3 == 0) goto L41
            java.lang.Iterable r3 = (java.lang.Iterable) r3
            java.util.ArrayList r0 = new java.util.ArrayList
            r1 = 10
            int r1 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r3, r1)
            r0.<init>(r1)
            java.util.Collection r0 = (java.util.Collection) r0
            java.util.Iterator r3 = r3.iterator()
        L2a:
            boolean r1 = r3.hasNext()
            if (r1 == 0) goto L3e
            java.lang.Object r1 = r3.next()
            androidx.camera.camera2.pipe.CameraId r1 = (androidx.camera.camera2.pipe.CameraId) r1
            java.lang.String r1 = r1.m457unboximpl()
            r0.add(r1)
            goto L2a
        L3e:
            java.util.List r0 = (java.util.List) r0
            goto L45
        L41:
            java.util.List r0 = kotlin.collections.CollectionsKt.emptyList()
        L45:
            r2.onCamerasUpdated(r0)
            return
        L49:
            r3 = move-exception
            monitor-exit(r0)
            throw r3
    }

    @Override // androidx.camera.core.impl.InternalCameraPresenceListener
    public void onCamerasUpdated(java.util.List<java.lang.String> r10) {
            r9 = this;
            java.lang.String r0 = "cameraIds"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.util.LinkedHashSet r0 = new java.util.LinkedHashSet
            r0.<init>()
            java.util.Set r0 = (java.util.Set) r0
            java.util.LinkedHashMap r1 = new java.util.LinkedHashMap
            r1.<init>()
            java.util.Map r1 = (java.util.Map) r1
            androidx.camera.camera2.pipe.CameraDevices r2 = r9.cameraDevices     // Catch: java.lang.Exception -> L144
            r3 = 1
            r4 = 0
            java.util.Set r2 = androidx.camera.camera2.pipe.CameraDevices.m337awaitConcurrentCameraIdsSeavPBo$default(r2, r4, r3, r4)     // Catch: java.lang.Exception -> L144
            if (r2 != 0) goto L21
            java.util.Set r2 = kotlin.collections.SetsKt.emptySet()     // Catch: java.lang.Exception -> L144
        L21:
            java.util.Iterator r2 = r2.iterator()     // Catch: java.lang.Exception -> L144
        L25:
            boolean r4 = r2.hasNext()     // Catch: java.lang.Exception -> L144
            if (r4 == 0) goto L136
            java.lang.Object r4 = r2.next()     // Catch: java.lang.Exception -> L144
            java.util.Set r4 = (java.util.Set) r4     // Catch: java.lang.Exception -> L144
            r5 = r4
            java.lang.Iterable r5 = (java.lang.Iterable) r5     // Catch: java.lang.Exception -> L144
            java.util.ArrayList r6 = new java.util.ArrayList     // Catch: java.lang.Exception -> L144
            r7 = 10
            int r7 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r5, r7)     // Catch: java.lang.Exception -> L144
            r6.<init>(r7)     // Catch: java.lang.Exception -> L144
            java.util.Collection r6 = (java.util.Collection) r6     // Catch: java.lang.Exception -> L144
            java.util.Iterator r5 = r5.iterator()     // Catch: java.lang.Exception -> L144
        L45:
            boolean r7 = r5.hasNext()     // Catch: java.lang.Exception -> L144
            if (r7 == 0) goto L59
            java.lang.Object r7 = r5.next()     // Catch: java.lang.Exception -> L144
            androidx.camera.camera2.pipe.CameraId r7 = (androidx.camera.camera2.pipe.CameraId) r7     // Catch: java.lang.Exception -> L144
            java.lang.String r7 = r7.m457unboximpl()     // Catch: java.lang.Exception -> L144
            r6.add(r7)     // Catch: java.lang.Exception -> L144
            goto L45
        L59:
            java.util.List r6 = (java.util.List) r6     // Catch: java.lang.Exception -> L144
            java.lang.Iterable r6 = (java.lang.Iterable) r6     // Catch: java.lang.Exception -> L144
            java.util.Set r5 = kotlin.collections.CollectionsKt.toSet(r6)     // Catch: java.lang.Exception -> L144
            r6 = r5
            java.util.Collection r6 = (java.util.Collection) r6     // Catch: java.lang.Exception -> L144
            boolean r6 = r10.containsAll(r6)     // Catch: java.lang.Exception -> L144
            if (r6 != 0) goto L95
            androidx.camera.camera2.impl.Camera2Logger r4 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Exception -> L144
            java.lang.String r4 = "CXCP"
            boolean r4 = androidx.camera.core.Logger.isWarnEnabled(r4)     // Catch: java.lang.Exception -> L144
            if (r4 == 0) goto L25
            java.lang.String r4 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Exception -> L144
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L144
            r6.<init>()     // Catch: java.lang.Exception -> L144
            java.lang.String r7 = "Failed to retrieve concurrent camera: "
            r6.append(r7)     // Catch: java.lang.Exception -> L144
            r6.append(r5)     // Catch: java.lang.Exception -> L144
            java.lang.String r5 = " from "
            r6.append(r5)     // Catch: java.lang.Exception -> L144
            r6.append(r10)     // Catch: java.lang.Exception -> L144
            java.lang.String r5 = r6.toString()     // Catch: java.lang.Exception -> L144
            android.util.Log.w(r4, r5)     // Catch: java.lang.Exception -> L144
            goto L25
        L95:
            r5 = r4
            java.lang.Iterable r5 = (java.lang.Iterable) r5     // Catch: java.lang.Exception -> L144
            java.util.List r5 = kotlin.collections.CollectionsKt.toList(r5)     // Catch: java.lang.Exception -> L144
            int r6 = r5.size()     // Catch: java.lang.Exception -> L144
            r7 = 2
            if (r6 < r7) goto L25
            r6 = 0
            java.lang.Object r6 = r5.get(r6)     // Catch: java.lang.Exception -> L144
            androidx.camera.camera2.pipe.CameraId r6 = (androidx.camera.camera2.pipe.CameraId) r6     // Catch: java.lang.Exception -> L144
            java.lang.String r6 = r6.m457unboximpl()     // Catch: java.lang.Exception -> L144
            java.lang.Object r5 = r5.get(r3)     // Catch: java.lang.Exception -> L144
            androidx.camera.camera2.pipe.CameraId r5 = (androidx.camera.camera2.pipe.CameraId) r5     // Catch: java.lang.Exception -> L144
            java.lang.String r5 = r5.m457unboximpl()     // Catch: java.lang.Exception -> L144
            androidx.camera.camera2.pipe.CameraDevices r7 = r9.cameraDevices     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            boolean r7 = androidx.camera.camera2.internal.CameraCompatibilityFilter.isBackwardCompatible(r6, r7)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            if (r7 == 0) goto L25
            androidx.camera.camera2.pipe.CameraDevices r7 = r9.cameraDevices     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            boolean r7 = androidx.camera.camera2.internal.CameraCompatibilityFilter.isBackwardCompatible(r5, r7)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            if (r7 == 0) goto L25
            r0.add(r4)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            boolean r7 = r1.containsKey(r6)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            if (r7 != 0) goto Ldb
            java.util.ArrayList r7 = new java.util.ArrayList     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            r7.<init>()     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            java.util.List r7 = (java.util.List) r7     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            r1.put(r6, r7)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
        Ldb:
            java.lang.Object r7 = r1.get(r6)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            kotlin.jvm.internal.Intrinsics.checkNotNull(r7)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            java.util.List r7 = (java.util.List) r7     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            r7.add(r5)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            boolean r7 = r1.containsKey(r5)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            if (r7 != 0) goto Lf7
            java.util.ArrayList r7 = new java.util.ArrayList     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            r7.<init>()     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            java.util.List r7 = (java.util.List) r7     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            r1.put(r5, r7)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
        Lf7:
            java.lang.Object r5 = r1.get(r5)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            kotlin.jvm.internal.Intrinsics.checkNotNull(r5)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            java.util.List r5 = (java.util.List) r5     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            r5.add(r6)     // Catch: androidx.camera.core.InitializationException -> L105 java.lang.Exception -> L144
            goto L25
        L105:
            r5 = move-exception
            androidx.camera.camera2.impl.Camera2Logger r6 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Exception -> L144
            java.lang.String r6 = "CXCP"
            boolean r6 = androidx.camera.core.Logger.isWarnEnabled(r6)     // Catch: java.lang.Exception -> L144
            if (r6 == 0) goto L25
            java.lang.String r6 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Exception -> L144
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L144
            r7.<init>()     // Catch: java.lang.Exception -> L144
            java.lang.String r8 = "Skipping incompatible concurrent pair: "
            r7.append(r8)     // Catch: java.lang.Exception -> L144
            r7.append(r4)     // Catch: java.lang.Exception -> L144
            java.lang.String r4 = " due to "
            r7.append(r4)     // Catch: java.lang.Exception -> L144
            java.lang.String r4 = r5.getMessage()     // Catch: java.lang.Exception -> L144
            r7.append(r4)     // Catch: java.lang.Exception -> L144
            java.lang.String r4 = r7.toString()     // Catch: java.lang.Exception -> L144
            android.util.Log.w(r6, r4)     // Catch: java.lang.Exception -> L144
            goto L25
        L136:
            java.lang.Object r10 = r9.lock
            monitor-enter(r10)
            r9.concurrentCameraIdsSet = r0     // Catch: java.lang.Throwable -> L141
            r9.concurrentCameraIdMap = r1     // Catch: java.lang.Throwable -> L141
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L141
            monitor-exit(r10)
            return
        L141:
            r0 = move-exception
            monitor-exit(r10)
            throw r0
        L144:
            r10 = move-exception
            androidx.camera.core.impl.CameraUpdateException r0 = new androidx.camera.core.impl.CameraUpdateException
            java.lang.String r1 = "Failed to retrieve concurrent camera id info for camera-pipe."
            java.lang.Throwable r10 = (java.lang.Throwable) r10
            r0.<init>(r1, r10)
            throw r0
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public void removeListener(androidx.camera.core.concurrent.CameraCoordinator.ConcurrentCameraModeListener r2) {
            r1 = this;
            java.lang.String r0 = "listener"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            return
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public void removePendingCameraInfo(androidx.camera.core.CameraInfo r4) {
            r3 = this;
            java.lang.String r0 = "cameraInfo"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.Object r0 = r3.lock
            monitor-enter(r0)
            boolean r1 = r3.concurrentModeOn     // Catch: java.lang.Throwable -> L36
            if (r1 == 0) goto L32
            java.util.List<java.lang.String> r1 = r3.pendingCameraIds     // Catch: java.lang.Throwable -> L36
            androidx.camera.camera2.adapter.CameraInfoAdapter$Companion r2 = androidx.camera.camera2.adapter.CameraInfoAdapter.Companion     // Catch: java.lang.Throwable -> L36
            java.lang.String r4 = r2.m63getCameraIdzjxgSG8(r4)     // Catch: java.lang.Throwable -> L36
            if (r4 == 0) goto L1b
            androidx.camera.camera2.pipe.CameraId r4 = androidx.camera.camera2.pipe.CameraId.m450boximpl(r4)     // Catch: java.lang.Throwable -> L36
            goto L1c
        L1b:
            r4 = 0
        L1c:
            if (r4 == 0) goto L26
            java.lang.String r4 = r4.m457unboximpl()     // Catch: java.lang.Throwable -> L36
            r1.remove(r4)     // Catch: java.lang.Throwable -> L36
            goto L32
        L26:
            java.lang.String r4 = "Required value was null."
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException     // Catch: java.lang.Throwable -> L36
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Throwable -> L36
            r1.<init>(r4)     // Catch: java.lang.Throwable -> L36
            throw r1     // Catch: java.lang.Throwable -> L36
        L32:
            kotlin.Unit r4 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L36
            monitor-exit(r0)
            return
        L36:
            r4 = move-exception
            monitor-exit(r0)
            throw r4
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public void setActiveConcurrentCameraInfos(java.util.List<? extends androidx.camera.core.CameraInfo> r2) {
            r1 = this;
            java.lang.String r0 = "cameraInfos"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.Object r0 = r1.lock
            monitor-enter(r0)
            r1.activeConcurrentCameraInfosList = r2     // Catch: java.lang.Throwable -> L11
            r1.tryStartConcurrentGraph()     // Catch: java.lang.Throwable -> L11
            kotlin.Unit r2 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L11
            monitor-exit(r0)
            return
        L11:
            r2 = move-exception
            monitor-exit(r0)
            throw r2
    }

    public final void setActiveConcurrentCameraInfosList(java.util.List<? extends androidx.camera.core.CameraInfo> r2) {
            r1 = this;
            java.lang.String r0 = "<set-?>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.activeConcurrentCameraInfosList = r2
            return
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public void setCameraOperatingMode(int r7) {
            r6 = this;
            java.lang.Object r0 = r6.lock
            monitor-enter(r0)
            r6.concurrentMode = r7     // Catch: java.lang.Throwable -> L4e
            androidx.camera.core.impl.CameraRepository r1 = r6.cameraRepository     // Catch: java.lang.Throwable -> L4e
            monitor-exit(r0)
            if (r1 != 0) goto Lb
            goto L4d
        Lb:
            r0 = 0
            r2 = 2
            r3 = 1
            if (r7 != r2) goto L12
            r4 = r3
            goto L13
        L12:
            r4 = r0
        L13:
            r6.concurrentModeOn = r4
            if (r4 != 0) goto L1d
            java.util.List r4 = kotlin.collections.CollectionsKt.emptyList()
            r6.activeConcurrentCameraInfosList = r4
        L1d:
            java.util.LinkedHashSet r1 = r1.getCameras()
            java.util.Iterator r1 = r1.iterator()
            java.lang.String r4 = "iterator(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r4)
        L2a:
            boolean r4 = r1.hasNext()
            if (r4 == 0) goto L4d
            java.lang.Object r4 = r1.next()
            androidx.camera.core.impl.CameraInternal r4 = (androidx.camera.core.impl.CameraInternal) r4
            boolean r5 = r4 instanceof androidx.camera.camera2.adapter.CameraInternalAdapter
            if (r5 == 0) goto L3d
            androidx.camera.camera2.adapter.CameraInternalAdapter r4 = (androidx.camera.camera2.adapter.CameraInternalAdapter) r4
            goto L3e
        L3d:
            r4 = 0
        L3e:
            if (r4 == 0) goto L2a
            if (r7 == r3) goto L49
            if (r7 == r2) goto L45
            goto L2a
        L45:
            r4.setCameraGraphCreationMode$camera_camera2(r0)
            goto L2a
        L49:
            r4.setCameraGraphCreationMode$camera_camera2(r3)
            goto L2a
        L4d:
            return
        L4e:
            r7 = move-exception
            monitor-exit(r0)
            throw r7
    }

    public final void setCameraRepository(androidx.camera.core.impl.CameraRepository r1) {
            r0 = this;
            r0.cameraRepository = r1
            return
    }

    public final void setConcurrentCameraIdMap(java.util.Map<java.lang.String, ? extends java.util.List<java.lang.String>> r2) {
            r1 = this;
            java.lang.String r0 = "<set-?>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.concurrentCameraIdMap = r2
            return
    }

    public final void setConcurrentCameraIdsSet(java.util.Set<? extends java.util.Set<androidx.camera.camera2.pipe.CameraId>> r2) {
            r1 = this;
            java.lang.String r0 = "<set-?>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.concurrentCameraIdsSet = r2
            return
    }

    public final void setConcurrentMode(int r1) {
            r0 = this;
            r0.concurrentMode = r1
            return
    }

    public final void setConcurrentModeOn(boolean r1) {
            r0 = this;
            r0.concurrentModeOn = r1
            return
    }

    public final void setPendingCameraIds(java.util.List<java.lang.String> r2) {
            r1 = this;
            java.lang.String r0 = "<set-?>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.pendingCameraIds = r2
            return
    }

    @Override // androidx.camera.core.concurrent.CameraCoordinator
    public void shutdown() {
            r3 = this;
            r0 = 0
            r3.cameraPipe = r0
            r1 = 0
            r3.concurrentModeOn = r1
            java.lang.Object r2 = r3.lock
            monitor-enter(r2)
            r3.cameraRepository = r0     // Catch: java.lang.Throwable -> L28
            java.util.Set r0 = kotlin.collections.SetsKt.emptySet()     // Catch: java.lang.Throwable -> L28
            r3.concurrentCameraIdsSet = r0     // Catch: java.lang.Throwable -> L28
            java.util.Map r0 = kotlin.collections.MapsKt.emptyMap()     // Catch: java.lang.Throwable -> L28
            r3.concurrentCameraIdMap = r0     // Catch: java.lang.Throwable -> L28
            java.util.List r0 = kotlin.collections.CollectionsKt.emptyList()     // Catch: java.lang.Throwable -> L28
            r3.activeConcurrentCameraInfosList = r0     // Catch: java.lang.Throwable -> L28
            r3.concurrentMode = r1     // Catch: java.lang.Throwable -> L28
            java.util.List<java.lang.String> r0 = r3.pendingCameraIds     // Catch: java.lang.Throwable -> L28
            r0.clear()     // Catch: java.lang.Throwable -> L28
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L28
            monitor-exit(r2)
            return
        L28:
            r0 = move-exception
            monitor-exit(r2)
            throw r0
    }
}
