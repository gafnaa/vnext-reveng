package androidx.camera.camera2.adapter;

/* JADX INFO: loaded from: classes.dex */
public final class CameraInternalAdapter_Factory implements dagger.internal.Factory<androidx.camera.camera2.adapter.CameraInternalAdapter> {
    private final dagger.internal.Provider<androidx.camera.core.impl.CameraControlInternal> cameraControllerProvider;
    private final dagger.internal.Provider<androidx.camera.core.impl.CameraInfoInternal> cameraInfoProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.adapter.CameraStateAdapter> cameraStateAdapterProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.config.CameraConfig> configProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> threadsProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseManager> useCaseManagerProvider;

    private CameraInternalAdapter_Factory(dagger.internal.Provider<androidx.camera.camera2.config.CameraConfig> r1, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseManager> r2, dagger.internal.Provider<androidx.camera.core.impl.CameraInfoInternal> r3, dagger.internal.Provider<androidx.camera.core.impl.CameraControlInternal> r4, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r5, dagger.internal.Provider<androidx.camera.camera2.adapter.CameraStateAdapter> r6) {
            r0 = this;
            r0.<init>()
            r0.configProvider = r1
            r0.useCaseManagerProvider = r2
            r0.cameraInfoProvider = r3
            r0.cameraControllerProvider = r4
            r0.threadsProvider = r5
            r0.cameraStateAdapterProvider = r6
            return
    }

    public static androidx.camera.camera2.adapter.CameraInternalAdapter_Factory create(dagger.internal.Provider<androidx.camera.camera2.config.CameraConfig> r7, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseManager> r8, dagger.internal.Provider<androidx.camera.core.impl.CameraInfoInternal> r9, dagger.internal.Provider<androidx.camera.core.impl.CameraControlInternal> r10, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r11, dagger.internal.Provider<androidx.camera.camera2.adapter.CameraStateAdapter> r12) {
            androidx.camera.camera2.adapter.CameraInternalAdapter_Factory r0 = new androidx.camera.camera2.adapter.CameraInternalAdapter_Factory
            r1 = r7
            r2 = r8
            r3 = r9
            r4 = r10
            r5 = r11
            r6 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6)
            return r0
    }

    public static androidx.camera.camera2.adapter.CameraInternalAdapter newInstance(androidx.camera.camera2.config.CameraConfig r7, androidx.camera.camera2.impl.UseCaseManager r8, androidx.camera.core.impl.CameraInfoInternal r9, androidx.camera.core.impl.CameraControlInternal r10, androidx.camera.camera2.impl.UseCaseThreads r11, androidx.camera.camera2.adapter.CameraStateAdapter r12) {
            androidx.camera.camera2.adapter.CameraInternalAdapter r0 = new androidx.camera.camera2.adapter.CameraInternalAdapter
            r1 = r7
            r2 = r8
            r3 = r9
            r4 = r10
            r5 = r11
            r6 = r12
            r0.<init>(r1, r2, r3, r4, r5, r6)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.adapter.CameraInternalAdapter get() {
            r7 = this;
            dagger.internal.Provider<androidx.camera.camera2.config.CameraConfig> r0 = r7.configProvider
            java.lang.Object r0 = r0.get()
            r1 = r0
            androidx.camera.camera2.config.CameraConfig r1 = (androidx.camera.camera2.config.CameraConfig) r1
            dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseManager> r0 = r7.useCaseManagerProvider
            java.lang.Object r0 = r0.get()
            r2 = r0
            androidx.camera.camera2.impl.UseCaseManager r2 = (androidx.camera.camera2.impl.UseCaseManager) r2
            dagger.internal.Provider<androidx.camera.core.impl.CameraInfoInternal> r0 = r7.cameraInfoProvider
            java.lang.Object r0 = r0.get()
            r3 = r0
            androidx.camera.core.impl.CameraInfoInternal r3 = (androidx.camera.core.impl.CameraInfoInternal) r3
            dagger.internal.Provider<androidx.camera.core.impl.CameraControlInternal> r0 = r7.cameraControllerProvider
            java.lang.Object r0 = r0.get()
            r4 = r0
            androidx.camera.core.impl.CameraControlInternal r4 = (androidx.camera.core.impl.CameraControlInternal) r4
            dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r0 = r7.threadsProvider
            java.lang.Object r0 = r0.get()
            r5 = r0
            androidx.camera.camera2.impl.UseCaseThreads r5 = (androidx.camera.camera2.impl.UseCaseThreads) r5
            dagger.internal.Provider<androidx.camera.camera2.adapter.CameraStateAdapter> r0 = r7.cameraStateAdapterProvider
            java.lang.Object r0 = r0.get()
            r6 = r0
            androidx.camera.camera2.adapter.CameraStateAdapter r6 = (androidx.camera.camera2.adapter.CameraStateAdapter) r6
            androidx.camera.camera2.adapter.CameraInternalAdapter r0 = newInstance(r1, r2, r3, r4, r5, r6)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraInternalAdapter r0 = r1.get()
            return r0
    }
}
