package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraInfoAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000\u009e\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010#\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\"\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 \u0088\u00012\u00020\u00012\u00020\u0002:\u0002\u0088\u0001Ba\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\u0006\u0010\u000f\u001a\u00020\u0010\u0012\u0006\u0010\u0011\u001a\u00020\u0012\u0012\u0006\u0010\u0013\u001a\u00020\u0014\u0012\u0006\u0010\u0015\u001a\u00020\u0016\u0012\u0006\u0010\u0017\u001a\u00020\u0018¢\u0006\u0004\b\u0019\u0010\u001aJ\b\u0010-\u001a\u00020#H\u0016J\u000e\u0010.\u001a\b\u0012\u0004\u0012\u00020\u001d0/H\u0016J\b\u00100\u001a\u000201H\u0016J\b\u00102\u001a\u000203H\u0016J\b\u00104\u001a\u00020#H\u0017J\b\u00105\u001a\u000206H\u0016J\u0012\u00107\u001a\u0004\u0018\u0001082\u0006\u00109\u001a\u000201H\u0016J\u0010\u0010:\u001a\u0002032\u0006\u0010;\u001a\u000203H\u0003J\b\u0010<\u001a\u000203H\u0016J\b\u0010=\u001a\u00020#H\u0016J\u0010\u0010<\u001a\u0002032\u0006\u0010>\u001a\u000203H\u0016J\u000e\u0010?\u001a\b\u0012\u0004\u0012\u00020A0@H\u0016J\u000e\u0010B\u001a\b\u0012\u0004\u0012\u0002030@H\u0016J\b\u0010C\u001a\u00020#H\u0016J\b\u0010D\u001a\u000203H\u0016J\u000e\u0010E\u001a\b\u0012\u0004\u0012\u0002030@H\u0016J\b\u0010F\u001a\u00020#H\u0016J\u000e\u0010G\u001a\b\u0012\u0004\u0012\u0002030@H\u0016J\b\u0010H\u001a\u00020IH\u0017J\u000e\u0010J\u001a\b\u0012\u0004\u0012\u00020K0@H\u0016J\u001e\u0010L\u001a\u00020M2\u0006\u0010N\u001a\u00020O2\f\u0010P\u001a\b\u0012\u0004\u0012\u00020K0QH\u0017J\u0016\u0010R\u001a\u00020M2\f\u0010P\u001a\b\u0012\u0004\u0012\u00020K0QH\u0017J\u0018\u0010S\u001a\u00020M2\u0006\u0010N\u001a\u00020O2\u0006\u0010T\u001a\u00020UH\u0016J\u0010\u0010V\u001a\u00020M2\u0006\u0010T\u001a\u00020UH\u0016J\b\u0010W\u001a\u000201H\u0016J\b\u0010X\u001a\u00020\u0012H\u0016J\b\u0010Y\u001a\u00020ZH\u0016J\u000e\u0010[\u001a\b\u0012\u0004\u0012\u0002030/H\u0016J\u0016\u0010\\\u001a\b\u0012\u0004\u0012\u00020^0]2\u0006\u0010_\u001a\u000203H\u0016J\u0016\u0010`\u001a\b\u0012\u0004\u0012\u00020^0]2\u0006\u0010_\u001a\u000203H\u0016J'\u0010a\u001a\u0004\u0018\u0001Hb\"\b\b\u0000\u0010b*\u0002082\f\u0010c\u001a\b\u0012\u0004\u0012\u0002Hb0dH\u0017¢\u0006\u0002\u0010eJ\b\u0010f\u001a\u000201H\u0016J\b\u0010g\u001a\u00020hH\u0016J\u0010\u0010i\u001a\u00020#2\u0006\u0010j\u001a\u00020kH\u0016J\u0014\u0010l\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030m0/H\u0016J\b\u0010n\u001a\u00020#H\u0017J\b\u0010o\u001a\u00020#H\u0016J\u000e\u0010p\u001a\b\u0012\u0004\u0012\u00020q0/H\u0016J\b\u0010r\u001a\u00020#H\u0016J\u0014\u0010s\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030m0/H\u0016J\u001c\u0010t\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002030m0/2\u0006\u0010u\u001a\u00020^H\u0016J\u000e\u0010v\u001a\b\u0012\u0004\u0012\u00020^0]H\u0016J\u001c\u0010w\u001a\b\u0012\u0004\u0012\u00020^0]2\f\u0010x\u001a\b\u0012\u0004\u0012\u0002030mH\u0016J\b\u0010y\u001a\u00020zH\u0016J\u001c\u0010{\u001a\b\u0012\u0004\u0012\u00020q0/2\f\u0010|\u001a\b\u0012\u0004\u0012\u00020q0/H\u0016J\b\u0010}\u001a\u00020#H\u0016J\b\u0010~\u001a\u00020#H\u0016J\t\u0010\u007f\u001a\u00030\u0080\u0001H\u0016J4\u0010\u0081\u0001\u001a\u00020#2\u000e\u0010\u0082\u0001\u001a\t\u0012\u0005\u0012\u00030\u0083\u00010]2\u0007\u0010\u0084\u0001\u001a\u0002032\u0007\u0010\u0085\u0001\u001a\u00020#2\u0007\u0010\u0005\u001a\u00030\u0086\u0001H\u0016J\u000f\u0010\u0087\u0001\u001a\b\u0012\u0004\u0012\u0002030/H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u0004¢\u0006\u0002\n\u0000R!\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001c8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b \u0010!\u001a\u0004\b\u001e\u0010\u001fR\u001b\u0010\"\u001a\u00020#8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b%\u0010!\u001a\u0004\b\"\u0010$R!\u0010&\u001a\u00020'8@X\u0081\u0084\u0002¢\u0006\u0012\n\u0004\b,\u0010!\u0012\u0004\b(\u0010)\u001a\u0004\b*\u0010+¨\u0006\u0089\u0001"}, d2 = {"Landroidx/camera/camera2/adapter/CameraInfoAdapter;", "Landroidx/camera/core/impl/CameraInfoInternal;", "Landroidx/camera/camera2/pipe/UnsafeWrapper;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "cameraConfig", "Landroidx/camera/camera2/config/CameraConfig;", "cameraStateAdapter", "Landroidx/camera/camera2/adapter/CameraStateAdapter;", "cameraControlStateAdapter", "Landroidx/camera/camera2/adapter/CameraControlStateAdapter;", "cameraCallbackMap", "Landroidx/camera/camera2/impl/CameraCallbackMap;", "focusMeteringControl", "Landroidx/camera/camera2/impl/FocusMeteringControl;", "cameraQuirks", "Landroidx/camera/camera2/compat/quirk/CameraQuirks;", "encoderProfilesProvider", "Landroidx/camera/core/impl/EncoderProfilesProvider;", "streamConfigurationMapCompat", "Landroidx/camera/camera2/compat/StreamConfigurationMapCompat;", "intrinsicZoomCalculator", "Landroidx/camera/camera2/internal/IntrinsicZoomCalculator;", "streamSpecsCalculator", "Landroidx/camera/core/internal/StreamSpecsCalculator;", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;Landroidx/camera/camera2/config/CameraConfig;Landroidx/camera/camera2/adapter/CameraStateAdapter;Landroidx/camera/camera2/adapter/CameraControlStateAdapter;Landroidx/camera/camera2/impl/CameraCallbackMap;Landroidx/camera/camera2/impl/FocusMeteringControl;Landroidx/camera/camera2/compat/quirk/CameraQuirks;Landroidx/camera/core/impl/EncoderProfilesProvider;Landroidx/camera/camera2/compat/StreamConfigurationMapCompat;Landroidx/camera/camera2/internal/IntrinsicZoomCalculator;Landroidx/camera/core/internal/StreamSpecsCalculator;)V", "_physicalCameraInfos", "", "Landroidx/camera/core/CameraInfo;", "get_physicalCameraInfos", "()Ljava/util/Set;", "_physicalCameraInfos$delegate", "Lkotlin/Lazy;", "isLegacyDevice", "", "()Z", "isLegacyDevice$delegate", "camera2CameraInfo", "Landroidx/camera/camera2/interop/Camera2CameraInfo;", "getCamera2CameraInfo$camera_camera2$annotations", "()V", "getCamera2CameraInfo$camera_camera2", "()Landroidx/camera/camera2/interop/Camera2CameraInfo;", "camera2CameraInfo$delegate", "isLogicalMultiCameraSupported", "getPhysicalCameraInfos", "", "getCameraId", "", "getLensFacing", "", "isExternalCamera", "getCameraCharacteristics", "Landroid/hardware/camera2/CameraCharacteristics;", "getPhysicalCameraCharacteristics", "", "physicalCameraId", "getCameraSelectorLensFacing", "lensFacingInt", "getSensorRotationDegrees", "hasFlashUnit", "relativeRotation", "getZoomState", "Landroidx/lifecycle/LiveData;", "Landroidx/camera/core/ZoomState;", "getTorchState", "isTorchStrengthSupported", "getMaxTorchStrengthLevel", "getTorchStrengthLevel", "isLowLightBoostSupported", "getLowLightBoostState", "getExposureState", "Landroidx/camera/core/ExposureState;", "getCameraState", "Landroidx/camera/core/CameraState;", "addCameraStateListener", "", "executor", "Ljava/util/concurrent/Executor;", "listener", "Landroidx/core/util/Consumer;", "removeCameraStateListener", "addSessionCaptureCallback", "callback", "Landroidx/camera/core/impl/CameraCaptureCallback;", "removeSessionCaptureCallback", "getImplementationType", "getEncoderProfilesProvider", "getTimebase", "Landroidx/camera/core/impl/Timebase;", "getSupportedOutputFormats", "getSupportedResolutions", "", "Landroid/util/Size;", "format", "getSupportedHighResolutions", "unwrapAs", "T", "type", "Lkotlin/reflect/KClass;", "(Lkotlin/reflect/KClass;)Ljava/lang/Object;", "toString", "getCameraQuirks", "Landroidx/camera/core/impl/Quirks;", "isFocusMeteringSupported", "action", "Landroidx/camera/core/FocusMeteringAction;", "getSupportedFrameRateRanges", "Landroid/util/Range;", "isZslSupported", "isPrivateReprocessingSupported", "getSupportedDynamicRanges", "Landroidx/camera/core/DynamicRange;", "isHighSpeedSupported", "getSupportedHighSpeedFrameRateRanges", "getSupportedHighSpeedFrameRateRangesFor", "size", "getSupportedHighSpeedResolutions", "getSupportedHighSpeedResolutionsFor", "fpsRange", "getSensorRect", "Landroid/graphics/Rect;", "querySupportedDynamicRanges", "candidateDynamicRanges", "isPreviewStabilizationSupported", "isVideoStabilizationSupported", "getIntrinsicZoomRatio", "", "isUseCaseCombinationSupported", "useCases", "Landroidx/camera/core/UseCase;", "cameraMode", "isFeatureComboInvocation", "Landroidx/camera/core/impl/CameraConfig;", "getAvailableCapabilities", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraInfoAdapter implements androidx.camera.core.impl.CameraInfoInternal, androidx.camera.camera2.pipe.UnsafeWrapper {
    public static final androidx.camera.camera2.adapter.CameraInfoAdapter.Companion Companion = null;
    private final kotlin.Lazy _physicalCameraInfos$delegate;
    private final kotlin.Lazy camera2CameraInfo$delegate;
    private final androidx.camera.camera2.impl.CameraCallbackMap cameraCallbackMap;
    private final androidx.camera.camera2.config.CameraConfig cameraConfig;
    private final androidx.camera.camera2.adapter.CameraControlStateAdapter cameraControlStateAdapter;
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;
    private final androidx.camera.camera2.compat.quirk.CameraQuirks cameraQuirks;
    private final androidx.camera.camera2.adapter.CameraStateAdapter cameraStateAdapter;
    private final androidx.camera.core.impl.EncoderProfilesProvider encoderProfilesProvider;
    private final androidx.camera.camera2.impl.FocusMeteringControl focusMeteringControl;
    private final androidx.camera.camera2.internal.IntrinsicZoomCalculator intrinsicZoomCalculator;
    private final kotlin.Lazy isLegacyDevice$delegate;
    private final androidx.camera.camera2.compat.StreamConfigurationMapCompat streamConfigurationMapCompat;
    private final androidx.camera.core.internal.StreamSpecsCalculator streamSpecsCalculator;

    /* JADX INFO: compiled from: CameraInfoAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J)\u0010\u0004\u001a\u0004\u0018\u0001H\u0005\"\b\b\u0000\u0010\u0005*\u00020\u0001*\u00020\u00062\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u0002H\u00050\b¢\u0006\u0002\u0010\tR\u0017\u0010\n\u001a\u0004\u0018\u00010\u000b*\u00020\u00068F¢\u0006\u0006\u001a\u0004\b\f\u0010\r¨\u0006\u000e"}, d2 = {"Landroidx/camera/camera2/adapter/CameraInfoAdapter$Companion;", "", "<init>", "()V", "unwrapAs", "T", "Landroidx/camera/core/CameraInfo;", "type", "Lkotlin/reflect/KClass;", "(Landroidx/camera/core/CameraInfo;Lkotlin/reflect/KClass;)Ljava/lang/Object;", "cameraId", "Landroidx/camera/camera2/pipe/CameraId;", "getCameraId-zjxgSG8", "(Landroidx/camera/core/CameraInfo;)Ljava/lang/String;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        /* JADX INFO: renamed from: getCameraId-zjxgSG8, reason: not valid java name */
        public final java.lang.String m63getCameraIdzjxgSG8(androidx.camera.core.CameraInfo r2) {
                r1 = this;
                java.lang.String r0 = "$this$cameraId"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.Class<androidx.camera.camera2.pipe.CameraMetadata> r0 = androidx.camera.camera2.pipe.CameraMetadata.class
                kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
                java.lang.Object r2 = r1.unwrapAs(r2, r0)
                androidx.camera.camera2.pipe.CameraMetadata r2 = (androidx.camera.camera2.pipe.CameraMetadata) r2
                if (r2 == 0) goto L18
                java.lang.String r2 = r2.mo469getCameraDz_R5H8()
                return r2
            L18:
                r2 = 0
                return r2
        }

        public final <T> T unwrapAs(androidx.camera.core.CameraInfo r4, kotlin.reflect.KClass<T> r5) {
                r3 = this;
                java.lang.String r0 = "<this>"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
                java.lang.String r0 = "type"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                boolean r0 = r4 instanceof androidx.camera.camera2.pipe.UnsafeWrapper
                if (r0 == 0) goto L15
                androidx.camera.camera2.pipe.UnsafeWrapper r4 = (androidx.camera.camera2.pipe.UnsafeWrapper) r4
                java.lang.Object r4 = r4.unwrapAs(r5)
                return r4
            L15:
                boolean r0 = r4 instanceof androidx.camera.core.impl.CameraInfoInternal
                r1 = 0
                if (r0 == 0) goto L33
                r0 = r4
                androidx.camera.core.impl.CameraInfoInternal r0 = (androidx.camera.core.impl.CameraInfoInternal) r0
                androidx.camera.core.impl.CameraInfoInternal r2 = r0.getImplementation()
                if (r2 == r4) goto L33
                androidx.camera.core.impl.CameraInfoInternal r4 = r0.getImplementation()
                java.lang.String r0 = "getImplementation(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r0)
                androidx.camera.core.CameraInfo r4 = (androidx.camera.core.CameraInfo) r4
                java.lang.Object r4 = r3.unwrapAs(r4, r5)
                return r4
            L33:
                return r1
        }
    }

    /* JADX INFO: renamed from: $r8$lambda$8g70NABhA3_822vIurrdbS-08FA, reason: not valid java name */
    public static /* synthetic */ java.util.Set m60$r8$lambda$8g70NABhA3_822vIurrdbS08FA(androidx.camera.camera2.adapter.CameraInfoAdapter r0) {
            java.util.Set r0 = _physicalCameraInfos_delegate$lambda$0(r0)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$fgry69gZOm7VnDY-P995-fW1f-Q, reason: not valid java name */
    public static /* synthetic */ boolean m61$r8$lambda$fgry69gZOm7VnDYP995fW1fQ(androidx.camera.camera2.adapter.CameraInfoAdapter r0) {
            boolean r0 = isLegacyDevice_delegate$lambda$0(r0)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$qd-sqass8XyIp3pPSJzEyEBqz3M, reason: not valid java name */
    public static /* synthetic */ androidx.camera.camera2.interop.Camera2CameraInfo m62$r8$lambda$qdsqass8XyIp3pPSJzEyEBqz3M(androidx.camera.camera2.adapter.CameraInfoAdapter r0) {
            androidx.camera.camera2.interop.Camera2CameraInfo r0 = camera2CameraInfo_delegate$lambda$0(r0)
            return r0
    }

    static {
            androidx.camera.camera2.adapter.CameraInfoAdapter$Companion r0 = new androidx.camera.camera2.adapter.CameraInfoAdapter$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.adapter.CameraInfoAdapter.Companion = r0
            return
    }

    @javax.inject.Inject
    public CameraInfoAdapter(androidx.camera.camera2.impl.CameraProperties r2, androidx.camera.camera2.config.CameraConfig r3, androidx.camera.camera2.adapter.CameraStateAdapter r4, androidx.camera.camera2.adapter.CameraControlStateAdapter r5, androidx.camera.camera2.impl.CameraCallbackMap r6, androidx.camera.camera2.impl.FocusMeteringControl r7, androidx.camera.camera2.compat.quirk.CameraQuirks r8, androidx.camera.core.impl.EncoderProfilesProvider r9, androidx.camera.camera2.compat.StreamConfigurationMapCompat r10, androidx.camera.camera2.internal.IntrinsicZoomCalculator r11, androidx.camera.core.internal.StreamSpecsCalculator r12) {
            r1 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "cameraConfig"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "cameraStateAdapter"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "cameraControlStateAdapter"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "cameraCallbackMap"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.lang.String r0 = "focusMeteringControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.String r0 = "cameraQuirks"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            java.lang.String r0 = "encoderProfilesProvider"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            java.lang.String r0 = "streamConfigurationMapCompat"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.lang.String r0 = "intrinsicZoomCalculator"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            java.lang.String r0 = "streamSpecsCalculator"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            r1.<init>()
            r1.cameraProperties = r2
            r1.cameraConfig = r3
            r1.cameraStateAdapter = r4
            r1.cameraControlStateAdapter = r5
            r1.cameraCallbackMap = r6
            r1.focusMeteringControl = r7
            r1.cameraQuirks = r8
            r1.encoderProfilesProvider = r9
            r1.streamConfigurationMapCompat = r10
            r1.intrinsicZoomCalculator = r11
            r1.streamSpecsCalculator = r12
            androidx.camera.camera2.impl.DeviceInfoLogger r3 = androidx.camera.camera2.impl.DeviceInfoLogger.INSTANCE
            r3.logDeviceInfo(r2)
            androidx.camera.camera2.adapter.CameraInfoAdapter$$ExternalSyntheticLambda0 r2 = new androidx.camera.camera2.adapter.CameraInfoAdapter$$ExternalSyntheticLambda0
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1._physicalCameraInfos$delegate = r2
            androidx.camera.camera2.adapter.CameraInfoAdapter$$ExternalSyntheticLambda1 r2 = new androidx.camera.camera2.adapter.CameraInfoAdapter$$ExternalSyntheticLambda1
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.isLegacyDevice$delegate = r2
            androidx.camera.camera2.adapter.CameraInfoAdapter$$ExternalSyntheticLambda2 r2 = new androidx.camera.camera2.adapter.CameraInfoAdapter$$ExternalSyntheticLambda2
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.camera2CameraInfo$delegate = r2
            return
    }

    private static final java.util.Set _physicalCameraInfos_delegate$lambda$0(androidx.camera.camera2.adapter.CameraInfoAdapter r6) {
            androidx.camera.camera2.impl.CameraProperties r0 = r6.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            java.util.Set r0 = r0.getPhysicalCameraIds()
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.LinkedHashSet r1 = new java.util.LinkedHashSet
            r1.<init>()
            java.util.Set r1 = (java.util.Set) r1
            java.util.Collection r1 = (java.util.Collection) r1
            java.util.Iterator r0 = r0.iterator()
        L19:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L49
            java.lang.Object r2 = r0.next()
            androidx.camera.camera2.pipe.CameraId r2 = (androidx.camera.camera2.pipe.CameraId) r2
            java.lang.String r2 = r2.m457unboximpl()
            androidx.camera.camera2.impl.CameraPipeCameraProperties r3 = new androidx.camera.camera2.impl.CameraPipeCameraProperties
            androidx.camera.camera2.config.CameraConfig r4 = new androidx.camera.camera2.config.CameraConfig
            r5 = 0
            r4.<init>(r2, r5)
            androidx.camera.camera2.impl.CameraProperties r5 = r6.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r5 = r5.getMetadata()
            androidx.camera.camera2.pipe.CameraMetadata r2 = r5.mo468awaitPhysicalMetadataEfqyGwQ(r2)
            r3.<init>(r4, r2)
            androidx.camera.camera2.adapter.PhysicalCameraInfoAdapter r2 = new androidx.camera.camera2.adapter.PhysicalCameraInfoAdapter
            androidx.camera.camera2.impl.CameraProperties r3 = (androidx.camera.camera2.impl.CameraProperties) r3
            r2.<init>(r3)
            r1.add(r2)
            goto L19
        L49:
            java.util.Set r1 = (java.util.Set) r1
            return r1
    }

    public static final /* synthetic */ androidx.camera.camera2.impl.CameraProperties access$getCameraProperties$p(androidx.camera.camera2.adapter.CameraInfoAdapter r0) {
            androidx.camera.camera2.impl.CameraProperties r0 = r0.cameraProperties
            return r0
    }

    private static final androidx.camera.camera2.interop.Camera2CameraInfo camera2CameraInfo_delegate$lambda$0(androidx.camera.camera2.adapter.CameraInfoAdapter r1) {
            androidx.camera.camera2.interop.Camera2CameraInfo$Companion r0 = androidx.camera.camera2.interop.Camera2CameraInfo.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r1.cameraProperties
            androidx.camera.camera2.interop.Camera2CameraInfo r1 = r0.create(r1)
            return r1
    }

    public static /* synthetic */ void getCamera2CameraInfo$camera_camera2$annotations() {
            return
    }

    private final int getCameraSelectorLensFacing(int r4) {
            r3 = this;
            if (r4 == 0) goto L2f
            r0 = 1
            if (r4 == r0) goto L2e
            r0 = 2
            if (r4 == r0) goto L2e
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isWarnEnabled(r0)
            if (r0 == 0) goto L2c
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Unrecognized lens facing: "
            r1.<init>(r2)
            r1.append(r4)
            r4 = 33
            r1.append(r4)
            java.lang.String r4 = r1.toString()
            android.util.Log.w(r0, r4)
        L2c:
            r4 = -1
            return r4
        L2e:
            return r0
        L2f:
            r4 = 0
            return r4
    }

    private final java.util.Set<androidx.camera.core.CameraInfo> get_physicalCameraInfos() {
            r1 = this;
            kotlin.Lazy r0 = r1._physicalCameraInfos$delegate
            java.lang.Object r0 = r0.getValue()
            java.util.Set r0 = (java.util.Set) r0
            return r0
    }

    private final boolean isLegacyDevice() {
            r1 = this;
            kotlin.Lazy r0 = r1.isLegacyDevice$delegate
            java.lang.Object r0 = r0.getValue()
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            boolean r0 = r0.booleanValue()
            return r0
    }

    private static final boolean isLegacyDevice_delegate$lambda$0(androidx.camera.camera2.adapter.CameraInfoAdapter r1) {
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r1.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r1 = r0.isHardwareLevelLegacy(r1)
            return r1
    }

    @Override // androidx.camera.core.CameraInfo
    public void addCameraStateListener(java.util.concurrent.Executor r2, androidx.core.util.Consumer<androidx.camera.core.CameraState> r3) {
            r1 = this;
            java.lang.String r0 = "executor"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "listener"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r1.cameraStateAdapter
            r0.addCameraStateListener$camera_camera2(r2, r3)
            return
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public void addSessionCaptureCallback(java.util.concurrent.Executor r2, androidx.camera.core.impl.CameraCaptureCallback r3) {
            r1 = this;
            java.lang.String r0 = "executor"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "callback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.impl.CameraCallbackMap r0 = r1.cameraCallbackMap
            r0.addCaptureCallback(r3, r2)
            return
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.Set<java.lang.Integer> getAvailableCapabilities() {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES
            java.lang.String r2 = "REQUEST_AVAILABLE_CAPABILITIES"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            int[] r0 = (int[]) r0
            if (r0 == 0) goto L1c
            java.util.Set r0 = kotlin.collections.ArraysKt.toSet(r0)
            if (r0 == 0) goto L1c
            return r0
        L1c:
            java.util.Set r0 = kotlin.collections.SetsKt.emptySet()
            return r0
    }

    public final androidx.camera.camera2.interop.Camera2CameraInfo getCamera2CameraInfo$camera_camera2() {
            r1 = this;
            kotlin.Lazy r0 = r1.camera2CameraInfo$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.camera.camera2.interop.Camera2CameraInfo r0 = (androidx.camera.camera2.interop.Camera2CameraInfo) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public android.hardware.camera2.CameraCharacteristics getCameraCharacteristics() {
            r2 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            java.lang.Class<android.hardware.camera2.CameraCharacteristics> r1 = android.hardware.camera2.CameraCharacteristics.class
            kotlin.reflect.KClass r1 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r1)
            java.lang.Object r0 = r0.unwrapAs(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            android.hardware.camera2.CameraCharacteristics r0 = (android.hardware.camera2.CameraCharacteristics) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public /* bridge */ /* synthetic */ java.lang.Object getCameraCharacteristics() {
            r1 = this;
            android.hardware.camera2.CameraCharacteristics r0 = r1.getCameraCharacteristics()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.lang.String getCameraId() {
            r1 = this;
            androidx.camera.camera2.config.CameraConfig r0 = r1.cameraConfig
            java.lang.String r0 = r0.m115getCameraIdDz_R5H8()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public androidx.camera.core.impl.Quirks getCameraQuirks() {
            r1 = this;
            androidx.camera.camera2.compat.quirk.CameraQuirks r0 = r1.cameraQuirks
            androidx.camera.core.impl.Quirks r0 = r0.getQuirks()
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.lifecycle.LiveData<androidx.camera.core.CameraState> getCameraState() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r1.cameraStateAdapter
            androidx.lifecycle.MutableLiveData r0 = r0.getCameraState$camera_camera2()
            androidx.lifecycle.LiveData r0 = (androidx.lifecycle.LiveData) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public androidx.camera.core.impl.EncoderProfilesProvider getEncoderProfilesProvider() {
            r1 = this;
            androidx.camera.core.impl.EncoderProfilesProvider r0 = r1.encoderProfilesProvider
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.camera.core.ExposureState getExposureState() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraControlStateAdapter r0 = r1.cameraControlStateAdapter
            androidx.camera.core.ExposureState r0 = r0.getExposureState()
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public java.lang.String getImplementationType() {
            r1 = this;
            boolean r0 = r1.isLegacyDevice()
            if (r0 == 0) goto L9
            java.lang.String r0 = "androidx.camera.camera2.legacy"
            return r0
        L9:
            java.lang.String r0 = "androidx.camera.camera2"
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public float getIntrinsicZoomRatio() {
            r3 = this;
            androidx.camera.camera2.internal.IntrinsicZoomCalculator r0 = r3.intrinsicZoomCalculator
            androidx.camera.camera2.impl.CameraProperties r1 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            java.lang.Float r0 = r0.calculateIntrinsicZoomRatio(r1)
            if (r0 == 0) goto L13
            float r0 = r0.floatValue()
            return r0
        L13:
            r0 = r3
            androidx.camera.camera2.adapter.CameraInfoAdapter r0 = (androidx.camera.camera2.adapter.CameraInfoAdapter) r0
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isWarnEnabled(r0)
            if (r0 == 0) goto L41
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Failed to calculate intrinsic zoom ratio for "
            r1.<init>(r2)
            androidx.camera.camera2.impl.CameraProperties r2 = access$getCameraProperties$p(r3)
            java.lang.String r2 = r2.mo143getCameraIdDz_R5H8()
            java.lang.String r2 = androidx.camera.camera2.pipe.CameraId.m456toStringimpl(r2)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.w(r0, r1)
        L41:
            r0 = 1065353216(0x3f800000, float:1.0)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public int getLensFacing() {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.LENS_FACING
            java.lang.String r2 = "LENS_FACING"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            int r0 = r3.getCameraSelectorLensFacing(r0)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.lifecycle.LiveData<java.lang.Integer> getLowLightBoostState() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraControlStateAdapter r0 = r1.cameraControlStateAdapter
            androidx.lifecycle.LiveData r0 = r0.getLowLightBoostState()
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public int getMaxTorchStrengthLevel() {
            r2 = this;
            boolean r0 = r2.isTorchStrengthSupported()
            if (r0 == 0) goto L13
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            int r0 = r0.getMaxTorchStrengthLevel(r1)
            return r0
        L13:
            r0 = 0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.lang.Object getPhysicalCameraCharacteristics(java.lang.String r3) {
            r2 = this;
            java.lang.String r0 = "physicalCameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.pipe.CameraId$Companion r0 = androidx.camera.camera2.pipe.CameraId.Companion
            java.lang.String r3 = androidx.camera.camera2.pipe.CameraId.m451constructorimpl(r3)
            androidx.camera.camera2.impl.CameraProperties r0 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            java.util.Set r0 = r0.getPhysicalCameraIds()
            androidx.camera.camera2.pipe.CameraId r1 = androidx.camera.camera2.pipe.CameraId.m450boximpl(r3)
            boolean r0 = r0.contains(r1)
            if (r0 != 0) goto L21
            r3 = 0
            return r3
        L21:
            androidx.camera.camera2.impl.CameraProperties r0 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            androidx.camera.camera2.pipe.CameraMetadata r3 = r0.mo468awaitPhysicalMetadataEfqyGwQ(r3)
            java.lang.Class<android.hardware.camera2.CameraCharacteristics> r0 = android.hardware.camera2.CameraCharacteristics.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            java.lang.Object r3 = r3.unwrapAs(r0)
            return r3
    }

    @Override // androidx.camera.core.CameraInfo
    public java.util.Set<androidx.camera.core.CameraInfo> getPhysicalCameraInfos() {
            r1 = this;
            java.util.Set r0 = r1.get_physicalCameraInfos()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public android.graphics.Rect getSensorRect() {
            r4 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r4.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE
            java.lang.String r2 = "SENSOR_INFO_ACTIVE_ARRAY_SIZE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            android.graphics.Rect r0 = (android.graphics.Rect) r0
            java.lang.String r1 = "robolectric"
            java.lang.String r2 = android.os.Build.FINGERPRINT
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r2)
            if (r1 == 0) goto L2a
            if (r0 != 0) goto L2a
            android.graphics.Rect r0 = new android.graphics.Rect
            r1 = 4000(0xfa0, float:5.605E-42)
            r2 = 3000(0xbb8, float:4.204E-42)
            r3 = 0
            r0.<init>(r3, r3, r1, r2)
            return r0
        L2a:
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public int getSensorRotationDegrees() {
            r1 = this;
            r0 = 0
            int r0 = r1.getSensorRotationDegrees(r0)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public int getSensorRotationDegrees(int r4) {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.SENSOR_ORIENTATION
            java.lang.String r2 = "SENSOR_ORIENTATION"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            int r4 = androidx.camera.core.impl.utils.CameraOrientationUtil.surfaceRotationToDegrees(r4)
            int r1 = r3.getLensFacing()
            r2 = 1
            if (r2 != r1) goto L26
            goto L27
        L26:
            r2 = 0
        L27:
            int r4 = androidx.camera.core.impl.utils.CameraOrientationUtil.getRelativeImageRotation(r4, r0, r2)
            return r4
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.Set<androidx.camera.core.DynamicRange> getSupportedDynamicRanges() {
            r2 = this;
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat$Companion r0 = androidx.camera.camera2.compat.DynamicRangeProfilesCompat.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat r0 = r0.fromCameraMetaData(r1)
            java.util.Set r0 = r0.getSupportedDynamicRanges()
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public java.util.Set<android.util.Range<java.lang.Integer>> getSupportedFrameRateRanges() {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES
            java.lang.String r2 = "CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            android.util.Range[] r0 = (android.util.Range[]) r0
            if (r0 == 0) goto L1c
            java.util.Set r0 = kotlin.collections.ArraysKt.toSet(r0)
            if (r0 == 0) goto L1c
            return r0
        L1c:
            java.util.Set r0 = kotlin.collections.SetsKt.emptySet()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.List<android.util.Size> getSupportedHighResolutions(int r2) {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r1.streamConfigurationMapCompat
            android.util.Size[] r2 = r0.getHighResolutionOutputSizes(r2)
            if (r2 == 0) goto L10
            java.util.List r2 = kotlin.collections.ArraysKt.toList(r2)
            if (r2 != 0) goto Lf
            goto L10
        Lf:
            return r2
        L10:
            java.util.List r2 = kotlin.collections.CollectionsKt.emptyList()
            return r2
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.Set<android.util.Range<java.lang.Integer>> getSupportedHighSpeedFrameRateRanges() {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r1.streamConfigurationMapCompat
            android.util.Range[] r0 = r0.getHighSpeedVideoFpsRanges()
            if (r0 == 0) goto L10
            java.util.Set r0 = kotlin.collections.ArraysKt.toSet(r0)
            if (r0 != 0) goto Lf
            goto L10
        Lf:
            return r0
        L10:
            java.util.Set r0 = kotlin.collections.SetsKt.emptySet()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.Set<android.util.Range<java.lang.Integer>> getSupportedHighSpeedFrameRateRangesFor(android.util.Size r3) {
            r2 = this;
            java.lang.String r0 = "size"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r0 = 0
            kotlin.Result$Companion r1 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> L1e
            r1 = r2
            androidx.camera.camera2.adapter.CameraInfoAdapter r1 = (androidx.camera.camera2.adapter.CameraInfoAdapter) r1     // Catch: java.lang.Throwable -> L1e
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r1 = r2.streamConfigurationMapCompat     // Catch: java.lang.Throwable -> L1e
            android.util.Range[] r3 = r1.getHighSpeedVideoFpsRangesFor(r3)     // Catch: java.lang.Throwable -> L1e
            if (r3 == 0) goto L18
            java.util.Set r3 = kotlin.collections.ArraysKt.toSet(r3)     // Catch: java.lang.Throwable -> L1e
            goto L19
        L18:
            r3 = r0
        L19:
            java.lang.Object r3 = kotlin.Result.m2181constructorimpl(r3)     // Catch: java.lang.Throwable -> L1e
            goto L29
        L1e:
            r3 = move-exception
            kotlin.Result$Companion r1 = kotlin.Result.Companion
            java.lang.Object r3 = kotlin.ResultKt.createFailure(r3)
            java.lang.Object r3 = kotlin.Result.m2181constructorimpl(r3)
        L29:
            boolean r1 = kotlin.Result.m2187isFailureimpl(r3)
            if (r1 == 0) goto L30
            goto L31
        L30:
            r0 = r3
        L31:
            java.util.Set r0 = (java.util.Set) r0
            if (r0 != 0) goto L39
            java.util.Set r0 = kotlin.collections.SetsKt.emptySet()
        L39:
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.List<android.util.Size> getSupportedHighSpeedResolutions() {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r1.streamConfigurationMapCompat
            android.util.Size[] r0 = r0.getHighSpeedVideoSizes()
            if (r0 == 0) goto L10
            java.util.List r0 = kotlin.collections.ArraysKt.toList(r0)
            if (r0 != 0) goto Lf
            goto L10
        Lf:
            return r0
        L10:
            java.util.List r0 = kotlin.collections.CollectionsKt.emptyList()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.List<android.util.Size> getSupportedHighSpeedResolutionsFor(android.util.Range<java.lang.Integer> r3) {
            r2 = this;
            java.lang.String r0 = "fpsRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r0 = 0
            kotlin.Result$Companion r1 = kotlin.Result.Companion     // Catch: java.lang.Throwable -> L1e
            r1 = r2
            androidx.camera.camera2.adapter.CameraInfoAdapter r1 = (androidx.camera.camera2.adapter.CameraInfoAdapter) r1     // Catch: java.lang.Throwable -> L1e
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r1 = r2.streamConfigurationMapCompat     // Catch: java.lang.Throwable -> L1e
            android.util.Size[] r3 = r1.getHighSpeedVideoSizesFor(r3)     // Catch: java.lang.Throwable -> L1e
            if (r3 == 0) goto L18
            java.util.List r3 = kotlin.collections.ArraysKt.toList(r3)     // Catch: java.lang.Throwable -> L1e
            goto L19
        L18:
            r3 = r0
        L19:
            java.lang.Object r3 = kotlin.Result.m2181constructorimpl(r3)     // Catch: java.lang.Throwable -> L1e
            goto L29
        L1e:
            r3 = move-exception
            kotlin.Result$Companion r1 = kotlin.Result.Companion
            java.lang.Object r3 = kotlin.ResultKt.createFailure(r3)
            java.lang.Object r3 = kotlin.Result.m2181constructorimpl(r3)
        L29:
            boolean r1 = kotlin.Result.m2187isFailureimpl(r3)
            if (r1 == 0) goto L30
            goto L31
        L30:
            r0 = r3
        L31:
            java.util.List r0 = (java.util.List) r0
            if (r0 != 0) goto L39
            java.util.List r0 = kotlin.collections.CollectionsKt.emptyList()
        L39:
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.Set<java.lang.Integer> getSupportedOutputFormats() {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r1.streamConfigurationMapCompat
            java.lang.Integer[] r0 = r0.getOutputFormats()
            if (r0 == 0) goto L10
            java.util.Set r0 = kotlin.collections.ArraysKt.toSet(r0)
            if (r0 != 0) goto Lf
            goto L10
        Lf:
            return r0
        L10:
            java.util.Set r0 = kotlin.collections.SetsKt.emptySet()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public java.util.List<android.util.Size> getSupportedResolutions(int r2) {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r1.streamConfigurationMapCompat
            android.util.Size[] r2 = r0.getOutputSizes(r2)
            if (r2 == 0) goto L10
            java.util.List r2 = kotlin.collections.ArraysKt.toList(r2)
            if (r2 != 0) goto Lf
            goto L10
        Lf:
            return r2
        L10:
            java.util.List r2 = kotlin.collections.CollectionsKt.emptyList()
            return r2
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public androidx.camera.core.impl.Timebase getTimebase() {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE
            java.lang.String r2 = "SENSOR_INFO_TIMESTAMP_SOURCE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            if (r0 == 0) goto L25
            r1 = 1
            if (r0 == r1) goto L22
            androidx.camera.core.impl.Timebase r0 = androidx.camera.core.impl.Timebase.UPTIME
            return r0
        L22:
            androidx.camera.core.impl.Timebase r0 = androidx.camera.core.impl.Timebase.REALTIME
            return r0
        L25:
            androidx.camera.core.impl.Timebase r0 = androidx.camera.core.impl.Timebase.UPTIME
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.lifecycle.LiveData<java.lang.Integer> getTorchState() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraControlStateAdapter r0 = r1.cameraControlStateAdapter
            androidx.lifecycle.LiveData r0 = r0.getTorchStateLiveData()
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.lifecycle.LiveData<java.lang.Integer> getTorchStrengthLevel() {
            r2 = this;
            boolean r0 = r2.isTorchStrengthSupported()
            if (r0 == 0) goto Ld
            androidx.camera.camera2.adapter.CameraControlStateAdapter r0 = r2.cameraControlStateAdapter
            androidx.lifecycle.LiveData r0 = r0.getTorchStrengthLiveData()
            return r0
        Ld:
            androidx.lifecycle.MutableLiveData r0 = new androidx.lifecycle.MutableLiveData
            r1 = 0
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r0.<init>(r1)
            androidx.lifecycle.LiveData r0 = (androidx.lifecycle.LiveData) r0
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public androidx.lifecycle.LiveData<androidx.camera.core.ZoomState> getZoomState() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraControlStateAdapter r0 = r1.cameraControlStateAdapter
            androidx.lifecycle.LiveData r0 = r0.getZoomStateLiveData()
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean hasFlashUnit() {
            r4 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r4.cameraProperties
            r1 = 1
            r2 = 0
            r3 = 0
            boolean r0 = androidx.camera.camera2.compat.workaround.FlashAvailabilityCheckerKt.isFlashAvailable$default(r0, r3, r1, r2)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public boolean isExternalCamera() {
            r3 = this;
            int r0 = r3.getLensFacing()
            r1 = 2
            if (r0 == r1) goto L27
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL
            java.lang.String r2 = "INFO_SUPPORTED_HARDWARE_LEVEL"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L1d
            goto L25
        L1d:
            int r0 = r0.intValue()
            r1 = 4
            if (r0 != r1) goto L25
            goto L27
        L25:
            r0 = 0
            return r0
        L27:
            r0 = 1
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isFocusMeteringSupported(androidx.camera.core.FocusMeteringAction r2) {
            r1 = this;
            java.lang.String r0 = "action"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.FocusMeteringControl r0 = r1.focusMeteringControl
            boolean r2 = r0.isFocusMeteringSupported(r2)
            return r2
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public boolean isHighSpeedSupported() {
            r2 = this;
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r0 = r0.getSupportsHighSpeedVideo(r1)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isLogicalMultiCameraSupported() {
            r2 = this;
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r0 = r0.getSupportsLogicalMultiCamera(r1)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isLowLightBoostSupported() {
            r2 = this;
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r0 = r0.getSupportsLowLightBoost(r1)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public boolean isPreviewStabilizationSupported() {
            r2 = this;
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r0 = r0.getSupportsPreviewStabilization(r1)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isPrivateReprocessingSupported() {
            r2 = this;
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r0 = r0.getSupportsPrivateReprocessing(r1)
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isTorchStrengthSupported() {
            r2 = this;
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r0 = r0.getSupportsTorchStrength(r1)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public boolean isUseCaseCombinationSupported(java.util.List<? extends androidx.camera.core.UseCase> r14, int r15, boolean r16, androidx.camera.core.impl.CameraConfig r17) {
            r13 = this;
            java.lang.String r0 = "useCases"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)
            java.lang.String r0 = "cameraConfig"
            r6 = r17
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            androidx.camera.core.internal.StreamSpecsCalculator r1 = r13.streamSpecsCalculator     // Catch: java.lang.IllegalArgumentException -> L21
            r3 = r13
            androidx.camera.core.impl.CameraInfoInternal r3 = (androidx.camera.core.impl.CameraInfoInternal) r3     // Catch: java.lang.IllegalArgumentException -> L21
            r11 = 360(0x168, float:5.04E-43)
            r12 = 0
            r5 = 0
            r7 = 0
            r8 = 0
            r10 = 0
            r4 = r14
            r2 = r15
            r9 = r16
            androidx.camera.core.internal.StreamSpecsCalculator.calculateSuggestedStreamSpecs$default(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12)     // Catch: java.lang.IllegalArgumentException -> L21
            r14 = 1
            return r14
        L21:
            r0 = move-exception
            r14 = r0
            androidx.camera.camera2.impl.Camera2Logger r15 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.Throwable r14 = (java.lang.Throwable) r14
            java.lang.String r15 = "CXCP"
            boolean r15 = androidx.camera.core.Logger.isDebugEnabled(r15)
            if (r15 == 0) goto L38
            java.lang.String r15 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r0 = "CameraInfoAdapter#isUseCaseCombinationSupported: calculateSuggestedStreamSpecs failed"
            android.util.Log.d(r15, r0, r14)
        L38:
            r14 = 0
            return r14
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public boolean isVideoStabilizationSupported() {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES
            java.lang.String r2 = "CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            int[] r0 = (int[]) r0
            if (r0 == 0) goto L1d
            r1 = 1
            boolean r0 = kotlin.collections.ArraysKt.contains(r0, r1)
            if (r0 == 0) goto L1d
            return r1
        L1d:
            r0 = 0
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public boolean isZslSupported() {
            r2 = this;
            boolean r0 = r2.isPrivateReprocessingSupported()
            if (r0 == 0) goto L12
            androidx.camera.camera2.compat.quirk.DeviceQuirks r0 = androidx.camera.camera2.compat.quirk.DeviceQuirks.INSTANCE
            java.lang.Class<androidx.camera.camera2.compat.quirk.ZslDisablerQuirk> r1 = androidx.camera.camera2.compat.quirk.ZslDisablerQuirk.class
            androidx.camera.core.impl.Quirk r0 = r0.get(r1)
            if (r0 != 0) goto L12
            r0 = 1
            return r0
        L12:
            r0 = 0
            return r0
    }

    @Override // androidx.camera.core.CameraInfo
    public java.util.Set<androidx.camera.core.DynamicRange> querySupportedDynamicRanges(java.util.Set<androidx.camera.core.DynamicRange> r2) {
            r1 = this;
            java.lang.String r0 = "candidateDynamicRanges"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.util.Set r0 = r1.getSupportedDynamicRanges()
            java.util.Set r2 = androidx.camera.core.impl.DynamicRanges.findAllPossibleMatches(r2, r0)
            return r2
    }

    @Override // androidx.camera.core.CameraInfo
    public void removeCameraStateListener(androidx.core.util.Consumer<androidx.camera.core.CameraState> r2) {
            r1 = this;
            java.lang.String r0 = "listener"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r1.cameraStateAdapter
            r0.removeCameraStateListener$camera_camera2(r2)
            return
    }

    @Override // androidx.camera.core.impl.CameraInfoInternal
    public void removeSessionCaptureCallback(androidx.camera.core.impl.CameraCaptureCallback r2) {
            r1 = this;
            java.lang.String r0 = "callback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.CameraCallbackMap r0 = r1.cameraCallbackMap
            r0.removeCaptureCallback(r2)
            return
    }

    public java.lang.String toString() {
            r2 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "CameraInfoAdapter<"
            r0.<init>(r1)
            androidx.camera.camera2.config.CameraConfig r1 = r2.cameraConfig
            r0.append(r1)
            java.lang.String r1 = ".cameraId>"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }

    @Override // androidx.camera.camera2.pipe.UnsafeWrapper
    public <T> T unwrapAs(kotlin.reflect.KClass<T> r3) {
            r2 = this;
            java.lang.String r0 = "type"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.Class<androidx.camera.camera2.interop.Camera2CameraInfo> r0 = androidx.camera.camera2.interop.Camera2CameraInfo.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            java.lang.String r1 = "null cannot be cast to non-null type T of androidx.camera.camera2.adapter.CameraInfoAdapter.unwrapAs"
            if (r0 == 0) goto L1d
            androidx.camera.camera2.interop.Camera2CameraInfo r3 = r2.getCamera2CameraInfo$camera_camera2()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r1)
            java.lang.Object r3 = (java.lang.Object) r3
            return r3
        L1d:
            java.lang.Class<androidx.camera.camera2.impl.CameraProperties> r0 = androidx.camera.camera2.impl.CameraProperties.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r0 == 0) goto L31
            androidx.camera.camera2.impl.CameraProperties r3 = r2.cameraProperties
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r1)
            java.lang.Object r3 = (java.lang.Object) r3
            return r3
        L31:
            java.lang.Class<androidx.camera.camera2.pipe.CameraMetadata> r0 = androidx.camera.camera2.pipe.CameraMetadata.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r0 == 0) goto L49
            androidx.camera.camera2.impl.CameraProperties r3 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r3 = r3.getMetadata()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r1)
            java.lang.Object r3 = (java.lang.Object) r3
            return r3
        L49:
            androidx.camera.camera2.impl.CameraProperties r0 = r2.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            java.lang.Object r3 = r0.unwrapAs(r3)
            return r3
    }
}
