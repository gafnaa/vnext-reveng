package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CaptureResultAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u00012\u00020\u0002B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\b\u0010\u000e\u001a\u00020\u000fH\u0016J\b\u0010\u0010\u001a\u00020\u0011H\u0016J\b\u0010\u0012\u001a\u00020\u0013H\u0016J\b\u0010\u0014\u001a\u00020\u0015H\u0016J\b\u0010\u0016\u001a\u00020\u0017H\u0016J\b\u0010\u0018\u001a\u00020\u0019H\u0016J\b\u0010\u001a\u001a\u00020\u001bH\u0016J\b\u0010\u001c\u001a\u00020\u001dH\u0016J\b\u0010\u001e\u001a\u00020\u001fH\u0016J\u0010\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#H\u0016J\b\u0010$\u001a\u00020%H\u0016J'\u0010&\u001a\u0004\u0018\u0001H'\"\b\b\u0000\u0010'*\u00020(2\f\u0010)\u001a\b\u0012\u0004\u0012\u0002H'0*H\u0016¢\u0006\u0002\u0010+R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u000bR\u0014\u0010\u0007\u001a\u00020\bX\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006,"}, d2 = {"Landroidx/camera/camera2/adapter/CaptureResultAdapter;", "Landroidx/camera/core/impl/CameraCaptureResult;", "Landroidx/camera/camera2/pipe/UnsafeWrapper;", "requestMetadata", "Landroidx/camera/camera2/pipe/RequestMetadata;", "frameNumber", "Landroidx/camera/camera2/pipe/FrameNumber;", "result", "Landroidx/camera/camera2/pipe/FrameInfo;", "<init>", "(Landroidx/camera/camera2/pipe/RequestMetadata;JLandroidx/camera/camera2/pipe/FrameInfo;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "J", "getResult$camera_camera2", "()Landroidx/camera/camera2/pipe/FrameInfo;", "getAfMode", "Landroidx/camera/core/impl/CameraCaptureMetaData$AfMode;", "getAfState", "Landroidx/camera/core/impl/CameraCaptureMetaData$AfState;", "getAeMode", "Landroidx/camera/core/impl/CameraCaptureMetaData$AeMode;", "getAeState", "Landroidx/camera/core/impl/CameraCaptureMetaData$AeState;", "getAwbMode", "Landroidx/camera/core/impl/CameraCaptureMetaData$AwbMode;", "getAwbState", "Landroidx/camera/core/impl/CameraCaptureMetaData$AwbState;", "getFlashState", "Landroidx/camera/core/impl/CameraCaptureMetaData$FlashState;", "getTimestamp", "", "getTagBundle", "Landroidx/camera/core/impl/TagBundle;", "populateExifData", "", "exifBuilder", "Landroidx/camera/core/impl/utils/ExifData$Builder;", "getCaptureResult", "Landroid/hardware/camera2/CaptureResult;", "unwrapAs", "T", "", "type", "Lkotlin/reflect/KClass;", "(Lkotlin/reflect/KClass;)Ljava/lang/Object;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CaptureResultAdapter implements androidx.camera.core.impl.CameraCaptureResult, androidx.camera.camera2.pipe.UnsafeWrapper {
    private final long frameNumber;
    private final androidx.camera.camera2.pipe.RequestMetadata requestMetadata;
    private final androidx.camera.camera2.pipe.FrameInfo result;

    private CaptureResultAdapter(androidx.camera.camera2.pipe.RequestMetadata r2, long r3, androidx.camera.camera2.pipe.FrameInfo r5) {
            r1 = this;
            java.lang.String r0 = "requestMetadata"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "result"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            r1.<init>()
            r1.requestMetadata = r2
            r1.frameNumber = r3
            r1.result = r5
            return
    }

    public /* synthetic */ CaptureResultAdapter(androidx.camera.camera2.pipe.RequestMetadata r1, long r2, androidx.camera.camera2.pipe.FrameInfo r4, kotlin.jvm.internal.DefaultConstructorMarker r5) {
            r0 = this;
            r0.<init>(r1, r2, r4)
            return
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public androidx.camera.core.impl.CameraCaptureMetaData.AeMode getAeMode() {
            r1 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            androidx.camera.core.impl.CameraCaptureMetaData$AeMode r0 = androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$getAeMode(r0)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public androidx.camera.core.impl.CameraCaptureMetaData.AeState getAeState() {
            r1 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            androidx.camera.core.impl.CameraCaptureMetaData$AeState r0 = androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$getAeState(r0)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public androidx.camera.core.impl.CameraCaptureMetaData.AfMode getAfMode() {
            r1 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            androidx.camera.core.impl.CameraCaptureMetaData$AfMode r0 = androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$getAfMode(r0)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public androidx.camera.core.impl.CameraCaptureMetaData.AfState getAfState() {
            r1 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            androidx.camera.core.impl.CameraCaptureMetaData$AfState r0 = androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$getAfState(r0)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public androidx.camera.core.impl.CameraCaptureMetaData.AwbMode getAwbMode() {
            r1 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            androidx.camera.core.impl.CameraCaptureMetaData$AwbMode r0 = androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$getAwbMode(r0)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public androidx.camera.core.impl.CameraCaptureMetaData.AwbState getAwbState() {
            r1 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            androidx.camera.core.impl.CameraCaptureMetaData$AwbState r0 = androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$getAwbState(r0)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public android.hardware.camera2.CaptureResult getCaptureResult() {
            r2 = this;
            java.lang.Class<android.hardware.camera2.TotalCaptureResult> r0 = android.hardware.camera2.TotalCaptureResult.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            java.lang.Object r0 = r2.unwrapAs(r0)
            if (r0 == 0) goto Lf
            android.hardware.camera2.CaptureResult r0 = (android.hardware.camera2.CaptureResult) r0
            return r0
        Lf:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Failed to unwrap "
            r0.<init>(r1)
            r0.append(r2)
            java.lang.String r1 = " as TotalCaptureResult"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public androidx.camera.core.impl.CameraCaptureMetaData.FlashState getFlashState() {
            r1 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            androidx.camera.core.impl.CameraCaptureMetaData$FlashState r0 = androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$getFlashState(r0)
            return r0
    }

    public final androidx.camera.camera2.pipe.FrameInfo getResult$camera_camera2() {
            r1 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public androidx.camera.core.impl.TagBundle getTagBundle() {
            r3 = this;
            androidx.camera.camera2.pipe.RequestMetadata r0 = r3.requestMetadata
            androidx.camera.camera2.pipe.Metadata$Key r1 = androidx.camera.camera2.impl.TagsKt.getCAMERAX_TAG_BUNDLE()
            androidx.camera.core.impl.TagBundle r2 = androidx.camera.core.impl.TagBundle.emptyBundle()
            java.lang.Object r0 = r0.getOrDefault(r1, r2)
            androidx.camera.core.impl.TagBundle r0 = (androidx.camera.core.impl.TagBundle) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public long getTimestamp() {
            r2 = this;
            androidx.camera.camera2.pipe.FrameInfo r0 = r2.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            long r0 = androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$getTimestamp(r0)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraCaptureResult
    public void populateExifData(androidx.camera.core.impl.utils.ExifData.Builder r2) {
            r1 = this;
            java.lang.String r0 = "exifBuilder"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            super.populateExifData(r2)
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            androidx.camera.camera2.pipe.FrameMetadata r0 = r0.getMetadata()
            androidx.camera.camera2.adapter.CaptureResultAdapterKt.access$populateExifData(r0, r2)
            return
    }

    @Override // androidx.camera.camera2.pipe.UnsafeWrapper
    public <T> T unwrapAs(kotlin.reflect.KClass<T> r2) {
            r1 = this;
            java.lang.String r0 = "type"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.Class<androidx.camera.camera2.pipe.FrameInfo> r0 = androidx.camera.camera2.pipe.FrameInfo.class
            kotlin.reflect.KClass r0 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r0)
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r0)
            if (r0 == 0) goto L1b
            androidx.camera.camera2.pipe.FrameInfo r2 = r1.result
            java.lang.String r0 = "null cannot be cast to non-null type T of androidx.camera.camera2.adapter.CaptureResultAdapter.unwrapAs"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2, r0)
            java.lang.Object r2 = (java.lang.Object) r2
            return r2
        L1b:
            androidx.camera.camera2.pipe.FrameInfo r0 = r1.result
            java.lang.Object r2 = r0.unwrapAs(r2)
            return r2
    }
}
