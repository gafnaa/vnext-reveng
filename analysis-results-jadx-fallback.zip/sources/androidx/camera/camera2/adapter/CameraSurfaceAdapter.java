package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraSurfaceAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\t\u0010\nJ\u0016\u0010\u0011\u001a\u00020\u00122\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\b0\u0014H\u0016J\"\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00100\u000f2\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\b0\u0014H\u0002J0\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\b2\u0006\u0010\u001c\u001a\u00020\u001a2\u0006\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 H\u0016J\u0015\u0010!\u001a\u00020\"2\u0006\u0010\u001b\u001a\u00020\bH\u0001¢\u0006\u0002\b#Jd\u0010$\u001a\u00020%2\u0006\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\b2\f\u0010&\u001a\b\u0012\u0004\u0012\u00020'0\u00142\u001c\u0010(\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030)\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001e0\u00140\u000f2\u0006\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020\"2\u0006\u0010-\u001a\u00020\"2\u0006\u0010.\u001a\u00020\"H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00100\u000f8\u0002@\u0002X\u0083\u000e¢\u0006\u0002\n\u0000¨\u0006/"}, d2 = {"Landroidx/camera/camera2/adapter/CameraSurfaceAdapter;", "Landroidx/camera/core/impl/CameraDeviceSurfaceManager;", "context", "Landroid/content/Context;", "cameraComponent", "", "availableCameraIds", "", "", "<init>", "(Landroid/content/Context;Ljava/lang/Object;Ljava/util/Set;)V", "component", "Landroidx/camera/camera2/config/CameraAppComponent;", "lock", "supportedSurfaceCombinationMap", "", "Landroidx/camera/camera2/adapter/SupportedSurfaceCombination;", "onCamerasUpdated", "", "cameraIds", "", "buildSurfaceCombinations", "cameraIdsToBuild", "transformSurfaceConfig", "Landroidx/camera/core/impl/SurfaceConfig;", "cameraMode", "", "cameraId", "imageFormat", "size", "Landroid/util/Size;", "streamUseCase", "Landroidx/camera/core/impl/StreamUseCase;", "checkIfSupportedCombinationExist", "", "checkIfSupportedCombinationExist$camera_camera2", "getSuggestedStreamSpecs", "Landroidx/camera/core/impl/SurfaceStreamSpecQueryResult;", "existingSurfaces", "Landroidx/camera/core/impl/AttachedSurfaceInfo;", "newUseCaseConfigsSupportedSizeMap", "Landroidx/camera/core/impl/UseCaseConfig;", "videoStabilization", "Landroidx/camera/core/impl/stabilization/VideoStabilization;", "hasVideoCapture", "isFeatureComboInvocation", "findMaxSupportedFrameRate", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraSurfaceAdapter implements androidx.camera.core.impl.CameraDeviceSurfaceManager {
    private final androidx.camera.camera2.config.CameraAppComponent component;
    private final android.content.Context context;
    private final java.lang.Object lock;
    private java.util.Map<java.lang.String, androidx.camera.camera2.adapter.SupportedSurfaceCombination> supportedSurfaceCombinationMap;

    public CameraSurfaceAdapter(android.content.Context r2, java.lang.Object r3, java.util.Set<java.lang.String> r4) {
            r1 = this;
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "availableCameraIds"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            r1.<init>()
            r1.context = r2
            java.lang.String r2 = "null cannot be cast to non-null type androidx.camera.camera2.config.CameraAppComponent"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3, r2)
            androidx.camera.camera2.config.CameraAppComponent r3 = (androidx.camera.camera2.config.CameraAppComponent) r3
            r1.component = r3
            java.lang.Object r2 = new java.lang.Object
            r2.<init>()
            r1.lock = r2
            java.util.Map r2 = kotlin.collections.MapsKt.emptyMap()
            r1.supportedSurfaceCombinationMap = r2
            java.lang.Iterable r4 = (java.lang.Iterable) r4     // Catch: androidx.camera.core.impl.CameraUpdateException -> L2f
            java.util.List r2 = kotlin.collections.CollectionsKt.toList(r4)     // Catch: androidx.camera.core.impl.CameraUpdateException -> L2f
            r1.onCamerasUpdated(r2)     // Catch: androidx.camera.core.impl.CameraUpdateException -> L2f
            return
        L2f:
            r2 = move-exception
            androidx.camera.core.InitializationException r3 = new androidx.camera.core.InitializationException
            java.lang.Throwable r2 = (java.lang.Throwable) r2
            r3.<init>(r2)
            throw r3
    }

    private final java.util.Map<java.lang.String, androidx.camera.camera2.adapter.SupportedSurfaceCombination> buildSurfaceCombinations(java.util.List<java.lang.String> r10) {
            r9 = this;
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            boolean r1 = r10.isEmpty()
            if (r1 == 0) goto Le
            goto L74
        Le:
            java.util.Iterator r10 = r10.iterator()     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
        L12:
            boolean r1 = r10.hasNext()     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            if (r1 == 0) goto L74
            java.lang.Object r1 = r10.next()     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            java.lang.String r1 = (java.lang.String) r1     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.config.CameraAppComponent r2 = r9.component     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.pipe.CameraDevices r2 = r2.getCameraDevices()     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            java.lang.String r3 = androidx.camera.camera2.pipe.CameraId.m451constructorimpl(r1)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            r4 = 2
            r5 = 0
            androidx.camera.camera2.pipe.CameraMetadata r2 = androidx.camera.camera2.pipe.CameraDevices.m336awaitCameraMetadataFpsL5FU$default(r2, r3, r5, r4, r5)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            if (r2 != 0) goto L31
            goto L12
        L31:
            android.hardware.camera2.CameraCharacteristics$Key r3 = android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            java.lang.String r4 = "SCALER_STREAM_CONFIGURATION_MAP"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            java.lang.Object r3 = r2.get(r3)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            android.hardware.camera2.params.StreamConfigurationMap r3 = (android.hardware.camera2.params.StreamConfigurationMap) r3     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.compat.quirk.CameraQuirks r4 = new androidx.camera.camera2.compat.quirk.CameraQuirks     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r5 = new androidx.camera.camera2.compat.StreamConfigurationMapCompat     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.compat.workaround.OutputSizesCorrector r6 = new androidx.camera.camera2.compat.workaround.OutputSizesCorrector     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            r6.<init>(r2, r3)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            r5.<init>(r3, r6)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            r4.<init>(r2, r5)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.adapter.SupportedSurfaceCombination r3 = new androidx.camera.camera2.adapter.SupportedSurfaceCombination     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            android.content.Context r5 = r9.context     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.config.CameraModule$Companion r6 = androidx.camera.camera2.config.CameraModule.Companion     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.core.impl.EncoderProfilesProvider r6 = r6.provideEncoderProfilesProvider(r1, r4)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            int r7 = android.os.Build.VERSION.SDK_INT     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            r8 = 35
            if (r7 < r8) goto L6b
            androidx.camera.camera2.impl.FeatureCombinationQueryImpl r7 = new androidx.camera.camera2.impl.FeatureCombinationQueryImpl     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.config.CameraAppComponent r8 = r9.component     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.camera2.pipe.CameraPipe r8 = r8.getCameraPipe()     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            r7.<init>(r2, r8, r4)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            androidx.camera.core.featuregroup.impl.FeatureCombinationQuery r7 = (androidx.camera.core.featuregroup.impl.FeatureCombinationQuery) r7     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            goto L6d
        L6b:
            androidx.camera.core.featuregroup.impl.FeatureCombinationQuery r7 = androidx.camera.core.featuregroup.impl.FeatureCombinationQuery.NO_OP_FEATURE_COMBINATION_QUERY     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
        L6d:
            r3.<init>(r5, r2, r6, r7)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            r0.put(r1, r3)     // Catch: java.lang.Exception -> L75 androidx.camera.camera2.pipe.DoNotDisturbException -> L80
            goto L12
        L74:
            return r0
        L75:
            r10 = move-exception
            androidx.camera.core.impl.CameraUpdateException r0 = new androidx.camera.core.impl.CameraUpdateException
            java.lang.String r1 = "Failed to build surface combinations"
            java.lang.Throwable r10 = (java.lang.Throwable) r10
            r0.<init>(r1, r10)
            throw r0
        L80:
            r10 = move-exception
            androidx.camera.core.impl.CameraUpdateException r0 = new androidx.camera.core.impl.CameraUpdateException
            java.lang.String r1 = "Failed to query camera metadata"
            java.lang.Throwable r10 = (java.lang.Throwable) r10
            r0.<init>(r1, r10)
            throw r0
    }

    public final boolean checkIfSupportedCombinationExist$camera_camera2(java.lang.String r2) {
            r1 = this;
            java.lang.String r0 = "cameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.util.Map<java.lang.String, androidx.camera.camera2.adapter.SupportedSurfaceCombination> r0 = r1.supportedSurfaceCombinationMap
            boolean r2 = r0.containsKey(r2)
            return r2
    }

    @Override // androidx.camera.core.impl.CameraDeviceSurfaceManager
    public androidx.camera.core.impl.SurfaceStreamSpecQueryResult getSuggestedStreamSpecs(int r11, java.lang.String r12, java.util.List<? extends androidx.camera.core.impl.AttachedSurfaceInfo> r13, java.util.Map<androidx.camera.core.impl.UseCaseConfig<?>, ? extends java.util.List<android.util.Size>> r14, androidx.camera.core.impl.stabilization.VideoStabilization r15, boolean r16, boolean r17, boolean r18) {
            r10 = this;
            java.lang.String r0 = "cameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            java.lang.String r0 = "existingSurfaces"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r13, r0)
            java.lang.String r0 = "newUseCaseConfigsSupportedSizeMap"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)
            java.lang.String r0 = "videoStabilization"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r15, r0)
            boolean r0 = r10.checkIfSupportedCombinationExist$camera_camera2(r12)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "No such camera id in supported combination list: "
            r1.<init>(r2)
            r1.append(r12)
            java.lang.String r1 = r1.toString()
            androidx.core.util.Preconditions.checkArgument(r0, r1)
            java.lang.Object r1 = r10.lock
            monitor-enter(r1)
            java.util.Map<java.lang.String, androidx.camera.camera2.adapter.SupportedSurfaceCombination> r0 = r10.supportedSurfaceCombinationMap     // Catch: java.lang.Throwable -> L5b
            java.lang.Object r0 = r0.get(r12)     // Catch: java.lang.Throwable -> L5b
            r2 = r0
            androidx.camera.camera2.adapter.SupportedSurfaceCombination r2 = (androidx.camera.camera2.adapter.SupportedSurfaceCombination) r2     // Catch: java.lang.Throwable -> L5b
            monitor-exit(r1)
            if (r2 == 0) goto L47
            r3 = r11
            r4 = r13
            r5 = r14
            r6 = r15
            r7 = r16
            r8 = r17
            r9 = r18
            androidx.camera.core.impl.SurfaceStreamSpecQueryResult r11 = r2.getSuggestedStreamSpecifications(r3, r4, r5, r6, r7, r8, r9)
            return r11
        L47:
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            java.lang.String r14 = "No such camera id in supported combination list: "
            r13.<init>(r14)
            r13.append(r12)
            java.lang.String r12 = r13.toString()
            r11.<init>(r12)
            throw r11
        L5b:
            r0 = move-exception
            r11 = r0
            monitor-exit(r1)
            throw r11
    }

    @Override // androidx.camera.core.impl.InternalCameraPresenceListener
    public void onCamerasUpdated(java.util.List<java.lang.String> r6) {
            r5 = this;
            java.lang.String r0 = "cameraIds"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.lang.Object r0 = r5.lock
            monitor-enter(r0)
            r1 = r6
            java.lang.Iterable r1 = (java.lang.Iterable) r1     // Catch: java.lang.Throwable -> La7
            java.util.Map<java.lang.String, androidx.camera.camera2.adapter.SupportedSurfaceCombination> r2 = r5.supportedSurfaceCombinationMap     // Catch: java.lang.Throwable -> La7
            java.util.Set r2 = r2.keySet()     // Catch: java.lang.Throwable -> La7
            java.lang.Iterable r2 = (java.lang.Iterable) r2     // Catch: java.lang.Throwable -> La7
            java.util.List r1 = kotlin.collections.CollectionsKt.minus(r1, r2)     // Catch: java.lang.Throwable -> La7
            kotlin.Unit r2 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> La7
            monitor-exit(r0)
            r0 = r1
            java.util.Collection r0 = (java.util.Collection) r0
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L42
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r0)
            if (r0 == 0) goto L42
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Creating new surface combinations for: "
            r2.<init>(r3)
            r2.append(r1)
            java.lang.String r2 = r2.toString()
            android.util.Log.d(r0, r2)
        L42:
            java.util.Map r0 = r5.buildSurfaceCombinations(r1)
            java.lang.Object r1 = r5.lock
            monitor-enter(r1)
            java.util.LinkedHashMap r2 = new java.util.LinkedHashMap     // Catch: java.lang.Throwable -> La4
            r2.<init>()     // Catch: java.lang.Throwable -> La4
            java.util.Map r2 = (java.util.Map) r2     // Catch: java.lang.Throwable -> La4
            java.util.Iterator r6 = r6.iterator()     // Catch: java.lang.Throwable -> La4
        L54:
            boolean r3 = r6.hasNext()     // Catch: java.lang.Throwable -> La4
            if (r3 == 0) goto L75
            java.lang.Object r3 = r6.next()     // Catch: java.lang.Throwable -> La4
            java.lang.String r3 = (java.lang.String) r3     // Catch: java.lang.Throwable -> La4
            java.util.Map<java.lang.String, androidx.camera.camera2.adapter.SupportedSurfaceCombination> r4 = r5.supportedSurfaceCombinationMap     // Catch: java.lang.Throwable -> La4
            boolean r4 = r4.containsKey(r3)     // Catch: java.lang.Throwable -> La4
            if (r4 == 0) goto L54
            java.util.Map<java.lang.String, androidx.camera.camera2.adapter.SupportedSurfaceCombination> r4 = r5.supportedSurfaceCombinationMap     // Catch: java.lang.Throwable -> La4
            java.lang.Object r4 = r4.get(r3)     // Catch: java.lang.Throwable -> La4
            kotlin.jvm.internal.Intrinsics.checkNotNull(r4)     // Catch: java.lang.Throwable -> La4
            r2.put(r3, r4)     // Catch: java.lang.Throwable -> La4
            goto L54
        L75:
            r2.putAll(r0)     // Catch: java.lang.Throwable -> La4
            r5.supportedSurfaceCombinationMap = r2     // Catch: java.lang.Throwable -> La4
            androidx.camera.camera2.impl.Camera2Logger r6 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Throwable -> La4
            java.lang.String r6 = "CXCP"
            boolean r6 = androidx.camera.core.Logger.isDebugEnabled(r6)     // Catch: java.lang.Throwable -> La4
            if (r6 == 0) goto La0
            java.lang.String r6 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Throwable -> La4
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> La4
            r0.<init>()     // Catch: java.lang.Throwable -> La4
            java.lang.String r3 = "Committed new surface combination map. Total cameras: "
            r0.append(r3)     // Catch: java.lang.Throwable -> La4
            int r2 = r2.size()     // Catch: java.lang.Throwable -> La4
            r0.append(r2)     // Catch: java.lang.Throwable -> La4
            java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> La4
            android.util.Log.d(r6, r0)     // Catch: java.lang.Throwable -> La4
        La0:
            kotlin.Unit r6 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> La4
            monitor-exit(r1)
            return
        La4:
            r6 = move-exception
            monitor-exit(r1)
            throw r6
        La7:
            r6 = move-exception
            monitor-exit(r0)
            throw r6
    }

    @Override // androidx.camera.core.impl.CameraDeviceSurfaceManager
    public androidx.camera.core.impl.SurfaceConfig transformSurfaceConfig(int r4, java.lang.String r5, int r6, android.util.Size r7, androidx.camera.core.impl.StreamUseCase r8) {
            r3 = this;
            java.lang.String r0 = "cameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "size"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.String r0 = "streamUseCase"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            boolean r0 = r3.checkIfSupportedCombinationExist$camera_camera2(r5)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "No such camera id in supported combination list: "
            r1.<init>(r2)
            r1.append(r5)
            java.lang.String r1 = r1.toString()
            androidx.core.util.Preconditions.checkArgument(r0, r1)
            java.lang.Object r0 = r3.lock
            monitor-enter(r0)
            java.util.Map<java.lang.String, androidx.camera.camera2.adapter.SupportedSurfaceCombination> r1 = r3.supportedSurfaceCombinationMap     // Catch: java.lang.Throwable -> L4b
            java.lang.Object r1 = r1.get(r5)     // Catch: java.lang.Throwable -> L4b
            androidx.camera.camera2.adapter.SupportedSurfaceCombination r1 = (androidx.camera.camera2.adapter.SupportedSurfaceCombination) r1     // Catch: java.lang.Throwable -> L4b
            monitor-exit(r0)
            if (r1 == 0) goto L37
            androidx.camera.core.impl.SurfaceConfig r4 = r1.transformSurfaceConfig(r4, r6, r7, r8)
            return r4
        L37:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            java.lang.String r7 = "No such camera id in supported combination list: "
            r6.<init>(r7)
            r6.append(r5)
            java.lang.String r5 = r6.toString()
            r4.<init>(r5)
            throw r4
        L4b:
            r4 = move-exception
            monitor-exit(r0)
            throw r4
    }
}
