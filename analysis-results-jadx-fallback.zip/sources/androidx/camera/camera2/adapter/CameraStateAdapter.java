package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraStateAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\b\u0007\u0018\u0000 02\u00020\u0001:\u0002/0B\t\b\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u001a\u001a\u00020\u001bJ\u000e\u0010\u001c\u001a\u00020\u001b2\u0006\u0010\u001d\u001a\u00020\u0010J\u0016\u0010\u001e\u001a\u00020\u001b2\u0006\u0010\u001d\u001a\u00020\u00102\u0006\u0010\u001f\u001a\u00020 J\u0018\u0010!\u001a\u00020\u001b2\u0006\u0010\u001d\u001a\u00020\u00102\u0006\u0010\u001f\u001a\u00020 H\u0003J\u001c\u0010\"\u001a\u00020\u001b2\u0006\u0010#\u001a\u00020\u00072\n\b\u0002\u0010$\u001a\u0004\u0018\u00010\u0013H\u0002J\u001f\u0010%\u001a\u0004\u0018\u00010&2\u0006\u0010'\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020 H\u0000¢\u0006\u0002\b(J#\u0010)\u001a\u00020\u001b2\u0006\u0010*\u001a\u00020\u00192\f\u0010+\u001a\b\u0012\u0004\u0012\u00020\f0\u0018H\u0000¢\u0006\u0002\b,J\u001b\u0010-\u001a\u00020\u001b2\f\u0010+\u001a\b\u0012\u0004\u0012\u00020\f0\u0018H\u0000¢\u0006\u0002\b.R\u000e\u0010\u0004\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bX\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0014\u0010\u000f\u001a\u0004\u0018\u00010\u00108\u0002@\u0002X\u0083\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0011\u001a\u00020\u00078\u0002@\u0002X\u0083\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\u0004\u0018\u00010\u00138\u0002@\u0002X\u0083\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0014\u001a\u00020\u00158\u0002@\u0002X\u0083\u000e¢\u0006\u0002\n\u0000R\"\u0010\u0016\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u0018\u0012\u0004\u0012\u00020\u00190\u00178\u0002X\u0083\u0004¢\u0006\u0002\n\u0000¨\u00061"}, d2 = {"Landroidx/camera/camera2/adapter/CameraStateAdapter;", "", "<init>", "()V", "lock", "cameraInternalState", "Landroidx/camera/core/impl/LiveDataObservable;", "Landroidx/camera/core/impl/CameraInternal$State;", "getCameraInternalState$camera_camera2", "()Landroidx/camera/core/impl/LiveDataObservable;", "cameraState", "Landroidx/lifecycle/MutableLiveData;", "Landroidx/camera/core/CameraState;", "getCameraState$camera_camera2", "()Landroidx/lifecycle/MutableLiveData;", "currentGraph", "Landroidx/camera/camera2/pipe/CameraGraph;", "currentCameraInternalState", "currentCameraStateError", "Landroidx/camera/core/CameraState$StateError;", "isRemoved", "", "cameraStateListeners", "", "Landroidx/core/util/Consumer;", "Ljava/util/concurrent/Executor;", "onRemoved", "", "onGraphUpdated", "cameraGraph", "onGraphStateUpdated", "graphState", "Landroidx/camera/camera2/pipe/GraphState;", "handleStateTransition", "postCameraState", "internalState", "stateError", "calculateNextState", "Landroidx/camera/camera2/adapter/CameraStateAdapter$CombinedCameraState;", "currentState", "calculateNextState$camera_camera2", "addCameraStateListener", "executor", "listener", "addCameraStateListener$camera_camera2", "removeCameraStateListener", "removeCameraStateListener$camera_camera2", "CombinedCameraState", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraStateAdapter {
    public static final androidx.camera.camera2.adapter.CameraStateAdapter.Companion Companion = null;
    private final androidx.camera.core.impl.LiveDataObservable<androidx.camera.core.impl.CameraInternal.State> cameraInternalState;
    private final androidx.lifecycle.MutableLiveData<androidx.camera.core.CameraState> cameraState;
    private final java.util.Map<androidx.core.util.Consumer<androidx.camera.core.CameraState>, java.util.concurrent.Executor> cameraStateListeners;
    private androidx.camera.core.impl.CameraInternal.State currentCameraInternalState;
    private androidx.camera.core.CameraState.StateError currentCameraStateError;
    private androidx.camera.camera2.pipe.CameraGraph currentGraph;
    private boolean isRemoved;
    private final java.lang.Object lock;

    /* JADX INFO: compiled from: CameraStateAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0080\b\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\r\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u001f\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0014\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0083\u0004J\n\u0010\u0012\u001a\u00020\u0013HÖ\u0081\u0004J\n\u0010\u0014\u001a\u00020\u0015HÖ\u0081\u0004R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0016"}, d2 = {"Landroidx/camera/camera2/adapter/CameraStateAdapter$CombinedCameraState;", "", "state", "Landroidx/camera/core/impl/CameraInternal$State;", "error", "Landroidx/camera/core/CameraState$StateError;", "<init>", "(Landroidx/camera/core/impl/CameraInternal$State;Landroidx/camera/core/CameraState$StateError;)V", "getState", "()Landroidx/camera/core/impl/CameraInternal$State;", "getError", "()Landroidx/camera/core/CameraState$StateError;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class CombinedCameraState {
        private final androidx.camera.core.CameraState.StateError error;
        private final androidx.camera.core.impl.CameraInternal.State state;

        public CombinedCameraState(androidx.camera.core.impl.CameraInternal.State r2, androidx.camera.core.CameraState.StateError r3) {
                r1 = this;
                java.lang.String r0 = "state"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                r1.<init>()
                r1.state = r2
                r1.error = r3
                return
        }

        public /* synthetic */ CombinedCameraState(androidx.camera.core.impl.CameraInternal.State r1, androidx.camera.core.CameraState.StateError r2, int r3, kotlin.jvm.internal.DefaultConstructorMarker r4) {
                r0 = this;
                r3 = r3 & 2
                if (r3 == 0) goto L5
                r2 = 0
            L5:
                r0.<init>(r1, r2)
                return
        }

        public static /* synthetic */ androidx.camera.camera2.adapter.CameraStateAdapter.CombinedCameraState copy$default(androidx.camera.camera2.adapter.CameraStateAdapter.CombinedCameraState r0, androidx.camera.core.impl.CameraInternal.State r1, androidx.camera.core.CameraState.StateError r2, int r3, java.lang.Object r4) {
                r4 = r3 & 1
                if (r4 == 0) goto L6
                androidx.camera.core.impl.CameraInternal$State r1 = r0.state
            L6:
                r3 = r3 & 2
                if (r3 == 0) goto Lc
                androidx.camera.core.CameraState$StateError r2 = r0.error
            Lc:
                androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r0 = r0.copy(r1, r2)
                return r0
        }

        public final androidx.camera.core.impl.CameraInternal.State component1() {
                r1 = this;
                androidx.camera.core.impl.CameraInternal$State r0 = r1.state
                return r0
        }

        public final androidx.camera.core.CameraState.StateError component2() {
                r1 = this;
                androidx.camera.core.CameraState$StateError r0 = r1.error
                return r0
        }

        public final androidx.camera.camera2.adapter.CameraStateAdapter.CombinedCameraState copy(androidx.camera.core.impl.CameraInternal.State r2, androidx.camera.core.CameraState.StateError r3) {
                r1 = this;
                java.lang.String r0 = "state"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r0 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
                r0.<init>(r2, r3)
                return r0
        }

        public boolean equals(java.lang.Object r5) {
                r4 = this;
                r0 = 1
                if (r4 != r5) goto L4
                return r0
            L4:
                boolean r1 = r5 instanceof androidx.camera.camera2.adapter.CameraStateAdapter.CombinedCameraState
                r2 = 0
                if (r1 != 0) goto La
                return r2
            La:
                androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r5 = (androidx.camera.camera2.adapter.CameraStateAdapter.CombinedCameraState) r5
                androidx.camera.core.impl.CameraInternal$State r1 = r4.state
                androidx.camera.core.impl.CameraInternal$State r3 = r5.state
                if (r1 == r3) goto L13
                return r2
            L13:
                androidx.camera.core.CameraState$StateError r1 = r4.error
                androidx.camera.core.CameraState$StateError r5 = r5.error
                boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)
                if (r5 != 0) goto L1e
                return r2
            L1e:
                return r0
        }

        public final androidx.camera.core.CameraState.StateError getError() {
                r1 = this;
                androidx.camera.core.CameraState$StateError r0 = r1.error
                return r0
        }

        public final androidx.camera.core.impl.CameraInternal.State getState() {
                r1 = this;
                androidx.camera.core.impl.CameraInternal$State r0 = r1.state
                return r0
        }

        public int hashCode() {
                r2 = this;
                androidx.camera.core.impl.CameraInternal$State r0 = r2.state
                int r0 = r0.hashCode()
                int r0 = r0 * 31
                androidx.camera.core.CameraState$StateError r1 = r2.error
                if (r1 != 0) goto Le
                r1 = 0
                goto L12
            Le:
                int r1 = r1.hashCode()
            L12:
                int r0 = r0 + r1
                return r0
        }

        public java.lang.String toString() {
                r2 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                java.lang.String r1 = "CombinedCameraState(state="
                r0.<init>(r1)
                androidx.camera.core.impl.CameraInternal$State r1 = r2.state
                r0.append(r1)
                java.lang.String r1 = ", error="
                r0.append(r1)
                androidx.camera.core.CameraState$StateError r1 = r2.error
                r0.append(r1)
                r1 = 41
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                return r0
        }
    }

    /* JADX INFO: compiled from: CameraStateAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u0005*\u00020\u0006H\u0000¢\u0006\u0004\b\u0007\u0010\bJ\u0011\u0010\t\u001a\u00020\n*\u00020\u000bH\u0000¢\u0006\u0002\b\fJ\u0017\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0006H\u0000¢\u0006\u0004\b\u0010\u0010\u0011J\u001f\u0010\u0012\u001a\u00020\u0013*\b\u0012\u0004\u0012\u00020\u00150\u00142\u0006\u0010\u0016\u001a\u00020\u0015H\u0000¢\u0006\u0002\b\u0017¨\u0006\u0018"}, d2 = {"Landroidx/camera/camera2/adapter/CameraStateAdapter$Companion;", "", "<init>", "()V", "toCameraStateError", "Landroidx/camera/core/CameraState$StateError;", "Landroidx/camera/camera2/pipe/CameraError;", "toCameraStateError-90vkdD0$camera_camera2", "(I)Landroidx/camera/core/CameraState$StateError;", "toCameraState", "Landroidx/camera/core/CameraState$Type;", "Landroidx/camera/core/impl/CameraInternal$State;", "toCameraState$camera_camera2", "isRecoverableError", "", "cameraError", "isRecoverableError-90vkdD0$camera_camera2", "(I)Z", "setOrPostValue", "", "Landroidx/lifecycle/MutableLiveData;", "Landroidx/camera/core/CameraState;", "cameraState", "setOrPostValue$camera_camera2", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {

        /* JADX INFO: compiled from: CameraStateAdapter.kt */
        @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
        public static final /* synthetic */ class WhenMappings {
            public static final /* synthetic */ int[] $EnumSwitchMapping$0 = null;

            static {
                    androidx.camera.core.impl.CameraInternal$State[] r0 = androidx.camera.core.impl.CameraInternal.State.values()
                    int r0 = r0.length
                    int[] r0 = new int[r0]
                    androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.CLOSED     // Catch: java.lang.NoSuchFieldError -> L10
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L10
                    r2 = 1
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L10
                L10:
                    androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.OPENING     // Catch: java.lang.NoSuchFieldError -> L19
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L19
                    r2 = 2
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L19
                L19:
                    androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.OPEN     // Catch: java.lang.NoSuchFieldError -> L22
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L22
                    r2 = 3
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L22
                L22:
                    androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.CLOSING     // Catch: java.lang.NoSuchFieldError -> L2b
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L2b
                    r2 = 4
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L2b
                L2b:
                    androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.PENDING_OPEN     // Catch: java.lang.NoSuchFieldError -> L34
                    int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L34
                    r2 = 5
                    r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L34
                L34:
                    androidx.camera.camera2.adapter.CameraStateAdapter.Companion.WhenMappings.$EnumSwitchMapping$0 = r0
                    return
            }
        }

        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        /* JADX INFO: renamed from: isRecoverableError-90vkdD0$camera_camera2, reason: not valid java name */
        public final boolean m64isRecoverableError90vkdD0$camera_camera2(int r2) {
                r1 = this;
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m388getERROR_CAMERA_DISCONNECTEDv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r2, r0)
                if (r0 != 0) goto L33
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m389getERROR_CAMERA_IN_USEv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r2, r0)
                if (r0 != 0) goto L33
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m390getERROR_CAMERA_LIMIT_EXCEEDEDv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r2, r0)
                if (r0 != 0) goto L33
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m386getERROR_CAMERA_DEVICEv7Vf74A()
                boolean r2 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r2, r0)
                if (r2 == 0) goto L31
                goto L33
            L31:
                r2 = 0
                return r2
            L33:
                r2 = 1
                return r2
        }

        public final void setOrPostValue$camera_camera2(androidx.lifecycle.MutableLiveData<androidx.camera.core.CameraState> r3, androidx.camera.core.CameraState r4) {
                r2 = this;
                java.lang.String r0 = "<this>"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                java.lang.String r0 = "cameraState"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
                android.os.Looper r0 = android.os.Looper.myLooper()
                android.os.Looper r1 = android.os.Looper.getMainLooper()
                boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r1)
                if (r0 == 0) goto L1c
                r3.setValue(r4)
                return
            L1c:
                r3.postValue(r4)
                return
        }

        public final androidx.camera.core.CameraState.Type toCameraState$camera_camera2(androidx.camera.core.impl.CameraInternal.State r4) {
                r3 = this;
                java.lang.String r0 = "<this>"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
                int[] r0 = androidx.camera.camera2.adapter.CameraStateAdapter.Companion.WhenMappings.$EnumSwitchMapping$0
                int r1 = r4.ordinal()
                r0 = r0[r1]
                r1 = 1
                if (r0 == r1) goto L3c
                r1 = 2
                if (r0 == r1) goto L39
                r1 = 3
                if (r0 == r1) goto L36
                r1 = 4
                if (r0 == r1) goto L33
                r1 = 5
                if (r0 != r1) goto L1f
                androidx.camera.core.CameraState$Type r4 = androidx.camera.core.CameraState.Type.PENDING_OPEN
                return r4
            L1f:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                java.lang.String r2 = "Unexpected CameraInternal state: "
                r1.<init>(r2)
                r1.append(r4)
                java.lang.String r4 = r1.toString()
                r0.<init>(r4)
                throw r0
            L33:
                androidx.camera.core.CameraState$Type r4 = androidx.camera.core.CameraState.Type.CLOSING
                return r4
            L36:
                androidx.camera.core.CameraState$Type r4 = androidx.camera.core.CameraState.Type.OPEN
                return r4
            L39:
                androidx.camera.core.CameraState$Type r4 = androidx.camera.core.CameraState.Type.OPENING
                return r4
            L3c:
                androidx.camera.core.CameraState$Type r4 = androidx.camera.core.CameraState.Type.CLOSED
                return r4
        }

        /* JADX INFO: renamed from: toCameraStateError-90vkdD0$camera_camera2, reason: not valid java name */
        public final androidx.camera.core.CameraState.StateError m65toCameraStateError90vkdD0$camera_camera2(int r4) {
                r3 = this;
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m398getERROR_UNDETERMINEDv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                r1 = 6
                if (r0 == 0) goto Lf
                goto Lc3
            Lf:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m389getERROR_CAMERA_IN_USEv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                r2 = 2
                if (r0 == 0) goto L1f
            L1c:
                r1 = r2
                goto Lc3
            L1f:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m390getERROR_CAMERA_LIMIT_EXCEEDEDv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L2e
                r1 = 1
                goto Lc3
            L2e:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m387getERROR_CAMERA_DISABLEDv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L3d
                r1 = 5
                goto Lc3
            L3d:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m386getERROR_CAMERA_DEVICEv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L4c
                r1 = 3
                goto Lc3
            L4c:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m393getERROR_CAMERA_SERVICEv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L5a
                goto Lc3
            L5a:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m388getERROR_CAMERA_DISCONNECTEDv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L67
                goto L1c
            L67:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m396getERROR_ILLEGAL_ARGUMENT_EXCEPTIONv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L74
                goto Lc3
            L74:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m397getERROR_SECURITY_EXCEPTIONv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L81
                goto Lc3
            L81:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m395getERROR_GRAPH_CONFIGv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L8f
                r1 = 4
                goto Lc3
            L8f:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m394getERROR_DO_NOT_DISTURB_ENABLEDv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto L9d
                r1 = 7
                goto Lc3
            L9d:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m399getERROR_UNKNOWN_EXCEPTIONv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto Laa
                goto Lc3
            Laa:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m391getERROR_CAMERA_OPENERv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto Lb7
                goto Lc3
            Lb7:
                androidx.camera.camera2.pipe.CameraError$Companion r0 = androidx.camera.camera2.pipe.CameraError.Companion
                int r0 = r0.m392getERROR_CAMERA_OPEN_TIMEOUTv7Vf74A()
                boolean r0 = androidx.camera.camera2.pipe.CameraError.m378equalsimpl0(r4, r0)
                if (r0 == 0) goto Lcd
            Lc3:
                androidx.camera.core.CameraState$StateError r4 = androidx.camera.core.CameraState.StateError.create(r1)
                java.lang.String r0 = "create(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r0)
                return r4
            Lcd:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r1 = new java.lang.StringBuilder
                java.lang.String r2 = "Unexpected CameraError: "
                r1.<init>(r2)
                java.lang.String r4 = androidx.camera.camera2.pipe.CameraError.m381toStringimpl(r4)
                r1.append(r4)
                java.lang.String r4 = r1.toString()
                r0.<init>(r4)
                throw r0
        }
    }

    /* JADX INFO: compiled from: CameraStateAdapter.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0 = null;

        static {
                androidx.camera.core.impl.CameraInternal$State[] r0 = androidx.camera.core.impl.CameraInternal.State.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.CLOSED     // Catch: java.lang.NoSuchFieldError -> L10
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L10
                r2 = 1
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L10
            L10:
                androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.OPENING     // Catch: java.lang.NoSuchFieldError -> L19
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L19
                r2 = 2
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L19
            L19:
                androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.OPEN     // Catch: java.lang.NoSuchFieldError -> L22
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L22
                r2 = 3
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L22
            L22:
                androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.CLOSING     // Catch: java.lang.NoSuchFieldError -> L2b
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L2b
                r2 = 4
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L2b
            L2b:
                androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.PENDING_OPEN     // Catch: java.lang.NoSuchFieldError -> L34
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L34
                r2 = 5
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L34
            L34:
                androidx.camera.camera2.adapter.CameraStateAdapter.WhenMappings.$EnumSwitchMapping$0 = r0
                return
        }
    }

    public static /* synthetic */ void $r8$lambda$6FOKxeEC7IWChTAzIfXreZ8PTVY(androidx.core.util.Consumer r0, androidx.camera.core.CameraState r1) {
            postCameraState$lambda$1$0(r0, r1)
            return
    }

    static {
            androidx.camera.camera2.adapter.CameraStateAdapter$Companion r0 = new androidx.camera.camera2.adapter.CameraStateAdapter$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.adapter.CameraStateAdapter.Companion = r0
            return
    }

    @javax.inject.Inject
    public CameraStateAdapter() {
            r3 = this;
            r3.<init>()
            java.lang.Object r0 = new java.lang.Object
            r0.<init>()
            r3.lock = r0
            androidx.camera.core.impl.LiveDataObservable r0 = new androidx.camera.core.impl.LiveDataObservable
            r0.<init>()
            r3.cameraInternalState = r0
            androidx.lifecycle.MutableLiveData r0 = new androidx.lifecycle.MutableLiveData
            r0.<init>()
            r3.cameraState = r0
            androidx.camera.core.impl.CameraInternal$State r0 = androidx.camera.core.impl.CameraInternal.State.CLOSED
            r3.currentCameraInternalState = r0
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            r3.cameraStateListeners = r0
            androidx.camera.core.impl.CameraInternal$State r0 = androidx.camera.core.impl.CameraInternal.State.CLOSED
            r1 = 0
            r2 = 2
            postCameraState$default(r3, r0, r1, r2, r1)
            return
    }

    public static final /* synthetic */ androidx.camera.core.impl.CameraInternal.State access$getCurrentCameraInternalState$p(androidx.camera.camera2.adapter.CameraStateAdapter r0) {
            androidx.camera.core.impl.CameraInternal$State r0 = r0.currentCameraInternalState
            return r0
    }

    public static final /* synthetic */ androidx.camera.camera2.pipe.CameraGraph access$getCurrentGraph$p(androidx.camera.camera2.adapter.CameraStateAdapter r0) {
            androidx.camera.camera2.pipe.CameraGraph r0 = r0.currentGraph
            return r0
    }

    private final void handleStateTransition(androidx.camera.camera2.pipe.CameraGraph r4, androidx.camera.camera2.pipe.GraphState r5) {
            r3 = this;
            androidx.camera.camera2.pipe.CameraGraph r0 = r3.currentGraph
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r4, r0)
            java.lang.String r1 = "CXCP"
            if (r0 != 0) goto L30
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r0 == 0) goto L61
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Ignored stale transition "
            r1.<init>(r2)
            r1.append(r5)
            java.lang.String r5 = " for "
            r1.append(r5)
            r1.append(r4)
            java.lang.String r4 = r1.toString()
            android.util.Log.d(r0, r4)
            return
        L30:
            androidx.camera.core.impl.CameraInternal$State r4 = r3.currentCameraInternalState
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = r3.calculateNextState$camera_camera2(r4, r5)
            if (r4 != 0) goto L62
            androidx.camera.camera2.impl.Camera2Logger r4 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r4 = androidx.camera.core.Logger.isWarnEnabled(r1)
            if (r4 == 0) goto L61
            java.lang.String r4 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Impermissible state transition: current camera internal state: "
            r0.<init>(r1)
            androidx.camera.core.impl.CameraInternal$State r1 = access$getCurrentCameraInternalState$p(r3)
            r0.append(r1)
            java.lang.String r1 = ", received graph state: "
            r0.append(r1)
            r0.append(r5)
            java.lang.String r5 = r0.toString()
            android.util.Log.w(r4, r5)
        L61:
            return
        L62:
            androidx.camera.core.impl.CameraInternal$State r5 = r4.getState()
            r3.currentCameraInternalState = r5
            androidx.camera.core.CameraState$StateError r5 = r4.getError()
            r3.currentCameraStateError = r5
            androidx.camera.camera2.impl.Camera2Logger r5 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            boolean r5 = androidx.camera.core.Logger.isDebugEnabled(r1)
            if (r5 == 0) goto L8b
            java.lang.String r5 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Updated current camera internal state to "
            r0.<init>(r1)
            r0.append(r4)
            java.lang.String r4 = r0.toString()
            android.util.Log.d(r5, r4)
        L8b:
            androidx.camera.core.impl.CameraInternal$State r4 = r3.currentCameraInternalState
            androidx.camera.core.CameraState$StateError r5 = r3.currentCameraStateError
            r3.postCameraState(r4, r5)
            return
    }

    private final void postCameraState(androidx.camera.core.impl.CameraInternal.State r4, androidx.camera.core.CameraState.StateError r5) {
            r3 = this;
            androidx.camera.core.impl.LiveDataObservable<androidx.camera.core.impl.CameraInternal$State> r0 = r3.cameraInternalState
            r0.postValue(r4)
            androidx.camera.camera2.adapter.CameraStateAdapter$Companion r0 = androidx.camera.camera2.adapter.CameraStateAdapter.Companion
            androidx.camera.core.CameraState$Type r4 = r0.toCameraState$camera_camera2(r4)
            androidx.camera.core.CameraState r4 = androidx.camera.core.CameraState.create(r4, r5)
            java.lang.String r5 = "create(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r5)
            androidx.lifecycle.MutableLiveData<androidx.camera.core.CameraState> r5 = r3.cameraState
            r0.setOrPostValue$camera_camera2(r5, r4)
            java.lang.Object r5 = r3.lock
            monitor-enter(r5)
            java.util.Map<androidx.core.util.Consumer<androidx.camera.core.CameraState>, java.util.concurrent.Executor> r0 = r3.cameraStateListeners     // Catch: java.lang.Throwable -> L51
            java.util.Set r0 = r0.entrySet()     // Catch: java.lang.Throwable -> L51
            java.lang.Iterable r0 = (java.lang.Iterable) r0     // Catch: java.lang.Throwable -> L51
            java.util.List r0 = kotlin.collections.CollectionsKt.toList(r0)     // Catch: java.lang.Throwable -> L51
            monitor-exit(r5)
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.Iterator r5 = r0.iterator()
        L2f:
            boolean r0 = r5.hasNext()
            if (r0 == 0) goto L50
            java.lang.Object r0 = r5.next()
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            java.lang.Object r1 = r0.getKey()
            androidx.core.util.Consumer r1 = (androidx.core.util.Consumer) r1
            java.lang.Object r0 = r0.getValue()
            java.util.concurrent.Executor r0 = (java.util.concurrent.Executor) r0
            androidx.camera.camera2.adapter.CameraStateAdapter$$ExternalSyntheticLambda0 r2 = new androidx.camera.camera2.adapter.CameraStateAdapter$$ExternalSyntheticLambda0
            r2.<init>(r1, r4)
            r0.execute(r2)
            goto L2f
        L50:
            return
        L51:
            r4 = move-exception
            monitor-exit(r5)
            throw r4
    }

    static /* synthetic */ void postCameraState$default(androidx.camera.camera2.adapter.CameraStateAdapter r0, androidx.camera.core.impl.CameraInternal.State r1, androidx.camera.core.CameraState.StateError r2, int r3, java.lang.Object r4) {
            r3 = r3 & 2
            if (r3 == 0) goto L5
            r2 = 0
        L5:
            r0.postCameraState(r1, r2)
            return
    }

    private static final void postCameraState$lambda$1$0(androidx.core.util.Consumer r0, androidx.camera.core.CameraState r1) {
            r0.accept(r1)
            return
    }

    public final void addCameraStateListener$camera_camera2(java.util.concurrent.Executor r3, androidx.core.util.Consumer<androidx.camera.core.CameraState> r4) {
            r2 = this;
            java.lang.String r0 = "executor"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "listener"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.Object r0 = r2.lock
            monitor-enter(r0)
            java.util.Map<androidx.core.util.Consumer<androidx.camera.core.CameraState>, java.util.concurrent.Executor> r1 = r2.cameraStateListeners     // Catch: java.lang.Throwable -> L16
            r1.put(r4, r3)     // Catch: java.lang.Throwable -> L16
            kotlin.Unit r3 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L16
            monitor-exit(r0)
            return
        L16:
            r3 = move-exception
            monitor-exit(r0)
            throw r3
    }

    public final androidx.camera.camera2.adapter.CameraStateAdapter.CombinedCameraState calculateNextState$camera_camera2(androidx.camera.core.impl.CameraInternal.State r4, androidx.camera.camera2.pipe.GraphState r5) {
            r3 = this;
            java.lang.String r0 = "currentState"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "graphState"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            int[] r0 = androidx.camera.camera2.adapter.CameraStateAdapter.WhenMappings.$EnumSwitchMapping$0
            int r4 = r4.ordinal()
            r4 = r0[r4]
            r0 = 1
            r1 = 2
            r2 = 0
            if (r4 == r0) goto L17d
            if (r4 == r1) goto L102
            r0 = 3
            if (r4 == r0) goto Laf
            r0 = 4
            if (r4 == r0) goto L76
            r0 = 5
            if (r4 == r0) goto L23
            return r2
        L23:
            androidx.camera.camera2.pipe.GraphState$GraphStateStarting r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStarting.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L33
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.OPENING
            r4.<init>(r5, r2, r1, r2)
            return r4
        L33:
            androidx.camera.camera2.pipe.GraphState$GraphStateStarted r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStarted.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L43
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.OPEN
            r4.<init>(r5, r2, r1, r2)
            return r4
        L43:
            boolean r4 = r5 instanceof androidx.camera.camera2.pipe.GraphState.GraphStateError
            if (r4 == 0) goto L75
            androidx.camera.camera2.adapter.CameraStateAdapter$Companion r4 = androidx.camera.camera2.adapter.CameraStateAdapter.Companion
            androidx.camera.camera2.pipe.GraphState$GraphStateError r5 = (androidx.camera.camera2.pipe.GraphState.GraphStateError) r5
            int r0 = r5.m570getCameraErrorv7Vf74A()
            boolean r0 = r4.m64isRecoverableError90vkdD0$camera_camera2(r0)
            if (r0 == 0) goto L65
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r0 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.PENDING_OPEN
            int r5 = r5.m570getCameraErrorv7Vf74A()
            androidx.camera.core.CameraState$StateError r4 = r4.m65toCameraStateError90vkdD0$camera_camera2(r5)
            r0.<init>(r1, r4)
            return r0
        L65:
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r0 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.CLOSED
            int r5 = r5.m570getCameraErrorv7Vf74A()
            androidx.camera.core.CameraState$StateError r4 = r4.m65toCameraStateError90vkdD0$camera_camera2(r5)
            r0.<init>(r1, r4)
            return r0
        L75:
            return r2
        L76:
            androidx.camera.camera2.pipe.GraphState$GraphStateStopped r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStopped.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L86
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.CLOSED
            r4.<init>(r5, r2, r1, r2)
            return r4
        L86:
            androidx.camera.camera2.pipe.GraphState$GraphStateStarting r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStarting.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L96
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.OPENING
            r4.<init>(r5, r2, r1, r2)
            return r4
        L96:
            boolean r4 = r5 instanceof androidx.camera.camera2.pipe.GraphState.GraphStateError
            if (r4 == 0) goto Lae
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r0 = androidx.camera.core.impl.CameraInternal.State.CLOSING
            androidx.camera.camera2.adapter.CameraStateAdapter$Companion r1 = androidx.camera.camera2.adapter.CameraStateAdapter.Companion
            androidx.camera.camera2.pipe.GraphState$GraphStateError r5 = (androidx.camera.camera2.pipe.GraphState.GraphStateError) r5
            int r5 = r5.m570getCameraErrorv7Vf74A()
            androidx.camera.core.CameraState$StateError r5 = r1.m65toCameraStateError90vkdD0$camera_camera2(r5)
            r4.<init>(r0, r5)
            return r4
        Lae:
            return r2
        Laf:
            androidx.camera.camera2.pipe.GraphState$GraphStateStopping r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStopping.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto Lbf
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.CLOSING
            r4.<init>(r5, r2, r1, r2)
            return r4
        Lbf:
            androidx.camera.camera2.pipe.GraphState$GraphStateStopped r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStopped.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto Lcf
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.CLOSED
            r4.<init>(r5, r2, r1, r2)
            return r4
        Lcf:
            boolean r4 = r5 instanceof androidx.camera.camera2.pipe.GraphState.GraphStateError
            if (r4 == 0) goto L101
            androidx.camera.camera2.adapter.CameraStateAdapter$Companion r4 = androidx.camera.camera2.adapter.CameraStateAdapter.Companion
            androidx.camera.camera2.pipe.GraphState$GraphStateError r5 = (androidx.camera.camera2.pipe.GraphState.GraphStateError) r5
            int r0 = r5.m570getCameraErrorv7Vf74A()
            boolean r0 = r4.m64isRecoverableError90vkdD0$camera_camera2(r0)
            if (r0 == 0) goto Lf1
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r0 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.PENDING_OPEN
            int r5 = r5.m570getCameraErrorv7Vf74A()
            androidx.camera.core.CameraState$StateError r4 = r4.m65toCameraStateError90vkdD0$camera_camera2(r5)
            r0.<init>(r1, r4)
            return r0
        Lf1:
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r0 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.CLOSED
            int r5 = r5.m570getCameraErrorv7Vf74A()
            androidx.camera.core.CameraState$StateError r4 = r4.m65toCameraStateError90vkdD0$camera_camera2(r5)
            r0.<init>(r1, r4)
            return r0
        L101:
            return r2
        L102:
            androidx.camera.camera2.pipe.GraphState$GraphStateStarted r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStarted.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L112
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.OPEN
            r4.<init>(r5, r2, r1, r2)
            return r4
        L112:
            boolean r4 = r5 instanceof androidx.camera.camera2.pipe.GraphState.GraphStateError
            if (r4 == 0) goto L15c
            androidx.camera.camera2.pipe.GraphState$GraphStateError r5 = (androidx.camera.camera2.pipe.GraphState.GraphStateError) r5
            boolean r4 = r5.getWillAttemptRetry()
            if (r4 == 0) goto L130
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r0 = androidx.camera.core.impl.CameraInternal.State.OPENING
            androidx.camera.camera2.adapter.CameraStateAdapter$Companion r1 = androidx.camera.camera2.adapter.CameraStateAdapter.Companion
            int r5 = r5.m570getCameraErrorv7Vf74A()
            androidx.camera.core.CameraState$StateError r5 = r1.m65toCameraStateError90vkdD0$camera_camera2(r5)
            r4.<init>(r0, r5)
            return r4
        L130:
            androidx.camera.camera2.adapter.CameraStateAdapter$Companion r4 = androidx.camera.camera2.adapter.CameraStateAdapter.Companion
            int r0 = r5.m570getCameraErrorv7Vf74A()
            boolean r0 = r4.m64isRecoverableError90vkdD0$camera_camera2(r0)
            if (r0 == 0) goto L14c
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r0 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.PENDING_OPEN
            int r5 = r5.m570getCameraErrorv7Vf74A()
            androidx.camera.core.CameraState$StateError r4 = r4.m65toCameraStateError90vkdD0$camera_camera2(r5)
            r0.<init>(r1, r4)
            return r0
        L14c:
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r0 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r1 = androidx.camera.core.impl.CameraInternal.State.CLOSING
            int r5 = r5.m570getCameraErrorv7Vf74A()
            androidx.camera.core.CameraState$StateError r4 = r4.m65toCameraStateError90vkdD0$camera_camera2(r5)
            r0.<init>(r1, r4)
            return r0
        L15c:
            androidx.camera.camera2.pipe.GraphState$GraphStateStopping r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStopping.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L16c
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.CLOSING
            r4.<init>(r5, r2, r1, r2)
            return r4
        L16c:
            androidx.camera.camera2.pipe.GraphState$GraphStateStopped r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStopped.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L17c
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.CLOSED
            r4.<init>(r5, r2, r1, r2)
            return r4
        L17c:
            return r2
        L17d:
            androidx.camera.camera2.pipe.GraphState$GraphStateStarting r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStarting.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L18d
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.OPENING
            r4.<init>(r5, r2, r1, r2)
            return r4
        L18d:
            androidx.camera.camera2.pipe.GraphState$GraphStateStarted r4 = androidx.camera.camera2.pipe.GraphState.GraphStateStarted.INSTANCE
            boolean r4 = kotlin.jvm.internal.Intrinsics.areEqual(r5, r4)
            if (r4 == 0) goto L19d
            androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState r4 = new androidx.camera.camera2.adapter.CameraStateAdapter$CombinedCameraState
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.OPEN
            r4.<init>(r5, r2, r1, r2)
            return r4
        L19d:
            return r2
    }

    public final androidx.camera.core.impl.LiveDataObservable<androidx.camera.core.impl.CameraInternal.State> getCameraInternalState$camera_camera2() {
            r1 = this;
            androidx.camera.core.impl.LiveDataObservable<androidx.camera.core.impl.CameraInternal$State> r0 = r1.cameraInternalState
            return r0
    }

    public final androidx.lifecycle.MutableLiveData<androidx.camera.core.CameraState> getCameraState$camera_camera2() {
            r1 = this;
            androidx.lifecycle.MutableLiveData<androidx.camera.core.CameraState> r0 = r1.cameraState
            return r0
    }

    public final void onGraphStateUpdated(androidx.camera.camera2.pipe.CameraGraph r5, androidx.camera.camera2.pipe.GraphState r6) {
            r4 = this;
            java.lang.String r0 = "Ignoring graph state update "
            java.lang.String r1 = "cameraGraph"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r1)
            java.lang.String r1 = "graphState"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r1)
            java.lang.Object r1 = r4.lock
            monitor-enter(r1)
            boolean r2 = r4.isRemoved     // Catch: java.lang.Throwable -> L63
            if (r2 == 0) goto L37
            androidx.camera.camera2.impl.Camera2Logger r5 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Throwable -> L63
            java.lang.String r5 = "CXCP"
            boolean r5 = androidx.camera.core.Logger.isWarnEnabled(r5)     // Catch: java.lang.Throwable -> L63
            if (r5 == 0) goto L35
            java.lang.String r5 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Throwable -> L63
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L63
            r2.<init>(r0)     // Catch: java.lang.Throwable -> L63
            r2.append(r6)     // Catch: java.lang.Throwable -> L63
            java.lang.String r6 = " on removed camera."
            r2.append(r6)     // Catch: java.lang.Throwable -> L63
            java.lang.String r6 = r2.toString()     // Catch: java.lang.Throwable -> L63
            android.util.Log.w(r5, r6)     // Catch: java.lang.Throwable -> L63
        L35:
            monitor-exit(r1)
            return
        L37:
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Throwable -> L63
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r0)     // Catch: java.lang.Throwable -> L63
            if (r0 == 0) goto L5c
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Throwable -> L63
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L63
            r2.<init>()     // Catch: java.lang.Throwable -> L63
            r2.append(r5)     // Catch: java.lang.Throwable -> L63
            java.lang.String r3 = " state updated to "
            r2.append(r3)     // Catch: java.lang.Throwable -> L63
            r2.append(r6)     // Catch: java.lang.Throwable -> L63
            java.lang.String r2 = r2.toString()     // Catch: java.lang.Throwable -> L63
            android.util.Log.d(r0, r2)     // Catch: java.lang.Throwable -> L63
        L5c:
            r4.handleStateTransition(r5, r6)     // Catch: java.lang.Throwable -> L63
            kotlin.Unit r5 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L63
            monitor-exit(r1)
            return
        L63:
            r5 = move-exception
            monitor-exit(r1)
            throw r5
    }

    public final void onGraphUpdated(androidx.camera.camera2.pipe.CameraGraph r5) {
            r4 = this;
            java.lang.String r0 = "Camera graph updated from "
            java.lang.String r1 = "cameraGraph"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r1)
            java.lang.Object r1 = r4.lock
            monitor-enter(r1)
            androidx.camera.camera2.impl.Camera2Logger r2 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Throwable -> L4f
            java.lang.String r2 = "CXCP"
            boolean r2 = androidx.camera.core.Logger.isDebugEnabled(r2)     // Catch: java.lang.Throwable -> L4f
            if (r2 == 0) goto L33
            java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Throwable -> L4f
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L4f
            r3.<init>(r0)     // Catch: java.lang.Throwable -> L4f
            androidx.camera.camera2.pipe.CameraGraph r0 = access$getCurrentGraph$p(r4)     // Catch: java.lang.Throwable -> L4f
            r3.append(r0)     // Catch: java.lang.Throwable -> L4f
            java.lang.String r0 = " to "
            r3.append(r0)     // Catch: java.lang.Throwable -> L4f
            r3.append(r5)     // Catch: java.lang.Throwable -> L4f
            java.lang.String r0 = r3.toString()     // Catch: java.lang.Throwable -> L4f
            android.util.Log.d(r2, r0)     // Catch: java.lang.Throwable -> L4f
        L33:
            androidx.camera.core.impl.CameraInternal$State r0 = r4.currentCameraInternalState     // Catch: java.lang.Throwable -> L4f
            androidx.camera.core.impl.CameraInternal$State r2 = androidx.camera.core.impl.CameraInternal.State.CLOSED     // Catch: java.lang.Throwable -> L4f
            if (r0 == r2) goto L45
            androidx.camera.core.impl.CameraInternal$State r0 = androidx.camera.core.impl.CameraInternal.State.CLOSING     // Catch: java.lang.Throwable -> L4f
            r2 = 2
            r3 = 0
            postCameraState$default(r4, r0, r3, r2, r3)     // Catch: java.lang.Throwable -> L4f
            androidx.camera.core.impl.CameraInternal$State r0 = androidx.camera.core.impl.CameraInternal.State.CLOSED     // Catch: java.lang.Throwable -> L4f
            postCameraState$default(r4, r0, r3, r2, r3)     // Catch: java.lang.Throwable -> L4f
        L45:
            r4.currentGraph = r5     // Catch: java.lang.Throwable -> L4f
            androidx.camera.core.impl.CameraInternal$State r5 = androidx.camera.core.impl.CameraInternal.State.CLOSED     // Catch: java.lang.Throwable -> L4f
            r4.currentCameraInternalState = r5     // Catch: java.lang.Throwable -> L4f
            kotlin.Unit r5 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L4f
            monitor-exit(r1)
            return
        L4f:
            r5 = move-exception
            monitor-exit(r1)
            throw r5
    }

    public final void onRemoved() {
            r4 = this;
            r0 = 8
            androidx.camera.core.CameraState$StateError r0 = androidx.camera.core.CameraState.StateError.create(r0)
            java.lang.String r1 = "create(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r1 = r4.lock
            monitor-enter(r1)
            boolean r2 = r4.isRemoved     // Catch: java.lang.Throwable -> L3a
            if (r2 == 0) goto L14
            monitor-exit(r1)
            return
        L14:
            androidx.camera.camera2.impl.Camera2Logger r2 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Throwable -> L3a
            java.lang.String r2 = "CXCP"
            boolean r2 = androidx.camera.core.Logger.isDebugEnabled(r2)     // Catch: java.lang.Throwable -> L3a
            if (r2 == 0) goto L27
            java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Throwable -> L3a
            java.lang.String r3 = "Camera is removed, forcing state to CLOSED."
            android.util.Log.d(r2, r3)     // Catch: java.lang.Throwable -> L3a
        L27:
            r2 = 1
            r4.isRemoved = r2     // Catch: java.lang.Throwable -> L3a
            androidx.camera.core.impl.CameraInternal$State r2 = androidx.camera.core.impl.CameraInternal.State.CLOSED     // Catch: java.lang.Throwable -> L3a
            r4.currentCameraInternalState = r2     // Catch: java.lang.Throwable -> L3a
            r4.currentCameraStateError = r0     // Catch: java.lang.Throwable -> L3a
            r4.postCameraState(r2, r0)     // Catch: java.lang.Throwable -> L3a
            r0 = 0
            r4.currentGraph = r0     // Catch: java.lang.Throwable -> L3a
            kotlin.Unit r0 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L3a
            monitor-exit(r1)
            return
        L3a:
            r0 = move-exception
            monitor-exit(r1)
            throw r0
    }

    public final void removeCameraStateListener$camera_camera2(androidx.core.util.Consumer<androidx.camera.core.CameraState> r3) {
            r2 = this;
            java.lang.String r0 = "listener"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.Object r0 = r2.lock
            monitor-enter(r0)
            java.util.Map<androidx.core.util.Consumer<androidx.camera.core.CameraState>, java.util.concurrent.Executor> r1 = r2.cameraStateListeners     // Catch: java.lang.Throwable -> L12
            java.lang.Object r3 = r1.remove(r3)     // Catch: java.lang.Throwable -> L12
            java.util.concurrent.Executor r3 = (java.util.concurrent.Executor) r3     // Catch: java.lang.Throwable -> L12
            monitor-exit(r0)
            return
        L12:
            r3 = move-exception
            monitor-exit(r0)
            throw r3
    }
}
