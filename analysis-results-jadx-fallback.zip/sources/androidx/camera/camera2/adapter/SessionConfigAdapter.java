package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: SessionConfigAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u001e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 02\u00020\u0001:\u00010B\u001f\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bJ\b\u0010#\u001a\u0004\u0018\u00010\u001aJ\u0006\u0010$\u001a\u00020\u0006J\u000e\u0010%\u001a\u00020&2\u0006\u0010'\u001a\u00020\u000bJ4\u0010(\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\f0\n2\f\u0010)\u001a\b\u0012\u0004\u0012\u00020\u001a0\u00032\u0010\u0010*\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030+0\u0003H\u0007J\"\u0010,\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\f0\n2\f\u0010)\u001a\b\u0012\u0004\u0012\u00020\u001a0\u0003H\u0007J\u0016\u0010-\u001a\u00020\f2\f\u0010.\u001a\b\u0012\u0002\b\u0003\u0018\u00010/H\u0002R\u0014\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R'\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\f0\n8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\r\u0010\u000eR'\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\f0\n8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\u0013\u0010\u0010\u001a\u0004\b\u0012\u0010\u000eR\u001b\u0010\u0014\u001a\u00020\u00158BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u0018\u0010\u0010\u001a\u0004\b\u0016\u0010\u0017R\u001b\u0010\u0019\u001a\u00020\u001a8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001d\u0010\u0010\u001a\u0004\b\u001b\u0010\u001cR!\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u000b0\u001f8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\"\u0010\u0010\u001a\u0004\b \u0010!¨\u00061"}, d2 = {"Landroidx/camera/camera2/adapter/SessionConfigAdapter;", "", "useCases", "", "Landroidx/camera/core/UseCase;", "isPrimary", "", "<init>", "(Ljava/util/Collection;Z)V", "surfaceToStreamUseCaseMap", "", "Landroidx/camera/core/impl/DeferrableSurface;", "", "getSurfaceToStreamUseCaseMap", "()Ljava/util/Map;", "surfaceToStreamUseCaseMap$delegate", "Lkotlin/Lazy;", "surfaceToStreamUseHintMap", "getSurfaceToStreamUseHintMap", "surfaceToStreamUseHintMap$delegate", "validatingBuilder", "Landroidx/camera/core/impl/SessionConfig$ValidatingBuilder;", "getValidatingBuilder", "()Landroidx/camera/core/impl/SessionConfig$ValidatingBuilder;", "validatingBuilder$delegate", "sessionConfig", "Landroidx/camera/core/impl/SessionConfig;", "getSessionConfig", "()Landroidx/camera/core/impl/SessionConfig;", "sessionConfig$delegate", "deferrableSurfaces", "", "getDeferrableSurfaces", "()Ljava/util/List;", "deferrableSurfaces$delegate", "getValidSessionConfigOrNull", "isSessionConfigValid", "reportSurfaceInvalid", "", "deferrableSurface", "getSurfaceToStreamUseCaseMapping", "sessionConfigs", "useCaseConfigs", "Landroidx/camera/core/impl/UseCaseConfig;", "getSurfaceToStreamUseHintMapping", "getStreamUseHintForContainerClass", "kClass", "Ljava/lang/Class;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class SessionConfigAdapter {
    public static final androidx.camera.camera2.adapter.SessionConfigAdapter.Companion Companion = null;
    private final kotlin.Lazy deferrableSurfaces$delegate;
    private final boolean isPrimary;
    private final kotlin.Lazy sessionConfig$delegate;
    private final kotlin.Lazy surfaceToStreamUseCaseMap$delegate;
    private final kotlin.Lazy surfaceToStreamUseHintMap$delegate;
    private final java.util.Collection<androidx.camera.core.UseCase> useCases;
    private final kotlin.Lazy validatingBuilder$delegate;

    /* JADX INFO: compiled from: SessionConfigAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u0005*\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b¨\u0006\t"}, d2 = {"Landroidx/camera/camera2/adapter/SessionConfigAdapter$Companion;", "", "<init>", "()V", "getSessionConfig", "Landroidx/camera/core/impl/SessionConfig;", "Landroidx/camera/core/UseCase;", "isPrimary", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final androidx.camera.core.impl.SessionConfig getSessionConfig(androidx.camera.core.UseCase r2, boolean r3) {
                r1 = this;
                java.lang.String r0 = "<this>"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                if (r3 == 0) goto L11
                androidx.camera.core.impl.SessionConfig r2 = r2.getSessionConfig()
                java.lang.String r3 = "getSessionConfig(...)"
            Ld:
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
                return r2
            L11:
                androidx.camera.core.impl.SessionConfig r2 = r2.getSecondarySessionConfig()
                java.lang.String r3 = "getSecondarySessionConfig(...)"
                goto Ld
        }
    }

    /* JADX INFO: renamed from: androidx.camera.camera2.adapter.SessionConfigAdapter$reportSurfaceInvalid$2, reason: invalid class name */
    /* JADX INFO: compiled from: SessionConfigAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.camera.camera2.adapter.SessionConfigAdapter$reportSurfaceInvalid$2", f = "SessionConfigAdapter.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    static final class AnonymousClass2 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
        final /* synthetic */ androidx.camera.core.impl.SessionConfig $sessionConfig;
        int label;

        AnonymousClass2(androidx.camera.core.impl.SessionConfig r1, kotlin.coroutines.Continuation<? super androidx.camera.camera2.adapter.SessionConfigAdapter.AnonymousClass2> r2) {
                r0 = this;
                r0.$sessionConfig = r1
                r1 = 2
                r0.<init>(r1, r2)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r2, kotlin.coroutines.Continuation<?> r3) {
                r1 = this;
                androidx.camera.camera2.adapter.SessionConfigAdapter$reportSurfaceInvalid$2 r2 = new androidx.camera.camera2.adapter.SessionConfigAdapter$reportSurfaceInvalid$2
                androidx.camera.core.impl.SessionConfig r0 = r1.$sessionConfig
                r2.<init>(r0, r3)
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                return r2
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
                r0 = this;
                kotlinx.coroutines.CoroutineScope r1 = (kotlinx.coroutines.CoroutineScope) r1
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                java.lang.Object r1 = r0.invoke2(r1, r2)
                return r1
        }

        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
        public final java.lang.Object invoke2(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
                r0 = this;
                kotlin.coroutines.Continuation r1 = r0.create(r1, r2)
                androidx.camera.camera2.adapter.SessionConfigAdapter$reportSurfaceInvalid$2 r1 = (androidx.camera.camera2.adapter.SessionConfigAdapter.AnonymousClass2) r1
                kotlin.Unit r2 = kotlin.Unit.INSTANCE
                java.lang.Object r1 = r1.invokeSuspend(r2)
                return r1
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r3) {
                r2 = this;
                kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r0 = r2.label
                if (r0 != 0) goto L1e
                kotlin.ResultKt.throwOnFailure(r3)
                androidx.camera.core.impl.SessionConfig r3 = r2.$sessionConfig
                if (r3 == 0) goto L1b
                androidx.camera.core.impl.SessionConfig$ErrorListener r3 = r3.getErrorListener()
                if (r3 == 0) goto L1b
                androidx.camera.core.impl.SessionConfig r0 = r2.$sessionConfig
                androidx.camera.core.impl.SessionConfig$SessionError r1 = androidx.camera.core.impl.SessionConfig.SessionError.SESSION_ERROR_SURFACE_NEEDS_RESET
                r3.onError(r0, r1)
            L1b:
                kotlin.Unit r3 = kotlin.Unit.INSTANCE
                return r3
            L1e:
                java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r3.<init>(r0)
                throw r3
        }
    }

    /* JADX INFO: renamed from: $r8$lambda$-icGDqvAHKSdZE3aOVJMyOoUyFk, reason: not valid java name */
    public static /* synthetic */ java.util.List m76$r8$lambda$icGDqvAHKSdZE3aOVJMyOoUyFk(androidx.camera.camera2.adapter.SessionConfigAdapter r0) {
            java.util.List r0 = deferrableSurfaces_delegate$lambda$0(r0)
            return r0
    }

    public static /* synthetic */ androidx.camera.core.impl.SessionConfig.ValidatingBuilder $r8$lambda$MWNVpTDD7KkQSD9XEE8XNPfWPZc(androidx.camera.camera2.adapter.SessionConfigAdapter r0) {
            androidx.camera.core.impl.SessionConfig$ValidatingBuilder r0 = validatingBuilder_delegate$lambda$0(r0)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$g_aOe16a-DUtVM_sJpjR-JZDPhs, reason: not valid java name */
    public static /* synthetic */ java.util.Map m77$r8$lambda$g_aOe16aDUtVM_sJpjRJZDPhs(androidx.camera.camera2.adapter.SessionConfigAdapter r0) {
            java.util.Map r0 = surfaceToStreamUseHintMap_delegate$lambda$0(r0)
            return r0
    }

    public static /* synthetic */ androidx.camera.core.impl.SessionConfig $r8$lambda$h5igSN6lhSEpYqjILIQEMI6OvfE(androidx.camera.camera2.adapter.SessionConfigAdapter r0) {
            androidx.camera.core.impl.SessionConfig r0 = sessionConfig_delegate$lambda$0(r0)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$nnJYHDr2I66xowM4-43xaBstCic, reason: not valid java name */
    public static /* synthetic */ java.util.Map m78$r8$lambda$nnJYHDr2I66xowM443xaBstCic(androidx.camera.camera2.adapter.SessionConfigAdapter r0) {
            java.util.Map r0 = surfaceToStreamUseCaseMap_delegate$lambda$0(r0)
            return r0
    }

    static {
            androidx.camera.camera2.adapter.SessionConfigAdapter$Companion r0 = new androidx.camera.camera2.adapter.SessionConfigAdapter$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.adapter.SessionConfigAdapter.Companion = r0
            return
    }

    public SessionConfigAdapter(java.util.Collection<? extends androidx.camera.core.UseCase> r2, boolean r3) {
            r1 = this;
            java.lang.String r0 = "useCases"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.useCases = r2
            r1.isPrimary = r3
            androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda0 r2 = new androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda0
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.surfaceToStreamUseCaseMap$delegate = r2
            androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda1 r2 = new androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda1
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.surfaceToStreamUseHintMap$delegate = r2
            androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda2 r2 = new androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda2
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.validatingBuilder$delegate = r2
            androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda3 r2 = new androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda3
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.sessionConfig$delegate = r2
            androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda4 r2 = new androidx.camera.camera2.adapter.SessionConfigAdapter$$ExternalSyntheticLambda4
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.deferrableSurfaces$delegate = r2
            return
    }

    public /* synthetic */ SessionConfigAdapter(java.util.Collection r1, boolean r2, int r3, kotlin.jvm.internal.DefaultConstructorMarker r4) {
            r0 = this;
            r3 = r3 & 2
            if (r3 == 0) goto L5
            r2 = 1
        L5:
            r0.<init>(r1, r2)
            return
    }

    private static final java.util.List deferrableSurfaces_delegate$lambda$0(androidx.camera.camera2.adapter.SessionConfigAdapter r4) {
            androidx.camera.core.impl.SessionConfig$ValidatingBuilder r0 = r4.getValidatingBuilder()
            boolean r0 = r0.isValid()
            if (r0 == 0) goto L4a
            androidx.camera.core.impl.SessionConfig r0 = r4.getSessionConfig()
            androidx.camera.core.impl.SessionConfig$OutputConfig r0 = r0.getPostviewOutputConfig()
            if (r0 == 0) goto L41
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.List r1 = (java.util.List) r1
            androidx.camera.core.impl.SessionConfig r2 = r4.getSessionConfig()
            java.util.List r2 = r2.getSurfaces()
            java.lang.String r3 = "getSurfaces(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
            java.util.Collection r2 = (java.util.Collection) r2
            r1.addAll(r2)
            androidx.camera.core.impl.DeferrableSurface r0 = r0.getSurface()
            java.lang.String r2 = "getSurface(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r2)
            r1.add(r0)
            java.util.List r0 = java.util.Collections.unmodifiableList(r1)
            if (r0 != 0) goto L40
            goto L41
        L40:
            return r0
        L41:
            androidx.camera.core.impl.SessionConfig r4 = r4.getSessionConfig()
            java.util.List r4 = r4.getSurfaces()
            return r4
        L4a:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r0 = "Check failed."
            r4.<init>(r0)
            throw r4
    }

    private final androidx.camera.core.impl.SessionConfig getSessionConfig() {
            r1 = this;
            kotlin.Lazy r0 = r1.sessionConfig$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.camera.core.impl.SessionConfig r0 = (androidx.camera.core.impl.SessionConfig) r0
            return r0
    }

    private final long getStreamUseHintForContainerClass(java.lang.Class<?> r3) {
            r2 = this;
            java.lang.Class<android.media.MediaCodec> r0 = android.media.MediaCodec.class
            boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r3 == 0) goto Lf
            androidx.camera.camera2.pipe.OutputStream$StreamUseHint$Companion r3 = androidx.camera.camera2.pipe.OutputStream.StreamUseHint.Companion
            long r0 = r3.m697getVIDEO_RECORD4VYZOf8()
            return r0
        Lf:
            androidx.camera.camera2.pipe.OutputStream$StreamUseHint$Companion r3 = androidx.camera.camera2.pipe.OutputStream.StreamUseHint.Companion
            long r0 = r3.m696getDEFAULT4VYZOf8()
            return r0
    }

    private final androidx.camera.core.impl.SessionConfig.ValidatingBuilder getValidatingBuilder() {
            r1 = this;
            kotlin.Lazy r0 = r1.validatingBuilder$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.camera.core.impl.SessionConfig$ValidatingBuilder r0 = (androidx.camera.core.impl.SessionConfig.ValidatingBuilder) r0
            return r0
    }

    private static final androidx.camera.core.impl.SessionConfig sessionConfig_delegate$lambda$0(androidx.camera.camera2.adapter.SessionConfigAdapter r1) {
            androidx.camera.core.impl.SessionConfig$ValidatingBuilder r0 = r1.getValidatingBuilder()
            boolean r0 = r0.isValid()
            if (r0 == 0) goto L18
            androidx.camera.core.impl.SessionConfig$ValidatingBuilder r1 = r1.getValidatingBuilder()
            androidx.camera.core.impl.SessionConfig r1 = r1.build()
            java.lang.String r0 = "build(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r0)
            return r1
        L18:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = "Check failed."
            r1.<init>(r0)
            throw r1
    }

    private static final java.util.Map surfaceToStreamUseCaseMap_delegate$lambda$0(androidx.camera.camera2.adapter.SessionConfigAdapter r6) {
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.List r1 = (java.util.List) r1
            java.util.Collection<androidx.camera.core.UseCase> r2 = r6.useCases
            java.util.Iterator r2 = r2.iterator()
        L14:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L38
            java.lang.Object r3 = r2.next()
            androidx.camera.core.UseCase r3 = (androidx.camera.core.UseCase) r3
            androidx.camera.camera2.adapter.SessionConfigAdapter$Companion r4 = androidx.camera.camera2.adapter.SessionConfigAdapter.Companion
            boolean r5 = r6.isPrimary
            androidx.camera.core.impl.SessionConfig r4 = r4.getSessionConfig(r3, r5)
            r0.add(r4)
            androidx.camera.core.impl.UseCaseConfig r3 = r3.getCurrentConfig()
            java.lang.String r4 = "getCurrentConfig(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)
            r1.add(r3)
            goto L14
        L38:
            java.util.Collection r0 = (java.util.Collection) r0
            java.util.Collection r1 = (java.util.Collection) r1
            java.util.Map r6 = r6.getSurfaceToStreamUseCaseMapping(r0, r1)
            return r6
    }

    private static final java.util.Map surfaceToStreamUseHintMap_delegate$lambda$0(androidx.camera.camera2.adapter.SessionConfigAdapter r5) {
            java.util.Collection<androidx.camera.core.UseCase> r0 = r5.useCases
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r2 = 10
            int r2 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r0, r2)
            r1.<init>(r2)
            java.util.Collection r1 = (java.util.Collection) r1
            java.util.Iterator r0 = r0.iterator()
        L15:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L2d
            java.lang.Object r2 = r0.next()
            androidx.camera.core.UseCase r2 = (androidx.camera.core.UseCase) r2
            androidx.camera.camera2.adapter.SessionConfigAdapter$Companion r3 = androidx.camera.camera2.adapter.SessionConfigAdapter.Companion
            boolean r4 = r5.isPrimary
            androidx.camera.core.impl.SessionConfig r2 = r3.getSessionConfig(r2, r4)
            r1.add(r2)
            goto L15
        L2d:
            java.util.List r1 = (java.util.List) r1
            java.util.Collection r1 = (java.util.Collection) r1
            java.util.Map r5 = r5.getSurfaceToStreamUseHintMapping(r1)
            return r5
    }

    private static final androidx.camera.core.impl.SessionConfig.ValidatingBuilder validatingBuilder_delegate$lambda$0(androidx.camera.camera2.adapter.SessionConfigAdapter r5) {
            androidx.camera.core.impl.SessionConfig$ValidatingBuilder r0 = new androidx.camera.core.impl.SessionConfig$ValidatingBuilder
            r0.<init>()
            java.util.Collection<androidx.camera.core.UseCase> r1 = r5.useCases
            java.util.Iterator r1 = r1.iterator()
        Lb:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L23
            java.lang.Object r2 = r1.next()
            androidx.camera.core.UseCase r2 = (androidx.camera.core.UseCase) r2
            androidx.camera.camera2.adapter.SessionConfigAdapter$Companion r3 = androidx.camera.camera2.adapter.SessionConfigAdapter.Companion
            boolean r4 = r5.isPrimary
            androidx.camera.core.impl.SessionConfig r2 = r3.getSessionConfig(r2, r4)
            r0.add(r2)
            goto Lb
        L23:
            return r0
    }

    public final java.util.List<androidx.camera.core.impl.DeferrableSurface> getDeferrableSurfaces() {
            r2 = this;
            kotlin.Lazy r0 = r2.deferrableSurfaces$delegate
            java.lang.Object r0 = r0.getValue()
            java.lang.String r1 = "getValue(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.util.List r0 = (java.util.List) r0
            return r0
    }

    public final java.util.Map<androidx.camera.core.impl.DeferrableSurface, java.lang.Long> getSurfaceToStreamUseCaseMap() {
            r1 = this;
            kotlin.Lazy r0 = r1.surfaceToStreamUseCaseMap$delegate
            java.lang.Object r0 = r0.getValue()
            java.util.Map r0 = (java.util.Map) r0
            return r0
    }

    public final java.util.Map<androidx.camera.core.impl.DeferrableSurface, java.lang.Long> getSurfaceToStreamUseCaseMapping(java.util.Collection<androidx.camera.core.impl.SessionConfig> r4, java.util.Collection<? extends androidx.camera.core.impl.UseCaseConfig<?>> r5) {
            r3 = this;
            java.lang.String r0 = "sessionConfigs"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "useCaseConfigs"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            r0 = r4
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            r1 = r0
            java.util.Collection r1 = (java.util.Collection) r1
            boolean r1 = r1.isEmpty()
            if (r1 == 0) goto L17
            goto L46
        L17:
            java.util.Iterator r0 = r0.iterator()
        L1b:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L46
            java.lang.Object r1 = r0.next()
            androidx.camera.core.impl.SessionConfig r1 = (androidx.camera.core.impl.SessionConfig) r1
            int r1 = r1.getTemplateType()
            r2 = 5
            if (r1 != r2) goto L1b
            androidx.camera.camera2.impl.Camera2Logger r4 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r4 = "CXCP"
            boolean r4 = androidx.camera.core.Logger.isErrorEnabled(r4)
            if (r4 == 0) goto L41
            java.lang.String r4 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r5 = "ZSL in populateSurfaceToStreamUseCaseMapping()"
            android.util.Log.e(r4, r5)
        L41:
            java.util.Map r4 = kotlin.collections.MapsKt.emptyMap()
            return r4
        L46:
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            androidx.camera.camera2.internal.StreamUseCaseUtil r1 = androidx.camera.camera2.internal.StreamUseCaseUtil.INSTANCE
            r1.populateSurfaceToStreamUseCaseMapping(r4, r5, r0)
            return r0
    }

    public final java.util.Map<androidx.camera.core.impl.DeferrableSurface, java.lang.Long> getSurfaceToStreamUseHintMap() {
            r1 = this;
            kotlin.Lazy r0 = r1.surfaceToStreamUseHintMap$delegate
            java.lang.Object r0 = r0.getValue()
            java.util.Map r0 = (java.util.Map) r0
            return r0
    }

    public final java.util.Map<androidx.camera.core.impl.DeferrableSurface, java.lang.Long> getSurfaceToStreamUseHintMapping(java.util.Collection<androidx.camera.core.impl.SessionConfig> r7) {
            r6 = this;
            java.lang.String r0 = "sessionConfigs"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            java.util.Iterator r7 = r7.iterator()
        L10:
            boolean r1 = r7.hasNext()
            if (r1 == 0) goto L69
            java.lang.Object r1 = r7.next()
            androidx.camera.core.impl.SessionConfig r1 = (androidx.camera.core.impl.SessionConfig) r1
            java.util.List r2 = r1.getSurfaces()
            java.util.Iterator r2 = r2.iterator()
        L24:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L10
            java.lang.Object r3 = r2.next()
            androidx.camera.core.impl.DeferrableSurface r3 = (androidx.camera.core.impl.DeferrableSurface) r3
            androidx.camera.core.impl.Config r4 = r1.getImplementationOptions()
            androidx.camera.core.impl.Config$Option<java.lang.Long> r5 = androidx.camera.camera2.impl.Camera2ImplConfig.STREAM_USE_HINT_OPTION
            boolean r4 = r4.containsOption(r5)
            if (r4 == 0) goto L59
            androidx.camera.core.impl.Config r4 = r1.getImplementationOptions()
            androidx.camera.core.impl.Config$Option<java.lang.Long> r5 = androidx.camera.camera2.impl.Camera2ImplConfig.STREAM_USE_HINT_OPTION
            java.lang.Object r4 = r4.retrieveOption(r5)
            if (r4 == 0) goto L59
            androidx.camera.core.impl.Config r4 = r1.getImplementationOptions()
            androidx.camera.core.impl.Config$Option<java.lang.Long> r5 = androidx.camera.camera2.impl.Camera2ImplConfig.STREAM_USE_HINT_OPTION
            java.lang.Object r4 = r4.retrieveOption(r5)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r4)
            r0.put(r3, r4)
            goto L24
        L59:
            java.lang.Class r4 = r3.getContainerClass()
            long r4 = r6.getStreamUseHintForContainerClass(r4)
            java.lang.Long r4 = java.lang.Long.valueOf(r4)
            r0.put(r3, r4)
            goto L24
        L69:
            return r0
    }

    public final androidx.camera.core.impl.SessionConfig getValidSessionConfigOrNull() {
            r1 = this;
            boolean r0 = r1.isSessionConfigValid()
            if (r0 == 0) goto Lb
            androidx.camera.core.impl.SessionConfig r0 = r1.getSessionConfig()
            return r0
        Lb:
            r0 = 0
            return r0
    }

    public final boolean isSessionConfigValid() {
            r1 = this;
            androidx.camera.core.impl.SessionConfig$ValidatingBuilder r0 = r1.getValidatingBuilder()
            boolean r0 = r0.isValid()
            return r0
    }

    public final void reportSurfaceInvalid(androidx.camera.core.impl.DeferrableSurface r10) {
            r9 = this;
            java.lang.String r0 = "deferrableSurface"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r0)
            if (r0 == 0) goto L29
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Unavailable "
            r1.<init>(r2)
            r1.append(r10)
            java.lang.String r2 = ", notify SessionConfig invalid"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r0, r1)
        L29:
            java.util.Collection<androidx.camera.core.UseCase> r0 = r9.useCases
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.Iterator r0 = r0.iterator()
        L31:
            boolean r1 = r0.hasNext()
            r2 = 0
            if (r1 == 0) goto L52
            java.lang.Object r1 = r0.next()
            r3 = r1
            androidx.camera.core.UseCase r3 = (androidx.camera.core.UseCase) r3
            androidx.camera.camera2.adapter.SessionConfigAdapter$Companion r4 = androidx.camera.camera2.adapter.SessionConfigAdapter.Companion
            boolean r5 = r9.isPrimary
            androidx.camera.core.impl.SessionConfig r3 = r4.getSessionConfig(r3, r5)
            java.util.List r3 = r3.getSurfaces()
            boolean r3 = r3.contains(r10)
            if (r3 == 0) goto L31
            goto L53
        L52:
            r1 = r2
        L53:
            androidx.camera.core.UseCase r1 = (androidx.camera.core.UseCase) r1
            if (r1 == 0) goto L5c
            androidx.camera.core.impl.SessionConfig r10 = r1.getSessionConfig()
            goto L5d
        L5c:
            r10 = r2
        L5d:
            kotlinx.coroutines.MainCoroutineDispatcher r0 = kotlinx.coroutines.Dispatchers.getMain()
            kotlinx.coroutines.MainCoroutineDispatcher r0 = r0.getImmediate()
            kotlin.coroutines.CoroutineContext r0 = (kotlin.coroutines.CoroutineContext) r0
            kotlinx.coroutines.CoroutineScope r3 = kotlinx.coroutines.CoroutineScopeKt.CoroutineScope(r0)
            androidx.camera.camera2.adapter.SessionConfigAdapter$reportSurfaceInvalid$2 r0 = new androidx.camera.camera2.adapter.SessionConfigAdapter$reportSurfaceInvalid$2
            r0.<init>(r10, r2)
            r6 = r0
            kotlin.jvm.functions.Function2 r6 = (kotlin.jvm.functions.Function2) r6
            r7 = 3
            r8 = 0
            r4 = 0
            r5 = 0
            kotlinx.coroutines.BuildersKt.launch$default(r3, r4, r5, r6, r7, r8)
            return
    }
}
