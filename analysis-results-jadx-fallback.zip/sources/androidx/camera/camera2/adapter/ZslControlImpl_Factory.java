package androidx.camera.camera2.adapter;

/* JADX INFO: loaded from: classes.dex */
public final class ZslControlImpl_Factory implements dagger.internal.Factory<androidx.camera.camera2.adapter.ZslControlImpl> {
    private final dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> cameraPropertiesProvider;

    private ZslControlImpl_Factory(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1) {
            r0 = this;
            r0.<init>()
            r0.cameraPropertiesProvider = r1
            return
    }

    public static androidx.camera.camera2.adapter.ZslControlImpl_Factory create(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1) {
            androidx.camera.camera2.adapter.ZslControlImpl_Factory r0 = new androidx.camera.camera2.adapter.ZslControlImpl_Factory
            r0.<init>(r1)
            return r0
    }

    public static androidx.camera.camera2.adapter.ZslControlImpl newInstance(androidx.camera.camera2.impl.CameraProperties r1) {
            androidx.camera.camera2.adapter.ZslControlImpl r0 = new androidx.camera.camera2.adapter.ZslControlImpl
            r0.<init>(r1)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.adapter.ZslControlImpl get() {
            r1 = this;
            dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r0 = r1.cameraPropertiesProvider
            java.lang.Object r0 = r0.get()
            androidx.camera.camera2.impl.CameraProperties r0 = (androidx.camera.camera2.impl.CameraProperties) r0
            androidx.camera.camera2.adapter.ZslControlImpl r0 = newInstance(r0)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.adapter.ZslControlImpl r0 = r1.get()
            return r0
    }
}
