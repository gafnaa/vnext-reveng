package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CoroutineAdapters.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000T\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0003\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\u001a\u001c\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u001a(\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00060\u0001\"\u0004\b\u0000\u0010\u0006*\b\u0012\u0004\u0012\u0002H\u00060\u00072\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u001a\u001c\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001\"\u0004\b\u0000\u0010\u0006*\b\u0012\u0004\u0012\u0002H\u00060\u0007\u001aA\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\u00060\u0001\"\u0004\b\u0000\u0010\u0006*\u00020\n2\u001e\b\u0004\u0010\u000b\u001a\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00060\r\u0012\u0006\u0012\u0004\u0018\u00010\u00050\fH\u0086\bø\u0001\u0000¢\u0006\u0002\u0010\u000e\u001a$\u0010\u000f\u001a\u00020\u0010\"\u0004\b\u0000\u0010\u0006*\b\u0012\u0004\u0012\u0002H\u00060\u00072\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u00060\u0012\u001a>\u0010\u000f\u001a\u00020\u0010\"\u0004\b\u0000\u0010\u0006\"\u0004\b\u0001\u0010\u0013*\b\u0012\u0004\u0012\u0002H\u00060\u00072\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u00130\u00122\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u0002H\u0006\u0012\u0004\u0012\u0002H\u00130\f\u001a.\u0010\u0015\u001a\u00020\u0010\"\u0004\b\u0000\u0010\u0006*\b\u0012\u0004\u0012\u0002H\u00060\u00072\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u00060\u00122\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017\u001aH\u0010\u0015\u001a\u00020\u0010\"\u0004\b\u0000\u0010\u0006\"\u0004\b\u0001\u0010\u0013*\b\u0012\u0004\u0012\u0002H\u00060\u00072\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u00130\u00122\b\u0010\u0016\u001a\u0004\u0018\u00010\u00172\u0012\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u0002H\u0006\u0012\u0004\u0012\u0002H\u00130\f\u001a\u001e\u0010\u0018\u001a\u00020\u0010\"\u0004\b\u0000\u0010\u0006*\b\u0012\u0004\u0012\u0002H\u00060\u00122\u0006\u0010\u0019\u001a\u00020\u0017\u001a&\u0010\u001a\u001a\u00020\u001b\"\u0004\b\u0000\u0010\u0006*\b\u0012\u0004\u0012\u0002H\u00060\u00072\u0006\u0010\u001c\u001a\u00020\u001dH\u0086@¢\u0006\u0002\u0010\u001e\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\u001f"}, d2 = {"asListenableFuture", "Lcom/google/common/util/concurrent/ListenableFuture;", "Ljava/lang/Void;", "Lkotlinx/coroutines/Job;", "tag", "", "T", "Lkotlinx/coroutines/Deferred;", "asVoidListenableFuture", "future", "Lkotlinx/coroutines/CoroutineScope;", "block", "Lkotlin/Function1;", "Lkotlin/coroutines/Continuation;", "(Lkotlinx/coroutines/CoroutineScope;Lkotlin/jvm/functions/Function1;)Lcom/google/common/util/concurrent/ListenableFuture;", "propagateTo", "", "destination", "Lkotlinx/coroutines/CompletableDeferred;", "R", "transform", "propagateCompletion", "completionCause", "", "completeFailing", "cause", "awaitUntil", "", "timeoutMillis", "", "(Lkotlinx/coroutines/Deferred;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "camera-camera2"}, k = 2, mv = {2, 1, 0}, xi = 48)
public final class CoroutineAdaptersKt {

    /* JADX INFO: renamed from: androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$1, reason: invalid class name */
    /* JADX INFO: compiled from: CoroutineAdapters.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.camera.camera2.adapter.CoroutineAdaptersKt", f = "CoroutineAdapters.kt", i = {}, l = {199}, m = "awaitUntil", n = {}, s = {}, v = 1)
    static final class AnonymousClass1<T> extends kotlin.coroutines.jvm.internal.ContinuationImpl {
        int label;
        /* synthetic */ java.lang.Object result;

        AnonymousClass1(kotlin.coroutines.Continuation<? super androidx.camera.camera2.adapter.CoroutineAdaptersKt.AnonymousClass1> r1) {
                r0 = this;
                r0.<init>(r1)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r4) {
                r3 = this;
                r3.result = r4
                int r4 = r3.label
                r0 = -2147483648(0xffffffff80000000, float:-0.0)
                r4 = r4 | r0
                r3.label = r4
                r0 = 0
                r4 = r3
                kotlin.coroutines.Continuation r4 = (kotlin.coroutines.Continuation) r4
                r2 = 0
                java.lang.Object r4 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.awaitUntil(r2, r0, r4)
                return r4
        }
    }

    /* JADX INFO: Add missing generic type declarations: [T] */
    /* JADX INFO: renamed from: androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$2, reason: invalid class name */
    /* JADX INFO: compiled from: CoroutineAdapters.kt */
    @kotlin.Metadata(d1 = {"\u0000\b\n\u0002\b\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "T", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
    @kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$2", f = "CoroutineAdapters.kt", i = {}, l = {199}, m = "invokeSuspend", n = {}, s = {}, v = 1)
    static final class AnonymousClass2<T> extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super T>, java.lang.Object> {
        final /* synthetic */ kotlinx.coroutines.Deferred<T> $this_awaitUntil;
        int label;

        AnonymousClass2(kotlinx.coroutines.Deferred<? extends T> r1, kotlin.coroutines.Continuation<? super androidx.camera.camera2.adapter.CoroutineAdaptersKt.AnonymousClass2> r2) {
                r0 = this;
                r0.$this_awaitUntil = r1
                r1 = 2
                r0.<init>(r1, r2)
                return
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r2, kotlin.coroutines.Continuation<?> r3) {
                r1 = this;
                androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$2 r2 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$2
                kotlinx.coroutines.Deferred<T> r0 = r1.$this_awaitUntil
                r2.<init>(r0, r3)
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                return r2
        }

        @Override // kotlin.jvm.functions.Function2
        public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.CoroutineScope r1, java.lang.Object r2) {
                r0 = this;
                kotlinx.coroutines.CoroutineScope r1 = (kotlinx.coroutines.CoroutineScope) r1
                kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
                java.lang.Object r1 = r0.invoke(r1, r2)
                return r1
        }

        public final java.lang.Object invoke(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super T> r2) {
                r0 = this;
                kotlin.coroutines.Continuation r1 = r0.create(r1, r2)
                androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$2 r1 = (androidx.camera.camera2.adapter.CoroutineAdaptersKt.AnonymousClass2) r1
                kotlin.Unit r2 = kotlin.Unit.INSTANCE
                java.lang.Object r1 = r1.invokeSuspend(r2)
                return r1
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r4) {
                r3 = this;
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r3.label
                r2 = 1
                if (r1 == 0) goto L17
                if (r1 != r2) goto Lf
                kotlin.ResultKt.throwOnFailure(r4)
                return r4
            Lf:
                java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
                java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
                r4.<init>(r0)
                throw r4
            L17:
                kotlin.ResultKt.throwOnFailure(r4)
                kotlinx.coroutines.Deferred<T> r4 = r3.$this_awaitUntil
                r1 = r3
                kotlin.coroutines.Continuation r1 = (kotlin.coroutines.Continuation) r1
                r3.label = r2
                java.lang.Object r4 = r4.await(r1)
                if (r4 != r0) goto L28
                return r0
            L28:
                return r4
        }
    }

    public static /* synthetic */ java.lang.Object $r8$lambda$291ob6vuDNDeI74nkG615Jp79gg(kotlinx.coroutines.Job r0, java.lang.Object r1, androidx.concurrent.futures.CallbackToFutureAdapter.Completer r2) {
            java.lang.Object r0 = asListenableFuture$lambda$0(r0, r1, r2)
            return r0
    }

    public static /* synthetic */ java.lang.Object $r8$lambda$CWMmOpF3SrnUZxqkZ9tNskVvWfc(kotlinx.coroutines.Deferred r0, java.lang.Object r1, androidx.concurrent.futures.CallbackToFutureAdapter.Completer r2) {
            java.lang.Object r0 = asListenableFuture$lambda$1(r0, r1, r2)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$MYmxNEn3jLkJk17hLnjOKOP-vkU, reason: not valid java name */
    public static /* synthetic */ java.lang.Void m72$r8$lambda$MYmxNEn3jLkJk17hLnjOKOPvkU(java.lang.Object r0) {
            java.lang.Void r0 = asVoidListenableFuture$lambda$0(r0)
            return r0
    }

    public static /* synthetic */ kotlin.Unit $r8$lambda$NqijppL2DSYQX2kgqByrGzDCers(kotlinx.coroutines.Deferred r0, kotlinx.coroutines.CompletableDeferred r1, java.lang.Throwable r2) {
            kotlin.Unit r0 = propagateTo$lambda$0(r0, r1, r2)
            return r0
    }

    public static /* synthetic */ kotlin.Unit $r8$lambda$V0luSTHRidOVmS9hfgdjliJRNUE(kotlinx.coroutines.Deferred r0, kotlinx.coroutines.CompletableDeferred r1, kotlin.jvm.functions.Function1 r2, java.lang.Throwable r3) {
            kotlin.Unit r0 = propagateTo$lambda$1(r0, r1, r2, r3)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$jVJCEkJI0ZZBOGn-an7ETARyhJY, reason: not valid java name */
    public static /* synthetic */ kotlin.Unit m73$r8$lambda$jVJCEkJI0ZZBOGnan7ETARyhJY(androidx.concurrent.futures.CallbackToFutureAdapter.Completer r0, kotlinx.coroutines.Deferred r1, java.lang.Throwable r2) {
            kotlin.Unit r0 = asListenableFuture$lambda$1$0(r0, r1, r2)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$yh7VCNLWmlYjZayiRXB7r-NOQlQ, reason: not valid java name */
    public static /* synthetic */ kotlin.Unit m74$r8$lambda$yh7VCNLWmlYjZayiRXB7rNOQlQ(androidx.concurrent.futures.CallbackToFutureAdapter.Completer r0, java.lang.Throwable r1) {
            kotlin.Unit r0 = asListenableFuture$lambda$0$0(r0, r1)
            return r0
    }

    public static final <T> com.google.common.util.concurrent.ListenableFuture<T> asListenableFuture(kotlinx.coroutines.Deferred<? extends T> r1, java.lang.Object r2) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda5 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda5
            r0.<init>(r1, r2)
            com.google.common.util.concurrent.ListenableFuture r1 = androidx.concurrent.futures.CallbackToFutureAdapter.getFuture(r0)
            java.lang.String r2 = "getFuture(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            return r1
    }

    public static final com.google.common.util.concurrent.ListenableFuture<java.lang.Void> asListenableFuture(kotlinx.coroutines.Job r1, java.lang.Object r2) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda0 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda0
            r0.<init>(r1, r2)
            com.google.common.util.concurrent.ListenableFuture r1 = androidx.concurrent.futures.CallbackToFutureAdapter.getFuture(r0)
            java.lang.String r2 = "getFuture(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            return r1
    }

    public static /* synthetic */ com.google.common.util.concurrent.ListenableFuture asListenableFuture$default(kotlinx.coroutines.Deferred r0, java.lang.Object r1, int r2, java.lang.Object r3) {
            r2 = r2 & 1
            if (r2 == 0) goto L6
            java.lang.String r1 = "Deferred.asListenableFuture"
        L6:
            com.google.common.util.concurrent.ListenableFuture r0 = asListenableFuture(r0, r1)
            return r0
    }

    public static /* synthetic */ com.google.common.util.concurrent.ListenableFuture asListenableFuture$default(kotlinx.coroutines.Job r0, java.lang.Object r1, int r2, java.lang.Object r3) {
            r2 = r2 & 1
            if (r2 == 0) goto L6
            java.lang.String r1 = "Job.asListenableFuture"
        L6:
            com.google.common.util.concurrent.ListenableFuture r0 = asListenableFuture(r0, r1)
            return r0
    }

    private static final java.lang.Object asListenableFuture$lambda$0(kotlinx.coroutines.Job r1, java.lang.Object r2, androidx.concurrent.futures.CallbackToFutureAdapter.Completer r3) {
            java.lang.String r0 = "completer"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda1 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda1
            r0.<init>(r3)
            r1.invokeOnCompletion(r0)
            return r2
    }

    private static final kotlin.Unit asListenableFuture$lambda$0$0(androidx.concurrent.futures.CallbackToFutureAdapter.Completer r1, java.lang.Throwable r2) {
            if (r2 == 0) goto Le
            boolean r0 = r2 instanceof java.util.concurrent.CancellationException
            if (r0 == 0) goto La
            r1.setCancelled()
            goto L12
        La:
            r1.setException(r2)
            goto L12
        Le:
            r2 = 0
            r1.set(r2)
        L12:
            kotlin.Unit r1 = kotlin.Unit.INSTANCE
            return r1
    }

    private static final java.lang.Object asListenableFuture$lambda$1(kotlinx.coroutines.Deferred r1, java.lang.Object r2, androidx.concurrent.futures.CallbackToFutureAdapter.Completer r3) {
            java.lang.String r0 = "completer"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda4 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda4
            r0.<init>(r3, r1)
            r1.invokeOnCompletion(r0)
            return r2
    }

    private static final kotlin.Unit asListenableFuture$lambda$1$0(androidx.concurrent.futures.CallbackToFutureAdapter.Completer r0, kotlinx.coroutines.Deferred r1, java.lang.Throwable r2) {
            if (r2 == 0) goto Le
            boolean r1 = r2 instanceof java.util.concurrent.CancellationException
            if (r1 == 0) goto La
            r0.setCancelled()
            goto L15
        La:
            r0.setException(r2)
            goto L15
        Le:
            java.lang.Object r1 = r1.getCompleted()
            r0.set(r1)
        L15:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            return r0
    }

    public static final <T> com.google.common.util.concurrent.ListenableFuture<java.lang.Void> asVoidListenableFuture(kotlinx.coroutines.Deferred<? extends T> r2) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r0 = 0
            r1 = 1
            com.google.common.util.concurrent.ListenableFuture r2 = asListenableFuture$default(r2, r0, r1, r0)
            androidx.camera.core.impl.utils.futures.FutureChain r2 = androidx.camera.core.impl.utils.futures.FutureChain.from(r2)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda2 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda2
            r0.<init>()
            java.util.concurrent.Executor r1 = androidx.camera.core.impl.utils.executor.CameraXExecutors.directExecutor()
            androidx.camera.core.impl.utils.futures.FutureChain r2 = r2.transform(r0, r1)
            java.lang.String r0 = "transform(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r0)
            com.google.common.util.concurrent.ListenableFuture r2 = (com.google.common.util.concurrent.ListenableFuture) r2
            return r2
    }

    private static final java.lang.Void asVoidListenableFuture$lambda$0(java.lang.Object r0) {
            r0 = 0
            return r0
    }

    public static final <T> java.lang.Object awaitUntil(kotlinx.coroutines.Deferred<? extends T> r4, long r5, kotlin.coroutines.Continuation<? super java.lang.Boolean> r7) {
            boolean r0 = r7 instanceof androidx.camera.camera2.adapter.CoroutineAdaptersKt.AnonymousClass1
            if (r0 == 0) goto L14
            r0 = r7
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$1 r0 = (androidx.camera.camera2.adapter.CoroutineAdaptersKt.AnonymousClass1) r0
            int r1 = r0.label
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r1 = r1 & r2
            if (r1 == 0) goto L14
            int r7 = r0.label
            int r7 = r7 - r2
            r0.label = r7
            goto L19
        L14:
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$1 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$1
            r0.<init>(r7)
        L19:
            java.lang.Object r7 = r0.result
            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r2 = r0.label
            r3 = 1
            if (r2 == 0) goto L32
            if (r2 != r3) goto L2a
            kotlin.ResultKt.throwOnFailure(r7)
            goto L46
        L2a:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L32:
            kotlin.ResultKt.throwOnFailure(r7)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$2 r7 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$awaitUntil$2
            r2 = 0
            r7.<init>(r4, r2)
            kotlin.jvm.functions.Function2 r7 = (kotlin.jvm.functions.Function2) r7
            r0.label = r3
            java.lang.Object r7 = kotlinx.coroutines.TimeoutKt.withTimeoutOrNull(r5, r7, r0)
            if (r7 != r1) goto L46
            return r1
        L46:
            if (r7 == 0) goto L49
            goto L4a
        L49:
            r3 = 0
        L4a:
            java.lang.Boolean r4 = kotlin.coroutines.jvm.internal.Boxing.boxBoolean(r3)
            return r4
    }

    public static final <T> void completeFailing(kotlinx.coroutines.CompletableDeferred<T> r1, java.lang.Throwable r2) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            java.lang.String r0 = "cause"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            boolean r0 = r2 instanceof java.util.concurrent.CancellationException
            if (r0 == 0) goto L14
            java.util.concurrent.CancellationException r2 = (java.util.concurrent.CancellationException) r2
            r1.cancel(r2)
            return
        L14:
            r1.completeExceptionally(r2)
            return
    }

    public static final <T> com.google.common.util.concurrent.ListenableFuture<T> future(kotlinx.coroutines.CoroutineScope r1, kotlin.jvm.functions.Function1<? super kotlin.coroutines.Continuation<? super T>, ? extends java.lang.Object> r2) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            java.lang.String r0 = "block"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$future$resolver$1 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$future$resolver$1
            r0.<init>(r1, r2)
            androidx.concurrent.futures.CallbackToFutureAdapter$Resolver r0 = (androidx.concurrent.futures.CallbackToFutureAdapter.Resolver) r0
            com.google.common.util.concurrent.ListenableFuture r1 = androidx.concurrent.futures.CallbackToFutureAdapter.getFuture(r0)
            java.lang.String r2 = "getFuture(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            return r1
    }

    public static final <T> void propagateCompletion(kotlinx.coroutines.Deferred<? extends T> r1, kotlinx.coroutines.CompletableDeferred<T> r2, java.lang.Throwable r3) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            java.lang.String r0 = "destination"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            if (r3 == 0) goto L10
            completeFailing(r2, r3)
            return
        L10:
            java.lang.Object r1 = r1.getCompleted()
            r2.complete(r1)
            return
    }

    public static final <T, R> void propagateCompletion(kotlinx.coroutines.Deferred<? extends T> r1, kotlinx.coroutines.CompletableDeferred<R> r2, java.lang.Throwable r3, kotlin.jvm.functions.Function1<? super T, ? extends R> r4) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            java.lang.String r0 = "destination"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "transform"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            if (r3 == 0) goto L15
            completeFailing(r2, r3)
            return
        L15:
            java.lang.Object r1 = r1.getCompleted()
            java.lang.Object r1 = r4.invoke(r1)
            r2.complete(r1)
            return
    }

    public static final <T> void propagateTo(kotlinx.coroutines.Deferred<? extends T> r1, kotlinx.coroutines.CompletableDeferred<T> r2) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            java.lang.String r0 = "destination"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda3 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda3
            r0.<init>(r1, r2)
            r1.invokeOnCompletion(r0)
            return
    }

    public static final <T, R> void propagateTo(kotlinx.coroutines.Deferred<? extends T> r1, kotlinx.coroutines.CompletableDeferred<R> r2, kotlin.jvm.functions.Function1<? super T, ? extends R> r3) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            java.lang.String r0 = "destination"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "transform"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda6 r0 = new androidx.camera.camera2.adapter.CoroutineAdaptersKt$$ExternalSyntheticLambda6
            r0.<init>(r1, r2, r3)
            r1.invokeOnCompletion(r0)
            return
    }

    private static final kotlin.Unit propagateTo$lambda$0(kotlinx.coroutines.Deferred r0, kotlinx.coroutines.CompletableDeferred r1, java.lang.Throwable r2) {
            propagateCompletion(r0, r1, r2)
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            return r0
    }

    private static final kotlin.Unit propagateTo$lambda$1(kotlinx.coroutines.Deferred r0, kotlinx.coroutines.CompletableDeferred r1, kotlin.jvm.functions.Function1 r2, java.lang.Throwable r3) {
            propagateCompletion(r0, r1, r3, r2)
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            return r0
    }
}
