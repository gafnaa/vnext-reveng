package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraControlAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000Ä\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001Bq\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0006\u0010\u000e\u001a\u00020\u000f\u0012\u0006\u0010\u0010\u001a\u00020\u0011\u0012\u0006\u0010\u0012\u001a\u00020\u0013\u0012\u0006\u0010\u0014\u001a\u00020\u0015\u0012\u0006\u0010\u0016\u001a\u00020\u0017\u0012\u0006\u0010\u0018\u001a\u00020\u0019\u0012\u0006\u0010\u001a\u001a\u00020\u001b¢\u0006\u0004\b\u001c\u0010\u001dJ\u0010\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#H\u0016J\b\u0010$\u001a\u00020!H\u0016J\b\u0010%\u001a\u00020#H\u0016J\u0016\u0010&\u001a\b\u0012\u0004\u0012\u00020(0'2\u0006\u0010)\u001a\u00020*H\u0016J\u0016\u0010+\u001a\b\u0012\u0004\u0012\u00020(0'2\u0006\u0010,\u001a\u00020-H\u0016J\u0016\u0010.\u001a\b\u0012\u0004\u0012\u00020(0'2\u0006\u0010/\u001a\u00020*H\u0016J\u0016\u00100\u001a\b\u0012\u0004\u0012\u0002010'2\u0006\u00102\u001a\u000203H\u0016J\u000e\u00104\u001a\b\u0012\u0004\u0012\u00020(0'H\u0016J\u0016\u00105\u001a\b\u0012\u0004\u0012\u00020(0'2\u0006\u00106\u001a\u000207H\u0016J\u0016\u00108\u001a\b\u0012\u0004\u0012\u00020(0'2\u0006\u00109\u001a\u000207H\u0016J\b\u0010:\u001a\u00020-H\u0016J\u0010\u0010;\u001a\u00020!2\u0006\u0010<\u001a\u00020-H\u0016J\u0012\u0010=\u001a\u00020!2\b\u0010>\u001a\u0004\u0018\u00010?H\u0016J\u0016\u0010@\u001a\b\u0012\u0004\u0012\u00020-0'2\u0006\u0010A\u001a\u00020-H\u0016J\u0010\u0010B\u001a\u00020!2\u0006\u0010C\u001a\u00020*H\u0016J\b\u0010D\u001a\u00020*H\u0016J\u0010\u0010E\u001a\u00020!2\u0006\u0010F\u001a\u00020GH\u0016J\b\u0010H\u001a\u00020!H\u0016J4\u0010I\u001a\u0010\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010(0J0'2\f\u0010K\u001a\b\u0012\u0004\u0012\u00020L0J2\u0006\u0010M\u001a\u00020-2\u0006\u0010N\u001a\u00020-H\u0016J\u001e\u0010O\u001a\b\u0012\u0004\u0012\u00020P0'2\u0006\u0010M\u001a\u00020-2\u0006\u0010N\u001a\u00020-H\u0016J\b\u0010Q\u001a\u00020RH\u0016J\b\u0010S\u001a\u00020!H\u0016J\b\u0010T\u001a\u00020!H\u0016J\b\u0010U\u001a\u00020*H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0014\u001a\u00020\u0015¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006V"}, d2 = {"Landroidx/camera/camera2/adapter/CameraControlAdapter;", "Landroidx/camera/core/impl/CameraControlInternal;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "evCompControl", "Landroidx/camera/camera2/impl/EvCompControl;", "flashControl", "Landroidx/camera/camera2/impl/FlashControl;", "focusMeteringControl", "Landroidx/camera/camera2/impl/FocusMeteringControl;", "stillCaptureRequestControl", "Landroidx/camera/camera2/impl/StillCaptureRequestControl;", "torchControl", "Landroidx/camera/camera2/impl/TorchControl;", "lowLightBoostControl", "Landroidx/camera/camera2/impl/LowLightBoostControl;", "zoomControl", "Landroidx/camera/camera2/impl/ZoomControl;", "zslControl", "Landroidx/camera/camera2/adapter/ZslControl;", "camera2cameraControl", "Landroidx/camera/camera2/interop/Camera2CameraControl;", "useCaseManager", "Landroidx/camera/camera2/impl/UseCaseManager;", "threads", "Landroidx/camera/camera2/impl/UseCaseThreads;", "videoUsageControl", "Landroidx/camera/camera2/impl/VideoUsageControl;", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;Landroidx/camera/camera2/impl/EvCompControl;Landroidx/camera/camera2/impl/FlashControl;Landroidx/camera/camera2/impl/FocusMeteringControl;Landroidx/camera/camera2/impl/StillCaptureRequestControl;Landroidx/camera/camera2/impl/TorchControl;Landroidx/camera/camera2/impl/LowLightBoostControl;Landroidx/camera/camera2/impl/ZoomControl;Landroidx/camera/camera2/adapter/ZslControl;Landroidx/camera/camera2/interop/Camera2CameraControl;Landroidx/camera/camera2/impl/UseCaseManager;Landroidx/camera/camera2/impl/UseCaseThreads;Landroidx/camera/camera2/impl/VideoUsageControl;)V", "getCamera2cameraControl", "()Landroidx/camera/camera2/interop/Camera2CameraControl;", "addInteropConfig", "", "config", "Landroidx/camera/core/impl/Config;", "clearInteropConfig", "getInteropConfig", "enableTorch", "Lcom/google/common/util/concurrent/ListenableFuture;", "Ljava/lang/Void;", "torch", "", "setTorchStrengthLevel", "torchStrengthLevel", "", "enableLowLightBoostAsync", "lowLightBoost", "startFocusAndMetering", "Landroidx/camera/core/FocusMeteringResult;", "action", "Landroidx/camera/core/FocusMeteringAction;", "cancelFocusAndMetering", "setZoomRatio", "ratio", "", "setLinearZoom", "linearZoom", "getFlashMode", "setFlashMode", "flashMode", "setScreenFlash", "screenFlash", "Landroidx/camera/core/ImageCapture$ScreenFlash;", "setExposureCompensationIndex", "exposure", "setZslDisabledByUserCaseConfig", "disabled", "isZslDisabledByByUserCaseConfig", "addZslConfig", "sessionConfigBuilder", "Landroidx/camera/core/impl/SessionConfig$Builder;", "clearZslConfig", "submitStillCaptureRequests", "", "captureConfigs", "Landroidx/camera/core/impl/CaptureConfig;", "captureMode", "flashType", "getCameraCapturePipelineAsync", "Landroidx/camera/core/imagecapture/CameraCapturePipeline;", "getSessionConfig", "Landroidx/camera/core/impl/SessionConfig;", "incrementVideoUsage", "decrementVideoUsage", "isInVideoUsage", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraControlAdapter implements androidx.camera.core.impl.CameraControlInternal {
    private final androidx.camera.camera2.interop.Camera2CameraControl camera2cameraControl;
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;
    private final androidx.camera.camera2.impl.EvCompControl evCompControl;
    private final androidx.camera.camera2.impl.FlashControl flashControl;
    private final androidx.camera.camera2.impl.FocusMeteringControl focusMeteringControl;
    private final androidx.camera.camera2.impl.LowLightBoostControl lowLightBoostControl;
    private final androidx.camera.camera2.impl.StillCaptureRequestControl stillCaptureRequestControl;
    private final androidx.camera.camera2.impl.UseCaseThreads threads;
    private final androidx.camera.camera2.impl.TorchControl torchControl;
    private final androidx.camera.camera2.impl.UseCaseManager useCaseManager;
    private final androidx.camera.camera2.impl.VideoUsageControl videoUsageControl;
    private final androidx.camera.camera2.impl.ZoomControl zoomControl;
    private final androidx.camera.camera2.adapter.ZslControl zslControl;

    public static /* synthetic */ java.lang.Void $r8$lambda$_U_T4yQVYsP1g9IqObAFhPRG_pc(androidx.camera.camera2.pipe.Result3A r0) {
            java.lang.Void r0 = cancelFocusAndMetering$lambda$0$0(r0)
            return r0
    }

    public static /* synthetic */ com.google.common.util.concurrent.ListenableFuture $r8$lambda$ldvtwY8UFxNy7qHhD5fhl92xopw(kotlin.jvm.functions.Function1 r0, java.lang.Object r1) {
            com.google.common.util.concurrent.ListenableFuture r0 = enableLowLightBoostAsync$lambda$3(r0, r1)
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$yOMcQG1sLxsguJ7CC05At-631ME, reason: not valid java name */
    public static /* synthetic */ com.google.common.util.concurrent.ListenableFuture m58$r8$lambda$yOMcQG1sLxsguJ7CC05At631ME(androidx.camera.camera2.adapter.CameraControlAdapter r0, boolean r1, java.lang.Void r2) {
            com.google.common.util.concurrent.ListenableFuture r0 = enableLowLightBoostAsync$lambda$2(r0, r1, r2)
            return r0
    }

    @javax.inject.Inject
    public CameraControlAdapter(androidx.camera.camera2.impl.CameraProperties r2, androidx.camera.camera2.impl.EvCompControl r3, androidx.camera.camera2.impl.FlashControl r4, androidx.camera.camera2.impl.FocusMeteringControl r5, androidx.camera.camera2.impl.StillCaptureRequestControl r6, androidx.camera.camera2.impl.TorchControl r7, androidx.camera.camera2.impl.LowLightBoostControl r8, androidx.camera.camera2.impl.ZoomControl r9, androidx.camera.camera2.adapter.ZslControl r10, androidx.camera.camera2.interop.Camera2CameraControl r11, androidx.camera.camera2.impl.UseCaseManager r12, androidx.camera.camera2.impl.UseCaseThreads r13, androidx.camera.camera2.impl.VideoUsageControl r14) {
            r1 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "evCompControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "flashControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "focusMeteringControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "stillCaptureRequestControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.lang.String r0 = "torchControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.String r0 = "lowLightBoostControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            java.lang.String r0 = "zoomControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            java.lang.String r0 = "zslControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.lang.String r0 = "camera2cameraControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            java.lang.String r0 = "useCaseManager"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            java.lang.String r0 = "threads"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r13, r0)
            java.lang.String r0 = "videoUsageControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r14, r0)
            r1.<init>()
            r1.cameraProperties = r2
            r1.evCompControl = r3
            r1.flashControl = r4
            r1.focusMeteringControl = r5
            r1.stillCaptureRequestControl = r6
            r1.torchControl = r7
            r1.lowLightBoostControl = r8
            r1.zoomControl = r9
            r1.zslControl = r10
            r1.camera2cameraControl = r11
            r1.useCaseManager = r12
            r1.threads = r13
            r1.videoUsageControl = r14
            return
    }

    public static final /* synthetic */ androidx.camera.camera2.impl.FlashControl access$getFlashControl$p(androidx.camera.camera2.adapter.CameraControlAdapter r0) {
            androidx.camera.camera2.impl.FlashControl r0 = r0.flashControl
            return r0
    }

    private static final java.lang.Void cancelFocusAndMetering$lambda$0$0(androidx.camera.camera2.pipe.Result3A r0) {
            r0 = 0
            return r0
    }

    private static final com.google.common.util.concurrent.ListenableFuture enableLowLightBoostAsync$lambda$2(androidx.camera.camera2.adapter.CameraControlAdapter r2, boolean r3, java.lang.Void r4) {
            androidx.camera.camera2.impl.LowLightBoostControl r2 = r2.lowLightBoostControl
            r4 = 2
            r0 = 0
            r1 = 0
            kotlinx.coroutines.Deferred r2 = androidx.camera.camera2.impl.LowLightBoostControl.setLowLightBoostAsync$default(r2, r3, r1, r4, r0)
            com.google.common.util.concurrent.ListenableFuture r2 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.asVoidListenableFuture(r2)
            return r2
    }

    private static final com.google.common.util.concurrent.ListenableFuture enableLowLightBoostAsync$lambda$3(kotlin.jvm.functions.Function1 r0, java.lang.Object r1) {
            java.lang.Object r0 = r0.invoke(r1)
            com.google.common.util.concurrent.ListenableFuture r0 = (com.google.common.util.concurrent.ListenableFuture) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void addInteropConfig(androidx.camera.core.impl.Config r3) {
            r2 = this;
            java.lang.String r0 = "config"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.interop.Camera2CameraControl r0 = r2.camera2cameraControl
            androidx.camera.camera2.interop.CaptureRequestOptions$Builder$Companion r1 = androidx.camera.camera2.interop.CaptureRequestOptions.Builder.Companion
            androidx.camera.camera2.interop.CaptureRequestOptions$Builder r3 = r1.from(r3)
            androidx.camera.camera2.interop.CaptureRequestOptions r3 = r3.build()
            r0.addCaptureRequestOptions(r3)
            return
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void addZslConfig(androidx.camera.core.impl.SessionConfig.Builder r2) {
            r1 = this;
            java.lang.String r0 = "sessionConfigBuilder"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.adapter.ZslControl r0 = r1.zslControl
            r0.addZslConfig(r2)
            return
    }

    @Override // androidx.camera.core.CameraControl
    public com.google.common.util.concurrent.ListenableFuture<java.lang.Void> cancelFocusAndMetering() {
            r5 = this;
            r0 = 0
            r1 = 1
            kotlinx.coroutines.CompletableDeferred r2 = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred$default(r0, r1, r0)
            androidx.camera.camera2.impl.FocusMeteringControl r3 = r5.focusMeteringControl
            kotlinx.coroutines.Deferred r3 = r3.cancelFocusAndMeteringAsync()
            androidx.camera.camera2.adapter.CameraControlAdapter$$ExternalSyntheticLambda2 r4 = new androidx.camera.camera2.adapter.CameraControlAdapter$$ExternalSyntheticLambda2
            r4.<init>()
            androidx.camera.camera2.adapter.CoroutineAdaptersKt.propagateTo(r3, r2, r4)
            kotlinx.coroutines.Deferred r2 = (kotlinx.coroutines.Deferred) r2
            com.google.common.util.concurrent.ListenableFuture r0 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.asListenableFuture$default(r2, r0, r1, r0)
            com.google.common.util.concurrent.ListenableFuture r0 = androidx.camera.core.impl.utils.futures.Futures.nonCancellationPropagating(r0)
            java.lang.String r1 = "nonCancellationPropagating(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void clearInteropConfig() {
            r1 = this;
            androidx.camera.camera2.interop.Camera2CameraControl r0 = r1.camera2cameraControl
            r0.clearCaptureRequestOptions()
            return
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void clearZslConfig() {
            r1 = this;
            androidx.camera.camera2.adapter.ZslControl r0 = r1.zslControl
            r0.clearZslConfig()
            return
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void decrementVideoUsage() {
            r1 = this;
            androidx.camera.camera2.impl.VideoUsageControl r0 = r1.videoUsageControl
            r0.decrementUsage()
            return
    }

    @Override // androidx.camera.core.CameraControl
    public com.google.common.util.concurrent.ListenableFuture<java.lang.Void> enableLowLightBoostAsync(boolean r9) {
            r8 = this;
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r8.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r0 = r0.getSupportsLowLightBoost(r1)
            if (r0 != 0) goto L34
            androidx.camera.camera2.impl.Camera2Logger r9 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r9 = "CXCP"
            boolean r9 = androidx.camera.core.Logger.isDebugEnabled(r9)
            if (r9 == 0) goto L21
            java.lang.String r9 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r0 = "Unable to enable/disable low-light boost due to it is not supported."
            android.util.Log.d(r9, r0)
        L21:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r0 = "Low-light boost is not supported!"
            r9.<init>(r0)
            java.lang.Throwable r9 = (java.lang.Throwable) r9
            com.google.common.util.concurrent.ListenableFuture r9 = androidx.camera.core.impl.utils.futures.Futures.immediateFailedFuture(r9)
            java.lang.String r0 = "immediateFailedFuture(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r0)
            return r9
        L34:
            androidx.camera.camera2.impl.TorchControl r0 = r8.torchControl
            androidx.lifecycle.LiveData r0 = r0.getTorchStateLiveData()
            java.lang.Object r0 = r0.getValue()
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L43
            goto L5a
        L43:
            int r0 = r0.intValue()
            r1 = 1
            if (r0 != r1) goto L5a
            androidx.camera.camera2.impl.TorchControl r2 = r8.torchControl
            r6 = 6
            r7 = 0
            r3 = 0
            r4 = 0
            r5 = 0
            kotlinx.coroutines.Deferred r0 = androidx.camera.camera2.impl.TorchControl.setTorchAsync$default(r2, r3, r4, r5, r6, r7)
            com.google.common.util.concurrent.ListenableFuture r0 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.asVoidListenableFuture(r0)
            goto L6b
        L5a:
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            kotlinx.coroutines.CompletableDeferred r0 = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred(r0)
            kotlin.Unit r1 = kotlin.Unit.INSTANCE
            r0.complete(r1)
            kotlinx.coroutines.Deferred r0 = (kotlinx.coroutines.Deferred) r0
            com.google.common.util.concurrent.ListenableFuture r0 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.asVoidListenableFuture(r0)
        L6b:
            androidx.camera.camera2.adapter.CameraControlAdapter$$ExternalSyntheticLambda0 r1 = new androidx.camera.camera2.adapter.CameraControlAdapter$$ExternalSyntheticLambda0
            r1.<init>(r8, r9)
            androidx.camera.camera2.adapter.CameraControlAdapter$$ExternalSyntheticLambda1 r9 = new androidx.camera.camera2.adapter.CameraControlAdapter$$ExternalSyntheticLambda1
            r9.<init>(r1)
            java.util.concurrent.Executor r1 = androidx.camera.core.impl.utils.executor.CameraXExecutors.directExecutor()
            com.google.common.util.concurrent.ListenableFuture r9 = androidx.camera.core.impl.utils.futures.Futures.transformAsync(r0, r9, r1)
            com.google.common.util.concurrent.ListenableFuture r9 = androidx.camera.core.impl.utils.futures.Futures.nonCancellationPropagating(r9)
            java.lang.String r0 = "nonCancellationPropagating(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r9, r0)
            return r9
    }

    @Override // androidx.camera.core.CameraControl
    public com.google.common.util.concurrent.ListenableFuture<java.lang.Void> enableTorch(boolean r8) {
            r7 = this;
            androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r1 = r7.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r1 = r1.getMetadata()
            boolean r0 = r0.getSupportsLowLightBoost(r1)
            if (r0 == 0) goto L4a
            androidx.camera.camera2.impl.LowLightBoostControl r0 = r7.lowLightBoostControl
            androidx.lifecycle.LiveData r0 = r0.getLowLightBoostStateLiveData()
            java.lang.Object r0 = r0.getValue()
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 != 0) goto L1d
            goto L24
        L1d:
            int r0 = r0.intValue()
            r1 = -1
            if (r0 == r1) goto L4a
        L24:
            androidx.camera.camera2.impl.Camera2Logger r8 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r8 = "CXCP"
            boolean r8 = androidx.camera.core.Logger.isDebugEnabled(r8)
            if (r8 == 0) goto L37
            java.lang.String r8 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r0 = "Unable to enable/disable torch when low-light boost is on."
            android.util.Log.d(r8, r0)
        L37:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "Torch can not be enabled/disable when low-light boost is on!"
            r8.<init>(r0)
            java.lang.Throwable r8 = (java.lang.Throwable) r8
            com.google.common.util.concurrent.ListenableFuture r8 = androidx.camera.core.impl.utils.futures.Futures.immediateFailedFuture(r8)
            java.lang.String r0 = "immediateFailedFuture(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0)
            return r8
        L4a:
            androidx.camera.camera2.impl.TorchControl r1 = r7.torchControl
            r5 = 6
            r6 = 0
            r3 = 0
            r4 = 0
            r2 = r8
            kotlinx.coroutines.Deferred r8 = androidx.camera.camera2.impl.TorchControl.setTorchAsync$default(r1, r2, r3, r4, r5, r6)
            com.google.common.util.concurrent.ListenableFuture r8 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.asVoidListenableFuture(r8)
            com.google.common.util.concurrent.ListenableFuture r8 = androidx.camera.core.impl.utils.futures.Futures.nonCancellationPropagating(r8)
            java.lang.String r0 = "nonCancellationPropagating(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0)
            return r8
    }

    public final androidx.camera.camera2.interop.Camera2CameraControl getCamera2cameraControl() {
            r1 = this;
            androidx.camera.camera2.interop.Camera2CameraControl r0 = r1.camera2cameraControl
            return r0
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public com.google.common.util.concurrent.ListenableFuture<androidx.camera.core.imagecapture.CameraCapturePipeline> getCameraCapturePipelineAsync(int r8, int r9) {
            r7 = this;
            androidx.camera.camera2.impl.UseCaseManager r0 = r7.useCaseManager
            androidx.camera.camera2.impl.UseCaseCamera r3 = r0.getCamera()
            if (r3 != 0) goto L1b
            androidx.camera.core.CameraControl$OperationCanceledException r8 = new androidx.camera.core.CameraControl$OperationCanceledException
            java.lang.String r9 = "Camera is not active."
            r8.<init>(r9)
            java.lang.Throwable r8 = (java.lang.Throwable) r8
            com.google.common.util.concurrent.ListenableFuture r8 = androidx.camera.core.impl.utils.futures.Futures.immediateFailedFuture(r8)
            java.lang.String r9 = "immediateFailedFuture(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r9)
            return r8
        L1b:
            androidx.camera.camera2.impl.UseCaseThreads r0 = r7.threads
            kotlinx.coroutines.CoroutineScope r2 = r0.getSequentialScope()
            androidx.camera.camera2.adapter.CameraControlAdapter$getCameraCapturePipelineAsync$$inlined$future$1 r1 = new androidx.camera.camera2.adapter.CameraControlAdapter$getCameraCapturePipelineAsync$$inlined$future$1
            r5 = r7
            r4 = r8
            r6 = r9
            r1.<init>(r2, r3, r4, r5, r6)
            androidx.concurrent.futures.CallbackToFutureAdapter$Resolver r1 = (androidx.concurrent.futures.CallbackToFutureAdapter.Resolver) r1
            com.google.common.util.concurrent.ListenableFuture r8 = androidx.concurrent.futures.CallbackToFutureAdapter.getFuture(r1)
            java.lang.String r9 = "getFuture(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r9)
            return r8
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public int getFlashMode() {
            r1 = this;
            androidx.camera.camera2.impl.FlashControl r0 = r1.flashControl
            int r0 = r0.getFlashMode()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public androidx.camera.core.impl.Config getInteropConfig() {
            r1 = this;
            androidx.camera.camera2.interop.Camera2CameraControl r0 = r1.camera2cameraControl
            androidx.camera.camera2.interop.CaptureRequestOptions r0 = r0.getCaptureRequestOptions()
            androidx.camera.core.impl.Config r0 = (androidx.camera.core.impl.Config) r0
            return r0
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public androidx.camera.core.impl.SessionConfig getSessionConfig() {
            r2 = this;
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isWarnEnabled(r0)
            if (r0 == 0) goto L13
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r1 = "TODO: getSessionConfig is not yet supported"
            android.util.Log.w(r0, r1)
        L13:
            androidx.camera.core.impl.SessionConfig r0 = androidx.camera.core.impl.SessionConfig.defaultEmptySessionConfig()
            java.lang.String r1 = "defaultEmptySessionConfig(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            return r0
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void incrementVideoUsage() {
            r1 = this;
            androidx.camera.camera2.impl.VideoUsageControl r0 = r1.videoUsageControl
            r0.incrementUsage()
            return
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public boolean isInVideoUsage() {
            r1 = this;
            androidx.camera.camera2.impl.VideoUsageControl r0 = r1.videoUsageControl
            boolean r0 = r0.isInVideoUsage()
            return r0
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public boolean isZslDisabledByByUserCaseConfig() {
            r1 = this;
            androidx.camera.camera2.adapter.ZslControl r0 = r1.zslControl
            boolean r0 = r0.isZslDisabledByUserCaseConfig()
            return r0
    }

    @Override // androidx.camera.core.CameraControl
    public com.google.common.util.concurrent.ListenableFuture<java.lang.Integer> setExposureCompensationIndex(int r5) {
            r4 = this;
            androidx.camera.camera2.impl.EvCompControl r0 = r4.evCompControl
            r1 = 0
            r2 = 2
            r3 = 0
            kotlinx.coroutines.Deferred r5 = androidx.camera.camera2.impl.EvCompControl.updateAsync$default(r0, r5, r1, r2, r3)
            r0 = 1
            com.google.common.util.concurrent.ListenableFuture r5 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.asListenableFuture$default(r5, r3, r0, r3)
            com.google.common.util.concurrent.ListenableFuture r5 = androidx.camera.core.impl.utils.futures.Futures.nonCancellationPropagating(r5)
            java.lang.String r0 = "nonCancellationPropagating(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r0)
            return r5
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void setFlashMode(int r5) {
            r4 = this;
            androidx.camera.camera2.impl.FlashControl r0 = r4.flashControl
            r1 = 2
            r2 = 0
            r3 = 0
            androidx.camera.camera2.impl.FlashControl.setFlashAsync$default(r0, r5, r3, r1, r2)
            androidx.camera.camera2.adapter.ZslControl r0 = r4.zslControl
            r1 = 1
            if (r5 == r1) goto Lf
            if (r5 != 0) goto L10
        Lf:
            r3 = r1
        L10:
            r0.setZslDisabledByFlashMode(r3)
            return
    }

    @Override // androidx.camera.core.CameraControl
    public com.google.common.util.concurrent.ListenableFuture<java.lang.Void> setLinearZoom(float r2) {
            r1 = this;
            androidx.camera.camera2.impl.ZoomControl r0 = r1.zoomControl
            com.google.common.util.concurrent.ListenableFuture r2 = r0.setLinearZoom(r2)
            return r2
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void setScreenFlash(androidx.camera.core.ImageCapture.ScreenFlash r2) {
            r1 = this;
            androidx.camera.camera2.impl.FlashControl r0 = r1.flashControl
            r0.setScreenFlash(r2)
            return
    }

    @Override // androidx.camera.core.CameraControl
    public com.google.common.util.concurrent.ListenableFuture<java.lang.Void> setTorchStrengthLevel(int r2) {
            r1 = this;
            androidx.camera.camera2.impl.TorchControl r0 = r1.torchControl
            kotlinx.coroutines.Deferred r2 = r0.setTorchStrengthLevelAsync(r2)
            com.google.common.util.concurrent.ListenableFuture r2 = androidx.camera.camera2.adapter.CoroutineAdaptersKt.asVoidListenableFuture(r2)
            com.google.common.util.concurrent.ListenableFuture r2 = androidx.camera.core.impl.utils.futures.Futures.nonCancellationPropagating(r2)
            java.lang.String r0 = "nonCancellationPropagating(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r0)
            return r2
    }

    @Override // androidx.camera.core.CameraControl
    public com.google.common.util.concurrent.ListenableFuture<java.lang.Void> setZoomRatio(float r2) {
            r1 = this;
            androidx.camera.camera2.impl.ZoomControl r0 = r1.zoomControl
            com.google.common.util.concurrent.ListenableFuture r2 = r0.setZoomRatio(r2)
            return r2
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public void setZslDisabledByUserCaseConfig(boolean r2) {
            r1 = this;
            androidx.camera.camera2.adapter.ZslControl r0 = r1.zslControl
            r0.setZslDisabledByUserCaseConfig(r2)
            return
    }

    @Override // androidx.camera.core.CameraControl
    public com.google.common.util.concurrent.ListenableFuture<androidx.camera.core.FocusMeteringResult> startFocusAndMetering(androidx.camera.core.FocusMeteringAction r8) {
            r7 = this;
            java.lang.String r0 = "action"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            androidx.camera.camera2.impl.FocusMeteringControl r1 = r7.focusMeteringControl
            r5 = 2
            r6 = 0
            r3 = 0
            r2 = r8
            com.google.common.util.concurrent.ListenableFuture r8 = androidx.camera.camera2.impl.FocusMeteringControl.startFocusAndMetering$default(r1, r2, r3, r5, r6)
            com.google.common.util.concurrent.ListenableFuture r8 = androidx.camera.core.impl.utils.futures.Futures.nonCancellationPropagating(r8)
            java.lang.String r0 = "nonCancellationPropagating(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r8, r0)
            return r8
    }

    @Override // androidx.camera.core.impl.CameraControlInternal
    public com.google.common.util.concurrent.ListenableFuture<java.util.List<java.lang.Void>> submitStillCaptureRequests(java.util.List<androidx.camera.core.impl.CaptureConfig> r2, int r3, int r4) {
            r1 = this;
            java.lang.String r0 = "captureConfigs"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.impl.StillCaptureRequestControl r0 = r1.stillCaptureRequestControl
            com.google.common.util.concurrent.ListenableFuture r2 = r0.issueCaptureRequests(r2, r3, r4)
            return r2
    }
}
