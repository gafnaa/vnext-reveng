package androidx.camera.camera2.adapter;

/* JADX INFO: loaded from: classes.dex */
public final class CaptureConfigAdapter_Factory implements dagger.internal.Factory<androidx.camera.camera2.adapter.CaptureConfigAdapter> {
    private final dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> cameraPropertiesProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.compat.workaround.TemplateParamsOverride> templateParamsOverrideProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> threadsProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.config.UseCaseGraphContext> useCaseGraphContextProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.adapter.ZslControl> zslControlProvider;

    private CaptureConfigAdapter_Factory(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1, dagger.internal.Provider<androidx.camera.camera2.config.UseCaseGraphContext> r2, dagger.internal.Provider<androidx.camera.camera2.adapter.ZslControl> r3, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r4, dagger.internal.Provider<androidx.camera.camera2.compat.workaround.TemplateParamsOverride> r5) {
            r0 = this;
            r0.<init>()
            r0.cameraPropertiesProvider = r1
            r0.useCaseGraphContextProvider = r2
            r0.zslControlProvider = r3
            r0.threadsProvider = r4
            r0.templateParamsOverrideProvider = r5
            return
    }

    public static androidx.camera.camera2.adapter.CaptureConfigAdapter_Factory create(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r6, dagger.internal.Provider<androidx.camera.camera2.config.UseCaseGraphContext> r7, dagger.internal.Provider<androidx.camera.camera2.adapter.ZslControl> r8, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r9, dagger.internal.Provider<androidx.camera.camera2.compat.workaround.TemplateParamsOverride> r10) {
            androidx.camera.camera2.adapter.CaptureConfigAdapter_Factory r0 = new androidx.camera.camera2.adapter.CaptureConfigAdapter_Factory
            r1 = r6
            r2 = r7
            r3 = r8
            r4 = r9
            r5 = r10
            r0.<init>(r1, r2, r3, r4, r5)
            return r0
    }

    public static androidx.camera.camera2.adapter.CaptureConfigAdapter newInstance(androidx.camera.camera2.impl.CameraProperties r6, androidx.camera.camera2.config.UseCaseGraphContext r7, androidx.camera.camera2.adapter.ZslControl r8, androidx.camera.camera2.impl.UseCaseThreads r9, androidx.camera.camera2.compat.workaround.TemplateParamsOverride r10) {
            androidx.camera.camera2.adapter.CaptureConfigAdapter r0 = new androidx.camera.camera2.adapter.CaptureConfigAdapter
            r1 = r6
            r2 = r7
            r3 = r8
            r4 = r9
            r5 = r10
            r0.<init>(r1, r2, r3, r4, r5)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.adapter.CaptureConfigAdapter get() {
            r5 = this;
            dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r0 = r5.cameraPropertiesProvider
            java.lang.Object r0 = r0.get()
            androidx.camera.camera2.impl.CameraProperties r0 = (androidx.camera.camera2.impl.CameraProperties) r0
            dagger.internal.Provider<androidx.camera.camera2.config.UseCaseGraphContext> r1 = r5.useCaseGraphContextProvider
            java.lang.Object r1 = r1.get()
            androidx.camera.camera2.config.UseCaseGraphContext r1 = (androidx.camera.camera2.config.UseCaseGraphContext) r1
            dagger.internal.Provider<androidx.camera.camera2.adapter.ZslControl> r2 = r5.zslControlProvider
            java.lang.Object r2 = r2.get()
            androidx.camera.camera2.adapter.ZslControl r2 = (androidx.camera.camera2.adapter.ZslControl) r2
            dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r3 = r5.threadsProvider
            java.lang.Object r3 = r3.get()
            androidx.camera.camera2.impl.UseCaseThreads r3 = (androidx.camera.camera2.impl.UseCaseThreads) r3
            dagger.internal.Provider<androidx.camera.camera2.compat.workaround.TemplateParamsOverride> r4 = r5.templateParamsOverrideProvider
            java.lang.Object r4 = r4.get()
            androidx.camera.camera2.compat.workaround.TemplateParamsOverride r4 = (androidx.camera.camera2.compat.workaround.TemplateParamsOverride) r4
            androidx.camera.camera2.adapter.CaptureConfigAdapter r0 = newInstance(r0, r1, r2, r3, r4)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.adapter.CaptureConfigAdapter r0 = r1.get()
            return r0
    }
}
