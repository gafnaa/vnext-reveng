package androidx.camera.camera2.adapter;

/* JADX INFO: loaded from: classes.dex */
public final class CameraControlAdapter_Factory implements dagger.internal.Factory<androidx.camera.camera2.adapter.CameraControlAdapter> {
    private final dagger.internal.Provider<androidx.camera.camera2.interop.Camera2CameraControl> camera2cameraControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> cameraPropertiesProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.EvCompControl> evCompControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.FlashControl> flashControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.FocusMeteringControl> focusMeteringControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.LowLightBoostControl> lowLightBoostControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.StillCaptureRequestControl> stillCaptureRequestControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> threadsProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.TorchControl> torchControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseManager> useCaseManagerProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.VideoUsageControl> videoUsageControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.ZoomControl> zoomControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.adapter.ZslControl> zslControlProvider;

    private CameraControlAdapter_Factory(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1, dagger.internal.Provider<androidx.camera.camera2.impl.EvCompControl> r2, dagger.internal.Provider<androidx.camera.camera2.impl.FlashControl> r3, dagger.internal.Provider<androidx.camera.camera2.impl.FocusMeteringControl> r4, dagger.internal.Provider<androidx.camera.camera2.impl.StillCaptureRequestControl> r5, dagger.internal.Provider<androidx.camera.camera2.impl.TorchControl> r6, dagger.internal.Provider<androidx.camera.camera2.impl.LowLightBoostControl> r7, dagger.internal.Provider<androidx.camera.camera2.impl.ZoomControl> r8, dagger.internal.Provider<androidx.camera.camera2.adapter.ZslControl> r9, dagger.internal.Provider<androidx.camera.camera2.interop.Camera2CameraControl> r10, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseManager> r11, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r12, dagger.internal.Provider<androidx.camera.camera2.impl.VideoUsageControl> r13) {
            r0 = this;
            r0.<init>()
            r0.cameraPropertiesProvider = r1
            r0.evCompControlProvider = r2
            r0.flashControlProvider = r3
            r0.focusMeteringControlProvider = r4
            r0.stillCaptureRequestControlProvider = r5
            r0.torchControlProvider = r6
            r0.lowLightBoostControlProvider = r7
            r0.zoomControlProvider = r8
            r0.zslControlProvider = r9
            r0.camera2cameraControlProvider = r10
            r0.useCaseManagerProvider = r11
            r0.threadsProvider = r12
            r0.videoUsageControlProvider = r13
            return
    }

    public static androidx.camera.camera2.adapter.CameraControlAdapter_Factory create(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r14, dagger.internal.Provider<androidx.camera.camera2.impl.EvCompControl> r15, dagger.internal.Provider<androidx.camera.camera2.impl.FlashControl> r16, dagger.internal.Provider<androidx.camera.camera2.impl.FocusMeteringControl> r17, dagger.internal.Provider<androidx.camera.camera2.impl.StillCaptureRequestControl> r18, dagger.internal.Provider<androidx.camera.camera2.impl.TorchControl> r19, dagger.internal.Provider<androidx.camera.camera2.impl.LowLightBoostControl> r20, dagger.internal.Provider<androidx.camera.camera2.impl.ZoomControl> r21, dagger.internal.Provider<androidx.camera.camera2.adapter.ZslControl> r22, dagger.internal.Provider<androidx.camera.camera2.interop.Camera2CameraControl> r23, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseManager> r24, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r25, dagger.internal.Provider<androidx.camera.camera2.impl.VideoUsageControl> r26) {
            androidx.camera.camera2.adapter.CameraControlAdapter_Factory r0 = new androidx.camera.camera2.adapter.CameraControlAdapter_Factory
            r1 = r14
            r2 = r15
            r3 = r16
            r4 = r17
            r5 = r18
            r6 = r19
            r7 = r20
            r8 = r21
            r9 = r22
            r10 = r23
            r11 = r24
            r12 = r25
            r13 = r26
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            return r0
    }

    public static androidx.camera.camera2.adapter.CameraControlAdapter newInstance(androidx.camera.camera2.impl.CameraProperties r14, androidx.camera.camera2.impl.EvCompControl r15, androidx.camera.camera2.impl.FlashControl r16, androidx.camera.camera2.impl.FocusMeteringControl r17, androidx.camera.camera2.impl.StillCaptureRequestControl r18, androidx.camera.camera2.impl.TorchControl r19, androidx.camera.camera2.impl.LowLightBoostControl r20, androidx.camera.camera2.impl.ZoomControl r21, androidx.camera.camera2.adapter.ZslControl r22, androidx.camera.camera2.interop.Camera2CameraControl r23, androidx.camera.camera2.impl.UseCaseManager r24, androidx.camera.camera2.impl.UseCaseThreads r25, androidx.camera.camera2.impl.VideoUsageControl r26) {
            androidx.camera.camera2.adapter.CameraControlAdapter r0 = new androidx.camera.camera2.adapter.CameraControlAdapter
            r1 = r14
            r2 = r15
            r3 = r16
            r4 = r17
            r5 = r18
            r6 = r19
            r7 = r20
            r8 = r21
            r9 = r22
            r10 = r23
            r11 = r24
            r12 = r25
            r13 = r26
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.adapter.CameraControlAdapter get() {
            r14 = this;
            dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r0 = r14.cameraPropertiesProvider
            java.lang.Object r0 = r0.get()
            r1 = r0
            androidx.camera.camera2.impl.CameraProperties r1 = (androidx.camera.camera2.impl.CameraProperties) r1
            dagger.internal.Provider<androidx.camera.camera2.impl.EvCompControl> r0 = r14.evCompControlProvider
            java.lang.Object r0 = r0.get()
            r2 = r0
            androidx.camera.camera2.impl.EvCompControl r2 = (androidx.camera.camera2.impl.EvCompControl) r2
            dagger.internal.Provider<androidx.camera.camera2.impl.FlashControl> r0 = r14.flashControlProvider
            java.lang.Object r0 = r0.get()
            r3 = r0
            androidx.camera.camera2.impl.FlashControl r3 = (androidx.camera.camera2.impl.FlashControl) r3
            dagger.internal.Provider<androidx.camera.camera2.impl.FocusMeteringControl> r0 = r14.focusMeteringControlProvider
            java.lang.Object r0 = r0.get()
            r4 = r0
            androidx.camera.camera2.impl.FocusMeteringControl r4 = (androidx.camera.camera2.impl.FocusMeteringControl) r4
            dagger.internal.Provider<androidx.camera.camera2.impl.StillCaptureRequestControl> r0 = r14.stillCaptureRequestControlProvider
            java.lang.Object r0 = r0.get()
            r5 = r0
            androidx.camera.camera2.impl.StillCaptureRequestControl r5 = (androidx.camera.camera2.impl.StillCaptureRequestControl) r5
            dagger.internal.Provider<androidx.camera.camera2.impl.TorchControl> r0 = r14.torchControlProvider
            java.lang.Object r0 = r0.get()
            r6 = r0
            androidx.camera.camera2.impl.TorchControl r6 = (androidx.camera.camera2.impl.TorchControl) r6
            dagger.internal.Provider<androidx.camera.camera2.impl.LowLightBoostControl> r0 = r14.lowLightBoostControlProvider
            java.lang.Object r0 = r0.get()
            r7 = r0
            androidx.camera.camera2.impl.LowLightBoostControl r7 = (androidx.camera.camera2.impl.LowLightBoostControl) r7
            dagger.internal.Provider<androidx.camera.camera2.impl.ZoomControl> r0 = r14.zoomControlProvider
            java.lang.Object r0 = r0.get()
            r8 = r0
            androidx.camera.camera2.impl.ZoomControl r8 = (androidx.camera.camera2.impl.ZoomControl) r8
            dagger.internal.Provider<androidx.camera.camera2.adapter.ZslControl> r0 = r14.zslControlProvider
            java.lang.Object r0 = r0.get()
            r9 = r0
            androidx.camera.camera2.adapter.ZslControl r9 = (androidx.camera.camera2.adapter.ZslControl) r9
            dagger.internal.Provider<androidx.camera.camera2.interop.Camera2CameraControl> r0 = r14.camera2cameraControlProvider
            java.lang.Object r0 = r0.get()
            r10 = r0
            androidx.camera.camera2.interop.Camera2CameraControl r10 = (androidx.camera.camera2.interop.Camera2CameraControl) r10
            dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseManager> r0 = r14.useCaseManagerProvider
            java.lang.Object r0 = r0.get()
            r11 = r0
            androidx.camera.camera2.impl.UseCaseManager r11 = (androidx.camera.camera2.impl.UseCaseManager) r11
            dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r0 = r14.threadsProvider
            java.lang.Object r0 = r0.get()
            r12 = r0
            androidx.camera.camera2.impl.UseCaseThreads r12 = (androidx.camera.camera2.impl.UseCaseThreads) r12
            dagger.internal.Provider<androidx.camera.camera2.impl.VideoUsageControl> r0 = r14.videoUsageControlProvider
            java.lang.Object r0 = r0.get()
            r13 = r0
            androidx.camera.camera2.impl.VideoUsageControl r13 = (androidx.camera.camera2.impl.VideoUsageControl) r13
            androidx.camera.camera2.adapter.CameraControlAdapter r0 = newInstance(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraControlAdapter r0 = r1.get()
            return r0
    }
}
