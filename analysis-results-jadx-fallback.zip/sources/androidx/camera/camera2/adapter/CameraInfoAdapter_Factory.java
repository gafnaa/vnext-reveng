package androidx.camera.camera2.adapter;

/* JADX INFO: loaded from: classes.dex */
public final class CameraInfoAdapter_Factory implements dagger.internal.Factory<androidx.camera.camera2.adapter.CameraInfoAdapter> {
    private final dagger.internal.Provider<androidx.camera.camera2.impl.CameraCallbackMap> cameraCallbackMapProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.config.CameraConfig> cameraConfigProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.adapter.CameraControlStateAdapter> cameraControlStateAdapterProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> cameraPropertiesProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.compat.quirk.CameraQuirks> cameraQuirksProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.adapter.CameraStateAdapter> cameraStateAdapterProvider;
    private final dagger.internal.Provider<androidx.camera.core.impl.EncoderProfilesProvider> encoderProfilesProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.FocusMeteringControl> focusMeteringControlProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.internal.IntrinsicZoomCalculator> intrinsicZoomCalculatorProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.compat.StreamConfigurationMapCompat> streamConfigurationMapCompatProvider;
    private final dagger.internal.Provider<androidx.camera.core.internal.StreamSpecsCalculator> streamSpecsCalculatorProvider;

    private CameraInfoAdapter_Factory(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1, dagger.internal.Provider<androidx.camera.camera2.config.CameraConfig> r2, dagger.internal.Provider<androidx.camera.camera2.adapter.CameraStateAdapter> r3, dagger.internal.Provider<androidx.camera.camera2.adapter.CameraControlStateAdapter> r4, dagger.internal.Provider<androidx.camera.camera2.impl.CameraCallbackMap> r5, dagger.internal.Provider<androidx.camera.camera2.impl.FocusMeteringControl> r6, dagger.internal.Provider<androidx.camera.camera2.compat.quirk.CameraQuirks> r7, dagger.internal.Provider<androidx.camera.core.impl.EncoderProfilesProvider> r8, dagger.internal.Provider<androidx.camera.camera2.compat.StreamConfigurationMapCompat> r9, dagger.internal.Provider<androidx.camera.camera2.internal.IntrinsicZoomCalculator> r10, dagger.internal.Provider<androidx.camera.core.internal.StreamSpecsCalculator> r11) {
            r0 = this;
            r0.<init>()
            r0.cameraPropertiesProvider = r1
            r0.cameraConfigProvider = r2
            r0.cameraStateAdapterProvider = r3
            r0.cameraControlStateAdapterProvider = r4
            r0.cameraCallbackMapProvider = r5
            r0.focusMeteringControlProvider = r6
            r0.cameraQuirksProvider = r7
            r0.encoderProfilesProvider = r8
            r0.streamConfigurationMapCompatProvider = r9
            r0.intrinsicZoomCalculatorProvider = r10
            r0.streamSpecsCalculatorProvider = r11
            return
    }

    public static androidx.camera.camera2.adapter.CameraInfoAdapter_Factory create(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r12, dagger.internal.Provider<androidx.camera.camera2.config.CameraConfig> r13, dagger.internal.Provider<androidx.camera.camera2.adapter.CameraStateAdapter> r14, dagger.internal.Provider<androidx.camera.camera2.adapter.CameraControlStateAdapter> r15, dagger.internal.Provider<androidx.camera.camera2.impl.CameraCallbackMap> r16, dagger.internal.Provider<androidx.camera.camera2.impl.FocusMeteringControl> r17, dagger.internal.Provider<androidx.camera.camera2.compat.quirk.CameraQuirks> r18, dagger.internal.Provider<androidx.camera.core.impl.EncoderProfilesProvider> r19, dagger.internal.Provider<androidx.camera.camera2.compat.StreamConfigurationMapCompat> r20, dagger.internal.Provider<androidx.camera.camera2.internal.IntrinsicZoomCalculator> r21, dagger.internal.Provider<androidx.camera.core.internal.StreamSpecsCalculator> r22) {
            androidx.camera.camera2.adapter.CameraInfoAdapter_Factory r0 = new androidx.camera.camera2.adapter.CameraInfoAdapter_Factory
            r1 = r12
            r2 = r13
            r3 = r14
            r4 = r15
            r5 = r16
            r6 = r17
            r7 = r18
            r8 = r19
            r9 = r20
            r10 = r21
            r11 = r22
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
            return r0
    }

    public static androidx.camera.camera2.adapter.CameraInfoAdapter newInstance(androidx.camera.camera2.impl.CameraProperties r12, androidx.camera.camera2.config.CameraConfig r13, androidx.camera.camera2.adapter.CameraStateAdapter r14, androidx.camera.camera2.adapter.CameraControlStateAdapter r15, androidx.camera.camera2.impl.CameraCallbackMap r16, androidx.camera.camera2.impl.FocusMeteringControl r17, androidx.camera.camera2.compat.quirk.CameraQuirks r18, androidx.camera.core.impl.EncoderProfilesProvider r19, androidx.camera.camera2.compat.StreamConfigurationMapCompat r20, androidx.camera.camera2.internal.IntrinsicZoomCalculator r21, androidx.camera.core.internal.StreamSpecsCalculator r22) {
            androidx.camera.camera2.adapter.CameraInfoAdapter r0 = new androidx.camera.camera2.adapter.CameraInfoAdapter
            r1 = r12
            r2 = r13
            r3 = r14
            r4 = r15
            r5 = r16
            r6 = r17
            r7 = r18
            r8 = r19
            r9 = r20
            r10 = r21
            r11 = r22
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.adapter.CameraInfoAdapter get() {
            r12 = this;
            dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r0 = r12.cameraPropertiesProvider
            java.lang.Object r0 = r0.get()
            r1 = r0
            androidx.camera.camera2.impl.CameraProperties r1 = (androidx.camera.camera2.impl.CameraProperties) r1
            dagger.internal.Provider<androidx.camera.camera2.config.CameraConfig> r0 = r12.cameraConfigProvider
            java.lang.Object r0 = r0.get()
            r2 = r0
            androidx.camera.camera2.config.CameraConfig r2 = (androidx.camera.camera2.config.CameraConfig) r2
            dagger.internal.Provider<androidx.camera.camera2.adapter.CameraStateAdapter> r0 = r12.cameraStateAdapterProvider
            java.lang.Object r0 = r0.get()
            r3 = r0
            androidx.camera.camera2.adapter.CameraStateAdapter r3 = (androidx.camera.camera2.adapter.CameraStateAdapter) r3
            dagger.internal.Provider<androidx.camera.camera2.adapter.CameraControlStateAdapter> r0 = r12.cameraControlStateAdapterProvider
            java.lang.Object r0 = r0.get()
            r4 = r0
            androidx.camera.camera2.adapter.CameraControlStateAdapter r4 = (androidx.camera.camera2.adapter.CameraControlStateAdapter) r4
            dagger.internal.Provider<androidx.camera.camera2.impl.CameraCallbackMap> r0 = r12.cameraCallbackMapProvider
            java.lang.Object r0 = r0.get()
            r5 = r0
            androidx.camera.camera2.impl.CameraCallbackMap r5 = (androidx.camera.camera2.impl.CameraCallbackMap) r5
            dagger.internal.Provider<androidx.camera.camera2.impl.FocusMeteringControl> r0 = r12.focusMeteringControlProvider
            java.lang.Object r0 = r0.get()
            r6 = r0
            androidx.camera.camera2.impl.FocusMeteringControl r6 = (androidx.camera.camera2.impl.FocusMeteringControl) r6
            dagger.internal.Provider<androidx.camera.camera2.compat.quirk.CameraQuirks> r0 = r12.cameraQuirksProvider
            java.lang.Object r0 = r0.get()
            r7 = r0
            androidx.camera.camera2.compat.quirk.CameraQuirks r7 = (androidx.camera.camera2.compat.quirk.CameraQuirks) r7
            dagger.internal.Provider<androidx.camera.core.impl.EncoderProfilesProvider> r0 = r12.encoderProfilesProvider
            java.lang.Object r0 = r0.get()
            r8 = r0
            androidx.camera.core.impl.EncoderProfilesProvider r8 = (androidx.camera.core.impl.EncoderProfilesProvider) r8
            dagger.internal.Provider<androidx.camera.camera2.compat.StreamConfigurationMapCompat> r0 = r12.streamConfigurationMapCompatProvider
            java.lang.Object r0 = r0.get()
            r9 = r0
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r9 = (androidx.camera.camera2.compat.StreamConfigurationMapCompat) r9
            dagger.internal.Provider<androidx.camera.camera2.internal.IntrinsicZoomCalculator> r0 = r12.intrinsicZoomCalculatorProvider
            java.lang.Object r0 = r0.get()
            r10 = r0
            androidx.camera.camera2.internal.IntrinsicZoomCalculator r10 = (androidx.camera.camera2.internal.IntrinsicZoomCalculator) r10
            dagger.internal.Provider<androidx.camera.core.internal.StreamSpecsCalculator> r0 = r12.streamSpecsCalculatorProvider
            java.lang.Object r0 = r0.get()
            r11 = r0
            androidx.camera.core.internal.StreamSpecsCalculator r11 = (androidx.camera.core.internal.StreamSpecsCalculator) r11
            androidx.camera.camera2.adapter.CameraInfoAdapter r0 = newInstance(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.adapter.CameraInfoAdapter r0 = r1.get()
            return r0
    }
}
