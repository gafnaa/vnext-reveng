package androidx.camera.camera2.adapter;

/* JADX INFO: loaded from: classes.dex */
public final class ZslControlNoOpImpl_Factory implements dagger.internal.Factory<androidx.camera.camera2.adapter.ZslControlNoOpImpl> {

    private static final class InstanceHolder {
        static final androidx.camera.camera2.adapter.ZslControlNoOpImpl_Factory INSTANCE = null;

        static {
                androidx.camera.camera2.adapter.ZslControlNoOpImpl_Factory r0 = new androidx.camera.camera2.adapter.ZslControlNoOpImpl_Factory
                r0.<init>()
                androidx.camera.camera2.adapter.ZslControlNoOpImpl_Factory.InstanceHolder.INSTANCE = r0
                return
        }

        private InstanceHolder() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public ZslControlNoOpImpl_Factory() {
            r0 = this;
            r0.<init>()
            return
    }

    public static androidx.camera.camera2.adapter.ZslControlNoOpImpl_Factory create() {
            androidx.camera.camera2.adapter.ZslControlNoOpImpl_Factory r0 = androidx.camera.camera2.adapter.ZslControlNoOpImpl_Factory.InstanceHolder.INSTANCE
            return r0
    }

    public static androidx.camera.camera2.adapter.ZslControlNoOpImpl newInstance() {
            androidx.camera.camera2.adapter.ZslControlNoOpImpl r0 = new androidx.camera.camera2.adapter.ZslControlNoOpImpl
            r0.<init>()
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.adapter.ZslControlNoOpImpl get() {
            r1 = this;
            androidx.camera.camera2.adapter.ZslControlNoOpImpl r0 = newInstance()
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.adapter.ZslControlNoOpImpl r0 = r1.get()
            return r0
    }
}
