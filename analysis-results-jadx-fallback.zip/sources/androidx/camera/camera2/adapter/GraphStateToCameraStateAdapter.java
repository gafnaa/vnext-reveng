package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: GraphStateToCameraStateAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\f\u001a\u00020\rH\u0016J\b\u0010\u000e\u001a\u00020\rH\u0016J\b\u0010\u000f\u001a\u00020\rH\u0016J\b\u0010\u0010\u001a\u00020\rH\u0016J\u0010\u0010\u0011\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\u0013H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086.¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000b¨\u0006\u0014"}, d2 = {"Landroidx/camera/camera2/adapter/GraphStateToCameraStateAdapter;", "Landroidx/camera/camera2/pipe/GraphStateListener;", "cameraStateAdapter", "Landroidx/camera/camera2/adapter/CameraStateAdapter;", "<init>", "(Landroidx/camera/camera2/adapter/CameraStateAdapter;)V", "cameraGraph", "Landroidx/camera/camera2/pipe/CameraGraph;", "getCameraGraph", "()Landroidx/camera/camera2/pipe/CameraGraph;", "setCameraGraph", "(Landroidx/camera/camera2/pipe/CameraGraph;)V", "onGraphStarting", "", "onGraphStarted", "onGraphStopping", "onGraphStopped", "onGraphError", "graphStateError", "Landroidx/camera/camera2/pipe/GraphState$GraphStateError;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class GraphStateToCameraStateAdapter implements androidx.camera.camera2.pipe.GraphStateListener {
    public androidx.camera.camera2.pipe.CameraGraph cameraGraph;
    private final androidx.camera.camera2.adapter.CameraStateAdapter cameraStateAdapter;

    public GraphStateToCameraStateAdapter(androidx.camera.camera2.adapter.CameraStateAdapter r2) {
            r1 = this;
            java.lang.String r0 = "cameraStateAdapter"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.cameraStateAdapter = r2
            return
    }

    public final androidx.camera.camera2.pipe.CameraGraph getCameraGraph() {
            r1 = this;
            androidx.camera.camera2.pipe.CameraGraph r0 = r1.cameraGraph
            if (r0 == 0) goto L5
            return r0
        L5:
            java.lang.String r0 = "cameraGraph"
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r0)
            r0 = 0
            return r0
    }

    @Override // androidx.camera.camera2.pipe.GraphStateListener
    public void onGraphError(androidx.camera.camera2.pipe.GraphState.GraphStateError r3) {
            r2 = this;
            java.lang.String r0 = "graphStateError"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r2.cameraStateAdapter
            androidx.camera.camera2.pipe.CameraGraph r1 = r2.getCameraGraph()
            androidx.camera.camera2.pipe.GraphState r3 = (androidx.camera.camera2.pipe.GraphState) r3
            r0.onGraphStateUpdated(r1, r3)
            return
    }

    @Override // androidx.camera.camera2.pipe.GraphStateListener
    public void onGraphStarted() {
            r3 = this;
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r3.cameraStateAdapter
            androidx.camera.camera2.pipe.CameraGraph r1 = r3.getCameraGraph()
            androidx.camera.camera2.pipe.GraphState$GraphStateStarted r2 = androidx.camera.camera2.pipe.GraphState.GraphStateStarted.INSTANCE
            androidx.camera.camera2.pipe.GraphState r2 = (androidx.camera.camera2.pipe.GraphState) r2
            r0.onGraphStateUpdated(r1, r2)
            return
    }

    @Override // androidx.camera.camera2.pipe.GraphStateListener
    public void onGraphStarting() {
            r3 = this;
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r3.cameraStateAdapter
            androidx.camera.camera2.pipe.CameraGraph r1 = r3.getCameraGraph()
            androidx.camera.camera2.pipe.GraphState$GraphStateStarting r2 = androidx.camera.camera2.pipe.GraphState.GraphStateStarting.INSTANCE
            androidx.camera.camera2.pipe.GraphState r2 = (androidx.camera.camera2.pipe.GraphState) r2
            r0.onGraphStateUpdated(r1, r2)
            return
    }

    @Override // androidx.camera.camera2.pipe.GraphStateListener
    public void onGraphStopped() {
            r3 = this;
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r3.cameraStateAdapter
            androidx.camera.camera2.pipe.CameraGraph r1 = r3.getCameraGraph()
            androidx.camera.camera2.pipe.GraphState$GraphStateStopped r2 = androidx.camera.camera2.pipe.GraphState.GraphStateStopped.INSTANCE
            androidx.camera.camera2.pipe.GraphState r2 = (androidx.camera.camera2.pipe.GraphState) r2
            r0.onGraphStateUpdated(r1, r2)
            return
    }

    @Override // androidx.camera.camera2.pipe.GraphStateListener
    public void onGraphStopping() {
            r3 = this;
            androidx.camera.camera2.adapter.CameraStateAdapter r0 = r3.cameraStateAdapter
            androidx.camera.camera2.pipe.CameraGraph r1 = r3.getCameraGraph()
            androidx.camera.camera2.pipe.GraphState$GraphStateStopping r2 = androidx.camera.camera2.pipe.GraphState.GraphStateStopping.INSTANCE
            androidx.camera.camera2.pipe.GraphState r2 = (androidx.camera.camera2.pipe.GraphState) r2
            r0.onGraphStateUpdated(r1, r2)
            return
    }

    public final void setCameraGraph(androidx.camera.camera2.pipe.CameraGraph r2) {
            r1 = this;
            java.lang.String r0 = "<set-?>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.cameraGraph = r2
            return
    }
}
