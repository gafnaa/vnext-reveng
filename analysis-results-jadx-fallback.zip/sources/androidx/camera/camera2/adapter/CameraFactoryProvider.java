package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraFactoryProvider.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B+\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\b\u0010\tJ<\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u00072\b\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u00152\u0006\u0010\u0016\u001a\u00020\u0017H\u0016J'\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u000e\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u00072\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0002¢\u0006\u0002\b\u001bR\u0010\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001c"}, d2 = {"Landroidx/camera/camera2/adapter/CameraFactoryProvider;", "Landroidx/camera/core/impl/CameraFactory$Provider;", "sharedCameraPipe", "Landroidx/camera/camera2/pipe/CameraPipe;", "sharedAppContext", "Landroid/content/Context;", "sharedThreadConfig", "Landroidx/camera/core/impl/CameraThreadConfig;", "<init>", "(Landroidx/camera/camera2/pipe/CameraPipe;Landroid/content/Context;Landroidx/camera/core/impl/CameraThreadConfig;)V", "sharedInteropCallbacks", "Landroidx/camera/camera2/impl/CameraInteropStateCallbackRepository;", "newInstance", "Landroidx/camera/core/impl/CameraFactory;", "context", "threadConfig", "availableCamerasLimiter", "Landroidx/camera/core/CameraSelector;", "cameraOpenRetryMaxTimeoutInMs", "", "cameraXConfig", "Landroidx/camera/core/CameraXConfig;", "streamSpecsCalculator", "Landroidx/camera/core/internal/StreamSpecsCalculator;", "createCameraPipe", "openRetryMaxTimeout", "Landroidx/camera/camera2/pipe/core/DurationNs;", "createCameraPipe-ck8WKOA", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraFactoryProvider implements androidx.camera.core.impl.CameraFactory.Provider {
    private final android.content.Context sharedAppContext;
    private final androidx.camera.camera2.pipe.CameraPipe sharedCameraPipe;
    private final androidx.camera.camera2.impl.CameraInteropStateCallbackRepository sharedInteropCallbacks;
    private final androidx.camera.core.impl.CameraThreadConfig sharedThreadConfig;

    public static /* synthetic */ androidx.camera.camera2.pipe.CameraPipe $r8$lambda$ZlHettYjxZNyriDnsgQO8y2N0Rk(androidx.camera.camera2.adapter.CameraFactoryProvider r0, android.content.Context r1, androidx.camera.core.impl.CameraThreadConfig r2, androidx.camera.camera2.pipe.core.DurationNs r3) {
            androidx.camera.camera2.pipe.CameraPipe r0 = newInstance$lambda$0(r0, r1, r2, r3)
            return r0
    }

    public CameraFactoryProvider() {
            r6 = this;
            r4 = 7
            r5 = 0
            r1 = 0
            r2 = 0
            r3 = 0
            r0 = r6
            r0.<init>(r1, r2, r3, r4, r5)
            return
    }

    public CameraFactoryProvider(androidx.camera.camera2.pipe.CameraPipe r1, android.content.Context r2, androidx.camera.core.impl.CameraThreadConfig r3) {
            r0 = this;
            r0.<init>()
            r0.sharedCameraPipe = r1
            r0.sharedAppContext = r2
            r0.sharedThreadConfig = r3
            androidx.camera.camera2.impl.CameraInteropStateCallbackRepository r1 = new androidx.camera.camera2.impl.CameraInteropStateCallbackRepository
            r1.<init>()
            r0.sharedInteropCallbacks = r1
            return
    }

    public /* synthetic */ CameraFactoryProvider(androidx.camera.camera2.pipe.CameraPipe r2, android.content.Context r3, androidx.camera.core.impl.CameraThreadConfig r4, int r5, kotlin.jvm.internal.DefaultConstructorMarker r6) {
            r1 = this;
            r6 = r5 & 1
            r0 = 0
            if (r6 == 0) goto L6
            r2 = r0
        L6:
            r6 = r5 & 2
            if (r6 == 0) goto Lb
            r3 = r0
        Lb:
            r5 = r5 & 4
            if (r5 == 0) goto L10
            r4 = r0
        L10:
            r1.<init>(r2, r3, r4)
            return
    }

    public static final /* synthetic */ androidx.camera.camera2.pipe.CameraPipe access$getSharedCameraPipe$p(androidx.camera.camera2.adapter.CameraFactoryProvider r0) {
            androidx.camera.camera2.pipe.CameraPipe r0 = r0.sharedCameraPipe
            return r0
    }

    public static final /* synthetic */ androidx.camera.camera2.impl.CameraInteropStateCallbackRepository access$getSharedInteropCallbacks$p(androidx.camera.camera2.adapter.CameraFactoryProvider r0) {
            androidx.camera.camera2.impl.CameraInteropStateCallbackRepository r0 = r0.sharedInteropCallbacks
            return r0
    }

    /* JADX INFO: renamed from: createCameraPipe-ck8WKOA, reason: not valid java name */
    private final androidx.camera.camera2.pipe.CameraPipe m59createCameraPipeck8WKOA(android.content.Context r18, androidx.camera.core.impl.CameraThreadConfig r19, androidx.camera.camera2.pipe.core.DurationNs r20) {
            r17 = this;
            java.lang.String r0 = "Created CameraPipe in "
            androidx.camera.camera2.pipe.core.Debug r1 = androidx.camera.camera2.pipe.core.Debug.INSTANCE
            java.lang.String r1 = "Create CameraPipe"
            android.os.Trace.beginSection(r1)     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.core.SystemTimeSource r1 = new androidx.camera.camera2.pipe.core.SystemTimeSource     // Catch: java.lang.Throwable -> Lb2
            r1.<init>()     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.core.Timestamps r2 = androidx.camera.camera2.pipe.core.Timestamps.INSTANCE     // Catch: java.lang.Throwable -> Lb2
            r2 = r1
            androidx.camera.camera2.pipe.core.TimeSource r2 = (androidx.camera.camera2.pipe.core.TimeSource) r2     // Catch: java.lang.Throwable -> Lb2
            long r2 = r2.mo987nowvQl9yQU()     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.CameraPipe$Config r4 = new androidx.camera.camera2.pipe.CameraPipe$Config     // Catch: java.lang.Throwable -> Lb2
            android.content.Context r5 = androidx.camera.core.impl.utils.ContextUtil.getPersistentApplicationContext(r18)     // Catch: java.lang.Throwable -> Lb2
            java.lang.String r6 = "getPersistentApplicationContext(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r6)     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.CameraPipe$ThreadConfig r6 = new androidx.camera.camera2.pipe.CameraPipe$ThreadConfig     // Catch: java.lang.Throwable -> Lb2
            java.util.concurrent.Executor r7 = r19.getCameraExecutor()     // Catch: java.lang.Throwable -> Lb2
            java.util.concurrent.Executor r11 = androidx.camera.core.impl.utils.executor.CameraXExecutors.newSequentialExecutor(r7)     // Catch: java.lang.Throwable -> Lb2
            r15 = 119(0x77, float:1.67E-43)
            r16 = 0
            r8 = 0
            r9 = 0
            r10 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r7 = r6
            r7.<init>(r8, r9, r10, r11, r12, r13, r14, r15, r16)     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.CameraPipe$CameraInteropConfig r9 = new androidx.camera.camera2.pipe.CameraPipe$CameraInteropConfig     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.impl.CameraInteropStateCallbackRepository r7 = access$getSharedInteropCallbacks$p(r17)     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.impl.CameraInteropStateCallbackRepository$CameraDeviceStateCallbacks r7 = r7.getDeviceStateCallback()     // Catch: java.lang.Throwable -> Lb2
            android.hardware.camera2.CameraDevice$StateCallback r7 = (android.hardware.camera2.CameraDevice.StateCallback) r7     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.impl.CameraInteropStateCallbackRepository r8 = access$getSharedInteropCallbacks$p(r17)     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.CameraInterop$CaptureSessionListener r8 = r8.getSessionStateCallback()     // Catch: java.lang.Throwable -> Lb2
            r15 = 0
            r10 = r20
            r9.<init>(r7, r8, r10, r15)     // Catch: java.lang.Throwable -> Lb2
            r13 = 236(0xec, float:3.31E-43)
            r14 = 0
            r7 = 0
            r8 = 0
            r10 = 0
            r11 = 0
            r12 = 0
            r4.<init>(r5, r6, r7, r8, r9, r10, r11, r12, r13, r14)     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.CameraPipe r4 = androidx.camera.camera2.pipe.CameraPipeKt.CameraPipe(r4)     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.impl.Camera2Logger r5 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE     // Catch: java.lang.Throwable -> Lb2
            java.lang.String r5 = "CXCP"
            boolean r5 = androidx.camera.core.Logger.isDebugEnabled(r5)     // Catch: java.lang.Throwable -> Lb2
            if (r5 == 0) goto Lae
            java.lang.String r5 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()     // Catch: java.lang.Throwable -> Lb2
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> Lb2
            r6.<init>(r0)     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.core.Timestamps r0 = androidx.camera.camera2.pipe.core.Timestamps.INSTANCE     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.core.Timestamps r0 = androidx.camera.camera2.pipe.core.Timestamps.INSTANCE     // Catch: java.lang.Throwable -> Lb2
            androidx.camera.camera2.pipe.core.TimeSource r1 = (androidx.camera.camera2.pipe.core.TimeSource) r1     // Catch: java.lang.Throwable -> Lb2
            long r0 = r1.mo987nowvQl9yQU()     // Catch: java.lang.Throwable -> Lb2
            long r0 = r0 - r2
            long r0 = androidx.camera.camera2.pipe.core.DurationNs.m974constructorimpl(r0)     // Catch: java.lang.Throwable -> Lb2
            java.lang.String r2 = "%.3f ms"
            double r0 = (double) r0     // Catch: java.lang.Throwable -> Lb2
            r7 = 4696837146684686336(0x412e848000000000, double:1000000.0)
            double r0 = r0 / r7
            java.lang.Double r0 = java.lang.Double.valueOf(r0)     // Catch: java.lang.Throwable -> Lb2
            java.lang.Object[] r0 = new java.lang.Object[]{r0}     // Catch: java.lang.Throwable -> Lb2
            r1 = 1
            java.lang.Object[] r0 = java.util.Arrays.copyOf(r0, r1)     // Catch: java.lang.Throwable -> Lb2
            java.lang.String r0 = java.lang.String.format(r15, r2, r0)     // Catch: java.lang.Throwable -> Lb2
            java.lang.String r1 = "format(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)     // Catch: java.lang.Throwable -> Lb2
            r6.append(r0)     // Catch: java.lang.Throwable -> Lb2
            java.lang.String r0 = r6.toString()     // Catch: java.lang.Throwable -> Lb2
            android.util.Log.d(r5, r0)     // Catch: java.lang.Throwable -> Lb2
        Lae:
            android.os.Trace.endSection()
            return r4
        Lb2:
            r0 = move-exception
            android.os.Trace.endSection()
            throw r0
    }

    private static final androidx.camera.camera2.pipe.CameraPipe newInstance$lambda$0(androidx.camera.camera2.adapter.CameraFactoryProvider r1, android.content.Context r2, androidx.camera.core.impl.CameraThreadConfig r3, androidx.camera.camera2.pipe.core.DurationNs r4) {
            androidx.camera.camera2.pipe.CameraPipe r0 = r1.sharedCameraPipe
            if (r0 == 0) goto L2f
            androidx.camera.camera2.impl.Camera2Logger r2 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r2 = "CXCP"
            boolean r2 = androidx.camera.core.Logger.isDebugEnabled(r2)
            if (r2 == 0) goto L2c
            java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "Using shared a "
            r3.<init>(r4)
            androidx.camera.camera2.pipe.CameraPipe r4 = access$getSharedCameraPipe$p(r1)
            r3.append(r4)
            java.lang.String r4 = " instance."
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            android.util.Log.d(r2, r3)
        L2c:
            androidx.camera.camera2.pipe.CameraPipe r1 = r1.sharedCameraPipe
            return r1
        L2f:
            androidx.camera.camera2.pipe.CameraPipe r1 = r1.m59createCameraPipeck8WKOA(r2, r3, r4)
            return r1
    }

    @Override // androidx.camera.core.impl.CameraFactory.Provider
    public androidx.camera.core.impl.CameraFactory newInstance(android.content.Context r9, androidx.camera.core.impl.CameraThreadConfig r10, androidx.camera.core.CameraSelector r11, long r12, androidx.camera.core.CameraXConfig r14, androidx.camera.core.internal.StreamSpecsCalculator r15) {
            r8 = this;
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            java.lang.String r0 = "threadConfig"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            java.lang.String r0 = "streamSpecsCalculator"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r15, r0)
            r0 = -1
            int r0 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r0 != 0) goto L17
            r12 = 0
            goto L1f
        L17:
            long r12 = androidx.camera.camera2.pipe.core.DurationNs.m974constructorimpl(r12)
            androidx.camera.camera2.pipe.core.DurationNs r12 = androidx.camera.camera2.pipe.core.DurationNs.m972boximpl(r12)
        L1f:
            androidx.camera.camera2.adapter.CameraFactoryProvider$$ExternalSyntheticLambda0 r13 = new androidx.camera.camera2.adapter.CameraFactoryProvider$$ExternalSyntheticLambda0
            r13.<init>(r8, r9, r10, r12)
            kotlin.Lazy r1 = kotlin.LazyKt.lazy(r13)
            androidx.camera.camera2.adapter.CameraFactoryAdapter r0 = new androidx.camera.camera2.adapter.CameraFactoryAdapter
            android.content.Context r12 = r8.sharedAppContext
            if (r12 != 0) goto L30
            r2 = r9
            goto L31
        L30:
            r2 = r12
        L31:
            androidx.camera.core.impl.CameraThreadConfig r9 = r8.sharedThreadConfig
            if (r9 != 0) goto L37
            r3 = r10
            goto L38
        L37:
            r3 = r9
        L38:
            androidx.camera.camera2.impl.CameraInteropStateCallbackRepository r4 = r8.sharedInteropCallbacks
            if (r14 != 0) goto L4a
            androidx.camera.core.CameraXConfig$Builder r9 = new androidx.camera.core.CameraXConfig$Builder
            r9.<init>()
            androidx.camera.core.CameraXConfig r14 = r9.build()
            java.lang.String r9 = "build(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r14, r9)
        L4a:
            r5 = r11
            r7 = r14
            r6 = r15
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            androidx.camera.core.impl.CameraFactory r0 = (androidx.camera.core.impl.CameraFactory) r0
            return r0
    }
}
