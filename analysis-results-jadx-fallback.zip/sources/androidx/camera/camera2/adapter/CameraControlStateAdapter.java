package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CameraControlStateAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B)\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r8F¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u0017\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u000e0\r8F¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0010R\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00140\r8F¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0010R\u0011\u0010\u0016\u001a\u00020\u00178F¢\u0006\u0006\u001a\u0004\b\u0018\u0010\u0019R\u0017\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u000e0\r8F¢\u0006\u0006\u001a\u0004\b\u001b\u0010\u0010¨\u0006\u001c"}, d2 = {"Landroidx/camera/camera2/adapter/CameraControlStateAdapter;", "", "zoomControl", "Landroidx/camera/camera2/impl/ZoomControl;", "evCompControl", "Landroidx/camera/camera2/impl/EvCompControl;", "torchControl", "Landroidx/camera/camera2/impl/TorchControl;", "lowLightBoostControl", "Landroidx/camera/camera2/impl/LowLightBoostControl;", "<init>", "(Landroidx/camera/camera2/impl/ZoomControl;Landroidx/camera/camera2/impl/EvCompControl;Landroidx/camera/camera2/impl/TorchControl;Landroidx/camera/camera2/impl/LowLightBoostControl;)V", "torchStateLiveData", "Landroidx/lifecycle/LiveData;", "", "getTorchStateLiveData", "()Landroidx/lifecycle/LiveData;", "torchStrengthLiveData", "getTorchStrengthLiveData", "zoomStateLiveData", "Landroidx/camera/core/ZoomState;", "getZoomStateLiveData", "exposureState", "Landroidx/camera/core/ExposureState;", "getExposureState", "()Landroidx/camera/core/ExposureState;", "lowLightBoostState", "getLowLightBoostState", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraControlStateAdapter {
    private final androidx.camera.camera2.impl.EvCompControl evCompControl;
    private final androidx.camera.camera2.impl.LowLightBoostControl lowLightBoostControl;
    private final androidx.camera.camera2.impl.TorchControl torchControl;
    private final androidx.camera.camera2.impl.ZoomControl zoomControl;

    @javax.inject.Inject
    public CameraControlStateAdapter(androidx.camera.camera2.impl.ZoomControl r2, androidx.camera.camera2.impl.EvCompControl r3, androidx.camera.camera2.impl.TorchControl r4, androidx.camera.camera2.impl.LowLightBoostControl r5) {
            r1 = this;
            java.lang.String r0 = "zoomControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "evCompControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "torchControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "lowLightBoostControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            r1.<init>()
            r1.zoomControl = r2
            r1.evCompControl = r3
            r1.torchControl = r4
            r1.lowLightBoostControl = r5
            return
    }

    public final androidx.camera.core.ExposureState getExposureState() {
            r1 = this;
            androidx.camera.camera2.impl.EvCompControl r0 = r1.evCompControl
            androidx.camera.camera2.adapter.EvCompValue r0 = r0.getExposureState()
            androidx.camera.core.ExposureState r0 = (androidx.camera.core.ExposureState) r0
            return r0
    }

    public final androidx.lifecycle.LiveData<java.lang.Integer> getLowLightBoostState() {
            r1 = this;
            androidx.camera.camera2.impl.LowLightBoostControl r0 = r1.lowLightBoostControl
            androidx.lifecycle.LiveData r0 = r0.getLowLightBoostStateLiveData()
            return r0
    }

    public final androidx.lifecycle.LiveData<java.lang.Integer> getTorchStateLiveData() {
            r1 = this;
            androidx.camera.camera2.impl.TorchControl r0 = r1.torchControl
            androidx.lifecycle.LiveData r0 = r0.getTorchStateLiveData()
            return r0
    }

    public final androidx.lifecycle.LiveData<java.lang.Integer> getTorchStrengthLiveData() {
            r1 = this;
            androidx.camera.camera2.impl.TorchControl r0 = r1.torchControl
            androidx.lifecycle.LiveData r0 = r0.getTorchStrengthLiveData()
            return r0
    }

    public final androidx.lifecycle.LiveData<androidx.camera.core.ZoomState> getZoomStateLiveData() {
            r1 = this;
            androidx.camera.camera2.impl.ZoomControl r0 = r1.zoomControl
            androidx.lifecycle.LiveData r0 = r0.getZoomStateLiveData()
            return r0
    }
}
