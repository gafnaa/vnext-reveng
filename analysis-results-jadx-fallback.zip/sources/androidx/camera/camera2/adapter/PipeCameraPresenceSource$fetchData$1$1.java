package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: PipeCameraPresenceSource.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 1, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.camera.camera2.adapter.PipeCameraPresenceSource$fetchData$1$1", f = "PipeCameraPresenceSource.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
final class PipeCameraPresenceSource$fetchData$1$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.CoroutineScope, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ androidx.concurrent.futures.CallbackToFutureAdapter.Completer<java.util.List<androidx.camera.core.CameraIdentifier>> $completer;
    int label;
    final /* synthetic */ androidx.camera.camera2.adapter.PipeCameraPresenceSource this$0;

    PipeCameraPresenceSource$fetchData$1$1(androidx.camera.camera2.adapter.PipeCameraPresenceSource r1, androidx.concurrent.futures.CallbackToFutureAdapter.Completer<java.util.List<androidx.camera.core.CameraIdentifier>> r2, kotlin.coroutines.Continuation<? super androidx.camera.camera2.adapter.PipeCameraPresenceSource$fetchData$1$1> r3) {
            r0 = this;
            r0.this$0 = r1
            r0.$completer = r2
            r1 = 2
            r0.<init>(r1, r3)
            return
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r3, kotlin.coroutines.Continuation<?> r4) {
            r2 = this;
            androidx.camera.camera2.adapter.PipeCameraPresenceSource$fetchData$1$1 r3 = new androidx.camera.camera2.adapter.PipeCameraPresenceSource$fetchData$1$1
            androidx.camera.camera2.adapter.PipeCameraPresenceSource r0 = r2.this$0
            androidx.concurrent.futures.CallbackToFutureAdapter$Completer<java.util.List<androidx.camera.core.CameraIdentifier>> r1 = r2.$completer
            r3.<init>(r0, r1, r4)
            kotlin.coroutines.Continuation r3 = (kotlin.coroutines.Continuation) r3
            return r3
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
            r0 = this;
            kotlinx.coroutines.CoroutineScope r1 = (kotlinx.coroutines.CoroutineScope) r1
            kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
            java.lang.Object r1 = r0.invoke2(r1, r2)
            return r1
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final java.lang.Object invoke2(kotlinx.coroutines.CoroutineScope r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
            r0 = this;
            kotlin.coroutines.Continuation r1 = r0.create(r1, r2)
            androidx.camera.camera2.adapter.PipeCameraPresenceSource$fetchData$1$1 r1 = (androidx.camera.camera2.adapter.PipeCameraPresenceSource$fetchData$1$1) r1
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            java.lang.Object r1 = r1.invokeSuspend(r2)
            return r1
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object r10) {
            r9 = this;
            java.lang.String r0 = "PipePresenceSrc"
            kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r1 = r9.label
            if (r1 != 0) goto L87
            kotlin.ResultKt.throwOnFailure(r10)
            androidx.camera.camera2.adapter.PipeCameraPresenceSource r10 = r9.this$0     // Catch: java.lang.Exception -> L72
            android.hardware.camera2.CameraManager r10 = androidx.camera.camera2.adapter.PipeCameraPresenceSource.access$getCameraManager$p(r10)     // Catch: java.lang.Exception -> L72
            java.lang.String[] r10 = r10.getCameraIdList()     // Catch: java.lang.Exception -> L72
            java.lang.String r1 = "getCameraIdList(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r10, r1)     // Catch: java.lang.Exception -> L72
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch: java.lang.Exception -> L72
            r1.<init>()     // Catch: java.lang.Exception -> L72
            java.util.Collection r1 = (java.util.Collection) r1     // Catch: java.lang.Exception -> L72
            int r2 = r10.length     // Catch: java.lang.Exception -> L72
            r3 = 0
        L24:
            if (r3 >= r2) goto L51
            r4 = r10[r3]     // Catch: java.lang.Exception -> L72
            r5 = 0
            kotlin.jvm.internal.Intrinsics.checkNotNull(r4)     // Catch: java.lang.IllegalArgumentException -> L32 java.lang.Exception -> L72
            r6 = 6
            androidx.camera.core.CameraIdentifier r5 = androidx.camera.core.CameraIdentifier.Factory.create$default(r4, r5, r5, r6, r5)     // Catch: java.lang.IllegalArgumentException -> L32 java.lang.Exception -> L72
            goto L49
        L32:
            r6 = move-exception
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L72
            r7.<init>()     // Catch: java.lang.Exception -> L72
            java.lang.String r8 = "Could not create CameraIdentifier for system ID: "
            r7.append(r8)     // Catch: java.lang.Exception -> L72
            r7.append(r4)     // Catch: java.lang.Exception -> L72
            java.lang.String r4 = r7.toString()     // Catch: java.lang.Exception -> L72
            java.lang.Throwable r6 = (java.lang.Throwable) r6     // Catch: java.lang.Exception -> L72
            android.util.Log.w(r0, r4, r6)     // Catch: java.lang.Exception -> L72
        L49:
            if (r5 == 0) goto L4e
            r1.add(r5)     // Catch: java.lang.Exception -> L72
        L4e:
            int r3 = r3 + 1
            goto L24
        L51:
            java.util.List r1 = (java.util.List) r1     // Catch: java.lang.Exception -> L72
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L72
            r10.<init>()     // Catch: java.lang.Exception -> L72
            java.lang.String r2 = "[FetchData] Refreshed camera list from hardware: "
            r10.append(r2)     // Catch: java.lang.Exception -> L72
            r10.append(r1)     // Catch: java.lang.Exception -> L72
            java.lang.String r10 = r10.toString()     // Catch: java.lang.Exception -> L72
            android.util.Log.d(r0, r10)     // Catch: java.lang.Exception -> L72
            androidx.camera.camera2.adapter.PipeCameraPresenceSource r10 = r9.this$0     // Catch: java.lang.Exception -> L72
            androidx.camera.camera2.adapter.PipeCameraPresenceSource.access$updateData(r10, r1)     // Catch: java.lang.Exception -> L72
            androidx.concurrent.futures.CallbackToFutureAdapter$Completer<java.util.List<androidx.camera.core.CameraIdentifier>> r10 = r9.$completer     // Catch: java.lang.Exception -> L72
            r10.set(r1)     // Catch: java.lang.Exception -> L72
            goto L84
        L72:
            r10 = move-exception
            java.lang.Throwable r10 = (java.lang.Throwable) r10
            java.lang.String r1 = "[FetchData] Failed to refresh camera list from hardware."
            android.util.Log.e(r0, r1, r10)
            androidx.camera.camera2.adapter.PipeCameraPresenceSource r0 = r9.this$0
            androidx.camera.camera2.adapter.PipeCameraPresenceSource.access$updateError(r0, r10)
            androidx.concurrent.futures.CallbackToFutureAdapter$Completer<java.util.List<androidx.camera.core.CameraIdentifier>> r0 = r9.$completer
            r0.setException(r10)
        L84:
            kotlin.Unit r10 = kotlin.Unit.INSTANCE
            return r10
        L87:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r10.<init>(r0)
            throw r10
    }
}
