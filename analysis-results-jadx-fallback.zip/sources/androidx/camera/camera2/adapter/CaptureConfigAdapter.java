package androidx.camera.camera2.adapter;

/* JADX INFO: compiled from: CaptureConfigAdapter.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000  2\u00020\u0001:\u0001 B1\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b¢\u0006\u0004\b\f\u0010\rJ7\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\u000e\b\u0002\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u001a0\u0019H\u0007¢\u0006\u0004\b\u001b\u0010\u001cJ\u0010\u0010\u001d\u001a\u00020\u001a2\u0006\u0010\u001e\u001a\u00020\u001fH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006!"}, d2 = {"Landroidx/camera/camera2/adapter/CaptureConfigAdapter;", "", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "useCaseGraphContext", "Landroidx/camera/camera2/config/UseCaseGraphContext;", "zslControl", "Landroidx/camera/camera2/adapter/ZslControl;", "threads", "Landroidx/camera/camera2/impl/UseCaseThreads;", "templateParamsOverride", "Landroidx/camera/camera2/compat/workaround/TemplateParamsOverride;", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;Landroidx/camera/camera2/config/UseCaseGraphContext;Landroidx/camera/camera2/adapter/ZslControl;Landroidx/camera/camera2/impl/UseCaseThreads;Landroidx/camera/camera2/compat/workaround/TemplateParamsOverride;)V", "isLegacyDevice", "", "mapToRequest", "Landroidx/camera/camera2/pipe/Request;", "captureConfig", "Landroidx/camera/core/impl/CaptureConfig;", "requestTemplate", "Landroidx/camera/camera2/pipe/RequestTemplate;", "sessionConfigOptions", "Landroidx/camera/core/impl/Config;", "additionalListeners", "", "Landroidx/camera/camera2/pipe/Request$Listener;", "mapToRequest-nAberiA", "(Landroidx/camera/core/impl/CaptureConfig;ILandroidx/camera/core/impl/Config;Ljava/util/List;)Landroidx/camera/camera2/pipe/Request;", "buildImageClosingRequestListener", "imageProxy", "Landroidx/camera/core/ImageProxy;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
@androidx.camera.camera2.config.UseCaseCameraScope
public final class CaptureConfigAdapter {
    public static final androidx.camera.camera2.adapter.CaptureConfigAdapter.Companion Companion = null;
    private final boolean isLegacyDevice;
    private final androidx.camera.camera2.compat.workaround.TemplateParamsOverride templateParamsOverride;
    private final androidx.camera.camera2.impl.UseCaseThreads threads;
    private final androidx.camera.camera2.config.UseCaseGraphContext useCaseGraphContext;
    private final androidx.camera.camera2.adapter.ZslControl zslControl;

    /* JADX INFO: compiled from: CaptureConfigAdapter.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J#\u0010\u0004\u001a\u00020\u0005*\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\tH\u0000¢\u0006\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"Landroidx/camera/camera2/adapter/CaptureConfigAdapter$Companion;", "", "<init>", "()V", "getStillCaptureTemplate", "Landroidx/camera/camera2/pipe/RequestTemplate;", "Landroidx/camera/core/impl/CaptureConfig;", "sessionTemplate", "isLegacyDevice", "", "getStillCaptureTemplate-CMLptTo$camera_camera2", "(Landroidx/camera/core/impl/CaptureConfig;IZ)I", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        /* JADX INFO: renamed from: getStillCaptureTemplate-CMLptTo$camera_camera2, reason: not valid java name */
        public final int m68getStillCaptureTemplateCMLptTo$camera_camera2(androidx.camera.core.impl.CaptureConfig r2, int r3, boolean r4) {
                r1 = this;
                java.lang.String r0 = "$this$getStillCaptureTemplate"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                r0 = 3
                int r0 = androidx.camera.camera2.pipe.RequestTemplate.m739constructorimpl(r0)
                boolean r3 = androidx.camera.camera2.pipe.RequestTemplate.m741equalsimpl0(r3, r0)
                r0 = -1
                if (r3 == 0) goto L15
                if (r4 != 0) goto L15
                r3 = 4
                goto L26
            L15:
                int r3 = r2.getTemplateType()
                if (r3 == r0) goto L25
                int r3 = r2.getTemplateType()
                r4 = 5
                if (r3 != r4) goto L23
                goto L25
            L23:
                r3 = r0
                goto L26
            L25:
                r3 = 2
            L26:
                if (r3 == r0) goto L2d
                int r2 = androidx.camera.camera2.pipe.RequestTemplate.m739constructorimpl(r3)
                return r2
            L2d:
                int r2 = r2.getTemplateType()
                int r2 = androidx.camera.camera2.pipe.RequestTemplate.m739constructorimpl(r2)
                return r2
        }
    }


    static {
            androidx.camera.camera2.adapter.CaptureConfigAdapter$Companion r0 = new androidx.camera.camera2.adapter.CaptureConfigAdapter$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.adapter.CaptureConfigAdapter.Companion = r0
            return
    }

    @javax.inject.Inject
    public CaptureConfigAdapter(androidx.camera.camera2.impl.CameraProperties r2, androidx.camera.camera2.config.UseCaseGraphContext r3, androidx.camera.camera2.adapter.ZslControl r4, androidx.camera.camera2.impl.UseCaseThreads r5, androidx.camera.camera2.compat.workaround.TemplateParamsOverride r6) {
            r1 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "useCaseGraphContext"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "zslControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "threads"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "templateParamsOverride"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            r1.<init>()
            r1.useCaseGraphContext = r3
            r1.zslControl = r4
            r1.threads = r5
            r1.templateParamsOverride = r6
            androidx.camera.camera2.pipe.CameraMetadata$Companion r3 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.pipe.CameraMetadata r2 = r2.getMetadata()
            boolean r2 = r3.isHardwareLevelLegacy(r2)
            r1.isLegacyDevice = r2
            return
    }

    public static final /* synthetic */ void access$buildImageClosingRequestListener$closeImageProxy(java.util.concurrent.atomic.AtomicReference r0) {
            buildImageClosingRequestListener$closeImageProxy(r0)
            return
    }

    private final androidx.camera.camera2.pipe.Request.Listener buildImageClosingRequestListener(androidx.camera.core.ImageProxy r2) {
            r1 = this;
            java.util.concurrent.atomic.AtomicReference r0 = new java.util.concurrent.atomic.AtomicReference
            r0.<init>(r2)
            androidx.camera.camera2.adapter.CaptureConfigAdapter$buildImageClosingRequestListener$1 r2 = new androidx.camera.camera2.adapter.CaptureConfigAdapter$buildImageClosingRequestListener$1
            r2.<init>(r0)
            androidx.camera.camera2.pipe.Request$Listener r2 = (androidx.camera.camera2.pipe.Request.Listener) r2
            return r2
    }

    private static final void buildImageClosingRequestListener$closeImageProxy(java.util.concurrent.atomic.AtomicReference<androidx.camera.core.ImageProxy> r1) {
            r0 = 0
            java.lang.Object r1 = r1.getAndSet(r0)
            androidx.camera.core.ImageProxy r1 = (androidx.camera.core.ImageProxy) r1
            if (r1 == 0) goto Lc
            r1.close()
        Lc:
            return
    }

    /* JADX INFO: renamed from: mapToRequest-nAberiA$default, reason: not valid java name */
    public static /* synthetic */ androidx.camera.camera2.pipe.Request m66mapToRequestnAberiA$default(androidx.camera.camera2.adapter.CaptureConfigAdapter r0, androidx.camera.core.impl.CaptureConfig r1, int r2, androidx.camera.core.impl.Config r3, java.util.List r4, int r5, java.lang.Object r6) {
            r5 = r5 & 8
            if (r5 == 0) goto L8
            java.util.List r4 = kotlin.collections.CollectionsKt.emptyList()
        L8:
            androidx.camera.camera2.pipe.Request r0 = r0.m67mapToRequestnAberiA(r1, r2, r3, r4)
            return r0
    }

    /* JADX INFO: renamed from: mapToRequest-nAberiA, reason: not valid java name */
    public final androidx.camera.camera2.pipe.Request m67mapToRequestnAberiA(androidx.camera.core.impl.CaptureConfig r9, int r10, androidx.camera.core.impl.Config r11, java.util.List<? extends androidx.camera.camera2.pipe.Request.Listener> r12) {
            r8 = this;
            java.lang.String r0 = "captureConfig"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            java.lang.String r0 = "sessionConfigOptions"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            java.lang.String r0 = "additionalListeners"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r12, r0)
            java.util.List r0 = r9.getSurfaces()
            java.lang.String r1 = "getSurfaces(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r1 = r0
            java.util.Collection r1 = (java.util.Collection) r1
            boolean r1 = r1.isEmpty()
            if (r1 != 0) goto L1dd
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.ArrayList r1 = new java.util.ArrayList
            r2 = 10
            int r2 = kotlin.collections.CollectionsKt.collectionSizeOrDefault(r0, r2)
            r1.<init>(r2)
            java.util.Collection r1 = (java.util.Collection) r1
            java.util.Iterator r0 = r0.iterator()
        L34:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L72
            java.lang.Object r2 = r0.next()
            androidx.camera.core.impl.DeferrableSurface r2 = (androidx.camera.core.impl.DeferrableSurface) r2
            androidx.camera.camera2.config.UseCaseGraphContext r3 = r8.useCaseGraphContext
            java.util.Map r3 = r3.getSurfaceToStreamMap()
            java.lang.Object r3 = r3.get(r2)
            if (r3 == 0) goto L5a
            androidx.camera.camera2.pipe.StreamId r3 = (androidx.camera.camera2.pipe.StreamId) r3
            int r2 = r3.m821unboximpl()
            androidx.camera.camera2.pipe.StreamId r2 = androidx.camera.camera2.pipe.StreamId.m815boximpl(r2)
            r1.add(r2)
            goto L34
        L5a:
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r10 = "Attempted to issue a capture with an unrecognized surface: "
            r9.<init>(r10)
            r9.append(r2)
            java.lang.String r9 = r9.toString()
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r9 = r9.toString()
            r10.<init>(r9)
            throw r10
        L72:
            java.util.List r1 = (java.util.List) r1
            androidx.camera.camera2.impl.CameraCallbackMap r0 = new androidx.camera.camera2.impl.CameraCallbackMap
            r0.<init>()
            java.util.List r2 = r9.getCameraCaptureCallbacks()
            java.lang.String r3 = "getCameraCaptureCallbacks(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
            java.lang.Iterable r2 = (java.lang.Iterable) r2
            java.util.Iterator r2 = r2.iterator()
        L88:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto La1
            java.lang.Object r3 = r2.next()
            androidx.camera.core.impl.CameraCaptureCallback r3 = (androidx.camera.core.impl.CameraCaptureCallback) r3
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3)
            androidx.camera.camera2.impl.UseCaseThreads r4 = r8.threads
            java.util.concurrent.Executor r4 = r4.getSequentialExecutor()
            r0.addCaptureCallback(r3, r4)
            goto L88
        La1:
            androidx.camera.core.impl.Config r2 = r9.getImplementationOptions()
            java.lang.String r3 = "getImplementationOptions(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
            androidx.camera.camera2.impl.Camera2ImplConfig$Builder r3 = new androidx.camera.camera2.impl.Camera2ImplConfig$Builder
            r3.<init>()
            r3.insertAllOptions(r11)
            r3.insertAllOptions(r2)
            androidx.camera.core.impl.Config$Option<java.lang.Integer> r11 = androidx.camera.core.impl.CaptureConfig.OPTION_ROTATION
            boolean r11 = r2.containsOption(r11)
            if (r11 == 0) goto Ld0
            android.hardware.camera2.CaptureRequest$Key r11 = android.hardware.camera2.CaptureRequest.JPEG_ORIENTATION
            java.lang.String r4 = "JPEG_ORIENTATION"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r4)
            androidx.camera.core.impl.Config$Option<java.lang.Integer> r4 = androidx.camera.core.impl.CaptureConfig.OPTION_ROTATION
            java.lang.Object r4 = r2.retrieveOption(r4)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r4)
            r3.setCaptureRequestOption(r11, r4)
        Ld0:
            androidx.camera.core.impl.Config$Option<java.lang.Integer> r11 = androidx.camera.core.impl.CaptureConfig.OPTION_JPEG_QUALITY
            boolean r11 = r2.containsOption(r11)
            if (r11 == 0) goto Lf6
            android.hardware.camera2.CaptureRequest$Key r11 = android.hardware.camera2.CaptureRequest.JPEG_QUALITY
            java.lang.String r4 = "JPEG_QUALITY"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r11, r4)
            androidx.camera.core.impl.Config$Option<java.lang.Integer> r4 = androidx.camera.core.impl.CaptureConfig.OPTION_JPEG_QUALITY
            java.lang.Object r2 = r2.retrieveOption(r4)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2)
            java.lang.Number r2 = (java.lang.Number) r2
            int r2 = r2.intValue()
            byte r2 = (byte) r2
            java.lang.Byte r2 = java.lang.Byte.valueOf(r2)
            r3.setCaptureRequestOption(r11, r2)
        Lf6:
            int r11 = r9.getTemplateType()
            int r11 = androidx.camera.camera2.pipe.RequestTemplate.m739constructorimpl(r11)
            int r2 = r9.getTemplateType()
            r4 = 5
            r5 = 0
            if (r2 != r4) goto L18a
            androidx.camera.camera2.adapter.ZslControl r2 = r8.zslControl
            boolean r2 = r2.isZslDisabledByUserCaseConfig()
            if (r2 != 0) goto L18a
            androidx.camera.camera2.adapter.ZslControl r2 = r8.zslControl
            boolean r2 = r2.isZslDisabledByFlashMode()
            if (r2 != 0) goto L18a
            androidx.camera.camera2.adapter.ZslControl r2 = r8.zslControl
            androidx.camera.core.ImageProxy r2 = r2.dequeueImageFromBuffer()
            if (r2 == 0) goto L18a
            androidx.camera.core.ImageInfo r4 = r2.getImageInfo()
            androidx.camera.core.impl.CameraCaptureResult r4 = androidx.camera.core.impl.CameraCaptureResults.retrieveCameraCaptureResult(r4)
            if (r4 == 0) goto L186
            boolean r5 = r4 instanceof androidx.camera.camera2.adapter.CaptureResultAdapter
            if (r5 == 0) goto L16a
            androidx.camera.camera2.pipe.media.AndroidImage r5 = new androidx.camera.camera2.pipe.media.AndroidImage
            android.media.Image r6 = r2.getImage()
            java.lang.String r7 = "Required value was null."
            if (r6 == 0) goto L160
            r5.<init>(r6)
            androidx.camera.camera2.adapter.CaptureResultAdapter r4 = (androidx.camera.camera2.adapter.CaptureResultAdapter) r4
            java.lang.Class<androidx.camera.camera2.pipe.FrameInfo> r6 = androidx.camera.camera2.pipe.FrameInfo.class
            kotlin.reflect.KClass r6 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r6)
            java.lang.Object r4 = r4.unwrapAs(r6)
            if (r4 == 0) goto L156
            androidx.camera.camera2.pipe.FrameInfo r4 = (androidx.camera.camera2.pipe.FrameInfo) r4
            androidx.camera.camera2.pipe.InputRequest r6 = new androidx.camera.camera2.pipe.InputRequest
            androidx.camera.camera2.pipe.media.ImageWrapper r5 = (androidx.camera.camera2.pipe.media.ImageWrapper) r5
            r6.<init>(r5, r4)
            androidx.camera.camera2.pipe.Request$Listener r2 = r8.buildImageClosingRequestListener(r2)
            r5 = r6
            goto L187
        L156:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = r7.toString()
            r9.<init>(r10)
            throw r9
        L160:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = r7.toString()
            r9.<init>(r10)
            throw r9
        L16a:
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r10 = "Unexpected capture result type: "
            r9.<init>(r10)
            java.lang.Class r10 = r4.getClass()
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r9 = r9.toString()
            r10.<init>(r9)
            throw r10
        L186:
            r2 = r5
        L187:
            r6 = r5
            r5 = r2
            goto L18b
        L18a:
            r6 = r5
        L18b:
            if (r6 != 0) goto L195
            androidx.camera.camera2.adapter.CaptureConfigAdapter$Companion r11 = androidx.camera.camera2.adapter.CaptureConfigAdapter.Companion
            boolean r2 = r8.isLegacyDevice
            int r11 = r11.m68getStillCaptureTemplateCMLptTo$camera_camera2(r9, r10, r2)
        L195:
            androidx.camera.camera2.compat.workaround.TemplateParamsOverride r10 = r8.templateParamsOverride
            androidx.camera.camera2.pipe.RequestTemplate r2 = androidx.camera.camera2.pipe.RequestTemplate.m738boximpl(r11)
            java.util.Map r10 = r10.mo113getOverrideParamsxlOpshk(r2)
            androidx.camera.camera2.impl.Camera2ImplConfig r2 = r3.build()
            androidx.camera.core.impl.Config r2 = (androidx.camera.core.impl.Config) r2
            java.util.Map r2 = androidx.camera.camera2.impl.Camera2ImplConfigKt.toParameters(r2)
            java.util.Map r2 = kotlin.collections.MapsKt.plus(r10, r2)
            java.util.List r10 = kotlin.collections.CollectionsKt.createListBuilder()
            r10.add(r0)
            if (r5 == 0) goto L1b9
            r10.add(r5)
        L1b9:
            java.util.Collection r12 = (java.util.Collection) r12
            r10.addAll(r12)
            java.util.List r4 = kotlin.collections.CollectionsKt.build(r10)
            androidx.camera.camera2.pipe.Metadata$Key r10 = androidx.camera.camera2.impl.TagsKt.getCAMERAX_TAG_BUNDLE()
            androidx.camera.core.impl.TagBundle r9 = r9.getTagBundle()
            kotlin.Pair r9 = kotlin.TuplesKt.to(r10, r9)
            java.util.Map r3 = kotlin.collections.MapsKt.mapOf(r9)
            androidx.camera.camera2.pipe.Request r0 = new androidx.camera.camera2.pipe.Request
            androidx.camera.camera2.pipe.RequestTemplate r5 = androidx.camera.camera2.pipe.RequestTemplate.m738boximpl(r11)
            r7 = 0
            r0.<init>(r1, r2, r3, r4, r5, r6, r7)
            return r0
        L1dd:
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            java.lang.String r11 = "Attempted to issue a capture without surfaces using "
            r10.<init>(r11)
            r10.append(r9)
            java.lang.String r9 = r10.toString()
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r9 = r9.toString()
            r10.<init>(r9)
            throw r10
    }
}
