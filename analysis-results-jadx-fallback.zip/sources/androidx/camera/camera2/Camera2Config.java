package androidx.camera.camera2;

/* JADX INFO: compiled from: Camera2Config.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0005\u0018\u0000 \u00052\u00020\u0001:\u0002\u0004\u0005B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0006"}, d2 = {"Landroidx/camera/camera2/Camera2Config;", "", "<init>", "()V", "DefaultProvider", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class Camera2Config {
    public static final androidx.camera.camera2.Camera2Config.Companion Companion = null;

    /* JADX INFO: compiled from: Camera2Config.kt */
    @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0007J,\u0010\u0006\u001a\u00020\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0007¨\u0006\r"}, d2 = {"Landroidx/camera/camera2/Camera2Config$Companion;", "", "<init>", "()V", "defaultConfig", "Landroidx/camera/core/CameraXConfig;", "from", "sharedCameraPipe", "Landroidx/camera/camera2/pipe/CameraPipe;", "sharedAppContext", "Landroid/content/Context;", "sharedThreadConfig", "Landroidx/camera/core/impl/CameraThreadConfig;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public static /* synthetic */ androidx.camera.core.CameraXConfig from$default(androidx.camera.camera2.Camera2Config.Companion r1, androidx.camera.camera2.pipe.CameraPipe r2, android.content.Context r3, androidx.camera.core.impl.CameraThreadConfig r4, int r5, java.lang.Object r6) {
                r6 = r5 & 1
                r0 = 0
                if (r6 == 0) goto L6
                r2 = r0
            L6:
                r6 = r5 & 2
                if (r6 == 0) goto Lb
                r3 = r0
            Lb:
                r5 = r5 & 4
                if (r5 == 0) goto L10
                r4 = r0
            L10:
                androidx.camera.core.CameraXConfig r1 = r1.from(r2, r3, r4)
                return r1
        }

        @kotlin.jvm.JvmStatic
        public final androidx.camera.core.CameraXConfig defaultConfig() {
                r6 = this;
                r4 = 7
                r5 = 0
                r1 = 0
                r2 = 0
                r3 = 0
                r0 = r6
                androidx.camera.core.CameraXConfig r1 = from$default(r0, r1, r2, r3, r4, r5)
                return r1
        }

        @kotlin.jvm.JvmStatic
        public final androidx.camera.core.CameraXConfig from(androidx.camera.camera2.pipe.CameraPipe r2, android.content.Context r3, androidx.camera.core.impl.CameraThreadConfig r4) {
                r1 = this;
                androidx.camera.camera2.adapter.CameraFactoryProvider r0 = new androidx.camera.camera2.adapter.CameraFactoryProvider
                r0.<init>(r2, r3, r4)
                androidx.camera.core.CameraXConfig$Builder r2 = new androidx.camera.core.CameraXConfig$Builder
                r2.<init>()
                androidx.camera.core.impl.CameraFactory$Provider r0 = (androidx.camera.core.impl.CameraFactory.Provider) r0
                androidx.camera.core.CameraXConfig$Builder r2 = r2.setCameraFactoryProvider(r0)
                androidx.camera.camera2.Camera2Config$Companion$$ExternalSyntheticLambda0 r3 = new androidx.camera.camera2.Camera2Config$Companion$$ExternalSyntheticLambda0
                r3.<init>()
                androidx.camera.core.CameraXConfig$Builder r2 = r2.setDeviceSurfaceManagerProvider(r3)
                androidx.camera.camera2.Camera2Config$Companion$$ExternalSyntheticLambda1 r3 = new androidx.camera.camera2.Camera2Config$Companion$$ExternalSyntheticLambda1
                r3.<init>()
                androidx.camera.core.CameraXConfig$Builder r2 = r2.setUseCaseConfigFactoryProvider(r3)
                r3 = 1
                androidx.camera.core.CameraXConfig$Builder r2 = r2.setRepeatingStreamForced(r3)
                androidx.camera.core.CameraXConfig r2 = r2.build()
                java.lang.String r3 = "build(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r2, r3)
                return r2
        }
    }

    /* JADX INFO: compiled from: Camera2Config.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0006"}, d2 = {"Landroidx/camera/camera2/Camera2Config$DefaultProvider;", "Landroidx/camera/core/CameraXConfig$Provider;", "<init>", "()V", "getCameraXConfig", "Landroidx/camera/core/CameraXConfig;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class DefaultProvider implements androidx.camera.core.CameraXConfig.Provider {
        public DefaultProvider() {
                r0 = this;
                r0.<init>()
                return
        }

        @Override // androidx.camera.core.CameraXConfig.Provider
        public androidx.camera.core.CameraXConfig getCameraXConfig() {
                r1 = this;
                androidx.camera.camera2.Camera2Config$Companion r0 = androidx.camera.camera2.Camera2Config.Companion
                androidx.camera.core.CameraXConfig r0 = r0.defaultConfig()
                return r0
        }
    }

    static {
            androidx.camera.camera2.Camera2Config$Companion r0 = new androidx.camera.camera2.Camera2Config$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.Camera2Config.Companion = r0
            return
    }

    private Camera2Config() {
            r0 = this;
            r0.<init>()
            return
    }

    @kotlin.jvm.JvmStatic
    public static final androidx.camera.core.CameraXConfig defaultConfig() {
            androidx.camera.camera2.Camera2Config$Companion r0 = androidx.camera.camera2.Camera2Config.Companion
            androidx.camera.core.CameraXConfig r0 = r0.defaultConfig()
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final androidx.camera.core.CameraXConfig from(androidx.camera.camera2.pipe.CameraPipe r1, android.content.Context r2, androidx.camera.core.impl.CameraThreadConfig r3) {
            androidx.camera.camera2.Camera2Config$Companion r0 = androidx.camera.camera2.Camera2Config.Companion
            androidx.camera.core.CameraXConfig r1 = r0.from(r1, r2, r3)
            return r1
    }
}
