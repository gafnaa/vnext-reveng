package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: StreamConfigurationMapCompatBaseImpl.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0011\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\t\n\u0002\b\u0002\b\u0010\u0018\u00002\u00020\u0001B\u0011\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0015\u0010\b\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\tH\u0016¢\u0006\u0002\u0010\u000bJ\u001d\u0010\f\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\t2\u0006\u0010\u000e\u001a\u00020\nH\u0016¢\u0006\u0002\u0010\u000fJ)\u0010\f\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\t\"\u0004\b\u0000\u0010\u00102\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u0002H\u00100\u0012H\u0016¢\u0006\u0002\u0010\u0013J\u001d\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\t2\u0006\u0010\u000e\u001a\u00020\nH\u0016¢\u0006\u0002\u0010\u000fJ\u001b\u0010\u0015\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\u0016\u0018\u00010\tH\u0016¢\u0006\u0002\u0010\u0017J#\u0010\u0018\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\u0016\u0018\u00010\t2\u0006\u0010\u0019\u001a\u00020\rH\u0016¢\u0006\u0002\u0010\u001aJ\u0015\u0010\u001b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\tH\u0016¢\u0006\u0002\u0010\u001cJ#\u0010\u001d\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\t2\f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\n0\u0016H\u0016¢\u0006\u0002\u0010\u001fJ\u0018\u0010 \u001a\u00020!2\u0006\u0010\u000e\u001a\u00020\n2\u0006\u0010\u0019\u001a\u00020\rH\u0016J\n\u0010\"\u001a\u0004\u0018\u00010\u0003H\u0016R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006#"}, d2 = {"Landroidx/camera/camera2/compat/StreamConfigurationMapCompatBaseImpl;", "Landroidx/camera/camera2/compat/StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl;", "streamConfigurationMap", "Landroid/hardware/camera2/params/StreamConfigurationMap;", "<init>", "(Landroid/hardware/camera2/params/StreamConfigurationMap;)V", "getStreamConfigurationMap", "()Landroid/hardware/camera2/params/StreamConfigurationMap;", "getOutputFormats", "", "", "()[Ljava/lang/Integer;", "getOutputSizes", "Landroid/util/Size;", "format", "(I)[Landroid/util/Size;", "T", "klass", "Ljava/lang/Class;", "(Ljava/lang/Class;)[Landroid/util/Size;", "getHighResolutionOutputSizes", "getHighSpeedVideoFpsRanges", "Landroid/util/Range;", "()[Landroid/util/Range;", "getHighSpeedVideoFpsRangesFor", "size", "(Landroid/util/Size;)[Landroid/util/Range;", "getHighSpeedVideoSizes", "()[Landroid/util/Size;", "getHighSpeedVideoSizesFor", "fpsRange", "(Landroid/util/Range;)[Landroid/util/Size;", "getOutputMinFrameDuration", "", "unwrap", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public class StreamConfigurationMapCompatBaseImpl implements androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl {
    private final android.hardware.camera2.params.StreamConfigurationMap streamConfigurationMap;

    public StreamConfigurationMapCompatBaseImpl(android.hardware.camera2.params.StreamConfigurationMap r1) {
            r0 = this;
            r0.<init>()
            r0.streamConfigurationMap = r1
            return
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.util.Size[] getHighResolutionOutputSizes(int r2) {
            r1 = this;
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            if (r0 == 0) goto L9
            android.util.Size[] r2 = r0.getHighResolutionOutputSizes(r2)
            return r2
        L9:
            r2 = 0
            return r2
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.util.Range<java.lang.Integer>[] getHighSpeedVideoFpsRanges() {
            r1 = this;
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            if (r0 == 0) goto L9
            android.util.Range[] r0 = r0.getHighSpeedVideoFpsRanges()
            return r0
        L9:
            r0 = 0
            return r0
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.util.Range<java.lang.Integer>[] getHighSpeedVideoFpsRangesFor(android.util.Size r2) {
            r1 = this;
            java.lang.String r0 = "size"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            if (r0 == 0) goto Le
            android.util.Range[] r2 = r0.getHighSpeedVideoFpsRangesFor(r2)
            return r2
        Le:
            r2 = 0
            return r2
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.util.Size[] getHighSpeedVideoSizes() {
            r1 = this;
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            if (r0 == 0) goto L9
            android.util.Size[] r0 = r0.getHighSpeedVideoSizes()
            return r0
        L9:
            r0 = 0
            return r0
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.util.Size[] getHighSpeedVideoSizesFor(android.util.Range<java.lang.Integer> r2) {
            r1 = this;
            java.lang.String r0 = "fpsRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            if (r0 == 0) goto Le
            android.util.Size[] r2 = r0.getHighSpeedVideoSizesFor(r2)
            return r2
        Le:
            r2 = 0
            return r2
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public java.lang.Integer[] getOutputFormats() {
            r4 = this;
            java.lang.String r0 = "Failed to get output formats from StreamConfigurationMap"
            java.lang.String r1 = "StreamConfigurationMapCompatBaseImpl"
            r2 = 0
            android.hardware.camera2.params.StreamConfigurationMap r3 = r4.streamConfigurationMap     // Catch: java.lang.IllegalArgumentException -> Le java.lang.NullPointerException -> L15
            if (r3 == 0) goto L1b
            int[] r0 = r3.getOutputFormats()     // Catch: java.lang.IllegalArgumentException -> Le java.lang.NullPointerException -> L15
            goto L1c
        Le:
            r3 = move-exception
            java.lang.Throwable r3 = (java.lang.Throwable) r3
            androidx.camera.core.Logger.w(r1, r0, r3)
            goto L1b
        L15:
            r3 = move-exception
            java.lang.Throwable r3 = (java.lang.Throwable) r3
            androidx.camera.core.Logger.w(r1, r0, r3)
        L1b:
            r0 = r2
        L1c:
            if (r0 == 0) goto L22
            java.lang.Integer[] r2 = kotlin.collections.ArraysKt.toTypedArray(r0)
        L22:
            return r2
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public long getOutputMinFrameDuration(int r2, android.util.Size r3) {
            r1 = this;
            java.lang.String r0 = "size"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            if (r0 == 0) goto Le
            long r2 = r0.getOutputMinFrameDuration(r2, r3)
            return r2
        Le:
            r2 = 0
            return r2
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.util.Size[] getOutputSizes(int r2) {
            r1 = this;
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            if (r0 == 0) goto L9
            android.util.Size[] r2 = r0.getOutputSizes(r2)
            return r2
        L9:
            r2 = 0
            return r2
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public <T> android.util.Size[] getOutputSizes(java.lang.Class<T> r2) {
            r1 = this;
            java.lang.String r0 = "klass"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            if (r0 == 0) goto L11
            android.util.Size[] r2 = r0.getOutputSizes(r2)
            if (r2 != 0) goto L10
            goto L11
        L10:
            return r2
        L11:
            r2 = 0
            android.util.Size[] r2 = new android.util.Size[r2]
            return r2
    }

    public final android.hardware.camera2.params.StreamConfigurationMap getStreamConfigurationMap() {
            r1 = this;
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            return r0
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.hardware.camera2.params.StreamConfigurationMap unwrap() {
            r1 = this;
            android.hardware.camera2.params.StreamConfigurationMap r0 = r1.streamConfigurationMap
            return r0
    }
}
