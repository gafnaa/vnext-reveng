package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: StreamConfigurationMapCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010%\n\u0002\u0010\b\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\t\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001:\u0001+B\u001b\b\u0007\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0013\u0010\u0014\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\r¢\u0006\u0002\u0010\u0015J\u001b\u0010\u0016\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r2\u0006\u0010\u0017\u001a\u00020\f¢\u0006\u0002\u0010\u0018J'\u0010\u0016\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r\"\u0004\b\u0000\u0010\u00192\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u0002H\u00190\u0011¢\u0006\u0002\u0010\u001bJ\u001b\u0010\u001c\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r2\u0006\u0010\u0017\u001a\u00020\f¢\u0006\u0002\u0010\u0018J\u0019\u0010\u001d\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u001e\u0018\u00010\r¢\u0006\u0002\u0010\u001fJ!\u0010 \u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u001e\u0018\u00010\r2\u0006\u0010!\u001a\u00020\u000e¢\u0006\u0002\u0010\"J\u0013\u0010#\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r¢\u0006\u0002\u0010$J!\u0010%\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r2\f\u0010&\u001a\b\u0012\u0004\u0012\u00020\f0\u001e¢\u0006\u0002\u0010'J\u0016\u0010(\u001a\u00020)2\u0006\u0010\u0017\u001a\u00020\f2\u0006\u0010!\u001a\u00020\u000eJ\b\u0010*\u001a\u0004\u0018\u00010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082D¢\u0006\u0002\n\u0000R \u0010\n\u001a\u0014\u0012\u0004\u0012\u00020\f\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0\r0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\"\u0010\u000f\u001a\u0016\u0012\u0004\u0012\u00020\f\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R$\u0010\u0010\u001a\u0018\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0011\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0\r0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006,"}, d2 = {"Landroidx/camera/camera2/compat/StreamConfigurationMapCompat;", "", "map", "Landroid/hardware/camera2/params/StreamConfigurationMap;", "outputSizesCorrector", "Landroidx/camera/camera2/compat/workaround/OutputSizesCorrector;", "<init>", "(Landroid/hardware/camera2/params/StreamConfigurationMap;Landroidx/camera/camera2/compat/workaround/OutputSizesCorrector;)V", "tag", "", "cachedFormatOutputSizes", "", "", "", "Landroid/util/Size;", "cachedFormatHighResolutionOutputSizes", "cachedClassOutputSizes", "Ljava/lang/Class;", "impl", "Landroidx/camera/camera2/compat/StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl;", "getOutputFormats", "()[Ljava/lang/Integer;", "getOutputSizes", "format", "(I)[Landroid/util/Size;", "T", "klass", "(Ljava/lang/Class;)[Landroid/util/Size;", "getHighResolutionOutputSizes", "getHighSpeedVideoFpsRanges", "Landroid/util/Range;", "()[Landroid/util/Range;", "getHighSpeedVideoFpsRangesFor", "size", "(Landroid/util/Size;)[Landroid/util/Range;", "getHighSpeedVideoSizes", "()[Landroid/util/Size;", "getHighSpeedVideoSizesFor", "fpsRange", "(Landroid/util/Range;)[Landroid/util/Size;", "getOutputMinFrameDuration", "", "toStreamConfigurationMap", "StreamConfigurationMapCompatImpl", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class StreamConfigurationMapCompat {
    private final java.util.Map<java.lang.Class<?>, android.util.Size[]> cachedClassOutputSizes;
    private final java.util.Map<java.lang.Integer, android.util.Size[]> cachedFormatHighResolutionOutputSizes;
    private final java.util.Map<java.lang.Integer, android.util.Size[]> cachedFormatOutputSizes;
    private androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl impl;
    private final androidx.camera.camera2.compat.workaround.OutputSizesCorrector outputSizesCorrector;
    private final java.lang.String tag;

    /* JADX INFO: compiled from: StreamConfigurationMapCompat.kt */
    @kotlin.Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\b`\u0018\u00002\u00020\u0001J\u0015\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u0003H&¢\u0006\u0002\u0010\u0005J\u001d\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u00032\u0006\u0010\b\u001a\u00020\u0004H&¢\u0006\u0002\u0010\tJ)\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0003\"\u0004\b\u0000\u0010\n2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\n0\fH&¢\u0006\u0002\u0010\rJ\u001d\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u00032\u0006\u0010\b\u001a\u00020\u0004H&¢\u0006\u0002\u0010\tJ\u001b\u0010\u000f\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u0010\u0018\u00010\u0003H&¢\u0006\u0002\u0010\u0011J#\u0010\u0012\u001a\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u0010\u0018\u00010\u00032\u0006\u0010\u0013\u001a\u00020\u0007H&¢\u0006\u0002\u0010\u0014J\u0015\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0003H&¢\u0006\u0002\u0010\u0016J#\u0010\u0017\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u00032\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00040\u0010H&¢\u0006\u0002\u0010\u0019J\u0018\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\b\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0007H&J\n\u0010\u001c\u001a\u0004\u0018\u00010\u001dH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u001eÀ\u0006\u0001"}, d2 = {"Landroidx/camera/camera2/compat/StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl;", "", "getOutputFormats", "", "", "()[Ljava/lang/Integer;", "getOutputSizes", "Landroid/util/Size;", "format", "(I)[Landroid/util/Size;", "T", "klass", "Ljava/lang/Class;", "(Ljava/lang/Class;)[Landroid/util/Size;", "getHighResolutionOutputSizes", "getHighSpeedVideoFpsRanges", "Landroid/util/Range;", "()[Landroid/util/Range;", "getHighSpeedVideoFpsRangesFor", "size", "(Landroid/util/Size;)[Landroid/util/Range;", "getHighSpeedVideoSizes", "()[Landroid/util/Size;", "getHighSpeedVideoSizesFor", "fpsRange", "(Landroid/util/Range;)[Landroid/util/Size;", "getOutputMinFrameDuration", "", "unwrap", "Landroid/hardware/camera2/params/StreamConfigurationMap;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public interface StreamConfigurationMapCompatImpl {
        android.util.Size[] getHighResolutionOutputSizes(int r1);

        android.util.Range<java.lang.Integer>[] getHighSpeedVideoFpsRanges();

        android.util.Range<java.lang.Integer>[] getHighSpeedVideoFpsRangesFor(android.util.Size r1) throws java.lang.IllegalArgumentException;

        android.util.Size[] getHighSpeedVideoSizes();

        android.util.Size[] getHighSpeedVideoSizesFor(android.util.Range<java.lang.Integer> r1) throws java.lang.IllegalArgumentException;

        java.lang.Integer[] getOutputFormats();

        long getOutputMinFrameDuration(int r1, android.util.Size r2);

        android.util.Size[] getOutputSizes(int r1);

        <T> android.util.Size[] getOutputSizes(java.lang.Class<T> r1);

        android.hardware.camera2.params.StreamConfigurationMap unwrap();
    }

    @javax.inject.Inject
    public StreamConfigurationMapCompat(android.hardware.camera2.params.StreamConfigurationMap r2, androidx.camera.camera2.compat.workaround.OutputSizesCorrector r3) {
            r1 = this;
            java.lang.String r0 = "outputSizesCorrector"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r1.<init>()
            r1.outputSizesCorrector = r3
            java.lang.String r3 = "StreamConfigurationMapCompat"
            r1.tag = r3
            java.util.LinkedHashMap r3 = new java.util.LinkedHashMap
            r3.<init>()
            java.util.Map r3 = (java.util.Map) r3
            r1.cachedFormatOutputSizes = r3
            java.util.LinkedHashMap r3 = new java.util.LinkedHashMap
            r3.<init>()
            java.util.Map r3 = (java.util.Map) r3
            r1.cachedFormatHighResolutionOutputSizes = r3
            java.util.LinkedHashMap r3 = new java.util.LinkedHashMap
            r3.<init>()
            java.util.Map r3 = (java.util.Map) r3
            r1.cachedClassOutputSizes = r3
            int r3 = android.os.Build.VERSION.SDK_INT
            r0 = 34
            if (r3 < r0) goto L37
            androidx.camera.camera2.compat.StreamConfigurationMapCompatApi34Impl r3 = new androidx.camera.camera2.compat.StreamConfigurationMapCompatApi34Impl
            r3.<init>(r2)
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r3 = (androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl) r3
            goto L3e
        L37:
            androidx.camera.camera2.compat.StreamConfigurationMapCompatBaseImpl r3 = new androidx.camera.camera2.compat.StreamConfigurationMapCompatBaseImpl
            r3.<init>(r2)
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r3 = (androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl) r3
        L3e:
            r1.impl = r3
            return
    }

    public final android.util.Size[] getHighResolutionOutputSizes(int r4) {
            r3 = this;
            java.util.Map<java.lang.Integer, android.util.Size[]> r0 = r3.cachedFormatHighResolutionOutputSizes
            java.lang.Integer r1 = java.lang.Integer.valueOf(r4)
            boolean r0 = r0.containsKey(r1)
            r1 = 0
            if (r0 == 0) goto L23
            java.util.Map<java.lang.Integer, android.util.Size[]> r0 = r3.cachedFormatHighResolutionOutputSizes
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            java.lang.Object r4 = r0.get(r4)
            android.util.Size[] r4 = (android.util.Size[]) r4
            if (r4 == 0) goto L22
            java.lang.Object r4 = r4.clone()
            android.util.Size[] r4 = (android.util.Size[]) r4
            return r4
        L22:
            return r1
        L23:
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r3.impl
            android.util.Size[] r0 = r0.getHighResolutionOutputSizes(r4)
            if (r0 == 0) goto L35
            int r2 = r0.length
            if (r2 != 0) goto L2f
            goto L35
        L2f:
            androidx.camera.camera2.compat.workaround.OutputSizesCorrector r2 = r3.outputSizesCorrector
            android.util.Size[] r0 = r2.applyQuirks(r0, r4)
        L35:
            java.util.Map<java.lang.Integer, android.util.Size[]> r2 = r3.cachedFormatHighResolutionOutputSizes
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r2.put(r4, r0)
            if (r0 == 0) goto L47
            java.lang.Object r4 = r0.clone()
            android.util.Size[] r4 = (android.util.Size[]) r4
            return r4
        L47:
            return r1
    }

    public final android.util.Range<java.lang.Integer>[] getHighSpeedVideoFpsRanges() {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r1.impl
            android.util.Range[] r0 = r0.getHighSpeedVideoFpsRanges()
            return r0
    }

    public final android.util.Range<java.lang.Integer>[] getHighSpeedVideoFpsRangesFor(android.util.Size r2) throws java.lang.IllegalArgumentException {
            r1 = this;
            java.lang.String r0 = "size"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r1.impl
            android.util.Range[] r2 = r0.getHighSpeedVideoFpsRangesFor(r2)
            return r2
    }

    public final android.util.Size[] getHighSpeedVideoSizes() {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r1.impl
            android.util.Size[] r0 = r0.getHighSpeedVideoSizes()
            return r0
    }

    public final android.util.Size[] getHighSpeedVideoSizesFor(android.util.Range<java.lang.Integer> r2) throws java.lang.IllegalArgumentException {
            r1 = this;
            java.lang.String r0 = "fpsRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r1.impl
            android.util.Size[] r2 = r0.getHighSpeedVideoSizesFor(r2)
            return r2
    }

    public final java.lang.Integer[] getOutputFormats() {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r1.impl
            java.lang.Integer[] r0 = r0.getOutputFormats()
            return r0
    }

    public final long getOutputMinFrameDuration(int r5, android.util.Size r6) {
            r4 = this;
            java.lang.String r0 = "size"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r4.impl     // Catch: java.lang.RuntimeException -> Lc
            long r5 = r0.getOutputMinFrameDuration(r5, r6)     // Catch: java.lang.RuntimeException -> Lc
            return r5
        Lc:
            r0 = move-exception
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.Throwable r0 = (java.lang.Throwable) r0
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isWarnEnabled(r1)
            if (r1 == 0) goto L36
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Unable to get min frame duration for format = "
            r2.<init>(r3)
            r2.append(r5)
            java.lang.String r5 = " and size = "
            r2.append(r5)
            r2.append(r6)
            java.lang.String r5 = r2.toString()
            android.util.Log.w(r1, r5, r0)
        L36:
            r5 = 0
            return r5
    }

    public final android.util.Size[] getOutputSizes(int r6) {
            r5 = this;
            java.util.Map<java.lang.Integer, android.util.Size[]> r0 = r5.cachedFormatOutputSizes
            java.lang.Integer r1 = java.lang.Integer.valueOf(r6)
            boolean r0 = r0.containsKey(r1)
            r1 = 0
            if (r0 == 0) goto L23
            java.util.Map<java.lang.Integer, android.util.Size[]> r0 = r5.cachedFormatOutputSizes
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            java.lang.Object r6 = r0.get(r6)
            android.util.Size[] r6 = (android.util.Size[]) r6
            if (r6 == 0) goto L22
            java.lang.Object r6 = r6.clone()
            android.util.Size[] r6 = (android.util.Size[]) r6
            return r6
        L22:
            return r1
        L23:
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r5.impl     // Catch: java.lang.Throwable -> L2a
            android.util.Size[] r1 = r0.getOutputSizes(r6)     // Catch: java.lang.Throwable -> L2a
            goto L3e
        L2a:
            r0 = move-exception
            java.lang.String r2 = r5.tag
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "Failed to get output sizes for "
            r3.<init>(r4)
            r3.append(r6)
            java.lang.String r3 = r3.toString()
            androidx.camera.core.Logger.w(r2, r3, r0)
        L3e:
            if (r1 == 0) goto L5a
            int r0 = r1.length
            if (r0 != 0) goto L44
            goto L5a
        L44:
            androidx.camera.camera2.compat.workaround.OutputSizesCorrector r0 = r5.outputSizesCorrector
            android.util.Size[] r0 = r0.applyQuirks(r1, r6)
            java.util.Map<java.lang.Integer, android.util.Size[]> r1 = r5.cachedFormatOutputSizes
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r1.put(r6, r0)
            java.lang.Object r6 = r0.clone()
            android.util.Size[] r6 = (android.util.Size[]) r6
            return r6
        L5a:
            java.lang.String r0 = r5.tag
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Retrieved output sizes array is null or empty for format "
            r2.<init>(r3)
            r2.append(r6)
            java.lang.String r6 = r2.toString()
            androidx.camera.core.Logger.w(r0, r6)
            return r1
    }

    public final <T> android.util.Size[] getOutputSizes(java.lang.Class<T> r6) {
            r5 = this;
            java.lang.String r0 = "klass"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.util.Map<java.lang.Class<?>, android.util.Size[]> r0 = r5.cachedClassOutputSizes
            boolean r0 = r0.containsKey(r6)
            r1 = 0
            if (r0 == 0) goto L20
            java.util.Map<java.lang.Class<?>, android.util.Size[]> r0 = r5.cachedClassOutputSizes
            java.lang.Object r6 = r0.get(r6)
            android.util.Size[] r6 = (android.util.Size[]) r6
            if (r6 == 0) goto L1f
            java.lang.Object r6 = r6.clone()
            android.util.Size[] r6 = (android.util.Size[]) r6
            return r6
        L1f:
            return r1
        L20:
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r5.impl     // Catch: java.lang.Throwable -> L27
            android.util.Size[] r1 = r0.getOutputSizes(r6)     // Catch: java.lang.Throwable -> L27
            goto L3b
        L27:
            r0 = move-exception
            java.lang.String r2 = r5.tag
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "Failed to get output sizes for "
            r3.<init>(r4)
            r3.append(r6)
            java.lang.String r3 = r3.toString()
            androidx.camera.core.Logger.w(r2, r3, r0)
        L3b:
            if (r1 == 0) goto L53
            int r0 = r1.length
            if (r0 != 0) goto L41
            goto L53
        L41:
            androidx.camera.camera2.compat.workaround.OutputSizesCorrector r0 = r5.outputSizesCorrector
            android.util.Size[] r0 = r0.applyQuirks(r1, r6)
            java.util.Map<java.lang.Class<?>, android.util.Size[]> r1 = r5.cachedClassOutputSizes
            r1.put(r6, r0)
            java.lang.Object r6 = r0.clone()
            android.util.Size[] r6 = (android.util.Size[]) r6
            return r6
        L53:
            java.lang.String r0 = r5.tag
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Retrieved output sizes array is null or empty for class "
            r2.<init>(r3)
            r2.append(r6)
            java.lang.String r6 = r2.toString()
            androidx.camera.core.Logger.w(r0, r6)
            return r1
    }

    public final android.hardware.camera2.params.StreamConfigurationMap toStreamConfigurationMap() {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat$StreamConfigurationMapCompatImpl r0 = r1.impl
            android.hardware.camera2.params.StreamConfigurationMap r0 = r0.unwrap()
            return r0
    }
}
