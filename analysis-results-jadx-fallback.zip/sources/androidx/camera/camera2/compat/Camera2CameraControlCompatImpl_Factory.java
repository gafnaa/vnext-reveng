package androidx.camera.camera2.compat;

/* JADX INFO: loaded from: classes.dex */
public final class Camera2CameraControlCompatImpl_Factory implements dagger.internal.Factory<androidx.camera.camera2.compat.Camera2CameraControlCompatImpl> {

    private static final class InstanceHolder {
        static final androidx.camera.camera2.compat.Camera2CameraControlCompatImpl_Factory INSTANCE = null;

        static {
                androidx.camera.camera2.compat.Camera2CameraControlCompatImpl_Factory r0 = new androidx.camera.camera2.compat.Camera2CameraControlCompatImpl_Factory
                r0.<init>()
                androidx.camera.camera2.compat.Camera2CameraControlCompatImpl_Factory.InstanceHolder.INSTANCE = r0
                return
        }

        private InstanceHolder() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public Camera2CameraControlCompatImpl_Factory() {
            r0 = this;
            r0.<init>()
            return
    }

    public static androidx.camera.camera2.compat.Camera2CameraControlCompatImpl_Factory create() {
            androidx.camera.camera2.compat.Camera2CameraControlCompatImpl_Factory r0 = androidx.camera.camera2.compat.Camera2CameraControlCompatImpl_Factory.InstanceHolder.INSTANCE
            return r0
    }

    public static androidx.camera.camera2.compat.Camera2CameraControlCompatImpl newInstance() {
            androidx.camera.camera2.compat.Camera2CameraControlCompatImpl r0 = new androidx.camera.camera2.compat.Camera2CameraControlCompatImpl
            r0.<init>()
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.compat.Camera2CameraControlCompatImpl get() {
            r1 = this;
            androidx.camera.camera2.compat.Camera2CameraControlCompatImpl r0 = newInstance()
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.compat.Camera2CameraControlCompatImpl r0 = r1.get()
            return r0
    }
}
