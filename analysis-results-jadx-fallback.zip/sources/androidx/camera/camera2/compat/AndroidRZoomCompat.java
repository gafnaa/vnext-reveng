package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: ZoomCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u001e\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f2\u0006\u0010\u0011\u001a\u00020\u00062\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\u0016\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f2\u0006\u0010\u0012\u001a\u00020\u0013H\u0016J\b\u0010\u0015\u001a\u00020\u0016H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\u00020\u00068VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\f\u001a\u00020\u00068VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\r\u0010\u000b¨\u0006\u0017"}, d2 = {"Landroidx/camera/camera2/compat/AndroidRZoomCompat;", "Landroidx/camera/camera2/compat/ZoomCompat;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "range", "Landroid/util/Range;", "", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;Landroid/util/Range;)V", "minZoomRatio", "getMinZoomRatio", "()F", "maxZoomRatio", "getMaxZoomRatio", "applyAsync", "Lkotlinx/coroutines/Deferred;", "", "zoomRatio", "requestControl", "Landroidx/camera/camera2/impl/UseCaseCameraRequestControl;", "resetAsync", "getCropSensorRegion", "Landroid/graphics/Rect;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class AndroidRZoomCompat implements androidx.camera.camera2.compat.ZoomCompat {
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;
    private final android.util.Range<java.lang.Float> range;

    public AndroidRZoomCompat(androidx.camera.camera2.impl.CameraProperties r2, android.util.Range<java.lang.Float> r3) {
            r1 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "range"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r1.<init>()
            r1.cameraProperties = r2
            r1.range = r3
            return
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public kotlinx.coroutines.Deferred<kotlin.Unit> applyAsync(float r9, androidx.camera.camera2.impl.UseCaseCameraRequestControl r10) {
            r8 = this;
            java.lang.String r0 = "requestControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r10, r0)
            float r0 = r8.getMinZoomRatio()
            float r1 = r8.getMaxZoomRatio()
            int r1 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1))
            if (r1 > 0) goto L4c
            int r0 = (r0 > r9 ? 1 : (r0 == r9 ? 0 : -1))
            if (r0 > 0) goto L4c
            r0 = 1
            kotlin.Pair[] r0 = new kotlin.Pair[r0]
            android.hardware.camera2.CaptureRequest$Key r1 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m15m()
            java.lang.Float r9 = java.lang.Float.valueOf(r9)
            kotlin.Pair r9 = kotlin.TuplesKt.to(r1, r9)
            r1 = 0
            r0[r1] = r9
            java.util.Map r3 = kotlin.collections.MapsKt.mutableMapOf(r0)
            int r9 = android.os.Build.VERSION.SDK_INT
            r0 = 34
            if (r9 < r0) goto L42
            androidx.camera.camera2.pipe.CameraMetadata$Companion r9 = androidx.camera.camera2.pipe.CameraMetadata.Companion
            androidx.camera.camera2.impl.CameraProperties r0 = r8.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            boolean r9 = r9.getSupportsZoomOverride(r0)
            if (r9 == 0) goto L42
            androidx.camera.camera2.compat.Api34Compat.setSettingsOverrideZoom(r3)
        L42:
            r6 = 6
            r7 = 0
            r4 = 0
            r5 = 0
            r2 = r10
            kotlinx.coroutines.Deferred r9 = androidx.camera.camera2.impl.UseCaseCameraRequestControl.setParametersAsync$default(r2, r3, r4, r5, r6, r7)
            return r9
        L4c:
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            java.lang.String r10 = "Failed requirement."
            java.lang.String r10 = r10.toString()
            r9.<init>(r10)
            throw r9
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public android.graphics.Rect getCropSensorRegion() {
            r3 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r3.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE
            java.lang.String r2 = "SENSOR_INFO_ACTIVE_ARRAY_SIZE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            java.lang.Object r0 = r0.get(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            android.graphics.Rect r0 = (android.graphics.Rect) r0
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public float getMaxZoomRatio() {
            r2 = this;
            android.util.Range<java.lang.Float> r0 = r2.range
            java.lang.Comparable r0 = r0.getUpper()
            java.lang.String r1 = "getUpper(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Number r0 = (java.lang.Number) r0
            float r0 = r0.floatValue()
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public float getMinZoomRatio() {
            r2 = this;
            android.util.Range<java.lang.Float> r0 = r2.range
            java.lang.Comparable r0 = r0.getLower()
            java.lang.String r1 = "getLower(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Number r0 = (java.lang.Number) r0
            float r0 = r0.floatValue()
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public kotlinx.coroutines.Deferred<kotlin.Unit> resetAsync(androidx.camera.camera2.impl.UseCaseCameraRequestControl r4) {
            r3 = this;
            java.lang.String r0 = "requestControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            android.hardware.camera2.CaptureRequest$Key r0 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m15m()
            java.lang.String r1 = "CONTROL_ZOOM_RATIO"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            android.hardware.camera2.CaptureRequest$Key[] r0 = new android.hardware.camera2.CaptureRequest.Key[]{r0}
            java.util.List r0 = kotlin.collections.CollectionsKt.mutableListOf(r0)
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 34
            if (r1 < r2) goto L28
            android.hardware.camera2.CaptureRequest$Key r1 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m31m$1()
            java.lang.String r2 = "CONTROL_SETTINGS_OVERRIDE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            r0.add(r1)
        L28:
            r1 = 2
            r2 = 0
            kotlinx.coroutines.Deferred r4 = androidx.camera.camera2.impl.UseCaseCameraRequestControl.removeParametersAsync$default(r4, r0, r2, r1, r2)
            return r4
    }
}
