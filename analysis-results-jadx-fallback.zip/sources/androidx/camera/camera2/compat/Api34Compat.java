package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: ApiCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0000\bÁ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J0\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\rH\u0007J \u0010\u000f\u001a\u00020\u00052\u0016\u0010\u0010\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0012\u0012\u0004\u0012\u00020\u00010\u0011H\u0007¨\u0006\u0013"}, d2 = {"Landroidx/camera/camera2/compat/Api34Compat;", "", "<init>", "()V", "onReadoutStarted", "", "callback", "Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;", "session", "Landroid/hardware/camera2/CameraCaptureSession;", "request", "Landroid/hardware/camera2/CaptureRequest;", "timestamp", "", "frameNumber", "setSettingsOverrideZoom", "parameters", "", "Landroid/hardware/camera2/CaptureRequest$Key;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class Api34Compat {
    public static final androidx.camera.camera2.compat.Api34Compat INSTANCE = null;

    static {
            androidx.camera.camera2.compat.Api34Compat r0 = new androidx.camera.camera2.compat.Api34Compat
            r0.<init>()
            androidx.camera.camera2.compat.Api34Compat.INSTANCE = r0
            return
    }

    private Api34Compat() {
            r0 = this;
            r0.<init>()
            return
    }

    @kotlin.jvm.JvmStatic
    public static final void onReadoutStarted(android.hardware.camera2.CameraCaptureSession.CaptureCallback r1, android.hardware.camera2.CameraCaptureSession r2, android.hardware.camera2.CaptureRequest r3, long r4, long r6) {
            java.lang.String r0 = "callback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            java.lang.String r0 = "session"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "request"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r1, r2, r3, r4, r6)
            return
    }

    @kotlin.jvm.JvmStatic
    public static final void setSettingsOverrideZoom(java.util.Map<android.hardware.camera2.CaptureRequest.Key<?>, java.lang.Object> r2) {
            java.lang.String r0 = "parameters"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            android.hardware.camera2.CaptureRequest$Key r0 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m31m$1()
            r1 = 1
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r2.put(r0, r1)
            return
    }
}
