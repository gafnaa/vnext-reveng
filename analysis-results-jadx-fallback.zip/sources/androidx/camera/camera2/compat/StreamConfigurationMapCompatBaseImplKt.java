package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: StreamConfigurationMapCompatBaseImpl.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u000e\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0002"}, d2 = {"TAG", "", "camera-camera2"}, k = 2, mv = {2, 1, 0}, xi = 48)
public final class StreamConfigurationMapCompatBaseImplKt {
    private static final java.lang.String TAG = "StreamConfigurationMapCompatBaseImpl";
}
