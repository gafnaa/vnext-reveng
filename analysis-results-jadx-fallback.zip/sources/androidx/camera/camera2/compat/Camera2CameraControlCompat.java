package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: Camera2CameraControlCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\bg\u0018\u00002\u00020\u0001:\u0001\u0010J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0005H&J\b\u0010\u0007\u001a\u00020\u0003H&J\b\u0010\b\u001a\u00020\u0003H&J$\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\n2\b\u0010\f\u001a\u0004\u0018\u00010\r2\b\b\u0002\u0010\u000e\u001a\u00020\u000fH&ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0011À\u0006\u0003"}, d2 = {"Landroidx/camera/camera2/compat/Camera2CameraControlCompat;", "Landroidx/camera/camera2/pipe/Request$Listener;", "addRequestOption", "", "bundle", "Landroidx/camera/camera2/interop/CaptureRequestOptions;", "getRequestOption", "clearRequestOption", "cancelCurrentTask", "applyAsync", "Lkotlinx/coroutines/Deferred;", "Ljava/lang/Void;", "requestControl", "Landroidx/camera/camera2/impl/UseCaseCameraRequestControl;", "cancelPreviousTask", "", "Bindings", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public interface Camera2CameraControlCompat extends androidx.camera.camera2.pipe.Request.Listener {

    /* JADX INFO: compiled from: Camera2CameraControlCompat.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b'\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H'¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/Camera2CameraControlCompat$Bindings;", "", "<init>", "()V", "bindCamera2CameraControlCompImpl", "Landroidx/camera/camera2/compat/Camera2CameraControlCompat;", "impl", "Landroidx/camera/camera2/compat/Camera2CameraControlCompatImpl;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    @dagger.Module
    public static abstract class Bindings {
        public Bindings() {
                r0 = this;
                r0.<init>()
                return
        }

        @dagger.Binds
        public abstract androidx.camera.camera2.compat.Camera2CameraControlCompat bindCamera2CameraControlCompImpl(androidx.camera.camera2.compat.Camera2CameraControlCompatImpl r1);
    }

    /* JADX INFO: compiled from: Camera2CameraControlCompat.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final class DefaultImpls {
        public static /* synthetic */ kotlinx.coroutines.Deferred applyAsync$default(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.impl.UseCaseCameraRequestControl r1, boolean r2, int r3, java.lang.Object r4) {
                kotlinx.coroutines.Deferred r0 = androidx.camera.camera2.compat.Camera2CameraControlCompat.applyAsync$default(r0, r1, r2, r3, r4)
                return r0
        }

        @java.lang.Deprecated
        public static void onAborted(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.Request r2) {
                java.lang.String r0 = "request"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.access$onAborted$jd(r1, r2)
                return
        }

        @kotlin.Deprecated(message = "Use the onBufferLost with OutputId.")
        @java.lang.Deprecated
        /* JADX INFO: renamed from: onBufferLost-DlC0U5Y, reason: not valid java name */
        public static void m92onBufferLostDlC0U5Y(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3, int r5) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m83access$onBufferLostDlC0U5Y$jd(r1, r2, r3, r5)
                return
        }

        @java.lang.Deprecated
        /* JADX INFO: renamed from: onBufferLost-iiEMlm4, reason: not valid java name */
        public static void m93onBufferLostiiEMlm4(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3, int r5, int r6) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m84access$onBufferLostiiEMlm4$jd(r1, r2, r3, r5, r6)
                return
        }

        @java.lang.Deprecated
        public static void onCaptureProgress(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, int r3) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.access$onCaptureProgress$jd(r1, r2, r3)
                return
        }

        @java.lang.Deprecated
        /* JADX INFO: renamed from: onComplete-CcXjc1I, reason: not valid java name */
        public static void m94onCompleteCcXjc1I(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3, androidx.camera.camera2.pipe.FrameInfo r5) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "result"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m85access$onCompleteCcXjc1I$jd(r1, r2, r3, r5)
                return
        }

        @java.lang.Deprecated
        /* JADX INFO: renamed from: onFailed-CcXjc1I, reason: not valid java name */
        public static void m95onFailedCcXjc1I(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3, androidx.camera.camera2.pipe.RequestFailure r5) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "requestFailure"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m86access$onFailedCcXjc1I$jd(r1, r2, r3, r5)
                return
        }

        @java.lang.Deprecated
        /* JADX INFO: renamed from: onPartialCaptureResult-CcXjc1I, reason: not valid java name */
        public static void m96onPartialCaptureResultCcXjc1I(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3, androidx.camera.camera2.pipe.FrameMetadata r5) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "captureResult"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m87access$onPartialCaptureResultCcXjc1I$jd(r1, r2, r3, r5)
                return
        }

        @java.lang.Deprecated
        /* JADX INFO: renamed from: onReadoutStarted-mP9r-9w, reason: not valid java name */
        public static void m97onReadoutStartedmP9r9w(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3, long r5) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m88access$onReadoutStartedmP9r9w$jd(r1, r2, r3, r5)
                return
        }

        @java.lang.Deprecated
        public static void onRequestSequenceAborted(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.access$onRequestSequenceAborted$jd(r1, r2)
                return
        }

        @java.lang.Deprecated
        /* JADX INFO: renamed from: onRequestSequenceCompleted-RuT0dZU, reason: not valid java name */
        public static void m98onRequestSequenceCompletedRuT0dZU(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m89access$onRequestSequenceCompletedRuT0dZU$jd(r1, r2, r3)
                return
        }

        @java.lang.Deprecated
        public static void onRequestSequenceCreated(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.access$onRequestSequenceCreated$jd(r1, r2)
                return
        }

        @java.lang.Deprecated
        public static void onRequestSequenceSubmitted(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.access$onRequestSequenceSubmitted$jd(r1, r2)
                return
        }

        @java.lang.Deprecated
        /* JADX INFO: renamed from: onStarted-uGKBvU4, reason: not valid java name */
        public static void m99onStarteduGKBvU4(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3, long r5) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m90access$onStarteduGKBvU4$jd(r1, r2, r3, r5)
                return
        }

        @java.lang.Deprecated
        /* JADX INFO: renamed from: onTotalCaptureResult-CcXjc1I, reason: not valid java name */
        public static void m100onTotalCaptureResultCcXjc1I(androidx.camera.camera2.compat.Camera2CameraControlCompat r1, androidx.camera.camera2.pipe.RequestMetadata r2, long r3, androidx.camera.camera2.pipe.FrameInfo r5) {
                java.lang.String r0 = "requestMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "totalCaptureResult"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
                androidx.camera.camera2.compat.Camera2CameraControlCompat.m91access$onTotalCaptureResultCcXjc1I$jd(r1, r2, r3, r5)
                return
        }
    }

    static /* synthetic */ void access$onAborted$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.Request r1) {
            super.onAborted(r1)
            return
    }

    /* JADX INFO: renamed from: access$onBufferLost-DlC0U5Y$jd, reason: not valid java name */
    static /* synthetic */ void m83access$onBufferLostDlC0U5Y$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2, int r4) {
            super.m720onBufferLostDlC0U5Y(r1, r2, r4)
            return
    }

    /* JADX INFO: renamed from: access$onBufferLost-iiEMlm4$jd, reason: not valid java name */
    static /* synthetic */ void m84access$onBufferLostiiEMlm4$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2, int r4, int r5) {
            super.mo126onBufferLostiiEMlm4(r1, r2, r4, r5)
            return
    }

    static /* synthetic */ void access$onCaptureProgress$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, int r2) {
            super.onCaptureProgress(r1, r2)
            return
    }

    /* JADX INFO: renamed from: access$onComplete-CcXjc1I$jd, reason: not valid java name */
    static /* synthetic */ void m85access$onCompleteCcXjc1I$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2, androidx.camera.camera2.pipe.FrameInfo r4) {
            super.mo69onCompleteCcXjc1I(r1, r2, r4)
            return
    }

    /* JADX INFO: renamed from: access$onFailed-CcXjc1I$jd, reason: not valid java name */
    static /* synthetic */ void m86access$onFailedCcXjc1I$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2, androidx.camera.camera2.pipe.RequestFailure r4) {
            super.mo70onFailedCcXjc1I(r1, r2, r4)
            return
    }

    /* JADX INFO: renamed from: access$onPartialCaptureResult-CcXjc1I$jd, reason: not valid java name */
    static /* synthetic */ void m87access$onPartialCaptureResultCcXjc1I$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2, androidx.camera.camera2.pipe.FrameMetadata r4) {
            super.mo127onPartialCaptureResultCcXjc1I(r1, r2, r4)
            return
    }

    /* JADX INFO: renamed from: access$onReadoutStarted-mP9r-9w$jd, reason: not valid java name */
    static /* synthetic */ void m88access$onReadoutStartedmP9r9w$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2, long r4) {
            super.mo128onReadoutStartedmP9r9w(r1, r2, r4)
            return
    }

    static /* synthetic */ void access$onRequestSequenceAborted$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1) {
            super.onRequestSequenceAborted(r1)
            return
    }

    /* JADX INFO: renamed from: access$onRequestSequenceCompleted-RuT0dZU$jd, reason: not valid java name */
    static /* synthetic */ void m89access$onRequestSequenceCompletedRuT0dZU$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2) {
            super.mo129onRequestSequenceCompletedRuT0dZU(r1, r2)
            return
    }

    static /* synthetic */ void access$onRequestSequenceCreated$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1) {
            super.onRequestSequenceCreated(r1)
            return
    }

    static /* synthetic */ void access$onRequestSequenceSubmitted$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1) {
            super.onRequestSequenceSubmitted(r1)
            return
    }

    /* JADX INFO: renamed from: access$onStarted-uGKBvU4$jd, reason: not valid java name */
    static /* synthetic */ void m90access$onStarteduGKBvU4$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2, long r4) {
            super.mo130onStarteduGKBvU4(r1, r2, r4)
            return
    }

    /* JADX INFO: renamed from: access$onTotalCaptureResult-CcXjc1I$jd, reason: not valid java name */
    static /* synthetic */ void m91access$onTotalCaptureResultCcXjc1I$jd(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.pipe.RequestMetadata r1, long r2, androidx.camera.camera2.pipe.FrameInfo r4) {
            super.mo71onTotalCaptureResultCcXjc1I(r1, r2, r4)
            return
    }

    static /* synthetic */ kotlinx.coroutines.Deferred applyAsync$default(androidx.camera.camera2.compat.Camera2CameraControlCompat r0, androidx.camera.camera2.impl.UseCaseCameraRequestControl r1, boolean r2, int r3, java.lang.Object r4) {
            if (r4 != 0) goto Lc
            r3 = r3 & 2
            if (r3 == 0) goto L7
            r2 = 1
        L7:
            kotlinx.coroutines.Deferred r0 = r0.applyAsync(r1, r2)
            return r0
        Lc:
            java.lang.UnsupportedOperationException r0 = new java.lang.UnsupportedOperationException
            java.lang.String r1 = "Super calls with default arguments not supported in this target, function: applyAsync"
            r0.<init>(r1)
            throw r0
    }

    void addRequestOption(androidx.camera.camera2.interop.CaptureRequestOptions r1);

    kotlinx.coroutines.Deferred<java.lang.Void> applyAsync(androidx.camera.camera2.impl.UseCaseCameraRequestControl r1, boolean r2);

    void cancelCurrentTask();

    void clearRequestOption();

    androidx.camera.camera2.interop.CaptureRequestOptions getRequestOption();
}
