package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: AeFpsRangeLegacyQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u0011\n\u0002\b\u0006\b\u0007\u0018\u0000 \u00142\u00020\u0001:\u0001\u0014B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J-\u0010\r\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u00072\u0016\u0010\u000e\u001a\u0012\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u00020\b0\u0007\u0018\u00010\u000fH\u0002¢\u0006\u0002\u0010\u0010J\u001c\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0002J\u000e\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0016R#\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u00078BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000b\u0010\f\u001a\u0004\b\t\u0010\n¨\u0006\u0015"}, d2 = {"Landroidx/camera/camera2/compat/quirk/AeFpsRangeLegacyQuirk;", "Landroidx/camera/core/internal/compat/quirk/AeFpsRangeQuirk;", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "<init>", "(Landroidx/camera/camera2/pipe/CameraMetadata;)V", "range", "Landroid/util/Range;", "", "getRange", "()Landroid/util/Range;", "range$delegate", "Lkotlin/Lazy;", "pickSuitableFpsRange", "availableFpsRanges", "", "([Landroid/util/Range;)Landroid/util/Range;", "getCorrectedFpsRange", "fpsRange", "getTargetAeFpsRange", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class AeFpsRangeLegacyQuirk implements androidx.camera.core.internal.compat.quirk.AeFpsRangeQuirk {
    public static final androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk.Companion Companion = null;
    private final kotlin.Lazy range$delegate;

    /* JADX INFO: compiled from: AeFpsRangeLegacyQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/AeFpsRangeLegacyQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean isEnabled(androidx.camera.camera2.pipe.CameraMetadata r2) {
                r1 = this;
                java.lang.String r0 = "cameraMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
                boolean r2 = r0.isHardwareLevelLegacy(r2)
                return r2
        }
    }

    public static /* synthetic */ android.util.Range $r8$lambda$M08z1plyKIceWjdadH5XAqm54nQ(androidx.camera.camera2.pipe.CameraMetadata r0, androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk r1) {
            android.util.Range r0 = range_delegate$lambda$0(r0, r1)
            return r0
    }

    static {
            androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk.Companion = r0
            return
    }

    public AeFpsRangeLegacyQuirk(androidx.camera.camera2.pipe.CameraMetadata r2) {
            r1 = this;
            java.lang.String r0 = "cameraMetadata"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk$$ExternalSyntheticLambda0 r0 = new androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk$$ExternalSyntheticLambda0
            r0.<init>(r2, r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r0)
            r1.range$delegate = r2
            return
    }

    private final android.util.Range<java.lang.Integer> getCorrectedFpsRange(android.util.Range<java.lang.Integer> r5) {
            r4 = this;
            java.lang.Comparable r0 = r5.getUpper()
            java.lang.Integer r0 = (java.lang.Integer) r0
            java.lang.Comparable r1 = r5.getLower()
            java.lang.Integer r1 = (java.lang.Integer) r1
            java.lang.Comparable r2 = r5.getUpper()
            java.lang.Number r2 = (java.lang.Number) r2
            int r2 = r2.intValue()
            r3 = 1000(0x3e8, float:1.401E-42)
            if (r2 < r3) goto L29
            java.lang.Comparable r0 = r5.getUpper()
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            int r0 = r0 / r3
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
        L29:
            java.lang.Comparable r2 = r5.getLower()
            java.lang.Number r2 = (java.lang.Number) r2
            int r2 = r2.intValue()
            if (r2 < r3) goto L44
            java.lang.Comparable r5 = r5.getLower()
            java.lang.Number r5 = (java.lang.Number) r5
            int r5 = r5.intValue()
            int r5 = r5 / r3
            java.lang.Integer r1 = java.lang.Integer.valueOf(r5)
        L44:
            android.util.Range r5 = new android.util.Range
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            java.lang.Comparable r0 = (java.lang.Comparable) r0
            r5.<init>(r1, r0)
            return r5
    }

    private final android.util.Range<java.lang.Integer> getRange() {
            r1 = this;
            kotlin.Lazy r0 = r1.range$delegate
            java.lang.Object r0 = r0.getValue()
            android.util.Range r0 = (android.util.Range) r0
            return r0
    }

    private final android.util.Range<java.lang.Integer> pickSuitableFpsRange(android.util.Range<java.lang.Integer>[] r7) {
            r6 = this;
            r0 = 0
            if (r7 == 0) goto L40
            int r1 = r7.length
            if (r1 != 0) goto L7
            goto L40
        L7:
            int r1 = r7.length
            r2 = 0
        L9:
            if (r2 >= r1) goto L40
            r3 = r7[r2]
            android.util.Range r3 = r6.getCorrectedFpsRange(r3)
            java.lang.Comparable r4 = r3.getUpper()
            java.lang.Integer r4 = (java.lang.Integer) r4
            if (r4 != 0) goto L1a
            goto L3d
        L1a:
            int r4 = r4.intValue()
            r5 = 30
            if (r4 == r5) goto L23
            goto L3d
        L23:
            if (r0 != 0) goto L26
            goto L3c
        L26:
            java.lang.Comparable r4 = r3.getLower()
            java.lang.Number r4 = (java.lang.Number) r4
            int r4 = r4.intValue()
            java.lang.Comparable r5 = r0.getLower()
            java.lang.Number r5 = (java.lang.Number) r5
            int r5 = r5.intValue()
            if (r4 >= r5) goto L3d
        L3c:
            r0 = r3
        L3d:
            int r2 = r2 + 1
            goto L9
        L40:
            return r0
    }

    private static final android.util.Range range_delegate$lambda$0(androidx.camera.camera2.pipe.CameraMetadata r2, androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk r3) {
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES
            java.lang.String r1 = "CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r2 = r2.get(r0)
            android.util.Range[] r2 = (android.util.Range[]) r2
            android.util.Range r2 = r3.pickSuitableFpsRange(r2)
            return r2
    }

    @Override // androidx.camera.core.internal.compat.quirk.AeFpsRangeQuirk
    public android.util.Range<java.lang.Integer> getTargetAeFpsRange() {
            r2 = this;
            android.util.Range r0 = r2.getRange()
            if (r0 != 0) goto Ld
            android.util.Range<java.lang.Integer> r0 = androidx.camera.core.impl.StreamSpec.FRAME_RATE_RANGE_UNSPECIFIED
            java.lang.String r1 = "FRAME_RATE_RANGE_UNSPECIFIED"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
        Ld:
            return r0
    }
}
