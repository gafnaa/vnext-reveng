package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: CamcorderProfileResolutionQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0007\u0018\u0000 \u000e2\u00020\u0001:\u0001\u000eB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\b0\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R!\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00078BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000b\u0010\f\u001a\u0004\b\t\u0010\n¨\u0006\u000f"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CamcorderProfileResolutionQuirk;", "Landroidx/camera/core/impl/Quirk;", "streamConfigurationMapCompat", "Landroidx/camera/camera2/compat/StreamConfigurationMapCompat;", "<init>", "(Landroidx/camera/camera2/compat/StreamConfigurationMapCompat;)V", "supportedResolution", "", "Landroid/util/Size;", "getSupportedResolution", "()Ljava/util/List;", "supportedResolution$delegate", "Lkotlin/Lazy;", "getSupportedResolutions", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CamcorderProfileResolutionQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk.Companion Companion = null;
    private final androidx.camera.camera2.compat.StreamConfigurationMapCompat streamConfigurationMapCompat;
    private final kotlin.Lazy supportedResolution$delegate;

    /* JADX INFO: compiled from: CamcorderProfileResolutionQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CamcorderProfileResolutionQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean isEnabled(androidx.camera.camera2.pipe.CameraMetadata r2) {
                r1 = this;
                java.lang.String r0 = "cameraMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
                boolean r2 = r0.isHardwareLevelLegacy(r2)
                return r2
        }
    }

    public static /* synthetic */ java.util.List $r8$lambda$bXAkRXoJlahpxssqlwQqYY8ViaU(androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk r0) {
            java.util.List r0 = supportedResolution_delegate$lambda$0(r0)
            return r0
    }

    static {
            androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk.Companion = r0
            return
    }

    public CamcorderProfileResolutionQuirk(androidx.camera.camera2.compat.StreamConfigurationMapCompat r2) {
            r1 = this;
            java.lang.String r0 = "streamConfigurationMapCompat"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.streamConfigurationMapCompat = r2
            androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk$$ExternalSyntheticLambda0 r2 = new androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk$$ExternalSyntheticLambda0
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.supportedResolution$delegate = r2
            return
    }

    private final java.util.List<android.util.Size> getSupportedResolution() {
            r1 = this;
            kotlin.Lazy r0 = r1.supportedResolution$delegate
            java.lang.Object r0 = r0.getValue()
            java.util.List r0 = (java.util.List) r0
            return r0
    }

    private static final java.util.List supportedResolution_delegate$lambda$0(androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk r3) {
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r3 = r3.streamConfigurationMapCompat
            r0 = 34
            android.util.Size[] r3 = r3.getOutputSizes(r0)
            if (r3 == 0) goto L10
            java.util.List r3 = kotlin.collections.ArraysKt.asList(r3)
            if (r3 != 0) goto L14
        L10:
            java.util.List r3 = kotlin.collections.CollectionsKt.emptyList()
        L14:
            androidx.camera.camera2.impl.Camera2Logger r0 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r0 = "CXCP"
            boolean r0 = androidx.camera.core.Logger.isDebugEnabled(r0)
            if (r0 == 0) goto L33
            java.lang.String r0 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "supportedResolutions = "
            r1.<init>(r2)
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            android.util.Log.d(r0, r1)
        L33:
            return r3
    }

    public final java.util.List<android.util.Size> getSupportedResolutions() {
            r1 = this;
            java.util.List r0 = r1.getSupportedResolution()
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            java.util.List r0 = kotlin.collections.CollectionsKt.toList(r0)
            return r0
    }
}
