package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: CaptureIntentPreviewQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\bf\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004J\b\u0010\u0002\u001a\u00020\u0003H\u0016ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0005À\u0006\u0003"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CaptureIntentPreviewQuirk;", "Landroidx/camera/core/impl/Quirk;", "workaroundByCaptureIntentPreview", "", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public interface CaptureIntentPreviewQuirk extends androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: CaptureIntentPreviewQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CaptureIntentPreviewQuirk$Companion;", "", "<init>", "()V", "workaroundByCaptureIntentPreview", "", "quirks", "Landroidx/camera/core/impl/Quirks;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        static final /* synthetic */ androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk.Companion $$INSTANCE = null;

        static {
                androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk$Companion
                r0.<init>()
                androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk.Companion.$$INSTANCE = r0
                return
        }

        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean workaroundByCaptureIntentPreview(androidx.camera.core.impl.Quirks r2) {
                r1 = this;
                java.lang.String r0 = "quirks"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.Class<androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk> r0 = androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk.class
                java.util.List r2 = r2.getAll(r0)
                java.util.Iterator r2 = r2.iterator()
            Lf:
                boolean r0 = r2.hasNext()
                if (r0 == 0) goto L23
                java.lang.Object r0 = r2.next()
                androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk r0 = (androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk) r0
                boolean r0 = r0.workaroundByCaptureIntentPreview()
                if (r0 == 0) goto Lf
                r2 = 1
                return r2
            L23:
                r2 = 0
                return r2
        }
    }

    /* JADX INFO: compiled from: CaptureIntentPreviewQuirk.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final class DefaultImpls {
        @java.lang.Deprecated
        public static boolean workaroundByCaptureIntentPreview(androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk r0) {
                boolean r0 = androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk.access$workaroundByCaptureIntentPreview$jd(r0)
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk.Companion.$$INSTANCE
            androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk.Companion = r0
            return
    }

    static /* synthetic */ boolean access$workaroundByCaptureIntentPreview$jd(androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk r0) {
            boolean r0 = super.workaroundByCaptureIntentPreview()
            return r0
    }

    default boolean workaroundByCaptureIntentPreview() {
            r1 = this;
            r0 = 1
            return r0
    }
}
