package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: ControlZoomRatioRangeAssertionErrorQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ControlZoomRatioRangeAssertionErrorQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ControlZoomRatioRangeAssertionErrorQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: ControlZoomRatioRangeAssertionErrorQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0004\u001a\u00020\u0005J\b\u0010\u0006\u001a\u00020\u0005H\u0002J\b\u0010\u0007\u001a\u00020\u0005H\u0002J\b\u0010\b\u001a\u00020\u0005H\u0002¨\u0006\t"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ControlZoomRatioRangeAssertionErrorQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "isJioPhoneNext", "isSamsungA2s", "isVivo2039", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        private final boolean isJioPhoneNext() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isJioDevice()
                if (r0 == 0) goto L19
                java.lang.String r0 = android.os.Build.MODEL
                java.lang.String r1 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                java.lang.String r1 = "LS1542QW"
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.startsWith(r0, r1, r2)
                if (r0 == 0) goto L19
                return r2
            L19:
                r0 = 0
                return r0
        }

        private final boolean isSamsungA2s() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                if (r0 == 0) goto L23
                java.lang.String r0 = android.os.Build.MODEL
                java.lang.String r1 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                java.lang.String r1 = "SM-A025"
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.startsWith(r0, r1, r2)
                if (r0 != 0) goto L22
                java.lang.String r0 = android.os.Build.MODEL
                java.lang.String r1 = "SM-S124DL"
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L23
            L22:
                return r2
            L23:
                r0 = 0
                return r0
        }

        private final boolean isVivo2039() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isVivoDevice()
                if (r0 == 0) goto L14
                java.lang.String r0 = android.os.Build.MODEL
                java.lang.String r1 = "VIVO 2039"
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L14
                return r2
            L14:
                r0 = 0
                return r0
        }

        public final boolean isEnabled() {
                r1 = this;
                boolean r0 = r1.isJioPhoneNext()
                if (r0 != 0) goto L15
                boolean r0 = r1.isSamsungA2s()
                if (r0 != 0) goto L15
                boolean r0 = r1.isVivo2039()
                if (r0 == 0) goto L13
                goto L15
            L13:
                r0 = 0
                return r0
            L15:
                r0 = 1
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk.Companion = r0
            return
    }

    public ControlZoomRatioRangeAssertionErrorQuirk() {
            r0 = this;
            r0.<init>()
            return
    }
}
