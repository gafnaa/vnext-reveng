package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: DisableAbortCapturesOnStopQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/quirk/DisableAbortCapturesOnStopQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DisableAbortCapturesOnStopQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.Companion Companion = null;
    private static final boolean isPocoX3ProDevice = false;
    private static final boolean isSamsungNote10PlusDevice = false;

    /* JADX INFO: compiled from: DisableAbortCapturesOnStopQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0007R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/DisableAbortCapturesOnStopQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "isSamsungNote10PlusDevice", "isPocoX3ProDevice", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        @kotlin.jvm.JvmStatic
        public final boolean isEnabled() {
                r1 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isTecnoDevice()
                if (r0 != 0) goto L17
                boolean r0 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.access$isSamsungNote10PlusDevice$cp()
                if (r0 != 0) goto L17
                boolean r0 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.access$isPocoX3ProDevice$cp()
                if (r0 == 0) goto L15
                goto L17
            L15:
                r0 = 0
                return r0
            L17:
                r0 = 1
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.Companion = r0
            androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
            boolean r0 = r0.isSamsungDevice()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L1e
            java.lang.String r0 = "d2q"
            java.lang.String r3 = android.os.Build.DEVICE
            boolean r0 = kotlin.text.StringsKt.equals(r0, r3, r2)
            if (r0 == 0) goto L1e
            r0 = r2
            goto L1f
        L1e:
            r0 = r1
        L1f:
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.isSamsungNote10PlusDevice = r0
            androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
            boolean r0 = r0.isPocoDevice()
            if (r0 == 0) goto L34
            java.lang.String r0 = "M2102J20SG"
            java.lang.String r3 = android.os.Build.MODEL
            boolean r0 = kotlin.text.StringsKt.equals(r0, r3, r2)
            if (r0 == 0) goto L34
            r1 = r2
        L34:
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.isPocoX3ProDevice = r1
            return
    }

    public DisableAbortCapturesOnStopQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ boolean access$isPocoX3ProDevice$cp() {
            boolean r0 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.isPocoX3ProDevice
            return r0
    }

    public static final /* synthetic */ boolean access$isSamsungNote10PlusDevice$cp() {
            boolean r0 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.isSamsungNote10PlusDevice
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final boolean isEnabled() {
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.Companion
            boolean r0 = r0.isEnabled()
            return r0
    }
}
