package androidx.camera.camera2.compat.quirk;

/* JADX INFO: loaded from: classes.dex */
public final class CameraQuirks_Factory implements dagger.internal.Factory<androidx.camera.camera2.compat.quirk.CameraQuirks> {
    private final dagger.internal.Provider<androidx.camera.camera2.pipe.CameraMetadata> cameraMetadataProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.compat.StreamConfigurationMapCompat> streamConfigurationMapCompatProvider;

    private CameraQuirks_Factory(dagger.internal.Provider<androidx.camera.camera2.pipe.CameraMetadata> r1, dagger.internal.Provider<androidx.camera.camera2.compat.StreamConfigurationMapCompat> r2) {
            r0 = this;
            r0.<init>()
            r0.cameraMetadataProvider = r1
            r0.streamConfigurationMapCompatProvider = r2
            return
    }

    public static androidx.camera.camera2.compat.quirk.CameraQuirks_Factory create(dagger.internal.Provider<androidx.camera.camera2.pipe.CameraMetadata> r1, dagger.internal.Provider<androidx.camera.camera2.compat.StreamConfigurationMapCompat> r2) {
            androidx.camera.camera2.compat.quirk.CameraQuirks_Factory r0 = new androidx.camera.camera2.compat.quirk.CameraQuirks_Factory
            r0.<init>(r1, r2)
            return r0
    }

    public static androidx.camera.camera2.compat.quirk.CameraQuirks newInstance(androidx.camera.camera2.pipe.CameraMetadata r1, androidx.camera.camera2.compat.StreamConfigurationMapCompat r2) {
            androidx.camera.camera2.compat.quirk.CameraQuirks r0 = new androidx.camera.camera2.compat.quirk.CameraQuirks
            r0.<init>(r1, r2)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.compat.quirk.CameraQuirks get() {
            r2 = this;
            dagger.internal.Provider<androidx.camera.camera2.pipe.CameraMetadata> r0 = r2.cameraMetadataProvider
            java.lang.Object r0 = r0.get()
            androidx.camera.camera2.pipe.CameraMetadata r0 = (androidx.camera.camera2.pipe.CameraMetadata) r0
            dagger.internal.Provider<androidx.camera.camera2.compat.StreamConfigurationMapCompat> r1 = r2.streamConfigurationMapCompatProvider
            java.lang.Object r1 = r1.get()
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r1 = (androidx.camera.camera2.compat.StreamConfigurationMapCompat) r1
            androidx.camera.camera2.compat.quirk.CameraQuirks r0 = newInstance(r0, r1)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.compat.quirk.CameraQuirks r0 = r1.get()
            return r0
    }
}
