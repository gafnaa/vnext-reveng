package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CrashWhenTakingPhotoWithAutoFlashAEModeQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CrashWhenTakingPhotoWithAutoFlashAEModeQuirk implements androidx.camera.core.impl.Quirk {
    private static final java.util.List<java.lang.String> AFFECTED_MODELS = null;
    public static final androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0007\u001a\u00020\bH\u0007R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CrashWhenTakingPhotoWithAutoFlashAEModeQuirk$Companion;", "", "<init>", "()V", "AFFECTED_MODELS", "", "", "isEnabled", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        @kotlin.jvm.JvmStatic
        public final boolean isEnabled() {
                r3 = this;
                java.util.List r0 = androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.access$getAFFECTED_MODELS$cp()
                java.lang.String r1 = android.os.Build.MODEL
                java.lang.String r2 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
                java.util.Locale r2 = java.util.Locale.ROOT
                java.lang.String r1 = r1.toUpperCase(r2)
                java.lang.String r2 = "toUpperCase(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
                boolean r0 = r0.contains(r1)
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.Companion = r0
            java.lang.String r14 = "SM-J510FN"
            java.lang.String r15 = "5059X"
            java.lang.String r2 = "SM-A3000"
            java.lang.String r3 = "SM-A3009"
            java.lang.String r4 = "SM-A300F"
            java.lang.String r5 = "SM-A300FU"
            java.lang.String r6 = "SM-A300G"
            java.lang.String r7 = "SM-A300H"
            java.lang.String r8 = "SM-A300M"
            java.lang.String r9 = "SM-A300X"
            java.lang.String r10 = "SM-A300XU"
            java.lang.String r11 = "SM-A300XZ"
            java.lang.String r12 = "SM-A300Y"
            java.lang.String r13 = "SM-A300YZ"
            java.lang.String[] r0 = new java.lang.String[]{r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.AFFECTED_MODELS = r0
            return
    }

    public CrashWhenTakingPhotoWithAutoFlashAEModeQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ java.util.List access$getAFFECTED_MODELS$cp() {
            java.util.List<java.lang.String> r0 = androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.AFFECTED_MODELS
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final boolean isEnabled() {
            androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.Companion
            boolean r0 = r0.isEnabled()
            return r0
    }
}
