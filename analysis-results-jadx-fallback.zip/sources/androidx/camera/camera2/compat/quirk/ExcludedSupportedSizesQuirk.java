package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: ExcludedSupportedSizesQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\b\u0007\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u001c\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ \u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\n\u0010\u000b\u001a\u0006\u0012\u0002\b\u00030\fJ\u001e\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002J\u001e\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002J,\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\f\u0010\u000b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\fH\u0002J,\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\f\u0010\u000b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\fH\u0002J,\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\f\u0010\u000b\u001a\b\u0012\u0002\b\u0003\u0018\u00010\fH\u0002J\u001e\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002J\u0016\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\t\u001a\u00020\nH\u0002J\u0016\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\t\u001a\u00020\nH\u0002J\u001e\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0002¨\u0006\u0017"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ExcludedSupportedSizesQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "getExcludedSizes", "", "Landroid/util/Size;", "cameraId", "", "imageFormat", "", "klass", "Ljava/lang/Class;", "getOnePlus6ExcludedSizes", "getOnePlus6TExcludedSizes", "getHuaweiP20LiteExcludedSizes", "getSamsungJ7PrimeApi27AboveExcludedSizes", "getSamsungJ7Api27AboveExcludedSizes", "getRedmiNote9ProExcludedSizes", "getSamsungA05sExcludedSizes", "getNokia7PlusExcludedSizes", "getSamsungZFold4ExcludedSizes", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ExcludedSupportedSizesQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk.Companion Companion = null;
    private static final java.lang.String TAG = "ExcludedSupportedSizesQuirk";
    private static final int UNKNOWN_IMAGE_FORMAT = -1;

    /* JADX INFO: compiled from: ExcludedSupportedSizesQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0014\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\b\u001a\u00020\tR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u0014\u0010\r\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\fR\u0014\u0010\u000f\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0010\u0010\fR\u0014\u0010\u0011\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0012\u0010\fR\u0014\u0010\u0013\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0014\u0010\fR\u0014\u0010\u0015\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0016\u0010\fR\u0014\u0010\u0017\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0018\u0010\fR\u0014\u0010\u0019\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u001a\u0010\fR\u0014\u0010\u001b\u001a\u00020\t8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u001c\u0010\f¨\u0006\u001d"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ExcludedSupportedSizesQuirk$Companion;", "", "<init>", "()V", "TAG", "", "UNKNOWN_IMAGE_FORMAT", "", "isEnabled", "", "isOnePlus6", "isOnePlus6$camera_camera2", "()Z", "isOnePlus6T", "isOnePlus6T$camera_camera2", "isHuaweiP20Lite", "isHuaweiP20Lite$camera_camera2", "isSamsungJ7PrimeApi27Above", "isSamsungJ7PrimeApi27Above$camera_camera2", "isSamsungJ7Api27Above", "isSamsungJ7Api27Above$camera_camera2", "isRedmiNote9Pro", "isRedmiNote9Pro$camera_camera2", "isSamsungA05s", "isSamsungA05s$camera_camera2", "isNokia7Plus", "isNokia7Plus$camera_camera2", "isSamsungZFold4", "isSamsungZFold4$camera_camera2", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean isEnabled() {
                r1 = this;
                boolean r0 = r1.isOnePlus6$camera_camera2()
                if (r0 != 0) goto L39
                boolean r0 = r1.isOnePlus6T$camera_camera2()
                if (r0 != 0) goto L39
                boolean r0 = r1.isHuaweiP20Lite$camera_camera2()
                if (r0 != 0) goto L39
                boolean r0 = r1.isSamsungJ7PrimeApi27Above$camera_camera2()
                if (r0 != 0) goto L39
                boolean r0 = r1.isSamsungJ7Api27Above$camera_camera2()
                if (r0 != 0) goto L39
                boolean r0 = r1.isRedmiNote9Pro$camera_camera2()
                if (r0 != 0) goto L39
                boolean r0 = r1.isSamsungA05s$camera_camera2()
                if (r0 != 0) goto L39
                boolean r0 = r1.isNokia7Plus$camera_camera2()
                if (r0 != 0) goto L39
                boolean r0 = r1.isSamsungZFold4$camera_camera2()
                if (r0 == 0) goto L37
                goto L39
            L37:
                r0 = 0
                return r0
            L39:
                r0 = 1
                return r0
        }

        public final boolean isHuaweiP20Lite$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isHuaweiDevice()
                if (r0 == 0) goto L14
                java.lang.String r0 = "HWANE"
                java.lang.String r1 = android.os.Build.DEVICE
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L14
                return r2
            L14:
                r0 = 0
                return r0
        }

        public final boolean isNokia7Plus$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isNokiaDevice()
                if (r0 == 0) goto L1e
                java.lang.String r0 = "B2N"
                java.lang.String r1 = android.os.Build.DEVICE
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 != 0) goto L1d
                java.lang.String r0 = "B2N_sprout"
                java.lang.String r1 = android.os.Build.DEVICE
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L1e
            L1d:
                return r2
            L1e:
                r0 = 0
                return r0
        }

        public final boolean isOnePlus6$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isOnePlusDevice()
                if (r0 == 0) goto L14
                java.lang.String r0 = "OnePlus6"
                java.lang.String r1 = android.os.Build.DEVICE
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L14
                return r2
            L14:
                r0 = 0
                return r0
        }

        public final boolean isOnePlus6T$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isOnePlusDevice()
                if (r0 == 0) goto L14
                java.lang.String r0 = "OnePlus6T"
                java.lang.String r1 = android.os.Build.DEVICE
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L14
                return r2
            L14:
                r0 = 0
                return r0
        }

        public final boolean isRedmiNote9Pro$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isRedmiDevice()
                if (r0 == 0) goto L14
                java.lang.String r0 = "joyeuse"
                java.lang.String r1 = android.os.Build.DEVICE
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L14
                return r2
            L14:
                r0 = 0
                return r0
        }

        public final boolean isSamsungA05s$camera_camera2() {
                r6 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                r1 = 0
                if (r0 == 0) goto L35
                java.lang.String r0 = "a05s"
                java.lang.String r2 = android.os.Build.DEVICE
                r3 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r2, r3)
                if (r0 == 0) goto L35
                java.lang.String r0 = android.os.Build.MODEL
                java.lang.String r2 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r2)
                java.util.Locale r2 = java.util.Locale.ROOT
                java.lang.String r0 = r0.toUpperCase(r2)
                java.lang.String r2 = "toUpperCase(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r2)
                java.lang.CharSequence r0 = (java.lang.CharSequence) r0
                java.lang.String r2 = "SM-A057"
                java.lang.CharSequence r2 = (java.lang.CharSequence) r2
                r4 = 2
                r5 = 0
                boolean r0 = kotlin.text.StringsKt.contains$default(r0, r2, r1, r4, r5)
                if (r0 == 0) goto L35
                return r3
            L35:
                return r1
        }

        public final boolean isSamsungJ7Api27Above$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                if (r0 == 0) goto L1a
                java.lang.String r0 = "J7XELTE"
                java.lang.String r1 = android.os.Build.DEVICE
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L1a
                int r0 = android.os.Build.VERSION.SDK_INT
                r1 = 27
                if (r0 < r1) goto L1a
                return r2
            L1a:
                r0 = 0
                return r0
        }

        public final boolean isSamsungJ7PrimeApi27Above$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                if (r0 == 0) goto L1a
                java.lang.String r0 = "ON7XELTE"
                java.lang.String r1 = android.os.Build.DEVICE
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L1a
                int r0 = android.os.Build.VERSION.SDK_INT
                r1 = 27
                if (r0 < r1) goto L1a
                return r2
            L1a:
                r0 = 0
                return r0
        }

        public final boolean isSamsungZFold4$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                if (r0 == 0) goto L28
                java.lang.String r0 = "q4q"
                java.lang.String r1 = android.os.Build.DEVICE
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 != 0) goto L27
                java.lang.String r0 = "SCG16"
                java.lang.String r1 = android.os.Build.DEVICE
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 != 0) goto L27
                java.lang.String r0 = "SC-55C"
                java.lang.String r1 = android.os.Build.DEVICE
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L28
            L27:
                return r2
            L28:
                r0 = 0
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk.Companion = r0
            return
    }

    public ExcludedSupportedSizesQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    private final java.util.List<android.util.Size> getHuaweiP20LiteExcludedSizes(java.lang.String r2, int r3, java.lang.Class<?> r4) {
            r1 = this;
            java.lang.String r0 = "0"
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r0)
            if (r2 == 0) goto L29
            r2 = 34
            if (r3 == r2) goto L12
            r2 = 35
            if (r3 == r2) goto L12
            if (r4 == 0) goto L29
        L12:
            android.util.Size r2 = new android.util.Size
            r3 = 720(0x2d0, float:1.009E-42)
            r2.<init>(r3, r3)
            android.util.Size r3 = new android.util.Size
            r4 = 400(0x190, float:5.6E-43)
            r3.<init>(r4, r4)
            android.util.Size[] r2 = new android.util.Size[]{r2, r3}
            java.util.List r2 = kotlin.collections.CollectionsKt.listOf(r2)
            return r2
        L29:
            java.util.List r2 = kotlin.collections.CollectionsKt.emptyList()
            return r2
    }

    private final java.util.List<android.util.Size> getNokia7PlusExcludedSizes(int r9) {
            r8 = this;
            r0 = 35
            if (r9 != r0) goto L43
            android.util.Size r1 = new android.util.Size
            r9 = 4032(0xfc0, float:5.65E-42)
            r0 = 3024(0xbd0, float:4.238E-42)
            r1.<init>(r9, r0)
            android.util.Size r2 = new android.util.Size
            r9 = 4000(0xfa0, float:5.605E-42)
            r3 = 3000(0xbb8, float:4.204E-42)
            r2.<init>(r9, r3)
            android.util.Size r3 = new android.util.Size
            r9 = 3264(0xcc0, float:4.574E-42)
            r4 = 2448(0x990, float:3.43E-42)
            r3.<init>(r9, r4)
            r9 = r4
            android.util.Size r4 = new android.util.Size
            r5 = 3200(0xc80, float:4.484E-42)
            r6 = 2400(0x960, float:3.363E-42)
            r4.<init>(r5, r6)
            android.util.Size r5 = new android.util.Size
            r5.<init>(r0, r0)
            android.util.Size r6 = new android.util.Size
            r0 = 2976(0xba0, float:4.17E-42)
            r6.<init>(r0, r0)
            android.util.Size r7 = new android.util.Size
            r7.<init>(r9, r9)
            android.util.Size[] r9 = new android.util.Size[]{r1, r2, r3, r4, r5, r6, r7}
            java.util.List r9 = kotlin.collections.CollectionsKt.listOf(r9)
            return r9
        L43:
            java.util.List r9 = kotlin.collections.CollectionsKt.emptyList()
            return r9
    }

    private final java.util.List<android.util.Size> getOnePlus6ExcludedSizes(java.lang.String r3, int r4) {
            r2 = this;
            java.lang.String r0 = "0"
            boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r3 == 0) goto L27
            r3 = 256(0x100, float:3.59E-43)
            if (r4 != r3) goto L27
            android.util.Size r3 = new android.util.Size
            r4 = 4160(0x1040, float:5.83E-42)
            r0 = 3120(0xc30, float:4.372E-42)
            r3.<init>(r4, r0)
            android.util.Size r4 = new android.util.Size
            r0 = 4000(0xfa0, float:5.605E-42)
            r1 = 3000(0xbb8, float:4.204E-42)
            r4.<init>(r0, r1)
            android.util.Size[] r3 = new android.util.Size[]{r3, r4}
            java.util.List r3 = kotlin.collections.CollectionsKt.listOf(r3)
            return r3
        L27:
            java.util.List r3 = kotlin.collections.CollectionsKt.emptyList()
            return r3
    }

    private final java.util.List<android.util.Size> getOnePlus6TExcludedSizes(java.lang.String r3, int r4) {
            r2 = this;
            java.lang.String r0 = "0"
            boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r0)
            if (r3 == 0) goto L27
            r3 = 256(0x100, float:3.59E-43)
            if (r4 != r3) goto L27
            android.util.Size r3 = new android.util.Size
            r4 = 4160(0x1040, float:5.83E-42)
            r0 = 3120(0xc30, float:4.372E-42)
            r3.<init>(r4, r0)
            android.util.Size r4 = new android.util.Size
            r0 = 4000(0xfa0, float:5.605E-42)
            r1 = 3000(0xbb8, float:4.204E-42)
            r4.<init>(r0, r1)
            android.util.Size[] r3 = new android.util.Size[]{r3, r4}
            java.util.List r3 = kotlin.collections.CollectionsKt.listOf(r3)
            return r3
        L27:
            java.util.List r3 = kotlin.collections.CollectionsKt.emptyList()
            return r3
    }

    private final java.util.List<android.util.Size> getRedmiNote9ProExcludedSizes(java.lang.String r2, int r3) {
            r1 = this;
            java.lang.String r0 = "0"
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r2, r0)
            if (r2 == 0) goto L1a
            r2 = 256(0x100, float:3.59E-43)
            if (r3 != r2) goto L1a
            android.util.Size r2 = new android.util.Size
            r3 = 9280(0x2440, float:1.3004E-41)
            r0 = 6944(0x1b20, float:9.73E-42)
            r2.<init>(r3, r0)
            java.util.List r2 = kotlin.collections.CollectionsKt.listOf(r2)
            return r2
        L1a:
            java.util.List r2 = kotlin.collections.CollectionsKt.emptyList()
            return r2
    }

    private final java.util.List<android.util.Size> getSamsungA05sExcludedSizes(int r9) {
            r8 = this;
            r0 = 35
            if (r9 != r0) goto L4a
            android.util.Size r1 = new android.util.Size
            r9 = 3840(0xf00, float:5.381E-42)
            r0 = 2160(0x870, float:3.027E-42)
            r1.<init>(r9, r0)
            android.util.Size r2 = new android.util.Size
            r9 = 3264(0xcc0, float:4.574E-42)
            r0 = 2448(0x990, float:3.43E-42)
            r2.<init>(r9, r0)
            android.util.Size r3 = new android.util.Size
            r9 = 3200(0xc80, float:4.484E-42)
            r0 = 2400(0x960, float:3.363E-42)
            r3.<init>(r9, r0)
            android.util.Size r4 = new android.util.Size
            r9 = 2688(0xa80, float:3.767E-42)
            r0 = 1512(0x5e8, float:2.119E-42)
            r4.<init>(r9, r0)
            android.util.Size r5 = new android.util.Size
            r9 = 1944(0x798, float:2.724E-42)
            r0 = 2592(0xa20, float:3.632E-42)
            r5.<init>(r0, r9)
            android.util.Size r6 = new android.util.Size
            r9 = 1940(0x794, float:2.719E-42)
            r6.<init>(r0, r9)
            android.util.Size r7 = new android.util.Size
            r9 = 1920(0x780, float:2.69E-42)
            r0 = 1440(0x5a0, float:2.018E-42)
            r7.<init>(r9, r0)
            android.util.Size[] r9 = new android.util.Size[]{r1, r2, r3, r4, r5, r6, r7}
            java.util.List r9 = kotlin.collections.CollectionsKt.listOf(r9)
            return r9
        L4a:
            java.util.List r9 = kotlin.collections.CollectionsKt.emptyList()
            return r9
    }

    private final java.util.List<android.util.Size> getSamsungJ7Api27AboveExcludedSizes(java.lang.String r17, int r18, java.lang.Class<?> r19) {
            r16 = this;
            r0 = r17
            r1 = r18
            java.lang.String r2 = "0"
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r2)
            r3 = 35
            r4 = 34
            r5 = 1080(0x438, float:1.513E-42)
            r6 = 1152(0x480, float:1.614E-42)
            r7 = 1536(0x600, float:2.152E-42)
            r8 = 1920(0x780, float:2.69E-42)
            r9 = 2048(0x800, float:2.87E-42)
            if (r2 == 0) goto L7c
            if (r1 == r4) goto L39
            if (r19 == 0) goto L1f
            goto L39
        L1f:
            if (r1 != r3) goto Lb9
            android.util.Size r0 = new android.util.Size
            r0.<init>(r9, r7)
            android.util.Size r1 = new android.util.Size
            r1.<init>(r9, r6)
            android.util.Size r2 = new android.util.Size
            r2.<init>(r8, r5)
            android.util.Size[] r0 = new android.util.Size[]{r0, r1, r2}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            return r0
        L39:
            android.util.Size r1 = new android.util.Size
            r0 = 3096(0xc18, float:4.338E-42)
            r2 = 4128(0x1020, float:5.785E-42)
            r1.<init>(r2, r0)
            android.util.Size r0 = new android.util.Size
            r3 = 2322(0x912, float:3.254E-42)
            r0.<init>(r2, r3)
            android.util.Size r3 = new android.util.Size
            r2 = 3088(0xc10, float:4.327E-42)
            r3.<init>(r2, r2)
            android.util.Size r4 = new android.util.Size
            r2 = 2448(0x990, float:3.43E-42)
            r10 = 3264(0xcc0, float:4.574E-42)
            r4.<init>(r10, r2)
            android.util.Size r2 = new android.util.Size
            r11 = 1836(0x72c, float:2.573E-42)
            r2.<init>(r10, r11)
            android.util.Size r10 = new android.util.Size
            r10.<init>(r9, r7)
            android.util.Size r7 = new android.util.Size
            r7.<init>(r9, r6)
            android.util.Size r6 = new android.util.Size
            r6.<init>(r8, r5)
            r5 = r2
            r8 = r6
            r6 = r10
            r2 = r0
            android.util.Size[] r0 = new android.util.Size[]{r1, r2, r3, r4, r5, r6, r7, r8}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            return r0
        L7c:
            java.lang.String r2 = "1"
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r2)
            if (r0 == 0) goto Lb9
            if (r1 == r4) goto L8a
            if (r1 == r3) goto L8a
            if (r19 == 0) goto Lb9
        L8a:
            android.util.Size r10 = new android.util.Size
            r0 = 2576(0xa10, float:3.61E-42)
            r1 = 1932(0x78c, float:2.707E-42)
            r10.<init>(r0, r1)
            android.util.Size r11 = new android.util.Size
            r0 = 2560(0xa00, float:3.587E-42)
            r1 = 1440(0x5a0, float:2.018E-42)
            r11.<init>(r0, r1)
            android.util.Size r12 = new android.util.Size
            r12.<init>(r8, r8)
            android.util.Size r13 = new android.util.Size
            r13.<init>(r9, r7)
            android.util.Size r14 = new android.util.Size
            r14.<init>(r9, r6)
            android.util.Size r15 = new android.util.Size
            r15.<init>(r8, r5)
            android.util.Size[] r0 = new android.util.Size[]{r10, r11, r12, r13, r14, r15}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            return r0
        Lb9:
            java.util.List r0 = kotlin.collections.CollectionsKt.emptyList()
            return r0
    }

    private final java.util.List<android.util.Size> getSamsungJ7PrimeApi27AboveExcludedSizes(java.lang.String r22, int r23, java.lang.Class<?> r24) {
            r21 = this;
            r0 = r22
            r1 = r23
            java.lang.String r2 = "0"
            boolean r2 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r2)
            r3 = 35
            r4 = 34
            r5 = 1080(0x438, float:1.513E-42)
            r6 = 1152(0x480, float:1.614E-42)
            r7 = 1536(0x600, float:2.152E-42)
            r8 = 1836(0x72c, float:2.573E-42)
            r9 = 1920(0x780, float:2.69E-42)
            r10 = 2448(0x990, float:3.43E-42)
            r11 = 2048(0x800, float:2.87E-42)
            r12 = 3264(0xcc0, float:4.574E-42)
            if (r2 == 0) goto L99
            r0 = 2322(0x912, float:3.254E-42)
            r2 = 4128(0x1020, float:5.785E-42)
            r13 = 3088(0xc10, float:4.327E-42)
            if (r1 == r4) goto L63
            if (r24 == 0) goto L2b
            goto L63
        L2b:
            if (r1 != r3) goto Ldb
            android.util.Size r14 = new android.util.Size
            r14.<init>(r2, r0)
            android.util.Size r15 = new android.util.Size
            r15.<init>(r13, r13)
            android.util.Size r0 = new android.util.Size
            r0.<init>(r12, r10)
            android.util.Size r1 = new android.util.Size
            r1.<init>(r12, r8)
            android.util.Size r2 = new android.util.Size
            r2.<init>(r11, r7)
            android.util.Size r3 = new android.util.Size
            r3.<init>(r11, r6)
            android.util.Size r4 = new android.util.Size
            r4.<init>(r9, r5)
            r16 = r0
            r17 = r1
            r18 = r2
            r19 = r3
            r20 = r4
            android.util.Size[] r0 = new android.util.Size[]{r14, r15, r16, r17, r18, r19, r20}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            return r0
        L63:
            android.util.Size r1 = new android.util.Size
            r3 = 3096(0xc18, float:4.338E-42)
            r1.<init>(r2, r3)
            android.util.Size r3 = new android.util.Size
            r3.<init>(r2, r0)
            r2 = r3
            android.util.Size r3 = new android.util.Size
            r3.<init>(r13, r13)
            android.util.Size r4 = new android.util.Size
            r4.<init>(r12, r10)
            android.util.Size r0 = new android.util.Size
            r0.<init>(r12, r8)
            android.util.Size r8 = new android.util.Size
            r8.<init>(r11, r7)
            android.util.Size r7 = new android.util.Size
            r7.<init>(r11, r6)
            r6 = r8
            android.util.Size r8 = new android.util.Size
            r8.<init>(r9, r5)
            r5 = r0
            android.util.Size[] r0 = new android.util.Size[]{r1, r2, r3, r4, r5, r6, r7, r8}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            return r0
        L99:
            java.lang.String r2 = "1"
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r2)
            if (r0 == 0) goto Ldb
            if (r1 == r4) goto La7
            if (r1 == r3) goto La7
            if (r24 == 0) goto Ldb
        La7:
            android.util.Size r13 = new android.util.Size
            r13.<init>(r12, r10)
            android.util.Size r14 = new android.util.Size
            r14.<init>(r12, r8)
            android.util.Size r15 = new android.util.Size
            r15.<init>(r10, r10)
            android.util.Size r0 = new android.util.Size
            r0.<init>(r9, r9)
            android.util.Size r1 = new android.util.Size
            r1.<init>(r11, r7)
            android.util.Size r2 = new android.util.Size
            r2.<init>(r11, r6)
            android.util.Size r3 = new android.util.Size
            r3.<init>(r9, r5)
            r16 = r0
            r17 = r1
            r18 = r2
            r19 = r3
            android.util.Size[] r0 = new android.util.Size[]{r13, r14, r15, r16, r17, r18, r19}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            return r0
        Ldb:
            java.util.List r0 = kotlin.collections.CollectionsKt.emptyList()
            return r0
    }

    private final java.util.List<android.util.Size> getSamsungZFold4ExcludedSizes(java.lang.String r13, int r14) {
            r12 = this;
            java.lang.String r0 = "1"
            boolean r13 = kotlin.jvm.internal.Intrinsics.areEqual(r13, r0)
            if (r13 == 0) goto L75
            r13 = 35
            if (r14 != r13) goto L75
            android.util.Size r0 = new android.util.Size
            r13 = 1280(0x500, float:1.794E-42)
            r14 = 720(0x2d0, float:1.009E-42)
            r0.<init>(r13, r14)
            android.util.Size r1 = new android.util.Size
            r13 = 1920(0x780, float:2.69E-42)
            r14 = 1080(0x438, float:1.513E-42)
            r1.<init>(r13, r14)
            android.util.Size r2 = new android.util.Size
            r3 = 2304(0x900, float:3.229E-42)
            r4 = 1296(0x510, float:1.816E-42)
            r2.<init>(r3, r4)
            android.util.Size r3 = new android.util.Size
            r4 = 640(0x280, float:8.97E-43)
            r5 = 360(0x168, float:5.04E-43)
            r3.<init>(r4, r5)
            android.util.Size r4 = new android.util.Size
            r5 = 177(0xb1, float:2.48E-43)
            r6 = 144(0x90, float:2.02E-43)
            r4.<init>(r5, r6)
            android.util.Size r5 = new android.util.Size
            r6 = 2336(0x920, float:3.273E-42)
            r5.<init>(r6, r14)
            android.util.Size r6 = new android.util.Size
            r7 = 2400(0x960, float:3.363E-42)
            r6.<init>(r7, r14)
            android.util.Size r7 = new android.util.Size
            r14 = 824(0x338, float:1.155E-42)
            r7.<init>(r13, r14)
            android.util.Size r8 = new android.util.Size
            r13 = 1088(0x440, float:1.525E-42)
            r8.<init>(r13, r13)
            android.util.Size r9 = new android.util.Size
            r13 = 1728(0x6c0, float:2.421E-42)
            r9.<init>(r13, r13)
            android.util.Size r10 = new android.util.Size
            r13 = 2736(0xab0, float:3.834E-42)
            r10.<init>(r13, r13)
            android.util.Size r11 = new android.util.Size
            r13 = 1824(0x720, float:2.556E-42)
            r14 = 712(0x2c8, float:9.98E-43)
            r11.<init>(r13, r14)
            android.util.Size[] r13 = new android.util.Size[]{r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11}
            java.util.List r13 = kotlin.collections.CollectionsKt.listOf(r13)
            return r13
        L75:
            java.util.List r13 = kotlin.collections.CollectionsKt.emptyList()
            return r13
    }

    public final java.util.List<android.util.Size> getExcludedSizes(java.lang.String r4, int r5) {
            r3 = this;
            java.lang.String r0 = "cameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk.Companion
            boolean r1 = r0.isOnePlus6$camera_camera2()
            if (r1 == 0) goto L12
            java.util.List r4 = r3.getOnePlus6ExcludedSizes(r4, r5)
            return r4
        L12:
            boolean r1 = r0.isOnePlus6T$camera_camera2()
            if (r1 == 0) goto L1d
            java.util.List r4 = r3.getOnePlus6TExcludedSizes(r4, r5)
            return r4
        L1d:
            boolean r1 = r0.isHuaweiP20Lite$camera_camera2()
            r2 = 0
            if (r1 == 0) goto L29
            java.util.List r4 = r3.getHuaweiP20LiteExcludedSizes(r4, r5, r2)
            return r4
        L29:
            boolean r1 = r0.isSamsungJ7PrimeApi27Above$camera_camera2()
            if (r1 == 0) goto L34
            java.util.List r4 = r3.getSamsungJ7PrimeApi27AboveExcludedSizes(r4, r5, r2)
            return r4
        L34:
            boolean r1 = r0.isSamsungJ7Api27Above$camera_camera2()
            if (r1 == 0) goto L3f
            java.util.List r4 = r3.getSamsungJ7Api27AboveExcludedSizes(r4, r5, r2)
            return r4
        L3f:
            boolean r1 = r0.isRedmiNote9Pro$camera_camera2()
            if (r1 == 0) goto L4a
            java.util.List r4 = r3.getRedmiNote9ProExcludedSizes(r4, r5)
            return r4
        L4a:
            boolean r1 = r0.isSamsungA05s$camera_camera2()
            if (r1 == 0) goto L55
            java.util.List r4 = r3.getSamsungA05sExcludedSizes(r5)
            return r4
        L55:
            boolean r1 = r0.isNokia7Plus$camera_camera2()
            if (r1 == 0) goto L60
            java.util.List r4 = r3.getNokia7PlusExcludedSizes(r5)
            return r4
        L60:
            boolean r0 = r0.isSamsungZFold4$camera_camera2()
            if (r0 == 0) goto L6b
            java.util.List r4 = r3.getSamsungZFold4ExcludedSizes(r4, r5)
            return r4
        L6b:
            java.lang.String r4 = "ExcludedSupportedSizesQuirk"
            java.lang.String r5 = "Cannot retrieve list of supported sizes to exclude on this device."
            androidx.camera.core.Logger.w(r4, r5)
            java.util.List r4 = kotlin.collections.CollectionsKt.emptyList()
            return r4
    }

    public final java.util.List<android.util.Size> getExcludedSizes(java.lang.String r4, java.lang.Class<?> r5) {
            r3 = this;
            java.lang.String r0 = "cameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "klass"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk.Companion
            boolean r1 = r0.isHuaweiP20Lite$camera_camera2()
            r2 = -1
            if (r1 == 0) goto L18
            java.util.List r4 = r3.getHuaweiP20LiteExcludedSizes(r4, r2, r5)
            return r4
        L18:
            boolean r1 = r0.isSamsungJ7PrimeApi27Above$camera_camera2()
            if (r1 == 0) goto L23
            java.util.List r4 = r3.getSamsungJ7PrimeApi27AboveExcludedSizes(r4, r2, r5)
            return r4
        L23:
            boolean r0 = r0.isSamsungJ7Api27Above$camera_camera2()
            if (r0 == 0) goto L2e
            java.util.List r4 = r3.getSamsungJ7Api27AboveExcludedSizes(r4, r2, r5)
            return r4
        L2e:
            java.lang.String r4 = "ExcludedSupportedSizesQuirk"
            java.lang.String r5 = "Cannot retrieve list of supported sizes to exclude on this device."
            androidx.camera.core.Logger.w(r4, r5)
            java.util.List r4 = kotlin.collections.CollectionsKt.emptyList()
            return r4
    }
}
