package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: DeviceQuirksLoader.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b¨\u0006\t"}, d2 = {"Landroidx/camera/camera2/compat/quirk/DeviceQuirksLoader;", "", "<init>", "()V", "loadQuirks", "", "Landroidx/camera/core/impl/Quirk;", "quirkSettings", "Landroidx/camera/core/impl/QuirkSettings;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DeviceQuirksLoader {
    public static final androidx.camera.camera2.compat.quirk.DeviceQuirksLoader INSTANCE = null;

    static {
            androidx.camera.camera2.compat.quirk.DeviceQuirksLoader r0 = new androidx.camera.camera2.compat.quirk.DeviceQuirksLoader
            r0.<init>()
            androidx.camera.camera2.compat.quirk.DeviceQuirksLoader.INSTANCE = r0
            return
    }

    private DeviceQuirksLoader() {
            r0 = this;
            r0.<init>()
            return
    }

    public final java.util.List<androidx.camera.core.impl.Quirk> loadQuirks(androidx.camera.core.impl.QuirkSettings r4) {
            r3 = this;
            java.lang.String r0 = "quirkSettings"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            java.lang.Class<androidx.camera.camera2.compat.quirk.PixelJpegRSupportedQuirk> r1 = androidx.camera.camera2.compat.quirk.PixelJpegRSupportedQuirk.class
            androidx.camera.camera2.compat.quirk.PixelJpegRSupportedQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.PixelJpegRSupportedQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L22
            androidx.camera.camera2.compat.quirk.PixelJpegRSupportedQuirk r1 = new androidx.camera.camera2.compat.quirk.PixelJpegRSupportedQuirk
            r1.<init>()
            r0.add(r1)
        L22:
            java.lang.Class<androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk> r1 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.class
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L38
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk r1 = new androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk
            r1.<init>()
            r0.add(r1)
        L38:
            java.lang.Class<androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk> r1 = androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.class
            androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L4e
            androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk r1 = new androidx.camera.camera2.compat.quirk.CrashWhenTakingPhotoWithAutoFlashAEModeQuirk
            r1.<init>()
            r0.add(r1)
        L4e:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk> r1 = androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk.class
            androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L64
            androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk r1 = new androidx.camera.camera2.compat.quirk.ControlZoomRatioRangeAssertionErrorQuirk
            r1.<init>()
            r0.add(r1)
        L64:
            java.lang.Class<androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk> r1 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.class
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L7a
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk r1 = new androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopQuirk
            r1.<init>()
            r0.add(r1)
        L7a:
            java.lang.Class<androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk> r1 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk.class
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L90
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk r1 = new androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk
            r1.<init>()
            r0.add(r1)
        L90:
            java.lang.Class<androidx.camera.camera2.compat.quirk.FlashAvailabilityBufferUnderflowQuirk> r1 = androidx.camera.camera2.compat.quirk.FlashAvailabilityBufferUnderflowQuirk.class
            androidx.camera.camera2.compat.quirk.FlashAvailabilityBufferUnderflowQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.FlashAvailabilityBufferUnderflowQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto La6
            androidx.camera.camera2.compat.quirk.FlashAvailabilityBufferUnderflowQuirk r1 = new androidx.camera.camera2.compat.quirk.FlashAvailabilityBufferUnderflowQuirk
            r1.<init>()
            r0.add(r1)
        La6:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ImageCapturePixelHDRPlusQuirk> r1 = androidx.camera.camera2.compat.quirk.ImageCapturePixelHDRPlusQuirk.class
            androidx.camera.camera2.compat.quirk.ImageCapturePixelHDRPlusQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ImageCapturePixelHDRPlusQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto Lbc
            androidx.camera.camera2.compat.quirk.ImageCapturePixelHDRPlusQuirk r1 = new androidx.camera.camera2.compat.quirk.ImageCapturePixelHDRPlusQuirk
            r1.<init>()
            r0.add(r1)
        Lbc:
            java.lang.Class<androidx.camera.camera2.compat.quirk.InvalidVideoProfilesQuirk> r1 = androidx.camera.camera2.compat.quirk.InvalidVideoProfilesQuirk.class
            androidx.camera.camera2.compat.quirk.InvalidVideoProfilesQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.InvalidVideoProfilesQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto Ld2
            androidx.camera.camera2.compat.quirk.InvalidVideoProfilesQuirk r1 = new androidx.camera.camera2.compat.quirk.InvalidVideoProfilesQuirk
            r1.<init>()
            r0.add(r1)
        Ld2:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk> r1 = androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk.class
            androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto Le8
            androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk r1 = new androidx.camera.camera2.compat.quirk.ExcludedSupportedSizesQuirk
            r1.<init>()
            r0.add(r1)
        Le8:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk> r1 = androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.class
            androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto Lfe
            androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk r1 = new androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk
            r1.<init>()
            r0.add(r1)
        Lfe:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk> r1 = androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk.class
            androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L114
            androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk r1 = new androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk
            r1.<init>()
            r0.add(r1)
        L114:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk> r1 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.class
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L12a
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk r1 = new androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk
            r1.<init>()
            r0.add(r1)
        L12a:
            java.lang.Class<androidx.camera.camera2.compat.quirk.Nexus4AndroidLTargetAspectRatioQuirk> r1 = androidx.camera.camera2.compat.quirk.Nexus4AndroidLTargetAspectRatioQuirk.class
            androidx.camera.camera2.compat.quirk.Nexus4AndroidLTargetAspectRatioQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.Nexus4AndroidLTargetAspectRatioQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L140
            androidx.camera.camera2.compat.quirk.Nexus4AndroidLTargetAspectRatioQuirk r1 = new androidx.camera.camera2.compat.quirk.Nexus4AndroidLTargetAspectRatioQuirk
            r1.<init>()
            r0.add(r1)
        L140:
            java.lang.Class<androidx.camera.camera2.compat.quirk.PreviewPixelHDRnetQuirk> r1 = androidx.camera.camera2.compat.quirk.PreviewPixelHDRnetQuirk.class
            androidx.camera.camera2.compat.quirk.PreviewPixelHDRnetQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.PreviewPixelHDRnetQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L156
            androidx.camera.camera2.compat.quirk.PreviewPixelHDRnetQuirk r1 = new androidx.camera.camera2.compat.quirk.PreviewPixelHDRnetQuirk
            r1.<init>()
            r0.add(r1)
        L156:
            java.lang.Class<androidx.camera.camera2.compat.quirk.RepeatingStreamConstraintForVideoRecordingQuirk> r1 = androidx.camera.camera2.compat.quirk.RepeatingStreamConstraintForVideoRecordingQuirk.class
            androidx.camera.camera2.compat.quirk.RepeatingStreamConstraintForVideoRecordingQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.RepeatingStreamConstraintForVideoRecordingQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L16c
            androidx.camera.camera2.compat.quirk.RepeatingStreamConstraintForVideoRecordingQuirk r1 = new androidx.camera.camera2.compat.quirk.RepeatingStreamConstraintForVideoRecordingQuirk
            r1.<init>()
            r0.add(r1)
        L16c:
            java.lang.Class<androidx.camera.camera2.compat.quirk.StillCaptureFlashStopRepeatingQuirk> r1 = androidx.camera.camera2.compat.quirk.StillCaptureFlashStopRepeatingQuirk.class
            androidx.camera.camera2.compat.quirk.StillCaptureFlashStopRepeatingQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.StillCaptureFlashStopRepeatingQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L182
            androidx.camera.camera2.compat.quirk.StillCaptureFlashStopRepeatingQuirk r1 = new androidx.camera.camera2.compat.quirk.StillCaptureFlashStopRepeatingQuirk
            r1.<init>()
            r0.add(r1)
        L182:
            java.lang.Class<androidx.camera.camera2.compat.quirk.TorchIsClosedAfterImageCapturingQuirk> r1 = androidx.camera.camera2.compat.quirk.TorchIsClosedAfterImageCapturingQuirk.class
            androidx.camera.camera2.compat.quirk.TorchIsClosedAfterImageCapturingQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.TorchIsClosedAfterImageCapturingQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L198
            androidx.camera.camera2.compat.quirk.TorchIsClosedAfterImageCapturingQuirk r1 = new androidx.camera.camera2.compat.quirk.TorchIsClosedAfterImageCapturingQuirk
            r1.<init>()
            r0.add(r1)
        L198:
            java.lang.Class<androidx.camera.camera2.compat.quirk.SurfaceOrderQuirk> r1 = androidx.camera.camera2.compat.quirk.SurfaceOrderQuirk.class
            androidx.camera.camera2.compat.quirk.SurfaceOrderQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.SurfaceOrderQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L1ae
            androidx.camera.camera2.compat.quirk.SurfaceOrderQuirk r1 = new androidx.camera.camera2.compat.quirk.SurfaceOrderQuirk
            r1.<init>()
            r0.add(r1)
        L1ae:
            java.lang.Class<androidx.camera.camera2.compat.quirk.CaptureSessionOnClosedNotCalledQuirk> r1 = androidx.camera.camera2.compat.quirk.CaptureSessionOnClosedNotCalledQuirk.class
            androidx.camera.camera2.compat.quirk.CaptureSessionOnClosedNotCalledQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.CaptureSessionOnClosedNotCalledQuirk.Companion
            boolean r2 = r2.isEnabled()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L1c4
            androidx.camera.camera2.compat.quirk.CaptureSessionOnClosedNotCalledQuirk r1 = new androidx.camera.camera2.compat.quirk.CaptureSessionOnClosedNotCalledQuirk
            r1.<init>()
            r0.add(r1)
        L1c4:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ZslDisablerQuirk> r1 = androidx.camera.camera2.compat.quirk.ZslDisablerQuirk.class
            androidx.camera.camera2.compat.quirk.ZslDisablerQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ZslDisablerQuirk.Companion
            boolean r2 = r2.load()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L1da
            androidx.camera.camera2.compat.quirk.ZslDisablerQuirk r1 = new androidx.camera.camera2.compat.quirk.ZslDisablerQuirk
            r1.<init>()
            r0.add(r1)
        L1da:
            java.lang.Class<androidx.camera.camera2.compat.quirk.SmallDisplaySizeQuirk> r1 = androidx.camera.camera2.compat.quirk.SmallDisplaySizeQuirk.class
            androidx.camera.camera2.compat.quirk.SmallDisplaySizeQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.SmallDisplaySizeQuirk.Companion
            boolean r2 = r2.load()
            boolean r1 = r4.shouldEnableQuirk(r1, r2)
            if (r1 == 0) goto L1f0
            androidx.camera.camera2.compat.quirk.SmallDisplaySizeQuirk r1 = new androidx.camera.camera2.compat.quirk.SmallDisplaySizeQuirk
            r1.<init>()
            r0.add(r1)
        L1f0:
            java.lang.Class<androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk> r1 = androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk.class
            boolean r2 = androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk.load()
            boolean r4 = r4.shouldEnableQuirk(r1, r2)
            if (r4 == 0) goto L201
            androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk r4 = androidx.camera.camera2.compat.quirk.PreviewUnderExposureQuirk.INSTANCE
            r0.add(r4)
        L201:
            return r0
    }
}
