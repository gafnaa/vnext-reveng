package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: ExtraSupportedSurfaceCombinationsQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\u0018\u0000 \r2\u00020\u0001:\u0001\rB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\bJ\u0016\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u0016\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u000b\u001a\u00020\fH\u0002¨\u0006\u000e"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ExtraSupportedSurfaceCombinationsQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "getExtraSupportedSurfaceCombinations", "", "Landroidx/camera/core/impl/SurfaceCombination;", "cameraId", "", "getSamsungS7ExtraCombinations", "getLimitedDeviceExtraSupportedFullConfigurations", "hardwareLevel", "", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ExtraSupportedSurfaceCombinationsQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.Companion Companion = null;
    private static final androidx.camera.core.impl.SurfaceCombination FULL_LEVEL_YUV_PRIV_YUV_CONFIGURATION = null;
    private static final androidx.camera.core.impl.SurfaceCombination FULL_LEVEL_YUV_YUV_YUV_CONFIGURATION = null;
    private static final androidx.camera.core.impl.SurfaceCombination LEVEL_3_LEVEL_PRIV_PRIV_YUV_SUBSET_CONFIGURATION = null;
    private static final java.util.Set<java.lang.String> SUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_GOOGLE_MODELS = null;
    private static final java.util.Set<java.lang.String> SUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_SAMSUNG_MODELS = null;
    private static final java.lang.String TAG = "ExtraSupportedSurfaceCombinationsQuirk";

    /* JADX INFO: compiled from: ExtraSupportedSurfaceCombinationsQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u000e\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\r\u001a\u00020\u000eJ\r\u0010\u0012\u001a\u00020\u000eH\u0000¢\u0006\u0002\b\u0013J\r\u0010\u0014\u001a\u00020\u000eH\u0000¢\u0006\u0002\b\u0015J\r\u0010\u0016\u001a\u00020\u0007H\u0000¢\u0006\u0002\b\u0017J\r\u0010\u0018\u001a\u00020\u0007H\u0000¢\u0006\u0002\b\u0019J\r\u0010\u001a\u001a\u00020\u0007H\u0000¢\u0006\u0002\b\u001bR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00050\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00050\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\u00020\u000e8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001c"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ExtraSupportedSurfaceCombinationsQuirk$Companion;", "", "<init>", "()V", "TAG", "", "FULL_LEVEL_YUV_PRIV_YUV_CONFIGURATION", "Landroidx/camera/core/impl/SurfaceCombination;", "FULL_LEVEL_YUV_YUV_YUV_CONFIGURATION", "LEVEL_3_LEVEL_PRIV_PRIV_YUV_SUBSET_CONFIGURATION", "SUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_GOOGLE_MODELS", "", "SUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_SAMSUNG_MODELS", "isEnabled", "", "isSamsungS7", "isSamsungS7$camera_camera2", "()Z", "supportExtraLevel3ConfigurationsGoogleDevice", "supportExtraLevel3ConfigurationsGoogleDevice$camera_camera2", "supportExtraLevel3ConfigurationsSamsungDevice", "supportExtraLevel3ConfigurationsSamsungDevice$camera_camera2", "createFullYuvPrivYuvConfiguration", "createFullYuvPrivYuvConfiguration$camera_camera2", "createFullYuvYuvYuvConfiguration", "createFullYuvYuvYuvConfiguration$camera_camera2", "createLevel3PrivPrivYuvSubsetConfiguration", "createLevel3PrivPrivYuvSubsetConfiguration$camera_camera2", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final androidx.camera.core.impl.SurfaceCombination createFullYuvPrivYuvConfiguration$camera_camera2() {
                r8 = this;
                androidx.camera.core.impl.SurfaceCombination r0 = new androidx.camera.core.impl.SurfaceCombination
                r0.<init>()
                androidx.camera.core.impl.SurfaceConfig$Companion r1 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r2 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r3 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.VGA
                r5 = 4
                r6 = 0
                r4 = 0
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r1, r2, r3, r4, r5, r6)
                r0.addSurfaceConfig(r1)
                androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
                r6 = 4
                r7 = 0
                r5 = 0
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
                r0.addSurfaceConfig(r1)
                androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
                r0.addSurfaceConfig(r1)
                return r0
        }

        public final androidx.camera.core.impl.SurfaceCombination createFullYuvYuvYuvConfiguration$camera_camera2() {
                r8 = this;
                androidx.camera.core.impl.SurfaceCombination r0 = new androidx.camera.core.impl.SurfaceCombination
                r0.<init>()
                androidx.camera.core.impl.SurfaceConfig$Companion r1 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r2 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r3 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.VGA
                r5 = 4
                r6 = 0
                r4 = 0
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r1, r2, r3, r4, r5, r6)
                r0.addSurfaceConfig(r1)
                androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
                r6 = 4
                r7 = 0
                r5 = 0
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
                r0.addSurfaceConfig(r1)
                androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
                r0.addSurfaceConfig(r1)
                return r0
        }

        public final androidx.camera.core.impl.SurfaceCombination createLevel3PrivPrivYuvSubsetConfiguration$camera_camera2() {
                r8 = this;
                androidx.camera.core.impl.SurfaceCombination r0 = new androidx.camera.core.impl.SurfaceCombination
                r0.<init>()
                androidx.camera.core.impl.SurfaceConfig$Companion r1 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r2 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r3 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.PREVIEW
                r5 = 4
                r6 = 0
                r4 = 0
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r1, r2, r3, r4, r5, r6)
                r0.addSurfaceConfig(r1)
                androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.VGA
                r6 = 4
                r7 = 0
                r5 = 0
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
                r0.addSurfaceConfig(r1)
                androidx.camera.core.impl.SurfaceConfig$Companion r2 = androidx.camera.core.impl.SurfaceConfig.Companion
                androidx.camera.core.impl.SurfaceConfig$ConfigType r3 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV
                androidx.camera.core.impl.SurfaceConfig$ConfigSize r4 = androidx.camera.core.impl.SurfaceConfig.ConfigSize.MAXIMUM
                androidx.camera.core.impl.SurfaceConfig r1 = androidx.camera.core.impl.SurfaceConfig.Companion.create$default(r2, r3, r4, r5, r6, r7)
                r0.addSurfaceConfig(r1)
                return r0
        }

        public final boolean isEnabled() {
                r1 = this;
                boolean r0 = r1.isSamsungS7$camera_camera2()
                if (r0 != 0) goto L15
                boolean r0 = r1.supportExtraLevel3ConfigurationsGoogleDevice$camera_camera2()
                if (r0 != 0) goto L15
                boolean r0 = r1.supportExtraLevel3ConfigurationsSamsungDevice$camera_camera2()
                if (r0 == 0) goto L13
                goto L15
            L13:
                r0 = 0
                return r0
            L15:
                r0 = 1
                return r0
        }

        public final boolean isSamsungS7$camera_camera2() {
                r3 = this;
                java.lang.String r0 = android.os.Build.DEVICE
                java.lang.String r1 = "heroqltevzw"
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r1, r0, r2)
                if (r0 != 0) goto L18
                java.lang.String r0 = "heroqltetmo"
                java.lang.String r1 = android.os.Build.DEVICE
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L16
                goto L18
            L16:
                r0 = 0
                return r0
            L18:
                return r2
        }

        public final boolean supportExtraLevel3ConfigurationsGoogleDevice$camera_camera2() {
                r2 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isGoogleDevice()
                if (r0 != 0) goto La
                r0 = 0
                return r0
            La:
                java.lang.String r0 = android.os.Build.MODEL
                java.lang.String r1 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                java.util.Locale r1 = java.util.Locale.ROOT
                java.lang.String r0 = r0.toUpperCase(r1)
                java.lang.String r1 = "toUpperCase(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                java.util.Set r1 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.access$getSUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_GOOGLE_MODELS$cp()
                boolean r0 = r1.contains(r0)
                return r0
        }

        public final boolean supportExtraLevel3ConfigurationsSamsungDevice$camera_camera2() {
                r6 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                r1 = 0
                if (r0 != 0) goto La
                return r1
            La:
                java.lang.String r0 = android.os.Build.MODEL
                java.lang.String r2 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r2)
                java.util.Locale r2 = java.util.Locale.ROOT
                java.lang.String r0 = r0.toUpperCase(r2)
                java.lang.String r2 = "toUpperCase(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r2)
                java.util.Set r2 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.access$getSUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_SAMSUNG_MODELS$cp()
                java.util.Iterator r2 = r2.iterator()
            L24:
                boolean r3 = r2.hasNext()
                if (r3 == 0) goto L3a
                java.lang.Object r3 = r2.next()
                java.lang.String r3 = (java.lang.String) r3
                r4 = 2
                r5 = 0
                boolean r3 = kotlin.text.StringsKt.startsWith$default(r0, r3, r1, r4, r5)
                if (r3 == 0) goto L24
                r0 = 1
                return r0
            L3a:
                return r1
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.Companion = r0
            androidx.camera.core.impl.SurfaceCombination r1 = r0.createFullYuvPrivYuvConfiguration$camera_camera2()
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.FULL_LEVEL_YUV_PRIV_YUV_CONFIGURATION = r1
            androidx.camera.core.impl.SurfaceCombination r1 = r0.createFullYuvYuvYuvConfiguration$camera_camera2()
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.FULL_LEVEL_YUV_YUV_YUV_CONFIGURATION = r1
            androidx.camera.core.impl.SurfaceCombination r0 = r0.createLevel3PrivPrivYuvSubsetConfiguration$camera_camera2()
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.LEVEL_3_LEVEL_PRIV_PRIV_YUV_SUBSET_CONFIGURATION = r0
            java.lang.String r9 = "PIXEL 9 PRO XL"
            java.lang.String r10 = "PIXEL 9 PRO FOLD"
            java.lang.String r1 = "PIXEL 6"
            java.lang.String r2 = "PIXEL 6 PRO"
            java.lang.String r3 = "PIXEL 7"
            java.lang.String r4 = "PIXEL 7 PRO"
            java.lang.String r5 = "PIXEL 8"
            java.lang.String r6 = "PIXEL 8 PRO"
            java.lang.String r7 = "PIXEL 9"
            java.lang.String r8 = "PIXEL 9 PRO"
            java.lang.String[] r0 = new java.lang.String[]{r1, r2, r3, r4, r5, r6, r7, r8, r9, r10}
            java.util.Set r0 = kotlin.collections.SetsKt.setOf(r0)
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.SUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_GOOGLE_MODELS = r0
            java.lang.String r14 = "SC-51F"
            java.lang.String r15 = "SC-52F"
            java.lang.String r1 = "SM-S921"
            java.lang.String r2 = "SC-51E"
            java.lang.String r3 = "SCG25"
            java.lang.String r4 = "SM-S926"
            java.lang.String r5 = "SM-S928"
            java.lang.String r6 = "SC-52E"
            java.lang.String r7 = "SCG26"
            java.lang.String r8 = "SM-S931"
            java.lang.String r9 = "SM-S936"
            java.lang.String r10 = "SM-S937"
            java.lang.String r11 = "SM-S938"
            java.lang.String r12 = "SCG31"
            java.lang.String r13 = "SCG32"
            java.lang.String[] r0 = new java.lang.String[]{r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15}
            java.util.Set r0 = kotlin.collections.SetsKt.setOf(r0)
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.SUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_SAMSUNG_MODELS = r0
            return
    }

    public ExtraSupportedSurfaceCombinationsQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ java.util.Set access$getSUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_GOOGLE_MODELS$cp() {
            java.util.Set<java.lang.String> r0 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.SUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_GOOGLE_MODELS
            return r0
    }

    public static final /* synthetic */ java.util.Set access$getSUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_SAMSUNG_MODELS$cp() {
            java.util.Set<java.lang.String> r0 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.SUPPORT_EXTRA_LEVEL_3_CONFIGURATIONS_SAMSUNG_MODELS
            return r0
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> getLimitedDeviceExtraSupportedFullConfigurations(int r2) {
            r1 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            if (r2 != 0) goto L13
            androidx.camera.core.impl.SurfaceCombination r2 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.FULL_LEVEL_YUV_PRIV_YUV_CONFIGURATION
            r0.add(r2)
            androidx.camera.core.impl.SurfaceCombination r2 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.FULL_LEVEL_YUV_YUV_YUV_CONFIGURATION
            r0.add(r2)
        L13:
            return r0
    }

    private final java.util.List<androidx.camera.core.impl.SurfaceCombination> getSamsungS7ExtraCombinations(java.lang.String r3) {
            r2 = this;
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            java.lang.String r1 = "1"
            boolean r3 = kotlin.jvm.internal.Intrinsics.areEqual(r3, r1)
            if (r3 == 0) goto L14
            androidx.camera.core.impl.SurfaceCombination r3 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.FULL_LEVEL_YUV_PRIV_YUV_CONFIGURATION
            r0.add(r3)
        L14:
            return r0
    }

    public final java.util.List<androidx.camera.core.impl.SurfaceCombination> getExtraSupportedSurfaceCombinations(java.lang.String r3) {
            r2 = this;
            java.lang.String r0 = "cameraId"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.Companion
            boolean r1 = r0.isSamsungS7$camera_camera2()
            if (r1 == 0) goto L12
            java.util.List r3 = r2.getSamsungS7ExtraCombinations(r3)
            return r3
        L12:
            boolean r3 = r0.supportExtraLevel3ConfigurationsGoogleDevice$camera_camera2()
            if (r3 != 0) goto L24
            boolean r3 = r0.supportExtraLevel3ConfigurationsSamsungDevice$camera_camera2()
            if (r3 == 0) goto L1f
            goto L24
        L1f:
            java.util.List r3 = kotlin.collections.CollectionsKt.emptyList()
            return r3
        L24:
            androidx.camera.core.impl.SurfaceCombination r3 = androidx.camera.camera2.compat.quirk.ExtraSupportedSurfaceCombinationsQuirk.LEVEL_3_LEVEL_PRIV_PRIV_YUV_SUBSET_CONFIGURATION
            java.util.List r3 = kotlin.collections.CollectionsKt.listOf(r3)
            return r3
    }
}
