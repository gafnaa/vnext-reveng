package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: DisableAbortCapturesOnStopWithSessionProcessorQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/quirk/DisableAbortCapturesOnStopWithSessionProcessorQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DisableAbortCapturesOnStopWithSessionProcessorQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: DisableAbortCapturesOnStopWithSessionProcessorQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0004\u001a\u00020\u0005¨\u0006\u0006"}, d2 = {"Landroidx/camera/camera2/compat/quirk/DisableAbortCapturesOnStopWithSessionProcessorQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean isEnabled() {
                r1 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                if (r0 != 0) goto L13
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isXiaomiDevice()
                if (r0 == 0) goto L11
                goto L13
            L11:
                r0 = 0
                return r0
            L13:
                r0 = 1
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.DisableAbortCapturesOnStopWithSessionProcessorQuirk.Companion = r0
            return
    }

    public DisableAbortCapturesOnStopWithSessionProcessorQuirk() {
            r0 = this;
            r0.<init>()
            return
    }
}
