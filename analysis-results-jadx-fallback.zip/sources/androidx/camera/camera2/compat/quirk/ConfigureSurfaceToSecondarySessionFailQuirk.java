package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: ConfigureSurfaceToSecondarySessionFailQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ConfigureSurfaceToSecondarySessionFailQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ConfigureSurfaceToSecondarySessionFailQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: ConfigureSurfaceToSecondarySessionFailQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ConfigureSurfaceToSecondarySessionFailQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean isEnabled(androidx.camera.camera2.pipe.CameraMetadata r2) {
                r1 = this;
                java.lang.String r0 = "cameraMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                androidx.camera.camera2.pipe.CameraMetadata$Companion r0 = androidx.camera.camera2.pipe.CameraMetadata.Companion
                boolean r2 = r0.isHardwareLevelLegacy(r2)
                return r2
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk.Companion = r0
            return
    }

    public ConfigureSurfaceToSecondarySessionFailQuirk() {
            r0 = this;
            r0.<init>()
            return
    }
}
