package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: DeviceQuirks.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J*\u0010\r\u001a\u0004\u0018\u0001H\u000e\"\n\b\u0000\u0010\u000e*\u0004\u0018\u00010\u000f2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u0011H\u0086\u0002¢\u0006\u0002\u0010\u0012R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R$\u0010\u0006\u001a\u00020\u00078\u0006@\u0006X\u0087.¢\u0006\u0014\n\u0000\u0012\u0004\b\b\u0010\u0003\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\f¨\u0006\u0013"}, d2 = {"Landroidx/camera/camera2/compat/quirk/DeviceQuirks;", "", "<init>", "()V", "TAG", "", "all", "Landroidx/camera/core/impl/Quirks;", "getAll$annotations", "getAll", "()Landroidx/camera/core/impl/Quirks;", "setAll", "(Landroidx/camera/core/impl/Quirks;)V", "get", "T", "Landroidx/camera/core/impl/Quirk;", "quirkClass", "Ljava/lang/Class;", "(Ljava/lang/Class;)Landroidx/camera/core/impl/Quirk;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DeviceQuirks {
    public static final androidx.camera.camera2.compat.quirk.DeviceQuirks INSTANCE = null;
    private static final java.lang.String TAG = "DeviceQuirks";
    public static volatile androidx.camera.core.impl.Quirks all;

    /* JADX INFO: renamed from: $r8$lambda$HfBMZLZ_-UgnnlH0dufyH-ifpDc, reason: not valid java name */
    public static /* synthetic */ void m103$r8$lambda$HfBMZLZ_UgnnlH0dufyHifpDc(androidx.camera.core.impl.QuirkSettings r0) {
            _init_$lambda$0(r0)
            return
    }

    static {
            androidx.camera.camera2.compat.quirk.DeviceQuirks r0 = new androidx.camera.camera2.compat.quirk.DeviceQuirks
            r0.<init>()
            androidx.camera.camera2.compat.quirk.DeviceQuirks.INSTANCE = r0
            androidx.camera.core.impl.QuirkSettingsHolder r0 = androidx.camera.core.impl.QuirkSettingsHolder.instance()
            java.util.concurrent.Executor r1 = androidx.camera.core.impl.utils.executor.CameraXExecutors.directExecutor()
            androidx.camera.camera2.compat.quirk.DeviceQuirks$$ExternalSyntheticLambda0 r2 = new androidx.camera.camera2.compat.quirk.DeviceQuirks$$ExternalSyntheticLambda0
            r2.<init>()
            r0.observe(r1, r2)
            return
    }

    private DeviceQuirks() {
            r0 = this;
            r0.<init>()
            return
    }

    private static final void _init_$lambda$0(androidx.camera.core.impl.QuirkSettings r2) {
            androidx.camera.core.impl.Quirks r0 = new androidx.camera.core.impl.Quirks
            androidx.camera.camera2.compat.quirk.DeviceQuirksLoader r1 = androidx.camera.camera2.compat.quirk.DeviceQuirksLoader.INSTANCE
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2)
            java.util.List r2 = r1.loadQuirks(r2)
            r0.<init>(r2)
            setAll(r0)
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r0 = "camera2 DeviceQuirks = "
            r2.<init>(r0)
            androidx.camera.core.impl.Quirks r0 = getAll()
            java.lang.String r0 = androidx.camera.core.impl.Quirks.toString(r0)
            r2.append(r0)
            java.lang.String r2 = r2.toString()
            java.lang.String r0 = "DeviceQuirks"
            androidx.camera.core.Logger.d(r0, r2)
            return
    }

    public static final androidx.camera.core.impl.Quirks getAll() {
            androidx.camera.core.impl.Quirks r0 = androidx.camera.camera2.compat.quirk.DeviceQuirks.all
            if (r0 == 0) goto L5
            return r0
        L5:
            java.lang.String r0 = "all"
            kotlin.jvm.internal.Intrinsics.throwUninitializedPropertyAccessException(r0)
            r0 = 0
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static /* synthetic */ void getAll$annotations() {
            return
    }

    public static final void setAll(androidx.camera.core.impl.Quirks r1) {
            java.lang.String r0 = "<set-?>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            androidx.camera.camera2.compat.quirk.DeviceQuirks.all = r1
            return
    }

    public final <T extends androidx.camera.core.impl.Quirk> T get(java.lang.Class<T> r2) {
            r1 = this;
            java.lang.String r0 = "quirkClass"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.core.impl.Quirks r0 = getAll()
            androidx.camera.core.impl.Quirk r2 = r0.get(r2)
            return r2
    }
}
