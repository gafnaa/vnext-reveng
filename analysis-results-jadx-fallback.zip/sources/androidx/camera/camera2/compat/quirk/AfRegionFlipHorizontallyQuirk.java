package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: AfRegionFlipHorizontallyQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/quirk/AfRegionFlipHorizontallyQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class AfRegionFlipHorizontallyQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: AfRegionFlipHorizontallyQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/AfRegionFlipHorizontallyQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean isEnabled(androidx.camera.camera2.pipe.CameraMetadata r3) {
                r2 = this;
                java.lang.String r0 = "cameraMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                if (r0 == 0) goto L2b
                int r0 = android.os.Build.VERSION.SDK_INT
                r1 = 33
                if (r0 >= r1) goto L2b
                android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.LENS_FACING
                java.lang.String r1 = "LENS_FACING"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                java.lang.Object r3 = r3.get(r0)
                java.lang.Integer r3 = (java.lang.Integer) r3
                if (r3 != 0) goto L23
                goto L2b
            L23:
                int r3 = r3.intValue()
                if (r3 != 0) goto L2b
                r3 = 1
                return r3
            L2b:
                r3 = 0
                return r3
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk.Companion = r0
            return
    }

    public AfRegionFlipHorizontallyQuirk() {
            r0 = this;
            r0.<init>()
            return
    }
}
