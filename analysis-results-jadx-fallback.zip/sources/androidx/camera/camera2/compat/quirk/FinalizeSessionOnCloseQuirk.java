package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: FinalizeSessionOnCloseQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/quirk/FinalizeSessionOnCloseQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class FinalizeSessionOnCloseQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: FinalizeSessionOnCloseQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0004\u001a\u00020\u0005J\r\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Landroidx/camera/camera2/compat/quirk/FinalizeSessionOnCloseQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "getBehavior", "Landroidx/camera/camera2/pipe/CameraGraph$Flags$FinalizeSessionOnCloseBehavior;", "getBehavior-Bm6Tfm4", "()I", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        /* JADX INFO: renamed from: getBehavior-Bm6Tfm4, reason: not valid java name */
        public final int m104getBehaviorBm6Tfm4() {
                r5 = this;
                java.lang.String r0 = android.os.Build.MODEL
                java.lang.String r1 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                java.util.Locale r1 = java.util.Locale.getDefault()
                java.lang.String r2 = "getDefault(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
                java.lang.String r0 = r0.toLowerCase(r1)
                java.lang.String r1 = "toLowerCase(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                r1 = 2
                r2 = 0
                java.lang.String r3 = "cph"
                r4 = 0
                boolean r0 = kotlin.text.StringsKt.startsWith$default(r0, r3, r4, r1, r2)
                if (r0 == 0) goto L2b
                androidx.camera.camera2.pipe.CameraGraph$Flags$FinalizeSessionOnCloseBehavior$Companion r0 = androidx.camera.camera2.pipe.CameraGraph.Flags.FinalizeSessionOnCloseBehavior.Companion
                int r0 = r0.m427getIMMEDIATEBm6Tfm4()
                return r0
            L2b:
                androidx.camera.camera2.pipe.CameraGraph$Flags$FinalizeSessionOnCloseBehavior$Companion r0 = androidx.camera.camera2.pipe.CameraGraph.Flags.FinalizeSessionOnCloseBehavior.Companion
                int r0 = r0.m428getOFFBm6Tfm4()
                return r0
        }

        public final boolean isEnabled() {
                r1 = this;
                r0 = 1
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk.Companion = r0
            return
    }

    public FinalizeSessionOnCloseQuirk() {
            r0 = this;
            r0.<init>()
            return
    }
}
