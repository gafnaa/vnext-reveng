package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: CameraNoResponseWhenEnablingFlashQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CameraNoResponseWhenEnablingFlashQuirk;", "Landroidx/camera/camera2/compat/quirk/UseTorchAsFlashQuirk;", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraNoResponseWhenEnablingFlashQuirk implements androidx.camera.camera2.compat.quirk.UseTorchAsFlashQuirk {
    private static final java.util.List<java.lang.String> AFFECTED_MODELS = null;
    public static final androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: CameraNoResponseWhenEnablingFlashQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\r"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CameraNoResponseWhenEnablingFlashQuirk$Companion;", "", "<init>", "()V", "AFFECTED_MODELS", "", "", "getAFFECTED_MODELS", "()Ljava/util/List;", "isEnabled", "", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final java.util.List<java.lang.String> getAFFECTED_MODELS() {
                r1 = this;
                java.util.List r0 = androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk.access$getAFFECTED_MODELS$cp()
                return r0
        }

        public final boolean isEnabled(androidx.camera.camera2.pipe.CameraMetadata r4) {
                r3 = this;
                java.lang.String r0 = "cameraMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
                java.util.List r0 = r3.getAFFECTED_MODELS()
                java.lang.String r1 = android.os.Build.MODEL
                java.lang.String r2 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
                java.util.Locale r2 = java.util.Locale.ROOT
                java.lang.String r1 = r1.toUpperCase(r2)
                java.lang.String r2 = "toUpperCase(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
                boolean r0 = r0.contains(r1)
                if (r0 == 0) goto L39
                android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.LENS_FACING
                java.lang.String r1 = "LENS_FACING"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                java.lang.Object r4 = r4.get(r0)
                java.lang.Integer r4 = (java.lang.Integer) r4
                if (r4 != 0) goto L31
                goto L39
            L31:
                int r4 = r4.intValue()
                r0 = 1
                if (r4 != r0) goto L39
                return r0
            L39:
                r4 = 0
                return r4
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk.Companion = r0
            java.lang.String r20 = "SM-J510FN"
            java.lang.String r21 = "VIVO 1610"
            java.lang.String r2 = "SM-N9200"
            java.lang.String r3 = "SM-N9208"
            java.lang.String r4 = "SAMSUNG-SM-N920A"
            java.lang.String r5 = "SM-N920C"
            java.lang.String r6 = "SM-N920F"
            java.lang.String r7 = "SM-N920G"
            java.lang.String r8 = "SM-N920I"
            java.lang.String r9 = "SM-N920K"
            java.lang.String r10 = "SM-N920L"
            java.lang.String r11 = "SM-N920P"
            java.lang.String r12 = "SM-N920R4"
            java.lang.String r13 = "SM-N920R6"
            java.lang.String r14 = "SM-N920R7"
            java.lang.String r15 = "SM-N920S"
            java.lang.String r16 = "SM-N920T"
            java.lang.String r17 = "SM-N920V"
            java.lang.String r18 = "SM-N920W8"
            java.lang.String r19 = "SM-N920X"
            java.lang.String[] r0 = new java.lang.String[]{r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20, r21}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk.AFFECTED_MODELS = r0
            return
    }

    public CameraNoResponseWhenEnablingFlashQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ java.util.List access$getAFFECTED_MODELS$cp() {
            java.util.List<java.lang.String> r0 = androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk.AFFECTED_MODELS
            return r0
    }
}
