package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: CameraQuirks.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u0000 \u000e2\u00020\u0001:\u0001\u000eB\u001b\b\u0007\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u0010\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001b\u0010\b\u001a\u00020\t8FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\n\u0010\u000b¨\u0006\u000f"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CameraQuirks;", "", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "streamConfigurationMapCompat", "Landroidx/camera/camera2/compat/StreamConfigurationMapCompat;", "<init>", "(Landroidx/camera/camera2/pipe/CameraMetadata;Landroidx/camera/camera2/compat/StreamConfigurationMapCompat;)V", "quirks", "Landroidx/camera/core/impl/Quirks;", "getQuirks", "()Landroidx/camera/core/impl/Quirks;", "quirks$delegate", "Lkotlin/Lazy;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CameraQuirks {
    public static final androidx.camera.camera2.compat.quirk.CameraQuirks.Companion Companion = null;
    private static final java.lang.String TAG = "CameraQuirks";
    private final androidx.camera.camera2.pipe.CameraMetadata cameraMetadata;
    private final kotlin.Lazy quirks$delegate;
    private final androidx.camera.camera2.compat.StreamConfigurationMapCompat streamConfigurationMapCompat;

    /* JADX INFO: compiled from: CameraQuirks.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CameraQuirks$Companion;", "", "<init>", "()V", "TAG", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }
    }

    /* JADX INFO: renamed from: $r8$lambda$3nXzTEXW5hJTW6N-AsrAgNfo7qI, reason: not valid java name */
    public static /* synthetic */ androidx.camera.core.impl.Quirks m102$r8$lambda$3nXzTEXW5hJTW6NAsrAgNfo7qI(androidx.camera.camera2.compat.quirk.CameraQuirks r0) {
            androidx.camera.core.impl.Quirks r0 = quirks_delegate$lambda$0(r0)
            return r0
    }

    static {
            androidx.camera.camera2.compat.quirk.CameraQuirks$Companion r0 = new androidx.camera.camera2.compat.quirk.CameraQuirks$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.CameraQuirks.Companion = r0
            return
    }

    @javax.inject.Inject
    public CameraQuirks(androidx.camera.camera2.pipe.CameraMetadata r2, androidx.camera.camera2.compat.StreamConfigurationMapCompat r3) {
            r1 = this;
            java.lang.String r0 = "streamConfigurationMapCompat"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r1.<init>()
            r1.cameraMetadata = r2
            r1.streamConfigurationMapCompat = r3
            androidx.camera.camera2.compat.quirk.CameraQuirks$$ExternalSyntheticLambda0 r2 = new androidx.camera.camera2.compat.quirk.CameraQuirks$$ExternalSyntheticLambda0
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.quirks$delegate = r2
            return
    }

    private static final androidx.camera.core.impl.Quirks quirks_delegate$lambda$0(androidx.camera.camera2.compat.quirk.CameraQuirks r5) {
            androidx.camera.core.impl.QuirkSettingsHolder r0 = androidx.camera.core.impl.QuirkSettingsHolder.instance()
            androidx.camera.core.impl.QuirkSettings r0 = r0.get()
            java.lang.String r1 = "get(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.List r1 = (java.util.List) r1
            androidx.camera.camera2.pipe.CameraMetadata r2 = r5.cameraMetadata
            if (r2 != 0) goto L31
            androidx.camera.camera2.impl.Camera2Logger r5 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r5 = "CXCP"
            boolean r5 = androidx.camera.core.Logger.isErrorEnabled(r5)
            if (r5 == 0) goto L2b
            java.lang.String r5 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r0 = "Failed to enable quirks: camera metadata injection failed"
            android.util.Log.e(r5, r0)
        L2b:
            androidx.camera.core.impl.Quirks r5 = new androidx.camera.core.impl.Quirks
            r5.<init>(r1)
            return r5
        L31:
            java.lang.Class<androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk> r2 = androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk.class
            androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L4b
            androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk r2 = new androidx.camera.camera2.compat.quirk.AeFpsRangeLegacyQuirk
            androidx.camera.camera2.pipe.CameraMetadata r3 = r5.cameraMetadata
            r2.<init>(r3)
            r1.add(r2)
        L4b:
            java.lang.Class<androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk> r2 = androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk.class
            androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L63
            androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk r2 = new androidx.camera.camera2.compat.quirk.AfRegionFlipHorizontallyQuirk
            r2.<init>()
            r1.add(r2)
        L63:
            java.lang.Class<androidx.camera.camera2.compat.quirk.AspectRatioLegacyApi21Quirk> r2 = androidx.camera.camera2.compat.quirk.AspectRatioLegacyApi21Quirk.class
            androidx.camera.camera2.compat.quirk.AspectRatioLegacyApi21Quirk$Companion r3 = androidx.camera.camera2.compat.quirk.AspectRatioLegacyApi21Quirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L7b
            androidx.camera.camera2.compat.quirk.AspectRatioLegacyApi21Quirk r2 = new androidx.camera.camera2.compat.quirk.AspectRatioLegacyApi21Quirk
            r2.<init>()
            r1.add(r2)
        L7b:
            java.lang.Class<androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk> r2 = androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk.class
            androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L95
            androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk r2 = new androidx.camera.camera2.compat.quirk.CamcorderProfileResolutionQuirk
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r3 = r5.streamConfigurationMapCompat
            r2.<init>(r3)
            r1.add(r2)
        L95:
            java.lang.Class<androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk> r2 = androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk.class
            androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto Lad
            androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk r2 = new androidx.camera.camera2.compat.quirk.CameraNoResponseWhenEnablingFlashQuirk
            r2.<init>()
            r1.add(r2)
        Lad:
            java.lang.Class<androidx.camera.camera2.compat.quirk.CaptureSessionStuckQuirk> r2 = androidx.camera.camera2.compat.quirk.CaptureSessionStuckQuirk.class
            androidx.camera.camera2.compat.quirk.CaptureSessionStuckQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.CaptureSessionStuckQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto Lc3
            androidx.camera.camera2.compat.quirk.CaptureSessionStuckQuirk r2 = new androidx.camera.camera2.compat.quirk.CaptureSessionStuckQuirk
            r2.<init>()
            r1.add(r2)
        Lc3:
            java.lang.Class<androidx.camera.camera2.compat.quirk.CloseCaptureSessionOnVideoQuirk> r2 = androidx.camera.camera2.compat.quirk.CloseCaptureSessionOnVideoQuirk.class
            androidx.camera.camera2.compat.quirk.CloseCaptureSessionOnVideoQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.CloseCaptureSessionOnVideoQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto Ld9
            androidx.camera.camera2.compat.quirk.CloseCaptureSessionOnVideoQuirk r2 = new androidx.camera.camera2.compat.quirk.CloseCaptureSessionOnVideoQuirk
            r2.<init>()
            r1.add(r2)
        Ld9:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk> r2 = androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk.class
            androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto Lf1
            androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk r2 = new androidx.camera.camera2.compat.quirk.ConfigureSurfaceToSecondarySessionFailQuirk
            r2.<init>()
            r1.add(r2)
        Lf1:
            java.lang.Class<androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk> r2 = androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk.class
            androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L107
            androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk r2 = new androidx.camera.camera2.compat.quirk.FinalizeSessionOnCloseQuirk
            r2.<init>()
            r1.add(r2)
        L107:
            java.lang.Class<androidx.camera.camera2.compat.quirk.FlashTooSlowQuirk> r2 = androidx.camera.camera2.compat.quirk.FlashTooSlowQuirk.class
            androidx.camera.camera2.compat.quirk.FlashTooSlowQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.FlashTooSlowQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L11f
            androidx.camera.camera2.compat.quirk.FlashTooSlowQuirk r2 = new androidx.camera.camera2.compat.quirk.FlashTooSlowQuirk
            r2.<init>()
            r1.add(r2)
        L11f:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ImageCaptureFailWithAutoFlashQuirk> r2 = androidx.camera.camera2.compat.quirk.ImageCaptureFailWithAutoFlashQuirk.class
            androidx.camera.camera2.compat.quirk.ImageCaptureFailWithAutoFlashQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.ImageCaptureFailWithAutoFlashQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L137
            androidx.camera.camera2.compat.quirk.ImageCaptureFailWithAutoFlashQuirk r2 = new androidx.camera.camera2.compat.quirk.ImageCaptureFailWithAutoFlashQuirk
            r2.<init>()
            r1.add(r2)
        L137:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ImageCaptureFlashNotFireQuirk> r2 = androidx.camera.camera2.compat.quirk.ImageCaptureFlashNotFireQuirk.class
            androidx.camera.camera2.compat.quirk.ImageCaptureFlashNotFireQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.ImageCaptureFlashNotFireQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L14f
            androidx.camera.camera2.compat.quirk.ImageCaptureFlashNotFireQuirk r2 = new androidx.camera.camera2.compat.quirk.ImageCaptureFlashNotFireQuirk
            r2.<init>()
            r1.add(r2)
        L14f:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ImageCaptureWashedOutImageQuirk> r2 = androidx.camera.camera2.compat.quirk.ImageCaptureWashedOutImageQuirk.class
            androidx.camera.camera2.compat.quirk.ImageCaptureWashedOutImageQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.ImageCaptureWashedOutImageQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L167
            androidx.camera.camera2.compat.quirk.ImageCaptureWashedOutImageQuirk r2 = new androidx.camera.camera2.compat.quirk.ImageCaptureWashedOutImageQuirk
            r2.<init>()
            r1.add(r2)
        L167:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ImageCaptureWithFlashUnderexposureQuirk> r2 = androidx.camera.camera2.compat.quirk.ImageCaptureWithFlashUnderexposureQuirk.class
            androidx.camera.camera2.compat.quirk.ImageCaptureWithFlashUnderexposureQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.ImageCaptureWithFlashUnderexposureQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L17f
            androidx.camera.camera2.compat.quirk.ImageCaptureWithFlashUnderexposureQuirk r2 = new androidx.camera.camera2.compat.quirk.ImageCaptureWithFlashUnderexposureQuirk
            r2.<init>()
            r1.add(r2)
        L17f:
            java.lang.Class<androidx.camera.camera2.compat.quirk.JpegHalCorruptImageQuirk> r2 = androidx.camera.camera2.compat.quirk.JpegHalCorruptImageQuirk.class
            androidx.camera.camera2.compat.quirk.JpegHalCorruptImageQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.JpegHalCorruptImageQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L195
            androidx.camera.camera2.compat.quirk.JpegHalCorruptImageQuirk r2 = new androidx.camera.camera2.compat.quirk.JpegHalCorruptImageQuirk
            r2.<init>()
            r1.add(r2)
        L195:
            java.lang.Class<androidx.camera.camera2.compat.quirk.JpegCaptureDownsizingQuirk> r2 = androidx.camera.camera2.compat.quirk.JpegCaptureDownsizingQuirk.class
            androidx.camera.camera2.compat.quirk.JpegCaptureDownsizingQuirk r3 = androidx.camera.camera2.compat.quirk.JpegCaptureDownsizingQuirk.INSTANCE
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L1aa
            androidx.camera.camera2.compat.quirk.JpegCaptureDownsizingQuirk r2 = androidx.camera.camera2.compat.quirk.JpegCaptureDownsizingQuirk.INSTANCE
            r1.add(r2)
        L1aa:
            java.lang.Class<androidx.camera.camera2.compat.quirk.PreviewOrientationIncorrectQuirk> r2 = androidx.camera.camera2.compat.quirk.PreviewOrientationIncorrectQuirk.class
            androidx.camera.camera2.compat.quirk.PreviewOrientationIncorrectQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.PreviewOrientationIncorrectQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L1c2
            androidx.camera.camera2.compat.quirk.PreviewOrientationIncorrectQuirk r2 = new androidx.camera.camera2.compat.quirk.PreviewOrientationIncorrectQuirk
            r2.<init>()
            r1.add(r2)
        L1c2:
            java.lang.Class<androidx.camera.camera2.compat.quirk.TextureViewIsClosedQuirk> r2 = androidx.camera.camera2.compat.quirk.TextureViewIsClosedQuirk.class
            androidx.camera.camera2.compat.quirk.TextureViewIsClosedQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.TextureViewIsClosedQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L1da
            androidx.camera.camera2.compat.quirk.TextureViewIsClosedQuirk r2 = new androidx.camera.camera2.compat.quirk.TextureViewIsClosedQuirk
            r2.<init>()
            r1.add(r2)
        L1da:
            java.lang.Class<androidx.camera.camera2.compat.quirk.TorchFlashRequiredFor3aUpdateQuirk> r2 = androidx.camera.camera2.compat.quirk.TorchFlashRequiredFor3aUpdateQuirk.class
            androidx.camera.camera2.compat.quirk.TorchFlashRequiredFor3aUpdateQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.TorchFlashRequiredFor3aUpdateQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L1f4
            androidx.camera.camera2.compat.quirk.TorchFlashRequiredFor3aUpdateQuirk r2 = new androidx.camera.camera2.compat.quirk.TorchFlashRequiredFor3aUpdateQuirk
            androidx.camera.camera2.pipe.CameraMetadata r3 = r5.cameraMetadata
            r2.<init>(r3)
            r1.add(r2)
        L1f4:
            java.lang.Class<androidx.camera.camera2.compat.quirk.YuvImageOnePixelShiftQuirk> r2 = androidx.camera.camera2.compat.quirk.YuvImageOnePixelShiftQuirk.class
            androidx.camera.camera2.compat.quirk.YuvImageOnePixelShiftQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.YuvImageOnePixelShiftQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L20a
            androidx.camera.camera2.compat.quirk.YuvImageOnePixelShiftQuirk r2 = new androidx.camera.camera2.compat.quirk.YuvImageOnePixelShiftQuirk
            r2.<init>()
            r1.add(r2)
        L20a:
            java.lang.Class<androidx.camera.camera2.compat.quirk.PreviewStretchWhenVideoCaptureIsBoundQuirk> r2 = androidx.camera.camera2.compat.quirk.PreviewStretchWhenVideoCaptureIsBoundQuirk.class
            androidx.camera.camera2.compat.quirk.PreviewStretchWhenVideoCaptureIsBoundQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.PreviewStretchWhenVideoCaptureIsBoundQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L220
            androidx.camera.camera2.compat.quirk.PreviewStretchWhenVideoCaptureIsBoundQuirk r2 = new androidx.camera.camera2.compat.quirk.PreviewStretchWhenVideoCaptureIsBoundQuirk
            r2.<init>()
            r1.add(r2)
        L220:
            java.lang.Class<androidx.camera.camera2.compat.quirk.PreviewDelayWhenVideoCaptureIsBoundQuirk> r2 = androidx.camera.camera2.compat.quirk.PreviewDelayWhenVideoCaptureIsBoundQuirk.class
            androidx.camera.camera2.compat.quirk.PreviewDelayWhenVideoCaptureIsBoundQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.PreviewDelayWhenVideoCaptureIsBoundQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L236
            androidx.camera.camera2.compat.quirk.PreviewDelayWhenVideoCaptureIsBoundQuirk r2 = new androidx.camera.camera2.compat.quirk.PreviewDelayWhenVideoCaptureIsBoundQuirk
            r2.<init>()
            r1.add(r2)
        L236:
            java.lang.Class<androidx.camera.camera2.compat.quirk.QuickSuccessiveImageCaptureFailsRepeatingRequestQuirk> r2 = androidx.camera.camera2.compat.quirk.QuickSuccessiveImageCaptureFailsRepeatingRequestQuirk.class
            androidx.camera.camera2.compat.quirk.QuickSuccessiveImageCaptureFailsRepeatingRequestQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.QuickSuccessiveImageCaptureFailsRepeatingRequestQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L24e
            androidx.camera.camera2.compat.quirk.QuickSuccessiveImageCaptureFailsRepeatingRequestQuirk r2 = new androidx.camera.camera2.compat.quirk.QuickSuccessiveImageCaptureFailsRepeatingRequestQuirk
            r2.<init>()
            r1.add(r2)
        L24e:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ImageCaptureFailedWhenVideoCaptureIsBoundQuirk> r2 = androidx.camera.camera2.compat.quirk.ImageCaptureFailedWhenVideoCaptureIsBoundQuirk.class
            androidx.camera.camera2.compat.quirk.ImageCaptureFailedWhenVideoCaptureIsBoundQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.ImageCaptureFailedWhenVideoCaptureIsBoundQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L264
            androidx.camera.camera2.compat.quirk.ImageCaptureFailedWhenVideoCaptureIsBoundQuirk r2 = new androidx.camera.camera2.compat.quirk.ImageCaptureFailedWhenVideoCaptureIsBoundQuirk
            r2.<init>()
            r1.add(r2)
        L264:
            java.lang.Class<androidx.camera.camera2.compat.quirk.TemporalNoiseQuirk> r2 = androidx.camera.camera2.compat.quirk.TemporalNoiseQuirk.class
            androidx.camera.camera2.compat.quirk.TemporalNoiseQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.TemporalNoiseQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r4 = r5.cameraMetadata
            boolean r3 = r3.isEnabled(r4)
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L27c
            androidx.camera.camera2.compat.quirk.TemporalNoiseQuirk r2 = new androidx.camera.camera2.compat.quirk.TemporalNoiseQuirk
            r2.<init>()
            r1.add(r2)
        L27c:
            java.lang.Class<androidx.camera.camera2.compat.quirk.ImageCaptureFailedForVideoSnapshotQuirk> r2 = androidx.camera.camera2.compat.quirk.ImageCaptureFailedForVideoSnapshotQuirk.class
            androidx.camera.camera2.compat.quirk.ImageCaptureFailedForVideoSnapshotQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.ImageCaptureFailedForVideoSnapshotQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L292
            androidx.camera.camera2.compat.quirk.ImageCaptureFailedForVideoSnapshotQuirk r2 = new androidx.camera.camera2.compat.quirk.ImageCaptureFailedForVideoSnapshotQuirk
            r2.<init>()
            r1.add(r2)
        L292:
            java.lang.Class<androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk> r2 = androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.class
            androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.Companion
            boolean r3 = r3.isEnabled()
            boolean r2 = r0.shouldEnableQuirk(r2, r3)
            if (r2 == 0) goto L2a8
            androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk r2 = new androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk
            r2.<init>()
            r1.add(r2)
        L2a8:
            java.lang.Class<androidx.camera.camera2.compat.quirk.UltraWideFlashCaptureUnderexposureQuirk> r2 = androidx.camera.camera2.compat.quirk.UltraWideFlashCaptureUnderexposureQuirk.class
            androidx.camera.camera2.compat.quirk.UltraWideFlashCaptureUnderexposureQuirk$Companion r3 = androidx.camera.camera2.compat.quirk.UltraWideFlashCaptureUnderexposureQuirk.Companion
            androidx.camera.camera2.pipe.CameraMetadata r5 = r5.cameraMetadata
            boolean r5 = r3.isEnabled(r5)
            boolean r5 = r0.shouldEnableQuirk(r2, r5)
            if (r5 == 0) goto L2c0
            androidx.camera.camera2.compat.quirk.UltraWideFlashCaptureUnderexposureQuirk r5 = new androidx.camera.camera2.compat.quirk.UltraWideFlashCaptureUnderexposureQuirk
            r5.<init>()
            r1.add(r5)
        L2c0:
            androidx.camera.core.impl.Quirks r5 = new androidx.camera.core.impl.Quirks
            r5.<init>(r1)
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "camera2 CameraQuirks = "
            r0.<init>(r1)
            java.lang.String r1 = androidx.camera.core.impl.Quirks.toString(r5)
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.String r1 = "CameraQuirks"
            androidx.camera.core.Logger.d(r1, r0)
            return r5
    }

    public final androidx.camera.core.impl.Quirks getQuirks() {
            r1 = this;
            kotlin.Lazy r0 = r1.quirks$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.camera.core.impl.Quirks r0 = (androidx.camera.core.impl.Quirks) r0
            return r0
    }
}
