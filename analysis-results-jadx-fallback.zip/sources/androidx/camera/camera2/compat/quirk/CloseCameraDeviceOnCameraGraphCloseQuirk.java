package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: CloseCameraDeviceOnCameraGraphCloseQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0007\u0018\u0000 \u00072\u00020\u0001:\u0001\u0007B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CloseCameraDeviceOnCameraGraphCloseQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "shouldCloseCameraDevice", "", "isExtensions", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CloseCameraDeviceOnCameraGraphCloseQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.Companion Companion = null;
    private static final boolean isSamsungExynos7570Device = false;
    private static final boolean isSamsungExynos7870Device = false;
    private static final boolean isSamsungProblematicDevice = false;
    private static final boolean isSonyProblematicDevice = false;
    private static final boolean isXiaomiProblematicDevice = false;

    /* JADX INFO: compiled from: CloseCameraDeviceOnCameraGraphCloseQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0006\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0007R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/CloseCameraDeviceOnCameraGraphCloseQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "isSamsungExynos7570Device", "isSamsungExynos7870Device", "isXiaomiProblematicDevice", "isSonyProblematicDevice", "isSamsungProblematicDevice", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        @kotlin.jvm.JvmStatic
        public final boolean isEnabled() {
                r3 = this;
                boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.access$isSamsungExynos7570Device$cp()
                r1 = 1
                if (r0 != 0) goto L51
                boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.access$isSamsungExynos7870Device$cp()
                if (r0 == 0) goto Le
                goto L51
            Le:
                int r0 = android.os.Build.VERSION.SDK_INT
                r2 = 30
                if (r2 > r0) goto L31
                r2 = 34
                if (r0 >= r2) goto L31
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isOppoDevice()
                if (r0 != 0) goto L30
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isOnePlusDevice()
                if (r0 != 0) goto L30
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isRealmeDevice()
                if (r0 == 0) goto L31
            L30:
                return r1
            L31:
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isVivoDevice()
                if (r0 == 0) goto L3a
                return r1
            L3a:
                boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.access$isXiaomiProblematicDevice$cp()
                if (r0 == 0) goto L41
                return r1
            L41:
                boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.access$isSamsungProblematicDevice$cp()
                if (r0 == 0) goto L48
                return r1
            L48:
                boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.access$isSonyProblematicDevice$cp()
                if (r0 == 0) goto L4f
                return r1
            L4f:
                r0 = 0
                return r0
            L51:
                return r1
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.Companion = r0
            java.lang.String r0 = android.os.Build.HARDWARE
            java.lang.String r1 = "samsungexynos7570"
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r1)
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungExynos7570Device = r0
            java.lang.String r0 = android.os.Build.HARDWARE
            java.lang.String r1 = "samsungexynos7870"
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r1)
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungExynos7870Device = r0
            androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
            boolean r0 = r0.isXiaomiDevice()
            java.lang.String r1 = "DEVICE"
            r2 = 0
            r3 = 1
            if (r0 == 0) goto L48
            java.lang.String r0 = "aurora"
            java.lang.String r4 = "houji"
            java.lang.String[] r0 = new java.lang.String[]{r0, r4}
            java.lang.String r4 = android.os.Build.DEVICE
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r1)
            java.util.Locale r5 = java.util.Locale.ROOT
            java.lang.String r4 = r4.toLowerCase(r5)
            java.lang.String r5 = "toLowerCase(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r5)
            boolean r0 = kotlin.collections.ArraysKt.contains(r0, r4)
            if (r0 == 0) goto L48
            r0 = r3
            goto L49
        L48:
            r0 = r2
        L49:
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isXiaomiProblematicDevice = r0
            androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
            boolean r0 = r0.isSonyDevice()
            if (r0 == 0) goto L8e
            java.lang.String r0 = "SO"
            java.lang.String r4 = "A301SO"
            java.lang.String r5 = "XQ-DQ"
            java.lang.String[] r0 = new java.lang.String[]{r5, r0, r4}
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            boolean r4 = r0 instanceof java.util.Collection
            if (r4 == 0) goto L71
            r4 = r0
            java.util.Collection r4 = (java.util.Collection) r4
            boolean r4 = r4.isEmpty()
            if (r4 == 0) goto L71
            goto L8e
        L71:
            java.util.Iterator r0 = r0.iterator()
        L75:
            boolean r4 = r0.hasNext()
            if (r4 == 0) goto L8e
            java.lang.Object r4 = r0.next()
            java.lang.String r4 = (java.lang.String) r4
            java.lang.String r5 = android.os.Build.DEVICE
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r1)
            boolean r4 = kotlin.text.StringsKt.startsWith(r5, r4, r3)
            if (r4 == 0) goto L75
            r0 = r3
            goto L8f
        L8e:
            r0 = r2
        L8f:
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSonyProblematicDevice = r0
            androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
            boolean r0 = r0.isSamsungDevice()
            if (r0 == 0) goto La6
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 31
            if (r0 < r1) goto La6
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 34
            if (r0 > r1) goto La6
            r2 = r3
        La6:
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungProblematicDevice = r2
            return
    }

    public CloseCameraDeviceOnCameraGraphCloseQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ boolean access$isSamsungExynos7570Device$cp() {
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungExynos7570Device
            return r0
    }

    public static final /* synthetic */ boolean access$isSamsungExynos7870Device$cp() {
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungExynos7870Device
            return r0
    }

    public static final /* synthetic */ boolean access$isSamsungProblematicDevice$cp() {
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungProblematicDevice
            return r0
    }

    public static final /* synthetic */ boolean access$isSonyProblematicDevice$cp() {
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSonyProblematicDevice
            return r0
    }

    public static final /* synthetic */ boolean access$isXiaomiProblematicDevice$cp() {
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isXiaomiProblematicDevice
            return r0
    }

    @kotlin.jvm.JvmStatic
    public static final boolean isEnabled() {
            androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.Companion
            boolean r0 = r0.isEnabled()
            return r0
    }

    public final boolean shouldCloseCameraDevice(boolean r2) {
            r1 = this;
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isXiaomiProblematicDevice
            if (r0 != 0) goto L12
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungProblematicDevice
            if (r0 == 0) goto L11
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungExynos7570Device
            if (r0 != 0) goto L11
            boolean r0 = androidx.camera.camera2.compat.quirk.CloseCameraDeviceOnCameraGraphCloseQuirk.isSamsungExynos7870Device
            if (r0 != 0) goto L11
            goto L12
        L11:
            r2 = 1
        L12:
            return r2
    }
}
