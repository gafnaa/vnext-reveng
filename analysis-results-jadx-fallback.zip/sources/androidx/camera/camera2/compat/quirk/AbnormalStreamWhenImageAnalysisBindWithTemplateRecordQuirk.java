package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0007\u0018\u0000 \u00062\u00020\u0001:\u0001\u0006B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0007"}, d2 = {"Landroidx/camera/camera2/compat/quirk/AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk;", "Landroidx/camera/camera2/compat/quirk/CaptureIntentPreviewQuirk;", "<init>", "()V", "workaroundByCaptureIntentPreview", "", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk implements androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk {
    public static final androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0004\u001a\u00020\u0005R\u0014\u0010\u0006\u001a\u00020\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/quirk/AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "isSamsungM55", "()Z", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public static final /* synthetic */ boolean access$isSamsungM55(androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.Companion r0) {
                boolean r0 = r0.isSamsungM55()
                return r0
        }

        private final boolean isSamsungM55() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                if (r0 == 0) goto L14
                java.lang.String r0 = android.os.Build.DEVICE
                java.lang.String r1 = "m55xq"
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L14
                return r2
            L14:
                r0 = 0
                return r0
        }

        public final boolean isEnabled() {
                r1 = this;
                boolean r0 = r1.isSamsungM55()
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.Companion = r0
            return
    }

    public AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    @Override // androidx.camera.camera2.compat.quirk.CaptureIntentPreviewQuirk
    public boolean workaroundByCaptureIntentPreview() {
            r1 = this;
            androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.Companion
            boolean r0 = androidx.camera.camera2.compat.quirk.AbnormalStreamWhenImageAnalysisBindWithTemplateRecordQuirk.Companion.access$isSamsungM55(r0)
            return r0
    }
}
