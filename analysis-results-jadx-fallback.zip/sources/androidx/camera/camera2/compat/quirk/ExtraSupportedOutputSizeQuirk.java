package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: ExtraSupportedOutputSizeQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u0000 \u00112\u00020\u0001:\u0001\u0011B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0019\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0002\u0010\tJ%\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\"\u0004\b\u0000\u0010\n2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u0002H\n0\f¢\u0006\u0002\u0010\rR\u001a\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010¨\u0006\u0012"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ExtraSupportedOutputSizeQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "getExtraSupportedResolutions", "", "Landroid/util/Size;", "format", "", "(I)[Landroid/util/Size;", "T", "klass", "Ljava/lang/Class;", "(Ljava/lang/Class;)[Landroid/util/Size;", "motoE5PlayExtraSupportedResolutions", "getMotoE5PlayExtraSupportedResolutions", "()[Landroid/util/Size;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ExtraSupportedOutputSizeQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk.Companion Companion = null;

    /* JADX INFO: compiled from: ExtraSupportedOutputSizeQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0004\u001a\u00020\u0005R\u0014\u0010\u0006\u001a\u00020\u00058@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ExtraSupportedOutputSizeQuirk$Companion;", "", "<init>", "()V", "isEnabled", "", "isMotoE5Play", "isMotoE5Play$camera_camera2", "()Z", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean isEnabled() {
                r1 = this;
                boolean r0 = r1.isMotoE5Play$camera_camera2()
                return r0
        }

        public final boolean isMotoE5Play$camera_camera2() {
                r3 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isMotorolaDevice()
                if (r0 == 0) goto L14
                java.lang.String r0 = "moto e5 play"
                java.lang.String r1 = android.os.Build.MODEL
                r2 = 1
                boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
                if (r0 == 0) goto L14
                return r2
            L14:
                r0 = 0
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk.Companion = r0
            return
    }

    public ExtraSupportedOutputSizeQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    private final android.util.Size[] getMotoE5PlayExtraSupportedResolutions() {
            r4 = this;
            android.util.Size r0 = new android.util.Size
            r1 = 1440(0x5a0, float:2.018E-42)
            r2 = 1080(0x438, float:1.513E-42)
            r0.<init>(r1, r2)
            android.util.Size r1 = new android.util.Size
            r2 = 960(0x3c0, float:1.345E-42)
            r3 = 720(0x2d0, float:1.009E-42)
            r1.<init>(r2, r3)
            android.util.Size[] r0 = new android.util.Size[]{r0, r1}
            return r0
    }

    public final android.util.Size[] getExtraSupportedResolutions(int r2) {
            r1 = this;
            r0 = 34
            if (r2 != r0) goto L11
            androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk.Companion
            boolean r2 = r2.isMotoE5Play$camera_camera2()
            if (r2 == 0) goto L11
            android.util.Size[] r2 = r1.getMotoE5PlayExtraSupportedResolutions()
            return r2
        L11:
            r2 = 0
            android.util.Size[] r2 = new android.util.Size[r2]
            return r2
    }

    public final <T> android.util.Size[] getExtraSupportedResolutions(java.lang.Class<T> r2) {
            r1 = this;
            java.lang.String r0 = "klass"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            boolean r2 = android.hardware.camera2.params.StreamConfigurationMap.isOutputSupportedFor(r2)
            if (r2 == 0) goto L18
            androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk$Companion r2 = androidx.camera.camera2.compat.quirk.ExtraSupportedOutputSizeQuirk.Companion
            boolean r2 = r2.isMotoE5Play$camera_camera2()
            if (r2 == 0) goto L18
            android.util.Size[] r2 = r1.getMotoE5PlayExtraSupportedResolutions()
            return r2
        L18:
            r2 = 0
            android.util.Size[] r2 = new android.util.Size[r2]
            return r2
    }
}
