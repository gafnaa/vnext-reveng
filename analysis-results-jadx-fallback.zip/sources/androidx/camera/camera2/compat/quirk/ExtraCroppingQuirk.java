package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: ExtraCroppingQuirk.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \b2\u00020\u0001:\u0001\bB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\t"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ExtraCroppingQuirk;", "Landroidx/camera/core/impl/Quirk;", "<init>", "()V", "getVerifiedResolution", "Landroid/util/Size;", "configType", "Landroidx/camera/core/impl/SurfaceConfig$ConfigType;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ExtraCroppingQuirk implements androidx.camera.core.impl.Quirk {
    public static final androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.Companion Companion = null;
    private static final java.util.Map<java.lang.String, android.util.Range<java.lang.Integer>> SAMSUNG_DISTORTION_MODELS_TO_API_LEVEL_MAP = null;

    /* JADX INFO: compiled from: ExtraCroppingQuirk.kt */
    @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\t\u001a\u00020\nR\"\u0010\u0004\u001a\u0016\u0012\u0004\u0012\u00020\u0006\u0012\f\u0012\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\u00020\n8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\f\u0010\r¨\u0006\u000e"}, d2 = {"Landroidx/camera/camera2/compat/quirk/ExtraCroppingQuirk$Companion;", "", "<init>", "()V", "SAMSUNG_DISTORTION_MODELS_TO_API_LEVEL_MAP", "", "", "Landroid/util/Range;", "", "isEnabled", "", "isSamsungDistortion", "isSamsungDistortion$camera_camera2", "()Z", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final boolean isEnabled() {
                r1 = this;
                boolean r0 = r1.isSamsungDistortion$camera_camera2()
                return r0
        }

        public final boolean isSamsungDistortion$camera_camera2() {
                r4 = this;
                androidx.camera.camera2.compat.quirk.Device r0 = androidx.camera.camera2.compat.quirk.Device.INSTANCE
                boolean r0 = r0.isSamsungDevice()
                if (r0 == 0) goto L4d
                java.util.Map r0 = androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.access$getSAMSUNG_DISTORTION_MODELS_TO_API_LEVEL_MAP$cp()
                java.lang.String r1 = android.os.Build.MODEL
                java.lang.String r2 = "MODEL"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
                java.util.Locale r3 = java.util.Locale.ROOT
                java.lang.String r1 = r1.toUpperCase(r3)
                java.lang.String r3 = "toUpperCase(...)"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r3)
                boolean r0 = r0.containsKey(r1)
                if (r0 == 0) goto L4d
                java.util.Map r0 = androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.access$getSAMSUNG_DISTORTION_MODELS_TO_API_LEVEL_MAP$cp()
                java.lang.String r1 = android.os.Build.MODEL
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
                java.util.Locale r2 = java.util.Locale.ROOT
                java.lang.String r1 = r1.toUpperCase(r2)
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r3)
                java.lang.Object r0 = r0.get(r1)
                android.util.Range r0 = (android.util.Range) r0
                if (r0 == 0) goto L4b
                int r1 = android.os.Build.VERSION.SDK_INT
                java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
                java.lang.Comparable r1 = (java.lang.Comparable) r1
                boolean r0 = r0.contains(r1)
                return r0
            L4b:
                r0 = 1
                return r0
            L4d:
                r0 = 0
                return r0
        }
    }

    /* JADX INFO: compiled from: ExtraCroppingQuirk.kt */
    @kotlin.Metadata(k = 3, mv = {2, 1, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0 = null;

        static {
                androidx.camera.core.impl.SurfaceConfig$ConfigType[] r0 = androidx.camera.core.impl.SurfaceConfig.ConfigType.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                androidx.camera.core.impl.SurfaceConfig$ConfigType r1 = androidx.camera.core.impl.SurfaceConfig.ConfigType.PRIV     // Catch: java.lang.NoSuchFieldError -> L10
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L10
                r2 = 1
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L10
            L10:
                androidx.camera.core.impl.SurfaceConfig$ConfigType r1 = androidx.camera.core.impl.SurfaceConfig.ConfigType.YUV     // Catch: java.lang.NoSuchFieldError -> L19
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L19
                r2 = 2
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L19
            L19:
                androidx.camera.core.impl.SurfaceConfig$ConfigType r1 = androidx.camera.core.impl.SurfaceConfig.ConfigType.JPEG     // Catch: java.lang.NoSuchFieldError -> L22
                int r1 = r1.ordinal()     // Catch: java.lang.NoSuchFieldError -> L22
                r2 = 3
                r0[r1] = r2     // Catch: java.lang.NoSuchFieldError -> L22
            L22:
                androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.WhenMappings.$EnumSwitchMapping$0 = r0
                return
        }
    }

    static {
            androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk$Companion r0 = new androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.Companion = r0
            r0 = 6
            kotlin.Pair[] r0 = new kotlin.Pair[r0]
            java.lang.String r2 = "SM-T580"
            kotlin.Pair r2 = kotlin.TuplesKt.to(r2, r1)
            r3 = 0
            r0[r3] = r2
            android.util.Range r2 = new android.util.Range
            r3 = 21
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r4 = r3
            java.lang.Comparable r4 = (java.lang.Comparable) r4
            r5 = 26
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            r6 = r5
            java.lang.Comparable r6 = (java.lang.Comparable) r6
            r2.<init>(r4, r6)
            java.lang.String r4 = "SM-J710MN"
            kotlin.Pair r2 = kotlin.TuplesKt.to(r4, r2)
            r4 = 1
            r0[r4] = r2
            java.lang.String r2 = "SM-A320FL"
            kotlin.Pair r2 = kotlin.TuplesKt.to(r2, r1)
            r4 = 2
            r0[r4] = r2
            java.lang.String r2 = "SM-G570M"
            kotlin.Pair r2 = kotlin.TuplesKt.to(r2, r1)
            r4 = 3
            r0[r4] = r2
            java.lang.String r2 = "SM-G610F"
            kotlin.Pair r1 = kotlin.TuplesKt.to(r2, r1)
            r2 = 4
            r0[r2] = r1
            android.util.Range r1 = new android.util.Range
            java.lang.Comparable r3 = (java.lang.Comparable) r3
            java.lang.Comparable r5 = (java.lang.Comparable) r5
            r1.<init>(r3, r5)
            java.lang.String r2 = "SM-G610M"
            kotlin.Pair r1 = kotlin.TuplesKt.to(r2, r1)
            r2 = 5
            r0[r2] = r1
            java.util.Map r0 = kotlin.collections.MapsKt.mutableMapOf(r0)
            androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.SAMSUNG_DISTORTION_MODELS_TO_API_LEVEL_MAP = r0
            return
    }

    public ExtraCroppingQuirk() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ java.util.Map access$getSAMSUNG_DISTORTION_MODELS_TO_API_LEVEL_MAP$cp() {
            java.util.Map<java.lang.String, android.util.Range<java.lang.Integer>> r0 = androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.SAMSUNG_DISTORTION_MODELS_TO_API_LEVEL_MAP
            return r0
    }

    public final android.util.Size getVerifiedResolution(androidx.camera.core.impl.SurfaceConfig.ConfigType r3) {
            r2 = this;
            java.lang.String r0 = "configType"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk$Companion r0 = androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.Companion
            boolean r0 = r0.isSamsungDistortion$camera_camera2()
            r1 = 0
            if (r0 == 0) goto L3e
            int[] r0 = androidx.camera.camera2.compat.quirk.ExtraCroppingQuirk.WhenMappings.$EnumSwitchMapping$0
            int r3 = r3.ordinal()
            r3 = r0[r3]
            r0 = 1
            if (r3 == r0) goto L34
            r0 = 2
            if (r3 == r0) goto L2a
            r0 = 3
            if (r3 == r0) goto L20
            return r1
        L20:
            android.util.Size r3 = new android.util.Size
            r0 = 3264(0xcc0, float:4.574E-42)
            r1 = 1836(0x72c, float:2.573E-42)
            r3.<init>(r0, r1)
            return r3
        L2a:
            android.util.Size r3 = new android.util.Size
            r0 = 1280(0x500, float:1.794E-42)
            r1 = 720(0x2d0, float:1.009E-42)
            r3.<init>(r0, r1)
            return r3
        L34:
            android.util.Size r3 = new android.util.Size
            r0 = 1920(0x780, float:2.69E-42)
            r1 = 1080(0x438, float:1.513E-42)
            r3.<init>(r0, r1)
            return r3
        L3e:
            return r1
    }
}
