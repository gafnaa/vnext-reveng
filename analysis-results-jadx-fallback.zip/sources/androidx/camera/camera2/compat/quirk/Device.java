package androidx.camera.camera2.compat.quirk;

/* JADX INFO: compiled from: Device.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0014\n\u0002\u0010\u000e\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0006\u0010\u0004\u001a\u00020\u0005J\u0006\u0010\u0006\u001a\u00020\u0005J\u0006\u0010\u0007\u001a\u00020\u0005J\u0006\u0010\b\u001a\u00020\u0005J\u0006\u0010\t\u001a\u00020\u0005J\u0006\u0010\n\u001a\u00020\u0005J\u0006\u0010\u000b\u001a\u00020\u0005J\u0006\u0010\f\u001a\u00020\u0005J\u0006\u0010\r\u001a\u00020\u0005J\u0006\u0010\u000e\u001a\u00020\u0005J\u0006\u0010\u000f\u001a\u00020\u0005J\u0006\u0010\u0010\u001a\u00020\u0005J\u0006\u0010\u0011\u001a\u00020\u0005J\u0006\u0010\u0012\u001a\u00020\u0005J\u0006\u0010\u0013\u001a\u00020\u0005J\u0006\u0010\u0014\u001a\u00020\u0005J\u0006\u0010\u0015\u001a\u00020\u0005J\u0006\u0010\u0016\u001a\u00020\u0005J\u0006\u0010\u0017\u001a\u00020\u0005J\u0010\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u001aH\u0002J\u0016\u0010\u001b\u001a\u00020\u0005*\u00020\u001a2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001aH\u0002J\u0006\u0010\u001d\u001a\u00020\u0005¨\u0006\u001e"}, d2 = {"Landroidx/camera/camera2/compat/quirk/Device;", "", "<init>", "()V", "isBluDevice", "", "isHuaweiDevice", "isInfinixDevice", "isItelDevice", "isJioDevice", "isGoogleDevice", "isMotorolaDevice", "isNokiaDevice", "isOnePlusDevice", "isOppoDevice", "isPositivoDevice", "isRealmeDevice", "isRedmiDevice", "isSamsungDevice", "isSonyDevice", "isTecnoDevice", "isXiaomiDevice", "isVivoDevice", "isPocoDevice", "isDeviceFrom", "vendor", "", "equalsCaseInsensitive", "other", "isUniSocChipsetDevice", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class Device {
    public static final androidx.camera.camera2.compat.quirk.Device INSTANCE = null;

    static {
            androidx.camera.camera2.compat.quirk.Device r0 = new androidx.camera.camera2.compat.quirk.Device
            r0.<init>()
            androidx.camera.camera2.compat.quirk.Device.INSTANCE = r0
            return
    }

    private Device() {
            r0 = this;
            r0.<init>()
            return
    }

    private final boolean equalsCaseInsensitive(java.lang.String r2, java.lang.String r3) {
            r1 = this;
            r0 = 1
            boolean r2 = kotlin.text.StringsKt.equals(r2, r3, r0)
            return r2
    }

    private final boolean isDeviceFrom(java.lang.String r3) {
            r2 = this;
            java.lang.String r0 = android.os.Build.MANUFACTURER
            java.lang.String r1 = "MANUFACTURER"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            boolean r0 = r2.equalsCaseInsensitive(r0, r3)
            if (r0 != 0) goto L1d
            java.lang.String r0 = android.os.Build.BRAND
            java.lang.String r1 = "BRAND"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            boolean r3 = r2.equalsCaseInsensitive(r0, r3)
            if (r3 == 0) goto L1b
            goto L1d
        L1b:
            r3 = 0
            return r3
        L1d:
            r3 = 1
            return r3
    }

    public final boolean isBluDevice() {
            r1 = this;
            java.lang.String r0 = "Blu"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isGoogleDevice() {
            r1 = this;
            java.lang.String r0 = "Google"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isHuaweiDevice() {
            r1 = this;
            java.lang.String r0 = "Huawei"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isInfinixDevice() {
            r1 = this;
            java.lang.String r0 = "Infinix"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isItelDevice() {
            r1 = this;
            java.lang.String r0 = "Itel"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isJioDevice() {
            r1 = this;
            java.lang.String r0 = "Jio"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isMotorolaDevice() {
            r1 = this;
            java.lang.String r0 = "Motorola"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isNokiaDevice() {
            r1 = this;
            java.lang.String r0 = "Nokia"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isOnePlusDevice() {
            r1 = this;
            java.lang.String r0 = "OnePlus"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isOppoDevice() {
            r1 = this;
            java.lang.String r0 = "Oppo"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isPocoDevice() {
            r1 = this;
            java.lang.String r0 = "Poco"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isPositivoDevice() {
            r1 = this;
            java.lang.String r0 = "Positivo"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isRealmeDevice() {
            r1 = this;
            java.lang.String r0 = "Realme"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isRedmiDevice() {
            r1 = this;
            java.lang.String r0 = "Redmi"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isSamsungDevice() {
            r1 = this;
            java.lang.String r0 = "Samsung"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isSonyDevice() {
            r1 = this;
            java.lang.String r0 = "Sony"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isTecnoDevice() {
            r1 = this;
            java.lang.String r0 = "Tecno"
            boolean r0 = r1.isDeviceFrom(r0)
            if (r0 != 0) goto L13
            java.lang.String r0 = "Tecno-mobile"
            boolean r0 = r1.isDeviceFrom(r0)
            if (r0 == 0) goto L11
            goto L13
        L11:
            r0 = 0
            return r0
        L13:
            r0 = 1
            return r0
    }

    public final boolean isUniSocChipsetDevice() {
            r8 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 31
            r2 = 1
            if (r0 < r1) goto L13
            java.lang.String r0 = "Spreadtrum"
            java.lang.String r1 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m24m()
            boolean r0 = kotlin.text.StringsKt.equals(r0, r1, r2)
            if (r0 != 0) goto L4e
        L13:
            java.lang.String r0 = android.os.Build.HARDWARE
            java.lang.String r1 = "HARDWARE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.util.Locale r3 = java.util.Locale.ROOT
            java.lang.String r0 = r0.toLowerCase(r3)
            java.lang.String r3 = "toLowerCase(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r3)
            java.lang.String r4 = "ums"
            r5 = 0
            r6 = 2
            r7 = 0
            boolean r0 = kotlin.text.StringsKt.startsWith$default(r0, r4, r5, r6, r7)
            if (r0 != 0) goto L4e
            boolean r0 = r8.isItelDevice()
            if (r0 == 0) goto L4d
            java.lang.String r0 = android.os.Build.HARDWARE
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.util.Locale r1 = java.util.Locale.ROOT
            java.lang.String r0 = r0.toLowerCase(r1)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r3)
            java.lang.String r1 = "sp"
            boolean r0 = kotlin.text.StringsKt.startsWith$default(r0, r1, r5, r6, r7)
            if (r0 == 0) goto L4d
            goto L4e
        L4d:
            return r5
        L4e:
            return r2
    }

    public final boolean isVivoDevice() {
            r1 = this;
            java.lang.String r0 = "Vivo"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }

    public final boolean isXiaomiDevice() {
            r1 = this;
            java.lang.String r0 = "Xiaomi"
            boolean r0 = r1.isDeviceFrom(r0)
            return r0
    }
}
