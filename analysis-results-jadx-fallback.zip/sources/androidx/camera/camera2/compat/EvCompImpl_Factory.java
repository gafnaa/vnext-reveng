package androidx.camera.camera2.compat;

/* JADX INFO: loaded from: classes.dex */
public final class EvCompImpl_Factory implements dagger.internal.Factory<androidx.camera.camera2.compat.EvCompImpl> {
    private final dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> cameraPropertiesProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.ComboRequestListener> comboRequestListenerProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> threadsProvider;

    private EvCompImpl_Factory(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r2, dagger.internal.Provider<androidx.camera.camera2.impl.ComboRequestListener> r3) {
            r0 = this;
            r0.<init>()
            r0.cameraPropertiesProvider = r1
            r0.threadsProvider = r2
            r0.comboRequestListenerProvider = r3
            return
    }

    public static androidx.camera.camera2.compat.EvCompImpl_Factory create(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1, dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r2, dagger.internal.Provider<androidx.camera.camera2.impl.ComboRequestListener> r3) {
            androidx.camera.camera2.compat.EvCompImpl_Factory r0 = new androidx.camera.camera2.compat.EvCompImpl_Factory
            r0.<init>(r1, r2, r3)
            return r0
    }

    public static androidx.camera.camera2.compat.EvCompImpl newInstance(androidx.camera.camera2.impl.CameraProperties r1, androidx.camera.camera2.impl.UseCaseThreads r2, androidx.camera.camera2.impl.ComboRequestListener r3) {
            androidx.camera.camera2.compat.EvCompImpl r0 = new androidx.camera.camera2.compat.EvCompImpl
            r0.<init>(r1, r2, r3)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.compat.EvCompImpl get() {
            r3 = this;
            dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r0 = r3.cameraPropertiesProvider
            java.lang.Object r0 = r0.get()
            androidx.camera.camera2.impl.CameraProperties r0 = (androidx.camera.camera2.impl.CameraProperties) r0
            dagger.internal.Provider<androidx.camera.camera2.impl.UseCaseThreads> r1 = r3.threadsProvider
            java.lang.Object r1 = r1.get()
            androidx.camera.camera2.impl.UseCaseThreads r1 = (androidx.camera.camera2.impl.UseCaseThreads) r1
            dagger.internal.Provider<androidx.camera.camera2.impl.ComboRequestListener> r2 = r3.comboRequestListenerProvider
            java.lang.Object r2 = r2.get()
            androidx.camera.camera2.impl.ComboRequestListener r2 = (androidx.camera.camera2.impl.ComboRequestListener) r2
            androidx.camera.camera2.compat.EvCompImpl r0 = newInstance(r0, r1, r2)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.compat.EvCompImpl r0 = r1.get()
            return r0
    }
}
