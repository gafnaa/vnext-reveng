package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: ZoomCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u0000 \u00152\u00020\u0001:\u0001\u0015B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u001e\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\u0006\u0010\u000f\u001a\u00020\u00072\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\u0016\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u000e0\r2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\b\u0010\u0013\u001a\u00020\u0014H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u0007X\u0096D¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0014\u0010\n\u001a\u00020\u0007X\u0096D¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\t¨\u0006\u0016"}, d2 = {"Landroidx/camera/camera2/compat/NoOpZoomCompat;", "Landroidx/camera/camera2/compat/ZoomCompat;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;)V", "minZoomRatio", "", "getMinZoomRatio", "()F", "maxZoomRatio", "getMaxZoomRatio", "applyAsync", "Lkotlinx/coroutines/Deferred;", "", "zoomRatio", "requestControl", "Landroidx/camera/camera2/impl/UseCaseCameraRequestControl;", "resetAsync", "getCropSensorRegion", "Landroid/graphics/Rect;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class NoOpZoomCompat implements androidx.camera.camera2.compat.ZoomCompat {
    public static final androidx.camera.camera2.compat.NoOpZoomCompat.Companion Companion = null;
    private static final java.util.List<android.hardware.camera2.CameraCharacteristics.Key<android.graphics.Rect>> requiredCharacteristics = null;
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;
    private final float maxZoomRatio;
    private final float minZoomRatio;

    /* JADX INFO: compiled from: ZoomCompat.kt */
    @kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0080\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R*\u0010\u0004\u001a\u001b\u0012\u0017\u0012\u0015\u0012\f\u0012\n \b*\u0004\u0018\u00010\u00070\u00070\u0006¢\u0006\u0002\b\t0\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"Landroidx/camera/camera2/compat/NoOpZoomCompat$Companion;", "", "<init>", "()V", "requiredCharacteristics", "", "Landroid/hardware/camera2/CameraCharacteristics$Key;", "Landroid/graphics/Rect;", "kotlin.jvm.PlatformType", "Lkotlin/jvm/internal/EnhancedNullability;", "getRequiredCharacteristics", "()Ljava/util/List;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final java.util.List<android.hardware.camera2.CameraCharacteristics.Key<android.graphics.Rect>> getRequiredCharacteristics() {
                r1 = this;
                java.util.List r0 = androidx.camera.camera2.compat.NoOpZoomCompat.access$getRequiredCharacteristics$cp()
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.NoOpZoomCompat$Companion r0 = new androidx.camera.camera2.compat.NoOpZoomCompat$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.NoOpZoomCompat.Companion = r0
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            androidx.camera.camera2.compat.NoOpZoomCompat.requiredCharacteristics = r0
            return
    }

    public NoOpZoomCompat(androidx.camera.camera2.impl.CameraProperties r2) {
            r1 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.cameraProperties = r2
            r2 = 1065353216(0x3f800000, float:1.0)
            r1.minZoomRatio = r2
            r1.maxZoomRatio = r2
            return
    }

    public static final /* synthetic */ java.util.List access$getRequiredCharacteristics$cp() {
            java.util.List<android.hardware.camera2.CameraCharacteristics$Key<android.graphics.Rect>> r0 = androidx.camera.camera2.compat.NoOpZoomCompat.requiredCharacteristics
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public kotlinx.coroutines.Deferred<kotlin.Unit> applyAsync(float r1, androidx.camera.camera2.impl.UseCaseCameraRequestControl r2) {
            r0 = this;
            java.lang.String r1 = "requestControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r1)
            kotlin.Unit r1 = kotlin.Unit.INSTANCE
            kotlinx.coroutines.CompletableDeferred r1 = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred(r1)
            kotlinx.coroutines.Deferred r1 = (kotlinx.coroutines.Deferred) r1
            return r1
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public android.graphics.Rect getCropSensorRegion() {
            r1 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r1.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.graphics.Rect r0 = androidx.camera.camera2.compat.workaround.CameraMetadataSafeGetterKt.getActiveArraySizeSafely(r0)
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public float getMaxZoomRatio() {
            r1 = this;
            float r0 = r1.maxZoomRatio
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public float getMinZoomRatio() {
            r1 = this;
            float r0 = r1.minZoomRatio
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public kotlinx.coroutines.Deferred<kotlin.Unit> resetAsync(androidx.camera.camera2.impl.UseCaseCameraRequestControl r2) {
            r1 = this;
            java.lang.String r0 = "requestControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            kotlinx.coroutines.CompletableDeferred r2 = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred(r2)
            kotlinx.coroutines.Deferred r2 = (kotlinx.coroutines.Deferred) r2
            return r2
    }
}
