package androidx.camera.camera2.compat;

/* JADX INFO: loaded from: classes.dex */
public final class ZoomCompat_Bindings_Companion_ProvideZoomCompatFactory implements dagger.internal.Factory<androidx.camera.camera2.compat.ZoomCompat> {
    private final dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> cameraPropertiesProvider;

    private ZoomCompat_Bindings_Companion_ProvideZoomCompatFactory(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1) {
            r0 = this;
            r0.<init>()
            r0.cameraPropertiesProvider = r1
            return
    }

    public static androidx.camera.camera2.compat.ZoomCompat_Bindings_Companion_ProvideZoomCompatFactory create(dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r1) {
            androidx.camera.camera2.compat.ZoomCompat_Bindings_Companion_ProvideZoomCompatFactory r0 = new androidx.camera.camera2.compat.ZoomCompat_Bindings_Companion_ProvideZoomCompatFactory
            r0.<init>(r1)
            return r0
    }

    public static androidx.camera.camera2.compat.ZoomCompat provideZoomCompat(androidx.camera.camera2.impl.CameraProperties r1) {
            androidx.camera.camera2.compat.ZoomCompat$Bindings$Companion r0 = androidx.camera.camera2.compat.ZoomCompat.Bindings.Companion
            androidx.camera.camera2.compat.ZoomCompat r1 = r0.provideZoomCompat(r1)
            java.lang.Object r1 = dagger.internal.Preconditions.checkNotNullFromProvides(r1)
            androidx.camera.camera2.compat.ZoomCompat r1 = (androidx.camera.camera2.compat.ZoomCompat) r1
            return r1
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.compat.ZoomCompat get() {
            r1 = this;
            dagger.internal.Provider<androidx.camera.camera2.impl.CameraProperties> r0 = r1.cameraPropertiesProvider
            java.lang.Object r0 = r0.get()
            androidx.camera.camera2.impl.CameraProperties r0 = (androidx.camera.camera2.impl.CameraProperties) r0
            androidx.camera.camera2.compat.ZoomCompat r0 = provideZoomCompat(r0)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.compat.ZoomCompat r0 = r1.get()
            return r0
    }
}
