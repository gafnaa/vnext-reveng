package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: EvCompCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B!\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u0010\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001eH\u0016J&\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\f0 2\u0006\u0010!\u001a\u00020\f2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020\u0010H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bX\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0014\u0010\u000f\u001a\u00020\u0010X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0013\u001a\u00020\u0014X\u0096\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0016\u0010\u0017\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006%"}, d2 = {"Landroidx/camera/camera2/compat/EvCompImpl;", "Landroidx/camera/camera2/compat/EvCompCompat;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "threads", "Landroidx/camera/camera2/impl/UseCaseThreads;", "comboRequestListener", "Landroidx/camera/camera2/impl/ComboRequestListener;", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;Landroidx/camera/camera2/impl/UseCaseThreads;Landroidx/camera/camera2/impl/ComboRequestListener;)V", "range", "Landroid/util/Range;", "", "getRange", "()Landroid/util/Range;", "supported", "", "getSupported", "()Z", "step", "Landroid/util/Rational;", "getStep", "()Landroid/util/Rational;", "updateSignal", "Lkotlinx/coroutines/CompletableDeferred;", "updateListener", "Landroidx/camera/camera2/pipe/Request$Listener;", "stopRunningTask", "", "throwable", "", "applyAsync", "Lkotlinx/coroutines/Deferred;", "evCompIndex", "requestControl", "Landroidx/camera/camera2/impl/UseCaseCameraRequestControl;", "cancelPreviousTask", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class EvCompImpl implements androidx.camera.camera2.compat.EvCompCompat {
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;
    private final androidx.camera.camera2.impl.ComboRequestListener comboRequestListener;
    private final android.util.Range<java.lang.Integer> range;
    private final android.util.Rational step;
    private final boolean supported;
    private final androidx.camera.camera2.impl.UseCaseThreads threads;
    private androidx.camera.camera2.pipe.Request.Listener updateListener;
    private kotlinx.coroutines.CompletableDeferred<java.lang.Integer> updateSignal;


    /* JADX INFO: renamed from: $r8$lambda$YC4JQEnY8FmJcoebMHC7Y-8Vs38, reason: not valid java name */
    public static /* synthetic */ kotlin.Unit m101$r8$lambda$YC4JQEnY8FmJcoebMHC7Y8Vs38(androidx.camera.camera2.compat.EvCompImpl r0, androidx.camera.camera2.compat.EvCompImpl.AnonymousClass3 r1, java.lang.Throwable r2) {
            kotlin.Unit r0 = applyAsync$lambda$2$0(r0, r1, r2)
            return r0
    }

    @javax.inject.Inject
    public EvCompImpl(androidx.camera.camera2.impl.CameraProperties r2, androidx.camera.camera2.impl.UseCaseThreads r3, androidx.camera.camera2.impl.ComboRequestListener r4) {
            r1 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "threads"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "comboRequestListener"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            r1.<init>()
            r1.cameraProperties = r2
            r1.threads = r3
            r1.comboRequestListener = r4
            androidx.camera.camera2.pipe.CameraMetadata r3 = r2.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r4 = android.hardware.camera2.CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE
            java.lang.String r0 = "CONTROL_AE_COMPENSATION_RANGE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r0)
            android.util.Range r0 = androidx.camera.camera2.compat.EvCompCompatKt.getEMPTY_RANGE()
            java.lang.Object r3 = r3.getOrDefault(r4, r0)
            java.lang.String r4 = "getOrDefault(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)
            android.util.Range r3 = (android.util.Range) r3
            r1.range = r3
            android.util.Range r3 = r1.getRange()
            java.lang.Comparable r3 = r3.getUpper()
            java.lang.Integer r3 = (java.lang.Integer) r3
            if (r3 != 0) goto L41
            goto L47
        L41:
            int r3 = r3.intValue()
            if (r3 == 0) goto L5c
        L47:
            android.util.Range r3 = r1.getRange()
            java.lang.Comparable r3 = r3.getLower()
            java.lang.Integer r3 = (java.lang.Integer) r3
            if (r3 != 0) goto L54
            goto L5a
        L54:
            int r3 = r3.intValue()
            if (r3 == 0) goto L5c
        L5a:
            r3 = 1
            goto L5d
        L5c:
            r3 = 0
        L5d:
            r1.supported = r3
            boolean r3 = r1.getSupported()
            if (r3 != 0) goto L6b
            android.util.Rational r2 = android.util.Rational.ZERO
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2)
            goto L7f
        L6b:
            androidx.camera.camera2.pipe.CameraMetadata r2 = r2.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r3 = android.hardware.camera2.CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP
            java.lang.String r4 = "CONTROL_AE_COMPENSATION_STEP"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)
            java.lang.Object r2 = r2.get(r3)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2)
            android.util.Rational r2 = (android.util.Rational) r2
        L7f:
            r1.step = r2
            return
    }

    private static final kotlin.Unit applyAsync$lambda$2$0(androidx.camera.camera2.compat.EvCompImpl r0, androidx.camera.camera2.compat.EvCompImpl.AnonymousClass3 r1, java.lang.Throwable r2) {
            androidx.camera.camera2.impl.ComboRequestListener r0 = r0.comboRequestListener
            androidx.camera.camera2.pipe.Request$Listener r1 = (androidx.camera.camera2.pipe.Request.Listener) r1
            r0.removeListener(r1)
            kotlin.Unit r0 = kotlin.Unit.INSTANCE
            return r0
    }

    @Override // androidx.camera.camera2.compat.EvCompCompat
    public kotlinx.coroutines.Deferred<java.lang.Integer> applyAsync(int r8, androidx.camera.camera2.impl.UseCaseCameraRequestControl r9, boolean r10) {
            r7 = this;
            java.lang.String r0 = "requestControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r9, r0)
            r0 = 1
            r1 = 0
            kotlinx.coroutines.CompletableDeferred r0 = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred$default(r1, r0, r1)
            kotlinx.coroutines.CompletableDeferred<java.lang.Integer> r2 = r7.updateSignal
            if (r2 == 0) goto L24
            if (r10 == 0) goto L1e
            androidx.camera.core.CameraControl$OperationCanceledException r10 = new androidx.camera.core.CameraControl$OperationCanceledException
            java.lang.String r3 = "Cancelled by another setExposureCompensationIndex()"
            r10.<init>(r3)
            java.lang.Throwable r10 = (java.lang.Throwable) r10
            r2.completeExceptionally(r10)
            goto L24
        L1e:
            r10 = r0
            kotlinx.coroutines.Deferred r10 = (kotlinx.coroutines.Deferred) r10
            androidx.camera.camera2.adapter.CoroutineAdaptersKt.propagateTo(r10, r2)
        L24:
            r7.updateSignal = r0
            androidx.camera.camera2.pipe.Request$Listener r10 = r7.updateListener
            if (r10 == 0) goto L31
            androidx.camera.camera2.impl.ComboRequestListener r2 = r7.comboRequestListener
            r2.removeListener(r10)
            r7.updateListener = r1
        L31:
            android.hardware.camera2.CaptureRequest$Key r10 = android.hardware.camera2.CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION
            java.lang.Integer r1 = java.lang.Integer.valueOf(r8)
            kotlin.Pair r10 = kotlin.TuplesKt.to(r10, r1)
            java.util.Map r2 = kotlin.collections.MapsKt.mapOf(r10)
            r5 = 6
            r6 = 0
            r3 = 0
            r4 = 0
            r1 = r9
            androidx.camera.camera2.impl.UseCaseCameraRequestControl.setParametersAsync$default(r1, r2, r3, r4, r5, r6)
            androidx.camera.camera2.compat.EvCompImpl$applyAsync$3 r9 = new androidx.camera.camera2.compat.EvCompImpl$applyAsync$3
            r9.<init>(r8, r0)
            androidx.camera.camera2.impl.ComboRequestListener r8 = r7.comboRequestListener
            r10 = r9
            androidx.camera.camera2.pipe.Request$Listener r10 = (androidx.camera.camera2.pipe.Request.Listener) r10
            androidx.camera.camera2.impl.UseCaseThreads r1 = r7.threads
            java.util.concurrent.Executor r1 = r1.getSequentialExecutor()
            r8.addListener(r10, r1)
            androidx.camera.camera2.compat.EvCompImpl$$ExternalSyntheticLambda0 r8 = new androidx.camera.camera2.compat.EvCompImpl$$ExternalSyntheticLambda0
            r8.<init>(r7, r9)
            r0.invokeOnCompletion(r8)
            r7.updateListener = r10
            kotlinx.coroutines.Deferred r0 = (kotlinx.coroutines.Deferred) r0
            return r0
    }

    @Override // androidx.camera.camera2.compat.EvCompCompat
    public android.util.Range<java.lang.Integer> getRange() {
            r1 = this;
            android.util.Range<java.lang.Integer> r0 = r1.range
            return r0
    }

    @Override // androidx.camera.camera2.compat.EvCompCompat
    public android.util.Rational getStep() {
            r1 = this;
            android.util.Rational r0 = r1.step
            return r0
    }

    @Override // androidx.camera.camera2.compat.EvCompCompat
    public boolean getSupported() {
            r1 = this;
            boolean r0 = r1.supported
            return r0
    }

    @Override // androidx.camera.camera2.compat.EvCompCompat
    public void stopRunningTask(java.lang.Throwable r2) {
            r1 = this;
            java.lang.String r0 = "throwable"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            kotlinx.coroutines.CompletableDeferred<java.lang.Integer> r0 = r1.updateSignal
            if (r0 == 0) goto Lc
            r0.completeExceptionally(r2)
        Lc:
            return
    }
}
