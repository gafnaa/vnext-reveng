package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: ApiCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010%\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\bÁ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J(\u0010\u0004\u001a\u00020\u00052\u0016\u0010\u0006\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\b\u0012\u0004\u0012\u00020\u00010\u00072\u0006\u0010\t\u001a\u00020\nH\u0007¨\u0006\u000b"}, d2 = {"Landroidx/camera/camera2/compat/Api35Compat;", "", "<init>", "()V", "setFlashStrengthLevel", "", "parameters", "", "Landroid/hardware/camera2/CaptureRequest$Key;", "level", "", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class Api35Compat {
    public static final androidx.camera.camera2.compat.Api35Compat INSTANCE = null;

    static {
            androidx.camera.camera2.compat.Api35Compat r0 = new androidx.camera.camera2.compat.Api35Compat
            r0.<init>()
            androidx.camera.camera2.compat.Api35Compat.INSTANCE = r0
            return
    }

    private Api35Compat() {
            r0 = this;
            r0.<init>()
            return
    }

    @kotlin.jvm.JvmStatic
    public static final void setFlashStrengthLevel(java.util.Map<android.hardware.camera2.CaptureRequest.Key<?>, java.lang.Object> r1, int r2) {
            java.lang.String r0 = "parameters"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r0)
            android.hardware.camera2.CaptureRequest$Key r0 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m35m$2()
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r1.put(r0, r2)
            return
    }
}
