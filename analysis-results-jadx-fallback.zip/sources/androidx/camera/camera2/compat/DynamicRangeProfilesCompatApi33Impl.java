package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: DynamicRangeProfilesCompatApi33Impl.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0006\b\u0001\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u0006\u0010\f\u001a\u00020\bH\u0016J\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\f\u001a\u00020\bH\u0016J\b\u0010\u000f\u001a\u00020\u0003H\u0016J\u0017\u0010\u0010\u001a\u0004\u0018\u00010\u00112\u0006\u0010\f\u001a\u00020\bH\u0002¢\u0006\u0002\u0010\u0012J\u0012\u0010\u0013\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0014\u001a\u00020\u0011H\u0002J\u001c\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00110\u0007H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00078VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\t\u0010\n¨\u0006\u0017"}, d2 = {"Landroidx/camera/camera2/compat/DynamicRangeProfilesCompatApi33Impl;", "Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl;", "dynamicRangeProfiles", "Landroid/hardware/camera2/params/DynamicRangeProfiles;", "<init>", "(Landroid/hardware/camera2/params/DynamicRangeProfiles;)V", "supportedDynamicRanges", "", "Landroidx/camera/core/DynamicRange;", "getSupportedDynamicRanges", "()Ljava/util/Set;", "getDynamicRangeCaptureRequestConstraints", "dynamicRange", "isExtraLatencyPresent", "", "unwrap", "dynamicRangeToFirstSupportedProfile", "", "(Landroidx/camera/core/DynamicRange;)Ljava/lang/Long;", "profileToDynamicRange", "profile", "profileSetToDynamicRangeSet", "profileSet", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DynamicRangeProfilesCompatApi33Impl implements androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl {
    private final android.hardware.camera2.params.DynamicRangeProfiles dynamicRangeProfiles;

    public DynamicRangeProfilesCompatApi33Impl(android.hardware.camera2.params.DynamicRangeProfiles r2) {
            r1 = this;
            java.lang.String r0 = "dynamicRangeProfiles"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.dynamicRangeProfiles = r2
            return
    }

    private final java.lang.Long dynamicRangeToFirstSupportedProfile(androidx.camera.core.DynamicRange r3) {
            r2 = this;
            androidx.camera.camera2.internal.DynamicRangeConversions r0 = androidx.camera.camera2.internal.DynamicRangeConversions.INSTANCE
            android.hardware.camera2.params.DynamicRangeProfiles r1 = r2.dynamicRangeProfiles
            java.lang.Long r3 = r0.dynamicRangeToFirstSupportedProfile(r3, r1)
            return r3
    }

    private final java.util.Set<androidx.camera.core.DynamicRange> profileSetToDynamicRangeSet(java.util.Set<java.lang.Long> r4) {
            r3 = this;
            boolean r0 = r4.isEmpty()
            if (r0 == 0) goto Lb
            java.util.Set r4 = kotlin.collections.SetsKt.emptySet()
            return r4
        Lb:
            java.util.LinkedHashSet r0 = new java.util.LinkedHashSet
            r0.<init>()
            java.util.Set r0 = (java.util.Set) r0
            java.util.Iterator r4 = r4.iterator()
        L16:
            boolean r1 = r4.hasNext()
            if (r1 == 0) goto L30
            java.lang.Object r1 = r4.next()
            java.lang.Number r1 = (java.lang.Number) r1
            long r1 = r1.longValue()
            androidx.camera.core.DynamicRange r1 = r3.profileToDynamicRange(r1)
            if (r1 == 0) goto L16
            r0.add(r1)
            goto L16
        L30:
            java.util.Set r4 = java.util.Collections.unmodifiableSet(r0)
            java.lang.String r0 = "unmodifiableSet(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r4, r0)
            return r4
    }

    private final androidx.camera.core.DynamicRange profileToDynamicRange(long r5) {
            r4 = this;
            androidx.camera.camera2.internal.DynamicRangeConversions r0 = androidx.camera.camera2.internal.DynamicRangeConversions.INSTANCE
            androidx.camera.core.DynamicRange r0 = r0.profileToDynamicRange(r5)
            if (r0 != 0) goto L27
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isWarnEnabled(r1)
            if (r1 == 0) goto L27
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Dynamic range profile cannot be converted to a DynamicRange object: "
            r2.<init>(r3)
            r2.append(r5)
            java.lang.String r5 = r2.toString()
            android.util.Log.w(r1, r5)
        L27:
            return r0
    }

    @Override // androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl
    public java.util.Set<androidx.camera.core.DynamicRange> getDynamicRangeCaptureRequestConstraints(androidx.camera.core.DynamicRange r3) {
            r2 = this;
            java.lang.String r0 = "dynamicRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.Long r0 = r2.dynamicRangeToFirstSupportedProfile(r3)
            if (r0 == 0) goto L1f
            android.hardware.camera2.params.DynamicRangeProfiles r3 = r2.dynamicRangeProfiles
            long r0 = r0.longValue()
            java.util.Set r3 = r3.getProfileCaptureRequestConstraints(r0)
            java.lang.String r0 = "getProfileCaptureRequestConstraints(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r0)
            java.util.Set r3 = r2.profileSetToDynamicRangeSet(r3)
            return r3
        L1f:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "DynamicRange is not supported: "
            r0.<init>(r1)
            r0.append(r3)
            java.lang.String r3 = r0.toString()
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r3 = r3.toString()
            r0.<init>(r3)
            throw r0
    }

    @Override // androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl
    public java.util.Set<androidx.camera.core.DynamicRange> getSupportedDynamicRanges() {
            r2 = this;
            android.hardware.camera2.params.DynamicRangeProfiles r0 = r2.dynamicRangeProfiles
            java.util.Set r0 = r0.getSupportedProfiles()
            java.lang.String r1 = "getSupportedProfiles(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.util.Set r0 = r2.profileSetToDynamicRangeSet(r0)
            return r0
    }

    @Override // androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl
    public boolean isExtraLatencyPresent(androidx.camera.core.DynamicRange r3) {
            r2 = this;
            java.lang.String r0 = "dynamicRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.Long r0 = r2.dynamicRangeToFirstSupportedProfile(r3)
            if (r0 == 0) goto L16
            android.hardware.camera2.params.DynamicRangeProfiles r3 = r2.dynamicRangeProfiles
            long r0 = r0.longValue()
            boolean r3 = r3.isExtraLatencyPresent(r0)
            return r3
        L16:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "DynamicRange is not supported: "
            r0.<init>(r1)
            r0.append(r3)
            java.lang.String r3 = r0.toString()
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r3 = r3.toString()
            r0.<init>(r3)
            throw r0
    }

    @Override // androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl
    public android.hardware.camera2.params.DynamicRangeProfiles unwrap() {
            r1 = this;
            android.hardware.camera2.params.DynamicRangeProfiles r0 = r1.dynamicRangeProfiles
            return r0
    }
}
