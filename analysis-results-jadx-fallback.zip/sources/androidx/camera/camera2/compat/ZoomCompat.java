package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: ZoomCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001:\u0001\u0011J\u001e\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\u000b\u001a\u00020\u00032\u0006\u0010\f\u001a\u00020\rH&J\u0016\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\f\u001a\u00020\rH&J\b\u0010\u000f\u001a\u00020\u0010H&R\u0012\u0010\u0002\u001a\u00020\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005R\u0012\u0010\u0006\u001a\u00020\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\u0005ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\u0012À\u0006\u0001"}, d2 = {"Landroidx/camera/camera2/compat/ZoomCompat;", "", "minZoomRatio", "", "getMinZoomRatio", "()F", "maxZoomRatio", "getMaxZoomRatio", "applyAsync", "Lkotlinx/coroutines/Deferred;", "", "zoomRatio", "requestControl", "Landroidx/camera/camera2/impl/UseCaseCameraRequestControl;", "resetAsync", "getCropSensorRegion", "Landroid/graphics/Rect;", "Bindings", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public interface ZoomCompat {

    /* JADX INFO: compiled from: ZoomCompat.kt */
    @kotlin.Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\b'\u0018\u0000 \u00042\u00020\u0001:\u0001\u0004B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Landroidx/camera/camera2/compat/ZoomCompat$Bindings;", "", "<init>", "()V", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    @dagger.Module
    public static abstract class Bindings {
        public static final androidx.camera.camera2.compat.ZoomCompat.Bindings.Companion Companion = null;

        /* JADX INFO: compiled from: ZoomCompat.kt */
        @kotlin.Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H\u0007¨\u0006\b"}, d2 = {"Landroidx/camera/camera2/compat/ZoomCompat$Bindings$Companion;", "", "<init>", "()V", "provideZoomCompat", "Landroidx/camera/camera2/compat/ZoomCompat;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
        public static final class Companion {
            private Companion() {
                    r0 = this;
                    r0.<init>()
                    return
            }

            public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                    r0 = this;
                    r0.<init>()
                    return
            }

            @dagger.Provides
            public final androidx.camera.camera2.compat.ZoomCompat provideZoomCompat(androidx.camera.camera2.impl.CameraProperties r6) {
                    r5 = this;
                    java.lang.String r0 = "cameraProperties"
                    kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
                    java.lang.String r0 = "robolectric"
                    java.lang.String r1 = android.os.Build.FINGERPRINT
                    boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r1)
                    if (r0 == 0) goto L6e
                    androidx.camera.camera2.compat.NoOpZoomCompat$Companion r0 = androidx.camera.camera2.compat.NoOpZoomCompat.Companion
                    java.util.List r0 = r0.getRequiredCharacteristics()
                    java.lang.Iterable r0 = (java.lang.Iterable) r0
                    boolean r1 = r0 instanceof java.util.Collection
                    if (r1 == 0) goto L25
                    r1 = r0
                    java.util.Collection r1 = (java.util.Collection) r1
                    boolean r1 = r1.isEmpty()
                    if (r1 == 0) goto L25
                    goto L86
                L25:
                    java.util.Iterator r0 = r0.iterator()
                L29:
                    boolean r1 = r0.hasNext()
                    if (r1 == 0) goto L86
                    java.lang.Object r1 = r0.next()
                    android.hardware.camera2.CameraCharacteristics$Key r1 = (android.hardware.camera2.CameraCharacteristics.Key) r1
                    androidx.camera.camera2.impl.Camera2Logger r2 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
                    java.lang.String r2 = "CXCP"
                    boolean r2 = androidx.camera.core.Logger.isWarnEnabled(r2)
                    if (r2 == 0) goto L59
                    java.lang.String r2 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder
                    java.lang.String r4 = "Failed to read "
                    r3.<init>(r4)
                    r3.append(r1)
                    java.lang.String r4 = " for zoom features."
                    r3.append(r4)
                    java.lang.String r3 = r3.toString()
                    android.util.Log.w(r2, r3)
                L59:
                    androidx.camera.camera2.pipe.CameraMetadata r2 = r6.getMetadata()
                    kotlin.jvm.internal.Intrinsics.checkNotNull(r1)
                    java.lang.Object r1 = r2.get(r1)
                    if (r1 != 0) goto L29
                    androidx.camera.camera2.compat.NoOpZoomCompat r0 = new androidx.camera.camera2.compat.NoOpZoomCompat
                    r0.<init>(r6)
                    androidx.camera.camera2.compat.ZoomCompat r0 = (androidx.camera.camera2.compat.ZoomCompat) r0
                    return r0
                L6e:
                    int r0 = android.os.Build.VERSION.SDK_INT
                    r1 = 30
                    if (r0 < r1) goto L86
                    androidx.camera.camera2.pipe.CameraMetadata r0 = r6.getMetadata()
                    android.util.Range r0 = androidx.camera.camera2.compat.workaround.CameraMetadataSafeGetterKt.getControlZoomRatioRangeSafely(r0)
                    if (r0 == 0) goto L86
                    androidx.camera.camera2.compat.AndroidRZoomCompat r1 = new androidx.camera.camera2.compat.AndroidRZoomCompat
                    r1.<init>(r6, r0)
                    androidx.camera.camera2.compat.ZoomCompat r1 = (androidx.camera.camera2.compat.ZoomCompat) r1
                    return r1
                L86:
                    androidx.camera.camera2.compat.CropRegionZoomCompat r0 = new androidx.camera.camera2.compat.CropRegionZoomCompat
                    r0.<init>(r6)
                    androidx.camera.camera2.compat.ZoomCompat r0 = (androidx.camera.camera2.compat.ZoomCompat) r0
                    return r0
            }
        }

        static {
                androidx.camera.camera2.compat.ZoomCompat$Bindings$Companion r0 = new androidx.camera.camera2.compat.ZoomCompat$Bindings$Companion
                r1 = 0
                r0.<init>(r1)
                androidx.camera.camera2.compat.ZoomCompat.Bindings.Companion = r0
                return
        }

        public Bindings() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    kotlinx.coroutines.Deferred<kotlin.Unit> applyAsync(float r1, androidx.camera.camera2.impl.UseCaseCameraRequestControl r2);

    android.graphics.Rect getCropSensorRegion();

    float getMaxZoomRatio();

    float getMinZoomRatio();

    kotlinx.coroutines.Deferred<kotlin.Unit> resetAsync(androidx.camera.camera2.impl.UseCaseCameraRequestControl r1);
}
