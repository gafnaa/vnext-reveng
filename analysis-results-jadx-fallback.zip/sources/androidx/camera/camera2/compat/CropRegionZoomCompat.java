package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: ZoomCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u001e\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u00102\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\u0016\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00110\u00102\u0006\u0010\u0013\u001a\u00020\u0014H\u0016J\b\u0010\u0016\u001a\u00020\rH\u0016J\u0018\u0010\u0017\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0012\u001a\u00020\u0007H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\u00020\u00078VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\tR\u0014\u0010\n\u001a\u00020\u00078VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\tR\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"Landroidx/camera/camera2/compat/CropRegionZoomCompat;", "Landroidx/camera/camera2/compat/ZoomCompat;", "cameraProperties", "Landroidx/camera/camera2/impl/CameraProperties;", "<init>", "(Landroidx/camera/camera2/impl/CameraProperties;)V", "minZoomRatio", "", "getMinZoomRatio", "()F", "maxZoomRatio", "getMaxZoomRatio", "currentCropRect", "Landroid/graphics/Rect;", "sensorRect", "applyAsync", "Lkotlinx/coroutines/Deferred;", "", "zoomRatio", "requestControl", "Landroidx/camera/camera2/impl/UseCaseCameraRequestControl;", "resetAsync", "getCropSensorRegion", "computeCropRect", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class CropRegionZoomCompat implements androidx.camera.camera2.compat.ZoomCompat {
    private final androidx.camera.camera2.impl.CameraProperties cameraProperties;
    private android.graphics.Rect currentCropRect;
    private final android.graphics.Rect sensorRect;

    public CropRegionZoomCompat(androidx.camera.camera2.impl.CameraProperties r3) {
            r2 = this;
            java.lang.String r0 = "cameraProperties"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r2.<init>()
            r2.cameraProperties = r3
            androidx.camera.camera2.pipe.CameraMetadata r3 = r3.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE
            java.lang.String r1 = "SENSOR_INFO_ACTIVE_ARRAY_SIZE"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            java.lang.Object r3 = r3.get(r0)
            kotlin.jvm.internal.Intrinsics.checkNotNull(r3)
            android.graphics.Rect r3 = (android.graphics.Rect) r3
            r2.sensorRect = r3
            return
    }

    private final android.graphics.Rect computeCropRect(android.graphics.Rect r6, float r7) {
            r5 = this;
            androidx.camera.camera2.internal.ZoomMath r0 = androidx.camera.camera2.internal.ZoomMath.INSTANCE
            boolean r0 = r0.nearZero$camera_camera2(r7)
            if (r0 == 0) goto L1d
            androidx.camera.camera2.impl.Camera2Logger r7 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r7 = "CXCP"
            boolean r7 = androidx.camera.core.Logger.isWarnEnabled(r7)
            if (r7 == 0) goto L1b
            java.lang.String r7 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.String r0 = "ZoomCompat: Invalid zoom ratio of 0.0f passed in, defaulting to 1.0f"
            android.util.Log.w(r7, r0)
        L1b:
            r7 = 1065353216(0x3f800000, float:1.0)
        L1d:
            int r0 = r6.width()
            float r0 = (float) r0
            float r0 = r0 / r7
            int r1 = r6.height()
            float r1 = (float) r1
            float r1 = r1 / r7
            int r7 = r6.width()
            float r7 = (float) r7
            float r7 = r7 - r0
            r2 = 1073741824(0x40000000, float:2.0)
            float r7 = r7 / r2
            int r6 = r6.height()
            float r6 = (float) r6
            float r6 = r6 - r1
            float r6 = r6 / r2
            android.graphics.Rect r2 = new android.graphics.Rect
            int r3 = (int) r7
            int r4 = (int) r6
            float r7 = r7 + r0
            int r7 = (int) r7
            float r6 = r6 + r1
            int r6 = (int) r6
            r2.<init>(r3, r4, r7, r6)
            return r2
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public kotlinx.coroutines.Deferred<kotlin.Unit> applyAsync(float r7, androidx.camera.camera2.impl.UseCaseCameraRequestControl r8) {
            r6 = this;
            java.lang.String r0 = "requestControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            android.graphics.Rect r0 = r6.sensorRect
            android.graphics.Rect r7 = r6.computeCropRect(r0, r7)
            r6.currentCropRect = r7
            android.hardware.camera2.CaptureRequest$Key r7 = android.hardware.camera2.CaptureRequest.SCALER_CROP_REGION
            android.graphics.Rect r0 = r6.currentCropRect
            java.lang.String r1 = "null cannot be cast to non-null type kotlin.Any"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0, r1)
            java.lang.Object r0 = (java.lang.Object) r0
            kotlin.Pair r7 = kotlin.TuplesKt.to(r7, r0)
            java.util.Map r1 = kotlin.collections.MapsKt.mapOf(r7)
            r4 = 6
            r5 = 0
            r2 = 0
            r3 = 0
            r0 = r8
            kotlinx.coroutines.Deferred r7 = androidx.camera.camera2.impl.UseCaseCameraRequestControl.setParametersAsync$default(r0, r1, r2, r3, r4, r5)
            return r7
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public android.graphics.Rect getCropSensorRegion() {
            r1 = this;
            android.graphics.Rect r0 = r1.currentCropRect
            if (r0 != 0) goto L6
            android.graphics.Rect r0 = r1.sensorRect
        L6:
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public float getMaxZoomRatio() {
            r4 = this;
            androidx.camera.camera2.impl.CameraProperties r0 = r4.cameraProperties
            androidx.camera.camera2.pipe.CameraMetadata r0 = r0.getMetadata()
            android.hardware.camera2.CameraCharacteristics$Key r1 = android.hardware.camera2.CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM
            java.lang.String r2 = "SCALER_AVAILABLE_MAX_DIGITAL_ZOOM"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            float r2 = r4.getMinZoomRatio()
            java.lang.Float r2 = java.lang.Float.valueOf(r2)
            java.lang.Object r0 = r0.getOrDefault(r1, r2)
            java.lang.Float r0 = (java.lang.Float) r0
            androidx.camera.camera2.internal.ZoomMath r1 = androidx.camera.camera2.internal.ZoomMath.INSTANCE
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            float r2 = r0.floatValue()
            boolean r1 = r1.nearZero$camera_camera2(r2)
            if (r1 == 0) goto L51
            androidx.camera.camera2.impl.Camera2Logger r1 = androidx.camera.camera2.impl.Camera2Logger.INSTANCE
            java.lang.String r1 = "CXCP"
            boolean r1 = androidx.camera.core.Logger.isWarnEnabled(r1)
            if (r1 == 0) goto L4e
            java.lang.String r1 = androidx.camera.camera2.impl.Camera2Logger.access$getTRUNCATED_TAG$p()
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Invalid max zoom ratio of "
            r2.<init>(r3)
            r2.append(r0)
            java.lang.String r0 = " detected, defaulting to 1.0f"
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            android.util.Log.w(r1, r0)
        L4e:
            r0 = 1065353216(0x3f800000, float:1.0)
            return r0
        L51:
            float r0 = r0.floatValue()
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public float getMinZoomRatio() {
            r1 = this;
            r0 = 1065353216(0x3f800000, float:1.0)
            return r0
    }

    @Override // androidx.camera.camera2.compat.ZoomCompat
    public kotlinx.coroutines.Deferred<kotlin.Unit> resetAsync(androidx.camera.camera2.impl.UseCaseCameraRequestControl r4) {
            r3 = this;
            java.lang.String r0 = "requestControl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            android.hardware.camera2.CaptureRequest$Key r0 = android.hardware.camera2.CaptureRequest.SCALER_CROP_REGION
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r0)
            r1 = 0
            r2 = 2
            kotlinx.coroutines.Deferred r4 = androidx.camera.camera2.impl.UseCaseCameraRequestControl.removeParametersAsync$default(r4, r0, r1, r2, r1)
            return r4
    }
}
