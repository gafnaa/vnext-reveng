package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: EvCompCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0003\"\u001a\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"EMPTY_RANGE", "Landroid/util/Range;", "", "getEMPTY_RANGE", "()Landroid/util/Range;", "camera-camera2"}, k = 2, mv = {2, 1, 0}, xi = 48)
public final class EvCompCompatKt {
    private static final android.util.Range<java.lang.Integer> EMPTY_RANGE = null;

    static {
            android.util.Range r0 = new android.util.Range
            r1 = 0
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r2 = r1
            java.lang.Comparable r2 = (java.lang.Comparable) r2
            java.lang.Comparable r1 = (java.lang.Comparable) r1
            r0.<init>(r2, r1)
            androidx.camera.camera2.compat.EvCompCompatKt.EMPTY_RANGE = r0
            return
    }

    public static final android.util.Range<java.lang.Integer> getEMPTY_RANGE() {
            android.util.Range<java.lang.Integer> r0 = androidx.camera.camera2.compat.EvCompCompatKt.EMPTY_RANGE
            return r0
    }
}
