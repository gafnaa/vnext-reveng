package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: StreamConfigurationMapCompatApi34Impl.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0002\b\u0001\u0018\u00002\u00020\u0001B\u0011\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0015\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bH\u0016¢\u0006\u0002\u0010\rJ\u001d\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000b2\u0006\u0010\u0010\u001a\u00020\fH\u0016¢\u0006\u0002\u0010\u0011J\u001d\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000b2\u0006\u0010\u0010\u001a\u00020\fH\u0016¢\u0006\u0002\u0010\u0011J\u0018\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0010\u001a\u00020\f2\u0006\u0010\u0015\u001a\u00020\u000fH\u0016R\u0014\u0010\u0006\u001a\u00020\u00078BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\b\u0010\t¨\u0006\u0016"}, d2 = {"Landroidx/camera/camera2/compat/StreamConfigurationMapCompatApi34Impl;", "Landroidx/camera/camera2/compat/StreamConfigurationMapCompatBaseImpl;", "map", "Landroid/hardware/camera2/params/StreamConfigurationMap;", "<init>", "(Landroid/hardware/camera2/params/StreamConfigurationMap;)V", "hasJpegRQuirk", "", "getHasJpegRQuirk", "()Z", "getOutputFormats", "", "", "()[Ljava/lang/Integer;", "getOutputSizes", "Landroid/util/Size;", "format", "(I)[Landroid/util/Size;", "getHighResolutionOutputSizes", "getOutputMinFrameDuration", "", "size", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class StreamConfigurationMapCompatApi34Impl extends androidx.camera.camera2.compat.StreamConfigurationMapCompatBaseImpl {
    public StreamConfigurationMapCompatApi34Impl(android.hardware.camera2.params.StreamConfigurationMap r1) {
            r0 = this;
            r0.<init>(r1)
            return
    }

    private final boolean getHasJpegRQuirk() {
            r2 = this;
            androidx.camera.camera2.compat.quirk.DeviceQuirks r0 = androidx.camera.camera2.compat.quirk.DeviceQuirks.INSTANCE
            java.lang.Class<androidx.camera.camera2.compat.quirk.PixelJpegRSupportedQuirk> r1 = androidx.camera.camera2.compat.quirk.PixelJpegRSupportedQuirk.class
            androidx.camera.core.impl.Quirk r0 = r0.get(r1)
            if (r0 == 0) goto Lc
            r0 = 1
            return r0
        Lc:
            r0 = 0
            return r0
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompatBaseImpl, androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.util.Size[] getHighResolutionOutputSizes(int r2) {
            r1 = this;
            r0 = 4101(0x1005, float:5.747E-42)
            if (r2 != r0) goto Lc
            boolean r0 = r1.getHasJpegRQuirk()
            if (r0 == 0) goto Lc
            r2 = 0
            return r2
        Lc:
            android.util.Size[] r2 = super.getHighResolutionOutputSizes(r2)
            return r2
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompatBaseImpl, androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public java.lang.Integer[] getOutputFormats() {
            r8 = this;
            java.lang.Integer[] r0 = super.getOutputFormats()
            boolean r1 = r8.getHasJpegRQuirk()
            if (r1 == 0) goto L39
            if (r0 == 0) goto L38
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.Collection r1 = (java.util.Collection) r1
            int r2 = r0.length
            r3 = 0
            r4 = r3
        L16:
            if (r4 >= r2) goto L2b
            r5 = r0[r4]
            r6 = r5
            java.lang.Number r6 = (java.lang.Number) r6
            int r6 = r6.intValue()
            r7 = 4101(0x1005, float:5.747E-42)
            if (r6 == r7) goto L28
            r1.add(r5)
        L28:
            int r4 = r4 + 1
            goto L16
        L2b:
            java.util.List r1 = (java.util.List) r1
            java.util.Collection r1 = (java.util.Collection) r1
            java.lang.Integer[] r0 = new java.lang.Integer[r3]
            java.lang.Object[] r0 = r1.toArray(r0)
            java.lang.Integer[] r0 = (java.lang.Integer[]) r0
            return r0
        L38:
            r0 = 0
        L39:
            return r0
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompatBaseImpl, androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public long getOutputMinFrameDuration(int r2, android.util.Size r3) {
            r1 = this;
            java.lang.String r0 = "size"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            r0 = 4101(0x1005, float:5.747E-42)
            if (r2 != r0) goto L12
            boolean r0 = r1.getHasJpegRQuirk()
            if (r0 == 0) goto L12
            r2 = 0
            return r2
        L12:
            long r2 = super.getOutputMinFrameDuration(r2, r3)
            return r2
    }

    @Override // androidx.camera.camera2.compat.StreamConfigurationMapCompatBaseImpl, androidx.camera.camera2.compat.StreamConfigurationMapCompat.StreamConfigurationMapCompatImpl
    public android.util.Size[] getOutputSizes(int r2) {
            r1 = this;
            r0 = 4101(0x1005, float:5.747E-42)
            if (r2 != r0) goto Lc
            boolean r0 = r1.getHasJpegRQuirk()
            if (r0 == 0) goto Lc
            r2 = 0
            return r2
        Lc:
            android.util.Size[] r2 = super.getOutputSizes(r2)
            return r2
    }
}
