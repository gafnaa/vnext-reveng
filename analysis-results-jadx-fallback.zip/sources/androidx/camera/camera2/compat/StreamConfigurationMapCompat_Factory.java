package androidx.camera.camera2.compat;

/* JADX INFO: loaded from: classes.dex */
public final class StreamConfigurationMapCompat_Factory implements dagger.internal.Factory<androidx.camera.camera2.compat.StreamConfigurationMapCompat> {
    private final dagger.internal.Provider<android.hardware.camera2.params.StreamConfigurationMap> mapProvider;
    private final dagger.internal.Provider<androidx.camera.camera2.compat.workaround.OutputSizesCorrector> outputSizesCorrectorProvider;

    private StreamConfigurationMapCompat_Factory(dagger.internal.Provider<android.hardware.camera2.params.StreamConfigurationMap> r1, dagger.internal.Provider<androidx.camera.camera2.compat.workaround.OutputSizesCorrector> r2) {
            r0 = this;
            r0.<init>()
            r0.mapProvider = r1
            r0.outputSizesCorrectorProvider = r2
            return
    }

    public static androidx.camera.camera2.compat.StreamConfigurationMapCompat_Factory create(dagger.internal.Provider<android.hardware.camera2.params.StreamConfigurationMap> r1, dagger.internal.Provider<androidx.camera.camera2.compat.workaround.OutputSizesCorrector> r2) {
            androidx.camera.camera2.compat.StreamConfigurationMapCompat_Factory r0 = new androidx.camera.camera2.compat.StreamConfigurationMapCompat_Factory
            r0.<init>(r1, r2)
            return r0
    }

    public static androidx.camera.camera2.compat.StreamConfigurationMapCompat newInstance(android.hardware.camera2.params.StreamConfigurationMap r1, androidx.camera.camera2.compat.workaround.OutputSizesCorrector r2) {
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = new androidx.camera.camera2.compat.StreamConfigurationMapCompat
            r0.<init>(r1, r2)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public androidx.camera.camera2.compat.StreamConfigurationMapCompat get() {
            r2 = this;
            dagger.internal.Provider<android.hardware.camera2.params.StreamConfigurationMap> r0 = r2.mapProvider
            java.lang.Object r0 = r0.get()
            android.hardware.camera2.params.StreamConfigurationMap r0 = (android.hardware.camera2.params.StreamConfigurationMap) r0
            dagger.internal.Provider<androidx.camera.camera2.compat.workaround.OutputSizesCorrector> r1 = r2.outputSizesCorrectorProvider
            java.lang.Object r1 = r1.get()
            androidx.camera.camera2.compat.workaround.OutputSizesCorrector r1 = (androidx.camera.camera2.compat.workaround.OutputSizesCorrector) r1
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = newInstance(r0, r1)
            return r0
    }

    @Override // javax.inject.Provider, jakarta.inject.Provider
    public /* bridge */ /* synthetic */ java.lang.Object get() {
            r1 = this;
            androidx.camera.camera2.compat.StreamConfigurationMapCompat r0 = r1.get()
            return r0
    }
}
