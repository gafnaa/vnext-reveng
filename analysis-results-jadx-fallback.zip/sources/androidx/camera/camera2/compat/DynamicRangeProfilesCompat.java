package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: DynamicRangeProfilesCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u00122\u00020\u0001:\u0002\u0011\u0012B\u0011\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u0006\u0010\f\u001a\u00020\bJ\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\f\u001a\u00020\bJ\n\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0007R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00078F¢\u0006\u0006\u001a\u0004\b\t\u0010\n¨\u0006\u0013"}, d2 = {"Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat;", "", "impl", "Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl;", "<init>", "(Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl;)V", "supportedDynamicRanges", "", "Landroidx/camera/core/DynamicRange;", "getSupportedDynamicRanges", "()Ljava/util/Set;", "getDynamicRangeCaptureRequestConstraints", "dynamicRange", "isExtraLatencyPresent", "", "toDynamicRangeProfiles", "Landroid/hardware/camera2/params/DynamicRangeProfiles;", "DynamicRangeProfilesCompatImpl", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DynamicRangeProfilesCompat {
    public static final androidx.camera.camera2.compat.DynamicRangeProfilesCompat.Companion Companion = null;
    private final androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl impl;

    /* JADX INFO: compiled from: DynamicRangeProfilesCompat.kt */
    @kotlin.Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007J\u0014\u0010\b\u001a\u0004\u0018\u00010\u00052\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0007¨\u0006\u000b"}, d2 = {"Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat$Companion;", "", "<init>", "()V", "fromCameraMetaData", "Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat;", "cameraMetadata", "Landroidx/camera/camera2/pipe/CameraMetadata;", "toDynamicRangesCompat", "dynamicRangeProfiles", "Landroid/hardware/camera2/params/DynamicRangeProfiles;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final androidx.camera.camera2.compat.DynamicRangeProfilesCompat fromCameraMetaData(androidx.camera.camera2.pipe.CameraMetadata r3) {
                r2 = this;
                java.lang.String r0 = "cameraMetadata"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                int r0 = android.os.Build.VERSION.SDK_INT
                r1 = 33
                if (r0 < r1) goto L21
                android.hardware.camera2.CameraCharacteristics$Key r0 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m34m$2()
                java.lang.String r1 = "REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES"
                kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
                java.lang.Object r3 = r3.get(r0)
                android.hardware.camera2.params.DynamicRangeProfiles r3 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m18m(r3)
                androidx.camera.camera2.compat.DynamicRangeProfilesCompat r3 = r2.toDynamicRangesCompat(r3)
                goto L22
            L21:
                r3 = 0
            L22:
                if (r3 != 0) goto L2a
                androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl$Companion r3 = androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.Companion
                androidx.camera.camera2.compat.DynamicRangeProfilesCompat r3 = r3.getCOMPAT_INSTANCE()
            L2a:
                return r3
        }

        public final androidx.camera.camera2.compat.DynamicRangeProfilesCompat toDynamicRangesCompat(android.hardware.camera2.params.DynamicRangeProfiles r3) {
                r2 = this;
                if (r3 != 0) goto L4
                r3 = 0
                return r3
            L4:
                r0 = 33
                int r1 = android.os.Build.VERSION.SDK_INT
                if (r1 < r0) goto L17
                androidx.camera.camera2.compat.DynamicRangeProfilesCompat r0 = new androidx.camera.camera2.compat.DynamicRangeProfilesCompat
                androidx.camera.camera2.compat.DynamicRangeProfilesCompatApi33Impl r1 = new androidx.camera.camera2.compat.DynamicRangeProfilesCompatApi33Impl
                r1.<init>(r3)
                androidx.camera.camera2.compat.DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl r1 = (androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl) r1
                r0.<init>(r1)
                return r0
            L17:
                java.lang.StringBuilder r3 = new java.lang.StringBuilder
                java.lang.String r0 = "DynamicRangeProfiles can only be converted to DynamicRangesCompat on API 33 or higher. is not supported on API "
                r3.<init>(r0)
                int r0 = android.os.Build.VERSION.SDK_INT
                r3.append(r0)
                java.lang.String r0 = " (requires API 33)"
                r3.append(r0)
                java.lang.String r3 = r3.toString()
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r3 = r3.toString()
                r0.<init>(r3)
                throw r0
        }
    }

    /* JADX INFO: compiled from: DynamicRangeProfilesCompat.kt */
    @kotlin.Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\b`\u0018\u00002\u00020\u0001J\u0016\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u0006\u0010\b\u001a\u00020\u0004H&J\u0010\u0010\t\u001a\u00020\n2\u0006\u0010\b\u001a\u00020\u0004H&J\n\u0010\u000b\u001a\u0004\u0018\u00010\fH&R\u0018\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0005\u0010\u0006ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\rÀ\u0006\u0001"}, d2 = {"Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl;", "", "supportedDynamicRanges", "", "Landroidx/camera/core/DynamicRange;", "getSupportedDynamicRanges", "()Ljava/util/Set;", "getDynamicRangeCaptureRequestConstraints", "dynamicRange", "isExtraLatencyPresent", "", "unwrap", "Landroid/hardware/camera2/params/DynamicRangeProfiles;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public interface DynamicRangeProfilesCompatImpl {
        java.util.Set<androidx.camera.core.DynamicRange> getDynamicRangeCaptureRequestConstraints(androidx.camera.core.DynamicRange r1);

        java.util.Set<androidx.camera.core.DynamicRange> getSupportedDynamicRanges();

        boolean isExtraLatencyPresent(androidx.camera.core.DynamicRange r1);

        android.hardware.camera2.params.DynamicRangeProfiles unwrap();
    }

    static {
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat$Companion r0 = new androidx.camera.camera2.compat.DynamicRangeProfilesCompat$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat.Companion = r0
            return
    }

    public DynamicRangeProfilesCompat(androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl r2) {
            r1 = this;
            java.lang.String r0 = "impl"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.impl = r2
            return
    }

    public final java.util.Set<androidx.camera.core.DynamicRange> getDynamicRangeCaptureRequestConstraints(androidx.camera.core.DynamicRange r2) {
            r1 = this;
            java.lang.String r0 = "dynamicRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl r0 = r1.impl
            java.util.Set r2 = r0.getDynamicRangeCaptureRequestConstraints(r2)
            return r2
    }

    public final java.util.Set<androidx.camera.core.DynamicRange> getSupportedDynamicRanges() {
            r1 = this;
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl r0 = r1.impl
            java.util.Set r0 = r0.getSupportedDynamicRanges()
            return r0
    }

    public final boolean isExtraLatencyPresent(androidx.camera.core.DynamicRange r2) {
            r1 = this;
            java.lang.String r0 = "dynamicRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl r0 = r1.impl
            boolean r2 = r0.isExtraLatencyPresent(r2)
            return r2
    }

    public final android.hardware.camera2.params.DynamicRangeProfiles toDynamicRangeProfiles() {
            r2 = this;
            r0 = 33
            int r1 = android.os.Build.VERSION.SDK_INT
            if (r1 < r0) goto Ld
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl r0 = r2.impl
            android.hardware.camera2.params.DynamicRangeProfiles r0 = r0.unwrap()
            return r0
        Ld:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "DynamicRangesCompat can only be converted to DynamicRangeProfiles on API 33 or higher. is not supported on API "
            r0.<init>(r1)
            int r1 = android.os.Build.VERSION.SDK_INT
            r0.append(r1)
            java.lang.String r1 = " (requires API 33)"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r0 = r0.toString()
            r1.<init>(r0)
            throw r1
    }
}
