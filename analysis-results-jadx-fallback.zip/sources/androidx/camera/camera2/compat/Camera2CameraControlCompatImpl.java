package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: Camera2CameraControlCompat.kt */
/* JADX INFO: loaded from: classes.dex */
@androidx.camera.camera2.config.CameraScope
@kotlin.Metadata(d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\t\b\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016J\b\u0010\u0011\u001a\u00020\u0010H\u0016J\b\u0010\u0012\u001a\u00020\u000eH\u0016J\b\u0010\u0013\u001a\u00020\u000eH\u0016J\"\u0010\u0014\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u00172\u0006\u0010\u0018\u001a\u00020\u0019H\u0016J&\u0010\u001a\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\n*\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\n2\b\b\u0002\u0010\u001b\u001a\u00020\u001cH\u0002J'\u0010\u001d\u001a\u00020\u000e2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#H\u0016¢\u0006\u0004\b$\u0010%R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0012\u0010\u0007\u001a\u00020\b8\u0002@\u0002X\u0083\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u000b\u0018\u00010\n8\u0002@\u0002X\u0083\u000e¢\u0006\u0002\n\u0000R\u001c\u0010\f\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u000b\u0018\u00010\n8\u0002@\u0002X\u0083\u000e¢\u0006\u0002\n\u0000¨\u0006&"}, d2 = {"Landroidx/camera/camera2/compat/Camera2CameraControlCompatImpl;", "Landroidx/camera/camera2/compat/Camera2CameraControlCompat;", "<init>", "()V", "lock", "", "updateSignalLock", "configBuilder", "Landroidx/camera/camera2/impl/Camera2ImplConfig$Builder;", "updateSignal", "Lkotlinx/coroutines/CompletableDeferred;", "Ljava/lang/Void;", "pendingSignal", "addRequestOption", "", "bundle", "Landroidx/camera/camera2/interop/CaptureRequestOptions;", "getRequestOption", "clearRequestOption", "cancelCurrentTask", "applyAsync", "Lkotlinx/coroutines/Deferred;", "requestControl", "Landroidx/camera/camera2/impl/UseCaseCameraRequestControl;", "cancelPreviousTask", "", "cancelSignal", "msg", "", "onComplete", "requestMetadata", "Landroidx/camera/camera2/pipe/RequestMetadata;", "frameNumber", "Landroidx/camera/camera2/pipe/FrameNumber;", "result", "Landroidx/camera/camera2/pipe/FrameInfo;", "onComplete-CcXjc1I", "(Landroidx/camera/camera2/pipe/RequestMetadata;JLandroidx/camera/camera2/pipe/FrameInfo;)V", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class Camera2CameraControlCompatImpl implements androidx.camera.camera2.compat.Camera2CameraControlCompat {
    private androidx.camera.camera2.impl.Camera2ImplConfig.Builder configBuilder;
    private final java.lang.Object lock;
    private kotlinx.coroutines.CompletableDeferred<java.lang.Void> pendingSignal;
    private kotlinx.coroutines.CompletableDeferred<java.lang.Void> updateSignal;
    private final java.lang.Object updateSignalLock;

    @javax.inject.Inject
    public Camera2CameraControlCompatImpl() {
            r1 = this;
            r1.<init>()
            java.lang.Object r0 = new java.lang.Object
            r0.<init>()
            r1.lock = r0
            java.lang.Object r0 = new java.lang.Object
            r0.<init>()
            r1.updateSignalLock = r0
            androidx.camera.camera2.impl.Camera2ImplConfig$Builder r0 = new androidx.camera.camera2.impl.Camera2ImplConfig$Builder
            r0.<init>()
            r1.configBuilder = r0
            return
    }

    private final kotlinx.coroutines.CompletableDeferred<java.lang.Void> cancelSignal(kotlinx.coroutines.CompletableDeferred<java.lang.Void> r2, java.lang.String r3) {
            r1 = this;
            androidx.camera.core.CameraControl$OperationCanceledException r0 = new androidx.camera.core.CameraControl$OperationCanceledException
            r0.<init>(r3)
            java.lang.Throwable r0 = (java.lang.Throwable) r0
            r2.completeExceptionally(r0)
            return r2
    }

    static /* synthetic */ kotlinx.coroutines.CompletableDeferred cancelSignal$default(androidx.camera.camera2.compat.Camera2CameraControlCompatImpl r0, kotlinx.coroutines.CompletableDeferred r1, java.lang.String r2, int r3, java.lang.Object r4) {
            r3 = r3 & 1
            if (r3 == 0) goto L6
            java.lang.String r2 = "Camera2CameraControl was updated with new options."
        L6:
            kotlinx.coroutines.CompletableDeferred r0 = r0.cancelSignal(r1, r2)
            return r0
    }

    @Override // androidx.camera.camera2.compat.Camera2CameraControlCompat
    public void addRequestOption(androidx.camera.camera2.interop.CaptureRequestOptions r7) {
            r6 = this;
            java.lang.String r0 = "bundle"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.Object r0 = r6.lock
            monitor-enter(r0)
            java.util.Set r1 = r7.listOptions()     // Catch: java.lang.Throwable -> L35
            java.util.Iterator r1 = r1.iterator()     // Catch: java.lang.Throwable -> L35
        L10:
            boolean r2 = r1.hasNext()     // Catch: java.lang.Throwable -> L35
            if (r2 == 0) goto L31
            java.lang.Object r2 = r1.next()     // Catch: java.lang.Throwable -> L35
            androidx.camera.core.impl.Config$Option r2 = (androidx.camera.core.impl.Config.Option) r2     // Catch: java.lang.Throwable -> L35
            java.lang.String r3 = "null cannot be cast to non-null type androidx.camera.core.impl.Config.Option<kotlin.Any>"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r2, r3)     // Catch: java.lang.Throwable -> L35
            androidx.camera.camera2.impl.Camera2ImplConfig$Builder r3 = r6.configBuilder     // Catch: java.lang.Throwable -> L35
            androidx.camera.core.impl.MutableConfig r3 = r3.getMutableConfig()     // Catch: java.lang.Throwable -> L35
            androidx.camera.core.impl.Config$OptionPriority r4 = androidx.camera.core.impl.Config.OptionPriority.ALWAYS_OVERRIDE     // Catch: java.lang.Throwable -> L35
            java.lang.Object r5 = r7.retrieveOption(r2)     // Catch: java.lang.Throwable -> L35
            r3.insertOption(r2, r4, r5)     // Catch: java.lang.Throwable -> L35
            goto L10
        L31:
            kotlin.Unit r7 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L35
            monitor-exit(r0)
            return
        L35:
            r7 = move-exception
            monitor-exit(r0)
            throw r7
    }

    @Override // androidx.camera.camera2.compat.Camera2CameraControlCompat
    public kotlinx.coroutines.Deferred<java.lang.Void> applyAsync(androidx.camera.camera2.impl.UseCaseCameraRequestControl r6, boolean r7) {
            r5 = this;
            r0 = 0
            r1 = 1
            kotlinx.coroutines.CompletableDeferred r2 = kotlinx.coroutines.CompletableDeferredKt.CompletableDeferred$default(r0, r1, r0)
            java.lang.Object r3 = r5.lock
            monitor-enter(r3)
            androidx.camera.camera2.impl.Camera2ImplConfig$Builder r4 = r5.configBuilder     // Catch: java.lang.Throwable -> L55
            androidx.camera.camera2.impl.Camera2ImplConfig r4 = r4.build()     // Catch: java.lang.Throwable -> L55
            monitor-exit(r3)
            java.lang.Object r3 = r5.updateSignalLock
            monitor-enter(r3)
            if (r6 == 0) goto L43
            if (r7 == 0) goto L1f
            kotlinx.coroutines.CompletableDeferred<java.lang.Void> r7 = r5.updateSignal     // Catch: java.lang.Throwable -> L52
            if (r7 == 0) goto L29
            cancelSignal$default(r5, r7, r0, r1, r0)     // Catch: java.lang.Throwable -> L52
            goto L29
        L1f:
            kotlinx.coroutines.CompletableDeferred<java.lang.Void> r7 = r5.updateSignal     // Catch: java.lang.Throwable -> L52
            if (r7 == 0) goto L29
            r0 = r2
            kotlinx.coroutines.Deferred r0 = (kotlinx.coroutines.Deferred) r0     // Catch: java.lang.Throwable -> L52
            androidx.camera.camera2.adapter.CoroutineAdaptersKt.propagateTo(r0, r7)     // Catch: java.lang.Throwable -> L52
        L29:
            r5.updateSignal = r2     // Catch: java.lang.Throwable -> L52
            androidx.camera.core.impl.Config r4 = (androidx.camera.core.impl.Config) r4     // Catch: java.lang.Throwable -> L52
            java.lang.String r7 = "Camera2CameraControl.tag"
            int r0 = r2.hashCode()     // Catch: java.lang.Throwable -> L52
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)     // Catch: java.lang.Throwable -> L52
            kotlin.Pair r7 = kotlin.TuplesKt.to(r7, r0)     // Catch: java.lang.Throwable -> L52
            java.util.Map r7 = kotlin.collections.MapsKt.mapOf(r7)     // Catch: java.lang.Throwable -> L52
            r6.updateCamera2ConfigAsync(r4, r7)     // Catch: java.lang.Throwable -> L52
            goto L4e
        L43:
            kotlinx.coroutines.CompletableDeferred<java.lang.Void> r6 = r5.pendingSignal     // Catch: java.lang.Throwable -> L52
            if (r6 == 0) goto L4a
            cancelSignal$default(r5, r6, r0, r1, r0)     // Catch: java.lang.Throwable -> L52
        L4a:
            r5.pendingSignal = r2     // Catch: java.lang.Throwable -> L52
            kotlin.Unit r6 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L52
        L4e:
            monitor-exit(r3)
            kotlinx.coroutines.Deferred r2 = (kotlinx.coroutines.Deferred) r2
            return r2
        L52:
            r6 = move-exception
            monitor-exit(r3)
            throw r6
        L55:
            r6 = move-exception
            monitor-exit(r3)
            throw r6
    }

    @Override // androidx.camera.camera2.compat.Camera2CameraControlCompat
    public void cancelCurrentTask() {
            r4 = this;
            java.lang.Object r0 = r4.updateSignalLock
            monitor-enter(r0)
            kotlinx.coroutines.CompletableDeferred<java.lang.Void> r1 = r4.updateSignal     // Catch: java.lang.Throwable -> L1e
            r2 = 0
            if (r1 == 0) goto Lf
            r4.updateSignal = r2     // Catch: java.lang.Throwable -> L1e
            java.lang.String r3 = "The camera control has became inactive."
            r4.cancelSignal(r1, r3)     // Catch: java.lang.Throwable -> L1e
        Lf:
            kotlinx.coroutines.CompletableDeferred<java.lang.Void> r1 = r4.pendingSignal     // Catch: java.lang.Throwable -> L1e
            if (r1 == 0) goto L1a
            r4.pendingSignal = r2     // Catch: java.lang.Throwable -> L1e
            java.lang.String r2 = "The camera control has became inactive."
            r4.cancelSignal(r1, r2)     // Catch: java.lang.Throwable -> L1e
        L1a:
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L1e
            monitor-exit(r0)
            return
        L1e:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    @Override // androidx.camera.camera2.compat.Camera2CameraControlCompat
    public void clearRequestOption() {
            r2 = this;
            java.lang.Object r0 = r2.lock
            monitor-enter(r0)
            androidx.camera.camera2.impl.Camera2ImplConfig$Builder r1 = new androidx.camera.camera2.impl.Camera2ImplConfig$Builder     // Catch: java.lang.Throwable -> Le
            r1.<init>()     // Catch: java.lang.Throwable -> Le
            r2.configBuilder = r1     // Catch: java.lang.Throwable -> Le
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> Le
            monitor-exit(r0)
            return
        Le:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    @Override // androidx.camera.camera2.compat.Camera2CameraControlCompat
    public androidx.camera.camera2.interop.CaptureRequestOptions getRequestOption() {
            r3 = this;
            java.lang.Object r0 = r3.lock
            monitor-enter(r0)
            androidx.camera.camera2.interop.CaptureRequestOptions$Builder$Companion r1 = androidx.camera.camera2.interop.CaptureRequestOptions.Builder.Companion     // Catch: java.lang.Throwable -> L17
            androidx.camera.camera2.impl.Camera2ImplConfig$Builder r2 = r3.configBuilder     // Catch: java.lang.Throwable -> L17
            androidx.camera.camera2.impl.Camera2ImplConfig r2 = r2.build()     // Catch: java.lang.Throwable -> L17
            androidx.camera.core.impl.Config r2 = (androidx.camera.core.impl.Config) r2     // Catch: java.lang.Throwable -> L17
            androidx.camera.camera2.interop.CaptureRequestOptions$Builder r1 = r1.from(r2)     // Catch: java.lang.Throwable -> L17
            androidx.camera.camera2.interop.CaptureRequestOptions r1 = r1.build()     // Catch: java.lang.Throwable -> L17
            monitor-exit(r0)
            return r1
        L17:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
    }

    @Override // androidx.camera.camera2.pipe.Request.Listener
    /* JADX INFO: renamed from: onComplete-CcXjc1I */
    public void mo69onCompleteCcXjc1I(androidx.camera.camera2.pipe.RequestMetadata r2, long r3, androidx.camera.camera2.pipe.FrameInfo r5) {
            r1 = this;
            java.lang.String r3 = "requestMetadata"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r3)
            java.lang.String r3 = "result"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r3)
            java.lang.Object r3 = r1.updateSignalLock
            monitor-enter(r3)
            kotlinx.coroutines.CompletableDeferred<java.lang.Void> r4 = r1.updateSignal     // Catch: java.lang.Throwable -> L34
            if (r4 == 0) goto L30
            java.lang.String r5 = "Camera2CameraControl.tag"
            int r0 = r4.hashCode()     // Catch: java.lang.Throwable -> L34
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)     // Catch: java.lang.Throwable -> L34
            boolean r2 = androidx.camera.camera2.impl.ComboRequestListenerKt.containsTag(r2, r5, r0)     // Catch: java.lang.Throwable -> L34
            if (r2 == 0) goto L30
            r2 = 0
            r4.complete(r2)     // Catch: java.lang.Throwable -> L34
            r1.updateSignal = r2     // Catch: java.lang.Throwable -> L34
            kotlinx.coroutines.CompletableDeferred<java.lang.Void> r4 = r1.pendingSignal     // Catch: java.lang.Throwable -> L34
            if (r4 == 0) goto L30
            r4.complete(r2)     // Catch: java.lang.Throwable -> L34
            r1.pendingSignal = r2     // Catch: java.lang.Throwable -> L34
        L30:
            kotlin.Unit r2 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L34
            monitor-exit(r3)
            return
        L34:
            r2 = move-exception
            monitor-exit(r3)
            throw r2
    }
}
