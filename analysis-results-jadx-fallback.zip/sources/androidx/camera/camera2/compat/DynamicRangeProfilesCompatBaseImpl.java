package androidx.camera.camera2.compat;

/* JADX INFO: compiled from: DynamicRangeProfilesCompatBaseImpl.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u0000 \u000f2\u00020\u0001:\u0001\u000fB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u0006\u0010\n\u001a\u00020\u0006H\u0016J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\n\u001a\u00020\u0006H\u0016J\n\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0016R\u001a\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\u0010"}, d2 = {"Landroidx/camera/camera2/compat/DynamicRangeProfilesCompatBaseImpl;", "Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl;", "<init>", "()V", "supportedDynamicRanges", "", "Landroidx/camera/core/DynamicRange;", "getSupportedDynamicRanges", "()Ljava/util/Set;", "getDynamicRangeCaptureRequestConstraints", "dynamicRange", "isExtraLatencyPresent", "", "unwrap", "Landroid/hardware/camera2/params/DynamicRangeProfiles;", "Companion", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DynamicRangeProfilesCompatBaseImpl implements androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl {
    private static final androidx.camera.camera2.compat.DynamicRangeProfilesCompat COMPAT_INSTANCE = null;
    public static final androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.Companion Companion = null;
    private static final java.util.Set<androidx.camera.core.DynamicRange> SDR_ONLY = null;

    /* JADX INFO: compiled from: DynamicRangeProfilesCompatBaseImpl.kt */
    @kotlin.Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u001e\u0010\b\u001a\u0012\u0012\u000e\u0012\f0\n¢\u0006\u0002\b\u000b¢\u0006\u0002\b\f0\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"}, d2 = {"Landroidx/camera/camera2/compat/DynamicRangeProfilesCompatBaseImpl$Companion;", "", "<init>", "()V", "COMPAT_INSTANCE", "Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat;", "getCOMPAT_INSTANCE", "()Landroidx/camera/camera2/compat/DynamicRangeProfilesCompat;", "SDR_ONLY", "", "Landroidx/camera/core/DynamicRange;", "Lorg/jspecify/annotations/NonNull;", "Lkotlin/jvm/internal/EnhancedNullability;", "camera-camera2"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }

        public final androidx.camera.camera2.compat.DynamicRangeProfilesCompat getCOMPAT_INSTANCE() {
                r1 = this;
                androidx.camera.camera2.compat.DynamicRangeProfilesCompat r0 = androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.access$getCOMPAT_INSTANCE$cp()
                return r0
        }
    }

    static {
            androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl$Companion r0 = new androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.Companion = r0
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat r0 = new androidx.camera.camera2.compat.DynamicRangeProfilesCompat
            androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl r1 = new androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl
            r1.<init>()
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat$DynamicRangeProfilesCompatImpl r1 = (androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl) r1
            r0.<init>(r1)
            androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.COMPAT_INSTANCE = r0
            androidx.camera.core.DynamicRange r0 = androidx.camera.core.DynamicRange.SDR
            java.util.Set r0 = kotlin.collections.SetsKt.setOf(r0)
            androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.SDR_ONLY = r0
            return
    }

    public DynamicRangeProfilesCompatBaseImpl() {
            r0 = this;
            r0.<init>()
            return
    }

    public static final /* synthetic */ androidx.camera.camera2.compat.DynamicRangeProfilesCompat access$getCOMPAT_INSTANCE$cp() {
            androidx.camera.camera2.compat.DynamicRangeProfilesCompat r0 = androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.COMPAT_INSTANCE
            return r0
    }

    @Override // androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl
    public java.util.Set<androidx.camera.core.DynamicRange> getDynamicRangeCaptureRequestConstraints(androidx.camera.core.DynamicRange r4) {
            r3 = this;
            java.lang.String r0 = "dynamicRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            androidx.camera.core.DynamicRange r0 = androidx.camera.core.DynamicRange.SDR
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r4)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "DynamicRange is not supported: "
            r1.<init>(r2)
            r1.append(r4)
            java.lang.String r4 = r1.toString()
            androidx.core.util.Preconditions.checkArgument(r0, r4)
            java.util.Set<androidx.camera.core.DynamicRange> r4 = androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.SDR_ONLY
            return r4
    }

    @Override // androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl
    public java.util.Set<androidx.camera.core.DynamicRange> getSupportedDynamicRanges() {
            r1 = this;
            java.util.Set<androidx.camera.core.DynamicRange> r0 = androidx.camera.camera2.compat.DynamicRangeProfilesCompatBaseImpl.SDR_ONLY
            return r0
    }

    @Override // androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl
    public boolean isExtraLatencyPresent(androidx.camera.core.DynamicRange r4) {
            r3 = this;
            java.lang.String r0 = "dynamicRange"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            androidx.camera.core.DynamicRange r0 = androidx.camera.core.DynamicRange.SDR
            boolean r0 = kotlin.jvm.internal.Intrinsics.areEqual(r0, r4)
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "DynamicRange is not supported: "
            r1.<init>(r2)
            r1.append(r4)
            java.lang.String r4 = r1.toString()
            androidx.core.util.Preconditions.checkArgument(r0, r4)
            r4 = 0
            return r4
    }

    @Override // androidx.camera.camera2.compat.DynamicRangeProfilesCompat.DynamicRangeProfilesCompatImpl
    public android.hardware.camera2.params.DynamicRangeProfiles unwrap() {
            r1 = this;
            r0 = 0
            return r0
    }
}
