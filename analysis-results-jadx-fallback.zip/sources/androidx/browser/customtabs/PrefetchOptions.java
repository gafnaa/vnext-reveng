package androidx.browser.customtabs;

/* JADX INFO: loaded from: classes.dex */
public final class PrefetchOptions {
    private static final java.lang.String KEY_REQUIRES_ANONYMOUS_IP_WHEN_CROSS_ORIGIN = "androidx.browser.customtabs.PrefetchOptions.KEY_REQUIRES_ANONYMOUS_IP_WHEN_CROSS_ORIGIN";
    private static final java.lang.String KEY_SOURCE_ORIGIN = "androidx.browser.customtabs.PrefetchOptions.KEY_SOURCE_ORIGIN";
    public final boolean requiresAnonymousIpWhenCrossOrigin;
    public final android.net.Uri sourceOrigin;

    public static final class Builder {
        private boolean mRequiresAnonymousIpWhenCrossOrigin;
        private android.net.Uri mSourceOrigin;

        public Builder() {
                r0 = this;
                r0.<init>()
                return
        }

        public androidx.browser.customtabs.PrefetchOptions build() {
                r3 = this;
                androidx.browser.customtabs.PrefetchOptions r0 = new androidx.browser.customtabs.PrefetchOptions
                boolean r1 = r3.mRequiresAnonymousIpWhenCrossOrigin
                android.net.Uri r2 = r3.mSourceOrigin
                r0.<init>(r1, r2)
                return r0
        }

        public androidx.browser.customtabs.PrefetchOptions.Builder setRequiresAnonymousIpWhenCrossOrigin(boolean r1) {
                r0 = this;
                r0.mRequiresAnonymousIpWhenCrossOrigin = r1
                return r0
        }

        public androidx.browser.customtabs.PrefetchOptions.Builder setSourceOrigin(android.net.Uri r1) {
                r0 = this;
                r0.mSourceOrigin = r1
                return r0
        }
    }

    PrefetchOptions(boolean r1, android.net.Uri r2) {
            r0 = this;
            r0.<init>()
            r0.requiresAnonymousIpWhenCrossOrigin = r1
            r0.sourceOrigin = r2
            return
    }

    static androidx.browser.customtabs.PrefetchOptions fromBundle(android.os.Bundle r3) {
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 33
            java.lang.String r2 = "androidx.browser.customtabs.PrefetchOptions.KEY_SOURCE_ORIGIN"
            if (r0 < r1) goto L11
            java.lang.Class<android.net.Uri> r0 = android.net.Uri.class
            java.lang.Object r0 = androidx.browser.customtabs.Api33Impl.getParcelable(r3, r2, r0)
            android.net.Uri r0 = (android.net.Uri) r0
            goto L17
        L11:
            android.os.Parcelable r0 = r3.getParcelable(r2)
            android.net.Uri r0 = (android.net.Uri) r0
        L17:
            androidx.browser.customtabs.PrefetchOptions r1 = new androidx.browser.customtabs.PrefetchOptions
            java.lang.String r2 = "androidx.browser.customtabs.PrefetchOptions.KEY_REQUIRES_ANONYMOUS_IP_WHEN_CROSS_ORIGIN"
            boolean r3 = r3.getBoolean(r2)
            r1.<init>(r3, r0)
            return r1
    }

    android.os.Bundle toBundle() {
            r3 = this;
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            java.lang.String r1 = "androidx.browser.customtabs.PrefetchOptions.KEY_REQUIRES_ANONYMOUS_IP_WHEN_CROSS_ORIGIN"
            boolean r2 = r3.requiresAnonymousIpWhenCrossOrigin
            r0.putBoolean(r1, r2)
            android.net.Uri r1 = r3.sourceOrigin
            if (r1 == 0) goto L15
            java.lang.String r2 = "androidx.browser.customtabs.PrefetchOptions.KEY_SOURCE_ORIGIN"
            r0.putParcelable(r2, r1)
        L15:
            return r0
    }
}
