package androidx.browser.customtabs;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class CustomTabsClient$2$$ExternalSyntheticLambda3 implements java.util.concurrent.Executor {
    public final /* synthetic */ android.os.Handler f$0;

    public /* synthetic */ CustomTabsClient$2$$ExternalSyntheticLambda3(android.os.Handler r1) {
            r0 = this;
            r0.<init>()
            r0.f$0 = r1
            return
    }

    @Override // java.util.concurrent.Executor
    public final void execute(java.lang.Runnable r2) {
            r1 = this;
            android.os.Handler r0 = r1.f$0
            r0.post(r2)
            return
    }
}
