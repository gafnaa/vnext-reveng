package androidx.browser.customtabs;

/* JADX INFO: loaded from: classes.dex */
public final class CustomContentAction {
    static final java.lang.String KEY_ID = "androidx.browser.customtabs.customcontentaction.ID";
    static final java.lang.String KEY_LABEL = "androidx.browser.customtabs.customcontentaction.LABEL";
    static final java.lang.String KEY_PENDING_INTENT = "androidx.browser.customtabs.customcontentaction.PENDING_INTENT";
    static final java.lang.String KEY_TARGET_TYPE = "androidx.browser.customtabs.customcontentaction.TARGET_TYPE";
    private final int mId;
    private final java.lang.String mLabel;
    private final android.app.PendingIntent mPendingIntent;
    private final int mTargetType;

    /* JADX INFO: renamed from: androidx.browser.customtabs.CustomContentAction$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
    }

    public static final class Builder {
        private final int mId;
        private final java.lang.String mLabel;
        private final android.app.PendingIntent mPendingIntent;
        private final int mTargetType;

        public Builder(int r2, java.lang.String r3, android.app.PendingIntent r4, int r5) {
                r1 = this;
                r1.<init>()
                boolean r0 = r3.isEmpty()
                if (r0 != 0) goto L37
                if (r2 < 0) goto L2f
                r0 = 1
                if (r5 == r0) goto L26
                r0 = 2
                if (r5 != r0) goto L12
                goto L26
            L12:
                java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r3 = new java.lang.StringBuilder
                java.lang.String r4 = "Invalid target type: "
                r3.<init>(r4)
                r3.append(r5)
                java.lang.String r3 = r3.toString()
                r2.<init>(r3)
                throw r2
            L26:
                r1.mId = r2
                r1.mLabel = r3
                r1.mPendingIntent = r4
                r1.mTargetType = r5
                return
            L2f:
                java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
                java.lang.String r3 = "Id cannot be set to negative numbers."
                r2.<init>(r3)
                throw r2
            L37:
                java.lang.IllegalArgumentException r2 = new java.lang.IllegalArgumentException
                java.lang.String r3 = "Label cannot be empty."
                r2.<init>(r3)
                throw r2
        }

        public androidx.browser.customtabs.CustomContentAction build() {
                r6 = this;
                androidx.browser.customtabs.CustomContentAction r0 = new androidx.browser.customtabs.CustomContentAction
                int r1 = r6.mId
                java.lang.String r2 = r6.mLabel
                android.app.PendingIntent r3 = r6.mPendingIntent
                int r4 = r6.mTargetType
                r5 = 0
                r0.<init>(r1, r2, r3, r4, r5)
                return r0
        }
    }

    private CustomContentAction(int r1, java.lang.String r2, android.app.PendingIntent r3, int r4) {
            r0 = this;
            r0.<init>()
            r0.mId = r1
            r0.mLabel = r2
            r0.mPendingIntent = r3
            r0.mTargetType = r4
            return
    }

    /* synthetic */ CustomContentAction(int r1, java.lang.String r2, android.app.PendingIntent r3, int r4, androidx.browser.customtabs.CustomContentAction.AnonymousClass1 r5) {
            r0 = this;
            r0.<init>(r1, r2, r3, r4)
            return
    }

    public static androidx.browser.customtabs.CustomContentAction fromBundle(android.os.Bundle r5) {
            java.lang.String r0 = "androidx.browser.customtabs.customcontentaction.ID"
            boolean r1 = r5.containsKey(r0)
            if (r1 == 0) goto L69
            int r0 = r5.getInt(r0)
            java.lang.String r1 = "androidx.browser.customtabs.customcontentaction.LABEL"
            java.lang.String r1 = r5.getString(r1)
            boolean r2 = android.text.TextUtils.isEmpty(r1)
            if (r2 != 0) goto L61
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 33
            java.lang.String r4 = "androidx.browser.customtabs.customcontentaction.PENDING_INTENT"
            if (r2 < r3) goto L29
            java.lang.Class<android.app.PendingIntent> r2 = android.app.PendingIntent.class
            java.lang.Object r2 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r5, r4, r2)
            android.app.PendingIntent r2 = (android.app.PendingIntent) r2
            goto L2f
        L29:
            android.os.Parcelable r2 = r5.getParcelable(r4)
            android.app.PendingIntent r2 = (android.app.PendingIntent) r2
        L2f:
            if (r2 == 0) goto L59
            java.lang.String r3 = "androidx.browser.customtabs.customcontentaction.TARGET_TYPE"
            r4 = 0
            int r5 = r5.getInt(r3, r4)
            r3 = 1
            if (r5 == r3) goto L53
            r3 = 2
            if (r5 != r3) goto L3f
            goto L53
        L3f:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Invalid target type: "
            r1.<init>(r2)
            r1.append(r5)
            java.lang.String r5 = r1.toString()
            r0.<init>(r5)
            throw r0
        L53:
            androidx.browser.customtabs.CustomContentAction r3 = new androidx.browser.customtabs.CustomContentAction
            r3.<init>(r0, r1, r2, r5)
            return r3
        L59:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Bundle is missing required key: androidx.browser.customtabs.customcontentaction.PENDING_INTENT"
            r5.<init>(r0)
            throw r5
        L61:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Bundle is missing required key: androidx.browser.customtabs.customcontentaction.LABEL"
            r5.<init>(r0)
            throw r5
        L69:
            java.lang.IllegalArgumentException r5 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Bundle is missing required key: androidx.browser.customtabs.customcontentaction.ID"
            r5.<init>(r0)
            throw r5
    }

    public int getId() {
            r1 = this;
            int r0 = r1.mId
            return r0
    }

    public java.lang.String getLabel() {
            r1 = this;
            java.lang.String r0 = r1.mLabel
            return r0
    }

    public android.app.PendingIntent getPendingIntent() {
            r1 = this;
            android.app.PendingIntent r0 = r1.mPendingIntent
            return r0
    }

    public int getTargetType() {
            r1 = this;
            int r0 = r1.mTargetType
            return r0
    }

    android.os.Bundle toBundle() {
            r3 = this;
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            java.lang.String r1 = "androidx.browser.customtabs.customcontentaction.ID"
            int r2 = r3.mId
            r0.putInt(r1, r2)
            java.lang.String r1 = "androidx.browser.customtabs.customcontentaction.LABEL"
            java.lang.String r2 = r3.mLabel
            r0.putString(r1, r2)
            java.lang.String r1 = "androidx.browser.customtabs.customcontentaction.PENDING_INTENT"
            android.app.PendingIntent r2 = r3.mPendingIntent
            r0.putParcelable(r1, r2)
            java.lang.String r1 = "androidx.browser.customtabs.customcontentaction.TARGET_TYPE"
            int r2 = r3.mTargetType
            r0.putInt(r1, r2)
            return r0
    }
}
