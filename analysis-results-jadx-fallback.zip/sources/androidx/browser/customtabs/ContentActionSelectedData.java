package androidx.browser.customtabs;

/* JADX INFO: loaded from: classes.dex */
public final class ContentActionSelectedData {
    private final android.content.Intent mIntent;

    private ContentActionSelectedData(android.content.Intent r1) {
            r0 = this;
            r0.<init>()
            r0.mIntent = r1
            return
    }

    public static androidx.browser.customtabs.ContentActionSelectedData fromIntent(android.content.Intent r1) {
            if (r1 != 0) goto L4
            r1 = 0
            return r1
        L4:
            androidx.browser.customtabs.ContentActionSelectedData r0 = new androidx.browser.customtabs.ContentActionSelectedData
            r0.<init>(r1)
            return r0
    }

    public int getClickedContentTargetType() {
            r3 = this;
            android.content.Intent r0 = r3.mIntent
            java.lang.String r1 = "androidx.browser.customtabs.extra.CLICKED_CONTENT_TARGET_TYPE"
            r2 = 0
            int r0 = r0.getIntExtra(r1, r2)
            return r0
    }

    public java.lang.String getImageAltText() {
            r2 = this;
            android.content.Intent r0 = r2.mIntent
            java.lang.String r1 = "androidx.browser.customtabs.extra.CONTEXT_IMAGE_ALT_TEXT"
            java.lang.String r0 = r0.getStringExtra(r1)
            return r0
    }

    public android.net.Uri getImageDataUri() {
            r3 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 33
            if (r0 < r1) goto L13
            android.content.Intent r0 = r3.mIntent
            java.lang.String r1 = "androidx.browser.customtabs.extra.CONTEXT_IMAGE_DATA_URI"
            java.lang.Class<android.net.Uri> r2 = android.net.Uri.class
            java.lang.Object r0 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r0, r1, r2)
            android.net.Uri r0 = (android.net.Uri) r0
            return r0
        L13:
            r0 = 0
            return r0
    }

    public java.lang.String getImageUrl() {
            r2 = this;
            android.content.Intent r0 = r2.mIntent
            java.lang.String r1 = "androidx.browser.customtabs.extra.CONTEXT_IMAGE_URL"
            java.lang.String r0 = r0.getStringExtra(r1)
            return r0
    }

    public android.content.Intent getIntent() {
            r1 = this;
            android.content.Intent r0 = r1.mIntent
            return r0
    }

    public java.lang.String getLinkText() {
            r2 = this;
            android.content.Intent r0 = r2.mIntent
            java.lang.String r1 = "androidx.browser.customtabs.extra.CONTEXT_LINK_TEXT"
            java.lang.String r0 = r0.getStringExtra(r1)
            return r0
    }

    public java.lang.String getLinkUrl() {
            r2 = this;
            android.content.Intent r0 = r2.mIntent
            java.lang.String r1 = "androidx.browser.customtabs.extra.CONTEXT_LINK_URL"
            java.lang.String r0 = r0.getStringExtra(r1)
            return r0
    }

    public android.net.Uri getPageUrl() {
            r1 = this;
            android.content.Intent r0 = r1.mIntent
            android.net.Uri r0 = r0.getData()
            return r0
    }

    public int getTriggeredActionId() {
            r3 = this;
            android.content.Intent r0 = r3.mIntent
            java.lang.String r1 = "androidx.browser.customtabs.extra.TRIGGERED_CUSTOM_CONTENT_ACTION_ID"
            r2 = -1
            int r0 = r0.getIntExtra(r1, r2)
            return r0
    }
}
