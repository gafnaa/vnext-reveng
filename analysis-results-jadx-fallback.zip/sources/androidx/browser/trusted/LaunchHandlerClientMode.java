package androidx.browser.trusted;

/* JADX INFO: loaded from: classes.dex */
public final class LaunchHandlerClientMode {
    public static final int AUTO = 0;
    public static final int FOCUS_EXISTING = 2;
    public static final int NAVIGATE_EXISTING = 1;
    public static final int NAVIGATE_NEW = 3;

    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
    public @interface ClientMode {
    }

    private LaunchHandlerClientMode() {
            r0 = this;
            r0.<init>()
            return
    }
}
