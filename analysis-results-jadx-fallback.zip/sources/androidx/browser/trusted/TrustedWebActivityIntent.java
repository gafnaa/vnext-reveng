package androidx.browser.trusted;

/* JADX INFO: loaded from: classes.dex */
public final class TrustedWebActivityIntent {
    private final java.util.List<android.net.Uri> mFileHandlingUris;
    private final android.content.Intent mIntent;
    private final java.util.List<android.net.Uri> mSharedFileUris;

    TrustedWebActivityIntent(android.content.Intent r1, java.util.List<android.net.Uri> r2, java.util.List<android.net.Uri> r3) {
            r0 = this;
            r0.<init>()
            r0.mIntent = r1
            r0.mSharedFileUris = r2
            r0.mFileHandlingUris = r3
            return
    }

    private void grantUriPermissionToProvider(android.content.Context r6) {
            r5 = this;
            java.util.List<android.net.Uri> r0 = r5.mSharedFileUris
            java.util.Iterator r0 = r0.iterator()
        L6:
            boolean r1 = r0.hasNext()
            r2 = 1
            if (r1 == 0) goto L1d
            java.lang.Object r1 = r0.next()
            android.net.Uri r1 = (android.net.Uri) r1
            android.content.Intent r3 = r5.mIntent
            java.lang.String r3 = r3.getPackage()
            r6.grantUriPermission(r3, r1, r2)
            goto L6
        L1d:
            java.util.List<android.net.Uri> r0 = r5.mFileHandlingUris
            java.util.Iterator r0 = r0.iterator()
        L23:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L51
            java.lang.Object r1 = r0.next()
            android.net.Uri r1 = (android.net.Uri) r1
            int r3 = r6.checkCallingOrSelfUriPermission(r1, r2)
            if (r3 != 0) goto L23
            r3 = 2
            int r3 = r6.checkCallingOrSelfUriPermission(r1, r3)
            if (r3 != 0) goto L47
            android.content.Intent r3 = r5.mIntent
            java.lang.String r3 = r3.getPackage()
            r4 = 3
            r6.grantUriPermission(r3, r1, r4)
            goto L23
        L47:
            android.content.Intent r3 = r5.mIntent
            java.lang.String r3 = r3.getPackage()
            r6.grantUriPermission(r3, r1, r2)
            goto L23
        L51:
            return
    }

    public java.util.List<androidx.browser.trusted.TrustedWebActivityDisplayMode> getDisplayOverrideList() {
            r3 = this;
            android.content.Intent r0 = r3.getIntent()
            java.lang.String r1 = "androidx.browser.trusted.extra.DISPLAY_OVERRIDE"
            java.lang.Class<android.os.Bundle> r2 = android.os.Bundle.class
            java.util.ArrayList r0 = androidx.core.content.IntentCompat.getParcelableArrayListExtra(r0, r1, r2)
            if (r0 != 0) goto L14
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            return r0
        L14:
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            java.util.Iterator r0 = r0.iterator()
        L1d:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L31
            java.lang.Object r2 = r0.next()
            android.os.Bundle r2 = (android.os.Bundle) r2
            androidx.browser.trusted.TrustedWebActivityDisplayMode r2 = androidx.browser.trusted.TrustedWebActivityDisplayMode.fromBundle(r2)
            r1.add(r2)
            goto L1d
        L31:
            return r1
    }

    public androidx.browser.trusted.FileHandlingData getFileHandlingData() {
            r2 = this;
            android.content.Intent r0 = r2.getIntent()
            java.lang.String r1 = "androidx.browser.trusted.extra.FILE_HANDLING_DATA"
            android.os.Bundle r0 = r0.getBundleExtra(r1)
            androidx.browser.trusted.FileHandlingData r0 = androidx.browser.trusted.FileHandlingData.fromBundle(r0)
            return r0
    }

    public android.content.Intent getIntent() {
            r1 = this;
            android.content.Intent r0 = r1.mIntent
            return r0
    }

    public int getLaunchHandlerClientMode() {
            r3 = this;
            android.content.Intent r0 = r3.getIntent()
            java.lang.String r1 = "androidx.browser.trusted.extra.LAUNCH_HANDLER_CLIENT_MODE"
            r2 = 0
            int r0 = r0.getIntExtra(r1, r2)
            return r0
    }

    public android.net.Uri getOriginalLaunchUrl() {
            r3 = this;
            android.content.Intent r0 = r3.getIntent()
            java.lang.String r1 = "androidx.browser.trusted.extra.ORIGINAL_LAUNCH_URL"
            java.lang.Class<android.net.Uri> r2 = android.net.Uri.class
            java.lang.Object r0 = androidx.core.content.IntentCompat.getParcelableExtra(r0, r1, r2)
            android.net.Uri r0 = (android.net.Uri) r0
            return r0
    }

    public void launchTrustedWebActivity(android.content.Context r3) {
            r2 = this;
            r2.grantUriPermissionToProvider(r3)
            android.content.Intent r0 = r2.mIntent
            r1 = 0
            androidx.core.content.ContextCompat.startActivity(r3, r0, r1)
            return
    }
}
