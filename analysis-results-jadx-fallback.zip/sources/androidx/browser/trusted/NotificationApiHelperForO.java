package androidx.browser.trusted;

/* JADX INFO: loaded from: classes.dex */
class NotificationApiHelperForO {
    private NotificationApiHelperForO() {
            r0 = this;
            r0.<init>()
            return
    }

    static android.app.Notification copyNotificationOntoChannel(android.content.Context r1, android.app.NotificationManager r2, android.app.Notification r3, java.lang.String r4, java.lang.String r5) {
            r0 = 3
            android.app.NotificationChannel r5 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r4, r5, r0)
            androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r2, r5)
            android.app.NotificationChannel r2 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r2, r4)
            int r2 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r2)
            if (r2 != 0) goto L14
            r1 = 0
            return r1
        L14:
            android.app.Notification$Builder r1 = android.app.Notification.Builder.recoverBuilder(r1, r3)
            androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r1, r4)
            android.app.Notification r1 = r1.build()
            return r1
    }

    static boolean isChannelEnabled(android.app.NotificationManager r0, java.lang.String r1) {
            android.app.NotificationChannel r0 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r0, r1)
            if (r0 == 0) goto Lf
            int r0 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r0)
            if (r0 == 0) goto Ld
            goto Lf
        Ld:
            r0 = 0
            return r0
        Lf:
            r0 = 1
            return r0
    }
}
