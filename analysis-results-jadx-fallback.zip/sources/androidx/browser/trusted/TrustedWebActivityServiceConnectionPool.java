package androidx.browser.trusted;

/* JADX INFO: loaded from: classes.dex */
public final class TrustedWebActivityServiceConnectionPool {
    private static final java.lang.String TAG = "TWAConnectionPool";
    private final java.util.Map<android.net.Uri, androidx.browser.trusted.ConnectionHolder> mConnections;
    private final android.content.Context mContext;

    static class BindToServiceAsyncTask extends android.os.AsyncTask<java.lang.Void, java.lang.Void, java.lang.Exception> {
        private final android.content.Context mAppContext;
        private final androidx.browser.trusted.ConnectionHolder mConnection;
        private final android.content.Intent mIntent;

        BindToServiceAsyncTask(android.content.Context r1, android.content.Intent r2, androidx.browser.trusted.ConnectionHolder r3) {
                r0 = this;
                r0.<init>()
                android.content.Context r1 = r1.getApplicationContext()
                r0.mAppContext = r1
                r0.mIntent = r2
                r0.mConnection = r3
                return
        }

        /* JADX INFO: renamed from: doInBackground, reason: avoid collision after fix types in other method */
        protected java.lang.Exception doInBackground2(java.lang.Void... r4) {
                r3 = this;
                android.content.Context r4 = r3.mAppContext     // Catch: java.lang.SecurityException -> L1f
                android.content.Intent r0 = r3.mIntent     // Catch: java.lang.SecurityException -> L1f
                androidx.browser.trusted.ConnectionHolder r1 = r3.mConnection     // Catch: java.lang.SecurityException -> L1f
                r2 = 4097(0x1001, float:5.741E-42)
                boolean r4 = r4.bindService(r0, r1, r2)     // Catch: java.lang.SecurityException -> L1f
                if (r4 == 0) goto L10
                r4 = 0
                return r4
            L10:
                android.content.Context r4 = r3.mAppContext     // Catch: java.lang.SecurityException -> L1f
                androidx.browser.trusted.ConnectionHolder r0 = r3.mConnection     // Catch: java.lang.SecurityException -> L1f
                r4.unbindService(r0)     // Catch: java.lang.SecurityException -> L1f
                java.lang.IllegalStateException r4 = new java.lang.IllegalStateException     // Catch: java.lang.SecurityException -> L1f
                java.lang.String r0 = "Could not bind to the service"
                r4.<init>(r0)     // Catch: java.lang.SecurityException -> L1f
                return r4
            L1f:
                r4 = move-exception
                java.lang.String r0 = "TWAConnectionPool"
                java.lang.String r1 = "SecurityException while binding."
                android.util.Log.w(r0, r1, r4)
                return r4
        }

        @Override // android.os.AsyncTask
        protected /* bridge */ /* synthetic */ java.lang.Exception doInBackground(java.lang.Void[] r1) {
                r0 = this;
                java.lang.Void[] r1 = (java.lang.Void[]) r1
                java.lang.Exception r1 = r0.doInBackground2(r1)
                return r1
        }

        /* JADX INFO: renamed from: onPostExecute, reason: avoid collision after fix types in other method */
        protected void onPostExecute2(java.lang.Exception r2) {
                r1 = this;
                if (r2 == 0) goto L7
                androidx.browser.trusted.ConnectionHolder r0 = r1.mConnection
                r0.cancel(r2)
            L7:
                return
        }

        @Override // android.os.AsyncTask
        protected /* bridge */ /* synthetic */ void onPostExecute(java.lang.Exception r1) {
                r0 = this;
                java.lang.Exception r1 = (java.lang.Exception) r1
                r0.onPostExecute2(r1)
                return
        }
    }

    private TrustedWebActivityServiceConnectionPool(android.content.Context r2) {
            r1 = this;
            r1.<init>()
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            r1.mConnections = r0
            android.content.Context r2 = r2.getApplicationContext()
            r1.mContext = r2
            return
    }

    public static androidx.browser.trusted.TrustedWebActivityServiceConnectionPool create(android.content.Context r1) {
            androidx.browser.trusted.TrustedWebActivityServiceConnectionPool r0 = new androidx.browser.trusted.TrustedWebActivityServiceConnectionPool
            r0.<init>(r1)
            return r0
    }

    private android.content.Intent createServiceIntent(android.content.Context r9, android.net.Uri r10, java.util.Set<androidx.browser.trusted.Token> r11, boolean r12) {
            r8 = this;
            r0 = 0
            if (r11 == 0) goto Lcc
            int r1 = r11.size()
            if (r1 != 0) goto Lb
            goto Lcc
        Lb:
            android.content.Intent r1 = new android.content.Intent
            r1.<init>()
            r1.setData(r10)
            java.lang.String r2 = "android.intent.action.VIEW"
            r1.setAction(r2)
            android.content.pm.PackageManager r2 = r9.getPackageManager()
            r3 = 131072(0x20000, float:1.83671E-40)
            java.util.List r1 = r2.queryIntentActivities(r1, r3)
            java.util.Iterator r1 = r1.iterator()
            r2 = r0
        L27:
            boolean r4 = r1.hasNext()
            if (r4 == 0) goto L53
            java.lang.Object r4 = r1.next()
            android.content.pm.ResolveInfo r4 = (android.content.pm.ResolveInfo) r4
            android.content.pm.ActivityInfo r4 = r4.activityInfo
            java.lang.String r4 = r4.packageName
            java.util.Iterator r5 = r11.iterator()
        L3b:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L27
            java.lang.Object r6 = r5.next()
            androidx.browser.trusted.Token r6 = (androidx.browser.trusted.Token) r6
            android.content.pm.PackageManager r7 = r9.getPackageManager()
            boolean r6 = r6.matches(r4, r7)
            if (r6 == 0) goto L3b
            r2 = r4
            goto L27
        L53:
            java.lang.String r11 = "TWAConnectionPool"
            if (r2 != 0) goto L70
            if (r12 == 0) goto L6f
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r12 = "No TWA candidates for "
            r9.<init>(r12)
            r9.append(r10)
            java.lang.String r10 = " have been registered."
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            android.util.Log.w(r11, r9)
        L6f:
            return r0
        L70:
            android.content.Intent r1 = new android.content.Intent
            r1.<init>()
            r1.setPackage(r2)
            java.lang.String r4 = "android.support.customtabs.trusted.TRUSTED_WEB_ACTIVITY_SERVICE"
            r1.setAction(r4)
            android.content.pm.PackageManager r9 = r9.getPackageManager()
            android.content.pm.ResolveInfo r9 = r9.resolveService(r1, r3)
            if (r9 != 0) goto L9b
            if (r12 == 0) goto L9a
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r10 = "Could not find TWAService for "
            r9.<init>(r10)
            r9.append(r2)
            java.lang.String r9 = r9.toString()
            android.util.Log.w(r11, r9)
        L9a:
            return r0
        L9b:
            if (r12 == 0) goto Lba
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            java.lang.String r0 = "Found "
            r12.<init>(r0)
            android.content.pm.ServiceInfo r0 = r9.serviceInfo
            java.lang.String r0 = r0.name
            r12.append(r0)
            java.lang.String r0 = " to handle request for "
            r12.append(r0)
            r12.append(r10)
            java.lang.String r10 = r12.toString()
            android.util.Log.i(r11, r10)
        Lba:
            android.content.Intent r10 = new android.content.Intent
            r10.<init>()
            android.content.ComponentName r11 = new android.content.ComponentName
            android.content.pm.ServiceInfo r9 = r9.serviceInfo
            java.lang.String r9 = r9.name
            r11.<init>(r2, r9)
            r10.setComponent(r11)
            return r10
        Lcc:
            return r0
    }

    public com.google.common.util.concurrent.ListenableFuture<androidx.browser.trusted.TrustedWebActivityServiceConnection> connect(android.net.Uri r3, java.util.Set<androidx.browser.trusted.Token> r4, java.util.concurrent.Executor r5) {
            r2 = this;
            java.util.Map<android.net.Uri, androidx.browser.trusted.ConnectionHolder> r0 = r2.mConnections
            java.lang.Object r0 = r0.get(r3)
            androidx.browser.trusted.ConnectionHolder r0 = (androidx.browser.trusted.ConnectionHolder) r0
            if (r0 == 0) goto Lf
            com.google.common.util.concurrent.ListenableFuture r3 = r0.getServiceWrapper()
            return r3
        Lf:
            android.content.Context r0 = r2.mContext
            r1 = 1
            android.content.Intent r4 = r2.createServiceIntent(r0, r3, r4, r1)
            if (r4 != 0) goto L24
            java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException
            java.lang.String r4 = "No service exists for scope"
            r3.<init>(r4)
            com.google.common.util.concurrent.ListenableFuture r3 = androidx.browser.trusted.FutureUtils.immediateFailedFuture(r3)
            return r3
        L24:
            androidx.browser.trusted.ConnectionHolder r0 = new androidx.browser.trusted.ConnectionHolder
            androidx.browser.trusted.TrustedWebActivityServiceConnectionPool$$ExternalSyntheticLambda0 r1 = new androidx.browser.trusted.TrustedWebActivityServiceConnectionPool$$ExternalSyntheticLambda0
            r1.<init>(r2, r3)
            r0.<init>(r1)
            java.util.Map<android.net.Uri, androidx.browser.trusted.ConnectionHolder> r1 = r2.mConnections
            r1.put(r3, r0)
            androidx.browser.trusted.TrustedWebActivityServiceConnectionPool$BindToServiceAsyncTask r3 = new androidx.browser.trusted.TrustedWebActivityServiceConnectionPool$BindToServiceAsyncTask
            android.content.Context r1 = r2.mContext
            r3.<init>(r1, r4, r0)
            r4 = 0
            java.lang.Void[] r4 = new java.lang.Void[r4]
            r3.executeOnExecutor(r5, r4)
            com.google.common.util.concurrent.ListenableFuture r3 = r0.getServiceWrapper()
            return r3
    }

    /* JADX INFO: renamed from: lambda$connect$0$androidx-browser-trusted-TrustedWebActivityServiceConnectionPool, reason: not valid java name */
    /* synthetic */ void m57x9cdfbfef(android.net.Uri r2) {
            r1 = this;
            java.util.Map<android.net.Uri, androidx.browser.trusted.ConnectionHolder> r0 = r1.mConnections
            r0.remove(r2)
            return
    }

    public boolean serviceExistsForScope(android.net.Uri r4, java.util.Set<androidx.browser.trusted.Token> r5) {
            r3 = this;
            java.util.Map<android.net.Uri, androidx.browser.trusted.ConnectionHolder> r0 = r3.mConnections
            java.lang.Object r0 = r0.get(r4)
            r1 = 1
            if (r0 == 0) goto La
            return r1
        La:
            android.content.Context r0 = r3.mContext
            r2 = 0
            android.content.Intent r4 = r3.createServiceIntent(r0, r4, r5, r2)
            if (r4 == 0) goto L14
            return r1
        L14:
            return r2
    }

    void unbindAllConnections() {
            r3 = this;
            java.util.Map<android.net.Uri, androidx.browser.trusted.ConnectionHolder> r0 = r3.mConnections
            java.util.Collection r0 = r0.values()
            java.util.Iterator r0 = r0.iterator()
        La:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L1c
            java.lang.Object r1 = r0.next()
            androidx.browser.trusted.ConnectionHolder r1 = (androidx.browser.trusted.ConnectionHolder) r1
            android.content.Context r2 = r3.mContext
            r2.unbindService(r1)
            goto La
        L1c:
            java.util.Map<android.net.Uri, androidx.browser.trusted.ConnectionHolder> r0 = r3.mConnections
            r0.clear()
            return
    }
}
