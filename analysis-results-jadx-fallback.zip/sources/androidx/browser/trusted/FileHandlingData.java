package androidx.browser.trusted;

/* JADX INFO: loaded from: classes.dex */
public final class FileHandlingData {
    public static final java.lang.String KEY_URIS = "androidx.browser.trusted.KEY_URIS";
    public final java.util.List<android.net.Uri> uris;

    public FileHandlingData(java.util.List<android.net.Uri> r1) {
            r0 = this;
            r0.<init>()
            java.lang.Object r1 = java.util.Objects.requireNonNull(r1)
            java.util.List r1 = (java.util.List) r1
            r0.uris = r1
            return
    }

    public static androidx.browser.trusted.FileHandlingData fromBundle(android.os.Bundle r3) {
            androidx.browser.trusted.FileHandlingData r0 = new androidx.browser.trusted.FileHandlingData
            java.lang.String r1 = "androidx.browser.trusted.KEY_URIS"
            java.lang.Class<android.net.Uri> r2 = android.net.Uri.class
            java.util.ArrayList r3 = androidx.core.os.BundleCompat.getParcelableArrayList(r3, r1, r2)
            r0.<init>(r3)
            return r0
    }

    public android.os.Bundle toBundle() {
            r3 = this;
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            java.util.List<android.net.Uri> r1 = r3.uris
            if (r1 == 0) goto L15
            java.util.ArrayList r1 = new java.util.ArrayList
            java.util.List<android.net.Uri> r2 = r3.uris
            r1.<init>(r2)
            java.lang.String r2 = "androidx.browser.trusted.KEY_URIS"
            r0.putParcelableArrayList(r2, r1)
        L15:
            return r0
    }
}
