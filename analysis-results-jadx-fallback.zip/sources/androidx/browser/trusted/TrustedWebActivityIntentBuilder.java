package androidx.browser.trusted;

/* JADX INFO: loaded from: classes.dex */
public class TrustedWebActivityIntentBuilder {
    public static final java.lang.String EXTRA_ADDITIONAL_TRUSTED_ORIGINS = "android.support.customtabs.extra.ADDITIONAL_TRUSTED_ORIGINS";
    public static final java.lang.String EXTRA_DISPLAY_MODE = "androidx.browser.trusted.extra.DISPLAY_MODE";
    public static final java.lang.String EXTRA_DISPLAY_OVERRIDE = "androidx.browser.trusted.extra.DISPLAY_OVERRIDE";
    public static final java.lang.String EXTRA_FILE_HANDLING_DATA = "androidx.browser.trusted.extra.FILE_HANDLING_DATA";
    public static final java.lang.String EXTRA_LAUNCH_HANDLER_CLIENT_MODE = "androidx.browser.trusted.extra.LAUNCH_HANDLER_CLIENT_MODE";
    public static final java.lang.String EXTRA_ORIGINAL_LAUNCH_URL = "androidx.browser.trusted.extra.ORIGINAL_LAUNCH_URL";
    public static final java.lang.String EXTRA_SCREEN_ORIENTATION = "androidx.browser.trusted.extra.SCREEN_ORIENTATION";
    public static final java.lang.String EXTRA_SHARE_DATA = "androidx.browser.trusted.extra.SHARE_DATA";
    public static final java.lang.String EXTRA_SHARE_TARGET = "androidx.browser.trusted.extra.SHARE_TARGET";
    public static final java.lang.String EXTRA_SPLASH_SCREEN_PARAMS = "androidx.browser.trusted.EXTRA_SPLASH_SCREEN_PARAMS";
    private java.util.List<java.lang.String> mAdditionalTrustedOrigins;
    private androidx.browser.trusted.TrustedWebActivityDisplayMode mDisplayMode;
    private java.util.List<androidx.browser.trusted.TrustedWebActivityDisplayMode> mDisplayOverrideList;
    private androidx.browser.trusted.FileHandlingData mFileHandlingData;
    private final androidx.browser.customtabs.CustomTabsIntent.Builder mIntentBuilder;
    private int mLaunchHandlerClientMode;
    private android.net.Uri mOriginalLaunchUrl;
    private int mScreenOrientation;
    private androidx.browser.trusted.sharing.ShareData mShareData;
    private androidx.browser.trusted.sharing.ShareTarget mShareTarget;
    private android.os.Bundle mSplashScreenParams;
    private final android.net.Uri mUri;

    public TrustedWebActivityIntentBuilder(android.net.Uri r3) {
            r2 = this;
            r2.<init>()
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = new androidx.browser.customtabs.CustomTabsIntent$Builder
            r0.<init>()
            r2.mIntentBuilder = r0
            r0 = 0
            r2.mLaunchHandlerClientMode = r0
            androidx.browser.trusted.TrustedWebActivityDisplayMode$DefaultMode r1 = new androidx.browser.trusted.TrustedWebActivityDisplayMode$DefaultMode
            r1.<init>()
            r2.mDisplayMode = r1
            r2.mScreenOrientation = r0
            r2.mUri = r3
            return
    }

    public androidx.browser.trusted.TrustedWebActivityIntent build(androidx.browser.customtabs.CustomTabsSession r6) {
            r5 = this;
            if (r6 == 0) goto Lc4
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = r5.mIntentBuilder
            r0.setSession(r6)
            androidx.browser.customtabs.CustomTabsIntent$Builder r6 = r5.mIntentBuilder
            androidx.browser.customtabs.CustomTabsIntent r6 = r6.build()
            android.content.Intent r6 = r6.intent
            android.net.Uri r0 = r5.mUri
            r6.setData(r0)
            java.lang.String r0 = "android.support.customtabs.extra.LAUNCH_AS_TRUSTED_WEB_ACTIVITY"
            r1 = 1
            r6.putExtra(r0, r1)
            java.util.List<java.lang.String> r0 = r5.mAdditionalTrustedOrigins
            if (r0 == 0) goto L2a
            java.util.ArrayList r0 = new java.util.ArrayList
            java.util.List<java.lang.String> r1 = r5.mAdditionalTrustedOrigins
            r0.<init>(r1)
            java.lang.String r1 = "android.support.customtabs.extra.ADDITIONAL_TRUSTED_ORIGINS"
            r6.putExtra(r1, r0)
        L2a:
            android.os.Bundle r0 = r5.mSplashScreenParams
            if (r0 == 0) goto L33
            java.lang.String r1 = "androidx.browser.trusted.EXTRA_SPLASH_SCREEN_PARAMS"
            r6.putExtra(r1, r0)
        L33:
            java.util.List r0 = java.util.Collections.EMPTY_LIST
            androidx.browser.trusted.sharing.ShareTarget r1 = r5.mShareTarget
            if (r1 == 0) goto L5b
            androidx.browser.trusted.sharing.ShareData r2 = r5.mShareData
            if (r2 == 0) goto L5b
            java.lang.String r2 = "androidx.browser.trusted.extra.SHARE_TARGET"
            android.os.Bundle r1 = r1.toBundle()
            r6.putExtra(r2, r1)
            androidx.browser.trusted.sharing.ShareData r1 = r5.mShareData
            android.os.Bundle r1 = r1.toBundle()
            java.lang.String r2 = "androidx.browser.trusted.extra.SHARE_DATA"
            r6.putExtra(r2, r1)
            androidx.browser.trusted.sharing.ShareData r1 = r5.mShareData
            java.util.List<android.net.Uri> r1 = r1.uris
            if (r1 == 0) goto L5b
            androidx.browser.trusted.sharing.ShareData r0 = r5.mShareData
            java.util.List<android.net.Uri> r0 = r0.uris
        L5b:
            java.util.List r1 = java.util.Collections.EMPTY_LIST
            androidx.browser.trusted.FileHandlingData r2 = r5.mFileHandlingData
            if (r2 == 0) goto L74
            java.lang.String r3 = "androidx.browser.trusted.extra.FILE_HANDLING_DATA"
            android.os.Bundle r2 = r2.toBundle()
            r6.putExtra(r3, r2)
            androidx.browser.trusted.FileHandlingData r2 = r5.mFileHandlingData
            java.util.List<android.net.Uri> r2 = r2.uris
            if (r2 == 0) goto L74
            androidx.browser.trusted.FileHandlingData r1 = r5.mFileHandlingData
            java.util.List<android.net.Uri> r1 = r1.uris
        L74:
            androidx.browser.trusted.TrustedWebActivityDisplayMode r2 = r5.mDisplayMode
            android.os.Bundle r2 = r2.toBundle()
            java.lang.String r3 = "androidx.browser.trusted.extra.DISPLAY_MODE"
            r6.putExtra(r3, r2)
            java.util.List<androidx.browser.trusted.TrustedWebActivityDisplayMode> r2 = r5.mDisplayOverrideList
            if (r2 == 0) goto La7
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            java.util.List<androidx.browser.trusted.TrustedWebActivityDisplayMode> r3 = r5.mDisplayOverrideList
            java.util.Iterator r3 = r3.iterator()
        L8e:
            boolean r4 = r3.hasNext()
            if (r4 == 0) goto La2
            java.lang.Object r4 = r3.next()
            androidx.browser.trusted.TrustedWebActivityDisplayMode r4 = (androidx.browser.trusted.TrustedWebActivityDisplayMode) r4
            android.os.Bundle r4 = r4.toBundle()
            r2.add(r4)
            goto L8e
        La2:
            java.lang.String r3 = "androidx.browser.trusted.extra.DISPLAY_OVERRIDE"
            r6.putExtra(r3, r2)
        La7:
            java.lang.String r2 = "androidx.browser.trusted.extra.SCREEN_ORIENTATION"
            int r3 = r5.mScreenOrientation
            r6.putExtra(r2, r3)
            android.net.Uri r2 = r5.mOriginalLaunchUrl
            if (r2 == 0) goto Lb7
            java.lang.String r3 = "androidx.browser.trusted.extra.ORIGINAL_LAUNCH_URL"
            r6.putExtra(r3, r2)
        Lb7:
            java.lang.String r2 = "androidx.browser.trusted.extra.LAUNCH_HANDLER_CLIENT_MODE"
            int r3 = r5.mLaunchHandlerClientMode
            r6.putExtra(r2, r3)
            androidx.browser.trusted.TrustedWebActivityIntent r2 = new androidx.browser.trusted.TrustedWebActivityIntent
            r2.<init>(r6, r0, r1)
            return r2
        Lc4:
            java.lang.NullPointerException r6 = new java.lang.NullPointerException
            java.lang.String r0 = "CustomTabsSession is required for launching a TWA"
            r6.<init>(r0)
            throw r6
    }

    public androidx.browser.customtabs.CustomTabsIntent buildCustomTabsIntent() {
            r1 = this;
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = r1.mIntentBuilder
            androidx.browser.customtabs.CustomTabsIntent r0 = r0.build()
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityDisplayMode getDisplayMode() {
            r1 = this;
            androidx.browser.trusted.TrustedWebActivityDisplayMode r0 = r1.mDisplayMode
            return r0
    }

    public android.net.Uri getUri() {
            r1 = this;
            android.net.Uri r0 = r1.mUri
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setAdditionalTrustedOrigins(java.util.List<java.lang.String> r1) {
            r0 = this;
            r0.mAdditionalTrustedOrigins = r1
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setColorScheme(int r2) {
            r1 = this;
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = r1.mIntentBuilder
            r0.setColorScheme(r2)
            return r1
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setColorSchemeParams(int r2, androidx.browser.customtabs.CustomTabColorSchemeParams r3) {
            r1 = this;
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = r1.mIntentBuilder
            r0.setColorSchemeParams(r2, r3)
            return r1
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setDefaultColorSchemeParams(androidx.browser.customtabs.CustomTabColorSchemeParams r2) {
            r1 = this;
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = r1.mIntentBuilder
            r0.setDefaultColorSchemeParams(r2)
            return r1
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setDisplayMode(androidx.browser.trusted.TrustedWebActivityDisplayMode r1) {
            r0 = this;
            r0.mDisplayMode = r1
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setDisplayOverrideList(java.util.List<androidx.browser.trusted.TrustedWebActivityDisplayMode> r1) {
            r0 = this;
            if (r1 != 0) goto La
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r0.mDisplayOverrideList = r1
            return r0
        La:
            r0.mDisplayOverrideList = r1
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setFileHandlingData(androidx.browser.trusted.FileHandlingData r1) {
            r0 = this;
            r0.mFileHandlingData = r1
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setLaunchHandlerClientMode(int r1) {
            r0 = this;
            r0.mLaunchHandlerClientMode = r1
            return r0
    }

    @java.lang.Deprecated
    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setNavigationBarColor(int r2) {
            r1 = this;
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = r1.mIntentBuilder
            r0.setNavigationBarColor(r2)
            return r1
    }

    @java.lang.Deprecated
    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setNavigationBarDividerColor(int r2) {
            r1 = this;
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = r1.mIntentBuilder
            r0.setNavigationBarDividerColor(r2)
            return r1
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setOriginalLaunchUrl(android.net.Uri r1) {
            r0 = this;
            r0.mOriginalLaunchUrl = r1
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setScreenOrientation(int r1) {
            r0 = this;
            r0.mScreenOrientation = r1
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setShareParams(androidx.browser.trusted.sharing.ShareTarget r1, androidx.browser.trusted.sharing.ShareData r2) {
            r0 = this;
            r0.mShareTarget = r1
            r0.mShareData = r2
            return r0
    }

    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setSplashScreenParams(android.os.Bundle r1) {
            r0 = this;
            r0.mSplashScreenParams = r1
            return r0
    }

    @java.lang.Deprecated
    public androidx.browser.trusted.TrustedWebActivityIntentBuilder setToolbarColor(int r2) {
            r1 = this;
            androidx.browser.customtabs.CustomTabsIntent$Builder r0 = r1.mIntentBuilder
            r0.setToolbarColor(r2)
            return r1
    }
}
