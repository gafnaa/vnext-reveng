package androidx.browser.auth;

/* JADX INFO: loaded from: classes.dex */
public interface AuthTabCallback {
    void onExtraCallback(java.lang.String r1, android.os.Bundle r2);

    android.os.Bundle onExtraCallbackWithResult(java.lang.String r1, android.os.Bundle r2);

    void onNavigationEvent(int r1, android.os.Bundle r2);

    void onWarmupCompleted(android.os.Bundle r1);
}
