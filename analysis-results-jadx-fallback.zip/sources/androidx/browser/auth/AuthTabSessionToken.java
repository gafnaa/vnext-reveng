package androidx.browser.auth;

/* JADX INFO: loaded from: classes.dex */
public final class AuthTabSessionToken {
    private static final java.lang.String TAG = "AuthTabSessionToken";
    private final androidx.browser.auth.AuthTabCallback mCallback;
    private final android.support.customtabs.IAuthTabCallback mCallbackBinder;
    private final android.app.PendingIntent mSessionId;


    static class MockCallback extends android.support.customtabs.IAuthTabCallback.Stub {
        MockCallback() {
                r0 = this;
                r0.<init>()
                return
        }

        @Override // android.support.customtabs.IAuthTabCallback
        public int getInterfaceVersion() {
                r1 = this;
                r0 = 1
                return r0
        }

        @Override // android.support.customtabs.IAuthTabCallback
        public void onExtraCallback(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.IAuthTabCallback
        public android.os.Bundle onExtraCallbackWithResult(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                android.os.Bundle r1 = android.os.Bundle.EMPTY
                return r1
        }

        @Override // android.support.customtabs.IAuthTabCallback
        public void onNavigationEvent(int r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.IAuthTabCallback
        public void onWarmupCompleted(android.os.Bundle r1) throws android.os.RemoteException {
                r0 = this;
                return
        }
    }

    public AuthTabSessionToken(android.support.customtabs.IAuthTabCallback r1, android.app.PendingIntent r2) {
            r0 = this;
            r0.<init>()
            if (r1 != 0) goto L10
            if (r2 == 0) goto L8
            goto L10
        L8:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "AuthTabSessionToken must have either a session id or a callback (or both)."
            r1.<init>(r2)
            throw r1
        L10:
            r0.mCallbackBinder = r1
            r0.mSessionId = r2
            if (r1 != 0) goto L18
            r1 = 0
            goto L1d
        L18:
            androidx.browser.auth.AuthTabSessionToken$1 r1 = new androidx.browser.auth.AuthTabSessionToken$1
            r1.<init>(r0)
        L1d:
            r0.mCallback = r1
            return
    }

    static /* synthetic */ android.support.customtabs.IAuthTabCallback access$000(androidx.browser.auth.AuthTabSessionToken r0) {
            android.support.customtabs.IAuthTabCallback r0 = r0.mCallbackBinder
            return r0
    }

    public static androidx.browser.auth.AuthTabSessionToken createSessionTokenFromIntent(android.content.Intent r4) {
            android.os.Bundle r0 = r4.getExtras()
            r1 = 0
            if (r0 != 0) goto L8
            return r1
        L8:
            java.lang.String r2 = "android.support.customtabs.extra.SESSION"
            android.os.IBinder r0 = r0.getBinder(r2)
            java.lang.String r2 = "android.support.customtabs.extra.SESSION_ID"
            java.lang.Class<android.app.PendingIntent> r3 = android.app.PendingIntent.class
            java.lang.Object r4 = androidx.core.content.IntentCompat.getParcelableExtra(r4, r2, r3)
            android.app.PendingIntent r4 = (android.app.PendingIntent) r4
            if (r0 != 0) goto L1d
            if (r4 != 0) goto L1d
            return r1
        L1d:
            if (r0 != 0) goto L20
            goto L24
        L20:
            android.support.customtabs.IAuthTabCallback r1 = android.support.customtabs.IAuthTabCallback.Stub.asInterface(r0)
        L24:
            androidx.browser.auth.AuthTabSessionToken r0 = new androidx.browser.auth.AuthTabSessionToken
            r0.<init>(r1, r4)
            return r0
    }

    private android.os.IBinder getCallbackBinderAssertNotNull() {
            r2 = this;
            android.support.customtabs.IAuthTabCallback r0 = r2.mCallbackBinder
            if (r0 == 0) goto L9
            android.os.IBinder r0 = r0.asBinder()
            return r0
        L9:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "AuthTabSessionToken must have valid binder or pending session"
            r0.<init>(r1)
            throw r0
    }

    public boolean equals(java.lang.Object r6) {
            r5 = this;
            boolean r0 = r6 instanceof androidx.browser.auth.AuthTabSessionToken
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            androidx.browser.auth.AuthTabSessionToken r6 = (androidx.browser.auth.AuthTabSessionToken) r6
            android.app.PendingIntent r0 = r6.getId()
            android.app.PendingIntent r2 = r5.mSessionId
            r3 = 1
            if (r2 != 0) goto L13
            r4 = r3
            goto L14
        L13:
            r4 = r1
        L14:
            if (r0 != 0) goto L17
            goto L18
        L17:
            r3 = r1
        L18:
            if (r4 == r3) goto L1b
            return r1
        L1b:
            if (r2 == 0) goto L22
            boolean r6 = r2.equals(r0)
            return r6
        L22:
            android.os.IBinder r0 = r5.getCallbackBinderAssertNotNull()
            android.os.IBinder r6 = r6.getCallbackBinderAssertNotNull()
            boolean r6 = r0.equals(r6)
            return r6
    }

    public androidx.browser.auth.AuthTabCallback getCallback() {
            r1 = this;
            androidx.browser.auth.AuthTabCallback r0 = r1.mCallback
            return r0
    }

    public android.os.IBinder getCallbackBinder() {
            r1 = this;
            android.support.customtabs.IAuthTabCallback r0 = r1.mCallbackBinder
            if (r0 != 0) goto L6
            r0 = 0
            return r0
        L6:
            android.os.IBinder r0 = r0.asBinder()
            return r0
    }

    public android.app.PendingIntent getId() {
            r1 = this;
            android.app.PendingIntent r0 = r1.mSessionId
            return r0
    }

    public boolean hasId() {
            r1 = this;
            android.app.PendingIntent r0 = r1.mSessionId
            if (r0 == 0) goto L6
            r0 = 1
            return r0
        L6:
            r0 = 0
            return r0
    }

    public int hashCode() {
            r1 = this;
            android.app.PendingIntent r0 = r1.mSessionId
            if (r0 == 0) goto L9
            int r0 = r0.hashCode()
            return r0
        L9:
            android.os.IBinder r0 = r1.getCallbackBinderAssertNotNull()
            int r0 = r0.hashCode()
            return r0
    }

    public boolean isAssociatedWith(androidx.browser.auth.AuthTabSession r2) {
            r1 = this;
            android.os.IBinder r2 = r2.getBinder()
            android.support.customtabs.IAuthTabCallback r0 = r1.mCallbackBinder
            boolean r2 = r2.equals(r0)
            return r2
    }
}
