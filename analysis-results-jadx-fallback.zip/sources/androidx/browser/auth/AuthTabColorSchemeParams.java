package androidx.browser.auth;

/* JADX INFO: loaded from: classes.dex */
public final class AuthTabColorSchemeParams {
    private final java.lang.Integer mNavigationBarColor;
    private final java.lang.Integer mNavigationBarDividerColor;
    private final java.lang.Integer mToolbarColor;

    /* JADX INFO: renamed from: androidx.browser.auth.AuthTabColorSchemeParams$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
    }

    public static final class Builder {
        private java.lang.Integer mNavigationBarColor;
        private java.lang.Integer mNavigationBarDividerColor;
        private java.lang.Integer mToolbarColor;

        public Builder() {
                r0 = this;
                r0.<init>()
                return
        }

        public androidx.browser.auth.AuthTabColorSchemeParams build() {
                r5 = this;
                androidx.browser.auth.AuthTabColorSchemeParams r0 = new androidx.browser.auth.AuthTabColorSchemeParams
                java.lang.Integer r1 = r5.mToolbarColor
                java.lang.Integer r2 = r5.mNavigationBarColor
                java.lang.Integer r3 = r5.mNavigationBarDividerColor
                r4 = 0
                r0.<init>(r1, r2, r3, r4)
                return r0
        }

        public androidx.browser.auth.AuthTabColorSchemeParams.Builder setNavigationBarColor(int r2) {
                r1 = this;
                r0 = -16777216(0xffffffffff000000, float:-1.7014118E38)
                r2 = r2 | r0
                java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
                r1.mNavigationBarColor = r2
                return r1
        }

        public androidx.browser.auth.AuthTabColorSchemeParams.Builder setNavigationBarDividerColor(int r1) {
                r0 = this;
                java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
                r0.mNavigationBarDividerColor = r1
                return r0
        }

        public androidx.browser.auth.AuthTabColorSchemeParams.Builder setToolbarColor(int r2) {
                r1 = this;
                r0 = -16777216(0xffffffffff000000, float:-1.7014118E38)
                r2 = r2 | r0
                java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
                r1.mToolbarColor = r2
                return r1
        }
    }

    private AuthTabColorSchemeParams(java.lang.Integer r1, java.lang.Integer r2, java.lang.Integer r3) {
            r0 = this;
            r0.<init>()
            r0.mToolbarColor = r1
            r0.mNavigationBarColor = r2
            r0.mNavigationBarDividerColor = r3
            return
    }

    /* synthetic */ AuthTabColorSchemeParams(java.lang.Integer r1, java.lang.Integer r2, java.lang.Integer r3, androidx.browser.auth.AuthTabColorSchemeParams.AnonymousClass1 r4) {
            r0 = this;
            r0.<init>(r1, r2, r3)
            return
    }

    static androidx.browser.auth.AuthTabColorSchemeParams fromBundle(android.os.Bundle r4) {
            if (r4 != 0) goto L8
            android.os.Bundle r4 = new android.os.Bundle
            r0 = 0
            r4.<init>(r0)
        L8:
            androidx.browser.auth.AuthTabColorSchemeParams r0 = new androidx.browser.auth.AuthTabColorSchemeParams
            java.lang.String r1 = "android.support.customtabs.extra.TOOLBAR_COLOR"
            java.lang.Object r1 = r4.get(r1)
            java.lang.Integer r1 = (java.lang.Integer) r1
            java.lang.String r2 = "androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR"
            java.lang.Object r2 = r4.get(r2)
            java.lang.Integer r2 = (java.lang.Integer) r2
            java.lang.String r3 = "androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR"
            java.lang.Object r4 = r4.get(r3)
            java.lang.Integer r4 = (java.lang.Integer) r4
            r0.<init>(r1, r2, r4)
            return r0
    }

    public java.lang.Integer getNavigationBarColor() {
            r1 = this;
            java.lang.Integer r0 = r1.mNavigationBarColor
            return r0
    }

    public java.lang.Integer getNavigationBarDividerColor() {
            r1 = this;
            java.lang.Integer r0 = r1.mNavigationBarDividerColor
            return r0
    }

    public java.lang.Integer getToolbarColor() {
            r1 = this;
            java.lang.Integer r0 = r1.mToolbarColor
            return r0
    }

    android.os.Bundle toBundle() {
            r3 = this;
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            java.lang.Integer r1 = r3.mToolbarColor
            if (r1 == 0) goto L12
            java.lang.String r2 = "android.support.customtabs.extra.TOOLBAR_COLOR"
            int r1 = r1.intValue()
            r0.putInt(r2, r1)
        L12:
            java.lang.Integer r1 = r3.mNavigationBarColor
            if (r1 == 0) goto L1f
            java.lang.String r2 = "androidx.browser.customtabs.extra.NAVIGATION_BAR_COLOR"
            int r1 = r1.intValue()
            r0.putInt(r2, r1)
        L1f:
            java.lang.Integer r1 = r3.mNavigationBarDividerColor
            if (r1 == 0) goto L2c
            java.lang.String r2 = "androidx.browser.customtabs.extra.NAVIGATION_BAR_DIVIDER_COLOR"
            int r1 = r1.intValue()
            r0.putInt(r2, r1)
        L2c:
            return r0
    }

    androidx.browser.auth.AuthTabColorSchemeParams withDefaults(androidx.browser.auth.AuthTabColorSchemeParams r5) {
            r4 = this;
            androidx.browser.auth.AuthTabColorSchemeParams r0 = new androidx.browser.auth.AuthTabColorSchemeParams
            java.lang.Integer r1 = r4.mToolbarColor
            if (r1 != 0) goto L8
            java.lang.Integer r1 = r5.mToolbarColor
        L8:
            java.lang.Integer r2 = r4.mNavigationBarColor
            if (r2 != 0) goto Le
            java.lang.Integer r2 = r5.mNavigationBarColor
        Le:
            java.lang.Integer r3 = r4.mNavigationBarDividerColor
            if (r3 != 0) goto L14
            java.lang.Integer r3 = r5.mNavigationBarDividerColor
        L14:
            r0.<init>(r1, r2, r3)
            return r0
    }
}
