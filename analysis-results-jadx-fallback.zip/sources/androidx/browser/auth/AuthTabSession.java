package androidx.browser.auth;

/* JADX INFO: loaded from: classes.dex */
public final class AuthTabSession {
    private final android.support.customtabs.IAuthTabCallback mCallback;
    private final android.content.ComponentName mComponentName;
    private final android.app.PendingIntent mId;

    public static class PendingSession {
        private final androidx.browser.auth.AuthTabCallback mCallback;
        private final java.util.concurrent.Executor mExecutor;
        private final android.app.PendingIntent mId;

        public PendingSession(android.app.PendingIntent r1, java.util.concurrent.Executor r2, androidx.browser.auth.AuthTabCallback r3) {
                r0 = this;
                r0.<init>()
                r0.mId = r1
                r0.mExecutor = r2
                r0.mCallback = r3
                return
        }

        public androidx.browser.auth.AuthTabCallback getCallback() {
                r1 = this;
                androidx.browser.auth.AuthTabCallback r0 = r1.mCallback
                return r0
        }

        public java.util.concurrent.Executor getExecutor() {
                r1 = this;
                java.util.concurrent.Executor r0 = r1.mExecutor
                return r0
        }

        public android.app.PendingIntent getId() {
                r1 = this;
                android.app.PendingIntent r0 = r1.mId
                return r0
        }
    }

    public AuthTabSession(android.support.customtabs.IAuthTabCallback r1, android.content.ComponentName r2, android.app.PendingIntent r3) {
            r0 = this;
            r0.<init>()
            r0.mCallback = r1
            r0.mComponentName = r2
            r0.mId = r3
            return
    }

    android.os.IBinder getBinder() {
            r1 = this;
            android.support.customtabs.IAuthTabCallback r0 = r1.mCallback
            android.os.IBinder r0 = r0.asBinder()
            return r0
    }

    android.content.ComponentName getComponentName() {
            r1 = this;
            android.content.ComponentName r0 = r1.mComponentName
            return r0
    }

    android.app.PendingIntent getId() {
            r1 = this;
            android.app.PendingIntent r0 = r1.mId
            return r0
    }
}
