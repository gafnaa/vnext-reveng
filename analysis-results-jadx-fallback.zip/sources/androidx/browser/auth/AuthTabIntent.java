package androidx.browser.auth;

/* JADX INFO: loaded from: classes.dex */
public class AuthTabIntent {
    public static final java.lang.String EXTRA_HTTPS_REDIRECT_HOST = "androidx.browser.auth.extra.HTTPS_REDIRECT_HOST";
    public static final java.lang.String EXTRA_HTTPS_REDIRECT_PATH = "androidx.browser.auth.extra.HTTPS_REDIRECT_PATH";
    public static final java.lang.String EXTRA_LAUNCH_AUTH_TAB = "androidx.browser.auth.extra.LAUNCH_AUTH_TAB";
    public static final java.lang.String EXTRA_REDIRECT_SCHEME = "androidx.browser.auth.extra.REDIRECT_SCHEME";
    public static final int RESULT_CANCELED = 0;
    public static final int RESULT_OK = -1;
    public static final int RESULT_UNKNOWN_CODE = -2;
    public static final int RESULT_VERIFICATION_FAILED = 2;
    public static final int RESULT_VERIFICATION_TIMED_OUT = 3;
    public final android.content.Intent intent;
    private final androidx.browser.auth.AuthTabSession.PendingSession mPendingSession;
    private final androidx.browser.auth.AuthTabSession mSession;

    /* JADX INFO: renamed from: androidx.browser.auth.AuthTabIntent$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
    }

    public static final class AuthResult {
        public final int resultCode;
        public final android.net.Uri resultUri;

        AuthResult(int r1, android.net.Uri r2) {
                r0 = this;
                r0.<init>()
                r0.resultCode = r1
                r0.resultUri = r2
                return
        }
    }

    public static class AuthenticateUserResultContract extends androidx.activity.result.contract.ActivityResultContract<android.content.Intent, androidx.browser.auth.AuthTabIntent.AuthResult> {
        public AuthenticateUserResultContract() {
                r0 = this;
                r0.<init>()
                return
        }

        /* JADX INFO: renamed from: createIntent, reason: avoid collision after fix types in other method */
        public android.content.Intent createIntent2(android.content.Context r1, android.content.Intent r2) {
                r0 = this;
                return r2
        }

        @Override // androidx.activity.result.contract.ActivityResultContract
        public /* bridge */ /* synthetic */ android.content.Intent createIntent(android.content.Context r1, android.content.Intent r2) {
                r0 = this;
                android.content.Intent r2 = (android.content.Intent) r2
                android.content.Intent r1 = r0.createIntent2(r1, r2)
                return r1
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // androidx.activity.result.contract.ActivityResultContract
        public androidx.browser.auth.AuthTabIntent.AuthResult parseResult(int r3, android.content.Intent r4) {
                r2 = this;
                r0 = -1
                r1 = 0
                if (r3 == r0) goto Le
                if (r3 == 0) goto L15
                r4 = 2
                if (r3 == r4) goto L15
                r4 = 3
                if (r3 == r4) goto L15
                r3 = -2
                goto L15
            Le:
                if (r4 == 0) goto L15
                android.net.Uri r4 = r4.getData()
                r1 = r4
            L15:
                androidx.browser.auth.AuthTabIntent$AuthResult r4 = new androidx.browser.auth.AuthTabIntent$AuthResult
                r4.<init>(r3, r1)
                return r4
        }

        @Override // androidx.activity.result.contract.ActivityResultContract
        public /* bridge */ /* synthetic */ androidx.browser.auth.AuthTabIntent.AuthResult parseResult(int r1, android.content.Intent r2) {
                r0 = this;
                androidx.browser.auth.AuthTabIntent$AuthResult r1 = r0.parseResult(r1, r2)
                return r1
        }
    }

    public static final class Builder {
        private android.util.SparseArray<android.os.Bundle> mColorSchemeParamBundles;
        private final androidx.browser.auth.AuthTabColorSchemeParams.Builder mDefaultColorSchemeBuilder;
        private android.os.Bundle mDefaultColorSchemeBundle;
        private final android.content.Intent mIntent;
        private androidx.browser.auth.AuthTabSession.PendingSession mPendingSession;
        private androidx.browser.auth.AuthTabSession mSession;

        public Builder() {
                r2 = this;
                r2.<init>()
                android.content.Intent r0 = new android.content.Intent
                java.lang.String r1 = "android.intent.action.VIEW"
                r0.<init>(r1)
                r2.mIntent = r0
                androidx.browser.auth.AuthTabColorSchemeParams$Builder r0 = new androidx.browser.auth.AuthTabColorSchemeParams$Builder
                r0.<init>()
                r2.mDefaultColorSchemeBuilder = r0
                return
        }

        private void setSessionParameters(android.os.IBinder r3, android.app.PendingIntent r4) {
                r2 = this;
                android.os.Bundle r0 = new android.os.Bundle
                r0.<init>()
                java.lang.String r1 = "android.support.customtabs.extra.SESSION"
                r0.putBinder(r1, r3)
                if (r4 == 0) goto L11
                java.lang.String r3 = "android.support.customtabs.extra.SESSION_ID"
                r0.putParcelable(r3, r4)
            L11:
                android.content.Intent r3 = r2.mIntent
                r3.putExtras(r0)
                return
        }

        public androidx.browser.auth.AuthTabIntent build() {
                r5 = this;
                android.content.Intent r0 = r5.mIntent
                java.lang.String r1 = "androidx.browser.auth.extra.LAUNCH_AUTH_TAB"
                r2 = 1
                r0.putExtra(r1, r2)
                android.content.Intent r0 = r5.mIntent
                java.lang.String r1 = "android.support.customtabs.extra.SESSION"
                boolean r0 = r0.hasExtra(r1)
                r1 = 0
                if (r0 != 0) goto L16
                r5.setSessionParameters(r1, r1)
            L16:
                android.content.Intent r0 = r5.mIntent
                androidx.browser.auth.AuthTabColorSchemeParams$Builder r2 = r5.mDefaultColorSchemeBuilder
                androidx.browser.auth.AuthTabColorSchemeParams r2 = r2.build()
                android.os.Bundle r2 = r2.toBundle()
                r0.putExtras(r2)
                android.os.Bundle r0 = r5.mDefaultColorSchemeBundle
                if (r0 == 0) goto L2e
                android.content.Intent r2 = r5.mIntent
                r2.putExtras(r0)
            L2e:
                android.util.SparseArray<android.os.Bundle> r0 = r5.mColorSchemeParamBundles
                if (r0 == 0) goto L43
                android.os.Bundle r0 = new android.os.Bundle
                r0.<init>()
                java.lang.String r2 = "androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS"
                android.util.SparseArray<android.os.Bundle> r3 = r5.mColorSchemeParamBundles
                r0.putSparseParcelableArray(r2, r3)
                android.content.Intent r2 = r5.mIntent
                r2.putExtras(r0)
            L43:
                androidx.browser.auth.AuthTabIntent r0 = new androidx.browser.auth.AuthTabIntent
                android.content.Intent r2 = r5.mIntent
                androidx.browser.auth.AuthTabSession r3 = r5.mSession
                androidx.browser.auth.AuthTabSession$PendingSession r4 = r5.mPendingSession
                r0.<init>(r2, r3, r4, r1)
                return r0
        }

        public androidx.browser.auth.AuthTabIntent.Builder setCloseButtonIcon(android.graphics.Bitmap r3) {
                r2 = this;
                android.content.Intent r0 = r2.mIntent
                java.lang.String r1 = "android.support.customtabs.extra.CLOSE_BUTTON_ICON"
                r0.putExtra(r1, r3)
                return r2
        }

        public androidx.browser.auth.AuthTabIntent.Builder setColorScheme(int r3) {
                r2 = this;
                android.content.Intent r0 = r2.mIntent
                java.lang.String r1 = "androidx.browser.customtabs.extra.COLOR_SCHEME"
                r0.putExtra(r1, r3)
                return r2
        }

        public androidx.browser.auth.AuthTabIntent.Builder setColorSchemeParams(int r2, androidx.browser.auth.AuthTabColorSchemeParams r3) {
                r1 = this;
                android.util.SparseArray<android.os.Bundle> r0 = r1.mColorSchemeParamBundles
                if (r0 != 0) goto Lb
                android.util.SparseArray r0 = new android.util.SparseArray
                r0.<init>()
                r1.mColorSchemeParamBundles = r0
            Lb:
                android.util.SparseArray<android.os.Bundle> r0 = r1.mColorSchemeParamBundles
                android.os.Bundle r3 = r3.toBundle()
                r0.put(r2, r3)
                return r1
        }

        public androidx.browser.auth.AuthTabIntent.Builder setDefaultColorSchemeParams(androidx.browser.auth.AuthTabColorSchemeParams r1) {
                r0 = this;
                android.os.Bundle r1 = r1.toBundle()
                r0.mDefaultColorSchemeBundle = r1
                return r0
        }

        public androidx.browser.auth.AuthTabIntent.Builder setEphemeralBrowsingEnabled(boolean r3) {
                r2 = this;
                android.content.Intent r0 = r2.mIntent
                java.lang.String r1 = "androidx.browser.customtabs.extra.ENABLE_EPHEMERAL_BROWSING"
                r0.putExtra(r1, r3)
                return r2
        }

        public androidx.browser.auth.AuthTabIntent.Builder setPendingSession(androidx.browser.auth.AuthTabSession.PendingSession r2) {
                r1 = this;
                r1.mPendingSession = r2
                r0 = 0
                android.app.PendingIntent r2 = r2.getId()
                r1.setSessionParameters(r0, r2)
                return r1
        }

        public androidx.browser.auth.AuthTabIntent.Builder setSession(androidx.browser.auth.AuthTabSession r3) {
                r2 = this;
                r2.mSession = r3
                android.content.Intent r0 = r2.mIntent
                android.content.ComponentName r1 = r3.getComponentName()
                java.lang.String r1 = r1.getPackageName()
                r0.setPackage(r1)
                android.os.IBinder r0 = r3.getBinder()
                android.app.PendingIntent r3 = r3.getId()
                r2.setSessionParameters(r0, r3)
                return r2
        }
    }

    @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.SOURCE)
    public @interface ResultCode {
    }

    private AuthTabIntent(android.content.Intent r1, androidx.browser.auth.AuthTabSession r2, androidx.browser.auth.AuthTabSession.PendingSession r3) {
            r0 = this;
            r0.<init>()
            r0.intent = r1
            r0.mSession = r2
            r0.mPendingSession = r3
            return
    }

    /* synthetic */ AuthTabIntent(android.content.Intent r1, androidx.browser.auth.AuthTabSession r2, androidx.browser.auth.AuthTabSession.PendingSession r3, androidx.browser.auth.AuthTabIntent.AnonymousClass1 r4) {
            r0 = this;
            r0.<init>(r1, r2, r3)
            return
    }

    public static androidx.browser.auth.AuthTabColorSchemeParams getColorSchemeParams(android.content.Intent r3, int r4) {
            android.os.Bundle r3 = r3.getExtras()
            if (r3 != 0) goto Lc
            r3 = 0
            androidx.browser.auth.AuthTabColorSchemeParams r3 = androidx.browser.auth.AuthTabColorSchemeParams.fromBundle(r3)
            return r3
        Lc:
            androidx.browser.auth.AuthTabColorSchemeParams r0 = androidx.browser.auth.AuthTabColorSchemeParams.fromBundle(r3)
            java.lang.String r1 = "androidx.browser.customtabs.extra.COLOR_SCHEME_PARAMS"
            java.lang.Class<android.os.Bundle> r2 = android.os.Bundle.class
            android.util.SparseArray r3 = androidx.core.os.BundleCompat.getSparseParcelableArray(r3, r1, r2)
            if (r3 == 0) goto L2b
            java.lang.Object r3 = r3.get(r4)
            android.os.Bundle r3 = (android.os.Bundle) r3
            if (r3 == 0) goto L2b
            androidx.browser.auth.AuthTabColorSchemeParams r3 = androidx.browser.auth.AuthTabColorSchemeParams.fromBundle(r3)
            androidx.browser.auth.AuthTabColorSchemeParams r3 = r3.withDefaults(r0)
            return r3
        L2b:
            return r0
    }

    public static androidx.activity.result.ActivityResultLauncher<android.content.Intent> registerActivityResultLauncher(androidx.activity.result.ActivityResultCaller r1, androidx.activity.result.ActivityResultCallback<androidx.browser.auth.AuthTabIntent.AuthResult> r2) {
            androidx.browser.auth.AuthTabIntent$AuthenticateUserResultContract r0 = new androidx.browser.auth.AuthTabIntent$AuthenticateUserResultContract
            r0.<init>()
            androidx.activity.result.ActivityResultLauncher r1 = r1.registerForActivityResult(r0, r2)
            return r1
    }

    public android.graphics.Bitmap getCloseButtonIcon() {
            r3 = this;
            android.content.Intent r0 = r3.intent
            java.lang.String r1 = "android.support.customtabs.extra.CLOSE_BUTTON_ICON"
            java.lang.Class<android.graphics.Bitmap> r2 = android.graphics.Bitmap.class
            java.lang.Object r0 = androidx.core.content.IntentCompat.getParcelableExtra(r0, r1, r2)
            android.graphics.Bitmap r0 = (android.graphics.Bitmap) r0
            return r0
    }

    public androidx.browser.auth.AuthTabSession.PendingSession getPendingSession() {
            r1 = this;
            androidx.browser.auth.AuthTabSession$PendingSession r0 = r1.mPendingSession
            return r0
    }

    public androidx.browser.auth.AuthTabSession getSession() {
            r1 = this;
            androidx.browser.auth.AuthTabSession r0 = r1.mSession
            return r0
    }

    public boolean isEphemeralBrowsingEnabled() {
            r3 = this;
            android.content.Intent r0 = r3.intent
            java.lang.String r1 = "androidx.browser.customtabs.extra.ENABLE_EPHEMERAL_BROWSING"
            r2 = 0
            boolean r0 = r0.getBooleanExtra(r1, r2)
            return r0
    }

    public void launch(androidx.activity.result.ActivityResultLauncher<android.content.Intent> r2, android.net.Uri r3, java.lang.String r4) {
            r1 = this;
            android.content.Intent r0 = r1.intent
            r0.setData(r3)
            android.content.Intent r3 = r1.intent
            java.lang.String r0 = "androidx.browser.auth.extra.REDIRECT_SCHEME"
            r3.putExtra(r0, r4)
            android.content.Intent r3 = r1.intent
            r2.launch(r3)
            return
    }

    public void launch(androidx.activity.result.ActivityResultLauncher<android.content.Intent> r2, android.net.Uri r3, java.lang.String r4, java.lang.String r5) {
            r1 = this;
            android.content.Intent r0 = r1.intent
            r0.setData(r3)
            android.content.Intent r3 = r1.intent
            java.lang.String r0 = "androidx.browser.auth.extra.HTTPS_REDIRECT_HOST"
            r3.putExtra(r0, r4)
            android.content.Intent r3 = r1.intent
            java.lang.String r4 = "androidx.browser.auth.extra.HTTPS_REDIRECT_PATH"
            r3.putExtra(r4, r5)
            android.content.Intent r3 = r1.intent
            r2.launch(r3)
            return
    }
}
