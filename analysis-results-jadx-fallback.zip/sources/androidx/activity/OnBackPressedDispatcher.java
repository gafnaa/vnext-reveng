package androidx.activity;

/* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001:\u0001$B!\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u000e\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005¢\u0006\u0004\b\u0007\u0010\bB\u0015\b\u0017\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\u0004\b\u0007\u0010\tJ\u0010\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0018H\u0007J\u0010\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u001a\u001a\u00020\u001bH\u0007J\u0018\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001a\u001a\u00020\u001bH\u0007J\b\u0010\n\u001a\u00020\u0006H\u0007J\u0010\u0010\u001e\u001a\u00020\u00162\u0006\u0010\u001f\u001a\u00020 H\u0007J\u0010\u0010!\u001a\u00020\u00162\u0006\u0010\u001f\u001a\u00020 H\u0007J\b\u0010\"\u001a\u00020\u0016H\u0007J\b\u0010#\u001a\u00020\u0016H\u0007R\u0010\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0016\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u001f\u0010\u000b\u001a\u00060\fR\u00020\u00008BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\r\u0010\u000eR\u0014\u0010\u0011\u001a\u00020\u00128@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u0014¨\u0006%"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher;", "", "fallbackOnBackPressed", "Ljava/lang/Runnable;", "onHasEnabledCallbacksChanged", "Landroidx/core/util/Consumer;", "", "<init>", "(Ljava/lang/Runnable;Landroidx/core/util/Consumer;)V", "(Ljava/lang/Runnable;)V", "hasEnabledCallbacks", "eventInput", "Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput;", "getEventInput", "()Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput;", "eventInput$delegate", "Lkotlin/Lazy;", "eventDispatcher", "Landroidx/navigationevent/NavigationEventDispatcher;", "getEventDispatcher$activity", "()Landroidx/navigationevent/NavigationEventDispatcher;", "setOnBackInvokedDispatcher", "", "invoker", "Landroid/window/OnBackInvokedDispatcher;", "addCallback", "onBackPressedCallback", "Landroidx/activity/OnBackPressedCallback;", "owner", "Landroidx/lifecycle/LifecycleOwner;", "dispatchOnBackStarted", "backEvent", "Landroidx/activity/BackEventCompat;", "dispatchOnBackProgressed", "onBackPressed", "dispatchOnBackCancelled", "OnBackPressedEventInput", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class OnBackPressedDispatcher {
    private final kotlin.Lazy eventInput$delegate;
    private final java.lang.Runnable fallbackOnBackPressed;
    private boolean hasEnabledCallbacks;
    private final androidx.core.util.Consumer<java.lang.Boolean> onHasEnabledCallbacksChanged;

    /* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
    @kotlin.Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0014J\u000e\u0010\f\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\u000eJ\u000e\u0010\u000f\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\u000eJ\u0006\u0010\u0010\u001a\u00020\tJ\u0006\u0010\u0011\u001a\u00020\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput;", "Landroidx/navigationevent/NavigationEventInput;", "<init>", "(Landroidx/activity/OnBackPressedDispatcher;)V", "dispatcher", "Landroidx/navigationevent/NavigationEventDispatcher;", "getDispatcher", "()Landroidx/navigationevent/NavigationEventDispatcher;", "onHasEnabledHandlersChanged", "", "hasEnabledHandlers", "", "backStarted", "event", "Landroidx/navigationevent/NavigationEvent;", "backProgressed", "backCancelled", "backCompleted", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
    private final class OnBackPressedEventInput extends androidx.navigationevent.NavigationEventInput {
        private final androidx.navigationevent.NavigationEventDispatcher dispatcher;
        final /* synthetic */ androidx.activity.OnBackPressedDispatcher this$0;

        /* JADX INFO: renamed from: $r8$lambda$dPEOltV-NxwFUffOSXiaKZsPUiI, reason: not valid java name */
        public static /* synthetic */ void m47$r8$lambda$dPEOltVNxwFUffOSXiaKZsPUiI(androidx.activity.OnBackPressedDispatcher r0) {
                dispatcher$lambda$0(r0)
                return
        }

        public OnBackPressedEventInput(androidx.activity.OnBackPressedDispatcher r3) {
                r2 = this;
                r2.this$0 = r3
                r2.<init>()
                androidx.navigationevent.NavigationEventDispatcher r0 = new androidx.navigationevent.NavigationEventDispatcher
                androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput$$ExternalSyntheticLambda0 r1 = new androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput$$ExternalSyntheticLambda0
                r1.<init>(r3)
                r0.<init>(r1)
                r3 = r2
                androidx.navigationevent.NavigationEventInput r3 = (androidx.navigationevent.NavigationEventInput) r3
                r0.addInput(r3)
                r2.dispatcher = r0
                return
        }

        private static final void dispatcher$lambda$0(androidx.activity.OnBackPressedDispatcher r0) {
                java.lang.Runnable r0 = androidx.activity.OnBackPressedDispatcher.access$getFallbackOnBackPressed$p(r0)
                if (r0 == 0) goto L9
                r0.run()
            L9:
                return
        }

        public final void backCancelled() {
                r0 = this;
                r0.dispatchOnBackCancelled()
                return
        }

        public final void backCompleted() {
                r0 = this;
                r0.dispatchOnBackCompleted()
                return
        }

        public final void backProgressed(androidx.navigationevent.NavigationEvent r2) {
                r1 = this;
                java.lang.String r0 = "event"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                r1.dispatchOnBackProgressed(r2)
                return
        }

        public final void backStarted(androidx.navigationevent.NavigationEvent r2) {
                r1 = this;
                java.lang.String r0 = "event"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                r1.dispatchOnBackStarted(r2)
                return
        }

        public final androidx.navigationevent.NavigationEventDispatcher getDispatcher() {
                r1 = this;
                androidx.navigationevent.NavigationEventDispatcher r0 = r1.dispatcher
                return r0
        }

        @Override // androidx.navigationevent.NavigationEventInput
        protected void onHasEnabledHandlersChanged(boolean r2) {
                r1 = this;
                androidx.activity.OnBackPressedDispatcher r0 = r1.this$0
                androidx.activity.OnBackPressedDispatcher.access$setHasEnabledCallbacks$p(r0, r2)
                androidx.activity.OnBackPressedDispatcher r0 = r1.this$0
                androidx.core.util.Consumer r0 = androidx.activity.OnBackPressedDispatcher.access$getOnHasEnabledCallbacksChanged$p(r0)
                if (r0 == 0) goto L14
                java.lang.Boolean r2 = java.lang.Boolean.valueOf(r2)
                r0.accept(r2)
            L14:
                return
        }
    }

    public static /* synthetic */ androidx.activity.OnBackPressedDispatcher.OnBackPressedEventInput $r8$lambda$Ce6hmwzpZeR4nJ6cSxwnPFSCXfY(androidx.activity.OnBackPressedDispatcher r0) {
            androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput r0 = eventInput_delegate$lambda$0(r0)
            return r0
    }

    public OnBackPressedDispatcher() {
            r2 = this;
            r0 = 0
            r1 = 1
            r2.<init>(r0, r1, r0)
            return
    }

    public OnBackPressedDispatcher(java.lang.Runnable r2) {
            r1 = this;
            r0 = 0
            r1.<init>(r2, r0)
            return
    }

    public /* synthetic */ OnBackPressedDispatcher(java.lang.Runnable r1, int r2, kotlin.jvm.internal.DefaultConstructorMarker r3) {
            r0 = this;
            r2 = r2 & 1
            if (r2 == 0) goto L5
            r1 = 0
        L5:
            r0.<init>(r1)
            return
    }

    public OnBackPressedDispatcher(java.lang.Runnable r1, androidx.core.util.Consumer<java.lang.Boolean> r2) {
            r0 = this;
            r0.<init>()
            r0.fallbackOnBackPressed = r1
            r0.onHasEnabledCallbacksChanged = r2
            androidx.activity.OnBackPressedDispatcher$$ExternalSyntheticLambda0 r1 = new androidx.activity.OnBackPressedDispatcher$$ExternalSyntheticLambda0
            r1.<init>(r0)
            kotlin.Lazy r1 = kotlin.LazyKt.lazy(r1)
            r0.eventInput$delegate = r1
            return
    }

    public static final /* synthetic */ java.lang.Runnable access$getFallbackOnBackPressed$p(androidx.activity.OnBackPressedDispatcher r0) {
            java.lang.Runnable r0 = r0.fallbackOnBackPressed
            return r0
    }

    public static final /* synthetic */ androidx.core.util.Consumer access$getOnHasEnabledCallbacksChanged$p(androidx.activity.OnBackPressedDispatcher r0) {
            androidx.core.util.Consumer<java.lang.Boolean> r0 = r0.onHasEnabledCallbacksChanged
            return r0
    }

    public static final /* synthetic */ void access$setHasEnabledCallbacks$p(androidx.activity.OnBackPressedDispatcher r0, boolean r1) {
            r0.hasEnabledCallbacks = r1
            return
    }

    private static final androidx.activity.OnBackPressedDispatcher.OnBackPressedEventInput eventInput_delegate$lambda$0(androidx.activity.OnBackPressedDispatcher r1) {
            androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput r0 = new androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput
            r0.<init>(r1)
            return r0
    }

    private final androidx.activity.OnBackPressedDispatcher.OnBackPressedEventInput getEventInput() {
            r1 = this;
            kotlin.Lazy r0 = r1.eventInput$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput r0 = (androidx.activity.OnBackPressedDispatcher.OnBackPressedEventInput) r0
            return r0
    }

    public final void addCallback(androidx.activity.OnBackPressedCallback r5) {
            r4 = this;
            java.lang.String r0 = "onBackPressedCallback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            androidx.activity.OnBackPressedCallbackInfo r0 = new androidx.activity.OnBackPressedCallbackInfo
            r1 = 0
            r2 = 2
            r0.<init>(r5, r1, r2, r1)
            androidx.navigationevent.NavigationEventInfo r0 = (androidx.navigationevent.NavigationEventInfo) r0
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r5 = r5.createNavigationEventHandler$activity(r0)
            androidx.navigationevent.NavigationEventDispatcher r0 = r4.getEventDispatcher$activity()
            androidx.navigationevent.NavigationEventHandler r5 = (androidx.navigationevent.NavigationEventHandler) r5
            r3 = 0
            androidx.navigationevent.NavigationEventDispatcher.addHandler$default(r0, r5, r3, r2, r1)
            return
    }

    public final void addCallback(androidx.lifecycle.LifecycleOwner r7, androidx.activity.OnBackPressedCallback r8) {
            r6 = this;
            java.lang.String r0 = "owner"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.String r0 = "onBackPressedCallback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            androidx.lifecycle.Lifecycle r0 = r7.getLifecycle()
            androidx.lifecycle.Lifecycle$State r1 = r0.getCurrentState()
            androidx.lifecycle.Lifecycle$State r2 = androidx.lifecycle.Lifecycle.State.DESTROYED
            if (r1 != r2) goto L17
            return
        L17:
            androidx.activity.OnBackPressedCallbackInfo r1 = new androidx.activity.OnBackPressedCallbackInfo
            r1.<init>(r8, r7)
            androidx.navigationevent.NavigationEventInfo r1 = (androidx.navigationevent.NavigationEventInfo) r1
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r7 = r8.createNavigationEventHandler$activity(r1)
            boolean r1 = androidx.activity.ActivityFlags.isOnBackPressedLifecycleOrderMaintained
            if (r1 == 0) goto L36
            r1 = 0
            r7.setLifecycleActive(r1)
            androidx.navigationevent.NavigationEventDispatcher r2 = r6.getEventDispatcher$activity()
            r3 = r7
            androidx.navigationevent.NavigationEventHandler r3 = (androidx.navigationevent.NavigationEventHandler) r3
            r4 = 2
            r5 = 0
            androidx.navigationevent.NavigationEventDispatcher.addHandler$default(r2, r3, r1, r4, r5)
        L36:
            androidx.activity.OnBackPressedDispatcher$addCallback$lifecycleObserver$1 r1 = new androidx.activity.OnBackPressedDispatcher$addCallback$lifecycleObserver$1
            r1.<init>(r7, r6, r0)
            r7 = r1
            androidx.lifecycle.LifecycleObserver r7 = (androidx.lifecycle.LifecycleObserver) r7
            r0.addObserver(r7)
            java.lang.AutoCloseable r1 = (java.lang.AutoCloseable) r1
            r8.addCloseable$activity(r1)
            return
    }

    public final void dispatchOnBackCancelled() {
            r1 = this;
            androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput r0 = r1.getEventInput()
            r0.backCancelled()
            return
    }

    public final void dispatchOnBackProgressed(androidx.activity.BackEventCompat r2) {
            r1 = this;
            java.lang.String r0 = "backEvent"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput r0 = r1.getEventInput()
            androidx.navigationevent.NavigationEvent r2 = r2.toNavigationEvent()
            r0.backProgressed(r2)
            return
    }

    public final void dispatchOnBackStarted(androidx.activity.BackEventCompat r2) {
            r1 = this;
            java.lang.String r0 = "backEvent"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput r0 = r1.getEventInput()
            androidx.navigationevent.NavigationEvent r2 = r2.toNavigationEvent()
            r0.backStarted(r2)
            return
    }

    public final androidx.navigationevent.NavigationEventDispatcher getEventDispatcher$activity() {
            r1 = this;
            androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput r0 = r1.getEventInput()
            androidx.navigationevent.NavigationEventDispatcher r0 = r0.getDispatcher()
            return r0
    }

    public final boolean hasEnabledCallbacks() {
            r1 = this;
            boolean r0 = r1.hasEnabledCallbacks
            return r0
    }

    public final void onBackPressed() {
            r1 = this;
            androidx.activity.OnBackPressedDispatcher$OnBackPressedEventInput r0 = r1.getEventInput()
            r0.backCompleted()
            return
    }

    public final void setOnBackInvokedDispatcher(android.window.OnBackInvokedDispatcher r4) {
            r3 = this;
            java.lang.String r0 = "invoker"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            androidx.navigationevent.NavigationEventDispatcher r0 = r3.getEventDispatcher$activity()
            androidx.navigationevent.OnBackInvokedDefaultInput r1 = new androidx.navigationevent.OnBackInvokedDefaultInput
            r1.<init>(r4)
            androidx.navigationevent.NavigationEventInput r1 = (androidx.navigationevent.NavigationEventInput) r1
            r2 = 1
            r0.addInput(r1, r2)
            androidx.navigationevent.NavigationEventDispatcher r0 = r3.getEventDispatcher$activity()
            androidx.navigationevent.OnBackInvokedOverlayInput r1 = new androidx.navigationevent.OnBackInvokedOverlayInput
            r1.<init>(r4)
            androidx.navigationevent.NavigationEventInput r1 = (androidx.navigationevent.NavigationEventInput) r1
            r4 = 0
            r0.addInput(r1, r4)
            return
    }
}
