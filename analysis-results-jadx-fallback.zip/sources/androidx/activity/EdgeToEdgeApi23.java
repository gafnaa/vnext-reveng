package androidx.activity;

/* JADX INFO: compiled from: EdgeToEdge.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J8\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH\u0017¨\u0006\u0010"}, d2 = {"Landroidx/activity/EdgeToEdgeApi23;", "Landroidx/activity/EdgeToEdgeBase;", "<init>", "()V", "setUp", "", "statusBarStyle", "Landroidx/activity/SystemBarStyle;", "navigationBarStyle", "window", "Landroid/view/Window;", "view", "Landroid/view/View;", "statusBarIsDark", "", "navigationBarIsDark", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class EdgeToEdgeApi23 extends androidx.activity.EdgeToEdgeBase {
    public EdgeToEdgeApi23() {
            r0 = this;
            r0.<init>()
            return
    }

    @Override // androidx.activity.EdgeToEdgeImpl
    public void setUp(androidx.activity.SystemBarStyle r1, androidx.activity.SystemBarStyle r2, android.view.Window r3, android.view.View r4, boolean r5, boolean r6) {
            r0 = this;
            java.lang.String r6 = "statusBarStyle"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r6)
            java.lang.String r6 = "navigationBarStyle"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r6)
            java.lang.String r6 = "window"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r6)
            java.lang.String r6 = "view"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r6)
            r6 = 0
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(r3, r6)
            int r1 = r1.getScrim$activity(r5)
            r3.setStatusBarColor(r1)
            int r1 = r2.getDarkScrim$activity()
            r3.setNavigationBarColor(r1)
            androidx.core.view.WindowInsetsControllerCompat r1 = new androidx.core.view.WindowInsetsControllerCompat
            r1.<init>(r3, r4)
            r2 = r5 ^ 1
            r1.setAppearanceLightStatusBars(r2)
            return
    }
}
