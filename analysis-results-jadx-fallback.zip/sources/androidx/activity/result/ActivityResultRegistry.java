package androidx.activity.result;

/* JADX INFO: compiled from: ActivityResultRegistry.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\u0010\b\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\b&\u0018\u0000 92\u00020\u0001:\u0003789B\u0007¢\u0006\u0004\b\u0002\u0010\u0003JG\u0010\u0012\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u0014\"\u0004\b\u0001\u0010\u00152\u0006\u0010\u0016\u001a\u00020\u00062\u0012\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0014\u0012\u0004\u0012\u0002H\u00150\u00182\u0006\u0010\u0019\u001a\u0002H\u00142\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bH'¢\u0006\u0002\u0010\u001cJJ\u0010\u001d\u001a\b\u0012\u0004\u0012\u0002H\u00140\u001e\"\u0004\b\u0000\u0010\u0014\"\u0004\b\u0001\u0010\u00152\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010 \u001a\u00020!2\u0012\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0014\u0012\u0004\u0012\u0002H\u00150\u00182\f\u0010\"\u001a\b\u0012\u0004\u0012\u0002H\u00150#JB\u0010\u001d\u001a\b\u0012\u0004\u0012\u0002H\u00140\u001e\"\u0004\b\u0000\u0010\u0014\"\u0004\b\u0001\u0010\u00152\u0006\u0010\u001f\u001a\u00020\u00072\u0012\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u0002H\u0014\u0012\u0004\u0012\u0002H\u00150\u00182\f\u0010\"\u001a\b\u0012\u0004\u0012\u0002H\u00150#J\u0015\u0010$\u001a\u00020\u00132\u0006\u0010\u001f\u001a\u00020\u0007H\u0001¢\u0006\u0002\b%J\u000e\u0010&\u001a\u00020\u00132\u0006\u0010'\u001a\u00020\u0011J\u0010\u0010(\u001a\u00020\u00132\b\u0010)\u001a\u0004\u0018\u00010\u0011J\"\u0010*\u001a\u00020+2\u0006\u0010\u0016\u001a\u00020\u00062\u0006\u0010,\u001a\u00020\u00062\b\u0010-\u001a\u0004\u0018\u00010.H\u0007J#\u0010*\u001a\u00020+\"\u0004\b\u0000\u0010\u00152\u0006\u0010\u0016\u001a\u00020\u00062\u0006\u0010/\u001a\u0002H\u0015H\u0007¢\u0006\u0002\u00100J8\u00101\u001a\u00020\u0013\"\u0004\b\u0000\u0010\u00152\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010,\u001a\u00020\u00062\b\u0010-\u001a\u0004\u0018\u00010.2\u000e\u00102\u001a\n\u0012\u0004\u0012\u0002H\u0015\u0018\u00010\u000eH\u0002J\u0010\u00103\u001a\u00020\u00132\u0006\u0010\u001f\u001a\u00020\u0007H\u0002J\b\u00104\u001a\u00020\u0006H\u0002J\u0018\u00105\u001a\u00020\u00132\u0006\u00106\u001a\u00020\u00062\u0006\u0010\u001f\u001a\u00020\u0007H\u0002R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n0\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00070\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\u0007\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u000e0\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001c\u0010\u000f\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006:"}, d2 = {"Landroidx/activity/result/ActivityResultRegistry;", "", "<init>", "()V", "rcToKey", "", "", "", "keyToRc", "keyToLifecycleContainers", "Landroidx/activity/result/ActivityResultRegistry$LifecycleContainer;", "launchedKeys", "", "keyToCallback", "Landroidx/activity/result/ActivityResultRegistry$CallbackAndContract;", "parsedPendingResults", "pendingResults", "Landroid/os/Bundle;", "onLaunch", "", "I", "O", "requestCode", "contract", "Landroidx/activity/result/contract/ActivityResultContract;", "input", "options", "Landroidx/core/app/ActivityOptionsCompat;", "(ILandroidx/activity/result/contract/ActivityResultContract;Ljava/lang/Object;Landroidx/core/app/ActivityOptionsCompat;)V", "register", "Landroidx/activity/result/ActivityResultLauncher;", "key", "lifecycleOwner", "Landroidx/lifecycle/LifecycleOwner;", "callback", "Landroidx/activity/result/ActivityResultCallback;", "unregister", "unregister$activity", "onSaveInstanceState", "outState", "onRestoreInstanceState", "savedInstanceState", "dispatchResult", "", "resultCode", "data", "Landroid/content/Intent;", "result", "(ILjava/lang/Object;)Z", "doDispatch", "callbackAndContract", "registerKey", "generateRandomNumber", "bindRcKey", "rc", "CallbackAndContract", "LifecycleContainer", "Companion", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
public abstract class ActivityResultRegistry {
    private static final androidx.activity.result.ActivityResultRegistry.Companion Companion = null;
    private static final int INITIAL_REQUEST_CODE_VALUE = 65536;
    private static final java.lang.String KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS = "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS";
    private static final java.lang.String KEY_COMPONENT_ACTIVITY_PENDING_RESULTS = "KEY_COMPONENT_ACTIVITY_PENDING_RESULT";
    private static final java.lang.String KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS = "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS";
    private static final java.lang.String KEY_COMPONENT_ACTIVITY_REGISTERED_RCS = "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS";
    private static final java.lang.String LOG_TAG = "ActivityResultRegistry";
    private final transient java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry.CallbackAndContract<?>> keyToCallback;
    private final java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry.LifecycleContainer> keyToLifecycleContainers;
    private final java.util.Map<java.lang.String, java.lang.Integer> keyToRc;
    private final java.util.List<java.lang.String> launchedKeys;
    private final java.util.Map<java.lang.String, java.lang.Object> parsedPendingResults;
    private final android.os.Bundle pendingResults;
    private final java.util.Map<java.lang.Integer, java.lang.String> rcToKey;

    /* JADX INFO: compiled from: ActivityResultRegistry.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002B'\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\u0012\u0010\u0010\u0005\u001a\f\u0012\u0002\b\u0003\u0012\u0004\u0012\u00028\u00000\u0006¢\u0006\u0004\b\u0007\u0010\bR\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u001b\u0010\u0005\u001a\f\u0012\u0002\b\u0003\u0012\u0004\u0012\u00028\u00000\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"Landroidx/activity/result/ActivityResultRegistry$CallbackAndContract;", "O", "", "callback", "Landroidx/activity/result/ActivityResultCallback;", "contract", "Landroidx/activity/result/contract/ActivityResultContract;", "<init>", "(Landroidx/activity/result/ActivityResultCallback;Landroidx/activity/result/contract/ActivityResultContract;)V", "getCallback", "()Landroidx/activity/result/ActivityResultCallback;", "getContract", "()Landroidx/activity/result/contract/ActivityResultContract;", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
    private static final class CallbackAndContract<O> {
        private final androidx.activity.result.ActivityResultCallback<O> callback;
        private final androidx.activity.result.contract.ActivityResultContract<?, O> contract;

        public CallbackAndContract(androidx.activity.result.ActivityResultCallback<O> r2, androidx.activity.result.contract.ActivityResultContract<?, O> r3) {
                r1 = this;
                java.lang.String r0 = "callback"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "contract"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                r1.<init>()
                r1.callback = r2
                r1.contract = r3
                return
        }

        public final androidx.activity.result.ActivityResultCallback<O> getCallback() {
                r1 = this;
                androidx.activity.result.ActivityResultCallback<O> r0 = r1.callback
                return r0
        }

        public final androidx.activity.result.contract.ActivityResultContract<?, O> getContract() {
                r1 = this;
                androidx.activity.result.contract.ActivityResultContract<?, O> r0 = r1.contract
                return r0
        }
    }

    /* JADX INFO: compiled from: ActivityResultRegistry.kt */
    @kotlin.Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\b\n\u0000\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Landroidx/activity/result/ActivityResultRegistry$Companion;", "", "<init>", "()V", "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", "", "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", "KEY_COMPONENT_ACTIVITY_PENDING_RESULTS", "LOG_TAG", "INITIAL_REQUEST_CODE_VALUE", "", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
    private static final class Companion {
        private Companion() {
                r0 = this;
                r0.<init>()
                return
        }

        public /* synthetic */ Companion(kotlin.jvm.internal.DefaultConstructorMarker r1) {
                r0 = this;
                r0.<init>()
                return
        }
    }

    /* JADX INFO: compiled from: ActivityResultRegistry.kt */
    @kotlin.Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0002\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\nJ\u0006\u0010\u000e\u001a\u00020\fR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000f"}, d2 = {"Landroidx/activity/result/ActivityResultRegistry$LifecycleContainer;", "", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "<init>", "(Landroidx/lifecycle/Lifecycle;)V", "getLifecycle", "()Landroidx/lifecycle/Lifecycle;", "observers", "", "Landroidx/lifecycle/LifecycleEventObserver;", "addObserver", "", "observer", "clearObservers", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
    private static final class LifecycleContainer {
        private final androidx.lifecycle.Lifecycle lifecycle;
        private final java.util.List<androidx.lifecycle.LifecycleEventObserver> observers;

        public LifecycleContainer(androidx.lifecycle.Lifecycle r2) {
                r1 = this;
                java.lang.String r0 = "lifecycle"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                r1.<init>()
                r1.lifecycle = r2
                java.util.ArrayList r2 = new java.util.ArrayList
                r2.<init>()
                java.util.List r2 = (java.util.List) r2
                r1.observers = r2
                return
        }

        public final void addObserver(androidx.lifecycle.LifecycleEventObserver r3) {
                r2 = this;
                java.lang.String r0 = "observer"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                androidx.lifecycle.Lifecycle r0 = r2.lifecycle
                r1 = r3
                androidx.lifecycle.LifecycleObserver r1 = (androidx.lifecycle.LifecycleObserver) r1
                r0.addObserver(r1)
                java.util.List<androidx.lifecycle.LifecycleEventObserver> r0 = r2.observers
                r0.add(r3)
                return
        }

        public final void clearObservers() {
                r3 = this;
                java.util.List<androidx.lifecycle.LifecycleEventObserver> r0 = r3.observers
                java.lang.Iterable r0 = (java.lang.Iterable) r0
                java.util.Iterator r0 = r0.iterator()
            L8:
                boolean r1 = r0.hasNext()
                if (r1 == 0) goto L1c
                java.lang.Object r1 = r0.next()
                androidx.lifecycle.LifecycleEventObserver r1 = (androidx.lifecycle.LifecycleEventObserver) r1
                androidx.lifecycle.Lifecycle r2 = r3.lifecycle
                androidx.lifecycle.LifecycleObserver r1 = (androidx.lifecycle.LifecycleObserver) r1
                r2.removeObserver(r1)
                goto L8
            L1c:
                java.util.List<androidx.lifecycle.LifecycleEventObserver> r0 = r3.observers
                r0.clear()
                return
        }

        public final androidx.lifecycle.Lifecycle getLifecycle() {
                r1 = this;
                androidx.lifecycle.Lifecycle r0 = r1.lifecycle
                return r0
        }
    }



    /* JADX INFO: renamed from: $r8$lambda$-f_tNvtP3uEenATo3uzHmjDoXwg, reason: not valid java name */
    public static /* synthetic */ java.lang.Integer m50$r8$lambda$f_tNvtP3uEenATo3uzHmjDoXwg() {
            java.lang.Integer r0 = generateRandomNumber$lambda$0()
            return r0
    }

    /* JADX INFO: renamed from: $r8$lambda$TWvtyPFk-iHdx0R-btWVLevVLT0, reason: not valid java name */
    public static /* synthetic */ void m51$r8$lambda$TWvtyPFkiHdx0RbtWVLevVLT0(androidx.activity.result.ActivityResultRegistry r0, java.lang.String r1, androidx.activity.result.ActivityResultCallback r2, androidx.activity.result.contract.ActivityResultContract r3, androidx.lifecycle.LifecycleOwner r4, androidx.lifecycle.Lifecycle.Event r5) {
            register$lambda$1(r0, r1, r2, r3, r4, r5)
            return
    }

    static {
            androidx.activity.result.ActivityResultRegistry$Companion r0 = new androidx.activity.result.ActivityResultRegistry$Companion
            r1 = 0
            r0.<init>(r1)
            androidx.activity.result.ActivityResultRegistry.Companion = r0
            return
    }

    public ActivityResultRegistry() {
            r1 = this;
            r1.<init>()
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            r1.rcToKey = r0
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            r1.keyToRc = r0
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            r1.keyToLifecycleContainers = r0
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            r1.launchedKeys = r0
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            r1.keyToCallback = r0
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            java.util.Map r0 = (java.util.Map) r0
            r1.parsedPendingResults = r0
            android.os.Bundle r0 = new android.os.Bundle
            r0.<init>()
            r1.pendingResults = r0
            return
    }

    public static final /* synthetic */ java.util.Map access$getKeyToRc$p(androidx.activity.result.ActivityResultRegistry r0) {
            java.util.Map<java.lang.String, java.lang.Integer> r0 = r0.keyToRc
            return r0
    }

    public static final /* synthetic */ java.util.List access$getLaunchedKeys$p(androidx.activity.result.ActivityResultRegistry r0) {
            java.util.List<java.lang.String> r0 = r0.launchedKeys
            return r0
    }

    private final void bindRcKey(int r3, java.lang.String r4) {
            r2 = this;
            java.util.Map<java.lang.Integer, java.lang.String> r0 = r2.rcToKey
            java.lang.Integer r1 = java.lang.Integer.valueOf(r3)
            r0.put(r1, r4)
            java.util.Map<java.lang.String, java.lang.Integer> r0 = r2.keyToRc
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r0.put(r4, r3)
            return
    }

    private final <O> void doDispatch(java.lang.String r2, int r3, android.content.Intent r4, androidx.activity.result.ActivityResultRegistry.CallbackAndContract<O> r5) {
            r1 = this;
            if (r5 == 0) goto L7
            androidx.activity.result.ActivityResultCallback r0 = r5.getCallback()
            goto L8
        L7:
            r0 = 0
        L8:
            if (r0 == 0) goto L27
            java.util.List<java.lang.String> r0 = r1.launchedKeys
            boolean r0 = r0.contains(r2)
            if (r0 == 0) goto L27
            androidx.activity.result.ActivityResultCallback r0 = r5.getCallback()
            androidx.activity.result.contract.ActivityResultContract r5 = r5.getContract()
            java.lang.Object r3 = r5.parseResult(r3, r4)
            r0.onActivityResult(r3)
            java.util.List<java.lang.String> r3 = r1.launchedKeys
            r3.remove(r2)
            return
        L27:
            java.util.Map<java.lang.String, java.lang.Object> r5 = r1.parsedPendingResults
            r5.remove(r2)
            android.os.Bundle r5 = r1.pendingResults
            androidx.activity.result.ActivityResult r0 = new androidx.activity.result.ActivityResult
            r0.<init>(r3, r4)
            android.os.Parcelable r0 = (android.os.Parcelable) r0
            r5.putParcelable(r2, r0)
            return
    }

    private final int generateRandomNumber() {
            r4 = this;
            androidx.activity.result.ActivityResultRegistry$$ExternalSyntheticLambda1 r0 = new androidx.activity.result.ActivityResultRegistry$$ExternalSyntheticLambda1
            r0.<init>()
            kotlin.sequences.Sequence r0 = kotlin.sequences.SequencesKt.generateSequence(r0)
            java.util.Iterator r0 = r0.iterator()
        Ld:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L2e
            java.lang.Object r1 = r0.next()
            java.lang.Number r1 = (java.lang.Number) r1
            int r2 = r1.intValue()
            java.util.Map<java.lang.Integer, java.lang.String> r3 = r4.rcToKey
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            boolean r2 = r3.containsKey(r2)
            if (r2 != 0) goto Ld
            int r0 = r1.intValue()
            return r0
        L2e:
            java.util.NoSuchElementException r0 = new java.util.NoSuchElementException
            java.lang.String r1 = "Sequence contains no element matching the predicate."
            r0.<init>(r1)
            throw r0
    }

    private static final java.lang.Integer generateRandomNumber$lambda$0() {
            kotlin.random.Random$Default r0 = kotlin.random.Random.Default
            r1 = 2147418112(0x7fff0000, float:NaN)
            int r0 = r0.nextInt(r1)
            r1 = 65536(0x10000, float:9.1835E-41)
            int r0 = r0 + r1
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            return r0
    }

    private static final void register$lambda$1(androidx.activity.result.ActivityResultRegistry r1, java.lang.String r2, androidx.activity.result.ActivityResultCallback r3, androidx.activity.result.contract.ActivityResultContract r4, androidx.lifecycle.LifecycleOwner r5, androidx.lifecycle.Lifecycle.Event r6) {
            java.lang.String r0 = "<unused var>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r5 = "event"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r5)
            androidx.lifecycle.Lifecycle$Event r5 = androidx.lifecycle.Lifecycle.Event.ON_START
            if (r5 != r6) goto L4f
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$CallbackAndContract<?>> r5 = r1.keyToCallback
            androidx.activity.result.ActivityResultRegistry$CallbackAndContract r6 = new androidx.activity.result.ActivityResultRegistry$CallbackAndContract
            r6.<init>(r3, r4)
            r5.put(r2, r6)
            java.util.Map<java.lang.String, java.lang.Object> r5 = r1.parsedPendingResults
            boolean r5 = r5.containsKey(r2)
            if (r5 == 0) goto L2e
            java.util.Map<java.lang.String, java.lang.Object> r5 = r1.parsedPendingResults
            java.lang.Object r5 = r5.get(r2)
            java.util.Map<java.lang.String, java.lang.Object> r6 = r1.parsedPendingResults
            r6.remove(r2)
            r3.onActivityResult(r5)
        L2e:
            android.os.Bundle r5 = r1.pendingResults
            java.lang.Class<androidx.activity.result.ActivityResult> r6 = androidx.activity.result.ActivityResult.class
            java.lang.Object r5 = androidx.core.os.BundleCompat.getParcelable(r5, r2, r6)
            androidx.activity.result.ActivityResult r5 = (androidx.activity.result.ActivityResult) r5
            if (r5 == 0) goto L60
            android.os.Bundle r1 = r1.pendingResults
            r1.remove(r2)
            int r1 = r5.getResultCode()
            android.content.Intent r2 = r5.getData()
            java.lang.Object r1 = r4.parseResult(r1, r2)
            r3.onActivityResult(r1)
            return
        L4f:
            androidx.lifecycle.Lifecycle$Event r3 = androidx.lifecycle.Lifecycle.Event.ON_STOP
            if (r3 != r6) goto L59
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$CallbackAndContract<?>> r1 = r1.keyToCallback
            r1.remove(r2)
            return
        L59:
            androidx.lifecycle.Lifecycle$Event r3 = androidx.lifecycle.Lifecycle.Event.ON_DESTROY
            if (r3 != r6) goto L60
            r1.unregister$activity(r2)
        L60:
            return
    }

    private final void registerKey(java.lang.String r2) {
            r1 = this;
            java.util.Map<java.lang.String, java.lang.Integer> r0 = r1.keyToRc
            java.lang.Object r0 = r0.get(r2)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 == 0) goto Lb
            return
        Lb:
            int r0 = r1.generateRandomNumber()
            r1.bindRcKey(r0, r2)
            return
    }

    public final boolean dispatchResult(int r2, int r3, android.content.Intent r4) {
            r1 = this;
            java.util.Map<java.lang.Integer, java.lang.String> r0 = r1.rcToKey
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            java.lang.Object r2 = r0.get(r2)
            java.lang.String r2 = (java.lang.String) r2
            if (r2 != 0) goto L10
            r2 = 0
            return r2
        L10:
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$CallbackAndContract<?>> r0 = r1.keyToCallback
            java.lang.Object r0 = r0.get(r2)
            androidx.activity.result.ActivityResultRegistry$CallbackAndContract r0 = (androidx.activity.result.ActivityResultRegistry.CallbackAndContract) r0
            r1.doDispatch(r2, r3, r4, r0)
            r2 = 1
            return r2
    }

    public final <O> boolean dispatchResult(int r3, O r4) {
            r2 = this;
            java.util.Map<java.lang.Integer, java.lang.String> r0 = r2.rcToKey
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            java.lang.Object r3 = r0.get(r3)
            java.lang.String r3 = (java.lang.String) r3
            if (r3 != 0) goto L10
            r3 = 0
            return r3
        L10:
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$CallbackAndContract<?>> r0 = r2.keyToCallback
            java.lang.Object r0 = r0.get(r3)
            androidx.activity.result.ActivityResultRegistry$CallbackAndContract r0 = (androidx.activity.result.ActivityResultRegistry.CallbackAndContract) r0
            if (r0 == 0) goto L1f
            androidx.activity.result.ActivityResultCallback r1 = r0.getCallback()
            goto L20
        L1f:
            r1 = 0
        L20:
            if (r1 != 0) goto L2d
            android.os.Bundle r0 = r2.pendingResults
            r0.remove(r3)
            java.util.Map<java.lang.String, java.lang.Object> r0 = r2.parsedPendingResults
            r0.put(r3, r4)
            goto L41
        L2d:
            androidx.activity.result.ActivityResultCallback r0 = r0.getCallback()
            java.lang.String r1 = "null cannot be cast to non-null type androidx.activity.result.ActivityResultCallback<O of androidx.activity.result.ActivityResultRegistry.dispatchResult>"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0, r1)
            java.util.List<java.lang.String> r1 = r2.launchedKeys
            boolean r3 = r1.remove(r3)
            if (r3 == 0) goto L41
            r0.onActivityResult(r4)
        L41:
            r3 = 1
            return r3
    }

    public abstract <I, O> void onLaunch(int r1, androidx.activity.result.contract.ActivityResultContract<I, O> r2, I r3, androidx.core.app.ActivityOptionsCompat r4);

    public final void onRestoreInstanceState(android.os.Bundle r7) {
            r6 = this;
            if (r7 != 0) goto L4
            goto L80
        L4:
            java.lang.String r0 = "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS"
            java.util.ArrayList r0 = r7.getIntegerArrayList(r0)
            java.lang.String r1 = "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS"
            java.util.ArrayList r1 = r7.getStringArrayList(r1)
            if (r1 == 0) goto L80
            if (r0 != 0) goto L15
            goto L80
        L15:
            java.lang.String r2 = "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS"
            java.util.ArrayList r2 = r7.getStringArrayList(r2)
            if (r2 == 0) goto L24
            java.util.List<java.lang.String> r3 = r6.launchedKeys
            java.util.Collection r2 = (java.util.Collection) r2
            r3.addAll(r2)
        L24:
            java.lang.String r2 = "KEY_COMPONENT_ACTIVITY_PENDING_RESULT"
            android.os.Bundle r7 = r7.getBundle(r2)
            if (r7 == 0) goto L31
            android.os.Bundle r2 = r6.pendingResults
            r2.putAll(r7)
        L31:
            r7 = r1
            java.util.Collection r7 = (java.util.Collection) r7
            int r7 = r7.size()
            r2 = 0
        L39:
            if (r2 >= r7) goto L80
            java.lang.Object r3 = r1.get(r2)
            java.lang.String r3 = (java.lang.String) r3
            java.util.Map<java.lang.String, java.lang.Integer> r4 = r6.keyToRc
            boolean r4 = r4.containsKey(r3)
            if (r4 == 0) goto L62
            java.util.Map<java.lang.String, java.lang.Integer> r4 = r6.keyToRc
            java.lang.Object r4 = r4.remove(r3)
            java.lang.Integer r4 = (java.lang.Integer) r4
            android.os.Bundle r5 = r6.pendingResults
            boolean r3 = r5.containsKey(r3)
            if (r3 != 0) goto L62
            java.util.Map<java.lang.Integer, java.lang.String> r3 = r6.rcToKey
            java.util.Map r3 = kotlin.jvm.internal.TypeIntrinsics.asMutableMap(r3)
            r3.remove(r4)
        L62:
            java.lang.Object r3 = r0.get(r2)
            java.lang.String r4 = "get(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r3, r4)
            java.lang.Number r3 = (java.lang.Number) r3
            int r3 = r3.intValue()
            java.lang.Object r5 = r1.get(r2)
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r5, r4)
            java.lang.String r5 = (java.lang.String) r5
            r6.bindRcKey(r3, r5)
            int r2 = r2 + 1
            goto L39
        L80:
            return
    }

    public final void onSaveInstanceState(android.os.Bundle r3) {
            r2 = this;
            java.lang.String r0 = "outState"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.util.ArrayList r0 = new java.util.ArrayList
            java.util.Map<java.lang.String, java.lang.Integer> r1 = r2.keyToRc
            java.util.Collection r1 = r1.values()
            r0.<init>(r1)
            java.lang.String r1 = "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS"
            r3.putIntegerArrayList(r1, r0)
            java.util.ArrayList r0 = new java.util.ArrayList
            java.util.Map<java.lang.String, java.lang.Integer> r1 = r2.keyToRc
            java.util.Set r1 = r1.keySet()
            java.util.Collection r1 = (java.util.Collection) r1
            r0.<init>(r1)
            java.lang.String r1 = "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS"
            r3.putStringArrayList(r1, r0)
            java.util.ArrayList r0 = new java.util.ArrayList
            java.util.List<java.lang.String> r1 = r2.launchedKeys
            java.util.Collection r1 = (java.util.Collection) r1
            r0.<init>(r1)
            java.lang.String r1 = "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS"
            r3.putStringArrayList(r1, r0)
            android.os.Bundle r0 = new android.os.Bundle
            android.os.Bundle r1 = r2.pendingResults
            r0.<init>(r1)
            java.lang.String r1 = "KEY_COMPONENT_ACTIVITY_PENDING_RESULT"
            r3.putBundle(r1, r0)
            return
    }

    public final <I, O> androidx.activity.result.ActivityResultLauncher<I> register(java.lang.String r3, androidx.activity.result.contract.ActivityResultContract<I, O> r4, androidx.activity.result.ActivityResultCallback<O> r5) {
            r2 = this;
            java.lang.String r0 = "key"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            java.lang.String r0 = "contract"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "callback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            r2.registerKey(r3)
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$CallbackAndContract<?>> r0 = r2.keyToCallback
            androidx.activity.result.ActivityResultRegistry$CallbackAndContract r1 = new androidx.activity.result.ActivityResultRegistry$CallbackAndContract
            r1.<init>(r5, r4)
            r0.put(r3, r1)
            java.util.Map<java.lang.String, java.lang.Object> r0 = r2.parsedPendingResults
            boolean r0 = r0.containsKey(r3)
            if (r0 == 0) goto L32
            java.util.Map<java.lang.String, java.lang.Object> r0 = r2.parsedPendingResults
            java.lang.Object r0 = r0.get(r3)
            java.util.Map<java.lang.String, java.lang.Object> r1 = r2.parsedPendingResults
            r1.remove(r3)
            r5.onActivityResult(r0)
        L32:
            android.os.Bundle r0 = r2.pendingResults
            java.lang.Class<androidx.activity.result.ActivityResult> r1 = androidx.activity.result.ActivityResult.class
            java.lang.Object r0 = androidx.core.os.BundleCompat.getParcelable(r0, r3, r1)
            androidx.activity.result.ActivityResult r0 = (androidx.activity.result.ActivityResult) r0
            if (r0 == 0) goto L52
            android.os.Bundle r1 = r2.pendingResults
            r1.remove(r3)
            int r1 = r0.getResultCode()
            android.content.Intent r0 = r0.getData()
            java.lang.Object r0 = r4.parseResult(r1, r0)
            r5.onActivityResult(r0)
        L52:
            androidx.activity.result.ActivityResultRegistry$register$3 r5 = new androidx.activity.result.ActivityResultRegistry$register$3
            r5.<init>(r2, r3, r4)
            androidx.activity.result.ActivityResultLauncher r5 = (androidx.activity.result.ActivityResultLauncher) r5
            return r5
    }

    public final <I, O> androidx.activity.result.ActivityResultLauncher<I> register(java.lang.String r4, androidx.lifecycle.LifecycleOwner r5, androidx.activity.result.contract.ActivityResultContract<I, O> r6, androidx.activity.result.ActivityResultCallback<O> r7) {
            r3 = this;
            java.lang.String r0 = "key"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            java.lang.String r0 = "lifecycleOwner"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r0 = "contract"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.lang.String r0 = "callback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            androidx.lifecycle.Lifecycle r0 = r5.getLifecycle()
            androidx.lifecycle.Lifecycle$State r1 = r0.getCurrentState()
            androidx.lifecycle.Lifecycle$State r2 = androidx.lifecycle.Lifecycle.State.STARTED
            boolean r1 = r1.isAtLeast(r2)
            if (r1 != 0) goto L4b
            r3.registerKey(r4)
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$LifecycleContainer> r5 = r3.keyToLifecycleContainers
            java.lang.Object r5 = r5.get(r4)
            androidx.activity.result.ActivityResultRegistry$LifecycleContainer r5 = (androidx.activity.result.ActivityResultRegistry.LifecycleContainer) r5
            if (r5 != 0) goto L36
            androidx.activity.result.ActivityResultRegistry$LifecycleContainer r5 = new androidx.activity.result.ActivityResultRegistry$LifecycleContainer
            r5.<init>(r0)
        L36:
            androidx.activity.result.ActivityResultRegistry$$ExternalSyntheticLambda0 r0 = new androidx.activity.result.ActivityResultRegistry$$ExternalSyntheticLambda0
            r0.<init>(r3, r4, r7, r6)
            r5.addObserver(r0)
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$LifecycleContainer> r7 = r3.keyToLifecycleContainers
            r7.put(r4, r5)
            androidx.activity.result.ActivityResultRegistry$register$2 r5 = new androidx.activity.result.ActivityResultRegistry$register$2
            r5.<init>(r3, r4, r6)
            androidx.activity.result.ActivityResultLauncher r5 = (androidx.activity.result.ActivityResultLauncher) r5
            return r5
        L4b:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            java.lang.String r6 = "LifecycleOwner "
            r4.<init>(r6)
            r4.append(r5)
            java.lang.String r5 = " is attempting to register while current state is "
            r4.append(r5)
            androidx.lifecycle.Lifecycle$State r5 = r0.getCurrentState()
            r4.append(r5)
            java.lang.String r5 = ". LifecycleOwners must call register before they are STARTED."
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r4 = r4.toString()
            r5.<init>(r4)
            throw r5
    }

    public final void unregister$activity(java.lang.String r6) {
            r5 = this;
            java.lang.String r0 = "key"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r0)
            java.util.List<java.lang.String> r0 = r5.launchedKeys
            boolean r0 = r0.contains(r6)
            if (r0 != 0) goto L1c
            java.util.Map<java.lang.String, java.lang.Integer> r0 = r5.keyToRc
            java.lang.Object r0 = r0.remove(r6)
            java.lang.Integer r0 = (java.lang.Integer) r0
            if (r0 == 0) goto L1c
            java.util.Map<java.lang.Integer, java.lang.String> r1 = r5.rcToKey
            r1.remove(r0)
        L1c:
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$CallbackAndContract<?>> r0 = r5.keyToCallback
            r0.remove(r6)
            java.util.Map<java.lang.String, java.lang.Object> r0 = r5.parsedPendingResults
            boolean r0 = r0.containsKey(r6)
            java.lang.String r1 = ": "
            java.lang.String r2 = "Dropping pending result for request "
            java.lang.String r3 = "ActivityResultRegistry"
            if (r0 == 0) goto L4f
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>(r2)
            r0.append(r6)
            r0.append(r1)
            java.util.Map<java.lang.String, java.lang.Object> r4 = r5.parsedPendingResults
            java.lang.Object r4 = r4.get(r6)
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            android.util.Log.w(r3, r0)
            java.util.Map<java.lang.String, java.lang.Object> r0 = r5.parsedPendingResults
            r0.remove(r6)
        L4f:
            android.os.Bundle r0 = r5.pendingResults
            boolean r0 = r0.containsKey(r6)
            if (r0 == 0) goto L7b
            android.os.Bundle r0 = r5.pendingResults
            java.lang.Class<androidx.activity.result.ActivityResult> r4 = androidx.activity.result.ActivityResult.class
            java.lang.Object r0 = androidx.core.os.BundleCompat.getParcelable(r0, r6, r4)
            androidx.activity.result.ActivityResult r0 = (androidx.activity.result.ActivityResult) r0
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>(r2)
            r4.append(r6)
            r4.append(r1)
            r4.append(r0)
            java.lang.String r0 = r4.toString()
            android.util.Log.w(r3, r0)
            android.os.Bundle r0 = r5.pendingResults
            r0.remove(r6)
        L7b:
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$LifecycleContainer> r0 = r5.keyToLifecycleContainers
            java.lang.Object r0 = r0.get(r6)
            androidx.activity.result.ActivityResultRegistry$LifecycleContainer r0 = (androidx.activity.result.ActivityResultRegistry.LifecycleContainer) r0
            if (r0 == 0) goto L8d
            r0.clearObservers()
            java.util.Map<java.lang.String, androidx.activity.result.ActivityResultRegistry$LifecycleContainer> r0 = r5.keyToLifecycleContainers
            r0.remove(r6)
        L8d:
            return
    }
}
