package androidx.activity;

/* JADX INFO: compiled from: EdgeToEdge.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J8\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH\u0017¨\u0006\u0010"}, d2 = {"Landroidx/activity/EdgeToEdgeApi35;", "Landroidx/activity/EdgeToEdgeApi30;", "<init>", "()V", "setUp", "", "statusBarStyle", "Landroidx/activity/SystemBarStyle;", "navigationBarStyle", "window", "Landroid/view/Window;", "view", "Landroid/view/View;", "statusBarIsDark", "", "navigationBarIsDark", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class EdgeToEdgeApi35 extends androidx.activity.EdgeToEdgeApi30 {
    public EdgeToEdgeApi35() {
            r0 = this;
            r0.<init>()
            return
    }

    @Override // androidx.activity.EdgeToEdgeApi29, androidx.activity.EdgeToEdgeApi26, androidx.activity.EdgeToEdgeImpl
    public void setUp(androidx.activity.SystemBarStyle r17, androidx.activity.SystemBarStyle r18, android.view.Window r19, android.view.View r20, boolean r21, boolean r22) {
            r16 = this;
            r0 = r17
            r1 = r18
            r2 = r19
            r3 = r20
            r4 = r21
            r5 = r22
            java.lang.String r6 = "statusBarStyle"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r0, r6)
            java.lang.String r6 = "navigationBarStyle"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r1, r6)
            java.lang.String r6 = "window"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r6)
            java.lang.String r6 = "view"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r6)
            r6 = 0
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(r2, r6)
            android.view.WindowManager$LayoutParams r7 = r2.getAttributes()
            int r8 = r7.flags
            r8 = r8 & 256(0x100, float:3.59E-43)
            r9 = 1
            if (r8 != 0) goto L38
            int r8 = r7.width
            r10 = -2
            if (r8 != r10) goto L38
            int r7 = r7.height
            if (r7 == r10) goto L7e
        L38:
            r2.setStatusBarColor(r6)
            r2.setNavigationBarColor(r6)
            int r0 = r0.getScrimWithEnforcedContrast$activity(r4)
            int r7 = r1.getScrimWithEnforcedContrast$activity(r5)
            r8 = r3
            android.view.ViewGroup r8 = (android.view.ViewGroup) r8
            androidx.core.view.insets.ProtectionLayout r10 = new androidx.core.view.insets.ProtectionLayout
            android.content.Context r11 = r8.getContext()
            r12 = 4
            androidx.core.view.insets.ColorProtection[] r13 = new androidx.core.view.insets.ColorProtection[r12]
            androidx.core.view.insets.ColorProtection r14 = new androidx.core.view.insets.ColorProtection
            r15 = 2
            r14.<init>(r15, r0)
            r13[r6] = r14
            androidx.core.view.insets.ColorProtection r0 = new androidx.core.view.insets.ColorProtection
            r0.<init>(r9, r7)
            r13[r9] = r0
            androidx.core.view.insets.ColorProtection r0 = new androidx.core.view.insets.ColorProtection
            r0.<init>(r12, r7)
            r13[r15] = r0
            androidx.core.view.insets.ColorProtection r0 = new androidx.core.view.insets.ColorProtection
            r12 = 8
            r0.<init>(r12, r7)
            r7 = 3
            r13[r7] = r0
            java.util.List r0 = kotlin.collections.CollectionsKt.listOf(r13)
            r10.<init>(r11, r0)
            android.view.View r10 = (android.view.View) r10
            r8.addView(r10)
        L7e:
            int r0 = r1.getNightMode$activity()
            if (r0 != 0) goto L85
            r6 = r9
        L85:
            androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m$1(r2, r6)
            androidx.core.view.WindowInsetsControllerCompat r0 = new androidx.core.view.WindowInsetsControllerCompat
            r0.<init>(r2, r3)
            r1 = r4 ^ 1
            r0.setAppearanceLightStatusBars(r1)
            r1 = r5 ^ 1
            r0.setAppearanceLightNavigationBars(r1)
            return
    }
}
