package androidx.activity;

/* JADX INFO: compiled from: OnBackPressedCallback.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0003\b&\u0018\u00002\u00020\u0001:\u0001\"B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0011\u001a\u00020\u0012H\u0007J\u0010\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u0015H\u0017J\u0010\u0010\u0016\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u0015H\u0017J\b\u0010\u0017\u001a\u00020\u0012H'J\b\u0010\u0018\u001a\u00020\u0012H\u0017J\u0019\u0010\u0019\u001a\u00020\u00122\n\u0010\u001a\u001a\u00060\u000fj\u0002`\u0010H\u0000¢\u0006\u0002\b\u001bJ\u0019\u0010\u001c\u001a\u00020\u00122\n\u0010\u001a\u001a\u00060\u000fj\u0002`\u0010H\u0000¢\u0006\u0002\b\u001dJ\u0015\u0010\u001e\u001a\u00020\b2\u0006\u0010\u001f\u001a\u00020 H\u0000¢\u0006\u0002\b!R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R&\u0010\n\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\u00038\u0007@GX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\u0005R\u0018\u0010\r\u001a\f\u0012\b\u0012\u00060\u000fj\u0002`\u00100\u000eX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006#"}, d2 = {"Landroidx/activity/OnBackPressedCallback;", "", "enabled", "", "<init>", "(Z)V", "eventHandlers", "", "Landroidx/activity/OnBackPressedCallback$OnBackPressedEventHandler;", "value", "isEnabled", "()Z", "setEnabled", "closeables", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Ljava/lang/AutoCloseable;", "Lkotlin/AutoCloseable;", "remove", "", "handleOnBackStarted", "backEvent", "Landroidx/activity/BackEventCompat;", "handleOnBackProgressed", "handleOnBackPressed", "handleOnBackCancelled", "addCloseable", "closeable", "addCloseable$activity", "removeCloseable", "removeCloseable$activity", "createNavigationEventHandler", "info", "Landroidx/navigationevent/NavigationEventInfo;", "createNavigationEventHandler$activity", "OnBackPressedEventHandler", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
public abstract class OnBackPressedCallback {
    private final java.util.concurrent.CopyOnWriteArrayList<java.lang.AutoCloseable> closeables;
    private final java.util.List<androidx.activity.OnBackPressedCallback.OnBackPressedEventHandler> eventHandlers;
    private boolean isEnabled;

    /* JADX INFO: compiled from: OnBackPressedCallback.kt */
    @kotlin.Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0014J\u0010\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0014J\b\u0010\u0013\u001a\u00020\u000fH\u0014J\b\u0010\u0014\u001a\u00020\u000fH\u0014R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R$\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\t@FX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\r¨\u0006\u0015"}, d2 = {"Landroidx/activity/OnBackPressedCallback$OnBackPressedEventHandler;", "Landroidx/navigationevent/NavigationEventHandler;", "Landroidx/navigationevent/NavigationEventInfo;", "onBackPressedCallback", "Landroidx/activity/OnBackPressedCallback;", "info", "<init>", "(Landroidx/activity/OnBackPressedCallback;Landroidx/navigationevent/NavigationEventInfo;)V", "value", "", "isLifecycleActive", "()Z", "setLifecycleActive", "(Z)V", "onBackStarted", "", "event", "Landroidx/navigationevent/NavigationEvent;", "onBackProgressed", "onBackCompleted", "onBackCancelled", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class OnBackPressedEventHandler extends androidx.navigationevent.NavigationEventHandler<androidx.navigationevent.NavigationEventInfo> {
        private boolean isLifecycleActive;
        private final androidx.activity.OnBackPressedCallback onBackPressedCallback;

        public OnBackPressedEventHandler(androidx.activity.OnBackPressedCallback r2, androidx.navigationevent.NavigationEventInfo r3) {
                r1 = this;
                java.lang.String r0 = "onBackPressedCallback"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
                java.lang.String r0 = "info"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                boolean r0 = r2.isEnabled()
                r1.<init>(r3, r0)
                r1.onBackPressedCallback = r2
                r2 = 1
                r1.isLifecycleActive = r2
                return
        }

        public final boolean isLifecycleActive() {
                r1 = this;
                boolean r0 = r1.isLifecycleActive
                return r0
        }

        @Override // androidx.navigationevent.NavigationEventHandler
        protected void onBackCancelled() {
                r1 = this;
                androidx.activity.OnBackPressedCallback r0 = r1.onBackPressedCallback
                r0.handleOnBackCancelled()
                return
        }

        @Override // androidx.navigationevent.NavigationEventHandler
        protected void onBackCompleted() {
                r1 = this;
                androidx.activity.OnBackPressedCallback r0 = r1.onBackPressedCallback
                r0.handleOnBackPressed()
                return
        }

        @Override // androidx.navigationevent.NavigationEventHandler
        protected void onBackProgressed(androidx.navigationevent.NavigationEvent r3) {
                r2 = this;
                java.lang.String r0 = "event"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                androidx.activity.OnBackPressedCallback r0 = r2.onBackPressedCallback
                androidx.activity.BackEventCompat r1 = new androidx.activity.BackEventCompat
                r1.<init>(r3)
                r0.handleOnBackProgressed(r1)
                return
        }

        @Override // androidx.navigationevent.NavigationEventHandler
        protected void onBackStarted(androidx.navigationevent.NavigationEvent r3) {
                r2 = this;
                java.lang.String r0 = "event"
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
                androidx.activity.OnBackPressedCallback r0 = r2.onBackPressedCallback
                androidx.activity.BackEventCompat r1 = new androidx.activity.BackEventCompat
                r1.<init>(r3)
                r0.handleOnBackStarted(r1)
                return
        }

        public final void setLifecycleActive(boolean r1) {
                r0 = this;
                r0.isLifecycleActive = r1
                if (r1 == 0) goto Le
                androidx.activity.OnBackPressedCallback r1 = r0.onBackPressedCallback
                boolean r1 = r1.isEnabled()
                if (r1 == 0) goto Le
                r1 = 1
                goto Lf
            Le:
                r1 = 0
            Lf:
                r0.setBackEnabled(r1)
                return
        }
    }

    public OnBackPressedCallback(boolean r2) {
            r1 = this;
            r1.<init>()
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.List r0 = (java.util.List) r0
            r1.eventHandlers = r0
            r1.isEnabled = r2
            java.util.concurrent.CopyOnWriteArrayList r2 = new java.util.concurrent.CopyOnWriteArrayList
            r2.<init>()
            r1.closeables = r2
            return
    }

    public final void addCloseable$activity(java.lang.AutoCloseable r2) {
            r1 = this;
            java.lang.String r0 = "closeable"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.util.concurrent.CopyOnWriteArrayList<java.lang.AutoCloseable> r0 = r1.closeables
            java.util.Collection r0 = (java.util.Collection) r0
            r0.add(r2)
            return
    }

    public final androidx.activity.OnBackPressedCallback.OnBackPressedEventHandler createNavigationEventHandler$activity(androidx.navigationevent.NavigationEventInfo r2) {
            r1 = this;
            java.lang.String r0 = "info"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r0 = new androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler
            r0.<init>(r1, r2)
            java.util.List<androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler> r2 = r1.eventHandlers
            java.util.Collection r2 = (java.util.Collection) r2
            r2.add(r0)
            return r0
    }

    public void handleOnBackCancelled() {
            r0 = this;
            return
    }

    public abstract void handleOnBackPressed();

    public void handleOnBackProgressed(androidx.activity.BackEventCompat r2) {
            r1 = this;
            java.lang.String r0 = "backEvent"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            return
    }

    public void handleOnBackStarted(androidx.activity.BackEventCompat r2) {
            r1 = this;
            java.lang.String r0 = "backEvent"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            return
    }

    public final boolean isEnabled() {
            r1 = this;
            boolean r0 = r1.isEnabled
            return r0
    }

    public final void remove() {
            r2 = this;
            java.util.concurrent.CopyOnWriteArrayList<java.lang.AutoCloseable> r0 = r2.closeables
            java.util.Iterator r0 = r0.iterator()
            java.lang.String r1 = "iterator(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
        Lb:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L1b
            java.lang.Object r1 = r0.next()
            java.lang.AutoCloseable r1 = (java.lang.AutoCloseable) r1
            kotlin.UByte$$ExternalSyntheticBackport0.m2255m(r1)
            goto Lb
        L1b:
            java.util.concurrent.CopyOnWriteArrayList<java.lang.AutoCloseable> r0 = r2.closeables
            r0.clear()
            java.util.List<androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler> r0 = r2.eventHandlers
            java.util.Iterator r0 = r0.iterator()
        L26:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L36
            java.lang.Object r1 = r0.next()
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r1 = (androidx.activity.OnBackPressedCallback.OnBackPressedEventHandler) r1
            r1.remove()
            goto L26
        L36:
            java.util.List<androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler> r0 = r2.eventHandlers
            r0.clear()
            return
    }

    public final void removeCloseable$activity(java.lang.AutoCloseable r2) {
            r1 = this;
            java.lang.String r0 = "closeable"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.util.concurrent.CopyOnWriteArrayList<java.lang.AutoCloseable> r0 = r1.closeables
            java.util.Collection r0 = (java.util.Collection) r0
            r0.remove(r2)
            return
    }

    public final void setEnabled(boolean r4) {
            r3 = this;
            r3.isEnabled = r4
            java.util.List<androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler> r0 = r3.eventHandlers
            java.util.Iterator r0 = r0.iterator()
        L8:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L23
            java.lang.Object r1 = r0.next()
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r1 = (androidx.activity.OnBackPressedCallback.OnBackPressedEventHandler) r1
            boolean r2 = r1.isLifecycleActive()
            if (r2 == 0) goto L1e
            if (r4 == 0) goto L1e
            r2 = 1
            goto L1f
        L1e:
            r2 = 0
        L1f:
            r1.setBackEnabled(r2)
            goto L8
        L23:
            return
    }
}
