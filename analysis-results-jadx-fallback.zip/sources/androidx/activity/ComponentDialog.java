package androidx.activity;

/* JADX INFO: compiled from: ComponentDialog.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0016\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u00042\u00020\u0005B\u001b\b\u0007\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0003\u0010\b\u001a\u00020\t¢\u0006\u0004\b\n\u0010\u000bJ\b\u0010!\u001a\u00020\"H\u0016J\u0012\u0010#\u001a\u00020$2\b\u0010%\u001a\u0004\u0018\u00010\"H\u0015J\b\u0010&\u001a\u00020$H\u0015J\b\u0010'\u001a\u00020$H\u0015J\b\u00103\u001a\u00020$H\u0017J\u0010\u00104\u001a\u00020$2\u0006\u00105\u001a\u00020\tH\u0016J\u0010\u00104\u001a\u00020$2\u0006\u00106\u001a\u000207H\u0016J\u001a\u00104\u001a\u00020$2\u0006\u00106\u001a\u0002072\b\u00108\u001a\u0004\u0018\u000109H\u0016J\u001a\u0010:\u001a\u00020$2\u0006\u00106\u001a\u0002072\b\u00108\u001a\u0004\u0018\u000109H\u0016J\b\u0010;\u001a\u00020$H\u0017R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\u00020\r8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0013\u001a\u00020\u00148VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016R\u0014\u0010\u0017\u001a\u00020\u00188VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u001aR\u001b\u0010\u001b\u001a\u00020\u001c8BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001f\u0010 \u001a\u0004\b\u001d\u0010\u001eR!\u0010(\u001a\u00020)8FX\u0086\u0084\u0002¢\u0006\u0012\n\u0004\b.\u0010 \u0012\u0004\b*\u0010+\u001a\u0004\b,\u0010-R\u0014\u0010/\u001a\u0002008VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b1\u00102¨\u0006<"}, d2 = {"Landroidx/activity/ComponentDialog;", "Landroid/app/Dialog;", "Landroidx/lifecycle/LifecycleOwner;", "Landroidx/activity/OnBackPressedDispatcherOwner;", "Landroidx/navigationevent/NavigationEventDispatcherOwner;", "Landroidx/savedstate/SavedStateRegistryOwner;", "context", "Landroid/content/Context;", "themeResId", "", "<init>", "(Landroid/content/Context;I)V", "_lifecycleRegistry", "Landroidx/lifecycle/LifecycleRegistry;", "lifecycleRegistry", "getLifecycleRegistry", "()Landroidx/lifecycle/LifecycleRegistry;", "savedStateRegistryController", "Landroidx/savedstate/SavedStateRegistryController;", "savedStateRegistry", "Landroidx/savedstate/SavedStateRegistry;", "getSavedStateRegistry", "()Landroidx/savedstate/SavedStateRegistry;", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "getLifecycle", "()Landroidx/lifecycle/Lifecycle;", "onBackPressedInput", "Landroidx/navigationevent/DirectNavigationEventInput;", "getOnBackPressedInput", "()Landroidx/navigationevent/DirectNavigationEventInput;", "onBackPressedInput$delegate", "Lkotlin/Lazy;", "onSaveInstanceState", "Landroid/os/Bundle;", "onCreate", "", "savedInstanceState", "onStart", "onStop", "onBackPressedDispatcher", "Landroidx/activity/OnBackPressedDispatcher;", "getOnBackPressedDispatcher$annotations", "()V", "getOnBackPressedDispatcher", "()Landroidx/activity/OnBackPressedDispatcher;", "onBackPressedDispatcher$delegate", "navigationEventDispatcher", "Landroidx/navigationevent/NavigationEventDispatcher;", "getNavigationEventDispatcher", "()Landroidx/navigationevent/NavigationEventDispatcher;", "onBackPressed", "setContentView", "layoutResID", "view", "Landroid/view/View;", "params", "Landroid/view/ViewGroup$LayoutParams;", "addContentView", "initializeViewTreeOwners", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
public class ComponentDialog extends android.app.Dialog implements androidx.lifecycle.LifecycleOwner, androidx.activity.OnBackPressedDispatcherOwner, androidx.navigationevent.NavigationEventDispatcherOwner, androidx.savedstate.SavedStateRegistryOwner {
    private androidx.lifecycle.LifecycleRegistry _lifecycleRegistry;
    private final kotlin.Lazy onBackPressedDispatcher$delegate;
    private final kotlin.Lazy onBackPressedInput$delegate;
    private final androidx.savedstate.SavedStateRegistryController savedStateRegistryController;

    public static /* synthetic */ androidx.navigationevent.DirectNavigationEventInput $r8$lambda$50PeDeOZ7xBZFvhmt63acaX0YUk(androidx.activity.ComponentDialog r0) {
            androidx.navigationevent.DirectNavigationEventInput r0 = onBackPressedInput_delegate$lambda$0(r0)
            return r0
    }

    public static /* synthetic */ void $r8$lambda$XxpmZzi8FNPM2sJJA30VCt2mBcQ(androidx.activity.ComponentDialog r0) {
            onBackPressedDispatcher_delegate$lambda$0$0(r0)
            return
    }

    public static /* synthetic */ androidx.activity.OnBackPressedDispatcher $r8$lambda$qS1cldBgQdRb0InzIVn5XXJnx0Q(androidx.activity.ComponentDialog r0) {
            androidx.activity.OnBackPressedDispatcher r0 = onBackPressedDispatcher_delegate$lambda$0(r0)
            return r0
    }

    public ComponentDialog(android.content.Context r4) {
            r3 = this;
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            r0 = 2
            r1 = 0
            r2 = 0
            r3.<init>(r4, r2, r0, r1)
            return
    }

    public ComponentDialog(android.content.Context r2, int r3) {
            r1 = this;
            java.lang.String r0 = "context"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>(r2, r3)
            androidx.savedstate.SavedStateRegistryController$Companion r2 = androidx.savedstate.SavedStateRegistryController.Companion
            r3 = r1
            androidx.savedstate.SavedStateRegistryOwner r3 = (androidx.savedstate.SavedStateRegistryOwner) r3
            androidx.savedstate.SavedStateRegistryController r2 = r2.create(r3)
            r1.savedStateRegistryController = r2
            androidx.activity.ComponentDialog$$ExternalSyntheticLambda2 r2 = new androidx.activity.ComponentDialog$$ExternalSyntheticLambda2
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.onBackPressedInput$delegate = r2
            androidx.activity.ComponentDialog$$ExternalSyntheticLambda3 r2 = new androidx.activity.ComponentDialog$$ExternalSyntheticLambda3
            r2.<init>(r1)
            kotlin.Lazy r2 = kotlin.LazyKt.lazy(r2)
            r1.onBackPressedDispatcher$delegate = r2
            return
    }

    public /* synthetic */ ComponentDialog(android.content.Context r1, int r2, int r3, kotlin.jvm.internal.DefaultConstructorMarker r4) {
            r0 = this;
            r3 = r3 & 2
            if (r3 == 0) goto L5
            r2 = 0
        L5:
            r0.<init>(r1, r2)
            return
    }

    private final androidx.lifecycle.LifecycleRegistry getLifecycleRegistry() {
            r2 = this;
            androidx.lifecycle.LifecycleRegistry r0 = r2._lifecycleRegistry
            if (r0 != 0) goto Le
            androidx.lifecycle.LifecycleRegistry r0 = new androidx.lifecycle.LifecycleRegistry
            r1 = r2
            androidx.lifecycle.LifecycleOwner r1 = (androidx.lifecycle.LifecycleOwner) r1
            r0.<init>(r1)
            r2._lifecycleRegistry = r0
        Le:
            return r0
    }

    public static /* synthetic */ void getOnBackPressedDispatcher$annotations() {
            return
    }

    private final androidx.navigationevent.DirectNavigationEventInput getOnBackPressedInput() {
            r1 = this;
            kotlin.Lazy r0 = r1.onBackPressedInput$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.navigationevent.DirectNavigationEventInput r0 = (androidx.navigationevent.DirectNavigationEventInput) r0
            return r0
    }

    private static final androidx.activity.OnBackPressedDispatcher onBackPressedDispatcher_delegate$lambda$0(androidx.activity.ComponentDialog r2) {
            androidx.activity.OnBackPressedDispatcher r0 = new androidx.activity.OnBackPressedDispatcher
            androidx.activity.ComponentDialog$$ExternalSyntheticLambda1 r1 = new androidx.activity.ComponentDialog$$ExternalSyntheticLambda1
            r1.<init>(r2)
            r0.<init>(r1)
            return r0
    }

    private static final void onBackPressedDispatcher_delegate$lambda$0$0(androidx.activity.ComponentDialog r0) {
            super.onBackPressed()
            return
    }

    private static final androidx.navigationevent.DirectNavigationEventInput onBackPressedInput_delegate$lambda$0(androidx.activity.ComponentDialog r2) {
            androidx.navigationevent.DirectNavigationEventInput r0 = new androidx.navigationevent.DirectNavigationEventInput
            r0.<init>()
            androidx.navigationevent.NavigationEventDispatcher r2 = r2.getNavigationEventDispatcher()
            r1 = r0
            androidx.navigationevent.NavigationEventInput r1 = (androidx.navigationevent.NavigationEventInput) r1
            r2.addInput(r1)
            return r0
    }

    @Override // android.app.Dialog
    public void addContentView(android.view.View r2, android.view.ViewGroup.LayoutParams r3) {
            r1 = this;
            java.lang.String r0 = "view"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.initializeViewTreeOwners()
            super.addContentView(r2, r3)
            return
    }

    @Override // androidx.lifecycle.LifecycleOwner
    public androidx.lifecycle.Lifecycle getLifecycle() {
            r1 = this;
            androidx.lifecycle.LifecycleRegistry r0 = r1.getLifecycleRegistry()
            androidx.lifecycle.Lifecycle r0 = (androidx.lifecycle.Lifecycle) r0
            return r0
    }

    @Override // androidx.navigationevent.NavigationEventDispatcherOwner
    public androidx.navigationevent.NavigationEventDispatcher getNavigationEventDispatcher() {
            r1 = this;
            androidx.activity.OnBackPressedDispatcher r0 = r1.getOnBackPressedDispatcher()
            androidx.navigationevent.NavigationEventDispatcher r0 = r0.getEventDispatcher$activity()
            return r0
    }

    @Override // androidx.activity.OnBackPressedDispatcherOwner
    public final androidx.activity.OnBackPressedDispatcher getOnBackPressedDispatcher() {
            r1 = this;
            kotlin.Lazy r0 = r1.onBackPressedDispatcher$delegate
            java.lang.Object r0 = r0.getValue()
            androidx.activity.OnBackPressedDispatcher r0 = (androidx.activity.OnBackPressedDispatcher) r0
            return r0
    }

    @Override // androidx.savedstate.SavedStateRegistryOwner
    public androidx.savedstate.SavedStateRegistry getSavedStateRegistry() {
            r1 = this;
            androidx.savedstate.SavedStateRegistryController r0 = r1.savedStateRegistryController
            androidx.savedstate.SavedStateRegistry r0 = r0.getSavedStateRegistry()
            return r0
    }

    public void initializeViewTreeOwners() {
            r3 = this;
            android.view.Window r0 = r3.getWindow()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            android.view.View r0 = r0.getDecorView()
            java.lang.String r1 = "getDecorView(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r2 = r3
            androidx.lifecycle.LifecycleOwner r2 = (androidx.lifecycle.LifecycleOwner) r2
            androidx.lifecycle.ViewTreeLifecycleOwner.set(r0, r2)
            android.view.Window r0 = r3.getWindow()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            android.view.View r0 = r0.getDecorView()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r2 = r3
            androidx.activity.OnBackPressedDispatcherOwner r2 = (androidx.activity.OnBackPressedDispatcherOwner) r2
            androidx.activity.ViewTreeOnBackPressedDispatcherOwner.set(r0, r2)
            android.view.Window r0 = r3.getWindow()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            android.view.View r0 = r0.getDecorView()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r2 = r3
            androidx.savedstate.SavedStateRegistryOwner r2 = (androidx.savedstate.SavedStateRegistryOwner) r2
            androidx.savedstate.ViewTreeSavedStateRegistryOwner.set(r0, r2)
            android.view.Window r0 = r3.getWindow()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0)
            android.view.View r0 = r0.getDecorView()
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            r1 = r3
            androidx.navigationevent.NavigationEventDispatcherOwner r1 = (androidx.navigationevent.NavigationEventDispatcherOwner) r1
            androidx.navigationevent.ViewTreeNavigationEventDispatcherOwner.set(r0, r1)
            return
    }

    @Override // android.app.Dialog
    @kotlin.Deprecated(message = "This method has been deprecated in favor of using the\n      {@link OnBackPressedDispatcher} via {@link #getOnBackPressedDispatcher()}.\n      The OnBackPressedDispatcher controls how back button events are dispatched\n      to one or more {@link OnBackPressedCallback} objects.")
    public void onBackPressed() {
            r1 = this;
            androidx.navigationevent.DirectNavigationEventInput r0 = r1.getOnBackPressedInput()
            r0.backCompleted()
            return
    }

    @Override // android.app.Dialog
    protected void onCreate(android.os.Bundle r4) {
            r3 = this;
            super.onCreate(r4)
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 33
            if (r0 < r1) goto L19
            androidx.activity.OnBackPressedDispatcher r0 = r3.getOnBackPressedDispatcher()
            android.window.OnBackInvokedDispatcher r1 = androidx.activity.BackEventCompat$$ExternalSyntheticApiModelOutline0.m(r3)
            java.lang.String r2 = "getOnBackInvokedDispatcher(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r1, r2)
            r0.setOnBackInvokedDispatcher(r1)
        L19:
            androidx.savedstate.SavedStateRegistryController r0 = r3.savedStateRegistryController
            r0.performRestore(r4)
            androidx.lifecycle.LifecycleRegistry r4 = r3.getLifecycleRegistry()
            androidx.lifecycle.Lifecycle$Event r0 = androidx.lifecycle.Lifecycle.Event.ON_CREATE
            r4.handleLifecycleEvent(r0)
            return
    }

    @Override // android.app.Dialog
    public android.os.Bundle onSaveInstanceState() {
            r2 = this;
            android.os.Bundle r0 = super.onSaveInstanceState()
            java.lang.String r1 = "onSaveInstanceState(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
            androidx.savedstate.SavedStateRegistryController r1 = r2.savedStateRegistryController
            r1.performSave(r0)
            return r0
    }

    @Override // android.app.Dialog
    protected void onStart() {
            r2 = this;
            super.onStart()
            androidx.lifecycle.LifecycleRegistry r0 = r2.getLifecycleRegistry()
            androidx.lifecycle.Lifecycle$Event r1 = androidx.lifecycle.Lifecycle.Event.ON_RESUME
            r0.handleLifecycleEvent(r1)
            return
    }

    @Override // android.app.Dialog
    protected void onStop() {
            r2 = this;
            androidx.lifecycle.LifecycleRegistry r0 = r2.getLifecycleRegistry()
            androidx.lifecycle.Lifecycle$Event r1 = androidx.lifecycle.Lifecycle.Event.ON_DESTROY
            r0.handleLifecycleEvent(r1)
            r0 = 0
            r2._lifecycleRegistry = r0
            super.onStop()
            return
    }

    @Override // android.app.Dialog
    public void setContentView(int r1) {
            r0 = this;
            r0.initializeViewTreeOwners()
            super.setContentView(r1)
            return
    }

    @Override // android.app.Dialog
    public void setContentView(android.view.View r2) {
            r1 = this;
            java.lang.String r0 = "view"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.initializeViewTreeOwners()
            super.setContentView(r2)
            return
    }

    @Override // android.app.Dialog
    public void setContentView(android.view.View r2, android.view.ViewGroup.LayoutParams r3) {
            r1 = this;
            java.lang.String r0 = "view"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.initializeViewTreeOwners()
            super.setContentView(r2, r3)
            return
    }
}
