package androidx.activity;

/* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000'\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u00012\u00060\u0002j\u0002`\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0016J\b\u0010\n\u001a\u00020\u0005H\u0016¨\u0006\u000b"}, d2 = {"androidx/activity/OnBackPressedDispatcher$addCallback$lifecycleObserver$1", "Landroidx/lifecycle/LifecycleEventObserver;", "Ljava/lang/AutoCloseable;", "Lkotlin/AutoCloseable;", "onStateChanged", "", "source", "Landroidx/lifecycle/LifecycleOwner;", "event", "Landroidx/lifecycle/Lifecycle$Event;", "close", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class OnBackPressedDispatcher$addCallback$lifecycleObserver$1 implements androidx.lifecycle.LifecycleEventObserver, java.lang.AutoCloseable {
    final /* synthetic */ androidx.activity.OnBackPressedCallback.OnBackPressedEventHandler $eventHandler;
    final /* synthetic */ androidx.lifecycle.Lifecycle $lifecycle;
    final /* synthetic */ androidx.activity.OnBackPressedDispatcher this$0;

    OnBackPressedDispatcher$addCallback$lifecycleObserver$1(androidx.activity.OnBackPressedCallback.OnBackPressedEventHandler r1, androidx.activity.OnBackPressedDispatcher r2, androidx.lifecycle.Lifecycle r3) {
            r0 = this;
            r0.$eventHandler = r1
            r0.this$0 = r2
            r0.$lifecycle = r3
            r0.<init>()
            return
    }

    @Override // java.lang.AutoCloseable
    public void close() {
            r2 = this;
            androidx.lifecycle.Lifecycle r0 = r2.$lifecycle
            r1 = r2
            androidx.lifecycle.LifecycleObserver r1 = (androidx.lifecycle.LifecycleObserver) r1
            r0.removeObserver(r1)
            return
    }

    @Override // androidx.lifecycle.LifecycleEventObserver
    public void onStateChanged(androidx.lifecycle.LifecycleOwner r5, androidx.lifecycle.Lifecycle.Event r6) {
            r4 = this;
            java.lang.String r0 = "source"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r0)
            java.lang.String r5 = "event"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r6, r5)
            boolean r5 = androidx.activity.ActivityFlags.isOnBackPressedLifecycleOrderMaintained
            r0 = 0
            if (r5 == 0) goto L24
            androidx.lifecycle.Lifecycle$Event r5 = androidx.lifecycle.Lifecycle.Event.ON_START
            if (r6 != r5) goto L1a
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r5 = r4.$eventHandler
            r0 = 1
            r5.setLifecycleActive(r0)
            goto L41
        L1a:
            androidx.lifecycle.Lifecycle$Event r5 = androidx.lifecycle.Lifecycle.Event.ON_STOP
            if (r6 != r5) goto L41
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r5 = r4.$eventHandler
            r5.setLifecycleActive(r0)
            goto L41
        L24:
            androidx.lifecycle.Lifecycle$Event r5 = androidx.lifecycle.Lifecycle.Event.ON_START
            if (r6 != r5) goto L38
            androidx.activity.OnBackPressedDispatcher r5 = r4.this$0
            androidx.navigationevent.NavigationEventDispatcher r5 = r5.getEventDispatcher$activity()
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r1 = r4.$eventHandler
            androidx.navigationevent.NavigationEventHandler r1 = (androidx.navigationevent.NavigationEventHandler) r1
            r2 = 2
            r3 = 0
            androidx.navigationevent.NavigationEventDispatcher.addHandler$default(r5, r1, r0, r2, r3)
            goto L41
        L38:
            androidx.lifecycle.Lifecycle$Event r5 = androidx.lifecycle.Lifecycle.Event.ON_STOP
            if (r6 != r5) goto L41
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r5 = r4.$eventHandler
            r5.remove()
        L41:
            androidx.lifecycle.Lifecycle$Event r5 = androidx.lifecycle.Lifecycle.Event.ON_DESTROY
            if (r6 != r5) goto L52
            androidx.activity.OnBackPressedCallback$OnBackPressedEventHandler r5 = r4.$eventHandler
            r5.remove()
            androidx.lifecycle.Lifecycle r5 = r4.$lifecycle
            r6 = r4
            androidx.lifecycle.LifecycleObserver r6 = (androidx.lifecycle.LifecycleObserver) r6
            r5.removeObserver(r6)
        L52:
            return
    }
}
