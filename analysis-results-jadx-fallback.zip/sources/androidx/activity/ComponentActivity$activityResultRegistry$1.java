package androidx.activity;

/* JADX INFO: compiled from: ComponentActivity.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000)\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002*\u0001\u0000\b\n\u0018\u00002\u00020\u0001JG\u0010\u0002\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u0004\"\u0004\b\u0001\u0010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u0002H\u0004\u0012\u0004\u0012\u0002H\u00050\t2\u0006\u0010\n\u001a\u0002H\u00042\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016¢\u0006\u0002\u0010\r¨\u0006\u000e"}, d2 = {"androidx/activity/ComponentActivity$activityResultRegistry$1", "Landroidx/activity/result/ActivityResultRegistry;", "onLaunch", "", "I", "O", "requestCode", "", "contract", "Landroidx/activity/result/contract/ActivityResultContract;", "input", "options", "Landroidx/core/app/ActivityOptionsCompat;", "(ILandroidx/activity/result/contract/ActivityResultContract;Ljava/lang/Object;Landroidx/core/app/ActivityOptionsCompat;)V", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class ComponentActivity$activityResultRegistry$1 extends androidx.activity.result.ActivityResultRegistry {
    final /* synthetic */ androidx.activity.ComponentActivity this$0;

    /* JADX INFO: renamed from: $r8$lambda$GPRYQhThGKvRdyPr7x-fDY1xENA, reason: not valid java name */
    public static /* synthetic */ void m46$r8$lambda$GPRYQhThGKvRdyPr7xfDY1xENA(androidx.activity.ComponentActivity$activityResultRegistry$1 r0, int r1, android.content.IntentSender.SendIntentException r2) {
            onLaunch$lambda$1(r0, r1, r2)
            return
    }

    public static /* synthetic */ void $r8$lambda$Gga0ztmPNYcZ2Poj0VEtDPu4ouA(androidx.activity.ComponentActivity$activityResultRegistry$1 r0, int r1, androidx.activity.result.contract.ActivityResultContract.SynchronousResult r2) {
            onLaunch$lambda$0(r0, r1, r2)
            return
    }

    ComponentActivity$activityResultRegistry$1(androidx.activity.ComponentActivity r1) {
            r0 = this;
            r0.this$0 = r1
            r0.<init>()
            return
    }

    private static final void onLaunch$lambda$0(androidx.activity.ComponentActivity$activityResultRegistry$1 r0, int r1, androidx.activity.result.contract.ActivityResultContract.SynchronousResult r2) {
            java.lang.Object r2 = r2.getValue()
            r0.dispatchResult(r1, r2)
            return
    }

    private static final void onLaunch$lambda$1(androidx.activity.ComponentActivity$activityResultRegistry$1 r2, int r3, android.content.IntentSender.SendIntentException r4) {
            android.content.Intent r0 = new android.content.Intent
            r0.<init>()
            java.lang.String r1 = "androidx.activity.result.contract.action.INTENT_SENDER_REQUEST"
            android.content.Intent r0 = r0.setAction(r1)
            java.lang.String r1 = "androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION"
            java.io.Serializable r4 = (java.io.Serializable) r4
            android.content.Intent r4 = r0.putExtra(r1, r4)
            r0 = 0
            r2.dispatchResult(r3, r0, r4)
            return
    }

    @Override // androidx.activity.result.ActivityResultRegistry
    public <I, O> void onLaunch(int r10, androidx.activity.result.contract.ActivityResultContract<I, O> r11, I r12, androidx.core.app.ActivityOptionsCompat r13) {
            r9 = this;
            java.lang.String r0 = "contract"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            androidx.activity.ComponentActivity r0 = r9.this$0
            r1 = r0
            android.content.Context r1 = (android.content.Context) r1
            androidx.activity.result.contract.ActivityResultContract$SynchronousResult r2 = r11.getSynchronousResult(r1, r12)
            if (r2 == 0) goto L22
            android.os.Handler r11 = new android.os.Handler
            android.os.Looper r12 = android.os.Looper.getMainLooper()
            r11.<init>(r12)
            androidx.activity.ComponentActivity$activityResultRegistry$1$$ExternalSyntheticLambda0 r12 = new androidx.activity.ComponentActivity$activityResultRegistry$1$$ExternalSyntheticLambda0
            r12.<init>(r9, r10, r2)
            r11.post(r12)
            return
        L22:
            android.content.Intent r11 = r11.createIntent(r1, r12)
            android.os.Bundle r12 = r11.getExtras()
            if (r12 == 0) goto L40
            android.os.Bundle r12 = r11.getExtras()
            kotlin.jvm.internal.Intrinsics.checkNotNull(r12)
            java.lang.ClassLoader r12 = r12.getClassLoader()
            if (r12 != 0) goto L40
            java.lang.ClassLoader r12 = r0.getClassLoader()
            r11.setExtrasClassLoader(r12)
        L40:
            java.lang.String r12 = "androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE"
            boolean r1 = r11.hasExtra(r12)
            if (r1 == 0) goto L50
            android.os.Bundle r13 = r11.getBundleExtra(r12)
            r11.removeExtra(r12)
            goto L58
        L50:
            if (r13 == 0) goto L57
            android.os.Bundle r13 = r13.toBundle()
            goto L58
        L57:
            r13 = 0
        L58:
            r8 = r13
            java.lang.String r12 = "androidx.activity.result.contract.action.REQUEST_PERMISSIONS"
            java.lang.String r13 = r11.getAction()
            boolean r12 = kotlin.jvm.internal.Intrinsics.areEqual(r12, r13)
            if (r12 == 0) goto L76
            java.lang.String r12 = "androidx.activity.result.contract.extra.PERMISSIONS"
            java.lang.String[] r11 = r11.getStringArrayExtra(r12)
            if (r11 != 0) goto L70
            r11 = 0
            java.lang.String[] r11 = new java.lang.String[r11]
        L70:
            android.app.Activity r0 = (android.app.Activity) r0
            androidx.core.app.ActivityCompat.requestPermissions(r0, r11, r10)
            return
        L76:
            java.lang.String r12 = "androidx.activity.result.contract.action.INTENT_SENDER_REQUEST"
            java.lang.String r13 = r11.getAction()
            boolean r12 = kotlin.jvm.internal.Intrinsics.areEqual(r12, r13)
            if (r12 == 0) goto Lc3
            java.lang.String r12 = "androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST"
            android.os.Parcelable r11 = r11.getParcelableExtra(r12)
            androidx.activity.result.IntentSenderRequest r11 = (androidx.activity.result.IntentSenderRequest) r11
            r1 = r0
            android.app.Activity r1 = (android.app.Activity) r1     // Catch: android.content.IntentSender.SendIntentException -> Laa
            kotlin.jvm.internal.Intrinsics.checkNotNull(r11)     // Catch: android.content.IntentSender.SendIntentException -> Laa
            android.content.IntentSender r2 = r11.getIntentSender()     // Catch: android.content.IntentSender.SendIntentException -> Laa
            android.content.Intent r4 = r11.getFillInIntent()     // Catch: android.content.IntentSender.SendIntentException -> Laa
            int r5 = r11.getFlagsMask()     // Catch: android.content.IntentSender.SendIntentException -> Laa
            int r6 = r11.getFlagsValues()     // Catch: android.content.IntentSender.SendIntentException -> Laa
            r7 = 0
            r3 = r10
            androidx.core.app.ActivityCompat.startIntentSenderForResult(r1, r2, r3, r4, r5, r6, r7, r8)     // Catch: android.content.IntentSender.SendIntentException -> La8
            kotlin.Unit r10 = kotlin.Unit.INSTANCE     // Catch: android.content.IntentSender.SendIntentException -> La8
            return
        La8:
            r0 = move-exception
            goto Lac
        Laa:
            r0 = move-exception
            r3 = r10
        Lac:
            r10 = r0
            android.os.Handler r11 = new android.os.Handler
            android.os.Looper r12 = android.os.Looper.getMainLooper()
            r11.<init>(r12)
            androidx.activity.ComponentActivity$activityResultRegistry$1$$ExternalSyntheticLambda1 r12 = new androidx.activity.ComponentActivity$activityResultRegistry$1$$ExternalSyntheticLambda1
            r12.<init>(r9, r3, r10)
            boolean r10 = r11.post(r12)
            java.lang.Boolean.valueOf(r10)
            return
        Lc3:
            r3 = r10
            android.app.Activity r0 = (android.app.Activity) r0
            androidx.core.app.ActivityCompat.startActivityForResult(r0, r11, r3, r8)
            return
    }
}
