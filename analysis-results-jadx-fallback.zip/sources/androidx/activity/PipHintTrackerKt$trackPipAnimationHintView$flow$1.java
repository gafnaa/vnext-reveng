package androidx.activity;

/* JADX INFO: compiled from: PipHintTracker.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\b\u0012\u0004\u0012\u00020\u00030\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/channels/ProducerScope;", "Landroid/graphics/Rect;"}, k = 3, mv = {2, 0, 0}, xi = 48)
@kotlin.coroutines.jvm.internal.DebugMetadata(c = "androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1", f = "PipHintTracker.kt", i = {}, l = {86}, m = "invokeSuspend", n = {}, s = {}, v = 1)
final class PipHintTrackerKt$trackPipAnimationHintView$flow$1 extends kotlin.coroutines.jvm.internal.SuspendLambda implements kotlin.jvm.functions.Function2<kotlinx.coroutines.channels.ProducerScope<? super android.graphics.Rect>, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> {
    final /* synthetic */ android.view.View $view;
    private /* synthetic */ java.lang.Object L$0;
    int label;

    public static /* synthetic */ void $r8$lambda$EzNCIbjtfjz3Ar8jZpBbve6Davg(kotlinx.coroutines.channels.ProducerScope r0, android.view.View r1, int r2, int r3, int r4, int r5, int r6, int r7, int r8, int r9) {
            invokeSuspend$lambda$0(r0, r1, r2, r3, r4, r5, r6, r7, r8, r9)
            return
    }

    public static /* synthetic */ kotlin.Unit $r8$lambda$JlDmmAtrK939XIgV9x1wNcsCteM(android.view.View r0, android.view.ViewTreeObserver.OnScrollChangedListener r1, android.view.View.OnLayoutChangeListener r2, androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 r3) {
            kotlin.Unit r0 = invokeSuspend$lambda$2(r0, r1, r2, r3)
            return r0
    }

    public static /* synthetic */ void $r8$lambda$noXGr5XZ6ZQiw0NE_bFNhh3sxIQ(kotlinx.coroutines.channels.ProducerScope r0, android.view.View r1) {
            invokeSuspend$lambda$1(r0, r1)
            return
    }

    PipHintTrackerKt$trackPipAnimationHintView$flow$1(android.view.View r1, kotlin.coroutines.Continuation<? super androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1> r2) {
            r0 = this;
            r0.$view = r1
            r1 = 2
            r0.<init>(r1, r2)
            return
    }

    private static final void invokeSuspend$lambda$0(kotlinx.coroutines.channels.ProducerScope r0, android.view.View r1, int r2, int r3, int r4, int r5, int r6, int r7, int r8, int r9) {
            if (r2 != r6) goto La
            if (r4 != r8) goto La
            if (r3 != r7) goto La
            if (r5 == r9) goto L9
            goto La
        L9:
            return
        La:
            kotlin.jvm.internal.Intrinsics.checkNotNull(r1)
            android.graphics.Rect r1 = androidx.activity.PipHintTrackerKt.access$trackPipAnimationHintView$positionInWindow(r1)
            r0.mo3736trySendJP2dKIU(r1)
            return
    }

    private static final void invokeSuspend$lambda$1(kotlinx.coroutines.channels.ProducerScope r0, android.view.View r1) {
            android.graphics.Rect r1 = androidx.activity.PipHintTrackerKt.access$trackPipAnimationHintView$positionInWindow(r1)
            r0.mo3736trySendJP2dKIU(r1)
            return
    }

    private static final kotlin.Unit invokeSuspend$lambda$2(android.view.View r1, android.view.ViewTreeObserver.OnScrollChangedListener r2, android.view.View.OnLayoutChangeListener r3, androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 r4) {
            android.view.ViewTreeObserver r0 = r1.getViewTreeObserver()
            r0.removeOnScrollChangedListener(r2)
            r1.removeOnLayoutChangeListener(r3)
            android.view.View$OnAttachStateChangeListener r4 = (android.view.View.OnAttachStateChangeListener) r4
            r1.removeOnAttachStateChangeListener(r4)
            kotlin.Unit r1 = kotlin.Unit.INSTANCE
            return r1
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final kotlin.coroutines.Continuation<kotlin.Unit> create(java.lang.Object r3, kotlin.coroutines.Continuation<?> r4) {
            r2 = this;
            androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1 r0 = new androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1
            android.view.View r1 = r2.$view
            r0.<init>(r1, r4)
            r0.L$0 = r3
            kotlin.coroutines.Continuation r0 = (kotlin.coroutines.Continuation) r0
            return r0
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ java.lang.Object invoke(kotlinx.coroutines.channels.ProducerScope<? super android.graphics.Rect> r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
            r0 = this;
            kotlinx.coroutines.channels.ProducerScope r1 = (kotlinx.coroutines.channels.ProducerScope) r1
            kotlin.coroutines.Continuation r2 = (kotlin.coroutines.Continuation) r2
            java.lang.Object r1 = r0.invoke2(r1, r2)
            return r1
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final java.lang.Object invoke2(kotlinx.coroutines.channels.ProducerScope<? super android.graphics.Rect> r1, kotlin.coroutines.Continuation<? super kotlin.Unit> r2) {
            r0 = this;
            kotlin.coroutines.Continuation r1 = r0.create(r1, r2)
            androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1 r1 = (androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1) r1
            kotlin.Unit r2 = kotlin.Unit.INSTANCE
            java.lang.Object r1 = r1.invokeSuspend(r2)
            return r1
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final java.lang.Object invokeSuspend(java.lang.Object r8) {
            r7 = this;
            java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r1 = r7.label
            r2 = 1
            if (r1 == 0) goto L17
            if (r1 != r2) goto Lf
            kotlin.ResultKt.throwOnFailure(r8)
            goto L6b
        Lf:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L17:
            kotlin.ResultKt.throwOnFailure(r8)
            java.lang.Object r8 = r7.L$0
            kotlinx.coroutines.channels.ProducerScope r8 = (kotlinx.coroutines.channels.ProducerScope) r8
            androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda0 r1 = new androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda0
            r1.<init>(r8)
            android.view.View r3 = r7.$view
            androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda1 r4 = new androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda1
            r4.<init>(r8, r3)
            androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1 r3 = new androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$attachStateChangeListener$1
            android.view.View r5 = r7.$view
            r3.<init>(r8, r5, r4, r1)
            android.view.View r5 = r7.$view
            boolean r5 = r5.isAttachedToWindow()
            if (r5 == 0) goto L50
            android.view.View r5 = r7.$view
            android.graphics.Rect r5 = androidx.activity.PipHintTrackerKt.access$trackPipAnimationHintView$positionInWindow(r5)
            r8.mo3736trySendJP2dKIU(r5)
            android.view.View r5 = r7.$view
            android.view.ViewTreeObserver r5 = r5.getViewTreeObserver()
            r5.addOnScrollChangedListener(r4)
            android.view.View r5 = r7.$view
            r5.addOnLayoutChangeListener(r1)
        L50:
            android.view.View r5 = r7.$view
            r6 = r3
            android.view.View$OnAttachStateChangeListener r6 = (android.view.View.OnAttachStateChangeListener) r6
            r5.addOnAttachStateChangeListener(r6)
            android.view.View r5 = r7.$view
            androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda2 r6 = new androidx.activity.PipHintTrackerKt$trackPipAnimationHintView$flow$1$$ExternalSyntheticLambda2
            r6.<init>(r5, r4, r1, r3)
            r1 = r7
            kotlin.coroutines.Continuation r1 = (kotlin.coroutines.Continuation) r1
            r7.label = r2
            java.lang.Object r8 = kotlinx.coroutines.channels.ProduceKt.awaitClose(r8, r6, r1)
            if (r8 != r0) goto L6b
            return r0
        L6b:
            kotlin.Unit r8 = kotlin.Unit.INSTANCE
            return r8
    }
}
