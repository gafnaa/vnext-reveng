package androidx.activity;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class BackEventCompat$$ExternalSyntheticApiModelOutline0 {
    public static /* bridge */ /* synthetic */ float m(android.window.BackEvent r0) {
            float r0 = r0.getTouchX()
            return r0
    }

    public static /* bridge */ /* synthetic */ int m() {
            int r0 = android.provider.MediaStore.getPickImagesMaxLimit()
            return r0
    }

    public static /* bridge */ /* synthetic */ int m(int r0) {
            int r0 = android.os.ext.SdkExtensions.getExtensionVersion(r0)
            return r0
    }

    public static /* bridge */ /* synthetic */ int m(android.app.NotificationChannel r0) {
            int r0 = r0.getImportance()
            return r0
    }

    public static /* bridge */ /* synthetic */ int m(android.content.res.Configuration r0) {
            int r0 = r0.colorMode
            return r0
    }

    public static /* bridge */ /* synthetic */ int m(android.graphics.ColorSpace.Named r0) {
            int r0 = r0.ordinal()
            return r0
    }

    public static /* bridge */ /* synthetic */ int m(android.graphics.Insets r0) {
            int r0 = r0.left
            return r0
    }

    public static /* bridge */ /* synthetic */ int m(android.hardware.camera2.CameraExtensionSession r0, android.hardware.camera2.CaptureRequest r1, java.util.concurrent.Executor r2, android.hardware.camera2.CameraExtensionSession$ExtensionCaptureCallback r3) {
            int r0 = r0.setRepeatingRequest(r1, r2, r3)
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ int m9m(android.window.BackEvent r0) {
            int r0 = r0.getSwipeEdge()
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ long m10m(android.window.BackEvent r2) {
            long r0 = r2.getFrameTimeMillis()
            return r0
    }

    public static /* bridge */ /* synthetic */ android.app.Notification.Builder m(android.app.Notification.Builder r0, java.lang.String r1) {
            android.app.Notification$Builder r0 = r0.setChannelId(r1)
            return r0
    }

    public static /* bridge */ /* synthetic */ android.app.NotificationChannel m(android.app.NotificationManager r0, java.lang.String r1) {
            android.app.NotificationChannel r0 = r0.getNotificationChannel(r1)
            return r0
    }

    public static /* synthetic */ android.app.NotificationChannel m(java.lang.String r1, java.lang.CharSequence r2, int r3) {
            android.app.NotificationChannel r0 = new android.app.NotificationChannel
            r0.<init>(r1, r2, r3)
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m11m() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.SRGB
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraCharacteristics.Key m12m() {
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.INFO_SESSION_CONFIGURATION_QUERY_VERSION
            return r0
    }

    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraExtensionSession$ExtensionCaptureCallback m(java.lang.Object r0) {
            android.hardware.camera2.CameraExtensionSession$ExtensionCaptureCallback r0 = (android.hardware.camera2.CameraExtensionSession$ExtensionCaptureCallback) r0
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraExtensionSession$StateCallback m13m(java.lang.Object r0) {
            android.hardware.camera2.CameraExtensionSession$StateCallback r0 = (android.hardware.camera2.CameraExtensionSession$StateCallback) r0
            return r0
    }

    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraExtensionSession.StillCaptureLatency m(android.hardware.camera2.CameraExtensionSession r0) {
            android.hardware.camera2.CameraExtensionSession$StillCaptureLatency r0 = r0.getRealtimeStillCaptureLatency()
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraExtensionSession m14m(java.lang.Object r0) {
            android.hardware.camera2.CameraExtensionSession r0 = (android.hardware.camera2.CameraExtensionSession) r0
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CaptureRequest.Key m15m() {
            android.hardware.camera2.CaptureRequest$Key r0 = android.hardware.camera2.CaptureRequest.CONTROL_ZOOM_RATIO
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CaptureResult.Key m16m() {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.params.ColorSpaceProfiles m17m(java.lang.Object r0) {
            android.hardware.camera2.params.ColorSpaceProfiles r0 = (android.hardware.camera2.params.ColorSpaceProfiles) r0
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.params.DynamicRangeProfiles m18m(java.lang.Object r0) {
            android.hardware.camera2.params.DynamicRangeProfiles r0 = (android.hardware.camera2.params.DynamicRangeProfiles) r0
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.params.MultiResolutionStreamConfigurationMap m19m(java.lang.Object r0) {
            android.hardware.camera2.params.MultiResolutionStreamConfigurationMap r0 = (android.hardware.camera2.params.MultiResolutionStreamConfigurationMap) r0
            return r0
    }

    public static /* synthetic */ android.hardware.camera2.params.OutputConfiguration m(android.util.Size r1, java.lang.Class r2) {
            android.hardware.camera2.params.OutputConfiguration r0 = new android.hardware.camera2.params.OutputConfiguration
            r0.<init>(r1, r2)
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* synthetic */ android.media.ApplicationMediaCapabilities.Builder m20m() {
            android.media.ApplicationMediaCapabilities$Builder r0 = new android.media.ApplicationMediaCapabilities$Builder
            r0.<init>()
            return r0
    }

    public static /* bridge */ /* synthetic */ android.media.ApplicationMediaCapabilities.Builder m(android.media.ApplicationMediaCapabilities.Builder r0, java.lang.String r1) {
            android.media.ApplicationMediaCapabilities$Builder r0 = r0.addSupportedVideoMimeType(r1)
            return r0
    }

    public static /* bridge */ /* synthetic */ android.media.ApplicationMediaCapabilities m(android.media.ApplicationMediaCapabilities.Builder r0) {
            android.media.ApplicationMediaCapabilities r0 = r0.build()
            return r0
    }

    public static /* bridge */ /* synthetic */ android.media.session.MediaSessionManager.RemoteUserInfo m(android.media.session.MediaSession r0) {
            android.media.session.MediaSessionManager$RemoteUserInfo r0 = r0.getCurrentControllerInfo()
            return r0
    }

    public static /* bridge */ /* synthetic */ android.text.TextDirectionHeuristic m(android.widget.TextView r0) {
            android.text.TextDirectionHeuristic r0 = r0.getTextDirectionHeuristic()
            return r0
    }

    public static /* synthetic */ android.window.BackEvent m(float r1, float r2, float r3, int r4) {
            android.window.BackEvent r0 = new android.window.BackEvent
            r0.<init>(r1, r2, r3, r4)
            return r0
    }

    public static /* synthetic */ android.window.BackEvent m(float r7, float r8, float r9, int r10, long r11) {
            android.window.BackEvent r0 = new android.window.BackEvent
            r1 = r7
            r2 = r8
            r3 = r9
            r4 = r10
            r5 = r11
            r0.<init>(r1, r2, r3, r4, r5)
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.window.OnBackInvokedCallback m21m(java.lang.Object r0) {
            android.window.OnBackInvokedCallback r0 = (android.window.OnBackInvokedCallback) r0
            return r0
    }

    public static /* bridge */ /* synthetic */ android.window.OnBackInvokedDispatcher m(android.app.Activity r0) {
            android.window.OnBackInvokedDispatcher r0 = r0.getOnBackInvokedDispatcher()
            return r0
    }

    public static /* bridge */ /* synthetic */ android.window.OnBackInvokedDispatcher m(androidx.activity.ComponentDialog r0) {
            android.window.OnBackInvokedDispatcher r0 = r0.getOnBackInvokedDispatcher()
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.window.OnBackInvokedDispatcher m22m(java.lang.Object r0) {
            android.window.OnBackInvokedDispatcher r0 = (android.window.OnBackInvokedDispatcher) r0
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ java.lang.Class m23m() {
            java.lang.Class<android.hardware.camera2.CameraExtensionSession> r0 = android.hardware.camera2.CameraExtensionSession.class
            return r0
    }

    public static /* bridge */ /* synthetic */ java.lang.Object m(android.content.Intent r0, java.lang.String r1, java.lang.Class r2) {
            java.lang.Object r0 = r0.getParcelableExtra(r1, r2)
            return r0
    }

    public static /* bridge */ /* synthetic */ java.lang.Object m(android.os.Bundle r0, java.lang.String r1, java.lang.Class r2) {
            java.lang.Object r0 = r0.getParcelable(r1, r2)
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ java.lang.String m24m() {
            java.lang.String r0 = android.os.Build.SOC_MANUFACTURER
            return r0
    }

    public static /* bridge */ /* synthetic */ java.util.List m(android.hardware.camera2.CameraCharacteristics r0) {
            java.util.List r0 = r0.getAvailablePhysicalCameraRequestKeys()
            return r0
    }

    public static /* bridge */ /* synthetic */ java.util.List m(android.hardware.camera2.params.OutputConfiguration r0) {
            java.util.List r0 = r0.getSurfaces()
            return r0
    }

    public static /* bridge */ /* synthetic */ java.util.Map m(android.hardware.camera2.TotalCaptureResult r0) {
            java.util.Map r0 = r0.getPhysicalCameraResults()
            return r0
    }

    public static /* bridge */ /* synthetic */ java.util.Set m(android.hardware.camera2.params.DynamicRangeProfiles r0) {
            java.util.Set r0 = r0.getSupportedProfiles()
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* synthetic */ void m25m() {
            android.window.BackEvent r0 = new android.window.BackEvent
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.app.NotificationManager r0, android.app.NotificationChannel r1) {
            r0.createNotificationChannel(r1)
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.content.res.Configuration r0, int r1) {
            r0.colorMode = r1
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.hardware.camera2.CameraCaptureSession.CaptureCallback r0, android.hardware.camera2.CameraCaptureSession r1, android.hardware.camera2.CaptureRequest r2, long r3, long r5) {
            r0.onReadoutStarted(r1, r2, r3, r5)
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.hardware.camera2.CameraCaptureSession.StateCallback r0, android.hardware.camera2.CameraCaptureSession r1) {
            r0.onCaptureQueueEmpty(r1)
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.hardware.camera2.CameraCaptureSession r0, java.util.List r1) {
            r0.finalizeOutputConfigurations(r1)
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.hardware.camera2.CameraDevice r0, android.hardware.camera2.params.SessionConfiguration r1) {
            r0.createCaptureSession(r1)
            return
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ void m26m(android.hardware.camera2.CameraExtensionSession r0) {
            r0.stopRepeating()
            return
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ void m27m(android.hardware.camera2.params.OutputConfiguration r0) {
            r0.enableSurfaceSharing()
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.hardware.camera2.params.OutputConfiguration r0, android.view.Surface r1) {
            r0.addSurface(r1)
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.hardware.camera2.params.SessionConfiguration r0, android.hardware.camera2.CaptureRequest r1) {
            r0.setSessionParameters(r1)
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.media.ImageReader r0) {
            r0.discardFreeBuffers()
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.view.Window r0, boolean r1) {
            r0.setStatusBarContrastEnforced(r1)
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.view.WindowManager.LayoutParams r0, int r1) {
            r0.layoutInDisplayCutoutMode = r1
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.window.OnBackInvokedDispatcher r0, int r1, android.window.OnBackInvokedCallback r2) {
            r0.registerOnBackInvokedCallback(r1, r2)
            return
    }

    public static /* bridge */ /* synthetic */ void m(android.window.OnBackInvokedDispatcher r0, android.window.OnBackInvokedCallback r1) {
            r0.unregisterOnBackInvokedCallback(r1)
            return
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ boolean m28m(android.widget.TextView r0) {
            boolean r0 = r0.isHorizontallyScrollable()
            return r0
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named[] m29m() {
            android.graphics.ColorSpace$Named[] r0 = android.graphics.ColorSpace.Named.values()
            return r0
    }

    public static /* bridge */ /* synthetic */ float m$1(android.window.BackEvent r0) {
            float r0 = r0.getTouchY()
            return r0
    }

    public static /* bridge */ /* synthetic */ int m$1(android.graphics.Insets r0) {
            int r0 = r0.top
            return r0
    }

    public static /* bridge */ /* synthetic */ int m$1(android.hardware.camera2.CameraExtensionSession r0, android.hardware.camera2.CaptureRequest r1, java.util.concurrent.Executor r2, android.hardware.camera2.CameraExtensionSession$ExtensionCaptureCallback r3) {
            int r0 = r0.capture(r1, r2, r3)
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$1() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.PRO_PHOTO_RGB
            return r0
    }

    /* JADX INFO: renamed from: m$1, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraCharacteristics.Key m30m$1() {
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION
            return r0
    }

    /* JADX INFO: renamed from: m$1, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CaptureRequest.Key m31m$1() {
            android.hardware.camera2.CaptureRequest$Key r0 = android.hardware.camera2.CaptureRequest.CONTROL_SETTINGS_OVERRIDE
            return r0
    }

    /* JADX INFO: renamed from: m$1, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CaptureResult.Key m32m$1() {
            android.hardware.camera2.CaptureResult$Key r0 = android.hardware.camera2.CaptureResult.CONTROL_LOW_LIGHT_BOOST_STATE
            return r0
    }

    public static /* bridge */ /* synthetic */ android.media.ApplicationMediaCapabilities.Builder m$1(android.media.ApplicationMediaCapabilities.Builder r0, java.lang.String r1) {
            android.media.ApplicationMediaCapabilities$Builder r0 = r0.addSupportedHdrType(r1)
            return r0
    }

    /* JADX INFO: renamed from: m$1, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ java.lang.Class m33m$1() {
            java.lang.Class<android.hardware.HardwareBuffer> r0 = android.hardware.HardwareBuffer.class
            return r0
    }

    public static /* bridge */ /* synthetic */ void m$1(android.hardware.camera2.CameraExtensionSession r0) {
            r0.close()
            return
    }

    public static /* bridge */ /* synthetic */ void m$1(android.view.Window r0, boolean r1) {
            r0.setNavigationBarContrastEnforced(r1)
            return
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$10() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.LINEAR_EXTENDED_SRGB
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$11() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.BT709
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$12() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.BT2020
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$13() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.DCI_P3
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$14() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.DISPLAY_P3
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$15() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.NTSC_1953
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$16() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.SMPTE_C
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$17() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.ADOBE_RGB
            return r0
    }

    public static /* bridge */ /* synthetic */ float m$2(android.window.BackEvent r0) {
            float r0 = r0.getProgress()
            return r0
    }

    public static /* bridge */ /* synthetic */ int m$2(android.graphics.Insets r0) {
            int r0 = r0.right
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$2() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.ACES
            return r0
    }

    /* JADX INFO: renamed from: m$2, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraCharacteristics.Key m34m$2() {
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES
            return r0
    }

    /* JADX INFO: renamed from: m$2, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CaptureRequest.Key m35m$2() {
            android.hardware.camera2.CaptureRequest$Key r0 = android.hardware.camera2.CaptureRequest.FLASH_STRENGTH_LEVEL
            return r0
    }

    public static /* bridge */ /* synthetic */ int m$3(android.graphics.Insets r0) {
            int r0 = r0.bottom
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$3() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.ACESCG
            return r0
    }

    /* JADX INFO: renamed from: m$3, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraCharacteristics.Key m36m$3() {
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE
            return r0
    }

    /* JADX INFO: renamed from: m$3, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CaptureRequest.Key m37m$3() {
            android.hardware.camera2.CaptureRequest$Key r0 = android.hardware.camera2.CaptureRequest.CONTROL_ENABLE_ZSL
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$4() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.CIE_XYZ
            return r0
    }

    /* JADX INFO: renamed from: m$4, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraCharacteristics.Key m38m$4() {
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.SCALER_AVAILABLE_STREAM_USE_CASES
            return r0
    }

    /* JADX INFO: renamed from: m$4, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CaptureRequest.Key m39m$4() {
            android.hardware.camera2.CaptureRequest$Key r0 = android.hardware.camera2.CaptureRequest.EXTENSION_STRENGTH
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$5() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.CIE_LAB
            return r0
    }

    /* JADX INFO: renamed from: m$5, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraCharacteristics.Key m40m$5() {
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.REQUEST_AVAILABLE_COLOR_SPACE_PROFILES
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$6() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.BT2020_HLG
            return r0
    }

    /* JADX INFO: renamed from: m$6, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ android.hardware.camera2.CameraCharacteristics.Key m41m$6() {
            android.hardware.camera2.CameraCharacteristics$Key r0 = android.hardware.camera2.CameraCharacteristics.SCALER_MULTI_RESOLUTION_STREAM_CONFIGURATION_MAP
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$7() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.BT2020_PQ
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$8() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.LINEAR_SRGB
            return r0
    }

    public static /* bridge */ /* synthetic */ android.graphics.ColorSpace.Named m$9() {
            android.graphics.ColorSpace$Named r0 = android.graphics.ColorSpace.Named.EXTENDED_SRGB
            return r0
    }
}
