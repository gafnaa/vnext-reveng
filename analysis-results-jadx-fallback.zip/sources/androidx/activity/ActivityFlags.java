package androidx.activity;

/* JADX INFO: compiled from: ActivityFlags.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0018\u0010\u0004\u001a\u00020\u00058\u0006@\u0006X\u0087\u000e¢\u0006\b\n\u0000\u0012\u0004\b\u0006\u0010\u0003¨\u0006\u0007"}, d2 = {"Landroidx/activity/ActivityFlags;", "", "<init>", "()V", "isOnBackPressedLifecycleOrderMaintained", "", "isOnBackPressedLifecycleOrderMaintained$annotations", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class ActivityFlags {
    public static final androidx.activity.ActivityFlags INSTANCE = null;
    public static boolean isOnBackPressedLifecycleOrderMaintained;

    static {
            androidx.activity.ActivityFlags r0 = new androidx.activity.ActivityFlags
            r0.<init>()
            androidx.activity.ActivityFlags.INSTANCE = r0
            r0 = 1
            androidx.activity.ActivityFlags.isOnBackPressedLifecycleOrderMaintained = r0
            return
    }

    private ActivityFlags() {
            r0 = this;
            r0.<init>()
            return
    }

    public static /* synthetic */ void isOnBackPressedLifecycleOrderMaintained$annotations() {
            return
    }
}
