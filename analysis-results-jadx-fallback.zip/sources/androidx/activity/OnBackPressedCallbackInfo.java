package androidx.activity;

/* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u001b\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\r\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u001f\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012HÖ\u0003J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001J\t\u0010\u0015\u001a\u00020\u0016HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0017"}, d2 = {"Landroidx/activity/OnBackPressedCallbackInfo;", "Landroidx/navigationevent/NavigationEventInfo;", "callback", "Landroidx/activity/OnBackPressedCallback;", "owner", "Landroidx/lifecycle/LifecycleOwner;", "<init>", "(Landroidx/activity/OnBackPressedCallback;Landroidx/lifecycle/LifecycleOwner;)V", "getCallback", "()Landroidx/activity/OnBackPressedCallback;", "getOwner", "()Landroidx/lifecycle/LifecycleOwner;", "component1", "component2", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "activity"}, k = 1, mv = {2, 0, 0}, xi = 48)
final class OnBackPressedCallbackInfo extends androidx.navigationevent.NavigationEventInfo {
    private final androidx.activity.OnBackPressedCallback callback;
    private final androidx.lifecycle.LifecycleOwner owner;

    public OnBackPressedCallbackInfo(androidx.activity.OnBackPressedCallback r2, androidx.lifecycle.LifecycleOwner r3) {
            r1 = this;
            java.lang.String r0 = "callback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            r1.<init>()
            r1.callback = r2
            r1.owner = r3
            return
    }

    public /* synthetic */ OnBackPressedCallbackInfo(androidx.activity.OnBackPressedCallback r1, androidx.lifecycle.LifecycleOwner r2, int r3, kotlin.jvm.internal.DefaultConstructorMarker r4) {
            r0 = this;
            r3 = r3 & 2
            if (r3 == 0) goto L5
            r2 = 0
        L5:
            r0.<init>(r1, r2)
            return
    }

    public static /* synthetic */ androidx.activity.OnBackPressedCallbackInfo copy$default(androidx.activity.OnBackPressedCallbackInfo r0, androidx.activity.OnBackPressedCallback r1, androidx.lifecycle.LifecycleOwner r2, int r3, java.lang.Object r4) {
            r4 = r3 & 1
            if (r4 == 0) goto L6
            androidx.activity.OnBackPressedCallback r1 = r0.callback
        L6:
            r3 = r3 & 2
            if (r3 == 0) goto Lc
            androidx.lifecycle.LifecycleOwner r2 = r0.owner
        Lc:
            androidx.activity.OnBackPressedCallbackInfo r0 = r0.copy(r1, r2)
            return r0
    }

    public final androidx.activity.OnBackPressedCallback component1() {
            r1 = this;
            androidx.activity.OnBackPressedCallback r0 = r1.callback
            return r0
    }

    public final androidx.lifecycle.LifecycleOwner component2() {
            r1 = this;
            androidx.lifecycle.LifecycleOwner r0 = r1.owner
            return r0
    }

    public final androidx.activity.OnBackPressedCallbackInfo copy(androidx.activity.OnBackPressedCallback r2, androidx.lifecycle.LifecycleOwner r3) {
            r1 = this;
            java.lang.String r0 = "callback"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            androidx.activity.OnBackPressedCallbackInfo r0 = new androidx.activity.OnBackPressedCallbackInfo
            r0.<init>(r2, r3)
            return r0
    }

    public boolean equals(java.lang.Object r5) {
            r4 = this;
            r0 = 1
            if (r4 != r5) goto L4
            return r0
        L4:
            boolean r1 = r5 instanceof androidx.activity.OnBackPressedCallbackInfo
            r2 = 0
            if (r1 != 0) goto La
            return r2
        La:
            androidx.activity.OnBackPressedCallbackInfo r5 = (androidx.activity.OnBackPressedCallbackInfo) r5
            androidx.activity.OnBackPressedCallback r1 = r4.callback
            androidx.activity.OnBackPressedCallback r3 = r5.callback
            boolean r1 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r3)
            if (r1 != 0) goto L17
            return r2
        L17:
            androidx.lifecycle.LifecycleOwner r1 = r4.owner
            androidx.lifecycle.LifecycleOwner r5 = r5.owner
            boolean r5 = kotlin.jvm.internal.Intrinsics.areEqual(r1, r5)
            if (r5 != 0) goto L22
            return r2
        L22:
            return r0
    }

    public final androidx.activity.OnBackPressedCallback getCallback() {
            r1 = this;
            androidx.activity.OnBackPressedCallback r0 = r1.callback
            return r0
    }

    public final androidx.lifecycle.LifecycleOwner getOwner() {
            r1 = this;
            androidx.lifecycle.LifecycleOwner r0 = r1.owner
            return r0
    }

    public int hashCode() {
            r2 = this;
            androidx.activity.OnBackPressedCallback r0 = r2.callback
            int r0 = r0.hashCode()
            int r0 = r0 * 31
            androidx.lifecycle.LifecycleOwner r1 = r2.owner
            if (r1 != 0) goto Le
            r1 = 0
            goto L12
        Le:
            int r1 = r1.hashCode()
        L12:
            int r0 = r0 + r1
            return r0
    }

    public java.lang.String toString() {
            r2 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "OnBackPressedCallbackInfo(callback="
            r0.<init>(r1)
            androidx.activity.OnBackPressedCallback r1 = r2.callback
            r0.append(r1)
            java.lang.String r1 = ", owner="
            r0.append(r1)
            androidx.lifecycle.LifecycleOwner r1 = r2.owner
            r0.append(r1)
            r1 = 41
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }
}
