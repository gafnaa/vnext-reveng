package androidx.activity;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class id {
        public static int report_drawn = 0x7f08009b;
        public static int view_tree_on_back_pressed_dispatcher_owner = 0x7f0800eb;

        private id() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    private R() {
            r0 = this;
            r0.<init>()
            return
    }
}
