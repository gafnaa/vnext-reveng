package androidx.activity;

/* JADX INFO: compiled from: ActivityViewModelLazy.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a4\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u0003*\u00020\u00042\u0010\b\n\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0006H\u0087\bø\u0001\u0000\u001aF\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u0003*\u00020\u00042\u0010\b\n\u0010\b\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\u00062\u0010\b\n\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0006H\u0087\bø\u0001\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001¨\u0006\n"}, d2 = {"viewModels", "Lkotlin/Lazy;", "VM", "Landroidx/lifecycle/ViewModel;", "Landroidx/activity/ComponentActivity;", "factoryProducer", "Lkotlin/Function0;", "Landroidx/lifecycle/ViewModelProvider$Factory;", "extrasProducer", "Landroidx/lifecycle/viewmodel/CreationExtras;", "activity"}, k = 2, mv = {2, 0, 0}, xi = 48)
public final class ActivityViewModelLazyKt {

    /* JADX INFO: renamed from: androidx.activity.ActivityViewModelLazyKt$viewModels$1, reason: invalid class name */
    /* JADX INFO: compiled from: ActivityViewModelLazy.kt */
    @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 176)
    public static final class AnonymousClass1 implements kotlin.jvm.functions.Function0<androidx.lifecycle.ViewModelStore> {
        final /* synthetic */ androidx.activity.ComponentActivity $this_viewModels;

        public AnonymousClass1(androidx.activity.ComponentActivity r1) {
                r0 = this;
                r0.$this_viewModels = r1
                r0.<init>()
                return
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final androidx.lifecycle.ViewModelStore invoke() {
                r1 = this;
                androidx.activity.ComponentActivity r0 = r1.$this_viewModels
                androidx.lifecycle.ViewModelStore r0 = r0.getViewModelStore()
                return r0
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ androidx.lifecycle.ViewModelStore invoke() {
                r1 = this;
                androidx.lifecycle.ViewModelStore r0 = r1.invoke()
                return r0
        }
    }

    /* JADX INFO: renamed from: androidx.activity.ActivityViewModelLazyKt$viewModels$2, reason: invalid class name */
    /* JADX INFO: compiled from: ActivityViewModelLazy.kt */
    @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 176)
    public static final class AnonymousClass2 implements kotlin.jvm.functions.Function0<androidx.lifecycle.viewmodel.CreationExtras> {
        final /* synthetic */ androidx.activity.ComponentActivity $this_viewModels;

        public AnonymousClass2(androidx.activity.ComponentActivity r1) {
                r0 = this;
                r0.$this_viewModels = r1
                r0.<init>()
                return
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final androidx.lifecycle.viewmodel.CreationExtras invoke() {
                r1 = this;
                androidx.activity.ComponentActivity r0 = r1.$this_viewModels
                androidx.lifecycle.viewmodel.CreationExtras r0 = r0.getDefaultViewModelCreationExtras()
                return r0
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ androidx.lifecycle.viewmodel.CreationExtras invoke() {
                r1 = this;
                androidx.lifecycle.viewmodel.CreationExtras r0 = r1.invoke()
                return r0
        }
    }

    /* JADX INFO: renamed from: androidx.activity.ActivityViewModelLazyKt$viewModels$3, reason: invalid class name */
    /* JADX INFO: compiled from: ActivityViewModelLazy.kt */
    @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 176)
    public static final class AnonymousClass3 implements kotlin.jvm.functions.Function0<androidx.lifecycle.ViewModelStore> {
        final /* synthetic */ androidx.activity.ComponentActivity $this_viewModels;

        public AnonymousClass3(androidx.activity.ComponentActivity r1) {
                r0 = this;
                r0.$this_viewModels = r1
                r0.<init>()
                return
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final androidx.lifecycle.ViewModelStore invoke() {
                r1 = this;
                androidx.activity.ComponentActivity r0 = r1.$this_viewModels
                androidx.lifecycle.ViewModelStore r0 = r0.getViewModelStore()
                return r0
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ androidx.lifecycle.ViewModelStore invoke() {
                r1 = this;
                androidx.lifecycle.ViewModelStore r0 = r1.invoke()
                return r0
        }
    }

    /* JADX INFO: renamed from: androidx.activity.ActivityViewModelLazyKt$viewModels$4, reason: invalid class name */
    /* JADX INFO: compiled from: ActivityViewModelLazy.kt */
    @kotlin.Metadata(k = 3, mv = {2, 0, 0}, xi = 176)
    public static final class AnonymousClass4 implements kotlin.jvm.functions.Function0<androidx.lifecycle.viewmodel.CreationExtras> {
        final /* synthetic */ kotlin.jvm.functions.Function0<androidx.lifecycle.viewmodel.CreationExtras> $extrasProducer;
        final /* synthetic */ androidx.activity.ComponentActivity $this_viewModels;

        public AnonymousClass4(kotlin.jvm.functions.Function0<? extends androidx.lifecycle.viewmodel.CreationExtras> r1, androidx.activity.ComponentActivity r2) {
                r0 = this;
                r0.$extrasProducer = r1
                r0.$this_viewModels = r2
                r0.<init>()
                return
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // kotlin.jvm.functions.Function0
        public final androidx.lifecycle.viewmodel.CreationExtras invoke() {
                r1 = this;
                kotlin.jvm.functions.Function0<androidx.lifecycle.viewmodel.CreationExtras> r0 = r1.$extrasProducer
                if (r0 == 0) goto Le
                java.lang.Object r0 = r0.invoke()
                androidx.lifecycle.viewmodel.CreationExtras r0 = (androidx.lifecycle.viewmodel.CreationExtras) r0
                if (r0 != 0) goto Ld
                goto Le
            Ld:
                return r0
            Le:
                androidx.activity.ComponentActivity r0 = r1.$this_viewModels
                androidx.lifecycle.viewmodel.CreationExtras r0 = r0.getDefaultViewModelCreationExtras()
                return r0
        }

        @Override // kotlin.jvm.functions.Function0
        public /* bridge */ /* synthetic */ androidx.lifecycle.viewmodel.CreationExtras invoke() {
                r1 = this;
                androidx.lifecycle.viewmodel.CreationExtras r0 = r1.invoke()
                return r0
        }
    }

    @kotlin.Deprecated(level = kotlin.DeprecationLevel.HIDDEN, message = "Superseded by viewModels that takes a CreationExtras")
    public static final /* synthetic */ <VM extends androidx.lifecycle.ViewModel> kotlin.Lazy<VM> viewModels(androidx.activity.ComponentActivity r4, kotlin.jvm.functions.Function0<? extends androidx.lifecycle.ViewModelProvider.Factory> r5) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            if (r5 != 0) goto Le
            androidx.activity.ActivityViewModelLazyKt$viewModels$factoryPromise$1 r5 = new androidx.activity.ActivityViewModelLazyKt$viewModels$factoryPromise$1
            r5.<init>(r4)
            kotlin.jvm.functions.Function0 r5 = (kotlin.jvm.functions.Function0) r5
        Le:
            androidx.lifecycle.ViewModelLazy r0 = new androidx.lifecycle.ViewModelLazy
            r1 = 4
            java.lang.String r2 = "VM"
            kotlin.jvm.internal.Intrinsics.reifiedOperationMarker(r1, r2)
            java.lang.Class<androidx.lifecycle.ViewModel> r1 = androidx.lifecycle.ViewModel.class
            kotlin.reflect.KClass r1 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r1)
            androidx.activity.ActivityViewModelLazyKt$viewModels$1 r2 = new androidx.activity.ActivityViewModelLazyKt$viewModels$1
            r2.<init>(r4)
            kotlin.jvm.functions.Function0 r2 = (kotlin.jvm.functions.Function0) r2
            androidx.activity.ActivityViewModelLazyKt$viewModels$2 r3 = new androidx.activity.ActivityViewModelLazyKt$viewModels$2
            r3.<init>(r4)
            kotlin.jvm.functions.Function0 r3 = (kotlin.jvm.functions.Function0) r3
            r0.<init>(r1, r2, r5, r3)
            kotlin.Lazy r0 = (kotlin.Lazy) r0
            return r0
    }

    public static final /* synthetic */ <VM extends androidx.lifecycle.ViewModel> kotlin.Lazy<VM> viewModels(androidx.activity.ComponentActivity r4, kotlin.jvm.functions.Function0<? extends androidx.lifecycle.viewmodel.CreationExtras> r5, kotlin.jvm.functions.Function0<? extends androidx.lifecycle.ViewModelProvider.Factory> r6) {
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            if (r6 != 0) goto Le
            androidx.activity.ActivityViewModelLazyKt$viewModels$factoryPromise$2 r6 = new androidx.activity.ActivityViewModelLazyKt$viewModels$factoryPromise$2
            r6.<init>(r4)
            kotlin.jvm.functions.Function0 r6 = (kotlin.jvm.functions.Function0) r6
        Le:
            androidx.lifecycle.ViewModelLazy r0 = new androidx.lifecycle.ViewModelLazy
            r1 = 4
            java.lang.String r2 = "VM"
            kotlin.jvm.internal.Intrinsics.reifiedOperationMarker(r1, r2)
            java.lang.Class<androidx.lifecycle.ViewModel> r1 = androidx.lifecycle.ViewModel.class
            kotlin.reflect.KClass r1 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r1)
            androidx.activity.ActivityViewModelLazyKt$viewModels$3 r2 = new androidx.activity.ActivityViewModelLazyKt$viewModels$3
            r2.<init>(r4)
            kotlin.jvm.functions.Function0 r2 = (kotlin.jvm.functions.Function0) r2
            androidx.activity.ActivityViewModelLazyKt$viewModels$4 r3 = new androidx.activity.ActivityViewModelLazyKt$viewModels$4
            r3.<init>(r5, r4)
            kotlin.jvm.functions.Function0 r3 = (kotlin.jvm.functions.Function0) r3
            r0.<init>(r1, r2, r6, r3)
            kotlin.Lazy r0 = (kotlin.Lazy) r0
            return r0
    }

    public static /* synthetic */ kotlin.Lazy viewModels$default(androidx.activity.ComponentActivity r2, kotlin.jvm.functions.Function0 r3, int r4, java.lang.Object r5) {
            r4 = r4 & 1
            if (r4 == 0) goto L5
            r3 = 0
        L5:
            java.lang.String r4 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r4)
            if (r3 != 0) goto L13
            androidx.activity.ActivityViewModelLazyKt$viewModels$factoryPromise$1 r3 = new androidx.activity.ActivityViewModelLazyKt$viewModels$factoryPromise$1
            r3.<init>(r2)
            kotlin.jvm.functions.Function0 r3 = (kotlin.jvm.functions.Function0) r3
        L13:
            androidx.lifecycle.ViewModelLazy r4 = new androidx.lifecycle.ViewModelLazy
            r5 = 4
            java.lang.String r0 = "VM"
            kotlin.jvm.internal.Intrinsics.reifiedOperationMarker(r5, r0)
            java.lang.Class<androidx.lifecycle.ViewModel> r5 = androidx.lifecycle.ViewModel.class
            kotlin.reflect.KClass r5 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r5)
            androidx.activity.ActivityViewModelLazyKt$viewModels$1 r0 = new androidx.activity.ActivityViewModelLazyKt$viewModels$1
            r0.<init>(r2)
            kotlin.jvm.functions.Function0 r0 = (kotlin.jvm.functions.Function0) r0
            androidx.activity.ActivityViewModelLazyKt$viewModels$2 r1 = new androidx.activity.ActivityViewModelLazyKt$viewModels$2
            r1.<init>(r2)
            kotlin.jvm.functions.Function0 r1 = (kotlin.jvm.functions.Function0) r1
            r4.<init>(r5, r0, r3, r1)
            kotlin.Lazy r4 = (kotlin.Lazy) r4
            return r4
    }

    public static /* synthetic */ kotlin.Lazy viewModels$default(androidx.activity.ComponentActivity r2, kotlin.jvm.functions.Function0 r3, kotlin.jvm.functions.Function0 r4, int r5, java.lang.Object r6) {
            r6 = r5 & 1
            r0 = 0
            if (r6 == 0) goto L6
            r3 = r0
        L6:
            r5 = r5 & 2
            if (r5 == 0) goto Lb
            r4 = r0
        Lb:
            java.lang.String r5 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r5)
            if (r4 != 0) goto L19
            androidx.activity.ActivityViewModelLazyKt$viewModels$factoryPromise$2 r4 = new androidx.activity.ActivityViewModelLazyKt$viewModels$factoryPromise$2
            r4.<init>(r2)
            kotlin.jvm.functions.Function0 r4 = (kotlin.jvm.functions.Function0) r4
        L19:
            androidx.lifecycle.ViewModelLazy r5 = new androidx.lifecycle.ViewModelLazy
            r6 = 4
            java.lang.String r0 = "VM"
            kotlin.jvm.internal.Intrinsics.reifiedOperationMarker(r6, r0)
            java.lang.Class<androidx.lifecycle.ViewModel> r6 = androidx.lifecycle.ViewModel.class
            kotlin.reflect.KClass r6 = kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(r6)
            androidx.activity.ActivityViewModelLazyKt$viewModels$3 r0 = new androidx.activity.ActivityViewModelLazyKt$viewModels$3
            r0.<init>(r2)
            kotlin.jvm.functions.Function0 r0 = (kotlin.jvm.functions.Function0) r0
            androidx.activity.ActivityViewModelLazyKt$viewModels$4 r1 = new androidx.activity.ActivityViewModelLazyKt$viewModels$4
            r1.<init>(r3, r2)
            kotlin.jvm.functions.Function0 r1 = (kotlin.jvm.functions.Function0) r1
            r5.<init>(r6, r0, r4, r1)
            kotlin.Lazy r5 = (kotlin.Lazy) r5
            return r5
    }
}
