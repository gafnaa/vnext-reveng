package androidx.asynclayoutinflater;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class attr {
        public static int alpha = 0x7f03002f;
        public static int font = 0x7f0300a5;
        public static int fontProviderAuthority = 0x7f0300a7;
        public static int fontProviderCerts = 0x7f0300a8;
        public static int fontProviderFetchStrategy = 0x7f0300aa;
        public static int fontProviderFetchTimeout = 0x7f0300ab;
        public static int fontProviderPackage = 0x7f0300ac;
        public static int fontProviderQuery = 0x7f0300ad;
        public static int fontStyle = 0x7f0300af;
        public static int fontVariationSettings = 0x7f0300b0;
        public static int fontWeight = 0x7f0300b1;
        public static int ttcIndex = 0x7f030179;

        private attr() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class color {
        public static int notification_action_color_filter = 0x7f050051;
        public static int notification_icon_bg_color = 0x7f050052;
        public static int ripple_material_light = 0x7f05005e;
        public static int secondary_text_default_material_light = 0x7f050060;

        private color() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 0x7f060053;
        public static int compat_button_inset_vertical_material = 0x7f060054;
        public static int compat_button_padding_horizontal_material = 0x7f060055;
        public static int compat_button_padding_vertical_material = 0x7f060056;
        public static int compat_control_corner_material = 0x7f060057;
        public static int compat_notification_large_icon_max_height = 0x7f060058;
        public static int compat_notification_large_icon_max_width = 0x7f060059;
        public static int notification_action_icon_size = 0x7f060069;
        public static int notification_action_text_size = 0x7f06006a;
        public static int notification_big_circle_margin = 0x7f06006b;
        public static int notification_content_margin_start = 0x7f06006c;
        public static int notification_large_icon_height = 0x7f06006d;
        public static int notification_large_icon_width = 0x7f06006e;
        public static int notification_main_column_padding_top = 0x7f06006f;
        public static int notification_media_narrow_margin = 0x7f060070;
        public static int notification_right_icon_size = 0x7f060071;
        public static int notification_right_side_padding_top = 0x7f060072;
        public static int notification_small_icon_background_padding = 0x7f060073;
        public static int notification_small_icon_size_as_large = 0x7f060074;
        public static int notification_subtext_size = 0x7f060075;
        public static int notification_top_pad = 0x7f060076;
        public static int notification_top_pad_large_text = 0x7f060077;

        private dimen() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class drawable {
        public static int notification_action_background = 0x7f07007e;
        public static int notification_bg = 0x7f07007f;
        public static int notification_bg_low = 0x7f070080;
        public static int notification_bg_low_normal = 0x7f070081;
        public static int notification_bg_low_pressed = 0x7f070082;
        public static int notification_bg_normal = 0x7f070083;
        public static int notification_bg_normal_pressed = 0x7f070084;
        public static int notification_icon_background = 0x7f070085;
        public static int notification_template_icon_bg = 0x7f070087;
        public static int notification_template_icon_low_bg = 0x7f070088;
        public static int notification_tile_bg = 0x7f070089;
        public static int notify_panel_notification_icon_bg = 0x7f07008a;

        private drawable() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class id {
        public static int action_container = 0x7f08002f;
        public static int action_divider = 0x7f080031;
        public static int action_image = 0x7f080032;
        public static int action_text = 0x7f080038;
        public static int actions = 0x7f080039;
        public static int async = 0x7f080045;
        public static int blocking = 0x7f080048;
        public static int chronometer = 0x7f080057;
        public static int forever = 0x7f08006d;
        public static int icon = 0x7f080075;
        public static int icon_group = 0x7f080077;
        public static int info = 0x7f08007b;
        public static int italic = 0x7f08007c;
        public static int line1 = 0x7f080080;
        public static int line3 = 0x7f080081;
        public static int normal = 0x7f08008c;
        public static int notification_background = 0x7f08008d;
        public static int notification_main_column = 0x7f08008e;
        public static int notification_main_column_container = 0x7f08008f;
        public static int right_icon = 0x7f08009d;
        public static int right_side = 0x7f08009e;
        public static int tag_transition_group = 0x7f0800d0;
        public static int tag_unhandled_key_event_manager = 0x7f0800d1;
        public static int tag_unhandled_key_listeners = 0x7f0800d2;
        public static int text = 0x7f0800d4;
        public static int text2 = 0x7f0800d5;
        public static int time = 0x7f0800d8;
        public static int title = 0x7f0800d9;

        private id() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class integer {
        public static int status_bar_notification_info_maxnum = 0x7f090007;

        private integer() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class layout {
        public static int notification_action = 0x7f0b0023;
        public static int notification_action_tombstone = 0x7f0b0024;
        public static int notification_template_custom_big = 0x7f0b002b;
        public static int notification_template_icon_group = 0x7f0b002c;
        public static int notification_template_part_chronometer = 0x7f0b0030;
        public static int notification_template_part_time = 0x7f0b0031;

        private layout() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class string {
        public static int status_bar_notification_info_overflow = 0x7f0e005a;

        private string() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class style {
        public static int TextAppearance_Compat_Notification = 0x7f0f010e;
        public static int TextAppearance_Compat_Notification_Info = 0x7f0f010f;
        public static int TextAppearance_Compat_Notification_Line2 = 0x7f0f0111;
        public static int TextAppearance_Compat_Notification_Time = 0x7f0f0114;
        public static int TextAppearance_Compat_Notification_Title = 0x7f0f0116;
        public static int Widget_Compat_NotificationActionContainer = 0x7f0f0184;
        public static int Widget_Compat_NotificationActionText = 0x7f0f0185;

        private style() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    public static final class styleable {
        public static int[] ColorStateListItem = null;
        public static int ColorStateListItem_alpha = 0x00000003;
        public static int ColorStateListItem_android_alpha = 0x00000001;
        public static int ColorStateListItem_android_color = 0x00000000;
        public static int ColorStateListItem_android_lStar = 0x00000002;
        public static int ColorStateListItem_lStar = 0x00000004;
        public static int[] FontFamily = null;
        public static int[] FontFamilyFont = null;
        public static int FontFamilyFont_android_font = 0x00000000;
        public static int FontFamilyFont_android_fontStyle = 0x00000002;
        public static int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static int FontFamilyFont_android_fontWeight = 0x00000001;
        public static int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static int FontFamilyFont_font = 0x00000005;
        public static int FontFamilyFont_fontStyle = 0x00000006;
        public static int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static int FontFamilyFont_fontWeight = 0x00000008;
        public static int FontFamilyFont_ttcIndex = 0x00000009;
        public static int FontFamily_fontProviderAuthority = 0x00000000;
        public static int FontFamily_fontProviderCerts = 0x00000001;
        public static int FontFamily_fontProviderFallbackQuery = 0x00000002;
        public static int FontFamily_fontProviderFetchStrategy = 0x00000003;
        public static int FontFamily_fontProviderFetchTimeout = 0x00000004;
        public static int FontFamily_fontProviderPackage = 0x00000005;
        public static int FontFamily_fontProviderQuery = 0x00000006;
        public static int FontFamily_fontProviderSystemFontFamily = 0x00000007;
        public static int[] GradientColor = null;
        public static int[] GradientColorItem = null;
        public static int GradientColorItem_android_color = 0x00000000;
        public static int GradientColorItem_android_offset = 0x00000001;
        public static int GradientColor_android_centerColor = 0x00000007;
        public static int GradientColor_android_centerX = 0x00000003;
        public static int GradientColor_android_centerY = 0x00000004;
        public static int GradientColor_android_endColor = 0x00000001;
        public static int GradientColor_android_endX = 0x0000000a;
        public static int GradientColor_android_endY = 0x0000000b;
        public static int GradientColor_android_gradientRadius = 0x00000005;
        public static int GradientColor_android_startColor = 0x00000000;
        public static int GradientColor_android_startX = 0x00000008;
        public static int GradientColor_android_startY = 0x00000009;
        public static int GradientColor_android_tileMode = 0x00000006;
        public static int GradientColor_android_type = 0x00000002;

        static {
                r0 = 2130903087(0x7f03002f, float:1.7412982E38)
                r1 = 2130903241(0x7f0300c9, float:1.7413294E38)
                r2 = 16843173(0x10101a5, float:2.3694738E-38)
                r3 = 16843551(0x101031f, float:2.3695797E-38)
                r4 = 16844359(0x1010647, float:2.3698062E-38)
                int[] r0 = new int[]{r2, r3, r4, r0, r1}
                androidx.asynclayoutinflater.R.styleable.ColorStateListItem = r0
                r0 = 8
                int[] r0 = new int[r0]
                r0 = {x003a: FILL_ARRAY_DATA , data: [2130903207, 2130903208, 2130903209, 2130903210, 2130903211, 2130903212, 2130903213, 2130903214} // fill-array
                androidx.asynclayoutinflater.R.styleable.FontFamily = r0
                r0 = 10
                int[] r0 = new int[r0]
                r0 = {x004e: FILL_ARRAY_DATA , data: [16844082, 16844083, 16844095, 16844143, 16844144, 2130903205, 2130903215, 2130903216, 2130903217, 2130903417} // fill-array
                androidx.asynclayoutinflater.R.styleable.FontFamilyFont = r0
                r0 = 12
                int[] r0 = new int[r0]
                r0 = {x0066: FILL_ARRAY_DATA , data: [16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051} // fill-array
                androidx.asynclayoutinflater.R.styleable.GradientColor = r0
                r0 = 16844052(0x1010514, float:2.36972E-38)
                int[] r0 = new int[]{r2, r0}
                androidx.asynclayoutinflater.R.styleable.GradientColorItem = r0
                return
        }

        private styleable() {
                r0 = this;
                r0.<init>()
                return
        }
    }

    private R() {
            r0 = this;
            r0.<init>()
            return
    }
}
