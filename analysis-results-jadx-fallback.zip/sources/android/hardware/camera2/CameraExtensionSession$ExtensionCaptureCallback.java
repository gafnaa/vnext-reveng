package android.hardware.camera2;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ class CameraExtensionSession$ExtensionCaptureCallback {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
