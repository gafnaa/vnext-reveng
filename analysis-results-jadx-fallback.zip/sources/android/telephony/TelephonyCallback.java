package android.telephony;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ class TelephonyCallback {

    public /* synthetic */ interface DisplayInfoListener {
        static {
                java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
                r0.<init>()
                throw r0
        }
    }

    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
