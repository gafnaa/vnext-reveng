package android.print;

/* JADX INFO: loaded from: classes.dex */
public class PdfConvert {


    public interface Result {
        void onError(java.lang.String r1);

        void onSuccess(java.io.File r1);
    }

    public PdfConvert() {
            r0 = this;
            r0.<init>()
            return
    }

    public static void print(android.content.Context r6, android.print.PrintDocumentAdapter r7, android.print.PrintAttributes r8, android.print.PdfConvert.Result r9) {
            android.print.PdfConvert$1 r4 = new android.print.PdfConvert$1
            r4.<init>(r6, r9, r7)
            r5 = 0
            r1 = 0
            r3 = 0
            r0 = r7
            r2 = r8
            r0.onLayout(r1, r2, r3, r4, r5)
            return
    }

    public static byte[] readFile(java.io.File r3) throws java.io.IOException {
            long r0 = r3.length()
            int r0 = (int) r0
            byte[] r0 = new byte[r0]
            java.io.FileInputStream r1 = new java.io.FileInputStream
            r1.<init>(r3)
            int r3 = r1.read(r0)     // Catch: java.lang.Throwable -> L1f
            r2 = -1
            if (r3 == r2) goto L17
            r1.close()
            return r0
        L17:
            java.io.IOException r3 = new java.io.IOException     // Catch: java.lang.Throwable -> L1f
            java.lang.String r0 = "EOF reached while trying to read the whole file"
            r3.<init>(r0)     // Catch: java.lang.Throwable -> L1f
            throw r3     // Catch: java.lang.Throwable -> L1f
        L1f:
            r3 = move-exception
            r1.close()     // Catch: java.lang.Throwable -> L24
            goto L28
        L24:
            r0 = move-exception
            r3.addSuppressed(r0)
        L28:
            throw r3
    }
}
