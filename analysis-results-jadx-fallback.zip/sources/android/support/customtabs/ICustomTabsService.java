package android.support.customtabs;

/* JADX INFO: loaded from: classes.dex */
public interface ICustomTabsService extends android.os.IInterface {
    public static final java.lang.String DESCRIPTOR = null;
    public static final int VERSION = 1;

    public static class Default implements android.support.customtabs.ICustomTabsService {
        public Default() {
                r0 = this;
                r0.<init>()
                return
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.ICustomTabsService
        public android.os.Bundle extraCommand(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public int getInterfaceVersion() {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean isEngagementSignalsApiAvailable(android.support.customtabs.ICustomTabsCallback r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean mayLaunchUrl(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2, android.os.Bundle r3, java.util.List<android.os.Bundle> r4) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean newAuthTabSession(android.support.customtabs.IAuthTabCallback r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean newSession(android.support.customtabs.ICustomTabsCallback r1) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean newSessionWithExtras(android.support.customtabs.ICustomTabsCallback r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public int postMessage(android.support.customtabs.ICustomTabsCallback r1, java.lang.String r2, android.os.Bundle r3) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public void prefetch(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2, android.os.Bundle r3) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsService
        public void prefetchWithMultipleUrls(android.support.customtabs.ICustomTabsCallback r1, java.util.List<android.net.Uri> r2, android.os.Bundle r3) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean receiveFile(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2, int r3, android.os.Bundle r4) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean requestPostMessageChannel(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean requestPostMessageChannelWithExtras(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2, android.os.Bundle r3) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean setEngagementSignalsCallback(android.support.customtabs.ICustomTabsCallback r1, android.os.IBinder r2, android.os.Bundle r3) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean updateVisuals(android.support.customtabs.ICustomTabsCallback r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean validateRelationship(android.support.customtabs.ICustomTabsCallback r1, int r2, android.net.Uri r3, android.os.Bundle r4) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsService
        public boolean warmup(long r1) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }
    }

    public static abstract class Stub extends android.os.Binder implements android.support.customtabs.ICustomTabsService {
        static final int TRANSACTION_extraCommand = 5;
        static final int TRANSACTION_getInterfaceVersion = 16777215;
        static final int TRANSACTION_isEngagementSignalsApiAvailable = 13;
        static final int TRANSACTION_mayLaunchUrl = 4;
        static final int TRANSACTION_newAuthTabSession = 18;
        static final int TRANSACTION_newSession = 3;
        static final int TRANSACTION_newSessionWithExtras = 10;
        static final int TRANSACTION_postMessage = 8;
        static final int TRANSACTION_prefetch = 15;
        static final int TRANSACTION_prefetchWithMultipleUrls = 16;
        static final int TRANSACTION_receiveFile = 12;
        static final int TRANSACTION_requestPostMessageChannel = 7;
        static final int TRANSACTION_requestPostMessageChannelWithExtras = 11;
        static final int TRANSACTION_setEngagementSignalsCallback = 14;
        static final int TRANSACTION_updateVisuals = 6;
        static final int TRANSACTION_validateRelationship = 9;
        static final int TRANSACTION_warmup = 2;

        private static class Proxy implements android.support.customtabs.ICustomTabsService {
            private int mCachedVersion;
            private android.os.IBinder mRemote;

            Proxy(android.os.IBinder r2) {
                    r1 = this;
                    r1.<init>()
                    r0 = -1
                    r1.mCachedVersion = r0
                    r1.mRemote = r2
                    return
            }

            @Override // android.os.IInterface
            public android.os.IBinder asBinder() {
                    r1 = this;
                    android.os.IBinder r0 = r1.mRemote
                    return r0
            }

            @Override // android.support.customtabs.ICustomTabsService
            public android.os.Bundle extraCommand(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L37
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L37
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L37
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L37
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L37
                    r2 = 5
                    boolean r4 = r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L37
                    if (r4 == 0) goto L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L37
                    android.os.Parcelable$Creator r4 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L37
                    java.lang.Object r4 = r1.readTypedObject(r4)     // Catch: java.lang.Throwable -> L37
                    android.os.Bundle r4 = (android.os.Bundle) r4     // Catch: java.lang.Throwable -> L37
                    r1.recycle()
                    r0.recycle()
                    return r4
                L2f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L37
                    java.lang.String r5 = "Method extraCommand is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L37
                    throw r4     // Catch: java.lang.Throwable -> L37
                L37:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            public java.lang.String getInterfaceDescriptor() {
                    r1 = this;
                    java.lang.String r0 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR
                    return r0
            }

            @Override // android.support.customtabs.ICustomTabsService
            public int getInterfaceVersion() throws android.os.RemoteException {
                    r5 = this;
                    int r0 = r5.mCachedVersion
                    r1 = -1
                    if (r0 != r1) goto L33
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2b
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2b
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2b
                    r3 = 16777215(0xffffff, float:2.3509886E-38)
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2b
                    r1.readException()     // Catch: java.lang.Throwable -> L2b
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2b
                    r5.mCachedVersion = r2     // Catch: java.lang.Throwable -> L2b
                    r1.recycle()
                    r0.recycle()
                    goto L33
                L2b:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
                L33:
                    int r0 = r5.mCachedVersion
                    return r0
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean isEngagementSignalsApiAvailable(android.support.customtabs.ICustomTabsCallback r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L37
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L37
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L37
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L37
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L37
                    r2 = 13
                    boolean r5 = r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L37
                    if (r5 == 0) goto L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L37
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L37
                    if (r5 == 0) goto L28
                    r4 = 1
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L2f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L37
                    java.lang.String r5 = "Method isEngagementSignalsApiAvailable is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L37
                    throw r4     // Catch: java.lang.Throwable -> L37
                L37:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean mayLaunchUrl(android.support.customtabs.ICustomTabsCallback r4, android.net.Uri r5, android.os.Bundle r6, java.util.List<android.os.Bundle> r7) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L3c
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L3c
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L3c
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L3c
                    r0.writeTypedObject(r6, r4)     // Catch: java.lang.Throwable -> L3c
                    android.support.customtabs.ICustomTabsService._Parcel.access$000(r0, r7, r4)     // Catch: java.lang.Throwable -> L3c
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L3c
                    r6 = 4
                    boolean r5 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L3c
                    if (r5 == 0) goto L34
                    r1.readException()     // Catch: java.lang.Throwable -> L3c
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L3c
                    if (r5 == 0) goto L2d
                    r4 = 1
                L2d:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L34:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L3c
                    java.lang.String r5 = "Method mayLaunchUrl is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L3c
                    throw r4     // Catch: java.lang.Throwable -> L3c
                L3c:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean newAuthTabSession(android.support.customtabs.IAuthTabCallback r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L37
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L37
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L37
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L37
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L37
                    r2 = 18
                    boolean r5 = r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L37
                    if (r5 == 0) goto L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L37
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L37
                    if (r5 == 0) goto L28
                    r4 = 1
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L2f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L37
                    java.lang.String r5 = "Method newAuthTabSession is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L37
                    throw r4     // Catch: java.lang.Throwable -> L37
                L37:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean newSession(android.support.customtabs.ICustomTabsCallback r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L33
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L33
                    r0.writeStrongInterface(r5)     // Catch: java.lang.Throwable -> L33
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L33
                    r2 = 3
                    r3 = 0
                    boolean r5 = r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L33
                    if (r5 == 0) goto L2b
                    r1.readException()     // Catch: java.lang.Throwable -> L33
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L33
                    if (r5 == 0) goto L24
                    r3 = 1
                L24:
                    r1.recycle()
                    r0.recycle()
                    return r3
                L2b:
                    android.os.RemoteException r5 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L33
                    java.lang.String r2 = "Method newSession is unimplemented."
                    r5.<init>(r2)     // Catch: java.lang.Throwable -> L33
                    throw r5     // Catch: java.lang.Throwable -> L33
                L33:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean newSessionWithExtras(android.support.customtabs.ICustomTabsCallback r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L37
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L37
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L37
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L37
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L37
                    r2 = 10
                    boolean r5 = r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L37
                    if (r5 == 0) goto L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L37
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L37
                    if (r5 == 0) goto L28
                    r4 = 1
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L2f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L37
                    java.lang.String r5 = "Method newSessionWithExtras is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L37
                    throw r4     // Catch: java.lang.Throwable -> L37
                L37:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public int postMessage(android.support.customtabs.ICustomTabsCallback r4, java.lang.String r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L37
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L37
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L37
                    r0.writeString(r5)     // Catch: java.lang.Throwable -> L37
                    r4 = 0
                    r0.writeTypedObject(r6, r4)     // Catch: java.lang.Throwable -> L37
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L37
                    r6 = 8
                    boolean r4 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L37
                    if (r4 == 0) goto L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L37
                    int r4 = r1.readInt()     // Catch: java.lang.Throwable -> L37
                    r1.recycle()
                    r0.recycle()
                    return r4
                L2f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L37
                    java.lang.String r5 = "Method postMessage is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L37
                    throw r4     // Catch: java.lang.Throwable -> L37
                L37:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public void prefetch(android.support.customtabs.ICustomTabsCallback r4, android.net.Uri r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L33
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L33
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L33
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L33
                    r0.writeTypedObject(r6, r4)     // Catch: java.lang.Throwable -> L33
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L33
                    r6 = 15
                    boolean r4 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L33
                    if (r4 == 0) goto L2b
                    r1.readException()     // Catch: java.lang.Throwable -> L33
                    r1.recycle()
                    r0.recycle()
                    return
                L2b:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L33
                    java.lang.String r5 = "Method prefetch is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L33
                    throw r4     // Catch: java.lang.Throwable -> L33
                L33:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public void prefetchWithMultipleUrls(android.support.customtabs.ICustomTabsCallback r4, java.util.List<android.net.Uri> r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L33
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L33
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L33
                    r4 = 0
                    android.support.customtabs.ICustomTabsService._Parcel.access$000(r0, r5, r4)     // Catch: java.lang.Throwable -> L33
                    r0.writeTypedObject(r6, r4)     // Catch: java.lang.Throwable -> L33
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L33
                    r6 = 16
                    boolean r4 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L33
                    if (r4 == 0) goto L2b
                    r1.readException()     // Catch: java.lang.Throwable -> L33
                    r1.recycle()
                    r0.recycle()
                    return
                L2b:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L33
                    java.lang.String r5 = "Method prefetchWithMultipleUrls is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L33
                    throw r4     // Catch: java.lang.Throwable -> L33
                L33:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean receiveFile(android.support.customtabs.ICustomTabsCallback r4, android.net.Uri r5, int r6, android.os.Bundle r7) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L3d
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L3d
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L3d
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L3d
                    r0.writeInt(r6)     // Catch: java.lang.Throwable -> L3d
                    r0.writeTypedObject(r7, r4)     // Catch: java.lang.Throwable -> L3d
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L3d
                    r6 = 12
                    boolean r5 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L3d
                    if (r5 == 0) goto L35
                    r1.readException()     // Catch: java.lang.Throwable -> L3d
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L3d
                    if (r5 == 0) goto L2e
                    r4 = 1
                L2e:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L35:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L3d
                    java.lang.String r5 = "Method receiveFile is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L3d
                    throw r4     // Catch: java.lang.Throwable -> L3d
                L3d:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean requestPostMessageChannel(android.support.customtabs.ICustomTabsCallback r4, android.net.Uri r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L36
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L36
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L36
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L36
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L36
                    r2 = 7
                    boolean r5 = r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L36
                    if (r5 == 0) goto L2e
                    r1.readException()     // Catch: java.lang.Throwable -> L36
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L36
                    if (r5 == 0) goto L27
                    r4 = 1
                L27:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L2e:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L36
                    java.lang.String r5 = "Method requestPostMessageChannel is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L36
                    throw r4     // Catch: java.lang.Throwable -> L36
                L36:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean requestPostMessageChannelWithExtras(android.support.customtabs.ICustomTabsCallback r4, android.net.Uri r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L3a
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L3a
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L3a
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L3a
                    r0.writeTypedObject(r6, r4)     // Catch: java.lang.Throwable -> L3a
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L3a
                    r6 = 11
                    boolean r5 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L3a
                    if (r5 == 0) goto L32
                    r1.readException()     // Catch: java.lang.Throwable -> L3a
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L3a
                    if (r5 == 0) goto L2b
                    r4 = 1
                L2b:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L32:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L3a
                    java.lang.String r5 = "Method requestPostMessageChannelWithExtras is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L3a
                    throw r4     // Catch: java.lang.Throwable -> L3a
                L3a:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean setEngagementSignalsCallback(android.support.customtabs.ICustomTabsCallback r4, android.os.IBinder r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L3a
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L3a
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L3a
                    r0.writeStrongBinder(r5)     // Catch: java.lang.Throwable -> L3a
                    r4 = 0
                    r0.writeTypedObject(r6, r4)     // Catch: java.lang.Throwable -> L3a
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L3a
                    r6 = 14
                    boolean r5 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L3a
                    if (r5 == 0) goto L32
                    r1.readException()     // Catch: java.lang.Throwable -> L3a
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L3a
                    if (r5 == 0) goto L2b
                    r4 = 1
                L2b:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L32:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L3a
                    java.lang.String r5 = "Method setEngagementSignalsCallback is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L3a
                    throw r4     // Catch: java.lang.Throwable -> L3a
                L3a:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean updateVisuals(android.support.customtabs.ICustomTabsCallback r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L36
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L36
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L36
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L36
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L36
                    r2 = 6
                    boolean r5 = r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L36
                    if (r5 == 0) goto L2e
                    r1.readException()     // Catch: java.lang.Throwable -> L36
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L36
                    if (r5 == 0) goto L27
                    r4 = 1
                L27:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L2e:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L36
                    java.lang.String r5 = "Method updateVisuals is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L36
                    throw r4     // Catch: java.lang.Throwable -> L36
                L36:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean validateRelationship(android.support.customtabs.ICustomTabsCallback r4, int r5, android.net.Uri r6, android.os.Bundle r7) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L3d
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L3d
                    r0.writeStrongInterface(r4)     // Catch: java.lang.Throwable -> L3d
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L3d
                    r4 = 0
                    r0.writeTypedObject(r6, r4)     // Catch: java.lang.Throwable -> L3d
                    r0.writeTypedObject(r7, r4)     // Catch: java.lang.Throwable -> L3d
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L3d
                    r6 = 9
                    boolean r5 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L3d
                    if (r5 == 0) goto L35
                    r1.readException()     // Catch: java.lang.Throwable -> L3d
                    int r5 = r1.readInt()     // Catch: java.lang.Throwable -> L3d
                    if (r5 == 0) goto L2e
                    r4 = 1
                L2e:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L35:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L3d
                    java.lang.String r5 = "Method validateRelationship is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L3d
                    throw r4     // Catch: java.lang.Throwable -> L3d
                L3d:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsService
            public boolean warmup(long r4) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L33
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L33
                    r0.writeLong(r4)     // Catch: java.lang.Throwable -> L33
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L33
                    r5 = 2
                    r2 = 0
                    boolean r4 = r4.transact(r5, r0, r1, r2)     // Catch: java.lang.Throwable -> L33
                    if (r4 == 0) goto L2b
                    r1.readException()     // Catch: java.lang.Throwable -> L33
                    int r4 = r1.readInt()     // Catch: java.lang.Throwable -> L33
                    if (r4 == 0) goto L24
                    r2 = 1
                L24:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L2b:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L33
                    java.lang.String r5 = "Method warmup is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L33
                    throw r4     // Catch: java.lang.Throwable -> L33
                L33:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }
        }

        public Stub() {
                r1 = this;
                r1.<init>()
                java.lang.String r0 = android.support.customtabs.ICustomTabsService.Stub.DESCRIPTOR
                r1.attachInterface(r1, r0)
                return
        }

        public static android.support.customtabs.ICustomTabsService asInterface(android.os.IBinder r2) {
                if (r2 != 0) goto L4
                r2 = 0
                return r2
            L4:
                java.lang.String r0 = android.support.customtabs.ICustomTabsService.Stub.DESCRIPTOR
                android.os.IInterface r0 = r2.queryLocalInterface(r0)
                if (r0 == 0) goto L13
                boolean r1 = r0 instanceof android.support.customtabs.ICustomTabsService
                if (r1 == 0) goto L13
                android.support.customtabs.ICustomTabsService r0 = (android.support.customtabs.ICustomTabsService) r0
                return r0
            L13:
                android.support.customtabs.ICustomTabsService$Stub$Proxy r0 = new android.support.customtabs.ICustomTabsService$Stub$Proxy
                r0.<init>(r2)
                return r0
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r0 = this;
                return r0
        }

        @Override // android.os.Binder
        public boolean onTransact(int r5, android.os.Parcel r6, android.os.Parcel r7, int r8) throws android.os.RemoteException {
                r4 = this;
                java.lang.String r0 = android.support.customtabs.ICustomTabsService.Stub.DESCRIPTOR
                r1 = 16777215(0xffffff, float:2.3509886E-38)
                r2 = 1
                if (r5 < r2) goto Ld
                if (r5 > r1) goto Ld
                r6.enforceInterface(r0)
            Ld:
                r3 = 1598968902(0x5f4e5446, float:1.4867585E19)
                if (r5 != r3) goto L16
                r7.writeString(r0)
                return r2
            L16:
                if (r5 != r1) goto L23
                r7.writeNoException()
                int r5 = r4.getInterfaceVersion()
                r7.writeInt(r5)
                return r2
            L23:
                switch(r5) {
                    case 2: goto L1fb;
                    case 3: goto L1e8;
                    case 4: goto L1bf;
                    case 5: goto L1a8;
                    case 6: goto L18d;
                    case 7: goto L171;
                    case 8: goto L151;
                    case 9: goto L129;
                    case 10: goto L10d;
                    case 11: goto Le9;
                    case 12: goto Lc1;
                    case 13: goto La5;
                    case 14: goto L85;
                    case 15: goto L65;
                    case 16: goto L47;
                    case 17: goto L26;
                    case 18: goto L2b;
                    default: goto L26;
                }
            L26:
                boolean r5 = super.onTransact(r5, r6, r7, r8)
                return r5
            L2b:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.IAuthTabCallback r5 = android.support.customtabs.IAuthTabCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r8)
                android.os.Bundle r6 = (android.os.Bundle) r6
                boolean r5 = r4.newAuthTabSession(r5, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L47:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.net.Uri.CREATOR
                java.util.ArrayList r8 = r6.createTypedArrayList(r8)
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r0)
                android.os.Bundle r6 = (android.os.Bundle) r6
                r4.prefetchWithMultipleUrls(r5, r8, r6)
                r7.writeNoException()
                goto L209
            L65:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.net.Uri.CREATOR
                java.lang.Object r8 = r6.readTypedObject(r8)
                android.net.Uri r8 = (android.net.Uri) r8
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r0)
                android.os.Bundle r6 = (android.os.Bundle) r6
                r4.prefetch(r5, r8, r6)
                r7.writeNoException()
                goto L209
            L85:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.IBinder r8 = r6.readStrongBinder()
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r0)
                android.os.Bundle r6 = (android.os.Bundle) r6
                boolean r5 = r4.setEngagementSignalsCallback(r5, r8, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            La5:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r8)
                android.os.Bundle r6 = (android.os.Bundle) r6
                boolean r5 = r4.isEngagementSignalsApiAvailable(r5, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            Lc1:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.net.Uri.CREATOR
                java.lang.Object r8 = r6.readTypedObject(r8)
                android.net.Uri r8 = (android.net.Uri) r8
                int r0 = r6.readInt()
                android.os.Parcelable$Creator r1 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r1)
                android.os.Bundle r6 = (android.os.Bundle) r6
                boolean r5 = r4.receiveFile(r5, r8, r0, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            Le9:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.net.Uri.CREATOR
                java.lang.Object r8 = r6.readTypedObject(r8)
                android.net.Uri r8 = (android.net.Uri) r8
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r0)
                android.os.Bundle r6 = (android.os.Bundle) r6
                boolean r5 = r4.requestPostMessageChannelWithExtras(r5, r8, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L10d:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r8)
                android.os.Bundle r6 = (android.os.Bundle) r6
                boolean r5 = r4.newSessionWithExtras(r5, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L129:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                int r8 = r6.readInt()
                android.os.Parcelable$Creator r0 = android.net.Uri.CREATOR
                java.lang.Object r0 = r6.readTypedObject(r0)
                android.net.Uri r0 = (android.net.Uri) r0
                android.os.Parcelable$Creator r1 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r1)
                android.os.Bundle r6 = (android.os.Bundle) r6
                boolean r5 = r4.validateRelationship(r5, r8, r0, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L151:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                java.lang.String r8 = r6.readString()
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r0)
                android.os.Bundle r6 = (android.os.Bundle) r6
                int r5 = r4.postMessage(r5, r8, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L171:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.net.Uri.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r8)
                android.net.Uri r6 = (android.net.Uri) r6
                boolean r5 = r4.requestPostMessageChannel(r5, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L18d:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r8)
                android.os.Bundle r6 = (android.os.Bundle) r6
                boolean r5 = r4.updateVisuals(r5, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L1a8:
                java.lang.String r5 = r6.readString()
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r8)
                android.os.Bundle r6 = (android.os.Bundle) r6
                android.os.Bundle r5 = r4.extraCommand(r5, r6)
                r7.writeNoException()
                r7.writeTypedObject(r5, r2)
                goto L209
            L1bf:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                android.os.Parcelable$Creator r8 = android.net.Uri.CREATOR
                java.lang.Object r8 = r6.readTypedObject(r8)
                android.net.Uri r8 = (android.net.Uri) r8
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r6.readTypedObject(r0)
                android.os.Bundle r0 = (android.os.Bundle) r0
                android.os.Parcelable$Creator r1 = android.os.Bundle.CREATOR
                java.util.ArrayList r6 = r6.createTypedArrayList(r1)
                boolean r5 = r4.mayLaunchUrl(r5, r8, r0, r6)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L1e8:
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.customtabs.ICustomTabsCallback r5 = android.support.customtabs.ICustomTabsCallback.Stub.asInterface(r5)
                boolean r5 = r4.newSession(r5)
                r7.writeNoException()
                r7.writeInt(r5)
                goto L209
            L1fb:
                long r5 = r6.readLong()
                boolean r5 = r4.warmup(r5)
                r7.writeNoException()
                r7.writeInt(r5)
            L209:
                return r2
        }
    }

    public static class _Parcel {
        public _Parcel() {
                r0 = this;
                r0.<init>()
                return
        }

        static /* synthetic */ void access$000(android.os.Parcel r0, java.util.List r1, int r2) {
                writeTypedList(r0, r1, r2)
                return
        }

        private static <T extends android.os.Parcelable> void writeTypedList(android.os.Parcel r3, java.util.List<T> r4, int r5) {
                if (r4 != 0) goto L7
                r4 = -1
                r3.writeInt(r4)
                return
            L7:
                int r0 = r4.size()
                r3.writeInt(r0)
                r1 = 0
            Lf:
                if (r1 >= r0) goto L1d
                java.lang.Object r2 = r4.get(r1)
                android.os.Parcelable r2 = (android.os.Parcelable) r2
                r3.writeTypedObject(r2, r5)
                int r1 = r1 + 1
                goto Lf
            L1d:
                return
        }
    }

    static {
            r0 = 36
            r1 = 46
            java.lang.String r2 = "android$support$customtabs$ICustomTabsService"
            java.lang.String r0 = r2.replace(r0, r1)
            android.support.customtabs.ICustomTabsService.DESCRIPTOR = r0
            return
    }

    android.os.Bundle extraCommand(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    int getInterfaceVersion() throws android.os.RemoteException;

    boolean isEngagementSignalsApiAvailable(android.support.customtabs.ICustomTabsCallback r1, android.os.Bundle r2) throws android.os.RemoteException;

    boolean mayLaunchUrl(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2, android.os.Bundle r3, java.util.List<android.os.Bundle> r4) throws android.os.RemoteException;

    boolean newAuthTabSession(android.support.customtabs.IAuthTabCallback r1, android.os.Bundle r2) throws android.os.RemoteException;

    boolean newSession(android.support.customtabs.ICustomTabsCallback r1) throws android.os.RemoteException;

    boolean newSessionWithExtras(android.support.customtabs.ICustomTabsCallback r1, android.os.Bundle r2) throws android.os.RemoteException;

    int postMessage(android.support.customtabs.ICustomTabsCallback r1, java.lang.String r2, android.os.Bundle r3) throws android.os.RemoteException;

    void prefetch(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2, android.os.Bundle r3) throws android.os.RemoteException;

    void prefetchWithMultipleUrls(android.support.customtabs.ICustomTabsCallback r1, java.util.List<android.net.Uri> r2, android.os.Bundle r3) throws android.os.RemoteException;

    boolean receiveFile(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2, int r3, android.os.Bundle r4) throws android.os.RemoteException;

    boolean requestPostMessageChannel(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2) throws android.os.RemoteException;

    boolean requestPostMessageChannelWithExtras(android.support.customtabs.ICustomTabsCallback r1, android.net.Uri r2, android.os.Bundle r3) throws android.os.RemoteException;

    boolean setEngagementSignalsCallback(android.support.customtabs.ICustomTabsCallback r1, android.os.IBinder r2, android.os.Bundle r3) throws android.os.RemoteException;

    boolean updateVisuals(android.support.customtabs.ICustomTabsCallback r1, android.os.Bundle r2) throws android.os.RemoteException;

    boolean validateRelationship(android.support.customtabs.ICustomTabsCallback r1, int r2, android.net.Uri r3, android.os.Bundle r4) throws android.os.RemoteException;

    boolean warmup(long r1) throws android.os.RemoteException;
}
