package android.support.customtabs.trusted;

/* JADX INFO: loaded from: classes.dex */
public interface ITrustedWebActivityService extends android.os.IInterface {
    public static final java.lang.String DESCRIPTOR = null;
    public static final int VERSION = 1;

    public static class Default implements android.support.customtabs.trusted.ITrustedWebActivityService {
        public Default() {
                r0 = this;
                r0.<init>()
                return
        }

        @Override // android.support.customtabs.trusted.ITrustedWebActivityService
        public android.os.Bundle areNotificationsEnabled(android.os.Bundle r1) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.trusted.ITrustedWebActivityService
        public void cancelNotification(android.os.Bundle r1) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.trusted.ITrustedWebActivityService
        public android.os.Bundle extraCommand(java.lang.String r1, android.os.Bundle r2, android.os.IBinder r3) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.trusted.ITrustedWebActivityService
        public android.os.Bundle getActiveNotifications() throws android.os.RemoteException {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.trusted.ITrustedWebActivityService
        public int getInterfaceVersion() {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.trusted.ITrustedWebActivityService
        public android.os.Bundle getSmallIconBitmap() throws android.os.RemoteException {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.trusted.ITrustedWebActivityService
        public int getSmallIconId() throws android.os.RemoteException {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.trusted.ITrustedWebActivityService
        public android.os.Bundle notifyNotificationWithChannel(android.os.Bundle r1) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }
    }

    public static abstract class Stub extends android.os.Binder implements android.support.customtabs.trusted.ITrustedWebActivityService {
        static final int TRANSACTION_areNotificationsEnabled = 6;
        static final int TRANSACTION_cancelNotification = 3;
        static final int TRANSACTION_extraCommand = 9;
        static final int TRANSACTION_getActiveNotifications = 5;
        static final int TRANSACTION_getInterfaceVersion = 16777215;
        static final int TRANSACTION_getSmallIconBitmap = 7;
        static final int TRANSACTION_getSmallIconId = 4;
        static final int TRANSACTION_notifyNotificationWithChannel = 2;

        private static class Proxy implements android.support.customtabs.trusted.ITrustedWebActivityService {
            private int mCachedVersion;
            private android.os.IBinder mRemote;

            Proxy(android.os.IBinder r2) {
                    r1 = this;
                    r1.<init>()
                    r0 = -1
                    r1.mCachedVersion = r0
                    r1.mRemote = r2
                    return
            }

            @Override // android.support.customtabs.trusted.ITrustedWebActivityService
            public android.os.Bundle areNotificationsEnabled(android.os.Bundle r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L34
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L34
                    r2 = 0
                    r0.writeTypedObject(r5, r2)     // Catch: java.lang.Throwable -> L34
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L34
                    r3 = 6
                    boolean r5 = r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L34
                    if (r5 == 0) goto L2c
                    r1.readException()     // Catch: java.lang.Throwable -> L34
                    android.os.Parcelable$Creator r5 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L34
                    java.lang.Object r5 = r1.readTypedObject(r5)     // Catch: java.lang.Throwable -> L34
                    android.os.Bundle r5 = (android.os.Bundle) r5     // Catch: java.lang.Throwable -> L34
                    r1.recycle()
                    r0.recycle()
                    return r5
                L2c:
                    android.os.RemoteException r5 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L34
                    java.lang.String r2 = "Method areNotificationsEnabled is unimplemented."
                    r5.<init>(r2)     // Catch: java.lang.Throwable -> L34
                    throw r5     // Catch: java.lang.Throwable -> L34
                L34:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.os.IInterface
            public android.os.IBinder asBinder() {
                    r1 = this;
                    android.os.IBinder r0 = r1.mRemote
                    return r0
            }

            @Override // android.support.customtabs.trusted.ITrustedWebActivityService
            public void cancelNotification(android.os.Bundle r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2c
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2c
                    r2 = 0
                    r0.writeTypedObject(r5, r2)     // Catch: java.lang.Throwable -> L2c
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L2c
                    r3 = 3
                    boolean r5 = r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L2c
                    if (r5 == 0) goto L24
                    r1.readException()     // Catch: java.lang.Throwable -> L2c
                    r1.recycle()
                    r0.recycle()
                    return
                L24:
                    android.os.RemoteException r5 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L2c
                    java.lang.String r2 = "Method cancelNotification is unimplemented."
                    r5.<init>(r2)     // Catch: java.lang.Throwable -> L2c
                    throw r5     // Catch: java.lang.Throwable -> L2c
                L2c:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.customtabs.trusted.ITrustedWebActivityService
            public android.os.Bundle extraCommand(java.lang.String r4, android.os.Bundle r5, android.os.IBinder r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L3b
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L3b
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L3b
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L3b
                    r0.writeStrongBinder(r6)     // Catch: java.lang.Throwable -> L3b
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L3b
                    r6 = 9
                    boolean r4 = r5.transact(r6, r0, r1, r4)     // Catch: java.lang.Throwable -> L3b
                    if (r4 == 0) goto L33
                    r1.readException()     // Catch: java.lang.Throwable -> L3b
                    android.os.Parcelable$Creator r4 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L3b
                    java.lang.Object r4 = r1.readTypedObject(r4)     // Catch: java.lang.Throwable -> L3b
                    android.os.Bundle r4 = (android.os.Bundle) r4     // Catch: java.lang.Throwable -> L3b
                    r1.recycle()
                    r0.recycle()
                    return r4
                L33:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L3b
                    java.lang.String r5 = "Method extraCommand is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L3b
                    throw r4     // Catch: java.lang.Throwable -> L3b
                L3b:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.trusted.ITrustedWebActivityService
            public android.os.Bundle getActiveNotifications() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L31
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L31
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L31
                    r3 = 5
                    r4 = 0
                    boolean r2 = r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L31
                    if (r2 == 0) goto L29
                    r1.readException()     // Catch: java.lang.Throwable -> L31
                    android.os.Parcelable$Creator r2 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L31
                    java.lang.Object r2 = r1.readTypedObject(r2)     // Catch: java.lang.Throwable -> L31
                    android.os.Bundle r2 = (android.os.Bundle) r2     // Catch: java.lang.Throwable -> L31
                    r1.recycle()
                    r0.recycle()
                    return r2
                L29:
                    android.os.RemoteException r2 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L31
                    java.lang.String r3 = "Method getActiveNotifications is unimplemented."
                    r2.<init>(r3)     // Catch: java.lang.Throwable -> L31
                    throw r2     // Catch: java.lang.Throwable -> L31
                L31:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            public java.lang.String getInterfaceDescriptor() {
                    r1 = this;
                    java.lang.String r0 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR
                    return r0
            }

            @Override // android.support.customtabs.trusted.ITrustedWebActivityService
            public int getInterfaceVersion() throws android.os.RemoteException {
                    r5 = this;
                    int r0 = r5.mCachedVersion
                    r1 = -1
                    if (r0 != r1) goto L33
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2b
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2b
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2b
                    r3 = 16777215(0xffffff, float:2.3509886E-38)
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2b
                    r1.readException()     // Catch: java.lang.Throwable -> L2b
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2b
                    r5.mCachedVersion = r2     // Catch: java.lang.Throwable -> L2b
                    r1.recycle()
                    r0.recycle()
                    goto L33
                L2b:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
                L33:
                    int r0 = r5.mCachedVersion
                    return r0
            }

            @Override // android.support.customtabs.trusted.ITrustedWebActivityService
            public android.os.Bundle getSmallIconBitmap() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L31
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L31
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L31
                    r3 = 7
                    r4 = 0
                    boolean r2 = r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L31
                    if (r2 == 0) goto L29
                    r1.readException()     // Catch: java.lang.Throwable -> L31
                    android.os.Parcelable$Creator r2 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L31
                    java.lang.Object r2 = r1.readTypedObject(r2)     // Catch: java.lang.Throwable -> L31
                    android.os.Bundle r2 = (android.os.Bundle) r2     // Catch: java.lang.Throwable -> L31
                    r1.recycle()
                    r0.recycle()
                    return r2
                L29:
                    android.os.RemoteException r2 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L31
                    java.lang.String r3 = "Method getSmallIconBitmap is unimplemented."
                    r2.<init>(r3)     // Catch: java.lang.Throwable -> L31
                    throw r2     // Catch: java.lang.Throwable -> L31
                L31:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.customtabs.trusted.ITrustedWebActivityService
            public int getSmallIconId() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2d
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2d
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2d
                    r3 = 4
                    r4 = 0
                    boolean r2 = r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2d
                    if (r2 == 0) goto L25
                    r1.readException()     // Catch: java.lang.Throwable -> L2d
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2d
                    r1.recycle()
                    r0.recycle()
                    return r2
                L25:
                    android.os.RemoteException r2 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L2d
                    java.lang.String r3 = "Method getSmallIconId is unimplemented."
                    r2.<init>(r3)     // Catch: java.lang.Throwable -> L2d
                    throw r2     // Catch: java.lang.Throwable -> L2d
                L2d:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.customtabs.trusted.ITrustedWebActivityService
            public android.os.Bundle notifyNotificationWithChannel(android.os.Bundle r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L34
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L34
                    r2 = 0
                    r0.writeTypedObject(r5, r2)     // Catch: java.lang.Throwable -> L34
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L34
                    r3 = 2
                    boolean r5 = r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L34
                    if (r5 == 0) goto L2c
                    r1.readException()     // Catch: java.lang.Throwable -> L34
                    android.os.Parcelable$Creator r5 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L34
                    java.lang.Object r5 = r1.readTypedObject(r5)     // Catch: java.lang.Throwable -> L34
                    android.os.Bundle r5 = (android.os.Bundle) r5     // Catch: java.lang.Throwable -> L34
                    r1.recycle()
                    r0.recycle()
                    return r5
                L2c:
                    android.os.RemoteException r5 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L34
                    java.lang.String r2 = "Method notifyNotificationWithChannel is unimplemented."
                    r5.<init>(r2)     // Catch: java.lang.Throwable -> L34
                    throw r5     // Catch: java.lang.Throwable -> L34
                L34:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }
        }

        public Stub() {
                r1 = this;
                r1.<init>()
                java.lang.String r0 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.DESCRIPTOR
                r1.attachInterface(r1, r0)
                return
        }

        public static android.support.customtabs.trusted.ITrustedWebActivityService asInterface(android.os.IBinder r2) {
                if (r2 != 0) goto L4
                r2 = 0
                return r2
            L4:
                java.lang.String r0 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.DESCRIPTOR
                android.os.IInterface r0 = r2.queryLocalInterface(r0)
                if (r0 == 0) goto L13
                boolean r1 = r0 instanceof android.support.customtabs.trusted.ITrustedWebActivityService
                if (r1 == 0) goto L13
                android.support.customtabs.trusted.ITrustedWebActivityService r0 = (android.support.customtabs.trusted.ITrustedWebActivityService) r0
                return r0
            L13:
                android.support.customtabs.trusted.ITrustedWebActivityService$Stub$Proxy r0 = new android.support.customtabs.trusted.ITrustedWebActivityService$Stub$Proxy
                r0.<init>(r2)
                return r0
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r0 = this;
                return r0
        }

        @Override // android.os.Binder
        public boolean onTransact(int r5, android.os.Parcel r6, android.os.Parcel r7, int r8) throws android.os.RemoteException {
                r4 = this;
                java.lang.String r0 = android.support.customtabs.trusted.ITrustedWebActivityService.Stub.DESCRIPTOR
                r1 = 16777215(0xffffff, float:2.3509886E-38)
                r2 = 1
                if (r5 < r2) goto Ld
                if (r5 > r1) goto Ld
                r6.enforceInterface(r0)
            Ld:
                r3 = 1598968902(0x5f4e5446, float:1.4867585E19)
                if (r5 != r3) goto L16
                r7.writeString(r0)
                return r2
            L16:
                if (r5 != r1) goto L23
                r7.writeNoException()
                int r5 = r4.getInterfaceVersion()
                r7.writeInt(r5)
                return r2
            L23:
                switch(r5) {
                    case 2: goto L89;
                    case 3: goto L7a;
                    case 4: goto L6f;
                    case 5: goto L64;
                    case 6: goto L51;
                    case 7: goto L46;
                    case 8: goto L26;
                    case 9: goto L2b;
                    default: goto L26;
                }
            L26:
                boolean r5 = super.onTransact(r5, r6, r7, r8)
                return r5
            L2b:
                java.lang.String r5 = r6.readString()
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r8 = r6.readTypedObject(r8)
                android.os.Bundle r8 = (android.os.Bundle) r8
                android.os.IBinder r6 = r6.readStrongBinder()
                android.os.Bundle r5 = r4.extraCommand(r5, r8, r6)
                r7.writeNoException()
                r7.writeTypedObject(r5, r2)
                goto L9b
            L46:
                android.os.Bundle r5 = r4.getSmallIconBitmap()
                r7.writeNoException()
                r7.writeTypedObject(r5, r2)
                goto L9b
            L51:
                android.os.Parcelable$Creator r5 = android.os.Bundle.CREATOR
                java.lang.Object r5 = r6.readTypedObject(r5)
                android.os.Bundle r5 = (android.os.Bundle) r5
                android.os.Bundle r5 = r4.areNotificationsEnabled(r5)
                r7.writeNoException()
                r7.writeTypedObject(r5, r2)
                goto L9b
            L64:
                android.os.Bundle r5 = r4.getActiveNotifications()
                r7.writeNoException()
                r7.writeTypedObject(r5, r2)
                goto L9b
            L6f:
                int r5 = r4.getSmallIconId()
                r7.writeNoException()
                r7.writeInt(r5)
                goto L9b
            L7a:
                android.os.Parcelable$Creator r5 = android.os.Bundle.CREATOR
                java.lang.Object r5 = r6.readTypedObject(r5)
                android.os.Bundle r5 = (android.os.Bundle) r5
                r4.cancelNotification(r5)
                r7.writeNoException()
                goto L9b
            L89:
                android.os.Parcelable$Creator r5 = android.os.Bundle.CREATOR
                java.lang.Object r5 = r6.readTypedObject(r5)
                android.os.Bundle r5 = (android.os.Bundle) r5
                android.os.Bundle r5 = r4.notifyNotificationWithChannel(r5)
                r7.writeNoException()
                r7.writeTypedObject(r5, r2)
            L9b:
                return r2
        }
    }

    static {
            r0 = 36
            r1 = 46
            java.lang.String r2 = "android$support$customtabs$trusted$ITrustedWebActivityService"
            java.lang.String r0 = r2.replace(r0, r1)
            android.support.customtabs.trusted.ITrustedWebActivityService.DESCRIPTOR = r0
            return
    }

    android.os.Bundle areNotificationsEnabled(android.os.Bundle r1) throws android.os.RemoteException;

    void cancelNotification(android.os.Bundle r1) throws android.os.RemoteException;

    android.os.Bundle extraCommand(java.lang.String r1, android.os.Bundle r2, android.os.IBinder r3) throws android.os.RemoteException;

    android.os.Bundle getActiveNotifications() throws android.os.RemoteException;

    int getInterfaceVersion() throws android.os.RemoteException;

    android.os.Bundle getSmallIconBitmap() throws android.os.RemoteException;

    int getSmallIconId() throws android.os.RemoteException;

    android.os.Bundle notifyNotificationWithChannel(android.os.Bundle r1) throws android.os.RemoteException;
}
