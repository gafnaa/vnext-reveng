package android.support.customtabs;

/* JADX INFO: loaded from: classes.dex */
public interface ICustomTabsCallback extends android.os.IInterface {
    public static final java.lang.String DESCRIPTOR = null;
    public static final int VERSION = 1;

    public static class Default implements android.support.customtabs.ICustomTabsCallback {
        public Default() {
                r0 = this;
                r0.<init>()
                return
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void extraCallback(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public android.os.Bundle extraCallbackWithResult(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                r1 = 0
                return r1
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public int getInterfaceVersion() {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onActivityLayout(int r1, int r2, int r3, int r4, int r5, android.os.Bundle r6) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onActivityResized(int r1, int r2, android.os.Bundle r3) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onMessageChannelReady(android.os.Bundle r1) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onMinimized(android.os.Bundle r1) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onNavigationEvent(int r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onPostMessage(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onRelationshipValidationResult(int r1, android.net.Uri r2, boolean r3, android.os.Bundle r4) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onUnminimized(android.os.Bundle r1) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.ICustomTabsCallback
        public void onWarmupCompleted(android.os.Bundle r1) throws android.os.RemoteException {
                r0 = this;
                return
        }
    }

    public static abstract class Stub extends android.os.Binder implements android.support.customtabs.ICustomTabsCallback {
        static final int TRANSACTION_extraCallback = 3;
        static final int TRANSACTION_extraCallbackWithResult = 7;
        static final int TRANSACTION_getInterfaceVersion = 16777215;
        static final int TRANSACTION_onActivityLayout = 10;
        static final int TRANSACTION_onActivityResized = 8;
        static final int TRANSACTION_onMessageChannelReady = 4;
        static final int TRANSACTION_onMinimized = 11;
        static final int TRANSACTION_onNavigationEvent = 2;
        static final int TRANSACTION_onPostMessage = 5;
        static final int TRANSACTION_onRelationshipValidationResult = 6;
        static final int TRANSACTION_onUnminimized = 12;
        static final int TRANSACTION_onWarmupCompleted = 9;

        private static class Proxy implements android.support.customtabs.ICustomTabsCallback {
            private int mCachedVersion;
            private android.os.IBinder mRemote;

            Proxy(android.os.IBinder r2) {
                    r1 = this;
                    r1.<init>()
                    r0 = -1
                    r1.mCachedVersion = r0
                    r1.mRemote = r2
                    return
            }

            @Override // android.os.IInterface
            public android.os.IBinder asBinder() {
                    r1 = this;
                    android.os.IBinder r0 = r1.mRemote
                    return r0
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void extraCallback(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L27
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L27
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L27
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L27
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L27
                    r5 = 0
                    r1 = 1
                    r2 = 3
                    boolean r4 = r4.transact(r2, r0, r5, r1)     // Catch: java.lang.Throwable -> L27
                    if (r4 == 0) goto L1f
                    r0.recycle()
                    return
                L1f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L27
                    java.lang.String r5 = "Method extraCallback is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L27
                    throw r4     // Catch: java.lang.Throwable -> L27
                L27:
                    r4 = move-exception
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public android.os.Bundle extraCallbackWithResult(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L37
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L37
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L37
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L37
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L37
                    r2 = 7
                    boolean r4 = r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L37
                    if (r4 == 0) goto L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L37
                    android.os.Parcelable$Creator r4 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L37
                    java.lang.Object r4 = r1.readTypedObject(r4)     // Catch: java.lang.Throwable -> L37
                    android.os.Bundle r4 = (android.os.Bundle) r4     // Catch: java.lang.Throwable -> L37
                    r1.recycle()
                    r0.recycle()
                    return r4
                L2f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L37
                    java.lang.String r5 = "Method extraCallbackWithResult is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L37
                    throw r4     // Catch: java.lang.Throwable -> L37
                L37:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            public java.lang.String getInterfaceDescriptor() {
                    r1 = this;
                    java.lang.String r0 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR
                    return r0
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public int getInterfaceVersion() throws android.os.RemoteException {
                    r5 = this;
                    int r0 = r5.mCachedVersion
                    r1 = -1
                    if (r0 != r1) goto L33
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2b
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2b
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2b
                    r3 = 16777215(0xffffff, float:2.3509886E-38)
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2b
                    r1.readException()     // Catch: java.lang.Throwable -> L2b
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2b
                    r5.mCachedVersion = r2     // Catch: java.lang.Throwable -> L2b
                    r1.recycle()
                    r0.recycle()
                    goto L33
                L2b:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
                L33:
                    int r0 = r5.mCachedVersion
                    return r0
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onActivityLayout(int r3, int r4, int r5, int r6, int r7, android.os.Bundle r8) throws android.os.RemoteException {
                    r2 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L34
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L34
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L34
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L34
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L34
                    r0.writeInt(r6)     // Catch: java.lang.Throwable -> L34
                    r0.writeInt(r7)     // Catch: java.lang.Throwable -> L34
                    r3 = 0
                    r0.writeTypedObject(r8, r3)     // Catch: java.lang.Throwable -> L34
                    android.os.IBinder r3 = r2.mRemote     // Catch: java.lang.Throwable -> L34
                    r4 = 0
                    r5 = 1
                    r6 = 10
                    boolean r3 = r3.transact(r6, r0, r4, r5)     // Catch: java.lang.Throwable -> L34
                    if (r3 == 0) goto L2c
                    r0.recycle()
                    return
                L2c:
                    android.os.RemoteException r3 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L34
                    java.lang.String r4 = "Method onActivityLayout is unimplemented."
                    r3.<init>(r4)     // Catch: java.lang.Throwable -> L34
                    throw r3     // Catch: java.lang.Throwable -> L34
                L34:
                    r3 = move-exception
                    r0.recycle()
                    throw r3
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onActivityResized(int r3, int r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r2 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2b
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L2b
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L2b
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L2b
                    r3 = 0
                    r0.writeTypedObject(r5, r3)     // Catch: java.lang.Throwable -> L2b
                    android.os.IBinder r3 = r2.mRemote     // Catch: java.lang.Throwable -> L2b
                    r4 = 0
                    r5 = 1
                    r1 = 8
                    boolean r3 = r3.transact(r1, r0, r4, r5)     // Catch: java.lang.Throwable -> L2b
                    if (r3 == 0) goto L23
                    r0.recycle()
                    return
                L23:
                    android.os.RemoteException r3 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L2b
                    java.lang.String r4 = "Method onActivityResized is unimplemented."
                    r3.<init>(r4)     // Catch: java.lang.Throwable -> L2b
                    throw r3     // Catch: java.lang.Throwable -> L2b
                L2b:
                    r3 = move-exception
                    r0.recycle()
                    throw r3
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onMessageChannelReady(android.os.Bundle r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2c
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2c
                    r2 = 0
                    r0.writeTypedObject(r5, r2)     // Catch: java.lang.Throwable -> L2c
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L2c
                    r3 = 4
                    boolean r5 = r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L2c
                    if (r5 == 0) goto L24
                    r1.readException()     // Catch: java.lang.Throwable -> L2c
                    r1.recycle()
                    r0.recycle()
                    return
                L24:
                    android.os.RemoteException r5 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L2c
                    java.lang.String r2 = "Method onMessageChannelReady is unimplemented."
                    r5.<init>(r2)     // Catch: java.lang.Throwable -> L2c
                    throw r5     // Catch: java.lang.Throwable -> L2c
                L2c:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onMinimized(android.os.Bundle r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L25
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L25
                    r1 = 0
                    r0.writeTypedObject(r5, r1)     // Catch: java.lang.Throwable -> L25
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L25
                    r1 = 0
                    r2 = 1
                    r3 = 11
                    boolean r5 = r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L25
                    if (r5 == 0) goto L1d
                    r0.recycle()
                    return
                L1d:
                    android.os.RemoteException r5 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L25
                    java.lang.String r1 = "Method onMinimized is unimplemented."
                    r5.<init>(r1)     // Catch: java.lang.Throwable -> L25
                    throw r5     // Catch: java.lang.Throwable -> L25
                L25:
                    r5 = move-exception
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onNavigationEvent(int r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L27
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L27
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L27
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L27
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L27
                    r5 = 0
                    r1 = 1
                    r2 = 2
                    boolean r4 = r4.transact(r2, r0, r5, r1)     // Catch: java.lang.Throwable -> L27
                    if (r4 == 0) goto L1f
                    r0.recycle()
                    return
                L1f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L27
                    java.lang.String r5 = "Method onNavigationEvent is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L27
                    throw r4     // Catch: java.lang.Throwable -> L27
                L27:
                    r4 = move-exception
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onPostMessage(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2f
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L2f
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L2f
                    r2 = 5
                    boolean r4 = r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    if (r4 == 0) goto L27
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    r1.recycle()
                    r0.recycle()
                    return
                L27:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L2f
                    java.lang.String r5 = "Method onPostMessage is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L2f
                    throw r4     // Catch: java.lang.Throwable -> L2f
                L2f:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onRelationshipValidationResult(int r3, android.net.Uri r4, boolean r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r2 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2d
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L2d
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L2d
                    r3 = 0
                    r0.writeTypedObject(r4, r3)     // Catch: java.lang.Throwable -> L2d
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L2d
                    r0.writeTypedObject(r6, r3)     // Catch: java.lang.Throwable -> L2d
                    android.os.IBinder r3 = r2.mRemote     // Catch: java.lang.Throwable -> L2d
                    r4 = 0
                    r5 = 1
                    r6 = 6
                    boolean r3 = r3.transact(r6, r0, r4, r5)     // Catch: java.lang.Throwable -> L2d
                    if (r3 == 0) goto L25
                    r0.recycle()
                    return
                L25:
                    android.os.RemoteException r3 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L2d
                    java.lang.String r4 = "Method onRelationshipValidationResult is unimplemented."
                    r3.<init>(r4)     // Catch: java.lang.Throwable -> L2d
                    throw r3     // Catch: java.lang.Throwable -> L2d
                L2d:
                    r3 = move-exception
                    r0.recycle()
                    throw r3
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onUnminimized(android.os.Bundle r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L25
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L25
                    r1 = 0
                    r0.writeTypedObject(r5, r1)     // Catch: java.lang.Throwable -> L25
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L25
                    r1 = 0
                    r2 = 1
                    r3 = 12
                    boolean r5 = r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L25
                    if (r5 == 0) goto L1d
                    r0.recycle()
                    return
                L1d:
                    android.os.RemoteException r5 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L25
                    java.lang.String r1 = "Method onUnminimized is unimplemented."
                    r5.<init>(r1)     // Catch: java.lang.Throwable -> L25
                    throw r5     // Catch: java.lang.Throwable -> L25
                L25:
                    r5 = move-exception
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.customtabs.ICustomTabsCallback
            public void onWarmupCompleted(android.os.Bundle r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.ICustomTabsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L25
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L25
                    r1 = 0
                    r0.writeTypedObject(r5, r1)     // Catch: java.lang.Throwable -> L25
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L25
                    r1 = 0
                    r2 = 1
                    r3 = 9
                    boolean r5 = r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L25
                    if (r5 == 0) goto L1d
                    r0.recycle()
                    return
                L1d:
                    android.os.RemoteException r5 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L25
                    java.lang.String r1 = "Method onWarmupCompleted is unimplemented."
                    r5.<init>(r1)     // Catch: java.lang.Throwable -> L25
                    throw r5     // Catch: java.lang.Throwable -> L25
                L25:
                    r5 = move-exception
                    r0.recycle()
                    throw r5
            }
        }

        public Stub() {
                r1 = this;
                r1.<init>()
                java.lang.String r0 = android.support.customtabs.ICustomTabsCallback.Stub.DESCRIPTOR
                r1.attachInterface(r1, r0)
                return
        }

        public static android.support.customtabs.ICustomTabsCallback asInterface(android.os.IBinder r2) {
                if (r2 != 0) goto L4
                r2 = 0
                return r2
            L4:
                java.lang.String r0 = android.support.customtabs.ICustomTabsCallback.Stub.DESCRIPTOR
                android.os.IInterface r0 = r2.queryLocalInterface(r0)
                if (r0 == 0) goto L13
                boolean r1 = r0 instanceof android.support.customtabs.ICustomTabsCallback
                if (r1 == 0) goto L13
                android.support.customtabs.ICustomTabsCallback r0 = (android.support.customtabs.ICustomTabsCallback) r0
                return r0
            L13:
                android.support.customtabs.ICustomTabsCallback$Stub$Proxy r0 = new android.support.customtabs.ICustomTabsCallback$Stub$Proxy
                r0.<init>(r2)
                return r0
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r0 = this;
                return r0
        }

        @Override // android.os.Binder
        public boolean onTransact(int r11, android.os.Parcel r12, android.os.Parcel r13, int r14) throws android.os.RemoteException {
                r10 = this;
                java.lang.String r0 = android.support.customtabs.ICustomTabsCallback.Stub.DESCRIPTOR
                r1 = 16777215(0xffffff, float:2.3509886E-38)
                r2 = 1
                if (r11 < r2) goto Ld
                if (r11 > r1) goto Ld
                r12.enforceInterface(r0)
            Ld:
                r3 = 1598968902(0x5f4e5446, float:1.4867585E19)
                if (r11 != r3) goto L16
                r13.writeString(r0)
                return r2
            L16:
                if (r11 != r1) goto L23
                r13.writeNoException()
                int r11 = r10.getInterfaceVersion()
                r13.writeInt(r11)
                return r2
            L23:
                switch(r11) {
                    case 2: goto Lfd;
                    case 3: goto Lec;
                    case 4: goto Ldc;
                    case 5: goto Lc8;
                    case 6: goto La6;
                    case 7: goto L8d;
                    case 8: goto L77;
                    case 9: goto L69;
                    case 10: goto L46;
                    case 11: goto L38;
                    case 12: goto L2c;
                    default: goto L26;
                }
            L26:
                r3 = r10
                boolean r11 = super.onTransact(r11, r12, r13, r14)
                return r11
            L2c:
                android.os.Parcelable$Creator r11 = android.os.Bundle.CREATOR
                java.lang.Object r11 = r12.readTypedObject(r11)
                android.os.Bundle r11 = (android.os.Bundle) r11
                r10.onUnminimized(r11)
                goto L43
            L38:
                android.os.Parcelable$Creator r11 = android.os.Bundle.CREATOR
                java.lang.Object r11 = r12.readTypedObject(r11)
                android.os.Bundle r11 = (android.os.Bundle) r11
                r10.onMinimized(r11)
            L43:
                r3 = r10
                goto L10d
            L46:
                int r4 = r12.readInt()
                int r5 = r12.readInt()
                int r6 = r12.readInt()
                int r7 = r12.readInt()
                int r8 = r12.readInt()
                android.os.Parcelable$Creator r11 = android.os.Bundle.CREATOR
                java.lang.Object r11 = r12.readTypedObject(r11)
                r9 = r11
                android.os.Bundle r9 = (android.os.Bundle) r9
                r3 = r10
                r3.onActivityLayout(r4, r5, r6, r7, r8, r9)
                goto L10d
            L69:
                r3 = r10
                android.os.Parcelable$Creator r11 = android.os.Bundle.CREATOR
                java.lang.Object r11 = r12.readTypedObject(r11)
                android.os.Bundle r11 = (android.os.Bundle) r11
                r10.onWarmupCompleted(r11)
                goto L10d
            L77:
                r3 = r10
                int r11 = r12.readInt()
                int r13 = r12.readInt()
                android.os.Parcelable$Creator r14 = android.os.Bundle.CREATOR
                java.lang.Object r12 = r12.readTypedObject(r14)
                android.os.Bundle r12 = (android.os.Bundle) r12
                r10.onActivityResized(r11, r13, r12)
                goto L10d
            L8d:
                r3 = r10
                java.lang.String r11 = r12.readString()
                android.os.Parcelable$Creator r14 = android.os.Bundle.CREATOR
                java.lang.Object r12 = r12.readTypedObject(r14)
                android.os.Bundle r12 = (android.os.Bundle) r12
                android.os.Bundle r11 = r10.extraCallbackWithResult(r11, r12)
                r13.writeNoException()
                r13.writeTypedObject(r11, r2)
                goto L10d
            La6:
                r3 = r10
                int r11 = r12.readInt()
                android.os.Parcelable$Creator r13 = android.net.Uri.CREATOR
                java.lang.Object r13 = r12.readTypedObject(r13)
                android.net.Uri r13 = (android.net.Uri) r13
                int r14 = r12.readInt()
                if (r14 == 0) goto Lbb
                r14 = r2
                goto Lbc
            Lbb:
                r14 = 0
            Lbc:
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r12 = r12.readTypedObject(r0)
                android.os.Bundle r12 = (android.os.Bundle) r12
                r10.onRelationshipValidationResult(r11, r13, r14, r12)
                goto L10d
            Lc8:
                r3 = r10
                java.lang.String r11 = r12.readString()
                android.os.Parcelable$Creator r14 = android.os.Bundle.CREATOR
                java.lang.Object r12 = r12.readTypedObject(r14)
                android.os.Bundle r12 = (android.os.Bundle) r12
                r10.onPostMessage(r11, r12)
                r13.writeNoException()
                goto L10d
            Ldc:
                r3 = r10
                android.os.Parcelable$Creator r11 = android.os.Bundle.CREATOR
                java.lang.Object r11 = r12.readTypedObject(r11)
                android.os.Bundle r11 = (android.os.Bundle) r11
                r10.onMessageChannelReady(r11)
                r13.writeNoException()
                goto L10d
            Lec:
                r3 = r10
                java.lang.String r11 = r12.readString()
                android.os.Parcelable$Creator r13 = android.os.Bundle.CREATOR
                java.lang.Object r12 = r12.readTypedObject(r13)
                android.os.Bundle r12 = (android.os.Bundle) r12
                r10.extraCallback(r11, r12)
                goto L10d
            Lfd:
                r3 = r10
                int r11 = r12.readInt()
                android.os.Parcelable$Creator r13 = android.os.Bundle.CREATOR
                java.lang.Object r12 = r12.readTypedObject(r13)
                android.os.Bundle r12 = (android.os.Bundle) r12
                r10.onNavigationEvent(r11, r12)
            L10d:
                return r2
        }
    }

    static {
            r0 = 36
            r1 = 46
            java.lang.String r2 = "android$support$customtabs$ICustomTabsCallback"
            java.lang.String r0 = r2.replace(r0, r1)
            android.support.customtabs.ICustomTabsCallback.DESCRIPTOR = r0
            return
    }

    void extraCallback(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    android.os.Bundle extraCallbackWithResult(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    int getInterfaceVersion() throws android.os.RemoteException;

    void onActivityLayout(int r1, int r2, int r3, int r4, int r5, android.os.Bundle r6) throws android.os.RemoteException;

    void onActivityResized(int r1, int r2, android.os.Bundle r3) throws android.os.RemoteException;

    void onMessageChannelReady(android.os.Bundle r1) throws android.os.RemoteException;

    void onMinimized(android.os.Bundle r1) throws android.os.RemoteException;

    void onNavigationEvent(int r1, android.os.Bundle r2) throws android.os.RemoteException;

    void onPostMessage(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    void onRelationshipValidationResult(int r1, android.net.Uri r2, boolean r3, android.os.Bundle r4) throws android.os.RemoteException;

    void onUnminimized(android.os.Bundle r1) throws android.os.RemoteException;

    void onWarmupCompleted(android.os.Bundle r1) throws android.os.RemoteException;
}
