package android.support.customtabs;

/* JADX INFO: loaded from: classes.dex */
public interface IEngagementSignalsCallback extends android.os.IInterface {
    public static final java.lang.String DESCRIPTOR = null;
    public static final int VERSION = 1;

    public static class Default implements android.support.customtabs.IEngagementSignalsCallback {
        public Default() {
                r0 = this;
                r0.<init>()
                return
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.IEngagementSignalsCallback
        public int getInterfaceVersion() {
                r1 = this;
                r0 = 0
                return r0
        }

        @Override // android.support.customtabs.IEngagementSignalsCallback
        public void onGreatestScrollPercentageIncreased(int r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.IEngagementSignalsCallback
        public void onSessionEnded(boolean r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                return
        }

        @Override // android.support.customtabs.IEngagementSignalsCallback
        public void onVerticalScrollEvent(boolean r1, android.os.Bundle r2) throws android.os.RemoteException {
                r0 = this;
                return
        }
    }

    public static abstract class Stub extends android.os.Binder implements android.support.customtabs.IEngagementSignalsCallback {
        static final int TRANSACTION_getInterfaceVersion = 16777215;
        static final int TRANSACTION_onGreatestScrollPercentageIncreased = 3;
        static final int TRANSACTION_onSessionEnded = 4;
        static final int TRANSACTION_onVerticalScrollEvent = 2;

        private static class Proxy implements android.support.customtabs.IEngagementSignalsCallback {
            private int mCachedVersion;
            private android.os.IBinder mRemote;

            Proxy(android.os.IBinder r2) {
                    r1 = this;
                    r1.<init>()
                    r0 = -1
                    r1.mCachedVersion = r0
                    r1.mRemote = r2
                    return
            }

            @Override // android.os.IInterface
            public android.os.IBinder asBinder() {
                    r1 = this;
                    android.os.IBinder r0 = r1.mRemote
                    return r0
            }

            public java.lang.String getInterfaceDescriptor() {
                    r1 = this;
                    java.lang.String r0 = android.support.customtabs.IEngagementSignalsCallback.Stub.Proxy.DESCRIPTOR
                    return r0
            }

            @Override // android.support.customtabs.IEngagementSignalsCallback
            public int getInterfaceVersion() throws android.os.RemoteException {
                    r5 = this;
                    int r0 = r5.mCachedVersion
                    r1 = -1
                    if (r0 != r1) goto L33
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = android.support.customtabs.IEngagementSignalsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L2b
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2b
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2b
                    r3 = 16777215(0xffffff, float:2.3509886E-38)
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2b
                    r1.readException()     // Catch: java.lang.Throwable -> L2b
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2b
                    r5.mCachedVersion = r2     // Catch: java.lang.Throwable -> L2b
                    r1.recycle()
                    r0.recycle()
                    goto L33
                L2b:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
                L33:
                    int r0 = r5.mCachedVersion
                    return r0
            }

            @Override // android.support.customtabs.IEngagementSignalsCallback
            public void onGreatestScrollPercentageIncreased(int r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.IEngagementSignalsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L27
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L27
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L27
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L27
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L27
                    r5 = 0
                    r1 = 1
                    r2 = 3
                    boolean r4 = r4.transact(r2, r0, r5, r1)     // Catch: java.lang.Throwable -> L27
                    if (r4 == 0) goto L1f
                    r0.recycle()
                    return
                L1f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L27
                    java.lang.String r5 = "Method onGreatestScrollPercentageIncreased is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L27
                    throw r4     // Catch: java.lang.Throwable -> L27
                L27:
                    r4 = move-exception
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.IEngagementSignalsCallback
            public void onSessionEnded(boolean r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.IEngagementSignalsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L27
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L27
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L27
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L27
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L27
                    r5 = 0
                    r1 = 1
                    r2 = 4
                    boolean r4 = r4.transact(r2, r0, r5, r1)     // Catch: java.lang.Throwable -> L27
                    if (r4 == 0) goto L1f
                    r0.recycle()
                    return
                L1f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L27
                    java.lang.String r5 = "Method onSessionEnded is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L27
                    throw r4     // Catch: java.lang.Throwable -> L27
                L27:
                    r4 = move-exception
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.customtabs.IEngagementSignalsCallback
            public void onVerticalScrollEvent(boolean r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    java.lang.String r1 = android.support.customtabs.IEngagementSignalsCallback.Stub.Proxy.DESCRIPTOR     // Catch: java.lang.Throwable -> L27
                    r0.writeInterfaceToken(r1)     // Catch: java.lang.Throwable -> L27
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L27
                    r4 = 0
                    r0.writeTypedObject(r5, r4)     // Catch: java.lang.Throwable -> L27
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L27
                    r5 = 0
                    r1 = 1
                    r2 = 2
                    boolean r4 = r4.transact(r2, r0, r5, r1)     // Catch: java.lang.Throwable -> L27
                    if (r4 == 0) goto L1f
                    r0.recycle()
                    return
                L1f:
                    android.os.RemoteException r4 = new android.os.RemoteException     // Catch: java.lang.Throwable -> L27
                    java.lang.String r5 = "Method onVerticalScrollEvent is unimplemented."
                    r4.<init>(r5)     // Catch: java.lang.Throwable -> L27
                    throw r4     // Catch: java.lang.Throwable -> L27
                L27:
                    r4 = move-exception
                    r0.recycle()
                    throw r4
            }
        }

        public Stub() {
                r1 = this;
                r1.<init>()
                java.lang.String r0 = android.support.customtabs.IEngagementSignalsCallback.Stub.DESCRIPTOR
                r1.attachInterface(r1, r0)
                return
        }

        public static android.support.customtabs.IEngagementSignalsCallback asInterface(android.os.IBinder r2) {
                if (r2 != 0) goto L4
                r2 = 0
                return r2
            L4:
                java.lang.String r0 = android.support.customtabs.IEngagementSignalsCallback.Stub.DESCRIPTOR
                android.os.IInterface r0 = r2.queryLocalInterface(r0)
                if (r0 == 0) goto L13
                boolean r1 = r0 instanceof android.support.customtabs.IEngagementSignalsCallback
                if (r1 == 0) goto L13
                android.support.customtabs.IEngagementSignalsCallback r0 = (android.support.customtabs.IEngagementSignalsCallback) r0
                return r0
            L13:
                android.support.customtabs.IEngagementSignalsCallback$Stub$Proxy r0 = new android.support.customtabs.IEngagementSignalsCallback$Stub$Proxy
                r0.<init>(r2)
                return r0
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r0 = this;
                return r0
        }

        @Override // android.os.Binder
        public boolean onTransact(int r5, android.os.Parcel r6, android.os.Parcel r7, int r8) throws android.os.RemoteException {
                r4 = this;
                java.lang.String r0 = android.support.customtabs.IEngagementSignalsCallback.Stub.DESCRIPTOR
                r1 = 16777215(0xffffff, float:2.3509886E-38)
                r2 = 1
                if (r5 < r2) goto Ld
                if (r5 > r1) goto Ld
                r6.enforceInterface(r0)
            Ld:
                r3 = 1598968902(0x5f4e5446, float:1.4867585E19)
                if (r5 != r3) goto L16
                r7.writeString(r0)
                return r2
            L16:
                if (r5 != r1) goto L23
                r7.writeNoException()
                int r5 = r4.getInterfaceVersion()
                r7.writeInt(r5)
                return r2
            L23:
                r0 = 2
                r1 = 0
                if (r5 == r0) goto L55
                r0 = 3
                if (r5 == r0) goto L45
                r0 = 4
                if (r5 == r0) goto L32
                boolean r5 = super.onTransact(r5, r6, r7, r8)
                return r5
            L32:
                int r5 = r6.readInt()
                if (r5 == 0) goto L39
                r1 = r2
            L39:
                android.os.Parcelable$Creator r5 = android.os.Bundle.CREATOR
                java.lang.Object r5 = r6.readTypedObject(r5)
                android.os.Bundle r5 = (android.os.Bundle) r5
                r4.onSessionEnded(r1, r5)
                goto L67
            L45:
                int r5 = r6.readInt()
                android.os.Parcelable$Creator r7 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r6.readTypedObject(r7)
                android.os.Bundle r6 = (android.os.Bundle) r6
                r4.onGreatestScrollPercentageIncreased(r5, r6)
                goto L67
            L55:
                int r5 = r6.readInt()
                if (r5 == 0) goto L5c
                r1 = r2
            L5c:
                android.os.Parcelable$Creator r5 = android.os.Bundle.CREATOR
                java.lang.Object r5 = r6.readTypedObject(r5)
                android.os.Bundle r5 = (android.os.Bundle) r5
                r4.onVerticalScrollEvent(r1, r5)
            L67:
                return r2
        }
    }

    static {
            r0 = 36
            r1 = 46
            java.lang.String r2 = "android$support$customtabs$IEngagementSignalsCallback"
            java.lang.String r0 = r2.replace(r0, r1)
            android.support.customtabs.IEngagementSignalsCallback.DESCRIPTOR = r0
            return
    }

    int getInterfaceVersion() throws android.os.RemoteException;

    void onGreatestScrollPercentageIncreased(int r1, android.os.Bundle r2) throws android.os.RemoteException;

    void onSessionEnded(boolean r1, android.os.Bundle r2) throws android.os.RemoteException;

    void onVerticalScrollEvent(boolean r1, android.os.Bundle r2) throws android.os.RemoteException;
}
