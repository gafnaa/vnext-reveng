package android.support.v4.media.session;

/* JADX INFO: loaded from: classes.dex */
public interface IMediaSession extends android.os.IInterface {

    public static abstract class Stub extends android.os.Binder implements android.support.v4.media.session.IMediaSession {
        private static final java.lang.String DESCRIPTOR = "android.support.v4.media.session.IMediaSession";
        static final int TRANSACTION_addQueueItem = 41;
        static final int TRANSACTION_addQueueItemAt = 42;
        static final int TRANSACTION_adjustVolume = 11;
        static final int TRANSACTION_fastForward = 22;
        static final int TRANSACTION_getExtras = 31;
        static final int TRANSACTION_getFlags = 9;
        static final int TRANSACTION_getLaunchPendingIntent = 8;
        static final int TRANSACTION_getMetadata = 27;
        static final int TRANSACTION_getPackageName = 6;
        static final int TRANSACTION_getPlaybackState = 28;
        static final int TRANSACTION_getQueue = 29;
        static final int TRANSACTION_getQueueTitle = 30;
        static final int TRANSACTION_getRatingType = 32;
        static final int TRANSACTION_getRepeatMode = 37;
        static final int TRANSACTION_getSessionInfo = 50;
        static final int TRANSACTION_getShuffleMode = 47;
        static final int TRANSACTION_getTag = 7;
        static final int TRANSACTION_getVolumeAttributes = 10;
        static final int TRANSACTION_isCaptioningEnabled = 45;
        static final int TRANSACTION_isShuffleModeEnabledRemoved = 38;
        static final int TRANSACTION_isTransportControlEnabled = 5;
        static final int TRANSACTION_next = 20;
        static final int TRANSACTION_pause = 18;
        static final int TRANSACTION_play = 13;
        static final int TRANSACTION_playFromMediaId = 14;
        static final int TRANSACTION_playFromSearch = 15;
        static final int TRANSACTION_playFromUri = 16;
        static final int TRANSACTION_prepare = 33;
        static final int TRANSACTION_prepareFromMediaId = 34;
        static final int TRANSACTION_prepareFromSearch = 35;
        static final int TRANSACTION_prepareFromUri = 36;
        static final int TRANSACTION_previous = 21;
        static final int TRANSACTION_rate = 25;
        static final int TRANSACTION_rateWithExtras = 51;
        static final int TRANSACTION_registerCallbackListener = 3;
        static final int TRANSACTION_removeQueueItem = 43;
        static final int TRANSACTION_removeQueueItemAt = 44;
        static final int TRANSACTION_rewind = 23;
        static final int TRANSACTION_seekTo = 24;
        static final int TRANSACTION_sendCommand = 1;
        static final int TRANSACTION_sendCustomAction = 26;
        static final int TRANSACTION_sendMediaButton = 2;
        static final int TRANSACTION_setCaptioningEnabled = 46;
        static final int TRANSACTION_setPlaybackSpeed = 49;
        static final int TRANSACTION_setRepeatMode = 39;
        static final int TRANSACTION_setShuffleMode = 48;
        static final int TRANSACTION_setShuffleModeEnabledRemoved = 40;
        static final int TRANSACTION_setVolumeTo = 12;
        static final int TRANSACTION_skipToQueueItem = 17;
        static final int TRANSACTION_stop = 19;
        static final int TRANSACTION_unregisterCallbackListener = 4;

        private static class Proxy implements android.support.v4.media.session.IMediaSession {
            private android.os.IBinder mRemote;

            Proxy(android.os.IBinder r1) {
                    r0 = this;
                    r0.<init>()
                    r0.mRemote = r1
                    return
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void addQueueItem(android.support.v4.media.MediaDescriptionCompat r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2c
                    r2 = 0
                    if (r5 == 0) goto L18
                    r3 = 1
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L2c
                    r5.writeToParcel(r0, r2)     // Catch: java.lang.Throwable -> L2c
                    goto L1b
                L18:
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2c
                L1b:
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L2c
                    r3 = 41
                    r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L2c
                    r1.readException()     // Catch: java.lang.Throwable -> L2c
                    r1.recycle()
                    r0.recycle()
                    return
                L2c:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void addQueueItemAt(android.support.v4.media.MediaDescriptionCompat r5, int r6) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    r2 = 0
                    if (r5 == 0) goto L18
                    r3 = 1
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L2f
                    r5.writeToParcel(r0, r2)     // Catch: java.lang.Throwable -> L2f
                    goto L1b
                L18:
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2f
                L1b:
                    r0.writeInt(r6)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L2f
                    r6 = 42
                    r5.transact(r6, r0, r1, r2)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    r1.recycle()
                    r0.recycle()
                    return
                L2f:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void adjustVolume(int r4, int r5, java.lang.String r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L28
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L28
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L28
                    r0.writeString(r6)     // Catch: java.lang.Throwable -> L28
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L28
                    r5 = 11
                    r6 = 0
                    r4.transact(r5, r0, r1, r6)     // Catch: java.lang.Throwable -> L28
                    r1.readException()     // Catch: java.lang.Throwable -> L28
                    r1.recycle()
                    r0.recycle()
                    return
                L28:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.os.IInterface
            public android.os.IBinder asBinder() {
                    r1 = this;
                    android.os.IBinder r0 = r1.mRemote
                    return r0
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void fastForward() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L1f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L1f
                    r3 = 22
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L1f
                    r1.readException()     // Catch: java.lang.Throwable -> L1f
                    r1.recycle()
                    r0.recycle()
                    return
                L1f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public android.os.Bundle getExtras() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2f
                    r3 = 31
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2f
                    if (r2 == 0) goto L27
                    android.os.Parcelable$Creator r2 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L2f
                    java.lang.Object r2 = r2.createFromParcel(r1)     // Catch: java.lang.Throwable -> L2f
                    android.os.Bundle r2 = (android.os.Bundle) r2     // Catch: java.lang.Throwable -> L2f
                    goto L28
                L27:
                    r2 = 0
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L2f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public long getFlags() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L23
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L23
                    r3 = 9
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L23
                    r1.readException()     // Catch: java.lang.Throwable -> L23
                    long r2 = r1.readLong()     // Catch: java.lang.Throwable -> L23
                    r1.recycle()
                    r0.recycle()
                    return r2
                L23:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            public java.lang.String getInterfaceDescriptor() {
                    r1 = this;
                    java.lang.String r0 = "android.support.v4.media.session.IMediaSession"
                    return r0
            }

            @Override // android.support.v4.media.session.IMediaSession
            public android.app.PendingIntent getLaunchPendingIntent() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2f
                    r3 = 8
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2f
                    if (r2 == 0) goto L27
                    android.os.Parcelable$Creator r2 = android.app.PendingIntent.CREATOR     // Catch: java.lang.Throwable -> L2f
                    java.lang.Object r2 = r2.createFromParcel(r1)     // Catch: java.lang.Throwable -> L2f
                    android.app.PendingIntent r2 = (android.app.PendingIntent) r2     // Catch: java.lang.Throwable -> L2f
                    goto L28
                L27:
                    r2 = 0
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L2f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public android.support.v4.media.MediaMetadataCompat getMetadata() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2f
                    r3 = 27
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2f
                    if (r2 == 0) goto L27
                    android.os.Parcelable$Creator<android.support.v4.media.MediaMetadataCompat> r2 = android.support.v4.media.MediaMetadataCompat.CREATOR     // Catch: java.lang.Throwable -> L2f
                    java.lang.Object r2 = r2.createFromParcel(r1)     // Catch: java.lang.Throwable -> L2f
                    android.support.v4.media.MediaMetadataCompat r2 = (android.support.v4.media.MediaMetadataCompat) r2     // Catch: java.lang.Throwable -> L2f
                    goto L28
                L27:
                    r2 = 0
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L2f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public java.lang.String getPackageName() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L22
                    r3 = 6
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    java.lang.String r2 = r1.readString()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return r2
                L22:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public android.support.v4.media.session.PlaybackStateCompat getPlaybackState() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2f
                    r3 = 28
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2f
                    if (r2 == 0) goto L27
                    android.os.Parcelable$Creator<android.support.v4.media.session.PlaybackStateCompat> r2 = android.support.v4.media.session.PlaybackStateCompat.CREATOR     // Catch: java.lang.Throwable -> L2f
                    java.lang.Object r2 = r2.createFromParcel(r1)     // Catch: java.lang.Throwable -> L2f
                    android.support.v4.media.session.PlaybackStateCompat r2 = (android.support.v4.media.session.PlaybackStateCompat) r2     // Catch: java.lang.Throwable -> L2f
                    goto L28
                L27:
                    r2 = 0
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L2f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public java.util.List<android.support.v4.media.session.MediaSessionCompat.QueueItem> getQueue() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L25
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L25
                    r3 = 29
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L25
                    r1.readException()     // Catch: java.lang.Throwable -> L25
                    android.os.Parcelable$Creator<android.support.v4.media.session.MediaSessionCompat$QueueItem> r2 = android.support.v4.media.session.MediaSessionCompat.QueueItem.CREATOR     // Catch: java.lang.Throwable -> L25
                    java.util.ArrayList r2 = r1.createTypedArrayList(r2)     // Catch: java.lang.Throwable -> L25
                    r1.recycle()
                    r0.recycle()
                    return r2
                L25:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public java.lang.CharSequence getQueueTitle() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2f
                    r3 = 30
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2f
                    if (r2 == 0) goto L27
                    android.os.Parcelable$Creator r2 = android.text.TextUtils.CHAR_SEQUENCE_CREATOR     // Catch: java.lang.Throwable -> L2f
                    java.lang.Object r2 = r2.createFromParcel(r1)     // Catch: java.lang.Throwable -> L2f
                    java.lang.CharSequence r2 = (java.lang.CharSequence) r2     // Catch: java.lang.Throwable -> L2f
                    goto L28
                L27:
                    r2 = 0
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L2f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public int getRatingType() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L23
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L23
                    r3 = 32
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L23
                    r1.readException()     // Catch: java.lang.Throwable -> L23
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L23
                    r1.recycle()
                    r0.recycle()
                    return r2
                L23:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public int getRepeatMode() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L23
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L23
                    r3 = 37
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L23
                    r1.readException()     // Catch: java.lang.Throwable -> L23
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L23
                    r1.recycle()
                    r0.recycle()
                    return r2
                L23:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public android.os.Bundle getSessionInfo() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2f
                    r3 = 50
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2f
                    if (r2 == 0) goto L27
                    android.os.Parcelable$Creator r2 = android.os.Bundle.CREATOR     // Catch: java.lang.Throwable -> L2f
                    java.lang.Object r2 = r2.createFromParcel(r1)     // Catch: java.lang.Throwable -> L2f
                    android.os.Bundle r2 = (android.os.Bundle) r2     // Catch: java.lang.Throwable -> L2f
                    goto L28
                L27:
                    r2 = 0
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L2f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public int getShuffleMode() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L23
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L23
                    r3 = 47
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L23
                    r1.readException()     // Catch: java.lang.Throwable -> L23
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L23
                    r1.recycle()
                    r0.recycle()
                    return r2
                L23:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public java.lang.String getTag() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L22
                    r3 = 7
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    java.lang.String r2 = r1.readString()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return r2
                L22:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public android.support.v4.media.session.ParcelableVolumeInfo getVolumeAttributes() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L2f
                    r3 = 10
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L2f
                    if (r2 == 0) goto L27
                    android.os.Parcelable$Creator<android.support.v4.media.session.ParcelableVolumeInfo> r2 = android.support.v4.media.session.ParcelableVolumeInfo.CREATOR     // Catch: java.lang.Throwable -> L2f
                    java.lang.Object r2 = r2.createFromParcel(r1)     // Catch: java.lang.Throwable -> L2f
                    android.support.v4.media.session.ParcelableVolumeInfo r2 = (android.support.v4.media.session.ParcelableVolumeInfo) r2     // Catch: java.lang.Throwable -> L2f
                    goto L28
                L27:
                    r2 = 0
                L28:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L2f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public boolean isCaptioningEnabled() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L26
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L26
                    r3 = 45
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L26
                    r1.readException()     // Catch: java.lang.Throwable -> L26
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L26
                    if (r2 == 0) goto L1f
                    r4 = 1
                L1f:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L26:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public boolean isShuffleModeEnabledRemoved() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L26
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L26
                    r3 = 38
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L26
                    r1.readException()     // Catch: java.lang.Throwable -> L26
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L26
                    if (r2 == 0) goto L1f
                    r4 = 1
                L1f:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L26:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public boolean isTransportControlEnabled() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L25
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L25
                    r3 = 5
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L25
                    r1.readException()     // Catch: java.lang.Throwable -> L25
                    int r2 = r1.readInt()     // Catch: java.lang.Throwable -> L25
                    if (r2 == 0) goto L1e
                    r4 = 1
                L1e:
                    r1.recycle()
                    r0.recycle()
                    return r4
                L25:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void next() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L1f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L1f
                    r3 = 20
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L1f
                    r1.readException()     // Catch: java.lang.Throwable -> L1f
                    r1.recycle()
                    r0.recycle()
                    return
                L1f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void pause() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L1f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L1f
                    r3 = 18
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L1f
                    r1.readException()     // Catch: java.lang.Throwable -> L1f
                    r1.recycle()
                    r0.recycle()
                    return
                L1f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void play() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L1f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L1f
                    r3 = 13
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L1f
                    r1.readException()     // Catch: java.lang.Throwable -> L1f
                    r1.recycle()
                    r0.recycle()
                    return
                L1f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void playFromMediaId(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L2f
                    r4 = 0
                    if (r5 == 0) goto L1b
                    r2 = 1
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2f
                    r5.writeToParcel(r0, r4)     // Catch: java.lang.Throwable -> L2f
                    goto L1e
                L1b:
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L2f
                L1e:
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L2f
                    r2 = 14
                    r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    r1.recycle()
                    r0.recycle()
                    return
                L2f:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void playFromSearch(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L2f
                    r4 = 0
                    if (r5 == 0) goto L1b
                    r2 = 1
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2f
                    r5.writeToParcel(r0, r4)     // Catch: java.lang.Throwable -> L2f
                    goto L1e
                L1b:
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L2f
                L1e:
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L2f
                    r2 = 15
                    r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    r1.recycle()
                    r0.recycle()
                    return
                L2f:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void playFromUri(android.net.Uri r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L38
                    r2 = 1
                    r3 = 0
                    if (r5 == 0) goto L18
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L38
                    r5.writeToParcel(r0, r3)     // Catch: java.lang.Throwable -> L38
                    goto L1b
                L18:
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L38
                L1b:
                    if (r6 == 0) goto L24
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L38
                    r6.writeToParcel(r0, r3)     // Catch: java.lang.Throwable -> L38
                    goto L27
                L24:
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L38
                L27:
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L38
                    r6 = 16
                    r5.transact(r6, r0, r1, r3)     // Catch: java.lang.Throwable -> L38
                    r1.readException()     // Catch: java.lang.Throwable -> L38
                    r1.recycle()
                    r0.recycle()
                    return
                L38:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void prepare() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L1f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L1f
                    r3 = 33
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L1f
                    r1.readException()     // Catch: java.lang.Throwable -> L1f
                    r1.recycle()
                    r0.recycle()
                    return
                L1f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void prepareFromMediaId(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L2f
                    r4 = 0
                    if (r5 == 0) goto L1b
                    r2 = 1
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2f
                    r5.writeToParcel(r0, r4)     // Catch: java.lang.Throwable -> L2f
                    goto L1e
                L1b:
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L2f
                L1e:
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L2f
                    r2 = 34
                    r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    r1.recycle()
                    r0.recycle()
                    return
                L2f:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void prepareFromSearch(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L2f
                    r4 = 0
                    if (r5 == 0) goto L1b
                    r2 = 1
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2f
                    r5.writeToParcel(r0, r4)     // Catch: java.lang.Throwable -> L2f
                    goto L1e
                L1b:
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L2f
                L1e:
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L2f
                    r2 = 35
                    r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    r1.recycle()
                    r0.recycle()
                    return
                L2f:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void prepareFromUri(android.net.Uri r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L38
                    r2 = 1
                    r3 = 0
                    if (r5 == 0) goto L18
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L38
                    r5.writeToParcel(r0, r3)     // Catch: java.lang.Throwable -> L38
                    goto L1b
                L18:
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L38
                L1b:
                    if (r6 == 0) goto L24
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L38
                    r6.writeToParcel(r0, r3)     // Catch: java.lang.Throwable -> L38
                    goto L27
                L24:
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L38
                L27:
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L38
                    r6 = 36
                    r5.transact(r6, r0, r1, r3)     // Catch: java.lang.Throwable -> L38
                    r1.readException()     // Catch: java.lang.Throwable -> L38
                    r1.recycle()
                    r0.recycle()
                    return
                L38:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void previous() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L1f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L1f
                    r3 = 21
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L1f
                    r1.readException()     // Catch: java.lang.Throwable -> L1f
                    r1.recycle()
                    r0.recycle()
                    return
                L1f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void rate(android.support.v4.media.RatingCompat r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2c
                    r2 = 0
                    if (r5 == 0) goto L18
                    r3 = 1
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L2c
                    r5.writeToParcel(r0, r2)     // Catch: java.lang.Throwable -> L2c
                    goto L1b
                L18:
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2c
                L1b:
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L2c
                    r3 = 25
                    r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L2c
                    r1.readException()     // Catch: java.lang.Throwable -> L2c
                    r1.recycle()
                    r0.recycle()
                    return
                L2c:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void rateWithExtras(android.support.v4.media.RatingCompat r5, android.os.Bundle r6) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L38
                    r2 = 1
                    r3 = 0
                    if (r5 == 0) goto L18
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L38
                    r5.writeToParcel(r0, r3)     // Catch: java.lang.Throwable -> L38
                    goto L1b
                L18:
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L38
                L1b:
                    if (r6 == 0) goto L24
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L38
                    r6.writeToParcel(r0, r3)     // Catch: java.lang.Throwable -> L38
                    goto L27
                L24:
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L38
                L27:
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L38
                    r6 = 51
                    r5.transact(r6, r0, r1, r3)     // Catch: java.lang.Throwable -> L38
                    r1.readException()     // Catch: java.lang.Throwable -> L38
                    r1.recycle()
                    r0.recycle()
                    return
                L38:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void registerCallbackListener(android.support.v4.media.session.IMediaControllerCallback r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L29
                    if (r5 == 0) goto L14
                    android.os.IBinder r5 = r5.asBinder()     // Catch: java.lang.Throwable -> L29
                    goto L15
                L14:
                    r5 = 0
                L15:
                    r0.writeStrongBinder(r5)     // Catch: java.lang.Throwable -> L29
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L29
                    r2 = 3
                    r3 = 0
                    r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L29
                    r1.readException()     // Catch: java.lang.Throwable -> L29
                    r1.recycle()
                    r0.recycle()
                    return
                L29:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void removeQueueItem(android.support.v4.media.MediaDescriptionCompat r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2c
                    r2 = 0
                    if (r5 == 0) goto L18
                    r3 = 1
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L2c
                    r5.writeToParcel(r0, r2)     // Catch: java.lang.Throwable -> L2c
                    goto L1b
                L18:
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2c
                L1b:
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L2c
                    r3 = 43
                    r5.transact(r3, r0, r1, r2)     // Catch: java.lang.Throwable -> L2c
                    r1.readException()     // Catch: java.lang.Throwable -> L2c
                    r1.recycle()
                    r0.recycle()
                    return
                L2c:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void removeQueueItemAt(int r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L22
                    r2 = 44
                    r3 = 0
                    r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return
                L22:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void rewind() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L1f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L1f
                    r3 = 23
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L1f
                    r1.readException()     // Catch: java.lang.Throwable -> L1f
                    r1.recycle()
                    r0.recycle()
                    return
                L1f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void seekTo(long r4) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    r0.writeLong(r4)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L22
                    r5 = 24
                    r2 = 0
                    r4.transact(r5, r0, r1, r2)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return
                L22:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void sendCommand(java.lang.String r4, android.os.Bundle r5, android.support.v4.media.session.MediaSessionCompat.ResultReceiverWrapper r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L39
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L39
                    r4 = 1
                    r2 = 0
                    if (r5 == 0) goto L1b
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L39
                    r5.writeToParcel(r0, r2)     // Catch: java.lang.Throwable -> L39
                    goto L1e
                L1b:
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L39
                L1e:
                    if (r6 == 0) goto L27
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L39
                    r6.writeToParcel(r0, r2)     // Catch: java.lang.Throwable -> L39
                    goto L2a
                L27:
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L39
                L2a:
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L39
                    r5.transact(r4, r0, r1, r2)     // Catch: java.lang.Throwable -> L39
                    r1.readException()     // Catch: java.lang.Throwable -> L39
                    r1.recycle()
                    r0.recycle()
                    return
                L39:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void sendCustomAction(java.lang.String r4, android.os.Bundle r5) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L2f
                    r0.writeString(r4)     // Catch: java.lang.Throwable -> L2f
                    r4 = 0
                    if (r5 == 0) goto L1b
                    r2 = 1
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L2f
                    r5.writeToParcel(r0, r4)     // Catch: java.lang.Throwable -> L2f
                    goto L1e
                L1b:
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L2f
                L1e:
                    android.os.IBinder r5 = r3.mRemote     // Catch: java.lang.Throwable -> L2f
                    r2 = 26
                    r5.transact(r2, r0, r1, r4)     // Catch: java.lang.Throwable -> L2f
                    r1.readException()     // Catch: java.lang.Throwable -> L2f
                    r1.recycle()
                    r0.recycle()
                    return
                L2f:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public boolean sendMediaButton(android.view.KeyEvent r6) throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L33
                    r2 = 1
                    r3 = 0
                    if (r6 == 0) goto L18
                    r0.writeInt(r2)     // Catch: java.lang.Throwable -> L33
                    r6.writeToParcel(r0, r3)     // Catch: java.lang.Throwable -> L33
                    goto L1b
                L18:
                    r0.writeInt(r3)     // Catch: java.lang.Throwable -> L33
                L1b:
                    android.os.IBinder r6 = r5.mRemote     // Catch: java.lang.Throwable -> L33
                    r4 = 2
                    r6.transact(r4, r0, r1, r3)     // Catch: java.lang.Throwable -> L33
                    r1.readException()     // Catch: java.lang.Throwable -> L33
                    int r6 = r1.readInt()     // Catch: java.lang.Throwable -> L33
                    if (r6 == 0) goto L2b
                    goto L2c
                L2b:
                    r2 = r3
                L2c:
                    r1.recycle()
                    r0.recycle()
                    return r2
                L33:
                    r6 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r6
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void setCaptioningEnabled(boolean r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L22
                    r2 = 46
                    r3 = 0
                    r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return
                L22:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void setPlaybackSpeed(float r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    r0.writeFloat(r5)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L22
                    r2 = 49
                    r3 = 0
                    r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return
                L22:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void setRepeatMode(int r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L22
                    r2 = 39
                    r3 = 0
                    r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return
                L22:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void setShuffleMode(int r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L22
                    r2 = 48
                    r3 = 0
                    r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return
                L22:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void setShuffleModeEnabledRemoved(boolean r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L22
                    r2 = 40
                    r3 = 0
                    r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return
                L22:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void setVolumeTo(int r4, int r5, java.lang.String r6) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L28
                    r0.writeInt(r4)     // Catch: java.lang.Throwable -> L28
                    r0.writeInt(r5)     // Catch: java.lang.Throwable -> L28
                    r0.writeString(r6)     // Catch: java.lang.Throwable -> L28
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L28
                    r5 = 12
                    r6 = 0
                    r4.transact(r5, r0, r1, r6)     // Catch: java.lang.Throwable -> L28
                    r1.readException()     // Catch: java.lang.Throwable -> L28
                    r1.recycle()
                    r0.recycle()
                    return
                L28:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void skipToQueueItem(long r4) throws android.os.RemoteException {
                    r3 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L22
                    r0.writeLong(r4)     // Catch: java.lang.Throwable -> L22
                    android.os.IBinder r4 = r3.mRemote     // Catch: java.lang.Throwable -> L22
                    r5 = 17
                    r2 = 0
                    r4.transact(r5, r0, r1, r2)     // Catch: java.lang.Throwable -> L22
                    r1.readException()     // Catch: java.lang.Throwable -> L22
                    r1.recycle()
                    r0.recycle()
                    return
                L22:
                    r4 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r4
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void stop() throws android.os.RemoteException {
                    r5 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L1f
                    android.os.IBinder r2 = r5.mRemote     // Catch: java.lang.Throwable -> L1f
                    r3 = 19
                    r4 = 0
                    r2.transact(r3, r0, r1, r4)     // Catch: java.lang.Throwable -> L1f
                    r1.readException()     // Catch: java.lang.Throwable -> L1f
                    r1.recycle()
                    r0.recycle()
                    return
                L1f:
                    r2 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r2
            }

            @Override // android.support.v4.media.session.IMediaSession
            public void unregisterCallbackListener(android.support.v4.media.session.IMediaControllerCallback r5) throws android.os.RemoteException {
                    r4 = this;
                    android.os.Parcel r0 = android.os.Parcel.obtain()
                    android.os.Parcel r1 = android.os.Parcel.obtain()
                    java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                    r0.writeInterfaceToken(r2)     // Catch: java.lang.Throwable -> L29
                    if (r5 == 0) goto L14
                    android.os.IBinder r5 = r5.asBinder()     // Catch: java.lang.Throwable -> L29
                    goto L15
                L14:
                    r5 = 0
                L15:
                    r0.writeStrongBinder(r5)     // Catch: java.lang.Throwable -> L29
                    android.os.IBinder r5 = r4.mRemote     // Catch: java.lang.Throwable -> L29
                    r2 = 4
                    r3 = 0
                    r5.transact(r2, r0, r1, r3)     // Catch: java.lang.Throwable -> L29
                    r1.readException()     // Catch: java.lang.Throwable -> L29
                    r1.recycle()
                    r0.recycle()
                    return
                L29:
                    r5 = move-exception
                    r1.recycle()
                    r0.recycle()
                    throw r5
            }
        }

        public Stub() {
                r1 = this;
                r1.<init>()
                java.lang.String r0 = "android.support.v4.media.session.IMediaSession"
                r1.attachInterface(r1, r0)
                return
        }

        public static android.support.v4.media.session.IMediaSession asInterface(android.os.IBinder r2) {
                if (r2 != 0) goto L4
                r2 = 0
                return r2
            L4:
                java.lang.String r0 = "android.support.v4.media.session.IMediaSession"
                android.os.IInterface r0 = r2.queryLocalInterface(r0)
                if (r0 == 0) goto L13
                boolean r1 = r0 instanceof android.support.v4.media.session.IMediaSession
                if (r1 == 0) goto L13
                android.support.v4.media.session.IMediaSession r0 = (android.support.v4.media.session.IMediaSession) r0
                return r0
            L13:
                android.support.v4.media.session.IMediaSession$Stub$Proxy r0 = new android.support.v4.media.session.IMediaSession$Stub$Proxy
                r0.<init>(r2)
                return r0
        }

        @Override // android.os.IInterface
        public android.os.IBinder asBinder() {
                r0 = this;
                return r0
        }

        @Override // android.os.Binder
        public boolean onTransact(int r5, android.os.Parcel r6, android.os.Parcel r7, int r8) throws android.os.RemoteException {
                r4 = this;
                r0 = 1598968902(0x5f4e5446, float:1.4867585E19)
                r1 = 1
                java.lang.String r2 = "android.support.v4.media.session.IMediaSession"
                if (r5 == r0) goto L413
                r0 = 0
                r3 = 0
                switch(r5) {
                    case 1: goto L3e6;
                    case 2: goto L3c9;
                    case 3: goto L3b7;
                    case 4: goto L3a5;
                    case 5: goto L397;
                    case 6: goto L389;
                    case 7: goto L37b;
                    case 8: goto L364;
                    case 9: goto L356;
                    case 10: goto L33f;
                    case 11: goto L329;
                    case 12: goto L313;
                    case 13: goto L309;
                    case 14: goto L2ec;
                    case 15: goto L2cf;
                    case 16: goto L2a6;
                    case 17: goto L298;
                    case 18: goto L28e;
                    case 19: goto L284;
                    case 20: goto L27a;
                    case 21: goto L270;
                    case 22: goto L266;
                    case 23: goto L25c;
                    case 24: goto L24e;
                    case 25: goto L235;
                    case 26: goto L218;
                    case 27: goto L201;
                    case 28: goto L1ea;
                    case 29: goto L1dc;
                    case 30: goto L1c5;
                    case 31: goto L1ae;
                    case 32: goto L1a0;
                    case 33: goto L196;
                    case 34: goto L179;
                    case 35: goto L15c;
                    case 36: goto L133;
                    case 37: goto L125;
                    case 38: goto L117;
                    case 39: goto L109;
                    case 40: goto Lf8;
                    case 41: goto Ldf;
                    case 42: goto Lc2;
                    case 43: goto La9;
                    case 44: goto L9b;
                    case 45: goto L8d;
                    case 46: goto L7c;
                    case 47: goto L6e;
                    case 48: goto L60;
                    case 49: goto L52;
                    case 50: goto L3b;
                    case 51: goto L12;
                    default: goto Ld;
                }
            Ld:
                boolean r5 = super.onTransact(r5, r6, r7, r8)
                return r5
            L12:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto L24
                android.os.Parcelable$Creator<android.support.v4.media.RatingCompat> r5 = android.support.v4.media.RatingCompat.CREATOR
                java.lang.Object r5 = r5.createFromParcel(r6)
                android.support.v4.media.RatingCompat r5 = (android.support.v4.media.RatingCompat) r5
                goto L25
            L24:
                r5 = r3
            L25:
                int r8 = r6.readInt()
                if (r8 == 0) goto L34
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r8.createFromParcel(r6)
                r3 = r6
                android.os.Bundle r3 = (android.os.Bundle) r3
            L34:
                r4.rateWithExtras(r5, r3)
                r7.writeNoException()
                return r1
            L3b:
                r6.enforceInterface(r2)
                android.os.Bundle r5 = r4.getSessionInfo()
                r7.writeNoException()
                if (r5 == 0) goto L4e
                r7.writeInt(r1)
                r5.writeToParcel(r7, r1)
                goto L51
            L4e:
                r7.writeInt(r0)
            L51:
                return r1
            L52:
                r6.enforceInterface(r2)
                float r5 = r6.readFloat()
                r4.setPlaybackSpeed(r5)
                r7.writeNoException()
                return r1
            L60:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                r4.setShuffleMode(r5)
                r7.writeNoException()
                return r1
            L6e:
                r6.enforceInterface(r2)
                int r5 = r4.getShuffleMode()
                r7.writeNoException()
                r7.writeInt(r5)
                return r1
            L7c:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto L86
                r0 = r1
            L86:
                r4.setCaptioningEnabled(r0)
                r7.writeNoException()
                return r1
            L8d:
                r6.enforceInterface(r2)
                boolean r5 = r4.isCaptioningEnabled()
                r7.writeNoException()
                r7.writeInt(r5)
                return r1
            L9b:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                r4.removeQueueItemAt(r5)
                r7.writeNoException()
                return r1
            La9:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto Lbb
                android.os.Parcelable$Creator<android.support.v4.media.MediaDescriptionCompat> r5 = android.support.v4.media.MediaDescriptionCompat.CREATOR
                java.lang.Object r5 = r5.createFromParcel(r6)
                r3 = r5
                android.support.v4.media.MediaDescriptionCompat r3 = (android.support.v4.media.MediaDescriptionCompat) r3
            Lbb:
                r4.removeQueueItem(r3)
                r7.writeNoException()
                return r1
            Lc2:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto Ld4
                android.os.Parcelable$Creator<android.support.v4.media.MediaDescriptionCompat> r5 = android.support.v4.media.MediaDescriptionCompat.CREATOR
                java.lang.Object r5 = r5.createFromParcel(r6)
                r3 = r5
                android.support.v4.media.MediaDescriptionCompat r3 = (android.support.v4.media.MediaDescriptionCompat) r3
            Ld4:
                int r5 = r6.readInt()
                r4.addQueueItemAt(r3, r5)
                r7.writeNoException()
                return r1
            Ldf:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto Lf1
                android.os.Parcelable$Creator<android.support.v4.media.MediaDescriptionCompat> r5 = android.support.v4.media.MediaDescriptionCompat.CREATOR
                java.lang.Object r5 = r5.createFromParcel(r6)
                r3 = r5
                android.support.v4.media.MediaDescriptionCompat r3 = (android.support.v4.media.MediaDescriptionCompat) r3
            Lf1:
                r4.addQueueItem(r3)
                r7.writeNoException()
                return r1
            Lf8:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto L102
                r0 = r1
            L102:
                r4.setShuffleModeEnabledRemoved(r0)
                r7.writeNoException()
                return r1
            L109:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                r4.setRepeatMode(r5)
                r7.writeNoException()
                return r1
            L117:
                r6.enforceInterface(r2)
                boolean r5 = r4.isShuffleModeEnabledRemoved()
                r7.writeNoException()
                r7.writeInt(r5)
                return r1
            L125:
                r6.enforceInterface(r2)
                int r5 = r4.getRepeatMode()
                r7.writeNoException()
                r7.writeInt(r5)
                return r1
            L133:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto L145
                android.os.Parcelable$Creator r5 = android.net.Uri.CREATOR
                java.lang.Object r5 = r5.createFromParcel(r6)
                android.net.Uri r5 = (android.net.Uri) r5
                goto L146
            L145:
                r5 = r3
            L146:
                int r8 = r6.readInt()
                if (r8 == 0) goto L155
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r8.createFromParcel(r6)
                r3 = r6
                android.os.Bundle r3 = (android.os.Bundle) r3
            L155:
                r4.prepareFromUri(r5, r3)
                r7.writeNoException()
                return r1
            L15c:
                r6.enforceInterface(r2)
                java.lang.String r5 = r6.readString()
                int r8 = r6.readInt()
                if (r8 == 0) goto L172
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r8.createFromParcel(r6)
                r3 = r6
                android.os.Bundle r3 = (android.os.Bundle) r3
            L172:
                r4.prepareFromSearch(r5, r3)
                r7.writeNoException()
                return r1
            L179:
                r6.enforceInterface(r2)
                java.lang.String r5 = r6.readString()
                int r8 = r6.readInt()
                if (r8 == 0) goto L18f
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r8.createFromParcel(r6)
                r3 = r6
                android.os.Bundle r3 = (android.os.Bundle) r3
            L18f:
                r4.prepareFromMediaId(r5, r3)
                r7.writeNoException()
                return r1
            L196:
                r6.enforceInterface(r2)
                r4.prepare()
                r7.writeNoException()
                return r1
            L1a0:
                r6.enforceInterface(r2)
                int r5 = r4.getRatingType()
                r7.writeNoException()
                r7.writeInt(r5)
                return r1
            L1ae:
                r6.enforceInterface(r2)
                android.os.Bundle r5 = r4.getExtras()
                r7.writeNoException()
                if (r5 == 0) goto L1c1
                r7.writeInt(r1)
                r5.writeToParcel(r7, r1)
                goto L1c4
            L1c1:
                r7.writeInt(r0)
            L1c4:
                return r1
            L1c5:
                r6.enforceInterface(r2)
                java.lang.CharSequence r5 = r4.getQueueTitle()
                r7.writeNoException()
                if (r5 == 0) goto L1d8
                r7.writeInt(r1)
                android.text.TextUtils.writeToParcel(r5, r7, r1)
                goto L1db
            L1d8:
                r7.writeInt(r0)
            L1db:
                return r1
            L1dc:
                r6.enforceInterface(r2)
                java.util.List r5 = r4.getQueue()
                r7.writeNoException()
                r7.writeTypedList(r5)
                return r1
            L1ea:
                r6.enforceInterface(r2)
                android.support.v4.media.session.PlaybackStateCompat r5 = r4.getPlaybackState()
                r7.writeNoException()
                if (r5 == 0) goto L1fd
                r7.writeInt(r1)
                r5.writeToParcel(r7, r1)
                goto L200
            L1fd:
                r7.writeInt(r0)
            L200:
                return r1
            L201:
                r6.enforceInterface(r2)
                android.support.v4.media.MediaMetadataCompat r5 = r4.getMetadata()
                r7.writeNoException()
                if (r5 == 0) goto L214
                r7.writeInt(r1)
                r5.writeToParcel(r7, r1)
                goto L217
            L214:
                r7.writeInt(r0)
            L217:
                return r1
            L218:
                r6.enforceInterface(r2)
                java.lang.String r5 = r6.readString()
                int r8 = r6.readInt()
                if (r8 == 0) goto L22e
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r8.createFromParcel(r6)
                r3 = r6
                android.os.Bundle r3 = (android.os.Bundle) r3
            L22e:
                r4.sendCustomAction(r5, r3)
                r7.writeNoException()
                return r1
            L235:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto L247
                android.os.Parcelable$Creator<android.support.v4.media.RatingCompat> r5 = android.support.v4.media.RatingCompat.CREATOR
                java.lang.Object r5 = r5.createFromParcel(r6)
                r3 = r5
                android.support.v4.media.RatingCompat r3 = (android.support.v4.media.RatingCompat) r3
            L247:
                r4.rate(r3)
                r7.writeNoException()
                return r1
            L24e:
                r6.enforceInterface(r2)
                long r5 = r6.readLong()
                r4.seekTo(r5)
                r7.writeNoException()
                return r1
            L25c:
                r6.enforceInterface(r2)
                r4.rewind()
                r7.writeNoException()
                return r1
            L266:
                r6.enforceInterface(r2)
                r4.fastForward()
                r7.writeNoException()
                return r1
            L270:
                r6.enforceInterface(r2)
                r4.previous()
                r7.writeNoException()
                return r1
            L27a:
                r6.enforceInterface(r2)
                r4.next()
                r7.writeNoException()
                return r1
            L284:
                r6.enforceInterface(r2)
                r4.stop()
                r7.writeNoException()
                return r1
            L28e:
                r6.enforceInterface(r2)
                r4.pause()
                r7.writeNoException()
                return r1
            L298:
                r6.enforceInterface(r2)
                long r5 = r6.readLong()
                r4.skipToQueueItem(r5)
                r7.writeNoException()
                return r1
            L2a6:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto L2b8
                android.os.Parcelable$Creator r5 = android.net.Uri.CREATOR
                java.lang.Object r5 = r5.createFromParcel(r6)
                android.net.Uri r5 = (android.net.Uri) r5
                goto L2b9
            L2b8:
                r5 = r3
            L2b9:
                int r8 = r6.readInt()
                if (r8 == 0) goto L2c8
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r8.createFromParcel(r6)
                r3 = r6
                android.os.Bundle r3 = (android.os.Bundle) r3
            L2c8:
                r4.playFromUri(r5, r3)
                r7.writeNoException()
                return r1
            L2cf:
                r6.enforceInterface(r2)
                java.lang.String r5 = r6.readString()
                int r8 = r6.readInt()
                if (r8 == 0) goto L2e5
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r8.createFromParcel(r6)
                r3 = r6
                android.os.Bundle r3 = (android.os.Bundle) r3
            L2e5:
                r4.playFromSearch(r5, r3)
                r7.writeNoException()
                return r1
            L2ec:
                r6.enforceInterface(r2)
                java.lang.String r5 = r6.readString()
                int r8 = r6.readInt()
                if (r8 == 0) goto L302
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r6 = r8.createFromParcel(r6)
                r3 = r6
                android.os.Bundle r3 = (android.os.Bundle) r3
            L302:
                r4.playFromMediaId(r5, r3)
                r7.writeNoException()
                return r1
            L309:
                r6.enforceInterface(r2)
                r4.play()
                r7.writeNoException()
                return r1
            L313:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                int r8 = r6.readInt()
                java.lang.String r6 = r6.readString()
                r4.setVolumeTo(r5, r8, r6)
                r7.writeNoException()
                return r1
            L329:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                int r8 = r6.readInt()
                java.lang.String r6 = r6.readString()
                r4.adjustVolume(r5, r8, r6)
                r7.writeNoException()
                return r1
            L33f:
                r6.enforceInterface(r2)
                android.support.v4.media.session.ParcelableVolumeInfo r5 = r4.getVolumeAttributes()
                r7.writeNoException()
                if (r5 == 0) goto L352
                r7.writeInt(r1)
                r5.writeToParcel(r7, r1)
                goto L355
            L352:
                r7.writeInt(r0)
            L355:
                return r1
            L356:
                r6.enforceInterface(r2)
                long r5 = r4.getFlags()
                r7.writeNoException()
                r7.writeLong(r5)
                return r1
            L364:
                r6.enforceInterface(r2)
                android.app.PendingIntent r5 = r4.getLaunchPendingIntent()
                r7.writeNoException()
                if (r5 == 0) goto L377
                r7.writeInt(r1)
                r5.writeToParcel(r7, r1)
                goto L37a
            L377:
                r7.writeInt(r0)
            L37a:
                return r1
            L37b:
                r6.enforceInterface(r2)
                java.lang.String r5 = r4.getTag()
                r7.writeNoException()
                r7.writeString(r5)
                return r1
            L389:
                r6.enforceInterface(r2)
                java.lang.String r5 = r4.getPackageName()
                r7.writeNoException()
                r7.writeString(r5)
                return r1
            L397:
                r6.enforceInterface(r2)
                boolean r5 = r4.isTransportControlEnabled()
                r7.writeNoException()
                r7.writeInt(r5)
                return r1
            L3a5:
                r6.enforceInterface(r2)
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.v4.media.session.IMediaControllerCallback r5 = android.support.v4.media.session.IMediaControllerCallback.Stub.asInterface(r5)
                r4.unregisterCallbackListener(r5)
                r7.writeNoException()
                return r1
            L3b7:
                r6.enforceInterface(r2)
                android.os.IBinder r5 = r6.readStrongBinder()
                android.support.v4.media.session.IMediaControllerCallback r5 = android.support.v4.media.session.IMediaControllerCallback.Stub.asInterface(r5)
                r4.registerCallbackListener(r5)
                r7.writeNoException()
                return r1
            L3c9:
                r6.enforceInterface(r2)
                int r5 = r6.readInt()
                if (r5 == 0) goto L3db
                android.os.Parcelable$Creator r5 = android.view.KeyEvent.CREATOR
                java.lang.Object r5 = r5.createFromParcel(r6)
                r3 = r5
                android.view.KeyEvent r3 = (android.view.KeyEvent) r3
            L3db:
                boolean r5 = r4.sendMediaButton(r3)
                r7.writeNoException()
                r7.writeInt(r5)
                return r1
            L3e6:
                r6.enforceInterface(r2)
                java.lang.String r5 = r6.readString()
                int r8 = r6.readInt()
                if (r8 == 0) goto L3fc
                android.os.Parcelable$Creator r8 = android.os.Bundle.CREATOR
                java.lang.Object r8 = r8.createFromParcel(r6)
                android.os.Bundle r8 = (android.os.Bundle) r8
                goto L3fd
            L3fc:
                r8 = r3
            L3fd:
                int r0 = r6.readInt()
                if (r0 == 0) goto L40c
                android.os.Parcelable$Creator<android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper> r0 = android.support.v4.media.session.MediaSessionCompat.ResultReceiverWrapper.CREATOR
                java.lang.Object r6 = r0.createFromParcel(r6)
                r3 = r6
                android.support.v4.media.session.MediaSessionCompat$ResultReceiverWrapper r3 = (android.support.v4.media.session.MediaSessionCompat.ResultReceiverWrapper) r3
            L40c:
                r4.sendCommand(r5, r8, r3)
                r7.writeNoException()
                return r1
            L413:
                r7.writeString(r2)
                return r1
        }
    }

    void addQueueItem(android.support.v4.media.MediaDescriptionCompat r1) throws android.os.RemoteException;

    void addQueueItemAt(android.support.v4.media.MediaDescriptionCompat r1, int r2) throws android.os.RemoteException;

    void adjustVolume(int r1, int r2, java.lang.String r3) throws android.os.RemoteException;

    void fastForward() throws android.os.RemoteException;

    android.os.Bundle getExtras() throws android.os.RemoteException;

    long getFlags() throws android.os.RemoteException;

    android.app.PendingIntent getLaunchPendingIntent() throws android.os.RemoteException;

    android.support.v4.media.MediaMetadataCompat getMetadata() throws android.os.RemoteException;

    java.lang.String getPackageName() throws android.os.RemoteException;

    android.support.v4.media.session.PlaybackStateCompat getPlaybackState() throws android.os.RemoteException;

    java.util.List<android.support.v4.media.session.MediaSessionCompat.QueueItem> getQueue() throws android.os.RemoteException;

    java.lang.CharSequence getQueueTitle() throws android.os.RemoteException;

    int getRatingType() throws android.os.RemoteException;

    int getRepeatMode() throws android.os.RemoteException;

    android.os.Bundle getSessionInfo() throws android.os.RemoteException;

    int getShuffleMode() throws android.os.RemoteException;

    java.lang.String getTag() throws android.os.RemoteException;

    android.support.v4.media.session.ParcelableVolumeInfo getVolumeAttributes() throws android.os.RemoteException;

    boolean isCaptioningEnabled() throws android.os.RemoteException;

    boolean isShuffleModeEnabledRemoved() throws android.os.RemoteException;

    boolean isTransportControlEnabled() throws android.os.RemoteException;

    void next() throws android.os.RemoteException;

    void pause() throws android.os.RemoteException;

    void play() throws android.os.RemoteException;

    void playFromMediaId(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    void playFromSearch(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    void playFromUri(android.net.Uri r1, android.os.Bundle r2) throws android.os.RemoteException;

    void prepare() throws android.os.RemoteException;

    void prepareFromMediaId(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    void prepareFromSearch(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    void prepareFromUri(android.net.Uri r1, android.os.Bundle r2) throws android.os.RemoteException;

    void previous() throws android.os.RemoteException;

    void rate(android.support.v4.media.RatingCompat r1) throws android.os.RemoteException;

    void rateWithExtras(android.support.v4.media.RatingCompat r1, android.os.Bundle r2) throws android.os.RemoteException;

    void registerCallbackListener(android.support.v4.media.session.IMediaControllerCallback r1) throws android.os.RemoteException;

    void removeQueueItem(android.support.v4.media.MediaDescriptionCompat r1) throws android.os.RemoteException;

    void removeQueueItemAt(int r1) throws android.os.RemoteException;

    void rewind() throws android.os.RemoteException;

    void seekTo(long r1) throws android.os.RemoteException;

    void sendCommand(java.lang.String r1, android.os.Bundle r2, android.support.v4.media.session.MediaSessionCompat.ResultReceiverWrapper r3) throws android.os.RemoteException;

    void sendCustomAction(java.lang.String r1, android.os.Bundle r2) throws android.os.RemoteException;

    boolean sendMediaButton(android.view.KeyEvent r1) throws android.os.RemoteException;

    void setCaptioningEnabled(boolean r1) throws android.os.RemoteException;

    void setPlaybackSpeed(float r1) throws android.os.RemoteException;

    void setRepeatMode(int r1) throws android.os.RemoteException;

    void setShuffleMode(int r1) throws android.os.RemoteException;

    void setShuffleModeEnabledRemoved(boolean r1) throws android.os.RemoteException;

    void setVolumeTo(int r1, int r2, java.lang.String r3) throws android.os.RemoteException;

    void skipToQueueItem(long r1) throws android.os.RemoteException;

    void stop() throws android.os.RemoteException;

    void unregisterCallbackListener(android.support.v4.media.session.IMediaControllerCallback r1) throws android.os.RemoteException;
}
