package android.support.v4.media;

/* JADX INFO: loaded from: classes.dex */
public final class MediaDescriptionCompat implements android.os.Parcelable {
    public static final long BT_FOLDER_TYPE_ALBUMS = 2;
    public static final long BT_FOLDER_TYPE_ARTISTS = 3;
    public static final long BT_FOLDER_TYPE_GENRES = 4;
    public static final long BT_FOLDER_TYPE_MIXED = 0;
    public static final long BT_FOLDER_TYPE_PLAYLISTS = 5;
    public static final long BT_FOLDER_TYPE_TITLES = 1;
    public static final long BT_FOLDER_TYPE_YEARS = 6;
    public static final android.os.Parcelable.Creator<android.support.v4.media.MediaDescriptionCompat> CREATOR = null;
    public static final java.lang.String DESCRIPTION_KEY_MEDIA_URI = "android.support.v4.media.description.MEDIA_URI";
    public static final java.lang.String DESCRIPTION_KEY_NULL_BUNDLE_FLAG = "android.support.v4.media.description.NULL_BUNDLE_FLAG";
    public static final java.lang.String EXTRA_BT_FOLDER_TYPE = "android.media.extra.BT_FOLDER_TYPE";
    public static final java.lang.String EXTRA_DOWNLOAD_STATUS = "android.media.extra.DOWNLOAD_STATUS";
    public static final long STATUS_DOWNLOADED = 2;
    public static final long STATUS_DOWNLOADING = 1;
    public static final long STATUS_NOT_DOWNLOADED = 0;
    private final java.lang.CharSequence mDescription;
    private android.media.MediaDescription mDescriptionFwk;
    private final android.os.Bundle mExtras;
    private final android.graphics.Bitmap mIcon;
    private final android.net.Uri mIconUri;
    private final java.lang.String mMediaId;
    private final android.net.Uri mMediaUri;
    private final java.lang.CharSequence mSubtitle;
    private final java.lang.CharSequence mTitle;


    public static final class Builder {
        private java.lang.CharSequence mDescription;
        private android.os.Bundle mExtras;
        private android.graphics.Bitmap mIcon;
        private android.net.Uri mIconUri;
        private java.lang.String mMediaId;
        private android.net.Uri mMediaUri;
        private java.lang.CharSequence mSubtitle;
        private java.lang.CharSequence mTitle;

        public Builder() {
                r0 = this;
                r0.<init>()
                return
        }

        public android.support.v4.media.MediaDescriptionCompat build() {
                r9 = this;
                android.support.v4.media.MediaDescriptionCompat r0 = new android.support.v4.media.MediaDescriptionCompat
                java.lang.String r1 = r9.mMediaId
                java.lang.CharSequence r2 = r9.mTitle
                java.lang.CharSequence r3 = r9.mSubtitle
                java.lang.CharSequence r4 = r9.mDescription
                android.graphics.Bitmap r5 = r9.mIcon
                android.net.Uri r6 = r9.mIconUri
                android.os.Bundle r7 = r9.mExtras
                android.net.Uri r8 = r9.mMediaUri
                r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
                return r0
        }

        public android.support.v4.media.MediaDescriptionCompat.Builder setDescription(java.lang.CharSequence r1) {
                r0 = this;
                r0.mDescription = r1
                return r0
        }

        public android.support.v4.media.MediaDescriptionCompat.Builder setExtras(android.os.Bundle r1) {
                r0 = this;
                r0.mExtras = r1
                return r0
        }

        public android.support.v4.media.MediaDescriptionCompat.Builder setIconBitmap(android.graphics.Bitmap r1) {
                r0 = this;
                r0.mIcon = r1
                return r0
        }

        public android.support.v4.media.MediaDescriptionCompat.Builder setIconUri(android.net.Uri r1) {
                r0 = this;
                r0.mIconUri = r1
                return r0
        }

        public android.support.v4.media.MediaDescriptionCompat.Builder setMediaId(java.lang.String r1) {
                r0 = this;
                r0.mMediaId = r1
                return r0
        }

        public android.support.v4.media.MediaDescriptionCompat.Builder setMediaUri(android.net.Uri r1) {
                r0 = this;
                r0.mMediaUri = r1
                return r0
        }

        public android.support.v4.media.MediaDescriptionCompat.Builder setSubtitle(java.lang.CharSequence r1) {
                r0 = this;
                r0.mSubtitle = r1
                return r0
        }

        public android.support.v4.media.MediaDescriptionCompat.Builder setTitle(java.lang.CharSequence r1) {
                r0 = this;
                r0.mTitle = r1
                return r0
        }
    }

    static {
            android.support.v4.media.MediaDescriptionCompat$1 r0 = new android.support.v4.media.MediaDescriptionCompat$1
            r0.<init>()
            android.support.v4.media.MediaDescriptionCompat.CREATOR = r0
            return
    }

    MediaDescriptionCompat(android.os.Parcel r3) {
            r2 = this;
            r2.<init>()
            java.lang.String r0 = r3.readString()
            r2.mMediaId = r0
            android.os.Parcelable$Creator r0 = android.text.TextUtils.CHAR_SEQUENCE_CREATOR
            java.lang.Object r0 = r0.createFromParcel(r3)
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0
            r2.mTitle = r0
            android.os.Parcelable$Creator r0 = android.text.TextUtils.CHAR_SEQUENCE_CREATOR
            java.lang.Object r0 = r0.createFromParcel(r3)
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0
            r2.mSubtitle = r0
            android.os.Parcelable$Creator r0 = android.text.TextUtils.CHAR_SEQUENCE_CREATOR
            java.lang.Object r0 = r0.createFromParcel(r3)
            java.lang.CharSequence r0 = (java.lang.CharSequence) r0
            r2.mDescription = r0
            java.lang.Class r0 = r2.getClass()
            java.lang.ClassLoader r0 = r0.getClassLoader()
            android.os.Parcelable r1 = r3.readParcelable(r0)
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            r2.mIcon = r1
            android.os.Parcelable r1 = r3.readParcelable(r0)
            android.net.Uri r1 = (android.net.Uri) r1
            r2.mIconUri = r1
            android.os.Bundle r1 = r3.readBundle(r0)
            r2.mExtras = r1
            android.os.Parcelable r3 = r3.readParcelable(r0)
            android.net.Uri r3 = (android.net.Uri) r3
            r2.mMediaUri = r3
            return
    }

    MediaDescriptionCompat(java.lang.String r1, java.lang.CharSequence r2, java.lang.CharSequence r3, java.lang.CharSequence r4, android.graphics.Bitmap r5, android.net.Uri r6, android.os.Bundle r7, android.net.Uri r8) {
            r0 = this;
            r0.<init>()
            r0.mMediaId = r1
            r0.mTitle = r2
            r0.mSubtitle = r3
            r0.mDescription = r4
            r0.mIcon = r5
            r0.mIconUri = r6
            r0.mExtras = r7
            r0.mMediaUri = r8
            return
    }

    public static android.support.v4.media.MediaDescriptionCompat fromMediaDescription(java.lang.Object r8) {
            r0 = 0
            if (r8 == 0) goto L76
            android.support.v4.media.MediaDescriptionCompat$Builder r1 = new android.support.v4.media.MediaDescriptionCompat$Builder
            r1.<init>()
            android.media.MediaDescription r8 = (android.media.MediaDescription) r8
            java.lang.String r2 = r8.getMediaId()
            r1.setMediaId(r2)
            java.lang.CharSequence r2 = r8.getTitle()
            r1.setTitle(r2)
            java.lang.CharSequence r2 = r8.getSubtitle()
            r1.setSubtitle(r2)
            java.lang.CharSequence r2 = r8.getDescription()
            r1.setDescription(r2)
            android.graphics.Bitmap r2 = r8.getIconBitmap()
            r1.setIconBitmap(r2)
            android.net.Uri r2 = r8.getIconUri()
            r1.setIconUri(r2)
            android.os.Bundle r2 = r8.getExtras()
            java.lang.String r3 = "android.support.v4.media.description.MEDIA_URI"
            if (r2 == 0) goto L46
            android.support.v4.media.session.MediaSessionCompat.ensureClassLoader(r2)
            android.os.Parcelable r4 = r2.getParcelable(r3)
            android.net.Uri r4 = (android.net.Uri) r4
            goto L47
        L46:
            r4 = r0
        L47:
            if (r4 == 0) goto L5f
            java.lang.String r5 = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
            boolean r6 = r2.containsKey(r5)
            if (r6 == 0) goto L59
            int r6 = r2.size()
            r7 = 2
            if (r6 != r7) goto L59
            goto L60
        L59:
            r2.remove(r3)
            r2.remove(r5)
        L5f:
            r0 = r2
        L60:
            r1.setExtras(r0)
            if (r4 == 0) goto L69
            r1.setMediaUri(r4)
            goto L70
        L69:
            android.net.Uri r0 = r8.getMediaUri()
            r1.setMediaUri(r0)
        L70:
            android.support.v4.media.MediaDescriptionCompat r0 = r1.build()
            r0.mDescriptionFwk = r8
        L76:
            return r0
    }

    @Override // android.os.Parcelable
    public int describeContents() {
            r1 = this;
            r0 = 0
            return r0
    }

    public java.lang.CharSequence getDescription() {
            r1 = this;
            java.lang.CharSequence r0 = r1.mDescription
            return r0
    }

    public android.os.Bundle getExtras() {
            r1 = this;
            android.os.Bundle r0 = r1.mExtras
            return r0
    }

    public android.graphics.Bitmap getIconBitmap() {
            r1 = this;
            android.graphics.Bitmap r0 = r1.mIcon
            return r0
    }

    public android.net.Uri getIconUri() {
            r1 = this;
            android.net.Uri r0 = r1.mIconUri
            return r0
    }

    public java.lang.Object getMediaDescription() {
            r2 = this;
            android.media.MediaDescription r0 = r2.mDescriptionFwk
            if (r0 != 0) goto L37
            android.media.MediaDescription$Builder r0 = new android.media.MediaDescription$Builder
            r0.<init>()
            java.lang.String r1 = r2.mMediaId
            r0.setMediaId(r1)
            java.lang.CharSequence r1 = r2.mTitle
            r0.setTitle(r1)
            java.lang.CharSequence r1 = r2.mSubtitle
            r0.setSubtitle(r1)
            java.lang.CharSequence r1 = r2.mDescription
            r0.setDescription(r1)
            android.graphics.Bitmap r1 = r2.mIcon
            r0.setIconBitmap(r1)
            android.net.Uri r1 = r2.mIconUri
            r0.setIconUri(r1)
            android.os.Bundle r1 = r2.mExtras
            r0.setExtras(r1)
            android.net.Uri r1 = r2.mMediaUri
            r0.setMediaUri(r1)
            android.media.MediaDescription r0 = r0.build()
            r2.mDescriptionFwk = r0
        L37:
            return r0
    }

    public java.lang.String getMediaId() {
            r1 = this;
            java.lang.String r0 = r1.mMediaId
            return r0
    }

    public android.net.Uri getMediaUri() {
            r1 = this;
            android.net.Uri r0 = r1.mMediaUri
            return r0
    }

    public java.lang.CharSequence getSubtitle() {
            r1 = this;
            java.lang.CharSequence r0 = r1.mSubtitle
            return r0
    }

    public java.lang.CharSequence getTitle() {
            r1 = this;
            java.lang.CharSequence r0 = r1.mTitle
            return r0
    }

    public java.lang.String toString() {
            r3 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.CharSequence r1 = r3.mTitle
            r0.append(r1)
            java.lang.String r1 = ", "
            r0.append(r1)
            java.lang.CharSequence r2 = r3.mSubtitle
            r0.append(r2)
            r0.append(r1)
            java.lang.CharSequence r1 = r3.mDescription
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
    }

    @Override // android.os.Parcelable
    public void writeToParcel(android.os.Parcel r2, int r3) {
            r1 = this;
            java.lang.Object r0 = r1.getMediaDescription()
            android.media.MediaDescription r0 = (android.media.MediaDescription) r0
            r0.writeToParcel(r2, r3)
            return
    }
}
