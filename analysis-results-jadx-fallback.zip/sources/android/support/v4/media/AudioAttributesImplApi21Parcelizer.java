package android.support.v4.media;

/* JADX INFO: loaded from: classes.dex */
public final class AudioAttributesImplApi21Parcelizer extends androidx.media.AudioAttributesImplApi21Parcelizer {
    public AudioAttributesImplApi21Parcelizer() {
            r0 = this;
            r0.<init>()
            return
    }

    public static androidx.media.AudioAttributesImplApi21 read(androidx.versionedparcelable.VersionedParcel r0) {
            androidx.media.AudioAttributesImplApi21 r0 = androidx.media.AudioAttributesImplApi21Parcelizer.read(r0)
            return r0
    }

    public static void write(androidx.media.AudioAttributesImplApi21 r0, androidx.versionedparcelable.VersionedParcel r1) {
            androidx.media.AudioAttributesImplApi21Parcelizer.write(r0, r1)
            return
    }
}
