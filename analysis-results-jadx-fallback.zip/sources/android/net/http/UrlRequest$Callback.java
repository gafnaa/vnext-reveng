package android.net.http;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ interface UrlRequest$Callback {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
