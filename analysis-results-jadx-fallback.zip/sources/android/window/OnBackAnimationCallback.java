package android.window;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ interface OnBackAnimationCallback extends android.window.OnBackInvokedCallback {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
