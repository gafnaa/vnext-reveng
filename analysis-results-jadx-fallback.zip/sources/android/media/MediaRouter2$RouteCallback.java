package android.media;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ class MediaRouter2$RouteCallback {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
