package android.media;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ interface Spatializer$OnSpatializerStateChangedListener {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
