package android.webkit;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ class WebViewRenderProcessClient {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
