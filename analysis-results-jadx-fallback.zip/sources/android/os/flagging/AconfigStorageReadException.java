package android.os.flagging;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ class AconfigStorageReadException extends java.lang.RuntimeException {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
