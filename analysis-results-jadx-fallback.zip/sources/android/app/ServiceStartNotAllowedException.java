package android.app;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ class ServiceStartNotAllowedException extends java.lang.IllegalStateException {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
