package android.app.job;

/* JADX INFO: loaded from: classes2.dex */
public /* synthetic */ class JobServiceEngine {
    static {
            java.lang.NoClassDefFoundError r0 = new java.lang.NoClassDefFoundError
            r0.<init>()
            throw r0
    }
}
