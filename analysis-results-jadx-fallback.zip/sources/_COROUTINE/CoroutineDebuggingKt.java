package _COROUTINE;

/* JADX INFO: compiled from: CoroutineDebugging.kt */
/* JADX INFO: loaded from: classes.dex */
@kotlin.Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\b\u0002\u001a\u0014\u0010\u0004\u001a\u00020\u0005*\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0001H\u0002\"\u0014\u0010\u0000\u001a\u00020\u0001X\u0080D¢\u0006\b\n\u0000\u001a\u0004\b\u0002\u0010\u0003¨\u0006\b"}, d2 = {"ARTIFICIAL_FRAME_PACKAGE_NAME", "", "getARTIFICIAL_FRAME_PACKAGE_NAME", "()Ljava/lang/String;", "artificialFrame", "Ljava/lang/StackTraceElement;", "", "name", "kotlinx-coroutines-core"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class CoroutineDebuggingKt {
    private static final java.lang.String ARTIFICIAL_FRAME_PACKAGE_NAME = "_COROUTINE";

    static {
            return
    }

    public static final /* synthetic */ java.lang.StackTraceElement access$artificialFrame(java.lang.Throwable r0, java.lang.String r1) {
            java.lang.StackTraceElement r0 = artificialFrame(r0, r1)
            return r0
    }

    private static final java.lang.StackTraceElement artificialFrame(java.lang.Throwable r3, java.lang.String r4) {
            java.lang.StackTraceElement[] r3 = r3.getStackTrace()
            r0 = 0
            r3 = r3[r0]
            java.lang.StackTraceElement r0 = new java.lang.StackTraceElement
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = _COROUTINE.CoroutineDebuggingKt.ARTIFICIAL_FRAME_PACKAGE_NAME
            r1.append(r2)
            r2 = 46
            r1.append(r2)
            r1.append(r4)
            java.lang.String r4 = r1.toString()
            java.lang.String r1 = r3.getFileName()
            int r3 = r3.getLineNumber()
            java.lang.String r2 = "_"
            r0.<init>(r4, r2, r1, r3)
            return r0
    }

    public static final java.lang.String getARTIFICIAL_FRAME_PACKAGE_NAME() {
            java.lang.String r0 = _COROUTINE.CoroutineDebuggingKt.ARTIFICIAL_FRAME_PACKAGE_NAME
            return r0
    }
}
