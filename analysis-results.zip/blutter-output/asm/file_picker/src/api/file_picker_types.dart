// lib: , url: package:file_picker/src/api/file_picker_types.dart

// class id: 1048739, size: 0x8
class :: {
}

// class id: 8331, size: 0x14, field offset: 0x14
enum FileType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11a93b0, size: 0x64
    // 0x11a93b0: EnterFrame
    //     0x11a93b0: stp             fp, lr, [SP, #-0x10]!
    //     0x11a93b4: mov             fp, SP
    // 0x11a93b8: AllocStack(0x10)
    //     0x11a93b8: sub             SP, SP, #0x10
    // 0x11a93bc: SetupParameters(FileType this /* r1 => r0, fp-0x8 */)
    //     0x11a93bc: mov             x0, x1
    //     0x11a93c0: stur            x1, [fp, #-8]
    // 0x11a93c4: CheckStackOverflow
    //     0x11a93c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a93c8: cmp             SP, x16
    //     0x11a93cc: b.ls            #0x11a940c
    // 0x11a93d0: r1 = Null
    //     0x11a93d0: mov             x1, NULL
    // 0x11a93d4: r2 = 4
    //     0x11a93d4: mov             x2, #4
    // 0x11a93d8: r0 = AllocateArray()
    //     0x11a93d8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11a93dc: r16 = "FileType."
    //     0x11a93dc: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b080] "FileType."
    //     0x11a93e0: ldr             x16, [x16, #0x80]
    // 0x11a93e4: StoreField: r0->field_f = r16
    //     0x11a93e4: stur            w16, [x0, #0xf]
    // 0x11a93e8: ldur            x1, [fp, #-8]
    // 0x11a93ec: LoadField: r2 = r1->field_f
    //     0x11a93ec: ldur            w2, [x1, #0xf]
    // 0x11a93f0: DecompressPointer r2
    //     0x11a93f0: add             x2, x2, HEAP, lsl #32
    // 0x11a93f4: StoreField: r0->field_13 = r2
    //     0x11a93f4: stur            w2, [x0, #0x13]
    // 0x11a93f8: str             x0, [SP]
    // 0x11a93fc: r0 = _interpolate()
    //     0x11a93fc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11a9400: LeaveFrame
    //     0x11a9400: mov             SP, fp
    //     0x11a9404: ldp             fp, lr, [SP], #0x10
    // 0x11a9408: ret
    //     0x11a9408: ret             
    // 0x11a940c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a940c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a9410: b               #0x11a93d0
  }
}
