// lib: , url: package:file_picker/src/api/platform_file.dart

// class id: 1048740, size: 0x8
class :: {
}

// class id: 3376, size: 0x24, field offset: 0x8
class PlatformFile extends Object {

  factory _ PlatformFile.fromMap(/* No info */) {
    // ** addr: 0xe07b48, size: 0x234
    // 0xe07b48: EnterFrame
    //     0xe07b48: stp             fp, lr, [SP, #-0x10]!
    //     0xe07b4c: mov             fp, SP
    // 0xe07b50: AllocStack(0x28)
    //     0xe07b50: sub             SP, SP, #0x28
    // 0xe07b54: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xe07b54: mov             x3, x2
    //     0xe07b58: stur            x2, [fp, #-8]
    // 0xe07b5c: CheckStackOverflow
    //     0xe07b5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe07b60: cmp             SP, x16
    //     0xe07b64: b.ls            #0xe07d74
    // 0xe07b68: r0 = LoadClassIdInstr(r3)
    //     0xe07b68: ldur            x0, [x3, #-1]
    //     0xe07b6c: ubfx            x0, x0, #0xc, #0x14
    // 0xe07b70: mov             x1, x3
    // 0xe07b74: r2 = "name"
    //     0xe07b74: ldr             x2, [PP, #0x6120]  ; [pp+0x6120] "name"
    // 0xe07b78: r0 = GDT[cid_x0 + -0xd48]()
    //     0xe07b78: sub             lr, x0, #0xd48
    //     0xe07b7c: ldr             lr, [x21, lr, lsl #3]
    //     0xe07b80: blr             lr
    // 0xe07b84: mov             x3, x0
    // 0xe07b88: r2 = Null
    //     0xe07b88: mov             x2, NULL
    // 0xe07b8c: r1 = Null
    //     0xe07b8c: mov             x1, NULL
    // 0xe07b90: stur            x3, [fp, #-0x10]
    // 0xe07b94: r4 = 60
    //     0xe07b94: mov             x4, #0x3c
    // 0xe07b98: branchIfSmi(r0, 0xe07ba4)
    //     0xe07b98: tbz             w0, #0, #0xe07ba4
    // 0xe07b9c: r4 = LoadClassIdInstr(r0)
    //     0xe07b9c: ldur            x4, [x0, #-1]
    //     0xe07ba0: ubfx            x4, x4, #0xc, #0x14
    // 0xe07ba4: sub             x4, x4, #0x5e
    // 0xe07ba8: cmp             x4, #1
    // 0xe07bac: b.ls            #0xe07bc0
    // 0xe07bb0: r8 = String
    //     0xe07bb0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0xe07bb4: r3 = Null
    //     0xe07bb4: add             x3, PP, #0x27, lsl #12  ; [pp+0x27d88] Null
    //     0xe07bb8: ldr             x3, [x3, #0xd88]
    // 0xe07bbc: r0 = String()
    //     0xe07bbc: bl              #0x13ee320  ; IsType_String_Stub
    // 0xe07bc0: ldur            x3, [fp, #-8]
    // 0xe07bc4: r0 = LoadClassIdInstr(r3)
    //     0xe07bc4: ldur            x0, [x3, #-1]
    //     0xe07bc8: ubfx            x0, x0, #0xc, #0x14
    // 0xe07bcc: mov             x1, x3
    // 0xe07bd0: r2 = "path"
    //     0xe07bd0: ldr             x2, [PP, #0x39c0]  ; [pp+0x39c0] "path"
    // 0xe07bd4: r0 = GDT[cid_x0 + -0xd48]()
    //     0xe07bd4: sub             lr, x0, #0xd48
    //     0xe07bd8: ldr             lr, [x21, lr, lsl #3]
    //     0xe07bdc: blr             lr
    // 0xe07be0: mov             x3, x0
    // 0xe07be4: r2 = Null
    //     0xe07be4: mov             x2, NULL
    // 0xe07be8: r1 = Null
    //     0xe07be8: mov             x1, NULL
    // 0xe07bec: stur            x3, [fp, #-0x18]
    // 0xe07bf0: r4 = 60
    //     0xe07bf0: mov             x4, #0x3c
    // 0xe07bf4: branchIfSmi(r0, 0xe07c00)
    //     0xe07bf4: tbz             w0, #0, #0xe07c00
    // 0xe07bf8: r4 = LoadClassIdInstr(r0)
    //     0xe07bf8: ldur            x4, [x0, #-1]
    //     0xe07bfc: ubfx            x4, x4, #0xc, #0x14
    // 0xe07c00: sub             x4, x4, #0x5e
    // 0xe07c04: cmp             x4, #1
    // 0xe07c08: b.ls            #0xe07c1c
    // 0xe07c0c: r8 = String?
    //     0xe07c0c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0xe07c10: r3 = Null
    //     0xe07c10: add             x3, PP, #0x27, lsl #12  ; [pp+0x27d98] Null
    //     0xe07c14: ldr             x3, [x3, #0xd98]
    // 0xe07c18: r0 = String?()
    //     0xe07c18: bl              #0x7db310  ; IsType_String?_Stub
    // 0xe07c1c: ldur            x3, [fp, #-8]
    // 0xe07c20: r0 = LoadClassIdInstr(r3)
    //     0xe07c20: ldur            x0, [x3, #-1]
    //     0xe07c24: ubfx            x0, x0, #0xc, #0x14
    // 0xe07c28: mov             x1, x3
    // 0xe07c2c: r2 = "bytes"
    //     0xe07c2c: add             x2, PP, #0x27, lsl #12  ; [pp+0x27da8] "bytes"
    //     0xe07c30: ldr             x2, [x2, #0xda8]
    // 0xe07c34: r0 = GDT[cid_x0 + -0xd48]()
    //     0xe07c34: sub             lr, x0, #0xd48
    //     0xe07c38: ldr             lr, [x21, lr, lsl #3]
    //     0xe07c3c: blr             lr
    // 0xe07c40: mov             x3, x0
    // 0xe07c44: r2 = Null
    //     0xe07c44: mov             x2, NULL
    // 0xe07c48: r1 = Null
    //     0xe07c48: mov             x1, NULL
    // 0xe07c4c: stur            x3, [fp, #-0x20]
    // 0xe07c50: r4 = 60
    //     0xe07c50: mov             x4, #0x3c
    // 0xe07c54: branchIfSmi(r0, 0xe07c60)
    //     0xe07c54: tbz             w0, #0, #0xe07c60
    // 0xe07c58: r4 = LoadClassIdInstr(r0)
    //     0xe07c58: ldur            x4, [x0, #-1]
    //     0xe07c5c: ubfx            x4, x4, #0xc, #0x14
    // 0xe07c60: sub             x4, x4, #0x74
    // 0xe07c64: cmp             x4, #3
    // 0xe07c68: b.ls            #0xe07c7c
    // 0xe07c6c: r8 = Uint8List?
    //     0xe07c6c: ldr             x8, [PP, #0x4198]  ; [pp+0x4198] Type: Uint8List?
    // 0xe07c70: r3 = Null
    //     0xe07c70: add             x3, PP, #0x27, lsl #12  ; [pp+0x27db0] Null
    //     0xe07c74: ldr             x3, [x3, #0xdb0]
    // 0xe07c78: r0 = Uint8List?()
    //     0xe07c78: bl              #0x822e74  ; IsType_Uint8List?_Stub
    // 0xe07c7c: ldur            x3, [fp, #-8]
    // 0xe07c80: r0 = LoadClassIdInstr(r3)
    //     0xe07c80: ldur            x0, [x3, #-1]
    //     0xe07c84: ubfx            x0, x0, #0xc, #0x14
    // 0xe07c88: mov             x1, x3
    // 0xe07c8c: r2 = "size"
    //     0xe07c8c: add             x2, PP, #0x22, lsl #12  ; [pp+0x22310] "size"
    //     0xe07c90: ldr             x2, [x2, #0x310]
    // 0xe07c94: r0 = GDT[cid_x0 + -0xd48]()
    //     0xe07c94: sub             lr, x0, #0xd48
    //     0xe07c98: ldr             lr, [x21, lr, lsl #3]
    //     0xe07c9c: blr             lr
    // 0xe07ca0: mov             x3, x0
    // 0xe07ca4: r2 = Null
    //     0xe07ca4: mov             x2, NULL
    // 0xe07ca8: r1 = Null
    //     0xe07ca8: mov             x1, NULL
    // 0xe07cac: stur            x3, [fp, #-0x28]
    // 0xe07cb0: branchIfSmi(r0, 0xe07cd8)
    //     0xe07cb0: tbz             w0, #0, #0xe07cd8
    // 0xe07cb4: r4 = LoadClassIdInstr(r0)
    //     0xe07cb4: ldur            x4, [x0, #-1]
    //     0xe07cb8: ubfx            x4, x4, #0xc, #0x14
    // 0xe07cbc: sub             x4, x4, #0x3c
    // 0xe07cc0: cmp             x4, #1
    // 0xe07cc4: b.ls            #0xe07cd8
    // 0xe07cc8: r8 = int
    //     0xe07cc8: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0xe07ccc: r3 = Null
    //     0xe07ccc: add             x3, PP, #0x27, lsl #12  ; [pp+0x27dc0] Null
    //     0xe07cd0: ldr             x3, [x3, #0xdc0]
    // 0xe07cd4: r0 = int()
    //     0xe07cd4: bl              #0x13ee980  ; IsType_int_Stub
    // 0xe07cd8: ldur            x1, [fp, #-8]
    // 0xe07cdc: r0 = LoadClassIdInstr(r1)
    //     0xe07cdc: ldur            x0, [x1, #-1]
    //     0xe07ce0: ubfx            x0, x0, #0xc, #0x14
    // 0xe07ce4: r2 = "identifier"
    //     0xe07ce4: ldr             x2, [PP, #0x5420]  ; [pp+0x5420] "identifier"
    // 0xe07ce8: r0 = GDT[cid_x0 + -0xd48]()
    //     0xe07ce8: sub             lr, x0, #0xd48
    //     0xe07cec: ldr             lr, [x21, lr, lsl #3]
    //     0xe07cf0: blr             lr
    // 0xe07cf4: mov             x3, x0
    // 0xe07cf8: r2 = Null
    //     0xe07cf8: mov             x2, NULL
    // 0xe07cfc: r1 = Null
    //     0xe07cfc: mov             x1, NULL
    // 0xe07d00: stur            x3, [fp, #-8]
    // 0xe07d04: r4 = 60
    //     0xe07d04: mov             x4, #0x3c
    // 0xe07d08: branchIfSmi(r0, 0xe07d14)
    //     0xe07d08: tbz             w0, #0, #0xe07d14
    // 0xe07d0c: r4 = LoadClassIdInstr(r0)
    //     0xe07d0c: ldur            x4, [x0, #-1]
    //     0xe07d10: ubfx            x4, x4, #0xc, #0x14
    // 0xe07d14: sub             x4, x4, #0x5e
    // 0xe07d18: cmp             x4, #1
    // 0xe07d1c: b.ls            #0xe07d30
    // 0xe07d20: r8 = String?
    //     0xe07d20: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0xe07d24: r3 = Null
    //     0xe07d24: add             x3, PP, #0x27, lsl #12  ; [pp+0x27dd0] Null
    //     0xe07d28: ldr             x3, [x3, #0xdd0]
    // 0xe07d2c: r0 = String?()
    //     0xe07d2c: bl              #0x7db310  ; IsType_String?_Stub
    // 0xe07d30: r0 = PlatformFile()
    //     0xe07d30: bl              #0xe07d7c  ; AllocatePlatformFileStub -> PlatformFile (size=0x24)
    // 0xe07d34: ldur            x1, [fp, #-0x18]
    // 0xe07d38: StoreField: r0->field_7 = r1
    //     0xe07d38: stur            w1, [x0, #7]
    // 0xe07d3c: ldur            x1, [fp, #-0x10]
    // 0xe07d40: StoreField: r0->field_b = r1
    //     0xe07d40: stur            w1, [x0, #0xb]
    // 0xe07d44: ldur            x1, [fp, #-0x28]
    // 0xe07d48: r2 = LoadInt32Instr(r1)
    //     0xe07d48: sbfx            x2, x1, #1, #0x1f
    //     0xe07d4c: tbz             w1, #0, #0xe07d54
    //     0xe07d50: ldur            x2, [x1, #7]
    // 0xe07d54: ArrayStore: r0[0] = r2  ; List_8
    //     0xe07d54: stur            x2, [x0, #0x17]
    // 0xe07d58: ldur            x1, [fp, #-0x20]
    // 0xe07d5c: StoreField: r0->field_f = r1
    //     0xe07d5c: stur            w1, [x0, #0xf]
    // 0xe07d60: ldur            x1, [fp, #-8]
    // 0xe07d64: StoreField: r0->field_1f = r1
    //     0xe07d64: stur            w1, [x0, #0x1f]
    // 0xe07d68: LeaveFrame
    //     0xe07d68: mov             SP, fp
    //     0xe07d6c: ldp             fp, lr, [SP], #0x10
    // 0xe07d70: ret
    //     0xe07d70: ret             
    // 0xe07d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe07d74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe07d78: b               #0xe07b68
  }
  _ toString(/* No info */) {
    // ** addr: 0x1114cdc, size: 0xfc
    // 0x1114cdc: EnterFrame
    //     0x1114cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x1114ce0: mov             fp, SP
    // 0x1114ce4: AllocStack(0x8)
    //     0x1114ce4: sub             SP, SP, #8
    // 0x1114ce8: CheckStackOverflow
    //     0x1114ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114cec: cmp             SP, x16
    //     0x1114cf0: b.ls            #0x1114dd0
    // 0x1114cf4: r1 = Null
    //     0x1114cf4: mov             x1, NULL
    // 0x1114cf8: r2 = 22
    //     0x1114cf8: mov             x2, #0x16
    // 0x1114cfc: r0 = AllocateArray()
    //     0x1114cfc: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114d00: mov             x2, x0
    // 0x1114d04: r16 = "PlatformFile(path "
    //     0x1114d04: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b058] "PlatformFile(path "
    //     0x1114d08: ldr             x16, [x16, #0x58]
    // 0x1114d0c: StoreField: r2->field_f = r16
    //     0x1114d0c: stur            w16, [x2, #0xf]
    // 0x1114d10: ldr             x0, [fp, #0x10]
    // 0x1114d14: LoadField: r1 = r0->field_7
    //     0x1114d14: ldur            w1, [x0, #7]
    // 0x1114d18: DecompressPointer r1
    //     0x1114d18: add             x1, x1, HEAP, lsl #32
    // 0x1114d1c: StoreField: r2->field_13 = r1
    //     0x1114d1c: stur            w1, [x2, #0x13]
    // 0x1114d20: r16 = ", name: "
    //     0x1114d20: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b060] ", name: "
    //     0x1114d24: ldr             x16, [x16, #0x60]
    // 0x1114d28: ArrayStore: r2[0] = r16  ; List_4
    //     0x1114d28: stur            w16, [x2, #0x17]
    // 0x1114d2c: LoadField: r1 = r0->field_b
    //     0x1114d2c: ldur            w1, [x0, #0xb]
    // 0x1114d30: DecompressPointer r1
    //     0x1114d30: add             x1, x1, HEAP, lsl #32
    // 0x1114d34: StoreField: r2->field_1b = r1
    //     0x1114d34: stur            w1, [x2, #0x1b]
    // 0x1114d38: r16 = ", bytes: "
    //     0x1114d38: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b068] ", bytes: "
    //     0x1114d3c: ldr             x16, [x16, #0x68]
    // 0x1114d40: StoreField: r2->field_1f = r16
    //     0x1114d40: stur            w16, [x2, #0x1f]
    // 0x1114d44: LoadField: r1 = r0->field_f
    //     0x1114d44: ldur            w1, [x0, #0xf]
    // 0x1114d48: DecompressPointer r1
    //     0x1114d48: add             x1, x1, HEAP, lsl #32
    // 0x1114d4c: StoreField: r2->field_23 = r1
    //     0x1114d4c: stur            w1, [x2, #0x23]
    // 0x1114d50: r16 = ", readStream: "
    //     0x1114d50: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b070] ", readStream: "
    //     0x1114d54: ldr             x16, [x16, #0x70]
    // 0x1114d58: StoreField: r2->field_27 = r16
    //     0x1114d58: stur            w16, [x2, #0x27]
    // 0x1114d5c: LoadField: r1 = r0->field_13
    //     0x1114d5c: ldur            w1, [x0, #0x13]
    // 0x1114d60: DecompressPointer r1
    //     0x1114d60: add             x1, x1, HEAP, lsl #32
    // 0x1114d64: StoreField: r2->field_2b = r1
    //     0x1114d64: stur            w1, [x2, #0x2b]
    // 0x1114d68: r16 = ", size: "
    //     0x1114d68: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b078] ", size: "
    //     0x1114d6c: ldr             x16, [x16, #0x78]
    // 0x1114d70: StoreField: r2->field_2f = r16
    //     0x1114d70: stur            w16, [x2, #0x2f]
    // 0x1114d74: ArrayLoad: r3 = r0[0]  ; List_8
    //     0x1114d74: ldur            x3, [x0, #0x17]
    // 0x1114d78: r0 = BoxInt64Instr(r3)
    //     0x1114d78: sbfiz           x0, x3, #1, #0x1f
    //     0x1114d7c: cmp             x3, x0, asr #1
    //     0x1114d80: b.eq            #0x1114d8c
    //     0x1114d84: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1114d88: stur            x3, [x0, #7]
    // 0x1114d8c: mov             x1, x2
    // 0x1114d90: ArrayStore: r1[9] = r0  ; List_4
    //     0x1114d90: add             x25, x1, #0x33
    //     0x1114d94: str             w0, [x25]
    //     0x1114d98: tbz             w0, #0, #0x1114db4
    //     0x1114d9c: ldurb           w16, [x1, #-1]
    //     0x1114da0: ldurb           w17, [x0, #-1]
    //     0x1114da4: and             x16, x17, x16, lsr #2
    //     0x1114da8: tst             x16, HEAP, lsr #32
    //     0x1114dac: b.eq            #0x1114db4
    //     0x1114db0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1114db4: r16 = ")"
    //     0x1114db4: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1114db8: StoreField: r2->field_37 = r16
    //     0x1114db8: stur            w16, [x2, #0x37]
    // 0x1114dbc: str             x2, [SP]
    // 0x1114dc0: r0 = _interpolate()
    //     0x1114dc0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114dc4: LeaveFrame
    //     0x1114dc4: mov             SP, fp
    //     0x1114dc8: ldp             fp, lr, [SP], #0x10
    // 0x1114dcc: ret
    //     0x1114dcc: ret             
    // 0x1114dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114dd4: b               #0x1114cf4
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x11497fc, size: 0x190
    // 0x11497fc: EnterFrame
    //     0x11497fc: stp             fp, lr, [SP, #-0x10]!
    //     0x1149800: mov             fp, SP
    // 0x1149804: AllocStack(0x20)
    //     0x1149804: sub             SP, SP, #0x20
    // 0x1149808: CheckStackOverflow
    //     0x1149808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114980c: cmp             SP, x16
    //     0x1149810: b.ls            #0x1149984
    // 0x1149814: ldr             x1, [fp, #0x10]
    // 0x1149818: LoadField: r0 = r1->field_7
    //     0x1149818: ldur            w0, [x1, #7]
    // 0x114981c: DecompressPointer r0
    //     0x114981c: add             x0, x0, HEAP, lsl #32
    // 0x1149820: r2 = LoadClassIdInstr(r0)
    //     0x1149820: ldur            x2, [x0, #-1]
    //     0x1149824: ubfx            x2, x2, #0xc, #0x14
    // 0x1149828: str             x0, [SP]
    // 0x114982c: mov             x0, x2
    // 0x1149830: r0 = GDT[cid_x0 + 0x70de]()
    //     0x1149830: mov             x17, #0x70de
    //     0x1149834: add             lr, x0, x17
    //     0x1149838: ldr             lr, [x21, lr, lsl #3]
    //     0x114983c: blr             lr
    // 0x1149840: mov             x2, x0
    // 0x1149844: ldr             x1, [fp, #0x10]
    // 0x1149848: stur            x2, [fp, #-8]
    // 0x114984c: LoadField: r0 = r1->field_b
    //     0x114984c: ldur            w0, [x1, #0xb]
    // 0x1149850: DecompressPointer r0
    //     0x1149850: add             x0, x0, HEAP, lsl #32
    // 0x1149854: r3 = LoadClassIdInstr(r0)
    //     0x1149854: ldur            x3, [x0, #-1]
    //     0x1149858: ubfx            x3, x3, #0xc, #0x14
    // 0x114985c: str             x0, [SP]
    // 0x1149860: mov             x0, x3
    // 0x1149864: r0 = GDT[cid_x0 + 0x70de]()
    //     0x1149864: mov             x17, #0x70de
    //     0x1149868: add             lr, x0, x17
    //     0x114986c: ldr             lr, [x21, lr, lsl #3]
    //     0x1149870: blr             lr
    // 0x1149874: mov             x1, x0
    // 0x1149878: ldur            x0, [fp, #-8]
    // 0x114987c: r2 = LoadInt32Instr(r0)
    //     0x114987c: sbfx            x2, x0, #1, #0x1f
    // 0x1149880: r0 = LoadInt32Instr(r1)
    //     0x1149880: sbfx            x0, x1, #1, #0x1f
    // 0x1149884: eor             x1, x2, x0
    // 0x1149888: ldr             x2, [fp, #0x10]
    // 0x114988c: stur            x1, [fp, #-0x10]
    // 0x1149890: LoadField: r0 = r2->field_f
    //     0x1149890: ldur            w0, [x2, #0xf]
    // 0x1149894: DecompressPointer r0
    //     0x1149894: add             x0, x0, HEAP, lsl #32
    // 0x1149898: r3 = LoadClassIdInstr(r0)
    //     0x1149898: ldur            x3, [x0, #-1]
    //     0x114989c: ubfx            x3, x3, #0xc, #0x14
    // 0x11498a0: str             x0, [SP]
    // 0x11498a4: mov             x0, x3
    // 0x11498a8: r0 = GDT[cid_x0 + 0x70de]()
    //     0x11498a8: mov             x17, #0x70de
    //     0x11498ac: add             lr, x0, x17
    //     0x11498b0: ldr             lr, [x21, lr, lsl #3]
    //     0x11498b4: blr             lr
    // 0x11498b8: r1 = LoadInt32Instr(r0)
    //     0x11498b8: sbfx            x1, x0, #1, #0x1f
    // 0x11498bc: ldur            x0, [fp, #-0x10]
    // 0x11498c0: eor             x2, x0, x1
    // 0x11498c4: r16 = 2011
    //     0x11498c4: mov             x16, #0x7db
    // 0x11498c8: eor             x1, x2, x16
    // 0x11498cc: ldr             x2, [fp, #0x10]
    // 0x11498d0: stur            x1, [fp, #-0x10]
    // 0x11498d4: LoadField: r0 = r2->field_1f
    //     0x11498d4: ldur            w0, [x2, #0x1f]
    // 0x11498d8: DecompressPointer r0
    //     0x11498d8: add             x0, x0, HEAP, lsl #32
    // 0x11498dc: r3 = LoadClassIdInstr(r0)
    //     0x11498dc: ldur            x3, [x0, #-1]
    //     0x11498e0: ubfx            x3, x3, #0xc, #0x14
    // 0x11498e4: str             x0, [SP]
    // 0x11498e8: mov             x0, x3
    // 0x11498ec: r0 = GDT[cid_x0 + 0x70de]()
    //     0x11498ec: mov             x17, #0x70de
    //     0x11498f0: add             lr, x0, x17
    //     0x11498f4: ldr             lr, [x21, lr, lsl #3]
    //     0x11498f8: blr             lr
    // 0x11498fc: r1 = LoadInt32Instr(r0)
    //     0x11498fc: sbfx            x1, x0, #1, #0x1f
    // 0x1149900: ldur            x0, [fp, #-0x10]
    // 0x1149904: eor             x2, x0, x1
    // 0x1149908: ldr             x0, [fp, #0x10]
    // 0x114990c: stur            x2, [fp, #-0x18]
    // 0x1149910: ArrayLoad: r3 = r0[0]  ; List_8
    //     0x1149910: ldur            x3, [x0, #0x17]
    // 0x1149914: r0 = BoxInt64Instr(r3)
    //     0x1149914: sbfiz           x0, x3, #1, #0x1f
    //     0x1149918: cmp             x3, x0, asr #1
    //     0x114991c: b.eq            #0x1149928
    //     0x1149920: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149924: stur            x3, [x0, #7]
    // 0x1149928: r1 = 60
    //     0x1149928: mov             x1, #0x3c
    // 0x114992c: branchIfSmi(r0, 0x1149938)
    //     0x114992c: tbz             w0, #0, #0x1149938
    // 0x1149930: r1 = LoadClassIdInstr(r0)
    //     0x1149930: ldur            x1, [x0, #-1]
    //     0x1149934: ubfx            x1, x1, #0xc, #0x14
    // 0x1149938: str             x0, [SP]
    // 0x114993c: mov             x0, x1
    // 0x1149940: r0 = GDT[cid_x0 + 0x70de]()
    //     0x1149940: mov             x17, #0x70de
    //     0x1149944: add             lr, x0, x17
    //     0x1149948: ldr             lr, [x21, lr, lsl #3]
    //     0x114994c: blr             lr
    // 0x1149950: r2 = LoadInt32Instr(r0)
    //     0x1149950: sbfx            x2, x0, #1, #0x1f
    //     0x1149954: tbz             w0, #0, #0x114995c
    //     0x1149958: ldur            x2, [x0, #7]
    // 0x114995c: ldur            x3, [fp, #-0x18]
    // 0x1149960: eor             x4, x3, x2
    // 0x1149964: r0 = BoxInt64Instr(r4)
    //     0x1149964: sbfiz           x0, x4, #1, #0x1f
    //     0x1149968: cmp             x4, x0, asr #1
    //     0x114996c: b.eq            #0x1149978
    //     0x1149970: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149974: stur            x4, [x0, #7]
    // 0x1149978: LeaveFrame
    //     0x1149978: mov             SP, fp
    //     0x114997c: ldp             fp, lr, [SP], #0x10
    // 0x1149980: ret
    //     0x1149980: ret             
    // 0x1149984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1149984: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1149988: b               #0x1149814
  }
  _ ==(/* No info */) {
    // ** addr: 0x1293a64, size: 0x180
    // 0x1293a64: EnterFrame
    //     0x1293a64: stp             fp, lr, [SP, #-0x10]!
    //     0x1293a68: mov             fp, SP
    // 0x1293a6c: AllocStack(0x10)
    //     0x1293a6c: sub             SP, SP, #0x10
    // 0x1293a70: CheckStackOverflow
    //     0x1293a70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1293a74: cmp             SP, x16
    //     0x1293a78: b.ls            #0x1293bdc
    // 0x1293a7c: ldr             x1, [fp, #0x10]
    // 0x1293a80: cmp             w1, NULL
    // 0x1293a84: b.ne            #0x1293a98
    // 0x1293a88: r0 = false
    //     0x1293a88: add             x0, NULL, #0x30  ; false
    // 0x1293a8c: LeaveFrame
    //     0x1293a8c: mov             SP, fp
    //     0x1293a90: ldp             fp, lr, [SP], #0x10
    // 0x1293a94: ret
    //     0x1293a94: ret             
    // 0x1293a98: ldr             x2, [fp, #0x18]
    // 0x1293a9c: cmp             w2, w1
    // 0x1293aa0: b.ne            #0x1293ab4
    // 0x1293aa4: r0 = true
    //     0x1293aa4: add             x0, NULL, #0x20  ; true
    // 0x1293aa8: LeaveFrame
    //     0x1293aa8: mov             SP, fp
    //     0x1293aac: ldp             fp, lr, [SP], #0x10
    // 0x1293ab0: ret
    //     0x1293ab0: ret             
    // 0x1293ab4: r0 = 60
    //     0x1293ab4: mov             x0, #0x3c
    // 0x1293ab8: branchIfSmi(r1, 0x1293ac4)
    //     0x1293ab8: tbz             w1, #0, #0x1293ac4
    // 0x1293abc: r0 = LoadClassIdInstr(r1)
    //     0x1293abc: ldur            x0, [x1, #-1]
    //     0x1293ac0: ubfx            x0, x0, #0xc, #0x14
    // 0x1293ac4: cmp             x0, #0xd30
    // 0x1293ac8: b.ne            #0x1293bcc
    // 0x1293acc: LoadField: r0 = r1->field_7
    //     0x1293acc: ldur            w0, [x1, #7]
    // 0x1293ad0: DecompressPointer r0
    //     0x1293ad0: add             x0, x0, HEAP, lsl #32
    // 0x1293ad4: LoadField: r3 = r2->field_7
    //     0x1293ad4: ldur            w3, [x2, #7]
    // 0x1293ad8: DecompressPointer r3
    //     0x1293ad8: add             x3, x3, HEAP, lsl #32
    // 0x1293adc: r4 = LoadClassIdInstr(r0)
    //     0x1293adc: ldur            x4, [x0, #-1]
    //     0x1293ae0: ubfx            x4, x4, #0xc, #0x14
    // 0x1293ae4: stp             x3, x0, [SP]
    // 0x1293ae8: mov             x0, x4
    // 0x1293aec: mov             lr, x0
    // 0x1293af0: ldr             lr, [x21, lr, lsl #3]
    // 0x1293af4: blr             lr
    // 0x1293af8: tbnz            w0, #4, #0x1293bcc
    // 0x1293afc: ldr             x2, [fp, #0x18]
    // 0x1293b00: ldr             x1, [fp, #0x10]
    // 0x1293b04: LoadField: r0 = r1->field_b
    //     0x1293b04: ldur            w0, [x1, #0xb]
    // 0x1293b08: DecompressPointer r0
    //     0x1293b08: add             x0, x0, HEAP, lsl #32
    // 0x1293b0c: LoadField: r3 = r2->field_b
    //     0x1293b0c: ldur            w3, [x2, #0xb]
    // 0x1293b10: DecompressPointer r3
    //     0x1293b10: add             x3, x3, HEAP, lsl #32
    // 0x1293b14: r4 = LoadClassIdInstr(r0)
    //     0x1293b14: ldur            x4, [x0, #-1]
    //     0x1293b18: ubfx            x4, x4, #0xc, #0x14
    // 0x1293b1c: stp             x3, x0, [SP]
    // 0x1293b20: mov             x0, x4
    // 0x1293b24: mov             lr, x0
    // 0x1293b28: ldr             lr, [x21, lr, lsl #3]
    // 0x1293b2c: blr             lr
    // 0x1293b30: tbnz            w0, #4, #0x1293bcc
    // 0x1293b34: ldr             x2, [fp, #0x18]
    // 0x1293b38: ldr             x1, [fp, #0x10]
    // 0x1293b3c: LoadField: r0 = r1->field_f
    //     0x1293b3c: ldur            w0, [x1, #0xf]
    // 0x1293b40: DecompressPointer r0
    //     0x1293b40: add             x0, x0, HEAP, lsl #32
    // 0x1293b44: LoadField: r3 = r2->field_f
    //     0x1293b44: ldur            w3, [x2, #0xf]
    // 0x1293b48: DecompressPointer r3
    //     0x1293b48: add             x3, x3, HEAP, lsl #32
    // 0x1293b4c: r4 = LoadClassIdInstr(r0)
    //     0x1293b4c: ldur            x4, [x0, #-1]
    //     0x1293b50: ubfx            x4, x4, #0xc, #0x14
    // 0x1293b54: stp             x3, x0, [SP]
    // 0x1293b58: mov             x0, x4
    // 0x1293b5c: mov             lr, x0
    // 0x1293b60: ldr             lr, [x21, lr, lsl #3]
    // 0x1293b64: blr             lr
    // 0x1293b68: tbnz            w0, #4, #0x1293bcc
    // 0x1293b6c: ldr             x2, [fp, #0x18]
    // 0x1293b70: ldr             x1, [fp, #0x10]
    // 0x1293b74: LoadField: r0 = r1->field_1f
    //     0x1293b74: ldur            w0, [x1, #0x1f]
    // 0x1293b78: DecompressPointer r0
    //     0x1293b78: add             x0, x0, HEAP, lsl #32
    // 0x1293b7c: LoadField: r3 = r2->field_1f
    //     0x1293b7c: ldur            w3, [x2, #0x1f]
    // 0x1293b80: DecompressPointer r3
    //     0x1293b80: add             x3, x3, HEAP, lsl #32
    // 0x1293b84: r4 = LoadClassIdInstr(r0)
    //     0x1293b84: ldur            x4, [x0, #-1]
    //     0x1293b88: ubfx            x4, x4, #0xc, #0x14
    // 0x1293b8c: stp             x3, x0, [SP]
    // 0x1293b90: mov             x0, x4
    // 0x1293b94: mov             lr, x0
    // 0x1293b98: ldr             lr, [x21, lr, lsl #3]
    // 0x1293b9c: blr             lr
    // 0x1293ba0: tbnz            w0, #4, #0x1293bcc
    // 0x1293ba4: ldr             x2, [fp, #0x18]
    // 0x1293ba8: ldr             x1, [fp, #0x10]
    // 0x1293bac: ArrayLoad: r3 = r1[0]  ; List_8
    //     0x1293bac: ldur            x3, [x1, #0x17]
    // 0x1293bb0: ArrayLoad: r1 = r2[0]  ; List_8
    //     0x1293bb0: ldur            x1, [x2, #0x17]
    // 0x1293bb4: cmp             x3, x1
    // 0x1293bb8: r16 = true
    //     0x1293bb8: add             x16, NULL, #0x20  ; true
    // 0x1293bbc: r17 = false
    //     0x1293bbc: add             x17, NULL, #0x30  ; false
    // 0x1293bc0: csel            x2, x16, x17, eq
    // 0x1293bc4: mov             x0, x2
    // 0x1293bc8: b               #0x1293bd0
    // 0x1293bcc: r0 = false
    //     0x1293bcc: add             x0, NULL, #0x30  ; false
    // 0x1293bd0: LeaveFrame
    //     0x1293bd0: mov             SP, fp
    //     0x1293bd4: ldp             fp, lr, [SP], #0x10
    // 0x1293bd8: ret
    //     0x1293bd8: ret             
    // 0x1293bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1293bdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1293be0: b               #0x1293a7c
  }
}
