// lib: , url: package:file_picker/src/api/file_picker_result.dart

// class id: 1048738, size: 0x8
class :: {
}

// class id: 3377, size: 0xc, field offset: 0x8
//   const constructor, 
class FilePickerResult extends Object {

  get _ paths(/* No info */) {
    // ** addr: 0xe07498, size: 0x148
    // 0xe07498: EnterFrame
    //     0xe07498: stp             fp, lr, [SP, #-0x10]!
    //     0xe0749c: mov             fp, SP
    // 0xe074a0: AllocStack(0x28)
    //     0xe074a0: sub             SP, SP, #0x28
    // 0xe074a4: CheckStackOverflow
    //     0xe074a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe074a8: cmp             SP, x16
    //     0xe074ac: b.ls            #0xe075d8
    // 0xe074b0: LoadField: r0 = r1->field_7
    //     0xe074b0: ldur            w0, [x1, #7]
    // 0xe074b4: DecompressPointer r0
    //     0xe074b4: add             x0, x0, HEAP, lsl #32
    // 0xe074b8: stur            x0, [fp, #-8]
    // 0xe074bc: r1 = Function '<anonymous closure>':.
    //     0xe074bc: add             x1, PP, #0x27, lsl #12  ; [pp+0x27cf8] Function: [dart:ui] Image::_image (0x11191c8)
    //     0xe074c0: ldr             x1, [x1, #0xcf8]
    // 0xe074c4: r2 = Null
    //     0xe074c4: mov             x2, NULL
    // 0xe074c8: r0 = AllocateClosure()
    //     0xe074c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xe074cc: r16 = <String?>
    //     0xe074cc: ldr             x16, [PP, #0xe28]  ; [pp+0xe28] TypeArguments: <String?>
    // 0xe074d0: ldur            lr, [fp, #-8]
    // 0xe074d4: stp             lr, x16, [SP, #8]
    // 0xe074d8: str             x0, [SP]
    // 0xe074dc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xe074dc: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xe074e0: r0 = map()
    //     0xe074e0: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xe074e4: mov             x3, x0
    // 0xe074e8: stur            x3, [fp, #-0x10]
    // 0xe074ec: LoadField: r4 = r3->field_7
    //     0xe074ec: ldur            w4, [x3, #7]
    // 0xe074f0: DecompressPointer r4
    //     0xe074f0: add             x4, x4, HEAP, lsl #32
    // 0xe074f4: mov             x0, x3
    // 0xe074f8: stur            x4, [fp, #-8]
    // 0xe074fc: r2 = Null
    //     0xe074fc: mov             x2, NULL
    // 0xe07500: r1 = Null
    //     0xe07500: mov             x1, NULL
    // 0xe07504: cmp             w0, NULL
    // 0xe07508: b.eq            #0xe075a0
    // 0xe0750c: branchIfSmi(r0, 0xe075a0)
    //     0xe0750c: tbz             w0, #0, #0xe075a0
    // 0xe07510: r3 = LoadClassIdInstr(r0)
    //     0xe07510: ldur            x3, [x0, #-1]
    //     0xe07514: ubfx            x3, x3, #0xc, #0x14
    // 0xe07518: r17 = 7724
    //     0xe07518: mov             x17, #0x1e2c
    // 0xe0751c: cmp             x3, x17
    // 0xe07520: b.eq            #0xe075a8
    // 0xe07524: r4 = LoadClassIdInstr(r0)
    //     0xe07524: ldur            x4, [x0, #-1]
    //     0xe07528: ubfx            x4, x4, #0xc, #0x14
    // 0xe0752c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xe07530: ldr             x3, [x3, #0x18]
    // 0xe07534: ldr             x3, [x3, x4, lsl #3]
    // 0xe07538: LoadField: r3 = r3->field_2b
    //     0xe07538: ldur            w3, [x3, #0x2b]
    // 0xe0753c: DecompressPointer r3
    //     0xe0753c: add             x3, x3, HEAP, lsl #32
    // 0xe07540: cmp             w3, NULL
    // 0xe07544: b.eq            #0xe075a0
    // 0xe07548: LoadField: r3 = r3->field_f
    //     0xe07548: ldur            w3, [x3, #0xf]
    // 0xe0754c: lsr             x3, x3, #3
    // 0xe07550: r17 = 7724
    //     0xe07550: mov             x17, #0x1e2c
    // 0xe07554: cmp             x3, x17
    // 0xe07558: b.eq            #0xe075a8
    // 0xe0755c: r3 = SubtypeTestCache
    //     0xe0755c: add             x3, PP, #0x27, lsl #12  ; [pp+0x27d00] SubtypeTestCache
    //     0xe07560: ldr             x3, [x3, #0xd00]
    // 0xe07564: r30 = Subtype1TestCacheStub
    //     0xe07564: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xe07568: LoadField: r30 = r30->field_7
    //     0xe07568: ldur            lr, [lr, #7]
    // 0xe0756c: blr             lr
    // 0xe07570: cmp             w7, NULL
    // 0xe07574: b.eq            #0xe07580
    // 0xe07578: tbnz            w7, #4, #0xe075a0
    // 0xe0757c: b               #0xe075a8
    // 0xe07580: r8 = EfficientLengthIterable
    //     0xe07580: add             x8, PP, #0x27, lsl #12  ; [pp+0x27d08] Type: EfficientLengthIterable
    //     0xe07584: ldr             x8, [x8, #0xd08]
    // 0xe07588: r3 = SubtypeTestCache
    //     0xe07588: add             x3, PP, #0x27, lsl #12  ; [pp+0x27d10] SubtypeTestCache
    //     0xe0758c: ldr             x3, [x3, #0xd10]
    // 0xe07590: r30 = InstanceOfStub
    //     0xe07590: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xe07594: LoadField: r30 = r30->field_7
    //     0xe07594: ldur            lr, [lr, #7]
    // 0xe07598: blr             lr
    // 0xe0759c: b               #0xe075ac
    // 0xe075a0: r0 = false
    //     0xe075a0: add             x0, NULL, #0x30  ; false
    // 0xe075a4: b               #0xe075ac
    // 0xe075a8: r0 = true
    //     0xe075a8: add             x0, NULL, #0x20  ; true
    // 0xe075ac: tbnz            w0, #4, #0xe075c0
    // 0xe075b0: ldur            x1, [fp, #-8]
    // 0xe075b4: ldur            x2, [fp, #-0x10]
    // 0xe075b8: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0xe075b8: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0xe075bc: b               #0xe075cc
    // 0xe075c0: ldur            x1, [fp, #-8]
    // 0xe075c4: ldur            x2, [fp, #-0x10]
    // 0xe075c8: r0 = _GrowableList._ofOther()
    //     0xe075c8: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0xe075cc: LeaveFrame
    //     0xe075cc: mov             SP, fp
    //     0xe075d0: ldp             fp, lr, [SP], #0x10
    // 0xe075d4: ret
    //     0xe075d4: ret             
    // 0xe075d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe075d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe075dc: b               #0xe074b0
  }
  _ toString(/* No info */) {
    // ** addr: 0x1114c78, size: 0x64
    // 0x1114c78: EnterFrame
    //     0x1114c78: stp             fp, lr, [SP, #-0x10]!
    //     0x1114c7c: mov             fp, SP
    // 0x1114c80: AllocStack(0x8)
    //     0x1114c80: sub             SP, SP, #8
    // 0x1114c84: CheckStackOverflow
    //     0x1114c84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114c88: cmp             SP, x16
    //     0x1114c8c: b.ls            #0x1114cd4
    // 0x1114c90: r1 = Null
    //     0x1114c90: mov             x1, NULL
    // 0x1114c94: r2 = 6
    //     0x1114c94: mov             x2, #6
    // 0x1114c98: r0 = AllocateArray()
    //     0x1114c98: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114c9c: r16 = "FilePickerResult(files: "
    //     0x1114c9c: add             x16, PP, #0x8b, lsl #12  ; [pp+0x8b088] "FilePickerResult(files: "
    //     0x1114ca0: ldr             x16, [x16, #0x88]
    // 0x1114ca4: StoreField: r0->field_f = r16
    //     0x1114ca4: stur            w16, [x0, #0xf]
    // 0x1114ca8: ldr             x1, [fp, #0x10]
    // 0x1114cac: LoadField: r2 = r1->field_7
    //     0x1114cac: ldur            w2, [x1, #7]
    // 0x1114cb0: DecompressPointer r2
    //     0x1114cb0: add             x2, x2, HEAP, lsl #32
    // 0x1114cb4: StoreField: r0->field_13 = r2
    //     0x1114cb4: stur            w2, [x0, #0x13]
    // 0x1114cb8: r16 = ")"
    //     0x1114cb8: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x1114cbc: ArrayStore: r0[0] = r16  ; List_4
    //     0x1114cbc: stur            w16, [x0, #0x17]
    // 0x1114cc0: str             x0, [SP]
    // 0x1114cc4: r0 = _interpolate()
    //     0x1114cc4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114cc8: LeaveFrame
    //     0x1114cc8: mov             SP, fp
    //     0x1114ccc: ldp             fp, lr, [SP], #0x10
    // 0x1114cd0: ret
    //     0x1114cd0: ret             
    // 0x1114cd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114cd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114cd8: b               #0x1114c90
  }
  _ ==(/* No info */) {
    // ** addr: 0x12939b8, size: 0xac
    // 0x12939b8: EnterFrame
    //     0x12939b8: stp             fp, lr, [SP, #-0x10]!
    //     0x12939bc: mov             fp, SP
    // 0x12939c0: AllocStack(0x18)
    //     0x12939c0: sub             SP, SP, #0x18
    // 0x12939c4: CheckStackOverflow
    //     0x12939c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12939c8: cmp             SP, x16
    //     0x12939cc: b.ls            #0x1293a5c
    // 0x12939d0: ldr             x0, [fp, #0x10]
    // 0x12939d4: cmp             w0, NULL
    // 0x12939d8: b.ne            #0x12939ec
    // 0x12939dc: r0 = false
    //     0x12939dc: add             x0, NULL, #0x30  ; false
    // 0x12939e0: LeaveFrame
    //     0x12939e0: mov             SP, fp
    //     0x12939e4: ldp             fp, lr, [SP], #0x10
    // 0x12939e8: ret
    //     0x12939e8: ret             
    // 0x12939ec: ldr             x1, [fp, #0x18]
    // 0x12939f0: cmp             w1, w0
    // 0x12939f4: b.ne            #0x1293a08
    // 0x12939f8: r0 = true
    //     0x12939f8: add             x0, NULL, #0x20  ; true
    // 0x12939fc: LeaveFrame
    //     0x12939fc: mov             SP, fp
    //     0x1293a00: ldp             fp, lr, [SP], #0x10
    // 0x1293a04: ret
    //     0x1293a04: ret             
    // 0x1293a08: r2 = 60
    //     0x1293a08: mov             x2, #0x3c
    // 0x1293a0c: branchIfSmi(r0, 0x1293a18)
    //     0x1293a0c: tbz             w0, #0, #0x1293a18
    // 0x1293a10: r2 = LoadClassIdInstr(r0)
    //     0x1293a10: ldur            x2, [x0, #-1]
    //     0x1293a14: ubfx            x2, x2, #0xc, #0x14
    // 0x1293a18: cmp             x2, #0xd31
    // 0x1293a1c: b.ne            #0x1293a4c
    // 0x1293a20: LoadField: r2 = r0->field_7
    //     0x1293a20: ldur            w2, [x0, #7]
    // 0x1293a24: DecompressPointer r2
    //     0x1293a24: add             x2, x2, HEAP, lsl #32
    // 0x1293a28: LoadField: r0 = r1->field_7
    //     0x1293a28: ldur            w0, [x1, #7]
    // 0x1293a2c: DecompressPointer r0
    //     0x1293a2c: add             x0, x0, HEAP, lsl #32
    // 0x1293a30: r16 = <PlatformFile>
    //     0x1293a30: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d60] TypeArguments: <PlatformFile>
    //     0x1293a34: ldr             x16, [x16, #0xd60]
    // 0x1293a38: stp             x2, x16, [SP, #8]
    // 0x1293a3c: str             x0, [SP]
    // 0x1293a40: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1293a40: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1293a44: r0 = listEquals()
    //     0x1293a44: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x1293a48: b               #0x1293a50
    // 0x1293a4c: r0 = false
    //     0x1293a4c: add             x0, NULL, #0x30  ; false
    // 0x1293a50: LeaveFrame
    //     0x1293a50: mov             SP, fp
    //     0x1293a54: ldp             fp, lr, [SP], #0x10
    // 0x1293a58: ret
    //     0x1293a58: ret             
    // 0x1293a5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1293a5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1293a60: b               #0x12939d0
  }
}
