// lib: , url: package:file_picker/src/file_picker.dart

// class id: 1048741, size: 0x8
class :: {
}

// class id: 3375, size: 0x8, field offset: 0x8
abstract class FilePicker extends Object {

  static _ pickFiles(/* No info */) {
    // ** addr: 0xe07600, size: 0x158
    // 0xe07600: EnterFrame
    //     0xe07600: stp             fp, lr, [SP, #-0x10]!
    //     0xe07604: mov             fp, SP
    // 0xe07608: AllocStack(0x18)
    //     0xe07608: sub             SP, SP, #0x18
    // 0xe0760c: SetupParameters({dynamic allowMultiple = false /* r3, fp-0x18 */, dynamic allowedExtensions = Null /* r5, fp-0x10 */, dynamic type = Instance_FileType /* r2, fp-0x8 */})
    //     0xe0760c: ldur            w0, [x4, #0x13]
    //     0xe07610: ldur            w1, [x4, #0x1f]
    //     0xe07614: add             x1, x1, HEAP, lsl #32
    //     0xe07618: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d18] "allowMultiple"
    //     0xe0761c: ldr             x16, [x16, #0xd18]
    //     0xe07620: cmp             w1, w16
    //     0xe07624: b.ne            #0xe07648
    //     0xe07628: ldur            w1, [x4, #0x23]
    //     0xe0762c: add             x1, x1, HEAP, lsl #32
    //     0xe07630: sub             w2, w0, w1
    //     0xe07634: add             x1, fp, w2, sxtw #2
    //     0xe07638: ldr             x1, [x1, #8]
    //     0xe0763c: mov             x3, x1
    //     0xe07640: mov             x1, #1
    //     0xe07644: b               #0xe07650
    //     0xe07648: add             x3, NULL, #0x30  ; false
    //     0xe0764c: mov             x1, #0
    //     0xe07650: stur            x3, [fp, #-0x18]
    //     0xe07654: lsl             x2, x1, #1
    //     0xe07658: lsl             w5, w2, #1
    //     0xe0765c: add             w6, w5, #8
    //     0xe07660: add             x16, x4, w6, sxtw #1
    //     0xe07664: ldur            w7, [x16, #0xf]
    //     0xe07668: add             x7, x7, HEAP, lsl #32
    //     0xe0766c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d20] "allowedExtensions"
    //     0xe07670: ldr             x16, [x16, #0xd20]
    //     0xe07674: cmp             w7, w16
    //     0xe07678: b.ne            #0xe076a8
    //     0xe0767c: add             w1, w5, #0xa
    //     0xe07680: add             x16, x4, w1, sxtw #1
    //     0xe07684: ldur            w5, [x16, #0xf]
    //     0xe07688: add             x5, x5, HEAP, lsl #32
    //     0xe0768c: sub             w1, w0, w5
    //     0xe07690: add             x5, fp, w1, sxtw #2
    //     0xe07694: ldr             x5, [x5, #8]
    //     0xe07698: add             w1, w2, #2
    //     0xe0769c: sbfx            x2, x1, #1, #0x1f
    //     0xe076a0: mov             x1, x2
    //     0xe076a4: b               #0xe076ac
    //     0xe076a8: mov             x5, NULL
    //     0xe076ac: stur            x5, [fp, #-0x10]
    //     0xe076b0: lsl             x2, x1, #1
    //     0xe076b4: lsl             w1, w2, #1
    //     0xe076b8: add             w2, w1, #8
    //     0xe076bc: add             x16, x4, w2, sxtw #1
    //     0xe076c0: ldur            w6, [x16, #0xf]
    //     0xe076c4: add             x6, x6, HEAP, lsl #32
    //     0xe076c8: ldr             x16, [PP, #0x3250]  ; [pp+0x3250] "type"
    //     0xe076cc: cmp             w6, w16
    //     0xe076d0: b.ne            #0xe076f8
    //     0xe076d4: add             w2, w1, #0xa
    //     0xe076d8: add             x16, x4, w2, sxtw #1
    //     0xe076dc: ldur            w1, [x16, #0xf]
    //     0xe076e0: add             x1, x1, HEAP, lsl #32
    //     0xe076e4: sub             w2, w0, w1
    //     0xe076e8: add             x0, fp, w2, sxtw #2
    //     0xe076ec: ldr             x0, [x0, #8]
    //     0xe076f0: mov             x2, x0
    //     0xe076f4: b               #0xe07700
    //     0xe076f8: add             x2, PP, #0x27, lsl #12  ; [pp+0x27d28] Obj!FileType@12c62e1
    //     0xe076fc: ldr             x2, [x2, #0xd28]
    //     0xe07700: stur            x2, [fp, #-8]
    // 0xe07704: CheckStackOverflow
    //     0xe07704: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe07708: cmp             SP, x16
    //     0xe0770c: b.ls            #0xe07750
    // 0xe07710: r0 = LoadStaticField(0xf18)
    //     0xe07710: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe07714: ldr             x0, [x0, #0x1e30]
    // 0xe07718: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe0771c: cmp             w0, w16
    // 0xe07720: b.ne            #0xe07730
    // 0xe07724: r2 = _instance
    //     0xe07724: add             x2, PP, #0x27, lsl #12  ; [pp+0x27d30] Field <FilePickerPlatform._instance@1170424656>: static late (offset: 0xf18)
    //     0xe07728: ldr             x2, [x2, #0xd30]
    // 0xe0772c: r0 = InitLateStaticField()
    //     0xe0772c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xe07730: mov             x1, x0
    // 0xe07734: ldur            x2, [fp, #-8]
    // 0xe07738: ldur            x3, [fp, #-0x18]
    // 0xe0773c: ldur            x5, [fp, #-0x10]
    // 0xe07740: r0 = _getPath()
    //     0xe07740: bl              #0xe07758  ; [package:file_picker/src/platform/file_picker_method_channel.dart] MethodChannelFilePicker::_getPath
    // 0xe07744: LeaveFrame
    //     0xe07744: mov             SP, fp
    //     0xe07748: ldp             fp, lr, [SP], #0x10
    // 0xe0774c: ret
    //     0xe0774c: ret             
    // 0xe07750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe07750: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe07754: b               #0xe07710
  }
  static _ saveFile(/* No info */) {
    // ** addr: 0xe9bfc8, size: 0x7c
    // 0xe9bfc8: EnterFrame
    //     0xe9bfc8: stp             fp, lr, [SP, #-0x10]!
    //     0xe9bfcc: mov             fp, SP
    // 0xe9bfd0: AllocStack(0x10)
    //     0xe9bfd0: sub             SP, SP, #0x10
    // 0xe9bfd4: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r5, fp-0x10 */)
    //     0xe9bfd4: mov             x3, x1
    //     0xe9bfd8: mov             x5, x2
    //     0xe9bfdc: stur            x1, [fp, #-8]
    //     0xe9bfe0: stur            x2, [fp, #-0x10]
    // 0xe9bfe4: CheckStackOverflow
    //     0xe9bfe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe9bfe8: cmp             SP, x16
    //     0xe9bfec: b.ls            #0xe9c03c
    // 0xe9bff0: r0 = LoadStaticField(0xf18)
    //     0xe9bff0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe9bff4: ldr             x0, [x0, #0x1e30]
    // 0xe9bff8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe9bffc: cmp             w0, w16
    // 0xe9c000: b.ne            #0xe9c010
    // 0xe9c004: r2 = _instance
    //     0xe9c004: add             x2, PP, #0x27, lsl #12  ; [pp+0x27d30] Field <FilePickerPlatform._instance@1170424656>: static late (offset: 0xf18)
    //     0xe9c008: ldr             x2, [x2, #0xd30]
    // 0xe9c00c: r0 = InitLateStaticField()
    //     0xe9c00c: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xe9c010: mov             x1, x0
    // 0xe9c014: ldur            x3, [fp, #-8]
    // 0xe9c018: ldur            x5, [fp, #-0x10]
    // 0xe9c01c: r2 = Null
    //     0xe9c01c: mov             x2, NULL
    // 0xe9c020: r6 = Null
    //     0xe9c020: mov             x6, NULL
    // 0xe9c024: r7 = Instance_FileType
    //     0xe9c024: add             x7, PP, #0x27, lsl #12  ; [pp+0x27d28] Obj!FileType@12c62e1
    //     0xe9c028: ldr             x7, [x7, #0xd28]
    // 0xe9c02c: r0 = saveFile()
    //     0xe9c02c: bl              #0xe9c044  ; [package:file_picker/src/platform/file_picker_method_channel.dart] MethodChannelFilePicker::saveFile
    // 0xe9c030: LeaveFrame
    //     0xe9c030: mov             SP, fp
    //     0xe9c034: ldp             fp, lr, [SP], #0x10
    // 0xe9c038: ret
    //     0xe9c038: ret             
    // 0xe9c03c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe9c03c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe9c040: b               #0xe9bff0
  }
}
