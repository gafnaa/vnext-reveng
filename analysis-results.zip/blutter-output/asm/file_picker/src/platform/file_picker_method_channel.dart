// lib: , url: package:file_picker/src/platform/file_picker_method_channel.dart

// class id: 1048742, size: 0x8
class :: {
}

// class id: 3706, size: 0xc, field offset: 0x8
class MethodChannelFilePicker extends FilePickerPlatform {

  _ _getPath(/* No info */) async {
    // ** addr: 0xe07758, size: 0x3e4
    // 0xe07758: EnterFrame
    //     0xe07758: stp             fp, lr, [SP, #-0x10]!
    //     0xe0775c: mov             fp, SP
    // 0xe07760: AllocStack(0xf0)
    //     0xe07760: sub             SP, SP, #0xf0
    // 0xe07764: SetupParameters(MethodChannelFilePicker this /* r1 => r1, fp-0xa0 */, dynamic _ /* r2 => r2, fp-0xa8 */, dynamic _ /* r3 => r3, fp-0xb0 */, dynamic _ /* r5 => r5, fp-0xb8 */)
    //     0xe07764: stur            NULL, [fp, #-8]
    //     0xe07768: stur            x1, [fp, #-0xa0]
    //     0xe0776c: stur            x2, [fp, #-0xa8]
    //     0xe07770: stur            x3, [fp, #-0xb0]
    //     0xe07774: stur            x5, [fp, #-0xb8]
    // 0xe07778: CheckStackOverflow
    //     0xe07778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe0777c: cmp             SP, x16
    //     0xe07780: b.ls            #0xe07b2c
    // 0xe07784: InitAsync() -> Future<FilePickerResult?>
    //     0xe07784: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d38] TypeArguments: <FilePickerResult?>
    //     0xe07788: ldr             x0, [x0, #0xd38]
    //     0xe0778c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xe07790: ldur            x0, [fp, #-0xa8]
    // 0xe07794: LoadField: r1 = r0->field_f
    //     0xe07794: ldur            w1, [x0, #0xf]
    // 0xe07798: DecompressPointer r1
    //     0xe07798: add             x1, x1, HEAP, lsl #32
    // 0xe0779c: stur            x1, [fp, #-0xc0]
    // 0xe077a0: r16 = "custom"
    //     0xe077a0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d40] "custom"
    //     0xe077a4: ldr             x16, [x16, #0xd40]
    // 0xe077a8: stp             x16, x1, [SP]
    // 0xe077ac: r0 = ==()
    //     0xe077ac: bl              #0x12b75a4  ; [dart:core] _OneByteString::==
    // 0xe077b0: tbz             w0, #4, #0xe077f0
    // 0xe077b4: ldur            x1, [fp, #-0xb8]
    // 0xe077b8: cmp             w1, NULL
    // 0xe077bc: b.ne            #0xe077c8
    // 0xe077c0: r0 = Null
    //     0xe077c0: mov             x0, NULL
    // 0xe077c4: b               #0xe077e0
    // 0xe077c8: LoadField: r0 = r1->field_b
    //     0xe077c8: ldur            w0, [x1, #0xb]
    // 0xe077cc: cbnz            w0, #0xe077d8
    // 0xe077d0: r2 = false
    //     0xe077d0: add             x2, NULL, #0x30  ; false
    // 0xe077d4: b               #0xe077dc
    // 0xe077d8: r2 = true
    //     0xe077d8: add             x2, NULL, #0x20  ; true
    // 0xe077dc: mov             x0, x2
    // 0xe077e0: cmp             w0, NULL
    // 0xe077e4: b.eq            #0xe077f4
    // 0xe077e8: tbnz            w0, #4, #0xe077f4
    // 0xe077ec: b               #0xe07a14
    // 0xe077f0: ldur            x1, [fp, #-0xb8]
    // 0xe077f4: ldur            x3, [fp, #-0xa0]
    // 0xe077f8: ldur            x2, [fp, #-0xb0]
    // 0xe077fc: r0 = Null
    //     0xe077fc: mov             x0, NULL
    // 0xe07800: r0 = Await()
    //     0xe07800: bl              #0x7f5c00  ; AwaitStub
    // 0xe07804: ldur            x0, [fp, #-0xa0]
    // 0xe07808: LoadField: r3 = r0->field_7
    //     0xe07808: ldur            w3, [x0, #7]
    // 0xe0780c: DecompressPointer r3
    //     0xe0780c: add             x3, x3, HEAP, lsl #32
    // 0xe07810: stur            x3, [fp, #-0xa8]
    // 0xe07814: r1 = Null
    //     0xe07814: mov             x1, NULL
    // 0xe07818: r2 = 16
    //     0xe07818: mov             x2, #0x10
    // 0xe0781c: r0 = AllocateArray()
    //     0xe0781c: bl              #0x13df928  ; AllocateArrayStub
    // 0xe07820: r16 = "allowMultipleSelection"
    //     0xe07820: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d48] "allowMultipleSelection"
    //     0xe07824: ldr             x16, [x16, #0xd48]
    // 0xe07828: StoreField: r0->field_f = r16
    //     0xe07828: stur            w16, [x0, #0xf]
    // 0xe0782c: ldur            x1, [fp, #-0xb0]
    // 0xe07830: StoreField: r0->field_13 = r1
    //     0xe07830: stur            w1, [x0, #0x13]
    // 0xe07834: r16 = "allowedExtensions"
    //     0xe07834: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d20] "allowedExtensions"
    //     0xe07838: ldr             x16, [x16, #0xd20]
    // 0xe0783c: ArrayStore: r0[0] = r16  ; List_4
    //     0xe0783c: stur            w16, [x0, #0x17]
    // 0xe07840: ldur            x2, [fp, #-0xb8]
    // 0xe07844: StoreField: r0->field_1b = r2
    //     0xe07844: stur            w2, [x0, #0x1b]
    // 0xe07848: r16 = "withData"
    //     0xe07848: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d50] "withData"
    //     0xe0784c: ldr             x16, [x16, #0xd50]
    // 0xe07850: StoreField: r0->field_1f = r16
    //     0xe07850: stur            w16, [x0, #0x1f]
    // 0xe07854: r16 = false
    //     0xe07854: add             x16, NULL, #0x30  ; false
    // 0xe07858: StoreField: r0->field_23 = r16
    //     0xe07858: stur            w16, [x0, #0x23]
    // 0xe0785c: r16 = "compressionQuality"
    //     0xe0785c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d58] "compressionQuality"
    //     0xe07860: ldr             x16, [x16, #0xd58]
    // 0xe07864: StoreField: r0->field_27 = r16
    //     0xe07864: stur            w16, [x0, #0x27]
    // 0xe07868: StoreField: r0->field_2b = rZR
    //     0xe07868: stur            wzr, [x0, #0x2b]
    // 0xe0786c: r16 = <String, Object?>
    //     0xe0786c: add             x16, PP, #8, lsl #12  ; [pp+0x8128] TypeArguments: <String, Object?>
    //     0xe07870: ldr             x16, [x16, #0x128]
    // 0xe07874: stp             x0, x16, [SP]
    // 0xe07878: r0 = Map._fromLiteral()
    //     0xe07878: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xe0787c: r16 = <Map>
    //     0xe0787c: ldr             x16, [PP, #0xa0]  ; [pp+0xa0] TypeArguments: <Map>
    // 0xe07880: ldur            lr, [fp, #-0xa8]
    // 0xe07884: stp             lr, x16, [SP, #0x10]
    // 0xe07888: ldur            x16, [fp, #-0xc0]
    // 0xe0788c: stp             x0, x16, [SP]
    // 0xe07890: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xe07890: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xe07894: r0 = invokeListMethod()
    //     0xe07894: bl              #0x920090  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeListMethod
    // 0xe07898: mov             x1, x0
    // 0xe0789c: stur            x1, [fp, #-0xa8]
    // 0xe078a0: r0 = Await()
    //     0xe078a0: bl              #0x7f5c00  ; AwaitStub
    // 0xe078a4: stur            x0, [fp, #-0xa0]
    // 0xe078a8: cmp             w0, NULL
    // 0xe078ac: b.ne            #0xe078b8
    // 0xe078b0: r0 = Null
    //     0xe078b0: mov             x0, NULL
    // 0xe078b4: r0 = ReturnAsyncNotFuture()
    //     0xe078b4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xe078b8: r1 = <PlatformFile>
    //     0xe078b8: add             x1, PP, #0x27, lsl #12  ; [pp+0x27d60] TypeArguments: <PlatformFile>
    //     0xe078bc: ldr             x1, [x1, #0xd60]
    // 0xe078c0: r2 = 0
    //     0xe078c0: mov             x2, #0
    // 0xe078c4: r0 = _GrowableList()
    //     0xe078c4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xe078c8: mov             x3, x0
    // 0xe078cc: ldur            x2, [fp, #-0xa0]
    // 0xe078d0: stur            x3, [fp, #-0xa8]
    // 0xe078d4: r0 = LoadClassIdInstr(r2)
    //     0xe078d4: ldur            x0, [x2, #-1]
    //     0xe078d8: ubfx            x0, x0, #0xc, #0x14
    // 0xe078dc: mov             x1, x2
    // 0xe078e0: r0 = GDT[cid_x0 + 0x12641]()
    //     0xe078e0: mov             x17, #0x2641
    //     0xe078e4: movk            x17, #1, lsl #16
    //     0xe078e8: add             lr, x0, x17
    //     0xe078ec: ldr             lr, [x21, lr, lsl #3]
    //     0xe078f0: blr             lr
    // 0xe078f4: mov             x2, x0
    // 0xe078f8: stur            x2, [fp, #-0xa0]
    // 0xe078fc: ldur            x3, [fp, #-0xa8]
    // 0xe07900: CheckStackOverflow
    //     0xe07900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe07904: cmp             SP, x16
    //     0xe07908: b.ls            #0xe07b34
    // 0xe0790c: r0 = LoadClassIdInstr(r2)
    //     0xe0790c: ldur            x0, [x2, #-1]
    //     0xe07910: ubfx            x0, x0, #0xc, #0x14
    // 0xe07914: mov             x1, x2
    // 0xe07918: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xe07918: mov             x17, #0x845b
    //     0xe0791c: movk            x17, #1, lsl #16
    //     0xe07920: add             lr, x0, x17
    //     0xe07924: ldr             lr, [x21, lr, lsl #3]
    //     0xe07928: blr             lr
    // 0xe0792c: tbnz            w0, #4, #0xe079f8
    // 0xe07930: ldur            x3, [fp, #-0xa8]
    // 0xe07934: ldur            x2, [fp, #-0xa0]
    // 0xe07938: r0 = LoadClassIdInstr(r2)
    //     0xe07938: ldur            x0, [x2, #-1]
    //     0xe0793c: ubfx            x0, x0, #0xc, #0x14
    // 0xe07940: mov             x1, x2
    // 0xe07944: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xe07944: mov             x17, #0x7d4c
    //     0xe07948: movk            x17, #1, lsl #16
    //     0xe0794c: add             lr, x0, x17
    //     0xe07950: ldr             lr, [x21, lr, lsl #3]
    //     0xe07954: blr             lr
    // 0xe07958: mov             x2, x0
    // 0xe0795c: r1 = Null
    //     0xe0795c: mov             x1, NULL
    // 0xe07960: stur            x0, [fp, #-0xb0]
    // 0xe07964: r0 = PlatformFile.fromMap()
    //     0xe07964: bl              #0xe07b48  ; [package:file_picker/src/api/platform_file.dart] PlatformFile::PlatformFile.fromMap
    // 0xe07968: mov             x2, x0
    // 0xe0796c: ldur            x0, [fp, #-0xa8]
    // 0xe07970: stur            x2, [fp, #-0xd0]
    // 0xe07974: LoadField: r3 = r0->field_b
    //     0xe07974: ldur            w3, [x0, #0xb]
    // 0xe07978: stur            x3, [fp, #-0xc0]
    // 0xe0797c: LoadField: r1 = r0->field_f
    //     0xe0797c: ldur            w1, [x0, #0xf]
    // 0xe07980: DecompressPointer r1
    //     0xe07980: add             x1, x1, HEAP, lsl #32
    // 0xe07984: LoadField: r4 = r1->field_b
    //     0xe07984: ldur            w4, [x1, #0xb]
    // 0xe07988: r5 = LoadInt32Instr(r3)
    //     0xe07988: sbfx            x5, x3, #1, #0x1f
    // 0xe0798c: stur            x5, [fp, #-0xc8]
    // 0xe07990: r1 = LoadInt32Instr(r4)
    //     0xe07990: sbfx            x1, x4, #1, #0x1f
    // 0xe07994: cmp             x5, x1
    // 0xe07998: b.ne            #0xe079a4
    // 0xe0799c: mov             x1, x0
    // 0xe079a0: r0 = _growToNextCapacity()
    //     0xe079a0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xe079a4: ldur            x2, [fp, #-0xa8]
    // 0xe079a8: ldur            x3, [fp, #-0xc8]
    // 0xe079ac: add             x0, x3, #1
    // 0xe079b0: lsl             x1, x0, #1
    // 0xe079b4: StoreField: r2->field_b = r1
    //     0xe079b4: stur            w1, [x2, #0xb]
    // 0xe079b8: LoadField: r1 = r2->field_f
    //     0xe079b8: ldur            w1, [x2, #0xf]
    // 0xe079bc: DecompressPointer r1
    //     0xe079bc: add             x1, x1, HEAP, lsl #32
    // 0xe079c0: ldur            x0, [fp, #-0xd0]
    // 0xe079c4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xe079c4: add             x25, x1, x3, lsl #2
    //     0xe079c8: add             x25, x25, #0xf
    //     0xe079cc: str             w0, [x25]
    //     0xe079d0: tbz             w0, #0, #0xe079ec
    //     0xe079d4: ldurb           w16, [x1, #-1]
    //     0xe079d8: ldurb           w17, [x0, #-1]
    //     0xe079dc: and             x16, x17, x16, lsr #2
    //     0xe079e0: tst             x16, HEAP, lsr #32
    //     0xe079e4: b.eq            #0xe079ec
    //     0xe079e8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xe079ec: mov             x3, x2
    // 0xe079f0: ldur            x2, [fp, #-0xa0]
    // 0xe079f4: b               #0xe07900
    // 0xe079f8: ldur            x2, [fp, #-0xa8]
    // 0xe079fc: r0 = FilePickerResult()
    //     0xe079fc: bl              #0xe07b3c  ; AllocateFilePickerResultStub -> FilePickerResult (size=0xc)
    // 0xe07a00: mov             x1, x0
    // 0xe07a04: ldur            x0, [fp, #-0xa8]
    // 0xe07a08: StoreField: r1->field_7 = r0
    //     0xe07a08: stur            w0, [x1, #7]
    // 0xe07a0c: mov             x0, x1
    // 0xe07a10: r0 = ReturnAsyncNotFuture()
    //     0xe07a10: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xe07a14: mov             x0, x1
    // 0xe07a18: r0 = ArgumentError()
    //     0xe07a18: bl              #0x7dcb60  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xe07a1c: mov             x1, x0
    // 0xe07a20: r0 = "allowedExtensions"
    //     0xe07a20: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d20] "allowedExtensions"
    //     0xe07a24: ldr             x0, [x0, #0xd20]
    // 0xe07a28: StoreField: r1->field_13 = r0
    //     0xe07a28: stur            w0, [x1, #0x13]
    // 0xe07a2c: r0 = "Custom extension filters are only allowed with FileType.custom. Remove the extension filter or change the FileType to FileType.custom."
    //     0xe07a2c: add             x0, PP, #0x27, lsl #12  ; [pp+0x27d68] "Custom extension filters are only allowed with FileType.custom. Remove the extension filter or change the FileType to FileType.custom."
    //     0xe07a30: ldr             x0, [x0, #0xd68]
    // 0xe07a34: ArrayStore: r1[0] = r0  ; List_4
    //     0xe07a34: stur            w0, [x1, #0x17]
    // 0xe07a38: ldur            x0, [fp, #-0xb8]
    // 0xe07a3c: StoreField: r1->field_f = r0
    //     0xe07a3c: stur            w0, [x1, #0xf]
    // 0xe07a40: r0 = true
    //     0xe07a40: add             x0, NULL, #0x20  ; true
    // 0xe07a44: StoreField: r1->field_b = r0
    //     0xe07a44: stur            w0, [x1, #0xb]
    // 0xe07a48: mov             x0, x1
    // 0xe07a4c: r0 = Throw()
    //     0xe07a4c: bl              #0x13ddb2c  ; ThrowStub
    // 0xe07a50: brk             #0
    // 0xe07a54: sub             SP, fp, #0xf0
    // 0xe07a58: mov             x3, x0
    // 0xe07a5c: stur            x0, [fp, #-0xa0]
    // 0xe07a60: mov             x0, x1
    // 0xe07a64: stur            x1, [fp, #-0xa8]
    // 0xe07a68: r1 = 60
    //     0xe07a68: mov             x1, #0x3c
    // 0xe07a6c: branchIfSmi(r3, 0xe07a78)
    //     0xe07a6c: tbz             w3, #0, #0xe07a78
    // 0xe07a70: r1 = LoadClassIdInstr(r3)
    //     0xe07a70: ldur            x1, [x3, #-1]
    //     0xe07a74: ubfx            x1, x1, #0xc, #0x14
    // 0xe07a78: cmp             x1, #0xae4
    // 0xe07a7c: b.ne            #0xe07ad4
    // 0xe07a80: r1 = Null
    //     0xe07a80: mov             x1, NULL
    // 0xe07a84: r2 = 8
    //     0xe07a84: mov             x2, #8
    // 0xe07a88: r0 = AllocateArray()
    //     0xe07a88: bl              #0x13df928  ; AllocateArrayStub
    // 0xe07a8c: r16 = "["
    //     0xe07a8c: ldr             x16, [PP, #0x1290]  ; [pp+0x1290] "["
    // 0xe07a90: StoreField: r0->field_f = r16
    //     0xe07a90: stur            w16, [x0, #0xf]
    // 0xe07a94: r16 = "MethodChannelFilePicker"
    //     0xe07a94: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d70] "MethodChannelFilePicker"
    //     0xe07a98: ldr             x16, [x16, #0xd70]
    // 0xe07a9c: StoreField: r0->field_13 = r16
    //     0xe07a9c: stur            w16, [x0, #0x13]
    // 0xe07aa0: r16 = "] Platform exception: "
    //     0xe07aa0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d78] "] Platform exception: "
    //     0xe07aa4: ldr             x16, [x16, #0xd78]
    // 0xe07aa8: ArrayStore: r0[0] = r16  ; List_4
    //     0xe07aa8: stur            w16, [x0, #0x17]
    // 0xe07aac: ldur            x1, [fp, #-0xa0]
    // 0xe07ab0: StoreField: r0->field_1b = r1
    //     0xe07ab0: stur            w1, [x0, #0x1b]
    // 0xe07ab4: str             x0, [SP]
    // 0xe07ab8: r0 = _interpolate()
    //     0xe07ab8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xe07abc: mov             x1, x0
    // 0xe07ac0: r0 = print()
    //     0xe07ac0: bl              #0x82a3d4  ; [dart:core] ::print
    // 0xe07ac4: ldur            x0, [fp, #-0xa0]
    // 0xe07ac8: ldur            x1, [fp, #-0xa8]
    // 0xe07acc: r0 = ReThrow()
    //     0xe07acc: bl              #0x13ddb00  ; ReThrowStub
    // 0xe07ad0: brk             #0
    // 0xe07ad4: mov             x0, x3
    // 0xe07ad8: r1 = Null
    //     0xe07ad8: mov             x1, NULL
    // 0xe07adc: r2 = 8
    //     0xe07adc: mov             x2, #8
    // 0xe07ae0: r0 = AllocateArray()
    //     0xe07ae0: bl              #0x13df928  ; AllocateArrayStub
    // 0xe07ae4: r16 = "["
    //     0xe07ae4: ldr             x16, [PP, #0x1290]  ; [pp+0x1290] "["
    // 0xe07ae8: StoreField: r0->field_f = r16
    //     0xe07ae8: stur            w16, [x0, #0xf]
    // 0xe07aec: r16 = "MethodChannelFilePicker"
    //     0xe07aec: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d70] "MethodChannelFilePicker"
    //     0xe07af0: ldr             x16, [x16, #0xd70]
    // 0xe07af4: StoreField: r0->field_13 = r16
    //     0xe07af4: stur            w16, [x0, #0x13]
    // 0xe07af8: r16 = "] Unsupported operation. Method not found. The exception thrown was: "
    //     0xe07af8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d80] "] Unsupported operation. Method not found. The exception thrown was: "
    //     0xe07afc: ldr             x16, [x16, #0xd80]
    // 0xe07b00: ArrayStore: r0[0] = r16  ; List_4
    //     0xe07b00: stur            w16, [x0, #0x17]
    // 0xe07b04: ldur            x1, [fp, #-0xa0]
    // 0xe07b08: StoreField: r0->field_1b = r1
    //     0xe07b08: stur            w1, [x0, #0x1b]
    // 0xe07b0c: str             x0, [SP]
    // 0xe07b10: r0 = _interpolate()
    //     0xe07b10: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xe07b14: mov             x1, x0
    // 0xe07b18: r0 = print()
    //     0xe07b18: bl              #0x82a3d4  ; [dart:core] ::print
    // 0xe07b1c: ldur            x0, [fp, #-0xa0]
    // 0xe07b20: ldur            x1, [fp, #-0xa8]
    // 0xe07b24: r0 = ReThrow()
    //     0xe07b24: bl              #0x13ddb00  ; ReThrowStub
    // 0xe07b28: brk             #0
    // 0xe07b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe07b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe07b30: b               #0xe07784
    // 0xe07b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe07b34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe07b38: b               #0xe0790c
  }
  _ MethodChannelFilePicker(/* No info */) {
    // ** addr: 0xe07dc8, size: 0xcc
    // 0xe07dc8: EnterFrame
    //     0xe07dc8: stp             fp, lr, [SP, #-0x10]!
    //     0xe07dcc: mov             fp, SP
    // 0xe07dd0: AllocStack(0x10)
    //     0xe07dd0: sub             SP, SP, #0x10
    // 0xe07dd4: SetupParameters(MethodChannelFilePicker this /* r1 => r2, fp-0x8 */)
    //     0xe07dd4: mov             x2, x1
    //     0xe07dd8: stur            x1, [fp, #-8]
    // 0xe07ddc: CheckStackOverflow
    //     0xe07ddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe07de0: cmp             SP, x16
    //     0xe07de4: b.ls            #0xe07e8c
    // 0xe07de8: r0 = MethodChannel()
    //     0xe07de8: bl              #0x8c37f8  ; AllocateMethodChannelStub -> MethodChannel (size=0x14)
    // 0xe07dec: mov             x1, x0
    // 0xe07df0: r0 = "miguelruivo.flutter.plugins.filepicker"
    //     0xe07df0: add             x0, PP, #0x27, lsl #12  ; [pp+0x27de0] "miguelruivo.flutter.plugins.filepicker"
    //     0xe07df4: ldr             x0, [x0, #0xde0]
    // 0xe07df8: StoreField: r1->field_7 = r0
    //     0xe07df8: stur            w0, [x1, #7]
    // 0xe07dfc: r0 = Instance_StandardMethodCodec
    //     0xe07dfc: add             x0, PP, #0x27, lsl #12  ; [pp+0x27de8] Obj!StandardMethodCodec@129c021
    //     0xe07e00: ldr             x0, [x0, #0xde8]
    // 0xe07e04: StoreField: r1->field_b = r0
    //     0xe07e04: stur            w0, [x1, #0xb]
    // 0xe07e08: mov             x0, x1
    // 0xe07e0c: ldur            x2, [fp, #-8]
    // 0xe07e10: StoreField: r2->field_7 = r0
    //     0xe07e10: stur            w0, [x2, #7]
    //     0xe07e14: ldurb           w16, [x2, #-1]
    //     0xe07e18: ldurb           w17, [x0, #-1]
    //     0xe07e1c: and             x16, x17, x16, lsr #2
    //     0xe07e20: tst             x16, HEAP, lsr #32
    //     0xe07e24: b.eq            #0xe07e2c
    //     0xe07e28: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xe07e2c: r0 = LoadStaticField(0xf14)
    //     0xe07e2c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe07e30: ldr             x0, [x0, #0x1e28]
    // 0xe07e34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe07e38: cmp             w0, w16
    // 0xe07e3c: b.ne            #0xe07e4c
    // 0xe07e40: r2 = _token
    //     0xe07e40: add             x2, PP, #0x27, lsl #12  ; [pp+0x27df0] Field <FilePickerPlatform._token@1170424656>: static late final (offset: 0xf14)
    //     0xe07e44: ldr             x2, [x2, #0xdf0]
    // 0xe07e48: r0 = InitLateFinalStaticField()
    //     0xe07e48: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xe07e4c: stur            x0, [fp, #-0x10]
    // 0xe07e50: r0 = LoadStaticField(0xde8)
    //     0xe07e50: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xe07e54: ldr             x0, [x0, #0x1bd0]
    // 0xe07e58: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xe07e5c: cmp             w0, w16
    // 0xe07e60: b.ne            #0xe07e6c
    // 0xe07e64: r2 = _instanceTokens
    //     0xe07e64: ldr             x2, [PP, #0x68c0]  ; [pp+0x68c0] Field <PlatformInterface._instanceTokens@1171304592>: static late final (offset: 0xde8)
    // 0xe07e68: r0 = InitLateFinalStaticField()
    //     0xe07e68: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xe07e6c: mov             x1, x0
    // 0xe07e70: ldur            x2, [fp, #-8]
    // 0xe07e74: ldur            x3, [fp, #-0x10]
    // 0xe07e78: r0 = []=()
    //     0xe07e78: bl              #0x7f6290  ; [dart:core] Expando::[]=
    // 0xe07e7c: r0 = Null
    //     0xe07e7c: mov             x0, NULL
    // 0xe07e80: LeaveFrame
    //     0xe07e80: mov             SP, fp
    //     0xe07e84: ldp             fp, lr, [SP], #0x10
    // 0xe07e88: ret
    //     0xe07e88: ret             
    // 0xe07e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe07e8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe07e90: b               #0xe07de8
  }
  _ saveFile(/* No info */) {
    // ** addr: 0xe9c044, size: 0xdc
    // 0xe9c044: EnterFrame
    //     0xe9c044: stp             fp, lr, [SP, #-0x10]!
    //     0xe9c048: mov             fp, SP
    // 0xe9c04c: AllocStack(0x38)
    //     0xe9c04c: sub             SP, SP, #0x38
    // 0xe9c050: SetupParameters(dynamic _ /* r3 => r3, fp-0x10 */, dynamic _ /* r5 => r5, fp-0x18 */)
    //     0xe9c050: stur            x3, [fp, #-0x10]
    //     0xe9c054: stur            x5, [fp, #-0x18]
    // 0xe9c058: CheckStackOverflow
    //     0xe9c058: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe9c05c: cmp             SP, x16
    //     0xe9c060: b.ls            #0xe9c118
    // 0xe9c064: LoadField: r0 = r1->field_7
    //     0xe9c064: ldur            w0, [x1, #7]
    // 0xe9c068: DecompressPointer r0
    //     0xe9c068: add             x0, x0, HEAP, lsl #32
    // 0xe9c06c: stur            x0, [fp, #-8]
    // 0xe9c070: r1 = Null
    //     0xe9c070: mov             x1, NULL
    // 0xe9c074: r2 = 20
    //     0xe9c074: mov             x2, #0x14
    // 0xe9c078: r0 = AllocateArray()
    //     0xe9c078: bl              #0x13df928  ; AllocateArrayStub
    // 0xe9c07c: r16 = "fileName"
    //     0xe9c07c: add             x16, PP, #0x9d, lsl #12  ; [pp+0x9d420] "fileName"
    //     0xe9c080: ldr             x16, [x16, #0x420]
    // 0xe9c084: StoreField: r0->field_f = r16
    //     0xe9c084: stur            w16, [x0, #0xf]
    // 0xe9c088: ldur            x1, [fp, #-0x18]
    // 0xe9c08c: StoreField: r0->field_13 = r1
    //     0xe9c08c: stur            w1, [x0, #0x13]
    // 0xe9c090: r16 = "fileType"
    //     0xe9c090: add             x16, PP, #0x9d, lsl #12  ; [pp+0x9d428] "fileType"
    //     0xe9c094: ldr             x16, [x16, #0x428]
    // 0xe9c098: ArrayStore: r0[0] = r16  ; List_4
    //     0xe9c098: stur            w16, [x0, #0x17]
    // 0xe9c09c: r16 = "any"
    //     0xe9c09c: add             x16, PP, #0x88, lsl #12  ; [pp+0x88958] "any"
    //     0xe9c0a0: ldr             x16, [x16, #0x958]
    // 0xe9c0a4: StoreField: r0->field_1b = r16
    //     0xe9c0a4: stur            w16, [x0, #0x1b]
    // 0xe9c0a8: r16 = "initialDirectory"
    //     0xe9c0a8: add             x16, PP, #0x9d, lsl #12  ; [pp+0x9d430] "initialDirectory"
    //     0xe9c0ac: ldr             x16, [x16, #0x430]
    // 0xe9c0b0: StoreField: r0->field_1f = r16
    //     0xe9c0b0: stur            w16, [x0, #0x1f]
    // 0xe9c0b4: StoreField: r0->field_23 = rNULL
    //     0xe9c0b4: stur            NULL, [x0, #0x23]
    // 0xe9c0b8: r16 = "allowedExtensions"
    //     0xe9c0b8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d20] "allowedExtensions"
    //     0xe9c0bc: ldr             x16, [x16, #0xd20]
    // 0xe9c0c0: StoreField: r0->field_27 = r16
    //     0xe9c0c0: stur            w16, [x0, #0x27]
    // 0xe9c0c4: StoreField: r0->field_2b = rNULL
    //     0xe9c0c4: stur            NULL, [x0, #0x2b]
    // 0xe9c0c8: r16 = "bytes"
    //     0xe9c0c8: add             x16, PP, #0x27, lsl #12  ; [pp+0x27da8] "bytes"
    //     0xe9c0cc: ldr             x16, [x16, #0xda8]
    // 0xe9c0d0: StoreField: r0->field_2f = r16
    //     0xe9c0d0: stur            w16, [x0, #0x2f]
    // 0xe9c0d4: ldur            x1, [fp, #-0x10]
    // 0xe9c0d8: StoreField: r0->field_33 = r1
    //     0xe9c0d8: stur            w1, [x0, #0x33]
    // 0xe9c0dc: r16 = <String, Object?>
    //     0xe9c0dc: add             x16, PP, #8, lsl #12  ; [pp+0x8128] TypeArguments: <String, Object?>
    //     0xe9c0e0: ldr             x16, [x16, #0x128]
    // 0xe9c0e4: stp             x0, x16, [SP]
    // 0xe9c0e8: r0 = Map._fromLiteral()
    //     0xe9c0e8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xe9c0ec: r16 = <String>
    //     0xe9c0ec: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0xe9c0f0: ldur            lr, [fp, #-8]
    // 0xe9c0f4: stp             lr, x16, [SP, #0x10]
    // 0xe9c0f8: r16 = "save"
    //     0xe9c0f8: add             x16, PP, #0x24, lsl #12  ; [pp+0x24520] "save"
    //     0xe9c0fc: ldr             x16, [x16, #0x520]
    // 0xe9c100: stp             x0, x16, [SP]
    // 0xe9c104: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xe9c104: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xe9c108: r0 = invokeMethod()
    //     0xe9c108: bl              #0x130b008  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xe9c10c: LeaveFrame
    //     0xe9c10c: mov             SP, fp
    //     0xe9c110: ldp             fp, lr, [SP], #0x10
    // 0xe9c114: ret
    //     0xe9c114: ret             
    // 0xe9c118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe9c118: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe9c11c: b               #0xe9c064
  }
}
