// lib: , url: package:file_picker/src/platform/file_picker_platform_interface.dart

// class id: 1048743, size: 0x8
class :: {
}

// class id: 3705, size: 0x8, field offset: 0x8
abstract class FilePickerPlatform extends PlatformInterface {

  static late FilePickerPlatform _instance; // offset: 0xf18
  static late final Object _token; // offset: 0xf14

  static FilePickerPlatform _instance() {
    // ** addr: 0xe07d88, size: 0x40
    // 0xe07d88: EnterFrame
    //     0xe07d88: stp             fp, lr, [SP, #-0x10]!
    //     0xe07d8c: mov             fp, SP
    // 0xe07d90: AllocStack(0x8)
    //     0xe07d90: sub             SP, SP, #8
    // 0xe07d94: CheckStackOverflow
    //     0xe07d94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe07d98: cmp             SP, x16
    //     0xe07d9c: b.ls            #0xe07dc0
    // 0xe07da0: r0 = MethodChannelFilePicker()
    //     0xe07da0: bl              #0xe07e94  ; AllocateMethodChannelFilePickerStub -> MethodChannelFilePicker (size=0xc)
    // 0xe07da4: mov             x1, x0
    // 0xe07da8: stur            x0, [fp, #-8]
    // 0xe07dac: r0 = MethodChannelFilePicker()
    //     0xe07dac: bl              #0xe07dc8  ; [package:file_picker/src/platform/file_picker_method_channel.dart] MethodChannelFilePicker::MethodChannelFilePicker
    // 0xe07db0: ldur            x0, [fp, #-8]
    // 0xe07db4: LeaveFrame
    //     0xe07db4: mov             SP, fp
    //     0xe07db8: ldp             fp, lr, [SP], #0x10
    // 0xe07dbc: ret
    //     0xe07dbc: ret             
    // 0xe07dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe07dc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe07dc4: b               #0xe07da0
  }
}
