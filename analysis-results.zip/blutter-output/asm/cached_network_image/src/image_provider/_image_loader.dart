// lib: , url: package:cached_network_image/src/image_provider/_image_loader.dart

// class id: 1048617, size: 0x8
class :: {
}

// class id: 3606, size: 0x8, field offset: 0x8
class ImageLoader extends Object
    implements ImageLoader {

  _ loadImageAsync(/* No info */) {
    // ** addr: 0x1186b48, size: 0x84
    // 0x1186b48: EnterFrame
    //     0x1186b48: stp             fp, lr, [SP, #-0x10]!
    //     0x1186b4c: mov             fp, SP
    // 0x1186b50: AllocStack(0x30)
    //     0x1186b50: sub             SP, SP, #0x30
    // 0x1186b54: SetupParameters(ImageLoader this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r6, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x1186b54: stur            x1, [fp, #-8]
    //     0x1186b58: stur            x2, [fp, #-0x10]
    //     0x1186b5c: stur            x3, [fp, #-0x18]
    //     0x1186b60: stur            x5, [fp, #-0x20]
    //     0x1186b64: stur            x6, [fp, #-0x28]
    //     0x1186b68: stur            x7, [fp, #-0x30]
    // 0x1186b6c: CheckStackOverflow
    //     0x1186b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1186b70: cmp             SP, x16
    //     0x1186b74: b.ls            #0x1186bc4
    // 0x1186b78: r1 = 1
    //     0x1186b78: mov             x1, #1
    // 0x1186b7c: r0 = AllocateContext()
    //     0x1186b7c: bl              #0x13de838  ; AllocateContextStub
    // 0x1186b80: mov             x1, x0
    // 0x1186b84: ldur            x0, [fp, #-0x20]
    // 0x1186b88: StoreField: r1->field_f = r0
    //     0x1186b88: stur            w0, [x1, #0xf]
    // 0x1186b8c: mov             x2, x1
    // 0x1186b90: r1 = Function '<anonymous closure>':.
    //     0x1186b90: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e80] AnonymousClosure: (0x118b4fc), in [package:cached_network_image/src/image_provider/_image_loader.dart] ImageLoader::loadImageAsync (0x1186b48)
    //     0x1186b94: ldr             x1, [x1, #0xe80]
    // 0x1186b98: r0 = AllocateClosure()
    //     0x1186b98: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1186b9c: ldur            x1, [fp, #-8]
    // 0x1186ba0: ldur            x2, [fp, #-0x10]
    // 0x1186ba4: ldur            x3, [fp, #-0x18]
    // 0x1186ba8: mov             x5, x0
    // 0x1186bac: ldur            x6, [fp, #-0x28]
    // 0x1186bb0: ldur            x7, [fp, #-0x30]
    // 0x1186bb4: r0 = _load()
    //     0x1186bb4: bl              #0x1186bcc  ; [package:cached_network_image/src/image_provider/_image_loader.dart] ImageLoader::_load
    // 0x1186bb8: LeaveFrame
    //     0x1186bb8: mov             SP, fp
    //     0x1186bbc: ldp             fp, lr, [SP], #0x10
    // 0x1186bc0: ret
    //     0x1186bc0: ret             
    // 0x1186bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1186bc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1186bc8: b               #0x1186b78
  }
  _ _load(/* No info */) {
    // ** addr: 0x1186bcc, size: 0x570
    // 0x1186bcc: EnterFrame
    //     0x1186bcc: stp             fp, lr, [SP, #-0x10]!
    //     0x1186bd0: mov             fp, SP
    // 0x1186bd4: AllocStack(0x130)
    //     0x1186bd4: sub             SP, SP, #0x130
    // 0x1186bd8: SetupParameters(ImageLoader this /* r1 => r4, fp-0xe8 */, dynamic _ /* r2 => r3, fp-0xf0 */, dynamic _ /* r3 => r2, fp-0xf8 */)
    //     0x1186bd8: stur            NULL, [fp, #-8]
    //     0x1186bdc: mov             x4, x1
    //     0x1186be0: stur            x2, [fp, #-0xd8]
    //     0x1186be4: mov             x16, x3
    //     0x1186be8: mov             x3, x2
    //     0x1186bec: mov             x2, x16
    //     0x1186bf0: mov             x0, x5
    //     0x1186bf4: stur            x1, [fp, #-0xd0]
    //     0x1186bf8: mov             x1, x6
    //     0x1186bfc: stur            x2, [fp, #-0xe0]
    //     0x1186c00: stur            x5, [fp, #-0xe8]
    //     0x1186c04: stur            x6, [fp, #-0xf0]
    //     0x1186c08: stur            x7, [fp, #-0xf8]
    // 0x1186c0c: CheckStackOverflow
    //     0x1186c0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1186c10: cmp             SP, x16
    //     0x1186c14: b.ls            #0x118712c
    // 0x1186c18: r1 = 1
    //     0x1186c18: mov             x1, #1
    // 0x1186c1c: r0 = AllocateContext()
    //     0x1186c1c: bl              #0x13de838  ; AllocateContextStub
    // 0x1186c20: mov             x1, x0
    // 0x1186c24: ldur            x0, [fp, #-0xf8]
    // 0x1186c28: stur            x1, [fp, #-0x100]
    // 0x1186c2c: StoreField: r1->field_f = r0
    //     0x1186c2c: stur            w0, [x1, #0xf]
    // 0x1186c30: r0 = <Codec>
    //     0x1186c30: add             x0, PP, #0x8d, lsl #12  ; [pp+0x8d278] TypeArguments: <Codec>
    //     0x1186c34: ldr             x0, [x0, #0x278]
    // 0x1186c38: r0 = InitAsyncStar()
    //     0x1186c38: bl              #0x118b480  ; InitAsyncStarStub
    // 0x1186c3c: r0 = Null
    //     0x1186c3c: mov             x0, NULL
    // 0x1186c40: r0 = YieldAsyncStar()
    //     0x1186c40: bl              #0x118b2f4  ; YieldAsyncStarStub
    // 0x1186c44: r16 = true
    //     0x1186c44: add             x16, NULL, #0x20  ; true
    // 0x1186c48: str             x16, [SP]
    // 0x1186c4c: ldur            x1, [fp, #-0xf0]
    // 0x1186c50: ldur            x2, [fp, #-0xd8]
    // 0x1186c54: r3 = Null
    //     0x1186c54: mov             x3, NULL
    // 0x1186c58: r5 = Null
    //     0x1186c58: mov             x5, NULL
    // 0x1186c5c: r6 = Null
    //     0x1186c5c: mov             x6, NULL
    // 0x1186c60: r7 = Null
    //     0x1186c60: mov             x7, NULL
    // 0x1186c64: r0 = getImageFile()
    //     0x1186c64: bl              #0x1187650  ; [dart:mixin_deduplication] _MixinApplication740&CacheManager&ImageCacheManager::getImageFile
    // 0x1186c68: r1 = <FileResponse>
    //     0x1186c68: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e88] TypeArguments: <FileResponse>
    //     0x1186c6c: ldr             x1, [x1, #0xe88]
    // 0x1186c70: stur            x0, [fp, #-0xd0]
    // 0x1186c74: r0 = _StreamIterator()
    //     0x1186c74: bl              #0x8f45f0  ; Allocate_StreamIteratorStub -> _StreamIterator<X0> (size=0x18)
    // 0x1186c78: mov             x2, x0
    // 0x1186c7c: r0 = false
    //     0x1186c7c: add             x0, NULL, #0x30  ; false
    // 0x1186c80: stur            x2, [fp, #-0xd8]
    // 0x1186c84: StoreField: r2->field_13 = r0
    //     0x1186c84: stur            w0, [x2, #0x13]
    // 0x1186c88: ldur            x1, [fp, #-0xd0]
    // 0x1186c8c: StoreField: r2->field_f = r1
    //     0x1186c8c: stur            w1, [x2, #0xf]
    // 0x1186c90: ldur            x3, [fp, #-0xe0]
    // 0x1186c94: CheckStackOverflow
    //     0x1186c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1186c98: cmp             SP, x16
    //     0x1186c9c: b.ls            #0x1187134
    // 0x1186ca0: LoadField: r4 = r2->field_b
    //     0x1186ca0: ldur            w4, [x2, #0xb]
    // 0x1186ca4: DecompressPointer r4
    //     0x1186ca4: add             x4, x4, HEAP, lsl #32
    // 0x1186ca8: stur            x4, [fp, #-0xd0]
    // 0x1186cac: cmp             w4, NULL
    // 0x1186cb0: b.eq            #0x1186d40
    // 0x1186cb4: LoadField: r1 = r2->field_13
    //     0x1186cb4: ldur            w1, [x2, #0x13]
    // 0x1186cb8: DecompressPointer r1
    //     0x1186cb8: add             x1, x1, HEAP, lsl #32
    // 0x1186cbc: tbnz            w1, #4, #0x1187068
    // 0x1186cc0: r1 = <bool>
    //     0x1186cc0: ldr             x1, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x1186cc4: r0 = _Future()
    //     0x1186cc4: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x1186cc8: stur            x0, [fp, #-0xf0]
    // 0x1186ccc: StoreField: r0->field_b = rZR
    //     0x1186ccc: stur            xzr, [x0, #0xb]
    // 0x1186cd0: r0 = LoadStaticField(0x364)
    //     0x1186cd0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1186cd4: ldr             x0, [x0, #0x6c8]
    // 0x1186cd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1186cdc: cmp             w0, w16
    // 0x1186ce0: b.ne            #0x1186cec
    // 0x1186ce4: r2 = _current
    //     0x1186ce4: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0x1186ce8: r0 = InitLateStaticField()
    //     0x1186ce8: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x1186cec: ldur            x2, [fp, #-0xf0]
    // 0x1186cf0: StoreField: r2->field_13 = r0
    //     0x1186cf0: stur            w0, [x2, #0x13]
    // 0x1186cf4: mov             x0, x2
    // 0x1186cf8: ldur            x3, [fp, #-0xd8]
    // 0x1186cfc: StoreField: r3->field_f = r0
    //     0x1186cfc: stur            w0, [x3, #0xf]
    //     0x1186d00: ldurb           w16, [x3, #-1]
    //     0x1186d04: ldurb           w17, [x0, #-1]
    //     0x1186d08: and             x16, x17, x16, lsr #2
    //     0x1186d0c: tst             x16, HEAP, lsr #32
    //     0x1186d10: b.eq            #0x1186d18
    //     0x1186d14: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1186d18: r4 = false
    //     0x1186d18: add             x4, NULL, #0x30  ; false
    // 0x1186d1c: StoreField: r3->field_13 = r4
    //     0x1186d1c: stur            w4, [x3, #0x13]
    // 0x1186d20: ldur            x1, [fp, #-0xd0]
    // 0x1186d24: r0 = LoadClassIdInstr(r1)
    //     0x1186d24: ldur            x0, [x1, #-1]
    //     0x1186d28: ubfx            x0, x0, #0xc, #0x14
    // 0x1186d2c: r0 = GDT[cid_x0 + 0x5d3]()
    //     0x1186d2c: add             lr, x0, #0x5d3
    //     0x1186d30: ldr             lr, [x21, lr, lsl #3]
    //     0x1186d34: blr             lr
    // 0x1186d38: ldur            x1, [fp, #-0xf0]
    // 0x1186d3c: b               #0x1186d4c
    // 0x1186d40: ldur            x1, [fp, #-0xd8]
    // 0x1186d44: r0 = _initializeOrDone()
    //     0x1186d44: bl              #0x8f40c4  ; [dart:async] _StreamIterator::_initializeOrDone
    // 0x1186d48: mov             x1, x0
    // 0x1186d4c: mov             x0, x1
    // 0x1186d50: stur            x1, [fp, #-0xd0]
    // 0x1186d54: r0 = Await()
    //     0x1186d54: bl              #0x7f5c00  ; AwaitStub
    // 0x1186d58: r16 = true
    //     0x1186d58: add             x16, NULL, #0x20  ; true
    // 0x1186d5c: cmp             w0, w16
    // 0x1186d60: b.ne            #0x1186f7c
    // 0x1186d64: ldur            x3, [fp, #-0xd8]
    // 0x1186d68: LoadField: r0 = r3->field_13
    //     0x1186d68: ldur            w0, [x3, #0x13]
    // 0x1186d6c: DecompressPointer r0
    //     0x1186d6c: add             x0, x0, HEAP, lsl #32
    // 0x1186d70: tbnz            w0, #4, #0x1186dc4
    // 0x1186d74: LoadField: r4 = r3->field_f
    //     0x1186d74: ldur            w4, [x3, #0xf]
    // 0x1186d78: DecompressPointer r4
    //     0x1186d78: add             x4, x4, HEAP, lsl #32
    // 0x1186d7c: mov             x0, x4
    // 0x1186d80: stur            x4, [fp, #-0xd0]
    // 0x1186d84: r2 = Null
    //     0x1186d84: mov             x2, NULL
    // 0x1186d88: r1 = Null
    //     0x1186d88: mov             x1, NULL
    // 0x1186d8c: r4 = 60
    //     0x1186d8c: mov             x4, #0x3c
    // 0x1186d90: branchIfSmi(r0, 0x1186d9c)
    //     0x1186d90: tbz             w0, #0, #0x1186d9c
    // 0x1186d94: r4 = LoadClassIdInstr(r0)
    //     0x1186d94: ldur            x4, [x0, #-1]
    //     0x1186d98: ubfx            x4, x4, #0xc, #0x14
    // 0x1186d9c: sub             x4, x4, #0x9ed
    // 0x1186da0: cmp             x4, #1
    // 0x1186da4: b.ls            #0x1186dbc
    // 0x1186da8: r8 = FileResponse
    //     0x1186da8: add             x8, PP, #0x94, lsl #12  ; [pp+0x94e90] Type: FileResponse
    //     0x1186dac: ldr             x8, [x8, #0xe90]
    // 0x1186db0: r3 = Null
    //     0x1186db0: add             x3, PP, #0x94, lsl #12  ; [pp+0x94e98] Null
    //     0x1186db4: ldr             x3, [x3, #0xe98]
    // 0x1186db8: r0 = FileResponse()
    //     0x1186db8: bl              #0xe5a918  ; IsType_FileResponse_Stub
    // 0x1186dbc: ldur            x0, [fp, #-0xd0]
    // 0x1186dc0: b               #0x1186dfc
    // 0x1186dc4: r0 = Null
    //     0x1186dc4: mov             x0, NULL
    // 0x1186dc8: r2 = Null
    //     0x1186dc8: mov             x2, NULL
    // 0x1186dcc: r1 = Null
    //     0x1186dcc: mov             x1, NULL
    // 0x1186dd0: r4 = LoadClassIdInstr(r0)
    //     0x1186dd0: ldur            x4, [x0, #-1]
    //     0x1186dd4: ubfx            x4, x4, #0xc, #0x14
    // 0x1186dd8: sub             x4, x4, #0x9ed
    // 0x1186ddc: cmp             x4, #1
    // 0x1186de0: b.ls            #0x1186df8
    // 0x1186de4: r8 = FileResponse
    //     0x1186de4: add             x8, PP, #0x94, lsl #12  ; [pp+0x94e90] Type: FileResponse
    //     0x1186de8: ldr             x8, [x8, #0xe90]
    // 0x1186dec: r3 = Null
    //     0x1186dec: add             x3, PP, #0x94, lsl #12  ; [pp+0x94ea8] Null
    //     0x1186df0: ldr             x3, [x3, #0xea8]
    // 0x1186df4: r0 = FileResponse()
    //     0x1186df4: bl              #0xe5a918  ; IsType_FileResponse_Stub
    // 0x1186df8: r0 = Null
    //     0x1186df8: mov             x0, NULL
    // 0x1186dfc: stur            x0, [fp, #-0xf0]
    // 0x1186e00: r1 = LoadClassIdInstr(r0)
    //     0x1186e00: ldur            x1, [x0, #-1]
    //     0x1186e04: ubfx            x1, x1, #0xc, #0x14
    // 0x1186e08: r17 = -272
    //     0x1186e08: mov             x17, #-0x110
    // 0x1186e0c: str             x1, [fp, x17]
    // 0x1186e10: cmp             x1, #0x9ee
    // 0x1186e14: b.ne            #0x1186e6c
    // 0x1186e18: ldur            x2, [fp, #-0xe0]
    // 0x1186e1c: LoadField: r3 = r0->field_b
    //     0x1186e1c: ldur            x3, [x0, #0xb]
    // 0x1186e20: r17 = -264
    //     0x1186e20: mov             x17, #-0x108
    // 0x1186e24: str             x3, [fp, x17]
    // 0x1186e28: LoadField: r4 = r0->field_7
    //     0x1186e28: ldur            w4, [x0, #7]
    // 0x1186e2c: DecompressPointer r4
    //     0x1186e2c: add             x4, x4, HEAP, lsl #32
    // 0x1186e30: stur            x4, [fp, #-0xd0]
    // 0x1186e34: r0 = ImageChunkEvent()
    //     0x1186e34: bl              #0x1187644  ; AllocateImageChunkEventStub -> ImageChunkEvent (size=0x14)
    // 0x1186e38: mov             x1, x0
    // 0x1186e3c: r17 = -264
    //     0x1186e3c: mov             x17, #-0x108
    // 0x1186e40: ldr             x0, [fp, x17]
    // 0x1186e44: StoreField: r1->field_7 = r0
    //     0x1186e44: stur            x0, [x1, #7]
    // 0x1186e48: ldur            x3, [fp, #-0xd0]
    // 0x1186e4c: StoreField: r1->field_f = r3
    //     0x1186e4c: stur            w3, [x1, #0xf]
    // 0x1186e50: ldur            x4, [fp, #-0xe0]
    // 0x1186e54: LoadField: r2 = r4->field_f
    //     0x1186e54: ldur            x2, [x4, #0xf]
    // 0x1186e58: cmp             x2, #4
    // 0x1186e5c: b.ge            #0x1187090
    // 0x1186e60: mov             x2, x1
    // 0x1186e64: mov             x1, x4
    // 0x1186e68: r0 = _add()
    //     0x1186e68: bl              #0x1208754  ; [dart:async] _StreamController::_add
    // 0x1186e6c: r17 = -272
    //     0x1186e6c: mov             x17, #-0x110
    // 0x1186e70: ldr             x0, [fp, x17]
    // 0x1186e74: cmp             x0, #0x9ed
    // 0x1186e78: b.ne            #0x1186f70
    // 0x1186e7c: ldur            x2, [fp, #-0xf0]
    // 0x1186e80: LoadField: r3 = r2->field_7
    //     0x1186e80: ldur            w3, [x2, #7]
    // 0x1186e84: DecompressPointer r3
    //     0x1186e84: add             x3, x3, HEAP, lsl #32
    // 0x1186e88: stur            x3, [fp, #-0xf8]
    // 0x1186e8c: LoadField: r1 = r3->field_f
    //     0x1186e8c: ldur            w1, [x3, #0xf]
    // 0x1186e90: DecompressPointer r1
    //     0x1186e90: add             x1, x1, HEAP, lsl #32
    // 0x1186e94: r0 = LoadClassIdInstr(r1)
    //     0x1186e94: ldur            x0, [x1, #-1]
    //     0x1186e98: ubfx            x0, x0, #0xc, #0x14
    // 0x1186e9c: r0 = GDT[cid_x0 + 0x5e6]()
    //     0x1186e9c: add             lr, x0, #0x5e6
    //     0x1186ea0: ldr             lr, [x21, lr, lsl #3]
    //     0x1186ea4: blr             lr
    // 0x1186ea8: mov             x1, x0
    // 0x1186eac: r17 = -280
    //     0x1186eac: mov             x17, #-0x118
    // 0x1186eb0: str             x1, [fp, x17]
    // 0x1186eb4: r0 = Await()
    //     0x1186eb4: bl              #0x7f5c00  ; AwaitStub
    // 0x1186eb8: mov             x1, x0
    // 0x1186ebc: r17 = -280
    //     0x1186ebc: mov             x17, #-0x118
    // 0x1186ec0: str             x1, [fp, x17]
    // 0x1186ec4: ldur            x16, [fp, #-0xe8]
    // 0x1186ec8: stp             x1, x16, [SP]
    // 0x1186ecc: ldur            x0, [fp, #-0xe8]
    // 0x1186ed0: ClosureCall
    //     0x1186ed0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x1186ed4: ldur            x2, [x0, #0x1f]
    //     0x1186ed8: blr             x2
    // 0x1186edc: mov             x1, x0
    // 0x1186ee0: r17 = -288
    //     0x1186ee0: mov             x17, #-0x120
    // 0x1186ee4: str             x1, [fp, x17]
    // 0x1186ee8: r0 = Await()
    //     0x1186ee8: bl              #0x7f5c00  ; AwaitStub
    // 0x1186eec: mov             x1, x0
    // 0x1186ef0: r0 = 0
    //     0x1186ef0: mov             x0, #0
    // 0x1186ef4: r17 = -288
    //     0x1186ef4: mov             x17, #-0x120
    // 0x1186ef8: str             x1, [fp, x17]
    // 0x1186efc: add             x2, fp, w0, sxtw #2
    // 0x1186f00: LoadField: r2 = r2->field_fffffff8
    //     0x1186f00: ldur            x2, [x2, #-8]
    // 0x1186f04: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1186f04: ldur            w3, [x2, #0x17]
    // 0x1186f08: DecompressPointer r3
    //     0x1186f08: add             x3, x3, HEAP, lsl #32
    // 0x1186f0c: stp             x1, x3, [SP]
    // 0x1186f10: r0 = add()
    //     0x1186f10: bl              #0x1187530  ; [dart:async] _AsyncStarStreamController::add
    // 0x1186f14: tbz             w0, #4, #0x1186f2c
    // 0x1186f18: r0 = Null
    //     0x1186f18: mov             x0, NULL
    // 0x1186f1c: r0 = YieldAsyncStar()
    //     0x1186f1c: bl              #0x118b2f4  ; YieldAsyncStarStub
    // 0x1186f20: r16 = true
    //     0x1186f20: add             x16, NULL, #0x20  ; true
    // 0x1186f24: cmp             w0, w16
    // 0x1186f28: b.ne            #0x1186f70
    // 0x1186f2c: ldur            x0, [fp, #-0xd8]
    // 0x1186f30: LoadField: r1 = r0->field_b
    //     0x1186f30: ldur            w1, [x0, #0xb]
    // 0x1186f34: DecompressPointer r1
    //     0x1186f34: add             x1, x1, HEAP, lsl #32
    // 0x1186f38: cmp             w1, NULL
    // 0x1186f3c: b.eq            #0x1186f54
    // 0x1186f40: mov             x1, x0
    // 0x1186f44: r0 = cancel()
    //     0x1186f44: bl              #0x8f3f74  ; [dart:async] _StreamIterator::cancel
    // 0x1186f48: mov             x1, x0
    // 0x1186f4c: stur            x1, [fp, #-0xf8]
    // 0x1186f50: r0 = Await()
    //     0x1186f50: bl              #0x7f5c00  ; AwaitStub
    // 0x1186f54: ldur            x1, [fp, #-0xe0]
    // 0x1186f58: r0 = close()
    //     0x1186f58: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x1186f5c: mov             x1, x0
    // 0x1186f60: stur            x1, [fp, #-0xf8]
    // 0x1186f64: r0 = Await()
    //     0x1186f64: bl              #0x7f5c00  ; AwaitStub
    // 0x1186f68: r0 = Null
    //     0x1186f68: mov             x0, NULL
    // 0x1186f6c: r0 = ReturnAsyncStar()
    //     0x1186f6c: b               #0x1187504  ; ReturnAsyncStarStub
    // 0x1186f70: ldur            x2, [fp, #-0xd8]
    // 0x1186f74: r0 = false
    //     0x1186f74: add             x0, NULL, #0x30  ; false
    // 0x1186f78: b               #0x1186c90
    // 0x1186f7c: ldur            x0, [fp, #-0xd8]
    // 0x1186f80: LoadField: r1 = r0->field_b
    //     0x1186f80: ldur            w1, [x0, #0xb]
    // 0x1186f84: DecompressPointer r1
    //     0x1186f84: add             x1, x1, HEAP, lsl #32
    // 0x1186f88: cmp             w1, NULL
    // 0x1186f8c: b.eq            #0x118704c
    // 0x1186f90: mov             x1, x0
    // 0x1186f94: r0 = cancel()
    //     0x1186f94: bl              #0x8f3f74  ; [dart:async] _StreamIterator::cancel
    // 0x1186f98: mov             x1, x0
    // 0x1186f9c: stur            x1, [fp, #-0xf8]
    // 0x1186fa0: r0 = Await()
    //     0x1186fa0: bl              #0x7f5c00  ; AwaitStub
    // 0x1186fa4: b               #0x118704c
    // 0x1186fa8: sub             SP, fp, #0x130
    // 0x1186fac: ldur            x2, [fp, #-0x100]
    // 0x1186fb0: mov             x3, x1
    // 0x1186fb4: stur            x0, [fp, #-0xf8]
    // 0x1186fb8: r17 = -280
    //     0x1186fb8: mov             x17, #-0x118
    // 0x1186fbc: str             x1, [fp, x17]
    // 0x1186fc0: r1 = Function '<anonymous closure>':.
    //     0x1186fc0: add             x1, PP, #0x94, lsl #12  ; [pp+0x94eb8] AnonymousClosure: (0x118b4a8), in [package:cached_network_image/src/image_provider/_image_loader.dart] ImageLoader::_load (0x1186bcc)
    //     0x1186fc4: ldr             x1, [x1, #0xeb8]
    // 0x1186fc8: r0 = AllocateClosure()
    //     0x1186fc8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1186fcc: str             x0, [SP]
    // 0x1186fd0: r0 = scheduleMicrotask()
    //     0x1186fd0: bl              #0x7e0298  ; [dart:async] ::scheduleMicrotask
    // 0x1186fd4: r0 = 0
    //     0x1186fd4: mov             x0, #0
    // 0x1186fd8: add             x1, fp, w0, sxtw #2
    // 0x1186fdc: LoadField: r1 = r1->field_fffffff8
    //     0x1186fdc: ldur            x1, [x1, #-8]
    // 0x1186fe0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x1186fe0: ldur            w0, [x1, #0x17]
    // 0x1186fe4: DecompressPointer r0
    //     0x1186fe4: add             x0, x0, HEAP, lsl #32
    // 0x1186fe8: ldur            x2, [fp, #-0xf8]
    // 0x1186fec: r17 = -280
    //     0x1186fec: mov             x17, #-0x118
    // 0x1186ff0: ldr             x3, [fp, x17]
    // 0x1186ff4: r17 = -288
    //     0x1186ff4: mov             x17, #-0x120
    // 0x1186ff8: str             x0, [fp, x17]
    // 0x1186ffc: r1 = <Codec>
    //     0x1186ffc: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d278] TypeArguments: <Codec>
    //     0x1187000: ldr             x1, [x1, #0x278]
    // 0x1187004: r0 = Stream.error()
    //     0x1187004: bl              #0x1187474  ; [dart:async] Stream::Stream.error
    // 0x1187008: r17 = -288
    //     0x1187008: mov             x17, #-0x120
    // 0x118700c: ldr             x16, [fp, x17]
    // 0x1187010: stp             x0, x16, [SP]
    // 0x1187014: r0 = addStream()
    //     0x1187014: bl              #0x118713c  ; [dart:async] _AsyncStarStreamController::addStream
    // 0x1187018: tbz             w0, #4, #0x1187030
    // 0x118701c: r0 = Null
    //     0x118701c: mov             x0, NULL
    // 0x1187020: r0 = YieldAsyncStar()
    //     0x1187020: bl              #0x118b2f4  ; YieldAsyncStarStub
    // 0x1187024: r16 = true
    //     0x1187024: add             x16, NULL, #0x20  ; true
    // 0x1187028: cmp             w0, w16
    // 0x118702c: b.ne            #0x118704c
    // 0x1187030: ldur            x1, [fp, #-0xe0]
    // 0x1187034: r0 = close()
    //     0x1187034: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x1187038: mov             x1, x0
    // 0x118703c: stur            x1, [fp, #-0xf8]
    // 0x1187040: r0 = Await()
    //     0x1187040: bl              #0x7f5c00  ; AwaitStub
    // 0x1187044: r0 = Null
    //     0x1187044: mov             x0, NULL
    // 0x1187048: r0 = ReturnAsyncStar()
    //     0x1187048: b               #0x1187504  ; ReturnAsyncStarStub
    // 0x118704c: ldur            x1, [fp, #-0xe0]
    // 0x1187050: r0 = close()
    //     0x1187050: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x1187054: mov             x1, x0
    // 0x1187058: stur            x1, [fp, #-0xf8]
    // 0x118705c: r0 = Await()
    //     0x118705c: bl              #0x7f5c00  ; AwaitStub
    // 0x1187060: r0 = Null
    //     0x1187060: mov             x0, NULL
    // 0x1187064: r0 = ReturnAsyncStar()
    //     0x1187064: b               #0x1187504  ; ReturnAsyncStarStub
    // 0x1187068: r0 = 0
    //     0x1187068: mov             x0, #0
    // 0x118706c: r0 = StateError()
    //     0x118706c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x1187070: mov             x1, x0
    // 0x1187074: r0 = "Already waiting for next."
    //     0x1187074: add             x0, PP, #0x16, lsl #12  ; [pp+0x162f0] "Already waiting for next."
    //     0x1187078: ldr             x0, [x0, #0x2f0]
    // 0x118707c: stur            x1, [fp, #-0xf8]
    // 0x1187080: StoreField: r1->field_b = r0
    //     0x1187080: stur            w0, [x1, #0xb]
    // 0x1187084: mov             x0, x1
    // 0x1187088: r0 = Throw()
    //     0x1187088: bl              #0x13ddb2c  ; ThrowStub
    // 0x118708c: brk             #0
    // 0x1187090: ldur            x1, [fp, #-0xe0]
    // 0x1187094: r0 = _badEventState()
    //     0x1187094: bl              #0x801620  ; [dart:async] _StreamController::_badEventState
    // 0x1187098: mov             x1, x0
    // 0x118709c: stur            x1, [fp, #-0xf8]
    // 0x11870a0: r0 = Throw()
    //     0x11870a0: bl              #0x13ddb2c  ; ThrowStub
    // 0x11870a4: brk             #0
    // 0x11870a8: sub             SP, fp, #0x130
    // 0x11870ac: ldur            x2, [fp, #-0xd8]
    // 0x11870b0: mov             x3, x0
    // 0x11870b4: stur            x0, [fp, #-0xd0]
    // 0x11870b8: mov             x0, x1
    // 0x11870bc: stur            x1, [fp, #-0xe8]
    // 0x11870c0: LoadField: r1 = r2->field_b
    //     0x11870c0: ldur            w1, [x2, #0xb]
    // 0x11870c4: DecompressPointer r1
    //     0x11870c4: add             x1, x1, HEAP, lsl #32
    // 0x11870c8: cmp             w1, NULL
    // 0x11870cc: b.eq            #0x11870e4
    // 0x11870d0: mov             x1, x2
    // 0x11870d4: r0 = cancel()
    //     0x11870d4: bl              #0x8f3f74  ; [dart:async] _StreamIterator::cancel
    // 0x11870d8: mov             x1, x0
    // 0x11870dc: stur            x1, [fp, #-0xf0]
    // 0x11870e0: r0 = Await()
    //     0x11870e0: bl              #0x7f5c00  ; AwaitStub
    // 0x11870e4: ldur            x0, [fp, #-0xd0]
    // 0x11870e8: ldur            x1, [fp, #-0xe8]
    // 0x11870ec: r0 = ReThrow()
    //     0x11870ec: bl              #0x13ddb00  ; ReThrowStub
    // 0x11870f0: brk             #0
    // 0x11870f4: sub             SP, fp, #0x130
    // 0x11870f8: mov             x2, x0
    // 0x11870fc: stur            x0, [fp, #-0xd0]
    // 0x1187100: mov             x0, x1
    // 0x1187104: stur            x1, [fp, #-0xd8]
    // 0x1187108: ldur            x1, [fp, #-0xe0]
    // 0x118710c: r0 = close()
    //     0x118710c: bl              #0x811f40  ; [dart:async] _StreamController::close
    // 0x1187110: mov             x1, x0
    // 0x1187114: stur            x1, [fp, #-0xe0]
    // 0x1187118: r0 = Await()
    //     0x1187118: bl              #0x7f5c00  ; AwaitStub
    // 0x118711c: ldur            x0, [fp, #-0xd0]
    // 0x1187120: ldur            x1, [fp, #-0xd8]
    // 0x1187124: r0 = ReThrow()
    //     0x1187124: bl              #0x13ddb00  ; ReThrowStub
    // 0x1187128: brk             #0
    // 0x118712c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118712c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1187130: b               #0x1186c18
    // 0x1187134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1187134: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1187138: b               #0x1186ca0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x118b4a8, size: 0x54
    // 0x118b4a8: EnterFrame
    //     0x118b4a8: stp             fp, lr, [SP, #-0x10]!
    //     0x118b4ac: mov             fp, SP
    // 0x118b4b0: AllocStack(0x8)
    //     0x118b4b0: sub             SP, SP, #8
    // 0x118b4b4: SetupParameters([dynamic _ /* r0 */])
    //     0x118b4b4: ldr             x0, [fp, #0x10]
    //     0x118b4b8: ldur            w1, [x0, #0x17]
    //     0x118b4bc: add             x1, x1, HEAP, lsl #32
    // 0x118b4c0: CheckStackOverflow
    //     0x118b4c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x118b4c4: cmp             SP, x16
    //     0x118b4c8: b.ls            #0x118b4f4
    // 0x118b4cc: LoadField: r0 = r1->field_f
    //     0x118b4cc: ldur            w0, [x1, #0xf]
    // 0x118b4d0: DecompressPointer r0
    //     0x118b4d0: add             x0, x0, HEAP, lsl #32
    // 0x118b4d4: str             x0, [SP]
    // 0x118b4d8: ClosureCall
    //     0x118b4d8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x118b4dc: ldur            x2, [x0, #0x1f]
    //     0x118b4e0: blr             x2
    // 0x118b4e4: r0 = Null
    //     0x118b4e4: mov             x0, NULL
    // 0x118b4e8: LeaveFrame
    //     0x118b4e8: mov             SP, fp
    //     0x118b4ec: ldp             fp, lr, [SP], #0x10
    // 0x118b4f0: ret
    //     0x118b4f0: ret             
    // 0x118b4f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118b4f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x118b4f8: b               #0x118b4cc
  }
  [closure] Future<Codec> <anonymous closure>(dynamic, Uint8List) async {
    // ** addr: 0x118b4fc, size: 0x78
    // 0x118b4fc: EnterFrame
    //     0x118b4fc: stp             fp, lr, [SP, #-0x10]!
    //     0x118b500: mov             fp, SP
    // 0x118b504: AllocStack(0x18)
    //     0x118b504: sub             SP, SP, #0x18
    // 0x118b508: SetupParameters(ImageLoader this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0x118b508: stur            NULL, [fp, #-8]
    //     0x118b50c: mov             x0, #0
    //     0x118b510: add             x1, fp, w0, sxtw #2
    //     0x118b514: ldr             x1, [x1, #0x18]
    //     0x118b518: add             x2, fp, w0, sxtw #2
    //     0x118b51c: ldr             x2, [x2, #0x10]
    //     0x118b520: stur            x2, [fp, #-0x18]
    //     0x118b524: ldur            w3, [x1, #0x17]
    //     0x118b528: add             x3, x3, HEAP, lsl #32
    //     0x118b52c: stur            x3, [fp, #-0x10]
    // 0x118b530: CheckStackOverflow
    //     0x118b530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x118b534: cmp             SP, x16
    //     0x118b538: b.ls            #0x118b56c
    // 0x118b53c: InitAsync() -> Future<Codec>
    //     0x118b53c: add             x0, PP, #0x8d, lsl #12  ; [pp+0x8d278] TypeArguments: <Codec>
    //     0x118b540: ldr             x0, [x0, #0x278]
    //     0x118b544: bl              #0x7f5e44  ; InitAsyncStub
    // 0x118b548: ldur            x1, [fp, #-0x18]
    // 0x118b54c: r0 = fromUint8List()
    //     0x118b54c: bl              #0xce7b70  ; [dart:ui] ImmutableBuffer::fromUint8List
    // 0x118b550: mov             x1, x0
    // 0x118b554: stur            x1, [fp, #-0x18]
    // 0x118b558: r0 = Await()
    //     0x118b558: bl              #0x7f5c00  ; AwaitStub
    // 0x118b55c: mov             x1, x0
    // 0x118b560: r2 = Null
    //     0x118b560: mov             x2, NULL
    // 0x118b564: r0 = instantiateImageCodecWithSize()
    //     0x118b564: bl              #0xdb5094  ; [dart:ui] ::instantiateImageCodecWithSize
    // 0x118b568: r0 = ReturnAsync()
    //     0x118b568: b               #0x82fdf0  ; ReturnAsyncStub
    // 0x118b56c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118b56c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x118b570: b               #0x118b53c
  }
}
