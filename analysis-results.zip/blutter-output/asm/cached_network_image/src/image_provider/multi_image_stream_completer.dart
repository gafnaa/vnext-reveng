// lib: , url: package:cached_network_image/src/image_provider/multi_image_stream_completer.dart

// class id: 1048619, size: 0x8
class :: {
}

// class id: 3592, size: 0x10, field offset: 0x8
class _MultiImageStreamCompleterHandle extends Object
    implements ImageStreamCompleterHandle {

  _ dispose(/* No info */) {
    // ** addr: 0x12e6df0, size: 0x74
    // 0x12e6df0: EnterFrame
    //     0x12e6df0: stp             fp, lr, [SP, #-0x10]!
    //     0x12e6df4: mov             fp, SP
    // 0x12e6df8: AllocStack(0x8)
    //     0x12e6df8: sub             SP, SP, #8
    // 0x12e6dfc: SetupParameters(_MultiImageStreamCompleterHandle this /* r1 => r0, fp-0x8 */)
    //     0x12e6dfc: mov             x0, x1
    //     0x12e6e00: stur            x1, [fp, #-8]
    // 0x12e6e04: CheckStackOverflow
    //     0x12e6e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e6e08: cmp             SP, x16
    //     0x12e6e0c: b.ls            #0x12e6e58
    // 0x12e6e10: LoadField: r1 = r0->field_b
    //     0x12e6e10: ldur            w1, [x0, #0xb]
    // 0x12e6e14: DecompressPointer r1
    //     0x12e6e14: add             x1, x1, HEAP, lsl #32
    // 0x12e6e18: r0 = dispose()
    //     0x12e6e18: bl              #0x12e6e64  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleterHandle::dispose
    // 0x12e6e1c: ldur            x0, [fp, #-8]
    // 0x12e6e20: LoadField: r1 = r0->field_7
    //     0x12e6e20: ldur            w1, [x0, #7]
    // 0x12e6e24: DecompressPointer r1
    //     0x12e6e24: add             x1, x1, HEAP, lsl #32
    // 0x12e6e28: cmp             w1, NULL
    // 0x12e6e2c: b.eq            #0x12e6e60
    // 0x12e6e30: LoadField: r2 = r1->field_6b
    //     0x12e6e30: ldur            x2, [x1, #0x6b]
    // 0x12e6e34: sub             x3, x2, #1
    // 0x12e6e38: StoreField: r1->field_6b = r3
    //     0x12e6e38: stur            x3, [x1, #0x6b]
    // 0x12e6e3c: r0 = __maybeDispose()
    //     0x12e6e3c: bl              #0x87c6d8  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::__maybeDispose
    // 0x12e6e40: ldur            x1, [fp, #-8]
    // 0x12e6e44: StoreField: r1->field_7 = rNULL
    //     0x12e6e44: stur            NULL, [x1, #7]
    // 0x12e6e48: r0 = Null
    //     0x12e6e48: mov             x0, NULL
    // 0x12e6e4c: LeaveFrame
    //     0x12e6e4c: mov             SP, fp
    //     0x12e6e50: ldp             fp, lr, [SP], #0x10
    // 0x12e6e54: ret
    //     0x12e6e54: ret             
    // 0x12e6e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e6e58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e6e5c: b               #0x12e6e10
    // 0x12e6e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12e6e60: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 5247, size: 0x74, field offset: 0x30
class MultiImageStreamCompleter extends ImageStreamCompleter {

  _ __maybeDispose(/* No info */) {
    // ** addr: 0x87c6d8, size: 0xe8
    // 0x87c6d8: EnterFrame
    //     0x87c6d8: stp             fp, lr, [SP, #-0x10]!
    //     0x87c6dc: mov             fp, SP
    // 0x87c6e0: AllocStack(0x8)
    //     0x87c6e0: sub             SP, SP, #8
    // 0x87c6e4: SetupParameters(MultiImageStreamCompleter this /* r1 => r3, fp-0x8 */)
    //     0x87c6e4: mov             x3, x1
    //     0x87c6e8: stur            x1, [fp, #-8]
    // 0x87c6ec: CheckStackOverflow
    //     0x87c6ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87c6f0: cmp             SP, x16
    //     0x87c6f4: b.ls            #0x87c7b8
    // 0x87c6f8: LoadField: r0 = r3->field_63
    //     0x87c6f8: ldur            w0, [x3, #0x63]
    // 0x87c6fc: DecompressPointer r0
    //     0x87c6fc: add             x0, x0, HEAP, lsl #32
    // 0x87c700: tbnz            w0, #4, #0x87c728
    // 0x87c704: LoadField: r0 = r3->field_67
    //     0x87c704: ldur            w0, [x3, #0x67]
    // 0x87c708: DecompressPointer r0
    //     0x87c708: add             x0, x0, HEAP, lsl #32
    // 0x87c70c: tbz             w0, #4, #0x87c728
    // 0x87c710: LoadField: r0 = r3->field_7
    //     0x87c710: ldur            w0, [x3, #7]
    // 0x87c714: DecompressPointer r0
    //     0x87c714: add             x0, x0, HEAP, lsl #32
    // 0x87c718: LoadField: r1 = r0->field_b
    //     0x87c718: ldur            w1, [x0, #0xb]
    // 0x87c71c: cbnz            w1, #0x87c728
    // 0x87c720: LoadField: r0 = r3->field_6b
    //     0x87c720: ldur            x0, [x3, #0x6b]
    // 0x87c724: cbz             x0, #0x87c738
    // 0x87c728: r0 = Null
    //     0x87c728: mov             x0, NULL
    // 0x87c72c: LeaveFrame
    //     0x87c72c: mov             SP, fp
    //     0x87c730: ldp             fp, lr, [SP], #0x10
    // 0x87c734: ret
    //     0x87c734: ret             
    // 0x87c738: r0 = true
    //     0x87c738: add             x0, NULL, #0x20  ; true
    // 0x87c73c: StoreField: r3->field_67 = r0
    //     0x87c73c: stur            w0, [x3, #0x67]
    // 0x87c740: LoadField: r1 = r3->field_5b
    //     0x87c740: ldur            w1, [x3, #0x5b]
    // 0x87c744: DecompressPointer r1
    //     0x87c744: add             x1, x1, HEAP, lsl #32
    // 0x87c748: cmp             w1, NULL
    // 0x87c74c: b.ne            #0x87c758
    // 0x87c750: mov             x2, x3
    // 0x87c754: b               #0x87c774
    // 0x87c758: r0 = LoadClassIdInstr(r1)
    //     0x87c758: ldur            x0, [x1, #-1]
    //     0x87c75c: ubfx            x0, x0, #0xc, #0x14
    // 0x87c760: r2 = Null
    //     0x87c760: mov             x2, NULL
    // 0x87c764: r0 = GDT[cid_x0 + 0x665]()
    //     0x87c764: add             lr, x0, #0x665
    //     0x87c768: ldr             lr, [x21, lr, lsl #3]
    //     0x87c76c: blr             lr
    // 0x87c770: ldur            x2, [fp, #-8]
    // 0x87c774: LoadField: r1 = r2->field_5b
    //     0x87c774: ldur            w1, [x2, #0x5b]
    // 0x87c778: DecompressPointer r1
    //     0x87c778: add             x1, x1, HEAP, lsl #32
    // 0x87c77c: cmp             w1, NULL
    // 0x87c780: b.ne            #0x87c78c
    // 0x87c784: mov             x1, x2
    // 0x87c788: b               #0x87c7a4
    // 0x87c78c: r0 = LoadClassIdInstr(r1)
    //     0x87c78c: ldur            x0, [x1, #-1]
    //     0x87c790: ubfx            x0, x0, #0xc, #0x14
    // 0x87c794: r0 = GDT[cid_x0 + 0x549]()
    //     0x87c794: add             lr, x0, #0x549
    //     0x87c798: ldr             lr, [x21, lr, lsl #3]
    //     0x87c79c: blr             lr
    // 0x87c7a0: ldur            x1, [fp, #-8]
    // 0x87c7a4: StoreField: r1->field_5b = rNULL
    //     0x87c7a4: stur            NULL, [x1, #0x5b]
    // 0x87c7a8: r0 = Null
    //     0x87c7a8: mov             x0, NULL
    // 0x87c7ac: LeaveFrame
    //     0x87c7ac: mov             SP, fp
    //     0x87c7b0: ldp             fp, lr, [SP], #0x10
    // 0x87c7b4: ret
    //     0x87c7b4: ret             
    // 0x87c7b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87c7b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87c7bc: b               #0x87c6f8
  }
  [closure] void addListener(dynamic, ImageStreamListener) {
    // ** addr: 0x91a9a0, size: 0x3c
    // 0x91a9a0: EnterFrame
    //     0x91a9a0: stp             fp, lr, [SP, #-0x10]!
    //     0x91a9a4: mov             fp, SP
    // 0x91a9a8: ldr             x0, [fp, #0x18]
    // 0x91a9ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x91a9ac: ldur            w1, [x0, #0x17]
    // 0x91a9b0: DecompressPointer r1
    //     0x91a9b0: add             x1, x1, HEAP, lsl #32
    // 0x91a9b4: CheckStackOverflow
    //     0x91a9b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x91a9b8: cmp             SP, x16
    //     0x91a9bc: b.ls            #0x91a9d4
    // 0x91a9c0: ldr             x2, [fp, #0x10]
    // 0x91a9c4: r0 = addListener()
    //     0x91a9c4: bl              #0x124a2dc  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::addListener
    // 0x91a9c8: LeaveFrame
    //     0x91a9c8: mov             SP, fp
    //     0x91a9cc: ldp             fp, lr, [SP], #0x10
    // 0x91a9d0: ret
    //     0x91a9d0: ret             
    // 0x91a9d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x91a9d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x91a9d8: b               #0x91a9c0
  }
  _ _decodeNextFrameAndSchedule(/* No info */) async {
    // ** addr: 0xd07edc, size: 0x17c
    // 0xd07edc: EnterFrame
    //     0xd07edc: stp             fp, lr, [SP, #-0x10]!
    //     0xd07ee0: mov             fp, SP
    // 0xd07ee4: AllocStack(0x98)
    //     0xd07ee4: sub             SP, SP, #0x98
    // 0xd07ee8: SetupParameters(MultiImageStreamCompleter this /* r1 => r1, fp-0x70 */)
    //     0xd07ee8: stur            NULL, [fp, #-8]
    //     0xd07eec: stur            x1, [fp, #-0x70]
    // 0xd07ef0: CheckStackOverflow
    //     0xd07ef0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd07ef4: cmp             SP, x16
    //     0xd07ef8: b.ls            #0xd08044
    // 0xd07efc: InitAsync() -> Future<void?>
    //     0xd07efc: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xd07f00: bl              #0x7f5e44  ; InitAsyncStub
    // 0xd07f04: ldur            x0, [fp, #-0x70]
    // 0xd07f08: LoadField: r1 = r0->field_2f
    //     0xd07f08: ldur            w1, [x0, #0x2f]
    // 0xd07f0c: DecompressPointer r1
    //     0xd07f0c: add             x1, x1, HEAP, lsl #32
    // 0xd07f10: cmp             w1, NULL
    // 0xd07f14: b.eq            #0xd0804c
    // 0xd07f18: r0 = getNextFrame()
    //     0xd07f18: bl              #0xce94b4  ; [dart:ui] _NativeCodec::getNextFrame
    // 0xd07f1c: mov             x1, x0
    // 0xd07f20: stur            x1, [fp, #-0x78]
    // 0xd07f24: r0 = Await()
    //     0xd07f24: bl              #0x7f5c00  ; AwaitStub
    // 0xd07f28: ldur            x2, [fp, #-0x70]
    // 0xd07f2c: StoreField: r2->field_43 = r0
    //     0xd07f2c: stur            w0, [x2, #0x43]
    //     0xd07f30: ldurb           w16, [x2, #-1]
    //     0xd07f34: ldurb           w17, [x0, #-1]
    //     0xd07f38: and             x16, x17, x16, lsr #2
    //     0xd07f3c: tst             x16, HEAP, lsr #32
    //     0xd07f40: b.eq            #0xd07f48
    //     0xd07f44: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd07f48: LoadField: r1 = r2->field_2f
    //     0xd07f48: ldur            w1, [x2, #0x2f]
    // 0xd07f4c: DecompressPointer r1
    //     0xd07f4c: add             x1, x1, HEAP, lsl #32
    // 0xd07f50: cmp             w1, NULL
    // 0xd07f54: b.eq            #0xd08050
    // 0xd07f58: r0 = frameCount()
    //     0xd07f58: bl              #0xd09318  ; [dart:ui] _NativeCodec::frameCount
    // 0xd07f5c: cmp             x0, #1
    // 0xd07f60: b.ne            #0xd07fc8
    // 0xd07f64: ldur            x1, [fp, #-0x70]
    // 0xd07f68: LoadField: r0 = r1->field_7
    //     0xd07f68: ldur            w0, [x1, #7]
    // 0xd07f6c: DecompressPointer r0
    //     0xd07f6c: add             x0, x0, HEAP, lsl #32
    // 0xd07f70: LoadField: r2 = r0->field_b
    //     0xd07f70: ldur            w2, [x0, #0xb]
    // 0xd07f74: cbnz            w2, #0xd07f80
    // 0xd07f78: r0 = Null
    //     0xd07f78: mov             x0, NULL
    // 0xd07f7c: r0 = ReturnAsyncNotFuture()
    //     0xd07f7c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd07f80: LoadField: r0 = r1->field_43
    //     0xd07f80: ldur            w0, [x1, #0x43]
    // 0xd07f84: DecompressPointer r0
    //     0xd07f84: add             x0, x0, HEAP, lsl #32
    // 0xd07f88: cmp             w0, NULL
    // 0xd07f8c: b.eq            #0xd08054
    // 0xd07f90: LoadField: r2 = r0->field_b
    //     0xd07f90: ldur            w2, [x0, #0xb]
    // 0xd07f94: DecompressPointer r2
    //     0xd07f94: add             x2, x2, HEAP, lsl #32
    // 0xd07f98: stur            x2, [fp, #-0x78]
    // 0xd07f9c: r0 = ImageInfo()
    //     0xd07f9c: bl              #0xd08ba8  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xd07fa0: mov             x1, x0
    // 0xd07fa4: ldur            x0, [fp, #-0x78]
    // 0xd07fa8: StoreField: r1->field_7 = r0
    //     0xd07fa8: stur            w0, [x1, #7]
    // 0xd07fac: d0 = 1.000000
    //     0xd07fac: fmov            d0, #1.00000000
    // 0xd07fb0: StoreField: r1->field_b = d0
    //     0xd07fb0: stur            d0, [x1, #0xb]
    // 0xd07fb4: mov             x2, x1
    // 0xd07fb8: ldur            x1, [fp, #-0x70]
    // 0xd07fbc: r0 = _emitFrame()
    //     0xd07fbc: bl              #0xd08718  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_emitFrame
    // 0xd07fc0: r0 = Null
    //     0xd07fc0: mov             x0, NULL
    // 0xd07fc4: r0 = ReturnAsyncNotFuture()
    //     0xd07fc4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd07fc8: ldur            x1, [fp, #-0x70]
    // 0xd07fcc: r0 = _scheduleAppFrame()
    //     0xd07fcc: bl              #0xd08058  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_scheduleAppFrame
    // 0xd07fd0: r0 = Null
    //     0xd07fd0: mov             x0, NULL
    // 0xd07fd4: r0 = ReturnAsyncNotFuture()
    //     0xd07fd4: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd07fd8: sub             SP, fp, #0x98
    // 0xd07fdc: ldur            x2, [fp, #-0x70]
    // 0xd07fe0: mov             x3, x0
    // 0xd07fe4: mov             x5, x1
    // 0xd07fe8: stur            x0, [fp, #-0x78]
    // 0xd07fec: stur            x1, [fp, #-0x80]
    // 0xd07ff0: r1 = <List<Object>>
    //     0xd07ff0: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0xd07ff4: r0 = ErrorDescription()
    //     0xd07ff4: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0xd07ff8: mov             x1, x0
    // 0xd07ffc: r2 = "resolving an image frame"
    //     0xd07ffc: add             x2, PP, #0x81, lsl #12  ; [pp+0x813b0] "resolving an image frame"
    //     0xd08000: ldr             x2, [x2, #0x3b0]
    // 0xd08004: r3 = Instance_DiagnosticLevel
    //     0xd08004: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0xd08008: stur            x0, [fp, #-0x88]
    // 0xd0800c: r0 = _ErrorDiagnostic()
    //     0xd0800c: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0xd08010: ldur            x1, [fp, #-0x70]
    // 0xd08014: LoadField: r0 = r1->field_3f
    //     0xd08014: ldur            w0, [x1, #0x3f]
    // 0xd08018: DecompressPointer r0
    //     0xd08018: add             x0, x0, HEAP, lsl #32
    // 0xd0801c: r16 = true
    //     0xd0801c: add             x16, NULL, #0x20  ; true
    // 0xd08020: stp             x16, x0, [SP]
    // 0xd08024: ldur            x2, [fp, #-0x88]
    // 0xd08028: ldur            x3, [fp, #-0x78]
    // 0xd0802c: ldur            x5, [fp, #-0x80]
    // 0xd08030: r4 = const [0, 0x6, 0x2, 0x4, informationCollector, 0x4, silent, 0x5, null]
    //     0xd08030: add             x4, PP, #0x81, lsl #12  ; [pp+0x813b8] List(9) [0, 0x6, 0x2, 0x4, "informationCollector", 0x4, "silent", 0x5, Null]
    //     0xd08034: ldr             x4, [x4, #0x3b8]
    // 0xd08038: r0 = reportError()
    //     0xd08038: bl              #0x91a2a0  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportError
    // 0xd0803c: r0 = Null
    //     0xd0803c: mov             x0, NULL
    // 0xd08040: r0 = ReturnAsyncNotFuture()
    //     0xd08040: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xd08044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08048: b               #0xd07efc
    // 0xd0804c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0804c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08050: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08050: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08054: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08054: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _scheduleAppFrame(/* No info */) {
    // ** addr: 0xd08058, size: 0x8c
    // 0xd08058: EnterFrame
    //     0xd08058: stp             fp, lr, [SP, #-0x10]!
    //     0xd0805c: mov             fp, SP
    // 0xd08060: AllocStack(0x8)
    //     0xd08060: sub             SP, SP, #8
    // 0xd08064: SetupParameters(MultiImageStreamCompleter this /* r1 => r2 */)
    //     0xd08064: mov             x2, x1
    // 0xd08068: CheckStackOverflow
    //     0xd08068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0806c: cmp             SP, x16
    //     0xd08070: b.ls            #0xd080d8
    // 0xd08074: LoadField: r0 = r2->field_5f
    //     0xd08074: ldur            w0, [x2, #0x5f]
    // 0xd08078: DecompressPointer r0
    //     0xd08078: add             x0, x0, HEAP, lsl #32
    // 0xd0807c: tbnz            w0, #4, #0xd08090
    // 0xd08080: r0 = Null
    //     0xd08080: mov             x0, NULL
    // 0xd08084: LeaveFrame
    //     0xd08084: mov             SP, fp
    //     0xd08088: ldp             fp, lr, [SP], #0x10
    // 0xd0808c: ret
    //     0xd0808c: ret             
    // 0xd08090: r0 = true
    //     0xd08090: add             x0, NULL, #0x20  ; true
    // 0xd08094: StoreField: r2->field_5f = r0
    //     0xd08094: stur            w0, [x2, #0x5f]
    // 0xd08098: r0 = LoadStaticField(0x5e4)
    //     0xd08098: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xd0809c: ldr             x0, [x0, #0xbc8]
    // 0xd080a0: stur            x0, [fp, #-8]
    // 0xd080a4: cmp             w0, NULL
    // 0xd080a8: b.eq            #0xd080e0
    // 0xd080ac: r1 = Function '_handleAppFrame@1194456093':.
    //     0xd080ac: add             x1, PP, #0x81, lsl #12  ; [pp+0x813c0] AnonymousClosure: (0xd0811c), in [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_handleAppFrame (0xd08158)
    //     0xd080b0: ldr             x1, [x1, #0x3c0]
    // 0xd080b4: r0 = AllocateClosure()
    //     0xd080b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd080b8: ldur            x1, [fp, #-8]
    // 0xd080bc: mov             x2, x0
    // 0xd080c0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xd080c0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xd080c4: r0 = scheduleFrameCallback()
    //     0xd080c4: bl              #0x8669b0  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::scheduleFrameCallback
    // 0xd080c8: r0 = Null
    //     0xd080c8: mov             x0, NULL
    // 0xd080cc: LeaveFrame
    //     0xd080cc: mov             SP, fp
    //     0xd080d0: ldp             fp, lr, [SP], #0x10
    // 0xd080d4: ret
    //     0xd080d4: ret             
    // 0xd080d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd080d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd080dc: b               #0xd08074
    // 0xd080e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd080e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _scheduleAppFrame(dynamic) {
    // ** addr: 0xd080e4, size: 0x38
    // 0xd080e4: EnterFrame
    //     0xd080e4: stp             fp, lr, [SP, #-0x10]!
    //     0xd080e8: mov             fp, SP
    // 0xd080ec: ldr             x0, [fp, #0x10]
    // 0xd080f0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd080f0: ldur            w1, [x0, #0x17]
    // 0xd080f4: DecompressPointer r1
    //     0xd080f4: add             x1, x1, HEAP, lsl #32
    // 0xd080f8: CheckStackOverflow
    //     0xd080f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd080fc: cmp             SP, x16
    //     0xd08100: b.ls            #0xd08114
    // 0xd08104: r0 = _scheduleAppFrame()
    //     0xd08104: bl              #0xd08058  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_scheduleAppFrame
    // 0xd08108: LeaveFrame
    //     0xd08108: mov             SP, fp
    //     0xd0810c: ldp             fp, lr, [SP], #0x10
    // 0xd08110: ret
    //     0xd08110: ret             
    // 0xd08114: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08114: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08118: b               #0xd08104
  }
  [closure] void _handleAppFrame(dynamic, Duration) {
    // ** addr: 0xd0811c, size: 0x3c
    // 0xd0811c: EnterFrame
    //     0xd0811c: stp             fp, lr, [SP, #-0x10]!
    //     0xd08120: mov             fp, SP
    // 0xd08124: ldr             x0, [fp, #0x18]
    // 0xd08128: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd08128: ldur            w1, [x0, #0x17]
    // 0xd0812c: DecompressPointer r1
    //     0xd0812c: add             x1, x1, HEAP, lsl #32
    // 0xd08130: CheckStackOverflow
    //     0xd08130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08134: cmp             SP, x16
    //     0xd08138: b.ls            #0xd08150
    // 0xd0813c: ldr             x2, [fp, #0x10]
    // 0xd08140: r0 = _handleAppFrame()
    //     0xd08140: bl              #0xd08158  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_handleAppFrame
    // 0xd08144: LeaveFrame
    //     0xd08144: mov             SP, fp
    //     0xd08148: ldp             fp, lr, [SP], #0x10
    // 0xd0814c: ret
    //     0xd0814c: ret             
    // 0xd08150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08150: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08154: b               #0xd0813c
  }
  _ _handleAppFrame(/* No info */) {
    // ** addr: 0xd08158, size: 0x328
    // 0xd08158: EnterFrame
    //     0xd08158: stp             fp, lr, [SP, #-0x10]!
    //     0xd0815c: mov             fp, SP
    // 0xd08160: AllocStack(0x28)
    //     0xd08160: sub             SP, SP, #0x28
    // 0xd08164: r0 = false
    //     0xd08164: add             x0, NULL, #0x30  ; false
    // 0xd08168: mov             x4, x1
    // 0xd0816c: mov             x3, x2
    // 0xd08170: stur            x1, [fp, #-8]
    // 0xd08174: stur            x2, [fp, #-0x10]
    // 0xd08178: CheckStackOverflow
    //     0xd08178: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0817c: cmp             SP, x16
    //     0xd08180: b.ls            #0xd08414
    // 0xd08184: StoreField: r4->field_5f = r0
    //     0xd08184: stur            w0, [x4, #0x5f]
    // 0xd08188: LoadField: r0 = r4->field_7
    //     0xd08188: ldur            w0, [x4, #7]
    // 0xd0818c: DecompressPointer r0
    //     0xd0818c: add             x0, x0, HEAP, lsl #32
    // 0xd08190: LoadField: r1 = r0->field_b
    //     0xd08190: ldur            w1, [x0, #0xb]
    // 0xd08194: cbnz            w1, #0xd081a8
    // 0xd08198: r0 = Null
    //     0xd08198: mov             x0, NULL
    // 0xd0819c: LeaveFrame
    //     0xd0819c: mov             SP, fp
    //     0xd081a0: ldp             fp, lr, [SP], #0x10
    // 0xd081a4: ret
    //     0xd081a4: ret             
    // 0xd081a8: LoadField: r0 = r4->field_4b
    //     0xd081a8: ldur            w0, [x4, #0x4b]
    // 0xd081ac: DecompressPointer r0
    //     0xd081ac: add             x0, x0, HEAP, lsl #32
    // 0xd081b0: cmp             w0, NULL
    // 0xd081b4: b.ne            #0xd081c0
    // 0xd081b8: mov             x1, x4
    // 0xd081bc: b               #0xd081d4
    // 0xd081c0: mov             x1, x4
    // 0xd081c4: mov             x2, x3
    // 0xd081c8: r0 = _hasFrameDurationPassed()
    //     0xd081c8: bl              #0xd086bc  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_hasFrameDurationPassed
    // 0xd081cc: tbnz            w0, #4, #0xd08368
    // 0xd081d0: ldur            x1, [fp, #-8]
    // 0xd081d4: LoadField: r0 = r1->field_43
    //     0xd081d4: ldur            w0, [x1, #0x43]
    // 0xd081d8: DecompressPointer r0
    //     0xd081d8: add             x0, x0, HEAP, lsl #32
    // 0xd081dc: cmp             w0, NULL
    // 0xd081e0: b.eq            #0xd0841c
    // 0xd081e4: LoadField: r2 = r0->field_b
    //     0xd081e4: ldur            w2, [x0, #0xb]
    // 0xd081e8: DecompressPointer r2
    //     0xd081e8: add             x2, x2, HEAP, lsl #32
    // 0xd081ec: stur            x2, [fp, #-0x18]
    // 0xd081f0: r0 = ImageInfo()
    //     0xd081f0: bl              #0xd08ba8  ; AllocateImageInfoStub -> ImageInfo (size=0x18)
    // 0xd081f4: mov             x1, x0
    // 0xd081f8: ldur            x0, [fp, #-0x18]
    // 0xd081fc: StoreField: r1->field_7 = r0
    //     0xd081fc: stur            w0, [x1, #7]
    // 0xd08200: d0 = 1.000000
    //     0xd08200: fmov            d0, #1.00000000
    // 0xd08204: StoreField: r1->field_b = d0
    //     0xd08204: stur            d0, [x1, #0xb]
    // 0xd08208: mov             x2, x1
    // 0xd0820c: ldur            x1, [fp, #-8]
    // 0xd08210: r0 = _emitFrame()
    //     0xd08210: bl              #0xd08718  ; [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::_emitFrame
    // 0xd08214: ldur            x0, [fp, #-0x10]
    // 0xd08218: ldur            x2, [fp, #-8]
    // 0xd0821c: StoreField: r2->field_47 = r0
    //     0xd0821c: stur            w0, [x2, #0x47]
    //     0xd08220: ldurb           w16, [x2, #-1]
    //     0xd08224: ldurb           w17, [x0, #-1]
    //     0xd08228: and             x16, x17, x16, lsr #2
    //     0xd0822c: tst             x16, HEAP, lsr #32
    //     0xd08230: b.eq            #0xd08238
    //     0xd08234: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd08238: LoadField: r0 = r2->field_43
    //     0xd08238: ldur            w0, [x2, #0x43]
    // 0xd0823c: DecompressPointer r0
    //     0xd0823c: add             x0, x0, HEAP, lsl #32
    // 0xd08240: cmp             w0, NULL
    // 0xd08244: b.eq            #0xd08420
    // 0xd08248: LoadField: r1 = r0->field_7
    //     0xd08248: ldur            w1, [x0, #7]
    // 0xd0824c: DecompressPointer r1
    //     0xd0824c: add             x1, x1, HEAP, lsl #32
    // 0xd08250: mov             x0, x1
    // 0xd08254: StoreField: r2->field_4b = r0
    //     0xd08254: stur            w0, [x2, #0x4b]
    //     0xd08258: ldurb           w16, [x2, #-1]
    //     0xd0825c: ldurb           w17, [x0, #-1]
    //     0xd08260: and             x16, x17, x16, lsr #2
    //     0xd08264: tst             x16, HEAP, lsr #32
    //     0xd08268: b.eq            #0xd08270
    //     0xd0826c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xd08270: StoreField: r2->field_43 = rNULL
    //     0xd08270: stur            NULL, [x2, #0x43]
    // 0xd08274: LoadField: r0 = r2->field_4f
    //     0xd08274: ldur            x0, [x2, #0x4f]
    // 0xd08278: stur            x0, [fp, #-0x20]
    // 0xd0827c: LoadField: r1 = r2->field_2f
    //     0xd0827c: ldur            w1, [x2, #0x2f]
    // 0xd08280: DecompressPointer r1
    //     0xd08280: add             x1, x1, HEAP, lsl #32
    // 0xd08284: cmp             w1, NULL
    // 0xd08288: b.eq            #0xd08424
    // 0xd0828c: r0 = frameCount()
    //     0xd0828c: bl              #0xd09318  ; [dart:ui] _NativeCodec::frameCount
    // 0xd08290: mov             x1, x0
    // 0xd08294: ldur            x0, [fp, #-0x20]
    // 0xd08298: cbz             x1, #0xd08428
    // 0xd0829c: sdiv            x3, x0, x1
    // 0xd082a0: msub            x2, x3, x1, x0
    // 0xd082a4: cmp             x2, xzr
    // 0xd082a8: b.lt            #0xd08440
    // 0xd082ac: cbnz            x2, #0xd082d0
    // 0xd082b0: ldur            x0, [fp, #-8]
    // 0xd082b4: LoadField: r1 = r0->field_33
    //     0xd082b4: ldur            w1, [x0, #0x33]
    // 0xd082b8: DecompressPointer r1
    //     0xd082b8: add             x1, x1, HEAP, lsl #32
    // 0xd082bc: cmp             w1, NULL
    // 0xd082c0: b.eq            #0xd082d4
    // 0xd082c4: mov             x1, x0
    // 0xd082c8: r0 = _switchToNewCodec()
    //     0xd082c8: bl              #0xd085f8  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_switchToNewCodec
    // 0xd082cc: b               #0xd08358
    // 0xd082d0: ldur            x0, [fp, #-8]
    // 0xd082d4: LoadField: r2 = r0->field_4f
    //     0xd082d4: ldur            x2, [x0, #0x4f]
    // 0xd082d8: stur            x2, [fp, #-0x20]
    // 0xd082dc: LoadField: r1 = r0->field_2f
    //     0xd082dc: ldur            w1, [x0, #0x2f]
    // 0xd082e0: DecompressPointer r1
    //     0xd082e0: add             x1, x1, HEAP, lsl #32
    // 0xd082e4: cmp             w1, NULL
    // 0xd082e8: b.eq            #0xd08454
    // 0xd082ec: r0 = frameCount()
    //     0xd082ec: bl              #0xd09318  ; [dart:ui] _NativeCodec::frameCount
    // 0xd082f0: mov             x1, x0
    // 0xd082f4: ldur            x0, [fp, #-0x20]
    // 0xd082f8: cbz             x1, #0xd08458
    // 0xd082fc: sdiv            x2, x0, x1
    // 0xd08300: ldur            x0, [fp, #-8]
    // 0xd08304: stur            x2, [fp, #-0x28]
    // 0xd08308: LoadField: r1 = r0->field_2f
    //     0xd08308: ldur            w1, [x0, #0x2f]
    // 0xd0830c: DecompressPointer r1
    //     0xd0830c: add             x1, x1, HEAP, lsl #32
    // 0xd08310: cmp             w1, NULL
    // 0xd08314: b.eq            #0xd08470
    // 0xd08318: r0 = repetitionCount()
    //     0xd08318: bl              #0xd08480  ; [dart:ui] _NativeCodec::repetitionCount
    // 0xd0831c: cmn             x0, #1
    // 0xd08320: b.eq            #0xd08350
    // 0xd08324: ldur            x2, [fp, #-8]
    // 0xd08328: ldur            x0, [fp, #-0x28]
    // 0xd0832c: LoadField: r1 = r2->field_2f
    //     0xd0832c: ldur            w1, [x2, #0x2f]
    // 0xd08330: DecompressPointer r1
    //     0xd08330: add             x1, x1, HEAP, lsl #32
    // 0xd08334: cmp             w1, NULL
    // 0xd08338: b.eq            #0xd08474
    // 0xd0833c: r0 = repetitionCount()
    //     0xd0833c: bl              #0xd08480  ; [dart:ui] _NativeCodec::repetitionCount
    // 0xd08340: mov             x1, x0
    // 0xd08344: ldur            x0, [fp, #-0x28]
    // 0xd08348: cmp             x0, x1
    // 0xd0834c: b.gt            #0xd08358
    // 0xd08350: ldur            x1, [fp, #-8]
    // 0xd08354: r0 = _decodeNextFrameAndSchedule()
    //     0xd08354: bl              #0xd07edc  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0xd08358: r0 = Null
    //     0xd08358: mov             x0, NULL
    // 0xd0835c: LeaveFrame
    //     0xd0835c: mov             SP, fp
    //     0xd08360: ldp             fp, lr, [SP], #0x10
    // 0xd08364: ret
    //     0xd08364: ret             
    // 0xd08368: ldur            x2, [fp, #-8]
    // 0xd0836c: ldur            x0, [fp, #-0x10]
    // 0xd08370: LoadField: r1 = r2->field_4b
    //     0xd08370: ldur            w1, [x2, #0x4b]
    // 0xd08374: DecompressPointer r1
    //     0xd08374: add             x1, x1, HEAP, lsl #32
    // 0xd08378: cmp             w1, NULL
    // 0xd0837c: b.eq            #0xd08478
    // 0xd08380: LoadField: r3 = r2->field_47
    //     0xd08380: ldur            w3, [x2, #0x47]
    // 0xd08384: DecompressPointer r3
    //     0xd08384: add             x3, x3, HEAP, lsl #32
    // 0xd08388: cmp             w3, NULL
    // 0xd0838c: b.eq            #0xd0847c
    // 0xd08390: LoadField: r4 = r0->field_7
    //     0xd08390: ldur            x4, [x0, #7]
    // 0xd08394: LoadField: r0 = r3->field_7
    //     0xd08394: ldur            x0, [x3, #7]
    // 0xd08398: sub             x3, x4, x0
    // 0xd0839c: LoadField: r0 = r1->field_7
    //     0xd0839c: ldur            x0, [x1, #7]
    // 0xd083a0: sub             x1, x0, x3
    // 0xd083a4: stur            x1, [fp, #-0x20]
    // 0xd083a8: r0 = Duration()
    //     0xd083a8: bl              #0x7dd0d0  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xd083ac: mov             x1, x0
    // 0xd083b0: ldur            x0, [fp, #-0x20]
    // 0xd083b4: StoreField: r1->field_7 = r0
    //     0xd083b4: stur            x0, [x1, #7]
    // 0xd083b8: r2 = 1.000000
    //     0xd083b8: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xd083bc: r0 = *()
    //     0xd083bc: bl              #0x7dd190  ; [dart:core] Duration::*
    // 0xd083c0: ldur            x2, [fp, #-8]
    // 0xd083c4: r1 = Function '_scheduleAppFrame@1194456093':.
    //     0xd083c4: add             x1, PP, #0x81, lsl #12  ; [pp+0x813c8] AnonymousClosure: (0xd080e4), in [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_scheduleAppFrame (0xd08058)
    //     0xd083c8: ldr             x1, [x1, #0x3c8]
    // 0xd083cc: stur            x0, [fp, #-0x10]
    // 0xd083d0: r0 = AllocateClosure()
    //     0xd083d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xd083d4: ldur            x2, [fp, #-0x10]
    // 0xd083d8: mov             x3, x0
    // 0xd083dc: r1 = Null
    //     0xd083dc: mov             x1, NULL
    // 0xd083e0: r0 = Timer()
    //     0xd083e0: bl              #0x7eed74  ; [dart:async] Timer::Timer
    // 0xd083e4: ldur            x1, [fp, #-8]
    // 0xd083e8: StoreField: r1->field_57 = r0
    //     0xd083e8: stur            w0, [x1, #0x57]
    //     0xd083ec: ldurb           w16, [x1, #-1]
    //     0xd083f0: ldurb           w17, [x0, #-1]
    //     0xd083f4: and             x16, x17, x16, lsr #2
    //     0xd083f8: tst             x16, HEAP, lsr #32
    //     0xd083fc: b.eq            #0xd08404
    //     0xd08400: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd08404: r0 = Null
    //     0xd08404: mov             x0, NULL
    // 0xd08408: LeaveFrame
    //     0xd08408: mov             SP, fp
    //     0xd0840c: ldp             fp, lr, [SP], #0x10
    // 0xd08410: ret
    //     0xd08410: ret             
    // 0xd08414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08418: b               #0xd08184
    // 0xd0841c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0841c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08420: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08424: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08424: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08428: stp             x0, x1, [SP, #-0x10]!
    // 0xd0842c: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xd08430: r4 = 0
    //     0xd08430: mov             x4, #0
    // 0xd08434: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xd08438: blr             lr
    // 0xd0843c: brk             #0
    // 0xd08440: cmp             x1, xzr
    // 0xd08444: sub             x3, x2, x1
    // 0xd08448: add             x2, x2, x1
    // 0xd0844c: csel            x2, x3, x2, lt
    // 0xd08450: b               #0xd082ac
    // 0xd08454: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08454: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08458: stp             x0, x1, [SP, #-0x10]!
    // 0xd0845c: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xd08460: r4 = 0
    //     0xd08460: mov             x4, #0
    // 0xd08464: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xd08468: blr             lr
    // 0xd0846c: brk             #0
    // 0xd08470: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08470: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08474: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08474: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08478: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08478: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd0847c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd0847c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _switchToNewCodec(/* No info */) {
    // ** addr: 0xd085f8, size: 0x64
    // 0xd085f8: EnterFrame
    //     0xd085f8: stp             fp, lr, [SP, #-0x10]!
    //     0xd085fc: mov             fp, SP
    // 0xd08600: AllocStack(0x8)
    //     0xd08600: sub             SP, SP, #8
    // 0xd08604: SetupParameters(MultiImageStreamCompleter this /* r1 => r0, fp-0x8 */)
    //     0xd08604: mov             x0, x1
    //     0xd08608: stur            x1, [fp, #-8]
    // 0xd0860c: CheckStackOverflow
    //     0xd0860c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd08610: cmp             SP, x16
    //     0xd08614: b.ls            #0xd08650
    // 0xd08618: StoreField: r0->field_4f = rZR
    //     0xd08618: stur            xzr, [x0, #0x4f]
    // 0xd0861c: StoreField: r0->field_57 = rNULL
    //     0xd0861c: stur            NULL, [x0, #0x57]
    // 0xd08620: LoadField: r2 = r0->field_33
    //     0xd08620: ldur            w2, [x0, #0x33]
    // 0xd08624: DecompressPointer r2
    //     0xd08624: add             x2, x2, HEAP, lsl #32
    // 0xd08628: cmp             w2, NULL
    // 0xd0862c: b.eq            #0xd08658
    // 0xd08630: mov             x1, x0
    // 0xd08634: r0 = _handleCodecReady()
    //     0xd08634: bl              #0xd0865c  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_handleCodecReady
    // 0xd08638: ldur            x1, [fp, #-8]
    // 0xd0863c: StoreField: r1->field_33 = rNULL
    //     0xd0863c: stur            NULL, [x1, #0x33]
    // 0xd08640: r0 = Null
    //     0xd08640: mov             x0, NULL
    // 0xd08644: LeaveFrame
    //     0xd08644: mov             SP, fp
    //     0xd08648: ldp             fp, lr, [SP], #0x10
    // 0xd0864c: ret
    //     0xd0864c: ret             
    // 0xd08650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd08650: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd08654: b               #0xd08618
    // 0xd08658: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08658: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleCodecReady(/* No info */) {
    // ** addr: 0xd0865c, size: 0x60
    // 0xd0865c: EnterFrame
    //     0xd0865c: stp             fp, lr, [SP, #-0x10]!
    //     0xd08660: mov             fp, SP
    // 0xd08664: mov             x0, x2
    // 0xd08668: CheckStackOverflow
    //     0xd08668: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd0866c: cmp             SP, x16
    //     0xd08670: b.ls            #0xd086b4
    // 0xd08674: StoreField: r1->field_2f = r0
    //     0xd08674: stur            w0, [x1, #0x2f]
    //     0xd08678: ldurb           w16, [x1, #-1]
    //     0xd0867c: ldurb           w17, [x0, #-1]
    //     0xd08680: and             x16, x17, x16, lsr #2
    //     0xd08684: tst             x16, HEAP, lsr #32
    //     0xd08688: b.eq            #0xd08690
    //     0xd0868c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd08690: LoadField: r0 = r1->field_7
    //     0xd08690: ldur            w0, [x1, #7]
    // 0xd08694: DecompressPointer r0
    //     0xd08694: add             x0, x0, HEAP, lsl #32
    // 0xd08698: LoadField: r2 = r0->field_b
    //     0xd08698: ldur            w2, [x0, #0xb]
    // 0xd0869c: cbz             w2, #0xd086a4
    // 0xd086a0: r0 = _decodeNextFrameAndSchedule()
    //     0xd086a0: bl              #0xd07edc  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0xd086a4: r0 = Null
    //     0xd086a4: mov             x0, NULL
    // 0xd086a8: LeaveFrame
    //     0xd086a8: mov             SP, fp
    //     0xd086ac: ldp             fp, lr, [SP], #0x10
    // 0xd086b0: ret
    //     0xd086b0: ret             
    // 0xd086b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd086b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd086b8: b               #0xd08674
  }
  _ _hasFrameDurationPassed(/* No info */) {
    // ** addr: 0xd086bc, size: 0x5c
    // 0xd086bc: EnterFrame
    //     0xd086bc: stp             fp, lr, [SP, #-0x10]!
    //     0xd086c0: mov             fp, SP
    // 0xd086c4: LoadField: r3 = r1->field_47
    //     0xd086c4: ldur            w3, [x1, #0x47]
    // 0xd086c8: DecompressPointer r3
    //     0xd086c8: add             x3, x3, HEAP, lsl #32
    // 0xd086cc: cmp             w3, NULL
    // 0xd086d0: b.eq            #0xd08710
    // 0xd086d4: LoadField: r4 = r2->field_7
    //     0xd086d4: ldur            x4, [x2, #7]
    // 0xd086d8: LoadField: r2 = r3->field_7
    //     0xd086d8: ldur            x2, [x3, #7]
    // 0xd086dc: sub             x3, x4, x2
    // 0xd086e0: LoadField: r2 = r1->field_4b
    //     0xd086e0: ldur            w2, [x1, #0x4b]
    // 0xd086e4: DecompressPointer r2
    //     0xd086e4: add             x2, x2, HEAP, lsl #32
    // 0xd086e8: cmp             w2, NULL
    // 0xd086ec: b.eq            #0xd08714
    // 0xd086f0: LoadField: r1 = r2->field_7
    //     0xd086f0: ldur            x1, [x2, #7]
    // 0xd086f4: cmp             x3, x1
    // 0xd086f8: r16 = true
    //     0xd086f8: add             x16, NULL, #0x20  ; true
    // 0xd086fc: r17 = false
    //     0xd086fc: add             x17, NULL, #0x30  ; false
    // 0xd08700: csel            x0, x16, x17, ge
    // 0xd08704: LeaveFrame
    //     0xd08704: mov             SP, fp
    //     0xd08708: ldp             fp, lr, [SP], #0x10
    // 0xd0870c: ret
    //     0xd0870c: ret             
    // 0xd08710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08710: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd08714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd08714: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ MultiImageStreamCompleter(/* No info */) {
    // ** addr: 0x11862f0, size: 0x160
    // 0x11862f0: EnterFrame
    //     0x11862f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11862f4: mov             fp, SP
    // 0x11862f8: AllocStack(0x30)
    //     0x11862f8: sub             SP, SP, #0x30
    // 0x11862fc: SetupParameters(MultiImageStreamCompleter this /* r1 => r3, fp-0x20 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x11862fc: stur            x1, [fp, #-8]
    //     0x1186300: mov             x16, x3
    //     0x1186304: mov             x3, x1
    //     0x1186308: mov             x1, x16
    //     0x118630c: mov             x0, x5
    //     0x1186310: stur            x2, [fp, #-0x10]
    //     0x1186314: stur            x1, [fp, #-0x18]
    //     0x1186318: stur            x5, [fp, #-0x20]
    // 0x118631c: CheckStackOverflow
    //     0x118631c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1186320: cmp             SP, x16
    //     0x1186324: b.ls            #0x1186448
    // 0x1186328: r1 = 2
    //     0x1186328: mov             x1, #2
    // 0x118632c: r0 = AllocateContext()
    //     0x118632c: bl              #0x13de838  ; AllocateContextStub
    // 0x1186330: mov             x3, x0
    // 0x1186334: ldur            x2, [fp, #-8]
    // 0x1186338: stur            x3, [fp, #-0x28]
    // 0x118633c: StoreField: r3->field_f = r2
    //     0x118633c: stur            w2, [x3, #0xf]
    // 0x1186340: ldur            x0, [fp, #-0x20]
    // 0x1186344: StoreField: r3->field_13 = r0
    //     0x1186344: stur            w0, [x3, #0x13]
    // 0x1186348: StoreField: r2->field_4f = rZR
    //     0x1186348: stur            xzr, [x2, #0x4f]
    // 0x118634c: r1 = false
    //     0x118634c: add             x1, NULL, #0x30  ; false
    // 0x1186350: StoreField: r2->field_5f = r1
    //     0x1186350: stur            w1, [x2, #0x5f]
    // 0x1186354: StoreField: r2->field_63 = r1
    //     0x1186354: stur            w1, [x2, #0x63]
    // 0x1186358: StoreField: r2->field_67 = r1
    //     0x1186358: stur            w1, [x2, #0x67]
    // 0x118635c: StoreField: r2->field_6b = rZR
    //     0x118635c: stur            xzr, [x2, #0x6b]
    // 0x1186360: StoreField: r2->field_3f = r0
    //     0x1186360: stur            w0, [x2, #0x3f]
    //     0x1186364: ldurb           w16, [x2, #-1]
    //     0x1186368: ldurb           w17, [x0, #-1]
    //     0x118636c: and             x16, x17, x16, lsr #2
    //     0x1186370: tst             x16, HEAP, lsr #32
    //     0x1186374: b.eq            #0x118637c
    //     0x1186378: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x118637c: d0 = 1.000000
    //     0x118637c: fmov            d0, #1.00000000
    // 0x1186380: StoreField: r2->field_37 = d0
    //     0x1186380: stur            d0, [x2, #0x37]
    // 0x1186384: mov             x1, x2
    // 0x1186388: r0 = ImageStreamCompleter()
    //     0x1186388: bl              #0x91aa54  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::ImageStreamCompleter
    // 0x118638c: ldur            x2, [fp, #-0x28]
    // 0x1186390: r1 = Function '<anonymous closure>':.
    //     0x1186390: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e58] AnonymousClosure: (0x1186824), in [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::MultiImageStreamCompleter (0x11862f0)
    //     0x1186394: ldr             x1, [x1, #0xe58]
    // 0x1186398: r0 = AllocateClosure()
    //     0x1186398: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x118639c: ldur            x2, [fp, #-0x28]
    // 0x11863a0: r1 = Function '<anonymous closure>':.
    //     0x11863a0: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e60] AnonymousClosure: (0x11866f0), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter (0x11864e8)
    //     0x11863a4: ldr             x1, [x1, #0xe60]
    // 0x11863a8: stur            x0, [fp, #-0x20]
    // 0x11863ac: r0 = AllocateClosure()
    //     0x11863ac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11863b0: ldur            x1, [fp, #-0x18]
    // 0x11863b4: r2 = LoadClassIdInstr(r1)
    //     0x11863b4: ldur            x2, [x1, #-1]
    //     0x11863b8: ubfx            x2, x2, #0xc, #0x14
    // 0x11863bc: str             x0, [SP]
    // 0x11863c0: mov             x0, x2
    // 0x11863c4: ldur            x2, [fp, #-0x20]
    // 0x11863c8: r4 = const [0, 0x3, 0x1, 0x2, onError, 0x2, null]
    //     0x11863c8: add             x4, PP, #0x83, lsl #12  ; [pp+0x83680] List(7) [0, 0x3, 0x1, 0x2, "onError", 0x2, Null]
    //     0x11863cc: ldr             x4, [x4, #0x680]
    // 0x11863d0: r0 = GDT[cid_x0 + 0x6de]()
    //     0x11863d0: add             lr, x0, #0x6de
    //     0x11863d4: ldr             lr, [x21, lr, lsl #3]
    //     0x11863d8: blr             lr
    // 0x11863dc: ldur            x2, [fp, #-8]
    // 0x11863e0: r1 = Function 'reportImageChunkEvent':.
    //     0x11863e0: add             x1, PP, #0x94, lsl #12  ; [pp+0x94d10] AnonymousClosure: (0x11868a4), in [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::reportImageChunkEvent (0x11868e0)
    //     0x11863e4: ldr             x1, [x1, #0xd10]
    // 0x11863e8: r0 = AllocateClosure()
    //     0x11863e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11863ec: ldur            x2, [fp, #-0x28]
    // 0x11863f0: r1 = Function '<anonymous closure>':.
    //     0x11863f0: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e68] AnonymousClosure: (0x1186450), in [package:flutter/src/painting/image_stream.dart] MultiFrameImageStreamCompleter::MultiFrameImageStreamCompleter (0x11864e8)
    //     0x11863f4: ldr             x1, [x1, #0xe68]
    // 0x11863f8: stur            x0, [fp, #-0x18]
    // 0x11863fc: r0 = AllocateClosure()
    //     0x11863fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1186400: str             x0, [SP]
    // 0x1186404: ldur            x1, [fp, #-0x10]
    // 0x1186408: ldur            x2, [fp, #-0x18]
    // 0x118640c: r4 = const [0, 0x3, 0x1, 0x2, onError, 0x2, null]
    //     0x118640c: add             x4, PP, #0x83, lsl #12  ; [pp+0x83680] List(7) [0, 0x3, 0x1, 0x2, "onError", 0x2, Null]
    //     0x1186410: ldr             x4, [x4, #0x680]
    // 0x1186414: r0 = listen()
    //     0x1186414: bl              #0x123a37c  ; [dart:async] _StreamImpl::listen
    // 0x1186418: ldur            x1, [fp, #-8]
    // 0x118641c: StoreField: r1->field_5b = r0
    //     0x118641c: stur            w0, [x1, #0x5b]
    //     0x1186420: ldurb           w16, [x1, #-1]
    //     0x1186424: ldurb           w17, [x0, #-1]
    //     0x1186428: and             x16, x17, x16, lsr #2
    //     0x118642c: tst             x16, HEAP, lsr #32
    //     0x1186430: b.eq            #0x1186438
    //     0x1186434: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1186438: r0 = Null
    //     0x1186438: mov             x0, NULL
    // 0x118643c: LeaveFrame
    //     0x118643c: mov             SP, fp
    //     0x1186440: ldp             fp, lr, [SP], #0x10
    // 0x1186444: ret
    //     0x1186444: ret             
    // 0x1186448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1186448: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x118644c: b               #0x1186328
  }
  [closure] void <anonymous closure>(dynamic, Codec) {
    // ** addr: 0x1186824, size: 0x80
    // 0x1186824: EnterFrame
    //     0x1186824: stp             fp, lr, [SP, #-0x10]!
    //     0x1186828: mov             fp, SP
    // 0x118682c: ldr             x0, [fp, #0x18]
    // 0x1186830: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1186830: ldur            w1, [x0, #0x17]
    // 0x1186834: DecompressPointer r1
    //     0x1186834: add             x1, x1, HEAP, lsl #32
    // 0x1186838: CheckStackOverflow
    //     0x1186838: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x118683c: cmp             SP, x16
    //     0x1186840: b.ls            #0x118689c
    // 0x1186844: LoadField: r2 = r1->field_f
    //     0x1186844: ldur            w2, [x1, #0xf]
    // 0x1186848: DecompressPointer r2
    //     0x1186848: add             x2, x2, HEAP, lsl #32
    // 0x118684c: LoadField: r0 = r2->field_57
    //     0x118684c: ldur            w0, [x2, #0x57]
    // 0x1186850: DecompressPointer r0
    //     0x1186850: add             x0, x0, HEAP, lsl #32
    // 0x1186854: cmp             w0, NULL
    // 0x1186858: b.eq            #0x1186880
    // 0x118685c: ldr             x0, [fp, #0x10]
    // 0x1186860: StoreField: r2->field_33 = r0
    //     0x1186860: stur            w0, [x2, #0x33]
    //     0x1186864: ldurb           w16, [x2, #-1]
    //     0x1186868: ldurb           w17, [x0, #-1]
    //     0x118686c: and             x16, x17, x16, lsr #2
    //     0x1186870: tst             x16, HEAP, lsr #32
    //     0x1186874: b.eq            #0x118687c
    //     0x1186878: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x118687c: b               #0x118688c
    // 0x1186880: mov             x1, x2
    // 0x1186884: ldr             x2, [fp, #0x10]
    // 0x1186888: r0 = _handleCodecReady()
    //     0x1186888: bl              #0xd0865c  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_handleCodecReady
    // 0x118688c: r0 = Null
    //     0x118688c: mov             x0, NULL
    // 0x1186890: LeaveFrame
    //     0x1186890: mov             SP, fp
    //     0x1186894: ldp             fp, lr, [SP], #0x10
    // 0x1186898: ret
    //     0x1186898: ret             
    // 0x118689c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118689c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11868a0: b               #0x1186844
  }
  _ addListener(/* No info */) {
    // ** addr: 0x124a2dc, size: 0x78
    // 0x124a2dc: EnterFrame
    //     0x124a2dc: stp             fp, lr, [SP, #-0x10]!
    //     0x124a2e0: mov             fp, SP
    // 0x124a2e4: AllocStack(0x10)
    //     0x124a2e4: sub             SP, SP, #0x10
    // 0x124a2e8: r0 = true
    //     0x124a2e8: add             x0, NULL, #0x20  ; true
    // 0x124a2ec: mov             x3, x1
    // 0x124a2f0: stur            x1, [fp, #-8]
    // 0x124a2f4: stur            x2, [fp, #-0x10]
    // 0x124a2f8: CheckStackOverflow
    //     0x124a2f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124a2fc: cmp             SP, x16
    //     0x124a300: b.ls            #0x124a34c
    // 0x124a304: StoreField: r3->field_63 = r0
    //     0x124a304: stur            w0, [x3, #0x63]
    // 0x124a308: LoadField: r0 = r3->field_7
    //     0x124a308: ldur            w0, [x3, #7]
    // 0x124a30c: DecompressPointer r0
    //     0x124a30c: add             x0, x0, HEAP, lsl #32
    // 0x124a310: LoadField: r1 = r0->field_b
    //     0x124a310: ldur            w1, [x0, #0xb]
    // 0x124a314: cbnz            w1, #0x124a330
    // 0x124a318: LoadField: r0 = r3->field_2f
    //     0x124a318: ldur            w0, [x3, #0x2f]
    // 0x124a31c: DecompressPointer r0
    //     0x124a31c: add             x0, x0, HEAP, lsl #32
    // 0x124a320: cmp             w0, NULL
    // 0x124a324: b.eq            #0x124a330
    // 0x124a328: mov             x1, x3
    // 0x124a32c: r0 = _decodeNextFrameAndSchedule()
    //     0x124a32c: bl              #0xd07edc  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::_decodeNextFrameAndSchedule
    // 0x124a330: ldur            x1, [fp, #-8]
    // 0x124a334: ldur            x2, [fp, #-0x10]
    // 0x124a338: r0 = addListener()
    //     0x124a338: bl              #0x124a354  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::addListener
    // 0x124a33c: r0 = Null
    //     0x124a33c: mov             x0, NULL
    // 0x124a340: LeaveFrame
    //     0x124a340: mov             SP, fp
    //     0x124a344: ldp             fp, lr, [SP], #0x10
    // 0x124a348: ret
    //     0x124a348: ret             
    // 0x124a34c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124a34c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124a350: b               #0x124a304
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x1253960, size: 0x7c
    // 0x1253960: EnterFrame
    //     0x1253960: stp             fp, lr, [SP, #-0x10]!
    //     0x1253964: mov             fp, SP
    // 0x1253968: AllocStack(0x8)
    //     0x1253968: sub             SP, SP, #8
    // 0x125396c: SetupParameters(MultiImageStreamCompleter this /* r1 => r0, fp-0x8 */)
    //     0x125396c: mov             x0, x1
    //     0x1253970: stur            x1, [fp, #-8]
    // 0x1253974: CheckStackOverflow
    //     0x1253974: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1253978: cmp             SP, x16
    //     0x125397c: b.ls            #0x12539d4
    // 0x1253980: mov             x1, x0
    // 0x1253984: r0 = removeListener()
    //     0x1253984: bl              #0x12539dc  ; [package:flutter/src/painting/image_stream.dart] ImageStreamCompleter::removeListener
    // 0x1253988: ldur            x0, [fp, #-8]
    // 0x125398c: LoadField: r1 = r0->field_7
    //     0x125398c: ldur            w1, [x0, #7]
    // 0x1253990: DecompressPointer r1
    //     0x1253990: add             x1, x1, HEAP, lsl #32
    // 0x1253994: LoadField: r2 = r1->field_b
    //     0x1253994: ldur            w2, [x1, #0xb]
    // 0x1253998: cbnz            w2, #0x12539c4
    // 0x125399c: LoadField: r1 = r0->field_57
    //     0x125399c: ldur            w1, [x0, #0x57]
    // 0x12539a0: DecompressPointer r1
    //     0x12539a0: add             x1, x1, HEAP, lsl #32
    // 0x12539a4: cmp             w1, NULL
    // 0x12539a8: b.ne            #0x12539b4
    // 0x12539ac: mov             x1, x0
    // 0x12539b0: b               #0x12539bc
    // 0x12539b4: r0 = cancel()
    //     0x12539b4: bl              #0x7f29dc  ; [dart:isolate] _Timer::cancel
    // 0x12539b8: ldur            x1, [fp, #-8]
    // 0x12539bc: StoreField: r1->field_57 = rNULL
    //     0x12539bc: stur            NULL, [x1, #0x57]
    // 0x12539c0: r0 = __maybeDispose()
    //     0x12539c0: bl              #0x87c6d8  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::__maybeDispose
    // 0x12539c4: r0 = Null
    //     0x12539c4: mov             x0, NULL
    // 0x12539c8: LeaveFrame
    //     0x12539c8: mov             SP, fp
    //     0x12539cc: ldp             fp, lr, [SP], #0x10
    // 0x12539d0: ret
    //     0x12539d0: ret             
    // 0x12539d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12539d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12539d8: b               #0x1253980
  }
}
