// lib: , url: package:cached_network_image/src/image_provider/cached_network_image_provider.dart

// class id: 1048618, size: 0x8
class :: {
}

// class id: 3603, size: 0x34, field offset: 0xc
//   const constructor, 
class CachedNetworkImageProvider extends ImageProvider<dynamic> {

  static late BaseCacheManager defaultCacheManager; // offset: 0xf44

  _ toString(/* No info */) {
    // ** addr: 0x110adcc, size: 0xc0
    // 0x110adcc: EnterFrame
    //     0x110adcc: stp             fp, lr, [SP, #-0x10]!
    //     0x110add0: mov             fp, SP
    // 0x110add4: AllocStack(0x8)
    //     0x110add4: sub             SP, SP, #8
    // 0x110add8: CheckStackOverflow
    //     0x110add8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110addc: cmp             SP, x16
    //     0x110ade0: b.ls            #0x110ae68
    // 0x110ade4: r1 = Null
    //     0x110ade4: mov             x1, NULL
    // 0x110ade8: r2 = 10
    //     0x110ade8: mov             x2, #0xa
    // 0x110adec: r0 = AllocateArray()
    //     0x110adec: bl              #0x13df928  ; AllocateArrayStub
    // 0x110adf0: r16 = "CachedNetworkImageProvider(\""
    //     0x110adf0: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ee28] "CachedNetworkImageProvider(\""
    //     0x110adf4: ldr             x16, [x16, #0xe28]
    // 0x110adf8: StoreField: r0->field_f = r16
    //     0x110adf8: stur            w16, [x0, #0xf]
    // 0x110adfc: ldr             x1, [fp, #0x10]
    // 0x110ae00: LoadField: r2 = r1->field_f
    //     0x110ae00: ldur            w2, [x1, #0xf]
    // 0x110ae04: DecompressPointer r2
    //     0x110ae04: add             x2, x2, HEAP, lsl #32
    // 0x110ae08: StoreField: r0->field_13 = r2
    //     0x110ae08: stur            w2, [x0, #0x13]
    // 0x110ae0c: r16 = "\", scale: "
    //     0x110ae0c: add             x16, PP, #0x7e, lsl #12  ; [pp+0x7ee30] "\", scale: "
    //     0x110ae10: ldr             x16, [x16, #0xe30]
    // 0x110ae14: ArrayStore: r0[0] = r16  ; List_4
    //     0x110ae14: stur            w16, [x0, #0x17]
    // 0x110ae18: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x110ae18: ldur            d0, [x1, #0x17]
    // 0x110ae1c: r1 = inline_Allocate_Double()
    //     0x110ae1c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x110ae20: add             x1, x1, #0x10
    //     0x110ae24: cmp             x2, x1
    //     0x110ae28: b.ls            #0x110ae70
    //     0x110ae2c: str             x1, [THR, #0x60]  ; THR::top
    //     0x110ae30: sub             x1, x1, #0xf
    //     0x110ae34: mov             x2, #0xe19c
    //     0x110ae38: movk            x2, #3, lsl #16
    //     0x110ae3c: stur            x2, [x1, #-1]
    // 0x110ae40: dmb             ishst
    // 0x110ae44: StoreField: r1->field_7 = d0
    //     0x110ae44: stur            d0, [x1, #7]
    // 0x110ae48: StoreField: r0->field_1b = r1
    //     0x110ae48: stur            w1, [x0, #0x1b]
    // 0x110ae4c: r16 = ")"
    //     0x110ae4c: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0x110ae50: StoreField: r0->field_1f = r16
    //     0x110ae50: stur            w16, [x0, #0x1f]
    // 0x110ae54: str             x0, [SP]
    // 0x110ae58: r0 = _interpolate()
    //     0x110ae58: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x110ae5c: LeaveFrame
    //     0x110ae5c: mov             SP, fp
    //     0x110ae60: ldp             fp, lr, [SP], #0x10
    // 0x110ae64: ret
    //     0x110ae64: ret             
    // 0x110ae68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110ae68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110ae6c: b               #0x110ade4
    // 0x110ae70: SaveReg d0
    //     0x110ae70: str             q0, [SP, #-0x10]!
    // 0x110ae74: SaveReg r0
    //     0x110ae74: str             x0, [SP, #-8]!
    // 0x110ae78: r0 = AllocateDouble()
    //     0x110ae78: bl              #0x13df878  ; AllocateDoubleStub
    // 0x110ae7c: mov             x1, x0
    // 0x110ae80: RestoreReg r0
    //     0x110ae80: ldr             x0, [SP], #8
    // 0x110ae84: RestoreReg d0
    //     0x110ae84: ldr             q0, [SP], #0x10
    // 0x110ae88: b               #0x110ae44
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114924c, size: 0x60
    // 0x114924c: EnterFrame
    //     0x114924c: stp             fp, lr, [SP, #-0x10]!
    //     0x1149250: mov             fp, SP
    // 0x1149254: AllocStack(0x10)
    //     0x1149254: sub             SP, SP, #0x10
    // 0x1149258: CheckStackOverflow
    //     0x1149258: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114925c: cmp             SP, x16
    //     0x1149260: b.ls            #0x11492a4
    // 0x1149264: ldr             x0, [fp, #0x10]
    // 0x1149268: LoadField: r1 = r0->field_f
    //     0x1149268: ldur            w1, [x0, #0xf]
    // 0x114926c: DecompressPointer r1
    //     0x114926c: add             x1, x1, HEAP, lsl #32
    // 0x1149270: stp             NULL, NULL, [SP]
    // 0x1149274: r2 = 1.000000
    //     0x1149274: ldr             x2, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0x1149278: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x1149278: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x114927c: r0 = hash()
    //     0x114927c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x1149280: mov             x2, x0
    // 0x1149284: r0 = BoxInt64Instr(r2)
    //     0x1149284: sbfiz           x0, x2, #1, #0x1f
    //     0x1149288: cmp             x2, x0, asr #1
    //     0x114928c: b.eq            #0x1149298
    //     0x1149290: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1149294: stur            x2, [x0, #7]
    // 0x1149298: LeaveFrame
    //     0x1149298: mov             SP, fp
    //     0x114929c: ldp             fp, lr, [SP], #0x10
    // 0x11492a0: ret
    //     0x11492a0: ret             
    // 0x11492a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11492a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11492a8: b               #0x1149264
  }
  _ obtainKey(/* No info */) {
    // ** addr: 0x115a89c, size: 0x34
    // 0x115a89c: EnterFrame
    //     0x115a89c: stp             fp, lr, [SP, #-0x10]!
    //     0x115a8a0: mov             fp, SP
    // 0x115a8a4: AllocStack(0x8)
    //     0x115a8a4: sub             SP, SP, #8
    // 0x115a8a8: SetupParameters(CachedNetworkImageProvider this /* r1 => r0, fp-0x8 */)
    //     0x115a8a8: mov             x0, x1
    //     0x115a8ac: stur            x1, [fp, #-8]
    // 0x115a8b0: r1 = <CachedNetworkImageProvider>
    //     0x115a8b0: add             x1, PP, #0x18, lsl #12  ; [pp+0x180d8] TypeArguments: <CachedNetworkImageProvider>
    //     0x115a8b4: ldr             x1, [x1, #0xd8]
    // 0x115a8b8: r0 = SynchronousFuture()
    //     0x115a8b8: bl              #0xeb3f1c  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0x115a8bc: ldur            x1, [fp, #-8]
    // 0x115a8c0: StoreField: r0->field_b = r1
    //     0x115a8c0: stur            w1, [x0, #0xb]
    // 0x115a8c4: LeaveFrame
    //     0x115a8c4: mov             SP, fp
    //     0x115a8c8: ldp             fp, lr, [SP], #0x10
    // 0x115a8cc: ret
    //     0x115a8cc: ret             
  }
  _ loadImage(/* No info */) {
    // ** addr: 0x11861ac, size: 0x144
    // 0x11861ac: EnterFrame
    //     0x11861ac: stp             fp, lr, [SP, #-0x10]!
    //     0x11861b0: mov             fp, SP
    // 0x11861b4: AllocStack(0x28)
    //     0x11861b4: sub             SP, SP, #0x28
    // 0x11861b8: SetupParameters(CachedNetworkImageProvider this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */)
    //     0x11861b8: mov             x5, x3
    //     0x11861bc: stur            x1, [fp, #-8]
    //     0x11861c0: stur            x2, [fp, #-0x10]
    //     0x11861c4: stur            x3, [fp, #-0x18]
    // 0x11861c8: CheckStackOverflow
    //     0x11861c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11861cc: cmp             SP, x16
    //     0x11861d0: b.ls            #0x11862e8
    // 0x11861d4: r1 = 2
    //     0x11861d4: mov             x1, #2
    // 0x11861d8: r0 = AllocateContext()
    //     0x11861d8: bl              #0x13de838  ; AllocateContextStub
    // 0x11861dc: mov             x2, x0
    // 0x11861e0: ldur            x0, [fp, #-8]
    // 0x11861e4: stur            x2, [fp, #-0x20]
    // 0x11861e8: StoreField: r2->field_f = r0
    //     0x11861e8: stur            w0, [x2, #0xf]
    // 0x11861ec: ldur            x1, [fp, #-0x10]
    // 0x11861f0: StoreField: r2->field_13 = r1
    //     0x11861f0: stur            w1, [x2, #0x13]
    // 0x11861f4: r1 = <ImageChunkEvent>
    //     0x11861f4: add             x1, PP, #0x94, lsl #12  ; [pp+0x94cd8] TypeArguments: <ImageChunkEvent>
    //     0x11861f8: ldr             x1, [x1, #0xcd8]
    // 0x11861fc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x11861fc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x1186200: r0 = StreamController()
    //     0x1186200: bl              #0x811820  ; [dart:async] StreamController::StreamController
    // 0x1186204: mov             x4, x0
    // 0x1186208: ldur            x0, [fp, #-0x20]
    // 0x118620c: stur            x4, [fp, #-0x10]
    // 0x1186210: LoadField: r2 = r0->field_13
    //     0x1186210: ldur            w2, [x0, #0x13]
    // 0x1186214: DecompressPointer r2
    //     0x1186214: add             x2, x2, HEAP, lsl #32
    // 0x1186218: ldur            x1, [fp, #-8]
    // 0x118621c: mov             x3, x4
    // 0x1186220: ldur            x5, [fp, #-0x18]
    // 0x1186224: r0 = _loadImageAsync()
    //     0x1186224: bl              #0x1186a8c  ; [package:cached_network_image/src/image_provider/cached_network_image_provider.dart] CachedNetworkImageProvider::_loadImageAsync
    // 0x1186228: mov             x2, x0
    // 0x118622c: ldur            x0, [fp, #-0x10]
    // 0x1186230: stur            x2, [fp, #-0x18]
    // 0x1186234: LoadField: r1 = r0->field_7
    //     0x1186234: ldur            w1, [x0, #7]
    // 0x1186238: DecompressPointer r1
    //     0x1186238: add             x1, x1, HEAP, lsl #32
    // 0x118623c: r0 = _ControllerStream()
    //     0x118623c: bl              #0x810928  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x10)
    // 0x1186240: mov             x3, x0
    // 0x1186244: ldur            x0, [fp, #-0x10]
    // 0x1186248: stur            x3, [fp, #-0x28]
    // 0x118624c: StoreField: r3->field_b = r0
    //     0x118624c: stur            w0, [x3, #0xb]
    // 0x1186250: ldur            x2, [fp, #-0x20]
    // 0x1186254: r1 = Function '<anonymous closure>':.
    //     0x1186254: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e40] AnonymousClosure: (0x1191838), in [package:cached_network_image/src/image_provider/cached_network_image_provider.dart] CachedNetworkImageProvider::loadImage (0x11861ac)
    //     0x1186258: ldr             x1, [x1, #0xe40]
    // 0x118625c: r0 = AllocateClosure()
    //     0x118625c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1186260: stur            x0, [fp, #-0x10]
    // 0x1186264: r0 = MultiImageStreamCompleter()
    //     0x1186264: bl              #0x1186a80  ; AllocateMultiImageStreamCompleterStub -> MultiImageStreamCompleter (size=0x74)
    // 0x1186268: mov             x1, x0
    // 0x118626c: ldur            x2, [fp, #-0x28]
    // 0x1186270: ldur            x3, [fp, #-0x18]
    // 0x1186274: ldur            x5, [fp, #-0x10]
    // 0x1186278: stur            x0, [fp, #-0x10]
    // 0x118627c: r0 = MultiImageStreamCompleter()
    //     0x118627c: bl              #0x11862f0  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::MultiImageStreamCompleter
    // 0x1186280: ldur            x0, [fp, #-8]
    // 0x1186284: LoadField: r1 = r0->field_1f
    //     0x1186284: ldur            w1, [x0, #0x1f]
    // 0x1186288: DecompressPointer r1
    //     0x1186288: add             x1, x1, HEAP, lsl #32
    // 0x118628c: cmp             w1, NULL
    // 0x1186290: b.eq            #0x11862d8
    // 0x1186294: r0 = ImageStreamListener()
    //     0x1186294: bl              #0xd097b8  ; AllocateImageStreamListenerStub -> ImageStreamListener (size=0x14)
    // 0x1186298: r1 = Function '<anonymous closure>':.
    //     0x1186298: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e48] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0x118629c: ldr             x1, [x1, #0xe48]
    // 0x11862a0: r2 = Null
    //     0x11862a0: mov             x2, NULL
    // 0x11862a4: stur            x0, [fp, #-8]
    // 0x11862a8: r0 = AllocateClosure()
    //     0x11862a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11862ac: mov             x1, x0
    // 0x11862b0: ldur            x0, [fp, #-8]
    // 0x11862b4: StoreField: r0->field_7 = r1
    //     0x11862b4: stur            w1, [x0, #7]
    // 0x11862b8: ldur            x2, [fp, #-0x20]
    // 0x11862bc: r1 = Function '<anonymous closure>':.
    //     0x11862bc: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e50] AnonymousClosure: (0x11917cc), in [package:cached_network_image/src/image_provider/cached_network_image_provider.dart] CachedNetworkImageProvider::loadImage (0x11861ac)
    //     0x11862c0: ldr             x1, [x1, #0xe50]
    // 0x11862c4: r0 = AllocateClosure()
    //     0x11862c4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11862c8: ldur            x2, [fp, #-8]
    // 0x11862cc: StoreField: r2->field_f = r0
    //     0x11862cc: stur            w0, [x2, #0xf]
    // 0x11862d0: ldur            x1, [fp, #-0x10]
    // 0x11862d4: r0 = addListener()
    //     0x11862d4: bl              #0x124a2dc  ; [package:cached_network_image/src/image_provider/multi_image_stream_completer.dart] MultiImageStreamCompleter::addListener
    // 0x11862d8: ldur            x0, [fp, #-0x10]
    // 0x11862dc: LeaveFrame
    //     0x11862dc: mov             SP, fp
    //     0x11862e0: ldp             fp, lr, [SP], #0x10
    // 0x11862e4: ret
    //     0x11862e4: ret             
    // 0x11862e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11862e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11862ec: b               #0x11861d4
  }
  _ _loadImageAsync(/* No info */) {
    // ** addr: 0x1186a8c, size: 0xbc
    // 0x1186a8c: EnterFrame
    //     0x1186a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x1186a90: mov             fp, SP
    // 0x1186a94: AllocStack(0x28)
    //     0x1186a94: sub             SP, SP, #0x28
    // 0x1186a98: SetupParameters(CachedNetworkImageProvider this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x1186a98: stur            x1, [fp, #-8]
    //     0x1186a9c: stur            x2, [fp, #-0x10]
    //     0x1186aa0: stur            x3, [fp, #-0x18]
    //     0x1186aa4: stur            x5, [fp, #-0x20]
    // 0x1186aa8: CheckStackOverflow
    //     0x1186aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1186aac: cmp             SP, x16
    //     0x1186ab0: b.ls            #0x1186b40
    // 0x1186ab4: r1 = 1
    //     0x1186ab4: mov             x1, #1
    // 0x1186ab8: r0 = AllocateContext()
    //     0x1186ab8: bl              #0x13de838  ; AllocateContextStub
    // 0x1186abc: mov             x1, x0
    // 0x1186ac0: ldur            x0, [fp, #-0x10]
    // 0x1186ac4: stur            x1, [fp, #-0x28]
    // 0x1186ac8: StoreField: r1->field_f = r0
    //     0x1186ac8: stur            w0, [x1, #0xf]
    // 0x1186acc: ldur            x0, [fp, #-8]
    // 0x1186ad0: LoadField: r2 = r0->field_f
    //     0x1186ad0: ldur            w2, [x0, #0xf]
    // 0x1186ad4: DecompressPointer r2
    //     0x1186ad4: add             x2, x2, HEAP, lsl #32
    // 0x1186ad8: stur            x2, [fp, #-0x10]
    // 0x1186adc: r0 = LoadStaticField(0xf44)
    //     0x1186adc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x1186ae0: ldr             x0, [x0, #0x1e88]
    // 0x1186ae4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x1186ae8: cmp             w0, w16
    // 0x1186aec: b.ne            #0x1186afc
    // 0x1186af0: r2 = defaultCacheManager
    //     0x1186af0: add             x2, PP, #0x94, lsl #12  ; [pp+0x94e70] Field <CachedNetworkImageProvider.defaultCacheManager>: static late (offset: 0xf44)
    //     0x1186af4: ldr             x2, [x2, #0xe70]
    // 0x1186af8: r0 = InitLateStaticField()
    //     0x1186af8: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x1186afc: stur            x0, [fp, #-8]
    // 0x1186b00: r0 = ImageLoader()
    //     0x1186b00: bl              #0x118b574  ; AllocateImageLoaderStub -> ImageLoader (size=0x8)
    // 0x1186b04: ldur            x2, [fp, #-0x28]
    // 0x1186b08: r1 = Function '<anonymous closure>':.
    //     0x1186b08: add             x1, PP, #0x94, lsl #12  ; [pp+0x94e78] AnonymousClosure: (0x118b580), in [package:cached_network_image/src/image_provider/cached_network_image_provider.dart] CachedNetworkImageProvider::_loadImageAsync (0x1186a8c)
    //     0x1186b0c: ldr             x1, [x1, #0xe78]
    // 0x1186b10: stur            x0, [fp, #-0x28]
    // 0x1186b14: r0 = AllocateClosure()
    //     0x1186b14: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1186b18: ldur            x1, [fp, #-0x28]
    // 0x1186b1c: ldur            x2, [fp, #-0x10]
    // 0x1186b20: ldur            x3, [fp, #-0x18]
    // 0x1186b24: ldur            x5, [fp, #-0x20]
    // 0x1186b28: ldur            x6, [fp, #-8]
    // 0x1186b2c: mov             x7, x0
    // 0x1186b30: r0 = loadImageAsync()
    //     0x1186b30: bl              #0x1186b48  ; [package:cached_network_image/src/image_provider/_image_loader.dart] ImageLoader::loadImageAsync
    // 0x1186b34: LeaveFrame
    //     0x1186b34: mov             SP, fp
    //     0x1186b38: ldp             fp, lr, [SP], #0x10
    // 0x1186b3c: ret
    //     0x1186b3c: ret             
    // 0x1186b40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1186b40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1186b44: b               #0x1186ab4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x118b580, size: 0x78
    // 0x118b580: EnterFrame
    //     0x118b580: stp             fp, lr, [SP, #-0x10]!
    //     0x118b584: mov             fp, SP
    // 0x118b588: ldr             x0, [fp, #0x10]
    // 0x118b58c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x118b58c: ldur            w1, [x0, #0x17]
    // 0x118b590: DecompressPointer r1
    //     0x118b590: add             x1, x1, HEAP, lsl #32
    // 0x118b594: CheckStackOverflow
    //     0x118b594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x118b598: cmp             SP, x16
    //     0x118b59c: b.ls            #0x118b5e4
    // 0x118b5a0: r0 = LoadStaticField(0x780)
    //     0x118b5a0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x118b5a4: ldr             x0, [x0, #0xf00]
    // 0x118b5a8: cmp             w0, NULL
    // 0x118b5ac: b.eq            #0x118b5ec
    // 0x118b5b0: LoadField: r2 = r0->field_ab
    //     0x118b5b0: ldur            w2, [x0, #0xab]
    // 0x118b5b4: DecompressPointer r2
    //     0x118b5b4: add             x2, x2, HEAP, lsl #32
    // 0x118b5b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x118b5bc: cmp             w2, w16
    // 0x118b5c0: b.eq            #0x118b5f0
    // 0x118b5c4: LoadField: r0 = r1->field_f
    //     0x118b5c4: ldur            w0, [x1, #0xf]
    // 0x118b5c8: DecompressPointer r0
    //     0x118b5c8: add             x0, x0, HEAP, lsl #32
    // 0x118b5cc: mov             x1, x2
    // 0x118b5d0: mov             x2, x0
    // 0x118b5d4: r0 = evict()
    //     0x118b5d4: bl              #0x118b5f8  ; [package:flutter/src/painting/image_cache.dart] ImageCache::evict
    // 0x118b5d8: LeaveFrame
    //     0x118b5d8: mov             SP, fp
    //     0x118b5dc: ldp             fp, lr, [SP], #0x10
    // 0x118b5e0: ret
    //     0x118b5e0: ret             
    // 0x118b5e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118b5e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x118b5e8: b               #0x118b5a0
    // 0x118b5ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x118b5ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x118b5f0: r9 = _imageCache
    //     0x118b5f0: ldr             x9, [PP, #0x3318]  ; [pp+0x3318] Field <_MixinApplication205&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding@18353248._imageCache@118047248>: late (offset: 0xac)
    // 0x118b5f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x118b5f4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static BaseCacheManager defaultCacheManager() {
    // ** addr: 0x118b6f0, size: 0x48
    // 0x118b6f0: EnterFrame
    //     0x118b6f0: stp             fp, lr, [SP, #-0x10]!
    //     0x118b6f4: mov             fp, SP
    // 0x118b6f8: CheckStackOverflow
    //     0x118b6f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x118b6fc: cmp             SP, x16
    //     0x118b700: b.ls            #0x118b730
    // 0x118b704: r0 = LoadStaticField(0xf54)
    //     0x118b704: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x118b708: ldr             x0, [x0, #0x1ea8]
    // 0x118b70c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x118b710: cmp             w0, w16
    // 0x118b714: b.ne            #0x118b724
    // 0x118b718: r2 = _instance
    //     0x118b718: add             x2, PP, #0x95, lsl #12  ; [pp+0x95100] Field <DefaultCacheManager._instance@1199037955>: static late final (offset: 0xf54)
    //     0x118b71c: ldr             x2, [x2, #0x100]
    // 0x118b720: r0 = InitLateFinalStaticField()
    //     0x118b720: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x118b724: LeaveFrame
    //     0x118b724: mov             SP, fp
    //     0x118b728: ldp             fp, lr, [SP], #0x10
    // 0x118b72c: ret
    //     0x118b72c: ret             
    // 0x118b730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x118b730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x118b734: b               #0x118b704
  }
  [closure] void <anonymous closure>(dynamic, Object, StackTrace?) {
    // ** addr: 0x11917cc, size: 0x6c
    // 0x11917cc: EnterFrame
    //     0x11917cc: stp             fp, lr, [SP, #-0x10]!
    //     0x11917d0: mov             fp, SP
    // 0x11917d4: AllocStack(0x10)
    //     0x11917d4: sub             SP, SP, #0x10
    // 0x11917d8: SetupParameters([dynamic _ /* r0 */])
    //     0x11917d8: ldr             x0, [fp, #0x20]
    //     0x11917dc: ldur            w1, [x0, #0x17]
    //     0x11917e0: add             x1, x1, HEAP, lsl #32
    // 0x11917e4: CheckStackOverflow
    //     0x11917e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11917e8: cmp             SP, x16
    //     0x11917ec: b.ls            #0x1191830
    // 0x11917f0: LoadField: r0 = r1->field_f
    //     0x11917f0: ldur            w0, [x1, #0xf]
    // 0x11917f4: DecompressPointer r0
    //     0x11917f4: add             x0, x0, HEAP, lsl #32
    // 0x11917f8: LoadField: r1 = r0->field_1f
    //     0x11917f8: ldur            w1, [x0, #0x1f]
    // 0x11917fc: DecompressPointer r1
    //     0x11917fc: add             x1, x1, HEAP, lsl #32
    // 0x1191800: cmp             w1, NULL
    // 0x1191804: b.eq            #0x1191820
    // 0x1191808: ldr             x16, [fp, #0x18]
    // 0x119180c: stp             x16, x1, [SP]
    // 0x1191810: mov             x0, x1
    // 0x1191814: ClosureCall
    //     0x1191814: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x1191818: ldur            x2, [x0, #0x1f]
    //     0x119181c: blr             x2
    // 0x1191820: r0 = Null
    //     0x1191820: mov             x0, NULL
    // 0x1191824: LeaveFrame
    //     0x1191824: mov             SP, fp
    //     0x1191828: ldp             fp, lr, [SP], #0x10
    // 0x119182c: ret
    //     0x119182c: ret             
    // 0x1191830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1191830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1191834: b               #0x11917f0
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0x1191838, size: 0xf8
    // 0x1191838: EnterFrame
    //     0x1191838: stp             fp, lr, [SP, #-0x10]!
    //     0x119183c: mov             fp, SP
    // 0x1191840: AllocStack(0x18)
    //     0x1191840: sub             SP, SP, #0x18
    // 0x1191844: SetupParameters([dynamic _ /* r0 */])
    //     0x1191844: ldr             x0, [fp, #0x10]
    //     0x1191848: ldur            w2, [x0, #0x17]
    //     0x119184c: add             x2, x2, HEAP, lsl #32
    //     0x1191850: stur            x2, [fp, #-0x10]
    // 0x1191854: LoadField: r0 = r2->field_f
    //     0x1191854: ldur            w0, [x2, #0xf]
    // 0x1191858: DecompressPointer r0
    //     0x1191858: add             x0, x0, HEAP, lsl #32
    // 0x119185c: stur            x0, [fp, #-8]
    // 0x1191860: r1 = <ImageProvider<Object>>
    //     0x1191860: add             x1, PP, #0x94, lsl #12  ; [pp+0x94cf0] TypeArguments: <ImageProvider<Object>>
    //     0x1191864: ldr             x1, [x1, #0xcf0]
    // 0x1191868: r0 = DiagnosticsProperty()
    //     0x1191868: bl              #0x82bc68  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x2c)
    // 0x119186c: mov             x2, x0
    // 0x1191870: r0 = Instance__NoDefaultValue
    //     0x1191870: ldr             x0, [PP, #0xca0]  ; [pp+0xca0] Obj!_NoDefaultValue@129f291
    // 0x1191874: stur            x2, [fp, #-0x18]
    // 0x1191878: StoreField: r2->field_23 = r0
    //     0x1191878: stur            w0, [x2, #0x23]
    // 0x119187c: r3 = false
    //     0x119187c: add             x3, NULL, #0x30  ; false
    // 0x1191880: StoreField: r2->field_13 = r3
    //     0x1191880: stur            w3, [x2, #0x13]
    // 0x1191884: r4 = true
    //     0x1191884: add             x4, NULL, #0x20  ; true
    // 0x1191888: StoreField: r2->field_1b = r4
    //     0x1191888: stur            w4, [x2, #0x1b]
    // 0x119188c: ldur            x1, [fp, #-8]
    // 0x1191890: ArrayStore: r2[0] = r1  ; List_4
    //     0x1191890: stur            w1, [x2, #0x17]
    // 0x1191894: r5 = Instance_DiagnosticLevel
    //     0x1191894: ldr             x5, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x1191898: StoreField: r2->field_27 = r5
    //     0x1191898: stur            w5, [x2, #0x27]
    // 0x119189c: ldur            x1, [fp, #-0x10]
    // 0x11918a0: LoadField: r6 = r1->field_13
    //     0x11918a0: ldur            w6, [x1, #0x13]
    // 0x11918a4: DecompressPointer r6
    //     0x11918a4: add             x6, x6, HEAP, lsl #32
    // 0x11918a8: stur            x6, [fp, #-8]
    // 0x11918ac: r1 = <CachedNetworkImageProvider>
    //     0x11918ac: add             x1, PP, #0x18, lsl #12  ; [pp+0x180d8] TypeArguments: <CachedNetworkImageProvider>
    //     0x11918b0: ldr             x1, [x1, #0xd8]
    // 0x11918b4: r0 = DiagnosticsProperty()
    //     0x11918b4: bl              #0x82bc68  ; AllocateDiagnosticsPropertyStub -> DiagnosticsProperty<X0> (size=0x2c)
    // 0x11918b8: mov             x3, x0
    // 0x11918bc: r0 = Instance__NoDefaultValue
    //     0x11918bc: ldr             x0, [PP, #0xca0]  ; [pp+0xca0] Obj!_NoDefaultValue@129f291
    // 0x11918c0: stur            x3, [fp, #-0x10]
    // 0x11918c4: StoreField: r3->field_23 = r0
    //     0x11918c4: stur            w0, [x3, #0x23]
    // 0x11918c8: r0 = false
    //     0x11918c8: add             x0, NULL, #0x30  ; false
    // 0x11918cc: StoreField: r3->field_13 = r0
    //     0x11918cc: stur            w0, [x3, #0x13]
    // 0x11918d0: r0 = true
    //     0x11918d0: add             x0, NULL, #0x20  ; true
    // 0x11918d4: StoreField: r3->field_1b = r0
    //     0x11918d4: stur            w0, [x3, #0x1b]
    // 0x11918d8: ldur            x0, [fp, #-8]
    // 0x11918dc: ArrayStore: r3[0] = r0  ; List_4
    //     0x11918dc: stur            w0, [x3, #0x17]
    // 0x11918e0: r0 = Instance_DiagnosticLevel
    //     0x11918e0: ldr             x0, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x11918e4: StoreField: r3->field_27 = r0
    //     0x11918e4: stur            w0, [x3, #0x27]
    // 0x11918e8: r1 = Null
    //     0x11918e8: mov             x1, NULL
    // 0x11918ec: r2 = 4
    //     0x11918ec: mov             x2, #4
    // 0x11918f0: r0 = AllocateArray()
    //     0x11918f0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11918f4: mov             x2, x0
    // 0x11918f8: ldur            x0, [fp, #-0x18]
    // 0x11918fc: stur            x2, [fp, #-8]
    // 0x1191900: StoreField: r2->field_f = r0
    //     0x1191900: stur            w0, [x2, #0xf]
    // 0x1191904: ldur            x0, [fp, #-0x10]
    // 0x1191908: StoreField: r2->field_13 = r0
    //     0x1191908: stur            w0, [x2, #0x13]
    // 0x119190c: r1 = <DiagnosticsNode>
    //     0x119190c: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x1191910: r0 = AllocateGrowableArray()
    //     0x1191910: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1191914: ldur            x1, [fp, #-8]
    // 0x1191918: StoreField: r0->field_f = r1
    //     0x1191918: stur            w1, [x0, #0xf]
    // 0x119191c: r1 = 4
    //     0x119191c: mov             x1, #4
    // 0x1191920: StoreField: r0->field_b = r1
    //     0x1191920: stur            w1, [x0, #0xb]
    // 0x1191924: LeaveFrame
    //     0x1191924: mov             SP, fp
    //     0x1191928: ldp             fp, lr, [SP], #0x10
    // 0x119192c: ret
    //     0x119192c: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x129215c, size: 0xbc
    // 0x129215c: EnterFrame
    //     0x129215c: stp             fp, lr, [SP, #-0x10]!
    //     0x1292160: mov             fp, SP
    // 0x1292164: AllocStack(0x10)
    //     0x1292164: sub             SP, SP, #0x10
    // 0x1292168: CheckStackOverflow
    //     0x1292168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129216c: cmp             SP, x16
    //     0x1292170: b.ls            #0x1292210
    // 0x1292174: ldr             x0, [fp, #0x10]
    // 0x1292178: cmp             w0, NULL
    // 0x129217c: b.ne            #0x1292190
    // 0x1292180: r0 = false
    //     0x1292180: add             x0, NULL, #0x30  ; false
    // 0x1292184: LeaveFrame
    //     0x1292184: mov             SP, fp
    //     0x1292188: ldp             fp, lr, [SP], #0x10
    // 0x129218c: ret
    //     0x129218c: ret             
    // 0x1292190: r1 = 60
    //     0x1292190: mov             x1, #0x3c
    // 0x1292194: branchIfSmi(r0, 0x12921a0)
    //     0x1292194: tbz             w0, #0, #0x12921a0
    // 0x1292198: r1 = LoadClassIdInstr(r0)
    //     0x1292198: ldur            x1, [x0, #-1]
    //     0x129219c: ubfx            x1, x1, #0xc, #0x14
    // 0x12921a0: sub             x16, x1, #0xe13
    // 0x12921a4: cmp             x16, #1
    // 0x12921a8: b.hi            #0x1292200
    // 0x12921ac: ldr             x1, [fp, #0x18]
    // 0x12921b0: LoadField: r2 = r1->field_f
    //     0x12921b0: ldur            w2, [x1, #0xf]
    // 0x12921b4: DecompressPointer r2
    //     0x12921b4: add             x2, x2, HEAP, lsl #32
    // 0x12921b8: LoadField: r1 = r0->field_f
    //     0x12921b8: ldur            w1, [x0, #0xf]
    // 0x12921bc: DecompressPointer r1
    //     0x12921bc: add             x1, x1, HEAP, lsl #32
    // 0x12921c0: r0 = LoadClassIdInstr(r2)
    //     0x12921c0: ldur            x0, [x2, #-1]
    //     0x12921c4: ubfx            x0, x0, #0xc, #0x14
    // 0x12921c8: stp             x1, x2, [SP]
    // 0x12921cc: mov             lr, x0
    // 0x12921d0: ldr             lr, [x21, lr, lsl #3]
    // 0x12921d4: blr             lr
    // 0x12921d8: tbnz            w0, #4, #0x12921f0
    // 0x12921dc: d0 = 1.000000
    //     0x12921dc: fmov            d0, #1.00000000
    // 0x12921e0: fcmp            d0, d0
    // 0x12921e4: b.ne            #0x12921f0
    // 0x12921e8: r0 = true
    //     0x12921e8: add             x0, NULL, #0x20  ; true
    // 0x12921ec: b               #0x12921f4
    // 0x12921f0: r0 = false
    //     0x12921f0: add             x0, NULL, #0x30  ; false
    // 0x12921f4: LeaveFrame
    //     0x12921f4: mov             SP, fp
    //     0x12921f8: ldp             fp, lr, [SP], #0x10
    // 0x12921fc: ret
    //     0x12921fc: ret             
    // 0x1292200: r0 = false
    //     0x1292200: add             x0, NULL, #0x30  ; false
    // 0x1292204: LeaveFrame
    //     0x1292204: mov             SP, fp
    //     0x1292208: ldp             fp, lr, [SP], #0x10
    // 0x129220c: ret
    //     0x129220c: ret             
    // 0x1292210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1292210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1292214: b               #0x1292174
  }
}
