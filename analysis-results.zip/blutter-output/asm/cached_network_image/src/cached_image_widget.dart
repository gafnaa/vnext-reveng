// lib: , url: package:cached_network_image/src/cached_image_widget.dart

// class id: 1048616, size: 0x8
class :: {
}

// class id: 6219, size: 0x68, field offset: 0xc
class CachedNetworkImage extends StatelessWidget {

  [closure] Container <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0xe47314, size: 0x44
    // 0xe47314: EnterFrame
    //     0xe47314: stp             fp, lr, [SP, #-0x10]!
    //     0xe47318: mov             fp, SP
    // 0xe4731c: AllocStack(0x8)
    //     0xe4731c: sub             SP, SP, #8
    // 0xe47320: CheckStackOverflow
    //     0xe47320: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe47324: cmp             SP, x16
    //     0xe47328: b.ls            #0xe47350
    // 0xe4732c: r0 = Container()
    //     0xe4732c: bl              #0x8a5af8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xe47330: mov             x1, x0
    // 0xe47334: stur            x0, [fp, #-8]
    // 0xe47338: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xe47338: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xe4733c: r0 = Container()
    //     0xe4733c: bl              #0x8a54e0  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xe47340: ldur            x0, [fp, #-8]
    // 0xe47344: LeaveFrame
    //     0xe47344: mov             SP, fp
    //     0xe47348: ldp             fp, lr, [SP], #0x10
    // 0xe4734c: ret
    //     0xe4734c: ret             
    // 0xe47350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe47350: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe47354: b               #0xe4732c
  }
  [closure] Widget _octoErrorBuilder(dynamic, BuildContext, Object, StackTrace?) {
    // ** addr: 0xe5a100, size: 0x44
    // 0xe5a100: EnterFrame
    //     0xe5a100: stp             fp, lr, [SP, #-0x10]!
    //     0xe5a104: mov             fp, SP
    // 0xe5a108: ldr             x0, [fp, #0x28]
    // 0xe5a10c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe5a10c: ldur            w1, [x0, #0x17]
    // 0xe5a110: DecompressPointer r1
    //     0xe5a110: add             x1, x1, HEAP, lsl #32
    // 0xe5a114: CheckStackOverflow
    //     0xe5a114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe5a118: cmp             SP, x16
    //     0xe5a11c: b.ls            #0xe5a13c
    // 0xe5a120: ldr             x2, [fp, #0x20]
    // 0xe5a124: ldr             x3, [fp, #0x18]
    // 0xe5a128: ldr             x5, [fp, #0x10]
    // 0xe5a12c: r0 = _octoErrorBuilder()
    //     0xe5a12c: bl              #0xe5a144  ; [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::_octoErrorBuilder
    // 0xe5a130: LeaveFrame
    //     0xe5a130: mov             SP, fp
    //     0xe5a134: ldp             fp, lr, [SP], #0x10
    // 0xe5a138: ret
    //     0xe5a138: ret             
    // 0xe5a13c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe5a13c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe5a140: b               #0xe5a120
  }
  _ _octoErrorBuilder(/* No info */) {
    // ** addr: 0xe5a144, size: 0x5c
    // 0xe5a144: EnterFrame
    //     0xe5a144: stp             fp, lr, [SP, #-0x10]!
    //     0xe5a148: mov             fp, SP
    // 0xe5a14c: AllocStack(0x20)
    //     0xe5a14c: sub             SP, SP, #0x20
    // 0xe5a150: CheckStackOverflow
    //     0xe5a150: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe5a154: cmp             SP, x16
    //     0xe5a158: b.ls            #0xe5a194
    // 0xe5a15c: LoadField: r0 = r1->field_1f
    //     0xe5a15c: ldur            w0, [x1, #0x1f]
    // 0xe5a160: DecompressPointer r0
    //     0xe5a160: add             x0, x0, HEAP, lsl #32
    // 0xe5a164: cmp             w0, NULL
    // 0xe5a168: b.eq            #0xe5a19c
    // 0xe5a16c: LoadField: r4 = r1->field_f
    //     0xe5a16c: ldur            w4, [x1, #0xf]
    // 0xe5a170: DecompressPointer r4
    //     0xe5a170: add             x4, x4, HEAP, lsl #32
    // 0xe5a174: stp             x2, x0, [SP, #0x10]
    // 0xe5a178: stp             x3, x4, [SP]
    // 0xe5a17c: ClosureCall
    //     0xe5a17c: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xe5a180: ldur            x2, [x0, #0x1f]
    //     0xe5a184: blr             x2
    // 0xe5a188: LeaveFrame
    //     0xe5a188: mov             SP, fp
    //     0xe5a18c: ldp             fp, lr, [SP], #0x10
    // 0xe5a190: ret
    //     0xe5a190: ret             
    // 0xe5a194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe5a194: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe5a198: b               #0xe5a15c
    // 0xe5a19c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe5a19c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _octoImageBuilder(dynamic, BuildContext, Widget) {
    // ** addr: 0xe5a4e0, size: 0x40
    // 0xe5a4e0: EnterFrame
    //     0xe5a4e0: stp             fp, lr, [SP, #-0x10]!
    //     0xe5a4e4: mov             fp, SP
    // 0xe5a4e8: ldr             x0, [fp, #0x20]
    // 0xe5a4ec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe5a4ec: ldur            w1, [x0, #0x17]
    // 0xe5a4f0: DecompressPointer r1
    //     0xe5a4f0: add             x1, x1, HEAP, lsl #32
    // 0xe5a4f4: CheckStackOverflow
    //     0xe5a4f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe5a4f8: cmp             SP, x16
    //     0xe5a4fc: b.ls            #0xe5a518
    // 0xe5a500: ldr             x2, [fp, #0x18]
    // 0xe5a504: ldr             x3, [fp, #0x10]
    // 0xe5a508: r0 = _octoImageBuilder()
    //     0xe5a508: bl              #0xe5a520  ; [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::_octoImageBuilder
    // 0xe5a50c: LeaveFrame
    //     0xe5a50c: mov             SP, fp
    //     0xe5a510: ldp             fp, lr, [SP], #0x10
    // 0xe5a514: ret
    //     0xe5a514: ret             
    // 0xe5a518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe5a518: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe5a51c: b               #0xe5a500
  }
  _ _octoImageBuilder(/* No info */) {
    // ** addr: 0xe5a520, size: 0x5c
    // 0xe5a520: EnterFrame
    //     0xe5a520: stp             fp, lr, [SP, #-0x10]!
    //     0xe5a524: mov             fp, SP
    // 0xe5a528: AllocStack(0x18)
    //     0xe5a528: sub             SP, SP, #0x18
    // 0xe5a52c: CheckStackOverflow
    //     0xe5a52c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe5a530: cmp             SP, x16
    //     0xe5a534: b.ls            #0xe5a570
    // 0xe5a538: LoadField: r0 = r1->field_13
    //     0xe5a538: ldur            w0, [x1, #0x13]
    // 0xe5a53c: DecompressPointer r0
    //     0xe5a53c: add             x0, x0, HEAP, lsl #32
    // 0xe5a540: cmp             w0, NULL
    // 0xe5a544: b.eq            #0xe5a578
    // 0xe5a548: LoadField: r3 = r1->field_b
    //     0xe5a548: ldur            w3, [x1, #0xb]
    // 0xe5a54c: DecompressPointer r3
    //     0xe5a54c: add             x3, x3, HEAP, lsl #32
    // 0xe5a550: stp             x2, x0, [SP, #8]
    // 0xe5a554: str             x3, [SP]
    // 0xe5a558: ClosureCall
    //     0xe5a558: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xe5a55c: ldur            x2, [x0, #0x1f]
    //     0xe5a560: blr             x2
    // 0xe5a564: LeaveFrame
    //     0xe5a564: mov             SP, fp
    //     0xe5a568: ldp             fp, lr, [SP], #0x10
    // 0xe5a56c: ret
    //     0xe5a56c: ret             
    // 0xe5a570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe5a570: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe5a574: b               #0xe5a538
    // 0xe5a578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe5a578: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _octoProgressIndicatorBuilder(dynamic, BuildContext, ImageChunkEvent?) {
    // ** addr: 0xe5a80c, size: 0x40
    // 0xe5a80c: EnterFrame
    //     0xe5a80c: stp             fp, lr, [SP, #-0x10]!
    //     0xe5a810: mov             fp, SP
    // 0xe5a814: ldr             x0, [fp, #0x20]
    // 0xe5a818: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xe5a818: ldur            w1, [x0, #0x17]
    // 0xe5a81c: DecompressPointer r1
    //     0xe5a81c: add             x1, x1, HEAP, lsl #32
    // 0xe5a820: CheckStackOverflow
    //     0xe5a820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe5a824: cmp             SP, x16
    //     0xe5a828: b.ls            #0xe5a844
    // 0xe5a82c: ldr             x2, [fp, #0x18]
    // 0xe5a830: ldr             x3, [fp, #0x10]
    // 0xe5a834: r0 = _octoProgressIndicatorBuilder()
    //     0xe5a834: bl              #0xe5a84c  ; [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::_octoProgressIndicatorBuilder
    // 0xe5a838: LeaveFrame
    //     0xe5a838: mov             SP, fp
    //     0xe5a83c: ldp             fp, lr, [SP], #0x10
    // 0xe5a840: ret
    //     0xe5a840: ret             
    // 0xe5a844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe5a844: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe5a848: b               #0xe5a82c
  }
  _ _octoProgressIndicatorBuilder(/* No info */) {
    // ** addr: 0xe5a84c, size: 0xc0
    // 0xe5a84c: EnterFrame
    //     0xe5a84c: stp             fp, lr, [SP, #-0x10]!
    //     0xe5a850: mov             fp, SP
    // 0xe5a854: AllocStack(0x48)
    //     0xe5a854: sub             SP, SP, #0x48
    // 0xe5a858: SetupParameters(dynamic _ /* r2 => r2, fp-0x28 */)
    //     0xe5a858: stur            x2, [fp, #-0x28]
    // 0xe5a85c: CheckStackOverflow
    //     0xe5a85c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xe5a860: cmp             SP, x16
    //     0xe5a864: b.ls            #0xe5a900
    // 0xe5a868: cmp             w3, NULL
    // 0xe5a86c: b.eq            #0xe5a888
    // 0xe5a870: LoadField: r0 = r3->field_f
    //     0xe5a870: ldur            w0, [x3, #0xf]
    // 0xe5a874: DecompressPointer r0
    //     0xe5a874: add             x0, x0, HEAP, lsl #32
    // 0xe5a878: LoadField: r4 = r3->field_7
    //     0xe5a878: ldur            x4, [x3, #7]
    // 0xe5a87c: mov             x3, x0
    // 0xe5a880: mov             x0, x4
    // 0xe5a884: b               #0xe5a890
    // 0xe5a888: r3 = Null
    //     0xe5a888: mov             x3, NULL
    // 0xe5a88c: r0 = 0
    //     0xe5a88c: mov             x0, #0
    // 0xe5a890: stur            x3, [fp, #-0x18]
    // 0xe5a894: stur            x0, [fp, #-0x20]
    // 0xe5a898: LoadField: r4 = r1->field_1b
    //     0xe5a898: ldur            w4, [x1, #0x1b]
    // 0xe5a89c: DecompressPointer r4
    //     0xe5a89c: add             x4, x4, HEAP, lsl #32
    // 0xe5a8a0: stur            x4, [fp, #-0x10]
    // 0xe5a8a4: cmp             w4, NULL
    // 0xe5a8a8: b.eq            #0xe5a908
    // 0xe5a8ac: LoadField: r5 = r1->field_f
    //     0xe5a8ac: ldur            w5, [x1, #0xf]
    // 0xe5a8b0: DecompressPointer r5
    //     0xe5a8b0: add             x5, x5, HEAP, lsl #32
    // 0xe5a8b4: stur            x5, [fp, #-8]
    // 0xe5a8b8: r0 = DownloadProgress()
    //     0xe5a8b8: bl              #0xe5a90c  ; AllocateDownloadProgressStub -> DownloadProgress (size=0x14)
    // 0xe5a8bc: mov             x1, x0
    // 0xe5a8c0: ldur            x0, [fp, #-0x18]
    // 0xe5a8c4: StoreField: r1->field_7 = r0
    //     0xe5a8c4: stur            w0, [x1, #7]
    // 0xe5a8c8: ldur            x0, [fp, #-0x20]
    // 0xe5a8cc: StoreField: r1->field_b = r0
    //     0xe5a8cc: stur            x0, [x1, #0xb]
    // 0xe5a8d0: ldur            x16, [fp, #-0x10]
    // 0xe5a8d4: ldur            lr, [fp, #-0x28]
    // 0xe5a8d8: stp             lr, x16, [SP, #0x10]
    // 0xe5a8dc: ldur            x16, [fp, #-8]
    // 0xe5a8e0: stp             x1, x16, [SP]
    // 0xe5a8e4: ldur            x0, [fp, #-0x10]
    // 0xe5a8e8: ClosureCall
    //     0xe5a8e8: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xe5a8ec: ldur            x2, [x0, #0x1f]
    //     0xe5a8f0: blr             x2
    // 0xe5a8f4: LeaveFrame
    //     0xe5a8f4: mov             SP, fp
    //     0xe5a8f8: ldp             fp, lr, [SP], #0x10
    // 0xe5a8fc: ret
    //     0xe5a8fc: ret             
    // 0xe5a900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xe5a900: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xe5a904: b               #0xe5a868
    // 0xe5a908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xe5a908: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ CachedNetworkImage(/* No info */) {
    // ** addr: 0xe84270, size: 0x4fc
    // 0xe84270: EnterFrame
    //     0xe84270: stp             fp, lr, [SP, #-0x10]!
    //     0xe84274: mov             fp, SP
    // 0xe84278: AllocStack(0x18)
    //     0xe84278: sub             SP, SP, #0x18
    // 0xe8427c: SetupParameters(CachedNetworkImage this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic errorListener = Null /* r5, fp-0x8 */, dynamic errorWidget = Null /* r6 */, dynamic fadeInCurve = Instance_Cubic /* r7 */, dynamic fit = Null /* r8 */, dynamic height = Null /* r9 */, dynamic imageBuilder = Null /* r10 */, dynamic placeholder = Null /* r11 */, dynamic progressIndicatorBuilder = Null /* r12 */, dynamic width = Null /* r24 */})
    //     0xe8427c: mov             x3, x1
    //     0xe84280: stur            x1, [fp, #-0x10]
    //     0xe84284: stur            x2, [fp, #-0x18]
    //     0xe84288: ldur            w0, [x4, #0x13]
    //     0xe8428c: ldur            w1, [x4, #0x1f]
    //     0xe84290: add             x1, x1, HEAP, lsl #32
    //     0xe84294: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e958] "errorListener"
    //     0xe84298: ldr             x16, [x16, #0x958]
    //     0xe8429c: cmp             w1, w16
    //     0xe842a0: b.ne            #0xe842c4
    //     0xe842a4: ldur            w1, [x4, #0x23]
    //     0xe842a8: add             x1, x1, HEAP, lsl #32
    //     0xe842ac: sub             w5, w0, w1
    //     0xe842b0: add             x1, fp, w5, sxtw #2
    //     0xe842b4: ldr             x1, [x1, #8]
    //     0xe842b8: mov             x5, x1
    //     0xe842bc: mov             x1, #1
    //     0xe842c0: b               #0xe842cc
    //     0xe842c4: mov             x5, NULL
    //     0xe842c8: mov             x1, #0
    //     0xe842cc: stur            x5, [fp, #-8]
    //     0xe842d0: lsl             x6, x1, #1
    //     0xe842d4: lsl             w7, w6, #1
    //     0xe842d8: add             w8, w7, #8
    //     0xe842dc: add             x16, x4, w8, sxtw #1
    //     0xe842e0: ldur            w9, [x16, #0xf]
    //     0xe842e4: add             x9, x9, HEAP, lsl #32
    //     0xe842e8: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e960] "errorWidget"
    //     0xe842ec: ldr             x16, [x16, #0x960]
    //     0xe842f0: cmp             w9, w16
    //     0xe842f4: b.ne            #0xe84328
    //     0xe842f8: add             w1, w7, #0xa
    //     0xe842fc: add             x16, x4, w1, sxtw #1
    //     0xe84300: ldur            w7, [x16, #0xf]
    //     0xe84304: add             x7, x7, HEAP, lsl #32
    //     0xe84308: sub             w1, w0, w7
    //     0xe8430c: add             x7, fp, w1, sxtw #2
    //     0xe84310: ldr             x7, [x7, #8]
    //     0xe84314: add             w1, w6, #2
    //     0xe84318: sbfx            x6, x1, #1, #0x1f
    //     0xe8431c: mov             x1, x6
    //     0xe84320: mov             x6, x7
    //     0xe84324: b               #0xe8432c
    //     0xe84328: mov             x6, NULL
    //     0xe8432c: lsl             x7, x1, #1
    //     0xe84330: lsl             w8, w7, #1
    //     0xe84334: add             w9, w8, #8
    //     0xe84338: add             x16, x4, w9, sxtw #1
    //     0xe8433c: ldur            w10, [x16, #0xf]
    //     0xe84340: add             x10, x10, HEAP, lsl #32
    //     0xe84344: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e968] "fadeInCurve"
    //     0xe84348: ldr             x16, [x16, #0x968]
    //     0xe8434c: cmp             w10, w16
    //     0xe84350: b.ne            #0xe84384
    //     0xe84354: add             w1, w8, #0xa
    //     0xe84358: add             x16, x4, w1, sxtw #1
    //     0xe8435c: ldur            w8, [x16, #0xf]
    //     0xe84360: add             x8, x8, HEAP, lsl #32
    //     0xe84364: sub             w1, w0, w8
    //     0xe84368: add             x8, fp, w1, sxtw #2
    //     0xe8436c: ldr             x8, [x8, #8]
    //     0xe84370: add             w1, w7, #2
    //     0xe84374: sbfx            x7, x1, #1, #0x1f
    //     0xe84378: mov             x1, x7
    //     0xe8437c: mov             x7, x8
    //     0xe84380: b               #0xe8438c
    //     0xe84384: add             x7, PP, #0x1e, lsl #12  ; [pp+0x1e970] Obj!Cubic@129f541
    //     0xe84388: ldr             x7, [x7, #0x970]
    //     0xe8438c: lsl             x8, x1, #1
    //     0xe84390: lsl             w9, w8, #1
    //     0xe84394: add             w10, w9, #8
    //     0xe84398: add             x16, x4, w10, sxtw #1
    //     0xe8439c: ldur            w11, [x16, #0xf]
    //     0xe843a0: add             x11, x11, HEAP, lsl #32
    //     0xe843a4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16fa8] "fit"
    //     0xe843a8: ldr             x16, [x16, #0xfa8]
    //     0xe843ac: cmp             w11, w16
    //     0xe843b0: b.ne            #0xe843e4
    //     0xe843b4: add             w1, w9, #0xa
    //     0xe843b8: add             x16, x4, w1, sxtw #1
    //     0xe843bc: ldur            w9, [x16, #0xf]
    //     0xe843c0: add             x9, x9, HEAP, lsl #32
    //     0xe843c4: sub             w1, w0, w9
    //     0xe843c8: add             x9, fp, w1, sxtw #2
    //     0xe843cc: ldr             x9, [x9, #8]
    //     0xe843d0: add             w1, w8, #2
    //     0xe843d4: sbfx            x8, x1, #1, #0x1f
    //     0xe843d8: mov             x1, x8
    //     0xe843dc: mov             x8, x9
    //     0xe843e0: b               #0xe843e8
    //     0xe843e4: mov             x8, NULL
    //     0xe843e8: lsl             x9, x1, #1
    //     0xe843ec: lsl             w10, w9, #1
    //     0xe843f0: add             w11, w10, #8
    //     0xe843f4: add             x16, x4, w11, sxtw #1
    //     0xe843f8: ldur            w12, [x16, #0xf]
    //     0xe843fc: add             x12, x12, HEAP, lsl #32
    //     0xe84400: ldr             x16, [PP, #0x4ac8]  ; [pp+0x4ac8] "height"
    //     0xe84404: cmp             w12, w16
    //     0xe84408: b.ne            #0xe8443c
    //     0xe8440c: add             w1, w10, #0xa
    //     0xe84410: add             x16, x4, w1, sxtw #1
    //     0xe84414: ldur            w10, [x16, #0xf]
    //     0xe84418: add             x10, x10, HEAP, lsl #32
    //     0xe8441c: sub             w1, w0, w10
    //     0xe84420: add             x10, fp, w1, sxtw #2
    //     0xe84424: ldr             x10, [x10, #8]
    //     0xe84428: add             w1, w9, #2
    //     0xe8442c: sbfx            x9, x1, #1, #0x1f
    //     0xe84430: mov             x1, x9
    //     0xe84434: mov             x9, x10
    //     0xe84438: b               #0xe84440
    //     0xe8443c: mov             x9, NULL
    //     0xe84440: lsl             x10, x1, #1
    //     0xe84444: lsl             w11, w10, #1
    //     0xe84448: add             w12, w11, #8
    //     0xe8444c: add             x16, x4, w12, sxtw #1
    //     0xe84450: ldur            w13, [x16, #0xf]
    //     0xe84454: add             x13, x13, HEAP, lsl #32
    //     0xe84458: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e978] "imageBuilder"
    //     0xe8445c: ldr             x16, [x16, #0x978]
    //     0xe84460: cmp             w13, w16
    //     0xe84464: b.ne            #0xe84498
    //     0xe84468: add             w1, w11, #0xa
    //     0xe8446c: add             x16, x4, w1, sxtw #1
    //     0xe84470: ldur            w11, [x16, #0xf]
    //     0xe84474: add             x11, x11, HEAP, lsl #32
    //     0xe84478: sub             w1, w0, w11
    //     0xe8447c: add             x11, fp, w1, sxtw #2
    //     0xe84480: ldr             x11, [x11, #8]
    //     0xe84484: add             w1, w10, #2
    //     0xe84488: sbfx            x10, x1, #1, #0x1f
    //     0xe8448c: mov             x1, x10
    //     0xe84490: mov             x10, x11
    //     0xe84494: b               #0xe8449c
    //     0xe84498: mov             x10, NULL
    //     0xe8449c: lsl             x11, x1, #1
    //     0xe844a0: lsl             w12, w11, #1
    //     0xe844a4: add             w13, w12, #8
    //     0xe844a8: add             x16, x4, w13, sxtw #1
    //     0xe844ac: ldur            w14, [x16, #0xf]
    //     0xe844b0: add             x14, x14, HEAP, lsl #32
    //     0xe844b4: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e980] "placeholder"
    //     0xe844b8: ldr             x16, [x16, #0x980]
    //     0xe844bc: cmp             w14, w16
    //     0xe844c0: b.ne            #0xe844f4
    //     0xe844c4: add             w1, w12, #0xa
    //     0xe844c8: add             x16, x4, w1, sxtw #1
    //     0xe844cc: ldur            w12, [x16, #0xf]
    //     0xe844d0: add             x12, x12, HEAP, lsl #32
    //     0xe844d4: sub             w1, w0, w12
    //     0xe844d8: add             x12, fp, w1, sxtw #2
    //     0xe844dc: ldr             x12, [x12, #8]
    //     0xe844e0: add             w1, w11, #2
    //     0xe844e4: sbfx            x11, x1, #1, #0x1f
    //     0xe844e8: mov             x1, x11
    //     0xe844ec: mov             x11, x12
    //     0xe844f0: b               #0xe844f8
    //     0xe844f4: mov             x11, NULL
    //     0xe844f8: lsl             x12, x1, #1
    //     0xe844fc: lsl             w13, w12, #1
    //     0xe84500: add             w14, w13, #8
    //     0xe84504: add             x16, x4, w14, sxtw #1
    //     0xe84508: ldur            w19, [x16, #0xf]
    //     0xe8450c: add             x19, x19, HEAP, lsl #32
    //     0xe84510: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e988] "progressIndicatorBuilder"
    //     0xe84514: ldr             x16, [x16, #0x988]
    //     0xe84518: cmp             w19, w16
    //     0xe8451c: b.ne            #0xe84550
    //     0xe84520: add             w1, w13, #0xa
    //     0xe84524: add             x16, x4, w1, sxtw #1
    //     0xe84528: ldur            w13, [x16, #0xf]
    //     0xe8452c: add             x13, x13, HEAP, lsl #32
    //     0xe84530: sub             w1, w0, w13
    //     0xe84534: add             x13, fp, w1, sxtw #2
    //     0xe84538: ldr             x13, [x13, #8]
    //     0xe8453c: add             w1, w12, #2
    //     0xe84540: sbfx            x12, x1, #1, #0x1f
    //     0xe84544: mov             x1, x12
    //     0xe84548: mov             x12, x13
    //     0xe8454c: b               #0xe84554
    //     0xe84550: mov             x12, NULL
    //     0xe84554: lsl             x13, x1, #1
    //     0xe84558: lsl             w1, w13, #1
    //     0xe8455c: add             w13, w1, #8
    //     0xe84560: add             x16, x4, w13, sxtw #1
    //     0xe84564: ldur            w14, [x16, #0xf]
    //     0xe84568: add             x14, x14, HEAP, lsl #32
    //     0xe8456c: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "width"
    //     0xe84570: cmp             w14, w16
    //     0xe84574: b.ne            #0xe8459c
    //     0xe84578: add             w13, w1, #0xa
    //     0xe8457c: add             x16, x4, w13, sxtw #1
    //     0xe84580: ldur            w1, [x16, #0xf]
    //     0xe84584: add             x1, x1, HEAP, lsl #32
    //     0xe84588: sub             w4, w0, w1
    //     0xe8458c: add             x0, fp, w4, sxtw #2
    //     0xe84590: ldr             x0, [x0, #8]
    //     0xe84594: mov             x24, x0
    //     0xe84598: b               #0xe845a0
    //     0xe8459c: mov             x24, NULL
    // 0xe845a0: r23 = Instance_Duration
    //     0xe845a0: ldr             x23, [PP, #0xa80]  ; [pp+0xa80] Obj!Duration@12c8921
    // 0xe845a4: r20 = Instance_Cubic
    //     0xe845a4: add             x20, PP, #0x15, lsl #12  ; [pp+0x158f0] Obj!Cubic@129f571
    //     0xe845a8: ldr             x20, [x20, #0x8f0]
    // 0xe845ac: r19 = Instance_Duration
    //     0xe845ac: ldr             x19, [PP, #0x5248]  ; [pp+0x5248] Obj!Duration@12c8931
    // 0xe845b0: r14 = Instance_Alignment
    //     0xe845b0: add             x14, PP, #0x15, lsl #12  ; [pp+0x15b80] Obj!Alignment@129e751
    //     0xe845b4: ldr             x14, [x14, #0xb80]
    // 0xe845b8: r13 = Instance_ImageRepeat
    //     0xe845b8: add             x13, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xe845bc: ldr             x13, [x13, #0xfb8]
    // 0xe845c0: r4 = false
    //     0xe845c0: add             x4, NULL, #0x30  ; false
    // 0xe845c4: r1 = Instance_FilterQuality
    //     0xe845c4: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e990] Obj!FilterQuality@12c8281
    //     0xe845c8: ldr             x1, [x1, #0x990]
    // 0xe845cc: mov             x0, x2
    // 0xe845d0: StoreField: r3->field_f = r0
    //     0xe845d0: stur            w0, [x3, #0xf]
    //     0xe845d4: ldurb           w16, [x3, #-1]
    //     0xe845d8: ldurb           w17, [x0, #-1]
    //     0xe845dc: and             x16, x17, x16, lsr #2
    //     0xe845e0: tst             x16, HEAP, lsr #32
    //     0xe845e4: b.eq            #0xe845ec
    //     0xe845e8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe845ec: mov             x0, x10
    // 0xe845f0: StoreField: r3->field_13 = r0
    //     0xe845f0: stur            w0, [x3, #0x13]
    //     0xe845f4: ldurb           w16, [x3, #-1]
    //     0xe845f8: ldurb           w17, [x0, #-1]
    //     0xe845fc: and             x16, x17, x16, lsr #2
    //     0xe84600: tst             x16, HEAP, lsr #32
    //     0xe84604: b.eq            #0xe8460c
    //     0xe84608: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe8460c: mov             x0, x11
    // 0xe84610: ArrayStore: r3[0] = r0  ; List_4
    //     0xe84610: stur            w0, [x3, #0x17]
    //     0xe84614: ldurb           w16, [x3, #-1]
    //     0xe84618: ldurb           w17, [x0, #-1]
    //     0xe8461c: and             x16, x17, x16, lsr #2
    //     0xe84620: tst             x16, HEAP, lsr #32
    //     0xe84624: b.eq            #0xe8462c
    //     0xe84628: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe8462c: mov             x0, x12
    // 0xe84630: StoreField: r3->field_1b = r0
    //     0xe84630: stur            w0, [x3, #0x1b]
    //     0xe84634: ldurb           w16, [x3, #-1]
    //     0xe84638: ldurb           w17, [x0, #-1]
    //     0xe8463c: and             x16, x17, x16, lsr #2
    //     0xe84640: tst             x16, HEAP, lsr #32
    //     0xe84644: b.eq            #0xe8464c
    //     0xe84648: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe8464c: mov             x0, x6
    // 0xe84650: StoreField: r3->field_1f = r0
    //     0xe84650: stur            w0, [x3, #0x1f]
    //     0xe84654: ldurb           w16, [x3, #-1]
    //     0xe84658: ldurb           w17, [x0, #-1]
    //     0xe8465c: and             x16, x17, x16, lsr #2
    //     0xe84660: tst             x16, HEAP, lsr #32
    //     0xe84664: b.eq            #0xe8466c
    //     0xe84668: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe8466c: StoreField: r3->field_27 = r23
    //     0xe8466c: stur            w23, [x3, #0x27]
    // 0xe84670: StoreField: r3->field_2b = r20
    //     0xe84670: stur            w20, [x3, #0x2b]
    // 0xe84674: StoreField: r3->field_2f = r19
    //     0xe84674: stur            w19, [x3, #0x2f]
    // 0xe84678: mov             x0, x7
    // 0xe8467c: StoreField: r3->field_33 = r0
    //     0xe8467c: stur            w0, [x3, #0x33]
    //     0xe84680: ldurb           w16, [x3, #-1]
    //     0xe84684: ldurb           w17, [x0, #-1]
    //     0xe84688: and             x16, x17, x16, lsr #2
    //     0xe8468c: tst             x16, HEAP, lsr #32
    //     0xe84690: b.eq            #0xe84698
    //     0xe84694: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe84698: mov             x0, x24
    // 0xe8469c: StoreField: r3->field_37 = r0
    //     0xe8469c: stur            w0, [x3, #0x37]
    //     0xe846a0: ldurb           w16, [x3, #-1]
    //     0xe846a4: ldurb           w17, [x0, #-1]
    //     0xe846a8: and             x16, x17, x16, lsr #2
    //     0xe846ac: tst             x16, HEAP, lsr #32
    //     0xe846b0: b.eq            #0xe846b8
    //     0xe846b4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe846b8: mov             x0, x9
    // 0xe846bc: StoreField: r3->field_3b = r0
    //     0xe846bc: stur            w0, [x3, #0x3b]
    //     0xe846c0: ldurb           w16, [x3, #-1]
    //     0xe846c4: ldurb           w17, [x0, #-1]
    //     0xe846c8: and             x16, x17, x16, lsr #2
    //     0xe846cc: tst             x16, HEAP, lsr #32
    //     0xe846d0: b.eq            #0xe846d8
    //     0xe846d4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe846d8: mov             x0, x8
    // 0xe846dc: StoreField: r3->field_3f = r0
    //     0xe846dc: stur            w0, [x3, #0x3f]
    //     0xe846e0: ldurb           w16, [x3, #-1]
    //     0xe846e4: ldurb           w17, [x0, #-1]
    //     0xe846e8: and             x16, x17, x16, lsr #2
    //     0xe846ec: tst             x16, HEAP, lsr #32
    //     0xe846f0: b.eq            #0xe846f8
    //     0xe846f4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xe846f8: StoreField: r3->field_43 = r14
    //     0xe846f8: stur            w14, [x3, #0x43]
    // 0xe846fc: StoreField: r3->field_47 = r13
    //     0xe846fc: stur            w13, [x3, #0x47]
    // 0xe84700: StoreField: r3->field_4b = r4
    //     0xe84700: stur            w4, [x3, #0x4b]
    // 0xe84704: StoreField: r3->field_4f = r4
    //     0xe84704: stur            w4, [x3, #0x4f]
    // 0xe84708: StoreField: r3->field_5b = r1
    //     0xe84708: stur            w1, [x3, #0x5b]
    // 0xe8470c: r1 = <CachedNetworkImageProvider>
    //     0xe8470c: add             x1, PP, #0x18, lsl #12  ; [pp+0x180d8] TypeArguments: <CachedNetworkImageProvider>
    //     0xe84710: ldr             x1, [x1, #0xd8]
    // 0xe84714: r0 = CachedNetworkImageProvider()
    //     0xe84714: bl              #0xe8476c  ; AllocateCachedNetworkImageProviderStub -> CachedNetworkImageProvider (size=0x34)
    // 0xe84718: ldur            x1, [fp, #-0x18]
    // 0xe8471c: StoreField: r0->field_f = r1
    //     0xe8471c: stur            w1, [x0, #0xf]
    // 0xe84720: d0 = 1.000000
    //     0xe84720: fmov            d0, #1.00000000
    // 0xe84724: ArrayStore: r0[0] = d0  ; List_8
    //     0xe84724: stur            d0, [x0, #0x17]
    // 0xe84728: ldur            x1, [fp, #-8]
    // 0xe8472c: StoreField: r0->field_1f = r1
    //     0xe8472c: stur            w1, [x0, #0x1f]
    // 0xe84730: r1 = Instance_ImageRenderMethodForWeb
    //     0xe84730: add             x1, PP, #0x18, lsl #12  ; [pp+0x180e0] Obj!ImageRenderMethodForWeb@12c6781
    //     0xe84734: ldr             x1, [x1, #0xe0]
    // 0xe84738: StoreField: r0->field_2f = r1
    //     0xe84738: stur            w1, [x0, #0x2f]
    // 0xe8473c: ldur            x1, [fp, #-0x10]
    // 0xe84740: StoreField: r1->field_b = r0
    //     0xe84740: stur            w0, [x1, #0xb]
    //     0xe84744: ldurb           w16, [x1, #-1]
    //     0xe84748: ldurb           w17, [x0, #-1]
    //     0xe8474c: and             x16, x17, x16, lsr #2
    //     0xe84750: tst             x16, HEAP, lsr #32
    //     0xe84754: b.eq            #0xe8475c
    //     0xe84758: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xe8475c: r0 = Null
    //     0xe8475c: mov             x0, NULL
    // 0xe84760: LeaveFrame
    //     0xe84760: mov             SP, fp
    //     0xe84764: ldp             fp, lr, [SP], #0x10
    // 0xe84768: ret
    //     0xe84768: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xfa9bb4, size: 0x1b4
    // 0xfa9bb4: EnterFrame
    //     0xfa9bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xfa9bb8: mov             fp, SP
    // 0xfa9bbc: AllocStack(0x70)
    //     0xfa9bbc: sub             SP, SP, #0x70
    // 0xfa9bc0: SetupParameters(CachedNetworkImage this /* r1 => r0, fp-0x8 */)
    //     0xfa9bc0: mov             x0, x1
    //     0xfa9bc4: stur            x1, [fp, #-8]
    // 0xfa9bc8: CheckStackOverflow
    //     0xfa9bc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa9bcc: cmp             SP, x16
    //     0xfa9bd0: b.ls            #0xfa9d60
    // 0xfa9bd4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfa9bd4: ldur            w1, [x0, #0x17]
    // 0xfa9bd8: DecompressPointer r1
    //     0xfa9bd8: add             x1, x1, HEAP, lsl #32
    // 0xfa9bdc: cmp             w1, NULL
    // 0xfa9be0: b.eq            #0xfa9bfc
    // 0xfa9be4: mov             x2, x0
    // 0xfa9be8: r1 = Function '_octoPlaceholderBuilder@1191180012':.
    //     0xfa9be8: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ee40] AnonymousClosure: (0xfa9f24), in [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::_octoPlaceholderBuilder (0xfa9f60)
    //     0xfa9bec: ldr             x1, [x1, #0xe40]
    // 0xfa9bf0: r0 = AllocateClosure()
    //     0xfa9bf0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfa9bf4: mov             x3, x0
    // 0xfa9bf8: b               #0xfa9c00
    // 0xfa9bfc: r3 = Null
    //     0xfa9bfc: mov             x3, NULL
    // 0xfa9c00: ldur            x0, [fp, #-8]
    // 0xfa9c04: stur            x3, [fp, #-0x10]
    // 0xfa9c08: LoadField: r1 = r0->field_1b
    //     0xfa9c08: ldur            w1, [x0, #0x1b]
    // 0xfa9c0c: DecompressPointer r1
    //     0xfa9c0c: add             x1, x1, HEAP, lsl #32
    // 0xfa9c10: cmp             w1, NULL
    // 0xfa9c14: b.eq            #0xfa9c30
    // 0xfa9c18: mov             x2, x0
    // 0xfa9c1c: r1 = Function '_octoProgressIndicatorBuilder@1191180012':.
    //     0xfa9c1c: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ee48] AnonymousClosure: (0xe5a80c), in [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::_octoProgressIndicatorBuilder (0xe5a84c)
    //     0xfa9c20: ldr             x1, [x1, #0xe48]
    // 0xfa9c24: r0 = AllocateClosure()
    //     0xfa9c24: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfa9c28: mov             x3, x0
    // 0xfa9c2c: b               #0xfa9c34
    // 0xfa9c30: r3 = Null
    //     0xfa9c30: mov             x3, NULL
    // 0xfa9c34: ldur            x0, [fp, #-0x10]
    // 0xfa9c38: stur            x3, [fp, #-0x18]
    // 0xfa9c3c: cmp             w0, NULL
    // 0xfa9c40: b.ne            #0xfa9c64
    // 0xfa9c44: cmp             w3, NULL
    // 0xfa9c48: b.ne            #0xfa9c64
    // 0xfa9c4c: r1 = Function '<anonymous closure>':.
    //     0xfa9c4c: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ee50] AnonymousClosure: (0xe47314), in [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::build (0xfa9bb4)
    //     0xfa9c50: ldr             x1, [x1, #0xe50]
    // 0xfa9c54: r2 = Null
    //     0xfa9c54: mov             x2, NULL
    // 0xfa9c58: r0 = AllocateClosure()
    //     0xfa9c58: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfa9c5c: mov             x3, x0
    // 0xfa9c60: b               #0xfa9c68
    // 0xfa9c64: mov             x3, x0
    // 0xfa9c68: ldur            x0, [fp, #-8]
    // 0xfa9c6c: stur            x3, [fp, #-0x20]
    // 0xfa9c70: LoadField: r7 = r0->field_b
    //     0xfa9c70: ldur            w7, [x0, #0xb]
    // 0xfa9c74: DecompressPointer r7
    //     0xfa9c74: add             x7, x7, HEAP, lsl #32
    // 0xfa9c78: stur            x7, [fp, #-0x10]
    // 0xfa9c7c: LoadField: r1 = r0->field_13
    //     0xfa9c7c: ldur            w1, [x0, #0x13]
    // 0xfa9c80: DecompressPointer r1
    //     0xfa9c80: add             x1, x1, HEAP, lsl #32
    // 0xfa9c84: cmp             w1, NULL
    // 0xfa9c88: b.eq            #0xfa9ca4
    // 0xfa9c8c: mov             x2, x0
    // 0xfa9c90: r1 = Function '_octoImageBuilder@1191180012':.
    //     0xfa9c90: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ee58] AnonymousClosure: (0xe5a4e0), in [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::_octoImageBuilder (0xe5a520)
    //     0xfa9c94: ldr             x1, [x1, #0xe58]
    // 0xfa9c98: r0 = AllocateClosure()
    //     0xfa9c98: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfa9c9c: mov             x3, x0
    // 0xfa9ca0: b               #0xfa9ca8
    // 0xfa9ca4: r3 = Null
    //     0xfa9ca4: mov             x3, NULL
    // 0xfa9ca8: ldur            x0, [fp, #-8]
    // 0xfa9cac: stur            x3, [fp, #-0x28]
    // 0xfa9cb0: LoadField: r1 = r0->field_1f
    //     0xfa9cb0: ldur            w1, [x0, #0x1f]
    // 0xfa9cb4: DecompressPointer r1
    //     0xfa9cb4: add             x1, x1, HEAP, lsl #32
    // 0xfa9cb8: cmp             w1, NULL
    // 0xfa9cbc: b.eq            #0xfa9cd8
    // 0xfa9cc0: mov             x2, x0
    // 0xfa9cc4: r1 = Function '_octoErrorBuilder@1191180012':.
    //     0xfa9cc4: add             x1, PP, #0x7e, lsl #12  ; [pp+0x7ee60] AnonymousClosure: (0xe5a100), in [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::_octoErrorBuilder (0xe5a144)
    //     0xfa9cc8: ldr             x1, [x1, #0xe60]
    // 0xfa9ccc: r0 = AllocateClosure()
    //     0xfa9ccc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xfa9cd0: mov             x2, x0
    // 0xfa9cd4: b               #0xfa9cdc
    // 0xfa9cd8: r2 = Null
    //     0xfa9cd8: mov             x2, NULL
    // 0xfa9cdc: ldur            x0, [fp, #-8]
    // 0xfa9ce0: stur            x2, [fp, #-0x50]
    // 0xfa9ce4: LoadField: r3 = r0->field_33
    //     0xfa9ce4: ldur            w3, [x0, #0x33]
    // 0xfa9ce8: DecompressPointer r3
    //     0xfa9ce8: add             x3, x3, HEAP, lsl #32
    // 0xfa9cec: stur            x3, [fp, #-0x48]
    // 0xfa9cf0: LoadField: r1 = r0->field_37
    //     0xfa9cf0: ldur            w1, [x0, #0x37]
    // 0xfa9cf4: DecompressPointer r1
    //     0xfa9cf4: add             x1, x1, HEAP, lsl #32
    // 0xfa9cf8: stur            x1, [fp, #-0x40]
    // 0xfa9cfc: LoadField: r6 = r0->field_3b
    //     0xfa9cfc: ldur            w6, [x0, #0x3b]
    // 0xfa9d00: DecompressPointer r6
    //     0xfa9d00: add             x6, x6, HEAP, lsl #32
    // 0xfa9d04: stur            x6, [fp, #-0x38]
    // 0xfa9d08: LoadField: r5 = r0->field_3f
    //     0xfa9d08: ldur            w5, [x0, #0x3f]
    // 0xfa9d0c: DecompressPointer r5
    //     0xfa9d0c: add             x5, x5, HEAP, lsl #32
    // 0xfa9d10: stur            x5, [fp, #-0x30]
    // 0xfa9d14: r0 = OctoImage()
    //     0xfa9d14: bl              #0xfa9f18  ; AllocateOctoImageStub -> OctoImage (size=0x5c)
    // 0xfa9d18: stur            x0, [fp, #-8]
    // 0xfa9d1c: ldur            x16, [fp, #-0x28]
    // 0xfa9d20: ldur            lr, [fp, #-0x20]
    // 0xfa9d24: stp             lr, x16, [SP, #0x10]
    // 0xfa9d28: ldur            x16, [fp, #-0x18]
    // 0xfa9d2c: ldur            lr, [fp, #-0x40]
    // 0xfa9d30: stp             lr, x16, [SP]
    // 0xfa9d34: mov             x1, x0
    // 0xfa9d38: ldur            x2, [fp, #-0x50]
    // 0xfa9d3c: ldur            x3, [fp, #-0x48]
    // 0xfa9d40: ldur            x5, [fp, #-0x30]
    // 0xfa9d44: ldur            x6, [fp, #-0x38]
    // 0xfa9d48: ldur            x7, [fp, #-0x10]
    // 0xfa9d4c: r0 = OctoImage()
    //     0xfa9d4c: bl              #0xfa9d68  ; [package:octo_image/src/image/image.dart] OctoImage::OctoImage
    // 0xfa9d50: ldur            x0, [fp, #-8]
    // 0xfa9d54: LeaveFrame
    //     0xfa9d54: mov             SP, fp
    //     0xfa9d58: ldp             fp, lr, [SP], #0x10
    // 0xfa9d5c: ret
    //     0xfa9d5c: ret             
    // 0xfa9d60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa9d60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa9d64: b               #0xfa9bd4
  }
  [closure] Widget _octoPlaceholderBuilder(dynamic, BuildContext) {
    // ** addr: 0xfa9f24, size: 0x3c
    // 0xfa9f24: EnterFrame
    //     0xfa9f24: stp             fp, lr, [SP, #-0x10]!
    //     0xfa9f28: mov             fp, SP
    // 0xfa9f2c: ldr             x0, [fp, #0x18]
    // 0xfa9f30: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xfa9f30: ldur            w1, [x0, #0x17]
    // 0xfa9f34: DecompressPointer r1
    //     0xfa9f34: add             x1, x1, HEAP, lsl #32
    // 0xfa9f38: CheckStackOverflow
    //     0xfa9f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa9f3c: cmp             SP, x16
    //     0xfa9f40: b.ls            #0xfa9f58
    // 0xfa9f44: ldr             x2, [fp, #0x10]
    // 0xfa9f48: r0 = _octoPlaceholderBuilder()
    //     0xfa9f48: bl              #0xfa9f60  ; [package:cached_network_image/src/cached_image_widget.dart] CachedNetworkImage::_octoPlaceholderBuilder
    // 0xfa9f4c: LeaveFrame
    //     0xfa9f4c: mov             SP, fp
    //     0xfa9f50: ldp             fp, lr, [SP], #0x10
    // 0xfa9f54: ret
    //     0xfa9f54: ret             
    // 0xfa9f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa9f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa9f5c: b               #0xfa9f44
  }
  _ _octoPlaceholderBuilder(/* No info */) {
    // ** addr: 0xfa9f60, size: 0x5c
    // 0xfa9f60: EnterFrame
    //     0xfa9f60: stp             fp, lr, [SP, #-0x10]!
    //     0xfa9f64: mov             fp, SP
    // 0xfa9f68: AllocStack(0x18)
    //     0xfa9f68: sub             SP, SP, #0x18
    // 0xfa9f6c: CheckStackOverflow
    //     0xfa9f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xfa9f70: cmp             SP, x16
    //     0xfa9f74: b.ls            #0xfa9fb0
    // 0xfa9f78: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xfa9f78: ldur            w0, [x1, #0x17]
    // 0xfa9f7c: DecompressPointer r0
    //     0xfa9f7c: add             x0, x0, HEAP, lsl #32
    // 0xfa9f80: cmp             w0, NULL
    // 0xfa9f84: b.eq            #0xfa9fb8
    // 0xfa9f88: LoadField: r3 = r1->field_f
    //     0xfa9f88: ldur            w3, [x1, #0xf]
    // 0xfa9f8c: DecompressPointer r3
    //     0xfa9f8c: add             x3, x3, HEAP, lsl #32
    // 0xfa9f90: stp             x2, x0, [SP, #8]
    // 0xfa9f94: str             x3, [SP]
    // 0xfa9f98: ClosureCall
    //     0xfa9f98: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xfa9f9c: ldur            x2, [x0, #0x1f]
    //     0xfa9fa0: blr             x2
    // 0xfa9fa4: LeaveFrame
    //     0xfa9fa4: mov             SP, fp
    //     0xfa9fa8: ldp             fp, lr, [SP], #0x10
    // 0xfa9fac: ret
    //     0xfa9fac: ret             
    // 0xfa9fb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xfa9fb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xfa9fb4: b               #0xfa9f78
    // 0xfa9fb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xfa9fb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
