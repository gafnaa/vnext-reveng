// lib: , url: package:collection/src/list_extensions.dart

// class id: 1048655, size: 0x8
class :: {

  static _ ListExtensions.forEachIndexed(/* No info */) {
    // ** addr: 0xf07380, size: 0xa0
    // 0xf07380: EnterFrame
    //     0xf07380: stp             fp, lr, [SP, #-0x10]!
    //     0xf07384: mov             fp, SP
    // 0xf07388: AllocStack(0x20)
    //     0xf07388: sub             SP, SP, #0x20
    // 0xf0738c: CheckStackOverflow
    //     0xf0738c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf07390: cmp             SP, x16
    //     0xf07394: b.ls            #0xf07410
    // 0xf07398: r2 = 0
    //     0xf07398: mov             x2, #0
    // 0xf0739c: ldr             x1, [fp, #0x18]
    // 0xf073a0: stur            x2, [fp, #-8]
    // 0xf073a4: CheckStackOverflow
    //     0xf073a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf073a8: cmp             SP, x16
    //     0xf073ac: b.ls            #0xf07418
    // 0xf073b0: LoadField: r0 = r1->field_b
    //     0xf073b0: ldur            w0, [x1, #0xb]
    // 0xf073b4: r3 = LoadInt32Instr(r0)
    //     0xf073b4: sbfx            x3, x0, #1, #0x1f
    // 0xf073b8: cmp             x2, x3
    // 0xf073bc: b.ge            #0xf07400
    // 0xf073c0: LoadField: r0 = r1->field_f
    //     0xf073c0: ldur            w0, [x1, #0xf]
    // 0xf073c4: DecompressPointer r0
    //     0xf073c4: add             x0, x0, HEAP, lsl #32
    // 0xf073c8: lsl             x3, x2, #1
    // 0xf073cc: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0xf073cc: add             x16, x0, x2, lsl #2
    //     0xf073d0: ldur            w4, [x16, #0xf]
    // 0xf073d4: DecompressPointer r4
    //     0xf073d4: add             x4, x4, HEAP, lsl #32
    // 0xf073d8: ldr             x16, [fp, #0x10]
    // 0xf073dc: stp             x3, x16, [SP, #8]
    // 0xf073e0: str             x4, [SP]
    // 0xf073e4: ldr             x0, [fp, #0x10]
    // 0xf073e8: ClosureCall
    //     0xf073e8: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xf073ec: ldur            x2, [x0, #0x1f]
    //     0xf073f0: blr             x2
    // 0xf073f4: ldur            x1, [fp, #-8]
    // 0xf073f8: add             x2, x1, #1
    // 0xf073fc: b               #0xf0739c
    // 0xf07400: r0 = Null
    //     0xf07400: mov             x0, NULL
    // 0xf07404: LeaveFrame
    //     0xf07404: mov             SP, fp
    //     0xf07408: ldp             fp, lr, [SP], #0x10
    // 0xf0740c: ret
    //     0xf0740c: ret             
    // 0xf07410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf07410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf07414: b               #0xf07398
    // 0xf07418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf07418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf0741c: b               #0xf073b0
  }
  static _ ListExtensions.equals(/* No info */) {
    // ** addr: 0xf98f00, size: 0x1b8
    // 0xf98f00: EnterFrame
    //     0xf98f00: stp             fp, lr, [SP, #-0x10]!
    //     0xf98f04: mov             fp, SP
    // 0xf98f08: AllocStack(0x28)
    //     0xf98f08: sub             SP, SP, #0x28
    // 0xf98f0c: CheckStackOverflow
    //     0xf98f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf98f10: cmp             SP, x16
    //     0xf98f14: b.ls            #0xf990a8
    // 0xf98f18: ldr             x1, [fp, #0x18]
    // 0xf98f1c: r0 = LoadClassIdInstr(r1)
    //     0xf98f1c: ldur            x0, [x1, #-1]
    //     0xf98f20: ubfx            x0, x0, #0xc, #0x14
    // 0xf98f24: str             x1, [SP]
    // 0xf98f28: r0 = GDT[cid_x0 + 0xf078]()
    //     0xf98f28: mov             x17, #0xf078
    //     0xf98f2c: add             lr, x0, x17
    //     0xf98f30: ldr             lr, [x21, lr, lsl #3]
    //     0xf98f34: blr             lr
    // 0xf98f38: mov             x2, x0
    // 0xf98f3c: ldr             x1, [fp, #0x10]
    // 0xf98f40: stur            x2, [fp, #-8]
    // 0xf98f44: r0 = LoadClassIdInstr(r1)
    //     0xf98f44: ldur            x0, [x1, #-1]
    //     0xf98f48: ubfx            x0, x0, #0xc, #0x14
    // 0xf98f4c: str             x1, [SP]
    // 0xf98f50: r0 = GDT[cid_x0 + 0xf078]()
    //     0xf98f50: mov             x17, #0xf078
    //     0xf98f54: add             lr, x0, x17
    //     0xf98f58: ldr             lr, [x21, lr, lsl #3]
    //     0xf98f5c: blr             lr
    // 0xf98f60: mov             x1, x0
    // 0xf98f64: ldur            x0, [fp, #-8]
    // 0xf98f68: r2 = LoadInt32Instr(r0)
    //     0xf98f68: sbfx            x2, x0, #1, #0x1f
    //     0xf98f6c: tbz             w0, #0, #0xf98f74
    //     0xf98f70: ldur            x2, [x0, #7]
    // 0xf98f74: r0 = LoadInt32Instr(r1)
    //     0xf98f74: sbfx            x0, x1, #1, #0x1f
    //     0xf98f78: tbz             w1, #0, #0xf98f80
    //     0xf98f7c: ldur            x0, [x1, #7]
    // 0xf98f80: cmp             x2, x0
    // 0xf98f84: b.eq            #0xf98f98
    // 0xf98f88: r0 = false
    //     0xf98f88: add             x0, NULL, #0x30  ; false
    // 0xf98f8c: LeaveFrame
    //     0xf98f8c: mov             SP, fp
    //     0xf98f90: ldp             fp, lr, [SP], #0x10
    // 0xf98f94: ret
    //     0xf98f94: ret             
    // 0xf98f98: r3 = 0
    //     0xf98f98: mov             x3, #0
    // 0xf98f9c: ldr             x2, [fp, #0x18]
    // 0xf98fa0: ldr             x1, [fp, #0x10]
    // 0xf98fa4: stur            x3, [fp, #-0x10]
    // 0xf98fa8: CheckStackOverflow
    //     0xf98fa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf98fac: cmp             SP, x16
    //     0xf98fb0: b.ls            #0xf990b0
    // 0xf98fb4: r0 = LoadClassIdInstr(r2)
    //     0xf98fb4: ldur            x0, [x2, #-1]
    //     0xf98fb8: ubfx            x0, x0, #0xc, #0x14
    // 0xf98fbc: str             x2, [SP]
    // 0xf98fc0: r0 = GDT[cid_x0 + 0xf078]()
    //     0xf98fc0: mov             x17, #0xf078
    //     0xf98fc4: add             lr, x0, x17
    //     0xf98fc8: ldr             lr, [x21, lr, lsl #3]
    //     0xf98fcc: blr             lr
    // 0xf98fd0: r1 = LoadInt32Instr(r0)
    //     0xf98fd0: sbfx            x1, x0, #1, #0x1f
    //     0xf98fd4: tbz             w0, #0, #0xf98fdc
    //     0xf98fd8: ldur            x1, [x0, #7]
    // 0xf98fdc: ldur            x2, [fp, #-0x10]
    // 0xf98fe0: cmp             x2, x1
    // 0xf98fe4: b.ge            #0xf99098
    // 0xf98fe8: ldr             x4, [fp, #0x18]
    // 0xf98fec: ldr             x3, [fp, #0x10]
    // 0xf98ff0: r0 = BoxInt64Instr(r2)
    //     0xf98ff0: sbfiz           x0, x2, #1, #0x1f
    //     0xf98ff4: cmp             x2, x0, asr #1
    //     0xf98ff8: b.eq            #0xf99004
    //     0xf98ffc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xf99000: stur            x2, [x0, #7]
    // 0xf99004: mov             x1, x0
    // 0xf99008: stur            x1, [fp, #-8]
    // 0xf9900c: r0 = LoadClassIdInstr(r4)
    //     0xf9900c: ldur            x0, [x4, #-1]
    //     0xf99010: ubfx            x0, x0, #0xc, #0x14
    // 0xf99014: stp             x1, x4, [SP]
    // 0xf99018: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xf99018: sub             lr, x0, #0xdfd
    //     0xf9901c: ldr             lr, [x21, lr, lsl #3]
    //     0xf99020: blr             lr
    // 0xf99024: mov             x2, x0
    // 0xf99028: ldr             x1, [fp, #0x10]
    // 0xf9902c: stur            x2, [fp, #-0x18]
    // 0xf99030: r0 = LoadClassIdInstr(r1)
    //     0xf99030: ldur            x0, [x1, #-1]
    //     0xf99034: ubfx            x0, x0, #0xc, #0x14
    // 0xf99038: ldur            x16, [fp, #-8]
    // 0xf9903c: stp             x16, x1, [SP]
    // 0xf99040: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xf99040: sub             lr, x0, #0xdfd
    //     0xf99044: ldr             lr, [x21, lr, lsl #3]
    //     0xf99048: blr             lr
    // 0xf9904c: mov             x1, x0
    // 0xf99050: ldur            x0, [fp, #-0x18]
    // 0xf99054: r2 = 60
    //     0xf99054: mov             x2, #0x3c
    // 0xf99058: branchIfSmi(r0, 0xf99064)
    //     0xf99058: tbz             w0, #0, #0xf99064
    // 0xf9905c: r2 = LoadClassIdInstr(r0)
    //     0xf9905c: ldur            x2, [x0, #-1]
    //     0xf99060: ubfx            x2, x2, #0xc, #0x14
    // 0xf99064: stp             x1, x0, [SP]
    // 0xf99068: mov             x0, x2
    // 0xf9906c: mov             lr, x0
    // 0xf99070: ldr             lr, [x21, lr, lsl #3]
    // 0xf99074: blr             lr
    // 0xf99078: tbnz            w0, #4, #0xf99088
    // 0xf9907c: ldur            x1, [fp, #-0x10]
    // 0xf99080: add             x3, x1, #1
    // 0xf99084: b               #0xf98f9c
    // 0xf99088: r0 = false
    //     0xf99088: add             x0, NULL, #0x30  ; false
    // 0xf9908c: LeaveFrame
    //     0xf9908c: mov             SP, fp
    //     0xf99090: ldp             fp, lr, [SP], #0x10
    // 0xf99094: ret
    //     0xf99094: ret             
    // 0xf99098: r0 = true
    //     0xf99098: add             x0, NULL, #0x20  ; true
    // 0xf9909c: LeaveFrame
    //     0xf9909c: mov             SP, fp
    //     0xf990a0: ldp             fp, lr, [SP], #0x10
    // 0xf990a4: ret
    //     0xf990a4: ret             
    // 0xf990a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf990a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf990ac: b               #0xf98f18
    // 0xf990b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf990b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf990b4: b               #0xf98fb4
  }
}
