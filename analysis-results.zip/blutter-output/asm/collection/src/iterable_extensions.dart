// lib: , url: package:collection/src/iterable_extensions.dart

// class id: 1048654, size: 0x8
class :: {

  static _ IterableExtension.lastOrNull(/* No info */) {
    // ** addr: 0xa0b80c, size: 0x80
    // 0xa0b80c: EnterFrame
    //     0xa0b80c: stp             fp, lr, [SP, #-0x10]!
    //     0xa0b810: mov             fp, SP
    // 0xa0b814: CheckStackOverflow
    //     0xa0b814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa0b818: cmp             SP, x16
    //     0xa0b81c: b.ls            #0xa0b884
    // 0xa0b820: ldr             x2, [fp, #0x10]
    // 0xa0b824: r0 = LoadClassIdInstr(r2)
    //     0xa0b824: ldur            x0, [x2, #-1]
    //     0xa0b828: ubfx            x0, x0, #0xc, #0x14
    // 0xa0b82c: mov             x1, x2
    // 0xa0b830: r0 = GDT[cid_x0 + 0x12b36]()
    //     0xa0b830: mov             x17, #0x2b36
    //     0xa0b834: movk            x17, #1, lsl #16
    //     0xa0b838: add             lr, x0, x17
    //     0xa0b83c: ldr             lr, [x21, lr, lsl #3]
    //     0xa0b840: blr             lr
    // 0xa0b844: tbnz            w0, #4, #0xa0b858
    // 0xa0b848: r0 = Null
    //     0xa0b848: mov             x0, NULL
    // 0xa0b84c: LeaveFrame
    //     0xa0b84c: mov             SP, fp
    //     0xa0b850: ldp             fp, lr, [SP], #0x10
    // 0xa0b854: ret
    //     0xa0b854: ret             
    // 0xa0b858: ldr             x1, [fp, #0x10]
    // 0xa0b85c: r0 = LoadClassIdInstr(r1)
    //     0xa0b85c: ldur            x0, [x1, #-1]
    //     0xa0b860: ubfx            x0, x0, #0xc, #0x14
    // 0xa0b864: r0 = GDT[cid_x0 + 0x140c8]()
    //     0xa0b864: mov             x17, #0x40c8
    //     0xa0b868: movk            x17, #1, lsl #16
    //     0xa0b86c: add             lr, x0, x17
    //     0xa0b870: ldr             lr, [x21, lr, lsl #3]
    //     0xa0b874: blr             lr
    // 0xa0b878: LeaveFrame
    //     0xa0b878: mov             SP, fp
    //     0xa0b87c: ldp             fp, lr, [SP], #0x10
    // 0xa0b880: ret
    //     0xa0b880: ret             
    // 0xa0b884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa0b884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa0b888: b               #0xa0b820
  }
  static _ IterableExtension.lastWhereOrNull(/* No info */) {
    // ** addr: 0xf050c0, size: 0x1a4
    // 0xf050c0: EnterFrame
    //     0xf050c0: stp             fp, lr, [SP, #-0x10]!
    //     0xf050c4: mov             fp, SP
    // 0xf050c8: AllocStack(0x48)
    //     0xf050c8: sub             SP, SP, #0x48
    // 0xf050cc: CheckStackOverflow
    //     0xf050cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf050d0: cmp             SP, x16
    //     0xf050d4: b.ls            #0xf05250
    // 0xf050d8: ldr             x1, [fp, #0x18]
    // 0xf050dc: r0 = iterator()
    //     0xf050dc: bl              #0xb09254  ; [dart:collection] ListQueue::iterator
    // 0xf050e0: stur            x0, [fp, #-0x30]
    // 0xf050e4: LoadField: r3 = r0->field_b
    //     0xf050e4: ldur            w3, [x0, #0xb]
    // 0xf050e8: DecompressPointer r3
    //     0xf050e8: add             x3, x3, HEAP, lsl #32
    // 0xf050ec: stur            x3, [fp, #-0x28]
    // 0xf050f0: ArrayLoad: r4 = r0[0]  ; List_8
    //     0xf050f0: ldur            x4, [x0, #0x17]
    // 0xf050f4: stur            x4, [fp, #-0x20]
    // 0xf050f8: LoadField: r5 = r0->field_f
    //     0xf050f8: ldur            x5, [x0, #0xf]
    // 0xf050fc: stur            x5, [fp, #-0x18]
    // 0xf05100: LoadField: r6 = r0->field_7
    //     0xf05100: ldur            w6, [x0, #7]
    // 0xf05104: DecompressPointer r6
    //     0xf05104: add             x6, x6, HEAP, lsl #32
    // 0xf05108: stur            x6, [fp, #-0x10]
    // 0xf0510c: r7 = Null
    //     0xf0510c: mov             x7, NULL
    // 0xf05110: stur            x7, [fp, #-8]
    // 0xf05114: CheckStackOverflow
    //     0xf05114: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf05118: cmp             SP, x16
    //     0xf0511c: b.ls            #0xf05258
    // 0xf05120: mov             x1, x3
    // 0xf05124: mov             x2, x4
    // 0xf05128: r0 = _checkModification()
    //     0xf05128: bl              #0x802db8  ; [dart:collection] ListQueue::_checkModification
    // 0xf0512c: ldur            x3, [fp, #-0x30]
    // 0xf05130: LoadField: r2 = r3->field_1f
    //     0xf05130: ldur            x2, [x3, #0x1f]
    // 0xf05134: ldur            x4, [fp, #-0x18]
    // 0xf05138: cmp             x2, x4
    // 0xf0513c: b.eq            #0xf05238
    // 0xf05140: ldur            x5, [fp, #-0x28]
    // 0xf05144: LoadField: r6 = r5->field_b
    //     0xf05144: ldur            w6, [x5, #0xb]
    // 0xf05148: DecompressPointer r6
    //     0xf05148: add             x6, x6, HEAP, lsl #32
    // 0xf0514c: LoadField: r0 = r6->field_b
    //     0xf0514c: ldur            w0, [x6, #0xb]
    // 0xf05150: r7 = LoadInt32Instr(r0)
    //     0xf05150: sbfx            x7, x0, #1, #0x1f
    // 0xf05154: mov             x0, x7
    // 0xf05158: mov             x1, x2
    // 0xf0515c: cmp             x1, x0
    // 0xf05160: b.hs            #0xf05260
    // 0xf05164: ArrayLoad: r8 = r6[r2]  ; Unknown_4
    //     0xf05164: add             x16, x6, x2, lsl #2
    //     0xf05168: ldur            w8, [x16, #0xf]
    // 0xf0516c: DecompressPointer r8
    //     0xf0516c: add             x8, x8, HEAP, lsl #32
    // 0xf05170: mov             x0, x8
    // 0xf05174: stur            x8, [fp, #-0x38]
    // 0xf05178: StoreField: r3->field_27 = r0
    //     0xf05178: stur            w0, [x3, #0x27]
    //     0xf0517c: tbz             w0, #0, #0xf05198
    //     0xf05180: ldurb           w16, [x3, #-1]
    //     0xf05184: ldurb           w17, [x0, #-1]
    //     0xf05188: and             x16, x17, x16, lsr #2
    //     0xf0518c: tst             x16, HEAP, lsr #32
    //     0xf05190: b.eq            #0xf05198
    //     0xf05194: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xf05198: ubfx            x2, x2, #0, #0x20
    // 0xf0519c: add             w0, w2, #1
    // 0xf051a0: ubfx            x7, x7, #0, #0x20
    // 0xf051a4: sub             w1, w7, #1
    // 0xf051a8: and             x2, x0, x1
    // 0xf051ac: ubfx            x2, x2, #0, #0x20
    // 0xf051b0: StoreField: r3->field_1f = r2
    //     0xf051b0: stur            x2, [x3, #0x1f]
    // 0xf051b4: cmp             w8, NULL
    // 0xf051b8: b.ne            #0xf051ec
    // 0xf051bc: mov             x0, x8
    // 0xf051c0: ldur            x2, [fp, #-0x10]
    // 0xf051c4: r1 = Null
    //     0xf051c4: mov             x1, NULL
    // 0xf051c8: cmp             w2, NULL
    // 0xf051cc: b.eq            #0xf051ec
    // 0xf051d0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf051d0: ldur            w4, [x2, #0x17]
    // 0xf051d4: DecompressPointer r4
    //     0xf051d4: add             x4, x4, HEAP, lsl #32
    // 0xf051d8: r8 = X0
    //     0xf051d8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf051dc: LoadField: r9 = r4->field_7
    //     0xf051dc: ldur            x9, [x4, #7]
    // 0xf051e0: r3 = Null
    //     0xf051e0: add             x3, PP, #0x9f, lsl #12  ; [pp+0x9fc80] Null
    //     0xf051e4: ldr             x3, [x3, #0xc80]
    // 0xf051e8: blr             x9
    // 0xf051ec: ldr             x16, [fp, #0x10]
    // 0xf051f0: ldur            lr, [fp, #-0x38]
    // 0xf051f4: stp             lr, x16, [SP]
    // 0xf051f8: ldr             x0, [fp, #0x10]
    // 0xf051fc: ClosureCall
    //     0xf051fc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xf05200: ldur            x2, [x0, #0x1f]
    //     0xf05204: blr             x2
    // 0xf05208: r16 = true
    //     0xf05208: add             x16, NULL, #0x20  ; true
    // 0xf0520c: cmp             w0, w16
    // 0xf05210: b.ne            #0xf0521c
    // 0xf05214: ldur            x7, [fp, #-0x38]
    // 0xf05218: b               #0xf05220
    // 0xf0521c: ldur            x7, [fp, #-8]
    // 0xf05220: ldur            x0, [fp, #-0x30]
    // 0xf05224: ldur            x6, [fp, #-0x10]
    // 0xf05228: ldur            x3, [fp, #-0x28]
    // 0xf0522c: ldur            x4, [fp, #-0x20]
    // 0xf05230: ldur            x5, [fp, #-0x18]
    // 0xf05234: b               #0xf05110
    // 0xf05238: mov             x1, x3
    // 0xf0523c: StoreField: r1->field_27 = rNULL
    //     0xf0523c: stur            NULL, [x1, #0x27]
    // 0xf05240: ldur            x0, [fp, #-8]
    // 0xf05244: LeaveFrame
    //     0xf05244: mov             SP, fp
    //     0xf05248: ldp             fp, lr, [SP], #0x10
    // 0xf0524c: ret
    //     0xf0524c: ret             
    // 0xf05250: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf05250: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf05254: b               #0xf050d8
    // 0xf05258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf05258: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf0525c: b               #0xf05120
    // 0xf05260: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf05260: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ IterableExtension.firstOrNull(/* No info */) {
    // ** addr: 0xf10a64, size: 0xa8
    // 0xf10a64: EnterFrame
    //     0xf10a64: stp             fp, lr, [SP, #-0x10]!
    //     0xf10a68: mov             fp, SP
    // 0xf10a6c: AllocStack(0x8)
    //     0xf10a6c: sub             SP, SP, #8
    // 0xf10a70: ldr             x2, [fp, #0x10]
    // 0xf10a74: LoadField: r3 = r2->field_7
    //     0xf10a74: ldur            w3, [x2, #7]
    // 0xf10a78: DecompressPointer r3
    //     0xf10a78: add             x3, x3, HEAP, lsl #32
    // 0xf10a7c: LoadField: r0 = r2->field_b
    //     0xf10a7c: ldur            w0, [x2, #0xb]
    // 0xf10a80: r1 = LoadInt32Instr(r0)
    //     0xf10a80: sbfx            x1, x0, #1, #0x1f
    // 0xf10a84: cmp             x1, #0
    // 0xf10a88: b.gt            #0xf10a9c
    // 0xf10a8c: r0 = Null
    //     0xf10a8c: mov             x0, NULL
    // 0xf10a90: LeaveFrame
    //     0xf10a90: mov             SP, fp
    //     0xf10a94: ldp             fp, lr, [SP], #0x10
    // 0xf10a98: ret
    //     0xf10a98: ret             
    // 0xf10a9c: mov             x0, x1
    // 0xf10aa0: r1 = 0
    //     0xf10aa0: mov             x1, #0
    // 0xf10aa4: cmp             x1, x0
    // 0xf10aa8: b.hs            #0xf10b08
    // 0xf10aac: LoadField: r0 = r2->field_f
    //     0xf10aac: ldur            w0, [x2, #0xf]
    // 0xf10ab0: DecompressPointer r0
    //     0xf10ab0: add             x0, x0, HEAP, lsl #32
    // 0xf10ab4: LoadField: r4 = r0->field_f
    //     0xf10ab4: ldur            w4, [x0, #0xf]
    // 0xf10ab8: DecompressPointer r4
    //     0xf10ab8: add             x4, x4, HEAP, lsl #32
    // 0xf10abc: stur            x4, [fp, #-8]
    // 0xf10ac0: cmp             w4, NULL
    // 0xf10ac4: b.ne            #0xf10af8
    // 0xf10ac8: mov             x0, x4
    // 0xf10acc: mov             x2, x3
    // 0xf10ad0: r1 = Null
    //     0xf10ad0: mov             x1, NULL
    // 0xf10ad4: cmp             w2, NULL
    // 0xf10ad8: b.eq            #0xf10af8
    // 0xf10adc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xf10adc: ldur            w4, [x2, #0x17]
    // 0xf10ae0: DecompressPointer r4
    //     0xf10ae0: add             x4, x4, HEAP, lsl #32
    // 0xf10ae4: r8 = X0
    //     0xf10ae4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xf10ae8: LoadField: r9 = r4->field_7
    //     0xf10ae8: ldur            x9, [x4, #7]
    // 0xf10aec: r3 = Null
    //     0xf10aec: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0290] Null
    //     0xf10af0: ldr             x3, [x3, #0x290]
    // 0xf10af4: blr             x9
    // 0xf10af8: ldur            x0, [fp, #-8]
    // 0xf10afc: LeaveFrame
    //     0xf10afc: mov             SP, fp
    //     0xf10b00: ldp             fp, lr, [SP], #0x10
    // 0xf10b04: ret
    //     0xf10b04: ret             
    // 0xf10b08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xf10b08: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static Iterable<Y1> IterableExtension.expandIndexed<Y0, Y1>(Iterable<Y0>, (dynamic, int, Y0) => Iterable<Y1>) {
    // ** addr: 0x1318be0, size: 0x190
    // 0x1318be0: EnterFrame
    //     0x1318be0: stp             fp, lr, [SP, #-0x10]!
    //     0x1318be4: mov             fp, SP
    // 0x1318be8: AllocStack(0x48)
    //     0x1318be8: sub             SP, SP, #0x48
    // 0x1318bec: SetupParameters(dynamic _ /* r5, fp-0x18 */, dynamic _ /* r6, fp-0x10 */)
    //     0x1318bec: stur            NULL, [fp, #-8]
    //     0x1318bf0: mov             x0, #0
    //     0x1318bf4: add             x5, fp, w0, sxtw #2
    //     0x1318bf8: ldr             x5, [x5, #0x18]
    //     0x1318bfc: stur            x5, [fp, #-0x18]
    //     0x1318c00: add             x6, fp, w0, sxtw #2
    //     0x1318c04: ldr             x6, [x6, #0x10]
    //     0x1318c08: stur            x6, [fp, #-0x10]
    // 0x1318c0c: LoadField: r1 = r4->field_f
    //     0x1318c0c: ldur            w1, [x4, #0xf]
    // 0x1318c10: cbnz            w1, #0x1318c1c
    // 0x1318c14: r1 = Null
    //     0x1318c14: mov             x1, NULL
    // 0x1318c18: b               #0x1318c2c
    // 0x1318c1c: ArrayLoad: r1 = r4[0]  ; List_4
    //     0x1318c1c: ldur            w1, [x4, #0x17]
    // 0x1318c20: add             x2, fp, w1, sxtw #2
    // 0x1318c24: ldr             x2, [x2, #0x10]
    // 0x1318c28: mov             x1, x2
    // 0x1318c2c: CheckStackOverflow
    //     0x1318c2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1318c30: cmp             SP, x16
    //     0x1318c34: b.ls            #0x1318d60
    // 0x1318c38: r2 = Null
    //     0x1318c38: mov             x2, NULL
    // 0x1318c3c: r3 = <Y1>
    //     0x1318c3c: add             x3, PP, #0xaa, lsl #12  ; [pp+0xaab68] TypeArguments: <Y1>
    //     0x1318c40: ldr             x3, [x3, #0xb68]
    // 0x1318c44: r0 = Null
    //     0x1318c44: mov             x0, NULL
    // 0x1318c48: cmp             x2, x0
    // 0x1318c4c: b.ne            #0x1318c58
    // 0x1318c50: cmp             x1, x0
    // 0x1318c54: b.eq            #0x1318c64
    // 0x1318c58: r30 = InstantiateTypeArgumentsStub
    //     0x1318c58: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x1318c5c: LoadField: r30 = r30->field_7
    //     0x1318c5c: ldur            lr, [lr, #7]
    // 0x1318c60: blr             lr
    // 0x1318c64: mov             x1, x0
    // 0x1318c68: stur            x1, [fp, #-0x20]
    // 0x1318c6c: r0 = InitSyncStar()
    //     0x1318c6c: bl              #0x861bac  ; InitSyncStarStub
    // 0x1318c70: r0 = Null
    //     0x1318c70: mov             x0, NULL
    // 0x1318c74: r0 = SuspendSyncStarAtStart()
    //     0x1318c74: bl              #0x861a20  ; SuspendSyncStarAtStartStub
    // 0x1318c78: ldur            x1, [fp, #-0x18]
    // 0x1318c7c: r0 = iterator()
    //     0x1318c7c: bl              #0xb09bdc  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x1318c80: stur            x0, [fp, #-0x18]
    // 0x1318c84: r2 = 0
    //     0x1318c84: mov             x2, #0
    // 0x1318c88: stur            x2, [fp, #-0x28]
    // 0x1318c8c: CheckStackOverflow
    //     0x1318c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1318c90: cmp             SP, x16
    //     0x1318c94: b.ls            #0x1318d68
    // 0x1318c98: mov             x1, x0
    // 0x1318c9c: r0 = moveNext()
    //     0x1318c9c: bl              #0x80261c  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x1318ca0: tbnz            w0, #4, #0x1318d44
    // 0x1318ca4: ldur            x2, [fp, #-0x18]
    // 0x1318ca8: LoadField: r3 = r2->field_2b
    //     0x1318ca8: ldur            w3, [x2, #0x2b]
    // 0x1318cac: DecompressPointer r3
    //     0x1318cac: add             x3, x3, HEAP, lsl #32
    // 0x1318cb0: cmp             w3, NULL
    // 0x1318cb4: b.eq            #0x1318d54
    // 0x1318cb8: ldur            x5, [fp, #-0x28]
    // 0x1318cbc: r4 = 0
    //     0x1318cbc: mov             x4, #0
    // 0x1318cc0: add             x0, fp, w4, sxtw #2
    // 0x1318cc4: LoadField: r0 = r0->field_fffffff8
    //     0x1318cc4: ldur            x0, [x0, #-8]
    // 0x1318cc8: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x1318cc8: ldur            w6, [x0, #0x17]
    // 0x1318ccc: DecompressPointer r6
    //     0x1318ccc: add             x6, x6, HEAP, lsl #32
    // 0x1318cd0: stur            x6, [fp, #-0x20]
    // 0x1318cd4: add             x7, x5, #1
    // 0x1318cd8: stur            x7, [fp, #-0x30]
    // 0x1318cdc: r0 = BoxInt64Instr(r5)
    //     0x1318cdc: sbfiz           x0, x5, #1, #0x1f
    //     0x1318ce0: cmp             x5, x0, asr #1
    //     0x1318ce4: b.eq            #0x1318cf0
    //     0x1318ce8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1318cec: stur            x5, [x0, #7]
    // 0x1318cf0: ldur            x16, [fp, #-0x10]
    // 0x1318cf4: stp             x0, x16, [SP, #8]
    // 0x1318cf8: str             x3, [SP]
    // 0x1318cfc: ldur            x0, [fp, #-0x10]
    // 0x1318d00: ClosureCall
    //     0x1318d00: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x1318d04: ldur            x2, [x0, #0x1f]
    //     0x1318d08: blr             x2
    // 0x1318d0c: ldur            x1, [fp, #-0x20]
    // 0x1318d10: StoreField: r1->field_1b = r0
    //     0x1318d10: stur            w0, [x1, #0x1b]
    //     0x1318d14: tbz             w0, #0, #0x1318d30
    //     0x1318d18: ldurb           w16, [x1, #-1]
    //     0x1318d1c: ldurb           w17, [x0, #-1]
    //     0x1318d20: and             x16, x17, x16, lsr #2
    //     0x1318d24: tst             x16, HEAP, lsr #32
    //     0x1318d28: b.eq            #0x1318d30
    //     0x1318d2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1318d30: r0 = true
    //     0x1318d30: add             x0, NULL, #0x20  ; true
    // 0x1318d34: r0 = SuspendSyncStarAtYield()
    //     0x1318d34: bl              #0x861898  ; SuspendSyncStarAtYieldStub
    // 0x1318d38: ldur            x2, [fp, #-0x30]
    // 0x1318d3c: ldur            x0, [fp, #-0x18]
    // 0x1318d40: b               #0x1318c88
    // 0x1318d44: r0 = false
    //     0x1318d44: add             x0, NULL, #0x30  ; false
    // 0x1318d48: LeaveFrame
    //     0x1318d48: mov             SP, fp
    //     0x1318d4c: ldp             fp, lr, [SP], #0x10
    // 0x1318d50: ret
    //     0x1318d50: ret             
    // 0x1318d54: r0 = noElement()
    //     0x1318d54: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0x1318d58: r0 = Throw()
    //     0x1318d58: bl              #0x13ddb2c  ; ThrowStub
    // 0x1318d5c: brk             #0
    // 0x1318d60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1318d60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1318d64: b               #0x1318c38
    // 0x1318d68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1318d68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1318d6c: b               #0x1318c98
  }
}
