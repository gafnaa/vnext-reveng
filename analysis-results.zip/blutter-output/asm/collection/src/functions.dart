// lib: , url: package:collection/src/functions.dart

// class id: 1048653, size: 0x8
class :: {

  static Map<Y1, List<Y0>> groupBy<Y0, Y1>(Iterable<Y0>, (dynamic, Y0) => Y1) {
    // ** addr: 0x1110b50, size: 0x2b0
    // 0x1110b50: EnterFrame
    //     0x1110b50: stp             fp, lr, [SP, #-0x10]!
    //     0x1110b54: mov             fp, SP
    // 0x1110b58: AllocStack(0x58)
    //     0x1110b58: sub             SP, SP, #0x58
    // 0x1110b5c: SetupParameters([dynamic _, dynamic _ /* r0 */])
    //     0x1110b5c: ldur            w0, [x4, #0xf]
    //     0x1110b60: cbnz            w0, #0x1110b6c
    //     0x1110b64: mov             x4, NULL
    //     0x1110b68: b               #0x1110b7c
    //     0x1110b6c: ldur            w0, [x4, #0x17]
    //     0x1110b70: add             x1, fp, w0, sxtw #2
    //     0x1110b74: ldr             x1, [x1, #0x10]
    //     0x1110b78: mov             x4, x1
    //     0x1110b7c: ldr             x0, [fp, #0x18]
    //     0x1110b80: stur            x4, [fp, #-8]
    // 0x1110b84: CheckStackOverflow
    //     0x1110b84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1110b88: cmp             SP, x16
    //     0x1110b8c: b.ls            #0x1110df0
    // 0x1110b90: mov             x1, x4
    // 0x1110b94: r2 = Null
    //     0x1110b94: mov             x2, NULL
    // 0x1110b98: r3 = <Y1, List<Y0>>
    //     0x1110b98: add             x3, PP, #0xd, lsl #12  ; [pp+0xdb78] TypeArguments: <Y1, List<Y0>>
    //     0x1110b9c: ldr             x3, [x3, #0xb78]
    // 0x1110ba0: r30 = InstantiateTypeArgumentsStub
    //     0x1110ba0: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x1110ba4: LoadField: r30 = r30->field_7
    //     0x1110ba4: ldur            lr, [lr, #7]
    // 0x1110ba8: blr             lr
    // 0x1110bac: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x1110bb0: stp             x16, x0, [SP]
    // 0x1110bb4: r0 = Map._fromLiteral()
    //     0x1110bb4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x1110bb8: mov             x4, x0
    // 0x1110bbc: ldr             x3, [fp, #0x18]
    // 0x1110bc0: stur            x4, [fp, #-0x38]
    // 0x1110bc4: LoadField: r5 = r3->field_7
    //     0x1110bc4: ldur            w5, [x3, #7]
    // 0x1110bc8: DecompressPointer r5
    //     0x1110bc8: add             x5, x5, HEAP, lsl #32
    // 0x1110bcc: stur            x5, [fp, #-0x30]
    // 0x1110bd0: LoadField: r0 = r3->field_b
    //     0x1110bd0: ldur            w0, [x3, #0xb]
    // 0x1110bd4: r6 = LoadInt32Instr(r0)
    //     0x1110bd4: sbfx            x6, x0, #1, #0x1f
    // 0x1110bd8: stur            x6, [fp, #-0x28]
    // 0x1110bdc: LoadField: r7 = r4->field_7
    //     0x1110bdc: ldur            w7, [x4, #7]
    // 0x1110be0: DecompressPointer r7
    //     0x1110be0: add             x7, x7, HEAP, lsl #32
    // 0x1110be4: stur            x7, [fp, #-0x20]
    // 0x1110be8: r0 = 0
    //     0x1110be8: mov             x0, #0
    // 0x1110bec: CheckStackOverflow
    //     0x1110bec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1110bf0: cmp             SP, x16
    //     0x1110bf4: b.ls            #0x1110df8
    // 0x1110bf8: LoadField: r1 = r3->field_b
    //     0x1110bf8: ldur            w1, [x3, #0xb]
    // 0x1110bfc: r2 = LoadInt32Instr(r1)
    //     0x1110bfc: sbfx            x2, x1, #1, #0x1f
    // 0x1110c00: cmp             x6, x2
    // 0x1110c04: b.ne            #0x1110dd0
    // 0x1110c08: cmp             x0, x2
    // 0x1110c0c: b.ge            #0x1110dc0
    // 0x1110c10: LoadField: r1 = r3->field_f
    //     0x1110c10: ldur            w1, [x3, #0xf]
    // 0x1110c14: DecompressPointer r1
    //     0x1110c14: add             x1, x1, HEAP, lsl #32
    // 0x1110c18: ArrayLoad: r8 = r1[r0]  ; Unknown_4
    //     0x1110c18: add             x16, x1, x0, lsl #2
    //     0x1110c1c: ldur            w8, [x16, #0xf]
    // 0x1110c20: DecompressPointer r8
    //     0x1110c20: add             x8, x8, HEAP, lsl #32
    // 0x1110c24: stur            x8, [fp, #-0x18]
    // 0x1110c28: add             x9, x0, #1
    // 0x1110c2c: stur            x9, [fp, #-0x10]
    // 0x1110c30: cmp             w8, NULL
    // 0x1110c34: b.ne            #0x1110c68
    // 0x1110c38: mov             x0, x8
    // 0x1110c3c: mov             x2, x5
    // 0x1110c40: r1 = Null
    //     0x1110c40: mov             x1, NULL
    // 0x1110c44: cmp             w2, NULL
    // 0x1110c48: b.eq            #0x1110c68
    // 0x1110c4c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1110c4c: ldur            w4, [x2, #0x17]
    // 0x1110c50: DecompressPointer r4
    //     0x1110c50: add             x4, x4, HEAP, lsl #32
    // 0x1110c54: r8 = X0
    //     0x1110c54: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1110c58: LoadField: r9 = r4->field_7
    //     0x1110c58: ldur            x9, [x4, #7]
    // 0x1110c5c: r3 = Null
    //     0x1110c5c: add             x3, PP, #0xd, lsl #12  ; [pp+0xdb80] Null
    //     0x1110c60: ldr             x3, [x3, #0xb80]
    // 0x1110c64: blr             x9
    // 0x1110c68: ldur            x1, [fp, #-0x38]
    // 0x1110c6c: ldr             x16, [fp, #0x10]
    // 0x1110c70: ldur            lr, [fp, #-0x18]
    // 0x1110c74: stp             lr, x16, [SP]
    // 0x1110c78: ldr             x0, [fp, #0x10]
    // 0x1110c7c: ClosureCall
    //     0x1110c7c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x1110c80: ldur            x2, [x0, #0x1f]
    //     0x1110c84: blr             x2
    // 0x1110c88: mov             x4, x0
    // 0x1110c8c: ldur            x3, [fp, #-0x38]
    // 0x1110c90: stur            x4, [fp, #-0x40]
    // 0x1110c94: r0 = LoadClassIdInstr(r3)
    //     0x1110c94: ldur            x0, [x3, #-1]
    //     0x1110c98: ubfx            x0, x0, #0xc, #0x14
    // 0x1110c9c: mov             x1, x3
    // 0x1110ca0: mov             x2, x4
    // 0x1110ca4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x1110ca4: sub             lr, x0, #0xd48
    //     0x1110ca8: ldr             lr, [x21, lr, lsl #3]
    //     0x1110cac: blr             lr
    // 0x1110cb0: mov             x1, x0
    // 0x1110cb4: cmp             w1, NULL
    // 0x1110cb8: b.ne            #0x1110d78
    // 0x1110cbc: ldur            x1, [fp, #-8]
    // 0x1110cc0: r0 = AllocateGrowableArray()
    //     0x1110cc0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1110cc4: mov             x4, x0
    // 0x1110cc8: r3 = const []
    //     0x1110cc8: ldr             x3, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0x1110ccc: stur            x4, [fp, #-0x48]
    // 0x1110cd0: StoreField: r4->field_f = r3
    //     0x1110cd0: stur            w3, [x4, #0xf]
    // 0x1110cd4: StoreField: r4->field_b = rZR
    //     0x1110cd4: stur            wzr, [x4, #0xb]
    // 0x1110cd8: ldur            x0, [fp, #-0x40]
    // 0x1110cdc: ldur            x2, [fp, #-0x20]
    // 0x1110ce0: r1 = Null
    //     0x1110ce0: mov             x1, NULL
    // 0x1110ce4: cmp             w2, NULL
    // 0x1110ce8: b.eq            #0x1110d08
    // 0x1110cec: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1110cec: ldur            w4, [x2, #0x17]
    // 0x1110cf0: DecompressPointer r4
    //     0x1110cf0: add             x4, x4, HEAP, lsl #32
    // 0x1110cf4: r8 = X0
    //     0x1110cf4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1110cf8: LoadField: r9 = r4->field_7
    //     0x1110cf8: ldur            x9, [x4, #7]
    // 0x1110cfc: r3 = Null
    //     0x1110cfc: add             x3, PP, #0xd, lsl #12  ; [pp+0xdb90] Null
    //     0x1110d00: ldr             x3, [x3, #0xb90]
    // 0x1110d04: blr             x9
    // 0x1110d08: ldur            x0, [fp, #-0x48]
    // 0x1110d0c: ldur            x2, [fp, #-0x20]
    // 0x1110d10: r1 = Null
    //     0x1110d10: mov             x1, NULL
    // 0x1110d14: cmp             w2, NULL
    // 0x1110d18: b.eq            #0x1110d38
    // 0x1110d1c: LoadField: r4 = r2->field_1b
    //     0x1110d1c: ldur            w4, [x2, #0x1b]
    // 0x1110d20: DecompressPointer r4
    //     0x1110d20: add             x4, x4, HEAP, lsl #32
    // 0x1110d24: r8 = X1
    //     0x1110d24: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x1110d28: LoadField: r9 = r4->field_7
    //     0x1110d28: ldur            x9, [x4, #7]
    // 0x1110d2c: r3 = Null
    //     0x1110d2c: add             x3, PP, #0xd, lsl #12  ; [pp+0xdba0] Null
    //     0x1110d30: ldr             x3, [x3, #0xba0]
    // 0x1110d34: blr             x9
    // 0x1110d38: ldur            x1, [fp, #-0x38]
    // 0x1110d3c: ldur            x2, [fp, #-0x40]
    // 0x1110d40: r0 = _hashCode()
    //     0x1110d40: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x1110d44: mov             x2, x0
    // 0x1110d48: r0 = BoxInt64Instr(r2)
    //     0x1110d48: sbfiz           x0, x2, #1, #0x1f
    //     0x1110d4c: cmp             x2, x0, asr #1
    //     0x1110d50: b.eq            #0x1110d5c
    //     0x1110d54: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1110d58: stur            x2, [x0, #7]
    // 0x1110d5c: ldur            x1, [fp, #-0x38]
    // 0x1110d60: ldur            x2, [fp, #-0x40]
    // 0x1110d64: ldur            x3, [fp, #-0x48]
    // 0x1110d68: mov             x5, x0
    // 0x1110d6c: r0 = _set()
    //     0x1110d6c: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x1110d70: ldur            x0, [fp, #-0x48]
    // 0x1110d74: b               #0x1110d7c
    // 0x1110d78: mov             x0, x1
    // 0x1110d7c: r1 = LoadClassIdInstr(r0)
    //     0x1110d7c: ldur            x1, [x0, #-1]
    //     0x1110d80: ubfx            x1, x1, #0xc, #0x14
    // 0x1110d84: ldur            x16, [fp, #-0x18]
    // 0x1110d88: stp             x16, x0, [SP]
    // 0x1110d8c: mov             x0, x1
    // 0x1110d90: r0 = GDT[cid_x0 + 0x175da]()
    //     0x1110d90: mov             x17, #0x75da
    //     0x1110d94: movk            x17, #1, lsl #16
    //     0x1110d98: add             lr, x0, x17
    //     0x1110d9c: ldr             lr, [x21, lr, lsl #3]
    //     0x1110da0: blr             lr
    // 0x1110da4: ldur            x0, [fp, #-0x10]
    // 0x1110da8: ldr             x3, [fp, #0x18]
    // 0x1110dac: ldur            x4, [fp, #-0x38]
    // 0x1110db0: ldur            x7, [fp, #-0x20]
    // 0x1110db4: ldur            x5, [fp, #-0x30]
    // 0x1110db8: ldur            x6, [fp, #-0x28]
    // 0x1110dbc: b               #0x1110bec
    // 0x1110dc0: ldur            x0, [fp, #-0x38]
    // 0x1110dc4: LeaveFrame
    //     0x1110dc4: mov             SP, fp
    //     0x1110dc8: ldp             fp, lr, [SP], #0x10
    // 0x1110dcc: ret
    //     0x1110dcc: ret             
    // 0x1110dd0: mov             x0, x3
    // 0x1110dd4: r0 = ConcurrentModificationError()
    //     0x1110dd4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x1110dd8: mov             x1, x0
    // 0x1110ddc: ldr             x0, [fp, #0x18]
    // 0x1110de0: StoreField: r1->field_b = r0
    //     0x1110de0: stur            w0, [x1, #0xb]
    // 0x1110de4: mov             x0, x1
    // 0x1110de8: r0 = Throw()
    //     0x1110de8: bl              #0x13ddb2c  ; ThrowStub
    // 0x1110dec: brk             #0
    // 0x1110df0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1110df0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1110df4: b               #0x1110b90
    // 0x1110df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1110df8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1110dfc: b               #0x1110bf8
  }
}
