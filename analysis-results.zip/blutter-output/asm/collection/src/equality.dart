// lib: , url: package:collection/src/equality.dart

// class id: 1048652, size: 0x8
class :: {
}

// class id: 3569, size: 0x10, field offset: 0x8
//   const constructor, 
class DeepCollectionEquality extends Object
    implements Equality<X0> {

  DefaultEquality<Never> field_8;
  bool field_c;

  [closure] bool isValidKey(dynamic, Object?) {
    // ** addr: 0xb04fcc, size: 0x3c
    // 0xb04fcc: EnterFrame
    //     0xb04fcc: stp             fp, lr, [SP, #-0x10]!
    //     0xb04fd0: mov             fp, SP
    // 0xb04fd4: ldr             x0, [fp, #0x18]
    // 0xb04fd8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb04fd8: ldur            w1, [x0, #0x17]
    // 0xb04fdc: DecompressPointer r1
    //     0xb04fdc: add             x1, x1, HEAP, lsl #32
    // 0xb04fe0: CheckStackOverflow
    //     0xb04fe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb04fe4: cmp             SP, x16
    //     0xb04fe8: b.ls            #0xb05000
    // 0xb04fec: ldr             x2, [fp, #0x10]
    // 0xb04ff0: r0 = isValidKey()
    //     0xb04ff0: bl              #0xb050b4  ; [package:collection/src/equality.dart] DeepCollectionEquality::isValidKey
    // 0xb04ff4: LeaveFrame
    //     0xb04ff4: mov             SP, fp
    //     0xb04ff8: ldp             fp, lr, [SP], #0x10
    // 0xb04ffc: ret
    //     0xb04ffc: ret             
    // 0xb05000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb05000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb05004: b               #0xb04fec
  }
  _ isValidKey(/* No info */) {
    // ** addr: 0xb050b4, size: 0x198
    // 0xb050b4: EnterFrame
    //     0xb050b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb050b8: mov             fp, SP
    // 0xb050bc: AllocStack(0x8)
    //     0xb050bc: sub             SP, SP, #8
    // 0xb050c0: SetupParameters(DeepCollectionEquality this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xb050c0: mov             x0, x2
    //     0xb050c4: mov             x4, x1
    //     0xb050c8: mov             x3, x2
    //     0xb050cc: stur            x2, [fp, #-8]
    // 0xb050d0: r2 = Null
    //     0xb050d0: mov             x2, NULL
    // 0xb050d4: r1 = Null
    //     0xb050d4: mov             x1, NULL
    // 0xb050d8: cmp             w0, NULL
    // 0xb050dc: b.eq            #0xb05174
    // 0xb050e0: branchIfSmi(r0, 0xb05174)
    //     0xb050e0: tbz             w0, #0, #0xb05174
    // 0xb050e4: r3 = LoadClassIdInstr(r0)
    //     0xb050e4: ldur            x3, [x0, #-1]
    //     0xb050e8: ubfx            x3, x3, #0xc, #0x14
    // 0xb050ec: r17 = 7635
    //     0xb050ec: mov             x17, #0x1dd3
    // 0xb050f0: cmp             x3, x17
    // 0xb050f4: b.eq            #0xb0517c
    // 0xb050f8: r4 = LoadClassIdInstr(r0)
    //     0xb050f8: ldur            x4, [x0, #-1]
    //     0xb050fc: ubfx            x4, x4, #0xc, #0x14
    // 0xb05100: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xb05104: ldr             x3, [x3, #0x18]
    // 0xb05108: ldr             x3, [x3, x4, lsl #3]
    // 0xb0510c: LoadField: r3 = r3->field_2b
    //     0xb0510c: ldur            w3, [x3, #0x2b]
    // 0xb05110: DecompressPointer r3
    //     0xb05110: add             x3, x3, HEAP, lsl #32
    // 0xb05114: cmp             w3, NULL
    // 0xb05118: b.eq            #0xb05174
    // 0xb0511c: LoadField: r3 = r3->field_f
    //     0xb0511c: ldur            w3, [x3, #0xf]
    // 0xb05120: lsr             x3, x3, #3
    // 0xb05124: r17 = 7635
    //     0xb05124: mov             x17, #0x1dd3
    // 0xb05128: cmp             x3, x17
    // 0xb0512c: b.eq            #0xb0517c
    // 0xb05130: r3 = SubtypeTestCache
    //     0xb05130: add             x3, PP, #0x12, lsl #12  ; [pp+0x12760] SubtypeTestCache
    //     0xb05134: ldr             x3, [x3, #0x760]
    // 0xb05138: r30 = Subtype1TestCacheStub
    //     0xb05138: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xb0513c: LoadField: r30 = r30->field_7
    //     0xb0513c: ldur            lr, [lr, #7]
    // 0xb05140: blr             lr
    // 0xb05144: cmp             w7, NULL
    // 0xb05148: b.eq            #0xb05154
    // 0xb0514c: tbnz            w7, #4, #0xb05174
    // 0xb05150: b               #0xb0517c
    // 0xb05154: r8 = Iterable
    //     0xb05154: add             x8, PP, #0x12, lsl #12  ; [pp+0x12768] Type: Iterable
    //     0xb05158: ldr             x8, [x8, #0x768]
    // 0xb0515c: r3 = SubtypeTestCache
    //     0xb0515c: add             x3, PP, #0x12, lsl #12  ; [pp+0x12770] SubtypeTestCache
    //     0xb05160: ldr             x3, [x3, #0x770]
    // 0xb05164: r30 = InstanceOfStub
    //     0xb05164: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xb05168: LoadField: r30 = r30->field_7
    //     0xb05168: ldur            lr, [lr, #7]
    // 0xb0516c: blr             lr
    // 0xb05170: b               #0xb05180
    // 0xb05174: r0 = false
    //     0xb05174: add             x0, NULL, #0x30  ; false
    // 0xb05178: b               #0xb05180
    // 0xb0517c: r0 = true
    //     0xb0517c: add             x0, NULL, #0x20  ; true
    // 0xb05180: tbz             w0, #4, #0xb0523c
    // 0xb05184: ldur            x0, [fp, #-8]
    // 0xb05188: r2 = Null
    //     0xb05188: mov             x2, NULL
    // 0xb0518c: r1 = Null
    //     0xb0518c: mov             x1, NULL
    // 0xb05190: cmp             w0, NULL
    // 0xb05194: b.eq            #0xb0522c
    // 0xb05198: branchIfSmi(r0, 0xb0522c)
    //     0xb05198: tbz             w0, #0, #0xb0522c
    // 0xb0519c: r3 = LoadClassIdInstr(r0)
    //     0xb0519c: ldur            x3, [x0, #-1]
    //     0xb051a0: ubfx            x3, x3, #0xc, #0x14
    // 0xb051a4: r17 = 7630
    //     0xb051a4: mov             x17, #0x1dce
    // 0xb051a8: cmp             x3, x17
    // 0xb051ac: b.eq            #0xb05234
    // 0xb051b0: r4 = LoadClassIdInstr(r0)
    //     0xb051b0: ldur            x4, [x0, #-1]
    //     0xb051b4: ubfx            x4, x4, #0xc, #0x14
    // 0xb051b8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xb051bc: ldr             x3, [x3, #0x18]
    // 0xb051c0: ldr             x3, [x3, x4, lsl #3]
    // 0xb051c4: LoadField: r3 = r3->field_2b
    //     0xb051c4: ldur            w3, [x3, #0x2b]
    // 0xb051c8: DecompressPointer r3
    //     0xb051c8: add             x3, x3, HEAP, lsl #32
    // 0xb051cc: cmp             w3, NULL
    // 0xb051d0: b.eq            #0xb0522c
    // 0xb051d4: LoadField: r3 = r3->field_f
    //     0xb051d4: ldur            w3, [x3, #0xf]
    // 0xb051d8: lsr             x3, x3, #3
    // 0xb051dc: r17 = 7630
    //     0xb051dc: mov             x17, #0x1dce
    // 0xb051e0: cmp             x3, x17
    // 0xb051e4: b.eq            #0xb05234
    // 0xb051e8: r3 = SubtypeTestCache
    //     0xb051e8: add             x3, PP, #0x12, lsl #12  ; [pp+0x12778] SubtypeTestCache
    //     0xb051ec: ldr             x3, [x3, #0x778]
    // 0xb051f0: r30 = Subtype1TestCacheStub
    //     0xb051f0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xb051f4: LoadField: r30 = r30->field_7
    //     0xb051f4: ldur            lr, [lr, #7]
    // 0xb051f8: blr             lr
    // 0xb051fc: cmp             w7, NULL
    // 0xb05200: b.eq            #0xb0520c
    // 0xb05204: tbnz            w7, #4, #0xb0522c
    // 0xb05208: b               #0xb05234
    // 0xb0520c: r8 = Map
    //     0xb0520c: add             x8, PP, #0x12, lsl #12  ; [pp+0x12780] Type: Map
    //     0xb05210: ldr             x8, [x8, #0x780]
    // 0xb05214: r3 = SubtypeTestCache
    //     0xb05214: add             x3, PP, #0x12, lsl #12  ; [pp+0x12788] SubtypeTestCache
    //     0xb05218: ldr             x3, [x3, #0x788]
    // 0xb0521c: r30 = InstanceOfStub
    //     0xb0521c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xb05220: LoadField: r30 = r30->field_7
    //     0xb05220: ldur            lr, [lr, #7]
    // 0xb05224: blr             lr
    // 0xb05228: b               #0xb05238
    // 0xb0522c: r0 = false
    //     0xb0522c: add             x0, NULL, #0x30  ; false
    // 0xb05230: b               #0xb05238
    // 0xb05234: r0 = true
    //     0xb05234: add             x0, NULL, #0x20  ; true
    // 0xb05238: tbz             w0, #4, #0xb0523c
    // 0xb0523c: r0 = true
    //     0xb0523c: add             x0, NULL, #0x20  ; true
    // 0xb05240: LeaveFrame
    //     0xb05240: mov             SP, fp
    //     0xb05244: ldp             fp, lr, [SP], #0x10
    // 0xb05248: ret
    //     0xb05248: ret             
  }
  [closure] int hash(dynamic, Object?) {
    // ** addr: 0x12e7bf4, size: 0x54
    // 0x12e7bf4: EnterFrame
    //     0x12e7bf4: stp             fp, lr, [SP, #-0x10]!
    //     0x12e7bf8: mov             fp, SP
    // 0x12e7bfc: ldr             x0, [fp, #0x18]
    // 0x12e7c00: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12e7c00: ldur            w1, [x0, #0x17]
    // 0x12e7c04: DecompressPointer r1
    //     0x12e7c04: add             x1, x1, HEAP, lsl #32
    // 0x12e7c08: CheckStackOverflow
    //     0x12e7c08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7c0c: cmp             SP, x16
    //     0x12e7c10: b.ls            #0x12e7c40
    // 0x12e7c14: ldr             x2, [fp, #0x10]
    // 0x12e7c18: r0 = hash()
    //     0x12e7c18: bl              #0x12e914c  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0x12e7c1c: mov             x2, x0
    // 0x12e7c20: r0 = BoxInt64Instr(r2)
    //     0x12e7c20: sbfiz           x0, x2, #1, #0x1f
    //     0x12e7c24: cmp             x2, x0, asr #1
    //     0x12e7c28: b.eq            #0x12e7c34
    //     0x12e7c2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e7c30: stur            x2, [x0, #7]
    // 0x12e7c34: LeaveFrame
    //     0x12e7c34: mov             SP, fp
    //     0x12e7c38: ldp             fp, lr, [SP], #0x10
    // 0x12e7c3c: ret
    //     0x12e7c3c: ret             
    // 0x12e7c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e7c40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e7c44: b               #0x12e7c14
  }
  [closure] bool equals(dynamic, Object?, Object?) {
    // ** addr: 0x12e7c48, size: 0x40
    // 0x12e7c48: EnterFrame
    //     0x12e7c48: stp             fp, lr, [SP, #-0x10]!
    //     0x12e7c4c: mov             fp, SP
    // 0x12e7c50: ldr             x0, [fp, #0x20]
    // 0x12e7c54: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x12e7c54: ldur            w1, [x0, #0x17]
    // 0x12e7c58: DecompressPointer r1
    //     0x12e7c58: add             x1, x1, HEAP, lsl #32
    // 0x12e7c5c: CheckStackOverflow
    //     0x12e7c5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7c60: cmp             SP, x16
    //     0x12e7c64: b.ls            #0x12e7c80
    // 0x12e7c68: ldr             x2, [fp, #0x18]
    // 0x12e7c6c: ldr             x3, [fp, #0x10]
    // 0x12e7c70: r0 = equals()
    //     0x12e7c70: bl              #0x12e82b0  ; [package:collection/src/equality.dart] DeepCollectionEquality::equals
    // 0x12e7c74: LeaveFrame
    //     0x12e7c74: mov             SP, fp
    //     0x12e7c78: ldp             fp, lr, [SP], #0x10
    // 0x12e7c7c: ret
    //     0x12e7c7c: ret             
    // 0x12e7c80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e7c80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e7c84: b               #0x12e7c68
  }
  _ equals(/* No info */) {
    // ** addr: 0x12e82b0, size: 0x720
    // 0x12e82b0: EnterFrame
    //     0x12e82b0: stp             fp, lr, [SP, #-0x10]!
    //     0x12e82b4: mov             fp, SP
    // 0x12e82b8: AllocStack(0x18)
    //     0x12e82b8: sub             SP, SP, #0x18
    // 0x12e82bc: SetupParameters(DeepCollectionEquality this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x12e82bc: mov             x5, x1
    //     0x12e82c0: mov             x4, x2
    //     0x12e82c4: stur            x1, [fp, #-8]
    //     0x12e82c8: stur            x2, [fp, #-0x10]
    //     0x12e82cc: stur            x3, [fp, #-0x18]
    // 0x12e82d0: CheckStackOverflow
    //     0x12e82d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e82d4: cmp             SP, x16
    //     0x12e82d8: b.ls            #0x12e89c8
    // 0x12e82dc: mov             x0, x4
    // 0x12e82e0: r2 = Null
    //     0x12e82e0: mov             x2, NULL
    // 0x12e82e4: r1 = Null
    //     0x12e82e4: mov             x1, NULL
    // 0x12e82e8: cmp             w0, NULL
    // 0x12e82ec: b.eq            #0x12e8384
    // 0x12e82f0: branchIfSmi(r0, 0x12e8384)
    //     0x12e82f0: tbz             w0, #0, #0x12e8384
    // 0x12e82f4: r3 = LoadClassIdInstr(r0)
    //     0x12e82f4: ldur            x3, [x0, #-1]
    //     0x12e82f8: ubfx            x3, x3, #0xc, #0x14
    // 0x12e82fc: r17 = 7623
    //     0x12e82fc: mov             x17, #0x1dc7
    // 0x12e8300: cmp             x3, x17
    // 0x12e8304: b.eq            #0x12e838c
    // 0x12e8308: r4 = LoadClassIdInstr(r0)
    //     0x12e8308: ldur            x4, [x0, #-1]
    //     0x12e830c: ubfx            x4, x4, #0xc, #0x14
    // 0x12e8310: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e8314: ldr             x3, [x3, #0x18]
    // 0x12e8318: ldr             x3, [x3, x4, lsl #3]
    // 0x12e831c: LoadField: r3 = r3->field_2b
    //     0x12e831c: ldur            w3, [x3, #0x2b]
    // 0x12e8320: DecompressPointer r3
    //     0x12e8320: add             x3, x3, HEAP, lsl #32
    // 0x12e8324: cmp             w3, NULL
    // 0x12e8328: b.eq            #0x12e8384
    // 0x12e832c: LoadField: r3 = r3->field_f
    //     0x12e832c: ldur            w3, [x3, #0xf]
    // 0x12e8330: lsr             x3, x3, #3
    // 0x12e8334: r17 = 7623
    //     0x12e8334: mov             x17, #0x1dc7
    // 0x12e8338: cmp             x3, x17
    // 0x12e833c: b.eq            #0x12e838c
    // 0x12e8340: r3 = SubtypeTestCache
    //     0x12e8340: add             x3, PP, #0x81, lsl #12  ; [pp+0x810d8] SubtypeTestCache
    //     0x12e8344: ldr             x3, [x3, #0xd8]
    // 0x12e8348: r30 = Subtype1TestCacheStub
    //     0x12e8348: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e834c: LoadField: r30 = r30->field_7
    //     0x12e834c: ldur            lr, [lr, #7]
    // 0x12e8350: blr             lr
    // 0x12e8354: cmp             w7, NULL
    // 0x12e8358: b.eq            #0x12e8364
    // 0x12e835c: tbnz            w7, #4, #0x12e8384
    // 0x12e8360: b               #0x12e838c
    // 0x12e8364: r8 = Set
    //     0x12e8364: add             x8, PP, #0x81, lsl #12  ; [pp+0x810e0] Type: Set
    //     0x12e8368: ldr             x8, [x8, #0xe0]
    // 0x12e836c: r3 = SubtypeTestCache
    //     0x12e836c: add             x3, PP, #0x81, lsl #12  ; [pp+0x810e8] SubtypeTestCache
    //     0x12e8370: ldr             x3, [x3, #0xe8]
    // 0x12e8374: r30 = InstanceOfStub
    //     0x12e8374: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e8378: LoadField: r30 = r30->field_7
    //     0x12e8378: ldur            lr, [lr, #7]
    // 0x12e837c: blr             lr
    // 0x12e8380: b               #0x12e8390
    // 0x12e8384: r0 = false
    //     0x12e8384: add             x0, NULL, #0x30  ; false
    // 0x12e8388: b               #0x12e8390
    // 0x12e838c: r0 = true
    //     0x12e838c: add             x0, NULL, #0x20  ; true
    // 0x12e8390: tbnz            w0, #4, #0x12e8488
    // 0x12e8394: ldur            x0, [fp, #-0x18]
    // 0x12e8398: r2 = Null
    //     0x12e8398: mov             x2, NULL
    // 0x12e839c: r1 = Null
    //     0x12e839c: mov             x1, NULL
    // 0x12e83a0: cmp             w0, NULL
    // 0x12e83a4: b.eq            #0x12e843c
    // 0x12e83a8: branchIfSmi(r0, 0x12e843c)
    //     0x12e83a8: tbz             w0, #0, #0x12e843c
    // 0x12e83ac: r3 = LoadClassIdInstr(r0)
    //     0x12e83ac: ldur            x3, [x0, #-1]
    //     0x12e83b0: ubfx            x3, x3, #0xc, #0x14
    // 0x12e83b4: r17 = 7623
    //     0x12e83b4: mov             x17, #0x1dc7
    // 0x12e83b8: cmp             x3, x17
    // 0x12e83bc: b.eq            #0x12e8444
    // 0x12e83c0: r4 = LoadClassIdInstr(r0)
    //     0x12e83c0: ldur            x4, [x0, #-1]
    //     0x12e83c4: ubfx            x4, x4, #0xc, #0x14
    // 0x12e83c8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e83cc: ldr             x3, [x3, #0x18]
    // 0x12e83d0: ldr             x3, [x3, x4, lsl #3]
    // 0x12e83d4: LoadField: r3 = r3->field_2b
    //     0x12e83d4: ldur            w3, [x3, #0x2b]
    // 0x12e83d8: DecompressPointer r3
    //     0x12e83d8: add             x3, x3, HEAP, lsl #32
    // 0x12e83dc: cmp             w3, NULL
    // 0x12e83e0: b.eq            #0x12e843c
    // 0x12e83e4: LoadField: r3 = r3->field_f
    //     0x12e83e4: ldur            w3, [x3, #0xf]
    // 0x12e83e8: lsr             x3, x3, #3
    // 0x12e83ec: r17 = 7623
    //     0x12e83ec: mov             x17, #0x1dc7
    // 0x12e83f0: cmp             x3, x17
    // 0x12e83f4: b.eq            #0x12e8444
    // 0x12e83f8: r3 = SubtypeTestCache
    //     0x12e83f8: add             x3, PP, #0x81, lsl #12  ; [pp+0x810f0] SubtypeTestCache
    //     0x12e83fc: ldr             x3, [x3, #0xf0]
    // 0x12e8400: r30 = Subtype1TestCacheStub
    //     0x12e8400: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e8404: LoadField: r30 = r30->field_7
    //     0x12e8404: ldur            lr, [lr, #7]
    // 0x12e8408: blr             lr
    // 0x12e840c: cmp             w7, NULL
    // 0x12e8410: b.eq            #0x12e841c
    // 0x12e8414: tbnz            w7, #4, #0x12e843c
    // 0x12e8418: b               #0x12e8444
    // 0x12e841c: r8 = Set
    //     0x12e841c: add             x8, PP, #0x81, lsl #12  ; [pp+0x810f8] Type: Set
    //     0x12e8420: ldr             x8, [x8, #0xf8]
    // 0x12e8424: r3 = SubtypeTestCache
    //     0x12e8424: add             x3, PP, #0x81, lsl #12  ; [pp+0x81100] SubtypeTestCache
    //     0x12e8428: ldr             x3, [x3, #0x100]
    // 0x12e842c: r30 = InstanceOfStub
    //     0x12e842c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e8430: LoadField: r30 = r30->field_7
    //     0x12e8430: ldur            lr, [lr, #7]
    // 0x12e8434: blr             lr
    // 0x12e8438: b               #0x12e8448
    // 0x12e843c: r0 = false
    //     0x12e843c: add             x0, NULL, #0x30  ; false
    // 0x12e8440: b               #0x12e8448
    // 0x12e8444: r0 = true
    //     0x12e8444: add             x0, NULL, #0x20  ; true
    // 0x12e8448: tbnz            w0, #4, #0x12e8478
    // 0x12e844c: ldur            x0, [fp, #-8]
    // 0x12e8450: r1 = <dynamic, Set, dynamic>
    //     0x12e8450: add             x1, PP, #0x81, lsl #12  ; [pp+0x81040] TypeArguments: <dynamic, Set, dynamic>
    //     0x12e8454: ldr             x1, [x1, #0x40]
    // 0x12e8458: r0 = SetEquality()
    //     0x12e8458: bl              #0x12e89e8  ; AllocateSetEqualityStub -> SetEquality<C2X0> (size=0x10)
    // 0x12e845c: ldur            x3, [fp, #-8]
    // 0x12e8460: StoreField: r0->field_b = r3
    //     0x12e8460: stur            w3, [x0, #0xb]
    // 0x12e8464: mov             x1, x0
    // 0x12e8468: ldur            x2, [fp, #-0x10]
    // 0x12e846c: ldur            x3, [fp, #-0x18]
    // 0x12e8470: r0 = equals()
    //     0x12e8470: bl              #0x12e77dc  ; [package:collection/src/equality.dart] _UnorderedEquality::equals
    // 0x12e8474: b               #0x12e847c
    // 0x12e8478: r0 = false
    //     0x12e8478: add             x0, NULL, #0x30  ; false
    // 0x12e847c: LeaveFrame
    //     0x12e847c: mov             SP, fp
    //     0x12e8480: ldp             fp, lr, [SP], #0x10
    // 0x12e8484: ret
    //     0x12e8484: ret             
    // 0x12e8488: ldur            x3, [fp, #-8]
    // 0x12e848c: ldur            x0, [fp, #-0x10]
    // 0x12e8490: r2 = Null
    //     0x12e8490: mov             x2, NULL
    // 0x12e8494: r1 = Null
    //     0x12e8494: mov             x1, NULL
    // 0x12e8498: cmp             w0, NULL
    // 0x12e849c: b.eq            #0x12e8534
    // 0x12e84a0: branchIfSmi(r0, 0x12e8534)
    //     0x12e84a0: tbz             w0, #0, #0x12e8534
    // 0x12e84a4: r3 = LoadClassIdInstr(r0)
    //     0x12e84a4: ldur            x3, [x0, #-1]
    //     0x12e84a8: ubfx            x3, x3, #0xc, #0x14
    // 0x12e84ac: r17 = 7630
    //     0x12e84ac: mov             x17, #0x1dce
    // 0x12e84b0: cmp             x3, x17
    // 0x12e84b4: b.eq            #0x12e853c
    // 0x12e84b8: r4 = LoadClassIdInstr(r0)
    //     0x12e84b8: ldur            x4, [x0, #-1]
    //     0x12e84bc: ubfx            x4, x4, #0xc, #0x14
    // 0x12e84c0: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e84c4: ldr             x3, [x3, #0x18]
    // 0x12e84c8: ldr             x3, [x3, x4, lsl #3]
    // 0x12e84cc: LoadField: r3 = r3->field_2b
    //     0x12e84cc: ldur            w3, [x3, #0x2b]
    // 0x12e84d0: DecompressPointer r3
    //     0x12e84d0: add             x3, x3, HEAP, lsl #32
    // 0x12e84d4: cmp             w3, NULL
    // 0x12e84d8: b.eq            #0x12e8534
    // 0x12e84dc: LoadField: r3 = r3->field_f
    //     0x12e84dc: ldur            w3, [x3, #0xf]
    // 0x12e84e0: lsr             x3, x3, #3
    // 0x12e84e4: r17 = 7630
    //     0x12e84e4: mov             x17, #0x1dce
    // 0x12e84e8: cmp             x3, x17
    // 0x12e84ec: b.eq            #0x12e853c
    // 0x12e84f0: r3 = SubtypeTestCache
    //     0x12e84f0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81108] SubtypeTestCache
    //     0x12e84f4: ldr             x3, [x3, #0x108]
    // 0x12e84f8: r30 = Subtype1TestCacheStub
    //     0x12e84f8: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e84fc: LoadField: r30 = r30->field_7
    //     0x12e84fc: ldur            lr, [lr, #7]
    // 0x12e8500: blr             lr
    // 0x12e8504: cmp             w7, NULL
    // 0x12e8508: b.eq            #0x12e8514
    // 0x12e850c: tbnz            w7, #4, #0x12e8534
    // 0x12e8510: b               #0x12e853c
    // 0x12e8514: r8 = Map
    //     0x12e8514: add             x8, PP, #0x81, lsl #12  ; [pp+0x81110] Type: Map
    //     0x12e8518: ldr             x8, [x8, #0x110]
    // 0x12e851c: r3 = SubtypeTestCache
    //     0x12e851c: add             x3, PP, #0x81, lsl #12  ; [pp+0x81118] SubtypeTestCache
    //     0x12e8520: ldr             x3, [x3, #0x118]
    // 0x12e8524: r30 = InstanceOfStub
    //     0x12e8524: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e8528: LoadField: r30 = r30->field_7
    //     0x12e8528: ldur            lr, [lr, #7]
    // 0x12e852c: blr             lr
    // 0x12e8530: b               #0x12e8540
    // 0x12e8534: r0 = false
    //     0x12e8534: add             x0, NULL, #0x30  ; false
    // 0x12e8538: b               #0x12e8540
    // 0x12e853c: r0 = true
    //     0x12e853c: add             x0, NULL, #0x20  ; true
    // 0x12e8540: tbnz            w0, #4, #0x12e8638
    // 0x12e8544: ldur            x0, [fp, #-0x18]
    // 0x12e8548: r2 = Null
    //     0x12e8548: mov             x2, NULL
    // 0x12e854c: r1 = Null
    //     0x12e854c: mov             x1, NULL
    // 0x12e8550: cmp             w0, NULL
    // 0x12e8554: b.eq            #0x12e85ec
    // 0x12e8558: branchIfSmi(r0, 0x12e85ec)
    //     0x12e8558: tbz             w0, #0, #0x12e85ec
    // 0x12e855c: r3 = LoadClassIdInstr(r0)
    //     0x12e855c: ldur            x3, [x0, #-1]
    //     0x12e8560: ubfx            x3, x3, #0xc, #0x14
    // 0x12e8564: r17 = 7630
    //     0x12e8564: mov             x17, #0x1dce
    // 0x12e8568: cmp             x3, x17
    // 0x12e856c: b.eq            #0x12e85f4
    // 0x12e8570: r4 = LoadClassIdInstr(r0)
    //     0x12e8570: ldur            x4, [x0, #-1]
    //     0x12e8574: ubfx            x4, x4, #0xc, #0x14
    // 0x12e8578: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e857c: ldr             x3, [x3, #0x18]
    // 0x12e8580: ldr             x3, [x3, x4, lsl #3]
    // 0x12e8584: LoadField: r3 = r3->field_2b
    //     0x12e8584: ldur            w3, [x3, #0x2b]
    // 0x12e8588: DecompressPointer r3
    //     0x12e8588: add             x3, x3, HEAP, lsl #32
    // 0x12e858c: cmp             w3, NULL
    // 0x12e8590: b.eq            #0x12e85ec
    // 0x12e8594: LoadField: r3 = r3->field_f
    //     0x12e8594: ldur            w3, [x3, #0xf]
    // 0x12e8598: lsr             x3, x3, #3
    // 0x12e859c: r17 = 7630
    //     0x12e859c: mov             x17, #0x1dce
    // 0x12e85a0: cmp             x3, x17
    // 0x12e85a4: b.eq            #0x12e85f4
    // 0x12e85a8: r3 = SubtypeTestCache
    //     0x12e85a8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81120] SubtypeTestCache
    //     0x12e85ac: ldr             x3, [x3, #0x120]
    // 0x12e85b0: r30 = Subtype1TestCacheStub
    //     0x12e85b0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e85b4: LoadField: r30 = r30->field_7
    //     0x12e85b4: ldur            lr, [lr, #7]
    // 0x12e85b8: blr             lr
    // 0x12e85bc: cmp             w7, NULL
    // 0x12e85c0: b.eq            #0x12e85cc
    // 0x12e85c4: tbnz            w7, #4, #0x12e85ec
    // 0x12e85c8: b               #0x12e85f4
    // 0x12e85cc: r8 = Map
    //     0x12e85cc: add             x8, PP, #0x81, lsl #12  ; [pp+0x81128] Type: Map
    //     0x12e85d0: ldr             x8, [x8, #0x128]
    // 0x12e85d4: r3 = SubtypeTestCache
    //     0x12e85d4: add             x3, PP, #0x81, lsl #12  ; [pp+0x81130] SubtypeTestCache
    //     0x12e85d8: ldr             x3, [x3, #0x130]
    // 0x12e85dc: r30 = InstanceOfStub
    //     0x12e85dc: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e85e0: LoadField: r30 = r30->field_7
    //     0x12e85e0: ldur            lr, [lr, #7]
    // 0x12e85e4: blr             lr
    // 0x12e85e8: b               #0x12e85f8
    // 0x12e85ec: r0 = false
    //     0x12e85ec: add             x0, NULL, #0x30  ; false
    // 0x12e85f0: b               #0x12e85f8
    // 0x12e85f4: r0 = true
    //     0x12e85f4: add             x0, NULL, #0x20  ; true
    // 0x12e85f8: tbnz            w0, #4, #0x12e8628
    // 0x12e85fc: ldur            x0, [fp, #-8]
    // 0x12e8600: r1 = Null
    //     0x12e8600: mov             x1, NULL
    // 0x12e8604: r0 = MapEquality()
    //     0x12e8604: bl              #0x113c404  ; AllocateMapEqualityStub -> MapEquality<X0, X1> (size=0x14)
    // 0x12e8608: ldur            x3, [fp, #-8]
    // 0x12e860c: StoreField: r0->field_b = r3
    //     0x12e860c: stur            w3, [x0, #0xb]
    // 0x12e8610: StoreField: r0->field_f = r3
    //     0x12e8610: stur            w3, [x0, #0xf]
    // 0x12e8614: mov             x1, x0
    // 0x12e8618: ldur            x2, [fp, #-0x10]
    // 0x12e861c: ldur            x3, [fp, #-0x18]
    // 0x12e8620: r0 = equals()
    //     0x12e8620: bl              #0x12e7c88  ; [package:collection/src/equality.dart] MapEquality::equals
    // 0x12e8624: b               #0x12e862c
    // 0x12e8628: r0 = false
    //     0x12e8628: add             x0, NULL, #0x30  ; false
    // 0x12e862c: LeaveFrame
    //     0x12e862c: mov             SP, fp
    //     0x12e8630: ldp             fp, lr, [SP], #0x10
    // 0x12e8634: ret
    //     0x12e8634: ret             
    // 0x12e8638: ldur            x3, [fp, #-8]
    // 0x12e863c: ldur            x0, [fp, #-0x10]
    // 0x12e8640: r2 = Null
    //     0x12e8640: mov             x2, NULL
    // 0x12e8644: r1 = Null
    //     0x12e8644: mov             x1, NULL
    // 0x12e8648: cmp             w0, NULL
    // 0x12e864c: b.eq            #0x12e86f0
    // 0x12e8650: branchIfSmi(r0, 0x12e86f0)
    //     0x12e8650: tbz             w0, #0, #0x12e86f0
    // 0x12e8654: r3 = LoadClassIdInstr(r0)
    //     0x12e8654: ldur            x3, [x0, #-1]
    //     0x12e8658: ubfx            x3, x3, #0xc, #0x14
    // 0x12e865c: r17 = 7631
    //     0x12e865c: mov             x17, #0x1dcf
    // 0x12e8660: cmp             x3, x17
    // 0x12e8664: b.eq            #0x12e86f8
    // 0x12e8668: sub             x3, x3, #0x5a
    // 0x12e866c: cmp             x3, #2
    // 0x12e8670: b.ls            #0x12e86f8
    // 0x12e8674: r4 = LoadClassIdInstr(r0)
    //     0x12e8674: ldur            x4, [x0, #-1]
    //     0x12e8678: ubfx            x4, x4, #0xc, #0x14
    // 0x12e867c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e8680: ldr             x3, [x3, #0x18]
    // 0x12e8684: ldr             x3, [x3, x4, lsl #3]
    // 0x12e8688: LoadField: r3 = r3->field_2b
    //     0x12e8688: ldur            w3, [x3, #0x2b]
    // 0x12e868c: DecompressPointer r3
    //     0x12e868c: add             x3, x3, HEAP, lsl #32
    // 0x12e8690: cmp             w3, NULL
    // 0x12e8694: b.eq            #0x12e86f0
    // 0x12e8698: LoadField: r3 = r3->field_f
    //     0x12e8698: ldur            w3, [x3, #0xf]
    // 0x12e869c: lsr             x3, x3, #3
    // 0x12e86a0: r17 = 7631
    //     0x12e86a0: mov             x17, #0x1dcf
    // 0x12e86a4: cmp             x3, x17
    // 0x12e86a8: b.eq            #0x12e86f8
    // 0x12e86ac: r3 = SubtypeTestCache
    //     0x12e86ac: add             x3, PP, #0x81, lsl #12  ; [pp+0x81138] SubtypeTestCache
    //     0x12e86b0: ldr             x3, [x3, #0x138]
    // 0x12e86b4: r30 = Subtype1TestCacheStub
    //     0x12e86b4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e86b8: LoadField: r30 = r30->field_7
    //     0x12e86b8: ldur            lr, [lr, #7]
    // 0x12e86bc: blr             lr
    // 0x12e86c0: cmp             w7, NULL
    // 0x12e86c4: b.eq            #0x12e86d0
    // 0x12e86c8: tbnz            w7, #4, #0x12e86f0
    // 0x12e86cc: b               #0x12e86f8
    // 0x12e86d0: r8 = List
    //     0x12e86d0: add             x8, PP, #0x81, lsl #12  ; [pp+0x81140] Type: List
    //     0x12e86d4: ldr             x8, [x8, #0x140]
    // 0x12e86d8: r3 = SubtypeTestCache
    //     0x12e86d8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81148] SubtypeTestCache
    //     0x12e86dc: ldr             x3, [x3, #0x148]
    // 0x12e86e0: r30 = InstanceOfStub
    //     0x12e86e0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e86e4: LoadField: r30 = r30->field_7
    //     0x12e86e4: ldur            lr, [lr, #7]
    // 0x12e86e8: blr             lr
    // 0x12e86ec: b               #0x12e86fc
    // 0x12e86f0: r0 = false
    //     0x12e86f0: add             x0, NULL, #0x30  ; false
    // 0x12e86f4: b               #0x12e86fc
    // 0x12e86f8: r0 = true
    //     0x12e86f8: add             x0, NULL, #0x20  ; true
    // 0x12e86fc: tbnz            w0, #4, #0x12e87fc
    // 0x12e8700: ldur            x0, [fp, #-0x18]
    // 0x12e8704: r2 = Null
    //     0x12e8704: mov             x2, NULL
    // 0x12e8708: r1 = Null
    //     0x12e8708: mov             x1, NULL
    // 0x12e870c: cmp             w0, NULL
    // 0x12e8710: b.eq            #0x12e87b4
    // 0x12e8714: branchIfSmi(r0, 0x12e87b4)
    //     0x12e8714: tbz             w0, #0, #0x12e87b4
    // 0x12e8718: r3 = LoadClassIdInstr(r0)
    //     0x12e8718: ldur            x3, [x0, #-1]
    //     0x12e871c: ubfx            x3, x3, #0xc, #0x14
    // 0x12e8720: r17 = 7631
    //     0x12e8720: mov             x17, #0x1dcf
    // 0x12e8724: cmp             x3, x17
    // 0x12e8728: b.eq            #0x12e87bc
    // 0x12e872c: sub             x3, x3, #0x5a
    // 0x12e8730: cmp             x3, #2
    // 0x12e8734: b.ls            #0x12e87bc
    // 0x12e8738: r4 = LoadClassIdInstr(r0)
    //     0x12e8738: ldur            x4, [x0, #-1]
    //     0x12e873c: ubfx            x4, x4, #0xc, #0x14
    // 0x12e8740: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e8744: ldr             x3, [x3, #0x18]
    // 0x12e8748: ldr             x3, [x3, x4, lsl #3]
    // 0x12e874c: LoadField: r3 = r3->field_2b
    //     0x12e874c: ldur            w3, [x3, #0x2b]
    // 0x12e8750: DecompressPointer r3
    //     0x12e8750: add             x3, x3, HEAP, lsl #32
    // 0x12e8754: cmp             w3, NULL
    // 0x12e8758: b.eq            #0x12e87b4
    // 0x12e875c: LoadField: r3 = r3->field_f
    //     0x12e875c: ldur            w3, [x3, #0xf]
    // 0x12e8760: lsr             x3, x3, #3
    // 0x12e8764: r17 = 7631
    //     0x12e8764: mov             x17, #0x1dcf
    // 0x12e8768: cmp             x3, x17
    // 0x12e876c: b.eq            #0x12e87bc
    // 0x12e8770: r3 = SubtypeTestCache
    //     0x12e8770: add             x3, PP, #0x81, lsl #12  ; [pp+0x81150] SubtypeTestCache
    //     0x12e8774: ldr             x3, [x3, #0x150]
    // 0x12e8778: r30 = Subtype1TestCacheStub
    //     0x12e8778: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e877c: LoadField: r30 = r30->field_7
    //     0x12e877c: ldur            lr, [lr, #7]
    // 0x12e8780: blr             lr
    // 0x12e8784: cmp             w7, NULL
    // 0x12e8788: b.eq            #0x12e8794
    // 0x12e878c: tbnz            w7, #4, #0x12e87b4
    // 0x12e8790: b               #0x12e87bc
    // 0x12e8794: r8 = List
    //     0x12e8794: add             x8, PP, #0x81, lsl #12  ; [pp+0x81158] Type: List
    //     0x12e8798: ldr             x8, [x8, #0x158]
    // 0x12e879c: r3 = SubtypeTestCache
    //     0x12e879c: add             x3, PP, #0x81, lsl #12  ; [pp+0x81160] SubtypeTestCache
    //     0x12e87a0: ldr             x3, [x3, #0x160]
    // 0x12e87a4: r30 = InstanceOfStub
    //     0x12e87a4: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e87a8: LoadField: r30 = r30->field_7
    //     0x12e87a8: ldur            lr, [lr, #7]
    // 0x12e87ac: blr             lr
    // 0x12e87b0: b               #0x12e87c0
    // 0x12e87b4: r0 = false
    //     0x12e87b4: add             x0, NULL, #0x30  ; false
    // 0x12e87b8: b               #0x12e87c0
    // 0x12e87bc: r0 = true
    //     0x12e87bc: add             x0, NULL, #0x20  ; true
    // 0x12e87c0: tbnz            w0, #4, #0x12e87ec
    // 0x12e87c4: ldur            x0, [fp, #-8]
    // 0x12e87c8: r1 = Null
    //     0x12e87c8: mov             x1, NULL
    // 0x12e87cc: r0 = ListEquality()
    //     0x12e87cc: bl              #0x12e89dc  ; AllocateListEqualityStub -> ListEquality<X0> (size=0x10)
    // 0x12e87d0: ldur            x3, [fp, #-8]
    // 0x12e87d4: StoreField: r0->field_b = r3
    //     0x12e87d4: stur            w3, [x0, #0xb]
    // 0x12e87d8: mov             x1, x0
    // 0x12e87dc: ldur            x2, [fp, #-0x10]
    // 0x12e87e0: ldur            x3, [fp, #-0x18]
    // 0x12e87e4: r0 = equals()
    //     0x12e87e4: bl              #0x12e75bc  ; [package:collection/src/equality.dart] ListEquality::equals
    // 0x12e87e8: b               #0x12e87f0
    // 0x12e87ec: r0 = false
    //     0x12e87ec: add             x0, NULL, #0x30  ; false
    // 0x12e87f0: LeaveFrame
    //     0x12e87f0: mov             SP, fp
    //     0x12e87f4: ldp             fp, lr, [SP], #0x10
    // 0x12e87f8: ret
    //     0x12e87f8: ret             
    // 0x12e87fc: ldur            x3, [fp, #-8]
    // 0x12e8800: ldur            x0, [fp, #-0x10]
    // 0x12e8804: r2 = Null
    //     0x12e8804: mov             x2, NULL
    // 0x12e8808: r1 = Null
    //     0x12e8808: mov             x1, NULL
    // 0x12e880c: cmp             w0, NULL
    // 0x12e8810: b.eq            #0x12e88a8
    // 0x12e8814: branchIfSmi(r0, 0x12e88a8)
    //     0x12e8814: tbz             w0, #0, #0x12e88a8
    // 0x12e8818: r3 = LoadClassIdInstr(r0)
    //     0x12e8818: ldur            x3, [x0, #-1]
    //     0x12e881c: ubfx            x3, x3, #0xc, #0x14
    // 0x12e8820: r17 = 7635
    //     0x12e8820: mov             x17, #0x1dd3
    // 0x12e8824: cmp             x3, x17
    // 0x12e8828: b.eq            #0x12e88b0
    // 0x12e882c: r4 = LoadClassIdInstr(r0)
    //     0x12e882c: ldur            x4, [x0, #-1]
    //     0x12e8830: ubfx            x4, x4, #0xc, #0x14
    // 0x12e8834: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e8838: ldr             x3, [x3, #0x18]
    // 0x12e883c: ldr             x3, [x3, x4, lsl #3]
    // 0x12e8840: LoadField: r3 = r3->field_2b
    //     0x12e8840: ldur            w3, [x3, #0x2b]
    // 0x12e8844: DecompressPointer r3
    //     0x12e8844: add             x3, x3, HEAP, lsl #32
    // 0x12e8848: cmp             w3, NULL
    // 0x12e884c: b.eq            #0x12e88a8
    // 0x12e8850: LoadField: r3 = r3->field_f
    //     0x12e8850: ldur            w3, [x3, #0xf]
    // 0x12e8854: lsr             x3, x3, #3
    // 0x12e8858: r17 = 7635
    //     0x12e8858: mov             x17, #0x1dd3
    // 0x12e885c: cmp             x3, x17
    // 0x12e8860: b.eq            #0x12e88b0
    // 0x12e8864: r3 = SubtypeTestCache
    //     0x12e8864: add             x3, PP, #0x81, lsl #12  ; [pp+0x81168] SubtypeTestCache
    //     0x12e8868: ldr             x3, [x3, #0x168]
    // 0x12e886c: r30 = Subtype1TestCacheStub
    //     0x12e886c: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e8870: LoadField: r30 = r30->field_7
    //     0x12e8870: ldur            lr, [lr, #7]
    // 0x12e8874: blr             lr
    // 0x12e8878: cmp             w7, NULL
    // 0x12e887c: b.eq            #0x12e8888
    // 0x12e8880: tbnz            w7, #4, #0x12e88a8
    // 0x12e8884: b               #0x12e88b0
    // 0x12e8888: r8 = Iterable
    //     0x12e8888: add             x8, PP, #0x81, lsl #12  ; [pp+0x81170] Type: Iterable
    //     0x12e888c: ldr             x8, [x8, #0x170]
    // 0x12e8890: r3 = SubtypeTestCache
    //     0x12e8890: add             x3, PP, #0x81, lsl #12  ; [pp+0x81178] SubtypeTestCache
    //     0x12e8894: ldr             x3, [x3, #0x178]
    // 0x12e8898: r30 = InstanceOfStub
    //     0x12e8898: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e889c: LoadField: r30 = r30->field_7
    //     0x12e889c: ldur            lr, [lr, #7]
    // 0x12e88a0: blr             lr
    // 0x12e88a4: b               #0x12e88b4
    // 0x12e88a8: r0 = false
    //     0x12e88a8: add             x0, NULL, #0x30  ; false
    // 0x12e88ac: b               #0x12e88b4
    // 0x12e88b0: r0 = true
    //     0x12e88b0: add             x0, NULL, #0x20  ; true
    // 0x12e88b4: tbnz            w0, #4, #0x12e89a8
    // 0x12e88b8: ldur            x0, [fp, #-0x18]
    // 0x12e88bc: r2 = Null
    //     0x12e88bc: mov             x2, NULL
    // 0x12e88c0: r1 = Null
    //     0x12e88c0: mov             x1, NULL
    // 0x12e88c4: cmp             w0, NULL
    // 0x12e88c8: b.eq            #0x12e8960
    // 0x12e88cc: branchIfSmi(r0, 0x12e8960)
    //     0x12e88cc: tbz             w0, #0, #0x12e8960
    // 0x12e88d0: r3 = LoadClassIdInstr(r0)
    //     0x12e88d0: ldur            x3, [x0, #-1]
    //     0x12e88d4: ubfx            x3, x3, #0xc, #0x14
    // 0x12e88d8: r17 = 7635
    //     0x12e88d8: mov             x17, #0x1dd3
    // 0x12e88dc: cmp             x3, x17
    // 0x12e88e0: b.eq            #0x12e8968
    // 0x12e88e4: r4 = LoadClassIdInstr(r0)
    //     0x12e88e4: ldur            x4, [x0, #-1]
    //     0x12e88e8: ubfx            x4, x4, #0xc, #0x14
    // 0x12e88ec: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e88f0: ldr             x3, [x3, #0x18]
    // 0x12e88f4: ldr             x3, [x3, x4, lsl #3]
    // 0x12e88f8: LoadField: r3 = r3->field_2b
    //     0x12e88f8: ldur            w3, [x3, #0x2b]
    // 0x12e88fc: DecompressPointer r3
    //     0x12e88fc: add             x3, x3, HEAP, lsl #32
    // 0x12e8900: cmp             w3, NULL
    // 0x12e8904: b.eq            #0x12e8960
    // 0x12e8908: LoadField: r3 = r3->field_f
    //     0x12e8908: ldur            w3, [x3, #0xf]
    // 0x12e890c: lsr             x3, x3, #3
    // 0x12e8910: r17 = 7635
    //     0x12e8910: mov             x17, #0x1dd3
    // 0x12e8914: cmp             x3, x17
    // 0x12e8918: b.eq            #0x12e8968
    // 0x12e891c: r3 = SubtypeTestCache
    //     0x12e891c: add             x3, PP, #0x81, lsl #12  ; [pp+0x81180] SubtypeTestCache
    //     0x12e8920: ldr             x3, [x3, #0x180]
    // 0x12e8924: r30 = Subtype1TestCacheStub
    //     0x12e8924: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e8928: LoadField: r30 = r30->field_7
    //     0x12e8928: ldur            lr, [lr, #7]
    // 0x12e892c: blr             lr
    // 0x12e8930: cmp             w7, NULL
    // 0x12e8934: b.eq            #0x12e8940
    // 0x12e8938: tbnz            w7, #4, #0x12e8960
    // 0x12e893c: b               #0x12e8968
    // 0x12e8940: r8 = Iterable
    //     0x12e8940: add             x8, PP, #0x81, lsl #12  ; [pp+0x81188] Type: Iterable
    //     0x12e8944: ldr             x8, [x8, #0x188]
    // 0x12e8948: r3 = SubtypeTestCache
    //     0x12e8948: add             x3, PP, #0x81, lsl #12  ; [pp+0x81190] SubtypeTestCache
    //     0x12e894c: ldr             x3, [x3, #0x190]
    // 0x12e8950: r30 = InstanceOfStub
    //     0x12e8950: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e8954: LoadField: r30 = r30->field_7
    //     0x12e8954: ldur            lr, [lr, #7]
    // 0x12e8958: blr             lr
    // 0x12e895c: b               #0x12e896c
    // 0x12e8960: r0 = false
    //     0x12e8960: add             x0, NULL, #0x30  ; false
    // 0x12e8964: b               #0x12e896c
    // 0x12e8968: r0 = true
    //     0x12e8968: add             x0, NULL, #0x20  ; true
    // 0x12e896c: tbnz            w0, #4, #0x12e8998
    // 0x12e8970: ldur            x0, [fp, #-8]
    // 0x12e8974: r1 = Null
    //     0x12e8974: mov             x1, NULL
    // 0x12e8978: r0 = IterableEquality()
    //     0x12e8978: bl              #0x12e89d0  ; AllocateIterableEqualityStub -> IterableEquality<X0> (size=0x10)
    // 0x12e897c: mov             x1, x0
    // 0x12e8980: ldur            x0, [fp, #-8]
    // 0x12e8984: StoreField: r1->field_b = r0
    //     0x12e8984: stur            w0, [x1, #0xb]
    // 0x12e8988: ldur            x2, [fp, #-0x10]
    // 0x12e898c: ldur            x3, [fp, #-0x18]
    // 0x12e8990: r0 = equals()
    //     0x12e8990: bl              #0x12e7384  ; [package:collection/src/equality.dart] IterableEquality::equals
    // 0x12e8994: b               #0x12e899c
    // 0x12e8998: r0 = false
    //     0x12e8998: add             x0, NULL, #0x30  ; false
    // 0x12e899c: LeaveFrame
    //     0x12e899c: mov             SP, fp
    //     0x12e89a0: ldp             fp, lr, [SP], #0x10
    // 0x12e89a4: ret
    //     0x12e89a4: ret             
    // 0x12e89a8: ldur            x2, [fp, #-0x10]
    // 0x12e89ac: ldur            x3, [fp, #-0x18]
    // 0x12e89b0: r1 = Instance_DefaultEquality
    //     0x12e89b0: add             x1, PP, #0x81, lsl #12  ; [pp+0x81090] Obj!DefaultEquality<Never>@12a0051
    //     0x12e89b4: ldr             x1, [x1, #0x90]
    // 0x12e89b8: r0 = equals()
    //     0x12e89b8: bl              #0x12e7338  ; [package:collection/src/equality.dart] DefaultEquality::equals
    // 0x12e89bc: LeaveFrame
    //     0x12e89bc: mov             SP, fp
    //     0x12e89c0: ldp             fp, lr, [SP], #0x10
    // 0x12e89c4: ret
    //     0x12e89c4: ret             
    // 0x12e89c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e89c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e89cc: b               #0x12e82dc
  }
  _ hash(/* No info */) {
    // ** addr: 0x12e914c, size: 0x3fc
    // 0x12e914c: EnterFrame
    //     0x12e914c: stp             fp, lr, [SP, #-0x10]!
    //     0x12e9150: mov             fp, SP
    // 0x12e9154: AllocStack(0x10)
    //     0x12e9154: sub             SP, SP, #0x10
    // 0x12e9158: SetupParameters(DeepCollectionEquality this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x12e9158: mov             x4, x1
    //     0x12e915c: mov             x3, x2
    //     0x12e9160: stur            x1, [fp, #-8]
    //     0x12e9164: stur            x2, [fp, #-0x10]
    // 0x12e9168: CheckStackOverflow
    //     0x12e9168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e916c: cmp             SP, x16
    //     0x12e9170: b.ls            #0x12e9540
    // 0x12e9174: mov             x0, x3
    // 0x12e9178: r2 = Null
    //     0x12e9178: mov             x2, NULL
    // 0x12e917c: r1 = Null
    //     0x12e917c: mov             x1, NULL
    // 0x12e9180: cmp             w0, NULL
    // 0x12e9184: b.eq            #0x12e921c
    // 0x12e9188: branchIfSmi(r0, 0x12e921c)
    //     0x12e9188: tbz             w0, #0, #0x12e921c
    // 0x12e918c: r3 = LoadClassIdInstr(r0)
    //     0x12e918c: ldur            x3, [x0, #-1]
    //     0x12e9190: ubfx            x3, x3, #0xc, #0x14
    // 0x12e9194: r17 = 7623
    //     0x12e9194: mov             x17, #0x1dc7
    // 0x12e9198: cmp             x3, x17
    // 0x12e919c: b.eq            #0x12e9224
    // 0x12e91a0: r4 = LoadClassIdInstr(r0)
    //     0x12e91a0: ldur            x4, [x0, #-1]
    //     0x12e91a4: ubfx            x4, x4, #0xc, #0x14
    // 0x12e91a8: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e91ac: ldr             x3, [x3, #0x18]
    // 0x12e91b0: ldr             x3, [x3, x4, lsl #3]
    // 0x12e91b4: LoadField: r3 = r3->field_2b
    //     0x12e91b4: ldur            w3, [x3, #0x2b]
    // 0x12e91b8: DecompressPointer r3
    //     0x12e91b8: add             x3, x3, HEAP, lsl #32
    // 0x12e91bc: cmp             w3, NULL
    // 0x12e91c0: b.eq            #0x12e921c
    // 0x12e91c4: LoadField: r3 = r3->field_f
    //     0x12e91c4: ldur            w3, [x3, #0xf]
    // 0x12e91c8: lsr             x3, x3, #3
    // 0x12e91cc: r17 = 7623
    //     0x12e91cc: mov             x17, #0x1dc7
    // 0x12e91d0: cmp             x3, x17
    // 0x12e91d4: b.eq            #0x12e9224
    // 0x12e91d8: r3 = SubtypeTestCache
    //     0x12e91d8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81028] SubtypeTestCache
    //     0x12e91dc: ldr             x3, [x3, #0x28]
    // 0x12e91e0: r30 = Subtype1TestCacheStub
    //     0x12e91e0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e91e4: LoadField: r30 = r30->field_7
    //     0x12e91e4: ldur            lr, [lr, #7]
    // 0x12e91e8: blr             lr
    // 0x12e91ec: cmp             w7, NULL
    // 0x12e91f0: b.eq            #0x12e91fc
    // 0x12e91f4: tbnz            w7, #4, #0x12e921c
    // 0x12e91f8: b               #0x12e9224
    // 0x12e91fc: r8 = Set
    //     0x12e91fc: add             x8, PP, #0x81, lsl #12  ; [pp+0x81030] Type: Set
    //     0x12e9200: ldr             x8, [x8, #0x30]
    // 0x12e9204: r3 = SubtypeTestCache
    //     0x12e9204: add             x3, PP, #0x81, lsl #12  ; [pp+0x81038] SubtypeTestCache
    //     0x12e9208: ldr             x3, [x3, #0x38]
    // 0x12e920c: r30 = InstanceOfStub
    //     0x12e920c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e9210: LoadField: r30 = r30->field_7
    //     0x12e9210: ldur            lr, [lr, #7]
    // 0x12e9214: blr             lr
    // 0x12e9218: b               #0x12e9228
    // 0x12e921c: r0 = false
    //     0x12e921c: add             x0, NULL, #0x30  ; false
    // 0x12e9220: b               #0x12e9228
    // 0x12e9224: r0 = true
    //     0x12e9224: add             x0, NULL, #0x20  ; true
    // 0x12e9228: tbnz            w0, #4, #0x12e925c
    // 0x12e922c: ldur            x0, [fp, #-8]
    // 0x12e9230: r1 = <dynamic, Set, dynamic>
    //     0x12e9230: add             x1, PP, #0x81, lsl #12  ; [pp+0x81040] TypeArguments: <dynamic, Set, dynamic>
    //     0x12e9234: ldr             x1, [x1, #0x40]
    // 0x12e9238: r0 = SetEquality()
    //     0x12e9238: bl              #0x12e89e8  ; AllocateSetEqualityStub -> SetEquality<C2X0> (size=0x10)
    // 0x12e923c: ldur            x3, [fp, #-8]
    // 0x12e9240: StoreField: r0->field_b = r3
    //     0x12e9240: stur            w3, [x0, #0xb]
    // 0x12e9244: mov             x1, x0
    // 0x12e9248: ldur            x2, [fp, #-0x10]
    // 0x12e924c: r0 = hash()
    //     0x12e924c: bl              #0x12e8d38  ; [package:collection/src/equality.dart] _UnorderedEquality::hash
    // 0x12e9250: LeaveFrame
    //     0x12e9250: mov             SP, fp
    //     0x12e9254: ldp             fp, lr, [SP], #0x10
    // 0x12e9258: ret
    //     0x12e9258: ret             
    // 0x12e925c: ldur            x3, [fp, #-8]
    // 0x12e9260: ldur            x0, [fp, #-0x10]
    // 0x12e9264: r2 = Null
    //     0x12e9264: mov             x2, NULL
    // 0x12e9268: r1 = Null
    //     0x12e9268: mov             x1, NULL
    // 0x12e926c: cmp             w0, NULL
    // 0x12e9270: b.eq            #0x12e9308
    // 0x12e9274: branchIfSmi(r0, 0x12e9308)
    //     0x12e9274: tbz             w0, #0, #0x12e9308
    // 0x12e9278: r3 = LoadClassIdInstr(r0)
    //     0x12e9278: ldur            x3, [x0, #-1]
    //     0x12e927c: ubfx            x3, x3, #0xc, #0x14
    // 0x12e9280: r17 = 7630
    //     0x12e9280: mov             x17, #0x1dce
    // 0x12e9284: cmp             x3, x17
    // 0x12e9288: b.eq            #0x12e9310
    // 0x12e928c: r4 = LoadClassIdInstr(r0)
    //     0x12e928c: ldur            x4, [x0, #-1]
    //     0x12e9290: ubfx            x4, x4, #0xc, #0x14
    // 0x12e9294: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e9298: ldr             x3, [x3, #0x18]
    // 0x12e929c: ldr             x3, [x3, x4, lsl #3]
    // 0x12e92a0: LoadField: r3 = r3->field_2b
    //     0x12e92a0: ldur            w3, [x3, #0x2b]
    // 0x12e92a4: DecompressPointer r3
    //     0x12e92a4: add             x3, x3, HEAP, lsl #32
    // 0x12e92a8: cmp             w3, NULL
    // 0x12e92ac: b.eq            #0x12e9308
    // 0x12e92b0: LoadField: r3 = r3->field_f
    //     0x12e92b0: ldur            w3, [x3, #0xf]
    // 0x12e92b4: lsr             x3, x3, #3
    // 0x12e92b8: r17 = 7630
    //     0x12e92b8: mov             x17, #0x1dce
    // 0x12e92bc: cmp             x3, x17
    // 0x12e92c0: b.eq            #0x12e9310
    // 0x12e92c4: r3 = SubtypeTestCache
    //     0x12e92c4: add             x3, PP, #0x81, lsl #12  ; [pp+0x81048] SubtypeTestCache
    //     0x12e92c8: ldr             x3, [x3, #0x48]
    // 0x12e92cc: r30 = Subtype1TestCacheStub
    //     0x12e92cc: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e92d0: LoadField: r30 = r30->field_7
    //     0x12e92d0: ldur            lr, [lr, #7]
    // 0x12e92d4: blr             lr
    // 0x12e92d8: cmp             w7, NULL
    // 0x12e92dc: b.eq            #0x12e92e8
    // 0x12e92e0: tbnz            w7, #4, #0x12e9308
    // 0x12e92e4: b               #0x12e9310
    // 0x12e92e8: r8 = Map
    //     0x12e92e8: add             x8, PP, #0x81, lsl #12  ; [pp+0x81050] Type: Map
    //     0x12e92ec: ldr             x8, [x8, #0x50]
    // 0x12e92f0: r3 = SubtypeTestCache
    //     0x12e92f0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81058] SubtypeTestCache
    //     0x12e92f4: ldr             x3, [x3, #0x58]
    // 0x12e92f8: r30 = InstanceOfStub
    //     0x12e92f8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e92fc: LoadField: r30 = r30->field_7
    //     0x12e92fc: ldur            lr, [lr, #7]
    // 0x12e9300: blr             lr
    // 0x12e9304: b               #0x12e9314
    // 0x12e9308: r0 = false
    //     0x12e9308: add             x0, NULL, #0x30  ; false
    // 0x12e930c: b               #0x12e9314
    // 0x12e9310: r0 = true
    //     0x12e9310: add             x0, NULL, #0x20  ; true
    // 0x12e9314: tbnz            w0, #4, #0x12e9348
    // 0x12e9318: ldur            x0, [fp, #-8]
    // 0x12e931c: r1 = Null
    //     0x12e931c: mov             x1, NULL
    // 0x12e9320: r0 = MapEquality()
    //     0x12e9320: bl              #0x113c404  ; AllocateMapEqualityStub -> MapEquality<X0, X1> (size=0x14)
    // 0x12e9324: ldur            x3, [fp, #-8]
    // 0x12e9328: StoreField: r0->field_b = r3
    //     0x12e9328: stur            w3, [x0, #0xb]
    // 0x12e932c: StoreField: r0->field_f = r3
    //     0x12e932c: stur            w3, [x0, #0xf]
    // 0x12e9330: mov             x1, x0
    // 0x12e9334: ldur            x2, [fp, #-0x10]
    // 0x12e9338: r0 = hash()
    //     0x12e9338: bl              #0x12e8ebc  ; [package:collection/src/equality.dart] MapEquality::hash
    // 0x12e933c: LeaveFrame
    //     0x12e933c: mov             SP, fp
    //     0x12e9340: ldp             fp, lr, [SP], #0x10
    // 0x12e9344: ret
    //     0x12e9344: ret             
    // 0x12e9348: ldur            x3, [fp, #-8]
    // 0x12e934c: ldur            x0, [fp, #-0x10]
    // 0x12e9350: r2 = Null
    //     0x12e9350: mov             x2, NULL
    // 0x12e9354: r1 = Null
    //     0x12e9354: mov             x1, NULL
    // 0x12e9358: cmp             w0, NULL
    // 0x12e935c: b.eq            #0x12e9400
    // 0x12e9360: branchIfSmi(r0, 0x12e9400)
    //     0x12e9360: tbz             w0, #0, #0x12e9400
    // 0x12e9364: r3 = LoadClassIdInstr(r0)
    //     0x12e9364: ldur            x3, [x0, #-1]
    //     0x12e9368: ubfx            x3, x3, #0xc, #0x14
    // 0x12e936c: r17 = 7631
    //     0x12e936c: mov             x17, #0x1dcf
    // 0x12e9370: cmp             x3, x17
    // 0x12e9374: b.eq            #0x12e9408
    // 0x12e9378: sub             x3, x3, #0x5a
    // 0x12e937c: cmp             x3, #2
    // 0x12e9380: b.ls            #0x12e9408
    // 0x12e9384: r4 = LoadClassIdInstr(r0)
    //     0x12e9384: ldur            x4, [x0, #-1]
    //     0x12e9388: ubfx            x4, x4, #0xc, #0x14
    // 0x12e938c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e9390: ldr             x3, [x3, #0x18]
    // 0x12e9394: ldr             x3, [x3, x4, lsl #3]
    // 0x12e9398: LoadField: r3 = r3->field_2b
    //     0x12e9398: ldur            w3, [x3, #0x2b]
    // 0x12e939c: DecompressPointer r3
    //     0x12e939c: add             x3, x3, HEAP, lsl #32
    // 0x12e93a0: cmp             w3, NULL
    // 0x12e93a4: b.eq            #0x12e9400
    // 0x12e93a8: LoadField: r3 = r3->field_f
    //     0x12e93a8: ldur            w3, [x3, #0xf]
    // 0x12e93ac: lsr             x3, x3, #3
    // 0x12e93b0: r17 = 7631
    //     0x12e93b0: mov             x17, #0x1dcf
    // 0x12e93b4: cmp             x3, x17
    // 0x12e93b8: b.eq            #0x12e9408
    // 0x12e93bc: r3 = SubtypeTestCache
    //     0x12e93bc: add             x3, PP, #0x81, lsl #12  ; [pp+0x81060] SubtypeTestCache
    //     0x12e93c0: ldr             x3, [x3, #0x60]
    // 0x12e93c4: r30 = Subtype1TestCacheStub
    //     0x12e93c4: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e93c8: LoadField: r30 = r30->field_7
    //     0x12e93c8: ldur            lr, [lr, #7]
    // 0x12e93cc: blr             lr
    // 0x12e93d0: cmp             w7, NULL
    // 0x12e93d4: b.eq            #0x12e93e0
    // 0x12e93d8: tbnz            w7, #4, #0x12e9400
    // 0x12e93dc: b               #0x12e9408
    // 0x12e93e0: r8 = List
    //     0x12e93e0: add             x8, PP, #0x81, lsl #12  ; [pp+0x81068] Type: List
    //     0x12e93e4: ldr             x8, [x8, #0x68]
    // 0x12e93e8: r3 = SubtypeTestCache
    //     0x12e93e8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81070] SubtypeTestCache
    //     0x12e93ec: ldr             x3, [x3, #0x70]
    // 0x12e93f0: r30 = InstanceOfStub
    //     0x12e93f0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e93f4: LoadField: r30 = r30->field_7
    //     0x12e93f4: ldur            lr, [lr, #7]
    // 0x12e93f8: blr             lr
    // 0x12e93fc: b               #0x12e940c
    // 0x12e9400: r0 = false
    //     0x12e9400: add             x0, NULL, #0x30  ; false
    // 0x12e9404: b               #0x12e940c
    // 0x12e9408: r0 = true
    //     0x12e9408: add             x0, NULL, #0x20  ; true
    // 0x12e940c: tbnz            w0, #4, #0x12e943c
    // 0x12e9410: ldur            x0, [fp, #-8]
    // 0x12e9414: r1 = Null
    //     0x12e9414: mov             x1, NULL
    // 0x12e9418: r0 = ListEquality()
    //     0x12e9418: bl              #0x12e89dc  ; AllocateListEqualityStub -> ListEquality<X0> (size=0x10)
    // 0x12e941c: ldur            x3, [fp, #-8]
    // 0x12e9420: StoreField: r0->field_b = r3
    //     0x12e9420: stur            w3, [x0, #0xb]
    // 0x12e9424: mov             x1, x0
    // 0x12e9428: ldur            x2, [fp, #-0x10]
    // 0x12e942c: r0 = hash()
    //     0x12e942c: bl              #0x12e8b90  ; [package:collection/src/equality.dart] ListEquality::hash
    // 0x12e9430: LeaveFrame
    //     0x12e9430: mov             SP, fp
    //     0x12e9434: ldp             fp, lr, [SP], #0x10
    // 0x12e9438: ret
    //     0x12e9438: ret             
    // 0x12e943c: ldur            x3, [fp, #-8]
    // 0x12e9440: ldur            x0, [fp, #-0x10]
    // 0x12e9444: r2 = Null
    //     0x12e9444: mov             x2, NULL
    // 0x12e9448: r1 = Null
    //     0x12e9448: mov             x1, NULL
    // 0x12e944c: cmp             w0, NULL
    // 0x12e9450: b.eq            #0x12e94e8
    // 0x12e9454: branchIfSmi(r0, 0x12e94e8)
    //     0x12e9454: tbz             w0, #0, #0x12e94e8
    // 0x12e9458: r3 = LoadClassIdInstr(r0)
    //     0x12e9458: ldur            x3, [x0, #-1]
    //     0x12e945c: ubfx            x3, x3, #0xc, #0x14
    // 0x12e9460: r17 = 7635
    //     0x12e9460: mov             x17, #0x1dd3
    // 0x12e9464: cmp             x3, x17
    // 0x12e9468: b.eq            #0x12e94f0
    // 0x12e946c: r4 = LoadClassIdInstr(r0)
    //     0x12e946c: ldur            x4, [x0, #-1]
    //     0x12e9470: ubfx            x4, x4, #0xc, #0x14
    // 0x12e9474: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x12e9478: ldr             x3, [x3, #0x18]
    // 0x12e947c: ldr             x3, [x3, x4, lsl #3]
    // 0x12e9480: LoadField: r3 = r3->field_2b
    //     0x12e9480: ldur            w3, [x3, #0x2b]
    // 0x12e9484: DecompressPointer r3
    //     0x12e9484: add             x3, x3, HEAP, lsl #32
    // 0x12e9488: cmp             w3, NULL
    // 0x12e948c: b.eq            #0x12e94e8
    // 0x12e9490: LoadField: r3 = r3->field_f
    //     0x12e9490: ldur            w3, [x3, #0xf]
    // 0x12e9494: lsr             x3, x3, #3
    // 0x12e9498: r17 = 7635
    //     0x12e9498: mov             x17, #0x1dd3
    // 0x12e949c: cmp             x3, x17
    // 0x12e94a0: b.eq            #0x12e94f0
    // 0x12e94a4: r3 = SubtypeTestCache
    //     0x12e94a4: add             x3, PP, #0x81, lsl #12  ; [pp+0x81078] SubtypeTestCache
    //     0x12e94a8: ldr             x3, [x3, #0x78]
    // 0x12e94ac: r30 = Subtype1TestCacheStub
    //     0x12e94ac: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x12e94b0: LoadField: r30 = r30->field_7
    //     0x12e94b0: ldur            lr, [lr, #7]
    // 0x12e94b4: blr             lr
    // 0x12e94b8: cmp             w7, NULL
    // 0x12e94bc: b.eq            #0x12e94c8
    // 0x12e94c0: tbnz            w7, #4, #0x12e94e8
    // 0x12e94c4: b               #0x12e94f0
    // 0x12e94c8: r8 = Iterable
    //     0x12e94c8: add             x8, PP, #0x81, lsl #12  ; [pp+0x81080] Type: Iterable
    //     0x12e94cc: ldr             x8, [x8, #0x80]
    // 0x12e94d0: r3 = SubtypeTestCache
    //     0x12e94d0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81088] SubtypeTestCache
    //     0x12e94d4: ldr             x3, [x3, #0x88]
    // 0x12e94d8: r30 = InstanceOfStub
    //     0x12e94d8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12e94dc: LoadField: r30 = r30->field_7
    //     0x12e94dc: ldur            lr, [lr, #7]
    // 0x12e94e0: blr             lr
    // 0x12e94e4: b               #0x12e94f4
    // 0x12e94e8: r0 = false
    //     0x12e94e8: add             x0, NULL, #0x30  ; false
    // 0x12e94ec: b               #0x12e94f4
    // 0x12e94f0: r0 = true
    //     0x12e94f0: add             x0, NULL, #0x20  ; true
    // 0x12e94f4: tbnz            w0, #4, #0x12e9524
    // 0x12e94f8: ldur            x0, [fp, #-8]
    // 0x12e94fc: r1 = Null
    //     0x12e94fc: mov             x1, NULL
    // 0x12e9500: r0 = IterableEquality()
    //     0x12e9500: bl              #0x12e89d0  ; AllocateIterableEqualityStub -> IterableEquality<X0> (size=0x10)
    // 0x12e9504: mov             x1, x0
    // 0x12e9508: ldur            x0, [fp, #-8]
    // 0x12e950c: StoreField: r1->field_b = r0
    //     0x12e950c: stur            w0, [x1, #0xb]
    // 0x12e9510: ldur            x2, [fp, #-0x10]
    // 0x12e9514: r0 = hash()
    //     0x12e9514: bl              #0x12e89f4  ; [package:collection/src/equality.dart] IterableEquality::hash
    // 0x12e9518: LeaveFrame
    //     0x12e9518: mov             SP, fp
    //     0x12e951c: ldp             fp, lr, [SP], #0x10
    // 0x12e9520: ret
    //     0x12e9520: ret             
    // 0x12e9524: ldur            x2, [fp, #-0x10]
    // 0x12e9528: r1 = Instance_DefaultEquality
    //     0x12e9528: add             x1, PP, #0x81, lsl #12  ; [pp+0x81090] Obj!DefaultEquality<Never>@12a0051
    //     0x12e952c: ldr             x1, [x1, #0x90]
    // 0x12e9530: r0 = _hashCode()
    //     0x12e9530: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x12e9534: LeaveFrame
    //     0x12e9534: mov             SP, fp
    //     0x12e9538: ldp             fp, lr, [SP], #0x10
    // 0x12e953c: ret
    //     0x12e953c: ret             
    // 0x12e9540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e9540: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9544: b               #0x12e9174
  }
}

// class id: 3570, size: 0x14, field offset: 0x8
//   const constructor, 
class MapEquality<X0, X1> extends Object
    implements Equality<X0> {

  DefaultEquality<Never> field_c;
  DefaultEquality<Never> field_10;

  _ equals(/* No info */) {
    // ** addr: 0x12e7c88, size: 0x438
    // 0x12e7c88: EnterFrame
    //     0x12e7c88: stp             fp, lr, [SP, #-0x10]!
    //     0x12e7c8c: mov             fp, SP
    // 0x12e7c90: AllocStack(0x48)
    //     0x12e7c90: sub             SP, SP, #0x48
    // 0x12e7c94: SetupParameters(MapEquality<X0, X1> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12e7c94: mov             x5, x1
    //     0x12e7c98: mov             x4, x2
    //     0x12e7c9c: stur            x1, [fp, #-0x10]
    //     0x12e7ca0: stur            x2, [fp, #-0x18]
    //     0x12e7ca4: stur            x3, [fp, #-0x20]
    // 0x12e7ca8: CheckStackOverflow
    //     0x12e7ca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7cac: cmp             SP, x16
    //     0x12e7cb0: b.ls            #0x12e80a8
    // 0x12e7cb4: LoadField: r6 = r5->field_7
    //     0x12e7cb4: ldur            w6, [x5, #7]
    // 0x12e7cb8: DecompressPointer r6
    //     0x12e7cb8: add             x6, x6, HEAP, lsl #32
    // 0x12e7cbc: mov             x0, x4
    // 0x12e7cc0: mov             x2, x6
    // 0x12e7cc4: stur            x6, [fp, #-8]
    // 0x12e7cc8: r1 = Null
    //     0x12e7cc8: mov             x1, NULL
    // 0x12e7ccc: r8 = Map<X0, X1>?
    //     0x12e7ccc: add             x8, PP, #0xd, lsl #12  ; [pp+0xd028] Type: Map<X0, X1>?
    //     0x12e7cd0: ldr             x8, [x8, #0x28]
    // 0x12e7cd4: LoadField: r9 = r8->field_7
    //     0x12e7cd4: ldur            x9, [x8, #7]
    // 0x12e7cd8: r3 = Null
    //     0x12e7cd8: add             x3, PP, #0xd, lsl #12  ; [pp+0xd050] Null
    //     0x12e7cdc: ldr             x3, [x3, #0x50]
    // 0x12e7ce0: blr             x9
    // 0x12e7ce4: ldur            x0, [fp, #-0x20]
    // 0x12e7ce8: ldur            x2, [fp, #-8]
    // 0x12e7cec: r1 = Null
    //     0x12e7cec: mov             x1, NULL
    // 0x12e7cf0: r8 = Map<X0, X1>?
    //     0x12e7cf0: add             x8, PP, #0xd, lsl #12  ; [pp+0xd028] Type: Map<X0, X1>?
    //     0x12e7cf4: ldr             x8, [x8, #0x28]
    // 0x12e7cf8: LoadField: r9 = r8->field_7
    //     0x12e7cf8: ldur            x9, [x8, #7]
    // 0x12e7cfc: r3 = Null
    //     0x12e7cfc: add             x3, PP, #0xd, lsl #12  ; [pp+0xd060] Null
    //     0x12e7d00: ldr             x3, [x3, #0x60]
    // 0x12e7d04: blr             x9
    // 0x12e7d08: ldur            x2, [fp, #-0x18]
    // 0x12e7d0c: ldur            x1, [fp, #-0x20]
    // 0x12e7d10: cmp             w2, w1
    // 0x12e7d14: b.ne            #0x12e7d28
    // 0x12e7d18: r0 = true
    //     0x12e7d18: add             x0, NULL, #0x20  ; true
    // 0x12e7d1c: LeaveFrame
    //     0x12e7d1c: mov             SP, fp
    //     0x12e7d20: ldp             fp, lr, [SP], #0x10
    // 0x12e7d24: ret
    //     0x12e7d24: ret             
    // 0x12e7d28: r0 = LoadClassIdInstr(r2)
    //     0x12e7d28: ldur            x0, [x2, #-1]
    //     0x12e7d2c: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7d30: str             x2, [SP]
    // 0x12e7d34: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12e7d34: mov             x17, #0xf078
    //     0x12e7d38: add             lr, x0, x17
    //     0x12e7d3c: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7d40: blr             lr
    // 0x12e7d44: mov             x2, x0
    // 0x12e7d48: ldur            x1, [fp, #-0x20]
    // 0x12e7d4c: stur            x2, [fp, #-8]
    // 0x12e7d50: r0 = LoadClassIdInstr(r1)
    //     0x12e7d50: ldur            x0, [x1, #-1]
    //     0x12e7d54: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7d58: str             x1, [SP]
    // 0x12e7d5c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12e7d5c: mov             x17, #0xf078
    //     0x12e7d60: add             lr, x0, x17
    //     0x12e7d64: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7d68: blr             lr
    // 0x12e7d6c: mov             x1, x0
    // 0x12e7d70: ldur            x0, [fp, #-8]
    // 0x12e7d74: r2 = LoadInt32Instr(r0)
    //     0x12e7d74: sbfx            x2, x0, #1, #0x1f
    //     0x12e7d78: tbz             w0, #0, #0x12e7d80
    //     0x12e7d7c: ldur            x2, [x0, #7]
    // 0x12e7d80: r0 = LoadInt32Instr(r1)
    //     0x12e7d80: sbfx            x0, x1, #1, #0x1f
    //     0x12e7d84: tbz             w1, #0, #0x12e7d8c
    //     0x12e7d88: ldur            x0, [x1, #7]
    // 0x12e7d8c: cmp             x2, x0
    // 0x12e7d90: b.eq            #0x12e7da4
    // 0x12e7d94: r0 = false
    //     0x12e7d94: add             x0, NULL, #0x30  ; false
    // 0x12e7d98: LeaveFrame
    //     0x12e7d98: mov             SP, fp
    //     0x12e7d9c: ldp             fp, lr, [SP], #0x10
    // 0x12e7da0: ret
    //     0x12e7da0: ret             
    // 0x12e7da4: ldur            x0, [fp, #-0x18]
    // 0x12e7da8: r1 = <_MapEntry, int>
    //     0x12e7da8: add             x1, PP, #0xd, lsl #12  ; [pp+0xd070] TypeArguments: <_MapEntry, int>
    //     0x12e7dac: ldr             x1, [x1, #0x70]
    // 0x12e7db0: r0 = _HashMap()
    //     0x12e7db0: bl              #0x7fc734  ; Allocate_HashMapStub -> _HashMap<X0, X1> (size=0x20)
    // 0x12e7db4: stur            x0, [fp, #-8]
    // 0x12e7db8: StoreField: r0->field_b = rZR
    //     0x12e7db8: stur            xzr, [x0, #0xb]
    // 0x12e7dbc: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12e7dbc: stur            xzr, [x0, #0x17]
    // 0x12e7dc0: r1 = <_HashMapEntry?>
    //     0x12e7dc0: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0x12e7dc4: ldr             x1, [x1, #0x930]
    // 0x12e7dc8: r2 = 16
    //     0x12e7dc8: mov             x2, #0x10
    // 0x12e7dcc: r0 = AllocateArray()
    //     0x12e7dcc: bl              #0x13df928  ; AllocateArrayStub
    // 0x12e7dd0: ldur            x2, [fp, #-8]
    // 0x12e7dd4: StoreField: r2->field_13 = r0
    //     0x12e7dd4: stur            w0, [x2, #0x13]
    // 0x12e7dd8: ldur            x3, [fp, #-0x18]
    // 0x12e7ddc: r0 = LoadClassIdInstr(r3)
    //     0x12e7ddc: ldur            x0, [x3, #-1]
    //     0x12e7de0: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7de4: mov             x1, x3
    // 0x12e7de8: r0 = GDT[cid_x0 + 0x44d]()
    //     0x12e7de8: add             lr, x0, #0x44d
    //     0x12e7dec: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7df0: blr             lr
    // 0x12e7df4: r1 = LoadClassIdInstr(r0)
    //     0x12e7df4: ldur            x1, [x0, #-1]
    //     0x12e7df8: ubfx            x1, x1, #0xc, #0x14
    // 0x12e7dfc: mov             x16, x0
    // 0x12e7e00: mov             x0, x1
    // 0x12e7e04: mov             x1, x16
    // 0x12e7e08: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e7e08: mov             x17, #0x2641
    //     0x12e7e0c: movk            x17, #1, lsl #16
    //     0x12e7e10: add             lr, x0, x17
    //     0x12e7e14: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7e18: blr             lr
    // 0x12e7e1c: mov             x2, x0
    // 0x12e7e20: stur            x2, [fp, #-0x28]
    // 0x12e7e24: ldur            x4, [fp, #-0x10]
    // 0x12e7e28: ldur            x3, [fp, #-0x18]
    // 0x12e7e2c: CheckStackOverflow
    //     0x12e7e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7e30: cmp             SP, x16
    //     0x12e7e34: b.ls            #0x12e80b0
    // 0x12e7e38: r0 = LoadClassIdInstr(r2)
    //     0x12e7e38: ldur            x0, [x2, #-1]
    //     0x12e7e3c: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7e40: mov             x1, x2
    // 0x12e7e44: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e7e44: mov             x17, #0x845b
    //     0x12e7e48: movk            x17, #1, lsl #16
    //     0x12e7e4c: add             lr, x0, x17
    //     0x12e7e50: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7e54: blr             lr
    // 0x12e7e58: tbnz            w0, #4, #0x12e7f34
    // 0x12e7e5c: ldur            x4, [fp, #-0x10]
    // 0x12e7e60: ldur            x3, [fp, #-0x18]
    // 0x12e7e64: ldur            x2, [fp, #-0x28]
    // 0x12e7e68: r0 = LoadClassIdInstr(r2)
    //     0x12e7e68: ldur            x0, [x2, #-1]
    //     0x12e7e6c: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7e70: mov             x1, x2
    // 0x12e7e74: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e7e74: mov             x17, #0x7d4c
    //     0x12e7e78: movk            x17, #1, lsl #16
    //     0x12e7e7c: add             lr, x0, x17
    //     0x12e7e80: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7e84: blr             lr
    // 0x12e7e88: mov             x4, x0
    // 0x12e7e8c: ldur            x3, [fp, #-0x18]
    // 0x12e7e90: stur            x4, [fp, #-0x30]
    // 0x12e7e94: r0 = LoadClassIdInstr(r3)
    //     0x12e7e94: ldur            x0, [x3, #-1]
    //     0x12e7e98: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7e9c: mov             x1, x3
    // 0x12e7ea0: mov             x2, x4
    // 0x12e7ea4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x12e7ea4: sub             lr, x0, #0xd48
    //     0x12e7ea8: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7eac: blr             lr
    // 0x12e7eb0: stur            x0, [fp, #-0x38]
    // 0x12e7eb4: r0 = _MapEntry()
    //     0x12e7eb4: bl              #0x12e80c0  ; Allocate_MapEntryStub -> _MapEntry (size=0x14)
    // 0x12e7eb8: mov             x3, x0
    // 0x12e7ebc: ldur            x0, [fp, #-0x10]
    // 0x12e7ec0: stur            x3, [fp, #-0x40]
    // 0x12e7ec4: StoreField: r3->field_7 = r0
    //     0x12e7ec4: stur            w0, [x3, #7]
    // 0x12e7ec8: ldur            x1, [fp, #-0x30]
    // 0x12e7ecc: StoreField: r3->field_b = r1
    //     0x12e7ecc: stur            w1, [x3, #0xb]
    // 0x12e7ed0: ldur            x1, [fp, #-0x38]
    // 0x12e7ed4: StoreField: r3->field_f = r1
    //     0x12e7ed4: stur            w1, [x3, #0xf]
    // 0x12e7ed8: ldur            x1, [fp, #-8]
    // 0x12e7edc: mov             x2, x3
    // 0x12e7ee0: r0 = []()
    //     0x12e7ee0: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x12e7ee4: cmp             w0, NULL
    // 0x12e7ee8: b.ne            #0x12e7ef4
    // 0x12e7eec: r0 = 0
    //     0x12e7eec: mov             x0, #0
    // 0x12e7ef0: b               #0x12e7f04
    // 0x12e7ef4: r1 = LoadInt32Instr(r0)
    //     0x12e7ef4: sbfx            x1, x0, #1, #0x1f
    //     0x12e7ef8: tbz             w0, #0, #0x12e7f00
    //     0x12e7efc: ldur            x1, [x0, #7]
    // 0x12e7f00: mov             x0, x1
    // 0x12e7f04: add             x2, x0, #1
    // 0x12e7f08: r0 = BoxInt64Instr(r2)
    //     0x12e7f08: sbfiz           x0, x2, #1, #0x1f
    //     0x12e7f0c: cmp             x2, x0, asr #1
    //     0x12e7f10: b.eq            #0x12e7f1c
    //     0x12e7f14: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e7f18: stur            x2, [x0, #7]
    // 0x12e7f1c: ldur            x1, [fp, #-8]
    // 0x12e7f20: ldur            x2, [fp, #-0x40]
    // 0x12e7f24: mov             x3, x0
    // 0x12e7f28: r0 = []=()
    //     0x12e7f28: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0x12e7f2c: ldur            x2, [fp, #-0x28]
    // 0x12e7f30: b               #0x12e7e24
    // 0x12e7f34: ldur            x2, [fp, #-0x20]
    // 0x12e7f38: r0 = LoadClassIdInstr(r2)
    //     0x12e7f38: ldur            x0, [x2, #-1]
    //     0x12e7f3c: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7f40: mov             x1, x2
    // 0x12e7f44: r0 = GDT[cid_x0 + 0x44d]()
    //     0x12e7f44: add             lr, x0, #0x44d
    //     0x12e7f48: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7f4c: blr             lr
    // 0x12e7f50: r1 = LoadClassIdInstr(r0)
    //     0x12e7f50: ldur            x1, [x0, #-1]
    //     0x12e7f54: ubfx            x1, x1, #0xc, #0x14
    // 0x12e7f58: mov             x16, x0
    // 0x12e7f5c: mov             x0, x1
    // 0x12e7f60: mov             x1, x16
    // 0x12e7f64: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e7f64: mov             x17, #0x2641
    //     0x12e7f68: movk            x17, #1, lsl #16
    //     0x12e7f6c: add             lr, x0, x17
    //     0x12e7f70: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7f74: blr             lr
    // 0x12e7f78: mov             x2, x0
    // 0x12e7f7c: stur            x2, [fp, #-0x18]
    // 0x12e7f80: ldur            x4, [fp, #-0x10]
    // 0x12e7f84: ldur            x3, [fp, #-0x20]
    // 0x12e7f88: CheckStackOverflow
    //     0x12e7f88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7f8c: cmp             SP, x16
    //     0x12e7f90: b.ls            #0x12e80b8
    // 0x12e7f94: r0 = LoadClassIdInstr(r2)
    //     0x12e7f94: ldur            x0, [x2, #-1]
    //     0x12e7f98: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7f9c: mov             x1, x2
    // 0x12e7fa0: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e7fa0: mov             x17, #0x845b
    //     0x12e7fa4: movk            x17, #1, lsl #16
    //     0x12e7fa8: add             lr, x0, x17
    //     0x12e7fac: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7fb0: blr             lr
    // 0x12e7fb4: tbnz            w0, #4, #0x12e8098
    // 0x12e7fb8: ldur            x4, [fp, #-0x10]
    // 0x12e7fbc: ldur            x3, [fp, #-0x20]
    // 0x12e7fc0: ldur            x2, [fp, #-0x18]
    // 0x12e7fc4: r0 = LoadClassIdInstr(r2)
    //     0x12e7fc4: ldur            x0, [x2, #-1]
    //     0x12e7fc8: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7fcc: mov             x1, x2
    // 0x12e7fd0: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e7fd0: mov             x17, #0x7d4c
    //     0x12e7fd4: movk            x17, #1, lsl #16
    //     0x12e7fd8: add             lr, x0, x17
    //     0x12e7fdc: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7fe0: blr             lr
    // 0x12e7fe4: mov             x4, x0
    // 0x12e7fe8: ldur            x3, [fp, #-0x20]
    // 0x12e7fec: stur            x4, [fp, #-0x28]
    // 0x12e7ff0: r0 = LoadClassIdInstr(r3)
    //     0x12e7ff0: ldur            x0, [x3, #-1]
    //     0x12e7ff4: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7ff8: mov             x1, x3
    // 0x12e7ffc: mov             x2, x4
    // 0x12e8000: r0 = GDT[cid_x0 + -0xd48]()
    //     0x12e8000: sub             lr, x0, #0xd48
    //     0x12e8004: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8008: blr             lr
    // 0x12e800c: stur            x0, [fp, #-0x30]
    // 0x12e8010: r0 = _MapEntry()
    //     0x12e8010: bl              #0x12e80c0  ; Allocate_MapEntryStub -> _MapEntry (size=0x14)
    // 0x12e8014: mov             x3, x0
    // 0x12e8018: ldur            x0, [fp, #-0x10]
    // 0x12e801c: stur            x3, [fp, #-0x38]
    // 0x12e8020: StoreField: r3->field_7 = r0
    //     0x12e8020: stur            w0, [x3, #7]
    // 0x12e8024: ldur            x1, [fp, #-0x28]
    // 0x12e8028: StoreField: r3->field_b = r1
    //     0x12e8028: stur            w1, [x3, #0xb]
    // 0x12e802c: ldur            x1, [fp, #-0x30]
    // 0x12e8030: StoreField: r3->field_f = r1
    //     0x12e8030: stur            w1, [x3, #0xf]
    // 0x12e8034: ldur            x1, [fp, #-8]
    // 0x12e8038: mov             x2, x3
    // 0x12e803c: r0 = []()
    //     0x12e803c: bl              #0x12888cc  ; [dart:collection] _HashMap::[]
    // 0x12e8040: cmp             w0, NULL
    // 0x12e8044: b.eq            #0x12e8088
    // 0x12e8048: cbz             w0, #0x12e8088
    // 0x12e804c: r1 = LoadInt32Instr(r0)
    //     0x12e804c: sbfx            x1, x0, #1, #0x1f
    //     0x12e8050: tbz             w0, #0, #0x12e8058
    //     0x12e8054: ldur            x1, [x0, #7]
    // 0x12e8058: sub             x2, x1, #1
    // 0x12e805c: r0 = BoxInt64Instr(r2)
    //     0x12e805c: sbfiz           x0, x2, #1, #0x1f
    //     0x12e8060: cmp             x2, x0, asr #1
    //     0x12e8064: b.eq            #0x12e8070
    //     0x12e8068: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e806c: stur            x2, [x0, #7]
    // 0x12e8070: ldur            x1, [fp, #-8]
    // 0x12e8074: ldur            x2, [fp, #-0x38]
    // 0x12e8078: mov             x3, x0
    // 0x12e807c: r0 = []=()
    //     0x12e807c: bl              #0x1288f5c  ; [dart:collection] _HashMap::[]=
    // 0x12e8080: ldur            x2, [fp, #-0x18]
    // 0x12e8084: b               #0x12e7f80
    // 0x12e8088: r0 = false
    //     0x12e8088: add             x0, NULL, #0x30  ; false
    // 0x12e808c: LeaveFrame
    //     0x12e808c: mov             SP, fp
    //     0x12e8090: ldp             fp, lr, [SP], #0x10
    // 0x12e8094: ret
    //     0x12e8094: ret             
    // 0x12e8098: r0 = true
    //     0x12e8098: add             x0, NULL, #0x20  ; true
    // 0x12e809c: LeaveFrame
    //     0x12e809c: mov             SP, fp
    //     0x12e80a0: ldp             fp, lr, [SP], #0x10
    // 0x12e80a4: ret
    //     0x12e80a4: ret             
    // 0x12e80a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e80a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e80ac: b               #0x12e7cb4
    // 0x12e80b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e80b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e80b4: b               #0x12e7e38
    // 0x12e80b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e80b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e80bc: b               #0x12e7f94
  }
  _ hash(/* No info */) {
    // ** addr: 0x12e8ebc, size: 0x290
    // 0x12e8ebc: EnterFrame
    //     0x12e8ebc: stp             fp, lr, [SP, #-0x10]!
    //     0x12e8ec0: mov             fp, SP
    // 0x12e8ec4: AllocStack(0x40)
    //     0x12e8ec4: sub             SP, SP, #0x40
    // 0x12e8ec8: SetupParameters(MapEquality<X0, X1> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x12e8ec8: mov             x4, x1
    //     0x12e8ecc: mov             x3, x2
    //     0x12e8ed0: stur            x1, [fp, #-0x10]
    //     0x12e8ed4: stur            x2, [fp, #-0x18]
    // 0x12e8ed8: CheckStackOverflow
    //     0x12e8ed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e8edc: cmp             SP, x16
    //     0x12e8ee0: b.ls            #0x12e913c
    // 0x12e8ee4: LoadField: r5 = r4->field_7
    //     0x12e8ee4: ldur            w5, [x4, #7]
    // 0x12e8ee8: DecompressPointer r5
    //     0x12e8ee8: add             x5, x5, HEAP, lsl #32
    // 0x12e8eec: mov             x0, x3
    // 0x12e8ef0: mov             x2, x5
    // 0x12e8ef4: stur            x5, [fp, #-8]
    // 0x12e8ef8: r1 = Null
    //     0x12e8ef8: mov             x1, NULL
    // 0x12e8efc: r8 = Map<X0, X1>?
    //     0x12e8efc: add             x8, PP, #0xd, lsl #12  ; [pp+0xd028] Type: Map<X0, X1>?
    //     0x12e8f00: ldr             x8, [x8, #0x28]
    // 0x12e8f04: LoadField: r9 = r8->field_7
    //     0x12e8f04: ldur            x9, [x8, #7]
    // 0x12e8f08: r3 = Null
    //     0x12e8f08: add             x3, PP, #0xd, lsl #12  ; [pp+0xd030] Null
    //     0x12e8f0c: ldr             x3, [x3, #0x30]
    // 0x12e8f10: blr             x9
    // 0x12e8f14: ldur            x2, [fp, #-0x18]
    // 0x12e8f18: cmp             w2, NULL
    // 0x12e8f1c: b.ne            #0x12e8f30
    // 0x12e8f20: r0 = 2011
    //     0x12e8f20: mov             x0, #0x7db
    // 0x12e8f24: LeaveFrame
    //     0x12e8f24: mov             SP, fp
    //     0x12e8f28: ldp             fp, lr, [SP], #0x10
    // 0x12e8f2c: ret
    //     0x12e8f2c: ret             
    // 0x12e8f30: ldur            x3, [fp, #-0x10]
    // 0x12e8f34: r0 = LoadClassIdInstr(r2)
    //     0x12e8f34: ldur            x0, [x2, #-1]
    //     0x12e8f38: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8f3c: mov             x1, x2
    // 0x12e8f40: r0 = GDT[cid_x0 + 0x44d]()
    //     0x12e8f40: add             lr, x0, #0x44d
    //     0x12e8f44: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8f48: blr             lr
    // 0x12e8f4c: r1 = LoadClassIdInstr(r0)
    //     0x12e8f4c: ldur            x1, [x0, #-1]
    //     0x12e8f50: ubfx            x1, x1, #0xc, #0x14
    // 0x12e8f54: mov             x16, x0
    // 0x12e8f58: mov             x0, x1
    // 0x12e8f5c: mov             x1, x16
    // 0x12e8f60: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e8f60: mov             x17, #0x2641
    //     0x12e8f64: movk            x17, #1, lsl #16
    //     0x12e8f68: add             lr, x0, x17
    //     0x12e8f6c: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8f70: blr             lr
    // 0x12e8f74: mov             x2, x0
    // 0x12e8f78: ldur            x0, [fp, #-0x10]
    // 0x12e8f7c: stur            x2, [fp, #-0x38]
    // 0x12e8f80: LoadField: r3 = r0->field_b
    //     0x12e8f80: ldur            w3, [x0, #0xb]
    // 0x12e8f84: DecompressPointer r3
    //     0x12e8f84: add             x3, x3, HEAP, lsl #32
    // 0x12e8f88: stur            x3, [fp, #-0x30]
    // 0x12e8f8c: LoadField: r4 = r0->field_f
    //     0x12e8f8c: ldur            w4, [x0, #0xf]
    // 0x12e8f90: DecompressPointer r4
    //     0x12e8f90: add             x4, x4, HEAP, lsl #32
    // 0x12e8f94: stur            x4, [fp, #-0x28]
    // 0x12e8f98: r6 = 0
    //     0x12e8f98: mov             x6, #0
    // 0x12e8f9c: ldur            x5, [fp, #-0x18]
    // 0x12e8fa0: stur            x6, [fp, #-0x20]
    // 0x12e8fa4: CheckStackOverflow
    //     0x12e8fa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e8fa8: cmp             SP, x16
    //     0x12e8fac: b.ls            #0x12e9144
    // 0x12e8fb0: r0 = LoadClassIdInstr(r2)
    //     0x12e8fb0: ldur            x0, [x2, #-1]
    //     0x12e8fb4: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8fb8: mov             x1, x2
    // 0x12e8fbc: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e8fbc: mov             x17, #0x845b
    //     0x12e8fc0: movk            x17, #1, lsl #16
    //     0x12e8fc4: add             lr, x0, x17
    //     0x12e8fc8: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8fcc: blr             lr
    // 0x12e8fd0: tbnz            w0, #4, #0x12e90f8
    // 0x12e8fd4: ldur            x4, [fp, #-0x18]
    // 0x12e8fd8: ldur            x2, [fp, #-0x38]
    // 0x12e8fdc: ldur            x3, [fp, #-0x30]
    // 0x12e8fe0: r0 = LoadClassIdInstr(r2)
    //     0x12e8fe0: ldur            x0, [x2, #-1]
    //     0x12e8fe4: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8fe8: mov             x1, x2
    // 0x12e8fec: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e8fec: mov             x17, #0x7d4c
    //     0x12e8ff0: movk            x17, #1, lsl #16
    //     0x12e8ff4: add             lr, x0, x17
    //     0x12e8ff8: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8ffc: blr             lr
    // 0x12e9000: mov             x4, x0
    // 0x12e9004: ldur            x3, [fp, #-0x30]
    // 0x12e9008: stur            x4, [fp, #-0x10]
    // 0x12e900c: r0 = LoadClassIdInstr(r3)
    //     0x12e900c: ldur            x0, [x3, #-1]
    //     0x12e9010: ubfx            x0, x0, #0xc, #0x14
    // 0x12e9014: mov             x1, x3
    // 0x12e9018: mov             x2, x4
    // 0x12e901c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12e901c: sub             lr, x0, #1, lsl #12
    //     0x12e9020: ldr             lr, [x21, lr, lsl #3]
    //     0x12e9024: blr             lr
    // 0x12e9028: mov             x4, x0
    // 0x12e902c: ldur            x3, [fp, #-0x18]
    // 0x12e9030: stur            x4, [fp, #-0x40]
    // 0x12e9034: r0 = LoadClassIdInstr(r3)
    //     0x12e9034: ldur            x0, [x3, #-1]
    //     0x12e9038: ubfx            x0, x0, #0xc, #0x14
    // 0x12e903c: mov             x1, x3
    // 0x12e9040: ldur            x2, [fp, #-0x10]
    // 0x12e9044: r0 = GDT[cid_x0 + -0xd48]()
    //     0x12e9044: sub             lr, x0, #0xd48
    //     0x12e9048: ldr             lr, [x21, lr, lsl #3]
    //     0x12e904c: blr             lr
    // 0x12e9050: mov             x3, x0
    // 0x12e9054: stur            x3, [fp, #-0x10]
    // 0x12e9058: cmp             w3, NULL
    // 0x12e905c: b.ne            #0x12e9090
    // 0x12e9060: mov             x0, x3
    // 0x12e9064: ldur            x2, [fp, #-8]
    // 0x12e9068: r1 = Null
    //     0x12e9068: mov             x1, NULL
    // 0x12e906c: cmp             w2, NULL
    // 0x12e9070: b.eq            #0x12e9090
    // 0x12e9074: LoadField: r4 = r2->field_1b
    //     0x12e9074: ldur            w4, [x2, #0x1b]
    // 0x12e9078: DecompressPointer r4
    //     0x12e9078: add             x4, x4, HEAP, lsl #32
    // 0x12e907c: r8 = X1
    //     0x12e907c: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x12e9080: LoadField: r9 = r4->field_7
    //     0x12e9080: ldur            x9, [x4, #7]
    // 0x12e9084: r3 = Null
    //     0x12e9084: add             x3, PP, #0xd, lsl #12  ; [pp+0xd040] Null
    //     0x12e9088: ldr             x3, [x3, #0x40]
    // 0x12e908c: blr             x9
    // 0x12e9090: ldur            x3, [fp, #-0x28]
    // 0x12e9094: r0 = LoadClassIdInstr(r3)
    //     0x12e9094: ldur            x0, [x3, #-1]
    //     0x12e9098: ubfx            x0, x0, #0xc, #0x14
    // 0x12e909c: mov             x1, x3
    // 0x12e90a0: ldur            x2, [fp, #-0x10]
    // 0x12e90a4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12e90a4: sub             lr, x0, #1, lsl #12
    //     0x12e90a8: ldr             lr, [x21, lr, lsl #3]
    //     0x12e90ac: blr             lr
    // 0x12e90b0: ldur            x1, [fp, #-0x40]
    // 0x12e90b4: ubfx            x1, x1, #0, #0x20
    // 0x12e90b8: r16 = 3
    //     0x12e90b8: mov             x16, #3
    // 0x12e90bc: mul             x2, x1, x16
    // 0x12e90c0: ldur            x1, [fp, #-0x20]
    // 0x12e90c4: ubfx            x1, x1, #0, #0x20
    // 0x12e90c8: add             w3, w1, w2
    // 0x12e90cc: ubfx            x0, x0, #0, #0x20
    // 0x12e90d0: r16 = 7
    //     0x12e90d0: mov             x16, #7
    // 0x12e90d4: mul             x1, x0, x16
    // 0x12e90d8: add             w2, w3, w1
    // 0x12e90dc: and             w1, w2, #0x7fffffff
    // 0x12e90e0: ubfx            x1, x1, #0, #0x20
    // 0x12e90e4: mov             x6, x1
    // 0x12e90e8: ldur            x2, [fp, #-0x38]
    // 0x12e90ec: ldur            x3, [fp, #-0x30]
    // 0x12e90f0: ldur            x4, [fp, #-0x28]
    // 0x12e90f4: b               #0x12e8f9c
    // 0x12e90f8: ldur            x1, [fp, #-0x20]
    // 0x12e90fc: ubfx            x1, x1, #0, #0x20
    // 0x12e9100: lsl             w2, w1, #3
    // 0x12e9104: ldur            x1, [fp, #-0x20]
    // 0x12e9108: ubfx            x1, x1, #0, #0x20
    // 0x12e910c: add             w3, w1, w2
    // 0x12e9110: and             w1, w3, #0x7fffffff
    // 0x12e9114: lsr             w2, w1, #0xb
    // 0x12e9118: eor             x3, x1, x2
    // 0x12e911c: lsl             w1, w3, #0xf
    // 0x12e9120: add             w2, w3, w1
    // 0x12e9124: and             w1, w2, #0x7fffffff
    // 0x12e9128: ubfx            x1, x1, #0, #0x20
    // 0x12e912c: mov             x0, x1
    // 0x12e9130: LeaveFrame
    //     0x12e9130: mov             SP, fp
    //     0x12e9134: ldp             fp, lr, [SP], #0x10
    // 0x12e9138: ret
    //     0x12e9138: ret             
    // 0x12e913c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e913c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9140: b               #0x12e8ee4
    // 0x12e9144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e9144: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e9148: b               #0x12e8fb0
  }
}

// class id: 3571, size: 0x14, field offset: 0x8
class _MapEntry extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0x11495b4, size: 0x100
    // 0x11495b4: EnterFrame
    //     0x11495b4: stp             fp, lr, [SP, #-0x10]!
    //     0x11495b8: mov             fp, SP
    // 0x11495bc: AllocStack(0x10)
    //     0x11495bc: sub             SP, SP, #0x10
    // 0x11495c0: CheckStackOverflow
    //     0x11495c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11495c4: cmp             SP, x16
    //     0x11495c8: b.ls            #0x114969c
    // 0x11495cc: ldr             x3, [fp, #0x10]
    // 0x11495d0: LoadField: r4 = r3->field_7
    //     0x11495d0: ldur            w4, [x3, #7]
    // 0x11495d4: DecompressPointer r4
    //     0x11495d4: add             x4, x4, HEAP, lsl #32
    // 0x11495d8: stur            x4, [fp, #-8]
    // 0x11495dc: LoadField: r1 = r4->field_b
    //     0x11495dc: ldur            w1, [x4, #0xb]
    // 0x11495e0: DecompressPointer r1
    //     0x11495e0: add             x1, x1, HEAP, lsl #32
    // 0x11495e4: LoadField: r2 = r3->field_b
    //     0x11495e4: ldur            w2, [x3, #0xb]
    // 0x11495e8: DecompressPointer r2
    //     0x11495e8: add             x2, x2, HEAP, lsl #32
    // 0x11495ec: r0 = LoadClassIdInstr(r1)
    //     0x11495ec: ldur            x0, [x1, #-1]
    //     0x11495f0: ubfx            x0, x0, #0xc, #0x14
    // 0x11495f4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11495f4: sub             lr, x0, #1, lsl #12
    //     0x11495f8: ldr             lr, [x21, lr, lsl #3]
    //     0x11495fc: blr             lr
    // 0x1149600: r16 = 3
    //     0x1149600: mov             x16, #3
    // 0x1149604: mul             x3, x0, x16
    // 0x1149608: ldur            x0, [fp, #-8]
    // 0x114960c: stur            x3, [fp, #-0x10]
    // 0x1149610: LoadField: r1 = r0->field_f
    //     0x1149610: ldur            w1, [x0, #0xf]
    // 0x1149614: DecompressPointer r1
    //     0x1149614: add             x1, x1, HEAP, lsl #32
    // 0x1149618: ldr             x0, [fp, #0x10]
    // 0x114961c: LoadField: r2 = r0->field_f
    //     0x114961c: ldur            w2, [x0, #0xf]
    // 0x1149620: DecompressPointer r2
    //     0x1149620: add             x2, x2, HEAP, lsl #32
    // 0x1149624: r0 = LoadClassIdInstr(r1)
    //     0x1149624: ldur            x0, [x1, #-1]
    //     0x1149628: ubfx            x0, x0, #0xc, #0x14
    // 0x114962c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x114962c: sub             lr, x0, #1, lsl #12
    //     0x1149630: ldr             lr, [x21, lr, lsl #3]
    //     0x1149634: blr             lr
    // 0x1149638: ubfx            x0, x0, #0, #0x20
    // 0x114963c: r16 = 7
    //     0x114963c: mov             x16, #7
    // 0x1149640: mul             x1, x0, x16
    // 0x1149644: ldur            x2, [fp, #-0x10]
    // 0x1149648: ubfx            x2, x2, #0, #0x20
    // 0x114964c: add             w3, w2, w1
    // 0x1149650: and             w1, w3, #0x7fffffff
    // 0x1149654: lsl             w0, w1, #1
    // 0x1149658: tst             x1, #0xc0000000
    // 0x114965c: b.eq            #0x1149690
    // 0x1149660: r0 = inline_Allocate_Mint()
    //     0x1149660: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x1149664: add             x0, x0, #0x10
    //     0x1149668: cmp             x2, x0
    //     0x114966c: b.ls            #0x11496a4
    //     0x1149670: str             x0, [THR, #0x60]  ; THR::top
    //     0x1149674: sub             x0, x0, #0xf
    //     0x1149678: mov             x2, #0xd19c
    //     0x114967c: movk            x2, #3, lsl #16
    //     0x1149680: stur            x2, [x0, #-1]
    // 0x1149684: dmb             ishst
    // 0x1149688: ubfx            x2, x1, #0, #0x20
    // 0x114968c: StoreField: r0->field_7 = r2
    //     0x114968c: stur            x2, [x0, #7]
    // 0x1149690: LeaveFrame
    //     0x1149690: mov             SP, fp
    //     0x1149694: ldp             fp, lr, [SP], #0x10
    // 0x1149698: ret
    //     0x1149698: ret             
    // 0x114969c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114969c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11496a0: b               #0x11495cc
    // 0x11496a4: SaveReg r1
    //     0x11496a4: str             x1, [SP, #-8]!
    // 0x11496a8: r0 = AllocateMint()
    //     0x11496a8: bl              #0x13df8d0  ; AllocateMintStub
    // 0x11496ac: RestoreReg r1
    //     0x11496ac: ldr             x1, [SP], #8
    // 0x11496b0: b               #0x1149688
  }
  _ ==(/* No info */) {
    // ** addr: 0x12928ec, size: 0xec
    // 0x12928ec: EnterFrame
    //     0x12928ec: stp             fp, lr, [SP, #-0x10]!
    //     0x12928f0: mov             fp, SP
    // 0x12928f4: AllocStack(0x8)
    //     0x12928f4: sub             SP, SP, #8
    // 0x12928f8: CheckStackOverflow
    //     0x12928f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12928fc: cmp             SP, x16
    //     0x1292900: b.ls            #0x12929d0
    // 0x1292904: ldr             x4, [fp, #0x10]
    // 0x1292908: cmp             w4, NULL
    // 0x129290c: b.ne            #0x1292920
    // 0x1292910: r0 = false
    //     0x1292910: add             x0, NULL, #0x30  ; false
    // 0x1292914: LeaveFrame
    //     0x1292914: mov             SP, fp
    //     0x1292918: ldp             fp, lr, [SP], #0x10
    // 0x129291c: ret
    //     0x129291c: ret             
    // 0x1292920: r0 = 60
    //     0x1292920: mov             x0, #0x3c
    // 0x1292924: branchIfSmi(r4, 0x1292930)
    //     0x1292924: tbz             w4, #0, #0x1292930
    // 0x1292928: r0 = LoadClassIdInstr(r4)
    //     0x1292928: ldur            x0, [x4, #-1]
    //     0x129292c: ubfx            x0, x0, #0xc, #0x14
    // 0x1292930: cmp             x0, #0xdf3
    // 0x1292934: b.ne            #0x12929c0
    // 0x1292938: ldr             x5, [fp, #0x18]
    // 0x129293c: LoadField: r6 = r5->field_7
    //     0x129293c: ldur            w6, [x5, #7]
    // 0x1292940: DecompressPointer r6
    //     0x1292940: add             x6, x6, HEAP, lsl #32
    // 0x1292944: stur            x6, [fp, #-8]
    // 0x1292948: LoadField: r1 = r6->field_b
    //     0x1292948: ldur            w1, [x6, #0xb]
    // 0x129294c: DecompressPointer r1
    //     0x129294c: add             x1, x1, HEAP, lsl #32
    // 0x1292950: LoadField: r2 = r5->field_b
    //     0x1292950: ldur            w2, [x5, #0xb]
    // 0x1292954: DecompressPointer r2
    //     0x1292954: add             x2, x2, HEAP, lsl #32
    // 0x1292958: LoadField: r3 = r4->field_b
    //     0x1292958: ldur            w3, [x4, #0xb]
    // 0x129295c: DecompressPointer r3
    //     0x129295c: add             x3, x3, HEAP, lsl #32
    // 0x1292960: r0 = LoadClassIdInstr(r1)
    //     0x1292960: ldur            x0, [x1, #-1]
    //     0x1292964: ubfx            x0, x0, #0xc, #0x14
    // 0x1292968: r0 = GDT[cid_x0 + -0xff7]()
    //     0x1292968: sub             lr, x0, #0xff7
    //     0x129296c: ldr             lr, [x21, lr, lsl #3]
    //     0x1292970: blr             lr
    // 0x1292974: tbnz            w0, #4, #0x12929c0
    // 0x1292978: ldr             x1, [fp, #0x18]
    // 0x129297c: ldr             x0, [fp, #0x10]
    // 0x1292980: ldur            x2, [fp, #-8]
    // 0x1292984: LoadField: r3 = r2->field_f
    //     0x1292984: ldur            w3, [x2, #0xf]
    // 0x1292988: DecompressPointer r3
    //     0x1292988: add             x3, x3, HEAP, lsl #32
    // 0x129298c: LoadField: r2 = r1->field_f
    //     0x129298c: ldur            w2, [x1, #0xf]
    // 0x1292990: DecompressPointer r2
    //     0x1292990: add             x2, x2, HEAP, lsl #32
    // 0x1292994: LoadField: r1 = r0->field_f
    //     0x1292994: ldur            w1, [x0, #0xf]
    // 0x1292998: DecompressPointer r1
    //     0x1292998: add             x1, x1, HEAP, lsl #32
    // 0x129299c: r0 = LoadClassIdInstr(r3)
    //     0x129299c: ldur            x0, [x3, #-1]
    //     0x12929a0: ubfx            x0, x0, #0xc, #0x14
    // 0x12929a4: mov             x16, x1
    // 0x12929a8: mov             x1, x3
    // 0x12929ac: mov             x3, x16
    // 0x12929b0: r0 = GDT[cid_x0 + -0xff7]()
    //     0x12929b0: sub             lr, x0, #0xff7
    //     0x12929b4: ldr             lr, [x21, lr, lsl #3]
    //     0x12929b8: blr             lr
    // 0x12929bc: b               #0x12929c4
    // 0x12929c0: r0 = false
    //     0x12929c0: add             x0, NULL, #0x30  ; false
    // 0x12929c4: LeaveFrame
    //     0x12929c4: mov             SP, fp
    //     0x12929c8: ldp             fp, lr, [SP], #0x10
    // 0x12929cc: ret
    //     0x12929cc: ret             
    // 0x12929d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12929d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12929d4: b               #0x1292904
  }
}

// class id: 3572, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class _UnorderedEquality<X0, X1 bound Iterable> extends Object
    implements Equality<X0> {

  _ equals(/* No info */) {
    // ** addr: 0x12e77dc, size: 0x40c
    // 0x12e77dc: EnterFrame
    //     0x12e77dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12e77e0: mov             fp, SP
    // 0x12e77e4: AllocStack(0x38)
    //     0x12e77e4: sub             SP, SP, #0x38
    // 0x12e77e8: SetupParameters(_UnorderedEquality<X0, X1 bound Iterable> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12e77e8: mov             x5, x1
    //     0x12e77ec: mov             x4, x2
    //     0x12e77f0: stur            x1, [fp, #-0x10]
    //     0x12e77f4: stur            x2, [fp, #-0x18]
    //     0x12e77f8: stur            x3, [fp, #-0x20]
    // 0x12e77fc: CheckStackOverflow
    //     0x12e77fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7800: cmp             SP, x16
    //     0x12e7804: b.ls            #0x12e7bd0
    // 0x12e7808: LoadField: r6 = r5->field_7
    //     0x12e7808: ldur            w6, [x5, #7]
    // 0x12e780c: DecompressPointer r6
    //     0x12e780c: add             x6, x6, HEAP, lsl #32
    // 0x12e7810: mov             x0, x4
    // 0x12e7814: mov             x2, x6
    // 0x12e7818: stur            x6, [fp, #-8]
    // 0x12e781c: r1 = Null
    //     0x12e781c: mov             x1, NULL
    // 0x12e7820: cmp             w0, NULL
    // 0x12e7824: b.eq            #0x12e7850
    // 0x12e7828: cmp             w2, NULL
    // 0x12e782c: b.eq            #0x12e7850
    // 0x12e7830: LoadField: r4 = r2->field_1b
    //     0x12e7830: ldur            w4, [x2, #0x1b]
    // 0x12e7834: DecompressPointer r4
    //     0x12e7834: add             x4, x4, HEAP, lsl #32
    // 0x12e7838: r8 = X1? bound Iterable
    //     0x12e7838: add             x8, PP, #0x81, lsl #12  ; [pp+0x810c0] TypeParameter: X1? bound Iterable
    //     0x12e783c: ldr             x8, [x8, #0xc0]
    // 0x12e7840: LoadField: r9 = r4->field_7
    //     0x12e7840: ldur            x9, [x4, #7]
    // 0x12e7844: r3 = Null
    //     0x12e7844: add             x3, PP, #0x81, lsl #12  ; [pp+0x811d8] Null
    //     0x12e7848: ldr             x3, [x3, #0x1d8]
    // 0x12e784c: blr             x9
    // 0x12e7850: ldur            x0, [fp, #-0x20]
    // 0x12e7854: ldur            x2, [fp, #-8]
    // 0x12e7858: r1 = Null
    //     0x12e7858: mov             x1, NULL
    // 0x12e785c: cmp             w0, NULL
    // 0x12e7860: b.eq            #0x12e788c
    // 0x12e7864: cmp             w2, NULL
    // 0x12e7868: b.eq            #0x12e788c
    // 0x12e786c: LoadField: r4 = r2->field_1b
    //     0x12e786c: ldur            w4, [x2, #0x1b]
    // 0x12e7870: DecompressPointer r4
    //     0x12e7870: add             x4, x4, HEAP, lsl #32
    // 0x12e7874: r8 = X1? bound Iterable
    //     0x12e7874: add             x8, PP, #0x81, lsl #12  ; [pp+0x810c0] TypeParameter: X1? bound Iterable
    //     0x12e7878: ldr             x8, [x8, #0xc0]
    // 0x12e787c: LoadField: r9 = r4->field_7
    //     0x12e787c: ldur            x9, [x4, #7]
    // 0x12e7880: r3 = Null
    //     0x12e7880: add             x3, PP, #0x81, lsl #12  ; [pp+0x811e8] Null
    //     0x12e7884: ldr             x3, [x3, #0x1e8]
    // 0x12e7888: blr             x9
    // 0x12e788c: ldur            x0, [fp, #-0x18]
    // 0x12e7890: ldur            x1, [fp, #-0x20]
    // 0x12e7894: stp             x1, x0, [SP, #-0x10]!
    // 0x12e7898: r30 = OptimizedIdenticalWithNumberCheckStub
    //     0x12e7898: ldr             lr, [PP, #0x428]  ; [pp+0x428] Stub: OptimizedIdenticalWithNumberCheck (0x7d32ac)
    // 0x12e789c: LoadField: r30 = r30->field_7
    //     0x12e789c: ldur            lr, [lr, #7]
    // 0x12e78a0: blr             lr
    // 0x12e78a4: ldp             x1, x0, [SP], #0x10
    // 0x12e78a8: b.ne            #0x12e78bc
    // 0x12e78ac: r0 = true
    //     0x12e78ac: add             x0, NULL, #0x20  ; true
    // 0x12e78b0: LeaveFrame
    //     0x12e78b0: mov             SP, fp
    //     0x12e78b4: ldp             fp, lr, [SP], #0x10
    // 0x12e78b8: ret
    //     0x12e78b8: ret             
    // 0x12e78bc: ldur            x4, [fp, #-0x10]
    // 0x12e78c0: ldur            x0, [fp, #-0x18]
    // 0x12e78c4: ldur            x2, [fp, #-8]
    // 0x12e78c8: r1 = Null
    //     0x12e78c8: mov             x1, NULL
    // 0x12e78cc: r3 = <X0, int>
    //     0x12e78cc: add             x3, PP, #0x81, lsl #12  ; [pp+0x811f8] TypeArguments: <X0, int>
    //     0x12e78d0: ldr             x3, [x3, #0x1f8]
    // 0x12e78d4: r30 = InstantiateTypeArgumentsStub
    //     0x12e78d4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x12e78d8: LoadField: r30 = r30->field_7
    //     0x12e78d8: ldur            lr, [lr, #7]
    // 0x12e78dc: blr             lr
    // 0x12e78e0: mov             x3, x0
    // 0x12e78e4: ldur            x0, [fp, #-0x10]
    // 0x12e78e8: stur            x3, [fp, #-0x30]
    // 0x12e78ec: LoadField: r4 = r0->field_b
    //     0x12e78ec: ldur            w4, [x0, #0xb]
    // 0x12e78f0: DecompressPointer r4
    //     0x12e78f0: add             x4, x4, HEAP, lsl #32
    // 0x12e78f4: mov             x2, x4
    // 0x12e78f8: stur            x4, [fp, #-0x28]
    // 0x12e78fc: r1 = Function 'equals':.
    //     0x12e78fc: add             x1, PP, #0x81, lsl #12  ; [pp+0x81200] AnonymousClosure: (0x12e7c48), in [package:collection/src/equality.dart] DeepCollectionEquality::equals (0x12e82b0)
    //     0x12e7900: ldr             x1, [x1, #0x200]
    // 0x12e7904: r0 = AllocateClosure()
    //     0x12e7904: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12e7908: ldur            x2, [fp, #-8]
    // 0x12e790c: mov             x3, x0
    // 0x12e7910: r1 = Null
    //     0x12e7910: mov             x1, NULL
    // 0x12e7914: stur            x3, [fp, #-0x10]
    // 0x12e7918: r8 = (dynamic this, X0, X0) => bool
    //     0x12e7918: add             x8, PP, #0x81, lsl #12  ; [pp+0x81208] FunctionType: (dynamic this, X0, X0) => bool
    //     0x12e791c: ldr             x8, [x8, #0x208]
    // 0x12e7920: LoadField: r9 = r8->field_7
    //     0x12e7920: ldur            x9, [x8, #7]
    // 0x12e7924: r3 = Null
    //     0x12e7924: add             x3, PP, #0x81, lsl #12  ; [pp+0x81210] Null
    //     0x12e7928: ldr             x3, [x3, #0x210]
    // 0x12e792c: blr             x9
    // 0x12e7930: ldur            x2, [fp, #-0x28]
    // 0x12e7934: r1 = Function 'hash':.
    //     0x12e7934: add             x1, PP, #0x81, lsl #12  ; [pp+0x81220] AnonymousClosure: (0x12e7bf4), in [package:collection/src/equality.dart] DeepCollectionEquality::hash (0x12e914c)
    //     0x12e7938: ldr             x1, [x1, #0x220]
    // 0x12e793c: r0 = AllocateClosure()
    //     0x12e793c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12e7940: ldur            x2, [fp, #-8]
    // 0x12e7944: mov             x3, x0
    // 0x12e7948: r1 = Null
    //     0x12e7948: mov             x1, NULL
    // 0x12e794c: stur            x3, [fp, #-8]
    // 0x12e7950: r8 = (dynamic this, X0) => int
    //     0x12e7950: add             x8, PP, #0x81, lsl #12  ; [pp+0x81228] FunctionType: (dynamic this, X0) => int
    //     0x12e7954: ldr             x8, [x8, #0x228]
    // 0x12e7958: LoadField: r9 = r8->field_7
    //     0x12e7958: ldur            x9, [x8, #7]
    // 0x12e795c: r3 = Null
    //     0x12e795c: add             x3, PP, #0x81, lsl #12  ; [pp+0x81230] Null
    //     0x12e7960: ldr             x3, [x3, #0x230]
    // 0x12e7964: blr             x9
    // 0x12e7968: ldur            x1, [fp, #-0x30]
    // 0x12e796c: r0 = _CustomHashMap()
    //     0x12e796c: bl              #0x12e7be8  ; Allocate_CustomHashMapStub -> _CustomHashMap<X0, X1> (size=0x2c)
    // 0x12e7970: mov             x3, x0
    // 0x12e7974: ldur            x0, [fp, #-0x10]
    // 0x12e7978: stur            x3, [fp, #-0x30]
    // 0x12e797c: StoreField: r3->field_1f = r0
    //     0x12e797c: stur            w0, [x3, #0x1f]
    // 0x12e7980: ldur            x0, [fp, #-8]
    // 0x12e7984: StoreField: r3->field_23 = r0
    //     0x12e7984: stur            w0, [x3, #0x23]
    // 0x12e7988: ldur            x2, [fp, #-0x28]
    // 0x12e798c: r1 = Function 'isValidKey':.
    //     0x12e798c: add             x1, PP, #0x81, lsl #12  ; [pp+0x81240] AnonymousClosure: (0xb04fcc), in [package:collection/src/equality.dart] DeepCollectionEquality::isValidKey (0xb050b4)
    //     0x12e7990: ldr             x1, [x1, #0x240]
    // 0x12e7994: r0 = AllocateClosure()
    //     0x12e7994: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12e7998: mov             x1, x0
    // 0x12e799c: ldur            x0, [fp, #-0x30]
    // 0x12e79a0: StoreField: r0->field_27 = r1
    //     0x12e79a0: stur            w1, [x0, #0x27]
    // 0x12e79a4: StoreField: r0->field_b = rZR
    //     0x12e79a4: stur            xzr, [x0, #0xb]
    // 0x12e79a8: ArrayStore: r0[0] = rZR  ; List_8
    //     0x12e79a8: stur            xzr, [x0, #0x17]
    // 0x12e79ac: r1 = <_HashMapEntry?>
    //     0x12e79ac: add             x1, PP, #8, lsl #12  ; [pp+0x8930] TypeArguments: <_HashMapEntry?>
    //     0x12e79b0: ldr             x1, [x1, #0x930]
    // 0x12e79b4: r2 = 16
    //     0x12e79b4: mov             x2, #0x10
    // 0x12e79b8: r0 = AllocateArray()
    //     0x12e79b8: bl              #0x13df928  ; AllocateArrayStub
    // 0x12e79bc: ldur            x2, [fp, #-0x30]
    // 0x12e79c0: StoreField: r2->field_13 = r0
    //     0x12e79c0: stur            w0, [x2, #0x13]
    // 0x12e79c4: ldur            x1, [fp, #-0x18]
    // 0x12e79c8: r0 = LoadClassIdInstr(r1)
    //     0x12e79c8: ldur            x0, [x1, #-1]
    //     0x12e79cc: ubfx            x0, x0, #0xc, #0x14
    // 0x12e79d0: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e79d0: mov             x17, #0x2641
    //     0x12e79d4: movk            x17, #1, lsl #16
    //     0x12e79d8: add             lr, x0, x17
    //     0x12e79dc: ldr             lr, [x21, lr, lsl #3]
    //     0x12e79e0: blr             lr
    // 0x12e79e4: mov             x2, x0
    // 0x12e79e8: stur            x2, [fp, #-8]
    // 0x12e79ec: r3 = 0
    //     0x12e79ec: mov             x3, #0
    // 0x12e79f0: stur            x3, [fp, #-0x38]
    // 0x12e79f4: CheckStackOverflow
    //     0x12e79f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e79f8: cmp             SP, x16
    //     0x12e79fc: b.ls            #0x12e7bd8
    // 0x12e7a00: r0 = LoadClassIdInstr(r2)
    //     0x12e7a00: ldur            x0, [x2, #-1]
    //     0x12e7a04: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7a08: mov             x1, x2
    // 0x12e7a0c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e7a0c: mov             x17, #0x845b
    //     0x12e7a10: movk            x17, #1, lsl #16
    //     0x12e7a14: add             lr, x0, x17
    //     0x12e7a18: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7a1c: blr             lr
    // 0x12e7a20: tbnz            w0, #4, #0x12e7ab4
    // 0x12e7a24: ldur            x2, [fp, #-8]
    // 0x12e7a28: r0 = LoadClassIdInstr(r2)
    //     0x12e7a28: ldur            x0, [x2, #-1]
    //     0x12e7a2c: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7a30: mov             x1, x2
    // 0x12e7a34: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e7a34: mov             x17, #0x7d4c
    //     0x12e7a38: movk            x17, #1, lsl #16
    //     0x12e7a3c: add             lr, x0, x17
    //     0x12e7a40: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7a44: blr             lr
    // 0x12e7a48: ldur            x1, [fp, #-0x30]
    // 0x12e7a4c: mov             x2, x0
    // 0x12e7a50: stur            x0, [fp, #-0x10]
    // 0x12e7a54: r0 = []()
    //     0x12e7a54: bl              #0x1288708  ; [dart:collection] _CustomHashMap::[]
    // 0x12e7a58: cmp             w0, NULL
    // 0x12e7a5c: b.ne            #0x12e7a68
    // 0x12e7a60: r0 = 0
    //     0x12e7a60: mov             x0, #0
    // 0x12e7a64: b               #0x12e7a78
    // 0x12e7a68: r1 = LoadInt32Instr(r0)
    //     0x12e7a68: sbfx            x1, x0, #1, #0x1f
    //     0x12e7a6c: tbz             w0, #0, #0x12e7a74
    //     0x12e7a70: ldur            x1, [x0, #7]
    // 0x12e7a74: mov             x0, x1
    // 0x12e7a78: ldur            x4, [fp, #-0x38]
    // 0x12e7a7c: add             x2, x0, #1
    // 0x12e7a80: r0 = BoxInt64Instr(r2)
    //     0x12e7a80: sbfiz           x0, x2, #1, #0x1f
    //     0x12e7a84: cmp             x2, x0, asr #1
    //     0x12e7a88: b.eq            #0x12e7a94
    //     0x12e7a8c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e7a90: stur            x2, [x0, #7]
    // 0x12e7a94: ldur            x1, [fp, #-0x30]
    // 0x12e7a98: ldur            x2, [fp, #-0x10]
    // 0x12e7a9c: mov             x3, x0
    // 0x12e7aa0: r0 = []=()
    //     0x12e7aa0: bl              #0x1288d30  ; [dart:collection] _CustomHashMap::[]=
    // 0x12e7aa4: ldur            x2, [fp, #-0x38]
    // 0x12e7aa8: add             x3, x2, #1
    // 0x12e7aac: ldur            x2, [fp, #-8]
    // 0x12e7ab0: b               #0x12e79f0
    // 0x12e7ab4: ldur            x1, [fp, #-0x20]
    // 0x12e7ab8: ldur            x2, [fp, #-0x38]
    // 0x12e7abc: r0 = LoadClassIdInstr(r1)
    //     0x12e7abc: ldur            x0, [x1, #-1]
    //     0x12e7ac0: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7ac4: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e7ac4: mov             x17, #0x2641
    //     0x12e7ac8: movk            x17, #1, lsl #16
    //     0x12e7acc: add             lr, x0, x17
    //     0x12e7ad0: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7ad4: blr             lr
    // 0x12e7ad8: mov             x2, x0
    // 0x12e7adc: stur            x2, [fp, #-8]
    // 0x12e7ae0: ldur            x3, [fp, #-0x38]
    // 0x12e7ae4: stur            x3, [fp, #-0x38]
    // 0x12e7ae8: CheckStackOverflow
    //     0x12e7ae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7aec: cmp             SP, x16
    //     0x12e7af0: b.ls            #0x12e7be0
    // 0x12e7af4: r0 = LoadClassIdInstr(r2)
    //     0x12e7af4: ldur            x0, [x2, #-1]
    //     0x12e7af8: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7afc: mov             x1, x2
    // 0x12e7b00: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e7b00: mov             x17, #0x845b
    //     0x12e7b04: movk            x17, #1, lsl #16
    //     0x12e7b08: add             lr, x0, x17
    //     0x12e7b0c: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7b10: blr             lr
    // 0x12e7b14: tbnz            w0, #4, #0x12e7bb0
    // 0x12e7b18: ldur            x2, [fp, #-8]
    // 0x12e7b1c: r0 = LoadClassIdInstr(r2)
    //     0x12e7b1c: ldur            x0, [x2, #-1]
    //     0x12e7b20: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7b24: mov             x1, x2
    // 0x12e7b28: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e7b28: mov             x17, #0x7d4c
    //     0x12e7b2c: movk            x17, #1, lsl #16
    //     0x12e7b30: add             lr, x0, x17
    //     0x12e7b34: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7b38: blr             lr
    // 0x12e7b3c: ldur            x1, [fp, #-0x30]
    // 0x12e7b40: mov             x2, x0
    // 0x12e7b44: stur            x0, [fp, #-0x10]
    // 0x12e7b48: r0 = []()
    //     0x12e7b48: bl              #0x1288708  ; [dart:collection] _CustomHashMap::[]
    // 0x12e7b4c: cmp             w0, NULL
    // 0x12e7b50: b.eq            #0x12e7ba0
    // 0x12e7b54: cbz             w0, #0x12e7ba0
    // 0x12e7b58: ldur            x4, [fp, #-0x38]
    // 0x12e7b5c: r1 = LoadInt32Instr(r0)
    //     0x12e7b5c: sbfx            x1, x0, #1, #0x1f
    //     0x12e7b60: tbz             w0, #0, #0x12e7b68
    //     0x12e7b64: ldur            x1, [x0, #7]
    // 0x12e7b68: sub             x2, x1, #1
    // 0x12e7b6c: r0 = BoxInt64Instr(r2)
    //     0x12e7b6c: sbfiz           x0, x2, #1, #0x1f
    //     0x12e7b70: cmp             x2, x0, asr #1
    //     0x12e7b74: b.eq            #0x12e7b80
    //     0x12e7b78: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e7b7c: stur            x2, [x0, #7]
    // 0x12e7b80: ldur            x1, [fp, #-0x30]
    // 0x12e7b84: ldur            x2, [fp, #-0x10]
    // 0x12e7b88: mov             x3, x0
    // 0x12e7b8c: r0 = []=()
    //     0x12e7b8c: bl              #0x1288d30  ; [dart:collection] _CustomHashMap::[]=
    // 0x12e7b90: ldur            x1, [fp, #-0x38]
    // 0x12e7b94: sub             x3, x1, #1
    // 0x12e7b98: ldur            x2, [fp, #-8]
    // 0x12e7b9c: b               #0x12e7ae4
    // 0x12e7ba0: r0 = false
    //     0x12e7ba0: add             x0, NULL, #0x30  ; false
    // 0x12e7ba4: LeaveFrame
    //     0x12e7ba4: mov             SP, fp
    //     0x12e7ba8: ldp             fp, lr, [SP], #0x10
    // 0x12e7bac: ret
    //     0x12e7bac: ret             
    // 0x12e7bb0: ldur            x1, [fp, #-0x38]
    // 0x12e7bb4: cbz             x1, #0x12e7bc0
    // 0x12e7bb8: r0 = false
    //     0x12e7bb8: add             x0, NULL, #0x30  ; false
    // 0x12e7bbc: b               #0x12e7bc4
    // 0x12e7bc0: r0 = true
    //     0x12e7bc0: add             x0, NULL, #0x20  ; true
    // 0x12e7bc4: LeaveFrame
    //     0x12e7bc4: mov             SP, fp
    //     0x12e7bc8: ldp             fp, lr, [SP], #0x10
    // 0x12e7bcc: ret
    //     0x12e7bcc: ret             
    // 0x12e7bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e7bd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e7bd4: b               #0x12e7808
    // 0x12e7bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e7bd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e7bdc: b               #0x12e7a00
    // 0x12e7be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e7be0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e7be4: b               #0x12e7af4
  }
  _ hash(/* No info */) {
    // ** addr: 0x12e8d38, size: 0x184
    // 0x12e8d38: EnterFrame
    //     0x12e8d38: stp             fp, lr, [SP, #-0x10]!
    //     0x12e8d3c: mov             fp, SP
    // 0x12e8d40: AllocStack(0x20)
    //     0x12e8d40: sub             SP, SP, #0x20
    // 0x12e8d44: SetupParameters(_UnorderedEquality<X0, X1 bound Iterable> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x12e8d44: mov             x4, x1
    //     0x12e8d48: mov             x3, x2
    //     0x12e8d4c: stur            x1, [fp, #-8]
    //     0x12e8d50: stur            x2, [fp, #-0x10]
    // 0x12e8d54: CheckStackOverflow
    //     0x12e8d54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e8d58: cmp             SP, x16
    //     0x12e8d5c: b.ls            #0x12e8eac
    // 0x12e8d60: LoadField: r2 = r4->field_7
    //     0x12e8d60: ldur            w2, [x4, #7]
    // 0x12e8d64: DecompressPointer r2
    //     0x12e8d64: add             x2, x2, HEAP, lsl #32
    // 0x12e8d68: mov             x0, x3
    // 0x12e8d6c: r1 = Null
    //     0x12e8d6c: mov             x1, NULL
    // 0x12e8d70: cmp             w0, NULL
    // 0x12e8d74: b.eq            #0x12e8da0
    // 0x12e8d78: cmp             w2, NULL
    // 0x12e8d7c: b.eq            #0x12e8da0
    // 0x12e8d80: LoadField: r4 = r2->field_1b
    //     0x12e8d80: ldur            w4, [x2, #0x1b]
    // 0x12e8d84: DecompressPointer r4
    //     0x12e8d84: add             x4, x4, HEAP, lsl #32
    // 0x12e8d88: r8 = X1? bound Iterable
    //     0x12e8d88: add             x8, PP, #0x81, lsl #12  ; [pp+0x810c0] TypeParameter: X1? bound Iterable
    //     0x12e8d8c: ldr             x8, [x8, #0xc0]
    // 0x12e8d90: LoadField: r9 = r4->field_7
    //     0x12e8d90: ldur            x9, [x4, #7]
    // 0x12e8d94: r3 = Null
    //     0x12e8d94: add             x3, PP, #0x81, lsl #12  ; [pp+0x810c8] Null
    //     0x12e8d98: ldr             x3, [x3, #0xc8]
    // 0x12e8d9c: blr             x9
    // 0x12e8da0: ldur            x1, [fp, #-0x10]
    // 0x12e8da4: r0 = LoadClassIdInstr(r1)
    //     0x12e8da4: ldur            x0, [x1, #-1]
    //     0x12e8da8: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8dac: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e8dac: mov             x17, #0x2641
    //     0x12e8db0: movk            x17, #1, lsl #16
    //     0x12e8db4: add             lr, x0, x17
    //     0x12e8db8: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8dbc: blr             lr
    // 0x12e8dc0: mov             x2, x0
    // 0x12e8dc4: ldur            x0, [fp, #-8]
    // 0x12e8dc8: stur            x2, [fp, #-0x20]
    // 0x12e8dcc: LoadField: r3 = r0->field_b
    //     0x12e8dcc: ldur            w3, [x0, #0xb]
    // 0x12e8dd0: DecompressPointer r3
    //     0x12e8dd0: add             x3, x3, HEAP, lsl #32
    // 0x12e8dd4: stur            x3, [fp, #-0x10]
    // 0x12e8dd8: r4 = 0
    //     0x12e8dd8: mov             x4, #0
    // 0x12e8ddc: stur            x4, [fp, #-0x18]
    // 0x12e8de0: CheckStackOverflow
    //     0x12e8de0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e8de4: cmp             SP, x16
    //     0x12e8de8: b.ls            #0x12e8eb4
    // 0x12e8dec: r0 = LoadClassIdInstr(r2)
    //     0x12e8dec: ldur            x0, [x2, #-1]
    //     0x12e8df0: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8df4: mov             x1, x2
    // 0x12e8df8: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e8df8: mov             x17, #0x845b
    //     0x12e8dfc: movk            x17, #1, lsl #16
    //     0x12e8e00: add             lr, x0, x17
    //     0x12e8e04: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8e08: blr             lr
    // 0x12e8e0c: tbnz            w0, #4, #0x12e8e68
    // 0x12e8e10: ldur            x2, [fp, #-0x20]
    // 0x12e8e14: r0 = LoadClassIdInstr(r2)
    //     0x12e8e14: ldur            x0, [x2, #-1]
    //     0x12e8e18: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8e1c: mov             x1, x2
    // 0x12e8e20: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e8e20: mov             x17, #0x7d4c
    //     0x12e8e24: movk            x17, #1, lsl #16
    //     0x12e8e28: add             lr, x0, x17
    //     0x12e8e2c: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8e30: blr             lr
    // 0x12e8e34: ldur            x1, [fp, #-0x10]
    // 0x12e8e38: mov             x2, x0
    // 0x12e8e3c: r0 = hash()
    //     0x12e8e3c: bl              #0x12e914c  ; [package:collection/src/equality.dart] DeepCollectionEquality::hash
    // 0x12e8e40: ldur            x1, [fp, #-0x18]
    // 0x12e8e44: ubfx            x1, x1, #0, #0x20
    // 0x12e8e48: ubfx            x0, x0, #0, #0x20
    // 0x12e8e4c: add             w2, w1, w0
    // 0x12e8e50: and             w1, w2, #0x7fffffff
    // 0x12e8e54: ubfx            x1, x1, #0, #0x20
    // 0x12e8e58: mov             x4, x1
    // 0x12e8e5c: ldur            x2, [fp, #-0x20]
    // 0x12e8e60: ldur            x3, [fp, #-0x10]
    // 0x12e8e64: b               #0x12e8ddc
    // 0x12e8e68: ldur            x1, [fp, #-0x18]
    // 0x12e8e6c: ubfx            x1, x1, #0, #0x20
    // 0x12e8e70: lsl             w2, w1, #3
    // 0x12e8e74: ldur            x1, [fp, #-0x18]
    // 0x12e8e78: ubfx            x1, x1, #0, #0x20
    // 0x12e8e7c: add             w3, w1, w2
    // 0x12e8e80: and             w1, w3, #0x7fffffff
    // 0x12e8e84: lsr             w2, w1, #0xb
    // 0x12e8e88: eor             x3, x1, x2
    // 0x12e8e8c: lsl             w1, w3, #0xf
    // 0x12e8e90: add             w2, w3, w1
    // 0x12e8e94: and             w1, w2, #0x7fffffff
    // 0x12e8e98: ubfx            x1, x1, #0, #0x20
    // 0x12e8e9c: mov             x0, x1
    // 0x12e8ea0: LeaveFrame
    //     0x12e8ea0: mov             SP, fp
    //     0x12e8ea4: ldp             fp, lr, [SP], #0x10
    // 0x12e8ea8: ret
    //     0x12e8ea8: ret             
    // 0x12e8eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e8eac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e8eb0: b               #0x12e8d60
    // 0x12e8eb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e8eb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e8eb8: b               #0x12e8dec
  }
}

// class id: 3573, size: 0x10, field offset: 0x10
//   const constructor, 
class SetEquality<C2X0> extends _UnorderedEquality<C2X0, dynamic> {
}

// class id: 3575, size: 0x10, field offset: 0x8
//   const constructor, 
class ListEquality<X0> extends Object
    implements Equality<X0> {

  DefaultEquality<Never> field_c;

  _ equals(/* No info */) {
    // ** addr: 0x12e75bc, size: 0x220
    // 0x12e75bc: EnterFrame
    //     0x12e75bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12e75c0: mov             fp, SP
    // 0x12e75c4: AllocStack(0x48)
    //     0x12e75c4: sub             SP, SP, #0x48
    // 0x12e75c8: SetupParameters(ListEquality<X0> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12e75c8: mov             x5, x1
    //     0x12e75cc: mov             x4, x2
    //     0x12e75d0: stur            x1, [fp, #-0x10]
    //     0x12e75d4: stur            x2, [fp, #-0x18]
    //     0x12e75d8: stur            x3, [fp, #-0x20]
    // 0x12e75dc: CheckStackOverflow
    //     0x12e75dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e75e0: cmp             SP, x16
    //     0x12e75e4: b.ls            #0x12e77cc
    // 0x12e75e8: LoadField: r6 = r5->field_7
    //     0x12e75e8: ldur            w6, [x5, #7]
    // 0x12e75ec: DecompressPointer r6
    //     0x12e75ec: add             x6, x6, HEAP, lsl #32
    // 0x12e75f0: mov             x0, x4
    // 0x12e75f4: mov             x2, x6
    // 0x12e75f8: stur            x6, [fp, #-8]
    // 0x12e75fc: r1 = Null
    //     0x12e75fc: mov             x1, NULL
    // 0x12e7600: r8 = List<X0>?
    //     0x12e7600: add             x8, PP, #0x81, lsl #12  ; [pp+0x810a8] Type: List<X0>?
    //     0x12e7604: ldr             x8, [x8, #0xa8]
    // 0x12e7608: LoadField: r9 = r8->field_7
    //     0x12e7608: ldur            x9, [x8, #7]
    // 0x12e760c: r3 = Null
    //     0x12e760c: add             x3, PP, #0x81, lsl #12  ; [pp+0x811b8] Null
    //     0x12e7610: ldr             x3, [x3, #0x1b8]
    // 0x12e7614: blr             x9
    // 0x12e7618: ldur            x0, [fp, #-0x20]
    // 0x12e761c: ldur            x2, [fp, #-8]
    // 0x12e7620: r1 = Null
    //     0x12e7620: mov             x1, NULL
    // 0x12e7624: r8 = List<X0>?
    //     0x12e7624: add             x8, PP, #0x81, lsl #12  ; [pp+0x810a8] Type: List<X0>?
    //     0x12e7628: ldr             x8, [x8, #0xa8]
    // 0x12e762c: LoadField: r9 = r8->field_7
    //     0x12e762c: ldur            x9, [x8, #7]
    // 0x12e7630: r3 = Null
    //     0x12e7630: add             x3, PP, #0x81, lsl #12  ; [pp+0x811c8] Null
    //     0x12e7634: ldr             x3, [x3, #0x1c8]
    // 0x12e7638: blr             x9
    // 0x12e763c: ldur            x2, [fp, #-0x18]
    // 0x12e7640: ldur            x1, [fp, #-0x20]
    // 0x12e7644: cmp             w2, w1
    // 0x12e7648: b.ne            #0x12e765c
    // 0x12e764c: r0 = true
    //     0x12e764c: add             x0, NULL, #0x20  ; true
    // 0x12e7650: LeaveFrame
    //     0x12e7650: mov             SP, fp
    //     0x12e7654: ldp             fp, lr, [SP], #0x10
    // 0x12e7658: ret
    //     0x12e7658: ret             
    // 0x12e765c: r0 = LoadClassIdInstr(r2)
    //     0x12e765c: ldur            x0, [x2, #-1]
    //     0x12e7660: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7664: str             x2, [SP]
    // 0x12e7668: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12e7668: mov             x17, #0xf078
    //     0x12e766c: add             lr, x0, x17
    //     0x12e7670: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7674: blr             lr
    // 0x12e7678: mov             x2, x0
    // 0x12e767c: ldur            x1, [fp, #-0x20]
    // 0x12e7680: stur            x2, [fp, #-8]
    // 0x12e7684: r0 = LoadClassIdInstr(r1)
    //     0x12e7684: ldur            x0, [x1, #-1]
    //     0x12e7688: ubfx            x0, x0, #0xc, #0x14
    // 0x12e768c: str             x1, [SP]
    // 0x12e7690: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12e7690: mov             x17, #0xf078
    //     0x12e7694: add             lr, x0, x17
    //     0x12e7698: ldr             lr, [x21, lr, lsl #3]
    //     0x12e769c: blr             lr
    // 0x12e76a0: mov             x1, x0
    // 0x12e76a4: ldur            x0, [fp, #-8]
    // 0x12e76a8: r2 = LoadInt32Instr(r0)
    //     0x12e76a8: sbfx            x2, x0, #1, #0x1f
    //     0x12e76ac: tbz             w0, #0, #0x12e76b4
    //     0x12e76b0: ldur            x2, [x0, #7]
    // 0x12e76b4: stur            x2, [fp, #-0x38]
    // 0x12e76b8: r0 = LoadInt32Instr(r1)
    //     0x12e76b8: sbfx            x0, x1, #1, #0x1f
    //     0x12e76bc: tbz             w1, #0, #0x12e76c4
    //     0x12e76c0: ldur            x0, [x1, #7]
    // 0x12e76c4: cmp             x2, x0
    // 0x12e76c8: b.eq            #0x12e76dc
    // 0x12e76cc: r0 = false
    //     0x12e76cc: add             x0, NULL, #0x30  ; false
    // 0x12e76d0: LeaveFrame
    //     0x12e76d0: mov             SP, fp
    //     0x12e76d4: ldp             fp, lr, [SP], #0x10
    // 0x12e76d8: ret
    //     0x12e76d8: ret             
    // 0x12e76dc: ldur            x0, [fp, #-0x10]
    // 0x12e76e0: LoadField: r3 = r0->field_b
    //     0x12e76e0: ldur            w3, [x0, #0xb]
    // 0x12e76e4: DecompressPointer r3
    //     0x12e76e4: add             x3, x3, HEAP, lsl #32
    // 0x12e76e8: stur            x3, [fp, #-0x30]
    // 0x12e76ec: r6 = 0
    //     0x12e76ec: mov             x6, #0
    // 0x12e76f0: ldur            x5, [fp, #-0x18]
    // 0x12e76f4: ldur            x4, [fp, #-0x20]
    // 0x12e76f8: stur            x6, [fp, #-0x28]
    // 0x12e76fc: CheckStackOverflow
    //     0x12e76fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7700: cmp             SP, x16
    //     0x12e7704: b.ls            #0x12e77d4
    // 0x12e7708: cmp             x6, x2
    // 0x12e770c: b.ge            #0x12e77bc
    // 0x12e7710: r0 = BoxInt64Instr(r6)
    //     0x12e7710: sbfiz           x0, x6, #1, #0x1f
    //     0x12e7714: cmp             x6, x0, asr #1
    //     0x12e7718: b.eq            #0x12e7724
    //     0x12e771c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e7720: stur            x6, [x0, #7]
    // 0x12e7724: mov             x1, x0
    // 0x12e7728: stur            x1, [fp, #-8]
    // 0x12e772c: r0 = LoadClassIdInstr(r5)
    //     0x12e772c: ldur            x0, [x5, #-1]
    //     0x12e7730: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7734: stp             x1, x5, [SP]
    // 0x12e7738: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12e7738: sub             lr, x0, #0xdfd
    //     0x12e773c: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7740: blr             lr
    // 0x12e7744: mov             x2, x0
    // 0x12e7748: ldur            x1, [fp, #-0x20]
    // 0x12e774c: stur            x2, [fp, #-0x10]
    // 0x12e7750: r0 = LoadClassIdInstr(r1)
    //     0x12e7750: ldur            x0, [x1, #-1]
    //     0x12e7754: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7758: ldur            x16, [fp, #-8]
    // 0x12e775c: stp             x16, x1, [SP]
    // 0x12e7760: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12e7760: sub             lr, x0, #0xdfd
    //     0x12e7764: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7768: blr             lr
    // 0x12e776c: ldur            x4, [fp, #-0x30]
    // 0x12e7770: r1 = LoadClassIdInstr(r4)
    //     0x12e7770: ldur            x1, [x4, #-1]
    //     0x12e7774: ubfx            x1, x1, #0xc, #0x14
    // 0x12e7778: mov             x3, x0
    // 0x12e777c: mov             x0, x1
    // 0x12e7780: mov             x1, x4
    // 0x12e7784: ldur            x2, [fp, #-0x10]
    // 0x12e7788: r0 = GDT[cid_x0 + -0xff7]()
    //     0x12e7788: sub             lr, x0, #0xff7
    //     0x12e778c: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7790: blr             lr
    // 0x12e7794: tbnz            w0, #4, #0x12e77ac
    // 0x12e7798: ldur            x1, [fp, #-0x28]
    // 0x12e779c: add             x6, x1, #1
    // 0x12e77a0: ldur            x3, [fp, #-0x30]
    // 0x12e77a4: ldur            x2, [fp, #-0x38]
    // 0x12e77a8: b               #0x12e76f0
    // 0x12e77ac: r0 = false
    //     0x12e77ac: add             x0, NULL, #0x30  ; false
    // 0x12e77b0: LeaveFrame
    //     0x12e77b0: mov             SP, fp
    //     0x12e77b4: ldp             fp, lr, [SP], #0x10
    // 0x12e77b8: ret
    //     0x12e77b8: ret             
    // 0x12e77bc: r0 = true
    //     0x12e77bc: add             x0, NULL, #0x20  ; true
    // 0x12e77c0: LeaveFrame
    //     0x12e77c0: mov             SP, fp
    //     0x12e77c4: ldp             fp, lr, [SP], #0x10
    // 0x12e77c8: ret
    //     0x12e77c8: ret             
    // 0x12e77cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e77cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e77d0: b               #0x12e75e8
    // 0x12e77d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e77d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e77d8: b               #0x12e7708
  }
  _ hash(/* No info */) {
    // ** addr: 0x12e8b90, size: 0x1a8
    // 0x12e8b90: EnterFrame
    //     0x12e8b90: stp             fp, lr, [SP, #-0x10]!
    //     0x12e8b94: mov             fp, SP
    // 0x12e8b98: AllocStack(0x38)
    //     0x12e8b98: sub             SP, SP, #0x38
    // 0x12e8b9c: SetupParameters(ListEquality<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x12e8b9c: mov             x4, x1
    //     0x12e8ba0: mov             x3, x2
    //     0x12e8ba4: stur            x1, [fp, #-8]
    //     0x12e8ba8: stur            x2, [fp, #-0x10]
    // 0x12e8bac: CheckStackOverflow
    //     0x12e8bac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e8bb0: cmp             SP, x16
    //     0x12e8bb4: b.ls            #0x12e8d28
    // 0x12e8bb8: LoadField: r2 = r4->field_7
    //     0x12e8bb8: ldur            w2, [x4, #7]
    // 0x12e8bbc: DecompressPointer r2
    //     0x12e8bbc: add             x2, x2, HEAP, lsl #32
    // 0x12e8bc0: mov             x0, x3
    // 0x12e8bc4: r1 = Null
    //     0x12e8bc4: mov             x1, NULL
    // 0x12e8bc8: r8 = List<X0>?
    //     0x12e8bc8: add             x8, PP, #0x81, lsl #12  ; [pp+0x810a8] Type: List<X0>?
    //     0x12e8bcc: ldr             x8, [x8, #0xa8]
    // 0x12e8bd0: LoadField: r9 = r8->field_7
    //     0x12e8bd0: ldur            x9, [x8, #7]
    // 0x12e8bd4: r3 = Null
    //     0x12e8bd4: add             x3, PP, #0x81, lsl #12  ; [pp+0x810b0] Null
    //     0x12e8bd8: ldr             x3, [x3, #0xb0]
    // 0x12e8bdc: blr             x9
    // 0x12e8be0: ldur            x0, [fp, #-8]
    // 0x12e8be4: LoadField: r1 = r0->field_b
    //     0x12e8be4: ldur            w1, [x0, #0xb]
    // 0x12e8be8: DecompressPointer r1
    //     0x12e8be8: add             x1, x1, HEAP, lsl #32
    // 0x12e8bec: stur            x1, [fp, #-0x28]
    // 0x12e8bf0: r4 = 0
    //     0x12e8bf0: mov             x4, #0
    // 0x12e8bf4: r3 = 0
    //     0x12e8bf4: mov             x3, #0
    // 0x12e8bf8: ldur            x2, [fp, #-0x10]
    // 0x12e8bfc: stur            x4, [fp, #-0x18]
    // 0x12e8c00: stur            x3, [fp, #-0x20]
    // 0x12e8c04: CheckStackOverflow
    //     0x12e8c04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e8c08: cmp             SP, x16
    //     0x12e8c0c: b.ls            #0x12e8d30
    // 0x12e8c10: r0 = LoadClassIdInstr(r2)
    //     0x12e8c10: ldur            x0, [x2, #-1]
    //     0x12e8c14: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8c18: str             x2, [SP]
    // 0x12e8c1c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12e8c1c: mov             x17, #0xf078
    //     0x12e8c20: add             lr, x0, x17
    //     0x12e8c24: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8c28: blr             lr
    // 0x12e8c2c: r1 = LoadInt32Instr(r0)
    //     0x12e8c2c: sbfx            x1, x0, #1, #0x1f
    //     0x12e8c30: tbz             w0, #0, #0x12e8c38
    //     0x12e8c34: ldur            x1, [x0, #7]
    // 0x12e8c38: ldur            x2, [fp, #-0x20]
    // 0x12e8c3c: cmp             x2, x1
    // 0x12e8c40: b.ge            #0x12e8ce4
    // 0x12e8c44: ldur            x4, [fp, #-0x10]
    // 0x12e8c48: ldur            x3, [fp, #-0x28]
    // 0x12e8c4c: r0 = BoxInt64Instr(r2)
    //     0x12e8c4c: sbfiz           x0, x2, #1, #0x1f
    //     0x12e8c50: cmp             x2, x0, asr #1
    //     0x12e8c54: b.eq            #0x12e8c60
    //     0x12e8c58: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e8c5c: stur            x2, [x0, #7]
    // 0x12e8c60: r1 = LoadClassIdInstr(r4)
    //     0x12e8c60: ldur            x1, [x4, #-1]
    //     0x12e8c64: ubfx            x1, x1, #0xc, #0x14
    // 0x12e8c68: stp             x0, x4, [SP]
    // 0x12e8c6c: mov             x0, x1
    // 0x12e8c70: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12e8c70: sub             lr, x0, #0xdfd
    //     0x12e8c74: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8c78: blr             lr
    // 0x12e8c7c: ldur            x3, [fp, #-0x28]
    // 0x12e8c80: r1 = LoadClassIdInstr(r3)
    //     0x12e8c80: ldur            x1, [x3, #-1]
    //     0x12e8c84: ubfx            x1, x1, #0xc, #0x14
    // 0x12e8c88: mov             x2, x0
    // 0x12e8c8c: mov             x0, x1
    // 0x12e8c90: mov             x1, x3
    // 0x12e8c94: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12e8c94: sub             lr, x0, #1, lsl #12
    //     0x12e8c98: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8c9c: blr             lr
    // 0x12e8ca0: ldur            x1, [fp, #-0x18]
    // 0x12e8ca4: ubfx            x1, x1, #0, #0x20
    // 0x12e8ca8: ubfx            x0, x0, #0, #0x20
    // 0x12e8cac: add             w2, w1, w0
    // 0x12e8cb0: and             w1, w2, #0x7fffffff
    // 0x12e8cb4: lsl             w2, w1, #0xa
    // 0x12e8cb8: add             w3, w1, w2
    // 0x12e8cbc: and             w1, w3, #0x7fffffff
    // 0x12e8cc0: mov             x2, x1
    // 0x12e8cc4: ubfx            x2, x2, #0, #0x20
    // 0x12e8cc8: asr             x3, x2, #6
    // 0x12e8ccc: ubfx            x1, x1, #0, #0x20
    // 0x12e8cd0: eor             x4, x1, x3
    // 0x12e8cd4: ldur            x1, [fp, #-0x20]
    // 0x12e8cd8: add             x3, x1, #1
    // 0x12e8cdc: ldur            x1, [fp, #-0x28]
    // 0x12e8ce0: b               #0x12e8bf8
    // 0x12e8ce4: ldur            x1, [fp, #-0x18]
    // 0x12e8ce8: ubfx            x1, x1, #0, #0x20
    // 0x12e8cec: lsl             w2, w1, #3
    // 0x12e8cf0: ldur            x1, [fp, #-0x18]
    // 0x12e8cf4: ubfx            x1, x1, #0, #0x20
    // 0x12e8cf8: add             w3, w1, w2
    // 0x12e8cfc: and             w1, w3, #0x7fffffff
    // 0x12e8d00: lsr             w2, w1, #0xb
    // 0x12e8d04: eor             x3, x1, x2
    // 0x12e8d08: lsl             w1, w3, #0xf
    // 0x12e8d0c: add             w2, w3, w1
    // 0x12e8d10: and             w1, w2, #0x7fffffff
    // 0x12e8d14: ubfx            x1, x1, #0, #0x20
    // 0x12e8d18: mov             x0, x1
    // 0x12e8d1c: LeaveFrame
    //     0x12e8d1c: mov             SP, fp
    //     0x12e8d20: ldp             fp, lr, [SP], #0x10
    // 0x12e8d24: ret
    //     0x12e8d24: ret             
    // 0x12e8d28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e8d28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e8d2c: b               #0x12e8bb8
    // 0x12e8d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e8d30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e8d34: b               #0x12e8c10
  }
}

// class id: 3576, size: 0x10, field offset: 0x8
//   const constructor, 
class IterableEquality<X0> extends Object
    implements Equality<X0> {

  DefaultEquality<Never> field_c;

  _ equals(/* No info */) {
    // ** addr: 0x12e7384, size: 0x238
    // 0x12e7384: EnterFrame
    //     0x12e7384: stp             fp, lr, [SP, #-0x10]!
    //     0x12e7388: mov             fp, SP
    // 0x12e738c: AllocStack(0x20)
    //     0x12e738c: sub             SP, SP, #0x20
    // 0x12e7390: SetupParameters(IterableEquality<X0> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12e7390: mov             x5, x1
    //     0x12e7394: mov             x4, x2
    //     0x12e7398: stur            x1, [fp, #-0x10]
    //     0x12e739c: stur            x2, [fp, #-0x18]
    //     0x12e73a0: stur            x3, [fp, #-0x20]
    // 0x12e73a4: CheckStackOverflow
    //     0x12e73a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e73a8: cmp             SP, x16
    //     0x12e73ac: b.ls            #0x12e75ac
    // 0x12e73b0: LoadField: r6 = r5->field_7
    //     0x12e73b0: ldur            w6, [x5, #7]
    // 0x12e73b4: DecompressPointer r6
    //     0x12e73b4: add             x6, x6, HEAP, lsl #32
    // 0x12e73b8: mov             x0, x4
    // 0x12e73bc: mov             x2, x6
    // 0x12e73c0: stur            x6, [fp, #-8]
    // 0x12e73c4: r1 = Null
    //     0x12e73c4: mov             x1, NULL
    // 0x12e73c8: r8 = Iterable<X0>?
    //     0x12e73c8: ldr             x8, [PP, #0x75b0]  ; [pp+0x75b0] Type: Iterable<X0>?
    // 0x12e73cc: LoadField: r9 = r8->field_7
    //     0x12e73cc: ldur            x9, [x8, #7]
    // 0x12e73d0: r3 = Null
    //     0x12e73d0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81198] Null
    //     0x12e73d4: ldr             x3, [x3, #0x198]
    // 0x12e73d8: blr             x9
    // 0x12e73dc: ldur            x0, [fp, #-0x20]
    // 0x12e73e0: ldur            x2, [fp, #-8]
    // 0x12e73e4: r1 = Null
    //     0x12e73e4: mov             x1, NULL
    // 0x12e73e8: r8 = Iterable<X0>?
    //     0x12e73e8: ldr             x8, [PP, #0x75b0]  ; [pp+0x75b0] Type: Iterable<X0>?
    // 0x12e73ec: LoadField: r9 = r8->field_7
    //     0x12e73ec: ldur            x9, [x8, #7]
    // 0x12e73f0: r3 = Null
    //     0x12e73f0: add             x3, PP, #0x81, lsl #12  ; [pp+0x811a8] Null
    //     0x12e73f4: ldr             x3, [x3, #0x1a8]
    // 0x12e73f8: blr             x9
    // 0x12e73fc: ldur            x1, [fp, #-0x18]
    // 0x12e7400: ldur            x2, [fp, #-0x20]
    // 0x12e7404: cmp             w1, w2
    // 0x12e7408: b.ne            #0x12e741c
    // 0x12e740c: r0 = true
    //     0x12e740c: add             x0, NULL, #0x20  ; true
    // 0x12e7410: LeaveFrame
    //     0x12e7410: mov             SP, fp
    //     0x12e7414: ldp             fp, lr, [SP], #0x10
    // 0x12e7418: ret
    //     0x12e7418: ret             
    // 0x12e741c: ldur            x3, [fp, #-0x10]
    // 0x12e7420: r0 = LoadClassIdInstr(r1)
    //     0x12e7420: ldur            x0, [x1, #-1]
    //     0x12e7424: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7428: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e7428: mov             x17, #0x2641
    //     0x12e742c: movk            x17, #1, lsl #16
    //     0x12e7430: add             lr, x0, x17
    //     0x12e7434: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7438: blr             lr
    // 0x12e743c: mov             x2, x0
    // 0x12e7440: ldur            x1, [fp, #-0x20]
    // 0x12e7444: stur            x2, [fp, #-8]
    // 0x12e7448: r0 = LoadClassIdInstr(r1)
    //     0x12e7448: ldur            x0, [x1, #-1]
    //     0x12e744c: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7450: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e7450: mov             x17, #0x2641
    //     0x12e7454: movk            x17, #1, lsl #16
    //     0x12e7458: add             lr, x0, x17
    //     0x12e745c: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7460: blr             lr
    // 0x12e7464: mov             x2, x0
    // 0x12e7468: ldur            x0, [fp, #-0x10]
    // 0x12e746c: stur            x2, [fp, #-0x20]
    // 0x12e7470: LoadField: r3 = r0->field_b
    //     0x12e7470: ldur            w3, [x0, #0xb]
    // 0x12e7474: DecompressPointer r3
    //     0x12e7474: add             x3, x3, HEAP, lsl #32
    // 0x12e7478: stur            x3, [fp, #-0x18]
    // 0x12e747c: ldur            x4, [fp, #-8]
    // 0x12e7480: CheckStackOverflow
    //     0x12e7480: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7484: cmp             SP, x16
    //     0x12e7488: b.ls            #0x12e75b4
    // 0x12e748c: r0 = LoadClassIdInstr(r4)
    //     0x12e748c: ldur            x0, [x4, #-1]
    //     0x12e7490: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7494: mov             x1, x4
    // 0x12e7498: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e7498: mov             x17, #0x845b
    //     0x12e749c: movk            x17, #1, lsl #16
    //     0x12e74a0: add             lr, x0, x17
    //     0x12e74a4: ldr             lr, [x21, lr, lsl #3]
    //     0x12e74a8: blr             lr
    // 0x12e74ac: mov             x3, x0
    // 0x12e74b0: ldur            x2, [fp, #-0x20]
    // 0x12e74b4: stur            x3, [fp, #-0x10]
    // 0x12e74b8: r0 = LoadClassIdInstr(r2)
    //     0x12e74b8: ldur            x0, [x2, #-1]
    //     0x12e74bc: ubfx            x0, x0, #0xc, #0x14
    // 0x12e74c0: mov             x1, x2
    // 0x12e74c4: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e74c4: mov             x17, #0x845b
    //     0x12e74c8: movk            x17, #1, lsl #16
    //     0x12e74cc: add             lr, x0, x17
    //     0x12e74d0: ldr             lr, [x21, lr, lsl #3]
    //     0x12e74d4: blr             lr
    // 0x12e74d8: mov             x1, x0
    // 0x12e74dc: ldur            x0, [fp, #-0x10]
    // 0x12e74e0: cmp             w0, w1
    // 0x12e74e4: b.ne            #0x12e759c
    // 0x12e74e8: tbnz            w0, #4, #0x12e758c
    // 0x12e74ec: ldur            x4, [fp, #-8]
    // 0x12e74f0: ldur            x2, [fp, #-0x20]
    // 0x12e74f4: ldur            x3, [fp, #-0x18]
    // 0x12e74f8: r0 = LoadClassIdInstr(r4)
    //     0x12e74f8: ldur            x0, [x4, #-1]
    //     0x12e74fc: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7500: mov             x1, x4
    // 0x12e7504: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e7504: mov             x17, #0x7d4c
    //     0x12e7508: movk            x17, #1, lsl #16
    //     0x12e750c: add             lr, x0, x17
    //     0x12e7510: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7514: blr             lr
    // 0x12e7518: mov             x3, x0
    // 0x12e751c: ldur            x2, [fp, #-0x20]
    // 0x12e7520: stur            x3, [fp, #-0x10]
    // 0x12e7524: r0 = LoadClassIdInstr(r2)
    //     0x12e7524: ldur            x0, [x2, #-1]
    //     0x12e7528: ubfx            x0, x0, #0xc, #0x14
    // 0x12e752c: mov             x1, x2
    // 0x12e7530: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e7530: mov             x17, #0x7d4c
    //     0x12e7534: movk            x17, #1, lsl #16
    //     0x12e7538: add             lr, x0, x17
    //     0x12e753c: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7540: blr             lr
    // 0x12e7544: ldur            x4, [fp, #-0x18]
    // 0x12e7548: r1 = LoadClassIdInstr(r4)
    //     0x12e7548: ldur            x1, [x4, #-1]
    //     0x12e754c: ubfx            x1, x1, #0xc, #0x14
    // 0x12e7550: mov             x3, x0
    // 0x12e7554: mov             x0, x1
    // 0x12e7558: mov             x1, x4
    // 0x12e755c: ldur            x2, [fp, #-0x10]
    // 0x12e7560: r0 = GDT[cid_x0 + -0xff7]()
    //     0x12e7560: sub             lr, x0, #0xff7
    //     0x12e7564: ldr             lr, [x21, lr, lsl #3]
    //     0x12e7568: blr             lr
    // 0x12e756c: tbnz            w0, #4, #0x12e757c
    // 0x12e7570: ldur            x2, [fp, #-0x20]
    // 0x12e7574: ldur            x3, [fp, #-0x18]
    // 0x12e7578: b               #0x12e747c
    // 0x12e757c: r0 = false
    //     0x12e757c: add             x0, NULL, #0x30  ; false
    // 0x12e7580: LeaveFrame
    //     0x12e7580: mov             SP, fp
    //     0x12e7584: ldp             fp, lr, [SP], #0x10
    // 0x12e7588: ret
    //     0x12e7588: ret             
    // 0x12e758c: r0 = true
    //     0x12e758c: add             x0, NULL, #0x20  ; true
    // 0x12e7590: LeaveFrame
    //     0x12e7590: mov             SP, fp
    //     0x12e7594: ldp             fp, lr, [SP], #0x10
    // 0x12e7598: ret
    //     0x12e7598: ret             
    // 0x12e759c: r0 = false
    //     0x12e759c: add             x0, NULL, #0x30  ; false
    // 0x12e75a0: LeaveFrame
    //     0x12e75a0: mov             SP, fp
    //     0x12e75a4: ldp             fp, lr, [SP], #0x10
    // 0x12e75a8: ret
    //     0x12e75a8: ret             
    // 0x12e75ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e75ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e75b0: b               #0x12e73b0
    // 0x12e75b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e75b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e75b8: b               #0x12e748c
  }
  _ hash(/* No info */) {
    // ** addr: 0x12e89f4, size: 0x19c
    // 0x12e89f4: EnterFrame
    //     0x12e89f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12e89f8: mov             fp, SP
    // 0x12e89fc: AllocStack(0x20)
    //     0x12e89fc: sub             SP, SP, #0x20
    // 0x12e8a00: SetupParameters(IterableEquality<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x12e8a00: mov             x4, x1
    //     0x12e8a04: mov             x3, x2
    //     0x12e8a08: stur            x1, [fp, #-8]
    //     0x12e8a0c: stur            x2, [fp, #-0x10]
    // 0x12e8a10: CheckStackOverflow
    //     0x12e8a10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e8a14: cmp             SP, x16
    //     0x12e8a18: b.ls            #0x12e8b80
    // 0x12e8a1c: LoadField: r2 = r4->field_7
    //     0x12e8a1c: ldur            w2, [x4, #7]
    // 0x12e8a20: DecompressPointer r2
    //     0x12e8a20: add             x2, x2, HEAP, lsl #32
    // 0x12e8a24: mov             x0, x3
    // 0x12e8a28: r1 = Null
    //     0x12e8a28: mov             x1, NULL
    // 0x12e8a2c: r8 = Iterable<X0>?
    //     0x12e8a2c: ldr             x8, [PP, #0x75b0]  ; [pp+0x75b0] Type: Iterable<X0>?
    // 0x12e8a30: LoadField: r9 = r8->field_7
    //     0x12e8a30: ldur            x9, [x8, #7]
    // 0x12e8a34: r3 = Null
    //     0x12e8a34: add             x3, PP, #0x81, lsl #12  ; [pp+0x81098] Null
    //     0x12e8a38: ldr             x3, [x3, #0x98]
    // 0x12e8a3c: blr             x9
    // 0x12e8a40: ldur            x1, [fp, #-0x10]
    // 0x12e8a44: r0 = LoadClassIdInstr(r1)
    //     0x12e8a44: ldur            x0, [x1, #-1]
    //     0x12e8a48: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8a4c: r0 = GDT[cid_x0 + 0x12641]()
    //     0x12e8a4c: mov             x17, #0x2641
    //     0x12e8a50: movk            x17, #1, lsl #16
    //     0x12e8a54: add             lr, x0, x17
    //     0x12e8a58: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8a5c: blr             lr
    // 0x12e8a60: mov             x2, x0
    // 0x12e8a64: ldur            x0, [fp, #-8]
    // 0x12e8a68: stur            x2, [fp, #-0x20]
    // 0x12e8a6c: LoadField: r3 = r0->field_b
    //     0x12e8a6c: ldur            w3, [x0, #0xb]
    // 0x12e8a70: DecompressPointer r3
    //     0x12e8a70: add             x3, x3, HEAP, lsl #32
    // 0x12e8a74: stur            x3, [fp, #-0x10]
    // 0x12e8a78: r4 = 0
    //     0x12e8a78: mov             x4, #0
    // 0x12e8a7c: stur            x4, [fp, #-0x18]
    // 0x12e8a80: CheckStackOverflow
    //     0x12e8a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e8a84: cmp             SP, x16
    //     0x12e8a88: b.ls            #0x12e8b88
    // 0x12e8a8c: r0 = LoadClassIdInstr(r2)
    //     0x12e8a8c: ldur            x0, [x2, #-1]
    //     0x12e8a90: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8a94: mov             x1, x2
    // 0x12e8a98: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x12e8a98: mov             x17, #0x845b
    //     0x12e8a9c: movk            x17, #1, lsl #16
    //     0x12e8aa0: add             lr, x0, x17
    //     0x12e8aa4: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8aa8: blr             lr
    // 0x12e8aac: tbnz            w0, #4, #0x12e8b3c
    // 0x12e8ab0: ldur            x2, [fp, #-0x20]
    // 0x12e8ab4: ldur            x3, [fp, #-0x10]
    // 0x12e8ab8: r0 = LoadClassIdInstr(r2)
    //     0x12e8ab8: ldur            x0, [x2, #-1]
    //     0x12e8abc: ubfx            x0, x0, #0xc, #0x14
    // 0x12e8ac0: mov             x1, x2
    // 0x12e8ac4: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x12e8ac4: mov             x17, #0x7d4c
    //     0x12e8ac8: movk            x17, #1, lsl #16
    //     0x12e8acc: add             lr, x0, x17
    //     0x12e8ad0: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8ad4: blr             lr
    // 0x12e8ad8: ldur            x3, [fp, #-0x10]
    // 0x12e8adc: r1 = LoadClassIdInstr(r3)
    //     0x12e8adc: ldur            x1, [x3, #-1]
    //     0x12e8ae0: ubfx            x1, x1, #0xc, #0x14
    // 0x12e8ae4: mov             x2, x0
    // 0x12e8ae8: mov             x0, x1
    // 0x12e8aec: mov             x1, x3
    // 0x12e8af0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x12e8af0: sub             lr, x0, #1, lsl #12
    //     0x12e8af4: ldr             lr, [x21, lr, lsl #3]
    //     0x12e8af8: blr             lr
    // 0x12e8afc: ldur            x1, [fp, #-0x18]
    // 0x12e8b00: ubfx            x1, x1, #0, #0x20
    // 0x12e8b04: ubfx            x0, x0, #0, #0x20
    // 0x12e8b08: add             w2, w1, w0
    // 0x12e8b0c: and             w1, w2, #0x7fffffff
    // 0x12e8b10: lsl             w2, w1, #0xa
    // 0x12e8b14: add             w3, w1, w2
    // 0x12e8b18: and             w1, w3, #0x7fffffff
    // 0x12e8b1c: mov             x2, x1
    // 0x12e8b20: ubfx            x2, x2, #0, #0x20
    // 0x12e8b24: asr             x3, x2, #6
    // 0x12e8b28: ubfx            x1, x1, #0, #0x20
    // 0x12e8b2c: eor             x4, x1, x3
    // 0x12e8b30: ldur            x2, [fp, #-0x20]
    // 0x12e8b34: ldur            x3, [fp, #-0x10]
    // 0x12e8b38: b               #0x12e8a7c
    // 0x12e8b3c: ldur            x1, [fp, #-0x18]
    // 0x12e8b40: ubfx            x1, x1, #0, #0x20
    // 0x12e8b44: lsl             w2, w1, #3
    // 0x12e8b48: ldur            x1, [fp, #-0x18]
    // 0x12e8b4c: ubfx            x1, x1, #0, #0x20
    // 0x12e8b50: add             w3, w1, w2
    // 0x12e8b54: and             w1, w3, #0x7fffffff
    // 0x12e8b58: lsr             w2, w1, #0xb
    // 0x12e8b5c: eor             x3, x1, x2
    // 0x12e8b60: lsl             w1, w3, #0xf
    // 0x12e8b64: add             w2, w3, w1
    // 0x12e8b68: and             w1, w2, #0x7fffffff
    // 0x12e8b6c: ubfx            x1, x1, #0, #0x20
    // 0x12e8b70: mov             x0, x1
    // 0x12e8b74: LeaveFrame
    //     0x12e8b74: mov             SP, fp
    //     0x12e8b78: ldp             fp, lr, [SP], #0x10
    // 0x12e8b7c: ret
    //     0x12e8b7c: ret             
    // 0x12e8b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e8b80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e8b84: b               #0x12e8a1c
    // 0x12e8b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e8b88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e8b8c: b               #0x12e8a8c
  }
}

// class id: 3577, size: 0xc, field offset: 0x8
//   const constructor, 
class DefaultEquality<X0> extends Object
    implements Equality<X0> {

  _ equals(/* No info */) {
    // ** addr: 0x12e7338, size: 0x4c
    // 0x12e7338: EnterFrame
    //     0x12e7338: stp             fp, lr, [SP, #-0x10]!
    //     0x12e733c: mov             fp, SP
    // 0x12e7340: AllocStack(0x10)
    //     0x12e7340: sub             SP, SP, #0x10
    // 0x12e7344: CheckStackOverflow
    //     0x12e7344: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e7348: cmp             SP, x16
    //     0x12e734c: b.ls            #0x12e737c
    // 0x12e7350: r0 = 60
    //     0x12e7350: mov             x0, #0x3c
    // 0x12e7354: branchIfSmi(r2, 0x12e7360)
    //     0x12e7354: tbz             w2, #0, #0x12e7360
    // 0x12e7358: r0 = LoadClassIdInstr(r2)
    //     0x12e7358: ldur            x0, [x2, #-1]
    //     0x12e735c: ubfx            x0, x0, #0xc, #0x14
    // 0x12e7360: stp             x3, x2, [SP]
    // 0x12e7364: mov             lr, x0
    // 0x12e7368: ldr             lr, [x21, lr, lsl #3]
    // 0x12e736c: blr             lr
    // 0x12e7370: LeaveFrame
    //     0x12e7370: mov             SP, fp
    //     0x12e7374: ldp             fp, lr, [SP], #0x10
    // 0x12e7378: ret
    //     0x12e7378: ret             
    // 0x12e737c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e737c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e7380: b               #0x12e7350
  }
}

// class id: 3578, size: 0xc, field offset: 0x8
abstract class Equality<X0> extends Object {
}
