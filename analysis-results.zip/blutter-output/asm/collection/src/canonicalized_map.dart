// lib: , url: package:collection/src/canonicalized_map.dart

// class id: 1048650, size: 0x8
class :: {
}

// class id: 3579, size: 0x18, field offset: 0x8
abstract class CanonicalizedMap<X0, X1, X2> extends Object
    implements Map<X0, X1> {

  Map<Y0, Y1> cast<Y0, Y1>(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0x12543bc, size: 0x60
    // 0x12543bc: EnterFrame
    //     0x12543bc: stp             fp, lr, [SP, #-0x10]!
    //     0x12543c0: mov             fp, SP
    // 0x12543c4: AllocStack(0x10)
    //     0x12543c4: sub             SP, SP, #0x10
    // 0x12543c8: SetupParameters([dynamic _ /* r0 */])
    //     0x12543c8: ldur            w0, [x4, #0xf]
    //     0x12543cc: cbnz            w0, #0x12543d8
    //     0x12543d0: mov             x1, NULL
    //     0x12543d4: b               #0x12543e4
    //     0x12543d8: ldur            w0, [x4, #0x17]
    //     0x12543dc: add             x1, fp, w0, sxtw #2
    //     0x12543e0: ldr             x1, [x1, #0x10]
    //     0x12543e4: ldr             x0, [fp, #0x10]
    // 0x12543e8: CheckStackOverflow
    //     0x12543e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12543ec: cmp             SP, x16
    //     0x12543f0: b.ls            #0x1254414
    // 0x12543f4: LoadField: r2 = r0->field_13
    //     0x12543f4: ldur            w2, [x0, #0x13]
    // 0x12543f8: DecompressPointer r2
    //     0x12543f8: add             x2, x2, HEAP, lsl #32
    // 0x12543fc: stp             x2, x1, [SP]
    // 0x1254400: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x1254400: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x1254404: r0 = cast()
    //     0x1254404: bl              #0x12857d8  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::cast
    // 0x1254408: LeaveFrame
    //     0x1254408: mov             SP, fp
    //     0x125440c: ldp             fp, lr, [SP], #0x10
    // 0x1254410: ret
    //     0x1254410: ret             
    // 0x1254414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1254414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1254418: b               #0x12543f4
  }
  int length(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0xcce3a0, size: 0x54
    // 0xcce3a0: EnterFrame
    //     0xcce3a0: stp             fp, lr, [SP, #-0x10]!
    //     0xcce3a4: mov             fp, SP
    // 0xcce3a8: ldr             x1, [fp, #0x10]
    // 0xcce3ac: LoadField: r2 = r1->field_13
    //     0xcce3ac: ldur            w2, [x1, #0x13]
    // 0xcce3b0: DecompressPointer r2
    //     0xcce3b0: add             x2, x2, HEAP, lsl #32
    // 0xcce3b4: LoadField: r1 = r2->field_13
    //     0xcce3b4: ldur            w1, [x2, #0x13]
    // 0xcce3b8: r3 = LoadInt32Instr(r1)
    //     0xcce3b8: sbfx            x3, x1, #1, #0x1f
    // 0xcce3bc: asr             x1, x3, #1
    // 0xcce3c0: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xcce3c0: ldur            w3, [x2, #0x17]
    // 0xcce3c4: r2 = LoadInt32Instr(r3)
    //     0xcce3c4: sbfx            x2, x3, #1, #0x1f
    // 0xcce3c8: sub             x3, x1, x2
    // 0xcce3cc: lsl             x0, x3, #1
    // 0xcce3d0: LeaveFrame
    //     0xcce3d0: mov             SP, fp
    //     0xcce3d4: ldp             fp, lr, [SP], #0x10
    // 0xcce3d8: ret
    //     0xcce3d8: ret             
  }
  X2? [](CanonicalizedMap<X0, X1, X2>, Object?) {
    // ** addr: 0x8f2ef8, size: 0x4c
    // 0x8f2ef8: EnterFrame
    //     0x8f2ef8: stp             fp, lr, [SP, #-0x10]!
    //     0x8f2efc: mov             fp, SP
    // 0x8f2f00: CheckStackOverflow
    //     0x8f2f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f2f04: cmp             SP, x16
    //     0x8f2f08: b.ls            #0x8f2f24
    // 0x8f2f0c: ldr             x1, [fp, #0x18]
    // 0x8f2f10: ldr             x2, [fp, #0x10]
    // 0x8f2f14: r0 = []()
    //     0x8f2f14: bl              #0x12b6aa4  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::[]
    // 0x8f2f18: LeaveFrame
    //     0x8f2f18: mov             SP, fp
    //     0x8f2f1c: ldp             fp, lr, [SP], #0x10
    // 0x8f2f20: ret
    //     0x8f2f20: ret             
    // 0x8f2f24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f2f24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f2f28: b               #0x8f2f0c
  }
  Map<Y0, Y1> map<Y0, Y1>(CanonicalizedMap<X0, X1, X2>, (dynamic, X1, X2) => MapEntry<Y0, Y1>) {
    // ** addr: 0x8f2f2c, size: 0x98
    // 0x8f2f2c: EnterFrame
    //     0x8f2f2c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f2f30: mov             fp, SP
    // 0x8f2f34: AllocStack(0x20)
    //     0x8f2f34: sub             SP, SP, #0x20
    // 0x8f2f38: SetupParameters([dynamic _, dynamic _ /* r3 */])
    //     0x8f2f38: ldur            w0, [x4, #0xf]
    //     0x8f2f3c: cbnz            w0, #0x8f2f48
    //     0x8f2f40: mov             x4, NULL
    //     0x8f2f44: b               #0x8f2f58
    //     0x8f2f48: ldur            w0, [x4, #0x17]
    //     0x8f2f4c: add             x1, fp, w0, sxtw #2
    //     0x8f2f50: ldr             x1, [x1, #0x10]
    //     0x8f2f54: mov             x4, x1
    //     0x8f2f58: ldr             x3, [fp, #0x18]
    //     0x8f2f5c: stur            x4, [fp, #-8]
    // 0x8f2f60: CheckStackOverflow
    //     0x8f2f60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f2f64: cmp             SP, x16
    //     0x8f2f68: b.ls            #0x8f2fbc
    // 0x8f2f6c: LoadField: r2 = r3->field_7
    //     0x8f2f6c: ldur            w2, [x3, #7]
    // 0x8f2f70: DecompressPointer r2
    //     0x8f2f70: add             x2, x2, HEAP, lsl #32
    // 0x8f2f74: ldr             x0, [fp, #0x10]
    // 0x8f2f78: mov             x1, x4
    // 0x8f2f7c: r8 = (dynamic this, X1, X2) => MapEntry<Y0, Y1>
    //     0x8f2f7c: add             x8, PP, #0x80, lsl #12  ; [pp+0x80a60] FunctionType: (dynamic this, X1, X2) => MapEntry<Y0, Y1>
    //     0x8f2f80: ldr             x8, [x8, #0xa60]
    // 0x8f2f84: LoadField: r9 = r8->field_7
    //     0x8f2f84: ldur            x9, [x8, #7]
    // 0x8f2f88: r3 = Null
    //     0x8f2f88: add             x3, PP, #0x80, lsl #12  ; [pp+0x80a68] Null
    //     0x8f2f8c: ldr             x3, [x3, #0xa68]
    // 0x8f2f90: blr             x9
    // 0x8f2f94: ldur            x16, [fp, #-8]
    // 0x8f2f98: ldr             lr, [fp, #0x18]
    // 0x8f2f9c: stp             lr, x16, [SP, #8]
    // 0x8f2fa0: ldr             x16, [fp, #0x10]
    // 0x8f2fa4: str             x16, [SP]
    // 0x8f2fa8: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x8f2fa8: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0x8f2fac: r0 = map()
    //     0x8f2fac: bl              #0xcff8b0  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::map
    // 0x8f2fb0: LeaveFrame
    //     0x8f2fb0: mov             SP, fp
    //     0x8f2fb4: ldp             fp, lr, [SP], #0x10
    // 0x8f2fb8: ret
    //     0x8f2fb8: ret             
    // 0x8f2fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f2fbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f2fc0: b               #0x8f2f6c
  }
  void forEach(CanonicalizedMap<X0, X1, X2>, (dynamic, X1, X2) => void) {
    // ** addr: 0x8f2fdc, size: 0x78
    // 0x8f2fdc: EnterFrame
    //     0x8f2fdc: stp             fp, lr, [SP, #-0x10]!
    //     0x8f2fe0: mov             fp, SP
    // 0x8f2fe4: CheckStackOverflow
    //     0x8f2fe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f2fe8: cmp             SP, x16
    //     0x8f2fec: b.ls            #0x8f3034
    // 0x8f2ff0: ldr             x3, [fp, #0x18]
    // 0x8f2ff4: LoadField: r2 = r3->field_7
    //     0x8f2ff4: ldur            w2, [x3, #7]
    // 0x8f2ff8: DecompressPointer r2
    //     0x8f2ff8: add             x2, x2, HEAP, lsl #32
    // 0x8f2ffc: ldr             x0, [fp, #0x10]
    // 0x8f3000: r1 = Null
    //     0x8f3000: mov             x1, NULL
    // 0x8f3004: r8 = (dynamic this, X1, X2) => void?
    //     0x8f3004: add             x8, PP, #0x80, lsl #12  ; [pp+0x80a80] FunctionType: (dynamic this, X1, X2) => void?
    //     0x8f3008: ldr             x8, [x8, #0xa80]
    // 0x8f300c: LoadField: r9 = r8->field_7
    //     0x8f300c: ldur            x9, [x8, #7]
    // 0x8f3010: r3 = Null
    //     0x8f3010: add             x3, PP, #0x80, lsl #12  ; [pp+0x80a88] Null
    //     0x8f3014: ldr             x3, [x3, #0xa88]
    // 0x8f3018: blr             x9
    // 0x8f301c: ldr             x1, [fp, #0x18]
    // 0x8f3020: ldr             x2, [fp, #0x10]
    // 0x8f3024: r0 = forEach()
    //     0x8f3024: bl              #0x1262548  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::forEach
    // 0x8f3028: LeaveFrame
    //     0x8f3028: mov             SP, fp
    //     0x8f302c: ldp             fp, lr, [SP], #0x10
    // 0x8f3030: ret
    //     0x8f3030: ret             
    // 0x8f3034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3034: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3038: b               #0x8f2ff0
  }
  bool containsKey(CanonicalizedMap<X0, X1, X2>, Object?) {
    // ** addr: 0x8f3054, size: 0x4c
    // 0x8f3054: EnterFrame
    //     0x8f3054: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3058: mov             fp, SP
    // 0x8f305c: CheckStackOverflow
    //     0x8f305c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3060: cmp             SP, x16
    //     0x8f3064: b.ls            #0x8f3080
    // 0x8f3068: ldr             x1, [fp, #0x18]
    // 0x8f306c: ldr             x2, [fp, #0x10]
    // 0x8f3070: r0 = containsKey()
    //     0x8f3070: bl              #0x1294cd8  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::containsKey
    // 0x8f3074: LeaveFrame
    //     0x8f3074: mov             SP, fp
    //     0x8f3078: ldp             fp, lr, [SP], #0x10
    // 0x8f307c: ret
    //     0x8f307c: ret             
    // 0x8f3080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f3080: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3084: b               #0x8f3068
  }
  void []=(CanonicalizedMap<X0, X1, X2>, X1, X2) {
    // ** addr: 0x8f30a0, size: 0x54
    // 0x8f30a0: EnterFrame
    //     0x8f30a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8f30a4: mov             fp, SP
    // 0x8f30a8: CheckStackOverflow
    //     0x8f30a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f30ac: cmp             SP, x16
    //     0x8f30b0: b.ls            #0x8f30d4
    // 0x8f30b4: ldr             x1, [fp, #0x20]
    // 0x8f30b8: ldr             x2, [fp, #0x18]
    // 0x8f30bc: ldr             x3, [fp, #0x10]
    // 0x8f30c0: r0 = []=()
    //     0x8f30c0: bl              #0x12b70cc  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::[]=
    // 0x8f30c4: r0 = Null
    //     0x8f30c4: mov             x0, NULL
    // 0x8f30c8: LeaveFrame
    //     0x8f30c8: mov             SP, fp
    //     0x8f30cc: ldp             fp, lr, [SP], #0x10
    // 0x8f30d0: ret
    //     0x8f30d0: ret             
    // 0x8f30d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f30d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f30d8: b               #0x8f30b4
  }
  bool dyn:get:isEmpty(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0x8f30f4, size: 0x60
    // 0x8f30f4: EnterFrame
    //     0x8f30f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8f30f8: mov             fp, SP
    // 0x8f30fc: ldr             x1, [fp, #0x10]
    // 0x8f3100: LoadField: r2 = r1->field_13
    //     0x8f3100: ldur            w2, [x1, #0x13]
    // 0x8f3104: DecompressPointer r2
    //     0x8f3104: add             x2, x2, HEAP, lsl #32
    // 0x8f3108: LoadField: r1 = r2->field_13
    //     0x8f3108: ldur            w1, [x2, #0x13]
    // 0x8f310c: r3 = LoadInt32Instr(r1)
    //     0x8f310c: sbfx            x3, x1, #1, #0x1f
    // 0x8f3110: asr             x1, x3, #1
    // 0x8f3114: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x8f3114: ldur            w3, [x2, #0x17]
    // 0x8f3118: r2 = LoadInt32Instr(r3)
    //     0x8f3118: sbfx            x2, x3, #1, #0x1f
    // 0x8f311c: sub             x3, x1, x2
    // 0x8f3120: cbz             x3, #0x8f312c
    // 0x8f3124: r0 = false
    //     0x8f3124: add             x0, NULL, #0x30  ; false
    // 0x8f3128: b               #0x8f3130
    // 0x8f312c: r0 = true
    //     0x8f312c: add             x0, NULL, #0x20  ; true
    // 0x8f3130: LeaveFrame
    //     0x8f3130: mov             SP, fp
    //     0x8f3134: ldp             fp, lr, [SP], #0x10
    // 0x8f3138: ret
    //     0x8f3138: ret             
  }
  bool dyn:get:isNotEmpty(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0x8f3154, size: 0x48
    // 0x8f3154: EnterFrame
    //     0x8f3154: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3158: mov             fp, SP
    // 0x8f315c: CheckStackOverflow
    //     0x8f315c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f3160: cmp             SP, x16
    //     0x8f3164: b.ls            #0x8f317c
    // 0x8f3168: ldr             x1, [fp, #0x10]
    // 0x8f316c: r0 = isNotEmpty()
    //     0x8f316c: bl              #0xb92e8c  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::isNotEmpty
    // 0x8f3170: LeaveFrame
    //     0x8f3170: mov             SP, fp
    //     0x8f3174: ldp             fp, lr, [SP], #0x10
    // 0x8f3178: ret
    //     0x8f3178: ret             
    // 0x8f317c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f317c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f3180: b               #0x8f3168
  }
  _ CanonicalizedMap.from(/* No info */) {
    // ** addr: 0x8f335c, size: 0xa0
    // 0x8f335c: EnterFrame
    //     0x8f335c: stp             fp, lr, [SP, #-0x10]!
    //     0x8f3360: mov             fp, SP
    // 0x8f3364: AllocStack(0x20)
    //     0x8f3364: sub             SP, SP, #0x20
    // 0x8f3368: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8f3368: mov             x4, x1
    //     0x8f336c: mov             x0, x2
    //     0x8f3370: stur            x1, [fp, #-8]
    //     0x8f3374: stur            x2, [fp, #-0x10]
    // 0x8f3378: CheckStackOverflow
    //     0x8f3378: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8f337c: cmp             SP, x16
    //     0x8f3380: b.ls            #0x8f33f4
    // 0x8f3384: LoadField: r2 = r4->field_7
    //     0x8f3384: ldur            w2, [x4, #7]
    // 0x8f3388: DecompressPointer r2
    //     0x8f3388: add             x2, x2, HEAP, lsl #32
    // 0x8f338c: r1 = Null
    //     0x8f338c: mov             x1, NULL
    // 0x8f3390: r3 = <X0, MapEntry<X1, X2>>
    //     0x8f3390: add             x3, PP, #8, lsl #12  ; [pp+0x86f0] TypeArguments: <X0, MapEntry<X1, X2>>
    //     0x8f3394: ldr             x3, [x3, #0x6f0]
    // 0x8f3398: r30 = InstantiateTypeArgumentsStub
    //     0x8f3398: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x8f339c: LoadField: r30 = r30->field_7
    //     0x8f339c: ldur            lr, [lr, #7]
    // 0x8f33a0: blr             lr
    // 0x8f33a4: ldr             x16, [THR, #0xa8]  ; THR::empty_array
    // 0x8f33a8: stp             x16, x0, [SP]
    // 0x8f33ac: r0 = Map._fromLiteral()
    //     0x8f33ac: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x8f33b0: ldur            x1, [fp, #-8]
    // 0x8f33b4: StoreField: r1->field_13 = r0
    //     0x8f33b4: stur            w0, [x1, #0x13]
    //     0x8f33b8: ldurb           w16, [x1, #-1]
    //     0x8f33bc: ldurb           w17, [x0, #-1]
    //     0x8f33c0: and             x16, x17, x16, lsr #2
    //     0x8f33c4: tst             x16, HEAP, lsr #32
    //     0x8f33c8: b.eq            #0x8f33d0
    //     0x8f33cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8f33d0: r0 = Closure: (String) => String from Function '_canonicalizer@683165596': static.
    //     0x8f33d0: add             x0, PP, #8, lsl #12  ; [pp+0x86f8] Closure: (String) => String from Function '_canonicalizer@683165596': static. (0x7f2ada7da3fc)
    //     0x8f33d4: ldr             x0, [x0, #0x6f8]
    // 0x8f33d8: StoreField: r1->field_b = r0
    //     0x8f33d8: stur            w0, [x1, #0xb]
    // 0x8f33dc: ldur            x2, [fp, #-0x10]
    // 0x8f33e0: r0 = addAll()
    //     0x8f33e0: bl              #0xb5a4e4  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::addAll
    // 0x8f33e4: r0 = Null
    //     0x8f33e4: mov             x0, NULL
    // 0x8f33e8: LeaveFrame
    //     0x8f33e8: mov             SP, fp
    //     0x8f33ec: ldp             fp, lr, [SP], #0x10
    // 0x8f33f0: ret
    //     0x8f33f0: ret             
    // 0x8f33f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8f33f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8f33f8: b               #0x8f3384
  }
  _ clear(/* No info */) {
    // ** addr: 0xa088b4, size: 0x3c
    // 0xa088b4: EnterFrame
    //     0xa088b4: stp             fp, lr, [SP, #-0x10]!
    //     0xa088b8: mov             fp, SP
    // 0xa088bc: CheckStackOverflow
    //     0xa088bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa088c0: cmp             SP, x16
    //     0xa088c4: b.ls            #0xa088e8
    // 0xa088c8: LoadField: r0 = r1->field_13
    //     0xa088c8: ldur            w0, [x1, #0x13]
    // 0xa088cc: DecompressPointer r0
    //     0xa088cc: add             x0, x0, HEAP, lsl #32
    // 0xa088d0: mov             x1, x0
    // 0xa088d4: r0 = clear()
    //     0xa088d4: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xa088d8: r0 = Null
    //     0xa088d8: mov             x0, NULL
    // 0xa088dc: LeaveFrame
    //     0xa088dc: mov             SP, fp
    //     0xa088e0: ldp             fp, lr, [SP], #0x10
    // 0xa088e4: ret
    //     0xa088e4: ret             
    // 0xa088e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa088e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa088ec: b               #0xa088c8
  }
  _ putIfAbsent(/* No info */) {
    // ** addr: 0xa12380, size: 0x120
    // 0xa12380: EnterFrame
    //     0xa12380: stp             fp, lr, [SP, #-0x10]!
    //     0xa12384: mov             fp, SP
    // 0xa12388: AllocStack(0x30)
    //     0xa12388: sub             SP, SP, #0x30
    // 0xa1238c: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xa1238c: stur            x1, [fp, #-8]
    //     0xa12390: mov             x16, x2
    //     0xa12394: mov             x2, x1
    //     0xa12398: mov             x1, x16
    //     0xa1239c: mov             x0, x3
    //     0xa123a0: stur            x1, [fp, #-0x10]
    //     0xa123a4: stur            x3, [fp, #-0x18]
    // 0xa123a8: CheckStackOverflow
    //     0xa123a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa123ac: cmp             SP, x16
    //     0xa123b0: b.ls            #0xa12498
    // 0xa123b4: r1 = 3
    //     0xa123b4: mov             x1, #3
    // 0xa123b8: r0 = AllocateContext()
    //     0xa123b8: bl              #0x13de838  ; AllocateContextStub
    // 0xa123bc: mov             x4, x0
    // 0xa123c0: ldur            x3, [fp, #-8]
    // 0xa123c4: stur            x4, [fp, #-0x28]
    // 0xa123c8: StoreField: r4->field_f = r3
    //     0xa123c8: stur            w3, [x4, #0xf]
    // 0xa123cc: ldur            x5, [fp, #-0x10]
    // 0xa123d0: StoreField: r4->field_13 = r5
    //     0xa123d0: stur            w5, [x4, #0x13]
    // 0xa123d4: ldur            x6, [fp, #-0x18]
    // 0xa123d8: ArrayStore: r4[0] = r6  ; List_4
    //     0xa123d8: stur            w6, [x4, #0x17]
    // 0xa123dc: LoadField: r7 = r3->field_7
    //     0xa123dc: ldur            w7, [x3, #7]
    // 0xa123e0: DecompressPointer r7
    //     0xa123e0: add             x7, x7, HEAP, lsl #32
    // 0xa123e4: mov             x0, x5
    // 0xa123e8: mov             x2, x7
    // 0xa123ec: stur            x7, [fp, #-0x20]
    // 0xa123f0: r1 = Null
    //     0xa123f0: mov             x1, NULL
    // 0xa123f4: cmp             w2, NULL
    // 0xa123f8: b.eq            #0xa12418
    // 0xa123fc: LoadField: r4 = r2->field_1b
    //     0xa123fc: ldur            w4, [x2, #0x1b]
    // 0xa12400: DecompressPointer r4
    //     0xa12400: add             x4, x4, HEAP, lsl #32
    // 0xa12404: r8 = X1
    //     0xa12404: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0xa12408: LoadField: r9 = r4->field_7
    //     0xa12408: ldur            x9, [x4, #7]
    // 0xa1240c: r3 = Null
    //     0xa1240c: add             x3, PP, #0xd, lsl #12  ; [pp+0xd8d0] Null
    //     0xa12410: ldr             x3, [x3, #0x8d0]
    // 0xa12414: blr             x9
    // 0xa12418: ldur            x0, [fp, #-0x18]
    // 0xa1241c: ldur            x2, [fp, #-0x20]
    // 0xa12420: r1 = Null
    //     0xa12420: mov             x1, NULL
    // 0xa12424: r8 = (dynamic this) => X2
    //     0xa12424: add             x8, PP, #0xd, lsl #12  ; [pp+0xd8e0] FunctionType: (dynamic this) => X2
    //     0xa12428: ldr             x8, [x8, #0x8e0]
    // 0xa1242c: LoadField: r9 = r8->field_7
    //     0xa1242c: ldur            x9, [x8, #7]
    // 0xa12430: r3 = Null
    //     0xa12430: add             x3, PP, #0xd, lsl #12  ; [pp+0xd8e8] Null
    //     0xa12434: ldr             x3, [x3, #0x8e8]
    // 0xa12438: blr             x9
    // 0xa1243c: ldur            x0, [fp, #-8]
    // 0xa12440: LoadField: r1 = r0->field_13
    //     0xa12440: ldur            w1, [x0, #0x13]
    // 0xa12444: DecompressPointer r1
    //     0xa12444: add             x1, x1, HEAP, lsl #32
    // 0xa12448: stur            x1, [fp, #-0x18]
    // 0xa1244c: ldur            x16, [fp, #-0x10]
    // 0xa12450: str             x16, [SP]
    // 0xa12454: r0 = toLowerCase()
    //     0xa12454: bl              #0x13dc09c  ; [dart:core] _OneByteString::toLowerCase
    // 0xa12458: ldur            x2, [fp, #-0x28]
    // 0xa1245c: ldur            x3, [fp, #-0x20]
    // 0xa12460: r1 = Function '<anonymous closure>':.
    //     0xa12460: add             x1, PP, #0xd, lsl #12  ; [pp+0xd8f8] AnonymousClosure: (0xa124a0), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::putIfAbsent (0xa12380)
    //     0xa12464: ldr             x1, [x1, #0x8f8]
    // 0xa12468: stur            x0, [fp, #-8]
    // 0xa1246c: r0 = AllocateClosureTA()
    //     0xa1246c: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xa12470: ldur            x1, [fp, #-0x18]
    // 0xa12474: ldur            x2, [fp, #-8]
    // 0xa12478: mov             x3, x0
    // 0xa1247c: r0 = putIfAbsent()
    //     0xa1247c: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xa12480: LoadField: r1 = r0->field_f
    //     0xa12480: ldur            w1, [x0, #0xf]
    // 0xa12484: DecompressPointer r1
    //     0xa12484: add             x1, x1, HEAP, lsl #32
    // 0xa12488: mov             x0, x1
    // 0xa1248c: LeaveFrame
    //     0xa1248c: mov             SP, fp
    //     0xa12490: ldp             fp, lr, [SP], #0x10
    // 0xa12494: ret
    //     0xa12494: ret             
    // 0xa12498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa12498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1249c: b               #0xa123b4
  }
  [closure] MapEntry<X1, X2> <anonymous closure>(dynamic) {
    // ** addr: 0xa124a0, size: 0xc0
    // 0xa124a0: EnterFrame
    //     0xa124a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa124a4: mov             fp, SP
    // 0xa124a8: AllocStack(0x20)
    //     0xa124a8: sub             SP, SP, #0x20
    // 0xa124ac: SetupParameters([dynamic _ /* r0 */])
    //     0xa124ac: ldr             x0, [fp, #0x10]
    //     0xa124b0: ldur            w4, [x0, #0x17]
    //     0xa124b4: add             x4, x4, HEAP, lsl #32
    //     0xa124b8: stur            x4, [fp, #-8]
    // 0xa124bc: CheckStackOverflow
    //     0xa124bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa124c0: cmp             SP, x16
    //     0xa124c4: b.ls            #0xa12558
    // 0xa124c8: LoadField: r0 = r4->field_f
    //     0xa124c8: ldur            w0, [x4, #0xf]
    // 0xa124cc: DecompressPointer r0
    //     0xa124cc: add             x0, x0, HEAP, lsl #32
    // 0xa124d0: LoadField: r2 = r0->field_7
    //     0xa124d0: ldur            w2, [x0, #7]
    // 0xa124d4: DecompressPointer r2
    //     0xa124d4: add             x2, x2, HEAP, lsl #32
    // 0xa124d8: r1 = Null
    //     0xa124d8: mov             x1, NULL
    // 0xa124dc: r3 = <X1, X2>
    //     0xa124dc: add             x3, PP, #8, lsl #12  ; [pp+0x8760] TypeArguments: <X1, X2>
    //     0xa124e0: ldr             x3, [x3, #0x760]
    // 0xa124e4: r0 = Null
    //     0xa124e4: mov             x0, NULL
    // 0xa124e8: cmp             x2, x0
    // 0xa124ec: b.eq            #0xa124fc
    // 0xa124f0: r30 = InstantiateTypeArgumentsStub
    //     0xa124f0: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xa124f4: LoadField: r30 = r30->field_7
    //     0xa124f4: ldur            lr, [lr, #7]
    // 0xa124f8: blr             lr
    // 0xa124fc: mov             x1, x0
    // 0xa12500: ldur            x0, [fp, #-8]
    // 0xa12504: stur            x1, [fp, #-0x18]
    // 0xa12508: LoadField: r2 = r0->field_13
    //     0xa12508: ldur            w2, [x0, #0x13]
    // 0xa1250c: DecompressPointer r2
    //     0xa1250c: add             x2, x2, HEAP, lsl #32
    // 0xa12510: stur            x2, [fp, #-0x10]
    // 0xa12514: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xa12514: ldur            w3, [x0, #0x17]
    // 0xa12518: DecompressPointer r3
    //     0xa12518: add             x3, x3, HEAP, lsl #32
    // 0xa1251c: str             x3, [SP]
    // 0xa12520: mov             x0, x3
    // 0xa12524: ClosureCall
    //     0xa12524: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xa12528: ldur            x2, [x0, #0x1f]
    //     0xa1252c: blr             x2
    // 0xa12530: ldur            x1, [fp, #-0x18]
    // 0xa12534: stur            x0, [fp, #-8]
    // 0xa12538: r0 = MapEntry()
    //     0xa12538: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xa1253c: ldur            x1, [fp, #-0x10]
    // 0xa12540: StoreField: r0->field_b = r1
    //     0xa12540: stur            w1, [x0, #0xb]
    // 0xa12544: ldur            x1, [fp, #-8]
    // 0xa12548: StoreField: r0->field_f = r1
    //     0xa12548: stur            w1, [x0, #0xf]
    // 0xa1254c: LeaveFrame
    //     0xa1254c: mov             SP, fp
    //     0xa12550: ldp             fp, lr, [SP], #0x10
    // 0xa12554: ret
    //     0xa12554: ret             
    // 0xa12558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa12558: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1255c: b               #0xa124c8
  }
  _ addEntries(/* No info */) {
    // ** addr: 0xaf9484, size: 0x10c
    // 0xaf9484: EnterFrame
    //     0xaf9484: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9488: mov             fp, SP
    // 0xaf948c: AllocStack(0x40)
    //     0xaf948c: sub             SP, SP, #0x40
    // 0xaf9490: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xaf9490: mov             x0, x2
    //     0xaf9494: stur            x1, [fp, #-8]
    //     0xaf9498: stur            x2, [fp, #-0x10]
    // 0xaf949c: CheckStackOverflow
    //     0xaf949c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf94a0: cmp             SP, x16
    //     0xaf94a4: b.ls            #0xaf9588
    // 0xaf94a8: r1 = 1
    //     0xaf94a8: mov             x1, #1
    // 0xaf94ac: r0 = AllocateContext()
    //     0xaf94ac: bl              #0x13de838  ; AllocateContextStub
    // 0xaf94b0: mov             x4, x0
    // 0xaf94b4: ldur            x3, [fp, #-8]
    // 0xaf94b8: stur            x4, [fp, #-0x20]
    // 0xaf94bc: StoreField: r4->field_f = r3
    //     0xaf94bc: stur            w3, [x4, #0xf]
    // 0xaf94c0: LoadField: r5 = r3->field_7
    //     0xaf94c0: ldur            w5, [x3, #7]
    // 0xaf94c4: DecompressPointer r5
    //     0xaf94c4: add             x5, x5, HEAP, lsl #32
    // 0xaf94c8: ldur            x0, [fp, #-0x10]
    // 0xaf94cc: mov             x2, x5
    // 0xaf94d0: stur            x5, [fp, #-0x18]
    // 0xaf94d4: r1 = Null
    //     0xaf94d4: mov             x1, NULL
    // 0xaf94d8: r8 = Iterable<MapEntry<X1, X2>>
    //     0xaf94d8: add             x8, PP, #0xb0, lsl #12  ; [pp+0xb0978] Type: Iterable<MapEntry<X1, X2>>
    //     0xaf94dc: ldr             x8, [x8, #0x978]
    // 0xaf94e0: LoadField: r9 = r8->field_7
    //     0xaf94e0: ldur            x9, [x8, #7]
    // 0xaf94e4: r3 = Null
    //     0xaf94e4: add             x3, PP, #0xb0, lsl #12  ; [pp+0xb0980] Null
    //     0xaf94e8: ldr             x3, [x3, #0x980]
    // 0xaf94ec: blr             x9
    // 0xaf94f0: ldur            x0, [fp, #-8]
    // 0xaf94f4: LoadField: r4 = r0->field_13
    //     0xaf94f4: ldur            w4, [x0, #0x13]
    // 0xaf94f8: DecompressPointer r4
    //     0xaf94f8: add             x4, x4, HEAP, lsl #32
    // 0xaf94fc: ldur            x2, [fp, #-0x18]
    // 0xaf9500: stur            x4, [fp, #-0x28]
    // 0xaf9504: r1 = Null
    //     0xaf9504: mov             x1, NULL
    // 0xaf9508: r3 = <MapEntry<X0, MapEntry<X1, X2>>>
    //     0xaf9508: add             x3, PP, #0xb0, lsl #12  ; [pp+0xb0990] TypeArguments: <MapEntry<X0, MapEntry<X1, X2>>>
    //     0xaf950c: ldr             x3, [x3, #0x990]
    // 0xaf9510: r30 = InstantiateTypeArgumentsStub
    //     0xaf9510: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xaf9514: LoadField: r30 = r30->field_7
    //     0xaf9514: ldur            lr, [lr, #7]
    // 0xaf9518: blr             lr
    // 0xaf951c: ldur            x2, [fp, #-0x20]
    // 0xaf9520: ldur            x3, [fp, #-0x18]
    // 0xaf9524: r1 = Function '<anonymous closure>':.
    //     0xaf9524: add             x1, PP, #0xb0, lsl #12  ; [pp+0xb0998] AnonymousClosure: (0xaf9590), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::addEntries (0xaf9484)
    //     0xaf9528: ldr             x1, [x1, #0x998]
    // 0xaf952c: stur            x0, [fp, #-8]
    // 0xaf9530: r0 = AllocateClosureTA()
    //     0xaf9530: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xaf9534: mov             x1, x0
    // 0xaf9538: ldur            x0, [fp, #-0x10]
    // 0xaf953c: r2 = LoadClassIdInstr(r0)
    //     0xaf953c: ldur            x2, [x0, #-1]
    //     0xaf9540: ubfx            x2, x2, #0xc, #0x14
    // 0xaf9544: ldur            x16, [fp, #-8]
    // 0xaf9548: stp             x0, x16, [SP, #8]
    // 0xaf954c: str             x1, [SP]
    // 0xaf9550: mov             x0, x2
    // 0xaf9554: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xaf9554: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xaf9558: r0 = GDT[cid_x0 + 0x12caa]()
    //     0xaf9558: mov             x17, #0x2caa
    //     0xaf955c: movk            x17, #1, lsl #16
    //     0xaf9560: add             lr, x0, x17
    //     0xaf9564: ldr             lr, [x21, lr, lsl #3]
    //     0xaf9568: blr             lr
    // 0xaf956c: ldur            x1, [fp, #-0x28]
    // 0xaf9570: mov             x2, x0
    // 0xaf9574: r0 = addEntries()
    //     0xaf9574: bl              #0xb14c80  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::addEntries
    // 0xaf9578: r0 = Null
    //     0xaf9578: mov             x0, NULL
    // 0xaf957c: LeaveFrame
    //     0xaf957c: mov             SP, fp
    //     0xaf9580: ldp             fp, lr, [SP], #0x10
    // 0xaf9584: ret
    //     0xaf9584: ret             
    // 0xaf9588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9588: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf958c: b               #0xaf94a8
  }
  [closure] MapEntry<X0, MapEntry<X1, X2>> <anonymous closure>(dynamic, MapEntry<X1, X2>) {
    // ** addr: 0xaf9590, size: 0x10c
    // 0xaf9590: EnterFrame
    //     0xaf9590: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9594: mov             fp, SP
    // 0xaf9598: AllocStack(0x28)
    //     0xaf9598: sub             SP, SP, #0x28
    // 0xaf959c: SetupParameters([dynamic _ /* r0 */])
    //     0xaf959c: ldr             x0, [fp, #0x18]
    //     0xaf95a0: ldur            w4, [x0, #0x17]
    //     0xaf95a4: add             x4, x4, HEAP, lsl #32
    //     0xaf95a8: stur            x4, [fp, #-8]
    // 0xaf95ac: CheckStackOverflow
    //     0xaf95ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xaf95b0: cmp             SP, x16
    //     0xaf95b4: b.ls            #0xaf9694
    // 0xaf95b8: LoadField: r0 = r4->field_f
    //     0xaf95b8: ldur            w0, [x4, #0xf]
    // 0xaf95bc: DecompressPointer r0
    //     0xaf95bc: add             x0, x0, HEAP, lsl #32
    // 0xaf95c0: LoadField: r2 = r0->field_7
    //     0xaf95c0: ldur            w2, [x0, #7]
    // 0xaf95c4: DecompressPointer r2
    //     0xaf95c4: add             x2, x2, HEAP, lsl #32
    // 0xaf95c8: r1 = Null
    //     0xaf95c8: mov             x1, NULL
    // 0xaf95cc: r3 = <X0, MapEntry<X1, X2>>
    //     0xaf95cc: add             x3, PP, #8, lsl #12  ; [pp+0x86f0] TypeArguments: <X0, MapEntry<X1, X2>>
    //     0xaf95d0: ldr             x3, [x3, #0x6f0]
    // 0xaf95d4: r30 = InstantiateTypeArgumentsStub
    //     0xaf95d4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xaf95d8: LoadField: r30 = r30->field_7
    //     0xaf95d8: ldur            lr, [lr, #7]
    // 0xaf95dc: blr             lr
    // 0xaf95e0: mov             x2, x0
    // 0xaf95e4: ldr             x0, [fp, #0x10]
    // 0xaf95e8: stur            x2, [fp, #-0x18]
    // 0xaf95ec: LoadField: r3 = r0->field_b
    //     0xaf95ec: ldur            w3, [x0, #0xb]
    // 0xaf95f0: DecompressPointer r3
    //     0xaf95f0: add             x3, x3, HEAP, lsl #32
    // 0xaf95f4: mov             x1, x3
    // 0xaf95f8: stur            x3, [fp, #-0x10]
    // 0xaf95fc: r0 = _canonicalizer()
    //     0xaf95fc: bl              #0x8f342c  ; [package:http_parser/src/case_insensitive_map.dart] CaseInsensitiveMap::_canonicalizer
    // 0xaf9600: mov             x4, x0
    // 0xaf9604: ldur            x0, [fp, #-8]
    // 0xaf9608: stur            x4, [fp, #-0x20]
    // 0xaf960c: LoadField: r1 = r0->field_f
    //     0xaf960c: ldur            w1, [x0, #0xf]
    // 0xaf9610: DecompressPointer r1
    //     0xaf9610: add             x1, x1, HEAP, lsl #32
    // 0xaf9614: LoadField: r2 = r1->field_7
    //     0xaf9614: ldur            w2, [x1, #7]
    // 0xaf9618: DecompressPointer r2
    //     0xaf9618: add             x2, x2, HEAP, lsl #32
    // 0xaf961c: r1 = Null
    //     0xaf961c: mov             x1, NULL
    // 0xaf9620: r3 = <X1, X2>
    //     0xaf9620: add             x3, PP, #8, lsl #12  ; [pp+0x8760] TypeArguments: <X1, X2>
    //     0xaf9624: ldr             x3, [x3, #0x760]
    // 0xaf9628: r0 = Null
    //     0xaf9628: mov             x0, NULL
    // 0xaf962c: cmp             x2, x0
    // 0xaf9630: b.eq            #0xaf9640
    // 0xaf9634: r30 = InstantiateTypeArgumentsStub
    //     0xaf9634: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xaf9638: LoadField: r30 = r30->field_7
    //     0xaf9638: ldur            lr, [lr, #7]
    // 0xaf963c: blr             lr
    // 0xaf9640: mov             x1, x0
    // 0xaf9644: ldr             x0, [fp, #0x10]
    // 0xaf9648: LoadField: r2 = r0->field_f
    //     0xaf9648: ldur            w2, [x0, #0xf]
    // 0xaf964c: DecompressPointer r2
    //     0xaf964c: add             x2, x2, HEAP, lsl #32
    // 0xaf9650: stur            x2, [fp, #-8]
    // 0xaf9654: r0 = MapEntry()
    //     0xaf9654: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xaf9658: mov             x2, x0
    // 0xaf965c: ldur            x0, [fp, #-0x10]
    // 0xaf9660: stur            x2, [fp, #-0x28]
    // 0xaf9664: StoreField: r2->field_b = r0
    //     0xaf9664: stur            w0, [x2, #0xb]
    // 0xaf9668: ldur            x0, [fp, #-8]
    // 0xaf966c: StoreField: r2->field_f = r0
    //     0xaf966c: stur            w0, [x2, #0xf]
    // 0xaf9670: ldur            x1, [fp, #-0x18]
    // 0xaf9674: r0 = MapEntry()
    //     0xaf9674: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xaf9678: ldur            x1, [fp, #-0x20]
    // 0xaf967c: StoreField: r0->field_b = r1
    //     0xaf967c: stur            w1, [x0, #0xb]
    // 0xaf9680: ldur            x1, [fp, #-0x28]
    // 0xaf9684: StoreField: r0->field_f = r1
    //     0xaf9684: stur            w1, [x0, #0xf]
    // 0xaf9688: LeaveFrame
    //     0xaf9688: mov             SP, fp
    //     0xaf968c: ldp             fp, lr, [SP], #0x10
    // 0xaf9690: ret
    //     0xaf9690: ret             
    // 0xaf9694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9694: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9698: b               #0xaf95b8
  }
  X2? remove(CanonicalizedMap<X0, X1, X2>, Object?) {
    // ** addr: 0xb57fb8, size: 0x178
    // 0xb57fb8: EnterFrame
    //     0xb57fb8: stp             fp, lr, [SP, #-0x10]!
    //     0xb57fbc: mov             fp, SP
    // 0xb57fc0: AllocStack(0x20)
    //     0xb57fc0: sub             SP, SP, #0x20
    // 0xb57fc4: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xb57fc4: mov             x4, x1
    //     0xb57fc8: mov             x3, x2
    //     0xb57fcc: stur            x1, [fp, #-0x10]
    //     0xb57fd0: stur            x2, [fp, #-0x18]
    // 0xb57fd4: CheckStackOverflow
    //     0xb57fd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb57fd8: cmp             SP, x16
    //     0xb57fdc: b.ls            #0xb58128
    // 0xb57fe0: LoadField: r5 = r4->field_7
    //     0xb57fe0: ldur            w5, [x4, #7]
    // 0xb57fe4: DecompressPointer r5
    //     0xb57fe4: add             x5, x5, HEAP, lsl #32
    // 0xb57fe8: mov             x0, x3
    // 0xb57fec: mov             x2, x5
    // 0xb57ff0: stur            x5, [fp, #-8]
    // 0xb57ff4: r1 = Null
    //     0xb57ff4: mov             x1, NULL
    // 0xb57ff8: cmp             w2, NULL
    // 0xb57ffc: b.eq            #0xb58094
    // 0xb58000: LoadField: r3 = r2->field_1b
    //     0xb58000: ldur            w3, [x2, #0x1b]
    // 0xb58004: DecompressPointer r3
    //     0xb58004: add             x3, x3, HEAP, lsl #32
    // 0xb58008: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0xb5800c: cmp             w3, w16
    // 0xb58010: b.eq            #0xb58094
    // 0xb58014: r16 = Object?
    //     0xb58014: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0xb58018: cmp             w3, w16
    // 0xb5801c: b.eq            #0xb58094
    // 0xb58020: r16 = void?
    //     0xb58020: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0xb58024: cmp             w3, w16
    // 0xb58028: b.eq            #0xb58094
    // 0xb5802c: tbnz            w0, #0, #0xb58048
    // 0xb58030: r16 = int
    //     0xb58030: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0xb58034: cmp             w3, w16
    // 0xb58038: b.eq            #0xb58094
    // 0xb5803c: r16 = num
    //     0xb5803c: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0xb58040: cmp             w3, w16
    // 0xb58044: b.eq            #0xb58094
    // 0xb58048: r3 = SubtypeTestCache
    //     0xb58048: add             x3, PP, #0xd, lsl #12  ; [pp+0xd8a8] SubtypeTestCache
    //     0xb5804c: ldr             x3, [x3, #0x8a8]
    // 0xb58050: r30 = Subtype6TestCacheStub
    //     0xb58050: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0xb58054: LoadField: r30 = r30->field_7
    //     0xb58054: ldur            lr, [lr, #7]
    // 0xb58058: blr             lr
    // 0xb5805c: cmp             w7, NULL
    // 0xb58060: b.eq            #0xb5806c
    // 0xb58064: tbnz            w7, #4, #0xb5808c
    // 0xb58068: b               #0xb58094
    // 0xb5806c: r8 = X1
    //     0xb5806c: add             x8, PP, #0xd, lsl #12  ; [pp+0xd8b0] TypeParameter: X1
    //     0xb58070: ldr             x8, [x8, #0x8b0]
    // 0xb58074: r3 = SubtypeTestCache
    //     0xb58074: add             x3, PP, #0xd, lsl #12  ; [pp+0xd8b8] SubtypeTestCache
    //     0xb58078: ldr             x3, [x3, #0x8b8]
    // 0xb5807c: r30 = InstanceOfStub
    //     0xb5807c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xb58080: LoadField: r30 = r30->field_7
    //     0xb58080: ldur            lr, [lr, #7]
    // 0xb58084: blr             lr
    // 0xb58088: b               #0xb58098
    // 0xb5808c: r0 = false
    //     0xb5808c: add             x0, NULL, #0x30  ; false
    // 0xb58090: b               #0xb58098
    // 0xb58094: r0 = true
    //     0xb58094: add             x0, NULL, #0x20  ; true
    // 0xb58098: tbnz            w0, #4, #0xb58118
    // 0xb5809c: ldur            x0, [fp, #-0x10]
    // 0xb580a0: LoadField: r3 = r0->field_13
    //     0xb580a0: ldur            w3, [x0, #0x13]
    // 0xb580a4: DecompressPointer r3
    //     0xb580a4: add             x3, x3, HEAP, lsl #32
    // 0xb580a8: ldur            x0, [fp, #-0x18]
    // 0xb580ac: ldur            x2, [fp, #-8]
    // 0xb580b0: stur            x3, [fp, #-0x20]
    // 0xb580b4: r1 = Null
    //     0xb580b4: mov             x1, NULL
    // 0xb580b8: cmp             w2, NULL
    // 0xb580bc: b.eq            #0xb580dc
    // 0xb580c0: LoadField: r4 = r2->field_1b
    //     0xb580c0: ldur            w4, [x2, #0x1b]
    // 0xb580c4: DecompressPointer r4
    //     0xb580c4: add             x4, x4, HEAP, lsl #32
    // 0xb580c8: r8 = X1
    //     0xb580c8: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0xb580cc: LoadField: r9 = r4->field_7
    //     0xb580cc: ldur            x9, [x4, #7]
    // 0xb580d0: r3 = Null
    //     0xb580d0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd8c0] Null
    //     0xb580d4: ldr             x3, [x3, #0x8c0]
    // 0xb580d8: blr             x9
    // 0xb580dc: ldur            x1, [fp, #-0x18]
    // 0xb580e0: r0 = _canonicalizer()
    //     0xb580e0: bl              #0x8f342c  ; [package:http_parser/src/case_insensitive_map.dart] CaseInsensitiveMap::_canonicalizer
    // 0xb580e4: ldur            x1, [fp, #-0x20]
    // 0xb580e8: mov             x2, x0
    // 0xb580ec: r0 = remove()
    //     0xb580ec: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xb580f0: cmp             w0, NULL
    // 0xb580f4: b.ne            #0xb58100
    // 0xb580f8: r0 = Null
    //     0xb580f8: mov             x0, NULL
    // 0xb580fc: b               #0xb5810c
    // 0xb58100: LoadField: r1 = r0->field_f
    //     0xb58100: ldur            w1, [x0, #0xf]
    // 0xb58104: DecompressPointer r1
    //     0xb58104: add             x1, x1, HEAP, lsl #32
    // 0xb58108: mov             x0, x1
    // 0xb5810c: LeaveFrame
    //     0xb5810c: mov             SP, fp
    //     0xb58110: ldp             fp, lr, [SP], #0x10
    // 0xb58114: ret
    //     0xb58114: ret             
    // 0xb58118: r0 = Null
    //     0xb58118: mov             x0, NULL
    // 0xb5811c: LeaveFrame
    //     0xb5811c: mov             SP, fp
    //     0xb58120: ldp             fp, lr, [SP], #0x10
    // 0xb58124: ret
    //     0xb58124: ret             
    // 0xb58128: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb58128: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5812c: b               #0xb57fe0
  }
  _ addAll(/* No info */) {
    // ** addr: 0xb5a4e4, size: 0xbc
    // 0xb5a4e4: EnterFrame
    //     0xb5a4e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5a4e8: mov             fp, SP
    // 0xb5a4ec: AllocStack(0x20)
    //     0xb5a4ec: sub             SP, SP, #0x20
    // 0xb5a4f0: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb5a4f0: mov             x0, x2
    //     0xb5a4f4: stur            x1, [fp, #-8]
    //     0xb5a4f8: stur            x2, [fp, #-0x10]
    // 0xb5a4fc: CheckStackOverflow
    //     0xb5a4fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5a500: cmp             SP, x16
    //     0xb5a504: b.ls            #0xb5a598
    // 0xb5a508: r1 = 1
    //     0xb5a508: mov             x1, #1
    // 0xb5a50c: r0 = AllocateContext()
    //     0xb5a50c: bl              #0x13de838  ; AllocateContextStub
    // 0xb5a510: mov             x3, x0
    // 0xb5a514: ldur            x0, [fp, #-8]
    // 0xb5a518: stur            x3, [fp, #-0x20]
    // 0xb5a51c: StoreField: r3->field_f = r0
    //     0xb5a51c: stur            w0, [x3, #0xf]
    // 0xb5a520: LoadField: r4 = r0->field_7
    //     0xb5a520: ldur            w4, [x0, #7]
    // 0xb5a524: DecompressPointer r4
    //     0xb5a524: add             x4, x4, HEAP, lsl #32
    // 0xb5a528: ldur            x0, [fp, #-0x10]
    // 0xb5a52c: mov             x2, x4
    // 0xb5a530: stur            x4, [fp, #-0x18]
    // 0xb5a534: r1 = Null
    //     0xb5a534: mov             x1, NULL
    // 0xb5a538: r8 = Map<X1, X2>
    //     0xb5a538: add             x8, PP, #8, lsl #12  ; [pp+0x8700] Type: Map<X1, X2>
    //     0xb5a53c: ldr             x8, [x8, #0x700]
    // 0xb5a540: LoadField: r9 = r8->field_7
    //     0xb5a540: ldur            x9, [x8, #7]
    // 0xb5a544: r3 = Null
    //     0xb5a544: add             x3, PP, #8, lsl #12  ; [pp+0x8708] Null
    //     0xb5a548: ldr             x3, [x3, #0x708]
    // 0xb5a54c: blr             x9
    // 0xb5a550: ldur            x2, [fp, #-0x20]
    // 0xb5a554: ldur            x3, [fp, #-0x18]
    // 0xb5a558: r1 = Function '<anonymous closure>':.
    //     0xb5a558: add             x1, PP, #8, lsl #12  ; [pp+0x8718] AnonymousClosure: (0xb5a5a0), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::addAll (0xb5a4e4)
    //     0xb5a55c: ldr             x1, [x1, #0x718]
    // 0xb5a560: r0 = AllocateClosureTA()
    //     0xb5a560: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xb5a564: ldur            x1, [fp, #-0x10]
    // 0xb5a568: r2 = LoadClassIdInstr(r1)
    //     0xb5a568: ldur            x2, [x1, #-1]
    //     0xb5a56c: ubfx            x2, x2, #0xc, #0x14
    // 0xb5a570: mov             x16, x0
    // 0xb5a574: mov             x0, x2
    // 0xb5a578: mov             x2, x16
    // 0xb5a57c: r0 = GDT[cid_x0 + 0x6c5]()
    //     0xb5a57c: add             lr, x0, #0x6c5
    //     0xb5a580: ldr             lr, [x21, lr, lsl #3]
    //     0xb5a584: blr             lr
    // 0xb5a588: r0 = Null
    //     0xb5a588: mov             x0, NULL
    // 0xb5a58c: LeaveFrame
    //     0xb5a58c: mov             SP, fp
    //     0xb5a590: ldp             fp, lr, [SP], #0x10
    // 0xb5a594: ret
    //     0xb5a594: ret             
    // 0xb5a598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5a598: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5a59c: b               #0xb5a508
  }
  [closure] void <anonymous closure>(dynamic, X1, X2) {
    // ** addr: 0xb5a5a0, size: 0x50
    // 0xb5a5a0: EnterFrame
    //     0xb5a5a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb5a5a4: mov             fp, SP
    // 0xb5a5a8: ldr             x0, [fp, #0x20]
    // 0xb5a5ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb5a5ac: ldur            w1, [x0, #0x17]
    // 0xb5a5b0: DecompressPointer r1
    //     0xb5a5b0: add             x1, x1, HEAP, lsl #32
    // 0xb5a5b4: CheckStackOverflow
    //     0xb5a5b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5a5b8: cmp             SP, x16
    //     0xb5a5bc: b.ls            #0xb5a5e8
    // 0xb5a5c0: LoadField: r0 = r1->field_f
    //     0xb5a5c0: ldur            w0, [x1, #0xf]
    // 0xb5a5c4: DecompressPointer r0
    //     0xb5a5c4: add             x0, x0, HEAP, lsl #32
    // 0xb5a5c8: mov             x1, x0
    // 0xb5a5cc: ldr             x2, [fp, #0x18]
    // 0xb5a5d0: ldr             x3, [fp, #0x10]
    // 0xb5a5d4: r0 = []=()
    //     0xb5a5d4: bl              #0x12b70cc  ; [package:collection/src/canonicalized_map.dart] CanonicalizedMap::[]=
    // 0xb5a5d8: ldr             x0, [fp, #0x10]
    // 0xb5a5dc: LeaveFrame
    //     0xb5a5dc: mov             SP, fp
    //     0xb5a5e0: ldp             fp, lr, [SP], #0x10
    // 0xb5a5e4: ret
    //     0xb5a5e4: ret             
    // 0xb5a5e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5a5e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5a5ec: b               #0xb5a5c0
  }
  bool isNotEmpty(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0xb92e8c, size: 0x44
    // 0xb92e8c: EnterFrame
    //     0xb92e8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb92e90: mov             fp, SP
    // 0xb92e94: LoadField: r2 = r1->field_13
    //     0xb92e94: ldur            w2, [x1, #0x13]
    // 0xb92e98: DecompressPointer r2
    //     0xb92e98: add             x2, x2, HEAP, lsl #32
    // 0xb92e9c: LoadField: r1 = r2->field_13
    //     0xb92e9c: ldur            w1, [x2, #0x13]
    // 0xb92ea0: r3 = LoadInt32Instr(r1)
    //     0xb92ea0: sbfx            x3, x1, #1, #0x1f
    // 0xb92ea4: asr             x1, x3, #1
    // 0xb92ea8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xb92ea8: ldur            w3, [x2, #0x17]
    // 0xb92eac: r2 = LoadInt32Instr(r3)
    //     0xb92eac: sbfx            x2, x3, #1, #0x1f
    // 0xb92eb0: sub             x3, x1, x2
    // 0xb92eb4: cbnz            x3, #0xb92ec0
    // 0xb92eb8: r0 = false
    //     0xb92eb8: add             x0, NULL, #0x30  ; false
    // 0xb92ebc: b               #0xb92ec4
    // 0xb92ec0: r0 = true
    //     0xb92ec0: add             x0, NULL, #0x20  ; true
    // 0xb92ec4: LeaveFrame
    //     0xb92ec4: mov             SP, fp
    //     0xb92ec8: ldp             fp, lr, [SP], #0x10
    // 0xb92ecc: ret
    //     0xb92ecc: ret             
  }
  get _ values(/* No info */) {
    // ** addr: 0xbeb7b0, size: 0xdc
    // 0xbeb7b0: EnterFrame
    //     0xbeb7b0: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb7b4: mov             fp, SP
    // 0xbeb7b8: AllocStack(0x40)
    //     0xbeb7b8: sub             SP, SP, #0x40
    // 0xbeb7bc: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r1, fp-0x8 */)
    //     0xbeb7bc: stur            x1, [fp, #-8]
    // 0xbeb7c0: CheckStackOverflow
    //     0xbeb7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeb7c4: cmp             SP, x16
    //     0xbeb7c8: b.ls            #0xbeb884
    // 0xbeb7cc: r1 = 1
    //     0xbeb7cc: mov             x1, #1
    // 0xbeb7d0: r0 = AllocateContext()
    //     0xbeb7d0: bl              #0x13de838  ; AllocateContextStub
    // 0xbeb7d4: mov             x4, x0
    // 0xbeb7d8: ldur            x0, [fp, #-8]
    // 0xbeb7dc: stur            x4, [fp, #-0x18]
    // 0xbeb7e0: StoreField: r4->field_f = r0
    //     0xbeb7e0: stur            w0, [x4, #0xf]
    // 0xbeb7e4: LoadField: r5 = r0->field_7
    //     0xbeb7e4: ldur            w5, [x0, #7]
    // 0xbeb7e8: DecompressPointer r5
    //     0xbeb7e8: add             x5, x5, HEAP, lsl #32
    // 0xbeb7ec: mov             x2, x5
    // 0xbeb7f0: stur            x5, [fp, #-0x10]
    // 0xbeb7f4: r1 = Null
    //     0xbeb7f4: mov             x1, NULL
    // 0xbeb7f8: r3 = <X2>
    //     0xbeb7f8: add             x3, PP, #0x80, lsl #12  ; [pp+0x80a48] TypeArguments: <X2>
    //     0xbeb7fc: ldr             x3, [x3, #0xa48]
    // 0xbeb800: r0 = Null
    //     0xbeb800: mov             x0, NULL
    // 0xbeb804: cmp             x2, x0
    // 0xbeb808: b.eq            #0xbeb818
    // 0xbeb80c: r30 = InstantiateTypeArgumentsStub
    //     0xbeb80c: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xbeb810: LoadField: r30 = r30->field_7
    //     0xbeb810: ldur            lr, [lr, #7]
    // 0xbeb814: blr             lr
    // 0xbeb818: mov             x2, x0
    // 0xbeb81c: ldur            x0, [fp, #-8]
    // 0xbeb820: stur            x2, [fp, #-0x28]
    // 0xbeb824: LoadField: r3 = r0->field_13
    //     0xbeb824: ldur            w3, [x0, #0x13]
    // 0xbeb828: DecompressPointer r3
    //     0xbeb828: add             x3, x3, HEAP, lsl #32
    // 0xbeb82c: stur            x3, [fp, #-0x20]
    // 0xbeb830: r1 = <MapEntry<String, String>>
    //     0xbeb830: add             x1, PP, #0xd, lsl #12  ; [pp+0xd900] TypeArguments: <MapEntry<String, String>>
    //     0xbeb834: ldr             x1, [x1, #0x900]
    // 0xbeb838: r0 = _CompactValuesIterable()
    //     0xbeb838: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xbeb83c: mov             x4, x0
    // 0xbeb840: ldur            x0, [fp, #-0x20]
    // 0xbeb844: stur            x4, [fp, #-8]
    // 0xbeb848: StoreField: r4->field_b = r0
    //     0xbeb848: stur            w0, [x4, #0xb]
    // 0xbeb84c: ldur            x2, [fp, #-0x18]
    // 0xbeb850: ldur            x3, [fp, #-0x10]
    // 0xbeb854: r1 = Function '<anonymous closure>':.
    //     0xbeb854: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a50] Function: [package:flutter/src/widgets/icon_data.dart] IconData::fontFamily (0x12dc910)
    //     0xbeb858: ldr             x1, [x1, #0xa50]
    // 0xbeb85c: r0 = AllocateClosureTA()
    //     0xbeb85c: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xbeb860: ldur            x16, [fp, #-0x28]
    // 0xbeb864: ldur            lr, [fp, #-8]
    // 0xbeb868: stp             lr, x16, [SP, #8]
    // 0xbeb86c: str             x0, [SP]
    // 0xbeb870: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbeb870: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbeb874: r0 = map()
    //     0xbeb874: bl              #0xb007e4  ; [dart:core] Iterable::map
    // 0xbeb878: LeaveFrame
    //     0xbeb878: mov             SP, fp
    //     0xbeb87c: ldp             fp, lr, [SP], #0x10
    // 0xbeb880: ret
    //     0xbeb880: ret             
    // 0xbeb884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb888: b               #0xbeb7cc
  }
  _ removeWhere(/* No info */) {
    // ** addr: 0xbec774, size: 0x84
    // 0xbec774: EnterFrame
    //     0xbec774: stp             fp, lr, [SP, #-0x10]!
    //     0xbec778: mov             fp, SP
    // 0xbec77c: AllocStack(0x10)
    //     0xbec77c: sub             SP, SP, #0x10
    // 0xbec780: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbec780: stur            x1, [fp, #-8]
    //     0xbec784: stur            x2, [fp, #-0x10]
    // 0xbec788: CheckStackOverflow
    //     0xbec788: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec78c: cmp             SP, x16
    //     0xbec790: b.ls            #0xbec7f0
    // 0xbec794: r1 = 2
    //     0xbec794: mov             x1, #2
    // 0xbec798: r0 = AllocateContext()
    //     0xbec798: bl              #0x13de838  ; AllocateContextStub
    // 0xbec79c: mov             x1, x0
    // 0xbec7a0: ldur            x0, [fp, #-8]
    // 0xbec7a4: StoreField: r1->field_f = r0
    //     0xbec7a4: stur            w0, [x1, #0xf]
    // 0xbec7a8: ldur            x2, [fp, #-0x10]
    // 0xbec7ac: StoreField: r1->field_13 = r2
    //     0xbec7ac: stur            w2, [x1, #0x13]
    // 0xbec7b0: LoadField: r4 = r0->field_13
    //     0xbec7b0: ldur            w4, [x0, #0x13]
    // 0xbec7b4: DecompressPointer r4
    //     0xbec7b4: add             x4, x4, HEAP, lsl #32
    // 0xbec7b8: stur            x4, [fp, #-0x10]
    // 0xbec7bc: LoadField: r3 = r0->field_7
    //     0xbec7bc: ldur            w3, [x0, #7]
    // 0xbec7c0: DecompressPointer r3
    //     0xbec7c0: add             x3, x3, HEAP, lsl #32
    // 0xbec7c4: mov             x2, x1
    // 0xbec7c8: r1 = Function '<anonymous closure>':.
    //     0xbec7c8: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a58] AnonymousClosure: (0xbec7f8), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::forEach (0x1262548)
    //     0xbec7cc: ldr             x1, [x1, #0xa58]
    // 0xbec7d0: r0 = AllocateClosureTA()
    //     0xbec7d0: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xbec7d4: ldur            x1, [fp, #-0x10]
    // 0xbec7d8: mov             x2, x0
    // 0xbec7dc: r0 = removeWhere()
    //     0xbec7dc: bl              #0xbf25dc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::removeWhere
    // 0xbec7e0: r0 = Null
    //     0xbec7e0: mov             x0, NULL
    // 0xbec7e4: LeaveFrame
    //     0xbec7e4: mov             SP, fp
    //     0xbec7e8: ldp             fp, lr, [SP], #0x10
    // 0xbec7ec: ret
    //     0xbec7ec: ret             
    // 0xbec7f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec7f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec7f4: b               #0xbec794
  }
  [closure] void <anonymous closure>(dynamic, X0, MapEntry<X1, X2>) {
    // ** addr: 0xbec7f8, size: 0x68
    // 0xbec7f8: EnterFrame
    //     0xbec7f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbec7fc: mov             fp, SP
    // 0xbec800: AllocStack(0x18)
    //     0xbec800: sub             SP, SP, #0x18
    // 0xbec804: SetupParameters([dynamic _ /* r0 */])
    //     0xbec804: ldr             x0, [fp, #0x20]
    //     0xbec808: ldur            w1, [x0, #0x17]
    //     0xbec80c: add             x1, x1, HEAP, lsl #32
    // 0xbec810: CheckStackOverflow
    //     0xbec810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec814: cmp             SP, x16
    //     0xbec818: b.ls            #0xbec858
    // 0xbec81c: LoadField: r0 = r1->field_13
    //     0xbec81c: ldur            w0, [x1, #0x13]
    // 0xbec820: DecompressPointer r0
    //     0xbec820: add             x0, x0, HEAP, lsl #32
    // 0xbec824: ldr             x1, [fp, #0x10]
    // 0xbec828: LoadField: r2 = r1->field_b
    //     0xbec828: ldur            w2, [x1, #0xb]
    // 0xbec82c: DecompressPointer r2
    //     0xbec82c: add             x2, x2, HEAP, lsl #32
    // 0xbec830: LoadField: r3 = r1->field_f
    //     0xbec830: ldur            w3, [x1, #0xf]
    // 0xbec834: DecompressPointer r3
    //     0xbec834: add             x3, x3, HEAP, lsl #32
    // 0xbec838: stp             x2, x0, [SP, #8]
    // 0xbec83c: str             x3, [SP]
    // 0xbec840: ClosureCall
    //     0xbec840: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xbec844: ldur            x2, [x0, #0x1f]
    //     0xbec848: blr             x2
    // 0xbec84c: LeaveFrame
    //     0xbec84c: mov             SP, fp
    //     0xbec850: ldp             fp, lr, [SP], #0x10
    // 0xbec854: ret
    //     0xbec854: ret             
    // 0xbec858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec858: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec85c: b               #0xbec81c
  }
  Map<Y0, Y1> map<Y0, Y1>(CanonicalizedMap<X0, X1, X2>, (dynamic, X1, X2) => MapEntry<Y0, Y1>) {
    // ** addr: 0xcff8b0, size: 0xb8
    // 0xcff8b0: EnterFrame
    //     0xcff8b0: stp             fp, lr, [SP, #-0x10]!
    //     0xcff8b4: mov             fp, SP
    // 0xcff8b8: AllocStack(0x28)
    //     0xcff8b8: sub             SP, SP, #0x28
    // 0xcff8bc: SetupParameters([dynamic _ /* r0 */, dynamic _ /* r1 */])
    //     0xcff8bc: ldur            w0, [x4, #0xf]
    //     0xcff8c0: cbnz            w0, #0xcff8cc
    //     0xcff8c4: mov             x2, NULL
    //     0xcff8c8: b               #0xcff8dc
    //     0xcff8cc: ldur            w0, [x4, #0x17]
    //     0xcff8d0: add             x1, fp, w0, sxtw #2
    //     0xcff8d4: ldr             x1, [x1, #0x10]
    //     0xcff8d8: mov             x2, x1
    //     0xcff8dc: ldr             x1, [fp, #0x18]
    //     0xcff8e0: ldr             x0, [fp, #0x10]
    //     0xcff8e4: stur            x2, [fp, #-8]
    // 0xcff8e8: CheckStackOverflow
    //     0xcff8e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff8ec: cmp             SP, x16
    //     0xcff8f0: b.ls            #0xcff960
    // 0xcff8f4: r1 = 2
    //     0xcff8f4: mov             x1, #2
    // 0xcff8f8: r0 = AllocateContext()
    //     0xcff8f8: bl              #0x13de838  ; AllocateContextStub
    // 0xcff8fc: mov             x1, x0
    // 0xcff900: ldr             x0, [fp, #0x18]
    // 0xcff904: StoreField: r1->field_f = r0
    //     0xcff904: stur            w0, [x1, #0xf]
    // 0xcff908: ldr             x2, [fp, #0x10]
    // 0xcff90c: StoreField: r1->field_13 = r2
    //     0xcff90c: stur            w2, [x1, #0x13]
    // 0xcff910: LoadField: r4 = r0->field_13
    //     0xcff910: ldur            w4, [x0, #0x13]
    // 0xcff914: DecompressPointer r4
    //     0xcff914: add             x4, x4, HEAP, lsl #32
    // 0xcff918: stur            x4, [fp, #-0x10]
    // 0xcff91c: LoadField: r3 = r0->field_7
    //     0xcff91c: ldur            w3, [x0, #7]
    // 0xcff920: DecompressPointer r3
    //     0xcff920: add             x3, x3, HEAP, lsl #32
    // 0xcff924: mov             x2, x1
    // 0xcff928: r1 = Function '<anonymous closure>':.
    //     0xcff928: add             x1, PP, #0x80, lsl #12  ; [pp+0x80a78] AnonymousClosure: (0xbec7f8), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::forEach (0x1262548)
    //     0xcff92c: ldr             x1, [x1, #0xa78]
    // 0xcff930: r0 = AllocateClosureTA()
    //     0xcff930: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0xcff934: mov             x1, x0
    // 0xcff938: ldur            x0, [fp, #-8]
    // 0xcff93c: StoreField: r1->field_b = r0
    //     0xcff93c: stur            w0, [x1, #0xb]
    // 0xcff940: ldur            x16, [fp, #-0x10]
    // 0xcff944: stp             x16, x0, [SP, #8]
    // 0xcff948: str             x1, [SP]
    // 0xcff94c: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0xcff94c: ldr             x4, [PP, #0x808]  ; [pp+0x808] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    // 0xcff950: r0 = map()
    //     0xcff950: bl              #0xf78e7c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin::map
    // 0xcff954: LeaveFrame
    //     0xcff954: mov             SP, fp
    //     0xcff958: ldp             fp, lr, [SP], #0x10
    // 0xcff95c: ret
    //     0xcff95c: ret             
    // 0xcff960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcff960: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcff964: b               #0xcff8f4
  }
  get _ entries(/* No info */) {
    // ** addr: 0x1253c58, size: 0xd0
    // 0x1253c58: EnterFrame
    //     0x1253c58: stp             fp, lr, [SP, #-0x10]!
    //     0x1253c5c: mov             fp, SP
    // 0x1253c60: AllocStack(0x40)
    //     0x1253c60: sub             SP, SP, #0x40
    // 0x1253c64: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r1, fp-0x8 */)
    //     0x1253c64: stur            x1, [fp, #-8]
    // 0x1253c68: CheckStackOverflow
    //     0x1253c68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1253c6c: cmp             SP, x16
    //     0x1253c70: b.ls            #0x1253d20
    // 0x1253c74: r1 = 1
    //     0x1253c74: mov             x1, #1
    // 0x1253c78: r0 = AllocateContext()
    //     0x1253c78: bl              #0x13de838  ; AllocateContextStub
    // 0x1253c7c: mov             x4, x0
    // 0x1253c80: ldur            x0, [fp, #-8]
    // 0x1253c84: stur            x4, [fp, #-0x18]
    // 0x1253c88: StoreField: r4->field_f = r0
    //     0x1253c88: stur            w0, [x4, #0xf]
    // 0x1253c8c: LoadField: r5 = r0->field_7
    //     0x1253c8c: ldur            w5, [x0, #7]
    // 0x1253c90: DecompressPointer r5
    //     0x1253c90: add             x5, x5, HEAP, lsl #32
    // 0x1253c94: mov             x2, x5
    // 0x1253c98: stur            x5, [fp, #-0x10]
    // 0x1253c9c: r1 = Null
    //     0x1253c9c: mov             x1, NULL
    // 0x1253ca0: r3 = <MapEntry<X1, X2>>
    //     0x1253ca0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd918] TypeArguments: <MapEntry<X1, X2>>
    //     0x1253ca4: ldr             x3, [x3, #0x918]
    // 0x1253ca8: r30 = InstantiateTypeArgumentsStub
    //     0x1253ca8: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x1253cac: LoadField: r30 = r30->field_7
    //     0x1253cac: ldur            lr, [lr, #7]
    // 0x1253cb0: blr             lr
    // 0x1253cb4: mov             x2, x0
    // 0x1253cb8: ldur            x0, [fp, #-8]
    // 0x1253cbc: stur            x2, [fp, #-0x28]
    // 0x1253cc0: LoadField: r3 = r0->field_13
    //     0x1253cc0: ldur            w3, [x0, #0x13]
    // 0x1253cc4: DecompressPointer r3
    //     0x1253cc4: add             x3, x3, HEAP, lsl #32
    // 0x1253cc8: stur            x3, [fp, #-0x20]
    // 0x1253ccc: r1 = <MapEntry<String, MapEntry<String, String>>, String, MapEntry<String, String>>
    //     0x1253ccc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd920] TypeArguments: <MapEntry<String, MapEntry<String, String>>, String, MapEntry<String, String>>
    //     0x1253cd0: ldr             x1, [x1, #0x920]
    // 0x1253cd4: r0 = _CompactEntriesIterable()
    //     0x1253cd4: bl              #0x893cd0  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x1253cd8: mov             x4, x0
    // 0x1253cdc: ldur            x0, [fp, #-0x20]
    // 0x1253ce0: stur            x4, [fp, #-8]
    // 0x1253ce4: StoreField: r4->field_b = r0
    //     0x1253ce4: stur            w0, [x4, #0xb]
    // 0x1253ce8: ldur            x2, [fp, #-0x18]
    // 0x1253cec: ldur            x3, [fp, #-0x10]
    // 0x1253cf0: r1 = Function '<anonymous closure>':.
    //     0x1253cf0: add             x1, PP, #0xd, lsl #12  ; [pp+0xd928] AnonymousClosure: (0x1253d28), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::entries (0x1253c58)
    //     0x1253cf4: ldr             x1, [x1, #0x928]
    // 0x1253cf8: r0 = AllocateClosureTA()
    //     0x1253cf8: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x1253cfc: ldur            x16, [fp, #-0x28]
    // 0x1253d00: ldur            lr, [fp, #-8]
    // 0x1253d04: stp             lr, x16, [SP, #8]
    // 0x1253d08: str             x0, [SP]
    // 0x1253d0c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1253d0c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1253d10: r0 = map()
    //     0x1253d10: bl              #0xb007e4  ; [dart:core] Iterable::map
    // 0x1253d14: LeaveFrame
    //     0x1253d14: mov             SP, fp
    //     0x1253d18: ldp             fp, lr, [SP], #0x10
    // 0x1253d1c: ret
    //     0x1253d1c: ret             
    // 0x1253d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1253d20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1253d24: b               #0x1253c74
  }
  [closure] MapEntry<X1, X2> <anonymous closure>(dynamic, MapEntry<X0, MapEntry<X1, X2>>) {
    // ** addr: 0x1253d28, size: 0xa0
    // 0x1253d28: EnterFrame
    //     0x1253d28: stp             fp, lr, [SP, #-0x10]!
    //     0x1253d2c: mov             fp, SP
    // 0x1253d30: AllocStack(0x10)
    //     0x1253d30: sub             SP, SP, #0x10
    // 0x1253d34: SetupParameters([dynamic _ /* r0 */])
    //     0x1253d34: ldr             x0, [fp, #0x18]
    //     0x1253d38: ldur            w1, [x0, #0x17]
    //     0x1253d3c: add             x1, x1, HEAP, lsl #32
    // 0x1253d40: LoadField: r0 = r1->field_f
    //     0x1253d40: ldur            w0, [x1, #0xf]
    // 0x1253d44: DecompressPointer r0
    //     0x1253d44: add             x0, x0, HEAP, lsl #32
    // 0x1253d48: LoadField: r2 = r0->field_7
    //     0x1253d48: ldur            w2, [x0, #7]
    // 0x1253d4c: DecompressPointer r2
    //     0x1253d4c: add             x2, x2, HEAP, lsl #32
    // 0x1253d50: r1 = Null
    //     0x1253d50: mov             x1, NULL
    // 0x1253d54: r3 = <X1, X2>
    //     0x1253d54: add             x3, PP, #8, lsl #12  ; [pp+0x8760] TypeArguments: <X1, X2>
    //     0x1253d58: ldr             x3, [x3, #0x760]
    // 0x1253d5c: r0 = Null
    //     0x1253d5c: mov             x0, NULL
    // 0x1253d60: cmp             x2, x0
    // 0x1253d64: b.eq            #0x1253d74
    // 0x1253d68: r30 = InstantiateTypeArgumentsStub
    //     0x1253d68: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x1253d6c: LoadField: r30 = r30->field_7
    //     0x1253d6c: ldur            lr, [lr, #7]
    // 0x1253d70: blr             lr
    // 0x1253d74: mov             x1, x0
    // 0x1253d78: ldr             x0, [fp, #0x10]
    // 0x1253d7c: LoadField: r2 = r0->field_f
    //     0x1253d7c: ldur            w2, [x0, #0xf]
    // 0x1253d80: DecompressPointer r2
    //     0x1253d80: add             x2, x2, HEAP, lsl #32
    // 0x1253d84: cmp             w2, NULL
    // 0x1253d88: b.eq            #0x1253dc4
    // 0x1253d8c: LoadField: r0 = r2->field_b
    //     0x1253d8c: ldur            w0, [x2, #0xb]
    // 0x1253d90: DecompressPointer r0
    //     0x1253d90: add             x0, x0, HEAP, lsl #32
    // 0x1253d94: stur            x0, [fp, #-0x10]
    // 0x1253d98: LoadField: r3 = r2->field_f
    //     0x1253d98: ldur            w3, [x2, #0xf]
    // 0x1253d9c: DecompressPointer r3
    //     0x1253d9c: add             x3, x3, HEAP, lsl #32
    // 0x1253da0: stur            x3, [fp, #-8]
    // 0x1253da4: r0 = MapEntry()
    //     0x1253da4: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x1253da8: ldur            x1, [fp, #-0x10]
    // 0x1253dac: StoreField: r0->field_b = r1
    //     0x1253dac: stur            w1, [x0, #0xb]
    // 0x1253db0: ldur            x1, [fp, #-8]
    // 0x1253db4: StoreField: r0->field_f = r1
    //     0x1253db4: stur            w1, [x0, #0xf]
    // 0x1253db8: LeaveFrame
    //     0x1253db8: mov             SP, fp
    //     0x1253dbc: ldp             fp, lr, [SP], #0x10
    // 0x1253dc0: ret
    //     0x1253dc0: ret             
    // 0x1253dc4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x1253dc4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  void forEach(CanonicalizedMap<X0, X1, X2>, (dynamic, X1, X2) => void) {
    // ** addr: 0x1262548, size: 0x84
    // 0x1262548: EnterFrame
    //     0x1262548: stp             fp, lr, [SP, #-0x10]!
    //     0x126254c: mov             fp, SP
    // 0x1262550: AllocStack(0x10)
    //     0x1262550: sub             SP, SP, #0x10
    // 0x1262554: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x1262554: stur            x1, [fp, #-8]
    //     0x1262558: stur            x2, [fp, #-0x10]
    // 0x126255c: CheckStackOverflow
    //     0x126255c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1262560: cmp             SP, x16
    //     0x1262564: b.ls            #0x12625c4
    // 0x1262568: r1 = 2
    //     0x1262568: mov             x1, #2
    // 0x126256c: r0 = AllocateContext()
    //     0x126256c: bl              #0x13de838  ; AllocateContextStub
    // 0x1262570: mov             x1, x0
    // 0x1262574: ldur            x0, [fp, #-8]
    // 0x1262578: StoreField: r1->field_f = r0
    //     0x1262578: stur            w0, [x1, #0xf]
    // 0x126257c: ldur            x2, [fp, #-0x10]
    // 0x1262580: StoreField: r1->field_13 = r2
    //     0x1262580: stur            w2, [x1, #0x13]
    // 0x1262584: LoadField: r4 = r0->field_13
    //     0x1262584: ldur            w4, [x0, #0x13]
    // 0x1262588: DecompressPointer r4
    //     0x1262588: add             x4, x4, HEAP, lsl #32
    // 0x126258c: stur            x4, [fp, #-0x10]
    // 0x1262590: LoadField: r3 = r0->field_7
    //     0x1262590: ldur            w3, [x0, #7]
    // 0x1262594: DecompressPointer r3
    //     0x1262594: add             x3, x3, HEAP, lsl #32
    // 0x1262598: mov             x2, x1
    // 0x126259c: r1 = Function '<anonymous closure>':.
    //     0x126259c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd910] AnonymousClosure: (0xbec7f8), in [package:collection/src/canonicalized_map.dart] CanonicalizedMap::forEach (0x1262548)
    //     0x12625a0: ldr             x1, [x1, #0x910]
    // 0x12625a4: r0 = AllocateClosureTA()
    //     0x12625a4: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x12625a8: ldur            x1, [fp, #-0x10]
    // 0x12625ac: mov             x2, x0
    // 0x12625b0: r0 = forEach()
    //     0x12625b0: bl              #0x12a0da0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0x12625b4: r0 = Null
    //     0x12625b4: mov             x0, NULL
    // 0x12625b8: LeaveFrame
    //     0x12625b8: mov             SP, fp
    //     0x12625bc: ldp             fp, lr, [SP], #0x10
    // 0x12625c0: ret
    //     0x12625c0: ret             
    // 0x12625c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12625c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12625c8: b               #0x1262568
  }
  bool isEmpty(CanonicalizedMap<X0, X1, X2>) {
    // ** addr: 0x1262834, size: 0x44
    // 0x1262834: EnterFrame
    //     0x1262834: stp             fp, lr, [SP, #-0x10]!
    //     0x1262838: mov             fp, SP
    // 0x126283c: LoadField: r2 = r1->field_13
    //     0x126283c: ldur            w2, [x1, #0x13]
    // 0x1262840: DecompressPointer r2
    //     0x1262840: add             x2, x2, HEAP, lsl #32
    // 0x1262844: LoadField: r1 = r2->field_13
    //     0x1262844: ldur            w1, [x2, #0x13]
    // 0x1262848: r3 = LoadInt32Instr(r1)
    //     0x1262848: sbfx            x3, x1, #1, #0x1f
    // 0x126284c: asr             x1, x3, #1
    // 0x1262850: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x1262850: ldur            w3, [x2, #0x17]
    // 0x1262854: r2 = LoadInt32Instr(r3)
    //     0x1262854: sbfx            x2, x3, #1, #0x1f
    // 0x1262858: sub             x3, x1, x2
    // 0x126285c: cbz             x3, #0x1262868
    // 0x1262860: r0 = false
    //     0x1262860: add             x0, NULL, #0x30  ; false
    // 0x1262864: b               #0x126286c
    // 0x1262868: r0 = true
    //     0x1262868: add             x0, NULL, #0x20  ; true
    // 0x126286c: LeaveFrame
    //     0x126286c: mov             SP, fp
    //     0x1262870: ldp             fp, lr, [SP], #0x10
    // 0x1262874: ret
    //     0x1262874: ret             
  }
  get _ keys(/* No info */) {
    // ** addr: 0x128299c, size: 0xd8
    // 0x128299c: EnterFrame
    //     0x128299c: stp             fp, lr, [SP, #-0x10]!
    //     0x12829a0: mov             fp, SP
    // 0x12829a4: AllocStack(0x40)
    //     0x12829a4: sub             SP, SP, #0x40
    // 0x12829a8: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r1, fp-0x8 */)
    //     0x12829a8: stur            x1, [fp, #-8]
    // 0x12829ac: CheckStackOverflow
    //     0x12829ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12829b0: cmp             SP, x16
    //     0x12829b4: b.ls            #0x1282a6c
    // 0x12829b8: r1 = 1
    //     0x12829b8: mov             x1, #1
    // 0x12829bc: r0 = AllocateContext()
    //     0x12829bc: bl              #0x13de838  ; AllocateContextStub
    // 0x12829c0: mov             x4, x0
    // 0x12829c4: ldur            x0, [fp, #-8]
    // 0x12829c8: stur            x4, [fp, #-0x18]
    // 0x12829cc: StoreField: r4->field_f = r0
    //     0x12829cc: stur            w0, [x4, #0xf]
    // 0x12829d0: LoadField: r5 = r0->field_7
    //     0x12829d0: ldur            w5, [x0, #7]
    // 0x12829d4: DecompressPointer r5
    //     0x12829d4: add             x5, x5, HEAP, lsl #32
    // 0x12829d8: mov             x2, x5
    // 0x12829dc: stur            x5, [fp, #-0x10]
    // 0x12829e0: r1 = Null
    //     0x12829e0: mov             x1, NULL
    // 0x12829e4: r3 = <X1>
    //     0x12829e4: ldr             x3, [PP, #0x2cb0]  ; [pp+0x2cb0] TypeArguments: <X1>
    // 0x12829e8: r0 = Null
    //     0x12829e8: mov             x0, NULL
    // 0x12829ec: cmp             x2, x0
    // 0x12829f0: b.eq            #0x1282a00
    // 0x12829f4: r30 = InstantiateTypeArgumentsStub
    //     0x12829f4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x12829f8: LoadField: r30 = r30->field_7
    //     0x12829f8: ldur            lr, [lr, #7]
    // 0x12829fc: blr             lr
    // 0x1282a00: mov             x2, x0
    // 0x1282a04: ldur            x0, [fp, #-8]
    // 0x1282a08: stur            x2, [fp, #-0x28]
    // 0x1282a0c: LoadField: r3 = r0->field_13
    //     0x1282a0c: ldur            w3, [x0, #0x13]
    // 0x1282a10: DecompressPointer r3
    //     0x1282a10: add             x3, x3, HEAP, lsl #32
    // 0x1282a14: stur            x3, [fp, #-0x20]
    // 0x1282a18: r1 = <MapEntry<String, String>>
    //     0x1282a18: add             x1, PP, #0xd, lsl #12  ; [pp+0xd900] TypeArguments: <MapEntry<String, String>>
    //     0x1282a1c: ldr             x1, [x1, #0x900]
    // 0x1282a20: r0 = _CompactValuesIterable()
    //     0x1282a20: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x1282a24: mov             x4, x0
    // 0x1282a28: ldur            x0, [fp, #-0x20]
    // 0x1282a2c: stur            x4, [fp, #-8]
    // 0x1282a30: StoreField: r4->field_b = r0
    //     0x1282a30: stur            w0, [x4, #0xb]
    // 0x1282a34: ldur            x2, [fp, #-0x18]
    // 0x1282a38: ldur            x3, [fp, #-0x10]
    // 0x1282a3c: r1 = Function '<anonymous closure>':.
    //     0x1282a3c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd908] Function: [dart:ui] Paint::_objects (0x11006d0)
    //     0x1282a40: ldr             x1, [x1, #0x908]
    // 0x1282a44: r0 = AllocateClosureTA()
    //     0x1282a44: bl              #0x13dea48  ; AllocateClosureTAStub
    // 0x1282a48: ldur            x16, [fp, #-0x28]
    // 0x1282a4c: ldur            lr, [fp, #-8]
    // 0x1282a50: stp             lr, x16, [SP, #8]
    // 0x1282a54: str             x0, [SP]
    // 0x1282a58: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x1282a58: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x1282a5c: r0 = map()
    //     0x1282a5c: bl              #0xb007e4  ; [dart:core] Iterable::map
    // 0x1282a60: LeaveFrame
    //     0x1282a60: mov             SP, fp
    //     0x1282a64: ldp             fp, lr, [SP], #0x10
    // 0x1282a68: ret
    //     0x1282a68: ret             
    // 0x1282a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1282a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1282a70: b               #0x12829b8
  }
  bool containsKey(CanonicalizedMap<X0, X1, X2>, Object?) {
    // ** addr: 0x1294cd8, size: 0x15c
    // 0x1294cd8: EnterFrame
    //     0x1294cd8: stp             fp, lr, [SP, #-0x10]!
    //     0x1294cdc: mov             fp, SP
    // 0x1294ce0: AllocStack(0x20)
    //     0x1294ce0: sub             SP, SP, #0x20
    // 0x1294ce4: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x1294ce4: mov             x4, x1
    //     0x1294ce8: mov             x3, x2
    //     0x1294cec: stur            x1, [fp, #-0x10]
    //     0x1294cf0: stur            x2, [fp, #-0x18]
    // 0x1294cf4: CheckStackOverflow
    //     0x1294cf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1294cf8: cmp             SP, x16
    //     0x1294cfc: b.ls            #0x1294e2c
    // 0x1294d00: LoadField: r5 = r4->field_7
    //     0x1294d00: ldur            w5, [x4, #7]
    // 0x1294d04: DecompressPointer r5
    //     0x1294d04: add             x5, x5, HEAP, lsl #32
    // 0x1294d08: mov             x0, x3
    // 0x1294d0c: mov             x2, x5
    // 0x1294d10: stur            x5, [fp, #-8]
    // 0x1294d14: r1 = Null
    //     0x1294d14: mov             x1, NULL
    // 0x1294d18: cmp             w2, NULL
    // 0x1294d1c: b.eq            #0x1294db4
    // 0x1294d20: LoadField: r3 = r2->field_1b
    //     0x1294d20: ldur            w3, [x2, #0x1b]
    // 0x1294d24: DecompressPointer r3
    //     0x1294d24: add             x3, x3, HEAP, lsl #32
    // 0x1294d28: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x1294d2c: cmp             w3, w16
    // 0x1294d30: b.eq            #0x1294db4
    // 0x1294d34: r16 = Object?
    //     0x1294d34: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x1294d38: cmp             w3, w16
    // 0x1294d3c: b.eq            #0x1294db4
    // 0x1294d40: r16 = void?
    //     0x1294d40: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x1294d44: cmp             w3, w16
    // 0x1294d48: b.eq            #0x1294db4
    // 0x1294d4c: tbnz            w0, #0, #0x1294d68
    // 0x1294d50: r16 = int
    //     0x1294d50: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x1294d54: cmp             w3, w16
    // 0x1294d58: b.eq            #0x1294db4
    // 0x1294d5c: r16 = num
    //     0x1294d5c: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x1294d60: cmp             w3, w16
    // 0x1294d64: b.eq            #0x1294db4
    // 0x1294d68: r3 = SubtypeTestCache
    //     0x1294d68: add             x3, PP, #0xd, lsl #12  ; [pp+0xd938] SubtypeTestCache
    //     0x1294d6c: ldr             x3, [x3, #0x938]
    // 0x1294d70: r30 = Subtype6TestCacheStub
    //     0x1294d70: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0x1294d74: LoadField: r30 = r30->field_7
    //     0x1294d74: ldur            lr, [lr, #7]
    // 0x1294d78: blr             lr
    // 0x1294d7c: cmp             w7, NULL
    // 0x1294d80: b.eq            #0x1294d8c
    // 0x1294d84: tbnz            w7, #4, #0x1294dac
    // 0x1294d88: b               #0x1294db4
    // 0x1294d8c: r8 = X1
    //     0x1294d8c: add             x8, PP, #0xd, lsl #12  ; [pp+0xd940] TypeParameter: X1
    //     0x1294d90: ldr             x8, [x8, #0x940]
    // 0x1294d94: r3 = SubtypeTestCache
    //     0x1294d94: add             x3, PP, #0xd, lsl #12  ; [pp+0xd948] SubtypeTestCache
    //     0x1294d98: ldr             x3, [x3, #0x948]
    // 0x1294d9c: r30 = InstanceOfStub
    //     0x1294d9c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x1294da0: LoadField: r30 = r30->field_7
    //     0x1294da0: ldur            lr, [lr, #7]
    // 0x1294da4: blr             lr
    // 0x1294da8: b               #0x1294db8
    // 0x1294dac: r0 = false
    //     0x1294dac: add             x0, NULL, #0x30  ; false
    // 0x1294db0: b               #0x1294db8
    // 0x1294db4: r0 = true
    //     0x1294db4: add             x0, NULL, #0x20  ; true
    // 0x1294db8: tbnz            w0, #4, #0x1294e1c
    // 0x1294dbc: ldur            x0, [fp, #-0x10]
    // 0x1294dc0: LoadField: r3 = r0->field_13
    //     0x1294dc0: ldur            w3, [x0, #0x13]
    // 0x1294dc4: DecompressPointer r3
    //     0x1294dc4: add             x3, x3, HEAP, lsl #32
    // 0x1294dc8: ldur            x0, [fp, #-0x18]
    // 0x1294dcc: ldur            x2, [fp, #-8]
    // 0x1294dd0: stur            x3, [fp, #-0x20]
    // 0x1294dd4: r1 = Null
    //     0x1294dd4: mov             x1, NULL
    // 0x1294dd8: cmp             w2, NULL
    // 0x1294ddc: b.eq            #0x1294dfc
    // 0x1294de0: LoadField: r4 = r2->field_1b
    //     0x1294de0: ldur            w4, [x2, #0x1b]
    // 0x1294de4: DecompressPointer r4
    //     0x1294de4: add             x4, x4, HEAP, lsl #32
    // 0x1294de8: r8 = X1
    //     0x1294de8: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x1294dec: LoadField: r9 = r4->field_7
    //     0x1294dec: ldur            x9, [x4, #7]
    // 0x1294df0: r3 = Null
    //     0x1294df0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd950] Null
    //     0x1294df4: ldr             x3, [x3, #0x950]
    // 0x1294df8: blr             x9
    // 0x1294dfc: ldur            x1, [fp, #-0x18]
    // 0x1294e00: r0 = _canonicalizer()
    //     0x1294e00: bl              #0x8f342c  ; [package:http_parser/src/case_insensitive_map.dart] CaseInsensitiveMap::_canonicalizer
    // 0x1294e04: ldur            x1, [fp, #-0x20]
    // 0x1294e08: mov             x2, x0
    // 0x1294e0c: r0 = containsKey()
    //     0x1294e0c: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x1294e10: LeaveFrame
    //     0x1294e10: mov             SP, fp
    //     0x1294e14: ldp             fp, lr, [SP], #0x10
    // 0x1294e18: ret
    //     0x1294e18: ret             
    // 0x1294e1c: r0 = false
    //     0x1294e1c: add             x0, NULL, #0x30  ; false
    // 0x1294e20: LeaveFrame
    //     0x1294e20: mov             SP, fp
    //     0x1294e24: ldp             fp, lr, [SP], #0x10
    // 0x1294e28: ret
    //     0x1294e28: ret             
    // 0x1294e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1294e2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1294e30: b               #0x1294d00
  }
  X2? [](CanonicalizedMap<X0, X1, X2>, Object?) {
    // ** addr: 0x12b6aa4, size: 0x198
    // 0x12b6aa4: EnterFrame
    //     0x12b6aa4: stp             fp, lr, [SP, #-0x10]!
    //     0x12b6aa8: mov             fp, SP
    // 0x12b6aac: AllocStack(0x20)
    //     0x12b6aac: sub             SP, SP, #0x20
    // 0x12b6ab0: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x12b6ab0: mov             x4, x1
    //     0x12b6ab4: mov             x3, x2
    //     0x12b6ab8: stur            x1, [fp, #-0x10]
    //     0x12b6abc: stur            x2, [fp, #-0x18]
    // 0x12b6ac0: CheckStackOverflow
    //     0x12b6ac0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b6ac4: cmp             SP, x16
    //     0x12b6ac8: b.ls            #0x12b6c34
    // 0x12b6acc: LoadField: r5 = r4->field_7
    //     0x12b6acc: ldur            w5, [x4, #7]
    // 0x12b6ad0: DecompressPointer r5
    //     0x12b6ad0: add             x5, x5, HEAP, lsl #32
    // 0x12b6ad4: mov             x0, x3
    // 0x12b6ad8: mov             x2, x5
    // 0x12b6adc: stur            x5, [fp, #-8]
    // 0x12b6ae0: r1 = Null
    //     0x12b6ae0: mov             x1, NULL
    // 0x12b6ae4: cmp             w2, NULL
    // 0x12b6ae8: b.eq            #0x12b6b80
    // 0x12b6aec: LoadField: r3 = r2->field_1b
    //     0x12b6aec: ldur            w3, [x2, #0x1b]
    // 0x12b6af0: DecompressPointer r3
    //     0x12b6af0: add             x3, x3, HEAP, lsl #32
    // 0x12b6af4: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x12b6af8: cmp             w3, w16
    // 0x12b6afc: b.eq            #0x12b6b80
    // 0x12b6b00: r16 = Object?
    //     0x12b6b00: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x12b6b04: cmp             w3, w16
    // 0x12b6b08: b.eq            #0x12b6b80
    // 0x12b6b0c: r16 = void?
    //     0x12b6b0c: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x12b6b10: cmp             w3, w16
    // 0x12b6b14: b.eq            #0x12b6b80
    // 0x12b6b18: tbnz            w0, #0, #0x12b6b34
    // 0x12b6b1c: r16 = int
    //     0x12b6b1c: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x12b6b20: cmp             w3, w16
    // 0x12b6b24: b.eq            #0x12b6b80
    // 0x12b6b28: r16 = num
    //     0x12b6b28: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x12b6b2c: cmp             w3, w16
    // 0x12b6b30: b.eq            #0x12b6b80
    // 0x12b6b34: r3 = SubtypeTestCache
    //     0x12b6b34: add             x3, PP, #0xd, lsl #12  ; [pp+0xd960] SubtypeTestCache
    //     0x12b6b38: ldr             x3, [x3, #0x960]
    // 0x12b6b3c: r30 = Subtype6TestCacheStub
    //     0x12b6b3c: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0x12b6b40: LoadField: r30 = r30->field_7
    //     0x12b6b40: ldur            lr, [lr, #7]
    // 0x12b6b44: blr             lr
    // 0x12b6b48: cmp             w7, NULL
    // 0x12b6b4c: b.eq            #0x12b6b58
    // 0x12b6b50: tbnz            w7, #4, #0x12b6b78
    // 0x12b6b54: b               #0x12b6b80
    // 0x12b6b58: r8 = X1
    //     0x12b6b58: add             x8, PP, #0xd, lsl #12  ; [pp+0xd968] TypeParameter: X1
    //     0x12b6b5c: ldr             x8, [x8, #0x968]
    // 0x12b6b60: r3 = SubtypeTestCache
    //     0x12b6b60: add             x3, PP, #0xd, lsl #12  ; [pp+0xd970] SubtypeTestCache
    //     0x12b6b64: ldr             x3, [x3, #0x970]
    // 0x12b6b68: r30 = InstanceOfStub
    //     0x12b6b68: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12b6b6c: LoadField: r30 = r30->field_7
    //     0x12b6b6c: ldur            lr, [lr, #7]
    // 0x12b6b70: blr             lr
    // 0x12b6b74: b               #0x12b6b84
    // 0x12b6b78: r0 = false
    //     0x12b6b78: add             x0, NULL, #0x30  ; false
    // 0x12b6b7c: b               #0x12b6b84
    // 0x12b6b80: r0 = true
    //     0x12b6b80: add             x0, NULL, #0x20  ; true
    // 0x12b6b84: tbnz            w0, #4, #0x12b6c24
    // 0x12b6b88: ldur            x0, [fp, #-0x10]
    // 0x12b6b8c: LoadField: r3 = r0->field_13
    //     0x12b6b8c: ldur            w3, [x0, #0x13]
    // 0x12b6b90: DecompressPointer r3
    //     0x12b6b90: add             x3, x3, HEAP, lsl #32
    // 0x12b6b94: ldur            x0, [fp, #-0x18]
    // 0x12b6b98: ldur            x2, [fp, #-8]
    // 0x12b6b9c: stur            x3, [fp, #-0x20]
    // 0x12b6ba0: r1 = Null
    //     0x12b6ba0: mov             x1, NULL
    // 0x12b6ba4: cmp             w2, NULL
    // 0x12b6ba8: b.eq            #0x12b6bc8
    // 0x12b6bac: LoadField: r4 = r2->field_1b
    //     0x12b6bac: ldur            w4, [x2, #0x1b]
    // 0x12b6bb0: DecompressPointer r4
    //     0x12b6bb0: add             x4, x4, HEAP, lsl #32
    // 0x12b6bb4: r8 = X1
    //     0x12b6bb4: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x12b6bb8: LoadField: r9 = r4->field_7
    //     0x12b6bb8: ldur            x9, [x4, #7]
    // 0x12b6bbc: r3 = Null
    //     0x12b6bbc: add             x3, PP, #0xd, lsl #12  ; [pp+0xd978] Null
    //     0x12b6bc0: ldr             x3, [x3, #0x978]
    // 0x12b6bc4: blr             x9
    // 0x12b6bc8: ldur            x1, [fp, #-0x18]
    // 0x12b6bcc: r0 = _canonicalizer()
    //     0x12b6bcc: bl              #0x8f342c  ; [package:http_parser/src/case_insensitive_map.dart] CaseInsensitiveMap::_canonicalizer
    // 0x12b6bd0: ldur            x1, [fp, #-0x20]
    // 0x12b6bd4: mov             x2, x0
    // 0x12b6bd8: r0 = _getValueOrData()
    //     0x12b6bd8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x12b6bdc: ldur            x1, [fp, #-0x20]
    // 0x12b6be0: LoadField: r2 = r1->field_f
    //     0x12b6be0: ldur            w2, [x1, #0xf]
    // 0x12b6be4: DecompressPointer r2
    //     0x12b6be4: add             x2, x2, HEAP, lsl #32
    // 0x12b6be8: cmp             w2, w0
    // 0x12b6bec: b.ne            #0x12b6bf8
    // 0x12b6bf0: r1 = Null
    //     0x12b6bf0: mov             x1, NULL
    // 0x12b6bf4: b               #0x12b6bfc
    // 0x12b6bf8: mov             x1, x0
    // 0x12b6bfc: cmp             w1, NULL
    // 0x12b6c00: b.ne            #0x12b6c0c
    // 0x12b6c04: r0 = Null
    //     0x12b6c04: mov             x0, NULL
    // 0x12b6c08: b               #0x12b6c18
    // 0x12b6c0c: LoadField: r2 = r1->field_f
    //     0x12b6c0c: ldur            w2, [x1, #0xf]
    // 0x12b6c10: DecompressPointer r2
    //     0x12b6c10: add             x2, x2, HEAP, lsl #32
    // 0x12b6c14: mov             x0, x2
    // 0x12b6c18: LeaveFrame
    //     0x12b6c18: mov             SP, fp
    //     0x12b6c1c: ldp             fp, lr, [SP], #0x10
    // 0x12b6c20: ret
    //     0x12b6c20: ret             
    // 0x12b6c24: r0 = Null
    //     0x12b6c24: mov             x0, NULL
    // 0x12b6c28: LeaveFrame
    //     0x12b6c28: mov             SP, fp
    //     0x12b6c2c: ldp             fp, lr, [SP], #0x10
    // 0x12b6c30: ret
    //     0x12b6c30: ret             
    // 0x12b6c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b6c34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b6c38: b               #0x12b6acc
  }
  void []=(CanonicalizedMap<X0, X1, X2>, X1, X2) {
    // ** addr: 0x12b70cc, size: 0x238
    // 0x12b70cc: EnterFrame
    //     0x12b70cc: stp             fp, lr, [SP, #-0x10]!
    //     0x12b70d0: mov             fp, SP
    // 0x12b70d4: AllocStack(0x28)
    //     0x12b70d4: sub             SP, SP, #0x28
    // 0x12b70d8: SetupParameters(CanonicalizedMap<X0, X1, X2> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0x12b70d8: mov             x5, x1
    //     0x12b70dc: mov             x4, x2
    //     0x12b70e0: stur            x1, [fp, #-0x10]
    //     0x12b70e4: stur            x2, [fp, #-0x18]
    //     0x12b70e8: stur            x3, [fp, #-0x20]
    // 0x12b70ec: CheckStackOverflow
    //     0x12b70ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b70f0: cmp             SP, x16
    //     0x12b70f4: b.ls            #0x12b72fc
    // 0x12b70f8: LoadField: r6 = r5->field_7
    //     0x12b70f8: ldur            w6, [x5, #7]
    // 0x12b70fc: DecompressPointer r6
    //     0x12b70fc: add             x6, x6, HEAP, lsl #32
    // 0x12b7100: mov             x0, x4
    // 0x12b7104: mov             x2, x6
    // 0x12b7108: stur            x6, [fp, #-8]
    // 0x12b710c: r1 = Null
    //     0x12b710c: mov             x1, NULL
    // 0x12b7110: cmp             w2, NULL
    // 0x12b7114: b.eq            #0x12b7134
    // 0x12b7118: LoadField: r4 = r2->field_1b
    //     0x12b7118: ldur            w4, [x2, #0x1b]
    // 0x12b711c: DecompressPointer r4
    //     0x12b711c: add             x4, x4, HEAP, lsl #32
    // 0x12b7120: r8 = X1
    //     0x12b7120: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x12b7124: LoadField: r9 = r4->field_7
    //     0x12b7124: ldur            x9, [x4, #7]
    // 0x12b7128: r3 = Null
    //     0x12b7128: add             x3, PP, #8, lsl #12  ; [pp+0x8720] Null
    //     0x12b712c: ldr             x3, [x3, #0x720]
    // 0x12b7130: blr             x9
    // 0x12b7134: ldur            x0, [fp, #-0x20]
    // 0x12b7138: ldur            x2, [fp, #-8]
    // 0x12b713c: r1 = Null
    //     0x12b713c: mov             x1, NULL
    // 0x12b7140: cmp             w2, NULL
    // 0x12b7144: b.eq            #0x12b7168
    // 0x12b7148: LoadField: r4 = r2->field_1f
    //     0x12b7148: ldur            w4, [x2, #0x1f]
    // 0x12b714c: DecompressPointer r4
    //     0x12b714c: add             x4, x4, HEAP, lsl #32
    // 0x12b7150: r8 = X2
    //     0x12b7150: add             x8, PP, #8, lsl #12  ; [pp+0x8730] TypeParameter: X2
    //     0x12b7154: ldr             x8, [x8, #0x730]
    // 0x12b7158: LoadField: r9 = r4->field_7
    //     0x12b7158: ldur            x9, [x4, #7]
    // 0x12b715c: r3 = Null
    //     0x12b715c: add             x3, PP, #8, lsl #12  ; [pp+0x8738] Null
    //     0x12b7160: ldr             x3, [x3, #0x738]
    // 0x12b7164: blr             x9
    // 0x12b7168: ldur            x0, [fp, #-0x18]
    // 0x12b716c: ldur            x2, [fp, #-8]
    // 0x12b7170: r1 = Null
    //     0x12b7170: mov             x1, NULL
    // 0x12b7174: cmp             w2, NULL
    // 0x12b7178: b.eq            #0x12b7210
    // 0x12b717c: LoadField: r3 = r2->field_1b
    //     0x12b717c: ldur            w3, [x2, #0x1b]
    // 0x12b7180: DecompressPointer r3
    //     0x12b7180: add             x3, x3, HEAP, lsl #32
    // 0x12b7184: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x12b7188: cmp             w3, w16
    // 0x12b718c: b.eq            #0x12b7210
    // 0x12b7190: r16 = Object?
    //     0x12b7190: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x12b7194: cmp             w3, w16
    // 0x12b7198: b.eq            #0x12b7210
    // 0x12b719c: r16 = void?
    //     0x12b719c: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x12b71a0: cmp             w3, w16
    // 0x12b71a4: b.eq            #0x12b7210
    // 0x12b71a8: tbnz            w0, #0, #0x12b71c4
    // 0x12b71ac: r16 = int
    //     0x12b71ac: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x12b71b0: cmp             w3, w16
    // 0x12b71b4: b.eq            #0x12b7210
    // 0x12b71b8: r16 = num
    //     0x12b71b8: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x12b71bc: cmp             w3, w16
    // 0x12b71c0: b.eq            #0x12b7210
    // 0x12b71c4: r3 = SubtypeTestCache
    //     0x12b71c4: add             x3, PP, #8, lsl #12  ; [pp+0x8748] SubtypeTestCache
    //     0x12b71c8: ldr             x3, [x3, #0x748]
    // 0x12b71cc: r30 = Subtype6TestCacheStub
    //     0x12b71cc: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0x12b71d0: LoadField: r30 = r30->field_7
    //     0x12b71d0: ldur            lr, [lr, #7]
    // 0x12b71d4: blr             lr
    // 0x12b71d8: cmp             w7, NULL
    // 0x12b71dc: b.eq            #0x12b71e8
    // 0x12b71e0: tbnz            w7, #4, #0x12b7208
    // 0x12b71e4: b               #0x12b7210
    // 0x12b71e8: r8 = X1
    //     0x12b71e8: add             x8, PP, #8, lsl #12  ; [pp+0x8750] TypeParameter: X1
    //     0x12b71ec: ldr             x8, [x8, #0x750]
    // 0x12b71f0: r3 = SubtypeTestCache
    //     0x12b71f0: add             x3, PP, #8, lsl #12  ; [pp+0x8758] SubtypeTestCache
    //     0x12b71f4: ldr             x3, [x3, #0x758]
    // 0x12b71f8: r30 = InstanceOfStub
    //     0x12b71f8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x12b71fc: LoadField: r30 = r30->field_7
    //     0x12b71fc: ldur            lr, [lr, #7]
    // 0x12b7200: blr             lr
    // 0x12b7204: b               #0x12b7214
    // 0x12b7208: r0 = false
    //     0x12b7208: add             x0, NULL, #0x30  ; false
    // 0x12b720c: b               #0x12b7214
    // 0x12b7210: r0 = true
    //     0x12b7210: add             x0, NULL, #0x20  ; true
    // 0x12b7214: tbnz            w0, #4, #0x12b72ec
    // 0x12b7218: ldur            x1, [fp, #-0x10]
    // 0x12b721c: ldur            x2, [fp, #-0x18]
    // 0x12b7220: ldur            x0, [fp, #-0x20]
    // 0x12b7224: LoadField: r3 = r1->field_13
    //     0x12b7224: ldur            w3, [x1, #0x13]
    // 0x12b7228: DecompressPointer r3
    //     0x12b7228: add             x3, x3, HEAP, lsl #32
    // 0x12b722c: mov             x1, x2
    // 0x12b7230: stur            x3, [fp, #-0x28]
    // 0x12b7234: r0 = _canonicalizer()
    //     0x12b7234: bl              #0x8f342c  ; [package:http_parser/src/case_insensitive_map.dart] CaseInsensitiveMap::_canonicalizer
    // 0x12b7238: ldur            x2, [fp, #-8]
    // 0x12b723c: r1 = Null
    //     0x12b723c: mov             x1, NULL
    // 0x12b7240: r3 = <X1, X2>
    //     0x12b7240: add             x3, PP, #8, lsl #12  ; [pp+0x8760] TypeArguments: <X1, X2>
    //     0x12b7244: ldr             x3, [x3, #0x760]
    // 0x12b7248: stur            x0, [fp, #-8]
    // 0x12b724c: r0 = Null
    //     0x12b724c: mov             x0, NULL
    // 0x12b7250: cmp             x2, x0
    // 0x12b7254: b.eq            #0x12b7264
    // 0x12b7258: r30 = InstantiateTypeArgumentsStub
    //     0x12b7258: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x12b725c: LoadField: r30 = r30->field_7
    //     0x12b725c: ldur            lr, [lr, #7]
    // 0x12b7260: blr             lr
    // 0x12b7264: mov             x1, x0
    // 0x12b7268: r0 = MapEntry()
    //     0x12b7268: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x12b726c: mov             x3, x0
    // 0x12b7270: ldur            x0, [fp, #-0x18]
    // 0x12b7274: stur            x3, [fp, #-0x10]
    // 0x12b7278: StoreField: r3->field_b = r0
    //     0x12b7278: stur            w0, [x3, #0xb]
    // 0x12b727c: ldur            x0, [fp, #-0x20]
    // 0x12b7280: StoreField: r3->field_f = r0
    //     0x12b7280: stur            w0, [x3, #0xf]
    // 0x12b7284: mov             x0, x3
    // 0x12b7288: r2 = Null
    //     0x12b7288: mov             x2, NULL
    // 0x12b728c: r1 = Null
    //     0x12b728c: mov             x1, NULL
    // 0x12b7290: r8 = MapEntry<String, String>
    //     0x12b7290: add             x8, PP, #8, lsl #12  ; [pp+0x8768] Type: MapEntry<String, String>
    //     0x12b7294: ldr             x8, [x8, #0x768]
    // 0x12b7298: r3 = Null
    //     0x12b7298: add             x3, PP, #8, lsl #12  ; [pp+0x8770] Null
    //     0x12b729c: ldr             x3, [x3, #0x770]
    // 0x12b72a0: r0 = MapEntry<String, String>()
    //     0x12b72a0: bl              #0x8e1108  ; IsType_MapEntry<String, String>_Stub
    // 0x12b72a4: ldur            x1, [fp, #-0x28]
    // 0x12b72a8: ldur            x2, [fp, #-8]
    // 0x12b72ac: r0 = _hashCode()
    //     0x12b72ac: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x12b72b0: mov             x2, x0
    // 0x12b72b4: r0 = BoxInt64Instr(r2)
    //     0x12b72b4: sbfiz           x0, x2, #1, #0x1f
    //     0x12b72b8: cmp             x2, x0, asr #1
    //     0x12b72bc: b.eq            #0x12b72c8
    //     0x12b72c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12b72c4: stur            x2, [x0, #7]
    // 0x12b72c8: ldur            x1, [fp, #-0x28]
    // 0x12b72cc: ldur            x2, [fp, #-8]
    // 0x12b72d0: ldur            x3, [fp, #-0x10]
    // 0x12b72d4: mov             x5, x0
    // 0x12b72d8: r0 = _set()
    //     0x12b72d8: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x12b72dc: r0 = Null
    //     0x12b72dc: mov             x0, NULL
    // 0x12b72e0: LeaveFrame
    //     0x12b72e0: mov             SP, fp
    //     0x12b72e4: ldp             fp, lr, [SP], #0x10
    // 0x12b72e8: ret
    //     0x12b72e8: ret             
    // 0x12b72ec: r0 = Null
    //     0x12b72ec: mov             x0, NULL
    // 0x12b72f0: LeaveFrame
    //     0x12b72f0: mov             SP, fp
    //     0x12b72f4: ldp             fp, lr, [SP], #0x10
    // 0x12b72f8: ret
    //     0x12b72f8: ret             
    // 0x12b72fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b72fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b7300: b               #0x12b70f8
  }
}
