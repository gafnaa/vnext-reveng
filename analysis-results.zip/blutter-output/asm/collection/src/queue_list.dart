// lib: , url: package:collection/src/queue_list.dart

// class id: 1048657, size: 0x8
class :: {
}

// class id: 4221, size: 0x20, field offset: 0xc
class QueueList<X0> extends _MixinApplication379&Object&ListMixin<X0>
    implements Queue<X0> {

  QueueList<Y0> cast<Y0>(QueueList<X0>) {
    // ** addr: 0xb21d68, size: 0x8c
    // 0xb21d68: EnterFrame
    //     0xb21d68: stp             fp, lr, [SP, #-0x10]!
    //     0xb21d6c: mov             fp, SP
    // 0xb21d70: AllocStack(0x10)
    //     0xb21d70: sub             SP, SP, #0x10
    // 0xb21d74: SetupParameters([dynamic _ /* r0 */])
    //     0xb21d74: ldur            w0, [x4, #0xf]
    //     0xb21d78: cbnz            w0, #0xb21d84
    //     0xb21d7c: mov             x1, NULL
    //     0xb21d80: b               #0xb21d90
    //     0xb21d84: ldur            w0, [x4, #0x17]
    //     0xb21d88: add             x1, fp, w0, sxtw #2
    //     0xb21d8c: ldr             x1, [x1, #0x10]
    //     0xb21d90: ldr             x0, [fp, #0x10]
    // 0xb21d94: CheckStackOverflow
    //     0xb21d94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21d98: cmp             SP, x16
    //     0xb21d9c: b.ls            #0xb21dec
    // 0xb21da0: LoadField: r2 = r0->field_7
    //     0xb21da0: ldur            w2, [x0, #7]
    // 0xb21da4: DecompressPointer r2
    //     0xb21da4: add             x2, x2, HEAP, lsl #32
    // 0xb21da8: r3 = <X0, Y0>
    //     0xb21da8: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf948] TypeArguments: <X0, Y0>
    //     0xb21dac: ldr             x3, [x3, #0x948]
    // 0xb21db0: r0 = Null
    //     0xb21db0: mov             x0, NULL
    // 0xb21db4: cmp             x2, x0
    // 0xb21db8: b.ne            #0xb21dc4
    // 0xb21dbc: cmp             x1, x0
    // 0xb21dc0: b.eq            #0xb21dd0
    // 0xb21dc4: r30 = InstantiateTypeArgumentsStub
    //     0xb21dc4: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xb21dc8: LoadField: r30 = r30->field_7
    //     0xb21dc8: ldur            lr, [lr, #7]
    // 0xb21dcc: blr             lr
    // 0xb21dd0: ldr             x16, [fp, #0x10]
    // 0xb21dd4: stp             x16, x0, [SP]
    // 0xb21dd8: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xb21dd8: ldr             x4, [PP, #0x18e0]  ; [pp+0x18e0] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xb21ddc: r0 = _castFrom()
    //     0xb21ddc: bl              #0xb21df4  ; [package:collection/src/queue_list.dart] QueueList::_castFrom
    // 0xb21de0: LeaveFrame
    //     0xb21de0: mov             SP, fp
    //     0xb21de4: ldp             fp, lr, [SP], #0x10
    // 0xb21de8: ret
    //     0xb21de8: ret             
    // 0xb21dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21dec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21df0: b               #0xb21da0
  }
  int length(QueueList<X0>) {
    // ** addr: 0xc15fe0, size: 0x1d0
    // 0xc15fe0: EnterFrame
    //     0xc15fe0: stp             fp, lr, [SP, #-0x10]!
    //     0xc15fe4: mov             fp, SP
    // 0xc15fe8: AllocStack(0x18)
    //     0xc15fe8: sub             SP, SP, #0x18
    // 0xc15fec: CheckStackOverflow
    //     0xc15fec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc15ff0: cmp             SP, x16
    //     0xc15ff4: b.ls            #0xc16190
    // 0xc15ff8: ldr             x2, [fp, #0x10]
    // 0xc15ffc: r3 = LoadClassIdInstr(r2)
    //     0xc15ffc: ldur            x3, [x2, #-1]
    //     0xc16000: ubfx            x3, x3, #0xc, #0x14
    // 0xc16004: stur            x3, [fp, #-8]
    // 0xc16008: r17 = 4221
    //     0xc16008: mov             x17, #0x107d
    // 0xc1600c: cmp             x3, x17
    // 0xc16010: b.ne            #0xc16024
    // 0xc16014: ArrayLoad: r0 = r2[0]  ; List_8
    //     0xc16014: ldur            x0, [x2, #0x17]
    // 0xc16018: mov             x2, x0
    // 0xc1601c: mov             x0, x3
    // 0xc16020: b               #0xc1608c
    // 0xc16024: LoadField: r0 = r2->field_1f
    //     0xc16024: ldur            w0, [x2, #0x1f]
    // 0xc16028: DecompressPointer r0
    //     0xc16028: add             x0, x0, HEAP, lsl #32
    // 0xc1602c: r1 = LoadClassIdInstr(r0)
    //     0xc1602c: ldur            x1, [x0, #-1]
    //     0xc16030: ubfx            x1, x1, #0xc, #0x14
    // 0xc16034: r17 = 4221
    //     0xc16034: mov             x17, #0x107d
    // 0xc16038: cmp             x1, x17
    // 0xc1603c: b.ne            #0xc1604c
    // 0xc16040: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xc16040: ldur            x1, [x0, #0x17]
    // 0xc16044: mov             x0, x1
    // 0xc16048: b               #0xc16084
    // 0xc1604c: LoadField: r1 = r0->field_1f
    //     0xc1604c: ldur            w1, [x0, #0x1f]
    // 0xc16050: DecompressPointer r1
    //     0xc16050: add             x1, x1, HEAP, lsl #32
    // 0xc16054: r0 = LoadClassIdInstr(r1)
    //     0xc16054: ldur            x0, [x1, #-1]
    //     0xc16058: ubfx            x0, x0, #0xc, #0x14
    // 0xc1605c: r17 = 4221
    //     0xc1605c: mov             x17, #0x107d
    // 0xc16060: cmp             x0, x17
    // 0xc16064: b.ne            #0xc16070
    // 0xc16068: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xc16068: ldur            x0, [x1, #0x17]
    // 0xc1606c: b               #0xc16084
    // 0xc16070: r0 = LoadClassIdInstr(r1)
    //     0xc16070: ldur            x0, [x1, #-1]
    //     0xc16074: ubfx            x0, x0, #0xc, #0x14
    // 0xc16078: r0 = GDT[cid_x0 + -0xfd0]()
    //     0xc16078: sub             lr, x0, #0xfd0
    //     0xc1607c: ldr             lr, [x21, lr, lsl #3]
    //     0xc16080: blr             lr
    // 0xc16084: mov             x2, x0
    // 0xc16088: ldur            x0, [fp, #-8]
    // 0xc1608c: stur            x2, [fp, #-0x10]
    // 0xc16090: r17 = 4221
    //     0xc16090: mov             x17, #0x107d
    // 0xc16094: cmp             x0, x17
    // 0xc16098: b.ne            #0xc160b8
    // 0xc1609c: ldr             x3, [fp, #0x10]
    // 0xc160a0: LoadField: r0 = r3->field_f
    //     0xc160a0: ldur            x0, [x3, #0xf]
    // 0xc160a4: mov             x16, x2
    // 0xc160a8: mov             x2, x0
    // 0xc160ac: mov             x0, x16
    // 0xc160b0: mov             x1, x3
    // 0xc160b4: b               #0xc16128
    // 0xc160b8: ldr             x3, [fp, #0x10]
    // 0xc160bc: LoadField: r0 = r3->field_1f
    //     0xc160bc: ldur            w0, [x3, #0x1f]
    // 0xc160c0: DecompressPointer r0
    //     0xc160c0: add             x0, x0, HEAP, lsl #32
    // 0xc160c4: r1 = LoadClassIdInstr(r0)
    //     0xc160c4: ldur            x1, [x0, #-1]
    //     0xc160c8: ubfx            x1, x1, #0xc, #0x14
    // 0xc160cc: r17 = 4221
    //     0xc160cc: mov             x17, #0x107d
    // 0xc160d0: cmp             x1, x17
    // 0xc160d4: b.ne            #0xc160e4
    // 0xc160d8: LoadField: r1 = r0->field_f
    //     0xc160d8: ldur            x1, [x0, #0xf]
    // 0xc160dc: mov             x0, x1
    // 0xc160e0: b               #0xc1611c
    // 0xc160e4: LoadField: r1 = r0->field_1f
    //     0xc160e4: ldur            w1, [x0, #0x1f]
    // 0xc160e8: DecompressPointer r1
    //     0xc160e8: add             x1, x1, HEAP, lsl #32
    // 0xc160ec: r0 = LoadClassIdInstr(r1)
    //     0xc160ec: ldur            x0, [x1, #-1]
    //     0xc160f0: ubfx            x0, x0, #0xc, #0x14
    // 0xc160f4: r17 = 4221
    //     0xc160f4: mov             x17, #0x107d
    // 0xc160f8: cmp             x0, x17
    // 0xc160fc: b.ne            #0xc16108
    // 0xc16100: LoadField: r0 = r1->field_f
    //     0xc16100: ldur            x0, [x1, #0xf]
    // 0xc16104: b               #0xc1611c
    // 0xc16108: r0 = LoadClassIdInstr(r1)
    //     0xc16108: ldur            x0, [x1, #-1]
    //     0xc1610c: ubfx            x0, x0, #0xc, #0x14
    // 0xc16110: r0 = GDT[cid_x0 + -0xfc8]()
    //     0xc16110: sub             lr, x0, #0xfc8
    //     0xc16114: ldr             lr, [x21, lr, lsl #3]
    //     0xc16118: blr             lr
    // 0xc1611c: mov             x2, x0
    // 0xc16120: ldr             x1, [fp, #0x10]
    // 0xc16124: ldur            x0, [fp, #-0x10]
    // 0xc16128: sub             x3, x0, x2
    // 0xc1612c: stur            x3, [fp, #-8]
    // 0xc16130: LoadField: r0 = r1->field_b
    //     0xc16130: ldur            w0, [x1, #0xb]
    // 0xc16134: DecompressPointer r0
    //     0xc16134: add             x0, x0, HEAP, lsl #32
    // 0xc16138: r1 = LoadClassIdInstr(r0)
    //     0xc16138: ldur            x1, [x0, #-1]
    //     0xc1613c: ubfx            x1, x1, #0xc, #0x14
    // 0xc16140: str             x0, [SP]
    // 0xc16144: mov             x0, x1
    // 0xc16148: r0 = GDT[cid_x0 + 0xf078]()
    //     0xc16148: mov             x17, #0xf078
    //     0xc1614c: add             lr, x0, x17
    //     0xc16150: ldr             lr, [x21, lr, lsl #3]
    //     0xc16154: blr             lr
    // 0xc16158: r2 = LoadInt32Instr(r0)
    //     0xc16158: sbfx            x2, x0, #1, #0x1f
    //     0xc1615c: tbz             w0, #0, #0xc16164
    //     0xc16160: ldur            x2, [x0, #7]
    // 0xc16164: sub             x3, x2, #1
    // 0xc16168: ldur            x2, [fp, #-8]
    // 0xc1616c: and             x4, x2, x3
    // 0xc16170: r0 = BoxInt64Instr(r4)
    //     0xc16170: sbfiz           x0, x4, #1, #0x1f
    //     0xc16174: cmp             x4, x0, asr #1
    //     0xc16178: b.eq            #0xc16184
    //     0xc1617c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc16180: stur            x4, [x0, #7]
    // 0xc16184: LeaveFrame
    //     0xc16184: mov             SP, fp
    //     0xc16188: ldp             fp, lr, [SP], #0x10
    // 0xc1618c: ret
    //     0xc1618c: ret             
    // 0xc16190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16190: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16194: b               #0xc15ff8
  }
  void []=(QueueList<X0>, int, X0) {
    // ** addr: 0x8195a4, size: 0x294
    // 0x8195a4: EnterFrame
    //     0x8195a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8195a8: mov             fp, SP
    // 0x8195ac: AllocStack(0x30)
    //     0x8195ac: sub             SP, SP, #0x30
    // 0x8195b0: CheckStackOverflow
    //     0x8195b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8195b4: cmp             SP, x16
    //     0x8195b8: b.ls            #0x819830
    // 0x8195bc: ldr             x3, [fp, #0x20]
    // 0x8195c0: LoadField: r2 = r3->field_7
    //     0x8195c0: ldur            w2, [x3, #7]
    // 0x8195c4: DecompressPointer r2
    //     0x8195c4: add             x2, x2, HEAP, lsl #32
    // 0x8195c8: ldr             x0, [fp, #0x10]
    // 0x8195cc: r1 = Null
    //     0x8195cc: mov             x1, NULL
    // 0x8195d0: cmp             w2, NULL
    // 0x8195d4: b.eq            #0x8195f4
    // 0x8195d8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x8195d8: ldur            w4, [x2, #0x17]
    // 0x8195dc: DecompressPointer r4
    //     0x8195dc: add             x4, x4, HEAP, lsl #32
    // 0x8195e0: r8 = X0
    //     0x8195e0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x8195e4: LoadField: r9 = r4->field_7
    //     0x8195e4: ldur            x9, [x4, #7]
    // 0x8195e8: r3 = Null
    //     0x8195e8: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf8c0] Null
    //     0x8195ec: ldr             x3, [x3, #0x8c0]
    // 0x8195f0: blr             x9
    // 0x8195f4: ldr             x0, [fp, #0x18]
    // 0x8195f8: r1 = LoadInt32Instr(r0)
    //     0x8195f8: sbfx            x1, x0, #1, #0x1f
    //     0x8195fc: tbz             w0, #0, #0x819604
    //     0x819600: ldur            x1, [x0, #7]
    // 0x819604: stur            x1, [fp, #-8]
    // 0x819608: tbnz            x1, #0x3f, #0x81977c
    // 0x81960c: ldr             x16, [fp, #0x20]
    // 0x819610: str             x16, [SP]
    // 0x819614: r0 = length()
    //     0x819614: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0x819618: r1 = LoadInt32Instr(r0)
    //     0x819618: sbfx            x1, x0, #1, #0x1f
    //     0x81961c: tbz             w0, #0, #0x819624
    //     0x819620: ldur            x1, [x0, #7]
    // 0x819624: ldur            x2, [fp, #-8]
    // 0x819628: cmp             x2, x1
    // 0x81962c: b.ge            #0x819784
    // 0x819630: ldr             x3, [fp, #0x20]
    // 0x819634: LoadField: r4 = r3->field_b
    //     0x819634: ldur            w4, [x3, #0xb]
    // 0x819638: DecompressPointer r4
    //     0x819638: add             x4, x4, HEAP, lsl #32
    // 0x81963c: stur            x4, [fp, #-0x10]
    // 0x819640: r0 = LoadClassIdInstr(r3)
    //     0x819640: ldur            x0, [x3, #-1]
    //     0x819644: ubfx            x0, x0, #0xc, #0x14
    // 0x819648: r17 = 4221
    //     0x819648: mov             x17, #0x107d
    // 0x81964c: cmp             x0, x17
    // 0x819650: b.ne            #0x81966c
    // 0x819654: LoadField: r0 = r3->field_f
    //     0x819654: ldur            x0, [x3, #0xf]
    // 0x819658: mov             x16, x2
    // 0x81965c: mov             x2, x0
    // 0x819660: mov             x0, x16
    // 0x819664: mov             x1, x4
    // 0x819668: b               #0x8196dc
    // 0x81966c: LoadField: r0 = r3->field_1f
    //     0x81966c: ldur            w0, [x3, #0x1f]
    // 0x819670: DecompressPointer r0
    //     0x819670: add             x0, x0, HEAP, lsl #32
    // 0x819674: r1 = LoadClassIdInstr(r0)
    //     0x819674: ldur            x1, [x0, #-1]
    //     0x819678: ubfx            x1, x1, #0xc, #0x14
    // 0x81967c: r17 = 4221
    //     0x81967c: mov             x17, #0x107d
    // 0x819680: cmp             x1, x17
    // 0x819684: b.ne            #0x819694
    // 0x819688: LoadField: r1 = r0->field_f
    //     0x819688: ldur            x1, [x0, #0xf]
    // 0x81968c: mov             x0, x1
    // 0x819690: b               #0x8196cc
    // 0x819694: LoadField: r1 = r0->field_1f
    //     0x819694: ldur            w1, [x0, #0x1f]
    // 0x819698: DecompressPointer r1
    //     0x819698: add             x1, x1, HEAP, lsl #32
    // 0x81969c: r0 = LoadClassIdInstr(r1)
    //     0x81969c: ldur            x0, [x1, #-1]
    //     0x8196a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8196a4: r17 = 4221
    //     0x8196a4: mov             x17, #0x107d
    // 0x8196a8: cmp             x0, x17
    // 0x8196ac: b.ne            #0x8196b8
    // 0x8196b0: LoadField: r0 = r1->field_f
    //     0x8196b0: ldur            x0, [x1, #0xf]
    // 0x8196b4: b               #0x8196cc
    // 0x8196b8: r0 = LoadClassIdInstr(r1)
    //     0x8196b8: ldur            x0, [x1, #-1]
    //     0x8196bc: ubfx            x0, x0, #0xc, #0x14
    // 0x8196c0: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x8196c0: sub             lr, x0, #0xfc8
    //     0x8196c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8196c8: blr             lr
    // 0x8196cc: mov             x2, x0
    // 0x8196d0: ldr             x3, [fp, #0x20]
    // 0x8196d4: ldur            x1, [fp, #-0x10]
    // 0x8196d8: ldur            x0, [fp, #-8]
    // 0x8196dc: add             x4, x2, x0
    // 0x8196e0: stur            x4, [fp, #-0x18]
    // 0x8196e4: LoadField: r0 = r3->field_b
    //     0x8196e4: ldur            w0, [x3, #0xb]
    // 0x8196e8: DecompressPointer r0
    //     0x8196e8: add             x0, x0, HEAP, lsl #32
    // 0x8196ec: r2 = LoadClassIdInstr(r0)
    //     0x8196ec: ldur            x2, [x0, #-1]
    //     0x8196f0: ubfx            x2, x2, #0xc, #0x14
    // 0x8196f4: str             x0, [SP]
    // 0x8196f8: mov             x0, x2
    // 0x8196fc: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8196fc: mov             x17, #0xf078
    //     0x819700: add             lr, x0, x17
    //     0x819704: ldr             lr, [x21, lr, lsl #3]
    //     0x819708: blr             lr
    // 0x81970c: r1 = LoadInt32Instr(r0)
    //     0x81970c: sbfx            x1, x0, #1, #0x1f
    //     0x819710: tbz             w0, #0, #0x819718
    //     0x819714: ldur            x1, [x0, #7]
    // 0x819718: sub             x0, x1, #1
    // 0x81971c: ldur            x1, [fp, #-0x18]
    // 0x819720: and             x2, x1, x0
    // 0x819724: r0 = BoxInt64Instr(r2)
    //     0x819724: sbfiz           x0, x2, #1, #0x1f
    //     0x819728: cmp             x2, x0, asr #1
    //     0x81972c: b.eq            #0x819738
    //     0x819730: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x819734: stur            x2, [x0, #7]
    // 0x819738: mov             x1, x0
    // 0x81973c: ldur            x0, [fp, #-0x10]
    // 0x819740: r2 = LoadClassIdInstr(r0)
    //     0x819740: ldur            x2, [x0, #-1]
    //     0x819744: ubfx            x2, x2, #0xc, #0x14
    // 0x819748: stp             x1, x0, [SP, #8]
    // 0x81974c: ldr             x16, [fp, #0x10]
    // 0x819750: str             x16, [SP]
    // 0x819754: mov             x0, x2
    // 0x819758: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0x819758: mov             x17, #0x8dc8
    //     0x81975c: movk            x17, #1, lsl #16
    //     0x819760: add             lr, x0, x17
    //     0x819764: ldr             lr, [x21, lr, lsl #3]
    //     0x819768: blr             lr
    // 0x81976c: r0 = Null
    //     0x81976c: mov             x0, NULL
    // 0x819770: LeaveFrame
    //     0x819770: mov             SP, fp
    //     0x819774: ldp             fp, lr, [SP], #0x10
    // 0x819778: ret
    //     0x819778: ret             
    // 0x81977c: ldr             x3, [fp, #0x20]
    // 0x819780: b               #0x819788
    // 0x819784: ldr             x3, [fp, #0x20]
    // 0x819788: ldr             x0, [fp, #0x18]
    // 0x81978c: r1 = Null
    //     0x81978c: mov             x1, NULL
    // 0x819790: r2 = 10
    //     0x819790: mov             x2, #0xa
    // 0x819794: r0 = AllocateArray()
    //     0x819794: bl              #0x13df928  ; AllocateArrayStub
    // 0x819798: stur            x0, [fp, #-0x10]
    // 0x81979c: r16 = "Index "
    //     0x81979c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf8d0] "Index "
    //     0x8197a0: ldr             x16, [x16, #0x8d0]
    // 0x8197a4: StoreField: r0->field_f = r16
    //     0x8197a4: stur            w16, [x0, #0xf]
    // 0x8197a8: ldr             x1, [fp, #0x18]
    // 0x8197ac: StoreField: r0->field_13 = r1
    //     0x8197ac: stur            w1, [x0, #0x13]
    // 0x8197b0: r16 = " must be in the range [0.."
    //     0x8197b0: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf8d8] " must be in the range [0.."
    //     0x8197b4: ldr             x16, [x16, #0x8d8]
    // 0x8197b8: ArrayStore: r0[0] = r16  ; List_4
    //     0x8197b8: stur            w16, [x0, #0x17]
    // 0x8197bc: ldr             x16, [fp, #0x20]
    // 0x8197c0: str             x16, [SP]
    // 0x8197c4: r0 = length()
    //     0x8197c4: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0x8197c8: ldur            x1, [fp, #-0x10]
    // 0x8197cc: ArrayStore: r1[3] = r0  ; List_4
    //     0x8197cc: add             x25, x1, #0x1b
    //     0x8197d0: str             w0, [x25]
    //     0x8197d4: tbz             w0, #0, #0x8197f0
    //     0x8197d8: ldurb           w16, [x1, #-1]
    //     0x8197dc: ldurb           w17, [x0, #-1]
    //     0x8197e0: and             x16, x17, x16, lsr #2
    //     0x8197e4: tst             x16, HEAP, lsr #32
    //     0x8197e8: b.eq            #0x8197f0
    //     0x8197ec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8197f0: ldur            x0, [fp, #-0x10]
    // 0x8197f4: r16 = ")."
    //     0x8197f4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16a78] ")."
    //     0x8197f8: ldr             x16, [x16, #0xa78]
    // 0x8197fc: StoreField: r0->field_1f = r16
    //     0x8197fc: stur            w16, [x0, #0x1f]
    // 0x819800: str             x0, [SP]
    // 0x819804: r0 = _interpolate()
    //     0x819804: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x819808: stur            x0, [fp, #-0x10]
    // 0x81980c: r0 = RangeError()
    //     0x81980c: bl              #0x7db570  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x819810: mov             x1, x0
    // 0x819814: ldur            x0, [fp, #-0x10]
    // 0x819818: ArrayStore: r1[0] = r0  ; List_4
    //     0x819818: stur            w0, [x1, #0x17]
    // 0x81981c: r0 = false
    //     0x81981c: add             x0, NULL, #0x30  ; false
    // 0x819820: StoreField: r1->field_b = r0
    //     0x819820: stur            w0, [x1, #0xb]
    // 0x819824: mov             x0, x1
    // 0x819828: r0 = Throw()
    //     0x819828: bl              #0x13ddb2c  ; ThrowStub
    // 0x81982c: brk             #0
    // 0x819830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x819830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x819834: b               #0x8195bc
  }
  void []=(QueueList<X0>, int, X0) {
    // ** addr: 0x819850, size: 0x94
    // 0x819850: EnterFrame
    //     0x819850: stp             fp, lr, [SP, #-0x10]!
    //     0x819854: mov             fp, SP
    // 0x819858: AllocStack(0x18)
    //     0x819858: sub             SP, SP, #0x18
    // 0x81985c: CheckStackOverflow
    //     0x81985c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x819860: cmp             SP, x16
    //     0x819864: b.ls            #0x8198c4
    // 0x819868: ldr             x0, [fp, #0x18]
    // 0x81986c: r2 = Null
    //     0x81986c: mov             x2, NULL
    // 0x819870: r1 = Null
    //     0x819870: mov             x1, NULL
    // 0x819874: branchIfSmi(r0, 0x81989c)
    //     0x819874: tbz             w0, #0, #0x81989c
    // 0x819878: r4 = LoadClassIdInstr(r0)
    //     0x819878: ldur            x4, [x0, #-1]
    //     0x81987c: ubfx            x4, x4, #0xc, #0x14
    // 0x819880: sub             x4, x4, #0x3c
    // 0x819884: cmp             x4, #1
    // 0x819888: b.ls            #0x81989c
    // 0x81988c: r8 = int
    //     0x81988c: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x819890: r3 = Null
    //     0x819890: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf8b0] Null
    //     0x819894: ldr             x3, [x3, #0x8b0]
    // 0x819898: r0 = int()
    //     0x819898: bl              #0x13ee980  ; IsType_int_Stub
    // 0x81989c: ldr             x16, [fp, #0x20]
    // 0x8198a0: ldr             lr, [fp, #0x18]
    // 0x8198a4: stp             lr, x16, [SP, #8]
    // 0x8198a8: ldr             x16, [fp, #0x10]
    // 0x8198ac: str             x16, [SP]
    // 0x8198b0: r0 = []=()
    //     0x8198b0: bl              #0x8195a4  ; [package:collection/src/queue_list.dart] QueueList::[]=
    // 0x8198b4: r0 = Null
    //     0x8198b4: mov             x0, NULL
    // 0x8198b8: LeaveFrame
    //     0x8198b8: mov             SP, fp
    //     0x8198bc: ldp             fp, lr, [SP], #0x10
    // 0x8198c0: ret
    //     0x8198c0: ret             
    // 0x8198c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8198c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8198c8: b               #0x819868
  }
  X0 [](QueueList<X0>, int) {
    // ** addr: 0x8198e4, size: 0x88
    // 0x8198e4: EnterFrame
    //     0x8198e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8198e8: mov             fp, SP
    // 0x8198ec: AllocStack(0x10)
    //     0x8198ec: sub             SP, SP, #0x10
    // 0x8198f0: CheckStackOverflow
    //     0x8198f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8198f4: cmp             SP, x16
    //     0x8198f8: b.ls            #0x81994c
    // 0x8198fc: ldr             x0, [fp, #0x10]
    // 0x819900: r2 = Null
    //     0x819900: mov             x2, NULL
    // 0x819904: r1 = Null
    //     0x819904: mov             x1, NULL
    // 0x819908: branchIfSmi(r0, 0x819930)
    //     0x819908: tbz             w0, #0, #0x819930
    // 0x81990c: r4 = LoadClassIdInstr(r0)
    //     0x81990c: ldur            x4, [x0, #-1]
    //     0x819910: ubfx            x4, x4, #0xc, #0x14
    // 0x819914: sub             x4, x4, #0x3c
    // 0x819918: cmp             x4, #1
    // 0x81991c: b.ls            #0x819930
    // 0x819920: r8 = int
    //     0x819920: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x819924: r3 = Null
    //     0x819924: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf8e0] Null
    //     0x819928: ldr             x3, [x3, #0x8e0]
    // 0x81992c: r0 = int()
    //     0x81992c: bl              #0x13ee980  ; IsType_int_Stub
    // 0x819930: ldr             x16, [fp, #0x18]
    // 0x819934: ldr             lr, [fp, #0x10]
    // 0x819938: stp             lr, x16, [SP]
    // 0x81993c: r0 = []()
    //     0x81993c: bl              #0x12b0e84  ; [package:collection/src/queue_list.dart] QueueList::[]
    // 0x819940: LeaveFrame
    //     0x819940: mov             SP, fp
    //     0x819944: ldp             fp, lr, [SP], #0x10
    // 0x819948: ret
    //     0x819948: ret             
    // 0x81994c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81994c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x819950: b               #0x8198fc
  }
  set _ length=(/* No info */) {
    // ** addr: 0x8263ec, size: 0x754
    // 0x8263ec: EnterFrame
    //     0x8263ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8263f0: mov             fp, SP
    // 0x8263f4: AllocStack(0x40)
    //     0x8263f4: sub             SP, SP, #0x40
    // 0x8263f8: SetupParameters(QueueList<X0> this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8263f8: stur            x1, [fp, #-8]
    //     0x8263fc: stur            x2, [fp, #-0x10]
    // 0x826400: CheckStackOverflow
    //     0x826400: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x826404: cmp             SP, x16
    //     0x826408: b.ls            #0x826b38
    // 0x82640c: tbnz            x2, #0x3f, #0x826a48
    // 0x826410: str             x1, [SP]
    // 0x826414: r0 = length()
    //     0x826414: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0x826418: r1 = LoadInt32Instr(r0)
    //     0x826418: sbfx            x1, x0, #1, #0x1f
    //     0x82641c: tbz             w0, #0, #0x826424
    //     0x826420: ldur            x1, [x0, #7]
    // 0x826424: ldur            x3, [fp, #-0x10]
    // 0x826428: cmp             x3, x1
    // 0x82642c: b.le            #0x8264f0
    // 0x826430: ldur            x4, [fp, #-8]
    // 0x826434: LoadField: r5 = r4->field_7
    //     0x826434: ldur            w5, [x4, #7]
    // 0x826438: DecompressPointer r5
    //     0x826438: add             x5, x5, HEAP, lsl #32
    // 0x82643c: mov             x2, x5
    // 0x826440: stur            x5, [fp, #-0x18]
    // 0x826444: r0 = Null
    //     0x826444: mov             x0, NULL
    // 0x826448: r1 = Null
    //     0x826448: mov             x1, NULL
    // 0x82644c: cmp             w2, NULL
    // 0x826450: b.eq            #0x8264e8
    // 0x826454: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x826454: ldur            w3, [x2, #0x17]
    // 0x826458: DecompressPointer r3
    //     0x826458: add             x3, x3, HEAP, lsl #32
    // 0x82645c: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x826460: cmp             w3, w16
    // 0x826464: b.eq            #0x8264e8
    // 0x826468: r16 = Object?
    //     0x826468: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x82646c: cmp             w3, w16
    // 0x826470: b.eq            #0x8264e8
    // 0x826474: r16 = void?
    //     0x826474: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x826478: cmp             w3, w16
    // 0x82647c: b.eq            #0x8264e8
    // 0x826480: tbnz            w0, #0, #0x82649c
    // 0x826484: r16 = int
    //     0x826484: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x826488: cmp             w3, w16
    // 0x82648c: b.eq            #0x8264e8
    // 0x826490: r16 = num
    //     0x826490: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x826494: cmp             w3, w16
    // 0x826498: b.eq            #0x8264e8
    // 0x82649c: r3 = SubtypeTestCache
    //     0x82649c: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf900] SubtypeTestCache
    //     0x8264a0: ldr             x3, [x3, #0x900]
    // 0x8264a4: r30 = Subtype6TestCacheStub
    //     0x8264a4: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0x8264a8: LoadField: r30 = r30->field_7
    //     0x8264a8: ldur            lr, [lr, #7]
    // 0x8264ac: blr             lr
    // 0x8264b0: cmp             w7, NULL
    // 0x8264b4: b.eq            #0x8264c0
    // 0x8264b8: tbnz            w7, #4, #0x8264e0
    // 0x8264bc: b               #0x8264e8
    // 0x8264c0: r8 = X0
    //     0x8264c0: add             x8, PP, #0xcf, lsl #12  ; [pp+0xcf908] TypeParameter: X0
    //     0x8264c4: ldr             x8, [x8, #0x908]
    // 0x8264c8: r3 = SubtypeTestCache
    //     0x8264c8: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf910] SubtypeTestCache
    //     0x8264cc: ldr             x3, [x3, #0x910]
    // 0x8264d0: r30 = InstanceOfStub
    //     0x8264d0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x8264d4: LoadField: r30 = r30->field_7
    //     0x8264d4: ldur            lr, [lr, #7]
    // 0x8264d8: blr             lr
    // 0x8264dc: b               #0x8264ec
    // 0x8264e0: r0 = false
    //     0x8264e0: add             x0, NULL, #0x30  ; false
    // 0x8264e4: b               #0x8264ec
    // 0x8264e8: r0 = true
    //     0x8264e8: add             x0, NULL, #0x20  ; true
    // 0x8264ec: tbnz            w0, #4, #0x826ac0
    // 0x8264f0: ldur            x2, [fp, #-0x10]
    // 0x8264f4: ldur            x16, [fp, #-8]
    // 0x8264f8: str             x16, [SP]
    // 0x8264fc: r0 = length()
    //     0x8264fc: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0x826500: r1 = LoadInt32Instr(r0)
    //     0x826500: sbfx            x1, x0, #1, #0x1f
    //     0x826504: tbz             w0, #0, #0x82650c
    //     0x826508: ldur            x1, [x0, #7]
    // 0x82650c: ldur            x2, [fp, #-0x10]
    // 0x826510: sub             x3, x2, x1
    // 0x826514: stur            x3, [fp, #-0x20]
    // 0x826518: tbnz            x3, #0x3f, #0x8266d8
    // 0x82651c: ldur            x1, [fp, #-8]
    // 0x826520: LoadField: r0 = r1->field_b
    //     0x826520: ldur            w0, [x1, #0xb]
    // 0x826524: DecompressPointer r0
    //     0x826524: add             x0, x0, HEAP, lsl #32
    // 0x826528: r4 = LoadClassIdInstr(r0)
    //     0x826528: ldur            x4, [x0, #-1]
    //     0x82652c: ubfx            x4, x4, #0xc, #0x14
    // 0x826530: str             x0, [SP]
    // 0x826534: mov             x0, x4
    // 0x826538: r0 = GDT[cid_x0 + 0xf078]()
    //     0x826538: mov             x17, #0xf078
    //     0x82653c: add             lr, x0, x17
    //     0x826540: ldr             lr, [x21, lr, lsl #3]
    //     0x826544: blr             lr
    // 0x826548: r1 = LoadInt32Instr(r0)
    //     0x826548: sbfx            x1, x0, #1, #0x1f
    //     0x82654c: tbz             w0, #0, #0x826554
    //     0x826550: ldur            x1, [x0, #7]
    // 0x826554: ldur            x0, [fp, #-0x10]
    // 0x826558: cmp             x1, x0
    // 0x82655c: b.gt            #0x82656c
    // 0x826560: ldur            x1, [fp, #-8]
    // 0x826564: mov             x2, x0
    // 0x826568: r0 = _preGrow()
    //     0x826568: bl              #0x826b40  ; [package:collection/src/queue_list.dart] QueueList::_preGrow
    // 0x82656c: ldur            x2, [fp, #-8]
    // 0x826570: r3 = LoadClassIdInstr(r2)
    //     0x826570: ldur            x3, [x2, #-1]
    //     0x826574: ubfx            x3, x3, #0xc, #0x14
    // 0x826578: stur            x3, [fp, #-0x28]
    // 0x82657c: r17 = 4221
    //     0x82657c: mov             x17, #0x107d
    // 0x826580: cmp             x3, x17
    // 0x826584: b.ne            #0x826598
    // 0x826588: ArrayLoad: r0 = r2[0]  ; List_8
    //     0x826588: ldur            x0, [x2, #0x17]
    // 0x82658c: mov             x1, x2
    // 0x826590: mov             x2, x3
    // 0x826594: b               #0x826600
    // 0x826598: LoadField: r0 = r2->field_1f
    //     0x826598: ldur            w0, [x2, #0x1f]
    // 0x82659c: DecompressPointer r0
    //     0x82659c: add             x0, x0, HEAP, lsl #32
    // 0x8265a0: r1 = LoadClassIdInstr(r0)
    //     0x8265a0: ldur            x1, [x0, #-1]
    //     0x8265a4: ubfx            x1, x1, #0xc, #0x14
    // 0x8265a8: r17 = 4221
    //     0x8265a8: mov             x17, #0x107d
    // 0x8265ac: cmp             x1, x17
    // 0x8265b0: b.ne            #0x8265c0
    // 0x8265b4: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x8265b4: ldur            x1, [x0, #0x17]
    // 0x8265b8: mov             x0, x1
    // 0x8265bc: b               #0x8265f8
    // 0x8265c0: LoadField: r1 = r0->field_1f
    //     0x8265c0: ldur            w1, [x0, #0x1f]
    // 0x8265c4: DecompressPointer r1
    //     0x8265c4: add             x1, x1, HEAP, lsl #32
    // 0x8265c8: r0 = LoadClassIdInstr(r1)
    //     0x8265c8: ldur            x0, [x1, #-1]
    //     0x8265cc: ubfx            x0, x0, #0xc, #0x14
    // 0x8265d0: r17 = 4221
    //     0x8265d0: mov             x17, #0x107d
    // 0x8265d4: cmp             x0, x17
    // 0x8265d8: b.ne            #0x8265e4
    // 0x8265dc: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x8265dc: ldur            x0, [x1, #0x17]
    // 0x8265e0: b               #0x8265f8
    // 0x8265e4: r0 = LoadClassIdInstr(r1)
    //     0x8265e4: ldur            x0, [x1, #-1]
    //     0x8265e8: ubfx            x0, x0, #0xc, #0x14
    // 0x8265ec: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x8265ec: sub             lr, x0, #0xfd0
    //     0x8265f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8265f4: blr             lr
    // 0x8265f8: ldur            x1, [fp, #-8]
    // 0x8265fc: ldur            x2, [fp, #-0x28]
    // 0x826600: ldur            x3, [fp, #-0x20]
    // 0x826604: add             x4, x0, x3
    // 0x826608: stur            x4, [fp, #-0x30]
    // 0x82660c: LoadField: r0 = r1->field_b
    //     0x82660c: ldur            w0, [x1, #0xb]
    // 0x826610: DecompressPointer r0
    //     0x826610: add             x0, x0, HEAP, lsl #32
    // 0x826614: r3 = LoadClassIdInstr(r0)
    //     0x826614: ldur            x3, [x0, #-1]
    //     0x826618: ubfx            x3, x3, #0xc, #0x14
    // 0x82661c: str             x0, [SP]
    // 0x826620: mov             x0, x3
    // 0x826624: r0 = GDT[cid_x0 + 0xf078]()
    //     0x826624: mov             x17, #0xf078
    //     0x826628: add             lr, x0, x17
    //     0x82662c: ldr             lr, [x21, lr, lsl #3]
    //     0x826630: blr             lr
    // 0x826634: r1 = LoadInt32Instr(r0)
    //     0x826634: sbfx            x1, x0, #1, #0x1f
    //     0x826638: tbz             w0, #0, #0x826640
    //     0x82663c: ldur            x1, [x0, #7]
    // 0x826640: sub             x0, x1, #1
    // 0x826644: ldur            x1, [fp, #-0x30]
    // 0x826648: and             x2, x1, x0
    // 0x82664c: ldur            x0, [fp, #-0x28]
    // 0x826650: r17 = 4221
    //     0x826650: mov             x17, #0x107d
    // 0x826654: cmp             x0, x17
    // 0x826658: b.ne            #0x826668
    // 0x82665c: ldur            x4, [fp, #-8]
    // 0x826660: ArrayStore: r4[0] = r2  ; List_8
    //     0x826660: stur            x2, [x4, #0x17]
    // 0x826664: b               #0x8266c8
    // 0x826668: ldur            x4, [fp, #-8]
    // 0x82666c: LoadField: r0 = r4->field_1f
    //     0x82666c: ldur            w0, [x4, #0x1f]
    // 0x826670: DecompressPointer r0
    //     0x826670: add             x0, x0, HEAP, lsl #32
    // 0x826674: r1 = LoadClassIdInstr(r0)
    //     0x826674: ldur            x1, [x0, #-1]
    //     0x826678: ubfx            x1, x1, #0xc, #0x14
    // 0x82667c: r17 = 4221
    //     0x82667c: mov             x17, #0x107d
    // 0x826680: cmp             x1, x17
    // 0x826684: b.ne            #0x826690
    // 0x826688: ArrayStore: r0[0] = r2  ; List_8
    //     0x826688: stur            x2, [x0, #0x17]
    // 0x82668c: b               #0x8266c8
    // 0x826690: LoadField: r1 = r0->field_1f
    //     0x826690: ldur            w1, [x0, #0x1f]
    // 0x826694: DecompressPointer r1
    //     0x826694: add             x1, x1, HEAP, lsl #32
    // 0x826698: r0 = LoadClassIdInstr(r1)
    //     0x826698: ldur            x0, [x1, #-1]
    //     0x82669c: ubfx            x0, x0, #0xc, #0x14
    // 0x8266a0: r17 = 4221
    //     0x8266a0: mov             x17, #0x107d
    // 0x8266a4: cmp             x0, x17
    // 0x8266a8: b.ne            #0x8266b4
    // 0x8266ac: ArrayStore: r1[0] = r2  ; List_8
    //     0x8266ac: stur            x2, [x1, #0x17]
    // 0x8266b0: b               #0x8266c8
    // 0x8266b4: r0 = LoadClassIdInstr(r1)
    //     0x8266b4: ldur            x0, [x1, #-1]
    //     0x8266b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8266bc: r0 = GDT[cid_x0 + -0xfc6]()
    //     0x8266bc: sub             lr, x0, #0xfc6
    //     0x8266c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8266c4: blr             lr
    // 0x8266c8: r0 = Null
    //     0x8266c8: mov             x0, NULL
    // 0x8266cc: LeaveFrame
    //     0x8266cc: mov             SP, fp
    //     0x8266d0: ldp             fp, lr, [SP], #0x10
    // 0x8266d4: ret
    //     0x8266d4: ret             
    // 0x8266d8: ldur            x4, [fp, #-8]
    // 0x8266dc: r2 = LoadClassIdInstr(r4)
    //     0x8266dc: ldur            x2, [x4, #-1]
    //     0x8266e0: ubfx            x2, x2, #0xc, #0x14
    // 0x8266e4: stur            x2, [fp, #-0x28]
    // 0x8266e8: r17 = 4221
    //     0x8266e8: mov             x17, #0x107d
    // 0x8266ec: cmp             x2, x17
    // 0x8266f0: b.ne            #0x826704
    // 0x8266f4: ArrayLoad: r0 = r4[0]  ; List_8
    //     0x8266f4: ldur            x0, [x4, #0x17]
    // 0x8266f8: mov             x1, x0
    // 0x8266fc: mov             x0, x3
    // 0x826700: b               #0x82676c
    // 0x826704: LoadField: r0 = r4->field_1f
    //     0x826704: ldur            w0, [x4, #0x1f]
    // 0x826708: DecompressPointer r0
    //     0x826708: add             x0, x0, HEAP, lsl #32
    // 0x82670c: r1 = LoadClassIdInstr(r0)
    //     0x82670c: ldur            x1, [x0, #-1]
    //     0x826710: ubfx            x1, x1, #0xc, #0x14
    // 0x826714: r17 = 4221
    //     0x826714: mov             x17, #0x107d
    // 0x826718: cmp             x1, x17
    // 0x82671c: b.ne            #0x82672c
    // 0x826720: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x826720: ldur            x1, [x0, #0x17]
    // 0x826724: mov             x0, x1
    // 0x826728: b               #0x826764
    // 0x82672c: LoadField: r1 = r0->field_1f
    //     0x82672c: ldur            w1, [x0, #0x1f]
    // 0x826730: DecompressPointer r1
    //     0x826730: add             x1, x1, HEAP, lsl #32
    // 0x826734: r0 = LoadClassIdInstr(r1)
    //     0x826734: ldur            x0, [x1, #-1]
    //     0x826738: ubfx            x0, x0, #0xc, #0x14
    // 0x82673c: r17 = 4221
    //     0x82673c: mov             x17, #0x107d
    // 0x826740: cmp             x0, x17
    // 0x826744: b.ne            #0x826750
    // 0x826748: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x826748: ldur            x0, [x1, #0x17]
    // 0x82674c: b               #0x826764
    // 0x826750: r0 = LoadClassIdInstr(r1)
    //     0x826750: ldur            x0, [x1, #-1]
    //     0x826754: ubfx            x0, x0, #0xc, #0x14
    // 0x826758: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x826758: sub             lr, x0, #0xfd0
    //     0x82675c: ldr             lr, [x21, lr, lsl #3]
    //     0x826760: blr             lr
    // 0x826764: mov             x1, x0
    // 0x826768: ldur            x0, [fp, #-0x20]
    // 0x82676c: add             x2, x1, x0
    // 0x826770: stur            x2, [fp, #-0x30]
    // 0x826774: tbnz            x2, #0x3f, #0x82683c
    // 0x826778: ldur            x3, [fp, #-8]
    // 0x82677c: ldur            x4, [fp, #-0x28]
    // 0x826780: LoadField: r5 = r3->field_b
    //     0x826780: ldur            w5, [x3, #0xb]
    // 0x826784: DecompressPointer r5
    //     0x826784: add             x5, x5, HEAP, lsl #32
    // 0x826788: stur            x5, [fp, #-0x38]
    // 0x82678c: r17 = 4221
    //     0x82678c: mov             x17, #0x107d
    // 0x826790: cmp             x4, x17
    // 0x826794: b.ne            #0x8267a8
    // 0x826798: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x826798: ldur            x0, [x3, #0x17]
    // 0x82679c: mov             x3, x0
    // 0x8267a0: mov             x1, x5
    // 0x8267a4: b               #0x826810
    // 0x8267a8: LoadField: r0 = r3->field_1f
    //     0x8267a8: ldur            w0, [x3, #0x1f]
    // 0x8267ac: DecompressPointer r0
    //     0x8267ac: add             x0, x0, HEAP, lsl #32
    // 0x8267b0: r1 = LoadClassIdInstr(r0)
    //     0x8267b0: ldur            x1, [x0, #-1]
    //     0x8267b4: ubfx            x1, x1, #0xc, #0x14
    // 0x8267b8: r17 = 4221
    //     0x8267b8: mov             x17, #0x107d
    // 0x8267bc: cmp             x1, x17
    // 0x8267c0: b.ne            #0x8267d0
    // 0x8267c4: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x8267c4: ldur            x1, [x0, #0x17]
    // 0x8267c8: mov             x0, x1
    // 0x8267cc: b               #0x826808
    // 0x8267d0: LoadField: r1 = r0->field_1f
    //     0x8267d0: ldur            w1, [x0, #0x1f]
    // 0x8267d4: DecompressPointer r1
    //     0x8267d4: add             x1, x1, HEAP, lsl #32
    // 0x8267d8: r0 = LoadClassIdInstr(r1)
    //     0x8267d8: ldur            x0, [x1, #-1]
    //     0x8267dc: ubfx            x0, x0, #0xc, #0x14
    // 0x8267e0: r17 = 4221
    //     0x8267e0: mov             x17, #0x107d
    // 0x8267e4: cmp             x0, x17
    // 0x8267e8: b.ne            #0x8267f4
    // 0x8267ec: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x8267ec: ldur            x0, [x1, #0x17]
    // 0x8267f0: b               #0x826808
    // 0x8267f4: r0 = LoadClassIdInstr(r1)
    //     0x8267f4: ldur            x0, [x1, #-1]
    //     0x8267f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8267fc: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x8267fc: sub             lr, x0, #0xfd0
    //     0x826800: ldr             lr, [x21, lr, lsl #3]
    //     0x826804: blr             lr
    // 0x826808: mov             x3, x0
    // 0x82680c: ldur            x1, [fp, #-0x38]
    // 0x826810: r0 = LoadClassIdInstr(r1)
    //     0x826810: ldur            x0, [x1, #-1]
    //     0x826814: ubfx            x0, x0, #0xc, #0x14
    // 0x826818: ldur            x2, [fp, #-0x30]
    // 0x82681c: r5 = Null
    //     0x82681c: mov             x5, NULL
    // 0x826820: r0 = GDT[cid_x0 + 0x187dd]()
    //     0x826820: mov             x17, #0x87dd
    //     0x826824: movk            x17, #1, lsl #16
    //     0x826828: add             lr, x0, x17
    //     0x82682c: ldr             lr, [x21, lr, lsl #3]
    //     0x826830: blr             lr
    // 0x826834: ldur            x2, [fp, #-0x30]
    // 0x826838: b               #0x8269b0
    // 0x82683c: mov             x1, x2
    // 0x826840: ldur            x2, [fp, #-8]
    // 0x826844: ldur            x3, [fp, #-0x28]
    // 0x826848: LoadField: r0 = r2->field_b
    //     0x826848: ldur            w0, [x2, #0xb]
    // 0x82684c: DecompressPointer r0
    //     0x82684c: add             x0, x0, HEAP, lsl #32
    // 0x826850: r4 = LoadClassIdInstr(r0)
    //     0x826850: ldur            x4, [x0, #-1]
    //     0x826854: ubfx            x4, x4, #0xc, #0x14
    // 0x826858: str             x0, [SP]
    // 0x82685c: mov             x0, x4
    // 0x826860: r0 = GDT[cid_x0 + 0xf078]()
    //     0x826860: mov             x17, #0xf078
    //     0x826864: add             lr, x0, x17
    //     0x826868: ldr             lr, [x21, lr, lsl #3]
    //     0x82686c: blr             lr
    // 0x826870: r1 = LoadInt32Instr(r0)
    //     0x826870: sbfx            x1, x0, #1, #0x1f
    //     0x826874: tbz             w0, #0, #0x82687c
    //     0x826878: ldur            x1, [x0, #7]
    // 0x82687c: ldur            x0, [fp, #-0x30]
    // 0x826880: add             x2, x0, x1
    // 0x826884: ldur            x3, [fp, #-8]
    // 0x826888: stur            x2, [fp, #-0x20]
    // 0x82688c: LoadField: r4 = r3->field_b
    //     0x82688c: ldur            w4, [x3, #0xb]
    // 0x826890: DecompressPointer r4
    //     0x826890: add             x4, x4, HEAP, lsl #32
    // 0x826894: ldur            x5, [fp, #-0x28]
    // 0x826898: stur            x4, [fp, #-0x38]
    // 0x82689c: r17 = 4221
    //     0x82689c: mov             x17, #0x107d
    // 0x8268a0: cmp             x5, x17
    // 0x8268a4: b.ne            #0x8268bc
    // 0x8268a8: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x8268a8: ldur            x0, [x3, #0x17]
    // 0x8268ac: mov             x1, x4
    // 0x8268b0: mov             x4, x3
    // 0x8268b4: mov             x3, x0
    // 0x8268b8: b               #0x826928
    // 0x8268bc: LoadField: r0 = r3->field_1f
    //     0x8268bc: ldur            w0, [x3, #0x1f]
    // 0x8268c0: DecompressPointer r0
    //     0x8268c0: add             x0, x0, HEAP, lsl #32
    // 0x8268c4: r1 = LoadClassIdInstr(r0)
    //     0x8268c4: ldur            x1, [x0, #-1]
    //     0x8268c8: ubfx            x1, x1, #0xc, #0x14
    // 0x8268cc: r17 = 4221
    //     0x8268cc: mov             x17, #0x107d
    // 0x8268d0: cmp             x1, x17
    // 0x8268d4: b.ne            #0x8268e4
    // 0x8268d8: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x8268d8: ldur            x1, [x0, #0x17]
    // 0x8268dc: mov             x0, x1
    // 0x8268e0: b               #0x82691c
    // 0x8268e4: LoadField: r1 = r0->field_1f
    //     0x8268e4: ldur            w1, [x0, #0x1f]
    // 0x8268e8: DecompressPointer r1
    //     0x8268e8: add             x1, x1, HEAP, lsl #32
    // 0x8268ec: r0 = LoadClassIdInstr(r1)
    //     0x8268ec: ldur            x0, [x1, #-1]
    //     0x8268f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8268f4: r17 = 4221
    //     0x8268f4: mov             x17, #0x107d
    // 0x8268f8: cmp             x0, x17
    // 0x8268fc: b.ne            #0x826908
    // 0x826900: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x826900: ldur            x0, [x1, #0x17]
    // 0x826904: b               #0x82691c
    // 0x826908: r0 = LoadClassIdInstr(r1)
    //     0x826908: ldur            x0, [x1, #-1]
    //     0x82690c: ubfx            x0, x0, #0xc, #0x14
    // 0x826910: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x826910: sub             lr, x0, #0xfd0
    //     0x826914: ldr             lr, [x21, lr, lsl #3]
    //     0x826918: blr             lr
    // 0x82691c: mov             x3, x0
    // 0x826920: ldur            x4, [fp, #-8]
    // 0x826924: ldur            x1, [fp, #-0x38]
    // 0x826928: r0 = LoadClassIdInstr(r1)
    //     0x826928: ldur            x0, [x1, #-1]
    //     0x82692c: ubfx            x0, x0, #0xc, #0x14
    // 0x826930: r2 = 0
    //     0x826930: mov             x2, #0
    // 0x826934: r5 = Null
    //     0x826934: mov             x5, NULL
    // 0x826938: r0 = GDT[cid_x0 + 0x187dd]()
    //     0x826938: mov             x17, #0x87dd
    //     0x82693c: movk            x17, #1, lsl #16
    //     0x826940: add             lr, x0, x17
    //     0x826944: ldr             lr, [x21, lr, lsl #3]
    //     0x826948: blr             lr
    // 0x82694c: ldur            x1, [fp, #-8]
    // 0x826950: LoadField: r2 = r1->field_b
    //     0x826950: ldur            w2, [x1, #0xb]
    // 0x826954: DecompressPointer r2
    //     0x826954: add             x2, x2, HEAP, lsl #32
    // 0x826958: stur            x2, [fp, #-0x38]
    // 0x82695c: r0 = LoadClassIdInstr(r2)
    //     0x82695c: ldur            x0, [x2, #-1]
    //     0x826960: ubfx            x0, x0, #0xc, #0x14
    // 0x826964: str             x2, [SP]
    // 0x826968: r0 = GDT[cid_x0 + 0xf078]()
    //     0x826968: mov             x17, #0xf078
    //     0x82696c: add             lr, x0, x17
    //     0x826970: ldr             lr, [x21, lr, lsl #3]
    //     0x826974: blr             lr
    // 0x826978: r3 = LoadInt32Instr(r0)
    //     0x826978: sbfx            x3, x0, #1, #0x1f
    //     0x82697c: tbz             w0, #0, #0x826984
    //     0x826980: ldur            x3, [x0, #7]
    // 0x826984: ldur            x1, [fp, #-0x38]
    // 0x826988: r0 = LoadClassIdInstr(r1)
    //     0x826988: ldur            x0, [x1, #-1]
    //     0x82698c: ubfx            x0, x0, #0xc, #0x14
    // 0x826990: ldur            x2, [fp, #-0x20]
    // 0x826994: r5 = Null
    //     0x826994: mov             x5, NULL
    // 0x826998: r0 = GDT[cid_x0 + 0x187dd]()
    //     0x826998: mov             x17, #0x87dd
    //     0x82699c: movk            x17, #1, lsl #16
    //     0x8269a0: add             lr, x0, x17
    //     0x8269a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8269a8: blr             lr
    // 0x8269ac: ldur            x2, [fp, #-0x20]
    // 0x8269b0: ldur            x0, [fp, #-0x28]
    // 0x8269b4: r17 = 4221
    //     0x8269b4: mov             x17, #0x107d
    // 0x8269b8: cmp             x0, x17
    // 0x8269bc: b.ne            #0x8269cc
    // 0x8269c0: ldur            x0, [fp, #-8]
    // 0x8269c4: ArrayStore: r0[0] = r2  ; List_8
    //     0x8269c4: stur            x2, [x0, #0x17]
    // 0x8269c8: b               #0x826a38
    // 0x8269cc: ldur            x0, [fp, #-8]
    // 0x8269d0: LoadField: r1 = r0->field_1f
    //     0x8269d0: ldur            w1, [x0, #0x1f]
    // 0x8269d4: DecompressPointer r1
    //     0x8269d4: add             x1, x1, HEAP, lsl #32
    // 0x8269d8: r0 = LoadClassIdInstr(r1)
    //     0x8269d8: ldur            x0, [x1, #-1]
    //     0x8269dc: ubfx            x0, x0, #0xc, #0x14
    // 0x8269e0: r17 = 4221
    //     0x8269e0: mov             x17, #0x107d
    // 0x8269e4: cmp             x0, x17
    // 0x8269e8: b.ne            #0x8269f4
    // 0x8269ec: ArrayStore: r1[0] = r2  ; List_8
    //     0x8269ec: stur            x2, [x1, #0x17]
    // 0x8269f0: b               #0x826a38
    // 0x8269f4: LoadField: r0 = r1->field_1f
    //     0x8269f4: ldur            w0, [x1, #0x1f]
    // 0x8269f8: DecompressPointer r0
    //     0x8269f8: add             x0, x0, HEAP, lsl #32
    // 0x8269fc: r1 = LoadClassIdInstr(r0)
    //     0x8269fc: ldur            x1, [x0, #-1]
    //     0x826a00: ubfx            x1, x1, #0xc, #0x14
    // 0x826a04: r17 = 4221
    //     0x826a04: mov             x17, #0x107d
    // 0x826a08: cmp             x1, x17
    // 0x826a0c: b.ne            #0x826a18
    // 0x826a10: ArrayStore: r0[0] = r2  ; List_8
    //     0x826a10: stur            x2, [x0, #0x17]
    // 0x826a14: b               #0x826a38
    // 0x826a18: r1 = LoadClassIdInstr(r0)
    //     0x826a18: ldur            x1, [x0, #-1]
    //     0x826a1c: ubfx            x1, x1, #0xc, #0x14
    // 0x826a20: mov             x16, x0
    // 0x826a24: mov             x0, x1
    // 0x826a28: mov             x1, x16
    // 0x826a2c: r0 = GDT[cid_x0 + -0xfc6]()
    //     0x826a2c: sub             lr, x0, #0xfc6
    //     0x826a30: ldr             lr, [x21, lr, lsl #3]
    //     0x826a34: blr             lr
    // 0x826a38: r0 = Null
    //     0x826a38: mov             x0, NULL
    // 0x826a3c: LeaveFrame
    //     0x826a3c: mov             SP, fp
    //     0x826a40: ldp             fp, lr, [SP], #0x10
    // 0x826a44: ret
    //     0x826a44: ret             
    // 0x826a48: mov             x0, x2
    // 0x826a4c: r1 = Null
    //     0x826a4c: mov             x1, NULL
    // 0x826a50: r2 = 6
    //     0x826a50: mov             x2, #6
    // 0x826a54: r0 = AllocateArray()
    //     0x826a54: bl              #0x13df928  ; AllocateArrayStub
    // 0x826a58: mov             x2, x0
    // 0x826a5c: r16 = "Length "
    //     0x826a5c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf918] "Length "
    //     0x826a60: ldr             x16, [x16, #0x918]
    // 0x826a64: StoreField: r2->field_f = r16
    //     0x826a64: stur            w16, [x2, #0xf]
    // 0x826a68: ldur            x3, [fp, #-0x10]
    // 0x826a6c: r0 = BoxInt64Instr(r3)
    //     0x826a6c: sbfiz           x0, x3, #1, #0x1f
    //     0x826a70: cmp             x3, x0, asr #1
    //     0x826a74: b.eq            #0x826a80
    //     0x826a78: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x826a7c: stur            x3, [x0, #7]
    // 0x826a80: StoreField: r2->field_13 = r0
    //     0x826a80: stur            w0, [x2, #0x13]
    // 0x826a84: r16 = " may not be negative."
    //     0x826a84: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf920] " may not be negative."
    //     0x826a88: ldr             x16, [x16, #0x920]
    // 0x826a8c: ArrayStore: r2[0] = r16  ; List_4
    //     0x826a8c: stur            w16, [x2, #0x17]
    // 0x826a90: str             x2, [SP]
    // 0x826a94: r0 = _interpolate()
    //     0x826a94: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x826a98: stur            x0, [fp, #-8]
    // 0x826a9c: r0 = RangeError()
    //     0x826a9c: bl              #0x7db570  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x826aa0: mov             x1, x0
    // 0x826aa4: ldur            x0, [fp, #-8]
    // 0x826aa8: ArrayStore: r1[0] = r0  ; List_4
    //     0x826aa8: stur            w0, [x1, #0x17]
    // 0x826aac: r0 = false
    //     0x826aac: add             x0, NULL, #0x30  ; false
    // 0x826ab0: StoreField: r1->field_b = r0
    //     0x826ab0: stur            w0, [x1, #0xb]
    // 0x826ab4: mov             x0, x1
    // 0x826ab8: r0 = Throw()
    //     0x826ab8: bl              #0x13ddb2c  ; ThrowStub
    // 0x826abc: brk             #0
    // 0x826ac0: r1 = Null
    //     0x826ac0: mov             x1, NULL
    // 0x826ac4: r2 = 6
    //     0x826ac4: mov             x2, #6
    // 0x826ac8: r0 = AllocateArray()
    //     0x826ac8: bl              #0x13df928  ; AllocateArrayStub
    // 0x826acc: stur            x0, [fp, #-8]
    // 0x826ad0: r16 = "The length can only be increased when the element type is nullable, but the current element type is `"
    //     0x826ad0: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf928] "The length can only be increased when the element type is nullable, but the current element type is `"
    //     0x826ad4: ldr             x16, [x16, #0x928]
    // 0x826ad8: StoreField: r0->field_f = r16
    //     0x826ad8: stur            w16, [x0, #0xf]
    // 0x826adc: ldur            x2, [fp, #-0x18]
    // 0x826ae0: r1 = Null
    //     0x826ae0: mov             x1, NULL
    // 0x826ae4: r3 = X0
    //     0x826ae4: ldr             x3, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x826ae8: r30 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0x826ae8: add             lr, PP, #0x12, lsl #12  ; [pp+0x12e80] Stub: InstantiateTypeNonNullableClassTypeParameter (0x7c1258)
    //     0x826aec: ldr             lr, [lr, #0xe80]
    // 0x826af0: LoadField: r30 = r30->field_7
    //     0x826af0: ldur            lr, [lr, #7]
    // 0x826af4: blr             lr
    // 0x826af8: mov             x1, x0
    // 0x826afc: ldur            x0, [fp, #-8]
    // 0x826b00: StoreField: r0->field_13 = r1
    //     0x826b00: stur            w1, [x0, #0x13]
    // 0x826b04: r16 = "`."
    //     0x826b04: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf930] "`."
    //     0x826b08: ldr             x16, [x16, #0x930]
    // 0x826b0c: ArrayStore: r0[0] = r16  ; List_4
    //     0x826b0c: stur            w16, [x0, #0x17]
    // 0x826b10: str             x0, [SP]
    // 0x826b14: r0 = _interpolate()
    //     0x826b14: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x826b18: stur            x0, [fp, #-8]
    // 0x826b1c: r0 = UnsupportedError()
    //     0x826b1c: bl              #0x7d923c  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0x826b20: mov             x1, x0
    // 0x826b24: ldur            x0, [fp, #-8]
    // 0x826b28: StoreField: r1->field_b = r0
    //     0x826b28: stur            w0, [x1, #0xb]
    // 0x826b2c: mov             x0, x1
    // 0x826b30: r0 = Throw()
    //     0x826b30: bl              #0x13ddb2c  ; ThrowStub
    // 0x826b34: brk             #0
    // 0x826b38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826b38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826b3c: b               #0x82640c
  }
  _ _preGrow(/* No info */) {
    // ** addr: 0x826b40, size: 0x214
    // 0x826b40: EnterFrame
    //     0x826b40: stp             fp, lr, [SP, #-0x10]!
    //     0x826b44: mov             fp, SP
    // 0x826b48: AllocStack(0x18)
    //     0x826b48: sub             SP, SP, #0x18
    // 0x826b4c: SetupParameters(QueueList<X0> this /* r1 => r0, fp-0x10 */)
    //     0x826b4c: mov             x0, x1
    //     0x826b50: stur            x1, [fp, #-0x10]
    // 0x826b54: CheckStackOverflow
    //     0x826b54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x826b58: cmp             SP, x16
    //     0x826b5c: b.ls            #0x826d44
    // 0x826b60: asr             x1, x2, #1
    // 0x826b64: add             x3, x2, x1
    // 0x826b68: lsl             x1, x3, #1
    // 0x826b6c: sub             x2, x1, #1
    // 0x826b70: mov             x4, x2
    // 0x826b74: stur            x4, [fp, #-8]
    // 0x826b78: CheckStackOverflow
    //     0x826b78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x826b7c: cmp             SP, x16
    //     0x826b80: b.ls            #0x826d4c
    // 0x826b84: sub             x1, x4, #1
    // 0x826b88: and             x2, x4, x1
    // 0x826b8c: cbz             x2, #0x826b98
    // 0x826b90: mov             x4, x2
    // 0x826b94: b               #0x826b74
    // 0x826b98: LoadField: r2 = r0->field_7
    //     0x826b98: ldur            w2, [x0, #7]
    // 0x826b9c: DecompressPointer r2
    //     0x826b9c: add             x2, x2, HEAP, lsl #32
    // 0x826ba0: r1 = Null
    //     0x826ba0: mov             x1, NULL
    // 0x826ba4: r3 = <X0?>
    //     0x826ba4: ldr             x3, [PP, #0xbf8]  ; [pp+0xbf8] TypeArguments: <X0?>
    // 0x826ba8: r0 = Null
    //     0x826ba8: mov             x0, NULL
    // 0x826bac: cmp             x2, x0
    // 0x826bb0: b.eq            #0x826bc0
    // 0x826bb4: r30 = InstantiateTypeArgumentsMayShareInstantiatorTAStub
    //     0x826bb4: ldr             lr, [PP, #0xc00]  ; [pp+0xc00] Stub: InstantiateTypeArgumentsMayShareInstantiatorTA (0x7c0e60)
    // 0x826bb8: LoadField: r30 = r30->field_7
    //     0x826bb8: ldur            lr, [lr, #7]
    // 0x826bbc: blr             lr
    // 0x826bc0: mov             x3, x0
    // 0x826bc4: ldur            x2, [fp, #-8]
    // 0x826bc8: r0 = BoxInt64Instr(r2)
    //     0x826bc8: sbfiz           x0, x2, #1, #0x1f
    //     0x826bcc: cmp             x2, x0, asr #1
    //     0x826bd0: b.eq            #0x826bdc
    //     0x826bd4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x826bd8: stur            x2, [x0, #7]
    // 0x826bdc: mov             x1, x3
    // 0x826be0: mov             x2, x0
    // 0x826be4: r0 = AllocateArray()
    //     0x826be4: bl              #0x13df928  ; AllocateArrayStub
    // 0x826be8: ldur            x1, [fp, #-0x10]
    // 0x826bec: mov             x2, x0
    // 0x826bf0: stur            x0, [fp, #-0x18]
    // 0x826bf4: r0 = _writeToList()
    //     0x826bf4: bl              #0x826d54  ; [package:collection/src/queue_list.dart] QueueList::_writeToList
    // 0x826bf8: ldur            x3, [fp, #-0x10]
    // 0x826bfc: r4 = LoadClassIdInstr(r3)
    //     0x826bfc: ldur            x4, [x3, #-1]
    //     0x826c00: ubfx            x4, x4, #0xc, #0x14
    // 0x826c04: stur            x4, [fp, #-8]
    // 0x826c08: r17 = 4221
    //     0x826c08: mov             x17, #0x107d
    // 0x826c0c: cmp             x4, x17
    // 0x826c10: b.ne            #0x826c24
    // 0x826c14: ArrayStore: r3[0] = r0  ; List_8
    //     0x826c14: stur            x0, [x3, #0x17]
    // 0x826c18: mov             x1, x3
    // 0x826c1c: mov             x2, x4
    // 0x826c20: b               #0x826ca0
    // 0x826c24: LoadField: r1 = r3->field_1f
    //     0x826c24: ldur            w1, [x3, #0x1f]
    // 0x826c28: DecompressPointer r1
    //     0x826c28: add             x1, x1, HEAP, lsl #32
    // 0x826c2c: r2 = LoadClassIdInstr(r1)
    //     0x826c2c: ldur            x2, [x1, #-1]
    //     0x826c30: ubfx            x2, x2, #0xc, #0x14
    // 0x826c34: r17 = 4221
    //     0x826c34: mov             x17, #0x107d
    // 0x826c38: cmp             x2, x17
    // 0x826c3c: b.ne            #0x826c48
    // 0x826c40: ArrayStore: r1[0] = r0  ; List_8
    //     0x826c40: stur            x0, [x1, #0x17]
    // 0x826c44: b               #0x826c98
    // 0x826c48: LoadField: r2 = r1->field_1f
    //     0x826c48: ldur            w2, [x1, #0x1f]
    // 0x826c4c: DecompressPointer r2
    //     0x826c4c: add             x2, x2, HEAP, lsl #32
    // 0x826c50: r1 = LoadClassIdInstr(r2)
    //     0x826c50: ldur            x1, [x2, #-1]
    //     0x826c54: ubfx            x1, x1, #0xc, #0x14
    // 0x826c58: r17 = 4221
    //     0x826c58: mov             x17, #0x107d
    // 0x826c5c: cmp             x1, x17
    // 0x826c60: b.ne            #0x826c6c
    // 0x826c64: ArrayStore: r2[0] = r0  ; List_8
    //     0x826c64: stur            x0, [x2, #0x17]
    // 0x826c68: b               #0x826c98
    // 0x826c6c: r1 = LoadClassIdInstr(r2)
    //     0x826c6c: ldur            x1, [x2, #-1]
    //     0x826c70: ubfx            x1, x1, #0xc, #0x14
    // 0x826c74: mov             x16, x2
    // 0x826c78: mov             x2, x1
    // 0x826c7c: mov             x1, x16
    // 0x826c80: mov             x16, x0
    // 0x826c84: mov             x0, x2
    // 0x826c88: mov             x2, x16
    // 0x826c8c: r0 = GDT[cid_x0 + -0xfc6]()
    //     0x826c8c: sub             lr, x0, #0xfc6
    //     0x826c90: ldr             lr, [x21, lr, lsl #3]
    //     0x826c94: blr             lr
    // 0x826c98: ldur            x1, [fp, #-0x10]
    // 0x826c9c: ldur            x2, [fp, #-8]
    // 0x826ca0: ldur            x0, [fp, #-0x18]
    // 0x826ca4: StoreField: r1->field_b = r0
    //     0x826ca4: stur            w0, [x1, #0xb]
    //     0x826ca8: ldurb           w16, [x1, #-1]
    //     0x826cac: ldurb           w17, [x0, #-1]
    //     0x826cb0: and             x16, x17, x16, lsr #2
    //     0x826cb4: tst             x16, HEAP, lsr #32
    //     0x826cb8: b.eq            #0x826cc0
    //     0x826cbc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x826cc0: r17 = 4221
    //     0x826cc0: mov             x17, #0x107d
    // 0x826cc4: cmp             x2, x17
    // 0x826cc8: b.ne            #0x826cd4
    // 0x826ccc: StoreField: r1->field_f = rZR
    //     0x826ccc: stur            xzr, [x1, #0xf]
    // 0x826cd0: b               #0x826d34
    // 0x826cd4: LoadField: r0 = r1->field_1f
    //     0x826cd4: ldur            w0, [x1, #0x1f]
    // 0x826cd8: DecompressPointer r0
    //     0x826cd8: add             x0, x0, HEAP, lsl #32
    // 0x826cdc: r1 = LoadClassIdInstr(r0)
    //     0x826cdc: ldur            x1, [x0, #-1]
    //     0x826ce0: ubfx            x1, x1, #0xc, #0x14
    // 0x826ce4: r17 = 4221
    //     0x826ce4: mov             x17, #0x107d
    // 0x826ce8: cmp             x1, x17
    // 0x826cec: b.ne            #0x826cf8
    // 0x826cf0: StoreField: r0->field_f = rZR
    //     0x826cf0: stur            xzr, [x0, #0xf]
    // 0x826cf4: b               #0x826d34
    // 0x826cf8: LoadField: r1 = r0->field_1f
    //     0x826cf8: ldur            w1, [x0, #0x1f]
    // 0x826cfc: DecompressPointer r1
    //     0x826cfc: add             x1, x1, HEAP, lsl #32
    // 0x826d00: r0 = LoadClassIdInstr(r1)
    //     0x826d00: ldur            x0, [x1, #-1]
    //     0x826d04: ubfx            x0, x0, #0xc, #0x14
    // 0x826d08: r17 = 4221
    //     0x826d08: mov             x17, #0x107d
    // 0x826d0c: cmp             x0, x17
    // 0x826d10: b.ne            #0x826d1c
    // 0x826d14: StoreField: r1->field_f = rZR
    //     0x826d14: stur            xzr, [x1, #0xf]
    // 0x826d18: b               #0x826d34
    // 0x826d1c: r0 = LoadClassIdInstr(r1)
    //     0x826d1c: ldur            x0, [x1, #-1]
    //     0x826d20: ubfx            x0, x0, #0xc, #0x14
    // 0x826d24: r2 = 0
    //     0x826d24: mov             x2, #0
    // 0x826d28: r0 = GDT[cid_x0 + -0xf9d]()
    //     0x826d28: sub             lr, x0, #0xf9d
    //     0x826d2c: ldr             lr, [x21, lr, lsl #3]
    //     0x826d30: blr             lr
    // 0x826d34: r0 = Null
    //     0x826d34: mov             x0, NULL
    // 0x826d38: LeaveFrame
    //     0x826d38: mov             SP, fp
    //     0x826d3c: ldp             fp, lr, [SP], #0x10
    // 0x826d40: ret
    //     0x826d40: ret             
    // 0x826d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826d44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826d48: b               #0x826b60
    // 0x826d4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x826d4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x826d50: b               #0x826b84
  }
  _ _writeToList(/* No info */) {
    // ** addr: 0x826d54, size: 0x664
    // 0x826d54: EnterFrame
    //     0x826d54: stp             fp, lr, [SP, #-0x10]!
    //     0x826d58: mov             fp, SP
    // 0x826d5c: AllocStack(0x38)
    //     0x826d5c: sub             SP, SP, #0x38
    // 0x826d60: SetupParameters(QueueList<X0> this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x826d60: mov             x3, x1
    //     0x826d64: stur            x1, [fp, #-0x10]
    //     0x826d68: stur            x2, [fp, #-0x18]
    // 0x826d6c: CheckStackOverflow
    //     0x826d6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x826d70: cmp             SP, x16
    //     0x826d74: b.ls            #0x8273b0
    // 0x826d78: r4 = LoadClassIdInstr(r3)
    //     0x826d78: ldur            x4, [x3, #-1]
    //     0x826d7c: ubfx            x4, x4, #0xc, #0x14
    // 0x826d80: stur            x4, [fp, #-8]
    // 0x826d84: r17 = 4221
    //     0x826d84: mov             x17, #0x107d
    // 0x826d88: cmp             x4, x17
    // 0x826d8c: b.ne            #0x826da0
    // 0x826d90: LoadField: r0 = r3->field_f
    //     0x826d90: ldur            x0, [x3, #0xf]
    // 0x826d94: mov             x3, x0
    // 0x826d98: mov             x2, x4
    // 0x826d9c: b               #0x826e08
    // 0x826da0: LoadField: r0 = r3->field_1f
    //     0x826da0: ldur            w0, [x3, #0x1f]
    // 0x826da4: DecompressPointer r0
    //     0x826da4: add             x0, x0, HEAP, lsl #32
    // 0x826da8: r1 = LoadClassIdInstr(r0)
    //     0x826da8: ldur            x1, [x0, #-1]
    //     0x826dac: ubfx            x1, x1, #0xc, #0x14
    // 0x826db0: r17 = 4221
    //     0x826db0: mov             x17, #0x107d
    // 0x826db4: cmp             x1, x17
    // 0x826db8: b.ne            #0x826dc8
    // 0x826dbc: LoadField: r1 = r0->field_f
    //     0x826dbc: ldur            x1, [x0, #0xf]
    // 0x826dc0: mov             x0, x1
    // 0x826dc4: b               #0x826e00
    // 0x826dc8: LoadField: r1 = r0->field_1f
    //     0x826dc8: ldur            w1, [x0, #0x1f]
    // 0x826dcc: DecompressPointer r1
    //     0x826dcc: add             x1, x1, HEAP, lsl #32
    // 0x826dd0: r0 = LoadClassIdInstr(r1)
    //     0x826dd0: ldur            x0, [x1, #-1]
    //     0x826dd4: ubfx            x0, x0, #0xc, #0x14
    // 0x826dd8: r17 = 4221
    //     0x826dd8: mov             x17, #0x107d
    // 0x826ddc: cmp             x0, x17
    // 0x826de0: b.ne            #0x826dec
    // 0x826de4: LoadField: r0 = r1->field_f
    //     0x826de4: ldur            x0, [x1, #0xf]
    // 0x826de8: b               #0x826e00
    // 0x826dec: r0 = LoadClassIdInstr(r1)
    //     0x826dec: ldur            x0, [x1, #-1]
    //     0x826df0: ubfx            x0, x0, #0xc, #0x14
    // 0x826df4: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x826df4: sub             lr, x0, #0xfc8
    //     0x826df8: ldr             lr, [x21, lr, lsl #3]
    //     0x826dfc: blr             lr
    // 0x826e00: mov             x3, x0
    // 0x826e04: ldur            x2, [fp, #-8]
    // 0x826e08: stur            x3, [fp, #-0x20]
    // 0x826e0c: r17 = 4221
    //     0x826e0c: mov             x17, #0x107d
    // 0x826e10: cmp             x2, x17
    // 0x826e14: b.ne            #0x826e2c
    // 0x826e18: ldur            x4, [fp, #-0x10]
    // 0x826e1c: ArrayLoad: r0 = r4[0]  ; List_8
    //     0x826e1c: ldur            x0, [x4, #0x17]
    // 0x826e20: mov             x1, x0
    // 0x826e24: mov             x0, x3
    // 0x826e28: b               #0x826e98
    // 0x826e2c: ldur            x4, [fp, #-0x10]
    // 0x826e30: LoadField: r0 = r4->field_1f
    //     0x826e30: ldur            w0, [x4, #0x1f]
    // 0x826e34: DecompressPointer r0
    //     0x826e34: add             x0, x0, HEAP, lsl #32
    // 0x826e38: r1 = LoadClassIdInstr(r0)
    //     0x826e38: ldur            x1, [x0, #-1]
    //     0x826e3c: ubfx            x1, x1, #0xc, #0x14
    // 0x826e40: r17 = 4221
    //     0x826e40: mov             x17, #0x107d
    // 0x826e44: cmp             x1, x17
    // 0x826e48: b.ne            #0x826e58
    // 0x826e4c: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x826e4c: ldur            x1, [x0, #0x17]
    // 0x826e50: mov             x0, x1
    // 0x826e54: b               #0x826e90
    // 0x826e58: LoadField: r1 = r0->field_1f
    //     0x826e58: ldur            w1, [x0, #0x1f]
    // 0x826e5c: DecompressPointer r1
    //     0x826e5c: add             x1, x1, HEAP, lsl #32
    // 0x826e60: r0 = LoadClassIdInstr(r1)
    //     0x826e60: ldur            x0, [x1, #-1]
    //     0x826e64: ubfx            x0, x0, #0xc, #0x14
    // 0x826e68: r17 = 4221
    //     0x826e68: mov             x17, #0x107d
    // 0x826e6c: cmp             x0, x17
    // 0x826e70: b.ne            #0x826e7c
    // 0x826e74: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x826e74: ldur            x0, [x1, #0x17]
    // 0x826e78: b               #0x826e90
    // 0x826e7c: r0 = LoadClassIdInstr(r1)
    //     0x826e7c: ldur            x0, [x1, #-1]
    //     0x826e80: ubfx            x0, x0, #0xc, #0x14
    // 0x826e84: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x826e84: sub             lr, x0, #0xfd0
    //     0x826e88: ldr             lr, [x21, lr, lsl #3]
    //     0x826e8c: blr             lr
    // 0x826e90: mov             x1, x0
    // 0x826e94: ldur            x0, [fp, #-0x20]
    // 0x826e98: cmp             x0, x1
    // 0x826e9c: b.gt            #0x8270a0
    // 0x826ea0: ldur            x2, [fp, #-8]
    // 0x826ea4: r17 = 4221
    //     0x826ea4: mov             x17, #0x107d
    // 0x826ea8: cmp             x2, x17
    // 0x826eac: b.ne            #0x826ec0
    // 0x826eb0: ldur            x3, [fp, #-0x10]
    // 0x826eb4: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x826eb4: ldur            x0, [x3, #0x17]
    // 0x826eb8: mov             x3, x0
    // 0x826ebc: b               #0x826f2c
    // 0x826ec0: ldur            x3, [fp, #-0x10]
    // 0x826ec4: LoadField: r0 = r3->field_1f
    //     0x826ec4: ldur            w0, [x3, #0x1f]
    // 0x826ec8: DecompressPointer r0
    //     0x826ec8: add             x0, x0, HEAP, lsl #32
    // 0x826ecc: r1 = LoadClassIdInstr(r0)
    //     0x826ecc: ldur            x1, [x0, #-1]
    //     0x826ed0: ubfx            x1, x1, #0xc, #0x14
    // 0x826ed4: r17 = 4221
    //     0x826ed4: mov             x17, #0x107d
    // 0x826ed8: cmp             x1, x17
    // 0x826edc: b.ne            #0x826eec
    // 0x826ee0: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x826ee0: ldur            x1, [x0, #0x17]
    // 0x826ee4: mov             x0, x1
    // 0x826ee8: b               #0x826f24
    // 0x826eec: LoadField: r1 = r0->field_1f
    //     0x826eec: ldur            w1, [x0, #0x1f]
    // 0x826ef0: DecompressPointer r1
    //     0x826ef0: add             x1, x1, HEAP, lsl #32
    // 0x826ef4: r0 = LoadClassIdInstr(r1)
    //     0x826ef4: ldur            x0, [x1, #-1]
    //     0x826ef8: ubfx            x0, x0, #0xc, #0x14
    // 0x826efc: r17 = 4221
    //     0x826efc: mov             x17, #0x107d
    // 0x826f00: cmp             x0, x17
    // 0x826f04: b.ne            #0x826f10
    // 0x826f08: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x826f08: ldur            x0, [x1, #0x17]
    // 0x826f0c: b               #0x826f24
    // 0x826f10: r0 = LoadClassIdInstr(r1)
    //     0x826f10: ldur            x0, [x1, #-1]
    //     0x826f14: ubfx            x0, x0, #0xc, #0x14
    // 0x826f18: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x826f18: sub             lr, x0, #0xfd0
    //     0x826f1c: ldr             lr, [x21, lr, lsl #3]
    //     0x826f20: blr             lr
    // 0x826f24: mov             x3, x0
    // 0x826f28: ldur            x2, [fp, #-8]
    // 0x826f2c: stur            x3, [fp, #-0x20]
    // 0x826f30: r17 = 4221
    //     0x826f30: mov             x17, #0x107d
    // 0x826f34: cmp             x2, x17
    // 0x826f38: b.ne            #0x826f5c
    // 0x826f3c: ldur            x4, [fp, #-0x10]
    // 0x826f40: LoadField: r0 = r4->field_f
    //     0x826f40: ldur            x0, [x4, #0xf]
    // 0x826f44: mov             x16, x3
    // 0x826f48: mov             x3, x0
    // 0x826f4c: mov             x0, x16
    // 0x826f50: mov             x1, x2
    // 0x826f54: mov             x2, x4
    // 0x826f58: b               #0x826fd0
    // 0x826f5c: ldur            x4, [fp, #-0x10]
    // 0x826f60: LoadField: r0 = r4->field_1f
    //     0x826f60: ldur            w0, [x4, #0x1f]
    // 0x826f64: DecompressPointer r0
    //     0x826f64: add             x0, x0, HEAP, lsl #32
    // 0x826f68: r1 = LoadClassIdInstr(r0)
    //     0x826f68: ldur            x1, [x0, #-1]
    //     0x826f6c: ubfx            x1, x1, #0xc, #0x14
    // 0x826f70: r17 = 4221
    //     0x826f70: mov             x17, #0x107d
    // 0x826f74: cmp             x1, x17
    // 0x826f78: b.ne            #0x826f88
    // 0x826f7c: LoadField: r1 = r0->field_f
    //     0x826f7c: ldur            x1, [x0, #0xf]
    // 0x826f80: mov             x0, x1
    // 0x826f84: b               #0x826fc0
    // 0x826f88: LoadField: r1 = r0->field_1f
    //     0x826f88: ldur            w1, [x0, #0x1f]
    // 0x826f8c: DecompressPointer r1
    //     0x826f8c: add             x1, x1, HEAP, lsl #32
    // 0x826f90: r0 = LoadClassIdInstr(r1)
    //     0x826f90: ldur            x0, [x1, #-1]
    //     0x826f94: ubfx            x0, x0, #0xc, #0x14
    // 0x826f98: r17 = 4221
    //     0x826f98: mov             x17, #0x107d
    // 0x826f9c: cmp             x0, x17
    // 0x826fa0: b.ne            #0x826fac
    // 0x826fa4: LoadField: r0 = r1->field_f
    //     0x826fa4: ldur            x0, [x1, #0xf]
    // 0x826fa8: b               #0x826fc0
    // 0x826fac: r0 = LoadClassIdInstr(r1)
    //     0x826fac: ldur            x0, [x1, #-1]
    //     0x826fb0: ubfx            x0, x0, #0xc, #0x14
    // 0x826fb4: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x826fb4: sub             lr, x0, #0xfc8
    //     0x826fb8: ldr             lr, [x21, lr, lsl #3]
    //     0x826fbc: blr             lr
    // 0x826fc0: mov             x3, x0
    // 0x826fc4: ldur            x2, [fp, #-0x10]
    // 0x826fc8: ldur            x0, [fp, #-0x20]
    // 0x826fcc: ldur            x1, [fp, #-8]
    // 0x826fd0: sub             x4, x0, x3
    // 0x826fd4: stur            x4, [fp, #-0x30]
    // 0x826fd8: LoadField: r5 = r2->field_b
    //     0x826fd8: ldur            w5, [x2, #0xb]
    // 0x826fdc: DecompressPointer r5
    //     0x826fdc: add             x5, x5, HEAP, lsl #32
    // 0x826fe0: stur            x5, [fp, #-0x28]
    // 0x826fe4: r17 = 4221
    //     0x826fe4: mov             x17, #0x107d
    // 0x826fe8: cmp             x1, x17
    // 0x826fec: b.ne            #0x826ffc
    // 0x826ff0: LoadField: r0 = r2->field_f
    //     0x826ff0: ldur            x0, [x2, #0xf]
    // 0x826ff4: mov             x2, x0
    // 0x826ff8: b               #0x827060
    // 0x826ffc: LoadField: r0 = r2->field_1f
    //     0x826ffc: ldur            w0, [x2, #0x1f]
    // 0x827000: DecompressPointer r0
    //     0x827000: add             x0, x0, HEAP, lsl #32
    // 0x827004: r1 = LoadClassIdInstr(r0)
    //     0x827004: ldur            x1, [x0, #-1]
    //     0x827008: ubfx            x1, x1, #0xc, #0x14
    // 0x82700c: r17 = 4221
    //     0x82700c: mov             x17, #0x107d
    // 0x827010: cmp             x1, x17
    // 0x827014: b.ne            #0x827024
    // 0x827018: LoadField: r1 = r0->field_f
    //     0x827018: ldur            x1, [x0, #0xf]
    // 0x82701c: mov             x0, x1
    // 0x827020: b               #0x82705c
    // 0x827024: LoadField: r1 = r0->field_1f
    //     0x827024: ldur            w1, [x0, #0x1f]
    // 0x827028: DecompressPointer r1
    //     0x827028: add             x1, x1, HEAP, lsl #32
    // 0x82702c: r0 = LoadClassIdInstr(r1)
    //     0x82702c: ldur            x0, [x1, #-1]
    //     0x827030: ubfx            x0, x0, #0xc, #0x14
    // 0x827034: r17 = 4221
    //     0x827034: mov             x17, #0x107d
    // 0x827038: cmp             x0, x17
    // 0x82703c: b.ne            #0x827048
    // 0x827040: LoadField: r0 = r1->field_f
    //     0x827040: ldur            x0, [x1, #0xf]
    // 0x827044: b               #0x82705c
    // 0x827048: r0 = LoadClassIdInstr(r1)
    //     0x827048: ldur            x0, [x1, #-1]
    //     0x82704c: ubfx            x0, x0, #0xc, #0x14
    // 0x827050: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x827050: sub             lr, x0, #0xfc8
    //     0x827054: ldr             lr, [x21, lr, lsl #3]
    //     0x827058: blr             lr
    // 0x82705c: mov             x2, x0
    // 0x827060: r0 = BoxInt64Instr(r2)
    //     0x827060: sbfiz           x0, x2, #1, #0x1f
    //     0x827064: cmp             x2, x0, asr #1
    //     0x827068: b.eq            #0x827074
    //     0x82706c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x827070: stur            x2, [x0, #7]
    // 0x827074: str             x0, [SP]
    // 0x827078: ldur            x1, [fp, #-0x18]
    // 0x82707c: ldur            x3, [fp, #-0x30]
    // 0x827080: ldur            x5, [fp, #-0x28]
    // 0x827084: r2 = 0
    //     0x827084: mov             x2, #0
    // 0x827088: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0x827088: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0x82708c: r0 = setRange()
    //     0x82708c: bl              #0xa049fc  ; [dart:core] _List::setRange
    // 0x827090: ldur            x0, [fp, #-0x30]
    // 0x827094: LeaveFrame
    //     0x827094: mov             SP, fp
    //     0x827098: ldp             fp, lr, [SP], #0x10
    // 0x82709c: ret
    //     0x82709c: ret             
    // 0x8270a0: ldur            x2, [fp, #-0x10]
    // 0x8270a4: ldur            x1, [fp, #-8]
    // 0x8270a8: LoadField: r0 = r2->field_b
    //     0x8270a8: ldur            w0, [x2, #0xb]
    // 0x8270ac: DecompressPointer r0
    //     0x8270ac: add             x0, x0, HEAP, lsl #32
    // 0x8270b0: r3 = LoadClassIdInstr(r0)
    //     0x8270b0: ldur            x3, [x0, #-1]
    //     0x8270b4: ubfx            x3, x3, #0xc, #0x14
    // 0x8270b8: str             x0, [SP]
    // 0x8270bc: mov             x0, x3
    // 0x8270c0: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8270c0: mov             x17, #0xf078
    //     0x8270c4: add             lr, x0, x17
    //     0x8270c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8270cc: blr             lr
    // 0x8270d0: mov             x3, x0
    // 0x8270d4: ldur            x2, [fp, #-8]
    // 0x8270d8: stur            x3, [fp, #-0x28]
    // 0x8270dc: r17 = 4221
    //     0x8270dc: mov             x17, #0x107d
    // 0x8270e0: cmp             x2, x17
    // 0x8270e4: b.ne            #0x827100
    // 0x8270e8: ldur            x4, [fp, #-0x10]
    // 0x8270ec: LoadField: r0 = r4->field_f
    //     0x8270ec: ldur            x0, [x4, #0xf]
    // 0x8270f0: mov             x1, x0
    // 0x8270f4: mov             x0, x3
    // 0x8270f8: mov             x3, x4
    // 0x8270fc: b               #0x827174
    // 0x827100: ldur            x4, [fp, #-0x10]
    // 0x827104: LoadField: r0 = r4->field_1f
    //     0x827104: ldur            w0, [x4, #0x1f]
    // 0x827108: DecompressPointer r0
    //     0x827108: add             x0, x0, HEAP, lsl #32
    // 0x82710c: r1 = LoadClassIdInstr(r0)
    //     0x82710c: ldur            x1, [x0, #-1]
    //     0x827110: ubfx            x1, x1, #0xc, #0x14
    // 0x827114: r17 = 4221
    //     0x827114: mov             x17, #0x107d
    // 0x827118: cmp             x1, x17
    // 0x82711c: b.ne            #0x82712c
    // 0x827120: LoadField: r1 = r0->field_f
    //     0x827120: ldur            x1, [x0, #0xf]
    // 0x827124: mov             x0, x1
    // 0x827128: b               #0x827164
    // 0x82712c: LoadField: r1 = r0->field_1f
    //     0x82712c: ldur            w1, [x0, #0x1f]
    // 0x827130: DecompressPointer r1
    //     0x827130: add             x1, x1, HEAP, lsl #32
    // 0x827134: r0 = LoadClassIdInstr(r1)
    //     0x827134: ldur            x0, [x1, #-1]
    //     0x827138: ubfx            x0, x0, #0xc, #0x14
    // 0x82713c: r17 = 4221
    //     0x82713c: mov             x17, #0x107d
    // 0x827140: cmp             x0, x17
    // 0x827144: b.ne            #0x827150
    // 0x827148: LoadField: r0 = r1->field_f
    //     0x827148: ldur            x0, [x1, #0xf]
    // 0x82714c: b               #0x827164
    // 0x827150: r0 = LoadClassIdInstr(r1)
    //     0x827150: ldur            x0, [x1, #-1]
    //     0x827154: ubfx            x0, x0, #0xc, #0x14
    // 0x827158: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x827158: sub             lr, x0, #0xfc8
    //     0x82715c: ldr             lr, [x21, lr, lsl #3]
    //     0x827160: blr             lr
    // 0x827164: mov             x1, x0
    // 0x827168: ldur            x3, [fp, #-0x10]
    // 0x82716c: ldur            x0, [fp, #-0x28]
    // 0x827170: ldur            x2, [fp, #-8]
    // 0x827174: r4 = LoadInt32Instr(r0)
    //     0x827174: sbfx            x4, x0, #1, #0x1f
    //     0x827178: tbz             w0, #0, #0x827180
    //     0x82717c: ldur            x4, [x0, #7]
    // 0x827180: sub             x5, x4, x1
    // 0x827184: stur            x5, [fp, #-0x20]
    // 0x827188: LoadField: r4 = r3->field_b
    //     0x827188: ldur            w4, [x3, #0xb]
    // 0x82718c: DecompressPointer r4
    //     0x82718c: add             x4, x4, HEAP, lsl #32
    // 0x827190: stur            x4, [fp, #-0x28]
    // 0x827194: r17 = 4221
    //     0x827194: mov             x17, #0x107d
    // 0x827198: cmp             x2, x17
    // 0x82719c: b.ne            #0x8271b0
    // 0x8271a0: LoadField: r0 = r3->field_f
    //     0x8271a0: ldur            x0, [x3, #0xf]
    // 0x8271a4: mov             x4, x2
    // 0x8271a8: mov             x2, x0
    // 0x8271ac: b               #0x827218
    // 0x8271b0: LoadField: r0 = r3->field_1f
    //     0x8271b0: ldur            w0, [x3, #0x1f]
    // 0x8271b4: DecompressPointer r0
    //     0x8271b4: add             x0, x0, HEAP, lsl #32
    // 0x8271b8: r1 = LoadClassIdInstr(r0)
    //     0x8271b8: ldur            x1, [x0, #-1]
    //     0x8271bc: ubfx            x1, x1, #0xc, #0x14
    // 0x8271c0: r17 = 4221
    //     0x8271c0: mov             x17, #0x107d
    // 0x8271c4: cmp             x1, x17
    // 0x8271c8: b.ne            #0x8271d8
    // 0x8271cc: LoadField: r1 = r0->field_f
    //     0x8271cc: ldur            x1, [x0, #0xf]
    // 0x8271d0: mov             x0, x1
    // 0x8271d4: b               #0x827210
    // 0x8271d8: LoadField: r1 = r0->field_1f
    //     0x8271d8: ldur            w1, [x0, #0x1f]
    // 0x8271dc: DecompressPointer r1
    //     0x8271dc: add             x1, x1, HEAP, lsl #32
    // 0x8271e0: r0 = LoadClassIdInstr(r1)
    //     0x8271e0: ldur            x0, [x1, #-1]
    //     0x8271e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8271e8: r17 = 4221
    //     0x8271e8: mov             x17, #0x107d
    // 0x8271ec: cmp             x0, x17
    // 0x8271f0: b.ne            #0x8271fc
    // 0x8271f4: LoadField: r0 = r1->field_f
    //     0x8271f4: ldur            x0, [x1, #0xf]
    // 0x8271f8: b               #0x827210
    // 0x8271fc: r0 = LoadClassIdInstr(r1)
    //     0x8271fc: ldur            x0, [x1, #-1]
    //     0x827200: ubfx            x0, x0, #0xc, #0x14
    // 0x827204: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x827204: sub             lr, x0, #0xfc8
    //     0x827208: ldr             lr, [x21, lr, lsl #3]
    //     0x82720c: blr             lr
    // 0x827210: mov             x2, x0
    // 0x827214: ldur            x4, [fp, #-8]
    // 0x827218: r0 = BoxInt64Instr(r2)
    //     0x827218: sbfiz           x0, x2, #1, #0x1f
    //     0x82721c: cmp             x2, x0, asr #1
    //     0x827220: b.eq            #0x82722c
    //     0x827224: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x827228: stur            x2, [x0, #7]
    // 0x82722c: str             x0, [SP]
    // 0x827230: ldur            x1, [fp, #-0x18]
    // 0x827234: ldur            x3, [fp, #-0x20]
    // 0x827238: ldur            x5, [fp, #-0x28]
    // 0x82723c: r2 = 0
    //     0x82723c: mov             x2, #0
    // 0x827240: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0x827240: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0x827244: r0 = setRange()
    //     0x827244: bl              #0xa049fc  ; [dart:core] _List::setRange
    // 0x827248: ldur            x2, [fp, #-8]
    // 0x82724c: r17 = 4221
    //     0x82724c: mov             x17, #0x107d
    // 0x827250: cmp             x2, x17
    // 0x827254: b.ne            #0x827270
    // 0x827258: ldur            x3, [fp, #-0x10]
    // 0x82725c: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x82725c: ldur            x0, [x3, #0x17]
    // 0x827260: mov             x1, x0
    // 0x827264: mov             x4, x3
    // 0x827268: mov             x0, x2
    // 0x82726c: b               #0x8272e0
    // 0x827270: ldur            x3, [fp, #-0x10]
    // 0x827274: LoadField: r0 = r3->field_1f
    //     0x827274: ldur            w0, [x3, #0x1f]
    // 0x827278: DecompressPointer r0
    //     0x827278: add             x0, x0, HEAP, lsl #32
    // 0x82727c: r1 = LoadClassIdInstr(r0)
    //     0x82727c: ldur            x1, [x0, #-1]
    //     0x827280: ubfx            x1, x1, #0xc, #0x14
    // 0x827284: r17 = 4221
    //     0x827284: mov             x17, #0x107d
    // 0x827288: cmp             x1, x17
    // 0x82728c: b.ne            #0x82729c
    // 0x827290: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x827290: ldur            x1, [x0, #0x17]
    // 0x827294: mov             x0, x1
    // 0x827298: b               #0x8272d4
    // 0x82729c: LoadField: r1 = r0->field_1f
    //     0x82729c: ldur            w1, [x0, #0x1f]
    // 0x8272a0: DecompressPointer r1
    //     0x8272a0: add             x1, x1, HEAP, lsl #32
    // 0x8272a4: r0 = LoadClassIdInstr(r1)
    //     0x8272a4: ldur            x0, [x1, #-1]
    //     0x8272a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8272ac: r17 = 4221
    //     0x8272ac: mov             x17, #0x107d
    // 0x8272b0: cmp             x0, x17
    // 0x8272b4: b.ne            #0x8272c0
    // 0x8272b8: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x8272b8: ldur            x0, [x1, #0x17]
    // 0x8272bc: b               #0x8272d4
    // 0x8272c0: r0 = LoadClassIdInstr(r1)
    //     0x8272c0: ldur            x0, [x1, #-1]
    //     0x8272c4: ubfx            x0, x0, #0xc, #0x14
    // 0x8272c8: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x8272c8: sub             lr, x0, #0xfd0
    //     0x8272cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8272d0: blr             lr
    // 0x8272d4: mov             x1, x0
    // 0x8272d8: ldur            x4, [fp, #-0x10]
    // 0x8272dc: ldur            x0, [fp, #-8]
    // 0x8272e0: ldur            x6, [fp, #-0x20]
    // 0x8272e4: add             x3, x6, x1
    // 0x8272e8: LoadField: r5 = r4->field_b
    //     0x8272e8: ldur            w5, [x4, #0xb]
    // 0x8272ec: DecompressPointer r5
    //     0x8272ec: add             x5, x5, HEAP, lsl #32
    // 0x8272f0: str             xzr, [SP]
    // 0x8272f4: ldur            x1, [fp, #-0x18]
    // 0x8272f8: mov             x2, x6
    // 0x8272fc: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0x8272fc: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0x827300: r0 = setRange()
    //     0x827300: bl              #0xa049fc  ; [dart:core] _List::setRange
    // 0x827304: ldur            x0, [fp, #-8]
    // 0x827308: r17 = 4221
    //     0x827308: mov             x17, #0x107d
    // 0x82730c: cmp             x0, x17
    // 0x827310: b.ne            #0x827324
    // 0x827314: ldur            x0, [fp, #-0x10]
    // 0x827318: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x827318: ldur            x1, [x0, #0x17]
    // 0x82731c: mov             x2, x1
    // 0x827320: b               #0x82739c
    // 0x827324: ldur            x0, [fp, #-0x10]
    // 0x827328: LoadField: r1 = r0->field_1f
    //     0x827328: ldur            w1, [x0, #0x1f]
    // 0x82732c: DecompressPointer r1
    //     0x82732c: add             x1, x1, HEAP, lsl #32
    // 0x827330: r0 = LoadClassIdInstr(r1)
    //     0x827330: ldur            x0, [x1, #-1]
    //     0x827334: ubfx            x0, x0, #0xc, #0x14
    // 0x827338: r17 = 4221
    //     0x827338: mov             x17, #0x107d
    // 0x82733c: cmp             x0, x17
    // 0x827340: b.ne            #0x827350
    // 0x827344: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x827344: ldur            x0, [x1, #0x17]
    // 0x827348: mov             x1, x0
    // 0x82734c: b               #0x827398
    // 0x827350: LoadField: r0 = r1->field_1f
    //     0x827350: ldur            w0, [x1, #0x1f]
    // 0x827354: DecompressPointer r0
    //     0x827354: add             x0, x0, HEAP, lsl #32
    // 0x827358: r1 = LoadClassIdInstr(r0)
    //     0x827358: ldur            x1, [x0, #-1]
    //     0x82735c: ubfx            x1, x1, #0xc, #0x14
    // 0x827360: r17 = 4221
    //     0x827360: mov             x17, #0x107d
    // 0x827364: cmp             x1, x17
    // 0x827368: b.ne            #0x827374
    // 0x82736c: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x82736c: ldur            x1, [x0, #0x17]
    // 0x827370: b               #0x827398
    // 0x827374: r1 = LoadClassIdInstr(r0)
    //     0x827374: ldur            x1, [x0, #-1]
    //     0x827378: ubfx            x1, x1, #0xc, #0x14
    // 0x82737c: mov             x16, x0
    // 0x827380: mov             x0, x1
    // 0x827384: mov             x1, x16
    // 0x827388: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x827388: sub             lr, x0, #0xfd0
    //     0x82738c: ldr             lr, [x21, lr, lsl #3]
    //     0x827390: blr             lr
    // 0x827394: mov             x1, x0
    // 0x827398: mov             x2, x1
    // 0x82739c: ldur            x1, [fp, #-0x20]
    // 0x8273a0: add             x0, x2, x1
    // 0x8273a4: LeaveFrame
    //     0x8273a4: mov             SP, fp
    //     0x8273a8: ldp             fp, lr, [SP], #0x10
    // 0x8273ac: ret
    //     0x8273ac: ret             
    // 0x8273b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8273b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8273b4: b               #0x826d78
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x9f0a28, size: 0x44
    // 0x9f0a28: EnterFrame
    //     0x9f0a28: stp             fp, lr, [SP, #-0x10]!
    //     0x9f0a2c: mov             fp, SP
    // 0x9f0a30: AllocStack(0x10)
    //     0x9f0a30: sub             SP, SP, #0x10
    // 0x9f0a34: SetupParameters([dynamic _ /* r0 */])
    //     0x9f0a34: ldr             x0, [fp, #0x18]
    //     0x9f0a38: ldur            w1, [x0, #0x17]
    //     0x9f0a3c: add             x1, x1, HEAP, lsl #32
    // 0x9f0a40: CheckStackOverflow
    //     0x9f0a40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9f0a44: cmp             SP, x16
    //     0x9f0a48: b.ls            #0x9f0a64
    // 0x9f0a4c: ldr             x16, [fp, #0x10]
    // 0x9f0a50: stp             x16, x1, [SP]
    // 0x9f0a54: r0 = add()
    //     0x9f0a54: bl              #0xa087fc  ; [package:collection/src/queue_list.dart] QueueList::add
    // 0x9f0a58: LeaveFrame
    //     0x9f0a58: mov             SP, fp
    //     0x9f0a5c: ldp             fp, lr, [SP], #0x10
    // 0x9f0a60: ret
    //     0x9f0a60: ret             
    // 0x9f0a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f0a64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f0a68: b               #0x9f0a4c
  }
  _ _add(/* No info */) {
    // ** addr: 0x9f0a6c, size: 0x3ac
    // 0x9f0a6c: EnterFrame
    //     0x9f0a6c: stp             fp, lr, [SP, #-0x10]!
    //     0x9f0a70: mov             fp, SP
    // 0x9f0a74: AllocStack(0x40)
    //     0x9f0a74: sub             SP, SP, #0x40
    // 0x9f0a78: SetupParameters(QueueList<X0> this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x9f0a78: mov             x3, x1
    //     0x9f0a7c: stur            x1, [fp, #-0x18]
    //     0x9f0a80: stur            x2, [fp, #-0x20]
    // 0x9f0a84: CheckStackOverflow
    //     0x9f0a84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9f0a88: cmp             SP, x16
    //     0x9f0a8c: b.ls            #0x9f0e10
    // 0x9f0a90: LoadField: r4 = r3->field_b
    //     0x9f0a90: ldur            w4, [x3, #0xb]
    // 0x9f0a94: DecompressPointer r4
    //     0x9f0a94: add             x4, x4, HEAP, lsl #32
    // 0x9f0a98: stur            x4, [fp, #-0x10]
    // 0x9f0a9c: r5 = LoadClassIdInstr(r3)
    //     0x9f0a9c: ldur            x5, [x3, #-1]
    //     0x9f0aa0: ubfx            x5, x5, #0xc, #0x14
    // 0x9f0aa4: stur            x5, [fp, #-8]
    // 0x9f0aa8: r17 = 4221
    //     0x9f0aa8: mov             x17, #0x107d
    // 0x9f0aac: cmp             x5, x17
    // 0x9f0ab0: b.ne            #0x9f0ac8
    // 0x9f0ab4: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x9f0ab4: ldur            x0, [x3, #0x17]
    // 0x9f0ab8: mov             x2, x4
    // 0x9f0abc: mov             x4, x0
    // 0x9f0ac0: mov             x3, x5
    // 0x9f0ac4: b               #0x9f0b34
    // 0x9f0ac8: LoadField: r0 = r3->field_1f
    //     0x9f0ac8: ldur            w0, [x3, #0x1f]
    // 0x9f0acc: DecompressPointer r0
    //     0x9f0acc: add             x0, x0, HEAP, lsl #32
    // 0x9f0ad0: r1 = LoadClassIdInstr(r0)
    //     0x9f0ad0: ldur            x1, [x0, #-1]
    //     0x9f0ad4: ubfx            x1, x1, #0xc, #0x14
    // 0x9f0ad8: r17 = 4221
    //     0x9f0ad8: mov             x17, #0x107d
    // 0x9f0adc: cmp             x1, x17
    // 0x9f0ae0: b.ne            #0x9f0af0
    // 0x9f0ae4: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x9f0ae4: ldur            x1, [x0, #0x17]
    // 0x9f0ae8: mov             x0, x1
    // 0x9f0aec: b               #0x9f0b28
    // 0x9f0af0: LoadField: r1 = r0->field_1f
    //     0x9f0af0: ldur            w1, [x0, #0x1f]
    // 0x9f0af4: DecompressPointer r1
    //     0x9f0af4: add             x1, x1, HEAP, lsl #32
    // 0x9f0af8: r0 = LoadClassIdInstr(r1)
    //     0x9f0af8: ldur            x0, [x1, #-1]
    //     0x9f0afc: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0b00: r17 = 4221
    //     0x9f0b00: mov             x17, #0x107d
    // 0x9f0b04: cmp             x0, x17
    // 0x9f0b08: b.ne            #0x9f0b14
    // 0x9f0b0c: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x9f0b0c: ldur            x0, [x1, #0x17]
    // 0x9f0b10: b               #0x9f0b28
    // 0x9f0b14: r0 = LoadClassIdInstr(r1)
    //     0x9f0b14: ldur            x0, [x1, #-1]
    //     0x9f0b18: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0b1c: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x9f0b1c: sub             lr, x0, #0xfd0
    //     0x9f0b20: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0b24: blr             lr
    // 0x9f0b28: mov             x4, x0
    // 0x9f0b2c: ldur            x2, [fp, #-0x10]
    // 0x9f0b30: ldur            x3, [fp, #-8]
    // 0x9f0b34: r0 = BoxInt64Instr(r4)
    //     0x9f0b34: sbfiz           x0, x4, #1, #0x1f
    //     0x9f0b38: cmp             x4, x0, asr #1
    //     0x9f0b3c: b.eq            #0x9f0b48
    //     0x9f0b40: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9f0b44: stur            x4, [x0, #7]
    // 0x9f0b48: r1 = LoadClassIdInstr(r2)
    //     0x9f0b48: ldur            x1, [x2, #-1]
    //     0x9f0b4c: ubfx            x1, x1, #0xc, #0x14
    // 0x9f0b50: stp             x0, x2, [SP, #8]
    // 0x9f0b54: ldur            x16, [fp, #-0x20]
    // 0x9f0b58: str             x16, [SP]
    // 0x9f0b5c: mov             x0, x1
    // 0x9f0b60: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0x9f0b60: mov             x17, #0x8dc8
    //     0x9f0b64: movk            x17, #1, lsl #16
    //     0x9f0b68: add             lr, x0, x17
    //     0x9f0b6c: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0b70: blr             lr
    // 0x9f0b74: ldur            x2, [fp, #-8]
    // 0x9f0b78: r17 = 4221
    //     0x9f0b78: mov             x17, #0x107d
    // 0x9f0b7c: cmp             x2, x17
    // 0x9f0b80: b.ne            #0x9f0b98
    // 0x9f0b84: ldur            x3, [fp, #-0x18]
    // 0x9f0b88: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x9f0b88: ldur            x0, [x3, #0x17]
    // 0x9f0b8c: mov             x1, x2
    // 0x9f0b90: mov             x2, x3
    // 0x9f0b94: b               #0x9f0c04
    // 0x9f0b98: ldur            x3, [fp, #-0x18]
    // 0x9f0b9c: LoadField: r0 = r3->field_1f
    //     0x9f0b9c: ldur            w0, [x3, #0x1f]
    // 0x9f0ba0: DecompressPointer r0
    //     0x9f0ba0: add             x0, x0, HEAP, lsl #32
    // 0x9f0ba4: r1 = LoadClassIdInstr(r0)
    //     0x9f0ba4: ldur            x1, [x0, #-1]
    //     0x9f0ba8: ubfx            x1, x1, #0xc, #0x14
    // 0x9f0bac: r17 = 4221
    //     0x9f0bac: mov             x17, #0x107d
    // 0x9f0bb0: cmp             x1, x17
    // 0x9f0bb4: b.ne            #0x9f0bc4
    // 0x9f0bb8: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x9f0bb8: ldur            x1, [x0, #0x17]
    // 0x9f0bbc: mov             x0, x1
    // 0x9f0bc0: b               #0x9f0bfc
    // 0x9f0bc4: LoadField: r1 = r0->field_1f
    //     0x9f0bc4: ldur            w1, [x0, #0x1f]
    // 0x9f0bc8: DecompressPointer r1
    //     0x9f0bc8: add             x1, x1, HEAP, lsl #32
    // 0x9f0bcc: r0 = LoadClassIdInstr(r1)
    //     0x9f0bcc: ldur            x0, [x1, #-1]
    //     0x9f0bd0: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0bd4: r17 = 4221
    //     0x9f0bd4: mov             x17, #0x107d
    // 0x9f0bd8: cmp             x0, x17
    // 0x9f0bdc: b.ne            #0x9f0be8
    // 0x9f0be0: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x9f0be0: ldur            x0, [x1, #0x17]
    // 0x9f0be4: b               #0x9f0bfc
    // 0x9f0be8: r0 = LoadClassIdInstr(r1)
    //     0x9f0be8: ldur            x0, [x1, #-1]
    //     0x9f0bec: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0bf0: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x9f0bf0: sub             lr, x0, #0xfd0
    //     0x9f0bf4: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0bf8: blr             lr
    // 0x9f0bfc: ldur            x2, [fp, #-0x18]
    // 0x9f0c00: ldur            x1, [fp, #-8]
    // 0x9f0c04: add             x3, x0, #1
    // 0x9f0c08: stur            x3, [fp, #-0x28]
    // 0x9f0c0c: LoadField: r0 = r2->field_b
    //     0x9f0c0c: ldur            w0, [x2, #0xb]
    // 0x9f0c10: DecompressPointer r0
    //     0x9f0c10: add             x0, x0, HEAP, lsl #32
    // 0x9f0c14: r4 = LoadClassIdInstr(r0)
    //     0x9f0c14: ldur            x4, [x0, #-1]
    //     0x9f0c18: ubfx            x4, x4, #0xc, #0x14
    // 0x9f0c1c: str             x0, [SP]
    // 0x9f0c20: mov             x0, x4
    // 0x9f0c24: r0 = GDT[cid_x0 + 0xf078]()
    //     0x9f0c24: mov             x17, #0xf078
    //     0x9f0c28: add             lr, x0, x17
    //     0x9f0c2c: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0c30: blr             lr
    // 0x9f0c34: r1 = LoadInt32Instr(r0)
    //     0x9f0c34: sbfx            x1, x0, #1, #0x1f
    //     0x9f0c38: tbz             w0, #0, #0x9f0c40
    //     0x9f0c3c: ldur            x1, [x0, #7]
    // 0x9f0c40: sub             x0, x1, #1
    // 0x9f0c44: ldur            x1, [fp, #-0x28]
    // 0x9f0c48: and             x2, x1, x0
    // 0x9f0c4c: ldur            x3, [fp, #-8]
    // 0x9f0c50: r17 = 4221
    //     0x9f0c50: mov             x17, #0x107d
    // 0x9f0c54: cmp             x3, x17
    // 0x9f0c58: b.ne            #0x9f0c6c
    // 0x9f0c5c: ldur            x4, [fp, #-0x18]
    // 0x9f0c60: ArrayStore: r4[0] = r2  ; List_8
    //     0x9f0c60: stur            x2, [x4, #0x17]
    // 0x9f0c64: mov             x2, x3
    // 0x9f0c68: b               #0x9f0cd0
    // 0x9f0c6c: ldur            x4, [fp, #-0x18]
    // 0x9f0c70: LoadField: r0 = r4->field_1f
    //     0x9f0c70: ldur            w0, [x4, #0x1f]
    // 0x9f0c74: DecompressPointer r0
    //     0x9f0c74: add             x0, x0, HEAP, lsl #32
    // 0x9f0c78: r1 = LoadClassIdInstr(r0)
    //     0x9f0c78: ldur            x1, [x0, #-1]
    //     0x9f0c7c: ubfx            x1, x1, #0xc, #0x14
    // 0x9f0c80: r17 = 4221
    //     0x9f0c80: mov             x17, #0x107d
    // 0x9f0c84: cmp             x1, x17
    // 0x9f0c88: b.ne            #0x9f0c94
    // 0x9f0c8c: ArrayStore: r0[0] = r2  ; List_8
    //     0x9f0c8c: stur            x2, [x0, #0x17]
    // 0x9f0c90: b               #0x9f0ccc
    // 0x9f0c94: LoadField: r1 = r0->field_1f
    //     0x9f0c94: ldur            w1, [x0, #0x1f]
    // 0x9f0c98: DecompressPointer r1
    //     0x9f0c98: add             x1, x1, HEAP, lsl #32
    // 0x9f0c9c: r0 = LoadClassIdInstr(r1)
    //     0x9f0c9c: ldur            x0, [x1, #-1]
    //     0x9f0ca0: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0ca4: r17 = 4221
    //     0x9f0ca4: mov             x17, #0x107d
    // 0x9f0ca8: cmp             x0, x17
    // 0x9f0cac: b.ne            #0x9f0cb8
    // 0x9f0cb0: ArrayStore: r1[0] = r2  ; List_8
    //     0x9f0cb0: stur            x2, [x1, #0x17]
    // 0x9f0cb4: b               #0x9f0ccc
    // 0x9f0cb8: r0 = LoadClassIdInstr(r1)
    //     0x9f0cb8: ldur            x0, [x1, #-1]
    //     0x9f0cbc: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0cc0: r0 = GDT[cid_x0 + -0xfc6]()
    //     0x9f0cc0: sub             lr, x0, #0xfc6
    //     0x9f0cc4: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0cc8: blr             lr
    // 0x9f0ccc: ldur            x2, [fp, #-8]
    // 0x9f0cd0: r17 = 4221
    //     0x9f0cd0: mov             x17, #0x107d
    // 0x9f0cd4: cmp             x2, x17
    // 0x9f0cd8: b.ne            #0x9f0cf4
    // 0x9f0cdc: ldur            x3, [fp, #-0x18]
    // 0x9f0ce0: LoadField: r0 = r3->field_f
    //     0x9f0ce0: ldur            x0, [x3, #0xf]
    // 0x9f0ce4: mov             x16, x2
    // 0x9f0ce8: mov             x2, x0
    // 0x9f0cec: mov             x0, x16
    // 0x9f0cf0: b               #0x9f0d60
    // 0x9f0cf4: ldur            x3, [fp, #-0x18]
    // 0x9f0cf8: LoadField: r0 = r3->field_1f
    //     0x9f0cf8: ldur            w0, [x3, #0x1f]
    // 0x9f0cfc: DecompressPointer r0
    //     0x9f0cfc: add             x0, x0, HEAP, lsl #32
    // 0x9f0d00: r1 = LoadClassIdInstr(r0)
    //     0x9f0d00: ldur            x1, [x0, #-1]
    //     0x9f0d04: ubfx            x1, x1, #0xc, #0x14
    // 0x9f0d08: r17 = 4221
    //     0x9f0d08: mov             x17, #0x107d
    // 0x9f0d0c: cmp             x1, x17
    // 0x9f0d10: b.ne            #0x9f0d20
    // 0x9f0d14: LoadField: r1 = r0->field_f
    //     0x9f0d14: ldur            x1, [x0, #0xf]
    // 0x9f0d18: mov             x0, x1
    // 0x9f0d1c: b               #0x9f0d58
    // 0x9f0d20: LoadField: r1 = r0->field_1f
    //     0x9f0d20: ldur            w1, [x0, #0x1f]
    // 0x9f0d24: DecompressPointer r1
    //     0x9f0d24: add             x1, x1, HEAP, lsl #32
    // 0x9f0d28: r0 = LoadClassIdInstr(r1)
    //     0x9f0d28: ldur            x0, [x1, #-1]
    //     0x9f0d2c: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0d30: r17 = 4221
    //     0x9f0d30: mov             x17, #0x107d
    // 0x9f0d34: cmp             x0, x17
    // 0x9f0d38: b.ne            #0x9f0d44
    // 0x9f0d3c: LoadField: r0 = r1->field_f
    //     0x9f0d3c: ldur            x0, [x1, #0xf]
    // 0x9f0d40: b               #0x9f0d58
    // 0x9f0d44: r0 = LoadClassIdInstr(r1)
    //     0x9f0d44: ldur            x0, [x1, #-1]
    //     0x9f0d48: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0d4c: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x9f0d4c: sub             lr, x0, #0xfc8
    //     0x9f0d50: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0d54: blr             lr
    // 0x9f0d58: mov             x2, x0
    // 0x9f0d5c: ldur            x0, [fp, #-8]
    // 0x9f0d60: stur            x2, [fp, #-0x28]
    // 0x9f0d64: r17 = 4221
    //     0x9f0d64: mov             x17, #0x107d
    // 0x9f0d68: cmp             x0, x17
    // 0x9f0d6c: b.ne            #0x9f0d84
    // 0x9f0d70: ldur            x3, [fp, #-0x18]
    // 0x9f0d74: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x9f0d74: ldur            x0, [x3, #0x17]
    // 0x9f0d78: mov             x1, x0
    // 0x9f0d7c: mov             x0, x2
    // 0x9f0d80: b               #0x9f0df0
    // 0x9f0d84: ldur            x3, [fp, #-0x18]
    // 0x9f0d88: LoadField: r0 = r3->field_1f
    //     0x9f0d88: ldur            w0, [x3, #0x1f]
    // 0x9f0d8c: DecompressPointer r0
    //     0x9f0d8c: add             x0, x0, HEAP, lsl #32
    // 0x9f0d90: r1 = LoadClassIdInstr(r0)
    //     0x9f0d90: ldur            x1, [x0, #-1]
    //     0x9f0d94: ubfx            x1, x1, #0xc, #0x14
    // 0x9f0d98: r17 = 4221
    //     0x9f0d98: mov             x17, #0x107d
    // 0x9f0d9c: cmp             x1, x17
    // 0x9f0da0: b.ne            #0x9f0db0
    // 0x9f0da4: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x9f0da4: ldur            x1, [x0, #0x17]
    // 0x9f0da8: mov             x0, x1
    // 0x9f0dac: b               #0x9f0de8
    // 0x9f0db0: LoadField: r1 = r0->field_1f
    //     0x9f0db0: ldur            w1, [x0, #0x1f]
    // 0x9f0db4: DecompressPointer r1
    //     0x9f0db4: add             x1, x1, HEAP, lsl #32
    // 0x9f0db8: r0 = LoadClassIdInstr(r1)
    //     0x9f0db8: ldur            x0, [x1, #-1]
    //     0x9f0dbc: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0dc0: r17 = 4221
    //     0x9f0dc0: mov             x17, #0x107d
    // 0x9f0dc4: cmp             x0, x17
    // 0x9f0dc8: b.ne            #0x9f0dd4
    // 0x9f0dcc: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x9f0dcc: ldur            x0, [x1, #0x17]
    // 0x9f0dd0: b               #0x9f0de8
    // 0x9f0dd4: r0 = LoadClassIdInstr(r1)
    //     0x9f0dd4: ldur            x0, [x1, #-1]
    //     0x9f0dd8: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0ddc: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x9f0ddc: sub             lr, x0, #0xfd0
    //     0x9f0de0: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0de4: blr             lr
    // 0x9f0de8: mov             x1, x0
    // 0x9f0dec: ldur            x0, [fp, #-0x28]
    // 0x9f0df0: cmp             x0, x1
    // 0x9f0df4: b.ne            #0x9f0e00
    // 0x9f0df8: ldur            x1, [fp, #-0x18]
    // 0x9f0dfc: r0 = _grow()
    //     0x9f0dfc: bl              #0x9f0e18  ; [package:collection/src/queue_list.dart] QueueList::_grow
    // 0x9f0e00: r0 = Null
    //     0x9f0e00: mov             x0, NULL
    // 0x9f0e04: LeaveFrame
    //     0x9f0e04: mov             SP, fp
    //     0x9f0e08: ldp             fp, lr, [SP], #0x10
    // 0x9f0e0c: ret
    //     0x9f0e0c: ret             
    // 0x9f0e10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f0e10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f0e14: b               #0x9f0a90
  }
  _ _grow(/* No info */) {
    // ** addr: 0x9f0e18, size: 0x4dc
    // 0x9f0e18: EnterFrame
    //     0x9f0e18: stp             fp, lr, [SP, #-0x10]!
    //     0x9f0e1c: mov             fp, SP
    // 0x9f0e20: AllocStack(0x38)
    //     0x9f0e20: sub             SP, SP, #0x38
    // 0x9f0e24: SetupParameters(QueueList<X0> this /* r1 => r0, fp-0x8 */)
    //     0x9f0e24: mov             x0, x1
    //     0x9f0e28: stur            x1, [fp, #-8]
    // 0x9f0e2c: CheckStackOverflow
    //     0x9f0e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9f0e30: cmp             SP, x16
    //     0x9f0e34: b.ls            #0x9f12ec
    // 0x9f0e38: LoadField: r2 = r0->field_7
    //     0x9f0e38: ldur            w2, [x0, #7]
    // 0x9f0e3c: DecompressPointer r2
    //     0x9f0e3c: add             x2, x2, HEAP, lsl #32
    // 0x9f0e40: r1 = Null
    //     0x9f0e40: mov             x1, NULL
    // 0x9f0e44: r3 = <X0?>
    //     0x9f0e44: ldr             x3, [PP, #0xbf8]  ; [pp+0xbf8] TypeArguments: <X0?>
    // 0x9f0e48: r0 = Null
    //     0x9f0e48: mov             x0, NULL
    // 0x9f0e4c: cmp             x2, x0
    // 0x9f0e50: b.eq            #0x9f0e60
    // 0x9f0e54: r30 = InstantiateTypeArgumentsMayShareInstantiatorTAStub
    //     0x9f0e54: ldr             lr, [PP, #0xc00]  ; [pp+0xc00] Stub: InstantiateTypeArgumentsMayShareInstantiatorTA (0x7c0e60)
    // 0x9f0e58: LoadField: r30 = r30->field_7
    //     0x9f0e58: ldur            lr, [lr, #7]
    // 0x9f0e5c: blr             lr
    // 0x9f0e60: mov             x2, x0
    // 0x9f0e64: ldur            x1, [fp, #-8]
    // 0x9f0e68: stur            x2, [fp, #-0x10]
    // 0x9f0e6c: LoadField: r0 = r1->field_b
    //     0x9f0e6c: ldur            w0, [x1, #0xb]
    // 0x9f0e70: DecompressPointer r0
    //     0x9f0e70: add             x0, x0, HEAP, lsl #32
    // 0x9f0e74: r3 = LoadClassIdInstr(r0)
    //     0x9f0e74: ldur            x3, [x0, #-1]
    //     0x9f0e78: ubfx            x3, x3, #0xc, #0x14
    // 0x9f0e7c: str             x0, [SP]
    // 0x9f0e80: mov             x0, x3
    // 0x9f0e84: r0 = GDT[cid_x0 + 0xf078]()
    //     0x9f0e84: mov             x17, #0xf078
    //     0x9f0e88: add             lr, x0, x17
    //     0x9f0e8c: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0e90: blr             lr
    // 0x9f0e94: r1 = LoadInt32Instr(r0)
    //     0x9f0e94: sbfx            x1, x0, #1, #0x1f
    //     0x9f0e98: tbz             w0, #0, #0x9f0ea0
    //     0x9f0e9c: ldur            x1, [x0, #7]
    // 0x9f0ea0: lsl             x2, x1, #1
    // 0x9f0ea4: r0 = BoxInt64Instr(r2)
    //     0x9f0ea4: sbfiz           x0, x2, #1, #0x1f
    //     0x9f0ea8: cmp             x2, x0, asr #1
    //     0x9f0eac: b.eq            #0x9f0eb8
    //     0x9f0eb0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9f0eb4: stur            x2, [x0, #7]
    // 0x9f0eb8: mov             x2, x0
    // 0x9f0ebc: ldur            x1, [fp, #-8]
    // 0x9f0ec0: stur            x2, [fp, #-0x18]
    // 0x9f0ec4: LoadField: r0 = r1->field_b
    //     0x9f0ec4: ldur            w0, [x1, #0xb]
    // 0x9f0ec8: DecompressPointer r0
    //     0x9f0ec8: add             x0, x0, HEAP, lsl #32
    // 0x9f0ecc: r3 = LoadClassIdInstr(r0)
    //     0x9f0ecc: ldur            x3, [x0, #-1]
    //     0x9f0ed0: ubfx            x3, x3, #0xc, #0x14
    // 0x9f0ed4: str             x0, [SP]
    // 0x9f0ed8: mov             x0, x3
    // 0x9f0edc: r0 = GDT[cid_x0 + 0xf078]()
    //     0x9f0edc: mov             x17, #0xf078
    //     0x9f0ee0: add             lr, x0, x17
    //     0x9f0ee4: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0ee8: blr             lr
    // 0x9f0eec: mov             x3, x0
    // 0x9f0ef0: ldur            x2, [fp, #-8]
    // 0x9f0ef4: stur            x3, [fp, #-0x28]
    // 0x9f0ef8: r4 = LoadClassIdInstr(r2)
    //     0x9f0ef8: ldur            x4, [x2, #-1]
    //     0x9f0efc: ubfx            x4, x4, #0xc, #0x14
    // 0x9f0f00: stur            x4, [fp, #-0x20]
    // 0x9f0f04: r17 = 4221
    //     0x9f0f04: mov             x17, #0x107d
    // 0x9f0f08: cmp             x4, x17
    // 0x9f0f0c: b.ne            #0x9f0f24
    // 0x9f0f10: LoadField: r0 = r2->field_f
    //     0x9f0f10: ldur            x0, [x2, #0xf]
    // 0x9f0f14: mov             x1, x0
    // 0x9f0f18: mov             x0, x3
    // 0x9f0f1c: mov             x3, x4
    // 0x9f0f20: b               #0x9f0f94
    // 0x9f0f24: LoadField: r0 = r2->field_1f
    //     0x9f0f24: ldur            w0, [x2, #0x1f]
    // 0x9f0f28: DecompressPointer r0
    //     0x9f0f28: add             x0, x0, HEAP, lsl #32
    // 0x9f0f2c: r1 = LoadClassIdInstr(r0)
    //     0x9f0f2c: ldur            x1, [x0, #-1]
    //     0x9f0f30: ubfx            x1, x1, #0xc, #0x14
    // 0x9f0f34: r17 = 4221
    //     0x9f0f34: mov             x17, #0x107d
    // 0x9f0f38: cmp             x1, x17
    // 0x9f0f3c: b.ne            #0x9f0f4c
    // 0x9f0f40: LoadField: r1 = r0->field_f
    //     0x9f0f40: ldur            x1, [x0, #0xf]
    // 0x9f0f44: mov             x0, x1
    // 0x9f0f48: b               #0x9f0f84
    // 0x9f0f4c: LoadField: r1 = r0->field_1f
    //     0x9f0f4c: ldur            w1, [x0, #0x1f]
    // 0x9f0f50: DecompressPointer r1
    //     0x9f0f50: add             x1, x1, HEAP, lsl #32
    // 0x9f0f54: r0 = LoadClassIdInstr(r1)
    //     0x9f0f54: ldur            x0, [x1, #-1]
    //     0x9f0f58: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0f5c: r17 = 4221
    //     0x9f0f5c: mov             x17, #0x107d
    // 0x9f0f60: cmp             x0, x17
    // 0x9f0f64: b.ne            #0x9f0f70
    // 0x9f0f68: LoadField: r0 = r1->field_f
    //     0x9f0f68: ldur            x0, [x1, #0xf]
    // 0x9f0f6c: b               #0x9f0f84
    // 0x9f0f70: r0 = LoadClassIdInstr(r1)
    //     0x9f0f70: ldur            x0, [x1, #-1]
    //     0x9f0f74: ubfx            x0, x0, #0xc, #0x14
    // 0x9f0f78: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x9f0f78: sub             lr, x0, #0xfc8
    //     0x9f0f7c: ldr             lr, [x21, lr, lsl #3]
    //     0x9f0f80: blr             lr
    // 0x9f0f84: mov             x1, x0
    // 0x9f0f88: ldur            x2, [fp, #-8]
    // 0x9f0f8c: ldur            x0, [fp, #-0x28]
    // 0x9f0f90: ldur            x3, [fp, #-0x20]
    // 0x9f0f94: r4 = LoadInt32Instr(r0)
    //     0x9f0f94: sbfx            x4, x0, #1, #0x1f
    //     0x9f0f98: tbz             w0, #0, #0x9f0fa0
    //     0x9f0f9c: ldur            x4, [x0, #7]
    // 0x9f0fa0: sub             x5, x4, x1
    // 0x9f0fa4: stur            x5, [fp, #-0x30]
    // 0x9f0fa8: LoadField: r4 = r2->field_b
    //     0x9f0fa8: ldur            w4, [x2, #0xb]
    // 0x9f0fac: DecompressPointer r4
    //     0x9f0fac: add             x4, x4, HEAP, lsl #32
    // 0x9f0fb0: stur            x4, [fp, #-0x28]
    // 0x9f0fb4: r17 = 4221
    //     0x9f0fb4: mov             x17, #0x107d
    // 0x9f0fb8: cmp             x3, x17
    // 0x9f0fbc: b.ne            #0x9f0fcc
    // 0x9f0fc0: LoadField: r0 = r2->field_f
    //     0x9f0fc0: ldur            x0, [x2, #0xf]
    // 0x9f0fc4: mov             x2, x0
    // 0x9f0fc8: b               #0x9f1034
    // 0x9f0fcc: LoadField: r0 = r2->field_1f
    //     0x9f0fcc: ldur            w0, [x2, #0x1f]
    // 0x9f0fd0: DecompressPointer r0
    //     0x9f0fd0: add             x0, x0, HEAP, lsl #32
    // 0x9f0fd4: r1 = LoadClassIdInstr(r0)
    //     0x9f0fd4: ldur            x1, [x0, #-1]
    //     0x9f0fd8: ubfx            x1, x1, #0xc, #0x14
    // 0x9f0fdc: r17 = 4221
    //     0x9f0fdc: mov             x17, #0x107d
    // 0x9f0fe0: cmp             x1, x17
    // 0x9f0fe4: b.ne            #0x9f0ff4
    // 0x9f0fe8: LoadField: r1 = r0->field_f
    //     0x9f0fe8: ldur            x1, [x0, #0xf]
    // 0x9f0fec: mov             x0, x1
    // 0x9f0ff0: b               #0x9f102c
    // 0x9f0ff4: LoadField: r1 = r0->field_1f
    //     0x9f0ff4: ldur            w1, [x0, #0x1f]
    // 0x9f0ff8: DecompressPointer r1
    //     0x9f0ff8: add             x1, x1, HEAP, lsl #32
    // 0x9f0ffc: r0 = LoadClassIdInstr(r1)
    //     0x9f0ffc: ldur            x0, [x1, #-1]
    //     0x9f1000: ubfx            x0, x0, #0xc, #0x14
    // 0x9f1004: r17 = 4221
    //     0x9f1004: mov             x17, #0x107d
    // 0x9f1008: cmp             x0, x17
    // 0x9f100c: b.ne            #0x9f1018
    // 0x9f1010: LoadField: r0 = r1->field_f
    //     0x9f1010: ldur            x0, [x1, #0xf]
    // 0x9f1014: b               #0x9f102c
    // 0x9f1018: r0 = LoadClassIdInstr(r1)
    //     0x9f1018: ldur            x0, [x1, #-1]
    //     0x9f101c: ubfx            x0, x0, #0xc, #0x14
    // 0x9f1020: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x9f1020: sub             lr, x0, #0xfc8
    //     0x9f1024: ldr             lr, [x21, lr, lsl #3]
    //     0x9f1028: blr             lr
    // 0x9f102c: mov             x2, x0
    // 0x9f1030: ldur            x3, [fp, #-0x20]
    // 0x9f1034: r0 = BoxInt64Instr(r2)
    //     0x9f1034: sbfiz           x0, x2, #1, #0x1f
    //     0x9f1038: cmp             x2, x0, asr #1
    //     0x9f103c: b.eq            #0x9f1048
    //     0x9f1040: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9f1044: stur            x2, [x0, #7]
    // 0x9f1048: ldur            x1, [fp, #-0x10]
    // 0x9f104c: ldur            x2, [fp, #-0x18]
    // 0x9f1050: stur            x0, [fp, #-0x10]
    // 0x9f1054: r0 = AllocateArray()
    //     0x9f1054: bl              #0x13df928  ; AllocateArrayStub
    // 0x9f1058: stur            x0, [fp, #-0x18]
    // 0x9f105c: ldur            x16, [fp, #-0x10]
    // 0x9f1060: str             x16, [SP]
    // 0x9f1064: mov             x1, x0
    // 0x9f1068: ldur            x3, [fp, #-0x30]
    // 0x9f106c: ldur            x5, [fp, #-0x28]
    // 0x9f1070: r2 = 0
    //     0x9f1070: mov             x2, #0
    // 0x9f1074: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0x9f1074: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0x9f1078: r0 = setRange()
    //     0x9f1078: bl              #0xa049fc  ; [dart:core] _List::setRange
    // 0x9f107c: ldur            x2, [fp, #-0x20]
    // 0x9f1080: r17 = 4221
    //     0x9f1080: mov             x17, #0x107d
    // 0x9f1084: cmp             x2, x17
    // 0x9f1088: b.ne            #0x9f10a4
    // 0x9f108c: ldur            x3, [fp, #-8]
    // 0x9f1090: LoadField: r0 = r3->field_f
    //     0x9f1090: ldur            x0, [x3, #0xf]
    // 0x9f1094: mov             x1, x0
    // 0x9f1098: mov             x4, x3
    // 0x9f109c: mov             x0, x2
    // 0x9f10a0: b               #0x9f1114
    // 0x9f10a4: ldur            x3, [fp, #-8]
    // 0x9f10a8: LoadField: r0 = r3->field_1f
    //     0x9f10a8: ldur            w0, [x3, #0x1f]
    // 0x9f10ac: DecompressPointer r0
    //     0x9f10ac: add             x0, x0, HEAP, lsl #32
    // 0x9f10b0: r1 = LoadClassIdInstr(r0)
    //     0x9f10b0: ldur            x1, [x0, #-1]
    //     0x9f10b4: ubfx            x1, x1, #0xc, #0x14
    // 0x9f10b8: r17 = 4221
    //     0x9f10b8: mov             x17, #0x107d
    // 0x9f10bc: cmp             x1, x17
    // 0x9f10c0: b.ne            #0x9f10d0
    // 0x9f10c4: LoadField: r1 = r0->field_f
    //     0x9f10c4: ldur            x1, [x0, #0xf]
    // 0x9f10c8: mov             x0, x1
    // 0x9f10cc: b               #0x9f1108
    // 0x9f10d0: LoadField: r1 = r0->field_1f
    //     0x9f10d0: ldur            w1, [x0, #0x1f]
    // 0x9f10d4: DecompressPointer r1
    //     0x9f10d4: add             x1, x1, HEAP, lsl #32
    // 0x9f10d8: r0 = LoadClassIdInstr(r1)
    //     0x9f10d8: ldur            x0, [x1, #-1]
    //     0x9f10dc: ubfx            x0, x0, #0xc, #0x14
    // 0x9f10e0: r17 = 4221
    //     0x9f10e0: mov             x17, #0x107d
    // 0x9f10e4: cmp             x0, x17
    // 0x9f10e8: b.ne            #0x9f10f4
    // 0x9f10ec: LoadField: r0 = r1->field_f
    //     0x9f10ec: ldur            x0, [x1, #0xf]
    // 0x9f10f0: b               #0x9f1108
    // 0x9f10f4: r0 = LoadClassIdInstr(r1)
    //     0x9f10f4: ldur            x0, [x1, #-1]
    //     0x9f10f8: ubfx            x0, x0, #0xc, #0x14
    // 0x9f10fc: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x9f10fc: sub             lr, x0, #0xfc8
    //     0x9f1100: ldr             lr, [x21, lr, lsl #3]
    //     0x9f1104: blr             lr
    // 0x9f1108: mov             x1, x0
    // 0x9f110c: ldur            x4, [fp, #-8]
    // 0x9f1110: ldur            x0, [fp, #-0x20]
    // 0x9f1114: ldur            x2, [fp, #-0x30]
    // 0x9f1118: add             x3, x2, x1
    // 0x9f111c: LoadField: r5 = r4->field_b
    //     0x9f111c: ldur            w5, [x4, #0xb]
    // 0x9f1120: DecompressPointer r5
    //     0x9f1120: add             x5, x5, HEAP, lsl #32
    // 0x9f1124: str             xzr, [SP]
    // 0x9f1128: ldur            x1, [fp, #-0x18]
    // 0x9f112c: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0x9f112c: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0x9f1130: r0 = setRange()
    //     0x9f1130: bl              #0xa049fc  ; [dart:core] _List::setRange
    // 0x9f1134: ldur            x3, [fp, #-0x20]
    // 0x9f1138: r17 = 4221
    //     0x9f1138: mov             x17, #0x107d
    // 0x9f113c: cmp             x3, x17
    // 0x9f1140: b.ne            #0x9f1158
    // 0x9f1144: ldur            x4, [fp, #-8]
    // 0x9f1148: StoreField: r4->field_f = rZR
    //     0x9f1148: stur            xzr, [x4, #0xf]
    // 0x9f114c: mov             x2, x4
    // 0x9f1150: mov             x1, x3
    // 0x9f1154: b               #0x9f11c4
    // 0x9f1158: ldur            x4, [fp, #-8]
    // 0x9f115c: LoadField: r0 = r4->field_1f
    //     0x9f115c: ldur            w0, [x4, #0x1f]
    // 0x9f1160: DecompressPointer r0
    //     0x9f1160: add             x0, x0, HEAP, lsl #32
    // 0x9f1164: r1 = LoadClassIdInstr(r0)
    //     0x9f1164: ldur            x1, [x0, #-1]
    //     0x9f1168: ubfx            x1, x1, #0xc, #0x14
    // 0x9f116c: r17 = 4221
    //     0x9f116c: mov             x17, #0x107d
    // 0x9f1170: cmp             x1, x17
    // 0x9f1174: b.ne            #0x9f1180
    // 0x9f1178: StoreField: r0->field_f = rZR
    //     0x9f1178: stur            xzr, [x0, #0xf]
    // 0x9f117c: b               #0x9f11bc
    // 0x9f1180: LoadField: r1 = r0->field_1f
    //     0x9f1180: ldur            w1, [x0, #0x1f]
    // 0x9f1184: DecompressPointer r1
    //     0x9f1184: add             x1, x1, HEAP, lsl #32
    // 0x9f1188: r0 = LoadClassIdInstr(r1)
    //     0x9f1188: ldur            x0, [x1, #-1]
    //     0x9f118c: ubfx            x0, x0, #0xc, #0x14
    // 0x9f1190: r17 = 4221
    //     0x9f1190: mov             x17, #0x107d
    // 0x9f1194: cmp             x0, x17
    // 0x9f1198: b.ne            #0x9f11a4
    // 0x9f119c: StoreField: r1->field_f = rZR
    //     0x9f119c: stur            xzr, [x1, #0xf]
    // 0x9f11a0: b               #0x9f11bc
    // 0x9f11a4: r0 = LoadClassIdInstr(r1)
    //     0x9f11a4: ldur            x0, [x1, #-1]
    //     0x9f11a8: ubfx            x0, x0, #0xc, #0x14
    // 0x9f11ac: r2 = 0
    //     0x9f11ac: mov             x2, #0
    // 0x9f11b0: r0 = GDT[cid_x0 + -0xf9d]()
    //     0x9f11b0: sub             lr, x0, #0xf9d
    //     0x9f11b4: ldr             lr, [x21, lr, lsl #3]
    //     0x9f11b8: blr             lr
    // 0x9f11bc: ldur            x2, [fp, #-8]
    // 0x9f11c0: ldur            x1, [fp, #-0x20]
    // 0x9f11c4: LoadField: r0 = r2->field_b
    //     0x9f11c4: ldur            w0, [x2, #0xb]
    // 0x9f11c8: DecompressPointer r0
    //     0x9f11c8: add             x0, x0, HEAP, lsl #32
    // 0x9f11cc: r3 = LoadClassIdInstr(r0)
    //     0x9f11cc: ldur            x3, [x0, #-1]
    //     0x9f11d0: ubfx            x3, x3, #0xc, #0x14
    // 0x9f11d4: str             x0, [SP]
    // 0x9f11d8: mov             x0, x3
    // 0x9f11dc: r0 = GDT[cid_x0 + 0xf078]()
    //     0x9f11dc: mov             x17, #0xf078
    //     0x9f11e0: add             lr, x0, x17
    //     0x9f11e4: ldr             lr, [x21, lr, lsl #3]
    //     0x9f11e8: blr             lr
    // 0x9f11ec: mov             x1, x0
    // 0x9f11f0: ldur            x0, [fp, #-0x20]
    // 0x9f11f4: r17 = 4221
    //     0x9f11f4: mov             x17, #0x107d
    // 0x9f11f8: cmp             x0, x17
    // 0x9f11fc: b.ne            #0x9f121c
    // 0x9f1200: ldur            x3, [fp, #-8]
    // 0x9f1204: r0 = LoadInt32Instr(r1)
    //     0x9f1204: sbfx            x0, x1, #1, #0x1f
    //     0x9f1208: tbz             w1, #0, #0x9f1210
    //     0x9f120c: ldur            x0, [x1, #7]
    // 0x9f1210: ArrayStore: r3[0] = r0  ; List_8
    //     0x9f1210: stur            x0, [x3, #0x17]
    // 0x9f1214: mov             x1, x3
    // 0x9f1218: b               #0x9f12bc
    // 0x9f121c: ldur            x3, [fp, #-8]
    // 0x9f1220: LoadField: r0 = r3->field_1f
    //     0x9f1220: ldur            w0, [x3, #0x1f]
    // 0x9f1224: DecompressPointer r0
    //     0x9f1224: add             x0, x0, HEAP, lsl #32
    // 0x9f1228: r2 = LoadClassIdInstr(r0)
    //     0x9f1228: ldur            x2, [x0, #-1]
    //     0x9f122c: ubfx            x2, x2, #0xc, #0x14
    // 0x9f1230: r17 = 4221
    //     0x9f1230: mov             x17, #0x107d
    // 0x9f1234: cmp             x2, x17
    // 0x9f1238: b.ne            #0x9f1250
    // 0x9f123c: r2 = LoadInt32Instr(r1)
    //     0x9f123c: sbfx            x2, x1, #1, #0x1f
    //     0x9f1240: tbz             w1, #0, #0x9f1248
    //     0x9f1244: ldur            x2, [x1, #7]
    // 0x9f1248: ArrayStore: r0[0] = r2  ; List_8
    //     0x9f1248: stur            x2, [x0, #0x17]
    // 0x9f124c: b               #0x9f12b8
    // 0x9f1250: LoadField: r2 = r0->field_1f
    //     0x9f1250: ldur            w2, [x0, #0x1f]
    // 0x9f1254: DecompressPointer r2
    //     0x9f1254: add             x2, x2, HEAP, lsl #32
    // 0x9f1258: r0 = LoadClassIdInstr(r2)
    //     0x9f1258: ldur            x0, [x2, #-1]
    //     0x9f125c: ubfx            x0, x0, #0xc, #0x14
    // 0x9f1260: r17 = 4221
    //     0x9f1260: mov             x17, #0x107d
    // 0x9f1264: cmp             x0, x17
    // 0x9f1268: b.ne            #0x9f1280
    // 0x9f126c: r0 = LoadInt32Instr(r1)
    //     0x9f126c: sbfx            x0, x1, #1, #0x1f
    //     0x9f1270: tbz             w1, #0, #0x9f1278
    //     0x9f1274: ldur            x0, [x1, #7]
    // 0x9f1278: ArrayStore: r2[0] = r0  ; List_8
    //     0x9f1278: stur            x0, [x2, #0x17]
    // 0x9f127c: b               #0x9f12b8
    // 0x9f1280: r0 = LoadInt32Instr(r1)
    //     0x9f1280: sbfx            x0, x1, #1, #0x1f
    //     0x9f1284: tbz             w1, #0, #0x9f128c
    //     0x9f1288: ldur            x0, [x1, #7]
    // 0x9f128c: r1 = LoadClassIdInstr(r2)
    //     0x9f128c: ldur            x1, [x2, #-1]
    //     0x9f1290: ubfx            x1, x1, #0xc, #0x14
    // 0x9f1294: mov             x16, x2
    // 0x9f1298: mov             x2, x1
    // 0x9f129c: mov             x1, x16
    // 0x9f12a0: mov             x16, x0
    // 0x9f12a4: mov             x0, x2
    // 0x9f12a8: mov             x2, x16
    // 0x9f12ac: r0 = GDT[cid_x0 + -0xfc6]()
    //     0x9f12ac: sub             lr, x0, #0xfc6
    //     0x9f12b0: ldr             lr, [x21, lr, lsl #3]
    //     0x9f12b4: blr             lr
    // 0x9f12b8: ldur            x1, [fp, #-8]
    // 0x9f12bc: ldur            x0, [fp, #-0x18]
    // 0x9f12c0: StoreField: r1->field_b = r0
    //     0x9f12c0: stur            w0, [x1, #0xb]
    //     0x9f12c4: ldurb           w16, [x1, #-1]
    //     0x9f12c8: ldurb           w17, [x0, #-1]
    //     0x9f12cc: and             x16, x17, x16, lsr #2
    //     0x9f12d0: tst             x16, HEAP, lsr #32
    //     0x9f12d4: b.eq            #0x9f12dc
    //     0x9f12d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x9f12dc: r0 = Null
    //     0x9f12dc: mov             x0, NULL
    // 0x9f12e0: LeaveFrame
    //     0x9f12e0: mov             SP, fp
    //     0x9f12e4: ldp             fp, lr, [SP], #0x10
    // 0x9f12e8: ret
    //     0x9f12e8: ret             
    // 0x9f12ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9f12ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9f12f0: b               #0x9f0e38
  }
  dynamic add(dynamic) {
    // ** addr: 0x9f9ba4, size: 0x24
    // 0x9f9ba4: EnterFrame
    //     0x9f9ba4: stp             fp, lr, [SP, #-0x10]!
    //     0x9f9ba8: mov             fp, SP
    // 0x9f9bac: ldr             x2, [fp, #0x10]
    // 0x9f9bb0: r1 = Function 'add':.
    //     0x9f9bb0: add             x1, PP, #0xcf, lsl #12  ; [pp+0xcf8a8] AnonymousClosure: (0x9f0a28), in [package:collection/src/queue_list.dart] QueueList::add (0xa087fc)
    //     0x9f9bb4: ldr             x1, [x1, #0x8a8]
    // 0x9f9bb8: r0 = AllocateClosure()
    //     0x9f9bb8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x9f9bbc: LeaveFrame
    //     0x9f9bbc: mov             SP, fp
    //     0x9f9bc0: ldp             fp, lr, [SP], #0x10
    // 0x9f9bc4: ret
    //     0x9f9bc4: ret             
  }
  _ removeLast(/* No info */) {
    // ** addr: 0x9f9d0c, size: 0x4c4
    // 0x9f9d0c: EnterFrame
    //     0x9f9d0c: stp             fp, lr, [SP, #-0x10]!
    //     0x9f9d10: mov             fp, SP
    // 0x9f9d14: AllocStack(0x40)
    //     0x9f9d14: sub             SP, SP, #0x40
    // 0x9f9d18: SetupParameters(QueueList<X0> this /* r1 => r2, fp-0x10 */)
    //     0x9f9d18: mov             x2, x1
    //     0x9f9d1c: stur            x1, [fp, #-0x10]
    // 0x9f9d20: CheckStackOverflow
    //     0x9f9d20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9f9d24: cmp             SP, x16
    //     0x9f9d28: b.ls            #0x9fa1c8
    // 0x9f9d2c: r3 = LoadClassIdInstr(r2)
    //     0x9f9d2c: ldur            x3, [x2, #-1]
    //     0x9f9d30: ubfx            x3, x3, #0xc, #0x14
    // 0x9f9d34: stur            x3, [fp, #-8]
    // 0x9f9d38: r17 = 4221
    //     0x9f9d38: mov             x17, #0x107d
    // 0x9f9d3c: cmp             x3, x17
    // 0x9f9d40: b.ne            #0x9f9d54
    // 0x9f9d44: LoadField: r0 = r2->field_f
    //     0x9f9d44: ldur            x0, [x2, #0xf]
    // 0x9f9d48: mov             x2, x3
    // 0x9f9d4c: mov             x3, x0
    // 0x9f9d50: b               #0x9f9dbc
    // 0x9f9d54: LoadField: r0 = r2->field_1f
    //     0x9f9d54: ldur            w0, [x2, #0x1f]
    // 0x9f9d58: DecompressPointer r0
    //     0x9f9d58: add             x0, x0, HEAP, lsl #32
    // 0x9f9d5c: r1 = LoadClassIdInstr(r0)
    //     0x9f9d5c: ldur            x1, [x0, #-1]
    //     0x9f9d60: ubfx            x1, x1, #0xc, #0x14
    // 0x9f9d64: r17 = 4221
    //     0x9f9d64: mov             x17, #0x107d
    // 0x9f9d68: cmp             x1, x17
    // 0x9f9d6c: b.ne            #0x9f9d7c
    // 0x9f9d70: LoadField: r1 = r0->field_f
    //     0x9f9d70: ldur            x1, [x0, #0xf]
    // 0x9f9d74: mov             x0, x1
    // 0x9f9d78: b               #0x9f9db4
    // 0x9f9d7c: LoadField: r1 = r0->field_1f
    //     0x9f9d7c: ldur            w1, [x0, #0x1f]
    // 0x9f9d80: DecompressPointer r1
    //     0x9f9d80: add             x1, x1, HEAP, lsl #32
    // 0x9f9d84: r0 = LoadClassIdInstr(r1)
    //     0x9f9d84: ldur            x0, [x1, #-1]
    //     0x9f9d88: ubfx            x0, x0, #0xc, #0x14
    // 0x9f9d8c: r17 = 4221
    //     0x9f9d8c: mov             x17, #0x107d
    // 0x9f9d90: cmp             x0, x17
    // 0x9f9d94: b.ne            #0x9f9da0
    // 0x9f9d98: LoadField: r0 = r1->field_f
    //     0x9f9d98: ldur            x0, [x1, #0xf]
    // 0x9f9d9c: b               #0x9f9db4
    // 0x9f9da0: r0 = LoadClassIdInstr(r1)
    //     0x9f9da0: ldur            x0, [x1, #-1]
    //     0x9f9da4: ubfx            x0, x0, #0xc, #0x14
    // 0x9f9da8: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x9f9da8: sub             lr, x0, #0xfc8
    //     0x9f9dac: ldr             lr, [x21, lr, lsl #3]
    //     0x9f9db0: blr             lr
    // 0x9f9db4: mov             x3, x0
    // 0x9f9db8: ldur            x2, [fp, #-8]
    // 0x9f9dbc: stur            x3, [fp, #-0x18]
    // 0x9f9dc0: r17 = 4221
    //     0x9f9dc0: mov             x17, #0x107d
    // 0x9f9dc4: cmp             x2, x17
    // 0x9f9dc8: b.ne            #0x9f9de0
    // 0x9f9dcc: ldur            x4, [fp, #-0x10]
    // 0x9f9dd0: ArrayLoad: r0 = r4[0]  ; List_8
    //     0x9f9dd0: ldur            x0, [x4, #0x17]
    // 0x9f9dd4: mov             x1, x0
    // 0x9f9dd8: mov             x0, x3
    // 0x9f9ddc: b               #0x9f9e4c
    // 0x9f9de0: ldur            x4, [fp, #-0x10]
    // 0x9f9de4: LoadField: r0 = r4->field_1f
    //     0x9f9de4: ldur            w0, [x4, #0x1f]
    // 0x9f9de8: DecompressPointer r0
    //     0x9f9de8: add             x0, x0, HEAP, lsl #32
    // 0x9f9dec: r1 = LoadClassIdInstr(r0)
    //     0x9f9dec: ldur            x1, [x0, #-1]
    //     0x9f9df0: ubfx            x1, x1, #0xc, #0x14
    // 0x9f9df4: r17 = 4221
    //     0x9f9df4: mov             x17, #0x107d
    // 0x9f9df8: cmp             x1, x17
    // 0x9f9dfc: b.ne            #0x9f9e0c
    // 0x9f9e00: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x9f9e00: ldur            x1, [x0, #0x17]
    // 0x9f9e04: mov             x0, x1
    // 0x9f9e08: b               #0x9f9e44
    // 0x9f9e0c: LoadField: r1 = r0->field_1f
    //     0x9f9e0c: ldur            w1, [x0, #0x1f]
    // 0x9f9e10: DecompressPointer r1
    //     0x9f9e10: add             x1, x1, HEAP, lsl #32
    // 0x9f9e14: r0 = LoadClassIdInstr(r1)
    //     0x9f9e14: ldur            x0, [x1, #-1]
    //     0x9f9e18: ubfx            x0, x0, #0xc, #0x14
    // 0x9f9e1c: r17 = 4221
    //     0x9f9e1c: mov             x17, #0x107d
    // 0x9f9e20: cmp             x0, x17
    // 0x9f9e24: b.ne            #0x9f9e30
    // 0x9f9e28: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x9f9e28: ldur            x0, [x1, #0x17]
    // 0x9f9e2c: b               #0x9f9e44
    // 0x9f9e30: r0 = LoadClassIdInstr(r1)
    //     0x9f9e30: ldur            x0, [x1, #-1]
    //     0x9f9e34: ubfx            x0, x0, #0xc, #0x14
    // 0x9f9e38: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x9f9e38: sub             lr, x0, #0xfd0
    //     0x9f9e3c: ldr             lr, [x21, lr, lsl #3]
    //     0x9f9e40: blr             lr
    // 0x9f9e44: mov             x1, x0
    // 0x9f9e48: ldur            x0, [fp, #-0x18]
    // 0x9f9e4c: cmp             x0, x1
    // 0x9f9e50: b.eq            #0x9fa1ac
    // 0x9f9e54: ldur            x2, [fp, #-8]
    // 0x9f9e58: r17 = 4221
    //     0x9f9e58: mov             x17, #0x107d
    // 0x9f9e5c: cmp             x2, x17
    // 0x9f9e60: b.ne            #0x9f9e78
    // 0x9f9e64: ldur            x3, [fp, #-0x10]
    // 0x9f9e68: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x9f9e68: ldur            x0, [x3, #0x17]
    // 0x9f9e6c: mov             x1, x2
    // 0x9f9e70: mov             x2, x3
    // 0x9f9e74: b               #0x9f9ee4
    // 0x9f9e78: ldur            x3, [fp, #-0x10]
    // 0x9f9e7c: LoadField: r0 = r3->field_1f
    //     0x9f9e7c: ldur            w0, [x3, #0x1f]
    // 0x9f9e80: DecompressPointer r0
    //     0x9f9e80: add             x0, x0, HEAP, lsl #32
    // 0x9f9e84: r1 = LoadClassIdInstr(r0)
    //     0x9f9e84: ldur            x1, [x0, #-1]
    //     0x9f9e88: ubfx            x1, x1, #0xc, #0x14
    // 0x9f9e8c: r17 = 4221
    //     0x9f9e8c: mov             x17, #0x107d
    // 0x9f9e90: cmp             x1, x17
    // 0x9f9e94: b.ne            #0x9f9ea4
    // 0x9f9e98: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x9f9e98: ldur            x1, [x0, #0x17]
    // 0x9f9e9c: mov             x0, x1
    // 0x9f9ea0: b               #0x9f9edc
    // 0x9f9ea4: LoadField: r1 = r0->field_1f
    //     0x9f9ea4: ldur            w1, [x0, #0x1f]
    // 0x9f9ea8: DecompressPointer r1
    //     0x9f9ea8: add             x1, x1, HEAP, lsl #32
    // 0x9f9eac: r0 = LoadClassIdInstr(r1)
    //     0x9f9eac: ldur            x0, [x1, #-1]
    //     0x9f9eb0: ubfx            x0, x0, #0xc, #0x14
    // 0x9f9eb4: r17 = 4221
    //     0x9f9eb4: mov             x17, #0x107d
    // 0x9f9eb8: cmp             x0, x17
    // 0x9f9ebc: b.ne            #0x9f9ec8
    // 0x9f9ec0: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x9f9ec0: ldur            x0, [x1, #0x17]
    // 0x9f9ec4: b               #0x9f9edc
    // 0x9f9ec8: r0 = LoadClassIdInstr(r1)
    //     0x9f9ec8: ldur            x0, [x1, #-1]
    //     0x9f9ecc: ubfx            x0, x0, #0xc, #0x14
    // 0x9f9ed0: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x9f9ed0: sub             lr, x0, #0xfd0
    //     0x9f9ed4: ldr             lr, [x21, lr, lsl #3]
    //     0x9f9ed8: blr             lr
    // 0x9f9edc: ldur            x2, [fp, #-0x10]
    // 0x9f9ee0: ldur            x1, [fp, #-8]
    // 0x9f9ee4: sub             x3, x0, #1
    // 0x9f9ee8: stur            x3, [fp, #-0x18]
    // 0x9f9eec: LoadField: r0 = r2->field_b
    //     0x9f9eec: ldur            w0, [x2, #0xb]
    // 0x9f9ef0: DecompressPointer r0
    //     0x9f9ef0: add             x0, x0, HEAP, lsl #32
    // 0x9f9ef4: r4 = LoadClassIdInstr(r0)
    //     0x9f9ef4: ldur            x4, [x0, #-1]
    //     0x9f9ef8: ubfx            x4, x4, #0xc, #0x14
    // 0x9f9efc: str             x0, [SP]
    // 0x9f9f00: mov             x0, x4
    // 0x9f9f04: r0 = GDT[cid_x0 + 0xf078]()
    //     0x9f9f04: mov             x17, #0xf078
    //     0x9f9f08: add             lr, x0, x17
    //     0x9f9f0c: ldr             lr, [x21, lr, lsl #3]
    //     0x9f9f10: blr             lr
    // 0x9f9f14: r1 = LoadInt32Instr(r0)
    //     0x9f9f14: sbfx            x1, x0, #1, #0x1f
    //     0x9f9f18: tbz             w0, #0, #0x9f9f20
    //     0x9f9f1c: ldur            x1, [x0, #7]
    // 0x9f9f20: sub             x0, x1, #1
    // 0x9f9f24: ldur            x1, [fp, #-0x18]
    // 0x9f9f28: and             x2, x1, x0
    // 0x9f9f2c: ldur            x3, [fp, #-8]
    // 0x9f9f30: r17 = 4221
    //     0x9f9f30: mov             x17, #0x107d
    // 0x9f9f34: cmp             x3, x17
    // 0x9f9f38: b.ne            #0x9f9f50
    // 0x9f9f3c: ldur            x4, [fp, #-0x10]
    // 0x9f9f40: ArrayStore: r4[0] = r2  ; List_8
    //     0x9f9f40: stur            x2, [x4, #0x17]
    // 0x9f9f44: mov             x2, x3
    // 0x9f9f48: mov             x3, x4
    // 0x9f9f4c: b               #0x9f9fb8
    // 0x9f9f50: ldur            x4, [fp, #-0x10]
    // 0x9f9f54: LoadField: r0 = r4->field_1f
    //     0x9f9f54: ldur            w0, [x4, #0x1f]
    // 0x9f9f58: DecompressPointer r0
    //     0x9f9f58: add             x0, x0, HEAP, lsl #32
    // 0x9f9f5c: r1 = LoadClassIdInstr(r0)
    //     0x9f9f5c: ldur            x1, [x0, #-1]
    //     0x9f9f60: ubfx            x1, x1, #0xc, #0x14
    // 0x9f9f64: r17 = 4221
    //     0x9f9f64: mov             x17, #0x107d
    // 0x9f9f68: cmp             x1, x17
    // 0x9f9f6c: b.ne            #0x9f9f78
    // 0x9f9f70: ArrayStore: r0[0] = r2  ; List_8
    //     0x9f9f70: stur            x2, [x0, #0x17]
    // 0x9f9f74: b               #0x9f9fb0
    // 0x9f9f78: LoadField: r1 = r0->field_1f
    //     0x9f9f78: ldur            w1, [x0, #0x1f]
    // 0x9f9f7c: DecompressPointer r1
    //     0x9f9f7c: add             x1, x1, HEAP, lsl #32
    // 0x9f9f80: r0 = LoadClassIdInstr(r1)
    //     0x9f9f80: ldur            x0, [x1, #-1]
    //     0x9f9f84: ubfx            x0, x0, #0xc, #0x14
    // 0x9f9f88: r17 = 4221
    //     0x9f9f88: mov             x17, #0x107d
    // 0x9f9f8c: cmp             x0, x17
    // 0x9f9f90: b.ne            #0x9f9f9c
    // 0x9f9f94: ArrayStore: r1[0] = r2  ; List_8
    //     0x9f9f94: stur            x2, [x1, #0x17]
    // 0x9f9f98: b               #0x9f9fb0
    // 0x9f9f9c: r0 = LoadClassIdInstr(r1)
    //     0x9f9f9c: ldur            x0, [x1, #-1]
    //     0x9f9fa0: ubfx            x0, x0, #0xc, #0x14
    // 0x9f9fa4: r0 = GDT[cid_x0 + -0xfc6]()
    //     0x9f9fa4: sub             lr, x0, #0xfc6
    //     0x9f9fa8: ldr             lr, [x21, lr, lsl #3]
    //     0x9f9fac: blr             lr
    // 0x9f9fb0: ldur            x3, [fp, #-0x10]
    // 0x9f9fb4: ldur            x2, [fp, #-8]
    // 0x9f9fb8: LoadField: r4 = r3->field_b
    //     0x9f9fb8: ldur            w4, [x3, #0xb]
    // 0x9f9fbc: DecompressPointer r4
    //     0x9f9fbc: add             x4, x4, HEAP, lsl #32
    // 0x9f9fc0: stur            x4, [fp, #-0x20]
    // 0x9f9fc4: r17 = 4221
    //     0x9f9fc4: mov             x17, #0x107d
    // 0x9f9fc8: cmp             x2, x17
    // 0x9f9fcc: b.ne            #0x9f9fe0
    // 0x9f9fd0: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x9f9fd0: ldur            x0, [x3, #0x17]
    // 0x9f9fd4: mov             x3, x0
    // 0x9f9fd8: mov             x2, x4
    // 0x9f9fdc: b               #0x9fa048
    // 0x9f9fe0: LoadField: r0 = r3->field_1f
    //     0x9f9fe0: ldur            w0, [x3, #0x1f]
    // 0x9f9fe4: DecompressPointer r0
    //     0x9f9fe4: add             x0, x0, HEAP, lsl #32
    // 0x9f9fe8: r1 = LoadClassIdInstr(r0)
    //     0x9f9fe8: ldur            x1, [x0, #-1]
    //     0x9f9fec: ubfx            x1, x1, #0xc, #0x14
    // 0x9f9ff0: r17 = 4221
    //     0x9f9ff0: mov             x17, #0x107d
    // 0x9f9ff4: cmp             x1, x17
    // 0x9f9ff8: b.ne            #0x9fa008
    // 0x9f9ffc: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x9f9ffc: ldur            x1, [x0, #0x17]
    // 0x9fa000: mov             x0, x1
    // 0x9fa004: b               #0x9fa040
    // 0x9fa008: LoadField: r1 = r0->field_1f
    //     0x9fa008: ldur            w1, [x0, #0x1f]
    // 0x9fa00c: DecompressPointer r1
    //     0x9fa00c: add             x1, x1, HEAP, lsl #32
    // 0x9fa010: r0 = LoadClassIdInstr(r1)
    //     0x9fa010: ldur            x0, [x1, #-1]
    //     0x9fa014: ubfx            x0, x0, #0xc, #0x14
    // 0x9fa018: r17 = 4221
    //     0x9fa018: mov             x17, #0x107d
    // 0x9fa01c: cmp             x0, x17
    // 0x9fa020: b.ne            #0x9fa02c
    // 0x9fa024: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x9fa024: ldur            x0, [x1, #0x17]
    // 0x9fa028: b               #0x9fa040
    // 0x9fa02c: r0 = LoadClassIdInstr(r1)
    //     0x9fa02c: ldur            x0, [x1, #-1]
    //     0x9fa030: ubfx            x0, x0, #0xc, #0x14
    // 0x9fa034: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x9fa034: sub             lr, x0, #0xfd0
    //     0x9fa038: ldr             lr, [x21, lr, lsl #3]
    //     0x9fa03c: blr             lr
    // 0x9fa040: mov             x3, x0
    // 0x9fa044: ldur            x2, [fp, #-0x20]
    // 0x9fa048: r0 = BoxInt64Instr(r3)
    //     0x9fa048: sbfiz           x0, x3, #1, #0x1f
    //     0x9fa04c: cmp             x3, x0, asr #1
    //     0x9fa050: b.eq            #0x9fa05c
    //     0x9fa054: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9fa058: stur            x3, [x0, #7]
    // 0x9fa05c: r1 = LoadClassIdInstr(r2)
    //     0x9fa05c: ldur            x1, [x2, #-1]
    //     0x9fa060: ubfx            x1, x1, #0xc, #0x14
    // 0x9fa064: stp             x0, x2, [SP]
    // 0x9fa068: mov             x0, x1
    // 0x9fa06c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x9fa06c: sub             lr, x0, #0xdfd
    //     0x9fa070: ldr             lr, [x21, lr, lsl #3]
    //     0x9fa074: blr             lr
    // 0x9fa078: mov             x3, x0
    // 0x9fa07c: stur            x3, [fp, #-0x20]
    // 0x9fa080: cmp             w3, NULL
    // 0x9fa084: b.ne            #0x9fa0c0
    // 0x9fa088: ldur            x4, [fp, #-0x10]
    // 0x9fa08c: LoadField: r2 = r4->field_7
    //     0x9fa08c: ldur            w2, [x4, #7]
    // 0x9fa090: DecompressPointer r2
    //     0x9fa090: add             x2, x2, HEAP, lsl #32
    // 0x9fa094: mov             x0, x3
    // 0x9fa098: r1 = Null
    //     0x9fa098: mov             x1, NULL
    // 0x9fa09c: cmp             w2, NULL
    // 0x9fa0a0: b.eq            #0x9fa0c0
    // 0x9fa0a4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x9fa0a4: ldur            w4, [x2, #0x17]
    // 0x9fa0a8: DecompressPointer r4
    //     0x9fa0a8: add             x4, x4, HEAP, lsl #32
    // 0x9fa0ac: r8 = X0
    //     0x9fa0ac: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x9fa0b0: LoadField: r9 = r4->field_7
    //     0x9fa0b0: ldur            x9, [x4, #7]
    // 0x9fa0b4: r3 = Null
    //     0x9fa0b4: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf938] Null
    //     0x9fa0b8: ldr             x3, [x3, #0x938]
    // 0x9fa0bc: blr             x9
    // 0x9fa0c0: ldur            x0, [fp, #-0x10]
    // 0x9fa0c4: ldur            x1, [fp, #-8]
    // 0x9fa0c8: LoadField: r2 = r0->field_b
    //     0x9fa0c8: ldur            w2, [x0, #0xb]
    // 0x9fa0cc: DecompressPointer r2
    //     0x9fa0cc: add             x2, x2, HEAP, lsl #32
    // 0x9fa0d0: stur            x2, [fp, #-0x28]
    // 0x9fa0d4: r17 = 4221
    //     0x9fa0d4: mov             x17, #0x107d
    // 0x9fa0d8: cmp             x1, x17
    // 0x9fa0dc: b.ne            #0x9fa0ec
    // 0x9fa0e0: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x9fa0e0: ldur            x1, [x0, #0x17]
    // 0x9fa0e4: mov             x3, x1
    // 0x9fa0e8: b               #0x9fa160
    // 0x9fa0ec: LoadField: r1 = r0->field_1f
    //     0x9fa0ec: ldur            w1, [x0, #0x1f]
    // 0x9fa0f0: DecompressPointer r1
    //     0x9fa0f0: add             x1, x1, HEAP, lsl #32
    // 0x9fa0f4: r0 = LoadClassIdInstr(r1)
    //     0x9fa0f4: ldur            x0, [x1, #-1]
    //     0x9fa0f8: ubfx            x0, x0, #0xc, #0x14
    // 0x9fa0fc: r17 = 4221
    //     0x9fa0fc: mov             x17, #0x107d
    // 0x9fa100: cmp             x0, x17
    // 0x9fa104: b.ne            #0x9fa110
    // 0x9fa108: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x9fa108: ldur            x0, [x1, #0x17]
    // 0x9fa10c: b               #0x9fa158
    // 0x9fa110: LoadField: r0 = r1->field_1f
    //     0x9fa110: ldur            w0, [x1, #0x1f]
    // 0x9fa114: DecompressPointer r0
    //     0x9fa114: add             x0, x0, HEAP, lsl #32
    // 0x9fa118: r1 = LoadClassIdInstr(r0)
    //     0x9fa118: ldur            x1, [x0, #-1]
    //     0x9fa11c: ubfx            x1, x1, #0xc, #0x14
    // 0x9fa120: r17 = 4221
    //     0x9fa120: mov             x17, #0x107d
    // 0x9fa124: cmp             x1, x17
    // 0x9fa128: b.ne            #0x9fa138
    // 0x9fa12c: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x9fa12c: ldur            x1, [x0, #0x17]
    // 0x9fa130: mov             x0, x1
    // 0x9fa134: b               #0x9fa158
    // 0x9fa138: r1 = LoadClassIdInstr(r0)
    //     0x9fa138: ldur            x1, [x0, #-1]
    //     0x9fa13c: ubfx            x1, x1, #0xc, #0x14
    // 0x9fa140: mov             x16, x0
    // 0x9fa144: mov             x0, x1
    // 0x9fa148: mov             x1, x16
    // 0x9fa14c: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x9fa14c: sub             lr, x0, #0xfd0
    //     0x9fa150: ldr             lr, [x21, lr, lsl #3]
    //     0x9fa154: blr             lr
    // 0x9fa158: mov             x3, x0
    // 0x9fa15c: ldur            x2, [fp, #-0x28]
    // 0x9fa160: r0 = BoxInt64Instr(r3)
    //     0x9fa160: sbfiz           x0, x3, #1, #0x1f
    //     0x9fa164: cmp             x3, x0, asr #1
    //     0x9fa168: b.eq            #0x9fa174
    //     0x9fa16c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9fa170: stur            x3, [x0, #7]
    // 0x9fa174: r1 = LoadClassIdInstr(r2)
    //     0x9fa174: ldur            x1, [x2, #-1]
    //     0x9fa178: ubfx            x1, x1, #0xc, #0x14
    // 0x9fa17c: stp             x0, x2, [SP, #8]
    // 0x9fa180: str             NULL, [SP]
    // 0x9fa184: mov             x0, x1
    // 0x9fa188: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0x9fa188: mov             x17, #0x8dc8
    //     0x9fa18c: movk            x17, #1, lsl #16
    //     0x9fa190: add             lr, x0, x17
    //     0x9fa194: ldr             lr, [x21, lr, lsl #3]
    //     0x9fa198: blr             lr
    // 0x9fa19c: ldur            x0, [fp, #-0x20]
    // 0x9fa1a0: LeaveFrame
    //     0x9fa1a0: mov             SP, fp
    //     0x9fa1a4: ldp             fp, lr, [SP], #0x10
    // 0x9fa1a8: ret
    //     0x9fa1a8: ret             
    // 0x9fa1ac: r0 = StateError()
    //     0x9fa1ac: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x9fa1b0: mov             x1, x0
    // 0x9fa1b4: r0 = "No element"
    //     0x9fa1b4: ldr             x0, [PP, #0xb78]  ; [pp+0xb78] "No element"
    // 0x9fa1b8: StoreField: r1->field_b = r0
    //     0x9fa1b8: stur            w0, [x1, #0xb]
    // 0x9fa1bc: mov             x0, x1
    // 0x9fa1c0: r0 = Throw()
    //     0x9fa1c0: bl              #0x13ddb2c  ; ThrowStub
    // 0x9fa1c4: brk             #0
    // 0x9fa1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fa1c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fa1cc: b               #0x9f9d2c
  }
  _ addAll(/* No info */) {
    // ** addr: 0xa064c0, size: 0x990
    // 0xa064c0: EnterFrame
    //     0xa064c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa064c4: mov             fp, SP
    // 0xa064c8: AllocStack(0x40)
    //     0xa064c8: sub             SP, SP, #0x40
    // 0xa064cc: SetupParameters(QueueList<X0> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xa064cc: mov             x4, x1
    //     0xa064d0: mov             x3, x2
    //     0xa064d4: stur            x1, [fp, #-8]
    //     0xa064d8: stur            x2, [fp, #-0x10]
    // 0xa064dc: CheckStackOverflow
    //     0xa064dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa064e0: cmp             SP, x16
    //     0xa064e4: b.ls            #0xa06e40
    // 0xa064e8: LoadField: r2 = r4->field_7
    //     0xa064e8: ldur            w2, [x4, #7]
    // 0xa064ec: DecompressPointer r2
    //     0xa064ec: add             x2, x2, HEAP, lsl #32
    // 0xa064f0: mov             x0, x3
    // 0xa064f4: r1 = Null
    //     0xa064f4: mov             x1, NULL
    // 0xa064f8: r8 = Iterable<X0>
    //     0xa064f8: ldr             x8, [PP, #0xbb0]  ; [pp+0xbb0] Type: Iterable<X0>
    // 0xa064fc: LoadField: r9 = r8->field_7
    //     0xa064fc: ldur            x9, [x8, #7]
    // 0xa06500: r3 = Null
    //     0xa06500: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf958] Null
    //     0xa06504: ldr             x3, [x3, #0x958]
    // 0xa06508: blr             x9
    // 0xa0650c: ldur            x0, [fp, #-0x10]
    // 0xa06510: r2 = Null
    //     0xa06510: mov             x2, NULL
    // 0xa06514: r1 = Null
    //     0xa06514: mov             x1, NULL
    // 0xa06518: cmp             w0, NULL
    // 0xa0651c: b.eq            #0xa065c0
    // 0xa06520: branchIfSmi(r0, 0xa065c0)
    //     0xa06520: tbz             w0, #0, #0xa065c0
    // 0xa06524: r3 = LoadClassIdInstr(r0)
    //     0xa06524: ldur            x3, [x0, #-1]
    //     0xa06528: ubfx            x3, x3, #0xc, #0x14
    // 0xa0652c: r17 = 7631
    //     0xa0652c: mov             x17, #0x1dcf
    // 0xa06530: cmp             x3, x17
    // 0xa06534: b.eq            #0xa065c8
    // 0xa06538: sub             x3, x3, #0x5a
    // 0xa0653c: cmp             x3, #2
    // 0xa06540: b.ls            #0xa065c8
    // 0xa06544: r4 = LoadClassIdInstr(r0)
    //     0xa06544: ldur            x4, [x0, #-1]
    //     0xa06548: ubfx            x4, x4, #0xc, #0x14
    // 0xa0654c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0xa06550: ldr             x3, [x3, #0x18]
    // 0xa06554: ldr             x3, [x3, x4, lsl #3]
    // 0xa06558: LoadField: r3 = r3->field_2b
    //     0xa06558: ldur            w3, [x3, #0x2b]
    // 0xa0655c: DecompressPointer r3
    //     0xa0655c: add             x3, x3, HEAP, lsl #32
    // 0xa06560: cmp             w3, NULL
    // 0xa06564: b.eq            #0xa065c0
    // 0xa06568: LoadField: r3 = r3->field_f
    //     0xa06568: ldur            w3, [x3, #0xf]
    // 0xa0656c: lsr             x3, x3, #3
    // 0xa06570: r17 = 7631
    //     0xa06570: mov             x17, #0x1dcf
    // 0xa06574: cmp             x3, x17
    // 0xa06578: b.eq            #0xa065c8
    // 0xa0657c: r3 = SubtypeTestCache
    //     0xa0657c: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf968] SubtypeTestCache
    //     0xa06580: ldr             x3, [x3, #0x968]
    // 0xa06584: r30 = Subtype1TestCacheStub
    //     0xa06584: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0xa06588: LoadField: r30 = r30->field_7
    //     0xa06588: ldur            lr, [lr, #7]
    // 0xa0658c: blr             lr
    // 0xa06590: cmp             w7, NULL
    // 0xa06594: b.eq            #0xa065a0
    // 0xa06598: tbnz            w7, #4, #0xa065c0
    // 0xa0659c: b               #0xa065c8
    // 0xa065a0: r8 = List
    //     0xa065a0: add             x8, PP, #0xcf, lsl #12  ; [pp+0xcf970] Type: List
    //     0xa065a4: ldr             x8, [x8, #0x970]
    // 0xa065a8: r3 = SubtypeTestCache
    //     0xa065a8: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf978] SubtypeTestCache
    //     0xa065ac: ldr             x3, [x3, #0x978]
    // 0xa065b0: r30 = InstanceOfStub
    //     0xa065b0: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xa065b4: LoadField: r30 = r30->field_7
    //     0xa065b4: ldur            lr, [lr, #7]
    // 0xa065b8: blr             lr
    // 0xa065bc: b               #0xa065cc
    // 0xa065c0: r0 = false
    //     0xa065c0: add             x0, NULL, #0x30  ; false
    // 0xa065c4: b               #0xa065cc
    // 0xa065c8: r0 = true
    //     0xa065c8: add             x0, NULL, #0x20  ; true
    // 0xa065cc: tbnz            w0, #4, #0xa06d9c
    // 0xa065d0: ldur            x1, [fp, #-8]
    // 0xa065d4: ldur            x5, [fp, #-0x10]
    // 0xa065d8: r0 = LoadClassIdInstr(r5)
    //     0xa065d8: ldur            x0, [x5, #-1]
    //     0xa065dc: ubfx            x0, x0, #0xc, #0x14
    // 0xa065e0: str             x5, [SP]
    // 0xa065e4: r0 = GDT[cid_x0 + 0xf078]()
    //     0xa065e4: mov             x17, #0xf078
    //     0xa065e8: add             lr, x0, x17
    //     0xa065ec: ldr             lr, [x21, lr, lsl #3]
    //     0xa065f0: blr             lr
    // 0xa065f4: stur            x0, [fp, #-0x18]
    // 0xa065f8: ldur            x16, [fp, #-8]
    // 0xa065fc: str             x16, [SP]
    // 0xa06600: r0 = length()
    //     0xa06600: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0xa06604: mov             x1, x0
    // 0xa06608: ldur            x0, [fp, #-0x18]
    // 0xa0660c: r2 = LoadInt32Instr(r0)
    //     0xa0660c: sbfx            x2, x0, #1, #0x1f
    //     0xa06610: tbz             w0, #0, #0xa06618
    //     0xa06614: ldur            x2, [x0, #7]
    // 0xa06618: stur            x2, [fp, #-0x30]
    // 0xa0661c: r3 = LoadInt32Instr(r1)
    //     0xa0661c: sbfx            x3, x1, #1, #0x1f
    //     0xa06620: tbz             w1, #0, #0xa06628
    //     0xa06624: ldur            x3, [x1, #7]
    // 0xa06628: stur            x3, [fp, #-0x28]
    // 0xa0662c: add             x1, x3, x2
    // 0xa06630: ldur            x4, [fp, #-8]
    // 0xa06634: stur            x1, [fp, #-0x20]
    // 0xa06638: LoadField: r0 = r4->field_b
    //     0xa06638: ldur            w0, [x4, #0xb]
    // 0xa0663c: DecompressPointer r0
    //     0xa0663c: add             x0, x0, HEAP, lsl #32
    // 0xa06640: r5 = LoadClassIdInstr(r0)
    //     0xa06640: ldur            x5, [x0, #-1]
    //     0xa06644: ubfx            x5, x5, #0xc, #0x14
    // 0xa06648: str             x0, [SP]
    // 0xa0664c: mov             x0, x5
    // 0xa06650: r0 = GDT[cid_x0 + 0xf078]()
    //     0xa06650: mov             x17, #0xf078
    //     0xa06654: add             lr, x0, x17
    //     0xa06658: ldr             lr, [x21, lr, lsl #3]
    //     0xa0665c: blr             lr
    // 0xa06660: r1 = LoadInt32Instr(r0)
    //     0xa06660: sbfx            x1, x0, #1, #0x1f
    //     0xa06664: tbz             w0, #0, #0xa0666c
    //     0xa06668: ldur            x1, [x0, #7]
    // 0xa0666c: ldur            x0, [fp, #-0x20]
    // 0xa06670: cmp             x0, x1
    // 0xa06674: b.lt            #0xa067e0
    // 0xa06678: ldur            x3, [fp, #-8]
    // 0xa0667c: mov             x1, x3
    // 0xa06680: mov             x2, x0
    // 0xa06684: r0 = _preGrow()
    //     0xa06684: bl              #0x826b40  ; [package:collection/src/queue_list.dart] QueueList::_preGrow
    // 0xa06688: ldur            x4, [fp, #-8]
    // 0xa0668c: LoadField: r1 = r4->field_b
    //     0xa0668c: ldur            w1, [x4, #0xb]
    // 0xa06690: DecompressPointer r1
    //     0xa06690: add             x1, x1, HEAP, lsl #32
    // 0xa06694: r0 = LoadClassIdInstr(r1)
    //     0xa06694: ldur            x0, [x1, #-1]
    //     0xa06698: ubfx            x0, x0, #0xc, #0x14
    // 0xa0669c: str             xzr, [SP]
    // 0xa066a0: ldur            x2, [fp, #-0x28]
    // 0xa066a4: ldur            x3, [fp, #-0x20]
    // 0xa066a8: ldur            x5, [fp, #-0x10]
    // 0xa066ac: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0xa066ac: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0xa066b0: r0 = GDT[cid_x0 + 0x18893]()
    //     0xa066b0: mov             x17, #0x8893
    //     0xa066b4: movk            x17, #1, lsl #16
    //     0xa066b8: add             lr, x0, x17
    //     0xa066bc: ldr             lr, [x21, lr, lsl #3]
    //     0xa066c0: blr             lr
    // 0xa066c4: ldur            x2, [fp, #-8]
    // 0xa066c8: r3 = LoadClassIdInstr(r2)
    //     0xa066c8: ldur            x3, [x2, #-1]
    //     0xa066cc: ubfx            x3, x3, #0xc, #0x14
    // 0xa066d0: stur            x3, [fp, #-0x20]
    // 0xa066d4: r17 = 4221
    //     0xa066d4: mov             x17, #0x107d
    // 0xa066d8: cmp             x3, x17
    // 0xa066dc: b.ne            #0xa066f0
    // 0xa066e0: ArrayLoad: r0 = r2[0]  ; List_8
    //     0xa066e0: ldur            x0, [x2, #0x17]
    // 0xa066e4: mov             x2, x0
    // 0xa066e8: mov             x0, x3
    // 0xa066ec: b               #0xa06758
    // 0xa066f0: LoadField: r0 = r2->field_1f
    //     0xa066f0: ldur            w0, [x2, #0x1f]
    // 0xa066f4: DecompressPointer r0
    //     0xa066f4: add             x0, x0, HEAP, lsl #32
    // 0xa066f8: r1 = LoadClassIdInstr(r0)
    //     0xa066f8: ldur            x1, [x0, #-1]
    //     0xa066fc: ubfx            x1, x1, #0xc, #0x14
    // 0xa06700: r17 = 4221
    //     0xa06700: mov             x17, #0x107d
    // 0xa06704: cmp             x1, x17
    // 0xa06708: b.ne            #0xa06718
    // 0xa0670c: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xa0670c: ldur            x1, [x0, #0x17]
    // 0xa06710: mov             x0, x1
    // 0xa06714: b               #0xa06750
    // 0xa06718: LoadField: r1 = r0->field_1f
    //     0xa06718: ldur            w1, [x0, #0x1f]
    // 0xa0671c: DecompressPointer r1
    //     0xa0671c: add             x1, x1, HEAP, lsl #32
    // 0xa06720: r0 = LoadClassIdInstr(r1)
    //     0xa06720: ldur            x0, [x1, #-1]
    //     0xa06724: ubfx            x0, x0, #0xc, #0x14
    // 0xa06728: r17 = 4221
    //     0xa06728: mov             x17, #0x107d
    // 0xa0672c: cmp             x0, x17
    // 0xa06730: b.ne            #0xa0673c
    // 0xa06734: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xa06734: ldur            x0, [x1, #0x17]
    // 0xa06738: b               #0xa06750
    // 0xa0673c: r0 = LoadClassIdInstr(r1)
    //     0xa0673c: ldur            x0, [x1, #-1]
    //     0xa06740: ubfx            x0, x0, #0xc, #0x14
    // 0xa06744: r0 = GDT[cid_x0 + -0xfd0]()
    //     0xa06744: sub             lr, x0, #0xfd0
    //     0xa06748: ldr             lr, [x21, lr, lsl #3]
    //     0xa0674c: blr             lr
    // 0xa06750: mov             x2, x0
    // 0xa06754: ldur            x0, [fp, #-0x20]
    // 0xa06758: ldur            x1, [fp, #-0x30]
    // 0xa0675c: add             x3, x2, x1
    // 0xa06760: r17 = 4221
    //     0xa06760: mov             x17, #0x107d
    // 0xa06764: cmp             x0, x17
    // 0xa06768: b.ne            #0xa06778
    // 0xa0676c: ldur            x2, [fp, #-8]
    // 0xa06770: ArrayStore: r2[0] = r3  ; List_8
    //     0xa06770: stur            x3, [x2, #0x17]
    // 0xa06774: b               #0xa06e30
    // 0xa06778: ldur            x2, [fp, #-8]
    // 0xa0677c: LoadField: r0 = r2->field_1f
    //     0xa0677c: ldur            w0, [x2, #0x1f]
    // 0xa06780: DecompressPointer r0
    //     0xa06780: add             x0, x0, HEAP, lsl #32
    // 0xa06784: r1 = LoadClassIdInstr(r0)
    //     0xa06784: ldur            x1, [x0, #-1]
    //     0xa06788: ubfx            x1, x1, #0xc, #0x14
    // 0xa0678c: r17 = 4221
    //     0xa0678c: mov             x17, #0x107d
    // 0xa06790: cmp             x1, x17
    // 0xa06794: b.ne            #0xa067a0
    // 0xa06798: ArrayStore: r0[0] = r3  ; List_8
    //     0xa06798: stur            x3, [x0, #0x17]
    // 0xa0679c: b               #0xa06e30
    // 0xa067a0: LoadField: r1 = r0->field_1f
    //     0xa067a0: ldur            w1, [x0, #0x1f]
    // 0xa067a4: DecompressPointer r1
    //     0xa067a4: add             x1, x1, HEAP, lsl #32
    // 0xa067a8: r0 = LoadClassIdInstr(r1)
    //     0xa067a8: ldur            x0, [x1, #-1]
    //     0xa067ac: ubfx            x0, x0, #0xc, #0x14
    // 0xa067b0: r17 = 4221
    //     0xa067b0: mov             x17, #0x107d
    // 0xa067b4: cmp             x0, x17
    // 0xa067b8: b.ne            #0xa067c4
    // 0xa067bc: ArrayStore: r1[0] = r3  ; List_8
    //     0xa067bc: stur            x3, [x1, #0x17]
    // 0xa067c0: b               #0xa06e30
    // 0xa067c4: r0 = LoadClassIdInstr(r1)
    //     0xa067c4: ldur            x0, [x1, #-1]
    //     0xa067c8: ubfx            x0, x0, #0xc, #0x14
    // 0xa067cc: mov             x2, x3
    // 0xa067d0: r0 = GDT[cid_x0 + -0xfc6]()
    //     0xa067d0: sub             lr, x0, #0xfc6
    //     0xa067d4: ldr             lr, [x21, lr, lsl #3]
    //     0xa067d8: blr             lr
    // 0xa067dc: b               #0xa06e30
    // 0xa067e0: ldur            x2, [fp, #-8]
    // 0xa067e4: ldur            x1, [fp, #-0x30]
    // 0xa067e8: LoadField: r0 = r2->field_b
    //     0xa067e8: ldur            w0, [x2, #0xb]
    // 0xa067ec: DecompressPointer r0
    //     0xa067ec: add             x0, x0, HEAP, lsl #32
    // 0xa067f0: r3 = LoadClassIdInstr(r0)
    //     0xa067f0: ldur            x3, [x0, #-1]
    //     0xa067f4: ubfx            x3, x3, #0xc, #0x14
    // 0xa067f8: str             x0, [SP]
    // 0xa067fc: mov             x0, x3
    // 0xa06800: r0 = GDT[cid_x0 + 0xf078]()
    //     0xa06800: mov             x17, #0xf078
    //     0xa06804: add             lr, x0, x17
    //     0xa06808: ldr             lr, [x21, lr, lsl #3]
    //     0xa0680c: blr             lr
    // 0xa06810: mov             x3, x0
    // 0xa06814: ldur            x2, [fp, #-8]
    // 0xa06818: stur            x3, [fp, #-0x18]
    // 0xa0681c: r4 = LoadClassIdInstr(r2)
    //     0xa0681c: ldur            x4, [x2, #-1]
    //     0xa06820: ubfx            x4, x4, #0xc, #0x14
    // 0xa06824: stur            x4, [fp, #-0x20]
    // 0xa06828: r17 = 4221
    //     0xa06828: mov             x17, #0x107d
    // 0xa0682c: cmp             x4, x17
    // 0xa06830: b.ne            #0xa06844
    // 0xa06834: ArrayLoad: r0 = r2[0]  ; List_8
    //     0xa06834: ldur            x0, [x2, #0x17]
    // 0xa06838: mov             x1, x0
    // 0xa0683c: mov             x0, x3
    // 0xa06840: b               #0xa068ac
    // 0xa06844: LoadField: r0 = r2->field_1f
    //     0xa06844: ldur            w0, [x2, #0x1f]
    // 0xa06848: DecompressPointer r0
    //     0xa06848: add             x0, x0, HEAP, lsl #32
    // 0xa0684c: r1 = LoadClassIdInstr(r0)
    //     0xa0684c: ldur            x1, [x0, #-1]
    //     0xa06850: ubfx            x1, x1, #0xc, #0x14
    // 0xa06854: r17 = 4221
    //     0xa06854: mov             x17, #0x107d
    // 0xa06858: cmp             x1, x17
    // 0xa0685c: b.ne            #0xa0686c
    // 0xa06860: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xa06860: ldur            x1, [x0, #0x17]
    // 0xa06864: mov             x0, x1
    // 0xa06868: b               #0xa068a4
    // 0xa0686c: LoadField: r1 = r0->field_1f
    //     0xa0686c: ldur            w1, [x0, #0x1f]
    // 0xa06870: DecompressPointer r1
    //     0xa06870: add             x1, x1, HEAP, lsl #32
    // 0xa06874: r0 = LoadClassIdInstr(r1)
    //     0xa06874: ldur            x0, [x1, #-1]
    //     0xa06878: ubfx            x0, x0, #0xc, #0x14
    // 0xa0687c: r17 = 4221
    //     0xa0687c: mov             x17, #0x107d
    // 0xa06880: cmp             x0, x17
    // 0xa06884: b.ne            #0xa06890
    // 0xa06888: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xa06888: ldur            x0, [x1, #0x17]
    // 0xa0688c: b               #0xa068a4
    // 0xa06890: r0 = LoadClassIdInstr(r1)
    //     0xa06890: ldur            x0, [x1, #-1]
    //     0xa06894: ubfx            x0, x0, #0xc, #0x14
    // 0xa06898: r0 = GDT[cid_x0 + -0xfd0]()
    //     0xa06898: sub             lr, x0, #0xfd0
    //     0xa0689c: ldr             lr, [x21, lr, lsl #3]
    //     0xa068a0: blr             lr
    // 0xa068a4: mov             x1, x0
    // 0xa068a8: ldur            x0, [fp, #-0x18]
    // 0xa068ac: ldur            x2, [fp, #-0x30]
    // 0xa068b0: r3 = LoadInt32Instr(r0)
    //     0xa068b0: sbfx            x3, x0, #1, #0x1f
    //     0xa068b4: tbz             w0, #0, #0xa068bc
    //     0xa068b8: ldur            x3, [x0, #7]
    // 0xa068bc: sub             x4, x3, x1
    // 0xa068c0: stur            x4, [fp, #-0x38]
    // 0xa068c4: cmp             x2, x4
    // 0xa068c8: b.ge            #0xa06b38
    // 0xa068cc: ldur            x3, [fp, #-8]
    // 0xa068d0: ldur            x4, [fp, #-0x20]
    // 0xa068d4: LoadField: r5 = r3->field_b
    //     0xa068d4: ldur            w5, [x3, #0xb]
    // 0xa068d8: DecompressPointer r5
    //     0xa068d8: add             x5, x5, HEAP, lsl #32
    // 0xa068dc: stur            x5, [fp, #-0x18]
    // 0xa068e0: r17 = 4221
    //     0xa068e0: mov             x17, #0x107d
    // 0xa068e4: cmp             x4, x17
    // 0xa068e8: b.ne            #0xa068fc
    // 0xa068ec: ArrayLoad: r0 = r3[0]  ; List_8
    //     0xa068ec: ldur            x0, [x3, #0x17]
    // 0xa068f0: mov             x3, x0
    // 0xa068f4: mov             x2, x4
    // 0xa068f8: b               #0xa06964
    // 0xa068fc: LoadField: r0 = r3->field_1f
    //     0xa068fc: ldur            w0, [x3, #0x1f]
    // 0xa06900: DecompressPointer r0
    //     0xa06900: add             x0, x0, HEAP, lsl #32
    // 0xa06904: r1 = LoadClassIdInstr(r0)
    //     0xa06904: ldur            x1, [x0, #-1]
    //     0xa06908: ubfx            x1, x1, #0xc, #0x14
    // 0xa0690c: r17 = 4221
    //     0xa0690c: mov             x17, #0x107d
    // 0xa06910: cmp             x1, x17
    // 0xa06914: b.ne            #0xa06924
    // 0xa06918: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xa06918: ldur            x1, [x0, #0x17]
    // 0xa0691c: mov             x0, x1
    // 0xa06920: b               #0xa0695c
    // 0xa06924: LoadField: r1 = r0->field_1f
    //     0xa06924: ldur            w1, [x0, #0x1f]
    // 0xa06928: DecompressPointer r1
    //     0xa06928: add             x1, x1, HEAP, lsl #32
    // 0xa0692c: r0 = LoadClassIdInstr(r1)
    //     0xa0692c: ldur            x0, [x1, #-1]
    //     0xa06930: ubfx            x0, x0, #0xc, #0x14
    // 0xa06934: r17 = 4221
    //     0xa06934: mov             x17, #0x107d
    // 0xa06938: cmp             x0, x17
    // 0xa0693c: b.ne            #0xa06948
    // 0xa06940: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xa06940: ldur            x0, [x1, #0x17]
    // 0xa06944: b               #0xa0695c
    // 0xa06948: r0 = LoadClassIdInstr(r1)
    //     0xa06948: ldur            x0, [x1, #-1]
    //     0xa0694c: ubfx            x0, x0, #0xc, #0x14
    // 0xa06950: r0 = GDT[cid_x0 + -0xfd0]()
    //     0xa06950: sub             lr, x0, #0xfd0
    //     0xa06954: ldr             lr, [x21, lr, lsl #3]
    //     0xa06958: blr             lr
    // 0xa0695c: mov             x3, x0
    // 0xa06960: ldur            x2, [fp, #-0x20]
    // 0xa06964: stur            x3, [fp, #-0x28]
    // 0xa06968: r17 = 4221
    //     0xa06968: mov             x17, #0x107d
    // 0xa0696c: cmp             x2, x17
    // 0xa06970: b.ne            #0xa06984
    // 0xa06974: ldur            x4, [fp, #-8]
    // 0xa06978: ArrayLoad: r0 = r4[0]  ; List_8
    //     0xa06978: ldur            x0, [x4, #0x17]
    // 0xa0697c: mov             x4, x2
    // 0xa06980: b               #0xa069ec
    // 0xa06984: ldur            x4, [fp, #-8]
    // 0xa06988: LoadField: r0 = r4->field_1f
    //     0xa06988: ldur            w0, [x4, #0x1f]
    // 0xa0698c: DecompressPointer r0
    //     0xa0698c: add             x0, x0, HEAP, lsl #32
    // 0xa06990: r1 = LoadClassIdInstr(r0)
    //     0xa06990: ldur            x1, [x0, #-1]
    //     0xa06994: ubfx            x1, x1, #0xc, #0x14
    // 0xa06998: r17 = 4221
    //     0xa06998: mov             x17, #0x107d
    // 0xa0699c: cmp             x1, x17
    // 0xa069a0: b.ne            #0xa069b0
    // 0xa069a4: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xa069a4: ldur            x1, [x0, #0x17]
    // 0xa069a8: mov             x0, x1
    // 0xa069ac: b               #0xa069e8
    // 0xa069b0: LoadField: r1 = r0->field_1f
    //     0xa069b0: ldur            w1, [x0, #0x1f]
    // 0xa069b4: DecompressPointer r1
    //     0xa069b4: add             x1, x1, HEAP, lsl #32
    // 0xa069b8: r0 = LoadClassIdInstr(r1)
    //     0xa069b8: ldur            x0, [x1, #-1]
    //     0xa069bc: ubfx            x0, x0, #0xc, #0x14
    // 0xa069c0: r17 = 4221
    //     0xa069c0: mov             x17, #0x107d
    // 0xa069c4: cmp             x0, x17
    // 0xa069c8: b.ne            #0xa069d4
    // 0xa069cc: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xa069cc: ldur            x0, [x1, #0x17]
    // 0xa069d0: b               #0xa069e8
    // 0xa069d4: r0 = LoadClassIdInstr(r1)
    //     0xa069d4: ldur            x0, [x1, #-1]
    //     0xa069d8: ubfx            x0, x0, #0xc, #0x14
    // 0xa069dc: r0 = GDT[cid_x0 + -0xfd0]()
    //     0xa069dc: sub             lr, x0, #0xfd0
    //     0xa069e0: ldr             lr, [x21, lr, lsl #3]
    //     0xa069e4: blr             lr
    // 0xa069e8: ldur            x4, [fp, #-0x20]
    // 0xa069ec: ldur            x1, [fp, #-0x18]
    // 0xa069f0: ldur            x6, [fp, #-0x30]
    // 0xa069f4: add             x3, x0, x6
    // 0xa069f8: r0 = LoadClassIdInstr(r1)
    //     0xa069f8: ldur            x0, [x1, #-1]
    //     0xa069fc: ubfx            x0, x0, #0xc, #0x14
    // 0xa06a00: str             xzr, [SP]
    // 0xa06a04: ldur            x2, [fp, #-0x28]
    // 0xa06a08: ldur            x5, [fp, #-0x10]
    // 0xa06a0c: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0xa06a0c: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0xa06a10: r0 = GDT[cid_x0 + 0x18893]()
    //     0xa06a10: mov             x17, #0x8893
    //     0xa06a14: movk            x17, #1, lsl #16
    //     0xa06a18: add             lr, x0, x17
    //     0xa06a1c: ldr             lr, [x21, lr, lsl #3]
    //     0xa06a20: blr             lr
    // 0xa06a24: ldur            x2, [fp, #-0x20]
    // 0xa06a28: r17 = 4221
    //     0xa06a28: mov             x17, #0x107d
    // 0xa06a2c: cmp             x2, x17
    // 0xa06a30: b.ne            #0xa06a44
    // 0xa06a34: ldur            x3, [fp, #-8]
    // 0xa06a38: ArrayLoad: r0 = r3[0]  ; List_8
    //     0xa06a38: ldur            x0, [x3, #0x17]
    // 0xa06a3c: mov             x1, x0
    // 0xa06a40: b               #0xa06ab0
    // 0xa06a44: ldur            x3, [fp, #-8]
    // 0xa06a48: LoadField: r0 = r3->field_1f
    //     0xa06a48: ldur            w0, [x3, #0x1f]
    // 0xa06a4c: DecompressPointer r0
    //     0xa06a4c: add             x0, x0, HEAP, lsl #32
    // 0xa06a50: r1 = LoadClassIdInstr(r0)
    //     0xa06a50: ldur            x1, [x0, #-1]
    //     0xa06a54: ubfx            x1, x1, #0xc, #0x14
    // 0xa06a58: r17 = 4221
    //     0xa06a58: mov             x17, #0x107d
    // 0xa06a5c: cmp             x1, x17
    // 0xa06a60: b.ne            #0xa06a70
    // 0xa06a64: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xa06a64: ldur            x1, [x0, #0x17]
    // 0xa06a68: mov             x0, x1
    // 0xa06a6c: b               #0xa06aa8
    // 0xa06a70: LoadField: r1 = r0->field_1f
    //     0xa06a70: ldur            w1, [x0, #0x1f]
    // 0xa06a74: DecompressPointer r1
    //     0xa06a74: add             x1, x1, HEAP, lsl #32
    // 0xa06a78: r0 = LoadClassIdInstr(r1)
    //     0xa06a78: ldur            x0, [x1, #-1]
    //     0xa06a7c: ubfx            x0, x0, #0xc, #0x14
    // 0xa06a80: r17 = 4221
    //     0xa06a80: mov             x17, #0x107d
    // 0xa06a84: cmp             x0, x17
    // 0xa06a88: b.ne            #0xa06a94
    // 0xa06a8c: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xa06a8c: ldur            x0, [x1, #0x17]
    // 0xa06a90: b               #0xa06aa8
    // 0xa06a94: r0 = LoadClassIdInstr(r1)
    //     0xa06a94: ldur            x0, [x1, #-1]
    //     0xa06a98: ubfx            x0, x0, #0xc, #0x14
    // 0xa06a9c: r0 = GDT[cid_x0 + -0xfd0]()
    //     0xa06a9c: sub             lr, x0, #0xfd0
    //     0xa06aa0: ldr             lr, [x21, lr, lsl #3]
    //     0xa06aa4: blr             lr
    // 0xa06aa8: mov             x1, x0
    // 0xa06aac: ldur            x2, [fp, #-0x20]
    // 0xa06ab0: ldur            x0, [fp, #-0x30]
    // 0xa06ab4: add             x3, x1, x0
    // 0xa06ab8: r17 = 4221
    //     0xa06ab8: mov             x17, #0x107d
    // 0xa06abc: cmp             x2, x17
    // 0xa06ac0: b.ne            #0xa06ad0
    // 0xa06ac4: ldur            x5, [fp, #-8]
    // 0xa06ac8: ArrayStore: r5[0] = r3  ; List_8
    //     0xa06ac8: stur            x3, [x5, #0x17]
    // 0xa06acc: b               #0xa06e30
    // 0xa06ad0: ldur            x5, [fp, #-8]
    // 0xa06ad4: LoadField: r0 = r5->field_1f
    //     0xa06ad4: ldur            w0, [x5, #0x1f]
    // 0xa06ad8: DecompressPointer r0
    //     0xa06ad8: add             x0, x0, HEAP, lsl #32
    // 0xa06adc: r1 = LoadClassIdInstr(r0)
    //     0xa06adc: ldur            x1, [x0, #-1]
    //     0xa06ae0: ubfx            x1, x1, #0xc, #0x14
    // 0xa06ae4: r17 = 4221
    //     0xa06ae4: mov             x17, #0x107d
    // 0xa06ae8: cmp             x1, x17
    // 0xa06aec: b.ne            #0xa06af8
    // 0xa06af0: ArrayStore: r0[0] = r3  ; List_8
    //     0xa06af0: stur            x3, [x0, #0x17]
    // 0xa06af4: b               #0xa06e30
    // 0xa06af8: LoadField: r1 = r0->field_1f
    //     0xa06af8: ldur            w1, [x0, #0x1f]
    // 0xa06afc: DecompressPointer r1
    //     0xa06afc: add             x1, x1, HEAP, lsl #32
    // 0xa06b00: r0 = LoadClassIdInstr(r1)
    //     0xa06b00: ldur            x0, [x1, #-1]
    //     0xa06b04: ubfx            x0, x0, #0xc, #0x14
    // 0xa06b08: r17 = 4221
    //     0xa06b08: mov             x17, #0x107d
    // 0xa06b0c: cmp             x0, x17
    // 0xa06b10: b.ne            #0xa06b1c
    // 0xa06b14: ArrayStore: r1[0] = r3  ; List_8
    //     0xa06b14: stur            x3, [x1, #0x17]
    // 0xa06b18: b               #0xa06e30
    // 0xa06b1c: r0 = LoadClassIdInstr(r1)
    //     0xa06b1c: ldur            x0, [x1, #-1]
    //     0xa06b20: ubfx            x0, x0, #0xc, #0x14
    // 0xa06b24: mov             x2, x3
    // 0xa06b28: r0 = GDT[cid_x0 + -0xfc6]()
    //     0xa06b28: sub             lr, x0, #0xfc6
    //     0xa06b2c: ldr             lr, [x21, lr, lsl #3]
    //     0xa06b30: blr             lr
    // 0xa06b34: b               #0xa06e30
    // 0xa06b38: ldur            x5, [fp, #-8]
    // 0xa06b3c: mov             x0, x2
    // 0xa06b40: ldur            x2, [fp, #-0x20]
    // 0xa06b44: sub             x3, x0, x4
    // 0xa06b48: stur            x3, [fp, #-0x28]
    // 0xa06b4c: LoadField: r6 = r5->field_b
    //     0xa06b4c: ldur            w6, [x5, #0xb]
    // 0xa06b50: DecompressPointer r6
    //     0xa06b50: add             x6, x6, HEAP, lsl #32
    // 0xa06b54: stur            x6, [fp, #-0x18]
    // 0xa06b58: r17 = 4221
    //     0xa06b58: mov             x17, #0x107d
    // 0xa06b5c: cmp             x2, x17
    // 0xa06b60: b.ne            #0xa06b70
    // 0xa06b64: ArrayLoad: r0 = r5[0]  ; List_8
    //     0xa06b64: ldur            x0, [x5, #0x17]
    // 0xa06b68: mov             x3, x0
    // 0xa06b6c: b               #0xa06bd8
    // 0xa06b70: LoadField: r0 = r5->field_1f
    //     0xa06b70: ldur            w0, [x5, #0x1f]
    // 0xa06b74: DecompressPointer r0
    //     0xa06b74: add             x0, x0, HEAP, lsl #32
    // 0xa06b78: r1 = LoadClassIdInstr(r0)
    //     0xa06b78: ldur            x1, [x0, #-1]
    //     0xa06b7c: ubfx            x1, x1, #0xc, #0x14
    // 0xa06b80: r17 = 4221
    //     0xa06b80: mov             x17, #0x107d
    // 0xa06b84: cmp             x1, x17
    // 0xa06b88: b.ne            #0xa06b98
    // 0xa06b8c: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xa06b8c: ldur            x1, [x0, #0x17]
    // 0xa06b90: mov             x0, x1
    // 0xa06b94: b               #0xa06bd0
    // 0xa06b98: LoadField: r1 = r0->field_1f
    //     0xa06b98: ldur            w1, [x0, #0x1f]
    // 0xa06b9c: DecompressPointer r1
    //     0xa06b9c: add             x1, x1, HEAP, lsl #32
    // 0xa06ba0: r0 = LoadClassIdInstr(r1)
    //     0xa06ba0: ldur            x0, [x1, #-1]
    //     0xa06ba4: ubfx            x0, x0, #0xc, #0x14
    // 0xa06ba8: r17 = 4221
    //     0xa06ba8: mov             x17, #0x107d
    // 0xa06bac: cmp             x0, x17
    // 0xa06bb0: b.ne            #0xa06bbc
    // 0xa06bb4: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xa06bb4: ldur            x0, [x1, #0x17]
    // 0xa06bb8: b               #0xa06bd0
    // 0xa06bbc: r0 = LoadClassIdInstr(r1)
    //     0xa06bbc: ldur            x0, [x1, #-1]
    //     0xa06bc0: ubfx            x0, x0, #0xc, #0x14
    // 0xa06bc4: r0 = GDT[cid_x0 + -0xfd0]()
    //     0xa06bc4: sub             lr, x0, #0xfd0
    //     0xa06bc8: ldr             lr, [x21, lr, lsl #3]
    //     0xa06bcc: blr             lr
    // 0xa06bd0: mov             x3, x0
    // 0xa06bd4: ldur            x2, [fp, #-0x20]
    // 0xa06bd8: stur            x3, [fp, #-0x30]
    // 0xa06bdc: r17 = 4221
    //     0xa06bdc: mov             x17, #0x107d
    // 0xa06be0: cmp             x2, x17
    // 0xa06be4: b.ne            #0xa06bfc
    // 0xa06be8: ldur            x4, [fp, #-8]
    // 0xa06bec: ArrayLoad: r0 = r4[0]  ; List_8
    //     0xa06bec: ldur            x0, [x4, #0x17]
    // 0xa06bf0: mov             x6, x4
    // 0xa06bf4: mov             x4, x2
    // 0xa06bf8: b               #0xa06c68
    // 0xa06bfc: ldur            x4, [fp, #-8]
    // 0xa06c00: LoadField: r0 = r4->field_1f
    //     0xa06c00: ldur            w0, [x4, #0x1f]
    // 0xa06c04: DecompressPointer r0
    //     0xa06c04: add             x0, x0, HEAP, lsl #32
    // 0xa06c08: r1 = LoadClassIdInstr(r0)
    //     0xa06c08: ldur            x1, [x0, #-1]
    //     0xa06c0c: ubfx            x1, x1, #0xc, #0x14
    // 0xa06c10: r17 = 4221
    //     0xa06c10: mov             x17, #0x107d
    // 0xa06c14: cmp             x1, x17
    // 0xa06c18: b.ne            #0xa06c28
    // 0xa06c1c: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xa06c1c: ldur            x1, [x0, #0x17]
    // 0xa06c20: mov             x0, x1
    // 0xa06c24: b               #0xa06c60
    // 0xa06c28: LoadField: r1 = r0->field_1f
    //     0xa06c28: ldur            w1, [x0, #0x1f]
    // 0xa06c2c: DecompressPointer r1
    //     0xa06c2c: add             x1, x1, HEAP, lsl #32
    // 0xa06c30: r0 = LoadClassIdInstr(r1)
    //     0xa06c30: ldur            x0, [x1, #-1]
    //     0xa06c34: ubfx            x0, x0, #0xc, #0x14
    // 0xa06c38: r17 = 4221
    //     0xa06c38: mov             x17, #0x107d
    // 0xa06c3c: cmp             x0, x17
    // 0xa06c40: b.ne            #0xa06c4c
    // 0xa06c44: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xa06c44: ldur            x0, [x1, #0x17]
    // 0xa06c48: b               #0xa06c60
    // 0xa06c4c: r0 = LoadClassIdInstr(r1)
    //     0xa06c4c: ldur            x0, [x1, #-1]
    //     0xa06c50: ubfx            x0, x0, #0xc, #0x14
    // 0xa06c54: r0 = GDT[cid_x0 + -0xfd0]()
    //     0xa06c54: sub             lr, x0, #0xfd0
    //     0xa06c58: ldr             lr, [x21, lr, lsl #3]
    //     0xa06c5c: blr             lr
    // 0xa06c60: ldur            x6, [fp, #-8]
    // 0xa06c64: ldur            x4, [fp, #-0x20]
    // 0xa06c68: ldur            x7, [fp, #-0x38]
    // 0xa06c6c: ldur            x1, [fp, #-0x18]
    // 0xa06c70: add             x3, x0, x7
    // 0xa06c74: r0 = LoadClassIdInstr(r1)
    //     0xa06c74: ldur            x0, [x1, #-1]
    //     0xa06c78: ubfx            x0, x0, #0xc, #0x14
    // 0xa06c7c: str             xzr, [SP]
    // 0xa06c80: ldur            x2, [fp, #-0x30]
    // 0xa06c84: ldur            x5, [fp, #-0x10]
    // 0xa06c88: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0xa06c88: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0xa06c8c: r0 = GDT[cid_x0 + 0x18893]()
    //     0xa06c8c: mov             x17, #0x8893
    //     0xa06c90: movk            x17, #1, lsl #16
    //     0xa06c94: add             lr, x0, x17
    //     0xa06c98: ldr             lr, [x21, lr, lsl #3]
    //     0xa06c9c: blr             lr
    // 0xa06ca0: ldur            x4, [fp, #-8]
    // 0xa06ca4: LoadField: r2 = r4->field_b
    //     0xa06ca4: ldur            w2, [x4, #0xb]
    // 0xa06ca8: DecompressPointer r2
    //     0xa06ca8: add             x2, x2, HEAP, lsl #32
    // 0xa06cac: ldur            x3, [fp, #-0x38]
    // 0xa06cb0: r0 = BoxInt64Instr(r3)
    //     0xa06cb0: sbfiz           x0, x3, #1, #0x1f
    //     0xa06cb4: cmp             x3, x0, asr #1
    //     0xa06cb8: b.eq            #0xa06cc4
    //     0xa06cbc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xa06cc0: stur            x3, [x0, #7]
    // 0xa06cc4: r1 = LoadClassIdInstr(r2)
    //     0xa06cc4: ldur            x1, [x2, #-1]
    //     0xa06cc8: ubfx            x1, x1, #0xc, #0x14
    // 0xa06ccc: str             x0, [SP]
    // 0xa06cd0: mov             x0, x1
    // 0xa06cd4: mov             x1, x2
    // 0xa06cd8: ldur            x3, [fp, #-0x28]
    // 0xa06cdc: ldur            x5, [fp, #-0x10]
    // 0xa06ce0: r2 = 0
    //     0xa06ce0: mov             x2, #0
    // 0xa06ce4: r4 = const [0, 0x5, 0x1, 0x5, null]
    //     0xa06ce4: ldr             x4, [PP, #0xbe0]  ; [pp+0xbe0] List(5) [0, 0x5, 0x1, 0x5, Null]
    // 0xa06ce8: r0 = GDT[cid_x0 + 0x18893]()
    //     0xa06ce8: mov             x17, #0x8893
    //     0xa06cec: movk            x17, #1, lsl #16
    //     0xa06cf0: add             lr, x0, x17
    //     0xa06cf4: ldr             lr, [x21, lr, lsl #3]
    //     0xa06cf8: blr             lr
    // 0xa06cfc: ldur            x0, [fp, #-0x20]
    // 0xa06d00: r17 = 4221
    //     0xa06d00: mov             x17, #0x107d
    // 0xa06d04: cmp             x0, x17
    // 0xa06d08: b.ne            #0xa06d1c
    // 0xa06d0c: ldur            x2, [fp, #-8]
    // 0xa06d10: ldur            x0, [fp, #-0x28]
    // 0xa06d14: ArrayStore: r2[0] = r0  ; List_8
    //     0xa06d14: stur            x0, [x2, #0x17]
    // 0xa06d18: b               #0xa06e30
    // 0xa06d1c: ldur            x2, [fp, #-8]
    // 0xa06d20: ldur            x0, [fp, #-0x28]
    // 0xa06d24: LoadField: r1 = r2->field_1f
    //     0xa06d24: ldur            w1, [x2, #0x1f]
    // 0xa06d28: DecompressPointer r1
    //     0xa06d28: add             x1, x1, HEAP, lsl #32
    // 0xa06d2c: r2 = LoadClassIdInstr(r1)
    //     0xa06d2c: ldur            x2, [x1, #-1]
    //     0xa06d30: ubfx            x2, x2, #0xc, #0x14
    // 0xa06d34: r17 = 4221
    //     0xa06d34: mov             x17, #0x107d
    // 0xa06d38: cmp             x2, x17
    // 0xa06d3c: b.ne            #0xa06d48
    // 0xa06d40: ArrayStore: r1[0] = r0  ; List_8
    //     0xa06d40: stur            x0, [x1, #0x17]
    // 0xa06d44: b               #0xa06e30
    // 0xa06d48: LoadField: r2 = r1->field_1f
    //     0xa06d48: ldur            w2, [x1, #0x1f]
    // 0xa06d4c: DecompressPointer r2
    //     0xa06d4c: add             x2, x2, HEAP, lsl #32
    // 0xa06d50: r1 = LoadClassIdInstr(r2)
    //     0xa06d50: ldur            x1, [x2, #-1]
    //     0xa06d54: ubfx            x1, x1, #0xc, #0x14
    // 0xa06d58: r17 = 4221
    //     0xa06d58: mov             x17, #0x107d
    // 0xa06d5c: cmp             x1, x17
    // 0xa06d60: b.ne            #0xa06d6c
    // 0xa06d64: ArrayStore: r2[0] = r0  ; List_8
    //     0xa06d64: stur            x0, [x2, #0x17]
    // 0xa06d68: b               #0xa06e30
    // 0xa06d6c: r1 = LoadClassIdInstr(r2)
    //     0xa06d6c: ldur            x1, [x2, #-1]
    //     0xa06d70: ubfx            x1, x1, #0xc, #0x14
    // 0xa06d74: mov             x16, x2
    // 0xa06d78: mov             x2, x1
    // 0xa06d7c: mov             x1, x16
    // 0xa06d80: mov             x16, x0
    // 0xa06d84: mov             x0, x2
    // 0xa06d88: mov             x2, x16
    // 0xa06d8c: r0 = GDT[cid_x0 + -0xfc6]()
    //     0xa06d8c: sub             lr, x0, #0xfc6
    //     0xa06d90: ldr             lr, [x21, lr, lsl #3]
    //     0xa06d94: blr             lr
    // 0xa06d98: b               #0xa06e30
    // 0xa06d9c: ldur            x2, [fp, #-8]
    // 0xa06da0: ldur            x1, [fp, #-0x10]
    // 0xa06da4: r0 = LoadClassIdInstr(r1)
    //     0xa06da4: ldur            x0, [x1, #-1]
    //     0xa06da8: ubfx            x0, x0, #0xc, #0x14
    // 0xa06dac: r0 = GDT[cid_x0 + 0x12641]()
    //     0xa06dac: mov             x17, #0x2641
    //     0xa06db0: movk            x17, #1, lsl #16
    //     0xa06db4: add             lr, x0, x17
    //     0xa06db8: ldr             lr, [x21, lr, lsl #3]
    //     0xa06dbc: blr             lr
    // 0xa06dc0: mov             x2, x0
    // 0xa06dc4: stur            x2, [fp, #-0x10]
    // 0xa06dc8: CheckStackOverflow
    //     0xa06dc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa06dcc: cmp             SP, x16
    //     0xa06dd0: b.ls            #0xa06e48
    // 0xa06dd4: r0 = LoadClassIdInstr(r2)
    //     0xa06dd4: ldur            x0, [x2, #-1]
    //     0xa06dd8: ubfx            x0, x0, #0xc, #0x14
    // 0xa06ddc: mov             x1, x2
    // 0xa06de0: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xa06de0: mov             x17, #0x845b
    //     0xa06de4: movk            x17, #1, lsl #16
    //     0xa06de8: add             lr, x0, x17
    //     0xa06dec: ldr             lr, [x21, lr, lsl #3]
    //     0xa06df0: blr             lr
    // 0xa06df4: tbnz            w0, #4, #0xa06e30
    // 0xa06df8: ldur            x2, [fp, #-0x10]
    // 0xa06dfc: r0 = LoadClassIdInstr(r2)
    //     0xa06dfc: ldur            x0, [x2, #-1]
    //     0xa06e00: ubfx            x0, x0, #0xc, #0x14
    // 0xa06e04: mov             x1, x2
    // 0xa06e08: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xa06e08: mov             x17, #0x7d4c
    //     0xa06e0c: movk            x17, #1, lsl #16
    //     0xa06e10: add             lr, x0, x17
    //     0xa06e14: ldr             lr, [x21, lr, lsl #3]
    //     0xa06e18: blr             lr
    // 0xa06e1c: ldur            x1, [fp, #-8]
    // 0xa06e20: mov             x2, x0
    // 0xa06e24: r0 = _add()
    //     0xa06e24: bl              #0x9f0a6c  ; [package:collection/src/queue_list.dart] QueueList::_add
    // 0xa06e28: ldur            x2, [fp, #-0x10]
    // 0xa06e2c: b               #0xa06dc8
    // 0xa06e30: r0 = Null
    //     0xa06e30: mov             x0, NULL
    // 0xa06e34: LeaveFrame
    //     0xa06e34: mov             SP, fp
    //     0xa06e38: ldp             fp, lr, [SP], #0x10
    // 0xa06e3c: ret
    //     0xa06e3c: ret             
    // 0xa06e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06e40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06e44: b               #0xa064e8
    // 0xa06e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa06e48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa06e4c: b               #0xa06dd4
  }
  _ add(/* No info */) {
    // ** addr: 0xa087fc, size: 0x70
    // 0xa087fc: EnterFrame
    //     0xa087fc: stp             fp, lr, [SP, #-0x10]!
    //     0xa08800: mov             fp, SP
    // 0xa08804: CheckStackOverflow
    //     0xa08804: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa08808: cmp             SP, x16
    //     0xa0880c: b.ls            #0xa08864
    // 0xa08810: ldr             x3, [fp, #0x18]
    // 0xa08814: LoadField: r2 = r3->field_7
    //     0xa08814: ldur            w2, [x3, #7]
    // 0xa08818: DecompressPointer r2
    //     0xa08818: add             x2, x2, HEAP, lsl #32
    // 0xa0881c: ldr             x0, [fp, #0x10]
    // 0xa08820: r1 = Null
    //     0xa08820: mov             x1, NULL
    // 0xa08824: cmp             w2, NULL
    // 0xa08828: b.eq            #0xa08848
    // 0xa0882c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xa0882c: ldur            w4, [x2, #0x17]
    // 0xa08830: DecompressPointer r4
    //     0xa08830: add             x4, x4, HEAP, lsl #32
    // 0xa08834: r8 = X0
    //     0xa08834: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xa08838: LoadField: r9 = r4->field_7
    //     0xa08838: ldur            x9, [x4, #7]
    // 0xa0883c: r3 = Null
    //     0xa0883c: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf980] Null
    //     0xa08840: ldr             x3, [x3, #0x980]
    // 0xa08844: blr             x9
    // 0xa08848: ldr             x1, [fp, #0x18]
    // 0xa0884c: ldr             x2, [fp, #0x10]
    // 0xa08850: r0 = _add()
    //     0xa08850: bl              #0x9f0a6c  ; [package:collection/src/queue_list.dart] QueueList::_add
    // 0xa08854: r0 = Null
    //     0xa08854: mov             x0, NULL
    // 0xa08858: LeaveFrame
    //     0xa08858: mov             SP, fp
    //     0xa0885c: ldp             fp, lr, [SP], #0x10
    // 0xa08860: ret
    //     0xa08860: ret             
    // 0xa08864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa08864: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa08868: b               #0xa08810
  }
  static QueueList<Y1> _castFrom<Y0, Y1>(QueueList<Y0>) {
    // ** addr: 0xb21df4, size: 0x90
    // 0xb21df4: EnterFrame
    //     0xb21df4: stp             fp, lr, [SP, #-0x10]!
    //     0xb21df8: mov             fp, SP
    // 0xb21dfc: AllocStack(0x8)
    //     0xb21dfc: sub             SP, SP, #8
    // 0xb21e00: SetupParameters()
    //     0xb21e00: ldur            w0, [x4, #0xf]
    //     0xb21e04: cbnz            w0, #0xb21e10
    //     0xb21e08: mov             x1, NULL
    //     0xb21e0c: b               #0xb21e1c
    //     0xb21e10: ldur            w0, [x4, #0x17]
    //     0xb21e14: add             x1, fp, w0, sxtw #2
    //     0xb21e18: ldr             x1, [x1, #0x10]
    // 0xb21e1c: CheckStackOverflow
    //     0xb21e1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21e20: cmp             SP, x16
    //     0xb21e24: b.ls            #0xb21e7c
    // 0xb21e28: r2 = Null
    //     0xb21e28: mov             x2, NULL
    // 0xb21e2c: r3 = <Y1, Y0, Y1>
    //     0xb21e2c: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf950] TypeArguments: <Y1, Y0, Y1>
    //     0xb21e30: ldr             x3, [x3, #0x950]
    // 0xb21e34: r0 = Null
    //     0xb21e34: mov             x0, NULL
    // 0xb21e38: cmp             x2, x0
    // 0xb21e3c: b.ne            #0xb21e48
    // 0xb21e40: cmp             x1, x0
    // 0xb21e44: b.eq            #0xb21e54
    // 0xb21e48: r30 = InstantiateTypeArgumentsStub
    //     0xb21e48: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0xb21e4c: LoadField: r30 = r30->field_7
    //     0xb21e4c: ldur            lr, [lr, #7]
    // 0xb21e50: blr             lr
    // 0xb21e54: mov             x1, x0
    // 0xb21e58: r0 = _CastQueueList()
    //     0xb21e58: bl              #0xb21f48  ; Allocate_CastQueueListStub -> _CastQueueList<C1X0, C1X1> (size=0x24)
    // 0xb21e5c: mov             x1, x0
    // 0xb21e60: ldr             x2, [fp, #0x10]
    // 0xb21e64: stur            x0, [fp, #-8]
    // 0xb21e68: r0 = _CastQueueList()
    //     0xb21e68: bl              #0xb21e84  ; [package:collection/src/queue_list.dart] _CastQueueList::_CastQueueList
    // 0xb21e6c: ldur            x0, [fp, #-8]
    // 0xb21e70: LeaveFrame
    //     0xb21e70: mov             SP, fp
    //     0xb21e74: ldp             fp, lr, [SP], #0x10
    // 0xb21e78: ret
    //     0xb21e78: ret             
    // 0xb21e7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21e7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21e80: b               #0xb21e28
  }
  _ toString(/* No info */) {
    // ** addr: 0x1107ec4, size: 0x40
    // 0x1107ec4: EnterFrame
    //     0x1107ec4: stp             fp, lr, [SP, #-0x10]!
    //     0x1107ec8: mov             fp, SP
    // 0x1107ecc: CheckStackOverflow
    //     0x1107ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1107ed0: cmp             SP, x16
    //     0x1107ed4: b.ls            #0x1107efc
    // 0x1107ed8: ldr             x1, [fp, #0x10]
    // 0x1107edc: r2 = "{"
    //     0x1107edc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf68] "{"
    //     0x1107ee0: ldr             x2, [x2, #0xf68]
    // 0x1107ee4: r3 = "}"
    //     0x1107ee4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf78] "}"
    //     0x1107ee8: ldr             x3, [x3, #0xf78]
    // 0x1107eec: r0 = iterableToFullString()
    //     0x1107eec: bl              #0x1107f04  ; [dart:core] Iterable::iterableToFullString
    // 0x1107ef0: LeaveFrame
    //     0x1107ef0: mov             SP, fp
    //     0x1107ef4: ldp             fp, lr, [SP], #0x10
    // 0x1107ef8: ret
    //     0x1107ef8: ret             
    // 0x1107efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1107efc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1107f00: b               #0x1107ed8
  }
  X0 [](QueueList<X0>, int) {
    // ** addr: 0x12b0e84, size: 0x294
    // 0x12b0e84: EnterFrame
    //     0x12b0e84: stp             fp, lr, [SP, #-0x10]!
    //     0x12b0e88: mov             fp, SP
    // 0x12b0e8c: AllocStack(0x28)
    //     0x12b0e8c: sub             SP, SP, #0x28
    // 0x12b0e90: CheckStackOverflow
    //     0x12b0e90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b0e94: cmp             SP, x16
    //     0x12b0e98: b.ls            #0x12b1110
    // 0x12b0e9c: ldr             x0, [fp, #0x10]
    // 0x12b0ea0: r1 = LoadInt32Instr(r0)
    //     0x12b0ea0: sbfx            x1, x0, #1, #0x1f
    //     0x12b0ea4: tbz             w0, #0, #0x12b0eac
    //     0x12b0ea8: ldur            x1, [x0, #7]
    // 0x12b0eac: stur            x1, [fp, #-8]
    // 0x12b0eb0: tbnz            x1, #0x3f, #0x12b105c
    // 0x12b0eb4: ldr             x16, [fp, #0x18]
    // 0x12b0eb8: str             x16, [SP]
    // 0x12b0ebc: r0 = length()
    //     0x12b0ebc: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0x12b0ec0: r1 = LoadInt32Instr(r0)
    //     0x12b0ec0: sbfx            x1, x0, #1, #0x1f
    //     0x12b0ec4: tbz             w0, #0, #0x12b0ecc
    //     0x12b0ec8: ldur            x1, [x0, #7]
    // 0x12b0ecc: ldur            x2, [fp, #-8]
    // 0x12b0ed0: cmp             x2, x1
    // 0x12b0ed4: b.ge            #0x12b1064
    // 0x12b0ed8: ldr             x3, [fp, #0x18]
    // 0x12b0edc: LoadField: r4 = r3->field_b
    //     0x12b0edc: ldur            w4, [x3, #0xb]
    // 0x12b0ee0: DecompressPointer r4
    //     0x12b0ee0: add             x4, x4, HEAP, lsl #32
    // 0x12b0ee4: stur            x4, [fp, #-0x10]
    // 0x12b0ee8: r0 = LoadClassIdInstr(r3)
    //     0x12b0ee8: ldur            x0, [x3, #-1]
    //     0x12b0eec: ubfx            x0, x0, #0xc, #0x14
    // 0x12b0ef0: r17 = 4221
    //     0x12b0ef0: mov             x17, #0x107d
    // 0x12b0ef4: cmp             x0, x17
    // 0x12b0ef8: b.ne            #0x12b0f14
    // 0x12b0efc: LoadField: r0 = r3->field_f
    //     0x12b0efc: ldur            x0, [x3, #0xf]
    // 0x12b0f00: mov             x1, x3
    // 0x12b0f04: mov             x3, x0
    // 0x12b0f08: mov             x0, x2
    // 0x12b0f0c: mov             x2, x4
    // 0x12b0f10: b               #0x12b0f84
    // 0x12b0f14: LoadField: r0 = r3->field_1f
    //     0x12b0f14: ldur            w0, [x3, #0x1f]
    // 0x12b0f18: DecompressPointer r0
    //     0x12b0f18: add             x0, x0, HEAP, lsl #32
    // 0x12b0f1c: r1 = LoadClassIdInstr(r0)
    //     0x12b0f1c: ldur            x1, [x0, #-1]
    //     0x12b0f20: ubfx            x1, x1, #0xc, #0x14
    // 0x12b0f24: r17 = 4221
    //     0x12b0f24: mov             x17, #0x107d
    // 0x12b0f28: cmp             x1, x17
    // 0x12b0f2c: b.ne            #0x12b0f3c
    // 0x12b0f30: LoadField: r1 = r0->field_f
    //     0x12b0f30: ldur            x1, [x0, #0xf]
    // 0x12b0f34: mov             x0, x1
    // 0x12b0f38: b               #0x12b0f74
    // 0x12b0f3c: LoadField: r1 = r0->field_1f
    //     0x12b0f3c: ldur            w1, [x0, #0x1f]
    // 0x12b0f40: DecompressPointer r1
    //     0x12b0f40: add             x1, x1, HEAP, lsl #32
    // 0x12b0f44: r0 = LoadClassIdInstr(r1)
    //     0x12b0f44: ldur            x0, [x1, #-1]
    //     0x12b0f48: ubfx            x0, x0, #0xc, #0x14
    // 0x12b0f4c: r17 = 4221
    //     0x12b0f4c: mov             x17, #0x107d
    // 0x12b0f50: cmp             x0, x17
    // 0x12b0f54: b.ne            #0x12b0f60
    // 0x12b0f58: LoadField: r0 = r1->field_f
    //     0x12b0f58: ldur            x0, [x1, #0xf]
    // 0x12b0f5c: b               #0x12b0f74
    // 0x12b0f60: r0 = LoadClassIdInstr(r1)
    //     0x12b0f60: ldur            x0, [x1, #-1]
    //     0x12b0f64: ubfx            x0, x0, #0xc, #0x14
    // 0x12b0f68: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x12b0f68: sub             lr, x0, #0xfc8
    //     0x12b0f6c: ldr             lr, [x21, lr, lsl #3]
    //     0x12b0f70: blr             lr
    // 0x12b0f74: mov             x3, x0
    // 0x12b0f78: ldr             x1, [fp, #0x18]
    // 0x12b0f7c: ldur            x2, [fp, #-0x10]
    // 0x12b0f80: ldur            x0, [fp, #-8]
    // 0x12b0f84: add             x4, x3, x0
    // 0x12b0f88: stur            x4, [fp, #-0x18]
    // 0x12b0f8c: LoadField: r0 = r1->field_b
    //     0x12b0f8c: ldur            w0, [x1, #0xb]
    // 0x12b0f90: DecompressPointer r0
    //     0x12b0f90: add             x0, x0, HEAP, lsl #32
    // 0x12b0f94: r3 = LoadClassIdInstr(r0)
    //     0x12b0f94: ldur            x3, [x0, #-1]
    //     0x12b0f98: ubfx            x3, x3, #0xc, #0x14
    // 0x12b0f9c: str             x0, [SP]
    // 0x12b0fa0: mov             x0, x3
    // 0x12b0fa4: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12b0fa4: mov             x17, #0xf078
    //     0x12b0fa8: add             lr, x0, x17
    //     0x12b0fac: ldr             lr, [x21, lr, lsl #3]
    //     0x12b0fb0: blr             lr
    // 0x12b0fb4: r1 = LoadInt32Instr(r0)
    //     0x12b0fb4: sbfx            x1, x0, #1, #0x1f
    //     0x12b0fb8: tbz             w0, #0, #0x12b0fc0
    //     0x12b0fbc: ldur            x1, [x0, #7]
    // 0x12b0fc0: sub             x0, x1, #1
    // 0x12b0fc4: ldur            x1, [fp, #-0x18]
    // 0x12b0fc8: and             x2, x1, x0
    // 0x12b0fcc: r0 = BoxInt64Instr(r2)
    //     0x12b0fcc: sbfiz           x0, x2, #1, #0x1f
    //     0x12b0fd0: cmp             x2, x0, asr #1
    //     0x12b0fd4: b.eq            #0x12b0fe0
    //     0x12b0fd8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12b0fdc: stur            x2, [x0, #7]
    // 0x12b0fe0: mov             x1, x0
    // 0x12b0fe4: ldur            x0, [fp, #-0x10]
    // 0x12b0fe8: r2 = LoadClassIdInstr(r0)
    //     0x12b0fe8: ldur            x2, [x0, #-1]
    //     0x12b0fec: ubfx            x2, x2, #0xc, #0x14
    // 0x12b0ff0: stp             x1, x0, [SP]
    // 0x12b0ff4: mov             x0, x2
    // 0x12b0ff8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12b0ff8: sub             lr, x0, #0xdfd
    //     0x12b0ffc: ldr             lr, [x21, lr, lsl #3]
    //     0x12b1000: blr             lr
    // 0x12b1004: mov             x3, x0
    // 0x12b1008: stur            x3, [fp, #-0x10]
    // 0x12b100c: cmp             w3, NULL
    // 0x12b1010: b.ne            #0x12b104c
    // 0x12b1014: ldr             x0, [fp, #0x18]
    // 0x12b1018: LoadField: r2 = r0->field_7
    //     0x12b1018: ldur            w2, [x0, #7]
    // 0x12b101c: DecompressPointer r2
    //     0x12b101c: add             x2, x2, HEAP, lsl #32
    // 0x12b1020: mov             x0, x3
    // 0x12b1024: r1 = Null
    //     0x12b1024: mov             x1, NULL
    // 0x12b1028: cmp             w2, NULL
    // 0x12b102c: b.eq            #0x12b104c
    // 0x12b1030: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12b1030: ldur            w4, [x2, #0x17]
    // 0x12b1034: DecompressPointer r4
    //     0x12b1034: add             x4, x4, HEAP, lsl #32
    // 0x12b1038: r8 = X0
    //     0x12b1038: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12b103c: LoadField: r9 = r4->field_7
    //     0x12b103c: ldur            x9, [x4, #7]
    // 0x12b1040: r3 = Null
    //     0x12b1040: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf8f0] Null
    //     0x12b1044: ldr             x3, [x3, #0x8f0]
    // 0x12b1048: blr             x9
    // 0x12b104c: ldur            x0, [fp, #-0x10]
    // 0x12b1050: LeaveFrame
    //     0x12b1050: mov             SP, fp
    //     0x12b1054: ldp             fp, lr, [SP], #0x10
    // 0x12b1058: ret
    //     0x12b1058: ret             
    // 0x12b105c: ldr             x0, [fp, #0x18]
    // 0x12b1060: b               #0x12b1068
    // 0x12b1064: ldr             x0, [fp, #0x18]
    // 0x12b1068: ldr             x3, [fp, #0x10]
    // 0x12b106c: r1 = Null
    //     0x12b106c: mov             x1, NULL
    // 0x12b1070: r2 = 10
    //     0x12b1070: mov             x2, #0xa
    // 0x12b1074: r0 = AllocateArray()
    //     0x12b1074: bl              #0x13df928  ; AllocateArrayStub
    // 0x12b1078: stur            x0, [fp, #-0x10]
    // 0x12b107c: r16 = "Index "
    //     0x12b107c: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf8d0] "Index "
    //     0x12b1080: ldr             x16, [x16, #0x8d0]
    // 0x12b1084: StoreField: r0->field_f = r16
    //     0x12b1084: stur            w16, [x0, #0xf]
    // 0x12b1088: ldr             x1, [fp, #0x10]
    // 0x12b108c: StoreField: r0->field_13 = r1
    //     0x12b108c: stur            w1, [x0, #0x13]
    // 0x12b1090: r16 = " must be in the range [0.."
    //     0x12b1090: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf8d8] " must be in the range [0.."
    //     0x12b1094: ldr             x16, [x16, #0x8d8]
    // 0x12b1098: ArrayStore: r0[0] = r16  ; List_4
    //     0x12b1098: stur            w16, [x0, #0x17]
    // 0x12b109c: ldr             x16, [fp, #0x18]
    // 0x12b10a0: str             x16, [SP]
    // 0x12b10a4: r0 = length()
    //     0x12b10a4: bl              #0xc15fe0  ; [package:collection/src/queue_list.dart] QueueList::length
    // 0x12b10a8: ldur            x1, [fp, #-0x10]
    // 0x12b10ac: ArrayStore: r1[3] = r0  ; List_4
    //     0x12b10ac: add             x25, x1, #0x1b
    //     0x12b10b0: str             w0, [x25]
    //     0x12b10b4: tbz             w0, #0, #0x12b10d0
    //     0x12b10b8: ldurb           w16, [x1, #-1]
    //     0x12b10bc: ldurb           w17, [x0, #-1]
    //     0x12b10c0: and             x16, x17, x16, lsr #2
    //     0x12b10c4: tst             x16, HEAP, lsr #32
    //     0x12b10c8: b.eq            #0x12b10d0
    //     0x12b10cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x12b10d0: ldur            x0, [fp, #-0x10]
    // 0x12b10d4: r16 = ")."
    //     0x12b10d4: add             x16, PP, #0x16, lsl #12  ; [pp+0x16a78] ")."
    //     0x12b10d8: ldr             x16, [x16, #0xa78]
    // 0x12b10dc: StoreField: r0->field_1f = r16
    //     0x12b10dc: stur            w16, [x0, #0x1f]
    // 0x12b10e0: str             x0, [SP]
    // 0x12b10e4: r0 = _interpolate()
    //     0x12b10e4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x12b10e8: stur            x0, [fp, #-0x10]
    // 0x12b10ec: r0 = RangeError()
    //     0x12b10ec: bl              #0x7db570  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0x12b10f0: mov             x1, x0
    // 0x12b10f4: ldur            x0, [fp, #-0x10]
    // 0x12b10f8: ArrayStore: r1[0] = r0  ; List_4
    //     0x12b10f8: stur            w0, [x1, #0x17]
    // 0x12b10fc: r0 = false
    //     0x12b10fc: add             x0, NULL, #0x30  ; false
    // 0x12b1100: StoreField: r1->field_b = r0
    //     0x12b1100: stur            w0, [x1, #0xb]
    // 0x12b1104: mov             x0, x1
    // 0x12b1108: r0 = Throw()
    //     0x12b1108: bl              #0x13ddb2c  ; ThrowStub
    // 0x12b110c: brk             #0
    // 0x12b1110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b1110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b1114: b               #0x12b0e9c
  }
  set _ _head=(/* No info */) {
    // ** addr: 0x12b6894, size: 0xc
    // 0x12b6894: StoreField: r1->field_f = r2
    //     0x12b6894: stur            x2, [x1, #0xf]
    // 0x12b6898: r0 = Null
    //     0x12b6898: mov             x0, NULL
    // 0x12b689c: ret
    //     0x12b689c: ret             
  }
  set _ _tail=(/* No info */) {
    // ** addr: 0x12b6a04, size: 0xc
    // 0x12b6a04: ArrayStore: r1[0] = r2  ; List_8
    //     0x12b6a04: stur            x2, [x1, #0x17]
    // 0x12b6a08: r0 = Null
    //     0x12b6a08: mov             x0, NULL
    // 0x12b6a0c: ret
    //     0x12b6a0c: ret             
  }
  int _tail(QueueList<X0>) {
    // ** addr: 0x12b70c4, size: 0x8
    // 0x12b70c4: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x12b70c4: ldur            x0, [x1, #0x17]
    // 0x12b70c8: ret
    //     0x12b70c8: ret             
  }
  _ removeFirst(/* No info */) {
    // ** addr: 0x12e6208, size: 0x188
    // 0x12e6208: EnterFrame
    //     0x12e6208: stp             fp, lr, [SP, #-0x10]!
    //     0x12e620c: mov             fp, SP
    // 0x12e6210: AllocStack(0x30)
    //     0x12e6210: sub             SP, SP, #0x30
    // 0x12e6214: SetupParameters(QueueList<X0> this /* r1 => r2, fp-0x8 */)
    //     0x12e6214: mov             x2, x1
    //     0x12e6218: stur            x1, [fp, #-8]
    // 0x12e621c: CheckStackOverflow
    //     0x12e621c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12e6220: cmp             SP, x16
    //     0x12e6224: b.ls            #0x12e6388
    // 0x12e6228: LoadField: r3 = r2->field_f
    //     0x12e6228: ldur            x3, [x2, #0xf]
    // 0x12e622c: ArrayLoad: r0 = r2[0]  ; List_8
    //     0x12e622c: ldur            x0, [x2, #0x17]
    // 0x12e6230: cmp             x3, x0
    // 0x12e6234: b.eq            #0x12e636c
    // 0x12e6238: LoadField: r4 = r2->field_b
    //     0x12e6238: ldur            w4, [x2, #0xb]
    // 0x12e623c: DecompressPointer r4
    //     0x12e623c: add             x4, x4, HEAP, lsl #32
    // 0x12e6240: r0 = BoxInt64Instr(r3)
    //     0x12e6240: sbfiz           x0, x3, #1, #0x1f
    //     0x12e6244: cmp             x3, x0, asr #1
    //     0x12e6248: b.eq            #0x12e6254
    //     0x12e624c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e6250: stur            x3, [x0, #7]
    // 0x12e6254: r1 = LoadClassIdInstr(r4)
    //     0x12e6254: ldur            x1, [x4, #-1]
    //     0x12e6258: ubfx            x1, x1, #0xc, #0x14
    // 0x12e625c: stp             x0, x4, [SP]
    // 0x12e6260: mov             x0, x1
    // 0x12e6264: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x12e6264: sub             lr, x0, #0xdfd
    //     0x12e6268: ldr             lr, [x21, lr, lsl #3]
    //     0x12e626c: blr             lr
    // 0x12e6270: mov             x3, x0
    // 0x12e6274: stur            x3, [fp, #-0x10]
    // 0x12e6278: cmp             w3, NULL
    // 0x12e627c: b.ne            #0x12e62b8
    // 0x12e6280: ldur            x4, [fp, #-8]
    // 0x12e6284: LoadField: r2 = r4->field_7
    //     0x12e6284: ldur            w2, [x4, #7]
    // 0x12e6288: DecompressPointer r2
    //     0x12e6288: add             x2, x2, HEAP, lsl #32
    // 0x12e628c: mov             x0, x3
    // 0x12e6290: r1 = Null
    //     0x12e6290: mov             x1, NULL
    // 0x12e6294: cmp             w2, NULL
    // 0x12e6298: b.eq            #0x12e62b8
    // 0x12e629c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12e629c: ldur            w4, [x2, #0x17]
    // 0x12e62a0: DecompressPointer r4
    //     0x12e62a0: add             x4, x4, HEAP, lsl #32
    // 0x12e62a4: r8 = X0
    //     0x12e62a4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12e62a8: LoadField: r9 = r4->field_7
    //     0x12e62a8: ldur            x9, [x4, #7]
    // 0x12e62ac: r3 = Null
    //     0x12e62ac: add             x3, PP, #0xc9, lsl #12  ; [pp+0xc97c0] Null
    //     0x12e62b0: ldr             x3, [x3, #0x7c0]
    // 0x12e62b4: blr             x9
    // 0x12e62b8: ldur            x2, [fp, #-8]
    // 0x12e62bc: LoadField: r3 = r2->field_b
    //     0x12e62bc: ldur            w3, [x2, #0xb]
    // 0x12e62c0: DecompressPointer r3
    //     0x12e62c0: add             x3, x3, HEAP, lsl #32
    // 0x12e62c4: LoadField: r4 = r2->field_f
    //     0x12e62c4: ldur            x4, [x2, #0xf]
    // 0x12e62c8: r0 = BoxInt64Instr(r4)
    //     0x12e62c8: sbfiz           x0, x4, #1, #0x1f
    //     0x12e62cc: cmp             x4, x0, asr #1
    //     0x12e62d0: b.eq            #0x12e62dc
    //     0x12e62d4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12e62d8: stur            x4, [x0, #7]
    // 0x12e62dc: r1 = LoadClassIdInstr(r3)
    //     0x12e62dc: ldur            x1, [x3, #-1]
    //     0x12e62e0: ubfx            x1, x1, #0xc, #0x14
    // 0x12e62e4: stp             x0, x3, [SP, #8]
    // 0x12e62e8: str             NULL, [SP]
    // 0x12e62ec: mov             x0, x1
    // 0x12e62f0: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0x12e62f0: mov             x17, #0x8dc8
    //     0x12e62f4: movk            x17, #1, lsl #16
    //     0x12e62f8: add             lr, x0, x17
    //     0x12e62fc: ldr             lr, [x21, lr, lsl #3]
    //     0x12e6300: blr             lr
    // 0x12e6304: ldur            x1, [fp, #-8]
    // 0x12e6308: LoadField: r0 = r1->field_f
    //     0x12e6308: ldur            x0, [x1, #0xf]
    // 0x12e630c: add             x2, x0, #1
    // 0x12e6310: stur            x2, [fp, #-0x18]
    // 0x12e6314: LoadField: r0 = r1->field_b
    //     0x12e6314: ldur            w0, [x1, #0xb]
    // 0x12e6318: DecompressPointer r0
    //     0x12e6318: add             x0, x0, HEAP, lsl #32
    // 0x12e631c: r3 = LoadClassIdInstr(r0)
    //     0x12e631c: ldur            x3, [x0, #-1]
    //     0x12e6320: ubfx            x3, x3, #0xc, #0x14
    // 0x12e6324: str             x0, [SP]
    // 0x12e6328: mov             x0, x3
    // 0x12e632c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x12e632c: mov             x17, #0xf078
    //     0x12e6330: add             lr, x0, x17
    //     0x12e6334: ldr             lr, [x21, lr, lsl #3]
    //     0x12e6338: blr             lr
    // 0x12e633c: r1 = LoadInt32Instr(r0)
    //     0x12e633c: sbfx            x1, x0, #1, #0x1f
    //     0x12e6340: tbz             w0, #0, #0x12e6348
    //     0x12e6344: ldur            x1, [x0, #7]
    // 0x12e6348: sub             x0, x1, #1
    // 0x12e634c: ldur            x1, [fp, #-0x18]
    // 0x12e6350: and             x2, x1, x0
    // 0x12e6354: ldur            x0, [fp, #-8]
    // 0x12e6358: StoreField: r0->field_f = r2
    //     0x12e6358: stur            x2, [x0, #0xf]
    // 0x12e635c: ldur            x0, [fp, #-0x10]
    // 0x12e6360: LeaveFrame
    //     0x12e6360: mov             SP, fp
    //     0x12e6364: ldp             fp, lr, [SP], #0x10
    // 0x12e6368: ret
    //     0x12e6368: ret             
    // 0x12e636c: r0 = StateError()
    //     0x12e636c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x12e6370: mov             x1, x0
    // 0x12e6374: r0 = "No element"
    //     0x12e6374: ldr             x0, [PP, #0xb78]  ; [pp+0xb78] "No element"
    // 0x12e6378: StoreField: r1->field_b = r0
    //     0x12e6378: stur            w0, [x1, #0xb]
    // 0x12e637c: mov             x0, x1
    // 0x12e6380: r0 = Throw()
    //     0x12e6380: bl              #0x13ddb2c  ; ThrowStub
    // 0x12e6384: brk             #0
    // 0x12e6388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12e6388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12e638c: b               #0x12e6228
  }
}

// class id: 4222, size: 0x24, field offset: 0x20
class _CastQueueList<C1X0, C1X1> extends QueueList<C1X0> {

  _ _CastQueueList(/* No info */) {
    // ** addr: 0xb21e84, size: 0xc4
    // 0xb21e84: EnterFrame
    //     0xb21e84: stp             fp, lr, [SP, #-0x10]!
    //     0xb21e88: mov             fp, SP
    // 0xb21e8c: AllocStack(0x18)
    //     0xb21e8c: sub             SP, SP, #0x18
    // 0xb21e90: SetupParameters(_CastQueueList<C1X0, C1X1> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xb21e90: stur            x1, [fp, #-8]
    //     0xb21e94: mov             x16, x2
    //     0xb21e98: mov             x2, x1
    //     0xb21e9c: mov             x1, x16
    // 0xb21ea0: CheckStackOverflow
    //     0xb21ea0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21ea4: cmp             SP, x16
    //     0xb21ea8: b.ls            #0xb21f40
    // 0xb21eac: mov             x0, x1
    // 0xb21eb0: StoreField: r2->field_1f = r0
    //     0xb21eb0: stur            w0, [x2, #0x1f]
    //     0xb21eb4: ldurb           w16, [x2, #-1]
    //     0xb21eb8: ldurb           w17, [x0, #-1]
    //     0xb21ebc: and             x16, x17, x16, lsr #2
    //     0xb21ec0: tst             x16, HEAP, lsr #32
    //     0xb21ec4: b.eq            #0xb21ecc
    //     0xb21ec8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb21ecc: LoadField: r0 = r2->field_7
    //     0xb21ecc: ldur            w0, [x2, #7]
    // 0xb21ed0: DecompressPointer r0
    //     0xb21ed0: add             x0, x0, HEAP, lsl #32
    // 0xb21ed4: LoadField: r3 = r1->field_b
    //     0xb21ed4: ldur            w3, [x1, #0xb]
    // 0xb21ed8: DecompressPointer r3
    //     0xb21ed8: add             x3, x3, HEAP, lsl #32
    // 0xb21edc: r1 = LoadClassIdInstr(r3)
    //     0xb21edc: ldur            x1, [x3, #-1]
    //     0xb21ee0: ubfx            x1, x1, #0xc, #0x14
    // 0xb21ee4: stp             x3, x0, [SP]
    // 0xb21ee8: mov             x0, x1
    // 0xb21eec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb21eec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb21ef0: r0 = GDT[cid_x0 + 0x13106]()
    //     0xb21ef0: mov             x17, #0x3106
    //     0xb21ef4: movk            x17, #1, lsl #16
    //     0xb21ef8: add             lr, x0, x17
    //     0xb21efc: ldr             lr, [x21, lr, lsl #3]
    //     0xb21f00: blr             lr
    // 0xb21f04: ldur            x2, [fp, #-8]
    // 0xb21f08: r1 = -1
    //     0xb21f08: mov             x1, #-1
    // 0xb21f0c: StoreField: r2->field_f = r1
    //     0xb21f0c: stur            x1, [x2, #0xf]
    // 0xb21f10: ArrayStore: r2[0] = r1  ; List_8
    //     0xb21f10: stur            x1, [x2, #0x17]
    // 0xb21f14: StoreField: r2->field_b = r0
    //     0xb21f14: stur            w0, [x2, #0xb]
    //     0xb21f18: ldurb           w16, [x2, #-1]
    //     0xb21f1c: ldurb           w17, [x0, #-1]
    //     0xb21f20: and             x16, x17, x16, lsr #2
    //     0xb21f24: tst             x16, HEAP, lsr #32
    //     0xb21f28: b.eq            #0xb21f30
    //     0xb21f2c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb21f30: r0 = Null
    //     0xb21f30: mov             x0, NULL
    // 0xb21f34: LeaveFrame
    //     0xb21f34: mov             SP, fp
    //     0xb21f38: ldp             fp, lr, [SP], #0x10
    // 0xb21f3c: ret
    //     0xb21f3c: ret             
    // 0xb21f40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21f40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21f44: b               #0xb21eac
  }
  set _ _head=(/* No info */) {
    // ** addr: 0x12b6808, size: 0x8c
    // 0x12b6808: EnterFrame
    //     0x12b6808: stp             fp, lr, [SP, #-0x10]!
    //     0x12b680c: mov             fp, SP
    // 0x12b6810: CheckStackOverflow
    //     0x12b6810: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b6814: cmp             SP, x16
    //     0x12b6818: b.ls            #0x12b688c
    // 0x12b681c: LoadField: r0 = r1->field_1f
    //     0x12b681c: ldur            w0, [x1, #0x1f]
    // 0x12b6820: DecompressPointer r0
    //     0x12b6820: add             x0, x0, HEAP, lsl #32
    // 0x12b6824: r1 = LoadClassIdInstr(r0)
    //     0x12b6824: ldur            x1, [x0, #-1]
    //     0x12b6828: ubfx            x1, x1, #0xc, #0x14
    // 0x12b682c: r17 = 4221
    //     0x12b682c: mov             x17, #0x107d
    // 0x12b6830: cmp             x1, x17
    // 0x12b6834: b.ne            #0x12b6840
    // 0x12b6838: StoreField: r0->field_f = rZR
    //     0x12b6838: stur            xzr, [x0, #0xf]
    // 0x12b683c: b               #0x12b687c
    // 0x12b6840: LoadField: r1 = r0->field_1f
    //     0x12b6840: ldur            w1, [x0, #0x1f]
    // 0x12b6844: DecompressPointer r1
    //     0x12b6844: add             x1, x1, HEAP, lsl #32
    // 0x12b6848: r0 = LoadClassIdInstr(r1)
    //     0x12b6848: ldur            x0, [x1, #-1]
    //     0x12b684c: ubfx            x0, x0, #0xc, #0x14
    // 0x12b6850: r17 = 4221
    //     0x12b6850: mov             x17, #0x107d
    // 0x12b6854: cmp             x0, x17
    // 0x12b6858: b.ne            #0x12b6864
    // 0x12b685c: StoreField: r1->field_f = rZR
    //     0x12b685c: stur            xzr, [x1, #0xf]
    // 0x12b6860: b               #0x12b687c
    // 0x12b6864: r0 = LoadClassIdInstr(r1)
    //     0x12b6864: ldur            x0, [x1, #-1]
    //     0x12b6868: ubfx            x0, x0, #0xc, #0x14
    // 0x12b686c: r2 = 0
    //     0x12b686c: mov             x2, #0
    // 0x12b6870: r0 = GDT[cid_x0 + -0xf9d]()
    //     0x12b6870: sub             lr, x0, #0xf9d
    //     0x12b6874: ldr             lr, [x21, lr, lsl #3]
    //     0x12b6878: blr             lr
    // 0x12b687c: r0 = 0
    //     0x12b687c: mov             x0, #0
    // 0x12b6880: LeaveFrame
    //     0x12b6880: mov             SP, fp
    //     0x12b6884: ldp             fp, lr, [SP], #0x10
    // 0x12b6888: ret
    //     0x12b6888: ret             
    // 0x12b688c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b688c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b6890: b               #0x12b681c
  }
  set _ _tail=(/* No info */) {
    // ** addr: 0x12b696c, size: 0x98
    // 0x12b696c: EnterFrame
    //     0x12b696c: stp             fp, lr, [SP, #-0x10]!
    //     0x12b6970: mov             fp, SP
    // 0x12b6974: AllocStack(0x8)
    //     0x12b6974: sub             SP, SP, #8
    // 0x12b6978: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0x12b6978: mov             x3, x2
    //     0x12b697c: stur            x2, [fp, #-8]
    // 0x12b6980: CheckStackOverflow
    //     0x12b6980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b6984: cmp             SP, x16
    //     0x12b6988: b.ls            #0x12b69fc
    // 0x12b698c: LoadField: r0 = r1->field_1f
    //     0x12b698c: ldur            w0, [x1, #0x1f]
    // 0x12b6990: DecompressPointer r0
    //     0x12b6990: add             x0, x0, HEAP, lsl #32
    // 0x12b6994: r1 = LoadClassIdInstr(r0)
    //     0x12b6994: ldur            x1, [x0, #-1]
    //     0x12b6998: ubfx            x1, x1, #0xc, #0x14
    // 0x12b699c: r17 = 4221
    //     0x12b699c: mov             x17, #0x107d
    // 0x12b69a0: cmp             x1, x17
    // 0x12b69a4: b.ne            #0x12b69b0
    // 0x12b69a8: ArrayStore: r0[0] = r3  ; List_8
    //     0x12b69a8: stur            x3, [x0, #0x17]
    // 0x12b69ac: b               #0x12b69ec
    // 0x12b69b0: LoadField: r1 = r0->field_1f
    //     0x12b69b0: ldur            w1, [x0, #0x1f]
    // 0x12b69b4: DecompressPointer r1
    //     0x12b69b4: add             x1, x1, HEAP, lsl #32
    // 0x12b69b8: r0 = LoadClassIdInstr(r1)
    //     0x12b69b8: ldur            x0, [x1, #-1]
    //     0x12b69bc: ubfx            x0, x0, #0xc, #0x14
    // 0x12b69c0: r17 = 4221
    //     0x12b69c0: mov             x17, #0x107d
    // 0x12b69c4: cmp             x0, x17
    // 0x12b69c8: b.ne            #0x12b69d4
    // 0x12b69cc: ArrayStore: r1[0] = r3  ; List_8
    //     0x12b69cc: stur            x3, [x1, #0x17]
    // 0x12b69d0: b               #0x12b69ec
    // 0x12b69d4: r0 = LoadClassIdInstr(r1)
    //     0x12b69d4: ldur            x0, [x1, #-1]
    //     0x12b69d8: ubfx            x0, x0, #0xc, #0x14
    // 0x12b69dc: mov             x2, x3
    // 0x12b69e0: r0 = GDT[cid_x0 + -0xfc6]()
    //     0x12b69e0: sub             lr, x0, #0xfc6
    //     0x12b69e4: ldr             lr, [x21, lr, lsl #3]
    //     0x12b69e8: blr             lr
    // 0x12b69ec: ldur            x0, [fp, #-8]
    // 0x12b69f0: LeaveFrame
    //     0x12b69f0: mov             SP, fp
    //     0x12b69f4: ldp             fp, lr, [SP], #0x10
    // 0x12b69f8: ret
    //     0x12b69f8: ret             
    // 0x12b69fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b69fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b6a00: b               #0x12b698c
  }
  get _ _head(/* No info */) {
    // ** addr: 0x12b6a10, size: 0x94
    // 0x12b6a10: EnterFrame
    //     0x12b6a10: stp             fp, lr, [SP, #-0x10]!
    //     0x12b6a14: mov             fp, SP
    // 0x12b6a18: CheckStackOverflow
    //     0x12b6a18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b6a1c: cmp             SP, x16
    //     0x12b6a20: b.ls            #0x12b6a9c
    // 0x12b6a24: LoadField: r0 = r1->field_1f
    //     0x12b6a24: ldur            w0, [x1, #0x1f]
    // 0x12b6a28: DecompressPointer r0
    //     0x12b6a28: add             x0, x0, HEAP, lsl #32
    // 0x12b6a2c: r1 = LoadClassIdInstr(r0)
    //     0x12b6a2c: ldur            x1, [x0, #-1]
    //     0x12b6a30: ubfx            x1, x1, #0xc, #0x14
    // 0x12b6a34: r17 = 4221
    //     0x12b6a34: mov             x17, #0x107d
    // 0x12b6a38: cmp             x1, x17
    // 0x12b6a3c: b.ne            #0x12b6a4c
    // 0x12b6a40: LoadField: r1 = r0->field_f
    //     0x12b6a40: ldur            x1, [x0, #0xf]
    // 0x12b6a44: mov             x0, x1
    // 0x12b6a48: b               #0x12b6a90
    // 0x12b6a4c: LoadField: r1 = r0->field_1f
    //     0x12b6a4c: ldur            w1, [x0, #0x1f]
    // 0x12b6a50: DecompressPointer r1
    //     0x12b6a50: add             x1, x1, HEAP, lsl #32
    // 0x12b6a54: r0 = LoadClassIdInstr(r1)
    //     0x12b6a54: ldur            x0, [x1, #-1]
    //     0x12b6a58: ubfx            x0, x0, #0xc, #0x14
    // 0x12b6a5c: r17 = 4221
    //     0x12b6a5c: mov             x17, #0x107d
    // 0x12b6a60: cmp             x0, x17
    // 0x12b6a64: b.ne            #0x12b6a74
    // 0x12b6a68: LoadField: r0 = r1->field_f
    //     0x12b6a68: ldur            x0, [x1, #0xf]
    // 0x12b6a6c: mov             x1, x0
    // 0x12b6a70: b               #0x12b6a8c
    // 0x12b6a74: r0 = LoadClassIdInstr(r1)
    //     0x12b6a74: ldur            x0, [x1, #-1]
    //     0x12b6a78: ubfx            x0, x0, #0xc, #0x14
    // 0x12b6a7c: r0 = GDT[cid_x0 + -0xfc8]()
    //     0x12b6a7c: sub             lr, x0, #0xfc8
    //     0x12b6a80: ldr             lr, [x21, lr, lsl #3]
    //     0x12b6a84: blr             lr
    // 0x12b6a88: mov             x1, x0
    // 0x12b6a8c: mov             x0, x1
    // 0x12b6a90: LeaveFrame
    //     0x12b6a90: mov             SP, fp
    //     0x12b6a94: ldp             fp, lr, [SP], #0x10
    // 0x12b6a98: ret
    //     0x12b6a98: ret             
    // 0x12b6a9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b6a9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b6aa0: b               #0x12b6a24
  }
  get _ _tail(/* No info */) {
    // ** addr: 0x12b7030, size: 0x94
    // 0x12b7030: EnterFrame
    //     0x12b7030: stp             fp, lr, [SP, #-0x10]!
    //     0x12b7034: mov             fp, SP
    // 0x12b7038: CheckStackOverflow
    //     0x12b7038: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b703c: cmp             SP, x16
    //     0x12b7040: b.ls            #0x12b70bc
    // 0x12b7044: LoadField: r0 = r1->field_1f
    //     0x12b7044: ldur            w0, [x1, #0x1f]
    // 0x12b7048: DecompressPointer r0
    //     0x12b7048: add             x0, x0, HEAP, lsl #32
    // 0x12b704c: r1 = LoadClassIdInstr(r0)
    //     0x12b704c: ldur            x1, [x0, #-1]
    //     0x12b7050: ubfx            x1, x1, #0xc, #0x14
    // 0x12b7054: r17 = 4221
    //     0x12b7054: mov             x17, #0x107d
    // 0x12b7058: cmp             x1, x17
    // 0x12b705c: b.ne            #0x12b706c
    // 0x12b7060: ArrayLoad: r1 = r0[0]  ; List_8
    //     0x12b7060: ldur            x1, [x0, #0x17]
    // 0x12b7064: mov             x0, x1
    // 0x12b7068: b               #0x12b70b0
    // 0x12b706c: LoadField: r1 = r0->field_1f
    //     0x12b706c: ldur            w1, [x0, #0x1f]
    // 0x12b7070: DecompressPointer r1
    //     0x12b7070: add             x1, x1, HEAP, lsl #32
    // 0x12b7074: r0 = LoadClassIdInstr(r1)
    //     0x12b7074: ldur            x0, [x1, #-1]
    //     0x12b7078: ubfx            x0, x0, #0xc, #0x14
    // 0x12b707c: r17 = 4221
    //     0x12b707c: mov             x17, #0x107d
    // 0x12b7080: cmp             x0, x17
    // 0x12b7084: b.ne            #0x12b7094
    // 0x12b7088: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x12b7088: ldur            x0, [x1, #0x17]
    // 0x12b708c: mov             x1, x0
    // 0x12b7090: b               #0x12b70ac
    // 0x12b7094: r0 = LoadClassIdInstr(r1)
    //     0x12b7094: ldur            x0, [x1, #-1]
    //     0x12b7098: ubfx            x0, x0, #0xc, #0x14
    // 0x12b709c: r0 = GDT[cid_x0 + -0xfd0]()
    //     0x12b709c: sub             lr, x0, #0xfd0
    //     0x12b70a0: ldr             lr, [x21, lr, lsl #3]
    //     0x12b70a4: blr             lr
    // 0x12b70a8: mov             x1, x0
    // 0x12b70ac: mov             x0, x1
    // 0x12b70b0: LeaveFrame
    //     0x12b70b0: mov             SP, fp
    //     0x12b70b4: ldp             fp, lr, [SP], #0x10
    // 0x12b70b8: ret
    //     0x12b70b8: ret             
    // 0x12b70bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b70bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b70c0: b               #0x12b7044
  }
}
