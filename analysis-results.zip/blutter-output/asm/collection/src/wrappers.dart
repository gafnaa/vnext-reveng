// lib: , url: package:collection/src/wrappers.dart

// class id: 1048659, size: 0x8
class :: {
}

// class id: 3564, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class _DelegatingIterableBase<X0> extends Object
    implements Iterable<X0> {

  int length(_DelegatingIterableBase<X0>) {
    // ** addr: 0xcce3f4, size: 0x2c
    // 0xcce3f4: ldr             x1, [SP]
    // 0xcce3f8: LoadField: r2 = r1->field_b
    //     0xcce3f8: ldur            w2, [x1, #0xb]
    // 0xcce3fc: DecompressPointer r2
    //     0xcce3fc: add             x2, x2, HEAP, lsl #32
    // 0xcce400: LoadField: r0 = r2->field_b
    //     0xcce400: ldur            w0, [x2, #0xb]
    // 0xcce404: ret
    //     0xcce404: ret             
  }
  dynamic contains(dynamic) {
    // ** addr: 0xb29b50, size: 0x3c
    // 0xb29b50: EnterFrame
    //     0xb29b50: stp             fp, lr, [SP, #-0x10]!
    //     0xb29b54: mov             fp, SP
    // 0xb29b58: ldr             x2, [fp, #0x10]
    // 0xb29b5c: r1 = Function 'contains':.
    //     0xb29b5c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2c48] AnonymousClosure: (0x827dd0), in [package:collection/src/wrappers.dart] _DelegatingIterableBase::contains (0xb58afc)
    //     0xb29b60: ldr             x1, [x1, #0xc48]
    // 0xb29b64: r0 = AllocateClosure()
    //     0xb29b64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb29b68: LeaveFrame
    //     0xb29b68: mov             SP, fp
    //     0xb29b6c: ldp             fp, lr, [SP], #0x10
    // 0xb29b70: ret
    //     0xb29b70: ret             
  }
  Iterable<Y0> map<Y0>(_DelegatingIterableBase<X0>, (dynamic, X0) => Y0) {
    // ** addr: 0x8277c4, size: 0x98
    // 0x8277c4: EnterFrame
    //     0x8277c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8277c8: mov             fp, SP
    // 0x8277cc: AllocStack(0x20)
    //     0x8277cc: sub             SP, SP, #0x20
    // 0x8277d0: SetupParameters([dynamic _, dynamic _ /* r3 */])
    //     0x8277d0: ldur            w0, [x4, #0xf]
    //     0x8277d4: cbnz            w0, #0x8277e0
    //     0x8277d8: mov             x4, NULL
    //     0x8277dc: b               #0x8277f0
    //     0x8277e0: ldur            w0, [x4, #0x17]
    //     0x8277e4: add             x1, fp, w0, sxtw #2
    //     0x8277e8: ldr             x1, [x1, #0x10]
    //     0x8277ec: mov             x4, x1
    //     0x8277f0: ldr             x3, [fp, #0x18]
    //     0x8277f4: stur            x4, [fp, #-8]
    // 0x8277f8: CheckStackOverflow
    //     0x8277f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8277fc: cmp             SP, x16
    //     0x827800: b.ls            #0x827854
    // 0x827804: LoadField: r2 = r3->field_7
    //     0x827804: ldur            w2, [x3, #7]
    // 0x827808: DecompressPointer r2
    //     0x827808: add             x2, x2, HEAP, lsl #32
    // 0x82780c: ldr             x0, [fp, #0x10]
    // 0x827810: mov             x1, x4
    // 0x827814: r8 = (dynamic this, X0) => Y0
    //     0x827814: add             x8, PP, #0xa2, lsl #12  ; [pp+0xa2c70] FunctionType: (dynamic this, X0) => Y0
    //     0x827818: ldr             x8, [x8, #0xc70]
    // 0x82781c: LoadField: r9 = r8->field_7
    //     0x82781c: ldur            x9, [x8, #7]
    // 0x827820: r3 = Null
    //     0x827820: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2c78] Null
    //     0x827824: ldr             x3, [x3, #0xc78]
    // 0x827828: blr             x9
    // 0x82782c: ldur            x16, [fp, #-8]
    // 0x827830: ldr             lr, [fp, #0x18]
    // 0x827834: stp             lr, x16, [SP, #8]
    // 0x827838: ldr             x16, [fp, #0x10]
    // 0x82783c: str             x16, [SP]
    // 0x827840: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x827840: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x827844: r0 = map()
    //     0x827844: bl              #0xb49130  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::map
    // 0x827848: LeaveFrame
    //     0x827848: mov             SP, fp
    //     0x82784c: ldp             fp, lr, [SP], #0x10
    // 0x827850: ret
    //     0x827850: ret             
    // 0x827854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827858: b               #0x827804
  }
  String join(_DelegatingIterableBase<X0>, [String]) {
    // ** addr: 0x82785c, size: 0xac
    // 0x82785c: EnterFrame
    //     0x82785c: stp             fp, lr, [SP, #-0x10]!
    //     0x827860: mov             fp, SP
    // 0x827864: AllocStack(0x18)
    //     0x827864: sub             SP, SP, #0x18
    // 0x827868: SetupParameters(_DelegatingIterableBase<X0> this /* r3, fp-0x10 */, [dynamic _ = "" /* r4, fp-0x8 */])
    //     0x827868: ldur            w0, [x4, #0x13]
    //     0x82786c: sub             x1, x0, #2
    //     0x827870: add             x3, fp, w1, sxtw #2
    //     0x827874: ldr             x3, [x3, #0x10]
    //     0x827878: stur            x3, [fp, #-0x10]
    //     0x82787c: cmp             w1, #2
    //     0x827880: b.lt            #0x827894
    //     0x827884: add             x0, fp, w1, sxtw #2
    //     0x827888: ldr             x0, [x0, #8]
    //     0x82788c: mov             x4, x0
    //     0x827890: b               #0x827898
    //     0x827894: ldr             x4, [PP, #0x900]  ; [pp+0x900] ""
    //     0x827898: stur            x4, [fp, #-8]
    // 0x82789c: CheckStackOverflow
    //     0x82789c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8278a0: cmp             SP, x16
    //     0x8278a4: b.ls            #0x827900
    // 0x8278a8: mov             x0, x4
    // 0x8278ac: r2 = Null
    //     0x8278ac: mov             x2, NULL
    // 0x8278b0: r1 = Null
    //     0x8278b0: mov             x1, NULL
    // 0x8278b4: r4 = 60
    //     0x8278b4: mov             x4, #0x3c
    // 0x8278b8: branchIfSmi(r0, 0x8278c4)
    //     0x8278b8: tbz             w0, #0, #0x8278c4
    // 0x8278bc: r4 = LoadClassIdInstr(r0)
    //     0x8278bc: ldur            x4, [x0, #-1]
    //     0x8278c0: ubfx            x4, x4, #0xc, #0x14
    // 0x8278c4: sub             x4, x4, #0x5e
    // 0x8278c8: cmp             x4, #1
    // 0x8278cc: b.ls            #0x8278e0
    // 0x8278d0: r8 = String
    //     0x8278d0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x8278d4: r3 = Null
    //     0x8278d4: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2c88] Null
    //     0x8278d8: ldr             x3, [x3, #0xc88]
    // 0x8278dc: r0 = String()
    //     0x8278dc: bl              #0x13ee320  ; IsType_String_Stub
    // 0x8278e0: ldur            x16, [fp, #-8]
    // 0x8278e4: str             x16, [SP]
    // 0x8278e8: ldur            x1, [fp, #-0x10]
    // 0x8278ec: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8278ec: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8278f0: r0 = join()
    //     0x8278f0: bl              #0xb2f4b8  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::join
    // 0x8278f4: LeaveFrame
    //     0x8278f4: mov             SP, fp
    //     0x8278f8: ldp             fp, lr, [SP], #0x10
    // 0x8278fc: ret
    //     0x8278fc: ret             
    // 0x827900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827900: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827904: b               #0x8278a8
  }
  bool dyn:get:isNotEmpty(_DelegatingIterableBase<X0>) {
    // ** addr: 0x827920, size: 0x48
    // 0x827920: EnterFrame
    //     0x827920: stp             fp, lr, [SP, #-0x10]!
    //     0x827924: mov             fp, SP
    // 0x827928: CheckStackOverflow
    //     0x827928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x82792c: cmp             SP, x16
    //     0x827930: b.ls            #0x827948
    // 0x827934: ldr             x1, [fp, #0x10]
    // 0x827938: r0 = isNotEmpty()
    //     0x827938: bl              #0xb22f28  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::isNotEmpty
    // 0x82793c: LeaveFrame
    //     0x82793c: mov             SP, fp
    //     0x827940: ldp             fp, lr, [SP], #0x10
    // 0x827944: ret
    //     0x827944: ret             
    // 0x827948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827948: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x82794c: b               #0x827934
  }
  void forEach(_DelegatingIterableBase<X0>, (dynamic, X0) => void) {
    // ** addr: 0x827968, size: 0x13c
    // 0x827968: EnterFrame
    //     0x827968: stp             fp, lr, [SP, #-0x10]!
    //     0x82796c: mov             fp, SP
    // 0x827970: AllocStack(0x28)
    //     0x827970: sub             SP, SP, #0x28
    // 0x827974: CheckStackOverflow
    //     0x827974: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827978: cmp             SP, x16
    //     0x82797c: b.ls            #0x827a78
    // 0x827980: ldr             x3, [fp, #0x18]
    // 0x827984: LoadField: r2 = r3->field_7
    //     0x827984: ldur            w2, [x3, #7]
    // 0x827988: DecompressPointer r2
    //     0x827988: add             x2, x2, HEAP, lsl #32
    // 0x82798c: ldr             x0, [fp, #0x10]
    // 0x827990: r1 = Null
    //     0x827990: mov             x1, NULL
    // 0x827994: r8 = (dynamic this, X0) => void?
    //     0x827994: add             x8, PP, #0xf, lsl #12  ; [pp+0xf768] FunctionType: (dynamic this, X0) => void?
    //     0x827998: ldr             x8, [x8, #0x768]
    // 0x82799c: LoadField: r9 = r8->field_7
    //     0x82799c: ldur            x9, [x8, #7]
    // 0x8279a0: r3 = Null
    //     0x8279a0: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2c98] Null
    //     0x8279a4: ldr             x3, [x3, #0xc98]
    // 0x8279a8: blr             x9
    // 0x8279ac: ldr             x0, [fp, #0x18]
    // 0x8279b0: LoadField: r2 = r0->field_b
    //     0x8279b0: ldur            w2, [x0, #0xb]
    // 0x8279b4: DecompressPointer r2
    //     0x8279b4: add             x2, x2, HEAP, lsl #32
    // 0x8279b8: stur            x2, [fp, #-0x18]
    // 0x8279bc: LoadField: r3 = r2->field_b
    //     0x8279bc: ldur            w3, [x2, #0xb]
    // 0x8279c0: stur            x3, [fp, #-0x10]
    // 0x8279c4: r0 = LoadInt32Instr(r3)
    //     0x8279c4: sbfx            x0, x3, #1, #0x1f
    // 0x8279c8: r4 = 0
    //     0x8279c8: mov             x4, #0
    // 0x8279cc: stur            x4, [fp, #-8]
    // 0x8279d0: CheckStackOverflow
    //     0x8279d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8279d4: cmp             SP, x16
    //     0x8279d8: b.ls            #0x827a80
    // 0x8279dc: cmp             x4, x0
    // 0x8279e0: b.ge            #0x827a4c
    // 0x8279e4: mov             x1, x4
    // 0x8279e8: cmp             x1, x0
    // 0x8279ec: b.hs            #0x827a88
    // 0x8279f0: LoadField: r0 = r2->field_f
    //     0x8279f0: ldur            w0, [x2, #0xf]
    // 0x8279f4: DecompressPointer r0
    //     0x8279f4: add             x0, x0, HEAP, lsl #32
    // 0x8279f8: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x8279f8: add             x16, x0, x4, lsl #2
    //     0x8279fc: ldur            w1, [x16, #0xf]
    // 0x827a00: DecompressPointer r1
    //     0x827a00: add             x1, x1, HEAP, lsl #32
    // 0x827a04: ldr             x16, [fp, #0x10]
    // 0x827a08: stp             x1, x16, [SP]
    // 0x827a0c: ldr             x0, [fp, #0x10]
    // 0x827a10: ClosureCall
    //     0x827a10: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x827a14: ldur            x2, [x0, #0x1f]
    //     0x827a18: blr             x2
    // 0x827a1c: ldur            x1, [fp, #-0x18]
    // 0x827a20: LoadField: r0 = r1->field_b
    //     0x827a20: ldur            w0, [x1, #0xb]
    // 0x827a24: ldur            x2, [fp, #-0x10]
    // 0x827a28: cmp             w0, w2
    // 0x827a2c: b.ne            #0x827a5c
    // 0x827a30: ldur            x3, [fp, #-8]
    // 0x827a34: add             x4, x3, #1
    // 0x827a38: r3 = LoadInt32Instr(r0)
    //     0x827a38: sbfx            x3, x0, #1, #0x1f
    // 0x827a3c: mov             x0, x3
    // 0x827a40: mov             x3, x2
    // 0x827a44: mov             x2, x1
    // 0x827a48: b               #0x8279cc
    // 0x827a4c: r0 = Null
    //     0x827a4c: mov             x0, NULL
    // 0x827a50: LeaveFrame
    //     0x827a50: mov             SP, fp
    //     0x827a54: ldp             fp, lr, [SP], #0x10
    // 0x827a58: ret
    //     0x827a58: ret             
    // 0x827a5c: r0 = ConcurrentModificationError()
    //     0x827a5c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x827a60: mov             x1, x0
    // 0x827a64: ldur            x0, [fp, #-0x18]
    // 0x827a68: StoreField: r1->field_b = r0
    //     0x827a68: stur            w0, [x1, #0xb]
    // 0x827a6c: mov             x0, x1
    // 0x827a70: r0 = Throw()
    //     0x827a70: bl              #0x13ddb2c  ; ThrowStub
    // 0x827a74: brk             #0
    // 0x827a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827a78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827a7c: b               #0x827980
    // 0x827a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827a80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827a84: b               #0x8279dc
    // 0x827a88: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x827a88: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  Iterable<X0> where(_DelegatingIterableBase<X0>, (dynamic, X0) => bool) {
    // ** addr: 0x827aa4, size: 0x78
    // 0x827aa4: EnterFrame
    //     0x827aa4: stp             fp, lr, [SP, #-0x10]!
    //     0x827aa8: mov             fp, SP
    // 0x827aac: CheckStackOverflow
    //     0x827aac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827ab0: cmp             SP, x16
    //     0x827ab4: b.ls            #0x827afc
    // 0x827ab8: ldr             x3, [fp, #0x18]
    // 0x827abc: LoadField: r2 = r3->field_7
    //     0x827abc: ldur            w2, [x3, #7]
    // 0x827ac0: DecompressPointer r2
    //     0x827ac0: add             x2, x2, HEAP, lsl #32
    // 0x827ac4: ldr             x0, [fp, #0x10]
    // 0x827ac8: r1 = Null
    //     0x827ac8: mov             x1, NULL
    // 0x827acc: r8 = (dynamic this, X0) => bool
    //     0x827acc: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8ed98] FunctionType: (dynamic this, X0) => bool
    //     0x827ad0: ldr             x8, [x8, #0xd98]
    // 0x827ad4: LoadField: r9 = r8->field_7
    //     0x827ad4: ldur            x9, [x8, #7]
    // 0x827ad8: r3 = Null
    //     0x827ad8: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2c50] Null
    //     0x827adc: ldr             x3, [x3, #0xc50]
    // 0x827ae0: blr             x9
    // 0x827ae4: ldr             x1, [fp, #0x18]
    // 0x827ae8: ldr             x2, [fp, #0x10]
    // 0x827aec: r0 = where()
    //     0x827aec: bl              #0xb2c4dc  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::where
    // 0x827af0: LeaveFrame
    //     0x827af0: mov             SP, fp
    //     0x827af4: ldp             fp, lr, [SP], #0x10
    // 0x827af8: ret
    //     0x827af8: ret             
    // 0x827afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827afc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827b00: b               #0x827ab8
  }
  List<X0> toList(_DelegatingIterableBase<X0>, {bool growable}) {
    // ** addr: 0x827b04, size: 0xc0
    // 0x827b04: EnterFrame
    //     0x827b04: stp             fp, lr, [SP, #-0x10]!
    //     0x827b08: mov             fp, SP
    // 0x827b0c: AllocStack(0x18)
    //     0x827b0c: sub             SP, SP, #0x18
    // 0x827b10: SetupParameters(_DelegatingIterableBase<X0> this /* r3, fp-0x10 */, {dynamic growable = true /* r4, fp-0x8 */})
    //     0x827b10: ldur            w0, [x4, #0x13]
    //     0x827b14: sub             x1, x0, #2
    //     0x827b18: add             x3, fp, w1, sxtw #2
    //     0x827b1c: ldr             x3, [x3, #0x10]
    //     0x827b20: stur            x3, [fp, #-0x10]
    //     0x827b24: ldur            w1, [x4, #0x1f]
    //     0x827b28: add             x1, x1, HEAP, lsl #32
    //     0x827b2c: ldr             x16, [PP, #0x1d80]  ; [pp+0x1d80] "growable"
    //     0x827b30: cmp             w1, w16
    //     0x827b34: b.ne            #0x827b54
    //     0x827b38: ldur            w1, [x4, #0x23]
    //     0x827b3c: add             x1, x1, HEAP, lsl #32
    //     0x827b40: sub             w2, w0, w1
    //     0x827b44: add             x0, fp, w2, sxtw #2
    //     0x827b48: ldr             x0, [x0, #8]
    //     0x827b4c: mov             x4, x0
    //     0x827b50: b               #0x827b58
    //     0x827b54: add             x4, NULL, #0x20  ; true
    //     0x827b58: stur            x4, [fp, #-8]
    // 0x827b5c: CheckStackOverflow
    //     0x827b5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827b60: cmp             SP, x16
    //     0x827b64: b.ls            #0x827bbc
    // 0x827b68: mov             x0, x4
    // 0x827b6c: r2 = Null
    //     0x827b6c: mov             x2, NULL
    // 0x827b70: r1 = Null
    //     0x827b70: mov             x1, NULL
    // 0x827b74: r4 = 60
    //     0x827b74: mov             x4, #0x3c
    // 0x827b78: branchIfSmi(r0, 0x827b84)
    //     0x827b78: tbz             w0, #0, #0x827b84
    // 0x827b7c: r4 = LoadClassIdInstr(r0)
    //     0x827b7c: ldur            x4, [x0, #-1]
    //     0x827b80: ubfx            x4, x4, #0xc, #0x14
    // 0x827b84: cmp             x4, #0x3f
    // 0x827b88: b.eq            #0x827b9c
    // 0x827b8c: r8 = bool
    //     0x827b8c: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x827b90: r3 = Null
    //     0x827b90: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2c60] Null
    //     0x827b94: ldr             x3, [x3, #0xc60]
    // 0x827b98: r0 = bool()
    //     0x827b98: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x827b9c: ldur            x16, [fp, #-8]
    // 0x827ba0: str             x16, [SP]
    // 0x827ba4: ldur            x1, [fp, #-0x10]
    // 0x827ba8: r4 = const [0, 0x2, 0x1, 0x1, growable, 0x1, null]
    //     0x827ba8: ldr             x4, [PP, #0x1418]  ; [pp+0x1418] List(7) [0, 0x2, 0x1, 0x1, "growable", 0x1, Null]
    // 0x827bac: r0 = toList()
    //     0x827bac: bl              #0xb5d35c  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::toList
    // 0x827bb0: LeaveFrame
    //     0x827bb0: mov             SP, fp
    //     0x827bb4: ldp             fp, lr, [SP], #0x10
    // 0x827bb8: ret
    //     0x827bb8: ret             
    // 0x827bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827bbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827bc0: b               #0x827b68
  }
  bool contains(_DelegatingIterableBase<X0>, Object?) {
    // ** addr: 0x827d9c, size: 0x4c
    // 0x827d9c: EnterFrame
    //     0x827d9c: stp             fp, lr, [SP, #-0x10]!
    //     0x827da0: mov             fp, SP
    // 0x827da4: CheckStackOverflow
    //     0x827da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827da8: cmp             SP, x16
    //     0x827dac: b.ls            #0x827dc8
    // 0x827db0: ldr             x1, [fp, #0x18]
    // 0x827db4: ldr             x2, [fp, #0x10]
    // 0x827db8: r0 = contains()
    //     0x827db8: bl              #0xb58afc  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::contains
    // 0x827dbc: LeaveFrame
    //     0x827dbc: mov             SP, fp
    //     0x827dc0: ldp             fp, lr, [SP], #0x10
    // 0x827dc4: ret
    //     0x827dc4: ret             
    // 0x827dc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827dc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827dcc: b               #0x827db0
  }
  [closure] bool contains(dynamic, Object?) {
    // ** addr: 0x827dd0, size: 0x3c
    // 0x827dd0: EnterFrame
    //     0x827dd0: stp             fp, lr, [SP, #-0x10]!
    //     0x827dd4: mov             fp, SP
    // 0x827dd8: ldr             x0, [fp, #0x18]
    // 0x827ddc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x827ddc: ldur            w1, [x0, #0x17]
    // 0x827de0: DecompressPointer r1
    //     0x827de0: add             x1, x1, HEAP, lsl #32
    // 0x827de4: CheckStackOverflow
    //     0x827de4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827de8: cmp             SP, x16
    //     0x827dec: b.ls            #0x827e04
    // 0x827df0: ldr             x2, [fp, #0x10]
    // 0x827df4: r0 = contains()
    //     0x827df4: bl              #0xb58afc  ; [package:collection/src/wrappers.dart] _DelegatingIterableBase::contains
    // 0x827df8: LeaveFrame
    //     0x827df8: mov             SP, fp
    //     0x827dfc: ldp             fp, lr, [SP], #0x10
    // 0x827e00: ret
    //     0x827e00: ret             
    // 0x827e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x827e04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x827e08: b               #0x827df0
  }
  Iterable<X0> takeWhile(_DelegatingIterableBase<X0>, (dynamic, X0) => bool) {
    // ** addr: 0x9fac10, size: 0x38
    // 0x9fac10: EnterFrame
    //     0x9fac10: stp             fp, lr, [SP, #-0x10]!
    //     0x9fac14: mov             fp, SP
    // 0x9fac18: CheckStackOverflow
    //     0x9fac18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9fac1c: cmp             SP, x16
    //     0x9fac20: b.ls            #0x9fac40
    // 0x9fac24: LoadField: r0 = r1->field_b
    //     0x9fac24: ldur            w0, [x1, #0xb]
    // 0x9fac28: DecompressPointer r0
    //     0x9fac28: add             x0, x0, HEAP, lsl #32
    // 0x9fac2c: mov             x1, x0
    // 0x9fac30: r0 = takeWhile()
    //     0x9fac30: bl              #0xa0d43c  ; [dart:collection] ListBase::takeWhile
    // 0x9fac34: LeaveFrame
    //     0x9fac34: mov             SP, fp
    //     0x9fac38: ldp             fp, lr, [SP], #0x10
    // 0x9fac3c: ret
    //     0x9fac3c: ret             
    // 0x9fac40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9fac40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9fac44: b               #0x9fac24
  }
  _ reduce(/* No info */) {
    // ** addr: 0xafa3cc, size: 0x74
    // 0xafa3cc: EnterFrame
    //     0xafa3cc: stp             fp, lr, [SP, #-0x10]!
    //     0xafa3d0: mov             fp, SP
    // 0xafa3d4: AllocStack(0x8)
    //     0xafa3d4: sub             SP, SP, #8
    // 0xafa3d8: SetupParameters(_DelegatingIterableBase<X0> this /* r1 => r3, fp-0x8 */)
    //     0xafa3d8: mov             x3, x1
    //     0xafa3dc: stur            x1, [fp, #-8]
    // 0xafa3e0: CheckStackOverflow
    //     0xafa3e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xafa3e4: cmp             SP, x16
    //     0xafa3e8: b.ls            #0xafa438
    // 0xafa3ec: LoadField: r2 = r3->field_7
    //     0xafa3ec: ldur            w2, [x3, #7]
    // 0xafa3f0: DecompressPointer r2
    //     0xafa3f0: add             x2, x2, HEAP, lsl #32
    // 0xafa3f4: r0 = Closure: (double, double) => double from Function '_extension#0|_sum@391088161': static.
    //     0xafa3f4: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa1ce8] Closure: (double, double) => double from Function '_extension#0|_sum@391088161': static. (0x7f2ada9c5914)
    //     0xafa3f8: ldr             x0, [x0, #0xce8]
    // 0xafa3fc: r1 = Null
    //     0xafa3fc: mov             x1, NULL
    // 0xafa400: r8 = (dynamic this, X0, X0) => X0
    //     0xafa400: ldr             x8, [PP, #0x4998]  ; [pp+0x4998] FunctionType: (dynamic this, X0, X0) => X0
    // 0xafa404: LoadField: r9 = r8->field_7
    //     0xafa404: ldur            x9, [x8, #7]
    // 0xafa408: r3 = Null
    //     0xafa408: add             x3, PP, #0xac, lsl #12  ; [pp+0xacd48] Null
    //     0xafa40c: ldr             x3, [x3, #0xd48]
    // 0xafa410: blr             x9
    // 0xafa414: ldur            x0, [fp, #-8]
    // 0xafa418: LoadField: r1 = r0->field_b
    //     0xafa418: ldur            w1, [x0, #0xb]
    // 0xafa41c: DecompressPointer r1
    //     0xafa41c: add             x1, x1, HEAP, lsl #32
    // 0xafa420: r2 = Closure: (double, double) => double from Function '_extension#0|_sum@391088161': static.
    //     0xafa420: add             x2, PP, #0xa1, lsl #12  ; [pp+0xa1ce8] Closure: (double, double) => double from Function '_extension#0|_sum@391088161': static. (0x7f2ada9c5914)
    //     0xafa424: ldr             x2, [x2, #0xce8]
    // 0xafa428: r0 = reduce()
    //     0xafa428: bl              #0xb15d7c  ; [dart:collection] ListBase::reduce
    // 0xafa42c: LeaveFrame
    //     0xafa42c: mov             SP, fp
    //     0xafa430: ldp             fp, lr, [SP], #0x10
    // 0xafa434: ret
    //     0xafa434: ret             
    // 0xafa438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa438: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa43c: b               #0xafa3ec
  }
  get _ last(/* No info */) {
    // ** addr: 0xafc204, size: 0x38
    // 0xafc204: EnterFrame
    //     0xafc204: stp             fp, lr, [SP, #-0x10]!
    //     0xafc208: mov             fp, SP
    // 0xafc20c: CheckStackOverflow
    //     0xafc20c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xafc210: cmp             SP, x16
    //     0xafc214: b.ls            #0xafc234
    // 0xafc218: LoadField: r0 = r1->field_b
    //     0xafc218: ldur            w0, [x1, #0xb]
    // 0xafc21c: DecompressPointer r0
    //     0xafc21c: add             x0, x0, HEAP, lsl #32
    // 0xafc220: mov             x1, x0
    // 0xafc224: r0 = last()
    //     0xafc224: bl              #0xb22764  ; [dart:core] _GrowableList::last
    // 0xafc228: LeaveFrame
    //     0xafc228: mov             SP, fp
    //     0xafc22c: ldp             fp, lr, [SP], #0x10
    // 0xafc230: ret
    //     0xafc230: ret             
    // 0xafc234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafc234: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafc238: b               #0xafc218
  }
  get _ single(/* No info */) {
    // ** addr: 0xb01f44, size: 0x38
    // 0xb01f44: EnterFrame
    //     0xb01f44: stp             fp, lr, [SP, #-0x10]!
    //     0xb01f48: mov             fp, SP
    // 0xb01f4c: CheckStackOverflow
    //     0xb01f4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb01f50: cmp             SP, x16
    //     0xb01f54: b.ls            #0xb01f74
    // 0xb01f58: LoadField: r0 = r1->field_b
    //     0xb01f58: ldur            w0, [x1, #0xb]
    // 0xb01f5c: DecompressPointer r0
    //     0xb01f5c: add             x0, x0, HEAP, lsl #32
    // 0xb01f60: mov             x1, x0
    // 0xb01f64: r0 = single()
    //     0xb01f64: bl              #0xb3aa28  ; [dart:core] _GrowableList::single
    // 0xb01f68: LeaveFrame
    //     0xb01f68: mov             SP, fp
    //     0xb01f6c: ldp             fp, lr, [SP], #0x10
    // 0xb01f70: ret
    //     0xb01f70: ret             
    // 0xb01f74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb01f74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb01f78: b               #0xb01f58
  }
  _ firstWhere(/* No info */) {
    // ** addr: 0xb0a8c8, size: 0xc8
    // 0xb0a8c8: EnterFrame
    //     0xb0a8c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb0a8cc: mov             fp, SP
    // 0xb0a8d0: AllocStack(0x20)
    //     0xb0a8d0: sub             SP, SP, #0x20
    // 0xb0a8d4: SetupParameters(_DelegatingIterableBase<X0> this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, {dynamic orElse = Null /* r4, fp-0x8 */})
    //     0xb0a8d4: mov             x5, x1
    //     0xb0a8d8: mov             x3, x2
    //     0xb0a8dc: stur            x1, [fp, #-0x10]
    //     0xb0a8e0: stur            x2, [fp, #-0x18]
    //     0xb0a8e4: ldur            w0, [x4, #0x13]
    //     0xb0a8e8: ldur            w1, [x4, #0x1f]
    //     0xb0a8ec: add             x1, x1, HEAP, lsl #32
    //     0xb0a8f0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe130] "orElse"
    //     0xb0a8f4: ldr             x16, [x16, #0x130]
    //     0xb0a8f8: cmp             w1, w16
    //     0xb0a8fc: b.ne            #0xb0a91c
    //     0xb0a900: ldur            w1, [x4, #0x23]
    //     0xb0a904: add             x1, x1, HEAP, lsl #32
    //     0xb0a908: sub             w2, w0, w1
    //     0xb0a90c: add             x0, fp, w2, sxtw #2
    //     0xb0a910: ldr             x0, [x0, #8]
    //     0xb0a914: mov             x4, x0
    //     0xb0a918: b               #0xb0a920
    //     0xb0a91c: mov             x4, NULL
    //     0xb0a920: stur            x4, [fp, #-8]
    // 0xb0a924: CheckStackOverflow
    //     0xb0a924: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb0a928: cmp             SP, x16
    //     0xb0a92c: b.ls            #0xb0a988
    // 0xb0a930: LoadField: r2 = r5->field_7
    //     0xb0a930: ldur            w2, [x5, #7]
    // 0xb0a934: DecompressPointer r2
    //     0xb0a934: add             x2, x2, HEAP, lsl #32
    // 0xb0a938: mov             x0, x4
    // 0xb0a93c: r1 = Null
    //     0xb0a93c: mov             x1, NULL
    // 0xb0a940: r8 = ((dynamic this) => X0)?
    //     0xb0a940: add             x8, PP, #0xe, lsl #12  ; [pp+0xe138] FunctionType: ((dynamic this) => X0)?
    //     0xb0a944: ldr             x8, [x8, #0x138]
    // 0xb0a948: LoadField: r9 = r8->field_7
    //     0xb0a948: ldur            x9, [x8, #7]
    // 0xb0a94c: r3 = Null
    //     0xb0a94c: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2ca8] Null
    //     0xb0a950: ldr             x3, [x3, #0xca8]
    // 0xb0a954: blr             x9
    // 0xb0a958: ldur            x0, [fp, #-0x10]
    // 0xb0a95c: LoadField: r1 = r0->field_b
    //     0xb0a95c: ldur            w1, [x0, #0xb]
    // 0xb0a960: DecompressPointer r1
    //     0xb0a960: add             x1, x1, HEAP, lsl #32
    // 0xb0a964: ldur            x16, [fp, #-8]
    // 0xb0a968: str             x16, [SP]
    // 0xb0a96c: ldur            x2, [fp, #-0x18]
    // 0xb0a970: r4 = const [0, 0x3, 0x1, 0x2, orElse, 0x2, null]
    //     0xb0a970: add             x4, PP, #0x17, lsl #12  ; [pp+0x17f30] List(7) [0, 0x3, 0x1, 0x2, "orElse", 0x2, Null]
    //     0xb0a974: ldr             x4, [x4, #0xf30]
    // 0xb0a978: r0 = firstWhere()
    //     0xb0a978: bl              #0xb59d18  ; [dart:collection] ListBase::firstWhere
    // 0xb0a97c: LeaveFrame
    //     0xb0a97c: mov             SP, fp
    //     0xb0a980: ldp             fp, lr, [SP], #0x10
    // 0xb0a984: ret
    //     0xb0a984: ret             
    // 0xb0a988: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb0a988: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0a98c: b               #0xb0a930
  }
  bool isNotEmpty(_DelegatingIterableBase<X0>) {
    // ** addr: 0xb22f28, size: 0x20
    // 0xb22f28: LoadField: r2 = r1->field_b
    //     0xb22f28: ldur            w2, [x1, #0xb]
    // 0xb22f2c: DecompressPointer r2
    //     0xb22f2c: add             x2, x2, HEAP, lsl #32
    // 0xb22f30: LoadField: r1 = r2->field_b
    //     0xb22f30: ldur            w1, [x2, #0xb]
    // 0xb22f34: cbnz            w1, #0xb22f40
    // 0xb22f38: r0 = false
    //     0xb22f38: add             x0, NULL, #0x30  ; false
    // 0xb22f3c: b               #0xb22f44
    // 0xb22f40: r0 = true
    //     0xb22f40: add             x0, NULL, #0x20  ; true
    // 0xb22f44: ret
    //     0xb22f44: ret             
  }
  Iterable<X0> where(_DelegatingIterableBase<X0>, (dynamic, X0) => bool) {
    // ** addr: 0xb2c4dc, size: 0x38
    // 0xb2c4dc: EnterFrame
    //     0xb2c4dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb2c4e0: mov             fp, SP
    // 0xb2c4e4: CheckStackOverflow
    //     0xb2c4e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2c4e8: cmp             SP, x16
    //     0xb2c4ec: b.ls            #0xb2c50c
    // 0xb2c4f0: LoadField: r0 = r1->field_b
    //     0xb2c4f0: ldur            w0, [x1, #0xb]
    // 0xb2c4f4: DecompressPointer r0
    //     0xb2c4f4: add             x0, x0, HEAP, lsl #32
    // 0xb2c4f8: mov             x1, x0
    // 0xb2c4fc: r0 = where()
    //     0xb2c4fc: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xb2c500: LeaveFrame
    //     0xb2c500: mov             SP, fp
    //     0xb2c504: ldp             fp, lr, [SP], #0x10
    // 0xb2c508: ret
    //     0xb2c508: ret             
    // 0xb2c50c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2c50c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2c510: b               #0xb2c4f0
  }
  _ elementAt(/* No info */) {
    // ** addr: 0xb2cf64, size: 0x40
    // 0xb2cf64: LoadField: r3 = r1->field_b
    //     0xb2cf64: ldur            w3, [x1, #0xb]
    // 0xb2cf68: DecompressPointer r3
    //     0xb2cf68: add             x3, x3, HEAP, lsl #32
    // 0xb2cf6c: LoadField: r4 = r3->field_b
    //     0xb2cf6c: ldur            w4, [x3, #0xb]
    // 0xb2cf70: r0 = LoadInt32Instr(r4)
    //     0xb2cf70: sbfx            x0, x4, #1, #0x1f
    // 0xb2cf74: mov             x1, x2
    // 0xb2cf78: cmp             x1, x0
    // 0xb2cf7c: b.hs            #0xb2cf98
    // 0xb2cf80: LoadField: r1 = r3->field_f
    //     0xb2cf80: ldur            w1, [x3, #0xf]
    // 0xb2cf84: DecompressPointer r1
    //     0xb2cf84: add             x1, x1, HEAP, lsl #32
    // 0xb2cf88: ArrayLoad: r0 = r1[r2]  ; Unknown_4
    //     0xb2cf88: add             x16, x1, x2, lsl #2
    //     0xb2cf8c: ldur            w0, [x16, #0xf]
    // 0xb2cf90: DecompressPointer r0
    //     0xb2cf90: add             x0, x0, HEAP, lsl #32
    // 0xb2cf94: ret
    //     0xb2cf94: ret             
    // 0xb2cf98: EnterFrame
    //     0xb2cf98: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cf9c: mov             fp, SP
    // 0xb2cfa0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb2cfa0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  String join(_DelegatingIterableBase<X0>, [String]) {
    // ** addr: 0xb2f4b8, size: 0x48
    // 0xb2f4b8: EnterFrame
    //     0xb2f4b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2f4bc: mov             fp, SP
    // 0xb2f4c0: AllocStack(0x8)
    //     0xb2f4c0: sub             SP, SP, #8
    // 0xb2f4c4: CheckStackOverflow
    //     0xb2f4c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2f4c8: cmp             SP, x16
    //     0xb2f4cc: b.ls            #0xb2f4f8
    // 0xb2f4d0: LoadField: r0 = r1->field_b
    //     0xb2f4d0: ldur            w0, [x1, #0xb]
    // 0xb2f4d4: DecompressPointer r0
    //     0xb2f4d4: add             x0, x0, HEAP, lsl #32
    // 0xb2f4d8: r16 = "\n"
    //     0xb2f4d8: ldr             x16, [PP, #0x8c0]  ; [pp+0x8c0] "\n"
    // 0xb2f4dc: str             x16, [SP]
    // 0xb2f4e0: mov             x1, x0
    // 0xb2f4e4: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb2f4e4: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb2f4e8: r0 = join()
    //     0xb2f4e8: bl              #0xb99e34  ; [dart:core] _GrowableList::join
    // 0xb2f4ec: LeaveFrame
    //     0xb2f4ec: mov             SP, fp
    //     0xb2f4f0: ldp             fp, lr, [SP], #0x10
    // 0xb2f4f4: ret
    //     0xb2f4f4: ret             
    // 0xb2f4f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2f4f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2f4fc: b               #0xb2f4d0
  }
  void forEach(_DelegatingIterableBase<X0>, (dynamic, X0) => void) {
    // ** addr: 0xb3ad80, size: 0xf8
    // 0xb3ad80: EnterFrame
    //     0xb3ad80: stp             fp, lr, [SP, #-0x10]!
    //     0xb3ad84: mov             fp, SP
    // 0xb3ad88: AllocStack(0x30)
    //     0xb3ad88: sub             SP, SP, #0x30
    // 0xb3ad8c: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xb3ad8c: stur            x2, [fp, #-0x20]
    // 0xb3ad90: CheckStackOverflow
    //     0xb3ad90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb3ad94: cmp             SP, x16
    //     0xb3ad98: b.ls            #0xb3ae64
    // 0xb3ad9c: LoadField: r3 = r1->field_b
    //     0xb3ad9c: ldur            w3, [x1, #0xb]
    // 0xb3ada0: DecompressPointer r3
    //     0xb3ada0: add             x3, x3, HEAP, lsl #32
    // 0xb3ada4: stur            x3, [fp, #-0x18]
    // 0xb3ada8: LoadField: r4 = r3->field_b
    //     0xb3ada8: ldur            w4, [x3, #0xb]
    // 0xb3adac: stur            x4, [fp, #-0x10]
    // 0xb3adb0: r0 = LoadInt32Instr(r4)
    //     0xb3adb0: sbfx            x0, x4, #1, #0x1f
    // 0xb3adb4: r5 = 0
    //     0xb3adb4: mov             x5, #0
    // 0xb3adb8: stur            x5, [fp, #-8]
    // 0xb3adbc: CheckStackOverflow
    //     0xb3adbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb3adc0: cmp             SP, x16
    //     0xb3adc4: b.ls            #0xb3ae6c
    // 0xb3adc8: cmp             x5, x0
    // 0xb3adcc: b.ge            #0xb3ae38
    // 0xb3add0: mov             x1, x5
    // 0xb3add4: cmp             x1, x0
    // 0xb3add8: b.hs            #0xb3ae74
    // 0xb3addc: LoadField: r0 = r3->field_f
    //     0xb3addc: ldur            w0, [x3, #0xf]
    // 0xb3ade0: DecompressPointer r0
    //     0xb3ade0: add             x0, x0, HEAP, lsl #32
    // 0xb3ade4: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0xb3ade4: add             x16, x0, x5, lsl #2
    //     0xb3ade8: ldur            w1, [x16, #0xf]
    // 0xb3adec: DecompressPointer r1
    //     0xb3adec: add             x1, x1, HEAP, lsl #32
    // 0xb3adf0: stp             x1, x2, [SP]
    // 0xb3adf4: mov             x0, x2
    // 0xb3adf8: ClosureCall
    //     0xb3adf8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb3adfc: ldur            x2, [x0, #0x1f]
    //     0xb3ae00: blr             x2
    // 0xb3ae04: ldur            x1, [fp, #-0x18]
    // 0xb3ae08: LoadField: r0 = r1->field_b
    //     0xb3ae08: ldur            w0, [x1, #0xb]
    // 0xb3ae0c: ldur            x2, [fp, #-0x10]
    // 0xb3ae10: cmp             w0, w2
    // 0xb3ae14: b.ne            #0xb3ae48
    // 0xb3ae18: ldur            x3, [fp, #-8]
    // 0xb3ae1c: add             x5, x3, #1
    // 0xb3ae20: r3 = LoadInt32Instr(r0)
    //     0xb3ae20: sbfx            x3, x0, #1, #0x1f
    // 0xb3ae24: mov             x0, x3
    // 0xb3ae28: mov             x4, x2
    // 0xb3ae2c: ldur            x2, [fp, #-0x20]
    // 0xb3ae30: mov             x3, x1
    // 0xb3ae34: b               #0xb3adb8
    // 0xb3ae38: r0 = Null
    //     0xb3ae38: mov             x0, NULL
    // 0xb3ae3c: LeaveFrame
    //     0xb3ae3c: mov             SP, fp
    //     0xb3ae40: ldp             fp, lr, [SP], #0x10
    // 0xb3ae44: ret
    //     0xb3ae44: ret             
    // 0xb3ae48: r0 = ConcurrentModificationError()
    //     0xb3ae48: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xb3ae4c: mov             x1, x0
    // 0xb3ae50: ldur            x0, [fp, #-0x18]
    // 0xb3ae54: StoreField: r1->field_b = r0
    //     0xb3ae54: stur            w0, [x1, #0xb]
    // 0xb3ae58: mov             x0, x1
    // 0xb3ae5c: r0 = Throw()
    //     0xb3ae5c: bl              #0x13ddb2c  ; ThrowStub
    // 0xb3ae60: brk             #0
    // 0xb3ae64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb3ae64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb3ae68: b               #0xb3ad9c
    // 0xb3ae6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb3ae6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb3ae70: b               #0xb3adc8
    // 0xb3ae74: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb3ae74: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  Iterable<Y0> map<Y0>(_DelegatingIterableBase<X0>, (dynamic, X0) => Y0) {
    // ** addr: 0xb49130, size: 0x68
    // 0xb49130: EnterFrame
    //     0xb49130: stp             fp, lr, [SP, #-0x10]!
    //     0xb49134: mov             fp, SP
    // 0xb49138: AllocStack(0x18)
    //     0xb49138: sub             SP, SP, #0x18
    // 0xb4913c: SetupParameters([dynamic _, dynamic _ /* r0 */])
    //     0xb4913c: ldur            w0, [x4, #0xf]
    //     0xb49140: cbnz            w0, #0xb4914c
    //     0xb49144: mov             x1, NULL
    //     0xb49148: b               #0xb49158
    //     0xb4914c: ldur            w0, [x4, #0x17]
    //     0xb49150: add             x1, fp, w0, sxtw #2
    //     0xb49154: ldr             x1, [x1, #0x10]
    //     0xb49158: ldr             x0, [fp, #0x18]
    // 0xb4915c: CheckStackOverflow
    //     0xb4915c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb49160: cmp             SP, x16
    //     0xb49164: b.ls            #0xb49190
    // 0xb49168: LoadField: r2 = r0->field_b
    //     0xb49168: ldur            w2, [x0, #0xb]
    // 0xb4916c: DecompressPointer r2
    //     0xb4916c: add             x2, x2, HEAP, lsl #32
    // 0xb49170: stp             x2, x1, [SP, #8]
    // 0xb49174: ldr             x16, [fp, #0x10]
    // 0xb49178: str             x16, [SP]
    // 0xb4917c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb4917c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb49180: r0 = map()
    //     0xb49180: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0xb49184: LeaveFrame
    //     0xb49184: mov             SP, fp
    //     0xb49188: ldp             fp, lr, [SP], #0x10
    // 0xb4918c: ret
    //     0xb4918c: ret             
    // 0xb49190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb49190: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb49194: b               #0xb49168
  }
  _ toSet(/* No info */) {
    // ** addr: 0xb49424, size: 0x38
    // 0xb49424: EnterFrame
    //     0xb49424: stp             fp, lr, [SP, #-0x10]!
    //     0xb49428: mov             fp, SP
    // 0xb4942c: CheckStackOverflow
    //     0xb4942c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb49430: cmp             SP, x16
    //     0xb49434: b.ls            #0xb49454
    // 0xb49438: LoadField: r0 = r1->field_b
    //     0xb49438: ldur            w0, [x1, #0xb]
    // 0xb4943c: DecompressPointer r0
    //     0xb4943c: add             x0, x0, HEAP, lsl #32
    // 0xb49440: mov             x1, x0
    // 0xb49444: r0 = toSet()
    //     0xb49444: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0xb49448: LeaveFrame
    //     0xb49448: mov             SP, fp
    //     0xb4944c: ldp             fp, lr, [SP], #0x10
    // 0xb49450: ret
    //     0xb49450: ret             
    // 0xb49454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb49454: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb49458: b               #0xb49438
  }
  bool isEmpty(_DelegatingIterableBase<X0>) {
    // ** addr: 0xb4ce9c, size: 0x20
    // 0xb4ce9c: LoadField: r2 = r1->field_b
    //     0xb4ce9c: ldur            w2, [x1, #0xb]
    // 0xb4cea0: DecompressPointer r2
    //     0xb4cea0: add             x2, x2, HEAP, lsl #32
    // 0xb4cea4: LoadField: r1 = r2->field_b
    //     0xb4cea4: ldur            w1, [x2, #0xb]
    // 0xb4cea8: cbz             w1, #0xb4ceb4
    // 0xb4ceac: r0 = false
    //     0xb4ceac: add             x0, NULL, #0x30  ; false
    // 0xb4ceb0: b               #0xb4ceb8
    // 0xb4ceb4: r0 = true
    //     0xb4ceb4: add             x0, NULL, #0x20  ; true
    // 0xb4ceb8: ret
    //     0xb4ceb8: ret             
  }
  _ any(/* No info */) {
    // ** addr: 0xb581f0, size: 0x38
    // 0xb581f0: EnterFrame
    //     0xb581f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb581f4: mov             fp, SP
    // 0xb581f8: CheckStackOverflow
    //     0xb581f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb581fc: cmp             SP, x16
    //     0xb58200: b.ls            #0xb58220
    // 0xb58204: LoadField: r0 = r1->field_b
    //     0xb58204: ldur            w0, [x1, #0xb]
    // 0xb58208: DecompressPointer r0
    //     0xb58208: add             x0, x0, HEAP, lsl #32
    // 0xb5820c: mov             x1, x0
    // 0xb58210: r0 = any()
    //     0xb58210: bl              #0xbae1ac  ; [dart:collection] ListBase::any
    // 0xb58214: LeaveFrame
    //     0xb58214: mov             SP, fp
    //     0xb58218: ldp             fp, lr, [SP], #0x10
    // 0xb5821c: ret
    //     0xb5821c: ret             
    // 0xb58220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb58220: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb58224: b               #0xb58204
  }
  bool contains(_DelegatingIterableBase<X0>, Object?) {
    // ** addr: 0xb58afc, size: 0x38
    // 0xb58afc: EnterFrame
    //     0xb58afc: stp             fp, lr, [SP, #-0x10]!
    //     0xb58b00: mov             fp, SP
    // 0xb58b04: CheckStackOverflow
    //     0xb58b04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb58b08: cmp             SP, x16
    //     0xb58b0c: b.ls            #0xb58b2c
    // 0xb58b10: LoadField: r0 = r1->field_b
    //     0xb58b10: ldur            w0, [x1, #0xb]
    // 0xb58b14: DecompressPointer r0
    //     0xb58b14: add             x0, x0, HEAP, lsl #32
    // 0xb58b18: mov             x1, x0
    // 0xb58b1c: r0 = contains()
    //     0xb58b1c: bl              #0xbaf414  ; [dart:collection] ListBase::contains
    // 0xb58b20: LeaveFrame
    //     0xb58b20: mov             SP, fp
    //     0xb58b24: ldp             fp, lr, [SP], #0x10
    // 0xb58b28: ret
    //     0xb58b28: ret             
    // 0xb58b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb58b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb58b30: b               #0xb58b10
  }
  _ skip(/* No info */) {
    // ** addr: 0xb5a638, size: 0x38
    // 0xb5a638: EnterFrame
    //     0xb5a638: stp             fp, lr, [SP, #-0x10]!
    //     0xb5a63c: mov             fp, SP
    // 0xb5a640: CheckStackOverflow
    //     0xb5a640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5a644: cmp             SP, x16
    //     0xb5a648: b.ls            #0xb5a668
    // 0xb5a64c: LoadField: r0 = r1->field_b
    //     0xb5a64c: ldur            w0, [x1, #0xb]
    // 0xb5a650: DecompressPointer r0
    //     0xb5a650: add             x0, x0, HEAP, lsl #32
    // 0xb5a654: mov             x1, x0
    // 0xb5a658: r0 = skip()
    //     0xb5a658: bl              #0xbb13c0  ; [dart:collection] ListBase::skip
    // 0xb5a65c: LeaveFrame
    //     0xb5a65c: mov             SP, fp
    //     0xb5a660: ldp             fp, lr, [SP], #0x10
    // 0xb5a664: ret
    //     0xb5a664: ret             
    // 0xb5a668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5a668: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5a66c: b               #0xb5a64c
  }
  get _ first(/* No info */) {
    // ** addr: 0xb5cbc4, size: 0x38
    // 0xb5cbc4: EnterFrame
    //     0xb5cbc4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5cbc8: mov             fp, SP
    // 0xb5cbcc: CheckStackOverflow
    //     0xb5cbcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5cbd0: cmp             SP, x16
    //     0xb5cbd4: b.ls            #0xb5cbf4
    // 0xb5cbd8: LoadField: r0 = r1->field_b
    //     0xb5cbd8: ldur            w0, [x1, #0xb]
    // 0xb5cbdc: DecompressPointer r0
    //     0xb5cbdc: add             x0, x0, HEAP, lsl #32
    // 0xb5cbe0: mov             x1, x0
    // 0xb5cbe4: r0 = first()
    //     0xb5cbe4: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0xb5cbe8: LeaveFrame
    //     0xb5cbe8: mov             SP, fp
    //     0xb5cbec: ldp             fp, lr, [SP], #0x10
    // 0xb5cbf0: ret
    //     0xb5cbf0: ret             
    // 0xb5cbf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5cbf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5cbf8: b               #0xb5cbd8
  }
  List<X0> toList(_DelegatingIterableBase<X0>, {bool growable}) {
    // ** addr: 0xb5d35c, size: 0x48
    // 0xb5d35c: EnterFrame
    //     0xb5d35c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5d360: mov             fp, SP
    // 0xb5d364: AllocStack(0x8)
    //     0xb5d364: sub             SP, SP, #8
    // 0xb5d368: CheckStackOverflow
    //     0xb5d368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5d36c: cmp             SP, x16
    //     0xb5d370: b.ls            #0xb5d39c
    // 0xb5d374: LoadField: r0 = r1->field_b
    //     0xb5d374: ldur            w0, [x1, #0xb]
    // 0xb5d378: DecompressPointer r0
    //     0xb5d378: add             x0, x0, HEAP, lsl #32
    // 0xb5d37c: r16 = true
    //     0xb5d37c: add             x16, NULL, #0x20  ; true
    // 0xb5d380: str             x16, [SP]
    // 0xb5d384: mov             x1, x0
    // 0xb5d388: r4 = const [0, 0x2, 0x1, 0x1, growable, 0x1, null]
    //     0xb5d388: ldr             x4, [PP, #0x1418]  ; [pp+0x1418] List(7) [0, 0x2, 0x1, 0x1, "growable", 0x1, Null]
    // 0xb5d38c: r0 = toList()
    //     0xb5d38c: bl              #0xbb6108  ; [dart:core] _GrowableList::toList
    // 0xb5d390: LeaveFrame
    //     0xb5d390: mov             SP, fp
    //     0xb5d394: ldp             fp, lr, [SP], #0x10
    // 0xb5d398: ret
    //     0xb5d398: ret             
    // 0xb5d39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5d39c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5d3a0: b               #0xb5d374
  }
  get _ iterator(/* No info */) {
    // ** addr: 0xb5e2a8, size: 0x48
    // 0xb5e2a8: EnterFrame
    //     0xb5e2a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e2ac: mov             fp, SP
    // 0xb5e2b0: AllocStack(0x8)
    //     0xb5e2b0: sub             SP, SP, #8
    // 0xb5e2b4: LoadField: r0 = r1->field_b
    //     0xb5e2b4: ldur            w0, [x1, #0xb]
    // 0xb5e2b8: DecompressPointer r0
    //     0xb5e2b8: add             x0, x0, HEAP, lsl #32
    // 0xb5e2bc: stur            x0, [fp, #-8]
    // 0xb5e2c0: LoadField: r1 = r0->field_7
    //     0xb5e2c0: ldur            w1, [x0, #7]
    // 0xb5e2c4: DecompressPointer r1
    //     0xb5e2c4: add             x1, x1, HEAP, lsl #32
    // 0xb5e2c8: r0 = ListIterator()
    //     0xb5e2c8: bl              #0x830f24  ; AllocateListIteratorStub -> ListIterator<X0> (size=0x24)
    // 0xb5e2cc: ldur            x1, [fp, #-8]
    // 0xb5e2d0: StoreField: r0->field_b = r1
    //     0xb5e2d0: stur            w1, [x0, #0xb]
    // 0xb5e2d4: LoadField: r2 = r1->field_b
    //     0xb5e2d4: ldur            w2, [x1, #0xb]
    // 0xb5e2d8: r1 = LoadInt32Instr(r2)
    //     0xb5e2d8: sbfx            x1, x2, #1, #0x1f
    // 0xb5e2dc: StoreField: r0->field_f = r1
    //     0xb5e2dc: stur            x1, [x0, #0xf]
    // 0xb5e2e0: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb5e2e0: stur            xzr, [x0, #0x17]
    // 0xb5e2e4: LeaveFrame
    //     0xb5e2e4: mov             SP, fp
    //     0xb5e2e8: ldp             fp, lr, [SP], #0x10
    // 0xb5e2ec: ret
    //     0xb5e2ec: ret             
  }
  _ whereType(/* No info */) {
    // ** addr: 0xbf02f0, size: 0x60
    // 0xbf02f0: EnterFrame
    //     0xbf02f0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf02f4: mov             fp, SP
    // 0xbf02f8: AllocStack(0x10)
    //     0xbf02f8: sub             SP, SP, #0x10
    // 0xbf02fc: SetupParameters([dynamic _ /* r0 */])
    //     0xbf02fc: ldur            w0, [x4, #0xf]
    //     0xbf0300: cbnz            w0, #0xbf030c
    //     0xbf0304: mov             x1, NULL
    //     0xbf0308: b               #0xbf0318
    //     0xbf030c: ldur            w0, [x4, #0x17]
    //     0xbf0310: add             x1, fp, w0, sxtw #2
    //     0xbf0314: ldr             x1, [x1, #0x10]
    //     0xbf0318: ldr             x0, [fp, #0x10]
    // 0xbf031c: CheckStackOverflow
    //     0xbf031c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0320: cmp             SP, x16
    //     0xbf0324: b.ls            #0xbf0348
    // 0xbf0328: LoadField: r2 = r0->field_b
    //     0xbf0328: ldur            w2, [x0, #0xb]
    // 0xbf032c: DecompressPointer r2
    //     0xbf032c: add             x2, x2, HEAP, lsl #32
    // 0xbf0330: stp             x2, x1, [SP]
    // 0xbf0334: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xbf0334: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xbf0338: r0 = whereType()
    //     0xbf0338: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0xbf033c: LeaveFrame
    //     0xbf033c: mov             SP, fp
    //     0xbf0340: ldp             fp, lr, [SP], #0x10
    // 0xbf0344: ret
    //     0xbf0344: ret             
    // 0xbf0348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf034c: b               #0xbf0328
  }
  _ toString(/* No info */) {
    // ** addr: 0x110af7c, size: 0x38
    // 0x110af7c: EnterFrame
    //     0x110af7c: stp             fp, lr, [SP, #-0x10]!
    //     0x110af80: mov             fp, SP
    // 0x110af84: CheckStackOverflow
    //     0x110af84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110af88: cmp             SP, x16
    //     0x110af8c: b.ls            #0x110afac
    // 0x110af90: ldr             x0, [fp, #0x10]
    // 0x110af94: LoadField: r1 = r0->field_b
    //     0x110af94: ldur            w1, [x0, #0xb]
    // 0x110af98: DecompressPointer r1
    //     0x110af98: add             x1, x1, HEAP, lsl #32
    // 0x110af9c: r0 = listToString()
    //     0x110af9c: bl              #0x110afb4  ; [dart:collection] ListBase::listToString
    // 0x110afa0: LeaveFrame
    //     0x110afa0: mov             SP, fp
    //     0x110afa4: ldp             fp, lr, [SP], #0x10
    // 0x110afa8: ret
    //     0x110afa8: ret             
    // 0x110afac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110afac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110afb0: b               #0x110af90
  }
  _ every(/* No info */) {
    // ** addr: 0x12cf370, size: 0x38
    // 0x12cf370: EnterFrame
    //     0x12cf370: stp             fp, lr, [SP, #-0x10]!
    //     0x12cf374: mov             fp, SP
    // 0x12cf378: CheckStackOverflow
    //     0x12cf378: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12cf37c: cmp             SP, x16
    //     0x12cf380: b.ls            #0x12cf3a0
    // 0x12cf384: LoadField: r0 = r1->field_b
    //     0x12cf384: ldur            w0, [x1, #0xb]
    // 0x12cf388: DecompressPointer r0
    //     0x12cf388: add             x0, x0, HEAP, lsl #32
    // 0x12cf38c: mov             x1, x0
    // 0x12cf390: r0 = every()
    //     0x12cf390: bl              #0x83f9a4  ; [dart:collection] ListBase::every
    // 0x12cf394: LeaveFrame
    //     0x12cf394: mov             SP, fp
    //     0x12cf398: ldp             fp, lr, [SP], #0x10
    // 0x12cf39c: ret
    //     0x12cf39c: ret             
    // 0x12cf3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12cf3a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12cf3a4: b               #0x12cf384
  }
}

// class id: 3565, size: 0x10, field offset: 0xc
//   const constructor, 
abstract class DelegatingList<X0> extends _DelegatingIterableBase<X0>
    implements List<X0> {

  List<Y0> cast<Y0>(DelegatingList<X0>) {
    // ** addr: 0xb25f8c, size: 0x60
    // 0xb25f8c: EnterFrame
    //     0xb25f8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb25f90: mov             fp, SP
    // 0xb25f94: AllocStack(0x10)
    //     0xb25f94: sub             SP, SP, #0x10
    // 0xb25f98: SetupParameters([dynamic _ /* r0 */])
    //     0xb25f98: ldur            w0, [x4, #0xf]
    //     0xb25f9c: cbnz            w0, #0xb25fa8
    //     0xb25fa0: mov             x1, NULL
    //     0xb25fa4: b               #0xb25fb4
    //     0xb25fa8: ldur            w0, [x4, #0x17]
    //     0xb25fac: add             x1, fp, w0, sxtw #2
    //     0xb25fb0: ldr             x1, [x1, #0x10]
    //     0xb25fb4: ldr             x0, [fp, #0x10]
    // 0xb25fb8: CheckStackOverflow
    //     0xb25fb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb25fbc: cmp             SP, x16
    //     0xb25fc0: b.ls            #0xb25fe4
    // 0xb25fc4: LoadField: r2 = r0->field_b
    //     0xb25fc4: ldur            w2, [x0, #0xb]
    // 0xb25fc8: DecompressPointer r2
    //     0xb25fc8: add             x2, x2, HEAP, lsl #32
    // 0xb25fcc: stp             x2, x1, [SP]
    // 0xb25fd0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb25fd0: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb25fd4: r0 = cast()
    //     0xb25fd4: bl              #0xb73994  ; [dart:collection] ListBase::cast
    // 0xb25fd8: LeaveFrame
    //     0xb25fd8: mov             SP, fp
    //     0xb25fdc: ldp             fp, lr, [SP], #0x10
    // 0xb25fe0: ret
    //     0xb25fe0: ret             
    // 0xb25fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb25fe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb25fe8: b               #0xb25fc4
  }
  _ indexOf(/* No info */) {
    // ** addr: 0x827638, size: 0x8c
    // 0x827638: EnterFrame
    //     0x827638: stp             fp, lr, [SP, #-0x10]!
    //     0x82763c: mov             fp, SP
    // 0x827640: AllocStack(0x18)
    //     0x827640: sub             SP, SP, #0x18
    // 0x827644: SetupParameters(DelegatingList<X0> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x827644: mov             x5, x1
    //     0x827648: mov             x3, x2
    //     0x82764c: stur            x1, [fp, #-8]
    //     0x827650: stur            x2, [fp, #-0x10]
    // 0x827654: CheckStackOverflow
    //     0x827654: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x827658: cmp             SP, x16
    //     0x82765c: b.ls            #0x8276bc
    // 0x827660: LoadField: r2 = r5->field_7
    //     0x827660: ldur            w2, [x5, #7]
    // 0x827664: DecompressPointer r2
    //     0x827664: add             x2, x2, HEAP, lsl #32
    // 0x827668: mov             x0, x3
    // 0x82766c: r1 = Null
    //     0x82766c: mov             x1, NULL
    // 0x827670: cmp             w2, NULL
    // 0x827674: b.eq            #0x827694
    // 0x827678: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x827678: ldur            w4, [x2, #0x17]
    // 0x82767c: DecompressPointer r4
    //     0x82767c: add             x4, x4, HEAP, lsl #32
    // 0x827680: r8 = X0
    //     0x827680: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x827684: LoadField: r9 = r4->field_7
    //     0x827684: ldur            x9, [x4, #7]
    // 0x827688: r3 = Null
    //     0x827688: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2c18] Null
    //     0x82768c: ldr             x3, [x3, #0xc18]
    // 0x827690: blr             x9
    // 0x827694: ldur            x0, [fp, #-8]
    // 0x827698: LoadField: r1 = r0->field_b
    //     0x827698: ldur            w1, [x0, #0xb]
    // 0x82769c: DecompressPointer r1
    //     0x82769c: add             x1, x1, HEAP, lsl #32
    // 0x8276a0: str             xzr, [SP]
    // 0x8276a4: ldur            x2, [fp, #-0x10]
    // 0x8276a8: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8276a8: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8276ac: r0 = indexOf()
    //     0x8276ac: bl              #0x9f1368  ; [dart:collection] ListBase::indexOf
    // 0x8276b0: LeaveFrame
    //     0x8276b0: mov             SP, fp
    //     0x8276b4: ldp             fp, lr, [SP], #0x10
    // 0x8276b8: ret
    //     0x8276b8: ret             
    // 0x8276bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8276bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8276c0: b               #0x827660
  }
  List<X0> +(DelegatingList<X0>, List<X0>) {
    // ** addr: 0x8276dc, size: 0x58
    // 0x8276dc: EnterFrame
    //     0x8276dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8276e0: mov             fp, SP
    // 0x8276e4: ldr             x0, [fp, #0x18]
    // 0x8276e8: LoadField: r2 = r0->field_7
    //     0x8276e8: ldur            w2, [x0, #7]
    // 0x8276ec: DecompressPointer r2
    //     0x8276ec: add             x2, x2, HEAP, lsl #32
    // 0x8276f0: ldr             x0, [fp, #0x10]
    // 0x8276f4: r1 = Null
    //     0x8276f4: mov             x1, NULL
    // 0x8276f8: r8 = List<X0>
    //     0x8276f8: add             x8, PP, #0x15, lsl #12  ; [pp+0x15c28] Type: List<X0>
    //     0x8276fc: ldr             x8, [x8, #0xc28]
    // 0x827700: LoadField: r9 = r8->field_7
    //     0x827700: ldur            x9, [x8, #7]
    // 0x827704: r3 = Null
    //     0x827704: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2c28] Null
    //     0x827708: ldr             x3, [x3, #0xc28]
    // 0x82770c: blr             x9
    // 0x827710: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x827710: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x827714: r0 = Throw()
    //     0x827714: bl              #0x13ddb2c  ; ThrowStub
    // 0x827718: brk             #0
  }
  X0 [](DelegatingList<X0>, int) {
    // ** addr: 0x827734, size: 0xa8
    // 0x827734: EnterFrame
    //     0x827734: stp             fp, lr, [SP, #-0x10]!
    //     0x827738: mov             fp, SP
    // 0x82773c: ldr             x0, [fp, #0x10]
    // 0x827740: r2 = Null
    //     0x827740: mov             x2, NULL
    // 0x827744: r1 = Null
    //     0x827744: mov             x1, NULL
    // 0x827748: branchIfSmi(r0, 0x827770)
    //     0x827748: tbz             w0, #0, #0x827770
    // 0x82774c: r4 = LoadClassIdInstr(r0)
    //     0x82774c: ldur            x4, [x0, #-1]
    //     0x827750: ubfx            x4, x4, #0xc, #0x14
    // 0x827754: sub             x4, x4, #0x3c
    // 0x827758: cmp             x4, #1
    // 0x82775c: b.ls            #0x827770
    // 0x827760: r8 = int
    //     0x827760: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x827764: r3 = Null
    //     0x827764: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2c38] Null
    //     0x827768: ldr             x3, [x3, #0xc38]
    // 0x82776c: r0 = int()
    //     0x82776c: bl              #0x13ee980  ; IsType_int_Stub
    // 0x827770: ldr             x2, [fp, #0x18]
    // 0x827774: LoadField: r3 = r2->field_b
    //     0x827774: ldur            w3, [x2, #0xb]
    // 0x827778: DecompressPointer r3
    //     0x827778: add             x3, x3, HEAP, lsl #32
    // 0x82777c: LoadField: r2 = r3->field_b
    //     0x82777c: ldur            w2, [x3, #0xb]
    // 0x827780: ldr             x4, [fp, #0x10]
    // 0x827784: r5 = LoadInt32Instr(r4)
    //     0x827784: sbfx            x5, x4, #1, #0x1f
    //     0x827788: tbz             w4, #0, #0x827790
    //     0x82778c: ldur            x5, [x4, #7]
    // 0x827790: r0 = LoadInt32Instr(r2)
    //     0x827790: sbfx            x0, x2, #1, #0x1f
    // 0x827794: mov             x1, x5
    // 0x827798: cmp             x1, x0
    // 0x82779c: b.hs            #0x8277c0
    // 0x8277a0: LoadField: r1 = r3->field_f
    //     0x8277a0: ldur            w1, [x3, #0xf]
    // 0x8277a4: DecompressPointer r1
    //     0x8277a4: add             x1, x1, HEAP, lsl #32
    // 0x8277a8: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x8277a8: add             x16, x1, x5, lsl #2
    //     0x8277ac: ldur            w0, [x16, #0xf]
    // 0x8277b0: DecompressPointer r0
    //     0x8277b0: add             x0, x0, HEAP, lsl #32
    // 0x8277b4: LeaveFrame
    //     0x8277b4: mov             SP, fp
    //     0x8277b8: ldp             fp, lr, [SP], #0x10
    // 0x8277bc: ret
    //     0x8277bc: ret             
    // 0x8277c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8277c0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ sort(/* No info */) {
    // ** addr: 0x8a20ec, size: 0x68
    // 0x8a20ec: EnterFrame
    //     0x8a20ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8a20f0: mov             fp, SP
    // 0x8a20f4: AllocStack(0x8)
    //     0x8a20f4: sub             SP, SP, #8
    // 0x8a20f8: SetupParameters([dynamic _ = Null /* r0 */])
    //     0x8a20f8: ldur            w0, [x4, #0x13]
    //     0x8a20fc: sub             x2, x0, #2
    //     0x8a2100: cmp             w2, #2
    //     0x8a2104: b.lt            #0x8a2114
    //     0x8a2108: add             x0, fp, w2, sxtw #2
    //     0x8a210c: ldr             x0, [x0, #8]
    //     0x8a2110: b               #0x8a2118
    //     0x8a2114: mov             x0, NULL
    // 0x8a2118: CheckStackOverflow
    //     0x8a2118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8a211c: cmp             SP, x16
    //     0x8a2120: b.ls            #0x8a214c
    // 0x8a2124: LoadField: r2 = r1->field_b
    //     0x8a2124: ldur            w2, [x1, #0xb]
    // 0x8a2128: DecompressPointer r2
    //     0x8a2128: add             x2, x2, HEAP, lsl #32
    // 0x8a212c: str             x0, [SP]
    // 0x8a2130: mov             x1, x2
    // 0x8a2134: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x8a2134: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x8a2138: r0 = sort()
    //     0x8a2138: bl              #0x9f9bf0  ; [dart:collection] ListBase::sort
    // 0x8a213c: r0 = Null
    //     0x8a213c: mov             x0, NULL
    // 0x8a2140: LeaveFrame
    //     0x8a2140: mov             SP, fp
    //     0x8a2144: ldp             fp, lr, [SP], #0x10
    // 0x8a2148: ret
    //     0x8a2148: ret             
    // 0x8a214c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8a214c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8a2150: b               #0x8a2124
  }
  _ sublist(/* No info */) {
    // ** addr: 0x8d19b4, size: 0x64
    // 0x8d19b4: EnterFrame
    //     0x8d19b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8d19b8: mov             fp, SP
    // 0x8d19bc: AllocStack(0x8)
    //     0x8d19bc: sub             SP, SP, #8
    // 0x8d19c0: SetupParameters([dynamic _ = Null /* r0 */])
    //     0x8d19c0: ldur            w0, [x4, #0x13]
    //     0x8d19c4: sub             x3, x0, #4
    //     0x8d19c8: cmp             w3, #2
    //     0x8d19cc: b.lt            #0x8d19dc
    //     0x8d19d0: add             x0, fp, w3, sxtw #2
    //     0x8d19d4: ldr             x0, [x0, #8]
    //     0x8d19d8: b               #0x8d19e0
    //     0x8d19dc: mov             x0, NULL
    // 0x8d19e0: CheckStackOverflow
    //     0x8d19e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8d19e4: cmp             SP, x16
    //     0x8d19e8: b.ls            #0x8d1a10
    // 0x8d19ec: LoadField: r3 = r1->field_b
    //     0x8d19ec: ldur            w3, [x1, #0xb]
    // 0x8d19f0: DecompressPointer r3
    //     0x8d19f0: add             x3, x3, HEAP, lsl #32
    // 0x8d19f4: str             x0, [SP]
    // 0x8d19f8: mov             x1, x3
    // 0x8d19fc: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x8d19fc: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x8d1a00: r0 = sublist()
    //     0x8d1a00: bl              #0xa014c4  ; [dart:core] _GrowableList::sublist
    // 0x8d1a04: LeaveFrame
    //     0x8d1a04: mov             SP, fp
    //     0x8d1a08: ldp             fp, lr, [SP], #0x10
    // 0x8d1a0c: ret
    //     0x8d1a0c: ret             
    // 0x8d1a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8d1a10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8d1a14: b               #0x8d19ec
  }
  get _ reversed(/* No info */) {
    // ** addr: 0x8d306c, size: 0x38
    // 0x8d306c: EnterFrame
    //     0x8d306c: stp             fp, lr, [SP, #-0x10]!
    //     0x8d3070: mov             fp, SP
    // 0x8d3074: AllocStack(0x8)
    //     0x8d3074: sub             SP, SP, #8
    // 0x8d3078: LoadField: r0 = r1->field_b
    //     0x8d3078: ldur            w0, [x1, #0xb]
    // 0x8d307c: DecompressPointer r0
    //     0x8d307c: add             x0, x0, HEAP, lsl #32
    // 0x8d3080: stur            x0, [fp, #-8]
    // 0x8d3084: LoadField: r1 = r0->field_7
    //     0x8d3084: ldur            w1, [x0, #7]
    // 0x8d3088: DecompressPointer r1
    //     0x8d3088: add             x1, x1, HEAP, lsl #32
    // 0x8d308c: r0 = ReversedListIterable()
    //     0x8d308c: bl              #0x7da320  ; AllocateReversedListIterableStub -> ReversedListIterable<X0> (size=0x10)
    // 0x8d3090: ldur            x1, [fp, #-8]
    // 0x8d3094: StoreField: r0->field_b = r1
    //     0x8d3094: stur            w1, [x0, #0xb]
    // 0x8d3098: LeaveFrame
    //     0x8d3098: mov             SP, fp
    //     0x8d309c: ldp             fp, lr, [SP], #0x10
    // 0x8d30a0: ret
    //     0x8d30a0: ret             
  }
  _ getRange(/* No info */) {
    // ** addr: 0x8db47c, size: 0x38
    // 0x8db47c: EnterFrame
    //     0x8db47c: stp             fp, lr, [SP, #-0x10]!
    //     0x8db480: mov             fp, SP
    // 0x8db484: CheckStackOverflow
    //     0x8db484: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8db488: cmp             SP, x16
    //     0x8db48c: b.ls            #0x8db4ac
    // 0x8db490: LoadField: r0 = r1->field_b
    //     0x8db490: ldur            w0, [x1, #0xb]
    // 0x8db494: DecompressPointer r0
    //     0x8db494: add             x0, x0, HEAP, lsl #32
    // 0x8db498: mov             x1, x0
    // 0x8db49c: r0 = getRange()
    //     0x8db49c: bl              #0xa0c058  ; [dart:collection] ListBase::getRange
    // 0x8db4a0: LeaveFrame
    //     0x8db4a0: mov             SP, fp
    //     0x8db4a4: ldp             fp, lr, [SP], #0x10
    // 0x8db4a8: ret
    //     0x8db4a8: ret             
    // 0x8db4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8db4ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8db4b0: b               #0x8db490
  }
  X0 [](DelegatingList<X0>, int) {
    // ** addr: 0x12bb39c, size: 0x54
    // 0x12bb39c: ldr             x2, [SP, #8]
    // 0x12bb3a0: LoadField: r3 = r2->field_b
    //     0x12bb3a0: ldur            w3, [x2, #0xb]
    // 0x12bb3a4: DecompressPointer r3
    //     0x12bb3a4: add             x3, x3, HEAP, lsl #32
    // 0x12bb3a8: LoadField: r2 = r3->field_b
    //     0x12bb3a8: ldur            w2, [x3, #0xb]
    // 0x12bb3ac: ldr             x4, [SP]
    // 0x12bb3b0: r5 = LoadInt32Instr(r4)
    //     0x12bb3b0: sbfx            x5, x4, #1, #0x1f
    //     0x12bb3b4: tbz             w4, #0, #0x12bb3bc
    //     0x12bb3b8: ldur            x5, [x4, #7]
    // 0x12bb3bc: r0 = LoadInt32Instr(r2)
    //     0x12bb3bc: sbfx            x0, x2, #1, #0x1f
    // 0x12bb3c0: mov             x1, x5
    // 0x12bb3c4: cmp             x1, x0
    // 0x12bb3c8: b.hs            #0x12bb3e4
    // 0x12bb3cc: LoadField: r1 = r3->field_f
    //     0x12bb3cc: ldur            w1, [x3, #0xf]
    // 0x12bb3d0: DecompressPointer r1
    //     0x12bb3d0: add             x1, x1, HEAP, lsl #32
    // 0x12bb3d4: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0x12bb3d4: add             x16, x1, x5, lsl #2
    //     0x12bb3d8: ldur            w0, [x16, #0xf]
    // 0x12bb3dc: DecompressPointer r0
    //     0x12bb3dc: add             x0, x0, HEAP, lsl #32
    // 0x12bb3e0: ret
    //     0x12bb3e0: ret             
    // 0x12bb3e4: EnterFrame
    //     0x12bb3e4: stp             fp, lr, [SP, #-0x10]!
    //     0x12bb3e8: mov             fp, SP
    // 0x12bb3ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x12bb3ec: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
}
