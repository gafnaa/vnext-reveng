// lib: , url: package:collection/src/priority_queue.dart

// class id: 1048656, size: 0x8
class :: {
}

// class id: 3567, size: 0x1c, field offset: 0x8
class HeapPriorityQueue<X0> extends Object
    implements PriorityQueue<X0> {

  bool contains(HeapPriorityQueue<X0>, X0) {
    // ** addr: 0x83a010, size: 0x4c
    // 0x83a010: EnterFrame
    //     0x83a010: stp             fp, lr, [SP, #-0x10]!
    //     0x83a014: mov             fp, SP
    // 0x83a018: CheckStackOverflow
    //     0x83a018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83a01c: cmp             SP, x16
    //     0x83a020: b.ls            #0x83a03c
    // 0x83a024: ldr             x1, [fp, #0x18]
    // 0x83a028: ldr             x2, [fp, #0x10]
    // 0x83a02c: r0 = contains()
    //     0x83a02c: bl              #0x83a044  ; [package:collection/src/priority_queue.dart] HeapPriorityQueue::contains
    // 0x83a030: LeaveFrame
    //     0x83a030: mov             SP, fp
    //     0x83a034: ldp             fp, lr, [SP], #0x10
    // 0x83a038: ret
    //     0x83a038: ret             
    // 0x83a03c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a03c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a040: b               #0x83a024
  }
  bool contains(HeapPriorityQueue<X0>, X0) {
    // ** addr: 0x83a044, size: 0x50
    // 0x83a044: EnterFrame
    //     0x83a044: stp             fp, lr, [SP, #-0x10]!
    //     0x83a048: mov             fp, SP
    // 0x83a04c: LoadField: r2 = r1->field_7
    //     0x83a04c: ldur            w2, [x1, #7]
    // 0x83a050: DecompressPointer r2
    //     0x83a050: add             x2, x2, HEAP, lsl #32
    // 0x83a054: r0 = "Masuk"
    //     0x83a054: add             x0, PP, #0x1b, lsl #12  ; [pp+0x1bd08] "Masuk"
    //     0x83a058: ldr             x0, [x0, #0xd08]
    // 0x83a05c: r1 = Null
    //     0x83a05c: mov             x1, NULL
    // 0x83a060: cmp             w2, NULL
    // 0x83a064: b.eq            #0x83a084
    // 0x83a068: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x83a068: ldur            w4, [x2, #0x17]
    // 0x83a06c: DecompressPointer r4
    //     0x83a06c: add             x4, x4, HEAP, lsl #32
    // 0x83a070: r8 = X0
    //     0x83a070: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x83a074: LoadField: r9 = r4->field_7
    //     0x83a074: ldur            x9, [x4, #7]
    // 0x83a078: r3 = Null
    //     0x83a078: add             x3, PP, #0x82, lsl #12  ; [pp+0x82910] Null
    //     0x83a07c: ldr             x3, [x3, #0x910]
    // 0x83a080: blr             x9
    // 0x83a084: r0 = false
    //     0x83a084: add             x0, NULL, #0x30  ; false
    // 0x83a088: LeaveFrame
    //     0x83a088: mov             SP, fp
    //     0x83a08c: ldp             fp, lr, [SP], #0x10
    // 0x83a090: ret
    //     0x83a090: ret             
  }
  _ toString(/* No info */) {
    // ** addr: 0x110af38, size: 0x44
    // 0x110af38: EnterFrame
    //     0x110af38: stp             fp, lr, [SP, #-0x10]!
    //     0x110af3c: mov             fp, SP
    // 0x110af40: CheckStackOverflow
    //     0x110af40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110af44: cmp             SP, x16
    //     0x110af48: b.ls            #0x110af74
    // 0x110af4c: ldr             x0, [fp, #0x10]
    // 0x110af50: LoadField: r1 = r0->field_f
    //     0x110af50: ldur            w1, [x0, #0xf]
    // 0x110af54: DecompressPointer r1
    //     0x110af54: add             x1, x1, HEAP, lsl #32
    // 0x110af58: r2 = 0
    //     0x110af58: mov             x2, #0
    // 0x110af5c: r0 = take()
    //     0x110af5c: bl              #0x82e2ec  ; [dart:collection] ListBase::take
    // 0x110af60: mov             x1, x0
    // 0x110af64: r0 = iterableToShortString()
    //     0x110af64: bl              #0x1101224  ; [dart:core] Iterable::iterableToShortString
    // 0x110af68: LeaveFrame
    //     0x110af68: mov             SP, fp
    //     0x110af6c: ldp             fp, lr, [SP], #0x10
    // 0x110af70: ret
    //     0x110af70: ret             
    // 0x110af74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110af74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110af78: b               #0x110af4c
  }
}

// class id: 3568, size: 0xc, field offset: 0x8
abstract class PriorityQueue<X0> extends Object {
}
