// lib: , url: package:file/src/interface/file.dart

// class id: 1048735, size: 0x8
class :: {
}

// class id: 3951, size: 0x8, field offset: 0x8
abstract class File extends Object
    implements FileSystemEntity, File {
}
