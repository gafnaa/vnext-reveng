// lib: , url: package:file/src/interface/directory.dart

// class id: 1048734, size: 0x8
class :: {
}

// class id: 3378, size: 0x8, field offset: 0x8
abstract class Directory extends Object
    implements FileSystemEntity, Directory {
}
