// lib: , url: package:file/src/backends/local/local_file_system.dart

// class id: 1048728, size: 0x8
class :: {
}

// class id: 3388, size: 0x8, field offset: 0x8
//   const constructor, 
class LocalFileSystem extends FileSystem {

  _ file(/* No info */) {
    // ** addr: 0x118819c, size: 0x90
    // 0x118819c: EnterFrame
    //     0x118819c: stp             fp, lr, [SP, #-0x10]!
    //     0x11881a0: mov             fp, SP
    // 0x11881a4: AllocStack(0x10)
    //     0x11881a4: sub             SP, SP, #0x10
    // 0x11881a8: SetupParameters(LocalFileSystem this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x11881a8: mov             x0, x1
    //     0x11881ac: mov             x1, x2
    //     0x11881b0: stur            x2, [fp, #-8]
    // 0x11881b4: CheckStackOverflow
    //     0x11881b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11881b8: cmp             SP, x16
    //     0x11881bc: b.ls            #0x1188224
    // 0x11881c0: r0 = current()
    //     0x11881c0: bl              #0x7ed1b8  ; [dart:io] IOOverrides::current
    // 0x11881c4: r0 = _File()
    //     0x11881c4: bl              #0x7fb71c  ; Allocate_FileStub -> _File (size=0x10)
    // 0x11881c8: ldur            x1, [fp, #-8]
    // 0x11881cc: stur            x0, [fp, #-0x10]
    // 0x11881d0: StoreField: r0->field_7 = r1
    //     0x11881d0: stur            w1, [x0, #7]
    // 0x11881d4: r0 = _toUtf8Array()
    //     0x11881d4: bl              #0x7ed07c  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x11881d8: ldur            x2, [fp, #-0x10]
    // 0x11881dc: StoreField: r2->field_b = r0
    //     0x11881dc: stur            w0, [x2, #0xb]
    //     0x11881e0: ldurb           w16, [x2, #-1]
    //     0x11881e4: ldurb           w17, [x0, #-1]
    //     0x11881e8: and             x16, x17, x16, lsr #2
    //     0x11881ec: tst             x16, HEAP, lsr #32
    //     0x11881f0: b.eq            #0x11881f8
    //     0x11881f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11881f8: r1 = <File, File>
    //     0x11881f8: add             x1, PP, #0x94, lsl #12  ; [pp+0x94f40] TypeArguments: <File, File>
    //     0x11881fc: ldr             x1, [x1, #0xf40]
    // 0x1188200: r0 = LocalFile()
    //     0x1188200: bl              #0x118822c  ; AllocateLocalFileStub -> LocalFile (size=0x14)
    // 0x1188204: r1 = Instance_LocalFileSystem
    //     0x1188204: add             x1, PP, #0x94, lsl #12  ; [pp+0x94f38] Obj!LocalFileSystem@129ff81
    //     0x1188208: ldr             x1, [x1, #0xf38]
    // 0x118820c: StoreField: r0->field_b = r1
    //     0x118820c: stur            w1, [x0, #0xb]
    // 0x1188210: ldur            x1, [fp, #-0x10]
    // 0x1188214: StoreField: r0->field_f = r1
    //     0x1188214: stur            w1, [x0, #0xf]
    // 0x1188218: LeaveFrame
    //     0x1188218: mov             SP, fp
    //     0x118821c: ldp             fp, lr, [SP], #0x10
    // 0x1188220: ret
    //     0x1188220: ret             
    // 0x1188224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1188224: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1188228: b               #0x11881c0
  }
  _ directory(/* No info */) {
    // ** addr: 0x118836c, size: 0x90
    // 0x118836c: EnterFrame
    //     0x118836c: stp             fp, lr, [SP, #-0x10]!
    //     0x1188370: mov             fp, SP
    // 0x1188374: AllocStack(0x10)
    //     0x1188374: sub             SP, SP, #0x10
    // 0x1188378: SetupParameters(LocalFileSystem this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x8 */)
    //     0x1188378: mov             x0, x1
    //     0x118837c: mov             x1, x2
    //     0x1188380: stur            x2, [fp, #-8]
    // 0x1188384: CheckStackOverflow
    //     0x1188384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1188388: cmp             SP, x16
    //     0x118838c: b.ls            #0x11883f4
    // 0x1188390: r0 = current()
    //     0x1188390: bl              #0x7ed1b8  ; [dart:io] IOOverrides::current
    // 0x1188394: r0 = _Directory()
    //     0x1188394: bl              #0x7ecd58  ; Allocate_DirectoryStub -> _Directory (size=0x10)
    // 0x1188398: ldur            x1, [fp, #-8]
    // 0x118839c: stur            x0, [fp, #-0x10]
    // 0x11883a0: StoreField: r0->field_7 = r1
    //     0x11883a0: stur            w1, [x0, #7]
    // 0x11883a4: r0 = _toUtf8Array()
    //     0x11883a4: bl              #0x7ed07c  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0x11883a8: ldur            x2, [fp, #-0x10]
    // 0x11883ac: StoreField: r2->field_b = r0
    //     0x11883ac: stur            w0, [x2, #0xb]
    //     0x11883b0: ldurb           w16, [x2, #-1]
    //     0x11883b4: ldurb           w17, [x0, #-1]
    //     0x11883b8: and             x16, x17, x16, lsr #2
    //     0x11883bc: tst             x16, HEAP, lsr #32
    //     0x11883c0: b.eq            #0x11883c8
    //     0x11883c4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11883c8: r1 = <LocalDirectory, Directory>
    //     0x11883c8: add             x1, PP, #0x94, lsl #12  ; [pp+0x94f58] TypeArguments: <LocalDirectory, Directory>
    //     0x11883cc: ldr             x1, [x1, #0xf58]
    // 0x11883d0: r0 = LocalDirectory()
    //     0x11883d0: bl              #0x11883fc  ; AllocateLocalDirectoryStub -> LocalDirectory (size=0x14)
    // 0x11883d4: r1 = Instance_LocalFileSystem
    //     0x11883d4: add             x1, PP, #0x94, lsl #12  ; [pp+0x94f38] Obj!LocalFileSystem@129ff81
    //     0x11883d8: ldr             x1, [x1, #0xf38]
    // 0x11883dc: StoreField: r0->field_b = r1
    //     0x11883dc: stur            w1, [x0, #0xb]
    // 0x11883e0: ldur            x1, [fp, #-0x10]
    // 0x11883e4: StoreField: r0->field_f = r1
    //     0x11883e4: stur            w1, [x0, #0xf]
    // 0x11883e8: LeaveFrame
    //     0x11883e8: mov             SP, fp
    //     0x11883ec: ldp             fp, lr, [SP], #0x10
    // 0x11883f0: ret
    //     0x11883f0: ret             
    // 0x11883f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11883f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11883f8: b               #0x1188390
  }
}
