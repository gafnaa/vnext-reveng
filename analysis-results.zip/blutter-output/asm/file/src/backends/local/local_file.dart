// lib: , url: package:file/src/backends/local/local_file.dart

// class id: 1048727, size: 0x8
class :: {
}

// class id: 3382, size: 0x14, field offset: 0x14
class LocalFile extends _MixinApplication712&LocalFileSystemEntity&ForwardingFile {

  _ toString(/* No info */) {
    // ** addr: 0x1114b5c, size: 0xa8
    // 0x1114b5c: EnterFrame
    //     0x1114b5c: stp             fp, lr, [SP, #-0x10]!
    //     0x1114b60: mov             fp, SP
    // 0x1114b64: AllocStack(0x10)
    //     0x1114b64: sub             SP, SP, #0x10
    // 0x1114b68: CheckStackOverflow
    //     0x1114b68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114b6c: cmp             SP, x16
    //     0x1114b70: b.ls            #0x1114bfc
    // 0x1114b74: r1 = Null
    //     0x1114b74: mov             x1, NULL
    // 0x1114b78: r2 = 6
    //     0x1114b78: mov             x2, #6
    // 0x1114b7c: r0 = AllocateArray()
    //     0x1114b7c: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114b80: mov             x2, x0
    // 0x1114b84: stur            x2, [fp, #-8]
    // 0x1114b88: r16 = "LocalFile: \'"
    //     0x1114b88: add             x16, PP, #0xa0, lsl #12  ; [pp+0xa0668] "LocalFile: \'"
    //     0x1114b8c: ldr             x16, [x16, #0x668]
    // 0x1114b90: StoreField: r2->field_f = r16
    //     0x1114b90: stur            w16, [x2, #0xf]
    // 0x1114b94: ldr             x0, [fp, #0x10]
    // 0x1114b98: LoadField: r1 = r0->field_f
    //     0x1114b98: ldur            w1, [x0, #0xf]
    // 0x1114b9c: DecompressPointer r1
    //     0x1114b9c: add             x1, x1, HEAP, lsl #32
    // 0x1114ba0: r0 = LoadClassIdInstr(r1)
    //     0x1114ba0: ldur            x0, [x1, #-1]
    //     0x1114ba4: ubfx            x0, x0, #0xc, #0x14
    // 0x1114ba8: r0 = GDT[cid_x0 + -0xfc5]()
    //     0x1114ba8: sub             lr, x0, #0xfc5
    //     0x1114bac: ldr             lr, [x21, lr, lsl #3]
    //     0x1114bb0: blr             lr
    // 0x1114bb4: ldur            x1, [fp, #-8]
    // 0x1114bb8: ArrayStore: r1[1] = r0  ; List_4
    //     0x1114bb8: add             x25, x1, #0x13
    //     0x1114bbc: str             w0, [x25]
    //     0x1114bc0: tbz             w0, #0, #0x1114bdc
    //     0x1114bc4: ldurb           w16, [x1, #-1]
    //     0x1114bc8: ldurb           w17, [x0, #-1]
    //     0x1114bcc: and             x16, x17, x16, lsr #2
    //     0x1114bd0: tst             x16, HEAP, lsr #32
    //     0x1114bd4: b.eq            #0x1114bdc
    //     0x1114bd8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1114bdc: ldur            x0, [fp, #-8]
    // 0x1114be0: r16 = "\'"
    //     0x1114be0: ldr             x16, [PP, #0x3900]  ; [pp+0x3900] "\'"
    // 0x1114be4: ArrayStore: r0[0] = r16  ; List_4
    //     0x1114be4: stur            w16, [x0, #0x17]
    // 0x1114be8: str             x0, [SP]
    // 0x1114bec: r0 = _interpolate()
    //     0x1114bec: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114bf0: LeaveFrame
    //     0x1114bf0: mov             SP, fp
    //     0x1114bf4: ldp             fp, lr, [SP], #0x10
    // 0x1114bf8: ret
    //     0x1114bf8: ret             
    // 0x1114bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114bfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114c00: b               #0x1114b74
  }
}
