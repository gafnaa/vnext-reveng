// lib: , url: package:file/src/backends/local/local_file_system_entity.dart

// class id: 1048729, size: 0x8
class :: {
}

// class id: 3380, size: 0x14, field offset: 0xc
abstract class LocalFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> extends ForwardingFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> {

  _ wrapFile(/* No info */) {
    // ** addr: 0x127efe0, size: 0x40
    // 0x127efe0: EnterFrame
    //     0x127efe0: stp             fp, lr, [SP, #-0x10]!
    //     0x127efe4: mov             fp, SP
    // 0x127efe8: AllocStack(0x8)
    //     0x127efe8: sub             SP, SP, #8
    // 0x127efec: SetupParameters(LocalFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> this /* r1 => r0 */, dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x127efec: mov             x0, x1
    //     0x127eff0: stur            x2, [fp, #-8]
    // 0x127eff4: r1 = <File, File>
    //     0x127eff4: add             x1, PP, #0x94, lsl #12  ; [pp+0x94f40] TypeArguments: <File, File>
    //     0x127eff8: ldr             x1, [x1, #0xf40]
    // 0x127effc: r0 = LocalFile()
    //     0x127effc: bl              #0x118822c  ; AllocateLocalFileStub -> LocalFile (size=0x14)
    // 0x127f000: r1 = Instance_LocalFileSystem
    //     0x127f000: add             x1, PP, #0x94, lsl #12  ; [pp+0x94f38] Obj!LocalFileSystem@129ff81
    //     0x127f004: ldr             x1, [x1, #0xf38]
    // 0x127f008: StoreField: r0->field_b = r1
    //     0x127f008: stur            w1, [x0, #0xb]
    // 0x127f00c: ldur            x1, [fp, #-8]
    // 0x127f010: StoreField: r0->field_f = r1
    //     0x127f010: stur            w1, [x0, #0xf]
    // 0x127f014: LeaveFrame
    //     0x127f014: mov             SP, fp
    //     0x127f018: ldp             fp, lr, [SP], #0x10
    // 0x127f01c: ret
    //     0x127f01c: ret             
  }
  _ wrapDirectory(/* No info */) {
    // ** addr: 0x12de368, size: 0x40
    // 0x12de368: EnterFrame
    //     0x12de368: stp             fp, lr, [SP, #-0x10]!
    //     0x12de36c: mov             fp, SP
    // 0x12de370: AllocStack(0x8)
    //     0x12de370: sub             SP, SP, #8
    // 0x12de374: SetupParameters(LocalFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> this /* r1 => r0 */, dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x12de374: mov             x0, x1
    //     0x12de378: stur            x2, [fp, #-8]
    // 0x12de37c: r1 = <LocalDirectory, Directory>
    //     0x12de37c: add             x1, PP, #0x94, lsl #12  ; [pp+0x94f58] TypeArguments: <LocalDirectory, Directory>
    //     0x12de380: ldr             x1, [x1, #0xf58]
    // 0x12de384: r0 = LocalDirectory()
    //     0x12de384: bl              #0x11883fc  ; AllocateLocalDirectoryStub -> LocalDirectory (size=0x14)
    // 0x12de388: r1 = Instance_LocalFileSystem
    //     0x12de388: add             x1, PP, #0x94, lsl #12  ; [pp+0x94f38] Obj!LocalFileSystem@129ff81
    //     0x12de38c: ldr             x1, [x1, #0xf38]
    // 0x12de390: StoreField: r0->field_b = r1
    //     0x12de390: stur            w1, [x0, #0xb]
    // 0x12de394: ldur            x1, [fp, #-8]
    // 0x12de398: StoreField: r0->field_f = r1
    //     0x12de398: stur            w1, [x0, #0xf]
    // 0x12de39c: LeaveFrame
    //     0x12de39c: mov             SP, fp
    //     0x12de3a0: ldp             fp, lr, [SP], #0x10
    // 0x12de3a4: ret
    //     0x12de3a4: ret             
  }
}
