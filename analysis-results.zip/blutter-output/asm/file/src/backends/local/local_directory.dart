// lib: , url: package:file/src/backends/local/local_directory.dart

// class id: 1048726, size: 0x8
class :: {
}

// class id: 3385, size: 0x14, field offset: 0x14
class LocalDirectory extends _MixinApplication711&LocalFileSystemEntity&ForwardingDirectory&DirectoryAddOnsMixin {

  _ toString(/* No info */) {
    // ** addr: 0x1114ab4, size: 0xa8
    // 0x1114ab4: EnterFrame
    //     0x1114ab4: stp             fp, lr, [SP, #-0x10]!
    //     0x1114ab8: mov             fp, SP
    // 0x1114abc: AllocStack(0x10)
    //     0x1114abc: sub             SP, SP, #0x10
    // 0x1114ac0: CheckStackOverflow
    //     0x1114ac0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1114ac4: cmp             SP, x16
    //     0x1114ac8: b.ls            #0x1114b54
    // 0x1114acc: r1 = Null
    //     0x1114acc: mov             x1, NULL
    // 0x1114ad0: r2 = 6
    //     0x1114ad0: mov             x2, #6
    // 0x1114ad4: r0 = AllocateArray()
    //     0x1114ad4: bl              #0x13df928  ; AllocateArrayStub
    // 0x1114ad8: mov             x2, x0
    // 0x1114adc: stur            x2, [fp, #-8]
    // 0x1114ae0: r16 = "LocalDirectory: \'"
    //     0x1114ae0: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1c98] "LocalDirectory: \'"
    //     0x1114ae4: ldr             x16, [x16, #0xc98]
    // 0x1114ae8: StoreField: r2->field_f = r16
    //     0x1114ae8: stur            w16, [x2, #0xf]
    // 0x1114aec: ldr             x0, [fp, #0x10]
    // 0x1114af0: LoadField: r1 = r0->field_f
    //     0x1114af0: ldur            w1, [x0, #0xf]
    // 0x1114af4: DecompressPointer r1
    //     0x1114af4: add             x1, x1, HEAP, lsl #32
    // 0x1114af8: r0 = LoadClassIdInstr(r1)
    //     0x1114af8: ldur            x0, [x1, #-1]
    //     0x1114afc: ubfx            x0, x0, #0xc, #0x14
    // 0x1114b00: r0 = GDT[cid_x0 + -0xfc5]()
    //     0x1114b00: sub             lr, x0, #0xfc5
    //     0x1114b04: ldr             lr, [x21, lr, lsl #3]
    //     0x1114b08: blr             lr
    // 0x1114b0c: ldur            x1, [fp, #-8]
    // 0x1114b10: ArrayStore: r1[1] = r0  ; List_4
    //     0x1114b10: add             x25, x1, #0x13
    //     0x1114b14: str             w0, [x25]
    //     0x1114b18: tbz             w0, #0, #0x1114b34
    //     0x1114b1c: ldurb           w16, [x1, #-1]
    //     0x1114b20: ldurb           w17, [x0, #-1]
    //     0x1114b24: and             x16, x17, x16, lsr #2
    //     0x1114b28: tst             x16, HEAP, lsr #32
    //     0x1114b2c: b.eq            #0x1114b34
    //     0x1114b30: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1114b34: ldur            x0, [fp, #-8]
    // 0x1114b38: r16 = "\'"
    //     0x1114b38: ldr             x16, [PP, #0x3900]  ; [pp+0x3900] "\'"
    // 0x1114b3c: ArrayStore: r0[0] = r16  ; List_4
    //     0x1114b3c: stur            w16, [x0, #0x17]
    // 0x1114b40: str             x0, [SP]
    // 0x1114b44: r0 = _interpolate()
    //     0x1114b44: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x1114b48: LeaveFrame
    //     0x1114b48: mov             SP, fp
    //     0x1114b4c: ldp             fp, lr, [SP], #0x10
    // 0x1114b50: ret
    //     0x1114b50: ret             
    // 0x1114b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1114b54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1114b58: b               #0x1114acc
  }
}
