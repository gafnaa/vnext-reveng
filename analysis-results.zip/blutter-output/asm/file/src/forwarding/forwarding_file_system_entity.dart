// lib: , url: package:file/src/forwarding/forwarding_file_system_entity.dart

// class id: 1048733, size: 0x8
class :: {
}

// class id: 3379, size: 0xc, field offset: 0x8
abstract class ForwardingFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> extends Object
    implements FileSystemEntity {

  _ exists(/* No info */) {
    // ** addr: 0x11ba3e8, size: 0x54
    // 0x11ba3e8: EnterFrame
    //     0x11ba3e8: stp             fp, lr, [SP, #-0x10]!
    //     0x11ba3ec: mov             fp, SP
    // 0x11ba3f0: CheckStackOverflow
    //     0x11ba3f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ba3f4: cmp             SP, x16
    //     0x11ba3f8: b.ls            #0x11ba434
    // 0x11ba3fc: LoadField: r0 = r1->field_f
    //     0x11ba3fc: ldur            w0, [x1, #0xf]
    // 0x11ba400: DecompressPointer r0
    //     0x11ba400: add             x0, x0, HEAP, lsl #32
    // 0x11ba404: r1 = LoadClassIdInstr(r0)
    //     0x11ba404: ldur            x1, [x0, #-1]
    //     0x11ba408: ubfx            x1, x1, #0xc, #0x14
    // 0x11ba40c: mov             x16, x0
    // 0x11ba410: mov             x0, x1
    // 0x11ba414: mov             x1, x16
    // 0x11ba418: r0 = GDT[cid_x0 + 0x1f47]()
    //     0x11ba418: mov             x17, #0x1f47
    //     0x11ba41c: add             lr, x0, x17
    //     0x11ba420: ldr             lr, [x21, lr, lsl #3]
    //     0x11ba424: blr             lr
    // 0x11ba428: LeaveFrame
    //     0x11ba428: mov             SP, fp
    //     0x11ba42c: ldp             fp, lr, [SP], #0x10
    // 0x11ba430: ret
    //     0x11ba430: ret             
    // 0x11ba434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ba434: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ba438: b               #0x11ba3fc
  }
  _ delete(/* No info */) async {
    // ** addr: 0x11cf400, size: 0xd4
    // 0x11cf400: EnterFrame
    //     0x11cf400: stp             fp, lr, [SP, #-0x10]!
    //     0x11cf404: mov             fp, SP
    // 0x11cf408: AllocStack(0x28)
    //     0x11cf408: sub             SP, SP, #0x28
    // 0x11cf40c: SetupParameters(ForwardingFileSystemEntity<X0 bound FileSystemEntity, X1 bound FileSystemEntity> this /* r1 => r1, fp-0x18 */)
    //     0x11cf40c: stur            NULL, [fp, #-8]
    //     0x11cf410: stur            x1, [fp, #-0x18]
    // 0x11cf414: CheckStackOverflow
    //     0x11cf414: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cf418: cmp             SP, x16
    //     0x11cf41c: b.ls            #0x11cf4cc
    // 0x11cf420: LoadField: r2 = r1->field_7
    //     0x11cf420: ldur            w2, [x1, #7]
    // 0x11cf424: DecompressPointer r2
    //     0x11cf424: add             x2, x2, HEAP, lsl #32
    // 0x11cf428: mov             x0, x2
    // 0x11cf42c: stur            x2, [fp, #-0x10]
    // 0x11cf430: r0 = InitAsync()
    //     0x11cf430: bl              #0x7f5e44  ; InitAsyncStub
    // 0x11cf434: ldur            x2, [fp, #-0x18]
    // 0x11cf438: LoadField: r1 = r2->field_f
    //     0x11cf438: ldur            w1, [x2, #0xf]
    // 0x11cf43c: DecompressPointer r1
    //     0x11cf43c: add             x1, x1, HEAP, lsl #32
    // 0x11cf440: r0 = LoadClassIdInstr(r1)
    //     0x11cf440: ldur            x0, [x1, #-1]
    //     0x11cf444: ubfx            x0, x0, #0xc, #0x14
    // 0x11cf448: r16 = false
    //     0x11cf448: add             x16, NULL, #0x30  ; false
    // 0x11cf44c: str             x16, [SP]
    // 0x11cf450: r4 = const [0, 0x2, 0x1, 0x1, recursive, 0x1, null]
    //     0x11cf450: add             x4, PP, #0x92, lsl #12  ; [pp+0x92b68] List(7) [0, 0x2, 0x1, 0x1, "recursive", 0x1, Null]
    //     0x11cf454: ldr             x4, [x4, #0xb68]
    // 0x11cf458: r0 = GDT[cid_x0 + 0x1e9b]()
    //     0x11cf458: mov             x17, #0x1e9b
    //     0x11cf45c: add             lr, x0, x17
    //     0x11cf460: ldr             lr, [x21, lr, lsl #3]
    //     0x11cf464: blr             lr
    // 0x11cf468: mov             x1, x0
    // 0x11cf46c: stur            x1, [fp, #-0x20]
    // 0x11cf470: r0 = Await()
    //     0x11cf470: bl              #0x7f5c00  ; AwaitStub
    // 0x11cf474: ldur            x2, [fp, #-0x10]
    // 0x11cf478: mov             x3, x0
    // 0x11cf47c: r1 = Null
    //     0x11cf47c: mov             x1, NULL
    // 0x11cf480: stur            x3, [fp, #-0x10]
    // 0x11cf484: cmp             w2, NULL
    // 0x11cf488: b.eq            #0x11cf4ac
    // 0x11cf48c: LoadField: r4 = r2->field_1b
    //     0x11cf48c: ldur            w4, [x2, #0x1b]
    // 0x11cf490: DecompressPointer r4
    //     0x11cf490: add             x4, x4, HEAP, lsl #32
    // 0x11cf494: r8 = X1 bound FileSystemEntity
    //     0x11cf494: add             x8, PP, #0x94, lsl #12  ; [pp+0x94f18] TypeParameter: X1 bound FileSystemEntity
    //     0x11cf498: ldr             x8, [x8, #0xf18]
    // 0x11cf49c: LoadField: r9 = r4->field_7
    //     0x11cf49c: ldur            x9, [x4, #7]
    // 0x11cf4a0: r3 = Null
    //     0x11cf4a0: add             x3, PP, #0x94, lsl #12  ; [pp+0x94f20] Null
    //     0x11cf4a4: ldr             x3, [x3, #0xf20]
    // 0x11cf4a8: blr             x9
    // 0x11cf4ac: ldur            x1, [fp, #-0x18]
    // 0x11cf4b0: r0 = LoadClassIdInstr(r1)
    //     0x11cf4b0: ldur            x0, [x1, #-1]
    //     0x11cf4b4: ubfx            x0, x0, #0xc, #0x14
    // 0x11cf4b8: ldur            x2, [fp, #-0x10]
    // 0x11cf4bc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x11cf4bc: sub             lr, x0, #1, lsl #12
    //     0x11cf4c0: ldr             lr, [x21, lr, lsl #3]
    //     0x11cf4c4: blr             lr
    // 0x11cf4c8: r0 = ReturnAsyncNotFuture()
    //     0x11cf4c8: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x11cf4cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cf4cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cf4d0: b               #0x11cf420
  }
  _ existsSync(/* No info */) {
    // ** addr: 0x126081c, size: 0x50
    // 0x126081c: EnterFrame
    //     0x126081c: stp             fp, lr, [SP, #-0x10]!
    //     0x1260820: mov             fp, SP
    // 0x1260824: CheckStackOverflow
    //     0x1260824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1260828: cmp             SP, x16
    //     0x126082c: b.ls            #0x1260864
    // 0x1260830: LoadField: r0 = r1->field_f
    //     0x1260830: ldur            w0, [x1, #0xf]
    // 0x1260834: DecompressPointer r0
    //     0x1260834: add             x0, x0, HEAP, lsl #32
    // 0x1260838: r1 = LoadClassIdInstr(r0)
    //     0x1260838: ldur            x1, [x0, #-1]
    //     0x126083c: ubfx            x1, x1, #0xc, #0x14
    // 0x1260840: mov             x16, x0
    // 0x1260844: mov             x0, x1
    // 0x1260848: mov             x1, x16
    // 0x126084c: r0 = GDT[cid_x0 + 0x8ea]()
    //     0x126084c: add             lr, x0, #0x8ea
    //     0x1260850: ldr             lr, [x21, lr, lsl #3]
    //     0x1260854: blr             lr
    // 0x1260858: LeaveFrame
    //     0x1260858: mov             SP, fp
    //     0x126085c: ldp             fp, lr, [SP], #0x10
    // 0x1260860: ret
    //     0x1260860: ret             
    // 0x1260864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1260864: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1260868: b               #0x1260830
  }
  get _ path(/* No info */) {
    // ** addr: 0x12f11f8, size: 0x50
    // 0x12f11f8: EnterFrame
    //     0x12f11f8: stp             fp, lr, [SP, #-0x10]!
    //     0x12f11fc: mov             fp, SP
    // 0x12f1200: CheckStackOverflow
    //     0x12f1200: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12f1204: cmp             SP, x16
    //     0x12f1208: b.ls            #0x12f1240
    // 0x12f120c: LoadField: r0 = r1->field_f
    //     0x12f120c: ldur            w0, [x1, #0xf]
    // 0x12f1210: DecompressPointer r0
    //     0x12f1210: add             x0, x0, HEAP, lsl #32
    // 0x12f1214: r1 = LoadClassIdInstr(r0)
    //     0x12f1214: ldur            x1, [x0, #-1]
    //     0x12f1218: ubfx            x1, x1, #0xc, #0x14
    // 0x12f121c: mov             x16, x0
    // 0x12f1220: mov             x0, x1
    // 0x12f1224: mov             x1, x16
    // 0x12f1228: r0 = GDT[cid_x0 + -0xfc5]()
    //     0x12f1228: sub             lr, x0, #0xfc5
    //     0x12f122c: ldr             lr, [x21, lr, lsl #3]
    //     0x12f1230: blr             lr
    // 0x12f1234: LeaveFrame
    //     0x12f1234: mov             SP, fp
    //     0x12f1238: ldp             fp, lr, [SP], #0x10
    // 0x12f123c: ret
    //     0x12f123c: ret             
    // 0x12f1240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12f1240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12f1244: b               #0x12f120c
  }
}
