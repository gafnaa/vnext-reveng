// lib: , url: package:device_info_plus/device_info_plus.dart

// class id: 1048686, size: 0x8
class :: {
}

// class id: 3421, size: 0xc, field offset: 0x8
class DeviceInfoPlugin extends Object {

  get _ androidInfo(/* No info */) async {
    // ** addr: 0x9e8854, size: 0xbc
    // 0x9e8854: EnterFrame
    //     0x9e8854: stp             fp, lr, [SP, #-0x10]!
    //     0x9e8858: mov             fp, SP
    // 0x9e885c: AllocStack(0x18)
    //     0x9e885c: sub             SP, SP, #0x18
    // 0x9e8860: SetupParameters(DeviceInfoPlugin this /* r1 => r1, fp-0x10 */)
    //     0x9e8860: stur            NULL, [fp, #-8]
    //     0x9e8864: stur            x1, [fp, #-0x10]
    // 0x9e8868: CheckStackOverflow
    //     0x9e8868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e886c: cmp             SP, x16
    //     0x9e8870: b.ls            #0x9e8908
    // 0x9e8874: InitAsync() -> Future<AndroidDeviceInfo>
    //     0x9e8874: add             x0, PP, #0x7a, lsl #12  ; [pp+0x7a698] TypeArguments: <AndroidDeviceInfo>
    //     0x9e8878: ldr             x0, [x0, #0x698]
    //     0x9e887c: bl              #0x7f5e44  ; InitAsyncStub
    // 0x9e8880: ldur            x0, [fp, #-0x10]
    // 0x9e8884: LoadField: r1 = r0->field_7
    //     0x9e8884: ldur            w1, [x0, #7]
    // 0x9e8888: DecompressPointer r1
    //     0x9e8888: add             x1, x1, HEAP, lsl #32
    // 0x9e888c: cmp             w1, NULL
    // 0x9e8890: b.ne            #0x9e8900
    // 0x9e8894: r0 = LoadStaticField(0xf84)
    //     0x9e8894: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x9e8898: ldr             x0, [x0, #0x1f08]
    // 0x9e889c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x9e88a0: cmp             w0, w16
    // 0x9e88a4: b.ne            #0x9e88b4
    // 0x9e88a8: r2 = _instance
    //     0x9e88a8: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a6a0] Field <DeviceInfoPlatform._instance@1255502559>: static late (offset: 0xf84)
    //     0x9e88ac: ldr             x2, [x2, #0x6a0]
    // 0x9e88b0: r0 = InitLateStaticField()
    //     0x9e88b0: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0x9e88b4: mov             x1, x0
    // 0x9e88b8: r0 = deviceInfo()
    //     0x9e88b8: bl              #0x9ebeb0  ; [package:device_info_plus_platform_interface/method_channel/method_channel_device_info.dart] MethodChannelDeviceInfo::deviceInfo
    // 0x9e88bc: mov             x1, x0
    // 0x9e88c0: stur            x1, [fp, #-0x18]
    // 0x9e88c4: r0 = Await()
    //     0x9e88c4: bl              #0x7f5c00  ; AwaitStub
    // 0x9e88c8: LoadField: r1 = r0->field_7
    //     0x9e88c8: ldur            w1, [x0, #7]
    // 0x9e88cc: DecompressPointer r1
    //     0x9e88cc: add             x1, x1, HEAP, lsl #32
    // 0x9e88d0: r0 = fromMap()
    //     0x9e88d0: bl              #0x9e8910  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::fromMap
    // 0x9e88d4: mov             x1, x0
    // 0x9e88d8: ldur            x2, [fp, #-0x10]
    // 0x9e88dc: StoreField: r2->field_7 = r0
    //     0x9e88dc: stur            w0, [x2, #7]
    //     0x9e88e0: ldurb           w16, [x2, #-1]
    //     0x9e88e4: ldurb           w17, [x0, #-1]
    //     0x9e88e8: and             x16, x17, x16, lsr #2
    //     0x9e88ec: tst             x16, HEAP, lsr #32
    //     0x9e88f0: b.eq            #0x9e88f8
    //     0x9e88f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x9e88f8: mov             x0, x1
    // 0x9e88fc: b               #0x9e8904
    // 0x9e8900: mov             x0, x1
    // 0x9e8904: r0 = ReturnAsyncNotFuture()
    //     0x9e8904: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x9e8908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e8908: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e890c: b               #0x9e8874
  }
}
