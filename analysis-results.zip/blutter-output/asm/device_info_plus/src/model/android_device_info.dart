// lib: , url: package:device_info_plus/src/model/android_device_info.dart

// class id: 1048687, size: 0x8
class :: {
}

// class id: 3418, size: 0x14, field offset: 0x8
//   const constructor, 
class AndroidBuildVersion extends Object {

  static _ _fromMap(/* No info */) {
    // ** addr: 0x9ebbe8, size: 0x2bc
    // 0x9ebbe8: EnterFrame
    //     0x9ebbe8: stp             fp, lr, [SP, #-0x10]!
    //     0x9ebbec: mov             fp, SP
    // 0x9ebbf0: AllocStack(0x18)
    //     0x9ebbf0: sub             SP, SP, #0x18
    // 0x9ebbf4: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x9ebbf4: mov             x3, x1
    //     0x9ebbf8: stur            x1, [fp, #-8]
    // 0x9ebbfc: CheckStackOverflow
    //     0x9ebbfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ebc00: cmp             SP, x16
    //     0x9ebc04: b.ls            #0x9ebe9c
    // 0x9ebc08: r0 = LoadClassIdInstr(r3)
    //     0x9ebc08: ldur            x0, [x3, #-1]
    //     0x9ebc0c: ubfx            x0, x0, #0xc, #0x14
    // 0x9ebc10: mov             x1, x3
    // 0x9ebc14: r2 = "baseOS"
    //     0x9ebc14: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a8f8] "baseOS"
    //     0x9ebc18: ldr             x2, [x2, #0x8f8]
    // 0x9ebc1c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9ebc1c: sub             lr, x0, #0xd48
    //     0x9ebc20: ldr             lr, [x21, lr, lsl #3]
    //     0x9ebc24: blr             lr
    // 0x9ebc28: r2 = Null
    //     0x9ebc28: mov             x2, NULL
    // 0x9ebc2c: r1 = Null
    //     0x9ebc2c: mov             x1, NULL
    // 0x9ebc30: r4 = 60
    //     0x9ebc30: mov             x4, #0x3c
    // 0x9ebc34: branchIfSmi(r0, 0x9ebc40)
    //     0x9ebc34: tbz             w0, #0, #0x9ebc40
    // 0x9ebc38: r4 = LoadClassIdInstr(r0)
    //     0x9ebc38: ldur            x4, [x0, #-1]
    //     0x9ebc3c: ubfx            x4, x4, #0xc, #0x14
    // 0x9ebc40: sub             x4, x4, #0x5e
    // 0x9ebc44: cmp             x4, #1
    // 0x9ebc48: b.ls            #0x9ebc5c
    // 0x9ebc4c: r8 = String?
    //     0x9ebc4c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9ebc50: r3 = Null
    //     0x9ebc50: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a900] Null
    //     0x9ebc54: ldr             x3, [x3, #0x900]
    // 0x9ebc58: r0 = String?()
    //     0x9ebc58: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9ebc5c: ldur            x3, [fp, #-8]
    // 0x9ebc60: r0 = LoadClassIdInstr(r3)
    //     0x9ebc60: ldur            x0, [x3, #-1]
    //     0x9ebc64: ubfx            x0, x0, #0xc, #0x14
    // 0x9ebc68: mov             x1, x3
    // 0x9ebc6c: r2 = "codename"
    //     0x9ebc6c: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a910] "codename"
    //     0x9ebc70: ldr             x2, [x2, #0x910]
    // 0x9ebc74: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9ebc74: sub             lr, x0, #0xd48
    //     0x9ebc78: ldr             lr, [x21, lr, lsl #3]
    //     0x9ebc7c: blr             lr
    // 0x9ebc80: r2 = Null
    //     0x9ebc80: mov             x2, NULL
    // 0x9ebc84: r1 = Null
    //     0x9ebc84: mov             x1, NULL
    // 0x9ebc88: r4 = 60
    //     0x9ebc88: mov             x4, #0x3c
    // 0x9ebc8c: branchIfSmi(r0, 0x9ebc98)
    //     0x9ebc8c: tbz             w0, #0, #0x9ebc98
    // 0x9ebc90: r4 = LoadClassIdInstr(r0)
    //     0x9ebc90: ldur            x4, [x0, #-1]
    //     0x9ebc94: ubfx            x4, x4, #0xc, #0x14
    // 0x9ebc98: sub             x4, x4, #0x5e
    // 0x9ebc9c: cmp             x4, #1
    // 0x9ebca0: b.ls            #0x9ebcb4
    // 0x9ebca4: r8 = String
    //     0x9ebca4: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9ebca8: r3 = Null
    //     0x9ebca8: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a918] Null
    //     0x9ebcac: ldr             x3, [x3, #0x918]
    // 0x9ebcb0: r0 = String()
    //     0x9ebcb0: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9ebcb4: ldur            x3, [fp, #-8]
    // 0x9ebcb8: r0 = LoadClassIdInstr(r3)
    //     0x9ebcb8: ldur            x0, [x3, #-1]
    //     0x9ebcbc: ubfx            x0, x0, #0xc, #0x14
    // 0x9ebcc0: mov             x1, x3
    // 0x9ebcc4: r2 = "incremental"
    //     0x9ebcc4: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a928] "incremental"
    //     0x9ebcc8: ldr             x2, [x2, #0x928]
    // 0x9ebccc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9ebccc: sub             lr, x0, #0xd48
    //     0x9ebcd0: ldr             lr, [x21, lr, lsl #3]
    //     0x9ebcd4: blr             lr
    // 0x9ebcd8: r2 = Null
    //     0x9ebcd8: mov             x2, NULL
    // 0x9ebcdc: r1 = Null
    //     0x9ebcdc: mov             x1, NULL
    // 0x9ebce0: r4 = 60
    //     0x9ebce0: mov             x4, #0x3c
    // 0x9ebce4: branchIfSmi(r0, 0x9ebcf0)
    //     0x9ebce4: tbz             w0, #0, #0x9ebcf0
    // 0x9ebce8: r4 = LoadClassIdInstr(r0)
    //     0x9ebce8: ldur            x4, [x0, #-1]
    //     0x9ebcec: ubfx            x4, x4, #0xc, #0x14
    // 0x9ebcf0: sub             x4, x4, #0x5e
    // 0x9ebcf4: cmp             x4, #1
    // 0x9ebcf8: b.ls            #0x9ebd0c
    // 0x9ebcfc: r8 = String
    //     0x9ebcfc: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9ebd00: r3 = Null
    //     0x9ebd00: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a930] Null
    //     0x9ebd04: ldr             x3, [x3, #0x930]
    // 0x9ebd08: r0 = String()
    //     0x9ebd08: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9ebd0c: ldur            x3, [fp, #-8]
    // 0x9ebd10: r0 = LoadClassIdInstr(r3)
    //     0x9ebd10: ldur            x0, [x3, #-1]
    //     0x9ebd14: ubfx            x0, x0, #0xc, #0x14
    // 0x9ebd18: mov             x1, x3
    // 0x9ebd1c: r2 = "previewSdkInt"
    //     0x9ebd1c: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a940] "previewSdkInt"
    //     0x9ebd20: ldr             x2, [x2, #0x940]
    // 0x9ebd24: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9ebd24: sub             lr, x0, #0xd48
    //     0x9ebd28: ldr             lr, [x21, lr, lsl #3]
    //     0x9ebd2c: blr             lr
    // 0x9ebd30: r2 = Null
    //     0x9ebd30: mov             x2, NULL
    // 0x9ebd34: r1 = Null
    //     0x9ebd34: mov             x1, NULL
    // 0x9ebd38: branchIfSmi(r0, 0x9ebd60)
    //     0x9ebd38: tbz             w0, #0, #0x9ebd60
    // 0x9ebd3c: r4 = LoadClassIdInstr(r0)
    //     0x9ebd3c: ldur            x4, [x0, #-1]
    //     0x9ebd40: ubfx            x4, x4, #0xc, #0x14
    // 0x9ebd44: sub             x4, x4, #0x3c
    // 0x9ebd48: cmp             x4, #1
    // 0x9ebd4c: b.ls            #0x9ebd60
    // 0x9ebd50: r8 = int?
    //     0x9ebd50: ldr             x8, [PP, #0x3d30]  ; [pp+0x3d30] Type: int?
    // 0x9ebd54: r3 = Null
    //     0x9ebd54: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a948] Null
    //     0x9ebd58: ldr             x3, [x3, #0x948]
    // 0x9ebd5c: r0 = int?()
    //     0x9ebd5c: bl              #0x13ee944  ; IsType_int?_Stub
    // 0x9ebd60: ldur            x3, [fp, #-8]
    // 0x9ebd64: r0 = LoadClassIdInstr(r3)
    //     0x9ebd64: ldur            x0, [x3, #-1]
    //     0x9ebd68: ubfx            x0, x0, #0xc, #0x14
    // 0x9ebd6c: mov             x1, x3
    // 0x9ebd70: r2 = "release"
    //     0x9ebd70: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a958] "release"
    //     0x9ebd74: ldr             x2, [x2, #0x958]
    // 0x9ebd78: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9ebd78: sub             lr, x0, #0xd48
    //     0x9ebd7c: ldr             lr, [x21, lr, lsl #3]
    //     0x9ebd80: blr             lr
    // 0x9ebd84: mov             x3, x0
    // 0x9ebd88: r2 = Null
    //     0x9ebd88: mov             x2, NULL
    // 0x9ebd8c: r1 = Null
    //     0x9ebd8c: mov             x1, NULL
    // 0x9ebd90: stur            x3, [fp, #-0x10]
    // 0x9ebd94: r4 = 60
    //     0x9ebd94: mov             x4, #0x3c
    // 0x9ebd98: branchIfSmi(r0, 0x9ebda4)
    //     0x9ebd98: tbz             w0, #0, #0x9ebda4
    // 0x9ebd9c: r4 = LoadClassIdInstr(r0)
    //     0x9ebd9c: ldur            x4, [x0, #-1]
    //     0x9ebda0: ubfx            x4, x4, #0xc, #0x14
    // 0x9ebda4: sub             x4, x4, #0x5e
    // 0x9ebda8: cmp             x4, #1
    // 0x9ebdac: b.ls            #0x9ebdc0
    // 0x9ebdb0: r8 = String
    //     0x9ebdb0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9ebdb4: r3 = Null
    //     0x9ebdb4: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a960] Null
    //     0x9ebdb8: ldr             x3, [x3, #0x960]
    // 0x9ebdbc: r0 = String()
    //     0x9ebdbc: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9ebdc0: ldur            x3, [fp, #-8]
    // 0x9ebdc4: r0 = LoadClassIdInstr(r3)
    //     0x9ebdc4: ldur            x0, [x3, #-1]
    //     0x9ebdc8: ubfx            x0, x0, #0xc, #0x14
    // 0x9ebdcc: mov             x1, x3
    // 0x9ebdd0: r2 = "sdkInt"
    //     0x9ebdd0: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a970] "sdkInt"
    //     0x9ebdd4: ldr             x2, [x2, #0x970]
    // 0x9ebdd8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9ebdd8: sub             lr, x0, #0xd48
    //     0x9ebddc: ldr             lr, [x21, lr, lsl #3]
    //     0x9ebde0: blr             lr
    // 0x9ebde4: mov             x3, x0
    // 0x9ebde8: r2 = Null
    //     0x9ebde8: mov             x2, NULL
    // 0x9ebdec: r1 = Null
    //     0x9ebdec: mov             x1, NULL
    // 0x9ebdf0: stur            x3, [fp, #-0x18]
    // 0x9ebdf4: branchIfSmi(r0, 0x9ebe1c)
    //     0x9ebdf4: tbz             w0, #0, #0x9ebe1c
    // 0x9ebdf8: r4 = LoadClassIdInstr(r0)
    //     0x9ebdf8: ldur            x4, [x0, #-1]
    //     0x9ebdfc: ubfx            x4, x4, #0xc, #0x14
    // 0x9ebe00: sub             x4, x4, #0x3c
    // 0x9ebe04: cmp             x4, #1
    // 0x9ebe08: b.ls            #0x9ebe1c
    // 0x9ebe0c: r8 = int
    //     0x9ebe0c: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x9ebe10: r3 = Null
    //     0x9ebe10: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a978] Null
    //     0x9ebe14: ldr             x3, [x3, #0x978]
    // 0x9ebe18: r0 = int()
    //     0x9ebe18: bl              #0x13ee980  ; IsType_int_Stub
    // 0x9ebe1c: ldur            x1, [fp, #-8]
    // 0x9ebe20: r0 = LoadClassIdInstr(r1)
    //     0x9ebe20: ldur            x0, [x1, #-1]
    //     0x9ebe24: ubfx            x0, x0, #0xc, #0x14
    // 0x9ebe28: r2 = "securityPatch"
    //     0x9ebe28: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a988] "securityPatch"
    //     0x9ebe2c: ldr             x2, [x2, #0x988]
    // 0x9ebe30: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9ebe30: sub             lr, x0, #0xd48
    //     0x9ebe34: ldr             lr, [x21, lr, lsl #3]
    //     0x9ebe38: blr             lr
    // 0x9ebe3c: r2 = Null
    //     0x9ebe3c: mov             x2, NULL
    // 0x9ebe40: r1 = Null
    //     0x9ebe40: mov             x1, NULL
    // 0x9ebe44: r4 = 60
    //     0x9ebe44: mov             x4, #0x3c
    // 0x9ebe48: branchIfSmi(r0, 0x9ebe54)
    //     0x9ebe48: tbz             w0, #0, #0x9ebe54
    // 0x9ebe4c: r4 = LoadClassIdInstr(r0)
    //     0x9ebe4c: ldur            x4, [x0, #-1]
    //     0x9ebe50: ubfx            x4, x4, #0xc, #0x14
    // 0x9ebe54: sub             x4, x4, #0x5e
    // 0x9ebe58: cmp             x4, #1
    // 0x9ebe5c: b.ls            #0x9ebe70
    // 0x9ebe60: r8 = String?
    //     0x9ebe60: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x9ebe64: r3 = Null
    //     0x9ebe64: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a990] Null
    //     0x9ebe68: ldr             x3, [x3, #0x990]
    // 0x9ebe6c: r0 = String?()
    //     0x9ebe6c: bl              #0x7db310  ; IsType_String?_Stub
    // 0x9ebe70: r0 = AndroidBuildVersion()
    //     0x9ebe70: bl              #0x9ebea4  ; AllocateAndroidBuildVersionStub -> AndroidBuildVersion (size=0x14)
    // 0x9ebe74: ldur            x1, [fp, #-0x10]
    // 0x9ebe78: StoreField: r0->field_7 = r1
    //     0x9ebe78: stur            w1, [x0, #7]
    // 0x9ebe7c: ldur            x1, [fp, #-0x18]
    // 0x9ebe80: r2 = LoadInt32Instr(r1)
    //     0x9ebe80: sbfx            x2, x1, #1, #0x1f
    //     0x9ebe84: tbz             w1, #0, #0x9ebe8c
    //     0x9ebe88: ldur            x2, [x1, #7]
    // 0x9ebe8c: StoreField: r0->field_b = r2
    //     0x9ebe8c: stur            x2, [x0, #0xb]
    // 0x9ebe90: LeaveFrame
    //     0x9ebe90: mov             SP, fp
    //     0x9ebe94: ldp             fp, lr, [SP], #0x10
    // 0x9ebe98: ret
    //     0x9ebe98: ret             
    // 0x9ebe9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ebe9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ebea0: b               #0x9ebc08
  }
}

// class id: 3420, size: 0x50, field offset: 0xc
class AndroidDeviceInfo extends BaseDeviceInfo {

  static _ fromMap(/* No info */) {
    // ** addr: 0x9e8910, size: 0xb44
    // 0x9e8910: EnterFrame
    //     0x9e8910: stp             fp, lr, [SP, #-0x10]!
    //     0x9e8914: mov             fp, SP
    // 0x9e8918: AllocStack(0x120)
    //     0x9e8918: sub             SP, SP, #0x120
    // 0x9e891c: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0x9e891c: mov             x3, x1
    //     0x9e8920: stur            x1, [fp, #-8]
    // 0x9e8924: CheckStackOverflow
    //     0x9e8924: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e8928: cmp             SP, x16
    //     0x9e892c: b.ls            #0x9e944c
    // 0x9e8930: r0 = LoadClassIdInstr(r3)
    //     0x9e8930: ldur            x0, [x3, #-1]
    //     0x9e8934: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8938: mov             x1, x3
    // 0x9e893c: r2 = "version"
    //     0x9e893c: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a6a8] "version"
    //     0x9e8940: ldr             x2, [x2, #0x6a8]
    // 0x9e8944: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8944: sub             lr, x0, #0xd48
    //     0x9e8948: ldr             lr, [x21, lr, lsl #3]
    //     0x9e894c: blr             lr
    // 0x9e8950: cmp             w0, NULL
    // 0x9e8954: b.ne            #0x9e8960
    // 0x9e8958: r0 = Null
    //     0x9e8958: mov             x0, NULL
    // 0x9e895c: b               #0x9e8980
    // 0x9e8960: r16 = <String, dynamic>
    //     0x9e8960: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x9e8964: stp             x0, x16, [SP]
    // 0x9e8968: r4 = 0
    //     0x9e8968: mov             x4, #0
    // 0x9e896c: ldr             x0, [SP]
    // 0x9e8970: r16 = 139822029843448
    //     0x9e8970: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7a6b0] IMM: 0x7f2ada6babf8
    //     0x9e8974: add             x16, x16, #0x6b0
    // 0x9e8978: ldp             lr, x5, [x16]
    // 0x9e897c: blr             lr
    // 0x9e8980: cmp             w0, NULL
    // 0x9e8984: b.ne            #0x9e89a0
    // 0x9e8988: r16 = <String, dynamic>
    //     0x9e8988: ldr             x16, [PP, #0x21e0]  ; [pp+0x21e0] TypeArguments: <String, dynamic>
    // 0x9e898c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x9e8990: stp             lr, x16, [SP]
    // 0x9e8994: r0 = Map._fromLiteral()
    //     0x9e8994: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x9e8998: mov             x4, x0
    // 0x9e899c: b               #0x9e89a4
    // 0x9e89a0: mov             x4, x0
    // 0x9e89a4: ldur            x3, [fp, #-8]
    // 0x9e89a8: mov             x0, x4
    // 0x9e89ac: stur            x4, [fp, #-0x10]
    // 0x9e89b0: r2 = Null
    //     0x9e89b0: mov             x2, NULL
    // 0x9e89b4: r1 = Null
    //     0x9e89b4: mov             x1, NULL
    // 0x9e89b8: r8 = Map<String, dynamic>
    //     0x9e89b8: ldr             x8, [PP, #0x3298]  ; [pp+0x3298] Type: Map<String, dynamic>
    // 0x9e89bc: r3 = Null
    //     0x9e89bc: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a6c0] Null
    //     0x9e89c0: ldr             x3, [x3, #0x6c0]
    // 0x9e89c4: r0 = Map<String, dynamic>()
    //     0x9e89c4: bl              #0x84f9a4  ; IsType_Map<String, dynamic>_Stub
    // 0x9e89c8: ldur            x1, [fp, #-0x10]
    // 0x9e89cc: r0 = _fromMap()
    //     0x9e89cc: bl              #0x9ebbe8  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidBuildVersion::_fromMap
    // 0x9e89d0: mov             x4, x0
    // 0x9e89d4: ldur            x3, [fp, #-8]
    // 0x9e89d8: stur            x4, [fp, #-0x10]
    // 0x9e89dc: r0 = LoadClassIdInstr(r3)
    //     0x9e89dc: ldur            x0, [x3, #-1]
    //     0x9e89e0: ubfx            x0, x0, #0xc, #0x14
    // 0x9e89e4: mov             x1, x3
    // 0x9e89e8: r2 = "board"
    //     0x9e89e8: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a6d0] "board"
    //     0x9e89ec: ldr             x2, [x2, #0x6d0]
    // 0x9e89f0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e89f0: sub             lr, x0, #0xd48
    //     0x9e89f4: ldr             lr, [x21, lr, lsl #3]
    //     0x9e89f8: blr             lr
    // 0x9e89fc: r2 = Null
    //     0x9e89fc: mov             x2, NULL
    // 0x9e8a00: r1 = Null
    //     0x9e8a00: mov             x1, NULL
    // 0x9e8a04: r4 = 60
    //     0x9e8a04: mov             x4, #0x3c
    // 0x9e8a08: branchIfSmi(r0, 0x9e8a14)
    //     0x9e8a08: tbz             w0, #0, #0x9e8a14
    // 0x9e8a0c: r4 = LoadClassIdInstr(r0)
    //     0x9e8a0c: ldur            x4, [x0, #-1]
    //     0x9e8a10: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8a14: sub             x4, x4, #0x5e
    // 0x9e8a18: cmp             x4, #1
    // 0x9e8a1c: b.ls            #0x9e8a30
    // 0x9e8a20: r8 = String
    //     0x9e8a20: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8a24: r3 = Null
    //     0x9e8a24: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a6d8] Null
    //     0x9e8a28: ldr             x3, [x3, #0x6d8]
    // 0x9e8a2c: r0 = String()
    //     0x9e8a2c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8a30: ldur            x3, [fp, #-8]
    // 0x9e8a34: r0 = LoadClassIdInstr(r3)
    //     0x9e8a34: ldur            x0, [x3, #-1]
    //     0x9e8a38: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8a3c: mov             x1, x3
    // 0x9e8a40: r2 = "bootloader"
    //     0x9e8a40: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a6e8] "bootloader"
    //     0x9e8a44: ldr             x2, [x2, #0x6e8]
    // 0x9e8a48: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8a48: sub             lr, x0, #0xd48
    //     0x9e8a4c: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8a50: blr             lr
    // 0x9e8a54: mov             x3, x0
    // 0x9e8a58: r2 = Null
    //     0x9e8a58: mov             x2, NULL
    // 0x9e8a5c: r1 = Null
    //     0x9e8a5c: mov             x1, NULL
    // 0x9e8a60: stur            x3, [fp, #-0x18]
    // 0x9e8a64: r4 = 60
    //     0x9e8a64: mov             x4, #0x3c
    // 0x9e8a68: branchIfSmi(r0, 0x9e8a74)
    //     0x9e8a68: tbz             w0, #0, #0x9e8a74
    // 0x9e8a6c: r4 = LoadClassIdInstr(r0)
    //     0x9e8a6c: ldur            x4, [x0, #-1]
    //     0x9e8a70: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8a74: sub             x4, x4, #0x5e
    // 0x9e8a78: cmp             x4, #1
    // 0x9e8a7c: b.ls            #0x9e8a90
    // 0x9e8a80: r8 = String
    //     0x9e8a80: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8a84: r3 = Null
    //     0x9e8a84: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a6f0] Null
    //     0x9e8a88: ldr             x3, [x3, #0x6f0]
    // 0x9e8a8c: r0 = String()
    //     0x9e8a8c: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8a90: ldur            x3, [fp, #-8]
    // 0x9e8a94: r0 = LoadClassIdInstr(r3)
    //     0x9e8a94: ldur            x0, [x3, #-1]
    //     0x9e8a98: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8a9c: mov             x1, x3
    // 0x9e8aa0: r2 = "brand"
    //     0x9e8aa0: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a700] "brand"
    //     0x9e8aa4: ldr             x2, [x2, #0x700]
    // 0x9e8aa8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8aa8: sub             lr, x0, #0xd48
    //     0x9e8aac: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8ab0: blr             lr
    // 0x9e8ab4: mov             x3, x0
    // 0x9e8ab8: r2 = Null
    //     0x9e8ab8: mov             x2, NULL
    // 0x9e8abc: r1 = Null
    //     0x9e8abc: mov             x1, NULL
    // 0x9e8ac0: stur            x3, [fp, #-0x20]
    // 0x9e8ac4: r4 = 60
    //     0x9e8ac4: mov             x4, #0x3c
    // 0x9e8ac8: branchIfSmi(r0, 0x9e8ad4)
    //     0x9e8ac8: tbz             w0, #0, #0x9e8ad4
    // 0x9e8acc: r4 = LoadClassIdInstr(r0)
    //     0x9e8acc: ldur            x4, [x0, #-1]
    //     0x9e8ad0: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8ad4: sub             x4, x4, #0x5e
    // 0x9e8ad8: cmp             x4, #1
    // 0x9e8adc: b.ls            #0x9e8af0
    // 0x9e8ae0: r8 = String
    //     0x9e8ae0: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8ae4: r3 = Null
    //     0x9e8ae4: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a708] Null
    //     0x9e8ae8: ldr             x3, [x3, #0x708]
    // 0x9e8aec: r0 = String()
    //     0x9e8aec: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8af0: ldur            x3, [fp, #-8]
    // 0x9e8af4: r0 = LoadClassIdInstr(r3)
    //     0x9e8af4: ldur            x0, [x3, #-1]
    //     0x9e8af8: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8afc: mov             x1, x3
    // 0x9e8b00: r2 = "device"
    //     0x9e8b00: ldr             x2, [PP, #0x21b8]  ; [pp+0x21b8] "device"
    // 0x9e8b04: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8b04: sub             lr, x0, #0xd48
    //     0x9e8b08: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8b0c: blr             lr
    // 0x9e8b10: mov             x3, x0
    // 0x9e8b14: r2 = Null
    //     0x9e8b14: mov             x2, NULL
    // 0x9e8b18: r1 = Null
    //     0x9e8b18: mov             x1, NULL
    // 0x9e8b1c: stur            x3, [fp, #-0x28]
    // 0x9e8b20: r4 = 60
    //     0x9e8b20: mov             x4, #0x3c
    // 0x9e8b24: branchIfSmi(r0, 0x9e8b30)
    //     0x9e8b24: tbz             w0, #0, #0x9e8b30
    // 0x9e8b28: r4 = LoadClassIdInstr(r0)
    //     0x9e8b28: ldur            x4, [x0, #-1]
    //     0x9e8b2c: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8b30: sub             x4, x4, #0x5e
    // 0x9e8b34: cmp             x4, #1
    // 0x9e8b38: b.ls            #0x9e8b4c
    // 0x9e8b3c: r8 = String
    //     0x9e8b3c: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8b40: r3 = Null
    //     0x9e8b40: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a718] Null
    //     0x9e8b44: ldr             x3, [x3, #0x718]
    // 0x9e8b48: r0 = String()
    //     0x9e8b48: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8b4c: ldur            x3, [fp, #-8]
    // 0x9e8b50: r0 = LoadClassIdInstr(r3)
    //     0x9e8b50: ldur            x0, [x3, #-1]
    //     0x9e8b54: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8b58: mov             x1, x3
    // 0x9e8b5c: r2 = "display"
    //     0x9e8b5c: add             x2, PP, #0x18, lsl #12  ; [pp+0x18178] "display"
    //     0x9e8b60: ldr             x2, [x2, #0x178]
    // 0x9e8b64: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8b64: sub             lr, x0, #0xd48
    //     0x9e8b68: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8b6c: blr             lr
    // 0x9e8b70: mov             x3, x0
    // 0x9e8b74: r2 = Null
    //     0x9e8b74: mov             x2, NULL
    // 0x9e8b78: r1 = Null
    //     0x9e8b78: mov             x1, NULL
    // 0x9e8b7c: stur            x3, [fp, #-0x30]
    // 0x9e8b80: r4 = 60
    //     0x9e8b80: mov             x4, #0x3c
    // 0x9e8b84: branchIfSmi(r0, 0x9e8b90)
    //     0x9e8b84: tbz             w0, #0, #0x9e8b90
    // 0x9e8b88: r4 = LoadClassIdInstr(r0)
    //     0x9e8b88: ldur            x4, [x0, #-1]
    //     0x9e8b8c: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8b90: sub             x4, x4, #0x5e
    // 0x9e8b94: cmp             x4, #1
    // 0x9e8b98: b.ls            #0x9e8bac
    // 0x9e8b9c: r8 = String
    //     0x9e8b9c: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8ba0: r3 = Null
    //     0x9e8ba0: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a728] Null
    //     0x9e8ba4: ldr             x3, [x3, #0x728]
    // 0x9e8ba8: r0 = String()
    //     0x9e8ba8: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8bac: ldur            x3, [fp, #-8]
    // 0x9e8bb0: r0 = LoadClassIdInstr(r3)
    //     0x9e8bb0: ldur            x0, [x3, #-1]
    //     0x9e8bb4: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8bb8: mov             x1, x3
    // 0x9e8bbc: r2 = "fingerprint"
    //     0x9e8bbc: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a738] "fingerprint"
    //     0x9e8bc0: ldr             x2, [x2, #0x738]
    // 0x9e8bc4: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8bc4: sub             lr, x0, #0xd48
    //     0x9e8bc8: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8bcc: blr             lr
    // 0x9e8bd0: mov             x3, x0
    // 0x9e8bd4: r2 = Null
    //     0x9e8bd4: mov             x2, NULL
    // 0x9e8bd8: r1 = Null
    //     0x9e8bd8: mov             x1, NULL
    // 0x9e8bdc: stur            x3, [fp, #-0x38]
    // 0x9e8be0: r4 = 60
    //     0x9e8be0: mov             x4, #0x3c
    // 0x9e8be4: branchIfSmi(r0, 0x9e8bf0)
    //     0x9e8be4: tbz             w0, #0, #0x9e8bf0
    // 0x9e8be8: r4 = LoadClassIdInstr(r0)
    //     0x9e8be8: ldur            x4, [x0, #-1]
    //     0x9e8bec: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8bf0: sub             x4, x4, #0x5e
    // 0x9e8bf4: cmp             x4, #1
    // 0x9e8bf8: b.ls            #0x9e8c0c
    // 0x9e8bfc: r8 = String
    //     0x9e8bfc: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8c00: r3 = Null
    //     0x9e8c00: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a740] Null
    //     0x9e8c04: ldr             x3, [x3, #0x740]
    // 0x9e8c08: r0 = String()
    //     0x9e8c08: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8c0c: ldur            x3, [fp, #-8]
    // 0x9e8c10: r0 = LoadClassIdInstr(r3)
    //     0x9e8c10: ldur            x0, [x3, #-1]
    //     0x9e8c14: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8c18: mov             x1, x3
    // 0x9e8c1c: r2 = "hardware"
    //     0x9e8c1c: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a750] "hardware"
    //     0x9e8c20: ldr             x2, [x2, #0x750]
    // 0x9e8c24: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8c24: sub             lr, x0, #0xd48
    //     0x9e8c28: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8c2c: blr             lr
    // 0x9e8c30: mov             x3, x0
    // 0x9e8c34: r2 = Null
    //     0x9e8c34: mov             x2, NULL
    // 0x9e8c38: r1 = Null
    //     0x9e8c38: mov             x1, NULL
    // 0x9e8c3c: stur            x3, [fp, #-0x40]
    // 0x9e8c40: r4 = 60
    //     0x9e8c40: mov             x4, #0x3c
    // 0x9e8c44: branchIfSmi(r0, 0x9e8c50)
    //     0x9e8c44: tbz             w0, #0, #0x9e8c50
    // 0x9e8c48: r4 = LoadClassIdInstr(r0)
    //     0x9e8c48: ldur            x4, [x0, #-1]
    //     0x9e8c4c: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8c50: sub             x4, x4, #0x5e
    // 0x9e8c54: cmp             x4, #1
    // 0x9e8c58: b.ls            #0x9e8c6c
    // 0x9e8c5c: r8 = String
    //     0x9e8c5c: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8c60: r3 = Null
    //     0x9e8c60: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a758] Null
    //     0x9e8c64: ldr             x3, [x3, #0x758]
    // 0x9e8c68: r0 = String()
    //     0x9e8c68: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8c6c: ldur            x3, [fp, #-8]
    // 0x9e8c70: r0 = LoadClassIdInstr(r3)
    //     0x9e8c70: ldur            x0, [x3, #-1]
    //     0x9e8c74: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8c78: mov             x1, x3
    // 0x9e8c7c: r2 = "host"
    //     0x9e8c7c: ldr             x2, [PP, #0x39b8]  ; [pp+0x39b8] "host"
    // 0x9e8c80: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8c80: sub             lr, x0, #0xd48
    //     0x9e8c84: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8c88: blr             lr
    // 0x9e8c8c: mov             x3, x0
    // 0x9e8c90: r2 = Null
    //     0x9e8c90: mov             x2, NULL
    // 0x9e8c94: r1 = Null
    //     0x9e8c94: mov             x1, NULL
    // 0x9e8c98: stur            x3, [fp, #-0x48]
    // 0x9e8c9c: r4 = 60
    //     0x9e8c9c: mov             x4, #0x3c
    // 0x9e8ca0: branchIfSmi(r0, 0x9e8cac)
    //     0x9e8ca0: tbz             w0, #0, #0x9e8cac
    // 0x9e8ca4: r4 = LoadClassIdInstr(r0)
    //     0x9e8ca4: ldur            x4, [x0, #-1]
    //     0x9e8ca8: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8cac: sub             x4, x4, #0x5e
    // 0x9e8cb0: cmp             x4, #1
    // 0x9e8cb4: b.ls            #0x9e8cc8
    // 0x9e8cb8: r8 = String
    //     0x9e8cb8: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8cbc: r3 = Null
    //     0x9e8cbc: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a768] Null
    //     0x9e8cc0: ldr             x3, [x3, #0x768]
    // 0x9e8cc4: r0 = String()
    //     0x9e8cc4: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8cc8: ldur            x3, [fp, #-8]
    // 0x9e8ccc: r0 = LoadClassIdInstr(r3)
    //     0x9e8ccc: ldur            x0, [x3, #-1]
    //     0x9e8cd0: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8cd4: mov             x1, x3
    // 0x9e8cd8: r2 = "id"
    //     0x9e8cd8: ldr             x2, [PP, #0x7f88]  ; [pp+0x7f88] "id"
    // 0x9e8cdc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8cdc: sub             lr, x0, #0xd48
    //     0x9e8ce0: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8ce4: blr             lr
    // 0x9e8ce8: mov             x3, x0
    // 0x9e8cec: r2 = Null
    //     0x9e8cec: mov             x2, NULL
    // 0x9e8cf0: r1 = Null
    //     0x9e8cf0: mov             x1, NULL
    // 0x9e8cf4: stur            x3, [fp, #-0x50]
    // 0x9e8cf8: r4 = 60
    //     0x9e8cf8: mov             x4, #0x3c
    // 0x9e8cfc: branchIfSmi(r0, 0x9e8d08)
    //     0x9e8cfc: tbz             w0, #0, #0x9e8d08
    // 0x9e8d00: r4 = LoadClassIdInstr(r0)
    //     0x9e8d00: ldur            x4, [x0, #-1]
    //     0x9e8d04: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8d08: sub             x4, x4, #0x5e
    // 0x9e8d0c: cmp             x4, #1
    // 0x9e8d10: b.ls            #0x9e8d24
    // 0x9e8d14: r8 = String
    //     0x9e8d14: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8d18: r3 = Null
    //     0x9e8d18: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a778] Null
    //     0x9e8d1c: ldr             x3, [x3, #0x778]
    // 0x9e8d20: r0 = String()
    //     0x9e8d20: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8d24: ldur            x3, [fp, #-8]
    // 0x9e8d28: r0 = LoadClassIdInstr(r3)
    //     0x9e8d28: ldur            x0, [x3, #-1]
    //     0x9e8d2c: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8d30: mov             x1, x3
    // 0x9e8d34: r2 = "manufacturer"
    //     0x9e8d34: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a788] "manufacturer"
    //     0x9e8d38: ldr             x2, [x2, #0x788]
    // 0x9e8d3c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8d3c: sub             lr, x0, #0xd48
    //     0x9e8d40: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8d44: blr             lr
    // 0x9e8d48: mov             x3, x0
    // 0x9e8d4c: r2 = Null
    //     0x9e8d4c: mov             x2, NULL
    // 0x9e8d50: r1 = Null
    //     0x9e8d50: mov             x1, NULL
    // 0x9e8d54: stur            x3, [fp, #-0x58]
    // 0x9e8d58: r4 = 60
    //     0x9e8d58: mov             x4, #0x3c
    // 0x9e8d5c: branchIfSmi(r0, 0x9e8d68)
    //     0x9e8d5c: tbz             w0, #0, #0x9e8d68
    // 0x9e8d60: r4 = LoadClassIdInstr(r0)
    //     0x9e8d60: ldur            x4, [x0, #-1]
    //     0x9e8d64: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8d68: sub             x4, x4, #0x5e
    // 0x9e8d6c: cmp             x4, #1
    // 0x9e8d70: b.ls            #0x9e8d84
    // 0x9e8d74: r8 = String
    //     0x9e8d74: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8d78: r3 = Null
    //     0x9e8d78: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a790] Null
    //     0x9e8d7c: ldr             x3, [x3, #0x790]
    // 0x9e8d80: r0 = String()
    //     0x9e8d80: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8d84: ldur            x3, [fp, #-8]
    // 0x9e8d88: r0 = LoadClassIdInstr(r3)
    //     0x9e8d88: ldur            x0, [x3, #-1]
    //     0x9e8d8c: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8d90: mov             x1, x3
    // 0x9e8d94: r2 = "model"
    //     0x9e8d94: add             x2, PP, #0x16, lsl #12  ; [pp+0x16fd8] "model"
    //     0x9e8d98: ldr             x2, [x2, #0xfd8]
    // 0x9e8d9c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8d9c: sub             lr, x0, #0xd48
    //     0x9e8da0: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8da4: blr             lr
    // 0x9e8da8: mov             x3, x0
    // 0x9e8dac: r2 = Null
    //     0x9e8dac: mov             x2, NULL
    // 0x9e8db0: r1 = Null
    //     0x9e8db0: mov             x1, NULL
    // 0x9e8db4: stur            x3, [fp, #-0x60]
    // 0x9e8db8: r4 = 60
    //     0x9e8db8: mov             x4, #0x3c
    // 0x9e8dbc: branchIfSmi(r0, 0x9e8dc8)
    //     0x9e8dbc: tbz             w0, #0, #0x9e8dc8
    // 0x9e8dc0: r4 = LoadClassIdInstr(r0)
    //     0x9e8dc0: ldur            x4, [x0, #-1]
    //     0x9e8dc4: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8dc8: sub             x4, x4, #0x5e
    // 0x9e8dcc: cmp             x4, #1
    // 0x9e8dd0: b.ls            #0x9e8de4
    // 0x9e8dd4: r8 = String
    //     0x9e8dd4: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8dd8: r3 = Null
    //     0x9e8dd8: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a7a0] Null
    //     0x9e8ddc: ldr             x3, [x3, #0x7a0]
    // 0x9e8de0: r0 = String()
    //     0x9e8de0: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8de4: ldur            x3, [fp, #-8]
    // 0x9e8de8: r0 = LoadClassIdInstr(r3)
    //     0x9e8de8: ldur            x0, [x3, #-1]
    //     0x9e8dec: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8df0: mov             x1, x3
    // 0x9e8df4: r2 = "product"
    //     0x9e8df4: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a7b0] "product"
    //     0x9e8df8: ldr             x2, [x2, #0x7b0]
    // 0x9e8dfc: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8dfc: sub             lr, x0, #0xd48
    //     0x9e8e00: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8e04: blr             lr
    // 0x9e8e08: mov             x3, x0
    // 0x9e8e0c: r2 = Null
    //     0x9e8e0c: mov             x2, NULL
    // 0x9e8e10: r1 = Null
    //     0x9e8e10: mov             x1, NULL
    // 0x9e8e14: stur            x3, [fp, #-0x68]
    // 0x9e8e18: r4 = 60
    //     0x9e8e18: mov             x4, #0x3c
    // 0x9e8e1c: branchIfSmi(r0, 0x9e8e28)
    //     0x9e8e1c: tbz             w0, #0, #0x9e8e28
    // 0x9e8e20: r4 = LoadClassIdInstr(r0)
    //     0x9e8e20: ldur            x4, [x0, #-1]
    //     0x9e8e24: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8e28: sub             x4, x4, #0x5e
    // 0x9e8e2c: cmp             x4, #1
    // 0x9e8e30: b.ls            #0x9e8e44
    // 0x9e8e34: r8 = String
    //     0x9e8e34: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8e38: r3 = Null
    //     0x9e8e38: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a7b8] Null
    //     0x9e8e3c: ldr             x3, [x3, #0x7b8]
    // 0x9e8e40: r0 = String()
    //     0x9e8e40: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8e44: ldur            x3, [fp, #-8]
    // 0x9e8e48: r0 = LoadClassIdInstr(r3)
    //     0x9e8e48: ldur            x0, [x3, #-1]
    //     0x9e8e4c: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8e50: mov             x1, x3
    // 0x9e8e54: r2 = "name"
    //     0x9e8e54: ldr             x2, [PP, #0x6120]  ; [pp+0x6120] "name"
    // 0x9e8e58: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8e58: sub             lr, x0, #0xd48
    //     0x9e8e5c: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8e60: blr             lr
    // 0x9e8e64: cmp             w0, NULL
    // 0x9e8e68: b.ne            #0x9e8e74
    // 0x9e8e6c: r4 = ""
    //     0x9e8e6c: ldr             x4, [PP, #0x900]  ; [pp+0x900] ""
    // 0x9e8e70: b               #0x9e8e78
    // 0x9e8e74: mov             x4, x0
    // 0x9e8e78: ldur            x3, [fp, #-8]
    // 0x9e8e7c: mov             x0, x4
    // 0x9e8e80: stur            x4, [fp, #-0x70]
    // 0x9e8e84: r2 = Null
    //     0x9e8e84: mov             x2, NULL
    // 0x9e8e88: r1 = Null
    //     0x9e8e88: mov             x1, NULL
    // 0x9e8e8c: r4 = 60
    //     0x9e8e8c: mov             x4, #0x3c
    // 0x9e8e90: branchIfSmi(r0, 0x9e8e9c)
    //     0x9e8e90: tbz             w0, #0, #0x9e8e9c
    // 0x9e8e94: r4 = LoadClassIdInstr(r0)
    //     0x9e8e94: ldur            x4, [x0, #-1]
    //     0x9e8e98: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8e9c: sub             x4, x4, #0x5e
    // 0x9e8ea0: cmp             x4, #1
    // 0x9e8ea4: b.ls            #0x9e8eb8
    // 0x9e8ea8: r8 = String
    //     0x9e8ea8: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e8eac: r3 = Null
    //     0x9e8eac: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a7c8] Null
    //     0x9e8eb0: ldr             x3, [x3, #0x7c8]
    // 0x9e8eb4: r0 = String()
    //     0x9e8eb4: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e8eb8: ldur            x3, [fp, #-8]
    // 0x9e8ebc: r0 = LoadClassIdInstr(r3)
    //     0x9e8ebc: ldur            x0, [x3, #-1]
    //     0x9e8ec0: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8ec4: mov             x1, x3
    // 0x9e8ec8: r2 = "supported32BitAbis"
    //     0x9e8ec8: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a7d8] "supported32BitAbis"
    //     0x9e8ecc: ldr             x2, [x2, #0x7d8]
    // 0x9e8ed0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8ed0: sub             lr, x0, #0xd48
    //     0x9e8ed4: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8ed8: blr             lr
    // 0x9e8edc: cmp             w0, NULL
    // 0x9e8ee0: b.ne            #0x9e8ef8
    // 0x9e8ee4: r1 = <String>
    //     0x9e8ee4: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e8ee8: r2 = 0
    //     0x9e8ee8: mov             x2, #0
    // 0x9e8eec: r0 = _GrowableList()
    //     0x9e8eec: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e8ef0: mov             x4, x0
    // 0x9e8ef4: b               #0x9e8efc
    // 0x9e8ef8: mov             x4, x0
    // 0x9e8efc: ldur            x3, [fp, #-8]
    // 0x9e8f00: mov             x0, x4
    // 0x9e8f04: stur            x4, [fp, #-0x78]
    // 0x9e8f08: r2 = Null
    //     0x9e8f08: mov             x2, NULL
    // 0x9e8f0c: r1 = Null
    //     0x9e8f0c: mov             x1, NULL
    // 0x9e8f10: r4 = 60
    //     0x9e8f10: mov             x4, #0x3c
    // 0x9e8f14: branchIfSmi(r0, 0x9e8f20)
    //     0x9e8f14: tbz             w0, #0, #0x9e8f20
    // 0x9e8f18: r4 = LoadClassIdInstr(r0)
    //     0x9e8f18: ldur            x4, [x0, #-1]
    //     0x9e8f1c: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8f20: sub             x4, x4, #0x5a
    // 0x9e8f24: cmp             x4, #2
    // 0x9e8f28: b.ls            #0x9e8f3c
    // 0x9e8f2c: r8 = List
    //     0x9e8f2c: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x9e8f30: r3 = Null
    //     0x9e8f30: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a7e0] Null
    //     0x9e8f34: ldr             x3, [x3, #0x7e0]
    // 0x9e8f38: r0 = List()
    //     0x9e8f38: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x9e8f3c: ldur            x1, [fp, #-0x78]
    // 0x9e8f40: r0 = _fromList()
    //     0x9e8f40: bl              #0x9e9778  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0x9e8f44: mov             x4, x0
    // 0x9e8f48: ldur            x3, [fp, #-8]
    // 0x9e8f4c: stur            x4, [fp, #-0x78]
    // 0x9e8f50: r0 = LoadClassIdInstr(r3)
    //     0x9e8f50: ldur            x0, [x3, #-1]
    //     0x9e8f54: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8f58: mov             x1, x3
    // 0x9e8f5c: r2 = "supported64BitAbis"
    //     0x9e8f5c: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a7f0] "supported64BitAbis"
    //     0x9e8f60: ldr             x2, [x2, #0x7f0]
    // 0x9e8f64: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8f64: sub             lr, x0, #0xd48
    //     0x9e8f68: ldr             lr, [x21, lr, lsl #3]
    //     0x9e8f6c: blr             lr
    // 0x9e8f70: cmp             w0, NULL
    // 0x9e8f74: b.ne            #0x9e8f8c
    // 0x9e8f78: r1 = <String>
    //     0x9e8f78: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e8f7c: r2 = 0
    //     0x9e8f7c: mov             x2, #0
    // 0x9e8f80: r0 = _GrowableList()
    //     0x9e8f80: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e8f84: mov             x4, x0
    // 0x9e8f88: b               #0x9e8f90
    // 0x9e8f8c: mov             x4, x0
    // 0x9e8f90: ldur            x3, [fp, #-8]
    // 0x9e8f94: mov             x0, x4
    // 0x9e8f98: stur            x4, [fp, #-0x80]
    // 0x9e8f9c: r2 = Null
    //     0x9e8f9c: mov             x2, NULL
    // 0x9e8fa0: r1 = Null
    //     0x9e8fa0: mov             x1, NULL
    // 0x9e8fa4: r4 = 60
    //     0x9e8fa4: mov             x4, #0x3c
    // 0x9e8fa8: branchIfSmi(r0, 0x9e8fb4)
    //     0x9e8fa8: tbz             w0, #0, #0x9e8fb4
    // 0x9e8fac: r4 = LoadClassIdInstr(r0)
    //     0x9e8fac: ldur            x4, [x0, #-1]
    //     0x9e8fb0: ubfx            x4, x4, #0xc, #0x14
    // 0x9e8fb4: sub             x4, x4, #0x5a
    // 0x9e8fb8: cmp             x4, #2
    // 0x9e8fbc: b.ls            #0x9e8fd0
    // 0x9e8fc0: r8 = List
    //     0x9e8fc0: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x9e8fc4: r3 = Null
    //     0x9e8fc4: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a7f8] Null
    //     0x9e8fc8: ldr             x3, [x3, #0x7f8]
    // 0x9e8fcc: r0 = List()
    //     0x9e8fcc: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x9e8fd0: ldur            x1, [fp, #-0x80]
    // 0x9e8fd4: r0 = _fromList()
    //     0x9e8fd4: bl              #0x9e9778  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0x9e8fd8: mov             x4, x0
    // 0x9e8fdc: ldur            x3, [fp, #-8]
    // 0x9e8fe0: stur            x4, [fp, #-0x80]
    // 0x9e8fe4: r0 = LoadClassIdInstr(r3)
    //     0x9e8fe4: ldur            x0, [x3, #-1]
    //     0x9e8fe8: ubfx            x0, x0, #0xc, #0x14
    // 0x9e8fec: mov             x1, x3
    // 0x9e8ff0: r2 = "supportedAbis"
    //     0x9e8ff0: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a808] "supportedAbis"
    //     0x9e8ff4: ldr             x2, [x2, #0x808]
    // 0x9e8ff8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e8ff8: sub             lr, x0, #0xd48
    //     0x9e8ffc: ldr             lr, [x21, lr, lsl #3]
    //     0x9e9000: blr             lr
    // 0x9e9004: cmp             w0, NULL
    // 0x9e9008: b.ne            #0x9e9020
    // 0x9e900c: r1 = Null
    //     0x9e900c: mov             x1, NULL
    // 0x9e9010: r2 = 0
    //     0x9e9010: mov             x2, #0
    // 0x9e9014: r0 = _GrowableList()
    //     0x9e9014: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e9018: mov             x4, x0
    // 0x9e901c: b               #0x9e9024
    // 0x9e9020: mov             x4, x0
    // 0x9e9024: ldur            x3, [fp, #-8]
    // 0x9e9028: mov             x0, x4
    // 0x9e902c: stur            x4, [fp, #-0x88]
    // 0x9e9030: r2 = Null
    //     0x9e9030: mov             x2, NULL
    // 0x9e9034: r1 = Null
    //     0x9e9034: mov             x1, NULL
    // 0x9e9038: r4 = 60
    //     0x9e9038: mov             x4, #0x3c
    // 0x9e903c: branchIfSmi(r0, 0x9e9048)
    //     0x9e903c: tbz             w0, #0, #0x9e9048
    // 0x9e9040: r4 = LoadClassIdInstr(r0)
    //     0x9e9040: ldur            x4, [x0, #-1]
    //     0x9e9044: ubfx            x4, x4, #0xc, #0x14
    // 0x9e9048: sub             x4, x4, #0x5a
    // 0x9e904c: cmp             x4, #2
    // 0x9e9050: b.ls            #0x9e9064
    // 0x9e9054: r8 = List
    //     0x9e9054: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x9e9058: r3 = Null
    //     0x9e9058: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a810] Null
    //     0x9e905c: ldr             x3, [x3, #0x810]
    // 0x9e9060: r0 = List()
    //     0x9e9060: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x9e9064: ldur            x1, [fp, #-0x88]
    // 0x9e9068: r0 = _fromList()
    //     0x9e9068: bl              #0x9e9778  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0x9e906c: mov             x4, x0
    // 0x9e9070: ldur            x3, [fp, #-8]
    // 0x9e9074: stur            x4, [fp, #-0x88]
    // 0x9e9078: r0 = LoadClassIdInstr(r3)
    //     0x9e9078: ldur            x0, [x3, #-1]
    //     0x9e907c: ubfx            x0, x0, #0xc, #0x14
    // 0x9e9080: mov             x1, x3
    // 0x9e9084: r2 = "tags"
    //     0x9e9084: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a820] "tags"
    //     0x9e9088: ldr             x2, [x2, #0x820]
    // 0x9e908c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e908c: sub             lr, x0, #0xd48
    //     0x9e9090: ldr             lr, [x21, lr, lsl #3]
    //     0x9e9094: blr             lr
    // 0x9e9098: mov             x3, x0
    // 0x9e909c: r2 = Null
    //     0x9e909c: mov             x2, NULL
    // 0x9e90a0: r1 = Null
    //     0x9e90a0: mov             x1, NULL
    // 0x9e90a4: stur            x3, [fp, #-0x90]
    // 0x9e90a8: r4 = 60
    //     0x9e90a8: mov             x4, #0x3c
    // 0x9e90ac: branchIfSmi(r0, 0x9e90b8)
    //     0x9e90ac: tbz             w0, #0, #0x9e90b8
    // 0x9e90b0: r4 = LoadClassIdInstr(r0)
    //     0x9e90b0: ldur            x4, [x0, #-1]
    //     0x9e90b4: ubfx            x4, x4, #0xc, #0x14
    // 0x9e90b8: sub             x4, x4, #0x5e
    // 0x9e90bc: cmp             x4, #1
    // 0x9e90c0: b.ls            #0x9e90d4
    // 0x9e90c4: r8 = String
    //     0x9e90c4: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e90c8: r3 = Null
    //     0x9e90c8: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a828] Null
    //     0x9e90cc: ldr             x3, [x3, #0x828]
    // 0x9e90d0: r0 = String()
    //     0x9e90d0: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e90d4: ldur            x3, [fp, #-8]
    // 0x9e90d8: r0 = LoadClassIdInstr(r3)
    //     0x9e90d8: ldur            x0, [x3, #-1]
    //     0x9e90dc: ubfx            x0, x0, #0xc, #0x14
    // 0x9e90e0: mov             x1, x3
    // 0x9e90e4: r2 = "type"
    //     0x9e90e4: ldr             x2, [PP, #0x3250]  ; [pp+0x3250] "type"
    // 0x9e90e8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e90e8: sub             lr, x0, #0xd48
    //     0x9e90ec: ldr             lr, [x21, lr, lsl #3]
    //     0x9e90f0: blr             lr
    // 0x9e90f4: r2 = Null
    //     0x9e90f4: mov             x2, NULL
    // 0x9e90f8: r1 = Null
    //     0x9e90f8: mov             x1, NULL
    // 0x9e90fc: r4 = 60
    //     0x9e90fc: mov             x4, #0x3c
    // 0x9e9100: branchIfSmi(r0, 0x9e910c)
    //     0x9e9100: tbz             w0, #0, #0x9e910c
    // 0x9e9104: r4 = LoadClassIdInstr(r0)
    //     0x9e9104: ldur            x4, [x0, #-1]
    //     0x9e9108: ubfx            x4, x4, #0xc, #0x14
    // 0x9e910c: sub             x4, x4, #0x5e
    // 0x9e9110: cmp             x4, #1
    // 0x9e9114: b.ls            #0x9e9128
    // 0x9e9118: r8 = String
    //     0x9e9118: ldr             x8, [PP, #0x970]  ; [pp+0x970] Type: String
    // 0x9e911c: r3 = Null
    //     0x9e911c: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a838] Null
    //     0x9e9120: ldr             x3, [x3, #0x838]
    // 0x9e9124: r0 = String()
    //     0x9e9124: bl              #0x13ee320  ; IsType_String_Stub
    // 0x9e9128: ldur            x3, [fp, #-8]
    // 0x9e912c: r0 = LoadClassIdInstr(r3)
    //     0x9e912c: ldur            x0, [x3, #-1]
    //     0x9e9130: ubfx            x0, x0, #0xc, #0x14
    // 0x9e9134: mov             x1, x3
    // 0x9e9138: r2 = "isPhysicalDevice"
    //     0x9e9138: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a848] "isPhysicalDevice"
    //     0x9e913c: ldr             x2, [x2, #0x848]
    // 0x9e9140: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e9140: sub             lr, x0, #0xd48
    //     0x9e9144: ldr             lr, [x21, lr, lsl #3]
    //     0x9e9148: blr             lr
    // 0x9e914c: mov             x3, x0
    // 0x9e9150: r2 = Null
    //     0x9e9150: mov             x2, NULL
    // 0x9e9154: r1 = Null
    //     0x9e9154: mov             x1, NULL
    // 0x9e9158: stur            x3, [fp, #-0x98]
    // 0x9e915c: r4 = 60
    //     0x9e915c: mov             x4, #0x3c
    // 0x9e9160: branchIfSmi(r0, 0x9e916c)
    //     0x9e9160: tbz             w0, #0, #0x9e916c
    // 0x9e9164: r4 = LoadClassIdInstr(r0)
    //     0x9e9164: ldur            x4, [x0, #-1]
    //     0x9e9168: ubfx            x4, x4, #0xc, #0x14
    // 0x9e916c: cmp             x4, #0x3f
    // 0x9e9170: b.eq            #0x9e9184
    // 0x9e9174: r8 = bool
    //     0x9e9174: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x9e9178: r3 = Null
    //     0x9e9178: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a850] Null
    //     0x9e917c: ldr             x3, [x3, #0x850]
    // 0x9e9180: r0 = bool()
    //     0x9e9180: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x9e9184: ldur            x3, [fp, #-8]
    // 0x9e9188: r0 = LoadClassIdInstr(r3)
    //     0x9e9188: ldur            x0, [x3, #-1]
    //     0x9e918c: ubfx            x0, x0, #0xc, #0x14
    // 0x9e9190: mov             x1, x3
    // 0x9e9194: r2 = "freeDiskSize"
    //     0x9e9194: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a860] "freeDiskSize"
    //     0x9e9198: ldr             x2, [x2, #0x860]
    // 0x9e919c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e919c: sub             lr, x0, #0xd48
    //     0x9e91a0: ldr             lr, [x21, lr, lsl #3]
    //     0x9e91a4: blr             lr
    // 0x9e91a8: r2 = Null
    //     0x9e91a8: mov             x2, NULL
    // 0x9e91ac: r1 = Null
    //     0x9e91ac: mov             x1, NULL
    // 0x9e91b0: branchIfSmi(r0, 0x9e91d8)
    //     0x9e91b0: tbz             w0, #0, #0x9e91d8
    // 0x9e91b4: r4 = LoadClassIdInstr(r0)
    //     0x9e91b4: ldur            x4, [x0, #-1]
    //     0x9e91b8: ubfx            x4, x4, #0xc, #0x14
    // 0x9e91bc: sub             x4, x4, #0x3c
    // 0x9e91c0: cmp             x4, #1
    // 0x9e91c4: b.ls            #0x9e91d8
    // 0x9e91c8: r8 = int
    //     0x9e91c8: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x9e91cc: r3 = Null
    //     0x9e91cc: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a868] Null
    //     0x9e91d0: ldr             x3, [x3, #0x868]
    // 0x9e91d4: r0 = int()
    //     0x9e91d4: bl              #0x13ee980  ; IsType_int_Stub
    // 0x9e91d8: ldur            x3, [fp, #-8]
    // 0x9e91dc: r0 = LoadClassIdInstr(r3)
    //     0x9e91dc: ldur            x0, [x3, #-1]
    //     0x9e91e0: ubfx            x0, x0, #0xc, #0x14
    // 0x9e91e4: mov             x1, x3
    // 0x9e91e8: r2 = "totalDiskSize"
    //     0x9e91e8: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a878] "totalDiskSize"
    //     0x9e91ec: ldr             x2, [x2, #0x878]
    // 0x9e91f0: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e91f0: sub             lr, x0, #0xd48
    //     0x9e91f4: ldr             lr, [x21, lr, lsl #3]
    //     0x9e91f8: blr             lr
    // 0x9e91fc: r2 = Null
    //     0x9e91fc: mov             x2, NULL
    // 0x9e9200: r1 = Null
    //     0x9e9200: mov             x1, NULL
    // 0x9e9204: branchIfSmi(r0, 0x9e922c)
    //     0x9e9204: tbz             w0, #0, #0x9e922c
    // 0x9e9208: r4 = LoadClassIdInstr(r0)
    //     0x9e9208: ldur            x4, [x0, #-1]
    //     0x9e920c: ubfx            x4, x4, #0xc, #0x14
    // 0x9e9210: sub             x4, x4, #0x3c
    // 0x9e9214: cmp             x4, #1
    // 0x9e9218: b.ls            #0x9e922c
    // 0x9e921c: r8 = int
    //     0x9e921c: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x9e9220: r3 = Null
    //     0x9e9220: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a880] Null
    //     0x9e9224: ldr             x3, [x3, #0x880]
    // 0x9e9228: r0 = int()
    //     0x9e9228: bl              #0x13ee980  ; IsType_int_Stub
    // 0x9e922c: ldur            x3, [fp, #-8]
    // 0x9e9230: r0 = LoadClassIdInstr(r3)
    //     0x9e9230: ldur            x0, [x3, #-1]
    //     0x9e9234: ubfx            x0, x0, #0xc, #0x14
    // 0x9e9238: mov             x1, x3
    // 0x9e923c: r2 = "systemFeatures"
    //     0x9e923c: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a890] "systemFeatures"
    //     0x9e9240: ldr             x2, [x2, #0x890]
    // 0x9e9244: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e9244: sub             lr, x0, #0xd48
    //     0x9e9248: ldr             lr, [x21, lr, lsl #3]
    //     0x9e924c: blr             lr
    // 0x9e9250: cmp             w0, NULL
    // 0x9e9254: b.ne            #0x9e926c
    // 0x9e9258: r1 = Null
    //     0x9e9258: mov             x1, NULL
    // 0x9e925c: r2 = 0
    //     0x9e925c: mov             x2, #0
    // 0x9e9260: r0 = _GrowableList()
    //     0x9e9260: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x9e9264: mov             x4, x0
    // 0x9e9268: b               #0x9e9270
    // 0x9e926c: mov             x4, x0
    // 0x9e9270: ldur            x3, [fp, #-8]
    // 0x9e9274: mov             x0, x4
    // 0x9e9278: stur            x4, [fp, #-0xa0]
    // 0x9e927c: r2 = Null
    //     0x9e927c: mov             x2, NULL
    // 0x9e9280: r1 = Null
    //     0x9e9280: mov             x1, NULL
    // 0x9e9284: r4 = 60
    //     0x9e9284: mov             x4, #0x3c
    // 0x9e9288: branchIfSmi(r0, 0x9e9294)
    //     0x9e9288: tbz             w0, #0, #0x9e9294
    // 0x9e928c: r4 = LoadClassIdInstr(r0)
    //     0x9e928c: ldur            x4, [x0, #-1]
    //     0x9e9290: ubfx            x4, x4, #0xc, #0x14
    // 0x9e9294: sub             x4, x4, #0x5a
    // 0x9e9298: cmp             x4, #2
    // 0x9e929c: b.ls            #0x9e92b0
    // 0x9e92a0: r8 = List
    //     0x9e92a0: ldr             x8, [PP, #0x30e8]  ; [pp+0x30e8] Type: List
    // 0x9e92a4: r3 = Null
    //     0x9e92a4: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a898] Null
    //     0x9e92a8: ldr             x3, [x3, #0x898]
    // 0x9e92ac: r0 = List()
    //     0x9e92ac: bl              #0x13efaa0  ; IsType_List_Stub
    // 0x9e92b0: ldur            x1, [fp, #-0xa0]
    // 0x9e92b4: r0 = _fromList()
    //     0x9e92b4: bl              #0x9e9778  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::_fromList
    // 0x9e92b8: mov             x4, x0
    // 0x9e92bc: ldur            x3, [fp, #-8]
    // 0x9e92c0: stur            x4, [fp, #-0xa0]
    // 0x9e92c4: r0 = LoadClassIdInstr(r3)
    //     0x9e92c4: ldur            x0, [x3, #-1]
    //     0x9e92c8: ubfx            x0, x0, #0xc, #0x14
    // 0x9e92cc: mov             x1, x3
    // 0x9e92d0: r2 = "isLowRamDevice"
    //     0x9e92d0: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a8a8] "isLowRamDevice"
    //     0x9e92d4: ldr             x2, [x2, #0x8a8]
    // 0x9e92d8: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e92d8: sub             lr, x0, #0xd48
    //     0x9e92dc: ldr             lr, [x21, lr, lsl #3]
    //     0x9e92e0: blr             lr
    // 0x9e92e4: r2 = Null
    //     0x9e92e4: mov             x2, NULL
    // 0x9e92e8: r1 = Null
    //     0x9e92e8: mov             x1, NULL
    // 0x9e92ec: r4 = 60
    //     0x9e92ec: mov             x4, #0x3c
    // 0x9e92f0: branchIfSmi(r0, 0x9e92fc)
    //     0x9e92f0: tbz             w0, #0, #0x9e92fc
    // 0x9e92f4: r4 = LoadClassIdInstr(r0)
    //     0x9e92f4: ldur            x4, [x0, #-1]
    //     0x9e92f8: ubfx            x4, x4, #0xc, #0x14
    // 0x9e92fc: cmp             x4, #0x3f
    // 0x9e9300: b.eq            #0x9e9314
    // 0x9e9304: r8 = bool
    //     0x9e9304: ldr             x8, [PP, #0xb18]  ; [pp+0xb18] Type: bool
    // 0x9e9308: r3 = Null
    //     0x9e9308: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a8b0] Null
    //     0x9e930c: ldr             x3, [x3, #0x8b0]
    // 0x9e9310: r0 = bool()
    //     0x9e9310: bl              #0x13ee15c  ; IsType_bool_Stub
    // 0x9e9314: ldur            x3, [fp, #-8]
    // 0x9e9318: r0 = LoadClassIdInstr(r3)
    //     0x9e9318: ldur            x0, [x3, #-1]
    //     0x9e931c: ubfx            x0, x0, #0xc, #0x14
    // 0x9e9320: mov             x1, x3
    // 0x9e9324: r2 = "physicalRamSize"
    //     0x9e9324: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a8c0] "physicalRamSize"
    //     0x9e9328: ldr             x2, [x2, #0x8c0]
    // 0x9e932c: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e932c: sub             lr, x0, #0xd48
    //     0x9e9330: ldr             lr, [x21, lr, lsl #3]
    //     0x9e9334: blr             lr
    // 0x9e9338: r2 = Null
    //     0x9e9338: mov             x2, NULL
    // 0x9e933c: r1 = Null
    //     0x9e933c: mov             x1, NULL
    // 0x9e9340: branchIfSmi(r0, 0x9e9368)
    //     0x9e9340: tbz             w0, #0, #0x9e9368
    // 0x9e9344: r4 = LoadClassIdInstr(r0)
    //     0x9e9344: ldur            x4, [x0, #-1]
    //     0x9e9348: ubfx            x4, x4, #0xc, #0x14
    // 0x9e934c: sub             x4, x4, #0x3c
    // 0x9e9350: cmp             x4, #1
    // 0x9e9354: b.ls            #0x9e9368
    // 0x9e9358: r8 = int
    //     0x9e9358: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x9e935c: r3 = Null
    //     0x9e935c: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a8c8] Null
    //     0x9e9360: ldr             x3, [x3, #0x8c8]
    // 0x9e9364: r0 = int()
    //     0x9e9364: bl              #0x13ee980  ; IsType_int_Stub
    // 0x9e9368: ldur            x3, [fp, #-8]
    // 0x9e936c: r0 = LoadClassIdInstr(r3)
    //     0x9e936c: ldur            x0, [x3, #-1]
    //     0x9e9370: ubfx            x0, x0, #0xc, #0x14
    // 0x9e9374: mov             x1, x3
    // 0x9e9378: r2 = "availableRamSize"
    //     0x9e9378: add             x2, PP, #0x7a, lsl #12  ; [pp+0x7a8d8] "availableRamSize"
    //     0x9e937c: ldr             x2, [x2, #0x8d8]
    // 0x9e9380: r0 = GDT[cid_x0 + -0xd48]()
    //     0x9e9380: sub             lr, x0, #0xd48
    //     0x9e9384: ldr             lr, [x21, lr, lsl #3]
    //     0x9e9388: blr             lr
    // 0x9e938c: r2 = Null
    //     0x9e938c: mov             x2, NULL
    // 0x9e9390: r1 = Null
    //     0x9e9390: mov             x1, NULL
    // 0x9e9394: branchIfSmi(r0, 0x9e93bc)
    //     0x9e9394: tbz             w0, #0, #0x9e93bc
    // 0x9e9398: r4 = LoadClassIdInstr(r0)
    //     0x9e9398: ldur            x4, [x0, #-1]
    //     0x9e939c: ubfx            x4, x4, #0xc, #0x14
    // 0x9e93a0: sub             x4, x4, #0x3c
    // 0x9e93a4: cmp             x4, #1
    // 0x9e93a8: b.ls            #0x9e93bc
    // 0x9e93ac: r8 = int
    //     0x9e93ac: ldr             x8, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x9e93b0: r3 = Null
    //     0x9e93b0: add             x3, PP, #0x7a, lsl #12  ; [pp+0x7a8e0] Null
    //     0x9e93b4: ldr             x3, [x3, #0x8e0]
    // 0x9e93b8: r0 = int()
    //     0x9e93b8: bl              #0x13ee980  ; IsType_int_Stub
    // 0x9e93bc: r0 = AndroidDeviceInfo()
    //     0x9e93bc: bl              #0x9e976c  ; AllocateAndroidDeviceInfoStub -> AndroidDeviceInfo (size=0x50)
    // 0x9e93c0: stur            x0, [fp, #-0xa8]
    // 0x9e93c4: ldur            x16, [fp, #-0x38]
    // 0x9e93c8: ldur            lr, [fp, #-0x40]
    // 0x9e93cc: stp             lr, x16, [SP, #0x68]
    // 0x9e93d0: ldur            x16, [fp, #-0x48]
    // 0x9e93d4: ldur            lr, [fp, #-0x50]
    // 0x9e93d8: stp             lr, x16, [SP, #0x58]
    // 0x9e93dc: ldur            x16, [fp, #-0x98]
    // 0x9e93e0: ldur            lr, [fp, #-0x58]
    // 0x9e93e4: stp             lr, x16, [SP, #0x48]
    // 0x9e93e8: ldur            x16, [fp, #-0x60]
    // 0x9e93ec: ldur            lr, [fp, #-0x70]
    // 0x9e93f0: stp             lr, x16, [SP, #0x38]
    // 0x9e93f4: ldur            x16, [fp, #-0x68]
    // 0x9e93f8: ldur            lr, [fp, #-0x78]
    // 0x9e93fc: stp             lr, x16, [SP, #0x28]
    // 0x9e9400: ldur            x16, [fp, #-0x80]
    // 0x9e9404: ldur            lr, [fp, #-0x88]
    // 0x9e9408: stp             lr, x16, [SP, #0x18]
    // 0x9e940c: ldur            x16, [fp, #-0xa0]
    // 0x9e9410: ldur            lr, [fp, #-0x90]
    // 0x9e9414: stp             lr, x16, [SP, #8]
    // 0x9e9418: ldur            x16, [fp, #-0x10]
    // 0x9e941c: str             x16, [SP]
    // 0x9e9420: mov             x1, x0
    // 0x9e9424: ldur            x2, [fp, #-0x18]
    // 0x9e9428: ldur            x3, [fp, #-0x20]
    // 0x9e942c: ldur            x5, [fp, #-8]
    // 0x9e9430: ldur            x6, [fp, #-0x28]
    // 0x9e9434: ldur            x7, [fp, #-0x30]
    // 0x9e9438: r0 = AndroidDeviceInfo._()
    //     0x9e9438: bl              #0x9e9454  ; [package:device_info_plus/src/model/android_device_info.dart] AndroidDeviceInfo::AndroidDeviceInfo._
    // 0x9e943c: ldur            x0, [fp, #-0xa8]
    // 0x9e9440: LeaveFrame
    //     0x9e9440: mov             SP, fp
    //     0x9e9444: ldp             fp, lr, [SP], #0x10
    // 0x9e9448: ret
    //     0x9e9448: ret             
    // 0x9e944c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e944c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e9450: b               #0x9e8930
  }
  _ AndroidDeviceInfo._(/* No info */) {
    // ** addr: 0x9e9454, size: 0x318
    // 0x9e9454: EnterFrame
    //     0x9e9454: stp             fp, lr, [SP, #-0x10]!
    //     0x9e9458: mov             fp, SP
    // 0x9e945c: AllocStack(0x20)
    //     0x9e945c: sub             SP, SP, #0x20
    // 0x9e9460: SetupParameters(AndroidDeviceInfo this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r5 */, dynamic _ /* r3 => r4 */, dynamic _ /* r5 => r3, fp-0x10 */, dynamic _ /* r6 => r2 */, dynamic _ /* r7 => r1 */)
    //     0x9e9460: mov             x4, x3
    //     0x9e9464: mov             x3, x5
    //     0x9e9468: stur            x5, [fp, #-0x10]
    //     0x9e946c: mov             x5, x2
    //     0x9e9470: mov             x2, x6
    //     0x9e9474: mov             x6, x1
    //     0x9e9478: stur            x1, [fp, #-8]
    //     0x9e947c: mov             x1, x7
    // 0x9e9480: CheckStackOverflow
    //     0x9e9480: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e9484: cmp             SP, x16
    //     0x9e9488: b.ls            #0x9e9764
    // 0x9e948c: ldr             x0, [fp, #0x10]
    // 0x9e9490: StoreField: r6->field_b = r0
    //     0x9e9490: stur            w0, [x6, #0xb]
    //     0x9e9494: ldurb           w16, [x6, #-1]
    //     0x9e9498: ldurb           w17, [x0, #-1]
    //     0x9e949c: and             x16, x17, x16, lsr #2
    //     0x9e94a0: tst             x16, HEAP, lsr #32
    //     0x9e94a4: b.eq            #0x9e94ac
    //     0x9e94a8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e94ac: mov             x0, x5
    // 0x9e94b0: StoreField: r6->field_f = r0
    //     0x9e94b0: stur            w0, [x6, #0xf]
    //     0x9e94b4: ldurb           w16, [x6, #-1]
    //     0x9e94b8: ldurb           w17, [x0, #-1]
    //     0x9e94bc: and             x16, x17, x16, lsr #2
    //     0x9e94c0: tst             x16, HEAP, lsr #32
    //     0x9e94c4: b.eq            #0x9e94cc
    //     0x9e94c8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e94cc: mov             x0, x4
    // 0x9e94d0: StoreField: r6->field_13 = r0
    //     0x9e94d0: stur            w0, [x6, #0x13]
    //     0x9e94d4: ldurb           w16, [x6, #-1]
    //     0x9e94d8: ldurb           w17, [x0, #-1]
    //     0x9e94dc: and             x16, x17, x16, lsr #2
    //     0x9e94e0: tst             x16, HEAP, lsr #32
    //     0x9e94e4: b.eq            #0x9e94ec
    //     0x9e94e8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e94ec: mov             x0, x2
    // 0x9e94f0: ArrayStore: r6[0] = r0  ; List_4
    //     0x9e94f0: stur            w0, [x6, #0x17]
    //     0x9e94f4: ldurb           w16, [x6, #-1]
    //     0x9e94f8: ldurb           w17, [x0, #-1]
    //     0x9e94fc: and             x16, x17, x16, lsr #2
    //     0x9e9500: tst             x16, HEAP, lsr #32
    //     0x9e9504: b.eq            #0x9e950c
    //     0x9e9508: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e950c: mov             x0, x1
    // 0x9e9510: StoreField: r6->field_1b = r0
    //     0x9e9510: stur            w0, [x6, #0x1b]
    //     0x9e9514: ldurb           w16, [x6, #-1]
    //     0x9e9518: ldurb           w17, [x0, #-1]
    //     0x9e951c: and             x16, x17, x16, lsr #2
    //     0x9e9520: tst             x16, HEAP, lsr #32
    //     0x9e9524: b.eq            #0x9e952c
    //     0x9e9528: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e952c: ldr             x0, [fp, #0x80]
    // 0x9e9530: StoreField: r6->field_1f = r0
    //     0x9e9530: stur            w0, [x6, #0x1f]
    //     0x9e9534: ldurb           w16, [x6, #-1]
    //     0x9e9538: ldurb           w17, [x0, #-1]
    //     0x9e953c: and             x16, x17, x16, lsr #2
    //     0x9e9540: tst             x16, HEAP, lsr #32
    //     0x9e9544: b.eq            #0x9e954c
    //     0x9e9548: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e954c: ldr             x0, [fp, #0x78]
    // 0x9e9550: StoreField: r6->field_23 = r0
    //     0x9e9550: stur            w0, [x6, #0x23]
    //     0x9e9554: ldurb           w16, [x6, #-1]
    //     0x9e9558: ldurb           w17, [x0, #-1]
    //     0x9e955c: and             x16, x17, x16, lsr #2
    //     0x9e9560: tst             x16, HEAP, lsr #32
    //     0x9e9564: b.eq            #0x9e956c
    //     0x9e9568: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e956c: ldr             x0, [fp, #0x70]
    // 0x9e9570: StoreField: r6->field_27 = r0
    //     0x9e9570: stur            w0, [x6, #0x27]
    //     0x9e9574: ldurb           w16, [x6, #-1]
    //     0x9e9578: ldurb           w17, [x0, #-1]
    //     0x9e957c: and             x16, x17, x16, lsr #2
    //     0x9e9580: tst             x16, HEAP, lsr #32
    //     0x9e9584: b.eq            #0x9e958c
    //     0x9e9588: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e958c: ldr             x0, [fp, #0x68]
    // 0x9e9590: StoreField: r6->field_2b = r0
    //     0x9e9590: stur            w0, [x6, #0x2b]
    //     0x9e9594: ldurb           w16, [x6, #-1]
    //     0x9e9598: ldurb           w17, [x0, #-1]
    //     0x9e959c: and             x16, x17, x16, lsr #2
    //     0x9e95a0: tst             x16, HEAP, lsr #32
    //     0x9e95a4: b.eq            #0x9e95ac
    //     0x9e95a8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e95ac: ldr             x0, [fp, #0x58]
    // 0x9e95b0: StoreField: r6->field_2f = r0
    //     0x9e95b0: stur            w0, [x6, #0x2f]
    //     0x9e95b4: ldurb           w16, [x6, #-1]
    //     0x9e95b8: ldurb           w17, [x0, #-1]
    //     0x9e95bc: and             x16, x17, x16, lsr #2
    //     0x9e95c0: tst             x16, HEAP, lsr #32
    //     0x9e95c4: b.eq            #0x9e95cc
    //     0x9e95c8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e95cc: ldr             x0, [fp, #0x50]
    // 0x9e95d0: StoreField: r6->field_33 = r0
    //     0x9e95d0: stur            w0, [x6, #0x33]
    //     0x9e95d4: ldurb           w16, [x6, #-1]
    //     0x9e95d8: ldurb           w17, [x0, #-1]
    //     0x9e95dc: and             x16, x17, x16, lsr #2
    //     0x9e95e0: tst             x16, HEAP, lsr #32
    //     0x9e95e4: b.eq            #0x9e95ec
    //     0x9e95e8: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e95ec: ldr             x0, [fp, #0x40]
    // 0x9e95f0: StoreField: r6->field_37 = r0
    //     0x9e95f0: stur            w0, [x6, #0x37]
    //     0x9e95f4: ldurb           w16, [x6, #-1]
    //     0x9e95f8: ldurb           w17, [x0, #-1]
    //     0x9e95fc: and             x16, x17, x16, lsr #2
    //     0x9e9600: tst             x16, HEAP, lsr #32
    //     0x9e9604: b.eq            #0x9e960c
    //     0x9e9608: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e960c: ldr             x0, [fp, #0x48]
    // 0x9e9610: StoreField: r6->field_3b = r0
    //     0x9e9610: stur            w0, [x6, #0x3b]
    //     0x9e9614: ldurb           w16, [x6, #-1]
    //     0x9e9618: ldurb           w17, [x0, #-1]
    //     0x9e961c: and             x16, x17, x16, lsr #2
    //     0x9e9620: tst             x16, HEAP, lsr #32
    //     0x9e9624: b.eq            #0x9e962c
    //     0x9e9628: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e962c: ldr             x0, [fp, #0x18]
    // 0x9e9630: StoreField: r6->field_43 = r0
    //     0x9e9630: stur            w0, [x6, #0x43]
    //     0x9e9634: ldurb           w16, [x6, #-1]
    //     0x9e9638: ldurb           w17, [x0, #-1]
    //     0x9e963c: and             x16, x17, x16, lsr #2
    //     0x9e9640: tst             x16, HEAP, lsr #32
    //     0x9e9644: b.eq            #0x9e964c
    //     0x9e9648: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x9e964c: ldr             x0, [fp, #0x60]
    // 0x9e9650: StoreField: r6->field_47 = r0
    //     0x9e9650: stur            w0, [x6, #0x47]
    // 0x9e9654: r16 = false
    //     0x9e9654: add             x16, NULL, #0x30  ; false
    // 0x9e9658: str             x16, [SP]
    // 0x9e965c: ldr             x2, [fp, #0x38]
    // 0x9e9660: r1 = <String>
    //     0x9e9660: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e9664: r4 = const [0, 0x3, 0x1, 0x2, growable, 0x2, null]
    //     0x9e9664: ldr             x4, [PP, #0x7ba0]  ; [pp+0x7ba0] List(7) [0, 0x3, 0x1, 0x2, "growable", 0x2, Null]
    // 0x9e9668: r0 = List.from()
    //     0x9e9668: bl              #0x876494  ; [dart:core] List::List.from
    // 0x9e966c: r16 = <String>
    //     0x9e966c: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e9670: stp             x0, x16, [SP]
    // 0x9e9674: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9e9674: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9e9678: r0 = makeFixedListUnmodifiable()
    //     0x9e9678: bl              #0x8c63c0  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x9e967c: r16 = false
    //     0x9e967c: add             x16, NULL, #0x30  ; false
    // 0x9e9680: str             x16, [SP]
    // 0x9e9684: ldr             x2, [fp, #0x30]
    // 0x9e9688: r1 = <String>
    //     0x9e9688: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e968c: r4 = const [0, 0x3, 0x1, 0x2, growable, 0x2, null]
    //     0x9e968c: ldr             x4, [PP, #0x7ba0]  ; [pp+0x7ba0] List(7) [0, 0x3, 0x1, 0x2, "growable", 0x2, Null]
    // 0x9e9690: r0 = List.from()
    //     0x9e9690: bl              #0x876494  ; [dart:core] List::List.from
    // 0x9e9694: r16 = <String>
    //     0x9e9694: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e9698: stp             x0, x16, [SP]
    // 0x9e969c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9e969c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9e96a0: r0 = makeFixedListUnmodifiable()
    //     0x9e96a0: bl              #0x8c63c0  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x9e96a4: r16 = false
    //     0x9e96a4: add             x16, NULL, #0x30  ; false
    // 0x9e96a8: str             x16, [SP]
    // 0x9e96ac: ldr             x2, [fp, #0x28]
    // 0x9e96b0: r1 = <String>
    //     0x9e96b0: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e96b4: r4 = const [0, 0x3, 0x1, 0x2, growable, 0x2, null]
    //     0x9e96b4: ldr             x4, [PP, #0x7ba0]  ; [pp+0x7ba0] List(7) [0, 0x3, 0x1, 0x2, "growable", 0x2, Null]
    // 0x9e96b8: r0 = List.from()
    //     0x9e96b8: bl              #0x876494  ; [dart:core] List::List.from
    // 0x9e96bc: r16 = <String>
    //     0x9e96bc: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e96c0: stp             x0, x16, [SP]
    // 0x9e96c4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9e96c4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9e96c8: r0 = makeFixedListUnmodifiable()
    //     0x9e96c8: bl              #0x8c63c0  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x9e96cc: ldur            x3, [fp, #-8]
    // 0x9e96d0: StoreField: r3->field_3f = r0
    //     0x9e96d0: stur            w0, [x3, #0x3f]
    //     0x9e96d4: ldurb           w16, [x3, #-1]
    //     0x9e96d8: ldurb           w17, [x0, #-1]
    //     0x9e96dc: and             x16, x17, x16, lsr #2
    //     0x9e96e0: tst             x16, HEAP, lsr #32
    //     0x9e96e4: b.eq            #0x9e96ec
    //     0x9e96e8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x9e96ec: r16 = false
    //     0x9e96ec: add             x16, NULL, #0x30  ; false
    // 0x9e96f0: str             x16, [SP]
    // 0x9e96f4: ldr             x2, [fp, #0x20]
    // 0x9e96f8: r1 = <String>
    //     0x9e96f8: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e96fc: r4 = const [0, 0x3, 0x1, 0x2, growable, 0x2, null]
    //     0x9e96fc: ldr             x4, [PP, #0x7ba0]  ; [pp+0x7ba0] List(7) [0, 0x3, 0x1, 0x2, "growable", 0x2, Null]
    // 0x9e9700: r0 = List.from()
    //     0x9e9700: bl              #0x876494  ; [dart:core] List::List.from
    // 0x9e9704: r16 = <String>
    //     0x9e9704: ldr             x16, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e9708: stp             x0, x16, [SP]
    // 0x9e970c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9e970c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9e9710: r0 = makeFixedListUnmodifiable()
    //     0x9e9710: bl              #0x8c63c0  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0x9e9714: ldur            x1, [fp, #-8]
    // 0x9e9718: StoreField: r1->field_4b = r0
    //     0x9e9718: stur            w0, [x1, #0x4b]
    //     0x9e971c: ldurb           w16, [x1, #-1]
    //     0x9e9720: ldurb           w17, [x0, #-1]
    //     0x9e9724: and             x16, x17, x16, lsr #2
    //     0x9e9728: tst             x16, HEAP, lsr #32
    //     0x9e972c: b.eq            #0x9e9734
    //     0x9e9730: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x9e9734: ldur            x0, [fp, #-0x10]
    // 0x9e9738: StoreField: r1->field_7 = r0
    //     0x9e9738: stur            w0, [x1, #7]
    //     0x9e973c: ldurb           w16, [x1, #-1]
    //     0x9e9740: ldurb           w17, [x0, #-1]
    //     0x9e9744: and             x16, x17, x16, lsr #2
    //     0x9e9748: tst             x16, HEAP, lsr #32
    //     0x9e974c: b.eq            #0x9e9754
    //     0x9e9750: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x9e9754: r0 = Null
    //     0x9e9754: mov             x0, NULL
    // 0x9e9758: LeaveFrame
    //     0x9e9758: mov             SP, fp
    //     0x9e975c: ldp             fp, lr, [SP], #0x10
    // 0x9e9760: ret
    //     0x9e9760: ret             
    // 0x9e9764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e9764: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e9768: b               #0x9e948c
  }
  static _ _fromList(/* No info */) {
    // ** addr: 0x9e9778, size: 0x8c
    // 0x9e9778: EnterFrame
    //     0x9e9778: stp             fp, lr, [SP, #-0x10]!
    //     0x9e977c: mov             fp, SP
    // 0x9e9780: AllocStack(0x8)
    //     0x9e9780: sub             SP, SP, #8
    // 0x9e9784: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0x9e9784: mov             x0, x1
    //     0x9e9788: stur            x1, [fp, #-8]
    // 0x9e978c: CheckStackOverflow
    //     0x9e978c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9e9790: cmp             SP, x16
    //     0x9e9794: b.ls            #0x9e97fc
    // 0x9e9798: r1 = Function '<anonymous closure>': static.
    //     0x9e9798: add             x1, PP, #0x7a, lsl #12  ; [pp+0x7a8f0] AnonymousClosure: (0x9e9804), in [package:simaster_ugm/app/modules/bimbingan/service/bimbingan_service.dart] BimbinganService::listBimbinganWithDosenProfile (0x9e981c)
    //     0x9e979c: ldr             x1, [x1, #0x8f0]
    // 0x9e97a0: r2 = Null
    //     0x9e97a0: mov             x2, NULL
    // 0x9e97a4: r0 = AllocateClosure()
    //     0x9e97a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x9e97a8: ldur            x1, [fp, #-8]
    // 0x9e97ac: r2 = LoadClassIdInstr(r1)
    //     0x9e97ac: ldur            x2, [x1, #-1]
    //     0x9e97b0: ubfx            x2, x2, #0xc, #0x14
    // 0x9e97b4: mov             x16, x0
    // 0x9e97b8: mov             x0, x2
    // 0x9e97bc: mov             x2, x16
    // 0x9e97c0: r0 = GDT[cid_x0 + 0x17f1f]()
    //     0x9e97c0: mov             x17, #0x7f1f
    //     0x9e97c4: movk            x17, #1, lsl #16
    //     0x9e97c8: add             lr, x0, x17
    //     0x9e97cc: ldr             lr, [x21, lr, lsl #3]
    //     0x9e97d0: blr             lr
    // 0x9e97d4: mov             x1, x0
    // 0x9e97d8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x9e97d8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x9e97dc: r0 = toList()
    //     0x9e97dc: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0x9e97e0: mov             x2, x0
    // 0x9e97e4: r1 = <String>
    //     0x9e97e4: ldr             x1, [PP, #0x8d0]  ; [pp+0x8d0] TypeArguments: <String>
    // 0x9e97e8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x9e97e8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x9e97ec: r0 = List.from()
    //     0x9e97ec: bl              #0x876494  ; [dart:core] List::List.from
    // 0x9e97f0: LeaveFrame
    //     0x9e97f0: mov             SP, fp
    //     0x9e97f4: ldp             fp, lr, [SP], #0x10
    // 0x9e97f8: ret
    //     0x9e97f8: ret             
    // 0x9e97fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9e97fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9e9800: b               #0x9e9798
  }
}
