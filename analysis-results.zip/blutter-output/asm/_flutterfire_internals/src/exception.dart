// lib: , url: package:_flutterfire_internals/src/exception.dart

// class id: 1048598, size: 0x8
class :: {

  static _ convertPlatformExceptionToFirebaseException(/* No info */) {
    // ** addr: 0x8c0778, size: 0x84
    // 0x8c0778: EnterFrame
    //     0x8c0778: stp             fp, lr, [SP, #-0x10]!
    //     0x8c077c: mov             fp, SP
    // 0x8c0780: AllocStack(0x18)
    //     0x8c0780: sub             SP, SP, #0x18
    // 0x8c0784: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2, fp-0x10 */)
    //     0x8c0784: mov             x0, x2
    //     0x8c0788: mov             x2, x3
    //     0x8c078c: stur            x1, [fp, #-8]
    //     0x8c0790: stur            x3, [fp, #-0x10]
    // 0x8c0794: CheckStackOverflow
    //     0x8c0794: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c0798: cmp             SP, x16
    //     0x8c079c: b.ls            #0x8c07f4
    // 0x8c07a0: r16 = Instance__StringStackTrace
    //     0x8c07a0: ldr             x16, [PP, #0x1618]  ; [pp+0x1618] Obj!_StringStackTrace@12b8231
    // 0x8c07a4: cmp             w0, w16
    // 0x8c07a8: b.ne            #0x8c07b0
    // 0x8c07ac: r0 = current()
    //     0x8c07ac: bl              #0x7f0e88  ; [dart:core] StackTrace::current
    // 0x8c07b0: ldur            x1, [fp, #-8]
    // 0x8c07b4: stur            x0, [fp, #-0x18]
    // 0x8c07b8: r2 = 60
    //     0x8c07b8: mov             x2, #0x3c
    // 0x8c07bc: branchIfSmi(r1, 0x8c07c8)
    //     0x8c07bc: tbz             w1, #0, #0x8c07c8
    // 0x8c07c0: r2 = LoadClassIdInstr(r1)
    //     0x8c07c0: ldur            x2, [x1, #-1]
    //     0x8c07c4: ubfx            x2, x2, #0xc, #0x14
    // 0x8c07c8: cmp             x2, #0xae4
    // 0x8c07cc: b.eq            #0x8c07dc
    // 0x8c07d0: mov             x2, x0
    // 0x8c07d4: r0 = throwWithStackTrace()
    //     0x8c07d4: bl              #0x7f11c0  ; [dart:core] Error::throwWithStackTrace
    // 0x8c07d8: brk             #0
    // 0x8c07dc: ldur            x2, [fp, #-0x10]
    // 0x8c07e0: r0 = platformExceptionToFirebaseException()
    //     0x8c07e0: bl              #0x8c07fc  ; [package:_flutterfire_internals/src/exception.dart] ::platformExceptionToFirebaseException
    // 0x8c07e4: mov             x1, x0
    // 0x8c07e8: ldur            x2, [fp, #-0x18]
    // 0x8c07ec: r0 = throwWithStackTrace()
    //     0x8c07ec: bl              #0x7f11c0  ; [dart:core] Error::throwWithStackTrace
    // 0x8c07f0: brk             #0
    // 0x8c07f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c07f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c07f8: b               #0x8c07a0
  }
  static _ platformExceptionToFirebaseException(/* No info */) {
    // ** addr: 0x8c07fc, size: 0x2a0
    // 0x8c07fc: EnterFrame
    //     0x8c07fc: stp             fp, lr, [SP, #-0x10]!
    //     0x8c0800: mov             fp, SP
    // 0x8c0804: AllocStack(0x30)
    //     0x8c0804: sub             SP, SP, #0x30
    // 0x8c0808: SetupParameters(dynamic _ /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x8c0808: mov             x4, x1
    //     0x8c080c: mov             x3, x2
    //     0x8c0810: stur            x1, [fp, #-0x10]
    //     0x8c0814: stur            x2, [fp, #-0x18]
    // 0x8c0818: CheckStackOverflow
    //     0x8c0818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8c081c: cmp             SP, x16
    //     0x8c0820: b.ls            #0x8c0a94
    // 0x8c0824: LoadField: r5 = r4->field_f
    //     0x8c0824: ldur            w5, [x4, #0xf]
    // 0x8c0828: DecompressPointer r5
    //     0x8c0828: add             x5, x5, HEAP, lsl #32
    // 0x8c082c: mov             x0, x5
    // 0x8c0830: stur            x5, [fp, #-8]
    // 0x8c0834: r2 = Null
    //     0x8c0834: mov             x2, NULL
    // 0x8c0838: r1 = Null
    //     0x8c0838: mov             x1, NULL
    // 0x8c083c: cmp             w0, NULL
    // 0x8c0840: b.eq            #0x8c08cc
    // 0x8c0844: branchIfSmi(r0, 0x8c08cc)
    //     0x8c0844: tbz             w0, #0, #0x8c08cc
    // 0x8c0848: r3 = LoadClassIdInstr(r0)
    //     0x8c0848: ldur            x3, [x0, #-1]
    //     0x8c084c: ubfx            x3, x3, #0xc, #0x14
    // 0x8c0850: r17 = 7630
    //     0x8c0850: mov             x17, #0x1dce
    // 0x8c0854: cmp             x3, x17
    // 0x8c0858: b.eq            #0x8c08d4
    // 0x8c085c: r4 = LoadClassIdInstr(r0)
    //     0x8c085c: ldur            x4, [x0, #-1]
    //     0x8c0860: ubfx            x4, x4, #0xc, #0x14
    // 0x8c0864: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x8c0868: ldr             x3, [x3, #0x18]
    // 0x8c086c: ldr             x3, [x3, x4, lsl #3]
    // 0x8c0870: LoadField: r3 = r3->field_2b
    //     0x8c0870: ldur            w3, [x3, #0x2b]
    // 0x8c0874: DecompressPointer r3
    //     0x8c0874: add             x3, x3, HEAP, lsl #32
    // 0x8c0878: cmp             w3, NULL
    // 0x8c087c: b.eq            #0x8c08cc
    // 0x8c0880: LoadField: r3 = r3->field_f
    //     0x8c0880: ldur            w3, [x3, #0xf]
    // 0x8c0884: lsr             x3, x3, #3
    // 0x8c0888: r17 = 7630
    //     0x8c0888: mov             x17, #0x1dce
    // 0x8c088c: cmp             x3, x17
    // 0x8c0890: b.eq            #0x8c08d4
    // 0x8c0894: r3 = SubtypeTestCache
    //     0x8c0894: ldr             x3, [PP, #0x7a88]  ; [pp+0x7a88] SubtypeTestCache
    // 0x8c0898: r30 = Subtype1TestCacheStub
    //     0x8c0898: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x8c089c: LoadField: r30 = r30->field_7
    //     0x8c089c: ldur            lr, [lr, #7]
    // 0x8c08a0: blr             lr
    // 0x8c08a4: cmp             w7, NULL
    // 0x8c08a8: b.eq            #0x8c08b4
    // 0x8c08ac: tbnz            w7, #4, #0x8c08cc
    // 0x8c08b0: b               #0x8c08d4
    // 0x8c08b4: r8 = Map
    //     0x8c08b4: ldr             x8, [PP, #0x7a90]  ; [pp+0x7a90] Type: Map
    // 0x8c08b8: r3 = SubtypeTestCache
    //     0x8c08b8: ldr             x3, [PP, #0x7a98]  ; [pp+0x7a98] SubtypeTestCache
    // 0x8c08bc: r30 = InstanceOfStub
    //     0x8c08bc: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x8c08c0: LoadField: r30 = r30->field_7
    //     0x8c08c0: ldur            lr, [lr, #7]
    // 0x8c08c4: blr             lr
    // 0x8c08c8: b               #0x8c08d8
    // 0x8c08cc: r0 = false
    //     0x8c08cc: add             x0, NULL, #0x30  ; false
    // 0x8c08d0: b               #0x8c08d8
    // 0x8c08d4: r0 = true
    //     0x8c08d4: add             x0, NULL, #0x20  ; true
    // 0x8c08d8: tbnz            w0, #4, #0x8c08f0
    // 0x8c08dc: ldur            x2, [fp, #-8]
    // 0x8c08e0: r1 = <String, Object>
    //     0x8c08e0: ldr             x1, [PP, #0x7aa0]  ; [pp+0x7aa0] TypeArguments: <String, Object>
    // 0x8c08e4: r0 = LinkedHashMap.from()
    //     0x8c08e4: bl              #0x8ac2e4  ; [dart:collection] LinkedHashMap::LinkedHashMap.from
    // 0x8c08e8: mov             x3, x0
    // 0x8c08ec: b               #0x8c08f4
    // 0x8c08f0: r3 = Null
    //     0x8c08f0: mov             x3, NULL
    // 0x8c08f4: ldur            x0, [fp, #-0x10]
    // 0x8c08f8: stur            x3, [fp, #-0x20]
    // 0x8c08fc: LoadField: r1 = r0->field_b
    //     0x8c08fc: ldur            w1, [x0, #0xb]
    // 0x8c0900: DecompressPointer r1
    //     0x8c0900: add             x1, x1, HEAP, lsl #32
    // 0x8c0904: cmp             w1, NULL
    // 0x8c0908: b.ne            #0x8c0914
    // 0x8c090c: r0 = ""
    //     0x8c090c: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x8c0910: b               #0x8c0918
    // 0x8c0914: mov             x0, x1
    // 0x8c0918: stur            x0, [fp, #-0x10]
    // 0x8c091c: cmp             w3, NULL
    // 0x8c0920: b.eq            #0x8c0a08
    // 0x8c0924: mov             x1, x3
    // 0x8c0928: r2 = "code"
    //     0x8c0928: ldr             x2, [PP, #0x4070]  ; [pp+0x4070] "code"
    // 0x8c092c: r0 = _getValueOrData()
    //     0x8c092c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c0930: ldur            x3, [fp, #-0x20]
    // 0x8c0934: LoadField: r1 = r3->field_f
    //     0x8c0934: ldur            w1, [x3, #0xf]
    // 0x8c0938: DecompressPointer r1
    //     0x8c0938: add             x1, x1, HEAP, lsl #32
    // 0x8c093c: cmp             w1, w0
    // 0x8c0940: b.ne            #0x8c094c
    // 0x8c0944: r4 = Null
    //     0x8c0944: mov             x4, NULL
    // 0x8c0948: b               #0x8c0950
    // 0x8c094c: mov             x4, x0
    // 0x8c0950: mov             x0, x4
    // 0x8c0954: stur            x4, [fp, #-0x28]
    // 0x8c0958: r2 = Null
    //     0x8c0958: mov             x2, NULL
    // 0x8c095c: r1 = Null
    //     0x8c095c: mov             x1, NULL
    // 0x8c0960: r4 = 60
    //     0x8c0960: mov             x4, #0x3c
    // 0x8c0964: branchIfSmi(r0, 0x8c0970)
    //     0x8c0964: tbz             w0, #0, #0x8c0970
    // 0x8c0968: r4 = LoadClassIdInstr(r0)
    //     0x8c0968: ldur            x4, [x0, #-1]
    //     0x8c096c: ubfx            x4, x4, #0xc, #0x14
    // 0x8c0970: sub             x4, x4, #0x5e
    // 0x8c0974: cmp             x4, #1
    // 0x8c0978: b.ls            #0x8c0988
    // 0x8c097c: r8 = String?
    //     0x8c097c: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x8c0980: r3 = Null
    //     0x8c0980: ldr             x3, [PP, #0x7aa8]  ; [pp+0x7aa8] Null
    // 0x8c0984: r0 = String?()
    //     0x8c0984: bl              #0x7db310  ; IsType_String?_Stub
    // 0x8c0988: ldur            x1, [fp, #-0x20]
    // 0x8c098c: r2 = "message"
    //     0x8c098c: ldr             x2, [PP, #0x62a0]  ; [pp+0x62a0] "message"
    // 0x8c0990: r0 = _getValueOrData()
    //     0x8c0990: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8c0994: mov             x1, x0
    // 0x8c0998: ldur            x0, [fp, #-0x20]
    // 0x8c099c: LoadField: r2 = r0->field_f
    //     0x8c099c: ldur            w2, [x0, #0xf]
    // 0x8c09a0: DecompressPointer r2
    //     0x8c09a0: add             x2, x2, HEAP, lsl #32
    // 0x8c09a4: cmp             w2, w1
    // 0x8c09a8: b.ne            #0x8c09b4
    // 0x8c09ac: r3 = Null
    //     0x8c09ac: mov             x3, NULL
    // 0x8c09b0: b               #0x8c09b8
    // 0x8c09b4: mov             x3, x1
    // 0x8c09b8: mov             x0, x3
    // 0x8c09bc: stur            x3, [fp, #-0x20]
    // 0x8c09c0: r2 = Null
    //     0x8c09c0: mov             x2, NULL
    // 0x8c09c4: r1 = Null
    //     0x8c09c4: mov             x1, NULL
    // 0x8c09c8: r4 = 60
    //     0x8c09c8: mov             x4, #0x3c
    // 0x8c09cc: branchIfSmi(r0, 0x8c09d8)
    //     0x8c09cc: tbz             w0, #0, #0x8c09d8
    // 0x8c09d0: r4 = LoadClassIdInstr(r0)
    //     0x8c09d0: ldur            x4, [x0, #-1]
    //     0x8c09d4: ubfx            x4, x4, #0xc, #0x14
    // 0x8c09d8: sub             x4, x4, #0x5e
    // 0x8c09dc: cmp             x4, #1
    // 0x8c09e0: b.ls            #0x8c09f0
    // 0x8c09e4: r8 = String?
    //     0x8c09e4: ldr             x8, [PP, #0x100]  ; [pp+0x100] Type: String?
    // 0x8c09e8: r3 = Null
    //     0x8c09e8: ldr             x3, [PP, #0x7ab8]  ; [pp+0x7ab8] Null
    // 0x8c09ec: r0 = String?()
    //     0x8c09ec: bl              #0x7db310  ; IsType_String?_Stub
    // 0x8c09f0: ldur            x0, [fp, #-0x20]
    // 0x8c09f4: cmp             w0, NULL
    // 0x8c09f8: b.ne            #0x8c0a00
    // 0x8c09fc: ldur            x0, [fp, #-0x10]
    // 0x8c0a00: ldur            x1, [fp, #-0x28]
    // 0x8c0a04: b               #0x8c0a4c
    // 0x8c0a08: ldur            x0, [fp, #-8]
    // 0x8c0a0c: cmp             w0, NULL
    // 0x8c0a10: b.eq            #0x8c0a44
    // 0x8c0a14: r1 = 60
    //     0x8c0a14: mov             x1, #0x3c
    // 0x8c0a18: branchIfSmi(r0, 0x8c0a24)
    //     0x8c0a18: tbz             w0, #0, #0x8c0a24
    // 0x8c0a1c: r1 = LoadClassIdInstr(r0)
    //     0x8c0a1c: ldur            x1, [x0, #-1]
    //     0x8c0a20: ubfx            x1, x1, #0xc, #0x14
    // 0x8c0a24: str             x0, [SP]
    // 0x8c0a28: mov             x0, x1
    // 0x8c0a2c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8c0a2c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8c0a30: r0 = GDT[cid_x0 + 0x91c1]()
    //     0x8c0a30: mov             x17, #0x91c1
    //     0x8c0a34: add             lr, x0, x17
    //     0x8c0a38: ldr             lr, [x21, lr, lsl #3]
    //     0x8c0a3c: blr             lr
    // 0x8c0a40: b               #0x8c0a48
    // 0x8c0a44: ldur            x0, [fp, #-0x10]
    // 0x8c0a48: r1 = Null
    //     0x8c0a48: mov             x1, NULL
    // 0x8c0a4c: stur            x0, [fp, #-0x10]
    // 0x8c0a50: cmp             w1, NULL
    // 0x8c0a54: b.ne            #0x8c0a60
    // 0x8c0a58: r2 = "unknown"
    //     0x8c0a58: ldr             x2, [PP, #0x7ac8]  ; [pp+0x7ac8] "unknown"
    // 0x8c0a5c: b               #0x8c0a64
    // 0x8c0a60: mov             x2, x1
    // 0x8c0a64: ldur            x1, [fp, #-0x18]
    // 0x8c0a68: stur            x2, [fp, #-8]
    // 0x8c0a6c: r0 = FirebaseException()
    //     0x8c0a6c: bl              #0x8c0a9c  ; AllocateFirebaseExceptionStub -> FirebaseException (size=0x18)
    // 0x8c0a70: ldur            x1, [fp, #-0x18]
    // 0x8c0a74: StoreField: r0->field_7 = r1
    //     0x8c0a74: stur            w1, [x0, #7]
    // 0x8c0a78: ldur            x1, [fp, #-0x10]
    // 0x8c0a7c: StoreField: r0->field_b = r1
    //     0x8c0a7c: stur            w1, [x0, #0xb]
    // 0x8c0a80: ldur            x1, [fp, #-8]
    // 0x8c0a84: StoreField: r0->field_f = r1
    //     0x8c0a84: stur            w1, [x0, #0xf]
    // 0x8c0a88: LeaveFrame
    //     0x8c0a88: mov             SP, fp
    //     0x8c0a8c: ldp             fp, lr, [SP], #0x10
    // 0x8c0a90: ret
    //     0x8c0a90: ret             
    // 0x8c0a94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8c0a94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8c0a98: b               #0x8c0824
  }
}
