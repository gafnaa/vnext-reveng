// lib: , url: package:flutter/src/rendering/table.dart

// class id: 1049050, size: 0x8
class :: {
}

// class id: 2845, size: 0x18, field offset: 0x8
//   const constructor, 
class _Index extends Object {

  _ ==(/* No info */) {
    // ** addr: 0x129a3bc, size: 0x80
    // 0x129a3bc: ldr             x1, [SP]
    // 0x129a3c0: cmp             w1, NULL
    // 0x129a3c4: b.ne            #0x129a3d0
    // 0x129a3c8: r0 = false
    //     0x129a3c8: add             x0, NULL, #0x30  ; false
    // 0x129a3cc: ret
    //     0x129a3cc: ret             
    // 0x129a3d0: ldr             x2, [SP, #8]
    // 0x129a3d4: cmp             w2, w1
    // 0x129a3d8: b.ne            #0x129a3e4
    // 0x129a3dc: r0 = true
    //     0x129a3dc: add             x0, NULL, #0x20  ; true
    // 0x129a3e0: ret
    //     0x129a3e0: ret             
    // 0x129a3e4: r3 = 60
    //     0x129a3e4: mov             x3, #0x3c
    // 0x129a3e8: branchIfSmi(r1, 0x129a3f4)
    //     0x129a3e8: tbz             w1, #0, #0x129a3f4
    // 0x129a3ec: r3 = LoadClassIdInstr(r1)
    //     0x129a3ec: ldur            x3, [x1, #-1]
    //     0x129a3f0: ubfx            x3, x3, #0xc, #0x14
    // 0x129a3f4: cmp             x3, #0xb1d
    // 0x129a3f8: b.eq            #0x129a404
    // 0x129a3fc: r0 = false
    //     0x129a3fc: add             x0, NULL, #0x30  ; false
    // 0x129a400: ret
    //     0x129a400: ret             
    // 0x129a404: LoadField: r3 = r2->field_7
    //     0x129a404: ldur            x3, [x2, #7]
    // 0x129a408: LoadField: r4 = r1->field_7
    //     0x129a408: ldur            x4, [x1, #7]
    // 0x129a40c: cmp             x3, x4
    // 0x129a410: b.ne            #0x129a434
    // 0x129a414: LoadField: r3 = r2->field_f
    //     0x129a414: ldur            x3, [x2, #0xf]
    // 0x129a418: LoadField: r2 = r1->field_f
    //     0x129a418: ldur            x2, [x1, #0xf]
    // 0x129a41c: cmp             x3, x2
    // 0x129a420: r16 = true
    //     0x129a420: add             x16, NULL, #0x20  ; true
    // 0x129a424: r17 = false
    //     0x129a424: add             x17, NULL, #0x30  ; false
    // 0x129a428: csel            x1, x16, x17, eq
    // 0x129a42c: mov             x0, x1
    // 0x129a430: b               #0x129a438
    // 0x129a434: r0 = false
    //     0x129a434: add             x0, NULL, #0x30  ; false
    // 0x129a438: ret
    //     0x129a438: ret             
  }
}

// class id: 3111, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TableColumnWidth extends Object {
}

// class id: 3112, size: 0x10, field offset: 0x8
//   const constructor, 
class FlexColumnWidth extends TableColumnWidth {

  _Double field_8;
}

// class id: 3114, size: 0xc, field offset: 0x8
//   const constructor, 
class IntrinsicColumnWidth extends TableColumnWidth {

  _Double field_8;

  _ minIntrinsicWidth(/* No info */) {
    // ** addr: 0x12ff7cc, size: 0x174
    // 0x12ff7cc: EnterFrame
    //     0x12ff7cc: stp             fp, lr, [SP, #-0x10]!
    //     0x12ff7d0: mov             fp, SP
    // 0x12ff7d4: AllocStack(0x48)
    //     0x12ff7d4: sub             SP, SP, #0x48
    // 0x12ff7d8: SetupParameters(IntrinsicColumnWidth this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x12ff7d8: mov             x0, x1
    //     0x12ff7dc: mov             x1, x2
    // 0x12ff7e0: CheckStackOverflow
    //     0x12ff7e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ff7e4: cmp             SP, x16
    //     0x12ff7e8: b.ls            #0x12ff920
    // 0x12ff7ec: r0 = iterator()
    //     0x12ff7ec: bl              #0xb099a4  ; [dart:async] _SyncStarIterable::iterator
    // 0x12ff7f0: stur            x0, [fp, #-0x10]
    // 0x12ff7f4: LoadField: r2 = r0->field_7
    //     0x12ff7f4: ldur            w2, [x0, #7]
    // 0x12ff7f8: DecompressPointer r2
    //     0x12ff7f8: add             x2, x2, HEAP, lsl #32
    // 0x12ff7fc: stur            x2, [fp, #-8]
    // 0x12ff800: d0 = 0.000000
    //     0x12ff800: eor             v0.16b, v0.16b, v0.16b
    // 0x12ff804: stur            d0, [fp, #-0x20]
    // 0x12ff808: CheckStackOverflow
    //     0x12ff808: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ff80c: cmp             SP, x16
    //     0x12ff810: b.ls            #0x12ff928
    // 0x12ff814: mov             x1, x0
    // 0x12ff818: r0 = moveNext()
    //     0x12ff818: bl              #0x801acc  ; [dart:async] _SyncStarIterator::moveNext
    // 0x12ff81c: tbnz            w0, #4, #0x12ff8e4
    // 0x12ff820: ldur            x3, [fp, #-0x10]
    // 0x12ff824: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x12ff824: ldur            w4, [x3, #0x17]
    // 0x12ff828: DecompressPointer r4
    //     0x12ff828: add             x4, x4, HEAP, lsl #32
    // 0x12ff82c: stur            x4, [fp, #-0x18]
    // 0x12ff830: cmp             w4, NULL
    // 0x12ff834: b.ne            #0x12ff868
    // 0x12ff838: mov             x0, x4
    // 0x12ff83c: ldur            x2, [fp, #-8]
    // 0x12ff840: r1 = Null
    //     0x12ff840: mov             x1, NULL
    // 0x12ff844: cmp             w2, NULL
    // 0x12ff848: b.eq            #0x12ff868
    // 0x12ff84c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12ff84c: ldur            w4, [x2, #0x17]
    // 0x12ff850: DecompressPointer r4
    //     0x12ff850: add             x4, x4, HEAP, lsl #32
    // 0x12ff854: r8 = X0
    //     0x12ff854: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12ff858: LoadField: r9 = r4->field_7
    //     0x12ff858: ldur            x9, [x4, #7]
    // 0x12ff85c: r3 = Null
    //     0x12ff85c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab4a8] Null
    //     0x12ff860: ldr             x3, [x3, #0x4a8]
    // 0x12ff864: blr             x9
    // 0x12ff868: ldur            d0, [fp, #-0x20]
    // 0x12ff86c: ldur            x1, [fp, #-0x18]
    // 0x12ff870: r0 = 60
    //     0x12ff870: mov             x0, #0x3c
    // 0x12ff874: branchIfSmi(r1, 0x12ff880)
    //     0x12ff874: tbz             w1, #0, #0x12ff880
    // 0x12ff878: r0 = LoadClassIdInstr(r1)
    //     0x12ff878: ldur            x0, [x1, #-1]
    //     0x12ff87c: ubfx            x0, x0, #0xc, #0x14
    // 0x12ff880: str             x1, [SP]
    // 0x12ff884: r0 = GDT[cid_x0 + 0x12f2c]()
    //     0x12ff884: mov             x17, #0x2f2c
    //     0x12ff888: movk            x17, #1, lsl #16
    //     0x12ff88c: add             lr, x0, x17
    //     0x12ff890: ldr             lr, [x21, lr, lsl #3]
    //     0x12ff894: blr             lr
    // 0x12ff898: r16 = <double, double>
    //     0x12ff898: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0x12ff89c: ldr             x16, [x16, #0x228]
    // 0x12ff8a0: ldur            lr, [fp, #-0x18]
    // 0x12ff8a4: stp             lr, x16, [SP, #0x18]
    // 0x12ff8a8: r16 = Instance__IntrinsicDimension
    //     0x12ff8a8: add             x16, PP, #0x98, lsl #12  ; [pp+0x98a78] Obj!_IntrinsicDimension@12c4681
    //     0x12ff8ac: ldr             x16, [x16, #0xa78]
    // 0x12ff8b0: r30 = inf
    //     0x12ff8b0: add             lr, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0x12ff8b4: ldr             lr, [lr, #0x8a8]
    // 0x12ff8b8: stp             lr, x16, [SP, #8]
    // 0x12ff8bc: str             x0, [SP]
    // 0x12ff8c0: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0x12ff8c0: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0x12ff8c4: r0 = _computeIntrinsics()
    //     0x12ff8c4: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0x12ff8c8: LoadField: d0 = r0->field_7
    //     0x12ff8c8: ldur            d0, [x0, #7]
    // 0x12ff8cc: ldur            d1, [fp, #-0x20]
    // 0x12ff8d0: fmax            v2.2d, v1.2d, v0.2d
    // 0x12ff8d4: mov             v0.16b, v2.16b
    // 0x12ff8d8: ldur            x0, [fp, #-0x10]
    // 0x12ff8dc: ldur            x2, [fp, #-8]
    // 0x12ff8e0: b               #0x12ff804
    // 0x12ff8e4: ldur            d1, [fp, #-0x20]
    // 0x12ff8e8: r0 = inline_Allocate_Double()
    //     0x12ff8e8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12ff8ec: add             x0, x0, #0x10
    //     0x12ff8f0: cmp             x1, x0
    //     0x12ff8f4: b.ls            #0x12ff930
    //     0x12ff8f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x12ff8fc: sub             x0, x0, #0xf
    //     0x12ff900: mov             x1, #0xe19c
    //     0x12ff904: movk            x1, #3, lsl #16
    //     0x12ff908: stur            x1, [x0, #-1]
    // 0x12ff90c: dmb             ishst
    // 0x12ff910: StoreField: r0->field_7 = d1
    //     0x12ff910: stur            d1, [x0, #7]
    // 0x12ff914: LeaveFrame
    //     0x12ff914: mov             SP, fp
    //     0x12ff918: ldp             fp, lr, [SP], #0x10
    // 0x12ff91c: ret
    //     0x12ff91c: ret             
    // 0x12ff920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ff920: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ff924: b               #0x12ff7ec
    // 0x12ff928: r0 = StackOverflowSharedWithFPURegs()
    //     0x12ff928: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12ff92c: b               #0x12ff814
    // 0x12ff930: SaveReg d1
    //     0x12ff930: str             q1, [SP, #-0x10]!
    // 0x12ff934: r0 = AllocateDouble()
    //     0x12ff934: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12ff938: RestoreReg d1
    //     0x12ff938: ldr             q1, [SP], #0x10
    // 0x12ff93c: b               #0x12ff910
  }
  _ maxIntrinsicWidth(/* No info */) {
    // ** addr: 0x12ff940, size: 0x174
    // 0x12ff940: EnterFrame
    //     0x12ff940: stp             fp, lr, [SP, #-0x10]!
    //     0x12ff944: mov             fp, SP
    // 0x12ff948: AllocStack(0x48)
    //     0x12ff948: sub             SP, SP, #0x48
    // 0x12ff94c: SetupParameters(IntrinsicColumnWidth this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x12ff94c: mov             x0, x1
    //     0x12ff950: mov             x1, x2
    // 0x12ff954: CheckStackOverflow
    //     0x12ff954: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ff958: cmp             SP, x16
    //     0x12ff95c: b.ls            #0x12ffa94
    // 0x12ff960: r0 = iterator()
    //     0x12ff960: bl              #0xb099a4  ; [dart:async] _SyncStarIterable::iterator
    // 0x12ff964: stur            x0, [fp, #-0x10]
    // 0x12ff968: LoadField: r2 = r0->field_7
    //     0x12ff968: ldur            w2, [x0, #7]
    // 0x12ff96c: DecompressPointer r2
    //     0x12ff96c: add             x2, x2, HEAP, lsl #32
    // 0x12ff970: stur            x2, [fp, #-8]
    // 0x12ff974: d0 = 0.000000
    //     0x12ff974: eor             v0.16b, v0.16b, v0.16b
    // 0x12ff978: stur            d0, [fp, #-0x20]
    // 0x12ff97c: CheckStackOverflow
    //     0x12ff97c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12ff980: cmp             SP, x16
    //     0x12ff984: b.ls            #0x12ffa9c
    // 0x12ff988: mov             x1, x0
    // 0x12ff98c: r0 = moveNext()
    //     0x12ff98c: bl              #0x801acc  ; [dart:async] _SyncStarIterator::moveNext
    // 0x12ff990: tbnz            w0, #4, #0x12ffa58
    // 0x12ff994: ldur            x3, [fp, #-0x10]
    // 0x12ff998: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x12ff998: ldur            w4, [x3, #0x17]
    // 0x12ff99c: DecompressPointer r4
    //     0x12ff99c: add             x4, x4, HEAP, lsl #32
    // 0x12ff9a0: stur            x4, [fp, #-0x18]
    // 0x12ff9a4: cmp             w4, NULL
    // 0x12ff9a8: b.ne            #0x12ff9dc
    // 0x12ff9ac: mov             x0, x4
    // 0x12ff9b0: ldur            x2, [fp, #-8]
    // 0x12ff9b4: r1 = Null
    //     0x12ff9b4: mov             x1, NULL
    // 0x12ff9b8: cmp             w2, NULL
    // 0x12ff9bc: b.eq            #0x12ff9dc
    // 0x12ff9c0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x12ff9c0: ldur            w4, [x2, #0x17]
    // 0x12ff9c4: DecompressPointer r4
    //     0x12ff9c4: add             x4, x4, HEAP, lsl #32
    // 0x12ff9c8: r8 = X0
    //     0x12ff9c8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x12ff9cc: LoadField: r9 = r4->field_7
    //     0x12ff9cc: ldur            x9, [x4, #7]
    // 0x12ff9d0: r3 = Null
    //     0x12ff9d0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab498] Null
    //     0x12ff9d4: ldr             x3, [x3, #0x498]
    // 0x12ff9d8: blr             x9
    // 0x12ff9dc: ldur            d0, [fp, #-0x20]
    // 0x12ff9e0: ldur            x1, [fp, #-0x18]
    // 0x12ff9e4: r0 = 60
    //     0x12ff9e4: mov             x0, #0x3c
    // 0x12ff9e8: branchIfSmi(r1, 0x12ff9f4)
    //     0x12ff9e8: tbz             w1, #0, #0x12ff9f4
    // 0x12ff9ec: r0 = LoadClassIdInstr(r1)
    //     0x12ff9ec: ldur            x0, [x1, #-1]
    //     0x12ff9f0: ubfx            x0, x0, #0xc, #0x14
    // 0x12ff9f4: str             x1, [SP]
    // 0x12ff9f8: r0 = GDT[cid_x0 + 0x12498]()
    //     0x12ff9f8: mov             x17, #0x2498
    //     0x12ff9fc: movk            x17, #1, lsl #16
    //     0x12ffa00: add             lr, x0, x17
    //     0x12ffa04: ldr             lr, [x21, lr, lsl #3]
    //     0x12ffa08: blr             lr
    // 0x12ffa0c: r16 = <double, double>
    //     0x12ffa0c: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0x12ffa10: ldr             x16, [x16, #0x228]
    // 0x12ffa14: ldur            lr, [fp, #-0x18]
    // 0x12ffa18: stp             lr, x16, [SP, #0x18]
    // 0x12ffa1c: r16 = Instance__IntrinsicDimension
    //     0x12ffa1c: add             x16, PP, #0x96, lsl #12  ; [pp+0x969d8] Obj!_IntrinsicDimension@12c46a1
    //     0x12ffa20: ldr             x16, [x16, #0x9d8]
    // 0x12ffa24: r30 = inf
    //     0x12ffa24: add             lr, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0x12ffa28: ldr             lr, [lr, #0x8a8]
    // 0x12ffa2c: stp             lr, x16, [SP, #8]
    // 0x12ffa30: str             x0, [SP]
    // 0x12ffa34: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0x12ffa34: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0x12ffa38: r0 = _computeIntrinsics()
    //     0x12ffa38: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0x12ffa3c: LoadField: d0 = r0->field_7
    //     0x12ffa3c: ldur            d0, [x0, #7]
    // 0x12ffa40: ldur            d1, [fp, #-0x20]
    // 0x12ffa44: fmax            v2.2d, v1.2d, v0.2d
    // 0x12ffa48: mov             v0.16b, v2.16b
    // 0x12ffa4c: ldur            x0, [fp, #-0x10]
    // 0x12ffa50: ldur            x2, [fp, #-8]
    // 0x12ffa54: b               #0x12ff978
    // 0x12ffa58: ldur            d1, [fp, #-0x20]
    // 0x12ffa5c: r0 = inline_Allocate_Double()
    //     0x12ffa5c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x12ffa60: add             x0, x0, #0x10
    //     0x12ffa64: cmp             x1, x0
    //     0x12ffa68: b.ls            #0x12ffaa4
    //     0x12ffa6c: str             x0, [THR, #0x60]  ; THR::top
    //     0x12ffa70: sub             x0, x0, #0xf
    //     0x12ffa74: mov             x1, #0xe19c
    //     0x12ffa78: movk            x1, #3, lsl #16
    //     0x12ffa7c: stur            x1, [x0, #-1]
    // 0x12ffa80: dmb             ishst
    // 0x12ffa84: StoreField: r0->field_7 = d1
    //     0x12ffa84: stur            d1, [x0, #7]
    // 0x12ffa88: LeaveFrame
    //     0x12ffa88: mov             SP, fp
    //     0x12ffa8c: ldp             fp, lr, [SP], #0x10
    // 0x12ffa90: ret
    //     0x12ffa90: ret             
    // 0x12ffa94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12ffa94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12ffa98: b               #0x12ff960
    // 0x12ffa9c: r0 = StackOverflowSharedWithFPURegs()
    //     0x12ffa9c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x12ffaa0: b               #0x12ff988
    // 0x12ffaa4: SaveReg d1
    //     0x12ffaa4: str             q1, [SP, #-0x10]!
    // 0x12ffaa8: r0 = AllocateDouble()
    //     0x12ffaa8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x12ffaac: RestoreReg d1
    //     0x12ffaac: ldr             q1, [SP], #0x10
    // 0x12ffab0: b               #0x12ffa84
  }
}

// class id: 4191, size: 0x14, field offset: 0xc
class TableCellParentData extends BoxParentData {
}

// class id: 4723, size: 0xa4, field offset: 0x50
class RenderTable extends RenderBox {

  late double _tableWidth; // offset: 0xa0

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb21668, size: 0x24
    // 0xb21668: EnterFrame
    //     0xb21668: stp             fp, lr, [SP, #-0x10]!
    //     0xb2166c: mov             fp, SP
    // 0xb21670: ldr             x2, [fp, #0x10]
    // 0xb21674: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb21674: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa11f8] AnonymousClosure: (0xb2168c), in [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicWidth (0xb21704)
    //     0xb21678: ldr             x1, [x1, #0x1f8]
    // 0xb2167c: r0 = AllocateClosure()
    //     0xb2167c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb21680: LeaveFrame
    //     0xb21680: mov             SP, fp
    //     0xb21684: ldp             fp, lr, [SP], #0x10
    // 0xb21688: ret
    //     0xb21688: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2168c, size: 0x78
    // 0xb2168c: EnterFrame
    //     0xb2168c: stp             fp, lr, [SP, #-0x10]!
    //     0xb21690: mov             fp, SP
    // 0xb21694: ldr             x0, [fp, #0x18]
    // 0xb21698: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb21698: ldur            w1, [x0, #0x17]
    // 0xb2169c: DecompressPointer r1
    //     0xb2169c: add             x1, x1, HEAP, lsl #32
    // 0xb216a0: CheckStackOverflow
    //     0xb216a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb216a4: cmp             SP, x16
    //     0xb216a8: b.ls            #0xb216ec
    // 0xb216ac: ldr             x2, [fp, #0x10]
    // 0xb216b0: r0 = computeMinIntrinsicWidth()
    //     0xb216b0: bl              #0xb21704  ; [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicWidth
    // 0xb216b4: r0 = inline_Allocate_Double()
    //     0xb216b4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb216b8: add             x0, x0, #0x10
    //     0xb216bc: cmp             x1, x0
    //     0xb216c0: b.ls            #0xb216f4
    //     0xb216c4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb216c8: sub             x0, x0, #0xf
    //     0xb216cc: mov             x1, #0xe19c
    //     0xb216d0: movk            x1, #3, lsl #16
    //     0xb216d4: stur            x1, [x0, #-1]
    // 0xb216d8: dmb             ishst
    // 0xb216dc: StoreField: r0->field_7 = d0
    //     0xb216dc: stur            d0, [x0, #7]
    // 0xb216e0: LeaveFrame
    //     0xb216e0: mov             SP, fp
    //     0xb216e4: ldp             fp, lr, [SP], #0x10
    // 0xb216e8: ret
    //     0xb216e8: ret             
    // 0xb216ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb216ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb216f0: b               #0xb216ac
    // 0xb216f4: SaveReg d0
    //     0xb216f4: str             q0, [SP, #-0x10]!
    // 0xb216f8: r0 = AllocateDouble()
    //     0xb216f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb216fc: RestoreReg d0
    //     0xb216fc: ldr             q0, [SP], #0x10
    // 0xb21700: b               #0xb216dc
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb21704, size: 0x15c
    // 0xb21704: EnterFrame
    //     0xb21704: stp             fp, lr, [SP, #-0x10]!
    //     0xb21708: mov             fp, SP
    // 0xb2170c: AllocStack(0x38)
    //     0xb2170c: sub             SP, SP, #0x38
    // 0xb21710: SetupParameters(RenderTable this /* r1 => r3, fp-0x20 */)
    //     0xb21710: mov             x3, x1
    //     0xb21714: stur            x1, [fp, #-0x20]
    // 0xb21718: CheckStackOverflow
    //     0xb21718: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2171c: cmp             SP, x16
    //     0xb21720: b.ls            #0xb21850
    // 0xb21724: LoadField: r0 = r3->field_5b
    //     0xb21724: ldur            x0, [x3, #0x5b]
    // 0xb21728: LoadField: r1 = r3->field_53
    //     0xb21728: ldur            x1, [x3, #0x53]
    // 0xb2172c: mul             x2, x0, x1
    // 0xb21730: cbnz            x2, #0xb21744
    // 0xb21734: d0 = 0.000000
    //     0xb21734: eor             v0.16b, v0.16b, v0.16b
    // 0xb21738: LeaveFrame
    //     0xb21738: mov             SP, fp
    //     0xb2173c: ldp             fp, lr, [SP], #0x10
    // 0xb21740: ret
    //     0xb21740: ret             
    // 0xb21744: d0 = 0.000000
    //     0xb21744: eor             v0.16b, v0.16b, v0.16b
    // 0xb21748: r4 = 0
    //     0xb21748: mov             x4, #0
    // 0xb2174c: stur            x4, [fp, #-0x18]
    // 0xb21750: stur            d0, [fp, #-0x28]
    // 0xb21754: CheckStackOverflow
    //     0xb21754: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21758: cmp             SP, x16
    //     0xb2175c: b.ls            #0xb21858
    // 0xb21760: LoadField: r0 = r3->field_53
    //     0xb21760: ldur            x0, [x3, #0x53]
    // 0xb21764: cmp             x4, x0
    // 0xb21768: b.ge            #0xb21844
    // 0xb2176c: LoadField: r5 = r3->field_63
    //     0xb2176c: ldur            w5, [x3, #0x63]
    // 0xb21770: DecompressPointer r5
    //     0xb21770: add             x5, x5, HEAP, lsl #32
    // 0xb21774: stur            x5, [fp, #-0x10]
    // 0xb21778: r0 = BoxInt64Instr(r4)
    //     0xb21778: sbfiz           x0, x4, #1, #0x1f
    //     0xb2177c: cmp             x4, x0, asr #1
    //     0xb21780: b.eq            #0xb2178c
    //     0xb21784: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb21788: stur            x4, [x0, #7]
    // 0xb2178c: mov             x1, x5
    // 0xb21790: mov             x2, x0
    // 0xb21794: stur            x0, [fp, #-8]
    // 0xb21798: r0 = containsKey()
    //     0xb21798: bl              #0x1259498  ; [dart:_internal] ListMapView::containsKey
    // 0xb2179c: tbnz            w0, #4, #0xb217cc
    // 0xb217a0: ldur            x0, [fp, #-0x10]
    // 0xb217a4: LoadField: r1 = r0->field_b
    //     0xb217a4: ldur            w1, [x0, #0xb]
    // 0xb217a8: DecompressPointer r1
    //     0xb217a8: add             x1, x1, HEAP, lsl #32
    // 0xb217ac: r0 = LoadClassIdInstr(r1)
    //     0xb217ac: ldur            x0, [x1, #-1]
    //     0xb217b0: ubfx            x0, x0, #0xc, #0x14
    // 0xb217b4: ldur            x16, [fp, #-8]
    // 0xb217b8: stp             x16, x1, [SP]
    // 0xb217bc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb217bc: sub             lr, x0, #0xdfd
    //     0xb217c0: ldr             lr, [x21, lr, lsl #3]
    //     0xb217c4: blr             lr
    // 0xb217c8: b               #0xb217d0
    // 0xb217cc: r0 = Null
    //     0xb217cc: mov             x0, NULL
    // 0xb217d0: cmp             w0, NULL
    // 0xb217d4: b.ne            #0xb217e4
    // 0xb217d8: r3 = Instance_FlexColumnWidth
    //     0xb217d8: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8ffc8] Obj!FlexColumnWidth@129ede1
    //     0xb217dc: ldr             x3, [x3, #0xfc8]
    // 0xb217e0: b               #0xb217e8
    // 0xb217e4: mov             x3, x0
    // 0xb217e8: ldur            d0, [fp, #-0x28]
    // 0xb217ec: ldur            x0, [fp, #-0x18]
    // 0xb217f0: ldur            x1, [fp, #-0x20]
    // 0xb217f4: mov             x2, x0
    // 0xb217f8: stur            x3, [fp, #-8]
    // 0xb217fc: r0 = column()
    //     0xb217fc: bl              #0xb21a00  ; [package:flutter/src/rendering/table.dart] RenderTable::column
    // 0xb21800: ldur            x1, [fp, #-8]
    // 0xb21804: r2 = LoadClassIdInstr(r1)
    //     0xb21804: ldur            x2, [x1, #-1]
    //     0xb21808: ubfx            x2, x2, #0xc, #0x14
    // 0xb2180c: mov             x16, x0
    // 0xb21810: mov             x0, x2
    // 0xb21814: mov             x2, x16
    // 0xb21818: r0 = GDT[cid_x0 + -0xffc]()
    //     0xb21818: sub             lr, x0, #0xffc
    //     0xb2181c: ldr             lr, [x21, lr, lsl #3]
    //     0xb21820: blr             lr
    // 0xb21824: LoadField: d1 = r0->field_7
    //     0xb21824: ldur            d1, [x0, #7]
    // 0xb21828: ldur            d0, [fp, #-0x28]
    // 0xb2182c: fadd            d2, d0, d1
    // 0xb21830: ldur            x0, [fp, #-0x18]
    // 0xb21834: add             x4, x0, #1
    // 0xb21838: mov             v0.16b, v2.16b
    // 0xb2183c: ldur            x3, [fp, #-0x20]
    // 0xb21840: b               #0xb2174c
    // 0xb21844: LeaveFrame
    //     0xb21844: mov             SP, fp
    //     0xb21848: ldp             fp, lr, [SP], #0x10
    // 0xb2184c: ret
    //     0xb2184c: ret             
    // 0xb21850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21854: b               #0xb21724
    // 0xb21858: r0 = StackOverflowSharedWithFPURegs()
    //     0xb21858: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2185c: b               #0xb21760
  }
  _ column(/* No info */) {
    // ** addr: 0xb21a00, size: 0x114
    // 0xb21a00: EnterFrame
    //     0xb21a00: stp             fp, lr, [SP, #-0x10]!
    //     0xb21a04: mov             fp, SP
    // 0xb21a08: AllocStack(0x30)
    //     0xb21a08: sub             SP, SP, #0x30
    // 0xb21a0c: SetupParameters(RenderTable this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xb21a0c: stur            NULL, [fp, #-8]
    //     0xb21a10: stur            x1, [fp, #-0x10]
    //     0xb21a14: stur            x2, [fp, #-0x18]
    // 0xb21a18: CheckStackOverflow
    //     0xb21a18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21a1c: cmp             SP, x16
    //     0xb21a20: b.ls            #0xb21b04
    // 0xb21a24: r0 = <RenderBox>
    //     0xb21a24: add             x0, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xb21a28: ldr             x0, [x0, #0x5c8]
    // 0xb21a2c: r0 = InitSyncStar()
    //     0xb21a2c: bl              #0x861bac  ; InitSyncStarStub
    // 0xb21a30: r0 = Null
    //     0xb21a30: mov             x0, NULL
    // 0xb21a34: r0 = SuspendSyncStarAtStart()
    //     0xb21a34: bl              #0x861a20  ; SuspendSyncStarAtStartStub
    // 0xb21a38: r4 = 0
    //     0xb21a38: mov             x4, #0
    // 0xb21a3c: ldur            x3, [fp, #-0x10]
    // 0xb21a40: ldur            x2, [fp, #-0x18]
    // 0xb21a44: stur            x4, [fp, #-0x20]
    // 0xb21a48: CheckStackOverflow
    //     0xb21a48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21a4c: cmp             SP, x16
    //     0xb21a50: b.ls            #0xb21b0c
    // 0xb21a54: LoadField: r0 = r3->field_5b
    //     0xb21a54: ldur            x0, [x3, #0x5b]
    // 0xb21a58: cmp             x4, x0
    // 0xb21a5c: b.ge            #0xb21af4
    // 0xb21a60: LoadField: r0 = r3->field_53
    //     0xb21a60: ldur            x0, [x3, #0x53]
    // 0xb21a64: mul             x1, x4, x0
    // 0xb21a68: add             x5, x2, x1
    // 0xb21a6c: LoadField: r6 = r3->field_4f
    //     0xb21a6c: ldur            w6, [x3, #0x4f]
    // 0xb21a70: DecompressPointer r6
    //     0xb21a70: add             x6, x6, HEAP, lsl #32
    // 0xb21a74: r0 = BoxInt64Instr(r5)
    //     0xb21a74: sbfiz           x0, x5, #1, #0x1f
    //     0xb21a78: cmp             x5, x0, asr #1
    //     0xb21a7c: b.eq            #0xb21a88
    //     0xb21a80: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb21a84: stur            x5, [x0, #7]
    // 0xb21a88: r1 = LoadClassIdInstr(r6)
    //     0xb21a88: ldur            x1, [x6, #-1]
    //     0xb21a8c: ubfx            x1, x1, #0xc, #0x14
    // 0xb21a90: stp             x0, x6, [SP]
    // 0xb21a94: mov             x0, x1
    // 0xb21a98: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb21a98: sub             lr, x0, #0xdfd
    //     0xb21a9c: ldr             lr, [x21, lr, lsl #3]
    //     0xb21aa0: blr             lr
    // 0xb21aa4: cmp             w0, NULL
    // 0xb21aa8: b.eq            #0xb21ae8
    // 0xb21aac: r1 = 0
    //     0xb21aac: mov             x1, #0
    // 0xb21ab0: add             x2, fp, w1, sxtw #2
    // 0xb21ab4: LoadField: r2 = r2->field_fffffff8
    //     0xb21ab4: ldur            x2, [x2, #-8]
    // 0xb21ab8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xb21ab8: ldur            w3, [x2, #0x17]
    // 0xb21abc: DecompressPointer r3
    //     0xb21abc: add             x3, x3, HEAP, lsl #32
    // 0xb21ac0: ArrayStore: r3[0] = r0  ; List_4
    //     0xb21ac0: stur            w0, [x3, #0x17]
    //     0xb21ac4: tbz             w0, #0, #0xb21ae0
    //     0xb21ac8: ldurb           w16, [x3, #-1]
    //     0xb21acc: ldurb           w17, [x0, #-1]
    //     0xb21ad0: and             x16, x17, x16, lsr #2
    //     0xb21ad4: tst             x16, HEAP, lsr #32
    //     0xb21ad8: b.eq            #0xb21ae0
    //     0xb21adc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb21ae0: r0 = true
    //     0xb21ae0: add             x0, NULL, #0x20  ; true
    // 0xb21ae4: r0 = SuspendSyncStarAtYield()
    //     0xb21ae4: bl              #0x861898  ; SuspendSyncStarAtYieldStub
    // 0xb21ae8: ldur            x1, [fp, #-0x20]
    // 0xb21aec: add             x4, x1, #1
    // 0xb21af0: b               #0xb21a3c
    // 0xb21af4: r0 = false
    //     0xb21af4: add             x0, NULL, #0x30  ; false
    // 0xb21af8: LeaveFrame
    //     0xb21af8: mov             SP, fp
    //     0xb21afc: ldp             fp, lr, [SP], #0x10
    // 0xb21b00: ret
    //     0xb21b00: ret             
    // 0xb21b04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21b04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21b08: b               #0xb21a24
    // 0xb21b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21b0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21b10: b               #0xb21a54
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb26138, size: 0x268
    // 0xb26138: EnterFrame
    //     0xb26138: stp             fp, lr, [SP, #-0x10]!
    //     0xb2613c: mov             fp, SP
    // 0xb26140: AllocStack(0x70)
    //     0xb26140: sub             SP, SP, #0x70
    // 0xb26144: SetupParameters(RenderTable this /* r1 => r1, fp-0x8 */)
    //     0xb26144: stur            x1, [fp, #-8]
    // 0xb26148: CheckStackOverflow
    //     0xb26148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2614c: cmp             SP, x16
    //     0xb26150: b.ls            #0xb26384
    // 0xb26154: LoadField: r0 = r1->field_5b
    //     0xb26154: ldur            x0, [x1, #0x5b]
    // 0xb26158: LoadField: r3 = r1->field_53
    //     0xb26158: ldur            x3, [x1, #0x53]
    // 0xb2615c: mul             x4, x0, x3
    // 0xb26160: cbnz            x4, #0xb26174
    // 0xb26164: d0 = 0.000000
    //     0xb26164: eor             v0.16b, v0.16b, v0.16b
    // 0xb26168: LeaveFrame
    //     0xb26168: mov             SP, fp
    //     0xb2616c: ldp             fp, lr, [SP], #0x10
    // 0xb26170: ret
    //     0xb26170: ret             
    // 0xb26174: d0 = inf
    //     0xb26174: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb26178: LoadField: d1 = r2->field_7
    //     0xb26178: ldur            d1, [x2, #7]
    // 0xb2617c: stur            d1, [fp, #-0x48]
    // 0xb26180: fcmp            d1, d0
    // 0xb26184: b.eq            #0xb26190
    // 0xb26188: mov             v2.16b, v1.16b
    // 0xb2618c: b               #0xb26194
    // 0xb26190: d2 = 0.000000
    //     0xb26190: eor             v2.16b, v2.16b, v2.16b
    // 0xb26194: stur            d2, [fp, #-0x40]
    // 0xb26198: r0 = BoxConstraints()
    //     0xb26198: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2619c: ldur            d0, [fp, #-0x40]
    // 0xb261a0: StoreField: r0->field_7 = d0
    //     0xb261a0: stur            d0, [x0, #7]
    // 0xb261a4: ldur            d1, [fp, #-0x48]
    // 0xb261a8: d0 = inf
    //     0xb261a8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb261ac: fcmp            d1, d0
    // 0xb261b0: b.ne            #0xb261b8
    // 0xb261b4: d1 = inf
    //     0xb261b4: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb261b8: StoreField: r0->field_f = d1
    //     0xb261b8: stur            d1, [x0, #0xf]
    // 0xb261bc: fcmp            d0, d0
    // 0xb261c0: b.eq            #0xb261cc
    // 0xb261c4: d1 = inf
    //     0xb261c4: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb261c8: b               #0xb261d0
    // 0xb261cc: d1 = 0.000000
    //     0xb261cc: eor             v1.16b, v1.16b, v1.16b
    // 0xb261d0: ArrayStore: r0[0] = d1  ; List_8
    //     0xb261d0: stur            d1, [x0, #0x17]
    // 0xb261d4: StoreField: r0->field_1f = d0
    //     0xb261d4: stur            d0, [x0, #0x1f]
    // 0xb261d8: ldur            x1, [fp, #-8]
    // 0xb261dc: mov             x2, x0
    // 0xb261e0: r0 = _computeColumnWidths()
    //     0xb261e0: bl              #0xb26418  ; [package:flutter/src/rendering/table.dart] RenderTable::_computeColumnWidths
    // 0xb261e4: mov             x2, x0
    // 0xb261e8: stur            x2, [fp, #-0x28]
    // 0xb261ec: LoadField: r0 = r2->field_b
    //     0xb261ec: ldur            w0, [x2, #0xb]
    // 0xb261f0: r3 = LoadInt32Instr(r0)
    //     0xb261f0: sbfx            x3, x0, #1, #0x1f
    // 0xb261f4: stur            x3, [fp, #-0x20]
    // 0xb261f8: d0 = 0.000000
    //     0xb261f8: eor             v0.16b, v0.16b, v0.16b
    // 0xb261fc: r5 = 0
    //     0xb261fc: mov             x5, #0
    // 0xb26200: ldur            x4, [fp, #-8]
    // 0xb26204: stur            x5, [fp, #-0x18]
    // 0xb26208: stur            d0, [fp, #-0x48]
    // 0xb2620c: CheckStackOverflow
    //     0xb2620c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26210: cmp             SP, x16
    //     0xb26214: b.ls            #0xb2638c
    // 0xb26218: LoadField: r0 = r4->field_5b
    //     0xb26218: ldur            x0, [x4, #0x5b]
    // 0xb2621c: cmp             x5, x0
    // 0xb26220: b.ge            #0xb26378
    // 0xb26224: d1 = 0.000000
    //     0xb26224: eor             v1.16b, v1.16b, v1.16b
    // 0xb26228: r6 = 0
    //     0xb26228: mov             x6, #0
    // 0xb2622c: stur            x6, [fp, #-0x10]
    // 0xb26230: stur            d1, [fp, #-0x40]
    // 0xb26234: CheckStackOverflow
    //     0xb26234: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26238: cmp             SP, x16
    //     0xb2623c: b.ls            #0xb26394
    // 0xb26240: LoadField: r0 = r4->field_53
    //     0xb26240: ldur            x0, [x4, #0x53]
    // 0xb26244: cmp             x6, x0
    // 0xb26248: b.ge            #0xb26358
    // 0xb2624c: mul             x1, x5, x0
    // 0xb26250: add             x7, x6, x1
    // 0xb26254: LoadField: r8 = r4->field_4f
    //     0xb26254: ldur            w8, [x4, #0x4f]
    // 0xb26258: DecompressPointer r8
    //     0xb26258: add             x8, x8, HEAP, lsl #32
    // 0xb2625c: r0 = BoxInt64Instr(r7)
    //     0xb2625c: sbfiz           x0, x7, #1, #0x1f
    //     0xb26260: cmp             x7, x0, asr #1
    //     0xb26264: b.eq            #0xb26270
    //     0xb26268: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb2626c: stur            x7, [x0, #7]
    // 0xb26270: r1 = LoadClassIdInstr(r8)
    //     0xb26270: ldur            x1, [x8, #-1]
    //     0xb26274: ubfx            x1, x1, #0xc, #0x14
    // 0xb26278: stp             x0, x8, [SP]
    // 0xb2627c: mov             x0, x1
    // 0xb26280: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb26280: sub             lr, x0, #0xdfd
    //     0xb26284: ldr             lr, [x21, lr, lsl #3]
    //     0xb26288: blr             lr
    // 0xb2628c: mov             x2, x0
    // 0xb26290: stur            x2, [fp, #-0x38]
    // 0xb26294: cmp             w2, NULL
    // 0xb26298: b.eq            #0xb26330
    // 0xb2629c: ldur            x3, [fp, #-0x28]
    // 0xb262a0: ldur            d0, [fp, #-0x40]
    // 0xb262a4: ldur            x4, [fp, #-0x10]
    // 0xb262a8: ldur            x0, [fp, #-0x20]
    // 0xb262ac: mov             x1, x4
    // 0xb262b0: cmp             x1, x0
    // 0xb262b4: b.hs            #0xb2639c
    // 0xb262b8: ArrayLoad: r1 = r3[r4]  ; Unknown_4
    //     0xb262b8: add             x16, x3, x4, lsl #2
    //     0xb262bc: ldur            w1, [x16, #0xf]
    // 0xb262c0: DecompressPointer r1
    //     0xb262c0: add             x1, x1, HEAP, lsl #32
    // 0xb262c4: stur            x1, [fp, #-0x30]
    // 0xb262c8: r0 = 60
    //     0xb262c8: mov             x0, #0x3c
    // 0xb262cc: branchIfSmi(r2, 0xb262d8)
    //     0xb262cc: tbz             w2, #0, #0xb262d8
    // 0xb262d0: r0 = LoadClassIdInstr(r2)
    //     0xb262d0: ldur            x0, [x2, #-1]
    //     0xb262d4: ubfx            x0, x0, #0xc, #0x14
    // 0xb262d8: str             x2, [SP]
    // 0xb262dc: r0 = GDT[cid_x0 + 0x120ed]()
    //     0xb262dc: mov             x17, #0x20ed
    //     0xb262e0: movk            x17, #1, lsl #16
    //     0xb262e4: add             lr, x0, x17
    //     0xb262e8: ldr             lr, [x21, lr, lsl #3]
    //     0xb262ec: blr             lr
    // 0xb262f0: r16 = <double, double>
    //     0xb262f0: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb262f4: ldr             x16, [x16, #0x228]
    // 0xb262f8: ldur            lr, [fp, #-0x38]
    // 0xb262fc: stp             lr, x16, [SP, #0x18]
    // 0xb26300: r16 = Instance__IntrinsicDimension
    //     0xb26300: add             x16, PP, #0x90, lsl #12  ; [pp+0x90bc8] Obj!_IntrinsicDimension@12c46c1
    //     0xb26304: ldr             x16, [x16, #0xbc8]
    // 0xb26308: ldur            lr, [fp, #-0x30]
    // 0xb2630c: stp             lr, x16, [SP, #8]
    // 0xb26310: str             x0, [SP]
    // 0xb26314: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb26314: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb26318: r0 = _computeIntrinsics()
    //     0xb26318: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb2631c: LoadField: d1 = r0->field_7
    //     0xb2631c: ldur            d1, [x0, #7]
    // 0xb26320: ldur            d2, [fp, #-0x40]
    // 0xb26324: fmax            v3.2d, v2.2d, v1.2d
    // 0xb26328: mov             v1.16b, v3.16b
    // 0xb2632c: b               #0xb26338
    // 0xb26330: ldur            d2, [fp, #-0x40]
    // 0xb26334: mov             v1.16b, v2.16b
    // 0xb26338: ldur            x0, [fp, #-0x10]
    // 0xb2633c: add             x6, x0, #1
    // 0xb26340: ldur            x4, [fp, #-8]
    // 0xb26344: ldur            x2, [fp, #-0x28]
    // 0xb26348: ldur            d0, [fp, #-0x48]
    // 0xb2634c: ldur            x5, [fp, #-0x18]
    // 0xb26350: ldur            x3, [fp, #-0x20]
    // 0xb26354: b               #0xb2622c
    // 0xb26358: mov             x0, x5
    // 0xb2635c: mov             v2.16b, v1.16b
    // 0xb26360: fadd            d1, d0, d2
    // 0xb26364: add             x5, x0, #1
    // 0xb26368: mov             v0.16b, v1.16b
    // 0xb2636c: ldur            x2, [fp, #-0x28]
    // 0xb26370: ldur            x3, [fp, #-0x20]
    // 0xb26374: b               #0xb26200
    // 0xb26378: LeaveFrame
    //     0xb26378: mov             SP, fp
    //     0xb2637c: ldp             fp, lr, [SP], #0x10
    // 0xb26380: ret
    //     0xb26380: ret             
    // 0xb26384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb26384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb26388: b               #0xb26154
    // 0xb2638c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2638c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26390: b               #0xb26218
    // 0xb26394: r0 = StackOverflowSharedWithFPURegs()
    //     0xb26394: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26398: b               #0xb26240
    // 0xb2639c: r0 = RangeErrorSharedWithFPURegs()
    //     0xb2639c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb263a0, size: 0x78
    // 0xb263a0: EnterFrame
    //     0xb263a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb263a4: mov             fp, SP
    // 0xb263a8: ldr             x0, [fp, #0x18]
    // 0xb263ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb263ac: ldur            w1, [x0, #0x17]
    // 0xb263b0: DecompressPointer r1
    //     0xb263b0: add             x1, x1, HEAP, lsl #32
    // 0xb263b4: CheckStackOverflow
    //     0xb263b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb263b8: cmp             SP, x16
    //     0xb263bc: b.ls            #0xb26400
    // 0xb263c0: ldr             x2, [fp, #0x10]
    // 0xb263c4: r0 = computeMinIntrinsicHeight()
    //     0xb263c4: bl              #0xb26138  ; [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicHeight
    // 0xb263c8: r0 = inline_Allocate_Double()
    //     0xb263c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb263cc: add             x0, x0, #0x10
    //     0xb263d0: cmp             x1, x0
    //     0xb263d4: b.ls            #0xb26408
    //     0xb263d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb263dc: sub             x0, x0, #0xf
    //     0xb263e0: mov             x1, #0xe19c
    //     0xb263e4: movk            x1, #3, lsl #16
    //     0xb263e8: stur            x1, [x0, #-1]
    // 0xb263ec: dmb             ishst
    // 0xb263f0: StoreField: r0->field_7 = d0
    //     0xb263f0: stur            d0, [x0, #7]
    // 0xb263f4: LeaveFrame
    //     0xb263f4: mov             SP, fp
    //     0xb263f8: ldp             fp, lr, [SP], #0x10
    // 0xb263fc: ret
    //     0xb263fc: ret             
    // 0xb26400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb26400: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb26404: b               #0xb263c0
    // 0xb26408: SaveReg d0
    //     0xb26408: str             q0, [SP, #-0x10]!
    // 0xb2640c: r0 = AllocateDouble()
    //     0xb2640c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb26410: RestoreReg d0
    //     0xb26410: ldr             q0, [SP], #0x10
    // 0xb26414: b               #0xb263f0
  }
  _ _computeColumnWidths(/* No info */) {
    // ** addr: 0xb26418, size: 0x994
    // 0xb26418: EnterFrame
    //     0xb26418: stp             fp, lr, [SP, #-0x10]!
    //     0xb2641c: mov             fp, SP
    // 0xb26420: AllocStack(0x90)
    //     0xb26420: sub             SP, SP, #0x90
    // 0xb26424: SetupParameters(RenderTable this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xb26424: mov             x4, x1
    //     0xb26428: mov             x0, x2
    //     0xb2642c: stur            x1, [fp, #-0x10]
    //     0xb26430: stur            x2, [fp, #-0x18]
    // 0xb26434: CheckStackOverflow
    //     0xb26434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26438: cmp             SP, x16
    //     0xb2643c: b.ls            #0xb26c68
    // 0xb26440: LoadField: r5 = r4->field_53
    //     0xb26440: ldur            x5, [x4, #0x53]
    // 0xb26444: mov             x2, x5
    // 0xb26448: stur            x5, [fp, #-8]
    // 0xb2644c: r1 = <double>
    //     0xb2644c: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb26450: r3 = 0.000000
    //     0xb26450: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb26454: r0 = _List.filled()
    //     0xb26454: bl              #0x7f3644  ; [dart:core] _List::_List.filled
    // 0xb26458: mov             x4, x0
    // 0xb2645c: ldur            x0, [fp, #-0x10]
    // 0xb26460: stur            x4, [fp, #-0x28]
    // 0xb26464: LoadField: r5 = r0->field_53
    //     0xb26464: ldur            x5, [x0, #0x53]
    // 0xb26468: mov             x2, x5
    // 0xb2646c: stur            x5, [fp, #-0x20]
    // 0xb26470: r1 = <double>
    //     0xb26470: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb26474: r3 = 0.000000
    //     0xb26474: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb26478: r0 = _List.filled()
    //     0xb26478: bl              #0x7f3644  ; [dart:core] _List::_List.filled
    // 0xb2647c: mov             x4, x0
    // 0xb26480: ldur            x3, [fp, #-0x10]
    // 0xb26484: stur            x4, [fp, #-0x38]
    // 0xb26488: LoadField: r5 = r3->field_53
    //     0xb26488: ldur            x5, [x3, #0x53]
    // 0xb2648c: stur            x5, [fp, #-0x30]
    // 0xb26490: r0 = BoxInt64Instr(r5)
    //     0xb26490: sbfiz           x0, x5, #1, #0x1f
    //     0xb26494: cmp             x5, x0, asr #1
    //     0xb26498: b.eq            #0xb264a4
    //     0xb2649c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb264a0: stur            x5, [x0, #7]
    // 0xb264a4: mov             x2, x0
    // 0xb264a8: r1 = <double?>
    //     0xb264a8: add             x1, PP, #0x7a, lsl #12  ; [pp+0x7aba8] TypeArguments: <double?>
    //     0xb264ac: ldr             x1, [x1, #0xba8]
    // 0xb264b0: r0 = AllocateArray()
    //     0xb264b0: bl              #0x13df928  ; AllocateArrayStub
    // 0xb264b4: stur            x0, [fp, #-0x58]
    // 0xb264b8: d2 = 0.000000
    //     0xb264b8: eor             v2.16b, v2.16b, v2.16b
    // 0xb264bc: d1 = 0.000000
    //     0xb264bc: eor             v1.16b, v1.16b, v1.16b
    // 0xb264c0: d0 = 0.000000
    //     0xb264c0: eor             v0.16b, v0.16b, v0.16b
    // 0xb264c4: r4 = 0
    //     0xb264c4: mov             x4, #0
    // 0xb264c8: ldur            x3, [fp, #-0x10]
    // 0xb264cc: stur            x4, [fp, #-0x50]
    // 0xb264d0: stur            d2, [fp, #-0x60]
    // 0xb264d4: stur            d1, [fp, #-0x68]
    // 0xb264d8: stur            d0, [fp, #-0x70]
    // 0xb264dc: CheckStackOverflow
    //     0xb264dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb264e0: cmp             SP, x16
    //     0xb264e4: b.ls            #0xb26c70
    // 0xb264e8: LoadField: r2 = r3->field_53
    //     0xb264e8: ldur            x2, [x3, #0x53]
    // 0xb264ec: cmp             x4, x2
    // 0xb264f0: b.ge            #0xb2670c
    // 0xb264f4: LoadField: r5 = r3->field_63
    //     0xb264f4: ldur            w5, [x3, #0x63]
    // 0xb264f8: DecompressPointer r5
    //     0xb264f8: add             x5, x5, HEAP, lsl #32
    // 0xb264fc: stur            x5, [fp, #-0x48]
    // 0xb26500: lsl             x6, x4, #1
    // 0xb26504: mov             x1, x5
    // 0xb26508: mov             x2, x6
    // 0xb2650c: stur            x6, [fp, #-0x40]
    // 0xb26510: r0 = containsKey()
    //     0xb26510: bl              #0x1259498  ; [dart:_internal] ListMapView::containsKey
    // 0xb26514: tbnz            w0, #4, #0xb26544
    // 0xb26518: ldur            x0, [fp, #-0x48]
    // 0xb2651c: LoadField: r1 = r0->field_b
    //     0xb2651c: ldur            w1, [x0, #0xb]
    // 0xb26520: DecompressPointer r1
    //     0xb26520: add             x1, x1, HEAP, lsl #32
    // 0xb26524: r0 = LoadClassIdInstr(r1)
    //     0xb26524: ldur            x0, [x1, #-1]
    //     0xb26528: ubfx            x0, x0, #0xc, #0x14
    // 0xb2652c: ldur            x16, [fp, #-0x40]
    // 0xb26530: stp             x16, x1, [SP]
    // 0xb26534: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb26534: sub             lr, x0, #0xdfd
    //     0xb26538: ldr             lr, [x21, lr, lsl #3]
    //     0xb2653c: blr             lr
    // 0xb26540: b               #0xb26548
    // 0xb26544: r0 = Null
    //     0xb26544: mov             x0, NULL
    // 0xb26548: cmp             w0, NULL
    // 0xb2654c: b.ne            #0xb2655c
    // 0xb26550: r3 = Instance_FlexColumnWidth
    //     0xb26550: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8ffc8] Obj!FlexColumnWidth@129ede1
    //     0xb26554: ldr             x3, [x3, #0xfc8]
    // 0xb26558: b               #0xb26560
    // 0xb2655c: mov             x3, x0
    // 0xb26560: ldur            d0, [fp, #-0x60]
    // 0xb26564: ldur            x0, [fp, #-0x50]
    // 0xb26568: ldur            x1, [fp, #-0x10]
    // 0xb2656c: mov             x2, x0
    // 0xb26570: stur            x3, [fp, #-0x40]
    // 0xb26574: r0 = column()
    //     0xb26574: bl              #0xb21a00  ; [package:flutter/src/rendering/table.dart] RenderTable::column
    // 0xb26578: mov             x4, x0
    // 0xb2657c: ldur            x3, [fp, #-0x40]
    // 0xb26580: stur            x4, [fp, #-0x48]
    // 0xb26584: r0 = LoadClassIdInstr(r3)
    //     0xb26584: ldur            x0, [x3, #-1]
    //     0xb26588: ubfx            x0, x0, #0xc, #0x14
    // 0xb2658c: mov             x1, x3
    // 0xb26590: mov             x2, x4
    // 0xb26594: r0 = GDT[cid_x0 + -0x1000]()
    //     0xb26594: sub             lr, x0, #1, lsl #12
    //     0xb26598: ldr             lr, [x21, lr, lsl #3]
    //     0xb2659c: blr             lr
    // 0xb265a0: mov             x2, x0
    // 0xb265a4: ldur            x0, [fp, #-8]
    // 0xb265a8: ldur            x1, [fp, #-0x50]
    // 0xb265ac: cmp             x1, x0
    // 0xb265b0: b.hs            #0xb26c78
    // 0xb265b4: ldur            x1, [fp, #-0x28]
    // 0xb265b8: mov             x0, x2
    // 0xb265bc: ldur            x3, [fp, #-0x50]
    // 0xb265c0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb265c0: add             x25, x1, x3, lsl #2
    //     0xb265c4: add             x25, x25, #0xf
    //     0xb265c8: str             w0, [x25]
    //     0xb265cc: tbz             w0, #0, #0xb265e8
    //     0xb265d0: ldurb           w16, [x1, #-1]
    //     0xb265d4: ldurb           w17, [x0, #-1]
    //     0xb265d8: and             x16, x17, x16, lsr #2
    //     0xb265dc: tst             x16, HEAP, lsr #32
    //     0xb265e0: b.eq            #0xb265e8
    //     0xb265e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb265e8: LoadField: d0 = r2->field_7
    //     0xb265e8: ldur            d0, [x2, #7]
    // 0xb265ec: ldur            d1, [fp, #-0x60]
    // 0xb265f0: stur            d0, [fp, #-0x80]
    // 0xb265f4: fadd            d2, d1, d0
    // 0xb265f8: ldur            x4, [fp, #-0x40]
    // 0xb265fc: stur            d2, [fp, #-0x78]
    // 0xb26600: r0 = LoadClassIdInstr(r4)
    //     0xb26600: ldur            x0, [x4, #-1]
    //     0xb26604: ubfx            x0, x0, #0xc, #0x14
    // 0xb26608: mov             x1, x4
    // 0xb2660c: ldur            x2, [fp, #-0x48]
    // 0xb26610: r0 = GDT[cid_x0 + -0xffc]()
    //     0xb26610: sub             lr, x0, #0xffc
    //     0xb26614: ldr             lr, [x21, lr, lsl #3]
    //     0xb26618: blr             lr
    // 0xb2661c: mov             x2, x0
    // 0xb26620: ldur            x0, [fp, #-0x20]
    // 0xb26624: ldur            x1, [fp, #-0x50]
    // 0xb26628: cmp             x1, x0
    // 0xb2662c: b.hs            #0xb26c7c
    // 0xb26630: ldur            x1, [fp, #-0x38]
    // 0xb26634: mov             x0, x2
    // 0xb26638: ldur            x2, [fp, #-0x50]
    // 0xb2663c: ArrayStore: r1[r2] = r0  ; List_4
    //     0xb2663c: add             x25, x1, x2, lsl #2
    //     0xb26640: add             x25, x25, #0xf
    //     0xb26644: str             w0, [x25]
    //     0xb26648: tbz             w0, #0, #0xb26664
    //     0xb2664c: ldurb           w16, [x1, #-1]
    //     0xb26650: ldurb           w17, [x0, #-1]
    //     0xb26654: and             x16, x17, x16, lsr #2
    //     0xb26658: tst             x16, HEAP, lsr #32
    //     0xb2665c: b.eq            #0xb26664
    //     0xb26660: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb26664: ldur            x1, [fp, #-0x40]
    // 0xb26668: r0 = LoadClassIdInstr(r1)
    //     0xb26668: ldur            x0, [x1, #-1]
    //     0xb2666c: ubfx            x0, x0, #0xc, #0x14
    // 0xb26670: r0 = GDT[cid_x0 + -0xf1e]()
    //     0xb26670: sub             lr, x0, #0xf1e
    //     0xb26674: ldr             lr, [x21, lr, lsl #3]
    //     0xb26678: blr             lr
    // 0xb2667c: mov             x2, x0
    // 0xb26680: cmp             w2, NULL
    // 0xb26684: b.eq            #0xb266e4
    // 0xb26688: ldur            d0, [fp, #-0x70]
    // 0xb2668c: ldur            x3, [fp, #-0x50]
    // 0xb26690: ldur            x0, [fp, #-0x30]
    // 0xb26694: mov             x1, x3
    // 0xb26698: cmp             x1, x0
    // 0xb2669c: b.hs            #0xb26c80
    // 0xb266a0: ldur            x1, [fp, #-0x58]
    // 0xb266a4: mov             x0, x2
    // 0xb266a8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb266a8: add             x25, x1, x3, lsl #2
    //     0xb266ac: add             x25, x25, #0xf
    //     0xb266b0: str             w0, [x25]
    //     0xb266b4: tbz             w0, #0, #0xb266d0
    //     0xb266b8: ldurb           w16, [x1, #-1]
    //     0xb266bc: ldurb           w17, [x0, #-1]
    //     0xb266c0: and             x16, x17, x16, lsr #2
    //     0xb266c4: tst             x16, HEAP, lsr #32
    //     0xb266c8: b.eq            #0xb266d0
    //     0xb266cc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb266d0: LoadField: d2 = r2->field_7
    //     0xb266d0: ldur            d2, [x2, #7]
    // 0xb266d4: fadd            d3, d0, d2
    // 0xb266d8: ldur            d1, [fp, #-0x68]
    // 0xb266dc: mov             v0.16b, v3.16b
    // 0xb266e0: b               #0xb266fc
    // 0xb266e4: ldur            d3, [fp, #-0x68]
    // 0xb266e8: ldur            d0, [fp, #-0x70]
    // 0xb266ec: ldur            x3, [fp, #-0x50]
    // 0xb266f0: ldur            d2, [fp, #-0x80]
    // 0xb266f4: fadd            d4, d3, d2
    // 0xb266f8: mov             v1.16b, v4.16b
    // 0xb266fc: add             x4, x3, #1
    // 0xb26700: ldur            d2, [fp, #-0x78]
    // 0xb26704: ldur            x0, [fp, #-0x58]
    // 0xb26708: b               #0xb264c8
    // 0xb2670c: ldur            x3, [fp, #-0x18]
    // 0xb26710: mov             v3.16b, v1.16b
    // 0xb26714: mov             v1.16b, v2.16b
    // 0xb26718: d2 = 0.000000
    //     0xb26718: eor             v2.16b, v2.16b, v2.16b
    // 0xb2671c: LoadField: d4 = r3->field_f
    //     0xb2671c: ldur            d4, [x3, #0xf]
    // 0xb26720: LoadField: d5 = r3->field_7
    //     0xb26720: ldur            d5, [x3, #7]
    // 0xb26724: fcmp            d0, d2
    // 0xb26728: b.le            #0xb2686c
    // 0xb2672c: mov             x3, v4.d[0]
    // 0xb26730: and             x3, x3, #0x7fffffffffffffff
    // 0xb26734: r17 = 9218868437227405312
    //     0xb26734: mov             x17, #0x7ff0000000000000
    // 0xb26738: cmp             x3, x17
    // 0xb2673c: b.eq            #0xb26750
    // 0xb26740: fcmp            d4, d4
    // 0xb26744: b.vs            #0xb26750
    // 0xb26748: mov             v6.16b, v4.16b
    // 0xb2674c: b               #0xb26754
    // 0xb26750: mov             v6.16b, v5.16b
    // 0xb26754: fcmp            d6, d1
    // 0xb26758: b.le            #0xb26858
    // 0xb2675c: fsub            d7, d6, d3
    // 0xb26760: mov             v3.16b, v1.16b
    // 0xb26764: ldur            x4, [fp, #-0x28]
    // 0xb26768: ldur            x3, [fp, #-0x58]
    // 0xb2676c: r5 = 0
    //     0xb2676c: mov             x5, #0
    // 0xb26770: CheckStackOverflow
    //     0xb26770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26774: cmp             SP, x16
    //     0xb26778: b.ls            #0xb26c84
    // 0xb2677c: cmp             x5, x2
    // 0xb26780: b.ge            #0xb26864
    // 0xb26784: ldur            x0, [fp, #-0x30]
    // 0xb26788: mov             x1, x5
    // 0xb2678c: cmp             x1, x0
    // 0xb26790: b.hs            #0xb26c8c
    // 0xb26794: ArrayLoad: r6 = r3[r5]  ; Unknown_4
    //     0xb26794: add             x16, x3, x5, lsl #2
    //     0xb26798: ldur            w6, [x16, #0xf]
    // 0xb2679c: DecompressPointer r6
    //     0xb2679c: add             x6, x6, HEAP, lsl #32
    // 0xb267a0: cmp             w6, NULL
    // 0xb267a4: b.eq            #0xb2684c
    // 0xb267a8: LoadField: d6 = r6->field_7
    //     0xb267a8: ldur            d6, [x6, #7]
    // 0xb267ac: fmul            d8, d7, d6
    // 0xb267b0: fdiv            d6, d8, d0
    // 0xb267b4: ldur            x0, [fp, #-8]
    // 0xb267b8: mov             x1, x5
    // 0xb267bc: cmp             x1, x0
    // 0xb267c0: b.hs            #0xb26c90
    // 0xb267c4: ArrayLoad: r6 = r4[r5]  ; Unknown_4
    //     0xb267c4: add             x16, x4, x5, lsl #2
    //     0xb267c8: ldur            w6, [x16, #0xf]
    // 0xb267cc: DecompressPointer r6
    //     0xb267cc: add             x6, x6, HEAP, lsl #32
    // 0xb267d0: LoadField: d8 = r6->field_7
    //     0xb267d0: ldur            d8, [x6, #7]
    // 0xb267d4: fcmp            d6, d8
    // 0xb267d8: b.le            #0xb26844
    // 0xb267dc: fsub            d9, d6, d8
    // 0xb267e0: fadd            d8, d3, d9
    // 0xb267e4: r0 = inline_Allocate_Double()
    //     0xb267e4: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0xb267e8: add             x0, x0, #0x10
    //     0xb267ec: cmp             x6, x0
    //     0xb267f0: b.ls            #0xb26c94
    //     0xb267f4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb267f8: sub             x0, x0, #0xf
    //     0xb267fc: mov             x6, #0xe19c
    //     0xb26800: movk            x6, #3, lsl #16
    //     0xb26804: stur            x6, [x0, #-1]
    // 0xb26808: dmb             ishst
    // 0xb2680c: StoreField: r0->field_7 = d6
    //     0xb2680c: stur            d6, [x0, #7]
    // 0xb26810: mov             x1, x4
    // 0xb26814: ArrayStore: r1[r5] = r0  ; List_4
    //     0xb26814: add             x25, x1, x5, lsl #2
    //     0xb26818: add             x25, x25, #0xf
    //     0xb2681c: str             w0, [x25]
    //     0xb26820: tbz             w0, #0, #0xb2683c
    //     0xb26824: ldurb           w16, [x1, #-1]
    //     0xb26828: ldurb           w17, [x0, #-1]
    //     0xb2682c: and             x16, x17, x16, lsr #2
    //     0xb26830: tst             x16, HEAP, lsr #32
    //     0xb26834: b.eq            #0xb2683c
    //     0xb26838: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb2683c: mov             v6.16b, v8.16b
    // 0xb26840: b               #0xb26848
    // 0xb26844: mov             v6.16b, v3.16b
    // 0xb26848: mov             v3.16b, v6.16b
    // 0xb2684c: add             x0, x5, #1
    // 0xb26850: mov             x5, x0
    // 0xb26854: b               #0xb26770
    // 0xb26858: ldur            x4, [fp, #-0x28]
    // 0xb2685c: ldur            x3, [fp, #-0x58]
    // 0xb26860: mov             v3.16b, v1.16b
    // 0xb26864: mov             v1.16b, v3.16b
    // 0xb26868: b               #0xb26944
    // 0xb2686c: ldur            x4, [fp, #-0x28]
    // 0xb26870: ldur            x3, [fp, #-0x58]
    // 0xb26874: fcmp            d5, d1
    // 0xb26878: b.le            #0xb26944
    // 0xb2687c: fsub            d3, d5, d1
    // 0xb26880: r0 = BoxInt64Instr(r2)
    //     0xb26880: sbfiz           x0, x2, #1, #0x1f
    //     0xb26884: cmp             x2, x0, asr #1
    //     0xb26888: b.eq            #0xb26894
    //     0xb2688c: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb26890: stur            x2, [x0, #7]
    // 0xb26894: r16 = LoadInt32Instr(r0)
    //     0xb26894: sbfx            x16, x0, #1, #0x1f
    // 0xb26898: scvtf           d6, w16
    // 0xb2689c: fdiv            d7, d3, d6
    // 0xb268a0: r5 = 0
    //     0xb268a0: mov             x5, #0
    // 0xb268a4: CheckStackOverflow
    //     0xb268a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb268a8: cmp             SP, x16
    //     0xb268ac: b.ls            #0xb26cc4
    // 0xb268b0: cmp             x5, x2
    // 0xb268b4: b.ge            #0xb26940
    // 0xb268b8: ldur            x0, [fp, #-8]
    // 0xb268bc: mov             x1, x5
    // 0xb268c0: cmp             x1, x0
    // 0xb268c4: b.hs            #0xb26ccc
    // 0xb268c8: ArrayLoad: r6 = r4[r5]  ; Unknown_4
    //     0xb268c8: add             x16, x4, x5, lsl #2
    //     0xb268cc: ldur            w6, [x16, #0xf]
    // 0xb268d0: DecompressPointer r6
    //     0xb268d0: add             x6, x6, HEAP, lsl #32
    // 0xb268d4: LoadField: d3 = r6->field_7
    //     0xb268d4: ldur            d3, [x6, #7]
    // 0xb268d8: fadd            d6, d3, d7
    // 0xb268dc: r0 = inline_Allocate_Double()
    //     0xb268dc: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0xb268e0: add             x0, x0, #0x10
    //     0xb268e4: cmp             x6, x0
    //     0xb268e8: b.ls            #0xb26cd0
    //     0xb268ec: str             x0, [THR, #0x60]  ; THR::top
    //     0xb268f0: sub             x0, x0, #0xf
    //     0xb268f4: mov             x6, #0xe19c
    //     0xb268f8: movk            x6, #3, lsl #16
    //     0xb268fc: stur            x6, [x0, #-1]
    // 0xb26900: dmb             ishst
    // 0xb26904: StoreField: r0->field_7 = d6
    //     0xb26904: stur            d6, [x0, #7]
    // 0xb26908: mov             x1, x4
    // 0xb2690c: ArrayStore: r1[r5] = r0  ; List_4
    //     0xb2690c: add             x25, x1, x5, lsl #2
    //     0xb26910: add             x25, x25, #0xf
    //     0xb26914: str             w0, [x25]
    //     0xb26918: tbz             w0, #0, #0xb26934
    //     0xb2691c: ldurb           w16, [x1, #-1]
    //     0xb26920: ldurb           w17, [x0, #-1]
    //     0xb26924: and             x16, x17, x16, lsr #2
    //     0xb26928: tst             x16, HEAP, lsr #32
    //     0xb2692c: b.eq            #0xb26934
    //     0xb26930: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb26934: add             x0, x5, #1
    // 0xb26938: mov             x5, x0
    // 0xb2693c: b               #0xb268a4
    // 0xb26940: mov             v1.16b, v5.16b
    // 0xb26944: fcmp            d1, d4
    // 0xb26948: b.le            #0xb26c58
    // 0xb2694c: fsub            d3, d1, d4
    // 0xb26950: mov             v1.16b, v3.16b
    // 0xb26954: mov             v3.16b, v0.16b
    // 0xb26958: mov             x6, x2
    // 0xb2695c: ldur            x5, [fp, #-0x38]
    // 0xb26960: d0 = 0.000000
    //     0xb26960: ldr             d0, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xb26964: CheckStackOverflow
    //     0xb26964: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26968: cmp             SP, x16
    //     0xb2696c: b.ls            #0xb26d00
    // 0xb26970: fcmp            d1, d0
    // 0xb26974: b.le            #0xb26b00
    // 0xb26978: fcmp            d3, d0
    // 0xb2697c: b.le            #0xb26b00
    // 0xb26980: mov             v5.16b, v1.16b
    // 0xb26984: mov             x7, x6
    // 0xb26988: d4 = 0.000000
    //     0xb26988: eor             v4.16b, v4.16b, v4.16b
    // 0xb2698c: r6 = 0
    //     0xb2698c: mov             x6, #0
    // 0xb26990: CheckStackOverflow
    //     0xb26990: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26994: cmp             SP, x16
    //     0xb26998: b.ls            #0xb26d08
    // 0xb2699c: cmp             x6, x2
    // 0xb269a0: b.ge            #0xb26af0
    // 0xb269a4: ldur            x0, [fp, #-0x30]
    // 0xb269a8: mov             x1, x6
    // 0xb269ac: cmp             x1, x0
    // 0xb269b0: b.hs            #0xb26d10
    // 0xb269b4: ArrayLoad: r8 = r3[r6]  ; Unknown_4
    //     0xb269b4: add             x16, x3, x6, lsl #2
    //     0xb269b8: ldur            w8, [x16, #0xf]
    // 0xb269bc: DecompressPointer r8
    //     0xb269bc: add             x8, x8, HEAP, lsl #32
    // 0xb269c0: cmp             w8, NULL
    // 0xb269c4: b.eq            #0xb26ae4
    // 0xb269c8: ldur            x0, [fp, #-8]
    // 0xb269cc: mov             x1, x6
    // 0xb269d0: cmp             x1, x0
    // 0xb269d4: b.hs            #0xb26d14
    // 0xb269d8: ArrayLoad: r9 = r4[r6]  ; Unknown_4
    //     0xb269d8: add             x16, x4, x6, lsl #2
    //     0xb269dc: ldur            w9, [x16, #0xf]
    // 0xb269e0: DecompressPointer r9
    //     0xb269e0: add             x9, x9, HEAP, lsl #32
    // 0xb269e4: LoadField: d6 = r8->field_7
    //     0xb269e4: ldur            d6, [x8, #7]
    // 0xb269e8: fmul            d7, d5, d6
    // 0xb269ec: fdiv            d8, d7, d3
    // 0xb269f0: LoadField: d7 = r9->field_7
    //     0xb269f0: ldur            d7, [x9, #7]
    // 0xb269f4: fsub            d9, d7, d8
    // 0xb269f8: ldur            x0, [fp, #-0x20]
    // 0xb269fc: mov             x1, x6
    // 0xb26a00: cmp             x1, x0
    // 0xb26a04: b.hs            #0xb26d18
    // 0xb26a08: ArrayLoad: r0 = r5[r6]  ; Unknown_4
    //     0xb26a08: add             x16, x5, x6, lsl #2
    //     0xb26a0c: ldur            w0, [x16, #0xf]
    // 0xb26a10: DecompressPointer r0
    //     0xb26a10: add             x0, x0, HEAP, lsl #32
    // 0xb26a14: LoadField: d8 = r0->field_7
    //     0xb26a14: ldur            d8, [x0, #7]
    // 0xb26a18: fcmp            d8, d9
    // 0xb26a1c: b.lt            #0xb26a6c
    // 0xb26a20: fsub            d10, d7, d8
    // 0xb26a24: fsub            d8, d5, d10
    // 0xb26a28: mov             x1, x4
    // 0xb26a2c: ArrayStore: r1[r6] = r0  ; List_4
    //     0xb26a2c: add             x25, x1, x6, lsl #2
    //     0xb26a30: add             x25, x25, #0xf
    //     0xb26a34: str             w0, [x25]
    //     0xb26a38: tbz             w0, #0, #0xb26a54
    //     0xb26a3c: ldurb           w16, [x1, #-1]
    //     0xb26a40: ldurb           w17, [x0, #-1]
    //     0xb26a44: and             x16, x17, x16, lsr #2
    //     0xb26a48: tst             x16, HEAP, lsr #32
    //     0xb26a4c: b.eq            #0xb26a54
    //     0xb26a50: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb26a54: ArrayStore: r3[r6] = rNULL  ; Unknown_4
    //     0xb26a54: add             x8, x3, x6, lsl #2
    //     0xb26a58: stur            NULL, [x8, #0xf]
    // 0xb26a5c: sub             x8, x7, #1
    // 0xb26a60: mov             v7.16b, v8.16b
    // 0xb26a64: mov             v6.16b, v4.16b
    // 0xb26a68: b               #0xb26ad8
    // 0xb26a6c: fsub            d8, d7, d9
    // 0xb26a70: fsub            d7, d5, d8
    // 0xb26a74: r0 = inline_Allocate_Double()
    //     0xb26a74: ldp             x0, x8, [THR, #0x60]  ; THR::top
    //     0xb26a78: add             x0, x0, #0x10
    //     0xb26a7c: cmp             x8, x0
    //     0xb26a80: b.ls            #0xb26d1c
    //     0xb26a84: str             x0, [THR, #0x60]  ; THR::top
    //     0xb26a88: sub             x0, x0, #0xf
    //     0xb26a8c: mov             x8, #0xe19c
    //     0xb26a90: movk            x8, #3, lsl #16
    //     0xb26a94: stur            x8, [x0, #-1]
    // 0xb26a98: dmb             ishst
    // 0xb26a9c: StoreField: r0->field_7 = d9
    //     0xb26a9c: stur            d9, [x0, #7]
    // 0xb26aa0: mov             x1, x4
    // 0xb26aa4: ArrayStore: r1[r6] = r0  ; List_4
    //     0xb26aa4: add             x25, x1, x6, lsl #2
    //     0xb26aa8: add             x25, x25, #0xf
    //     0xb26aac: str             w0, [x25]
    //     0xb26ab0: tbz             w0, #0, #0xb26acc
    //     0xb26ab4: ldurb           w16, [x1, #-1]
    //     0xb26ab8: ldurb           w17, [x0, #-1]
    //     0xb26abc: and             x16, x17, x16, lsr #2
    //     0xb26ac0: tst             x16, HEAP, lsr #32
    //     0xb26ac4: b.eq            #0xb26acc
    //     0xb26ac8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb26acc: fadd            d8, d4, d6
    // 0xb26ad0: mov             x8, x7
    // 0xb26ad4: mov             v6.16b, v8.16b
    // 0xb26ad8: mov             v5.16b, v7.16b
    // 0xb26adc: mov             x7, x8
    // 0xb26ae0: mov             v4.16b, v6.16b
    // 0xb26ae4: add             x0, x6, #1
    // 0xb26ae8: mov             x6, x0
    // 0xb26aec: b               #0xb26990
    // 0xb26af0: mov             v3.16b, v4.16b
    // 0xb26af4: mov             v1.16b, v5.16b
    // 0xb26af8: mov             x6, x7
    // 0xb26afc: b               #0xb26964
    // 0xb26b00: mov             x3, x6
    // 0xb26b04: CheckStackOverflow
    //     0xb26b04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26b08: cmp             SP, x16
    //     0xb26b0c: b.ls            #0xb26d5c
    // 0xb26b10: fcmp            d1, d0
    // 0xb26b14: b.le            #0xb26c58
    // 0xb26b18: cmp             x3, #0
    // 0xb26b1c: b.le            #0xb26c58
    // 0xb26b20: scvtf           d3, x3
    // 0xb26b24: fdiv            d4, d1, d3
    // 0xb26b28: r6 = 0
    //     0xb26b28: mov             x6, #0
    // 0xb26b2c: r3 = 0
    //     0xb26b2c: mov             x3, #0
    // 0xb26b30: CheckStackOverflow
    //     0xb26b30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26b34: cmp             SP, x16
    //     0xb26b38: b.ls            #0xb26d64
    // 0xb26b3c: cmp             x3, x2
    // 0xb26b40: b.ge            #0xb26c50
    // 0xb26b44: ldur            x0, [fp, #-8]
    // 0xb26b48: mov             x1, x3
    // 0xb26b4c: cmp             x1, x0
    // 0xb26b50: b.hs            #0xb26d6c
    // 0xb26b54: ArrayLoad: r7 = r4[r3]  ; Unknown_4
    //     0xb26b54: add             x16, x4, x3, lsl #2
    //     0xb26b58: ldur            w7, [x16, #0xf]
    // 0xb26b5c: DecompressPointer r7
    //     0xb26b5c: add             x7, x7, HEAP, lsl #32
    // 0xb26b60: ldur            x0, [fp, #-0x20]
    // 0xb26b64: mov             x1, x3
    // 0xb26b68: cmp             x1, x0
    // 0xb26b6c: b.hs            #0xb26d70
    // 0xb26b70: ArrayLoad: r0 = r5[r3]  ; Unknown_4
    //     0xb26b70: add             x16, x5, x3, lsl #2
    //     0xb26b74: ldur            w0, [x16, #0xf]
    // 0xb26b78: DecompressPointer r0
    //     0xb26b78: add             x0, x0, HEAP, lsl #32
    // 0xb26b7c: LoadField: d3 = r7->field_7
    //     0xb26b7c: ldur            d3, [x7, #7]
    // 0xb26b80: LoadField: d5 = r0->field_7
    //     0xb26b80: ldur            d5, [x0, #7]
    // 0xb26b84: fsub            d6, d3, d5
    // 0xb26b88: fcmp            d6, d2
    // 0xb26b8c: b.le            #0xb26c44
    // 0xb26b90: fcmp            d4, d6
    // 0xb26b94: b.lt            #0xb26bd4
    // 0xb26b98: fsub            d5, d1, d6
    // 0xb26b9c: mov             x1, x4
    // 0xb26ba0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb26ba0: add             x25, x1, x3, lsl #2
    //     0xb26ba4: add             x25, x25, #0xf
    //     0xb26ba8: str             w0, [x25]
    //     0xb26bac: tbz             w0, #0, #0xb26bc8
    //     0xb26bb0: ldurb           w16, [x1, #-1]
    //     0xb26bb4: ldurb           w17, [x0, #-1]
    //     0xb26bb8: and             x16, x17, x16, lsr #2
    //     0xb26bbc: tst             x16, HEAP, lsr #32
    //     0xb26bc0: b.eq            #0xb26bc8
    //     0xb26bc4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb26bc8: mov             v3.16b, v5.16b
    // 0xb26bcc: mov             x1, x6
    // 0xb26bd0: b               #0xb26c3c
    // 0xb26bd4: fsub            d5, d1, d4
    // 0xb26bd8: fsub            d6, d3, d4
    // 0xb26bdc: r0 = inline_Allocate_Double()
    //     0xb26bdc: ldp             x0, x7, [THR, #0x60]  ; THR::top
    //     0xb26be0: add             x0, x0, #0x10
    //     0xb26be4: cmp             x7, x0
    //     0xb26be8: b.ls            #0xb26d74
    //     0xb26bec: str             x0, [THR, #0x60]  ; THR::top
    //     0xb26bf0: sub             x0, x0, #0xf
    //     0xb26bf4: mov             x7, #0xe19c
    //     0xb26bf8: movk            x7, #3, lsl #16
    //     0xb26bfc: stur            x7, [x0, #-1]
    // 0xb26c00: dmb             ishst
    // 0xb26c04: StoreField: r0->field_7 = d6
    //     0xb26c04: stur            d6, [x0, #7]
    // 0xb26c08: mov             x1, x4
    // 0xb26c0c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb26c0c: add             x25, x1, x3, lsl #2
    //     0xb26c10: add             x25, x25, #0xf
    //     0xb26c14: str             w0, [x25]
    //     0xb26c18: tbz             w0, #0, #0xb26c34
    //     0xb26c1c: ldurb           w16, [x1, #-1]
    //     0xb26c20: ldurb           w17, [x0, #-1]
    //     0xb26c24: and             x16, x17, x16, lsr #2
    //     0xb26c28: tst             x16, HEAP, lsr #32
    //     0xb26c2c: b.eq            #0xb26c34
    //     0xb26c30: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb26c34: add             x1, x6, #1
    // 0xb26c38: mov             v3.16b, v5.16b
    // 0xb26c3c: mov             v1.16b, v3.16b
    // 0xb26c40: mov             x6, x1
    // 0xb26c44: add             x0, x3, #1
    // 0xb26c48: mov             x3, x0
    // 0xb26c4c: b               #0xb26b30
    // 0xb26c50: mov             x3, x6
    // 0xb26c54: b               #0xb26b04
    // 0xb26c58: mov             x0, x4
    // 0xb26c5c: LeaveFrame
    //     0xb26c5c: mov             SP, fp
    //     0xb26c60: ldp             fp, lr, [SP], #0x10
    // 0xb26c64: ret
    //     0xb26c64: ret             
    // 0xb26c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb26c68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb26c6c: b               #0xb26440
    // 0xb26c70: r0 = StackOverflowSharedWithFPURegs()
    //     0xb26c70: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26c74: b               #0xb264e8
    // 0xb26c78: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb26c78: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb26c7c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb26c7c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb26c80: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26c80: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26c84: r0 = StackOverflowSharedWithFPURegs()
    //     0xb26c84: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26c88: b               #0xb2677c
    // 0xb26c8c: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26c8c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26c90: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26c90: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26c94: stp             q7, q8, [SP, #-0x20]!
    // 0xb26c98: stp             q4, q6, [SP, #-0x20]!
    // 0xb26c9c: stp             q0, q2, [SP, #-0x20]!
    // 0xb26ca0: stp             x4, x5, [SP, #-0x10]!
    // 0xb26ca4: stp             x2, x3, [SP, #-0x10]!
    // 0xb26ca8: r0 = AllocateDouble()
    //     0xb26ca8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb26cac: ldp             x2, x3, [SP], #0x10
    // 0xb26cb0: ldp             x4, x5, [SP], #0x10
    // 0xb26cb4: ldp             q0, q2, [SP], #0x20
    // 0xb26cb8: ldp             q4, q6, [SP], #0x20
    // 0xb26cbc: ldp             q7, q8, [SP], #0x20
    // 0xb26cc0: b               #0xb2680c
    // 0xb26cc4: r0 = StackOverflowSharedWithFPURegs()
    //     0xb26cc4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26cc8: b               #0xb268b0
    // 0xb26ccc: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26ccc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26cd0: stp             q6, q7, [SP, #-0x20]!
    // 0xb26cd4: stp             q4, q5, [SP, #-0x20]!
    // 0xb26cd8: stp             q0, q2, [SP, #-0x20]!
    // 0xb26cdc: stp             x4, x5, [SP, #-0x10]!
    // 0xb26ce0: stp             x2, x3, [SP, #-0x10]!
    // 0xb26ce4: r0 = AllocateDouble()
    //     0xb26ce4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb26ce8: ldp             x2, x3, [SP], #0x10
    // 0xb26cec: ldp             x4, x5, [SP], #0x10
    // 0xb26cf0: ldp             q0, q2, [SP], #0x20
    // 0xb26cf4: ldp             q4, q5, [SP], #0x20
    // 0xb26cf8: ldp             q6, q7, [SP], #0x20
    // 0xb26cfc: b               #0xb26904
    // 0xb26d00: r0 = StackOverflowSharedWithFPURegs()
    //     0xb26d00: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26d04: b               #0xb26970
    // 0xb26d08: r0 = StackOverflowSharedWithFPURegs()
    //     0xb26d08: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26d0c: b               #0xb2699c
    // 0xb26d10: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26d10: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26d14: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26d14: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26d18: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26d18: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26d1c: stp             q7, q9, [SP, #-0x20]!
    // 0xb26d20: stp             q4, q6, [SP, #-0x20]!
    // 0xb26d24: stp             q2, q3, [SP, #-0x20]!
    // 0xb26d28: SaveReg d0
    //     0xb26d28: str             q0, [SP, #-0x10]!
    // 0xb26d2c: stp             x6, x7, [SP, #-0x10]!
    // 0xb26d30: stp             x4, x5, [SP, #-0x10]!
    // 0xb26d34: stp             x2, x3, [SP, #-0x10]!
    // 0xb26d38: r0 = AllocateDouble()
    //     0xb26d38: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb26d3c: ldp             x2, x3, [SP], #0x10
    // 0xb26d40: ldp             x4, x5, [SP], #0x10
    // 0xb26d44: ldp             x6, x7, [SP], #0x10
    // 0xb26d48: RestoreReg d0
    //     0xb26d48: ldr             q0, [SP], #0x10
    // 0xb26d4c: ldp             q2, q3, [SP], #0x20
    // 0xb26d50: ldp             q4, q6, [SP], #0x20
    // 0xb26d54: ldp             q7, q9, [SP], #0x20
    // 0xb26d58: b               #0xb26a9c
    // 0xb26d5c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb26d5c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26d60: b               #0xb26b10
    // 0xb26d64: r0 = StackOverflowSharedWithFPURegs()
    //     0xb26d64: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb26d68: b               #0xb26b3c
    // 0xb26d6c: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26d6c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26d70: r0 = RangeErrorSharedWithFPURegs()
    //     0xb26d70: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xb26d74: stp             q5, q6, [SP, #-0x20]!
    // 0xb26d78: stp             q2, q4, [SP, #-0x20]!
    // 0xb26d7c: SaveReg d0
    //     0xb26d7c: str             q0, [SP, #-0x10]!
    // 0xb26d80: stp             x5, x6, [SP, #-0x10]!
    // 0xb26d84: stp             x3, x4, [SP, #-0x10]!
    // 0xb26d88: SaveReg r2
    //     0xb26d88: str             x2, [SP, #-8]!
    // 0xb26d8c: r0 = AllocateDouble()
    //     0xb26d8c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb26d90: RestoreReg r2
    //     0xb26d90: ldr             x2, [SP], #8
    // 0xb26d94: ldp             x3, x4, [SP], #0x10
    // 0xb26d98: ldp             x5, x6, [SP], #0x10
    // 0xb26d9c: RestoreReg d0
    //     0xb26d9c: ldr             q0, [SP], #0x10
    // 0xb26da0: ldp             q2, q4, [SP], #0x20
    // 0xb26da4: ldp             q5, q6, [SP], #0x20
    // 0xb26da8: b               #0xb26c04
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2c630, size: 0x30
    // 0xb2c630: EnterFrame
    //     0xb2c630: stp             fp, lr, [SP, #-0x10]!
    //     0xb2c634: mov             fp, SP
    // 0xb2c638: CheckStackOverflow
    //     0xb2c638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2c63c: cmp             SP, x16
    //     0xb2c640: b.ls            #0xb2c658
    // 0xb2c644: LoadField: d0 = r2->field_7
    //     0xb2c644: ldur            d0, [x2, #7]
    // 0xb2c648: r0 = getMinIntrinsicHeight()
    //     0xb2c648: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb2c64c: LeaveFrame
    //     0xb2c64c: mov             SP, fp
    //     0xb2c650: ldp             fp, lr, [SP], #0x10
    // 0xb2c654: ret
    //     0xb2c654: ret             
    // 0xb2c658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2c658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2c65c: b               #0xb2c644
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2f63c, size: 0x15c
    // 0xb2f63c: EnterFrame
    //     0xb2f63c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2f640: mov             fp, SP
    // 0xb2f644: AllocStack(0x38)
    //     0xb2f644: sub             SP, SP, #0x38
    // 0xb2f648: SetupParameters(RenderTable this /* r1 => r3, fp-0x20 */)
    //     0xb2f648: mov             x3, x1
    //     0xb2f64c: stur            x1, [fp, #-0x20]
    // 0xb2f650: CheckStackOverflow
    //     0xb2f650: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2f654: cmp             SP, x16
    //     0xb2f658: b.ls            #0xb2f788
    // 0xb2f65c: LoadField: r0 = r3->field_5b
    //     0xb2f65c: ldur            x0, [x3, #0x5b]
    // 0xb2f660: LoadField: r1 = r3->field_53
    //     0xb2f660: ldur            x1, [x3, #0x53]
    // 0xb2f664: mul             x2, x0, x1
    // 0xb2f668: cbnz            x2, #0xb2f67c
    // 0xb2f66c: d0 = 0.000000
    //     0xb2f66c: eor             v0.16b, v0.16b, v0.16b
    // 0xb2f670: LeaveFrame
    //     0xb2f670: mov             SP, fp
    //     0xb2f674: ldp             fp, lr, [SP], #0x10
    // 0xb2f678: ret
    //     0xb2f678: ret             
    // 0xb2f67c: d0 = 0.000000
    //     0xb2f67c: eor             v0.16b, v0.16b, v0.16b
    // 0xb2f680: r4 = 0
    //     0xb2f680: mov             x4, #0
    // 0xb2f684: stur            x4, [fp, #-0x18]
    // 0xb2f688: stur            d0, [fp, #-0x28]
    // 0xb2f68c: CheckStackOverflow
    //     0xb2f68c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2f690: cmp             SP, x16
    //     0xb2f694: b.ls            #0xb2f790
    // 0xb2f698: LoadField: r0 = r3->field_53
    //     0xb2f698: ldur            x0, [x3, #0x53]
    // 0xb2f69c: cmp             x4, x0
    // 0xb2f6a0: b.ge            #0xb2f77c
    // 0xb2f6a4: LoadField: r5 = r3->field_63
    //     0xb2f6a4: ldur            w5, [x3, #0x63]
    // 0xb2f6a8: DecompressPointer r5
    //     0xb2f6a8: add             x5, x5, HEAP, lsl #32
    // 0xb2f6ac: stur            x5, [fp, #-0x10]
    // 0xb2f6b0: r0 = BoxInt64Instr(r4)
    //     0xb2f6b0: sbfiz           x0, x4, #1, #0x1f
    //     0xb2f6b4: cmp             x4, x0, asr #1
    //     0xb2f6b8: b.eq            #0xb2f6c4
    //     0xb2f6bc: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb2f6c0: stur            x4, [x0, #7]
    // 0xb2f6c4: mov             x1, x5
    // 0xb2f6c8: mov             x2, x0
    // 0xb2f6cc: stur            x0, [fp, #-8]
    // 0xb2f6d0: r0 = containsKey()
    //     0xb2f6d0: bl              #0x1259498  ; [dart:_internal] ListMapView::containsKey
    // 0xb2f6d4: tbnz            w0, #4, #0xb2f704
    // 0xb2f6d8: ldur            x0, [fp, #-0x10]
    // 0xb2f6dc: LoadField: r1 = r0->field_b
    //     0xb2f6dc: ldur            w1, [x0, #0xb]
    // 0xb2f6e0: DecompressPointer r1
    //     0xb2f6e0: add             x1, x1, HEAP, lsl #32
    // 0xb2f6e4: r0 = LoadClassIdInstr(r1)
    //     0xb2f6e4: ldur            x0, [x1, #-1]
    //     0xb2f6e8: ubfx            x0, x0, #0xc, #0x14
    // 0xb2f6ec: ldur            x16, [fp, #-8]
    // 0xb2f6f0: stp             x16, x1, [SP]
    // 0xb2f6f4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb2f6f4: sub             lr, x0, #0xdfd
    //     0xb2f6f8: ldr             lr, [x21, lr, lsl #3]
    //     0xb2f6fc: blr             lr
    // 0xb2f700: b               #0xb2f708
    // 0xb2f704: r0 = Null
    //     0xb2f704: mov             x0, NULL
    // 0xb2f708: cmp             w0, NULL
    // 0xb2f70c: b.ne            #0xb2f71c
    // 0xb2f710: r3 = Instance_FlexColumnWidth
    //     0xb2f710: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8ffc8] Obj!FlexColumnWidth@129ede1
    //     0xb2f714: ldr             x3, [x3, #0xfc8]
    // 0xb2f718: b               #0xb2f720
    // 0xb2f71c: mov             x3, x0
    // 0xb2f720: ldur            d0, [fp, #-0x28]
    // 0xb2f724: ldur            x0, [fp, #-0x18]
    // 0xb2f728: ldur            x1, [fp, #-0x20]
    // 0xb2f72c: mov             x2, x0
    // 0xb2f730: stur            x3, [fp, #-8]
    // 0xb2f734: r0 = column()
    //     0xb2f734: bl              #0xb21a00  ; [package:flutter/src/rendering/table.dart] RenderTable::column
    // 0xb2f738: ldur            x1, [fp, #-8]
    // 0xb2f73c: r2 = LoadClassIdInstr(r1)
    //     0xb2f73c: ldur            x2, [x1, #-1]
    //     0xb2f740: ubfx            x2, x2, #0xc, #0x14
    // 0xb2f744: mov             x16, x0
    // 0xb2f748: mov             x0, x2
    // 0xb2f74c: mov             x2, x16
    // 0xb2f750: r0 = GDT[cid_x0 + -0x1000]()
    //     0xb2f750: sub             lr, x0, #1, lsl #12
    //     0xb2f754: ldr             lr, [x21, lr, lsl #3]
    //     0xb2f758: blr             lr
    // 0xb2f75c: LoadField: d1 = r0->field_7
    //     0xb2f75c: ldur            d1, [x0, #7]
    // 0xb2f760: ldur            d0, [fp, #-0x28]
    // 0xb2f764: fadd            d2, d0, d1
    // 0xb2f768: ldur            x0, [fp, #-0x18]
    // 0xb2f76c: add             x4, x0, #1
    // 0xb2f770: mov             v0.16b, v2.16b
    // 0xb2f774: ldur            x3, [fp, #-0x20]
    // 0xb2f778: b               #0xb2f684
    // 0xb2f77c: LeaveFrame
    //     0xb2f77c: mov             SP, fp
    //     0xb2f780: ldp             fp, lr, [SP], #0x10
    // 0xb2f784: ret
    //     0xb2f784: ret             
    // 0xb2f788: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2f788: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2f78c: b               #0xb2f65c
    // 0xb2f790: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2f790: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2f794: b               #0xb2f698
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2f798, size: 0x78
    // 0xb2f798: EnterFrame
    //     0xb2f798: stp             fp, lr, [SP, #-0x10]!
    //     0xb2f79c: mov             fp, SP
    // 0xb2f7a0: ldr             x0, [fp, #0x18]
    // 0xb2f7a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2f7a4: ldur            w1, [x0, #0x17]
    // 0xb2f7a8: DecompressPointer r1
    //     0xb2f7a8: add             x1, x1, HEAP, lsl #32
    // 0xb2f7ac: CheckStackOverflow
    //     0xb2f7ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2f7b0: cmp             SP, x16
    //     0xb2f7b4: b.ls            #0xb2f7f8
    // 0xb2f7b8: ldr             x2, [fp, #0x10]
    // 0xb2f7bc: r0 = computeMaxIntrinsicWidth()
    //     0xb2f7bc: bl              #0xb2f63c  ; [package:flutter/src/rendering/table.dart] RenderTable::computeMaxIntrinsicWidth
    // 0xb2f7c0: r0 = inline_Allocate_Double()
    //     0xb2f7c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2f7c4: add             x0, x0, #0x10
    //     0xb2f7c8: cmp             x1, x0
    //     0xb2f7cc: b.ls            #0xb2f800
    //     0xb2f7d0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2f7d4: sub             x0, x0, #0xf
    //     0xb2f7d8: mov             x1, #0xe19c
    //     0xb2f7dc: movk            x1, #3, lsl #16
    //     0xb2f7e0: stur            x1, [x0, #-1]
    // 0xb2f7e4: dmb             ishst
    // 0xb2f7e8: StoreField: r0->field_7 = d0
    //     0xb2f7e8: stur            d0, [x0, #7]
    // 0xb2f7ec: LeaveFrame
    //     0xb2f7ec: mov             SP, fp
    //     0xb2f7f0: ldp             fp, lr, [SP], #0x10
    // 0xb2f7f4: ret
    //     0xb2f7f4: ret             
    // 0xb2f7f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2f7f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2f7fc: b               #0xb2f7b8
    // 0xb2f800: SaveReg d0
    //     0xb2f800: str             q0, [SP, #-0x10]!
    // 0xb2f804: r0 = AllocateDouble()
    //     0xb2f804: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2f808: RestoreReg d0
    //     0xb2f808: ldr             q0, [SP], #0x10
    // 0xb2f80c: b               #0xb2f7e8
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb57408, size: 0x32c
    // 0xb57408: EnterFrame
    //     0xb57408: stp             fp, lr, [SP, #-0x10]!
    //     0xb5740c: mov             fp, SP
    // 0xb57410: AllocStack(0x88)
    //     0xb57410: sub             SP, SP, #0x88
    // 0xb57414: SetupParameters(RenderTable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb57414: mov             x3, x1
    //     0xb57418: mov             x0, x2
    //     0xb5741c: stur            x1, [fp, #-8]
    //     0xb57420: stur            x2, [fp, #-0x10]
    // 0xb57424: CheckStackOverflow
    //     0xb57424: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb57428: cmp             SP, x16
    //     0xb5742c: b.ls            #0xb57714
    // 0xb57430: LoadField: r1 = r3->field_5b
    //     0xb57430: ldur            x1, [x3, #0x5b]
    // 0xb57434: LoadField: r2 = r3->field_53
    //     0xb57434: ldur            x2, [x3, #0x53]
    // 0xb57438: mul             x4, x1, x2
    // 0xb5743c: cbnz            x4, #0xb57458
    // 0xb57440: mov             x1, x0
    // 0xb57444: r2 = Instance_Size
    //     0xb57444: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb57448: r0 = constrain()
    //     0xb57448: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb5744c: LeaveFrame
    //     0xb5744c: mov             SP, fp
    //     0xb57450: ldp             fp, lr, [SP], #0x10
    // 0xb57454: ret
    //     0xb57454: ret             
    // 0xb57458: mov             x1, x3
    // 0xb5745c: mov             x2, x0
    // 0xb57460: r0 = _computeColumnWidths()
    //     0xb57460: bl              #0xb26418  ; [package:flutter/src/rendering/table.dart] RenderTable::_computeColumnWidths
    // 0xb57464: r1 = Function '<anonymous closure>':.
    //     0xb57464: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1258] AnonymousClosure: (0xade914), in [package:flutter/src/gestures/scale.dart] ScaleGestureRecognizer::_reconfigure (0xade978)
    //     0xb57468: ldr             x1, [x1, #0x258]
    // 0xb5746c: r2 = Null
    //     0xb5746c: mov             x2, NULL
    // 0xb57470: stur            x0, [fp, #-0x18]
    // 0xb57474: r0 = AllocateClosure()
    //     0xb57474: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb57478: r16 = <double>
    //     0xb57478: ldr             x16, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xb5747c: ldur            lr, [fp, #-0x18]
    // 0xb57480: stp             lr, x16, [SP, #0x10]
    // 0xb57484: r16 = 0.000000
    //     0xb57484: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb57488: stp             x0, x16, [SP]
    // 0xb5748c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xb5748c: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xb57490: r0 = fold()
    //     0xb57490: bl              #0x861118  ; [dart:collection] ListBase::fold
    // 0xb57494: mov             x3, x0
    // 0xb57498: ldur            x2, [fp, #-0x18]
    // 0xb5749c: stur            x3, [fp, #-0x38]
    // 0xb574a0: LoadField: r0 = r2->field_b
    //     0xb574a0: ldur            w0, [x2, #0xb]
    // 0xb574a4: r4 = LoadInt32Instr(r0)
    //     0xb574a4: sbfx            x4, x0, #1, #0x1f
    // 0xb574a8: stur            x4, [fp, #-0x30]
    // 0xb574ac: d0 = 0.000000
    //     0xb574ac: eor             v0.16b, v0.16b, v0.16b
    // 0xb574b0: r6 = 0
    //     0xb574b0: mov             x6, #0
    // 0xb574b4: ldur            x5, [fp, #-8]
    // 0xb574b8: stur            x6, [fp, #-0x28]
    // 0xb574bc: stur            d0, [fp, #-0x58]
    // 0xb574c0: CheckStackOverflow
    //     0xb574c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb574c4: cmp             SP, x16
    //     0xb574c8: b.ls            #0xb5771c
    // 0xb574cc: LoadField: r0 = r5->field_5b
    //     0xb574cc: ldur            x0, [x5, #0x5b]
    // 0xb574d0: cmp             x6, x0
    // 0xb574d4: b.ge            #0xb576dc
    // 0xb574d8: d1 = 0.000000
    //     0xb574d8: eor             v1.16b, v1.16b, v1.16b
    // 0xb574dc: r7 = 0
    //     0xb574dc: mov             x7, #0
    // 0xb574e0: stur            x7, [fp, #-0x20]
    // 0xb574e4: stur            d1, [fp, #-0x50]
    // 0xb574e8: CheckStackOverflow
    //     0xb574e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb574ec: cmp             SP, x16
    //     0xb574f0: b.ls            #0xb57724
    // 0xb574f4: LoadField: r0 = r5->field_53
    //     0xb574f4: ldur            x0, [x5, #0x53]
    // 0xb574f8: cmp             x7, x0
    // 0xb574fc: b.ge            #0xb576bc
    // 0xb57500: mul             x1, x6, x0
    // 0xb57504: add             x8, x7, x1
    // 0xb57508: LoadField: r9 = r5->field_4f
    //     0xb57508: ldur            w9, [x5, #0x4f]
    // 0xb5750c: DecompressPointer r9
    //     0xb5750c: add             x9, x9, HEAP, lsl #32
    // 0xb57510: r0 = BoxInt64Instr(r8)
    //     0xb57510: sbfiz           x0, x8, #1, #0x1f
    //     0xb57514: cmp             x8, x0, asr #1
    //     0xb57518: b.eq            #0xb57524
    //     0xb5751c: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb57520: stur            x8, [x0, #7]
    // 0xb57524: r1 = LoadClassIdInstr(r9)
    //     0xb57524: ldur            x1, [x9, #-1]
    //     0xb57528: ubfx            x1, x1, #0xc, #0x14
    // 0xb5752c: stp             x0, x9, [SP]
    // 0xb57530: mov             x0, x1
    // 0xb57534: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb57534: sub             lr, x0, #0xdfd
    //     0xb57538: ldr             lr, [x21, lr, lsl #3]
    //     0xb5753c: blr             lr
    // 0xb57540: mov             x3, x0
    // 0xb57544: stur            x3, [fp, #-0x48]
    // 0xb57548: cmp             w3, NULL
    // 0xb5754c: b.eq            #0xb57694
    // 0xb57550: LoadField: r4 = r3->field_7
    //     0xb57550: ldur            w4, [x3, #7]
    // 0xb57554: DecompressPointer r4
    //     0xb57554: add             x4, x4, HEAP, lsl #32
    // 0xb57558: stur            x4, [fp, #-0x40]
    // 0xb5755c: cmp             w4, NULL
    // 0xb57560: b.eq            #0xb5772c
    // 0xb57564: mov             x0, x4
    // 0xb57568: r2 = Null
    //     0xb57568: mov             x2, NULL
    // 0xb5756c: r1 = Null
    //     0xb5756c: mov             x1, NULL
    // 0xb57570: r4 = LoadClassIdInstr(r0)
    //     0xb57570: ldur            x4, [x0, #-1]
    //     0xb57574: ubfx            x4, x4, #0xc, #0x14
    // 0xb57578: r17 = 4191
    //     0xb57578: mov             x17, #0x105f
    // 0xb5757c: cmp             x4, x17
    // 0xb57580: b.eq            #0xb57598
    // 0xb57584: r8 = TableCellParentData
    //     0xb57584: add             x8, PP, #0x84, lsl #12  ; [pp+0x84a98] Type: TableCellParentData
    //     0xb57588: ldr             x8, [x8, #0xa98]
    // 0xb5758c: r3 = Null
    //     0xb5758c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1260] Null
    //     0xb57590: ldr             x3, [x3, #0x260]
    // 0xb57594: r0 = DefaultTypeTest()
    //     0xb57594: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb57598: ldur            x0, [fp, #-0x40]
    // 0xb5759c: LoadField: r1 = r0->field_b
    //     0xb5759c: ldur            w1, [x0, #0xb]
    // 0xb575a0: DecompressPointer r1
    //     0xb575a0: add             x1, x1, HEAP, lsl #32
    // 0xb575a4: cmp             w1, NULL
    // 0xb575a8: b.ne            #0xb575b8
    // 0xb575ac: r0 = Instance_TableCellVerticalAlignment
    //     0xb575ac: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8ffd0] Obj!TableCellVerticalAlignment@12c4161
    //     0xb575b0: ldr             x0, [x0, #0xfd0]
    // 0xb575b4: b               #0xb575bc
    // 0xb575b8: mov             x0, x1
    // 0xb575bc: LoadField: r1 = r0->field_7
    //     0xb575bc: ldur            x1, [x0, #7]
    // 0xb575c0: cmp             x1, #2
    // 0xb575c4: b.le            #0xb575f0
    // 0xb575c8: cmp             x1, #4
    // 0xb575cc: b.gt            #0xb575f0
    // 0xb575d0: cmp             x1, #3
    // 0xb575d4: b.le            #0xb575e0
    // 0xb575d8: ldur            d0, [fp, #-0x50]
    // 0xb575dc: b               #0xb5768c
    // 0xb575e0: r0 = Instance_Size
    //     0xb575e0: ldr             x0, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb575e4: LeaveFrame
    //     0xb575e4: mov             SP, fp
    //     0xb575e8: ldp             fp, lr, [SP], #0x10
    // 0xb575ec: ret
    //     0xb575ec: ret             
    // 0xb575f0: ldur            x2, [fp, #-0x18]
    // 0xb575f4: ldur            d0, [fp, #-0x50]
    // 0xb575f8: ldur            x3, [fp, #-0x20]
    // 0xb575fc: ldur            x0, [fp, #-0x30]
    // 0xb57600: mov             x1, x3
    // 0xb57604: cmp             x1, x0
    // 0xb57608: b.hs            #0xb57730
    // 0xb5760c: ArrayLoad: r0 = r2[r3]  ; Unknown_4
    //     0xb5760c: add             x16, x2, x3, lsl #2
    //     0xb57610: ldur            w0, [x16, #0xf]
    // 0xb57614: DecompressPointer r0
    //     0xb57614: add             x0, x0, HEAP, lsl #32
    // 0xb57618: LoadField: d1 = r0->field_7
    //     0xb57618: ldur            d1, [x0, #7]
    // 0xb5761c: stur            d1, [fp, #-0x60]
    // 0xb57620: r0 = BoxConstraints()
    //     0xb57620: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb57624: ldur            d0, [fp, #-0x60]
    // 0xb57628: stur            x0, [fp, #-0x40]
    // 0xb5762c: StoreField: r0->field_7 = d0
    //     0xb5762c: stur            d0, [x0, #7]
    // 0xb57630: StoreField: r0->field_f = d0
    //     0xb57630: stur            d0, [x0, #0xf]
    // 0xb57634: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb57634: stur            xzr, [x0, #0x17]
    // 0xb57638: d0 = inf
    //     0xb57638: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb5763c: StoreField: r0->field_1f = d0
    //     0xb5763c: stur            d0, [x0, #0x1f]
    // 0xb57640: ldur            x2, [fp, #-0x48]
    // 0xb57644: r1 = Function '_computeDryLayout@29392247':.
    //     0xb57644: add             x1, PP, #0x27, lsl #12  ; [pp+0x27010] AnonymousClosure: (0xb20488), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout (0xb204c4)
    //     0xb57648: ldr             x1, [x1, #0x10]
    // 0xb5764c: r0 = AllocateClosure()
    //     0xb5764c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb57650: r16 = <BoxConstraints, Size>
    //     0xb57650: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0xb57654: ldr             x16, [x16, #0x18]
    // 0xb57658: ldur            lr, [fp, #-0x48]
    // 0xb5765c: stp             lr, x16, [SP, #0x18]
    // 0xb57660: r16 = Instance__DryLayout
    //     0xb57660: add             x16, PP, #0x27, lsl #12  ; [pp+0x27020] Obj!_DryLayout@129c191
    //     0xb57664: ldr             x16, [x16, #0x20]
    // 0xb57668: ldur            lr, [fp, #-0x40]
    // 0xb5766c: stp             lr, x16, [SP, #8]
    // 0xb57670: str             x0, [SP]
    // 0xb57674: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb57674: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb57678: r0 = _computeIntrinsics()
    //     0xb57678: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb5767c: LoadField: d0 = r0->field_f
    //     0xb5767c: ldur            d0, [x0, #0xf]
    // 0xb57680: ldur            d1, [fp, #-0x50]
    // 0xb57684: fmax            v2.2d, v1.2d, v0.2d
    // 0xb57688: mov             v0.16b, v2.16b
    // 0xb5768c: mov             v1.16b, v0.16b
    // 0xb57690: b               #0xb57698
    // 0xb57694: ldur            d1, [fp, #-0x50]
    // 0xb57698: ldur            x0, [fp, #-0x20]
    // 0xb5769c: add             x7, x0, #1
    // 0xb576a0: ldur            x5, [fp, #-8]
    // 0xb576a4: ldur            x2, [fp, #-0x18]
    // 0xb576a8: ldur            x3, [fp, #-0x38]
    // 0xb576ac: ldur            d0, [fp, #-0x58]
    // 0xb576b0: ldur            x6, [fp, #-0x28]
    // 0xb576b4: ldur            x4, [fp, #-0x30]
    // 0xb576b8: b               #0xb574e0
    // 0xb576bc: mov             x0, x6
    // 0xb576c0: fadd            d2, d0, d1
    // 0xb576c4: add             x6, x0, #1
    // 0xb576c8: mov             v0.16b, v2.16b
    // 0xb576cc: ldur            x2, [fp, #-0x18]
    // 0xb576d0: ldur            x3, [fp, #-0x38]
    // 0xb576d4: ldur            x4, [fp, #-0x30]
    // 0xb576d8: b               #0xb574b4
    // 0xb576dc: mov             x0, x3
    // 0xb576e0: LoadField: d1 = r0->field_7
    //     0xb576e0: ldur            d1, [x0, #7]
    // 0xb576e4: stur            d1, [fp, #-0x50]
    // 0xb576e8: r0 = Size()
    //     0xb576e8: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb576ec: ldur            d0, [fp, #-0x50]
    // 0xb576f0: StoreField: r0->field_7 = d0
    //     0xb576f0: stur            d0, [x0, #7]
    // 0xb576f4: ldur            d0, [fp, #-0x58]
    // 0xb576f8: StoreField: r0->field_f = d0
    //     0xb576f8: stur            d0, [x0, #0xf]
    // 0xb576fc: ldur            x1, [fp, #-0x10]
    // 0xb57700: mov             x2, x0
    // 0xb57704: r0 = constrain()
    //     0xb57704: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb57708: LeaveFrame
    //     0xb57708: mov             SP, fp
    //     0xb5770c: ldp             fp, lr, [SP], #0x10
    // 0xb57710: ret
    //     0xb57710: ret             
    // 0xb57714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb57714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb57718: b               #0xb57430
    // 0xb5771c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb5771c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb57720: b               #0xb574cc
    // 0xb57724: r0 = StackOverflowSharedWithFPURegs()
    //     0xb57724: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb57728: b               #0xb574f4
    // 0xb5772c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5772c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb57730: r0 = RangeErrorSharedWithFPURegs()
    //     0xb57730: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58b7c, size: 0x24
    // 0xb58b7c: EnterFrame
    //     0xb58b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xb58b80: mov             fp, SP
    // 0xb58b84: ldr             x2, [fp, #0x10]
    // 0xb58b88: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58b88: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa11f0] AnonymousClosure: (0xb2f798), in [package:flutter/src/rendering/table.dart] RenderTable::computeMaxIntrinsicWidth (0xb2f63c)
    //     0xb58b8c: ldr             x1, [x1, #0x1f0]
    // 0xb58b90: r0 = AllocateClosure()
    //     0xb58b90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58b94: LeaveFrame
    //     0xb58b94: mov             SP, fp
    //     0xb58b98: ldp             fp, lr, [SP], #0x10
    // 0xb58b9c: ret
    //     0xb58b9c: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5cbfc, size: 0xc
    // 0xb5cbfc: LoadField: r0 = r1->field_93
    //     0xb5cbfc: ldur            w0, [x1, #0x93]
    // 0xb5cc00: DecompressPointer r0
    //     0xb5cc00: add             x0, x0, HEAP, lsl #32
    // 0xb5cc04: ret
    //     0xb5cc04: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5ecbc, size: 0x24
    // 0xb5ecbc: EnterFrame
    //     0xb5ecbc: stp             fp, lr, [SP, #-0x10]!
    //     0xb5ecc0: mov             fp, SP
    // 0xb5ecc4: ldr             x2, [fp, #0x10]
    // 0xb5ecc8: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5ecc8: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa11e0] AnonymousClosure: (0xb2c660), in [package:flutter/src/rendering/table.dart] RenderTable::computeMaxIntrinsicHeight (0xb2c630)
    //     0xb5eccc: ldr             x1, [x1, #0x1e0]
    // 0xb5ecd0: r0 = AllocateClosure()
    //     0xb5ecd0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5ecd4: LeaveFrame
    //     0xb5ecd4: mov             SP, fp
    //     0xb5ecd8: ldp             fp, lr, [SP], #0x10
    // 0xb5ecdc: ret
    //     0xb5ecdc: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb677c0, size: 0x308
    // 0xb677c0: EnterFrame
    //     0xb677c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb677c4: mov             fp, SP
    // 0xb677c8: AllocStack(0x78)
    //     0xb677c8: sub             SP, SP, #0x78
    // 0xb677cc: SetupParameters(RenderTable this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb677cc: mov             x5, x1
    //     0xb677d0: mov             x4, x2
    //     0xb677d4: stur            x1, [fp, #-8]
    //     0xb677d8: stur            x2, [fp, #-0x10]
    //     0xb677dc: stur            x3, [fp, #-0x18]
    // 0xb677e0: CheckStackOverflow
    //     0xb677e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb677e4: cmp             SP, x16
    //     0xb677e8: b.ls            #0xb67ab0
    // 0xb677ec: mov             x0, x4
    // 0xb677f0: r2 = Null
    //     0xb677f0: mov             x2, NULL
    // 0xb677f4: r1 = Null
    //     0xb677f4: mov             x1, NULL
    // 0xb677f8: r4 = 60
    //     0xb677f8: mov             x4, #0x3c
    // 0xb677fc: branchIfSmi(r0, 0xb67808)
    //     0xb677fc: tbz             w0, #0, #0xb67808
    // 0xb67800: r4 = LoadClassIdInstr(r0)
    //     0xb67800: ldur            x4, [x0, #-1]
    //     0xb67804: ubfx            x4, x4, #0xc, #0x14
    // 0xb67808: sub             x4, x4, #0xb46
    // 0xb6780c: cmp             x4, #1
    // 0xb67810: b.ls            #0xb67824
    // 0xb67814: r8 = BoxConstraints
    //     0xb67814: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb67818: r3 = Null
    //     0xb67818: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1270] Null
    //     0xb6781c: ldr             x3, [x3, #0x270]
    // 0xb67820: r0 = BoxConstraints()
    //     0xb67820: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb67824: ldur            x0, [fp, #-8]
    // 0xb67828: LoadField: r1 = r0->field_5b
    //     0xb67828: ldur            x1, [x0, #0x5b]
    // 0xb6782c: LoadField: r2 = r0->field_53
    //     0xb6782c: ldur            x2, [x0, #0x53]
    // 0xb67830: mul             x3, x1, x2
    // 0xb67834: cbnz            x3, #0xb67848
    // 0xb67838: r0 = Null
    //     0xb67838: mov             x0, NULL
    // 0xb6783c: LeaveFrame
    //     0xb6783c: mov             SP, fp
    //     0xb67840: ldp             fp, lr, [SP], #0x10
    // 0xb67844: ret
    //     0xb67844: ret             
    // 0xb67848: mov             x1, x0
    // 0xb6784c: ldur            x2, [fp, #-0x10]
    // 0xb67850: r0 = _computeColumnWidths()
    //     0xb67850: bl              #0xb26418  ; [package:flutter/src/rendering/table.dart] RenderTable::_computeColumnWidths
    // 0xb67854: mov             x1, x0
    // 0xb67858: stur            x1, [fp, #-0x30]
    // 0xb6785c: LoadField: r0 = r1->field_b
    //     0xb6785c: ldur            w0, [x1, #0xb]
    // 0xb67860: r2 = LoadInt32Instr(r0)
    //     0xb67860: sbfx            x2, x0, #1, #0x1f
    // 0xb67864: stur            x2, [fp, #-0x28]
    // 0xb67868: r5 = Null
    //     0xb67868: mov             x5, NULL
    // 0xb6786c: r4 = 0
    //     0xb6786c: mov             x4, #0
    // 0xb67870: ldur            x3, [fp, #-8]
    // 0xb67874: stur            x5, [fp, #-0x10]
    // 0xb67878: stur            x4, [fp, #-0x20]
    // 0xb6787c: CheckStackOverflow
    //     0xb6787c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb67880: cmp             SP, x16
    //     0xb67884: b.ls            #0xb67ab8
    // 0xb67888: LoadField: r0 = r3->field_53
    //     0xb67888: ldur            x0, [x3, #0x53]
    // 0xb6788c: cmp             x4, x0
    // 0xb67890: b.ge            #0xb67a9c
    // 0xb67894: LoadField: r0 = r3->field_4f
    //     0xb67894: ldur            w0, [x3, #0x4f]
    // 0xb67898: DecompressPointer r0
    //     0xb67898: add             x0, x0, HEAP, lsl #32
    // 0xb6789c: lsl             x6, x4, #1
    // 0xb678a0: r7 = LoadClassIdInstr(r0)
    //     0xb678a0: ldur            x7, [x0, #-1]
    //     0xb678a4: ubfx            x7, x7, #0xc, #0x14
    // 0xb678a8: stp             x6, x0, [SP]
    // 0xb678ac: mov             x0, x7
    // 0xb678b0: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb678b0: sub             lr, x0, #0xdfd
    //     0xb678b4: ldr             lr, [x21, lr, lsl #3]
    //     0xb678b8: blr             lr
    // 0xb678bc: mov             x2, x0
    // 0xb678c0: ldur            x0, [fp, #-0x28]
    // 0xb678c4: ldur            x1, [fp, #-0x20]
    // 0xb678c8: stur            x2, [fp, #-0x38]
    // 0xb678cc: cmp             x1, x0
    // 0xb678d0: b.hs            #0xb67ac0
    // 0xb678d4: ldur            x0, [fp, #-0x30]
    // 0xb678d8: ldur            x1, [fp, #-0x20]
    // 0xb678dc: ArrayLoad: r3 = r0[r1]  ; Unknown_4
    //     0xb678dc: add             x16, x0, x1, lsl #2
    //     0xb678e0: ldur            w3, [x16, #0xf]
    // 0xb678e4: DecompressPointer r3
    //     0xb678e4: add             x3, x3, HEAP, lsl #32
    // 0xb678e8: LoadField: d0 = r3->field_7
    //     0xb678e8: ldur            d0, [x3, #7]
    // 0xb678ec: stur            d0, [fp, #-0x50]
    // 0xb678f0: r0 = BoxConstraints()
    //     0xb678f0: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb678f4: mov             x3, x0
    // 0xb678f8: ldur            d0, [fp, #-0x50]
    // 0xb678fc: stur            x3, [fp, #-0x48]
    // 0xb67900: StoreField: r3->field_7 = d0
    //     0xb67900: stur            d0, [x3, #7]
    // 0xb67904: StoreField: r3->field_f = d0
    //     0xb67904: stur            d0, [x3, #0xf]
    // 0xb67908: ArrayStore: r3[0] = rZR  ; List_8
    //     0xb67908: stur            xzr, [x3, #0x17]
    // 0xb6790c: d0 = inf
    //     0xb6790c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb67910: StoreField: r3->field_1f = d0
    //     0xb67910: stur            d0, [x3, #0x1f]
    // 0xb67914: ldur            x4, [fp, #-0x38]
    // 0xb67918: cmp             w4, NULL
    // 0xb6791c: b.ne            #0xb67928
    // 0xb67920: ldur            x5, [fp, #-0x10]
    // 0xb67924: b               #0xb67a88
    // 0xb67928: LoadField: r5 = r4->field_7
    //     0xb67928: ldur            w5, [x4, #7]
    // 0xb6792c: DecompressPointer r5
    //     0xb6792c: add             x5, x5, HEAP, lsl #32
    // 0xb67930: stur            x5, [fp, #-0x40]
    // 0xb67934: cmp             w5, NULL
    // 0xb67938: b.eq            #0xb67ac4
    // 0xb6793c: mov             x0, x5
    // 0xb67940: r2 = Null
    //     0xb67940: mov             x2, NULL
    // 0xb67944: r1 = Null
    //     0xb67944: mov             x1, NULL
    // 0xb67948: r4 = LoadClassIdInstr(r0)
    //     0xb67948: ldur            x4, [x0, #-1]
    //     0xb6794c: ubfx            x4, x4, #0xc, #0x14
    // 0xb67950: r17 = 4191
    //     0xb67950: mov             x17, #0x105f
    // 0xb67954: cmp             x4, x17
    // 0xb67958: b.eq            #0xb67970
    // 0xb6795c: r8 = TableCellParentData
    //     0xb6795c: add             x8, PP, #0x84, lsl #12  ; [pp+0x84a98] Type: TableCellParentData
    //     0xb67960: ldr             x8, [x8, #0xa98]
    // 0xb67964: r3 = Null
    //     0xb67964: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1280] Null
    //     0xb67968: ldr             x3, [x3, #0x280]
    // 0xb6796c: r0 = DefaultTypeTest()
    //     0xb6796c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb67970: ldur            x0, [fp, #-0x40]
    // 0xb67974: LoadField: r1 = r0->field_b
    //     0xb67974: ldur            w1, [x0, #0xb]
    // 0xb67978: DecompressPointer r1
    //     0xb67978: add             x1, x1, HEAP, lsl #32
    // 0xb6797c: cmp             w1, NULL
    // 0xb67980: b.ne            #0xb67990
    // 0xb67984: r0 = Instance_TableCellVerticalAlignment
    //     0xb67984: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8ffd0] Obj!TableCellVerticalAlignment@12c4161
    //     0xb67988: ldr             x0, [x0, #0xfd0]
    // 0xb6798c: b               #0xb67994
    // 0xb67990: mov             x0, x1
    // 0xb67994: r16 = Instance_TableCellVerticalAlignment
    //     0xb67994: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1290] Obj!TableCellVerticalAlignment@12c4201
    //     0xb67998: ldr             x16, [x16, #0x290]
    // 0xb6799c: cmp             w0, w16
    // 0xb679a0: b.ne            #0xb679f8
    // 0xb679a4: ldur            x2, [fp, #-0x48]
    // 0xb679a8: ldur            x3, [fp, #-0x18]
    // 0xb679ac: r0 = AllocateRecord2()
    //     0xb679ac: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb679b0: ldur            x2, [fp, #-0x38]
    // 0xb679b4: r1 = Function '_computeDryBaseline@29392247':.
    //     0xb679b4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90868] AnonymousClosure: (0xb196f0), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryBaseline (0xb1972c)
    //     0xb679b8: ldr             x1, [x1, #0x868]
    // 0xb679bc: stur            x0, [fp, #-0x40]
    // 0xb679c0: r0 = AllocateClosure()
    //     0xb679c0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb679c4: r16 = <(BoxConstraints, TextBaseline), double?>
    //     0xb679c4: add             x16, PP, #0x90, lsl #12  ; [pp+0x907f8] TypeArguments: <(BoxConstraints, TextBaseline), double?>
    //     0xb679c8: ldr             x16, [x16, #0x7f8]
    // 0xb679cc: ldur            lr, [fp, #-0x38]
    // 0xb679d0: stp             lr, x16, [SP, #0x18]
    // 0xb679d4: r16 = Instance__Baseline
    //     0xb679d4: add             x16, PP, #0x90, lsl #12  ; [pp+0x90800] Obj!_Baseline@129c181
    //     0xb679d8: ldr             x16, [x16, #0x800]
    // 0xb679dc: ldur            lr, [fp, #-0x40]
    // 0xb679e0: stp             lr, x16, [SP, #8]
    // 0xb679e4: str             x0, [SP]
    // 0xb679e8: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb679e8: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb679ec: r0 = _computeIntrinsics()
    //     0xb679ec: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb679f0: mov             x1, x0
    // 0xb679f4: b               #0xb67a54
    // 0xb679f8: r16 = Instance_TableCellVerticalAlignment
    //     0xb679f8: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa1298] Obj!TableCellVerticalAlignment@12c41e1
    //     0xb679fc: ldr             x16, [x16, #0x298]
    // 0xb67a00: cmp             w0, w16
    // 0xb67a04: b.eq            #0xb67a48
    // 0xb67a08: r16 = Instance_TableCellVerticalAlignment
    //     0xb67a08: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8ffd0] Obj!TableCellVerticalAlignment@12c4161
    //     0xb67a0c: ldr             x16, [x16, #0xfd0]
    // 0xb67a10: cmp             w0, w16
    // 0xb67a14: b.eq            #0xb67a48
    // 0xb67a18: r16 = Instance_TableCellVerticalAlignment
    //     0xb67a18: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa12a0] Obj!TableCellVerticalAlignment@12c41c1
    //     0xb67a1c: ldr             x16, [x16, #0x2a0]
    // 0xb67a20: cmp             w0, w16
    // 0xb67a24: b.eq            #0xb67a48
    // 0xb67a28: r16 = Instance_TableCellVerticalAlignment
    //     0xb67a28: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa12a8] Obj!TableCellVerticalAlignment@12c41a1
    //     0xb67a2c: ldr             x16, [x16, #0x2a8]
    // 0xb67a30: cmp             w0, w16
    // 0xb67a34: b.eq            #0xb67a48
    // 0xb67a38: r16 = Instance_TableCellVerticalAlignment
    //     0xb67a38: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa12b0] Obj!TableCellVerticalAlignment@12c4181
    //     0xb67a3c: ldr             x16, [x16, #0x2b0]
    // 0xb67a40: cmp             w0, w16
    // 0xb67a44: b.ne            #0xb67a50
    // 0xb67a48: r1 = Null
    //     0xb67a48: mov             x1, NULL
    // 0xb67a4c: b               #0xb67a54
    // 0xb67a50: r1 = Null
    //     0xb67a50: mov             x1, NULL
    // 0xb67a54: cmp             w1, NULL
    // 0xb67a58: b.eq            #0xb67a7c
    // 0xb67a5c: ldur            x2, [fp, #-0x10]
    // 0xb67a60: cmp             w2, NULL
    // 0xb67a64: b.eq            #0xb67a84
    // 0xb67a68: LoadField: d0 = r1->field_7
    //     0xb67a68: ldur            d0, [x1, #7]
    // 0xb67a6c: LoadField: d1 = r2->field_7
    //     0xb67a6c: ldur            d1, [x2, #7]
    // 0xb67a70: fcmp            d0, d1
    // 0xb67a74: b.le            #0xb67a80
    // 0xb67a78: b               #0xb67a84
    // 0xb67a7c: ldur            x2, [fp, #-0x10]
    // 0xb67a80: mov             x1, x2
    // 0xb67a84: mov             x5, x1
    // 0xb67a88: ldur            x1, [fp, #-0x20]
    // 0xb67a8c: add             x4, x1, #1
    // 0xb67a90: ldur            x1, [fp, #-0x30]
    // 0xb67a94: ldur            x2, [fp, #-0x28]
    // 0xb67a98: b               #0xb67870
    // 0xb67a9c: mov             x2, x5
    // 0xb67aa0: mov             x0, x2
    // 0xb67aa4: LeaveFrame
    //     0xb67aa4: mov             SP, fp
    //     0xb67aa8: ldp             fp, lr, [SP], #0x10
    // 0xb67aac: ret
    //     0xb67aac: ret             
    // 0xb67ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb67ab0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb67ab4: b               #0xb677ec
    // 0xb67ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb67ab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb67abc: b               #0xb67888
    // 0xb67ac0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb67ac0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb67ac4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb67ac4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ setFlatChildren(/* No info */) {
    // ** addr: 0xb90ec0, size: 0x68c
    // 0xb90ec0: EnterFrame
    //     0xb90ec0: stp             fp, lr, [SP, #-0x10]!
    //     0xb90ec4: mov             fp, SP
    // 0xb90ec8: AllocStack(0x58)
    //     0xb90ec8: sub             SP, SP, #0x58
    // 0xb90ecc: SetupParameters(RenderTable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */)
    //     0xb90ecc: mov             x0, x2
    //     0xb90ed0: stur            x2, [fp, #-0x18]
    //     0xb90ed4: mov             x2, x3
    //     0xb90ed8: stur            x3, [fp, #-0x20]
    //     0xb90edc: mov             x3, x1
    //     0xb90ee0: stur            x1, [fp, #-8]
    // 0xb90ee4: CheckStackOverflow
    //     0xb90ee4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb90ee8: cmp             SP, x16
    //     0xb90eec: b.ls            #0xb914e4
    // 0xb90ef0: LoadField: r1 = r3->field_4f
    //     0xb90ef0: ldur            w1, [x3, #0x4f]
    // 0xb90ef4: DecompressPointer r1
    //     0xb90ef4: add             x1, x1, HEAP, lsl #32
    // 0xb90ef8: cmp             w2, w1
    // 0xb90efc: b.ne            #0xb90f1c
    // 0xb90f00: LoadField: r4 = r3->field_53
    //     0xb90f00: ldur            x4, [x3, #0x53]
    // 0xb90f04: cmp             x0, x4
    // 0xb90f08: b.ne            #0xb90f1c
    // 0xb90f0c: r0 = Null
    //     0xb90f0c: mov             x0, NULL
    // 0xb90f10: LeaveFrame
    //     0xb90f10: mov             SP, fp
    //     0xb90f14: ldp             fp, lr, [SP], #0x10
    // 0xb90f18: ret
    //     0xb90f18: ret             
    // 0xb90f1c: cbz             x0, #0xb90f28
    // 0xb90f20: LoadField: r4 = r2->field_b
    //     0xb90f20: ldur            w4, [x2, #0xb]
    // 0xb90f24: cbnz            w4, #0xb91040
    // 0xb90f28: StoreField: r3->field_53 = r0
    //     0xb90f28: stur            x0, [x3, #0x53]
    // 0xb90f2c: r0 = LoadClassIdInstr(r1)
    //     0xb90f2c: ldur            x0, [x1, #-1]
    //     0xb90f30: ubfx            x0, x0, #0xc, #0x14
    // 0xb90f34: r0 = GDT[cid_x0 + 0x12b36]()
    //     0xb90f34: mov             x17, #0x2b36
    //     0xb90f38: movk            x17, #1, lsl #16
    //     0xb90f3c: add             lr, x0, x17
    //     0xb90f40: ldr             lr, [x21, lr, lsl #3]
    //     0xb90f44: blr             lr
    // 0xb90f48: tbnz            w0, #4, #0xb90f5c
    // 0xb90f4c: r0 = Null
    //     0xb90f4c: mov             x0, NULL
    // 0xb90f50: LeaveFrame
    //     0xb90f50: mov             SP, fp
    //     0xb90f54: ldp             fp, lr, [SP], #0x10
    // 0xb90f58: ret
    //     0xb90f58: ret             
    // 0xb90f5c: ldur            x2, [fp, #-8]
    // 0xb90f60: LoadField: r1 = r2->field_4f
    //     0xb90f60: ldur            w1, [x2, #0x4f]
    // 0xb90f64: DecompressPointer r1
    //     0xb90f64: add             x1, x1, HEAP, lsl #32
    // 0xb90f68: r0 = LoadClassIdInstr(r1)
    //     0xb90f68: ldur            x0, [x1, #-1]
    //     0xb90f6c: ubfx            x0, x0, #0xc, #0x14
    // 0xb90f70: r0 = GDT[cid_x0 + 0x12641]()
    //     0xb90f70: mov             x17, #0x2641
    //     0xb90f74: movk            x17, #1, lsl #16
    //     0xb90f78: add             lr, x0, x17
    //     0xb90f7c: ldr             lr, [x21, lr, lsl #3]
    //     0xb90f80: blr             lr
    // 0xb90f84: mov             x2, x0
    // 0xb90f88: stur            x2, [fp, #-0x10]
    // 0xb90f8c: CheckStackOverflow
    //     0xb90f8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb90f90: cmp             SP, x16
    //     0xb90f94: b.ls            #0xb914ec
    // 0xb90f98: r0 = LoadClassIdInstr(r2)
    //     0xb90f98: ldur            x0, [x2, #-1]
    //     0xb90f9c: ubfx            x0, x0, #0xc, #0x14
    // 0xb90fa0: mov             x1, x2
    // 0xb90fa4: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xb90fa4: mov             x17, #0x845b
    //     0xb90fa8: movk            x17, #1, lsl #16
    //     0xb90fac: add             lr, x0, x17
    //     0xb90fb0: ldr             lr, [x21, lr, lsl #3]
    //     0xb90fb4: blr             lr
    // 0xb90fb8: tbnz            w0, #4, #0xb90ffc
    // 0xb90fbc: ldur            x2, [fp, #-0x10]
    // 0xb90fc0: r0 = LoadClassIdInstr(r2)
    //     0xb90fc0: ldur            x0, [x2, #-1]
    //     0xb90fc4: ubfx            x0, x0, #0xc, #0x14
    // 0xb90fc8: mov             x1, x2
    // 0xb90fcc: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xb90fcc: mov             x17, #0x7d4c
    //     0xb90fd0: movk            x17, #1, lsl #16
    //     0xb90fd4: add             lr, x0, x17
    //     0xb90fd8: ldr             lr, [x21, lr, lsl #3]
    //     0xb90fdc: blr             lr
    // 0xb90fe0: cmp             w0, NULL
    // 0xb90fe4: b.eq            #0xb90ff4
    // 0xb90fe8: ldur            x1, [fp, #-8]
    // 0xb90fec: mov             x2, x0
    // 0xb90ff0: r0 = dropChild()
    //     0xb90ff0: bl              #0xbee868  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0xb90ff4: ldur            x2, [fp, #-0x10]
    // 0xb90ff8: b               #0xb90f8c
    // 0xb90ffc: ldur            x2, [fp, #-8]
    // 0xb91000: StoreField: r2->field_5b = rZR
    //     0xb91000: stur            xzr, [x2, #0x5b]
    // 0xb91004: LoadField: r1 = r2->field_4f
    //     0xb91004: ldur            w1, [x2, #0x4f]
    // 0xb91008: DecompressPointer r1
    //     0xb91008: add             x1, x1, HEAP, lsl #32
    // 0xb9100c: r0 = LoadClassIdInstr(r1)
    //     0xb9100c: ldur            x0, [x1, #-1]
    //     0xb91010: ubfx            x0, x0, #0xc, #0x14
    // 0xb91014: r0 = GDT[cid_x0 + 0x16a12]()
    //     0xb91014: mov             x17, #0x6a12
    //     0xb91018: movk            x17, #1, lsl #16
    //     0xb9101c: add             lr, x0, x17
    //     0xb91020: ldr             lr, [x21, lr, lsl #3]
    //     0xb91024: blr             lr
    // 0xb91028: ldur            x1, [fp, #-8]
    // 0xb9102c: r0 = markNeedsLayout()
    //     0xb9102c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xb91030: r0 = Null
    //     0xb91030: mov             x0, NULL
    // 0xb91034: LeaveFrame
    //     0xb91034: mov             SP, fp
    //     0xb91038: ldp             fp, lr, [SP], #0x10
    // 0xb9103c: ret
    //     0xb9103c: ret             
    // 0xb91040: r1 = <RenderBox>
    //     0xb91040: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xb91044: ldr             x1, [x1, #0x5c8]
    // 0xb91048: r0 = _HashSet()
    //     0xb91048: bl              #0x89f6f0  ; Allocate_HashSetStub -> _HashSet<X0> (size=0x20)
    // 0xb9104c: stur            x0, [fp, #-0x10]
    // 0xb91050: StoreField: r0->field_f = rZR
    //     0xb91050: stur            xzr, [x0, #0xf]
    // 0xb91054: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb91054: stur            xzr, [x0, #0x17]
    // 0xb91058: r1 = <_HashSetEntry<RenderBox>?>
    //     0xb91058: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1488] TypeArguments: <_HashSetEntry<RenderBox>?>
    //     0xb9105c: ldr             x1, [x1, #0x488]
    // 0xb91060: r2 = 16
    //     0xb91060: mov             x2, #0x10
    // 0xb91064: r0 = AllocateArray()
    //     0xb91064: bl              #0x13df928  ; AllocateArrayStub
    // 0xb91068: ldur            x2, [fp, #-0x10]
    // 0xb9106c: StoreField: r2->field_b = r0
    //     0xb9106c: stur            w0, [x2, #0xb]
    // 0xb91070: r6 = 0
    //     0xb91070: mov             x6, #0
    // 0xb91074: ldur            x5, [fp, #-8]
    // 0xb91078: ldur            x4, [fp, #-0x18]
    // 0xb9107c: ldur            x3, [fp, #-0x20]
    // 0xb91080: stur            x6, [fp, #-0x48]
    // 0xb91084: CheckStackOverflow
    //     0xb91084: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb91088: cmp             SP, x16
    //     0xb9108c: b.ls            #0xb914f4
    // 0xb91090: LoadField: r0 = r5->field_5b
    //     0xb91090: ldur            x0, [x5, #0x5b]
    // 0xb91094: cmp             x6, x0
    // 0xb91098: b.ge            #0xb9123c
    // 0xb9109c: mul             x7, x6, x4
    // 0xb910a0: stur            x7, [fp, #-0x40]
    // 0xb910a4: r8 = 0
    //     0xb910a4: mov             x8, #0
    // 0xb910a8: stur            x8, [fp, #-0x38]
    // 0xb910ac: CheckStackOverflow
    //     0xb910ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb910b0: cmp             SP, x16
    //     0xb910b4: b.ls            #0xb914fc
    // 0xb910b8: LoadField: r0 = r5->field_53
    //     0xb910b8: ldur            x0, [x5, #0x53]
    // 0xb910bc: cmp             x8, x0
    // 0xb910c0: b.ge            #0xb9122c
    // 0xb910c4: mul             x1, x6, x0
    // 0xb910c8: add             x9, x8, x1
    // 0xb910cc: add             x10, x8, x7
    // 0xb910d0: stur            x10, [fp, #-0x30]
    // 0xb910d4: LoadField: r11 = r5->field_4f
    //     0xb910d4: ldur            w11, [x5, #0x4f]
    // 0xb910d8: DecompressPointer r11
    //     0xb910d8: add             x11, x11, HEAP, lsl #32
    // 0xb910dc: r0 = BoxInt64Instr(r9)
    //     0xb910dc: sbfiz           x0, x9, #1, #0x1f
    //     0xb910e0: cmp             x9, x0, asr #1
    //     0xb910e4: b.eq            #0xb910f0
    //     0xb910e8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb910ec: stur            x9, [x0, #7]
    // 0xb910f0: mov             x1, x0
    // 0xb910f4: stur            x1, [fp, #-0x28]
    // 0xb910f8: r0 = LoadClassIdInstr(r11)
    //     0xb910f8: ldur            x0, [x11, #-1]
    //     0xb910fc: ubfx            x0, x0, #0xc, #0x14
    // 0xb91100: stp             x1, x11, [SP]
    // 0xb91104: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb91104: sub             lr, x0, #0xdfd
    //     0xb91108: ldr             lr, [x21, lr, lsl #3]
    //     0xb9110c: blr             lr
    // 0xb91110: cmp             w0, NULL
    // 0xb91114: b.eq            #0xb91208
    // 0xb91118: ldur            x1, [fp, #-0x18]
    // 0xb9111c: ldur            x2, [fp, #-0x38]
    // 0xb91120: cmp             x2, x1
    // 0xb91124: b.ge            #0xb911c8
    // 0xb91128: ldur            x3, [fp, #-0x20]
    // 0xb9112c: ldur            x4, [fp, #-0x30]
    // 0xb91130: LoadField: r0 = r3->field_b
    //     0xb91130: ldur            w0, [x3, #0xb]
    // 0xb91134: r5 = LoadInt32Instr(r0)
    //     0xb91134: sbfx            x5, x0, #1, #0x1f
    // 0xb91138: cmp             x4, x5
    // 0xb9113c: b.ge            #0xb911c8
    // 0xb91140: ldur            x5, [fp, #-8]
    // 0xb91144: LoadField: r0 = r5->field_4f
    //     0xb91144: ldur            w0, [x5, #0x4f]
    // 0xb91148: DecompressPointer r0
    //     0xb91148: add             x0, x0, HEAP, lsl #32
    // 0xb9114c: r6 = LoadClassIdInstr(r0)
    //     0xb9114c: ldur            x6, [x0, #-1]
    //     0xb91150: ubfx            x6, x6, #0xc, #0x14
    // 0xb91154: ldur            x16, [fp, #-0x28]
    // 0xb91158: stp             x16, x0, [SP]
    // 0xb9115c: mov             x0, x6
    // 0xb91160: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb91160: sub             lr, x0, #0xdfd
    //     0xb91164: ldr             lr, [x21, lr, lsl #3]
    //     0xb91168: blr             lr
    // 0xb9116c: mov             x3, x0
    // 0xb91170: ldur            x2, [fp, #-0x20]
    // 0xb91174: LoadField: r0 = r2->field_b
    //     0xb91174: ldur            w0, [x2, #0xb]
    // 0xb91178: r1 = LoadInt32Instr(r0)
    //     0xb91178: sbfx            x1, x0, #1, #0x1f
    // 0xb9117c: mov             x0, x1
    // 0xb91180: ldur            x1, [fp, #-0x30]
    // 0xb91184: cmp             x1, x0
    // 0xb91188: b.hs            #0xb91504
    // 0xb9118c: LoadField: r0 = r2->field_f
    //     0xb9118c: ldur            w0, [x2, #0xf]
    // 0xb91190: DecompressPointer r0
    //     0xb91190: add             x0, x0, HEAP, lsl #32
    // 0xb91194: ldur            x1, [fp, #-0x30]
    // 0xb91198: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0xb91198: add             x16, x0, x1, lsl #2
    //     0xb9119c: ldur            w4, [x16, #0xf]
    // 0xb911a0: DecompressPointer r4
    //     0xb911a0: add             x4, x4, HEAP, lsl #32
    // 0xb911a4: r0 = 60
    //     0xb911a4: mov             x0, #0x3c
    // 0xb911a8: branchIfSmi(r3, 0xb911b4)
    //     0xb911a8: tbz             w3, #0, #0xb911b4
    // 0xb911ac: r0 = LoadClassIdInstr(r3)
    //     0xb911ac: ldur            x0, [x3, #-1]
    //     0xb911b0: ubfx            x0, x0, #0xc, #0x14
    // 0xb911b4: stp             x4, x3, [SP]
    // 0xb911b8: mov             lr, x0
    // 0xb911bc: ldr             lr, [x21, lr, lsl #3]
    // 0xb911c0: blr             lr
    // 0xb911c4: tbz             w0, #4, #0xb91208
    // 0xb911c8: ldur            x1, [fp, #-8]
    // 0xb911cc: LoadField: r0 = r1->field_4f
    //     0xb911cc: ldur            w0, [x1, #0x4f]
    // 0xb911d0: DecompressPointer r0
    //     0xb911d0: add             x0, x0, HEAP, lsl #32
    // 0xb911d4: r2 = LoadClassIdInstr(r0)
    //     0xb911d4: ldur            x2, [x0, #-1]
    //     0xb911d8: ubfx            x2, x2, #0xc, #0x14
    // 0xb911dc: ldur            x16, [fp, #-0x28]
    // 0xb911e0: stp             x16, x0, [SP]
    // 0xb911e4: mov             x0, x2
    // 0xb911e8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb911e8: sub             lr, x0, #0xdfd
    //     0xb911ec: ldr             lr, [x21, lr, lsl #3]
    //     0xb911f0: blr             lr
    // 0xb911f4: cmp             w0, NULL
    // 0xb911f8: b.eq            #0xb91508
    // 0xb911fc: ldur            x1, [fp, #-0x10]
    // 0xb91200: mov             x2, x0
    // 0xb91204: r0 = add()
    //     0xb91204: bl              #0x1259a30  ; [dart:collection] _HashSet::add
    // 0xb91208: ldur            x0, [fp, #-0x38]
    // 0xb9120c: add             x8, x0, #1
    // 0xb91210: ldur            x5, [fp, #-8]
    // 0xb91214: ldur            x4, [fp, #-0x18]
    // 0xb91218: ldur            x3, [fp, #-0x20]
    // 0xb9121c: ldur            x6, [fp, #-0x48]
    // 0xb91220: ldur            x7, [fp, #-0x40]
    // 0xb91224: ldur            x2, [fp, #-0x10]
    // 0xb91228: b               #0xb910a8
    // 0xb9122c: mov             x0, x6
    // 0xb91230: add             x6, x0, #1
    // 0xb91234: ldur            x2, [fp, #-0x10]
    // 0xb91238: b               #0xb91074
    // 0xb9123c: r5 = 0
    //     0xb9123c: mov             x5, #0
    // 0xb91240: ldur            x2, [fp, #-8]
    // 0xb91244: ldur            x4, [fp, #-0x18]
    // 0xb91248: ldur            x3, [fp, #-0x20]
    // 0xb9124c: stur            x5, [fp, #-0x48]
    // 0xb91250: CheckStackOverflow
    //     0xb91250: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb91254: cmp             SP, x16
    //     0xb91258: b.ls            #0xb9150c
    // 0xb9125c: mul             x6, x5, x4
    // 0xb91260: stur            x6, [fp, #-0x40]
    // 0xb91264: LoadField: r0 = r3->field_b
    //     0xb91264: ldur            w0, [x3, #0xb]
    // 0xb91268: r1 = LoadInt32Instr(r0)
    //     0xb91268: sbfx            x1, x0, #1, #0x1f
    // 0xb9126c: cmp             x6, x1
    // 0xb91270: b.ge            #0xb9145c
    // 0xb91274: r7 = 0
    //     0xb91274: mov             x7, #0
    // 0xb91278: stur            x7, [fp, #-0x38]
    // 0xb9127c: CheckStackOverflow
    //     0xb9127c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb91280: cmp             SP, x16
    //     0xb91284: b.ls            #0xb91514
    // 0xb91288: cmp             x7, x4
    // 0xb9128c: b.ge            #0xb91450
    // 0xb91290: add             x8, x7, x6
    // 0xb91294: stur            x8, [fp, #-0x30]
    // 0xb91298: LoadField: r9 = r2->field_53
    //     0xb91298: ldur            x9, [x2, #0x53]
    // 0xb9129c: mul             x0, x5, x9
    // 0xb912a0: add             x10, x7, x0
    // 0xb912a4: LoadField: r0 = r3->field_b
    //     0xb912a4: ldur            w0, [x3, #0xb]
    // 0xb912a8: r1 = LoadInt32Instr(r0)
    //     0xb912a8: sbfx            x1, x0, #1, #0x1f
    // 0xb912ac: mov             x0, x1
    // 0xb912b0: mov             x1, x8
    // 0xb912b4: cmp             x1, x0
    // 0xb912b8: b.hs            #0xb9151c
    // 0xb912bc: LoadField: r0 = r3->field_f
    //     0xb912bc: ldur            w0, [x3, #0xf]
    // 0xb912c0: DecompressPointer r0
    //     0xb912c0: add             x0, x0, HEAP, lsl #32
    // 0xb912c4: ArrayLoad: r1 = r0[r8]  ; Unknown_4
    //     0xb912c4: add             x16, x0, x8, lsl #2
    //     0xb912c8: ldur            w1, [x16, #0xf]
    // 0xb912cc: DecompressPointer r1
    //     0xb912cc: add             x1, x1, HEAP, lsl #32
    // 0xb912d0: cmp             w1, NULL
    // 0xb912d4: b.eq            #0xb91430
    // 0xb912d8: cmp             x7, x9
    // 0xb912dc: b.lt            #0xb912e8
    // 0xb912e0: mov             x4, x8
    // 0xb912e4: b               #0xb91398
    // 0xb912e8: LoadField: r0 = r2->field_5b
    //     0xb912e8: ldur            x0, [x2, #0x5b]
    // 0xb912ec: cmp             x5, x0
    // 0xb912f0: b.lt            #0xb912fc
    // 0xb912f4: mov             x4, x8
    // 0xb912f8: b               #0xb91398
    // 0xb912fc: LoadField: r9 = r2->field_4f
    //     0xb912fc: ldur            w9, [x2, #0x4f]
    // 0xb91300: DecompressPointer r9
    //     0xb91300: add             x9, x9, HEAP, lsl #32
    // 0xb91304: r0 = BoxInt64Instr(r10)
    //     0xb91304: sbfiz           x0, x10, #1, #0x1f
    //     0xb91308: cmp             x10, x0, asr #1
    //     0xb9130c: b.eq            #0xb91318
    //     0xb91310: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb91314: stur            x10, [x0, #7]
    // 0xb91318: r1 = LoadClassIdInstr(r9)
    //     0xb91318: ldur            x1, [x9, #-1]
    //     0xb9131c: ubfx            x1, x1, #0xc, #0x14
    // 0xb91320: stp             x0, x9, [SP]
    // 0xb91324: mov             x0, x1
    // 0xb91328: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xb91328: sub             lr, x0, #0xdfd
    //     0xb9132c: ldr             lr, [x21, lr, lsl #3]
    //     0xb91330: blr             lr
    // 0xb91334: mov             x3, x0
    // 0xb91338: ldur            x2, [fp, #-0x20]
    // 0xb9133c: LoadField: r0 = r2->field_b
    //     0xb9133c: ldur            w0, [x2, #0xb]
    // 0xb91340: r1 = LoadInt32Instr(r0)
    //     0xb91340: sbfx            x1, x0, #1, #0x1f
    // 0xb91344: mov             x0, x1
    // 0xb91348: ldur            x1, [fp, #-0x30]
    // 0xb9134c: cmp             x1, x0
    // 0xb91350: b.hs            #0xb91520
    // 0xb91354: LoadField: r0 = r2->field_f
    //     0xb91354: ldur            w0, [x2, #0xf]
    // 0xb91358: DecompressPointer r0
    //     0xb91358: add             x0, x0, HEAP, lsl #32
    // 0xb9135c: ldur            x1, [fp, #-0x30]
    // 0xb91360: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0xb91360: add             x16, x0, x1, lsl #2
    //     0xb91364: ldur            w4, [x16, #0xf]
    // 0xb91368: DecompressPointer r4
    //     0xb91368: add             x4, x4, HEAP, lsl #32
    // 0xb9136c: r0 = 60
    //     0xb9136c: mov             x0, #0x3c
    // 0xb91370: branchIfSmi(r3, 0xb9137c)
    //     0xb91370: tbz             w3, #0, #0xb9137c
    // 0xb91374: r0 = LoadClassIdInstr(r3)
    //     0xb91374: ldur            x0, [x3, #-1]
    //     0xb91378: ubfx            x0, x0, #0xc, #0x14
    // 0xb9137c: stp             x4, x3, [SP]
    // 0xb91380: mov             lr, x0
    // 0xb91384: ldr             lr, [x21, lr, lsl #3]
    // 0xb91388: blr             lr
    // 0xb9138c: tbz             w0, #4, #0xb91430
    // 0xb91390: ldur            x3, [fp, #-0x20]
    // 0xb91394: ldur            x4, [fp, #-0x30]
    // 0xb91398: LoadField: r0 = r3->field_b
    //     0xb91398: ldur            w0, [x3, #0xb]
    // 0xb9139c: r1 = LoadInt32Instr(r0)
    //     0xb9139c: sbfx            x1, x0, #1, #0x1f
    // 0xb913a0: mov             x0, x1
    // 0xb913a4: mov             x1, x4
    // 0xb913a8: cmp             x1, x0
    // 0xb913ac: b.hs            #0xb91524
    // 0xb913b0: LoadField: r0 = r3->field_f
    //     0xb913b0: ldur            w0, [x3, #0xf]
    // 0xb913b4: DecompressPointer r0
    //     0xb913b4: add             x0, x0, HEAP, lsl #32
    // 0xb913b8: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0xb913b8: add             x16, x0, x4, lsl #2
    //     0xb913bc: ldur            w5, [x16, #0xf]
    // 0xb913c0: DecompressPointer r5
    //     0xb913c0: add             x5, x5, HEAP, lsl #32
    // 0xb913c4: ldur            x1, [fp, #-0x10]
    // 0xb913c8: mov             x2, x5
    // 0xb913cc: stur            x5, [fp, #-0x28]
    // 0xb913d0: r0 = _hashCode()
    //     0xb913d0: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0xb913d4: ldur            x1, [fp, #-0x10]
    // 0xb913d8: ldur            x2, [fp, #-0x28]
    // 0xb913dc: mov             x3, x0
    // 0xb913e0: r0 = _remove()
    //     0xb913e0: bl              #0xb9154c  ; [dart:collection] _HashSet::_remove
    // 0xb913e4: tbz             w0, #4, #0xb91430
    // 0xb913e8: ldur            x3, [fp, #-0x20]
    // 0xb913ec: ldur            x2, [fp, #-0x30]
    // 0xb913f0: LoadField: r0 = r3->field_b
    //     0xb913f0: ldur            w0, [x3, #0xb]
    // 0xb913f4: r1 = LoadInt32Instr(r0)
    //     0xb913f4: sbfx            x1, x0, #1, #0x1f
    // 0xb913f8: mov             x0, x1
    // 0xb913fc: mov             x1, x2
    // 0xb91400: cmp             x1, x0
    // 0xb91404: b.hs            #0xb91528
    // 0xb91408: LoadField: r0 = r3->field_f
    //     0xb91408: ldur            w0, [x3, #0xf]
    // 0xb9140c: DecompressPointer r0
    //     0xb9140c: add             x0, x0, HEAP, lsl #32
    // 0xb91410: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0xb91410: add             x16, x0, x2, lsl #2
    //     0xb91414: ldur            w1, [x16, #0xf]
    // 0xb91418: DecompressPointer r1
    //     0xb91418: add             x1, x1, HEAP, lsl #32
    // 0xb9141c: cmp             w1, NULL
    // 0xb91420: b.eq            #0xb9152c
    // 0xb91424: mov             x2, x1
    // 0xb91428: ldur            x1, [fp, #-8]
    // 0xb9142c: r0 = adoptChild()
    //     0xb9142c: bl              #0xc05494  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0xb91430: ldur            x0, [fp, #-0x38]
    // 0xb91434: add             x7, x0, #1
    // 0xb91438: ldur            x2, [fp, #-8]
    // 0xb9143c: ldur            x4, [fp, #-0x18]
    // 0xb91440: ldur            x3, [fp, #-0x20]
    // 0xb91444: ldur            x5, [fp, #-0x48]
    // 0xb91448: ldur            x6, [fp, #-0x40]
    // 0xb9144c: b               #0xb91278
    // 0xb91450: mov             x0, x5
    // 0xb91454: add             x5, x0, #1
    // 0xb91458: b               #0xb91240
    // 0xb9145c: mov             x0, x3
    // 0xb91460: mov             x3, x2
    // 0xb91464: mov             x2, x3
    // 0xb91468: r1 = Function 'dropChild':.
    //     0xb91468: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1490] AnonymousClosure: (0xb918c8), in [package:flutter/src/rendering/object.dart] RenderObject::dropChild (0xbee868)
    //     0xb9146c: ldr             x1, [x1, #0x490]
    // 0xb91470: r0 = AllocateClosure()
    //     0xb91470: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb91474: ldur            x1, [fp, #-0x10]
    // 0xb91478: mov             x2, x0
    // 0xb9147c: r0 = forEach()
    //     0xb9147c: bl              #0xb009e8  ; [dart:collection] SetBase::forEach
    // 0xb91480: ldur            x0, [fp, #-8]
    // 0xb91484: ldur            x1, [fp, #-0x18]
    // 0xb91488: StoreField: r0->field_53 = r1
    //     0xb91488: stur            x1, [x0, #0x53]
    // 0xb9148c: ldur            x2, [fp, #-0x20]
    // 0xb91490: LoadField: r3 = r2->field_b
    //     0xb91490: ldur            w3, [x2, #0xb]
    // 0xb91494: r4 = LoadInt32Instr(r3)
    //     0xb91494: sbfx            x4, x3, #1, #0x1f
    // 0xb91498: cbz             x1, #0xb91530
    // 0xb9149c: sdiv            x3, x4, x1
    // 0xb914a0: StoreField: r0->field_5b = r3
    //     0xb914a0: stur            x3, [x0, #0x5b]
    // 0xb914a4: r1 = <RenderBox?>
    //     0xb914a4: add             x1, PP, #0x96, lsl #12  ; [pp+0x96d80] TypeArguments: <RenderBox?>
    //     0xb914a8: ldr             x1, [x1, #0xd80]
    // 0xb914ac: r0 = _GrowableList._ofGrowableList()
    //     0xb914ac: bl              #0x7d7558  ; [dart:core] _GrowableList::_GrowableList._ofGrowableList
    // 0xb914b0: ldur            x1, [fp, #-8]
    // 0xb914b4: StoreField: r1->field_4f = r0
    //     0xb914b4: stur            w0, [x1, #0x4f]
    //     0xb914b8: ldurb           w16, [x1, #-1]
    //     0xb914bc: ldurb           w17, [x0, #-1]
    //     0xb914c0: and             x16, x17, x16, lsr #2
    //     0xb914c4: tst             x16, HEAP, lsr #32
    //     0xb914c8: b.eq            #0xb914d0
    //     0xb914cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb914d0: r0 = markNeedsLayout()
    //     0xb914d0: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xb914d4: r0 = Null
    //     0xb914d4: mov             x0, NULL
    // 0xb914d8: LeaveFrame
    //     0xb914d8: mov             SP, fp
    //     0xb914dc: ldp             fp, lr, [SP], #0x10
    // 0xb914e0: ret
    //     0xb914e0: ret             
    // 0xb914e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb914e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb914e8: b               #0xb90ef0
    // 0xb914ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb914ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb914f0: b               #0xb90f98
    // 0xb914f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb914f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb914f8: b               #0xb91090
    // 0xb914fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb914fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb91500: b               #0xb910b8
    // 0xb91504: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb91504: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb91508: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb91508: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb9150c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9150c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb91510: b               #0xb9125c
    // 0xb91514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb91514: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb91518: b               #0xb91288
    // 0xb9151c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb9151c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb91520: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb91520: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb91524: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb91524: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb91528: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb91528: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb9152c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb9152c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb91530: stp             x2, x4, [SP, #-0x10]!
    // 0xb91534: stp             x0, x1, [SP, #-0x10]!
    // 0xb91538: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xb9153c: r4 = 0
    //     0xb9153c: mov             x4, #0
    // 0xb91540: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xb91544: blr             lr
    // 0xb91548: brk             #0
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbe1944, size: 0x11c0
    // 0xbe1944: EnterFrame
    //     0xbe1944: stp             fp, lr, [SP, #-0x10]!
    //     0xbe1948: mov             fp, SP
    // 0xbe194c: AllocStack(0xd0)
    //     0xbe194c: sub             SP, SP, #0xd0
    // 0xbe1950: SetupParameters(RenderTable this /* r1 => r3, fp-0x10 */)
    //     0xbe1950: mov             x3, x1
    //     0xbe1954: stur            x1, [fp, #-0x10]
    // 0xbe1958: CheckStackOverflow
    //     0xbe1958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe195c: cmp             SP, x16
    //     0xbe1960: b.ls            #0xbe29b8
    // 0xbe1964: LoadField: r4 = r3->field_27
    //     0xbe1964: ldur            w4, [x3, #0x27]
    // 0xbe1968: DecompressPointer r4
    //     0xbe1968: add             x4, x4, HEAP, lsl #32
    // 0xbe196c: stur            x4, [fp, #-8]
    // 0xbe1970: cmp             w4, NULL
    // 0xbe1974: b.eq            #0xbe26bc
    // 0xbe1978: mov             x0, x4
    // 0xbe197c: r2 = Null
    //     0xbe197c: mov             x2, NULL
    // 0xbe1980: r1 = Null
    //     0xbe1980: mov             x1, NULL
    // 0xbe1984: r4 = LoadClassIdInstr(r0)
    //     0xbe1984: ldur            x4, [x0, #-1]
    //     0xbe1988: ubfx            x4, x4, #0xc, #0x14
    // 0xbe198c: sub             x4, x4, #0xb46
    // 0xbe1990: cmp             x4, #1
    // 0xbe1994: b.ls            #0xbe19a8
    // 0xbe1998: r8 = BoxConstraints
    //     0xbe1998: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbe199c: r3 = Null
    //     0xbe199c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1220] Null
    //     0xbe19a0: ldr             x3, [x3, #0x220]
    // 0xbe19a4: r0 = BoxConstraints()
    //     0xbe19a4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbe19a8: ldur            x0, [fp, #-0x10]
    // 0xbe19ac: LoadField: r3 = r0->field_5b
    //     0xbe19ac: ldur            x3, [x0, #0x5b]
    // 0xbe19b0: stur            x3, [fp, #-0x20]
    // 0xbe19b4: LoadField: r4 = r0->field_53
    //     0xbe19b4: ldur            x4, [x0, #0x53]
    // 0xbe19b8: stur            x4, [fp, #-0x18]
    // 0xbe19bc: mul             x1, x3, x4
    // 0xbe19c0: cbnz            x1, #0xbe1a08
    // 0xbe19c4: r5 = 0.000000
    //     0xbe19c4: ldr             x5, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe19c8: StoreField: r0->field_9f = r5
    //     0xbe19c8: stur            w5, [x0, #0x9f]
    // 0xbe19cc: ldur            x1, [fp, #-8]
    // 0xbe19d0: r2 = Instance_Size
    //     0xbe19d0: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xbe19d4: r0 = constrain()
    //     0xbe19d4: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbe19d8: ldur            x6, [fp, #-0x10]
    // 0xbe19dc: StoreField: r6->field_4b = r0
    //     0xbe19dc: stur            w0, [x6, #0x4b]
    //     0xbe19e0: ldurb           w16, [x6, #-1]
    //     0xbe19e4: ldurb           w17, [x0, #-1]
    //     0xbe19e8: and             x16, x17, x16, lsr #2
    //     0xbe19ec: tst             x16, HEAP, lsr #32
    //     0xbe19f0: b.eq            #0xbe19f8
    //     0xbe19f4: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0xbe19f8: r0 = Null
    //     0xbe19f8: mov             x0, NULL
    // 0xbe19fc: LeaveFrame
    //     0xbe19fc: mov             SP, fp
    //     0xbe1a00: ldp             fp, lr, [SP], #0x10
    // 0xbe1a04: ret
    //     0xbe1a04: ret             
    // 0xbe1a08: mov             x6, x0
    // 0xbe1a0c: r5 = 0.000000
    //     0xbe1a0c: ldr             x5, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe1a10: mov             x1, x6
    // 0xbe1a14: ldur            x2, [fp, #-8]
    // 0xbe1a18: r0 = _computeColumnWidths()
    //     0xbe1a18: bl              #0xb26418  ; [package:flutter/src/rendering/table.dart] RenderTable::_computeColumnWidths
    // 0xbe1a1c: ldur            x2, [fp, #-0x18]
    // 0xbe1a20: r1 = <double>
    //     0xbe1a20: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xbe1a24: r3 = 0.000000
    //     0xbe1a24: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe1a28: stur            x0, [fp, #-0x28]
    // 0xbe1a2c: r0 = _List.filled()
    //     0xbe1a2c: bl              #0x7f3644  ; [dart:core] _List::_List.filled
    // 0xbe1a30: ldur            x1, [fp, #-0x10]
    // 0xbe1a34: stur            x0, [fp, #-0x30]
    // 0xbe1a38: r0 = name()
    //     0xbe1a38: bl              #0x1311c24  ; [package:get/get_navigation/src/routes/get_route.dart] GetPage::name
    // 0xbe1a3c: LoadField: r1 = r0->field_7
    //     0xbe1a3c: ldur            x1, [x0, #7]
    // 0xbe1a40: cmp             x1, #0
    // 0xbe1a44: b.gt            #0xbe1c3c
    // 0xbe1a48: ldur            x3, [fp, #-0x28]
    // 0xbe1a4c: ldur            x2, [fp, #-0x30]
    // 0xbe1a50: ldur            x4, [fp, #-0x18]
    // 0xbe1a54: sub             x5, x4, #1
    // 0xbe1a58: mov             x0, x4
    // 0xbe1a5c: mov             x1, x5
    // 0xbe1a60: cmp             x1, x0
    // 0xbe1a64: b.hs            #0xbe29c0
    // 0xbe1a68: add             x0, x2, x5, lsl #2
    // 0xbe1a6c: r16 = 0.000000
    //     0xbe1a6c: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe1a70: StoreField: r0->field_f = r16
    //     0xbe1a70: stur            w16, [x0, #0xf]
    // 0xbe1a74: sub             x0, x4, #2
    // 0xbe1a78: LoadField: r5 = r3->field_b
    //     0xbe1a78: ldur            w5, [x3, #0xb]
    // 0xbe1a7c: stur            x5, [fp, #-0x38]
    // 0xbe1a80: r6 = LoadInt32Instr(r5)
    //     0xbe1a80: sbfx            x6, x5, #1, #0x1f
    // 0xbe1a84: mov             x7, x0
    // 0xbe1a88: CheckStackOverflow
    //     0xbe1a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe1a8c: cmp             SP, x16
    //     0xbe1a90: b.ls            #0xbe29c4
    // 0xbe1a94: tbnz            x7, #0x3f, #0xbe1b54
    // 0xbe1a98: add             x8, x7, #1
    // 0xbe1a9c: mov             x0, x4
    // 0xbe1aa0: mov             x1, x8
    // 0xbe1aa4: cmp             x1, x0
    // 0xbe1aa8: b.hs            #0xbe29cc
    // 0xbe1aac: ArrayLoad: r9 = r2[r8]  ; Unknown_4
    //     0xbe1aac: add             x16, x2, x8, lsl #2
    //     0xbe1ab0: ldur            w9, [x16, #0xf]
    // 0xbe1ab4: DecompressPointer r9
    //     0xbe1ab4: add             x9, x9, HEAP, lsl #32
    // 0xbe1ab8: mov             x0, x6
    // 0xbe1abc: mov             x1, x8
    // 0xbe1ac0: cmp             x1, x0
    // 0xbe1ac4: b.hs            #0xbe29d0
    // 0xbe1ac8: ArrayLoad: r0 = r3[r8]  ; Unknown_4
    //     0xbe1ac8: add             x16, x3, x8, lsl #2
    //     0xbe1acc: ldur            w0, [x16, #0xf]
    // 0xbe1ad0: DecompressPointer r0
    //     0xbe1ad0: add             x0, x0, HEAP, lsl #32
    // 0xbe1ad4: LoadField: d0 = r9->field_7
    //     0xbe1ad4: ldur            d0, [x9, #7]
    // 0xbe1ad8: LoadField: d1 = r0->field_7
    //     0xbe1ad8: ldur            d1, [x0, #7]
    // 0xbe1adc: fadd            d2, d0, d1
    // 0xbe1ae0: mov             x0, x4
    // 0xbe1ae4: mov             x1, x7
    // 0xbe1ae8: cmp             x1, x0
    // 0xbe1aec: b.hs            #0xbe29d4
    // 0xbe1af0: r0 = inline_Allocate_Double()
    //     0xbe1af0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe1af4: add             x0, x0, #0x10
    //     0xbe1af8: cmp             x1, x0
    //     0xbe1afc: b.ls            #0xbe29d8
    //     0xbe1b00: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe1b04: sub             x0, x0, #0xf
    //     0xbe1b08: mov             x1, #0xe19c
    //     0xbe1b0c: movk            x1, #3, lsl #16
    //     0xbe1b10: stur            x1, [x0, #-1]
    // 0xbe1b14: dmb             ishst
    // 0xbe1b18: StoreField: r0->field_7 = d2
    //     0xbe1b18: stur            d2, [x0, #7]
    // 0xbe1b1c: mov             x1, x2
    // 0xbe1b20: ArrayStore: r1[r7] = r0  ; List_4
    //     0xbe1b20: add             x25, x1, x7, lsl #2
    //     0xbe1b24: add             x25, x25, #0xf
    //     0xbe1b28: str             w0, [x25]
    //     0xbe1b2c: tbz             w0, #0, #0xbe1b48
    //     0xbe1b30: ldurb           w16, [x1, #-1]
    //     0xbe1b34: ldurb           w17, [x0, #-1]
    //     0xbe1b38: and             x16, x17, x16, lsr #2
    //     0xbe1b3c: tst             x16, HEAP, lsr #32
    //     0xbe1b40: b.eq            #0xbe1b48
    //     0xbe1b44: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe1b48: sub             x0, x7, #1
    // 0xbe1b4c: mov             x7, x0
    // 0xbe1b50: b               #0xbe1a88
    // 0xbe1b54: ldur            x0, [fp, #-0x10]
    // 0xbe1b58: r1 = <double>
    //     0xbe1b58: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xbe1b5c: r0 = ReversedListIterable()
    //     0xbe1b5c: bl              #0x7da320  ; AllocateReversedListIterableStub -> ReversedListIterable<X0> (size=0x10)
    // 0xbe1b60: ldur            x2, [fp, #-0x30]
    // 0xbe1b64: StoreField: r0->field_b = r2
    //     0xbe1b64: stur            w2, [x0, #0xb]
    // 0xbe1b68: ldur            x3, [fp, #-0x10]
    // 0xbe1b6c: StoreField: r3->field_9b = r0
    //     0xbe1b6c: stur            w0, [x3, #0x9b]
    //     0xbe1b70: ldurb           w16, [x3, #-1]
    //     0xbe1b74: ldurb           w17, [x0, #-1]
    //     0xbe1b78: and             x16, x17, x16, lsr #2
    //     0xbe1b7c: tst             x16, HEAP, lsr #32
    //     0xbe1b80: b.eq            #0xbe1b88
    //     0xbe1b84: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe1b88: ldur            x4, [fp, #-0x18]
    // 0xbe1b8c: cmp             x4, #0
    // 0xbe1b90: b.le            #0xbe26e4
    // 0xbe1b94: ldur            x5, [fp, #-0x38]
    // 0xbe1b98: mov             x0, x4
    // 0xbe1b9c: r1 = 0
    //     0xbe1b9c: mov             x1, #0
    // 0xbe1ba0: cmp             x1, x0
    // 0xbe1ba4: b.hs            #0xbe2a00
    // 0xbe1ba8: LoadField: r6 = r2->field_f
    //     0xbe1ba8: ldur            w6, [x2, #0xf]
    // 0xbe1bac: DecompressPointer r6
    //     0xbe1bac: add             x6, x6, HEAP, lsl #32
    // 0xbe1bb0: r0 = LoadInt32Instr(r5)
    //     0xbe1bb0: sbfx            x0, x5, #1, #0x1f
    // 0xbe1bb4: cmp             x0, #0
    // 0xbe1bb8: b.le            #0xbe26d8
    // 0xbe1bbc: ldur            x7, [fp, #-0x28]
    // 0xbe1bc0: r1 = 0
    //     0xbe1bc0: mov             x1, #0
    // 0xbe1bc4: cmp             x1, x0
    // 0xbe1bc8: b.hs            #0xbe2a04
    // 0xbe1bcc: LoadField: r0 = r7->field_f
    //     0xbe1bcc: ldur            w0, [x7, #0xf]
    // 0xbe1bd0: DecompressPointer r0
    //     0xbe1bd0: add             x0, x0, HEAP, lsl #32
    // 0xbe1bd4: LoadField: d0 = r6->field_7
    //     0xbe1bd4: ldur            d0, [x6, #7]
    // 0xbe1bd8: LoadField: d1 = r0->field_7
    //     0xbe1bd8: ldur            d1, [x0, #7]
    // 0xbe1bdc: fadd            d2, d0, d1
    // 0xbe1be0: r0 = inline_Allocate_Double()
    //     0xbe1be0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe1be4: add             x0, x0, #0x10
    //     0xbe1be8: cmp             x1, x0
    //     0xbe1bec: b.ls            #0xbe2a08
    //     0xbe1bf0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe1bf4: sub             x0, x0, #0xf
    //     0xbe1bf8: mov             x1, #0xe19c
    //     0xbe1bfc: movk            x1, #3, lsl #16
    //     0xbe1c00: stur            x1, [x0, #-1]
    // 0xbe1c04: dmb             ishst
    // 0xbe1c08: StoreField: r0->field_7 = d2
    //     0xbe1c08: stur            d2, [x0, #7]
    // 0xbe1c0c: StoreField: r3->field_9f = r0
    //     0xbe1c0c: stur            w0, [x3, #0x9f]
    //     0xbe1c10: ldurb           w16, [x3, #-1]
    //     0xbe1c14: ldurb           w17, [x0, #-1]
    //     0xbe1c18: and             x16, x17, x16, lsr #2
    //     0xbe1c1c: tst             x16, HEAP, lsr #32
    //     0xbe1c20: b.eq            #0xbe1c28
    //     0xbe1c24: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe1c28: r0 = LoadInt32Instr(r5)
    //     0xbe1c28: sbfx            x0, x5, #1, #0x1f
    // 0xbe1c2c: mov             x2, x3
    // 0xbe1c30: mov             x3, x0
    // 0xbe1c34: mov             x0, x4
    // 0xbe1c38: b               #0xbe1dc8
    // 0xbe1c3c: ldur            x3, [fp, #-0x10]
    // 0xbe1c40: ldur            x7, [fp, #-0x28]
    // 0xbe1c44: ldur            x2, [fp, #-0x30]
    // 0xbe1c48: ldur            x4, [fp, #-0x18]
    // 0xbe1c4c: mov             x0, x4
    // 0xbe1c50: r1 = 0
    //     0xbe1c50: mov             x1, #0
    // 0xbe1c54: cmp             x1, x0
    // 0xbe1c58: b.hs            #0xbe2a30
    // 0xbe1c5c: r16 = 0.000000
    //     0xbe1c5c: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe1c60: StoreField: r2->field_f = r16
    //     0xbe1c60: stur            w16, [x2, #0xf]
    // 0xbe1c64: LoadField: r5 = r7->field_b
    //     0xbe1c64: ldur            w5, [x7, #0xb]
    // 0xbe1c68: stur            x5, [fp, #-0x38]
    // 0xbe1c6c: r6 = LoadInt32Instr(r5)
    //     0xbe1c6c: sbfx            x6, x5, #1, #0x1f
    // 0xbe1c70: r8 = 1
    //     0xbe1c70: mov             x8, #1
    // 0xbe1c74: CheckStackOverflow
    //     0xbe1c74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe1c78: cmp             SP, x16
    //     0xbe1c7c: b.ls            #0xbe2a34
    // 0xbe1c80: cmp             x8, x4
    // 0xbe1c84: b.ge            #0xbe1d24
    // 0xbe1c88: sub             x9, x8, #1
    // 0xbe1c8c: ArrayLoad: r10 = r2[r9]  ; Unknown_4
    //     0xbe1c8c: add             x16, x2, x9, lsl #2
    //     0xbe1c90: ldur            w10, [x16, #0xf]
    // 0xbe1c94: DecompressPointer r10
    //     0xbe1c94: add             x10, x10, HEAP, lsl #32
    // 0xbe1c98: mov             x0, x6
    // 0xbe1c9c: mov             x1, x9
    // 0xbe1ca0: cmp             x1, x0
    // 0xbe1ca4: b.hs            #0xbe2a3c
    // 0xbe1ca8: ArrayLoad: r0 = r7[r9]  ; Unknown_4
    //     0xbe1ca8: add             x16, x7, x9, lsl #2
    //     0xbe1cac: ldur            w0, [x16, #0xf]
    // 0xbe1cb0: DecompressPointer r0
    //     0xbe1cb0: add             x0, x0, HEAP, lsl #32
    // 0xbe1cb4: LoadField: d0 = r10->field_7
    //     0xbe1cb4: ldur            d0, [x10, #7]
    // 0xbe1cb8: LoadField: d1 = r0->field_7
    //     0xbe1cb8: ldur            d1, [x0, #7]
    // 0xbe1cbc: fadd            d2, d0, d1
    // 0xbe1cc0: r0 = inline_Allocate_Double()
    //     0xbe1cc0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe1cc4: add             x0, x0, #0x10
    //     0xbe1cc8: cmp             x1, x0
    //     0xbe1ccc: b.ls            #0xbe2a40
    //     0xbe1cd0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe1cd4: sub             x0, x0, #0xf
    //     0xbe1cd8: mov             x1, #0xe19c
    //     0xbe1cdc: movk            x1, #3, lsl #16
    //     0xbe1ce0: stur            x1, [x0, #-1]
    // 0xbe1ce4: dmb             ishst
    // 0xbe1ce8: StoreField: r0->field_7 = d2
    //     0xbe1ce8: stur            d2, [x0, #7]
    // 0xbe1cec: mov             x1, x2
    // 0xbe1cf0: ArrayStore: r1[r8] = r0  ; List_4
    //     0xbe1cf0: add             x25, x1, x8, lsl #2
    //     0xbe1cf4: add             x25, x25, #0xf
    //     0xbe1cf8: str             w0, [x25]
    //     0xbe1cfc: tbz             w0, #0, #0xbe1d18
    //     0xbe1d00: ldurb           w16, [x1, #-1]
    //     0xbe1d04: ldurb           w17, [x0, #-1]
    //     0xbe1d08: and             x16, x17, x16, lsr #2
    //     0xbe1d0c: tst             x16, HEAP, lsr #32
    //     0xbe1d10: b.eq            #0xbe1d18
    //     0xbe1d14: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe1d18: add             x0, x8, #1
    // 0xbe1d1c: mov             x8, x0
    // 0xbe1d20: b               #0xbe1c74
    // 0xbe1d24: mov             x0, x2
    // 0xbe1d28: StoreField: r3->field_9b = r0
    //     0xbe1d28: stur            w0, [x3, #0x9b]
    //     0xbe1d2c: ldurb           w16, [x3, #-1]
    //     0xbe1d30: ldurb           w17, [x0, #-1]
    //     0xbe1d34: and             x16, x17, x16, lsr #2
    //     0xbe1d38: tst             x16, HEAP, lsr #32
    //     0xbe1d3c: b.eq            #0xbe1d44
    //     0xbe1d40: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe1d44: mov             x1, x2
    // 0xbe1d48: r0 = last()
    //     0xbe1d48: bl              #0xb227dc  ; [dart:core] _Array::last
    // 0xbe1d4c: ldur            x1, [fp, #-0x28]
    // 0xbe1d50: stur            x0, [fp, #-0x40]
    // 0xbe1d54: r0 = last()
    //     0xbe1d54: bl              #0xb227dc  ; [dart:core] _Array::last
    // 0xbe1d58: mov             x1, x0
    // 0xbe1d5c: ldur            x0, [fp, #-0x40]
    // 0xbe1d60: LoadField: d0 = r0->field_7
    //     0xbe1d60: ldur            d0, [x0, #7]
    // 0xbe1d64: LoadField: d1 = r1->field_7
    //     0xbe1d64: ldur            d1, [x1, #7]
    // 0xbe1d68: fadd            d2, d0, d1
    // 0xbe1d6c: r0 = inline_Allocate_Double()
    //     0xbe1d6c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe1d70: add             x0, x0, #0x10
    //     0xbe1d74: cmp             x1, x0
    //     0xbe1d78: b.ls            #0xbe2a70
    //     0xbe1d7c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe1d80: sub             x0, x0, #0xf
    //     0xbe1d84: mov             x1, #0xe19c
    //     0xbe1d88: movk            x1, #3, lsl #16
    //     0xbe1d8c: stur            x1, [x0, #-1]
    // 0xbe1d90: dmb             ishst
    // 0xbe1d94: StoreField: r0->field_7 = d2
    //     0xbe1d94: stur            d2, [x0, #7]
    // 0xbe1d98: ldur            x2, [fp, #-0x10]
    // 0xbe1d9c: StoreField: r2->field_9f = r0
    //     0xbe1d9c: stur            w0, [x2, #0x9f]
    //     0xbe1da0: ldurb           w16, [x2, #-1]
    //     0xbe1da4: ldurb           w17, [x0, #-1]
    //     0xbe1da8: and             x16, x17, x16, lsr #2
    //     0xbe1dac: tst             x16, HEAP, lsr #32
    //     0xbe1db0: b.eq            #0xbe1db8
    //     0xbe1db4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbe1db8: ldur            x0, [fp, #-0x38]
    // 0xbe1dbc: r1 = LoadInt32Instr(r0)
    //     0xbe1dbc: sbfx            x1, x0, #1, #0x1f
    // 0xbe1dc0: mov             x3, x1
    // 0xbe1dc4: ldur            x0, [fp, #-0x18]
    // 0xbe1dc8: stur            x3, [fp, #-0x48]
    // 0xbe1dcc: LoadField: r4 = r2->field_97
    //     0xbe1dcc: ldur            w4, [x2, #0x97]
    // 0xbe1dd0: DecompressPointer r4
    //     0xbe1dd0: add             x4, x4, HEAP, lsl #32
    // 0xbe1dd4: mov             x1, x4
    // 0xbe1dd8: stur            x4, [fp, #-0x38]
    // 0xbe1ddc: r0 = clear()
    //     0xbe1ddc: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xbe1de0: ldur            x2, [fp, #-0x10]
    // 0xbe1de4: StoreField: r2->field_93 = rNULL
    //     0xbe1de4: stur            NULL, [x2, #0x93]
    // 0xbe1de8: ldur            x3, [fp, #-0x18]
    // 0xbe1dec: r0 = BoxInt64Instr(r3)
    //     0xbe1dec: sbfiz           x0, x3, #1, #0x1f
    //     0xbe1df0: cmp             x3, x0, asr #1
    //     0xbe1df4: b.eq            #0xbe1e00
    //     0xbe1df8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe1dfc: stur            x3, [x0, #7]
    // 0xbe1e00: stur            x0, [fp, #-0x40]
    // 0xbe1e04: ldur            x8, [fp, #-0x48]
    // 0xbe1e08: d0 = 0.000000
    //     0xbe1e08: eor             v0.16b, v0.16b, v0.16b
    // 0xbe1e0c: r9 = 0
    //     0xbe1e0c: mov             x9, #0
    // 0xbe1e10: ldur            x6, [fp, #-0x28]
    // 0xbe1e14: ldur            x5, [fp, #-0x30]
    // 0xbe1e18: ldur            x4, [fp, #-0x38]
    // 0xbe1e1c: ldur            x7, [fp, #-0x20]
    // 0xbe1e20: stur            x9, [fp, #-0x58]
    // 0xbe1e24: stur            x8, [fp, #-0x60]
    // 0xbe1e28: stur            d0, [fp, #-0x98]
    // 0xbe1e2c: CheckStackOverflow
    //     0xbe1e2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe1e30: cmp             SP, x16
    //     0xbe1e34: b.ls            #0xbe2a80
    // 0xbe1e38: cmp             x9, x7
    // 0xbe1e3c: b.ge            #0xbe25a8
    // 0xbe1e40: LoadField: r1 = r4->field_b
    //     0xbe1e40: ldur            w1, [x4, #0xb]
    // 0xbe1e44: LoadField: r10 = r4->field_f
    //     0xbe1e44: ldur            w10, [x4, #0xf]
    // 0xbe1e48: DecompressPointer r10
    //     0xbe1e48: add             x10, x10, HEAP, lsl #32
    // 0xbe1e4c: LoadField: r11 = r10->field_b
    //     0xbe1e4c: ldur            w11, [x10, #0xb]
    // 0xbe1e50: r10 = LoadInt32Instr(r1)
    //     0xbe1e50: sbfx            x10, x1, #1, #0x1f
    // 0xbe1e54: stur            x10, [fp, #-0x50]
    // 0xbe1e58: r1 = LoadInt32Instr(r11)
    //     0xbe1e58: sbfx            x1, x11, #1, #0x1f
    // 0xbe1e5c: cmp             x10, x1
    // 0xbe1e60: b.ne            #0xbe1e6c
    // 0xbe1e64: mov             x1, x4
    // 0xbe1e68: r0 = _growToNextCapacity()
    //     0xbe1e68: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbe1e6c: ldur            x3, [fp, #-0x38]
    // 0xbe1e70: ldur            d0, [fp, #-0x98]
    // 0xbe1e74: ldur            x2, [fp, #-0x50]
    // 0xbe1e78: add             x0, x2, #1
    // 0xbe1e7c: lsl             x1, x0, #1
    // 0xbe1e80: StoreField: r3->field_b = r1
    //     0xbe1e80: stur            w1, [x3, #0xb]
    // 0xbe1e84: LoadField: r1 = r3->field_f
    //     0xbe1e84: ldur            w1, [x3, #0xf]
    // 0xbe1e88: DecompressPointer r1
    //     0xbe1e88: add             x1, x1, HEAP, lsl #32
    // 0xbe1e8c: r0 = inline_Allocate_Double()
    //     0xbe1e8c: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbe1e90: add             x0, x0, #0x10
    //     0xbe1e94: cmp             x4, x0
    //     0xbe1e98: b.ls            #0xbe2a88
    //     0xbe1e9c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe1ea0: sub             x0, x0, #0xf
    //     0xbe1ea4: mov             x4, #0xe19c
    //     0xbe1ea8: movk            x4, #3, lsl #16
    //     0xbe1eac: stur            x4, [x0, #-1]
    // 0xbe1eb0: dmb             ishst
    // 0xbe1eb4: StoreField: r0->field_7 = d0
    //     0xbe1eb4: stur            d0, [x0, #7]
    // 0xbe1eb8: ArrayStore: r1[r2] = r0  ; List_4
    //     0xbe1eb8: add             x25, x1, x2, lsl #2
    //     0xbe1ebc: add             x25, x25, #0xf
    //     0xbe1ec0: str             w0, [x25]
    //     0xbe1ec4: tbz             w0, #0, #0xbe1ee0
    //     0xbe1ec8: ldurb           w16, [x1, #-1]
    //     0xbe1ecc: ldurb           w17, [x0, #-1]
    //     0xbe1ed0: and             x16, x17, x16, lsr #2
    //     0xbe1ed4: tst             x16, HEAP, lsr #32
    //     0xbe1ed8: b.eq            #0xbe1ee0
    //     0xbe1edc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe1ee0: ldur            x2, [fp, #-0x40]
    // 0xbe1ee4: r1 = <double>
    //     0xbe1ee4: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0xbe1ee8: r0 = AllocateArray()
    //     0xbe1ee8: bl              #0x13df928  ; AllocateArrayStub
    // 0xbe1eec: mov             x2, x0
    // 0xbe1ef0: stur            x2, [fp, #-0x78]
    // 0xbe1ef4: ldur            x3, [fp, #-0x18]
    // 0xbe1ef8: r0 = 0
    //     0xbe1ef8: mov             x0, #0
    // 0xbe1efc: CheckStackOverflow
    //     0xbe1efc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe1f00: cmp             SP, x16
    //     0xbe1f04: b.ls            #0xbe2aa8
    // 0xbe1f08: cmp             x0, x3
    // 0xbe1f0c: b.ge            #0xbe1f28
    // 0xbe1f10: add             x1, x2, x0, lsl #2
    // 0xbe1f14: r16 = 0.000000
    //     0xbe1f14: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe1f18: StoreField: r1->field_f = r16
    //     0xbe1f18: stur            w16, [x1, #0xf]
    // 0xbe1f1c: add             x1, x0, #1
    // 0xbe1f20: mov             x0, x1
    // 0xbe1f24: b               #0xbe1efc
    // 0xbe1f28: ldur            x4, [fp, #-0x58]
    // 0xbe1f2c: mul             x5, x4, x3
    // 0xbe1f30: stur            x5, [fp, #-0x70]
    // 0xbe1f34: r0 = BoxInt64Instr(r4)
    //     0xbe1f34: sbfiz           x0, x4, #1, #0x1f
    //     0xbe1f38: cmp             x4, x0, asr #1
    //     0xbe1f3c: b.eq            #0xbe1f48
    //     0xbe1f40: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe1f44: stur            x4, [x0, #7]
    // 0xbe1f48: mov             x6, x0
    // 0xbe1f4c: stur            x6, [fp, #-0x68]
    // 0xbe1f50: ldur            x9, [fp, #-0x60]
    // 0xbe1f54: d0 = 0.000000
    //     0xbe1f54: eor             v0.16b, v0.16b, v0.16b
    // 0xbe1f58: r10 = 0
    //     0xbe1f58: mov             x10, #0
    // 0xbe1f5c: ldur            x7, [fp, #-0x10]
    // 0xbe1f60: ldur            x8, [fp, #-0x28]
    // 0xbe1f64: stur            x10, [fp, #-0x50]
    // 0xbe1f68: stur            x9, [fp, #-0x60]
    // 0xbe1f6c: stur            d0, [fp, #-0xa0]
    // 0xbe1f70: CheckStackOverflow
    //     0xbe1f70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe1f74: cmp             SP, x16
    //     0xbe1f78: b.ls            #0xbe2ab0
    // 0xbe1f7c: cmp             x10, x3
    // 0xbe1f80: b.ge            #0xbe2150
    // 0xbe1f84: add             x11, x10, x5
    // 0xbe1f88: LoadField: r12 = r7->field_4f
    //     0xbe1f88: ldur            w12, [x7, #0x4f]
    // 0xbe1f8c: DecompressPointer r12
    //     0xbe1f8c: add             x12, x12, HEAP, lsl #32
    // 0xbe1f90: r0 = BoxInt64Instr(r11)
    //     0xbe1f90: sbfiz           x0, x11, #1, #0x1f
    //     0xbe1f94: cmp             x11, x0, asr #1
    //     0xbe1f98: b.eq            #0xbe1fa4
    //     0xbe1f9c: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xbe1fa0: stur            x11, [x0, #7]
    // 0xbe1fa4: r1 = LoadClassIdInstr(r12)
    //     0xbe1fa4: ldur            x1, [x12, #-1]
    //     0xbe1fa8: ubfx            x1, x1, #0xc, #0x14
    // 0xbe1fac: stp             x0, x12, [SP]
    // 0xbe1fb0: mov             x0, x1
    // 0xbe1fb4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xbe1fb4: sub             lr, x0, #0xdfd
    //     0xbe1fb8: ldr             lr, [x21, lr, lsl #3]
    //     0xbe1fbc: blr             lr
    // 0xbe1fc0: mov             x3, x0
    // 0xbe1fc4: stur            x3, [fp, #-0x88]
    // 0xbe1fc8: cmp             w3, NULL
    // 0xbe1fcc: b.eq            #0xbe2128
    // 0xbe1fd0: LoadField: r4 = r3->field_7
    //     0xbe1fd0: ldur            w4, [x3, #7]
    // 0xbe1fd4: DecompressPointer r4
    //     0xbe1fd4: add             x4, x4, HEAP, lsl #32
    // 0xbe1fd8: stur            x4, [fp, #-0x80]
    // 0xbe1fdc: cmp             w4, NULL
    // 0xbe1fe0: b.eq            #0xbe2ab8
    // 0xbe1fe4: mov             x0, x4
    // 0xbe1fe8: r2 = Null
    //     0xbe1fe8: mov             x2, NULL
    // 0xbe1fec: r1 = Null
    //     0xbe1fec: mov             x1, NULL
    // 0xbe1ff0: r4 = LoadClassIdInstr(r0)
    //     0xbe1ff0: ldur            x4, [x0, #-1]
    //     0xbe1ff4: ubfx            x4, x4, #0xc, #0x14
    // 0xbe1ff8: r17 = 4191
    //     0xbe1ff8: mov             x17, #0x105f
    // 0xbe1ffc: cmp             x4, x17
    // 0xbe2000: b.eq            #0xbe2018
    // 0xbe2004: r8 = TableCellParentData
    //     0xbe2004: add             x8, PP, #0x84, lsl #12  ; [pp+0x84a98] Type: TableCellParentData
    //     0xbe2008: ldr             x8, [x8, #0xa98]
    // 0xbe200c: r3 = Null
    //     0xbe200c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1230] Null
    //     0xbe2010: ldr             x3, [x3, #0x230]
    // 0xbe2014: r0 = DefaultTypeTest()
    //     0xbe2014: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe2018: ldur            x0, [fp, #-0x68]
    // 0xbe201c: ldur            x1, [fp, #-0x80]
    // 0xbe2020: StoreField: r1->field_f = r0
    //     0xbe2020: stur            w0, [x1, #0xf]
    //     0xbe2024: tbz             w0, #0, #0xbe2040
    //     0xbe2028: ldurb           w16, [x1, #-1]
    //     0xbe202c: ldurb           w17, [x0, #-1]
    //     0xbe2030: and             x16, x17, x16, lsr #2
    //     0xbe2034: tst             x16, HEAP, lsr #32
    //     0xbe2038: b.eq            #0xbe2040
    //     0xbe203c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe2040: LoadField: r0 = r1->field_b
    //     0xbe2040: ldur            w0, [x1, #0xb]
    // 0xbe2044: DecompressPointer r0
    //     0xbe2044: add             x0, x0, HEAP, lsl #32
    // 0xbe2048: cmp             w0, NULL
    // 0xbe204c: b.ne            #0xbe2058
    // 0xbe2050: r0 = Instance_TableCellVerticalAlignment
    //     0xbe2050: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8ffd0] Obj!TableCellVerticalAlignment@12c4161
    //     0xbe2054: ldr             x0, [x0, #0xfd0]
    // 0xbe2058: LoadField: r1 = r0->field_7
    //     0xbe2058: ldur            x1, [x0, #7]
    // 0xbe205c: cmp             x1, #2
    // 0xbe2060: b.le            #0xbe207c
    // 0xbe2064: cmp             x1, #4
    // 0xbe2068: b.gt            #0xbe207c
    // 0xbe206c: cmp             x1, #3
    // 0xbe2070: b.le            #0xbe26f0
    // 0xbe2074: ldur            d0, [fp, #-0xa0]
    // 0xbe2078: b               #0xbe212c
    // 0xbe207c: ldur            x3, [fp, #-0x28]
    // 0xbe2080: ldur            x4, [fp, #-0x50]
    // 0xbe2084: ldur            x2, [fp, #-0x88]
    // 0xbe2088: ldur            x0, [fp, #-0x48]
    // 0xbe208c: mov             x1, x4
    // 0xbe2090: cmp             x1, x0
    // 0xbe2094: b.hs            #0xbe2abc
    // 0xbe2098: ArrayLoad: r0 = r3[r4]  ; Unknown_4
    //     0xbe2098: add             x16, x3, x4, lsl #2
    //     0xbe209c: ldur            w0, [x16, #0xf]
    // 0xbe20a0: DecompressPointer r0
    //     0xbe20a0: add             x0, x0, HEAP, lsl #32
    // 0xbe20a4: LoadField: d0 = r0->field_7
    //     0xbe20a4: ldur            d0, [x0, #7]
    // 0xbe20a8: stur            d0, [fp, #-0xa8]
    // 0xbe20ac: r0 = BoxConstraints()
    //     0xbe20ac: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbe20b0: ldur            d0, [fp, #-0xa8]
    // 0xbe20b4: StoreField: r0->field_7 = d0
    //     0xbe20b4: stur            d0, [x0, #7]
    // 0xbe20b8: StoreField: r0->field_f = d0
    //     0xbe20b8: stur            d0, [x0, #0xf]
    // 0xbe20bc: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe20bc: stur            xzr, [x0, #0x17]
    // 0xbe20c0: d0 = inf
    //     0xbe20c0: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbe20c4: StoreField: r0->field_1f = d0
    //     0xbe20c4: stur            d0, [x0, #0x1f]
    // 0xbe20c8: ldur            x3, [fp, #-0x88]
    // 0xbe20cc: r1 = LoadClassIdInstr(r3)
    //     0xbe20cc: ldur            x1, [x3, #-1]
    //     0xbe20d0: ubfx            x1, x1, #0xc, #0x14
    // 0xbe20d4: r16 = true
    //     0xbe20d4: add             x16, NULL, #0x20  ; true
    // 0xbe20d8: str             x16, [SP]
    // 0xbe20dc: mov             x2, x0
    // 0xbe20e0: mov             x0, x1
    // 0xbe20e4: mov             x1, x3
    // 0xbe20e8: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbe20e8: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbe20ec: ldr             x4, [x4, #0xed0]
    // 0xbe20f0: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe20f0: mov             x17, #0xe6b9
    //     0xbe20f4: add             lr, x0, x17
    //     0xbe20f8: ldr             lr, [x21, lr, lsl #3]
    //     0xbe20fc: blr             lr
    // 0xbe2100: ldur            x2, [fp, #-0x88]
    // 0xbe2104: LoadField: r0 = r2->field_4b
    //     0xbe2104: ldur            w0, [x2, #0x4b]
    // 0xbe2108: DecompressPointer r0
    //     0xbe2108: add             x0, x0, HEAP, lsl #32
    // 0xbe210c: cmp             w0, NULL
    // 0xbe2110: b.eq            #0xbe2798
    // 0xbe2114: ldur            d0, [fp, #-0xa0]
    // 0xbe2118: LoadField: d1 = r0->field_f
    //     0xbe2118: ldur            d1, [x0, #0xf]
    // 0xbe211c: fmax            v2.2d, v0.2d, v1.2d
    // 0xbe2120: mov             v0.16b, v2.16b
    // 0xbe2124: b               #0xbe212c
    // 0xbe2128: ldur            d0, [fp, #-0xa0]
    // 0xbe212c: ldur            x3, [fp, #-0x50]
    // 0xbe2130: add             x10, x3, #1
    // 0xbe2134: ldur            x9, [fp, #-0x60]
    // 0xbe2138: ldur            x4, [fp, #-0x58]
    // 0xbe213c: ldur            x5, [fp, #-0x70]
    // 0xbe2140: ldur            x3, [fp, #-0x18]
    // 0xbe2144: ldur            x2, [fp, #-0x78]
    // 0xbe2148: ldur            x6, [fp, #-0x68]
    // 0xbe214c: b               #0xbe1f5c
    // 0xbe2150: ldur            d1, [fp, #-0x98]
    // 0xbe2154: mov             x2, x3
    // 0xbe2158: mov             x3, x4
    // 0xbe215c: d2 = 0.000000
    //     0xbe215c: eor             v2.16b, v2.16b, v2.16b
    // 0xbe2160: mul             x4, x3, x2
    // 0xbe2164: stur            x4, [fp, #-0x90]
    // 0xbe2168: fadd            d3, d1, d2
    // 0xbe216c: stur            d3, [fp, #-0xb0]
    // 0xbe2170: fadd            d4, d1, d0
    // 0xbe2174: stur            d4, [fp, #-0xa8]
    // 0xbe2178: r9 = 0
    //     0xbe2178: mov             x9, #0
    // 0xbe217c: ldur            x7, [fp, #-0x10]
    // 0xbe2180: ldur            x5, [fp, #-0x28]
    // 0xbe2184: ldur            x8, [fp, #-0x30]
    // 0xbe2188: ldur            x6, [fp, #-0x78]
    // 0xbe218c: stur            x9, [fp, #-0x70]
    // 0xbe2190: CheckStackOverflow
    //     0xbe2190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe2194: cmp             SP, x16
    //     0xbe2198: b.ls            #0xbe2ac0
    // 0xbe219c: cmp             x9, x2
    // 0xbe21a0: b.ge            #0xbe2578
    // 0xbe21a4: add             x10, x9, x4
    // 0xbe21a8: LoadField: r11 = r7->field_4f
    //     0xbe21a8: ldur            w11, [x7, #0x4f]
    // 0xbe21ac: DecompressPointer r11
    //     0xbe21ac: add             x11, x11, HEAP, lsl #32
    // 0xbe21b0: r0 = BoxInt64Instr(r10)
    //     0xbe21b0: sbfiz           x0, x10, #1, #0x1f
    //     0xbe21b4: cmp             x10, x0, asr #1
    //     0xbe21b8: b.eq            #0xbe21c4
    //     0xbe21bc: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xbe21c0: stur            x10, [x0, #7]
    // 0xbe21c4: r1 = LoadClassIdInstr(r11)
    //     0xbe21c4: ldur            x1, [x11, #-1]
    //     0xbe21c8: ubfx            x1, x1, #0xc, #0x14
    // 0xbe21cc: stp             x0, x11, [SP]
    // 0xbe21d0: mov             x0, x1
    // 0xbe21d4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xbe21d4: sub             lr, x0, #0xdfd
    //     0xbe21d8: ldr             lr, [x21, lr, lsl #3]
    //     0xbe21dc: blr             lr
    // 0xbe21e0: mov             x3, x0
    // 0xbe21e4: stur            x3, [fp, #-0x80]
    // 0xbe21e8: cmp             w3, NULL
    // 0xbe21ec: b.eq            #0xbe2548
    // 0xbe21f0: LoadField: r4 = r3->field_7
    //     0xbe21f0: ldur            w4, [x3, #7]
    // 0xbe21f4: DecompressPointer r4
    //     0xbe21f4: add             x4, x4, HEAP, lsl #32
    // 0xbe21f8: stur            x4, [fp, #-0x68]
    // 0xbe21fc: cmp             w4, NULL
    // 0xbe2200: b.eq            #0xbe2ac8
    // 0xbe2204: mov             x0, x4
    // 0xbe2208: r2 = Null
    //     0xbe2208: mov             x2, NULL
    // 0xbe220c: r1 = Null
    //     0xbe220c: mov             x1, NULL
    // 0xbe2210: r4 = LoadClassIdInstr(r0)
    //     0xbe2210: ldur            x4, [x0, #-1]
    //     0xbe2214: ubfx            x4, x4, #0xc, #0x14
    // 0xbe2218: r17 = 4191
    //     0xbe2218: mov             x17, #0x105f
    // 0xbe221c: cmp             x4, x17
    // 0xbe2220: b.eq            #0xbe2238
    // 0xbe2224: r8 = TableCellParentData
    //     0xbe2224: add             x8, PP, #0x84, lsl #12  ; [pp+0x84a98] Type: TableCellParentData
    //     0xbe2228: ldr             x8, [x8, #0xa98]
    // 0xbe222c: r3 = Null
    //     0xbe222c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1240] Null
    //     0xbe2230: ldr             x3, [x3, #0x240]
    // 0xbe2234: r0 = DefaultTypeTest()
    //     0xbe2234: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe2238: ldur            x0, [fp, #-0x68]
    // 0xbe223c: LoadField: r1 = r0->field_b
    //     0xbe223c: ldur            w1, [x0, #0xb]
    // 0xbe2240: DecompressPointer r1
    //     0xbe2240: add             x1, x1, HEAP, lsl #32
    // 0xbe2244: cmp             w1, NULL
    // 0xbe2248: b.ne            #0xbe2254
    // 0xbe224c: r1 = Instance_TableCellVerticalAlignment
    //     0xbe224c: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8ffd0] Obj!TableCellVerticalAlignment@12c4161
    //     0xbe2250: ldr             x1, [x1, #0xfd0]
    // 0xbe2254: LoadField: r2 = r1->field_7
    //     0xbe2254: ldur            x2, [x1, #7]
    // 0xbe2258: cmp             x2, #2
    // 0xbe225c: b.gt            #0xbe23d8
    // 0xbe2260: cmp             x2, #1
    // 0xbe2264: b.gt            #0xbe2358
    // 0xbe2268: cmp             x2, #0
    // 0xbe226c: b.gt            #0xbe22c8
    // 0xbe2270: ldur            x1, [fp, #-0x30]
    // 0xbe2274: ldur            d0, [fp, #-0x98]
    // 0xbe2278: ldur            x2, [fp, #-0x70]
    // 0xbe227c: ArrayLoad: r3 = r1[r2]  ; Unknown_4
    //     0xbe227c: add             x16, x1, x2, lsl #2
    //     0xbe2280: ldur            w3, [x16, #0xf]
    // 0xbe2284: DecompressPointer r3
    //     0xbe2284: add             x3, x3, HEAP, lsl #32
    // 0xbe2288: LoadField: d1 = r3->field_7
    //     0xbe2288: ldur            d1, [x3, #7]
    // 0xbe228c: stur            d1, [fp, #-0xb8]
    // 0xbe2290: r0 = Offset()
    //     0xbe2290: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbe2294: ldur            d0, [fp, #-0xb8]
    // 0xbe2298: StoreField: r0->field_7 = d0
    //     0xbe2298: stur            d0, [x0, #7]
    // 0xbe229c: ldur            d0, [fp, #-0x98]
    // 0xbe22a0: StoreField: r0->field_f = d0
    //     0xbe22a0: stur            d0, [x0, #0xf]
    // 0xbe22a4: ldur            x1, [fp, #-0x68]
    // 0xbe22a8: StoreField: r1->field_7 = r0
    //     0xbe22a8: stur            w0, [x1, #7]
    //     0xbe22ac: ldurb           w16, [x1, #-1]
    //     0xbe22b0: ldurb           w17, [x0, #-1]
    //     0xbe22b4: and             x16, x17, x16, lsr #2
    //     0xbe22b8: tst             x16, HEAP, lsr #32
    //     0xbe22bc: b.eq            #0xbe22c4
    //     0xbe22c0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe22c4: b               #0xbe254c
    // 0xbe22c8: mov             x1, x0
    // 0xbe22cc: ldur            x0, [fp, #-0x30]
    // 0xbe22d0: ldur            d0, [fp, #-0x98]
    // 0xbe22d4: ldur            x2, [fp, #-0x70]
    // 0xbe22d8: ldur            x3, [fp, #-0x80]
    // 0xbe22dc: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0xbe22dc: add             x16, x0, x2, lsl #2
    //     0xbe22e0: ldur            w4, [x16, #0xf]
    // 0xbe22e4: DecompressPointer r4
    //     0xbe22e4: add             x4, x4, HEAP, lsl #32
    // 0xbe22e8: LoadField: r5 = r3->field_4b
    //     0xbe22e8: ldur            w5, [x3, #0x4b]
    // 0xbe22ec: DecompressPointer r5
    //     0xbe22ec: add             x5, x5, HEAP, lsl #32
    // 0xbe22f0: cmp             w5, NULL
    // 0xbe22f4: b.eq            #0xbe2850
    // 0xbe22f8: ldur            d1, [fp, #-0xa0]
    // 0xbe22fc: d2 = 2.000000
    //     0xbe22fc: fmov            d2, #2.00000000
    // 0xbe2300: LoadField: d3 = r5->field_f
    //     0xbe2300: ldur            d3, [x5, #0xf]
    // 0xbe2304: fsub            d4, d1, d3
    // 0xbe2308: fdiv            d3, d4, d2
    // 0xbe230c: fadd            d4, d0, d3
    // 0xbe2310: stur            d4, [fp, #-0xc0]
    // 0xbe2314: LoadField: d3 = r4->field_7
    //     0xbe2314: ldur            d3, [x4, #7]
    // 0xbe2318: stur            d3, [fp, #-0xb8]
    // 0xbe231c: r0 = Offset()
    //     0xbe231c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbe2320: ldur            d0, [fp, #-0xb8]
    // 0xbe2324: StoreField: r0->field_7 = d0
    //     0xbe2324: stur            d0, [x0, #7]
    // 0xbe2328: ldur            d0, [fp, #-0xc0]
    // 0xbe232c: StoreField: r0->field_f = d0
    //     0xbe232c: stur            d0, [x0, #0xf]
    // 0xbe2330: ldur            x1, [fp, #-0x68]
    // 0xbe2334: StoreField: r1->field_7 = r0
    //     0xbe2334: stur            w0, [x1, #7]
    //     0xbe2338: ldurb           w16, [x1, #-1]
    //     0xbe233c: ldurb           w17, [x0, #-1]
    //     0xbe2340: and             x16, x17, x16, lsr #2
    //     0xbe2344: tst             x16, HEAP, lsr #32
    //     0xbe2348: b.eq            #0xbe2350
    //     0xbe234c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe2350: ldur            d0, [fp, #-0x98]
    // 0xbe2354: b               #0xbe254c
    // 0xbe2358: mov             x1, x0
    // 0xbe235c: ldur            x0, [fp, #-0x30]
    // 0xbe2360: ldur            x2, [fp, #-0x70]
    // 0xbe2364: ldur            x3, [fp, #-0x80]
    // 0xbe2368: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0xbe2368: add             x16, x0, x2, lsl #2
    //     0xbe236c: ldur            w4, [x16, #0xf]
    // 0xbe2370: DecompressPointer r4
    //     0xbe2370: add             x4, x4, HEAP, lsl #32
    // 0xbe2374: LoadField: r5 = r3->field_4b
    //     0xbe2374: ldur            w5, [x3, #0x4b]
    // 0xbe2378: DecompressPointer r5
    //     0xbe2378: add             x5, x5, HEAP, lsl #32
    // 0xbe237c: cmp             w5, NULL
    // 0xbe2380: b.eq            #0xbe2904
    // 0xbe2384: ldur            d0, [fp, #-0xa8]
    // 0xbe2388: LoadField: d1 = r5->field_f
    //     0xbe2388: ldur            d1, [x5, #0xf]
    // 0xbe238c: fsub            d2, d0, d1
    // 0xbe2390: stur            d2, [fp, #-0xc0]
    // 0xbe2394: LoadField: d1 = r4->field_7
    //     0xbe2394: ldur            d1, [x4, #7]
    // 0xbe2398: stur            d1, [fp, #-0xb8]
    // 0xbe239c: r0 = Offset()
    //     0xbe239c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbe23a0: ldur            d0, [fp, #-0xb8]
    // 0xbe23a4: StoreField: r0->field_7 = d0
    //     0xbe23a4: stur            d0, [x0, #7]
    // 0xbe23a8: ldur            d0, [fp, #-0xc0]
    // 0xbe23ac: StoreField: r0->field_f = d0
    //     0xbe23ac: stur            d0, [x0, #0xf]
    // 0xbe23b0: ldur            x1, [fp, #-0x68]
    // 0xbe23b4: StoreField: r1->field_7 = r0
    //     0xbe23b4: stur            w0, [x1, #7]
    //     0xbe23b8: ldurb           w16, [x1, #-1]
    //     0xbe23bc: ldurb           w17, [x0, #-1]
    //     0xbe23c0: and             x16, x17, x16, lsr #2
    //     0xbe23c4: tst             x16, HEAP, lsr #32
    //     0xbe23c8: b.eq            #0xbe23d0
    //     0xbe23cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe23d0: ldur            d0, [fp, #-0x98]
    // 0xbe23d4: b               #0xbe254c
    // 0xbe23d8: ldur            x3, [fp, #-0x80]
    // 0xbe23dc: mov             x1, x0
    // 0xbe23e0: cmp             x2, #4
    // 0xbe23e4: b.gt            #0xbe2470
    // 0xbe23e8: cmp             x2, #3
    // 0xbe23ec: b.gt            #0xbe2468
    // 0xbe23f0: ldur            x0, [fp, #-0x30]
    // 0xbe23f4: ldur            x2, [fp, #-0x70]
    // 0xbe23f8: ldur            d0, [fp, #-0xb0]
    // 0xbe23fc: ldur            x3, [fp, #-0x78]
    // 0xbe2400: ArrayLoad: r4 = r0[r2]  ; Unknown_4
    //     0xbe2400: add             x16, x0, x2, lsl #2
    //     0xbe2404: ldur            w4, [x16, #0xf]
    // 0xbe2408: DecompressPointer r4
    //     0xbe2408: add             x4, x4, HEAP, lsl #32
    // 0xbe240c: ArrayLoad: r5 = r3[r2]  ; Unknown_4
    //     0xbe240c: add             x16, x3, x2, lsl #2
    //     0xbe2410: ldur            w5, [x16, #0xf]
    // 0xbe2414: DecompressPointer r5
    //     0xbe2414: add             x5, x5, HEAP, lsl #32
    // 0xbe2418: LoadField: d1 = r5->field_7
    //     0xbe2418: ldur            d1, [x5, #7]
    // 0xbe241c: fsub            d2, d0, d1
    // 0xbe2420: stur            d2, [fp, #-0xc0]
    // 0xbe2424: LoadField: d1 = r4->field_7
    //     0xbe2424: ldur            d1, [x4, #7]
    // 0xbe2428: stur            d1, [fp, #-0xb8]
    // 0xbe242c: r0 = Offset()
    //     0xbe242c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbe2430: ldur            d0, [fp, #-0xb8]
    // 0xbe2434: StoreField: r0->field_7 = d0
    //     0xbe2434: stur            d0, [x0, #7]
    // 0xbe2438: ldur            d0, [fp, #-0xc0]
    // 0xbe243c: StoreField: r0->field_f = d0
    //     0xbe243c: stur            d0, [x0, #0xf]
    // 0xbe2440: ldur            x2, [fp, #-0x68]
    // 0xbe2444: StoreField: r2->field_7 = r0
    //     0xbe2444: stur            w0, [x2, #7]
    //     0xbe2448: ldurb           w16, [x2, #-1]
    //     0xbe244c: ldurb           w17, [x0, #-1]
    //     0xbe2450: and             x16, x17, x16, lsr #2
    //     0xbe2454: tst             x16, HEAP, lsr #32
    //     0xbe2458: b.eq            #0xbe2460
    //     0xbe245c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbe2460: ldur            d0, [fp, #-0x98]
    // 0xbe2464: b               #0xbe254c
    // 0xbe2468: mov             x2, x1
    // 0xbe246c: b               #0xbe2474
    // 0xbe2470: mov             x2, x1
    // 0xbe2474: ldur            x6, [fp, #-0x28]
    // 0xbe2478: ldur            x4, [fp, #-0x30]
    // 0xbe247c: ldur            d0, [fp, #-0x98]
    // 0xbe2480: ldur            d1, [fp, #-0xa0]
    // 0xbe2484: ldur            x5, [fp, #-0x70]
    // 0xbe2488: ldur            x0, [fp, #-0x48]
    // 0xbe248c: mov             x1, x5
    // 0xbe2490: cmp             x1, x0
    // 0xbe2494: b.hs            #0xbe2acc
    // 0xbe2498: ArrayLoad: r0 = r6[r5]  ; Unknown_4
    //     0xbe2498: add             x16, x6, x5, lsl #2
    //     0xbe249c: ldur            w0, [x16, #0xf]
    // 0xbe24a0: DecompressPointer r0
    //     0xbe24a0: add             x0, x0, HEAP, lsl #32
    // 0xbe24a4: LoadField: d2 = r0->field_7
    //     0xbe24a4: ldur            d2, [x0, #7]
    // 0xbe24a8: stur            d2, [fp, #-0xb8]
    // 0xbe24ac: r0 = BoxConstraints()
    //     0xbe24ac: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbe24b0: ldur            d0, [fp, #-0xb8]
    // 0xbe24b4: StoreField: r0->field_7 = d0
    //     0xbe24b4: stur            d0, [x0, #7]
    // 0xbe24b8: StoreField: r0->field_f = d0
    //     0xbe24b8: stur            d0, [x0, #0xf]
    // 0xbe24bc: ldur            d0, [fp, #-0xa0]
    // 0xbe24c0: ArrayStore: r0[0] = d0  ; List_8
    //     0xbe24c0: stur            d0, [x0, #0x17]
    // 0xbe24c4: StoreField: r0->field_1f = d0
    //     0xbe24c4: stur            d0, [x0, #0x1f]
    // 0xbe24c8: ldur            x3, [fp, #-0x80]
    // 0xbe24cc: r1 = LoadClassIdInstr(r3)
    //     0xbe24cc: ldur            x1, [x3, #-1]
    //     0xbe24d0: ubfx            x1, x1, #0xc, #0x14
    // 0xbe24d4: mov             x2, x0
    // 0xbe24d8: mov             x0, x1
    // 0xbe24dc: mov             x1, x3
    // 0xbe24e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbe24e0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbe24e4: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe24e4: mov             x17, #0xe6b9
    //     0xbe24e8: add             lr, x0, x17
    //     0xbe24ec: ldr             lr, [x21, lr, lsl #3]
    //     0xbe24f0: blr             lr
    // 0xbe24f4: ldur            x0, [fp, #-0x30]
    // 0xbe24f8: ldur            x1, [fp, #-0x70]
    // 0xbe24fc: ArrayLoad: r2 = r0[r1]  ; Unknown_4
    //     0xbe24fc: add             x16, x0, x1, lsl #2
    //     0xbe2500: ldur            w2, [x16, #0xf]
    // 0xbe2504: DecompressPointer r2
    //     0xbe2504: add             x2, x2, HEAP, lsl #32
    // 0xbe2508: LoadField: d0 = r2->field_7
    //     0xbe2508: ldur            d0, [x2, #7]
    // 0xbe250c: stur            d0, [fp, #-0xb8]
    // 0xbe2510: r0 = Offset()
    //     0xbe2510: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbe2514: ldur            d0, [fp, #-0xb8]
    // 0xbe2518: StoreField: r0->field_7 = d0
    //     0xbe2518: stur            d0, [x0, #7]
    // 0xbe251c: ldur            d0, [fp, #-0x98]
    // 0xbe2520: StoreField: r0->field_f = d0
    //     0xbe2520: stur            d0, [x0, #0xf]
    // 0xbe2524: ldur            x1, [fp, #-0x68]
    // 0xbe2528: StoreField: r1->field_7 = r0
    //     0xbe2528: stur            w0, [x1, #7]
    //     0xbe252c: ldurb           w16, [x1, #-1]
    //     0xbe2530: ldurb           w17, [x0, #-1]
    //     0xbe2534: and             x16, x17, x16, lsr #2
    //     0xbe2538: tst             x16, HEAP, lsr #32
    //     0xbe253c: b.eq            #0xbe2544
    //     0xbe2540: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe2544: b               #0xbe254c
    // 0xbe2548: ldur            d0, [fp, #-0x98]
    // 0xbe254c: ldur            x0, [fp, #-0x70]
    // 0xbe2550: add             x9, x0, #1
    // 0xbe2554: mov             v1.16b, v0.16b
    // 0xbe2558: ldur            x3, [fp, #-0x58]
    // 0xbe255c: ldur            d0, [fp, #-0xa0]
    // 0xbe2560: ldur            x4, [fp, #-0x90]
    // 0xbe2564: ldur            d3, [fp, #-0xb0]
    // 0xbe2568: ldur            d4, [fp, #-0xa8]
    // 0xbe256c: ldur            x2, [fp, #-0x18]
    // 0xbe2570: d2 = 0.000000
    //     0xbe2570: eor             v2.16b, v2.16b, v2.16b
    // 0xbe2574: b               #0xbe217c
    // 0xbe2578: mov             v31.16b, v0.16b
    // 0xbe257c: mov             v0.16b, v1.16b
    // 0xbe2580: mov             v1.16b, v31.16b
    // 0xbe2584: mov             x0, x3
    // 0xbe2588: fadd            d2, d0, d1
    // 0xbe258c: add             x9, x0, #1
    // 0xbe2590: mov             v0.16b, v2.16b
    // 0xbe2594: ldur            x8, [fp, #-0x60]
    // 0xbe2598: ldur            x2, [fp, #-0x10]
    // 0xbe259c: ldur            x3, [fp, #-0x18]
    // 0xbe25a0: ldur            x0, [fp, #-0x40]
    // 0xbe25a4: b               #0xbe1e10
    // 0xbe25a8: mov             x0, x4
    // 0xbe25ac: LoadField: r1 = r0->field_b
    //     0xbe25ac: ldur            w1, [x0, #0xb]
    // 0xbe25b0: LoadField: r2 = r0->field_f
    //     0xbe25b0: ldur            w2, [x0, #0xf]
    // 0xbe25b4: DecompressPointer r2
    //     0xbe25b4: add             x2, x2, HEAP, lsl #32
    // 0xbe25b8: LoadField: r3 = r2->field_b
    //     0xbe25b8: ldur            w3, [x2, #0xb]
    // 0xbe25bc: r2 = LoadInt32Instr(r1)
    //     0xbe25bc: sbfx            x2, x1, #1, #0x1f
    // 0xbe25c0: stur            x2, [fp, #-0x18]
    // 0xbe25c4: r1 = LoadInt32Instr(r3)
    //     0xbe25c4: sbfx            x1, x3, #1, #0x1f
    // 0xbe25c8: cmp             x2, x1
    // 0xbe25cc: b.ne            #0xbe25d8
    // 0xbe25d0: mov             x1, x0
    // 0xbe25d4: r0 = _growToNextCapacity()
    //     0xbe25d4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbe25d8: ldur            x3, [fp, #-0x10]
    // 0xbe25dc: ldur            x0, [fp, #-0x38]
    // 0xbe25e0: ldur            d0, [fp, #-0x98]
    // 0xbe25e4: ldur            x2, [fp, #-0x18]
    // 0xbe25e8: add             x1, x2, #1
    // 0xbe25ec: lsl             x4, x1, #1
    // 0xbe25f0: StoreField: r0->field_b = r4
    //     0xbe25f0: stur            w4, [x0, #0xb]
    // 0xbe25f4: LoadField: r1 = r0->field_f
    //     0xbe25f4: ldur            w1, [x0, #0xf]
    // 0xbe25f8: DecompressPointer r1
    //     0xbe25f8: add             x1, x1, HEAP, lsl #32
    // 0xbe25fc: r0 = inline_Allocate_Double()
    //     0xbe25fc: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbe2600: add             x0, x0, #0x10
    //     0xbe2604: cmp             x4, x0
    //     0xbe2608: b.ls            #0xbe2ad0
    //     0xbe260c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe2610: sub             x0, x0, #0xf
    //     0xbe2614: mov             x4, #0xe19c
    //     0xbe2618: movk            x4, #3, lsl #16
    //     0xbe261c: stur            x4, [x0, #-1]
    // 0xbe2620: dmb             ishst
    // 0xbe2624: StoreField: r0->field_7 = d0
    //     0xbe2624: stur            d0, [x0, #7]
    // 0xbe2628: ArrayStore: r1[r2] = r0  ; List_4
    //     0xbe2628: add             x25, x1, x2, lsl #2
    //     0xbe262c: add             x25, x25, #0xf
    //     0xbe2630: str             w0, [x25]
    //     0xbe2634: tbz             w0, #0, #0xbe2650
    //     0xbe2638: ldurb           w16, [x1, #-1]
    //     0xbe263c: ldurb           w17, [x0, #-1]
    //     0xbe2640: and             x16, x17, x16, lsr #2
    //     0xbe2644: tst             x16, HEAP, lsr #32
    //     0xbe2648: b.eq            #0xbe2650
    //     0xbe264c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe2650: LoadField: r0 = r3->field_9f
    //     0xbe2650: ldur            w0, [x3, #0x9f]
    // 0xbe2654: DecompressPointer r0
    //     0xbe2654: add             x0, x0, HEAP, lsl #32
    // 0xbe2658: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbe265c: cmp             w0, w16
    // 0xbe2660: b.eq            #0xbe2af0
    // 0xbe2664: LoadField: d1 = r0->field_7
    //     0xbe2664: ldur            d1, [x0, #7]
    // 0xbe2668: stur            d1, [fp, #-0xa0]
    // 0xbe266c: r0 = Size()
    //     0xbe266c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbe2670: ldur            d0, [fp, #-0xa0]
    // 0xbe2674: StoreField: r0->field_7 = d0
    //     0xbe2674: stur            d0, [x0, #7]
    // 0xbe2678: ldur            d0, [fp, #-0x98]
    // 0xbe267c: StoreField: r0->field_f = d0
    //     0xbe267c: stur            d0, [x0, #0xf]
    // 0xbe2680: ldur            x1, [fp, #-8]
    // 0xbe2684: mov             x2, x0
    // 0xbe2688: r0 = constrain()
    //     0xbe2688: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbe268c: ldur            x4, [fp, #-0x10]
    // 0xbe2690: StoreField: r4->field_4b = r0
    //     0xbe2690: stur            w0, [x4, #0x4b]
    //     0xbe2694: ldurb           w16, [x4, #-1]
    //     0xbe2698: ldurb           w17, [x0, #-1]
    //     0xbe269c: and             x16, x17, x16, lsr #2
    //     0xbe26a0: tst             x16, HEAP, lsr #32
    //     0xbe26a4: b.eq            #0xbe26ac
    //     0xbe26a8: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbe26ac: r0 = Null
    //     0xbe26ac: mov             x0, NULL
    // 0xbe26b0: LeaveFrame
    //     0xbe26b0: mov             SP, fp
    //     0xbe26b4: ldp             fp, lr, [SP], #0x10
    // 0xbe26b8: ret
    //     0xbe26b8: ret             
    // 0xbe26bc: r0 = StateError()
    //     0xbe26bc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe26c0: mov             x1, x0
    // 0xbe26c4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe26c4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe26c8: StoreField: r1->field_b = r0
    //     0xbe26c8: stur            w0, [x1, #0xb]
    // 0xbe26cc: mov             x0, x1
    // 0xbe26d0: r0 = Throw()
    //     0xbe26d0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe26d4: brk             #0
    // 0xbe26d8: r0 = noElement()
    //     0xbe26d8: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0xbe26dc: r0 = Throw()
    //     0xbe26dc: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe26e0: brk             #0
    // 0xbe26e4: r0 = noElement()
    //     0xbe26e4: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0xbe26e8: r0 = Throw()
    //     0xbe26e8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe26ec: brk             #0
    // 0xbe26f0: ldur            x4, [fp, #-0x10]
    // 0xbe26f4: ldur            x5, [fp, #-0x28]
    // 0xbe26f8: ldur            x3, [fp, #-0x50]
    // 0xbe26fc: ldur            x2, [fp, #-0x88]
    // 0xbe2700: ldur            x0, [fp, #-0x60]
    // 0xbe2704: mov             x1, x3
    // 0xbe2708: cmp             x1, x0
    // 0xbe270c: b.hs            #0xbe2afc
    // 0xbe2710: ArrayLoad: r0 = r5[r3]  ; Unknown_4
    //     0xbe2710: add             x16, x5, x3, lsl #2
    //     0xbe2714: ldur            w0, [x16, #0xf]
    // 0xbe2718: DecompressPointer r0
    //     0xbe2718: add             x0, x0, HEAP, lsl #32
    // 0xbe271c: LoadField: d0 = r0->field_7
    //     0xbe271c: ldur            d0, [x0, #7]
    // 0xbe2720: stur            d0, [fp, #-0x98]
    // 0xbe2724: r0 = BoxConstraints()
    //     0xbe2724: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbe2728: ldur            d0, [fp, #-0x98]
    // 0xbe272c: StoreField: r0->field_7 = d0
    //     0xbe272c: stur            d0, [x0, #7]
    // 0xbe2730: StoreField: r0->field_f = d0
    //     0xbe2730: stur            d0, [x0, #0xf]
    // 0xbe2734: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe2734: stur            xzr, [x0, #0x17]
    // 0xbe2738: d0 = inf
    //     0xbe2738: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbe273c: StoreField: r0->field_1f = d0
    //     0xbe273c: stur            d0, [x0, #0x1f]
    // 0xbe2740: ldur            x3, [fp, #-0x88]
    // 0xbe2744: r1 = LoadClassIdInstr(r3)
    //     0xbe2744: ldur            x1, [x3, #-1]
    //     0xbe2748: ubfx            x1, x1, #0xc, #0x14
    // 0xbe274c: r16 = true
    //     0xbe274c: add             x16, NULL, #0x20  ; true
    // 0xbe2750: str             x16, [SP]
    // 0xbe2754: mov             x2, x0
    // 0xbe2758: mov             x0, x1
    // 0xbe275c: mov             x1, x3
    // 0xbe2760: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbe2760: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbe2764: ldr             x4, [x4, #0xed0]
    // 0xbe2768: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe2768: mov             x17, #0xe6b9
    //     0xbe276c: add             lr, x0, x17
    //     0xbe2770: ldr             lr, [x21, lr, lsl #3]
    //     0xbe2774: blr             lr
    // 0xbe2778: ldur            x1, [fp, #-0x10]
    // 0xbe277c: r0 = Shader._()
    //     0xbe277c: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xbe2780: r1 = Null
    //     0xbe2780: mov             x1, NULL
    // 0xbe2784: cmp             w1, NULL
    // 0xbe2788: b.eq            #0xbe2b00
    // 0xbe278c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xbe278c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xbe2790: r0 = Throw()
    //     0xbe2790: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe2794: brk             #0
    // 0xbe2798: mov             x3, x2
    // 0xbe279c: r1 = Null
    //     0xbe279c: mov             x1, NULL
    // 0xbe27a0: r2 = 8
    //     0xbe27a0: mov             x2, #8
    // 0xbe27a4: r0 = AllocateArray()
    //     0xbe27a4: bl              #0x13df928  ; AllocateArrayStub
    // 0xbe27a8: stur            x0, [fp, #-8]
    // 0xbe27ac: r16 = "RenderBox was not laid out: "
    //     0xbe27ac: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbe27b0: StoreField: r0->field_f = r16
    //     0xbe27b0: stur            w16, [x0, #0xf]
    // 0xbe27b4: ldur            x16, [fp, #-0x88]
    // 0xbe27b8: str             x16, [SP]
    // 0xbe27bc: r0 = runtimeType()
    //     0xbe27bc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbe27c0: ldur            x1, [fp, #-8]
    // 0xbe27c4: ArrayStore: r1[1] = r0  ; List_4
    //     0xbe27c4: add             x25, x1, #0x13
    //     0xbe27c8: str             w0, [x25]
    //     0xbe27cc: tbz             w0, #0, #0xbe27e8
    //     0xbe27d0: ldurb           w16, [x1, #-1]
    //     0xbe27d4: ldurb           w17, [x0, #-1]
    //     0xbe27d8: and             x16, x17, x16, lsr #2
    //     0xbe27dc: tst             x16, HEAP, lsr #32
    //     0xbe27e0: b.eq            #0xbe27e8
    //     0xbe27e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe27e8: ldur            x0, [fp, #-8]
    // 0xbe27ec: r16 = "#"
    //     0xbe27ec: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbe27f0: ArrayStore: r0[0] = r16  ; List_4
    //     0xbe27f0: stur            w16, [x0, #0x17]
    // 0xbe27f4: ldur            x1, [fp, #-0x88]
    // 0xbe27f8: r0 = shortHash()
    //     0xbe27f8: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbe27fc: ldur            x1, [fp, #-8]
    // 0xbe2800: ArrayStore: r1[3] = r0  ; List_4
    //     0xbe2800: add             x25, x1, #0x1b
    //     0xbe2804: str             w0, [x25]
    //     0xbe2808: tbz             w0, #0, #0xbe2824
    //     0xbe280c: ldurb           w16, [x1, #-1]
    //     0xbe2810: ldurb           w17, [x0, #-1]
    //     0xbe2814: and             x16, x17, x16, lsr #2
    //     0xbe2818: tst             x16, HEAP, lsr #32
    //     0xbe281c: b.eq            #0xbe2824
    //     0xbe2820: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe2824: ldur            x16, [fp, #-8]
    // 0xbe2828: str             x16, [SP]
    // 0xbe282c: r0 = _interpolate()
    //     0xbe282c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbe2830: stur            x0, [fp, #-8]
    // 0xbe2834: r0 = StateError()
    //     0xbe2834: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe2838: mov             x1, x0
    // 0xbe283c: ldur            x0, [fp, #-8]
    // 0xbe2840: StoreField: r1->field_b = r0
    //     0xbe2840: stur            w0, [x1, #0xb]
    // 0xbe2844: mov             x0, x1
    // 0xbe2848: r0 = Throw()
    //     0xbe2848: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe284c: brk             #0
    // 0xbe2850: r1 = Null
    //     0xbe2850: mov             x1, NULL
    // 0xbe2854: r2 = 8
    //     0xbe2854: mov             x2, #8
    // 0xbe2858: r0 = AllocateArray()
    //     0xbe2858: bl              #0x13df928  ; AllocateArrayStub
    // 0xbe285c: stur            x0, [fp, #-8]
    // 0xbe2860: r16 = "RenderBox was not laid out: "
    //     0xbe2860: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbe2864: StoreField: r0->field_f = r16
    //     0xbe2864: stur            w16, [x0, #0xf]
    // 0xbe2868: ldur            x16, [fp, #-0x80]
    // 0xbe286c: str             x16, [SP]
    // 0xbe2870: r0 = runtimeType()
    //     0xbe2870: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbe2874: ldur            x1, [fp, #-8]
    // 0xbe2878: ArrayStore: r1[1] = r0  ; List_4
    //     0xbe2878: add             x25, x1, #0x13
    //     0xbe287c: str             w0, [x25]
    //     0xbe2880: tbz             w0, #0, #0xbe289c
    //     0xbe2884: ldurb           w16, [x1, #-1]
    //     0xbe2888: ldurb           w17, [x0, #-1]
    //     0xbe288c: and             x16, x17, x16, lsr #2
    //     0xbe2890: tst             x16, HEAP, lsr #32
    //     0xbe2894: b.eq            #0xbe289c
    //     0xbe2898: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe289c: ldur            x0, [fp, #-8]
    // 0xbe28a0: r16 = "#"
    //     0xbe28a0: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbe28a4: ArrayStore: r0[0] = r16  ; List_4
    //     0xbe28a4: stur            w16, [x0, #0x17]
    // 0xbe28a8: ldur            x1, [fp, #-0x80]
    // 0xbe28ac: r0 = shortHash()
    //     0xbe28ac: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbe28b0: ldur            x1, [fp, #-8]
    // 0xbe28b4: ArrayStore: r1[3] = r0  ; List_4
    //     0xbe28b4: add             x25, x1, #0x1b
    //     0xbe28b8: str             w0, [x25]
    //     0xbe28bc: tbz             w0, #0, #0xbe28d8
    //     0xbe28c0: ldurb           w16, [x1, #-1]
    //     0xbe28c4: ldurb           w17, [x0, #-1]
    //     0xbe28c8: and             x16, x17, x16, lsr #2
    //     0xbe28cc: tst             x16, HEAP, lsr #32
    //     0xbe28d0: b.eq            #0xbe28d8
    //     0xbe28d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe28d8: ldur            x16, [fp, #-8]
    // 0xbe28dc: str             x16, [SP]
    // 0xbe28e0: r0 = _interpolate()
    //     0xbe28e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbe28e4: stur            x0, [fp, #-8]
    // 0xbe28e8: r0 = StateError()
    //     0xbe28e8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe28ec: mov             x1, x0
    // 0xbe28f0: ldur            x0, [fp, #-8]
    // 0xbe28f4: StoreField: r1->field_b = r0
    //     0xbe28f4: stur            w0, [x1, #0xb]
    // 0xbe28f8: mov             x0, x1
    // 0xbe28fc: r0 = Throw()
    //     0xbe28fc: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe2900: brk             #0
    // 0xbe2904: r1 = Null
    //     0xbe2904: mov             x1, NULL
    // 0xbe2908: r2 = 8
    //     0xbe2908: mov             x2, #8
    // 0xbe290c: r0 = AllocateArray()
    //     0xbe290c: bl              #0x13df928  ; AllocateArrayStub
    // 0xbe2910: stur            x0, [fp, #-8]
    // 0xbe2914: r16 = "RenderBox was not laid out: "
    //     0xbe2914: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbe2918: StoreField: r0->field_f = r16
    //     0xbe2918: stur            w16, [x0, #0xf]
    // 0xbe291c: ldur            x16, [fp, #-0x80]
    // 0xbe2920: str             x16, [SP]
    // 0xbe2924: r0 = runtimeType()
    //     0xbe2924: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbe2928: ldur            x1, [fp, #-8]
    // 0xbe292c: ArrayStore: r1[1] = r0  ; List_4
    //     0xbe292c: add             x25, x1, #0x13
    //     0xbe2930: str             w0, [x25]
    //     0xbe2934: tbz             w0, #0, #0xbe2950
    //     0xbe2938: ldurb           w16, [x1, #-1]
    //     0xbe293c: ldurb           w17, [x0, #-1]
    //     0xbe2940: and             x16, x17, x16, lsr #2
    //     0xbe2944: tst             x16, HEAP, lsr #32
    //     0xbe2948: b.eq            #0xbe2950
    //     0xbe294c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe2950: ldur            x0, [fp, #-8]
    // 0xbe2954: r16 = "#"
    //     0xbe2954: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbe2958: ArrayStore: r0[0] = r16  ; List_4
    //     0xbe2958: stur            w16, [x0, #0x17]
    // 0xbe295c: ldur            x1, [fp, #-0x80]
    // 0xbe2960: r0 = shortHash()
    //     0xbe2960: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbe2964: ldur            x1, [fp, #-8]
    // 0xbe2968: ArrayStore: r1[3] = r0  ; List_4
    //     0xbe2968: add             x25, x1, #0x1b
    //     0xbe296c: str             w0, [x25]
    //     0xbe2970: tbz             w0, #0, #0xbe298c
    //     0xbe2974: ldurb           w16, [x1, #-1]
    //     0xbe2978: ldurb           w17, [x0, #-1]
    //     0xbe297c: and             x16, x17, x16, lsr #2
    //     0xbe2980: tst             x16, HEAP, lsr #32
    //     0xbe2984: b.eq            #0xbe298c
    //     0xbe2988: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbe298c: ldur            x16, [fp, #-8]
    // 0xbe2990: str             x16, [SP]
    // 0xbe2994: r0 = _interpolate()
    //     0xbe2994: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbe2998: stur            x0, [fp, #-8]
    // 0xbe299c: r0 = StateError()
    //     0xbe299c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe29a0: mov             x1, x0
    // 0xbe29a4: ldur            x0, [fp, #-8]
    // 0xbe29a8: StoreField: r1->field_b = r0
    //     0xbe29a8: stur            w0, [x1, #0xb]
    // 0xbe29ac: mov             x0, x1
    // 0xbe29b0: r0 = Throw()
    //     0xbe29b0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe29b4: brk             #0
    // 0xbe29b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe29b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe29bc: b               #0xbe1964
    // 0xbe29c0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe29c0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe29c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe29c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe29c8: b               #0xbe1a94
    // 0xbe29cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe29cc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe29d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe29d0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe29d4: r0 = RangeErrorSharedWithFPURegs()
    //     0xbe29d4: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xbe29d8: SaveReg d2
    //     0xbe29d8: str             q2, [SP, #-0x10]!
    // 0xbe29dc: stp             x6, x7, [SP, #-0x10]!
    // 0xbe29e0: stp             x4, x5, [SP, #-0x10]!
    // 0xbe29e4: stp             x2, x3, [SP, #-0x10]!
    // 0xbe29e8: r0 = AllocateDouble()
    //     0xbe29e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe29ec: ldp             x2, x3, [SP], #0x10
    // 0xbe29f0: ldp             x4, x5, [SP], #0x10
    // 0xbe29f4: ldp             x6, x7, [SP], #0x10
    // 0xbe29f8: RestoreReg d2
    //     0xbe29f8: ldr             q2, [SP], #0x10
    // 0xbe29fc: b               #0xbe1b18
    // 0xbe2a00: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe2a00: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe2a04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe2a04: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe2a08: SaveReg d2
    //     0xbe2a08: str             q2, [SP, #-0x10]!
    // 0xbe2a0c: stp             x5, x7, [SP, #-0x10]!
    // 0xbe2a10: stp             x3, x4, [SP, #-0x10]!
    // 0xbe2a14: SaveReg r2
    //     0xbe2a14: str             x2, [SP, #-8]!
    // 0xbe2a18: r0 = AllocateDouble()
    //     0xbe2a18: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe2a1c: RestoreReg r2
    //     0xbe2a1c: ldr             x2, [SP], #8
    // 0xbe2a20: ldp             x3, x4, [SP], #0x10
    // 0xbe2a24: ldp             x5, x7, [SP], #0x10
    // 0xbe2a28: RestoreReg d2
    //     0xbe2a28: ldr             q2, [SP], #0x10
    // 0xbe2a2c: b               #0xbe1c08
    // 0xbe2a30: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe2a30: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe2a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe2a34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe2a38: b               #0xbe1c80
    // 0xbe2a3c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe2a3c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe2a40: SaveReg d2
    //     0xbe2a40: str             q2, [SP, #-0x10]!
    // 0xbe2a44: stp             x7, x8, [SP, #-0x10]!
    // 0xbe2a48: stp             x5, x6, [SP, #-0x10]!
    // 0xbe2a4c: stp             x3, x4, [SP, #-0x10]!
    // 0xbe2a50: SaveReg r2
    //     0xbe2a50: str             x2, [SP, #-8]!
    // 0xbe2a54: r0 = AllocateDouble()
    //     0xbe2a54: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe2a58: RestoreReg r2
    //     0xbe2a58: ldr             x2, [SP], #8
    // 0xbe2a5c: ldp             x3, x4, [SP], #0x10
    // 0xbe2a60: ldp             x5, x6, [SP], #0x10
    // 0xbe2a64: ldp             x7, x8, [SP], #0x10
    // 0xbe2a68: RestoreReg d2
    //     0xbe2a68: ldr             q2, [SP], #0x10
    // 0xbe2a6c: b               #0xbe1ce8
    // 0xbe2a70: SaveReg d2
    //     0xbe2a70: str             q2, [SP, #-0x10]!
    // 0xbe2a74: r0 = AllocateDouble()
    //     0xbe2a74: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe2a78: RestoreReg d2
    //     0xbe2a78: ldr             q2, [SP], #0x10
    // 0xbe2a7c: b               #0xbe1d94
    // 0xbe2a80: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe2a80: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe2a84: b               #0xbe1e38
    // 0xbe2a88: SaveReg d0
    //     0xbe2a88: str             q0, [SP, #-0x10]!
    // 0xbe2a8c: stp             x2, x3, [SP, #-0x10]!
    // 0xbe2a90: SaveReg r1
    //     0xbe2a90: str             x1, [SP, #-8]!
    // 0xbe2a94: r0 = AllocateDouble()
    //     0xbe2a94: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe2a98: RestoreReg r1
    //     0xbe2a98: ldr             x1, [SP], #8
    // 0xbe2a9c: ldp             x2, x3, [SP], #0x10
    // 0xbe2aa0: RestoreReg d0
    //     0xbe2aa0: ldr             q0, [SP], #0x10
    // 0xbe2aa4: b               #0xbe1eb4
    // 0xbe2aa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe2aa8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe2aac: b               #0xbe1f08
    // 0xbe2ab0: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe2ab0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe2ab4: b               #0xbe1f7c
    // 0xbe2ab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe2ab8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe2abc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe2abc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe2ac0: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe2ac0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe2ac4: b               #0xbe219c
    // 0xbe2ac8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe2ac8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe2acc: r0 = RangeErrorSharedWithFPURegs()
    //     0xbe2acc: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xbe2ad0: SaveReg d0
    //     0xbe2ad0: str             q0, [SP, #-0x10]!
    // 0xbe2ad4: stp             x2, x3, [SP, #-0x10]!
    // 0xbe2ad8: SaveReg r1
    //     0xbe2ad8: str             x1, [SP, #-8]!
    // 0xbe2adc: r0 = AllocateDouble()
    //     0xbe2adc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe2ae0: RestoreReg r1
    //     0xbe2ae0: ldr             x1, [SP], #8
    // 0xbe2ae4: ldp             x2, x3, [SP], #0x10
    // 0xbe2ae8: RestoreReg d0
    //     0xbe2ae8: ldr             q0, [SP], #0x10
    // 0xbe2aec: b               #0xbe2624
    // 0xbe2af0: r9 = _tableWidth
    //     0xbe2af0: add             x9, PP, #0xa1, lsl #12  ; [pp+0xa1250] Field <RenderTable._tableWidth@612148626>: late (offset: 0xa0)
    //     0xbe2af4: ldr             x9, [x9, #0x250]
    // 0xbe2af8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbe2af8: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbe2afc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe2afc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe2b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe2b00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0xbf0130, size: 0xf0
    // 0xbf0130: EnterFrame
    //     0xbf0130: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0134: mov             fp, SP
    // 0xbf0138: AllocStack(0x20)
    //     0xbf0138: sub             SP, SP, #0x20
    // 0xbf013c: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xbf013c: stur            x2, [fp, #-8]
    // 0xbf0140: CheckStackOverflow
    //     0xbf0140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0144: cmp             SP, x16
    //     0xbf0148: b.ls            #0xbf0210
    // 0xbf014c: LoadField: r0 = r1->field_4f
    //     0xbf014c: ldur            w0, [x1, #0x4f]
    // 0xbf0150: DecompressPointer r0
    //     0xbf0150: add             x0, x0, HEAP, lsl #32
    // 0xbf0154: r1 = LoadClassIdInstr(r0)
    //     0xbf0154: ldur            x1, [x0, #-1]
    //     0xbf0158: ubfx            x1, x1, #0xc, #0x14
    // 0xbf015c: mov             x16, x0
    // 0xbf0160: mov             x0, x1
    // 0xbf0164: mov             x1, x16
    // 0xbf0168: r0 = GDT[cid_x0 + 0x12641]()
    //     0xbf0168: mov             x17, #0x2641
    //     0xbf016c: movk            x17, #1, lsl #16
    //     0xbf0170: add             lr, x0, x17
    //     0xbf0174: ldr             lr, [x21, lr, lsl #3]
    //     0xbf0178: blr             lr
    // 0xbf017c: mov             x2, x0
    // 0xbf0180: stur            x2, [fp, #-0x10]
    // 0xbf0184: CheckStackOverflow
    //     0xbf0184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0188: cmp             SP, x16
    //     0xbf018c: b.ls            #0xbf0218
    // 0xbf0190: r0 = LoadClassIdInstr(r2)
    //     0xbf0190: ldur            x0, [x2, #-1]
    //     0xbf0194: ubfx            x0, x0, #0xc, #0x14
    // 0xbf0198: mov             x1, x2
    // 0xbf019c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xbf019c: mov             x17, #0x845b
    //     0xbf01a0: movk            x17, #1, lsl #16
    //     0xbf01a4: add             lr, x0, x17
    //     0xbf01a8: ldr             lr, [x21, lr, lsl #3]
    //     0xbf01ac: blr             lr
    // 0xbf01b0: tbnz            w0, #4, #0xbf0200
    // 0xbf01b4: ldur            x2, [fp, #-0x10]
    // 0xbf01b8: r0 = LoadClassIdInstr(r2)
    //     0xbf01b8: ldur            x0, [x2, #-1]
    //     0xbf01bc: ubfx            x0, x0, #0xc, #0x14
    // 0xbf01c0: mov             x1, x2
    // 0xbf01c4: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xbf01c4: mov             x17, #0x7d4c
    //     0xbf01c8: movk            x17, #1, lsl #16
    //     0xbf01cc: add             lr, x0, x17
    //     0xbf01d0: ldr             lr, [x21, lr, lsl #3]
    //     0xbf01d4: blr             lr
    // 0xbf01d8: cmp             w0, NULL
    // 0xbf01dc: b.eq            #0xbf01f8
    // 0xbf01e0: ldur            x16, [fp, #-8]
    // 0xbf01e4: stp             x0, x16, [SP]
    // 0xbf01e8: ldur            x0, [fp, #-8]
    // 0xbf01ec: ClosureCall
    //     0xbf01ec: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbf01f0: ldur            x2, [x0, #0x1f]
    //     0xbf01f4: blr             x2
    // 0xbf01f8: ldur            x2, [fp, #-0x10]
    // 0xbf01fc: b               #0xbf0184
    // 0xbf0200: r0 = Null
    //     0xbf0200: mov             x0, NULL
    // 0xbf0204: LeaveFrame
    //     0xbf0204: mov             SP, fp
    //     0xbf0208: ldp             fp, lr, [SP], #0x10
    // 0xbf020c: ret
    //     0xbf020c: ret             
    // 0xbf0210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0214: b               #0xbf014c
    // 0xbf0218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0218: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf021c: b               #0xbf0190
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbfb0d8, size: 0x24
    // 0xbfb0d8: r4 = Instance_SemanticsRole
    //     0xbfb0d8: add             x4, PP, #0xa1, lsl #12  ; [pp+0xa12e0] Obj!SemanticsRole@12c7841
    //     0xbfb0dc: ldr             x4, [x4, #0x2e0]
    // 0xbfb0e0: r3 = true
    //     0xbfb0e0: add             x3, NULL, #0x20  ; true
    // 0xbfb0e4: StoreField: r2->field_63 = r4
    //     0xbfb0e4: stur            w4, [x2, #0x63]
    // 0xbfb0e8: StoreField: r2->field_1f = r3
    //     0xbfb0e8: stur            w3, [x2, #0x1f]
    // 0xbfb0ec: StoreField: r2->field_7 = r3
    //     0xbfb0ec: stur            w3, [x2, #7]
    // 0xbfb0f0: ArrayStore: r2[0] = r3  ; List_4
    //     0xbfb0f0: stur            w3, [x2, #0x17]
    // 0xbfb0f4: r0 = Null
    //     0xbfb0f4: mov             x0, NULL
    // 0xbfb0f8: ret
    //     0xbfb0f8: ret             
  }
  _ detach(/* No info */) {
    // ** addr: 0xc090bc, size: 0x1e0
    // 0xc090bc: EnterFrame
    //     0xc090bc: stp             fp, lr, [SP, #-0x10]!
    //     0xc090c0: mov             fp, SP
    // 0xc090c4: AllocStack(0x20)
    //     0xc090c4: sub             SP, SP, #0x20
    // 0xc090c8: SetupParameters(RenderTable this /* r1 => r0, fp-0x8 */)
    //     0xc090c8: mov             x0, x1
    //     0xc090cc: stur            x1, [fp, #-8]
    // 0xc090d0: CheckStackOverflow
    //     0xc090d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc090d4: cmp             SP, x16
    //     0xc090d8: b.ls            #0xc09280
    // 0xc090dc: mov             x1, x0
    // 0xc090e0: r0 = detach()
    //     0xc090e0: bl              #0xc09564  ; [package:flutter/src/rendering/object.dart] RenderObject::detach
    // 0xc090e4: ldur            x2, [fp, #-8]
    // 0xc090e8: LoadField: r3 = r2->field_77
    //     0xc090e8: ldur            w3, [x2, #0x77]
    // 0xc090ec: DecompressPointer r3
    //     0xc090ec: add             x3, x3, HEAP, lsl #32
    // 0xc090f0: stur            x3, [fp, #-0x20]
    // 0xc090f4: cmp             w3, NULL
    // 0xc090f8: b.eq            #0xc091ac
    // 0xc090fc: LoadField: r0 = r3->field_b
    //     0xc090fc: ldur            w0, [x3, #0xb]
    // 0xc09100: r4 = LoadInt32Instr(r0)
    //     0xc09100: sbfx            x4, x0, #1, #0x1f
    // 0xc09104: stur            x4, [fp, #-0x18]
    // 0xc09108: r0 = 0
    //     0xc09108: mov             x0, #0
    // 0xc0910c: CheckStackOverflow
    //     0xc0910c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc09110: cmp             SP, x16
    //     0xc09114: b.ls            #0xc09288
    // 0xc09118: cmp             x0, x4
    // 0xc0911c: b.ge            #0xc09164
    // 0xc09120: ArrayLoad: r1 = r3[r0]  ; Unknown_4
    //     0xc09120: add             x16, x3, x0, lsl #2
    //     0xc09124: ldur            w1, [x16, #0xf]
    // 0xc09128: DecompressPointer r1
    //     0xc09128: add             x1, x1, HEAP, lsl #32
    // 0xc0912c: add             x5, x0, #1
    // 0xc09130: stur            x5, [fp, #-0x10]
    // 0xc09134: cmp             w1, NULL
    // 0xc09138: b.eq            #0xc09150
    // 0xc0913c: r0 = LoadClassIdInstr(r1)
    //     0xc0913c: ldur            x0, [x1, #-1]
    //     0xc09140: ubfx            x0, x0, #0xc, #0x14
    // 0xc09144: r0 = GDT[cid_x0 + -0x1000]()
    //     0xc09144: sub             lr, x0, #1, lsl #12
    //     0xc09148: ldr             lr, [x21, lr, lsl #3]
    //     0xc0914c: blr             lr
    // 0xc09150: ldur            x0, [fp, #-0x10]
    // 0xc09154: ldur            x2, [fp, #-8]
    // 0xc09158: ldur            x3, [fp, #-0x20]
    // 0xc0915c: ldur            x4, [fp, #-0x18]
    // 0xc09160: b               #0xc0910c
    // 0xc09164: mov             x0, x2
    // 0xc09168: LoadField: r1 = r0->field_73
    //     0xc09168: ldur            w1, [x0, #0x73]
    // 0xc0916c: DecompressPointer r1
    //     0xc0916c: add             x1, x1, HEAP, lsl #32
    // 0xc09170: cmp             w1, NULL
    // 0xc09174: b.eq            #0xc09290
    // 0xc09178: LoadField: r2 = r1->field_b
    //     0xc09178: ldur            w2, [x1, #0xb]
    // 0xc0917c: r1 = <BoxPainter?>
    //     0xc0917c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96d60] TypeArguments: <BoxPainter?>
    //     0xc09180: ldr             x1, [x1, #0xd60]
    // 0xc09184: r0 = AllocateArray()
    //     0xc09184: bl              #0x13df928  ; AllocateArrayStub
    // 0xc09188: ldur            x1, [fp, #-8]
    // 0xc0918c: StoreField: r1->field_77 = r0
    //     0xc0918c: stur            w0, [x1, #0x77]
    //     0xc09190: ldurb           w16, [x1, #-1]
    //     0xc09194: ldurb           w17, [x0, #-1]
    //     0xc09198: and             x16, x17, x16, lsr #2
    //     0xc0919c: tst             x16, HEAP, lsr #32
    //     0xc091a0: b.eq            #0xc091a8
    //     0xc091a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc091a8: b               #0xc091b0
    // 0xc091ac: mov             x1, x2
    // 0xc091b0: LoadField: r0 = r1->field_4f
    //     0xc091b0: ldur            w0, [x1, #0x4f]
    // 0xc091b4: DecompressPointer r0
    //     0xc091b4: add             x0, x0, HEAP, lsl #32
    // 0xc091b8: r1 = LoadClassIdInstr(r0)
    //     0xc091b8: ldur            x1, [x0, #-1]
    //     0xc091bc: ubfx            x1, x1, #0xc, #0x14
    // 0xc091c0: mov             x16, x0
    // 0xc091c4: mov             x0, x1
    // 0xc091c8: mov             x1, x16
    // 0xc091cc: r0 = GDT[cid_x0 + 0x12641]()
    //     0xc091cc: mov             x17, #0x2641
    //     0xc091d0: movk            x17, #1, lsl #16
    //     0xc091d4: add             lr, x0, x17
    //     0xc091d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc091dc: blr             lr
    // 0xc091e0: mov             x2, x0
    // 0xc091e4: stur            x2, [fp, #-8]
    // 0xc091e8: CheckStackOverflow
    //     0xc091e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc091ec: cmp             SP, x16
    //     0xc091f0: b.ls            #0xc09294
    // 0xc091f4: r0 = LoadClassIdInstr(r2)
    //     0xc091f4: ldur            x0, [x2, #-1]
    //     0xc091f8: ubfx            x0, x0, #0xc, #0x14
    // 0xc091fc: mov             x1, x2
    // 0xc09200: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xc09200: mov             x17, #0x845b
    //     0xc09204: movk            x17, #1, lsl #16
    //     0xc09208: add             lr, x0, x17
    //     0xc0920c: ldr             lr, [x21, lr, lsl #3]
    //     0xc09210: blr             lr
    // 0xc09214: tbnz            w0, #4, #0xc09270
    // 0xc09218: ldur            x2, [fp, #-8]
    // 0xc0921c: r0 = LoadClassIdInstr(r2)
    //     0xc0921c: ldur            x0, [x2, #-1]
    //     0xc09220: ubfx            x0, x0, #0xc, #0x14
    // 0xc09224: mov             x1, x2
    // 0xc09228: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xc09228: mov             x17, #0x7d4c
    //     0xc0922c: movk            x17, #1, lsl #16
    //     0xc09230: add             lr, x0, x17
    //     0xc09234: ldr             lr, [x21, lr, lsl #3]
    //     0xc09238: blr             lr
    // 0xc0923c: cmp             w0, NULL
    // 0xc09240: b.eq            #0xc09268
    // 0xc09244: r1 = LoadClassIdInstr(r0)
    //     0xc09244: ldur            x1, [x0, #-1]
    //     0xc09248: ubfx            x1, x1, #0xc, #0x14
    // 0xc0924c: mov             x16, x0
    // 0xc09250: mov             x0, x1
    // 0xc09254: mov             x1, x16
    // 0xc09258: r0 = GDT[cid_x0 + 0xf618]()
    //     0xc09258: mov             x17, #0xf618
    //     0xc0925c: add             lr, x0, x17
    //     0xc09260: ldr             lr, [x21, lr, lsl #3]
    //     0xc09264: blr             lr
    // 0xc09268: ldur            x2, [fp, #-8]
    // 0xc0926c: b               #0xc091e8
    // 0xc09270: r0 = Null
    //     0xc09270: mov             x0, NULL
    // 0xc09274: LeaveFrame
    //     0xc09274: mov             SP, fp
    //     0xc09278: ldp             fp, lr, [SP], #0x10
    // 0xc0927c: ret
    //     0xc0927c: ret             
    // 0xc09280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc09280: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc09284: b               #0xc090dc
    // 0xc09288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc09288: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0928c: b               #0xc09118
    // 0xc09290: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc09290: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc09294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc09294: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc09298: b               #0xc091f4
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0cf78, size: 0x110
    // 0xc0cf78: EnterFrame
    //     0xc0cf78: stp             fp, lr, [SP, #-0x10]!
    //     0xc0cf7c: mov             fp, SP
    // 0xc0cf80: AllocStack(0x10)
    //     0xc0cf80: sub             SP, SP, #0x10
    // 0xc0cf84: SetupParameters(RenderTable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc0cf84: mov             x3, x1
    //     0xc0cf88: mov             x0, x2
    //     0xc0cf8c: stur            x1, [fp, #-8]
    //     0xc0cf90: stur            x2, [fp, #-0x10]
    // 0xc0cf94: CheckStackOverflow
    //     0xc0cf94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0cf98: cmp             SP, x16
    //     0xc0cf9c: b.ls            #0xc0d078
    // 0xc0cfa0: mov             x1, x3
    // 0xc0cfa4: mov             x2, x0
    // 0xc0cfa8: r0 = attach()
    //     0xc0cfa8: bl              #0xc0d350  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0xc0cfac: ldur            x0, [fp, #-8]
    // 0xc0cfb0: LoadField: r1 = r0->field_4f
    //     0xc0cfb0: ldur            w1, [x0, #0x4f]
    // 0xc0cfb4: DecompressPointer r1
    //     0xc0cfb4: add             x1, x1, HEAP, lsl #32
    // 0xc0cfb8: r0 = LoadClassIdInstr(r1)
    //     0xc0cfb8: ldur            x0, [x1, #-1]
    //     0xc0cfbc: ubfx            x0, x0, #0xc, #0x14
    // 0xc0cfc0: r0 = GDT[cid_x0 + 0x12641]()
    //     0xc0cfc0: mov             x17, #0x2641
    //     0xc0cfc4: movk            x17, #1, lsl #16
    //     0xc0cfc8: add             lr, x0, x17
    //     0xc0cfcc: ldr             lr, [x21, lr, lsl #3]
    //     0xc0cfd0: blr             lr
    // 0xc0cfd4: mov             x2, x0
    // 0xc0cfd8: stur            x2, [fp, #-8]
    // 0xc0cfdc: CheckStackOverflow
    //     0xc0cfdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0cfe0: cmp             SP, x16
    //     0xc0cfe4: b.ls            #0xc0d080
    // 0xc0cfe8: r0 = LoadClassIdInstr(r2)
    //     0xc0cfe8: ldur            x0, [x2, #-1]
    //     0xc0cfec: ubfx            x0, x0, #0xc, #0x14
    // 0xc0cff0: mov             x1, x2
    // 0xc0cff4: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xc0cff4: mov             x17, #0x845b
    //     0xc0cff8: movk            x17, #1, lsl #16
    //     0xc0cffc: add             lr, x0, x17
    //     0xc0d000: ldr             lr, [x21, lr, lsl #3]
    //     0xc0d004: blr             lr
    // 0xc0d008: tbnz            w0, #4, #0xc0d068
    // 0xc0d00c: ldur            x2, [fp, #-8]
    // 0xc0d010: r0 = LoadClassIdInstr(r2)
    //     0xc0d010: ldur            x0, [x2, #-1]
    //     0xc0d014: ubfx            x0, x0, #0xc, #0x14
    // 0xc0d018: mov             x1, x2
    // 0xc0d01c: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xc0d01c: mov             x17, #0x7d4c
    //     0xc0d020: movk            x17, #1, lsl #16
    //     0xc0d024: add             lr, x0, x17
    //     0xc0d028: ldr             lr, [x21, lr, lsl #3]
    //     0xc0d02c: blr             lr
    // 0xc0d030: cmp             w0, NULL
    // 0xc0d034: b.eq            #0xc0d060
    // 0xc0d038: r1 = LoadClassIdInstr(r0)
    //     0xc0d038: ldur            x1, [x0, #-1]
    //     0xc0d03c: ubfx            x1, x1, #0xc, #0x14
    // 0xc0d040: mov             x16, x0
    // 0xc0d044: mov             x0, x1
    // 0xc0d048: mov             x1, x16
    // 0xc0d04c: ldur            x2, [fp, #-0x10]
    // 0xc0d050: r0 = GDT[cid_x0 + 0xf4f5]()
    //     0xc0d050: mov             x17, #0xf4f5
    //     0xc0d054: add             lr, x0, x17
    //     0xc0d058: ldr             lr, [x21, lr, lsl #3]
    //     0xc0d05c: blr             lr
    // 0xc0d060: ldur            x2, [fp, #-8]
    // 0xc0d064: b               #0xc0cfdc
    // 0xc0d068: r0 = Null
    //     0xc0d068: mov             x0, NULL
    // 0xc0d06c: LeaveFrame
    //     0xc0d06c: mov             SP, fp
    //     0xc0d070: ldp             fp, lr, [SP], #0x10
    // 0xc0d074: ret
    //     0xc0d074: ret             
    // 0xc0d078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0d078: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0d07c: b               #0xc0cfa0
    // 0xc0d080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0d080: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0d084: b               #0xc0cfe8
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0eb44, size: 0xb0
    // 0xc0eb44: EnterFrame
    //     0xc0eb44: stp             fp, lr, [SP, #-0x10]!
    //     0xc0eb48: mov             fp, SP
    // 0xc0eb4c: AllocStack(0x8)
    //     0xc0eb4c: sub             SP, SP, #8
    // 0xc0eb50: SetupParameters(RenderTable this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0eb50: mov             x0, x2
    //     0xc0eb54: mov             x4, x1
    //     0xc0eb58: mov             x3, x2
    //     0xc0eb5c: stur            x2, [fp, #-8]
    // 0xc0eb60: r2 = Null
    //     0xc0eb60: mov             x2, NULL
    // 0xc0eb64: r1 = Null
    //     0xc0eb64: mov             x1, NULL
    // 0xc0eb68: r4 = 60
    //     0xc0eb68: mov             x4, #0x3c
    // 0xc0eb6c: branchIfSmi(r0, 0xc0eb78)
    //     0xc0eb6c: tbz             w0, #0, #0xc0eb78
    // 0xc0eb70: r4 = LoadClassIdInstr(r0)
    //     0xc0eb70: ldur            x4, [x0, #-1]
    //     0xc0eb74: ubfx            x4, x4, #0xc, #0x14
    // 0xc0eb78: r17 = -4679
    //     0xc0eb78: mov             x17, #-0x1247
    // 0xc0eb7c: add             x4, x4, x17
    // 0xc0eb80: cmp             x4, #0x128
    // 0xc0eb84: b.ls            #0xc0eb98
    // 0xc0eb88: r8 = RenderObject
    //     0xc0eb88: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0xc0eb8c: r3 = Null
    //     0xc0eb8c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa12e8] Null
    //     0xc0eb90: ldr             x3, [x3, #0x2e8]
    // 0xc0eb94: r0 = RenderObject()
    //     0xc0eb94: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0xc0eb98: ldur            x0, [fp, #-8]
    // 0xc0eb9c: LoadField: r1 = r0->field_7
    //     0xc0eb9c: ldur            w1, [x0, #7]
    // 0xc0eba0: DecompressPointer r1
    //     0xc0eba0: add             x1, x1, HEAP, lsl #32
    // 0xc0eba4: r2 = LoadClassIdInstr(r1)
    //     0xc0eba4: ldur            x2, [x1, #-1]
    //     0xc0eba8: ubfx            x2, x2, #0xc, #0x14
    // 0xc0ebac: r17 = 4191
    //     0xc0ebac: mov             x17, #0x105f
    // 0xc0ebb0: cmp             x2, x17
    // 0xc0ebb4: b.eq            #0xc0ebe4
    // 0xc0ebb8: r0 = TableCellParentData()
    //     0xc0ebb8: bl              #0xc0ebf4  ; AllocateTableCellParentDataStub -> TableCellParentData (size=0x14)
    // 0xc0ebbc: r1 = Instance_Offset
    //     0xc0ebbc: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0ebc0: StoreField: r0->field_7 = r1
    //     0xc0ebc0: stur            w1, [x0, #7]
    // 0xc0ebc4: ldur            x1, [fp, #-8]
    // 0xc0ebc8: StoreField: r1->field_7 = r0
    //     0xc0ebc8: stur            w0, [x1, #7]
    //     0xc0ebcc: ldurb           w16, [x1, #-1]
    //     0xc0ebd0: ldurb           w17, [x0, #-1]
    //     0xc0ebd4: and             x16, x17, x16, lsr #2
    //     0xc0ebd8: tst             x16, HEAP, lsr #32
    //     0xc0ebdc: b.eq            #0xc0ebe4
    //     0xc0ebe0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0ebe4: r0 = Null
    //     0xc0ebe4: mov             x0, NULL
    // 0xc0ebe8: LeaveFrame
    //     0xc0ebe8: mov             SP, fp
    //     0xc0ebec: ldp             fp, lr, [SP], #0x10
    // 0xc0ebf0: ret
    //     0xc0ebf0: ret             
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0xc10834, size: 0x54
    // 0xc10834: EnterFrame
    //     0xc10834: stp             fp, lr, [SP, #-0x10]!
    //     0xc10838: mov             fp, SP
    // 0xc1083c: AllocStack(0x8)
    //     0xc1083c: sub             SP, SP, #8
    // 0xc10840: SetupParameters(RenderTable this /* r1 => r0, fp-0x8 */)
    //     0xc10840: mov             x0, x1
    //     0xc10844: stur            x1, [fp, #-8]
    // 0xc10848: CheckStackOverflow
    //     0xc10848: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1084c: cmp             SP, x16
    //     0xc10850: b.ls            #0xc10880
    // 0xc10854: mov             x2, x0
    // 0xc10858: r1 = Function 'redepthChild':.
    //     0xc10858: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a018] AnonymousClosure: (0xc055e8), in [package:flutter/src/rendering/object.dart] RenderObject::redepthChild (0xc05584)
    //     0xc1085c: ldr             x1, [x1, #0x18]
    // 0xc10860: r0 = AllocateClosure()
    //     0xc10860: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc10864: ldur            x1, [fp, #-8]
    // 0xc10868: mov             x2, x0
    // 0xc1086c: r0 = visitChildren()
    //     0xc1086c: bl              #0xbf0130  ; [package:flutter/src/rendering/table.dart] RenderTable::visitChildren
    // 0xc10870: r0 = Null
    //     0xc10870: mov             x0, NULL
    // 0xc10874: LeaveFrame
    //     0xc10874: mov             SP, fp
    //     0xc10878: ldp             fp, lr, [SP], #0x10
    // 0xc1087c: ret
    //     0xc1087c: ret             
    // 0xc10880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc10880: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc10884: b               #0xc10854
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0xc1425c, size: 0x11f0
    // 0xc1425c: EnterFrame
    //     0xc1425c: stp             fp, lr, [SP, #-0x10]!
    //     0xc14260: mov             fp, SP
    // 0xc14264: AllocStack(0x128)
    //     0xc14264: sub             SP, SP, #0x128
    // 0xc14268: SetupParameters(RenderTable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0xc14268: mov             x0, x1
    //     0xc1426c: stur            x1, [fp, #-8]
    //     0xc14270: mov             x1, x2
    //     0xc14274: stur            x2, [fp, #-0x10]
    //     0xc14278: mov             x2, x3
    //     0xc1427c: stur            x3, [fp, #-0x18]
    //     0xc14280: stur            x5, [fp, #-0x20]
    // 0xc14284: CheckStackOverflow
    //     0xc14284: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc14288: cmp             SP, x16
    //     0xc1428c: b.ls            #0xc153cc
    // 0xc14290: r1 = 1
    //     0xc14290: mov             x1, #1
    // 0xc14294: r0 = AllocateContext()
    //     0xc14294: bl              #0x13de838  ; AllocateContextStub
    // 0xc14298: mov             x3, x0
    // 0xc1429c: ldur            x0, [fp, #-8]
    // 0xc142a0: stur            x3, [fp, #-0x28]
    // 0xc142a4: StoreField: r3->field_f = r0
    //     0xc142a4: stur            w0, [x3, #0xf]
    // 0xc142a8: r1 = <SemanticsNode>
    //     0xc142a8: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0xc142ac: r2 = 0
    //     0xc142ac: mov             x2, #0
    // 0xc142b0: r0 = _GrowableList()
    //     0xc142b0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xc142b4: mov             x3, x0
    // 0xc142b8: ldur            x0, [fp, #-8]
    // 0xc142bc: stur            x3, [fp, #-0x30]
    // 0xc142c0: LoadField: r2 = r0->field_5b
    //     0xc142c0: ldur            x2, [x0, #0x5b]
    // 0xc142c4: r1 = <List<List<SemanticsNode>>>
    //     0xc142c4: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa12b8] TypeArguments: <List<List<SemanticsNode>>>
    //     0xc142c8: ldr             x1, [x1, #0x2b8]
    // 0xc142cc: r0 = _GrowableList()
    //     0xc142cc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xc142d0: LoadField: r1 = r0->field_b
    //     0xc142d0: ldur            w1, [x0, #0xb]
    // 0xc142d4: r3 = LoadInt32Instr(r1)
    //     0xc142d4: sbfx            x3, x1, #1, #0x1f
    // 0xc142d8: stur            x3, [fp, #-0x48]
    // 0xc142dc: LoadField: r4 = r0->field_f
    //     0xc142dc: ldur            w4, [x0, #0xf]
    // 0xc142e0: DecompressPointer r4
    //     0xc142e0: add             x4, x4, HEAP, lsl #32
    // 0xc142e4: stur            x4, [fp, #-0x40]
    // 0xc142e8: r5 = 0
    //     0xc142e8: mov             x5, #0
    // 0xc142ec: ldur            x0, [fp, #-0x28]
    // 0xc142f0: stur            x5, [fp, #-0x38]
    // 0xc142f4: CheckStackOverflow
    //     0xc142f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc142f8: cmp             SP, x16
    //     0xc142fc: b.ls            #0xc153d4
    // 0xc14300: cmp             x5, x3
    // 0xc14304: b.ge            #0xc14404
    // 0xc14308: LoadField: r1 = r0->field_f
    //     0xc14308: ldur            w1, [x0, #0xf]
    // 0xc1430c: DecompressPointer r1
    //     0xc1430c: add             x1, x1, HEAP, lsl #32
    // 0xc14310: LoadField: r2 = r1->field_53
    //     0xc14310: ldur            x2, [x1, #0x53]
    // 0xc14314: r1 = <List<SemanticsNode>>
    //     0xc14314: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa12c0] TypeArguments: <List<SemanticsNode>>
    //     0xc14318: ldr             x1, [x1, #0x2c0]
    // 0xc1431c: r0 = _GrowableList()
    //     0xc1431c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xc14320: stur            x0, [fp, #-0x58]
    // 0xc14324: r3 = 0
    //     0xc14324: mov             x3, #0
    // 0xc14328: stur            x3, [fp, #-0x50]
    // 0xc1432c: CheckStackOverflow
    //     0xc1432c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc14330: cmp             SP, x16
    //     0xc14334: b.ls            #0xc153dc
    // 0xc14338: LoadField: r1 = r0->field_b
    //     0xc14338: ldur            w1, [x0, #0xb]
    // 0xc1433c: r2 = LoadInt32Instr(r1)
    //     0xc1433c: sbfx            x2, x1, #1, #0x1f
    // 0xc14340: cmp             x3, x2
    // 0xc14344: b.ge            #0xc143bc
    // 0xc14348: r1 = <SemanticsNode>
    //     0xc14348: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0xc1434c: r2 = 0
    //     0xc1434c: mov             x2, #0
    // 0xc14350: r0 = _GrowableList()
    //     0xc14350: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xc14354: mov             x3, x0
    // 0xc14358: ldur            x2, [fp, #-0x58]
    // 0xc1435c: LoadField: r0 = r2->field_b
    //     0xc1435c: ldur            w0, [x2, #0xb]
    // 0xc14360: r1 = LoadInt32Instr(r0)
    //     0xc14360: sbfx            x1, x0, #1, #0x1f
    // 0xc14364: mov             x0, x1
    // 0xc14368: ldur            x1, [fp, #-0x50]
    // 0xc1436c: cmp             x1, x0
    // 0xc14370: b.hs            #0xc153e4
    // 0xc14374: LoadField: r1 = r2->field_f
    //     0xc14374: ldur            w1, [x2, #0xf]
    // 0xc14378: DecompressPointer r1
    //     0xc14378: add             x1, x1, HEAP, lsl #32
    // 0xc1437c: mov             x0, x3
    // 0xc14380: ldur            x3, [fp, #-0x50]
    // 0xc14384: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc14384: add             x25, x1, x3, lsl #2
    //     0xc14388: add             x25, x25, #0xf
    //     0xc1438c: str             w0, [x25]
    //     0xc14390: tbz             w0, #0, #0xc143ac
    //     0xc14394: ldurb           w16, [x1, #-1]
    //     0xc14398: ldurb           w17, [x0, #-1]
    //     0xc1439c: and             x16, x17, x16, lsr #2
    //     0xc143a0: tst             x16, HEAP, lsr #32
    //     0xc143a4: b.eq            #0xc143ac
    //     0xc143a8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc143ac: add             x0, x3, #1
    // 0xc143b0: mov             x3, x0
    // 0xc143b4: mov             x0, x2
    // 0xc143b8: b               #0xc14328
    // 0xc143bc: ldur            x3, [fp, #-0x38]
    // 0xc143c0: mov             x2, x0
    // 0xc143c4: ldur            x1, [fp, #-0x40]
    // 0xc143c8: mov             x0, x2
    // 0xc143cc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc143cc: add             x25, x1, x3, lsl #2
    //     0xc143d0: add             x25, x25, #0xf
    //     0xc143d4: str             w0, [x25]
    //     0xc143d8: tbz             w0, #0, #0xc143f4
    //     0xc143dc: ldurb           w16, [x1, #-1]
    //     0xc143e0: ldurb           w17, [x0, #-1]
    //     0xc143e4: and             x16, x17, x16, lsr #2
    //     0xc143e8: tst             x16, HEAP, lsr #32
    //     0xc143ec: b.eq            #0xc143f4
    //     0xc143f0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc143f4: add             x5, x3, #1
    // 0xc143f8: ldur            x4, [fp, #-0x40]
    // 0xc143fc: ldur            x3, [fp, #-0x48]
    // 0xc14400: b               #0xc142ec
    // 0xc14404: ldur            x3, [fp, #-8]
    // 0xc14408: ldur            x4, [fp, #-0x20]
    // 0xc1440c: LoadField: r0 = r4->field_b
    //     0xc1440c: ldur            w0, [x4, #0xb]
    // 0xc14410: r5 = LoadInt32Instr(r0)
    //     0xc14410: sbfx            x5, x0, #1, #0x1f
    // 0xc14414: stur            x5, [fp, #-0x50]
    // 0xc14418: LoadField: r6 = r3->field_87
    //     0xc14418: ldur            w6, [x3, #0x87]
    // 0xc1441c: DecompressPointer r6
    //     0xc1441c: add             x6, x6, HEAP, lsl #32
    // 0xc14420: stur            x6, [fp, #-0x60]
    // 0xc14424: r0 = 0
    //     0xc14424: mov             x0, #0
    // 0xc14428: ldur            x8, [fp, #-0x28]
    // 0xc1442c: ldur            x7, [fp, #-0x40]
    // 0xc14430: CheckStackOverflow
    //     0xc14430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc14434: cmp             SP, x16
    //     0xc14438: b.ls            #0xc153e8
    // 0xc1443c: LoadField: r1 = r4->field_b
    //     0xc1443c: ldur            w1, [x4, #0xb]
    // 0xc14440: r2 = LoadInt32Instr(r1)
    //     0xc14440: sbfx            x2, x1, #1, #0x1f
    // 0xc14444: cmp             x5, x2
    // 0xc14448: b.ne            #0xc153ac
    // 0xc1444c: cmp             x0, x2
    // 0xc14450: b.ge            #0xc147d8
    // 0xc14454: LoadField: r1 = r4->field_f
    //     0xc14454: ldur            w1, [x4, #0xf]
    // 0xc14458: DecompressPointer r1
    //     0xc14458: add             x1, x1, HEAP, lsl #32
    // 0xc1445c: ArrayLoad: r9 = r1[r0]  ; Unknown_4
    //     0xc1445c: add             x16, x1, x0, lsl #2
    //     0xc14460: ldur            w9, [x16, #0xf]
    // 0xc14464: DecompressPointer r9
    //     0xc14464: add             x9, x9, HEAP, lsl #32
    // 0xc14468: stur            x9, [fp, #-0x58]
    // 0xc1446c: add             x10, x0, #1
    // 0xc14470: stur            x10, [fp, #-0x38]
    // 0xc14474: LoadField: r2 = r9->field_b
    //     0xc14474: ldur            x2, [x9, #0xb]
    // 0xc14478: r0 = BoxInt64Instr(r2)
    //     0xc14478: sbfiz           x0, x2, #1, #0x1f
    //     0xc1447c: cmp             x2, x0, asr #1
    //     0xc14480: b.eq            #0xc1448c
    //     0xc14484: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc14488: stur            x2, [x0, #7]
    // 0xc1448c: mov             x1, x6
    // 0xc14490: mov             x2, x0
    // 0xc14494: r0 = containsKey()
    //     0xc14494: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xc14498: tbnz            w0, #4, #0xc14588
    // 0xc1449c: ldur            x3, [fp, #-0x60]
    // 0xc144a0: ldur            x4, [fp, #-0x58]
    // 0xc144a4: LoadField: r2 = r4->field_b
    //     0xc144a4: ldur            x2, [x4, #0xb]
    // 0xc144a8: r0 = BoxInt64Instr(r2)
    //     0xc144a8: sbfiz           x0, x2, #1, #0x1f
    //     0xc144ac: cmp             x2, x0, asr #1
    //     0xc144b0: b.eq            #0xc144bc
    //     0xc144b4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc144b8: stur            x2, [x0, #7]
    // 0xc144bc: mov             x1, x3
    // 0xc144c0: mov             x2, x0
    // 0xc144c4: r0 = _getValueOrData()
    //     0xc144c4: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc144c8: ldur            x2, [fp, #-0x60]
    // 0xc144cc: LoadField: r1 = r2->field_f
    //     0xc144cc: ldur            w1, [x2, #0xf]
    // 0xc144d0: DecompressPointer r1
    //     0xc144d0: add             x1, x1, HEAP, lsl #32
    // 0xc144d4: cmp             w1, w0
    // 0xc144d8: b.ne            #0xc144e0
    // 0xc144dc: r0 = Null
    //     0xc144dc: mov             x0, NULL
    // 0xc144e0: ldur            x3, [fp, #-8]
    // 0xc144e4: cmp             w0, NULL
    // 0xc144e8: b.eq            #0xc153f0
    // 0xc144ec: LoadField: r4 = r0->field_7
    //     0xc144ec: ldur            x4, [x0, #7]
    // 0xc144f0: LoadField: r5 = r0->field_f
    //     0xc144f0: ldur            x5, [x0, #0xf]
    // 0xc144f4: LoadField: r0 = r3->field_5b
    //     0xc144f4: ldur            x0, [x3, #0x5b]
    // 0xc144f8: cmp             x4, x0
    // 0xc144fc: b.ge            #0xc147c0
    // 0xc14500: LoadField: r0 = r3->field_53
    //     0xc14500: ldur            x0, [x3, #0x53]
    // 0xc14504: cmp             x5, x0
    // 0xc14508: b.ge            #0xc147c0
    // 0xc1450c: ldur            x6, [fp, #-0x40]
    // 0xc14510: ldur            x0, [fp, #-0x48]
    // 0xc14514: mov             x1, x4
    // 0xc14518: cmp             x1, x0
    // 0xc1451c: b.hs            #0xc153f4
    // 0xc14520: ArrayLoad: r7 = r6[r4]  ; Unknown_4
    //     0xc14520: add             x16, x6, x4, lsl #2
    //     0xc14524: ldur            w7, [x16, #0xf]
    // 0xc14528: DecompressPointer r7
    //     0xc14528: add             x7, x7, HEAP, lsl #32
    // 0xc1452c: r0 = BoxInt64Instr(r5)
    //     0xc1452c: sbfiz           x0, x5, #1, #0x1f
    //     0xc14530: cmp             x5, x0, asr #1
    //     0xc14534: b.eq            #0xc14540
    //     0xc14538: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc1453c: stur            x5, [x0, #7]
    // 0xc14540: r1 = LoadClassIdInstr(r7)
    //     0xc14540: ldur            x1, [x7, #-1]
    //     0xc14544: ubfx            x1, x1, #0xc, #0x14
    // 0xc14548: stp             x0, x7, [SP]
    // 0xc1454c: mov             x0, x1
    // 0xc14550: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xc14550: sub             lr, x0, #0xdfd
    //     0xc14554: ldr             lr, [x21, lr, lsl #3]
    //     0xc14558: blr             lr
    // 0xc1455c: r1 = LoadClassIdInstr(r0)
    //     0xc1455c: ldur            x1, [x0, #-1]
    //     0xc14560: ubfx            x1, x1, #0xc, #0x14
    // 0xc14564: ldur            x16, [fp, #-0x58]
    // 0xc14568: stp             x16, x0, [SP]
    // 0xc1456c: mov             x0, x1
    // 0xc14570: r0 = GDT[cid_x0 + 0x175da]()
    //     0xc14570: mov             x17, #0x75da
    //     0xc14574: movk            x17, #1, lsl #16
    //     0xc14578: add             lr, x0, x17
    //     0xc1457c: ldr             lr, [x21, lr, lsl #3]
    //     0xc14580: blr             lr
    // 0xc14584: b               #0xc147c0
    // 0xc14588: ldur            x0, [fp, #-0x58]
    // 0xc1458c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc1458c: ldur            w1, [x0, #0x17]
    // 0xc14590: DecompressPointer r1
    //     0xc14590: add             x1, x1, HEAP, lsl #32
    // 0xc14594: cmp             w1, NULL
    // 0xc14598: b.eq            #0xc145a4
    // 0xc1459c: r0 = getAsTranslation()
    //     0xc1459c: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xc145a0: b               #0xc145a8
    // 0xc145a4: r0 = Null
    //     0xc145a4: mov             x0, NULL
    // 0xc145a8: cmp             w0, NULL
    // 0xc145ac: b.ne            #0xc145b8
    // 0xc145b0: r2 = Instance_Offset
    //     0xc145b0: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc145b4: b               #0xc145bc
    // 0xc145b8: mov             x2, x0
    // 0xc145bc: ldur            x3, [fp, #-0x28]
    // 0xc145c0: ldur            x0, [fp, #-0x58]
    // 0xc145c4: LoadField: r1 = r0->field_1f
    //     0xc145c4: ldur            w1, [x0, #0x1f]
    // 0xc145c8: DecompressPointer r1
    //     0xc145c8: add             x1, x1, HEAP, lsl #32
    // 0xc145cc: r0 = shift()
    //     0xc145cc: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0xc145d0: LoadField: d0 = r0->field_f
    //     0xc145d0: ldur            d0, [x0, #0xf]
    // 0xc145d4: ldur            x1, [fp, #-0x28]
    // 0xc145d8: LoadField: r2 = r1->field_f
    //     0xc145d8: ldur            w2, [x1, #0xf]
    // 0xc145dc: DecompressPointer r2
    //     0xc145dc: add             x2, x2, HEAP, lsl #32
    // 0xc145e0: LoadField: r3 = r2->field_97
    //     0xc145e0: ldur            w3, [x2, #0x97]
    // 0xc145e4: DecompressPointer r3
    //     0xc145e4: add             x3, x3, HEAP, lsl #32
    // 0xc145e8: LoadField: r4 = r3->field_b
    //     0xc145e8: ldur            w4, [x3, #0xb]
    // 0xc145ec: r5 = LoadInt32Instr(r4)
    //     0xc145ec: sbfx            x5, x4, #1, #0x1f
    // 0xc145f0: sub             x4, x5, #1
    // 0xc145f4: LoadField: r5 = r3->field_f
    //     0xc145f4: ldur            w5, [x3, #0xf]
    // 0xc145f8: DecompressPointer r5
    //     0xc145f8: add             x5, x5, HEAP, lsl #32
    // 0xc145fc: mov             x3, x4
    // 0xc14600: CheckStackOverflow
    //     0xc14600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc14604: cmp             SP, x16
    //     0xc14608: b.ls            #0xc153f8
    // 0xc1460c: tbnz            x3, #0x3f, #0xc14634
    // 0xc14610: ArrayLoad: r4 = r5[r3]  ; Unknown_4
    //     0xc14610: add             x16, x5, x3, lsl #2
    //     0xc14614: ldur            w4, [x16, #0xf]
    // 0xc14618: DecompressPointer r4
    //     0xc14618: add             x4, x4, HEAP, lsl #32
    // 0xc1461c: LoadField: d1 = r4->field_7
    //     0xc1461c: ldur            d1, [x4, #7]
    // 0xc14620: fcmp            d0, d1
    // 0xc14624: b.ge            #0xc14638
    // 0xc14628: sub             x4, x3, #1
    // 0xc1462c: mov             x3, x4
    // 0xc14630: b               #0xc14600
    // 0xc14634: r3 = -1
    //     0xc14634: mov             x3, #-1
    // 0xc14638: stur            x3, [fp, #-0x68]
    // 0xc1463c: LoadField: d0 = r0->field_7
    //     0xc1463c: ldur            d0, [x0, #7]
    // 0xc14640: stur            d0, [fp, #-0xd0]
    // 0xc14644: LoadField: r0 = r2->field_9b
    //     0xc14644: ldur            w0, [x2, #0x9b]
    // 0xc14648: DecompressPointer r0
    //     0xc14648: add             x0, x0, HEAP, lsl #32
    // 0xc1464c: cmp             w0, NULL
    // 0xc14650: b.ne            #0xc14660
    // 0xc14654: mov             x2, x3
    // 0xc14658: r3 = -1
    //     0xc14658: mov             x3, #-1
    // 0xc1465c: b               #0xc14720
    // 0xc14660: r2 = LoadClassIdInstr(r0)
    //     0xc14660: ldur            x2, [x0, #-1]
    //     0xc14664: ubfx            x2, x2, #0xc, #0x14
    // 0xc14668: str             x0, [SP]
    // 0xc1466c: mov             x0, x2
    // 0xc14670: r0 = GDT[cid_x0 + 0xf078]()
    //     0xc14670: mov             x17, #0xf078
    //     0xc14674: add             lr, x0, x17
    //     0xc14678: ldr             lr, [x21, lr, lsl #3]
    //     0xc1467c: blr             lr
    // 0xc14680: r1 = LoadInt32Instr(r0)
    //     0xc14680: sbfx            x1, x0, #1, #0x1f
    //     0xc14684: tbz             w0, #0, #0xc1468c
    //     0xc14688: ldur            x1, [x0, #7]
    // 0xc1468c: sub             x0, x1, #1
    // 0xc14690: mov             x4, x0
    // 0xc14694: ldur            d0, [fp, #-0xd0]
    // 0xc14698: ldur            x3, [fp, #-0x28]
    // 0xc1469c: stur            x4, [fp, #-0x70]
    // 0xc146a0: CheckStackOverflow
    //     0xc146a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc146a4: cmp             SP, x16
    //     0xc146a8: b.ls            #0xc15400
    // 0xc146ac: tbnz            x4, #0x3f, #0xc14718
    // 0xc146b0: LoadField: r0 = r3->field_f
    //     0xc146b0: ldur            w0, [x3, #0xf]
    // 0xc146b4: DecompressPointer r0
    //     0xc146b4: add             x0, x0, HEAP, lsl #32
    // 0xc146b8: LoadField: r1 = r0->field_9b
    //     0xc146b8: ldur            w1, [x0, #0x9b]
    // 0xc146bc: DecompressPointer r1
    //     0xc146bc: add             x1, x1, HEAP, lsl #32
    // 0xc146c0: cmp             w1, NULL
    // 0xc146c4: b.eq            #0xc15408
    // 0xc146c8: r0 = LoadClassIdInstr(r1)
    //     0xc146c8: ldur            x0, [x1, #-1]
    //     0xc146cc: ubfx            x0, x0, #0xc, #0x14
    // 0xc146d0: mov             x2, x4
    // 0xc146d4: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0xc146d4: mov             x17, #0x2eb9
    //     0xc146d8: movk            x17, #1, lsl #16
    //     0xc146dc: add             lr, x0, x17
    //     0xc146e0: ldr             lr, [x21, lr, lsl #3]
    //     0xc146e4: blr             lr
    // 0xc146e8: LoadField: d0 = r0->field_7
    //     0xc146e8: ldur            d0, [x0, #7]
    // 0xc146ec: ldur            d1, [fp, #-0xd0]
    // 0xc146f0: fcmp            d1, d0
    // 0xc146f4: b.ge            #0xc14708
    // 0xc146f8: ldur            x0, [fp, #-0x70]
    // 0xc146fc: sub             x4, x0, #1
    // 0xc14700: mov             v0.16b, v1.16b
    // 0xc14704: b               #0xc14698
    // 0xc14708: ldur            x0, [fp, #-0x70]
    // 0xc1470c: mov             x3, x0
    // 0xc14710: ldur            x2, [fp, #-0x68]
    // 0xc14714: b               #0xc14720
    // 0xc14718: ldur            x2, [fp, #-0x68]
    // 0xc1471c: r3 = -1
    //     0xc1471c: mov             x3, #-1
    // 0xc14720: cmn             x2, #1
    // 0xc14724: b.eq            #0xc147c0
    // 0xc14728: r0 = BoxInt64Instr(r3)
    //     0xc14728: sbfiz           x0, x3, #1, #0x1f
    //     0xc1472c: cmp             x3, x0, asr #1
    //     0xc14730: b.eq            #0xc1473c
    //     0xc14734: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc14738: stur            x3, [x0, #7]
    // 0xc1473c: mov             x4, x0
    // 0xc14740: r0 = BoxInt64Instr(r3)
    //     0xc14740: sbfiz           x0, x3, #1, #0x1f
    //     0xc14744: cmp             x3, x0, asr #1
    //     0xc14748: b.eq            #0xc14754
    //     0xc1474c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc14750: stur            x3, [x0, #7]
    // 0xc14754: cmn             w0, #2
    // 0xc14758: b.eq            #0xc147c0
    // 0xc1475c: ldur            x3, [fp, #-0x40]
    // 0xc14760: ldur            x0, [fp, #-0x48]
    // 0xc14764: mov             x1, x2
    // 0xc14768: cmp             x1, x0
    // 0xc1476c: b.hs            #0xc1540c
    // 0xc14770: ArrayLoad: r0 = r3[r2]  ; Unknown_4
    //     0xc14770: add             x16, x3, x2, lsl #2
    //     0xc14774: ldur            w0, [x16, #0xf]
    // 0xc14778: DecompressPointer r0
    //     0xc14778: add             x0, x0, HEAP, lsl #32
    // 0xc1477c: r1 = LoadClassIdInstr(r0)
    //     0xc1477c: ldur            x1, [x0, #-1]
    //     0xc14780: ubfx            x1, x1, #0xc, #0x14
    // 0xc14784: stp             x4, x0, [SP]
    // 0xc14788: mov             x0, x1
    // 0xc1478c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xc1478c: sub             lr, x0, #0xdfd
    //     0xc14790: ldr             lr, [x21, lr, lsl #3]
    //     0xc14794: blr             lr
    // 0xc14798: r1 = LoadClassIdInstr(r0)
    //     0xc14798: ldur            x1, [x0, #-1]
    //     0xc1479c: ubfx            x1, x1, #0xc, #0x14
    // 0xc147a0: ldur            x16, [fp, #-0x58]
    // 0xc147a4: stp             x16, x0, [SP]
    // 0xc147a8: mov             x0, x1
    // 0xc147ac: r0 = GDT[cid_x0 + 0x175da]()
    //     0xc147ac: mov             x17, #0x75da
    //     0xc147b0: movk            x17, #1, lsl #16
    //     0xc147b4: add             lr, x0, x17
    //     0xc147b8: ldr             lr, [x21, lr, lsl #3]
    //     0xc147bc: blr             lr
    // 0xc147c0: ldur            x0, [fp, #-0x38]
    // 0xc147c4: ldur            x3, [fp, #-8]
    // 0xc147c8: ldur            x4, [fp, #-0x20]
    // 0xc147cc: ldur            x6, [fp, #-0x60]
    // 0xc147d0: ldur            x5, [fp, #-0x50]
    // 0xc147d4: b               #0xc14428
    // 0xc147d8: mov             x1, x3
    // 0xc147dc: LoadField: r0 = r1->field_8b
    //     0xc147dc: ldur            w0, [x1, #0x8b]
    // 0xc147e0: DecompressPointer r0
    //     0xc147e0: add             x0, x0, HEAP, lsl #32
    // 0xc147e4: stur            x0, [fp, #-0x80]
    // 0xc147e8: LoadField: r2 = r1->field_8f
    //     0xc147e8: ldur            w2, [x1, #0x8f]
    // 0xc147ec: DecompressPointer r2
    //     0xc147ec: add             x2, x2, HEAP, lsl #32
    // 0xc147f0: stur            x2, [fp, #-0x78]
    // 0xc147f4: LoadField: r3 = r1->field_97
    //     0xc147f4: ldur            w3, [x1, #0x97]
    // 0xc147f8: DecompressPointer r3
    //     0xc147f8: add             x3, x3, HEAP, lsl #32
    // 0xc147fc: stur            x3, [fp, #-0x58]
    // 0xc14800: ldur            x6, [fp, #-0x30]
    // 0xc14804: r7 = 0
    //     0xc14804: mov             x7, #0
    // 0xc14808: ldur            x5, [fp, #-0x28]
    // 0xc1480c: ldur            x4, [fp, #-0x40]
    // 0xc14810: stur            x7, [fp, #-0x38]
    // 0xc14814: CheckStackOverflow
    //     0xc14814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc14818: cmp             SP, x16
    //     0xc1481c: b.ls            #0xc15410
    // 0xc14820: LoadField: r8 = r1->field_5b
    //     0xc14820: ldur            x8, [x1, #0x5b]
    // 0xc14824: cmp             x7, x8
    // 0xc14828: b.ge            #0xc15384
    // 0xc1482c: r1 = 1
    //     0xc1482c: mov             x1, #1
    // 0xc14830: r0 = AllocateContext()
    //     0xc14830: bl              #0x13de838  ; AllocateContextStub
    // 0xc14834: mov             x3, x0
    // 0xc14838: ldur            x0, [fp, #-0x28]
    // 0xc1483c: stur            x3, [fp, #-0x88]
    // 0xc14840: StoreField: r3->field_b = r0
    //     0xc14840: stur            w0, [x3, #0xb]
    // 0xc14844: ldur            x1, [fp, #-8]
    // 0xc14848: ldur            x2, [fp, #-0x38]
    // 0xc1484c: r0 = getRowBox()
    //     0xc1484c: bl              #0xc154d8  ; [package:flutter/src/rendering/table.dart] RenderTable::getRowBox
    // 0xc14850: mov             x4, x0
    // 0xc14854: ldur            x3, [fp, #-0x88]
    // 0xc14858: stur            x4, [fp, #-0x98]
    // 0xc1485c: StoreField: r3->field_f = r0
    //     0xc1485c: stur            w0, [x3, #0xf]
    //     0xc14860: ldurb           w16, [x3, #-1]
    //     0xc14864: ldurb           w17, [x0, #-1]
    //     0xc14868: and             x16, x17, x16, lsr #2
    //     0xc1486c: tst             x16, HEAP, lsr #32
    //     0xc14870: b.eq            #0xc14878
    //     0xc14874: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc14878: LoadField: d0 = r4->field_1f
    //     0xc14878: ldur            d0, [x4, #0x1f]
    // 0xc1487c: LoadField: d1 = r4->field_f
    //     0xc1487c: ldur            d1, [x4, #0xf]
    // 0xc14880: stur            d1, [fp, #-0xd8]
    // 0xc14884: fsub            d2, d0, d1
    // 0xc14888: stur            d2, [fp, #-0xd0]
    // 0xc1488c: d0 = 0.000000
    //     0xc1488c: eor             v0.16b, v0.16b, v0.16b
    // 0xc14890: fcmp            d2, d0
    // 0xc14894: b.ne            #0xc148a0
    // 0xc14898: ldur            x2, [fp, #-0x30]
    // 0xc1489c: b               #0xc15364
    // 0xc148a0: ldur            x6, [fp, #-0x38]
    // 0xc148a4: ldur            x5, [fp, #-0x80]
    // 0xc148a8: r0 = BoxInt64Instr(r6)
    //     0xc148a8: sbfiz           x0, x6, #1, #0x1f
    //     0xc148ac: cmp             x6, x0, asr #1
    //     0xc148b0: b.eq            #0xc148bc
    //     0xc148b4: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xc148b8: stur            x6, [x0, #7]
    // 0xc148bc: mov             x1, x5
    // 0xc148c0: mov             x2, x0
    // 0xc148c4: stur            x0, [fp, #-0x90]
    // 0xc148c8: r0 = _getValueOrData()
    //     0xc148c8: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc148cc: ldur            x1, [fp, #-0x80]
    // 0xc148d0: LoadField: r2 = r1->field_f
    //     0xc148d0: ldur            w2, [x1, #0xf]
    // 0xc148d4: DecompressPointer r2
    //     0xc148d4: add             x2, x2, HEAP, lsl #32
    // 0xc148d8: cmp             w2, w0
    // 0xc148dc: b.ne            #0xc148e4
    // 0xc148e0: r0 = Null
    //     0xc148e0: mov             x0, NULL
    // 0xc148e4: cmp             w0, NULL
    // 0xc148e8: b.ne            #0xc1492c
    // 0xc148ec: r0 = SemanticsNode()
    //     0xc148ec: bl              #0x894094  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xf0)
    // 0xc148f0: ldur            x2, [fp, #-0x88]
    // 0xc148f4: r1 = Function '<anonymous closure>':.
    //     0xc148f4: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa12c8] AnonymousClosure: (0xc1585c), in [package:flutter/src/rendering/table.dart] RenderTable::assembleSemanticsNode (0xc1425c)
    //     0xc148f8: ldr             x1, [x1, #0x2c8]
    // 0xc148fc: stur            x0, [fp, #-0x88]
    // 0xc14900: r0 = AllocateClosure()
    //     0xc14900: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc14904: str             x0, [SP]
    // 0xc14908: ldur            x1, [fp, #-0x88]
    // 0xc1490c: r4 = const [0, 0x2, 0x1, 0x1, showOnScreen, 0x1, null]
    //     0xc1490c: ldr             x4, [PP, #0x29d8]  ; [pp+0x29d8] List(7) [0, 0x2, 0x1, 0x1, "showOnScreen", 0x1, Null]
    // 0xc14910: r0 = SemanticsNode()
    //     0xc14910: bl              #0x893ce8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0xc14914: ldur            x1, [fp, #-0x80]
    // 0xc14918: ldur            x2, [fp, #-0x90]
    // 0xc1491c: ldur            x3, [fp, #-0x88]
    // 0xc14920: r0 = []=()
    //     0xc14920: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xc14924: ldur            x3, [fp, #-0x88]
    // 0xc14928: b               #0xc14930
    // 0xc1492c: mov             x3, x0
    // 0xc14930: ldur            x0, [fp, #-0x98]
    // 0xc14934: ldur            d0, [fp, #-0xd0]
    // 0xc14938: stur            x3, [fp, #-0x88]
    // 0xc1493c: r1 = <SemanticsNode>
    //     0xc1493c: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0xc14940: r2 = 0
    //     0xc14940: mov             x2, #0
    // 0xc14944: r0 = _GrowableList()
    //     0xc14944: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xc14948: mov             x2, x0
    // 0xc1494c: ldur            d0, [fp, #-0xd0]
    // 0xc14950: d1 = 0.000000
    //     0xc14950: ldr             d1, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xc14954: stur            x2, [fp, #-0xa0]
    // 0xc14958: fadd            d2, d0, d1
    // 0xc1495c: stur            d2, [fp, #-0x100]
    // 0xc14960: d3 = 0.000000
    //     0xc14960: eor             v3.16b, v3.16b, v3.16b
    // 0xc14964: fadd            d4, d0, d3
    // 0xc14968: ldur            x0, [fp, #-0x98]
    // 0xc1496c: stur            d4, [fp, #-0xf8]
    // 0xc14970: ArrayLoad: d5 = r0[0]  ; List_8
    //     0xc14970: ldur            d5, [x0, #0x17]
    // 0xc14974: stur            d5, [fp, #-0xf0]
    // 0xc14978: LoadField: d6 = r0->field_7
    //     0xc14978: ldur            d6, [x0, #7]
    // 0xc1497c: stur            d6, [fp, #-0xe8]
    // 0xc14980: fsub            d7, d5, d6
    // 0xc14984: stur            d7, [fp, #-0xe0]
    // 0xc14988: r7 = 0
    //     0xc14988: mov             x7, #0
    // 0xc1498c: ldur            x4, [fp, #-8]
    // 0xc14990: ldur            x3, [fp, #-0x38]
    // 0xc14994: ldur            x5, [fp, #-0x58]
    // 0xc14998: ldur            x6, [fp, #-0x40]
    // 0xc1499c: stur            x7, [fp, #-0x50]
    // 0xc149a0: CheckStackOverflow
    //     0xc149a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc149a4: cmp             SP, x16
    //     0xc149a8: b.ls            #0xc15418
    // 0xc149ac: LoadField: r0 = r4->field_53
    //     0xc149ac: ldur            x0, [x4, #0x53]
    // 0xc149b0: cmp             x7, x0
    // 0xc149b4: b.ge            #0xc15230
    // 0xc149b8: ldur            x0, [fp, #-0x48]
    // 0xc149bc: mov             x1, x3
    // 0xc149c0: cmp             x1, x0
    // 0xc149c4: b.hs            #0xc15420
    // 0xc149c8: ArrayLoad: r8 = r6[r3]  ; Unknown_4
    //     0xc149c8: add             x16, x6, x3, lsl #2
    //     0xc149cc: ldur            w8, [x16, #0xf]
    // 0xc149d0: DecompressPointer r8
    //     0xc149d0: add             x8, x8, HEAP, lsl #32
    // 0xc149d4: r0 = BoxInt64Instr(r7)
    //     0xc149d4: sbfiz           x0, x7, #1, #0x1f
    //     0xc149d8: cmp             x7, x0, asr #1
    //     0xc149dc: b.eq            #0xc149e8
    //     0xc149e0: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xc149e4: stur            x7, [x0, #7]
    // 0xc149e8: mov             x1, x0
    // 0xc149ec: stur            x1, [fp, #-0x90]
    // 0xc149f0: r0 = LoadClassIdInstr(r8)
    //     0xc149f0: ldur            x0, [x8, #-1]
    //     0xc149f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc149f8: stp             x1, x8, [SP]
    // 0xc149fc: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xc149fc: sub             lr, x0, #0xdfd
    //     0xc14a00: ldr             lr, [x21, lr, lsl #3]
    //     0xc14a04: blr             lr
    // 0xc14a08: mov             x2, x0
    // 0xc14a0c: stur            x2, [fp, #-0x98]
    // 0xc14a10: r0 = LoadClassIdInstr(r2)
    //     0xc14a10: ldur            x0, [x2, #-1]
    //     0xc14a14: ubfx            x0, x0, #0xc, #0x14
    // 0xc14a18: mov             x1, x2
    // 0xc14a1c: r0 = GDT[cid_x0 + 0x12b36]()
    //     0xc14a1c: mov             x17, #0x2b36
    //     0xc14a20: movk            x17, #1, lsl #16
    //     0xc14a24: add             lr, x0, x17
    //     0xc14a28: ldr             lr, [x21, lr, lsl #3]
    //     0xc14a2c: blr             lr
    // 0xc14a30: tbnz            w0, #4, #0xc14a3c
    // 0xc14a34: ldur            x2, [fp, #-0xa0]
    // 0xc14a38: b               #0xc15204
    // 0xc14a3c: ldur            x1, [fp, #-0x98]
    // 0xc14a40: r0 = LoadClassIdInstr(r1)
    //     0xc14a40: ldur            x0, [x1, #-1]
    //     0xc14a44: ubfx            x0, x0, #0xc, #0x14
    // 0xc14a48: str             x1, [SP]
    // 0xc14a4c: r0 = GDT[cid_x0 + 0xf078]()
    //     0xc14a4c: mov             x17, #0xf078
    //     0xc14a50: add             lr, x0, x17
    //     0xc14a54: ldr             lr, [x21, lr, lsl #3]
    //     0xc14a58: blr             lr
    // 0xc14a5c: r1 = LoadInt32Instr(r0)
    //     0xc14a5c: sbfx            x1, x0, #1, #0x1f
    //     0xc14a60: tbz             w0, #0, #0xc14a68
    //     0xc14a64: ldur            x1, [x0, #7]
    // 0xc14a68: cmp             x1, #1
    // 0xc14a6c: b.le            #0xc14a78
    // 0xc14a70: r2 = true
    //     0xc14a70: add             x2, NULL, #0x20  ; true
    // 0xc14a74: b               #0xc14b04
    // 0xc14a78: ldur            x2, [fp, #-0x98]
    // 0xc14a7c: r0 = LoadClassIdInstr(r2)
    //     0xc14a7c: ldur            x0, [x2, #-1]
    //     0xc14a80: ubfx            x0, x0, #0xc, #0x14
    // 0xc14a84: mov             x1, x2
    // 0xc14a88: r0 = GDT[cid_x0 + 0x13b04]()
    //     0xc14a88: mov             x17, #0x3b04
    //     0xc14a8c: movk            x17, #1, lsl #16
    //     0xc14a90: add             lr, x0, x17
    //     0xc14a94: ldr             lr, [x21, lr, lsl #3]
    //     0xc14a98: blr             lr
    // 0xc14a9c: LoadField: r1 = r0->field_d3
    //     0xc14a9c: ldur            w1, [x0, #0xd3]
    // 0xc14aa0: DecompressPointer r1
    //     0xc14aa0: add             x1, x1, HEAP, lsl #32
    // 0xc14aa4: r16 = Instance_SemanticsRole
    //     0xc14aa4: add             x16, PP, #0x96, lsl #12  ; [pp+0x96d38] Obj!SemanticsRole@12c78a1
    //     0xc14aa8: ldr             x16, [x16, #0xd38]
    // 0xc14aac: cmp             w1, w16
    // 0xc14ab0: b.eq            #0xc14b00
    // 0xc14ab4: ldur            x2, [fp, #-0x98]
    // 0xc14ab8: r0 = LoadClassIdInstr(r2)
    //     0xc14ab8: ldur            x0, [x2, #-1]
    //     0xc14abc: ubfx            x0, x0, #0xc, #0x14
    // 0xc14ac0: mov             x1, x2
    // 0xc14ac4: r0 = GDT[cid_x0 + 0x13b04]()
    //     0xc14ac4: mov             x17, #0x3b04
    //     0xc14ac8: movk            x17, #1, lsl #16
    //     0xc14acc: add             lr, x0, x17
    //     0xc14ad0: ldr             lr, [x21, lr, lsl #3]
    //     0xc14ad4: blr             lr
    // 0xc14ad8: LoadField: r1 = r0->field_d3
    //     0xc14ad8: ldur            w1, [x0, #0xd3]
    // 0xc14adc: DecompressPointer r1
    //     0xc14adc: add             x1, x1, HEAP, lsl #32
    // 0xc14ae0: r16 = Instance_SemanticsRole
    //     0xc14ae0: add             x16, PP, #0x8f, lsl #12  ; [pp+0x8fff8] Obj!SemanticsRole@12c7881
    //     0xc14ae4: ldr             x16, [x16, #0xff8]
    // 0xc14ae8: cmp             w1, w16
    // 0xc14aec: r16 = true
    //     0xc14aec: add             x16, NULL, #0x20  ; true
    // 0xc14af0: r17 = false
    //     0xc14af0: add             x17, NULL, #0x30  ; false
    // 0xc14af4: csel            x0, x16, x17, ne
    // 0xc14af8: mov             x2, x0
    // 0xc14afc: b               #0xc14b04
    // 0xc14b00: r2 = false
    //     0xc14b00: add             x2, NULL, #0x30  ; false
    // 0xc14b04: stur            x2, [fp, #-0xa8]
    // 0xc14b08: tbz             w2, #4, #0xc14b38
    // 0xc14b0c: ldur            x3, [fp, #-0x98]
    // 0xc14b10: r0 = LoadClassIdInstr(r3)
    //     0xc14b10: ldur            x0, [x3, #-1]
    //     0xc14b14: ubfx            x0, x0, #0xc, #0x14
    // 0xc14b18: mov             x1, x3
    // 0xc14b1c: r0 = GDT[cid_x0 + 0x13b04]()
    //     0xc14b1c: mov             x17, #0x3b04
    //     0xc14b20: movk            x17, #1, lsl #16
    //     0xc14b24: add             lr, x0, x17
    //     0xc14b28: ldr             lr, [x21, lr, lsl #3]
    //     0xc14b2c: blr             lr
    // 0xc14b30: mov             x5, x0
    // 0xc14b34: b               #0xc14bc0
    // 0xc14b38: ldur            x1, [fp, #-0x38]
    // 0xc14b3c: ldur            x2, [fp, #-0x50]
    // 0xc14b40: r0 = _Index()
    //     0xc14b40: bl              #0xc154ac  ; Allocate_IndexStub -> _Index (size=0x18)
    // 0xc14b44: mov             x3, x0
    // 0xc14b48: ldur            x0, [fp, #-0x38]
    // 0xc14b4c: stur            x3, [fp, #-0xb0]
    // 0xc14b50: StoreField: r3->field_7 = r0
    //     0xc14b50: stur            x0, [x3, #7]
    // 0xc14b54: ldur            x4, [fp, #-0x50]
    // 0xc14b58: StoreField: r3->field_f = r4
    //     0xc14b58: stur            x4, [x3, #0xf]
    // 0xc14b5c: r1 = Function '<anonymous closure>':.
    //     0xc14b5c: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa12d0] AnonymousClosure: (0xc15818), in [package:flutter/src/rendering/table.dart] RenderTable::assembleSemanticsNode (0xc1425c)
    //     0xc14b60: ldr             x1, [x1, #0x2d0]
    // 0xc14b64: r2 = Null
    //     0xc14b64: mov             x2, NULL
    // 0xc14b68: r0 = AllocateClosure()
    //     0xc14b68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc14b6c: ldur            x1, [fp, #-0x78]
    // 0xc14b70: ldur            x2, [fp, #-0xb0]
    // 0xc14b74: mov             x3, x0
    // 0xc14b78: r0 = putIfAbsent()
    //     0xc14b78: bl              #0xa1be20  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xc14b7c: stur            x0, [fp, #-0xb0]
    // 0xc14b80: r0 = SemanticsConfiguration()
    //     0xc14b80: bl              #0x839284  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0xc8)
    // 0xc14b84: mov             x1, x0
    // 0xc14b88: stur            x0, [fp, #-0xb8]
    // 0xc14b8c: r0 = SemanticsConfiguration()
    //     0xc14b8c: bl              #0x837c94  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0xc14b90: ldur            x2, [fp, #-0xb8]
    // 0xc14b94: r0 = Instance_SemanticsRole
    //     0xc14b94: add             x0, PP, #0x96, lsl #12  ; [pp+0x96d38] Obj!SemanticsRole@12c78a1
    //     0xc14b98: ldr             x0, [x0, #0xd38]
    // 0xc14b9c: StoreField: r2->field_63 = r0
    //     0xc14b9c: stur            w0, [x2, #0x63]
    // 0xc14ba0: r3 = true
    //     0xc14ba0: add             x3, NULL, #0x20  ; true
    // 0xc14ba4: StoreField: r2->field_1f = r3
    //     0xc14ba4: stur            w3, [x2, #0x1f]
    // 0xc14ba8: ldur            x16, [fp, #-0x98]
    // 0xc14bac: str             x16, [SP]
    // 0xc14bb0: ldur            x1, [fp, #-0xb0]
    // 0xc14bb4: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xc14bb4: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xc14bb8: r0 = updateWith()
    //     0xc14bb8: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc14bbc: ldur            x5, [fp, #-0xb0]
    // 0xc14bc0: ldur            x4, [fp, #-8]
    // 0xc14bc4: ldur            x3, [fp, #-0x50]
    // 0xc14bc8: stur            x5, [fp, #-0xb0]
    // 0xc14bcc: LoadField: r0 = r4->field_53
    //     0xc14bcc: ldur            x0, [x4, #0x53]
    // 0xc14bd0: sub             x1, x0, #1
    // 0xc14bd4: cmp             x3, x1
    // 0xc14bd8: b.ne            #0xc14c24
    // 0xc14bdc: ldur            d0, [fp, #-0xe0]
    // 0xc14be0: LoadField: r1 = r4->field_9b
    //     0xc14be0: ldur            w1, [x4, #0x9b]
    // 0xc14be4: DecompressPointer r1
    //     0xc14be4: add             x1, x1, HEAP, lsl #32
    // 0xc14be8: cmp             w1, NULL
    // 0xc14bec: b.eq            #0xc15424
    // 0xc14bf0: r0 = LoadClassIdInstr(r1)
    //     0xc14bf0: ldur            x0, [x1, #-1]
    //     0xc14bf4: ubfx            x0, x0, #0xc, #0x14
    // 0xc14bf8: mov             x2, x3
    // 0xc14bfc: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0xc14bfc: mov             x17, #0x2eb9
    //     0xc14c00: movk            x17, #1, lsl #16
    //     0xc14c04: add             lr, x0, x17
    //     0xc14c08: ldr             lr, [x21, lr, lsl #3]
    //     0xc14c0c: blr             lr
    // 0xc14c10: LoadField: d0 = r0->field_7
    //     0xc14c10: ldur            d0, [x0, #7]
    // 0xc14c14: ldur            d1, [fp, #-0xe0]
    // 0xc14c18: fsub            d2, d1, d0
    // 0xc14c1c: mov             v1.16b, v2.16b
    // 0xc14c20: b               #0xc14cac
    // 0xc14c24: ldur            d1, [fp, #-0xe0]
    // 0xc14c28: LoadField: r1 = r4->field_9b
    //     0xc14c28: ldur            w1, [x4, #0x9b]
    // 0xc14c2c: DecompressPointer r1
    //     0xc14c2c: add             x1, x1, HEAP, lsl #32
    // 0xc14c30: cmp             w1, NULL
    // 0xc14c34: b.eq            #0xc15428
    // 0xc14c38: add             x2, x3, #1
    // 0xc14c3c: r0 = LoadClassIdInstr(r1)
    //     0xc14c3c: ldur            x0, [x1, #-1]
    //     0xc14c40: ubfx            x0, x0, #0xc, #0x14
    // 0xc14c44: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0xc14c44: mov             x17, #0x2eb9
    //     0xc14c48: movk            x17, #1, lsl #16
    //     0xc14c4c: add             lr, x0, x17
    //     0xc14c50: ldr             lr, [x21, lr, lsl #3]
    //     0xc14c54: blr             lr
    // 0xc14c58: mov             x4, x0
    // 0xc14c5c: ldur            x3, [fp, #-8]
    // 0xc14c60: stur            x4, [fp, #-0xb8]
    // 0xc14c64: LoadField: r1 = r3->field_9b
    //     0xc14c64: ldur            w1, [x3, #0x9b]
    // 0xc14c68: DecompressPointer r1
    //     0xc14c68: add             x1, x1, HEAP, lsl #32
    // 0xc14c6c: cmp             w1, NULL
    // 0xc14c70: b.eq            #0xc1542c
    // 0xc14c74: r0 = LoadClassIdInstr(r1)
    //     0xc14c74: ldur            x0, [x1, #-1]
    //     0xc14c78: ubfx            x0, x0, #0xc, #0x14
    // 0xc14c7c: ldur            x2, [fp, #-0x50]
    // 0xc14c80: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0xc14c80: mov             x17, #0x2eb9
    //     0xc14c84: movk            x17, #1, lsl #16
    //     0xc14c88: add             lr, x0, x17
    //     0xc14c8c: ldr             lr, [x21, lr, lsl #3]
    //     0xc14c90: blr             lr
    // 0xc14c94: mov             x1, x0
    // 0xc14c98: ldur            x0, [fp, #-0xb8]
    // 0xc14c9c: LoadField: d0 = r0->field_7
    //     0xc14c9c: ldur            d0, [x0, #7]
    // 0xc14ca0: LoadField: d1 = r1->field_7
    //     0xc14ca0: ldur            d1, [x1, #7]
    // 0xc14ca4: fsub            d2, d0, d1
    // 0xc14ca8: mov             v1.16b, v2.16b
    // 0xc14cac: d0 = 0.000000
    //     0xc14cac: eor             v0.16b, v0.16b, v0.16b
    // 0xc14cb0: r17 = -264
    //     0xc14cb0: mov             x17, #-0x108
    // 0xc14cb4: str             d1, [fp, x17]
    // 0xc14cb8: fcmp            d0, d1
    // 0xc14cbc: b.lt            #0xc14cc8
    // 0xc14cc0: ldur            x2, [fp, #-0xa0]
    // 0xc14cc4: b               #0xc15204
    // 0xc14cc8: ldur            x3, [fp, #-0xa8]
    // 0xc14ccc: tbnz            w3, #4, #0xc14dec
    // 0xc14cd0: ldur            x4, [fp, #-8]
    // 0xc14cd4: ldur            x5, [fp, #-0xb0]
    // 0xc14cd8: LoadField: r1 = r4->field_9b
    //     0xc14cd8: ldur            w1, [x4, #0x9b]
    // 0xc14cdc: DecompressPointer r1
    //     0xc14cdc: add             x1, x1, HEAP, lsl #32
    // 0xc14ce0: cmp             w1, NULL
    // 0xc14ce4: b.eq            #0xc15430
    // 0xc14ce8: r0 = LoadClassIdInstr(r1)
    //     0xc14ce8: ldur            x0, [x1, #-1]
    //     0xc14cec: ubfx            x0, x0, #0xc, #0x14
    // 0xc14cf0: ldur            x2, [fp, #-0x50]
    // 0xc14cf4: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0xc14cf4: mov             x17, #0x2eb9
    //     0xc14cf8: movk            x17, #1, lsl #16
    //     0xc14cfc: add             lr, x0, x17
    //     0xc14d00: ldr             lr, [x21, lr, lsl #3]
    //     0xc14d04: blr             lr
    // 0xc14d08: stur            x0, [fp, #-0xb8]
    // 0xc14d0c: r0 = Matrix4()
    //     0xc14d0c: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xc14d10: r4 = 32
    //     0xc14d10: mov             x4, #0x20
    // 0xc14d14: stur            x0, [fp, #-0xc0]
    // 0xc14d18: r0 = AllocateFloat64Array()
    //     0xc14d18: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xc14d1c: mov             x2, x0
    // 0xc14d20: ldur            x0, [fp, #-0xc0]
    // 0xc14d24: stur            x2, [fp, #-0xc8]
    // 0xc14d28: StoreField: r0->field_7 = r2
    //     0xc14d28: stur            w2, [x0, #7]
    // 0xc14d2c: mov             x1, x0
    // 0xc14d30: r0 = setIdentity()
    //     0xc14d30: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xc14d34: ldur            x0, [fp, #-0xc8]
    // 0xc14d38: StoreField: r0->field_87 = rZR
    //     0xc14d38: stur            xzr, [x0, #0x87]
    // 0xc14d3c: StoreField: r0->field_7f = rZR
    //     0xc14d3c: stur            xzr, [x0, #0x7f]
    // 0xc14d40: ldur            x1, [fp, #-0xb8]
    // 0xc14d44: LoadField: d0 = r1->field_7
    //     0xc14d44: ldur            d0, [x1, #7]
    // 0xc14d48: StoreField: r0->field_77 = d0
    //     0xc14d48: stur            d0, [x0, #0x77]
    // 0xc14d4c: ldur            x0, [fp, #-0xb0]
    // 0xc14d50: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc14d50: ldur            w1, [x0, #0x17]
    // 0xc14d54: DecompressPointer r1
    //     0xc14d54: add             x1, x1, HEAP, lsl #32
    // 0xc14d58: ldur            x2, [fp, #-0xc0]
    // 0xc14d5c: r0 = matrixEquals()
    //     0xc14d5c: bl              #0x892cb0  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::matrixEquals
    // 0xc14d60: tbz             w0, #4, #0xc14da4
    // 0xc14d64: ldur            x1, [fp, #-0xc0]
    // 0xc14d68: r0 = isIdentity()
    //     0xc14d68: bl              #0x892998  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::isIdentity
    // 0xc14d6c: tbnz            w0, #4, #0xc14d78
    // 0xc14d70: r0 = Null
    //     0xc14d70: mov             x0, NULL
    // 0xc14d74: b               #0xc14d7c
    // 0xc14d78: ldur            x0, [fp, #-0xc0]
    // 0xc14d7c: ldur            x2, [fp, #-0xb0]
    // 0xc14d80: ArrayStore: r2[0] = r0  ; List_4
    //     0xc14d80: stur            w0, [x2, #0x17]
    //     0xc14d84: ldurb           w16, [x2, #-1]
    //     0xc14d88: ldurb           w17, [x0, #-1]
    //     0xc14d8c: and             x16, x17, x16, lsr #2
    //     0xc14d90: tst             x16, HEAP, lsr #32
    //     0xc14d94: b.eq            #0xc14d9c
    //     0xc14d98: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc14d9c: mov             x1, x2
    // 0xc14da0: r0 = _markDirty()
    //     0xc14da0: bl              #0x87ffac  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::_markDirty
    // 0xc14da4: r17 = -264
    //     0xc14da4: mov             x17, #-0x108
    // 0xc14da8: ldr             d1, [fp, x17]
    // 0xc14dac: ldur            d2, [fp, #-0xf8]
    // 0xc14db0: d0 = 0.000000
    //     0xc14db0: eor             v0.16b, v0.16b, v0.16b
    // 0xc14db4: fadd            d3, d1, d0
    // 0xc14db8: r17 = -272
    //     0xc14db8: mov             x17, #-0x110
    // 0xc14dbc: str             d3, [fp, x17]
    // 0xc14dc0: r0 = Rect()
    //     0xc14dc0: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc14dc4: StoreField: r0->field_7 = rZR
    //     0xc14dc4: stur            xzr, [x0, #7]
    // 0xc14dc8: StoreField: r0->field_f = rZR
    //     0xc14dc8: stur            xzr, [x0, #0xf]
    // 0xc14dcc: r17 = -272
    //     0xc14dcc: mov             x17, #-0x110
    // 0xc14dd0: ldr             d0, [fp, x17]
    // 0xc14dd4: ArrayStore: r0[0] = d0  ; List_8
    //     0xc14dd4: stur            d0, [x0, #0x17]
    // 0xc14dd8: ldur            d0, [fp, #-0xf8]
    // 0xc14ddc: StoreField: r0->field_1f = d0
    //     0xc14ddc: stur            d0, [x0, #0x1f]
    // 0xc14de0: ldur            x1, [fp, #-0xb0]
    // 0xc14de4: mov             x2, x0
    // 0xc14de8: r0 = rect=()
    //     0xc14de8: bl              #0x892bd8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0xc14dec: ldur            x1, [fp, #-0x98]
    // 0xc14df0: r0 = LoadClassIdInstr(r1)
    //     0xc14df0: ldur            x0, [x1, #-1]
    //     0xc14df4: ubfx            x0, x0, #0xc, #0x14
    // 0xc14df8: r0 = GDT[cid_x0 + 0x12641]()
    //     0xc14df8: mov             x17, #0x2641
    //     0xc14dfc: movk            x17, #1, lsl #16
    //     0xc14e00: add             lr, x0, x17
    //     0xc14e04: ldr             lr, [x21, lr, lsl #3]
    //     0xc14e08: blr             lr
    // 0xc14e0c: mov             x2, x0
    // 0xc14e10: stur            x2, [fp, #-0x98]
    // 0xc14e14: ldur            x4, [fp, #-8]
    // 0xc14e18: ldur            x6, [fp, #-0x38]
    // 0xc14e1c: ldur            x5, [fp, #-0x50]
    // 0xc14e20: ldur            x3, [fp, #-0xa8]
    // 0xc14e24: r17 = -264
    //     0xc14e24: mov             x17, #-0x108
    // 0xc14e28: ldr             d0, [fp, x17]
    // 0xc14e2c: ldur            d1, [fp, #-0x100]
    // 0xc14e30: ldur            x7, [fp, #-0x58]
    // 0xc14e34: CheckStackOverflow
    //     0xc14e34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc14e38: cmp             SP, x16
    //     0xc14e3c: b.ls            #0xc15434
    // 0xc14e40: r0 = LoadClassIdInstr(r2)
    //     0xc14e40: ldur            x0, [x2, #-1]
    //     0xc14e44: ubfx            x0, x0, #0xc, #0x14
    // 0xc14e48: mov             x1, x2
    // 0xc14e4c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xc14e4c: mov             x17, #0x845b
    //     0xc14e50: movk            x17, #1, lsl #16
    //     0xc14e54: add             lr, x0, x17
    //     0xc14e58: ldr             lr, [x21, lr, lsl #3]
    //     0xc14e5c: blr             lr
    // 0xc14e60: tbnz            w0, #4, #0xc15164
    // 0xc14e64: ldur            x4, [fp, #-0x38]
    // 0xc14e68: ldur            x3, [fp, #-0x50]
    // 0xc14e6c: ldur            x2, [fp, #-0x98]
    // 0xc14e70: r0 = LoadClassIdInstr(r2)
    //     0xc14e70: ldur            x0, [x2, #-1]
    //     0xc14e74: ubfx            x0, x0, #0xc, #0x14
    // 0xc14e78: mov             x1, x2
    // 0xc14e7c: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xc14e7c: mov             x17, #0x7d4c
    //     0xc14e80: movk            x17, #1, lsl #16
    //     0xc14e84: add             lr, x0, x17
    //     0xc14e88: ldr             lr, [x21, lr, lsl #3]
    //     0xc14e8c: blr             lr
    // 0xc14e90: stur            x0, [fp, #-0xb8]
    // 0xc14e94: LoadField: r1 = r0->field_b
    //     0xc14e94: ldur            x1, [x0, #0xb]
    // 0xc14e98: stur            x1, [fp, #-0x68]
    // 0xc14e9c: r0 = _Index()
    //     0xc14e9c: bl              #0xc154ac  ; Allocate_IndexStub -> _Index (size=0x18)
    // 0xc14ea0: mov             x4, x0
    // 0xc14ea4: ldur            x3, [fp, #-0x38]
    // 0xc14ea8: stur            x4, [fp, #-0xc8]
    // 0xc14eac: StoreField: r4->field_7 = r3
    //     0xc14eac: stur            x3, [x4, #7]
    // 0xc14eb0: ldur            x5, [fp, #-0x50]
    // 0xc14eb4: StoreField: r4->field_f = r5
    //     0xc14eb4: stur            x5, [x4, #0xf]
    // 0xc14eb8: ldur            x2, [fp, #-0x68]
    // 0xc14ebc: r0 = BoxInt64Instr(r2)
    //     0xc14ebc: sbfiz           x0, x2, #1, #0x1f
    //     0xc14ec0: cmp             x2, x0, asr #1
    //     0xc14ec4: b.eq            #0xc14ed0
    //     0xc14ec8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc14ecc: stur            x2, [x0, #7]
    // 0xc14ed0: ldur            x1, [fp, #-0x60]
    // 0xc14ed4: mov             x2, x0
    // 0xc14ed8: stur            x0, [fp, #-0xc0]
    // 0xc14edc: r0 = _hashCode()
    //     0xc14edc: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0xc14ee0: mov             x2, x0
    // 0xc14ee4: r0 = BoxInt64Instr(r2)
    //     0xc14ee4: sbfiz           x0, x2, #1, #0x1f
    //     0xc14ee8: cmp             x2, x0, asr #1
    //     0xc14eec: b.eq            #0xc14ef8
    //     0xc14ef0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc14ef4: stur            x2, [x0, #7]
    // 0xc14ef8: ldur            x1, [fp, #-0x60]
    // 0xc14efc: ldur            x2, [fp, #-0xc0]
    // 0xc14f00: ldur            x3, [fp, #-0xc8]
    // 0xc14f04: mov             x5, x0
    // 0xc14f08: r0 = _set()
    //     0xc14f08: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xc14f0c: ldur            x0, [fp, #-0xb8]
    // 0xc14f10: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc14f10: ldur            w1, [x0, #0x17]
    // 0xc14f14: DecompressPointer r1
    //     0xc14f14: add             x1, x1, HEAP, lsl #32
    // 0xc14f18: cmp             w1, NULL
    // 0xc14f1c: b.eq            #0xc14f28
    // 0xc14f20: r0 = getAsTranslation()
    //     0xc14f20: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xc14f24: b               #0xc14f2c
    // 0xc14f28: r0 = Null
    //     0xc14f28: mov             x0, NULL
    // 0xc14f2c: cmp             w0, NULL
    // 0xc14f30: b.ne            #0xc14f3c
    // 0xc14f34: r2 = Instance_Offset
    //     0xc14f34: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc14f38: b               #0xc14f40
    // 0xc14f3c: mov             x2, x0
    // 0xc14f40: ldur            x0, [fp, #-0xb8]
    // 0xc14f44: ldur            d0, [fp, #-0x100]
    // 0xc14f48: LoadField: r1 = r0->field_1f
    //     0xc14f48: ldur            w1, [x0, #0x1f]
    // 0xc14f4c: DecompressPointer r1
    //     0xc14f4c: add             x1, x1, HEAP, lsl #32
    // 0xc14f50: r0 = shift()
    //     0xc14f50: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0xc14f54: mov             x2, x0
    // 0xc14f58: LoadField: d0 = r2->field_1f
    //     0xc14f58: ldur            d0, [x2, #0x1f]
    // 0xc14f5c: ldur            d1, [fp, #-0x100]
    // 0xc14f60: fcmp            d0, d1
    // 0xc14f64: b.le            #0xc14fac
    // 0xc14f68: ldur            x3, [fp, #-0x38]
    // 0xc14f6c: ldur            x4, [fp, #-0x58]
    // 0xc14f70: LoadField: r0 = r4->field_b
    //     0xc14f70: ldur            w0, [x4, #0xb]
    // 0xc14f74: r1 = LoadInt32Instr(r0)
    //     0xc14f74: sbfx            x1, x0, #1, #0x1f
    // 0xc14f78: mov             x0, x1
    // 0xc14f7c: mov             x1, x3
    // 0xc14f80: cmp             x1, x0
    // 0xc14f84: b.hs            #0xc1543c
    // 0xc14f88: LoadField: r0 = r4->field_f
    //     0xc14f88: ldur            w0, [x4, #0xf]
    // 0xc14f8c: DecompressPointer r0
    //     0xc14f8c: add             x0, x0, HEAP, lsl #32
    // 0xc14f90: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xc14f90: add             x16, x0, x3, lsl #2
    //     0xc14f94: ldur            w1, [x16, #0xf]
    // 0xc14f98: DecompressPointer r1
    //     0xc14f98: add             x1, x1, HEAP, lsl #32
    // 0xc14f9c: LoadField: d0 = r1->field_7
    //     0xc14f9c: ldur            d0, [x1, #7]
    // 0xc14fa0: fneg            d2, d0
    // 0xc14fa4: mov             v0.16b, v2.16b
    // 0xc14fa8: b               #0xc14fb8
    // 0xc14fac: ldur            x3, [fp, #-0x38]
    // 0xc14fb0: ldur            x4, [fp, #-0x58]
    // 0xc14fb4: d0 = 0.000000
    //     0xc14fb4: eor             v0.16b, v0.16b, v0.16b
    // 0xc14fb8: ldur            x5, [fp, #-0xa8]
    // 0xc14fbc: r17 = -272
    //     0xc14fbc: mov             x17, #-0x110
    // 0xc14fc0: str             d0, [fp, x17]
    // 0xc14fc4: tbnz            w5, #4, #0xc1502c
    // 0xc14fc8: r17 = -264
    //     0xc14fc8: mov             x17, #-0x108
    // 0xc14fcc: ldr             d2, [fp, x17]
    // 0xc14fd0: LoadField: d3 = r2->field_7
    //     0xc14fd0: ldur            d3, [x2, #7]
    // 0xc14fd4: fcmp            d3, d2
    // 0xc14fd8: b.lt            #0xc15020
    // 0xc14fdc: ldur            x6, [fp, #-8]
    // 0xc14fe0: LoadField: r1 = r6->field_9b
    //     0xc14fe0: ldur            w1, [x6, #0x9b]
    // 0xc14fe4: DecompressPointer r1
    //     0xc14fe4: add             x1, x1, HEAP, lsl #32
    // 0xc14fe8: cmp             w1, NULL
    // 0xc14fec: b.eq            #0xc15440
    // 0xc14ff0: r0 = LoadClassIdInstr(r1)
    //     0xc14ff0: ldur            x0, [x1, #-1]
    //     0xc14ff4: ubfx            x0, x0, #0xc, #0x14
    // 0xc14ff8: ldur            x2, [fp, #-0x50]
    // 0xc14ffc: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0xc14ffc: mov             x17, #0x2eb9
    //     0xc15000: movk            x17, #1, lsl #16
    //     0xc15004: add             lr, x0, x17
    //     0xc15008: ldr             lr, [x21, lr, lsl #3]
    //     0xc1500c: blr             lr
    // 0xc15010: LoadField: d0 = r0->field_7
    //     0xc15010: ldur            d0, [x0, #7]
    // 0xc15014: fneg            d1, d0
    // 0xc15018: mov             v0.16b, v1.16b
    // 0xc1501c: b               #0xc15024
    // 0xc15020: d0 = 0.000000
    //     0xc15020: eor             v0.16b, v0.16b, v0.16b
    // 0xc15024: mov             v1.16b, v0.16b
    // 0xc15028: b               #0xc150c4
    // 0xc1502c: ldur            x3, [fp, #-8]
    // 0xc15030: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xc15030: ldur            d0, [x2, #0x17]
    // 0xc15034: r17 = -280
    //     0xc15034: mov             x17, #-0x118
    // 0xc15038: str             d0, [fp, x17]
    // 0xc1503c: LoadField: r1 = r3->field_9b
    //     0xc1503c: ldur            w1, [x3, #0x9b]
    // 0xc15040: DecompressPointer r1
    //     0xc15040: add             x1, x1, HEAP, lsl #32
    // 0xc15044: cmp             w1, NULL
    // 0xc15048: b.eq            #0xc15444
    // 0xc1504c: r0 = LoadClassIdInstr(r1)
    //     0xc1504c: ldur            x0, [x1, #-1]
    //     0xc15050: ubfx            x0, x0, #0xc, #0x14
    // 0xc15054: ldur            x2, [fp, #-0x50]
    // 0xc15058: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0xc15058: mov             x17, #0x2eb9
    //     0xc1505c: movk            x17, #1, lsl #16
    //     0xc15060: add             lr, x0, x17
    //     0xc15064: ldr             lr, [x21, lr, lsl #3]
    //     0xc15068: blr             lr
    // 0xc1506c: LoadField: d0 = r0->field_7
    //     0xc1506c: ldur            d0, [x0, #7]
    // 0xc15070: r17 = -280
    //     0xc15070: mov             x17, #-0x118
    // 0xc15074: ldr             d1, [fp, x17]
    // 0xc15078: fcmp            d0, d1
    // 0xc1507c: b.lt            #0xc150bc
    // 0xc15080: ldur            x3, [fp, #-8]
    // 0xc15084: LoadField: r1 = r3->field_9b
    //     0xc15084: ldur            w1, [x3, #0x9b]
    // 0xc15088: DecompressPointer r1
    //     0xc15088: add             x1, x1, HEAP, lsl #32
    // 0xc1508c: cmp             w1, NULL
    // 0xc15090: b.eq            #0xc15448
    // 0xc15094: r0 = LoadClassIdInstr(r1)
    //     0xc15094: ldur            x0, [x1, #-1]
    //     0xc15098: ubfx            x0, x0, #0xc, #0x14
    // 0xc1509c: ldur            x2, [fp, #-0x50]
    // 0xc150a0: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0xc150a0: mov             x17, #0x2eb9
    //     0xc150a4: movk            x17, #1, lsl #16
    //     0xc150a8: add             lr, x0, x17
    //     0xc150ac: ldr             lr, [x21, lr, lsl #3]
    //     0xc150b0: blr             lr
    // 0xc150b4: LoadField: d0 = r0->field_7
    //     0xc150b4: ldur            d0, [x0, #7]
    // 0xc150b8: b               #0xc150c0
    // 0xc150bc: d0 = 0.000000
    //     0xc150bc: eor             v0.16b, v0.16b, v0.16b
    // 0xc150c0: mov             v1.16b, v0.16b
    // 0xc150c4: d0 = 0.000000
    //     0xc150c4: eor             v0.16b, v0.16b, v0.16b
    // 0xc150c8: r17 = -280
    //     0xc150c8: mov             x17, #-0x118
    // 0xc150cc: str             d1, [fp, x17]
    // 0xc150d0: fcmp            d1, d0
    // 0xc150d4: b.eq            #0xc150e4
    // 0xc150d8: r17 = -272
    //     0xc150d8: mov             x17, #-0x110
    // 0xc150dc: ldr             d2, [fp, x17]
    // 0xc150e0: b               #0xc150f4
    // 0xc150e4: r17 = -272
    //     0xc150e4: mov             x17, #-0x110
    // 0xc150e8: ldr             d2, [fp, x17]
    // 0xc150ec: fcmp            d2, d0
    // 0xc150f0: b.eq            #0xc1515c
    // 0xc150f4: ldur            x0, [fp, #-0xb8]
    // 0xc150f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc150f8: ldur            w1, [x0, #0x17]
    // 0xc150fc: DecompressPointer r1
    //     0xc150fc: add             x1, x1, HEAP, lsl #32
    // 0xc15100: cmp             w1, NULL
    // 0xc15104: b.eq            #0xc15110
    // 0xc15108: r0 = getAsTranslation()
    //     0xc15108: bl              #0xc155c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xc1510c: b               #0xc15114
    // 0xc15110: r0 = Null
    //     0xc15110: mov             x0, NULL
    // 0xc15114: cmp             w0, NULL
    // 0xc15118: b.ne            #0xc15120
    // 0xc1511c: r0 = Instance_Offset
    //     0xc1511c: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15120: r17 = -272
    //     0xc15120: mov             x17, #-0x110
    // 0xc15124: ldr             d1, [fp, x17]
    // 0xc15128: r17 = -280
    //     0xc15128: mov             x17, #-0x118
    // 0xc1512c: ldr             d0, [fp, x17]
    // 0xc15130: LoadField: d2 = r0->field_7
    //     0xc15130: ldur            d2, [x0, #7]
    // 0xc15134: fadd            d3, d2, d0
    // 0xc15138: LoadField: d0 = r0->field_f
    //     0xc15138: ldur            d0, [x0, #0xf]
    // 0xc1513c: fadd            d2, d0, d1
    // 0xc15140: mov             v0.16b, v3.16b
    // 0xc15144: mov             v1.16b, v2.16b
    // 0xc15148: r1 = Null
    //     0xc15148: mov             x1, NULL
    // 0xc1514c: r0 = Matrix4.translationValues()
    //     0xc1514c: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xc15150: ldur            x1, [fp, #-0xb8]
    // 0xc15154: mov             x2, x0
    // 0xc15158: r0 = transform=()
    //     0xc15158: bl              #0x8928fc  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::transform=
    // 0xc1515c: ldur            x2, [fp, #-0x98]
    // 0xc15160: b               #0xc14e14
    // 0xc15164: ldur            x3, [fp, #-0xa0]
    // 0xc15168: ldur            x2, [fp, #-0xb0]
    // 0xc1516c: ldur            x0, [fp, #-0x90]
    // 0xc15170: StoreField: r2->field_27 = r0
    //     0xc15170: stur            w0, [x2, #0x27]
    //     0xc15174: tbz             w0, #0, #0xc15190
    //     0xc15178: ldurb           w16, [x2, #-1]
    //     0xc1517c: ldurb           w17, [x0, #-1]
    //     0xc15180: and             x16, x17, x16, lsr #2
    //     0xc15184: tst             x16, HEAP, lsr #32
    //     0xc15188: b.eq            #0xc15190
    //     0xc1518c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc15190: LoadField: r0 = r3->field_b
    //     0xc15190: ldur            w0, [x3, #0xb]
    // 0xc15194: LoadField: r1 = r3->field_f
    //     0xc15194: ldur            w1, [x3, #0xf]
    // 0xc15198: DecompressPointer r1
    //     0xc15198: add             x1, x1, HEAP, lsl #32
    // 0xc1519c: LoadField: r4 = r1->field_b
    //     0xc1519c: ldur            w4, [x1, #0xb]
    // 0xc151a0: r5 = LoadInt32Instr(r0)
    //     0xc151a0: sbfx            x5, x0, #1, #0x1f
    // 0xc151a4: stur            x5, [fp, #-0x68]
    // 0xc151a8: r0 = LoadInt32Instr(r4)
    //     0xc151a8: sbfx            x0, x4, #1, #0x1f
    // 0xc151ac: cmp             x5, x0
    // 0xc151b0: b.ne            #0xc151bc
    // 0xc151b4: mov             x1, x3
    // 0xc151b8: r0 = _growToNextCapacity()
    //     0xc151b8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc151bc: ldur            x2, [fp, #-0xa0]
    // 0xc151c0: ldur            x3, [fp, #-0x68]
    // 0xc151c4: add             x0, x3, #1
    // 0xc151c8: lsl             x1, x0, #1
    // 0xc151cc: StoreField: r2->field_b = r1
    //     0xc151cc: stur            w1, [x2, #0xb]
    // 0xc151d0: LoadField: r1 = r2->field_f
    //     0xc151d0: ldur            w1, [x2, #0xf]
    // 0xc151d4: DecompressPointer r1
    //     0xc151d4: add             x1, x1, HEAP, lsl #32
    // 0xc151d8: ldur            x0, [fp, #-0xb0]
    // 0xc151dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc151dc: add             x25, x1, x3, lsl #2
    //     0xc151e0: add             x25, x25, #0xf
    //     0xc151e4: str             w0, [x25]
    //     0xc151e8: tbz             w0, #0, #0xc15204
    //     0xc151ec: ldurb           w16, [x1, #-1]
    //     0xc151f0: ldurb           w17, [x0, #-1]
    //     0xc151f4: and             x16, x17, x16, lsr #2
    //     0xc151f8: tst             x16, HEAP, lsr #32
    //     0xc151fc: b.eq            #0xc15204
    //     0xc15200: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc15204: ldur            x0, [fp, #-0x50]
    // 0xc15208: add             x7, x0, #1
    // 0xc1520c: ldur            d2, [fp, #-0x100]
    // 0xc15210: ldur            d4, [fp, #-0xf8]
    // 0xc15214: ldur            d5, [fp, #-0xf0]
    // 0xc15218: ldur            d6, [fp, #-0xe8]
    // 0xc1521c: ldur            d7, [fp, #-0xe0]
    // 0xc15220: ldur            d0, [fp, #-0xd0]
    // 0xc15224: d3 = 0.000000
    //     0xc15224: eor             v3.16b, v3.16b, v3.16b
    // 0xc15228: d1 = 0.000000
    //     0xc15228: ldr             d1, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xc1522c: b               #0xc1498c
    // 0xc15230: ldur            x1, [fp, #-0x30]
    // 0xc15234: mov             v1.16b, v5.16b
    // 0xc15238: mov             v2.16b, v6.16b
    // 0xc1523c: r0 = SemanticsConfiguration()
    //     0xc1523c: bl              #0x839284  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0xc8)
    // 0xc15240: mov             x1, x0
    // 0xc15244: stur            x0, [fp, #-0x90]
    // 0xc15248: r0 = SemanticsConfiguration()
    //     0xc15248: bl              #0x837c94  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0xc1524c: ldur            x1, [fp, #-0x90]
    // 0xc15250: ldur            x2, [fp, #-0x38]
    // 0xc15254: r0 = indexInParent=()
    //     0xc15254: bl              #0xc1544c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::indexInParent=
    // 0xc15258: ldur            x2, [fp, #-0x90]
    // 0xc1525c: r0 = Instance_SemanticsRole
    //     0xc1525c: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa12d8] Obj!SemanticsRole@12c7861
    //     0xc15260: ldr             x0, [x0, #0x2d8]
    // 0xc15264: StoreField: r2->field_63 = r0
    //     0xc15264: stur            w0, [x2, #0x63]
    // 0xc15268: r3 = true
    //     0xc15268: add             x3, NULL, #0x20  ; true
    // 0xc1526c: StoreField: r2->field_1f = r3
    //     0xc1526c: stur            w3, [x2, #0x1f]
    // 0xc15270: ldur            x16, [fp, #-0xa0]
    // 0xc15274: str             x16, [SP]
    // 0xc15278: ldur            x1, [fp, #-0x88]
    // 0xc1527c: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xc1527c: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xc15280: r0 = updateWith()
    //     0xc15280: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc15284: ldur            d0, [fp, #-0xe8]
    // 0xc15288: ldur            d1, [fp, #-0xd8]
    // 0xc1528c: r1 = Null
    //     0xc1528c: mov             x1, NULL
    // 0xc15290: r0 = Matrix4.translationValues()
    //     0xc15290: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xc15294: ldur            x1, [fp, #-0x88]
    // 0xc15298: mov             x2, x0
    // 0xc1529c: r0 = transform=()
    //     0xc1529c: bl              #0x8928fc  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::transform=
    // 0xc152a0: ldur            d0, [fp, #-0xf0]
    // 0xc152a4: ldur            d1, [fp, #-0xe8]
    // 0xc152a8: fsub            d2, d0, d1
    // 0xc152ac: d0 = 0.000000
    //     0xc152ac: eor             v0.16b, v0.16b, v0.16b
    // 0xc152b0: fadd            d1, d2, d0
    // 0xc152b4: ldur            d2, [fp, #-0xd0]
    // 0xc152b8: stur            d1, [fp, #-0xe0]
    // 0xc152bc: fadd            d3, d2, d0
    // 0xc152c0: stur            d3, [fp, #-0xd8]
    // 0xc152c4: r0 = Rect()
    //     0xc152c4: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc152c8: StoreField: r0->field_7 = rZR
    //     0xc152c8: stur            xzr, [x0, #7]
    // 0xc152cc: StoreField: r0->field_f = rZR
    //     0xc152cc: stur            xzr, [x0, #0xf]
    // 0xc152d0: ldur            d0, [fp, #-0xe0]
    // 0xc152d4: ArrayStore: r0[0] = d0  ; List_8
    //     0xc152d4: stur            d0, [x0, #0x17]
    // 0xc152d8: ldur            d0, [fp, #-0xd8]
    // 0xc152dc: StoreField: r0->field_1f = d0
    //     0xc152dc: stur            d0, [x0, #0x1f]
    // 0xc152e0: ldur            x1, [fp, #-0x88]
    // 0xc152e4: mov             x2, x0
    // 0xc152e8: r0 = rect=()
    //     0xc152e8: bl              #0x892bd8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0xc152ec: ldur            x0, [fp, #-0x30]
    // 0xc152f0: LoadField: r1 = r0->field_b
    //     0xc152f0: ldur            w1, [x0, #0xb]
    // 0xc152f4: LoadField: r2 = r0->field_f
    //     0xc152f4: ldur            w2, [x0, #0xf]
    // 0xc152f8: DecompressPointer r2
    //     0xc152f8: add             x2, x2, HEAP, lsl #32
    // 0xc152fc: LoadField: r3 = r2->field_b
    //     0xc152fc: ldur            w3, [x2, #0xb]
    // 0xc15300: r2 = LoadInt32Instr(r1)
    //     0xc15300: sbfx            x2, x1, #1, #0x1f
    // 0xc15304: stur            x2, [fp, #-0x50]
    // 0xc15308: r1 = LoadInt32Instr(r3)
    //     0xc15308: sbfx            x1, x3, #1, #0x1f
    // 0xc1530c: cmp             x2, x1
    // 0xc15310: b.ne            #0xc1531c
    // 0xc15314: mov             x1, x0
    // 0xc15318: r0 = _growToNextCapacity()
    //     0xc15318: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc1531c: ldur            x2, [fp, #-0x30]
    // 0xc15320: ldur            x3, [fp, #-0x50]
    // 0xc15324: add             x0, x3, #1
    // 0xc15328: lsl             x1, x0, #1
    // 0xc1532c: StoreField: r2->field_b = r1
    //     0xc1532c: stur            w1, [x2, #0xb]
    // 0xc15330: LoadField: r1 = r2->field_f
    //     0xc15330: ldur            w1, [x2, #0xf]
    // 0xc15334: DecompressPointer r1
    //     0xc15334: add             x1, x1, HEAP, lsl #32
    // 0xc15338: ldur            x0, [fp, #-0x88]
    // 0xc1533c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc1533c: add             x25, x1, x3, lsl #2
    //     0xc15340: add             x25, x25, #0xf
    //     0xc15344: str             w0, [x25]
    //     0xc15348: tbz             w0, #0, #0xc15364
    //     0xc1534c: ldurb           w16, [x1, #-1]
    //     0xc15350: ldurb           w17, [x0, #-1]
    //     0xc15354: and             x16, x17, x16, lsr #2
    //     0xc15358: tst             x16, HEAP, lsr #32
    //     0xc1535c: b.eq            #0xc15364
    //     0xc15360: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc15364: ldur            x0, [fp, #-0x38]
    // 0xc15368: add             x7, x0, #1
    // 0xc1536c: ldur            x1, [fp, #-8]
    // 0xc15370: mov             x6, x2
    // 0xc15374: ldur            x0, [fp, #-0x80]
    // 0xc15378: ldur            x2, [fp, #-0x78]
    // 0xc1537c: ldur            x3, [fp, #-0x58]
    // 0xc15380: b               #0xc14808
    // 0xc15384: mov             x2, x6
    // 0xc15388: str             x2, [SP]
    // 0xc1538c: ldur            x1, [fp, #-0x10]
    // 0xc15390: ldur            x2, [fp, #-0x18]
    // 0xc15394: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xc15394: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xc15398: r0 = updateWith()
    //     0xc15398: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc1539c: r0 = Null
    //     0xc1539c: mov             x0, NULL
    // 0xc153a0: LeaveFrame
    //     0xc153a0: mov             SP, fp
    //     0xc153a4: ldp             fp, lr, [SP], #0x10
    // 0xc153a8: ret
    //     0xc153a8: ret             
    // 0xc153ac: mov             x0, x4
    // 0xc153b0: r0 = ConcurrentModificationError()
    //     0xc153b0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc153b4: mov             x1, x0
    // 0xc153b8: ldur            x0, [fp, #-0x20]
    // 0xc153bc: StoreField: r1->field_b = r0
    //     0xc153bc: stur            w0, [x1, #0xb]
    // 0xc153c0: mov             x0, x1
    // 0xc153c4: r0 = Throw()
    //     0xc153c4: bl              #0x13ddb2c  ; ThrowStub
    // 0xc153c8: brk             #0
    // 0xc153cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc153cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc153d0: b               #0xc14290
    // 0xc153d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc153d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc153d8: b               #0xc14300
    // 0xc153dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc153dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc153e0: b               #0xc14338
    // 0xc153e4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc153e4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc153e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc153e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc153ec: b               #0xc1443c
    // 0xc153f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc153f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc153f4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc153f4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc153f8: r0 = StackOverflowSharedWithFPURegs()
    //     0xc153f8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc153fc: b               #0xc1460c
    // 0xc15400: r0 = StackOverflowSharedWithFPURegs()
    //     0xc15400: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc15404: b               #0xc146ac
    // 0xc15408: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15408: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc1540c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc1540c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc15410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc15410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc15414: b               #0xc14820
    // 0xc15418: r0 = StackOverflowSharedWithFPURegs()
    //     0xc15418: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc1541c: b               #0xc149ac
    // 0xc15420: r0 = RangeErrorSharedWithFPURegs()
    //     0xc15420: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc15424: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15424: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc15428: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15428: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc1542c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1542c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc15430: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15430: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc15434: r0 = StackOverflowSharedWithFPURegs()
    //     0xc15434: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc15438: b               #0xc14e40
    // 0xc1543c: r0 = RangeErrorSharedWithFPURegs()
    //     0xc1543c: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc15440: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15440: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc15444: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15444: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc15448: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc15448: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getRowBox(/* No info */) {
    // ** addr: 0xc154d8, size: 0xec
    // 0xc154d8: EnterFrame
    //     0xc154d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc154dc: mov             fp, SP
    // 0xc154e0: AllocStack(0x20)
    //     0xc154e0: sub             SP, SP, #0x20
    // 0xc154e4: SetupParameters(RenderTable this /* r1 => r3 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xc154e4: mov             x3, x1
    //     0xc154e8: stur            x2, [fp, #-0x18]
    // 0xc154ec: CheckStackOverflow
    //     0xc154ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc154f0: cmp             SP, x16
    //     0xc154f4: b.ls            #0xc155b4
    // 0xc154f8: LoadField: r4 = r3->field_97
    //     0xc154f8: ldur            w4, [x3, #0x97]
    // 0xc154fc: DecompressPointer r4
    //     0xc154fc: add             x4, x4, HEAP, lsl #32
    // 0xc15500: stur            x4, [fp, #-0x10]
    // 0xc15504: LoadField: r0 = r4->field_b
    //     0xc15504: ldur            w0, [x4, #0xb]
    // 0xc15508: r1 = LoadInt32Instr(r0)
    //     0xc15508: sbfx            x1, x0, #1, #0x1f
    // 0xc1550c: mov             x0, x1
    // 0xc15510: mov             x1, x2
    // 0xc15514: cmp             x1, x0
    // 0xc15518: b.hs            #0xc155bc
    // 0xc1551c: LoadField: r0 = r4->field_f
    //     0xc1551c: ldur            w0, [x4, #0xf]
    // 0xc15520: DecompressPointer r0
    //     0xc15520: add             x0, x0, HEAP, lsl #32
    // 0xc15524: ArrayLoad: r5 = r0[r2]  ; Unknown_4
    //     0xc15524: add             x16, x0, x2, lsl #2
    //     0xc15528: ldur            w5, [x16, #0xf]
    // 0xc1552c: DecompressPointer r5
    //     0xc1552c: add             x5, x5, HEAP, lsl #32
    // 0xc15530: mov             x1, x3
    // 0xc15534: stur            x5, [fp, #-8]
    // 0xc15538: r0 = size()
    //     0xc15538: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1553c: LoadField: d0 = r0->field_7
    //     0xc1553c: ldur            d0, [x0, #7]
    // 0xc15540: ldur            x0, [fp, #-0x18]
    // 0xc15544: stur            d0, [fp, #-0x20]
    // 0xc15548: add             x2, x0, #1
    // 0xc1554c: ldur            x3, [fp, #-0x10]
    // 0xc15550: LoadField: r0 = r3->field_b
    //     0xc15550: ldur            w0, [x3, #0xb]
    // 0xc15554: r1 = LoadInt32Instr(r0)
    //     0xc15554: sbfx            x1, x0, #1, #0x1f
    // 0xc15558: mov             x0, x1
    // 0xc1555c: mov             x1, x2
    // 0xc15560: cmp             x1, x0
    // 0xc15564: b.hs            #0xc155c0
    // 0xc15568: LoadField: r0 = r3->field_f
    //     0xc15568: ldur            w0, [x3, #0xf]
    // 0xc1556c: DecompressPointer r0
    //     0xc1556c: add             x0, x0, HEAP, lsl #32
    // 0xc15570: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0xc15570: add             x16, x0, x2, lsl #2
    //     0xc15574: ldur            w1, [x16, #0xf]
    // 0xc15578: DecompressPointer r1
    //     0xc15578: add             x1, x1, HEAP, lsl #32
    // 0xc1557c: stur            x1, [fp, #-0x10]
    // 0xc15580: r0 = Rect()
    //     0xc15580: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc15584: StoreField: r0->field_7 = rZR
    //     0xc15584: stur            xzr, [x0, #7]
    // 0xc15588: ldur            x1, [fp, #-8]
    // 0xc1558c: LoadField: d0 = r1->field_7
    //     0xc1558c: ldur            d0, [x1, #7]
    // 0xc15590: StoreField: r0->field_f = d0
    //     0xc15590: stur            d0, [x0, #0xf]
    // 0xc15594: ldur            d0, [fp, #-0x20]
    // 0xc15598: ArrayStore: r0[0] = d0  ; List_8
    //     0xc15598: stur            d0, [x0, #0x17]
    // 0xc1559c: ldur            x1, [fp, #-0x10]
    // 0xc155a0: LoadField: d0 = r1->field_7
    //     0xc155a0: ldur            d0, [x1, #7]
    // 0xc155a4: StoreField: r0->field_1f = d0
    //     0xc155a4: stur            d0, [x0, #0x1f]
    // 0xc155a8: LeaveFrame
    //     0xc155a8: mov             SP, fp
    //     0xc155ac: ldp             fp, lr, [SP], #0x10
    // 0xc155b0: ret
    //     0xc155b0: ret             
    // 0xc155b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc155b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc155b8: b               #0xc154f8
    // 0xc155bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc155bc: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc155c0: r0 = RangeErrorSharedWithFPURegs()
    //     0xc155c0: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  [closure] SemanticsNode <anonymous closure>(dynamic) {
    // ** addr: 0xc15818, size: 0x44
    // 0xc15818: EnterFrame
    //     0xc15818: stp             fp, lr, [SP, #-0x10]!
    //     0xc1581c: mov             fp, SP
    // 0xc15820: AllocStack(0x8)
    //     0xc15820: sub             SP, SP, #8
    // 0xc15824: CheckStackOverflow
    //     0xc15824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc15828: cmp             SP, x16
    //     0xc1582c: b.ls            #0xc15854
    // 0xc15830: r0 = SemanticsNode()
    //     0xc15830: bl              #0x894094  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xf0)
    // 0xc15834: mov             x1, x0
    // 0xc15838: stur            x0, [fp, #-8]
    // 0xc1583c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc1583c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc15840: r0 = SemanticsNode()
    //     0xc15840: bl              #0x893ce8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0xc15844: ldur            x0, [fp, #-8]
    // 0xc15848: LeaveFrame
    //     0xc15848: mov             SP, fp
    //     0xc1584c: ldp             fp, lr, [SP], #0x10
    // 0xc15850: ret
    //     0xc15850: ret             
    // 0xc15854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc15854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc15858: b               #0xc15830
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc1585c, size: 0x68
    // 0xc1585c: EnterFrame
    //     0xc1585c: stp             fp, lr, [SP, #-0x10]!
    //     0xc15860: mov             fp, SP
    // 0xc15864: AllocStack(0x10)
    //     0xc15864: sub             SP, SP, #0x10
    // 0xc15868: SetupParameters([dynamic _ /* r0 */])
    //     0xc15868: ldr             x0, [fp, #0x10]
    //     0xc1586c: ldur            w1, [x0, #0x17]
    //     0xc15870: add             x1, x1, HEAP, lsl #32
    // 0xc15874: CheckStackOverflow
    //     0xc15874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc15878: cmp             SP, x16
    //     0xc1587c: b.ls            #0xc158bc
    // 0xc15880: LoadField: r0 = r1->field_b
    //     0xc15880: ldur            w0, [x1, #0xb]
    // 0xc15884: DecompressPointer r0
    //     0xc15884: add             x0, x0, HEAP, lsl #32
    // 0xc15888: LoadField: r2 = r0->field_f
    //     0xc15888: ldur            w2, [x0, #0xf]
    // 0xc1588c: DecompressPointer r2
    //     0xc1588c: add             x2, x2, HEAP, lsl #32
    // 0xc15890: LoadField: r0 = r1->field_f
    //     0xc15890: ldur            w0, [x1, #0xf]
    // 0xc15894: DecompressPointer r0
    //     0xc15894: add             x0, x0, HEAP, lsl #32
    // 0xc15898: stp             x0, x2, [SP]
    // 0xc1589c: mov             x1, x2
    // 0xc158a0: r4 = const [0, 0x3, 0x2, 0x1, descendant, 0x1, rect, 0x2, null]
    //     0xc158a0: add             x4, PP, #0x98, lsl #12  ; [pp+0x988c0] List(9) [0, 0x3, 0x2, 0x1, "descendant", 0x1, "rect", 0x2, Null]
    //     0xc158a4: ldr             x4, [x4, #0x8c0]
    // 0xc158a8: r0 = showOnScreen()
    //     0xc158a8: bl              #0xbee008  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0xc158ac: r0 = Null
    //     0xc158ac: mov             x0, NULL
    // 0xc158b0: LeaveFrame
    //     0xc158b0: mov             SP, fp
    //     0xc158b4: ldp             fp, lr, [SP], #0x10
    // 0xc158b8: ret
    //     0xc158b8: ret             
    // 0xc158bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc158bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc158c0: b               #0xc15880
  }
  _ paint(/* No info */) {
    // ** addr: 0xc2ecc8, size: 0x650
    // 0xc2ecc8: EnterFrame
    //     0xc2ecc8: stp             fp, lr, [SP, #-0x10]!
    //     0xc2eccc: mov             fp, SP
    // 0xc2ecd0: AllocStack(0xb8)
    //     0xc2ecd0: sub             SP, SP, #0xb8
    // 0xc2ecd4: SetupParameters(RenderTable this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc2ecd4: mov             x0, x2
    //     0xc2ecd8: stur            x2, [fp, #-0x10]
    //     0xc2ecdc: mov             x2, x1
    //     0xc2ece0: stur            x1, [fp, #-8]
    //     0xc2ece4: stur            x3, [fp, #-0x18]
    // 0xc2ece8: CheckStackOverflow
    //     0xc2ece8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2ecec: cmp             SP, x16
    //     0xc2ecf0: b.ls            #0xc2f2e8
    // 0xc2ecf4: LoadField: r1 = r2->field_5b
    //     0xc2ecf4: ldur            x1, [x2, #0x5b]
    // 0xc2ecf8: LoadField: r4 = r2->field_53
    //     0xc2ecf8: ldur            x4, [x2, #0x53]
    // 0xc2ecfc: mul             x5, x1, x4
    // 0xc2ed00: cbnz            x5, #0xc2ed14
    // 0xc2ed04: r0 = Null
    //     0xc2ed04: mov             x0, NULL
    // 0xc2ed08: LeaveFrame
    //     0xc2ed08: mov             SP, fp
    //     0xc2ed0c: ldp             fp, lr, [SP], #0x10
    // 0xc2ed10: ret
    //     0xc2ed10: ret             
    // 0xc2ed14: LoadField: r1 = r2->field_73
    //     0xc2ed14: ldur            w1, [x2, #0x73]
    // 0xc2ed18: DecompressPointer r1
    //     0xc2ed18: add             x1, x1, HEAP, lsl #32
    // 0xc2ed1c: cmp             w1, NULL
    // 0xc2ed20: b.eq            #0xc2f0e8
    // 0xc2ed24: mov             x1, x0
    // 0xc2ed28: r0 = canvas()
    //     0xc2ed28: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc2ed2c: mov             x3, x0
    // 0xc2ed30: ldur            x0, [fp, #-0x18]
    // 0xc2ed34: stur            x3, [fp, #-0x28]
    // 0xc2ed38: LoadField: d0 = r0->field_7
    //     0xc2ed38: ldur            d0, [x0, #7]
    // 0xc2ed3c: stur            d0, [fp, #-0x98]
    // 0xc2ed40: LoadField: d1 = r0->field_f
    //     0xc2ed40: ldur            d1, [x0, #0xf]
    // 0xc2ed44: ldur            x4, [fp, #-8]
    // 0xc2ed48: stur            d1, [fp, #-0x90]
    // 0xc2ed4c: LoadField: r5 = r4->field_97
    //     0xc2ed4c: ldur            w5, [x4, #0x97]
    // 0xc2ed50: DecompressPointer r5
    //     0xc2ed50: add             x5, x5, HEAP, lsl #32
    // 0xc2ed54: mov             x2, x4
    // 0xc2ed58: stur            x5, [fp, #-0x20]
    // 0xc2ed5c: r1 = Function 'markNeedsPaint':.
    //     0xc2ed5c: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc2ed60: ldr             x1, [x1, #0x1f0]
    // 0xc2ed64: r0 = AllocateClosure()
    //     0xc2ed64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc2ed68: mov             x2, x0
    // 0xc2ed6c: stur            x2, [fp, #-0x48]
    // 0xc2ed70: r5 = 0
    //     0xc2ed70: mov             x5, #0
    // 0xc2ed74: ldur            x3, [fp, #-8]
    // 0xc2ed78: ldur            x4, [fp, #-0x20]
    // 0xc2ed7c: ldur            d0, [fp, #-0x98]
    // 0xc2ed80: ldur            d1, [fp, #-0x90]
    // 0xc2ed84: stur            x5, [fp, #-0x40]
    // 0xc2ed88: CheckStackOverflow
    //     0xc2ed88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2ed8c: cmp             SP, x16
    //     0xc2ed90: b.ls            #0xc2f2f0
    // 0xc2ed94: LoadField: r0 = r3->field_5b
    //     0xc2ed94: ldur            x0, [x3, #0x5b]
    // 0xc2ed98: cmp             x5, x0
    // 0xc2ed9c: b.ge            #0xc2f0e8
    // 0xc2eda0: LoadField: r0 = r3->field_73
    //     0xc2eda0: ldur            w0, [x3, #0x73]
    // 0xc2eda4: DecompressPointer r0
    //     0xc2eda4: add             x0, x0, HEAP, lsl #32
    // 0xc2eda8: cmp             w0, NULL
    // 0xc2edac: b.eq            #0xc2f2f8
    // 0xc2edb0: LoadField: r1 = r0->field_b
    //     0xc2edb0: ldur            w1, [x0, #0xb]
    // 0xc2edb4: r6 = LoadInt32Instr(r1)
    //     0xc2edb4: sbfx            x6, x1, #1, #0x1f
    // 0xc2edb8: cmp             x6, x5
    // 0xc2edbc: b.le            #0xc2f0e8
    // 0xc2edc0: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0xc2edc0: add             x16, x0, x5, lsl #2
    //     0xc2edc4: ldur            w6, [x16, #0xf]
    // 0xc2edc8: DecompressPointer r6
    //     0xc2edc8: add             x6, x6, HEAP, lsl #32
    // 0xc2edcc: stur            x6, [fp, #-0x38]
    // 0xc2edd0: cmp             w6, NULL
    // 0xc2edd4: b.eq            #0xc2f0d8
    // 0xc2edd8: LoadField: r7 = r3->field_77
    //     0xc2edd8: ldur            w7, [x3, #0x77]
    // 0xc2eddc: DecompressPointer r7
    //     0xc2eddc: add             x7, x7, HEAP, lsl #32
    // 0xc2ede0: stur            x7, [fp, #-0x30]
    // 0xc2ede4: cmp             w7, NULL
    // 0xc2ede8: b.eq            #0xc2f2fc
    // 0xc2edec: LoadField: r0 = r7->field_b
    //     0xc2edec: ldur            w0, [x7, #0xb]
    // 0xc2edf0: r1 = LoadInt32Instr(r0)
    //     0xc2edf0: sbfx            x1, x0, #1, #0x1f
    // 0xc2edf4: mov             x0, x1
    // 0xc2edf8: mov             x1, x5
    // 0xc2edfc: cmp             x1, x0
    // 0xc2ee00: b.hs            #0xc2f300
    // 0xc2ee04: ArrayLoad: r0 = r7[r5]  ; Unknown_4
    //     0xc2ee04: add             x16, x7, x5, lsl #2
    //     0xc2ee08: ldur            w0, [x16, #0xf]
    // 0xc2ee0c: DecompressPointer r0
    //     0xc2ee0c: add             x0, x0, HEAP, lsl #32
    // 0xc2ee10: cmp             w0, NULL
    // 0xc2ee14: b.ne            #0xc2ef38
    // 0xc2ee18: r0 = LoadClassIdInstr(r6)
    //     0xc2ee18: ldur            x0, [x6, #-1]
    //     0xc2ee1c: ubfx            x0, x0, #0xc, #0x14
    // 0xc2ee20: r17 = 5237
    //     0xc2ee20: mov             x17, #0x1475
    // 0xc2ee24: cmp             x0, x17
    // 0xc2ee28: b.ne            #0xc2ee60
    // 0xc2ee2c: r0 = _ShapeDecorationPainter()
    //     0xc2ee2c: bl              #0xb7a684  ; Allocate_ShapeDecorationPainterStub -> _ShapeDecorationPainter (size=0x38)
    // 0xc2ee30: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xc2ee34: ArrayStore: r0[0] = r1  ; List_4
    //     0xc2ee34: stur            w1, [x0, #0x17]
    // 0xc2ee38: StoreField: r0->field_27 = r1
    //     0xc2ee38: stur            w1, [x0, #0x27]
    // 0xc2ee3c: StoreField: r0->field_2b = r1
    //     0xc2ee3c: stur            w1, [x0, #0x2b]
    // 0xc2ee40: StoreField: r0->field_2f = r1
    //     0xc2ee40: stur            w1, [x0, #0x2f]
    // 0xc2ee44: ldur            x2, [fp, #-0x38]
    // 0xc2ee48: StoreField: r0->field_b = r2
    //     0xc2ee48: stur            w2, [x0, #0xb]
    // 0xc2ee4c: ldur            x3, [fp, #-0x48]
    // 0xc2ee50: StoreField: r0->field_7 = r3
    //     0xc2ee50: stur            w3, [x0, #7]
    // 0xc2ee54: mov             x4, x0
    // 0xc2ee58: mov             x2, x3
    // 0xc2ee5c: b               #0xc2eefc
    // 0xc2ee60: mov             x3, x2
    // 0xc2ee64: mov             x2, x6
    // 0xc2ee68: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0xc2ee6c: r17 = 5238
    //     0xc2ee6c: mov             x17, #0x1476
    // 0xc2ee70: cmp             x0, x17
    // 0xc2ee74: b.ne            #0xc2ee94
    // 0xc2ee78: r0 = _BoxDecorationPainter()
    //     0xc2ee78: bl              #0xb7a678  ; Allocate_BoxDecorationPainterStub -> _BoxDecorationPainter (size=0x1c)
    // 0xc2ee7c: ldur            x1, [fp, #-0x38]
    // 0xc2ee80: StoreField: r0->field_b = r1
    //     0xc2ee80: stur            w1, [x0, #0xb]
    // 0xc2ee84: ldur            x2, [fp, #-0x48]
    // 0xc2ee88: StoreField: r0->field_7 = r2
    //     0xc2ee88: stur            w2, [x0, #7]
    // 0xc2ee8c: mov             x4, x0
    // 0xc2ee90: b               #0xc2eefc
    // 0xc2ee94: mov             x1, x2
    // 0xc2ee98: mov             x2, x3
    // 0xc2ee9c: r17 = 5239
    //     0xc2ee9c: mov             x17, #0x1477
    // 0xc2eea0: cmp             x0, x17
    // 0xc2eea4: b.ne            #0xc2eedc
    // 0xc2eea8: LoadField: r0 = r1->field_7
    //     0xc2eea8: ldur            w0, [x1, #7]
    // 0xc2eeac: DecompressPointer r0
    //     0xc2eeac: add             x0, x0, HEAP, lsl #32
    // 0xc2eeb0: stur            x0, [fp, #-0x50]
    // 0xc2eeb4: r0 = _UnderlinePainter()
    //     0xc2eeb4: bl              #0xb7a66c  ; Allocate_UnderlinePainterStub -> _UnderlinePainter (size=0x14)
    // 0xc2eeb8: mov             x1, x0
    // 0xc2eebc: ldur            x0, [fp, #-0x38]
    // 0xc2eec0: StoreField: r1->field_b = r0
    //     0xc2eec0: stur            w0, [x1, #0xb]
    // 0xc2eec4: ldur            x0, [fp, #-0x50]
    // 0xc2eec8: StoreField: r1->field_f = r0
    //     0xc2eec8: stur            w0, [x1, #0xf]
    // 0xc2eecc: ldur            x2, [fp, #-0x48]
    // 0xc2eed0: StoreField: r1->field_7 = r2
    //     0xc2eed0: stur            w2, [x1, #7]
    // 0xc2eed4: mov             x4, x1
    // 0xc2eed8: b               #0xc2eefc
    // 0xc2eedc: mov             x0, x1
    // 0xc2eee0: r0 = _CupertinoEdgeShadowPainter()
    //     0xc2eee0: bl              #0xb7a660  ; Allocate_CupertinoEdgeShadowPainterStub -> _CupertinoEdgeShadowPainter (size=0x10)
    // 0xc2eee4: mov             x1, x0
    // 0xc2eee8: ldur            x0, [fp, #-0x38]
    // 0xc2eeec: StoreField: r1->field_b = r0
    //     0xc2eeec: stur            w0, [x1, #0xb]
    // 0xc2eef0: ldur            x2, [fp, #-0x48]
    // 0xc2eef4: StoreField: r1->field_7 = r2
    //     0xc2eef4: stur            w2, [x1, #7]
    // 0xc2eef8: mov             x4, x1
    // 0xc2eefc: ldur            x3, [fp, #-0x40]
    // 0xc2ef00: ldur            x1, [fp, #-0x30]
    // 0xc2ef04: mov             x0, x4
    // 0xc2ef08: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc2ef08: add             x25, x1, x3, lsl #2
    //     0xc2ef0c: add             x25, x25, #0xf
    //     0xc2ef10: str             w0, [x25]
    //     0xc2ef14: tbz             w0, #0, #0xc2ef30
    //     0xc2ef18: ldurb           w16, [x1, #-1]
    //     0xc2ef1c: ldurb           w17, [x0, #-1]
    //     0xc2ef20: and             x16, x17, x16, lsr #2
    //     0xc2ef24: tst             x16, HEAP, lsr #32
    //     0xc2ef28: b.eq            #0xc2ef30
    //     0xc2ef2c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc2ef30: mov             x6, x4
    // 0xc2ef34: b               #0xc2ef40
    // 0xc2ef38: mov             x3, x5
    // 0xc2ef3c: mov             x6, x0
    // 0xc2ef40: ldur            x4, [fp, #-8]
    // 0xc2ef44: ldur            x5, [fp, #-0x20]
    // 0xc2ef48: ldur            d0, [fp, #-0x98]
    // 0xc2ef4c: ldur            d1, [fp, #-0x90]
    // 0xc2ef50: stur            x6, [fp, #-0x50]
    // 0xc2ef54: LoadField: r0 = r5->field_b
    //     0xc2ef54: ldur            w0, [x5, #0xb]
    // 0xc2ef58: r7 = LoadInt32Instr(r0)
    //     0xc2ef58: sbfx            x7, x0, #1, #0x1f
    // 0xc2ef5c: mov             x0, x7
    // 0xc2ef60: mov             x1, x3
    // 0xc2ef64: stur            x7, [fp, #-0x58]
    // 0xc2ef68: cmp             x1, x0
    // 0xc2ef6c: b.hs            #0xc2f304
    // 0xc2ef70: LoadField: r0 = r5->field_f
    //     0xc2ef70: ldur            w0, [x5, #0xf]
    // 0xc2ef74: DecompressPointer r0
    //     0xc2ef74: add             x0, x0, HEAP, lsl #32
    // 0xc2ef78: stur            x0, [fp, #-0x38]
    // 0xc2ef7c: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xc2ef7c: add             x16, x0, x3, lsl #2
    //     0xc2ef80: ldur            w1, [x16, #0xf]
    // 0xc2ef84: DecompressPointer r1
    //     0xc2ef84: add             x1, x1, HEAP, lsl #32
    // 0xc2ef88: stur            x1, [fp, #-0x30]
    // 0xc2ef8c: LoadField: d2 = r1->field_7
    //     0xc2ef8c: ldur            d2, [x1, #7]
    // 0xc2ef90: fadd            d3, d1, d2
    // 0xc2ef94: stur            d3, [fp, #-0xa0]
    // 0xc2ef98: r0 = Offset()
    //     0xc2ef98: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc2ef9c: mov             x2, x0
    // 0xc2efa0: ldur            d0, [fp, #-0x98]
    // 0xc2efa4: stur            x2, [fp, #-0x68]
    // 0xc2efa8: StoreField: r2->field_7 = d0
    //     0xc2efa8: stur            d0, [x2, #7]
    // 0xc2efac: ldur            d1, [fp, #-0xa0]
    // 0xc2efb0: StoreField: r2->field_f = d1
    //     0xc2efb0: stur            d1, [x2, #0xf]
    // 0xc2efb4: ldur            x3, [fp, #-8]
    // 0xc2efb8: LoadField: r4 = r3->field_7b
    //     0xc2efb8: ldur            w4, [x3, #0x7b]
    // 0xc2efbc: DecompressPointer r4
    //     0xc2efbc: add             x4, x4, HEAP, lsl #32
    // 0xc2efc0: stur            x4, [fp, #-0x60]
    // 0xc2efc4: LoadField: r0 = r3->field_4b
    //     0xc2efc4: ldur            w0, [x3, #0x4b]
    // 0xc2efc8: DecompressPointer r0
    //     0xc2efc8: add             x0, x0, HEAP, lsl #32
    // 0xc2efcc: cmp             w0, NULL
    // 0xc2efd0: b.eq            #0xc2f260
    // 0xc2efd4: ldur            x5, [fp, #-0x40]
    // 0xc2efd8: ldur            x7, [fp, #-0x38]
    // 0xc2efdc: ldur            x8, [fp, #-0x30]
    // 0xc2efe0: ldur            x6, [fp, #-0x50]
    // 0xc2efe4: LoadField: d1 = r0->field_7
    //     0xc2efe4: ldur            d1, [x0, #7]
    // 0xc2efe8: stur            d1, [fp, #-0xa8]
    // 0xc2efec: add             x9, x5, #1
    // 0xc2eff0: ldur            x0, [fp, #-0x58]
    // 0xc2eff4: mov             x1, x9
    // 0xc2eff8: cmp             x1, x0
    // 0xc2effc: b.hs            #0xc2f308
    // 0xc2f000: ArrayLoad: r0 = r7[r9]  ; Unknown_4
    //     0xc2f000: add             x16, x7, x9, lsl #2
    //     0xc2f004: ldur            w0, [x16, #0xf]
    // 0xc2f008: DecompressPointer r0
    //     0xc2f008: add             x0, x0, HEAP, lsl #32
    // 0xc2f00c: LoadField: d2 = r0->field_7
    //     0xc2f00c: ldur            d2, [x0, #7]
    // 0xc2f010: LoadField: d3 = r8->field_7
    //     0xc2f010: ldur            d3, [x8, #7]
    // 0xc2f014: fsub            d4, d2, d3
    // 0xc2f018: stur            d4, [fp, #-0xa0]
    // 0xc2f01c: r0 = Size()
    //     0xc2f01c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xc2f020: ldur            d0, [fp, #-0xa8]
    // 0xc2f024: stur            x0, [fp, #-0x88]
    // 0xc2f028: StoreField: r0->field_7 = d0
    //     0xc2f028: stur            d0, [x0, #7]
    // 0xc2f02c: ldur            d0, [fp, #-0xa0]
    // 0xc2f030: StoreField: r0->field_f = d0
    //     0xc2f030: stur            d0, [x0, #0xf]
    // 0xc2f034: ldur            x1, [fp, #-0x60]
    // 0xc2f038: LoadField: r2 = r1->field_7
    //     0xc2f038: ldur            w2, [x1, #7]
    // 0xc2f03c: DecompressPointer r2
    //     0xc2f03c: add             x2, x2, HEAP, lsl #32
    // 0xc2f040: stur            x2, [fp, #-0x80]
    // 0xc2f044: LoadField: r3 = r1->field_b
    //     0xc2f044: ldur            w3, [x1, #0xb]
    // 0xc2f048: DecompressPointer r3
    //     0xc2f048: add             x3, x3, HEAP, lsl #32
    // 0xc2f04c: stur            x3, [fp, #-0x78]
    // 0xc2f050: LoadField: r4 = r1->field_f
    //     0xc2f050: ldur            w4, [x1, #0xf]
    // 0xc2f054: DecompressPointer r4
    //     0xc2f054: add             x4, x4, HEAP, lsl #32
    // 0xc2f058: stur            x4, [fp, #-0x70]
    // 0xc2f05c: LoadField: r5 = r1->field_13
    //     0xc2f05c: ldur            w5, [x1, #0x13]
    // 0xc2f060: DecompressPointer r5
    //     0xc2f060: add             x5, x5, HEAP, lsl #32
    // 0xc2f064: stur            x5, [fp, #-0x38]
    // 0xc2f068: LoadField: r6 = r1->field_1b
    //     0xc2f068: ldur            w6, [x1, #0x1b]
    // 0xc2f06c: DecompressPointer r6
    //     0xc2f06c: add             x6, x6, HEAP, lsl #32
    // 0xc2f070: stur            x6, [fp, #-0x30]
    // 0xc2f074: r0 = ImageConfiguration()
    //     0xc2f074: bl              #0xb6d7b4  ; AllocateImageConfigurationStub -> ImageConfiguration (size=0x20)
    // 0xc2f078: mov             x1, x0
    // 0xc2f07c: ldur            x0, [fp, #-0x80]
    // 0xc2f080: StoreField: r1->field_7 = r0
    //     0xc2f080: stur            w0, [x1, #7]
    // 0xc2f084: ldur            x0, [fp, #-0x78]
    // 0xc2f088: StoreField: r1->field_b = r0
    //     0xc2f088: stur            w0, [x1, #0xb]
    // 0xc2f08c: ldur            x0, [fp, #-0x70]
    // 0xc2f090: StoreField: r1->field_f = r0
    //     0xc2f090: stur            w0, [x1, #0xf]
    // 0xc2f094: ldur            x0, [fp, #-0x38]
    // 0xc2f098: StoreField: r1->field_13 = r0
    //     0xc2f098: stur            w0, [x1, #0x13]
    // 0xc2f09c: ldur            x0, [fp, #-0x88]
    // 0xc2f0a0: ArrayStore: r1[0] = r0  ; List_4
    //     0xc2f0a0: stur            w0, [x1, #0x17]
    // 0xc2f0a4: ldur            x0, [fp, #-0x30]
    // 0xc2f0a8: StoreField: r1->field_1b = r0
    //     0xc2f0a8: stur            w0, [x1, #0x1b]
    // 0xc2f0ac: ldur            x0, [fp, #-0x50]
    // 0xc2f0b0: r2 = LoadClassIdInstr(r0)
    //     0xc2f0b0: ldur            x2, [x0, #-1]
    //     0xc2f0b4: ubfx            x2, x2, #0xc, #0x14
    // 0xc2f0b8: mov             x5, x1
    // 0xc2f0bc: mov             x1, x0
    // 0xc2f0c0: mov             x0, x2
    // 0xc2f0c4: ldur            x2, [fp, #-0x28]
    // 0xc2f0c8: ldur            x3, [fp, #-0x68]
    // 0xc2f0cc: r0 = GDT[cid_x0 + -0xffc]()
    //     0xc2f0cc: sub             lr, x0, #0xffc
    //     0xc2f0d0: ldr             lr, [x21, lr, lsl #3]
    //     0xc2f0d4: blr             lr
    // 0xc2f0d8: ldur            x0, [fp, #-0x40]
    // 0xc2f0dc: add             x5, x0, #1
    // 0xc2f0e0: ldur            x2, [fp, #-0x48]
    // 0xc2f0e4: b               #0xc2ed74
    // 0xc2f0e8: ldur            x0, [fp, #-0x18]
    // 0xc2f0ec: LoadField: d0 = r0->field_7
    //     0xc2f0ec: ldur            d0, [x0, #7]
    // 0xc2f0f0: stur            d0, [fp, #-0x98]
    // 0xc2f0f4: LoadField: d1 = r0->field_f
    //     0xc2f0f4: ldur            d1, [x0, #0xf]
    // 0xc2f0f8: stur            d1, [fp, #-0x90]
    // 0xc2f0fc: r2 = 0
    //     0xc2f0fc: mov             x2, #0
    // 0xc2f100: ldur            x1, [fp, #-8]
    // 0xc2f104: stur            x2, [fp, #-0x40]
    // 0xc2f108: CheckStackOverflow
    //     0xc2f108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2f10c: cmp             SP, x16
    //     0xc2f110: b.ls            #0xc2f30c
    // 0xc2f114: LoadField: r0 = r1->field_4f
    //     0xc2f114: ldur            w0, [x1, #0x4f]
    // 0xc2f118: DecompressPointer r0
    //     0xc2f118: add             x0, x0, HEAP, lsl #32
    // 0xc2f11c: r3 = LoadClassIdInstr(r0)
    //     0xc2f11c: ldur            x3, [x0, #-1]
    //     0xc2f120: ubfx            x3, x3, #0xc, #0x14
    // 0xc2f124: str             x0, [SP]
    // 0xc2f128: mov             x0, x3
    // 0xc2f12c: r0 = GDT[cid_x0 + 0xf078]()
    //     0xc2f12c: mov             x17, #0xf078
    //     0xc2f130: add             lr, x0, x17
    //     0xc2f134: ldr             lr, [x21, lr, lsl #3]
    //     0xc2f138: blr             lr
    // 0xc2f13c: r1 = LoadInt32Instr(r0)
    //     0xc2f13c: sbfx            x1, x0, #1, #0x1f
    // 0xc2f140: ldur            x2, [fp, #-0x40]
    // 0xc2f144: cmp             x2, x1
    // 0xc2f148: b.ge            #0xc2f250
    // 0xc2f14c: ldur            x3, [fp, #-8]
    // 0xc2f150: LoadField: r4 = r3->field_4f
    //     0xc2f150: ldur            w4, [x3, #0x4f]
    // 0xc2f154: DecompressPointer r4
    //     0xc2f154: add             x4, x4, HEAP, lsl #32
    // 0xc2f158: r0 = BoxInt64Instr(r2)
    //     0xc2f158: sbfiz           x0, x2, #1, #0x1f
    //     0xc2f15c: cmp             x2, x0, asr #1
    //     0xc2f160: b.eq            #0xc2f16c
    //     0xc2f164: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc2f168: stur            x2, [x0, #7]
    // 0xc2f16c: r1 = LoadClassIdInstr(r4)
    //     0xc2f16c: ldur            x1, [x4, #-1]
    //     0xc2f170: ubfx            x1, x1, #0xc, #0x14
    // 0xc2f174: stp             x0, x4, [SP]
    // 0xc2f178: mov             x0, x1
    // 0xc2f17c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xc2f17c: sub             lr, x0, #0xdfd
    //     0xc2f180: ldr             lr, [x21, lr, lsl #3]
    //     0xc2f184: blr             lr
    // 0xc2f188: mov             x3, x0
    // 0xc2f18c: stur            x3, [fp, #-0x20]
    // 0xc2f190: cmp             w3, NULL
    // 0xc2f194: b.eq            #0xc2f23c
    // 0xc2f198: ldur            d0, [fp, #-0x98]
    // 0xc2f19c: ldur            d1, [fp, #-0x90]
    // 0xc2f1a0: LoadField: r4 = r3->field_7
    //     0xc2f1a0: ldur            w4, [x3, #7]
    // 0xc2f1a4: DecompressPointer r4
    //     0xc2f1a4: add             x4, x4, HEAP, lsl #32
    // 0xc2f1a8: stur            x4, [fp, #-0x18]
    // 0xc2f1ac: cmp             w4, NULL
    // 0xc2f1b0: b.eq            #0xc2f314
    // 0xc2f1b4: mov             x0, x4
    // 0xc2f1b8: r2 = Null
    //     0xc2f1b8: mov             x2, NULL
    // 0xc2f1bc: r1 = Null
    //     0xc2f1bc: mov             x1, NULL
    // 0xc2f1c0: r4 = LoadClassIdInstr(r0)
    //     0xc2f1c0: ldur            x4, [x0, #-1]
    //     0xc2f1c4: ubfx            x4, x4, #0xc, #0x14
    // 0xc2f1c8: r17 = -4190
    //     0xc2f1c8: mov             x17, #-0x105e
    // 0xc2f1cc: add             x4, x4, x17
    // 0xc2f1d0: cmp             x4, #0x17
    // 0xc2f1d4: b.ls            #0xc2f1ec
    // 0xc2f1d8: r8 = BoxParentData
    //     0xc2f1d8: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xc2f1dc: ldr             x8, [x8, #0x5e8]
    // 0xc2f1e0: r3 = Null
    //     0xc2f1e0: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1200] Null
    //     0xc2f1e4: ldr             x3, [x3, #0x200]
    // 0xc2f1e8: r0 = DefaultTypeTest()
    //     0xc2f1e8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc2f1ec: ldur            x0, [fp, #-0x18]
    // 0xc2f1f0: LoadField: r1 = r0->field_7
    //     0xc2f1f0: ldur            w1, [x0, #7]
    // 0xc2f1f4: DecompressPointer r1
    //     0xc2f1f4: add             x1, x1, HEAP, lsl #32
    // 0xc2f1f8: LoadField: d0 = r1->field_7
    //     0xc2f1f8: ldur            d0, [x1, #7]
    // 0xc2f1fc: ldur            d1, [fp, #-0x98]
    // 0xc2f200: fadd            d2, d0, d1
    // 0xc2f204: stur            d2, [fp, #-0xa8]
    // 0xc2f208: LoadField: d0 = r1->field_f
    //     0xc2f208: ldur            d0, [x1, #0xf]
    // 0xc2f20c: ldur            d3, [fp, #-0x90]
    // 0xc2f210: fadd            d4, d0, d3
    // 0xc2f214: stur            d4, [fp, #-0xa0]
    // 0xc2f218: r0 = Offset()
    //     0xc2f218: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc2f21c: ldur            d0, [fp, #-0xa8]
    // 0xc2f220: StoreField: r0->field_7 = d0
    //     0xc2f220: stur            d0, [x0, #7]
    // 0xc2f224: ldur            d0, [fp, #-0xa0]
    // 0xc2f228: StoreField: r0->field_f = d0
    //     0xc2f228: stur            d0, [x0, #0xf]
    // 0xc2f22c: ldur            x1, [fp, #-0x10]
    // 0xc2f230: ldur            x2, [fp, #-0x20]
    // 0xc2f234: mov             x3, x0
    // 0xc2f238: r0 = paintChild()
    //     0xc2f238: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc2f23c: ldur            x0, [fp, #-0x40]
    // 0xc2f240: add             x2, x0, #1
    // 0xc2f244: ldur            d0, [fp, #-0x98]
    // 0xc2f248: ldur            d1, [fp, #-0x90]
    // 0xc2f24c: b               #0xc2f100
    // 0xc2f250: r0 = Null
    //     0xc2f250: mov             x0, NULL
    // 0xc2f254: LeaveFrame
    //     0xc2f254: mov             SP, fp
    //     0xc2f258: ldp             fp, lr, [SP], #0x10
    // 0xc2f25c: ret
    //     0xc2f25c: ret             
    // 0xc2f260: r1 = Null
    //     0xc2f260: mov             x1, NULL
    // 0xc2f264: r2 = 8
    //     0xc2f264: mov             x2, #8
    // 0xc2f268: r0 = AllocateArray()
    //     0xc2f268: bl              #0x13df928  ; AllocateArrayStub
    // 0xc2f26c: stur            x0, [fp, #-0x10]
    // 0xc2f270: r16 = "RenderBox was not laid out: "
    //     0xc2f270: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xc2f274: StoreField: r0->field_f = r16
    //     0xc2f274: stur            w16, [x0, #0xf]
    // 0xc2f278: r16 = RenderTable
    //     0xc2f278: add             x16, PP, #0x96, lsl #12  ; [pp+0x96d48] Type: RenderTable
    //     0xc2f27c: ldr             x16, [x16, #0xd48]
    // 0xc2f280: StoreField: r0->field_13 = r16
    //     0xc2f280: stur            w16, [x0, #0x13]
    // 0xc2f284: r16 = "#"
    //     0xc2f284: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xc2f288: ArrayStore: r0[0] = r16  ; List_4
    //     0xc2f288: stur            w16, [x0, #0x17]
    // 0xc2f28c: ldur            x1, [fp, #-8]
    // 0xc2f290: r0 = shortHash()
    //     0xc2f290: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xc2f294: ldur            x1, [fp, #-0x10]
    // 0xc2f298: ArrayStore: r1[3] = r0  ; List_4
    //     0xc2f298: add             x25, x1, #0x1b
    //     0xc2f29c: str             w0, [x25]
    //     0xc2f2a0: tbz             w0, #0, #0xc2f2bc
    //     0xc2f2a4: ldurb           w16, [x1, #-1]
    //     0xc2f2a8: ldurb           w17, [x0, #-1]
    //     0xc2f2ac: and             x16, x17, x16, lsr #2
    //     0xc2f2b0: tst             x16, HEAP, lsr #32
    //     0xc2f2b4: b.eq            #0xc2f2bc
    //     0xc2f2b8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc2f2bc: ldur            x16, [fp, #-0x10]
    // 0xc2f2c0: str             x16, [SP]
    // 0xc2f2c4: r0 = _interpolate()
    //     0xc2f2c4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xc2f2c8: stur            x0, [fp, #-8]
    // 0xc2f2cc: r0 = StateError()
    //     0xc2f2cc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc2f2d0: mov             x1, x0
    // 0xc2f2d4: ldur            x0, [fp, #-8]
    // 0xc2f2d8: StoreField: r1->field_b = r0
    //     0xc2f2d8: stur            w0, [x1, #0xb]
    // 0xc2f2dc: mov             x0, x1
    // 0xc2f2e0: r0 = Throw()
    //     0xc2f2e0: bl              #0x13ddb2c  ; ThrowStub
    // 0xc2f2e4: brk             #0
    // 0xc2f2e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2f2e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2f2ec: b               #0xc2ecf4
    // 0xc2f2f0: r0 = StackOverflowSharedWithFPURegs()
    //     0xc2f2f0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc2f2f4: b               #0xc2ed94
    // 0xc2f2f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc2f2f8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc2f2fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc2f2fc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc2f300: r0 = RangeErrorSharedWithFPURegs()
    //     0xc2f300: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc2f304: r0 = RangeErrorSharedWithFPURegs()
    //     0xc2f304: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc2f308: r0 = RangeErrorSharedWithFPURegs()
    //     0xc2f308: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
    // 0xc2f30c: r0 = StackOverflowSharedWithFPURegs()
    //     0xc2f30c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc2f310: b               #0xc2f114
    // 0xc2f314: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc2f314: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ clearSemantics(/* No info */) {
    // ** addr: 0xcd0588, size: 0x60
    // 0xcd0588: EnterFrame
    //     0xcd0588: stp             fp, lr, [SP, #-0x10]!
    //     0xcd058c: mov             fp, SP
    // 0xcd0590: AllocStack(0x8)
    //     0xcd0590: sub             SP, SP, #8
    // 0xcd0594: SetupParameters(RenderTable this /* r1 => r0, fp-0x8 */)
    //     0xcd0594: mov             x0, x1
    //     0xcd0598: stur            x1, [fp, #-8]
    // 0xcd059c: CheckStackOverflow
    //     0xcd059c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd05a0: cmp             SP, x16
    //     0xcd05a4: b.ls            #0xcd05e0
    // 0xcd05a8: mov             x1, x0
    // 0xcd05ac: r0 = clearSemantics()
    //     0xcd05ac: bl              #0xcd05e8  ; [package:flutter/src/rendering/object.dart] RenderObject::clearSemantics
    // 0xcd05b0: ldur            x0, [fp, #-8]
    // 0xcd05b4: LoadField: r1 = r0->field_8b
    //     0xcd05b4: ldur            w1, [x0, #0x8b]
    // 0xcd05b8: DecompressPointer r1
    //     0xcd05b8: add             x1, x1, HEAP, lsl #32
    // 0xcd05bc: r0 = clear()
    //     0xcd05bc: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xcd05c0: ldur            x0, [fp, #-8]
    // 0xcd05c4: LoadField: r1 = r0->field_8f
    //     0xcd05c4: ldur            w1, [x0, #0x8f]
    // 0xcd05c8: DecompressPointer r1
    //     0xcd05c8: add             x1, x1, HEAP, lsl #32
    // 0xcd05cc: r0 = clear()
    //     0xcd05cc: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xcd05d0: r0 = Null
    //     0xcd05d0: mov             x0, NULL
    // 0xcd05d4: LeaveFrame
    //     0xcd05d4: mov             SP, fp
    //     0xcd05d8: ldp             fp, lr, [SP], #0x10
    // 0xcd05dc: ret
    //     0xcd05dc: ret             
    // 0xcd05e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd05e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd05e4: b               #0xcd05a8
  }
  set _ configuration=(/* No info */) {
    // ** addr: 0xcfeb14, size: 0x88
    // 0xcfeb14: EnterFrame
    //     0xcfeb14: stp             fp, lr, [SP, #-0x10]!
    //     0xcfeb18: mov             fp, SP
    // 0xcfeb1c: AllocStack(0x20)
    //     0xcfeb1c: sub             SP, SP, #0x20
    // 0xcfeb20: SetupParameters(RenderTable this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcfeb20: mov             x0, x2
    //     0xcfeb24: stur            x1, [fp, #-8]
    //     0xcfeb28: stur            x2, [fp, #-0x10]
    // 0xcfeb2c: CheckStackOverflow
    //     0xcfeb2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfeb30: cmp             SP, x16
    //     0xcfeb34: b.ls            #0xcfeb94
    // 0xcfeb38: LoadField: r2 = r1->field_7b
    //     0xcfeb38: ldur            w2, [x1, #0x7b]
    // 0xcfeb3c: DecompressPointer r2
    //     0xcfeb3c: add             x2, x2, HEAP, lsl #32
    // 0xcfeb40: stp             x2, x0, [SP]
    // 0xcfeb44: r0 = ==()
    //     0xcfeb44: bl              #0x1299204  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::==
    // 0xcfeb48: tbnz            w0, #4, #0xcfeb5c
    // 0xcfeb4c: r0 = Null
    //     0xcfeb4c: mov             x0, NULL
    // 0xcfeb50: LeaveFrame
    //     0xcfeb50: mov             SP, fp
    //     0xcfeb54: ldp             fp, lr, [SP], #0x10
    // 0xcfeb58: ret
    //     0xcfeb58: ret             
    // 0xcfeb5c: ldur            x1, [fp, #-8]
    // 0xcfeb60: ldur            x0, [fp, #-0x10]
    // 0xcfeb64: StoreField: r1->field_7b = r0
    //     0xcfeb64: stur            w0, [x1, #0x7b]
    //     0xcfeb68: ldurb           w16, [x1, #-1]
    //     0xcfeb6c: ldurb           w17, [x0, #-1]
    //     0xcfeb70: and             x16, x17, x16, lsr #2
    //     0xcfeb74: tst             x16, HEAP, lsr #32
    //     0xcfeb78: b.eq            #0xcfeb80
    //     0xcfeb7c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcfeb80: r0 = markNeedsPaint()
    //     0xcfeb80: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcfeb84: r0 = Null
    //     0xcfeb84: mov             x0, NULL
    // 0xcfeb88: LeaveFrame
    //     0xcfeb88: mov             SP, fp
    //     0xcfeb8c: ldp             fp, lr, [SP], #0x10
    // 0xcfeb90: ret
    //     0xcfeb90: ret             
    // 0xcfeb94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfeb94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfeb98: b               #0xcfeb38
  }
  set _ rowDecorations=(/* No info */) {
    // ** addr: 0xcfeb9c, size: 0x148
    // 0xcfeb9c: EnterFrame
    //     0xcfeb9c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfeba0: mov             fp, SP
    // 0xcfeba4: AllocStack(0x20)
    //     0xcfeba4: sub             SP, SP, #0x20
    // 0xcfeba8: SetupParameters(RenderTable this /* r1 => r2, fp-0x20 */, dynamic _ /* r2 => r0 */)
    //     0xcfeba8: mov             x0, x2
    //     0xcfebac: mov             x2, x1
    //     0xcfebb0: stur            x1, [fp, #-0x20]
    // 0xcfebb4: CheckStackOverflow
    //     0xcfebb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfebb8: cmp             SP, x16
    //     0xcfebbc: b.ls            #0xcfecd4
    // 0xcfebc0: LoadField: r1 = r2->field_73
    //     0xcfebc0: ldur            w1, [x2, #0x73]
    // 0xcfebc4: DecompressPointer r1
    //     0xcfebc4: add             x1, x1, HEAP, lsl #32
    // 0xcfebc8: cmp             w1, w0
    // 0xcfebcc: b.ne            #0xcfebe0
    // 0xcfebd0: r0 = Null
    //     0xcfebd0: mov             x0, NULL
    // 0xcfebd4: LeaveFrame
    //     0xcfebd4: mov             SP, fp
    //     0xcfebd8: ldp             fp, lr, [SP], #0x10
    // 0xcfebdc: ret
    //     0xcfebdc: ret             
    // 0xcfebe0: StoreField: r2->field_73 = r0
    //     0xcfebe0: stur            w0, [x2, #0x73]
    //     0xcfebe4: ldurb           w16, [x2, #-1]
    //     0xcfebe8: ldurb           w17, [x0, #-1]
    //     0xcfebec: and             x16, x17, x16, lsr #2
    //     0xcfebf0: tst             x16, HEAP, lsr #32
    //     0xcfebf4: b.eq            #0xcfebfc
    //     0xcfebf8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcfebfc: LoadField: r3 = r2->field_77
    //     0xcfebfc: ldur            w3, [x2, #0x77]
    // 0xcfec00: DecompressPointer r3
    //     0xcfec00: add             x3, x3, HEAP, lsl #32
    // 0xcfec04: stur            x3, [fp, #-0x18]
    // 0xcfec08: cmp             w3, NULL
    // 0xcfec0c: b.eq            #0xcfec78
    // 0xcfec10: LoadField: r0 = r3->field_b
    //     0xcfec10: ldur            w0, [x3, #0xb]
    // 0xcfec14: r4 = LoadInt32Instr(r0)
    //     0xcfec14: sbfx            x4, x0, #1, #0x1f
    // 0xcfec18: stur            x4, [fp, #-0x10]
    // 0xcfec1c: r0 = 0
    //     0xcfec1c: mov             x0, #0
    // 0xcfec20: CheckStackOverflow
    //     0xcfec20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfec24: cmp             SP, x16
    //     0xcfec28: b.ls            #0xcfecdc
    // 0xcfec2c: cmp             x0, x4
    // 0xcfec30: b.ge            #0xcfec78
    // 0xcfec34: ArrayLoad: r1 = r3[r0]  ; Unknown_4
    //     0xcfec34: add             x16, x3, x0, lsl #2
    //     0xcfec38: ldur            w1, [x16, #0xf]
    // 0xcfec3c: DecompressPointer r1
    //     0xcfec3c: add             x1, x1, HEAP, lsl #32
    // 0xcfec40: add             x5, x0, #1
    // 0xcfec44: stur            x5, [fp, #-8]
    // 0xcfec48: cmp             w1, NULL
    // 0xcfec4c: b.eq            #0xcfec64
    // 0xcfec50: r0 = LoadClassIdInstr(r1)
    //     0xcfec50: ldur            x0, [x1, #-1]
    //     0xcfec54: ubfx            x0, x0, #0xc, #0x14
    // 0xcfec58: r0 = GDT[cid_x0 + -0x1000]()
    //     0xcfec58: sub             lr, x0, #1, lsl #12
    //     0xcfec5c: ldr             lr, [x21, lr, lsl #3]
    //     0xcfec60: blr             lr
    // 0xcfec64: ldur            x0, [fp, #-8]
    // 0xcfec68: ldur            x2, [fp, #-0x20]
    // 0xcfec6c: ldur            x3, [fp, #-0x18]
    // 0xcfec70: ldur            x4, [fp, #-0x10]
    // 0xcfec74: b               #0xcfec20
    // 0xcfec78: ldur            x0, [fp, #-0x20]
    // 0xcfec7c: LoadField: r1 = r0->field_73
    //     0xcfec7c: ldur            w1, [x0, #0x73]
    // 0xcfec80: DecompressPointer r1
    //     0xcfec80: add             x1, x1, HEAP, lsl #32
    // 0xcfec84: cmp             w1, NULL
    // 0xcfec88: b.eq            #0xcfeca0
    // 0xcfec8c: LoadField: r2 = r1->field_b
    //     0xcfec8c: ldur            w2, [x1, #0xb]
    // 0xcfec90: r1 = <BoxPainter?>
    //     0xcfec90: add             x1, PP, #0x96, lsl #12  ; [pp+0x96d60] TypeArguments: <BoxPainter?>
    //     0xcfec94: ldr             x1, [x1, #0xd60]
    // 0xcfec98: r0 = AllocateArray()
    //     0xcfec98: bl              #0x13df928  ; AllocateArrayStub
    // 0xcfec9c: b               #0xcfeca4
    // 0xcfeca0: r0 = Null
    //     0xcfeca0: mov             x0, NULL
    // 0xcfeca4: ldur            x1, [fp, #-0x20]
    // 0xcfeca8: StoreField: r1->field_77 = r0
    //     0xcfeca8: stur            w0, [x1, #0x77]
    //     0xcfecac: ldurb           w16, [x1, #-1]
    //     0xcfecb0: ldurb           w17, [x0, #-1]
    //     0xcfecb4: and             x16, x17, x16, lsr #2
    //     0xcfecb8: tst             x16, HEAP, lsr #32
    //     0xcfecbc: b.eq            #0xcfecc4
    //     0xcfecc0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcfecc4: r0 = Null
    //     0xcfecc4: mov             x0, NULL
    // 0xcfecc8: LeaveFrame
    //     0xcfecc8: mov             SP, fp
    //     0xcfeccc: ldp             fp, lr, [SP], #0x10
    // 0xcfecd0: ret
    //     0xcfecd0: ret             
    // 0xcfecd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfecd4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfecd8: b               #0xcfebc0
    // 0xcfecdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfecdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfece0: b               #0xcfec2c
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcfece4, size: 0x70
    // 0xcfece4: EnterFrame
    //     0xcfece4: stp             fp, lr, [SP, #-0x10]!
    //     0xcfece8: mov             fp, SP
    // 0xcfecec: mov             x0, x2
    // 0xcfecf0: CheckStackOverflow
    //     0xcfecf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfecf4: cmp             SP, x16
    //     0xcfecf8: b.ls            #0xcfed4c
    // 0xcfecfc: LoadField: r2 = r1->field_6b
    //     0xcfecfc: ldur            w2, [x1, #0x6b]
    // 0xcfed00: DecompressPointer r2
    //     0xcfed00: add             x2, x2, HEAP, lsl #32
    // 0xcfed04: cmp             w2, w0
    // 0xcfed08: b.ne            #0xcfed1c
    // 0xcfed0c: r0 = Null
    //     0xcfed0c: mov             x0, NULL
    // 0xcfed10: LeaveFrame
    //     0xcfed10: mov             SP, fp
    //     0xcfed14: ldp             fp, lr, [SP], #0x10
    // 0xcfed18: ret
    //     0xcfed18: ret             
    // 0xcfed1c: StoreField: r1->field_6b = r0
    //     0xcfed1c: stur            w0, [x1, #0x6b]
    //     0xcfed20: ldurb           w16, [x1, #-1]
    //     0xcfed24: ldurb           w17, [x0, #-1]
    //     0xcfed28: and             x16, x17, x16, lsr #2
    //     0xcfed2c: tst             x16, HEAP, lsr #32
    //     0xcfed30: b.eq            #0xcfed38
    //     0xcfed34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcfed38: r0 = markNeedsLayout()
    //     0xcfed38: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcfed3c: r0 = Null
    //     0xcfed3c: mov             x0, NULL
    // 0xcfed40: LeaveFrame
    //     0xcfed40: mov             SP, fp
    //     0xcfed44: ldp             fp, lr, [SP], #0x10
    // 0xcfed48: ret
    //     0xcfed48: ret             
    // 0xcfed4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfed4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfed50: b               #0xcfecfc
  }
  set _ columnWidths=(/* No info */) {
    // ** addr: 0xcfed54, size: 0xa8
    // 0xcfed54: EnterFrame
    //     0xcfed54: stp             fp, lr, [SP, #-0x10]!
    //     0xcfed58: mov             fp, SP
    // 0xcfed5c: AllocStack(0x10)
    //     0xcfed5c: sub             SP, SP, #0x10
    // 0xcfed60: SetupParameters(RenderTable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xcfed60: mov             x3, x1
    //     0xcfed64: stur            x1, [fp, #-8]
    //     0xcfed68: stur            x2, [fp, #-0x10]
    // 0xcfed6c: CheckStackOverflow
    //     0xcfed6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfed70: cmp             SP, x16
    //     0xcfed74: b.ls            #0xcfedf4
    // 0xcfed78: LoadField: r0 = r3->field_63
    //     0xcfed78: ldur            w0, [x3, #0x63]
    // 0xcfed7c: DecompressPointer r0
    //     0xcfed7c: add             x0, x0, HEAP, lsl #32
    // 0xcfed80: cmp             w0, w2
    // 0xcfed84: b.ne            #0xcfed98
    // 0xcfed88: r0 = Null
    //     0xcfed88: mov             x0, NULL
    // 0xcfed8c: LeaveFrame
    //     0xcfed8c: mov             SP, fp
    //     0xcfed90: ldp             fp, lr, [SP], #0x10
    // 0xcfed94: ret
    //     0xcfed94: ret             
    // 0xcfed98: LoadField: r1 = r0->field_b
    //     0xcfed98: ldur            w1, [x0, #0xb]
    // 0xcfed9c: DecompressPointer r1
    //     0xcfed9c: add             x1, x1, HEAP, lsl #32
    // 0xcfeda0: r0 = LoadClassIdInstr(r1)
    //     0xcfeda0: ldur            x0, [x1, #-1]
    //     0xcfeda4: ubfx            x0, x0, #0xc, #0x14
    // 0xcfeda8: r0 = GDT[cid_x0 + 0x12b36]()
    //     0xcfeda8: mov             x17, #0x2b36
    //     0xcfedac: movk            x17, #1, lsl #16
    //     0xcfedb0: add             lr, x0, x17
    //     0xcfedb4: ldr             lr, [x21, lr, lsl #3]
    //     0xcfedb8: blr             lr
    // 0xcfedbc: ldur            x0, [fp, #-0x10]
    // 0xcfedc0: ldur            x1, [fp, #-8]
    // 0xcfedc4: StoreField: r1->field_63 = r0
    //     0xcfedc4: stur            w0, [x1, #0x63]
    //     0xcfedc8: ldurb           w16, [x1, #-1]
    //     0xcfedcc: ldurb           w17, [x0, #-1]
    //     0xcfedd0: and             x16, x17, x16, lsr #2
    //     0xcfedd4: tst             x16, HEAP, lsr #32
    //     0xcfedd8: b.eq            #0xcfede0
    //     0xcfeddc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcfede0: r0 = markNeedsLayout()
    //     0xcfede0: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcfede4: r0 = Null
    //     0xcfede4: mov             x0, NULL
    // 0xcfede8: LeaveFrame
    //     0xcfede8: mov             SP, fp
    //     0xcfedec: ldp             fp, lr, [SP], #0x10
    // 0xcfedf0: ret
    //     0xcfedf0: ret             
    // 0xcfedf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfedf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfedf8: b               #0xcfed78
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ecfd0, size: 0x1c0
    // 0x10ecfd0: EnterFrame
    //     0x10ecfd0: stp             fp, lr, [SP, #-0x10]!
    //     0x10ecfd4: mov             fp, SP
    // 0x10ecfd8: AllocStack(0x48)
    //     0x10ecfd8: sub             SP, SP, #0x48
    // 0x10ecfdc: SetupParameters(RenderTable this /* r1 => r3, fp-0x10 */, dynamic _ /* r3 => r1, fp-0x18 */)
    //     0x10ecfdc: stur            x1, [fp, #-8]
    //     0x10ecfe0: mov             x16, x3
    //     0x10ecfe4: mov             x3, x1
    //     0x10ecfe8: mov             x1, x16
    //     0x10ecfec: stur            x2, [fp, #-0x10]
    //     0x10ecff0: stur            x1, [fp, #-0x18]
    // 0x10ecff4: CheckStackOverflow
    //     0x10ecff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ecff8: cmp             SP, x16
    //     0x10ecffc: b.ls            #0x10ed17c
    // 0x10ed000: LoadField: r0 = r3->field_4f
    //     0x10ed000: ldur            w0, [x3, #0x4f]
    // 0x10ed004: DecompressPointer r0
    //     0x10ed004: add             x0, x0, HEAP, lsl #32
    // 0x10ed008: r4 = LoadClassIdInstr(r0)
    //     0x10ed008: ldur            x4, [x0, #-1]
    //     0x10ed00c: ubfx            x4, x4, #0xc, #0x14
    // 0x10ed010: str             x0, [SP]
    // 0x10ed014: mov             x0, x4
    // 0x10ed018: r0 = GDT[cid_x0 + 0xf078]()
    //     0x10ed018: mov             x17, #0xf078
    //     0x10ed01c: add             lr, x0, x17
    //     0x10ed020: ldr             lr, [x21, lr, lsl #3]
    //     0x10ed024: blr             lr
    // 0x10ed028: r1 = LoadInt32Instr(r0)
    //     0x10ed028: sbfx            x1, x0, #1, #0x1f
    // 0x10ed02c: sub             x0, x1, #1
    // 0x10ed030: mov             x3, x0
    // 0x10ed034: ldur            x2, [fp, #-8]
    // 0x10ed038: stur            x3, [fp, #-0x20]
    // 0x10ed03c: CheckStackOverflow
    //     0x10ed03c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ed040: cmp             SP, x16
    //     0x10ed044: b.ls            #0x10ed184
    // 0x10ed048: tbnz            x3, #0x3f, #0x10ed16c
    // 0x10ed04c: LoadField: r4 = r2->field_4f
    //     0x10ed04c: ldur            w4, [x2, #0x4f]
    // 0x10ed050: DecompressPointer r4
    //     0x10ed050: add             x4, x4, HEAP, lsl #32
    // 0x10ed054: r0 = BoxInt64Instr(r3)
    //     0x10ed054: sbfiz           x0, x3, #1, #0x1f
    //     0x10ed058: cmp             x3, x0, asr #1
    //     0x10ed05c: b.eq            #0x10ed068
    //     0x10ed060: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x10ed064: stur            x3, [x0, #7]
    // 0x10ed068: r1 = LoadClassIdInstr(r4)
    //     0x10ed068: ldur            x1, [x4, #-1]
    //     0x10ed06c: ubfx            x1, x1, #0xc, #0x14
    // 0x10ed070: stp             x0, x4, [SP]
    // 0x10ed074: mov             x0, x1
    // 0x10ed078: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x10ed078: sub             lr, x0, #0xdfd
    //     0x10ed07c: ldr             lr, [x21, lr, lsl #3]
    //     0x10ed080: blr             lr
    // 0x10ed084: mov             x3, x0
    // 0x10ed088: stur            x3, [fp, #-0x30]
    // 0x10ed08c: cmp             w3, NULL
    // 0x10ed090: b.eq            #0x10ed160
    // 0x10ed094: LoadField: r4 = r3->field_7
    //     0x10ed094: ldur            w4, [x3, #7]
    // 0x10ed098: DecompressPointer r4
    //     0x10ed098: add             x4, x4, HEAP, lsl #32
    // 0x10ed09c: stur            x4, [fp, #-0x28]
    // 0x10ed0a0: cmp             w4, NULL
    // 0x10ed0a4: b.eq            #0x10ed18c
    // 0x10ed0a8: mov             x0, x4
    // 0x10ed0ac: r2 = Null
    //     0x10ed0ac: mov             x2, NULL
    // 0x10ed0b0: r1 = Null
    //     0x10ed0b0: mov             x1, NULL
    // 0x10ed0b4: r4 = LoadClassIdInstr(r0)
    //     0x10ed0b4: ldur            x4, [x0, #-1]
    //     0x10ed0b8: ubfx            x4, x4, #0xc, #0x14
    // 0x10ed0bc: r17 = -4190
    //     0x10ed0bc: mov             x17, #-0x105e
    // 0x10ed0c0: add             x4, x4, x17
    // 0x10ed0c4: cmp             x4, #0x17
    // 0x10ed0c8: b.ls            #0x10ed0e0
    // 0x10ed0cc: r8 = BoxParentData
    //     0x10ed0cc: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0x10ed0d0: ldr             x8, [x8, #0x5e8]
    // 0x10ed0d4: r3 = Null
    //     0x10ed0d4: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1210] Null
    //     0x10ed0d8: ldr             x3, [x3, #0x210]
    // 0x10ed0dc: r0 = DefaultTypeTest()
    //     0x10ed0dc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10ed0e0: ldur            x0, [fp, #-0x28]
    // 0x10ed0e4: LoadField: r3 = r0->field_7
    //     0x10ed0e4: ldur            w3, [x0, #7]
    // 0x10ed0e8: DecompressPointer r3
    //     0x10ed0e8: add             x3, x3, HEAP, lsl #32
    // 0x10ed0ec: ldur            x1, [fp, #-0x18]
    // 0x10ed0f0: mov             x2, x3
    // 0x10ed0f4: stur            x3, [fp, #-0x38]
    // 0x10ed0f8: r0 = -()
    //     0x10ed0f8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x10ed0fc: ldur            x1, [fp, #-0x38]
    // 0x10ed100: stur            x0, [fp, #-0x28]
    // 0x10ed104: r0 = unary-()
    //     0x10ed104: bl              #0x856e6c  ; [dart:ui] Offset::unary-
    // 0x10ed108: ldur            x1, [fp, #-0x10]
    // 0x10ed10c: mov             x2, x0
    // 0x10ed110: r0 = pushOffset()
    //     0x10ed110: bl              #0xaf9e0c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x10ed114: ldur            x1, [fp, #-0x30]
    // 0x10ed118: r0 = LoadClassIdInstr(r1)
    //     0x10ed118: ldur            x0, [x1, #-1]
    //     0x10ed11c: ubfx            x0, x0, #0xc, #0x14
    // 0x10ed120: ldur            x2, [fp, #-0x10]
    // 0x10ed124: ldur            x3, [fp, #-0x28]
    // 0x10ed128: r0 = GDT[cid_x0 + 0x13d77]()
    //     0x10ed128: mov             x17, #0x3d77
    //     0x10ed12c: movk            x17, #1, lsl #16
    //     0x10ed130: add             lr, x0, x17
    //     0x10ed134: ldr             lr, [x21, lr, lsl #3]
    //     0x10ed138: blr             lr
    // 0x10ed13c: ldur            x1, [fp, #-0x10]
    // 0x10ed140: stur            x0, [fp, #-0x28]
    // 0x10ed144: r0 = popTransform()
    //     0x10ed144: bl              #0xaf9850  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x10ed148: ldur            x1, [fp, #-0x28]
    // 0x10ed14c: tbnz            w1, #4, #0x10ed160
    // 0x10ed150: r0 = true
    //     0x10ed150: add             x0, NULL, #0x20  ; true
    // 0x10ed154: LeaveFrame
    //     0x10ed154: mov             SP, fp
    //     0x10ed158: ldp             fp, lr, [SP], #0x10
    // 0x10ed15c: ret
    //     0x10ed15c: ret             
    // 0x10ed160: ldur            x1, [fp, #-0x20]
    // 0x10ed164: sub             x3, x1, #1
    // 0x10ed168: b               #0x10ed034
    // 0x10ed16c: r0 = false
    //     0x10ed16c: add             x0, NULL, #0x30  ; false
    // 0x10ed170: LeaveFrame
    //     0x10ed170: mov             SP, fp
    //     0x10ed174: ldp             fp, lr, [SP], #0x10
    // 0x10ed178: ret
    //     0x10ed178: ret             
    // 0x10ed17c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ed17c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ed180: b               #0x10ed000
    // 0x10ed184: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ed184: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ed188: b               #0x10ed048
    // 0x10ed18c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10ed18c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f0300, size: 0x24
    // 0x10f0300: EnterFrame
    //     0x10f0300: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0304: mov             fp, SP
    // 0x10f0308: ldr             x2, [fp, #0x10]
    // 0x10f030c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f030c: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa11e8] AnonymousClosure: (0xb263a0), in [package:flutter/src/rendering/table.dart] RenderTable::computeMinIntrinsicHeight (0xb26138)
    //     0x10f0310: ldr             x1, [x1, #0x1e8]
    // 0x10f0314: r0 = AllocateClosure()
    //     0x10f0314: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0318: LeaveFrame
    //     0x10f0318: mov             SP, fp
    //     0x10f031c: ldp             fp, lr, [SP], #0x10
    // 0x10f0320: ret
    //     0x10f0320: ret             
  }
  _ setChild(/* No info */) {
    // ** addr: 0x1146c2c, size: 0x130
    // 0x1146c2c: EnterFrame
    //     0x1146c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x1146c30: mov             fp, SP
    // 0x1146c34: AllocStack(0x38)
    //     0x1146c34: sub             SP, SP, #0x38
    // 0x1146c38: SetupParameters(RenderTable this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r0 */, dynamic _ /* r5 => r2, fp-0x18 */)
    //     0x1146c38: mov             x4, x1
    //     0x1146c3c: mov             x0, x2
    //     0x1146c40: mov             x2, x5
    //     0x1146c44: stur            x1, [fp, #-0x10]
    //     0x1146c48: stur            x5, [fp, #-0x18]
    // 0x1146c4c: CheckStackOverflow
    //     0x1146c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1146c50: cmp             SP, x16
    //     0x1146c54: b.ls            #0x1146d54
    // 0x1146c58: LoadField: r1 = r4->field_53
    //     0x1146c58: ldur            x1, [x4, #0x53]
    // 0x1146c5c: mul             x5, x3, x1
    // 0x1146c60: add             x3, x0, x5
    // 0x1146c64: LoadField: r5 = r4->field_4f
    //     0x1146c64: ldur            w5, [x4, #0x4f]
    // 0x1146c68: DecompressPointer r5
    //     0x1146c68: add             x5, x5, HEAP, lsl #32
    // 0x1146c6c: r0 = BoxInt64Instr(r3)
    //     0x1146c6c: sbfiz           x0, x3, #1, #0x1f
    //     0x1146c70: cmp             x3, x0, asr #1
    //     0x1146c74: b.eq            #0x1146c80
    //     0x1146c78: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x1146c7c: stur            x3, [x0, #7]
    // 0x1146c80: mov             x1, x0
    // 0x1146c84: stur            x1, [fp, #-8]
    // 0x1146c88: r0 = LoadClassIdInstr(r5)
    //     0x1146c88: ldur            x0, [x5, #-1]
    //     0x1146c8c: ubfx            x0, x0, #0xc, #0x14
    // 0x1146c90: stp             x1, x5, [SP]
    // 0x1146c94: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x1146c94: sub             lr, x0, #0xdfd
    //     0x1146c98: ldr             lr, [x21, lr, lsl #3]
    //     0x1146c9c: blr             lr
    // 0x1146ca0: mov             x1, x0
    // 0x1146ca4: stur            x1, [fp, #-0x20]
    // 0x1146ca8: r0 = 60
    //     0x1146ca8: mov             x0, #0x3c
    // 0x1146cac: branchIfSmi(r1, 0x1146cb8)
    //     0x1146cac: tbz             w1, #0, #0x1146cb8
    // 0x1146cb0: r0 = LoadClassIdInstr(r1)
    //     0x1146cb0: ldur            x0, [x1, #-1]
    //     0x1146cb4: ubfx            x0, x0, #0xc, #0x14
    // 0x1146cb8: ldur            x16, [fp, #-0x18]
    // 0x1146cbc: stp             x16, x1, [SP]
    // 0x1146cc0: mov             lr, x0
    // 0x1146cc4: ldr             lr, [x21, lr, lsl #3]
    // 0x1146cc8: blr             lr
    // 0x1146ccc: tbnz            w0, #4, #0x1146ce0
    // 0x1146cd0: r0 = Null
    //     0x1146cd0: mov             x0, NULL
    // 0x1146cd4: LeaveFrame
    //     0x1146cd4: mov             SP, fp
    //     0x1146cd8: ldp             fp, lr, [SP], #0x10
    // 0x1146cdc: ret
    //     0x1146cdc: ret             
    // 0x1146ce0: ldur            x2, [fp, #-0x20]
    // 0x1146ce4: cmp             w2, NULL
    // 0x1146ce8: b.eq            #0x1146cf4
    // 0x1146cec: ldur            x1, [fp, #-0x10]
    // 0x1146cf0: r0 = dropChild()
    //     0x1146cf0: bl              #0xbee868  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x1146cf4: ldur            x1, [fp, #-0x10]
    // 0x1146cf8: ldur            x2, [fp, #-0x18]
    // 0x1146cfc: LoadField: r0 = r1->field_4f
    //     0x1146cfc: ldur            w0, [x1, #0x4f]
    // 0x1146d00: DecompressPointer r0
    //     0x1146d00: add             x0, x0, HEAP, lsl #32
    // 0x1146d04: r3 = LoadClassIdInstr(r0)
    //     0x1146d04: ldur            x3, [x0, #-1]
    //     0x1146d08: ubfx            x3, x3, #0xc, #0x14
    // 0x1146d0c: ldur            x16, [fp, #-8]
    // 0x1146d10: stp             x16, x0, [SP, #8]
    // 0x1146d14: str             x2, [SP]
    // 0x1146d18: mov             x0, x3
    // 0x1146d1c: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0x1146d1c: mov             x17, #0x8dc8
    //     0x1146d20: movk            x17, #1, lsl #16
    //     0x1146d24: add             lr, x0, x17
    //     0x1146d28: ldr             lr, [x21, lr, lsl #3]
    //     0x1146d2c: blr             lr
    // 0x1146d30: ldur            x2, [fp, #-0x18]
    // 0x1146d34: cmp             w2, NULL
    // 0x1146d38: b.eq            #0x1146d44
    // 0x1146d3c: ldur            x1, [fp, #-0x10]
    // 0x1146d40: r0 = adoptChild()
    //     0x1146d40: bl              #0xc05494  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x1146d44: r0 = Null
    //     0x1146d44: mov             x0, NULL
    // 0x1146d48: LeaveFrame
    //     0x1146d48: mov             SP, fp
    //     0x1146d4c: ldp             fp, lr, [SP], #0x10
    // 0x1146d50: ret
    //     0x1146d50: ret             
    // 0x1146d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1146d54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1146d58: b               #0x1146c58
  }
  _ RenderTable(/* No info */) {
    // ** addr: 0x11d5c14, size: 0x258
    // 0x11d5c14: EnterFrame
    //     0x11d5c14: stp             fp, lr, [SP, #-0x10]!
    //     0x11d5c18: mov             fp, SP
    // 0x11d5c1c: AllocStack(0x40)
    //     0x11d5c1c: sub             SP, SP, #0x40
    // 0x11d5c20: r4 = const []
    //     0x11d5c20: add             x4, PP, #0x96, lsl #12  ; [pp+0x96d68] List<RenderBox?>(0)
    //     0x11d5c24: ldr             x4, [x4, #0xd68]
    // 0x11d5c28: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0x11d5c2c: stur            x1, [fp, #-8]
    // 0x11d5c30: mov             x16, x5
    // 0x11d5c34: mov             x5, x1
    // 0x11d5c38: mov             x1, x16
    // 0x11d5c3c: mov             x16, x2
    // 0x11d5c40: mov             x2, x5
    // 0x11d5c44: mov             x5, x16
    // 0x11d5c48: mov             x16, x6
    // 0x11d5c4c: mov             x6, x2
    // 0x11d5c50: mov             x2, x16
    // 0x11d5c54: stur            x5, [fp, #-0x10]
    // 0x11d5c58: stur            x3, [fp, #-0x18]
    // 0x11d5c5c: stur            x1, [fp, #-0x20]
    // 0x11d5c60: stur            x2, [fp, #-0x28]
    // 0x11d5c64: stur            x7, [fp, #-0x30]
    // 0x11d5c68: CheckStackOverflow
    //     0x11d5c68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d5c6c: cmp             SP, x16
    //     0x11d5c70: b.ls            #0x11d5e64
    // 0x11d5c74: StoreField: r6->field_4f = r4
    //     0x11d5c74: stur            w4, [x6, #0x4f]
    // 0x11d5c78: StoreField: r6->field_9f = r0
    //     0x11d5c78: stur            w0, [x6, #0x9f]
    // 0x11d5c7c: r16 = <int, _Index>
    //     0x11d5c7c: add             x16, PP, #0x96, lsl #12  ; [pp+0x96d70] TypeArguments: <int, _Index>
    //     0x11d5c80: ldr             x16, [x16, #0xd70]
    // 0x11d5c84: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11d5c88: stp             lr, x16, [SP]
    // 0x11d5c8c: r0 = Map._fromLiteral()
    //     0x11d5c8c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11d5c90: ldur            x1, [fp, #-8]
    // 0x11d5c94: StoreField: r1->field_87 = r0
    //     0x11d5c94: stur            w0, [x1, #0x87]
    //     0x11d5c98: ldurb           w16, [x1, #-1]
    //     0x11d5c9c: ldurb           w17, [x0, #-1]
    //     0x11d5ca0: and             x16, x17, x16, lsr #2
    //     0x11d5ca4: tst             x16, HEAP, lsr #32
    //     0x11d5ca8: b.eq            #0x11d5cb0
    //     0x11d5cac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d5cb0: r16 = <int, SemanticsNode>
    //     0x11d5cb0: ldr             x16, [PP, #0x25a0]  ; [pp+0x25a0] TypeArguments: <int, SemanticsNode>
    // 0x11d5cb4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11d5cb8: stp             lr, x16, [SP]
    // 0x11d5cbc: r0 = Map._fromLiteral()
    //     0x11d5cbc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11d5cc0: ldur            x1, [fp, #-8]
    // 0x11d5cc4: StoreField: r1->field_8b = r0
    //     0x11d5cc4: stur            w0, [x1, #0x8b]
    //     0x11d5cc8: ldurb           w16, [x1, #-1]
    //     0x11d5ccc: ldurb           w17, [x0, #-1]
    //     0x11d5cd0: and             x16, x17, x16, lsr #2
    //     0x11d5cd4: tst             x16, HEAP, lsr #32
    //     0x11d5cd8: b.eq            #0x11d5ce0
    //     0x11d5cdc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d5ce0: r16 = <_Index, SemanticsNode>
    //     0x11d5ce0: add             x16, PP, #0x96, lsl #12  ; [pp+0x96d78] TypeArguments: <_Index, SemanticsNode>
    //     0x11d5ce4: ldr             x16, [x16, #0xd78]
    // 0x11d5ce8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11d5cec: stp             lr, x16, [SP]
    // 0x11d5cf0: r0 = Map._fromLiteral()
    //     0x11d5cf0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11d5cf4: ldur            x3, [fp, #-8]
    // 0x11d5cf8: StoreField: r3->field_8f = r0
    //     0x11d5cf8: stur            w0, [x3, #0x8f]
    //     0x11d5cfc: ldurb           w16, [x3, #-1]
    //     0x11d5d00: ldurb           w17, [x0, #-1]
    //     0x11d5d04: and             x16, x17, x16, lsr #2
    //     0x11d5d08: tst             x16, HEAP, lsr #32
    //     0x11d5d0c: b.eq            #0x11d5d14
    //     0x11d5d10: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11d5d14: r1 = <double>
    //     0x11d5d14: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11d5d18: r2 = 0
    //     0x11d5d18: mov             x2, #0
    // 0x11d5d1c: r0 = _GrowableList()
    //     0x11d5d1c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x11d5d20: ldur            x1, [fp, #-8]
    // 0x11d5d24: StoreField: r1->field_97 = r0
    //     0x11d5d24: stur            w0, [x1, #0x97]
    //     0x11d5d28: ldurb           w16, [x1, #-1]
    //     0x11d5d2c: ldurb           w17, [x0, #-1]
    //     0x11d5d30: and             x16, x17, x16, lsr #2
    //     0x11d5d34: tst             x16, HEAP, lsr #32
    //     0x11d5d38: b.eq            #0x11d5d40
    //     0x11d5d3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d5d40: ldr             x0, [fp, #0x10]
    // 0x11d5d44: StoreField: r1->field_6b = r0
    //     0x11d5d44: stur            w0, [x1, #0x6b]
    //     0x11d5d48: ldurb           w16, [x1, #-1]
    //     0x11d5d4c: ldurb           w17, [x0, #-1]
    //     0x11d5d50: and             x16, x17, x16, lsr #2
    //     0x11d5d54: tst             x16, HEAP, lsr #32
    //     0x11d5d58: b.eq            #0x11d5d60
    //     0x11d5d5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d5d60: ldur            x0, [fp, #-0x18]
    // 0x11d5d64: StoreField: r1->field_53 = r0
    //     0x11d5d64: stur            x0, [x1, #0x53]
    // 0x11d5d68: ldur            x0, [fp, #-0x30]
    // 0x11d5d6c: StoreField: r1->field_5b = r0
    //     0x11d5d6c: stur            x0, [x1, #0x5b]
    // 0x11d5d70: ldur            x0, [fp, #-0x10]
    // 0x11d5d74: StoreField: r1->field_63 = r0
    //     0x11d5d74: stur            w0, [x1, #0x63]
    //     0x11d5d78: ldurb           w16, [x1, #-1]
    //     0x11d5d7c: ldurb           w17, [x0, #-1]
    //     0x11d5d80: and             x16, x17, x16, lsr #2
    //     0x11d5d84: tst             x16, HEAP, lsr #32
    //     0x11d5d88: b.eq            #0x11d5d90
    //     0x11d5d8c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d5d90: r0 = Instance_FlexColumnWidth
    //     0x11d5d90: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8ffc8] Obj!FlexColumnWidth@129ede1
    //     0x11d5d94: ldr             x0, [x0, #0xfc8]
    // 0x11d5d98: StoreField: r1->field_67 = r0
    //     0x11d5d98: stur            w0, [x1, #0x67]
    // 0x11d5d9c: r0 = Instance_TableCellVerticalAlignment
    //     0x11d5d9c: add             x0, PP, #0x8f, lsl #12  ; [pp+0x8ffd0] Obj!TableCellVerticalAlignment@12c4161
    //     0x11d5da0: ldr             x0, [x0, #0xfd0]
    // 0x11d5da4: StoreField: r1->field_7f = r0
    //     0x11d5da4: stur            w0, [x1, #0x7f]
    // 0x11d5da8: ldur            x0, [fp, #-0x20]
    // 0x11d5dac: StoreField: r1->field_7b = r0
    //     0x11d5dac: stur            w0, [x1, #0x7b]
    //     0x11d5db0: ldurb           w16, [x1, #-1]
    //     0x11d5db4: ldurb           w17, [x0, #-1]
    //     0x11d5db8: and             x16, x17, x16, lsr #2
    //     0x11d5dbc: tst             x16, HEAP, lsr #32
    //     0x11d5dc0: b.eq            #0x11d5dc8
    //     0x11d5dc4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d5dc8: r0 = _LayoutCacheStorage()
    //     0x11d5dc8: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d5dcc: ldur            x2, [fp, #-8]
    // 0x11d5dd0: StoreField: r2->field_47 = r0
    //     0x11d5dd0: stur            w0, [x2, #0x47]
    //     0x11d5dd4: ldurb           w16, [x2, #-1]
    //     0x11d5dd8: ldurb           w17, [x0, #-1]
    //     0x11d5ddc: and             x16, x17, x16, lsr #2
    //     0x11d5de0: tst             x16, HEAP, lsr #32
    //     0x11d5de4: b.eq            #0x11d5dec
    //     0x11d5de8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d5dec: mov             x1, x2
    // 0x11d5df0: r0 = RenderObject()
    //     0x11d5df0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d5df4: r1 = <RenderBox?>
    //     0x11d5df4: add             x1, PP, #0x96, lsl #12  ; [pp+0x96d80] TypeArguments: <RenderBox?>
    //     0x11d5df8: ldr             x1, [x1, #0xd80]
    // 0x11d5dfc: r2 = 0
    //     0x11d5dfc: mov             x2, #0
    // 0x11d5e00: r0 = _GrowableList()
    //     0x11d5e00: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x11d5e04: mov             x3, x0
    // 0x11d5e08: ldur            x0, [fp, #-8]
    // 0x11d5e0c: stur            x3, [fp, #-0x10]
    // 0x11d5e10: LoadField: r1 = r0->field_53
    //     0x11d5e10: ldur            x1, [x0, #0x53]
    // 0x11d5e14: LoadField: r2 = r0->field_5b
    //     0x11d5e14: ldur            x2, [x0, #0x5b]
    // 0x11d5e18: mul             x4, x1, x2
    // 0x11d5e1c: mov             x1, x3
    // 0x11d5e20: mov             x2, x4
    // 0x11d5e24: r0 = length=()
    //     0x11d5e24: bl              #0x9fa1d0  ; [dart:core] _GrowableList::length=
    // 0x11d5e28: ldur            x0, [fp, #-0x10]
    // 0x11d5e2c: ldur            x1, [fp, #-8]
    // 0x11d5e30: StoreField: r1->field_4f = r0
    //     0x11d5e30: stur            w0, [x1, #0x4f]
    //     0x11d5e34: ldurb           w16, [x1, #-1]
    //     0x11d5e38: ldurb           w17, [x0, #-1]
    //     0x11d5e3c: and             x16, x17, x16, lsr #2
    //     0x11d5e40: tst             x16, HEAP, lsr #32
    //     0x11d5e44: b.eq            #0x11d5e4c
    //     0x11d5e48: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d5e4c: ldur            x2, [fp, #-0x28]
    // 0x11d5e50: r0 = rowDecorations=()
    //     0x11d5e50: bl              #0xcfeb9c  ; [package:flutter/src/rendering/table.dart] RenderTable::rowDecorations=
    // 0x11d5e54: r0 = Null
    //     0x11d5e54: mov             x0, NULL
    // 0x11d5e58: LeaveFrame
    //     0x11d5e58: mov             SP, fp
    //     0x11d5e5c: ldp             fp, lr, [SP], #0x10
    // 0x11d5e60: ret
    //     0x11d5e60: ret             
    // 0x11d5e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d5e64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d5e68: b               #0x11d5c74
  }
}

// class id: 8219, size: 0x14, field offset: 0x14
enum TableCellVerticalAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab28c, size: 0x64
    // 0x11ab28c: EnterFrame
    //     0x11ab28c: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab290: mov             fp, SP
    // 0x11ab294: AllocStack(0x10)
    //     0x11ab294: sub             SP, SP, #0x10
    // 0x11ab298: SetupParameters(TableCellVerticalAlignment this /* r1 => r0, fp-0x8 */)
    //     0x11ab298: mov             x0, x1
    //     0x11ab29c: stur            x1, [fp, #-8]
    // 0x11ab2a0: CheckStackOverflow
    //     0x11ab2a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab2a4: cmp             SP, x16
    //     0x11ab2a8: b.ls            #0x11ab2e8
    // 0x11ab2ac: r1 = Null
    //     0x11ab2ac: mov             x1, NULL
    // 0x11ab2b0: r2 = 4
    //     0x11ab2b0: mov             x2, #4
    // 0x11ab2b4: r0 = AllocateArray()
    //     0x11ab2b4: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab2b8: r16 = "TableCellVerticalAlignment."
    //     0x11ab2b8: add             x16, PP, #0x96, lsl #12  ; [pp+0x964e0] "TableCellVerticalAlignment."
    //     0x11ab2bc: ldr             x16, [x16, #0x4e0]
    // 0x11ab2c0: StoreField: r0->field_f = r16
    //     0x11ab2c0: stur            w16, [x0, #0xf]
    // 0x11ab2c4: ldur            x1, [fp, #-8]
    // 0x11ab2c8: LoadField: r2 = r1->field_f
    //     0x11ab2c8: ldur            w2, [x1, #0xf]
    // 0x11ab2cc: DecompressPointer r2
    //     0x11ab2cc: add             x2, x2, HEAP, lsl #32
    // 0x11ab2d0: StoreField: r0->field_13 = r2
    //     0x11ab2d0: stur            w2, [x0, #0x13]
    // 0x11ab2d4: str             x0, [SP]
    // 0x11ab2d8: r0 = _interpolate()
    //     0x11ab2d8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab2dc: LeaveFrame
    //     0x11ab2dc: mov             SP, fp
    //     0x11ab2e0: ldp             fp, lr, [SP], #0x10
    // 0x11ab2e4: ret
    //     0x11ab2e4: ret             
    // 0x11ab2e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab2e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab2ec: b               #0x11ab2ac
  }
}
