// lib: , url: package:flutter/src/rendering/sliver_multi_box_adaptor.dart

// class id: 1049047, size: 0x8
class :: {
}

// class id: 2847, size: 0x8, field offset: 0x8
abstract class RenderSliverBoxChildManager extends Object {
}

// class id: 4171, size: 0x8, field offset: 0x8
abstract class KeepAliveParentDataMixin extends Object
    implements ParentData {
}

// class id: 4183, size: 0x20, field offset: 0x18
class SliverMultiBoxAdaptorParentData extends _MixinApplication449&SliverLogicalParentData&ContainerParentDataMixin&KeepAliveParentDataMixin {
}

// class id: 4640, size: 0x8, field offset: 0x8
abstract class RenderSliverWithKeepAliveMixin extends Object
    implements RenderSliver {
}

// class id: 4696, size: 0x64, field offset: 0x5c
abstract class RenderSliverMultiBoxAdaptor extends _MixinApplication22&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers&RenderSliverWithKeepAliveMixin {

  _ move(/* No info */) {
    // ** addr: 0xa19f3c, size: 0x228
    // 0xa19f3c: EnterFrame
    //     0xa19f3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa19f40: mov             fp, SP
    // 0xa19f44: AllocStack(0x30)
    //     0xa19f44: sub             SP, SP, #0x30
    // 0xa19f48: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xa19f48: mov             x5, x1
    //     0xa19f4c: mov             x4, x2
    //     0xa19f50: stur            x1, [fp, #-8]
    //     0xa19f54: stur            x2, [fp, #-0x10]
    //     0xa19f58: stur            x3, [fp, #-0x18]
    // 0xa19f5c: CheckStackOverflow
    //     0xa19f5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa19f60: cmp             SP, x16
    //     0xa19f64: b.ls            #0xa1a154
    // 0xa19f68: mov             x0, x4
    // 0xa19f6c: r2 = Null
    //     0xa19f6c: mov             x2, NULL
    // 0xa19f70: r1 = Null
    //     0xa19f70: mov             x1, NULL
    // 0xa19f74: r4 = 60
    //     0xa19f74: mov             x4, #0x3c
    // 0xa19f78: branchIfSmi(r0, 0xa19f84)
    //     0xa19f78: tbz             w0, #0, #0xa19f84
    // 0xa19f7c: r4 = LoadClassIdInstr(r0)
    //     0xa19f7c: ldur            x4, [x0, #-1]
    //     0xa19f80: ubfx            x4, x4, #0xc, #0x14
    // 0xa19f84: r17 = -4710
    //     0xa19f84: mov             x17, #-0x1266
    // 0xa19f88: add             x4, x4, x17
    // 0xa19f8c: cmp             x4, #0x109
    // 0xa19f90: b.ls            #0xa19fa4
    // 0xa19f94: r8 = RenderBox
    //     0xa19f94: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xa19f98: r3 = Null
    //     0xa19f98: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a060] Null
    //     0xa19f9c: ldr             x3, [x3, #0x60]
    // 0xa19fa0: r0 = RenderBox()
    //     0xa19fa0: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xa19fa4: ldur            x0, [fp, #-0x18]
    // 0xa19fa8: r2 = Null
    //     0xa19fa8: mov             x2, NULL
    // 0xa19fac: r1 = Null
    //     0xa19fac: mov             x1, NULL
    // 0xa19fb0: r4 = 60
    //     0xa19fb0: mov             x4, #0x3c
    // 0xa19fb4: branchIfSmi(r0, 0xa19fc0)
    //     0xa19fb4: tbz             w0, #0, #0xa19fc0
    // 0xa19fb8: r4 = LoadClassIdInstr(r0)
    //     0xa19fb8: ldur            x4, [x0, #-1]
    //     0xa19fbc: ubfx            x4, x4, #0xc, #0x14
    // 0xa19fc0: r17 = -4710
    //     0xa19fc0: mov             x17, #-0x1266
    // 0xa19fc4: add             x4, x4, x17
    // 0xa19fc8: cmp             x4, #0x109
    // 0xa19fcc: b.ls            #0xa19fe0
    // 0xa19fd0: r8 = RenderBox?
    //     0xa19fd0: ldr             x8, [PP, #0x47c8]  ; [pp+0x47c8] Type: RenderBox?
    // 0xa19fd4: r3 = Null
    //     0xa19fd4: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a070] Null
    //     0xa19fd8: ldr             x3, [x3, #0x70]
    // 0xa19fdc: r0 = RenderBox?()
    //     0xa19fdc: bl              #0x870a94  ; IsType_RenderBox?_Stub
    // 0xa19fe0: ldur            x3, [fp, #-0x10]
    // 0xa19fe4: LoadField: r4 = r3->field_7
    //     0xa19fe4: ldur            w4, [x3, #7]
    // 0xa19fe8: DecompressPointer r4
    //     0xa19fe8: add             x4, x4, HEAP, lsl #32
    // 0xa19fec: stur            x4, [fp, #-0x20]
    // 0xa19ff0: cmp             w4, NULL
    // 0xa19ff4: b.eq            #0xa1a15c
    // 0xa19ff8: mov             x0, x4
    // 0xa19ffc: r2 = Null
    //     0xa19ffc: mov             x2, NULL
    // 0xa1a000: r1 = Null
    //     0xa1a000: mov             x1, NULL
    // 0xa1a004: r4 = LoadClassIdInstr(r0)
    //     0xa1a004: ldur            x4, [x0, #-1]
    //     0xa1a008: ubfx            x4, x4, #0xc, #0x14
    // 0xa1a00c: r17 = -4183
    //     0xa1a00c: mov             x17, #-0x1057
    // 0xa1a010: add             x4, x4, x17
    // 0xa1a014: cmp             x4, #1
    // 0xa1a018: b.ls            #0xa1a030
    // 0xa1a01c: r8 = SliverMultiBoxAdaptorParentData
    //     0xa1a01c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xa1a020: ldr             x8, [x8, #0x590]
    // 0xa1a024: r3 = Null
    //     0xa1a024: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a080] Null
    //     0xa1a028: ldr             x3, [x3, #0x80]
    // 0xa1a02c: r0 = DefaultTypeTest()
    //     0xa1a02c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xa1a030: ldur            x0, [fp, #-0x20]
    // 0xa1a034: LoadField: r1 = r0->field_1b
    //     0xa1a034: ldur            w1, [x0, #0x1b]
    // 0xa1a038: DecompressPointer r1
    //     0xa1a038: add             x1, x1, HEAP, lsl #32
    // 0xa1a03c: tbz             w1, #4, #0xa1a084
    // 0xa1a040: ldur            x0, [fp, #-8]
    // 0xa1a044: mov             x1, x0
    // 0xa1a048: ldur            x2, [fp, #-0x10]
    // 0xa1a04c: ldur            x3, [fp, #-0x18]
    // 0xa1a050: r0 = move()
    //     0xa1a050: bl              #0xa1a164  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::move
    // 0xa1a054: ldur            x3, [fp, #-8]
    // 0xa1a058: LoadField: r1 = r3->field_5b
    //     0xa1a058: ldur            w1, [x3, #0x5b]
    // 0xa1a05c: DecompressPointer r1
    //     0xa1a05c: add             x1, x1, HEAP, lsl #32
    // 0xa1a060: r0 = LoadClassIdInstr(r1)
    //     0xa1a060: ldur            x0, [x1, #-1]
    //     0xa1a064: ubfx            x0, x0, #0xc, #0x14
    // 0xa1a068: ldur            x2, [fp, #-0x10]
    // 0xa1a06c: r0 = GDT[cid_x0 + -0xb86]()
    //     0xa1a06c: sub             lr, x0, #0xb86
    //     0xa1a070: ldr             lr, [x21, lr, lsl #3]
    //     0xa1a074: blr             lr
    // 0xa1a078: ldur            x1, [fp, #-8]
    // 0xa1a07c: r0 = markNeedsLayout()
    //     0xa1a07c: bl              #0xbfb800  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0xa1a080: b               #0xa1a144
    // 0xa1a084: ldur            x3, [fp, #-8]
    // 0xa1a088: LoadField: r4 = r3->field_5f
    //     0xa1a088: ldur            w4, [x3, #0x5f]
    // 0xa1a08c: DecompressPointer r4
    //     0xa1a08c: add             x4, x4, HEAP, lsl #32
    // 0xa1a090: stur            x4, [fp, #-0x18]
    // 0xa1a094: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xa1a094: ldur            w2, [x0, #0x17]
    // 0xa1a098: DecompressPointer r2
    //     0xa1a098: add             x2, x2, HEAP, lsl #32
    // 0xa1a09c: mov             x1, x4
    // 0xa1a0a0: r0 = _getValueOrData()
    //     0xa1a0a0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xa1a0a4: ldur            x1, [fp, #-0x18]
    // 0xa1a0a8: LoadField: r2 = r1->field_f
    //     0xa1a0a8: ldur            w2, [x1, #0xf]
    // 0xa1a0ac: DecompressPointer r2
    //     0xa1a0ac: add             x2, x2, HEAP, lsl #32
    // 0xa1a0b0: cmp             w2, w0
    // 0xa1a0b4: b.ne            #0xa1a0bc
    // 0xa1a0b8: r0 = Null
    //     0xa1a0b8: mov             x0, NULL
    // 0xa1a0bc: r2 = 60
    //     0xa1a0bc: mov             x2, #0x3c
    // 0xa1a0c0: branchIfSmi(r0, 0xa1a0cc)
    //     0xa1a0c0: tbz             w0, #0, #0xa1a0cc
    // 0xa1a0c4: r2 = LoadClassIdInstr(r0)
    //     0xa1a0c4: ldur            x2, [x0, #-1]
    //     0xa1a0c8: ubfx            x2, x2, #0xc, #0x14
    // 0xa1a0cc: ldur            x16, [fp, #-0x10]
    // 0xa1a0d0: stp             x16, x0, [SP]
    // 0xa1a0d4: mov             x0, x2
    // 0xa1a0d8: mov             lr, x0
    // 0xa1a0dc: ldr             lr, [x21, lr, lsl #3]
    // 0xa1a0e0: blr             lr
    // 0xa1a0e4: tbnz            w0, #4, #0xa1a0fc
    // 0xa1a0e8: ldur            x0, [fp, #-0x20]
    // 0xa1a0ec: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xa1a0ec: ldur            w2, [x0, #0x17]
    // 0xa1a0f0: DecompressPointer r2
    //     0xa1a0f0: add             x2, x2, HEAP, lsl #32
    // 0xa1a0f4: ldur            x1, [fp, #-0x18]
    // 0xa1a0f8: r0 = remove()
    //     0xa1a0f8: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xa1a0fc: ldur            x0, [fp, #-8]
    // 0xa1a100: ldur            x3, [fp, #-0x20]
    // 0xa1a104: LoadField: r1 = r0->field_5b
    //     0xa1a104: ldur            w1, [x0, #0x5b]
    // 0xa1a108: DecompressPointer r1
    //     0xa1a108: add             x1, x1, HEAP, lsl #32
    // 0xa1a10c: r0 = LoadClassIdInstr(r1)
    //     0xa1a10c: ldur            x0, [x1, #-1]
    //     0xa1a110: ubfx            x0, x0, #0xc, #0x14
    // 0xa1a114: ldur            x2, [fp, #-0x10]
    // 0xa1a118: r0 = GDT[cid_x0 + -0xb86]()
    //     0xa1a118: sub             lr, x0, #0xb86
    //     0xa1a11c: ldr             lr, [x21, lr, lsl #3]
    //     0xa1a120: blr             lr
    // 0xa1a124: ldur            x0, [fp, #-0x20]
    // 0xa1a128: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xa1a128: ldur            w2, [x0, #0x17]
    // 0xa1a12c: DecompressPointer r2
    //     0xa1a12c: add             x2, x2, HEAP, lsl #32
    // 0xa1a130: cmp             w2, NULL
    // 0xa1a134: b.eq            #0xa1a160
    // 0xa1a138: ldur            x1, [fp, #-0x18]
    // 0xa1a13c: ldur            x3, [fp, #-0x10]
    // 0xa1a140: r0 = []=()
    //     0xa1a140: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xa1a144: r0 = Null
    //     0xa1a144: mov             x0, NULL
    // 0xa1a148: LeaveFrame
    //     0xa1a148: mov             SP, fp
    //     0xa1a14c: ldp             fp, lr, [SP], #0x10
    // 0xa1a150: ret
    //     0xa1a150: ret             
    // 0xa1a154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa1a154: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1a158: b               #0xa19f68
    // 0xa1a15c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa1a15c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa1a160: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa1a160: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0xa1b578, size: 0x120
    // 0xa1b578: EnterFrame
    //     0xa1b578: stp             fp, lr, [SP, #-0x10]!
    //     0xa1b57c: mov             fp, SP
    // 0xa1b580: AllocStack(0x18)
    //     0xa1b580: sub             SP, SP, #0x18
    // 0xa1b584: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xa1b584: mov             x4, x1
    //     0xa1b588: mov             x3, x2
    //     0xa1b58c: stur            x1, [fp, #-8]
    //     0xa1b590: stur            x2, [fp, #-0x10]
    // 0xa1b594: CheckStackOverflow
    //     0xa1b594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xa1b598: cmp             SP, x16
    //     0xa1b59c: b.ls            #0xa1b68c
    // 0xa1b5a0: mov             x0, x3
    // 0xa1b5a4: r2 = Null
    //     0xa1b5a4: mov             x2, NULL
    // 0xa1b5a8: r1 = Null
    //     0xa1b5a8: mov             x1, NULL
    // 0xa1b5ac: r4 = 60
    //     0xa1b5ac: mov             x4, #0x3c
    // 0xa1b5b0: branchIfSmi(r0, 0xa1b5bc)
    //     0xa1b5b0: tbz             w0, #0, #0xa1b5bc
    // 0xa1b5b4: r4 = LoadClassIdInstr(r0)
    //     0xa1b5b4: ldur            x4, [x0, #-1]
    //     0xa1b5b8: ubfx            x4, x4, #0xc, #0x14
    // 0xa1b5bc: r17 = -4710
    //     0xa1b5bc: mov             x17, #-0x1266
    // 0xa1b5c0: add             x4, x4, x17
    // 0xa1b5c4: cmp             x4, #0x109
    // 0xa1b5c8: b.ls            #0xa1b5dc
    // 0xa1b5cc: r8 = RenderBox
    //     0xa1b5cc: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xa1b5d0: r3 = Null
    //     0xa1b5d0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a040] Null
    //     0xa1b5d4: ldr             x3, [x3, #0x40]
    // 0xa1b5d8: r0 = RenderBox()
    //     0xa1b5d8: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xa1b5dc: ldur            x3, [fp, #-0x10]
    // 0xa1b5e0: LoadField: r4 = r3->field_7
    //     0xa1b5e0: ldur            w4, [x3, #7]
    // 0xa1b5e4: DecompressPointer r4
    //     0xa1b5e4: add             x4, x4, HEAP, lsl #32
    // 0xa1b5e8: stur            x4, [fp, #-0x18]
    // 0xa1b5ec: cmp             w4, NULL
    // 0xa1b5f0: b.eq            #0xa1b694
    // 0xa1b5f4: mov             x0, x4
    // 0xa1b5f8: r2 = Null
    //     0xa1b5f8: mov             x2, NULL
    // 0xa1b5fc: r1 = Null
    //     0xa1b5fc: mov             x1, NULL
    // 0xa1b600: r4 = LoadClassIdInstr(r0)
    //     0xa1b600: ldur            x4, [x0, #-1]
    //     0xa1b604: ubfx            x4, x4, #0xc, #0x14
    // 0xa1b608: r17 = -4183
    //     0xa1b608: mov             x17, #-0x1057
    // 0xa1b60c: add             x4, x4, x17
    // 0xa1b610: cmp             x4, #1
    // 0xa1b614: b.ls            #0xa1b62c
    // 0xa1b618: r8 = SliverMultiBoxAdaptorParentData
    //     0xa1b618: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xa1b61c: ldr             x8, [x8, #0x590]
    // 0xa1b620: r3 = Null
    //     0xa1b620: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a050] Null
    //     0xa1b624: ldr             x3, [x3, #0x50]
    // 0xa1b628: r0 = DefaultTypeTest()
    //     0xa1b628: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xa1b62c: ldur            x0, [fp, #-0x18]
    // 0xa1b630: LoadField: r1 = r0->field_1b
    //     0xa1b630: ldur            w1, [x0, #0x1b]
    // 0xa1b634: DecompressPointer r1
    //     0xa1b634: add             x1, x1, HEAP, lsl #32
    // 0xa1b638: tbz             w1, #4, #0xa1b658
    // 0xa1b63c: ldur            x1, [fp, #-8]
    // 0xa1b640: ldur            x2, [fp, #-0x10]
    // 0xa1b644: r0 = remove()
    //     0xa1b644: bl              #0xa1b698  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::remove
    // 0xa1b648: r0 = Null
    //     0xa1b648: mov             x0, NULL
    // 0xa1b64c: LeaveFrame
    //     0xa1b64c: mov             SP, fp
    //     0xa1b650: ldp             fp, lr, [SP], #0x10
    // 0xa1b654: ret
    //     0xa1b654: ret             
    // 0xa1b658: ldur            x3, [fp, #-8]
    // 0xa1b65c: LoadField: r1 = r3->field_5f
    //     0xa1b65c: ldur            w1, [x3, #0x5f]
    // 0xa1b660: DecompressPointer r1
    //     0xa1b660: add             x1, x1, HEAP, lsl #32
    // 0xa1b664: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xa1b664: ldur            w2, [x0, #0x17]
    // 0xa1b668: DecompressPointer r2
    //     0xa1b668: add             x2, x2, HEAP, lsl #32
    // 0xa1b66c: r0 = remove()
    //     0xa1b66c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xa1b670: ldur            x1, [fp, #-8]
    // 0xa1b674: ldur            x2, [fp, #-0x10]
    // 0xa1b678: r0 = dropChild()
    //     0xa1b678: bl              #0xbee868  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0xa1b67c: r0 = Null
    //     0xa1b67c: mov             x0, NULL
    // 0xa1b680: LeaveFrame
    //     0xa1b680: mov             SP, fp
    //     0xa1b684: ldp             fp, lr, [SP], #0x10
    // 0xa1b688: ret
    //     0xa1b688: ret             
    // 0xa1b68c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa1b68c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa1b690: b               #0xa1b5a0
    // 0xa1b694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa1b694: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ insert(/* No info */) {
    // ** addr: 0xae9930, size: 0xcc
    // 0xae9930: EnterFrame
    //     0xae9930: stp             fp, lr, [SP, #-0x10]!
    //     0xae9934: mov             fp, SP
    // 0xae9938: AllocStack(0x18)
    //     0xae9938: sub             SP, SP, #0x18
    // 0xae993c: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xae993c: mov             x5, x1
    //     0xae9940: mov             x4, x2
    //     0xae9944: stur            x1, [fp, #-8]
    //     0xae9948: stur            x2, [fp, #-0x10]
    //     0xae994c: stur            x3, [fp, #-0x18]
    // 0xae9950: CheckStackOverflow
    //     0xae9950: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xae9954: cmp             SP, x16
    //     0xae9958: b.ls            #0xae99f4
    // 0xae995c: mov             x0, x4
    // 0xae9960: r2 = Null
    //     0xae9960: mov             x2, NULL
    // 0xae9964: r1 = Null
    //     0xae9964: mov             x1, NULL
    // 0xae9968: r4 = 60
    //     0xae9968: mov             x4, #0x3c
    // 0xae996c: branchIfSmi(r0, 0xae9978)
    //     0xae996c: tbz             w0, #0, #0xae9978
    // 0xae9970: r4 = LoadClassIdInstr(r0)
    //     0xae9970: ldur            x4, [x0, #-1]
    //     0xae9974: ubfx            x4, x4, #0xc, #0x14
    // 0xae9978: r17 = -4710
    //     0xae9978: mov             x17, #-0x1266
    // 0xae997c: add             x4, x4, x17
    // 0xae9980: cmp             x4, #0x109
    // 0xae9984: b.ls            #0xae9998
    // 0xae9988: r8 = RenderBox
    //     0xae9988: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xae998c: r3 = Null
    //     0xae998c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a090] Null
    //     0xae9990: ldr             x3, [x3, #0x90]
    // 0xae9994: r0 = RenderBox()
    //     0xae9994: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xae9998: ldur            x0, [fp, #-0x18]
    // 0xae999c: r2 = Null
    //     0xae999c: mov             x2, NULL
    // 0xae99a0: r1 = Null
    //     0xae99a0: mov             x1, NULL
    // 0xae99a4: r4 = 60
    //     0xae99a4: mov             x4, #0x3c
    // 0xae99a8: branchIfSmi(r0, 0xae99b4)
    //     0xae99a8: tbz             w0, #0, #0xae99b4
    // 0xae99ac: r4 = LoadClassIdInstr(r0)
    //     0xae99ac: ldur            x4, [x0, #-1]
    //     0xae99b0: ubfx            x4, x4, #0xc, #0x14
    // 0xae99b4: r17 = -4710
    //     0xae99b4: mov             x17, #-0x1266
    // 0xae99b8: add             x4, x4, x17
    // 0xae99bc: cmp             x4, #0x109
    // 0xae99c0: b.ls            #0xae99d4
    // 0xae99c4: r8 = RenderBox?
    //     0xae99c4: ldr             x8, [PP, #0x47c8]  ; [pp+0x47c8] Type: RenderBox?
    // 0xae99c8: r3 = Null
    //     0xae99c8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a0a0] Null
    //     0xae99cc: ldr             x3, [x3, #0xa0]
    // 0xae99d0: r0 = RenderBox?()
    //     0xae99d0: bl              #0x870a94  ; IsType_RenderBox?_Stub
    // 0xae99d4: ldur            x1, [fp, #-8]
    // 0xae99d8: ldur            x2, [fp, #-0x10]
    // 0xae99dc: ldur            x3, [fp, #-0x18]
    // 0xae99e0: r0 = insert()
    //     0xae99e0: bl              #0xae99fc  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::insert
    // 0xae99e4: r0 = Null
    //     0xae99e4: mov             x0, NULL
    // 0xae99e8: LeaveFrame
    //     0xae99e8: mov             SP, fp
    //     0xae99ec: ldp             fp, lr, [SP], #0x10
    // 0xae99f0: ret
    //     0xae99f0: ret             
    // 0xae99f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xae99f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xae99f8: b               #0xae995c
  }
  _ insertAndLayoutChild(/* No info */) {
    // ** addr: 0xbe4bac, size: 0x264
    // 0xbe4bac: EnterFrame
    //     0xbe4bac: stp             fp, lr, [SP, #-0x10]!
    //     0xbe4bb0: mov             fp, SP
    // 0xbe4bb4: AllocStack(0x38)
    //     0xbe4bb4: sub             SP, SP, #0x38
    // 0xbe4bb8: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r6, fp-0x18 */, dynamic _ /* r2 => r5, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */, {dynamic parentUsesSize = false /* r4, fp-0x10 */})
    //     0xbe4bb8: mov             x6, x1
    //     0xbe4bbc: mov             x5, x2
    //     0xbe4bc0: stur            x1, [fp, #-0x18]
    //     0xbe4bc4: stur            x2, [fp, #-0x20]
    //     0xbe4bc8: stur            x3, [fp, #-0x28]
    //     0xbe4bcc: ldur            w0, [x4, #0x13]
    //     0xbe4bd0: ldur            w1, [x4, #0x1f]
    //     0xbe4bd4: add             x1, x1, HEAP, lsl #32
    //     0xbe4bd8: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fa8] "parentUsesSize"
    //     0xbe4bdc: ldr             x16, [x16, #0xfa8]
    //     0xbe4be0: cmp             w1, w16
    //     0xbe4be4: b.ne            #0xbe4c04
    //     0xbe4be8: ldur            w1, [x4, #0x23]
    //     0xbe4bec: add             x1, x1, HEAP, lsl #32
    //     0xbe4bf0: sub             w2, w0, w1
    //     0xbe4bf4: add             x0, fp, w2, sxtw #2
    //     0xbe4bf8: ldr             x0, [x0, #8]
    //     0xbe4bfc: mov             x4, x0
    //     0xbe4c00: b               #0xbe4c08
    //     0xbe4c04: add             x4, NULL, #0x30  ; false
    //     0xbe4c08: stur            x4, [fp, #-0x10]
    // 0xbe4c0c: CheckStackOverflow
    //     0xbe4c0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe4c10: cmp             SP, x16
    //     0xbe4c14: b.ls            #0xbe4df0
    // 0xbe4c18: cmp             w3, NULL
    // 0xbe4c1c: b.eq            #0xbe4df8
    // 0xbe4c20: LoadField: r7 = r3->field_7
    //     0xbe4c20: ldur            w7, [x3, #7]
    // 0xbe4c24: DecompressPointer r7
    //     0xbe4c24: add             x7, x7, HEAP, lsl #32
    // 0xbe4c28: stur            x7, [fp, #-8]
    // 0xbe4c2c: cmp             w7, NULL
    // 0xbe4c30: b.eq            #0xbe4dfc
    // 0xbe4c34: mov             x0, x7
    // 0xbe4c38: r2 = Null
    //     0xbe4c38: mov             x2, NULL
    // 0xbe4c3c: r1 = Null
    //     0xbe4c3c: mov             x1, NULL
    // 0xbe4c40: r4 = LoadClassIdInstr(r0)
    //     0xbe4c40: ldur            x4, [x0, #-1]
    //     0xbe4c44: ubfx            x4, x4, #0xc, #0x14
    // 0xbe4c48: r17 = -4183
    //     0xbe4c48: mov             x17, #-0x1057
    // 0xbe4c4c: add             x4, x4, x17
    // 0xbe4c50: cmp             x4, #1
    // 0xbe4c54: b.ls            #0xbe4c6c
    // 0xbe4c58: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe4c58: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe4c5c: ldr             x8, [x8, #0x590]
    // 0xbe4c60: r3 = Null
    //     0xbe4c60: add             x3, PP, #0x96, lsl #12  ; [pp+0x966f8] Null
    //     0xbe4c64: ldr             x3, [x3, #0x6f8]
    // 0xbe4c68: r0 = DefaultTypeTest()
    //     0xbe4c68: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe4c6c: ldur            x0, [fp, #-8]
    // 0xbe4c70: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe4c70: ldur            w1, [x0, #0x17]
    // 0xbe4c74: DecompressPointer r1
    //     0xbe4c74: add             x1, x1, HEAP, lsl #32
    // 0xbe4c78: cmp             w1, NULL
    // 0xbe4c7c: b.eq            #0xbe4e00
    // 0xbe4c80: r0 = LoadInt32Instr(r1)
    //     0xbe4c80: sbfx            x0, x1, #1, #0x1f
    //     0xbe4c84: tbz             w1, #0, #0xbe4c8c
    //     0xbe4c88: ldur            x0, [x1, #7]
    // 0xbe4c8c: add             x4, x0, #1
    // 0xbe4c90: ldur            x1, [fp, #-0x18]
    // 0xbe4c94: mov             x2, x4
    // 0xbe4c98: ldur            x3, [fp, #-0x28]
    // 0xbe4c9c: stur            x4, [fp, #-0x30]
    // 0xbe4ca0: r0 = _createOrObtainChild()
    //     0xbe4ca0: bl              #0xbe4e10  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_createOrObtainChild
    // 0xbe4ca4: ldur            x0, [fp, #-0x28]
    // 0xbe4ca8: LoadField: r3 = r0->field_7
    //     0xbe4ca8: ldur            w3, [x0, #7]
    // 0xbe4cac: DecompressPointer r3
    //     0xbe4cac: add             x3, x3, HEAP, lsl #32
    // 0xbe4cb0: stur            x3, [fp, #-8]
    // 0xbe4cb4: cmp             w3, NULL
    // 0xbe4cb8: b.eq            #0xbe4e04
    // 0xbe4cbc: mov             x0, x3
    // 0xbe4cc0: r2 = Null
    //     0xbe4cc0: mov             x2, NULL
    // 0xbe4cc4: r1 = Null
    //     0xbe4cc4: mov             x1, NULL
    // 0xbe4cc8: r4 = LoadClassIdInstr(r0)
    //     0xbe4cc8: ldur            x4, [x0, #-1]
    //     0xbe4ccc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe4cd0: r17 = -4183
    //     0xbe4cd0: mov             x17, #-0x1057
    // 0xbe4cd4: add             x4, x4, x17
    // 0xbe4cd8: cmp             x4, #1
    // 0xbe4cdc: b.ls            #0xbe4cf4
    // 0xbe4ce0: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe4ce0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe4ce4: ldr             x8, [x8, #0x590]
    // 0xbe4ce8: r3 = Null
    //     0xbe4ce8: add             x3, PP, #0x96, lsl #12  ; [pp+0x96708] Null
    //     0xbe4cec: ldr             x3, [x3, #0x708]
    // 0xbe4cf0: r0 = DefaultTypeTest()
    //     0xbe4cf0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe4cf4: ldur            x0, [fp, #-8]
    // 0xbe4cf8: LoadField: r3 = r0->field_f
    //     0xbe4cf8: ldur            w3, [x0, #0xf]
    // 0xbe4cfc: DecompressPointer r3
    //     0xbe4cfc: add             x3, x3, HEAP, lsl #32
    // 0xbe4d00: stur            x3, [fp, #-0x28]
    // 0xbe4d04: cmp             w3, NULL
    // 0xbe4d08: b.eq            #0xbe4dcc
    // 0xbe4d0c: ldur            x4, [fp, #-0x30]
    // 0xbe4d10: LoadField: r5 = r3->field_7
    //     0xbe4d10: ldur            w5, [x3, #7]
    // 0xbe4d14: DecompressPointer r5
    //     0xbe4d14: add             x5, x5, HEAP, lsl #32
    // 0xbe4d18: stur            x5, [fp, #-8]
    // 0xbe4d1c: cmp             w5, NULL
    // 0xbe4d20: b.eq            #0xbe4e08
    // 0xbe4d24: mov             x0, x5
    // 0xbe4d28: r2 = Null
    //     0xbe4d28: mov             x2, NULL
    // 0xbe4d2c: r1 = Null
    //     0xbe4d2c: mov             x1, NULL
    // 0xbe4d30: r4 = LoadClassIdInstr(r0)
    //     0xbe4d30: ldur            x4, [x0, #-1]
    //     0xbe4d34: ubfx            x4, x4, #0xc, #0x14
    // 0xbe4d38: r17 = -4183
    //     0xbe4d38: mov             x17, #-0x1057
    // 0xbe4d3c: add             x4, x4, x17
    // 0xbe4d40: cmp             x4, #1
    // 0xbe4d44: b.ls            #0xbe4d5c
    // 0xbe4d48: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe4d48: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe4d4c: ldr             x8, [x8, #0x590]
    // 0xbe4d50: r3 = Null
    //     0xbe4d50: add             x3, PP, #0x96, lsl #12  ; [pp+0x96718] Null
    //     0xbe4d54: ldr             x3, [x3, #0x718]
    // 0xbe4d58: r0 = DefaultTypeTest()
    //     0xbe4d58: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe4d5c: ldur            x0, [fp, #-8]
    // 0xbe4d60: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe4d60: ldur            w1, [x0, #0x17]
    // 0xbe4d64: DecompressPointer r1
    //     0xbe4d64: add             x1, x1, HEAP, lsl #32
    // 0xbe4d68: cmp             w1, NULL
    // 0xbe4d6c: b.eq            #0xbe4e0c
    // 0xbe4d70: r0 = LoadInt32Instr(r1)
    //     0xbe4d70: sbfx            x0, x1, #1, #0x1f
    //     0xbe4d74: tbz             w1, #0, #0xbe4d7c
    //     0xbe4d78: ldur            x0, [x1, #7]
    // 0xbe4d7c: ldur            x1, [fp, #-0x30]
    // 0xbe4d80: cmp             x0, x1
    // 0xbe4d84: b.ne            #0xbe4dcc
    // 0xbe4d88: ldur            x3, [fp, #-0x28]
    // 0xbe4d8c: r0 = LoadClassIdInstr(r3)
    //     0xbe4d8c: ldur            x0, [x3, #-1]
    //     0xbe4d90: ubfx            x0, x0, #0xc, #0x14
    // 0xbe4d94: ldur            x16, [fp, #-0x10]
    // 0xbe4d98: str             x16, [SP]
    // 0xbe4d9c: mov             x1, x3
    // 0xbe4da0: ldur            x2, [fp, #-0x20]
    // 0xbe4da4: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbe4da4: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbe4da8: ldr             x4, [x4, #0xed0]
    // 0xbe4dac: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe4dac: mov             x17, #0xe6b9
    //     0xbe4db0: add             lr, x0, x17
    //     0xbe4db4: ldr             lr, [x21, lr, lsl #3]
    //     0xbe4db8: blr             lr
    // 0xbe4dbc: ldur            x0, [fp, #-0x28]
    // 0xbe4dc0: LeaveFrame
    //     0xbe4dc0: mov             SP, fp
    //     0xbe4dc4: ldp             fp, lr, [SP], #0x10
    // 0xbe4dc8: ret
    //     0xbe4dc8: ret             
    // 0xbe4dcc: ldur            x1, [fp, #-0x18]
    // 0xbe4dd0: r2 = true
    //     0xbe4dd0: add             x2, NULL, #0x20  ; true
    // 0xbe4dd4: LoadField: r3 = r1->field_5b
    //     0xbe4dd4: ldur            w3, [x1, #0x5b]
    // 0xbe4dd8: DecompressPointer r3
    //     0xbe4dd8: add             x3, x3, HEAP, lsl #32
    // 0xbe4ddc: StoreField: r3->field_53 = r2
    //     0xbe4ddc: stur            w2, [x3, #0x53]
    // 0xbe4de0: r0 = Null
    //     0xbe4de0: mov             x0, NULL
    // 0xbe4de4: LeaveFrame
    //     0xbe4de4: mov             SP, fp
    //     0xbe4de8: ldp             fp, lr, [SP], #0x10
    // 0xbe4dec: ret
    //     0xbe4dec: ret             
    // 0xbe4df0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe4df0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe4df4: b               #0xbe4c18
    // 0xbe4df8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4df8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4dfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4dfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4e00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4e00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4e04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4e04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4e08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4e08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4e0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createOrObtainChild(/* No info */) {
    // ** addr: 0xbe4e10, size: 0x9c
    // 0xbe4e10: EnterFrame
    //     0xbe4e10: stp             fp, lr, [SP, #-0x10]!
    //     0xbe4e14: mov             fp, SP
    // 0xbe4e18: AllocStack(0x30)
    //     0xbe4e18: sub             SP, SP, #0x30
    // 0xbe4e1c: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xbe4e1c: stur            x1, [fp, #-8]
    //     0xbe4e20: stur            x2, [fp, #-0x10]
    //     0xbe4e24: stur            x3, [fp, #-0x18]
    // 0xbe4e28: CheckStackOverflow
    //     0xbe4e28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe4e2c: cmp             SP, x16
    //     0xbe4e30: b.ls            #0xbe4ea4
    // 0xbe4e34: r1 = 3
    //     0xbe4e34: mov             x1, #3
    // 0xbe4e38: r0 = AllocateContext()
    //     0xbe4e38: bl              #0x13de838  ; AllocateContextStub
    // 0xbe4e3c: mov             x2, x0
    // 0xbe4e40: ldur            x3, [fp, #-8]
    // 0xbe4e44: StoreField: r2->field_f = r3
    //     0xbe4e44: stur            w3, [x2, #0xf]
    // 0xbe4e48: ldur            x4, [fp, #-0x10]
    // 0xbe4e4c: r0 = BoxInt64Instr(r4)
    //     0xbe4e4c: sbfiz           x0, x4, #1, #0x1f
    //     0xbe4e50: cmp             x4, x0, asr #1
    //     0xbe4e54: b.eq            #0xbe4e60
    //     0xbe4e58: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe4e5c: stur            x4, [x0, #7]
    // 0xbe4e60: StoreField: r2->field_13 = r0
    //     0xbe4e60: stur            w0, [x2, #0x13]
    // 0xbe4e64: ldur            x0, [fp, #-0x18]
    // 0xbe4e68: ArrayStore: r2[0] = r0  ; List_4
    //     0xbe4e68: stur            w0, [x2, #0x17]
    // 0xbe4e6c: r1 = Function '<anonymous closure>':.
    //     0xbe4e6c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96728] AnonymousClosure: (0xbe4eac), in [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_createOrObtainChild (0xbe4e10)
    //     0xbe4e70: ldr             x1, [x1, #0x728]
    // 0xbe4e74: r0 = AllocateClosure()
    //     0xbe4e74: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbe4e78: r16 = <SliverConstraints>
    //     0xbe4e78: add             x16, PP, #0x96, lsl #12  ; [pp+0x96730] TypeArguments: <SliverConstraints>
    //     0xbe4e7c: ldr             x16, [x16, #0x730]
    // 0xbe4e80: ldur            lr, [fp, #-8]
    // 0xbe4e84: stp             lr, x16, [SP, #8]
    // 0xbe4e88: str             x0, [SP]
    // 0xbe4e8c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbe4e8c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbe4e90: r0 = invokeLayoutCallback()
    //     0xbe4e90: bl              #0xbb849c  ; [package:flutter/src/rendering/object.dart] RenderObject::invokeLayoutCallback
    // 0xbe4e94: r0 = Null
    //     0xbe4e94: mov             x0, NULL
    // 0xbe4e98: LeaveFrame
    //     0xbe4e98: mov             SP, fp
    //     0xbe4e9c: ldp             fp, lr, [SP], #0x10
    // 0xbe4ea0: ret
    //     0xbe4ea0: ret             
    // 0xbe4ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe4ea4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe4ea8: b               #0xbe4e34
  }
  [closure] void <anonymous closure>(dynamic, SliverConstraints) {
    // ** addr: 0xbe4eac, size: 0x18c
    // 0xbe4eac: EnterFrame
    //     0xbe4eac: stp             fp, lr, [SP, #-0x10]!
    //     0xbe4eb0: mov             fp, SP
    // 0xbe4eb4: AllocStack(0x18)
    //     0xbe4eb4: sub             SP, SP, #0x18
    // 0xbe4eb8: SetupParameters([dynamic _ /* r0 */])
    //     0xbe4eb8: ldr             x0, [fp, #0x18]
    //     0xbe4ebc: ldur            w3, [x0, #0x17]
    //     0xbe4ec0: add             x3, x3, HEAP, lsl #32
    //     0xbe4ec4: stur            x3, [fp, #-8]
    // 0xbe4ec8: CheckStackOverflow
    //     0xbe4ec8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe4ecc: cmp             SP, x16
    //     0xbe4ed0: b.ls            #0xbe5028
    // 0xbe4ed4: LoadField: r0 = r3->field_f
    //     0xbe4ed4: ldur            w0, [x3, #0xf]
    // 0xbe4ed8: DecompressPointer r0
    //     0xbe4ed8: add             x0, x0, HEAP, lsl #32
    // 0xbe4edc: LoadField: r1 = r0->field_5f
    //     0xbe4edc: ldur            w1, [x0, #0x5f]
    // 0xbe4ee0: DecompressPointer r1
    //     0xbe4ee0: add             x1, x1, HEAP, lsl #32
    // 0xbe4ee4: LoadField: r2 = r3->field_13
    //     0xbe4ee4: ldur            w2, [x3, #0x13]
    // 0xbe4ee8: DecompressPointer r2
    //     0xbe4ee8: add             x2, x2, HEAP, lsl #32
    // 0xbe4eec: r0 = containsKey()
    //     0xbe4eec: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xbe4ef0: tbnz            w0, #4, #0xbe4fdc
    // 0xbe4ef4: ldur            x0, [fp, #-8]
    // 0xbe4ef8: LoadField: r1 = r0->field_f
    //     0xbe4ef8: ldur            w1, [x0, #0xf]
    // 0xbe4efc: DecompressPointer r1
    //     0xbe4efc: add             x1, x1, HEAP, lsl #32
    // 0xbe4f00: LoadField: r2 = r1->field_5f
    //     0xbe4f00: ldur            w2, [x1, #0x5f]
    // 0xbe4f04: DecompressPointer r2
    //     0xbe4f04: add             x2, x2, HEAP, lsl #32
    // 0xbe4f08: LoadField: r1 = r0->field_13
    //     0xbe4f08: ldur            w1, [x0, #0x13]
    // 0xbe4f0c: DecompressPointer r1
    //     0xbe4f0c: add             x1, x1, HEAP, lsl #32
    // 0xbe4f10: mov             x16, x1
    // 0xbe4f14: mov             x1, x2
    // 0xbe4f18: mov             x2, x16
    // 0xbe4f1c: r0 = remove()
    //     0xbe4f1c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xbe4f20: mov             x3, x0
    // 0xbe4f24: stur            x3, [fp, #-0x18]
    // 0xbe4f28: cmp             w3, NULL
    // 0xbe4f2c: b.eq            #0xbe5030
    // 0xbe4f30: LoadField: r4 = r3->field_7
    //     0xbe4f30: ldur            w4, [x3, #7]
    // 0xbe4f34: DecompressPointer r4
    //     0xbe4f34: add             x4, x4, HEAP, lsl #32
    // 0xbe4f38: stur            x4, [fp, #-0x10]
    // 0xbe4f3c: cmp             w4, NULL
    // 0xbe4f40: b.eq            #0xbe5034
    // 0xbe4f44: mov             x0, x4
    // 0xbe4f48: r2 = Null
    //     0xbe4f48: mov             x2, NULL
    // 0xbe4f4c: r1 = Null
    //     0xbe4f4c: mov             x1, NULL
    // 0xbe4f50: r4 = LoadClassIdInstr(r0)
    //     0xbe4f50: ldur            x4, [x0, #-1]
    //     0xbe4f54: ubfx            x4, x4, #0xc, #0x14
    // 0xbe4f58: r17 = -4183
    //     0xbe4f58: mov             x17, #-0x1057
    // 0xbe4f5c: add             x4, x4, x17
    // 0xbe4f60: cmp             x4, #1
    // 0xbe4f64: b.ls            #0xbe4f7c
    // 0xbe4f68: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe4f68: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe4f6c: ldr             x8, [x8, #0x590]
    // 0xbe4f70: r3 = Null
    //     0xbe4f70: add             x3, PP, #0x96, lsl #12  ; [pp+0x96738] Null
    //     0xbe4f74: ldr             x3, [x3, #0x738]
    // 0xbe4f78: r0 = DefaultTypeTest()
    //     0xbe4f78: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe4f7c: ldur            x0, [fp, #-8]
    // 0xbe4f80: LoadField: r1 = r0->field_f
    //     0xbe4f80: ldur            w1, [x0, #0xf]
    // 0xbe4f84: DecompressPointer r1
    //     0xbe4f84: add             x1, x1, HEAP, lsl #32
    // 0xbe4f88: ldur            x2, [fp, #-0x18]
    // 0xbe4f8c: r0 = dropChild()
    //     0xbe4f8c: bl              #0xbee868  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0xbe4f90: ldur            x0, [fp, #-0x10]
    // 0xbe4f94: ldur            x2, [fp, #-0x18]
    // 0xbe4f98: StoreField: r2->field_7 = r0
    //     0xbe4f98: stur            w0, [x2, #7]
    //     0xbe4f9c: ldurb           w16, [x2, #-1]
    //     0xbe4fa0: ldurb           w17, [x0, #-1]
    //     0xbe4fa4: and             x16, x17, x16, lsr #2
    //     0xbe4fa8: tst             x16, HEAP, lsr #32
    //     0xbe4fac: b.eq            #0xbe4fb4
    //     0xbe4fb0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbe4fb4: ldur            x0, [fp, #-8]
    // 0xbe4fb8: LoadField: r1 = r0->field_f
    //     0xbe4fb8: ldur            w1, [x0, #0xf]
    // 0xbe4fbc: DecompressPointer r1
    //     0xbe4fbc: add             x1, x1, HEAP, lsl #32
    // 0xbe4fc0: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xbe4fc0: ldur            w3, [x0, #0x17]
    // 0xbe4fc4: DecompressPointer r3
    //     0xbe4fc4: add             x3, x3, HEAP, lsl #32
    // 0xbe4fc8: r0 = insert()
    //     0xbe4fc8: bl              #0xae99fc  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::insert
    // 0xbe4fcc: ldur            x0, [fp, #-0x10]
    // 0xbe4fd0: r1 = false
    //     0xbe4fd0: add             x1, NULL, #0x30  ; false
    // 0xbe4fd4: StoreField: r0->field_1b = r1
    //     0xbe4fd4: stur            w1, [x0, #0x1b]
    // 0xbe4fd8: b               #0xbe5018
    // 0xbe4fdc: ldur            x0, [fp, #-8]
    // 0xbe4fe0: LoadField: r1 = r0->field_f
    //     0xbe4fe0: ldur            w1, [x0, #0xf]
    // 0xbe4fe4: DecompressPointer r1
    //     0xbe4fe4: add             x1, x1, HEAP, lsl #32
    // 0xbe4fe8: LoadField: r2 = r1->field_5b
    //     0xbe4fe8: ldur            w2, [x1, #0x5b]
    // 0xbe4fec: DecompressPointer r2
    //     0xbe4fec: add             x2, x2, HEAP, lsl #32
    // 0xbe4ff0: LoadField: r1 = r0->field_13
    //     0xbe4ff0: ldur            w1, [x0, #0x13]
    // 0xbe4ff4: DecompressPointer r1
    //     0xbe4ff4: add             x1, x1, HEAP, lsl #32
    // 0xbe4ff8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xbe4ff8: ldur            w3, [x0, #0x17]
    // 0xbe4ffc: DecompressPointer r3
    //     0xbe4ffc: add             x3, x3, HEAP, lsl #32
    // 0xbe5000: r0 = LoadInt32Instr(r1)
    //     0xbe5000: sbfx            x0, x1, #1, #0x1f
    //     0xbe5004: tbz             w1, #0, #0xbe500c
    //     0xbe5008: ldur            x0, [x1, #7]
    // 0xbe500c: mov             x1, x2
    // 0xbe5010: mov             x2, x0
    // 0xbe5014: r0 = createChild()
    //     0xbe5014: bl              #0xbe5038  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::createChild
    // 0xbe5018: r0 = Null
    //     0xbe5018: mov             x0, NULL
    // 0xbe501c: LeaveFrame
    //     0xbe501c: mov             SP, fp
    //     0xbe5020: ldp             fp, lr, [SP], #0x10
    // 0xbe5024: ret
    //     0xbe5024: ret             
    // 0xbe5028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe5028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe502c: b               #0xbe4ed4
    // 0xbe5030: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5030: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe5034: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5034: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ insertAndLayoutLeadingChild(/* No info */) {
    // ** addr: 0xbe5694, size: 0x21c
    // 0xbe5694: EnterFrame
    //     0xbe5694: stp             fp, lr, [SP, #-0x10]!
    //     0xbe5698: mov             fp, SP
    // 0xbe569c: AllocStack(0x38)
    //     0xbe569c: sub             SP, SP, #0x38
    // 0xbe56a0: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r5, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */, {dynamic parentUsesSize = false /* r4, fp-0x10 */})
    //     0xbe56a0: mov             x5, x1
    //     0xbe56a4: mov             x3, x2
    //     0xbe56a8: stur            x1, [fp, #-0x18]
    //     0xbe56ac: stur            x2, [fp, #-0x20]
    //     0xbe56b0: ldur            w0, [x4, #0x13]
    //     0xbe56b4: ldur            w1, [x4, #0x1f]
    //     0xbe56b8: add             x1, x1, HEAP, lsl #32
    //     0xbe56bc: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fa8] "parentUsesSize"
    //     0xbe56c0: ldr             x16, [x16, #0xfa8]
    //     0xbe56c4: cmp             w1, w16
    //     0xbe56c8: b.ne            #0xbe56e8
    //     0xbe56cc: ldur            w1, [x4, #0x23]
    //     0xbe56d0: add             x1, x1, HEAP, lsl #32
    //     0xbe56d4: sub             w2, w0, w1
    //     0xbe56d8: add             x0, fp, w2, sxtw #2
    //     0xbe56dc: ldr             x0, [x0, #8]
    //     0xbe56e0: mov             x4, x0
    //     0xbe56e4: b               #0xbe56ec
    //     0xbe56e8: add             x4, NULL, #0x30  ; false
    //     0xbe56ec: stur            x4, [fp, #-0x10]
    // 0xbe56f0: CheckStackOverflow
    //     0xbe56f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe56f4: cmp             SP, x16
    //     0xbe56f8: b.ls            #0xbe5890
    // 0xbe56fc: LoadField: r0 = r5->field_53
    //     0xbe56fc: ldur            w0, [x5, #0x53]
    // 0xbe5700: DecompressPointer r0
    //     0xbe5700: add             x0, x0, HEAP, lsl #32
    // 0xbe5704: cmp             w0, NULL
    // 0xbe5708: b.eq            #0xbe5898
    // 0xbe570c: LoadField: r6 = r0->field_7
    //     0xbe570c: ldur            w6, [x0, #7]
    // 0xbe5710: DecompressPointer r6
    //     0xbe5710: add             x6, x6, HEAP, lsl #32
    // 0xbe5714: stur            x6, [fp, #-8]
    // 0xbe5718: cmp             w6, NULL
    // 0xbe571c: b.eq            #0xbe589c
    // 0xbe5720: mov             x0, x6
    // 0xbe5724: r2 = Null
    //     0xbe5724: mov             x2, NULL
    // 0xbe5728: r1 = Null
    //     0xbe5728: mov             x1, NULL
    // 0xbe572c: r4 = LoadClassIdInstr(r0)
    //     0xbe572c: ldur            x4, [x0, #-1]
    //     0xbe5730: ubfx            x4, x4, #0xc, #0x14
    // 0xbe5734: r17 = -4183
    //     0xbe5734: mov             x17, #-0x1057
    // 0xbe5738: add             x4, x4, x17
    // 0xbe573c: cmp             x4, #1
    // 0xbe5740: b.ls            #0xbe5758
    // 0xbe5744: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe5744: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe5748: ldr             x8, [x8, #0x590]
    // 0xbe574c: r3 = Null
    //     0xbe574c: add             x3, PP, #0x96, lsl #12  ; [pp+0x967a8] Null
    //     0xbe5750: ldr             x3, [x3, #0x7a8]
    // 0xbe5754: r0 = DefaultTypeTest()
    //     0xbe5754: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe5758: ldur            x0, [fp, #-8]
    // 0xbe575c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe575c: ldur            w1, [x0, #0x17]
    // 0xbe5760: DecompressPointer r1
    //     0xbe5760: add             x1, x1, HEAP, lsl #32
    // 0xbe5764: cmp             w1, NULL
    // 0xbe5768: b.eq            #0xbe58a0
    // 0xbe576c: r0 = LoadInt32Instr(r1)
    //     0xbe576c: sbfx            x0, x1, #1, #0x1f
    //     0xbe5770: tbz             w1, #0, #0xbe5778
    //     0xbe5774: ldur            x0, [x1, #7]
    // 0xbe5778: sub             x4, x0, #1
    // 0xbe577c: ldur            x1, [fp, #-0x18]
    // 0xbe5780: mov             x2, x4
    // 0xbe5784: stur            x4, [fp, #-0x28]
    // 0xbe5788: r3 = Null
    //     0xbe5788: mov             x3, NULL
    // 0xbe578c: r0 = _createOrObtainChild()
    //     0xbe578c: bl              #0xbe4e10  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_createOrObtainChild
    // 0xbe5790: ldur            x3, [fp, #-0x18]
    // 0xbe5794: LoadField: r4 = r3->field_53
    //     0xbe5794: ldur            w4, [x3, #0x53]
    // 0xbe5798: DecompressPointer r4
    //     0xbe5798: add             x4, x4, HEAP, lsl #32
    // 0xbe579c: stur            x4, [fp, #-0x30]
    // 0xbe57a0: cmp             w4, NULL
    // 0xbe57a4: b.eq            #0xbe58a4
    // 0xbe57a8: LoadField: r5 = r4->field_7
    //     0xbe57a8: ldur            w5, [x4, #7]
    // 0xbe57ac: DecompressPointer r5
    //     0xbe57ac: add             x5, x5, HEAP, lsl #32
    // 0xbe57b0: stur            x5, [fp, #-8]
    // 0xbe57b4: cmp             w5, NULL
    // 0xbe57b8: b.eq            #0xbe58a8
    // 0xbe57bc: mov             x0, x5
    // 0xbe57c0: r2 = Null
    //     0xbe57c0: mov             x2, NULL
    // 0xbe57c4: r1 = Null
    //     0xbe57c4: mov             x1, NULL
    // 0xbe57c8: r4 = LoadClassIdInstr(r0)
    //     0xbe57c8: ldur            x4, [x0, #-1]
    //     0xbe57cc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe57d0: r17 = -4183
    //     0xbe57d0: mov             x17, #-0x1057
    // 0xbe57d4: add             x4, x4, x17
    // 0xbe57d8: cmp             x4, #1
    // 0xbe57dc: b.ls            #0xbe57f4
    // 0xbe57e0: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe57e0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe57e4: ldr             x8, [x8, #0x590]
    // 0xbe57e8: r3 = Null
    //     0xbe57e8: add             x3, PP, #0x96, lsl #12  ; [pp+0x967b8] Null
    //     0xbe57ec: ldr             x3, [x3, #0x7b8]
    // 0xbe57f0: r0 = DefaultTypeTest()
    //     0xbe57f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe57f4: ldur            x0, [fp, #-8]
    // 0xbe57f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe57f8: ldur            w1, [x0, #0x17]
    // 0xbe57fc: DecompressPointer r1
    //     0xbe57fc: add             x1, x1, HEAP, lsl #32
    // 0xbe5800: cmp             w1, NULL
    // 0xbe5804: b.eq            #0xbe58ac
    // 0xbe5808: r0 = LoadInt32Instr(r1)
    //     0xbe5808: sbfx            x0, x1, #1, #0x1f
    //     0xbe580c: tbz             w1, #0, #0xbe5814
    //     0xbe5810: ldur            x0, [x1, #7]
    // 0xbe5814: ldur            x1, [fp, #-0x28]
    // 0xbe5818: cmp             x0, x1
    // 0xbe581c: b.ne            #0xbe586c
    // 0xbe5820: ldur            x3, [fp, #-0x18]
    // 0xbe5824: ldur            x1, [fp, #-0x30]
    // 0xbe5828: r0 = LoadClassIdInstr(r1)
    //     0xbe5828: ldur            x0, [x1, #-1]
    //     0xbe582c: ubfx            x0, x0, #0xc, #0x14
    // 0xbe5830: ldur            x16, [fp, #-0x10]
    // 0xbe5834: str             x16, [SP]
    // 0xbe5838: ldur            x2, [fp, #-0x20]
    // 0xbe583c: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbe583c: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbe5840: ldr             x4, [x4, #0xed0]
    // 0xbe5844: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe5844: mov             x17, #0xe6b9
    //     0xbe5848: add             lr, x0, x17
    //     0xbe584c: ldr             lr, [x21, lr, lsl #3]
    //     0xbe5850: blr             lr
    // 0xbe5854: ldur            x1, [fp, #-0x18]
    // 0xbe5858: LoadField: r0 = r1->field_53
    //     0xbe5858: ldur            w0, [x1, #0x53]
    // 0xbe585c: DecompressPointer r0
    //     0xbe585c: add             x0, x0, HEAP, lsl #32
    // 0xbe5860: LeaveFrame
    //     0xbe5860: mov             SP, fp
    //     0xbe5864: ldp             fp, lr, [SP], #0x10
    // 0xbe5868: ret
    //     0xbe5868: ret             
    // 0xbe586c: ldur            x1, [fp, #-0x18]
    // 0xbe5870: r2 = true
    //     0xbe5870: add             x2, NULL, #0x20  ; true
    // 0xbe5874: LoadField: r3 = r1->field_5b
    //     0xbe5874: ldur            w3, [x1, #0x5b]
    // 0xbe5878: DecompressPointer r3
    //     0xbe5878: add             x3, x3, HEAP, lsl #32
    // 0xbe587c: StoreField: r3->field_53 = r2
    //     0xbe587c: stur            w2, [x3, #0x53]
    // 0xbe5880: r0 = Null
    //     0xbe5880: mov             x0, NULL
    // 0xbe5884: LeaveFrame
    //     0xbe5884: mov             SP, fp
    //     0xbe5888: ldp             fp, lr, [SP], #0x10
    // 0xbe588c: ret
    //     0xbe588c: ret             
    // 0xbe5890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe5890: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe5894: b               #0xbe56fc
    // 0xbe5898: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5898: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe589c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe589c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe58a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe58a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe58a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe58a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe58a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe58a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe58ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe58ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addInitialChild(/* No info */) {
    // ** addr: 0xbe60b8, size: 0x1d0
    // 0xbe60b8: EnterFrame
    //     0xbe60b8: stp             fp, lr, [SP, #-0x10]!
    //     0xbe60bc: mov             fp, SP
    // 0xbe60c0: AllocStack(0x18)
    //     0xbe60c0: sub             SP, SP, #0x18
    // 0xbe60c4: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r0, fp-0x8 */, {int index = 0 /* r3 */, _Double layoutOffset = 0.000000 /* d0, fp-0x18 */})
    //     0xbe60c4: mov             x0, x1
    //     0xbe60c8: stur            x1, [fp, #-8]
    //     0xbe60cc: ldur            w1, [x4, #0x13]
    //     0xbe60d0: ldur            w2, [x4, #0x1f]
    //     0xbe60d4: add             x2, x2, HEAP, lsl #32
    //     0xbe60d8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd080] "index"
    //     0xbe60dc: ldr             x16, [x16, #0x80]
    //     0xbe60e0: cmp             w2, w16
    //     0xbe60e4: b.ne            #0xbe6110
    //     0xbe60e8: ldur            w2, [x4, #0x23]
    //     0xbe60ec: add             x2, x2, HEAP, lsl #32
    //     0xbe60f0: sub             w3, w1, w2
    //     0xbe60f4: add             x2, fp, w3, sxtw #2
    //     0xbe60f8: ldr             x2, [x2, #8]
    //     0xbe60fc: sbfx            x3, x2, #1, #0x1f
    //     0xbe6100: tbz             w2, #0, #0xbe6108
    //     0xbe6104: ldur            x3, [x2, #7]
    //     0xbe6108: mov             x2, #1
    //     0xbe610c: b               #0xbe6118
    //     0xbe6110: mov             x3, #0
    //     0xbe6114: mov             x2, #0
    //     0xbe6118: lsl             x5, x2, #1
    //     0xbe611c: lsl             w2, w5, #1
    //     0xbe6120: add             w5, w2, #8
    //     0xbe6124: add             x16, x4, w5, sxtw #1
    //     0xbe6128: ldur            w6, [x16, #0xf]
    //     0xbe612c: add             x6, x6, HEAP, lsl #32
    //     0xbe6130: add             x16, PP, #0x96, lsl #12  ; [pp+0x968a0] "layoutOffset"
    //     0xbe6134: ldr             x16, [x16, #0x8a0]
    //     0xbe6138: cmp             w6, w16
    //     0xbe613c: b.ne            #0xbe6164
    //     0xbe6140: add             w5, w2, #0xa
    //     0xbe6144: add             x16, x4, w5, sxtw #1
    //     0xbe6148: ldur            w2, [x16, #0xf]
    //     0xbe614c: add             x2, x2, HEAP, lsl #32
    //     0xbe6150: sub             w4, w1, w2
    //     0xbe6154: add             x1, fp, w4, sxtw #2
    //     0xbe6158: ldr             x1, [x1, #8]
    //     0xbe615c: ldur            d0, [x1, #7]
    //     0xbe6160: b               #0xbe6168
    //     0xbe6164: eor             v0.16b, v0.16b, v0.16b
    //     0xbe6168: stur            d0, [fp, #-0x18]
    // 0xbe616c: CheckStackOverflow
    //     0xbe616c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe6170: cmp             SP, x16
    //     0xbe6174: b.ls            #0xbe626c
    // 0xbe6178: mov             x1, x0
    // 0xbe617c: mov             x2, x3
    // 0xbe6180: r3 = Null
    //     0xbe6180: mov             x3, NULL
    // 0xbe6184: r0 = _createOrObtainChild()
    //     0xbe6184: bl              #0xbe4e10  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_createOrObtainChild
    // 0xbe6188: ldur            x0, [fp, #-8]
    // 0xbe618c: LoadField: r1 = r0->field_53
    //     0xbe618c: ldur            w1, [x0, #0x53]
    // 0xbe6190: DecompressPointer r1
    //     0xbe6190: add             x1, x1, HEAP, lsl #32
    // 0xbe6194: cmp             w1, NULL
    // 0xbe6198: b.eq            #0xbe624c
    // 0xbe619c: ldur            d0, [fp, #-0x18]
    // 0xbe61a0: LoadField: r3 = r1->field_7
    //     0xbe61a0: ldur            w3, [x1, #7]
    // 0xbe61a4: DecompressPointer r3
    //     0xbe61a4: add             x3, x3, HEAP, lsl #32
    // 0xbe61a8: stur            x3, [fp, #-0x10]
    // 0xbe61ac: cmp             w3, NULL
    // 0xbe61b0: b.eq            #0xbe6274
    // 0xbe61b4: mov             x0, x3
    // 0xbe61b8: r2 = Null
    //     0xbe61b8: mov             x2, NULL
    // 0xbe61bc: r1 = Null
    //     0xbe61bc: mov             x1, NULL
    // 0xbe61c0: r4 = LoadClassIdInstr(r0)
    //     0xbe61c0: ldur            x4, [x0, #-1]
    //     0xbe61c4: ubfx            x4, x4, #0xc, #0x14
    // 0xbe61c8: r17 = -4183
    //     0xbe61c8: mov             x17, #-0x1057
    // 0xbe61cc: add             x4, x4, x17
    // 0xbe61d0: cmp             x4, #1
    // 0xbe61d4: b.ls            #0xbe61ec
    // 0xbe61d8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe61d8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe61dc: ldr             x8, [x8, #0x590]
    // 0xbe61e0: r3 = Null
    //     0xbe61e0: add             x3, PP, #0x96, lsl #12  ; [pp+0x968a8] Null
    //     0xbe61e4: ldr             x3, [x3, #0x8a8]
    // 0xbe61e8: r0 = DefaultTypeTest()
    //     0xbe61e8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe61ec: ldur            d0, [fp, #-0x18]
    // 0xbe61f0: r0 = inline_Allocate_Double()
    //     0xbe61f0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe61f4: add             x0, x0, #0x10
    //     0xbe61f8: cmp             x1, x0
    //     0xbe61fc: b.ls            #0xbe6278
    //     0xbe6200: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe6204: sub             x0, x0, #0xf
    //     0xbe6208: mov             x1, #0xe19c
    //     0xbe620c: movk            x1, #3, lsl #16
    //     0xbe6210: stur            x1, [x0, #-1]
    // 0xbe6214: dmb             ishst
    // 0xbe6218: StoreField: r0->field_7 = d0
    //     0xbe6218: stur            d0, [x0, #7]
    // 0xbe621c: ldur            x1, [fp, #-0x10]
    // 0xbe6220: StoreField: r1->field_7 = r0
    //     0xbe6220: stur            w0, [x1, #7]
    //     0xbe6224: ldurb           w16, [x1, #-1]
    //     0xbe6228: ldurb           w17, [x0, #-1]
    //     0xbe622c: and             x16, x17, x16, lsr #2
    //     0xbe6230: tst             x16, HEAP, lsr #32
    //     0xbe6234: b.eq            #0xbe623c
    //     0xbe6238: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe623c: r0 = true
    //     0xbe623c: add             x0, NULL, #0x20  ; true
    // 0xbe6240: LeaveFrame
    //     0xbe6240: mov             SP, fp
    //     0xbe6244: ldp             fp, lr, [SP], #0x10
    // 0xbe6248: ret
    //     0xbe6248: ret             
    // 0xbe624c: r1 = true
    //     0xbe624c: add             x1, NULL, #0x20  ; true
    // 0xbe6250: LoadField: r2 = r0->field_5b
    //     0xbe6250: ldur            w2, [x0, #0x5b]
    // 0xbe6254: DecompressPointer r2
    //     0xbe6254: add             x2, x2, HEAP, lsl #32
    // 0xbe6258: StoreField: r2->field_53 = r1
    //     0xbe6258: stur            w1, [x2, #0x53]
    // 0xbe625c: r0 = false
    //     0xbe625c: add             x0, NULL, #0x30  ; false
    // 0xbe6260: LeaveFrame
    //     0xbe6260: mov             SP, fp
    //     0xbe6264: ldp             fp, lr, [SP], #0x10
    // 0xbe6268: ret
    //     0xbe6268: ret             
    // 0xbe626c: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe626c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe6270: b               #0xbe6178
    // 0xbe6274: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe6274: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe6278: SaveReg d0
    //     0xbe6278: str             q0, [SP, #-0x10]!
    // 0xbe627c: r0 = AllocateDouble()
    //     0xbe627c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe6280: RestoreReg d0
    //     0xbe6280: ldr             q0, [SP], #0x10
    // 0xbe6284: b               #0xbe6218
  }
  _ collectGarbage(/* No info */) {
    // ** addr: 0xbe64f8, size: 0xb0
    // 0xbe64f8: EnterFrame
    //     0xbe64f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbe64fc: mov             fp, SP
    // 0xbe6500: AllocStack(0x30)
    //     0xbe6500: sub             SP, SP, #0x30
    // 0xbe6504: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xbe6504: stur            x1, [fp, #-8]
    //     0xbe6508: stur            x2, [fp, #-0x10]
    //     0xbe650c: stur            x3, [fp, #-0x18]
    // 0xbe6510: CheckStackOverflow
    //     0xbe6510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe6514: cmp             SP, x16
    //     0xbe6518: b.ls            #0xbe65a0
    // 0xbe651c: r1 = 3
    //     0xbe651c: mov             x1, #3
    // 0xbe6520: r0 = AllocateContext()
    //     0xbe6520: bl              #0x13de838  ; AllocateContextStub
    // 0xbe6524: mov             x2, x0
    // 0xbe6528: ldur            x3, [fp, #-8]
    // 0xbe652c: StoreField: r2->field_f = r3
    //     0xbe652c: stur            w3, [x2, #0xf]
    // 0xbe6530: ldur            x4, [fp, #-0x10]
    // 0xbe6534: r0 = BoxInt64Instr(r4)
    //     0xbe6534: sbfiz           x0, x4, #1, #0x1f
    //     0xbe6538: cmp             x4, x0, asr #1
    //     0xbe653c: b.eq            #0xbe6548
    //     0xbe6540: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe6544: stur            x4, [x0, #7]
    // 0xbe6548: StoreField: r2->field_13 = r0
    //     0xbe6548: stur            w0, [x2, #0x13]
    // 0xbe654c: ldur            x4, [fp, #-0x18]
    // 0xbe6550: r0 = BoxInt64Instr(r4)
    //     0xbe6550: sbfiz           x0, x4, #1, #0x1f
    //     0xbe6554: cmp             x4, x0, asr #1
    //     0xbe6558: b.eq            #0xbe6564
    //     0xbe655c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe6560: stur            x4, [x0, #7]
    // 0xbe6564: ArrayStore: r2[0] = r0  ; List_4
    //     0xbe6564: stur            w0, [x2, #0x17]
    // 0xbe6568: r1 = Function '<anonymous closure>':.
    //     0xbe6568: add             x1, PP, #0x96, lsl #12  ; [pp+0x967c8] AnonymousClosure: (0xbe65a8), in [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage (0xbe64f8)
    //     0xbe656c: ldr             x1, [x1, #0x7c8]
    // 0xbe6570: r0 = AllocateClosure()
    //     0xbe6570: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbe6574: r16 = <SliverConstraints>
    //     0xbe6574: add             x16, PP, #0x96, lsl #12  ; [pp+0x96730] TypeArguments: <SliverConstraints>
    //     0xbe6578: ldr             x16, [x16, #0x730]
    // 0xbe657c: ldur            lr, [fp, #-8]
    // 0xbe6580: stp             lr, x16, [SP, #8]
    // 0xbe6584: str             x0, [SP]
    // 0xbe6588: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xbe6588: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xbe658c: r0 = invokeLayoutCallback()
    //     0xbe658c: bl              #0xbb849c  ; [package:flutter/src/rendering/object.dart] RenderObject::invokeLayoutCallback
    // 0xbe6590: r0 = Null
    //     0xbe6590: mov             x0, NULL
    // 0xbe6594: LeaveFrame
    //     0xbe6594: mov             SP, fp
    //     0xbe6598: ldp             fp, lr, [SP], #0x10
    // 0xbe659c: ret
    //     0xbe659c: ret             
    // 0xbe65a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe65a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe65a4: b               #0xbe651c
  }
  [closure] void <anonymous closure>(dynamic, SliverConstraints) {
    // ** addr: 0xbe65a8, size: 0x2e4
    // 0xbe65a8: EnterFrame
    //     0xbe65a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbe65ac: mov             fp, SP
    // 0xbe65b0: AllocStack(0x30)
    //     0xbe65b0: sub             SP, SP, #0x30
    // 0xbe65b4: SetupParameters([dynamic _ /* r0 */])
    //     0xbe65b4: ldr             x0, [fp, #0x18]
    //     0xbe65b8: ldur            w3, [x0, #0x17]
    //     0xbe65bc: add             x3, x3, HEAP, lsl #32
    //     0xbe65c0: stur            x3, [fp, #-8]
    // 0xbe65c4: CheckStackOverflow
    //     0xbe65c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe65c8: cmp             SP, x16
    //     0xbe65cc: b.ls            #0xbe6860
    // 0xbe65d0: CheckStackOverflow
    //     0xbe65d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe65d4: cmp             SP, x16
    //     0xbe65d8: b.ls            #0xbe6868
    // 0xbe65dc: LoadField: r0 = r3->field_13
    //     0xbe65dc: ldur            w0, [x3, #0x13]
    // 0xbe65e0: DecompressPointer r0
    //     0xbe65e0: add             x0, x0, HEAP, lsl #32
    // 0xbe65e4: r1 = LoadInt32Instr(r0)
    //     0xbe65e4: sbfx            x1, x0, #1, #0x1f
    //     0xbe65e8: tbz             w0, #0, #0xbe65f0
    //     0xbe65ec: ldur            x1, [x0, #7]
    // 0xbe65f0: cmp             x1, #0
    // 0xbe65f4: b.le            #0xbe6668
    // 0xbe65f8: LoadField: r1 = r3->field_f
    //     0xbe65f8: ldur            w1, [x3, #0xf]
    // 0xbe65fc: DecompressPointer r1
    //     0xbe65fc: add             x1, x1, HEAP, lsl #32
    // 0xbe6600: LoadField: r2 = r1->field_53
    //     0xbe6600: ldur            w2, [x1, #0x53]
    // 0xbe6604: DecompressPointer r2
    //     0xbe6604: add             x2, x2, HEAP, lsl #32
    // 0xbe6608: cmp             w2, NULL
    // 0xbe660c: b.eq            #0xbe6870
    // 0xbe6610: r0 = _destroyOrCacheChild()
    //     0xbe6610: bl              #0xbe688c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_destroyOrCacheChild
    // 0xbe6614: ldur            x3, [fp, #-8]
    // 0xbe6618: LoadField: r0 = r3->field_13
    //     0xbe6618: ldur            w0, [x3, #0x13]
    // 0xbe661c: DecompressPointer r0
    //     0xbe661c: add             x0, x0, HEAP, lsl #32
    // 0xbe6620: r1 = LoadInt32Instr(r0)
    //     0xbe6620: sbfx            x1, x0, #1, #0x1f
    //     0xbe6624: tbz             w0, #0, #0xbe662c
    //     0xbe6628: ldur            x1, [x0, #7]
    // 0xbe662c: sub             x2, x1, #1
    // 0xbe6630: r0 = BoxInt64Instr(r2)
    //     0xbe6630: sbfiz           x0, x2, #1, #0x1f
    //     0xbe6634: cmp             x2, x0, asr #1
    //     0xbe6638: b.eq            #0xbe6644
    //     0xbe663c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe6640: stur            x2, [x0, #7]
    // 0xbe6644: StoreField: r3->field_13 = r0
    //     0xbe6644: stur            w0, [x3, #0x13]
    //     0xbe6648: tbz             w0, #0, #0xbe6664
    //     0xbe664c: ldurb           w16, [x3, #-1]
    //     0xbe6650: ldurb           w17, [x0, #-1]
    //     0xbe6654: and             x16, x17, x16, lsr #2
    //     0xbe6658: tst             x16, HEAP, lsr #32
    //     0xbe665c: b.eq            #0xbe6664
    //     0xbe6660: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe6664: b               #0xbe65d0
    // 0xbe6668: CheckStackOverflow
    //     0xbe6668: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe666c: cmp             SP, x16
    //     0xbe6670: b.ls            #0xbe6874
    // 0xbe6674: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xbe6674: ldur            w0, [x3, #0x17]
    // 0xbe6678: DecompressPointer r0
    //     0xbe6678: add             x0, x0, HEAP, lsl #32
    // 0xbe667c: r1 = LoadInt32Instr(r0)
    //     0xbe667c: sbfx            x1, x0, #1, #0x1f
    //     0xbe6680: tbz             w0, #0, #0xbe6688
    //     0xbe6684: ldur            x1, [x0, #7]
    // 0xbe6688: cmp             x1, #0
    // 0xbe668c: b.le            #0xbe6704
    // 0xbe6690: LoadField: r1 = r3->field_f
    //     0xbe6690: ldur            w1, [x3, #0xf]
    // 0xbe6694: DecompressPointer r1
    //     0xbe6694: add             x1, x1, HEAP, lsl #32
    // 0xbe6698: LoadField: r2 = r1->field_57
    //     0xbe6698: ldur            w2, [x1, #0x57]
    // 0xbe669c: DecompressPointer r2
    //     0xbe669c: add             x2, x2, HEAP, lsl #32
    // 0xbe66a0: cmp             w2, NULL
    // 0xbe66a4: b.eq            #0xbe687c
    // 0xbe66a8: r0 = _destroyOrCacheChild()
    //     0xbe66a8: bl              #0xbe688c  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::_destroyOrCacheChild
    // 0xbe66ac: ldur            x2, [fp, #-8]
    // 0xbe66b0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xbe66b0: ldur            w0, [x2, #0x17]
    // 0xbe66b4: DecompressPointer r0
    //     0xbe66b4: add             x0, x0, HEAP, lsl #32
    // 0xbe66b8: r1 = LoadInt32Instr(r0)
    //     0xbe66b8: sbfx            x1, x0, #1, #0x1f
    //     0xbe66bc: tbz             w0, #0, #0xbe66c4
    //     0xbe66c0: ldur            x1, [x0, #7]
    // 0xbe66c4: sub             x3, x1, #1
    // 0xbe66c8: r0 = BoxInt64Instr(r3)
    //     0xbe66c8: sbfiz           x0, x3, #1, #0x1f
    //     0xbe66cc: cmp             x3, x0, asr #1
    //     0xbe66d0: b.eq            #0xbe66dc
    //     0xbe66d4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe66d8: stur            x3, [x0, #7]
    // 0xbe66dc: ArrayStore: r2[0] = r0  ; List_4
    //     0xbe66dc: stur            w0, [x2, #0x17]
    //     0xbe66e0: tbz             w0, #0, #0xbe66fc
    //     0xbe66e4: ldurb           w16, [x2, #-1]
    //     0xbe66e8: ldurb           w17, [x0, #-1]
    //     0xbe66ec: and             x16, x17, x16, lsr #2
    //     0xbe66f0: tst             x16, HEAP, lsr #32
    //     0xbe66f4: b.eq            #0xbe66fc
    //     0xbe66f8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbe66fc: mov             x3, x2
    // 0xbe6700: b               #0xbe6668
    // 0xbe6704: mov             x2, x3
    // 0xbe6708: LoadField: r0 = r2->field_f
    //     0xbe6708: ldur            w0, [x2, #0xf]
    // 0xbe670c: DecompressPointer r0
    //     0xbe670c: add             x0, x0, HEAP, lsl #32
    // 0xbe6710: LoadField: r3 = r0->field_5f
    //     0xbe6710: ldur            w3, [x0, #0x5f]
    // 0xbe6714: DecompressPointer r3
    //     0xbe6714: add             x3, x3, HEAP, lsl #32
    // 0xbe6718: stur            x3, [fp, #-0x10]
    // 0xbe671c: r1 = <RenderBox>
    //     0xbe671c: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xbe6720: ldr             x1, [x1, #0x5c8]
    // 0xbe6724: r0 = _CompactValuesIterable()
    //     0xbe6724: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xbe6728: mov             x3, x0
    // 0xbe672c: ldur            x0, [fp, #-0x10]
    // 0xbe6730: stur            x3, [fp, #-0x18]
    // 0xbe6734: StoreField: r3->field_b = r0
    //     0xbe6734: stur            w0, [x3, #0xb]
    // 0xbe6738: r1 = Function '<anonymous closure>':.
    //     0xbe6738: add             x1, PP, #0x96, lsl #12  ; [pp+0x967d0] AnonymousClosure: (0xbe6cdc), in [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage (0xbe64f8)
    //     0xbe673c: ldr             x1, [x1, #0x7d0]
    // 0xbe6740: r2 = Null
    //     0xbe6740: mov             x2, NULL
    // 0xbe6744: r0 = AllocateClosure()
    //     0xbe6744: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbe6748: ldur            x1, [fp, #-0x18]
    // 0xbe674c: mov             x2, x0
    // 0xbe6750: r0 = where()
    //     0xbe6750: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xbe6754: mov             x1, x0
    // 0xbe6758: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbe6758: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbe675c: r0 = toList()
    //     0xbe675c: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0xbe6760: mov             x1, x0
    // 0xbe6764: ldur            x0, [fp, #-8]
    // 0xbe6768: stur            x1, [fp, #-0x10]
    // 0xbe676c: LoadField: r2 = r0->field_f
    //     0xbe676c: ldur            w2, [x0, #0xf]
    // 0xbe6770: DecompressPointer r2
    //     0xbe6770: add             x2, x2, HEAP, lsl #32
    // 0xbe6774: LoadField: r0 = r2->field_5b
    //     0xbe6774: ldur            w0, [x2, #0x5b]
    // 0xbe6778: DecompressPointer r0
    //     0xbe6778: add             x0, x0, HEAP, lsl #32
    // 0xbe677c: r2 = LoadClassIdInstr(r0)
    //     0xbe677c: ldur            x2, [x0, #-1]
    //     0xbe6780: ubfx            x2, x2, #0xc, #0x14
    // 0xbe6784: str             x0, [SP]
    // 0xbe6788: mov             x0, x2
    // 0xbe678c: r0 = GDT[cid_x0 + 0x728]()
    //     0xbe678c: add             lr, x0, #0x728
    //     0xbe6790: ldr             lr, [x21, lr, lsl #3]
    //     0xbe6794: blr             lr
    // 0xbe6798: mov             x3, x0
    // 0xbe679c: ldur            x2, [fp, #-0x10]
    // 0xbe67a0: stur            x3, [fp, #-0x18]
    // 0xbe67a4: LoadField: r4 = r2->field_b
    //     0xbe67a4: ldur            w4, [x2, #0xb]
    // 0xbe67a8: stur            x4, [fp, #-8]
    // 0xbe67ac: r0 = LoadInt32Instr(r4)
    //     0xbe67ac: sbfx            x0, x4, #1, #0x1f
    // 0xbe67b0: r5 = 0
    //     0xbe67b0: mov             x5, #0
    // 0xbe67b4: stur            x5, [fp, #-0x20]
    // 0xbe67b8: CheckStackOverflow
    //     0xbe67b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe67bc: cmp             SP, x16
    //     0xbe67c0: b.ls            #0xbe6880
    // 0xbe67c4: cmp             x5, x0
    // 0xbe67c8: b.ge            #0xbe6834
    // 0xbe67cc: mov             x1, x5
    // 0xbe67d0: cmp             x1, x0
    // 0xbe67d4: b.hs            #0xbe6888
    // 0xbe67d8: LoadField: r0 = r2->field_f
    //     0xbe67d8: ldur            w0, [x2, #0xf]
    // 0xbe67dc: DecompressPointer r0
    //     0xbe67dc: add             x0, x0, HEAP, lsl #32
    // 0xbe67e0: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0xbe67e0: add             x16, x0, x5, lsl #2
    //     0xbe67e4: ldur            w1, [x16, #0xf]
    // 0xbe67e8: DecompressPointer r1
    //     0xbe67e8: add             x1, x1, HEAP, lsl #32
    // 0xbe67ec: stp             x1, x3, [SP]
    // 0xbe67f0: mov             x0, x3
    // 0xbe67f4: ClosureCall
    //     0xbe67f4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbe67f8: ldur            x2, [x0, #0x1f]
    //     0xbe67fc: blr             x2
    // 0xbe6800: ldur            x1, [fp, #-0x10]
    // 0xbe6804: LoadField: r0 = r1->field_b
    //     0xbe6804: ldur            w0, [x1, #0xb]
    // 0xbe6808: ldur            x2, [fp, #-8]
    // 0xbe680c: cmp             w0, w2
    // 0xbe6810: b.ne            #0xbe6844
    // 0xbe6814: ldur            x3, [fp, #-0x20]
    // 0xbe6818: add             x5, x3, #1
    // 0xbe681c: r3 = LoadInt32Instr(r0)
    //     0xbe681c: sbfx            x3, x0, #1, #0x1f
    // 0xbe6820: mov             x0, x3
    // 0xbe6824: mov             x4, x2
    // 0xbe6828: mov             x2, x1
    // 0xbe682c: ldur            x3, [fp, #-0x18]
    // 0xbe6830: b               #0xbe67b4
    // 0xbe6834: r0 = Null
    //     0xbe6834: mov             x0, NULL
    // 0xbe6838: LeaveFrame
    //     0xbe6838: mov             SP, fp
    //     0xbe683c: ldp             fp, lr, [SP], #0x10
    // 0xbe6840: ret
    //     0xbe6840: ret             
    // 0xbe6844: r0 = ConcurrentModificationError()
    //     0xbe6844: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbe6848: mov             x1, x0
    // 0xbe684c: ldur            x0, [fp, #-0x10]
    // 0xbe6850: StoreField: r1->field_b = r0
    //     0xbe6850: stur            w0, [x1, #0xb]
    // 0xbe6854: mov             x0, x1
    // 0xbe6858: r0 = Throw()
    //     0xbe6858: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe685c: brk             #0
    // 0xbe6860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6860: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe6864: b               #0xbe65d0
    // 0xbe6868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6868: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe686c: b               #0xbe65dc
    // 0xbe6870: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe6870: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe6874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6874: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe6878: b               #0xbe6674
    // 0xbe687c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe687c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe6880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6880: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe6884: b               #0xbe67c4
    // 0xbe6888: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe6888: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _destroyOrCacheChild(/* No info */) {
    // ** addr: 0xbe688c, size: 0x130
    // 0xbe688c: EnterFrame
    //     0xbe688c: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6890: mov             fp, SP
    // 0xbe6894: AllocStack(0x18)
    //     0xbe6894: sub             SP, SP, #0x18
    // 0xbe6898: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xbe6898: mov             x4, x1
    //     0xbe689c: mov             x3, x2
    //     0xbe68a0: stur            x1, [fp, #-0x10]
    //     0xbe68a4: stur            x2, [fp, #-0x18]
    // 0xbe68a8: CheckStackOverflow
    //     0xbe68a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe68ac: cmp             SP, x16
    //     0xbe68b0: b.ls            #0xbe69ac
    // 0xbe68b4: LoadField: r5 = r3->field_7
    //     0xbe68b4: ldur            w5, [x3, #7]
    // 0xbe68b8: DecompressPointer r5
    //     0xbe68b8: add             x5, x5, HEAP, lsl #32
    // 0xbe68bc: stur            x5, [fp, #-8]
    // 0xbe68c0: cmp             w5, NULL
    // 0xbe68c4: b.eq            #0xbe69b4
    // 0xbe68c8: mov             x0, x5
    // 0xbe68cc: r2 = Null
    //     0xbe68cc: mov             x2, NULL
    // 0xbe68d0: r1 = Null
    //     0xbe68d0: mov             x1, NULL
    // 0xbe68d4: r4 = LoadClassIdInstr(r0)
    //     0xbe68d4: ldur            x4, [x0, #-1]
    //     0xbe68d8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe68dc: r17 = -4183
    //     0xbe68dc: mov             x17, #-0x1057
    // 0xbe68e0: add             x4, x4, x17
    // 0xbe68e4: cmp             x4, #1
    // 0xbe68e8: b.ls            #0xbe6900
    // 0xbe68ec: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe68ec: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe68f0: ldr             x8, [x8, #0x590]
    // 0xbe68f4: r3 = Null
    //     0xbe68f4: add             x3, PP, #0x96, lsl #12  ; [pp+0x967e8] Null
    //     0xbe68f8: ldr             x3, [x3, #0x7e8]
    // 0xbe68fc: r0 = DefaultTypeTest()
    //     0xbe68fc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe6900: ldur            x0, [fp, #-8]
    // 0xbe6904: LoadField: r1 = r0->field_13
    //     0xbe6904: ldur            w1, [x0, #0x13]
    // 0xbe6908: DecompressPointer r1
    //     0xbe6908: add             x1, x1, HEAP, lsl #32
    // 0xbe690c: tbnz            w1, #4, #0xbe6988
    // 0xbe6910: ldur            x4, [fp, #-0x10]
    // 0xbe6914: ldur            x3, [fp, #-0x18]
    // 0xbe6918: mov             x1, x4
    // 0xbe691c: mov             x2, x3
    // 0xbe6920: r0 = remove()
    //     0xbe6920: bl              #0xa1b578  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::remove
    // 0xbe6924: ldur            x0, [fp, #-0x10]
    // 0xbe6928: LoadField: r1 = r0->field_5f
    //     0xbe6928: ldur            w1, [x0, #0x5f]
    // 0xbe692c: DecompressPointer r1
    //     0xbe692c: add             x1, x1, HEAP, lsl #32
    // 0xbe6930: ldur            x4, [fp, #-8]
    // 0xbe6934: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xbe6934: ldur            w2, [x4, #0x17]
    // 0xbe6938: DecompressPointer r2
    //     0xbe6938: add             x2, x2, HEAP, lsl #32
    // 0xbe693c: cmp             w2, NULL
    // 0xbe6940: b.eq            #0xbe69b8
    // 0xbe6944: ldur            x3, [fp, #-0x18]
    // 0xbe6948: r0 = []=()
    //     0xbe6948: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xbe694c: ldur            x0, [fp, #-8]
    // 0xbe6950: ldur            x2, [fp, #-0x18]
    // 0xbe6954: StoreField: r2->field_7 = r0
    //     0xbe6954: stur            w0, [x2, #7]
    //     0xbe6958: ldurb           w16, [x2, #-1]
    //     0xbe695c: ldurb           w17, [x0, #-1]
    //     0xbe6960: and             x16, x17, x16, lsr #2
    //     0xbe6964: tst             x16, HEAP, lsr #32
    //     0xbe6968: b.eq            #0xbe6970
    //     0xbe696c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbe6970: ldur            x1, [fp, #-0x10]
    // 0xbe6974: r0 = adoptChild()
    //     0xbe6974: bl              #0xc05494  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0xbe6978: ldur            x0, [fp, #-8]
    // 0xbe697c: r1 = true
    //     0xbe697c: add             x1, NULL, #0x20  ; true
    // 0xbe6980: StoreField: r0->field_1b = r1
    //     0xbe6980: stur            w1, [x0, #0x1b]
    // 0xbe6984: b               #0xbe699c
    // 0xbe6988: ldur            x0, [fp, #-0x10]
    // 0xbe698c: ldur            x2, [fp, #-0x18]
    // 0xbe6990: LoadField: r1 = r0->field_5b
    //     0xbe6990: ldur            w1, [x0, #0x5b]
    // 0xbe6994: DecompressPointer r1
    //     0xbe6994: add             x1, x1, HEAP, lsl #32
    // 0xbe6998: r0 = removeChild()
    //     0xbe6998: bl              #0xbe69bc  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::removeChild
    // 0xbe699c: r0 = Null
    //     0xbe699c: mov             x0, NULL
    // 0xbe69a0: LeaveFrame
    //     0xbe69a0: mov             SP, fp
    //     0xbe69a4: ldp             fp, lr, [SP], #0x10
    // 0xbe69a8: ret
    //     0xbe69a8: ret             
    // 0xbe69ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe69ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe69b0: b               #0xbe68b4
    // 0xbe69b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe69b4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe69b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe69b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, RenderBox) {
    // ** addr: 0xbe6cdc, size: 0x7c
    // 0xbe6cdc: EnterFrame
    //     0xbe6cdc: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6ce0: mov             fp, SP
    // 0xbe6ce4: AllocStack(0x8)
    //     0xbe6ce4: sub             SP, SP, #8
    // 0xbe6ce8: ldr             x0, [fp, #0x10]
    // 0xbe6cec: LoadField: r3 = r0->field_7
    //     0xbe6cec: ldur            w3, [x0, #7]
    // 0xbe6cf0: DecompressPointer r3
    //     0xbe6cf0: add             x3, x3, HEAP, lsl #32
    // 0xbe6cf4: stur            x3, [fp, #-8]
    // 0xbe6cf8: cmp             w3, NULL
    // 0xbe6cfc: b.eq            #0xbe6d54
    // 0xbe6d00: mov             x0, x3
    // 0xbe6d04: r2 = Null
    //     0xbe6d04: mov             x2, NULL
    // 0xbe6d08: r1 = Null
    //     0xbe6d08: mov             x1, NULL
    // 0xbe6d0c: r4 = LoadClassIdInstr(r0)
    //     0xbe6d0c: ldur            x4, [x0, #-1]
    //     0xbe6d10: ubfx            x4, x4, #0xc, #0x14
    // 0xbe6d14: r17 = -4183
    //     0xbe6d14: mov             x17, #-0x1057
    // 0xbe6d18: add             x4, x4, x17
    // 0xbe6d1c: cmp             x4, #1
    // 0xbe6d20: b.ls            #0xbe6d38
    // 0xbe6d24: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe6d24: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe6d28: ldr             x8, [x8, #0x590]
    // 0xbe6d2c: r3 = Null
    //     0xbe6d2c: add             x3, PP, #0x96, lsl #12  ; [pp+0x967d8] Null
    //     0xbe6d30: ldr             x3, [x3, #0x7d8]
    // 0xbe6d34: r0 = DefaultTypeTest()
    //     0xbe6d34: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe6d38: ldur            x1, [fp, #-8]
    // 0xbe6d3c: LoadField: r2 = r1->field_13
    //     0xbe6d3c: ldur            w2, [x1, #0x13]
    // 0xbe6d40: DecompressPointer r2
    //     0xbe6d40: add             x2, x2, HEAP, lsl #32
    // 0xbe6d44: eor             x0, x2, #0x10
    // 0xbe6d48: LeaveFrame
    //     0xbe6d48: mov             SP, fp
    //     0xbe6d4c: ldp             fp, lr, [SP], #0x10
    // 0xbe6d50: ret
    //     0xbe6d50: ret             
    // 0xbe6d54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe6d54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ calculateTrailingGarbage(/* No info */) {
    // ** addr: 0xbe6d58, size: 0xf0
    // 0xbe6d58: EnterFrame
    //     0xbe6d58: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6d5c: mov             fp, SP
    // 0xbe6d60: AllocStack(0x18)
    //     0xbe6d60: sub             SP, SP, #0x18
    // 0xbe6d64: SetupParameters(dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xbe6d64: mov             x3, x2
    //     0xbe6d68: stur            x2, [fp, #-0x18]
    // 0xbe6d6c: LoadField: r0 = r1->field_57
    //     0xbe6d6c: ldur            w0, [x1, #0x57]
    // 0xbe6d70: DecompressPointer r0
    //     0xbe6d70: add             x0, x0, HEAP, lsl #32
    // 0xbe6d74: r4 = 0
    //     0xbe6d74: mov             x4, #0
    // 0xbe6d78: stur            x4, [fp, #-0x10]
    // 0xbe6d7c: CheckStackOverflow
    //     0xbe6d7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe6d80: cmp             SP, x16
    //     0xbe6d84: b.ls            #0xbe6e38
    // 0xbe6d88: cmp             w0, NULL
    // 0xbe6d8c: b.eq            #0xbe6e28
    // 0xbe6d90: LoadField: r5 = r0->field_7
    //     0xbe6d90: ldur            w5, [x0, #7]
    // 0xbe6d94: DecompressPointer r5
    //     0xbe6d94: add             x5, x5, HEAP, lsl #32
    // 0xbe6d98: stur            x5, [fp, #-8]
    // 0xbe6d9c: cmp             w5, NULL
    // 0xbe6da0: b.eq            #0xbe6e40
    // 0xbe6da4: mov             x0, x5
    // 0xbe6da8: r2 = Null
    //     0xbe6da8: mov             x2, NULL
    // 0xbe6dac: r1 = Null
    //     0xbe6dac: mov             x1, NULL
    // 0xbe6db0: r4 = LoadClassIdInstr(r0)
    //     0xbe6db0: ldur            x4, [x0, #-1]
    //     0xbe6db4: ubfx            x4, x4, #0xc, #0x14
    // 0xbe6db8: r17 = -4183
    //     0xbe6db8: mov             x17, #-0x1057
    // 0xbe6dbc: add             x4, x4, x17
    // 0xbe6dc0: cmp             x4, #1
    // 0xbe6dc4: b.ls            #0xbe6ddc
    // 0xbe6dc8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe6dc8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe6dcc: ldr             x8, [x8, #0x590]
    // 0xbe6dd0: r3 = Null
    //     0xbe6dd0: add             x3, PP, #0x96, lsl #12  ; [pp+0x969a0] Null
    //     0xbe6dd4: ldr             x3, [x3, #0x9a0]
    // 0xbe6dd8: r0 = DefaultTypeTest()
    //     0xbe6dd8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe6ddc: ldur            x1, [fp, #-8]
    // 0xbe6de0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbe6de0: ldur            w2, [x1, #0x17]
    // 0xbe6de4: DecompressPointer r2
    //     0xbe6de4: add             x2, x2, HEAP, lsl #32
    // 0xbe6de8: cmp             w2, NULL
    // 0xbe6dec: b.eq            #0xbe6e44
    // 0xbe6df0: r3 = LoadInt32Instr(r2)
    //     0xbe6df0: sbfx            x3, x2, #1, #0x1f
    //     0xbe6df4: tbz             w2, #0, #0xbe6dfc
    //     0xbe6df8: ldur            x3, [x2, #7]
    // 0xbe6dfc: ldur            x2, [fp, #-0x18]
    // 0xbe6e00: cmp             x3, x2
    // 0xbe6e04: b.le            #0xbe6e20
    // 0xbe6e08: ldur            x0, [fp, #-0x10]
    // 0xbe6e0c: add             x4, x0, #1
    // 0xbe6e10: LoadField: r0 = r1->field_b
    //     0xbe6e10: ldur            w0, [x1, #0xb]
    // 0xbe6e14: DecompressPointer r0
    //     0xbe6e14: add             x0, x0, HEAP, lsl #32
    // 0xbe6e18: mov             x3, x2
    // 0xbe6e1c: b               #0xbe6d78
    // 0xbe6e20: ldur            x0, [fp, #-0x10]
    // 0xbe6e24: b               #0xbe6e2c
    // 0xbe6e28: mov             x0, x4
    // 0xbe6e2c: LeaveFrame
    //     0xbe6e2c: mov             SP, fp
    //     0xbe6e30: ldp             fp, lr, [SP], #0x10
    // 0xbe6e34: ret
    //     0xbe6e34: ret             
    // 0xbe6e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6e38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe6e3c: b               #0xbe6d88
    // 0xbe6e40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe6e40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe6e44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe6e44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ calculateLeadingGarbage(/* No info */) {
    // ** addr: 0xbe6e48, size: 0xf0
    // 0xbe6e48: EnterFrame
    //     0xbe6e48: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6e4c: mov             fp, SP
    // 0xbe6e50: AllocStack(0x18)
    //     0xbe6e50: sub             SP, SP, #0x18
    // 0xbe6e54: SetupParameters(dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xbe6e54: mov             x3, x2
    //     0xbe6e58: stur            x2, [fp, #-0x18]
    // 0xbe6e5c: LoadField: r0 = r1->field_53
    //     0xbe6e5c: ldur            w0, [x1, #0x53]
    // 0xbe6e60: DecompressPointer r0
    //     0xbe6e60: add             x0, x0, HEAP, lsl #32
    // 0xbe6e64: r4 = 0
    //     0xbe6e64: mov             x4, #0
    // 0xbe6e68: stur            x4, [fp, #-0x10]
    // 0xbe6e6c: CheckStackOverflow
    //     0xbe6e6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe6e70: cmp             SP, x16
    //     0xbe6e74: b.ls            #0xbe6f28
    // 0xbe6e78: cmp             w0, NULL
    // 0xbe6e7c: b.eq            #0xbe6f18
    // 0xbe6e80: LoadField: r5 = r0->field_7
    //     0xbe6e80: ldur            w5, [x0, #7]
    // 0xbe6e84: DecompressPointer r5
    //     0xbe6e84: add             x5, x5, HEAP, lsl #32
    // 0xbe6e88: stur            x5, [fp, #-8]
    // 0xbe6e8c: cmp             w5, NULL
    // 0xbe6e90: b.eq            #0xbe6f30
    // 0xbe6e94: mov             x0, x5
    // 0xbe6e98: r2 = Null
    //     0xbe6e98: mov             x2, NULL
    // 0xbe6e9c: r1 = Null
    //     0xbe6e9c: mov             x1, NULL
    // 0xbe6ea0: r4 = LoadClassIdInstr(r0)
    //     0xbe6ea0: ldur            x4, [x0, #-1]
    //     0xbe6ea4: ubfx            x4, x4, #0xc, #0x14
    // 0xbe6ea8: r17 = -4183
    //     0xbe6ea8: mov             x17, #-0x1057
    // 0xbe6eac: add             x4, x4, x17
    // 0xbe6eb0: cmp             x4, #1
    // 0xbe6eb4: b.ls            #0xbe6ecc
    // 0xbe6eb8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe6eb8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe6ebc: ldr             x8, [x8, #0x590]
    // 0xbe6ec0: r3 = Null
    //     0xbe6ec0: add             x3, PP, #0x96, lsl #12  ; [pp+0x969b0] Null
    //     0xbe6ec4: ldr             x3, [x3, #0x9b0]
    // 0xbe6ec8: r0 = DefaultTypeTest()
    //     0xbe6ec8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe6ecc: ldur            x1, [fp, #-8]
    // 0xbe6ed0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbe6ed0: ldur            w2, [x1, #0x17]
    // 0xbe6ed4: DecompressPointer r2
    //     0xbe6ed4: add             x2, x2, HEAP, lsl #32
    // 0xbe6ed8: cmp             w2, NULL
    // 0xbe6edc: b.eq            #0xbe6f34
    // 0xbe6ee0: r3 = LoadInt32Instr(r2)
    //     0xbe6ee0: sbfx            x3, x2, #1, #0x1f
    //     0xbe6ee4: tbz             w2, #0, #0xbe6eec
    //     0xbe6ee8: ldur            x3, [x2, #7]
    // 0xbe6eec: ldur            x2, [fp, #-0x18]
    // 0xbe6ef0: cmp             x3, x2
    // 0xbe6ef4: b.ge            #0xbe6f10
    // 0xbe6ef8: ldur            x0, [fp, #-0x10]
    // 0xbe6efc: add             x4, x0, #1
    // 0xbe6f00: LoadField: r0 = r1->field_f
    //     0xbe6f00: ldur            w0, [x1, #0xf]
    // 0xbe6f04: DecompressPointer r0
    //     0xbe6f04: add             x0, x0, HEAP, lsl #32
    // 0xbe6f08: mov             x3, x2
    // 0xbe6f0c: b               #0xbe6e68
    // 0xbe6f10: ldur            x0, [fp, #-0x10]
    // 0xbe6f14: b               #0xbe6f1c
    // 0xbe6f18: mov             x0, x4
    // 0xbe6f1c: LeaveFrame
    //     0xbe6f1c: mov             SP, fp
    //     0xbe6f20: ldp             fp, lr, [SP], #0x10
    // 0xbe6f24: ret
    //     0xbe6f24: ret             
    // 0xbe6f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6f28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe6f2c: b               #0xbe6e78
    // 0xbe6f30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe6f30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe6f34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe6f34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbecad8, size: 0x30
    // 0xbecad8: EnterFrame
    //     0xbecad8: stp             fp, lr, [SP, #-0x10]!
    //     0xbecadc: mov             fp, SP
    // 0xbecae0: CheckStackOverflow
    //     0xbecae0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbecae4: cmp             SP, x16
    //     0xbecae8: b.ls            #0xbecb00
    // 0xbecaec: r0 = visitChildren()
    //     0xbecaec: bl              #0xbecb08  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::visitChildren
    // 0xbecaf0: r0 = Null
    //     0xbecaf0: mov             x0, NULL
    // 0xbecaf4: LeaveFrame
    //     0xbecaf4: mov             SP, fp
    //     0xbecaf8: ldp             fp, lr, [SP], #0x10
    // 0xbecafc: ret
    //     0xbecafc: ret             
    // 0xbecb00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbecb00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbecb04: b               #0xbecaec
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0xbf0220, size: 0x7c
    // 0xbf0220: EnterFrame
    //     0xbf0220: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0224: mov             fp, SP
    // 0xbf0228: AllocStack(0x18)
    //     0xbf0228: sub             SP, SP, #0x18
    // 0xbf022c: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbf022c: mov             x3, x1
    //     0xbf0230: mov             x0, x2
    //     0xbf0234: stur            x1, [fp, #-8]
    //     0xbf0238: stur            x2, [fp, #-0x10]
    // 0xbf023c: CheckStackOverflow
    //     0xbf023c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0240: cmp             SP, x16
    //     0xbf0244: b.ls            #0xbf0294
    // 0xbf0248: mov             x1, x3
    // 0xbf024c: mov             x2, x0
    // 0xbf0250: r0 = visitChildren()
    //     0xbf0250: bl              #0xbecb08  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::visitChildren
    // 0xbf0254: ldur            x0, [fp, #-8]
    // 0xbf0258: LoadField: r2 = r0->field_5f
    //     0xbf0258: ldur            w2, [x0, #0x5f]
    // 0xbf025c: DecompressPointer r2
    //     0xbf025c: add             x2, x2, HEAP, lsl #32
    // 0xbf0260: stur            x2, [fp, #-0x18]
    // 0xbf0264: r1 = <RenderBox>
    //     0xbf0264: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xbf0268: ldr             x1, [x1, #0x5c8]
    // 0xbf026c: r0 = _CompactValuesIterable()
    //     0xbf026c: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xbf0270: mov             x1, x0
    // 0xbf0274: ldur            x0, [fp, #-0x18]
    // 0xbf0278: StoreField: r1->field_b = r0
    //     0xbf0278: stur            w0, [x1, #0xb]
    // 0xbf027c: ldur            x2, [fp, #-0x10]
    // 0xbf0280: r0 = forEach()
    //     0xbf0280: bl              #0xaffee4  ; [dart:core] Iterable::forEach
    // 0xbf0284: r0 = Null
    //     0xbf0284: mov             x0, NULL
    // 0xbf0288: LeaveFrame
    //     0xbf0288: mov             SP, fp
    //     0xbf028c: ldp             fp, lr, [SP], #0x10
    // 0xbf0290: ret
    //     0xbf0290: ret             
    // 0xbf0294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0294: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0298: b               #0xbf0248
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf203c, size: 0xac
    // 0xbf203c: EnterFrame
    //     0xbf203c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2040: mov             fp, SP
    // 0xbf2044: AllocStack(0x18)
    //     0xbf2044: sub             SP, SP, #0x18
    // 0xbf2048: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xbf2048: mov             x5, x1
    //     0xbf204c: mov             x4, x2
    //     0xbf2050: stur            x1, [fp, #-8]
    //     0xbf2054: stur            x2, [fp, #-0x10]
    //     0xbf2058: stur            x3, [fp, #-0x18]
    // 0xbf205c: CheckStackOverflow
    //     0xbf205c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf2060: cmp             SP, x16
    //     0xbf2064: b.ls            #0xbf20e0
    // 0xbf2068: mov             x0, x4
    // 0xbf206c: r2 = Null
    //     0xbf206c: mov             x2, NULL
    // 0xbf2070: r1 = Null
    //     0xbf2070: mov             x1, NULL
    // 0xbf2074: r4 = 60
    //     0xbf2074: mov             x4, #0x3c
    // 0xbf2078: branchIfSmi(r0, 0xbf2084)
    //     0xbf2078: tbz             w0, #0, #0xbf2084
    // 0xbf207c: r4 = LoadClassIdInstr(r0)
    //     0xbf207c: ldur            x4, [x0, #-1]
    //     0xbf2080: ubfx            x4, x4, #0xc, #0x14
    // 0xbf2084: r17 = -4710
    //     0xbf2084: mov             x17, #-0x1266
    // 0xbf2088: add             x4, x4, x17
    // 0xbf208c: cmp             x4, #0x109
    // 0xbf2090: b.ls            #0xbf20a4
    // 0xbf2094: r8 = RenderBox
    //     0xbf2094: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf2098: r3 = Null
    //     0xbf2098: add             x3, PP, #0x99, lsl #12  ; [pp+0x99fa8] Null
    //     0xbf209c: ldr             x3, [x3, #0xfa8]
    // 0xbf20a0: r0 = RenderBox()
    //     0xbf20a0: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf20a4: ldur            x1, [fp, #-8]
    // 0xbf20a8: ldur            x2, [fp, #-0x10]
    // 0xbf20ac: r0 = paintsChild()
    //     0xbf20ac: bl              #0xbf2d10  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::paintsChild
    // 0xbf20b0: tbz             w0, #4, #0xbf20c0
    // 0xbf20b4: ldur            x1, [fp, #-0x18]
    // 0xbf20b8: r0 = setZero()
    //     0xbf20b8: bl              #0x881d94  ; [package:vector_math/vector_math_64.dart] Matrix4::setZero
    // 0xbf20bc: b               #0xbf20d0
    // 0xbf20c0: ldur            x1, [fp, #-8]
    // 0xbf20c4: ldur            x2, [fp, #-0x10]
    // 0xbf20c8: ldur            x3, [fp, #-0x18]
    // 0xbf20cc: r0 = applyPaintTransformForBoxChild()
    //     0xbf20cc: bl              #0xbf20e8  ; [dart:mixin_deduplication] _MixinApplication21&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers::applyPaintTransformForBoxChild
    // 0xbf20d0: r0 = Null
    //     0xbf20d0: mov             x0, NULL
    // 0xbf20d4: LeaveFrame
    //     0xbf20d4: mov             SP, fp
    //     0xbf20d8: ldp             fp, lr, [SP], #0x10
    // 0xbf20dc: ret
    //     0xbf20dc: ret             
    // 0xbf20e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf20e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf20e4: b               #0xbf2068
  }
  _ childMainAxisPosition(/* No info */) {
    // ** addr: 0xbf2310, size: 0x108
    // 0xbf2310: EnterFrame
    //     0xbf2310: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2314: mov             fp, SP
    // 0xbf2318: AllocStack(0x18)
    //     0xbf2318: sub             SP, SP, #0x18
    // 0xbf231c: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r3, fp-0x10 */)
    //     0xbf231c: mov             x3, x1
    //     0xbf2320: stur            x1, [fp, #-0x10]
    // 0xbf2324: LoadField: r4 = r2->field_7
    //     0xbf2324: ldur            w4, [x2, #7]
    // 0xbf2328: DecompressPointer r4
    //     0xbf2328: add             x4, x4, HEAP, lsl #32
    // 0xbf232c: stur            x4, [fp, #-8]
    // 0xbf2330: cmp             w4, NULL
    // 0xbf2334: b.eq            #0xbf2410
    // 0xbf2338: mov             x0, x4
    // 0xbf233c: r2 = Null
    //     0xbf233c: mov             x2, NULL
    // 0xbf2340: r1 = Null
    //     0xbf2340: mov             x1, NULL
    // 0xbf2344: r4 = LoadClassIdInstr(r0)
    //     0xbf2344: ldur            x4, [x0, #-1]
    //     0xbf2348: ubfx            x4, x4, #0xc, #0x14
    // 0xbf234c: r17 = -4183
    //     0xbf234c: mov             x17, #-0x1057
    // 0xbf2350: add             x4, x4, x17
    // 0xbf2354: cmp             x4, #1
    // 0xbf2358: b.ls            #0xbf2370
    // 0xbf235c: r8 = SliverMultiBoxAdaptorParentData
    //     0xbf235c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbf2360: ldr             x8, [x8, #0x590]
    // 0xbf2364: r3 = Null
    //     0xbf2364: add             x3, PP, #0x99, lsl #12  ; [pp+0x99fd8] Null
    //     0xbf2368: ldr             x3, [x3, #0xfd8]
    // 0xbf236c: r0 = DefaultTypeTest()
    //     0xbf236c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf2370: ldur            x0, [fp, #-8]
    // 0xbf2374: LoadField: r3 = r0->field_7
    //     0xbf2374: ldur            w3, [x0, #7]
    // 0xbf2378: DecompressPointer r3
    //     0xbf2378: add             x3, x3, HEAP, lsl #32
    // 0xbf237c: stur            x3, [fp, #-0x18]
    // 0xbf2380: cmp             w3, NULL
    // 0xbf2384: b.eq            #0xbf2414
    // 0xbf2388: ldur            x0, [fp, #-0x10]
    // 0xbf238c: LoadField: r4 = r0->field_27
    //     0xbf238c: ldur            w4, [x0, #0x27]
    // 0xbf2390: DecompressPointer r4
    //     0xbf2390: add             x4, x4, HEAP, lsl #32
    // 0xbf2394: stur            x4, [fp, #-8]
    // 0xbf2398: cmp             w4, NULL
    // 0xbf239c: b.eq            #0xbf23f4
    // 0xbf23a0: mov             x0, x4
    // 0xbf23a4: r2 = Null
    //     0xbf23a4: mov             x2, NULL
    // 0xbf23a8: r1 = Null
    //     0xbf23a8: mov             x1, NULL
    // 0xbf23ac: r4 = LoadClassIdInstr(r0)
    //     0xbf23ac: ldur            x4, [x0, #-1]
    //     0xbf23b0: ubfx            x4, x4, #0xc, #0x14
    // 0xbf23b4: cmp             x4, #0xb45
    // 0xbf23b8: b.eq            #0xbf23d0
    // 0xbf23bc: r8 = SliverConstraints
    //     0xbf23bc: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbf23c0: ldr             x8, [x8, #0x3c0]
    // 0xbf23c4: r3 = Null
    //     0xbf23c4: add             x3, PP, #0x99, lsl #12  ; [pp+0x99fe8] Null
    //     0xbf23c8: ldr             x3, [x3, #0xfe8]
    // 0xbf23cc: r0 = DefaultTypeTest()
    //     0xbf23cc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf23d0: ldur            x0, [fp, #-8]
    // 0xbf23d4: LoadField: d0 = r0->field_13
    //     0xbf23d4: ldur            d0, [x0, #0x13]
    // 0xbf23d8: ldur            x0, [fp, #-0x18]
    // 0xbf23dc: LoadField: d1 = r0->field_7
    //     0xbf23dc: ldur            d1, [x0, #7]
    // 0xbf23e0: fsub            d2, d1, d0
    // 0xbf23e4: mov             v0.16b, v2.16b
    // 0xbf23e8: LeaveFrame
    //     0xbf23e8: mov             SP, fp
    //     0xbf23ec: ldp             fp, lr, [SP], #0x10
    // 0xbf23f0: ret
    //     0xbf23f0: ret             
    // 0xbf23f4: r0 = StateError()
    //     0xbf23f4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbf23f8: mov             x1, x0
    // 0xbf23fc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbf23fc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbf2400: StoreField: r1->field_b = r0
    //     0xbf2400: stur            w0, [x1, #0xb]
    // 0xbf2404: mov             x0, x1
    // 0xbf2408: r0 = Throw()
    //     0xbf2408: bl              #0x13ddb2c  ; ThrowStub
    // 0xbf240c: brk             #0
    // 0xbf2410: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf2410: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf2414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf2414: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ semanticBounds(/* No info */) {
    // ** addr: 0xbf29ac, size: 0x88
    // 0xbf29ac: EnterFrame
    //     0xbf29ac: stp             fp, lr, [SP, #-0x10]!
    //     0xbf29b0: mov             fp, SP
    // 0xbf29b4: CheckStackOverflow
    //     0xbf29b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf29b8: cmp             SP, x16
    //     0xbf29bc: b.ls            #0xbf2a2c
    // 0xbf29c0: LoadField: r0 = r1->field_47
    //     0xbf29c0: ldur            w0, [x1, #0x47]
    // 0xbf29c4: DecompressPointer r0
    //     0xbf29c4: add             x0, x0, HEAP, lsl #32
    // 0xbf29c8: cmp             w0, NULL
    // 0xbf29cc: b.eq            #0xbf2a1c
    // 0xbf29d0: LoadField: r2 = r0->field_3f
    //     0xbf29d0: ldur            w2, [x0, #0x3f]
    // 0xbf29d4: DecompressPointer r2
    //     0xbf29d4: add             x2, x2, HEAP, lsl #32
    // 0xbf29d8: tbz             w2, #4, #0xbf2a1c
    // 0xbf29dc: LoadField: r0 = r1->field_53
    //     0xbf29dc: ldur            w0, [x1, #0x53]
    // 0xbf29e0: DecompressPointer r0
    //     0xbf29e0: add             x0, x0, HEAP, lsl #32
    // 0xbf29e4: cmp             w0, NULL
    // 0xbf29e8: b.eq            #0xbf2a1c
    // 0xbf29ec: LoadField: r2 = r0->field_4b
    //     0xbf29ec: ldur            w2, [x0, #0x4b]
    // 0xbf29f0: DecompressPointer r2
    //     0xbf29f0: add             x2, x2, HEAP, lsl #32
    // 0xbf29f4: cmp             w2, NULL
    // 0xbf29f8: b.eq            #0xbf2a1c
    // 0xbf29fc: mov             x1, x0
    // 0xbf2a00: r0 = size()
    //     0xbf2a00: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbf2a04: mov             x2, x0
    // 0xbf2a08: r1 = Instance_Offset
    //     0xbf2a08: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbf2a0c: r0 = &()
    //     0xbf2a0c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xbf2a10: LeaveFrame
    //     0xbf2a10: mov             SP, fp
    //     0xbf2a14: ldp             fp, lr, [SP], #0x10
    // 0xbf2a18: ret
    //     0xbf2a18: ret             
    // 0xbf2a1c: r0 = paintBounds()
    //     0xbf2a1c: bl              #0xbf0350  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::paintBounds
    // 0xbf2a20: LeaveFrame
    //     0xbf2a20: mov             SP, fp
    //     0xbf2a24: ldp             fp, lr, [SP], #0x10
    // 0xbf2a28: ret
    //     0xbf2a28: ret             
    // 0xbf2a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2a2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2a30: b               #0xbf29c0
  }
  _ paintsChild(/* No info */) {
    // ** addr: 0xbf2d10, size: 0xfc
    // 0xbf2d10: EnterFrame
    //     0xbf2d10: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2d14: mov             fp, SP
    // 0xbf2d18: AllocStack(0x18)
    //     0xbf2d18: sub             SP, SP, #0x18
    // 0xbf2d1c: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xbf2d1c: mov             x4, x1
    //     0xbf2d20: mov             x3, x2
    //     0xbf2d24: stur            x1, [fp, #-8]
    //     0xbf2d28: stur            x2, [fp, #-0x10]
    // 0xbf2d2c: CheckStackOverflow
    //     0xbf2d2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf2d30: cmp             SP, x16
    //     0xbf2d34: b.ls            #0xbf2e04
    // 0xbf2d38: mov             x0, x3
    // 0xbf2d3c: r2 = Null
    //     0xbf2d3c: mov             x2, NULL
    // 0xbf2d40: r1 = Null
    //     0xbf2d40: mov             x1, NULL
    // 0xbf2d44: r4 = 60
    //     0xbf2d44: mov             x4, #0x3c
    // 0xbf2d48: branchIfSmi(r0, 0xbf2d54)
    //     0xbf2d48: tbz             w0, #0, #0xbf2d54
    // 0xbf2d4c: r4 = LoadClassIdInstr(r0)
    //     0xbf2d4c: ldur            x4, [x0, #-1]
    //     0xbf2d50: ubfx            x4, x4, #0xc, #0x14
    // 0xbf2d54: r17 = -4710
    //     0xbf2d54: mov             x17, #-0x1266
    // 0xbf2d58: add             x4, x4, x17
    // 0xbf2d5c: cmp             x4, #0x109
    // 0xbf2d60: b.ls            #0xbf2d74
    // 0xbf2d64: r8 = RenderBox
    //     0xbf2d64: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf2d68: r3 = Null
    //     0xbf2d68: add             x3, PP, #0x99, lsl #12  ; [pp+0x99ff8] Null
    //     0xbf2d6c: ldr             x3, [x3, #0xff8]
    // 0xbf2d70: r0 = RenderBox()
    //     0xbf2d70: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf2d74: ldur            x0, [fp, #-0x10]
    // 0xbf2d78: LoadField: r3 = r0->field_7
    //     0xbf2d78: ldur            w3, [x0, #7]
    // 0xbf2d7c: DecompressPointer r3
    //     0xbf2d7c: add             x3, x3, HEAP, lsl #32
    // 0xbf2d80: mov             x0, x3
    // 0xbf2d84: stur            x3, [fp, #-0x18]
    // 0xbf2d88: r2 = Null
    //     0xbf2d88: mov             x2, NULL
    // 0xbf2d8c: r1 = Null
    //     0xbf2d8c: mov             x1, NULL
    // 0xbf2d90: r4 = LoadClassIdInstr(r0)
    //     0xbf2d90: ldur            x4, [x0, #-1]
    //     0xbf2d94: ubfx            x4, x4, #0xc, #0x14
    // 0xbf2d98: r17 = -4183
    //     0xbf2d98: mov             x17, #-0x1057
    // 0xbf2d9c: add             x4, x4, x17
    // 0xbf2da0: cmp             x4, #1
    // 0xbf2da4: b.ls            #0xbf2dbc
    // 0xbf2da8: r8 = SliverMultiBoxAdaptorParentData?
    //     0xbf2da8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96ea0] Type: SliverMultiBoxAdaptorParentData?
    //     0xbf2dac: ldr             x8, [x8, #0xea0]
    // 0xbf2db0: r3 = Null
    //     0xbf2db0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a008] Null
    //     0xbf2db4: ldr             x3, [x3, #8]
    // 0xbf2db8: r0 = DefaultNullableTypeTest()
    //     0xbf2db8: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xbf2dbc: ldur            x0, [fp, #-0x18]
    // 0xbf2dc0: cmp             w0, NULL
    // 0xbf2dc4: b.eq            #0xbf2df4
    // 0xbf2dc8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xbf2dc8: ldur            w2, [x0, #0x17]
    // 0xbf2dcc: DecompressPointer r2
    //     0xbf2dcc: add             x2, x2, HEAP, lsl #32
    // 0xbf2dd0: cmp             w2, NULL
    // 0xbf2dd4: b.eq            #0xbf2df4
    // 0xbf2dd8: ldur            x0, [fp, #-8]
    // 0xbf2ddc: LoadField: r1 = r0->field_5f
    //     0xbf2ddc: ldur            w1, [x0, #0x5f]
    // 0xbf2de0: DecompressPointer r1
    //     0xbf2de0: add             x1, x1, HEAP, lsl #32
    // 0xbf2de4: r0 = containsKey()
    //     0xbf2de4: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xbf2de8: eor             x1, x0, #0x10
    // 0xbf2dec: mov             x0, x1
    // 0xbf2df0: b               #0xbf2df8
    // 0xbf2df4: r0 = false
    //     0xbf2df4: add             x0, NULL, #0x30  ; false
    // 0xbf2df8: LeaveFrame
    //     0xbf2df8: mov             SP, fp
    //     0xbf2dfc: ldp             fp, lr, [SP], #0x10
    // 0xbf2e00: ret
    //     0xbf2e00: ret             
    // 0xbf2e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2e04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2e08: b               #0xbf2d38
  }
  _ adoptChild(/* No info */) {
    // ** addr: 0xc05384, size: 0x110
    // 0xc05384: EnterFrame
    //     0xc05384: stp             fp, lr, [SP, #-0x10]!
    //     0xc05388: mov             fp, SP
    // 0xc0538c: AllocStack(0x18)
    //     0xc0538c: sub             SP, SP, #0x18
    // 0xc05390: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc05390: mov             x3, x1
    //     0xc05394: mov             x0, x2
    //     0xc05398: stur            x1, [fp, #-8]
    //     0xc0539c: stur            x2, [fp, #-0x10]
    // 0xc053a0: CheckStackOverflow
    //     0xc053a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc053a4: cmp             SP, x16
    //     0xc053a8: b.ls            #0xc05488
    // 0xc053ac: mov             x1, x3
    // 0xc053b0: mov             x2, x0
    // 0xc053b4: r0 = adoptChild()
    //     0xc053b4: bl              #0xc05494  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0xc053b8: ldur            x3, [fp, #-0x10]
    // 0xc053bc: LoadField: r4 = r3->field_7
    //     0xc053bc: ldur            w4, [x3, #7]
    // 0xc053c0: DecompressPointer r4
    //     0xc053c0: add             x4, x4, HEAP, lsl #32
    // 0xc053c4: stur            x4, [fp, #-0x18]
    // 0xc053c8: cmp             w4, NULL
    // 0xc053cc: b.eq            #0xc05490
    // 0xc053d0: mov             x0, x4
    // 0xc053d4: r2 = Null
    //     0xc053d4: mov             x2, NULL
    // 0xc053d8: r1 = Null
    //     0xc053d8: mov             x1, NULL
    // 0xc053dc: r4 = LoadClassIdInstr(r0)
    //     0xc053dc: ldur            x4, [x0, #-1]
    //     0xc053e0: ubfx            x4, x4, #0xc, #0x14
    // 0xc053e4: r17 = -4183
    //     0xc053e4: mov             x17, #-0x1057
    // 0xc053e8: add             x4, x4, x17
    // 0xc053ec: cmp             x4, #1
    // 0xc053f0: b.ls            #0xc05408
    // 0xc053f4: r8 = SliverMultiBoxAdaptorParentData
    //     0xc053f4: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xc053f8: ldr             x8, [x8, #0x590]
    // 0xc053fc: r3 = Null
    //     0xc053fc: add             x3, PP, #0x9b, lsl #12  ; [pp+0x9b4c8] Null
    //     0xc05400: ldr             x3, [x3, #0x4c8]
    // 0xc05404: r0 = DefaultTypeTest()
    //     0xc05404: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc05408: ldur            x0, [fp, #-0x18]
    // 0xc0540c: LoadField: r1 = r0->field_1b
    //     0xc0540c: ldur            w1, [x0, #0x1b]
    // 0xc05410: DecompressPointer r1
    //     0xc05410: add             x1, x1, HEAP, lsl #32
    // 0xc05414: tbz             w1, #4, #0xc05478
    // 0xc05418: ldur            x0, [fp, #-8]
    // 0xc0541c: LoadField: r3 = r0->field_5b
    //     0xc0541c: ldur            w3, [x0, #0x5b]
    // 0xc05420: DecompressPointer r3
    //     0xc05420: add             x3, x3, HEAP, lsl #32
    // 0xc05424: ldur            x0, [fp, #-0x10]
    // 0xc05428: stur            x3, [fp, #-0x18]
    // 0xc0542c: r2 = Null
    //     0xc0542c: mov             x2, NULL
    // 0xc05430: r1 = Null
    //     0xc05430: mov             x1, NULL
    // 0xc05434: r4 = LoadClassIdInstr(r0)
    //     0xc05434: ldur            x4, [x0, #-1]
    //     0xc05438: ubfx            x4, x4, #0xc, #0x14
    // 0xc0543c: r17 = -4710
    //     0xc0543c: mov             x17, #-0x1266
    // 0xc05440: add             x4, x4, x17
    // 0xc05444: cmp             x4, #0x109
    // 0xc05448: b.ls            #0xc0545c
    // 0xc0544c: r8 = RenderBox
    //     0xc0544c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc05450: r3 = Null
    //     0xc05450: add             x3, PP, #0x9b, lsl #12  ; [pp+0x9b4d8] Null
    //     0xc05454: ldr             x3, [x3, #0x4d8]
    // 0xc05458: r0 = RenderBox()
    //     0xc05458: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0545c: ldur            x1, [fp, #-0x18]
    // 0xc05460: r0 = LoadClassIdInstr(r1)
    //     0xc05460: ldur            x0, [x1, #-1]
    //     0xc05464: ubfx            x0, x0, #0xc, #0x14
    // 0xc05468: ldur            x2, [fp, #-0x10]
    // 0xc0546c: r0 = GDT[cid_x0 + -0xb86]()
    //     0xc0546c: sub             lr, x0, #0xb86
    //     0xc05470: ldr             lr, [x21, lr, lsl #3]
    //     0xc05474: blr             lr
    // 0xc05478: r0 = Null
    //     0xc05478: mov             x0, NULL
    // 0xc0547c: LeaveFrame
    //     0xc0547c: mov             SP, fp
    //     0xc05480: ldp             fp, lr, [SP], #0x10
    // 0xc05484: ret
    //     0xc05484: ret             
    // 0xc05488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05488: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0548c: b               #0xc053ac
    // 0xc05490: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc05490: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xc092fc, size: 0x10c
    // 0xc092fc: EnterFrame
    //     0xc092fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc09300: mov             fp, SP
    // 0xc09304: AllocStack(0x18)
    //     0xc09304: sub             SP, SP, #0x18
    // 0xc09308: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r0, fp-0x8 */)
    //     0xc09308: mov             x0, x1
    //     0xc0930c: stur            x1, [fp, #-8]
    // 0xc09310: CheckStackOverflow
    //     0xc09310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc09314: cmp             SP, x16
    //     0xc09318: b.ls            #0xc093f8
    // 0xc0931c: mov             x1, x0
    // 0xc09320: r0 = detach()
    //     0xc09320: bl              #0xc09408  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::detach
    // 0xc09324: ldur            x0, [fp, #-8]
    // 0xc09328: LoadField: r2 = r0->field_5f
    //     0xc09328: ldur            w2, [x0, #0x5f]
    // 0xc0932c: DecompressPointer r2
    //     0xc0932c: add             x2, x2, HEAP, lsl #32
    // 0xc09330: stur            x2, [fp, #-0x10]
    // 0xc09334: r1 = <RenderBox>
    //     0xc09334: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc09338: ldr             x1, [x1, #0x5c8]
    // 0xc0933c: r0 = _CompactValuesIterable()
    //     0xc0933c: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xc09340: mov             x1, x0
    // 0xc09344: ldur            x0, [fp, #-0x10]
    // 0xc09348: StoreField: r1->field_b = r0
    //     0xc09348: stur            w0, [x1, #0xb]
    // 0xc0934c: r0 = iterator()
    //     0xc0934c: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xc09350: stur            x0, [fp, #-0x10]
    // 0xc09354: LoadField: r2 = r0->field_7
    //     0xc09354: ldur            w2, [x0, #7]
    // 0xc09358: DecompressPointer r2
    //     0xc09358: add             x2, x2, HEAP, lsl #32
    // 0xc0935c: stur            x2, [fp, #-8]
    // 0xc09360: CheckStackOverflow
    //     0xc09360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc09364: cmp             SP, x16
    //     0xc09368: b.ls            #0xc09400
    // 0xc0936c: mov             x1, x0
    // 0xc09370: r0 = moveNext()
    //     0xc09370: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xc09374: tbnz            w0, #4, #0xc093e8
    // 0xc09378: ldur            x3, [fp, #-0x10]
    // 0xc0937c: LoadField: r4 = r3->field_33
    //     0xc0937c: ldur            w4, [x3, #0x33]
    // 0xc09380: DecompressPointer r4
    //     0xc09380: add             x4, x4, HEAP, lsl #32
    // 0xc09384: stur            x4, [fp, #-0x18]
    // 0xc09388: cmp             w4, NULL
    // 0xc0938c: b.ne            #0xc093c0
    // 0xc09390: mov             x0, x4
    // 0xc09394: ldur            x2, [fp, #-8]
    // 0xc09398: r1 = Null
    //     0xc09398: mov             x1, NULL
    // 0xc0939c: cmp             w2, NULL
    // 0xc093a0: b.eq            #0xc093c0
    // 0xc093a4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc093a4: ldur            w4, [x2, #0x17]
    // 0xc093a8: DecompressPointer r4
    //     0xc093a8: add             x4, x4, HEAP, lsl #32
    // 0xc093ac: r8 = X0
    //     0xc093ac: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xc093b0: LoadField: r9 = r4->field_7
    //     0xc093b0: ldur            x9, [x4, #7]
    // 0xc093b4: r3 = Null
    //     0xc093b4: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a020] Null
    //     0xc093b8: ldr             x3, [x3, #0x20]
    // 0xc093bc: blr             x9
    // 0xc093c0: ldur            x1, [fp, #-0x18]
    // 0xc093c4: r0 = LoadClassIdInstr(r1)
    //     0xc093c4: ldur            x0, [x1, #-1]
    //     0xc093c8: ubfx            x0, x0, #0xc, #0x14
    // 0xc093cc: r0 = GDT[cid_x0 + 0xf618]()
    //     0xc093cc: mov             x17, #0xf618
    //     0xc093d0: add             lr, x0, x17
    //     0xc093d4: ldr             lr, [x21, lr, lsl #3]
    //     0xc093d8: blr             lr
    // 0xc093dc: ldur            x0, [fp, #-0x10]
    // 0xc093e0: ldur            x2, [fp, #-8]
    // 0xc093e4: b               #0xc09360
    // 0xc093e8: r0 = Null
    //     0xc093e8: mov             x0, NULL
    // 0xc093ec: LeaveFrame
    //     0xc093ec: mov             SP, fp
    //     0xc093f0: ldp             fp, lr, [SP], #0x10
    // 0xc093f4: ret
    //     0xc093f4: ret             
    // 0xc093f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc093f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc093fc: b               #0xc0931c
    // 0xc09400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc09400: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc09404: b               #0xc0936c
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0d0b8, size: 0x11c
    // 0xc0d0b8: EnterFrame
    //     0xc0d0b8: stp             fp, lr, [SP, #-0x10]!
    //     0xc0d0bc: mov             fp, SP
    // 0xc0d0c0: AllocStack(0x20)
    //     0xc0d0c0: sub             SP, SP, #0x20
    // 0xc0d0c4: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc0d0c4: mov             x3, x1
    //     0xc0d0c8: mov             x0, x2
    //     0xc0d0cc: stur            x1, [fp, #-8]
    //     0xc0d0d0: stur            x2, [fp, #-0x10]
    // 0xc0d0d4: CheckStackOverflow
    //     0xc0d0d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0d0d8: cmp             SP, x16
    //     0xc0d0dc: b.ls            #0xc0d1c4
    // 0xc0d0e0: mov             x1, x3
    // 0xc0d0e4: mov             x2, x0
    // 0xc0d0e8: r0 = attach()
    //     0xc0d0e8: bl              #0xc0d1d4  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::attach
    // 0xc0d0ec: ldur            x0, [fp, #-8]
    // 0xc0d0f0: LoadField: r2 = r0->field_5f
    //     0xc0d0f0: ldur            w2, [x0, #0x5f]
    // 0xc0d0f4: DecompressPointer r2
    //     0xc0d0f4: add             x2, x2, HEAP, lsl #32
    // 0xc0d0f8: stur            x2, [fp, #-0x18]
    // 0xc0d0fc: r1 = <RenderBox>
    //     0xc0d0fc: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0d100: ldr             x1, [x1, #0x5c8]
    // 0xc0d104: r0 = _CompactValuesIterable()
    //     0xc0d104: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xc0d108: mov             x1, x0
    // 0xc0d10c: ldur            x0, [fp, #-0x18]
    // 0xc0d110: StoreField: r1->field_b = r0
    //     0xc0d110: stur            w0, [x1, #0xb]
    // 0xc0d114: r0 = iterator()
    //     0xc0d114: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0xc0d118: stur            x0, [fp, #-0x18]
    // 0xc0d11c: LoadField: r2 = r0->field_7
    //     0xc0d11c: ldur            w2, [x0, #7]
    // 0xc0d120: DecompressPointer r2
    //     0xc0d120: add             x2, x2, HEAP, lsl #32
    // 0xc0d124: stur            x2, [fp, #-8]
    // 0xc0d128: CheckStackOverflow
    //     0xc0d128: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0d12c: cmp             SP, x16
    //     0xc0d130: b.ls            #0xc0d1cc
    // 0xc0d134: mov             x1, x0
    // 0xc0d138: r0 = moveNext()
    //     0xc0d138: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xc0d13c: tbnz            w0, #4, #0xc0d1b4
    // 0xc0d140: ldur            x3, [fp, #-0x18]
    // 0xc0d144: LoadField: r4 = r3->field_33
    //     0xc0d144: ldur            w4, [x3, #0x33]
    // 0xc0d148: DecompressPointer r4
    //     0xc0d148: add             x4, x4, HEAP, lsl #32
    // 0xc0d14c: stur            x4, [fp, #-0x20]
    // 0xc0d150: cmp             w4, NULL
    // 0xc0d154: b.ne            #0xc0d188
    // 0xc0d158: mov             x0, x4
    // 0xc0d15c: ldur            x2, [fp, #-8]
    // 0xc0d160: r1 = Null
    //     0xc0d160: mov             x1, NULL
    // 0xc0d164: cmp             w2, NULL
    // 0xc0d168: b.eq            #0xc0d188
    // 0xc0d16c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc0d16c: ldur            w4, [x2, #0x17]
    // 0xc0d170: DecompressPointer r4
    //     0xc0d170: add             x4, x4, HEAP, lsl #32
    // 0xc0d174: r8 = X0
    //     0xc0d174: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xc0d178: LoadField: r9 = r4->field_7
    //     0xc0d178: ldur            x9, [x4, #7]
    // 0xc0d17c: r3 = Null
    //     0xc0d17c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a030] Null
    //     0xc0d180: ldr             x3, [x3, #0x30]
    // 0xc0d184: blr             x9
    // 0xc0d188: ldur            x1, [fp, #-0x20]
    // 0xc0d18c: r0 = LoadClassIdInstr(r1)
    //     0xc0d18c: ldur            x0, [x1, #-1]
    //     0xc0d190: ubfx            x0, x0, #0xc, #0x14
    // 0xc0d194: ldur            x2, [fp, #-0x10]
    // 0xc0d198: r0 = GDT[cid_x0 + 0xf4f5]()
    //     0xc0d198: mov             x17, #0xf4f5
    //     0xc0d19c: add             lr, x0, x17
    //     0xc0d1a0: ldr             lr, [x21, lr, lsl #3]
    //     0xc0d1a4: blr             lr
    // 0xc0d1a8: ldur            x0, [fp, #-0x18]
    // 0xc0d1ac: ldur            x2, [fp, #-8]
    // 0xc0d1b0: b               #0xc0d128
    // 0xc0d1b4: r0 = Null
    //     0xc0d1b4: mov             x0, NULL
    // 0xc0d1b8: LeaveFrame
    //     0xc0d1b8: mov             SP, fp
    //     0xc0d1bc: ldp             fp, lr, [SP], #0x10
    // 0xc0d1c0: ret
    //     0xc0d1c0: ret             
    // 0xc0d1c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0d1c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0d1c8: b               #0xc0d0e0
    // 0xc0d1cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0d1cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0d1d0: b               #0xc0d134
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0ed80, size: 0xb8
    // 0xc0ed80: EnterFrame
    //     0xc0ed80: stp             fp, lr, [SP, #-0x10]!
    //     0xc0ed84: mov             fp, SP
    // 0xc0ed88: AllocStack(0x8)
    //     0xc0ed88: sub             SP, SP, #8
    // 0xc0ed8c: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0ed8c: mov             x0, x2
    //     0xc0ed90: mov             x4, x1
    //     0xc0ed94: mov             x3, x2
    //     0xc0ed98: stur            x2, [fp, #-8]
    // 0xc0ed9c: r2 = Null
    //     0xc0ed9c: mov             x2, NULL
    // 0xc0eda0: r1 = Null
    //     0xc0eda0: mov             x1, NULL
    // 0xc0eda4: r4 = 60
    //     0xc0eda4: mov             x4, #0x3c
    // 0xc0eda8: branchIfSmi(r0, 0xc0edb4)
    //     0xc0eda8: tbz             w0, #0, #0xc0edb4
    // 0xc0edac: r4 = LoadClassIdInstr(r0)
    //     0xc0edac: ldur            x4, [x0, #-1]
    //     0xc0edb0: ubfx            x4, x4, #0xc, #0x14
    // 0xc0edb4: r17 = -4679
    //     0xc0edb4: mov             x17, #-0x1247
    // 0xc0edb8: add             x4, x4, x17
    // 0xc0edbc: cmp             x4, #0x128
    // 0xc0edc0: b.ls            #0xc0edd4
    // 0xc0edc4: r8 = RenderObject
    //     0xc0edc4: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0xc0edc8: r3 = Null
    //     0xc0edc8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a0b0] Null
    //     0xc0edcc: ldr             x3, [x3, #0xb0]
    // 0xc0edd0: r0 = RenderObject()
    //     0xc0edd0: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0xc0edd4: ldur            x0, [fp, #-8]
    // 0xc0edd8: LoadField: r1 = r0->field_7
    //     0xc0edd8: ldur            w1, [x0, #7]
    // 0xc0eddc: DecompressPointer r1
    //     0xc0eddc: add             x1, x1, HEAP, lsl #32
    // 0xc0ede0: r2 = LoadClassIdInstr(r1)
    //     0xc0ede0: ldur            x2, [x1, #-1]
    //     0xc0ede4: ubfx            x2, x2, #0xc, #0x14
    // 0xc0ede8: r17 = -4183
    //     0xc0ede8: mov             x17, #-0x1057
    // 0xc0edec: add             x16, x2, x17
    // 0xc0edf0: cmp             x16, #1
    // 0xc0edf4: b.ls            #0xc0ee28
    // 0xc0edf8: r0 = SliverMultiBoxAdaptorParentData()
    //     0xc0edf8: bl              #0xc0ee38  ; AllocateSliverMultiBoxAdaptorParentDataStub -> SliverMultiBoxAdaptorParentData (size=0x20)
    // 0xc0edfc: r1 = false
    //     0xc0edfc: add             x1, NULL, #0x30  ; false
    // 0xc0ee00: StoreField: r0->field_1b = r1
    //     0xc0ee00: stur            w1, [x0, #0x1b]
    // 0xc0ee04: StoreField: r0->field_13 = r1
    //     0xc0ee04: stur            w1, [x0, #0x13]
    // 0xc0ee08: ldur            x1, [fp, #-8]
    // 0xc0ee0c: StoreField: r1->field_7 = r0
    //     0xc0ee0c: stur            w0, [x1, #7]
    //     0xc0ee10: ldurb           w16, [x1, #-1]
    //     0xc0ee14: ldurb           w17, [x0, #-1]
    //     0xc0ee18: and             x16, x17, x16, lsr #2
    //     0xc0ee1c: tst             x16, HEAP, lsr #32
    //     0xc0ee20: b.eq            #0xc0ee28
    //     0xc0ee24: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0ee28: r0 = Null
    //     0xc0ee28: mov             x0, NULL
    // 0xc0ee2c: LeaveFrame
    //     0xc0ee2c: mov             SP, fp
    //     0xc0ee30: ldp             fp, lr, [SP], #0x10
    // 0xc0ee34: ret
    //     0xc0ee34: ret             
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0xc10888, size: 0x88
    // 0xc10888: EnterFrame
    //     0xc10888: stp             fp, lr, [SP, #-0x10]!
    //     0xc1088c: mov             fp, SP
    // 0xc10890: AllocStack(0x18)
    //     0xc10890: sub             SP, SP, #0x18
    // 0xc10894: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r0, fp-0x8 */)
    //     0xc10894: mov             x0, x1
    //     0xc10898: stur            x1, [fp, #-8]
    // 0xc1089c: CheckStackOverflow
    //     0xc1089c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc108a0: cmp             SP, x16
    //     0xc108a4: b.ls            #0xc10908
    // 0xc108a8: mov             x1, x0
    // 0xc108ac: r0 = redepthChildren()
    //     0xc108ac: bl              #0xc10910  ; [dart:mixin_deduplication] _MixinApplication20&RenderSliver&ContainerRenderObjectMixin::redepthChildren
    // 0xc108b0: ldur            x2, [fp, #-8]
    // 0xc108b4: LoadField: r0 = r2->field_5f
    //     0xc108b4: ldur            w0, [x2, #0x5f]
    // 0xc108b8: DecompressPointer r0
    //     0xc108b8: add             x0, x0, HEAP, lsl #32
    // 0xc108bc: stur            x0, [fp, #-0x10]
    // 0xc108c0: r1 = <RenderBox>
    //     0xc108c0: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc108c4: ldr             x1, [x1, #0x5c8]
    // 0xc108c8: r0 = _CompactValuesIterable()
    //     0xc108c8: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0xc108cc: mov             x3, x0
    // 0xc108d0: ldur            x0, [fp, #-0x10]
    // 0xc108d4: stur            x3, [fp, #-0x18]
    // 0xc108d8: StoreField: r3->field_b = r0
    //     0xc108d8: stur            w0, [x3, #0xb]
    // 0xc108dc: ldur            x2, [fp, #-8]
    // 0xc108e0: r1 = Function 'redepthChild':.
    //     0xc108e0: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a018] AnonymousClosure: (0xc055e8), in [package:flutter/src/rendering/object.dart] RenderObject::redepthChild (0xc05584)
    //     0xc108e4: ldr             x1, [x1, #0x18]
    // 0xc108e8: r0 = AllocateClosure()
    //     0xc108e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc108ec: ldur            x1, [fp, #-0x18]
    // 0xc108f0: mov             x2, x0
    // 0xc108f4: r0 = forEach()
    //     0xc108f4: bl              #0xaffee4  ; [dart:core] Iterable::forEach
    // 0xc108f8: r0 = Null
    //     0xc108f8: mov             x0, NULL
    // 0xc108fc: LeaveFrame
    //     0xc108fc: mov             SP, fp
    //     0xc10900: ldp             fp, lr, [SP], #0x10
    // 0xc10904: ret
    //     0xc10904: ret             
    // 0xc10908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc10908: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1090c: b               #0xc108a8
  }
  _ paint(/* No info */) {
    // ** addr: 0xccd5c4, size: 0x578
    // 0xccd5c4: EnterFrame
    //     0xccd5c4: stp             fp, lr, [SP, #-0x10]!
    //     0xccd5c8: mov             fp, SP
    // 0xccd5cc: AllocStack(0x80)
    //     0xccd5cc: sub             SP, SP, #0x80
    // 0xccd5d0: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xccd5d0: mov             x5, x1
    //     0xccd5d4: mov             x4, x2
    //     0xccd5d8: stur            x1, [fp, #-0x10]
    //     0xccd5dc: stur            x2, [fp, #-0x18]
    //     0xccd5e0: stur            x3, [fp, #-0x20]
    // 0xccd5e4: CheckStackOverflow
    //     0xccd5e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccd5e8: cmp             SP, x16
    //     0xccd5ec: b.ls            #0xccdb18
    // 0xccd5f0: LoadField: r0 = r5->field_53
    //     0xccd5f0: ldur            w0, [x5, #0x53]
    // 0xccd5f4: DecompressPointer r0
    //     0xccd5f4: add             x0, x0, HEAP, lsl #32
    // 0xccd5f8: cmp             w0, NULL
    // 0xccd5fc: b.ne            #0xccd610
    // 0xccd600: r0 = Null
    //     0xccd600: mov             x0, NULL
    // 0xccd604: LeaveFrame
    //     0xccd604: mov             SP, fp
    //     0xccd608: ldp             fp, lr, [SP], #0x10
    // 0xccd60c: ret
    //     0xccd60c: ret             
    // 0xccd610: LoadField: r6 = r5->field_27
    //     0xccd610: ldur            w6, [x5, #0x27]
    // 0xccd614: DecompressPointer r6
    //     0xccd614: add             x6, x6, HEAP, lsl #32
    // 0xccd618: stur            x6, [fp, #-8]
    // 0xccd61c: cmp             w6, NULL
    // 0xccd620: b.eq            #0xccdabc
    // 0xccd624: mov             x0, x6
    // 0xccd628: r2 = Null
    //     0xccd628: mov             x2, NULL
    // 0xccd62c: r1 = Null
    //     0xccd62c: mov             x1, NULL
    // 0xccd630: r4 = LoadClassIdInstr(r0)
    //     0xccd630: ldur            x4, [x0, #-1]
    //     0xccd634: ubfx            x4, x4, #0xc, #0x14
    // 0xccd638: cmp             x4, #0xb45
    // 0xccd63c: b.eq            #0xccd654
    // 0xccd640: r8 = SliverConstraints
    //     0xccd640: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xccd644: ldr             x8, [x8, #0x3c0]
    // 0xccd648: r3 = Null
    //     0xccd648: add             x3, PP, #0x99, lsl #12  ; [pp+0x99f48] Null
    //     0xccd64c: ldr             x3, [x3, #0xf48]
    // 0xccd650: r0 = DefaultTypeTest()
    //     0xccd650: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xccd654: ldur            x0, [fp, #-8]
    // 0xccd658: LoadField: r1 = r0->field_7
    //     0xccd658: ldur            w1, [x0, #7]
    // 0xccd65c: DecompressPointer r1
    //     0xccd65c: add             x1, x1, HEAP, lsl #32
    // 0xccd660: LoadField: r2 = r0->field_b
    //     0xccd660: ldur            w2, [x0, #0xb]
    // 0xccd664: DecompressPointer r2
    //     0xccd664: add             x2, x2, HEAP, lsl #32
    // 0xccd668: r0 = applyGrowthDirectionToAxisDirection()
    //     0xccd668: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0xccd66c: LoadField: r1 = r0->field_7
    //     0xccd66c: ldur            x1, [x0, #7]
    // 0xccd670: cmp             x1, #1
    // 0xccd674: b.gt            #0xccd6e0
    // 0xccd678: cmp             x1, #0
    // 0xccd67c: b.gt            #0xccd6cc
    // 0xccd680: ldur            x1, [fp, #-0x10]
    // 0xccd684: LoadField: r0 = r1->field_47
    //     0xccd684: ldur            w0, [x1, #0x47]
    // 0xccd688: DecompressPointer r0
    //     0xccd688: add             x0, x0, HEAP, lsl #32
    // 0xccd68c: cmp             w0, NULL
    // 0xccd690: b.eq            #0xccdb20
    // 0xccd694: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xccd694: ldur            d0, [x0, #0x17]
    // 0xccd698: stur            d0, [fp, #-0x38]
    // 0xccd69c: r0 = Offset()
    //     0xccd69c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xccd6a0: StoreField: r0->field_7 = rZR
    //     0xccd6a0: stur            xzr, [x0, #7]
    // 0xccd6a4: ldur            d0, [fp, #-0x38]
    // 0xccd6a8: StoreField: r0->field_f = d0
    //     0xccd6a8: stur            d0, [x0, #0xf]
    // 0xccd6ac: ldur            x1, [fp, #-0x20]
    // 0xccd6b0: mov             x2, x0
    // 0xccd6b4: r0 = +()
    //     0xccd6b4: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xccd6b8: r2 = Instance_Offset
    //     0xccd6b8: add             x2, PP, #0x99, lsl #12  ; [pp+0x99f58] Obj!Offset@12a7bf1
    //     0xccd6bc: ldr             x2, [x2, #0xf58]
    // 0xccd6c0: r1 = Instance_Offset
    //     0xccd6c0: ldr             x1, [PP, #0x55a8]  ; [pp+0x55a8] Obj!Offset@12a7af1
    // 0xccd6c4: r4 = true
    //     0xccd6c4: add             x4, NULL, #0x20  ; true
    // 0xccd6c8: b               #0xccd744
    // 0xccd6cc: ldur            x0, [fp, #-0x20]
    // 0xccd6d0: r2 = Instance_Offset
    //     0xccd6d0: ldr             x2, [PP, #0x55a8]  ; [pp+0x55a8] Obj!Offset@12a7af1
    // 0xccd6d4: r1 = Instance_Offset
    //     0xccd6d4: ldr             x1, [PP, #0x55b0]  ; [pp+0x55b0] Obj!Offset@12a7ad1
    // 0xccd6d8: r4 = false
    //     0xccd6d8: add             x4, NULL, #0x30  ; false
    // 0xccd6dc: b               #0xccd744
    // 0xccd6e0: cmp             x1, #2
    // 0xccd6e4: b.gt            #0xccd6fc
    // 0xccd6e8: ldur            x0, [fp, #-0x20]
    // 0xccd6ec: r2 = Instance_Offset
    //     0xccd6ec: ldr             x2, [PP, #0x55b0]  ; [pp+0x55b0] Obj!Offset@12a7ad1
    // 0xccd6f0: r1 = Instance_Offset
    //     0xccd6f0: ldr             x1, [PP, #0x55a8]  ; [pp+0x55a8] Obj!Offset@12a7af1
    // 0xccd6f4: r4 = false
    //     0xccd6f4: add             x4, NULL, #0x30  ; false
    // 0xccd6f8: b               #0xccd744
    // 0xccd6fc: ldur            x1, [fp, #-0x10]
    // 0xccd700: LoadField: r0 = r1->field_47
    //     0xccd700: ldur            w0, [x1, #0x47]
    // 0xccd704: DecompressPointer r0
    //     0xccd704: add             x0, x0, HEAP, lsl #32
    // 0xccd708: cmp             w0, NULL
    // 0xccd70c: b.eq            #0xccdb24
    // 0xccd710: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xccd710: ldur            d0, [x0, #0x17]
    // 0xccd714: stur            d0, [fp, #-0x38]
    // 0xccd718: r0 = Offset()
    //     0xccd718: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xccd71c: ldur            d0, [fp, #-0x38]
    // 0xccd720: StoreField: r0->field_7 = d0
    //     0xccd720: stur            d0, [x0, #7]
    // 0xccd724: StoreField: r0->field_f = rZR
    //     0xccd724: stur            xzr, [x0, #0xf]
    // 0xccd728: ldur            x1, [fp, #-0x20]
    // 0xccd72c: mov             x2, x0
    // 0xccd730: r0 = +()
    //     0xccd730: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xccd734: r2 = Instance_Offset
    //     0xccd734: add             x2, PP, #0x99, lsl #12  ; [pp+0x99f60] Obj!Offset@12a7bd1
    //     0xccd738: ldr             x2, [x2, #0xf60]
    // 0xccd73c: r1 = Instance_Offset
    //     0xccd73c: ldr             x1, [PP, #0x55b0]  ; [pp+0x55b0] Obj!Offset@12a7ad1
    // 0xccd740: r4 = true
    //     0xccd740: add             x4, NULL, #0x20  ; true
    // 0xccd744: ldur            x3, [fp, #-0x10]
    // 0xccd748: stur            x4, [fp, #-0x28]
    // 0xccd74c: LoadField: r5 = r3->field_53
    //     0xccd74c: ldur            w5, [x3, #0x53]
    // 0xccd750: DecompressPointer r5
    //     0xccd750: add             x5, x5, HEAP, lsl #32
    // 0xccd754: LoadField: d0 = r0->field_7
    //     0xccd754: ldur            d0, [x0, #7]
    // 0xccd758: stur            d0, [fp, #-0x60]
    // 0xccd75c: LoadField: d1 = r2->field_7
    //     0xccd75c: ldur            d1, [x2, #7]
    // 0xccd760: stur            d1, [fp, #-0x58]
    // 0xccd764: LoadField: d2 = r1->field_7
    //     0xccd764: ldur            d2, [x1, #7]
    // 0xccd768: stur            d2, [fp, #-0x50]
    // 0xccd76c: LoadField: d3 = r0->field_f
    //     0xccd76c: ldur            d3, [x0, #0xf]
    // 0xccd770: stur            d3, [fp, #-0x48]
    // 0xccd774: LoadField: d4 = r2->field_f
    //     0xccd774: ldur            d4, [x2, #0xf]
    // 0xccd778: stur            d4, [fp, #-0x40]
    // 0xccd77c: LoadField: d5 = r1->field_f
    //     0xccd77c: ldur            d5, [x1, #0xf]
    // 0xccd780: stur            d5, [fp, #-0x38]
    // 0xccd784: stur            x5, [fp, #-0x20]
    // 0xccd788: CheckStackOverflow
    //     0xccd788: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccd78c: cmp             SP, x16
    //     0xccd790: b.ls            #0xccdb28
    // 0xccd794: cmp             w5, NULL
    // 0xccd798: b.eq            #0xccdaac
    // 0xccd79c: LoadField: r6 = r5->field_7
    //     0xccd79c: ldur            w6, [x5, #7]
    // 0xccd7a0: DecompressPointer r6
    //     0xccd7a0: add             x6, x6, HEAP, lsl #32
    // 0xccd7a4: stur            x6, [fp, #-8]
    // 0xccd7a8: cmp             w6, NULL
    // 0xccd7ac: b.eq            #0xccdb30
    // 0xccd7b0: mov             x0, x6
    // 0xccd7b4: r2 = Null
    //     0xccd7b4: mov             x2, NULL
    // 0xccd7b8: r1 = Null
    //     0xccd7b8: mov             x1, NULL
    // 0xccd7bc: r4 = LoadClassIdInstr(r0)
    //     0xccd7bc: ldur            x4, [x0, #-1]
    //     0xccd7c0: ubfx            x4, x4, #0xc, #0x14
    // 0xccd7c4: r17 = -4183
    //     0xccd7c4: mov             x17, #-0x1057
    // 0xccd7c8: add             x4, x4, x17
    // 0xccd7cc: cmp             x4, #1
    // 0xccd7d0: b.ls            #0xccd7e8
    // 0xccd7d4: r8 = SliverMultiBoxAdaptorParentData
    //     0xccd7d4: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xccd7d8: ldr             x8, [x8, #0x590]
    // 0xccd7dc: r3 = Null
    //     0xccd7dc: add             x3, PP, #0x99, lsl #12  ; [pp+0x99f68] Null
    //     0xccd7e0: ldr             x3, [x3, #0xf68]
    // 0xccd7e4: r0 = DefaultTypeTest()
    //     0xccd7e4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xccd7e8: ldur            x0, [fp, #-8]
    // 0xccd7ec: LoadField: r3 = r0->field_7
    //     0xccd7ec: ldur            w3, [x0, #7]
    // 0xccd7f0: DecompressPointer r3
    //     0xccd7f0: add             x3, x3, HEAP, lsl #32
    // 0xccd7f4: stur            x3, [fp, #-0x30]
    // 0xccd7f8: cmp             w3, NULL
    // 0xccd7fc: b.eq            #0xccdb34
    // 0xccd800: ldur            x4, [fp, #-0x10]
    // 0xccd804: LoadField: r5 = r4->field_27
    //     0xccd804: ldur            w5, [x4, #0x27]
    // 0xccd808: DecompressPointer r5
    //     0xccd808: add             x5, x5, HEAP, lsl #32
    // 0xccd80c: stur            x5, [fp, #-8]
    // 0xccd810: cmp             w5, NULL
    // 0xccd814: b.eq            #0xccdaf8
    // 0xccd818: ldur            x6, [fp, #-0x28]
    // 0xccd81c: ldur            d0, [fp, #-0x60]
    // 0xccd820: ldur            d1, [fp, #-0x58]
    // 0xccd824: ldur            d2, [fp, #-0x50]
    // 0xccd828: ldur            d3, [fp, #-0x48]
    // 0xccd82c: ldur            d4, [fp, #-0x40]
    // 0xccd830: ldur            d5, [fp, #-0x38]
    // 0xccd834: mov             x0, x5
    // 0xccd838: r2 = Null
    //     0xccd838: mov             x2, NULL
    // 0xccd83c: r1 = Null
    //     0xccd83c: mov             x1, NULL
    // 0xccd840: r4 = LoadClassIdInstr(r0)
    //     0xccd840: ldur            x4, [x0, #-1]
    //     0xccd844: ubfx            x4, x4, #0xc, #0x14
    // 0xccd848: cmp             x4, #0xb45
    // 0xccd84c: b.eq            #0xccd864
    // 0xccd850: r8 = SliverConstraints
    //     0xccd850: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xccd854: ldr             x8, [x8, #0x3c0]
    // 0xccd858: r3 = Null
    //     0xccd858: add             x3, PP, #0x99, lsl #12  ; [pp+0x99f78] Null
    //     0xccd85c: ldr             x3, [x3, #0xf78]
    // 0xccd860: r0 = DefaultTypeTest()
    //     0xccd860: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xccd864: ldur            x0, [fp, #-8]
    // 0xccd868: LoadField: d0 = r0->field_13
    //     0xccd868: ldur            d0, [x0, #0x13]
    // 0xccd86c: ldur            x0, [fp, #-0x30]
    // 0xccd870: LoadField: d1 = r0->field_7
    //     0xccd870: ldur            d1, [x0, #7]
    // 0xccd874: fsub            d2, d1, d0
    // 0xccd878: ldur            x3, [fp, #-0x10]
    // 0xccd87c: stur            d2, [fp, #-0x68]
    // 0xccd880: r0 = LoadClassIdInstr(r3)
    //     0xccd880: ldur            x0, [x3, #-1]
    //     0xccd884: ubfx            x0, x0, #0xc, #0x14
    // 0xccd888: mov             x1, x3
    // 0xccd88c: ldur            x2, [fp, #-0x20]
    // 0xccd890: r0 = GDT[cid_x0 + 0x155d]()
    //     0xccd890: mov             x17, #0x155d
    //     0xccd894: add             lr, x0, x17
    //     0xccd898: ldr             lr, [x21, lr, lsl #3]
    //     0xccd89c: blr             lr
    // 0xccd8a0: mov             v2.16b, v0.16b
    // 0xccd8a4: ldur            d0, [fp, #-0x68]
    // 0xccd8a8: ldur            d1, [fp, #-0x58]
    // 0xccd8ac: fmul            d3, d1, d0
    // 0xccd8b0: ldur            d4, [fp, #-0x60]
    // 0xccd8b4: fadd            d5, d4, d3
    // 0xccd8b8: ldur            d3, [fp, #-0x50]
    // 0xccd8bc: fmul            d6, d3, d2
    // 0xccd8c0: fadd            d7, d5, d6
    // 0xccd8c4: ldur            d5, [fp, #-0x40]
    // 0xccd8c8: stur            d7, [fp, #-0x78]
    // 0xccd8cc: fmul            d6, d5, d0
    // 0xccd8d0: ldur            d8, [fp, #-0x48]
    // 0xccd8d4: fadd            d9, d8, d6
    // 0xccd8d8: ldur            d6, [fp, #-0x38]
    // 0xccd8dc: fmul            d10, d6, d2
    // 0xccd8e0: fadd            d2, d9, d10
    // 0xccd8e4: stur            d2, [fp, #-0x70]
    // 0xccd8e8: r0 = Offset()
    //     0xccd8e8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xccd8ec: ldur            d0, [fp, #-0x78]
    // 0xccd8f0: StoreField: r0->field_7 = d0
    //     0xccd8f0: stur            d0, [x0, #7]
    // 0xccd8f4: ldur            d1, [fp, #-0x70]
    // 0xccd8f8: StoreField: r0->field_f = d1
    //     0xccd8f8: stur            d1, [x0, #0xf]
    // 0xccd8fc: ldur            x3, [fp, #-0x28]
    // 0xccd900: tbnz            w3, #4, #0xccd978
    // 0xccd904: ldur            x4, [fp, #-0x10]
    // 0xccd908: ldur            d2, [fp, #-0x58]
    // 0xccd90c: ldur            d3, [fp, #-0x40]
    // 0xccd910: r0 = LoadClassIdInstr(r4)
    //     0xccd910: ldur            x0, [x4, #-1]
    //     0xccd914: ubfx            x0, x0, #0xc, #0x14
    // 0xccd918: mov             x1, x4
    // 0xccd91c: ldur            x2, [fp, #-0x20]
    // 0xccd920: r0 = GDT[cid_x0 + 0x2f60]()
    //     0xccd920: mov             x17, #0x2f60
    //     0xccd924: add             lr, x0, x17
    //     0xccd928: ldr             lr, [x21, lr, lsl #3]
    //     0xccd92c: blr             lr
    // 0xccd930: mov             v1.16b, v0.16b
    // 0xccd934: ldur            d0, [fp, #-0x58]
    // 0xccd938: fmul            d2, d0, d1
    // 0xccd93c: ldur            d3, [fp, #-0x40]
    // 0xccd940: fmul            d4, d3, d1
    // 0xccd944: ldur            d1, [fp, #-0x78]
    // 0xccd948: fadd            d5, d1, d2
    // 0xccd94c: ldur            d1, [fp, #-0x70]
    // 0xccd950: stur            d5, [fp, #-0x80]
    // 0xccd954: fadd            d2, d1, d4
    // 0xccd958: stur            d2, [fp, #-0x78]
    // 0xccd95c: r0 = Offset()
    //     0xccd95c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xccd960: ldur            d0, [fp, #-0x80]
    // 0xccd964: StoreField: r0->field_7 = d0
    //     0xccd964: stur            d0, [x0, #7]
    // 0xccd968: ldur            d0, [fp, #-0x78]
    // 0xccd96c: StoreField: r0->field_f = d0
    //     0xccd96c: stur            d0, [x0, #0xf]
    // 0xccd970: mov             x4, x0
    // 0xccd974: b               #0xccd97c
    // 0xccd978: mov             x4, x0
    // 0xccd97c: ldur            x3, [fp, #-0x10]
    // 0xccd980: stur            x4, [fp, #-0x30]
    // 0xccd984: LoadField: r5 = r3->field_27
    //     0xccd984: ldur            w5, [x3, #0x27]
    // 0xccd988: DecompressPointer r5
    //     0xccd988: add             x5, x5, HEAP, lsl #32
    // 0xccd98c: stur            x5, [fp, #-8]
    // 0xccd990: cmp             w5, NULL
    // 0xccd994: b.eq            #0xccdad8
    // 0xccd998: ldur            d0, [fp, #-0x68]
    // 0xccd99c: mov             x0, x5
    // 0xccd9a0: r2 = Null
    //     0xccd9a0: mov             x2, NULL
    // 0xccd9a4: r1 = Null
    //     0xccd9a4: mov             x1, NULL
    // 0xccd9a8: r4 = LoadClassIdInstr(r0)
    //     0xccd9a8: ldur            x4, [x0, #-1]
    //     0xccd9ac: ubfx            x4, x4, #0xc, #0x14
    // 0xccd9b0: cmp             x4, #0xb45
    // 0xccd9b4: b.eq            #0xccd9cc
    // 0xccd9b8: r8 = SliverConstraints
    //     0xccd9b8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xccd9bc: ldr             x8, [x8, #0x3c0]
    // 0xccd9c0: r3 = Null
    //     0xccd9c0: add             x3, PP, #0x99, lsl #12  ; [pp+0x99f88] Null
    //     0xccd9c4: ldr             x3, [x3, #0xf88]
    // 0xccd9c8: r0 = DefaultTypeTest()
    //     0xccd9c8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xccd9cc: ldur            x0, [fp, #-8]
    // 0xccd9d0: LoadField: d0 = r0->field_2b
    //     0xccd9d0: ldur            d0, [x0, #0x2b]
    // 0xccd9d4: ldur            d1, [fp, #-0x68]
    // 0xccd9d8: fcmp            d0, d1
    // 0xccd9dc: b.le            #0xccda2c
    // 0xccd9e0: ldur            x3, [fp, #-0x10]
    // 0xccd9e4: r0 = LoadClassIdInstr(r3)
    //     0xccd9e4: ldur            x0, [x3, #-1]
    //     0xccd9e8: ubfx            x0, x0, #0xc, #0x14
    // 0xccd9ec: mov             x1, x3
    // 0xccd9f0: ldur            x2, [fp, #-0x20]
    // 0xccd9f4: r0 = GDT[cid_x0 + 0x2f60]()
    //     0xccd9f4: mov             x17, #0x2f60
    //     0xccd9f8: add             lr, x0, x17
    //     0xccd9fc: ldr             lr, [x21, lr, lsl #3]
    //     0xccda00: blr             lr
    // 0xccda04: mov             v1.16b, v0.16b
    // 0xccda08: ldur            d0, [fp, #-0x68]
    // 0xccda0c: fadd            d2, d0, d1
    // 0xccda10: d0 = 0.000000
    //     0xccda10: eor             v0.16b, v0.16b, v0.16b
    // 0xccda14: fcmp            d2, d0
    // 0xccda18: b.le            #0xccda2c
    // 0xccda1c: ldur            x1, [fp, #-0x18]
    // 0xccda20: ldur            x2, [fp, #-0x20]
    // 0xccda24: ldur            x3, [fp, #-0x30]
    // 0xccda28: r0 = paintChild()
    //     0xccda28: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xccda2c: ldur            x0, [fp, #-0x20]
    // 0xccda30: LoadField: r3 = r0->field_7
    //     0xccda30: ldur            w3, [x0, #7]
    // 0xccda34: DecompressPointer r3
    //     0xccda34: add             x3, x3, HEAP, lsl #32
    // 0xccda38: stur            x3, [fp, #-8]
    // 0xccda3c: cmp             w3, NULL
    // 0xccda40: b.eq            #0xccdb38
    // 0xccda44: mov             x0, x3
    // 0xccda48: r2 = Null
    //     0xccda48: mov             x2, NULL
    // 0xccda4c: r1 = Null
    //     0xccda4c: mov             x1, NULL
    // 0xccda50: r4 = LoadClassIdInstr(r0)
    //     0xccda50: ldur            x4, [x0, #-1]
    //     0xccda54: ubfx            x4, x4, #0xc, #0x14
    // 0xccda58: r17 = -4183
    //     0xccda58: mov             x17, #-0x1057
    // 0xccda5c: add             x4, x4, x17
    // 0xccda60: cmp             x4, #1
    // 0xccda64: b.ls            #0xccda7c
    // 0xccda68: r8 = SliverMultiBoxAdaptorParentData
    //     0xccda68: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xccda6c: ldr             x8, [x8, #0x590]
    // 0xccda70: r3 = Null
    //     0xccda70: add             x3, PP, #0x99, lsl #12  ; [pp+0x99f98] Null
    //     0xccda74: ldr             x3, [x3, #0xf98]
    // 0xccda78: r0 = DefaultTypeTest()
    //     0xccda78: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xccda7c: ldur            x0, [fp, #-8]
    // 0xccda80: LoadField: r5 = r0->field_f
    //     0xccda80: ldur            w5, [x0, #0xf]
    // 0xccda84: DecompressPointer r5
    //     0xccda84: add             x5, x5, HEAP, lsl #32
    // 0xccda88: ldur            x3, [fp, #-0x10]
    // 0xccda8c: ldur            x4, [fp, #-0x28]
    // 0xccda90: ldur            d0, [fp, #-0x60]
    // 0xccda94: ldur            d1, [fp, #-0x58]
    // 0xccda98: ldur            d2, [fp, #-0x50]
    // 0xccda9c: ldur            d3, [fp, #-0x48]
    // 0xccdaa0: ldur            d4, [fp, #-0x40]
    // 0xccdaa4: ldur            d5, [fp, #-0x38]
    // 0xccdaa8: b               #0xccd784
    // 0xccdaac: r0 = Null
    //     0xccdaac: mov             x0, NULL
    // 0xccdab0: LeaveFrame
    //     0xccdab0: mov             SP, fp
    //     0xccdab4: ldp             fp, lr, [SP], #0x10
    // 0xccdab8: ret
    //     0xccdab8: ret             
    // 0xccdabc: r0 = StateError()
    //     0xccdabc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccdac0: mov             x1, x0
    // 0xccdac4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xccdac4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xccdac8: StoreField: r1->field_b = r0
    //     0xccdac8: stur            w0, [x1, #0xb]
    // 0xccdacc: mov             x0, x1
    // 0xccdad0: r0 = Throw()
    //     0xccdad0: bl              #0x13ddb2c  ; ThrowStub
    // 0xccdad4: brk             #0
    // 0xccdad8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xccdad8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xccdadc: r0 = StateError()
    //     0xccdadc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccdae0: mov             x1, x0
    // 0xccdae4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xccdae4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xccdae8: StoreField: r1->field_b = r0
    //     0xccdae8: stur            w0, [x1, #0xb]
    // 0xccdaec: mov             x0, x1
    // 0xccdaf0: r0 = Throw()
    //     0xccdaf0: bl              #0x13ddb2c  ; ThrowStub
    // 0xccdaf4: brk             #0
    // 0xccdaf8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xccdaf8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xccdafc: r0 = StateError()
    //     0xccdafc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccdb00: mov             x1, x0
    // 0xccdb04: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xccdb04: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xccdb08: StoreField: r1->field_b = r0
    //     0xccdb08: stur            w0, [x1, #0xb]
    // 0xccdb0c: mov             x0, x1
    // 0xccdb10: r0 = Throw()
    //     0xccdb10: bl              #0x13ddb2c  ; ThrowStub
    // 0xccdb14: brk             #0
    // 0xccdb18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccdb18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccdb1c: b               #0xccd5f0
    // 0xccdb20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccdb20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xccdb24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccdb24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xccdb28: r0 = StackOverflowSharedWithFPURegs()
    //     0xccdb28: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xccdb2c: b               #0xccd794
    // 0xccdb30: r0 = NullCastErrorSharedWithFPURegs()
    //     0xccdb30: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xccdb34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccdb34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xccdb38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccdb38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x1143ed8, size: 0x140
    // 0x1143ed8: EnterFrame
    //     0x1143ed8: stp             fp, lr, [SP, #-0x10]!
    //     0x1143edc: mov             fp, SP
    // 0x1143ee0: AllocStack(0x38)
    //     0x1143ee0: sub             SP, SP, #0x38
    // 0x1143ee4: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* d0 => d0, fp-0x30 */, dynamic _ /* d1 => d1, fp-0x38 */)
    //     0x1143ee4: stur            x1, [fp, #-0x18]
    //     0x1143ee8: stur            x2, [fp, #-0x20]
    //     0x1143eec: stur            d0, [fp, #-0x30]
    //     0x1143ef0: stur            d1, [fp, #-0x38]
    // 0x1143ef4: CheckStackOverflow
    //     0x1143ef4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1143ef8: cmp             SP, x16
    //     0x1143efc: b.ls            #0x1144004
    // 0x1143f00: LoadField: r0 = r1->field_57
    //     0x1143f00: ldur            w0, [x1, #0x57]
    // 0x1143f04: DecompressPointer r0
    //     0x1143f04: add             x0, x0, HEAP, lsl #32
    // 0x1143f08: stur            x0, [fp, #-0x10]
    // 0x1143f0c: LoadField: r3 = r2->field_7
    //     0x1143f0c: ldur            w3, [x2, #7]
    // 0x1143f10: DecompressPointer r3
    //     0x1143f10: add             x3, x3, HEAP, lsl #32
    // 0x1143f14: stur            x3, [fp, #-8]
    // 0x1143f18: r0 = BoxHitTestResult()
    //     0x1143f18: bl              #0x836ba0  ; AllocateBoxHitTestResultStub -> BoxHitTestResult (size=0x14)
    // 0x1143f1c: mov             x4, x0
    // 0x1143f20: ldur            x0, [fp, #-8]
    // 0x1143f24: stur            x4, [fp, #-0x28]
    // 0x1143f28: StoreField: r4->field_7 = r0
    //     0x1143f28: stur            w0, [x4, #7]
    // 0x1143f2c: ldur            x0, [fp, #-0x20]
    // 0x1143f30: LoadField: r1 = r0->field_b
    //     0x1143f30: ldur            w1, [x0, #0xb]
    // 0x1143f34: DecompressPointer r1
    //     0x1143f34: add             x1, x1, HEAP, lsl #32
    // 0x1143f38: StoreField: r4->field_b = r1
    //     0x1143f38: stur            w1, [x4, #0xb]
    // 0x1143f3c: LoadField: r1 = r0->field_f
    //     0x1143f3c: ldur            w1, [x0, #0xf]
    // 0x1143f40: DecompressPointer r1
    //     0x1143f40: add             x1, x1, HEAP, lsl #32
    // 0x1143f44: StoreField: r4->field_f = r1
    //     0x1143f44: stur            w1, [x4, #0xf]
    // 0x1143f48: ldur            x0, [fp, #-0x10]
    // 0x1143f4c: stur            x0, [fp, #-8]
    // 0x1143f50: CheckStackOverflow
    //     0x1143f50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1143f54: cmp             SP, x16
    //     0x1143f58: b.ls            #0x114400c
    // 0x1143f5c: cmp             w0, NULL
    // 0x1143f60: b.eq            #0x1143ff4
    // 0x1143f64: ldur            x1, [fp, #-0x18]
    // 0x1143f68: mov             x2, x4
    // 0x1143f6c: mov             x3, x0
    // 0x1143f70: ldur            d0, [fp, #-0x30]
    // 0x1143f74: ldur            d1, [fp, #-0x38]
    // 0x1143f78: r0 = hitTestBoxChild()
    //     0x1143f78: bl              #0x1144018  ; [dart:mixin_deduplication] _MixinApplication21&RenderSliver&ContainerRenderObjectMixin&RenderSliverHelpers::hitTestBoxChild
    // 0x1143f7c: tbz             w0, #4, #0x1143fe4
    // 0x1143f80: ldur            x0, [fp, #-8]
    // 0x1143f84: LoadField: r3 = r0->field_7
    //     0x1143f84: ldur            w3, [x0, #7]
    // 0x1143f88: DecompressPointer r3
    //     0x1143f88: add             x3, x3, HEAP, lsl #32
    // 0x1143f8c: stur            x3, [fp, #-0x10]
    // 0x1143f90: cmp             w3, NULL
    // 0x1143f94: b.eq            #0x1144014
    // 0x1143f98: mov             x0, x3
    // 0x1143f9c: r2 = Null
    //     0x1143f9c: mov             x2, NULL
    // 0x1143fa0: r1 = Null
    //     0x1143fa0: mov             x1, NULL
    // 0x1143fa4: r4 = LoadClassIdInstr(r0)
    //     0x1143fa4: ldur            x4, [x0, #-1]
    //     0x1143fa8: ubfx            x4, x4, #0xc, #0x14
    // 0x1143fac: r17 = -4183
    //     0x1143fac: mov             x17, #-0x1057
    // 0x1143fb0: add             x4, x4, x17
    // 0x1143fb4: cmp             x4, #1
    // 0x1143fb8: b.ls            #0x1143fd0
    // 0x1143fbc: r8 = SliverMultiBoxAdaptorParentData
    //     0x1143fbc: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0x1143fc0: ldr             x8, [x8, #0x590]
    // 0x1143fc4: r3 = Null
    //     0x1143fc4: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa40e0] Null
    //     0x1143fc8: ldr             x3, [x3, #0xe0]
    // 0x1143fcc: r0 = DefaultTypeTest()
    //     0x1143fcc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1143fd0: ldur            x1, [fp, #-0x10]
    // 0x1143fd4: LoadField: r0 = r1->field_b
    //     0x1143fd4: ldur            w0, [x1, #0xb]
    // 0x1143fd8: DecompressPointer r0
    //     0x1143fd8: add             x0, x0, HEAP, lsl #32
    // 0x1143fdc: ldur            x4, [fp, #-0x28]
    // 0x1143fe0: b               #0x1143f4c
    // 0x1143fe4: r0 = true
    //     0x1143fe4: add             x0, NULL, #0x20  ; true
    // 0x1143fe8: LeaveFrame
    //     0x1143fe8: mov             SP, fp
    //     0x1143fec: ldp             fp, lr, [SP], #0x10
    // 0x1143ff0: ret
    //     0x1143ff0: ret             
    // 0x1143ff4: r0 = false
    //     0x1143ff4: add             x0, NULL, #0x30  ; false
    // 0x1143ff8: LeaveFrame
    //     0x1143ff8: mov             SP, fp
    //     0x1143ffc: ldp             fp, lr, [SP], #0x10
    // 0x1144000: ret
    //     0x1144000: ret             
    // 0x1144004: r0 = StackOverflowSharedWithFPURegs()
    //     0x1144004: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x1144008: b               #0x1143f00
    // 0x114400c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114400c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1144010: b               #0x1143f5c
    // 0x1144014: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1144014: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ childScrollOffset(/* No info */) {
    // ** addr: 0x115a734, size: 0x74
    // 0x115a734: EnterFrame
    //     0x115a734: stp             fp, lr, [SP, #-0x10]!
    //     0x115a738: mov             fp, SP
    // 0x115a73c: AllocStack(0x8)
    //     0x115a73c: sub             SP, SP, #8
    // 0x115a740: LoadField: r3 = r2->field_7
    //     0x115a740: ldur            w3, [x2, #7]
    // 0x115a744: DecompressPointer r3
    //     0x115a744: add             x3, x3, HEAP, lsl #32
    // 0x115a748: stur            x3, [fp, #-8]
    // 0x115a74c: cmp             w3, NULL
    // 0x115a750: b.eq            #0x115a7a4
    // 0x115a754: mov             x0, x3
    // 0x115a758: r2 = Null
    //     0x115a758: mov             x2, NULL
    // 0x115a75c: r1 = Null
    //     0x115a75c: mov             x1, NULL
    // 0x115a760: r4 = LoadClassIdInstr(r0)
    //     0x115a760: ldur            x4, [x0, #-1]
    //     0x115a764: ubfx            x4, x4, #0xc, #0x14
    // 0x115a768: r17 = -4183
    //     0x115a768: mov             x17, #-0x1057
    // 0x115a76c: add             x4, x4, x17
    // 0x115a770: cmp             x4, #1
    // 0x115a774: b.ls            #0x115a78c
    // 0x115a778: r8 = SliverMultiBoxAdaptorParentData
    //     0x115a778: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0x115a77c: ldr             x8, [x8, #0x590]
    // 0x115a780: r3 = Null
    //     0x115a780: add             x3, PP, #0xa4, lsl #12  ; [pp+0xa40d0] Null
    //     0x115a784: ldr             x3, [x3, #0xd0]
    // 0x115a788: r0 = DefaultTypeTest()
    //     0x115a788: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x115a78c: ldur            x1, [fp, #-8]
    // 0x115a790: LoadField: r0 = r1->field_7
    //     0x115a790: ldur            w0, [x1, #7]
    // 0x115a794: DecompressPointer r0
    //     0x115a794: add             x0, x0, HEAP, lsl #32
    // 0x115a798: LeaveFrame
    //     0x115a798: mov             SP, fp
    //     0x115a79c: ldp             fp, lr, [SP], #0x10
    // 0x115a7a0: ret
    //     0x115a7a0: ret             
    // 0x115a7a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115a7a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintExtentOf(/* No info */) {
    // ** addr: 0x1185dbc, size: 0xc4
    // 0x1185dbc: EnterFrame
    //     0x1185dbc: stp             fp, lr, [SP, #-0x10]!
    //     0x1185dc0: mov             fp, SP
    // 0x1185dc4: AllocStack(0x10)
    //     0x1185dc4: sub             SP, SP, #0x10
    // 0x1185dc8: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1185dc8: mov             x3, x2
    //     0x1185dcc: stur            x2, [fp, #-0x10]
    // 0x1185dd0: CheckStackOverflow
    //     0x1185dd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1185dd4: cmp             SP, x16
    //     0x1185dd8: b.ls            #0x1185e78
    // 0x1185ddc: LoadField: r4 = r1->field_27
    //     0x1185ddc: ldur            w4, [x1, #0x27]
    // 0x1185de0: DecompressPointer r4
    //     0x1185de0: add             x4, x4, HEAP, lsl #32
    // 0x1185de4: stur            x4, [fp, #-8]
    // 0x1185de8: cmp             w4, NULL
    // 0x1185dec: b.eq            #0x1185e5c
    // 0x1185df0: mov             x0, x4
    // 0x1185df4: r2 = Null
    //     0x1185df4: mov             x2, NULL
    // 0x1185df8: r1 = Null
    //     0x1185df8: mov             x1, NULL
    // 0x1185dfc: r4 = LoadClassIdInstr(r0)
    //     0x1185dfc: ldur            x4, [x0, #-1]
    //     0x1185e00: ubfx            x4, x4, #0xc, #0x14
    // 0x1185e04: cmp             x4, #0xb45
    // 0x1185e08: b.eq            #0x1185e20
    // 0x1185e0c: r8 = SliverConstraints
    //     0x1185e0c: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x1185e10: ldr             x8, [x8, #0x3c0]
    // 0x1185e14: r3 = Null
    //     0x1185e14: add             x3, PP, #0x96, lsl #12  ; [pp+0x96798] Null
    //     0x1185e18: ldr             x3, [x3, #0x798]
    // 0x1185e1c: r0 = DefaultTypeTest()
    //     0x1185e1c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1185e20: ldur            x1, [fp, #-8]
    // 0x1185e24: r0 = axis()
    //     0x1185e24: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x1185e28: LoadField: r1 = r0->field_7
    //     0x1185e28: ldur            x1, [x0, #7]
    // 0x1185e2c: cmp             x1, #0
    // 0x1185e30: b.gt            #0x1185e44
    // 0x1185e34: ldur            x1, [fp, #-0x10]
    // 0x1185e38: r0 = size()
    //     0x1185e38: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x1185e3c: LoadField: d0 = r0->field_7
    //     0x1185e3c: ldur            d0, [x0, #7]
    // 0x1185e40: b               #0x1185e50
    // 0x1185e44: ldur            x1, [fp, #-0x10]
    // 0x1185e48: r0 = size()
    //     0x1185e48: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x1185e4c: LoadField: d0 = r0->field_f
    //     0x1185e4c: ldur            d0, [x0, #0xf]
    // 0x1185e50: LeaveFrame
    //     0x1185e50: mov             SP, fp
    //     0x1185e54: ldp             fp, lr, [SP], #0x10
    // 0x1185e58: ret
    //     0x1185e58: ret             
    // 0x1185e5c: r0 = StateError()
    //     0x1185e5c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x1185e60: mov             x1, x0
    // 0x1185e64: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x1185e64: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x1185e68: StoreField: r1->field_b = r0
    //     0x1185e68: stur            w0, [x1, #0xb]
    // 0x1185e6c: mov             x0, x1
    // 0x1185e70: r0 = Throw()
    //     0x1185e70: bl              #0x13ddb2c  ; ThrowStub
    // 0x1185e74: brk             #0
    // 0x1185e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1185e78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1185e7c: b               #0x1185ddc
  }
  _ RenderSliverMultiBoxAdaptor(/* No info */) {
    // ** addr: 0x11d4bf0, size: 0x98
    // 0x11d4bf0: EnterFrame
    //     0x11d4bf0: stp             fp, lr, [SP, #-0x10]!
    //     0x11d4bf4: mov             fp, SP
    // 0x11d4bf8: AllocStack(0x20)
    //     0x11d4bf8: sub             SP, SP, #0x20
    // 0x11d4bfc: SetupParameters(RenderSliverMultiBoxAdaptor this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x11d4bfc: mov             x0, x2
    //     0x11d4c00: stur            x1, [fp, #-8]
    //     0x11d4c04: stur            x2, [fp, #-0x10]
    // 0x11d4c08: CheckStackOverflow
    //     0x11d4c08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d4c0c: cmp             SP, x16
    //     0x11d4c10: b.ls            #0x11d4c80
    // 0x11d4c14: r16 = <int, RenderBox>
    //     0x11d4c14: add             x16, PP, #0x8c, lsl #12  ; [pp+0x8cfa8] TypeArguments: <int, RenderBox>
    //     0x11d4c18: ldr             x16, [x16, #0xfa8]
    // 0x11d4c1c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x11d4c20: stp             lr, x16, [SP]
    // 0x11d4c24: r0 = Map._fromLiteral()
    //     0x11d4c24: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x11d4c28: ldur            x1, [fp, #-8]
    // 0x11d4c2c: StoreField: r1->field_5f = r0
    //     0x11d4c2c: stur            w0, [x1, #0x5f]
    //     0x11d4c30: ldurb           w16, [x1, #-1]
    //     0x11d4c34: ldurb           w17, [x0, #-1]
    //     0x11d4c38: and             x16, x17, x16, lsr #2
    //     0x11d4c3c: tst             x16, HEAP, lsr #32
    //     0x11d4c40: b.eq            #0x11d4c48
    //     0x11d4c44: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d4c48: ldur            x0, [fp, #-0x10]
    // 0x11d4c4c: StoreField: r1->field_5b = r0
    //     0x11d4c4c: stur            w0, [x1, #0x5b]
    //     0x11d4c50: ldurb           w16, [x1, #-1]
    //     0x11d4c54: ldurb           w17, [x0, #-1]
    //     0x11d4c58: and             x16, x17, x16, lsr #2
    //     0x11d4c5c: tst             x16, HEAP, lsr #32
    //     0x11d4c60: b.eq            #0x11d4c68
    //     0x11d4c64: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d4c68: StoreField: r1->field_4b = rZR
    //     0x11d4c68: stur            xzr, [x1, #0x4b]
    // 0x11d4c6c: r0 = RenderObject()
    //     0x11d4c6c: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d4c70: r0 = Null
    //     0x11d4c70: mov             x0, NULL
    // 0x11d4c74: LeaveFrame
    //     0x11d4c74: mov             SP, fp
    //     0x11d4c78: ldp             fp, lr, [SP], #0x10
    // 0x11d4c7c: ret
    //     0x11d4c7c: ret             
    // 0x11d4c80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d4c80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d4c84: b               #0x11d4c14
  }
}
