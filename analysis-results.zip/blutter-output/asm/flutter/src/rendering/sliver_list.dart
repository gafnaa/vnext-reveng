// lib: , url: package:flutter/src/rendering/sliver_list.dart

// class id: 1049046, size: 0x8
class :: {
}

// class id: 4697, size: 0x64, field offset: 0x64
class RenderSliverList extends RenderSliverMultiBoxAdaptor {

  _ performLayout(/* No info */) {
    // ** addr: 0xbe8b50, size: 0x15bc
    // 0xbe8b50: EnterFrame
    //     0xbe8b50: stp             fp, lr, [SP, #-0x10]!
    //     0xbe8b54: mov             fp, SP
    // 0xbe8b58: AllocStack(0x98)
    //     0xbe8b58: sub             SP, SP, #0x98
    // 0xbe8b5c: SetupParameters(RenderSliverList this /* r1 => r1, fp-0x8 */)
    //     0xbe8b5c: stur            x1, [fp, #-8]
    // 0xbe8b60: CheckStackOverflow
    //     0xbe8b60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe8b64: cmp             SP, x16
    //     0xbe8b68: b.ls            #0xbe9fbc
    // 0xbe8b6c: r1 = 7
    //     0xbe8b6c: mov             x1, #7
    // 0xbe8b70: r0 = AllocateContext()
    //     0xbe8b70: bl              #0x13de838  ; AllocateContextStub
    // 0xbe8b74: mov             x4, x0
    // 0xbe8b78: ldur            x3, [fp, #-8]
    // 0xbe8b7c: stur            x4, [fp, #-0x18]
    // 0xbe8b80: StoreField: r4->field_f = r3
    //     0xbe8b80: stur            w3, [x4, #0xf]
    // 0xbe8b84: LoadField: r5 = r3->field_27
    //     0xbe8b84: ldur            w5, [x3, #0x27]
    // 0xbe8b88: DecompressPointer r5
    //     0xbe8b88: add             x5, x5, HEAP, lsl #32
    // 0xbe8b8c: stur            x5, [fp, #-0x10]
    // 0xbe8b90: cmp             w5, NULL
    // 0xbe8b94: b.eq            #0xbe9f60
    // 0xbe8b98: mov             x0, x5
    // 0xbe8b9c: r2 = Null
    //     0xbe8b9c: mov             x2, NULL
    // 0xbe8ba0: r1 = Null
    //     0xbe8ba0: mov             x1, NULL
    // 0xbe8ba4: r4 = LoadClassIdInstr(r0)
    //     0xbe8ba4: ldur            x4, [x0, #-1]
    //     0xbe8ba8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8bac: cmp             x4, #0xb45
    // 0xbe8bb0: b.eq            #0xbe8bc8
    // 0xbe8bb4: r8 = SliverConstraints
    //     0xbe8bb4: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe8bb8: ldr             x8, [x8, #0x3c0]
    // 0xbe8bbc: r3 = Null
    //     0xbe8bbc: add             x3, PP, #0x96, lsl #12  ; [pp+0x96578] Null
    //     0xbe8bc0: ldr             x3, [x3, #0x578]
    // 0xbe8bc4: r0 = DefaultTypeTest()
    //     0xbe8bc4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe8bc8: ldur            x0, [fp, #-8]
    // 0xbe8bcc: LoadField: r2 = r0->field_5b
    //     0xbe8bcc: ldur            w2, [x0, #0x5b]
    // 0xbe8bd0: DecompressPointer r2
    //     0xbe8bd0: add             x2, x2, HEAP, lsl #32
    // 0xbe8bd4: stur            x2, [fp, #-0x20]
    // 0xbe8bd8: r3 = false
    //     0xbe8bd8: add             x3, NULL, #0x30  ; false
    // 0xbe8bdc: StoreField: r2->field_53 = r3
    //     0xbe8bdc: stur            w3, [x2, #0x53]
    // 0xbe8be0: ldur            x4, [fp, #-0x10]
    // 0xbe8be4: LoadField: d0 = r4->field_13
    //     0xbe8be4: ldur            d0, [x4, #0x13]
    // 0xbe8be8: stur            d0, [fp, #-0x80]
    // 0xbe8bec: LoadField: d1 = r4->field_47
    //     0xbe8bec: ldur            d1, [x4, #0x47]
    // 0xbe8bf0: fadd            d2, d0, d1
    // 0xbe8bf4: stur            d2, [fp, #-0x78]
    // 0xbe8bf8: LoadField: d1 = r4->field_4f
    //     0xbe8bf8: ldur            d1, [x4, #0x4f]
    // 0xbe8bfc: fadd            d3, d2, d1
    // 0xbe8c00: mov             x1, x4
    // 0xbe8c04: stur            d3, [fp, #-0x70]
    // 0xbe8c08: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbe8c08: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbe8c0c: r0 = asBoxConstraints()
    //     0xbe8c0c: bl              #0xbe58b0  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0xbe8c10: mov             x3, x0
    // 0xbe8c14: ldur            x2, [fp, #-0x18]
    // 0xbe8c18: stur            x3, [fp, #-0x28]
    // 0xbe8c1c: StoreField: r2->field_13 = r0
    //     0xbe8c1c: stur            w0, [x2, #0x13]
    //     0xbe8c20: ldurb           w16, [x2, #-1]
    //     0xbe8c24: ldurb           w17, [x0, #-1]
    //     0xbe8c28: and             x16, x17, x16, lsr #2
    //     0xbe8c2c: tst             x16, HEAP, lsr #32
    //     0xbe8c30: b.eq            #0xbe8c38
    //     0xbe8c34: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbe8c38: ldur            x0, [fp, #-8]
    // 0xbe8c3c: LoadField: r1 = r0->field_53
    //     0xbe8c3c: ldur            w1, [x0, #0x53]
    // 0xbe8c40: DecompressPointer r1
    //     0xbe8c40: add             x1, x1, HEAP, lsl #32
    // 0xbe8c44: cmp             w1, NULL
    // 0xbe8c48: b.ne            #0xbe8c94
    // 0xbe8c4c: mov             x1, x0
    // 0xbe8c50: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbe8c50: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbe8c54: r0 = addInitialChild()
    //     0xbe8c54: bl              #0xbe60b8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0xbe8c58: tbz             w0, #4, #0xbe8c84
    // 0xbe8c5c: ldur            x3, [fp, #-8]
    // 0xbe8c60: r4 = Instance_SliverGeometry
    //     0xbe8c60: add             x4, PP, #0x96, lsl #12  ; [pp+0x96588] Obj!SliverGeometry@12ad351
    //     0xbe8c64: ldr             x4, [x4, #0x588]
    // 0xbe8c68: StoreField: r3->field_47 = r4
    //     0xbe8c68: stur            w4, [x3, #0x47]
    // 0xbe8c6c: ldur            x1, [fp, #-0x20]
    // 0xbe8c70: r0 = didFinishLayout()
    //     0xbe8c70: bl              #0xbe5ab0  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0xbe8c74: r0 = Null
    //     0xbe8c74: mov             x0, NULL
    // 0xbe8c78: LeaveFrame
    //     0xbe8c78: mov             SP, fp
    //     0xbe8c7c: ldp             fp, lr, [SP], #0x10
    // 0xbe8c80: ret
    //     0xbe8c80: ret             
    // 0xbe8c84: ldur            x3, [fp, #-8]
    // 0xbe8c88: r4 = Instance_SliverGeometry
    //     0xbe8c88: add             x4, PP, #0x96, lsl #12  ; [pp+0x96588] Obj!SliverGeometry@12ad351
    //     0xbe8c8c: ldr             x4, [x4, #0x588]
    // 0xbe8c90: b               #0xbe8ca0
    // 0xbe8c94: mov             x3, x0
    // 0xbe8c98: r4 = Instance_SliverGeometry
    //     0xbe8c98: add             x4, PP, #0x96, lsl #12  ; [pp+0x96588] Obj!SliverGeometry@12ad351
    //     0xbe8c9c: ldr             x4, [x4, #0x588]
    // 0xbe8ca0: ldur            x5, [fp, #-0x18]
    // 0xbe8ca4: ArrayStore: r5[0] = rNULL  ; List_4
    //     0xbe8ca4: stur            NULL, [x5, #0x17]
    // 0xbe8ca8: LoadField: r6 = r3->field_53
    //     0xbe8ca8: ldur            w6, [x3, #0x53]
    // 0xbe8cac: DecompressPointer r6
    //     0xbe8cac: add             x6, x6, HEAP, lsl #32
    // 0xbe8cb0: stur            x6, [fp, #-0x38]
    // 0xbe8cb4: cmp             w6, NULL
    // 0xbe8cb8: b.eq            #0xbe9fc4
    // 0xbe8cbc: LoadField: r7 = r6->field_7
    //     0xbe8cbc: ldur            w7, [x6, #7]
    // 0xbe8cc0: DecompressPointer r7
    //     0xbe8cc0: add             x7, x7, HEAP, lsl #32
    // 0xbe8cc4: stur            x7, [fp, #-0x30]
    // 0xbe8cc8: cmp             w7, NULL
    // 0xbe8ccc: b.eq            #0xbe9fc8
    // 0xbe8cd0: mov             x0, x7
    // 0xbe8cd4: r2 = Null
    //     0xbe8cd4: mov             x2, NULL
    // 0xbe8cd8: r1 = Null
    //     0xbe8cd8: mov             x1, NULL
    // 0xbe8cdc: r4 = LoadClassIdInstr(r0)
    //     0xbe8cdc: ldur            x4, [x0, #-1]
    //     0xbe8ce0: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8ce4: r17 = -4183
    //     0xbe8ce4: mov             x17, #-0x1057
    // 0xbe8ce8: add             x4, x4, x17
    // 0xbe8cec: cmp             x4, #1
    // 0xbe8cf0: b.ls            #0xbe8d08
    // 0xbe8cf4: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe8cf4: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe8cf8: ldr             x8, [x8, #0x590]
    // 0xbe8cfc: r3 = Null
    //     0xbe8cfc: add             x3, PP, #0x96, lsl #12  ; [pp+0x96598] Null
    //     0xbe8d00: ldr             x3, [x3, #0x598]
    // 0xbe8d04: r0 = DefaultTypeTest()
    //     0xbe8d04: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe8d08: ldur            x0, [fp, #-0x30]
    // 0xbe8d0c: LoadField: r1 = r0->field_7
    //     0xbe8d0c: ldur            w1, [x0, #7]
    // 0xbe8d10: DecompressPointer r1
    //     0xbe8d10: add             x1, x1, HEAP, lsl #32
    // 0xbe8d14: cmp             w1, NULL
    // 0xbe8d18: b.ne            #0xbe8e2c
    // 0xbe8d1c: ldur            x0, [fp, #-0x38]
    // 0xbe8d20: r3 = 0
    //     0xbe8d20: mov             x3, #0
    // 0xbe8d24: stur            x3, [fp, #-0x40]
    // 0xbe8d28: CheckStackOverflow
    //     0xbe8d28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe8d2c: cmp             SP, x16
    //     0xbe8d30: b.ls            #0xbe9fcc
    // 0xbe8d34: cmp             w0, NULL
    // 0xbe8d38: b.eq            #0xbe8dbc
    // 0xbe8d3c: LoadField: r4 = r0->field_7
    //     0xbe8d3c: ldur            w4, [x0, #7]
    // 0xbe8d40: DecompressPointer r4
    //     0xbe8d40: add             x4, x4, HEAP, lsl #32
    // 0xbe8d44: stur            x4, [fp, #-0x30]
    // 0xbe8d48: cmp             w4, NULL
    // 0xbe8d4c: b.eq            #0xbe9fd4
    // 0xbe8d50: mov             x0, x4
    // 0xbe8d54: r2 = Null
    //     0xbe8d54: mov             x2, NULL
    // 0xbe8d58: r1 = Null
    //     0xbe8d58: mov             x1, NULL
    // 0xbe8d5c: r4 = LoadClassIdInstr(r0)
    //     0xbe8d5c: ldur            x4, [x0, #-1]
    //     0xbe8d60: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8d64: r17 = -4183
    //     0xbe8d64: mov             x17, #-0x1057
    // 0xbe8d68: add             x4, x4, x17
    // 0xbe8d6c: cmp             x4, #1
    // 0xbe8d70: b.ls            #0xbe8d88
    // 0xbe8d74: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe8d74: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe8d78: ldr             x8, [x8, #0x590]
    // 0xbe8d7c: r3 = Null
    //     0xbe8d7c: add             x3, PP, #0x96, lsl #12  ; [pp+0x965a8] Null
    //     0xbe8d80: ldr             x3, [x3, #0x5a8]
    // 0xbe8d84: r0 = DefaultTypeTest()
    //     0xbe8d84: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe8d88: ldur            x0, [fp, #-0x30]
    // 0xbe8d8c: LoadField: r1 = r0->field_7
    //     0xbe8d8c: ldur            w1, [x0, #7]
    // 0xbe8d90: DecompressPointer r1
    //     0xbe8d90: add             x1, x1, HEAP, lsl #32
    // 0xbe8d94: cmp             w1, NULL
    // 0xbe8d98: b.ne            #0xbe8db4
    // 0xbe8d9c: ldur            x2, [fp, #-0x40]
    // 0xbe8da0: LoadField: r1 = r0->field_f
    //     0xbe8da0: ldur            w1, [x0, #0xf]
    // 0xbe8da4: DecompressPointer r1
    //     0xbe8da4: add             x1, x1, HEAP, lsl #32
    // 0xbe8da8: add             x3, x2, #1
    // 0xbe8dac: mov             x0, x1
    // 0xbe8db0: b               #0xbe8d24
    // 0xbe8db4: ldur            x2, [fp, #-0x40]
    // 0xbe8db8: b               #0xbe8dc0
    // 0xbe8dbc: mov             x2, x3
    // 0xbe8dc0: ldur            x0, [fp, #-8]
    // 0xbe8dc4: mov             x1, x0
    // 0xbe8dc8: r3 = 0
    //     0xbe8dc8: mov             x3, #0
    // 0xbe8dcc: r0 = collectGarbage()
    //     0xbe8dcc: bl              #0xbe64f8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0xbe8dd0: ldur            x0, [fp, #-8]
    // 0xbe8dd4: LoadField: r1 = r0->field_53
    //     0xbe8dd4: ldur            w1, [x0, #0x53]
    // 0xbe8dd8: DecompressPointer r1
    //     0xbe8dd8: add             x1, x1, HEAP, lsl #32
    // 0xbe8ddc: cmp             w1, NULL
    // 0xbe8de0: b.ne            #0xbe8e24
    // 0xbe8de4: mov             x1, x0
    // 0xbe8de8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbe8de8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbe8dec: r0 = addInitialChild()
    //     0xbe8dec: bl              #0xbe60b8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0xbe8df0: tbz             w0, #4, #0xbe8e1c
    // 0xbe8df4: ldur            x3, [fp, #-8]
    // 0xbe8df8: r0 = Instance_SliverGeometry
    //     0xbe8df8: add             x0, PP, #0x96, lsl #12  ; [pp+0x96588] Obj!SliverGeometry@12ad351
    //     0xbe8dfc: ldr             x0, [x0, #0x588]
    // 0xbe8e00: StoreField: r3->field_47 = r0
    //     0xbe8e00: stur            w0, [x3, #0x47]
    // 0xbe8e04: ldur            x1, [fp, #-0x20]
    // 0xbe8e08: r0 = didFinishLayout()
    //     0xbe8e08: bl              #0xbe5ab0  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0xbe8e0c: r0 = Null
    //     0xbe8e0c: mov             x0, NULL
    // 0xbe8e10: LeaveFrame
    //     0xbe8e10: mov             SP, fp
    //     0xbe8e14: ldp             fp, lr, [SP], #0x10
    // 0xbe8e18: ret
    //     0xbe8e18: ret             
    // 0xbe8e1c: ldur            x3, [fp, #-8]
    // 0xbe8e20: b               #0xbe8e30
    // 0xbe8e24: mov             x3, x0
    // 0xbe8e28: b               #0xbe8e30
    // 0xbe8e2c: ldur            x3, [fp, #-8]
    // 0xbe8e30: LoadField: r4 = r3->field_53
    //     0xbe8e30: ldur            w4, [x3, #0x53]
    // 0xbe8e34: DecompressPointer r4
    //     0xbe8e34: add             x4, x4, HEAP, lsl #32
    // 0xbe8e38: stur            x4, [fp, #-0x38]
    // 0xbe8e3c: cmp             w4, NULL
    // 0xbe8e40: b.eq            #0xbe9fd8
    // 0xbe8e44: LoadField: r5 = r4->field_7
    //     0xbe8e44: ldur            w5, [x4, #7]
    // 0xbe8e48: DecompressPointer r5
    //     0xbe8e48: add             x5, x5, HEAP, lsl #32
    // 0xbe8e4c: stur            x5, [fp, #-0x30]
    // 0xbe8e50: cmp             w5, NULL
    // 0xbe8e54: b.eq            #0xbe9fdc
    // 0xbe8e58: mov             x0, x5
    // 0xbe8e5c: r2 = Null
    //     0xbe8e5c: mov             x2, NULL
    // 0xbe8e60: r1 = Null
    //     0xbe8e60: mov             x1, NULL
    // 0xbe8e64: r4 = LoadClassIdInstr(r0)
    //     0xbe8e64: ldur            x4, [x0, #-1]
    //     0xbe8e68: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8e6c: r17 = -4183
    //     0xbe8e6c: mov             x17, #-0x1057
    // 0xbe8e70: add             x4, x4, x17
    // 0xbe8e74: cmp             x4, #1
    // 0xbe8e78: b.ls            #0xbe8e90
    // 0xbe8e7c: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe8e7c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe8e80: ldr             x8, [x8, #0x590]
    // 0xbe8e84: r3 = Null
    //     0xbe8e84: add             x3, PP, #0x96, lsl #12  ; [pp+0x965b8] Null
    //     0xbe8e88: ldr             x3, [x3, #0x5b8]
    // 0xbe8e8c: r0 = DefaultTypeTest()
    //     0xbe8e8c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe8e90: ldur            x0, [fp, #-0x30]
    // 0xbe8e94: LoadField: r1 = r0->field_7
    //     0xbe8e94: ldur            w1, [x0, #7]
    // 0xbe8e98: DecompressPointer r1
    //     0xbe8e98: add             x1, x1, HEAP, lsl #32
    // 0xbe8e9c: cmp             w1, NULL
    // 0xbe8ea0: b.eq            #0xbe9fe0
    // 0xbe8ea4: LoadField: d0 = r1->field_7
    //     0xbe8ea4: ldur            d0, [x1, #7]
    // 0xbe8ea8: ldur            x1, [fp, #-0x38]
    // 0xbe8eac: mov             v1.16b, v0.16b
    // 0xbe8eb0: ldur            x3, [fp, #-0x18]
    // 0xbe8eb4: r2 = Null
    //     0xbe8eb4: mov             x2, NULL
    // 0xbe8eb8: ldur            x0, [fp, #-8]
    // 0xbe8ebc: ldur            d0, [fp, #-0x78]
    // 0xbe8ec0: stur            d1, [fp, #-0x88]
    // 0xbe8ec4: CheckStackOverflow
    //     0xbe8ec4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe8ec8: cmp             SP, x16
    //     0xbe8ecc: b.ls            #0xbe9fe4
    // 0xbe8ed0: fcmp            d1, d0
    // 0xbe8ed4: b.le            #0xbe9394
    // 0xbe8ed8: r16 = true
    //     0xbe8ed8: add             x16, NULL, #0x20  ; true
    // 0xbe8edc: str             x16, [SP]
    // 0xbe8ee0: mov             x1, x0
    // 0xbe8ee4: ldur            x2, [fp, #-0x28]
    // 0xbe8ee8: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbe8ee8: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbe8eec: ldr             x4, [x4, #0xed0]
    // 0xbe8ef0: r0 = insertAndLayoutLeadingChild()
    //     0xbe8ef0: bl              #0xbe5694  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0xbe8ef4: mov             x3, x0
    // 0xbe8ef8: stur            x3, [fp, #-0x48]
    // 0xbe8efc: cmp             w3, NULL
    // 0xbe8f00: b.eq            #0xbe91b4
    // 0xbe8f04: ldur            x4, [fp, #-8]
    // 0xbe8f08: LoadField: r5 = r4->field_53
    //     0xbe8f08: ldur            w5, [x4, #0x53]
    // 0xbe8f0c: DecompressPointer r5
    //     0xbe8f0c: add             x5, x5, HEAP, lsl #32
    // 0xbe8f10: stur            x5, [fp, #-0x38]
    // 0xbe8f14: cmp             w5, NULL
    // 0xbe8f18: b.eq            #0xbe9fec
    // 0xbe8f1c: LoadField: r6 = r4->field_27
    //     0xbe8f1c: ldur            w6, [x4, #0x27]
    // 0xbe8f20: DecompressPointer r6
    //     0xbe8f20: add             x6, x6, HEAP, lsl #32
    // 0xbe8f24: stur            x6, [fp, #-0x30]
    // 0xbe8f28: cmp             w6, NULL
    // 0xbe8f2c: b.eq            #0xbe9f7c
    // 0xbe8f30: mov             x0, x6
    // 0xbe8f34: r2 = Null
    //     0xbe8f34: mov             x2, NULL
    // 0xbe8f38: r1 = Null
    //     0xbe8f38: mov             x1, NULL
    // 0xbe8f3c: r4 = LoadClassIdInstr(r0)
    //     0xbe8f3c: ldur            x4, [x0, #-1]
    //     0xbe8f40: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8f44: cmp             x4, #0xb45
    // 0xbe8f48: b.eq            #0xbe8f60
    // 0xbe8f4c: r8 = SliverConstraints
    //     0xbe8f4c: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe8f50: ldr             x8, [x8, #0x3c0]
    // 0xbe8f54: r3 = Null
    //     0xbe8f54: add             x3, PP, #0x96, lsl #12  ; [pp+0x965c8] Null
    //     0xbe8f58: ldr             x3, [x3, #0x5c8]
    // 0xbe8f5c: r0 = DefaultTypeTest()
    //     0xbe8f5c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe8f60: ldur            x1, [fp, #-0x30]
    // 0xbe8f64: r0 = axis()
    //     0xbe8f64: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe8f68: LoadField: r1 = r0->field_7
    //     0xbe8f68: ldur            x1, [x0, #7]
    // 0xbe8f6c: cmp             x1, #0
    // 0xbe8f70: b.gt            #0xbe8f88
    // 0xbe8f74: ldur            x1, [fp, #-0x38]
    // 0xbe8f78: r0 = size()
    //     0xbe8f78: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe8f7c: LoadField: d0 = r0->field_7
    //     0xbe8f7c: ldur            d0, [x0, #7]
    // 0xbe8f80: mov             v2.16b, v0.16b
    // 0xbe8f84: b               #0xbe8f98
    // 0xbe8f88: ldur            x1, [fp, #-0x38]
    // 0xbe8f8c: r0 = size()
    //     0xbe8f8c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe8f90: LoadField: d0 = r0->field_f
    //     0xbe8f90: ldur            d0, [x0, #0xf]
    // 0xbe8f94: mov             v2.16b, v0.16b
    // 0xbe8f98: ldur            d1, [fp, #-0x88]
    // 0xbe8f9c: d0 = -0.000000
    //     0xbe8f9c: ldr             d0, [PP, #0x4ce0]  ; [pp+0x4ce0] IMM: double(-1e-10) from 0xbddb7cdfd9d7bdbb
    // 0xbe8fa0: fsub            d3, d1, d2
    // 0xbe8fa4: stur            d3, [fp, #-0x90]
    // 0xbe8fa8: fcmp            d0, d3
    // 0xbe8fac: b.gt            #0xbe9094
    // 0xbe8fb0: ldur            x4, [fp, #-0x18]
    // 0xbe8fb4: ldur            x3, [fp, #-0x48]
    // 0xbe8fb8: LoadField: r5 = r3->field_7
    //     0xbe8fb8: ldur            w5, [x3, #7]
    // 0xbe8fbc: DecompressPointer r5
    //     0xbe8fbc: add             x5, x5, HEAP, lsl #32
    // 0xbe8fc0: stur            x5, [fp, #-0x30]
    // 0xbe8fc4: cmp             w5, NULL
    // 0xbe8fc8: b.eq            #0xbe9ff0
    // 0xbe8fcc: mov             x0, x5
    // 0xbe8fd0: r2 = Null
    //     0xbe8fd0: mov             x2, NULL
    // 0xbe8fd4: r1 = Null
    //     0xbe8fd4: mov             x1, NULL
    // 0xbe8fd8: r4 = LoadClassIdInstr(r0)
    //     0xbe8fd8: ldur            x4, [x0, #-1]
    //     0xbe8fdc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8fe0: r17 = -4183
    //     0xbe8fe0: mov             x17, #-0x1057
    // 0xbe8fe4: add             x4, x4, x17
    // 0xbe8fe8: cmp             x4, #1
    // 0xbe8fec: b.ls            #0xbe9004
    // 0xbe8ff0: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe8ff0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe8ff4: ldr             x8, [x8, #0x590]
    // 0xbe8ff8: r3 = Null
    //     0xbe8ff8: add             x3, PP, #0x96, lsl #12  ; [pp+0x965d8] Null
    //     0xbe8ffc: ldr             x3, [x3, #0x5d8]
    // 0xbe9000: r0 = DefaultTypeTest()
    //     0xbe9000: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9004: ldur            d1, [fp, #-0x90]
    // 0xbe9008: r0 = inline_Allocate_Double()
    //     0xbe9008: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe900c: add             x0, x0, #0x10
    //     0xbe9010: cmp             x1, x0
    //     0xbe9014: b.ls            #0xbe9ff4
    //     0xbe9018: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe901c: sub             x0, x0, #0xf
    //     0xbe9020: mov             x1, #0xe19c
    //     0xbe9024: movk            x1, #3, lsl #16
    //     0xbe9028: stur            x1, [x0, #-1]
    // 0xbe902c: dmb             ishst
    // 0xbe9030: StoreField: r0->field_7 = d1
    //     0xbe9030: stur            d1, [x0, #7]
    // 0xbe9034: ldur            x1, [fp, #-0x30]
    // 0xbe9038: StoreField: r1->field_7 = r0
    //     0xbe9038: stur            w0, [x1, #7]
    //     0xbe903c: ldurb           w16, [x1, #-1]
    //     0xbe9040: ldurb           w17, [x0, #-1]
    //     0xbe9044: and             x16, x17, x16, lsr #2
    //     0xbe9048: tst             x16, HEAP, lsr #32
    //     0xbe904c: b.eq            #0xbe9054
    //     0xbe9050: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe9054: ldur            x3, [fp, #-0x18]
    // 0xbe9058: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xbe9058: ldur            w0, [x3, #0x17]
    // 0xbe905c: DecompressPointer r0
    //     0xbe905c: add             x0, x0, HEAP, lsl #32
    // 0xbe9060: cmp             w0, NULL
    // 0xbe9064: b.ne            #0xbe9088
    // 0xbe9068: ldur            x0, [fp, #-0x48]
    // 0xbe906c: ArrayStore: r3[0] = r0  ; List_4
    //     0xbe906c: stur            w0, [x3, #0x17]
    //     0xbe9070: ldurb           w16, [x3, #-1]
    //     0xbe9074: ldurb           w17, [x0, #-1]
    //     0xbe9078: and             x16, x17, x16, lsr #2
    //     0xbe907c: tst             x16, HEAP, lsr #32
    //     0xbe9080: b.eq            #0xbe9088
    //     0xbe9084: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe9088: ldur            x2, [fp, #-0x48]
    // 0xbe908c: ldur            x1, [fp, #-0x48]
    // 0xbe9090: b               #0xbe8eb8
    // 0xbe9094: ldur            x1, [fp, #-8]
    // 0xbe9098: mov             v1.16b, v3.16b
    // 0xbe909c: fneg            d0, d1
    // 0xbe90a0: stur            d0, [fp, #-0x88]
    // 0xbe90a4: r0 = SliverGeometry()
    //     0xbe90a4: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe90a8: StoreField: r0->field_7 = rZR
    //     0xbe90a8: stur            xzr, [x0, #7]
    // 0xbe90ac: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe90ac: stur            xzr, [x0, #0x17]
    // 0xbe90b0: StoreField: r0->field_f = rZR
    //     0xbe90b0: stur            xzr, [x0, #0xf]
    // 0xbe90b4: StoreField: r0->field_27 = rZR
    //     0xbe90b4: stur            xzr, [x0, #0x27]
    // 0xbe90b8: StoreField: r0->field_2f = rZR
    //     0xbe90b8: stur            xzr, [x0, #0x2f]
    // 0xbe90bc: r4 = false
    //     0xbe90bc: add             x4, NULL, #0x30  ; false
    // 0xbe90c0: StoreField: r0->field_43 = r4
    //     0xbe90c0: stur            w4, [x0, #0x43]
    // 0xbe90c4: ldur            d0, [fp, #-0x88]
    // 0xbe90c8: r1 = inline_Allocate_Double()
    //     0xbe90c8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbe90cc: add             x1, x1, #0x10
    //     0xbe90d0: cmp             x2, x1
    //     0xbe90d4: b.ls            #0xbea004
    //     0xbe90d8: str             x1, [THR, #0x60]  ; THR::top
    //     0xbe90dc: sub             x1, x1, #0xf
    //     0xbe90e0: mov             x2, #0xe19c
    //     0xbe90e4: movk            x2, #3, lsl #16
    //     0xbe90e8: stur            x2, [x1, #-1]
    // 0xbe90ec: dmb             ishst
    // 0xbe90f0: StoreField: r1->field_7 = d0
    //     0xbe90f0: stur            d0, [x1, #7]
    // 0xbe90f4: StoreField: r0->field_47 = r1
    //     0xbe90f4: stur            w1, [x0, #0x47]
    // 0xbe90f8: StoreField: r0->field_1f = rZR
    //     0xbe90f8: stur            xzr, [x0, #0x1f]
    // 0xbe90fc: StoreField: r0->field_37 = rZR
    //     0xbe90fc: stur            xzr, [x0, #0x37]
    // 0xbe9100: StoreField: r0->field_4b = rZR
    //     0xbe9100: stur            xzr, [x0, #0x4b]
    // 0xbe9104: d0 = 0.000000
    //     0xbe9104: eor             v0.16b, v0.16b, v0.16b
    // 0xbe9108: fcmp            d0, d0
    // 0xbe910c: r16 = true
    //     0xbe910c: add             x16, NULL, #0x20  ; true
    // 0xbe9110: r17 = false
    //     0xbe9110: add             x17, NULL, #0x30  ; false
    // 0xbe9114: csel            x1, x16, x17, gt
    // 0xbe9118: StoreField: r0->field_3f = r1
    //     0xbe9118: stur            w1, [x0, #0x3f]
    // 0xbe911c: ldur            x5, [fp, #-8]
    // 0xbe9120: StoreField: r5->field_47 = r0
    //     0xbe9120: stur            w0, [x5, #0x47]
    //     0xbe9124: ldurb           w16, [x5, #-1]
    //     0xbe9128: ldurb           w17, [x0, #-1]
    //     0xbe912c: and             x16, x17, x16, lsr #2
    //     0xbe9130: tst             x16, HEAP, lsr #32
    //     0xbe9134: b.eq            #0xbe913c
    //     0xbe9138: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbe913c: LoadField: r0 = r5->field_53
    //     0xbe913c: ldur            w0, [x5, #0x53]
    // 0xbe9140: DecompressPointer r0
    //     0xbe9140: add             x0, x0, HEAP, lsl #32
    // 0xbe9144: cmp             w0, NULL
    // 0xbe9148: b.eq            #0xbea020
    // 0xbe914c: LoadField: r3 = r0->field_7
    //     0xbe914c: ldur            w3, [x0, #7]
    // 0xbe9150: DecompressPointer r3
    //     0xbe9150: add             x3, x3, HEAP, lsl #32
    // 0xbe9154: stur            x3, [fp, #-0x30]
    // 0xbe9158: cmp             w3, NULL
    // 0xbe915c: b.eq            #0xbea024
    // 0xbe9160: mov             x0, x3
    // 0xbe9164: r2 = Null
    //     0xbe9164: mov             x2, NULL
    // 0xbe9168: r1 = Null
    //     0xbe9168: mov             x1, NULL
    // 0xbe916c: r4 = LoadClassIdInstr(r0)
    //     0xbe916c: ldur            x4, [x0, #-1]
    //     0xbe9170: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9174: r17 = -4183
    //     0xbe9174: mov             x17, #-0x1057
    // 0xbe9178: add             x4, x4, x17
    // 0xbe917c: cmp             x4, #1
    // 0xbe9180: b.ls            #0xbe9198
    // 0xbe9184: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9184: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9188: ldr             x8, [x8, #0x590]
    // 0xbe918c: r3 = Null
    //     0xbe918c: add             x3, PP, #0x96, lsl #12  ; [pp+0x965e8] Null
    //     0xbe9190: ldr             x3, [x3, #0x5e8]
    // 0xbe9194: r0 = DefaultTypeTest()
    //     0xbe9194: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9198: ldur            x0, [fp, #-0x30]
    // 0xbe919c: r6 = 0.000000
    //     0xbe919c: ldr             x6, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe91a0: StoreField: r0->field_7 = r6
    //     0xbe91a0: stur            w6, [x0, #7]
    // 0xbe91a4: r0 = Null
    //     0xbe91a4: mov             x0, NULL
    // 0xbe91a8: LeaveFrame
    //     0xbe91a8: mov             SP, fp
    //     0xbe91ac: ldp             fp, lr, [SP], #0x10
    // 0xbe91b0: ret
    //     0xbe91b0: ret             
    // 0xbe91b4: ldur            x5, [fp, #-8]
    // 0xbe91b8: ldur            x3, [fp, #-0x18]
    // 0xbe91bc: ldur            d1, [fp, #-0x78]
    // 0xbe91c0: r4 = false
    //     0xbe91c0: add             x4, NULL, #0x30  ; false
    // 0xbe91c4: r6 = 0.000000
    //     0xbe91c4: ldr             x6, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe91c8: d0 = 0.000000
    //     0xbe91c8: eor             v0.16b, v0.16b, v0.16b
    // 0xbe91cc: LoadField: r7 = r5->field_53
    //     0xbe91cc: ldur            w7, [x5, #0x53]
    // 0xbe91d0: DecompressPointer r7
    //     0xbe91d0: add             x7, x7, HEAP, lsl #32
    // 0xbe91d4: stur            x7, [fp, #-0x38]
    // 0xbe91d8: cmp             w7, NULL
    // 0xbe91dc: b.eq            #0xbea028
    // 0xbe91e0: LoadField: r8 = r7->field_7
    //     0xbe91e0: ldur            w8, [x7, #7]
    // 0xbe91e4: DecompressPointer r8
    //     0xbe91e4: add             x8, x8, HEAP, lsl #32
    // 0xbe91e8: stur            x8, [fp, #-0x30]
    // 0xbe91ec: cmp             w8, NULL
    // 0xbe91f0: b.eq            #0xbea02c
    // 0xbe91f4: mov             x0, x8
    // 0xbe91f8: r2 = Null
    //     0xbe91f8: mov             x2, NULL
    // 0xbe91fc: r1 = Null
    //     0xbe91fc: mov             x1, NULL
    // 0xbe9200: r4 = LoadClassIdInstr(r0)
    //     0xbe9200: ldur            x4, [x0, #-1]
    //     0xbe9204: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9208: r17 = -4183
    //     0xbe9208: mov             x17, #-0x1057
    // 0xbe920c: add             x4, x4, x17
    // 0xbe9210: cmp             x4, #1
    // 0xbe9214: b.ls            #0xbe922c
    // 0xbe9218: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9218: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe921c: ldr             x8, [x8, #0x590]
    // 0xbe9220: r3 = Null
    //     0xbe9220: add             x3, PP, #0x96, lsl #12  ; [pp+0x965f8] Null
    //     0xbe9224: ldr             x3, [x3, #0x5f8]
    // 0xbe9228: r0 = DefaultTypeTest()
    //     0xbe9228: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe922c: ldur            x0, [fp, #-0x30]
    // 0xbe9230: r3 = 0.000000
    //     0xbe9230: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe9234: StoreField: r0->field_7 = r3
    //     0xbe9234: stur            w3, [x0, #7]
    // 0xbe9238: ldur            d1, [fp, #-0x78]
    // 0xbe923c: d0 = 0.000000
    //     0xbe923c: eor             v0.16b, v0.16b, v0.16b
    // 0xbe9240: fcmp            d1, d0
    // 0xbe9244: b.ne            #0xbe92dc
    // 0xbe9248: ldur            x5, [fp, #-8]
    // 0xbe924c: ldur            x4, [fp, #-0x18]
    // 0xbe9250: ldur            x1, [fp, #-0x38]
    // 0xbe9254: r0 = LoadClassIdInstr(r1)
    //     0xbe9254: ldur            x0, [x1, #-1]
    //     0xbe9258: ubfx            x0, x0, #0xc, #0x14
    // 0xbe925c: r16 = true
    //     0xbe925c: add             x16, NULL, #0x20  ; true
    // 0xbe9260: str             x16, [SP]
    // 0xbe9264: ldur            x2, [fp, #-0x28]
    // 0xbe9268: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbe9268: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbe926c: ldr             x4, [x4, #0xed0]
    // 0xbe9270: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe9270: mov             x17, #0xe6b9
    //     0xbe9274: add             lr, x0, x17
    //     0xbe9278: ldr             lr, [x21, lr, lsl #3]
    //     0xbe927c: blr             lr
    // 0xbe9280: ldur            x1, [fp, #-8]
    // 0xbe9284: LoadField: r2 = r1->field_53
    //     0xbe9284: ldur            w2, [x1, #0x53]
    // 0xbe9288: DecompressPointer r2
    //     0xbe9288: add             x2, x2, HEAP, lsl #32
    // 0xbe928c: ldur            x3, [fp, #-0x18]
    // 0xbe9290: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xbe9290: ldur            w0, [x3, #0x17]
    // 0xbe9294: DecompressPointer r0
    //     0xbe9294: add             x0, x0, HEAP, lsl #32
    // 0xbe9298: cmp             w0, NULL
    // 0xbe929c: b.ne            #0xbe92c0
    // 0xbe92a0: mov             x0, x2
    // 0xbe92a4: ArrayStore: r3[0] = r0  ; List_4
    //     0xbe92a4: stur            w0, [x3, #0x17]
    //     0xbe92a8: ldurb           w16, [x3, #-1]
    //     0xbe92ac: ldurb           w17, [x0, #-1]
    //     0xbe92b0: and             x16, x17, x16, lsr #2
    //     0xbe92b4: tst             x16, HEAP, lsr #32
    //     0xbe92b8: b.eq            #0xbe92c0
    //     0xbe92bc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe92c0: mov             x6, x2
    // 0xbe92c4: mov             x0, x2
    // 0xbe92c8: mov             x5, x1
    // 0xbe92cc: ldur            d0, [fp, #-0x78]
    // 0xbe92d0: r4 = false
    //     0xbe92d0: add             x4, NULL, #0x30  ; false
    // 0xbe92d4: d1 = 0.000000
    //     0xbe92d4: eor             v1.16b, v1.16b, v1.16b
    // 0xbe92d8: b               #0xbe93a8
    // 0xbe92dc: ldur            x1, [fp, #-8]
    // 0xbe92e0: mov             v0.16b, v1.16b
    // 0xbe92e4: fneg            d1, d0
    // 0xbe92e8: stur            d1, [fp, #-0x88]
    // 0xbe92ec: r0 = SliverGeometry()
    //     0xbe92ec: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe92f0: StoreField: r0->field_7 = rZR
    //     0xbe92f0: stur            xzr, [x0, #7]
    // 0xbe92f4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe92f4: stur            xzr, [x0, #0x17]
    // 0xbe92f8: StoreField: r0->field_f = rZR
    //     0xbe92f8: stur            xzr, [x0, #0xf]
    // 0xbe92fc: StoreField: r0->field_27 = rZR
    //     0xbe92fc: stur            xzr, [x0, #0x27]
    // 0xbe9300: StoreField: r0->field_2f = rZR
    //     0xbe9300: stur            xzr, [x0, #0x2f]
    // 0xbe9304: r4 = false
    //     0xbe9304: add             x4, NULL, #0x30  ; false
    // 0xbe9308: StoreField: r0->field_43 = r4
    //     0xbe9308: stur            w4, [x0, #0x43]
    // 0xbe930c: ldur            d0, [fp, #-0x88]
    // 0xbe9310: r1 = inline_Allocate_Double()
    //     0xbe9310: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbe9314: add             x1, x1, #0x10
    //     0xbe9318: cmp             x2, x1
    //     0xbe931c: b.ls            #0xbea030
    //     0xbe9320: str             x1, [THR, #0x60]  ; THR::top
    //     0xbe9324: sub             x1, x1, #0xf
    //     0xbe9328: mov             x2, #0xe19c
    //     0xbe932c: movk            x2, #3, lsl #16
    //     0xbe9330: stur            x2, [x1, #-1]
    // 0xbe9334: dmb             ishst
    // 0xbe9338: StoreField: r1->field_7 = d0
    //     0xbe9338: stur            d0, [x1, #7]
    // 0xbe933c: StoreField: r0->field_47 = r1
    //     0xbe933c: stur            w1, [x0, #0x47]
    // 0xbe9340: StoreField: r0->field_1f = rZR
    //     0xbe9340: stur            xzr, [x0, #0x1f]
    // 0xbe9344: StoreField: r0->field_37 = rZR
    //     0xbe9344: stur            xzr, [x0, #0x37]
    // 0xbe9348: StoreField: r0->field_4b = rZR
    //     0xbe9348: stur            xzr, [x0, #0x4b]
    // 0xbe934c: d1 = 0.000000
    //     0xbe934c: eor             v1.16b, v1.16b, v1.16b
    // 0xbe9350: fcmp            d1, d1
    // 0xbe9354: r16 = true
    //     0xbe9354: add             x16, NULL, #0x20  ; true
    // 0xbe9358: r17 = false
    //     0xbe9358: add             x17, NULL, #0x30  ; false
    // 0xbe935c: csel            x1, x16, x17, gt
    // 0xbe9360: StoreField: r0->field_3f = r1
    //     0xbe9360: stur            w1, [x0, #0x3f]
    // 0xbe9364: ldur            x5, [fp, #-8]
    // 0xbe9368: StoreField: r5->field_47 = r0
    //     0xbe9368: stur            w0, [x5, #0x47]
    //     0xbe936c: ldurb           w16, [x5, #-1]
    //     0xbe9370: ldurb           w17, [x0, #-1]
    //     0xbe9374: and             x16, x17, x16, lsr #2
    //     0xbe9378: tst             x16, HEAP, lsr #32
    //     0xbe937c: b.eq            #0xbe9384
    //     0xbe9380: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbe9384: r0 = Null
    //     0xbe9384: mov             x0, NULL
    // 0xbe9388: LeaveFrame
    //     0xbe9388: mov             SP, fp
    //     0xbe938c: ldp             fp, lr, [SP], #0x10
    // 0xbe9390: ret
    //     0xbe9390: ret             
    // 0xbe9394: mov             x5, x0
    // 0xbe9398: r4 = false
    //     0xbe9398: add             x4, NULL, #0x30  ; false
    // 0xbe939c: d1 = 0.000000
    //     0xbe939c: eor             v1.16b, v1.16b, v1.16b
    // 0xbe93a0: mov             x6, x2
    // 0xbe93a4: mov             x0, x1
    // 0xbe93a8: d2 = 0.000000
    //     0xbe93a8: ldr             d2, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xbe93ac: stur            x6, [fp, #-0x48]
    // 0xbe93b0: fcmp            d2, d0
    // 0xbe93b4: b.le            #0xbe968c
    // 0xbe93b8: mov             x7, x0
    // 0xbe93bc: stur            x7, [fp, #-0x38]
    // 0xbe93c0: CheckStackOverflow
    //     0xbe93c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe93c4: cmp             SP, x16
    //     0xbe93c8: b.ls            #0xbea04c
    // 0xbe93cc: LoadField: r0 = r5->field_53
    //     0xbe93cc: ldur            w0, [x5, #0x53]
    // 0xbe93d0: DecompressPointer r0
    //     0xbe93d0: add             x0, x0, HEAP, lsl #32
    // 0xbe93d4: cmp             w0, NULL
    // 0xbe93d8: b.eq            #0xbea054
    // 0xbe93dc: LoadField: r8 = r0->field_7
    //     0xbe93dc: ldur            w8, [x0, #7]
    // 0xbe93e0: DecompressPointer r8
    //     0xbe93e0: add             x8, x8, HEAP, lsl #32
    // 0xbe93e4: stur            x8, [fp, #-0x30]
    // 0xbe93e8: cmp             w8, NULL
    // 0xbe93ec: b.eq            #0xbea058
    // 0xbe93f0: mov             x0, x8
    // 0xbe93f4: r2 = Null
    //     0xbe93f4: mov             x2, NULL
    // 0xbe93f8: r1 = Null
    //     0xbe93f8: mov             x1, NULL
    // 0xbe93fc: r4 = LoadClassIdInstr(r0)
    //     0xbe93fc: ldur            x4, [x0, #-1]
    //     0xbe9400: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9404: r17 = -4183
    //     0xbe9404: mov             x17, #-0x1057
    // 0xbe9408: add             x4, x4, x17
    // 0xbe940c: cmp             x4, #1
    // 0xbe9410: b.ls            #0xbe9428
    // 0xbe9414: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9414: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9418: ldr             x8, [x8, #0x590]
    // 0xbe941c: r3 = Null
    //     0xbe941c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96608] Null
    //     0xbe9420: ldr             x3, [x3, #0x608]
    // 0xbe9424: r0 = DefaultTypeTest()
    //     0xbe9424: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9428: ldur            x0, [fp, #-0x30]
    // 0xbe942c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe942c: ldur            w1, [x0, #0x17]
    // 0xbe9430: DecompressPointer r1
    //     0xbe9430: add             x1, x1, HEAP, lsl #32
    // 0xbe9434: cmp             w1, NULL
    // 0xbe9438: b.eq            #0xbea05c
    // 0xbe943c: r2 = LoadInt32Instr(r1)
    //     0xbe943c: sbfx            x2, x1, #1, #0x1f
    //     0xbe9440: tbz             w1, #0, #0xbe9448
    //     0xbe9444: ldur            x2, [x1, #7]
    // 0xbe9448: cmp             x2, #0
    // 0xbe944c: b.le            #0xbe9678
    // 0xbe9450: ldur            x3, [fp, #-8]
    // 0xbe9454: LoadField: r4 = r0->field_7
    //     0xbe9454: ldur            w4, [x0, #7]
    // 0xbe9458: DecompressPointer r4
    //     0xbe9458: add             x4, x4, HEAP, lsl #32
    // 0xbe945c: stur            x4, [fp, #-0x50]
    // 0xbe9460: cmp             w4, NULL
    // 0xbe9464: b.eq            #0xbea060
    // 0xbe9468: r16 = true
    //     0xbe9468: add             x16, NULL, #0x20  ; true
    // 0xbe946c: str             x16, [SP]
    // 0xbe9470: mov             x1, x3
    // 0xbe9474: ldur            x2, [fp, #-0x28]
    // 0xbe9478: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbe9478: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbe947c: ldr             x4, [x4, #0xed0]
    // 0xbe9480: r0 = insertAndLayoutLeadingChild()
    //     0xbe9480: bl              #0xbe5694  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0xbe9484: mov             x4, x0
    // 0xbe9488: ldur            x3, [fp, #-8]
    // 0xbe948c: stur            x4, [fp, #-0x60]
    // 0xbe9490: LoadField: r5 = r3->field_53
    //     0xbe9490: ldur            w5, [x3, #0x53]
    // 0xbe9494: DecompressPointer r5
    //     0xbe9494: add             x5, x5, HEAP, lsl #32
    // 0xbe9498: stur            x5, [fp, #-0x58]
    // 0xbe949c: cmp             w5, NULL
    // 0xbe94a0: b.eq            #0xbea064
    // 0xbe94a4: LoadField: r6 = r3->field_27
    //     0xbe94a4: ldur            w6, [x3, #0x27]
    // 0xbe94a8: DecompressPointer r6
    //     0xbe94a8: add             x6, x6, HEAP, lsl #32
    // 0xbe94ac: stur            x6, [fp, #-0x30]
    // 0xbe94b0: cmp             w6, NULL
    // 0xbe94b4: b.eq            #0xbe9f9c
    // 0xbe94b8: mov             x0, x6
    // 0xbe94bc: r2 = Null
    //     0xbe94bc: mov             x2, NULL
    // 0xbe94c0: r1 = Null
    //     0xbe94c0: mov             x1, NULL
    // 0xbe94c4: r4 = LoadClassIdInstr(r0)
    //     0xbe94c4: ldur            x4, [x0, #-1]
    //     0xbe94c8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe94cc: cmp             x4, #0xb45
    // 0xbe94d0: b.eq            #0xbe94e8
    // 0xbe94d4: r8 = SliverConstraints
    //     0xbe94d4: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe94d8: ldr             x8, [x8, #0x3c0]
    // 0xbe94dc: r3 = Null
    //     0xbe94dc: add             x3, PP, #0x96, lsl #12  ; [pp+0x96618] Null
    //     0xbe94e0: ldr             x3, [x3, #0x618]
    // 0xbe94e4: r0 = DefaultTypeTest()
    //     0xbe94e4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe94e8: ldur            x1, [fp, #-0x30]
    // 0xbe94ec: r0 = axis()
    //     0xbe94ec: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe94f0: LoadField: r1 = r0->field_7
    //     0xbe94f0: ldur            x1, [x0, #7]
    // 0xbe94f4: cmp             x1, #0
    // 0xbe94f8: b.gt            #0xbe950c
    // 0xbe94fc: ldur            x1, [fp, #-0x58]
    // 0xbe9500: r0 = size()
    //     0xbe9500: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe9504: LoadField: d0 = r0->field_7
    //     0xbe9504: ldur            d0, [x0, #7]
    // 0xbe9508: b               #0xbe9518
    // 0xbe950c: ldur            x1, [fp, #-0x58]
    // 0xbe9510: r0 = size()
    //     0xbe9510: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe9514: LoadField: d0 = r0->field_f
    //     0xbe9514: ldur            d0, [x0, #0xf]
    // 0xbe9518: ldur            x3, [fp, #-8]
    // 0xbe951c: ldur            x0, [fp, #-0x50]
    // 0xbe9520: LoadField: d1 = r0->field_7
    //     0xbe9520: ldur            d1, [x0, #7]
    // 0xbe9524: fsub            d2, d1, d0
    // 0xbe9528: stur            d2, [fp, #-0x88]
    // 0xbe952c: LoadField: r0 = r3->field_53
    //     0xbe952c: ldur            w0, [x3, #0x53]
    // 0xbe9530: DecompressPointer r0
    //     0xbe9530: add             x0, x0, HEAP, lsl #32
    // 0xbe9534: cmp             w0, NULL
    // 0xbe9538: b.eq            #0xbea068
    // 0xbe953c: LoadField: r4 = r0->field_7
    //     0xbe953c: ldur            w4, [x0, #7]
    // 0xbe9540: DecompressPointer r4
    //     0xbe9540: add             x4, x4, HEAP, lsl #32
    // 0xbe9544: stur            x4, [fp, #-0x30]
    // 0xbe9548: cmp             w4, NULL
    // 0xbe954c: b.eq            #0xbea06c
    // 0xbe9550: mov             x0, x4
    // 0xbe9554: r2 = Null
    //     0xbe9554: mov             x2, NULL
    // 0xbe9558: r1 = Null
    //     0xbe9558: mov             x1, NULL
    // 0xbe955c: r4 = LoadClassIdInstr(r0)
    //     0xbe955c: ldur            x4, [x0, #-1]
    //     0xbe9560: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9564: r17 = -4183
    //     0xbe9564: mov             x17, #-0x1057
    // 0xbe9568: add             x4, x4, x17
    // 0xbe956c: cmp             x4, #1
    // 0xbe9570: b.ls            #0xbe9588
    // 0xbe9574: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9574: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9578: ldr             x8, [x8, #0x590]
    // 0xbe957c: r3 = Null
    //     0xbe957c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96628] Null
    //     0xbe9580: ldr             x3, [x3, #0x628]
    // 0xbe9584: r0 = DefaultTypeTest()
    //     0xbe9584: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9588: ldur            x1, [fp, #-0x30]
    // 0xbe958c: r0 = 0.000000
    //     0xbe958c: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbe9590: StoreField: r1->field_7 = r0
    //     0xbe9590: stur            w0, [x1, #7]
    // 0xbe9594: ldur            d1, [fp, #-0x88]
    // 0xbe9598: d0 = -0.000000
    //     0xbe9598: ldr             d0, [PP, #0x4ce0]  ; [pp+0x4ce0] IMM: double(-1e-10) from 0xbddb7cdfd9d7bdbb
    // 0xbe959c: fcmp            d0, d1
    // 0xbe95a0: b.gt            #0xbe95c4
    // 0xbe95a4: ldur            x7, [fp, #-0x60]
    // 0xbe95a8: ldur            x5, [fp, #-8]
    // 0xbe95ac: ldur            x3, [fp, #-0x18]
    // 0xbe95b0: ldur            d0, [fp, #-0x78]
    // 0xbe95b4: ldur            x6, [fp, #-0x48]
    // 0xbe95b8: r4 = false
    //     0xbe95b8: add             x4, NULL, #0x30  ; false
    // 0xbe95bc: d1 = 0.000000
    //     0xbe95bc: eor             v1.16b, v1.16b, v1.16b
    // 0xbe95c0: b               #0xbe93bc
    // 0xbe95c4: ldur            x1, [fp, #-8]
    // 0xbe95c8: fneg            d0, d1
    // 0xbe95cc: stur            d0, [fp, #-0x90]
    // 0xbe95d0: r0 = SliverGeometry()
    //     0xbe95d0: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe95d4: StoreField: r0->field_7 = rZR
    //     0xbe95d4: stur            xzr, [x0, #7]
    // 0xbe95d8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe95d8: stur            xzr, [x0, #0x17]
    // 0xbe95dc: StoreField: r0->field_f = rZR
    //     0xbe95dc: stur            xzr, [x0, #0xf]
    // 0xbe95e0: StoreField: r0->field_27 = rZR
    //     0xbe95e0: stur            xzr, [x0, #0x27]
    // 0xbe95e4: StoreField: r0->field_2f = rZR
    //     0xbe95e4: stur            xzr, [x0, #0x2f]
    // 0xbe95e8: r3 = false
    //     0xbe95e8: add             x3, NULL, #0x30  ; false
    // 0xbe95ec: StoreField: r0->field_43 = r3
    //     0xbe95ec: stur            w3, [x0, #0x43]
    // 0xbe95f0: ldur            d0, [fp, #-0x90]
    // 0xbe95f4: r1 = inline_Allocate_Double()
    //     0xbe95f4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbe95f8: add             x1, x1, #0x10
    //     0xbe95fc: cmp             x2, x1
    //     0xbe9600: b.ls            #0xbea070
    //     0xbe9604: str             x1, [THR, #0x60]  ; THR::top
    //     0xbe9608: sub             x1, x1, #0xf
    //     0xbe960c: mov             x2, #0xe19c
    //     0xbe9610: movk            x2, #3, lsl #16
    //     0xbe9614: stur            x2, [x1, #-1]
    // 0xbe9618: dmb             ishst
    // 0xbe961c: StoreField: r1->field_7 = d0
    //     0xbe961c: stur            d0, [x1, #7]
    // 0xbe9620: StoreField: r0->field_47 = r1
    //     0xbe9620: stur            w1, [x0, #0x47]
    // 0xbe9624: StoreField: r0->field_1f = rZR
    //     0xbe9624: stur            xzr, [x0, #0x1f]
    // 0xbe9628: StoreField: r0->field_37 = rZR
    //     0xbe9628: stur            xzr, [x0, #0x37]
    // 0xbe962c: StoreField: r0->field_4b = rZR
    //     0xbe962c: stur            xzr, [x0, #0x4b]
    // 0xbe9630: d0 = 0.000000
    //     0xbe9630: eor             v0.16b, v0.16b, v0.16b
    // 0xbe9634: fcmp            d0, d0
    // 0xbe9638: r16 = true
    //     0xbe9638: add             x16, NULL, #0x20  ; true
    // 0xbe963c: r17 = false
    //     0xbe963c: add             x17, NULL, #0x30  ; false
    // 0xbe9640: csel            x1, x16, x17, gt
    // 0xbe9644: StoreField: r0->field_3f = r1
    //     0xbe9644: stur            w1, [x0, #0x3f]
    // 0xbe9648: ldur            x4, [fp, #-8]
    // 0xbe964c: StoreField: r4->field_47 = r0
    //     0xbe964c: stur            w0, [x4, #0x47]
    //     0xbe9650: ldurb           w16, [x4, #-1]
    //     0xbe9654: ldurb           w17, [x0, #-1]
    //     0xbe9658: and             x16, x17, x16, lsr #2
    //     0xbe965c: tst             x16, HEAP, lsr #32
    //     0xbe9660: b.eq            #0xbe9668
    //     0xbe9664: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbe9668: r0 = Null
    //     0xbe9668: mov             x0, NULL
    // 0xbe966c: LeaveFrame
    //     0xbe966c: mov             SP, fp
    //     0xbe9670: ldp             fp, lr, [SP], #0x10
    // 0xbe9674: ret
    //     0xbe9674: ret             
    // 0xbe9678: ldur            x4, [fp, #-8]
    // 0xbe967c: r3 = false
    //     0xbe967c: add             x3, NULL, #0x30  ; false
    // 0xbe9680: d0 = 0.000000
    //     0xbe9680: eor             v0.16b, v0.16b, v0.16b
    // 0xbe9684: ldur            x5, [fp, #-0x38]
    // 0xbe9688: b               #0xbe969c
    // 0xbe968c: mov             x3, x4
    // 0xbe9690: mov             x4, x5
    // 0xbe9694: mov             v0.16b, v1.16b
    // 0xbe9698: mov             x5, x0
    // 0xbe969c: ldur            x0, [fp, #-0x48]
    // 0xbe96a0: stur            x5, [fp, #-0x30]
    // 0xbe96a4: cmp             w0, NULL
    // 0xbe96a8: b.ne            #0xbe9710
    // 0xbe96ac: ldur            x6, [fp, #-0x18]
    // 0xbe96b0: cmp             w5, NULL
    // 0xbe96b4: b.eq            #0xbea08c
    // 0xbe96b8: r0 = LoadClassIdInstr(r5)
    //     0xbe96b8: ldur            x0, [x5, #-1]
    //     0xbe96bc: ubfx            x0, x0, #0xc, #0x14
    // 0xbe96c0: r16 = true
    //     0xbe96c0: add             x16, NULL, #0x20  ; true
    // 0xbe96c4: str             x16, [SP]
    // 0xbe96c8: mov             x1, x5
    // 0xbe96cc: ldur            x2, [fp, #-0x28]
    // 0xbe96d0: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbe96d0: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbe96d4: ldr             x4, [x4, #0xed0]
    // 0xbe96d8: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe96d8: mov             x17, #0xe6b9
    //     0xbe96dc: add             lr, x0, x17
    //     0xbe96e0: ldr             lr, [x21, lr, lsl #3]
    //     0xbe96e4: blr             lr
    // 0xbe96e8: ldur            x0, [fp, #-0x30]
    // 0xbe96ec: ldur            x3, [fp, #-0x18]
    // 0xbe96f0: ArrayStore: r3[0] = r0  ; List_4
    //     0xbe96f0: stur            w0, [x3, #0x17]
    //     0xbe96f4: ldurb           w16, [x3, #-1]
    //     0xbe96f8: ldurb           w17, [x0, #-1]
    //     0xbe96fc: and             x16, x17, x16, lsr #2
    //     0xbe9700: tst             x16, HEAP, lsr #32
    //     0xbe9704: b.eq            #0xbe970c
    //     0xbe9708: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe970c: b               #0xbe9714
    // 0xbe9710: ldur            x3, [fp, #-0x18]
    // 0xbe9714: ldur            x4, [fp, #-0x30]
    // 0xbe9718: r5 = true
    //     0xbe9718: add             x5, NULL, #0x20  ; true
    // 0xbe971c: StoreField: r3->field_1b = r5
    //     0xbe971c: stur            w5, [x3, #0x1b]
    // 0xbe9720: mov             x0, x4
    // 0xbe9724: StoreField: r3->field_1f = r0
    //     0xbe9724: stur            w0, [x3, #0x1f]
    //     0xbe9728: ldurb           w16, [x3, #-1]
    //     0xbe972c: ldurb           w17, [x0, #-1]
    //     0xbe9730: and             x16, x17, x16, lsr #2
    //     0xbe9734: tst             x16, HEAP, lsr #32
    //     0xbe9738: b.eq            #0xbe9740
    //     0xbe973c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe9740: cmp             w4, NULL
    // 0xbe9744: b.eq            #0xbea090
    // 0xbe9748: LoadField: r6 = r4->field_7
    //     0xbe9748: ldur            w6, [x4, #7]
    // 0xbe974c: DecompressPointer r6
    //     0xbe974c: add             x6, x6, HEAP, lsl #32
    // 0xbe9750: stur            x6, [fp, #-0x28]
    // 0xbe9754: cmp             w6, NULL
    // 0xbe9758: b.eq            #0xbea094
    // 0xbe975c: mov             x0, x6
    // 0xbe9760: r2 = Null
    //     0xbe9760: mov             x2, NULL
    // 0xbe9764: r1 = Null
    //     0xbe9764: mov             x1, NULL
    // 0xbe9768: r4 = LoadClassIdInstr(r0)
    //     0xbe9768: ldur            x4, [x0, #-1]
    //     0xbe976c: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9770: r17 = -4183
    //     0xbe9770: mov             x17, #-0x1057
    // 0xbe9774: add             x4, x4, x17
    // 0xbe9778: cmp             x4, #1
    // 0xbe977c: b.ls            #0xbe9794
    // 0xbe9780: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9780: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9784: ldr             x8, [x8, #0x590]
    // 0xbe9788: r3 = Null
    //     0xbe9788: add             x3, PP, #0x96, lsl #12  ; [pp+0x96638] Null
    //     0xbe978c: ldr             x3, [x3, #0x638]
    // 0xbe9790: r0 = DefaultTypeTest()
    //     0xbe9790: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9794: ldur            x1, [fp, #-0x28]
    // 0xbe9798: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xbe9798: ldur            w0, [x1, #0x17]
    // 0xbe979c: DecompressPointer r0
    //     0xbe979c: add             x0, x0, HEAP, lsl #32
    // 0xbe97a0: cmp             w0, NULL
    // 0xbe97a4: b.eq            #0xbea098
    // 0xbe97a8: ldur            x3, [fp, #-0x18]
    // 0xbe97ac: StoreField: r3->field_23 = r0
    //     0xbe97ac: stur            w0, [x3, #0x23]
    //     0xbe97b0: tbz             w0, #0, #0xbe97cc
    //     0xbe97b4: ldurb           w16, [x3, #-1]
    //     0xbe97b8: ldurb           w17, [x0, #-1]
    //     0xbe97bc: and             x16, x17, x16, lsr #2
    //     0xbe97c0: tst             x16, HEAP, lsr #32
    //     0xbe97c4: b.eq            #0xbe97cc
    //     0xbe97c8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe97cc: LoadField: r0 = r1->field_7
    //     0xbe97cc: ldur            w0, [x1, #7]
    // 0xbe97d0: DecompressPointer r0
    //     0xbe97d0: add             x0, x0, HEAP, lsl #32
    // 0xbe97d4: stur            x0, [fp, #-0x38]
    // 0xbe97d8: cmp             w0, NULL
    // 0xbe97dc: b.eq            #0xbea09c
    // 0xbe97e0: ldur            x1, [fp, #-8]
    // 0xbe97e4: ldur            x2, [fp, #-0x30]
    // 0xbe97e8: r0 = paintExtentOf()
    //     0xbe97e8: bl              #0x1185dbc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::paintExtentOf
    // 0xbe97ec: ldur            x0, [fp, #-0x38]
    // 0xbe97f0: LoadField: d1 = r0->field_7
    //     0xbe97f0: ldur            d1, [x0, #7]
    // 0xbe97f4: fadd            d2, d1, d0
    // 0xbe97f8: r0 = inline_Allocate_Double()
    //     0xbe97f8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe97fc: add             x0, x0, #0x10
    //     0xbe9800: cmp             x1, x0
    //     0xbe9804: b.ls            #0xbea0a0
    //     0xbe9808: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe980c: sub             x0, x0, #0xf
    //     0xbe9810: mov             x1, #0xe19c
    //     0xbe9814: movk            x1, #3, lsl #16
    //     0xbe9818: stur            x1, [x0, #-1]
    // 0xbe981c: dmb             ishst
    // 0xbe9820: StoreField: r0->field_7 = d2
    //     0xbe9820: stur            d2, [x0, #7]
    // 0xbe9824: ldur            x3, [fp, #-0x18]
    // 0xbe9828: StoreField: r3->field_27 = r0
    //     0xbe9828: stur            w0, [x3, #0x27]
    //     0xbe982c: ldurb           w16, [x3, #-1]
    //     0xbe9830: ldurb           w17, [x0, #-1]
    //     0xbe9834: and             x16, x17, x16, lsr #2
    //     0xbe9838: tst             x16, HEAP, lsr #32
    //     0xbe983c: b.eq            #0xbe9844
    //     0xbe9840: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe9844: mov             x2, x3
    // 0xbe9848: r1 = Function 'advance':.
    //     0xbe9848: add             x1, PP, #0x96, lsl #12  ; [pp+0x96648] AnonymousClosure: (0xbea10c), in [package:flutter/src/rendering/sliver_list.dart] RenderSliverList::performLayout (0xbe8b50)
    //     0xbe984c: ldr             x1, [x1, #0x648]
    // 0xbe9850: r0 = AllocateClosure()
    //     0xbe9850: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbe9854: mov             x1, x0
    // 0xbe9858: stur            x1, [fp, #-0x28]
    // 0xbe985c: r3 = 0
    //     0xbe985c: mov             x3, #0
    // 0xbe9860: ldur            x2, [fp, #-0x18]
    // 0xbe9864: ldur            d0, [fp, #-0x78]
    // 0xbe9868: stur            x3, [fp, #-0x68]
    // 0xbe986c: CheckStackOverflow
    //     0xbe986c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe9870: cmp             SP, x16
    //     0xbe9874: b.ls            #0xbea0b0
    // 0xbe9878: LoadField: r0 = r2->field_27
    //     0xbe9878: ldur            w0, [x2, #0x27]
    // 0xbe987c: DecompressPointer r0
    //     0xbe987c: add             x0, x0, HEAP, lsl #32
    // 0xbe9880: LoadField: d1 = r0->field_7
    //     0xbe9880: ldur            d1, [x0, #7]
    // 0xbe9884: fcmp            d0, d1
    // 0xbe9888: b.le            #0xbe99e8
    // 0xbe988c: add             x4, x3, #1
    // 0xbe9890: stur            x4, [fp, #-0x40]
    // 0xbe9894: str             x1, [SP]
    // 0xbe9898: mov             x0, x1
    // 0xbe989c: ClosureCall
    //     0xbe989c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbe98a0: ldur            x2, [x0, #0x1f]
    //     0xbe98a4: blr             x2
    // 0xbe98a8: r16 = true
    //     0xbe98a8: add             x16, NULL, #0x20  ; true
    // 0xbe98ac: cmp             w0, w16
    // 0xbe98b0: b.ne            #0xbe98c0
    // 0xbe98b4: ldur            x3, [fp, #-0x40]
    // 0xbe98b8: ldur            x1, [fp, #-0x28]
    // 0xbe98bc: b               #0xbe9860
    // 0xbe98c0: ldur            x4, [fp, #-8]
    // 0xbe98c4: ldur            x0, [fp, #-0x40]
    // 0xbe98c8: sub             x2, x0, #1
    // 0xbe98cc: mov             x1, x4
    // 0xbe98d0: r3 = 0
    //     0xbe98d0: mov             x3, #0
    // 0xbe98d4: r0 = collectGarbage()
    //     0xbe98d4: bl              #0xbe64f8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0xbe98d8: ldur            x3, [fp, #-8]
    // 0xbe98dc: LoadField: r4 = r3->field_57
    //     0xbe98dc: ldur            w4, [x3, #0x57]
    // 0xbe98e0: DecompressPointer r4
    //     0xbe98e0: add             x4, x4, HEAP, lsl #32
    // 0xbe98e4: stur            x4, [fp, #-0x38]
    // 0xbe98e8: cmp             w4, NULL
    // 0xbe98ec: b.eq            #0xbea0b8
    // 0xbe98f0: LoadField: r5 = r4->field_7
    //     0xbe98f0: ldur            w5, [x4, #7]
    // 0xbe98f4: DecompressPointer r5
    //     0xbe98f4: add             x5, x5, HEAP, lsl #32
    // 0xbe98f8: stur            x5, [fp, #-0x30]
    // 0xbe98fc: cmp             w5, NULL
    // 0xbe9900: b.eq            #0xbea0bc
    // 0xbe9904: mov             x0, x5
    // 0xbe9908: r2 = Null
    //     0xbe9908: mov             x2, NULL
    // 0xbe990c: r1 = Null
    //     0xbe990c: mov             x1, NULL
    // 0xbe9910: r4 = LoadClassIdInstr(r0)
    //     0xbe9910: ldur            x4, [x0, #-1]
    //     0xbe9914: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9918: r17 = -4183
    //     0xbe9918: mov             x17, #-0x1057
    // 0xbe991c: add             x4, x4, x17
    // 0xbe9920: cmp             x4, #1
    // 0xbe9924: b.ls            #0xbe993c
    // 0xbe9928: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9928: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe992c: ldr             x8, [x8, #0x590]
    // 0xbe9930: r3 = Null
    //     0xbe9930: add             x3, PP, #0x96, lsl #12  ; [pp+0x96650] Null
    //     0xbe9934: ldr             x3, [x3, #0x650]
    // 0xbe9938: r0 = DefaultTypeTest()
    //     0xbe9938: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe993c: ldur            x0, [fp, #-0x30]
    // 0xbe9940: LoadField: r3 = r0->field_7
    //     0xbe9940: ldur            w3, [x0, #7]
    // 0xbe9944: DecompressPointer r3
    //     0xbe9944: add             x3, x3, HEAP, lsl #32
    // 0xbe9948: stur            x3, [fp, #-0x48]
    // 0xbe994c: cmp             w3, NULL
    // 0xbe9950: b.eq            #0xbea0c0
    // 0xbe9954: ldur            x1, [fp, #-8]
    // 0xbe9958: ldur            x2, [fp, #-0x38]
    // 0xbe995c: r0 = paintExtentOf()
    //     0xbe995c: bl              #0x1185dbc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::paintExtentOf
    // 0xbe9960: ldur            x0, [fp, #-0x48]
    // 0xbe9964: LoadField: d1 = r0->field_7
    //     0xbe9964: ldur            d1, [x0, #7]
    // 0xbe9968: fadd            d2, d1, d0
    // 0xbe996c: stur            d2, [fp, #-0x78]
    // 0xbe9970: r0 = SliverGeometry()
    //     0xbe9970: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe9974: ldur            d0, [fp, #-0x78]
    // 0xbe9978: StoreField: r0->field_7 = d0
    //     0xbe9978: stur            d0, [x0, #7]
    // 0xbe997c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe997c: stur            xzr, [x0, #0x17]
    // 0xbe9980: StoreField: r0->field_f = rZR
    //     0xbe9980: stur            xzr, [x0, #0xf]
    // 0xbe9984: StoreField: r0->field_27 = d0
    //     0xbe9984: stur            d0, [x0, #0x27]
    // 0xbe9988: StoreField: r0->field_2f = rZR
    //     0xbe9988: stur            xzr, [x0, #0x2f]
    // 0xbe998c: r1 = false
    //     0xbe998c: add             x1, NULL, #0x30  ; false
    // 0xbe9990: StoreField: r0->field_43 = r1
    //     0xbe9990: stur            w1, [x0, #0x43]
    // 0xbe9994: StoreField: r0->field_1f = rZR
    //     0xbe9994: stur            xzr, [x0, #0x1f]
    // 0xbe9998: StoreField: r0->field_37 = rZR
    //     0xbe9998: stur            xzr, [x0, #0x37]
    // 0xbe999c: StoreField: r0->field_4b = rZR
    //     0xbe999c: stur            xzr, [x0, #0x4b]
    // 0xbe99a0: d0 = 0.000000
    //     0xbe99a0: eor             v0.16b, v0.16b, v0.16b
    // 0xbe99a4: fcmp            d0, d0
    // 0xbe99a8: r16 = true
    //     0xbe99a8: add             x16, NULL, #0x20  ; true
    // 0xbe99ac: r17 = false
    //     0xbe99ac: add             x17, NULL, #0x30  ; false
    // 0xbe99b0: csel            x1, x16, x17, gt
    // 0xbe99b4: StoreField: r0->field_3f = r1
    //     0xbe99b4: stur            w1, [x0, #0x3f]
    // 0xbe99b8: ldur            x1, [fp, #-8]
    // 0xbe99bc: StoreField: r1->field_47 = r0
    //     0xbe99bc: stur            w0, [x1, #0x47]
    //     0xbe99c0: ldurb           w16, [x1, #-1]
    //     0xbe99c4: ldurb           w17, [x0, #-1]
    //     0xbe99c8: and             x16, x17, x16, lsr #2
    //     0xbe99cc: tst             x16, HEAP, lsr #32
    //     0xbe99d0: b.eq            #0xbe99d8
    //     0xbe99d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe99d8: r0 = Null
    //     0xbe99d8: mov             x0, NULL
    // 0xbe99dc: LeaveFrame
    //     0xbe99dc: mov             SP, fp
    //     0xbe99e0: ldp             fp, lr, [SP], #0x10
    // 0xbe99e4: ret
    //     0xbe99e4: ret             
    // 0xbe99e8: ldur            x1, [fp, #-8]
    // 0xbe99ec: d0 = 0.000000
    //     0xbe99ec: eor             v0.16b, v0.16b, v0.16b
    // 0xbe99f0: ldur            x2, [fp, #-0x18]
    // 0xbe99f4: ldur            d1, [fp, #-0x70]
    // 0xbe99f8: CheckStackOverflow
    //     0xbe99f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe99fc: cmp             SP, x16
    //     0xbe9a00: b.ls            #0xbea0c4
    // 0xbe9a04: LoadField: r0 = r2->field_27
    //     0xbe9a04: ldur            w0, [x2, #0x27]
    // 0xbe9a08: DecompressPointer r0
    //     0xbe9a08: add             x0, x0, HEAP, lsl #32
    // 0xbe9a0c: LoadField: d2 = r0->field_7
    //     0xbe9a0c: ldur            d2, [x0, #7]
    // 0xbe9a10: fcmp            d1, d2
    // 0xbe9a14: b.le            #0xbe9a54
    // 0xbe9a18: ldur            x16, [fp, #-0x28]
    // 0xbe9a1c: str             x16, [SP]
    // 0xbe9a20: ldur            x0, [fp, #-0x28]
    // 0xbe9a24: ClosureCall
    //     0xbe9a24: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbe9a28: ldur            x2, [x0, #0x1f]
    //     0xbe9a2c: blr             x2
    // 0xbe9a30: r16 = true
    //     0xbe9a30: add             x16, NULL, #0x20  ; true
    // 0xbe9a34: cmp             w0, w16
    // 0xbe9a38: b.ne            #0xbe9a4c
    // 0xbe9a3c: ldur            x1, [fp, #-8]
    // 0xbe9a40: ldur            x3, [fp, #-0x68]
    // 0xbe9a44: d0 = 0.000000
    //     0xbe9a44: eor             v0.16b, v0.16b, v0.16b
    // 0xbe9a48: b               #0xbe99f0
    // 0xbe9a4c: r4 = true
    //     0xbe9a4c: add             x4, NULL, #0x20  ; true
    // 0xbe9a50: b               #0xbe9a58
    // 0xbe9a54: r4 = false
    //     0xbe9a54: add             x4, NULL, #0x30  ; false
    // 0xbe9a58: ldur            x3, [fp, #-0x18]
    // 0xbe9a5c: stur            x4, [fp, #-0x30]
    // 0xbe9a60: LoadField: r0 = r3->field_1f
    //     0xbe9a60: ldur            w0, [x3, #0x1f]
    // 0xbe9a64: DecompressPointer r0
    //     0xbe9a64: add             x0, x0, HEAP, lsl #32
    // 0xbe9a68: cmp             w0, NULL
    // 0xbe9a6c: b.eq            #0xbe9ba8
    // 0xbe9a70: LoadField: r5 = r0->field_7
    //     0xbe9a70: ldur            w5, [x0, #7]
    // 0xbe9a74: DecompressPointer r5
    //     0xbe9a74: add             x5, x5, HEAP, lsl #32
    // 0xbe9a78: stur            x5, [fp, #-0x28]
    // 0xbe9a7c: cmp             w5, NULL
    // 0xbe9a80: b.eq            #0xbea0cc
    // 0xbe9a84: mov             x0, x5
    // 0xbe9a88: r2 = Null
    //     0xbe9a88: mov             x2, NULL
    // 0xbe9a8c: r1 = Null
    //     0xbe9a8c: mov             x1, NULL
    // 0xbe9a90: r4 = LoadClassIdInstr(r0)
    //     0xbe9a90: ldur            x4, [x0, #-1]
    //     0xbe9a94: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9a98: r17 = -4183
    //     0xbe9a98: mov             x17, #-0x1057
    // 0xbe9a9c: add             x4, x4, x17
    // 0xbe9aa0: cmp             x4, #1
    // 0xbe9aa4: b.ls            #0xbe9abc
    // 0xbe9aa8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9aa8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9aac: ldr             x8, [x8, #0x590]
    // 0xbe9ab0: r3 = Null
    //     0xbe9ab0: add             x3, PP, #0x96, lsl #12  ; [pp+0x96660] Null
    //     0xbe9ab4: ldr             x3, [x3, #0x660]
    // 0xbe9ab8: r0 = DefaultTypeTest()
    //     0xbe9ab8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9abc: ldur            x0, [fp, #-0x28]
    // 0xbe9ac0: LoadField: r1 = r0->field_f
    //     0xbe9ac0: ldur            w1, [x0, #0xf]
    // 0xbe9ac4: DecompressPointer r1
    //     0xbe9ac4: add             x1, x1, HEAP, lsl #32
    // 0xbe9ac8: mov             x0, x1
    // 0xbe9acc: ldur            x3, [fp, #-0x18]
    // 0xbe9ad0: StoreField: r3->field_1f = r0
    //     0xbe9ad0: stur            w0, [x3, #0x1f]
    //     0xbe9ad4: ldurb           w16, [x3, #-1]
    //     0xbe9ad8: ldurb           w17, [x0, #-1]
    //     0xbe9adc: and             x16, x17, x16, lsr #2
    //     0xbe9ae0: tst             x16, HEAP, lsr #32
    //     0xbe9ae4: b.eq            #0xbe9aec
    //     0xbe9ae8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbe9aec: mov             x0, x1
    // 0xbe9af0: r1 = 0
    //     0xbe9af0: mov             x1, #0
    // 0xbe9af4: CheckStackOverflow
    //     0xbe9af4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe9af8: cmp             SP, x16
    //     0xbe9afc: b.ls            #0xbea0d0
    // 0xbe9b00: cmp             w0, NULL
    // 0xbe9b04: b.eq            #0xbe9b9c
    // 0xbe9b08: add             x4, x1, #1
    // 0xbe9b0c: stur            x4, [fp, #-0x40]
    // 0xbe9b10: LoadField: r5 = r0->field_7
    //     0xbe9b10: ldur            w5, [x0, #7]
    // 0xbe9b14: DecompressPointer r5
    //     0xbe9b14: add             x5, x5, HEAP, lsl #32
    // 0xbe9b18: stur            x5, [fp, #-0x28]
    // 0xbe9b1c: cmp             w5, NULL
    // 0xbe9b20: b.eq            #0xbea0d8
    // 0xbe9b24: mov             x0, x5
    // 0xbe9b28: r2 = Null
    //     0xbe9b28: mov             x2, NULL
    // 0xbe9b2c: r1 = Null
    //     0xbe9b2c: mov             x1, NULL
    // 0xbe9b30: r4 = LoadClassIdInstr(r0)
    //     0xbe9b30: ldur            x4, [x0, #-1]
    //     0xbe9b34: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9b38: r17 = -4183
    //     0xbe9b38: mov             x17, #-0x1057
    // 0xbe9b3c: add             x4, x4, x17
    // 0xbe9b40: cmp             x4, #1
    // 0xbe9b44: b.ls            #0xbe9b5c
    // 0xbe9b48: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9b48: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9b4c: ldr             x8, [x8, #0x590]
    // 0xbe9b50: r3 = Null
    //     0xbe9b50: add             x3, PP, #0x96, lsl #12  ; [pp+0x96670] Null
    //     0xbe9b54: ldr             x3, [x3, #0x670]
    // 0xbe9b58: r0 = DefaultTypeTest()
    //     0xbe9b58: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9b5c: ldur            x0, [fp, #-0x28]
    // 0xbe9b60: LoadField: r2 = r0->field_f
    //     0xbe9b60: ldur            w2, [x0, #0xf]
    // 0xbe9b64: DecompressPointer r2
    //     0xbe9b64: add             x2, x2, HEAP, lsl #32
    // 0xbe9b68: mov             x0, x2
    // 0xbe9b6c: ldur            x4, [fp, #-0x18]
    // 0xbe9b70: StoreField: r4->field_1f = r0
    //     0xbe9b70: stur            w0, [x4, #0x1f]
    //     0xbe9b74: ldurb           w16, [x4, #-1]
    //     0xbe9b78: ldurb           w17, [x0, #-1]
    //     0xbe9b7c: and             x16, x17, x16, lsr #2
    //     0xbe9b80: tst             x16, HEAP, lsr #32
    //     0xbe9b84: b.eq            #0xbe9b8c
    //     0xbe9b88: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbe9b8c: ldur            x1, [fp, #-0x40]
    // 0xbe9b90: mov             x0, x2
    // 0xbe9b94: mov             x3, x4
    // 0xbe9b98: b               #0xbe9af4
    // 0xbe9b9c: mov             x4, x3
    // 0xbe9ba0: mov             x3, x1
    // 0xbe9ba4: b               #0xbe9bb0
    // 0xbe9ba8: mov             x4, x3
    // 0xbe9bac: r3 = 0
    //     0xbe9bac: mov             x3, #0
    // 0xbe9bb0: ldur            x0, [fp, #-0x30]
    // 0xbe9bb4: ldur            x1, [fp, #-8]
    // 0xbe9bb8: ldur            x2, [fp, #-0x68]
    // 0xbe9bbc: r0 = collectGarbage()
    //     0xbe9bbc: bl              #0xbe64f8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0xbe9bc0: ldur            x0, [fp, #-0x30]
    // 0xbe9bc4: tbnz            w0, #4, #0xbe9be0
    // 0xbe9bc8: ldur            x3, [fp, #-0x18]
    // 0xbe9bcc: LoadField: r0 = r3->field_27
    //     0xbe9bcc: ldur            w0, [x3, #0x27]
    // 0xbe9bd0: DecompressPointer r0
    //     0xbe9bd0: add             x0, x0, HEAP, lsl #32
    // 0xbe9bd4: LoadField: d0 = r0->field_7
    //     0xbe9bd4: ldur            d0, [x0, #7]
    // 0xbe9bd8: mov             v1.16b, v0.16b
    // 0xbe9bdc: b               #0xbe9d20
    // 0xbe9be0: ldur            x4, [fp, #-8]
    // 0xbe9be4: ldur            x3, [fp, #-0x18]
    // 0xbe9be8: LoadField: r0 = r4->field_53
    //     0xbe9be8: ldur            w0, [x4, #0x53]
    // 0xbe9bec: DecompressPointer r0
    //     0xbe9bec: add             x0, x0, HEAP, lsl #32
    // 0xbe9bf0: cmp             w0, NULL
    // 0xbe9bf4: b.eq            #0xbea0dc
    // 0xbe9bf8: LoadField: r5 = r0->field_7
    //     0xbe9bf8: ldur            w5, [x0, #7]
    // 0xbe9bfc: DecompressPointer r5
    //     0xbe9bfc: add             x5, x5, HEAP, lsl #32
    // 0xbe9c00: stur            x5, [fp, #-0x28]
    // 0xbe9c04: cmp             w5, NULL
    // 0xbe9c08: b.eq            #0xbea0e0
    // 0xbe9c0c: mov             x0, x5
    // 0xbe9c10: r2 = Null
    //     0xbe9c10: mov             x2, NULL
    // 0xbe9c14: r1 = Null
    //     0xbe9c14: mov             x1, NULL
    // 0xbe9c18: r4 = LoadClassIdInstr(r0)
    //     0xbe9c18: ldur            x4, [x0, #-1]
    //     0xbe9c1c: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9c20: r17 = -4183
    //     0xbe9c20: mov             x17, #-0x1057
    // 0xbe9c24: add             x4, x4, x17
    // 0xbe9c28: cmp             x4, #1
    // 0xbe9c2c: b.ls            #0xbe9c44
    // 0xbe9c30: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9c30: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9c34: ldr             x8, [x8, #0x590]
    // 0xbe9c38: r3 = Null
    //     0xbe9c38: add             x3, PP, #0x96, lsl #12  ; [pp+0x96680] Null
    //     0xbe9c3c: ldr             x3, [x3, #0x680]
    // 0xbe9c40: r0 = DefaultTypeTest()
    //     0xbe9c40: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9c44: ldur            x3, [fp, #-0x28]
    // 0xbe9c48: ArrayLoad: r4 = r3[0]  ; List_4
    //     0xbe9c48: ldur            w4, [x3, #0x17]
    // 0xbe9c4c: DecompressPointer r4
    //     0xbe9c4c: add             x4, x4, HEAP, lsl #32
    // 0xbe9c50: stur            x4, [fp, #-0x38]
    // 0xbe9c54: cmp             w4, NULL
    // 0xbe9c58: b.eq            #0xbea0e4
    // 0xbe9c5c: ldur            x5, [fp, #-8]
    // 0xbe9c60: LoadField: r0 = r5->field_57
    //     0xbe9c60: ldur            w0, [x5, #0x57]
    // 0xbe9c64: DecompressPointer r0
    //     0xbe9c64: add             x0, x0, HEAP, lsl #32
    // 0xbe9c68: cmp             w0, NULL
    // 0xbe9c6c: b.eq            #0xbea0e8
    // 0xbe9c70: LoadField: r6 = r0->field_7
    //     0xbe9c70: ldur            w6, [x0, #7]
    // 0xbe9c74: DecompressPointer r6
    //     0xbe9c74: add             x6, x6, HEAP, lsl #32
    // 0xbe9c78: stur            x6, [fp, #-0x30]
    // 0xbe9c7c: cmp             w6, NULL
    // 0xbe9c80: b.eq            #0xbea0ec
    // 0xbe9c84: mov             x0, x6
    // 0xbe9c88: r2 = Null
    //     0xbe9c88: mov             x2, NULL
    // 0xbe9c8c: r1 = Null
    //     0xbe9c8c: mov             x1, NULL
    // 0xbe9c90: r4 = LoadClassIdInstr(r0)
    //     0xbe9c90: ldur            x4, [x0, #-1]
    //     0xbe9c94: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9c98: r17 = -4183
    //     0xbe9c98: mov             x17, #-0x1057
    // 0xbe9c9c: add             x4, x4, x17
    // 0xbe9ca0: cmp             x4, #1
    // 0xbe9ca4: b.ls            #0xbe9cbc
    // 0xbe9ca8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9ca8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9cac: ldr             x8, [x8, #0x590]
    // 0xbe9cb0: r3 = Null
    //     0xbe9cb0: add             x3, PP, #0x96, lsl #12  ; [pp+0x96690] Null
    //     0xbe9cb4: ldr             x3, [x3, #0x690]
    // 0xbe9cb8: r0 = DefaultTypeTest()
    //     0xbe9cb8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9cbc: ldur            x0, [fp, #-0x30]
    // 0xbe9cc0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe9cc0: ldur            w1, [x0, #0x17]
    // 0xbe9cc4: DecompressPointer r1
    //     0xbe9cc4: add             x1, x1, HEAP, lsl #32
    // 0xbe9cc8: cmp             w1, NULL
    // 0xbe9ccc: b.eq            #0xbea0f0
    // 0xbe9cd0: ldur            x0, [fp, #-0x28]
    // 0xbe9cd4: LoadField: r6 = r0->field_7
    //     0xbe9cd4: ldur            w6, [x0, #7]
    // 0xbe9cd8: DecompressPointer r6
    //     0xbe9cd8: add             x6, x6, HEAP, lsl #32
    // 0xbe9cdc: ldur            x0, [fp, #-0x18]
    // 0xbe9ce0: LoadField: r2 = r0->field_27
    //     0xbe9ce0: ldur            w2, [x0, #0x27]
    // 0xbe9ce4: DecompressPointer r2
    //     0xbe9ce4: add             x2, x2, HEAP, lsl #32
    // 0xbe9ce8: ldur            x3, [fp, #-0x38]
    // 0xbe9cec: r4 = LoadInt32Instr(r3)
    //     0xbe9cec: sbfx            x4, x3, #1, #0x1f
    //     0xbe9cf0: tbz             w3, #0, #0xbe9cf8
    //     0xbe9cf4: ldur            x4, [x3, #7]
    // 0xbe9cf8: r5 = LoadInt32Instr(r1)
    //     0xbe9cf8: sbfx            x5, x1, #1, #0x1f
    //     0xbe9cfc: tbz             w1, #0, #0xbe9d04
    //     0xbe9d00: ldur            x5, [x1, #7]
    // 0xbe9d04: LoadField: d0 = r2->field_7
    //     0xbe9d04: ldur            d0, [x2, #7]
    // 0xbe9d08: ldur            x1, [fp, #-0x20]
    // 0xbe9d0c: ldur            x2, [fp, #-0x10]
    // 0xbe9d10: mov             x3, x4
    // 0xbe9d14: r0 = estimateMaxScrollOffset()
    //     0xbe9d14: bl              #0xbe496c  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::estimateMaxScrollOffset
    // 0xbe9d18: mov             v1.16b, v0.16b
    // 0xbe9d1c: ldur            x3, [fp, #-0x18]
    // 0xbe9d20: ldur            x4, [fp, #-8]
    // 0xbe9d24: ldur            d0, [fp, #-0x80]
    // 0xbe9d28: ldur            x5, [fp, #-0x10]
    // 0xbe9d2c: stur            d1, [fp, #-0x70]
    // 0xbe9d30: LoadField: r0 = r4->field_53
    //     0xbe9d30: ldur            w0, [x4, #0x53]
    // 0xbe9d34: DecompressPointer r0
    //     0xbe9d34: add             x0, x0, HEAP, lsl #32
    // 0xbe9d38: cmp             w0, NULL
    // 0xbe9d3c: b.eq            #0xbea0f4
    // 0xbe9d40: LoadField: r6 = r0->field_7
    //     0xbe9d40: ldur            w6, [x0, #7]
    // 0xbe9d44: DecompressPointer r6
    //     0xbe9d44: add             x6, x6, HEAP, lsl #32
    // 0xbe9d48: stur            x6, [fp, #-0x28]
    // 0xbe9d4c: cmp             w6, NULL
    // 0xbe9d50: b.eq            #0xbea0f8
    // 0xbe9d54: mov             x0, x6
    // 0xbe9d58: r2 = Null
    //     0xbe9d58: mov             x2, NULL
    // 0xbe9d5c: r1 = Null
    //     0xbe9d5c: mov             x1, NULL
    // 0xbe9d60: r4 = LoadClassIdInstr(r0)
    //     0xbe9d60: ldur            x4, [x0, #-1]
    //     0xbe9d64: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9d68: r17 = -4183
    //     0xbe9d68: mov             x17, #-0x1057
    // 0xbe9d6c: add             x4, x4, x17
    // 0xbe9d70: cmp             x4, #1
    // 0xbe9d74: b.ls            #0xbe9d8c
    // 0xbe9d78: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9d78: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9d7c: ldr             x8, [x8, #0x590]
    // 0xbe9d80: r3 = Null
    //     0xbe9d80: add             x3, PP, #0x96, lsl #12  ; [pp+0x966a0] Null
    //     0xbe9d84: ldr             x3, [x3, #0x6a0]
    // 0xbe9d88: r0 = DefaultTypeTest()
    //     0xbe9d88: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9d8c: ldur            x0, [fp, #-0x28]
    // 0xbe9d90: LoadField: r1 = r0->field_7
    //     0xbe9d90: ldur            w1, [x0, #7]
    // 0xbe9d94: DecompressPointer r1
    //     0xbe9d94: add             x1, x1, HEAP, lsl #32
    // 0xbe9d98: cmp             w1, NULL
    // 0xbe9d9c: b.eq            #0xbea0fc
    // 0xbe9da0: ldur            x0, [fp, #-0x18]
    // 0xbe9da4: LoadField: r2 = r0->field_27
    //     0xbe9da4: ldur            w2, [x0, #0x27]
    // 0xbe9da8: DecompressPointer r2
    //     0xbe9da8: add             x2, x2, HEAP, lsl #32
    // 0xbe9dac: LoadField: d0 = r1->field_7
    //     0xbe9dac: ldur            d0, [x1, #7]
    // 0xbe9db0: LoadField: d1 = r2->field_7
    //     0xbe9db0: ldur            d1, [x2, #7]
    // 0xbe9db4: ldur            x1, [fp, #-8]
    // 0xbe9db8: ldur            x2, [fp, #-0x10]
    // 0xbe9dbc: r0 = calculatePaintOffset()
    //     0xbe9dbc: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbe9dc0: ldur            x3, [fp, #-8]
    // 0xbe9dc4: stur            d0, [fp, #-0x78]
    // 0xbe9dc8: LoadField: r0 = r3->field_53
    //     0xbe9dc8: ldur            w0, [x3, #0x53]
    // 0xbe9dcc: DecompressPointer r0
    //     0xbe9dcc: add             x0, x0, HEAP, lsl #32
    // 0xbe9dd0: cmp             w0, NULL
    // 0xbe9dd4: b.eq            #0xbea100
    // 0xbe9dd8: LoadField: r4 = r0->field_7
    //     0xbe9dd8: ldur            w4, [x0, #7]
    // 0xbe9ddc: DecompressPointer r4
    //     0xbe9ddc: add             x4, x4, HEAP, lsl #32
    // 0xbe9de0: stur            x4, [fp, #-0x28]
    // 0xbe9de4: cmp             w4, NULL
    // 0xbe9de8: b.eq            #0xbea104
    // 0xbe9dec: mov             x0, x4
    // 0xbe9df0: r2 = Null
    //     0xbe9df0: mov             x2, NULL
    // 0xbe9df4: r1 = Null
    //     0xbe9df4: mov             x1, NULL
    // 0xbe9df8: r4 = LoadClassIdInstr(r0)
    //     0xbe9df8: ldur            x4, [x0, #-1]
    //     0xbe9dfc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe9e00: r17 = -4183
    //     0xbe9e00: mov             x17, #-0x1057
    // 0xbe9e04: add             x4, x4, x17
    // 0xbe9e08: cmp             x4, #1
    // 0xbe9e0c: b.ls            #0xbe9e24
    // 0xbe9e10: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe9e10: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe9e14: ldr             x8, [x8, #0x590]
    // 0xbe9e18: r3 = Null
    //     0xbe9e18: add             x3, PP, #0x96, lsl #12  ; [pp+0x966b0] Null
    //     0xbe9e1c: ldr             x3, [x3, #0x6b0]
    // 0xbe9e20: r0 = DefaultTypeTest()
    //     0xbe9e20: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe9e24: ldur            x0, [fp, #-0x28]
    // 0xbe9e28: LoadField: r1 = r0->field_7
    //     0xbe9e28: ldur            w1, [x0, #7]
    // 0xbe9e2c: DecompressPointer r1
    //     0xbe9e2c: add             x1, x1, HEAP, lsl #32
    // 0xbe9e30: cmp             w1, NULL
    // 0xbe9e34: b.eq            #0xbea108
    // 0xbe9e38: ldur            x0, [fp, #-0x18]
    // 0xbe9e3c: LoadField: r2 = r0->field_27
    //     0xbe9e3c: ldur            w2, [x0, #0x27]
    // 0xbe9e40: DecompressPointer r2
    //     0xbe9e40: add             x2, x2, HEAP, lsl #32
    // 0xbe9e44: LoadField: d0 = r1->field_7
    //     0xbe9e44: ldur            d0, [x1, #7]
    // 0xbe9e48: LoadField: d1 = r2->field_7
    //     0xbe9e48: ldur            d1, [x2, #7]
    // 0xbe9e4c: ldur            x1, [fp, #-8]
    // 0xbe9e50: ldur            x2, [fp, #-0x10]
    // 0xbe9e54: r0 = calculateCacheOffset()
    //     0xbe9e54: bl              #0xbe4790  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0xbe9e58: ldur            x0, [fp, #-0x10]
    // 0xbe9e5c: stur            d0, [fp, #-0x90]
    // 0xbe9e60: LoadField: d1 = r0->field_2b
    //     0xbe9e60: ldur            d1, [x0, #0x2b]
    // 0xbe9e64: ldur            d2, [fp, #-0x80]
    // 0xbe9e68: fadd            d3, d2, d1
    // 0xbe9e6c: ldur            x0, [fp, #-0x18]
    // 0xbe9e70: LoadField: r1 = r0->field_27
    //     0xbe9e70: ldur            w1, [x0, #0x27]
    // 0xbe9e74: DecompressPointer r1
    //     0xbe9e74: add             x1, x1, HEAP, lsl #32
    // 0xbe9e78: LoadField: d1 = r1->field_7
    //     0xbe9e78: ldur            d1, [x1, #7]
    // 0xbe9e7c: stur            d1, [fp, #-0x88]
    // 0xbe9e80: fcmp            d1, d3
    // 0xbe9e84: b.le            #0xbe9e94
    // 0xbe9e88: r1 = true
    //     0xbe9e88: add             x1, NULL, #0x20  ; true
    // 0xbe9e8c: d3 = 0.000000
    //     0xbe9e8c: eor             v3.16b, v3.16b, v3.16b
    // 0xbe9e90: b               #0xbe9eac
    // 0xbe9e94: d3 = 0.000000
    //     0xbe9e94: eor             v3.16b, v3.16b, v3.16b
    // 0xbe9e98: fcmp            d2, d3
    // 0xbe9e9c: r16 = true
    //     0xbe9e9c: add             x16, NULL, #0x20  ; true
    // 0xbe9ea0: r17 = false
    //     0xbe9ea0: add             x17, NULL, #0x30  ; false
    // 0xbe9ea4: csel            x0, x16, x17, gt
    // 0xbe9ea8: mov             x1, x0
    // 0xbe9eac: ldur            x0, [fp, #-8]
    // 0xbe9eb0: ldur            d4, [fp, #-0x70]
    // 0xbe9eb4: ldur            d2, [fp, #-0x78]
    // 0xbe9eb8: stur            x1, [fp, #-0x10]
    // 0xbe9ebc: r0 = SliverGeometry()
    //     0xbe9ebc: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe9ec0: ldur            d0, [fp, #-0x70]
    // 0xbe9ec4: StoreField: r0->field_7 = d0
    //     0xbe9ec4: stur            d0, [x0, #7]
    // 0xbe9ec8: ldur            d1, [fp, #-0x78]
    // 0xbe9ecc: ArrayStore: r0[0] = d1  ; List_8
    //     0xbe9ecc: stur            d1, [x0, #0x17]
    // 0xbe9ed0: StoreField: r0->field_f = rZR
    //     0xbe9ed0: stur            xzr, [x0, #0xf]
    // 0xbe9ed4: StoreField: r0->field_27 = d0
    //     0xbe9ed4: stur            d0, [x0, #0x27]
    // 0xbe9ed8: StoreField: r0->field_2f = rZR
    //     0xbe9ed8: stur            xzr, [x0, #0x2f]
    // 0xbe9edc: ldur            x1, [fp, #-0x10]
    // 0xbe9ee0: StoreField: r0->field_43 = r1
    //     0xbe9ee0: stur            w1, [x0, #0x43]
    // 0xbe9ee4: StoreField: r0->field_1f = d1
    //     0xbe9ee4: stur            d1, [x0, #0x1f]
    // 0xbe9ee8: StoreField: r0->field_37 = d1
    //     0xbe9ee8: stur            d1, [x0, #0x37]
    // 0xbe9eec: ldur            d2, [fp, #-0x90]
    // 0xbe9ef0: StoreField: r0->field_4b = d2
    //     0xbe9ef0: stur            d2, [x0, #0x4b]
    // 0xbe9ef4: d2 = 0.000000
    //     0xbe9ef4: eor             v2.16b, v2.16b, v2.16b
    // 0xbe9ef8: fcmp            d1, d2
    // 0xbe9efc: r16 = true
    //     0xbe9efc: add             x16, NULL, #0x20  ; true
    // 0xbe9f00: r17 = false
    //     0xbe9f00: add             x17, NULL, #0x30  ; false
    // 0xbe9f04: csel            x1, x16, x17, gt
    // 0xbe9f08: StoreField: r0->field_3f = r1
    //     0xbe9f08: stur            w1, [x0, #0x3f]
    // 0xbe9f0c: ldur            x1, [fp, #-8]
    // 0xbe9f10: StoreField: r1->field_47 = r0
    //     0xbe9f10: stur            w0, [x1, #0x47]
    //     0xbe9f14: ldurb           w16, [x1, #-1]
    //     0xbe9f18: ldurb           w17, [x0, #-1]
    //     0xbe9f1c: and             x16, x17, x16, lsr #2
    //     0xbe9f20: tst             x16, HEAP, lsr #32
    //     0xbe9f24: b.eq            #0xbe9f2c
    //     0xbe9f28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe9f2c: ldur            d1, [fp, #-0x88]
    // 0xbe9f30: fcmp            d0, d1
    // 0xbe9f34: b.ne            #0xbe9f48
    // 0xbe9f38: ldur            x1, [fp, #-0x20]
    // 0xbe9f3c: r0 = true
    //     0xbe9f3c: add             x0, NULL, #0x20  ; true
    // 0xbe9f40: StoreField: r1->field_53 = r0
    //     0xbe9f40: stur            w0, [x1, #0x53]
    // 0xbe9f44: b               #0xbe9f4c
    // 0xbe9f48: ldur            x1, [fp, #-0x20]
    // 0xbe9f4c: r0 = didFinishLayout()
    //     0xbe9f4c: bl              #0xbe5ab0  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0xbe9f50: r0 = Null
    //     0xbe9f50: mov             x0, NULL
    // 0xbe9f54: LeaveFrame
    //     0xbe9f54: mov             SP, fp
    //     0xbe9f58: ldp             fp, lr, [SP], #0x10
    // 0xbe9f5c: ret
    //     0xbe9f5c: ret             
    // 0xbe9f60: r0 = StateError()
    //     0xbe9f60: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe9f64: mov             x1, x0
    // 0xbe9f68: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe9f68: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe9f6c: StoreField: r1->field_b = r0
    //     0xbe9f6c: stur            w0, [x1, #0xb]
    // 0xbe9f70: mov             x0, x1
    // 0xbe9f74: r0 = Throw()
    //     0xbe9f74: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe9f78: brk             #0
    // 0xbe9f7c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe9f7c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe9f80: r0 = StateError()
    //     0xbe9f80: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe9f84: mov             x1, x0
    // 0xbe9f88: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe9f88: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe9f8c: StoreField: r1->field_b = r0
    //     0xbe9f8c: stur            w0, [x1, #0xb]
    // 0xbe9f90: mov             x0, x1
    // 0xbe9f94: r0 = Throw()
    //     0xbe9f94: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe9f98: brk             #0
    // 0xbe9f9c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe9f9c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe9fa0: r0 = StateError()
    //     0xbe9fa0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe9fa4: mov             x1, x0
    // 0xbe9fa8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe9fa8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe9fac: StoreField: r1->field_b = r0
    //     0xbe9fac: stur            w0, [x1, #0xb]
    // 0xbe9fb0: mov             x0, x1
    // 0xbe9fb4: r0 = Throw()
    //     0xbe9fb4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe9fb8: brk             #0
    // 0xbe9fbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe9fbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe9fc0: b               #0xbe8b6c
    // 0xbe9fc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe9fc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe9fc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe9fc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe9fcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe9fcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe9fd0: b               #0xbe8d34
    // 0xbe9fd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe9fd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe9fd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe9fd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe9fdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe9fdc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe9fe0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe9fe0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe9fe4: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe9fe4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe9fe8: b               #0xbe8ed0
    // 0xbe9fec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe9fec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe9ff0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe9ff0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe9ff4: SaveReg d1
    //     0xbe9ff4: str             q1, [SP, #-0x10]!
    // 0xbe9ff8: r0 = AllocateDouble()
    //     0xbe9ff8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe9ffc: RestoreReg d1
    //     0xbe9ffc: ldr             q1, [SP], #0x10
    // 0xbea000: b               #0xbe9030
    // 0xbea004: SaveReg d0
    //     0xbea004: str             q0, [SP, #-0x10]!
    // 0xbea008: SaveReg r0
    //     0xbea008: str             x0, [SP, #-8]!
    // 0xbea00c: r0 = AllocateDouble()
    //     0xbea00c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbea010: mov             x1, x0
    // 0xbea014: RestoreReg r0
    //     0xbea014: ldr             x0, [SP], #8
    // 0xbea018: RestoreReg d0
    //     0xbea018: ldr             q0, [SP], #0x10
    // 0xbea01c: b               #0xbe90f0
    // 0xbea020: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea020: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea024: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea028: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea028: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea02c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea02c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea030: SaveReg d0
    //     0xbea030: str             q0, [SP, #-0x10]!
    // 0xbea034: SaveReg r0
    //     0xbea034: str             x0, [SP, #-8]!
    // 0xbea038: r0 = AllocateDouble()
    //     0xbea038: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbea03c: mov             x1, x0
    // 0xbea040: RestoreReg r0
    //     0xbea040: ldr             x0, [SP], #8
    // 0xbea044: RestoreReg d0
    //     0xbea044: ldr             q0, [SP], #0x10
    // 0xbea048: b               #0xbe9338
    // 0xbea04c: r0 = StackOverflowSharedWithFPURegs()
    //     0xbea04c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbea050: b               #0xbe93cc
    // 0xbea054: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea054: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea058: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea058: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea05c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea05c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea060: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea064: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea064: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea068: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea068: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea06c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea06c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea070: SaveReg d0
    //     0xbea070: str             q0, [SP, #-0x10]!
    // 0xbea074: SaveReg r0
    //     0xbea074: str             x0, [SP, #-8]!
    // 0xbea078: r0 = AllocateDouble()
    //     0xbea078: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbea07c: mov             x1, x0
    // 0xbea080: RestoreReg r0
    //     0xbea080: ldr             x0, [SP], #8
    // 0xbea084: RestoreReg d0
    //     0xbea084: ldr             q0, [SP], #0x10
    // 0xbea088: b               #0xbe961c
    // 0xbea08c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea08c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea090: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea090: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea094: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea094: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea098: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea098: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea09c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea09c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0a0: SaveReg d2
    //     0xbea0a0: str             q2, [SP, #-0x10]!
    // 0xbea0a4: r0 = AllocateDouble()
    //     0xbea0a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbea0a8: RestoreReg d2
    //     0xbea0a8: ldr             q2, [SP], #0x10
    // 0xbea0ac: b               #0xbe9820
    // 0xbea0b0: r0 = StackOverflowSharedWithFPURegs()
    //     0xbea0b0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbea0b4: b               #0xbe9878
    // 0xbea0b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0c4: r0 = StackOverflowSharedWithFPURegs()
    //     0xbea0c4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbea0c8: b               #0xbe9a04
    // 0xbea0cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbea0d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbea0d4: b               #0xbe9b00
    // 0xbea0d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0ec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea0f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea0f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea0f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea0f8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea0fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea0fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea100: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea100: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea104: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbea104: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbea108: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea108: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool advance(dynamic) {
    // ** addr: 0xbea10c, size: 0x41c
    // 0xbea10c: EnterFrame
    //     0xbea10c: stp             fp, lr, [SP, #-0x10]!
    //     0xbea110: mov             fp, SP
    // 0xbea114: AllocStack(0x38)
    //     0xbea114: sub             SP, SP, #0x38
    // 0xbea118: SetupParameters([dynamic _ /* r0 */])
    //     0xbea118: ldr             x0, [fp, #0x10]
    //     0xbea11c: ldur            w1, [x0, #0x17]
    //     0xbea120: add             x1, x1, HEAP, lsl #32
    //     0xbea124: stur            x1, [fp, #-8]
    // 0xbea128: CheckStackOverflow
    //     0xbea128: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbea12c: cmp             SP, x16
    //     0xbea130: b.ls            #0xbea4f8
    // 0xbea134: LoadField: r0 = r1->field_1f
    //     0xbea134: ldur            w0, [x1, #0x1f]
    // 0xbea138: DecompressPointer r0
    //     0xbea138: add             x0, x0, HEAP, lsl #32
    // 0xbea13c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbea13c: ldur            w2, [x1, #0x17]
    // 0xbea140: DecompressPointer r2
    //     0xbea140: add             x2, x2, HEAP, lsl #32
    // 0xbea144: r3 = LoadClassIdInstr(r0)
    //     0xbea144: ldur            x3, [x0, #-1]
    //     0xbea148: ubfx            x3, x3, #0xc, #0x14
    // 0xbea14c: stp             x2, x0, [SP]
    // 0xbea150: mov             x0, x3
    // 0xbea154: mov             lr, x0
    // 0xbea158: ldr             lr, [x21, lr, lsl #3]
    // 0xbea15c: blr             lr
    // 0xbea160: tbnz            w0, #4, #0xbea174
    // 0xbea164: ldur            x3, [fp, #-8]
    // 0xbea168: r4 = false
    //     0xbea168: add             x4, NULL, #0x30  ; false
    // 0xbea16c: StoreField: r3->field_1b = r4
    //     0xbea16c: stur            w4, [x3, #0x1b]
    // 0xbea170: b               #0xbea17c
    // 0xbea174: ldur            x3, [fp, #-8]
    // 0xbea178: r4 = false
    //     0xbea178: add             x4, NULL, #0x30  ; false
    // 0xbea17c: LoadField: r5 = r3->field_f
    //     0xbea17c: ldur            w5, [x3, #0xf]
    // 0xbea180: DecompressPointer r5
    //     0xbea180: add             x5, x5, HEAP, lsl #32
    // 0xbea184: stur            x5, [fp, #-0x18]
    // 0xbea188: LoadField: r0 = r3->field_1f
    //     0xbea188: ldur            w0, [x3, #0x1f]
    // 0xbea18c: DecompressPointer r0
    //     0xbea18c: add             x0, x0, HEAP, lsl #32
    // 0xbea190: cmp             w0, NULL
    // 0xbea194: b.eq            #0xbea500
    // 0xbea198: LoadField: r6 = r0->field_7
    //     0xbea198: ldur            w6, [x0, #7]
    // 0xbea19c: DecompressPointer r6
    //     0xbea19c: add             x6, x6, HEAP, lsl #32
    // 0xbea1a0: stur            x6, [fp, #-0x10]
    // 0xbea1a4: cmp             w6, NULL
    // 0xbea1a8: b.eq            #0xbea504
    // 0xbea1ac: mov             x0, x6
    // 0xbea1b0: r2 = Null
    //     0xbea1b0: mov             x2, NULL
    // 0xbea1b4: r1 = Null
    //     0xbea1b4: mov             x1, NULL
    // 0xbea1b8: r4 = LoadClassIdInstr(r0)
    //     0xbea1b8: ldur            x4, [x0, #-1]
    //     0xbea1bc: ubfx            x4, x4, #0xc, #0x14
    // 0xbea1c0: r17 = -4183
    //     0xbea1c0: mov             x17, #-0x1057
    // 0xbea1c4: add             x4, x4, x17
    // 0xbea1c8: cmp             x4, #1
    // 0xbea1cc: b.ls            #0xbea1e4
    // 0xbea1d0: r8 = SliverMultiBoxAdaptorParentData
    //     0xbea1d0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbea1d4: ldr             x8, [x8, #0x590]
    // 0xbea1d8: r3 = Null
    //     0xbea1d8: add             x3, PP, #0x96, lsl #12  ; [pp+0x966c0] Null
    //     0xbea1dc: ldr             x3, [x3, #0x6c0]
    // 0xbea1e0: r0 = DefaultTypeTest()
    //     0xbea1e0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbea1e4: ldur            x0, [fp, #-0x10]
    // 0xbea1e8: LoadField: r3 = r0->field_f
    //     0xbea1e8: ldur            w3, [x0, #0xf]
    // 0xbea1ec: DecompressPointer r3
    //     0xbea1ec: add             x3, x3, HEAP, lsl #32
    // 0xbea1f0: mov             x0, x3
    // 0xbea1f4: ldur            x4, [fp, #-8]
    // 0xbea1f8: stur            x3, [fp, #-0x28]
    // 0xbea1fc: StoreField: r4->field_1f = r0
    //     0xbea1fc: stur            w0, [x4, #0x1f]
    //     0xbea200: ldurb           w16, [x4, #-1]
    //     0xbea204: ldurb           w17, [x0, #-1]
    //     0xbea208: and             x16, x17, x16, lsr #2
    //     0xbea20c: tst             x16, HEAP, lsr #32
    //     0xbea210: b.eq            #0xbea218
    //     0xbea214: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbea218: cmp             w3, NULL
    // 0xbea21c: b.ne            #0xbea22c
    // 0xbea220: r5 = false
    //     0xbea220: add             x5, NULL, #0x30  ; false
    // 0xbea224: StoreField: r4->field_1b = r5
    //     0xbea224: stur            w5, [x4, #0x1b]
    // 0xbea228: b               #0xbea230
    // 0xbea22c: r5 = false
    //     0xbea22c: add             x5, NULL, #0x30  ; false
    // 0xbea230: LoadField: r0 = r4->field_23
    //     0xbea230: ldur            w0, [x4, #0x23]
    // 0xbea234: DecompressPointer r0
    //     0xbea234: add             x0, x0, HEAP, lsl #32
    // 0xbea238: r1 = LoadInt32Instr(r0)
    //     0xbea238: sbfx            x1, x0, #1, #0x1f
    //     0xbea23c: tbz             w0, #0, #0xbea244
    //     0xbea240: ldur            x1, [x0, #7]
    // 0xbea244: add             x6, x1, #1
    // 0xbea248: stur            x6, [fp, #-0x20]
    // 0xbea24c: r0 = BoxInt64Instr(r6)
    //     0xbea24c: sbfiz           x0, x6, #1, #0x1f
    //     0xbea250: cmp             x6, x0, asr #1
    //     0xbea254: b.eq            #0xbea260
    //     0xbea258: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbea25c: stur            x6, [x0, #7]
    // 0xbea260: StoreField: r4->field_23 = r0
    //     0xbea260: stur            w0, [x4, #0x23]
    //     0xbea264: tbz             w0, #0, #0xbea280
    //     0xbea268: ldurb           w16, [x4, #-1]
    //     0xbea26c: ldurb           w17, [x0, #-1]
    //     0xbea270: and             x16, x17, x16, lsr #2
    //     0xbea274: tst             x16, HEAP, lsr #32
    //     0xbea278: b.eq            #0xbea280
    //     0xbea27c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbea280: LoadField: r0 = r4->field_1b
    //     0xbea280: ldur            w0, [x4, #0x1b]
    // 0xbea284: DecompressPointer r0
    //     0xbea284: add             x0, x0, HEAP, lsl #32
    // 0xbea288: tbz             w0, #4, #0xbea3e8
    // 0xbea28c: cmp             w3, NULL
    // 0xbea290: b.ne            #0xbea29c
    // 0xbea294: mov             x0, x4
    // 0xbea298: b               #0xbea318
    // 0xbea29c: LoadField: r7 = r3->field_7
    //     0xbea29c: ldur            w7, [x3, #7]
    // 0xbea2a0: DecompressPointer r7
    //     0xbea2a0: add             x7, x7, HEAP, lsl #32
    // 0xbea2a4: stur            x7, [fp, #-0x10]
    // 0xbea2a8: cmp             w7, NULL
    // 0xbea2ac: b.eq            #0xbea508
    // 0xbea2b0: mov             x0, x7
    // 0xbea2b4: r2 = Null
    //     0xbea2b4: mov             x2, NULL
    // 0xbea2b8: r1 = Null
    //     0xbea2b8: mov             x1, NULL
    // 0xbea2bc: r4 = LoadClassIdInstr(r0)
    //     0xbea2bc: ldur            x4, [x0, #-1]
    //     0xbea2c0: ubfx            x4, x4, #0xc, #0x14
    // 0xbea2c4: r17 = -4183
    //     0xbea2c4: mov             x17, #-0x1057
    // 0xbea2c8: add             x4, x4, x17
    // 0xbea2cc: cmp             x4, #1
    // 0xbea2d0: b.ls            #0xbea2e8
    // 0xbea2d4: r8 = SliverMultiBoxAdaptorParentData
    //     0xbea2d4: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbea2d8: ldr             x8, [x8, #0x590]
    // 0xbea2dc: r3 = Null
    //     0xbea2dc: add             x3, PP, #0x96, lsl #12  ; [pp+0x966d0] Null
    //     0xbea2e0: ldr             x3, [x3, #0x6d0]
    // 0xbea2e4: r0 = DefaultTypeTest()
    //     0xbea2e4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbea2e8: ldur            x0, [fp, #-0x10]
    // 0xbea2ec: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbea2ec: ldur            w1, [x0, #0x17]
    // 0xbea2f0: DecompressPointer r1
    //     0xbea2f0: add             x1, x1, HEAP, lsl #32
    // 0xbea2f4: cmp             w1, NULL
    // 0xbea2f8: b.eq            #0xbea50c
    // 0xbea2fc: r0 = LoadInt32Instr(r1)
    //     0xbea2fc: sbfx            x0, x1, #1, #0x1f
    //     0xbea300: tbz             w1, #0, #0xbea308
    //     0xbea304: ldur            x0, [x1, #7]
    // 0xbea308: ldur            x1, [fp, #-0x20]
    // 0xbea30c: cmp             x0, x1
    // 0xbea310: b.eq            #0xbea37c
    // 0xbea314: ldur            x0, [fp, #-8]
    // 0xbea318: LoadField: r2 = r0->field_13
    //     0xbea318: ldur            w2, [x0, #0x13]
    // 0xbea31c: DecompressPointer r2
    //     0xbea31c: add             x2, x2, HEAP, lsl #32
    // 0xbea320: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xbea320: ldur            w3, [x0, #0x17]
    // 0xbea324: DecompressPointer r3
    //     0xbea324: add             x3, x3, HEAP, lsl #32
    // 0xbea328: r16 = true
    //     0xbea328: add             x16, NULL, #0x20  ; true
    // 0xbea32c: str             x16, [SP]
    // 0xbea330: ldur            x1, [fp, #-0x18]
    // 0xbea334: r4 = const [0, 0x4, 0x1, 0x3, parentUsesSize, 0x3, null]
    //     0xbea334: add             x4, PP, #0x96, lsl #12  ; [pp+0x966e0] List(7) [0, 0x4, 0x1, 0x3, "parentUsesSize", 0x3, Null]
    //     0xbea338: ldr             x4, [x4, #0x6e0]
    // 0xbea33c: r0 = insertAndLayoutChild()
    //     0xbea33c: bl              #0xbe4bac  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutChild
    // 0xbea340: mov             x1, x0
    // 0xbea344: ldur            x3, [fp, #-8]
    // 0xbea348: StoreField: r3->field_1f = r0
    //     0xbea348: stur            w0, [x3, #0x1f]
    //     0xbea34c: ldurb           w16, [x3, #-1]
    //     0xbea350: ldurb           w17, [x0, #-1]
    //     0xbea354: and             x16, x17, x16, lsr #2
    //     0xbea358: tst             x16, HEAP, lsr #32
    //     0xbea35c: b.eq            #0xbea364
    //     0xbea360: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbea364: cmp             w1, NULL
    // 0xbea368: b.ne            #0xbea3b8
    // 0xbea36c: r0 = false
    //     0xbea36c: add             x0, NULL, #0x30  ; false
    // 0xbea370: LeaveFrame
    //     0xbea370: mov             SP, fp
    //     0xbea374: ldp             fp, lr, [SP], #0x10
    // 0xbea378: ret
    //     0xbea378: ret             
    // 0xbea37c: ldur            x3, [fp, #-8]
    // 0xbea380: ldur            x1, [fp, #-0x28]
    // 0xbea384: LoadField: r2 = r3->field_13
    //     0xbea384: ldur            w2, [x3, #0x13]
    // 0xbea388: DecompressPointer r2
    //     0xbea388: add             x2, x2, HEAP, lsl #32
    // 0xbea38c: r0 = LoadClassIdInstr(r1)
    //     0xbea38c: ldur            x0, [x1, #-1]
    //     0xbea390: ubfx            x0, x0, #0xc, #0x14
    // 0xbea394: r16 = true
    //     0xbea394: add             x16, NULL, #0x20  ; true
    // 0xbea398: str             x16, [SP]
    // 0xbea39c: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbea39c: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbea3a0: ldr             x4, [x4, #0xed0]
    // 0xbea3a4: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbea3a4: mov             x17, #0xe6b9
    //     0xbea3a8: add             lr, x0, x17
    //     0xbea3ac: ldr             lr, [x21, lr, lsl #3]
    //     0xbea3b0: blr             lr
    // 0xbea3b4: ldur            x3, [fp, #-8]
    // 0xbea3b8: LoadField: r1 = r3->field_1f
    //     0xbea3b8: ldur            w1, [x3, #0x1f]
    // 0xbea3bc: DecompressPointer r1
    //     0xbea3bc: add             x1, x1, HEAP, lsl #32
    // 0xbea3c0: mov             x0, x1
    // 0xbea3c4: ArrayStore: r3[0] = r0  ; List_4
    //     0xbea3c4: stur            w0, [x3, #0x17]
    //     0xbea3c8: ldurb           w16, [x3, #-1]
    //     0xbea3cc: ldurb           w17, [x0, #-1]
    //     0xbea3d0: and             x16, x17, x16, lsr #2
    //     0xbea3d4: tst             x16, HEAP, lsr #32
    //     0xbea3d8: b.eq            #0xbea3e0
    //     0xbea3dc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbea3e0: mov             x4, x1
    // 0xbea3e4: b               #0xbea3f4
    // 0xbea3e8: mov             x1, x3
    // 0xbea3ec: mov             x3, x4
    // 0xbea3f0: mov             x4, x1
    // 0xbea3f4: stur            x4, [fp, #-0x18]
    // 0xbea3f8: cmp             w4, NULL
    // 0xbea3fc: b.eq            #0xbea510
    // 0xbea400: LoadField: r5 = r4->field_7
    //     0xbea400: ldur            w5, [x4, #7]
    // 0xbea404: DecompressPointer r5
    //     0xbea404: add             x5, x5, HEAP, lsl #32
    // 0xbea408: stur            x5, [fp, #-0x10]
    // 0xbea40c: cmp             w5, NULL
    // 0xbea410: b.eq            #0xbea514
    // 0xbea414: mov             x0, x5
    // 0xbea418: r2 = Null
    //     0xbea418: mov             x2, NULL
    // 0xbea41c: r1 = Null
    //     0xbea41c: mov             x1, NULL
    // 0xbea420: r4 = LoadClassIdInstr(r0)
    //     0xbea420: ldur            x4, [x0, #-1]
    //     0xbea424: ubfx            x4, x4, #0xc, #0x14
    // 0xbea428: r17 = -4183
    //     0xbea428: mov             x17, #-0x1057
    // 0xbea42c: add             x4, x4, x17
    // 0xbea430: cmp             x4, #1
    // 0xbea434: b.ls            #0xbea44c
    // 0xbea438: r8 = SliverMultiBoxAdaptorParentData
    //     0xbea438: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbea43c: ldr             x8, [x8, #0x590]
    // 0xbea440: r3 = Null
    //     0xbea440: add             x3, PP, #0x96, lsl #12  ; [pp+0x966e8] Null
    //     0xbea444: ldr             x3, [x3, #0x6e8]
    // 0xbea448: r0 = DefaultTypeTest()
    //     0xbea448: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbea44c: ldur            x3, [fp, #-8]
    // 0xbea450: LoadField: r4 = r3->field_27
    //     0xbea450: ldur            w4, [x3, #0x27]
    // 0xbea454: DecompressPointer r4
    //     0xbea454: add             x4, x4, HEAP, lsl #32
    // 0xbea458: mov             x0, x4
    // 0xbea45c: ldur            x1, [fp, #-0x10]
    // 0xbea460: stur            x4, [fp, #-0x28]
    // 0xbea464: StoreField: r1->field_7 = r0
    //     0xbea464: stur            w0, [x1, #7]
    //     0xbea468: ldurb           w16, [x1, #-1]
    //     0xbea46c: ldurb           w17, [x0, #-1]
    //     0xbea470: and             x16, x17, x16, lsr #2
    //     0xbea474: tst             x16, HEAP, lsr #32
    //     0xbea478: b.eq            #0xbea480
    //     0xbea47c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbea480: LoadField: r1 = r3->field_f
    //     0xbea480: ldur            w1, [x3, #0xf]
    // 0xbea484: DecompressPointer r1
    //     0xbea484: add             x1, x1, HEAP, lsl #32
    // 0xbea488: ldur            x2, [fp, #-0x18]
    // 0xbea48c: r0 = paintExtentOf()
    //     0xbea48c: bl              #0x1185dbc  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::paintExtentOf
    // 0xbea490: ldur            x1, [fp, #-0x28]
    // 0xbea494: LoadField: d1 = r1->field_7
    //     0xbea494: ldur            d1, [x1, #7]
    // 0xbea498: fadd            d2, d1, d0
    // 0xbea49c: r0 = inline_Allocate_Double()
    //     0xbea49c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbea4a0: add             x0, x0, #0x10
    //     0xbea4a4: cmp             x1, x0
    //     0xbea4a8: b.ls            #0xbea518
    //     0xbea4ac: str             x0, [THR, #0x60]  ; THR::top
    //     0xbea4b0: sub             x0, x0, #0xf
    //     0xbea4b4: mov             x1, #0xe19c
    //     0xbea4b8: movk            x1, #3, lsl #16
    //     0xbea4bc: stur            x1, [x0, #-1]
    // 0xbea4c0: dmb             ishst
    // 0xbea4c4: StoreField: r0->field_7 = d2
    //     0xbea4c4: stur            d2, [x0, #7]
    // 0xbea4c8: ldur            x1, [fp, #-8]
    // 0xbea4cc: StoreField: r1->field_27 = r0
    //     0xbea4cc: stur            w0, [x1, #0x27]
    //     0xbea4d0: ldurb           w16, [x1, #-1]
    //     0xbea4d4: ldurb           w17, [x0, #-1]
    //     0xbea4d8: and             x16, x17, x16, lsr #2
    //     0xbea4dc: tst             x16, HEAP, lsr #32
    //     0xbea4e0: b.eq            #0xbea4e8
    //     0xbea4e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbea4e8: r0 = true
    //     0xbea4e8: add             x0, NULL, #0x20  ; true
    // 0xbea4ec: LeaveFrame
    //     0xbea4ec: mov             SP, fp
    //     0xbea4f0: ldp             fp, lr, [SP], #0x10
    // 0xbea4f4: ret
    //     0xbea4f4: ret             
    // 0xbea4f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbea4f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbea4fc: b               #0xbea134
    // 0xbea500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea500: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea504: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea508: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea508: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea50c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea50c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea510: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea510: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea514: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbea514: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbea518: SaveReg d2
    //     0xbea518: str             q2, [SP, #-0x10]!
    // 0xbea51c: r0 = AllocateDouble()
    //     0xbea51c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbea520: RestoreReg d2
    //     0xbea520: ldr             q2, [SP], #0x10
    // 0xbea524: b               #0xbea4c4
  }
}
