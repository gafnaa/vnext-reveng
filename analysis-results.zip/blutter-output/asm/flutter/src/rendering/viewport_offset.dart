// lib: , url: package:flutter/src/rendering/viewport_offset.dart

// class id: 1049056, size: 0x8
class :: {
}

// class id: 4537, size: 0x24, field offset: 0x24
abstract class ViewportOffset extends ChangeNotifier {

  _ moveTo(/* No info */) {
    // ** addr: 0xb3478c, size: 0xc0
    // 0xb3478c: EnterFrame
    //     0xb3478c: stp             fp, lr, [SP, #-0x10]!
    //     0xb34790: mov             fp, SP
    // 0xb34794: AllocStack(0x38)
    //     0xb34794: sub             SP, SP, #0x38
    // 0xb34798: SetupParameters(ViewportOffset this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0xb34798: stur            x1, [fp, #-8]
    //     0xb3479c: stur            x2, [fp, #-0x10]
    //     0xb347a0: stur            x3, [fp, #-0x18]
    //     0xb347a4: stur            d0, [fp, #-0x28]
    // 0xb347a8: CheckStackOverflow
    //     0xb347a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb347ac: cmp             SP, x16
    //     0xb347b0: b.ls            #0xb34844
    // 0xb347b4: r16 = Instance_Duration
    //     0xb347b4: ldr             x16, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    // 0xb347b8: stp             x16, x3, [SP]
    // 0xb347bc: r0 = ==()
    //     0xb347bc: bl              #0x124ef40  ; [dart:core] Duration::==
    // 0xb347c0: tbnz            w0, #4, #0xb34824
    // 0xb347c4: ldur            x1, [fp, #-8]
    // 0xb347c8: ldur            d0, [fp, #-0x28]
    // 0xb347cc: r0 = jumpTo()
    //     0xb347cc: bl              #0x86ba5c  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::jumpTo
    // 0xb347d0: r1 = <void?>
    //     0xb347d0: ldr             x1, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    // 0xb347d4: r0 = _Future()
    //     0xb347d4: bl              #0x7f5dd4  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xb347d8: stur            x0, [fp, #-0x20]
    // 0xb347dc: StoreField: r0->field_b = rZR
    //     0xb347dc: stur            xzr, [x0, #0xb]
    // 0xb347e0: r0 = LoadStaticField(0x364)
    //     0xb347e0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xb347e4: ldr             x0, [x0, #0x6c8]
    // 0xb347e8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb347ec: cmp             w0, w16
    // 0xb347f0: b.ne            #0xb347fc
    // 0xb347f4: r2 = _current
    //     0xb347f4: ldr             x2, [PP, #0x2c0]  ; [pp+0x2c0] Field <Zone._current@5048458>: static late (offset: 0x364)
    // 0xb347f8: r0 = InitLateStaticField()
    //     0xb347f8: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xb347fc: mov             x1, x0
    // 0xb34800: ldur            x0, [fp, #-0x20]
    // 0xb34804: StoreField: r0->field_13 = r1
    //     0xb34804: stur            w1, [x0, #0x13]
    // 0xb34808: mov             x1, x0
    // 0xb3480c: r2 = Null
    //     0xb3480c: mov             x2, NULL
    // 0xb34810: r0 = _asyncComplete()
    //     0xb34810: bl              #0x7eee44  ; [dart:async] _Future::_asyncComplete
    // 0xb34814: ldur            x0, [fp, #-0x20]
    // 0xb34818: LeaveFrame
    //     0xb34818: mov             SP, fp
    //     0xb3481c: ldp             fp, lr, [SP], #0x10
    // 0xb34820: ret
    //     0xb34820: ret             
    // 0xb34824: ldur            x1, [fp, #-8]
    // 0xb34828: ldur            d0, [fp, #-0x28]
    // 0xb3482c: ldur            x2, [fp, #-0x10]
    // 0xb34830: ldur            x3, [fp, #-0x18]
    // 0xb34834: r0 = animateTo()
    //     0xb34834: bl              #0x86ea3c  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::animateTo
    // 0xb34838: LeaveFrame
    //     0xb34838: mov             SP, fp
    //     0xb3483c: ldp             fp, lr, [SP], #0x10
    // 0xb34840: ret
    //     0xb34840: ret             
    // 0xb34844: r0 = StackOverflowSharedWithFPURegs()
    //     0xb34844: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb34848: b               #0xb347b4
  }
}

// class id: 8216, size: 0x14, field offset: 0x14
enum ScrollDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab354, size: 0x64
    // 0x11ab354: EnterFrame
    //     0x11ab354: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab358: mov             fp, SP
    // 0x11ab35c: AllocStack(0x10)
    //     0x11ab35c: sub             SP, SP, #0x10
    // 0x11ab360: SetupParameters(ScrollDirection this /* r1 => r0, fp-0x8 */)
    //     0x11ab360: mov             x0, x1
    //     0x11ab364: stur            x1, [fp, #-8]
    // 0x11ab368: CheckStackOverflow
    //     0x11ab368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab36c: cmp             SP, x16
    //     0x11ab370: b.ls            #0x11ab3b0
    // 0x11ab374: r1 = Null
    //     0x11ab374: mov             x1, NULL
    // 0x11ab378: r2 = 4
    //     0x11ab378: mov             x2, #4
    // 0x11ab37c: r0 = AllocateArray()
    //     0x11ab37c: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab380: r16 = "ScrollDirection."
    //     0x11ab380: add             x16, PP, #0x10, lsl #12  ; [pp+0x10eb8] "ScrollDirection."
    //     0x11ab384: ldr             x16, [x16, #0xeb8]
    // 0x11ab388: StoreField: r0->field_f = r16
    //     0x11ab388: stur            w16, [x0, #0xf]
    // 0x11ab38c: ldur            x1, [fp, #-8]
    // 0x11ab390: LoadField: r2 = r1->field_f
    //     0x11ab390: ldur            w2, [x1, #0xf]
    // 0x11ab394: DecompressPointer r2
    //     0x11ab394: add             x2, x2, HEAP, lsl #32
    // 0x11ab398: StoreField: r0->field_13 = r2
    //     0x11ab398: stur            w2, [x0, #0x13]
    // 0x11ab39c: str             x0, [SP]
    // 0x11ab3a0: r0 = _interpolate()
    //     0x11ab3a0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab3a4: LeaveFrame
    //     0x11ab3a4: mov             SP, fp
    //     0x11ab3a8: ldp             fp, lr, [SP], #0x10
    // 0x11ab3ac: ret
    //     0x11ab3ac: ret             
    // 0x11ab3b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab3b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab3b4: b               #0x11ab374
  }
}
