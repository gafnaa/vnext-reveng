// lib: , url: package:flutter/src/rendering/sliver_fill.dart

// class id: 1049043, size: 0x8
class :: {
}

// class id: 4703, size: 0x70, field offset: 0x64
class RenderSliverFillViewport extends RenderSliverFixedExtentBoxAdaptor {

  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbec860, size: 0x278
    // 0xbec860: EnterFrame
    //     0xbec860: stp             fp, lr, [SP, #-0x10]!
    //     0xbec864: mov             fp, SP
    // 0xbec868: AllocStack(0x48)
    //     0xbec868: sub             SP, SP, #0x48
    // 0xbec86c: SetupParameters(RenderSliverFillViewport this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xbec86c: mov             x4, x1
    //     0xbec870: mov             x3, x2
    //     0xbec874: stur            x1, [fp, #-0x10]
    //     0xbec878: stur            x2, [fp, #-0x18]
    // 0xbec87c: CheckStackOverflow
    //     0xbec87c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec880: cmp             SP, x16
    //     0xbec884: b.ls            #0xbecabc
    // 0xbec888: LoadField: r5 = r4->field_27
    //     0xbec888: ldur            w5, [x4, #0x27]
    // 0xbec88c: DecompressPointer r5
    //     0xbec88c: add             x5, x5, HEAP, lsl #32
    // 0xbec890: stur            x5, [fp, #-8]
    // 0xbec894: cmp             w5, NULL
    // 0xbec898: b.eq            #0xbeca80
    // 0xbec89c: mov             x0, x5
    // 0xbec8a0: r2 = Null
    //     0xbec8a0: mov             x2, NULL
    // 0xbec8a4: r1 = Null
    //     0xbec8a4: mov             x1, NULL
    // 0xbec8a8: r4 = LoadClassIdInstr(r0)
    //     0xbec8a8: ldur            x4, [x0, #-1]
    //     0xbec8ac: ubfx            x4, x4, #0xc, #0x14
    // 0xbec8b0: cmp             x4, #0xb45
    // 0xbec8b4: b.eq            #0xbec8cc
    // 0xbec8b8: r8 = SliverConstraints
    //     0xbec8b8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbec8bc: ldr             x8, [x8, #0x3c0]
    // 0xbec8c0: r3 = Null
    //     0xbec8c0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab700] Null
    //     0xbec8c4: ldr             x3, [x3, #0x700]
    // 0xbec8c8: r0 = DefaultTypeTest()
    //     0xbec8c8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbec8cc: ldur            x0, [fp, #-8]
    // 0xbec8d0: LoadField: d0 = r0->field_13
    //     0xbec8d0: ldur            d0, [x0, #0x13]
    // 0xbec8d4: stur            d0, [fp, #-0x30]
    // 0xbec8d8: LoadField: d1 = r0->field_3f
    //     0xbec8d8: ldur            d1, [x0, #0x3f]
    // 0xbec8dc: fadd            d2, d0, d1
    // 0xbec8e0: ldur            x3, [fp, #-0x10]
    // 0xbec8e4: stur            d2, [fp, #-0x28]
    // 0xbec8e8: LoadField: r0 = r3->field_53
    //     0xbec8e8: ldur            w0, [x3, #0x53]
    // 0xbec8ec: DecompressPointer r0
    //     0xbec8ec: add             x0, x0, HEAP, lsl #32
    // 0xbec8f0: mov             x4, x0
    // 0xbec8f4: stur            x4, [fp, #-0x20]
    // 0xbec8f8: CheckStackOverflow
    //     0xbec8f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec8fc: cmp             SP, x16
    //     0xbec900: b.ls            #0xbecac4
    // 0xbec904: cmp             w4, NULL
    // 0xbec908: b.eq            #0xbeca70
    // 0xbec90c: LoadField: r5 = r4->field_7
    //     0xbec90c: ldur            w5, [x4, #7]
    // 0xbec910: DecompressPointer r5
    //     0xbec910: add             x5, x5, HEAP, lsl #32
    // 0xbec914: stur            x5, [fp, #-8]
    // 0xbec918: cmp             w5, NULL
    // 0xbec91c: b.eq            #0xbecacc
    // 0xbec920: mov             x0, x5
    // 0xbec924: r2 = Null
    //     0xbec924: mov             x2, NULL
    // 0xbec928: r1 = Null
    //     0xbec928: mov             x1, NULL
    // 0xbec92c: r4 = LoadClassIdInstr(r0)
    //     0xbec92c: ldur            x4, [x0, #-1]
    //     0xbec930: ubfx            x4, x4, #0xc, #0x14
    // 0xbec934: r17 = -4183
    //     0xbec934: mov             x17, #-0x1057
    // 0xbec938: add             x4, x4, x17
    // 0xbec93c: cmp             x4, #1
    // 0xbec940: b.ls            #0xbec958
    // 0xbec944: r8 = SliverMultiBoxAdaptorParentData
    //     0xbec944: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbec948: ldr             x8, [x8, #0x590]
    // 0xbec94c: r3 = Null
    //     0xbec94c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab710] Null
    //     0xbec950: ldr             x3, [x3, #0x710]
    // 0xbec954: r0 = DefaultTypeTest()
    //     0xbec954: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbec958: ldur            x0, [fp, #-8]
    // 0xbec95c: LoadField: r1 = r0->field_7
    //     0xbec95c: ldur            w1, [x0, #7]
    // 0xbec960: DecompressPointer r1
    //     0xbec960: add             x1, x1, HEAP, lsl #32
    // 0xbec964: cmp             w1, NULL
    // 0xbec968: b.eq            #0xbecad0
    // 0xbec96c: LoadField: d0 = r1->field_7
    //     0xbec96c: ldur            d0, [x1, #7]
    // 0xbec970: ldur            d1, [fp, #-0x28]
    // 0xbec974: stur            d0, [fp, #-0x38]
    // 0xbec978: fcmp            d0, d1
    // 0xbec97c: b.ge            #0xbeca70
    // 0xbec980: ldur            x3, [fp, #-0x10]
    // 0xbec984: LoadField: r4 = r3->field_27
    //     0xbec984: ldur            w4, [x3, #0x27]
    // 0xbec988: DecompressPointer r4
    //     0xbec988: add             x4, x4, HEAP, lsl #32
    // 0xbec98c: stur            x4, [fp, #-8]
    // 0xbec990: cmp             w4, NULL
    // 0xbec994: b.eq            #0xbeca9c
    // 0xbec998: ldur            d2, [fp, #-0x30]
    // 0xbec99c: mov             x0, x4
    // 0xbec9a0: r2 = Null
    //     0xbec9a0: mov             x2, NULL
    // 0xbec9a4: r1 = Null
    //     0xbec9a4: mov             x1, NULL
    // 0xbec9a8: r4 = LoadClassIdInstr(r0)
    //     0xbec9a8: ldur            x4, [x0, #-1]
    //     0xbec9ac: ubfx            x4, x4, #0xc, #0x14
    // 0xbec9b0: cmp             x4, #0xb45
    // 0xbec9b4: b.eq            #0xbec9cc
    // 0xbec9b8: r8 = SliverConstraints
    //     0xbec9b8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbec9bc: ldr             x8, [x8, #0x3c0]
    // 0xbec9c0: r3 = Null
    //     0xbec9c0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab720] Null
    //     0xbec9c4: ldr             x3, [x3, #0x720]
    // 0xbec9c8: r0 = DefaultTypeTest()
    //     0xbec9c8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbec9cc: ldur            x0, [fp, #-8]
    // 0xbec9d0: LoadField: d0 = r0->field_3f
    //     0xbec9d0: ldur            d0, [x0, #0x3f]
    // 0xbec9d4: ldur            d1, [fp, #-0x38]
    // 0xbec9d8: fadd            d2, d1, d0
    // 0xbec9dc: ldur            d0, [fp, #-0x30]
    // 0xbec9e0: fcmp            d2, d0
    // 0xbec9e4: b.le            #0xbeca04
    // 0xbec9e8: ldur            x16, [fp, #-0x18]
    // 0xbec9ec: ldur            lr, [fp, #-0x20]
    // 0xbec9f0: stp             lr, x16, [SP]
    // 0xbec9f4: ldur            x0, [fp, #-0x18]
    // 0xbec9f8: ClosureCall
    //     0xbec9f8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbec9fc: ldur            x2, [x0, #0x1f]
    //     0xbeca00: blr             x2
    // 0xbeca04: ldur            x0, [fp, #-0x20]
    // 0xbeca08: LoadField: r3 = r0->field_7
    //     0xbeca08: ldur            w3, [x0, #7]
    // 0xbeca0c: DecompressPointer r3
    //     0xbeca0c: add             x3, x3, HEAP, lsl #32
    // 0xbeca10: stur            x3, [fp, #-8]
    // 0xbeca14: cmp             w3, NULL
    // 0xbeca18: b.eq            #0xbecad4
    // 0xbeca1c: mov             x0, x3
    // 0xbeca20: r2 = Null
    //     0xbeca20: mov             x2, NULL
    // 0xbeca24: r1 = Null
    //     0xbeca24: mov             x1, NULL
    // 0xbeca28: r4 = LoadClassIdInstr(r0)
    //     0xbeca28: ldur            x4, [x0, #-1]
    //     0xbeca2c: ubfx            x4, x4, #0xc, #0x14
    // 0xbeca30: r17 = -4183
    //     0xbeca30: mov             x17, #-0x1057
    // 0xbeca34: add             x4, x4, x17
    // 0xbeca38: cmp             x4, #1
    // 0xbeca3c: b.ls            #0xbeca54
    // 0xbeca40: r8 = SliverMultiBoxAdaptorParentData
    //     0xbeca40: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbeca44: ldr             x8, [x8, #0x590]
    // 0xbeca48: r3 = Null
    //     0xbeca48: add             x3, PP, #0xab, lsl #12  ; [pp+0xab730] Null
    //     0xbeca4c: ldr             x3, [x3, #0x730]
    // 0xbeca50: r0 = DefaultTypeTest()
    //     0xbeca50: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbeca54: ldur            x0, [fp, #-8]
    // 0xbeca58: LoadField: r4 = r0->field_f
    //     0xbeca58: ldur            w4, [x0, #0xf]
    // 0xbeca5c: DecompressPointer r4
    //     0xbeca5c: add             x4, x4, HEAP, lsl #32
    // 0xbeca60: ldur            x3, [fp, #-0x10]
    // 0xbeca64: ldur            d0, [fp, #-0x30]
    // 0xbeca68: ldur            d2, [fp, #-0x28]
    // 0xbeca6c: b               #0xbec8f4
    // 0xbeca70: r0 = Null
    //     0xbeca70: mov             x0, NULL
    // 0xbeca74: LeaveFrame
    //     0xbeca74: mov             SP, fp
    //     0xbeca78: ldp             fp, lr, [SP], #0x10
    // 0xbeca7c: ret
    //     0xbeca7c: ret             
    // 0xbeca80: r0 = StateError()
    //     0xbeca80: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbeca84: mov             x1, x0
    // 0xbeca88: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbeca88: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbeca8c: StoreField: r1->field_b = r0
    //     0xbeca8c: stur            w0, [x1, #0xb]
    // 0xbeca90: mov             x0, x1
    // 0xbeca94: r0 = Throw()
    //     0xbeca94: bl              #0x13ddb2c  ; ThrowStub
    // 0xbeca98: brk             #0
    // 0xbeca9c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbeca9c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbecaa0: r0 = StateError()
    //     0xbecaa0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbecaa4: mov             x1, x0
    // 0xbecaa8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbecaa8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbecaac: StoreField: r1->field_b = r0
    //     0xbecaac: stur            w0, [x1, #0xb]
    // 0xbecab0: mov             x0, x1
    // 0xbecab4: r0 = Throw()
    //     0xbecab4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbecab8: brk             #0
    // 0xbecabc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbecabc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbecac0: b               #0xbec888
    // 0xbecac4: r0 = StackOverflowSharedWithFPURegs()
    //     0xbecac4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbecac8: b               #0xbec904
    // 0xbecacc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbecacc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbecad0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbecad0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbecad4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbecad4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ viewportFraction=(/* No info */) {
    // ** addr: 0xcfe9b8, size: 0x50
    // 0xcfe9b8: EnterFrame
    //     0xcfe9b8: stp             fp, lr, [SP, #-0x10]!
    //     0xcfe9bc: mov             fp, SP
    // 0xcfe9c0: d1 = 1.000000
    //     0xcfe9c0: fmov            d1, #1.00000000
    // 0xcfe9c4: CheckStackOverflow
    //     0xcfe9c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfe9c8: cmp             SP, x16
    //     0xcfe9cc: b.ls            #0xcfea00
    // 0xcfe9d0: fcmp            d1, d1
    // 0xcfe9d4: b.ne            #0xcfe9e8
    // 0xcfe9d8: r0 = Null
    //     0xcfe9d8: mov             x0, NULL
    // 0xcfe9dc: LeaveFrame
    //     0xcfe9dc: mov             SP, fp
    //     0xcfe9e0: ldp             fp, lr, [SP], #0x10
    // 0xcfe9e4: ret
    //     0xcfe9e4: ret             
    // 0xcfe9e8: StoreField: r1->field_63 = d1
    //     0xcfe9e8: stur            d1, [x1, #0x63]
    // 0xcfe9ec: r0 = markNeedsLayout()
    //     0xcfe9ec: bl              #0xbfb800  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0xcfe9f0: r0 = Null
    //     0xcfe9f0: mov             x0, NULL
    // 0xcfe9f4: LeaveFrame
    //     0xcfe9f4: mov             SP, fp
    //     0xcfe9f8: ldp             fp, lr, [SP], #0x10
    // 0xcfe9fc: ret
    //     0xcfe9fc: ret             
    // 0xcfea00: r0 = StackOverflowSharedWithFPURegs()
    //     0xcfea00: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcfea04: b               #0xcfe9d0
  }
}
