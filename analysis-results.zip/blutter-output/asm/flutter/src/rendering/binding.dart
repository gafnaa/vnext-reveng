// lib: , url: package:flutter/src/rendering/binding.dart

// class id: 1049020, size: 0x8
class :: {
}

// class id: 4483, size: 0x28, field offset: 0x24
class _BindingPipelineManifold extends ChangeNotifier
    implements PipelineManifold {

  _ requestVisualUpdate(/* No info */) {
    // ** addr: 0x8379f4, size: 0x3c
    // 0x8379f4: EnterFrame
    //     0x8379f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8379f8: mov             fp, SP
    // 0x8379fc: CheckStackOverflow
    //     0x8379fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x837a00: cmp             SP, x16
    //     0x837a04: b.ls            #0x837a28
    // 0x837a08: LoadField: r0 = r1->field_23
    //     0x837a08: ldur            w0, [x1, #0x23]
    // 0x837a0c: DecompressPointer r0
    //     0x837a0c: add             x0, x0, HEAP, lsl #32
    // 0x837a10: mov             x1, x0
    // 0x837a14: r0 = ensureVisualUpdate()
    //     0x837a14: bl              #0x837a30  ; [dart:mixin_deduplication] _MixinApplication203&BindingBase&GestureBinding&SchedulerBinding::ensureVisualUpdate
    // 0x837a18: r0 = Null
    //     0x837a18: mov             x0, NULL
    // 0x837a1c: LeaveFrame
    //     0x837a1c: mov             SP, fp
    //     0x837a20: ldp             fp, lr, [SP], #0x10
    // 0x837a24: ret
    //     0x837a24: ret             
    // 0x837a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x837a28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x837a2c: b               #0x837a08
  }
  get _ semanticsEnabled(/* No info */) {
    // ** addr: 0x844560, size: 0x38
    // 0x844560: EnterFrame
    //     0x844560: stp             fp, lr, [SP, #-0x10]!
    //     0x844564: mov             fp, SP
    // 0x844568: CheckStackOverflow
    //     0x844568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84456c: cmp             SP, x16
    //     0x844570: b.ls            #0x844590
    // 0x844574: LoadField: r0 = r1->field_23
    //     0x844574: ldur            w0, [x1, #0x23]
    // 0x844578: DecompressPointer r0
    //     0x844578: add             x0, x0, HEAP, lsl #32
    // 0x84457c: mov             x1, x0
    // 0x844580: r0 = semanticsEnabled()
    //     0x844580: bl              #0x844598  ; [dart:mixin_deduplication] _MixinApplication206&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding::semanticsEnabled
    // 0x844584: LeaveFrame
    //     0x844584: mov             SP, fp
    //     0x844588: ldp             fp, lr, [SP], #0x10
    // 0x84458c: ret
    //     0x84458c: ret             
    // 0x844590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844590: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844594: b               #0x844574
  }
  _ _BindingPipelineManifold(/* No info */) {
    // ** addr: 0x87d658, size: 0xc0
    // 0x87d658: EnterFrame
    //     0x87d658: stp             fp, lr, [SP, #-0x10]!
    //     0x87d65c: mov             fp, SP
    // 0x87d660: AllocStack(0x10)
    //     0x87d660: sub             SP, SP, #0x10
    // 0x87d664: SetupParameters(_BindingPipelineManifold this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x87d664: stur            x1, [fp, #-8]
    //     0x87d668: mov             x16, x2
    //     0x87d66c: mov             x2, x1
    //     0x87d670: mov             x1, x16
    //     0x87d674: stur            x1, [fp, #-0x10]
    // 0x87d678: CheckStackOverflow
    //     0x87d678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d67c: cmp             SP, x16
    //     0x87d680: b.ls            #0x87d710
    // 0x87d684: mov             x0, x1
    // 0x87d688: StoreField: r2->field_23 = r0
    //     0x87d688: stur            w0, [x2, #0x23]
    //     0x87d68c: ldurb           w16, [x2, #-1]
    //     0x87d690: ldurb           w17, [x0, #-1]
    //     0x87d694: and             x16, x17, x16, lsr #2
    //     0x87d698: tst             x16, HEAP, lsr #32
    //     0x87d69c: b.eq            #0x87d6a4
    //     0x87d6a0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x87d6a4: StoreField: r2->field_7 = rZR
    //     0x87d6a4: stur            xzr, [x2, #7]
    // 0x87d6a8: StoreField: r2->field_13 = rZR
    //     0x87d6a8: stur            xzr, [x2, #0x13]
    // 0x87d6ac: StoreField: r2->field_1b = rZR
    //     0x87d6ac: stur            xzr, [x2, #0x1b]
    // 0x87d6b0: r0 = LoadStaticField(0x45c)
    //     0x87d6b0: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x87d6b4: ldr             x0, [x0, #0x8b8]
    // 0x87d6b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87d6bc: cmp             w0, w16
    // 0x87d6c0: b.ne            #0x87d6cc
    // 0x87d6c4: r2 = _emptyListeners
    //     0x87d6c4: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0x87d6c8: r0 = InitLateFinalStaticField()
    //     0x87d6c8: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x87d6cc: ldur            x2, [fp, #-8]
    // 0x87d6d0: StoreField: r2->field_f = r0
    //     0x87d6d0: stur            w0, [x2, #0xf]
    //     0x87d6d4: ldurb           w16, [x2, #-1]
    //     0x87d6d8: ldurb           w17, [x0, #-1]
    //     0x87d6dc: and             x16, x17, x16, lsr #2
    //     0x87d6e0: tst             x16, HEAP, lsr #32
    //     0x87d6e4: b.eq            #0x87d6ec
    //     0x87d6e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x87d6ec: r1 = Function 'notifyListeners':.
    //     0x87d6ec: ldr             x1, [PP, #0x2108]  ; [pp+0x2108] AnonymousClosure: (0x834128), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x833be0)
    // 0x87d6f0: r0 = AllocateClosure()
    //     0x87d6f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87d6f4: ldur            x1, [fp, #-0x10]
    // 0x87d6f8: mov             x2, x0
    // 0x87d6fc: r0 = addSemanticsEnabledListener()
    //     0x87d6fc: bl              #0x8450bc  ; [dart:mixin_deduplication] _MixinApplication206&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding::addSemanticsEnabledListener
    // 0x87d700: r0 = Null
    //     0x87d700: mov             x0, NULL
    // 0x87d704: LeaveFrame
    //     0x87d704: mov             SP, fp
    //     0x87d708: ldp             fp, lr, [SP], #0x10
    // 0x87d70c: ret
    //     0x87d70c: ret             
    // 0x87d710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87d710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87d714: b               #0x87d684
  }
}

// class id: 4568, size: 0x8, field offset: 0x8
abstract class RendererBinding extends _MixinApplication198&BindingBase&ServicesBinding&SchedulerBinding&GestureBinding&SemanticsBinding&HitTestable {

  get _ instance(/* No info */) {
    // ** addr: 0x899f04, size: 0x20
    // 0x899f04: r0 = LoadStaticField(0x7d8)
    //     0x899f04: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x899f08: ldr             x0, [x0, #0xfb0]
    // 0x899f0c: cmp             w0, NULL
    // 0x899f10: b.eq            #0x899f18
    // 0x899f14: ret
    //     0x899f14: ret             
    // 0x899f18: EnterFrame
    //     0x899f18: stp             fp, lr, [SP, #-0x10]!
    //     0x899f1c: mov             fp, SP
    // 0x899f20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x899f20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4669, size: 0x48, field offset: 0x48
class _DefaultRootPipelineOwner extends PipelineOwner {
}

// class id: 4680, size: 0x64, field offset: 0x60
class _ReusableRenderView extends RenderView {

  _ scheduleInitialSemantics(/* No info */) {
    // ** addr: 0xb8ec00, size: 0x48
    // 0xb8ec00: EnterFrame
    //     0xb8ec00: stp             fp, lr, [SP, #-0x10]!
    //     0xb8ec04: mov             fp, SP
    // 0xb8ec08: AllocStack(0x8)
    //     0xb8ec08: sub             SP, SP, #8
    // 0xb8ec0c: SetupParameters(_ReusableRenderView this /* r1 => r0, fp-0x8 */)
    //     0xb8ec0c: mov             x0, x1
    //     0xb8ec10: stur            x1, [fp, #-8]
    // 0xb8ec14: CheckStackOverflow
    //     0xb8ec14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8ec18: cmp             SP, x16
    //     0xb8ec1c: b.ls            #0xb8ec40
    // 0xb8ec20: mov             x1, x0
    // 0xb8ec24: r0 = clearSemantics()
    //     0xb8ec24: bl              #0xcd05e8  ; [package:flutter/src/rendering/object.dart] RenderObject::clearSemantics
    // 0xb8ec28: ldur            x1, [fp, #-8]
    // 0xb8ec2c: r0 = scheduleInitialSemantics()
    //     0xb8ec2c: bl              #0xb8ec48  ; [package:flutter/src/rendering/object.dart] RenderObject::scheduleInitialSemantics
    // 0xb8ec30: r0 = Null
    //     0xb8ec30: mov             x0, NULL
    // 0xb8ec34: LeaveFrame
    //     0xb8ec34: mov             SP, fp
    //     0xb8ec38: ldp             fp, lr, [SP], #0x10
    // 0xb8ec3c: ret
    //     0xb8ec3c: ret             
    // 0xb8ec40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8ec40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8ec44: b               #0xb8ec20
  }
  _ prepareInitialFrame(/* No info */) {
    // ** addr: 0xb8ecf0, size: 0x68
    // 0xb8ecf0: EnterFrame
    //     0xb8ecf0: stp             fp, lr, [SP, #-0x10]!
    //     0xb8ecf4: mov             fp, SP
    // 0xb8ecf8: AllocStack(0x8)
    //     0xb8ecf8: sub             SP, SP, #8
    // 0xb8ecfc: SetupParameters(_ReusableRenderView this /* r1 => r0, fp-0x8 */)
    //     0xb8ecfc: mov             x0, x1
    //     0xb8ed00: stur            x1, [fp, #-8]
    // 0xb8ed04: CheckStackOverflow
    //     0xb8ed04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8ed08: cmp             SP, x16
    //     0xb8ed0c: b.ls            #0xb8ed50
    // 0xb8ed10: LoadField: r1 = r0->field_5f
    //     0xb8ed10: ldur            w1, [x0, #0x5f]
    // 0xb8ed14: DecompressPointer r1
    //     0xb8ed14: add             x1, x1, HEAP, lsl #32
    // 0xb8ed18: tbnz            w1, #4, #0xb8ed2c
    // 0xb8ed1c: r0 = Null
    //     0xb8ed1c: mov             x0, NULL
    // 0xb8ed20: LeaveFrame
    //     0xb8ed20: mov             SP, fp
    //     0xb8ed24: ldp             fp, lr, [SP], #0x10
    // 0xb8ed28: ret
    //     0xb8ed28: ret             
    // 0xb8ed2c: mov             x1, x0
    // 0xb8ed30: r0 = prepareInitialFrame()
    //     0xb8ed30: bl              #0xb8ed58  ; [package:flutter/src/rendering/view.dart] RenderView::prepareInitialFrame
    // 0xb8ed34: ldur            x1, [fp, #-8]
    // 0xb8ed38: r2 = true
    //     0xb8ed38: add             x2, NULL, #0x20  ; true
    // 0xb8ed3c: StoreField: r1->field_5f = r2
    //     0xb8ed3c: stur            w2, [x1, #0x5f]
    // 0xb8ed40: r0 = Null
    //     0xb8ed40: mov             x0, NULL
    // 0xb8ed44: LeaveFrame
    //     0xb8ed44: mov             SP, fp
    //     0xb8ed48: ldp             fp, lr, [SP], #0x10
    // 0xb8ed4c: ret
    //     0xb8ed4c: ret             
    // 0xb8ed50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8ed50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8ed54: b               #0xb8ed10
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc04c58, size: 0x34
    // 0xc04c58: EnterFrame
    //     0xc04c58: stp             fp, lr, [SP, #-0x10]!
    //     0xc04c5c: mov             fp, SP
    // 0xc04c60: CheckStackOverflow
    //     0xc04c60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc04c64: cmp             SP, x16
    //     0xc04c68: b.ls            #0xc04c84
    // 0xc04c6c: r2 = Null
    //     0xc04c6c: mov             x2, NULL
    // 0xc04c70: r0 = child=()
    //     0xc04c70: bl              #0xaef6c4  ; [dart:mixin_deduplication] _MixinApplication423&RenderObject&RenderObjectWithChildMixin::child=
    // 0xc04c74: r0 = Null
    //     0xc04c74: mov             x0, NULL
    // 0xc04c78: LeaveFrame
    //     0xc04c78: mov             SP, fp
    //     0xc04c7c: ldp             fp, lr, [SP], #0x10
    // 0xc04c80: ret
    //     0xc04c80: ret             
    // 0xc04c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04c84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04c88: b               #0xc04c6c
  }
}
