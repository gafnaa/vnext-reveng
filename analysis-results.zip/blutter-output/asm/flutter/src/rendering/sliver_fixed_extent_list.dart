// lib: , url: package:flutter/src/rendering/sliver_fixed_extent_list.dart

// class id: 1049044, size: 0x8
class :: {
}

// class id: 4699, size: 0x64, field offset: 0x64
abstract class RenderSliverFixedExtentBoxAdaptor extends RenderSliverMultiBoxAdaptor {

  _ performLayout(/* No info */) {
    // ** addr: 0xbe2dc0, size: 0x19d0
    // 0xbe2dc0: EnterFrame
    //     0xbe2dc0: stp             fp, lr, [SP, #-0x10]!
    //     0xbe2dc4: mov             fp, SP
    // 0xbe2dc8: AllocStack(0xa0)
    //     0xbe2dc8: sub             SP, SP, #0xa0
    // 0xbe2dcc: SetupParameters(RenderSliverFixedExtentBoxAdaptor this /* r1 => r3, fp-0x10 */)
    //     0xbe2dcc: mov             x3, x1
    //     0xbe2dd0: stur            x1, [fp, #-0x10]
    // 0xbe2dd4: CheckStackOverflow
    //     0xbe2dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe2dd8: cmp             SP, x16
    //     0xbe2ddc: b.ls            #0xbe45cc
    // 0xbe2de0: LoadField: r4 = r3->field_27
    //     0xbe2de0: ldur            w4, [x3, #0x27]
    // 0xbe2de4: DecompressPointer r4
    //     0xbe2de4: add             x4, x4, HEAP, lsl #32
    // 0xbe2de8: stur            x4, [fp, #-8]
    // 0xbe2dec: cmp             w4, NULL
    // 0xbe2df0: b.eq            #0xbe4410
    // 0xbe2df4: mov             x0, x4
    // 0xbe2df8: r2 = Null
    //     0xbe2df8: mov             x2, NULL
    // 0xbe2dfc: r1 = Null
    //     0xbe2dfc: mov             x1, NULL
    // 0xbe2e00: r4 = LoadClassIdInstr(r0)
    //     0xbe2e00: ldur            x4, [x0, #-1]
    //     0xbe2e04: ubfx            x4, x4, #0xc, #0x14
    // 0xbe2e08: cmp             x4, #0xb45
    // 0xbe2e0c: b.eq            #0xbe2e24
    // 0xbe2e10: r8 = SliverConstraints
    //     0xbe2e10: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe2e14: ldr             x8, [x8, #0x3c0]
    // 0xbe2e18: r3 = Null
    //     0xbe2e18: add             x3, PP, #0xab, lsl #12  ; [pp+0xab4b8] Null
    //     0xbe2e1c: ldr             x3, [x3, #0x4b8]
    // 0xbe2e20: r0 = DefaultTypeTest()
    //     0xbe2e20: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe2e24: ldur            x0, [fp, #-0x10]
    // 0xbe2e28: LoadField: r2 = r0->field_5b
    //     0xbe2e28: ldur            w2, [x0, #0x5b]
    // 0xbe2e2c: DecompressPointer r2
    //     0xbe2e2c: add             x2, x2, HEAP, lsl #32
    // 0xbe2e30: stur            x2, [fp, #-0x18]
    // 0xbe2e34: r3 = false
    //     0xbe2e34: add             x3, NULL, #0x30  ; false
    // 0xbe2e38: StoreField: r2->field_53 = r3
    //     0xbe2e38: stur            w3, [x2, #0x53]
    // 0xbe2e3c: ldur            x4, [fp, #-8]
    // 0xbe2e40: LoadField: d2 = r4->field_13
    //     0xbe2e40: ldur            d2, [x4, #0x13]
    // 0xbe2e44: stur            d2, [fp, #-0x78]
    // 0xbe2e48: LoadField: d0 = r4->field_47
    //     0xbe2e48: ldur            d0, [x4, #0x47]
    // 0xbe2e4c: fadd            d1, d2, d0
    // 0xbe2e50: LoadField: d0 = r4->field_4f
    //     0xbe2e50: ldur            d0, [x4, #0x4f]
    // 0xbe2e54: fadd            d3, d1, d0
    // 0xbe2e58: mov             x1, x0
    // 0xbe2e5c: mov             v0.16b, v1.16b
    // 0xbe2e60: stur            d3, [fp, #-0x70]
    // 0xbe2e64: d1 = -1.000000
    //     0xbe2e64: fmov            d1, #-1.00000000
    // 0xbe2e68: r0 = getMinChildIndexForScrollOffset()
    //     0xbe2e68: bl              #0xbe7318  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMinChildIndexForScrollOffset
    // 0xbe2e6c: ldur            d0, [fp, #-0x70]
    // 0xbe2e70: stur            x0, [fp, #-0x20]
    // 0xbe2e74: mov             x1, v0.d[0]
    // 0xbe2e78: and             x1, x1, #0x7fffffffffffffff
    // 0xbe2e7c: r17 = 9218868437227405312
    //     0xbe2e7c: mov             x17, #0x7ff0000000000000
    // 0xbe2e80: cmp             x1, x17
    // 0xbe2e84: b.eq            #0xbe2ebc
    // 0xbe2e88: fcmp            d0, d0
    // 0xbe2e8c: b.vs            #0xbe2ebc
    // 0xbe2e90: ldur            x1, [fp, #-0x10]
    // 0xbe2e94: d1 = -1.000000
    //     0xbe2e94: fmov            d1, #-1.00000000
    // 0xbe2e98: r0 = getMaxChildIndexForScrollOffset()
    //     0xbe2e98: bl              #0xbe6f38  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMaxChildIndexForScrollOffset
    // 0xbe2e9c: mov             x2, x0
    // 0xbe2ea0: r0 = BoxInt64Instr(r2)
    //     0xbe2ea0: sbfiz           x0, x2, #1, #0x1f
    //     0xbe2ea4: cmp             x2, x0, asr #1
    //     0xbe2ea8: b.eq            #0xbe2eb4
    //     0xbe2eac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe2eb0: stur            x2, [x0, #7]
    // 0xbe2eb4: mov             x3, x0
    // 0xbe2eb8: b               #0xbe2ec0
    // 0xbe2ebc: r3 = Null
    //     0xbe2ebc: mov             x3, NULL
    // 0xbe2ec0: ldur            x0, [fp, #-0x10]
    // 0xbe2ec4: stur            x3, [fp, #-0x28]
    // 0xbe2ec8: LoadField: r1 = r0->field_53
    //     0xbe2ec8: ldur            w1, [x0, #0x53]
    // 0xbe2ecc: DecompressPointer r1
    //     0xbe2ecc: add             x1, x1, HEAP, lsl #32
    // 0xbe2ed0: cmp             w1, NULL
    // 0xbe2ed4: b.eq            #0xbe2f28
    // 0xbe2ed8: mov             x1, x0
    // 0xbe2edc: ldur            x2, [fp, #-0x20]
    // 0xbe2ee0: r0 = calculateLeadingGarbage()
    //     0xbe2ee0: bl              #0xbe6e48  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::calculateLeadingGarbage
    // 0xbe2ee4: mov             x3, x0
    // 0xbe2ee8: ldur            x0, [fp, #-0x28]
    // 0xbe2eec: stur            x3, [fp, #-0x30]
    // 0xbe2ef0: cmp             w0, NULL
    // 0xbe2ef4: b.eq            #0xbe2f14
    // 0xbe2ef8: r2 = LoadInt32Instr(r0)
    //     0xbe2ef8: sbfx            x2, x0, #1, #0x1f
    //     0xbe2efc: tbz             w0, #0, #0xbe2f04
    //     0xbe2f00: ldur            x2, [x0, #7]
    // 0xbe2f04: ldur            x1, [fp, #-0x10]
    // 0xbe2f08: r0 = calculateTrailingGarbage()
    //     0xbe2f08: bl              #0xbe6d58  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::calculateTrailingGarbage
    // 0xbe2f0c: mov             x3, x0
    // 0xbe2f10: b               #0xbe2f18
    // 0xbe2f14: r3 = 0
    //     0xbe2f14: mov             x3, #0
    // 0xbe2f18: ldur            x1, [fp, #-0x10]
    // 0xbe2f1c: ldur            x2, [fp, #-0x30]
    // 0xbe2f20: r0 = collectGarbage()
    //     0xbe2f20: bl              #0xbe64f8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0xbe2f24: b               #0xbe2f38
    // 0xbe2f28: ldur            x1, [fp, #-0x10]
    // 0xbe2f2c: r2 = 0
    //     0xbe2f2c: mov             x2, #0
    // 0xbe2f30: r3 = 0
    //     0xbe2f30: mov             x3, #0
    // 0xbe2f34: r0 = collectGarbage()
    //     0xbe2f34: bl              #0xbe64f8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0xbe2f38: ldur            x0, [fp, #-0x10]
    // 0xbe2f3c: LoadField: r1 = r0->field_53
    //     0xbe2f3c: ldur            w1, [x0, #0x53]
    // 0xbe2f40: DecompressPointer r1
    //     0xbe2f40: add             x1, x1, HEAP, lsl #32
    // 0xbe2f44: cmp             w1, NULL
    // 0xbe2f48: b.ne            #0xbe3078
    // 0xbe2f4c: ldur            x3, [fp, #-0x20]
    // 0xbe2f50: mov             x1, x0
    // 0xbe2f54: mov             x2, x3
    // 0xbe2f58: d0 = -1.000000
    //     0xbe2f58: fmov            d0, #-1.00000000
    // 0xbe2f5c: r0 = indexToLayoutOffset()
    //     0xbe2f5c: bl              #0xbe6288  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::indexToLayoutOffset
    // 0xbe2f60: ldur            x2, [fp, #-0x20]
    // 0xbe2f64: r0 = BoxInt64Instr(r2)
    //     0xbe2f64: sbfiz           x0, x2, #1, #0x1f
    //     0xbe2f68: cmp             x2, x0, asr #1
    //     0xbe2f6c: b.eq            #0xbe2f78
    //     0xbe2f70: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xbe2f74: stur            x2, [x0, #7]
    // 0xbe2f78: r1 = inline_Allocate_Double()
    //     0xbe2f78: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xbe2f7c: add             x1, x1, #0x10
    //     0xbe2f80: cmp             x3, x1
    //     0xbe2f84: b.ls            #0xbe45d4
    //     0xbe2f88: str             x1, [THR, #0x60]  ; THR::top
    //     0xbe2f8c: sub             x1, x1, #0xf
    //     0xbe2f90: mov             x3, #0xe19c
    //     0xbe2f94: movk            x3, #3, lsl #16
    //     0xbe2f98: stur            x3, [x1, #-1]
    // 0xbe2f9c: dmb             ishst
    // 0xbe2fa0: StoreField: r1->field_7 = d0
    //     0xbe2fa0: stur            d0, [x1, #7]
    // 0xbe2fa4: stp             x1, x0, [SP]
    // 0xbe2fa8: ldur            x1, [fp, #-0x10]
    // 0xbe2fac: r4 = const [0, 0x3, 0x2, 0x1, index, 0x1, layoutOffset, 0x2, null]
    //     0xbe2fac: add             x4, PP, #0x96, lsl #12  ; [pp+0x968e0] List(9) [0, 0x3, 0x2, 0x1, "index", 0x1, "layoutOffset", 0x2, Null]
    //     0xbe2fb0: ldr             x4, [x4, #0x8e0]
    // 0xbe2fb4: r0 = addInitialChild()
    //     0xbe2fb4: bl              #0xbe60b8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0xbe2fb8: tbz             w0, #4, #0xbe3064
    // 0xbe2fbc: ldur            x3, [fp, #-0x20]
    // 0xbe2fc0: cmp             x3, #0
    // 0xbe2fc4: b.gt            #0xbe2fd0
    // 0xbe2fc8: d0 = 0.000000
    //     0xbe2fc8: eor             v0.16b, v0.16b, v0.16b
    // 0xbe2fcc: b               #0xbe2fdc
    // 0xbe2fd0: ldur            x1, [fp, #-0x10]
    // 0xbe2fd4: d0 = -1.000000
    //     0xbe2fd4: fmov            d0, #-1.00000000
    // 0xbe2fd8: r0 = computeMaxScrollOffset()
    //     0xbe2fd8: bl              #0xbe5be8  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::computeMaxScrollOffset
    // 0xbe2fdc: ldur            x1, [fp, #-0x10]
    // 0xbe2fe0: stur            d0, [fp, #-0x70]
    // 0xbe2fe4: r0 = SliverGeometry()
    //     0xbe2fe4: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe2fe8: ldur            d0, [fp, #-0x70]
    // 0xbe2fec: StoreField: r0->field_7 = d0
    //     0xbe2fec: stur            d0, [x0, #7]
    // 0xbe2ff0: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe2ff0: stur            xzr, [x0, #0x17]
    // 0xbe2ff4: StoreField: r0->field_f = rZR
    //     0xbe2ff4: stur            xzr, [x0, #0xf]
    // 0xbe2ff8: StoreField: r0->field_27 = d0
    //     0xbe2ff8: stur            d0, [x0, #0x27]
    // 0xbe2ffc: StoreField: r0->field_2f = rZR
    //     0xbe2ffc: stur            xzr, [x0, #0x2f]
    // 0xbe3000: r4 = false
    //     0xbe3000: add             x4, NULL, #0x30  ; false
    // 0xbe3004: StoreField: r0->field_43 = r4
    //     0xbe3004: stur            w4, [x0, #0x43]
    // 0xbe3008: StoreField: r0->field_1f = rZR
    //     0xbe3008: stur            xzr, [x0, #0x1f]
    // 0xbe300c: StoreField: r0->field_37 = rZR
    //     0xbe300c: stur            xzr, [x0, #0x37]
    // 0xbe3010: StoreField: r0->field_4b = rZR
    //     0xbe3010: stur            xzr, [x0, #0x4b]
    // 0xbe3014: d0 = 0.000000
    //     0xbe3014: eor             v0.16b, v0.16b, v0.16b
    // 0xbe3018: fcmp            d0, d0
    // 0xbe301c: r16 = true
    //     0xbe301c: add             x16, NULL, #0x20  ; true
    // 0xbe3020: r17 = false
    //     0xbe3020: add             x17, NULL, #0x30  ; false
    // 0xbe3024: csel            x1, x16, x17, gt
    // 0xbe3028: StoreField: r0->field_3f = r1
    //     0xbe3028: stur            w1, [x0, #0x3f]
    // 0xbe302c: ldur            x5, [fp, #-0x10]
    // 0xbe3030: StoreField: r5->field_47 = r0
    //     0xbe3030: stur            w0, [x5, #0x47]
    //     0xbe3034: ldurb           w16, [x5, #-1]
    //     0xbe3038: ldurb           w17, [x0, #-1]
    //     0xbe303c: and             x16, x17, x16, lsr #2
    //     0xbe3040: tst             x16, HEAP, lsr #32
    //     0xbe3044: b.eq            #0xbe304c
    //     0xbe3048: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbe304c: ldur            x1, [fp, #-0x18]
    // 0xbe3050: r0 = didFinishLayout()
    //     0xbe3050: bl              #0xbe5ab0  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0xbe3054: r0 = Null
    //     0xbe3054: mov             x0, NULL
    // 0xbe3058: LeaveFrame
    //     0xbe3058: mov             SP, fp
    //     0xbe305c: ldp             fp, lr, [SP], #0x10
    // 0xbe3060: ret
    //     0xbe3060: ret             
    // 0xbe3064: ldur            x5, [fp, #-0x10]
    // 0xbe3068: ldur            x3, [fp, #-0x20]
    // 0xbe306c: r4 = false
    //     0xbe306c: add             x4, NULL, #0x30  ; false
    // 0xbe3070: d0 = 0.000000
    //     0xbe3070: eor             v0.16b, v0.16b, v0.16b
    // 0xbe3074: b               #0xbe3088
    // 0xbe3078: mov             x5, x0
    // 0xbe307c: ldur            x3, [fp, #-0x20]
    // 0xbe3080: r4 = false
    //     0xbe3080: add             x4, NULL, #0x30  ; false
    // 0xbe3084: d0 = 0.000000
    //     0xbe3084: eor             v0.16b, v0.16b, v0.16b
    // 0xbe3088: LoadField: r0 = r5->field_53
    //     0xbe3088: ldur            w0, [x5, #0x53]
    // 0xbe308c: DecompressPointer r0
    //     0xbe308c: add             x0, x0, HEAP, lsl #32
    // 0xbe3090: cmp             w0, NULL
    // 0xbe3094: b.eq            #0xbe45f0
    // 0xbe3098: LoadField: r6 = r0->field_7
    //     0xbe3098: ldur            w6, [x0, #7]
    // 0xbe309c: DecompressPointer r6
    //     0xbe309c: add             x6, x6, HEAP, lsl #32
    // 0xbe30a0: stur            x6, [fp, #-0x38]
    // 0xbe30a4: cmp             w6, NULL
    // 0xbe30a8: b.eq            #0xbe45f4
    // 0xbe30ac: mov             x0, x6
    // 0xbe30b0: r2 = Null
    //     0xbe30b0: mov             x2, NULL
    // 0xbe30b4: r1 = Null
    //     0xbe30b4: mov             x1, NULL
    // 0xbe30b8: r4 = LoadClassIdInstr(r0)
    //     0xbe30b8: ldur            x4, [x0, #-1]
    //     0xbe30bc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe30c0: r17 = -4183
    //     0xbe30c0: mov             x17, #-0x1057
    // 0xbe30c4: add             x4, x4, x17
    // 0xbe30c8: cmp             x4, #1
    // 0xbe30cc: b.ls            #0xbe30e4
    // 0xbe30d0: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe30d0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe30d4: ldr             x8, [x8, #0x590]
    // 0xbe30d8: r3 = Null
    //     0xbe30d8: add             x3, PP, #0xab, lsl #12  ; [pp+0xab4c8] Null
    //     0xbe30dc: ldr             x3, [x3, #0x4c8]
    // 0xbe30e0: r0 = DefaultTypeTest()
    //     0xbe30e0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe30e4: ldur            x0, [fp, #-0x38]
    // 0xbe30e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe30e8: ldur            w1, [x0, #0x17]
    // 0xbe30ec: DecompressPointer r1
    //     0xbe30ec: add             x1, x1, HEAP, lsl #32
    // 0xbe30f0: cmp             w1, NULL
    // 0xbe30f4: b.eq            #0xbe45f8
    // 0xbe30f8: r0 = LoadInt32Instr(r1)
    //     0xbe30f8: sbfx            x0, x1, #1, #0x1f
    //     0xbe30fc: tbz             w1, #0, #0xbe3104
    //     0xbe3100: ldur            x0, [x1, #7]
    // 0xbe3104: sub             x1, x0, #1
    // 0xbe3108: ldur            x3, [fp, #-0x10]
    // 0xbe310c: r4 = LoadClassIdInstr(r3)
    //     0xbe310c: ldur            x4, [x3, #-1]
    //     0xbe3110: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3114: stur            x4, [fp, #-0x48]
    // 0xbe3118: mov             x6, x1
    // 0xbe311c: r7 = Null
    //     0xbe311c: mov             x7, NULL
    // 0xbe3120: ldur            x5, [fp, #-0x20]
    // 0xbe3124: stur            x7, [fp, #-0x40]
    // 0xbe3128: stur            x6, [fp, #-0x30]
    // 0xbe312c: CheckStackOverflow
    //     0xbe312c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe3130: cmp             SP, x16
    //     0xbe3134: b.ls            #0xbe45fc
    // 0xbe3138: cmp             x6, x5
    // 0xbe313c: b.lt            #0xbe36c0
    // 0xbe3140: r17 = -4702
    //     0xbe3140: mov             x17, #-0x125e
    // 0xbe3144: add             x16, x4, x17
    // 0xbe3148: cmp             x16, #1
    // 0xbe314c: b.ls            #0xbe315c
    // 0xbe3150: r17 = 4700
    //     0xbe3150: mov             x17, #0x125c
    // 0xbe3154: cmp             x4, x17
    // 0xbe3158: b.eq            #0xbe315c
    // 0xbe315c: r17 = 4700
    //     0xbe315c: mov             x17, #0x125c
    // 0xbe3160: cmp             x4, x17
    // 0xbe3164: b.ne            #0xbe3234
    // 0xbe3168: LoadField: r8 = r3->field_27
    //     0xbe3168: ldur            w8, [x3, #0x27]
    // 0xbe316c: DecompressPointer r8
    //     0xbe316c: add             x8, x8, HEAP, lsl #32
    // 0xbe3170: stur            x8, [fp, #-0x38]
    // 0xbe3174: cmp             w8, NULL
    // 0xbe3178: b.eq            #0xbe442c
    // 0xbe317c: mov             x0, x8
    // 0xbe3180: r2 = Null
    //     0xbe3180: mov             x2, NULL
    // 0xbe3184: r1 = Null
    //     0xbe3184: mov             x1, NULL
    // 0xbe3188: r4 = LoadClassIdInstr(r0)
    //     0xbe3188: ldur            x4, [x0, #-1]
    //     0xbe318c: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3190: cmp             x4, #0xb45
    // 0xbe3194: b.eq            #0xbe31ac
    // 0xbe3198: r8 = SliverConstraints
    //     0xbe3198: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe319c: ldr             x8, [x8, #0x3c0]
    // 0xbe31a0: r3 = Null
    //     0xbe31a0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab4d8] Null
    //     0xbe31a4: ldr             x3, [x3, #0x4d8]
    // 0xbe31a8: r0 = DefaultTypeTest()
    //     0xbe31a8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe31ac: ldur            x1, [fp, #-0x38]
    // 0xbe31b0: r0 = axis()
    //     0xbe31b0: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe31b4: r16 = Instance_Axis
    //     0xbe31b4: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe31b8: cmp             w0, w16
    // 0xbe31bc: b.ne            #0xbe31e0
    // 0xbe31c0: ldur            x0, [fp, #-0x10]
    // 0xbe31c4: LoadField: r1 = r0->field_63
    //     0xbe31c4: ldur            w1, [x0, #0x63]
    // 0xbe31c8: DecompressPointer r1
    //     0xbe31c8: add             x1, x1, HEAP, lsl #32
    // 0xbe31cc: cmp             w1, NULL
    // 0xbe31d0: b.eq            #0xbe4604
    // 0xbe31d4: r0 = size()
    //     0xbe31d4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe31d8: LoadField: d0 = r0->field_f
    //     0xbe31d8: ldur            d0, [x0, #0xf]
    // 0xbe31dc: b               #0xbe31fc
    // 0xbe31e0: ldur            x0, [fp, #-0x10]
    // 0xbe31e4: LoadField: r1 = r0->field_63
    //     0xbe31e4: ldur            w1, [x0, #0x63]
    // 0xbe31e8: DecompressPointer r1
    //     0xbe31e8: add             x1, x1, HEAP, lsl #32
    // 0xbe31ec: cmp             w1, NULL
    // 0xbe31f0: b.eq            #0xbe4608
    // 0xbe31f4: r0 = size()
    //     0xbe31f4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe31f8: LoadField: d0 = r0->field_7
    //     0xbe31f8: ldur            d0, [x0, #7]
    // 0xbe31fc: r0 = inline_Allocate_Double()
    //     0xbe31fc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe3200: add             x0, x0, #0x10
    //     0xbe3204: cmp             x1, x0
    //     0xbe3208: b.ls            #0xbe460c
    //     0xbe320c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe3210: sub             x0, x0, #0xf
    //     0xbe3214: mov             x1, #0xe19c
    //     0xbe3218: movk            x1, #3, lsl #16
    //     0xbe321c: stur            x1, [x0, #-1]
    // 0xbe3220: dmb             ishst
    // 0xbe3224: StoreField: r0->field_7 = d0
    //     0xbe3224: stur            d0, [x0, #7]
    // 0xbe3228: mov             x4, x0
    // 0xbe322c: ldur            x3, [fp, #-0x10]
    // 0xbe3230: b               #0xbe32f8
    // 0xbe3234: mov             x3, x4
    // 0xbe3238: r17 = 4701
    //     0xbe3238: mov             x17, #0x125d
    // 0xbe323c: cmp             x3, x17
    // 0xbe3240: b.ne            #0xbe3250
    // 0xbe3244: ldur            x3, [fp, #-0x10]
    // 0xbe3248: r4 = Null
    //     0xbe3248: mov             x4, NULL
    // 0xbe324c: b               #0xbe32f8
    // 0xbe3250: r17 = 4702
    //     0xbe3250: mov             x17, #0x125e
    // 0xbe3254: cmp             x3, x17
    // 0xbe3258: b.ne            #0xbe3274
    // 0xbe325c: ldur            x4, [fp, #-0x10]
    // 0xbe3260: LoadField: r0 = r4->field_63
    //     0xbe3260: ldur            w0, [x4, #0x63]
    // 0xbe3264: DecompressPointer r0
    //     0xbe3264: add             x0, x0, HEAP, lsl #32
    // 0xbe3268: mov             x3, x4
    // 0xbe326c: mov             x4, x0
    // 0xbe3270: b               #0xbe32f8
    // 0xbe3274: ldur            x4, [fp, #-0x10]
    // 0xbe3278: LoadField: r5 = r4->field_27
    //     0xbe3278: ldur            w5, [x4, #0x27]
    // 0xbe327c: DecompressPointer r5
    //     0xbe327c: add             x5, x5, HEAP, lsl #32
    // 0xbe3280: stur            x5, [fp, #-0x38]
    // 0xbe3284: cmp             w5, NULL
    // 0xbe3288: b.eq            #0xbe44ac
    // 0xbe328c: mov             x0, x5
    // 0xbe3290: r2 = Null
    //     0xbe3290: mov             x2, NULL
    // 0xbe3294: r1 = Null
    //     0xbe3294: mov             x1, NULL
    // 0xbe3298: r4 = LoadClassIdInstr(r0)
    //     0xbe3298: ldur            x4, [x0, #-1]
    //     0xbe329c: ubfx            x4, x4, #0xc, #0x14
    // 0xbe32a0: cmp             x4, #0xb45
    // 0xbe32a4: b.eq            #0xbe32bc
    // 0xbe32a8: r8 = SliverConstraints
    //     0xbe32a8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe32ac: ldr             x8, [x8, #0x3c0]
    // 0xbe32b0: r3 = Null
    //     0xbe32b0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab4e8] Null
    //     0xbe32b4: ldr             x3, [x3, #0x4e8]
    // 0xbe32b8: r0 = DefaultTypeTest()
    //     0xbe32b8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe32bc: ldur            x0, [fp, #-0x38]
    // 0xbe32c0: LoadField: d0 = r0->field_3f
    //     0xbe32c0: ldur            d0, [x0, #0x3f]
    // 0xbe32c4: r0 = inline_Allocate_Double()
    //     0xbe32c4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe32c8: add             x0, x0, #0x10
    //     0xbe32cc: cmp             x1, x0
    //     0xbe32d0: b.ls            #0xbe461c
    //     0xbe32d4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe32d8: sub             x0, x0, #0xf
    //     0xbe32dc: mov             x1, #0xe19c
    //     0xbe32e0: movk            x1, #3, lsl #16
    //     0xbe32e4: stur            x1, [x0, #-1]
    // 0xbe32e8: dmb             ishst
    // 0xbe32ec: StoreField: r0->field_7 = d0
    //     0xbe32ec: stur            d0, [x0, #7]
    // 0xbe32f0: mov             x4, x0
    // 0xbe32f4: ldur            x3, [fp, #-0x10]
    // 0xbe32f8: stur            x4, [fp, #-0x50]
    // 0xbe32fc: cmp             w4, NULL
    // 0xbe3300: b.eq            #0xbe462c
    // 0xbe3304: LoadField: r5 = r3->field_27
    //     0xbe3304: ldur            w5, [x3, #0x27]
    // 0xbe3308: DecompressPointer r5
    //     0xbe3308: add             x5, x5, HEAP, lsl #32
    // 0xbe330c: stur            x5, [fp, #-0x38]
    // 0xbe3310: cmp             w5, NULL
    // 0xbe3314: b.eq            #0xbe448c
    // 0xbe3318: mov             x0, x5
    // 0xbe331c: r2 = Null
    //     0xbe331c: mov             x2, NULL
    // 0xbe3320: r1 = Null
    //     0xbe3320: mov             x1, NULL
    // 0xbe3324: r4 = LoadClassIdInstr(r0)
    //     0xbe3324: ldur            x4, [x0, #-1]
    //     0xbe3328: ubfx            x4, x4, #0xc, #0x14
    // 0xbe332c: cmp             x4, #0xb45
    // 0xbe3330: b.eq            #0xbe3348
    // 0xbe3334: r8 = SliverConstraints
    //     0xbe3334: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3338: ldr             x8, [x8, #0x3c0]
    // 0xbe333c: r3 = Null
    //     0xbe333c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab4f8] Null
    //     0xbe3340: ldr             x3, [x3, #0x4f8]
    // 0xbe3344: r0 = DefaultTypeTest()
    //     0xbe3344: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3348: ldur            x16, [fp, #-0x50]
    // 0xbe334c: ldur            lr, [fp, #-0x50]
    // 0xbe3350: stp             lr, x16, [SP]
    // 0xbe3354: ldur            x1, [fp, #-0x38]
    // 0xbe3358: r4 = const [0, 0x3, 0x2, 0x1, maxExtent, 0x2, minExtent, 0x1, null]
    //     0xbe3358: add             x4, PP, #0xab, lsl #12  ; [pp+0xab508] List(9) [0, 0x3, 0x2, 0x1, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0xbe335c: ldr             x4, [x4, #0x508]
    // 0xbe3360: r0 = asBoxConstraints()
    //     0xbe3360: bl              #0xbe58b0  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0xbe3364: ldur            x1, [fp, #-0x10]
    // 0xbe3368: mov             x2, x0
    // 0xbe336c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbe336c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbe3370: r0 = insertAndLayoutLeadingChild()
    //     0xbe3370: bl              #0xbe5694  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0xbe3374: mov             x3, x0
    // 0xbe3378: stur            x3, [fp, #-0x50]
    // 0xbe337c: cmp             w3, NULL
    // 0xbe3380: b.eq            #0xbe3600
    // 0xbe3384: ldur            x4, [fp, #-0x48]
    // 0xbe3388: LoadField: r5 = r3->field_7
    //     0xbe3388: ldur            w5, [x3, #7]
    // 0xbe338c: DecompressPointer r5
    //     0xbe338c: add             x5, x5, HEAP, lsl #32
    // 0xbe3390: stur            x5, [fp, #-0x38]
    // 0xbe3394: cmp             w5, NULL
    // 0xbe3398: b.eq            #0xbe4630
    // 0xbe339c: mov             x0, x5
    // 0xbe33a0: r2 = Null
    //     0xbe33a0: mov             x2, NULL
    // 0xbe33a4: r1 = Null
    //     0xbe33a4: mov             x1, NULL
    // 0xbe33a8: r4 = LoadClassIdInstr(r0)
    //     0xbe33a8: ldur            x4, [x0, #-1]
    //     0xbe33ac: ubfx            x4, x4, #0xc, #0x14
    // 0xbe33b0: r17 = -4183
    //     0xbe33b0: mov             x17, #-0x1057
    // 0xbe33b4: add             x4, x4, x17
    // 0xbe33b8: cmp             x4, #1
    // 0xbe33bc: b.ls            #0xbe33d4
    // 0xbe33c0: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe33c0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe33c4: ldr             x8, [x8, #0x590]
    // 0xbe33c8: r3 = Null
    //     0xbe33c8: add             x3, PP, #0xab, lsl #12  ; [pp+0xab510] Null
    //     0xbe33cc: ldr             x3, [x3, #0x510]
    // 0xbe33d0: r0 = DefaultTypeTest()
    //     0xbe33d0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe33d4: ldur            x3, [fp, #-0x48]
    // 0xbe33d8: r17 = -4702
    //     0xbe33d8: mov             x17, #-0x125e
    // 0xbe33dc: add             x16, x3, x17
    // 0xbe33e0: cmp             x16, #1
    // 0xbe33e4: b.ls            #0xbe33f4
    // 0xbe33e8: r17 = 4700
    //     0xbe33e8: mov             x17, #0x125c
    // 0xbe33ec: cmp             x3, x17
    // 0xbe33f0: b.eq            #0xbe33f4
    // 0xbe33f4: r17 = 4700
    //     0xbe33f4: mov             x17, #0x125c
    // 0xbe33f8: cmp             x3, x17
    // 0xbe33fc: b.ne            #0xbe34c8
    // 0xbe3400: ldur            x4, [fp, #-0x10]
    // 0xbe3404: LoadField: r5 = r4->field_27
    //     0xbe3404: ldur            w5, [x4, #0x27]
    // 0xbe3408: DecompressPointer r5
    //     0xbe3408: add             x5, x5, HEAP, lsl #32
    // 0xbe340c: stur            x5, [fp, #-0x58]
    // 0xbe3410: cmp             w5, NULL
    // 0xbe3414: b.eq            #0xbe444c
    // 0xbe3418: mov             x0, x5
    // 0xbe341c: r2 = Null
    //     0xbe341c: mov             x2, NULL
    // 0xbe3420: r1 = Null
    //     0xbe3420: mov             x1, NULL
    // 0xbe3424: r4 = LoadClassIdInstr(r0)
    //     0xbe3424: ldur            x4, [x0, #-1]
    //     0xbe3428: ubfx            x4, x4, #0xc, #0x14
    // 0xbe342c: cmp             x4, #0xb45
    // 0xbe3430: b.eq            #0xbe3448
    // 0xbe3434: r8 = SliverConstraints
    //     0xbe3434: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3438: ldr             x8, [x8, #0x3c0]
    // 0xbe343c: r3 = Null
    //     0xbe343c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab520] Null
    //     0xbe3440: ldr             x3, [x3, #0x520]
    // 0xbe3444: r0 = DefaultTypeTest()
    //     0xbe3444: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3448: ldur            x1, [fp, #-0x58]
    // 0xbe344c: r0 = axis()
    //     0xbe344c: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe3450: r16 = Instance_Axis
    //     0xbe3450: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe3454: cmp             w0, w16
    // 0xbe3458: b.ne            #0xbe347c
    // 0xbe345c: ldur            x0, [fp, #-0x10]
    // 0xbe3460: LoadField: r1 = r0->field_63
    //     0xbe3460: ldur            w1, [x0, #0x63]
    // 0xbe3464: DecompressPointer r1
    //     0xbe3464: add             x1, x1, HEAP, lsl #32
    // 0xbe3468: cmp             w1, NULL
    // 0xbe346c: b.eq            #0xbe4634
    // 0xbe3470: r0 = size()
    //     0xbe3470: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe3474: LoadField: d0 = r0->field_f
    //     0xbe3474: ldur            d0, [x0, #0xf]
    // 0xbe3478: b               #0xbe3498
    // 0xbe347c: ldur            x0, [fp, #-0x10]
    // 0xbe3480: LoadField: r1 = r0->field_63
    //     0xbe3480: ldur            w1, [x0, #0x63]
    // 0xbe3484: DecompressPointer r1
    //     0xbe3484: add             x1, x1, HEAP, lsl #32
    // 0xbe3488: cmp             w1, NULL
    // 0xbe348c: b.eq            #0xbe4638
    // 0xbe3490: r0 = size()
    //     0xbe3490: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe3494: LoadField: d0 = r0->field_7
    //     0xbe3494: ldur            d0, [x0, #7]
    // 0xbe3498: r0 = inline_Allocate_Double()
    //     0xbe3498: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe349c: add             x0, x0, #0x10
    //     0xbe34a0: cmp             x1, x0
    //     0xbe34a4: b.ls            #0xbe463c
    //     0xbe34a8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe34ac: sub             x0, x0, #0xf
    //     0xbe34b0: mov             x1, #0xe19c
    //     0xbe34b4: movk            x1, #3, lsl #16
    //     0xbe34b8: stur            x1, [x0, #-1]
    // 0xbe34bc: dmb             ishst
    // 0xbe34c0: StoreField: r0->field_7 = d0
    //     0xbe34c0: stur            d0, [x0, #7]
    // 0xbe34c4: b               #0xbe3574
    // 0xbe34c8: r17 = 4701
    //     0xbe34c8: mov             x17, #0x125d
    // 0xbe34cc: cmp             x3, x17
    // 0xbe34d0: b.ne            #0xbe34dc
    // 0xbe34d4: r0 = Null
    //     0xbe34d4: mov             x0, NULL
    // 0xbe34d8: b               #0xbe3574
    // 0xbe34dc: r17 = 4702
    //     0xbe34dc: mov             x17, #0x125e
    // 0xbe34e0: cmp             x3, x17
    // 0xbe34e4: b.ne            #0xbe34f8
    // 0xbe34e8: ldur            x4, [fp, #-0x10]
    // 0xbe34ec: LoadField: r0 = r4->field_63
    //     0xbe34ec: ldur            w0, [x4, #0x63]
    // 0xbe34f0: DecompressPointer r0
    //     0xbe34f0: add             x0, x0, HEAP, lsl #32
    // 0xbe34f4: b               #0xbe3574
    // 0xbe34f8: ldur            x4, [fp, #-0x10]
    // 0xbe34fc: LoadField: r5 = r4->field_27
    //     0xbe34fc: ldur            w5, [x4, #0x27]
    // 0xbe3500: DecompressPointer r5
    //     0xbe3500: add             x5, x5, HEAP, lsl #32
    // 0xbe3504: stur            x5, [fp, #-0x58]
    // 0xbe3508: cmp             w5, NULL
    // 0xbe350c: b.eq            #0xbe446c
    // 0xbe3510: mov             x0, x5
    // 0xbe3514: r2 = Null
    //     0xbe3514: mov             x2, NULL
    // 0xbe3518: r1 = Null
    //     0xbe3518: mov             x1, NULL
    // 0xbe351c: r4 = LoadClassIdInstr(r0)
    //     0xbe351c: ldur            x4, [x0, #-1]
    //     0xbe3520: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3524: cmp             x4, #0xb45
    // 0xbe3528: b.eq            #0xbe3540
    // 0xbe352c: r8 = SliverConstraints
    //     0xbe352c: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3530: ldr             x8, [x8, #0x3c0]
    // 0xbe3534: r3 = Null
    //     0xbe3534: add             x3, PP, #0xab, lsl #12  ; [pp+0xab530] Null
    //     0xbe3538: ldr             x3, [x3, #0x530]
    // 0xbe353c: r0 = DefaultTypeTest()
    //     0xbe353c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3540: ldur            x0, [fp, #-0x58]
    // 0xbe3544: LoadField: d0 = r0->field_3f
    //     0xbe3544: ldur            d0, [x0, #0x3f]
    // 0xbe3548: r0 = inline_Allocate_Double()
    //     0xbe3548: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe354c: add             x0, x0, #0x10
    //     0xbe3550: cmp             x1, x0
    //     0xbe3554: b.ls            #0xbe464c
    //     0xbe3558: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe355c: sub             x0, x0, #0xf
    //     0xbe3560: mov             x1, #0xe19c
    //     0xbe3564: movk            x1, #3, lsl #16
    //     0xbe3568: stur            x1, [x0, #-1]
    // 0xbe356c: dmb             ishst
    // 0xbe3570: StoreField: r0->field_7 = d0
    //     0xbe3570: stur            d0, [x0, #7]
    // 0xbe3574: ldur            x3, [fp, #-0x40]
    // 0xbe3578: ldur            x2, [fp, #-0x30]
    // 0xbe357c: ldur            x1, [fp, #-0x38]
    // 0xbe3580: cmp             w0, NULL
    // 0xbe3584: b.eq            #0xbe465c
    // 0xbe3588: scvtf           d0, x2
    // 0xbe358c: LoadField: d1 = r0->field_7
    //     0xbe358c: ldur            d1, [x0, #7]
    // 0xbe3590: fmul            d2, d1, d0
    // 0xbe3594: r0 = inline_Allocate_Double()
    //     0xbe3594: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbe3598: add             x0, x0, #0x10
    //     0xbe359c: cmp             x4, x0
    //     0xbe35a0: b.ls            #0xbe4660
    //     0xbe35a4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe35a8: sub             x0, x0, #0xf
    //     0xbe35ac: mov             x4, #0xe19c
    //     0xbe35b0: movk            x4, #3, lsl #16
    //     0xbe35b4: stur            x4, [x0, #-1]
    // 0xbe35b8: dmb             ishst
    // 0xbe35bc: StoreField: r0->field_7 = d2
    //     0xbe35bc: stur            d2, [x0, #7]
    // 0xbe35c0: StoreField: r1->field_7 = r0
    //     0xbe35c0: stur            w0, [x1, #7]
    //     0xbe35c4: ldurb           w16, [x1, #-1]
    //     0xbe35c8: ldurb           w17, [x0, #-1]
    //     0xbe35cc: and             x16, x17, x16, lsr #2
    //     0xbe35d0: tst             x16, HEAP, lsr #32
    //     0xbe35d4: b.eq            #0xbe35dc
    //     0xbe35d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe35dc: cmp             w3, NULL
    // 0xbe35e0: b.ne            #0xbe35ec
    // 0xbe35e4: ldur            x7, [fp, #-0x50]
    // 0xbe35e8: b               #0xbe35f0
    // 0xbe35ec: mov             x7, x3
    // 0xbe35f0: sub             x6, x2, #1
    // 0xbe35f4: ldur            x3, [fp, #-0x10]
    // 0xbe35f8: ldur            x4, [fp, #-0x48]
    // 0xbe35fc: b               #0xbe3120
    // 0xbe3600: ldur            x0, [fp, #-0x10]
    // 0xbe3604: ldur            x2, [fp, #-0x30]
    // 0xbe3608: mov             x1, x0
    // 0xbe360c: d0 = -1.000000
    //     0xbe360c: fmov            d0, #-1.00000000
    // 0xbe3610: r0 = indexToLayoutOffset()
    //     0xbe3610: bl              #0xbe6288  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::indexToLayoutOffset
    // 0xbe3614: stur            d0, [fp, #-0x70]
    // 0xbe3618: r0 = SliverGeometry()
    //     0xbe3618: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe361c: StoreField: r0->field_7 = rZR
    //     0xbe361c: stur            xzr, [x0, #7]
    // 0xbe3620: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe3620: stur            xzr, [x0, #0x17]
    // 0xbe3624: StoreField: r0->field_f = rZR
    //     0xbe3624: stur            xzr, [x0, #0xf]
    // 0xbe3628: StoreField: r0->field_27 = rZR
    //     0xbe3628: stur            xzr, [x0, #0x27]
    // 0xbe362c: StoreField: r0->field_2f = rZR
    //     0xbe362c: stur            xzr, [x0, #0x2f]
    // 0xbe3630: r1 = false
    //     0xbe3630: add             x1, NULL, #0x30  ; false
    // 0xbe3634: StoreField: r0->field_43 = r1
    //     0xbe3634: stur            w1, [x0, #0x43]
    // 0xbe3638: ldur            d0, [fp, #-0x70]
    // 0xbe363c: r1 = inline_Allocate_Double()
    //     0xbe363c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbe3640: add             x1, x1, #0x10
    //     0xbe3644: cmp             x2, x1
    //     0xbe3648: b.ls            #0xbe4680
    //     0xbe364c: str             x1, [THR, #0x60]  ; THR::top
    //     0xbe3650: sub             x1, x1, #0xf
    //     0xbe3654: mov             x2, #0xe19c
    //     0xbe3658: movk            x2, #3, lsl #16
    //     0xbe365c: stur            x2, [x1, #-1]
    // 0xbe3660: dmb             ishst
    // 0xbe3664: StoreField: r1->field_7 = d0
    //     0xbe3664: stur            d0, [x1, #7]
    // 0xbe3668: StoreField: r0->field_47 = r1
    //     0xbe3668: stur            w1, [x0, #0x47]
    // 0xbe366c: StoreField: r0->field_1f = rZR
    //     0xbe366c: stur            xzr, [x0, #0x1f]
    // 0xbe3670: StoreField: r0->field_37 = rZR
    //     0xbe3670: stur            xzr, [x0, #0x37]
    // 0xbe3674: StoreField: r0->field_4b = rZR
    //     0xbe3674: stur            xzr, [x0, #0x4b]
    // 0xbe3678: d0 = 0.000000
    //     0xbe3678: eor             v0.16b, v0.16b, v0.16b
    // 0xbe367c: fcmp            d0, d0
    // 0xbe3680: r16 = true
    //     0xbe3680: add             x16, NULL, #0x20  ; true
    // 0xbe3684: r17 = false
    //     0xbe3684: add             x17, NULL, #0x30  ; false
    // 0xbe3688: csel            x1, x16, x17, gt
    // 0xbe368c: StoreField: r0->field_3f = r1
    //     0xbe368c: stur            w1, [x0, #0x3f]
    // 0xbe3690: ldur            x4, [fp, #-0x10]
    // 0xbe3694: StoreField: r4->field_47 = r0
    //     0xbe3694: stur            w0, [x4, #0x47]
    //     0xbe3698: ldurb           w16, [x4, #-1]
    //     0xbe369c: ldurb           w17, [x0, #-1]
    //     0xbe36a0: and             x16, x17, x16, lsr #2
    //     0xbe36a4: tst             x16, HEAP, lsr #32
    //     0xbe36a8: b.eq            #0xbe36b0
    //     0xbe36ac: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbe36b0: r0 = Null
    //     0xbe36b0: mov             x0, NULL
    // 0xbe36b4: LeaveFrame
    //     0xbe36b4: mov             SP, fp
    //     0xbe36b8: ldp             fp, lr, [SP], #0x10
    // 0xbe36bc: ret
    //     0xbe36bc: ret             
    // 0xbe36c0: mov             x4, x3
    // 0xbe36c4: mov             x3, x7
    // 0xbe36c8: d0 = 0.000000
    //     0xbe36c8: eor             v0.16b, v0.16b, v0.16b
    // 0xbe36cc: cmp             w3, NULL
    // 0xbe36d0: b.ne            #0xbe3848
    // 0xbe36d4: LoadField: r3 = r4->field_53
    //     0xbe36d4: ldur            w3, [x4, #0x53]
    // 0xbe36d8: DecompressPointer r3
    //     0xbe36d8: add             x3, x3, HEAP, lsl #32
    // 0xbe36dc: stur            x3, [fp, #-0x50]
    // 0xbe36e0: cmp             w3, NULL
    // 0xbe36e4: b.eq            #0xbe469c
    // 0xbe36e8: LoadField: r5 = r3->field_7
    //     0xbe36e8: ldur            w5, [x3, #7]
    // 0xbe36ec: DecompressPointer r5
    //     0xbe36ec: add             x5, x5, HEAP, lsl #32
    // 0xbe36f0: stur            x5, [fp, #-0x38]
    // 0xbe36f4: cmp             w5, NULL
    // 0xbe36f8: b.eq            #0xbe46a0
    // 0xbe36fc: mov             x0, x5
    // 0xbe3700: r2 = Null
    //     0xbe3700: mov             x2, NULL
    // 0xbe3704: r1 = Null
    //     0xbe3704: mov             x1, NULL
    // 0xbe3708: r4 = LoadClassIdInstr(r0)
    //     0xbe3708: ldur            x4, [x0, #-1]
    //     0xbe370c: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3710: r17 = -4183
    //     0xbe3710: mov             x17, #-0x1057
    // 0xbe3714: add             x4, x4, x17
    // 0xbe3718: cmp             x4, #1
    // 0xbe371c: b.ls            #0xbe3734
    // 0xbe3720: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe3720: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe3724: ldr             x8, [x8, #0x590]
    // 0xbe3728: r3 = Null
    //     0xbe3728: add             x3, PP, #0xab, lsl #12  ; [pp+0xab540] Null
    //     0xbe372c: ldr             x3, [x3, #0x540]
    // 0xbe3730: r0 = DefaultTypeTest()
    //     0xbe3730: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3734: ldur            x0, [fp, #-0x38]
    // 0xbe3738: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe3738: ldur            w1, [x0, #0x17]
    // 0xbe373c: DecompressPointer r1
    //     0xbe373c: add             x1, x1, HEAP, lsl #32
    // 0xbe3740: cmp             w1, NULL
    // 0xbe3744: b.eq            #0xbe46a4
    // 0xbe3748: ldur            x1, [fp, #-0x10]
    // 0xbe374c: r0 = _getChildConstraints()
    //     0xbe374c: bl              #0xbe53ac  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::_getChildConstraints
    // 0xbe3750: ldur            x1, [fp, #-0x50]
    // 0xbe3754: r2 = LoadClassIdInstr(r1)
    //     0xbe3754: ldur            x2, [x1, #-1]
    //     0xbe3758: ubfx            x2, x2, #0xc, #0x14
    // 0xbe375c: mov             x16, x0
    // 0xbe3760: mov             x0, x2
    // 0xbe3764: mov             x2, x16
    // 0xbe3768: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbe3768: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbe376c: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe376c: mov             x17, #0xe6b9
    //     0xbe3770: add             lr, x0, x17
    //     0xbe3774: ldr             lr, [x21, lr, lsl #3]
    //     0xbe3778: blr             lr
    // 0xbe377c: ldur            x3, [fp, #-0x10]
    // 0xbe3780: LoadField: r0 = r3->field_53
    //     0xbe3780: ldur            w0, [x3, #0x53]
    // 0xbe3784: DecompressPointer r0
    //     0xbe3784: add             x0, x0, HEAP, lsl #32
    // 0xbe3788: cmp             w0, NULL
    // 0xbe378c: b.eq            #0xbe46a8
    // 0xbe3790: LoadField: r4 = r0->field_7
    //     0xbe3790: ldur            w4, [x0, #7]
    // 0xbe3794: DecompressPointer r4
    //     0xbe3794: add             x4, x4, HEAP, lsl #32
    // 0xbe3798: stur            x4, [fp, #-0x38]
    // 0xbe379c: cmp             w4, NULL
    // 0xbe37a0: b.eq            #0xbe46ac
    // 0xbe37a4: mov             x0, x4
    // 0xbe37a8: r2 = Null
    //     0xbe37a8: mov             x2, NULL
    // 0xbe37ac: r1 = Null
    //     0xbe37ac: mov             x1, NULL
    // 0xbe37b0: r4 = LoadClassIdInstr(r0)
    //     0xbe37b0: ldur            x4, [x0, #-1]
    //     0xbe37b4: ubfx            x4, x4, #0xc, #0x14
    // 0xbe37b8: r17 = -4183
    //     0xbe37b8: mov             x17, #-0x1057
    // 0xbe37bc: add             x4, x4, x17
    // 0xbe37c0: cmp             x4, #1
    // 0xbe37c4: b.ls            #0xbe37dc
    // 0xbe37c8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe37c8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe37cc: ldr             x8, [x8, #0x590]
    // 0xbe37d0: r3 = Null
    //     0xbe37d0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab550] Null
    //     0xbe37d4: ldr             x3, [x3, #0x550]
    // 0xbe37d8: r0 = DefaultTypeTest()
    //     0xbe37d8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe37dc: ldur            x1, [fp, #-0x10]
    // 0xbe37e0: ldur            x2, [fp, #-0x20]
    // 0xbe37e4: d0 = -1.000000
    //     0xbe37e4: fmov            d0, #-1.00000000
    // 0xbe37e8: r0 = indexToLayoutOffset()
    //     0xbe37e8: bl              #0xbe6288  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::indexToLayoutOffset
    // 0xbe37ec: r0 = inline_Allocate_Double()
    //     0xbe37ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe37f0: add             x0, x0, #0x10
    //     0xbe37f4: cmp             x1, x0
    //     0xbe37f8: b.ls            #0xbe46b0
    //     0xbe37fc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe3800: sub             x0, x0, #0xf
    //     0xbe3804: mov             x1, #0xe19c
    //     0xbe3808: movk            x1, #3, lsl #16
    //     0xbe380c: stur            x1, [x0, #-1]
    // 0xbe3810: dmb             ishst
    // 0xbe3814: StoreField: r0->field_7 = d0
    //     0xbe3814: stur            d0, [x0, #7]
    // 0xbe3818: ldur            x1, [fp, #-0x38]
    // 0xbe381c: StoreField: r1->field_7 = r0
    //     0xbe381c: stur            w0, [x1, #7]
    //     0xbe3820: ldurb           w16, [x1, #-1]
    //     0xbe3824: ldurb           w17, [x0, #-1]
    //     0xbe3828: and             x16, x17, x16, lsr #2
    //     0xbe382c: tst             x16, HEAP, lsr #32
    //     0xbe3830: b.eq            #0xbe3838
    //     0xbe3834: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe3838: ldur            x4, [fp, #-0x10]
    // 0xbe383c: LoadField: r0 = r4->field_53
    //     0xbe383c: ldur            w0, [x4, #0x53]
    // 0xbe3840: DecompressPointer r0
    //     0xbe3840: add             x0, x0, HEAP, lsl #32
    // 0xbe3844: mov             x3, x0
    // 0xbe3848: stur            x3, [fp, #-0x40]
    // 0xbe384c: cmp             w3, NULL
    // 0xbe3850: b.eq            #0xbe46c0
    // 0xbe3854: LoadField: r5 = r3->field_7
    //     0xbe3854: ldur            w5, [x3, #7]
    // 0xbe3858: DecompressPointer r5
    //     0xbe3858: add             x5, x5, HEAP, lsl #32
    // 0xbe385c: stur            x5, [fp, #-0x38]
    // 0xbe3860: cmp             w5, NULL
    // 0xbe3864: b.eq            #0xbe46c4
    // 0xbe3868: mov             x0, x5
    // 0xbe386c: r2 = Null
    //     0xbe386c: mov             x2, NULL
    // 0xbe3870: r1 = Null
    //     0xbe3870: mov             x1, NULL
    // 0xbe3874: r4 = LoadClassIdInstr(r0)
    //     0xbe3874: ldur            x4, [x0, #-1]
    //     0xbe3878: ubfx            x4, x4, #0xc, #0x14
    // 0xbe387c: r17 = -4183
    //     0xbe387c: mov             x17, #-0x1057
    // 0xbe3880: add             x4, x4, x17
    // 0xbe3884: cmp             x4, #1
    // 0xbe3888: b.ls            #0xbe38a0
    // 0xbe388c: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe388c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe3890: ldr             x8, [x8, #0x590]
    // 0xbe3894: r3 = Null
    //     0xbe3894: add             x3, PP, #0xab, lsl #12  ; [pp+0xab560] Null
    //     0xbe3898: ldr             x3, [x3, #0x560]
    // 0xbe389c: r0 = DefaultTypeTest()
    //     0xbe389c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe38a0: ldur            x0, [fp, #-0x38]
    // 0xbe38a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe38a4: ldur            w1, [x0, #0x17]
    // 0xbe38a8: DecompressPointer r1
    //     0xbe38a8: add             x1, x1, HEAP, lsl #32
    // 0xbe38ac: cmp             w1, NULL
    // 0xbe38b0: b.eq            #0xbe46c8
    // 0xbe38b4: r0 = LoadInt32Instr(r1)
    //     0xbe38b4: sbfx            x0, x1, #1, #0x1f
    //     0xbe38b8: tbz             w1, #0, #0xbe38c0
    //     0xbe38bc: ldur            x0, [x1, #7]
    // 0xbe38c0: add             x1, x0, #1
    // 0xbe38c4: ldur            x3, [fp, #-0x10]
    // 0xbe38c8: r4 = LoadClassIdInstr(r3)
    //     0xbe38c8: ldur            x4, [x3, #-1]
    //     0xbe38cc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe38d0: stur            x4, [fp, #-0x68]
    // 0xbe38d4: r5 = LoadClassIdInstr(r3)
    //     0xbe38d4: ldur            x5, [x3, #-1]
    //     0xbe38d8: ubfx            x5, x5, #0xc, #0x14
    // 0xbe38dc: stur            x5, [fp, #-0x60]
    // 0xbe38e0: r6 = LoadClassIdInstr(r3)
    //     0xbe38e0: ldur            x6, [x3, #-1]
    //     0xbe38e4: ubfx            x6, x6, #0xc, #0x14
    // 0xbe38e8: stur            x6, [fp, #-0x48]
    // 0xbe38ec: ldur            x9, [fp, #-0x40]
    // 0xbe38f0: mov             x8, x1
    // 0xbe38f4: ldur            x7, [fp, #-0x28]
    // 0xbe38f8: stur            x9, [fp, #-0x40]
    // 0xbe38fc: stur            x8, [fp, #-0x30]
    // 0xbe3900: CheckStackOverflow
    //     0xbe3900: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe3904: cmp             SP, x16
    //     0xbe3908: b.ls            #0xbe46cc
    // 0xbe390c: cmp             w7, NULL
    // 0xbe3910: b.eq            #0xbe3928
    // 0xbe3914: r0 = LoadInt32Instr(r7)
    //     0xbe3914: sbfx            x0, x7, #1, #0x1f
    //     0xbe3918: tbz             w7, #0, #0xbe3920
    //     0xbe391c: ldur            x0, [x7, #7]
    // 0xbe3920: cmp             x8, x0
    // 0xbe3924: b.gt            #0xbe4180
    // 0xbe3928: LoadField: r10 = r9->field_7
    //     0xbe3928: ldur            w10, [x9, #7]
    // 0xbe392c: DecompressPointer r10
    //     0xbe392c: add             x10, x10, HEAP, lsl #32
    // 0xbe3930: stur            x10, [fp, #-0x38]
    // 0xbe3934: cmp             w10, NULL
    // 0xbe3938: b.eq            #0xbe46d4
    // 0xbe393c: mov             x0, x10
    // 0xbe3940: r2 = Null
    //     0xbe3940: mov             x2, NULL
    // 0xbe3944: r1 = Null
    //     0xbe3944: mov             x1, NULL
    // 0xbe3948: r4 = LoadClassIdInstr(r0)
    //     0xbe3948: ldur            x4, [x0, #-1]
    //     0xbe394c: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3950: r17 = -4183
    //     0xbe3950: mov             x17, #-0x1057
    // 0xbe3954: add             x4, x4, x17
    // 0xbe3958: cmp             x4, #1
    // 0xbe395c: b.ls            #0xbe3974
    // 0xbe3960: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe3960: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe3964: ldr             x8, [x8, #0x590]
    // 0xbe3968: r3 = Null
    //     0xbe3968: add             x3, PP, #0xab, lsl #12  ; [pp+0xab570] Null
    //     0xbe396c: ldr             x3, [x3, #0x570]
    // 0xbe3970: r0 = DefaultTypeTest()
    //     0xbe3970: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3974: ldur            x0, [fp, #-0x38]
    // 0xbe3978: LoadField: r3 = r0->field_f
    //     0xbe3978: ldur            w3, [x0, #0xf]
    // 0xbe397c: DecompressPointer r3
    //     0xbe397c: add             x3, x3, HEAP, lsl #32
    // 0xbe3980: stur            x3, [fp, #-0x50]
    // 0xbe3984: cmp             w3, NULL
    // 0xbe3988: b.ne            #0xbe3994
    // 0xbe398c: ldur            x3, [fp, #-0x30]
    // 0xbe3990: b               #0xbe3a10
    // 0xbe3994: ldur            x4, [fp, #-0x30]
    // 0xbe3998: LoadField: r5 = r3->field_7
    //     0xbe3998: ldur            w5, [x3, #7]
    // 0xbe399c: DecompressPointer r5
    //     0xbe399c: add             x5, x5, HEAP, lsl #32
    // 0xbe39a0: stur            x5, [fp, #-0x38]
    // 0xbe39a4: cmp             w5, NULL
    // 0xbe39a8: b.eq            #0xbe46d8
    // 0xbe39ac: mov             x0, x5
    // 0xbe39b0: r2 = Null
    //     0xbe39b0: mov             x2, NULL
    // 0xbe39b4: r1 = Null
    //     0xbe39b4: mov             x1, NULL
    // 0xbe39b8: r4 = LoadClassIdInstr(r0)
    //     0xbe39b8: ldur            x4, [x0, #-1]
    //     0xbe39bc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe39c0: r17 = -4183
    //     0xbe39c0: mov             x17, #-0x1057
    // 0xbe39c4: add             x4, x4, x17
    // 0xbe39c8: cmp             x4, #1
    // 0xbe39cc: b.ls            #0xbe39e4
    // 0xbe39d0: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe39d0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe39d4: ldr             x8, [x8, #0x590]
    // 0xbe39d8: r3 = Null
    //     0xbe39d8: add             x3, PP, #0xab, lsl #12  ; [pp+0xab580] Null
    //     0xbe39dc: ldr             x3, [x3, #0x580]
    // 0xbe39e0: r0 = DefaultTypeTest()
    //     0xbe39e0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe39e4: ldur            x0, [fp, #-0x38]
    // 0xbe39e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe39e8: ldur            w1, [x0, #0x17]
    // 0xbe39ec: DecompressPointer r1
    //     0xbe39ec: add             x1, x1, HEAP, lsl #32
    // 0xbe39f0: cmp             w1, NULL
    // 0xbe39f4: b.eq            #0xbe46dc
    // 0xbe39f8: r0 = LoadInt32Instr(r1)
    //     0xbe39f8: sbfx            x0, x1, #1, #0x1f
    //     0xbe39fc: tbz             w1, #0, #0xbe3a04
    //     0xbe3a00: ldur            x0, [x1, #7]
    // 0xbe3a04: ldur            x3, [fp, #-0x30]
    // 0xbe3a08: cmp             x0, x3
    // 0xbe3a0c: b.eq            #0xbe3c78
    // 0xbe3a10: ldur            x4, [fp, #-0x48]
    // 0xbe3a14: r17 = -4702
    //     0xbe3a14: mov             x17, #-0x125e
    // 0xbe3a18: add             x16, x4, x17
    // 0xbe3a1c: cmp             x16, #1
    // 0xbe3a20: b.ls            #0xbe3a30
    // 0xbe3a24: r17 = 4700
    //     0xbe3a24: mov             x17, #0x125c
    // 0xbe3a28: cmp             x4, x17
    // 0xbe3a2c: b.eq            #0xbe3a30
    // 0xbe3a30: r17 = 4700
    //     0xbe3a30: mov             x17, #0x125c
    // 0xbe3a34: cmp             x4, x17
    // 0xbe3a38: b.ne            #0xbe3b0c
    // 0xbe3a3c: ldur            x5, [fp, #-0x10]
    // 0xbe3a40: LoadField: r6 = r5->field_27
    //     0xbe3a40: ldur            w6, [x5, #0x27]
    // 0xbe3a44: DecompressPointer r6
    //     0xbe3a44: add             x6, x6, HEAP, lsl #32
    // 0xbe3a48: stur            x6, [fp, #-0x38]
    // 0xbe3a4c: cmp             w6, NULL
    // 0xbe3a50: b.eq            #0xbe44cc
    // 0xbe3a54: mov             x0, x6
    // 0xbe3a58: r2 = Null
    //     0xbe3a58: mov             x2, NULL
    // 0xbe3a5c: r1 = Null
    //     0xbe3a5c: mov             x1, NULL
    // 0xbe3a60: r4 = LoadClassIdInstr(r0)
    //     0xbe3a60: ldur            x4, [x0, #-1]
    //     0xbe3a64: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3a68: cmp             x4, #0xb45
    // 0xbe3a6c: b.eq            #0xbe3a84
    // 0xbe3a70: r8 = SliverConstraints
    //     0xbe3a70: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3a74: ldr             x8, [x8, #0x3c0]
    // 0xbe3a78: r3 = Null
    //     0xbe3a78: add             x3, PP, #0xab, lsl #12  ; [pp+0xab590] Null
    //     0xbe3a7c: ldr             x3, [x3, #0x590]
    // 0xbe3a80: r0 = DefaultTypeTest()
    //     0xbe3a80: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3a84: ldur            x1, [fp, #-0x38]
    // 0xbe3a88: r0 = axis()
    //     0xbe3a88: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe3a8c: r16 = Instance_Axis
    //     0xbe3a8c: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe3a90: cmp             w0, w16
    // 0xbe3a94: b.ne            #0xbe3ab8
    // 0xbe3a98: ldur            x0, [fp, #-0x10]
    // 0xbe3a9c: LoadField: r1 = r0->field_63
    //     0xbe3a9c: ldur            w1, [x0, #0x63]
    // 0xbe3aa0: DecompressPointer r1
    //     0xbe3aa0: add             x1, x1, HEAP, lsl #32
    // 0xbe3aa4: cmp             w1, NULL
    // 0xbe3aa8: b.eq            #0xbe46e0
    // 0xbe3aac: r0 = size()
    //     0xbe3aac: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe3ab0: LoadField: d0 = r0->field_f
    //     0xbe3ab0: ldur            d0, [x0, #0xf]
    // 0xbe3ab4: b               #0xbe3ad4
    // 0xbe3ab8: ldur            x0, [fp, #-0x10]
    // 0xbe3abc: LoadField: r1 = r0->field_63
    //     0xbe3abc: ldur            w1, [x0, #0x63]
    // 0xbe3ac0: DecompressPointer r1
    //     0xbe3ac0: add             x1, x1, HEAP, lsl #32
    // 0xbe3ac4: cmp             w1, NULL
    // 0xbe3ac8: b.eq            #0xbe46e4
    // 0xbe3acc: r0 = size()
    //     0xbe3acc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe3ad0: LoadField: d0 = r0->field_7
    //     0xbe3ad0: ldur            d0, [x0, #7]
    // 0xbe3ad4: r0 = inline_Allocate_Double()
    //     0xbe3ad4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe3ad8: add             x0, x0, #0x10
    //     0xbe3adc: cmp             x1, x0
    //     0xbe3ae0: b.ls            #0xbe46e8
    //     0xbe3ae4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe3ae8: sub             x0, x0, #0xf
    //     0xbe3aec: mov             x1, #0xe19c
    //     0xbe3af0: movk            x1, #3, lsl #16
    //     0xbe3af4: stur            x1, [x0, #-1]
    // 0xbe3af8: dmb             ishst
    // 0xbe3afc: StoreField: r0->field_7 = d0
    //     0xbe3afc: stur            d0, [x0, #7]
    // 0xbe3b00: mov             x4, x0
    // 0xbe3b04: ldur            x3, [fp, #-0x10]
    // 0xbe3b08: b               #0xbe3bd0
    // 0xbe3b0c: mov             x3, x4
    // 0xbe3b10: r17 = 4701
    //     0xbe3b10: mov             x17, #0x125d
    // 0xbe3b14: cmp             x3, x17
    // 0xbe3b18: b.ne            #0xbe3b28
    // 0xbe3b1c: ldur            x3, [fp, #-0x10]
    // 0xbe3b20: r4 = Null
    //     0xbe3b20: mov             x4, NULL
    // 0xbe3b24: b               #0xbe3bd0
    // 0xbe3b28: r17 = 4702
    //     0xbe3b28: mov             x17, #0x125e
    // 0xbe3b2c: cmp             x3, x17
    // 0xbe3b30: b.ne            #0xbe3b4c
    // 0xbe3b34: ldur            x4, [fp, #-0x10]
    // 0xbe3b38: LoadField: r0 = r4->field_63
    //     0xbe3b38: ldur            w0, [x4, #0x63]
    // 0xbe3b3c: DecompressPointer r0
    //     0xbe3b3c: add             x0, x0, HEAP, lsl #32
    // 0xbe3b40: mov             x3, x4
    // 0xbe3b44: mov             x4, x0
    // 0xbe3b48: b               #0xbe3bd0
    // 0xbe3b4c: ldur            x4, [fp, #-0x10]
    // 0xbe3b50: LoadField: r5 = r4->field_27
    //     0xbe3b50: ldur            w5, [x4, #0x27]
    // 0xbe3b54: DecompressPointer r5
    //     0xbe3b54: add             x5, x5, HEAP, lsl #32
    // 0xbe3b58: stur            x5, [fp, #-0x38]
    // 0xbe3b5c: cmp             w5, NULL
    // 0xbe3b60: b.eq            #0xbe450c
    // 0xbe3b64: mov             x0, x5
    // 0xbe3b68: r2 = Null
    //     0xbe3b68: mov             x2, NULL
    // 0xbe3b6c: r1 = Null
    //     0xbe3b6c: mov             x1, NULL
    // 0xbe3b70: r4 = LoadClassIdInstr(r0)
    //     0xbe3b70: ldur            x4, [x0, #-1]
    //     0xbe3b74: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3b78: cmp             x4, #0xb45
    // 0xbe3b7c: b.eq            #0xbe3b94
    // 0xbe3b80: r8 = SliverConstraints
    //     0xbe3b80: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3b84: ldr             x8, [x8, #0x3c0]
    // 0xbe3b88: r3 = Null
    //     0xbe3b88: add             x3, PP, #0xab, lsl #12  ; [pp+0xab5a0] Null
    //     0xbe3b8c: ldr             x3, [x3, #0x5a0]
    // 0xbe3b90: r0 = DefaultTypeTest()
    //     0xbe3b90: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3b94: ldur            x0, [fp, #-0x38]
    // 0xbe3b98: LoadField: d0 = r0->field_3f
    //     0xbe3b98: ldur            d0, [x0, #0x3f]
    // 0xbe3b9c: r0 = inline_Allocate_Double()
    //     0xbe3b9c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe3ba0: add             x0, x0, #0x10
    //     0xbe3ba4: cmp             x1, x0
    //     0xbe3ba8: b.ls            #0xbe46f8
    //     0xbe3bac: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe3bb0: sub             x0, x0, #0xf
    //     0xbe3bb4: mov             x1, #0xe19c
    //     0xbe3bb8: movk            x1, #3, lsl #16
    //     0xbe3bbc: stur            x1, [x0, #-1]
    // 0xbe3bc0: dmb             ishst
    // 0xbe3bc4: StoreField: r0->field_7 = d0
    //     0xbe3bc4: stur            d0, [x0, #7]
    // 0xbe3bc8: mov             x4, x0
    // 0xbe3bcc: ldur            x3, [fp, #-0x10]
    // 0xbe3bd0: stur            x4, [fp, #-0x58]
    // 0xbe3bd4: cmp             w4, NULL
    // 0xbe3bd8: b.eq            #0xbe4708
    // 0xbe3bdc: LoadField: r5 = r3->field_27
    //     0xbe3bdc: ldur            w5, [x3, #0x27]
    // 0xbe3be0: DecompressPointer r5
    //     0xbe3be0: add             x5, x5, HEAP, lsl #32
    // 0xbe3be4: stur            x5, [fp, #-0x38]
    // 0xbe3be8: cmp             w5, NULL
    // 0xbe3bec: b.eq            #0xbe44ec
    // 0xbe3bf0: mov             x0, x5
    // 0xbe3bf4: r2 = Null
    //     0xbe3bf4: mov             x2, NULL
    // 0xbe3bf8: r1 = Null
    //     0xbe3bf8: mov             x1, NULL
    // 0xbe3bfc: r4 = LoadClassIdInstr(r0)
    //     0xbe3bfc: ldur            x4, [x0, #-1]
    //     0xbe3c00: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3c04: cmp             x4, #0xb45
    // 0xbe3c08: b.eq            #0xbe3c20
    // 0xbe3c0c: r8 = SliverConstraints
    //     0xbe3c0c: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3c10: ldr             x8, [x8, #0x3c0]
    // 0xbe3c14: r3 = Null
    //     0xbe3c14: add             x3, PP, #0xab, lsl #12  ; [pp+0xab5b0] Null
    //     0xbe3c18: ldr             x3, [x3, #0x5b0]
    // 0xbe3c1c: r0 = DefaultTypeTest()
    //     0xbe3c1c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3c20: ldur            x16, [fp, #-0x58]
    // 0xbe3c24: ldur            lr, [fp, #-0x58]
    // 0xbe3c28: stp             lr, x16, [SP]
    // 0xbe3c2c: ldur            x1, [fp, #-0x38]
    // 0xbe3c30: r4 = const [0, 0x3, 0x2, 0x1, maxExtent, 0x2, minExtent, 0x1, null]
    //     0xbe3c30: add             x4, PP, #0xab, lsl #12  ; [pp+0xab508] List(9) [0, 0x3, 0x2, 0x1, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0xbe3c34: ldr             x4, [x4, #0x508]
    // 0xbe3c38: r0 = asBoxConstraints()
    //     0xbe3c38: bl              #0xbe58b0  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0xbe3c3c: ldur            x1, [fp, #-0x10]
    // 0xbe3c40: mov             x2, x0
    // 0xbe3c44: ldur            x3, [fp, #-0x40]
    // 0xbe3c48: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xbe3c48: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xbe3c4c: r0 = insertAndLayoutChild()
    //     0xbe3c4c: bl              #0xbe4bac  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutChild
    // 0xbe3c50: cmp             w0, NULL
    // 0xbe3c54: b.eq            #0xbe3c60
    // 0xbe3c58: mov             x9, x0
    // 0xbe3c5c: b               #0xbe3ed4
    // 0xbe3c60: ldur            x1, [fp, #-0x10]
    // 0xbe3c64: ldur            x2, [fp, #-0x30]
    // 0xbe3c68: d0 = -1.000000
    //     0xbe3c68: fmov            d0, #-1.00000000
    // 0xbe3c6c: r0 = indexToLayoutOffset()
    //     0xbe3c6c: bl              #0xbe6288  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::indexToLayoutOffset
    // 0xbe3c70: mov             v1.16b, v0.16b
    // 0xbe3c74: b               #0xbe4184
    // 0xbe3c78: ldur            x3, [fp, #-0x68]
    // 0xbe3c7c: r17 = -4702
    //     0xbe3c7c: mov             x17, #-0x125e
    // 0xbe3c80: add             x16, x3, x17
    // 0xbe3c84: cmp             x16, #1
    // 0xbe3c88: b.ls            #0xbe3c98
    // 0xbe3c8c: r17 = 4700
    //     0xbe3c8c: mov             x17, #0x125c
    // 0xbe3c90: cmp             x3, x17
    // 0xbe3c94: b.eq            #0xbe3c98
    // 0xbe3c98: r17 = 4700
    //     0xbe3c98: mov             x17, #0x125c
    // 0xbe3c9c: cmp             x3, x17
    // 0xbe3ca0: b.ne            #0xbe3d74
    // 0xbe3ca4: ldur            x4, [fp, #-0x10]
    // 0xbe3ca8: LoadField: r5 = r4->field_27
    //     0xbe3ca8: ldur            w5, [x4, #0x27]
    // 0xbe3cac: DecompressPointer r5
    //     0xbe3cac: add             x5, x5, HEAP, lsl #32
    // 0xbe3cb0: stur            x5, [fp, #-0x38]
    // 0xbe3cb4: cmp             w5, NULL
    // 0xbe3cb8: b.eq            #0xbe452c
    // 0xbe3cbc: mov             x0, x5
    // 0xbe3cc0: r2 = Null
    //     0xbe3cc0: mov             x2, NULL
    // 0xbe3cc4: r1 = Null
    //     0xbe3cc4: mov             x1, NULL
    // 0xbe3cc8: r4 = LoadClassIdInstr(r0)
    //     0xbe3cc8: ldur            x4, [x0, #-1]
    //     0xbe3ccc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3cd0: cmp             x4, #0xb45
    // 0xbe3cd4: b.eq            #0xbe3cec
    // 0xbe3cd8: r8 = SliverConstraints
    //     0xbe3cd8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3cdc: ldr             x8, [x8, #0x3c0]
    // 0xbe3ce0: r3 = Null
    //     0xbe3ce0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab5c0] Null
    //     0xbe3ce4: ldr             x3, [x3, #0x5c0]
    // 0xbe3ce8: r0 = DefaultTypeTest()
    //     0xbe3ce8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3cec: ldur            x1, [fp, #-0x38]
    // 0xbe3cf0: r0 = axis()
    //     0xbe3cf0: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe3cf4: r16 = Instance_Axis
    //     0xbe3cf4: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe3cf8: cmp             w0, w16
    // 0xbe3cfc: b.ne            #0xbe3d20
    // 0xbe3d00: ldur            x0, [fp, #-0x10]
    // 0xbe3d04: LoadField: r1 = r0->field_63
    //     0xbe3d04: ldur            w1, [x0, #0x63]
    // 0xbe3d08: DecompressPointer r1
    //     0xbe3d08: add             x1, x1, HEAP, lsl #32
    // 0xbe3d0c: cmp             w1, NULL
    // 0xbe3d10: b.eq            #0xbe470c
    // 0xbe3d14: r0 = size()
    //     0xbe3d14: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe3d18: LoadField: d0 = r0->field_f
    //     0xbe3d18: ldur            d0, [x0, #0xf]
    // 0xbe3d1c: b               #0xbe3d3c
    // 0xbe3d20: ldur            x0, [fp, #-0x10]
    // 0xbe3d24: LoadField: r1 = r0->field_63
    //     0xbe3d24: ldur            w1, [x0, #0x63]
    // 0xbe3d28: DecompressPointer r1
    //     0xbe3d28: add             x1, x1, HEAP, lsl #32
    // 0xbe3d2c: cmp             w1, NULL
    // 0xbe3d30: b.eq            #0xbe4710
    // 0xbe3d34: r0 = size()
    //     0xbe3d34: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe3d38: LoadField: d0 = r0->field_7
    //     0xbe3d38: ldur            d0, [x0, #7]
    // 0xbe3d3c: r0 = inline_Allocate_Double()
    //     0xbe3d3c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe3d40: add             x0, x0, #0x10
    //     0xbe3d44: cmp             x1, x0
    //     0xbe3d48: b.ls            #0xbe4714
    //     0xbe3d4c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe3d50: sub             x0, x0, #0xf
    //     0xbe3d54: mov             x1, #0xe19c
    //     0xbe3d58: movk            x1, #3, lsl #16
    //     0xbe3d5c: stur            x1, [x0, #-1]
    // 0xbe3d60: dmb             ishst
    // 0xbe3d64: StoreField: r0->field_7 = d0
    //     0xbe3d64: stur            d0, [x0, #7]
    // 0xbe3d68: mov             x4, x0
    // 0xbe3d6c: ldur            x3, [fp, #-0x10]
    // 0xbe3d70: b               #0xbe3e34
    // 0xbe3d74: r17 = 4701
    //     0xbe3d74: mov             x17, #0x125d
    // 0xbe3d78: cmp             x3, x17
    // 0xbe3d7c: b.ne            #0xbe3d8c
    // 0xbe3d80: ldur            x3, [fp, #-0x10]
    // 0xbe3d84: r4 = Null
    //     0xbe3d84: mov             x4, NULL
    // 0xbe3d88: b               #0xbe3e34
    // 0xbe3d8c: r17 = 4702
    //     0xbe3d8c: mov             x17, #0x125e
    // 0xbe3d90: cmp             x3, x17
    // 0xbe3d94: b.ne            #0xbe3db0
    // 0xbe3d98: ldur            x4, [fp, #-0x10]
    // 0xbe3d9c: LoadField: r0 = r4->field_63
    //     0xbe3d9c: ldur            w0, [x4, #0x63]
    // 0xbe3da0: DecompressPointer r0
    //     0xbe3da0: add             x0, x0, HEAP, lsl #32
    // 0xbe3da4: mov             x3, x4
    // 0xbe3da8: mov             x4, x0
    // 0xbe3dac: b               #0xbe3e34
    // 0xbe3db0: ldur            x4, [fp, #-0x10]
    // 0xbe3db4: LoadField: r5 = r4->field_27
    //     0xbe3db4: ldur            w5, [x4, #0x27]
    // 0xbe3db8: DecompressPointer r5
    //     0xbe3db8: add             x5, x5, HEAP, lsl #32
    // 0xbe3dbc: stur            x5, [fp, #-0x38]
    // 0xbe3dc0: cmp             w5, NULL
    // 0xbe3dc4: b.eq            #0xbe45ac
    // 0xbe3dc8: mov             x0, x5
    // 0xbe3dcc: r2 = Null
    //     0xbe3dcc: mov             x2, NULL
    // 0xbe3dd0: r1 = Null
    //     0xbe3dd0: mov             x1, NULL
    // 0xbe3dd4: r4 = LoadClassIdInstr(r0)
    //     0xbe3dd4: ldur            x4, [x0, #-1]
    //     0xbe3dd8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3ddc: cmp             x4, #0xb45
    // 0xbe3de0: b.eq            #0xbe3df8
    // 0xbe3de4: r8 = SliverConstraints
    //     0xbe3de4: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3de8: ldr             x8, [x8, #0x3c0]
    // 0xbe3dec: r3 = Null
    //     0xbe3dec: add             x3, PP, #0xab, lsl #12  ; [pp+0xab5d0] Null
    //     0xbe3df0: ldr             x3, [x3, #0x5d0]
    // 0xbe3df4: r0 = DefaultTypeTest()
    //     0xbe3df4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3df8: ldur            x0, [fp, #-0x38]
    // 0xbe3dfc: LoadField: d0 = r0->field_3f
    //     0xbe3dfc: ldur            d0, [x0, #0x3f]
    // 0xbe3e00: r0 = inline_Allocate_Double()
    //     0xbe3e00: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe3e04: add             x0, x0, #0x10
    //     0xbe3e08: cmp             x1, x0
    //     0xbe3e0c: b.ls            #0xbe4724
    //     0xbe3e10: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe3e14: sub             x0, x0, #0xf
    //     0xbe3e18: mov             x1, #0xe19c
    //     0xbe3e1c: movk            x1, #3, lsl #16
    //     0xbe3e20: stur            x1, [x0, #-1]
    // 0xbe3e24: dmb             ishst
    // 0xbe3e28: StoreField: r0->field_7 = d0
    //     0xbe3e28: stur            d0, [x0, #7]
    // 0xbe3e2c: mov             x4, x0
    // 0xbe3e30: ldur            x3, [fp, #-0x10]
    // 0xbe3e34: stur            x4, [fp, #-0x40]
    // 0xbe3e38: cmp             w4, NULL
    // 0xbe3e3c: b.eq            #0xbe4734
    // 0xbe3e40: LoadField: r5 = r3->field_27
    //     0xbe3e40: ldur            w5, [x3, #0x27]
    // 0xbe3e44: DecompressPointer r5
    //     0xbe3e44: add             x5, x5, HEAP, lsl #32
    // 0xbe3e48: stur            x5, [fp, #-0x38]
    // 0xbe3e4c: cmp             w5, NULL
    // 0xbe3e50: b.eq            #0xbe458c
    // 0xbe3e54: ldur            x6, [fp, #-0x50]
    // 0xbe3e58: mov             x0, x5
    // 0xbe3e5c: r2 = Null
    //     0xbe3e5c: mov             x2, NULL
    // 0xbe3e60: r1 = Null
    //     0xbe3e60: mov             x1, NULL
    // 0xbe3e64: r4 = LoadClassIdInstr(r0)
    //     0xbe3e64: ldur            x4, [x0, #-1]
    //     0xbe3e68: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3e6c: cmp             x4, #0xb45
    // 0xbe3e70: b.eq            #0xbe3e88
    // 0xbe3e74: r8 = SliverConstraints
    //     0xbe3e74: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3e78: ldr             x8, [x8, #0x3c0]
    // 0xbe3e7c: r3 = Null
    //     0xbe3e7c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab5e0] Null
    //     0xbe3e80: ldr             x3, [x3, #0x5e0]
    // 0xbe3e84: r0 = DefaultTypeTest()
    //     0xbe3e84: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3e88: ldur            x16, [fp, #-0x40]
    // 0xbe3e8c: ldur            lr, [fp, #-0x40]
    // 0xbe3e90: stp             lr, x16, [SP]
    // 0xbe3e94: ldur            x1, [fp, #-0x38]
    // 0xbe3e98: r4 = const [0, 0x3, 0x2, 0x1, maxExtent, 0x2, minExtent, 0x1, null]
    //     0xbe3e98: add             x4, PP, #0xab, lsl #12  ; [pp+0xab508] List(9) [0, 0x3, 0x2, 0x1, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0xbe3e9c: ldr             x4, [x4, #0x508]
    // 0xbe3ea0: r0 = asBoxConstraints()
    //     0xbe3ea0: bl              #0xbe58b0  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0xbe3ea4: ldur            x3, [fp, #-0x50]
    // 0xbe3ea8: r1 = LoadClassIdInstr(r3)
    //     0xbe3ea8: ldur            x1, [x3, #-1]
    //     0xbe3eac: ubfx            x1, x1, #0xc, #0x14
    // 0xbe3eb0: mov             x2, x0
    // 0xbe3eb4: mov             x0, x1
    // 0xbe3eb8: mov             x1, x3
    // 0xbe3ebc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbe3ebc: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbe3ec0: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe3ec0: mov             x17, #0xe6b9
    //     0xbe3ec4: add             lr, x0, x17
    //     0xbe3ec8: ldr             lr, [x21, lr, lsl #3]
    //     0xbe3ecc: blr             lr
    // 0xbe3ed0: ldur            x9, [fp, #-0x50]
    // 0xbe3ed4: ldur            x3, [fp, #-0x60]
    // 0xbe3ed8: stur            x9, [fp, #-0x40]
    // 0xbe3edc: LoadField: r4 = r9->field_7
    //     0xbe3edc: ldur            w4, [x9, #7]
    // 0xbe3ee0: DecompressPointer r4
    //     0xbe3ee0: add             x4, x4, HEAP, lsl #32
    // 0xbe3ee4: stur            x4, [fp, #-0x38]
    // 0xbe3ee8: cmp             w4, NULL
    // 0xbe3eec: b.eq            #0xbe4738
    // 0xbe3ef0: mov             x0, x4
    // 0xbe3ef4: r2 = Null
    //     0xbe3ef4: mov             x2, NULL
    // 0xbe3ef8: r1 = Null
    //     0xbe3ef8: mov             x1, NULL
    // 0xbe3efc: r4 = LoadClassIdInstr(r0)
    //     0xbe3efc: ldur            x4, [x0, #-1]
    //     0xbe3f00: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3f04: r17 = -4183
    //     0xbe3f04: mov             x17, #-0x1057
    // 0xbe3f08: add             x4, x4, x17
    // 0xbe3f0c: cmp             x4, #1
    // 0xbe3f10: b.ls            #0xbe3f28
    // 0xbe3f14: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe3f14: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe3f18: ldr             x8, [x8, #0x590]
    // 0xbe3f1c: r3 = Null
    //     0xbe3f1c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab5f0] Null
    //     0xbe3f20: ldr             x3, [x3, #0x5f0]
    // 0xbe3f24: r0 = DefaultTypeTest()
    //     0xbe3f24: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3f28: ldur            x3, [fp, #-0x38]
    // 0xbe3f2c: ArrayLoad: r4 = r3[0]  ; List_4
    //     0xbe3f2c: ldur            w4, [x3, #0x17]
    // 0xbe3f30: DecompressPointer r4
    //     0xbe3f30: add             x4, x4, HEAP, lsl #32
    // 0xbe3f34: stur            x4, [fp, #-0x58]
    // 0xbe3f38: cmp             w4, NULL
    // 0xbe3f3c: b.eq            #0xbe473c
    // 0xbe3f40: ldur            x5, [fp, #-0x60]
    // 0xbe3f44: r17 = -4702
    //     0xbe3f44: mov             x17, #-0x125e
    // 0xbe3f48: add             x16, x5, x17
    // 0xbe3f4c: cmp             x16, #1
    // 0xbe3f50: b.ls            #0xbe3f60
    // 0xbe3f54: r17 = 4700
    //     0xbe3f54: mov             x17, #0x125c
    // 0xbe3f58: cmp             x5, x17
    // 0xbe3f5c: b.eq            #0xbe3f60
    // 0xbe3f60: r17 = 4700
    //     0xbe3f60: mov             x17, #0x125c
    // 0xbe3f64: cmp             x5, x17
    // 0xbe3f68: b.ne            #0xbe4038
    // 0xbe3f6c: ldur            x6, [fp, #-0x10]
    // 0xbe3f70: LoadField: r7 = r6->field_27
    //     0xbe3f70: ldur            w7, [x6, #0x27]
    // 0xbe3f74: DecompressPointer r7
    //     0xbe3f74: add             x7, x7, HEAP, lsl #32
    // 0xbe3f78: stur            x7, [fp, #-0x50]
    // 0xbe3f7c: cmp             w7, NULL
    // 0xbe3f80: b.eq            #0xbe454c
    // 0xbe3f84: mov             x0, x7
    // 0xbe3f88: r2 = Null
    //     0xbe3f88: mov             x2, NULL
    // 0xbe3f8c: r1 = Null
    //     0xbe3f8c: mov             x1, NULL
    // 0xbe3f90: r4 = LoadClassIdInstr(r0)
    //     0xbe3f90: ldur            x4, [x0, #-1]
    //     0xbe3f94: ubfx            x4, x4, #0xc, #0x14
    // 0xbe3f98: cmp             x4, #0xb45
    // 0xbe3f9c: b.eq            #0xbe3fb4
    // 0xbe3fa0: r8 = SliverConstraints
    //     0xbe3fa0: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe3fa4: ldr             x8, [x8, #0x3c0]
    // 0xbe3fa8: r3 = Null
    //     0xbe3fa8: add             x3, PP, #0xab, lsl #12  ; [pp+0xab600] Null
    //     0xbe3fac: ldr             x3, [x3, #0x600]
    // 0xbe3fb0: r0 = DefaultTypeTest()
    //     0xbe3fb0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe3fb4: ldur            x1, [fp, #-0x50]
    // 0xbe3fb8: r0 = axis()
    //     0xbe3fb8: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe3fbc: r16 = Instance_Axis
    //     0xbe3fbc: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe3fc0: cmp             w0, w16
    // 0xbe3fc4: b.ne            #0xbe3fe8
    // 0xbe3fc8: ldur            x0, [fp, #-0x10]
    // 0xbe3fcc: LoadField: r1 = r0->field_63
    //     0xbe3fcc: ldur            w1, [x0, #0x63]
    // 0xbe3fd0: DecompressPointer r1
    //     0xbe3fd0: add             x1, x1, HEAP, lsl #32
    // 0xbe3fd4: cmp             w1, NULL
    // 0xbe3fd8: b.eq            #0xbe4740
    // 0xbe3fdc: r0 = size()
    //     0xbe3fdc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe3fe0: LoadField: d0 = r0->field_f
    //     0xbe3fe0: ldur            d0, [x0, #0xf]
    // 0xbe3fe4: b               #0xbe4004
    // 0xbe3fe8: ldur            x0, [fp, #-0x10]
    // 0xbe3fec: LoadField: r1 = r0->field_63
    //     0xbe3fec: ldur            w1, [x0, #0x63]
    // 0xbe3ff0: DecompressPointer r1
    //     0xbe3ff0: add             x1, x1, HEAP, lsl #32
    // 0xbe3ff4: cmp             w1, NULL
    // 0xbe3ff8: b.eq            #0xbe4744
    // 0xbe3ffc: r0 = size()
    //     0xbe3ffc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe4000: LoadField: d0 = r0->field_7
    //     0xbe4000: ldur            d0, [x0, #7]
    // 0xbe4004: r0 = inline_Allocate_Double()
    //     0xbe4004: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe4008: add             x0, x0, #0x10
    //     0xbe400c: cmp             x1, x0
    //     0xbe4010: b.ls            #0xbe4748
    //     0xbe4014: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe4018: sub             x0, x0, #0xf
    //     0xbe401c: mov             x1, #0xe19c
    //     0xbe4020: movk            x1, #3, lsl #16
    //     0xbe4024: stur            x1, [x0, #-1]
    // 0xbe4028: dmb             ishst
    // 0xbe402c: StoreField: r0->field_7 = d0
    //     0xbe402c: stur            d0, [x0, #7]
    // 0xbe4030: mov             x3, x0
    // 0xbe4034: b               #0xbe40f0
    // 0xbe4038: mov             x3, x5
    // 0xbe403c: r17 = 4701
    //     0xbe403c: mov             x17, #0x125d
    // 0xbe4040: cmp             x3, x17
    // 0xbe4044: b.ne            #0xbe4050
    // 0xbe4048: r3 = Null
    //     0xbe4048: mov             x3, NULL
    // 0xbe404c: b               #0xbe40f0
    // 0xbe4050: r17 = 4702
    //     0xbe4050: mov             x17, #0x125e
    // 0xbe4054: cmp             x3, x17
    // 0xbe4058: b.ne            #0xbe4070
    // 0xbe405c: ldur            x4, [fp, #-0x10]
    // 0xbe4060: LoadField: r0 = r4->field_63
    //     0xbe4060: ldur            w0, [x4, #0x63]
    // 0xbe4064: DecompressPointer r0
    //     0xbe4064: add             x0, x0, HEAP, lsl #32
    // 0xbe4068: mov             x3, x0
    // 0xbe406c: b               #0xbe40f0
    // 0xbe4070: ldur            x4, [fp, #-0x10]
    // 0xbe4074: LoadField: r5 = r4->field_27
    //     0xbe4074: ldur            w5, [x4, #0x27]
    // 0xbe4078: DecompressPointer r5
    //     0xbe4078: add             x5, x5, HEAP, lsl #32
    // 0xbe407c: stur            x5, [fp, #-0x50]
    // 0xbe4080: cmp             w5, NULL
    // 0xbe4084: b.eq            #0xbe456c
    // 0xbe4088: mov             x0, x5
    // 0xbe408c: r2 = Null
    //     0xbe408c: mov             x2, NULL
    // 0xbe4090: r1 = Null
    //     0xbe4090: mov             x1, NULL
    // 0xbe4094: r4 = LoadClassIdInstr(r0)
    //     0xbe4094: ldur            x4, [x0, #-1]
    //     0xbe4098: ubfx            x4, x4, #0xc, #0x14
    // 0xbe409c: cmp             x4, #0xb45
    // 0xbe40a0: b.eq            #0xbe40b8
    // 0xbe40a4: r8 = SliverConstraints
    //     0xbe40a4: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe40a8: ldr             x8, [x8, #0x3c0]
    // 0xbe40ac: r3 = Null
    //     0xbe40ac: add             x3, PP, #0xab, lsl #12  ; [pp+0xab610] Null
    //     0xbe40b0: ldr             x3, [x3, #0x610]
    // 0xbe40b4: r0 = DefaultTypeTest()
    //     0xbe40b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe40b8: ldur            x0, [fp, #-0x50]
    // 0xbe40bc: LoadField: d0 = r0->field_3f
    //     0xbe40bc: ldur            d0, [x0, #0x3f]
    // 0xbe40c0: r0 = inline_Allocate_Double()
    //     0xbe40c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe40c4: add             x0, x0, #0x10
    //     0xbe40c8: cmp             x1, x0
    //     0xbe40cc: b.ls            #0xbe4758
    //     0xbe40d0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe40d4: sub             x0, x0, #0xf
    //     0xbe40d8: mov             x1, #0xe19c
    //     0xbe40dc: movk            x1, #3, lsl #16
    //     0xbe40e0: stur            x1, [x0, #-1]
    // 0xbe40e4: dmb             ishst
    // 0xbe40e8: StoreField: r0->field_7 = d0
    //     0xbe40e8: stur            d0, [x0, #7]
    // 0xbe40ec: mov             x3, x0
    // 0xbe40f0: ldur            x2, [fp, #-0x30]
    // 0xbe40f4: ldur            x1, [fp, #-0x38]
    // 0xbe40f8: ldur            x0, [fp, #-0x58]
    // 0xbe40fc: cmp             w3, NULL
    // 0xbe4100: b.eq            #0xbe4768
    // 0xbe4104: r4 = LoadInt32Instr(r0)
    //     0xbe4104: sbfx            x4, x0, #1, #0x1f
    //     0xbe4108: tbz             w0, #0, #0xbe4110
    //     0xbe410c: ldur            x4, [x0, #7]
    // 0xbe4110: scvtf           d0, x4
    // 0xbe4114: LoadField: d1 = r3->field_7
    //     0xbe4114: ldur            d1, [x3, #7]
    // 0xbe4118: fmul            d2, d1, d0
    // 0xbe411c: r0 = inline_Allocate_Double()
    //     0xbe411c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xbe4120: add             x0, x0, #0x10
    //     0xbe4124: cmp             x3, x0
    //     0xbe4128: b.ls            #0xbe476c
    //     0xbe412c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe4130: sub             x0, x0, #0xf
    //     0xbe4134: mov             x3, #0xe19c
    //     0xbe4138: movk            x3, #3, lsl #16
    //     0xbe413c: stur            x3, [x0, #-1]
    // 0xbe4140: dmb             ishst
    // 0xbe4144: StoreField: r0->field_7 = d2
    //     0xbe4144: stur            d2, [x0, #7]
    // 0xbe4148: StoreField: r1->field_7 = r0
    //     0xbe4148: stur            w0, [x1, #7]
    //     0xbe414c: ldurb           w16, [x1, #-1]
    //     0xbe4150: ldurb           w17, [x0, #-1]
    //     0xbe4154: and             x16, x17, x16, lsr #2
    //     0xbe4158: tst             x16, HEAP, lsr #32
    //     0xbe415c: b.eq            #0xbe4164
    //     0xbe4160: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe4164: add             x8, x2, #1
    // 0xbe4168: ldur            x9, [fp, #-0x40]
    // 0xbe416c: ldur            x3, [fp, #-0x10]
    // 0xbe4170: ldur            x5, [fp, #-0x60]
    // 0xbe4174: ldur            x4, [fp, #-0x68]
    // 0xbe4178: ldur            x6, [fp, #-0x48]
    // 0xbe417c: b               #0xbe38f4
    // 0xbe4180: d1 = inf
    //     0xbe4180: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbe4184: ldur            x3, [fp, #-0x10]
    // 0xbe4188: ldur            d0, [fp, #-0x78]
    // 0xbe418c: ldur            x4, [fp, #-8]
    // 0xbe4190: stur            d1, [fp, #-0x70]
    // 0xbe4194: LoadField: r0 = r3->field_57
    //     0xbe4194: ldur            w0, [x3, #0x57]
    // 0xbe4198: DecompressPointer r0
    //     0xbe4198: add             x0, x0, HEAP, lsl #32
    // 0xbe419c: cmp             w0, NULL
    // 0xbe41a0: b.eq            #0xbe4784
    // 0xbe41a4: LoadField: r5 = r0->field_7
    //     0xbe41a4: ldur            w5, [x0, #7]
    // 0xbe41a8: DecompressPointer r5
    //     0xbe41a8: add             x5, x5, HEAP, lsl #32
    // 0xbe41ac: stur            x5, [fp, #-0x28]
    // 0xbe41b0: cmp             w5, NULL
    // 0xbe41b4: b.eq            #0xbe4788
    // 0xbe41b8: mov             x0, x5
    // 0xbe41bc: r2 = Null
    //     0xbe41bc: mov             x2, NULL
    // 0xbe41c0: r1 = Null
    //     0xbe41c0: mov             x1, NULL
    // 0xbe41c4: r4 = LoadClassIdInstr(r0)
    //     0xbe41c4: ldur            x4, [x0, #-1]
    //     0xbe41c8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe41cc: r17 = -4183
    //     0xbe41cc: mov             x17, #-0x1057
    // 0xbe41d0: add             x4, x4, x17
    // 0xbe41d4: cmp             x4, #1
    // 0xbe41d8: b.ls            #0xbe41f0
    // 0xbe41dc: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe41dc: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe41e0: ldr             x8, [x8, #0x590]
    // 0xbe41e4: r3 = Null
    //     0xbe41e4: add             x3, PP, #0xab, lsl #12  ; [pp+0xab620] Null
    //     0xbe41e8: ldr             x3, [x3, #0x620]
    // 0xbe41ec: r0 = DefaultTypeTest()
    //     0xbe41ec: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe41f0: ldur            x0, [fp, #-0x28]
    // 0xbe41f4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xbe41f4: ldur            w3, [x0, #0x17]
    // 0xbe41f8: DecompressPointer r3
    //     0xbe41f8: add             x3, x3, HEAP, lsl #32
    // 0xbe41fc: stur            x3, [fp, #-0x38]
    // 0xbe4200: cmp             w3, NULL
    // 0xbe4204: b.eq            #0xbe478c
    // 0xbe4208: ldur            x1, [fp, #-0x10]
    // 0xbe420c: ldur            x2, [fp, #-0x20]
    // 0xbe4210: d0 = -1.000000
    //     0xbe4210: fmov            d0, #-1.00000000
    // 0xbe4214: r0 = indexToLayoutOffset()
    //     0xbe4214: bl              #0xbe6288  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::indexToLayoutOffset
    // 0xbe4218: mov             v1.16b, v0.16b
    // 0xbe421c: ldur            x0, [fp, #-0x38]
    // 0xbe4220: stur            d1, [fp, #-0x80]
    // 0xbe4224: r5 = LoadInt32Instr(r0)
    //     0xbe4224: sbfx            x5, x0, #1, #0x1f
    //     0xbe4228: tbz             w0, #0, #0xbe4230
    //     0xbe422c: ldur            x5, [x0, #7]
    // 0xbe4230: stur            x5, [fp, #-0x30]
    // 0xbe4234: add             x2, x5, #1
    // 0xbe4238: ldur            x1, [fp, #-0x10]
    // 0xbe423c: d0 = -1.000000
    //     0xbe423c: fmov            d0, #-1.00000000
    // 0xbe4240: r0 = indexToLayoutOffset()
    //     0xbe4240: bl              #0xbe6288  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::indexToLayoutOffset
    // 0xbe4244: ldur            x1, [fp, #-0x10]
    // 0xbe4248: ldur            x2, [fp, #-8]
    // 0xbe424c: ldur            x3, [fp, #-0x20]
    // 0xbe4250: ldur            x5, [fp, #-0x30]
    // 0xbe4254: mov             v1.16b, v0.16b
    // 0xbe4258: mov             v2.16b, v0.16b
    // 0xbe425c: ldur            d0, [fp, #-0x80]
    // 0xbe4260: stur            d2, [fp, #-0x88]
    // 0xbe4264: r0 = estimateMaxScrollOffset()
    //     0xbe4264: bl              #0xbe48d8  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::estimateMaxScrollOffset
    // 0xbe4268: mov             v1.16b, v0.16b
    // 0xbe426c: ldur            d0, [fp, #-0x70]
    // 0xbe4270: fmin            v2.2d, v0.2d, v1.2d
    // 0xbe4274: ldur            x1, [fp, #-0x10]
    // 0xbe4278: ldur            x2, [fp, #-8]
    // 0xbe427c: ldur            d0, [fp, #-0x80]
    // 0xbe4280: ldur            d1, [fp, #-0x88]
    // 0xbe4284: stur            d2, [fp, #-0x90]
    // 0xbe4288: r0 = calculatePaintOffset()
    //     0xbe4288: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbe428c: ldur            x1, [fp, #-0x10]
    // 0xbe4290: ldur            x2, [fp, #-8]
    // 0xbe4294: mov             v2.16b, v0.16b
    // 0xbe4298: ldur            d0, [fp, #-0x80]
    // 0xbe429c: ldur            d1, [fp, #-0x88]
    // 0xbe42a0: stur            d2, [fp, #-0x70]
    // 0xbe42a4: r0 = calculateCacheOffset()
    //     0xbe42a4: bl              #0xbe4790  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0xbe42a8: mov             v2.16b, v0.16b
    // 0xbe42ac: ldur            x0, [fp, #-8]
    // 0xbe42b0: stur            d2, [fp, #-0x80]
    // 0xbe42b4: LoadField: d0 = r0->field_2b
    //     0xbe42b4: ldur            d0, [x0, #0x2b]
    // 0xbe42b8: ldur            d3, [fp, #-0x78]
    // 0xbe42bc: fadd            d1, d3, d0
    // 0xbe42c0: mov             x0, v1.d[0]
    // 0xbe42c4: and             x0, x0, #0x7fffffffffffffff
    // 0xbe42c8: r17 = 9218868437227405312
    //     0xbe42c8: mov             x17, #0x7ff0000000000000
    // 0xbe42cc: cmp             x0, x17
    // 0xbe42d0: b.eq            #0xbe4308
    // 0xbe42d4: fcmp            d1, d1
    // 0xbe42d8: b.vs            #0xbe4308
    // 0xbe42dc: ldur            x1, [fp, #-0x10]
    // 0xbe42e0: mov             v0.16b, v1.16b
    // 0xbe42e4: d1 = -1.000000
    //     0xbe42e4: fmov            d1, #-1.00000000
    // 0xbe42e8: r0 = getMaxChildIndexForScrollOffset()
    //     0xbe42e8: bl              #0xbe6f38  ; [package:flutter/src/rendering/sliver_fixed_extent_list.dart] RenderSliverFixedExtentBoxAdaptor::getMaxChildIndexForScrollOffset
    // 0xbe42ec: mov             x2, x0
    // 0xbe42f0: r0 = BoxInt64Instr(r2)
    //     0xbe42f0: sbfiz           x0, x2, #1, #0x1f
    //     0xbe42f4: cmp             x2, x0, asr #1
    //     0xbe42f8: b.eq            #0xbe4304
    //     0xbe42fc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbe4300: stur            x2, [x0, #7]
    // 0xbe4304: b               #0xbe430c
    // 0xbe4308: r0 = Null
    //     0xbe4308: mov             x0, NULL
    // 0xbe430c: cmp             w0, NULL
    // 0xbe4310: b.eq            #0xbe4338
    // 0xbe4314: ldur            x1, [fp, #-0x30]
    // 0xbe4318: r2 = LoadInt32Instr(r0)
    //     0xbe4318: sbfx            x2, x0, #1, #0x1f
    //     0xbe431c: tbz             w0, #0, #0xbe4324
    //     0xbe4320: ldur            x2, [x0, #7]
    // 0xbe4324: cmp             x1, x2
    // 0xbe4328: b.lt            #0xbe4338
    // 0xbe432c: r1 = true
    //     0xbe432c: add             x1, NULL, #0x20  ; true
    // 0xbe4330: d1 = 0.000000
    //     0xbe4330: eor             v1.16b, v1.16b, v1.16b
    // 0xbe4334: b               #0xbe4354
    // 0xbe4338: ldur            d0, [fp, #-0x78]
    // 0xbe433c: d1 = 0.000000
    //     0xbe433c: eor             v1.16b, v1.16b, v1.16b
    // 0xbe4340: fcmp            d0, d1
    // 0xbe4344: r16 = true
    //     0xbe4344: add             x16, NULL, #0x20  ; true
    // 0xbe4348: r17 = false
    //     0xbe4348: add             x17, NULL, #0x30  ; false
    // 0xbe434c: csel            x0, x16, x17, gt
    // 0xbe4350: mov             x1, x0
    // 0xbe4354: ldur            x0, [fp, #-0x10]
    // 0xbe4358: ldur            d4, [fp, #-0x88]
    // 0xbe435c: ldur            d2, [fp, #-0x70]
    // 0xbe4360: ldur            d0, [fp, #-0x80]
    // 0xbe4364: ldur            d3, [fp, #-0x90]
    // 0xbe4368: stur            x1, [fp, #-8]
    // 0xbe436c: r0 = SliverGeometry()
    //     0xbe436c: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe4370: ldur            d0, [fp, #-0x90]
    // 0xbe4374: StoreField: r0->field_7 = d0
    //     0xbe4374: stur            d0, [x0, #7]
    // 0xbe4378: ldur            d1, [fp, #-0x70]
    // 0xbe437c: ArrayStore: r0[0] = d1  ; List_8
    //     0xbe437c: stur            d1, [x0, #0x17]
    // 0xbe4380: StoreField: r0->field_f = rZR
    //     0xbe4380: stur            xzr, [x0, #0xf]
    // 0xbe4384: StoreField: r0->field_27 = d0
    //     0xbe4384: stur            d0, [x0, #0x27]
    // 0xbe4388: StoreField: r0->field_2f = rZR
    //     0xbe4388: stur            xzr, [x0, #0x2f]
    // 0xbe438c: ldur            x1, [fp, #-8]
    // 0xbe4390: StoreField: r0->field_43 = r1
    //     0xbe4390: stur            w1, [x0, #0x43]
    // 0xbe4394: StoreField: r0->field_1f = d1
    //     0xbe4394: stur            d1, [x0, #0x1f]
    // 0xbe4398: StoreField: r0->field_37 = d1
    //     0xbe4398: stur            d1, [x0, #0x37]
    // 0xbe439c: ldur            d2, [fp, #-0x80]
    // 0xbe43a0: StoreField: r0->field_4b = d2
    //     0xbe43a0: stur            d2, [x0, #0x4b]
    // 0xbe43a4: d2 = 0.000000
    //     0xbe43a4: eor             v2.16b, v2.16b, v2.16b
    // 0xbe43a8: fcmp            d1, d2
    // 0xbe43ac: r16 = true
    //     0xbe43ac: add             x16, NULL, #0x20  ; true
    // 0xbe43b0: r17 = false
    //     0xbe43b0: add             x17, NULL, #0x30  ; false
    // 0xbe43b4: csel            x1, x16, x17, gt
    // 0xbe43b8: StoreField: r0->field_3f = r1
    //     0xbe43b8: stur            w1, [x0, #0x3f]
    // 0xbe43bc: ldur            x1, [fp, #-0x10]
    // 0xbe43c0: StoreField: r1->field_47 = r0
    //     0xbe43c0: stur            w0, [x1, #0x47]
    //     0xbe43c4: ldurb           w16, [x1, #-1]
    //     0xbe43c8: ldurb           w17, [x0, #-1]
    //     0xbe43cc: and             x16, x17, x16, lsr #2
    //     0xbe43d0: tst             x16, HEAP, lsr #32
    //     0xbe43d4: b.eq            #0xbe43dc
    //     0xbe43d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe43dc: ldur            d1, [fp, #-0x88]
    // 0xbe43e0: fcmp            d0, d1
    // 0xbe43e4: b.ne            #0xbe43f8
    // 0xbe43e8: ldur            x1, [fp, #-0x18]
    // 0xbe43ec: r0 = true
    //     0xbe43ec: add             x0, NULL, #0x20  ; true
    // 0xbe43f0: StoreField: r1->field_53 = r0
    //     0xbe43f0: stur            w0, [x1, #0x53]
    // 0xbe43f4: b               #0xbe43fc
    // 0xbe43f8: ldur            x1, [fp, #-0x18]
    // 0xbe43fc: r0 = didFinishLayout()
    //     0xbe43fc: bl              #0xbe5ab0  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0xbe4400: r0 = Null
    //     0xbe4400: mov             x0, NULL
    // 0xbe4404: LeaveFrame
    //     0xbe4404: mov             SP, fp
    //     0xbe4408: ldp             fp, lr, [SP], #0x10
    // 0xbe440c: ret
    //     0xbe440c: ret             
    // 0xbe4410: r0 = StateError()
    //     0xbe4410: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4414: mov             x1, x0
    // 0xbe4418: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4418: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe441c: StoreField: r1->field_b = r0
    //     0xbe441c: stur            w0, [x1, #0xb]
    // 0xbe4420: mov             x0, x1
    // 0xbe4424: r0 = Throw()
    //     0xbe4424: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4428: brk             #0
    // 0xbe442c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe442c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4430: r0 = StateError()
    //     0xbe4430: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4434: mov             x1, x0
    // 0xbe4438: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4438: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe443c: StoreField: r1->field_b = r0
    //     0xbe443c: stur            w0, [x1, #0xb]
    // 0xbe4440: mov             x0, x1
    // 0xbe4444: r0 = Throw()
    //     0xbe4444: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4448: brk             #0
    // 0xbe444c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe444c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4450: r0 = StateError()
    //     0xbe4450: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4454: mov             x1, x0
    // 0xbe4458: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4458: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe445c: StoreField: r1->field_b = r0
    //     0xbe445c: stur            w0, [x1, #0xb]
    // 0xbe4460: mov             x0, x1
    // 0xbe4464: r0 = Throw()
    //     0xbe4464: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4468: brk             #0
    // 0xbe446c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe446c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4470: r0 = StateError()
    //     0xbe4470: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4474: mov             x1, x0
    // 0xbe4478: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4478: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe447c: StoreField: r1->field_b = r0
    //     0xbe447c: stur            w0, [x1, #0xb]
    // 0xbe4480: mov             x0, x1
    // 0xbe4484: r0 = Throw()
    //     0xbe4484: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4488: brk             #0
    // 0xbe448c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe448c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4490: r0 = StateError()
    //     0xbe4490: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4494: mov             x1, x0
    // 0xbe4498: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4498: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe449c: StoreField: r1->field_b = r0
    //     0xbe449c: stur            w0, [x1, #0xb]
    // 0xbe44a0: mov             x0, x1
    // 0xbe44a4: r0 = Throw()
    //     0xbe44a4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe44a8: brk             #0
    // 0xbe44ac: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe44ac: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe44b0: r0 = StateError()
    //     0xbe44b0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe44b4: mov             x1, x0
    // 0xbe44b8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe44b8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe44bc: StoreField: r1->field_b = r0
    //     0xbe44bc: stur            w0, [x1, #0xb]
    // 0xbe44c0: mov             x0, x1
    // 0xbe44c4: r0 = Throw()
    //     0xbe44c4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe44c8: brk             #0
    // 0xbe44cc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe44cc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe44d0: r0 = StateError()
    //     0xbe44d0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe44d4: mov             x1, x0
    // 0xbe44d8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe44d8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe44dc: StoreField: r1->field_b = r0
    //     0xbe44dc: stur            w0, [x1, #0xb]
    // 0xbe44e0: mov             x0, x1
    // 0xbe44e4: r0 = Throw()
    //     0xbe44e4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe44e8: brk             #0
    // 0xbe44ec: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe44ec: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe44f0: r0 = StateError()
    //     0xbe44f0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe44f4: mov             x1, x0
    // 0xbe44f8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe44f8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe44fc: StoreField: r1->field_b = r0
    //     0xbe44fc: stur            w0, [x1, #0xb]
    // 0xbe4500: mov             x0, x1
    // 0xbe4504: r0 = Throw()
    //     0xbe4504: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4508: brk             #0
    // 0xbe450c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe450c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4510: r0 = StateError()
    //     0xbe4510: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4514: mov             x1, x0
    // 0xbe4518: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4518: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe451c: StoreField: r1->field_b = r0
    //     0xbe451c: stur            w0, [x1, #0xb]
    // 0xbe4520: mov             x0, x1
    // 0xbe4524: r0 = Throw()
    //     0xbe4524: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4528: brk             #0
    // 0xbe452c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe452c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4530: r0 = StateError()
    //     0xbe4530: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4534: mov             x1, x0
    // 0xbe4538: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4538: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe453c: StoreField: r1->field_b = r0
    //     0xbe453c: stur            w0, [x1, #0xb]
    // 0xbe4540: mov             x0, x1
    // 0xbe4544: r0 = Throw()
    //     0xbe4544: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4548: brk             #0
    // 0xbe454c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe454c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4550: r0 = StateError()
    //     0xbe4550: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4554: mov             x1, x0
    // 0xbe4558: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4558: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe455c: StoreField: r1->field_b = r0
    //     0xbe455c: stur            w0, [x1, #0xb]
    // 0xbe4560: mov             x0, x1
    // 0xbe4564: r0 = Throw()
    //     0xbe4564: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4568: brk             #0
    // 0xbe456c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe456c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4570: r0 = StateError()
    //     0xbe4570: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4574: mov             x1, x0
    // 0xbe4578: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4578: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe457c: StoreField: r1->field_b = r0
    //     0xbe457c: stur            w0, [x1, #0xb]
    // 0xbe4580: mov             x0, x1
    // 0xbe4584: r0 = Throw()
    //     0xbe4584: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe4588: brk             #0
    // 0xbe458c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe458c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe4590: r0 = StateError()
    //     0xbe4590: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe4594: mov             x1, x0
    // 0xbe4598: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe4598: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe459c: StoreField: r1->field_b = r0
    //     0xbe459c: stur            w0, [x1, #0xb]
    // 0xbe45a0: mov             x0, x1
    // 0xbe45a4: r0 = Throw()
    //     0xbe45a4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe45a8: brk             #0
    // 0xbe45ac: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe45ac: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe45b0: r0 = StateError()
    //     0xbe45b0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe45b4: mov             x1, x0
    // 0xbe45b8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe45b8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe45bc: StoreField: r1->field_b = r0
    //     0xbe45bc: stur            w0, [x1, #0xb]
    // 0xbe45c0: mov             x0, x1
    // 0xbe45c4: r0 = Throw()
    //     0xbe45c4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe45c8: brk             #0
    // 0xbe45cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe45cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe45d0: b               #0xbe2de0
    // 0xbe45d4: SaveReg d0
    //     0xbe45d4: str             q0, [SP, #-0x10]!
    // 0xbe45d8: stp             x0, x2, [SP, #-0x10]!
    // 0xbe45dc: r0 = AllocateDouble()
    //     0xbe45dc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe45e0: mov             x1, x0
    // 0xbe45e4: ldp             x0, x2, [SP], #0x10
    // 0xbe45e8: RestoreReg d0
    //     0xbe45e8: ldr             q0, [SP], #0x10
    // 0xbe45ec: b               #0xbe2fa0
    // 0xbe45f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe45f0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe45f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe45f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe45f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe45f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe45fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe45fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe4600: b               #0xbe3138
    // 0xbe4604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4604: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4608: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4608: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe460c: SaveReg d0
    //     0xbe460c: str             q0, [SP, #-0x10]!
    // 0xbe4610: r0 = AllocateDouble()
    //     0xbe4610: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4614: RestoreReg d0
    //     0xbe4614: ldr             q0, [SP], #0x10
    // 0xbe4618: b               #0xbe3224
    // 0xbe461c: SaveReg d0
    //     0xbe461c: str             q0, [SP, #-0x10]!
    // 0xbe4620: r0 = AllocateDouble()
    //     0xbe4620: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4624: RestoreReg d0
    //     0xbe4624: ldr             q0, [SP], #0x10
    // 0xbe4628: b               #0xbe32ec
    // 0xbe462c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe462c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4630: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4634: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4634: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4638: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4638: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe463c: SaveReg d0
    //     0xbe463c: str             q0, [SP, #-0x10]!
    // 0xbe4640: r0 = AllocateDouble()
    //     0xbe4640: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4644: RestoreReg d0
    //     0xbe4644: ldr             q0, [SP], #0x10
    // 0xbe4648: b               #0xbe34c0
    // 0xbe464c: SaveReg d0
    //     0xbe464c: str             q0, [SP, #-0x10]!
    // 0xbe4650: r0 = AllocateDouble()
    //     0xbe4650: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4654: RestoreReg d0
    //     0xbe4654: ldr             q0, [SP], #0x10
    // 0xbe4658: b               #0xbe3570
    // 0xbe465c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe465c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4660: SaveReg d2
    //     0xbe4660: str             q2, [SP, #-0x10]!
    // 0xbe4664: stp             x2, x3, [SP, #-0x10]!
    // 0xbe4668: SaveReg r1
    //     0xbe4668: str             x1, [SP, #-8]!
    // 0xbe466c: r0 = AllocateDouble()
    //     0xbe466c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4670: RestoreReg r1
    //     0xbe4670: ldr             x1, [SP], #8
    // 0xbe4674: ldp             x2, x3, [SP], #0x10
    // 0xbe4678: RestoreReg d2
    //     0xbe4678: ldr             q2, [SP], #0x10
    // 0xbe467c: b               #0xbe35bc
    // 0xbe4680: SaveReg d0
    //     0xbe4680: str             q0, [SP, #-0x10]!
    // 0xbe4684: SaveReg r0
    //     0xbe4684: str             x0, [SP, #-8]!
    // 0xbe4688: r0 = AllocateDouble()
    //     0xbe4688: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe468c: mov             x1, x0
    // 0xbe4690: RestoreReg r0
    //     0xbe4690: ldr             x0, [SP], #8
    // 0xbe4694: RestoreReg d0
    //     0xbe4694: ldr             q0, [SP], #0x10
    // 0xbe4698: b               #0xbe3664
    // 0xbe469c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe469c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe46a0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe46a0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe46a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46b0: SaveReg d0
    //     0xbe46b0: str             q0, [SP, #-0x10]!
    // 0xbe46b4: r0 = AllocateDouble()
    //     0xbe46b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe46b8: RestoreReg d0
    //     0xbe46b8: ldr             q0, [SP], #0x10
    // 0xbe46bc: b               #0xbe3814
    // 0xbe46c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe46cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe46d0: b               #0xbe390c
    // 0xbe46d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe46e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe46e8: SaveReg d0
    //     0xbe46e8: str             q0, [SP, #-0x10]!
    // 0xbe46ec: r0 = AllocateDouble()
    //     0xbe46ec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe46f0: RestoreReg d0
    //     0xbe46f0: ldr             q0, [SP], #0x10
    // 0xbe46f4: b               #0xbe3afc
    // 0xbe46f8: SaveReg d0
    //     0xbe46f8: str             q0, [SP, #-0x10]!
    // 0xbe46fc: r0 = AllocateDouble()
    //     0xbe46fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4700: RestoreReg d0
    //     0xbe4700: ldr             q0, [SP], #0x10
    // 0xbe4704: b               #0xbe3bc4
    // 0xbe4708: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4708: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe470c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe470c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4710: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4714: SaveReg d0
    //     0xbe4714: str             q0, [SP, #-0x10]!
    // 0xbe4718: r0 = AllocateDouble()
    //     0xbe4718: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe471c: RestoreReg d0
    //     0xbe471c: ldr             q0, [SP], #0x10
    // 0xbe4720: b               #0xbe3d64
    // 0xbe4724: SaveReg d0
    //     0xbe4724: str             q0, [SP, #-0x10]!
    // 0xbe4728: r0 = AllocateDouble()
    //     0xbe4728: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe472c: RestoreReg d0
    //     0xbe472c: ldr             q0, [SP], #0x10
    // 0xbe4730: b               #0xbe3e28
    // 0xbe4734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4734: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4738: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4738: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe473c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe473c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4740: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4740: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4744: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4748: SaveReg d0
    //     0xbe4748: str             q0, [SP, #-0x10]!
    // 0xbe474c: r0 = AllocateDouble()
    //     0xbe474c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4750: RestoreReg d0
    //     0xbe4750: ldr             q0, [SP], #0x10
    // 0xbe4754: b               #0xbe402c
    // 0xbe4758: SaveReg d0
    //     0xbe4758: str             q0, [SP, #-0x10]!
    // 0xbe475c: r0 = AllocateDouble()
    //     0xbe475c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4760: RestoreReg d0
    //     0xbe4760: ldr             q0, [SP], #0x10
    // 0xbe4764: b               #0xbe40e8
    // 0xbe4768: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4768: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe476c: SaveReg d2
    //     0xbe476c: str             q2, [SP, #-0x10]!
    // 0xbe4770: stp             x1, x2, [SP, #-0x10]!
    // 0xbe4774: r0 = AllocateDouble()
    //     0xbe4774: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4778: ldp             x1, x2, [SP], #0x10
    // 0xbe477c: RestoreReg d2
    //     0xbe477c: ldr             q2, [SP], #0x10
    // 0xbe4780: b               #0xbe4144
    // 0xbe4784: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe4784: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe4788: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe4788: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe478c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe478c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ estimateMaxScrollOffset(/* No info */) {
    // ** addr: 0xbe48d8, size: 0x94
    // 0xbe48d8: EnterFrame
    //     0xbe48d8: stp             fp, lr, [SP, #-0x10]!
    //     0xbe48dc: mov             fp, SP
    // 0xbe48e0: mov             v31.16b, v1.16b
    // 0xbe48e4: mov             v1.16b, v0.16b
    // 0xbe48e8: mov             v0.16b, v31.16b
    // 0xbe48ec: CheckStackOverflow
    //     0xbe48ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe48f0: cmp             SP, x16
    //     0xbe48f4: b.ls            #0xbe4940
    // 0xbe48f8: LoadField: r0 = r1->field_5b
    //     0xbe48f8: ldur            w0, [x1, #0x5b]
    // 0xbe48fc: DecompressPointer r0
    //     0xbe48fc: add             x0, x0, HEAP, lsl #32
    // 0xbe4900: r6 = inline_Allocate_Double()
    //     0xbe4900: ldp             x6, x1, [THR, #0x60]  ; THR::top
    //     0xbe4904: add             x6, x6, #0x10
    //     0xbe4908: cmp             x1, x6
    //     0xbe490c: b.ls            #0xbe4948
    //     0xbe4910: str             x6, [THR, #0x60]  ; THR::top
    //     0xbe4914: sub             x6, x6, #0xf
    //     0xbe4918: mov             x1, #0xe19c
    //     0xbe491c: movk            x1, #3, lsl #16
    //     0xbe4920: stur            x1, [x6, #-1]
    // 0xbe4924: dmb             ishst
    // 0xbe4928: StoreField: r6->field_7 = d1
    //     0xbe4928: stur            d1, [x6, #7]
    // 0xbe492c: mov             x1, x0
    // 0xbe4930: r0 = estimateMaxScrollOffset()
    //     0xbe4930: bl              #0xbe496c  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::estimateMaxScrollOffset
    // 0xbe4934: LeaveFrame
    //     0xbe4934: mov             SP, fp
    //     0xbe4938: ldp             fp, lr, [SP], #0x10
    // 0xbe493c: ret
    //     0xbe493c: ret             
    // 0xbe4940: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe4940: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe4944: b               #0xbe48f8
    // 0xbe4948: stp             q0, q1, [SP, #-0x20]!
    // 0xbe494c: stp             x3, x5, [SP, #-0x10]!
    // 0xbe4950: stp             x0, x2, [SP, #-0x10]!
    // 0xbe4954: r0 = AllocateDouble()
    //     0xbe4954: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe4958: mov             x6, x0
    // 0xbe495c: ldp             x0, x2, [SP], #0x10
    // 0xbe4960: ldp             x3, x5, [SP], #0x10
    // 0xbe4964: ldp             q0, q1, [SP], #0x20
    // 0xbe4968: b               #0xbe4928
  }
  _ _getChildConstraints(/* No info */) {
    // ** addr: 0xbe53ac, size: 0x2e8
    // 0xbe53ac: EnterFrame
    //     0xbe53ac: stp             fp, lr, [SP, #-0x10]!
    //     0xbe53b0: mov             fp, SP
    // 0xbe53b4: AllocStack(0x28)
    //     0xbe53b4: sub             SP, SP, #0x28
    // 0xbe53b8: SetupParameters(RenderSliverFixedExtentBoxAdaptor this /* r1 => r3, fp-0x10 */)
    //     0xbe53b8: mov             x3, x1
    //     0xbe53bc: stur            x1, [fp, #-0x10]
    // 0xbe53c0: CheckStackOverflow
    //     0xbe53c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe53c4: cmp             SP, x16
    //     0xbe53c8: b.ls            #0xbe5660
    // 0xbe53cc: r0 = LoadClassIdInstr(r3)
    //     0xbe53cc: ldur            x0, [x3, #-1]
    //     0xbe53d0: ubfx            x0, x0, #0xc, #0x14
    // 0xbe53d4: r17 = -4702
    //     0xbe53d4: mov             x17, #-0x125e
    // 0xbe53d8: add             x16, x0, x17
    // 0xbe53dc: cmp             x16, #1
    // 0xbe53e0: b.ls            #0xbe53f0
    // 0xbe53e4: r17 = 4700
    //     0xbe53e4: mov             x17, #0x125c
    // 0xbe53e8: cmp             x0, x17
    // 0xbe53ec: b.eq            #0xbe53f0
    // 0xbe53f0: r17 = 4700
    //     0xbe53f0: mov             x17, #0x125c
    // 0xbe53f4: cmp             x0, x17
    // 0xbe53f8: b.ne            #0xbe54c8
    // 0xbe53fc: LoadField: r4 = r3->field_27
    //     0xbe53fc: ldur            w4, [x3, #0x27]
    // 0xbe5400: DecompressPointer r4
    //     0xbe5400: add             x4, x4, HEAP, lsl #32
    // 0xbe5404: stur            x4, [fp, #-8]
    // 0xbe5408: cmp             w4, NULL
    // 0xbe540c: b.eq            #0xbe5604
    // 0xbe5410: mov             x0, x4
    // 0xbe5414: r2 = Null
    //     0xbe5414: mov             x2, NULL
    // 0xbe5418: r1 = Null
    //     0xbe5418: mov             x1, NULL
    // 0xbe541c: r4 = LoadClassIdInstr(r0)
    //     0xbe541c: ldur            x4, [x0, #-1]
    //     0xbe5420: ubfx            x4, x4, #0xc, #0x14
    // 0xbe5424: cmp             x4, #0xb45
    // 0xbe5428: b.eq            #0xbe5440
    // 0xbe542c: r8 = SliverConstraints
    //     0xbe542c: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe5430: ldr             x8, [x8, #0x3c0]
    // 0xbe5434: r3 = Null
    //     0xbe5434: add             x3, PP, #0xab, lsl #12  ; [pp+0xab630] Null
    //     0xbe5438: ldr             x3, [x3, #0x630]
    // 0xbe543c: r0 = DefaultTypeTest()
    //     0xbe543c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe5440: ldur            x1, [fp, #-8]
    // 0xbe5444: r0 = axis()
    //     0xbe5444: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe5448: r16 = Instance_Axis
    //     0xbe5448: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe544c: cmp             w0, w16
    // 0xbe5450: b.ne            #0xbe5474
    // 0xbe5454: ldur            x0, [fp, #-0x10]
    // 0xbe5458: LoadField: r1 = r0->field_63
    //     0xbe5458: ldur            w1, [x0, #0x63]
    // 0xbe545c: DecompressPointer r1
    //     0xbe545c: add             x1, x1, HEAP, lsl #32
    // 0xbe5460: cmp             w1, NULL
    // 0xbe5464: b.eq            #0xbe5668
    // 0xbe5468: r0 = size()
    //     0xbe5468: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe546c: LoadField: d0 = r0->field_f
    //     0xbe546c: ldur            d0, [x0, #0xf]
    // 0xbe5470: b               #0xbe5490
    // 0xbe5474: ldur            x0, [fp, #-0x10]
    // 0xbe5478: LoadField: r1 = r0->field_63
    //     0xbe5478: ldur            w1, [x0, #0x63]
    // 0xbe547c: DecompressPointer r1
    //     0xbe547c: add             x1, x1, HEAP, lsl #32
    // 0xbe5480: cmp             w1, NULL
    // 0xbe5484: b.eq            #0xbe566c
    // 0xbe5488: r0 = size()
    //     0xbe5488: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe548c: LoadField: d0 = r0->field_7
    //     0xbe548c: ldur            d0, [x0, #7]
    // 0xbe5490: r0 = inline_Allocate_Double()
    //     0xbe5490: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe5494: add             x0, x0, #0x10
    //     0xbe5498: cmp             x1, x0
    //     0xbe549c: b.ls            #0xbe5670
    //     0xbe54a0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe54a4: sub             x0, x0, #0xf
    //     0xbe54a8: mov             x1, #0xe19c
    //     0xbe54ac: movk            x1, #3, lsl #16
    //     0xbe54b0: stur            x1, [x0, #-1]
    // 0xbe54b4: dmb             ishst
    // 0xbe54b8: StoreField: r0->field_7 = d0
    //     0xbe54b8: stur            d0, [x0, #7]
    // 0xbe54bc: mov             x3, x0
    // 0xbe54c0: ldur            x0, [fp, #-0x10]
    // 0xbe54c4: b               #0xbe558c
    // 0xbe54c8: r17 = 4701
    //     0xbe54c8: mov             x17, #0x125d
    // 0xbe54cc: cmp             x0, x17
    // 0xbe54d0: b.ne            #0xbe54e0
    // 0xbe54d4: ldur            x0, [fp, #-0x10]
    // 0xbe54d8: r3 = Null
    //     0xbe54d8: mov             x3, NULL
    // 0xbe54dc: b               #0xbe558c
    // 0xbe54e0: r17 = 4702
    //     0xbe54e0: mov             x17, #0x125e
    // 0xbe54e4: cmp             x0, x17
    // 0xbe54e8: b.ne            #0xbe5508
    // 0xbe54ec: ldur            x3, [fp, #-0x10]
    // 0xbe54f0: LoadField: r0 = r3->field_63
    //     0xbe54f0: ldur            w0, [x3, #0x63]
    // 0xbe54f4: DecompressPointer r0
    //     0xbe54f4: add             x0, x0, HEAP, lsl #32
    // 0xbe54f8: mov             x16, x3
    // 0xbe54fc: mov             x3, x0
    // 0xbe5500: mov             x0, x16
    // 0xbe5504: b               #0xbe558c
    // 0xbe5508: ldur            x3, [fp, #-0x10]
    // 0xbe550c: LoadField: r4 = r3->field_27
    //     0xbe550c: ldur            w4, [x3, #0x27]
    // 0xbe5510: DecompressPointer r4
    //     0xbe5510: add             x4, x4, HEAP, lsl #32
    // 0xbe5514: stur            x4, [fp, #-8]
    // 0xbe5518: cmp             w4, NULL
    // 0xbe551c: b.eq            #0xbe5620
    // 0xbe5520: mov             x0, x4
    // 0xbe5524: r2 = Null
    //     0xbe5524: mov             x2, NULL
    // 0xbe5528: r1 = Null
    //     0xbe5528: mov             x1, NULL
    // 0xbe552c: r4 = LoadClassIdInstr(r0)
    //     0xbe552c: ldur            x4, [x0, #-1]
    //     0xbe5530: ubfx            x4, x4, #0xc, #0x14
    // 0xbe5534: cmp             x4, #0xb45
    // 0xbe5538: b.eq            #0xbe5550
    // 0xbe553c: r8 = SliverConstraints
    //     0xbe553c: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe5540: ldr             x8, [x8, #0x3c0]
    // 0xbe5544: r3 = Null
    //     0xbe5544: add             x3, PP, #0xab, lsl #12  ; [pp+0xab640] Null
    //     0xbe5548: ldr             x3, [x3, #0x640]
    // 0xbe554c: r0 = DefaultTypeTest()
    //     0xbe554c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe5550: ldur            x0, [fp, #-8]
    // 0xbe5554: LoadField: d0 = r0->field_3f
    //     0xbe5554: ldur            d0, [x0, #0x3f]
    // 0xbe5558: r0 = inline_Allocate_Double()
    //     0xbe5558: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe555c: add             x0, x0, #0x10
    //     0xbe5560: cmp             x1, x0
    //     0xbe5564: b.ls            #0xbe5680
    //     0xbe5568: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe556c: sub             x0, x0, #0xf
    //     0xbe5570: mov             x1, #0xe19c
    //     0xbe5574: movk            x1, #3, lsl #16
    //     0xbe5578: stur            x1, [x0, #-1]
    // 0xbe557c: dmb             ishst
    // 0xbe5580: StoreField: r0->field_7 = d0
    //     0xbe5580: stur            d0, [x0, #7]
    // 0xbe5584: mov             x3, x0
    // 0xbe5588: ldur            x0, [fp, #-0x10]
    // 0xbe558c: stur            x3, [fp, #-0x18]
    // 0xbe5590: cmp             w3, NULL
    // 0xbe5594: b.eq            #0xbe5690
    // 0xbe5598: LoadField: r4 = r0->field_27
    //     0xbe5598: ldur            w4, [x0, #0x27]
    // 0xbe559c: DecompressPointer r4
    //     0xbe559c: add             x4, x4, HEAP, lsl #32
    // 0xbe55a0: stur            x4, [fp, #-8]
    // 0xbe55a4: cmp             w4, NULL
    // 0xbe55a8: b.eq            #0xbe5640
    // 0xbe55ac: mov             x0, x4
    // 0xbe55b0: r2 = Null
    //     0xbe55b0: mov             x2, NULL
    // 0xbe55b4: r1 = Null
    //     0xbe55b4: mov             x1, NULL
    // 0xbe55b8: r4 = LoadClassIdInstr(r0)
    //     0xbe55b8: ldur            x4, [x0, #-1]
    //     0xbe55bc: ubfx            x4, x4, #0xc, #0x14
    // 0xbe55c0: cmp             x4, #0xb45
    // 0xbe55c4: b.eq            #0xbe55dc
    // 0xbe55c8: r8 = SliverConstraints
    //     0xbe55c8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe55cc: ldr             x8, [x8, #0x3c0]
    // 0xbe55d0: r3 = Null
    //     0xbe55d0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab650] Null
    //     0xbe55d4: ldr             x3, [x3, #0x650]
    // 0xbe55d8: r0 = DefaultTypeTest()
    //     0xbe55d8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe55dc: ldur            x16, [fp, #-0x18]
    // 0xbe55e0: ldur            lr, [fp, #-0x18]
    // 0xbe55e4: stp             lr, x16, [SP]
    // 0xbe55e8: ldur            x1, [fp, #-8]
    // 0xbe55ec: r4 = const [0, 0x3, 0x2, 0x1, maxExtent, 0x2, minExtent, 0x1, null]
    //     0xbe55ec: add             x4, PP, #0xab, lsl #12  ; [pp+0xab508] List(9) [0, 0x3, 0x2, 0x1, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0xbe55f0: ldr             x4, [x4, #0x508]
    // 0xbe55f4: r0 = asBoxConstraints()
    //     0xbe55f4: bl              #0xbe58b0  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0xbe55f8: LeaveFrame
    //     0xbe55f8: mov             SP, fp
    //     0xbe55fc: ldp             fp, lr, [SP], #0x10
    // 0xbe5600: ret
    //     0xbe5600: ret             
    // 0xbe5604: r0 = StateError()
    //     0xbe5604: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe5608: mov             x1, x0
    // 0xbe560c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe560c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe5610: StoreField: r1->field_b = r0
    //     0xbe5610: stur            w0, [x1, #0xb]
    // 0xbe5614: mov             x0, x1
    // 0xbe5618: r0 = Throw()
    //     0xbe5618: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe561c: brk             #0
    // 0xbe5620: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe5620: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe5624: r0 = StateError()
    //     0xbe5624: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe5628: mov             x1, x0
    // 0xbe562c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe562c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe5630: StoreField: r1->field_b = r0
    //     0xbe5630: stur            w0, [x1, #0xb]
    // 0xbe5634: mov             x0, x1
    // 0xbe5638: r0 = Throw()
    //     0xbe5638: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe563c: brk             #0
    // 0xbe5640: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe5640: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe5644: r0 = StateError()
    //     0xbe5644: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe5648: mov             x1, x0
    // 0xbe564c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe564c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe5650: StoreField: r1->field_b = r0
    //     0xbe5650: stur            w0, [x1, #0xb]
    // 0xbe5654: mov             x0, x1
    // 0xbe5658: r0 = Throw()
    //     0xbe5658: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe565c: brk             #0
    // 0xbe5660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe5660: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe5664: b               #0xbe53cc
    // 0xbe5668: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5668: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe566c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe566c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe5670: SaveReg d0
    //     0xbe5670: str             q0, [SP, #-0x10]!
    // 0xbe5674: r0 = AllocateDouble()
    //     0xbe5674: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe5678: RestoreReg d0
    //     0xbe5678: ldr             q0, [SP], #0x10
    // 0xbe567c: b               #0xbe54b8
    // 0xbe5680: SaveReg d0
    //     0xbe5680: str             q0, [SP, #-0x10]!
    // 0xbe5684: r0 = AllocateDouble()
    //     0xbe5684: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe5688: RestoreReg d0
    //     0xbe5688: ldr             q0, [SP], #0x10
    // 0xbe568c: b               #0xbe5580
    // 0xbe5690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5690: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeMaxScrollOffset(/* No info */) {
    // ** addr: 0xbe5be8, size: 0x284
    // 0xbe5be8: EnterFrame
    //     0xbe5be8: stp             fp, lr, [SP, #-0x10]!
    //     0xbe5bec: mov             fp, SP
    // 0xbe5bf0: AllocStack(0x10)
    //     0xbe5bf0: sub             SP, SP, #0x10
    // 0xbe5bf4: SetupParameters(RenderSliverFixedExtentBoxAdaptor this /* r1 => r3, fp-0x10 */)
    //     0xbe5bf4: mov             x3, x1
    //     0xbe5bf8: stur            x1, [fp, #-0x10]
    // 0xbe5bfc: CheckStackOverflow
    //     0xbe5bfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe5c00: cmp             SP, x16
    //     0xbe5c04: b.ls            #0xbe5e38
    // 0xbe5c08: r0 = LoadClassIdInstr(r3)
    //     0xbe5c08: ldur            x0, [x3, #-1]
    //     0xbe5c0c: ubfx            x0, x0, #0xc, #0x14
    // 0xbe5c10: r17 = -4702
    //     0xbe5c10: mov             x17, #-0x125e
    // 0xbe5c14: add             x16, x0, x17
    // 0xbe5c18: cmp             x16, #1
    // 0xbe5c1c: b.ls            #0xbe5c2c
    // 0xbe5c20: r17 = 4700
    //     0xbe5c20: mov             x17, #0x125c
    // 0xbe5c24: cmp             x0, x17
    // 0xbe5c28: b.eq            #0xbe5c2c
    // 0xbe5c2c: r17 = 4700
    //     0xbe5c2c: mov             x17, #0x125c
    // 0xbe5c30: cmp             x0, x17
    // 0xbe5c34: b.ne            #0xbe5d04
    // 0xbe5c38: LoadField: r4 = r3->field_27
    //     0xbe5c38: ldur            w4, [x3, #0x27]
    // 0xbe5c3c: DecompressPointer r4
    //     0xbe5c3c: add             x4, x4, HEAP, lsl #32
    // 0xbe5c40: stur            x4, [fp, #-8]
    // 0xbe5c44: cmp             w4, NULL
    // 0xbe5c48: b.eq            #0xbe5dfc
    // 0xbe5c4c: mov             x0, x4
    // 0xbe5c50: r2 = Null
    //     0xbe5c50: mov             x2, NULL
    // 0xbe5c54: r1 = Null
    //     0xbe5c54: mov             x1, NULL
    // 0xbe5c58: r4 = LoadClassIdInstr(r0)
    //     0xbe5c58: ldur            x4, [x0, #-1]
    //     0xbe5c5c: ubfx            x4, x4, #0xc, #0x14
    // 0xbe5c60: cmp             x4, #0xb45
    // 0xbe5c64: b.eq            #0xbe5c7c
    // 0xbe5c68: r8 = SliverConstraints
    //     0xbe5c68: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe5c6c: ldr             x8, [x8, #0x3c0]
    // 0xbe5c70: r3 = Null
    //     0xbe5c70: add             x3, PP, #0xab, lsl #12  ; [pp+0xab660] Null
    //     0xbe5c74: ldr             x3, [x3, #0x660]
    // 0xbe5c78: r0 = DefaultTypeTest()
    //     0xbe5c78: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe5c7c: ldur            x1, [fp, #-8]
    // 0xbe5c80: r0 = axis()
    //     0xbe5c80: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe5c84: r16 = Instance_Axis
    //     0xbe5c84: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe5c88: cmp             w0, w16
    // 0xbe5c8c: b.ne            #0xbe5cb0
    // 0xbe5c90: ldur            x0, [fp, #-0x10]
    // 0xbe5c94: LoadField: r1 = r0->field_63
    //     0xbe5c94: ldur            w1, [x0, #0x63]
    // 0xbe5c98: DecompressPointer r1
    //     0xbe5c98: add             x1, x1, HEAP, lsl #32
    // 0xbe5c9c: cmp             w1, NULL
    // 0xbe5ca0: b.eq            #0xbe5e40
    // 0xbe5ca4: r0 = size()
    //     0xbe5ca4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe5ca8: LoadField: d0 = r0->field_f
    //     0xbe5ca8: ldur            d0, [x0, #0xf]
    // 0xbe5cac: b               #0xbe5ccc
    // 0xbe5cb0: ldur            x0, [fp, #-0x10]
    // 0xbe5cb4: LoadField: r1 = r0->field_63
    //     0xbe5cb4: ldur            w1, [x0, #0x63]
    // 0xbe5cb8: DecompressPointer r1
    //     0xbe5cb8: add             x1, x1, HEAP, lsl #32
    // 0xbe5cbc: cmp             w1, NULL
    // 0xbe5cc0: b.eq            #0xbe5e44
    // 0xbe5cc4: r0 = size()
    //     0xbe5cc4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe5cc8: LoadField: d0 = r0->field_7
    //     0xbe5cc8: ldur            d0, [x0, #7]
    // 0xbe5ccc: r0 = inline_Allocate_Double()
    //     0xbe5ccc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe5cd0: add             x0, x0, #0x10
    //     0xbe5cd4: cmp             x1, x0
    //     0xbe5cd8: b.ls            #0xbe5e48
    //     0xbe5cdc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe5ce0: sub             x0, x0, #0xf
    //     0xbe5ce4: mov             x1, #0xe19c
    //     0xbe5ce8: movk            x1, #3, lsl #16
    //     0xbe5cec: stur            x1, [x0, #-1]
    // 0xbe5cf0: dmb             ishst
    // 0xbe5cf4: StoreField: r0->field_7 = d0
    //     0xbe5cf4: stur            d0, [x0, #7]
    // 0xbe5cf8: mov             x2, x0
    // 0xbe5cfc: ldur            x0, [fp, #-0x10]
    // 0xbe5d00: b               #0xbe5dc4
    // 0xbe5d04: r17 = 4701
    //     0xbe5d04: mov             x17, #0x125d
    // 0xbe5d08: cmp             x0, x17
    // 0xbe5d0c: b.ne            #0xbe5d1c
    // 0xbe5d10: ldur            x0, [fp, #-0x10]
    // 0xbe5d14: r2 = Null
    //     0xbe5d14: mov             x2, NULL
    // 0xbe5d18: b               #0xbe5dc4
    // 0xbe5d1c: r17 = 4702
    //     0xbe5d1c: mov             x17, #0x125e
    // 0xbe5d20: cmp             x0, x17
    // 0xbe5d24: b.ne            #0xbe5d40
    // 0xbe5d28: ldur            x3, [fp, #-0x10]
    // 0xbe5d2c: LoadField: r0 = r3->field_63
    //     0xbe5d2c: ldur            w0, [x3, #0x63]
    // 0xbe5d30: DecompressPointer r0
    //     0xbe5d30: add             x0, x0, HEAP, lsl #32
    // 0xbe5d34: mov             x2, x0
    // 0xbe5d38: mov             x0, x3
    // 0xbe5d3c: b               #0xbe5dc4
    // 0xbe5d40: ldur            x3, [fp, #-0x10]
    // 0xbe5d44: LoadField: r4 = r3->field_27
    //     0xbe5d44: ldur            w4, [x3, #0x27]
    // 0xbe5d48: DecompressPointer r4
    //     0xbe5d48: add             x4, x4, HEAP, lsl #32
    // 0xbe5d4c: stur            x4, [fp, #-8]
    // 0xbe5d50: cmp             w4, NULL
    // 0xbe5d54: b.eq            #0xbe5e18
    // 0xbe5d58: mov             x0, x4
    // 0xbe5d5c: r2 = Null
    //     0xbe5d5c: mov             x2, NULL
    // 0xbe5d60: r1 = Null
    //     0xbe5d60: mov             x1, NULL
    // 0xbe5d64: r4 = LoadClassIdInstr(r0)
    //     0xbe5d64: ldur            x4, [x0, #-1]
    //     0xbe5d68: ubfx            x4, x4, #0xc, #0x14
    // 0xbe5d6c: cmp             x4, #0xb45
    // 0xbe5d70: b.eq            #0xbe5d88
    // 0xbe5d74: r8 = SliverConstraints
    //     0xbe5d74: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe5d78: ldr             x8, [x8, #0x3c0]
    // 0xbe5d7c: r3 = Null
    //     0xbe5d7c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab670] Null
    //     0xbe5d80: ldr             x3, [x3, #0x670]
    // 0xbe5d84: r0 = DefaultTypeTest()
    //     0xbe5d84: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe5d88: ldur            x0, [fp, #-8]
    // 0xbe5d8c: LoadField: d0 = r0->field_3f
    //     0xbe5d8c: ldur            d0, [x0, #0x3f]
    // 0xbe5d90: r0 = inline_Allocate_Double()
    //     0xbe5d90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe5d94: add             x0, x0, #0x10
    //     0xbe5d98: cmp             x1, x0
    //     0xbe5d9c: b.ls            #0xbe5e58
    //     0xbe5da0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe5da4: sub             x0, x0, #0xf
    //     0xbe5da8: mov             x1, #0xe19c
    //     0xbe5dac: movk            x1, #3, lsl #16
    //     0xbe5db0: stur            x1, [x0, #-1]
    // 0xbe5db4: dmb             ishst
    // 0xbe5db8: StoreField: r0->field_7 = d0
    //     0xbe5db8: stur            d0, [x0, #7]
    // 0xbe5dbc: mov             x2, x0
    // 0xbe5dc0: ldur            x0, [fp, #-0x10]
    // 0xbe5dc4: stur            x2, [fp, #-8]
    // 0xbe5dc8: cmp             w2, NULL
    // 0xbe5dcc: b.eq            #0xbe5e68
    // 0xbe5dd0: LoadField: r1 = r0->field_5b
    //     0xbe5dd0: ldur            w1, [x0, #0x5b]
    // 0xbe5dd4: DecompressPointer r1
    //     0xbe5dd4: add             x1, x1, HEAP, lsl #32
    // 0xbe5dd8: r0 = childCount()
    //     0xbe5dd8: bl              #0xbe5e6c  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::childCount
    // 0xbe5ddc: scvtf           d0, x0
    // 0xbe5de0: ldur            x0, [fp, #-8]
    // 0xbe5de4: LoadField: d1 = r0->field_7
    //     0xbe5de4: ldur            d1, [x0, #7]
    // 0xbe5de8: fmul            d2, d0, d1
    // 0xbe5dec: mov             v0.16b, v2.16b
    // 0xbe5df0: LeaveFrame
    //     0xbe5df0: mov             SP, fp
    //     0xbe5df4: ldp             fp, lr, [SP], #0x10
    // 0xbe5df8: ret
    //     0xbe5df8: ret             
    // 0xbe5dfc: r0 = StateError()
    //     0xbe5dfc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe5e00: mov             x1, x0
    // 0xbe5e04: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe5e04: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe5e08: StoreField: r1->field_b = r0
    //     0xbe5e08: stur            w0, [x1, #0xb]
    // 0xbe5e0c: mov             x0, x1
    // 0xbe5e10: r0 = Throw()
    //     0xbe5e10: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe5e14: brk             #0
    // 0xbe5e18: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe5e18: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe5e1c: r0 = StateError()
    //     0xbe5e1c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe5e20: mov             x1, x0
    // 0xbe5e24: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe5e24: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe5e28: StoreField: r1->field_b = r0
    //     0xbe5e28: stur            w0, [x1, #0xb]
    // 0xbe5e2c: mov             x0, x1
    // 0xbe5e30: r0 = Throw()
    //     0xbe5e30: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe5e34: brk             #0
    // 0xbe5e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe5e38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe5e3c: b               #0xbe5c08
    // 0xbe5e40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5e40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe5e44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5e44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe5e48: SaveReg d0
    //     0xbe5e48: str             q0, [SP, #-0x10]!
    // 0xbe5e4c: r0 = AllocateDouble()
    //     0xbe5e4c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe5e50: RestoreReg d0
    //     0xbe5e50: ldr             q0, [SP], #0x10
    // 0xbe5e54: b               #0xbe5cf4
    // 0xbe5e58: SaveReg d0
    //     0xbe5e58: str             q0, [SP, #-0x10]!
    // 0xbe5e5c: r0 = AllocateDouble()
    //     0xbe5e5c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe5e60: RestoreReg d0
    //     0xbe5e60: ldr             q0, [SP], #0x10
    // 0xbe5e64: b               #0xbe5db8
    // 0xbe5e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5e68: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ indexToLayoutOffset(/* No info */) {
    // ** addr: 0xbe6288, size: 0x270
    // 0xbe6288: EnterFrame
    //     0xbe6288: stp             fp, lr, [SP, #-0x10]!
    //     0xbe628c: mov             fp, SP
    // 0xbe6290: AllocStack(0x18)
    //     0xbe6290: sub             SP, SP, #0x18
    // 0xbe6294: SetupParameters(RenderSliverFixedExtentBoxAdaptor this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xbe6294: mov             x4, x1
    //     0xbe6298: mov             x3, x2
    //     0xbe629c: stur            x1, [fp, #-0x10]
    //     0xbe62a0: stur            x2, [fp, #-0x18]
    // 0xbe62a4: CheckStackOverflow
    //     0xbe62a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe62a8: cmp             SP, x16
    //     0xbe62ac: b.ls            #0xbe64c4
    // 0xbe62b0: r0 = LoadClassIdInstr(r4)
    //     0xbe62b0: ldur            x0, [x4, #-1]
    //     0xbe62b4: ubfx            x0, x0, #0xc, #0x14
    // 0xbe62b8: r17 = -4702
    //     0xbe62b8: mov             x17, #-0x125e
    // 0xbe62bc: add             x16, x0, x17
    // 0xbe62c0: cmp             x16, #1
    // 0xbe62c4: b.ls            #0xbe62d4
    // 0xbe62c8: r17 = 4700
    //     0xbe62c8: mov             x17, #0x125c
    // 0xbe62cc: cmp             x0, x17
    // 0xbe62d0: b.eq            #0xbe62d4
    // 0xbe62d4: r17 = 4700
    //     0xbe62d4: mov             x17, #0x125c
    // 0xbe62d8: cmp             x0, x17
    // 0xbe62dc: b.ne            #0xbe63b0
    // 0xbe62e0: LoadField: r5 = r4->field_27
    //     0xbe62e0: ldur            w5, [x4, #0x27]
    // 0xbe62e4: DecompressPointer r5
    //     0xbe62e4: add             x5, x5, HEAP, lsl #32
    // 0xbe62e8: stur            x5, [fp, #-8]
    // 0xbe62ec: cmp             w5, NULL
    // 0xbe62f0: b.eq            #0xbe6488
    // 0xbe62f4: mov             x0, x5
    // 0xbe62f8: r2 = Null
    //     0xbe62f8: mov             x2, NULL
    // 0xbe62fc: r1 = Null
    //     0xbe62fc: mov             x1, NULL
    // 0xbe6300: r4 = LoadClassIdInstr(r0)
    //     0xbe6300: ldur            x4, [x0, #-1]
    //     0xbe6304: ubfx            x4, x4, #0xc, #0x14
    // 0xbe6308: cmp             x4, #0xb45
    // 0xbe630c: b.eq            #0xbe6324
    // 0xbe6310: r8 = SliverConstraints
    //     0xbe6310: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe6314: ldr             x8, [x8, #0x3c0]
    // 0xbe6318: r3 = Null
    //     0xbe6318: add             x3, PP, #0xab, lsl #12  ; [pp+0xab680] Null
    //     0xbe631c: ldr             x3, [x3, #0x680]
    // 0xbe6320: r0 = DefaultTypeTest()
    //     0xbe6320: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe6324: ldur            x1, [fp, #-8]
    // 0xbe6328: r0 = axis()
    //     0xbe6328: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe632c: r16 = Instance_Axis
    //     0xbe632c: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe6330: cmp             w0, w16
    // 0xbe6334: b.ne            #0xbe635c
    // 0xbe6338: ldur            x1, [fp, #-0x10]
    // 0xbe633c: LoadField: r0 = r1->field_63
    //     0xbe633c: ldur            w0, [x1, #0x63]
    // 0xbe6340: DecompressPointer r0
    //     0xbe6340: add             x0, x0, HEAP, lsl #32
    // 0xbe6344: cmp             w0, NULL
    // 0xbe6348: b.eq            #0xbe64cc
    // 0xbe634c: mov             x1, x0
    // 0xbe6350: r0 = size()
    //     0xbe6350: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe6354: LoadField: d0 = r0->field_f
    //     0xbe6354: ldur            d0, [x0, #0xf]
    // 0xbe6358: b               #0xbe637c
    // 0xbe635c: ldur            x1, [fp, #-0x10]
    // 0xbe6360: LoadField: r0 = r1->field_63
    //     0xbe6360: ldur            w0, [x1, #0x63]
    // 0xbe6364: DecompressPointer r0
    //     0xbe6364: add             x0, x0, HEAP, lsl #32
    // 0xbe6368: cmp             w0, NULL
    // 0xbe636c: b.eq            #0xbe64d0
    // 0xbe6370: mov             x1, x0
    // 0xbe6374: r0 = size()
    //     0xbe6374: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe6378: LoadField: d0 = r0->field_7
    //     0xbe6378: ldur            d0, [x0, #7]
    // 0xbe637c: r0 = inline_Allocate_Double()
    //     0xbe637c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe6380: add             x0, x0, #0x10
    //     0xbe6384: cmp             x1, x0
    //     0xbe6388: b.ls            #0xbe64d4
    //     0xbe638c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe6390: sub             x0, x0, #0xf
    //     0xbe6394: mov             x1, #0xe19c
    //     0xbe6398: movk            x1, #3, lsl #16
    //     0xbe639c: stur            x1, [x0, #-1]
    // 0xbe63a0: dmb             ishst
    // 0xbe63a4: StoreField: r0->field_7 = d0
    //     0xbe63a4: stur            d0, [x0, #7]
    // 0xbe63a8: mov             x1, x0
    // 0xbe63ac: b               #0xbe6460
    // 0xbe63b0: mov             x1, x4
    // 0xbe63b4: r17 = 4701
    //     0xbe63b4: mov             x17, #0x125d
    // 0xbe63b8: cmp             x0, x17
    // 0xbe63bc: b.ne            #0xbe63c8
    // 0xbe63c0: r1 = Null
    //     0xbe63c0: mov             x1, NULL
    // 0xbe63c4: b               #0xbe6460
    // 0xbe63c8: r17 = 4702
    //     0xbe63c8: mov             x17, #0x125e
    // 0xbe63cc: cmp             x0, x17
    // 0xbe63d0: b.ne            #0xbe63e4
    // 0xbe63d4: LoadField: r0 = r1->field_63
    //     0xbe63d4: ldur            w0, [x1, #0x63]
    // 0xbe63d8: DecompressPointer r0
    //     0xbe63d8: add             x0, x0, HEAP, lsl #32
    // 0xbe63dc: mov             x1, x0
    // 0xbe63e0: b               #0xbe6460
    // 0xbe63e4: LoadField: r3 = r1->field_27
    //     0xbe63e4: ldur            w3, [x1, #0x27]
    // 0xbe63e8: DecompressPointer r3
    //     0xbe63e8: add             x3, x3, HEAP, lsl #32
    // 0xbe63ec: stur            x3, [fp, #-8]
    // 0xbe63f0: cmp             w3, NULL
    // 0xbe63f4: b.eq            #0xbe64a4
    // 0xbe63f8: mov             x0, x3
    // 0xbe63fc: r2 = Null
    //     0xbe63fc: mov             x2, NULL
    // 0xbe6400: r1 = Null
    //     0xbe6400: mov             x1, NULL
    // 0xbe6404: r4 = LoadClassIdInstr(r0)
    //     0xbe6404: ldur            x4, [x0, #-1]
    //     0xbe6408: ubfx            x4, x4, #0xc, #0x14
    // 0xbe640c: cmp             x4, #0xb45
    // 0xbe6410: b.eq            #0xbe6428
    // 0xbe6414: r8 = SliverConstraints
    //     0xbe6414: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe6418: ldr             x8, [x8, #0x3c0]
    // 0xbe641c: r3 = Null
    //     0xbe641c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab690] Null
    //     0xbe6420: ldr             x3, [x3, #0x690]
    // 0xbe6424: r0 = DefaultTypeTest()
    //     0xbe6424: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe6428: ldur            x0, [fp, #-8]
    // 0xbe642c: LoadField: d0 = r0->field_3f
    //     0xbe642c: ldur            d0, [x0, #0x3f]
    // 0xbe6430: r0 = inline_Allocate_Double()
    //     0xbe6430: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe6434: add             x0, x0, #0x10
    //     0xbe6438: cmp             x1, x0
    //     0xbe643c: b.ls            #0xbe64e4
    //     0xbe6440: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe6444: sub             x0, x0, #0xf
    //     0xbe6448: mov             x1, #0xe19c
    //     0xbe644c: movk            x1, #3, lsl #16
    //     0xbe6450: stur            x1, [x0, #-1]
    // 0xbe6454: dmb             ishst
    // 0xbe6458: StoreField: r0->field_7 = d0
    //     0xbe6458: stur            d0, [x0, #7]
    // 0xbe645c: mov             x1, x0
    // 0xbe6460: ldur            x0, [fp, #-0x18]
    // 0xbe6464: cmp             w1, NULL
    // 0xbe6468: b.eq            #0xbe64f4
    // 0xbe646c: scvtf           d0, x0
    // 0xbe6470: LoadField: d1 = r1->field_7
    //     0xbe6470: ldur            d1, [x1, #7]
    // 0xbe6474: fmul            d2, d1, d0
    // 0xbe6478: mov             v0.16b, v2.16b
    // 0xbe647c: LeaveFrame
    //     0xbe647c: mov             SP, fp
    //     0xbe6480: ldp             fp, lr, [SP], #0x10
    // 0xbe6484: ret
    //     0xbe6484: ret             
    // 0xbe6488: r0 = StateError()
    //     0xbe6488: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe648c: mov             x1, x0
    // 0xbe6490: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe6490: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe6494: StoreField: r1->field_b = r0
    //     0xbe6494: stur            w0, [x1, #0xb]
    // 0xbe6498: mov             x0, x1
    // 0xbe649c: r0 = Throw()
    //     0xbe649c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe64a0: brk             #0
    // 0xbe64a4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe64a4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe64a8: r0 = StateError()
    //     0xbe64a8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe64ac: mov             x1, x0
    // 0xbe64b0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe64b0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe64b4: StoreField: r1->field_b = r0
    //     0xbe64b4: stur            w0, [x1, #0xb]
    // 0xbe64b8: mov             x0, x1
    // 0xbe64bc: r0 = Throw()
    //     0xbe64bc: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe64c0: brk             #0
    // 0xbe64c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe64c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe64c8: b               #0xbe62b0
    // 0xbe64cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe64cc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe64d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe64d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe64d4: SaveReg d0
    //     0xbe64d4: str             q0, [SP, #-0x10]!
    // 0xbe64d8: r0 = AllocateDouble()
    //     0xbe64d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe64dc: RestoreReg d0
    //     0xbe64dc: ldr             q0, [SP], #0x10
    // 0xbe64e0: b               #0xbe63a4
    // 0xbe64e4: SaveReg d0
    //     0xbe64e4: str             q0, [SP, #-0x10]!
    // 0xbe64e8: r0 = AllocateDouble()
    //     0xbe64e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe64ec: RestoreReg d0
    //     0xbe64ec: ldr             q0, [SP], #0x10
    // 0xbe64f0: b               #0xbe6458
    // 0xbe64f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe64f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMaxChildIndexForScrollOffset(/* No info */) {
    // ** addr: 0xbe6f38, size: 0x3e0
    // 0xbe6f38: EnterFrame
    //     0xbe6f38: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6f3c: mov             fp, SP
    // 0xbe6f40: AllocStack(0x20)
    //     0xbe6f40: sub             SP, SP, #0x20
    // 0xbe6f44: SetupParameters(RenderSliverFixedExtentBoxAdaptor this /* r1 => r3, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0xbe6f44: mov             x3, x1
    //     0xbe6f48: stur            x1, [fp, #-0x10]
    //     0xbe6f4c: stur            d0, [fp, #-0x18]
    // 0xbe6f50: CheckStackOverflow
    //     0xbe6f50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe6f54: cmp             SP, x16
    //     0xbe6f58: b.ls            #0xbe729c
    // 0xbe6f5c: r0 = LoadClassIdInstr(r3)
    //     0xbe6f5c: ldur            x0, [x3, #-1]
    //     0xbe6f60: ubfx            x0, x0, #0xc, #0x14
    // 0xbe6f64: r17 = -4702
    //     0xbe6f64: mov             x17, #-0x125e
    // 0xbe6f68: add             x16, x0, x17
    // 0xbe6f6c: cmp             x16, #1
    // 0xbe6f70: b.ls            #0xbe6f80
    // 0xbe6f74: r17 = 4700
    //     0xbe6f74: mov             x17, #0x125c
    // 0xbe6f78: cmp             x0, x17
    // 0xbe6f7c: b.eq            #0xbe6f80
    // 0xbe6f80: r17 = 4700
    //     0xbe6f80: mov             x17, #0x125c
    // 0xbe6f84: cmp             x0, x17
    // 0xbe6f88: b.ne            #0xbe7058
    // 0xbe6f8c: LoadField: r4 = r3->field_27
    //     0xbe6f8c: ldur            w4, [x3, #0x27]
    // 0xbe6f90: DecompressPointer r4
    //     0xbe6f90: add             x4, x4, HEAP, lsl #32
    // 0xbe6f94: stur            x4, [fp, #-8]
    // 0xbe6f98: cmp             w4, NULL
    // 0xbe6f9c: b.eq            #0xbe7260
    // 0xbe6fa0: mov             x0, x4
    // 0xbe6fa4: r2 = Null
    //     0xbe6fa4: mov             x2, NULL
    // 0xbe6fa8: r1 = Null
    //     0xbe6fa8: mov             x1, NULL
    // 0xbe6fac: r4 = LoadClassIdInstr(r0)
    //     0xbe6fac: ldur            x4, [x0, #-1]
    //     0xbe6fb0: ubfx            x4, x4, #0xc, #0x14
    // 0xbe6fb4: cmp             x4, #0xb45
    // 0xbe6fb8: b.eq            #0xbe6fd0
    // 0xbe6fbc: r8 = SliverConstraints
    //     0xbe6fbc: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe6fc0: ldr             x8, [x8, #0x3c0]
    // 0xbe6fc4: r3 = Null
    //     0xbe6fc4: add             x3, PP, #0xab, lsl #12  ; [pp+0xab6a0] Null
    //     0xbe6fc8: ldr             x3, [x3, #0x6a0]
    // 0xbe6fcc: r0 = DefaultTypeTest()
    //     0xbe6fcc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe6fd0: ldur            x1, [fp, #-8]
    // 0xbe6fd4: r0 = axis()
    //     0xbe6fd4: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe6fd8: r16 = Instance_Axis
    //     0xbe6fd8: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe6fdc: cmp             w0, w16
    // 0xbe6fe0: b.ne            #0xbe7008
    // 0xbe6fe4: ldur            x1, [fp, #-0x10]
    // 0xbe6fe8: LoadField: r0 = r1->field_63
    //     0xbe6fe8: ldur            w0, [x1, #0x63]
    // 0xbe6fec: DecompressPointer r0
    //     0xbe6fec: add             x0, x0, HEAP, lsl #32
    // 0xbe6ff0: cmp             w0, NULL
    // 0xbe6ff4: b.eq            #0xbe72a4
    // 0xbe6ff8: mov             x1, x0
    // 0xbe6ffc: r0 = size()
    //     0xbe6ffc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe7000: LoadField: d0 = r0->field_f
    //     0xbe7000: ldur            d0, [x0, #0xf]
    // 0xbe7004: b               #0xbe7028
    // 0xbe7008: ldur            x1, [fp, #-0x10]
    // 0xbe700c: LoadField: r0 = r1->field_63
    //     0xbe700c: ldur            w0, [x1, #0x63]
    // 0xbe7010: DecompressPointer r0
    //     0xbe7010: add             x0, x0, HEAP, lsl #32
    // 0xbe7014: cmp             w0, NULL
    // 0xbe7018: b.eq            #0xbe72a8
    // 0xbe701c: mov             x1, x0
    // 0xbe7020: r0 = size()
    //     0xbe7020: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe7024: LoadField: d0 = r0->field_7
    //     0xbe7024: ldur            d0, [x0, #7]
    // 0xbe7028: r0 = inline_Allocate_Double()
    //     0xbe7028: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe702c: add             x0, x0, #0x10
    //     0xbe7030: cmp             x1, x0
    //     0xbe7034: b.ls            #0xbe72ac
    //     0xbe7038: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe703c: sub             x0, x0, #0xf
    //     0xbe7040: mov             x1, #0xe19c
    //     0xbe7044: movk            x1, #3, lsl #16
    //     0xbe7048: stur            x1, [x0, #-1]
    // 0xbe704c: dmb             ishst
    // 0xbe7050: StoreField: r0->field_7 = d0
    //     0xbe7050: stur            d0, [x0, #7]
    // 0xbe7054: b               #0xbe7100
    // 0xbe7058: mov             x1, x3
    // 0xbe705c: r17 = 4701
    //     0xbe705c: mov             x17, #0x125d
    // 0xbe7060: cmp             x0, x17
    // 0xbe7064: b.ne            #0xbe7070
    // 0xbe7068: r0 = Null
    //     0xbe7068: mov             x0, NULL
    // 0xbe706c: b               #0xbe7100
    // 0xbe7070: r17 = 4702
    //     0xbe7070: mov             x17, #0x125e
    // 0xbe7074: cmp             x0, x17
    // 0xbe7078: b.ne            #0xbe7088
    // 0xbe707c: LoadField: r0 = r1->field_63
    //     0xbe707c: ldur            w0, [x1, #0x63]
    // 0xbe7080: DecompressPointer r0
    //     0xbe7080: add             x0, x0, HEAP, lsl #32
    // 0xbe7084: b               #0xbe7100
    // 0xbe7088: LoadField: r3 = r1->field_27
    //     0xbe7088: ldur            w3, [x1, #0x27]
    // 0xbe708c: DecompressPointer r3
    //     0xbe708c: add             x3, x3, HEAP, lsl #32
    // 0xbe7090: stur            x3, [fp, #-8]
    // 0xbe7094: cmp             w3, NULL
    // 0xbe7098: b.eq            #0xbe727c
    // 0xbe709c: mov             x0, x3
    // 0xbe70a0: r2 = Null
    //     0xbe70a0: mov             x2, NULL
    // 0xbe70a4: r1 = Null
    //     0xbe70a4: mov             x1, NULL
    // 0xbe70a8: r4 = LoadClassIdInstr(r0)
    //     0xbe70a8: ldur            x4, [x0, #-1]
    //     0xbe70ac: ubfx            x4, x4, #0xc, #0x14
    // 0xbe70b0: cmp             x4, #0xb45
    // 0xbe70b4: b.eq            #0xbe70cc
    // 0xbe70b8: r8 = SliverConstraints
    //     0xbe70b8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe70bc: ldr             x8, [x8, #0x3c0]
    // 0xbe70c0: r3 = Null
    //     0xbe70c0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab6b0] Null
    //     0xbe70c4: ldr             x3, [x3, #0x6b0]
    // 0xbe70c8: r0 = DefaultTypeTest()
    //     0xbe70c8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe70cc: ldur            x0, [fp, #-8]
    // 0xbe70d0: LoadField: d0 = r0->field_3f
    //     0xbe70d0: ldur            d0, [x0, #0x3f]
    // 0xbe70d4: r0 = inline_Allocate_Double()
    //     0xbe70d4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe70d8: add             x0, x0, #0x10
    //     0xbe70dc: cmp             x1, x0
    //     0xbe70e0: b.ls            #0xbe72bc
    //     0xbe70e4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe70e8: sub             x0, x0, #0xf
    //     0xbe70ec: mov             x1, #0xe19c
    //     0xbe70f0: movk            x1, #3, lsl #16
    //     0xbe70f4: stur            x1, [x0, #-1]
    // 0xbe70f8: dmb             ishst
    // 0xbe70fc: StoreField: r0->field_7 = d0
    //     0xbe70fc: stur            d0, [x0, #7]
    // 0xbe7100: d1 = 0.000000
    //     0xbe7100: eor             v1.16b, v1.16b, v1.16b
    // 0xbe7104: cmp             w0, NULL
    // 0xbe7108: b.eq            #0xbe72cc
    // 0xbe710c: LoadField: d2 = r0->field_7
    //     0xbe710c: ldur            d2, [x0, #7]
    // 0xbe7110: stur            d2, [fp, #-0x20]
    // 0xbe7114: fcmp            d2, d1
    // 0xbe7118: b.le            #0xbe7250
    // 0xbe711c: ldur            d0, [fp, #-0x18]
    // 0xbe7120: d3 = 1.000000
    //     0xbe7120: fmov            d3, #1.00000000
    // 0xbe7124: fdiv            d4, d0, d2
    // 0xbe7128: fsub            d5, d4, d3
    // 0xbe712c: mov             v0.16b, v5.16b
    // 0xbe7130: stur            d5, [fp, #-0x18]
    // 0xbe7134: stp             fp, lr, [SP, #-0x10]!
    // 0xbe7138: mov             fp, SP
    // 0xbe713c: CallRuntime_LibcRound(double) -> double
    //     0xbe713c: and             SP, SP, #0xfffffffffffffff0
    //     0xbe7140: mov             sp, SP
    //     0xbe7144: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xbe7148: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbe714c: blr             x16
    //     0xbe7150: mov             x16, #8
    //     0xbe7154: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbe7158: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xbe715c: sub             sp, x16, #1, lsl #12
    //     0xbe7160: mov             SP, fp
    //     0xbe7164: ldp             fp, lr, [SP], #0x10
    // 0xbe7168: fcmp            d0, d0
    // 0xbe716c: b.vs            #0xbe72d0
    // 0xbe7170: fcvtzs          x0, d0
    // 0xbe7174: asr             x16, x0, #0x1e
    // 0xbe7178: cmp             x16, x0, asr #63
    // 0xbe717c: b.ne            #0xbe72d0
    // 0xbe7180: lsl             x0, x0, #1
    // 0xbe7184: ldur            d1, [fp, #-0x18]
    // 0xbe7188: ldur            d0, [fp, #-0x20]
    // 0xbe718c: fmul            d2, d1, d0
    // 0xbe7190: r1 = LoadInt32Instr(r0)
    //     0xbe7190: sbfx            x1, x0, #1, #0x1f
    //     0xbe7194: tbz             w0, #0, #0xbe719c
    //     0xbe7198: ldur            x1, [x0, #7]
    // 0xbe719c: scvtf           d3, x1
    // 0xbe71a0: fmul            d4, d3, d0
    // 0xbe71a4: fsub            d0, d2, d4
    // 0xbe71a8: d2 = 0.000000
    //     0xbe71a8: eor             v2.16b, v2.16b, v2.16b
    // 0xbe71ac: fcmp            d0, d2
    // 0xbe71b0: b.ne            #0xbe71c8
    // 0xbe71b4: d3 = 0.000000
    //     0xbe71b4: ldr             d3, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xbe71b8: fcmp            d3, d2
    // 0xbe71bc: b.gt            #0xbe71f0
    // 0xbe71c0: r0 = 0
    //     0xbe71c0: mov             x0, #0
    // 0xbe71c4: b               #0xbe7210
    // 0xbe71c8: d3 = 0.000000
    //     0xbe71c8: ldr             d3, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xbe71cc: fcmp            d2, d0
    // 0xbe71d0: b.le            #0xbe71e8
    // 0xbe71d4: fneg            d2, d0
    // 0xbe71d8: fcmp            d3, d2
    // 0xbe71dc: b.gt            #0xbe71f0
    // 0xbe71e0: r0 = 0
    //     0xbe71e0: mov             x0, #0
    // 0xbe71e4: b               #0xbe7210
    // 0xbe71e8: fcmp            d3, d0
    // 0xbe71ec: b.le            #0xbe720c
    // 0xbe71f0: r0 = 0
    //     0xbe71f0: mov             x0, #0
    // 0xbe71f4: cmp             x0, x1
    // 0xbe71f8: csel            x2, x1, x0, lt
    // 0xbe71fc: mov             x0, x2
    // 0xbe7200: LeaveFrame
    //     0xbe7200: mov             SP, fp
    //     0xbe7204: ldp             fp, lr, [SP], #0x10
    // 0xbe7208: ret
    //     0xbe7208: ret             
    // 0xbe720c: r0 = 0
    //     0xbe720c: mov             x0, #0
    // 0xbe7210: fcmp            d1, d1
    // 0xbe7214: b.vs            #0xbe72ec
    // 0xbe7218: fcvtps          x1, d1
    // 0xbe721c: asr             x16, x1, #0x1e
    // 0xbe7220: cmp             x16, x1, asr #63
    // 0xbe7224: b.ne            #0xbe72ec
    // 0xbe7228: lsl             x1, x1, #1
    // 0xbe722c: r2 = LoadInt32Instr(r1)
    //     0xbe722c: sbfx            x2, x1, #1, #0x1f
    //     0xbe7230: tbz             w1, #0, #0xbe7238
    //     0xbe7234: ldur            x2, [x1, #7]
    // 0xbe7238: cmp             x0, x2
    // 0xbe723c: csel            x1, x2, x0, lt
    // 0xbe7240: mov             x0, x1
    // 0xbe7244: LeaveFrame
    //     0xbe7244: mov             SP, fp
    //     0xbe7248: ldp             fp, lr, [SP], #0x10
    // 0xbe724c: ret
    //     0xbe724c: ret             
    // 0xbe7250: r0 = 0
    //     0xbe7250: mov             x0, #0
    // 0xbe7254: LeaveFrame
    //     0xbe7254: mov             SP, fp
    //     0xbe7258: ldp             fp, lr, [SP], #0x10
    // 0xbe725c: ret
    //     0xbe725c: ret             
    // 0xbe7260: r0 = StateError()
    //     0xbe7260: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe7264: mov             x1, x0
    // 0xbe7268: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe7268: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe726c: StoreField: r1->field_b = r0
    //     0xbe726c: stur            w0, [x1, #0xb]
    // 0xbe7270: mov             x0, x1
    // 0xbe7274: r0 = Throw()
    //     0xbe7274: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe7278: brk             #0
    // 0xbe727c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe727c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe7280: r0 = StateError()
    //     0xbe7280: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe7284: mov             x1, x0
    // 0xbe7288: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe7288: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe728c: StoreField: r1->field_b = r0
    //     0xbe728c: stur            w0, [x1, #0xb]
    // 0xbe7290: mov             x0, x1
    // 0xbe7294: r0 = Throw()
    //     0xbe7294: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe7298: brk             #0
    // 0xbe729c: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe729c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe72a0: b               #0xbe6f5c
    // 0xbe72a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe72a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe72a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe72a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe72ac: SaveReg d0
    //     0xbe72ac: str             q0, [SP, #-0x10]!
    // 0xbe72b0: r0 = AllocateDouble()
    //     0xbe72b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe72b4: RestoreReg d0
    //     0xbe72b4: ldr             q0, [SP], #0x10
    // 0xbe72b8: b               #0xbe7050
    // 0xbe72bc: SaveReg d0
    //     0xbe72bc: str             q0, [SP, #-0x10]!
    // 0xbe72c0: r0 = AllocateDouble()
    //     0xbe72c0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe72c4: RestoreReg d0
    //     0xbe72c4: ldr             q0, [SP], #0x10
    // 0xbe72c8: b               #0xbe70fc
    // 0xbe72cc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe72cc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe72d0: SaveReg d0
    //     0xbe72d0: str             q0, [SP, #-0x10]!
    // 0xbe72d4: r0 = 76
    //     0xbe72d4: mov             x0, #0x4c
    // 0xbe72d8: r30 = DoubleToIntegerStub
    //     0xbe72d8: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbe72dc: LoadField: r30 = r30->field_7
    //     0xbe72dc: ldur            lr, [lr, #7]
    // 0xbe72e0: blr             lr
    // 0xbe72e4: RestoreReg d0
    //     0xbe72e4: ldr             q0, [SP], #0x10
    // 0xbe72e8: b               #0xbe7184
    // 0xbe72ec: SaveReg d1
    //     0xbe72ec: str             q1, [SP, #-0x10]!
    // 0xbe72f0: SaveReg r0
    //     0xbe72f0: str             x0, [SP, #-8]!
    // 0xbe72f4: d0 = 0.000000
    //     0xbe72f4: fmov            d0, d1
    // 0xbe72f8: r0 = 66
    //     0xbe72f8: mov             x0, #0x42
    // 0xbe72fc: r30 = DoubleToIntegerStub
    //     0xbe72fc: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbe7300: LoadField: r30 = r30->field_7
    //     0xbe7300: ldur            lr, [lr, #7]
    // 0xbe7304: blr             lr
    // 0xbe7308: mov             x1, x0
    // 0xbe730c: RestoreReg r0
    //     0xbe730c: ldr             x0, [SP], #8
    // 0xbe7310: RestoreReg d1
    //     0xbe7310: ldr             q1, [SP], #0x10
    // 0xbe7314: b               #0xbe722c
  }
  _ getMinChildIndexForScrollOffset(/* No info */) {
    // ** addr: 0xbe7318, size: 0x3ac
    // 0xbe7318: EnterFrame
    //     0xbe7318: stp             fp, lr, [SP, #-0x10]!
    //     0xbe731c: mov             fp, SP
    // 0xbe7320: AllocStack(0x28)
    //     0xbe7320: sub             SP, SP, #0x28
    // 0xbe7324: SetupParameters(RenderSliverFixedExtentBoxAdaptor this /* r1 => r3, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0xbe7324: mov             x3, x1
    //     0xbe7328: stur            x1, [fp, #-0x10]
    //     0xbe732c: stur            d0, [fp, #-0x18]
    // 0xbe7330: CheckStackOverflow
    //     0xbe7330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe7334: cmp             SP, x16
    //     0xbe7338: b.ls            #0xbe7654
    // 0xbe733c: r0 = LoadClassIdInstr(r3)
    //     0xbe733c: ldur            x0, [x3, #-1]
    //     0xbe7340: ubfx            x0, x0, #0xc, #0x14
    // 0xbe7344: r17 = -4702
    //     0xbe7344: mov             x17, #-0x125e
    // 0xbe7348: add             x16, x0, x17
    // 0xbe734c: cmp             x16, #1
    // 0xbe7350: b.ls            #0xbe7360
    // 0xbe7354: r17 = 4700
    //     0xbe7354: mov             x17, #0x125c
    // 0xbe7358: cmp             x0, x17
    // 0xbe735c: b.eq            #0xbe7360
    // 0xbe7360: r17 = 4700
    //     0xbe7360: mov             x17, #0x125c
    // 0xbe7364: cmp             x0, x17
    // 0xbe7368: b.ne            #0xbe7438
    // 0xbe736c: LoadField: r4 = r3->field_27
    //     0xbe736c: ldur            w4, [x3, #0x27]
    // 0xbe7370: DecompressPointer r4
    //     0xbe7370: add             x4, x4, HEAP, lsl #32
    // 0xbe7374: stur            x4, [fp, #-8]
    // 0xbe7378: cmp             w4, NULL
    // 0xbe737c: b.eq            #0xbe7618
    // 0xbe7380: mov             x0, x4
    // 0xbe7384: r2 = Null
    //     0xbe7384: mov             x2, NULL
    // 0xbe7388: r1 = Null
    //     0xbe7388: mov             x1, NULL
    // 0xbe738c: r4 = LoadClassIdInstr(r0)
    //     0xbe738c: ldur            x4, [x0, #-1]
    //     0xbe7390: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7394: cmp             x4, #0xb45
    // 0xbe7398: b.eq            #0xbe73b0
    // 0xbe739c: r8 = SliverConstraints
    //     0xbe739c: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe73a0: ldr             x8, [x8, #0x3c0]
    // 0xbe73a4: r3 = Null
    //     0xbe73a4: add             x3, PP, #0xab, lsl #12  ; [pp+0xab6c0] Null
    //     0xbe73a8: ldr             x3, [x3, #0x6c0]
    // 0xbe73ac: r0 = DefaultTypeTest()
    //     0xbe73ac: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe73b0: ldur            x1, [fp, #-8]
    // 0xbe73b4: r0 = axis()
    //     0xbe73b4: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe73b8: r16 = Instance_Axis
    //     0xbe73b8: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe73bc: cmp             w0, w16
    // 0xbe73c0: b.ne            #0xbe73e8
    // 0xbe73c4: ldur            x1, [fp, #-0x10]
    // 0xbe73c8: LoadField: r0 = r1->field_63
    //     0xbe73c8: ldur            w0, [x1, #0x63]
    // 0xbe73cc: DecompressPointer r0
    //     0xbe73cc: add             x0, x0, HEAP, lsl #32
    // 0xbe73d0: cmp             w0, NULL
    // 0xbe73d4: b.eq            #0xbe765c
    // 0xbe73d8: mov             x1, x0
    // 0xbe73dc: r0 = size()
    //     0xbe73dc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe73e0: LoadField: d0 = r0->field_f
    //     0xbe73e0: ldur            d0, [x0, #0xf]
    // 0xbe73e4: b               #0xbe7408
    // 0xbe73e8: ldur            x1, [fp, #-0x10]
    // 0xbe73ec: LoadField: r0 = r1->field_63
    //     0xbe73ec: ldur            w0, [x1, #0x63]
    // 0xbe73f0: DecompressPointer r0
    //     0xbe73f0: add             x0, x0, HEAP, lsl #32
    // 0xbe73f4: cmp             w0, NULL
    // 0xbe73f8: b.eq            #0xbe7660
    // 0xbe73fc: mov             x1, x0
    // 0xbe7400: r0 = size()
    //     0xbe7400: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbe7404: LoadField: d0 = r0->field_7
    //     0xbe7404: ldur            d0, [x0, #7]
    // 0xbe7408: r0 = inline_Allocate_Double()
    //     0xbe7408: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe740c: add             x0, x0, #0x10
    //     0xbe7410: cmp             x1, x0
    //     0xbe7414: b.ls            #0xbe7664
    //     0xbe7418: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe741c: sub             x0, x0, #0xf
    //     0xbe7420: mov             x1, #0xe19c
    //     0xbe7424: movk            x1, #3, lsl #16
    //     0xbe7428: stur            x1, [x0, #-1]
    // 0xbe742c: dmb             ishst
    // 0xbe7430: StoreField: r0->field_7 = d0
    //     0xbe7430: stur            d0, [x0, #7]
    // 0xbe7434: b               #0xbe74e0
    // 0xbe7438: mov             x1, x3
    // 0xbe743c: r17 = 4701
    //     0xbe743c: mov             x17, #0x125d
    // 0xbe7440: cmp             x0, x17
    // 0xbe7444: b.ne            #0xbe7450
    // 0xbe7448: r0 = Null
    //     0xbe7448: mov             x0, NULL
    // 0xbe744c: b               #0xbe74e0
    // 0xbe7450: r17 = 4702
    //     0xbe7450: mov             x17, #0x125e
    // 0xbe7454: cmp             x0, x17
    // 0xbe7458: b.ne            #0xbe7468
    // 0xbe745c: LoadField: r0 = r1->field_63
    //     0xbe745c: ldur            w0, [x1, #0x63]
    // 0xbe7460: DecompressPointer r0
    //     0xbe7460: add             x0, x0, HEAP, lsl #32
    // 0xbe7464: b               #0xbe74e0
    // 0xbe7468: LoadField: r3 = r1->field_27
    //     0xbe7468: ldur            w3, [x1, #0x27]
    // 0xbe746c: DecompressPointer r3
    //     0xbe746c: add             x3, x3, HEAP, lsl #32
    // 0xbe7470: stur            x3, [fp, #-8]
    // 0xbe7474: cmp             w3, NULL
    // 0xbe7478: b.eq            #0xbe7634
    // 0xbe747c: mov             x0, x3
    // 0xbe7480: r2 = Null
    //     0xbe7480: mov             x2, NULL
    // 0xbe7484: r1 = Null
    //     0xbe7484: mov             x1, NULL
    // 0xbe7488: r4 = LoadClassIdInstr(r0)
    //     0xbe7488: ldur            x4, [x0, #-1]
    //     0xbe748c: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7490: cmp             x4, #0xb45
    // 0xbe7494: b.eq            #0xbe74ac
    // 0xbe7498: r8 = SliverConstraints
    //     0xbe7498: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe749c: ldr             x8, [x8, #0x3c0]
    // 0xbe74a0: r3 = Null
    //     0xbe74a0: add             x3, PP, #0xab, lsl #12  ; [pp+0xab6d0] Null
    //     0xbe74a4: ldr             x3, [x3, #0x6d0]
    // 0xbe74a8: r0 = DefaultTypeTest()
    //     0xbe74a8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe74ac: ldur            x0, [fp, #-8]
    // 0xbe74b0: LoadField: d0 = r0->field_3f
    //     0xbe74b0: ldur            d0, [x0, #0x3f]
    // 0xbe74b4: r0 = inline_Allocate_Double()
    //     0xbe74b4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe74b8: add             x0, x0, #0x10
    //     0xbe74bc: cmp             x1, x0
    //     0xbe74c0: b.ls            #0xbe7674
    //     0xbe74c4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe74c8: sub             x0, x0, #0xf
    //     0xbe74cc: mov             x1, #0xe19c
    //     0xbe74d0: movk            x1, #3, lsl #16
    //     0xbe74d4: stur            x1, [x0, #-1]
    // 0xbe74d8: dmb             ishst
    // 0xbe74dc: StoreField: r0->field_7 = d0
    //     0xbe74dc: stur            d0, [x0, #7]
    // 0xbe74e0: d1 = 0.000000
    //     0xbe74e0: eor             v1.16b, v1.16b, v1.16b
    // 0xbe74e4: cmp             w0, NULL
    // 0xbe74e8: b.eq            #0xbe7684
    // 0xbe74ec: LoadField: d2 = r0->field_7
    //     0xbe74ec: ldur            d2, [x0, #7]
    // 0xbe74f0: stur            d2, [fp, #-0x28]
    // 0xbe74f4: fcmp            d2, d1
    // 0xbe74f8: b.le            #0xbe7608
    // 0xbe74fc: ldur            d0, [fp, #-0x18]
    // 0xbe7500: fdiv            d3, d0, d2
    // 0xbe7504: mov             v0.16b, v3.16b
    // 0xbe7508: stur            d3, [fp, #-0x20]
    // 0xbe750c: stp             fp, lr, [SP, #-0x10]!
    // 0xbe7510: mov             fp, SP
    // 0xbe7514: CallRuntime_LibcRound(double) -> double
    //     0xbe7514: and             SP, SP, #0xfffffffffffffff0
    //     0xbe7518: mov             sp, SP
    //     0xbe751c: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0xbe7520: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbe7524: blr             x16
    //     0xbe7528: mov             x16, #8
    //     0xbe752c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xbe7530: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xbe7534: sub             sp, x16, #1, lsl #12
    //     0xbe7538: mov             SP, fp
    //     0xbe753c: ldp             fp, lr, [SP], #0x10
    // 0xbe7540: fcmp            d0, d0
    // 0xbe7544: b.vs            #0xbe7688
    // 0xbe7548: fcvtzs          x0, d0
    // 0xbe754c: asr             x16, x0, #0x1e
    // 0xbe7550: cmp             x16, x0, asr #63
    // 0xbe7554: b.ne            #0xbe7688
    // 0xbe7558: lsl             x0, x0, #1
    // 0xbe755c: ldur            d1, [fp, #-0x20]
    // 0xbe7560: ldur            d0, [fp, #-0x28]
    // 0xbe7564: fmul            d2, d1, d0
    // 0xbe7568: r1 = LoadInt32Instr(r0)
    //     0xbe7568: sbfx            x1, x0, #1, #0x1f
    //     0xbe756c: tbz             w0, #0, #0xbe7574
    //     0xbe7570: ldur            x1, [x0, #7]
    // 0xbe7574: scvtf           d3, x1
    // 0xbe7578: fmul            d4, d3, d0
    // 0xbe757c: fsub            d0, d2, d4
    // 0xbe7580: d2 = 0.000000
    //     0xbe7580: eor             v2.16b, v2.16b, v2.16b
    // 0xbe7584: fcmp            d0, d2
    // 0xbe7588: b.ne            #0xbe759c
    // 0xbe758c: d3 = 0.000000
    //     0xbe758c: ldr             d3, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xbe7590: fcmp            d3, d2
    // 0xbe7594: b.le            #0xbe75d0
    // 0xbe7598: b               #0xbe75c0
    // 0xbe759c: d3 = 0.000000
    //     0xbe759c: ldr             d3, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xbe75a0: fcmp            d2, d0
    // 0xbe75a4: b.le            #0xbe75b8
    // 0xbe75a8: fneg            d2, d0
    // 0xbe75ac: fcmp            d3, d2
    // 0xbe75b0: b.le            #0xbe75d0
    // 0xbe75b4: b               #0xbe75c0
    // 0xbe75b8: fcmp            d3, d0
    // 0xbe75bc: b.le            #0xbe75d0
    // 0xbe75c0: mov             x0, x1
    // 0xbe75c4: LeaveFrame
    //     0xbe75c4: mov             SP, fp
    //     0xbe75c8: ldp             fp, lr, [SP], #0x10
    // 0xbe75cc: ret
    //     0xbe75cc: ret             
    // 0xbe75d0: fcmp            d1, d1
    // 0xbe75d4: b.vs            #0xbe76a4
    // 0xbe75d8: fcvtms          x0, d1
    // 0xbe75dc: asr             x16, x0, #0x1e
    // 0xbe75e0: cmp             x16, x0, asr #63
    // 0xbe75e4: b.ne            #0xbe76a4
    // 0xbe75e8: lsl             x0, x0, #1
    // 0xbe75ec: r1 = LoadInt32Instr(r0)
    //     0xbe75ec: sbfx            x1, x0, #1, #0x1f
    //     0xbe75f0: tbz             w0, #0, #0xbe75f8
    //     0xbe75f4: ldur            x1, [x0, #7]
    // 0xbe75f8: mov             x0, x1
    // 0xbe75fc: LeaveFrame
    //     0xbe75fc: mov             SP, fp
    //     0xbe7600: ldp             fp, lr, [SP], #0x10
    // 0xbe7604: ret
    //     0xbe7604: ret             
    // 0xbe7608: r0 = 0
    //     0xbe7608: mov             x0, #0
    // 0xbe760c: LeaveFrame
    //     0xbe760c: mov             SP, fp
    //     0xbe7610: ldp             fp, lr, [SP], #0x10
    // 0xbe7614: ret
    //     0xbe7614: ret             
    // 0xbe7618: r0 = StateError()
    //     0xbe7618: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe761c: mov             x1, x0
    // 0xbe7620: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe7620: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe7624: StoreField: r1->field_b = r0
    //     0xbe7624: stur            w0, [x1, #0xb]
    // 0xbe7628: mov             x0, x1
    // 0xbe762c: r0 = Throw()
    //     0xbe762c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe7630: brk             #0
    // 0xbe7634: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe7634: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe7638: r0 = StateError()
    //     0xbe7638: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe763c: mov             x1, x0
    // 0xbe7640: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe7640: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe7644: StoreField: r1->field_b = r0
    //     0xbe7644: stur            w0, [x1, #0xb]
    // 0xbe7648: mov             x0, x1
    // 0xbe764c: r0 = Throw()
    //     0xbe764c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe7650: brk             #0
    // 0xbe7654: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe7654: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe7658: b               #0xbe733c
    // 0xbe765c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe765c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe7660: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe7660: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe7664: SaveReg d0
    //     0xbe7664: str             q0, [SP, #-0x10]!
    // 0xbe7668: r0 = AllocateDouble()
    //     0xbe7668: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe766c: RestoreReg d0
    //     0xbe766c: ldr             q0, [SP], #0x10
    // 0xbe7670: b               #0xbe7430
    // 0xbe7674: SaveReg d0
    //     0xbe7674: str             q0, [SP, #-0x10]!
    // 0xbe7678: r0 = AllocateDouble()
    //     0xbe7678: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe767c: RestoreReg d0
    //     0xbe767c: ldr             q0, [SP], #0x10
    // 0xbe7680: b               #0xbe74dc
    // 0xbe7684: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe7684: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe7688: SaveReg d0
    //     0xbe7688: str             q0, [SP, #-0x10]!
    // 0xbe768c: r0 = 76
    //     0xbe768c: mov             x0, #0x4c
    // 0xbe7690: r30 = DoubleToIntegerStub
    //     0xbe7690: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbe7694: LoadField: r30 = r30->field_7
    //     0xbe7694: ldur            lr, [lr, #7]
    // 0xbe7698: blr             lr
    // 0xbe769c: RestoreReg d0
    //     0xbe769c: ldr             q0, [SP], #0x10
    // 0xbe76a0: b               #0xbe755c
    // 0xbe76a4: SaveReg d1
    //     0xbe76a4: str             q1, [SP, #-0x10]!
    // 0xbe76a8: d0 = 0.000000
    //     0xbe76a8: fmov            d0, d1
    // 0xbe76ac: r0 = 70
    //     0xbe76ac: mov             x0, #0x46
    // 0xbe76b0: r30 = DoubleToIntegerStub
    //     0xbe76b0: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbe76b4: LoadField: r30 = r30->field_7
    //     0xbe76b4: ldur            lr, [lr, #7]
    // 0xbe76b8: blr             lr
    // 0xbe76bc: RestoreReg d1
    //     0xbe76bc: ldr             q1, [SP], #0x10
    // 0xbe76c0: b               #0xbe75ec
  }
  _ paintExtentOf(/* No info */) {
    // ** addr: 0x1185b70, size: 0x24c
    // 0x1185b70: EnterFrame
    //     0x1185b70: stp             fp, lr, [SP, #-0x10]!
    //     0x1185b74: mov             fp, SP
    // 0x1185b78: AllocStack(0x10)
    //     0x1185b78: sub             SP, SP, #0x10
    // 0x1185b7c: SetupParameters(RenderSliverFixedExtentBoxAdaptor this /* r1 => r3, fp-0x10 */)
    //     0x1185b7c: mov             x3, x1
    //     0x1185b80: stur            x1, [fp, #-0x10]
    // 0x1185b84: CheckStackOverflow
    //     0x1185b84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1185b88: cmp             SP, x16
    //     0x1185b8c: b.ls            #0x1185d88
    // 0x1185b90: r0 = LoadClassIdInstr(r3)
    //     0x1185b90: ldur            x0, [x3, #-1]
    //     0x1185b94: ubfx            x0, x0, #0xc, #0x14
    // 0x1185b98: r17 = -4702
    //     0x1185b98: mov             x17, #-0x125e
    // 0x1185b9c: add             x16, x0, x17
    // 0x1185ba0: cmp             x16, #1
    // 0x1185ba4: b.ls            #0x1185bb4
    // 0x1185ba8: r17 = 4700
    //     0x1185ba8: mov             x17, #0x125c
    // 0x1185bac: cmp             x0, x17
    // 0x1185bb0: b.eq            #0x1185bb4
    // 0x1185bb4: r17 = 4700
    //     0x1185bb4: mov             x17, #0x125c
    // 0x1185bb8: cmp             x0, x17
    // 0x1185bbc: b.ne            #0x1185c8c
    // 0x1185bc0: LoadField: r4 = r3->field_27
    //     0x1185bc0: ldur            w4, [x3, #0x27]
    // 0x1185bc4: DecompressPointer r4
    //     0x1185bc4: add             x4, x4, HEAP, lsl #32
    // 0x1185bc8: stur            x4, [fp, #-8]
    // 0x1185bcc: cmp             w4, NULL
    // 0x1185bd0: b.eq            #0x1185d4c
    // 0x1185bd4: mov             x0, x4
    // 0x1185bd8: r2 = Null
    //     0x1185bd8: mov             x2, NULL
    // 0x1185bdc: r1 = Null
    //     0x1185bdc: mov             x1, NULL
    // 0x1185be0: r4 = LoadClassIdInstr(r0)
    //     0x1185be0: ldur            x4, [x0, #-1]
    //     0x1185be4: ubfx            x4, x4, #0xc, #0x14
    // 0x1185be8: cmp             x4, #0xb45
    // 0x1185bec: b.eq            #0x1185c04
    // 0x1185bf0: r8 = SliverConstraints
    //     0x1185bf0: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x1185bf4: ldr             x8, [x8, #0x3c0]
    // 0x1185bf8: r3 = Null
    //     0x1185bf8: add             x3, PP, #0xab, lsl #12  ; [pp+0xab6e0] Null
    //     0x1185bfc: ldr             x3, [x3, #0x6e0]
    // 0x1185c00: r0 = DefaultTypeTest()
    //     0x1185c00: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1185c04: ldur            x1, [fp, #-8]
    // 0x1185c08: r0 = axis()
    //     0x1185c08: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x1185c0c: r16 = Instance_Axis
    //     0x1185c0c: ldr             x16, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0x1185c10: cmp             w0, w16
    // 0x1185c14: b.ne            #0x1185c3c
    // 0x1185c18: ldur            x1, [fp, #-0x10]
    // 0x1185c1c: LoadField: r0 = r1->field_63
    //     0x1185c1c: ldur            w0, [x1, #0x63]
    // 0x1185c20: DecompressPointer r0
    //     0x1185c20: add             x0, x0, HEAP, lsl #32
    // 0x1185c24: cmp             w0, NULL
    // 0x1185c28: b.eq            #0x1185d90
    // 0x1185c2c: mov             x1, x0
    // 0x1185c30: r0 = size()
    //     0x1185c30: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x1185c34: LoadField: d0 = r0->field_f
    //     0x1185c34: ldur            d0, [x0, #0xf]
    // 0x1185c38: b               #0x1185c5c
    // 0x1185c3c: ldur            x1, [fp, #-0x10]
    // 0x1185c40: LoadField: r0 = r1->field_63
    //     0x1185c40: ldur            w0, [x1, #0x63]
    // 0x1185c44: DecompressPointer r0
    //     0x1185c44: add             x0, x0, HEAP, lsl #32
    // 0x1185c48: cmp             w0, NULL
    // 0x1185c4c: b.eq            #0x1185d94
    // 0x1185c50: mov             x1, x0
    // 0x1185c54: r0 = size()
    //     0x1185c54: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x1185c58: LoadField: d0 = r0->field_7
    //     0x1185c58: ldur            d0, [x0, #7]
    // 0x1185c5c: r0 = inline_Allocate_Double()
    //     0x1185c5c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1185c60: add             x0, x0, #0x10
    //     0x1185c64: cmp             x1, x0
    //     0x1185c68: b.ls            #0x1185d98
    //     0x1185c6c: str             x0, [THR, #0x60]  ; THR::top
    //     0x1185c70: sub             x0, x0, #0xf
    //     0x1185c74: mov             x1, #0xe19c
    //     0x1185c78: movk            x1, #3, lsl #16
    //     0x1185c7c: stur            x1, [x0, #-1]
    // 0x1185c80: dmb             ishst
    // 0x1185c84: StoreField: r0->field_7 = d0
    //     0x1185c84: stur            d0, [x0, #7]
    // 0x1185c88: b               #0x1185d34
    // 0x1185c8c: mov             x1, x3
    // 0x1185c90: r17 = 4701
    //     0x1185c90: mov             x17, #0x125d
    // 0x1185c94: cmp             x0, x17
    // 0x1185c98: b.ne            #0x1185ca4
    // 0x1185c9c: r0 = Null
    //     0x1185c9c: mov             x0, NULL
    // 0x1185ca0: b               #0x1185d34
    // 0x1185ca4: r17 = 4702
    //     0x1185ca4: mov             x17, #0x125e
    // 0x1185ca8: cmp             x0, x17
    // 0x1185cac: b.ne            #0x1185cbc
    // 0x1185cb0: LoadField: r0 = r1->field_63
    //     0x1185cb0: ldur            w0, [x1, #0x63]
    // 0x1185cb4: DecompressPointer r0
    //     0x1185cb4: add             x0, x0, HEAP, lsl #32
    // 0x1185cb8: b               #0x1185d34
    // 0x1185cbc: LoadField: r3 = r1->field_27
    //     0x1185cbc: ldur            w3, [x1, #0x27]
    // 0x1185cc0: DecompressPointer r3
    //     0x1185cc0: add             x3, x3, HEAP, lsl #32
    // 0x1185cc4: stur            x3, [fp, #-8]
    // 0x1185cc8: cmp             w3, NULL
    // 0x1185ccc: b.eq            #0x1185d68
    // 0x1185cd0: mov             x0, x3
    // 0x1185cd4: r2 = Null
    //     0x1185cd4: mov             x2, NULL
    // 0x1185cd8: r1 = Null
    //     0x1185cd8: mov             x1, NULL
    // 0x1185cdc: r4 = LoadClassIdInstr(r0)
    //     0x1185cdc: ldur            x4, [x0, #-1]
    //     0x1185ce0: ubfx            x4, x4, #0xc, #0x14
    // 0x1185ce4: cmp             x4, #0xb45
    // 0x1185ce8: b.eq            #0x1185d00
    // 0x1185cec: r8 = SliverConstraints
    //     0x1185cec: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x1185cf0: ldr             x8, [x8, #0x3c0]
    // 0x1185cf4: r3 = Null
    //     0x1185cf4: add             x3, PP, #0xab, lsl #12  ; [pp+0xab6f0] Null
    //     0x1185cf8: ldr             x3, [x3, #0x6f0]
    // 0x1185cfc: r0 = DefaultTypeTest()
    //     0x1185cfc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1185d00: ldur            x0, [fp, #-8]
    // 0x1185d04: LoadField: d0 = r0->field_3f
    //     0x1185d04: ldur            d0, [x0, #0x3f]
    // 0x1185d08: r0 = inline_Allocate_Double()
    //     0x1185d08: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x1185d0c: add             x0, x0, #0x10
    //     0x1185d10: cmp             x1, x0
    //     0x1185d14: b.ls            #0x1185da8
    //     0x1185d18: str             x0, [THR, #0x60]  ; THR::top
    //     0x1185d1c: sub             x0, x0, #0xf
    //     0x1185d20: mov             x1, #0xe19c
    //     0x1185d24: movk            x1, #3, lsl #16
    //     0x1185d28: stur            x1, [x0, #-1]
    // 0x1185d2c: dmb             ishst
    // 0x1185d30: StoreField: r0->field_7 = d0
    //     0x1185d30: stur            d0, [x0, #7]
    // 0x1185d34: cmp             w0, NULL
    // 0x1185d38: b.eq            #0x1185db8
    // 0x1185d3c: LoadField: d0 = r0->field_7
    //     0x1185d3c: ldur            d0, [x0, #7]
    // 0x1185d40: LeaveFrame
    //     0x1185d40: mov             SP, fp
    //     0x1185d44: ldp             fp, lr, [SP], #0x10
    // 0x1185d48: ret
    //     0x1185d48: ret             
    // 0x1185d4c: r0 = StateError()
    //     0x1185d4c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x1185d50: mov             x1, x0
    // 0x1185d54: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x1185d54: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x1185d58: StoreField: r1->field_b = r0
    //     0x1185d58: stur            w0, [x1, #0xb]
    // 0x1185d5c: mov             x0, x1
    // 0x1185d60: r0 = Throw()
    //     0x1185d60: bl              #0x13ddb2c  ; ThrowStub
    // 0x1185d64: brk             #0
    // 0x1185d68: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x1185d68: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x1185d6c: r0 = StateError()
    //     0x1185d6c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x1185d70: mov             x1, x0
    // 0x1185d74: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x1185d74: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x1185d78: StoreField: r1->field_b = r0
    //     0x1185d78: stur            w0, [x1, #0xb]
    // 0x1185d7c: mov             x0, x1
    // 0x1185d80: r0 = Throw()
    //     0x1185d80: bl              #0x13ddb2c  ; ThrowStub
    // 0x1185d84: brk             #0
    // 0x1185d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1185d88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1185d8c: b               #0x1185b90
    // 0x1185d90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1185d90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1185d94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1185d94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1185d98: SaveReg d0
    //     0x1185d98: str             q0, [SP, #-0x10]!
    // 0x1185d9c: r0 = AllocateDouble()
    //     0x1185d9c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1185da0: RestoreReg d0
    //     0x1185da0: ldr             q0, [SP], #0x10
    // 0x1185da4: b               #0x1185c84
    // 0x1185da8: SaveReg d0
    //     0x1185da8: str             q0, [SP, #-0x10]!
    // 0x1185dac: r0 = AllocateDouble()
    //     0x1185dac: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1185db0: RestoreReg d0
    //     0x1185db0: ldr             q0, [SP], #0x10
    // 0x1185db4: b               #0x1185d30
    // 0x1185db8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1185db8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
