// lib: , url: package:flutter/src/rendering/mouse_tracker.dart

// class id: 1049033, size: 0x8
class :: {
}

// class id: 2863, size: 0x10, field offset: 0x8
class _MouseState extends Object {

  _ replaceAnnotations(/* No info */) {
    // ** addr: 0x8363f0, size: 0x38
    // 0x8363f0: mov             x0, x2
    // 0x8363f4: LoadField: r2 = r1->field_7
    //     0x8363f4: ldur            w2, [x1, #7]
    // 0x8363f8: DecompressPointer r2
    //     0x8363f8: add             x2, x2, HEAP, lsl #32
    // 0x8363fc: StoreField: r1->field_7 = r0
    //     0x8363fc: stur            w0, [x1, #7]
    //     0x836400: ldurb           w16, [x1, #-1]
    //     0x836404: ldurb           w17, [x0, #-1]
    //     0x836408: and             x16, x17, x16, lsr #2
    //     0x83640c: tst             x16, HEAP, lsr #32
    //     0x836410: b.eq            #0x836420
    //     0x836414: str             lr, [SP, #-8]!
    //     0x836418: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0x83641c: ldr             lr, [SP], #8
    // 0x836420: mov             x0, x2
    // 0x836424: ret
    //     0x836424: ret             
  }
  _ replaceLatestEvent(/* No info */) {
    // ** addr: 0x8365f8, size: 0x38
    // 0x8365f8: mov             x0, x2
    // 0x8365fc: LoadField: r2 = r1->field_b
    //     0x8365fc: ldur            w2, [x1, #0xb]
    // 0x836600: DecompressPointer r2
    //     0x836600: add             x2, x2, HEAP, lsl #32
    // 0x836604: StoreField: r1->field_b = r0
    //     0x836604: stur            w0, [x1, #0xb]
    //     0x836608: ldurb           w16, [x1, #-1]
    //     0x83660c: ldurb           w17, [x0, #-1]
    //     0x836610: and             x16, x17, x16, lsr #2
    //     0x836614: tst             x16, HEAP, lsr #32
    //     0x836618: b.eq            #0x836628
    //     0x83661c: str             lr, [SP, #-8]!
    //     0x836620: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0x836624: ldr             lr, [SP], #8
    // 0x836628: mov             x0, x2
    // 0x83662c: ret
    //     0x83662c: ret             
  }
  get _ device(/* No info */) {
    // ** addr: 0x87dcc0, size: 0x58
    // 0x87dcc0: EnterFrame
    //     0x87dcc0: stp             fp, lr, [SP, #-0x10]!
    //     0x87dcc4: mov             fp, SP
    // 0x87dcc8: CheckStackOverflow
    //     0x87dcc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87dccc: cmp             SP, x16
    //     0x87dcd0: b.ls            #0x87dd10
    // 0x87dcd4: LoadField: r0 = r1->field_b
    //     0x87dcd4: ldur            w0, [x1, #0xb]
    // 0x87dcd8: DecompressPointer r0
    //     0x87dcd8: add             x0, x0, HEAP, lsl #32
    // 0x87dcdc: r1 = LoadClassIdInstr(r0)
    //     0x87dcdc: ldur            x1, [x0, #-1]
    //     0x87dce0: ubfx            x1, x1, #0xc, #0x14
    // 0x87dce4: mov             x16, x0
    // 0x87dce8: mov             x0, x1
    // 0x87dcec: mov             x1, x16
    // 0x87dcf0: r0 = GDT[cid_x0 + 0x15a90]()
    //     0x87dcf0: mov             x17, #0x5a90
    //     0x87dcf4: movk            x17, #1, lsl #16
    //     0x87dcf8: add             lr, x0, x17
    //     0x87dcfc: ldr             lr, [x21, lr, lsl #3]
    //     0x87dd00: blr             lr
    // 0x87dd04: LeaveFrame
    //     0x87dd04: mov             SP, fp
    //     0x87dd08: ldp             fp, lr, [SP], #0x10
    // 0x87dd0c: ret
    //     0x87dd0c: ret             
    // 0x87dd10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87dd10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87dd14: b               #0x87dcd4
  }
}

// class id: 4478, size: 0x30, field offset: 0x24
class MouseTracker extends ChangeNotifier {

  _ updateWithEvent(/* No info */) {
    // ** addr: 0x83374c, size: 0x360
    // 0x83374c: EnterFrame
    //     0x83374c: stp             fp, lr, [SP, #-0x10]!
    //     0x833750: mov             fp, SP
    // 0x833754: AllocStack(0x40)
    //     0x833754: sub             SP, SP, #0x40
    // 0x833758: SetupParameters(MouseTracker this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x833758: mov             x0, x1
    //     0x83375c: stur            x1, [fp, #-8]
    //     0x833760: mov             x1, x2
    //     0x833764: stur            x2, [fp, #-0x10]
    //     0x833768: stur            x3, [fp, #-0x18]
    // 0x83376c: CheckStackOverflow
    //     0x83376c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833770: cmp             SP, x16
    //     0x833774: b.ls            #0x833aa4
    // 0x833778: r1 = 5
    //     0x833778: mov             x1, #5
    // 0x83377c: r0 = AllocateContext()
    //     0x83377c: bl              #0x13de838  ; AllocateContextStub
    // 0x833780: mov             x3, x0
    // 0x833784: ldur            x2, [fp, #-8]
    // 0x833788: stur            x3, [fp, #-0x20]
    // 0x83378c: StoreField: r3->field_f = r2
    //     0x83378c: stur            w2, [x3, #0xf]
    // 0x833790: ldur            x1, [fp, #-0x10]
    // 0x833794: StoreField: r3->field_13 = r1
    //     0x833794: stur            w1, [x3, #0x13]
    // 0x833798: r0 = LoadClassIdInstr(r1)
    //     0x833798: ldur            x0, [x1, #-1]
    //     0x83379c: ubfx            x0, x0, #0xc, #0x14
    // 0x8337a0: r0 = GDT[cid_x0 + 0x15e74]()
    //     0x8337a0: mov             x17, #0x5e74
    //     0x8337a4: movk            x17, #1, lsl #16
    //     0x8337a8: add             lr, x0, x17
    //     0x8337ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8337b0: blr             lr
    // 0x8337b4: r16 = Instance_PointerDeviceKind
    //     0x8337b4: ldr             x16, [PP, #0x4328]  ; [pp+0x4328] Obj!PointerDeviceKind@12c7b41
    // 0x8337b8: cmp             w0, w16
    // 0x8337bc: b.eq            #0x833804
    // 0x8337c0: ldur            x2, [fp, #-0x20]
    // 0x8337c4: LoadField: r1 = r2->field_13
    //     0x8337c4: ldur            w1, [x2, #0x13]
    // 0x8337c8: DecompressPointer r1
    //     0x8337c8: add             x1, x1, HEAP, lsl #32
    // 0x8337cc: r0 = LoadClassIdInstr(r1)
    //     0x8337cc: ldur            x0, [x1, #-1]
    //     0x8337d0: ubfx            x0, x0, #0xc, #0x14
    // 0x8337d4: r0 = GDT[cid_x0 + 0x15e74]()
    //     0x8337d4: mov             x17, #0x5e74
    //     0x8337d8: movk            x17, #1, lsl #16
    //     0x8337dc: add             lr, x0, x17
    //     0x8337e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8337e4: blr             lr
    // 0x8337e8: r16 = Instance_PointerDeviceKind
    //     0x8337e8: ldr             x16, [PP, #0x4330]  ; [pp+0x4330] Obj!PointerDeviceKind@12c7b21
    // 0x8337ec: cmp             w0, w16
    // 0x8337f0: b.eq            #0x833804
    // 0x8337f4: r0 = Null
    //     0x8337f4: mov             x0, NULL
    // 0x8337f8: LeaveFrame
    //     0x8337f8: mov             SP, fp
    //     0x8337fc: ldp             fp, lr, [SP], #0x10
    // 0x833800: ret
    //     0x833800: ret             
    // 0x833804: ldur            x3, [fp, #-0x20]
    // 0x833808: LoadField: r4 = r3->field_13
    //     0x833808: ldur            w4, [x3, #0x13]
    // 0x83380c: DecompressPointer r4
    //     0x83380c: add             x4, x4, HEAP, lsl #32
    // 0x833810: mov             x0, x4
    // 0x833814: stur            x4, [fp, #-0x10]
    // 0x833818: r2 = Null
    //     0x833818: mov             x2, NULL
    // 0x83381c: r1 = Null
    //     0x83381c: mov             x1, NULL
    // 0x833820: cmp             w0, NULL
    // 0x833824: b.eq            #0x833850
    // 0x833828: branchIfSmi(r0, 0x833850)
    //     0x833828: tbz             w0, #0, #0x833850
    // 0x83382c: r3 = LoadClassIdInstr(r0)
    //     0x83382c: ldur            x3, [x0, #-1]
    //     0x833830: ubfx            x3, x3, #0xc, #0x14
    // 0x833834: r17 = -4148
    //     0x833834: mov             x17, #-0x1034
    // 0x833838: add             x3, x3, x17
    // 0x83383c: cmp             x3, #5
    // 0x833840: b.ls            #0x833858
    // 0x833844: sub             x3, x3, #0x458
    // 0x833848: cmp             x3, #4
    // 0x83384c: b.ls            #0x833858
    // 0x833850: r0 = false
    //     0x833850: add             x0, NULL, #0x30  ; false
    // 0x833854: b               #0x83385c
    // 0x833858: r0 = true
    //     0x833858: add             x0, NULL, #0x20  ; true
    // 0x83385c: tbnz            w0, #4, #0x833870
    // 0x833860: r0 = Null
    //     0x833860: mov             x0, NULL
    // 0x833864: LeaveFrame
    //     0x833864: mov             SP, fp
    //     0x833868: ldp             fp, lr, [SP], #0x10
    // 0x83386c: ret
    //     0x83386c: ret             
    // 0x833870: ldur            x0, [fp, #-0x10]
    // 0x833874: r2 = Null
    //     0x833874: mov             x2, NULL
    // 0x833878: r1 = Null
    //     0x833878: mov             x1, NULL
    // 0x83387c: cmp             w0, NULL
    // 0x833880: b.eq            #0x8338a8
    // 0x833884: branchIfSmi(r0, 0x8338a8)
    //     0x833884: tbz             w0, #0, #0x8338a8
    // 0x833888: r3 = LoadClassIdInstr(r0)
    //     0x833888: ldur            x3, [x0, #-1]
    //     0x83388c: ubfx            x3, x3, #0xc, #0x14
    // 0x833890: r17 = 4167
    //     0x833890: mov             x17, #0x1047
    // 0x833894: cmp             x3, x17
    // 0x833898: b.eq            #0x8338b0
    // 0x83389c: r17 = 5296
    //     0x83389c: mov             x17, #0x14b0
    // 0x8338a0: cmp             x3, x17
    // 0x8338a4: b.eq            #0x8338b0
    // 0x8338a8: r0 = false
    //     0x8338a8: add             x0, NULL, #0x30  ; false
    // 0x8338ac: b               #0x8338b4
    // 0x8338b0: r0 = true
    //     0x8338b0: add             x0, NULL, #0x20  ; true
    // 0x8338b4: tbnz            w0, #4, #0x8338d0
    // 0x8338b8: r0 = HitTestResult()
    //     0x8338b8: bl              #0x836ee0  ; AllocateHitTestResultStub -> HitTestResult (size=0x14)
    // 0x8338bc: mov             x1, x0
    // 0x8338c0: stur            x0, [fp, #-0x28]
    // 0x8338c4: r0 = HitTestResult()
    //     0x8338c4: bl              #0x836bac  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::HitTestResult
    // 0x8338c8: ldur            x0, [fp, #-0x28]
    // 0x8338cc: b               #0x833974
    // 0x8338d0: ldur            x0, [fp, #-0x18]
    // 0x8338d4: cmp             w0, NULL
    // 0x8338d8: b.ne            #0x833974
    // 0x8338dc: ldur            x3, [fp, #-8]
    // 0x8338e0: ldur            x2, [fp, #-0x20]
    // 0x8338e4: ldur            x1, [fp, #-0x10]
    // 0x8338e8: r0 = LoadClassIdInstr(r1)
    //     0x8338e8: ldur            x0, [x1, #-1]
    //     0x8338ec: ubfx            x0, x0, #0xc, #0x14
    // 0x8338f0: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x8338f0: mov             x17, #0x3f27
    //     0x8338f4: movk            x17, #1, lsl #16
    //     0x8338f8: add             lr, x0, x17
    //     0x8338fc: ldr             lr, [x21, lr, lsl #3]
    //     0x833900: blr             lr
    // 0x833904: mov             x3, x0
    // 0x833908: ldur            x2, [fp, #-0x20]
    // 0x83390c: stur            x3, [fp, #-0x10]
    // 0x833910: LoadField: r1 = r2->field_13
    //     0x833910: ldur            w1, [x2, #0x13]
    // 0x833914: DecompressPointer r1
    //     0x833914: add             x1, x1, HEAP, lsl #32
    // 0x833918: r0 = LoadClassIdInstr(r1)
    //     0x833918: ldur            x0, [x1, #-1]
    //     0x83391c: ubfx            x0, x0, #0xc, #0x14
    // 0x833920: r0 = GDT[cid_x0 + 0x149dc]()
    //     0x833920: mov             x17, #0x49dc
    //     0x833924: movk            x17, #1, lsl #16
    //     0x833928: add             lr, x0, x17
    //     0x83392c: ldr             lr, [x21, lr, lsl #3]
    //     0x833930: blr             lr
    // 0x833934: mov             x3, x0
    // 0x833938: ldur            x2, [fp, #-8]
    // 0x83393c: LoadField: r4 = r2->field_23
    //     0x83393c: ldur            w4, [x2, #0x23]
    // 0x833940: DecompressPointer r4
    //     0x833940: add             x4, x4, HEAP, lsl #32
    // 0x833944: r0 = BoxInt64Instr(r3)
    //     0x833944: sbfiz           x0, x3, #1, #0x1f
    //     0x833948: cmp             x3, x0, asr #1
    //     0x83394c: b.eq            #0x833958
    //     0x833950: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x833954: stur            x3, [x0, #7]
    // 0x833958: ldur            x16, [fp, #-0x10]
    // 0x83395c: stp             x16, x4, [SP, #8]
    // 0x833960: str             x0, [SP]
    // 0x833964: mov             x0, x4
    // 0x833968: ClosureCall
    //     0x833968: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x83396c: ldur            x2, [x0, #0x1f]
    //     0x833970: blr             x2
    // 0x833974: ldur            x2, [fp, #-8]
    // 0x833978: ldur            x3, [fp, #-0x20]
    // 0x83397c: ArrayStore: r3[0] = r0  ; List_4
    //     0x83397c: stur            w0, [x3, #0x17]
    //     0x833980: tbz             w0, #0, #0x83399c
    //     0x833984: ldurb           w16, [x3, #-1]
    //     0x833988: ldurb           w17, [x0, #-1]
    //     0x83398c: and             x16, x17, x16, lsr #2
    //     0x833990: tst             x16, HEAP, lsr #32
    //     0x833994: b.eq            #0x83399c
    //     0x833998: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x83399c: LoadField: r1 = r3->field_13
    //     0x83399c: ldur            w1, [x3, #0x13]
    // 0x8339a0: DecompressPointer r1
    //     0x8339a0: add             x1, x1, HEAP, lsl #32
    // 0x8339a4: r0 = LoadClassIdInstr(r1)
    //     0x8339a4: ldur            x0, [x1, #-1]
    //     0x8339a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8339ac: r0 = GDT[cid_x0 + 0x15a90]()
    //     0x8339ac: mov             x17, #0x5a90
    //     0x8339b0: movk            x17, #1, lsl #16
    //     0x8339b4: add             lr, x0, x17
    //     0x8339b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8339bc: blr             lr
    // 0x8339c0: mov             x2, x0
    // 0x8339c4: r0 = BoxInt64Instr(r2)
    //     0x8339c4: sbfiz           x0, x2, #1, #0x1f
    //     0x8339c8: cmp             x2, x0, asr #1
    //     0x8339cc: b.eq            #0x8339d8
    //     0x8339d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8339d4: stur            x2, [x0, #7]
    // 0x8339d8: mov             x1, x0
    // 0x8339dc: ldur            x3, [fp, #-0x20]
    // 0x8339e0: StoreField: r3->field_1b = r0
    //     0x8339e0: stur            w0, [x3, #0x1b]
    //     0x8339e4: tbz             w0, #0, #0x833a00
    //     0x8339e8: ldurb           w16, [x3, #-1]
    //     0x8339ec: ldurb           w17, [x0, #-1]
    //     0x8339f0: and             x16, x17, x16, lsr #2
    //     0x8339f4: tst             x16, HEAP, lsr #32
    //     0x8339f8: b.eq            #0x833a00
    //     0x8339fc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x833a00: ldur            x0, [fp, #-8]
    // 0x833a04: LoadField: r4 = r0->field_2b
    //     0x833a04: ldur            w4, [x0, #0x2b]
    // 0x833a08: DecompressPointer r4
    //     0x833a08: add             x4, x4, HEAP, lsl #32
    // 0x833a0c: mov             x2, x1
    // 0x833a10: mov             x1, x4
    // 0x833a14: stur            x4, [fp, #-0x10]
    // 0x833a18: r0 = _getValueOrData()
    //     0x833a18: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x833a1c: mov             x1, x0
    // 0x833a20: ldur            x0, [fp, #-0x10]
    // 0x833a24: LoadField: r2 = r0->field_f
    //     0x833a24: ldur            w2, [x0, #0xf]
    // 0x833a28: DecompressPointer r2
    //     0x833a28: add             x2, x2, HEAP, lsl #32
    // 0x833a2c: cmp             w2, w1
    // 0x833a30: b.ne            #0x833a38
    // 0x833a34: r1 = Null
    //     0x833a34: mov             x1, NULL
    // 0x833a38: ldur            x3, [fp, #-0x20]
    // 0x833a3c: mov             x0, x1
    // 0x833a40: StoreField: r3->field_1f = r0
    //     0x833a40: stur            w0, [x3, #0x1f]
    //     0x833a44: ldurb           w16, [x3, #-1]
    //     0x833a48: ldurb           w17, [x0, #-1]
    //     0x833a4c: and             x16, x17, x16, lsr #2
    //     0x833a50: tst             x16, HEAP, lsr #32
    //     0x833a54: b.eq            #0x833a5c
    //     0x833a58: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x833a5c: LoadField: r2 = r3->field_13
    //     0x833a5c: ldur            w2, [x3, #0x13]
    // 0x833a60: DecompressPointer r2
    //     0x833a60: add             x2, x2, HEAP, lsl #32
    // 0x833a64: r0 = _shouldMarkStateDirty()
    //     0x833a64: bl              #0x8347c8  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_shouldMarkStateDirty
    // 0x833a68: tbz             w0, #4, #0x833a7c
    // 0x833a6c: r0 = Null
    //     0x833a6c: mov             x0, NULL
    // 0x833a70: LeaveFrame
    //     0x833a70: mov             SP, fp
    //     0x833a74: ldp             fp, lr, [SP], #0x10
    // 0x833a78: ret
    //     0x833a78: ret             
    // 0x833a7c: ldur            x2, [fp, #-0x20]
    // 0x833a80: r1 = Function '<anonymous closure>':.
    //     0x833a80: ldr             x1, [PP, #0x4338]  ; [pp+0x4338] AnonymousClosure: (0x834974), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::updateWithEvent (0x83374c)
    // 0x833a84: r0 = AllocateClosure()
    //     0x833a84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x833a88: ldur            x1, [fp, #-8]
    // 0x833a8c: mov             x2, x0
    // 0x833a90: r0 = _monitorMouseConnection()
    //     0x833a90: bl              #0x833b20  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_monitorMouseConnection
    // 0x833a94: r0 = Null
    //     0x833a94: mov             x0, NULL
    // 0x833a98: LeaveFrame
    //     0x833a98: mov             SP, fp
    //     0x833a9c: ldp             fp, lr, [SP], #0x10
    // 0x833aa0: ret
    //     0x833aa0: ret             
    // 0x833aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833aa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833aa8: b               #0x833778
  }
  _ _monitorMouseConnection(/* No info */) {
    // ** addr: 0x833b20, size: 0xc0
    // 0x833b20: EnterFrame
    //     0x833b20: stp             fp, lr, [SP, #-0x10]!
    //     0x833b24: mov             fp, SP
    // 0x833b28: AllocStack(0x20)
    //     0x833b28: sub             SP, SP, #0x20
    // 0x833b2c: SetupParameters(MouseTracker this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r0 */)
    //     0x833b2c: mov             x0, x2
    //     0x833b30: stur            x1, [fp, #-0x18]
    // 0x833b34: CheckStackOverflow
    //     0x833b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x833b38: cmp             SP, x16
    //     0x833b3c: b.ls            #0x833bd8
    // 0x833b40: LoadField: r2 = r1->field_2b
    //     0x833b40: ldur            w2, [x1, #0x2b]
    // 0x833b44: DecompressPointer r2
    //     0x833b44: add             x2, x2, HEAP, lsl #32
    // 0x833b48: stur            x2, [fp, #-0x10]
    // 0x833b4c: LoadField: r3 = r2->field_13
    //     0x833b4c: ldur            w3, [x2, #0x13]
    // 0x833b50: r4 = LoadInt32Instr(r3)
    //     0x833b50: sbfx            x4, x3, #1, #0x1f
    // 0x833b54: asr             x3, x4, #1
    // 0x833b58: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x833b58: ldur            w4, [x2, #0x17]
    // 0x833b5c: r5 = LoadInt32Instr(r4)
    //     0x833b5c: sbfx            x5, x4, #1, #0x1f
    // 0x833b60: sub             x4, x3, x5
    // 0x833b64: cbnz            x4, #0x833b70
    // 0x833b68: r3 = false
    //     0x833b68: add             x3, NULL, #0x30  ; false
    // 0x833b6c: b               #0x833b74
    // 0x833b70: r3 = true
    //     0x833b70: add             x3, NULL, #0x20  ; true
    // 0x833b74: stur            x3, [fp, #-8]
    // 0x833b78: str             x0, [SP]
    // 0x833b7c: ClosureCall
    //     0x833b7c: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x833b80: ldur            x2, [x0, #0x1f]
    //     0x833b84: blr             x2
    // 0x833b88: ldur            x0, [fp, #-0x10]
    // 0x833b8c: LoadField: r1 = r0->field_13
    //     0x833b8c: ldur            w1, [x0, #0x13]
    // 0x833b90: r2 = LoadInt32Instr(r1)
    //     0x833b90: sbfx            x2, x1, #1, #0x1f
    // 0x833b94: asr             x1, x2, #1
    // 0x833b98: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x833b98: ldur            w2, [x0, #0x17]
    // 0x833b9c: r0 = LoadInt32Instr(r2)
    //     0x833b9c: sbfx            x0, x2, #1, #0x1f
    // 0x833ba0: sub             x2, x1, x0
    // 0x833ba4: cbnz            x2, #0x833bb0
    // 0x833ba8: r0 = false
    //     0x833ba8: add             x0, NULL, #0x30  ; false
    // 0x833bac: b               #0x833bb4
    // 0x833bb0: r0 = true
    //     0x833bb0: add             x0, NULL, #0x20  ; true
    // 0x833bb4: ldur            x1, [fp, #-8]
    // 0x833bb8: cmp             w1, w0
    // 0x833bbc: b.eq            #0x833bc8
    // 0x833bc0: ldur            x1, [fp, #-0x18]
    // 0x833bc4: r0 = notifyListeners()
    //     0x833bc4: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x833bc8: r0 = Null
    //     0x833bc8: mov             x0, NULL
    // 0x833bcc: LeaveFrame
    //     0x833bcc: mov             SP, fp
    //     0x833bd0: ldp             fp, lr, [SP], #0x10
    // 0x833bd4: ret
    //     0x833bd4: ret             
    // 0x833bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x833bd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x833bdc: b               #0x833b40
  }
  static _ _shouldMarkStateDirty(/* No info */) {
    // ** addr: 0x8347c8, size: 0x1ac
    // 0x8347c8: EnterFrame
    //     0x8347c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8347cc: mov             fp, SP
    // 0x8347d0: AllocStack(0x20)
    //     0x8347d0: sub             SP, SP, #0x20
    // 0x8347d4: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x8347d4: mov             x3, x2
    //     0x8347d8: stur            x2, [fp, #-0x10]
    // 0x8347dc: CheckStackOverflow
    //     0x8347dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8347e0: cmp             SP, x16
    //     0x8347e4: b.ls            #0x83496c
    // 0x8347e8: cmp             w1, NULL
    // 0x8347ec: b.ne            #0x834800
    // 0x8347f0: r0 = true
    //     0x8347f0: add             x0, NULL, #0x20  ; true
    // 0x8347f4: LeaveFrame
    //     0x8347f4: mov             SP, fp
    //     0x8347f8: ldp             fp, lr, [SP], #0x10
    // 0x8347fc: ret
    //     0x8347fc: ret             
    // 0x834800: LoadField: r4 = r1->field_b
    //     0x834800: ldur            w4, [x1, #0xb]
    // 0x834804: DecompressPointer r4
    //     0x834804: add             x4, x4, HEAP, lsl #32
    // 0x834808: mov             x0, x3
    // 0x83480c: stur            x4, [fp, #-8]
    // 0x834810: r2 = Null
    //     0x834810: mov             x2, NULL
    // 0x834814: r1 = Null
    //     0x834814: mov             x1, NULL
    // 0x834818: cmp             w0, NULL
    // 0x83481c: b.eq            #0x834848
    // 0x834820: branchIfSmi(r0, 0x834848)
    //     0x834820: tbz             w0, #0, #0x834848
    // 0x834824: r3 = LoadClassIdInstr(r0)
    //     0x834824: ldur            x3, [x0, #-1]
    //     0x834828: ubfx            x3, x3, #0xc, #0x14
    // 0x83482c: r17 = -4148
    //     0x83482c: mov             x17, #-0x1034
    // 0x834830: add             x3, x3, x17
    // 0x834834: cmp             x3, #5
    // 0x834838: b.ls            #0x834850
    // 0x83483c: sub             x3, x3, #0x458
    // 0x834840: cmp             x3, #4
    // 0x834844: b.ls            #0x834850
    // 0x834848: r0 = false
    //     0x834848: add             x0, NULL, #0x30  ; false
    // 0x83484c: b               #0x834854
    // 0x834850: r0 = true
    //     0x834850: add             x0, NULL, #0x20  ; true
    // 0x834854: tbnz            w0, #4, #0x834868
    // 0x834858: r0 = false
    //     0x834858: add             x0, NULL, #0x30  ; false
    // 0x83485c: LeaveFrame
    //     0x83485c: mov             SP, fp
    //     0x834860: ldp             fp, lr, [SP], #0x10
    // 0x834864: ret
    //     0x834864: ret             
    // 0x834868: ldur            x0, [fp, #-8]
    // 0x83486c: r2 = Null
    //     0x83486c: mov             x2, NULL
    // 0x834870: r1 = Null
    //     0x834870: mov             x1, NULL
    // 0x834874: cmp             w0, NULL
    // 0x834878: b.eq            #0x8348a0
    // 0x83487c: branchIfSmi(r0, 0x8348a0)
    //     0x83487c: tbz             w0, #0, #0x8348a0
    // 0x834880: r3 = LoadClassIdInstr(r0)
    //     0x834880: ldur            x3, [x0, #-1]
    //     0x834884: ubfx            x3, x3, #0xc, #0x14
    // 0x834888: r17 = 4169
    //     0x834888: mov             x17, #0x1049
    // 0x83488c: cmp             x3, x17
    // 0x834890: b.eq            #0x8348a8
    // 0x834894: r17 = 5298
    //     0x834894: mov             x17, #0x14b2
    // 0x834898: cmp             x3, x17
    // 0x83489c: b.eq            #0x8348a8
    // 0x8348a0: r0 = false
    //     0x8348a0: add             x0, NULL, #0x30  ; false
    // 0x8348a4: b               #0x8348ac
    // 0x8348a8: r0 = true
    //     0x8348a8: add             x0, NULL, #0x20  ; true
    // 0x8348ac: tbz             w0, #4, #0x8348f8
    // 0x8348b0: ldur            x0, [fp, #-0x10]
    // 0x8348b4: r2 = Null
    //     0x8348b4: mov             x2, NULL
    // 0x8348b8: r1 = Null
    //     0x8348b8: mov             x1, NULL
    // 0x8348bc: cmp             w0, NULL
    // 0x8348c0: b.eq            #0x8348e8
    // 0x8348c4: branchIfSmi(r0, 0x8348e8)
    //     0x8348c4: tbz             w0, #0, #0x8348e8
    // 0x8348c8: r3 = LoadClassIdInstr(r0)
    //     0x8348c8: ldur            x3, [x0, #-1]
    //     0x8348cc: ubfx            x3, x3, #0xc, #0x14
    // 0x8348d0: r17 = 4167
    //     0x8348d0: mov             x17, #0x1047
    // 0x8348d4: cmp             x3, x17
    // 0x8348d8: b.eq            #0x8348f0
    // 0x8348dc: r17 = 5296
    //     0x8348dc: mov             x17, #0x14b0
    // 0x8348e0: cmp             x3, x17
    // 0x8348e4: b.eq            #0x8348f0
    // 0x8348e8: r0 = false
    //     0x8348e8: add             x0, NULL, #0x30  ; false
    // 0x8348ec: b               #0x8348f4
    // 0x8348f0: r0 = true
    //     0x8348f0: add             x0, NULL, #0x20  ; true
    // 0x8348f4: tbnz            w0, #4, #0x834900
    // 0x8348f8: r0 = true
    //     0x8348f8: add             x0, NULL, #0x20  ; true
    // 0x8348fc: b               #0x834960
    // 0x834900: ldur            x2, [fp, #-0x10]
    // 0x834904: ldur            x1, [fp, #-8]
    // 0x834908: r0 = LoadClassIdInstr(r1)
    //     0x834908: ldur            x0, [x1, #-1]
    //     0x83490c: ubfx            x0, x0, #0xc, #0x14
    // 0x834910: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x834910: mov             x17, #0x3f27
    //     0x834914: movk            x17, #1, lsl #16
    //     0x834918: add             lr, x0, x17
    //     0x83491c: ldr             lr, [x21, lr, lsl #3]
    //     0x834920: blr             lr
    // 0x834924: mov             x2, x0
    // 0x834928: ldur            x1, [fp, #-0x10]
    // 0x83492c: stur            x2, [fp, #-8]
    // 0x834930: r0 = LoadClassIdInstr(r1)
    //     0x834930: ldur            x0, [x1, #-1]
    //     0x834934: ubfx            x0, x0, #0xc, #0x14
    // 0x834938: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x834938: mov             x17, #0x3f27
    //     0x83493c: movk            x17, #1, lsl #16
    //     0x834940: add             lr, x0, x17
    //     0x834944: ldr             lr, [x21, lr, lsl #3]
    //     0x834948: blr             lr
    // 0x83494c: ldur            x16, [fp, #-8]
    // 0x834950: stp             x0, x16, [SP]
    // 0x834954: r0 = ==()
    //     0x834954: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x834958: eor             x1, x0, #0x10
    // 0x83495c: mov             x0, x1
    // 0x834960: LeaveFrame
    //     0x834960: mov             SP, fp
    //     0x834964: ldp             fp, lr, [SP], #0x10
    // 0x834968: ret
    //     0x834968: ret             
    // 0x83496c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83496c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834970: b               #0x8347e8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x834974, size: 0x5c
    // 0x834974: EnterFrame
    //     0x834974: stp             fp, lr, [SP, #-0x10]!
    //     0x834978: mov             fp, SP
    // 0x83497c: AllocStack(0x8)
    //     0x83497c: sub             SP, SP, #8
    // 0x834980: SetupParameters([dynamic _ /* r0 */])
    //     0x834980: ldr             x0, [fp, #0x10]
    //     0x834984: ldur            w2, [x0, #0x17]
    //     0x834988: add             x2, x2, HEAP, lsl #32
    // 0x83498c: CheckStackOverflow
    //     0x83498c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834990: cmp             SP, x16
    //     0x834994: b.ls            #0x8349c8
    // 0x834998: LoadField: r0 = r2->field_f
    //     0x834998: ldur            w0, [x2, #0xf]
    // 0x83499c: DecompressPointer r0
    //     0x83499c: add             x0, x0, HEAP, lsl #32
    // 0x8349a0: stur            x0, [fp, #-8]
    // 0x8349a4: r1 = Function '<anonymous closure>':.
    //     0x8349a4: ldr             x1, [PP, #0x4340]  ; [pp+0x4340] AnonymousClosure: (0x834a14), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::updateWithEvent (0x83374c)
    // 0x8349a8: r0 = AllocateClosure()
    //     0x8349a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8349ac: ldur            x1, [fp, #-8]
    // 0x8349b0: mov             x2, x0
    // 0x8349b4: r0 = lockState()
    //     0x8349b4: bl              #0x8349d0  ; [package:flutter/src/widgets/framework.dart] BuildOwner::lockState
    // 0x8349b8: r0 = Null
    //     0x8349b8: mov             x0, NULL
    // 0x8349bc: LeaveFrame
    //     0x8349bc: mov             SP, fp
    //     0x8349c0: ldp             fp, lr, [SP], #0x10
    // 0x8349c4: ret
    //     0x8349c4: ret             
    // 0x8349c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8349c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8349cc: b               #0x834998
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x834a14, size: 0x380
    // 0x834a14: EnterFrame
    //     0x834a14: stp             fp, lr, [SP, #-0x10]!
    //     0x834a18: mov             fp, SP
    // 0x834a1c: AllocStack(0x48)
    //     0x834a1c: sub             SP, SP, #0x48
    // 0x834a20: SetupParameters([dynamic _ /* r0 */])
    //     0x834a20: ldr             x0, [fp, #0x10]
    //     0x834a24: ldur            w3, [x0, #0x17]
    //     0x834a28: add             x3, x3, HEAP, lsl #32
    //     0x834a2c: stur            x3, [fp, #-0x18]
    // 0x834a30: CheckStackOverflow
    //     0x834a30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834a34: cmp             SP, x16
    //     0x834a38: b.ls            #0x834d88
    // 0x834a3c: LoadField: r4 = r3->field_1f
    //     0x834a3c: ldur            w4, [x3, #0x1f]
    // 0x834a40: DecompressPointer r4
    //     0x834a40: add             x4, x4, HEAP, lsl #32
    // 0x834a44: stur            x4, [fp, #-0x10]
    // 0x834a48: cmp             w4, NULL
    // 0x834a4c: b.ne            #0x834b48
    // 0x834a50: LoadField: r5 = r3->field_13
    //     0x834a50: ldur            w5, [x3, #0x13]
    // 0x834a54: DecompressPointer r5
    //     0x834a54: add             x5, x5, HEAP, lsl #32
    // 0x834a58: mov             x0, x5
    // 0x834a5c: stur            x5, [fp, #-8]
    // 0x834a60: r2 = Null
    //     0x834a60: mov             x2, NULL
    // 0x834a64: r1 = Null
    //     0x834a64: mov             x1, NULL
    // 0x834a68: cmp             w0, NULL
    // 0x834a6c: b.eq            #0x834a94
    // 0x834a70: branchIfSmi(r0, 0x834a94)
    //     0x834a70: tbz             w0, #0, #0x834a94
    // 0x834a74: r3 = LoadClassIdInstr(r0)
    //     0x834a74: ldur            x3, [x0, #-1]
    //     0x834a78: ubfx            x3, x3, #0xc, #0x14
    // 0x834a7c: r17 = 4167
    //     0x834a7c: mov             x17, #0x1047
    // 0x834a80: cmp             x3, x17
    // 0x834a84: b.eq            #0x834a9c
    // 0x834a88: r17 = 5296
    //     0x834a88: mov             x17, #0x14b0
    // 0x834a8c: cmp             x3, x17
    // 0x834a90: b.eq            #0x834a9c
    // 0x834a94: r0 = false
    //     0x834a94: add             x0, NULL, #0x30  ; false
    // 0x834a98: b               #0x834aa0
    // 0x834a9c: r0 = true
    //     0x834a9c: add             x0, NULL, #0x20  ; true
    // 0x834aa0: tbnz            w0, #4, #0x834ab4
    // 0x834aa4: r0 = Null
    //     0x834aa4: mov             x0, NULL
    // 0x834aa8: LeaveFrame
    //     0x834aa8: mov             SP, fp
    //     0x834aac: ldp             fp, lr, [SP], #0x10
    // 0x834ab0: ret
    //     0x834ab0: ret             
    // 0x834ab4: ldur            x0, [fp, #-0x18]
    // 0x834ab8: ldur            x1, [fp, #-8]
    // 0x834abc: LoadField: r2 = r0->field_f
    //     0x834abc: ldur            w2, [x0, #0xf]
    // 0x834ac0: DecompressPointer r2
    //     0x834ac0: add             x2, x2, HEAP, lsl #32
    // 0x834ac4: LoadField: r3 = r2->field_2b
    //     0x834ac4: ldur            w3, [x2, #0x2b]
    // 0x834ac8: DecompressPointer r3
    //     0x834ac8: add             x3, x3, HEAP, lsl #32
    // 0x834acc: stur            x3, [fp, #-0x28]
    // 0x834ad0: LoadField: r2 = r0->field_1b
    //     0x834ad0: ldur            w2, [x0, #0x1b]
    // 0x834ad4: DecompressPointer r2
    //     0x834ad4: add             x2, x2, HEAP, lsl #32
    // 0x834ad8: stur            x2, [fp, #-0x20]
    // 0x834adc: r16 = <MouseTrackerAnnotation, Matrix4>
    //     0x834adc: ldr             x16, [PP, #0x2198]  ; [pp+0x2198] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x834ae0: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x834ae4: stp             lr, x16, [SP]
    // 0x834ae8: r0 = Map._fromLiteral()
    //     0x834ae8: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x834aec: stur            x0, [fp, #-0x30]
    // 0x834af0: r0 = _MouseState()
    //     0x834af0: bl              #0x836630  ; Allocate_MouseStateStub -> _MouseState (size=0x10)
    // 0x834af4: mov             x3, x0
    // 0x834af8: ldur            x0, [fp, #-0x30]
    // 0x834afc: stur            x3, [fp, #-0x38]
    // 0x834b00: StoreField: r3->field_7 = r0
    //     0x834b00: stur            w0, [x3, #7]
    // 0x834b04: ldur            x0, [fp, #-8]
    // 0x834b08: StoreField: r3->field_b = r0
    //     0x834b08: stur            w0, [x3, #0xb]
    // 0x834b0c: ldur            x1, [fp, #-0x28]
    // 0x834b10: ldur            x2, [fp, #-0x20]
    // 0x834b14: r0 = _hashCode()
    //     0x834b14: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x834b18: mov             x2, x0
    // 0x834b1c: r0 = BoxInt64Instr(r2)
    //     0x834b1c: sbfiz           x0, x2, #1, #0x1f
    //     0x834b20: cmp             x2, x0, asr #1
    //     0x834b24: b.eq            #0x834b30
    //     0x834b28: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x834b2c: stur            x2, [x0, #7]
    // 0x834b30: ldur            x1, [fp, #-0x28]
    // 0x834b34: ldur            x2, [fp, #-0x20]
    // 0x834b38: ldur            x3, [fp, #-0x38]
    // 0x834b3c: mov             x5, x0
    // 0x834b40: r0 = _set()
    //     0x834b40: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x834b44: b               #0x834bf8
    // 0x834b48: LoadField: r4 = r3->field_13
    //     0x834b48: ldur            w4, [x3, #0x13]
    // 0x834b4c: DecompressPointer r4
    //     0x834b4c: add             x4, x4, HEAP, lsl #32
    // 0x834b50: mov             x0, x4
    // 0x834b54: stur            x4, [fp, #-8]
    // 0x834b58: r2 = Null
    //     0x834b58: mov             x2, NULL
    // 0x834b5c: r1 = Null
    //     0x834b5c: mov             x1, NULL
    // 0x834b60: cmp             w0, NULL
    // 0x834b64: b.eq            #0x834b8c
    // 0x834b68: branchIfSmi(r0, 0x834b8c)
    //     0x834b68: tbz             w0, #0, #0x834b8c
    // 0x834b6c: r3 = LoadClassIdInstr(r0)
    //     0x834b6c: ldur            x3, [x0, #-1]
    //     0x834b70: ubfx            x3, x3, #0xc, #0x14
    // 0x834b74: r17 = 4167
    //     0x834b74: mov             x17, #0x1047
    // 0x834b78: cmp             x3, x17
    // 0x834b7c: b.eq            #0x834b94
    // 0x834b80: r17 = 5296
    //     0x834b80: mov             x17, #0x14b0
    // 0x834b84: cmp             x3, x17
    // 0x834b88: b.eq            #0x834b94
    // 0x834b8c: r0 = false
    //     0x834b8c: add             x0, NULL, #0x30  ; false
    // 0x834b90: b               #0x834b98
    // 0x834b94: r0 = true
    //     0x834b94: add             x0, NULL, #0x20  ; true
    // 0x834b98: tbnz            w0, #4, #0x834bf8
    // 0x834b9c: ldur            x2, [fp, #-0x18]
    // 0x834ba0: ldur            x1, [fp, #-8]
    // 0x834ba4: LoadField: r0 = r2->field_f
    //     0x834ba4: ldur            w0, [x2, #0xf]
    // 0x834ba8: DecompressPointer r0
    //     0x834ba8: add             x0, x0, HEAP, lsl #32
    // 0x834bac: LoadField: r3 = r0->field_2b
    //     0x834bac: ldur            w3, [x0, #0x2b]
    // 0x834bb0: DecompressPointer r3
    //     0x834bb0: add             x3, x3, HEAP, lsl #32
    // 0x834bb4: stur            x3, [fp, #-0x20]
    // 0x834bb8: r0 = LoadClassIdInstr(r1)
    //     0x834bb8: ldur            x0, [x1, #-1]
    //     0x834bbc: ubfx            x0, x0, #0xc, #0x14
    // 0x834bc0: r0 = GDT[cid_x0 + 0x15a90]()
    //     0x834bc0: mov             x17, #0x5a90
    //     0x834bc4: movk            x17, #1, lsl #16
    //     0x834bc8: add             lr, x0, x17
    //     0x834bcc: ldr             lr, [x21, lr, lsl #3]
    //     0x834bd0: blr             lr
    // 0x834bd4: mov             x2, x0
    // 0x834bd8: r0 = BoxInt64Instr(r2)
    //     0x834bd8: sbfiz           x0, x2, #1, #0x1f
    //     0x834bdc: cmp             x2, x0, asr #1
    //     0x834be0: b.eq            #0x834bec
    //     0x834be4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x834be8: stur            x2, [x0, #7]
    // 0x834bec: ldur            x1, [fp, #-0x20]
    // 0x834bf0: mov             x2, x0
    // 0x834bf4: r0 = remove()
    //     0x834bf4: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x834bf8: ldur            x0, [fp, #-0x18]
    // 0x834bfc: LoadField: r1 = r0->field_f
    //     0x834bfc: ldur            w1, [x0, #0xf]
    // 0x834c00: DecompressPointer r1
    //     0x834c00: add             x1, x1, HEAP, lsl #32
    // 0x834c04: LoadField: r3 = r1->field_2b
    //     0x834c04: ldur            w3, [x1, #0x2b]
    // 0x834c08: DecompressPointer r3
    //     0x834c08: add             x3, x3, HEAP, lsl #32
    // 0x834c0c: stur            x3, [fp, #-8]
    // 0x834c10: LoadField: r2 = r0->field_1b
    //     0x834c10: ldur            w2, [x0, #0x1b]
    // 0x834c14: DecompressPointer r2
    //     0x834c14: add             x2, x2, HEAP, lsl #32
    // 0x834c18: mov             x1, x3
    // 0x834c1c: r0 = _getValueOrData()
    //     0x834c1c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x834c20: mov             x1, x0
    // 0x834c24: ldur            x0, [fp, #-8]
    // 0x834c28: LoadField: r2 = r0->field_f
    //     0x834c28: ldur            w2, [x0, #0xf]
    // 0x834c2c: DecompressPointer r2
    //     0x834c2c: add             x2, x2, HEAP, lsl #32
    // 0x834c30: cmp             w2, w1
    // 0x834c34: b.ne            #0x834c40
    // 0x834c38: r0 = Null
    //     0x834c38: mov             x0, NULL
    // 0x834c3c: b               #0x834c44
    // 0x834c40: mov             x0, x1
    // 0x834c44: cmp             w0, NULL
    // 0x834c48: b.ne            #0x834c60
    // 0x834c4c: ldur            x0, [fp, #-0x10]
    // 0x834c50: cmp             w0, NULL
    // 0x834c54: b.eq            #0x834d90
    // 0x834c58: mov             x3, x0
    // 0x834c5c: b               #0x834c64
    // 0x834c60: mov             x3, x0
    // 0x834c64: ldur            x0, [fp, #-0x18]
    // 0x834c68: stur            x3, [fp, #-8]
    // 0x834c6c: LoadField: r2 = r0->field_13
    //     0x834c6c: ldur            w2, [x0, #0x13]
    // 0x834c70: DecompressPointer r2
    //     0x834c70: add             x2, x2, HEAP, lsl #32
    // 0x834c74: mov             x1, x3
    // 0x834c78: r0 = replaceLatestEvent()
    //     0x834c78: bl              #0x8365f8  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseState::replaceLatestEvent
    // 0x834c7c: mov             x4, x0
    // 0x834c80: ldur            x3, [fp, #-0x18]
    // 0x834c84: stur            x4, [fp, #-0x10]
    // 0x834c88: LoadField: r0 = r3->field_13
    //     0x834c88: ldur            w0, [x3, #0x13]
    // 0x834c8c: DecompressPointer r0
    //     0x834c8c: add             x0, x0, HEAP, lsl #32
    // 0x834c90: r2 = Null
    //     0x834c90: mov             x2, NULL
    // 0x834c94: r1 = Null
    //     0x834c94: mov             x1, NULL
    // 0x834c98: cmp             w0, NULL
    // 0x834c9c: b.eq            #0x834cc4
    // 0x834ca0: branchIfSmi(r0, 0x834cc4)
    //     0x834ca0: tbz             w0, #0, #0x834cc4
    // 0x834ca4: r3 = LoadClassIdInstr(r0)
    //     0x834ca4: ldur            x3, [x0, #-1]
    //     0x834ca8: ubfx            x3, x3, #0xc, #0x14
    // 0x834cac: r17 = 4167
    //     0x834cac: mov             x17, #0x1047
    // 0x834cb0: cmp             x3, x17
    // 0x834cb4: b.eq            #0x834ccc
    // 0x834cb8: r17 = 5296
    //     0x834cb8: mov             x17, #0x14b0
    // 0x834cbc: cmp             x3, x17
    // 0x834cc0: b.eq            #0x834ccc
    // 0x834cc4: r0 = false
    //     0x834cc4: add             x0, NULL, #0x30  ; false
    // 0x834cc8: b               #0x834cd0
    // 0x834ccc: r0 = true
    //     0x834ccc: add             x0, NULL, #0x20  ; true
    // 0x834cd0: tbnz            w0, #4, #0x834cec
    // 0x834cd4: r16 = <MouseTrackerAnnotation, Matrix4>
    //     0x834cd4: ldr             x16, [PP, #0x2198]  ; [pp+0x2198] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x834cd8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x834cdc: stp             lr, x16, [SP]
    // 0x834ce0: r0 = Map._fromLiteral()
    //     0x834ce0: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x834ce4: mov             x4, x0
    // 0x834ce8: b               #0x834d08
    // 0x834cec: ldur            x0, [fp, #-0x18]
    // 0x834cf0: LoadField: r1 = r0->field_f
    //     0x834cf0: ldur            w1, [x0, #0xf]
    // 0x834cf4: DecompressPointer r1
    //     0x834cf4: add             x1, x1, HEAP, lsl #32
    // 0x834cf8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x834cf8: ldur            w2, [x0, #0x17]
    // 0x834cfc: DecompressPointer r2
    //     0x834cfc: add             x2, x2, HEAP, lsl #32
    // 0x834d00: r0 = _hitTestInViewResultToAnnotations()
    //     0x834d00: bl              #0x836428  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_hitTestInViewResultToAnnotations
    // 0x834d04: mov             x4, x0
    // 0x834d08: ldur            x0, [fp, #-0x18]
    // 0x834d0c: ldur            x3, [fp, #-0x10]
    // 0x834d10: ldur            x1, [fp, #-8]
    // 0x834d14: mov             x2, x4
    // 0x834d18: stur            x4, [fp, #-0x20]
    // 0x834d1c: r0 = replaceAnnotations()
    //     0x834d1c: bl              #0x8363f0  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseState::replaceAnnotations
    // 0x834d20: mov             x1, x0
    // 0x834d24: ldur            x0, [fp, #-0x18]
    // 0x834d28: stur            x1, [fp, #-0x30]
    // 0x834d2c: LoadField: r2 = r0->field_f
    //     0x834d2c: ldur            w2, [x0, #0xf]
    // 0x834d30: DecompressPointer r2
    //     0x834d30: add             x2, x2, HEAP, lsl #32
    // 0x834d34: stur            x2, [fp, #-0x28]
    // 0x834d38: LoadField: r3 = r0->field_13
    //     0x834d38: ldur            w3, [x0, #0x13]
    // 0x834d3c: DecompressPointer r3
    //     0x834d3c: add             x3, x3, HEAP, lsl #32
    // 0x834d40: stur            x3, [fp, #-8]
    // 0x834d44: r0 = _MouseTrackerUpdateDetails()
    //     0x834d44: bl              #0x8363e4  ; Allocate_MouseTrackerUpdateDetailsStub -> _MouseTrackerUpdateDetails (size=0x18)
    // 0x834d48: mov             x1, x0
    // 0x834d4c: ldur            x0, [fp, #-0x30]
    // 0x834d50: StoreField: r1->field_7 = r0
    //     0x834d50: stur            w0, [x1, #7]
    // 0x834d54: ldur            x0, [fp, #-0x20]
    // 0x834d58: StoreField: r1->field_b = r0
    //     0x834d58: stur            w0, [x1, #0xb]
    // 0x834d5c: ldur            x0, [fp, #-0x10]
    // 0x834d60: StoreField: r1->field_f = r0
    //     0x834d60: stur            w0, [x1, #0xf]
    // 0x834d64: ldur            x0, [fp, #-8]
    // 0x834d68: StoreField: r1->field_13 = r0
    //     0x834d68: stur            w0, [x1, #0x13]
    // 0x834d6c: mov             x2, x1
    // 0x834d70: ldur            x1, [fp, #-0x28]
    // 0x834d74: r0 = _handleDeviceUpdate()
    //     0x834d74: bl              #0x834db4  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdate
    // 0x834d78: r0 = Null
    //     0x834d78: mov             x0, NULL
    // 0x834d7c: LeaveFrame
    //     0x834d7c: mov             SP, fp
    //     0x834d80: ldp             fp, lr, [SP], #0x10
    // 0x834d84: ret
    //     0x834d84: ret             
    // 0x834d88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834d88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834d8c: b               #0x834a3c
    // 0x834d90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x834d90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleDeviceUpdate(/* No info */) {
    // ** addr: 0x834db4, size: 0xf4
    // 0x834db4: EnterFrame
    //     0x834db4: stp             fp, lr, [SP, #-0x10]!
    //     0x834db8: mov             fp, SP
    // 0x834dbc: AllocStack(0x40)
    //     0x834dbc: sub             SP, SP, #0x40
    // 0x834dc0: SetupParameters(MouseTracker this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x834dc0: mov             x0, x2
    //     0x834dc4: stur            x2, [fp, #-0x10]
    //     0x834dc8: mov             x2, x1
    //     0x834dcc: stur            x1, [fp, #-8]
    // 0x834dd0: CheckStackOverflow
    //     0x834dd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834dd4: cmp             SP, x16
    //     0x834dd8: b.ls            #0x834ea0
    // 0x834ddc: mov             x1, x0
    // 0x834de0: r0 = _handleDeviceUpdateMouseEvents()
    //     0x834de0: bl              #0x835464  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdateMouseEvents
    // 0x834de4: ldur            x0, [fp, #-8]
    // 0x834de8: LoadField: r2 = r0->field_27
    //     0x834de8: ldur            w2, [x0, #0x27]
    // 0x834dec: DecompressPointer r2
    //     0x834dec: add             x2, x2, HEAP, lsl #32
    // 0x834df0: ldur            x3, [fp, #-0x10]
    // 0x834df4: stur            x2, [fp, #-0x18]
    // 0x834df8: LoadField: r1 = r3->field_f
    //     0x834df8: ldur            w1, [x3, #0xf]
    // 0x834dfc: DecompressPointer r1
    //     0x834dfc: add             x1, x1, HEAP, lsl #32
    // 0x834e00: r0 = LoadClassIdInstr(r1)
    //     0x834e00: ldur            x0, [x1, #-1]
    //     0x834e04: ubfx            x0, x0, #0xc, #0x14
    // 0x834e08: r0 = GDT[cid_x0 + 0x15a90]()
    //     0x834e08: mov             x17, #0x5a90
    //     0x834e0c: movk            x17, #1, lsl #16
    //     0x834e10: add             lr, x0, x17
    //     0x834e14: ldr             lr, [x21, lr, lsl #3]
    //     0x834e18: blr             lr
    // 0x834e1c: mov             x2, x0
    // 0x834e20: ldur            x0, [fp, #-0x10]
    // 0x834e24: stur            x2, [fp, #-0x28]
    // 0x834e28: LoadField: r3 = r0->field_13
    //     0x834e28: ldur            w3, [x0, #0x13]
    // 0x834e2c: DecompressPointer r3
    //     0x834e2c: add             x3, x3, HEAP, lsl #32
    // 0x834e30: stur            x3, [fp, #-0x20]
    // 0x834e34: LoadField: r4 = r0->field_b
    //     0x834e34: ldur            w4, [x0, #0xb]
    // 0x834e38: DecompressPointer r4
    //     0x834e38: add             x4, x4, HEAP, lsl #32
    // 0x834e3c: stur            x4, [fp, #-8]
    // 0x834e40: r1 = <MouseTrackerAnnotation, Matrix4>
    //     0x834e40: ldr             x1, [PP, #0x2198]  ; [pp+0x2198] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x834e44: r0 = _CompactKeysIterable()
    //     0x834e44: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x834e48: mov             x3, x0
    // 0x834e4c: ldur            x0, [fp, #-8]
    // 0x834e50: stur            x3, [fp, #-0x10]
    // 0x834e54: StoreField: r3->field_b = r0
    //     0x834e54: stur            w0, [x3, #0xb]
    // 0x834e58: r1 = Function '<anonymous closure>':.
    //     0x834e58: ldr             x1, [PP, #0x21a0]  ; [pp+0x21a0] AnonymousClosure: (0x8363a0), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdate (0x834db4)
    // 0x834e5c: r2 = Null
    //     0x834e5c: mov             x2, NULL
    // 0x834e60: r0 = AllocateClosure()
    //     0x834e60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x834e64: r16 = <MouseCursor>
    //     0x834e64: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0x834e68: ldur            lr, [fp, #-0x10]
    // 0x834e6c: stp             lr, x16, [SP, #8]
    // 0x834e70: str             x0, [SP]
    // 0x834e74: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x834e74: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x834e78: r0 = map()
    //     0x834e78: bl              #0xb007e4  ; [dart:core] Iterable::map
    // 0x834e7c: ldur            x1, [fp, #-0x18]
    // 0x834e80: ldur            x2, [fp, #-0x28]
    // 0x834e84: ldur            x3, [fp, #-0x20]
    // 0x834e88: mov             x5, x0
    // 0x834e8c: r0 = handleDeviceCursorUpdate()
    //     0x834e8c: bl              #0x834f00  ; [package:flutter/src/services/mouse_cursor.dart] MouseCursorManager::handleDeviceCursorUpdate
    // 0x834e90: r0 = Null
    //     0x834e90: mov             x0, NULL
    // 0x834e94: LeaveFrame
    //     0x834e94: mov             SP, fp
    //     0x834e98: ldp             fp, lr, [SP], #0x10
    // 0x834e9c: ret
    //     0x834e9c: ret             
    // 0x834ea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834ea0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834ea4: b               #0x834ddc
  }
  static _ _handleDeviceUpdateMouseEvents(/* No info */) {
    // ** addr: 0x835464, size: 0x418
    // 0x835464: EnterFrame
    //     0x835464: stp             fp, lr, [SP, #-0x10]!
    //     0x835468: mov             fp, SP
    // 0x83546c: AllocStack(0x50)
    //     0x83546c: sub             SP, SP, #0x50
    // 0x835470: SetupParameters(dynamic _ /* r1 => r1, fp-0x18 */)
    //     0x835470: stur            x1, [fp, #-0x18]
    // 0x835474: CheckStackOverflow
    //     0x835474: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x835478: cmp             SP, x16
    //     0x83547c: b.ls            #0x83586c
    // 0x835480: LoadField: r0 = r1->field_13
    //     0x835480: ldur            w0, [x1, #0x13]
    // 0x835484: DecompressPointer r0
    //     0x835484: add             x0, x0, HEAP, lsl #32
    // 0x835488: cmp             w0, NULL
    // 0x83548c: b.ne            #0x8354a0
    // 0x835490: LoadField: r0 = r1->field_f
    //     0x835490: ldur            w0, [x1, #0xf]
    // 0x835494: DecompressPointer r0
    //     0x835494: add             x0, x0, HEAP, lsl #32
    // 0x835498: mov             x2, x0
    // 0x83549c: b               #0x8354a4
    // 0x8354a0: mov             x2, x0
    // 0x8354a4: stur            x2, [fp, #-0x10]
    // 0x8354a8: LoadField: r0 = r1->field_7
    //     0x8354a8: ldur            w0, [x1, #7]
    // 0x8354ac: DecompressPointer r0
    //     0x8354ac: add             x0, x0, HEAP, lsl #32
    // 0x8354b0: stur            x0, [fp, #-8]
    // 0x8354b4: r1 = 3
    //     0x8354b4: mov             x1, #3
    // 0x8354b8: r0 = AllocateContext()
    //     0x8354b8: bl              #0x13de838  ; AllocateContextStub
    // 0x8354bc: mov             x3, x0
    // 0x8354c0: ldur            x0, [fp, #-8]
    // 0x8354c4: stur            x3, [fp, #-0x28]
    // 0x8354c8: StoreField: r3->field_f = r0
    //     0x8354c8: stur            w0, [x3, #0xf]
    // 0x8354cc: ldur            x1, [fp, #-0x18]
    // 0x8354d0: LoadField: r4 = r1->field_b
    //     0x8354d0: ldur            w4, [x1, #0xb]
    // 0x8354d4: DecompressPointer r4
    //     0x8354d4: add             x4, x4, HEAP, lsl #32
    // 0x8354d8: stur            x4, [fp, #-0x20]
    // 0x8354dc: StoreField: r3->field_13 = r4
    //     0x8354dc: stur            w4, [x3, #0x13]
    // 0x8354e0: ldur            x2, [fp, #-0x10]
    // 0x8354e4: r1 = Null
    //     0x8354e4: mov             x1, NULL
    // 0x8354e8: r0 = PointerExitEvent.fromMouseEvent()
    //     0x8354e8: bl              #0x835d28  ; [package:flutter/src/gestures/events.dart] PointerExitEvent::PointerExitEvent.fromMouseEvent
    // 0x8354ec: ldur            x3, [fp, #-0x28]
    // 0x8354f0: ArrayStore: r3[0] = r0  ; List_4
    //     0x8354f0: stur            w0, [x3, #0x17]
    //     0x8354f4: ldurb           w16, [x3, #-1]
    //     0x8354f8: ldurb           w17, [x0, #-1]
    //     0x8354fc: and             x16, x17, x16, lsr #2
    //     0x835500: tst             x16, HEAP, lsr #32
    //     0x835504: b.eq            #0x83550c
    //     0x835508: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x83550c: mov             x2, x3
    // 0x835510: r1 = Function '<anonymous closure>': static.
    //     0x835510: ldr             x1, [PP, #0x2240]  ; [pp+0x2240] AnonymousClosure: static (0x836274), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdateMouseEvents (0x835464)
    // 0x835514: r0 = AllocateClosure()
    //     0x835514: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x835518: ldur            x1, [fp, #-8]
    // 0x83551c: mov             x2, x0
    // 0x835520: r0 = forEach()
    //     0x835520: bl              #0x12a0da0  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0x835524: r1 = <MouseTrackerAnnotation, Matrix4>
    //     0x835524: ldr             x1, [PP, #0x2198]  ; [pp+0x2198] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x835528: r0 = _CompactKeysIterable()
    //     0x835528: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x83552c: mov             x3, x0
    // 0x835530: ldur            x0, [fp, #-0x20]
    // 0x835534: stur            x3, [fp, #-8]
    // 0x835538: StoreField: r3->field_b = r0
    //     0x835538: stur            w0, [x3, #0xb]
    // 0x83553c: ldur            x2, [fp, #-0x28]
    // 0x835540: r1 = Function '<anonymous closure>': static.
    //     0x835540: ldr             x1, [PP, #0x2248]  ; [pp+0x2248] AnonymousClosure: static (0x8361d4), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdateMouseEvents (0x835464)
    // 0x835544: r0 = AllocateClosure()
    //     0x835544: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x835548: ldur            x1, [fp, #-8]
    // 0x83554c: mov             x2, x0
    // 0x835550: r0 = where()
    //     0x835550: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x835554: mov             x3, x0
    // 0x835558: stur            x3, [fp, #-0x18]
    // 0x83555c: LoadField: r4 = r3->field_7
    //     0x83555c: ldur            w4, [x3, #7]
    // 0x835560: DecompressPointer r4
    //     0x835560: add             x4, x4, HEAP, lsl #32
    // 0x835564: mov             x0, x3
    // 0x835568: stur            x4, [fp, #-8]
    // 0x83556c: r2 = Null
    //     0x83556c: mov             x2, NULL
    // 0x835570: r1 = Null
    //     0x835570: mov             x1, NULL
    // 0x835574: cmp             w0, NULL
    // 0x835578: b.eq            #0x835604
    // 0x83557c: branchIfSmi(r0, 0x835604)
    //     0x83557c: tbz             w0, #0, #0x835604
    // 0x835580: r3 = LoadClassIdInstr(r0)
    //     0x835580: ldur            x3, [x0, #-1]
    //     0x835584: ubfx            x3, x3, #0xc, #0x14
    // 0x835588: r17 = 7724
    //     0x835588: mov             x17, #0x1e2c
    // 0x83558c: cmp             x3, x17
    // 0x835590: b.eq            #0x83560c
    // 0x835594: r4 = LoadClassIdInstr(r0)
    //     0x835594: ldur            x4, [x0, #-1]
    //     0x835598: ubfx            x4, x4, #0xc, #0x14
    // 0x83559c: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x8355a0: ldr             x3, [x3, #0x18]
    // 0x8355a4: ldr             x3, [x3, x4, lsl #3]
    // 0x8355a8: LoadField: r3 = r3->field_2b
    //     0x8355a8: ldur            w3, [x3, #0x2b]
    // 0x8355ac: DecompressPointer r3
    //     0x8355ac: add             x3, x3, HEAP, lsl #32
    // 0x8355b0: cmp             w3, NULL
    // 0x8355b4: b.eq            #0x835604
    // 0x8355b8: LoadField: r3 = r3->field_f
    //     0x8355b8: ldur            w3, [x3, #0xf]
    // 0x8355bc: lsr             x3, x3, #3
    // 0x8355c0: r17 = 7724
    //     0x8355c0: mov             x17, #0x1e2c
    // 0x8355c4: cmp             x3, x17
    // 0x8355c8: b.eq            #0x83560c
    // 0x8355cc: r3 = SubtypeTestCache
    //     0x8355cc: ldr             x3, [PP, #0x2250]  ; [pp+0x2250] SubtypeTestCache
    // 0x8355d0: r30 = Subtype1TestCacheStub
    //     0x8355d0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x8355d4: LoadField: r30 = r30->field_7
    //     0x8355d4: ldur            lr, [lr, #7]
    // 0x8355d8: blr             lr
    // 0x8355dc: cmp             w7, NULL
    // 0x8355e0: b.eq            #0x8355ec
    // 0x8355e4: tbnz            w7, #4, #0x835604
    // 0x8355e8: b               #0x83560c
    // 0x8355ec: r8 = EfficientLengthIterable
    //     0x8355ec: ldr             x8, [PP, #0x2258]  ; [pp+0x2258] Type: EfficientLengthIterable
    // 0x8355f0: r3 = SubtypeTestCache
    //     0x8355f0: ldr             x3, [PP, #0x2260]  ; [pp+0x2260] SubtypeTestCache
    // 0x8355f4: r30 = InstanceOfStub
    //     0x8355f4: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x8355f8: LoadField: r30 = r30->field_7
    //     0x8355f8: ldur            lr, [lr, #7]
    // 0x8355fc: blr             lr
    // 0x835600: b               #0x835610
    // 0x835604: r0 = false
    //     0x835604: add             x0, NULL, #0x30  ; false
    // 0x835608: b               #0x835610
    // 0x83560c: r0 = true
    //     0x83560c: add             x0, NULL, #0x20  ; true
    // 0x835610: tbnz            w0, #4, #0x835624
    // 0x835614: ldur            x1, [fp, #-8]
    // 0x835618: ldur            x2, [fp, #-0x18]
    // 0x83561c: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x83561c: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x835620: b               #0x835630
    // 0x835624: ldur            x1, [fp, #-8]
    // 0x835628: ldur            x2, [fp, #-0x18]
    // 0x83562c: r0 = _GrowableList._ofOther()
    //     0x83562c: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x835630: ldur            x2, [fp, #-0x10]
    // 0x835634: stur            x0, [fp, #-8]
    // 0x835638: r1 = Null
    //     0x835638: mov             x1, NULL
    // 0x83563c: r0 = PointerEnterEvent.fromMouseEvent()
    //     0x83563c: bl              #0x83587c  ; [package:flutter/src/gestures/events.dart] PointerEnterEvent::PointerEnterEvent.fromMouseEvent
    // 0x835640: ldur            x1, [fp, #-8]
    // 0x835644: stur            x0, [fp, #-8]
    // 0x835648: r0 = reversed()
    //     0x835648: bl              #0xa07188  ; [dart:collection] ListBase::reversed
    // 0x83564c: mov             x1, x0
    // 0x835650: r0 = iterator()
    //     0x835650: bl              #0xb12cf4  ; [dart:collection] ListBase::iterator
    // 0x835654: mov             x1, x0
    // 0x835658: stur            x1, [fp, #-0x28]
    // 0x83565c: LoadField: r2 = r1->field_b
    //     0x83565c: ldur            w2, [x1, #0xb]
    // 0x835660: DecompressPointer r2
    //     0x835660: add             x2, x2, HEAP, lsl #32
    // 0x835664: stur            x2, [fp, #-0x18]
    // 0x835668: LoadField: r3 = r1->field_f
    //     0x835668: ldur            x3, [x1, #0xf]
    // 0x83566c: stur            x3, [fp, #-0x30]
    // 0x835670: LoadField: r4 = r1->field_7
    //     0x835670: ldur            w4, [x1, #7]
    // 0x835674: DecompressPointer r4
    //     0x835674: add             x4, x4, HEAP, lsl #32
    // 0x835678: stur            x4, [fp, #-0x10]
    // 0x83567c: ldur            x6, [fp, #-0x20]
    // 0x835680: ldur            x5, [fp, #-8]
    // 0x835684: CheckStackOverflow
    //     0x835684: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x835688: cmp             SP, x16
    //     0x83568c: b.ls            #0x835874
    // 0x835690: r0 = LoadClassIdInstr(r2)
    //     0x835690: ldur            x0, [x2, #-1]
    //     0x835694: ubfx            x0, x0, #0xc, #0x14
    // 0x835698: str             x2, [SP]
    // 0x83569c: r0 = GDT[cid_x0 + 0xf078]()
    //     0x83569c: mov             x17, #0xf078
    //     0x8356a0: add             lr, x0, x17
    //     0x8356a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8356a8: blr             lr
    // 0x8356ac: r1 = LoadInt32Instr(r0)
    //     0x8356ac: sbfx            x1, x0, #1, #0x1f
    //     0x8356b0: tbz             w0, #0, #0x8356b8
    //     0x8356b4: ldur            x1, [x0, #7]
    // 0x8356b8: ldur            x3, [fp, #-0x30]
    // 0x8356bc: cmp             x3, x1
    // 0x8356c0: b.ne            #0x83584c
    // 0x8356c4: ldur            x4, [fp, #-0x28]
    // 0x8356c8: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x8356c8: ldur            x2, [x4, #0x17]
    // 0x8356cc: cmp             x2, x1
    // 0x8356d0: b.ge            #0x835834
    // 0x8356d4: ldur            x5, [fp, #-0x18]
    // 0x8356d8: r0 = LoadClassIdInstr(r5)
    //     0x8356d8: ldur            x0, [x5, #-1]
    //     0x8356dc: ubfx            x0, x0, #0xc, #0x14
    // 0x8356e0: mov             x1, x5
    // 0x8356e4: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0x8356e4: mov             x17, #0x2eb9
    //     0x8356e8: movk            x17, #1, lsl #16
    //     0x8356ec: add             lr, x0, x17
    //     0x8356f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8356f4: blr             lr
    // 0x8356f8: mov             x4, x0
    // 0x8356fc: ldur            x3, [fp, #-0x28]
    // 0x835700: stur            x4, [fp, #-0x38]
    // 0x835704: StoreField: r3->field_1f = r0
    //     0x835704: stur            w0, [x3, #0x1f]
    //     0x835708: tbz             w0, #0, #0x835724
    //     0x83570c: ldurb           w16, [x3, #-1]
    //     0x835710: ldurb           w17, [x0, #-1]
    //     0x835714: and             x16, x17, x16, lsr #2
    //     0x835718: tst             x16, HEAP, lsr #32
    //     0x83571c: b.eq            #0x835724
    //     0x835720: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x835724: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x835724: ldur            x0, [x3, #0x17]
    // 0x835728: add             x1, x0, #1
    // 0x83572c: ArrayStore: r3[0] = r1  ; List_8
    //     0x83572c: stur            x1, [x3, #0x17]
    // 0x835730: cmp             w4, NULL
    // 0x835734: b.ne            #0x835764
    // 0x835738: mov             x0, x4
    // 0x83573c: ldur            x2, [fp, #-0x10]
    // 0x835740: r1 = Null
    //     0x835740: mov             x1, NULL
    // 0x835744: cmp             w2, NULL
    // 0x835748: b.eq            #0x835764
    // 0x83574c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x83574c: ldur            w4, [x2, #0x17]
    // 0x835750: DecompressPointer r4
    //     0x835750: add             x4, x4, HEAP, lsl #32
    // 0x835754: r8 = X0
    //     0x835754: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x835758: LoadField: r9 = r4->field_7
    //     0x835758: ldur            x9, [x4, #7]
    // 0x83575c: r3 = Null
    //     0x83575c: ldr             x3, [PP, #0x2268]  ; [pp+0x2268] Null
    // 0x835760: blr             x9
    // 0x835764: ldur            x2, [fp, #-0x38]
    // 0x835768: r0 = LoadClassIdInstr(r2)
    //     0x835768: ldur            x0, [x2, #-1]
    //     0x83576c: ubfx            x0, x0, #0xc, #0x14
    // 0x835770: mov             x1, x2
    // 0x835774: r0 = GDT[cid_x0 + 0x90f7]()
    //     0x835774: mov             x17, #0x90f7
    //     0x835778: add             lr, x0, x17
    //     0x83577c: ldr             lr, [x21, lr, lsl #3]
    //     0x835780: blr             lr
    // 0x835784: tbnz            w0, #4, #0x835820
    // 0x835788: ldur            x2, [fp, #-0x38]
    // 0x83578c: r0 = LoadClassIdInstr(r2)
    //     0x83578c: ldur            x0, [x2, #-1]
    //     0x835790: ubfx            x0, x0, #0xc, #0x14
    // 0x835794: mov             x1, x2
    // 0x835798: r0 = GDT[cid_x0 + 0xb1e0]()
    //     0x835798: mov             x17, #0xb1e0
    //     0x83579c: add             lr, x0, x17
    //     0x8357a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8357a4: blr             lr
    // 0x8357a8: stur            x0, [fp, #-0x40]
    // 0x8357ac: cmp             w0, NULL
    // 0x8357b0: b.eq            #0x835820
    // 0x8357b4: ldur            x3, [fp, #-0x20]
    // 0x8357b8: mov             x1, x3
    // 0x8357bc: ldur            x2, [fp, #-0x38]
    // 0x8357c0: r0 = _getValueOrData()
    //     0x8357c0: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x8357c4: ldur            x3, [fp, #-0x20]
    // 0x8357c8: LoadField: r1 = r3->field_f
    //     0x8357c8: ldur            w1, [x3, #0xf]
    // 0x8357cc: DecompressPointer r1
    //     0x8357cc: add             x1, x1, HEAP, lsl #32
    // 0x8357d0: cmp             w1, w0
    // 0x8357d4: b.ne            #0x8357e0
    // 0x8357d8: r2 = Null
    //     0x8357d8: mov             x2, NULL
    // 0x8357dc: b               #0x8357e4
    // 0x8357e0: mov             x2, x0
    // 0x8357e4: ldur            x4, [fp, #-8]
    // 0x8357e8: r0 = LoadClassIdInstr(r4)
    //     0x8357e8: ldur            x0, [x4, #-1]
    //     0x8357ec: ubfx            x0, x0, #0xc, #0x14
    // 0x8357f0: mov             x1, x4
    // 0x8357f4: r0 = GDT[cid_x0 + 0x14eda]()
    //     0x8357f4: mov             x17, #0x4eda
    //     0x8357f8: movk            x17, #1, lsl #16
    //     0x8357fc: add             lr, x0, x17
    //     0x835800: ldr             lr, [x21, lr, lsl #3]
    //     0x835804: blr             lr
    // 0x835808: ldur            x16, [fp, #-0x40]
    // 0x83580c: stp             x0, x16, [SP]
    // 0x835810: ldur            x0, [fp, #-0x40]
    // 0x835814: ClosureCall
    //     0x835814: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x835818: ldur            x2, [x0, #0x1f]
    //     0x83581c: blr             x2
    // 0x835820: ldur            x1, [fp, #-0x28]
    // 0x835824: ldur            x4, [fp, #-0x10]
    // 0x835828: ldur            x2, [fp, #-0x18]
    // 0x83582c: ldur            x3, [fp, #-0x30]
    // 0x835830: b               #0x83567c
    // 0x835834: mov             x0, x4
    // 0x835838: StoreField: r0->field_1f = rNULL
    //     0x835838: stur            NULL, [x0, #0x1f]
    // 0x83583c: r0 = Null
    //     0x83583c: mov             x0, NULL
    // 0x835840: LeaveFrame
    //     0x835840: mov             SP, fp
    //     0x835844: ldp             fp, lr, [SP], #0x10
    // 0x835848: ret
    //     0x835848: ret             
    // 0x83584c: ldur            x0, [fp, #-0x18]
    // 0x835850: r0 = ConcurrentModificationError()
    //     0x835850: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x835854: mov             x1, x0
    // 0x835858: ldur            x0, [fp, #-0x18]
    // 0x83585c: StoreField: r1->field_b = r0
    //     0x83585c: stur            w0, [x1, #0xb]
    // 0x835860: mov             x0, x1
    // 0x835864: r0 = Throw()
    //     0x835864: bl              #0x13ddb2c  ; ThrowStub
    // 0x835868: brk             #0
    // 0x83586c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83586c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x835870: b               #0x835480
    // 0x835874: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x835874: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x835878: b               #0x835690
  }
  [closure] static bool <anonymous closure>(dynamic, MouseTrackerAnnotation) {
    // ** addr: 0x8361d4, size: 0x50
    // 0x8361d4: EnterFrame
    //     0x8361d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8361d8: mov             fp, SP
    // 0x8361dc: ldr             x0, [fp, #0x18]
    // 0x8361e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8361e0: ldur            w1, [x0, #0x17]
    // 0x8361e4: DecompressPointer r1
    //     0x8361e4: add             x1, x1, HEAP, lsl #32
    // 0x8361e8: CheckStackOverflow
    //     0x8361e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8361ec: cmp             SP, x16
    //     0x8361f0: b.ls            #0x83621c
    // 0x8361f4: LoadField: r0 = r1->field_f
    //     0x8361f4: ldur            w0, [x1, #0xf]
    // 0x8361f8: DecompressPointer r0
    //     0x8361f8: add             x0, x0, HEAP, lsl #32
    // 0x8361fc: mov             x1, x0
    // 0x836200: ldr             x2, [fp, #0x10]
    // 0x836204: r0 = containsKey()
    //     0x836204: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x836208: eor             x1, x0, #0x10
    // 0x83620c: mov             x0, x1
    // 0x836210: LeaveFrame
    //     0x836210: mov             SP, fp
    //     0x836214: ldp             fp, lr, [SP], #0x10
    // 0x836218: ret
    //     0x836218: ret             
    // 0x83621c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83621c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836220: b               #0x8361f4
  }
  [closure] static void <anonymous closure>(dynamic, MouseTrackerAnnotation, Matrix4) {
    // ** addr: 0x836274, size: 0x12c
    // 0x836274: EnterFrame
    //     0x836274: stp             fp, lr, [SP, #-0x10]!
    //     0x836278: mov             fp, SP
    // 0x83627c: AllocStack(0x30)
    //     0x83627c: sub             SP, SP, #0x30
    // 0x836280: SetupParameters([dynamic _ /* r0 */])
    //     0x836280: ldr             x0, [fp, #0x20]
    //     0x836284: ldur            w2, [x0, #0x17]
    //     0x836288: add             x2, x2, HEAP, lsl #32
    //     0x83628c: stur            x2, [fp, #-8]
    // 0x836290: CheckStackOverflow
    //     0x836290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836294: cmp             SP, x16
    //     0x836298: b.ls            #0x836398
    // 0x83629c: ldr             x3, [fp, #0x18]
    // 0x8362a0: r0 = LoadClassIdInstr(r3)
    //     0x8362a0: ldur            x0, [x3, #-1]
    //     0x8362a4: ubfx            x0, x0, #0xc, #0x14
    // 0x8362a8: mov             x1, x3
    // 0x8362ac: r0 = GDT[cid_x0 + 0x90f7]()
    //     0x8362ac: mov             x17, #0x90f7
    //     0x8362b0: add             lr, x0, x17
    //     0x8362b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8362b8: blr             lr
    // 0x8362bc: tbnz            w0, #4, #0x836388
    // 0x8362c0: ldur            x0, [fp, #-8]
    // 0x8362c4: LoadField: r1 = r0->field_13
    //     0x8362c4: ldur            w1, [x0, #0x13]
    // 0x8362c8: DecompressPointer r1
    //     0x8362c8: add             x1, x1, HEAP, lsl #32
    // 0x8362cc: ldr             x2, [fp, #0x18]
    // 0x8362d0: r0 = containsKey()
    //     0x8362d0: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x8362d4: tbz             w0, #4, #0x836388
    // 0x8362d8: ldr             x2, [fp, #0x18]
    // 0x8362dc: r0 = LoadClassIdInstr(r2)
    //     0x8362dc: ldur            x0, [x2, #-1]
    //     0x8362e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8362e4: mov             x1, x2
    // 0x8362e8: r0 = GDT[cid_x0 + 0xb1da]()
    //     0x8362e8: mov             x17, #0xb1da
    //     0x8362ec: add             lr, x0, x17
    //     0x8362f0: ldr             lr, [x21, lr, lsl #3]
    //     0x8362f4: blr             lr
    // 0x8362f8: stur            x0, [fp, #-0x20]
    // 0x8362fc: cmp             w0, NULL
    // 0x836300: b.eq            #0x836388
    // 0x836304: ldur            x1, [fp, #-8]
    // 0x836308: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x836308: ldur            w3, [x1, #0x17]
    // 0x83630c: DecompressPointer r3
    //     0x83630c: add             x3, x3, HEAP, lsl #32
    // 0x836310: stur            x3, [fp, #-0x18]
    // 0x836314: LoadField: r4 = r1->field_f
    //     0x836314: ldur            w4, [x1, #0xf]
    // 0x836318: DecompressPointer r4
    //     0x836318: add             x4, x4, HEAP, lsl #32
    // 0x83631c: mov             x1, x4
    // 0x836320: ldr             x2, [fp, #0x18]
    // 0x836324: stur            x4, [fp, #-0x10]
    // 0x836328: r0 = _getValueOrData()
    //     0x836328: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x83632c: mov             x1, x0
    // 0x836330: ldur            x0, [fp, #-0x10]
    // 0x836334: LoadField: r2 = r0->field_f
    //     0x836334: ldur            w2, [x0, #0xf]
    // 0x836338: DecompressPointer r2
    //     0x836338: add             x2, x2, HEAP, lsl #32
    // 0x83633c: cmp             w2, w1
    // 0x836340: b.ne            #0x83634c
    // 0x836344: r2 = Null
    //     0x836344: mov             x2, NULL
    // 0x836348: b               #0x836350
    // 0x83634c: mov             x2, x1
    // 0x836350: ldur            x1, [fp, #-0x18]
    // 0x836354: r0 = LoadClassIdInstr(r1)
    //     0x836354: ldur            x0, [x1, #-1]
    //     0x836358: ubfx            x0, x0, #0xc, #0x14
    // 0x83635c: r0 = GDT[cid_x0 + 0x14eda]()
    //     0x83635c: mov             x17, #0x4eda
    //     0x836360: movk            x17, #1, lsl #16
    //     0x836364: add             lr, x0, x17
    //     0x836368: ldr             lr, [x21, lr, lsl #3]
    //     0x83636c: blr             lr
    // 0x836370: ldur            x16, [fp, #-0x20]
    // 0x836374: stp             x0, x16, [SP]
    // 0x836378: ldur            x0, [fp, #-0x20]
    // 0x83637c: ClosureCall
    //     0x83637c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x836380: ldur            x2, [x0, #0x1f]
    //     0x836384: blr             x2
    // 0x836388: r0 = Null
    //     0x836388: mov             x0, NULL
    // 0x83638c: LeaveFrame
    //     0x83638c: mov             SP, fp
    //     0x836390: ldp             fp, lr, [SP], #0x10
    // 0x836394: ret
    //     0x836394: ret             
    // 0x836398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836398: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83639c: b               #0x83629c
  }
  [closure] MouseCursor <anonymous closure>(dynamic, MouseTrackerAnnotation) {
    // ** addr: 0x8363a0, size: 0x44
    // 0x8363a0: EnterFrame
    //     0x8363a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8363a4: mov             fp, SP
    // 0x8363a8: CheckStackOverflow
    //     0x8363a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8363ac: cmp             SP, x16
    //     0x8363b0: b.ls            #0x8363dc
    // 0x8363b4: ldr             x1, [fp, #0x10]
    // 0x8363b8: r0 = LoadClassIdInstr(r1)
    //     0x8363b8: ldur            x0, [x1, #-1]
    //     0x8363bc: ubfx            x0, x0, #0xc, #0x14
    // 0x8363c0: r0 = GDT[cid_x0 + 0x90fd]()
    //     0x8363c0: mov             x17, #0x90fd
    //     0x8363c4: add             lr, x0, x17
    //     0x8363c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8363cc: blr             lr
    // 0x8363d0: LeaveFrame
    //     0x8363d0: mov             SP, fp
    //     0x8363d4: ldp             fp, lr, [SP], #0x10
    // 0x8363d8: ret
    //     0x8363d8: ret             
    // 0x8363dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8363dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8363e0: b               #0x8363b4
  }
  _ _hitTestInViewResultToAnnotations(/* No info */) {
    // ** addr: 0x836428, size: 0x1d0
    // 0x836428: EnterFrame
    //     0x836428: stp             fp, lr, [SP, #-0x10]!
    //     0x83642c: mov             fp, SP
    // 0x836430: AllocStack(0x40)
    //     0x836430: sub             SP, SP, #0x40
    // 0x836434: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x836434: stur            x2, [fp, #-8]
    // 0x836438: CheckStackOverflow
    //     0x836438: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83643c: cmp             SP, x16
    //     0x836440: b.ls            #0x8365e4
    // 0x836444: r16 = <MouseTrackerAnnotation, Matrix4>
    //     0x836444: ldr             x16, [PP, #0x2198]  ; [pp+0x2198] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x836448: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x83644c: stp             lr, x16, [SP]
    // 0x836450: r0 = Map._fromLiteral()
    //     0x836450: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x836454: mov             x3, x0
    // 0x836458: ldur            x0, [fp, #-8]
    // 0x83645c: stur            x3, [fp, #-0x30]
    // 0x836460: LoadField: r4 = r0->field_7
    //     0x836460: ldur            w4, [x0, #7]
    // 0x836464: DecompressPointer r4
    //     0x836464: add             x4, x4, HEAP, lsl #32
    // 0x836468: stur            x4, [fp, #-0x28]
    // 0x83646c: LoadField: r0 = r4->field_b
    //     0x83646c: ldur            w0, [x4, #0xb]
    // 0x836470: r5 = LoadInt32Instr(r0)
    //     0x836470: sbfx            x5, x0, #1, #0x1f
    // 0x836474: stur            x5, [fp, #-0x20]
    // 0x836478: r0 = 0
    //     0x836478: mov             x0, #0
    // 0x83647c: CheckStackOverflow
    //     0x83647c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836480: cmp             SP, x16
    //     0x836484: b.ls            #0x8365ec
    // 0x836488: LoadField: r1 = r4->field_b
    //     0x836488: ldur            w1, [x4, #0xb]
    // 0x83648c: r2 = LoadInt32Instr(r1)
    //     0x83648c: sbfx            x2, x1, #1, #0x1f
    // 0x836490: cmp             x5, x2
    // 0x836494: b.ne            #0x8365c4
    // 0x836498: cmp             x0, x2
    // 0x83649c: b.ge            #0x8365b4
    // 0x8364a0: LoadField: r1 = r4->field_f
    //     0x8364a0: ldur            w1, [x4, #0xf]
    // 0x8364a4: DecompressPointer r1
    //     0x8364a4: add             x1, x1, HEAP, lsl #32
    // 0x8364a8: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x8364a8: add             x16, x1, x0, lsl #2
    //     0x8364ac: ldur            w6, [x16, #0xf]
    // 0x8364b0: DecompressPointer r6
    //     0x8364b0: add             x6, x6, HEAP, lsl #32
    // 0x8364b4: stur            x6, [fp, #-0x18]
    // 0x8364b8: add             x7, x0, #1
    // 0x8364bc: stur            x7, [fp, #-0x10]
    // 0x8364c0: LoadField: r8 = r6->field_b
    //     0x8364c0: ldur            w8, [x6, #0xb]
    // 0x8364c4: DecompressPointer r8
    //     0x8364c4: add             x8, x8, HEAP, lsl #32
    // 0x8364c8: mov             x0, x8
    // 0x8364cc: stur            x8, [fp, #-8]
    // 0x8364d0: r2 = Null
    //     0x8364d0: mov             x2, NULL
    // 0x8364d4: r1 = Null
    //     0x8364d4: mov             x1, NULL
    // 0x8364d8: cmp             w0, NULL
    // 0x8364dc: b.eq            #0x83655c
    // 0x8364e0: branchIfSmi(r0, 0x83655c)
    //     0x8364e0: tbz             w0, #0, #0x83655c
    // 0x8364e4: r3 = LoadClassIdInstr(r0)
    //     0x8364e4: ldur            x3, [x0, #-1]
    //     0x8364e8: ubfx            x3, x3, #0xc, #0x14
    // 0x8364ec: r4 = LoadClassIdInstr(r0)
    //     0x8364ec: ldur            x4, [x0, #-1]
    //     0x8364f0: ubfx            x4, x4, #0xc, #0x14
    // 0x8364f4: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x8364f8: ldr             x3, [x3, #0x18]
    // 0x8364fc: ldr             x3, [x3, x4, lsl #3]
    // 0x836500: LoadField: r3 = r3->field_2b
    //     0x836500: ldur            w3, [x3, #0x2b]
    // 0x836504: DecompressPointer r3
    //     0x836504: add             x3, x3, HEAP, lsl #32
    // 0x836508: cmp             w3, NULL
    // 0x83650c: b.eq            #0x83655c
    // 0x836510: LoadField: r3 = r3->field_f
    //     0x836510: ldur            w3, [x3, #0xf]
    // 0x836514: lsr             x3, x3, #3
    // 0x836518: r17 = 5300
    //     0x836518: mov             x17, #0x14b4
    // 0x83651c: cmp             x3, x17
    // 0x836520: b.eq            #0x836564
    // 0x836524: r3 = SubtypeTestCache
    //     0x836524: ldr             x3, [PP, #0x2278]  ; [pp+0x2278] SubtypeTestCache
    // 0x836528: r30 = Subtype1TestCacheStub
    //     0x836528: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x83652c: LoadField: r30 = r30->field_7
    //     0x83652c: ldur            lr, [lr, #7]
    // 0x836530: blr             lr
    // 0x836534: cmp             w7, NULL
    // 0x836538: b.eq            #0x836544
    // 0x83653c: tbnz            w7, #4, #0x83655c
    // 0x836540: b               #0x836564
    // 0x836544: r8 = MouseTrackerAnnotation
    //     0x836544: ldr             x8, [PP, #0x2280]  ; [pp+0x2280] Type: MouseTrackerAnnotation
    // 0x836548: r3 = SubtypeTestCache
    //     0x836548: ldr             x3, [PP, #0x2288]  ; [pp+0x2288] SubtypeTestCache
    // 0x83654c: r30 = InstanceOfStub
    //     0x83654c: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x836550: LoadField: r30 = r30->field_7
    //     0x836550: ldur            lr, [lr, #7]
    // 0x836554: blr             lr
    // 0x836558: b               #0x836568
    // 0x83655c: r0 = false
    //     0x83655c: add             x0, NULL, #0x30  ; false
    // 0x836560: b               #0x836568
    // 0x836564: r0 = true
    //     0x836564: add             x0, NULL, #0x20  ; true
    // 0x836568: tbnz            w0, #4, #0x8365a0
    // 0x83656c: ldur            x4, [fp, #-0x30]
    // 0x836570: ldur            x0, [fp, #-0x18]
    // 0x836574: LoadField: r3 = r0->field_f
    //     0x836574: ldur            w3, [x0, #0xf]
    // 0x836578: DecompressPointer r3
    //     0x836578: add             x3, x3, HEAP, lsl #32
    // 0x83657c: cmp             w3, NULL
    // 0x836580: b.eq            #0x8365f4
    // 0x836584: r0 = LoadClassIdInstr(r4)
    //     0x836584: ldur            x0, [x4, #-1]
    //     0x836588: ubfx            x0, x0, #0xc, #0x14
    // 0x83658c: mov             x1, x4
    // 0x836590: ldur            x2, [fp, #-8]
    // 0x836594: r0 = GDT[cid_x0 + -0xd50]()
    //     0x836594: sub             lr, x0, #0xd50
    //     0x836598: ldr             lr, [x21, lr, lsl #3]
    //     0x83659c: blr             lr
    // 0x8365a0: ldur            x0, [fp, #-0x10]
    // 0x8365a4: ldur            x3, [fp, #-0x30]
    // 0x8365a8: ldur            x4, [fp, #-0x28]
    // 0x8365ac: ldur            x5, [fp, #-0x20]
    // 0x8365b0: b               #0x83647c
    // 0x8365b4: ldur            x0, [fp, #-0x30]
    // 0x8365b8: LeaveFrame
    //     0x8365b8: mov             SP, fp
    //     0x8365bc: ldp             fp, lr, [SP], #0x10
    // 0x8365c0: ret
    //     0x8365c0: ret             
    // 0x8365c4: mov             x0, x4
    // 0x8365c8: r0 = ConcurrentModificationError()
    //     0x8365c8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8365cc: mov             x1, x0
    // 0x8365d0: ldur            x0, [fp, #-0x28]
    // 0x8365d4: StoreField: r1->field_b = r0
    //     0x8365d4: stur            w0, [x1, #0xb]
    // 0x8365d8: mov             x0, x1
    // 0x8365dc: r0 = Throw()
    //     0x8365dc: bl              #0x13ddb2c  ; ThrowStub
    // 0x8365e0: brk             #0
    // 0x8365e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8365e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8365e8: b               #0x836444
    // 0x8365ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8365ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8365f0: b               #0x836488
    // 0x8365f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8365f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ mouseIsConnected(/* No info */) {
    // ** addr: 0x83bdac, size: 0x38
    // 0x83bdac: EnterFrame
    //     0x83bdac: stp             fp, lr, [SP, #-0x10]!
    //     0x83bdb0: mov             fp, SP
    // 0x83bdb4: CheckStackOverflow
    //     0x83bdb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83bdb8: cmp             SP, x16
    //     0x83bdbc: b.ls            #0x83bddc
    // 0x83bdc0: LoadField: r0 = r1->field_2b
    //     0x83bdc0: ldur            w0, [x1, #0x2b]
    // 0x83bdc4: DecompressPointer r0
    //     0x83bdc4: add             x0, x0, HEAP, lsl #32
    // 0x83bdc8: mov             x1, x0
    // 0x83bdcc: r0 = isNotEmpty()
    //     0x83bdcc: bl              #0xbecd80  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::isNotEmpty
    // 0x83bdd0: LeaveFrame
    //     0x83bdd0: mov             SP, fp
    //     0x83bdd4: ldp             fp, lr, [SP], #0x10
    // 0x83bdd8: ret
    //     0x83bdd8: ret             
    // 0x83bddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bddc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83bde0: b               #0x83bdc0
  }
  _ MouseTracker(/* No info */) {
    // ** addr: 0x8447e4, size: 0x124
    // 0x8447e4: EnterFrame
    //     0x8447e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8447e8: mov             fp, SP
    // 0x8447ec: AllocStack(0x28)
    //     0x8447ec: sub             SP, SP, #0x28
    // 0x8447f0: SetupParameters(MouseTracker this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x8447f0: mov             x0, x2
    //     0x8447f4: stur            x1, [fp, #-8]
    //     0x8447f8: stur            x2, [fp, #-0x10]
    // 0x8447fc: CheckStackOverflow
    //     0x8447fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x844800: cmp             SP, x16
    //     0x844804: b.ls            #0x844900
    // 0x844808: r16 = <int, MouseCursorSession>
    //     0x844808: ldr             x16, [PP, #0x2f10]  ; [pp+0x2f10] TypeArguments: <int, MouseCursorSession>
    // 0x84480c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x844810: stp             lr, x16, [SP]
    // 0x844814: r0 = Map._fromLiteral()
    //     0x844814: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x844818: stur            x0, [fp, #-0x18]
    // 0x84481c: r0 = MouseCursorManager()
    //     0x84481c: bl              #0x844908  ; AllocateMouseCursorManagerStub -> MouseCursorManager (size=0x10)
    // 0x844820: mov             x1, x0
    // 0x844824: ldur            x0, [fp, #-0x18]
    // 0x844828: StoreField: r1->field_b = r0
    //     0x844828: stur            w0, [x1, #0xb]
    // 0x84482c: r0 = Instance_SystemMouseCursor
    //     0x84482c: ldr             x0, [PP, #0x21b0]  ; [pp+0x21b0] Obj!SystemMouseCursor@12b3201
    // 0x844830: StoreField: r1->field_7 = r0
    //     0x844830: stur            w0, [x1, #7]
    // 0x844834: mov             x0, x1
    // 0x844838: ldur            x1, [fp, #-8]
    // 0x84483c: StoreField: r1->field_27 = r0
    //     0x84483c: stur            w0, [x1, #0x27]
    //     0x844840: ldurb           w16, [x1, #-1]
    //     0x844844: ldurb           w17, [x0, #-1]
    //     0x844848: and             x16, x17, x16, lsr #2
    //     0x84484c: tst             x16, HEAP, lsr #32
    //     0x844850: b.eq            #0x844858
    //     0x844854: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x844858: r16 = <int, _MouseState>
    //     0x844858: ldr             x16, [PP, #0x2f18]  ; [pp+0x2f18] TypeArguments: <int, _MouseState>
    // 0x84485c: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x844860: stp             lr, x16, [SP]
    // 0x844864: r0 = Map._fromLiteral()
    //     0x844864: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x844868: ldur            x1, [fp, #-8]
    // 0x84486c: StoreField: r1->field_2b = r0
    //     0x84486c: stur            w0, [x1, #0x2b]
    //     0x844870: ldurb           w16, [x1, #-1]
    //     0x844874: ldurb           w17, [x0, #-1]
    //     0x844878: and             x16, x17, x16, lsr #2
    //     0x84487c: tst             x16, HEAP, lsr #32
    //     0x844880: b.eq            #0x844888
    //     0x844884: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x844888: ldur            x0, [fp, #-0x10]
    // 0x84488c: StoreField: r1->field_23 = r0
    //     0x84488c: stur            w0, [x1, #0x23]
    //     0x844890: ldurb           w16, [x1, #-1]
    //     0x844894: ldurb           w17, [x0, #-1]
    //     0x844898: and             x16, x17, x16, lsr #2
    //     0x84489c: tst             x16, HEAP, lsr #32
    //     0x8448a0: b.eq            #0x8448a8
    //     0x8448a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8448a8: StoreField: r1->field_7 = rZR
    //     0x8448a8: stur            xzr, [x1, #7]
    // 0x8448ac: StoreField: r1->field_13 = rZR
    //     0x8448ac: stur            xzr, [x1, #0x13]
    // 0x8448b0: StoreField: r1->field_1b = rZR
    //     0x8448b0: stur            xzr, [x1, #0x1b]
    // 0x8448b4: r0 = LoadStaticField(0x45c)
    //     0x8448b4: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x8448b8: ldr             x0, [x0, #0x8b8]
    // 0x8448bc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8448c0: cmp             w0, w16
    // 0x8448c4: b.ne            #0x8448d0
    // 0x8448c8: r2 = _emptyListeners
    //     0x8448c8: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0x8448cc: r0 = InitLateFinalStaticField()
    //     0x8448cc: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x8448d0: ldur            x1, [fp, #-8]
    // 0x8448d4: StoreField: r1->field_f = r0
    //     0x8448d4: stur            w0, [x1, #0xf]
    //     0x8448d8: ldurb           w16, [x1, #-1]
    //     0x8448dc: ldurb           w17, [x0, #-1]
    //     0x8448e0: and             x16, x17, x16, lsr #2
    //     0x8448e4: tst             x16, HEAP, lsr #32
    //     0x8448e8: b.eq            #0x8448f0
    //     0x8448ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8448f0: r0 = Null
    //     0x8448f0: mov             x0, NULL
    // 0x8448f4: LeaveFrame
    //     0x8448f4: mov             SP, fp
    //     0x8448f8: ldp             fp, lr, [SP], #0x10
    // 0x8448fc: ret
    //     0x8448fc: ret             
    // 0x844900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844900: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844904: b               #0x844808
  }
  _ updateAllDevices(/* No info */) {
    // ** addr: 0x87d91c, size: 0x60
    // 0x87d91c: EnterFrame
    //     0x87d91c: stp             fp, lr, [SP, #-0x10]!
    //     0x87d920: mov             fp, SP
    // 0x87d924: AllocStack(0x8)
    //     0x87d924: sub             SP, SP, #8
    // 0x87d928: SetupParameters(MouseTracker this /* r1 => r1, fp-0x8 */)
    //     0x87d928: stur            x1, [fp, #-8]
    // 0x87d92c: CheckStackOverflow
    //     0x87d92c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d930: cmp             SP, x16
    //     0x87d934: b.ls            #0x87d974
    // 0x87d938: r1 = 1
    //     0x87d938: mov             x1, #1
    // 0x87d93c: r0 = AllocateContext()
    //     0x87d93c: bl              #0x13de838  ; AllocateContextStub
    // 0x87d940: mov             x1, x0
    // 0x87d944: ldur            x0, [fp, #-8]
    // 0x87d948: StoreField: r1->field_f = r0
    //     0x87d948: stur            w0, [x1, #0xf]
    // 0x87d94c: mov             x2, x1
    // 0x87d950: r1 = Function '<anonymous closure>':.
    //     0x87d950: ldr             x1, [PP, #0x2178]  ; [pp+0x2178] AnonymousClosure: (0x87d97c), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::updateAllDevices (0x87d91c)
    // 0x87d954: r0 = AllocateClosure()
    //     0x87d954: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87d958: ldur            x1, [fp, #-8]
    // 0x87d95c: mov             x2, x0
    // 0x87d960: r0 = lockState()
    //     0x87d960: bl              #0x8349d0  ; [package:flutter/src/widgets/framework.dart] BuildOwner::lockState
    // 0x87d964: r0 = Null
    //     0x87d964: mov             x0, NULL
    // 0x87d968: LeaveFrame
    //     0x87d968: mov             SP, fp
    //     0x87d96c: ldp             fp, lr, [SP], #0x10
    // 0x87d970: ret
    //     0x87d970: ret             
    // 0x87d974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87d974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87d978: b               #0x87d938
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x87d97c, size: 0x208
    // 0x87d97c: EnterFrame
    //     0x87d97c: stp             fp, lr, [SP, #-0x10]!
    //     0x87d980: mov             fp, SP
    // 0x87d984: AllocStack(0x60)
    //     0x87d984: sub             SP, SP, #0x60
    // 0x87d988: SetupParameters([dynamic _ /* r0 */])
    //     0x87d988: ldr             x0, [fp, #0x10]
    //     0x87d98c: ldur            w2, [x0, #0x17]
    //     0x87d990: add             x2, x2, HEAP, lsl #32
    //     0x87d994: stur            x2, [fp, #-0x10]
    // 0x87d998: CheckStackOverflow
    //     0x87d998: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d99c: cmp             SP, x16
    //     0x87d9a0: b.ls            #0x87db74
    // 0x87d9a4: LoadField: r0 = r2->field_f
    //     0x87d9a4: ldur            w0, [x2, #0xf]
    // 0x87d9a8: DecompressPointer r0
    //     0x87d9a8: add             x0, x0, HEAP, lsl #32
    // 0x87d9ac: LoadField: r3 = r0->field_2b
    //     0x87d9ac: ldur            w3, [x0, #0x2b]
    // 0x87d9b0: DecompressPointer r3
    //     0x87d9b0: add             x3, x3, HEAP, lsl #32
    // 0x87d9b4: stur            x3, [fp, #-8]
    // 0x87d9b8: r1 = <_MouseState>
    //     0x87d9b8: ldr             x1, [PP, #0x2180]  ; [pp+0x2180] TypeArguments: <_MouseState>
    // 0x87d9bc: r0 = _CompactValuesIterable()
    //     0x87d9bc: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x87d9c0: mov             x1, x0
    // 0x87d9c4: ldur            x0, [fp, #-8]
    // 0x87d9c8: StoreField: r1->field_b = r0
    //     0x87d9c8: stur            w0, [x1, #0xb]
    // 0x87d9cc: r0 = iterator()
    //     0x87d9cc: bl              #0xb09b20  ; [dart:_compact_hash] _CompactValuesIterable::iterator
    // 0x87d9d0: stur            x0, [fp, #-0x18]
    // 0x87d9d4: LoadField: r2 = r0->field_7
    //     0x87d9d4: ldur            w2, [x0, #7]
    // 0x87d9d8: DecompressPointer r2
    //     0x87d9d8: add             x2, x2, HEAP, lsl #32
    // 0x87d9dc: stur            x2, [fp, #-8]
    // 0x87d9e0: ldur            x3, [fp, #-0x10]
    // 0x87d9e4: CheckStackOverflow
    //     0x87d9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87d9e8: cmp             SP, x16
    //     0x87d9ec: b.ls            #0x87db7c
    // 0x87d9f0: mov             x1, x0
    // 0x87d9f4: r0 = moveNext()
    //     0x87d9f4: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x87d9f8: tbnz            w0, #4, #0x87db64
    // 0x87d9fc: ldur            x3, [fp, #-0x18]
    // 0x87da00: LoadField: r4 = r3->field_33
    //     0x87da00: ldur            w4, [x3, #0x33]
    // 0x87da04: DecompressPointer r4
    //     0x87da04: add             x4, x4, HEAP, lsl #32
    // 0x87da08: stur            x4, [fp, #-0x20]
    // 0x87da0c: cmp             w4, NULL
    // 0x87da10: b.ne            #0x87da40
    // 0x87da14: mov             x0, x4
    // 0x87da18: ldur            x2, [fp, #-8]
    // 0x87da1c: r1 = Null
    //     0x87da1c: mov             x1, NULL
    // 0x87da20: cmp             w2, NULL
    // 0x87da24: b.eq            #0x87da40
    // 0x87da28: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87da28: ldur            w4, [x2, #0x17]
    // 0x87da2c: DecompressPointer r4
    //     0x87da2c: add             x4, x4, HEAP, lsl #32
    // 0x87da30: r8 = X0
    //     0x87da30: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87da34: LoadField: r9 = r4->field_7
    //     0x87da34: ldur            x9, [x4, #7]
    // 0x87da38: r3 = Null
    //     0x87da38: ldr             x3, [PP, #0x2188]  ; [pp+0x2188] Null
    // 0x87da3c: blr             x9
    // 0x87da40: ldur            x3, [fp, #-0x10]
    // 0x87da44: ldur            x0, [fp, #-0x20]
    // 0x87da48: LoadField: r4 = r0->field_b
    //     0x87da48: ldur            w4, [x0, #0xb]
    // 0x87da4c: DecompressPointer r4
    //     0x87da4c: add             x4, x4, HEAP, lsl #32
    // 0x87da50: stur            x4, [fp, #-0x28]
    // 0x87da54: LoadField: r1 = r3->field_f
    //     0x87da54: ldur            w1, [x3, #0xf]
    // 0x87da58: DecompressPointer r1
    //     0x87da58: add             x1, x1, HEAP, lsl #32
    // 0x87da5c: mov             x2, x0
    // 0x87da60: r0 = _findAnnotations()
    //     0x87da60: bl              #0x87db84  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_findAnnotations
    // 0x87da64: mov             x2, x0
    // 0x87da68: ldur            x1, [fp, #-0x20]
    // 0x87da6c: stur            x2, [fp, #-0x38]
    // 0x87da70: LoadField: r3 = r1->field_7
    //     0x87da70: ldur            w3, [x1, #7]
    // 0x87da74: DecompressPointer r3
    //     0x87da74: add             x3, x3, HEAP, lsl #32
    // 0x87da78: mov             x0, x2
    // 0x87da7c: stur            x3, [fp, #-0x30]
    // 0x87da80: StoreField: r1->field_7 = r0
    //     0x87da80: stur            w0, [x1, #7]
    //     0x87da84: ldurb           w16, [x1, #-1]
    //     0x87da88: ldurb           w17, [x0, #-1]
    //     0x87da8c: and             x16, x17, x16, lsr #2
    //     0x87da90: tst             x16, HEAP, lsr #32
    //     0x87da94: b.eq            #0x87da9c
    //     0x87da98: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x87da9c: ldur            x0, [fp, #-0x10]
    // 0x87daa0: LoadField: r1 = r0->field_f
    //     0x87daa0: ldur            w1, [x0, #0xf]
    // 0x87daa4: DecompressPointer r1
    //     0x87daa4: add             x1, x1, HEAP, lsl #32
    // 0x87daa8: stur            x1, [fp, #-0x20]
    // 0x87daac: r0 = _MouseTrackerUpdateDetails()
    //     0x87daac: bl              #0x8363e4  ; Allocate_MouseTrackerUpdateDetailsStub -> _MouseTrackerUpdateDetails (size=0x18)
    // 0x87dab0: mov             x2, x0
    // 0x87dab4: ldur            x0, [fp, #-0x30]
    // 0x87dab8: stur            x2, [fp, #-0x40]
    // 0x87dabc: StoreField: r2->field_7 = r0
    //     0x87dabc: stur            w0, [x2, #7]
    // 0x87dac0: ldur            x0, [fp, #-0x38]
    // 0x87dac4: StoreField: r2->field_b = r0
    //     0x87dac4: stur            w0, [x2, #0xb]
    // 0x87dac8: ldur            x1, [fp, #-0x28]
    // 0x87dacc: StoreField: r2->field_f = r1
    //     0x87dacc: stur            w1, [x2, #0xf]
    // 0x87dad0: mov             x1, x2
    // 0x87dad4: r0 = _handleDeviceUpdateMouseEvents()
    //     0x87dad4: bl              #0x835464  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdateMouseEvents
    // 0x87dad8: ldur            x0, [fp, #-0x20]
    // 0x87dadc: LoadField: r2 = r0->field_27
    //     0x87dadc: ldur            w2, [x0, #0x27]
    // 0x87dae0: DecompressPointer r2
    //     0x87dae0: add             x2, x2, HEAP, lsl #32
    // 0x87dae4: ldur            x1, [fp, #-0x40]
    // 0x87dae8: stur            x2, [fp, #-0x28]
    // 0x87daec: r0 = device()
    //     0x87daec: bl              #0x834ea8  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseTrackerUpdateDetails::device
    // 0x87daf0: mov             x2, x0
    // 0x87daf4: ldur            x0, [fp, #-0x40]
    // 0x87daf8: stur            x2, [fp, #-0x48]
    // 0x87dafc: LoadField: r3 = r0->field_13
    //     0x87dafc: ldur            w3, [x0, #0x13]
    // 0x87db00: DecompressPointer r3
    //     0x87db00: add             x3, x3, HEAP, lsl #32
    // 0x87db04: stur            x3, [fp, #-0x20]
    // 0x87db08: r1 = <MouseTrackerAnnotation, Matrix4>
    //     0x87db08: ldr             x1, [PP, #0x2198]  ; [pp+0x2198] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x87db0c: r0 = _CompactKeysIterable()
    //     0x87db0c: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0x87db10: mov             x3, x0
    // 0x87db14: ldur            x0, [fp, #-0x38]
    // 0x87db18: stur            x3, [fp, #-0x30]
    // 0x87db1c: StoreField: r3->field_b = r0
    //     0x87db1c: stur            w0, [x3, #0xb]
    // 0x87db20: r1 = Function '<anonymous closure>':.
    //     0x87db20: ldr             x1, [PP, #0x21a0]  ; [pp+0x21a0] AnonymousClosure: (0x8363a0), in [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_handleDeviceUpdate (0x834db4)
    // 0x87db24: r2 = Null
    //     0x87db24: mov             x2, NULL
    // 0x87db28: r0 = AllocateClosure()
    //     0x87db28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87db2c: r16 = <MouseCursor>
    //     0x87db2c: ldr             x16, [PP, #0x21a8]  ; [pp+0x21a8] TypeArguments: <MouseCursor>
    // 0x87db30: ldur            lr, [fp, #-0x30]
    // 0x87db34: stp             lr, x16, [SP, #8]
    // 0x87db38: str             x0, [SP]
    // 0x87db3c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x87db3c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x87db40: r0 = map()
    //     0x87db40: bl              #0xb007e4  ; [dart:core] Iterable::map
    // 0x87db44: ldur            x1, [fp, #-0x28]
    // 0x87db48: ldur            x2, [fp, #-0x48]
    // 0x87db4c: ldur            x3, [fp, #-0x20]
    // 0x87db50: mov             x5, x0
    // 0x87db54: r0 = handleDeviceCursorUpdate()
    //     0x87db54: bl              #0x834f00  ; [package:flutter/src/services/mouse_cursor.dart] MouseCursorManager::handleDeviceCursorUpdate
    // 0x87db58: ldur            x0, [fp, #-0x18]
    // 0x87db5c: ldur            x2, [fp, #-8]
    // 0x87db60: b               #0x87d9e0
    // 0x87db64: r0 = Null
    //     0x87db64: mov             x0, NULL
    // 0x87db68: LeaveFrame
    //     0x87db68: mov             SP, fp
    //     0x87db6c: ldp             fp, lr, [SP], #0x10
    // 0x87db70: ret
    //     0x87db70: ret             
    // 0x87db74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87db74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87db78: b               #0x87d9a4
    // 0x87db7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87db7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87db80: b               #0x87d9f0
  }
  _ _findAnnotations(/* No info */) {
    // ** addr: 0x87db84, size: 0x13c
    // 0x87db84: EnterFrame
    //     0x87db84: stp             fp, lr, [SP, #-0x10]!
    //     0x87db88: mov             fp, SP
    // 0x87db8c: AllocStack(0x40)
    //     0x87db8c: sub             SP, SP, #0x40
    // 0x87db90: SetupParameters(MouseTracker this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x87db90: mov             x3, x1
    //     0x87db94: stur            x1, [fp, #-8]
    //     0x87db98: stur            x2, [fp, #-0x10]
    // 0x87db9c: CheckStackOverflow
    //     0x87db9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87dba0: cmp             SP, x16
    //     0x87dba4: b.ls            #0x87dcb8
    // 0x87dba8: LoadField: r1 = r2->field_b
    //     0x87dba8: ldur            w1, [x2, #0xb]
    // 0x87dbac: DecompressPointer r1
    //     0x87dbac: add             x1, x1, HEAP, lsl #32
    // 0x87dbb0: r0 = LoadClassIdInstr(r1)
    //     0x87dbb0: ldur            x0, [x1, #-1]
    //     0x87dbb4: ubfx            x0, x0, #0xc, #0x14
    // 0x87dbb8: r0 = GDT[cid_x0 + 0x13f27]()
    //     0x87dbb8: mov             x17, #0x3f27
    //     0x87dbbc: movk            x17, #1, lsl #16
    //     0x87dbc0: add             lr, x0, x17
    //     0x87dbc4: ldr             lr, [x21, lr, lsl #3]
    //     0x87dbc8: blr             lr
    // 0x87dbcc: ldur            x1, [fp, #-0x10]
    // 0x87dbd0: stur            x0, [fp, #-0x18]
    // 0x87dbd4: r0 = device()
    //     0x87dbd4: bl              #0x87dcc0  ; [package:flutter/src/rendering/mouse_tracker.dart] _MouseState::device
    // 0x87dbd8: mov             x2, x0
    // 0x87dbdc: ldur            x0, [fp, #-0x10]
    // 0x87dbe0: stur            x2, [fp, #-0x20]
    // 0x87dbe4: LoadField: r1 = r0->field_b
    //     0x87dbe4: ldur            w1, [x0, #0xb]
    // 0x87dbe8: DecompressPointer r1
    //     0x87dbe8: add             x1, x1, HEAP, lsl #32
    // 0x87dbec: r0 = LoadClassIdInstr(r1)
    //     0x87dbec: ldur            x0, [x1, #-1]
    //     0x87dbf0: ubfx            x0, x0, #0xc, #0x14
    // 0x87dbf4: r0 = GDT[cid_x0 + 0x149dc]()
    //     0x87dbf4: mov             x17, #0x49dc
    //     0x87dbf8: movk            x17, #1, lsl #16
    //     0x87dbfc: add             lr, x0, x17
    //     0x87dc00: ldr             lr, [x21, lr, lsl #3]
    //     0x87dc04: blr             lr
    // 0x87dc08: mov             x4, x0
    // 0x87dc0c: ldur            x3, [fp, #-8]
    // 0x87dc10: stur            x4, [fp, #-0x28]
    // 0x87dc14: LoadField: r2 = r3->field_2b
    //     0x87dc14: ldur            w2, [x3, #0x2b]
    // 0x87dc18: DecompressPointer r2
    //     0x87dc18: add             x2, x2, HEAP, lsl #32
    // 0x87dc1c: ldur            x5, [fp, #-0x20]
    // 0x87dc20: r0 = BoxInt64Instr(r5)
    //     0x87dc20: sbfiz           x0, x5, #1, #0x1f
    //     0x87dc24: cmp             x5, x0, asr #1
    //     0x87dc28: b.eq            #0x87dc34
    //     0x87dc2c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87dc30: stur            x5, [x0, #7]
    // 0x87dc34: mov             x1, x2
    // 0x87dc38: mov             x2, x0
    // 0x87dc3c: r0 = containsKey()
    //     0x87dc3c: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x87dc40: tbz             w0, #4, #0x87dc60
    // 0x87dc44: r16 = <MouseTrackerAnnotation, Matrix4>
    //     0x87dc44: ldr             x16, [PP, #0x2198]  ; [pp+0x2198] TypeArguments: <MouseTrackerAnnotation, Matrix4>
    // 0x87dc48: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x87dc4c: stp             lr, x16, [SP]
    // 0x87dc50: r0 = Map._fromLiteral()
    //     0x87dc50: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x87dc54: LeaveFrame
    //     0x87dc54: mov             SP, fp
    //     0x87dc58: ldp             fp, lr, [SP], #0x10
    // 0x87dc5c: ret
    //     0x87dc5c: ret             
    // 0x87dc60: ldur            x2, [fp, #-8]
    // 0x87dc64: ldur            x3, [fp, #-0x28]
    // 0x87dc68: LoadField: r4 = r2->field_23
    //     0x87dc68: ldur            w4, [x2, #0x23]
    // 0x87dc6c: DecompressPointer r4
    //     0x87dc6c: add             x4, x4, HEAP, lsl #32
    // 0x87dc70: r0 = BoxInt64Instr(r3)
    //     0x87dc70: sbfiz           x0, x3, #1, #0x1f
    //     0x87dc74: cmp             x3, x0, asr #1
    //     0x87dc78: b.eq            #0x87dc84
    //     0x87dc7c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x87dc80: stur            x3, [x0, #7]
    // 0x87dc84: ldur            x16, [fp, #-0x18]
    // 0x87dc88: stp             x16, x4, [SP, #8]
    // 0x87dc8c: str             x0, [SP]
    // 0x87dc90: mov             x0, x4
    // 0x87dc94: ClosureCall
    //     0x87dc94: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x87dc98: ldur            x2, [x0, #0x1f]
    //     0x87dc9c: blr             x2
    // 0x87dca0: ldur            x1, [fp, #-8]
    // 0x87dca4: mov             x2, x0
    // 0x87dca8: r0 = _hitTestInViewResultToAnnotations()
    //     0x87dca8: bl              #0x836428  ; [package:flutter/src/rendering/mouse_tracker.dart] MouseTracker::_hitTestInViewResultToAnnotations
    // 0x87dcac: LeaveFrame
    //     0x87dcac: mov             SP, fp
    //     0x87dcb0: ldp             fp, lr, [SP], #0x10
    // 0x87dcb4: ret
    //     0x87dcb4: ret             
    // 0x87dcb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87dcb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87dcbc: b               #0x87dba8
  }
}

// class id: 5039, size: 0x18, field offset: 0x8
//   const constructor, 
class _MouseTrackerUpdateDetails extends _MixinApplication3&Object&Diagnosticable {

  get _ device(/* No info */) {
    // ** addr: 0x834ea8, size: 0x58
    // 0x834ea8: EnterFrame
    //     0x834ea8: stp             fp, lr, [SP, #-0x10]!
    //     0x834eac: mov             fp, SP
    // 0x834eb0: CheckStackOverflow
    //     0x834eb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x834eb4: cmp             SP, x16
    //     0x834eb8: b.ls            #0x834ef8
    // 0x834ebc: LoadField: r0 = r1->field_f
    //     0x834ebc: ldur            w0, [x1, #0xf]
    // 0x834ec0: DecompressPointer r0
    //     0x834ec0: add             x0, x0, HEAP, lsl #32
    // 0x834ec4: r1 = LoadClassIdInstr(r0)
    //     0x834ec4: ldur            x1, [x0, #-1]
    //     0x834ec8: ubfx            x1, x1, #0xc, #0x14
    // 0x834ecc: mov             x16, x0
    // 0x834ed0: mov             x0, x1
    // 0x834ed4: mov             x1, x16
    // 0x834ed8: r0 = GDT[cid_x0 + 0x15a90]()
    //     0x834ed8: mov             x17, #0x5a90
    //     0x834edc: movk            x17, #1, lsl #16
    //     0x834ee0: add             lr, x0, x17
    //     0x834ee4: ldr             lr, [x21, lr, lsl #3]
    //     0x834ee8: blr             lr
    // 0x834eec: LeaveFrame
    //     0x834eec: mov             SP, fp
    //     0x834ef0: ldp             fp, lr, [SP], #0x10
    // 0x834ef4: ret
    //     0x834ef4: ret             
    // 0x834ef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x834ef8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x834efc: b               #0x834ebc
  }
}
