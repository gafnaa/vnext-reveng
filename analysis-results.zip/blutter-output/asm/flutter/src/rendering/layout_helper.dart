// lib: , url: package:flutter/src/rendering/layout_helper.dart

// class id: 1049031, size: 0x8
class :: {
}

// class id: 2864, size: 0x8, field offset: 0x8
abstract class ChildLayoutHelper extends Object {

  [closure] static double? getDryBaseline(dynamic, RenderBox, BoxConstraints, TextBaseline) {
    // ** addr: 0xb19640, size: 0x38
    // 0xb19640: EnterFrame
    //     0xb19640: stp             fp, lr, [SP, #-0x10]!
    //     0xb19644: mov             fp, SP
    // 0xb19648: CheckStackOverflow
    //     0xb19648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1964c: cmp             SP, x16
    //     0xb19650: b.ls            #0xb19670
    // 0xb19654: ldr             x1, [fp, #0x20]
    // 0xb19658: ldr             x2, [fp, #0x18]
    // 0xb1965c: ldr             x3, [fp, #0x10]
    // 0xb19660: r0 = getDryBaseline()
    //     0xb19660: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb19664: LeaveFrame
    //     0xb19664: mov             SP, fp
    //     0xb19668: ldp             fp, lr, [SP], #0x10
    // 0xb1966c: ret
    //     0xb1966c: ret             
    // 0xb19670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb19670: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb19674: b               #0xb19654
  }
  [closure] static Size dryLayoutChild(dynamic, RenderBox, BoxConstraints) {
    // ** addr: 0xb2b214, size: 0x34
    // 0xb2b214: EnterFrame
    //     0xb2b214: stp             fp, lr, [SP, #-0x10]!
    //     0xb2b218: mov             fp, SP
    // 0xb2b21c: CheckStackOverflow
    //     0xb2b21c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2b220: cmp             SP, x16
    //     0xb2b224: b.ls            #0xb2b240
    // 0xb2b228: ldr             x1, [fp, #0x18]
    // 0xb2b22c: ldr             x2, [fp, #0x10]
    // 0xb2b230: r0 = getDryLayout()
    //     0xb2b230: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb2b234: LeaveFrame
    //     0xb2b234: mov             SP, fp
    //     0xb2b238: ldp             fp, lr, [SP], #0x10
    // 0xb2b23c: ret
    //     0xb2b23c: ret             
    // 0xb2b240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2b240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2b244: b               #0xb2b228
  }
  [closure] static Size layoutChild(dynamic, RenderBox, BoxConstraints) {
    // ** addr: 0xb4de18, size: 0x34
    // 0xb4de18: EnterFrame
    //     0xb4de18: stp             fp, lr, [SP, #-0x10]!
    //     0xb4de1c: mov             fp, SP
    // 0xb4de20: CheckStackOverflow
    //     0xb4de20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4de24: cmp             SP, x16
    //     0xb4de28: b.ls            #0xb4de44
    // 0xb4de2c: ldr             x1, [fp, #0x18]
    // 0xb4de30: ldr             x2, [fp, #0x10]
    // 0xb4de34: r0 = layoutChild()
    //     0xb4de34: bl              #0xb4de4c  ; [package:flutter/src/rendering/layout_helper.dart] ChildLayoutHelper::layoutChild
    // 0xb4de38: LeaveFrame
    //     0xb4de38: mov             SP, fp
    //     0xb4de3c: ldp             fp, lr, [SP], #0x10
    // 0xb4de40: ret
    //     0xb4de40: ret             
    // 0xb4de44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4de44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4de48: b               #0xb4de2c
  }
  static _ layoutChild(/* No info */) {
    // ** addr: 0xb4de4c, size: 0x68
    // 0xb4de4c: EnterFrame
    //     0xb4de4c: stp             fp, lr, [SP, #-0x10]!
    //     0xb4de50: mov             fp, SP
    // 0xb4de54: AllocStack(0x10)
    //     0xb4de54: sub             SP, SP, #0x10
    // 0xb4de58: SetupParameters(dynamic _ /* r1 => r3, fp-0x8 */)
    //     0xb4de58: mov             x3, x1
    //     0xb4de5c: stur            x1, [fp, #-8]
    // 0xb4de60: CheckStackOverflow
    //     0xb4de60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4de64: cmp             SP, x16
    //     0xb4de68: b.ls            #0xb4deac
    // 0xb4de6c: r0 = LoadClassIdInstr(r3)
    //     0xb4de6c: ldur            x0, [x3, #-1]
    //     0xb4de70: ubfx            x0, x0, #0xc, #0x14
    // 0xb4de74: r16 = true
    //     0xb4de74: add             x16, NULL, #0x20  ; true
    // 0xb4de78: str             x16, [SP]
    // 0xb4de7c: mov             x1, x3
    // 0xb4de80: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xb4de80: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xb4de84: ldr             x4, [x4, #0xed0]
    // 0xb4de88: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xb4de88: mov             x17, #0xe6b9
    //     0xb4de8c: add             lr, x0, x17
    //     0xb4de90: ldr             lr, [x21, lr, lsl #3]
    //     0xb4de94: blr             lr
    // 0xb4de98: ldur            x1, [fp, #-8]
    // 0xb4de9c: r0 = size()
    //     0xb4de9c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xb4dea0: LeaveFrame
    //     0xb4dea0: mov             SP, fp
    //     0xb4dea4: ldp             fp, lr, [SP], #0x10
    // 0xb4dea8: ret
    //     0xb4dea8: ret             
    // 0xb4deac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4deac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4deb0: b               #0xb4de6c
  }
  [closure] static double? getBaseline(dynamic, RenderBox, BoxConstraints, TextBaseline) {
    // ** addr: 0xbbfca0, size: 0x48
    // 0xbbfca0: EnterFrame
    //     0xbbfca0: stp             fp, lr, [SP, #-0x10]!
    //     0xbbfca4: mov             fp, SP
    // 0xbbfca8: AllocStack(0x8)
    //     0xbbfca8: sub             SP, SP, #8
    // 0xbbfcac: CheckStackOverflow
    //     0xbbfcac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbfcb0: cmp             SP, x16
    //     0xbbfcb4: b.ls            #0xbbfce0
    // 0xbbfcb8: r16 = true
    //     0xbbfcb8: add             x16, NULL, #0x20  ; true
    // 0xbbfcbc: str             x16, [SP]
    // 0xbbfcc0: ldr             x1, [fp, #0x20]
    // 0xbbfcc4: ldr             x2, [fp, #0x10]
    // 0xbbfcc8: r4 = const [0, 0x3, 0x1, 0x2, onlyReal, 0x2, null]
    //     0xbbfcc8: add             x4, PP, #0x90, lsl #12  ; [pp+0x907d0] List(7) [0, 0x3, 0x1, 0x2, "onlyReal", 0x2, Null]
    //     0xbbfccc: ldr             x4, [x4, #0x7d0]
    // 0xbbfcd0: r0 = getDistanceToBaseline()
    //     0xbbfcd0: bl              #0xb53c94  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToBaseline
    // 0xbbfcd4: LeaveFrame
    //     0xbbfcd4: mov             SP, fp
    //     0xbbfcd8: ldp             fp, lr, [SP], #0x10
    // 0xbbfcdc: ret
    //     0xbbfcdc: ret             
    // 0xbbfce0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbfce0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbfce4: b               #0xbbfcb8
  }
}
