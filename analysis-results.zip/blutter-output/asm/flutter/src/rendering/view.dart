// lib: , url: package:flutter/src/rendering/view.dart

// class id: 1049054, size: 0x8
class :: {
}

// class id: 2843, size: 0x18, field offset: 0x8
//   const constructor, 
class ViewConfiguration extends Object {

  _ toPhysicalSize(/* No info */) {
    // ** addr: 0x898b6c, size: 0x54
    // 0x898b6c: EnterFrame
    //     0x898b6c: stp             fp, lr, [SP, #-0x10]!
    //     0x898b70: mov             fp, SP
    // 0x898b74: AllocStack(0x8)
    //     0x898b74: sub             SP, SP, #8
    // 0x898b78: SetupParameters(ViewConfiguration this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0x898b78: mov             x0, x1
    //     0x898b7c: mov             x1, x2
    // 0x898b80: CheckStackOverflow
    //     0x898b80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898b84: cmp             SP, x16
    //     0x898b88: b.ls            #0x898bb8
    // 0x898b8c: LoadField: r2 = r0->field_b
    //     0x898b8c: ldur            w2, [x0, #0xb]
    // 0x898b90: DecompressPointer r2
    //     0x898b90: add             x2, x2, HEAP, lsl #32
    // 0x898b94: stur            x2, [fp, #-8]
    // 0x898b98: LoadField: d0 = r0->field_f
    //     0x898b98: ldur            d0, [x0, #0xf]
    // 0x898b9c: r0 = *()
    //     0x898b9c: bl              #0x81d1f4  ; [dart:ui] Size::*
    // 0x898ba0: ldur            x1, [fp, #-8]
    // 0x898ba4: mov             x2, x0
    // 0x898ba8: r0 = constrain()
    //     0x898ba8: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x898bac: LeaveFrame
    //     0x898bac: mov             SP, fp
    //     0x898bb0: ldp             fp, lr, [SP], #0x10
    // 0x898bb4: ret
    //     0x898bb4: ret             
    // 0x898bb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898bb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898bbc: b               #0x898b8c
  }
  _ toMatrix(/* No info */) {
    // ** addr: 0x89d130, size: 0x38
    // 0x89d130: EnterFrame
    //     0x89d130: stp             fp, lr, [SP, #-0x10]!
    //     0x89d134: mov             fp, SP
    // 0x89d138: CheckStackOverflow
    //     0x89d138: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89d13c: cmp             SP, x16
    //     0x89d140: b.ls            #0x89d160
    // 0x89d144: LoadField: d1 = r1->field_f
    //     0x89d144: ldur            d1, [x1, #0xf]
    // 0x89d148: mov             v0.16b, v1.16b
    // 0x89d14c: r1 = Null
    //     0x89d14c: mov             x1, NULL
    // 0x89d150: r0 = Matrix4.diagonal3Values()
    //     0x89d150: bl              #0x89d168  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.diagonal3Values
    // 0x89d154: LeaveFrame
    //     0x89d154: mov             SP, fp
    //     0x89d158: ldp             fp, lr, [SP], #0x10
    // 0x89d15c: ret
    //     0x89d15c: ret             
    // 0x89d160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89d160: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89d164: b               #0x89d144
  }
  factory _ ViewConfiguration.fromView(/* No info */) {
    // ** addr: 0x89d1c0, size: 0x16c
    // 0x89d1c0: EnterFrame
    //     0x89d1c0: stp             fp, lr, [SP, #-0x10]!
    //     0x89d1c4: mov             fp, SP
    // 0x89d1c8: AllocStack(0x20)
    //     0x89d1c8: sub             SP, SP, #0x20
    // 0x89d1cc: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x89d1cc: mov             x0, x2
    //     0x89d1d0: stur            x2, [fp, #-8]
    // 0x89d1d4: CheckStackOverflow
    //     0x89d1d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89d1d8: cmp             SP, x16
    //     0x89d1dc: b.ls            #0x89d324
    // 0x89d1e0: mov             x1, x0
    // 0x89d1e4: r0 = physicalConstraints()
    //     0x89d1e4: bl              #0x89d3b0  ; [dart:ui] FlutterView::physicalConstraints
    // 0x89d1e8: stur            x0, [fp, #-0x10]
    // 0x89d1ec: LoadField: d0 = r0->field_7
    //     0x89d1ec: ldur            d0, [x0, #7]
    // 0x89d1f0: stur            d0, [fp, #-0x20]
    // 0x89d1f4: r0 = BoxConstraints()
    //     0x89d1f4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x89d1f8: mov             x3, x0
    // 0x89d1fc: ldur            d0, [fp, #-0x20]
    // 0x89d200: stur            x3, [fp, #-0x18]
    // 0x89d204: StoreField: r3->field_7 = d0
    //     0x89d204: stur            d0, [x3, #7]
    // 0x89d208: ldur            x0, [fp, #-0x10]
    // 0x89d20c: LoadField: d0 = r0->field_f
    //     0x89d20c: ldur            d0, [x0, #0xf]
    // 0x89d210: StoreField: r3->field_f = d0
    //     0x89d210: stur            d0, [x3, #0xf]
    // 0x89d214: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x89d214: ldur            d0, [x0, #0x17]
    // 0x89d218: ArrayStore: r3[0] = d0  ; List_8
    //     0x89d218: stur            d0, [x3, #0x17]
    // 0x89d21c: LoadField: d0 = r0->field_1f
    //     0x89d21c: ldur            d0, [x0, #0x1f]
    // 0x89d220: StoreField: r3->field_1f = d0
    //     0x89d220: stur            d0, [x3, #0x1f]
    // 0x89d224: ldur            x4, [fp, #-8]
    // 0x89d228: r0 = LoadClassIdInstr(r4)
    //     0x89d228: ldur            x0, [x4, #-1]
    //     0x89d22c: ubfx            x0, x0, #0xc, #0x14
    // 0x89d230: cmp             x0, #0xe86
    // 0x89d234: b.ne            #0x89d24c
    // 0x89d238: LoadField: r0 = r4->field_13
    //     0x89d238: ldur            w0, [x4, #0x13]
    // 0x89d23c: DecompressPointer r0
    //     0x89d23c: add             x0, x0, HEAP, lsl #32
    // 0x89d240: mov             x1, x0
    // 0x89d244: mov             x0, x3
    // 0x89d248: b               #0x89d2e4
    // 0x89d24c: LoadField: r0 = r4->field_f
    //     0x89d24c: ldur            w0, [x4, #0xf]
    // 0x89d250: DecompressPointer r0
    //     0x89d250: add             x0, x0, HEAP, lsl #32
    // 0x89d254: ArrayLoad: r5 = r0[0]  ; List_4
    //     0x89d254: ldur            w5, [x0, #0x17]
    // 0x89d258: DecompressPointer r5
    //     0x89d258: add             x5, x5, HEAP, lsl #32
    // 0x89d25c: stur            x5, [fp, #-0x10]
    // 0x89d260: LoadField: r2 = r4->field_7
    //     0x89d260: ldur            x2, [x4, #7]
    // 0x89d264: r0 = BoxInt64Instr(r2)
    //     0x89d264: sbfiz           x0, x2, #1, #0x1f
    //     0x89d268: cmp             x2, x0, asr #1
    //     0x89d26c: b.eq            #0x89d278
    //     0x89d270: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x89d274: stur            x2, [x0, #7]
    // 0x89d278: mov             x1, x5
    // 0x89d27c: mov             x2, x0
    // 0x89d280: r0 = _getValueOrData()
    //     0x89d280: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x89d284: mov             x1, x0
    // 0x89d288: ldur            x0, [fp, #-0x10]
    // 0x89d28c: LoadField: r2 = r0->field_f
    //     0x89d28c: ldur            w2, [x0, #0xf]
    // 0x89d290: DecompressPointer r2
    //     0x89d290: add             x2, x2, HEAP, lsl #32
    // 0x89d294: cmp             w2, w1
    // 0x89d298: b.ne            #0x89d2a0
    // 0x89d29c: r1 = Null
    //     0x89d29c: mov             x1, NULL
    // 0x89d2a0: cmp             w1, NULL
    // 0x89d2a4: b.ne            #0x89d2b0
    // 0x89d2a8: r0 = Null
    //     0x89d2a8: mov             x0, NULL
    // 0x89d2ac: b               #0x89d2c4
    // 0x89d2b0: r0 = LoadClassIdInstr(r1)
    //     0x89d2b0: ldur            x0, [x1, #-1]
    //     0x89d2b4: ubfx            x0, x0, #0xc, #0x14
    // 0x89d2b8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x89d2b8: sub             lr, x0, #1, lsl #12
    //     0x89d2bc: ldr             lr, [x21, lr, lsl #3]
    //     0x89d2c0: blr             lr
    // 0x89d2c4: cmp             w0, NULL
    // 0x89d2c8: b.ne            #0x89d2dc
    // 0x89d2cc: ldur            x0, [fp, #-8]
    // 0x89d2d0: LoadField: r1 = r0->field_13
    //     0x89d2d0: ldur            w1, [x0, #0x13]
    // 0x89d2d4: DecompressPointer r1
    //     0x89d2d4: add             x1, x1, HEAP, lsl #32
    // 0x89d2d8: mov             x0, x1
    // 0x89d2dc: mov             x1, x0
    // 0x89d2e0: ldur            x0, [fp, #-0x18]
    // 0x89d2e4: LoadField: d1 = r1->field_13
    //     0x89d2e4: ldur            d1, [x1, #0x13]
    // 0x89d2e8: mov             x1, x0
    // 0x89d2ec: mov             v0.16b, v1.16b
    // 0x89d2f0: stur            d1, [fp, #-0x20]
    // 0x89d2f4: r0 = /()
    //     0x89d2f4: bl              #0x89d338  ; [package:flutter/src/rendering/box.dart] BoxConstraints::/
    // 0x89d2f8: stur            x0, [fp, #-8]
    // 0x89d2fc: r0 = ViewConfiguration()
    //     0x89d2fc: bl              #0x89d32c  ; AllocateViewConfigurationStub -> ViewConfiguration (size=0x18)
    // 0x89d300: ldur            x1, [fp, #-0x18]
    // 0x89d304: StoreField: r0->field_b = r1
    //     0x89d304: stur            w1, [x0, #0xb]
    // 0x89d308: ldur            x1, [fp, #-8]
    // 0x89d30c: StoreField: r0->field_7 = r1
    //     0x89d30c: stur            w1, [x0, #7]
    // 0x89d310: ldur            d0, [fp, #-0x20]
    // 0x89d314: StoreField: r0->field_f = d0
    //     0x89d314: stur            d0, [x0, #0xf]
    // 0x89d318: LeaveFrame
    //     0x89d318: mov             SP, fp
    //     0x89d31c: ldp             fp, lr, [SP], #0x10
    // 0x89d320: ret
    //     0x89d320: ret             
    // 0x89d324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89d324: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89d328: b               #0x89d1e0
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114cb50, size: 0xac
    // 0x114cb50: EnterFrame
    //     0x114cb50: stp             fp, lr, [SP, #-0x10]!
    //     0x114cb54: mov             fp, SP
    // 0x114cb58: AllocStack(0x8)
    //     0x114cb58: sub             SP, SP, #8
    // 0x114cb5c: CheckStackOverflow
    //     0x114cb5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114cb60: cmp             SP, x16
    //     0x114cb64: b.ls            #0x114cbdc
    // 0x114cb68: ldr             x0, [fp, #0x10]
    // 0x114cb6c: LoadField: r1 = r0->field_7
    //     0x114cb6c: ldur            w1, [x0, #7]
    // 0x114cb70: DecompressPointer r1
    //     0x114cb70: add             x1, x1, HEAP, lsl #32
    // 0x114cb74: LoadField: r2 = r0->field_b
    //     0x114cb74: ldur            w2, [x0, #0xb]
    // 0x114cb78: DecompressPointer r2
    //     0x114cb78: add             x2, x2, HEAP, lsl #32
    // 0x114cb7c: LoadField: d0 = r0->field_f
    //     0x114cb7c: ldur            d0, [x0, #0xf]
    // 0x114cb80: r0 = inline_Allocate_Double()
    //     0x114cb80: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x114cb84: add             x0, x0, #0x10
    //     0x114cb88: cmp             x3, x0
    //     0x114cb8c: b.ls            #0x114cbe4
    //     0x114cb90: str             x0, [THR, #0x60]  ; THR::top
    //     0x114cb94: sub             x0, x0, #0xf
    //     0x114cb98: mov             x3, #0xe19c
    //     0x114cb9c: movk            x3, #3, lsl #16
    //     0x114cba0: stur            x3, [x0, #-1]
    // 0x114cba4: dmb             ishst
    // 0x114cba8: StoreField: r0->field_7 = d0
    //     0x114cba8: stur            d0, [x0, #7]
    // 0x114cbac: str             x0, [SP]
    // 0x114cbb0: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0x114cbb0: ldr             x4, [PP, #0xca8]  ; [pp+0xca8] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0x114cbb4: r0 = hash()
    //     0x114cbb4: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114cbb8: mov             x2, x0
    // 0x114cbbc: r0 = BoxInt64Instr(r2)
    //     0x114cbbc: sbfiz           x0, x2, #1, #0x1f
    //     0x114cbc0: cmp             x2, x0, asr #1
    //     0x114cbc4: b.eq            #0x114cbd0
    //     0x114cbc8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114cbcc: stur            x2, [x0, #7]
    // 0x114cbd0: LeaveFrame
    //     0x114cbd0: mov             SP, fp
    //     0x114cbd4: ldp             fp, lr, [SP], #0x10
    // 0x114cbd8: ret
    //     0x114cbd8: ret             
    // 0x114cbdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114cbdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114cbe0: b               #0x114cb68
    // 0x114cbe4: SaveReg d0
    //     0x114cbe4: str             q0, [SP, #-0x10]!
    // 0x114cbe8: stp             x1, x2, [SP, #-0x10]!
    // 0x114cbec: r0 = AllocateDouble()
    //     0x114cbec: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114cbf0: ldp             x1, x2, [SP], #0x10
    // 0x114cbf4: RestoreReg d0
    //     0x114cbf4: ldr             q0, [SP], #0x10
    // 0x114cbf8: b               #0x114cba8
  }
  _ ==(/* No info */) {
    // ** addr: 0x129a43c, size: 0x1dc
    // 0x129a43c: EnterFrame
    //     0x129a43c: stp             fp, lr, [SP, #-0x10]!
    //     0x129a440: mov             fp, SP
    // 0x129a444: AllocStack(0x20)
    //     0x129a444: sub             SP, SP, #0x20
    // 0x129a448: CheckStackOverflow
    //     0x129a448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129a44c: cmp             SP, x16
    //     0x129a450: b.ls            #0x129a610
    // 0x129a454: ldr             x0, [fp, #0x10]
    // 0x129a458: cmp             w0, NULL
    // 0x129a45c: b.ne            #0x129a470
    // 0x129a460: r0 = false
    //     0x129a460: add             x0, NULL, #0x30  ; false
    // 0x129a464: LeaveFrame
    //     0x129a464: mov             SP, fp
    //     0x129a468: ldp             fp, lr, [SP], #0x10
    // 0x129a46c: ret
    //     0x129a46c: ret             
    // 0x129a470: str             x0, [SP]
    // 0x129a474: r0 = runtimeType()
    //     0x129a474: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129a478: r1 = LoadClassIdInstr(r0)
    //     0x129a478: ldur            x1, [x0, #-1]
    //     0x129a47c: ubfx            x1, x1, #0xc, #0x14
    // 0x129a480: r16 = ViewConfiguration
    //     0x129a480: ldr             x16, [PP, #0x2ea8]  ; [pp+0x2ea8] Type: ViewConfiguration
    // 0x129a484: stp             x16, x0, [SP]
    // 0x129a488: mov             x0, x1
    // 0x129a48c: mov             lr, x0
    // 0x129a490: ldr             lr, [x21, lr, lsl #3]
    // 0x129a494: blr             lr
    // 0x129a498: tbz             w0, #4, #0x129a4ac
    // 0x129a49c: r0 = false
    //     0x129a49c: add             x0, NULL, #0x30  ; false
    // 0x129a4a0: LeaveFrame
    //     0x129a4a0: mov             SP, fp
    //     0x129a4a4: ldp             fp, lr, [SP], #0x10
    // 0x129a4a8: ret
    //     0x129a4a8: ret             
    // 0x129a4ac: ldr             x0, [fp, #0x10]
    // 0x129a4b0: r1 = 60
    //     0x129a4b0: mov             x1, #0x3c
    // 0x129a4b4: branchIfSmi(r0, 0x129a4c0)
    //     0x129a4b4: tbz             w0, #0, #0x129a4c0
    // 0x129a4b8: r1 = LoadClassIdInstr(r0)
    //     0x129a4b8: ldur            x1, [x0, #-1]
    //     0x129a4bc: ubfx            x1, x1, #0xc, #0x14
    // 0x129a4c0: cmp             x1, #0xb1b
    // 0x129a4c4: b.ne            #0x129a600
    // 0x129a4c8: ldr             x1, [fp, #0x18]
    // 0x129a4cc: LoadField: r2 = r0->field_7
    //     0x129a4cc: ldur            w2, [x0, #7]
    // 0x129a4d0: DecompressPointer r2
    //     0x129a4d0: add             x2, x2, HEAP, lsl #32
    // 0x129a4d4: stur            x2, [fp, #-0x10]
    // 0x129a4d8: LoadField: r3 = r1->field_7
    //     0x129a4d8: ldur            w3, [x1, #7]
    // 0x129a4dc: DecompressPointer r3
    //     0x129a4dc: add             x3, x3, HEAP, lsl #32
    // 0x129a4e0: stur            x3, [fp, #-8]
    // 0x129a4e4: cmp             w2, w3
    // 0x129a4e8: b.eq            #0x129a550
    // 0x129a4ec: r16 = BoxConstraints
    //     0x129a4ec: ldr             x16, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0x129a4f0: r30 = BoxConstraints
    //     0x129a4f0: ldr             lr, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0x129a4f4: stp             lr, x16, [SP]
    // 0x129a4f8: r0 = ==()
    //     0x129a4f8: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x129a4fc: tbnz            w0, #4, #0x129a600
    // 0x129a500: ldur            x0, [fp, #-0x10]
    // 0x129a504: ldur            x1, [fp, #-8]
    // 0x129a508: LoadField: d0 = r1->field_7
    //     0x129a508: ldur            d0, [x1, #7]
    // 0x129a50c: LoadField: d1 = r0->field_7
    //     0x129a50c: ldur            d1, [x0, #7]
    // 0x129a510: fcmp            d0, d1
    // 0x129a514: b.ne            #0x129a600
    // 0x129a518: LoadField: d0 = r1->field_f
    //     0x129a518: ldur            d0, [x1, #0xf]
    // 0x129a51c: LoadField: d1 = r0->field_f
    //     0x129a51c: ldur            d1, [x0, #0xf]
    // 0x129a520: fcmp            d0, d1
    // 0x129a524: b.ne            #0x129a600
    // 0x129a528: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x129a528: ldur            d0, [x1, #0x17]
    // 0x129a52c: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x129a52c: ldur            d1, [x0, #0x17]
    // 0x129a530: fcmp            d0, d1
    // 0x129a534: b.ne            #0x129a600
    // 0x129a538: LoadField: d0 = r1->field_1f
    //     0x129a538: ldur            d0, [x1, #0x1f]
    // 0x129a53c: LoadField: d1 = r0->field_1f
    //     0x129a53c: ldur            d1, [x0, #0x1f]
    // 0x129a540: fcmp            d0, d1
    // 0x129a544: b.ne            #0x129a600
    // 0x129a548: ldr             x1, [fp, #0x18]
    // 0x129a54c: ldr             x0, [fp, #0x10]
    // 0x129a550: LoadField: r2 = r0->field_b
    //     0x129a550: ldur            w2, [x0, #0xb]
    // 0x129a554: DecompressPointer r2
    //     0x129a554: add             x2, x2, HEAP, lsl #32
    // 0x129a558: stur            x2, [fp, #-0x10]
    // 0x129a55c: LoadField: r3 = r1->field_b
    //     0x129a55c: ldur            w3, [x1, #0xb]
    // 0x129a560: DecompressPointer r3
    //     0x129a560: add             x3, x3, HEAP, lsl #32
    // 0x129a564: stur            x3, [fp, #-8]
    // 0x129a568: cmp             w2, w3
    // 0x129a56c: b.ne            #0x129a57c
    // 0x129a570: mov             x2, x1
    // 0x129a574: mov             x1, x0
    // 0x129a578: b               #0x129a5e0
    // 0x129a57c: r16 = BoxConstraints
    //     0x129a57c: ldr             x16, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0x129a580: r30 = BoxConstraints
    //     0x129a580: ldr             lr, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0x129a584: stp             lr, x16, [SP]
    // 0x129a588: r0 = ==()
    //     0x129a588: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x129a58c: tbnz            w0, #4, #0x129a600
    // 0x129a590: ldur            x1, [fp, #-0x10]
    // 0x129a594: ldur            x2, [fp, #-8]
    // 0x129a598: LoadField: d0 = r2->field_7
    //     0x129a598: ldur            d0, [x2, #7]
    // 0x129a59c: LoadField: d1 = r1->field_7
    //     0x129a59c: ldur            d1, [x1, #7]
    // 0x129a5a0: fcmp            d0, d1
    // 0x129a5a4: b.ne            #0x129a600
    // 0x129a5a8: LoadField: d0 = r2->field_f
    //     0x129a5a8: ldur            d0, [x2, #0xf]
    // 0x129a5ac: LoadField: d1 = r1->field_f
    //     0x129a5ac: ldur            d1, [x1, #0xf]
    // 0x129a5b0: fcmp            d0, d1
    // 0x129a5b4: b.ne            #0x129a600
    // 0x129a5b8: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x129a5b8: ldur            d0, [x2, #0x17]
    // 0x129a5bc: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x129a5bc: ldur            d1, [x1, #0x17]
    // 0x129a5c0: fcmp            d0, d1
    // 0x129a5c4: b.ne            #0x129a600
    // 0x129a5c8: LoadField: d0 = r2->field_1f
    //     0x129a5c8: ldur            d0, [x2, #0x1f]
    // 0x129a5cc: LoadField: d1 = r1->field_1f
    //     0x129a5cc: ldur            d1, [x1, #0x1f]
    // 0x129a5d0: fcmp            d0, d1
    // 0x129a5d4: b.ne            #0x129a600
    // 0x129a5d8: ldr             x2, [fp, #0x18]
    // 0x129a5dc: ldr             x1, [fp, #0x10]
    // 0x129a5e0: LoadField: d0 = r1->field_f
    //     0x129a5e0: ldur            d0, [x1, #0xf]
    // 0x129a5e4: LoadField: d1 = r2->field_f
    //     0x129a5e4: ldur            d1, [x2, #0xf]
    // 0x129a5e8: fcmp            d0, d1
    // 0x129a5ec: r16 = true
    //     0x129a5ec: add             x16, NULL, #0x20  ; true
    // 0x129a5f0: r17 = false
    //     0x129a5f0: add             x17, NULL, #0x30  ; false
    // 0x129a5f4: csel            x1, x16, x17, eq
    // 0x129a5f8: mov             x0, x1
    // 0x129a5fc: b               #0x129a604
    // 0x129a600: r0 = false
    //     0x129a600: add             x0, NULL, #0x30  ; false
    // 0x129a604: LeaveFrame
    //     0x129a604: mov             SP, fp
    //     0x129a608: ldp             fp, lr, [SP], #0x10
    // 0x129a60c: ret
    //     0x129a60c: ret             
    // 0x129a610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129a610: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129a614: b               #0x129a454
  }
}

// class id: 4679, size: 0x60, field offset: 0x4c
class RenderView extends _MixinApplication423&RenderObject&RenderObjectWithChildMixin {

  _ hitTest(/* No info */) {
    // ** addr: 0x836a60, size: 0xf0
    // 0x836a60: EnterFrame
    //     0x836a60: stp             fp, lr, [SP, #-0x10]!
    //     0x836a64: mov             fp, SP
    // 0x836a68: AllocStack(0x28)
    //     0x836a68: sub             SP, SP, #0x28
    // 0x836a6c: SetupParameters(RenderView this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0x836a6c: mov             x0, x1
    //     0x836a70: stur            x1, [fp, #-0x18]
    //     0x836a74: mov             x1, x2
    //     0x836a78: stur            x2, [fp, #-0x20]
    //     0x836a7c: stur            x3, [fp, #-0x28]
    // 0x836a80: CheckStackOverflow
    //     0x836a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x836a84: cmp             SP, x16
    //     0x836a88: b.ls            #0x836b48
    // 0x836a8c: LoadField: r2 = r0->field_47
    //     0x836a8c: ldur            w2, [x0, #0x47]
    // 0x836a90: DecompressPointer r2
    //     0x836a90: add             x2, x2, HEAP, lsl #32
    // 0x836a94: stur            x2, [fp, #-0x10]
    // 0x836a98: cmp             w2, NULL
    // 0x836a9c: b.eq            #0x836b18
    // 0x836aa0: LoadField: r4 = r1->field_7
    //     0x836aa0: ldur            w4, [x1, #7]
    // 0x836aa4: DecompressPointer r4
    //     0x836aa4: add             x4, x4, HEAP, lsl #32
    // 0x836aa8: stur            x4, [fp, #-8]
    // 0x836aac: r0 = BoxHitTestResult()
    //     0x836aac: bl              #0x836ba0  ; AllocateBoxHitTestResultStub -> BoxHitTestResult (size=0x14)
    // 0x836ab0: mov             x1, x0
    // 0x836ab4: ldur            x0, [fp, #-8]
    // 0x836ab8: StoreField: r1->field_7 = r0
    //     0x836ab8: stur            w0, [x1, #7]
    // 0x836abc: ldur            x4, [fp, #-0x20]
    // 0x836ac0: LoadField: r0 = r4->field_b
    //     0x836ac0: ldur            w0, [x4, #0xb]
    // 0x836ac4: DecompressPointer r0
    //     0x836ac4: add             x0, x0, HEAP, lsl #32
    // 0x836ac8: StoreField: r1->field_b = r0
    //     0x836ac8: stur            w0, [x1, #0xb]
    // 0x836acc: LoadField: r0 = r4->field_f
    //     0x836acc: ldur            w0, [x4, #0xf]
    // 0x836ad0: DecompressPointer r0
    //     0x836ad0: add             x0, x0, HEAP, lsl #32
    // 0x836ad4: StoreField: r1->field_f = r0
    //     0x836ad4: stur            w0, [x1, #0xf]
    // 0x836ad8: ldur            x0, [fp, #-0x10]
    // 0x836adc: r2 = LoadClassIdInstr(r0)
    //     0x836adc: ldur            x2, [x0, #-1]
    //     0x836ae0: ubfx            x2, x2, #0xc, #0x14
    // 0x836ae4: mov             x16, x1
    // 0x836ae8: mov             x1, x2
    // 0x836aec: mov             x2, x16
    // 0x836af0: mov             x16, x0
    // 0x836af4: mov             x0, x1
    // 0x836af8: mov             x1, x16
    // 0x836afc: ldur            x3, [fp, #-0x28]
    // 0x836b00: r0 = GDT[cid_x0 + 0x13d77]()
    //     0x836b00: mov             x17, #0x3d77
    //     0x836b04: movk            x17, #1, lsl #16
    //     0x836b08: add             lr, x0, x17
    //     0x836b0c: ldr             lr, [x21, lr, lsl #3]
    //     0x836b10: blr             lr
    // 0x836b14: ldur            x0, [fp, #-0x18]
    // 0x836b18: r1 = <HitTestTarget>
    //     0x836b18: ldr             x1, [PP, #0x2ef0]  ; [pp+0x2ef0] TypeArguments: <HitTestTarget>
    // 0x836b1c: r0 = HitTestEntry()
    //     0x836b1c: bl              #0x836a54  ; AllocateHitTestEntryStub -> HitTestEntry<X0 bound HitTestTarget> (size=0x14)
    // 0x836b20: mov             x1, x0
    // 0x836b24: ldur            x0, [fp, #-0x18]
    // 0x836b28: StoreField: r1->field_b = r0
    //     0x836b28: stur            w0, [x1, #0xb]
    // 0x836b2c: mov             x2, x1
    // 0x836b30: ldur            x1, [fp, #-0x20]
    // 0x836b34: r0 = add()
    //     0x836b34: bl              #0x836754  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x836b38: r0 = true
    //     0x836b38: add             x0, NULL, #0x20  ; true
    // 0x836b3c: LeaveFrame
    //     0x836b3c: mov             SP, fp
    //     0x836b40: ldp             fp, lr, [SP], #0x10
    // 0x836b44: ret
    //     0x836b44: ret             
    // 0x836b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836b48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836b4c: b               #0x836a8c
  }
  _ compositeFrame(/* No info */) {
    // ** addr: 0x898844, size: 0x104
    // 0x898844: EnterFrame
    //     0x898844: stp             fp, lr, [SP, #-0x10]!
    //     0x898848: mov             fp, SP
    // 0x89884c: AllocStack(0x28)
    //     0x89884c: sub             SP, SP, #0x28
    // 0x898850: SetupParameters(RenderView this /* r1 => r1, fp-0x8 */)
    //     0x898850: stur            x1, [fp, #-8]
    // 0x898854: CheckStackOverflow
    //     0x898854: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898858: cmp             SP, x16
    //     0x89885c: b.ls            #0x898934
    // 0x898860: r0 = instance()
    //     0x898860: bl              #0x899f04  ; [package:flutter/src/rendering/binding.dart] RendererBinding::instance
    // 0x898864: mov             x1, x0
    // 0x898868: r0 = createSceneBuilder()
    //     0x898868: bl              #0x899c60  ; [dart:mixin_deduplication] _MixinApplication207&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding::createSceneBuilder
    // 0x89886c: ldur            x1, [fp, #-8]
    // 0x898870: stur            x0, [fp, #-0x10]
    // 0x898874: r0 = layer()
    //     0x898874: bl              #0x899c4c  ; [package:flutter/src/rendering/object.dart] RenderObject::layer
    // 0x898878: cmp             w0, NULL
    // 0x89887c: b.eq            #0x89893c
    // 0x898880: mov             x1, x0
    // 0x898884: ldur            x2, [fp, #-0x10]
    // 0x898888: r0 = buildScene()
    //     0x898888: bl              #0x899940  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::buildScene
    // 0x89888c: ldur            x1, [fp, #-8]
    // 0x898890: stur            x0, [fp, #-0x10]
    // 0x898894: r0 = _updateSystemChrome()
    //     0x898894: bl              #0x898dac  ; [package:flutter/src/rendering/view.dart] RenderView::_updateSystemChrome
    // 0x898898: ldur            x0, [fp, #-8]
    // 0x89889c: LoadField: r3 = r0->field_53
    //     0x89889c: ldur            w3, [x0, #0x53]
    // 0x8988a0: DecompressPointer r3
    //     0x8988a0: add             x3, x3, HEAP, lsl #32
    // 0x8988a4: stur            x3, [fp, #-0x18]
    // 0x8988a8: LoadField: r1 = r0->field_4f
    //     0x8988a8: ldur            w1, [x0, #0x4f]
    // 0x8988ac: DecompressPointer r1
    //     0x8988ac: add             x1, x1, HEAP, lsl #32
    // 0x8988b0: cmp             w1, NULL
    // 0x8988b4: b.eq            #0x898940
    // 0x8988b8: LoadField: r2 = r0->field_4b
    //     0x8988b8: ldur            w2, [x0, #0x4b]
    // 0x8988bc: DecompressPointer r2
    //     0x8988bc: add             x2, x2, HEAP, lsl #32
    // 0x8988c0: r0 = toPhysicalSize()
    //     0x8988c0: bl              #0x898b6c  ; [package:flutter/src/rendering/view.dart] ViewConfiguration::toPhysicalSize
    // 0x8988c4: ldur            x1, [fp, #-0x18]
    // 0x8988c8: ldur            x2, [fp, #-0x10]
    // 0x8988cc: mov             x3, x0
    // 0x8988d0: r0 = render()
    //     0x8988d0: bl              #0x898a00  ; [dart:ui] FlutterView::render
    // 0x8988d4: ldur            x0, [fp, #-0x10]
    // 0x8988d8: LoadField: r1 = r0->field_7
    //     0x8988d8: ldur            w1, [x0, #7]
    // 0x8988dc: DecompressPointer r1
    //     0x8988dc: add             x1, x1, HEAP, lsl #32
    // 0x8988e0: cmp             w1, NULL
    // 0x8988e4: b.eq            #0x898944
    // 0x8988e8: LoadField: r2 = r1->field_7
    //     0x8988e8: ldur            x2, [x1, #7]
    // 0x8988ec: ldr             x1, [x2]
    // 0x8988f0: cbz             x1, #0x898924
    // 0x8988f4: mov             x2, x1
    // 0x8988f8: stur            x2, [fp, #-0x20]
    // 0x8988fc: r1 = <Never>
    //     0x8988fc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x898900: r0 = Pointer()
    //     0x898900: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x898904: mov             x1, x0
    // 0x898908: ldur            x0, [fp, #-0x20]
    // 0x89890c: StoreField: r1->field_7 = r0
    //     0x89890c: stur            x0, [x1, #7]
    // 0x898910: r0 = _dispose$Method$FfiNative()
    //     0x898910: bl              #0x898948  ; [dart:ui] _NativeScene::_dispose$Method$FfiNative
    // 0x898914: r0 = Null
    //     0x898914: mov             x0, NULL
    // 0x898918: LeaveFrame
    //     0x898918: mov             SP, fp
    //     0x89891c: ldp             fp, lr, [SP], #0x10
    // 0x898920: ret
    //     0x898920: ret             
    // 0x898924: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x898924: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x898928: str             x16, [SP]
    // 0x89892c: r0 = _throwNew()
    //     0x89892c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x898930: brk             #0
    // 0x898934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898934: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898938: b               #0x898860
    // 0x89893c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89893c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x898940: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x898940: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x898944: r0 = NullErrorSharedWithoutFPURegs()
    //     0x898944: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _updateSystemChrome(/* No info */) {
    // ** addr: 0x898dac, size: 0x438
    // 0x898dac: EnterFrame
    //     0x898dac: stp             fp, lr, [SP, #-0x10]!
    //     0x898db0: mov             fp, SP
    // 0x898db4: AllocStack(0x68)
    //     0x898db4: sub             SP, SP, #0x68
    // 0x898db8: SetupParameters(RenderView this /* r1 => r0, fp-0x8 */)
    //     0x898db8: mov             x0, x1
    //     0x898dbc: stur            x1, [fp, #-8]
    // 0x898dc0: CheckStackOverflow
    //     0x898dc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898dc4: cmp             SP, x16
    //     0x898dc8: b.ls            #0x8991d0
    // 0x898dcc: mov             x1, x0
    // 0x898dd0: r0 = paintBounds()
    //     0x898dd0: bl              #0xbf0584  ; [package:flutter/src/rendering/view.dart] RenderView::paintBounds
    // 0x898dd4: mov             x1, x0
    // 0x898dd8: stur            x0, [fp, #-0x10]
    // 0x898ddc: r0 = center()
    //     0x898ddc: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x898de0: LoadField: d0 = r0->field_7
    //     0x898de0: ldur            d0, [x0, #7]
    // 0x898de4: ldur            x3, [fp, #-8]
    // 0x898de8: stur            d0, [fp, #-0x40]
    // 0x898dec: LoadField: r4 = r3->field_53
    //     0x898dec: ldur            w4, [x3, #0x53]
    // 0x898df0: DecompressPointer r4
    //     0x898df0: add             x4, x4, HEAP, lsl #32
    // 0x898df4: stur            x4, [fp, #-0x28]
    // 0x898df8: r5 = LoadClassIdInstr(r4)
    //     0x898df8: ldur            x5, [x4, #-1]
    //     0x898dfc: ubfx            x5, x5, #0xc, #0x14
    // 0x898e00: stur            x5, [fp, #-0x20]
    // 0x898e04: cmp             x5, #0xe86
    // 0x898e08: b.ne            #0x898e24
    // 0x898e0c: LoadField: r0 = r4->field_13
    //     0x898e0c: ldur            w0, [x4, #0x13]
    // 0x898e10: DecompressPointer r0
    //     0x898e10: add             x0, x0, HEAP, lsl #32
    // 0x898e14: mov             x3, x0
    // 0x898e18: mov             x1, x4
    // 0x898e1c: mov             x0, x5
    // 0x898e20: b               #0x898ec4
    // 0x898e24: LoadField: r0 = r4->field_f
    //     0x898e24: ldur            w0, [x4, #0xf]
    // 0x898e28: DecompressPointer r0
    //     0x898e28: add             x0, x0, HEAP, lsl #32
    // 0x898e2c: ArrayLoad: r6 = r0[0]  ; List_4
    //     0x898e2c: ldur            w6, [x0, #0x17]
    // 0x898e30: DecompressPointer r6
    //     0x898e30: add             x6, x6, HEAP, lsl #32
    // 0x898e34: stur            x6, [fp, #-0x18]
    // 0x898e38: LoadField: r2 = r4->field_7
    //     0x898e38: ldur            x2, [x4, #7]
    // 0x898e3c: r0 = BoxInt64Instr(r2)
    //     0x898e3c: sbfiz           x0, x2, #1, #0x1f
    //     0x898e40: cmp             x2, x0, asr #1
    //     0x898e44: b.eq            #0x898e50
    //     0x898e48: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0x898e4c: stur            x2, [x0, #7]
    // 0x898e50: mov             x1, x6
    // 0x898e54: mov             x2, x0
    // 0x898e58: r0 = _getValueOrData()
    //     0x898e58: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x898e5c: mov             x1, x0
    // 0x898e60: ldur            x0, [fp, #-0x18]
    // 0x898e64: LoadField: r2 = r0->field_f
    //     0x898e64: ldur            w2, [x0, #0xf]
    // 0x898e68: DecompressPointer r2
    //     0x898e68: add             x2, x2, HEAP, lsl #32
    // 0x898e6c: cmp             w2, w1
    // 0x898e70: b.ne            #0x898e78
    // 0x898e74: r1 = Null
    //     0x898e74: mov             x1, NULL
    // 0x898e78: cmp             w1, NULL
    // 0x898e7c: b.ne            #0x898e88
    // 0x898e80: r0 = Null
    //     0x898e80: mov             x0, NULL
    // 0x898e84: b               #0x898e9c
    // 0x898e88: r0 = LoadClassIdInstr(r1)
    //     0x898e88: ldur            x0, [x1, #-1]
    //     0x898e8c: ubfx            x0, x0, #0xc, #0x14
    // 0x898e90: r0 = GDT[cid_x0 + -0x1000]()
    //     0x898e90: sub             lr, x0, #1, lsl #12
    //     0x898e94: ldr             lr, [x21, lr, lsl #3]
    //     0x898e98: blr             lr
    // 0x898e9c: cmp             w0, NULL
    // 0x898ea0: b.ne            #0x898eb4
    // 0x898ea4: ldur            x1, [fp, #-0x28]
    // 0x898ea8: LoadField: r0 = r1->field_13
    //     0x898ea8: ldur            w0, [x1, #0x13]
    // 0x898eac: DecompressPointer r0
    //     0x898eac: add             x0, x0, HEAP, lsl #32
    // 0x898eb0: b               #0x898eb8
    // 0x898eb4: ldur            x1, [fp, #-0x28]
    // 0x898eb8: mov             x3, x0
    // 0x898ebc: ldur            d0, [fp, #-0x40]
    // 0x898ec0: ldur            x0, [fp, #-0x20]
    // 0x898ec4: ldur            x2, [fp, #-0x10]
    // 0x898ec8: d1 = 2.000000
    //     0x898ec8: fmov            d1, #2.00000000
    // 0x898ecc: LoadField: r4 = r3->field_2b
    //     0x898ecc: ldur            w4, [x3, #0x2b]
    // 0x898ed0: DecompressPointer r4
    //     0x898ed0: add             x4, x4, HEAP, lsl #32
    // 0x898ed4: LoadField: d2 = r4->field_f
    //     0x898ed4: ldur            d2, [x4, #0xf]
    // 0x898ed8: fdiv            d3, d2, d1
    // 0x898edc: stur            d3, [fp, #-0x48]
    // 0x898ee0: r0 = Offset()
    //     0x898ee0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x898ee4: ldur            d0, [fp, #-0x40]
    // 0x898ee8: stur            x0, [fp, #-0x18]
    // 0x898eec: StoreField: r0->field_7 = d0
    //     0x898eec: stur            d0, [x0, #7]
    // 0x898ef0: ldur            d0, [fp, #-0x48]
    // 0x898ef4: StoreField: r0->field_f = d0
    //     0x898ef4: stur            d0, [x0, #0xf]
    // 0x898ef8: ldur            x1, [fp, #-0x10]
    // 0x898efc: r0 = center()
    //     0x898efc: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x898f00: LoadField: d0 = r0->field_7
    //     0x898f00: ldur            d0, [x0, #7]
    // 0x898f04: ldur            x0, [fp, #-0x10]
    // 0x898f08: stur            d0, [fp, #-0x48]
    // 0x898f0c: LoadField: d1 = r0->field_1f
    //     0x898f0c: ldur            d1, [x0, #0x1f]
    // 0x898f10: d2 = 1.000000
    //     0x898f10: fmov            d2, #1.00000000
    // 0x898f14: fsub            d3, d1, d2
    // 0x898f18: ldur            x0, [fp, #-0x20]
    // 0x898f1c: stur            d3, [fp, #-0x40]
    // 0x898f20: cmp             x0, #0xe86
    // 0x898f24: b.ne            #0x898f40
    // 0x898f28: ldur            x3, [fp, #-0x28]
    // 0x898f2c: LoadField: r0 = r3->field_13
    //     0x898f2c: ldur            w0, [x3, #0x13]
    // 0x898f30: DecompressPointer r0
    //     0x898f30: add             x0, x0, HEAP, lsl #32
    // 0x898f34: mov             x1, x0
    // 0x898f38: mov             v1.16b, v3.16b
    // 0x898f3c: b               #0x898fe0
    // 0x898f40: ldur            x3, [fp, #-0x28]
    // 0x898f44: LoadField: r0 = r3->field_f
    //     0x898f44: ldur            w0, [x3, #0xf]
    // 0x898f48: DecompressPointer r0
    //     0x898f48: add             x0, x0, HEAP, lsl #32
    // 0x898f4c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x898f4c: ldur            w4, [x0, #0x17]
    // 0x898f50: DecompressPointer r4
    //     0x898f50: add             x4, x4, HEAP, lsl #32
    // 0x898f54: stur            x4, [fp, #-0x10]
    // 0x898f58: LoadField: r2 = r3->field_7
    //     0x898f58: ldur            x2, [x3, #7]
    // 0x898f5c: r0 = BoxInt64Instr(r2)
    //     0x898f5c: sbfiz           x0, x2, #1, #0x1f
    //     0x898f60: cmp             x2, x0, asr #1
    //     0x898f64: b.eq            #0x898f70
    //     0x898f68: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0x898f6c: stur            x2, [x0, #7]
    // 0x898f70: mov             x1, x4
    // 0x898f74: mov             x2, x0
    // 0x898f78: r0 = _getValueOrData()
    //     0x898f78: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x898f7c: mov             x1, x0
    // 0x898f80: ldur            x0, [fp, #-0x10]
    // 0x898f84: LoadField: r2 = r0->field_f
    //     0x898f84: ldur            w2, [x0, #0xf]
    // 0x898f88: DecompressPointer r2
    //     0x898f88: add             x2, x2, HEAP, lsl #32
    // 0x898f8c: cmp             w2, w1
    // 0x898f90: b.ne            #0x898f98
    // 0x898f94: r1 = Null
    //     0x898f94: mov             x1, NULL
    // 0x898f98: cmp             w1, NULL
    // 0x898f9c: b.ne            #0x898fa8
    // 0x898fa0: r0 = Null
    //     0x898fa0: mov             x0, NULL
    // 0x898fa4: b               #0x898fbc
    // 0x898fa8: r0 = LoadClassIdInstr(r1)
    //     0x898fa8: ldur            x0, [x1, #-1]
    //     0x898fac: ubfx            x0, x0, #0xc, #0x14
    // 0x898fb0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x898fb0: sub             lr, x0, #1, lsl #12
    //     0x898fb4: ldr             lr, [x21, lr, lsl #3]
    //     0x898fb8: blr             lr
    // 0x898fbc: cmp             w0, NULL
    // 0x898fc0: b.ne            #0x898fd4
    // 0x898fc4: ldur            x0, [fp, #-0x28]
    // 0x898fc8: LoadField: r1 = r0->field_13
    //     0x898fc8: ldur            w1, [x0, #0x13]
    // 0x898fcc: DecompressPointer r1
    //     0x898fcc: add             x1, x1, HEAP, lsl #32
    // 0x898fd0: mov             x0, x1
    // 0x898fd4: mov             x1, x0
    // 0x898fd8: ldur            d1, [fp, #-0x40]
    // 0x898fdc: ldur            d0, [fp, #-0x48]
    // 0x898fe0: ldur            x0, [fp, #-8]
    // 0x898fe4: d2 = 2.000000
    //     0x898fe4: fmov            d2, #2.00000000
    // 0x898fe8: LoadField: r2 = r1->field_2b
    //     0x898fe8: ldur            w2, [x1, #0x2b]
    // 0x898fec: DecompressPointer r2
    //     0x898fec: add             x2, x2, HEAP, lsl #32
    // 0x898ff0: LoadField: d3 = r2->field_1f
    //     0x898ff0: ldur            d3, [x2, #0x1f]
    // 0x898ff4: fdiv            d4, d3, d2
    // 0x898ff8: fsub            d2, d1, d4
    // 0x898ffc: stur            d2, [fp, #-0x50]
    // 0x899000: r0 = Offset()
    //     0x899000: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x899004: ldur            d0, [fp, #-0x48]
    // 0x899008: stur            x0, [fp, #-0x28]
    // 0x89900c: StoreField: r0->field_7 = d0
    //     0x89900c: stur            d0, [x0, #7]
    // 0x899010: ldur            d0, [fp, #-0x50]
    // 0x899014: StoreField: r0->field_f = d0
    //     0x899014: stur            d0, [x0, #0xf]
    // 0x899018: ldur            x1, [fp, #-8]
    // 0x89901c: LoadField: r2 = r1->field_2f
    //     0x89901c: ldur            w2, [x1, #0x2f]
    // 0x899020: DecompressPointer r2
    //     0x899020: add             x2, x2, HEAP, lsl #32
    // 0x899024: stur            x2, [fp, #-0x10]
    // 0x899028: LoadField: r1 = r2->field_b
    //     0x899028: ldur            w1, [x2, #0xb]
    // 0x89902c: DecompressPointer r1
    //     0x89902c: add             x1, x1, HEAP, lsl #32
    // 0x899030: cmp             w1, NULL
    // 0x899034: b.eq            #0x8991d8
    // 0x899038: r16 = <SystemUiOverlayStyle>
    //     0x899038: ldr             x16, [PP, #0x2c08]  ; [pp+0x2c08] TypeArguments: <SystemUiOverlayStyle>
    // 0x89903c: stp             x1, x16, [SP, #8]
    // 0x899040: ldur            x16, [fp, #-0x18]
    // 0x899044: str             x16, [SP]
    // 0x899048: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x899048: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x89904c: r0 = find()
    //     0x89904c: bl              #0x899760  ; [package:flutter/src/rendering/layer.dart] Layer::find
    // 0x899050: mov             x1, x0
    // 0x899054: ldur            x0, [fp, #-0x10]
    // 0x899058: stur            x1, [fp, #-8]
    // 0x89905c: LoadField: r2 = r0->field_b
    //     0x89905c: ldur            w2, [x0, #0xb]
    // 0x899060: DecompressPointer r2
    //     0x899060: add             x2, x2, HEAP, lsl #32
    // 0x899064: cmp             w2, NULL
    // 0x899068: b.eq            #0x8991dc
    // 0x89906c: r16 = <SystemUiOverlayStyle>
    //     0x89906c: ldr             x16, [PP, #0x2c08]  ; [pp+0x2c08] TypeArguments: <SystemUiOverlayStyle>
    // 0x899070: stp             x2, x16, [SP, #8]
    // 0x899074: ldur            x16, [fp, #-0x28]
    // 0x899078: str             x16, [SP]
    // 0x89907c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x89907c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x899080: r0 = find()
    //     0x899080: bl              #0x899760  ; [package:flutter/src/rendering/layer.dart] Layer::find
    // 0x899084: mov             x1, x0
    // 0x899088: ldur            x0, [fp, #-8]
    // 0x89908c: cmp             w0, NULL
    // 0x899090: b.ne            #0x8990ac
    // 0x899094: cmp             w1, NULL
    // 0x899098: b.ne            #0x8990ac
    // 0x89909c: r0 = Null
    //     0x89909c: mov             x0, NULL
    // 0x8990a0: LeaveFrame
    //     0x8990a0: mov             SP, fp
    //     0x8990a4: ldp             fp, lr, [SP], #0x10
    // 0x8990a8: ret
    //     0x8990a8: ret             
    // 0x8990ac: cmp             w0, NULL
    // 0x8990b0: b.eq            #0x89913c
    // 0x8990b4: cmp             w1, NULL
    // 0x8990b8: b.eq            #0x89913c
    // 0x8990bc: LoadField: r2 = r0->field_1b
    //     0x8990bc: ldur            w2, [x0, #0x1b]
    // 0x8990c0: DecompressPointer r2
    //     0x8990c0: add             x2, x2, HEAP, lsl #32
    // 0x8990c4: stur            x2, [fp, #-0x38]
    // 0x8990c8: LoadField: r3 = r0->field_1f
    //     0x8990c8: ldur            w3, [x0, #0x1f]
    // 0x8990cc: DecompressPointer r3
    //     0x8990cc: add             x3, x3, HEAP, lsl #32
    // 0x8990d0: stur            x3, [fp, #-0x30]
    // 0x8990d4: ArrayLoad: r4 = r0[0]  ; List_4
    //     0x8990d4: ldur            w4, [x0, #0x17]
    // 0x8990d8: DecompressPointer r4
    //     0x8990d8: add             x4, x4, HEAP, lsl #32
    // 0x8990dc: stur            x4, [fp, #-0x28]
    // 0x8990e0: LoadField: r0 = r1->field_7
    //     0x8990e0: ldur            w0, [x1, #7]
    // 0x8990e4: DecompressPointer r0
    //     0x8990e4: add             x0, x0, HEAP, lsl #32
    // 0x8990e8: stur            x0, [fp, #-0x18]
    // 0x8990ec: LoadField: r5 = r1->field_f
    //     0x8990ec: ldur            w5, [x1, #0xf]
    // 0x8990f0: DecompressPointer r5
    //     0x8990f0: add             x5, x5, HEAP, lsl #32
    // 0x8990f4: stur            x5, [fp, #-0x10]
    // 0x8990f8: r0 = SystemUiOverlayStyle()
    //     0x8990f8: bl              #0x899754  ; AllocateSystemUiOverlayStyleStub -> SystemUiOverlayStyle (size=0x28)
    // 0x8990fc: mov             x1, x0
    // 0x899100: ldur            x0, [fp, #-0x18]
    // 0x899104: StoreField: r1->field_7 = r0
    //     0x899104: stur            w0, [x1, #7]
    // 0x899108: ldur            x0, [fp, #-0x10]
    // 0x89910c: StoreField: r1->field_f = r0
    //     0x89910c: stur            w0, [x1, #0xf]
    // 0x899110: ldur            x0, [fp, #-0x28]
    // 0x899114: ArrayStore: r1[0] = r0  ; List_4
    //     0x899114: stur            w0, [x1, #0x17]
    // 0x899118: ldur            x0, [fp, #-0x38]
    // 0x89911c: StoreField: r1->field_1b = r0
    //     0x89911c: stur            w0, [x1, #0x1b]
    // 0x899120: ldur            x0, [fp, #-0x30]
    // 0x899124: StoreField: r1->field_1f = r0
    //     0x899124: stur            w0, [x1, #0x1f]
    // 0x899128: r0 = setSystemUIOverlayStyle()
    //     0x899128: bl              #0x8991e4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setSystemUIOverlayStyle
    // 0x89912c: r0 = Null
    //     0x89912c: mov             x0, NULL
    // 0x899130: LeaveFrame
    //     0x899130: mov             SP, fp
    //     0x899134: ldp             fp, lr, [SP], #0x10
    // 0x899138: ret
    //     0x899138: ret             
    // 0x89913c: cmp             w0, NULL
    // 0x899140: b.ne            #0x899148
    // 0x899144: mov             x0, x1
    // 0x899148: cmp             w0, NULL
    // 0x89914c: b.eq            #0x8991e0
    // 0x899150: LoadField: r1 = r0->field_1b
    //     0x899150: ldur            w1, [x0, #0x1b]
    // 0x899154: DecompressPointer r1
    //     0x899154: add             x1, x1, HEAP, lsl #32
    // 0x899158: stur            x1, [fp, #-0x30]
    // 0x89915c: LoadField: r2 = r0->field_1f
    //     0x89915c: ldur            w2, [x0, #0x1f]
    // 0x899160: DecompressPointer r2
    //     0x899160: add             x2, x2, HEAP, lsl #32
    // 0x899164: stur            x2, [fp, #-0x28]
    // 0x899168: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x899168: ldur            w3, [x0, #0x17]
    // 0x89916c: DecompressPointer r3
    //     0x89916c: add             x3, x3, HEAP, lsl #32
    // 0x899170: stur            x3, [fp, #-0x18]
    // 0x899174: LoadField: r4 = r0->field_7
    //     0x899174: ldur            w4, [x0, #7]
    // 0x899178: DecompressPointer r4
    //     0x899178: add             x4, x4, HEAP, lsl #32
    // 0x89917c: stur            x4, [fp, #-0x10]
    // 0x899180: LoadField: r5 = r0->field_f
    //     0x899180: ldur            w5, [x0, #0xf]
    // 0x899184: DecompressPointer r5
    //     0x899184: add             x5, x5, HEAP, lsl #32
    // 0x899188: stur            x5, [fp, #-8]
    // 0x89918c: r0 = SystemUiOverlayStyle()
    //     0x89918c: bl              #0x899754  ; AllocateSystemUiOverlayStyleStub -> SystemUiOverlayStyle (size=0x28)
    // 0x899190: mov             x1, x0
    // 0x899194: ldur            x0, [fp, #-0x10]
    // 0x899198: StoreField: r1->field_7 = r0
    //     0x899198: stur            w0, [x1, #7]
    // 0x89919c: ldur            x0, [fp, #-8]
    // 0x8991a0: StoreField: r1->field_f = r0
    //     0x8991a0: stur            w0, [x1, #0xf]
    // 0x8991a4: ldur            x0, [fp, #-0x18]
    // 0x8991a8: ArrayStore: r1[0] = r0  ; List_4
    //     0x8991a8: stur            w0, [x1, #0x17]
    // 0x8991ac: ldur            x0, [fp, #-0x30]
    // 0x8991b0: StoreField: r1->field_1b = r0
    //     0x8991b0: stur            w0, [x1, #0x1b]
    // 0x8991b4: ldur            x0, [fp, #-0x28]
    // 0x8991b8: StoreField: r1->field_1f = r0
    //     0x8991b8: stur            w0, [x1, #0x1f]
    // 0x8991bc: r0 = setSystemUIOverlayStyle()
    //     0x8991bc: bl              #0x8991e4  ; [package:flutter/src/services/system_chrome.dart] SystemChrome::setSystemUIOverlayStyle
    // 0x8991c0: r0 = Null
    //     0x8991c0: mov             x0, NULL
    // 0x8991c4: LeaveFrame
    //     0x8991c4: mov             SP, fp
    //     0x8991c8: ldp             fp, lr, [SP], #0x10
    // 0x8991cc: ret
    //     0x8991cc: ret             
    // 0x8991d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8991d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8991d4: b               #0x898dcc
    // 0x8991d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8991d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8991dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8991dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8991e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8991e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ configuration=(/* No info */) {
    // ** addr: 0x89ce24, size: 0x11c
    // 0x89ce24: EnterFrame
    //     0x89ce24: stp             fp, lr, [SP, #-0x10]!
    //     0x89ce28: mov             fp, SP
    // 0x89ce2c: AllocStack(0x28)
    //     0x89ce2c: sub             SP, SP, #0x28
    // 0x89ce30: SetupParameters(RenderView this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x89ce30: stur            x1, [fp, #-8]
    //     0x89ce34: mov             x16, x2
    //     0x89ce38: mov             x2, x1
    //     0x89ce3c: mov             x1, x16
    //     0x89ce40: stur            x1, [fp, #-0x10]
    // 0x89ce44: CheckStackOverflow
    //     0x89ce44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89ce48: cmp             SP, x16
    //     0x89ce4c: b.ls            #0x89cf38
    // 0x89ce50: LoadField: r0 = r2->field_4f
    //     0x89ce50: ldur            w0, [x2, #0x4f]
    // 0x89ce54: DecompressPointer r0
    //     0x89ce54: add             x0, x0, HEAP, lsl #32
    // 0x89ce58: r3 = LoadClassIdInstr(r0)
    //     0x89ce58: ldur            x3, [x0, #-1]
    //     0x89ce5c: ubfx            x3, x3, #0xc, #0x14
    // 0x89ce60: stp             x1, x0, [SP]
    // 0x89ce64: mov             x0, x3
    // 0x89ce68: mov             lr, x0
    // 0x89ce6c: ldr             lr, [x21, lr, lsl #3]
    // 0x89ce70: blr             lr
    // 0x89ce74: tbnz            w0, #4, #0x89ce88
    // 0x89ce78: r0 = Null
    //     0x89ce78: mov             x0, NULL
    // 0x89ce7c: LeaveFrame
    //     0x89ce7c: mov             SP, fp
    //     0x89ce80: ldp             fp, lr, [SP], #0x10
    // 0x89ce84: ret
    //     0x89ce84: ret             
    // 0x89ce88: ldur            x1, [fp, #-8]
    // 0x89ce8c: LoadField: r2 = r1->field_4f
    //     0x89ce8c: ldur            w2, [x1, #0x4f]
    // 0x89ce90: DecompressPointer r2
    //     0x89ce90: add             x2, x2, HEAP, lsl #32
    // 0x89ce94: ldur            x0, [fp, #-0x10]
    // 0x89ce98: stur            x2, [fp, #-0x18]
    // 0x89ce9c: StoreField: r1->field_4f = r0
    //     0x89ce9c: stur            w0, [x1, #0x4f]
    //     0x89cea0: ldurb           w16, [x1, #-1]
    //     0x89cea4: ldurb           w17, [x0, #-1]
    //     0x89cea8: and             x16, x17, x16, lsr #2
    //     0x89ceac: tst             x16, HEAP, lsr #32
    //     0x89ceb0: b.eq            #0x89ceb8
    //     0x89ceb4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x89ceb8: LoadField: r0 = r1->field_5b
    //     0x89ceb8: ldur            w0, [x1, #0x5b]
    // 0x89cebc: DecompressPointer r0
    //     0x89cebc: add             x0, x0, HEAP, lsl #32
    // 0x89cec0: cmp             w0, NULL
    // 0x89cec4: b.ne            #0x89ced8
    // 0x89cec8: r0 = Null
    //     0x89cec8: mov             x0, NULL
    // 0x89cecc: LeaveFrame
    //     0x89cecc: mov             SP, fp
    //     0x89ced0: ldp             fp, lr, [SP], #0x10
    // 0x89ced4: ret
    //     0x89ced4: ret             
    // 0x89ced8: cmp             w2, NULL
    // 0x89cedc: b.eq            #0x89cf0c
    // 0x89cee0: r16 = ViewConfiguration
    //     0x89cee0: ldr             x16, [PP, #0x2ea8]  ; [pp+0x2ea8] Type: ViewConfiguration
    // 0x89cee4: r30 = ViewConfiguration
    //     0x89cee4: ldr             lr, [PP, #0x2ea8]  ; [pp+0x2ea8] Type: ViewConfiguration
    // 0x89cee8: stp             lr, x16, [SP]
    // 0x89ceec: r0 = ==()
    //     0x89ceec: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x89cef0: tbnz            w0, #4, #0x89cf0c
    // 0x89cef4: ldur            x1, [fp, #-0x10]
    // 0x89cef8: ldur            x0, [fp, #-0x18]
    // 0x89cefc: LoadField: d0 = r0->field_f
    //     0x89cefc: ldur            d0, [x0, #0xf]
    // 0x89cf00: LoadField: d1 = r1->field_f
    //     0x89cf00: ldur            d1, [x1, #0xf]
    // 0x89cf04: fcmp            d0, d1
    // 0x89cf08: b.eq            #0x89cf20
    // 0x89cf0c: ldur            x1, [fp, #-8]
    // 0x89cf10: r0 = _updateMatricesAndCreateNewRootLayer()
    //     0x89cf10: bl              #0x89cfc8  ; [package:flutter/src/rendering/view.dart] RenderView::_updateMatricesAndCreateNewRootLayer
    // 0x89cf14: ldur            x1, [fp, #-8]
    // 0x89cf18: mov             x2, x0
    // 0x89cf1c: r0 = replaceRootLayer()
    //     0x89cf1c: bl              #0x89cf40  ; [package:flutter/src/rendering/object.dart] RenderObject::replaceRootLayer
    // 0x89cf20: ldur            x1, [fp, #-8]
    // 0x89cf24: r0 = markNeedsLayout()
    //     0x89cf24: bl              #0xbfb800  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0x89cf28: r0 = Null
    //     0x89cf28: mov             x0, NULL
    // 0x89cf2c: LeaveFrame
    //     0x89cf2c: mov             SP, fp
    //     0x89cf30: ldp             fp, lr, [SP], #0x10
    // 0x89cf34: ret
    //     0x89cf34: ret             
    // 0x89cf38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89cf38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89cf3c: b               #0x89ce50
  }
  _ _updateMatricesAndCreateNewRootLayer(/* No info */) {
    // ** addr: 0x89cfc8, size: 0xb0
    // 0x89cfc8: EnterFrame
    //     0x89cfc8: stp             fp, lr, [SP, #-0x10]!
    //     0x89cfcc: mov             fp, SP
    // 0x89cfd0: AllocStack(0x18)
    //     0x89cfd0: sub             SP, SP, #0x18
    // 0x89cfd4: SetupParameters(RenderView this /* r1 => r2, fp-0x8 */)
    //     0x89cfd4: mov             x2, x1
    //     0x89cfd8: stur            x1, [fp, #-8]
    // 0x89cfdc: CheckStackOverflow
    //     0x89cfdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89cfe0: cmp             SP, x16
    //     0x89cfe4: b.ls            #0x89d06c
    // 0x89cfe8: LoadField: r1 = r2->field_4f
    //     0x89cfe8: ldur            w1, [x2, #0x4f]
    // 0x89cfec: DecompressPointer r1
    //     0x89cfec: add             x1, x1, HEAP, lsl #32
    // 0x89cff0: cmp             w1, NULL
    // 0x89cff4: b.eq            #0x89d074
    // 0x89cff8: r0 = toMatrix()
    //     0x89cff8: bl              #0x89d130  ; [package:flutter/src/rendering/view.dart] ViewConfiguration::toMatrix
    // 0x89cffc: mov             x1, x0
    // 0x89d000: ldur            x2, [fp, #-8]
    // 0x89d004: stur            x1, [fp, #-0x10]
    // 0x89d008: StoreField: r2->field_5b = r0
    //     0x89d008: stur            w0, [x2, #0x5b]
    //     0x89d00c: ldurb           w16, [x2, #-1]
    //     0x89d010: ldurb           w17, [x0, #-1]
    //     0x89d014: and             x16, x17, x16, lsr #2
    //     0x89d018: tst             x16, HEAP, lsr #32
    //     0x89d01c: b.eq            #0x89d024
    //     0x89d020: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x89d024: r0 = TransformLayer()
    //     0x89d024: bl              #0x89d124  ; AllocateTransformLayerStub -> TransformLayer (size=0x5c)
    // 0x89d028: mov             x2, x0
    // 0x89d02c: r0 = true
    //     0x89d02c: add             x0, NULL, #0x20  ; true
    // 0x89d030: stur            x2, [fp, #-0x18]
    // 0x89d034: StoreField: r2->field_57 = r0
    //     0x89d034: stur            w0, [x2, #0x57]
    // 0x89d038: ldur            x0, [fp, #-0x10]
    // 0x89d03c: StoreField: r2->field_4b = r0
    //     0x89d03c: stur            w0, [x2, #0x4b]
    // 0x89d040: r0 = Instance_Offset
    //     0x89d040: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x89d044: StoreField: r2->field_47 = r0
    //     0x89d044: stur            w0, [x2, #0x47]
    // 0x89d048: mov             x1, x2
    // 0x89d04c: r0 = Layer()
    //     0x89d04c: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x89d050: ldur            x1, [fp, #-0x18]
    // 0x89d054: ldur            x2, [fp, #-8]
    // 0x89d058: r0 = attach()
    //     0x89d058: bl              #0x1146e7c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::attach
    // 0x89d05c: ldur            x0, [fp, #-0x18]
    // 0x89d060: LeaveFrame
    //     0x89d060: mov             SP, fp
    //     0x89d064: ldp             fp, lr, [SP], #0x10
    // 0x89d068: ret
    //     0x89d068: ret             
    // 0x89d06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89d06c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89d070: b               #0x89cfe8
    // 0x89d074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89d074: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ prepareInitialFrame(/* No info */) {
    // ** addr: 0xb8ed58, size: 0x54
    // 0xb8ed58: EnterFrame
    //     0xb8ed58: stp             fp, lr, [SP, #-0x10]!
    //     0xb8ed5c: mov             fp, SP
    // 0xb8ed60: AllocStack(0x8)
    //     0xb8ed60: sub             SP, SP, #8
    // 0xb8ed64: SetupParameters(RenderView this /* r1 => r0, fp-0x8 */)
    //     0xb8ed64: mov             x0, x1
    //     0xb8ed68: stur            x1, [fp, #-8]
    // 0xb8ed6c: CheckStackOverflow
    //     0xb8ed6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8ed70: cmp             SP, x16
    //     0xb8ed74: b.ls            #0xb8eda4
    // 0xb8ed78: mov             x1, x0
    // 0xb8ed7c: r0 = scheduleInitialLayout()
    //     0xb8ed7c: bl              #0xb8ee88  ; [package:flutter/src/rendering/object.dart] RenderObject::scheduleInitialLayout
    // 0xb8ed80: ldur            x1, [fp, #-8]
    // 0xb8ed84: r0 = _updateMatricesAndCreateNewRootLayer()
    //     0xb8ed84: bl              #0x89cfc8  ; [package:flutter/src/rendering/view.dart] RenderView::_updateMatricesAndCreateNewRootLayer
    // 0xb8ed88: ldur            x1, [fp, #-8]
    // 0xb8ed8c: mov             x2, x0
    // 0xb8ed90: r0 = scheduleInitialPaint()
    //     0xb8ed90: bl              #0xb8edac  ; [package:flutter/src/rendering/object.dart] RenderObject::scheduleInitialPaint
    // 0xb8ed94: r0 = Null
    //     0xb8ed94: mov             x0, NULL
    // 0xb8ed98: LeaveFrame
    //     0xb8ed98: mov             SP, fp
    //     0xb8ed9c: ldp             fp, lr, [SP], #0x10
    // 0xb8eda0: ret
    //     0xb8eda0: ret             
    // 0xb8eda4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8eda4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8eda8: b               #0xb8ed78
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbeb6a0, size: 0x104
    // 0xbeb6a0: EnterFrame
    //     0xbeb6a0: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb6a4: mov             fp, SP
    // 0xbeb6a8: AllocStack(0x20)
    //     0xbeb6a8: sub             SP, SP, #0x20
    // 0xbeb6ac: SetupParameters(RenderView this /* r1 => r0, fp-0x8 */)
    //     0xbeb6ac: mov             x0, x1
    //     0xbeb6b0: stur            x1, [fp, #-8]
    // 0xbeb6b4: CheckStackOverflow
    //     0xbeb6b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeb6b8: cmp             SP, x16
    //     0xbeb6bc: b.ls            #0xbeb79c
    // 0xbeb6c0: mov             x1, x0
    // 0xbeb6c4: r0 = constraints()
    //     0xbeb6c4: bl              #0xcceaa4  ; [package:flutter/src/rendering/view.dart] RenderView::constraints
    // 0xbeb6c8: mov             x1, x0
    // 0xbeb6cc: r0 = isTight()
    //     0xbeb6cc: bl              #0x13081bc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::isTight
    // 0xbeb6d0: eor             x2, x0, #0x10
    // 0xbeb6d4: ldur            x0, [fp, #-8]
    // 0xbeb6d8: stur            x2, [fp, #-0x18]
    // 0xbeb6dc: LoadField: r3 = r0->field_47
    //     0xbeb6dc: ldur            w3, [x0, #0x47]
    // 0xbeb6e0: DecompressPointer r3
    //     0xbeb6e0: add             x3, x3, HEAP, lsl #32
    // 0xbeb6e4: stur            x3, [fp, #-0x10]
    // 0xbeb6e8: cmp             w3, NULL
    // 0xbeb6ec: b.ne            #0xbeb6f8
    // 0xbeb6f0: mov             x0, x2
    // 0xbeb6f4: b               #0xbeb73c
    // 0xbeb6f8: mov             x1, x0
    // 0xbeb6fc: r0 = constraints()
    //     0xbeb6fc: bl              #0xcceaa4  ; [package:flutter/src/rendering/view.dart] RenderView::constraints
    // 0xbeb700: ldur            x1, [fp, #-0x10]
    // 0xbeb704: r2 = LoadClassIdInstr(r1)
    //     0xbeb704: ldur            x2, [x1, #-1]
    //     0xbeb708: ubfx            x2, x2, #0xc, #0x14
    // 0xbeb70c: ldur            x16, [fp, #-0x18]
    // 0xbeb710: str             x16, [SP]
    // 0xbeb714: mov             x16, x0
    // 0xbeb718: mov             x0, x2
    // 0xbeb71c: mov             x2, x16
    // 0xbeb720: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbeb720: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbeb724: ldr             x4, [x4, #0xed0]
    // 0xbeb728: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbeb728: mov             x17, #0xe6b9
    //     0xbeb72c: add             lr, x0, x17
    //     0xbeb730: ldr             lr, [x21, lr, lsl #3]
    //     0xbeb734: blr             lr
    // 0xbeb738: ldur            x0, [fp, #-0x18]
    // 0xbeb73c: tbnz            w0, #4, #0xbeb75c
    // 0xbeb740: ldur            x0, [fp, #-8]
    // 0xbeb744: LoadField: r1 = r0->field_47
    //     0xbeb744: ldur            w1, [x0, #0x47]
    // 0xbeb748: DecompressPointer r1
    //     0xbeb748: add             x1, x1, HEAP, lsl #32
    // 0xbeb74c: cmp             w1, NULL
    // 0xbeb750: b.eq            #0xbeb75c
    // 0xbeb754: r0 = size()
    //     0xbeb754: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbeb758: b               #0xbeb76c
    // 0xbeb75c: ldur            x1, [fp, #-8]
    // 0xbeb760: r0 = constraints()
    //     0xbeb760: bl              #0xcceaa4  ; [package:flutter/src/rendering/view.dart] RenderView::constraints
    // 0xbeb764: mov             x1, x0
    // 0xbeb768: r0 = smallest()
    //     0xbeb768: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbeb76c: ldur            x1, [fp, #-8]
    // 0xbeb770: StoreField: r1->field_4b = r0
    //     0xbeb770: stur            w0, [x1, #0x4b]
    //     0xbeb774: ldurb           w16, [x1, #-1]
    //     0xbeb778: ldurb           w17, [x0, #-1]
    //     0xbeb77c: and             x16, x17, x16, lsr #2
    //     0xbeb780: tst             x16, HEAP, lsr #32
    //     0xbeb784: b.eq            #0xbeb78c
    //     0xbeb788: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbeb78c: r0 = Null
    //     0xbeb78c: mov             x0, NULL
    // 0xbeb790: LeaveFrame
    //     0xbeb790: mov             SP, fp
    //     0xbeb794: ldp             fp, lr, [SP], #0x10
    // 0xbeb798: ret
    //     0xbeb798: ret             
    // 0xbeb79c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb79c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb7a0: b               #0xbeb6c0
  }
  get _ paintBounds(/* No info */) {
    // ** addr: 0xbf0584, size: 0x5c
    // 0xbf0584: EnterFrame
    //     0xbf0584: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0588: mov             fp, SP
    // 0xbf058c: CheckStackOverflow
    //     0xbf058c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0590: cmp             SP, x16
    //     0xbf0594: b.ls            #0xbf05d4
    // 0xbf0598: LoadField: r0 = r1->field_4b
    //     0xbf0598: ldur            w0, [x1, #0x4b]
    // 0xbf059c: DecompressPointer r0
    //     0xbf059c: add             x0, x0, HEAP, lsl #32
    // 0xbf05a0: LoadField: r2 = r1->field_4f
    //     0xbf05a0: ldur            w2, [x1, #0x4f]
    // 0xbf05a4: DecompressPointer r2
    //     0xbf05a4: add             x2, x2, HEAP, lsl #32
    // 0xbf05a8: cmp             w2, NULL
    // 0xbf05ac: b.eq            #0xbf05dc
    // 0xbf05b0: LoadField: d0 = r2->field_f
    //     0xbf05b0: ldur            d0, [x2, #0xf]
    // 0xbf05b4: mov             x1, x0
    // 0xbf05b8: r0 = *()
    //     0xbf05b8: bl              #0x81d1f4  ; [dart:ui] Size::*
    // 0xbf05bc: mov             x2, x0
    // 0xbf05c0: r1 = Instance_Offset
    //     0xbf05c0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbf05c4: r0 = &()
    //     0xbf05c4: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xbf05c8: LeaveFrame
    //     0xbf05c8: mov             SP, fp
    //     0xbf05cc: ldp             fp, lr, [SP], #0x10
    // 0xbf05d0: ret
    //     0xbf05d0: ret             
    // 0xbf05d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf05d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf05d8: b               #0xbf0598
    // 0xbf05dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf05dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf251c, size: 0x98
    // 0xbf251c: EnterFrame
    //     0xbf251c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2520: mov             fp, SP
    // 0xbf2524: AllocStack(0x10)
    //     0xbf2524: sub             SP, SP, #0x10
    // 0xbf2528: SetupParameters(RenderView this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xbf2528: mov             x4, x1
    //     0xbf252c: mov             x0, x2
    //     0xbf2530: stur            x1, [fp, #-8]
    //     0xbf2534: stur            x3, [fp, #-0x10]
    // 0xbf2538: CheckStackOverflow
    //     0xbf2538: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf253c: cmp             SP, x16
    //     0xbf2540: b.ls            #0xbf25a8
    // 0xbf2544: r2 = Null
    //     0xbf2544: mov             x2, NULL
    // 0xbf2548: r1 = Null
    //     0xbf2548: mov             x1, NULL
    // 0xbf254c: r4 = 60
    //     0xbf254c: mov             x4, #0x3c
    // 0xbf2550: branchIfSmi(r0, 0xbf255c)
    //     0xbf2550: tbz             w0, #0, #0xbf255c
    // 0xbf2554: r4 = LoadClassIdInstr(r0)
    //     0xbf2554: ldur            x4, [x0, #-1]
    //     0xbf2558: ubfx            x4, x4, #0xc, #0x14
    // 0xbf255c: r17 = -4710
    //     0xbf255c: mov             x17, #-0x1266
    // 0xbf2560: add             x4, x4, x17
    // 0xbf2564: cmp             x4, #0x109
    // 0xbf2568: b.ls            #0xbf257c
    // 0xbf256c: r8 = RenderBox
    //     0xbf256c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf2570: r3 = Null
    //     0xbf2570: add             x3, PP, #0xd, lsl #12  ; [pp+0xdea0] Null
    //     0xbf2574: ldr             x3, [x3, #0xea0]
    // 0xbf2578: r0 = RenderBox()
    //     0xbf2578: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf257c: ldur            x0, [fp, #-8]
    // 0xbf2580: LoadField: r2 = r0->field_5b
    //     0xbf2580: ldur            w2, [x0, #0x5b]
    // 0xbf2584: DecompressPointer r2
    //     0xbf2584: add             x2, x2, HEAP, lsl #32
    // 0xbf2588: cmp             w2, NULL
    // 0xbf258c: b.eq            #0xbf25b0
    // 0xbf2590: ldur            x1, [fp, #-0x10]
    // 0xbf2594: r0 = multiply()
    //     0xbf2594: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbf2598: r0 = Null
    //     0xbf2598: mov             x0, NULL
    // 0xbf259c: LeaveFrame
    //     0xbf259c: mov             SP, fp
    //     0xbf25a0: ldp             fp, lr, [SP], #0x10
    // 0xbf25a4: ret
    //     0xbf25a4: ret             
    // 0xbf25a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf25a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf25ac: b               #0xbf2544
    // 0xbf25b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf25b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ semanticBounds(/* No info */) {
    // ** addr: 0xbf2a60, size: 0x60
    // 0xbf2a60: EnterFrame
    //     0xbf2a60: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2a64: mov             fp, SP
    // 0xbf2a68: AllocStack(0x8)
    //     0xbf2a68: sub             SP, SP, #8
    // 0xbf2a6c: CheckStackOverflow
    //     0xbf2a6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf2a70: cmp             SP, x16
    //     0xbf2a74: b.ls            #0xbf2ab4
    // 0xbf2a78: LoadField: r0 = r1->field_5b
    //     0xbf2a78: ldur            w0, [x1, #0x5b]
    // 0xbf2a7c: DecompressPointer r0
    //     0xbf2a7c: add             x0, x0, HEAP, lsl #32
    // 0xbf2a80: stur            x0, [fp, #-8]
    // 0xbf2a84: cmp             w0, NULL
    // 0xbf2a88: b.eq            #0xbf2abc
    // 0xbf2a8c: LoadField: r2 = r1->field_4b
    //     0xbf2a8c: ldur            w2, [x1, #0x4b]
    // 0xbf2a90: DecompressPointer r2
    //     0xbf2a90: add             x2, x2, HEAP, lsl #32
    // 0xbf2a94: r1 = Instance_Offset
    //     0xbf2a94: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbf2a98: r0 = &()
    //     0xbf2a98: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xbf2a9c: ldur            x1, [fp, #-8]
    // 0xbf2aa0: mov             x2, x0
    // 0xbf2aa4: r0 = transformRect()
    //     0xbf2aa4: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0xbf2aa8: LeaveFrame
    //     0xbf2aa8: mov             SP, fp
    //     0xbf2aac: ldp             fp, lr, [SP], #0x10
    // 0xbf2ab0: ret
    //     0xbf2ab0: ret             
    // 0xbf2ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2ab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2ab8: b               #0xbf2a78
    // 0xbf2abc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf2abc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xccdc20, size: 0x4c
    // 0xccdc20: EnterFrame
    //     0xccdc20: stp             fp, lr, [SP, #-0x10]!
    //     0xccdc24: mov             fp, SP
    // 0xccdc28: mov             x0, x1
    // 0xccdc2c: mov             x1, x2
    // 0xccdc30: CheckStackOverflow
    //     0xccdc30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccdc34: cmp             SP, x16
    //     0xccdc38: b.ls            #0xccdc64
    // 0xccdc3c: LoadField: r2 = r0->field_47
    //     0xccdc3c: ldur            w2, [x0, #0x47]
    // 0xccdc40: DecompressPointer r2
    //     0xccdc40: add             x2, x2, HEAP, lsl #32
    // 0xccdc44: cmp             w2, NULL
    // 0xccdc48: b.eq            #0xccdc54
    // 0xccdc4c: r3 = Instance_Offset
    //     0xccdc4c: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xccdc50: r0 = paintChild()
    //     0xccdc50: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xccdc54: r0 = Null
    //     0xccdc54: mov             x0, NULL
    // 0xccdc58: LeaveFrame
    //     0xccdc58: mov             SP, fp
    //     0xccdc5c: ldp             fp, lr, [SP], #0x10
    // 0xccdc60: ret
    //     0xccdc60: ret             
    // 0xccdc64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccdc64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccdc68: b               #0xccdc3c
  }
  get _ constraints(/* No info */) {
    // ** addr: 0xcceaa4, size: 0x50
    // 0xcceaa4: EnterFrame
    //     0xcceaa4: stp             fp, lr, [SP, #-0x10]!
    //     0xcceaa8: mov             fp, SP
    // 0xcceaac: LoadField: r0 = r1->field_4f
    //     0xcceaac: ldur            w0, [x1, #0x4f]
    // 0xcceab0: DecompressPointer r0
    //     0xcceab0: add             x0, x0, HEAP, lsl #32
    // 0xcceab4: cmp             w0, NULL
    // 0xcceab8: b.eq            #0xccead4
    // 0xcceabc: LoadField: r1 = r0->field_7
    //     0xcceabc: ldur            w1, [x0, #7]
    // 0xcceac0: DecompressPointer r1
    //     0xcceac0: add             x1, x1, HEAP, lsl #32
    // 0xcceac4: mov             x0, x1
    // 0xcceac8: LeaveFrame
    //     0xcceac8: mov             SP, fp
    //     0xcceacc: ldp             fp, lr, [SP], #0x10
    // 0xccead0: ret
    //     0xccead0: ret             
    // 0xccead4: r0 = StateError()
    //     0xccead4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccead8: mov             x1, x0
    // 0xcceadc: r0 = "Constraints are not available because RenderView has not been given a configuration yet."
    //     0xcceadc: add             x0, PP, #0xd, lsl #12  ; [pp+0xded8] "Constraints are not available because RenderView has not been given a configuration yet."
    //     0xcceae0: ldr             x0, [x0, #0xed8]
    // 0xcceae4: StoreField: r1->field_b = r0
    //     0xcceae4: stur            w0, [x1, #0xb]
    // 0xcceae8: mov             x0, x1
    // 0xcceaec: r0 = Throw()
    //     0xcceaec: bl              #0x13ddb2c  ; ThrowStub
    // 0xcceaf0: brk             #0
  }
  _ RenderView(/* No info */) {
    // ** addr: 0x13e5edc, size: 0x84
    // 0x13e5edc: EnterFrame
    //     0x13e5edc: stp             fp, lr, [SP, #-0x10]!
    //     0x13e5ee0: mov             fp, SP
    // 0x13e5ee4: AllocStack(0x8)
    //     0x13e5ee4: sub             SP, SP, #8
    // 0x13e5ee8: r3 = Instance_Size
    //     0x13e5ee8: ldr             x3, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0x13e5eec: r0 = true
    //     0x13e5eec: add             x0, NULL, #0x20  ; true
    // 0x13e5ef0: stur            x1, [fp, #-8]
    // 0x13e5ef4: mov             x16, x2
    // 0x13e5ef8: mov             x2, x1
    // 0x13e5efc: mov             x1, x16
    // 0x13e5f00: CheckStackOverflow
    //     0x13e5f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e5f04: cmp             SP, x16
    //     0x13e5f08: b.ls            #0x13e5f58
    // 0x13e5f0c: StoreField: r2->field_4b = r3
    //     0x13e5f0c: stur            w3, [x2, #0x4b]
    // 0x13e5f10: StoreField: r2->field_57 = r0
    //     0x13e5f10: stur            w0, [x2, #0x57]
    // 0x13e5f14: mov             x0, x1
    // 0x13e5f18: StoreField: r2->field_53 = r0
    //     0x13e5f18: stur            w0, [x2, #0x53]
    //     0x13e5f1c: ldurb           w16, [x2, #-1]
    //     0x13e5f20: ldurb           w17, [x0, #-1]
    //     0x13e5f24: and             x16, x17, x16, lsr #2
    //     0x13e5f28: tst             x16, HEAP, lsr #32
    //     0x13e5f2c: b.eq            #0x13e5f34
    //     0x13e5f30: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x13e5f34: mov             x1, x2
    // 0x13e5f38: r0 = RenderObject()
    //     0x13e5f38: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x13e5f3c: ldur            x1, [fp, #-8]
    // 0x13e5f40: r2 = Null
    //     0x13e5f40: mov             x2, NULL
    // 0x13e5f44: r0 = child=()
    //     0x13e5f44: bl              #0xaef6c4  ; [dart:mixin_deduplication] _MixinApplication423&RenderObject&RenderObjectWithChildMixin::child=
    // 0x13e5f48: r0 = Null
    //     0x13e5f48: mov             x0, NULL
    // 0x13e5f4c: LeaveFrame
    //     0x13e5f4c: mov             SP, fp
    //     0x13e5f50: ldp             fp, lr, [SP], #0x10
    // 0x13e5f54: ret
    //     0x13e5f54: ret             
    // 0x13e5f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e5f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e5f5c: b               #0x13e5f0c
  }
  _ updateSemantics(/* No info */) {
    // ** addr: 0x13e6100, size: 0x84
    // 0x13e6100: EnterFrame
    //     0x13e6100: stp             fp, lr, [SP, #-0x10]!
    //     0x13e6104: mov             fp, SP
    // 0x13e6108: AllocStack(0x18)
    //     0x13e6108: sub             SP, SP, #0x18
    // 0x13e610c: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x13e610c: stur            x2, [fp, #-0x18]
    // 0x13e6110: CheckStackOverflow
    //     0x13e6110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x13e6114: cmp             SP, x16
    //     0x13e6118: b.ls            #0x13e6178
    // 0x13e611c: LoadField: r0 = r1->field_53
    //     0x13e611c: ldur            w0, [x1, #0x53]
    // 0x13e6120: DecompressPointer r0
    //     0x13e6120: add             x0, x0, HEAP, lsl #32
    // 0x13e6124: LoadField: r3 = r0->field_7
    //     0x13e6124: ldur            x3, [x0, #7]
    // 0x13e6128: stur            x3, [fp, #-0x10]
    // 0x13e612c: LoadField: r0 = r2->field_7
    //     0x13e612c: ldur            w0, [x2, #7]
    // 0x13e6130: DecompressPointer r0
    //     0x13e6130: add             x0, x0, HEAP, lsl #32
    // 0x13e6134: cmp             w0, NULL
    // 0x13e6138: b.eq            #0x13e6180
    // 0x13e613c: LoadField: r1 = r0->field_7
    //     0x13e613c: ldur            x1, [x0, #7]
    // 0x13e6140: ldr             x0, [x1]
    // 0x13e6144: stur            x0, [fp, #-8]
    // 0x13e6148: r1 = <Never>
    //     0x13e6148: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x13e614c: r0 = Pointer()
    //     0x13e614c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x13e6150: mov             x1, x0
    // 0x13e6154: ldur            x0, [fp, #-8]
    // 0x13e6158: StoreField: r1->field_7 = r0
    //     0x13e6158: stur            x0, [x1, #7]
    // 0x13e615c: mov             x2, x1
    // 0x13e6160: ldur            x1, [fp, #-0x10]
    // 0x13e6164: r0 = __updateSemantics$Method$FfiNative()
    //     0x13e6164: bl              #0x13e6184  ; [dart:ui] FlutterView::__updateSemantics$Method$FfiNative
    // 0x13e6168: r0 = Null
    //     0x13e6168: mov             x0, NULL
    // 0x13e616c: LeaveFrame
    //     0x13e616c: mov             SP, fp
    //     0x13e6170: ldp             fp, lr, [SP], #0x10
    // 0x13e6174: ret
    //     0x13e6174: ret             
    // 0x13e6178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x13e6178: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x13e617c: b               #0x13e611c
    // 0x13e6180: r0 = NullErrorSharedWithoutFPURegs()
    //     0x13e6180: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
}
