// lib: , url: package:flutter/src/rendering/sliver_padding.dart

// class id: 1049048, size: 0x8
class :: {
}

// class id: 4690, size: 0x50, field offset: 0x50
abstract class RenderSliverEdgeInsetsPadding extends _MixinApplication235&RenderSliver&RenderObjectWithChildMixin {

  _ performLayout(/* No info */) {
    // ** addr: 0xbea570, size: 0x7d4
    // 0xbea570: EnterFrame
    //     0xbea570: stp             fp, lr, [SP, #-0x10]!
    //     0xbea574: mov             fp, SP
    // 0xbea578: AllocStack(0x80)
    //     0xbea578: sub             SP, SP, #0x80
    // 0xbea57c: SetupParameters(RenderSliverEdgeInsetsPadding this /* r1 => r3, fp-0x10 */)
    //     0xbea57c: mov             x3, x1
    //     0xbea580: stur            x1, [fp, #-0x10]
    // 0xbea584: CheckStackOverflow
    //     0xbea584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbea588: cmp             SP, x16
    //     0xbea58c: b.ls            #0xbead24
    // 0xbea590: LoadField: r4 = r3->field_27
    //     0xbea590: ldur            w4, [x3, #0x27]
    // 0xbea594: DecompressPointer r4
    //     0xbea594: add             x4, x4, HEAP, lsl #32
    // 0xbea598: stur            x4, [fp, #-8]
    // 0xbea59c: cmp             w4, NULL
    // 0xbea5a0: b.eq            #0xbead08
    // 0xbea5a4: mov             x0, x4
    // 0xbea5a8: r2 = Null
    //     0xbea5a8: mov             x2, NULL
    // 0xbea5ac: r1 = Null
    //     0xbea5ac: mov             x1, NULL
    // 0xbea5b0: r4 = LoadClassIdInstr(r0)
    //     0xbea5b0: ldur            x4, [x0, #-1]
    //     0xbea5b4: ubfx            x4, x4, #0xc, #0x14
    // 0xbea5b8: cmp             x4, #0xb45
    // 0xbea5bc: b.eq            #0xbea5d4
    // 0xbea5c0: r8 = SliverConstraints
    //     0xbea5c0: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbea5c4: ldr             x8, [x8, #0x3c0]
    // 0xbea5c8: r3 = Null
    //     0xbea5c8: add             x3, PP, #0x96, lsl #12  ; [pp+0x96508] Null
    //     0xbea5cc: ldr             x3, [x3, #0x508]
    // 0xbea5d0: r0 = DefaultTypeTest()
    //     0xbea5d0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbea5d4: ldur            x0, [fp, #-0x10]
    // 0xbea5d8: r1 = LoadClassIdInstr(r0)
    //     0xbea5d8: ldur            x1, [x0, #-1]
    //     0xbea5dc: ubfx            x1, x1, #0xc, #0x14
    // 0xbea5e0: r17 = 4691
    //     0xbea5e0: mov             x17, #0x1253
    // 0xbea5e4: cmp             x1, x17
    // 0xbea5e8: b.ne            #0xbea5fc
    // 0xbea5ec: LoadField: r1 = r0->field_5b
    //     0xbea5ec: ldur            w1, [x0, #0x5b]
    // 0xbea5f0: DecompressPointer r1
    //     0xbea5f0: add             x1, x1, HEAP, lsl #32
    // 0xbea5f4: mov             x2, x1
    // 0xbea5f8: b               #0xbea608
    // 0xbea5fc: LoadField: r1 = r0->field_4f
    //     0xbea5fc: ldur            w1, [x0, #0x4f]
    // 0xbea600: DecompressPointer r1
    //     0xbea600: add             x1, x1, HEAP, lsl #32
    // 0xbea604: mov             x2, x1
    // 0xbea608: stur            x2, [fp, #-0x18]
    // 0xbea60c: cmp             w2, NULL
    // 0xbea610: b.eq            #0xbead2c
    // 0xbea614: mov             x1, x0
    // 0xbea618: r0 = beforePadding()
    //     0xbea618: bl              #0xbeb234  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::beforePadding
    // 0xbea61c: ldur            x1, [fp, #-0x10]
    // 0xbea620: stur            d0, [fp, #-0x30]
    // 0xbea624: r0 = afterPadding()
    //     0xbea624: bl              #0xbeb054  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::afterPadding
    // 0xbea628: ldur            x1, [fp, #-0x10]
    // 0xbea62c: r0 = mainAxisPadding()
    //     0xbea62c: bl              #0xbeaf34  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::mainAxisPadding
    // 0xbea630: ldur            x1, [fp, #-0x10]
    // 0xbea634: stur            d0, [fp, #-0x38]
    // 0xbea638: r0 = crossAxisPadding()
    //     0xbea638: bl              #0xbeae10  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::crossAxisPadding
    // 0xbea63c: mov             v2.16b, v0.16b
    // 0xbea640: ldur            x0, [fp, #-0x10]
    // 0xbea644: stur            d2, [fp, #-0x50]
    // 0xbea648: LoadField: r1 = r0->field_4b
    //     0xbea648: ldur            w1, [x0, #0x4b]
    // 0xbea64c: DecompressPointer r1
    //     0xbea64c: add             x1, x1, HEAP, lsl #32
    // 0xbea650: cmp             w1, NULL
    // 0xbea654: b.ne            #0xbea794
    // 0xbea658: ldur            x3, [fp, #-8]
    // 0xbea65c: mov             x1, x0
    // 0xbea660: mov             x2, x3
    // 0xbea664: ldur            d1, [fp, #-0x38]
    // 0xbea668: d0 = 0.000000
    //     0xbea668: eor             v0.16b, v0.16b, v0.16b
    // 0xbea66c: r0 = calculatePaintOffset()
    //     0xbea66c: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbea670: ldur            x1, [fp, #-0x10]
    // 0xbea674: ldur            x2, [fp, #-8]
    // 0xbea678: ldur            d1, [fp, #-0x38]
    // 0xbea67c: mov             v2.16b, v0.16b
    // 0xbea680: d0 = 0.000000
    //     0xbea680: eor             v0.16b, v0.16b, v0.16b
    // 0xbea684: stur            d2, [fp, #-0x40]
    // 0xbea688: r0 = calculateCacheOffset()
    //     0xbea688: bl              #0xbe4790  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0xbea68c: ldur            x0, [fp, #-8]
    // 0xbea690: stur            d0, [fp, #-0x48]
    // 0xbea694: LoadField: d1 = r0->field_2b
    //     0xbea694: ldur            d1, [x0, #0x2b]
    // 0xbea698: ldur            d2, [fp, #-0x40]
    // 0xbea69c: fcmp            d2, d1
    // 0xbea6a0: b.le            #0xbea6b0
    // 0xbea6a4: mov             v2.16b, v1.16b
    // 0xbea6a8: d3 = 0.000000
    //     0xbea6a8: eor             v3.16b, v3.16b, v3.16b
    // 0xbea6ac: b               #0xbea708
    // 0xbea6b0: fcmp            d1, d2
    // 0xbea6b4: b.le            #0xbea6c0
    // 0xbea6b8: d3 = 0.000000
    //     0xbea6b8: eor             v3.16b, v3.16b, v3.16b
    // 0xbea6bc: b               #0xbea708
    // 0xbea6c0: d3 = 0.000000
    //     0xbea6c0: eor             v3.16b, v3.16b, v3.16b
    // 0xbea6c4: fcmp            d2, d3
    // 0xbea6c8: b.ne            #0xbea6dc
    // 0xbea6cc: fadd            d4, d2, d1
    // 0xbea6d0: fmul            d5, d4, d2
    // 0xbea6d4: fmul            d2, d5, d1
    // 0xbea6d8: b               #0xbea708
    // 0xbea6dc: fcmp            d2, d3
    // 0xbea6e0: b.ne            #0xbea6fc
    // 0xbea6e4: fcmp            d1, #0.0
    // 0xbea6e8: b.vs            #0xbea6fc
    // 0xbea6ec: b.ne            #0xbea6f8
    // 0xbea6f0: r0 = 0.000000
    //     0xbea6f0: fmov            x0, d1
    // 0xbea6f4: cmp             x0, #0
    // 0xbea6f8: b.lt            #0xbea704
    // 0xbea6fc: fcmp            d1, d1
    // 0xbea700: b.vc            #0xbea708
    // 0xbea704: mov             v2.16b, v1.16b
    // 0xbea708: ldur            x1, [fp, #-0x10]
    // 0xbea70c: ldur            d1, [fp, #-0x38]
    // 0xbea710: stur            d2, [fp, #-0x40]
    // 0xbea714: r0 = SliverGeometry()
    //     0xbea714: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbea718: ldur            d3, [fp, #-0x38]
    // 0xbea71c: StoreField: r0->field_7 = d3
    //     0xbea71c: stur            d3, [x0, #7]
    // 0xbea720: ldur            d0, [fp, #-0x40]
    // 0xbea724: ArrayStore: r0[0] = d0  ; List_8
    //     0xbea724: stur            d0, [x0, #0x17]
    // 0xbea728: StoreField: r0->field_f = rZR
    //     0xbea728: stur            xzr, [x0, #0xf]
    // 0xbea72c: StoreField: r0->field_27 = d3
    //     0xbea72c: stur            d3, [x0, #0x27]
    // 0xbea730: StoreField: r0->field_2f = rZR
    //     0xbea730: stur            xzr, [x0, #0x2f]
    // 0xbea734: r3 = false
    //     0xbea734: add             x3, NULL, #0x30  ; false
    // 0xbea738: StoreField: r0->field_43 = r3
    //     0xbea738: stur            w3, [x0, #0x43]
    // 0xbea73c: StoreField: r0->field_1f = d0
    //     0xbea73c: stur            d0, [x0, #0x1f]
    // 0xbea740: StoreField: r0->field_37 = d0
    //     0xbea740: stur            d0, [x0, #0x37]
    // 0xbea744: ldur            d1, [fp, #-0x48]
    // 0xbea748: StoreField: r0->field_4b = d1
    //     0xbea748: stur            d1, [x0, #0x4b]
    // 0xbea74c: d4 = 0.000000
    //     0xbea74c: eor             v4.16b, v4.16b, v4.16b
    // 0xbea750: fcmp            d0, d4
    // 0xbea754: r16 = true
    //     0xbea754: add             x16, NULL, #0x20  ; true
    // 0xbea758: r17 = false
    //     0xbea758: add             x17, NULL, #0x30  ; false
    // 0xbea75c: csel            x1, x16, x17, gt
    // 0xbea760: StoreField: r0->field_3f = r1
    //     0xbea760: stur            w1, [x0, #0x3f]
    // 0xbea764: ldur            x4, [fp, #-0x10]
    // 0xbea768: StoreField: r4->field_47 = r0
    //     0xbea768: stur            w0, [x4, #0x47]
    //     0xbea76c: ldurb           w16, [x4, #-1]
    //     0xbea770: ldurb           w17, [x0, #-1]
    //     0xbea774: and             x16, x17, x16, lsr #2
    //     0xbea778: tst             x16, HEAP, lsr #32
    //     0xbea77c: b.eq            #0xbea784
    //     0xbea780: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbea784: r0 = Null
    //     0xbea784: mov             x0, NULL
    // 0xbea788: LeaveFrame
    //     0xbea788: mov             SP, fp
    //     0xbea78c: ldp             fp, lr, [SP], #0x10
    // 0xbea790: ret
    //     0xbea790: ret             
    // 0xbea794: mov             x4, x0
    // 0xbea798: ldur            d3, [fp, #-0x38]
    // 0xbea79c: ldur            x0, [fp, #-8]
    // 0xbea7a0: r3 = false
    //     0xbea7a0: add             x3, NULL, #0x30  ; false
    // 0xbea7a4: d4 = 0.000000
    //     0xbea7a4: eor             v4.16b, v4.16b, v4.16b
    // 0xbea7a8: mov             x1, x4
    // 0xbea7ac: mov             x2, x0
    // 0xbea7b0: mov             v0.16b, v4.16b
    // 0xbea7b4: ldur            d1, [fp, #-0x30]
    // 0xbea7b8: r0 = calculatePaintOffset()
    //     0xbea7b8: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbea7bc: mov             v2.16b, v0.16b
    // 0xbea7c0: ldur            x0, [fp, #-8]
    // 0xbea7c4: stur            d2, [fp, #-0x68]
    // 0xbea7c8: LoadField: d0 = r0->field_23
    //     0xbea7c8: ldur            d0, [x0, #0x23]
    // 0xbea7cc: d3 = 0.000000
    //     0xbea7cc: eor             v3.16b, v3.16b, v3.16b
    // 0xbea7d0: fcmp            d0, d3
    // 0xbea7d4: b.le            #0xbea7e8
    // 0xbea7d8: fsub            d1, d0, d2
    // 0xbea7dc: fmax            v0.2d, v3.2d, v1.2d
    // 0xbea7e0: mov             v6.16b, v0.16b
    // 0xbea7e4: b               #0xbea7ec
    // 0xbea7e8: mov             v6.16b, v0.16b
    // 0xbea7ec: ldur            x3, [fp, #-0x10]
    // 0xbea7f0: ldur            d5, [fp, #-0x30]
    // 0xbea7f4: ldur            d4, [fp, #-0x50]
    // 0xbea7f8: stur            d6, [fp, #-0x60]
    // 0xbea7fc: LoadField: r4 = r3->field_4b
    //     0xbea7fc: ldur            w4, [x3, #0x4b]
    // 0xbea800: DecompressPointer r4
    //     0xbea800: add             x4, x4, HEAP, lsl #32
    // 0xbea804: stur            x4, [fp, #-0x20]
    // 0xbea808: cmp             w4, NULL
    // 0xbea80c: b.eq            #0xbead30
    // 0xbea810: LoadField: d0 = r0->field_13
    //     0xbea810: ldur            d0, [x0, #0x13]
    // 0xbea814: fsub            d1, d0, d5
    // 0xbea818: fmax            v7.2d, v3.2d, v1.2d
    // 0xbea81c: stur            d7, [fp, #-0x58]
    // 0xbea820: LoadField: d0 = r0->field_47
    //     0xbea820: ldur            d0, [x0, #0x47]
    // 0xbea824: fadd            d1, d0, d5
    // 0xbea828: fmin            v8.2d, v3.2d, v1.2d
    // 0xbea82c: stur            d8, [fp, #-0x48]
    // 0xbea830: LoadField: d9 = r0->field_2b
    //     0xbea830: ldur            d9, [x0, #0x2b]
    // 0xbea834: mov             x1, x3
    // 0xbea838: mov             x2, x0
    // 0xbea83c: mov             v0.16b, v3.16b
    // 0xbea840: mov             v1.16b, v5.16b
    // 0xbea844: stur            d9, [fp, #-0x40]
    // 0xbea848: r0 = calculatePaintOffset()
    //     0xbea848: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbea84c: ldur            d2, [fp, #-0x40]
    // 0xbea850: fsub            d5, d2, d0
    // 0xbea854: ldur            x0, [fp, #-8]
    // 0xbea858: stur            d5, [fp, #-0x78]
    // 0xbea85c: LoadField: d3 = r0->field_4f
    //     0xbea85c: ldur            d3, [x0, #0x4f]
    // 0xbea860: ldur            x1, [fp, #-0x10]
    // 0xbea864: mov             x2, x0
    // 0xbea868: ldur            d1, [fp, #-0x30]
    // 0xbea86c: stur            d3, [fp, #-0x70]
    // 0xbea870: d0 = 0.000000
    //     0xbea870: eor             v0.16b, v0.16b, v0.16b
    // 0xbea874: r0 = calculateCacheOffset()
    //     0xbea874: bl              #0xbe4790  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0xbea878: ldur            d6, [fp, #-0x70]
    // 0xbea87c: fsub            d4, d6, d0
    // 0xbea880: ldur            x0, [fp, #-8]
    // 0xbea884: LoadField: d0 = r0->field_33
    //     0xbea884: ldur            d0, [x0, #0x33]
    // 0xbea888: ldur            d1, [fp, #-0x50]
    // 0xbea88c: fsub            d2, d0, d1
    // 0xbea890: d7 = 0.000000
    //     0xbea890: eor             v7.16b, v7.16b, v7.16b
    // 0xbea894: fmax            v1.2d, v7.2d, v2.2d
    // 0xbea898: LoadField: d0 = r0->field_1b
    //     0xbea898: ldur            d0, [x0, #0x1b]
    // 0xbea89c: ldur            d8, [fp, #-0x30]
    // 0xbea8a0: fadd            d3, d8, d0
    // 0xbea8a4: ldur            d0, [fp, #-0x58]
    // 0xbea8a8: str             d0, [SP]
    // 0xbea8ac: mov             x1, x0
    // 0xbea8b0: ldur            d0, [fp, #-0x48]
    // 0xbea8b4: ldur            d2, [fp, #-0x60]
    // 0xbea8b8: ldur            d5, [fp, #-0x78]
    // 0xbea8bc: r0 = copyWith()
    //     0xbea8bc: bl              #0xbead44  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::copyWith
    // 0xbea8c0: r16 = true
    //     0xbea8c0: add             x16, NULL, #0x20  ; true
    // 0xbea8c4: str             x16, [SP]
    // 0xbea8c8: ldur            x1, [fp, #-0x20]
    // 0xbea8cc: mov             x2, x0
    // 0xbea8d0: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbea8d0: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbea8d4: ldr             x4, [x4, #0xed0]
    // 0xbea8d8: r0 = layout()
    //     0xbea8d8: bl              #0xcd00ac  ; [package:flutter/src/rendering/object.dart] RenderObject::layout
    // 0xbea8dc: ldur            x1, [fp, #-0x10]
    // 0xbea8e0: LoadField: r0 = r1->field_4b
    //     0xbea8e0: ldur            w0, [x1, #0x4b]
    // 0xbea8e4: DecompressPointer r0
    //     0xbea8e4: add             x0, x0, HEAP, lsl #32
    // 0xbea8e8: cmp             w0, NULL
    // 0xbea8ec: b.eq            #0xbead34
    // 0xbea8f0: LoadField: r3 = r0->field_47
    //     0xbea8f0: ldur            w3, [x0, #0x47]
    // 0xbea8f4: DecompressPointer r3
    //     0xbea8f4: add             x3, x3, HEAP, lsl #32
    // 0xbea8f8: stur            x3, [fp, #-0x28]
    // 0xbea8fc: cmp             w3, NULL
    // 0xbea900: b.eq            #0xbead38
    // 0xbea904: LoadField: r0 = r3->field_47
    //     0xbea904: ldur            w0, [x3, #0x47]
    // 0xbea908: DecompressPointer r0
    //     0xbea908: add             x0, x0, HEAP, lsl #32
    // 0xbea90c: stur            x0, [fp, #-0x20]
    // 0xbea910: cmp             w0, NULL
    // 0xbea914: b.eq            #0xbea994
    // 0xbea918: r0 = SliverGeometry()
    //     0xbea918: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbea91c: StoreField: r0->field_7 = rZR
    //     0xbea91c: stur            xzr, [x0, #7]
    // 0xbea920: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbea920: stur            xzr, [x0, #0x17]
    // 0xbea924: StoreField: r0->field_f = rZR
    //     0xbea924: stur            xzr, [x0, #0xf]
    // 0xbea928: StoreField: r0->field_27 = rZR
    //     0xbea928: stur            xzr, [x0, #0x27]
    // 0xbea92c: StoreField: r0->field_2f = rZR
    //     0xbea92c: stur            xzr, [x0, #0x2f]
    // 0xbea930: r1 = false
    //     0xbea930: add             x1, NULL, #0x30  ; false
    // 0xbea934: StoreField: r0->field_43 = r1
    //     0xbea934: stur            w1, [x0, #0x43]
    // 0xbea938: ldur            x1, [fp, #-0x20]
    // 0xbea93c: StoreField: r0->field_47 = r1
    //     0xbea93c: stur            w1, [x0, #0x47]
    // 0xbea940: StoreField: r0->field_1f = rZR
    //     0xbea940: stur            xzr, [x0, #0x1f]
    // 0xbea944: StoreField: r0->field_37 = rZR
    //     0xbea944: stur            xzr, [x0, #0x37]
    // 0xbea948: StoreField: r0->field_4b = rZR
    //     0xbea948: stur            xzr, [x0, #0x4b]
    // 0xbea94c: d2 = 0.000000
    //     0xbea94c: eor             v2.16b, v2.16b, v2.16b
    // 0xbea950: fcmp            d2, d2
    // 0xbea954: r16 = true
    //     0xbea954: add             x16, NULL, #0x20  ; true
    // 0xbea958: r17 = false
    //     0xbea958: add             x17, NULL, #0x30  ; false
    // 0xbea95c: csel            x1, x16, x17, gt
    // 0xbea960: StoreField: r0->field_3f = r1
    //     0xbea960: stur            w1, [x0, #0x3f]
    // 0xbea964: ldur            x4, [fp, #-0x10]
    // 0xbea968: StoreField: r4->field_47 = r0
    //     0xbea968: stur            w0, [x4, #0x47]
    //     0xbea96c: ldurb           w16, [x4, #-1]
    //     0xbea970: ldurb           w17, [x0, #-1]
    //     0xbea974: and             x16, x17, x16, lsr #2
    //     0xbea978: tst             x16, HEAP, lsr #32
    //     0xbea97c: b.eq            #0xbea984
    //     0xbea980: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbea984: r0 = Null
    //     0xbea984: mov             x0, NULL
    // 0xbea988: LeaveFrame
    //     0xbea988: mov             SP, fp
    //     0xbea98c: ldp             fp, lr, [SP], #0x10
    // 0xbea990: ret
    //     0xbea990: ret             
    // 0xbea994: mov             x4, x1
    // 0xbea998: ldur            d4, [fp, #-0x30]
    // 0xbea99c: ldur            d7, [fp, #-0x38]
    // 0xbea9a0: ldur            d5, [fp, #-0x40]
    // 0xbea9a4: ldur            d3, [fp, #-0x70]
    // 0xbea9a8: ldur            d6, [fp, #-0x68]
    // 0xbea9ac: ldur            x0, [fp, #-8]
    // 0xbea9b0: d2 = 0.000000
    //     0xbea9b0: eor             v2.16b, v2.16b, v2.16b
    // 0xbea9b4: LoadField: d8 = r3->field_7
    //     0xbea9b4: ldur            d8, [x3, #7]
    // 0xbea9b8: mov             x1, x4
    // 0xbea9bc: mov             x2, x0
    // 0xbea9c0: mov             v0.16b, v2.16b
    // 0xbea9c4: mov             v1.16b, v4.16b
    // 0xbea9c8: stur            d8, [fp, #-0x48]
    // 0xbea9cc: r0 = calculateCacheOffset()
    //     0xbea9cc: bl              #0xbe4790  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0xbea9d0: mov             v3.16b, v0.16b
    // 0xbea9d4: ldur            d0, [fp, #-0x30]
    // 0xbea9d8: ldur            d2, [fp, #-0x48]
    // 0xbea9dc: stur            d3, [fp, #-0x58]
    // 0xbea9e0: fadd            d4, d0, d2
    // 0xbea9e4: ldur            d5, [fp, #-0x38]
    // 0xbea9e8: stur            d4, [fp, #-0x50]
    // 0xbea9ec: fadd            d6, d5, d2
    // 0xbea9f0: ldur            x1, [fp, #-0x10]
    // 0xbea9f4: ldur            x2, [fp, #-8]
    // 0xbea9f8: mov             v0.16b, v4.16b
    // 0xbea9fc: mov             v1.16b, v6.16b
    // 0xbeaa00: stur            d6, [fp, #-0x30]
    // 0xbeaa04: r0 = calculateCacheOffset()
    //     0xbeaa04: bl              #0xbe4790  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0xbeaa08: ldur            x1, [fp, #-0x10]
    // 0xbeaa0c: ldur            x2, [fp, #-8]
    // 0xbeaa10: mov             v2.16b, v0.16b
    // 0xbeaa14: ldur            d0, [fp, #-0x50]
    // 0xbeaa18: ldur            d1, [fp, #-0x30]
    // 0xbeaa1c: stur            d2, [fp, #-0x50]
    // 0xbeaa20: r0 = calculatePaintOffset()
    //     0xbeaa20: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbeaa24: mov             v2.16b, v0.16b
    // 0xbeaa28: ldur            d1, [fp, #-0x58]
    // 0xbeaa2c: ldur            d0, [fp, #-0x50]
    // 0xbeaa30: fadd            d3, d1, d0
    // 0xbeaa34: ldur            d0, [fp, #-0x68]
    // 0xbeaa38: fadd            d1, d0, d2
    // 0xbeaa3c: ldur            x0, [fp, #-0x28]
    // 0xbeaa40: ArrayLoad: d4 = r0[0]  ; List_8
    //     0xbeaa40: ldur            d4, [x0, #0x17]
    // 0xbeaa44: LoadField: d5 = r0->field_1f
    //     0xbeaa44: ldur            d5, [x0, #0x1f]
    // 0xbeaa48: fadd            d6, d5, d2
    // 0xbeaa4c: fmax            v2.2d, v4.2d, v6.2d
    // 0xbeaa50: fadd            d6, d0, d2
    // 0xbeaa54: ldur            d2, [fp, #-0x40]
    // 0xbeaa58: fmin            v7.2d, v6.2d, v2.2d
    // 0xbeaa5c: stur            d7, [fp, #-0x60]
    // 0xbeaa60: fadd            d2, d1, d5
    // 0xbeaa64: fmin            v5.2d, v2.2d, v7.2d
    // 0xbeaa68: stur            d5, [fp, #-0x58]
    // 0xbeaa6c: LoadField: d2 = r0->field_4b
    //     0xbeaa6c: ldur            d2, [x0, #0x4b]
    // 0xbeaa70: fadd            d6, d3, d2
    // 0xbeaa74: ldur            d2, [fp, #-0x70]
    // 0xbeaa78: fmin            v3.2d, v6.2d, v2.2d
    // 0xbeaa7c: stur            d3, [fp, #-0x50]
    // 0xbeaa80: LoadField: d2 = r0->field_27
    //     0xbeaa80: ldur            d2, [x0, #0x27]
    // 0xbeaa84: ldur            d6, [fp, #-0x38]
    // 0xbeaa88: fadd            d8, d6, d2
    // 0xbeaa8c: stur            d8, [fp, #-0x40]
    // 0xbeaa90: fadd            d2, d1, d4
    // 0xbeaa94: LoadField: d1 = r0->field_37
    //     0xbeaa94: ldur            d1, [x0, #0x37]
    // 0xbeaa98: fadd            d4, d0, d1
    // 0xbeaa9c: fmax            v0.2d, v2.2d, v4.2d
    // 0xbeaaa0: stur            d0, [fp, #-0x38]
    // 0xbeaaa4: LoadField: r1 = r0->field_43
    //     0xbeaaa4: ldur            w1, [x0, #0x43]
    // 0xbeaaa8: DecompressPointer r1
    //     0xbeaaa8: add             x1, x1, HEAP, lsl #32
    // 0xbeaaac: stur            x1, [fp, #-0x20]
    // 0xbeaab0: r0 = SliverGeometry()
    //     0xbeaab0: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbeaab4: ldur            d0, [fp, #-0x30]
    // 0xbeaab8: StoreField: r0->field_7 = d0
    //     0xbeaab8: stur            d0, [x0, #7]
    // 0xbeaabc: ldur            d0, [fp, #-0x60]
    // 0xbeaac0: ArrayStore: r0[0] = d0  ; List_8
    //     0xbeaac0: stur            d0, [x0, #0x17]
    // 0xbeaac4: StoreField: r0->field_f = rZR
    //     0xbeaac4: stur            xzr, [x0, #0xf]
    // 0xbeaac8: ldur            d1, [fp, #-0x40]
    // 0xbeaacc: StoreField: r0->field_27 = d1
    //     0xbeaacc: stur            d1, [x0, #0x27]
    // 0xbeaad0: StoreField: r0->field_2f = rZR
    //     0xbeaad0: stur            xzr, [x0, #0x2f]
    // 0xbeaad4: ldur            x1, [fp, #-0x20]
    // 0xbeaad8: StoreField: r0->field_43 = r1
    //     0xbeaad8: stur            w1, [x0, #0x43]
    // 0xbeaadc: ldur            d1, [fp, #-0x58]
    // 0xbeaae0: StoreField: r0->field_1f = d1
    //     0xbeaae0: stur            d1, [x0, #0x1f]
    // 0xbeaae4: ldur            d1, [fp, #-0x38]
    // 0xbeaae8: StoreField: r0->field_37 = d1
    //     0xbeaae8: stur            d1, [x0, #0x37]
    // 0xbeaaec: ldur            d1, [fp, #-0x50]
    // 0xbeaaf0: StoreField: r0->field_4b = d1
    //     0xbeaaf0: stur            d1, [x0, #0x4b]
    // 0xbeaaf4: d1 = 0.000000
    //     0xbeaaf4: eor             v1.16b, v1.16b, v1.16b
    // 0xbeaaf8: fcmp            d0, d1
    // 0xbeaafc: r16 = true
    //     0xbeaafc: add             x16, NULL, #0x20  ; true
    // 0xbeab00: r17 = false
    //     0xbeab00: add             x17, NULL, #0x30  ; false
    // 0xbeab04: csel            x1, x16, x17, gt
    // 0xbeab08: StoreField: r0->field_3f = r1
    //     0xbeab08: stur            w1, [x0, #0x3f]
    // 0xbeab0c: ldur            x3, [fp, #-0x10]
    // 0xbeab10: StoreField: r3->field_47 = r0
    //     0xbeab10: stur            w0, [x3, #0x47]
    //     0xbeab14: ldurb           w16, [x3, #-1]
    //     0xbeab18: ldurb           w17, [x0, #-1]
    //     0xbeab1c: and             x16, x17, x16, lsr #2
    //     0xbeab20: tst             x16, HEAP, lsr #32
    //     0xbeab24: b.eq            #0xbeab2c
    //     0xbeab28: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbeab2c: ldur            x0, [fp, #-8]
    // 0xbeab30: LoadField: r1 = r0->field_7
    //     0xbeab30: ldur            w1, [x0, #7]
    // 0xbeab34: DecompressPointer r1
    //     0xbeab34: add             x1, x1, HEAP, lsl #32
    // 0xbeab38: LoadField: r2 = r0->field_b
    //     0xbeab38: ldur            w2, [x0, #0xb]
    // 0xbeab3c: DecompressPointer r2
    //     0xbeab3c: add             x2, x2, HEAP, lsl #32
    // 0xbeab40: r0 = applyGrowthDirectionToAxisDirection()
    //     0xbeab40: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0xbeab44: LoadField: r1 = r0->field_7
    //     0xbeab44: ldur            x1, [x0, #7]
    // 0xbeab48: cmp             x1, #1
    // 0xbeab4c: b.gt            #0xbeabb4
    // 0xbeab50: cmp             x1, #0
    // 0xbeab54: b.gt            #0xbeab98
    // 0xbeab58: ldur            d0, [fp, #-0x48]
    // 0xbeab5c: ldur            x0, [fp, #-0x18]
    // 0xbeab60: LoadField: d1 = r0->field_1f
    //     0xbeab60: ldur            d1, [x0, #0x1f]
    // 0xbeab64: fadd            d2, d1, d0
    // 0xbeab68: mov             x1, x0
    // 0xbeab6c: stur            d2, [fp, #-0x30]
    // 0xbeab70: r0 = vertical()
    //     0xbeab70: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xbeab74: mov             v1.16b, v0.16b
    // 0xbeab78: ldur            d0, [fp, #-0x48]
    // 0xbeab7c: fadd            d2, d1, d0
    // 0xbeab80: ldur            x1, [fp, #-0x10]
    // 0xbeab84: ldur            x2, [fp, #-8]
    // 0xbeab88: ldur            d0, [fp, #-0x30]
    // 0xbeab8c: mov             v1.16b, v2.16b
    // 0xbeab90: r0 = calculatePaintOffset()
    //     0xbeab90: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbeab94: b               #0xbeac14
    // 0xbeab98: ldur            x0, [fp, #-0x18]
    // 0xbeab9c: LoadField: d1 = r0->field_7
    //     0xbeab9c: ldur            d1, [x0, #7]
    // 0xbeaba0: ldur            x1, [fp, #-0x10]
    // 0xbeaba4: ldur            x2, [fp, #-8]
    // 0xbeaba8: d0 = 0.000000
    //     0xbeaba8: eor             v0.16b, v0.16b, v0.16b
    // 0xbeabac: r0 = calculatePaintOffset()
    //     0xbeabac: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbeabb0: b               #0xbeac14
    // 0xbeabb4: ldur            d0, [fp, #-0x48]
    // 0xbeabb8: cmp             x1, #2
    // 0xbeabbc: b.gt            #0xbeabdc
    // 0xbeabc0: ldur            x0, [fp, #-0x18]
    // 0xbeabc4: LoadField: d1 = r0->field_f
    //     0xbeabc4: ldur            d1, [x0, #0xf]
    // 0xbeabc8: ldur            x1, [fp, #-0x10]
    // 0xbeabcc: ldur            x2, [fp, #-8]
    // 0xbeabd0: d0 = 0.000000
    //     0xbeabd0: eor             v0.16b, v0.16b, v0.16b
    // 0xbeabd4: r0 = calculatePaintOffset()
    //     0xbeabd4: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbeabd8: b               #0xbeac14
    // 0xbeabdc: ldur            x0, [fp, #-0x18]
    // 0xbeabe0: ArrayLoad: d1 = r0[0]  ; List_8
    //     0xbeabe0: ldur            d1, [x0, #0x17]
    // 0xbeabe4: fadd            d2, d1, d0
    // 0xbeabe8: mov             x1, x0
    // 0xbeabec: stur            d2, [fp, #-0x30]
    // 0xbeabf0: r0 = horizontal()
    //     0xbeabf0: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xbeabf4: mov             v1.16b, v0.16b
    // 0xbeabf8: ldur            d0, [fp, #-0x48]
    // 0xbeabfc: fadd            d2, d1, d0
    // 0xbeac00: ldur            x1, [fp, #-0x10]
    // 0xbeac04: ldur            x2, [fp, #-8]
    // 0xbeac08: ldur            d0, [fp, #-0x30]
    // 0xbeac0c: mov             v1.16b, v2.16b
    // 0xbeac10: r0 = calculatePaintOffset()
    //     0xbeac10: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbeac14: ldur            x0, [fp, #-0x10]
    // 0xbeac18: stur            d0, [fp, #-0x30]
    // 0xbeac1c: LoadField: r1 = r0->field_4b
    //     0xbeac1c: ldur            w1, [x0, #0x4b]
    // 0xbeac20: DecompressPointer r1
    //     0xbeac20: add             x1, x1, HEAP, lsl #32
    // 0xbeac24: cmp             w1, NULL
    // 0xbeac28: b.eq            #0xbead3c
    // 0xbeac2c: LoadField: r3 = r1->field_7
    //     0xbeac2c: ldur            w3, [x1, #7]
    // 0xbeac30: DecompressPointer r3
    //     0xbeac30: add             x3, x3, HEAP, lsl #32
    // 0xbeac34: stur            x3, [fp, #-0x10]
    // 0xbeac38: cmp             w3, NULL
    // 0xbeac3c: b.eq            #0xbead40
    // 0xbeac40: mov             x0, x3
    // 0xbeac44: r2 = Null
    //     0xbeac44: mov             x2, NULL
    // 0xbeac48: r1 = Null
    //     0xbeac48: mov             x1, NULL
    // 0xbeac4c: r4 = LoadClassIdInstr(r0)
    //     0xbeac4c: ldur            x4, [x0, #-1]
    //     0xbeac50: ubfx            x4, x4, #0xc, #0x14
    // 0xbeac54: r17 = -4177
    //     0xbeac54: mov             x17, #-0x1051
    // 0xbeac58: add             x4, x4, x17
    // 0xbeac5c: cmp             x4, #2
    // 0xbeac60: b.ls            #0xbeac78
    // 0xbeac64: r8 = SliverPhysicalParentData
    //     0xbeac64: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0xbeac68: ldr             x8, [x8, #0x240]
    // 0xbeac6c: r3 = Null
    //     0xbeac6c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96518] Null
    //     0xbeac70: ldr             x3, [x3, #0x518]
    // 0xbeac74: r0 = DefaultTypeTest()
    //     0xbeac74: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbeac78: ldur            x1, [fp, #-8]
    // 0xbeac7c: r0 = axis()
    //     0xbeac7c: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbeac80: LoadField: r1 = r0->field_7
    //     0xbeac80: ldur            x1, [x0, #7]
    // 0xbeac84: cmp             x1, #0
    // 0xbeac88: b.gt            #0xbeacb4
    // 0xbeac8c: ldur            d0, [fp, #-0x30]
    // 0xbeac90: ldur            x0, [fp, #-0x18]
    // 0xbeac94: LoadField: d1 = r0->field_f
    //     0xbeac94: ldur            d1, [x0, #0xf]
    // 0xbeac98: stur            d1, [fp, #-0x38]
    // 0xbeac9c: r0 = Offset()
    //     0xbeac9c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbeaca0: ldur            d0, [fp, #-0x30]
    // 0xbeaca4: StoreField: r0->field_7 = d0
    //     0xbeaca4: stur            d0, [x0, #7]
    // 0xbeaca8: ldur            d0, [fp, #-0x38]
    // 0xbeacac: StoreField: r0->field_f = d0
    //     0xbeacac: stur            d0, [x0, #0xf]
    // 0xbeacb0: b               #0xbeacd8
    // 0xbeacb4: ldur            d0, [fp, #-0x30]
    // 0xbeacb8: ldur            x0, [fp, #-0x18]
    // 0xbeacbc: LoadField: d1 = r0->field_7
    //     0xbeacbc: ldur            d1, [x0, #7]
    // 0xbeacc0: stur            d1, [fp, #-0x38]
    // 0xbeacc4: r0 = Offset()
    //     0xbeacc4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbeacc8: ldur            d0, [fp, #-0x38]
    // 0xbeaccc: StoreField: r0->field_7 = d0
    //     0xbeaccc: stur            d0, [x0, #7]
    // 0xbeacd0: ldur            d0, [fp, #-0x30]
    // 0xbeacd4: StoreField: r0->field_f = d0
    //     0xbeacd4: stur            d0, [x0, #0xf]
    // 0xbeacd8: ldur            x1, [fp, #-0x10]
    // 0xbeacdc: StoreField: r1->field_7 = r0
    //     0xbeacdc: stur            w0, [x1, #7]
    //     0xbeace0: ldurb           w16, [x1, #-1]
    //     0xbeace4: ldurb           w17, [x0, #-1]
    //     0xbeace8: and             x16, x17, x16, lsr #2
    //     0xbeacec: tst             x16, HEAP, lsr #32
    //     0xbeacf0: b.eq            #0xbeacf8
    //     0xbeacf4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbeacf8: r0 = Null
    //     0xbeacf8: mov             x0, NULL
    // 0xbeacfc: LeaveFrame
    //     0xbeacfc: mov             SP, fp
    //     0xbead00: ldp             fp, lr, [SP], #0x10
    // 0xbead04: ret
    //     0xbead04: ret             
    // 0xbead08: r0 = StateError()
    //     0xbead08: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbead0c: mov             x1, x0
    // 0xbead10: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbead10: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbead14: StoreField: r1->field_b = r0
    //     0xbead14: stur            w0, [x1, #0xb]
    // 0xbead18: mov             x0, x1
    // 0xbead1c: r0 = Throw()
    //     0xbead1c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbead20: brk             #0
    // 0xbead24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbead24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbead28: b               #0xbea590
    // 0xbead2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbead2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbead30: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbead30: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbead34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbead34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbead38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbead38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbead3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbead3c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbead40: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbead40: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ crossAxisPadding(/* No info */) {
    // ** addr: 0xbeae10, size: 0x124
    // 0xbeae10: EnterFrame
    //     0xbeae10: stp             fp, lr, [SP, #-0x10]!
    //     0xbeae14: mov             fp, SP
    // 0xbeae18: AllocStack(0x10)
    //     0xbeae18: sub             SP, SP, #0x10
    // 0xbeae1c: SetupParameters(RenderSliverEdgeInsetsPadding this /* r1 => r3, fp-0x10 */)
    //     0xbeae1c: mov             x3, x1
    //     0xbeae20: stur            x1, [fp, #-0x10]
    // 0xbeae24: CheckStackOverflow
    //     0xbeae24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeae28: cmp             SP, x16
    //     0xbeae2c: b.ls            #0xbeaf24
    // 0xbeae30: LoadField: r4 = r3->field_27
    //     0xbeae30: ldur            w4, [x3, #0x27]
    // 0xbeae34: DecompressPointer r4
    //     0xbeae34: add             x4, x4, HEAP, lsl #32
    // 0xbeae38: stur            x4, [fp, #-8]
    // 0xbeae3c: cmp             w4, NULL
    // 0xbeae40: b.eq            #0xbeaf08
    // 0xbeae44: mov             x0, x4
    // 0xbeae48: r2 = Null
    //     0xbeae48: mov             x2, NULL
    // 0xbeae4c: r1 = Null
    //     0xbeae4c: mov             x1, NULL
    // 0xbeae50: r4 = LoadClassIdInstr(r0)
    //     0xbeae50: ldur            x4, [x0, #-1]
    //     0xbeae54: ubfx            x4, x4, #0xc, #0x14
    // 0xbeae58: cmp             x4, #0xb45
    // 0xbeae5c: b.eq            #0xbeae74
    // 0xbeae60: r8 = SliverConstraints
    //     0xbeae60: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbeae64: ldr             x8, [x8, #0x3c0]
    // 0xbeae68: r3 = Null
    //     0xbeae68: add             x3, PP, #0x96, lsl #12  ; [pp+0x96528] Null
    //     0xbeae6c: ldr             x3, [x3, #0x528]
    // 0xbeae70: r0 = DefaultTypeTest()
    //     0xbeae70: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbeae74: ldur            x1, [fp, #-8]
    // 0xbeae78: r0 = axis()
    //     0xbeae78: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbeae7c: LoadField: r1 = r0->field_7
    //     0xbeae7c: ldur            x1, [x0, #7]
    // 0xbeae80: cmp             x1, #0
    // 0xbeae84: b.gt            #0xbeaec4
    // 0xbeae88: ldur            x0, [fp, #-0x10]
    // 0xbeae8c: r1 = LoadClassIdInstr(r0)
    //     0xbeae8c: ldur            x1, [x0, #-1]
    //     0xbeae90: ubfx            x1, x1, #0xc, #0x14
    // 0xbeae94: r17 = 4691
    //     0xbeae94: mov             x17, #0x1253
    // 0xbeae98: cmp             x1, x17
    // 0xbeae9c: b.ne            #0xbeaeac
    // 0xbeaea0: LoadField: r1 = r0->field_5b
    //     0xbeaea0: ldur            w1, [x0, #0x5b]
    // 0xbeaea4: DecompressPointer r1
    //     0xbeaea4: add             x1, x1, HEAP, lsl #32
    // 0xbeaea8: b               #0xbeaeb4
    // 0xbeaeac: LoadField: r1 = r0->field_4f
    //     0xbeaeac: ldur            w1, [x0, #0x4f]
    // 0xbeaeb0: DecompressPointer r1
    //     0xbeaeb0: add             x1, x1, HEAP, lsl #32
    // 0xbeaeb4: cmp             w1, NULL
    // 0xbeaeb8: b.eq            #0xbeaf2c
    // 0xbeaebc: r0 = vertical()
    //     0xbeaebc: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xbeaec0: b               #0xbeaefc
    // 0xbeaec4: ldur            x0, [fp, #-0x10]
    // 0xbeaec8: r1 = LoadClassIdInstr(r0)
    //     0xbeaec8: ldur            x1, [x0, #-1]
    //     0xbeaecc: ubfx            x1, x1, #0xc, #0x14
    // 0xbeaed0: r17 = 4691
    //     0xbeaed0: mov             x17, #0x1253
    // 0xbeaed4: cmp             x1, x17
    // 0xbeaed8: b.ne            #0xbeaee8
    // 0xbeaedc: LoadField: r1 = r0->field_5b
    //     0xbeaedc: ldur            w1, [x0, #0x5b]
    // 0xbeaee0: DecompressPointer r1
    //     0xbeaee0: add             x1, x1, HEAP, lsl #32
    // 0xbeaee4: b               #0xbeaef0
    // 0xbeaee8: LoadField: r1 = r0->field_4f
    //     0xbeaee8: ldur            w1, [x0, #0x4f]
    // 0xbeaeec: DecompressPointer r1
    //     0xbeaeec: add             x1, x1, HEAP, lsl #32
    // 0xbeaef0: cmp             w1, NULL
    // 0xbeaef4: b.eq            #0xbeaf30
    // 0xbeaef8: r0 = horizontal()
    //     0xbeaef8: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xbeaefc: LeaveFrame
    //     0xbeaefc: mov             SP, fp
    //     0xbeaf00: ldp             fp, lr, [SP], #0x10
    // 0xbeaf04: ret
    //     0xbeaf04: ret             
    // 0xbeaf08: r0 = StateError()
    //     0xbeaf08: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbeaf0c: mov             x1, x0
    // 0xbeaf10: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbeaf10: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbeaf14: StoreField: r1->field_b = r0
    //     0xbeaf14: stur            w0, [x1, #0xb]
    // 0xbeaf18: mov             x0, x1
    // 0xbeaf1c: r0 = Throw()
    //     0xbeaf1c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbeaf20: brk             #0
    // 0xbeaf24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeaf24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeaf28: b               #0xbeae30
    // 0xbeaf2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeaf2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeaf30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeaf30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ mainAxisPadding(/* No info */) {
    // ** addr: 0xbeaf34, size: 0xe0
    // 0xbeaf34: EnterFrame
    //     0xbeaf34: stp             fp, lr, [SP, #-0x10]!
    //     0xbeaf38: mov             fp, SP
    // 0xbeaf3c: AllocStack(0x10)
    //     0xbeaf3c: sub             SP, SP, #0x10
    // 0xbeaf40: CheckStackOverflow
    //     0xbeaf40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeaf44: cmp             SP, x16
    //     0xbeaf48: b.ls            #0xbeb008
    // 0xbeaf4c: r0 = LoadClassIdInstr(r1)
    //     0xbeaf4c: ldur            x0, [x1, #-1]
    //     0xbeaf50: ubfx            x0, x0, #0xc, #0x14
    // 0xbeaf54: r17 = 4691
    //     0xbeaf54: mov             x17, #0x1253
    // 0xbeaf58: cmp             x0, x17
    // 0xbeaf5c: b.ne            #0xbeaf70
    // 0xbeaf60: LoadField: r0 = r1->field_5b
    //     0xbeaf60: ldur            w0, [x1, #0x5b]
    // 0xbeaf64: DecompressPointer r0
    //     0xbeaf64: add             x0, x0, HEAP, lsl #32
    // 0xbeaf68: mov             x3, x0
    // 0xbeaf6c: b               #0xbeaf7c
    // 0xbeaf70: LoadField: r0 = r1->field_4f
    //     0xbeaf70: ldur            w0, [x1, #0x4f]
    // 0xbeaf74: DecompressPointer r0
    //     0xbeaf74: add             x0, x0, HEAP, lsl #32
    // 0xbeaf78: mov             x3, x0
    // 0xbeaf7c: stur            x3, [fp, #-0x10]
    // 0xbeaf80: cmp             w3, NULL
    // 0xbeaf84: b.eq            #0xbeb010
    // 0xbeaf88: LoadField: r4 = r1->field_27
    //     0xbeaf88: ldur            w4, [x1, #0x27]
    // 0xbeaf8c: DecompressPointer r4
    //     0xbeaf8c: add             x4, x4, HEAP, lsl #32
    // 0xbeaf90: stur            x4, [fp, #-8]
    // 0xbeaf94: cmp             w4, NULL
    // 0xbeaf98: b.eq            #0xbeafec
    // 0xbeaf9c: mov             x0, x4
    // 0xbeafa0: r2 = Null
    //     0xbeafa0: mov             x2, NULL
    // 0xbeafa4: r1 = Null
    //     0xbeafa4: mov             x1, NULL
    // 0xbeafa8: r4 = LoadClassIdInstr(r0)
    //     0xbeafa8: ldur            x4, [x0, #-1]
    //     0xbeafac: ubfx            x4, x4, #0xc, #0x14
    // 0xbeafb0: cmp             x4, #0xb45
    // 0xbeafb4: b.eq            #0xbeafcc
    // 0xbeafb8: r8 = SliverConstraints
    //     0xbeafb8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbeafbc: ldr             x8, [x8, #0x3c0]
    // 0xbeafc0: r3 = Null
    //     0xbeafc0: add             x3, PP, #0x96, lsl #12  ; [pp+0x96538] Null
    //     0xbeafc4: ldr             x3, [x3, #0x538]
    // 0xbeafc8: r0 = DefaultTypeTest()
    //     0xbeafc8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbeafcc: ldur            x1, [fp, #-8]
    // 0xbeafd0: r0 = axis()
    //     0xbeafd0: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbeafd4: ldur            x1, [fp, #-0x10]
    // 0xbeafd8: mov             x2, x0
    // 0xbeafdc: r0 = along()
    //     0xbeafdc: bl              #0xbeb014  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::along
    // 0xbeafe0: LeaveFrame
    //     0xbeafe0: mov             SP, fp
    //     0xbeafe4: ldp             fp, lr, [SP], #0x10
    // 0xbeafe8: ret
    //     0xbeafe8: ret             
    // 0xbeafec: r0 = StateError()
    //     0xbeafec: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbeaff0: mov             x1, x0
    // 0xbeaff4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbeaff4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbeaff8: StoreField: r1->field_b = r0
    //     0xbeaff8: stur            w0, [x1, #0xb]
    // 0xbeaffc: mov             x0, x1
    // 0xbeb000: r0 = Throw()
    //     0xbeb000: bl              #0x13ddb2c  ; ThrowStub
    // 0xbeb004: brk             #0
    // 0xbeb008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb00c: b               #0xbeaf4c
    // 0xbeb010: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb010: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ afterPadding(/* No info */) {
    // ** addr: 0xbeb054, size: 0x1e0
    // 0xbeb054: EnterFrame
    //     0xbeb054: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb058: mov             fp, SP
    // 0xbeb05c: AllocStack(0x10)
    //     0xbeb05c: sub             SP, SP, #0x10
    // 0xbeb060: SetupParameters(RenderSliverEdgeInsetsPadding this /* r1 => r3, fp-0x10 */)
    //     0xbeb060: mov             x3, x1
    //     0xbeb064: stur            x1, [fp, #-0x10]
    // 0xbeb068: CheckStackOverflow
    //     0xbeb068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeb06c: cmp             SP, x16
    //     0xbeb070: b.ls            #0xbeb21c
    // 0xbeb074: LoadField: r4 = r3->field_27
    //     0xbeb074: ldur            w4, [x3, #0x27]
    // 0xbeb078: DecompressPointer r4
    //     0xbeb078: add             x4, x4, HEAP, lsl #32
    // 0xbeb07c: stur            x4, [fp, #-8]
    // 0xbeb080: cmp             w4, NULL
    // 0xbeb084: b.eq            #0xbeb200
    // 0xbeb088: mov             x0, x4
    // 0xbeb08c: r2 = Null
    //     0xbeb08c: mov             x2, NULL
    // 0xbeb090: r1 = Null
    //     0xbeb090: mov             x1, NULL
    // 0xbeb094: r4 = LoadClassIdInstr(r0)
    //     0xbeb094: ldur            x4, [x0, #-1]
    //     0xbeb098: ubfx            x4, x4, #0xc, #0x14
    // 0xbeb09c: cmp             x4, #0xb45
    // 0xbeb0a0: b.eq            #0xbeb0b8
    // 0xbeb0a4: r8 = SliverConstraints
    //     0xbeb0a4: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbeb0a8: ldr             x8, [x8, #0x3c0]
    // 0xbeb0ac: r3 = Null
    //     0xbeb0ac: add             x3, PP, #0x96, lsl #12  ; [pp+0x96548] Null
    //     0xbeb0b0: ldr             x3, [x3, #0x548]
    // 0xbeb0b4: r0 = DefaultTypeTest()
    //     0xbeb0b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbeb0b8: ldur            x0, [fp, #-8]
    // 0xbeb0bc: LoadField: r1 = r0->field_7
    //     0xbeb0bc: ldur            w1, [x0, #7]
    // 0xbeb0c0: DecompressPointer r1
    //     0xbeb0c0: add             x1, x1, HEAP, lsl #32
    // 0xbeb0c4: LoadField: r2 = r0->field_b
    //     0xbeb0c4: ldur            w2, [x0, #0xb]
    // 0xbeb0c8: DecompressPointer r2
    //     0xbeb0c8: add             x2, x2, HEAP, lsl #32
    // 0xbeb0cc: r0 = applyGrowthDirectionToAxisDirection()
    //     0xbeb0cc: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0xbeb0d0: LoadField: r1 = r0->field_7
    //     0xbeb0d0: ldur            x1, [x0, #7]
    // 0xbeb0d4: cmp             x1, #1
    // 0xbeb0d8: b.gt            #0xbeb16c
    // 0xbeb0dc: cmp             x1, #0
    // 0xbeb0e0: b.gt            #0xbeb128
    // 0xbeb0e4: ldur            x0, [fp, #-0x10]
    // 0xbeb0e8: r1 = LoadClassIdInstr(r0)
    //     0xbeb0e8: ldur            x1, [x0, #-1]
    //     0xbeb0ec: ubfx            x1, x1, #0xc, #0x14
    // 0xbeb0f0: r17 = 4691
    //     0xbeb0f0: mov             x17, #0x1253
    // 0xbeb0f4: cmp             x1, x17
    // 0xbeb0f8: b.ne            #0xbeb10c
    // 0xbeb0fc: LoadField: r1 = r0->field_5b
    //     0xbeb0fc: ldur            w1, [x0, #0x5b]
    // 0xbeb100: DecompressPointer r1
    //     0xbeb100: add             x1, x1, HEAP, lsl #32
    // 0xbeb104: mov             x0, x1
    // 0xbeb108: b               #0xbeb118
    // 0xbeb10c: LoadField: r1 = r0->field_4f
    //     0xbeb10c: ldur            w1, [x0, #0x4f]
    // 0xbeb110: DecompressPointer r1
    //     0xbeb110: add             x1, x1, HEAP, lsl #32
    // 0xbeb114: mov             x0, x1
    // 0xbeb118: cmp             w0, NULL
    // 0xbeb11c: b.eq            #0xbeb224
    // 0xbeb120: LoadField: d0 = r0->field_f
    //     0xbeb120: ldur            d0, [x0, #0xf]
    // 0xbeb124: b               #0xbeb1f4
    // 0xbeb128: ldur            x0, [fp, #-0x10]
    // 0xbeb12c: r1 = LoadClassIdInstr(r0)
    //     0xbeb12c: ldur            x1, [x0, #-1]
    //     0xbeb130: ubfx            x1, x1, #0xc, #0x14
    // 0xbeb134: r17 = 4691
    //     0xbeb134: mov             x17, #0x1253
    // 0xbeb138: cmp             x1, x17
    // 0xbeb13c: b.ne            #0xbeb150
    // 0xbeb140: LoadField: r1 = r0->field_5b
    //     0xbeb140: ldur            w1, [x0, #0x5b]
    // 0xbeb144: DecompressPointer r1
    //     0xbeb144: add             x1, x1, HEAP, lsl #32
    // 0xbeb148: mov             x0, x1
    // 0xbeb14c: b               #0xbeb15c
    // 0xbeb150: LoadField: r1 = r0->field_4f
    //     0xbeb150: ldur            w1, [x0, #0x4f]
    // 0xbeb154: DecompressPointer r1
    //     0xbeb154: add             x1, x1, HEAP, lsl #32
    // 0xbeb158: mov             x0, x1
    // 0xbeb15c: cmp             w0, NULL
    // 0xbeb160: b.eq            #0xbeb228
    // 0xbeb164: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbeb164: ldur            d0, [x0, #0x17]
    // 0xbeb168: b               #0xbeb1f4
    // 0xbeb16c: ldur            x0, [fp, #-0x10]
    // 0xbeb170: cmp             x1, #2
    // 0xbeb174: b.gt            #0xbeb1b8
    // 0xbeb178: r1 = LoadClassIdInstr(r0)
    //     0xbeb178: ldur            x1, [x0, #-1]
    //     0xbeb17c: ubfx            x1, x1, #0xc, #0x14
    // 0xbeb180: r17 = 4691
    //     0xbeb180: mov             x17, #0x1253
    // 0xbeb184: cmp             x1, x17
    // 0xbeb188: b.ne            #0xbeb19c
    // 0xbeb18c: LoadField: r1 = r0->field_5b
    //     0xbeb18c: ldur            w1, [x0, #0x5b]
    // 0xbeb190: DecompressPointer r1
    //     0xbeb190: add             x1, x1, HEAP, lsl #32
    // 0xbeb194: mov             x0, x1
    // 0xbeb198: b               #0xbeb1a8
    // 0xbeb19c: LoadField: r1 = r0->field_4f
    //     0xbeb19c: ldur            w1, [x0, #0x4f]
    // 0xbeb1a0: DecompressPointer r1
    //     0xbeb1a0: add             x1, x1, HEAP, lsl #32
    // 0xbeb1a4: mov             x0, x1
    // 0xbeb1a8: cmp             w0, NULL
    // 0xbeb1ac: b.eq            #0xbeb22c
    // 0xbeb1b0: LoadField: d0 = r0->field_1f
    //     0xbeb1b0: ldur            d0, [x0, #0x1f]
    // 0xbeb1b4: b               #0xbeb1f4
    // 0xbeb1b8: r1 = LoadClassIdInstr(r0)
    //     0xbeb1b8: ldur            x1, [x0, #-1]
    //     0xbeb1bc: ubfx            x1, x1, #0xc, #0x14
    // 0xbeb1c0: r17 = 4691
    //     0xbeb1c0: mov             x17, #0x1253
    // 0xbeb1c4: cmp             x1, x17
    // 0xbeb1c8: b.ne            #0xbeb1dc
    // 0xbeb1cc: LoadField: r1 = r0->field_5b
    //     0xbeb1cc: ldur            w1, [x0, #0x5b]
    // 0xbeb1d0: DecompressPointer r1
    //     0xbeb1d0: add             x1, x1, HEAP, lsl #32
    // 0xbeb1d4: mov             x0, x1
    // 0xbeb1d8: b               #0xbeb1e8
    // 0xbeb1dc: LoadField: r1 = r0->field_4f
    //     0xbeb1dc: ldur            w1, [x0, #0x4f]
    // 0xbeb1e0: DecompressPointer r1
    //     0xbeb1e0: add             x1, x1, HEAP, lsl #32
    // 0xbeb1e4: mov             x0, x1
    // 0xbeb1e8: cmp             w0, NULL
    // 0xbeb1ec: b.eq            #0xbeb230
    // 0xbeb1f0: LoadField: d0 = r0->field_7
    //     0xbeb1f0: ldur            d0, [x0, #7]
    // 0xbeb1f4: LeaveFrame
    //     0xbeb1f4: mov             SP, fp
    //     0xbeb1f8: ldp             fp, lr, [SP], #0x10
    // 0xbeb1fc: ret
    //     0xbeb1fc: ret             
    // 0xbeb200: r0 = StateError()
    //     0xbeb200: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbeb204: mov             x1, x0
    // 0xbeb208: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbeb208: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbeb20c: StoreField: r1->field_b = r0
    //     0xbeb20c: stur            w0, [x1, #0xb]
    // 0xbeb210: mov             x0, x1
    // 0xbeb214: r0 = Throw()
    //     0xbeb214: bl              #0x13ddb2c  ; ThrowStub
    // 0xbeb218: brk             #0
    // 0xbeb21c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb21c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb220: b               #0xbeb074
    // 0xbeb224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb224: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeb228: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb228: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeb22c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb22c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeb230: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb230: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ beforePadding(/* No info */) {
    // ** addr: 0xbeb234, size: 0x1e0
    // 0xbeb234: EnterFrame
    //     0xbeb234: stp             fp, lr, [SP, #-0x10]!
    //     0xbeb238: mov             fp, SP
    // 0xbeb23c: AllocStack(0x10)
    //     0xbeb23c: sub             SP, SP, #0x10
    // 0xbeb240: SetupParameters(RenderSliverEdgeInsetsPadding this /* r1 => r3, fp-0x10 */)
    //     0xbeb240: mov             x3, x1
    //     0xbeb244: stur            x1, [fp, #-0x10]
    // 0xbeb248: CheckStackOverflow
    //     0xbeb248: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeb24c: cmp             SP, x16
    //     0xbeb250: b.ls            #0xbeb3fc
    // 0xbeb254: LoadField: r4 = r3->field_27
    //     0xbeb254: ldur            w4, [x3, #0x27]
    // 0xbeb258: DecompressPointer r4
    //     0xbeb258: add             x4, x4, HEAP, lsl #32
    // 0xbeb25c: stur            x4, [fp, #-8]
    // 0xbeb260: cmp             w4, NULL
    // 0xbeb264: b.eq            #0xbeb3e0
    // 0xbeb268: mov             x0, x4
    // 0xbeb26c: r2 = Null
    //     0xbeb26c: mov             x2, NULL
    // 0xbeb270: r1 = Null
    //     0xbeb270: mov             x1, NULL
    // 0xbeb274: r4 = LoadClassIdInstr(r0)
    //     0xbeb274: ldur            x4, [x0, #-1]
    //     0xbeb278: ubfx            x4, x4, #0xc, #0x14
    // 0xbeb27c: cmp             x4, #0xb45
    // 0xbeb280: b.eq            #0xbeb298
    // 0xbeb284: r8 = SliverConstraints
    //     0xbeb284: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbeb288: ldr             x8, [x8, #0x3c0]
    // 0xbeb28c: r3 = Null
    //     0xbeb28c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96558] Null
    //     0xbeb290: ldr             x3, [x3, #0x558]
    // 0xbeb294: r0 = DefaultTypeTest()
    //     0xbeb294: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbeb298: ldur            x0, [fp, #-8]
    // 0xbeb29c: LoadField: r1 = r0->field_7
    //     0xbeb29c: ldur            w1, [x0, #7]
    // 0xbeb2a0: DecompressPointer r1
    //     0xbeb2a0: add             x1, x1, HEAP, lsl #32
    // 0xbeb2a4: LoadField: r2 = r0->field_b
    //     0xbeb2a4: ldur            w2, [x0, #0xb]
    // 0xbeb2a8: DecompressPointer r2
    //     0xbeb2a8: add             x2, x2, HEAP, lsl #32
    // 0xbeb2ac: r0 = applyGrowthDirectionToAxisDirection()
    //     0xbeb2ac: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0xbeb2b0: LoadField: r1 = r0->field_7
    //     0xbeb2b0: ldur            x1, [x0, #7]
    // 0xbeb2b4: cmp             x1, #1
    // 0xbeb2b8: b.gt            #0xbeb34c
    // 0xbeb2bc: cmp             x1, #0
    // 0xbeb2c0: b.gt            #0xbeb308
    // 0xbeb2c4: ldur            x0, [fp, #-0x10]
    // 0xbeb2c8: r1 = LoadClassIdInstr(r0)
    //     0xbeb2c8: ldur            x1, [x0, #-1]
    //     0xbeb2cc: ubfx            x1, x1, #0xc, #0x14
    // 0xbeb2d0: r17 = 4691
    //     0xbeb2d0: mov             x17, #0x1253
    // 0xbeb2d4: cmp             x1, x17
    // 0xbeb2d8: b.ne            #0xbeb2ec
    // 0xbeb2dc: LoadField: r1 = r0->field_5b
    //     0xbeb2dc: ldur            w1, [x0, #0x5b]
    // 0xbeb2e0: DecompressPointer r1
    //     0xbeb2e0: add             x1, x1, HEAP, lsl #32
    // 0xbeb2e4: mov             x0, x1
    // 0xbeb2e8: b               #0xbeb2f8
    // 0xbeb2ec: LoadField: r1 = r0->field_4f
    //     0xbeb2ec: ldur            w1, [x0, #0x4f]
    // 0xbeb2f0: DecompressPointer r1
    //     0xbeb2f0: add             x1, x1, HEAP, lsl #32
    // 0xbeb2f4: mov             x0, x1
    // 0xbeb2f8: cmp             w0, NULL
    // 0xbeb2fc: b.eq            #0xbeb404
    // 0xbeb300: LoadField: d0 = r0->field_1f
    //     0xbeb300: ldur            d0, [x0, #0x1f]
    // 0xbeb304: b               #0xbeb3d4
    // 0xbeb308: ldur            x0, [fp, #-0x10]
    // 0xbeb30c: r1 = LoadClassIdInstr(r0)
    //     0xbeb30c: ldur            x1, [x0, #-1]
    //     0xbeb310: ubfx            x1, x1, #0xc, #0x14
    // 0xbeb314: r17 = 4691
    //     0xbeb314: mov             x17, #0x1253
    // 0xbeb318: cmp             x1, x17
    // 0xbeb31c: b.ne            #0xbeb330
    // 0xbeb320: LoadField: r1 = r0->field_5b
    //     0xbeb320: ldur            w1, [x0, #0x5b]
    // 0xbeb324: DecompressPointer r1
    //     0xbeb324: add             x1, x1, HEAP, lsl #32
    // 0xbeb328: mov             x0, x1
    // 0xbeb32c: b               #0xbeb33c
    // 0xbeb330: LoadField: r1 = r0->field_4f
    //     0xbeb330: ldur            w1, [x0, #0x4f]
    // 0xbeb334: DecompressPointer r1
    //     0xbeb334: add             x1, x1, HEAP, lsl #32
    // 0xbeb338: mov             x0, x1
    // 0xbeb33c: cmp             w0, NULL
    // 0xbeb340: b.eq            #0xbeb408
    // 0xbeb344: LoadField: d0 = r0->field_7
    //     0xbeb344: ldur            d0, [x0, #7]
    // 0xbeb348: b               #0xbeb3d4
    // 0xbeb34c: ldur            x0, [fp, #-0x10]
    // 0xbeb350: cmp             x1, #2
    // 0xbeb354: b.gt            #0xbeb398
    // 0xbeb358: r1 = LoadClassIdInstr(r0)
    //     0xbeb358: ldur            x1, [x0, #-1]
    //     0xbeb35c: ubfx            x1, x1, #0xc, #0x14
    // 0xbeb360: r17 = 4691
    //     0xbeb360: mov             x17, #0x1253
    // 0xbeb364: cmp             x1, x17
    // 0xbeb368: b.ne            #0xbeb37c
    // 0xbeb36c: LoadField: r1 = r0->field_5b
    //     0xbeb36c: ldur            w1, [x0, #0x5b]
    // 0xbeb370: DecompressPointer r1
    //     0xbeb370: add             x1, x1, HEAP, lsl #32
    // 0xbeb374: mov             x0, x1
    // 0xbeb378: b               #0xbeb388
    // 0xbeb37c: LoadField: r1 = r0->field_4f
    //     0xbeb37c: ldur            w1, [x0, #0x4f]
    // 0xbeb380: DecompressPointer r1
    //     0xbeb380: add             x1, x1, HEAP, lsl #32
    // 0xbeb384: mov             x0, x1
    // 0xbeb388: cmp             w0, NULL
    // 0xbeb38c: b.eq            #0xbeb40c
    // 0xbeb390: LoadField: d0 = r0->field_f
    //     0xbeb390: ldur            d0, [x0, #0xf]
    // 0xbeb394: b               #0xbeb3d4
    // 0xbeb398: r1 = LoadClassIdInstr(r0)
    //     0xbeb398: ldur            x1, [x0, #-1]
    //     0xbeb39c: ubfx            x1, x1, #0xc, #0x14
    // 0xbeb3a0: r17 = 4691
    //     0xbeb3a0: mov             x17, #0x1253
    // 0xbeb3a4: cmp             x1, x17
    // 0xbeb3a8: b.ne            #0xbeb3bc
    // 0xbeb3ac: LoadField: r1 = r0->field_5b
    //     0xbeb3ac: ldur            w1, [x0, #0x5b]
    // 0xbeb3b0: DecompressPointer r1
    //     0xbeb3b0: add             x1, x1, HEAP, lsl #32
    // 0xbeb3b4: mov             x0, x1
    // 0xbeb3b8: b               #0xbeb3c8
    // 0xbeb3bc: LoadField: r1 = r0->field_4f
    //     0xbeb3bc: ldur            w1, [x0, #0x4f]
    // 0xbeb3c0: DecompressPointer r1
    //     0xbeb3c0: add             x1, x1, HEAP, lsl #32
    // 0xbeb3c4: mov             x0, x1
    // 0xbeb3c8: cmp             w0, NULL
    // 0xbeb3cc: b.eq            #0xbeb410
    // 0xbeb3d0: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbeb3d0: ldur            d0, [x0, #0x17]
    // 0xbeb3d4: LeaveFrame
    //     0xbeb3d4: mov             SP, fp
    //     0xbeb3d8: ldp             fp, lr, [SP], #0x10
    // 0xbeb3dc: ret
    //     0xbeb3dc: ret             
    // 0xbeb3e0: r0 = StateError()
    //     0xbeb3e0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbeb3e4: mov             x1, x0
    // 0xbeb3e8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbeb3e8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbeb3ec: StoreField: r1->field_b = r0
    //     0xbeb3ec: stur            w0, [x1, #0xb]
    // 0xbeb3f0: mov             x0, x1
    // 0xbeb3f4: r0 = Throw()
    //     0xbeb3f4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbeb3f8: brk             #0
    // 0xbeb3fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeb3fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeb400: b               #0xbeb254
    // 0xbeb404: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb404: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeb408: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb408: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeb40c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb40c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbeb410: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeb410: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf248c, size: 0x90
    // 0xbf248c: EnterFrame
    //     0xbf248c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2490: mov             fp, SP
    // 0xbf2494: AllocStack(0x10)
    //     0xbf2494: sub             SP, SP, #0x10
    // 0xbf2498: SetupParameters(dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xbf2498: stur            x3, [fp, #-0x10]
    // 0xbf249c: CheckStackOverflow
    //     0xbf249c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf24a0: cmp             SP, x16
    //     0xbf24a4: b.ls            #0xbf2510
    // 0xbf24a8: LoadField: r4 = r2->field_7
    //     0xbf24a8: ldur            w4, [x2, #7]
    // 0xbf24ac: DecompressPointer r4
    //     0xbf24ac: add             x4, x4, HEAP, lsl #32
    // 0xbf24b0: stur            x4, [fp, #-8]
    // 0xbf24b4: cmp             w4, NULL
    // 0xbf24b8: b.eq            #0xbf2518
    // 0xbf24bc: mov             x0, x4
    // 0xbf24c0: r2 = Null
    //     0xbf24c0: mov             x2, NULL
    // 0xbf24c4: r1 = Null
    //     0xbf24c4: mov             x1, NULL
    // 0xbf24c8: r4 = LoadClassIdInstr(r0)
    //     0xbf24c8: ldur            x4, [x0, #-1]
    //     0xbf24cc: ubfx            x4, x4, #0xc, #0x14
    // 0xbf24d0: r17 = -4177
    //     0xbf24d0: mov             x17, #-0x1051
    // 0xbf24d4: add             x4, x4, x17
    // 0xbf24d8: cmp             x4, #2
    // 0xbf24dc: b.ls            #0xbf24f4
    // 0xbf24e0: r8 = SliverPhysicalParentData
    //     0xbf24e0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0xbf24e4: ldr             x8, [x8, #0x240]
    // 0xbf24e8: r3 = Null
    //     0xbf24e8: add             x3, PP, #0x96, lsl #12  ; [pp+0x964f8] Null
    //     0xbf24ec: ldr             x3, [x3, #0x4f8]
    // 0xbf24f0: r0 = DefaultTypeTest()
    //     0xbf24f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf24f4: ldur            x1, [fp, #-8]
    // 0xbf24f8: ldur            x2, [fp, #-0x10]
    // 0xbf24fc: r0 = applyPaintTransform()
    //     0xbf24fc: bl              #0xbf1bec  ; [package:flutter/src/rendering/sliver.dart] SliverPhysicalParentData::applyPaintTransform
    // 0xbf2500: r0 = Null
    //     0xbf2500: mov             x0, NULL
    // 0xbf2504: LeaveFrame
    //     0xbf2504: mov             SP, fp
    //     0xbf2508: ldp             fp, lr, [SP], #0x10
    // 0xbf250c: ret
    //     0xbf250c: ret             
    // 0xbf2510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2510: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2514: b               #0xbf24a8
    // 0xbf2518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf2518: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0ee44, size: 0xb4
    // 0xc0ee44: EnterFrame
    //     0xc0ee44: stp             fp, lr, [SP, #-0x10]!
    //     0xc0ee48: mov             fp, SP
    // 0xc0ee4c: AllocStack(0x8)
    //     0xc0ee4c: sub             SP, SP, #8
    // 0xc0ee50: SetupParameters(RenderSliverEdgeInsetsPadding this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0ee50: mov             x0, x2
    //     0xc0ee54: mov             x4, x1
    //     0xc0ee58: mov             x3, x2
    //     0xc0ee5c: stur            x2, [fp, #-8]
    // 0xc0ee60: r2 = Null
    //     0xc0ee60: mov             x2, NULL
    // 0xc0ee64: r1 = Null
    //     0xc0ee64: mov             x1, NULL
    // 0xc0ee68: r4 = 60
    //     0xc0ee68: mov             x4, #0x3c
    // 0xc0ee6c: branchIfSmi(r0, 0xc0ee78)
    //     0xc0ee6c: tbz             w0, #0, #0xc0ee78
    // 0xc0ee70: r4 = LoadClassIdInstr(r0)
    //     0xc0ee70: ldur            x4, [x0, #-1]
    //     0xc0ee74: ubfx            x4, x4, #0xc, #0x14
    // 0xc0ee78: r17 = -4679
    //     0xc0ee78: mov             x17, #-0x1247
    // 0xc0ee7c: add             x4, x4, x17
    // 0xc0ee80: cmp             x4, #0x128
    // 0xc0ee84: b.ls            #0xc0ee98
    // 0xc0ee88: r8 = RenderObject
    //     0xc0ee88: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0xc0ee8c: r3 = Null
    //     0xc0ee8c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96568] Null
    //     0xc0ee90: ldr             x3, [x3, #0x568]
    // 0xc0ee94: r0 = RenderObject()
    //     0xc0ee94: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0xc0ee98: ldur            x0, [fp, #-8]
    // 0xc0ee9c: LoadField: r1 = r0->field_7
    //     0xc0ee9c: ldur            w1, [x0, #7]
    // 0xc0eea0: DecompressPointer r1
    //     0xc0eea0: add             x1, x1, HEAP, lsl #32
    // 0xc0eea4: r2 = LoadClassIdInstr(r1)
    //     0xc0eea4: ldur            x2, [x1, #-1]
    //     0xc0eea8: ubfx            x2, x2, #0xc, #0x14
    // 0xc0eeac: r17 = -4177
    //     0xc0eeac: mov             x17, #-0x1051
    // 0xc0eeb0: add             x16, x2, x17
    // 0xc0eeb4: cmp             x16, #2
    // 0xc0eeb8: b.ls            #0xc0eee8
    // 0xc0eebc: r0 = SliverPhysicalParentData()
    //     0xc0eebc: bl              #0xc0eef8  ; AllocateSliverPhysicalParentDataStub -> SliverPhysicalParentData (size=0xc)
    // 0xc0eec0: r1 = Instance_Offset
    //     0xc0eec0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0eec4: StoreField: r0->field_7 = r1
    //     0xc0eec4: stur            w1, [x0, #7]
    // 0xc0eec8: ldur            x1, [fp, #-8]
    // 0xc0eecc: StoreField: r1->field_7 = r0
    //     0xc0eecc: stur            w0, [x1, #7]
    //     0xc0eed0: ldurb           w16, [x1, #-1]
    //     0xc0eed4: ldurb           w17, [x0, #-1]
    //     0xc0eed8: and             x16, x17, x16, lsr #2
    //     0xc0eedc: tst             x16, HEAP, lsr #32
    //     0xc0eee0: b.eq            #0xc0eee8
    //     0xc0eee4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0eee8: r0 = Null
    //     0xc0eee8: mov             x0, NULL
    // 0xc0eeec: LeaveFrame
    //     0xc0eeec: mov             SP, fp
    //     0xc0eef0: ldp             fp, lr, [SP], #0x10
    // 0xc0eef4: ret
    //     0xc0eef4: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xccdb3c, size: 0xe4
    // 0xccdb3c: EnterFrame
    //     0xccdb3c: stp             fp, lr, [SP, #-0x10]!
    //     0xccdb40: mov             fp, SP
    // 0xccdb44: AllocStack(0x20)
    //     0xccdb44: sub             SP, SP, #0x20
    // 0xccdb48: SetupParameters(dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xccdb48: mov             x4, x2
    //     0xccdb4c: stur            x2, [fp, #-0x18]
    //     0xccdb50: stur            x3, [fp, #-0x20]
    // 0xccdb54: CheckStackOverflow
    //     0xccdb54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccdb58: cmp             SP, x16
    //     0xccdb5c: b.ls            #0xccdc10
    // 0xccdb60: LoadField: r5 = r1->field_4b
    //     0xccdb60: ldur            w5, [x1, #0x4b]
    // 0xccdb64: DecompressPointer r5
    //     0xccdb64: add             x5, x5, HEAP, lsl #32
    // 0xccdb68: stur            x5, [fp, #-0x10]
    // 0xccdb6c: cmp             w5, NULL
    // 0xccdb70: b.eq            #0xccdc00
    // 0xccdb74: LoadField: r0 = r5->field_47
    //     0xccdb74: ldur            w0, [x5, #0x47]
    // 0xccdb78: DecompressPointer r0
    //     0xccdb78: add             x0, x0, HEAP, lsl #32
    // 0xccdb7c: cmp             w0, NULL
    // 0xccdb80: b.eq            #0xccdc18
    // 0xccdb84: LoadField: r1 = r0->field_3f
    //     0xccdb84: ldur            w1, [x0, #0x3f]
    // 0xccdb88: DecompressPointer r1
    //     0xccdb88: add             x1, x1, HEAP, lsl #32
    // 0xccdb8c: tbnz            w1, #4, #0xccdc00
    // 0xccdb90: LoadField: r6 = r5->field_7
    //     0xccdb90: ldur            w6, [x5, #7]
    // 0xccdb94: DecompressPointer r6
    //     0xccdb94: add             x6, x6, HEAP, lsl #32
    // 0xccdb98: stur            x6, [fp, #-8]
    // 0xccdb9c: cmp             w6, NULL
    // 0xccdba0: b.eq            #0xccdc1c
    // 0xccdba4: mov             x0, x6
    // 0xccdba8: r2 = Null
    //     0xccdba8: mov             x2, NULL
    // 0xccdbac: r1 = Null
    //     0xccdbac: mov             x1, NULL
    // 0xccdbb0: r4 = LoadClassIdInstr(r0)
    //     0xccdbb0: ldur            x4, [x0, #-1]
    //     0xccdbb4: ubfx            x4, x4, #0xc, #0x14
    // 0xccdbb8: r17 = -4177
    //     0xccdbb8: mov             x17, #-0x1051
    // 0xccdbbc: add             x4, x4, x17
    // 0xccdbc0: cmp             x4, #2
    // 0xccdbc4: b.ls            #0xccdbdc
    // 0xccdbc8: r8 = SliverPhysicalParentData
    //     0xccdbc8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0xccdbcc: ldr             x8, [x8, #0x240]
    // 0xccdbd0: r3 = Null
    //     0xccdbd0: add             x3, PP, #0x96, lsl #12  ; [pp+0x964e8] Null
    //     0xccdbd4: ldr             x3, [x3, #0x4e8]
    // 0xccdbd8: r0 = DefaultTypeTest()
    //     0xccdbd8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xccdbdc: ldur            x0, [fp, #-8]
    // 0xccdbe0: LoadField: r2 = r0->field_7
    //     0xccdbe0: ldur            w2, [x0, #7]
    // 0xccdbe4: DecompressPointer r2
    //     0xccdbe4: add             x2, x2, HEAP, lsl #32
    // 0xccdbe8: ldur            x1, [fp, #-0x20]
    // 0xccdbec: r0 = +()
    //     0xccdbec: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xccdbf0: ldur            x1, [fp, #-0x18]
    // 0xccdbf4: ldur            x2, [fp, #-0x10]
    // 0xccdbf8: mov             x3, x0
    // 0xccdbfc: r0 = paintChild()
    //     0xccdbfc: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xccdc00: r0 = Null
    //     0xccdc00: mov             x0, NULL
    // 0xccdc04: LeaveFrame
    //     0xccdc04: mov             SP, fp
    //     0xccdc08: ldp             fp, lr, [SP], #0x10
    // 0xccdc0c: ret
    //     0xccdc0c: ret             
    // 0xccdc10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccdc10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccdc14: b               #0xccdb60
    // 0xccdc18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccdc18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xccdc1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccdc1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x1144478, size: 0x17c
    // 0x1144478: EnterFrame
    //     0x1144478: stp             fp, lr, [SP, #-0x10]!
    //     0x114447c: mov             fp, SP
    // 0x1144480: AllocStack(0x48)
    //     0x1144480: sub             SP, SP, #0x48
    // 0x1144484: SetupParameters(RenderSliverEdgeInsetsPadding this /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */, dynamic _ /* d0 => d1, fp-0x28 */, dynamic _ /* d1 => d3, fp-0x30 */)
    //     0x1144484: mov             x4, x1
    //     0x1144488: mov             x3, x2
    //     0x114448c: mov             v3.16b, v1.16b
    //     0x1144490: stur            d1, [fp, #-0x30]
    //     0x1144494: mov             v1.16b, v0.16b
    //     0x1144498: stur            x1, [fp, #-0x18]
    //     0x114449c: stur            x2, [fp, #-0x20]
    //     0x11444a0: stur            d0, [fp, #-0x28]
    // 0x11444a4: CheckStackOverflow
    //     0x11444a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11444a8: cmp             SP, x16
    //     0x11444ac: b.ls            #0x11445dc
    // 0x11444b0: LoadField: r5 = r4->field_4b
    //     0x11444b0: ldur            w5, [x4, #0x4b]
    // 0x11444b4: DecompressPointer r5
    //     0x11444b4: add             x5, x5, HEAP, lsl #32
    // 0x11444b8: stur            x5, [fp, #-0x10]
    // 0x11444bc: cmp             w5, NULL
    // 0x11444c0: b.eq            #0x11445cc
    // 0x11444c4: d0 = 0.000000
    //     0x11444c4: eor             v0.16b, v0.16b, v0.16b
    // 0x11444c8: LoadField: r0 = r5->field_47
    //     0x11444c8: ldur            w0, [x5, #0x47]
    // 0x11444cc: DecompressPointer r0
    //     0x11444cc: add             x0, x0, HEAP, lsl #32
    // 0x11444d0: cmp             w0, NULL
    // 0x11444d4: b.eq            #0x11445e4
    // 0x11444d8: LoadField: d2 = r0->field_37
    //     0x11444d8: ldur            d2, [x0, #0x37]
    // 0x11444dc: fcmp            d2, d0
    // 0x11444e0: b.le            #0x11445cc
    // 0x11444e4: LoadField: r6 = r5->field_7
    //     0x11444e4: ldur            w6, [x5, #7]
    // 0x11444e8: DecompressPointer r6
    //     0x11444e8: add             x6, x6, HEAP, lsl #32
    // 0x11444ec: stur            x6, [fp, #-8]
    // 0x11444f0: cmp             w6, NULL
    // 0x11444f4: b.eq            #0x11445e8
    // 0x11444f8: mov             x0, x6
    // 0x11444fc: r2 = Null
    //     0x11444fc: mov             x2, NULL
    // 0x1144500: r1 = Null
    //     0x1144500: mov             x1, NULL
    // 0x1144504: r4 = LoadClassIdInstr(r0)
    //     0x1144504: ldur            x4, [x0, #-1]
    //     0x1144508: ubfx            x4, x4, #0xc, #0x14
    // 0x114450c: r17 = -4177
    //     0x114450c: mov             x17, #-0x1051
    // 0x1144510: add             x4, x4, x17
    // 0x1144514: cmp             x4, #2
    // 0x1144518: b.ls            #0x1144530
    // 0x114451c: r8 = SliverPhysicalParentData
    //     0x114451c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0x1144520: ldr             x8, [x8, #0x240]
    // 0x1144524: r3 = Null
    //     0x1144524: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1308] Null
    //     0x1144528: ldr             x3, [x3, #0x308]
    // 0x114452c: r0 = DefaultTypeTest()
    //     0x114452c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1144530: ldur            x1, [fp, #-0x18]
    // 0x1144534: ldur            x2, [fp, #-0x10]
    // 0x1144538: r0 = childMainAxisPosition()
    //     0x1144538: bl              #0x1144724  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::childMainAxisPosition
    // 0x114453c: ldur            x0, [fp, #-0x18]
    // 0x1144540: stur            d0, [fp, #-0x38]
    // 0x1144544: LoadField: r2 = r0->field_4b
    //     0x1144544: ldur            w2, [x0, #0x4b]
    // 0x1144548: DecompressPointer r2
    //     0x1144548: add             x2, x2, HEAP, lsl #32
    // 0x114454c: cmp             w2, NULL
    // 0x1144550: b.eq            #0x11445ec
    // 0x1144554: mov             x1, x0
    // 0x1144558: r0 = childCrossAxisPosition()
    //     0x1144558: bl              #0x121ebcc  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::childCrossAxisPosition
    // 0x114455c: ldur            x0, [fp, #-8]
    // 0x1144560: stur            d0, [fp, #-0x40]
    // 0x1144564: LoadField: r3 = r0->field_7
    //     0x1144564: ldur            w3, [x0, #7]
    // 0x1144568: DecompressPointer r3
    //     0x1144568: add             x3, x3, HEAP, lsl #32
    // 0x114456c: ldur            x0, [fp, #-0x18]
    // 0x1144570: stur            x3, [fp, #-0x10]
    // 0x1144574: LoadField: r1 = r0->field_4b
    //     0x1144574: ldur            w1, [x0, #0x4b]
    // 0x1144578: DecompressPointer r1
    //     0x1144578: add             x1, x1, HEAP, lsl #32
    // 0x114457c: cmp             w1, NULL
    // 0x1144580: b.eq            #0x11445f0
    // 0x1144584: r0 = LoadClassIdInstr(r1)
    //     0x1144584: ldur            x0, [x1, #-1]
    //     0x1144588: ubfx            x0, x0, #0xc, #0x14
    // 0x114458c: str             x1, [SP]
    // 0x1144590: r0 = GDT[cid_x0 + 0x5ab8]()
    //     0x1144590: mov             x17, #0x5ab8
    //     0x1144594: add             lr, x0, x17
    //     0x1144598: ldr             lr, [x21, lr, lsl #3]
    //     0x114459c: blr             lr
    // 0x11445a0: ldur            x1, [fp, #-0x20]
    // 0x11445a4: ldur            d0, [fp, #-0x40]
    // 0x11445a8: ldur            d1, [fp, #-0x28]
    // 0x11445ac: mov             x2, x0
    // 0x11445b0: ldur            d2, [fp, #-0x38]
    // 0x11445b4: ldur            d3, [fp, #-0x30]
    // 0x11445b8: ldur            x3, [fp, #-0x10]
    // 0x11445bc: r0 = addWithAxisOffset()
    //     0x11445bc: bl              #0x11445f4  ; [package:flutter/src/rendering/sliver.dart] SliverHitTestResult::addWithAxisOffset
    // 0x11445c0: LeaveFrame
    //     0x11445c0: mov             SP, fp
    //     0x11445c4: ldp             fp, lr, [SP], #0x10
    // 0x11445c8: ret
    //     0x11445c8: ret             
    // 0x11445cc: r0 = false
    //     0x11445cc: add             x0, NULL, #0x30  ; false
    // 0x11445d0: LeaveFrame
    //     0x11445d0: mov             SP, fp
    //     0x11445d4: ldp             fp, lr, [SP], #0x10
    // 0x11445d8: ret
    //     0x11445d8: ret             
    // 0x11445dc: r0 = StackOverflowSharedWithFPURegs()
    //     0x11445dc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11445e0: b               #0x11444b0
    // 0x11445e4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x11445e4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x11445e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x11445e8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x11445ec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x11445ec: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x11445f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x11445f0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ childMainAxisPosition(/* No info */) {
    // ** addr: 0x1144724, size: 0xb0
    // 0x1144724: EnterFrame
    //     0x1144724: stp             fp, lr, [SP, #-0x10]!
    //     0x1144728: mov             fp, SP
    // 0x114472c: AllocStack(0x10)
    //     0x114472c: sub             SP, SP, #0x10
    // 0x1144730: SetupParameters(RenderSliverEdgeInsetsPadding this /* r1 => r3, fp-0x10 */)
    //     0x1144730: mov             x3, x1
    //     0x1144734: stur            x1, [fp, #-0x10]
    // 0x1144738: CheckStackOverflow
    //     0x1144738: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114473c: cmp             SP, x16
    //     0x1144740: b.ls            #0x11447cc
    // 0x1144744: LoadField: r4 = r3->field_27
    //     0x1144744: ldur            w4, [x3, #0x27]
    // 0x1144748: DecompressPointer r4
    //     0x1144748: add             x4, x4, HEAP, lsl #32
    // 0x114474c: stur            x4, [fp, #-8]
    // 0x1144750: cmp             w4, NULL
    // 0x1144754: b.eq            #0x11447b0
    // 0x1144758: mov             x0, x4
    // 0x114475c: r2 = Null
    //     0x114475c: mov             x2, NULL
    // 0x1144760: r1 = Null
    //     0x1144760: mov             x1, NULL
    // 0x1144764: r4 = LoadClassIdInstr(r0)
    //     0x1144764: ldur            x4, [x0, #-1]
    //     0x1144768: ubfx            x4, x4, #0xc, #0x14
    // 0x114476c: cmp             x4, #0xb45
    // 0x1144770: b.eq            #0x1144788
    // 0x1144774: r8 = SliverConstraints
    //     0x1144774: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x1144778: ldr             x8, [x8, #0x3c0]
    // 0x114477c: r3 = Null
    //     0x114477c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1318] Null
    //     0x1144780: ldr             x3, [x3, #0x318]
    // 0x1144784: r0 = DefaultTypeTest()
    //     0x1144784: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x1144788: ldur            x1, [fp, #-0x10]
    // 0x114478c: r0 = beforePadding()
    //     0x114478c: bl              #0xbeb234  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::beforePadding
    // 0x1144790: ldur            x1, [fp, #-0x10]
    // 0x1144794: ldur            x2, [fp, #-8]
    // 0x1144798: mov             v1.16b, v0.16b
    // 0x114479c: d0 = 0.000000
    //     0x114479c: eor             v0.16b, v0.16b, v0.16b
    // 0x11447a0: r0 = calculatePaintOffset()
    //     0x11447a0: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0x11447a4: LeaveFrame
    //     0x11447a4: mov             SP, fp
    //     0x11447a8: ldp             fp, lr, [SP], #0x10
    // 0x11447ac: ret
    //     0x11447ac: ret             
    // 0x11447b0: r0 = StateError()
    //     0x11447b0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x11447b4: mov             x1, x0
    // 0x11447b8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x11447b8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x11447bc: StoreField: r1->field_b = r0
    //     0x11447bc: stur            w0, [x1, #0xb]
    // 0x11447c0: mov             x0, x1
    // 0x11447c4: r0 = Throw()
    //     0x11447c4: bl              #0x13ddb2c  ; ThrowStub
    // 0x11447c8: brk             #0
    // 0x11447cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11447cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11447d0: b               #0x1144744
  }
  _ childScrollOffset(/* No info */) {
    // ** addr: 0x115a7a8, size: 0x68
    // 0x115a7a8: EnterFrame
    //     0x115a7a8: stp             fp, lr, [SP, #-0x10]!
    //     0x115a7ac: mov             fp, SP
    // 0x115a7b0: CheckStackOverflow
    //     0x115a7b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115a7b4: cmp             SP, x16
    //     0x115a7b8: b.ls            #0x115a7f8
    // 0x115a7bc: r0 = beforePadding()
    //     0x115a7bc: bl              #0xbeb234  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::beforePadding
    // 0x115a7c0: r0 = inline_Allocate_Double()
    //     0x115a7c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x115a7c4: add             x0, x0, #0x10
    //     0x115a7c8: cmp             x1, x0
    //     0x115a7cc: b.ls            #0x115a800
    //     0x115a7d0: str             x0, [THR, #0x60]  ; THR::top
    //     0x115a7d4: sub             x0, x0, #0xf
    //     0x115a7d8: mov             x1, #0xe19c
    //     0x115a7dc: movk            x1, #3, lsl #16
    //     0x115a7e0: stur            x1, [x0, #-1]
    // 0x115a7e4: dmb             ishst
    // 0x115a7e8: StoreField: r0->field_7 = d0
    //     0x115a7e8: stur            d0, [x0, #7]
    // 0x115a7ec: LeaveFrame
    //     0x115a7ec: mov             SP, fp
    //     0x115a7f0: ldp             fp, lr, [SP], #0x10
    // 0x115a7f4: ret
    //     0x115a7f4: ret             
    // 0x115a7f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115a7f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115a7fc: b               #0x115a7bc
    // 0x115a800: SaveReg d0
    //     0x115a800: str             q0, [SP, #-0x10]!
    // 0x115a804: r0 = AllocateDouble()
    //     0x115a804: bl              #0x13df878  ; AllocateDoubleStub
    // 0x115a808: RestoreReg d0
    //     0x115a808: ldr             q0, [SP], #0x10
    // 0x115a80c: b               #0x115a7e8
  }
  _ childCrossAxisPosition(/* No info */) {
    // ** addr: 0x121ebcc, size: 0x134
    // 0x121ebcc: EnterFrame
    //     0x121ebcc: stp             fp, lr, [SP, #-0x10]!
    //     0x121ebd0: mov             fp, SP
    // 0x121ebd4: AllocStack(0x10)
    //     0x121ebd4: sub             SP, SP, #0x10
    // 0x121ebd8: SetupParameters(RenderSliverEdgeInsetsPadding this /* r1 => r3, fp-0x10 */)
    //     0x121ebd8: mov             x3, x1
    //     0x121ebdc: stur            x1, [fp, #-0x10]
    // 0x121ebe0: CheckStackOverflow
    //     0x121ebe0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x121ebe4: cmp             SP, x16
    //     0x121ebe8: b.ls            #0x121ecf0
    // 0x121ebec: LoadField: r4 = r3->field_27
    //     0x121ebec: ldur            w4, [x3, #0x27]
    // 0x121ebf0: DecompressPointer r4
    //     0x121ebf0: add             x4, x4, HEAP, lsl #32
    // 0x121ebf4: stur            x4, [fp, #-8]
    // 0x121ebf8: cmp             w4, NULL
    // 0x121ebfc: b.eq            #0x121ecd4
    // 0x121ec00: mov             x0, x4
    // 0x121ec04: r2 = Null
    //     0x121ec04: mov             x2, NULL
    // 0x121ec08: r1 = Null
    //     0x121ec08: mov             x1, NULL
    // 0x121ec0c: r4 = LoadClassIdInstr(r0)
    //     0x121ec0c: ldur            x4, [x0, #-1]
    //     0x121ec10: ubfx            x4, x4, #0xc, #0x14
    // 0x121ec14: cmp             x4, #0xb45
    // 0x121ec18: b.eq            #0x121ec30
    // 0x121ec1c: r8 = SliverConstraints
    //     0x121ec1c: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x121ec20: ldr             x8, [x8, #0x3c0]
    // 0x121ec24: r3 = Null
    //     0x121ec24: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa12f8] Null
    //     0x121ec28: ldr             x3, [x3, #0x2f8]
    // 0x121ec2c: r0 = DefaultTypeTest()
    //     0x121ec2c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x121ec30: ldur            x1, [fp, #-8]
    // 0x121ec34: r0 = axis()
    //     0x121ec34: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0x121ec38: LoadField: r1 = r0->field_7
    //     0x121ec38: ldur            x1, [x0, #7]
    // 0x121ec3c: cmp             x1, #0
    // 0x121ec40: b.gt            #0x121ec88
    // 0x121ec44: ldur            x0, [fp, #-0x10]
    // 0x121ec48: r1 = LoadClassIdInstr(r0)
    //     0x121ec48: ldur            x1, [x0, #-1]
    //     0x121ec4c: ubfx            x1, x1, #0xc, #0x14
    // 0x121ec50: r17 = 4691
    //     0x121ec50: mov             x17, #0x1253
    // 0x121ec54: cmp             x1, x17
    // 0x121ec58: b.ne            #0x121ec6c
    // 0x121ec5c: LoadField: r1 = r0->field_5b
    //     0x121ec5c: ldur            w1, [x0, #0x5b]
    // 0x121ec60: DecompressPointer r1
    //     0x121ec60: add             x1, x1, HEAP, lsl #32
    // 0x121ec64: mov             x0, x1
    // 0x121ec68: b               #0x121ec78
    // 0x121ec6c: LoadField: r1 = r0->field_4f
    //     0x121ec6c: ldur            w1, [x0, #0x4f]
    // 0x121ec70: DecompressPointer r1
    //     0x121ec70: add             x1, x1, HEAP, lsl #32
    // 0x121ec74: mov             x0, x1
    // 0x121ec78: cmp             w0, NULL
    // 0x121ec7c: b.eq            #0x121ecf8
    // 0x121ec80: LoadField: d0 = r0->field_f
    //     0x121ec80: ldur            d0, [x0, #0xf]
    // 0x121ec84: b               #0x121ecc8
    // 0x121ec88: ldur            x0, [fp, #-0x10]
    // 0x121ec8c: r1 = LoadClassIdInstr(r0)
    //     0x121ec8c: ldur            x1, [x0, #-1]
    //     0x121ec90: ubfx            x1, x1, #0xc, #0x14
    // 0x121ec94: r17 = 4691
    //     0x121ec94: mov             x17, #0x1253
    // 0x121ec98: cmp             x1, x17
    // 0x121ec9c: b.ne            #0x121ecb0
    // 0x121eca0: LoadField: r1 = r0->field_5b
    //     0x121eca0: ldur            w1, [x0, #0x5b]
    // 0x121eca4: DecompressPointer r1
    //     0x121eca4: add             x1, x1, HEAP, lsl #32
    // 0x121eca8: mov             x0, x1
    // 0x121ecac: b               #0x121ecbc
    // 0x121ecb0: LoadField: r1 = r0->field_4f
    //     0x121ecb0: ldur            w1, [x0, #0x4f]
    // 0x121ecb4: DecompressPointer r1
    //     0x121ecb4: add             x1, x1, HEAP, lsl #32
    // 0x121ecb8: mov             x0, x1
    // 0x121ecbc: cmp             w0, NULL
    // 0x121ecc0: b.eq            #0x121ecfc
    // 0x121ecc4: LoadField: d0 = r0->field_7
    //     0x121ecc4: ldur            d0, [x0, #7]
    // 0x121ecc8: LeaveFrame
    //     0x121ecc8: mov             SP, fp
    //     0x121eccc: ldp             fp, lr, [SP], #0x10
    // 0x121ecd0: ret
    //     0x121ecd0: ret             
    // 0x121ecd4: r0 = StateError()
    //     0x121ecd4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x121ecd8: mov             x1, x0
    // 0x121ecdc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x121ecdc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x121ece0: StoreField: r1->field_b = r0
    //     0x121ece0: stur            w0, [x1, #0xb]
    // 0x121ece4: mov             x0, x1
    // 0x121ece8: r0 = Throw()
    //     0x121ece8: bl              #0x13ddb2c  ; ThrowStub
    // 0x121ecec: brk             #0
    // 0x121ecf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x121ecf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x121ecf4: b               #0x121ebec
    // 0x121ecf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x121ecf8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x121ecfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x121ecfc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4692, size: 0x5c, field offset: 0x50
class RenderSliverPadding extends RenderSliverEdgeInsetsPadding {

  _ performLayout(/* No info */) {
    // ** addr: 0xbea528, size: 0x48
    // 0xbea528: EnterFrame
    //     0xbea528: stp             fp, lr, [SP, #-0x10]!
    //     0xbea52c: mov             fp, SP
    // 0xbea530: AllocStack(0x8)
    //     0xbea530: sub             SP, SP, #8
    // 0xbea534: SetupParameters(RenderSliverPadding this /* r1 => r0, fp-0x8 */)
    //     0xbea534: mov             x0, x1
    //     0xbea538: stur            x1, [fp, #-8]
    // 0xbea53c: CheckStackOverflow
    //     0xbea53c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbea540: cmp             SP, x16
    //     0xbea544: b.ls            #0xbea568
    // 0xbea548: mov             x1, x0
    // 0xbea54c: r0 = _resolve()
    //     0xbea54c: bl              #0xbeb414  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverPadding::_resolve
    // 0xbea550: ldur            x1, [fp, #-8]
    // 0xbea554: r0 = performLayout()
    //     0xbea554: bl              #0xbea570  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverEdgeInsetsPadding::performLayout
    // 0xbea558: r0 = Null
    //     0xbea558: mov             x0, NULL
    // 0xbea55c: LeaveFrame
    //     0xbea55c: mov             SP, fp
    //     0xbea560: ldp             fp, lr, [SP], #0x10
    // 0xbea564: ret
    //     0xbea564: ret             
    // 0xbea568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbea568: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbea56c: b               #0xbea548
  }
  _ _resolve(/* No info */) {
    // ** addr: 0xbeb414, size: 0x4c
    // 0xbeb414: LoadField: r2 = r1->field_4f
    //     0xbeb414: ldur            w2, [x1, #0x4f]
    // 0xbeb418: DecompressPointer r2
    //     0xbeb418: add             x2, x2, HEAP, lsl #32
    // 0xbeb41c: cmp             w2, NULL
    // 0xbeb420: b.eq            #0xbeb42c
    // 0xbeb424: r0 = Null
    //     0xbeb424: mov             x0, NULL
    // 0xbeb428: ret
    //     0xbeb428: ret             
    // 0xbeb42c: LoadField: r0 = r1->field_53
    //     0xbeb42c: ldur            w0, [x1, #0x53]
    // 0xbeb430: DecompressPointer r0
    //     0xbeb430: add             x0, x0, HEAP, lsl #32
    // 0xbeb434: StoreField: r1->field_4f = r0
    //     0xbeb434: stur            w0, [x1, #0x4f]
    //     0xbeb438: ldurb           w16, [x1, #-1]
    //     0xbeb43c: ldurb           w17, [x0, #-1]
    //     0xbeb440: and             x16, x17, x16, lsr #2
    //     0xbeb444: tst             x16, HEAP, lsr #32
    //     0xbeb448: b.eq            #0xbeb458
    //     0xbeb44c: str             lr, [SP, #-8]!
    //     0xbeb450: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xbeb454: ldr             lr, [SP], #8
    // 0xbeb458: r0 = Null
    //     0xbeb458: mov             x0, NULL
    // 0xbeb45c: ret
    //     0xbeb45c: ret             
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcf8c08, size: 0x70
    // 0xcf8c08: EnterFrame
    //     0xcf8c08: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8c0c: mov             fp, SP
    // 0xcf8c10: mov             x0, x2
    // 0xcf8c14: CheckStackOverflow
    //     0xcf8c14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8c18: cmp             SP, x16
    //     0xcf8c1c: b.ls            #0xcf8c70
    // 0xcf8c20: LoadField: r2 = r1->field_57
    //     0xcf8c20: ldur            w2, [x1, #0x57]
    // 0xcf8c24: DecompressPointer r2
    //     0xcf8c24: add             x2, x2, HEAP, lsl #32
    // 0xcf8c28: cmp             w2, w0
    // 0xcf8c2c: b.ne            #0xcf8c40
    // 0xcf8c30: r0 = Null
    //     0xcf8c30: mov             x0, NULL
    // 0xcf8c34: LeaveFrame
    //     0xcf8c34: mov             SP, fp
    //     0xcf8c38: ldp             fp, lr, [SP], #0x10
    // 0xcf8c3c: ret
    //     0xcf8c3c: ret             
    // 0xcf8c40: StoreField: r1->field_57 = r0
    //     0xcf8c40: stur            w0, [x1, #0x57]
    //     0xcf8c44: ldurb           w16, [x1, #-1]
    //     0xcf8c48: ldurb           w17, [x0, #-1]
    //     0xcf8c4c: and             x16, x17, x16, lsr #2
    //     0xcf8c50: tst             x16, HEAP, lsr #32
    //     0xcf8c54: b.eq            #0xcf8c5c
    //     0xcf8c58: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf8c5c: r0 = _markNeedsResolution()
    //     0xcf8c5c: bl              #0xcf8c78  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverPadding::_markNeedsResolution
    // 0xcf8c60: r0 = Null
    //     0xcf8c60: mov             x0, NULL
    // 0xcf8c64: LeaveFrame
    //     0xcf8c64: mov             SP, fp
    //     0xcf8c68: ldp             fp, lr, [SP], #0x10
    // 0xcf8c6c: ret
    //     0xcf8c6c: ret             
    // 0xcf8c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8c70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8c74: b               #0xcf8c20
  }
  _ _markNeedsResolution(/* No info */) {
    // ** addr: 0xcf8c78, size: 0x34
    // 0xcf8c78: EnterFrame
    //     0xcf8c78: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8c7c: mov             fp, SP
    // 0xcf8c80: CheckStackOverflow
    //     0xcf8c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8c84: cmp             SP, x16
    //     0xcf8c88: b.ls            #0xcf8ca4
    // 0xcf8c8c: StoreField: r1->field_4f = rNULL
    //     0xcf8c8c: stur            NULL, [x1, #0x4f]
    // 0xcf8c90: r0 = markNeedsLayout()
    //     0xcf8c90: bl              #0xbfb800  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0xcf8c94: r0 = Null
    //     0xcf8c94: mov             x0, NULL
    // 0xcf8c98: LeaveFrame
    //     0xcf8c98: mov             SP, fp
    //     0xcf8c9c: ldp             fp, lr, [SP], #0x10
    // 0xcf8ca0: ret
    //     0xcf8ca0: ret             
    // 0xcf8ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8ca4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8ca8: b               #0xcf8c8c
  }
  set _ padding=(/* No info */) {
    // ** addr: 0xcf8cac, size: 0x88
    // 0xcf8cac: EnterFrame
    //     0xcf8cac: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8cb0: mov             fp, SP
    // 0xcf8cb4: AllocStack(0x20)
    //     0xcf8cb4: sub             SP, SP, #0x20
    // 0xcf8cb8: SetupParameters(RenderSliverPadding this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf8cb8: mov             x0, x2
    //     0xcf8cbc: stur            x1, [fp, #-8]
    //     0xcf8cc0: stur            x2, [fp, #-0x10]
    // 0xcf8cc4: CheckStackOverflow
    //     0xcf8cc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8cc8: cmp             SP, x16
    //     0xcf8ccc: b.ls            #0xcf8d2c
    // 0xcf8cd0: LoadField: r2 = r1->field_53
    //     0xcf8cd0: ldur            w2, [x1, #0x53]
    // 0xcf8cd4: DecompressPointer r2
    //     0xcf8cd4: add             x2, x2, HEAP, lsl #32
    // 0xcf8cd8: stp             x0, x2, [SP]
    // 0xcf8cdc: r0 = ==()
    //     0xcf8cdc: bl              #0x1298c8c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0xcf8ce0: tbnz            w0, #4, #0xcf8cf4
    // 0xcf8ce4: r0 = Null
    //     0xcf8ce4: mov             x0, NULL
    // 0xcf8ce8: LeaveFrame
    //     0xcf8ce8: mov             SP, fp
    //     0xcf8cec: ldp             fp, lr, [SP], #0x10
    // 0xcf8cf0: ret
    //     0xcf8cf0: ret             
    // 0xcf8cf4: ldur            x1, [fp, #-8]
    // 0xcf8cf8: ldur            x0, [fp, #-0x10]
    // 0xcf8cfc: StoreField: r1->field_53 = r0
    //     0xcf8cfc: stur            w0, [x1, #0x53]
    //     0xcf8d00: ldurb           w16, [x1, #-1]
    //     0xcf8d04: ldurb           w17, [x0, #-1]
    //     0xcf8d08: and             x16, x17, x16, lsr #2
    //     0xcf8d0c: tst             x16, HEAP, lsr #32
    //     0xcf8d10: b.eq            #0xcf8d18
    //     0xcf8d14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf8d18: r0 = _markNeedsResolution()
    //     0xcf8d18: bl              #0xcf8c78  ; [package:flutter/src/rendering/sliver_padding.dart] RenderSliverPadding::_markNeedsResolution
    // 0xcf8d1c: r0 = Null
    //     0xcf8d1c: mov             x0, NULL
    // 0xcf8d20: LeaveFrame
    //     0xcf8d20: mov             SP, fp
    //     0xcf8d24: ldp             fp, lr, [SP], #0x10
    // 0xcf8d28: ret
    //     0xcf8d28: ret             
    // 0xcf8d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8d2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8d30: b               #0xcf8cd0
  }
}
