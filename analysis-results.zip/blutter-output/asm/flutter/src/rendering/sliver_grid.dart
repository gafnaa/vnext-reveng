// lib: , url: package:flutter/src/rendering/sliver_grid.dart

// class id: 1049045, size: 0x8
class :: {
}

// class id: 2848, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliverGridLayout extends Object {
}

// class id: 2849, size: 0x34, field offset: 0x8
//   const constructor, 
class SliverGridRegularTileLayout extends SliverGridLayout {

  _ getGeometryForChildIndex(/* No info */) {
    // ** addr: 0xbe893c, size: 0x10c
    // 0xbe893c: EnterFrame
    //     0xbe893c: stp             fp, lr, [SP, #-0x10]!
    //     0xbe8940: mov             fp, SP
    // 0xbe8944: AllocStack(0x20)
    //     0xbe8944: sub             SP, SP, #0x20
    // 0xbe8948: LoadField: r0 = r1->field_7
    //     0xbe8948: ldur            x0, [x1, #7]
    // 0xbe894c: cbz             x0, #0xbe89f8
    // 0xbe8950: sdiv            x4, x2, x0
    // 0xbe8954: msub            x3, x4, x0, x2
    // 0xbe8958: cmp             x3, xzr
    // 0xbe895c: b.lt            #0xbe8a14
    // 0xbe8960: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xbe8960: ldur            d0, [x1, #0x17]
    // 0xbe8964: scvtf           d1, x3
    // 0xbe8968: fmul            d2, d1, d0
    // 0xbe896c: cbz             x0, #0xbe8a28
    // 0xbe8970: sdiv            x3, x2, x0
    // 0xbe8974: LoadField: d1 = r1->field_f
    //     0xbe8974: ldur            d1, [x1, #0xf]
    // 0xbe8978: scvtf           d3, x3
    // 0xbe897c: fmul            d4, d3, d1
    // 0xbe8980: stur            d4, [fp, #-0x20]
    // 0xbe8984: LoadField: r2 = r1->field_2f
    //     0xbe8984: ldur            w2, [x1, #0x2f]
    // 0xbe8988: DecompressPointer r2
    //     0xbe8988: add             x2, x2, HEAP, lsl #32
    // 0xbe898c: tbnz            w2, #4, #0xbe89b0
    // 0xbe8990: scvtf           d1, x0
    // 0xbe8994: fmul            d3, d1, d0
    // 0xbe8998: fsub            d1, d3, d2
    // 0xbe899c: LoadField: d2 = r1->field_27
    //     0xbe899c: ldur            d2, [x1, #0x27]
    // 0xbe89a0: fsub            d3, d1, d2
    // 0xbe89a4: fsub            d1, d0, d2
    // 0xbe89a8: fsub            d0, d3, d1
    // 0xbe89ac: b               #0xbe89b4
    // 0xbe89b0: mov             v0.16b, v2.16b
    // 0xbe89b4: stur            d0, [fp, #-0x18]
    // 0xbe89b8: LoadField: d1 = r1->field_1f
    //     0xbe89b8: ldur            d1, [x1, #0x1f]
    // 0xbe89bc: stur            d1, [fp, #-0x10]
    // 0xbe89c0: LoadField: d2 = r1->field_27
    //     0xbe89c0: ldur            d2, [x1, #0x27]
    // 0xbe89c4: stur            d2, [fp, #-8]
    // 0xbe89c8: r0 = SliverGridGeometry()
    //     0xbe89c8: bl              #0xbe8a48  ; AllocateSliverGridGeometryStub -> SliverGridGeometry (size=0x28)
    // 0xbe89cc: ldur            d0, [fp, #-0x20]
    // 0xbe89d0: StoreField: r0->field_7 = d0
    //     0xbe89d0: stur            d0, [x0, #7]
    // 0xbe89d4: ldur            d0, [fp, #-0x18]
    // 0xbe89d8: StoreField: r0->field_f = d0
    //     0xbe89d8: stur            d0, [x0, #0xf]
    // 0xbe89dc: ldur            d0, [fp, #-0x10]
    // 0xbe89e0: ArrayStore: r0[0] = d0  ; List_8
    //     0xbe89e0: stur            d0, [x0, #0x17]
    // 0xbe89e4: ldur            d0, [fp, #-8]
    // 0xbe89e8: StoreField: r0->field_1f = d0
    //     0xbe89e8: stur            d0, [x0, #0x1f]
    // 0xbe89ec: LeaveFrame
    //     0xbe89ec: mov             SP, fp
    //     0xbe89f0: ldp             fp, lr, [SP], #0x10
    // 0xbe89f4: ret
    //     0xbe89f4: ret             
    // 0xbe89f8: stp             x1, x2, [SP, #-0x10]!
    // 0xbe89fc: SaveReg r0
    //     0xbe89fc: str             x0, [SP, #-8]!
    // 0xbe8a00: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xbe8a04: r4 = 0
    //     0xbe8a04: mov             x4, #0
    // 0xbe8a08: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xbe8a0c: blr             lr
    // 0xbe8a10: brk             #0
    // 0xbe8a14: cmp             x0, xzr
    // 0xbe8a18: sub             x4, x3, x0
    // 0xbe8a1c: add             x3, x3, x0
    // 0xbe8a20: csel            x3, x4, x3, lt
    // 0xbe8a24: b               #0xbe8960
    // 0xbe8a28: stp             q0, q2, [SP, #-0x20]!
    // 0xbe8a2c: stp             x1, x2, [SP, #-0x10]!
    // 0xbe8a30: SaveReg r0
    //     0xbe8a30: str             x0, [SP, #-8]!
    // 0xbe8a34: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xbe8a38: r4 = 0
    //     0xbe8a38: mov             x4, #0
    // 0xbe8a3c: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xbe8a40: blr             lr
    // 0xbe8a44: brk             #0
  }
  _ getMinChildIndexForScrollOffset(/* No info */) {
    // ** addr: 0xbe8a54, size: 0xfc
    // 0xbe8a54: EnterFrame
    //     0xbe8a54: stp             fp, lr, [SP, #-0x10]!
    //     0xbe8a58: mov             fp, SP
    // 0xbe8a5c: AllocStack(0x18)
    //     0xbe8a5c: sub             SP, SP, #0x18
    // 0xbe8a60: d1 = 0.000000
    //     0xbe8a60: ldr             d1, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xbe8a64: CheckStackOverflow
    //     0xbe8a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe8a68: cmp             SP, x16
    //     0xbe8a6c: b.ls            #0xbe8b10
    // 0xbe8a70: LoadField: d2 = r1->field_f
    //     0xbe8a70: ldur            d2, [x1, #0xf]
    // 0xbe8a74: fcmp            d2, d1
    // 0xbe8a78: b.le            #0xbe8b00
    // 0xbe8a7c: LoadField: r0 = r1->field_7
    //     0xbe8a7c: ldur            x0, [x1, #7]
    // 0xbe8a80: stur            x0, [fp, #-8]
    // 0xbe8a84: r1 = inline_Allocate_Double()
    //     0xbe8a84: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xbe8a88: add             x1, x1, #0x10
    //     0xbe8a8c: cmp             x2, x1
    //     0xbe8a90: b.ls            #0xbe8b18
    //     0xbe8a94: str             x1, [THR, #0x60]  ; THR::top
    //     0xbe8a98: sub             x1, x1, #0xf
    //     0xbe8a9c: mov             x2, #0xe19c
    //     0xbe8aa0: movk            x2, #3, lsl #16
    //     0xbe8aa4: stur            x2, [x1, #-1]
    // 0xbe8aa8: dmb             ishst
    // 0xbe8aac: StoreField: r1->field_7 = d0
    //     0xbe8aac: stur            d0, [x1, #7]
    // 0xbe8ab0: r2 = inline_Allocate_Double()
    //     0xbe8ab0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbe8ab4: add             x2, x2, #0x10
    //     0xbe8ab8: cmp             x3, x2
    //     0xbe8abc: b.ls            #0xbe8b34
    //     0xbe8ac0: str             x2, [THR, #0x60]  ; THR::top
    //     0xbe8ac4: sub             x2, x2, #0xf
    //     0xbe8ac8: mov             x3, #0xe19c
    //     0xbe8acc: movk            x3, #3, lsl #16
    //     0xbe8ad0: stur            x3, [x2, #-1]
    // 0xbe8ad4: dmb             ishst
    // 0xbe8ad8: StoreField: r2->field_7 = d2
    //     0xbe8ad8: stur            d2, [x2, #7]
    // 0xbe8adc: stp             x2, x1, [SP]
    // 0xbe8ae0: r0 = ~/()
    //     0xbe8ae0: bl              #0x13d8ee8  ; [dart:core] _Double::~/
    // 0xbe8ae4: r1 = LoadInt32Instr(r0)
    //     0xbe8ae4: sbfx            x1, x0, #1, #0x1f
    //     0xbe8ae8: tbz             w0, #0, #0xbe8af0
    //     0xbe8aec: ldur            x1, [x0, #7]
    // 0xbe8af0: ldur            x2, [fp, #-8]
    // 0xbe8af4: mul             x3, x2, x1
    // 0xbe8af8: mov             x0, x3
    // 0xbe8afc: b               #0xbe8b04
    // 0xbe8b00: r0 = 0
    //     0xbe8b00: mov             x0, #0
    // 0xbe8b04: LeaveFrame
    //     0xbe8b04: mov             SP, fp
    //     0xbe8b08: ldp             fp, lr, [SP], #0x10
    // 0xbe8b0c: ret
    //     0xbe8b0c: ret             
    // 0xbe8b10: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe8b10: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe8b14: b               #0xbe8a70
    // 0xbe8b18: stp             q0, q2, [SP, #-0x20]!
    // 0xbe8b1c: SaveReg r0
    //     0xbe8b1c: str             x0, [SP, #-8]!
    // 0xbe8b20: r0 = AllocateDouble()
    //     0xbe8b20: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8b24: mov             x1, x0
    // 0xbe8b28: RestoreReg r0
    //     0xbe8b28: ldr             x0, [SP], #8
    // 0xbe8b2c: ldp             q0, q2, [SP], #0x20
    // 0xbe8b30: b               #0xbe8aac
    // 0xbe8b34: SaveReg d2
    //     0xbe8b34: str             q2, [SP, #-0x10]!
    // 0xbe8b38: stp             x0, x1, [SP, #-0x10]!
    // 0xbe8b3c: r0 = AllocateDouble()
    //     0xbe8b3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8b40: mov             x2, x0
    // 0xbe8b44: ldp             x0, x1, [SP], #0x10
    // 0xbe8b48: RestoreReg d2
    //     0xbe8b48: ldr             q2, [SP], #0x10
    // 0xbe8b4c: b               #0xbe8ad8
  }
}

// class id: 2850, size: 0x28, field offset: 0x8
//   const constructor, 
class SliverGridGeometry extends Object {

  _ getBoxConstraints(/* No info */) {
    // ** addr: 0xbe8860, size: 0xdc
    // 0xbe8860: EnterFrame
    //     0xbe8860: stp             fp, lr, [SP, #-0x10]!
    //     0xbe8864: mov             fp, SP
    // 0xbe8868: AllocStack(0x18)
    //     0xbe8868: sub             SP, SP, #0x18
    // 0xbe886c: SetupParameters(SliverGridGeometry this /* r1 => r0 */, dynamic _ /* r2 => r1 */)
    //     0xbe886c: mov             x0, x1
    //     0xbe8870: mov             x1, x2
    // 0xbe8874: CheckStackOverflow
    //     0xbe8874: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe8878: cmp             SP, x16
    //     0xbe887c: b.ls            #0xbe8900
    // 0xbe8880: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbe8880: ldur            d0, [x0, #0x17]
    // 0xbe8884: LoadField: d1 = r0->field_1f
    //     0xbe8884: ldur            d1, [x0, #0x1f]
    // 0xbe8888: r0 = inline_Allocate_Double()
    //     0xbe8888: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbe888c: add             x0, x0, #0x10
    //     0xbe8890: cmp             x2, x0
    //     0xbe8894: b.ls            #0xbe8908
    //     0xbe8898: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe889c: sub             x0, x0, #0xf
    //     0xbe88a0: mov             x2, #0xe19c
    //     0xbe88a4: movk            x2, #3, lsl #16
    //     0xbe88a8: stur            x2, [x0, #-1]
    // 0xbe88ac: dmb             ishst
    // 0xbe88b0: StoreField: r0->field_7 = d0
    //     0xbe88b0: stur            d0, [x0, #7]
    // 0xbe88b4: r2 = inline_Allocate_Double()
    //     0xbe88b4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbe88b8: add             x2, x2, #0x10
    //     0xbe88bc: cmp             x3, x2
    //     0xbe88c0: b.ls            #0xbe8920
    //     0xbe88c4: str             x2, [THR, #0x60]  ; THR::top
    //     0xbe88c8: sub             x2, x2, #0xf
    //     0xbe88cc: mov             x3, #0xe19c
    //     0xbe88d0: movk            x3, #3, lsl #16
    //     0xbe88d4: stur            x3, [x2, #-1]
    // 0xbe88d8: dmb             ishst
    // 0xbe88dc: StoreField: r2->field_7 = d1
    //     0xbe88dc: stur            d1, [x2, #7]
    // 0xbe88e0: stp             x0, x0, [SP, #8]
    // 0xbe88e4: str             x2, [SP]
    // 0xbe88e8: r4 = const [0, 0x4, 0x3, 0x1, crossAxisExtent, 0x3, maxExtent, 0x2, minExtent, 0x1, null]
    //     0xbe88e8: add             x4, PP, #0x96, lsl #12  ; [pp+0x968f8] List(11) [0, 0x4, 0x3, 0x1, "crossAxisExtent", 0x3, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0xbe88ec: ldr             x4, [x4, #0x8f8]
    // 0xbe88f0: r0 = asBoxConstraints()
    //     0xbe88f0: bl              #0xbe58b0  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0xbe88f4: LeaveFrame
    //     0xbe88f4: mov             SP, fp
    //     0xbe88f8: ldp             fp, lr, [SP], #0x10
    // 0xbe88fc: ret
    //     0xbe88fc: ret             
    // 0xbe8900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe8900: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe8904: b               #0xbe8880
    // 0xbe8908: stp             q0, q1, [SP, #-0x20]!
    // 0xbe890c: SaveReg r1
    //     0xbe890c: str             x1, [SP, #-8]!
    // 0xbe8910: r0 = AllocateDouble()
    //     0xbe8910: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8914: RestoreReg r1
    //     0xbe8914: ldr             x1, [SP], #8
    // 0xbe8918: ldp             q0, q1, [SP], #0x20
    // 0xbe891c: b               #0xbe88b0
    // 0xbe8920: SaveReg d1
    //     0xbe8920: str             q1, [SP, #-0x10]!
    // 0xbe8924: stp             x0, x1, [SP, #-0x10]!
    // 0xbe8928: r0 = AllocateDouble()
    //     0xbe8928: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe892c: mov             x2, x0
    // 0xbe8930: ldp             x0, x1, [SP], #0x10
    // 0xbe8934: RestoreReg d1
    //     0xbe8934: ldr             q1, [SP], #0x10
    // 0xbe8938: b               #0xbe88dc
  }
}

// class id: 3119, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliverGridDelegate extends Object {
}

// class id: 3120, size: 0x2c, field offset: 0x8
//   const constructor, 
class SliverGridDelegateWithFixedCrossAxisCount extends SliverGridDelegate {

  _Mint field_8;
  _Double field_10;
  _Double field_18;
  _Double field_20;

  _ getLayout(/* No info */) {
    // ** addr: 0x12ff6dc, size: 0xf0
    // 0x12ff6dc: EnterFrame
    //     0x12ff6dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12ff6e0: mov             fp, SP
    // 0x12ff6e4: AllocStack(0x30)
    //     0x12ff6e4: sub             SP, SP, #0x30
    // 0x12ff6e8: d0 = 0.000000
    //     0x12ff6e8: eor             v0.16b, v0.16b, v0.16b
    // 0x12ff6ec: LoadField: d1 = r2->field_33
    //     0x12ff6ec: ldur            d1, [x2, #0x33]
    // 0x12ff6f0: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x12ff6f0: ldur            d2, [x1, #0x17]
    // 0x12ff6f4: LoadField: r0 = r1->field_7
    //     0x12ff6f4: ldur            x0, [x1, #7]
    // 0x12ff6f8: stur            x0, [fp, #-0x10]
    // 0x12ff6fc: sub             x3, x0, #1
    // 0x12ff700: scvtf           d3, x3
    // 0x12ff704: fmul            d4, d2, d3
    // 0x12ff708: fsub            d3, d1, d4
    // 0x12ff70c: fmax            v1.2d, v0.2d, v3.2d
    // 0x12ff710: scvtf           d0, x0
    // 0x12ff714: fdiv            d3, d1, d0
    // 0x12ff718: stur            d3, [fp, #-0x30]
    // 0x12ff71c: LoadField: d0 = r1->field_1f
    //     0x12ff71c: ldur            d0, [x1, #0x1f]
    // 0x12ff720: fdiv            d1, d3, d0
    // 0x12ff724: stur            d1, [fp, #-0x28]
    // 0x12ff728: LoadField: d0 = r1->field_f
    //     0x12ff728: ldur            d0, [x1, #0xf]
    // 0x12ff72c: fadd            d4, d1, d0
    // 0x12ff730: stur            d4, [fp, #-0x20]
    // 0x12ff734: fadd            d0, d3, d2
    // 0x12ff738: stur            d0, [fp, #-0x18]
    // 0x12ff73c: LoadField: r1 = r2->field_3b
    //     0x12ff73c: ldur            w1, [x2, #0x3b]
    // 0x12ff740: DecompressPointer r1
    //     0x12ff740: add             x1, x1, HEAP, lsl #32
    // 0x12ff744: r16 = Instance_AxisDirection
    //     0x12ff744: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0x12ff748: cmp             w1, w16
    // 0x12ff74c: b.eq            #0x12ff75c
    // 0x12ff750: r16 = Instance_AxisDirection
    //     0x12ff750: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0x12ff754: cmp             w1, w16
    // 0x12ff758: b.ne            #0x12ff764
    // 0x12ff75c: r1 = true
    //     0x12ff75c: add             x1, NULL, #0x20  ; true
    // 0x12ff760: b               #0x12ff788
    // 0x12ff764: r16 = Instance_AxisDirection
    //     0x12ff764: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0x12ff768: cmp             w1, w16
    // 0x12ff76c: b.eq            #0x12ff77c
    // 0x12ff770: r16 = Instance_AxisDirection
    //     0x12ff770: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0x12ff774: cmp             w1, w16
    // 0x12ff778: b.ne            #0x12ff784
    // 0x12ff77c: r1 = false
    //     0x12ff77c: add             x1, NULL, #0x30  ; false
    // 0x12ff780: b               #0x12ff788
    // 0x12ff784: r1 = Null
    //     0x12ff784: mov             x1, NULL
    // 0x12ff788: stur            x1, [fp, #-8]
    // 0x12ff78c: r0 = SliverGridRegularTileLayout()
    //     0x12ff78c: bl              #0x12ff528  ; AllocateSliverGridRegularTileLayoutStub -> SliverGridRegularTileLayout (size=0x34)
    // 0x12ff790: ldur            x1, [fp, #-0x10]
    // 0x12ff794: StoreField: r0->field_7 = r1
    //     0x12ff794: stur            x1, [x0, #7]
    // 0x12ff798: ldur            d0, [fp, #-0x20]
    // 0x12ff79c: StoreField: r0->field_f = d0
    //     0x12ff79c: stur            d0, [x0, #0xf]
    // 0x12ff7a0: ldur            d0, [fp, #-0x18]
    // 0x12ff7a4: ArrayStore: r0[0] = d0  ; List_8
    //     0x12ff7a4: stur            d0, [x0, #0x17]
    // 0x12ff7a8: ldur            d0, [fp, #-0x28]
    // 0x12ff7ac: StoreField: r0->field_1f = d0
    //     0x12ff7ac: stur            d0, [x0, #0x1f]
    // 0x12ff7b0: ldur            d0, [fp, #-0x30]
    // 0x12ff7b4: StoreField: r0->field_27 = d0
    //     0x12ff7b4: stur            d0, [x0, #0x27]
    // 0x12ff7b8: ldur            x1, [fp, #-8]
    // 0x12ff7bc: StoreField: r0->field_2f = r1
    //     0x12ff7bc: stur            w1, [x0, #0x2f]
    // 0x12ff7c0: LeaveFrame
    //     0x12ff7c0: mov             SP, fp
    //     0x12ff7c4: ldp             fp, lr, [SP], #0x10
    // 0x12ff7c8: ret
    //     0x12ff7c8: ret             
  }
}

// class id: 4184, size: 0x24, field offset: 0x20
class SliverGridParentData extends SliverMultiBoxAdaptorParentData {
}

// class id: 4698, size: 0x68, field offset: 0x64
class RenderSliverGrid extends RenderSliverMultiBoxAdaptor {

  _ performLayout(/* No info */) {
    // ** addr: 0xbe76c4, size: 0x119c
    // 0xbe76c4: EnterFrame
    //     0xbe76c4: stp             fp, lr, [SP, #-0x10]!
    //     0xbe76c8: mov             fp, SP
    // 0xbe76cc: AllocStack(0xe0)
    //     0xbe76cc: sub             SP, SP, #0xe0
    // 0xbe76d0: SetupParameters(RenderSliverGrid this /* r1 => r3, fp-0x10 */)
    //     0xbe76d0: mov             x3, x1
    //     0xbe76d4: stur            x1, [fp, #-0x10]
    // 0xbe76d8: CheckStackOverflow
    //     0xbe76d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe76dc: cmp             SP, x16
    //     0xbe76e0: b.ls            #0xbe8580
    // 0xbe76e4: LoadField: r4 = r3->field_27
    //     0xbe76e4: ldur            w4, [x3, #0x27]
    // 0xbe76e8: DecompressPointer r4
    //     0xbe76e8: add             x4, x4, HEAP, lsl #32
    // 0xbe76ec: stur            x4, [fp, #-8]
    // 0xbe76f0: cmp             w4, NULL
    // 0xbe76f4: b.eq            #0xbe8564
    // 0xbe76f8: mov             x0, x4
    // 0xbe76fc: r2 = Null
    //     0xbe76fc: mov             x2, NULL
    // 0xbe7700: r1 = Null
    //     0xbe7700: mov             x1, NULL
    // 0xbe7704: r4 = LoadClassIdInstr(r0)
    //     0xbe7704: ldur            x4, [x0, #-1]
    //     0xbe7708: ubfx            x4, x4, #0xc, #0x14
    // 0xbe770c: cmp             x4, #0xb45
    // 0xbe7710: b.eq            #0xbe7728
    // 0xbe7714: r8 = SliverConstraints
    //     0xbe7714: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbe7718: ldr             x8, [x8, #0x3c0]
    // 0xbe771c: r3 = Null
    //     0xbe771c: add             x3, PP, #0x96, lsl #12  ; [pp+0x968d0] Null
    //     0xbe7720: ldr             x3, [x3, #0x8d0]
    // 0xbe7724: r0 = DefaultTypeTest()
    //     0xbe7724: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe7728: ldur            x3, [fp, #-0x10]
    // 0xbe772c: LoadField: r4 = r3->field_5b
    //     0xbe772c: ldur            w4, [x3, #0x5b]
    // 0xbe7730: DecompressPointer r4
    //     0xbe7730: add             x4, x4, HEAP, lsl #32
    // 0xbe7734: stur            x4, [fp, #-0x18]
    // 0xbe7738: r5 = false
    //     0xbe7738: add             x5, NULL, #0x30  ; false
    // 0xbe773c: StoreField: r4->field_53 = r5
    //     0xbe773c: stur            w5, [x4, #0x53]
    // 0xbe7740: ldur            x6, [fp, #-8]
    // 0xbe7744: LoadField: d0 = r6->field_13
    //     0xbe7744: ldur            d0, [x6, #0x13]
    // 0xbe7748: stur            d0, [fp, #-0x88]
    // 0xbe774c: LoadField: d1 = r6->field_47
    //     0xbe774c: ldur            d1, [x6, #0x47]
    // 0xbe7750: fadd            d2, d0, d1
    // 0xbe7754: stur            d2, [fp, #-0x80]
    // 0xbe7758: LoadField: d1 = r6->field_4f
    //     0xbe7758: ldur            d1, [x6, #0x4f]
    // 0xbe775c: fadd            d3, d2, d1
    // 0xbe7760: stur            d3, [fp, #-0x78]
    // 0xbe7764: LoadField: r1 = r3->field_63
    //     0xbe7764: ldur            w1, [x3, #0x63]
    // 0xbe7768: DecompressPointer r1
    //     0xbe7768: add             x1, x1, HEAP, lsl #32
    // 0xbe776c: r0 = LoadClassIdInstr(r1)
    //     0xbe776c: ldur            x0, [x1, #-1]
    //     0xbe7770: ubfx            x0, x0, #0xc, #0x14
    // 0xbe7774: mov             x2, x6
    // 0xbe7778: r0 = GDT[cid_x0 + -0x1000]()
    //     0xbe7778: sub             lr, x0, #1, lsl #12
    //     0xbe777c: ldr             lr, [x21, lr, lsl #3]
    //     0xbe7780: blr             lr
    // 0xbe7784: mov             x1, x0
    // 0xbe7788: ldur            d0, [fp, #-0x80]
    // 0xbe778c: stur            x0, [fp, #-0x20]
    // 0xbe7790: r0 = getMinChildIndexForScrollOffset()
    //     0xbe7790: bl              #0xbe8a54  ; [package:flutter/src/rendering/sliver_grid.dart] SliverGridRegularTileLayout::getMinChildIndexForScrollOffset
    // 0xbe7794: mov             x3, x0
    // 0xbe7798: ldur            d0, [fp, #-0x78]
    // 0xbe779c: stur            x3, [fp, #-0x30]
    // 0xbe77a0: mov             x0, v0.d[0]
    // 0xbe77a4: and             x0, x0, #0x7fffffffffffffff
    // 0xbe77a8: r17 = 9218868437227405312
    //     0xbe77a8: mov             x17, #0x7ff0000000000000
    // 0xbe77ac: cmp             x0, x17
    // 0xbe77b0: b.eq            #0xbe7850
    // 0xbe77b4: fcmp            d0, d0
    // 0xbe77b8: b.vs            #0xbe7840
    // 0xbe77bc: ldur            x4, [fp, #-0x20]
    // 0xbe77c0: d1 = 0.000000
    //     0xbe77c0: eor             v1.16b, v1.16b, v1.16b
    // 0xbe77c4: LoadField: d2 = r4->field_f
    //     0xbe77c4: ldur            d2, [x4, #0xf]
    // 0xbe77c8: fcmp            d2, d1
    // 0xbe77cc: b.le            #0xbe781c
    // 0xbe77d0: r2 = 0
    //     0xbe77d0: mov             x2, #0
    // 0xbe77d4: fdiv            d3, d0, d2
    // 0xbe77d8: fcmp            d3, d3
    // 0xbe77dc: b.vs            #0xbe8588
    // 0xbe77e0: fcvtps          x0, d3
    // 0xbe77e4: asr             x16, x0, #0x1e
    // 0xbe77e8: cmp             x16, x0, asr #63
    // 0xbe77ec: b.ne            #0xbe8588
    // 0xbe77f0: lsl             x0, x0, #1
    // 0xbe77f4: LoadField: r1 = r4->field_7
    //     0xbe77f4: ldur            x1, [x4, #7]
    // 0xbe77f8: r5 = LoadInt32Instr(r0)
    //     0xbe77f8: sbfx            x5, x0, #1, #0x1f
    //     0xbe77fc: tbz             w0, #0, #0xbe7804
    //     0xbe7800: ldur            x5, [x0, #7]
    // 0xbe7804: mul             x0, x1, x5
    // 0xbe7808: sub             x1, x0, #1
    // 0xbe780c: cmp             x2, x1
    // 0xbe7810: csel            x0, x1, x2, lt
    // 0xbe7814: mov             x5, x0
    // 0xbe7818: b               #0xbe7824
    // 0xbe781c: r2 = 0
    //     0xbe781c: mov             x2, #0
    // 0xbe7820: r5 = 0
    //     0xbe7820: mov             x5, #0
    // 0xbe7824: r0 = BoxInt64Instr(r5)
    //     0xbe7824: sbfiz           x0, x5, #1, #0x1f
    //     0xbe7828: cmp             x5, x0, asr #1
    //     0xbe782c: b.eq            #0xbe7838
    //     0xbe7830: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xbe7834: stur            x5, [x0, #7]
    // 0xbe7838: mov             x5, x0
    // 0xbe783c: b               #0xbe7860
    // 0xbe7840: ldur            x4, [fp, #-0x20]
    // 0xbe7844: d1 = 0.000000
    //     0xbe7844: eor             v1.16b, v1.16b, v1.16b
    // 0xbe7848: r2 = 0
    //     0xbe7848: mov             x2, #0
    // 0xbe784c: b               #0xbe785c
    // 0xbe7850: ldur            x4, [fp, #-0x20]
    // 0xbe7854: d1 = 0.000000
    //     0xbe7854: eor             v1.16b, v1.16b, v1.16b
    // 0xbe7858: r2 = 0
    //     0xbe7858: mov             x2, #0
    // 0xbe785c: r5 = Null
    //     0xbe785c: mov             x5, NULL
    // 0xbe7860: ldur            x0, [fp, #-0x10]
    // 0xbe7864: stur            x5, [fp, #-0x28]
    // 0xbe7868: LoadField: r1 = r0->field_53
    //     0xbe7868: ldur            w1, [x0, #0x53]
    // 0xbe786c: DecompressPointer r1
    //     0xbe786c: add             x1, x1, HEAP, lsl #32
    // 0xbe7870: cmp             w1, NULL
    // 0xbe7874: b.eq            #0xbe78c8
    // 0xbe7878: mov             x1, x0
    // 0xbe787c: mov             x2, x3
    // 0xbe7880: r0 = calculateLeadingGarbage()
    //     0xbe7880: bl              #0xbe6e48  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::calculateLeadingGarbage
    // 0xbe7884: mov             x3, x0
    // 0xbe7888: ldur            x0, [fp, #-0x28]
    // 0xbe788c: stur            x3, [fp, #-0x38]
    // 0xbe7890: cmp             w0, NULL
    // 0xbe7894: b.eq            #0xbe78b4
    // 0xbe7898: r2 = LoadInt32Instr(r0)
    //     0xbe7898: sbfx            x2, x0, #1, #0x1f
    //     0xbe789c: tbz             w0, #0, #0xbe78a4
    //     0xbe78a0: ldur            x2, [x0, #7]
    // 0xbe78a4: ldur            x1, [fp, #-0x10]
    // 0xbe78a8: r0 = calculateTrailingGarbage()
    //     0xbe78a8: bl              #0xbe6d58  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::calculateTrailingGarbage
    // 0xbe78ac: mov             x3, x0
    // 0xbe78b0: b               #0xbe78b8
    // 0xbe78b4: r3 = 0
    //     0xbe78b4: mov             x3, #0
    // 0xbe78b8: ldur            x1, [fp, #-0x10]
    // 0xbe78bc: ldur            x2, [fp, #-0x38]
    // 0xbe78c0: r0 = collectGarbage()
    //     0xbe78c0: bl              #0xbe64f8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0xbe78c4: b               #0xbe78d4
    // 0xbe78c8: ldur            x1, [fp, #-0x10]
    // 0xbe78cc: mov             x3, x2
    // 0xbe78d0: r0 = collectGarbage()
    //     0xbe78d0: bl              #0xbe64f8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::collectGarbage
    // 0xbe78d4: ldur            x0, [fp, #-0x10]
    // 0xbe78d8: ldur            x1, [fp, #-0x20]
    // 0xbe78dc: ldur            x2, [fp, #-0x30]
    // 0xbe78e0: r0 = getGeometryForChildIndex()
    //     0xbe78e0: bl              #0xbe893c  ; [package:flutter/src/rendering/sliver_grid.dart] SliverGridRegularTileLayout::getGeometryForChildIndex
    // 0xbe78e4: mov             x3, x0
    // 0xbe78e8: ldur            x2, [fp, #-0x10]
    // 0xbe78ec: stur            x3, [fp, #-0x40]
    // 0xbe78f0: LoadField: r0 = r2->field_53
    //     0xbe78f0: ldur            w0, [x2, #0x53]
    // 0xbe78f4: DecompressPointer r0
    //     0xbe78f4: add             x0, x0, HEAP, lsl #32
    // 0xbe78f8: cmp             w0, NULL
    // 0xbe78fc: b.ne            #0xbe7a3c
    // 0xbe7900: ldur            x4, [fp, #-0x30]
    // 0xbe7904: LoadField: d0 = r3->field_7
    //     0xbe7904: ldur            d0, [x3, #7]
    // 0xbe7908: r0 = BoxInt64Instr(r4)
    //     0xbe7908: sbfiz           x0, x4, #1, #0x1f
    //     0xbe790c: cmp             x4, x0, asr #1
    //     0xbe7910: b.eq            #0xbe791c
    //     0xbe7914: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xbe7918: stur            x4, [x0, #7]
    // 0xbe791c: r1 = inline_Allocate_Double()
    //     0xbe791c: ldp             x1, x5, [THR, #0x60]  ; THR::top
    //     0xbe7920: add             x1, x1, #0x10
    //     0xbe7924: cmp             x5, x1
    //     0xbe7928: b.ls            #0xbe85b8
    //     0xbe792c: str             x1, [THR, #0x60]  ; THR::top
    //     0xbe7930: sub             x1, x1, #0xf
    //     0xbe7934: mov             x5, #0xe19c
    //     0xbe7938: movk            x5, #3, lsl #16
    //     0xbe793c: stur            x5, [x1, #-1]
    // 0xbe7940: dmb             ishst
    // 0xbe7944: StoreField: r1->field_7 = d0
    //     0xbe7944: stur            d0, [x1, #7]
    // 0xbe7948: stp             x1, x0, [SP]
    // 0xbe794c: mov             x1, x2
    // 0xbe7950: r4 = const [0, 0x3, 0x2, 0x1, index, 0x1, layoutOffset, 0x2, null]
    //     0xbe7950: add             x4, PP, #0x96, lsl #12  ; [pp+0x968e0] List(9) [0, 0x3, 0x2, 0x1, "index", 0x1, "layoutOffset", 0x2, Null]
    //     0xbe7954: ldr             x4, [x4, #0x8e0]
    // 0xbe7958: r0 = addInitialChild()
    //     0xbe7958: bl              #0xbe60b8  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::addInitialChild
    // 0xbe795c: tbz             w0, #4, #0xbe7a2c
    // 0xbe7960: ldur            x1, [fp, #-0x18]
    // 0xbe7964: r0 = childCount()
    //     0xbe7964: bl              #0xbe5e6c  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::childCount
    // 0xbe7968: cbnz            x0, #0xbe7974
    // 0xbe796c: d0 = 0.000000
    //     0xbe796c: eor             v0.16b, v0.16b, v0.16b
    // 0xbe7970: b               #0xbe79a4
    // 0xbe7974: ldur            x3, [fp, #-0x20]
    // 0xbe7978: sub             x1, x0, #1
    // 0xbe797c: LoadField: r0 = r3->field_7
    //     0xbe797c: ldur            x0, [x3, #7]
    // 0xbe7980: cbz             x0, #0xbe85dc
    // 0xbe7984: sdiv            x2, x1, x0
    // 0xbe7988: add             x0, x2, #1
    // 0xbe798c: LoadField: d0 = r3->field_f
    //     0xbe798c: ldur            d0, [x3, #0xf]
    // 0xbe7990: LoadField: d1 = r3->field_1f
    //     0xbe7990: ldur            d1, [x3, #0x1f]
    // 0xbe7994: fsub            d2, d0, d1
    // 0xbe7998: scvtf           d1, x0
    // 0xbe799c: fmul            d3, d0, d1
    // 0xbe79a0: fsub            d0, d3, d2
    // 0xbe79a4: ldur            x1, [fp, #-0x10]
    // 0xbe79a8: stur            d0, [fp, #-0x78]
    // 0xbe79ac: r0 = SliverGeometry()
    //     0xbe79ac: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe79b0: ldur            d0, [fp, #-0x78]
    // 0xbe79b4: StoreField: r0->field_7 = d0
    //     0xbe79b4: stur            d0, [x0, #7]
    // 0xbe79b8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xbe79b8: stur            xzr, [x0, #0x17]
    // 0xbe79bc: StoreField: r0->field_f = rZR
    //     0xbe79bc: stur            xzr, [x0, #0xf]
    // 0xbe79c0: StoreField: r0->field_27 = d0
    //     0xbe79c0: stur            d0, [x0, #0x27]
    // 0xbe79c4: StoreField: r0->field_2f = rZR
    //     0xbe79c4: stur            xzr, [x0, #0x2f]
    // 0xbe79c8: r1 = false
    //     0xbe79c8: add             x1, NULL, #0x30  ; false
    // 0xbe79cc: StoreField: r0->field_43 = r1
    //     0xbe79cc: stur            w1, [x0, #0x43]
    // 0xbe79d0: StoreField: r0->field_1f = rZR
    //     0xbe79d0: stur            xzr, [x0, #0x1f]
    // 0xbe79d4: StoreField: r0->field_37 = rZR
    //     0xbe79d4: stur            xzr, [x0, #0x37]
    // 0xbe79d8: StoreField: r0->field_4b = rZR
    //     0xbe79d8: stur            xzr, [x0, #0x4b]
    // 0xbe79dc: d0 = 0.000000
    //     0xbe79dc: eor             v0.16b, v0.16b, v0.16b
    // 0xbe79e0: fcmp            d0, d0
    // 0xbe79e4: r16 = true
    //     0xbe79e4: add             x16, NULL, #0x20  ; true
    // 0xbe79e8: r17 = false
    //     0xbe79e8: add             x17, NULL, #0x30  ; false
    // 0xbe79ec: csel            x1, x16, x17, gt
    // 0xbe79f0: StoreField: r0->field_3f = r1
    //     0xbe79f0: stur            w1, [x0, #0x3f]
    // 0xbe79f4: ldur            x4, [fp, #-0x10]
    // 0xbe79f8: StoreField: r4->field_47 = r0
    //     0xbe79f8: stur            w0, [x4, #0x47]
    //     0xbe79fc: ldurb           w16, [x4, #-1]
    //     0xbe7a00: ldurb           w17, [x0, #-1]
    //     0xbe7a04: and             x16, x17, x16, lsr #2
    //     0xbe7a08: tst             x16, HEAP, lsr #32
    //     0xbe7a0c: b.eq            #0xbe7a14
    //     0xbe7a10: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbe7a14: ldur            x1, [fp, #-0x18]
    // 0xbe7a18: r0 = didFinishLayout()
    //     0xbe7a18: bl              #0xbe5ab0  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0xbe7a1c: r0 = Null
    //     0xbe7a1c: mov             x0, NULL
    // 0xbe7a20: LeaveFrame
    //     0xbe7a20: mov             SP, fp
    //     0xbe7a24: ldp             fp, lr, [SP], #0x10
    // 0xbe7a28: ret
    //     0xbe7a28: ret             
    // 0xbe7a2c: ldur            x4, [fp, #-0x10]
    // 0xbe7a30: ldur            x3, [fp, #-0x20]
    // 0xbe7a34: d0 = 0.000000
    //     0xbe7a34: eor             v0.16b, v0.16b, v0.16b
    // 0xbe7a38: b               #0xbe7a48
    // 0xbe7a3c: mov             x4, x2
    // 0xbe7a40: ldur            x3, [fp, #-0x20]
    // 0xbe7a44: d0 = 0.000000
    //     0xbe7a44: eor             v0.16b, v0.16b, v0.16b
    // 0xbe7a48: ldur            x5, [fp, #-0x40]
    // 0xbe7a4c: LoadField: d1 = r5->field_7
    //     0xbe7a4c: ldur            d1, [x5, #7]
    // 0xbe7a50: stur            d1, [fp, #-0x80]
    // 0xbe7a54: ArrayLoad: d2 = r5[0]  ; List_8
    //     0xbe7a54: ldur            d2, [x5, #0x17]
    // 0xbe7a58: fadd            d3, d1, d2
    // 0xbe7a5c: stur            d3, [fp, #-0x78]
    // 0xbe7a60: LoadField: r0 = r4->field_53
    //     0xbe7a60: ldur            w0, [x4, #0x53]
    // 0xbe7a64: DecompressPointer r0
    //     0xbe7a64: add             x0, x0, HEAP, lsl #32
    // 0xbe7a68: cmp             w0, NULL
    // 0xbe7a6c: b.eq            #0xbe85f8
    // 0xbe7a70: LoadField: r6 = r0->field_7
    //     0xbe7a70: ldur            w6, [x0, #7]
    // 0xbe7a74: DecompressPointer r6
    //     0xbe7a74: add             x6, x6, HEAP, lsl #32
    // 0xbe7a78: stur            x6, [fp, #-0x48]
    // 0xbe7a7c: cmp             w6, NULL
    // 0xbe7a80: b.eq            #0xbe85fc
    // 0xbe7a84: mov             x0, x6
    // 0xbe7a88: r2 = Null
    //     0xbe7a88: mov             x2, NULL
    // 0xbe7a8c: r1 = Null
    //     0xbe7a8c: mov             x1, NULL
    // 0xbe7a90: r4 = LoadClassIdInstr(r0)
    //     0xbe7a90: ldur            x4, [x0, #-1]
    //     0xbe7a94: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7a98: r17 = -4183
    //     0xbe7a98: mov             x17, #-0x1057
    // 0xbe7a9c: add             x4, x4, x17
    // 0xbe7aa0: cmp             x4, #1
    // 0xbe7aa4: b.ls            #0xbe7abc
    // 0xbe7aa8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe7aa8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe7aac: ldr             x8, [x8, #0x590]
    // 0xbe7ab0: r3 = Null
    //     0xbe7ab0: add             x3, PP, #0x96, lsl #12  ; [pp+0x968e8] Null
    //     0xbe7ab4: ldr             x3, [x3, #0x8e8]
    // 0xbe7ab8: r0 = DefaultTypeTest()
    //     0xbe7ab8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe7abc: ldur            x0, [fp, #-0x48]
    // 0xbe7ac0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe7ac0: ldur            w1, [x0, #0x17]
    // 0xbe7ac4: DecompressPointer r1
    //     0xbe7ac4: add             x1, x1, HEAP, lsl #32
    // 0xbe7ac8: cmp             w1, NULL
    // 0xbe7acc: b.eq            #0xbe8600
    // 0xbe7ad0: r0 = LoadInt32Instr(r1)
    //     0xbe7ad0: sbfx            x0, x1, #1, #0x1f
    //     0xbe7ad4: tbz             w1, #0, #0xbe7adc
    //     0xbe7ad8: ldur            x0, [x1, #7]
    // 0xbe7adc: sub             x1, x0, #1
    // 0xbe7ae0: ldur            x0, [fp, #-0x20]
    // 0xbe7ae4: LoadField: r2 = r0->field_7
    //     0xbe7ae4: ldur            x2, [x0, #7]
    // 0xbe7ae8: stur            x2, [fp, #-0x60]
    // 0xbe7aec: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbe7aec: ldur            d0, [x0, #0x17]
    // 0xbe7af0: stur            d0, [fp, #-0xc8]
    // 0xbe7af4: LoadField: d1 = r0->field_f
    //     0xbe7af4: ldur            d1, [x0, #0xf]
    // 0xbe7af8: stur            d1, [fp, #-0xc0]
    // 0xbe7afc: LoadField: r3 = r0->field_2f
    //     0xbe7afc: ldur            w3, [x0, #0x2f]
    // 0xbe7b00: DecompressPointer r3
    //     0xbe7b00: add             x3, x3, HEAP, lsl #32
    // 0xbe7b04: stur            x3, [fp, #-0x58]
    // 0xbe7b08: LoadField: d2 = r0->field_1f
    //     0xbe7b08: ldur            d2, [x0, #0x1f]
    // 0xbe7b0c: stur            d2, [fp, #-0xb8]
    // 0xbe7b10: LoadField: d3 = r0->field_27
    //     0xbe7b10: ldur            d3, [x0, #0x27]
    // 0xbe7b14: stur            d3, [fp, #-0xb0]
    // 0xbe7b18: r0 = inline_Allocate_Double()
    //     0xbe7b18: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbe7b1c: add             x0, x0, #0x10
    //     0xbe7b20: cmp             x4, x0
    //     0xbe7b24: b.ls            #0xbe8604
    //     0xbe7b28: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe7b2c: sub             x0, x0, #0xf
    //     0xbe7b30: mov             x4, #0xe19c
    //     0xbe7b34: movk            x4, #3, lsl #16
    //     0xbe7b38: stur            x4, [x0, #-1]
    // 0xbe7b3c: dmb             ishst
    // 0xbe7b40: StoreField: r0->field_7 = d2
    //     0xbe7b40: stur            d2, [x0, #7]
    // 0xbe7b44: stur            x0, [fp, #-0x50]
    // 0xbe7b48: r4 = inline_Allocate_Double()
    //     0xbe7b48: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbe7b4c: add             x4, x4, #0x10
    //     0xbe7b50: cmp             x5, x4
    //     0xbe7b54: b.ls            #0xbe862c
    //     0xbe7b58: str             x4, [THR, #0x60]  ; THR::top
    //     0xbe7b5c: sub             x4, x4, #0xf
    //     0xbe7b60: mov             x5, #0xe19c
    //     0xbe7b64: movk            x5, #3, lsl #16
    //     0xbe7b68: stur            x5, [x4, #-1]
    // 0xbe7b6c: dmb             ishst
    // 0xbe7b70: StoreField: r4->field_7 = d3
    //     0xbe7b70: stur            d3, [x4, #7]
    // 0xbe7b74: stur            x4, [fp, #-0x48]
    // 0xbe7b78: scvtf           d4, x2
    // 0xbe7b7c: fmul            d5, d4, d0
    // 0xbe7b80: stur            d5, [fp, #-0xa8]
    // 0xbe7b84: fsub            d4, d0, d3
    // 0xbe7b88: stur            d4, [fp, #-0xa0]
    // 0xbe7b8c: ldur            d6, [fp, #-0x78]
    // 0xbe7b90: mov             x6, x1
    // 0xbe7b94: r7 = Null
    //     0xbe7b94: mov             x7, NULL
    // 0xbe7b98: ldur            x5, [fp, #-0x30]
    // 0xbe7b9c: stur            x7, [fp, #-0x20]
    // 0xbe7ba0: stur            x6, [fp, #-0x38]
    // 0xbe7ba4: stur            d6, [fp, #-0x98]
    // 0xbe7ba8: CheckStackOverflow
    //     0xbe7ba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe7bac: cmp             SP, x16
    //     0xbe7bb0: b.ls            #0xbe8658
    // 0xbe7bb4: cmp             x6, x5
    // 0xbe7bb8: b.lt            #0xbe7d80
    // 0xbe7bbc: cbz             x2, #0xbe8660
    // 0xbe7bc0: sdiv            x8, x6, x2
    // 0xbe7bc4: msub            x1, x8, x2, x6
    // 0xbe7bc8: cmp             x1, xzr
    // 0xbe7bcc: b.lt            #0xbe8694
    // 0xbe7bd0: scvtf           d7, x1
    // 0xbe7bd4: fmul            d8, d7, d0
    // 0xbe7bd8: cbz             x2, #0xbe86a8
    // 0xbe7bdc: sdiv            x1, x6, x2
    // 0xbe7be0: scvtf           d7, x1
    // 0xbe7be4: fmul            d9, d7, d1
    // 0xbe7be8: stur            d9, [fp, #-0x90]
    // 0xbe7bec: tbnz            w3, #4, #0xbe7c00
    // 0xbe7bf0: fsub            d7, d5, d8
    // 0xbe7bf4: fsub            d8, d7, d3
    // 0xbe7bf8: fsub            d7, d8, d4
    // 0xbe7bfc: b               #0xbe7c04
    // 0xbe7c00: mov             v7.16b, v8.16b
    // 0xbe7c04: stur            d7, [fp, #-0x78]
    // 0xbe7c08: stp             x0, x0, [SP, #8]
    // 0xbe7c0c: str             x4, [SP]
    // 0xbe7c10: ldur            x1, [fp, #-8]
    // 0xbe7c14: r4 = const [0, 0x4, 0x3, 0x1, crossAxisExtent, 0x3, maxExtent, 0x2, minExtent, 0x1, null]
    //     0xbe7c14: add             x4, PP, #0x96, lsl #12  ; [pp+0x968f8] List(11) [0, 0x4, 0x3, 0x1, "crossAxisExtent", 0x3, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0xbe7c18: ldr             x4, [x4, #0x8f8]
    // 0xbe7c1c: r0 = asBoxConstraints()
    //     0xbe7c1c: bl              #0xbe58b0  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0xbe7c20: ldur            x1, [fp, #-0x10]
    // 0xbe7c24: mov             x2, x0
    // 0xbe7c28: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbe7c28: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbe7c2c: r0 = insertAndLayoutLeadingChild()
    //     0xbe7c2c: bl              #0xbe5694  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutLeadingChild
    // 0xbe7c30: mov             x3, x0
    // 0xbe7c34: stur            x3, [fp, #-0x70]
    // 0xbe7c38: cmp             w3, NULL
    // 0xbe7c3c: b.eq            #0xbe86dc
    // 0xbe7c40: LoadField: r4 = r3->field_7
    //     0xbe7c40: ldur            w4, [x3, #7]
    // 0xbe7c44: DecompressPointer r4
    //     0xbe7c44: add             x4, x4, HEAP, lsl #32
    // 0xbe7c48: stur            x4, [fp, #-0x68]
    // 0xbe7c4c: cmp             w4, NULL
    // 0xbe7c50: b.eq            #0xbe86e0
    // 0xbe7c54: mov             x0, x4
    // 0xbe7c58: r2 = Null
    //     0xbe7c58: mov             x2, NULL
    // 0xbe7c5c: r1 = Null
    //     0xbe7c5c: mov             x1, NULL
    // 0xbe7c60: r4 = LoadClassIdInstr(r0)
    //     0xbe7c60: ldur            x4, [x0, #-1]
    //     0xbe7c64: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7c68: r17 = 4184
    //     0xbe7c68: mov             x17, #0x1058
    // 0xbe7c6c: cmp             x4, x17
    // 0xbe7c70: b.eq            #0xbe7c88
    // 0xbe7c74: r8 = SliverGridParentData
    //     0xbe7c74: add             x8, PP, #0x96, lsl #12  ; [pp+0x96900] Type: SliverGridParentData
    //     0xbe7c78: ldr             x8, [x8, #0x900]
    // 0xbe7c7c: r3 = Null
    //     0xbe7c7c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96908] Null
    //     0xbe7c80: ldr             x3, [x3, #0x908]
    // 0xbe7c84: r0 = DefaultTypeTest()
    //     0xbe7c84: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe7c88: ldur            d0, [fp, #-0x90]
    // 0xbe7c8c: r0 = inline_Allocate_Double()
    //     0xbe7c8c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe7c90: add             x0, x0, #0x10
    //     0xbe7c94: cmp             x1, x0
    //     0xbe7c98: b.ls            #0xbe86e4
    //     0xbe7c9c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe7ca0: sub             x0, x0, #0xf
    //     0xbe7ca4: mov             x1, #0xe19c
    //     0xbe7ca8: movk            x1, #3, lsl #16
    //     0xbe7cac: stur            x1, [x0, #-1]
    // 0xbe7cb0: dmb             ishst
    // 0xbe7cb4: StoreField: r0->field_7 = d0
    //     0xbe7cb4: stur            d0, [x0, #7]
    // 0xbe7cb8: ldur            x1, [fp, #-0x68]
    // 0xbe7cbc: StoreField: r1->field_7 = r0
    //     0xbe7cbc: stur            w0, [x1, #7]
    //     0xbe7cc0: ldurb           w16, [x1, #-1]
    //     0xbe7cc4: ldurb           w17, [x0, #-1]
    //     0xbe7cc8: and             x16, x17, x16, lsr #2
    //     0xbe7ccc: tst             x16, HEAP, lsr #32
    //     0xbe7cd0: b.eq            #0xbe7cd8
    //     0xbe7cd4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe7cd8: ldur            d1, [fp, #-0x78]
    // 0xbe7cdc: r0 = inline_Allocate_Double()
    //     0xbe7cdc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbe7ce0: add             x0, x0, #0x10
    //     0xbe7ce4: cmp             x2, x0
    //     0xbe7ce8: b.ls            #0xbe86f4
    //     0xbe7cec: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe7cf0: sub             x0, x0, #0xf
    //     0xbe7cf4: mov             x2, #0xe19c
    //     0xbe7cf8: movk            x2, #3, lsl #16
    //     0xbe7cfc: stur            x2, [x0, #-1]
    // 0xbe7d00: dmb             ishst
    // 0xbe7d04: StoreField: r0->field_7 = d1
    //     0xbe7d04: stur            d1, [x0, #7]
    // 0xbe7d08: StoreField: r1->field_1f = r0
    //     0xbe7d08: stur            w0, [x1, #0x1f]
    //     0xbe7d0c: ldurb           w16, [x1, #-1]
    //     0xbe7d10: ldurb           w17, [x0, #-1]
    //     0xbe7d14: and             x16, x17, x16, lsr #2
    //     0xbe7d18: tst             x16, HEAP, lsr #32
    //     0xbe7d1c: b.eq            #0xbe7d24
    //     0xbe7d20: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe7d24: ldur            x0, [fp, #-0x20]
    // 0xbe7d28: cmp             w0, NULL
    // 0xbe7d2c: b.ne            #0xbe7d38
    // 0xbe7d30: ldur            x7, [fp, #-0x70]
    // 0xbe7d34: b               #0xbe7d3c
    // 0xbe7d38: mov             x7, x0
    // 0xbe7d3c: ldur            d2, [fp, #-0x98]
    // 0xbe7d40: ldur            x0, [fp, #-0x38]
    // 0xbe7d44: ldur            d1, [fp, #-0xb8]
    // 0xbe7d48: fadd            d3, d0, d1
    // 0xbe7d4c: fmax            v6.2d, v2.2d, v3.2d
    // 0xbe7d50: sub             x6, x0, #1
    // 0xbe7d54: ldur            x2, [fp, #-0x60]
    // 0xbe7d58: ldur            d0, [fp, #-0xc8]
    // 0xbe7d5c: mov             v2.16b, v1.16b
    // 0xbe7d60: ldur            d1, [fp, #-0xc0]
    // 0xbe7d64: ldur            d3, [fp, #-0xb0]
    // 0xbe7d68: ldur            x3, [fp, #-0x58]
    // 0xbe7d6c: ldur            d5, [fp, #-0xa8]
    // 0xbe7d70: ldur            d4, [fp, #-0xa0]
    // 0xbe7d74: ldur            x0, [fp, #-0x50]
    // 0xbe7d78: ldur            x4, [fp, #-0x48]
    // 0xbe7d7c: b               #0xbe7b98
    // 0xbe7d80: mov             v1.16b, v2.16b
    // 0xbe7d84: mov             v2.16b, v6.16b
    // 0xbe7d88: mov             x0, x7
    // 0xbe7d8c: cmp             w0, NULL
    // 0xbe7d90: b.ne            #0xbe7ef4
    // 0xbe7d94: ldur            x0, [fp, #-0x10]
    // 0xbe7d98: ldur            x3, [fp, #-0x40]
    // 0xbe7d9c: ldur            d0, [fp, #-0x80]
    // 0xbe7da0: LoadField: r4 = r0->field_53
    //     0xbe7da0: ldur            w4, [x0, #0x53]
    // 0xbe7da4: DecompressPointer r4
    //     0xbe7da4: add             x4, x4, HEAP, lsl #32
    // 0xbe7da8: stur            x4, [fp, #-0x48]
    // 0xbe7dac: cmp             w4, NULL
    // 0xbe7db0: b.eq            #0xbe870c
    // 0xbe7db4: mov             x1, x3
    // 0xbe7db8: ldur            x2, [fp, #-8]
    // 0xbe7dbc: r0 = getBoxConstraints()
    //     0xbe7dbc: bl              #0xbe8860  ; [package:flutter/src/rendering/sliver_grid.dart] SliverGridGeometry::getBoxConstraints
    // 0xbe7dc0: ldur            x1, [fp, #-0x48]
    // 0xbe7dc4: r2 = LoadClassIdInstr(r1)
    //     0xbe7dc4: ldur            x2, [x1, #-1]
    //     0xbe7dc8: ubfx            x2, x2, #0xc, #0x14
    // 0xbe7dcc: mov             x16, x0
    // 0xbe7dd0: mov             x0, x2
    // 0xbe7dd4: mov             x2, x16
    // 0xbe7dd8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbe7dd8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbe7ddc: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe7ddc: mov             x17, #0xe6b9
    //     0xbe7de0: add             lr, x0, x17
    //     0xbe7de4: ldr             lr, [x21, lr, lsl #3]
    //     0xbe7de8: blr             lr
    // 0xbe7dec: ldur            x3, [fp, #-0x10]
    // 0xbe7df0: LoadField: r4 = r3->field_53
    //     0xbe7df0: ldur            w4, [x3, #0x53]
    // 0xbe7df4: DecompressPointer r4
    //     0xbe7df4: add             x4, x4, HEAP, lsl #32
    // 0xbe7df8: stur            x4, [fp, #-0x50]
    // 0xbe7dfc: cmp             w4, NULL
    // 0xbe7e00: b.eq            #0xbe8710
    // 0xbe7e04: LoadField: r5 = r4->field_7
    //     0xbe7e04: ldur            w5, [x4, #7]
    // 0xbe7e08: DecompressPointer r5
    //     0xbe7e08: add             x5, x5, HEAP, lsl #32
    // 0xbe7e0c: stur            x5, [fp, #-0x48]
    // 0xbe7e10: cmp             w5, NULL
    // 0xbe7e14: b.eq            #0xbe8714
    // 0xbe7e18: mov             x0, x5
    // 0xbe7e1c: r2 = Null
    //     0xbe7e1c: mov             x2, NULL
    // 0xbe7e20: r1 = Null
    //     0xbe7e20: mov             x1, NULL
    // 0xbe7e24: r4 = LoadClassIdInstr(r0)
    //     0xbe7e24: ldur            x4, [x0, #-1]
    //     0xbe7e28: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7e2c: r17 = 4184
    //     0xbe7e2c: mov             x17, #0x1058
    // 0xbe7e30: cmp             x4, x17
    // 0xbe7e34: b.eq            #0xbe7e4c
    // 0xbe7e38: r8 = SliverGridParentData
    //     0xbe7e38: add             x8, PP, #0x96, lsl #12  ; [pp+0x96900] Type: SliverGridParentData
    //     0xbe7e3c: ldr             x8, [x8, #0x900]
    // 0xbe7e40: r3 = Null
    //     0xbe7e40: add             x3, PP, #0x96, lsl #12  ; [pp+0x96918] Null
    //     0xbe7e44: ldr             x3, [x3, #0x918]
    // 0xbe7e48: r0 = DefaultTypeTest()
    //     0xbe7e48: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe7e4c: ldur            d0, [fp, #-0x80]
    // 0xbe7e50: r0 = inline_Allocate_Double()
    //     0xbe7e50: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe7e54: add             x0, x0, #0x10
    //     0xbe7e58: cmp             x1, x0
    //     0xbe7e5c: b.ls            #0xbe8718
    //     0xbe7e60: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe7e64: sub             x0, x0, #0xf
    //     0xbe7e68: mov             x1, #0xe19c
    //     0xbe7e6c: movk            x1, #3, lsl #16
    //     0xbe7e70: stur            x1, [x0, #-1]
    // 0xbe7e74: dmb             ishst
    // 0xbe7e78: StoreField: r0->field_7 = d0
    //     0xbe7e78: stur            d0, [x0, #7]
    // 0xbe7e7c: ldur            x1, [fp, #-0x48]
    // 0xbe7e80: StoreField: r1->field_7 = r0
    //     0xbe7e80: stur            w0, [x1, #7]
    //     0xbe7e84: ldurb           w16, [x1, #-1]
    //     0xbe7e88: ldurb           w17, [x0, #-1]
    //     0xbe7e8c: and             x16, x17, x16, lsr #2
    //     0xbe7e90: tst             x16, HEAP, lsr #32
    //     0xbe7e94: b.eq            #0xbe7e9c
    //     0xbe7e98: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe7e9c: ldur            x0, [fp, #-0x40]
    // 0xbe7ea0: LoadField: d1 = r0->field_f
    //     0xbe7ea0: ldur            d1, [x0, #0xf]
    // 0xbe7ea4: r0 = inline_Allocate_Double()
    //     0xbe7ea4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbe7ea8: add             x0, x0, #0x10
    //     0xbe7eac: cmp             x2, x0
    //     0xbe7eb0: b.ls            #0xbe8728
    //     0xbe7eb4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe7eb8: sub             x0, x0, #0xf
    //     0xbe7ebc: mov             x2, #0xe19c
    //     0xbe7ec0: movk            x2, #3, lsl #16
    //     0xbe7ec4: stur            x2, [x0, #-1]
    // 0xbe7ec8: dmb             ishst
    // 0xbe7ecc: StoreField: r0->field_7 = d1
    //     0xbe7ecc: stur            d1, [x0, #7]
    // 0xbe7ed0: StoreField: r1->field_1f = r0
    //     0xbe7ed0: stur            w0, [x1, #0x1f]
    //     0xbe7ed4: ldurb           w16, [x1, #-1]
    //     0xbe7ed8: ldurb           w17, [x0, #-1]
    //     0xbe7edc: and             x16, x17, x16, lsr #2
    //     0xbe7ee0: tst             x16, HEAP, lsr #32
    //     0xbe7ee4: b.eq            #0xbe7eec
    //     0xbe7ee8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe7eec: ldur            x4, [fp, #-0x50]
    // 0xbe7ef0: b               #0xbe7efc
    // 0xbe7ef4: ldur            d0, [fp, #-0x80]
    // 0xbe7ef8: mov             x4, x0
    // 0xbe7efc: ldur            x3, [fp, #-0x60]
    // 0xbe7f00: ldur            d2, [fp, #-0xc8]
    // 0xbe7f04: ldur            d1, [fp, #-0xb8]
    // 0xbe7f08: ldur            d3, [fp, #-0xb0]
    // 0xbe7f0c: stur            x4, [fp, #-0x40]
    // 0xbe7f10: LoadField: r5 = r4->field_7
    //     0xbe7f10: ldur            w5, [x4, #7]
    // 0xbe7f14: DecompressPointer r5
    //     0xbe7f14: add             x5, x5, HEAP, lsl #32
    // 0xbe7f18: stur            x5, [fp, #-0x20]
    // 0xbe7f1c: cmp             w5, NULL
    // 0xbe7f20: b.eq            #0xbe8740
    // 0xbe7f24: mov             x0, x5
    // 0xbe7f28: r2 = Null
    //     0xbe7f28: mov             x2, NULL
    // 0xbe7f2c: r1 = Null
    //     0xbe7f2c: mov             x1, NULL
    // 0xbe7f30: r4 = LoadClassIdInstr(r0)
    //     0xbe7f30: ldur            x4, [x0, #-1]
    //     0xbe7f34: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7f38: r17 = -4183
    //     0xbe7f38: mov             x17, #-0x1057
    // 0xbe7f3c: add             x4, x4, x17
    // 0xbe7f40: cmp             x4, #1
    // 0xbe7f44: b.ls            #0xbe7f5c
    // 0xbe7f48: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe7f48: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe7f4c: ldr             x8, [x8, #0x590]
    // 0xbe7f50: r3 = Null
    //     0xbe7f50: add             x3, PP, #0x96, lsl #12  ; [pp+0x96928] Null
    //     0xbe7f54: ldr             x3, [x3, #0x928]
    // 0xbe7f58: r0 = DefaultTypeTest()
    //     0xbe7f58: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe7f5c: ldur            x0, [fp, #-0x20]
    // 0xbe7f60: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe7f60: ldur            w1, [x0, #0x17]
    // 0xbe7f64: DecompressPointer r1
    //     0xbe7f64: add             x1, x1, HEAP, lsl #32
    // 0xbe7f68: cmp             w1, NULL
    // 0xbe7f6c: b.eq            #0xbe8744
    // 0xbe7f70: r0 = LoadInt32Instr(r1)
    //     0xbe7f70: sbfx            x0, x1, #1, #0x1f
    //     0xbe7f74: tbz             w1, #0, #0xbe7f7c
    //     0xbe7f78: ldur            x0, [x1, #7]
    // 0xbe7f7c: add             x1, x0, #1
    // 0xbe7f80: ldur            d0, [fp, #-0xb8]
    // 0xbe7f84: r0 = inline_Allocate_Double()
    //     0xbe7f84: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbe7f88: add             x0, x0, #0x10
    //     0xbe7f8c: cmp             x2, x0
    //     0xbe7f90: b.ls            #0xbe8748
    //     0xbe7f94: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe7f98: sub             x0, x0, #0xf
    //     0xbe7f9c: mov             x2, #0xe19c
    //     0xbe7fa0: movk            x2, #3, lsl #16
    //     0xbe7fa4: stur            x2, [x0, #-1]
    // 0xbe7fa8: dmb             ishst
    // 0xbe7fac: StoreField: r0->field_7 = d0
    //     0xbe7fac: stur            d0, [x0, #7]
    // 0xbe7fb0: ldur            d1, [fp, #-0xb0]
    // 0xbe7fb4: stur            x0, [fp, #-0x50]
    // 0xbe7fb8: r2 = inline_Allocate_Double()
    //     0xbe7fb8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbe7fbc: add             x2, x2, #0x10
    //     0xbe7fc0: cmp             x3, x2
    //     0xbe7fc4: b.ls            #0xbe8760
    //     0xbe7fc8: str             x2, [THR, #0x60]  ; THR::top
    //     0xbe7fcc: sub             x2, x2, #0xf
    //     0xbe7fd0: mov             x3, #0xe19c
    //     0xbe7fd4: movk            x3, #3, lsl #16
    //     0xbe7fd8: stur            x3, [x2, #-1]
    // 0xbe7fdc: dmb             ishst
    // 0xbe7fe0: StoreField: r2->field_7 = d1
    //     0xbe7fe0: stur            d1, [x2, #7]
    // 0xbe7fe4: ldur            x3, [fp, #-0x60]
    // 0xbe7fe8: stur            x2, [fp, #-0x48]
    // 0xbe7fec: scvtf           d2, x3
    // 0xbe7ff0: ldur            d3, [fp, #-0xc8]
    // 0xbe7ff4: fmul            d4, d2, d3
    // 0xbe7ff8: stur            d4, [fp, #-0xa8]
    // 0xbe7ffc: fsub            d2, d3, d1
    // 0xbe8000: stur            d2, [fp, #-0xa0]
    // 0xbe8004: ldur            d6, [fp, #-0x98]
    // 0xbe8008: ldur            x7, [fp, #-0x40]
    // 0xbe800c: mov             x6, x1
    // 0xbe8010: ldur            x5, [fp, #-0x28]
    // 0xbe8014: ldur            d5, [fp, #-0xc0]
    // 0xbe8018: ldur            x4, [fp, #-0x58]
    // 0xbe801c: stur            x7, [fp, #-0x20]
    // 0xbe8020: stur            x6, [fp, #-0x38]
    // 0xbe8024: stur            d6, [fp, #-0x98]
    // 0xbe8028: CheckStackOverflow
    //     0xbe8028: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe802c: cmp             SP, x16
    //     0xbe8030: b.ls            #0xbe877c
    // 0xbe8034: cmp             w5, NULL
    // 0xbe8038: b.eq            #0xbe8050
    // 0xbe803c: r1 = LoadInt32Instr(r5)
    //     0xbe803c: sbfx            x1, x5, #1, #0x1f
    //     0xbe8040: tbz             w5, #0, #0xbe8048
    //     0xbe8044: ldur            x1, [x5, #7]
    // 0xbe8048: cmp             x6, x1
    // 0xbe804c: b.gt            #0xbe8340
    // 0xbe8050: cbz             x3, #0xbe8784
    // 0xbe8054: sdiv            x8, x6, x3
    // 0xbe8058: msub            x1, x8, x3, x6
    // 0xbe805c: cmp             x1, xzr
    // 0xbe8060: b.lt            #0xbe87b8
    // 0xbe8064: scvtf           d7, x1
    // 0xbe8068: fmul            d8, d7, d3
    // 0xbe806c: cbz             x3, #0xbe87cc
    // 0xbe8070: sdiv            x1, x6, x3
    // 0xbe8074: scvtf           d7, x1
    // 0xbe8078: fmul            d9, d7, d5
    // 0xbe807c: stur            d9, [fp, #-0x90]
    // 0xbe8080: tbnz            w4, #4, #0xbe8094
    // 0xbe8084: fsub            d7, d4, d8
    // 0xbe8088: fsub            d8, d7, d1
    // 0xbe808c: fsub            d7, d8, d2
    // 0xbe8090: b               #0xbe8098
    // 0xbe8094: mov             v7.16b, v8.16b
    // 0xbe8098: stur            d7, [fp, #-0x78]
    // 0xbe809c: stp             x0, x0, [SP, #8]
    // 0xbe80a0: str             x2, [SP]
    // 0xbe80a4: ldur            x1, [fp, #-8]
    // 0xbe80a8: r4 = const [0, 0x4, 0x3, 0x1, crossAxisExtent, 0x3, maxExtent, 0x2, minExtent, 0x1, null]
    //     0xbe80a8: add             x4, PP, #0x96, lsl #12  ; [pp+0x968f8] List(11) [0, 0x4, 0x3, 0x1, "crossAxisExtent", 0x3, "maxExtent", 0x2, "minExtent", 0x1, Null]
    //     0xbe80ac: ldr             x4, [x4, #0x8f8]
    // 0xbe80b0: r0 = asBoxConstraints()
    //     0xbe80b0: bl              #0xbe58b0  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::asBoxConstraints
    // 0xbe80b4: mov             x4, x0
    // 0xbe80b8: ldur            x3, [fp, #-0x20]
    // 0xbe80bc: stur            x4, [fp, #-0x68]
    // 0xbe80c0: LoadField: r5 = r3->field_7
    //     0xbe80c0: ldur            w5, [x3, #7]
    // 0xbe80c4: DecompressPointer r5
    //     0xbe80c4: add             x5, x5, HEAP, lsl #32
    // 0xbe80c8: stur            x5, [fp, #-0x40]
    // 0xbe80cc: cmp             w5, NULL
    // 0xbe80d0: b.eq            #0xbe8800
    // 0xbe80d4: mov             x0, x5
    // 0xbe80d8: r2 = Null
    //     0xbe80d8: mov             x2, NULL
    // 0xbe80dc: r1 = Null
    //     0xbe80dc: mov             x1, NULL
    // 0xbe80e0: r4 = LoadClassIdInstr(r0)
    //     0xbe80e0: ldur            x4, [x0, #-1]
    //     0xbe80e4: ubfx            x4, x4, #0xc, #0x14
    // 0xbe80e8: r17 = -4183
    //     0xbe80e8: mov             x17, #-0x1057
    // 0xbe80ec: add             x4, x4, x17
    // 0xbe80f0: cmp             x4, #1
    // 0xbe80f4: b.ls            #0xbe810c
    // 0xbe80f8: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe80f8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe80fc: ldr             x8, [x8, #0x590]
    // 0xbe8100: r3 = Null
    //     0xbe8100: add             x3, PP, #0x96, lsl #12  ; [pp+0x96938] Null
    //     0xbe8104: ldr             x3, [x3, #0x938]
    // 0xbe8108: r0 = DefaultTypeTest()
    //     0xbe8108: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe810c: ldur            x0, [fp, #-0x40]
    // 0xbe8110: LoadField: r3 = r0->field_f
    //     0xbe8110: ldur            w3, [x0, #0xf]
    // 0xbe8114: DecompressPointer r3
    //     0xbe8114: add             x3, x3, HEAP, lsl #32
    // 0xbe8118: stur            x3, [fp, #-0x70]
    // 0xbe811c: cmp             w3, NULL
    // 0xbe8120: b.ne            #0xbe812c
    // 0xbe8124: ldur            x4, [fp, #-0x38]
    // 0xbe8128: b               #0xbe81a8
    // 0xbe812c: ldur            x4, [fp, #-0x38]
    // 0xbe8130: LoadField: r5 = r3->field_7
    //     0xbe8130: ldur            w5, [x3, #7]
    // 0xbe8134: DecompressPointer r5
    //     0xbe8134: add             x5, x5, HEAP, lsl #32
    // 0xbe8138: stur            x5, [fp, #-0x40]
    // 0xbe813c: cmp             w5, NULL
    // 0xbe8140: b.eq            #0xbe8804
    // 0xbe8144: mov             x0, x5
    // 0xbe8148: r2 = Null
    //     0xbe8148: mov             x2, NULL
    // 0xbe814c: r1 = Null
    //     0xbe814c: mov             x1, NULL
    // 0xbe8150: r4 = LoadClassIdInstr(r0)
    //     0xbe8150: ldur            x4, [x0, #-1]
    //     0xbe8154: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8158: r17 = -4183
    //     0xbe8158: mov             x17, #-0x1057
    // 0xbe815c: add             x4, x4, x17
    // 0xbe8160: cmp             x4, #1
    // 0xbe8164: b.ls            #0xbe817c
    // 0xbe8168: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe8168: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe816c: ldr             x8, [x8, #0x590]
    // 0xbe8170: r3 = Null
    //     0xbe8170: add             x3, PP, #0x96, lsl #12  ; [pp+0x96948] Null
    //     0xbe8174: ldr             x3, [x3, #0x948]
    // 0xbe8178: r0 = DefaultTypeTest()
    //     0xbe8178: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe817c: ldur            x0, [fp, #-0x40]
    // 0xbe8180: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe8180: ldur            w1, [x0, #0x17]
    // 0xbe8184: DecompressPointer r1
    //     0xbe8184: add             x1, x1, HEAP, lsl #32
    // 0xbe8188: cmp             w1, NULL
    // 0xbe818c: b.eq            #0xbe8808
    // 0xbe8190: r0 = LoadInt32Instr(r1)
    //     0xbe8190: sbfx            x0, x1, #1, #0x1f
    //     0xbe8194: tbz             w1, #0, #0xbe819c
    //     0xbe8198: ldur            x0, [x1, #7]
    // 0xbe819c: ldur            x4, [fp, #-0x38]
    // 0xbe81a0: cmp             x0, x4
    // 0xbe81a4: b.eq            #0xbe81d8
    // 0xbe81a8: ldur            x1, [fp, #-0x10]
    // 0xbe81ac: ldur            x2, [fp, #-0x68]
    // 0xbe81b0: ldur            x3, [fp, #-0x20]
    // 0xbe81b4: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xbe81b4: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xbe81b8: r0 = insertAndLayoutChild()
    //     0xbe81b8: bl              #0xbe4bac  ; [package:flutter/src/rendering/sliver_multi_box_adaptor.dart] RenderSliverMultiBoxAdaptor::insertAndLayoutChild
    // 0xbe81bc: cmp             w0, NULL
    // 0xbe81c0: b.eq            #0xbe81cc
    // 0xbe81c4: mov             x7, x0
    // 0xbe81c8: b               #0xbe8204
    // 0xbe81cc: ldur            d0, [fp, #-0x98]
    // 0xbe81d0: r4 = true
    //     0xbe81d0: add             x4, NULL, #0x20  ; true
    // 0xbe81d4: b               #0xbe8348
    // 0xbe81d8: ldur            x3, [fp, #-0x70]
    // 0xbe81dc: r0 = LoadClassIdInstr(r3)
    //     0xbe81dc: ldur            x0, [x3, #-1]
    //     0xbe81e0: ubfx            x0, x0, #0xc, #0x14
    // 0xbe81e4: mov             x1, x3
    // 0xbe81e8: ldur            x2, [fp, #-0x68]
    // 0xbe81ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbe81ec: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbe81f0: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbe81f0: mov             x17, #0xe6b9
    //     0xbe81f4: add             lr, x0, x17
    //     0xbe81f8: ldr             lr, [x21, lr, lsl #3]
    //     0xbe81fc: blr             lr
    // 0xbe8200: ldur            x7, [fp, #-0x70]
    // 0xbe8204: ldur            d1, [fp, #-0x98]
    // 0xbe8208: ldur            x3, [fp, #-0x38]
    // 0xbe820c: ldur            d2, [fp, #-0x90]
    // 0xbe8210: ldur            d0, [fp, #-0xb8]
    // 0xbe8214: ldur            d3, [fp, #-0x78]
    // 0xbe8218: stur            x7, [fp, #-0x40]
    // 0xbe821c: LoadField: r4 = r7->field_7
    //     0xbe821c: ldur            w4, [x7, #7]
    // 0xbe8220: DecompressPointer r4
    //     0xbe8220: add             x4, x4, HEAP, lsl #32
    // 0xbe8224: stur            x4, [fp, #-0x20]
    // 0xbe8228: cmp             w4, NULL
    // 0xbe822c: b.eq            #0xbe880c
    // 0xbe8230: mov             x0, x4
    // 0xbe8234: r2 = Null
    //     0xbe8234: mov             x2, NULL
    // 0xbe8238: r1 = Null
    //     0xbe8238: mov             x1, NULL
    // 0xbe823c: r4 = LoadClassIdInstr(r0)
    //     0xbe823c: ldur            x4, [x0, #-1]
    //     0xbe8240: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8244: r17 = 4184
    //     0xbe8244: mov             x17, #0x1058
    // 0xbe8248: cmp             x4, x17
    // 0xbe824c: b.eq            #0xbe8264
    // 0xbe8250: r8 = SliverGridParentData
    //     0xbe8250: add             x8, PP, #0x96, lsl #12  ; [pp+0x96900] Type: SliverGridParentData
    //     0xbe8254: ldr             x8, [x8, #0x900]
    // 0xbe8258: r3 = Null
    //     0xbe8258: add             x3, PP, #0x96, lsl #12  ; [pp+0x96958] Null
    //     0xbe825c: ldr             x3, [x3, #0x958]
    // 0xbe8260: r0 = DefaultTypeTest()
    //     0xbe8260: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe8264: ldur            d0, [fp, #-0x90]
    // 0xbe8268: r0 = inline_Allocate_Double()
    //     0xbe8268: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe826c: add             x0, x0, #0x10
    //     0xbe8270: cmp             x1, x0
    //     0xbe8274: b.ls            #0xbe8810
    //     0xbe8278: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe827c: sub             x0, x0, #0xf
    //     0xbe8280: mov             x1, #0xe19c
    //     0xbe8284: movk            x1, #3, lsl #16
    //     0xbe8288: stur            x1, [x0, #-1]
    // 0xbe828c: dmb             ishst
    // 0xbe8290: StoreField: r0->field_7 = d0
    //     0xbe8290: stur            d0, [x0, #7]
    // 0xbe8294: ldur            x1, [fp, #-0x20]
    // 0xbe8298: StoreField: r1->field_7 = r0
    //     0xbe8298: stur            w0, [x1, #7]
    //     0xbe829c: ldurb           w16, [x1, #-1]
    //     0xbe82a0: ldurb           w17, [x0, #-1]
    //     0xbe82a4: and             x16, x17, x16, lsr #2
    //     0xbe82a8: tst             x16, HEAP, lsr #32
    //     0xbe82ac: b.eq            #0xbe82b4
    //     0xbe82b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe82b4: ldur            d1, [fp, #-0x78]
    // 0xbe82b8: r0 = inline_Allocate_Double()
    //     0xbe82b8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xbe82bc: add             x0, x0, #0x10
    //     0xbe82c0: cmp             x2, x0
    //     0xbe82c4: b.ls            #0xbe8820
    //     0xbe82c8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe82cc: sub             x0, x0, #0xf
    //     0xbe82d0: mov             x2, #0xe19c
    //     0xbe82d4: movk            x2, #3, lsl #16
    //     0xbe82d8: stur            x2, [x0, #-1]
    // 0xbe82dc: dmb             ishst
    // 0xbe82e0: StoreField: r0->field_7 = d1
    //     0xbe82e0: stur            d1, [x0, #7]
    // 0xbe82e4: StoreField: r1->field_1f = r0
    //     0xbe82e4: stur            w0, [x1, #0x1f]
    //     0xbe82e8: ldurb           w16, [x1, #-1]
    //     0xbe82ec: ldurb           w17, [x0, #-1]
    //     0xbe82f0: and             x16, x17, x16, lsr #2
    //     0xbe82f4: tst             x16, HEAP, lsr #32
    //     0xbe82f8: b.eq            #0xbe8300
    //     0xbe82fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe8300: ldur            d1, [fp, #-0xb8]
    // 0xbe8304: fadd            d2, d0, d1
    // 0xbe8308: ldur            d0, [fp, #-0x98]
    // 0xbe830c: fmax            v6.2d, v0.2d, v2.2d
    // 0xbe8310: ldur            x0, [fp, #-0x38]
    // 0xbe8314: add             x6, x0, #1
    // 0xbe8318: ldur            x7, [fp, #-0x40]
    // 0xbe831c: ldur            x3, [fp, #-0x60]
    // 0xbe8320: ldur            d3, [fp, #-0xc8]
    // 0xbe8324: mov             v0.16b, v1.16b
    // 0xbe8328: ldur            d1, [fp, #-0xb0]
    // 0xbe832c: ldur            d4, [fp, #-0xa8]
    // 0xbe8330: ldur            d2, [fp, #-0xa0]
    // 0xbe8334: ldur            x0, [fp, #-0x50]
    // 0xbe8338: ldur            x2, [fp, #-0x48]
    // 0xbe833c: b               #0xbe8010
    // 0xbe8340: mov             v0.16b, v6.16b
    // 0xbe8344: r4 = false
    //     0xbe8344: add             x4, NULL, #0x30  ; false
    // 0xbe8348: ldur            x3, [fp, #-0x10]
    // 0xbe834c: stur            x4, [fp, #-0x28]
    // 0xbe8350: LoadField: r0 = r3->field_57
    //     0xbe8350: ldur            w0, [x3, #0x57]
    // 0xbe8354: DecompressPointer r0
    //     0xbe8354: add             x0, x0, HEAP, lsl #32
    // 0xbe8358: cmp             w0, NULL
    // 0xbe835c: b.eq            #0xbe8838
    // 0xbe8360: LoadField: r5 = r0->field_7
    //     0xbe8360: ldur            w5, [x0, #7]
    // 0xbe8364: DecompressPointer r5
    //     0xbe8364: add             x5, x5, HEAP, lsl #32
    // 0xbe8368: stur            x5, [fp, #-0x20]
    // 0xbe836c: cmp             w5, NULL
    // 0xbe8370: b.eq            #0xbe883c
    // 0xbe8374: mov             x0, x5
    // 0xbe8378: r2 = Null
    //     0xbe8378: mov             x2, NULL
    // 0xbe837c: r1 = Null
    //     0xbe837c: mov             x1, NULL
    // 0xbe8380: r4 = LoadClassIdInstr(r0)
    //     0xbe8380: ldur            x4, [x0, #-1]
    //     0xbe8384: ubfx            x4, x4, #0xc, #0x14
    // 0xbe8388: r17 = -4183
    //     0xbe8388: mov             x17, #-0x1057
    // 0xbe838c: add             x4, x4, x17
    // 0xbe8390: cmp             x4, #1
    // 0xbe8394: b.ls            #0xbe83ac
    // 0xbe8398: r8 = SliverMultiBoxAdaptorParentData
    //     0xbe8398: add             x8, PP, #0x96, lsl #12  ; [pp+0x96590] Type: SliverMultiBoxAdaptorParentData
    //     0xbe839c: ldr             x8, [x8, #0x590]
    // 0xbe83a0: r3 = Null
    //     0xbe83a0: add             x3, PP, #0x96, lsl #12  ; [pp+0x96968] Null
    //     0xbe83a4: ldr             x3, [x3, #0x968]
    // 0xbe83a8: r0 = DefaultTypeTest()
    //     0xbe83a8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbe83ac: ldur            x0, [fp, #-0x20]
    // 0xbe83b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbe83b0: ldur            w1, [x0, #0x17]
    // 0xbe83b4: DecompressPointer r1
    //     0xbe83b4: add             x1, x1, HEAP, lsl #32
    // 0xbe83b8: cmp             w1, NULL
    // 0xbe83bc: b.eq            #0xbe8840
    // 0xbe83c0: ldur            x0, [fp, #-0x28]
    // 0xbe83c4: tbnz            w0, #4, #0xbe83d0
    // 0xbe83c8: ldur            d4, [fp, #-0x98]
    // 0xbe83cc: b               #0xbe8424
    // 0xbe83d0: ldur            d1, [fp, #-0x80]
    // 0xbe83d4: r6 = inline_Allocate_Double()
    //     0xbe83d4: ldp             x6, x0, [THR, #0x60]  ; THR::top
    //     0xbe83d8: add             x6, x6, #0x10
    //     0xbe83dc: cmp             x0, x6
    //     0xbe83e0: b.ls            #0xbe8844
    //     0xbe83e4: str             x6, [THR, #0x60]  ; THR::top
    //     0xbe83e8: sub             x6, x6, #0xf
    //     0xbe83ec: mov             x0, #0xe19c
    //     0xbe83f0: movk            x0, #3, lsl #16
    //     0xbe83f4: stur            x0, [x6, #-1]
    // 0xbe83f8: dmb             ishst
    // 0xbe83fc: StoreField: r6->field_7 = d1
    //     0xbe83fc: stur            d1, [x6, #7]
    // 0xbe8400: r5 = LoadInt32Instr(r1)
    //     0xbe8400: sbfx            x5, x1, #1, #0x1f
    //     0xbe8404: tbz             w1, #0, #0xbe840c
    //     0xbe8408: ldur            x5, [x1, #7]
    // 0xbe840c: ldur            x1, [fp, #-0x18]
    // 0xbe8410: ldur            x2, [fp, #-8]
    // 0xbe8414: ldur            x3, [fp, #-0x30]
    // 0xbe8418: ldur            d0, [fp, #-0x98]
    // 0xbe841c: r0 = estimateMaxScrollOffset()
    //     0xbe841c: bl              #0xbe496c  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::estimateMaxScrollOffset
    // 0xbe8420: mov             v4.16b, v0.16b
    // 0xbe8424: ldur            d3, [fp, #-0x88]
    // 0xbe8428: ldur            d2, [fp, #-0x80]
    // 0xbe842c: stur            d4, [fp, #-0x78]
    // 0xbe8430: fmin            v0.2d, v3.2d, v2.2d
    // 0xbe8434: ldur            x1, [fp, #-0x10]
    // 0xbe8438: ldur            x2, [fp, #-8]
    // 0xbe843c: ldur            d1, [fp, #-0x98]
    // 0xbe8440: r0 = calculatePaintOffset()
    //     0xbe8440: bl              #0xbe483c  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculatePaintOffset
    // 0xbe8444: ldur            x1, [fp, #-0x10]
    // 0xbe8448: ldur            x2, [fp, #-8]
    // 0xbe844c: mov             v2.16b, v0.16b
    // 0xbe8450: ldur            d0, [fp, #-0x80]
    // 0xbe8454: ldur            d1, [fp, #-0x98]
    // 0xbe8458: stur            d2, [fp, #-0x80]
    // 0xbe845c: r0 = calculateCacheOffset()
    //     0xbe845c: bl              #0xbe4790  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::calculateCacheOffset
    // 0xbe8460: mov             v2.16b, v0.16b
    // 0xbe8464: ldur            d1, [fp, #-0x78]
    // 0xbe8468: ldur            d0, [fp, #-0x80]
    // 0xbe846c: stur            d2, [fp, #-0x90]
    // 0xbe8470: fcmp            d1, d0
    // 0xbe8474: b.le            #0xbe8480
    // 0xbe8478: d4 = 0.000000
    //     0xbe8478: eor             v4.16b, v4.16b, v4.16b
    // 0xbe847c: b               #0xbe8490
    // 0xbe8480: ldur            d3, [fp, #-0x88]
    // 0xbe8484: d4 = 0.000000
    //     0xbe8484: eor             v4.16b, v4.16b, v4.16b
    // 0xbe8488: fcmp            d3, d4
    // 0xbe848c: b.le            #0xbe8498
    // 0xbe8490: r1 = true
    //     0xbe8490: add             x1, NULL, #0x20  ; true
    // 0xbe8494: b               #0xbe84b4
    // 0xbe8498: ldur            x0, [fp, #-8]
    // 0xbe849c: LoadField: d3 = r0->field_23
    //     0xbe849c: ldur            d3, [x0, #0x23]
    // 0xbe84a0: fcmp            d3, d4
    // 0xbe84a4: r16 = true
    //     0xbe84a4: add             x16, NULL, #0x20  ; true
    // 0xbe84a8: r17 = false
    //     0xbe84a8: add             x17, NULL, #0x30  ; false
    // 0xbe84ac: csel            x0, x16, x17, ne
    // 0xbe84b0: mov             x1, x0
    // 0xbe84b4: ldur            x0, [fp, #-0x10]
    // 0xbe84b8: ldur            d3, [fp, #-0x98]
    // 0xbe84bc: stur            x1, [fp, #-8]
    // 0xbe84c0: r0 = SliverGeometry()
    //     0xbe84c0: bl              #0xbe5bdc  ; AllocateSliverGeometryStub -> SliverGeometry (size=0x58)
    // 0xbe84c4: ldur            d0, [fp, #-0x78]
    // 0xbe84c8: StoreField: r0->field_7 = d0
    //     0xbe84c8: stur            d0, [x0, #7]
    // 0xbe84cc: ldur            d1, [fp, #-0x80]
    // 0xbe84d0: ArrayStore: r0[0] = d1  ; List_8
    //     0xbe84d0: stur            d1, [x0, #0x17]
    // 0xbe84d4: StoreField: r0->field_f = rZR
    //     0xbe84d4: stur            xzr, [x0, #0xf]
    // 0xbe84d8: StoreField: r0->field_27 = d0
    //     0xbe84d8: stur            d0, [x0, #0x27]
    // 0xbe84dc: StoreField: r0->field_2f = rZR
    //     0xbe84dc: stur            xzr, [x0, #0x2f]
    // 0xbe84e0: ldur            x1, [fp, #-8]
    // 0xbe84e4: StoreField: r0->field_43 = r1
    //     0xbe84e4: stur            w1, [x0, #0x43]
    // 0xbe84e8: StoreField: r0->field_1f = d1
    //     0xbe84e8: stur            d1, [x0, #0x1f]
    // 0xbe84ec: StoreField: r0->field_37 = d1
    //     0xbe84ec: stur            d1, [x0, #0x37]
    // 0xbe84f0: ldur            d2, [fp, #-0x90]
    // 0xbe84f4: StoreField: r0->field_4b = d2
    //     0xbe84f4: stur            d2, [x0, #0x4b]
    // 0xbe84f8: d2 = 0.000000
    //     0xbe84f8: eor             v2.16b, v2.16b, v2.16b
    // 0xbe84fc: fcmp            d1, d2
    // 0xbe8500: r16 = true
    //     0xbe8500: add             x16, NULL, #0x20  ; true
    // 0xbe8504: r17 = false
    //     0xbe8504: add             x17, NULL, #0x30  ; false
    // 0xbe8508: csel            x1, x16, x17, gt
    // 0xbe850c: StoreField: r0->field_3f = r1
    //     0xbe850c: stur            w1, [x0, #0x3f]
    // 0xbe8510: ldur            x1, [fp, #-0x10]
    // 0xbe8514: StoreField: r1->field_47 = r0
    //     0xbe8514: stur            w0, [x1, #0x47]
    //     0xbe8518: ldurb           w16, [x1, #-1]
    //     0xbe851c: ldurb           w17, [x0, #-1]
    //     0xbe8520: and             x16, x17, x16, lsr #2
    //     0xbe8524: tst             x16, HEAP, lsr #32
    //     0xbe8528: b.eq            #0xbe8530
    //     0xbe852c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe8530: ldur            d1, [fp, #-0x98]
    // 0xbe8534: fcmp            d0, d1
    // 0xbe8538: b.ne            #0xbe854c
    // 0xbe853c: ldur            x1, [fp, #-0x18]
    // 0xbe8540: r0 = true
    //     0xbe8540: add             x0, NULL, #0x20  ; true
    // 0xbe8544: StoreField: r1->field_53 = r0
    //     0xbe8544: stur            w0, [x1, #0x53]
    // 0xbe8548: b               #0xbe8550
    // 0xbe854c: ldur            x1, [fp, #-0x18]
    // 0xbe8550: r0 = didFinishLayout()
    //     0xbe8550: bl              #0xbe5ab0  ; [package:flutter/src/widgets/sliver.dart] SliverMultiBoxAdaptorElement::didFinishLayout
    // 0xbe8554: r0 = Null
    //     0xbe8554: mov             x0, NULL
    // 0xbe8558: LeaveFrame
    //     0xbe8558: mov             SP, fp
    //     0xbe855c: ldp             fp, lr, [SP], #0x10
    // 0xbe8560: ret
    //     0xbe8560: ret             
    // 0xbe8564: r0 = StateError()
    //     0xbe8564: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe8568: mov             x1, x0
    // 0xbe856c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe856c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe8570: StoreField: r1->field_b = r0
    //     0xbe8570: stur            w0, [x1, #0xb]
    // 0xbe8574: mov             x0, x1
    // 0xbe8578: r0 = Throw()
    //     0xbe8578: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe857c: brk             #0
    // 0xbe8580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe8580: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe8584: b               #0xbe76e4
    // 0xbe8588: stp             q1, q3, [SP, #-0x20]!
    // 0xbe858c: stp             x3, x4, [SP, #-0x10]!
    // 0xbe8590: SaveReg r2
    //     0xbe8590: str             x2, [SP, #-8]!
    // 0xbe8594: d0 = 0.000000
    //     0xbe8594: fmov            d0, d3
    // 0xbe8598: r0 = 66
    //     0xbe8598: mov             x0, #0x42
    // 0xbe859c: r30 = DoubleToIntegerStub
    //     0xbe859c: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xbe85a0: LoadField: r30 = r30->field_7
    //     0xbe85a0: ldur            lr, [lr, #7]
    // 0xbe85a4: blr             lr
    // 0xbe85a8: RestoreReg r2
    //     0xbe85a8: ldr             x2, [SP], #8
    // 0xbe85ac: ldp             x3, x4, [SP], #0x10
    // 0xbe85b0: ldp             q1, q3, [SP], #0x20
    // 0xbe85b4: b               #0xbe77f4
    // 0xbe85b8: SaveReg d0
    //     0xbe85b8: str             q0, [SP, #-0x10]!
    // 0xbe85bc: stp             x3, x4, [SP, #-0x10]!
    // 0xbe85c0: stp             x0, x2, [SP, #-0x10]!
    // 0xbe85c4: r0 = AllocateDouble()
    //     0xbe85c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe85c8: mov             x1, x0
    // 0xbe85cc: ldp             x0, x2, [SP], #0x10
    // 0xbe85d0: ldp             x3, x4, [SP], #0x10
    // 0xbe85d4: RestoreReg d0
    //     0xbe85d4: ldr             q0, [SP], #0x10
    // 0xbe85d8: b               #0xbe7944
    // 0xbe85dc: stp             x1, x3, [SP, #-0x10]!
    // 0xbe85e0: SaveReg r0
    //     0xbe85e0: str             x0, [SP, #-8]!
    // 0xbe85e4: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xbe85e8: r4 = 0
    //     0xbe85e8: mov             x4, #0
    // 0xbe85ec: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xbe85f0: blr             lr
    // 0xbe85f4: brk             #0
    // 0xbe85f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe85f8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe85fc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe85fc: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe8600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe8600: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe8604: stp             q2, q3, [SP, #-0x20]!
    // 0xbe8608: stp             q0, q1, [SP, #-0x20]!
    // 0xbe860c: stp             x2, x3, [SP, #-0x10]!
    // 0xbe8610: SaveReg r1
    //     0xbe8610: str             x1, [SP, #-8]!
    // 0xbe8614: r0 = AllocateDouble()
    //     0xbe8614: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8618: RestoreReg r1
    //     0xbe8618: ldr             x1, [SP], #8
    // 0xbe861c: ldp             x2, x3, [SP], #0x10
    // 0xbe8620: ldp             q0, q1, [SP], #0x20
    // 0xbe8624: ldp             q2, q3, [SP], #0x20
    // 0xbe8628: b               #0xbe7b40
    // 0xbe862c: stp             q2, q3, [SP, #-0x20]!
    // 0xbe8630: stp             q0, q1, [SP, #-0x20]!
    // 0xbe8634: stp             x2, x3, [SP, #-0x10]!
    // 0xbe8638: stp             x0, x1, [SP, #-0x10]!
    // 0xbe863c: r0 = AllocateDouble()
    //     0xbe863c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8640: mov             x4, x0
    // 0xbe8644: ldp             x0, x1, [SP], #0x10
    // 0xbe8648: ldp             x2, x3, [SP], #0x10
    // 0xbe864c: ldp             q0, q1, [SP], #0x20
    // 0xbe8650: ldp             q2, q3, [SP], #0x20
    // 0xbe8654: b               #0xbe7b70
    // 0xbe8658: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe8658: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe865c: b               #0xbe7bb4
    // 0xbe8660: stp             q5, q6, [SP, #-0x20]!
    // 0xbe8664: stp             q3, q4, [SP, #-0x20]!
    // 0xbe8668: stp             q1, q2, [SP, #-0x20]!
    // 0xbe866c: SaveReg d0
    //     0xbe866c: str             q0, [SP, #-0x10]!
    // 0xbe8670: stp             x6, x7, [SP, #-0x10]!
    // 0xbe8674: stp             x4, x5, [SP, #-0x10]!
    // 0xbe8678: stp             x2, x3, [SP, #-0x10]!
    // 0xbe867c: SaveReg r0
    //     0xbe867c: str             x0, [SP, #-8]!
    // 0xbe8680: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xbe8684: r4 = 0
    //     0xbe8684: mov             x4, #0
    // 0xbe8688: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xbe868c: blr             lr
    // 0xbe8690: brk             #0
    // 0xbe8694: cmp             x2, xzr
    // 0xbe8698: sub             x8, x1, x2
    // 0xbe869c: add             x1, x1, x2
    // 0xbe86a0: csel            x1, x8, x1, lt
    // 0xbe86a4: b               #0xbe7bd0
    // 0xbe86a8: stp             q6, q8, [SP, #-0x20]!
    // 0xbe86ac: stp             q4, q5, [SP, #-0x20]!
    // 0xbe86b0: stp             q2, q3, [SP, #-0x20]!
    // 0xbe86b4: stp             q0, q1, [SP, #-0x20]!
    // 0xbe86b8: stp             x6, x7, [SP, #-0x10]!
    // 0xbe86bc: stp             x4, x5, [SP, #-0x10]!
    // 0xbe86c0: stp             x2, x3, [SP, #-0x10]!
    // 0xbe86c4: SaveReg r0
    //     0xbe86c4: str             x0, [SP, #-8]!
    // 0xbe86c8: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xbe86cc: r4 = 0
    //     0xbe86cc: mov             x4, #0
    // 0xbe86d0: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xbe86d4: blr             lr
    // 0xbe86d8: brk             #0
    // 0xbe86dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe86dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe86e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe86e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe86e4: SaveReg d0
    //     0xbe86e4: str             q0, [SP, #-0x10]!
    // 0xbe86e8: r0 = AllocateDouble()
    //     0xbe86e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe86ec: RestoreReg d0
    //     0xbe86ec: ldr             q0, [SP], #0x10
    // 0xbe86f0: b               #0xbe7cb4
    // 0xbe86f4: stp             q0, q1, [SP, #-0x20]!
    // 0xbe86f8: SaveReg r1
    //     0xbe86f8: str             x1, [SP, #-8]!
    // 0xbe86fc: r0 = AllocateDouble()
    //     0xbe86fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8700: RestoreReg r1
    //     0xbe8700: ldr             x1, [SP], #8
    // 0xbe8704: ldp             q0, q1, [SP], #0x20
    // 0xbe8708: b               #0xbe7d04
    // 0xbe870c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe870c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe8710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe8710: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe8714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe8714: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe8718: SaveReg d0
    //     0xbe8718: str             q0, [SP, #-0x10]!
    // 0xbe871c: r0 = AllocateDouble()
    //     0xbe871c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8720: RestoreReg d0
    //     0xbe8720: ldr             q0, [SP], #0x10
    // 0xbe8724: b               #0xbe7e78
    // 0xbe8728: stp             q0, q1, [SP, #-0x20]!
    // 0xbe872c: SaveReg r1
    //     0xbe872c: str             x1, [SP, #-8]!
    // 0xbe8730: r0 = AllocateDouble()
    //     0xbe8730: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8734: RestoreReg r1
    //     0xbe8734: ldr             x1, [SP], #8
    // 0xbe8738: ldp             q0, q1, [SP], #0x20
    // 0xbe873c: b               #0xbe7ecc
    // 0xbe8740: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe8740: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe8744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe8744: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe8748: SaveReg d0
    //     0xbe8748: str             q0, [SP, #-0x10]!
    // 0xbe874c: SaveReg r1
    //     0xbe874c: str             x1, [SP, #-8]!
    // 0xbe8750: r0 = AllocateDouble()
    //     0xbe8750: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8754: RestoreReg r1
    //     0xbe8754: ldr             x1, [SP], #8
    // 0xbe8758: RestoreReg d0
    //     0xbe8758: ldr             q0, [SP], #0x10
    // 0xbe875c: b               #0xbe7fac
    // 0xbe8760: stp             q0, q1, [SP, #-0x20]!
    // 0xbe8764: stp             x0, x1, [SP, #-0x10]!
    // 0xbe8768: r0 = AllocateDouble()
    //     0xbe8768: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe876c: mov             x2, x0
    // 0xbe8770: ldp             x0, x1, [SP], #0x10
    // 0xbe8774: ldp             q0, q1, [SP], #0x20
    // 0xbe8778: b               #0xbe7fe0
    // 0xbe877c: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe877c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe8780: b               #0xbe8034
    // 0xbe8784: stp             q5, q6, [SP, #-0x20]!
    // 0xbe8788: stp             q3, q4, [SP, #-0x20]!
    // 0xbe878c: stp             q1, q2, [SP, #-0x20]!
    // 0xbe8790: SaveReg d0
    //     0xbe8790: str             q0, [SP, #-0x10]!
    // 0xbe8794: stp             x6, x7, [SP, #-0x10]!
    // 0xbe8798: stp             x4, x5, [SP, #-0x10]!
    // 0xbe879c: stp             x2, x3, [SP, #-0x10]!
    // 0xbe87a0: SaveReg r0
    //     0xbe87a0: str             x0, [SP, #-8]!
    // 0xbe87a4: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xbe87a8: r4 = 0
    //     0xbe87a8: mov             x4, #0
    // 0xbe87ac: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xbe87b0: blr             lr
    // 0xbe87b4: brk             #0
    // 0xbe87b8: cmp             x3, xzr
    // 0xbe87bc: sub             x8, x1, x3
    // 0xbe87c0: add             x1, x1, x3
    // 0xbe87c4: csel            x1, x8, x1, lt
    // 0xbe87c8: b               #0xbe8064
    // 0xbe87cc: stp             q6, q8, [SP, #-0x20]!
    // 0xbe87d0: stp             q4, q5, [SP, #-0x20]!
    // 0xbe87d4: stp             q2, q3, [SP, #-0x20]!
    // 0xbe87d8: stp             q0, q1, [SP, #-0x20]!
    // 0xbe87dc: stp             x6, x7, [SP, #-0x10]!
    // 0xbe87e0: stp             x4, x5, [SP, #-0x10]!
    // 0xbe87e4: stp             x2, x3, [SP, #-0x10]!
    // 0xbe87e8: SaveReg r0
    //     0xbe87e8: str             x0, [SP, #-8]!
    // 0xbe87ec: ldr             x5, [THR, #0x478]  ; THR::IntegerDivisionByZeroException
    // 0xbe87f0: r4 = 0
    //     0xbe87f0: mov             x4, #0
    // 0xbe87f4: ldr             lr, [THR, #0x210]  ; THR::call_to_runtime_entry_point
    // 0xbe87f8: blr             lr
    // 0xbe87fc: brk             #0
    // 0xbe8800: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe8800: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe8804: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe8804: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe8808: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe8808: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe880c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe880c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe8810: SaveReg d0
    //     0xbe8810: str             q0, [SP, #-0x10]!
    // 0xbe8814: r0 = AllocateDouble()
    //     0xbe8814: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8818: RestoreReg d0
    //     0xbe8818: ldr             q0, [SP], #0x10
    // 0xbe881c: b               #0xbe8290
    // 0xbe8820: stp             q0, q1, [SP, #-0x20]!
    // 0xbe8824: SaveReg r1
    //     0xbe8824: str             x1, [SP, #-8]!
    // 0xbe8828: r0 = AllocateDouble()
    //     0xbe8828: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe882c: RestoreReg r1
    //     0xbe882c: ldr             x1, [SP], #8
    // 0xbe8830: ldp             q0, q1, [SP], #0x20
    // 0xbe8834: b               #0xbe82e0
    // 0xbe8838: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe8838: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe883c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbe883c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbe8840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe8840: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe8844: SaveReg d1
    //     0xbe8844: str             q1, [SP, #-0x10]!
    // 0xbe8848: SaveReg r1
    //     0xbe8848: str             x1, [SP, #-8]!
    // 0xbe884c: r0 = AllocateDouble()
    //     0xbe884c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbe8850: mov             x6, x0
    // 0xbe8854: RestoreReg r1
    //     0xbe8854: ldr             x1, [SP], #8
    // 0xbe8858: RestoreReg d1
    //     0xbe8858: ldr             q1, [SP], #0x10
    // 0xbe885c: b               #0xbe83fc
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0ecc0, size: 0xb4
    // 0xc0ecc0: EnterFrame
    //     0xc0ecc0: stp             fp, lr, [SP, #-0x10]!
    //     0xc0ecc4: mov             fp, SP
    // 0xc0ecc8: AllocStack(0x8)
    //     0xc0ecc8: sub             SP, SP, #8
    // 0xc0eccc: SetupParameters(RenderSliverGrid this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0eccc: mov             x0, x2
    //     0xc0ecd0: mov             x4, x1
    //     0xc0ecd4: mov             x3, x2
    //     0xc0ecd8: stur            x2, [fp, #-8]
    // 0xc0ecdc: r2 = Null
    //     0xc0ecdc: mov             x2, NULL
    // 0xc0ece0: r1 = Null
    //     0xc0ece0: mov             x1, NULL
    // 0xc0ece4: r4 = 60
    //     0xc0ece4: mov             x4, #0x3c
    // 0xc0ece8: branchIfSmi(r0, 0xc0ecf4)
    //     0xc0ece8: tbz             w0, #0, #0xc0ecf4
    // 0xc0ecec: r4 = LoadClassIdInstr(r0)
    //     0xc0ecec: ldur            x4, [x0, #-1]
    //     0xc0ecf0: ubfx            x4, x4, #0xc, #0x14
    // 0xc0ecf4: r17 = -4679
    //     0xc0ecf4: mov             x17, #-0x1247
    // 0xc0ecf8: add             x4, x4, x17
    // 0xc0ecfc: cmp             x4, #0x128
    // 0xc0ed00: b.ls            #0xc0ed14
    // 0xc0ed04: r8 = RenderObject
    //     0xc0ed04: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0xc0ed08: r3 = Null
    //     0xc0ed08: add             x3, PP, #0x96, lsl #12  ; [pp+0x969c0] Null
    //     0xc0ed0c: ldr             x3, [x3, #0x9c0]
    // 0xc0ed10: r0 = RenderObject()
    //     0xc0ed10: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0xc0ed14: ldur            x0, [fp, #-8]
    // 0xc0ed18: LoadField: r1 = r0->field_7
    //     0xc0ed18: ldur            w1, [x0, #7]
    // 0xc0ed1c: DecompressPointer r1
    //     0xc0ed1c: add             x1, x1, HEAP, lsl #32
    // 0xc0ed20: r2 = LoadClassIdInstr(r1)
    //     0xc0ed20: ldur            x2, [x1, #-1]
    //     0xc0ed24: ubfx            x2, x2, #0xc, #0x14
    // 0xc0ed28: r17 = 4184
    //     0xc0ed28: mov             x17, #0x1058
    // 0xc0ed2c: cmp             x2, x17
    // 0xc0ed30: b.eq            #0xc0ed64
    // 0xc0ed34: r0 = SliverGridParentData()
    //     0xc0ed34: bl              #0xc0ed74  ; AllocateSliverGridParentDataStub -> SliverGridParentData (size=0x24)
    // 0xc0ed38: r1 = false
    //     0xc0ed38: add             x1, NULL, #0x30  ; false
    // 0xc0ed3c: StoreField: r0->field_1b = r1
    //     0xc0ed3c: stur            w1, [x0, #0x1b]
    // 0xc0ed40: StoreField: r0->field_13 = r1
    //     0xc0ed40: stur            w1, [x0, #0x13]
    // 0xc0ed44: ldur            x1, [fp, #-8]
    // 0xc0ed48: StoreField: r1->field_7 = r0
    //     0xc0ed48: stur            w0, [x1, #7]
    //     0xc0ed4c: ldurb           w16, [x1, #-1]
    //     0xc0ed50: ldurb           w17, [x0, #-1]
    //     0xc0ed54: and             x16, x17, x16, lsr #2
    //     0xc0ed58: tst             x16, HEAP, lsr #32
    //     0xc0ed5c: b.eq            #0xc0ed64
    //     0xc0ed60: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0ed64: r0 = Null
    //     0xc0ed64: mov             x0, NULL
    // 0xc0ed68: LeaveFrame
    //     0xc0ed68: mov             SP, fp
    //     0xc0ed6c: ldp             fp, lr, [SP], #0x10
    // 0xc0ed70: ret
    //     0xc0ed70: ret             
  }
  set _ gridDelegate=(/* No info */) {
    // ** addr: 0xcfe784, size: 0x1ac
    // 0xcfe784: EnterFrame
    //     0xcfe784: stp             fp, lr, [SP, #-0x10]!
    //     0xcfe788: mov             fp, SP
    // 0xcfe78c: AllocStack(0x28)
    //     0xcfe78c: sub             SP, SP, #0x28
    // 0xcfe790: SetupParameters(RenderSliverGrid this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcfe790: mov             x0, x2
    //     0xcfe794: stur            x1, [fp, #-8]
    //     0xcfe798: stur            x2, [fp, #-0x10]
    // 0xcfe79c: CheckStackOverflow
    //     0xcfe79c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcfe7a0: cmp             SP, x16
    //     0xcfe7a4: b.ls            #0xcfe928
    // 0xcfe7a8: LoadField: r2 = r1->field_63
    //     0xcfe7a8: ldur            w2, [x1, #0x63]
    // 0xcfe7ac: DecompressPointer r2
    //     0xcfe7ac: add             x2, x2, HEAP, lsl #32
    // 0xcfe7b0: cmp             w2, w0
    // 0xcfe7b4: b.ne            #0xcfe7c8
    // 0xcfe7b8: r0 = Null
    //     0xcfe7b8: mov             x0, NULL
    // 0xcfe7bc: LeaveFrame
    //     0xcfe7bc: mov             SP, fp
    //     0xcfe7c0: ldp             fp, lr, [SP], #0x10
    // 0xcfe7c4: ret
    //     0xcfe7c4: ret             
    // 0xcfe7c8: stp             x2, x0, [SP]
    // 0xcfe7cc: r0 = _haveSameRuntimeType()
    //     0xcfe7cc: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0xcfe7d0: tbz             w0, #4, #0xcfe7dc
    // 0xcfe7d4: ldur            x2, [fp, #-0x10]
    // 0xcfe7d8: b               #0xcfe878
    // 0xcfe7dc: ldur            x4, [fp, #-8]
    // 0xcfe7e0: ldur            x3, [fp, #-0x10]
    // 0xcfe7e4: LoadField: r5 = r4->field_63
    //     0xcfe7e4: ldur            w5, [x4, #0x63]
    // 0xcfe7e8: DecompressPointer r5
    //     0xcfe7e8: add             x5, x5, HEAP, lsl #32
    // 0xcfe7ec: stur            x5, [fp, #-0x18]
    // 0xcfe7f0: r0 = LoadClassIdInstr(r3)
    //     0xcfe7f0: ldur            x0, [x3, #-1]
    //     0xcfe7f4: ubfx            x0, x0, #0xc, #0x14
    // 0xcfe7f8: cmp             x0, #0xc30
    // 0xcfe7fc: b.ne            #0xcfe884
    // 0xcfe800: mov             x0, x5
    // 0xcfe804: r2 = Null
    //     0xcfe804: mov             x2, NULL
    // 0xcfe808: r1 = Null
    //     0xcfe808: mov             x1, NULL
    // 0xcfe80c: r4 = LoadClassIdInstr(r0)
    //     0xcfe80c: ldur            x4, [x0, #-1]
    //     0xcfe810: ubfx            x4, x4, #0xc, #0x14
    // 0xcfe814: cmp             x4, #0xc30
    // 0xcfe818: b.eq            #0xcfe830
    // 0xcfe81c: r8 = SliverGridDelegateWithFixedCrossAxisCount
    //     0xcfe81c: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cfe0] Type: SliverGridDelegateWithFixedCrossAxisCount
    //     0xcfe820: ldr             x8, [x8, #0xfe0]
    // 0xcfe824: r3 = Null
    //     0xcfe824: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8cfe8] Null
    //     0xcfe828: ldr             x3, [x3, #0xfe8]
    // 0xcfe82c: r0 = DefaultTypeTest()
    //     0xcfe82c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcfe830: ldur            x1, [fp, #-0x18]
    // 0xcfe834: LoadField: r0 = r1->field_7
    //     0xcfe834: ldur            x0, [x1, #7]
    // 0xcfe838: ldur            x2, [fp, #-0x10]
    // 0xcfe83c: LoadField: r3 = r2->field_7
    //     0xcfe83c: ldur            x3, [x2, #7]
    // 0xcfe840: cmp             x0, x3
    // 0xcfe844: b.ne            #0xcfe878
    // 0xcfe848: LoadField: d0 = r1->field_f
    //     0xcfe848: ldur            d0, [x1, #0xf]
    // 0xcfe84c: LoadField: d1 = r2->field_f
    //     0xcfe84c: ldur            d1, [x2, #0xf]
    // 0xcfe850: fcmp            d0, d1
    // 0xcfe854: b.ne            #0xcfe878
    // 0xcfe858: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xcfe858: ldur            d0, [x1, #0x17]
    // 0xcfe85c: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xcfe85c: ldur            d1, [x2, #0x17]
    // 0xcfe860: fcmp            d0, d1
    // 0xcfe864: b.ne            #0xcfe878
    // 0xcfe868: LoadField: d0 = r1->field_1f
    //     0xcfe868: ldur            d0, [x1, #0x1f]
    // 0xcfe86c: LoadField: d1 = r2->field_1f
    //     0xcfe86c: ldur            d1, [x2, #0x1f]
    // 0xcfe870: fcmp            d0, d1
    // 0xcfe874: b.eq            #0xcfe8f4
    // 0xcfe878: ldur            x1, [fp, #-8]
    // 0xcfe87c: r0 = markNeedsLayout()
    //     0xcfe87c: bl              #0xbfb800  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsLayout
    // 0xcfe880: b               #0xcfe8f4
    // 0xcfe884: mov             x1, x5
    // 0xcfe888: cmp             x0, #0xc31
    // 0xcfe88c: b.ne            #0xcfe8c4
    // 0xcfe890: mov             x0, x1
    // 0xcfe894: r2 = Null
    //     0xcfe894: mov             x2, NULL
    // 0xcfe898: r1 = Null
    //     0xcfe898: mov             x1, NULL
    // 0xcfe89c: r4 = LoadClassIdInstr(r0)
    //     0xcfe89c: ldur            x4, [x0, #-1]
    //     0xcfe8a0: ubfx            x4, x4, #0xc, #0x14
    // 0xcfe8a4: cmp             x4, #0xc31
    // 0xcfe8a8: b.eq            #0xcfe8c0
    // 0xcfe8ac: r8 = _YearPickerGridDelegate
    //     0xcfe8ac: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cff8] Type: _YearPickerGridDelegate
    //     0xcfe8b0: ldr             x8, [x8, #0xff8]
    // 0xcfe8b4: r3 = Null
    //     0xcfe8b4: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d000] Null
    //     0xcfe8b8: ldr             x3, [x3]
    // 0xcfe8bc: r0 = DefaultTypeTest()
    //     0xcfe8bc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcfe8c0: b               #0xcfe8f4
    // 0xcfe8c4: mov             x0, x1
    // 0xcfe8c8: r2 = Null
    //     0xcfe8c8: mov             x2, NULL
    // 0xcfe8cc: r1 = Null
    //     0xcfe8cc: mov             x1, NULL
    // 0xcfe8d0: r4 = LoadClassIdInstr(r0)
    //     0xcfe8d0: ldur            x4, [x0, #-1]
    //     0xcfe8d4: ubfx            x4, x4, #0xc, #0x14
    // 0xcfe8d8: cmp             x4, #0xc32
    // 0xcfe8dc: b.eq            #0xcfe8f4
    // 0xcfe8e0: r8 = _DayPickerGridDelegate
    //     0xcfe8e0: add             x8, PP, #0x8d, lsl #12  ; [pp+0x8d010] Type: _DayPickerGridDelegate
    //     0xcfe8e4: ldr             x8, [x8, #0x10]
    // 0xcfe8e8: r3 = Null
    //     0xcfe8e8: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d018] Null
    //     0xcfe8ec: ldr             x3, [x3, #0x18]
    // 0xcfe8f0: r0 = DefaultTypeTest()
    //     0xcfe8f0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcfe8f4: ldur            x1, [fp, #-8]
    // 0xcfe8f8: ldur            x0, [fp, #-0x10]
    // 0xcfe8fc: StoreField: r1->field_63 = r0
    //     0xcfe8fc: stur            w0, [x1, #0x63]
    //     0xcfe900: ldurb           w16, [x1, #-1]
    //     0xcfe904: ldurb           w17, [x0, #-1]
    //     0xcfe908: and             x16, x17, x16, lsr #2
    //     0xcfe90c: tst             x16, HEAP, lsr #32
    //     0xcfe910: b.eq            #0xcfe918
    //     0xcfe914: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcfe918: r0 = Null
    //     0xcfe918: mov             x0, NULL
    // 0xcfe91c: LeaveFrame
    //     0xcfe91c: mov             SP, fp
    //     0xcfe920: ldp             fp, lr, [SP], #0x10
    // 0xcfe924: ret
    //     0xcfe924: ret             
    // 0xcfe928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfe928: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfe92c: b               #0xcfe7a8
  }
  _ childCrossAxisPosition(/* No info */) {
    // ** addr: 0x121eb0c, size: 0x80
    // 0x121eb0c: EnterFrame
    //     0x121eb0c: stp             fp, lr, [SP, #-0x10]!
    //     0x121eb10: mov             fp, SP
    // 0x121eb14: AllocStack(0x8)
    //     0x121eb14: sub             SP, SP, #8
    // 0x121eb18: LoadField: r3 = r2->field_7
    //     0x121eb18: ldur            w3, [x2, #7]
    // 0x121eb1c: DecompressPointer r3
    //     0x121eb1c: add             x3, x3, HEAP, lsl #32
    // 0x121eb20: stur            x3, [fp, #-8]
    // 0x121eb24: cmp             w3, NULL
    // 0x121eb28: b.eq            #0x121eb84
    // 0x121eb2c: mov             x0, x3
    // 0x121eb30: r2 = Null
    //     0x121eb30: mov             x2, NULL
    // 0x121eb34: r1 = Null
    //     0x121eb34: mov             x1, NULL
    // 0x121eb38: r4 = LoadClassIdInstr(r0)
    //     0x121eb38: ldur            x4, [x0, #-1]
    //     0x121eb3c: ubfx            x4, x4, #0xc, #0x14
    // 0x121eb40: r17 = 4184
    //     0x121eb40: mov             x17, #0x1058
    // 0x121eb44: cmp             x4, x17
    // 0x121eb48: b.eq            #0x121eb60
    // 0x121eb4c: r8 = SliverGridParentData
    //     0x121eb4c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96900] Type: SliverGridParentData
    //     0x121eb50: ldr             x8, [x8, #0x900]
    // 0x121eb54: r3 = Null
    //     0x121eb54: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1328] Null
    //     0x121eb58: ldr             x3, [x3, #0x328]
    // 0x121eb5c: r0 = DefaultTypeTest()
    //     0x121eb5c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x121eb60: ldur            x0, [fp, #-8]
    // 0x121eb64: LoadField: r1 = r0->field_1f
    //     0x121eb64: ldur            w1, [x0, #0x1f]
    // 0x121eb68: DecompressPointer r1
    //     0x121eb68: add             x1, x1, HEAP, lsl #32
    // 0x121eb6c: cmp             w1, NULL
    // 0x121eb70: b.eq            #0x121eb88
    // 0x121eb74: LoadField: d0 = r1->field_7
    //     0x121eb74: ldur            d0, [x1, #7]
    // 0x121eb78: LeaveFrame
    //     0x121eb78: mov             SP, fp
    //     0x121eb7c: ldp             fp, lr, [SP], #0x10
    // 0x121eb80: ret
    //     0x121eb80: ret             
    // 0x121eb84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x121eb84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x121eb88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x121eb88: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
