// lib: , url: package:flutter/src/rendering/image_filter_config.dart

// class id: 1049029, size: 0x8
class :: {
}

// class id: 2870, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class ImageFilterConfig extends Object {
}

// class id: 2871, size: 0x10, field offset: 0x8
//   const constructor, 
class _ComposeImageFilterConfig extends ImageFilterConfig {

  ImageFilter resolve(_ComposeImageFilterConfig, ImageFilterContext) {
    // ** addr: 0xc18e78, size: 0x84
    // 0xc18e78: EnterFrame
    //     0xc18e78: stp             fp, lr, [SP, #-0x10]!
    //     0xc18e7c: mov             fp, SP
    // 0xc18e80: CheckStackOverflow
    //     0xc18e80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18e84: cmp             SP, x16
    //     0xc18e88: b.ls            #0xc18edc
    // 0xc18e8c: ldr             x0, [fp, #0x10]
    // 0xc18e90: r2 = Null
    //     0xc18e90: mov             x2, NULL
    // 0xc18e94: r1 = Null
    //     0xc18e94: mov             x1, NULL
    // 0xc18e98: r4 = 60
    //     0xc18e98: mov             x4, #0x3c
    // 0xc18e9c: branchIfSmi(r0, 0xc18ea8)
    //     0xc18e9c: tbz             w0, #0, #0xc18ea8
    // 0xc18ea0: r4 = LoadClassIdInstr(r0)
    //     0xc18ea0: ldur            x4, [x0, #-1]
    //     0xc18ea4: ubfx            x4, x4, #0xc, #0x14
    // 0xc18ea8: cmp             x4, #0xb3a
    // 0xc18eac: b.eq            #0xc18ec4
    // 0xc18eb0: r8 = ImageFilterContext
    //     0xc18eb0: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8ce50] Type: ImageFilterContext
    //     0xc18eb4: ldr             x8, [x8, #0xe50]
    // 0xc18eb8: r3 = Null
    //     0xc18eb8: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf9d0] Null
    //     0xc18ebc: ldr             x3, [x3, #0x9d0]
    // 0xc18ec0: r0 = DefaultTypeTest()
    //     0xc18ec0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc18ec4: ldr             x1, [fp, #0x18]
    // 0xc18ec8: ldr             x2, [fp, #0x10]
    // 0xc18ecc: r0 = resolve()
    //     0xc18ecc: bl              #0x13082f0  ; [package:flutter/src/rendering/image_filter_config.dart] _ComposeImageFilterConfig::resolve
    // 0xc18ed0: LeaveFrame
    //     0xc18ed0: mov             SP, fp
    //     0xc18ed4: ldp             fp, lr, [SP], #0x10
    // 0xc18ed8: ret
    //     0xc18ed8: ret             
    // 0xc18edc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18edc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18ee0: b               #0xc18e8c
  }
  _ ==(/* No info */) {
    // ** addr: 0x129a010, size: 0x108
    // 0x129a010: EnterFrame
    //     0x129a010: stp             fp, lr, [SP, #-0x10]!
    //     0x129a014: mov             fp, SP
    // 0x129a018: AllocStack(0x10)
    //     0x129a018: sub             SP, SP, #0x10
    // 0x129a01c: CheckStackOverflow
    //     0x129a01c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129a020: cmp             SP, x16
    //     0x129a024: b.ls            #0x129a110
    // 0x129a028: ldr             x0, [fp, #0x10]
    // 0x129a02c: cmp             w0, NULL
    // 0x129a030: b.ne            #0x129a044
    // 0x129a034: r0 = false
    //     0x129a034: add             x0, NULL, #0x30  ; false
    // 0x129a038: LeaveFrame
    //     0x129a038: mov             SP, fp
    //     0x129a03c: ldp             fp, lr, [SP], #0x10
    // 0x129a040: ret
    //     0x129a040: ret             
    // 0x129a044: ldr             x1, [fp, #0x18]
    // 0x129a048: cmp             w1, w0
    // 0x129a04c: b.ne            #0x129a060
    // 0x129a050: r0 = true
    //     0x129a050: add             x0, NULL, #0x20  ; true
    // 0x129a054: LeaveFrame
    //     0x129a054: mov             SP, fp
    //     0x129a058: ldp             fp, lr, [SP], #0x10
    // 0x129a05c: ret
    //     0x129a05c: ret             
    // 0x129a060: str             x0, [SP]
    // 0x129a064: r0 = runtimeType()
    //     0x129a064: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x129a068: r1 = LoadClassIdInstr(r0)
    //     0x129a068: ldur            x1, [x0, #-1]
    //     0x129a06c: ubfx            x1, x1, #0xc, #0x14
    // 0x129a070: r16 = _ComposeImageFilterConfig
    //     0x129a070: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf9c8] Type: _ComposeImageFilterConfig
    //     0x129a074: ldr             x16, [x16, #0x9c8]
    // 0x129a078: stp             x16, x0, [SP]
    // 0x129a07c: mov             x0, x1
    // 0x129a080: mov             lr, x0
    // 0x129a084: ldr             lr, [x21, lr, lsl #3]
    // 0x129a088: blr             lr
    // 0x129a08c: tbz             w0, #4, #0x129a0a0
    // 0x129a090: r0 = false
    //     0x129a090: add             x0, NULL, #0x30  ; false
    // 0x129a094: LeaveFrame
    //     0x129a094: mov             SP, fp
    //     0x129a098: ldp             fp, lr, [SP], #0x10
    // 0x129a09c: ret
    //     0x129a09c: ret             
    // 0x129a0a0: ldr             x0, [fp, #0x10]
    // 0x129a0a4: r1 = 60
    //     0x129a0a4: mov             x1, #0x3c
    // 0x129a0a8: branchIfSmi(r0, 0x129a0b4)
    //     0x129a0a8: tbz             w0, #0, #0x129a0b4
    // 0x129a0ac: r1 = LoadClassIdInstr(r0)
    //     0x129a0ac: ldur            x1, [x0, #-1]
    //     0x129a0b0: ubfx            x1, x1, #0xc, #0x14
    // 0x129a0b4: cmp             x1, #0xb37
    // 0x129a0b8: b.ne            #0x129a100
    // 0x129a0bc: ldr             x1, [fp, #0x18]
    // 0x129a0c0: LoadField: r2 = r0->field_7
    //     0x129a0c0: ldur            w2, [x0, #7]
    // 0x129a0c4: DecompressPointer r2
    //     0x129a0c4: add             x2, x2, HEAP, lsl #32
    // 0x129a0c8: LoadField: r3 = r1->field_7
    //     0x129a0c8: ldur            w3, [x1, #7]
    // 0x129a0cc: DecompressPointer r3
    //     0x129a0cc: add             x3, x3, HEAP, lsl #32
    // 0x129a0d0: stp             x3, x2, [SP]
    // 0x129a0d4: r0 = ==()
    //     0x129a0d4: bl              #0x1299f30  ; [package:flutter/src/rendering/image_filter_config.dart] _BlurImageFilterConfig::==
    // 0x129a0d8: tbnz            w0, #4, #0x129a100
    // 0x129a0dc: ldr             x1, [fp, #0x18]
    // 0x129a0e0: ldr             x0, [fp, #0x10]
    // 0x129a0e4: LoadField: r2 = r0->field_b
    //     0x129a0e4: ldur            w2, [x0, #0xb]
    // 0x129a0e8: DecompressPointer r2
    //     0x129a0e8: add             x2, x2, HEAP, lsl #32
    // 0x129a0ec: LoadField: r0 = r1->field_b
    //     0x129a0ec: ldur            w0, [x1, #0xb]
    // 0x129a0f0: DecompressPointer r0
    //     0x129a0f0: add             x0, x0, HEAP, lsl #32
    // 0x129a0f4: stp             x0, x2, [SP]
    // 0x129a0f8: r0 = ==()
    //     0x129a0f8: bl              #0x1299e38  ; [package:flutter/src/rendering/image_filter_config.dart] _DirectImageFilterConfig::==
    // 0x129a0fc: b               #0x129a104
    // 0x129a100: r0 = false
    //     0x129a100: add             x0, NULL, #0x30  ; false
    // 0x129a104: LeaveFrame
    //     0x129a104: mov             SP, fp
    //     0x129a108: ldp             fp, lr, [SP], #0x10
    // 0x129a10c: ret
    //     0x129a10c: ret             
    // 0x129a110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129a110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129a114: b               #0x129a028
  }
  ImageFilter resolve(_ComposeImageFilterConfig, ImageFilterContext) {
    // ** addr: 0x13082f0, size: 0x7c
    // 0x13082f0: EnterFrame
    //     0x13082f0: stp             fp, lr, [SP, #-0x10]!
    //     0x13082f4: mov             fp, SP
    // 0x13082f8: AllocStack(0x10)
    //     0x13082f8: sub             SP, SP, #0x10
    // 0x13082fc: SetupParameters(_ComposeImageFilterConfig this /* r1 => r0, fp-0x8 */)
    //     0x13082fc: mov             x0, x1
    //     0x1308300: stur            x1, [fp, #-8]
    // 0x1308304: CheckStackOverflow
    //     0x1308304: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1308308: cmp             SP, x16
    //     0x130830c: b.ls            #0x1308364
    // 0x1308310: LoadField: r1 = r0->field_7
    //     0x1308310: ldur            w1, [x0, #7]
    // 0x1308314: DecompressPointer r1
    //     0x1308314: add             x1, x1, HEAP, lsl #32
    // 0x1308318: r0 = resolve()
    //     0x1308318: bl              #0x13082b8  ; [package:flutter/src/rendering/image_filter_config.dart] _BlurImageFilterConfig::resolve
    // 0x130831c: mov             x1, x0
    // 0x1308320: ldur            x0, [fp, #-8]
    // 0x1308324: stur            x1, [fp, #-0x10]
    // 0x1308328: LoadField: r2 = r0->field_b
    //     0x1308328: ldur            w2, [x0, #0xb]
    // 0x130832c: DecompressPointer r2
    //     0x130832c: add             x2, x2, HEAP, lsl #32
    // 0x1308330: LoadField: r0 = r2->field_7
    //     0x1308330: ldur            w0, [x2, #7]
    // 0x1308334: DecompressPointer r0
    //     0x1308334: add             x0, x0, HEAP, lsl #32
    // 0x1308338: stur            x0, [fp, #-8]
    // 0x130833c: r0 = _ComposeImageFilter()
    //     0x130833c: bl              #0xc18fe8  ; Allocate_ComposeImageFilterStub -> _ComposeImageFilter (size=0x14)
    // 0x1308340: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x1308344: StoreField: r0->field_f = r1
    //     0x1308344: stur            w1, [x0, #0xf]
    // 0x1308348: ldur            x1, [fp, #-8]
    // 0x130834c: StoreField: r0->field_7 = r1
    //     0x130834c: stur            w1, [x0, #7]
    // 0x1308350: ldur            x1, [fp, #-0x10]
    // 0x1308354: StoreField: r0->field_b = r1
    //     0x1308354: stur            w1, [x0, #0xb]
    // 0x1308358: LeaveFrame
    //     0x1308358: mov             SP, fp
    //     0x130835c: ldp             fp, lr, [SP], #0x10
    // 0x1308360: ret
    //     0x1308360: ret             
    // 0x1308364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1308364: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1308368: b               #0x1308310
  }
}

// class id: 2872, size: 0x20, field offset: 0x8
//   const constructor, 
class _BlurImageFilterConfig extends ImageFilterConfig {

  ImageFilter resolve(_BlurImageFilterConfig, ImageFilterContext) {
    // ** addr: 0xc18db8, size: 0x84
    // 0xc18db8: EnterFrame
    //     0xc18db8: stp             fp, lr, [SP, #-0x10]!
    //     0xc18dbc: mov             fp, SP
    // 0xc18dc0: CheckStackOverflow
    //     0xc18dc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18dc4: cmp             SP, x16
    //     0xc18dc8: b.ls            #0xc18e1c
    // 0xc18dcc: ldr             x0, [fp, #0x10]
    // 0xc18dd0: r2 = Null
    //     0xc18dd0: mov             x2, NULL
    // 0xc18dd4: r1 = Null
    //     0xc18dd4: mov             x1, NULL
    // 0xc18dd8: r4 = 60
    //     0xc18dd8: mov             x4, #0x3c
    // 0xc18ddc: branchIfSmi(r0, 0xc18de8)
    //     0xc18ddc: tbz             w0, #0, #0xc18de8
    // 0xc18de0: r4 = LoadClassIdInstr(r0)
    //     0xc18de0: ldur            x4, [x0, #-1]
    //     0xc18de4: ubfx            x4, x4, #0xc, #0x14
    // 0xc18de8: cmp             x4, #0xb3a
    // 0xc18dec: b.eq            #0xc18e04
    // 0xc18df0: r8 = ImageFilterContext
    //     0xc18df0: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8ce50] Type: ImageFilterContext
    //     0xc18df4: ldr             x8, [x8, #0xe50]
    // 0xc18df8: r3 = Null
    //     0xc18df8: add             x3, PP, #0xcf, lsl #12  ; [pp+0xcf9b8] Null
    //     0xc18dfc: ldr             x3, [x3, #0x9b8]
    // 0xc18e00: r0 = DefaultTypeTest()
    //     0xc18e00: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc18e04: ldr             x1, [fp, #0x18]
    // 0xc18e08: ldr             x2, [fp, #0x10]
    // 0xc18e0c: r0 = resolve()
    //     0xc18e0c: bl              #0x13082b8  ; [package:flutter/src/rendering/image_filter_config.dart] _BlurImageFilterConfig::resolve
    // 0xc18e10: LeaveFrame
    //     0xc18e10: mov             SP, fp
    //     0xc18e14: ldp             fp, lr, [SP], #0x10
    // 0xc18e18: ret
    //     0xc18e18: ret             
    // 0xc18e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18e1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18e20: b               #0xc18dcc
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114c840, size: 0x6c
    // 0x114c840: EnterFrame
    //     0x114c840: stp             fp, lr, [SP, #-0x10]!
    //     0x114c844: mov             fp, SP
    // 0x114c848: AllocStack(0x10)
    //     0x114c848: sub             SP, SP, #0x10
    // 0x114c84c: CheckStackOverflow
    //     0x114c84c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114c850: cmp             SP, x16
    //     0x114c854: b.ls            #0x114c8a4
    // 0x114c858: r16 = Instance_TileMode
    //     0x114c858: add             x16, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x114c85c: ldr             x16, [x16, #0x900]
    // 0x114c860: r30 = false
    //     0x114c860: add             lr, NULL, #0x30  ; false
    // 0x114c864: stp             lr, x16, [SP]
    // 0x114c868: r1 = 30.000000
    //     0x114c868: add             x1, PP, #0x18, lsl #12  ; [pp+0x180c8] 30
    //     0x114c86c: ldr             x1, [x1, #0xc8]
    // 0x114c870: r2 = 30.000000
    //     0x114c870: add             x2, PP, #0x18, lsl #12  ; [pp+0x180c8] 30
    //     0x114c874: ldr             x2, [x2, #0xc8]
    // 0x114c878: r4 = const [0, 0x4, 0x2, 0x4, null]
    //     0x114c878: ldr             x4, [PP, #0x1388]  ; [pp+0x1388] List(5) [0, 0x4, 0x2, 0x4, Null]
    // 0x114c87c: r0 = hash()
    //     0x114c87c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114c880: mov             x2, x0
    // 0x114c884: r0 = BoxInt64Instr(r2)
    //     0x114c884: sbfiz           x0, x2, #1, #0x1f
    //     0x114c888: cmp             x2, x0, asr #1
    //     0x114c88c: b.eq            #0x114c898
    //     0x114c890: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c894: stur            x2, [x0, #7]
    // 0x114c898: LeaveFrame
    //     0x114c898: mov             SP, fp
    //     0x114c89c: ldp             fp, lr, [SP], #0x10
    // 0x114c8a0: ret
    //     0x114c8a0: ret             
    // 0x114c8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114c8a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114c8a8: b               #0x114c858
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299f30, size: 0xe0
    // 0x1299f30: EnterFrame
    //     0x1299f30: stp             fp, lr, [SP, #-0x10]!
    //     0x1299f34: mov             fp, SP
    // 0x1299f38: AllocStack(0x10)
    //     0x1299f38: sub             SP, SP, #0x10
    // 0x1299f3c: CheckStackOverflow
    //     0x1299f3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299f40: cmp             SP, x16
    //     0x1299f44: b.ls            #0x129a008
    // 0x1299f48: ldr             x0, [fp, #0x10]
    // 0x1299f4c: cmp             w0, NULL
    // 0x1299f50: b.ne            #0x1299f64
    // 0x1299f54: r0 = false
    //     0x1299f54: add             x0, NULL, #0x30  ; false
    // 0x1299f58: LeaveFrame
    //     0x1299f58: mov             SP, fp
    //     0x1299f5c: ldp             fp, lr, [SP], #0x10
    // 0x1299f60: ret
    //     0x1299f60: ret             
    // 0x1299f64: ldr             x1, [fp, #0x18]
    // 0x1299f68: cmp             w1, w0
    // 0x1299f6c: b.ne            #0x1299f80
    // 0x1299f70: r0 = true
    //     0x1299f70: add             x0, NULL, #0x20  ; true
    // 0x1299f74: LeaveFrame
    //     0x1299f74: mov             SP, fp
    //     0x1299f78: ldp             fp, lr, [SP], #0x10
    // 0x1299f7c: ret
    //     0x1299f7c: ret             
    // 0x1299f80: str             x0, [SP]
    // 0x1299f84: r0 = runtimeType()
    //     0x1299f84: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1299f88: r1 = LoadClassIdInstr(r0)
    //     0x1299f88: ldur            x1, [x0, #-1]
    //     0x1299f8c: ubfx            x1, x1, #0xc, #0x14
    // 0x1299f90: r16 = _BlurImageFilterConfig
    //     0x1299f90: add             x16, PP, #0xcf, lsl #12  ; [pp+0xcf9b0] Type: _BlurImageFilterConfig
    //     0x1299f94: ldr             x16, [x16, #0x9b0]
    // 0x1299f98: stp             x16, x0, [SP]
    // 0x1299f9c: mov             x0, x1
    // 0x1299fa0: mov             lr, x0
    // 0x1299fa4: ldr             lr, [x21, lr, lsl #3]
    // 0x1299fa8: blr             lr
    // 0x1299fac: tbz             w0, #4, #0x1299fc0
    // 0x1299fb0: r0 = false
    //     0x1299fb0: add             x0, NULL, #0x30  ; false
    // 0x1299fb4: LeaveFrame
    //     0x1299fb4: mov             SP, fp
    //     0x1299fb8: ldp             fp, lr, [SP], #0x10
    // 0x1299fbc: ret
    //     0x1299fbc: ret             
    // 0x1299fc0: ldr             x1, [fp, #0x10]
    // 0x1299fc4: r2 = 60
    //     0x1299fc4: mov             x2, #0x3c
    // 0x1299fc8: branchIfSmi(r1, 0x1299fd4)
    //     0x1299fc8: tbz             w1, #0, #0x1299fd4
    // 0x1299fcc: r2 = LoadClassIdInstr(r1)
    //     0x1299fcc: ldur            x2, [x1, #-1]
    //     0x1299fd0: ubfx            x2, x2, #0xc, #0x14
    // 0x1299fd4: cmp             x2, #0xb38
    // 0x1299fd8: b.ne            #0x1299ff8
    // 0x1299fdc: d0 = 30.000000
    //     0x1299fdc: fmov            d0, #30.00000000
    // 0x1299fe0: fcmp            d0, d0
    // 0x1299fe4: b.ne            #0x1299ff8
    // 0x1299fe8: fcmp            d0, d0
    // 0x1299fec: b.ne            #0x1299ff8
    // 0x1299ff0: r0 = true
    //     0x1299ff0: add             x0, NULL, #0x20  ; true
    // 0x1299ff4: b               #0x1299ffc
    // 0x1299ff8: r0 = false
    //     0x1299ff8: add             x0, NULL, #0x30  ; false
    // 0x1299ffc: LeaveFrame
    //     0x1299ffc: mov             SP, fp
    //     0x129a000: ldp             fp, lr, [SP], #0x10
    // 0x129a004: ret
    //     0x129a004: ret             
    // 0x129a008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129a008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129a00c: b               #0x1299f48
  }
  ImageFilter resolve(_BlurImageFilterConfig, ImageFilterContext) {
    // ** addr: 0x13082b8, size: 0x38
    // 0x13082b8: EnterFrame
    //     0x13082b8: stp             fp, lr, [SP, #-0x10]!
    //     0x13082bc: mov             fp, SP
    // 0x13082c0: r0 = _GaussianBlurImageFilter()
    //     0x13082c0: bl              #0x9191c8  ; Allocate_GaussianBlurImageFilterStub -> _GaussianBlurImageFilter (size=0x24)
    // 0x13082c4: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x13082c8: StoreField: r0->field_1f = r1
    //     0x13082c8: stur            w1, [x0, #0x1f]
    // 0x13082cc: d0 = 30.000000
    //     0x13082cc: fmov            d0, #30.00000000
    // 0x13082d0: StoreField: r0->field_7 = d0
    //     0x13082d0: stur            d0, [x0, #7]
    // 0x13082d4: StoreField: r0->field_f = d0
    //     0x13082d4: stur            d0, [x0, #0xf]
    // 0x13082d8: r1 = Instance_TileMode
    //     0x13082d8: add             x1, PP, #0x1e, lsl #12  ; [pp+0x1e900] Obj!TileMode@12c7f61
    //     0x13082dc: ldr             x1, [x1, #0x900]
    // 0x13082e0: ArrayStore: r0[0] = r1  ; List_4
    //     0x13082e0: stur            w1, [x0, #0x17]
    // 0x13082e4: LeaveFrame
    //     0x13082e4: mov             SP, fp
    //     0x13082e8: ldp             fp, lr, [SP], #0x10
    // 0x13082ec: ret
    //     0x13082ec: ret             
  }
}

// class id: 2873, size: 0xc, field offset: 0x8
//   const constructor, 
class _DirectImageFilterConfig extends ImageFilterConfig {

  ImageFilter resolve(_DirectImageFilterConfig, ImageFilterContext) {
    // ** addr: 0xcf5a60, size: 0x70
    // 0xcf5a60: EnterFrame
    //     0xcf5a60: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5a64: mov             fp, SP
    // 0xcf5a68: ldr             x0, [fp, #0x10]
    // 0xcf5a6c: r2 = Null
    //     0xcf5a6c: mov             x2, NULL
    // 0xcf5a70: r1 = Null
    //     0xcf5a70: mov             x1, NULL
    // 0xcf5a74: r4 = 60
    //     0xcf5a74: mov             x4, #0x3c
    // 0xcf5a78: branchIfSmi(r0, 0xcf5a84)
    //     0xcf5a78: tbz             w0, #0, #0xcf5a84
    // 0xcf5a7c: r4 = LoadClassIdInstr(r0)
    //     0xcf5a7c: ldur            x4, [x0, #-1]
    //     0xcf5a80: ubfx            x4, x4, #0xc, #0x14
    // 0xcf5a84: cmp             x4, #0xb3a
    // 0xcf5a88: b.eq            #0xcf5aa0
    // 0xcf5a8c: r8 = ImageFilterContext
    //     0xcf5a8c: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8ce50] Type: ImageFilterContext
    //     0xcf5a90: ldr             x8, [x8, #0xe50]
    // 0xcf5a94: r3 = Null
    //     0xcf5a94: add             x3, PP, #0x8c, lsl #12  ; [pp+0x8ce58] Null
    //     0xcf5a98: ldr             x3, [x3, #0xe58]
    // 0xcf5a9c: r0 = DefaultTypeTest()
    //     0xcf5a9c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcf5aa0: ldr             x1, [fp, #0x18]
    // 0xcf5aa4: LoadField: r0 = r1->field_7
    //     0xcf5aa4: ldur            w0, [x1, #7]
    // 0xcf5aa8: DecompressPointer r0
    //     0xcf5aa8: add             x0, x0, HEAP, lsl #32
    // 0xcf5aac: LeaveFrame
    //     0xcf5aac: mov             SP, fp
    //     0xcf5ab0: ldp             fp, lr, [SP], #0x10
    // 0xcf5ab4: ret
    //     0xcf5ab4: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299e38, size: 0xf8
    // 0x1299e38: EnterFrame
    //     0x1299e38: stp             fp, lr, [SP, #-0x10]!
    //     0x1299e3c: mov             fp, SP
    // 0x1299e40: AllocStack(0x10)
    //     0x1299e40: sub             SP, SP, #0x10
    // 0x1299e44: CheckStackOverflow
    //     0x1299e44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299e48: cmp             SP, x16
    //     0x1299e4c: b.ls            #0x1299f28
    // 0x1299e50: ldr             x0, [fp, #0x10]
    // 0x1299e54: cmp             w0, NULL
    // 0x1299e58: b.ne            #0x1299e6c
    // 0x1299e5c: r0 = false
    //     0x1299e5c: add             x0, NULL, #0x30  ; false
    // 0x1299e60: LeaveFrame
    //     0x1299e60: mov             SP, fp
    //     0x1299e64: ldp             fp, lr, [SP], #0x10
    // 0x1299e68: ret
    //     0x1299e68: ret             
    // 0x1299e6c: ldr             x1, [fp, #0x18]
    // 0x1299e70: cmp             w1, w0
    // 0x1299e74: b.ne            #0x1299e88
    // 0x1299e78: r0 = true
    //     0x1299e78: add             x0, NULL, #0x20  ; true
    // 0x1299e7c: LeaveFrame
    //     0x1299e7c: mov             SP, fp
    //     0x1299e80: ldp             fp, lr, [SP], #0x10
    // 0x1299e84: ret
    //     0x1299e84: ret             
    // 0x1299e88: str             x0, [SP]
    // 0x1299e8c: r0 = runtimeType()
    //     0x1299e8c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1299e90: r1 = LoadClassIdInstr(r0)
    //     0x1299e90: ldur            x1, [x0, #-1]
    //     0x1299e94: ubfx            x1, x1, #0xc, #0x14
    // 0x1299e98: r16 = _DirectImageFilterConfig
    //     0x1299e98: add             x16, PP, #0x85, lsl #12  ; [pp+0x850d0] Type: _DirectImageFilterConfig
    //     0x1299e9c: ldr             x16, [x16, #0xd0]
    // 0x1299ea0: stp             x16, x0, [SP]
    // 0x1299ea4: mov             x0, x1
    // 0x1299ea8: mov             lr, x0
    // 0x1299eac: ldr             lr, [x21, lr, lsl #3]
    // 0x1299eb0: blr             lr
    // 0x1299eb4: tbz             w0, #4, #0x1299ec8
    // 0x1299eb8: r0 = false
    //     0x1299eb8: add             x0, NULL, #0x30  ; false
    // 0x1299ebc: LeaveFrame
    //     0x1299ebc: mov             SP, fp
    //     0x1299ec0: ldp             fp, lr, [SP], #0x10
    // 0x1299ec4: ret
    //     0x1299ec4: ret             
    // 0x1299ec8: ldr             x0, [fp, #0x10]
    // 0x1299ecc: r1 = 60
    //     0x1299ecc: mov             x1, #0x3c
    // 0x1299ed0: branchIfSmi(r0, 0x1299edc)
    //     0x1299ed0: tbz             w0, #0, #0x1299edc
    // 0x1299ed4: r1 = LoadClassIdInstr(r0)
    //     0x1299ed4: ldur            x1, [x0, #-1]
    //     0x1299ed8: ubfx            x1, x1, #0xc, #0x14
    // 0x1299edc: cmp             x1, #0xb39
    // 0x1299ee0: b.ne            #0x1299f18
    // 0x1299ee4: ldr             x1, [fp, #0x18]
    // 0x1299ee8: LoadField: r2 = r0->field_7
    //     0x1299ee8: ldur            w2, [x0, #7]
    // 0x1299eec: DecompressPointer r2
    //     0x1299eec: add             x2, x2, HEAP, lsl #32
    // 0x1299ef0: LoadField: r0 = r1->field_7
    //     0x1299ef0: ldur            w0, [x1, #7]
    // 0x1299ef4: DecompressPointer r0
    //     0x1299ef4: add             x0, x0, HEAP, lsl #32
    // 0x1299ef8: r1 = LoadClassIdInstr(r2)
    //     0x1299ef8: ldur            x1, [x2, #-1]
    //     0x1299efc: ubfx            x1, x1, #0xc, #0x14
    // 0x1299f00: stp             x0, x2, [SP]
    // 0x1299f04: mov             x0, x1
    // 0x1299f08: mov             lr, x0
    // 0x1299f0c: ldr             lr, [x21, lr, lsl #3]
    // 0x1299f10: blr             lr
    // 0x1299f14: b               #0x1299f1c
    // 0x1299f18: r0 = false
    //     0x1299f18: add             x0, NULL, #0x30  ; false
    // 0x1299f1c: LeaveFrame
    //     0x1299f1c: mov             SP, fp
    //     0x1299f20: ldp             fp, lr, [SP], #0x10
    // 0x1299f24: ret
    //     0x1299f24: ret             
    // 0x1299f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1299f28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1299f2c: b               #0x1299e50
  }
}

// class id: 2874, size: 0x8, field offset: 0x8
//   const constructor, 
class ImageFilterContext extends Object {
}
