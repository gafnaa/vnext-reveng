// lib: , url: package:flutter/src/rendering/wrap.dart

// class id: 1049057, size: 0x8
class :: {

  static _ _AxisSize._convert(/* No info */) {
    // ** addr: 0xb661a0, size: 0x40
    // 0xb661a0: EnterFrame
    //     0xb661a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb661a4: mov             fp, SP
    // 0xb661a8: CheckStackOverflow
    //     0xb661a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb661ac: cmp             SP, x16
    //     0xb661b0: b.ls            #0xb661d8
    // 0xb661b4: LoadField: r0 = r2->field_7
    //     0xb661b4: ldur            x0, [x2, #7]
    // 0xb661b8: cmp             x0, #0
    // 0xb661bc: b.gt            #0xb661c8
    // 0xb661c0: mov             x0, x1
    // 0xb661c4: b               #0xb661cc
    // 0xb661c8: r0 = flipped()
    //     0xb661c8: bl              #0xb1922c  ; [dart:ui] Size::flipped
    // 0xb661cc: LeaveFrame
    //     0xb661cc: mov             SP, fp
    //     0xb661d0: ldp             fp, lr, [SP], #0x10
    // 0xb661d4: ret
    //     0xb661d4: ret             
    // 0xb661d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb661d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb661dc: b               #0xb661b4
  }
  static _ _AxisSize.(/* No info */) {
    // ** addr: 0xb66bd0, size: 0x2c
    // 0xb66bd0: EnterFrame
    //     0xb66bd0: stp             fp, lr, [SP, #-0x10]!
    //     0xb66bd4: mov             fp, SP
    // 0xb66bd8: AllocStack(0x8)
    //     0xb66bd8: sub             SP, SP, #8
    // 0xb66bdc: SetupParameters(dynamic _ /* d0 => d0, fp-0x8 */)
    //     0xb66bdc: stur            d0, [fp, #-8]
    // 0xb66be0: r0 = Size()
    //     0xb66be0: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb66be4: ldur            d0, [fp, #-8]
    // 0xb66be8: StoreField: r0->field_7 = d0
    //     0xb66be8: stur            d0, [x0, #7]
    // 0xb66bec: StoreField: r0->field_f = rZR
    //     0xb66bec: stur            xzr, [x0, #0xf]
    // 0xb66bf0: LeaveFrame
    //     0xb66bf0: mov             SP, fp
    //     0xb66bf4: ldp             fp, lr, [SP], #0x10
    // 0xb66bf8: ret
    //     0xb66bf8: ret             
  }
  static _ _AxisSize.-(/* No info */) {
    // ** addr: 0xbcc7c0, size: 0x4c
    // 0xbcc7c0: EnterFrame
    //     0xbcc7c0: stp             fp, lr, [SP, #-0x10]!
    //     0xbcc7c4: mov             fp, SP
    // 0xbcc7c8: AllocStack(0x10)
    //     0xbcc7c8: sub             SP, SP, #0x10
    // 0xbcc7cc: LoadField: d0 = r1->field_7
    //     0xbcc7cc: ldur            d0, [x1, #7]
    // 0xbcc7d0: LoadField: d1 = r2->field_7
    //     0xbcc7d0: ldur            d1, [x2, #7]
    // 0xbcc7d4: fsub            d2, d0, d1
    // 0xbcc7d8: stur            d2, [fp, #-0x10]
    // 0xbcc7dc: LoadField: d0 = r1->field_f
    //     0xbcc7dc: ldur            d0, [x1, #0xf]
    // 0xbcc7e0: LoadField: d1 = r2->field_f
    //     0xbcc7e0: ldur            d1, [x2, #0xf]
    // 0xbcc7e4: fsub            d3, d0, d1
    // 0xbcc7e8: stur            d3, [fp, #-8]
    // 0xbcc7ec: r0 = Size()
    //     0xbcc7ec: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbcc7f0: ldur            d0, [fp, #-0x10]
    // 0xbcc7f4: StoreField: r0->field_7 = d0
    //     0xbcc7f4: stur            d0, [x0, #7]
    // 0xbcc7f8: ldur            d0, [fp, #-8]
    // 0xbcc7fc: StoreField: r0->field_f = d0
    //     0xbcc7fc: stur            d0, [x0, #0xf]
    // 0xbcc800: LeaveFrame
    //     0xbcc800: mov             SP, fp
    //     0xbcc804: ldp             fp, lr, [SP], #0x10
    // 0xbcc808: ret
    //     0xbcc808: ret             
  }
}

// class id: 2838, size: 0x18, field offset: 0x8
class _RunMetrics extends Object {

  _ tryAddingNewChild(/* No info */) {
    // ** addr: 0xb66bfc, size: 0x11c
    // 0xb66bfc: EnterFrame
    //     0xb66bfc: stp             fp, lr, [SP, #-0x10]!
    //     0xb66c00: mov             fp, SP
    // 0xb66c04: AllocStack(0x28)
    //     0xb66c04: sub             SP, SP, #0x28
    // 0xb66c08: d2 = 0.000000
    //     0xb66c08: ldr             d2, [PP, #0x5490]  ; [pp+0x5490] IMM: double(1e-10) from 0x3ddb7cdfd9d7bdbb
    // 0xb66c0c: mov             x0, x2
    // 0xb66c10: stur            x2, [fp, #-8]
    // 0xb66c14: mov             x2, x1
    // 0xb66c18: stur            x1, [fp, #-0x20]
    // 0xb66c1c: mov             x1, x3
    // 0xb66c20: stur            x3, [fp, #-0x10]
    // 0xb66c24: stur            x5, [fp, #-0x28]
    // 0xb66c28: CheckStackOverflow
    //     0xb66c28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb66c2c: cmp             SP, x16
    //     0xb66c30: b.ls            #0xb66d10
    // 0xb66c34: LoadField: r3 = r2->field_7
    //     0xb66c34: ldur            w3, [x2, #7]
    // 0xb66c38: DecompressPointer r3
    //     0xb66c38: add             x3, x3, HEAP, lsl #32
    // 0xb66c3c: stur            x3, [fp, #-0x18]
    // 0xb66c40: LoadField: d3 = r3->field_7
    //     0xb66c40: ldur            d3, [x3, #7]
    // 0xb66c44: LoadField: d4 = r1->field_7
    //     0xb66c44: ldur            d4, [x1, #7]
    // 0xb66c48: fadd            d5, d3, d4
    // 0xb66c4c: fadd            d3, d5, d0
    // 0xb66c50: fsub            d4, d3, d1
    // 0xb66c54: fcmp            d4, d2
    // 0xb66c58: b.le            #0xb66c8c
    // 0xb66c5c: r0 = _RunMetrics()
    //     0xb66c5c: bl              #0xb66d38  ; Allocate_RunMetricsStub -> _RunMetrics (size=0x18)
    // 0xb66c60: mov             x1, x0
    // 0xb66c64: r0 = 1
    //     0xb66c64: mov             x0, #1
    // 0xb66c68: StoreField: r1->field_b = r0
    //     0xb66c68: stur            x0, [x1, #0xb]
    // 0xb66c6c: ldur            x0, [fp, #-8]
    // 0xb66c70: StoreField: r1->field_13 = r0
    //     0xb66c70: stur            w0, [x1, #0x13]
    // 0xb66c74: ldur            x4, [fp, #-0x10]
    // 0xb66c78: StoreField: r1->field_7 = r4
    //     0xb66c78: stur            w4, [x1, #7]
    // 0xb66c7c: mov             x0, x1
    // 0xb66c80: LeaveFrame
    //     0xb66c80: mov             SP, fp
    //     0xb66c84: ldp             fp, lr, [SP], #0x10
    // 0xb66c88: ret
    //     0xb66c88: ret             
    // 0xb66c8c: mov             x4, x1
    // 0xb66c90: r0 = _AxisSize.()
    //     0xb66c90: bl              #0xb66bd0  ; [package:flutter/src/rendering/wrap.dart] ::_AxisSize.
    // 0xb66c94: ldur            x1, [fp, #-0x10]
    // 0xb66c98: mov             x2, x0
    // 0xb66c9c: r0 = _AxisSize.+()
    //     0xb66c9c: bl              #0xb18b88  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.+
    // 0xb66ca0: ldur            x1, [fp, #-0x18]
    // 0xb66ca4: mov             x2, x0
    // 0xb66ca8: r0 = _AxisSize.+()
    //     0xb66ca8: bl              #0xb18b88  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.+
    // 0xb66cac: ldur            x1, [fp, #-0x20]
    // 0xb66cb0: StoreField: r1->field_7 = r0
    //     0xb66cb0: stur            w0, [x1, #7]
    //     0xb66cb4: ldurb           w16, [x1, #-1]
    //     0xb66cb8: ldurb           w17, [x0, #-1]
    //     0xb66cbc: and             x16, x17, x16, lsr #2
    //     0xb66cc0: tst             x16, HEAP, lsr #32
    //     0xb66cc4: b.eq            #0xb66ccc
    //     0xb66cc8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb66ccc: LoadField: r2 = r1->field_b
    //     0xb66ccc: ldur            x2, [x1, #0xb]
    // 0xb66cd0: add             x3, x2, #1
    // 0xb66cd4: StoreField: r1->field_b = r3
    //     0xb66cd4: stur            x3, [x1, #0xb]
    // 0xb66cd8: ldur            x2, [fp, #-0x28]
    // 0xb66cdc: tbnz            w2, #4, #0xb66d00
    // 0xb66ce0: ldur            x0, [fp, #-8]
    // 0xb66ce4: StoreField: r1->field_13 = r0
    //     0xb66ce4: stur            w0, [x1, #0x13]
    //     0xb66ce8: ldurb           w16, [x1, #-1]
    //     0xb66cec: ldurb           w17, [x0, #-1]
    //     0xb66cf0: and             x16, x17, x16, lsr #2
    //     0xb66cf4: tst             x16, HEAP, lsr #32
    //     0xb66cf8: b.eq            #0xb66d00
    //     0xb66cfc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb66d00: r0 = Null
    //     0xb66d00: mov             x0, NULL
    // 0xb66d04: LeaveFrame
    //     0xb66d04: mov             SP, fp
    //     0xb66d08: ldp             fp, lr, [SP], #0x10
    // 0xb66d0c: ret
    //     0xb66d0c: ret             
    // 0xb66d10: r0 = StackOverflowSharedWithFPURegs()
    //     0xb66d10: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb66d14: b               #0xb66c34
  }
}

// class id: 4207, size: 0x18, field offset: 0x18
class WrapParentData extends ContainerBoxParentData<dynamic> {
}

// class id: 4806, size: 0x94, field offset: 0x60
class RenderWrap extends _MixinApplication453&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb20140, size: 0x24
    // 0xb20140: EnterFrame
    //     0xb20140: stp             fp, lr, [SP, #-0x10]!
    //     0xb20144: mov             fp, SP
    // 0xb20148: ldr             x2, [fp, #0x10]
    // 0xb2014c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb2014c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa27d8] AnonymousClosure: (0xb20164), in [package:flutter/src/rendering/wrap.dart] RenderWrap::computeMinIntrinsicWidth (0xb201dc)
    //     0xb20150: ldr             x1, [x1, #0x7d8]
    // 0xb20154: r0 = AllocateClosure()
    //     0xb20154: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb20158: LeaveFrame
    //     0xb20158: mov             SP, fp
    //     0xb2015c: ldp             fp, lr, [SP], #0x10
    // 0xb20160: ret
    //     0xb20160: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb20164, size: 0x78
    // 0xb20164: EnterFrame
    //     0xb20164: stp             fp, lr, [SP, #-0x10]!
    //     0xb20168: mov             fp, SP
    // 0xb2016c: ldr             x0, [fp, #0x18]
    // 0xb20170: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb20170: ldur            w1, [x0, #0x17]
    // 0xb20174: DecompressPointer r1
    //     0xb20174: add             x1, x1, HEAP, lsl #32
    // 0xb20178: CheckStackOverflow
    //     0xb20178: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2017c: cmp             SP, x16
    //     0xb20180: b.ls            #0xb201c4
    // 0xb20184: ldr             x2, [fp, #0x10]
    // 0xb20188: r0 = computeMinIntrinsicWidth()
    //     0xb20188: bl              #0xb201dc  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::computeMinIntrinsicWidth
    // 0xb2018c: r0 = inline_Allocate_Double()
    //     0xb2018c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb20190: add             x0, x0, #0x10
    //     0xb20194: cmp             x1, x0
    //     0xb20198: b.ls            #0xb201cc
    //     0xb2019c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb201a0: sub             x0, x0, #0xf
    //     0xb201a4: mov             x1, #0xe19c
    //     0xb201a8: movk            x1, #3, lsl #16
    //     0xb201ac: stur            x1, [x0, #-1]
    // 0xb201b0: dmb             ishst
    // 0xb201b4: StoreField: r0->field_7 = d0
    //     0xb201b4: stur            d0, [x0, #7]
    // 0xb201b8: LeaveFrame
    //     0xb201b8: mov             SP, fp
    //     0xb201bc: ldp             fp, lr, [SP], #0x10
    // 0xb201c0: ret
    //     0xb201c0: ret             
    // 0xb201c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb201c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb201c8: b               #0xb20184
    // 0xb201cc: SaveReg d0
    //     0xb201cc: str             q0, [SP, #-0x10]!
    // 0xb201d0: r0 = AllocateDouble()
    //     0xb201d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb201d4: RestoreReg d0
    //     0xb201d4: ldr             q0, [SP], #0x10
    // 0xb201d8: b               #0xb201b4
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb201dc, size: 0x184
    // 0xb201dc: EnterFrame
    //     0xb201dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb201e0: mov             fp, SP
    // 0xb201e4: AllocStack(0x58)
    //     0xb201e4: sub             SP, SP, #0x58
    // 0xb201e8: SetupParameters(RenderWrap this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xb201e8: stur            x1, [fp, #-0x18]
    //     0xb201ec: stur            x2, [fp, #-0x20]
    // 0xb201f0: CheckStackOverflow
    //     0xb201f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb201f4: cmp             SP, x16
    //     0xb201f8: b.ls            #0xb2034c
    // 0xb201fc: LoadField: r0 = r1->field_5f
    //     0xb201fc: ldur            w0, [x1, #0x5f]
    // 0xb20200: DecompressPointer r0
    //     0xb20200: add             x0, x0, HEAP, lsl #32
    // 0xb20204: LoadField: r3 = r0->field_7
    //     0xb20204: ldur            x3, [x0, #7]
    // 0xb20208: cmp             x3, #0
    // 0xb2020c: b.gt            #0xb20310
    // 0xb20210: LoadField: r0 = r1->field_57
    //     0xb20210: ldur            w0, [x1, #0x57]
    // 0xb20214: DecompressPointer r0
    //     0xb20214: add             x0, x0, HEAP, lsl #32
    // 0xb20218: mov             x1, x0
    // 0xb2021c: d0 = 0.000000
    //     0xb2021c: eor             v0.16b, v0.16b, v0.16b
    // 0xb20220: stur            x1, [fp, #-8]
    // 0xb20224: stur            d0, [fp, #-0x28]
    // 0xb20228: CheckStackOverflow
    //     0xb20228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2022c: cmp             SP, x16
    //     0xb20230: b.ls            #0xb20354
    // 0xb20234: cmp             w1, NULL
    // 0xb20238: b.eq            #0xb202fc
    // 0xb2023c: r0 = LoadClassIdInstr(r1)
    //     0xb2023c: ldur            x0, [x1, #-1]
    //     0xb20240: ubfx            x0, x0, #0xc, #0x14
    // 0xb20244: str             x1, [SP]
    // 0xb20248: r0 = GDT[cid_x0 + 0x12f2c]()
    //     0xb20248: mov             x17, #0x2f2c
    //     0xb2024c: movk            x17, #1, lsl #16
    //     0xb20250: add             lr, x0, x17
    //     0xb20254: ldr             lr, [x21, lr, lsl #3]
    //     0xb20258: blr             lr
    // 0xb2025c: r16 = <double, double>
    //     0xb2025c: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb20260: ldr             x16, [x16, #0x228]
    // 0xb20264: ldur            lr, [fp, #-8]
    // 0xb20268: stp             lr, x16, [SP, #0x18]
    // 0xb2026c: r16 = Instance__IntrinsicDimension
    //     0xb2026c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98a78] Obj!_IntrinsicDimension@12c4681
    //     0xb20270: ldr             x16, [x16, #0xa78]
    // 0xb20274: r30 = inf
    //     0xb20274: add             lr, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xb20278: ldr             lr, [lr, #0x8a8]
    // 0xb2027c: stp             lr, x16, [SP, #8]
    // 0xb20280: str             x0, [SP]
    // 0xb20284: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb20284: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb20288: r0 = _computeIntrinsics()
    //     0xb20288: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb2028c: LoadField: d0 = r0->field_7
    //     0xb2028c: ldur            d0, [x0, #7]
    // 0xb20290: ldur            d1, [fp, #-0x28]
    // 0xb20294: fmax            v2.2d, v1.2d, v0.2d
    // 0xb20298: ldur            x0, [fp, #-8]
    // 0xb2029c: stur            d2, [fp, #-0x30]
    // 0xb202a0: LoadField: r3 = r0->field_7
    //     0xb202a0: ldur            w3, [x0, #7]
    // 0xb202a4: DecompressPointer r3
    //     0xb202a4: add             x3, x3, HEAP, lsl #32
    // 0xb202a8: stur            x3, [fp, #-0x10]
    // 0xb202ac: cmp             w3, NULL
    // 0xb202b0: b.eq            #0xb2035c
    // 0xb202b4: mov             x0, x3
    // 0xb202b8: r2 = Null
    //     0xb202b8: mov             x2, NULL
    // 0xb202bc: r1 = Null
    //     0xb202bc: mov             x1, NULL
    // 0xb202c0: r4 = LoadClassIdInstr(r0)
    //     0xb202c0: ldur            x4, [x0, #-1]
    //     0xb202c4: ubfx            x4, x4, #0xc, #0x14
    // 0xb202c8: r17 = 4207
    //     0xb202c8: mov             x17, #0x106f
    // 0xb202cc: cmp             x4, x17
    // 0xb202d0: b.eq            #0xb202e8
    // 0xb202d4: r8 = WrapParentData
    //     0xb202d4: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e4c0] Type: WrapParentData
    //     0xb202d8: ldr             x8, [x8, #0x4c0]
    // 0xb202dc: r3 = Null
    //     0xb202dc: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa27e0] Null
    //     0xb202e0: ldr             x3, [x3, #0x7e0]
    // 0xb202e4: r0 = DefaultTypeTest()
    //     0xb202e4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb202e8: ldur            x0, [fp, #-0x10]
    // 0xb202ec: LoadField: r1 = r0->field_13
    //     0xb202ec: ldur            w1, [x0, #0x13]
    // 0xb202f0: DecompressPointer r1
    //     0xb202f0: add             x1, x1, HEAP, lsl #32
    // 0xb202f4: ldur            d0, [fp, #-0x30]
    // 0xb202f8: b               #0xb20220
    // 0xb202fc: mov             v1.16b, v0.16b
    // 0xb20300: mov             v0.16b, v1.16b
    // 0xb20304: LeaveFrame
    //     0xb20304: mov             SP, fp
    //     0xb20308: ldp             fp, lr, [SP], #0x10
    // 0xb2030c: ret
    //     0xb2030c: ret             
    // 0xb20310: r0 = BoxConstraints()
    //     0xb20310: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb20314: StoreField: r0->field_7 = rZR
    //     0xb20314: stur            xzr, [x0, #7]
    // 0xb20318: d0 = inf
    //     0xb20318: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2031c: StoreField: r0->field_f = d0
    //     0xb2031c: stur            d0, [x0, #0xf]
    // 0xb20320: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb20320: stur            xzr, [x0, #0x17]
    // 0xb20324: ldur            x1, [fp, #-0x20]
    // 0xb20328: LoadField: d0 = r1->field_7
    //     0xb20328: ldur            d0, [x1, #7]
    // 0xb2032c: StoreField: r0->field_1f = d0
    //     0xb2032c: stur            d0, [x0, #0x1f]
    // 0xb20330: ldur            x1, [fp, #-0x18]
    // 0xb20334: mov             x2, x0
    // 0xb20338: r0 = getDryLayout()
    //     0xb20338: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb2033c: LoadField: d0 = r0->field_7
    //     0xb2033c: ldur            d0, [x0, #7]
    // 0xb20340: LeaveFrame
    //     0xb20340: mov             SP, fp
    //     0xb20344: ldp             fp, lr, [SP], #0x10
    // 0xb20348: ret
    //     0xb20348: ret             
    // 0xb2034c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2034c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb20350: b               #0xb201fc
    // 0xb20354: r0 = StackOverflowSharedWithFPURegs()
    //     0xb20354: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb20358: b               #0xb20234
    // 0xb2035c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb2035c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb25718, size: 0x180
    // 0xb25718: EnterFrame
    //     0xb25718: stp             fp, lr, [SP, #-0x10]!
    //     0xb2571c: mov             fp, SP
    // 0xb25720: AllocStack(0x48)
    //     0xb25720: sub             SP, SP, #0x48
    // 0xb25724: SetupParameters(RenderWrap this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb25724: stur            x1, [fp, #-8]
    //     0xb25728: stur            x2, [fp, #-0x10]
    // 0xb2572c: CheckStackOverflow
    //     0xb2572c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb25730: cmp             SP, x16
    //     0xb25734: b.ls            #0xb25884
    // 0xb25738: LoadField: r0 = r1->field_5f
    //     0xb25738: ldur            w0, [x1, #0x5f]
    // 0xb2573c: DecompressPointer r0
    //     0xb2573c: add             x0, x0, HEAP, lsl #32
    // 0xb25740: LoadField: r3 = r0->field_7
    //     0xb25740: ldur            x3, [x0, #7]
    // 0xb25744: cmp             x3, #0
    // 0xb25748: b.gt            #0xb25788
    // 0xb2574c: r0 = BoxConstraints()
    //     0xb2574c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb25750: StoreField: r0->field_7 = rZR
    //     0xb25750: stur            xzr, [x0, #7]
    // 0xb25754: ldur            x1, [fp, #-0x10]
    // 0xb25758: LoadField: d0 = r1->field_7
    //     0xb25758: ldur            d0, [x1, #7]
    // 0xb2575c: StoreField: r0->field_f = d0
    //     0xb2575c: stur            d0, [x0, #0xf]
    // 0xb25760: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb25760: stur            xzr, [x0, #0x17]
    // 0xb25764: d0 = inf
    //     0xb25764: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb25768: StoreField: r0->field_1f = d0
    //     0xb25768: stur            d0, [x0, #0x1f]
    // 0xb2576c: ldur            x1, [fp, #-8]
    // 0xb25770: mov             x2, x0
    // 0xb25774: r0 = getDryLayout()
    //     0xb25774: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb25778: LoadField: d0 = r0->field_f
    //     0xb25778: ldur            d0, [x0, #0xf]
    // 0xb2577c: LeaveFrame
    //     0xb2577c: mov             SP, fp
    //     0xb25780: ldp             fp, lr, [SP], #0x10
    // 0xb25784: ret
    //     0xb25784: ret             
    // 0xb25788: mov             x0, x1
    // 0xb2578c: LoadField: r1 = r0->field_57
    //     0xb2578c: ldur            w1, [x0, #0x57]
    // 0xb25790: DecompressPointer r1
    //     0xb25790: add             x1, x1, HEAP, lsl #32
    // 0xb25794: d0 = 0.000000
    //     0xb25794: eor             v0.16b, v0.16b, v0.16b
    // 0xb25798: stur            x1, [fp, #-8]
    // 0xb2579c: stur            d0, [fp, #-0x18]
    // 0xb257a0: CheckStackOverflow
    //     0xb257a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb257a4: cmp             SP, x16
    //     0xb257a8: b.ls            #0xb2588c
    // 0xb257ac: cmp             w1, NULL
    // 0xb257b0: b.eq            #0xb25870
    // 0xb257b4: r0 = LoadClassIdInstr(r1)
    //     0xb257b4: ldur            x0, [x1, #-1]
    //     0xb257b8: ubfx            x0, x0, #0xc, #0x14
    // 0xb257bc: str             x1, [SP]
    // 0xb257c0: r0 = GDT[cid_x0 + 0xc5bb]()
    //     0xb257c0: mov             x17, #0xc5bb
    //     0xb257c4: add             lr, x0, x17
    //     0xb257c8: ldr             lr, [x21, lr, lsl #3]
    //     0xb257cc: blr             lr
    // 0xb257d0: r16 = <double, double>
    //     0xb257d0: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb257d4: ldr             x16, [x16, #0x228]
    // 0xb257d8: ldur            lr, [fp, #-8]
    // 0xb257dc: stp             lr, x16, [SP, #0x18]
    // 0xb257e0: r16 = Instance__IntrinsicDimension
    //     0xb257e0: add             x16, PP, #0x99, lsl #12  ; [pp+0x992f0] Obj!_IntrinsicDimension@12c46e1
    //     0xb257e4: ldr             x16, [x16, #0x2f0]
    // 0xb257e8: r30 = inf
    //     0xb257e8: add             lr, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xb257ec: ldr             lr, [lr, #0x8a8]
    // 0xb257f0: stp             lr, x16, [SP, #8]
    // 0xb257f4: str             x0, [SP]
    // 0xb257f8: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb257f8: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb257fc: r0 = _computeIntrinsics()
    //     0xb257fc: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb25800: LoadField: d0 = r0->field_7
    //     0xb25800: ldur            d0, [x0, #7]
    // 0xb25804: ldur            d1, [fp, #-0x18]
    // 0xb25808: fmax            v2.2d, v1.2d, v0.2d
    // 0xb2580c: ldur            x0, [fp, #-8]
    // 0xb25810: stur            d2, [fp, #-0x20]
    // 0xb25814: LoadField: r3 = r0->field_7
    //     0xb25814: ldur            w3, [x0, #7]
    // 0xb25818: DecompressPointer r3
    //     0xb25818: add             x3, x3, HEAP, lsl #32
    // 0xb2581c: stur            x3, [fp, #-0x10]
    // 0xb25820: cmp             w3, NULL
    // 0xb25824: b.eq            #0xb25894
    // 0xb25828: mov             x0, x3
    // 0xb2582c: r2 = Null
    //     0xb2582c: mov             x2, NULL
    // 0xb25830: r1 = Null
    //     0xb25830: mov             x1, NULL
    // 0xb25834: r4 = LoadClassIdInstr(r0)
    //     0xb25834: ldur            x4, [x0, #-1]
    //     0xb25838: ubfx            x4, x4, #0xc, #0x14
    // 0xb2583c: r17 = 4207
    //     0xb2583c: mov             x17, #0x106f
    // 0xb25840: cmp             x4, x17
    // 0xb25844: b.eq            #0xb2585c
    // 0xb25848: r8 = WrapParentData
    //     0xb25848: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e4c0] Type: WrapParentData
    //     0xb2584c: ldr             x8, [x8, #0x4c0]
    // 0xb25850: r3 = Null
    //     0xb25850: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa27b0] Null
    //     0xb25854: ldr             x3, [x3, #0x7b0]
    // 0xb25858: r0 = DefaultTypeTest()
    //     0xb25858: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb2585c: ldur            x0, [fp, #-0x10]
    // 0xb25860: LoadField: r1 = r0->field_13
    //     0xb25860: ldur            w1, [x0, #0x13]
    // 0xb25864: DecompressPointer r1
    //     0xb25864: add             x1, x1, HEAP, lsl #32
    // 0xb25868: ldur            d0, [fp, #-0x20]
    // 0xb2586c: b               #0xb25798
    // 0xb25870: mov             v1.16b, v0.16b
    // 0xb25874: mov             v0.16b, v1.16b
    // 0xb25878: LeaveFrame
    //     0xb25878: mov             SP, fp
    //     0xb2587c: ldp             fp, lr, [SP], #0x10
    // 0xb25880: ret
    //     0xb25880: ret             
    // 0xb25884: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb25884: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb25888: b               #0xb25738
    // 0xb2588c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2588c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb25890: b               #0xb257ac
    // 0xb25894: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb25894: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb25898, size: 0x78
    // 0xb25898: EnterFrame
    //     0xb25898: stp             fp, lr, [SP, #-0x10]!
    //     0xb2589c: mov             fp, SP
    // 0xb258a0: ldr             x0, [fp, #0x18]
    // 0xb258a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb258a4: ldur            w1, [x0, #0x17]
    // 0xb258a8: DecompressPointer r1
    //     0xb258a8: add             x1, x1, HEAP, lsl #32
    // 0xb258ac: CheckStackOverflow
    //     0xb258ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb258b0: cmp             SP, x16
    //     0xb258b4: b.ls            #0xb258f8
    // 0xb258b8: ldr             x2, [fp, #0x10]
    // 0xb258bc: r0 = computeMinIntrinsicHeight()
    //     0xb258bc: bl              #0xb25718  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::computeMinIntrinsicHeight
    // 0xb258c0: r0 = inline_Allocate_Double()
    //     0xb258c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb258c4: add             x0, x0, #0x10
    //     0xb258c8: cmp             x1, x0
    //     0xb258cc: b.ls            #0xb25900
    //     0xb258d0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb258d4: sub             x0, x0, #0xf
    //     0xb258d8: mov             x1, #0xe19c
    //     0xb258dc: movk            x1, #3, lsl #16
    //     0xb258e0: stur            x1, [x0, #-1]
    // 0xb258e4: dmb             ishst
    // 0xb258e8: StoreField: r0->field_7 = d0
    //     0xb258e8: stur            d0, [x0, #7]
    // 0xb258ec: LeaveFrame
    //     0xb258ec: mov             SP, fp
    //     0xb258f0: ldp             fp, lr, [SP], #0x10
    // 0xb258f4: ret
    //     0xb258f4: ret             
    // 0xb258f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb258f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb258fc: b               #0xb258b8
    // 0xb25900: SaveReg d0
    //     0xb25900: str             q0, [SP, #-0x10]!
    // 0xb25904: r0 = AllocateDouble()
    //     0xb25904: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb25908: RestoreReg d0
    //     0xb25908: ldr             q0, [SP], #0x10
    // 0xb2590c: b               #0xb258e8
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2be08, size: 0x184
    // 0xb2be08: EnterFrame
    //     0xb2be08: stp             fp, lr, [SP, #-0x10]!
    //     0xb2be0c: mov             fp, SP
    // 0xb2be10: AllocStack(0x48)
    //     0xb2be10: sub             SP, SP, #0x48
    // 0xb2be14: SetupParameters(RenderWrap this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2be14: stur            x1, [fp, #-8]
    //     0xb2be18: stur            x2, [fp, #-0x10]
    // 0xb2be1c: CheckStackOverflow
    //     0xb2be1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2be20: cmp             SP, x16
    //     0xb2be24: b.ls            #0xb2bf78
    // 0xb2be28: LoadField: r0 = r1->field_5f
    //     0xb2be28: ldur            w0, [x1, #0x5f]
    // 0xb2be2c: DecompressPointer r0
    //     0xb2be2c: add             x0, x0, HEAP, lsl #32
    // 0xb2be30: LoadField: r3 = r0->field_7
    //     0xb2be30: ldur            x3, [x0, #7]
    // 0xb2be34: cmp             x3, #0
    // 0xb2be38: b.gt            #0xb2be78
    // 0xb2be3c: r0 = BoxConstraints()
    //     0xb2be3c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2be40: StoreField: r0->field_7 = rZR
    //     0xb2be40: stur            xzr, [x0, #7]
    // 0xb2be44: ldur            x1, [fp, #-0x10]
    // 0xb2be48: LoadField: d0 = r1->field_7
    //     0xb2be48: ldur            d0, [x1, #7]
    // 0xb2be4c: StoreField: r0->field_f = d0
    //     0xb2be4c: stur            d0, [x0, #0xf]
    // 0xb2be50: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb2be50: stur            xzr, [x0, #0x17]
    // 0xb2be54: d0 = inf
    //     0xb2be54: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2be58: StoreField: r0->field_1f = d0
    //     0xb2be58: stur            d0, [x0, #0x1f]
    // 0xb2be5c: ldur            x1, [fp, #-8]
    // 0xb2be60: mov             x2, x0
    // 0xb2be64: r0 = getDryLayout()
    //     0xb2be64: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb2be68: LoadField: d0 = r0->field_f
    //     0xb2be68: ldur            d0, [x0, #0xf]
    // 0xb2be6c: LeaveFrame
    //     0xb2be6c: mov             SP, fp
    //     0xb2be70: ldp             fp, lr, [SP], #0x10
    // 0xb2be74: ret
    //     0xb2be74: ret             
    // 0xb2be78: mov             x0, x1
    // 0xb2be7c: LoadField: r1 = r0->field_57
    //     0xb2be7c: ldur            w1, [x0, #0x57]
    // 0xb2be80: DecompressPointer r1
    //     0xb2be80: add             x1, x1, HEAP, lsl #32
    // 0xb2be84: d0 = 0.000000
    //     0xb2be84: eor             v0.16b, v0.16b, v0.16b
    // 0xb2be88: stur            x1, [fp, #-8]
    // 0xb2be8c: stur            d0, [fp, #-0x18]
    // 0xb2be90: CheckStackOverflow
    //     0xb2be90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2be94: cmp             SP, x16
    //     0xb2be98: b.ls            #0xb2bf80
    // 0xb2be9c: cmp             w1, NULL
    // 0xb2bea0: b.eq            #0xb2bf64
    // 0xb2bea4: r0 = LoadClassIdInstr(r1)
    //     0xb2bea4: ldur            x0, [x1, #-1]
    //     0xb2bea8: ubfx            x0, x0, #0xc, #0x14
    // 0xb2beac: str             x1, [SP]
    // 0xb2beb0: r0 = GDT[cid_x0 + 0x120ed]()
    //     0xb2beb0: mov             x17, #0x20ed
    //     0xb2beb4: movk            x17, #1, lsl #16
    //     0xb2beb8: add             lr, x0, x17
    //     0xb2bebc: ldr             lr, [x21, lr, lsl #3]
    //     0xb2bec0: blr             lr
    // 0xb2bec4: r16 = <double, double>
    //     0xb2bec4: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb2bec8: ldr             x16, [x16, #0x228]
    // 0xb2becc: ldur            lr, [fp, #-8]
    // 0xb2bed0: stp             lr, x16, [SP, #0x18]
    // 0xb2bed4: r16 = Instance__IntrinsicDimension
    //     0xb2bed4: add             x16, PP, #0x90, lsl #12  ; [pp+0x90bc8] Obj!_IntrinsicDimension@12c46c1
    //     0xb2bed8: ldr             x16, [x16, #0xbc8]
    // 0xb2bedc: r30 = inf
    //     0xb2bedc: add             lr, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xb2bee0: ldr             lr, [lr, #0x8a8]
    // 0xb2bee4: stp             lr, x16, [SP, #8]
    // 0xb2bee8: str             x0, [SP]
    // 0xb2beec: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb2beec: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb2bef0: r0 = _computeIntrinsics()
    //     0xb2bef0: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb2bef4: LoadField: d0 = r0->field_7
    //     0xb2bef4: ldur            d0, [x0, #7]
    // 0xb2bef8: ldur            d1, [fp, #-0x18]
    // 0xb2befc: fadd            d2, d1, d0
    // 0xb2bf00: ldur            x0, [fp, #-8]
    // 0xb2bf04: stur            d2, [fp, #-0x20]
    // 0xb2bf08: LoadField: r3 = r0->field_7
    //     0xb2bf08: ldur            w3, [x0, #7]
    // 0xb2bf0c: DecompressPointer r3
    //     0xb2bf0c: add             x3, x3, HEAP, lsl #32
    // 0xb2bf10: stur            x3, [fp, #-0x10]
    // 0xb2bf14: cmp             w3, NULL
    // 0xb2bf18: b.eq            #0xb2bf88
    // 0xb2bf1c: mov             x0, x3
    // 0xb2bf20: r2 = Null
    //     0xb2bf20: mov             x2, NULL
    // 0xb2bf24: r1 = Null
    //     0xb2bf24: mov             x1, NULL
    // 0xb2bf28: r4 = LoadClassIdInstr(r0)
    //     0xb2bf28: ldur            x4, [x0, #-1]
    //     0xb2bf2c: ubfx            x4, x4, #0xc, #0x14
    // 0xb2bf30: r17 = 4207
    //     0xb2bf30: mov             x17, #0x106f
    // 0xb2bf34: cmp             x4, x17
    // 0xb2bf38: b.eq            #0xb2bf50
    // 0xb2bf3c: r8 = WrapParentData
    //     0xb2bf3c: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e4c0] Type: WrapParentData
    //     0xb2bf40: ldr             x8, [x8, #0x4c0]
    // 0xb2bf44: r3 = Null
    //     0xb2bf44: add             x3, PP, #0x98, lsl #12  ; [pp+0x984b0] Null
    //     0xb2bf48: ldr             x3, [x3, #0x4b0]
    // 0xb2bf4c: r0 = DefaultTypeTest()
    //     0xb2bf4c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb2bf50: ldur            x0, [fp, #-0x10]
    // 0xb2bf54: LoadField: r1 = r0->field_13
    //     0xb2bf54: ldur            w1, [x0, #0x13]
    // 0xb2bf58: DecompressPointer r1
    //     0xb2bf58: add             x1, x1, HEAP, lsl #32
    // 0xb2bf5c: ldur            d0, [fp, #-0x20]
    // 0xb2bf60: b               #0xb2be88
    // 0xb2bf64: mov             v1.16b, v0.16b
    // 0xb2bf68: mov             v0.16b, v1.16b
    // 0xb2bf6c: LeaveFrame
    //     0xb2bf6c: mov             SP, fp
    //     0xb2bf70: ldp             fp, lr, [SP], #0x10
    // 0xb2bf74: ret
    //     0xb2bf74: ret             
    // 0xb2bf78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2bf78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2bf7c: b               #0xb2be28
    // 0xb2bf80: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2bf80: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2bf84: b               #0xb2be9c
    // 0xb2bf88: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb2bf88: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2bf8c, size: 0x78
    // 0xb2bf8c: EnterFrame
    //     0xb2bf8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2bf90: mov             fp, SP
    // 0xb2bf94: ldr             x0, [fp, #0x18]
    // 0xb2bf98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2bf98: ldur            w1, [x0, #0x17]
    // 0xb2bf9c: DecompressPointer r1
    //     0xb2bf9c: add             x1, x1, HEAP, lsl #32
    // 0xb2bfa0: CheckStackOverflow
    //     0xb2bfa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2bfa4: cmp             SP, x16
    //     0xb2bfa8: b.ls            #0xb2bfec
    // 0xb2bfac: ldr             x2, [fp, #0x10]
    // 0xb2bfb0: r0 = computeMaxIntrinsicHeight()
    //     0xb2bfb0: bl              #0xb2be08  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::computeMaxIntrinsicHeight
    // 0xb2bfb4: r0 = inline_Allocate_Double()
    //     0xb2bfb4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2bfb8: add             x0, x0, #0x10
    //     0xb2bfbc: cmp             x1, x0
    //     0xb2bfc0: b.ls            #0xb2bff4
    //     0xb2bfc4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2bfc8: sub             x0, x0, #0xf
    //     0xb2bfcc: mov             x1, #0xe19c
    //     0xb2bfd0: movk            x1, #3, lsl #16
    //     0xb2bfd4: stur            x1, [x0, #-1]
    // 0xb2bfd8: dmb             ishst
    // 0xb2bfdc: StoreField: r0->field_7 = d0
    //     0xb2bfdc: stur            d0, [x0, #7]
    // 0xb2bfe0: LeaveFrame
    //     0xb2bfe0: mov             SP, fp
    //     0xb2bfe4: ldp             fp, lr, [SP], #0x10
    // 0xb2bfe8: ret
    //     0xb2bfe8: ret             
    // 0xb2bfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2bfec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2bff0: b               #0xb2bfac
    // 0xb2bff4: SaveReg d0
    //     0xb2bff4: str             q0, [SP, #-0x10]!
    // 0xb2bff8: r0 = AllocateDouble()
    //     0xb2bff8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2bffc: RestoreReg d0
    //     0xb2bffc: ldr             q0, [SP], #0x10
    // 0xb2c000: b               #0xb2bfdc
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2edb8, size: 0x184
    // 0xb2edb8: EnterFrame
    //     0xb2edb8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2edbc: mov             fp, SP
    // 0xb2edc0: AllocStack(0x58)
    //     0xb2edc0: sub             SP, SP, #0x58
    // 0xb2edc4: SetupParameters(RenderWrap this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xb2edc4: stur            x1, [fp, #-0x18]
    //     0xb2edc8: stur            x2, [fp, #-0x20]
    // 0xb2edcc: CheckStackOverflow
    //     0xb2edcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2edd0: cmp             SP, x16
    //     0xb2edd4: b.ls            #0xb2ef28
    // 0xb2edd8: LoadField: r0 = r1->field_5f
    //     0xb2edd8: ldur            w0, [x1, #0x5f]
    // 0xb2eddc: DecompressPointer r0
    //     0xb2eddc: add             x0, x0, HEAP, lsl #32
    // 0xb2ede0: LoadField: r3 = r0->field_7
    //     0xb2ede0: ldur            x3, [x0, #7]
    // 0xb2ede4: cmp             x3, #0
    // 0xb2ede8: b.gt            #0xb2eeec
    // 0xb2edec: LoadField: r0 = r1->field_57
    //     0xb2edec: ldur            w0, [x1, #0x57]
    // 0xb2edf0: DecompressPointer r0
    //     0xb2edf0: add             x0, x0, HEAP, lsl #32
    // 0xb2edf4: mov             x1, x0
    // 0xb2edf8: d0 = 0.000000
    //     0xb2edf8: eor             v0.16b, v0.16b, v0.16b
    // 0xb2edfc: stur            x1, [fp, #-8]
    // 0xb2ee00: stur            d0, [fp, #-0x28]
    // 0xb2ee04: CheckStackOverflow
    //     0xb2ee04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ee08: cmp             SP, x16
    //     0xb2ee0c: b.ls            #0xb2ef30
    // 0xb2ee10: cmp             w1, NULL
    // 0xb2ee14: b.eq            #0xb2eed8
    // 0xb2ee18: r0 = LoadClassIdInstr(r1)
    //     0xb2ee18: ldur            x0, [x1, #-1]
    //     0xb2ee1c: ubfx            x0, x0, #0xc, #0x14
    // 0xb2ee20: str             x1, [SP]
    // 0xb2ee24: r0 = GDT[cid_x0 + 0x12498]()
    //     0xb2ee24: mov             x17, #0x2498
    //     0xb2ee28: movk            x17, #1, lsl #16
    //     0xb2ee2c: add             lr, x0, x17
    //     0xb2ee30: ldr             lr, [x21, lr, lsl #3]
    //     0xb2ee34: blr             lr
    // 0xb2ee38: r16 = <double, double>
    //     0xb2ee38: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7c228] TypeArguments: <double, double>
    //     0xb2ee3c: ldr             x16, [x16, #0x228]
    // 0xb2ee40: ldur            lr, [fp, #-8]
    // 0xb2ee44: stp             lr, x16, [SP, #0x18]
    // 0xb2ee48: r16 = Instance__IntrinsicDimension
    //     0xb2ee48: add             x16, PP, #0x96, lsl #12  ; [pp+0x969d8] Obj!_IntrinsicDimension@12c46a1
    //     0xb2ee4c: ldr             x16, [x16, #0x9d8]
    // 0xb2ee50: r30 = inf
    //     0xb2ee50: add             lr, PP, #0x15, lsl #12  ; [pp+0x158a8] inf
    //     0xb2ee54: ldr             lr, [lr, #0x8a8]
    // 0xb2ee58: stp             lr, x16, [SP, #8]
    // 0xb2ee5c: str             x0, [SP]
    // 0xb2ee60: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb2ee60: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb2ee64: r0 = _computeIntrinsics()
    //     0xb2ee64: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb2ee68: LoadField: d0 = r0->field_7
    //     0xb2ee68: ldur            d0, [x0, #7]
    // 0xb2ee6c: ldur            d1, [fp, #-0x28]
    // 0xb2ee70: fadd            d2, d1, d0
    // 0xb2ee74: ldur            x0, [fp, #-8]
    // 0xb2ee78: stur            d2, [fp, #-0x30]
    // 0xb2ee7c: LoadField: r3 = r0->field_7
    //     0xb2ee7c: ldur            w3, [x0, #7]
    // 0xb2ee80: DecompressPointer r3
    //     0xb2ee80: add             x3, x3, HEAP, lsl #32
    // 0xb2ee84: stur            x3, [fp, #-0x10]
    // 0xb2ee88: cmp             w3, NULL
    // 0xb2ee8c: b.eq            #0xb2ef38
    // 0xb2ee90: mov             x0, x3
    // 0xb2ee94: r2 = Null
    //     0xb2ee94: mov             x2, NULL
    // 0xb2ee98: r1 = Null
    //     0xb2ee98: mov             x1, NULL
    // 0xb2ee9c: r4 = LoadClassIdInstr(r0)
    //     0xb2ee9c: ldur            x4, [x0, #-1]
    //     0xb2eea0: ubfx            x4, x4, #0xc, #0x14
    // 0xb2eea4: r17 = 4207
    //     0xb2eea4: mov             x17, #0x106f
    // 0xb2eea8: cmp             x4, x17
    // 0xb2eeac: b.eq            #0xb2eec4
    // 0xb2eeb0: r8 = WrapParentData
    //     0xb2eeb0: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e4c0] Type: WrapParentData
    //     0xb2eeb4: ldr             x8, [x8, #0x4c0]
    // 0xb2eeb8: r3 = Null
    //     0xb2eeb8: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa27c8] Null
    //     0xb2eebc: ldr             x3, [x3, #0x7c8]
    // 0xb2eec0: r0 = DefaultTypeTest()
    //     0xb2eec0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb2eec4: ldur            x0, [fp, #-0x10]
    // 0xb2eec8: LoadField: r1 = r0->field_13
    //     0xb2eec8: ldur            w1, [x0, #0x13]
    // 0xb2eecc: DecompressPointer r1
    //     0xb2eecc: add             x1, x1, HEAP, lsl #32
    // 0xb2eed0: ldur            d0, [fp, #-0x30]
    // 0xb2eed4: b               #0xb2edfc
    // 0xb2eed8: mov             v1.16b, v0.16b
    // 0xb2eedc: mov             v0.16b, v1.16b
    // 0xb2eee0: LeaveFrame
    //     0xb2eee0: mov             SP, fp
    //     0xb2eee4: ldp             fp, lr, [SP], #0x10
    // 0xb2eee8: ret
    //     0xb2eee8: ret             
    // 0xb2eeec: r0 = BoxConstraints()
    //     0xb2eeec: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2eef0: StoreField: r0->field_7 = rZR
    //     0xb2eef0: stur            xzr, [x0, #7]
    // 0xb2eef4: d0 = inf
    //     0xb2eef4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2eef8: StoreField: r0->field_f = d0
    //     0xb2eef8: stur            d0, [x0, #0xf]
    // 0xb2eefc: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb2eefc: stur            xzr, [x0, #0x17]
    // 0xb2ef00: ldur            x1, [fp, #-0x20]
    // 0xb2ef04: LoadField: d0 = r1->field_7
    //     0xb2ef04: ldur            d0, [x1, #7]
    // 0xb2ef08: StoreField: r0->field_1f = d0
    //     0xb2ef08: stur            d0, [x0, #0x1f]
    // 0xb2ef0c: ldur            x1, [fp, #-0x18]
    // 0xb2ef10: mov             x2, x0
    // 0xb2ef14: r0 = getDryLayout()
    //     0xb2ef14: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb2ef18: LoadField: d0 = r0->field_7
    //     0xb2ef18: ldur            d0, [x0, #7]
    // 0xb2ef1c: LeaveFrame
    //     0xb2ef1c: mov             SP, fp
    //     0xb2ef20: ldp             fp, lr, [SP], #0x10
    // 0xb2ef24: ret
    //     0xb2ef24: ret             
    // 0xb2ef28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ef28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ef2c: b               #0xb2edd8
    // 0xb2ef30: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2ef30: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2ef34: b               #0xb2ee10
    // 0xb2ef38: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb2ef38: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2ef3c, size: 0x78
    // 0xb2ef3c: EnterFrame
    //     0xb2ef3c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ef40: mov             fp, SP
    // 0xb2ef44: ldr             x0, [fp, #0x18]
    // 0xb2ef48: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2ef48: ldur            w1, [x0, #0x17]
    // 0xb2ef4c: DecompressPointer r1
    //     0xb2ef4c: add             x1, x1, HEAP, lsl #32
    // 0xb2ef50: CheckStackOverflow
    //     0xb2ef50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ef54: cmp             SP, x16
    //     0xb2ef58: b.ls            #0xb2ef9c
    // 0xb2ef5c: ldr             x2, [fp, #0x10]
    // 0xb2ef60: r0 = computeMaxIntrinsicWidth()
    //     0xb2ef60: bl              #0xb2edb8  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::computeMaxIntrinsicWidth
    // 0xb2ef64: r0 = inline_Allocate_Double()
    //     0xb2ef64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2ef68: add             x0, x0, #0x10
    //     0xb2ef6c: cmp             x1, x0
    //     0xb2ef70: b.ls            #0xb2efa4
    //     0xb2ef74: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2ef78: sub             x0, x0, #0xf
    //     0xb2ef7c: mov             x1, #0xe19c
    //     0xb2ef80: movk            x1, #3, lsl #16
    //     0xb2ef84: stur            x1, [x0, #-1]
    // 0xb2ef88: dmb             ishst
    // 0xb2ef8c: StoreField: r0->field_7 = d0
    //     0xb2ef8c: stur            d0, [x0, #7]
    // 0xb2ef90: LeaveFrame
    //     0xb2ef90: mov             SP, fp
    //     0xb2ef94: ldp             fp, lr, [SP], #0x10
    // 0xb2ef98: ret
    //     0xb2ef98: ret             
    // 0xb2ef9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ef9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2efa0: b               #0xb2ef5c
    // 0xb2efa4: SaveReg d0
    //     0xb2efa4: str             q0, [SP, #-0x10]!
    // 0xb2efa8: r0 = AllocateDouble()
    //     0xb2efa8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2efac: RestoreReg d0
    //     0xb2efac: ldr             q0, [SP], #0x10
    // 0xb2efb0: b               #0xb2ef8c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb52544, size: 0x2c
    // 0xb52544: EnterFrame
    //     0xb52544: stp             fp, lr, [SP, #-0x10]!
    //     0xb52548: mov             fp, SP
    // 0xb5254c: CheckStackOverflow
    //     0xb5254c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb52550: cmp             SP, x16
    //     0xb52554: b.ls            #0xb52568
    // 0xb52558: r0 = _computeDryLayout()
    //     0xb52558: bl              #0xb52570  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::_computeDryLayout
    // 0xb5255c: LeaveFrame
    //     0xb5255c: mov             SP, fp
    //     0xb52560: ldp             fp, lr, [SP], #0x10
    // 0xb52564: ret
    //     0xb52564: ret             
    // 0xb52568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb52568: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5256c: b               #0xb52558
  }
  _ _computeDryLayout(/* No info */) {
    // ** addr: 0xb52570, size: 0x3e0
    // 0xb52570: EnterFrame
    //     0xb52570: stp             fp, lr, [SP, #-0x10]!
    //     0xb52574: mov             fp, SP
    // 0xb52578: AllocStack(0x80)
    //     0xb52578: sub             SP, SP, #0x80
    // 0xb5257c: SetupParameters(RenderWrap this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xb5257c: mov             x0, x1
    //     0xb52580: stur            x1, [fp, #-0x10]
    //     0xb52584: mov             x1, x2
    //     0xb52588: stur            x2, [fp, #-0x18]
    // 0xb5258c: CheckStackOverflow
    //     0xb5258c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb52590: cmp             SP, x16
    //     0xb52594: b.ls            #0xb52904
    // 0xb52598: LoadField: r2 = r0->field_5f
    //     0xb52598: ldur            w2, [x0, #0x5f]
    // 0xb5259c: DecompressPointer r2
    //     0xb5259c: add             x2, x2, HEAP, lsl #32
    // 0xb525a0: LoadField: r3 = r2->field_7
    //     0xb525a0: ldur            x3, [x2, #7]
    // 0xb525a4: stur            x3, [fp, #-8]
    // 0xb525a8: cmp             x3, #0
    // 0xb525ac: b.gt            #0xb52610
    // 0xb525b0: LoadField: d0 = r1->field_f
    //     0xb525b0: ldur            d0, [x1, #0xf]
    // 0xb525b4: stur            d0, [fp, #-0x40]
    // 0xb525b8: r0 = BoxConstraints()
    //     0xb525b8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb525bc: StoreField: r0->field_7 = rZR
    //     0xb525bc: stur            xzr, [x0, #7]
    // 0xb525c0: ldur            d0, [fp, #-0x40]
    // 0xb525c4: StoreField: r0->field_f = d0
    //     0xb525c4: stur            d0, [x0, #0xf]
    // 0xb525c8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb525c8: stur            xzr, [x0, #0x17]
    // 0xb525cc: d1 = inf
    //     0xb525cc: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb525d0: StoreField: r0->field_1f = d1
    //     0xb525d0: stur            d1, [x0, #0x1f]
    // 0xb525d4: r3 = inline_Allocate_Double()
    //     0xb525d4: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb525d8: add             x3, x3, #0x10
    //     0xb525dc: cmp             x1, x3
    //     0xb525e0: b.ls            #0xb5290c
    //     0xb525e4: str             x3, [THR, #0x60]  ; THR::top
    //     0xb525e8: sub             x3, x3, #0xf
    //     0xb525ec: mov             x1, #0xe19c
    //     0xb525f0: movk            x1, #3, lsl #16
    //     0xb525f4: stur            x1, [x3, #-1]
    // 0xb525f8: dmb             ishst
    // 0xb525fc: StoreField: r3->field_7 = d0
    //     0xb525fc: stur            d0, [x3, #7]
    // 0xb52600: mov             x2, x0
    // 0xb52604: r0 = AllocateRecord2()
    //     0xb52604: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb52608: mov             x1, x0
    // 0xb5260c: b               #0xb52670
    // 0xb52610: d1 = inf
    //     0xb52610: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb52614: LoadField: d0 = r1->field_1f
    //     0xb52614: ldur            d0, [x1, #0x1f]
    // 0xb52618: stur            d0, [fp, #-0x40]
    // 0xb5261c: r0 = BoxConstraints()
    //     0xb5261c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb52620: StoreField: r0->field_7 = rZR
    //     0xb52620: stur            xzr, [x0, #7]
    // 0xb52624: d0 = inf
    //     0xb52624: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb52628: StoreField: r0->field_f = d0
    //     0xb52628: stur            d0, [x0, #0xf]
    // 0xb5262c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb5262c: stur            xzr, [x0, #0x17]
    // 0xb52630: ldur            d0, [fp, #-0x40]
    // 0xb52634: StoreField: r0->field_1f = d0
    //     0xb52634: stur            d0, [x0, #0x1f]
    // 0xb52638: r3 = inline_Allocate_Double()
    //     0xb52638: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb5263c: add             x3, x3, #0x10
    //     0xb52640: cmp             x1, x3
    //     0xb52644: b.ls            #0xb52928
    //     0xb52648: str             x3, [THR, #0x60]  ; THR::top
    //     0xb5264c: sub             x3, x3, #0xf
    //     0xb52650: mov             x1, #0xe19c
    //     0xb52654: movk            x1, #3, lsl #16
    //     0xb52658: stur            x1, [x3, #-1]
    // 0xb5265c: dmb             ishst
    // 0xb52660: StoreField: r3->field_7 = d0
    //     0xb52660: stur            d0, [x3, #7]
    // 0xb52664: mov             x2, x0
    // 0xb52668: r0 = AllocateRecord2()
    //     0xb52668: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb5266c: mov             x1, x0
    // 0xb52670: ldur            x0, [fp, #-0x10]
    // 0xb52674: LoadField: r3 = r1->field_f
    //     0xb52674: ldur            w3, [x1, #0xf]
    // 0xb52678: DecompressPointer r3
    //     0xb52678: add             x3, x3, HEAP, lsl #32
    // 0xb5267c: stur            x3, [fp, #-0x28]
    // 0xb52680: LoadField: r2 = r1->field_13
    //     0xb52680: ldur            w2, [x1, #0x13]
    // 0xb52684: DecompressPointer r2
    //     0xb52684: add             x2, x2, HEAP, lsl #32
    // 0xb52688: LoadField: r1 = r0->field_57
    //     0xb52688: ldur            w1, [x0, #0x57]
    // 0xb5268c: DecompressPointer r1
    //     0xb5268c: add             x1, x1, HEAP, lsl #32
    // 0xb52690: LoadField: d0 = r2->field_7
    //     0xb52690: ldur            d0, [x2, #7]
    // 0xb52694: stur            d0, [fp, #-0x60]
    // 0xb52698: mov             x4, x1
    // 0xb5269c: ldur            x1, [fp, #-8]
    // 0xb526a0: d4 = 0.000000
    //     0xb526a0: eor             v4.16b, v4.16b, v4.16b
    // 0xb526a4: d3 = 0.000000
    //     0xb526a4: eor             v3.16b, v3.16b, v3.16b
    // 0xb526a8: d2 = 0.000000
    //     0xb526a8: eor             v2.16b, v2.16b, v2.16b
    // 0xb526ac: d1 = 0.000000
    //     0xb526ac: eor             v1.16b, v1.16b, v1.16b
    // 0xb526b0: r5 = 0
    //     0xb526b0: mov             x5, #0
    // 0xb526b4: stur            x5, [fp, #-8]
    // 0xb526b8: stur            x4, [fp, #-0x20]
    // 0xb526bc: stur            d4, [fp, #-0x40]
    // 0xb526c0: stur            d3, [fp, #-0x48]
    // 0xb526c4: stur            d2, [fp, #-0x50]
    // 0xb526c8: stur            d1, [fp, #-0x58]
    // 0xb526cc: CheckStackOverflow
    //     0xb526cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb526d0: cmp             SP, x16
    //     0xb526d4: b.ls            #0xb52944
    // 0xb526d8: cmp             w4, NULL
    // 0xb526dc: b.eq            #0xb52890
    // 0xb526e0: mov             x1, x4
    // 0xb526e4: mov             x2, x3
    // 0xb526e8: r0 = getDryLayout()
    //     0xb526e8: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb526ec: ldur            x3, [fp, #-0x10]
    // 0xb526f0: LoadField: r1 = r3->field_5f
    //     0xb526f0: ldur            w1, [x3, #0x5f]
    // 0xb526f4: DecompressPointer r1
    //     0xb526f4: add             x1, x1, HEAP, lsl #32
    // 0xb526f8: LoadField: r4 = r1->field_7
    //     0xb526f8: ldur            x4, [x1, #7]
    // 0xb526fc: stur            x4, [fp, #-0x38]
    // 0xb52700: cmp             x4, #0
    // 0xb52704: b.gt            #0xb52710
    // 0xb52708: LoadField: d0 = r0->field_7
    //     0xb52708: ldur            d0, [x0, #7]
    // 0xb5270c: b               #0xb52714
    // 0xb52710: LoadField: d0 = r0->field_f
    //     0xb52710: ldur            d0, [x0, #0xf]
    // 0xb52714: cmp             x4, #0
    // 0xb52718: b.gt            #0xb52728
    // 0xb5271c: LoadField: d5 = r0->field_f
    //     0xb5271c: ldur            d5, [x0, #0xf]
    // 0xb52720: mov             v1.16b, v5.16b
    // 0xb52724: b               #0xb52730
    // 0xb52728: LoadField: d5 = r0->field_7
    //     0xb52728: ldur            d5, [x0, #7]
    // 0xb5272c: mov             v1.16b, v5.16b
    // 0xb52730: ldur            x0, [fp, #-8]
    // 0xb52734: cmp             x0, #0
    // 0xb52738: b.le            #0xb5279c
    // 0xb5273c: ldur            d5, [fp, #-0x50]
    // 0xb52740: ldur            d2, [fp, #-0x60]
    // 0xb52744: fadd            d3, d5, d0
    // 0xb52748: LoadField: d4 = r3->field_67
    //     0xb52748: ldur            d4, [x3, #0x67]
    // 0xb5274c: fadd            d6, d3, d4
    // 0xb52750: fcmp            d6, d2
    // 0xb52754: b.le            #0xb5278c
    // 0xb52758: ldur            d4, [fp, #-0x40]
    // 0xb5275c: ldur            d3, [fp, #-0x48]
    // 0xb52760: ldur            d6, [fp, #-0x58]
    // 0xb52764: fmax            v7.2d, v4.2d, v5.2d
    // 0xb52768: LoadField: d4 = r3->field_73
    //     0xb52768: ldur            d4, [x3, #0x73]
    // 0xb5276c: fadd            d5, d6, d4
    // 0xb52770: fadd            d6, d3, d5
    // 0xb52774: mov             v5.16b, v6.16b
    // 0xb52778: mov             v6.16b, v7.16b
    // 0xb5277c: d4 = 0.000000
    //     0xb5277c: eor             v4.16b, v4.16b, v4.16b
    // 0xb52780: d3 = 0.000000
    //     0xb52780: eor             v3.16b, v3.16b, v3.16b
    // 0xb52784: r0 = 0
    //     0xb52784: mov             x0, #0
    // 0xb52788: b               #0xb527d4
    // 0xb5278c: ldur            d4, [fp, #-0x40]
    // 0xb52790: ldur            d3, [fp, #-0x48]
    // 0xb52794: ldur            d6, [fp, #-0x58]
    // 0xb52798: b               #0xb527b0
    // 0xb5279c: ldur            d4, [fp, #-0x40]
    // 0xb527a0: ldur            d3, [fp, #-0x48]
    // 0xb527a4: ldur            d5, [fp, #-0x50]
    // 0xb527a8: ldur            d6, [fp, #-0x58]
    // 0xb527ac: ldur            d2, [fp, #-0x60]
    // 0xb527b0: mov             v31.16b, v5.16b
    // 0xb527b4: mov             v5.16b, v4.16b
    // 0xb527b8: mov             v4.16b, v31.16b
    // 0xb527bc: mov             v31.16b, v3.16b
    // 0xb527c0: mov             v3.16b, v5.16b
    // 0xb527c4: mov             v5.16b, v31.16b
    // 0xb527c8: mov             v31.16b, v6.16b
    // 0xb527cc: mov             v6.16b, v3.16b
    // 0xb527d0: mov             v3.16b, v31.16b
    // 0xb527d4: stur            d6, [fp, #-0x78]
    // 0xb527d8: stur            d5, [fp, #-0x80]
    // 0xb527dc: fadd            d7, d4, d0
    // 0xb527e0: fmax            v0.2d, v3.2d, v1.2d
    // 0xb527e4: stur            d0, [fp, #-0x70]
    // 0xb527e8: cmp             x0, #0
    // 0xb527ec: b.le            #0xb52800
    // 0xb527f0: LoadField: d1 = r3->field_67
    //     0xb527f0: ldur            d1, [x3, #0x67]
    // 0xb527f4: fadd            d8, d7, d1
    // 0xb527f8: mov             v1.16b, v8.16b
    // 0xb527fc: b               #0xb52804
    // 0xb52800: mov             v1.16b, v7.16b
    // 0xb52804: ldur            x1, [fp, #-0x20]
    // 0xb52808: stur            d1, [fp, #-0x68]
    // 0xb5280c: add             x5, x0, #1
    // 0xb52810: stur            x5, [fp, #-8]
    // 0xb52814: LoadField: r6 = r1->field_7
    //     0xb52814: ldur            w6, [x1, #7]
    // 0xb52818: DecompressPointer r6
    //     0xb52818: add             x6, x6, HEAP, lsl #32
    // 0xb5281c: stur            x6, [fp, #-0x30]
    // 0xb52820: cmp             w6, NULL
    // 0xb52824: b.eq            #0xb5294c
    // 0xb52828: mov             x0, x6
    // 0xb5282c: r2 = Null
    //     0xb5282c: mov             x2, NULL
    // 0xb52830: r1 = Null
    //     0xb52830: mov             x1, NULL
    // 0xb52834: r4 = LoadClassIdInstr(r0)
    //     0xb52834: ldur            x4, [x0, #-1]
    //     0xb52838: ubfx            x4, x4, #0xc, #0x14
    // 0xb5283c: r17 = 4207
    //     0xb5283c: mov             x17, #0x106f
    // 0xb52840: cmp             x4, x17
    // 0xb52844: b.eq            #0xb5285c
    // 0xb52848: r8 = WrapParentData
    //     0xb52848: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e4c0] Type: WrapParentData
    //     0xb5284c: ldr             x8, [x8, #0x4c0]
    // 0xb52850: r3 = Null
    //     0xb52850: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e5d0] Null
    //     0xb52854: ldr             x3, [x3, #0x5d0]
    // 0xb52858: r0 = DefaultTypeTest()
    //     0xb52858: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb5285c: ldur            x0, [fp, #-0x30]
    // 0xb52860: LoadField: r4 = r0->field_13
    //     0xb52860: ldur            w4, [x0, #0x13]
    // 0xb52864: DecompressPointer r4
    //     0xb52864: add             x4, x4, HEAP, lsl #32
    // 0xb52868: ldur            d4, [fp, #-0x78]
    // 0xb5286c: ldur            d3, [fp, #-0x80]
    // 0xb52870: ldur            d2, [fp, #-0x68]
    // 0xb52874: ldur            d1, [fp, #-0x70]
    // 0xb52878: ldur            x5, [fp, #-8]
    // 0xb5287c: ldur            x1, [fp, #-0x38]
    // 0xb52880: ldur            x0, [fp, #-0x10]
    // 0xb52884: ldur            x3, [fp, #-0x28]
    // 0xb52888: ldur            d0, [fp, #-0x60]
    // 0xb5288c: b               #0xb526b4
    // 0xb52890: mov             v5.16b, v2.16b
    // 0xb52894: mov             v6.16b, v1.16b
    // 0xb52898: fadd            d0, d3, d6
    // 0xb5289c: stur            d0, [fp, #-0x60]
    // 0xb528a0: fmax            v1.2d, v4.2d, v5.2d
    // 0xb528a4: stur            d1, [fp, #-0x48]
    // 0xb528a8: cmp             x1, #0
    // 0xb528ac: b.gt            #0xb528cc
    // 0xb528b0: r0 = Size()
    //     0xb528b0: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb528b4: ldur            d0, [fp, #-0x48]
    // 0xb528b8: StoreField: r0->field_7 = d0
    //     0xb528b8: stur            d0, [x0, #7]
    // 0xb528bc: ldur            d1, [fp, #-0x60]
    // 0xb528c0: StoreField: r0->field_f = d1
    //     0xb528c0: stur            d1, [x0, #0xf]
    // 0xb528c4: mov             x2, x0
    // 0xb528c8: b               #0xb528f0
    // 0xb528cc: mov             v31.16b, v1.16b
    // 0xb528d0: mov             v1.16b, v0.16b
    // 0xb528d4: mov             v0.16b, v31.16b
    // 0xb528d8: r0 = Size()
    //     0xb528d8: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb528dc: ldur            d0, [fp, #-0x60]
    // 0xb528e0: StoreField: r0->field_7 = d0
    //     0xb528e0: stur            d0, [x0, #7]
    // 0xb528e4: ldur            d0, [fp, #-0x48]
    // 0xb528e8: StoreField: r0->field_f = d0
    //     0xb528e8: stur            d0, [x0, #0xf]
    // 0xb528ec: mov             x2, x0
    // 0xb528f0: ldur            x1, [fp, #-0x18]
    // 0xb528f4: r0 = constrain()
    //     0xb528f4: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb528f8: LeaveFrame
    //     0xb528f8: mov             SP, fp
    //     0xb528fc: ldp             fp, lr, [SP], #0x10
    // 0xb52900: ret
    //     0xb52900: ret             
    // 0xb52904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb52904: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb52908: b               #0xb52598
    // 0xb5290c: SaveReg d0
    //     0xb5290c: str             q0, [SP, #-0x10]!
    // 0xb52910: SaveReg r0
    //     0xb52910: str             x0, [SP, #-8]!
    // 0xb52914: r0 = AllocateDouble()
    //     0xb52914: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb52918: mov             x3, x0
    // 0xb5291c: RestoreReg r0
    //     0xb5291c: ldr             x0, [SP], #8
    // 0xb52920: RestoreReg d0
    //     0xb52920: ldr             q0, [SP], #0x10
    // 0xb52924: b               #0xb525fc
    // 0xb52928: SaveReg d0
    //     0xb52928: str             q0, [SP, #-0x10]!
    // 0xb5292c: SaveReg r0
    //     0xb5292c: str             x0, [SP, #-8]!
    // 0xb52930: r0 = AllocateDouble()
    //     0xb52930: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb52934: mov             x3, x0
    // 0xb52938: RestoreReg r0
    //     0xb52938: ldr             x0, [SP], #8
    // 0xb5293c: RestoreReg d0
    //     0xb5293c: ldr             q0, [SP], #0x10
    // 0xb52940: b               #0xb52660
    // 0xb52944: r0 = StackOverflowSharedWithFPURegs()
    //     0xb52944: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb52948: b               #0xb526d8
    // 0xb5294c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb5294c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb5872c, size: 0x24
    // 0xb5872c: EnterFrame
    //     0xb5872c: stp             fp, lr, [SP, #-0x10]!
    //     0xb58730: mov             fp, SP
    // 0xb58734: ldr             x2, [fp, #0x10]
    // 0xb58738: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58738: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa27c0] AnonymousClosure: (0xb2ef3c), in [package:flutter/src/rendering/wrap.dart] RenderWrap::computeMaxIntrinsicWidth (0xb2edb8)
    //     0xb5873c: ldr             x1, [x1, #0x7c0]
    // 0xb58740: r0 = AllocateClosure()
    //     0xb58740: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58744: LeaveFrame
    //     0xb58744: mov             SP, fp
    //     0xb58748: ldp             fp, lr, [SP], #0x10
    // 0xb5874c: ret
    //     0xb5874c: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5c2d8, size: 0x2c
    // 0xb5c2d8: EnterFrame
    //     0xb5c2d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb5c2dc: mov             fp, SP
    // 0xb5c2e0: CheckStackOverflow
    //     0xb5c2e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5c2e4: cmp             SP, x16
    //     0xb5c2e8: b.ls            #0xb5c2fc
    // 0xb5c2ec: r0 = defaultComputeDistanceToHighestActualBaseline()
    //     0xb5c2ec: bl              #0xb5c304  ; [dart:mixin_deduplication] _MixinApplication453&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultComputeDistanceToHighestActualBaseline
    // 0xb5c2f0: LeaveFrame
    //     0xb5c2f0: mov             SP, fp
    //     0xb5c2f4: ldp             fp, lr, [SP], #0x10
    // 0xb5c2f8: ret
    //     0xb5c2f8: ret             
    // 0xb5c2fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5c2fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5c300: b               #0xb5c2ec
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e930, size: 0x24
    // 0xb5e930: EnterFrame
    //     0xb5e930: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e934: mov             fp, SP
    // 0xb5e938: ldr             x2, [fp, #0x10]
    // 0xb5e93c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e93c: add             x1, PP, #0x98, lsl #12  ; [pp+0x984a8] AnonymousClosure: (0xb2bf8c), in [package:flutter/src/rendering/wrap.dart] RenderWrap::computeMaxIntrinsicHeight (0xb2be08)
    //     0xb5e940: ldr             x1, [x1, #0x4a8]
    // 0xb5e944: r0 = AllocateClosure()
    //     0xb5e944: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e948: LeaveFrame
    //     0xb5e948: mov             SP, fp
    //     0xb5e94c: ldp             fp, lr, [SP], #0x10
    // 0xb5e950: ret
    //     0xb5e950: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb65ab4, size: 0x26c
    // 0xb65ab4: EnterFrame
    //     0xb65ab4: stp             fp, lr, [SP, #-0x10]!
    //     0xb65ab8: mov             fp, SP
    // 0xb65abc: AllocStack(0x38)
    //     0xb65abc: sub             SP, SP, #0x38
    // 0xb65ac0: SetupParameters(RenderWrap this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb65ac0: mov             x0, x2
    //     0xb65ac4: stur            x1, [fp, #-8]
    //     0xb65ac8: stur            x2, [fp, #-0x10]
    //     0xb65acc: stur            x3, [fp, #-0x18]
    // 0xb65ad0: CheckStackOverflow
    //     0xb65ad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb65ad4: cmp             SP, x16
    //     0xb65ad8: b.ls            #0xb65d18
    // 0xb65adc: r1 = 3
    //     0xb65adc: mov             x1, #3
    // 0xb65ae0: r0 = AllocateContext()
    //     0xb65ae0: bl              #0x13de838  ; AllocateContextStub
    // 0xb65ae4: mov             x3, x0
    // 0xb65ae8: ldur            x0, [fp, #-0x18]
    // 0xb65aec: stur            x3, [fp, #-0x20]
    // 0xb65af0: StoreField: r3->field_f = r0
    //     0xb65af0: stur            w0, [x3, #0xf]
    // 0xb65af4: ldur            x0, [fp, #-0x10]
    // 0xb65af8: r2 = Null
    //     0xb65af8: mov             x2, NULL
    // 0xb65afc: r1 = Null
    //     0xb65afc: mov             x1, NULL
    // 0xb65b00: r4 = 60
    //     0xb65b00: mov             x4, #0x3c
    // 0xb65b04: branchIfSmi(r0, 0xb65b10)
    //     0xb65b04: tbz             w0, #0, #0xb65b10
    // 0xb65b08: r4 = LoadClassIdInstr(r0)
    //     0xb65b08: ldur            x4, [x0, #-1]
    //     0xb65b0c: ubfx            x4, x4, #0xc, #0x14
    // 0xb65b10: sub             x4, x4, #0xb46
    // 0xb65b14: cmp             x4, #1
    // 0xb65b18: b.ls            #0xb65b2c
    // 0xb65b1c: r8 = BoxConstraints
    //     0xb65b1c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb65b20: r3 = Null
    //     0xb65b20: add             x3, PP, #0x98, lsl #12  ; [pp+0x984c0] Null
    //     0xb65b24: ldr             x3, [x3, #0x4c0]
    // 0xb65b28: r0 = BoxConstraints()
    //     0xb65b28: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb65b2c: ldur            x1, [fp, #-8]
    // 0xb65b30: LoadField: r0 = r1->field_57
    //     0xb65b30: ldur            w0, [x1, #0x57]
    // 0xb65b34: DecompressPointer r0
    //     0xb65b34: add             x0, x0, HEAP, lsl #32
    // 0xb65b38: cmp             w0, NULL
    // 0xb65b3c: b.ne            #0xb65b50
    // 0xb65b40: r0 = Null
    //     0xb65b40: mov             x0, NULL
    // 0xb65b44: LeaveFrame
    //     0xb65b44: mov             SP, fp
    //     0xb65b48: ldp             fp, lr, [SP], #0x10
    // 0xb65b4c: ret
    //     0xb65b4c: ret             
    // 0xb65b50: LoadField: r0 = r1->field_5f
    //     0xb65b50: ldur            w0, [x1, #0x5f]
    // 0xb65b54: DecompressPointer r0
    //     0xb65b54: add             x0, x0, HEAP, lsl #32
    // 0xb65b58: LoadField: r2 = r0->field_7
    //     0xb65b58: ldur            x2, [x0, #7]
    // 0xb65b5c: cmp             x2, #0
    // 0xb65b60: b.gt            #0xb65b94
    // 0xb65b64: ldur            x2, [fp, #-0x10]
    // 0xb65b68: LoadField: d0 = r2->field_f
    //     0xb65b68: ldur            d0, [x2, #0xf]
    // 0xb65b6c: stur            d0, [fp, #-0x38]
    // 0xb65b70: r0 = BoxConstraints()
    //     0xb65b70: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb65b74: StoreField: r0->field_7 = rZR
    //     0xb65b74: stur            xzr, [x0, #7]
    // 0xb65b78: ldur            d0, [fp, #-0x38]
    // 0xb65b7c: StoreField: r0->field_f = d0
    //     0xb65b7c: stur            d0, [x0, #0xf]
    // 0xb65b80: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb65b80: stur            xzr, [x0, #0x17]
    // 0xb65b84: d0 = inf
    //     0xb65b84: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb65b88: StoreField: r0->field_1f = d0
    //     0xb65b88: stur            d0, [x0, #0x1f]
    // 0xb65b8c: mov             x1, x0
    // 0xb65b90: b               #0xb65bc4
    // 0xb65b94: ldur            x2, [fp, #-0x10]
    // 0xb65b98: d0 = inf
    //     0xb65b98: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb65b9c: LoadField: d1 = r2->field_1f
    //     0xb65b9c: ldur            d1, [x2, #0x1f]
    // 0xb65ba0: stur            d1, [fp, #-0x38]
    // 0xb65ba4: r0 = BoxConstraints()
    //     0xb65ba4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb65ba8: StoreField: r0->field_7 = rZR
    //     0xb65ba8: stur            xzr, [x0, #7]
    // 0xb65bac: d0 = inf
    //     0xb65bac: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb65bb0: StoreField: r0->field_f = d0
    //     0xb65bb0: stur            d0, [x0, #0xf]
    // 0xb65bb4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb65bb4: stur            xzr, [x0, #0x17]
    // 0xb65bb8: ldur            d0, [fp, #-0x38]
    // 0xb65bbc: StoreField: r0->field_1f = d0
    //     0xb65bbc: stur            d0, [x0, #0x1f]
    // 0xb65bc0: mov             x1, x0
    // 0xb65bc4: ldur            x0, [fp, #-0x20]
    // 0xb65bc8: StoreField: r0->field_13 = r1
    //     0xb65bc8: stur            w1, [x0, #0x13]
    // 0xb65bcc: ldur            x1, [fp, #-8]
    // 0xb65bd0: ldur            x2, [fp, #-0x10]
    // 0xb65bd4: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb65bd4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb65bd8: ldr             x3, [x3, #0x700]
    // 0xb65bdc: r0 = _computeRuns()
    //     0xb65bdc: bl              #0xb66740  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::_computeRuns
    // 0xb65be0: mov             x3, x0
    // 0xb65be4: stur            x3, [fp, #-0x28]
    // 0xb65be8: mov             x4, x1
    // 0xb65bec: stur            x4, [fp, #-0x18]
    // 0xb65bf0: r0 = LoadClassIdInstr(r3)
    //     0xb65bf0: ldur            x0, [x3, #-1]
    //     0xb65bf4: ubfx            x0, x0, #0xc, #0x14
    // 0xb65bf8: sub             x16, x0, #0xeda
    // 0xb65bfc: cmp             x16, #1
    // 0xb65c00: b.hi            #0xb65cf8
    // 0xb65c04: mov             x0, x4
    // 0xb65c08: r2 = Null
    //     0xb65c08: mov             x2, NULL
    // 0xb65c0c: r1 = Null
    //     0xb65c0c: mov             x1, NULL
    // 0xb65c10: cmp             w0, NULL
    // 0xb65c14: b.eq            #0xb65c60
    // 0xb65c18: branchIfSmi(r0, 0xb65c60)
    //     0xb65c18: tbz             w0, #0, #0xb65c60
    // 0xb65c1c: r3 = SubtypeTestCache
    //     0xb65c1c: add             x3, PP, #0x98, lsl #12  ; [pp+0x984d0] SubtypeTestCache
    //     0xb65c20: ldr             x3, [x3, #0x4d0]
    // 0xb65c24: r30 = Subtype2TestCacheStub
    //     0xb65c24: ldr             lr, [PP, #0x30]  ; [pp+0x30] Stub: Subtype2TestCache (0x7d2e44)
    // 0xb65c28: LoadField: r30 = r30->field_7
    //     0xb65c28: ldur            lr, [lr, #7]
    // 0xb65c2c: blr             lr
    // 0xb65c30: cmp             w7, NULL
    // 0xb65c34: b.eq            #0xb65c40
    // 0xb65c38: tbnz            w7, #4, #0xb65c60
    // 0xb65c3c: b               #0xb65c68
    // 0xb65c40: r8 = List<_RunMetrics>
    //     0xb65c40: add             x8, PP, #0x98, lsl #12  ; [pp+0x984d8] Type: List<_RunMetrics>
    //     0xb65c44: ldr             x8, [x8, #0x4d8]
    // 0xb65c48: r3 = SubtypeTestCache
    //     0xb65c48: add             x3, PP, #0x98, lsl #12  ; [pp+0x984e0] SubtypeTestCache
    //     0xb65c4c: ldr             x3, [x3, #0x4e0]
    // 0xb65c50: r30 = InstanceOfStub
    //     0xb65c50: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xb65c54: LoadField: r30 = r30->field_7
    //     0xb65c54: ldur            lr, [lr, #7]
    // 0xb65c58: blr             lr
    // 0xb65c5c: b               #0xb65c6c
    // 0xb65c60: r0 = false
    //     0xb65c60: add             x0, NULL, #0x30  ; false
    // 0xb65c64: b               #0xb65c6c
    // 0xb65c68: r0 = true
    //     0xb65c68: add             x0, NULL, #0x20  ; true
    // 0xb65c6c: tbnz            w0, #4, #0xb65cf8
    // 0xb65c70: ldur            x4, [fp, #-8]
    // 0xb65c74: ldur            x0, [fp, #-0x20]
    // 0xb65c78: LoadField: r3 = r4->field_5f
    //     0xb65c78: ldur            w3, [x4, #0x5f]
    // 0xb65c7c: DecompressPointer r3
    //     0xb65c7c: add             x3, x3, HEAP, lsl #32
    // 0xb65c80: ldur            x1, [fp, #-0x28]
    // 0xb65c84: ldur            x2, [fp, #-0x10]
    // 0xb65c88: r0 = _AxisSize.applyConstraints()
    //     0xb65c88: bl              #0xb18ad0  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.applyConstraints
    // 0xb65c8c: mov             x3, x0
    // 0xb65c90: ldur            x0, [fp, #-0x20]
    // 0xb65c94: stur            x3, [fp, #-0x10]
    // 0xb65c98: ArrayStore: r0[0] = rNULL  ; List_4
    //     0xb65c98: stur            NULL, [x0, #0x17]
    // 0xb65c9c: mov             x2, x0
    // 0xb65ca0: r1 = Function 'findHighestBaseline':.
    //     0xb65ca0: add             x1, PP, #0x98, lsl #12  ; [pp+0x984e8] AnonymousClosure: (0xb66d88), in [package:flutter/src/rendering/wrap.dart] RenderWrap::computeDryBaseline (0xb65ab4)
    //     0xb65ca4: ldr             x1, [x1, #0x4e8]
    // 0xb65ca8: r0 = AllocateClosure()
    //     0xb65ca8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb65cac: ldur            x2, [fp, #-0x20]
    // 0xb65cb0: r1 = Function 'getChildSize':.
    //     0xb65cb0: add             x1, PP, #0x98, lsl #12  ; [pp+0x984f0] AnonymousClosure: (0xb66d44), in [package:flutter/src/rendering/wrap.dart] RenderWrap::computeDryBaseline (0xb65ab4)
    //     0xb65cb4: ldr             x1, [x1, #0x4f0]
    // 0xb65cb8: stur            x0, [fp, #-0x30]
    // 0xb65cbc: r0 = AllocateClosure()
    //     0xb65cbc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb65cc0: ldur            x1, [fp, #-8]
    // 0xb65cc4: ldur            x2, [fp, #-0x18]
    // 0xb65cc8: ldur            x3, [fp, #-0x28]
    // 0xb65ccc: ldur            x5, [fp, #-0x10]
    // 0xb65cd0: ldur            x6, [fp, #-0x30]
    // 0xb65cd4: mov             x7, x0
    // 0xb65cd8: r0 = _positionChildren()
    //     0xb65cd8: bl              #0xb65d20  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::_positionChildren
    // 0xb65cdc: ldur            x0, [fp, #-0x20]
    // 0xb65ce0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb65ce0: ldur            w1, [x0, #0x17]
    // 0xb65ce4: DecompressPointer r1
    //     0xb65ce4: add             x1, x1, HEAP, lsl #32
    // 0xb65ce8: mov             x0, x1
    // 0xb65cec: LeaveFrame
    //     0xb65cec: mov             SP, fp
    //     0xb65cf0: ldp             fp, lr, [SP], #0x10
    // 0xb65cf4: ret
    //     0xb65cf4: ret             
    // 0xb65cf8: r0 = StateError()
    //     0xb65cf8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb65cfc: mov             x1, x0
    // 0xb65d00: r0 = "Pattern matching error"
    //     0xb65d00: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e528] "Pattern matching error"
    //     0xb65d04: ldr             x0, [x0, #0x528]
    // 0xb65d08: StoreField: r1->field_b = r0
    //     0xb65d08: stur            w0, [x1, #0xb]
    // 0xb65d0c: mov             x0, x1
    // 0xb65d10: r0 = Throw()
    //     0xb65d10: bl              #0x13ddb2c  ; ThrowStub
    // 0xb65d14: brk             #0
    // 0xb65d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb65d18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb65d1c: b               #0xb65adc
  }
  _ _positionChildren(/* No info */) {
    // ** addr: 0xb65d20, size: 0x480
    // 0xb65d20: EnterFrame
    //     0xb65d20: stp             fp, lr, [SP, #-0x10]!
    //     0xb65d24: mov             fp, SP
    // 0xb65d28: AllocStack(0xc8)
    //     0xb65d28: sub             SP, SP, #0xc8
    // 0xb65d2c: SetupParameters(RenderWrap this /* r1 => r6, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x28 */, dynamic _ /* r7 => r0, fp-0x30 */)
    //     0xb65d2c: mov             x4, x2
    //     0xb65d30: stur            x2, [fp, #-0x10]
    //     0xb65d34: mov             x2, x6
    //     0xb65d38: stur            x6, [fp, #-0x28]
    //     0xb65d3c: mov             x6, x1
    //     0xb65d40: mov             x0, x7
    //     0xb65d44: stur            x1, [fp, #-8]
    //     0xb65d48: stur            x3, [fp, #-0x18]
    //     0xb65d4c: stur            x5, [fp, #-0x20]
    //     0xb65d50: stur            x7, [fp, #-0x30]
    // 0xb65d54: CheckStackOverflow
    //     0xb65d54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb65d58: cmp             SP, x16
    //     0xb65d5c: b.ls            #0xb66188
    // 0xb65d60: mov             x1, x6
    // 0xb65d64: r0 = distanceMax()
    //     0xb65d64: bl              #0xa12b54  ; [package:flutter/src/gestures/events.dart] PointerEvent::distanceMax
    // 0xb65d68: ldur            x1, [fp, #-0x18]
    // 0xb65d6c: stur            d0, [fp, #-0x70]
    // 0xb65d70: r0 = r()
    //     0xb65d70: bl              #0x12d84e8  ; [dart:ui] Color::r
    // 0xb65d74: mov             v1.16b, v0.16b
    // 0xb65d78: d0 = 0.000000
    //     0xb65d78: eor             v0.16b, v0.16b, v0.16b
    // 0xb65d7c: fmax            v2.2d, v0.2d, v1.2d
    // 0xb65d80: ldur            x1, [fp, #-8]
    // 0xb65d84: stur            d2, [fp, #-0x78]
    // 0xb65d88: r0 = _areAxesFlipped()
    //     0xb65d88: bl              #0xb6660c  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::_areAxesFlipped
    // 0xb65d8c: mov             x3, x0
    // 0xb65d90: stur            x3, [fp, #-0x38]
    // 0xb65d94: mov             x2, x1
    // 0xb65d98: stur            x2, [fp, #-0x18]
    // 0xb65d9c: tbnz            w2, #4, #0xb65db8
    // 0xb65da0: ldur            x1, [fp, #-8]
    // 0xb65da4: r0 = traversalChildIdentifier()
    //     0xb65da4: bl              #0x88daf4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::traversalChildIdentifier
    // 0xb65da8: mov             x1, x0
    // 0xb65dac: r0 = _flipped()
    //     0xb65dac: bl              #0xb665d4  ; [package:flutter/src/rendering/wrap.dart] WrapCrossAlignment::_flipped
    // 0xb65db0: mov             x2, x0
    // 0xb65db4: b               #0xb65dc4
    // 0xb65db8: ldur            x1, [fp, #-8]
    // 0xb65dbc: r0 = traversalChildIdentifier()
    //     0xb65dbc: bl              #0x88daf4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::traversalChildIdentifier
    // 0xb65dc0: mov             x2, x0
    // 0xb65dc4: ldur            x0, [fp, #-0x10]
    // 0xb65dc8: ldur            x3, [fp, #-0x38]
    // 0xb65dcc: ldur            x1, [fp, #-8]
    // 0xb65dd0: stur            x2, [fp, #-0x40]
    // 0xb65dd4: r0 = runAlignment()
    //     0xb65dd4: bl              #0xb665c8  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::runAlignment
    // 0xb65dd8: ldur            x1, [fp, #-8]
    // 0xb65ddc: stur            x0, [fp, #-0x48]
    // 0xb65de0: r0 = runSpacing()
    //     0xb65de0: bl              #0xb665c0  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::runSpacing
    // 0xb65de4: ldur            x1, [fp, #-0x10]
    // 0xb65de8: stur            d0, [fp, #-0x80]
    // 0xb65dec: r0 = LoadClassIdInstr(r1)
    //     0xb65dec: ldur            x0, [x1, #-1]
    //     0xb65df0: ubfx            x0, x0, #0xc, #0x14
    // 0xb65df4: str             x1, [SP]
    // 0xb65df8: r0 = GDT[cid_x0 + 0xf078]()
    //     0xb65df8: mov             x17, #0xf078
    //     0xb65dfc: add             lr, x0, x17
    //     0xb65e00: ldr             lr, [x21, lr, lsl #3]
    //     0xb65e04: blr             lr
    // 0xb65e08: r2 = LoadInt32Instr(r0)
    //     0xb65e08: sbfx            x2, x0, #1, #0x1f
    //     0xb65e0c: tbz             w0, #0, #0xb65e14
    //     0xb65e10: ldur            x2, [x0, #7]
    // 0xb65e14: ldur            x1, [fp, #-0x48]
    // 0xb65e18: ldur            d0, [fp, #-0x78]
    // 0xb65e1c: ldur            d1, [fp, #-0x80]
    // 0xb65e20: ldur            x3, [fp, #-0x18]
    // 0xb65e24: r0 = _distributeSpace()
    //     0xb65e24: bl              #0xb661e0  ; [package:flutter/src/rendering/wrap.dart] WrapAlignment::_distributeSpace
    // 0xb65e28: mov             x3, x0
    // 0xb65e2c: stur            x3, [fp, #-0x50]
    // 0xb65e30: mov             x4, x1
    // 0xb65e34: ldur            x0, [fp, #-0x38]
    // 0xb65e38: stur            x4, [fp, #-0x48]
    // 0xb65e3c: tbnz            w0, #4, #0xb65e58
    // 0xb65e40: ldur            x2, [fp, #-8]
    // 0xb65e44: r1 = Function 'childBefore':.
    //     0xb65e44: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e540] AnonymousClosure: (0xb66690), of [dart:mixin_deduplication] _MixinApplication452&RenderBox&ContainerRenderObjectMixin
    //     0xb65e48: ldr             x1, [x1, #0x540]
    // 0xb65e4c: r0 = AllocateClosure()
    //     0xb65e4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb65e50: mov             x2, x0
    // 0xb65e54: b               #0xb65e6c
    // 0xb65e58: ldur            x2, [fp, #-8]
    // 0xb65e5c: r1 = Function 'childAfter':.
    //     0xb65e5c: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e548] AnonymousClosure: (0xb20360), of [dart:mixin_deduplication] _MixinApplication452&RenderBox&ContainerRenderObjectMixin
    //     0xb65e60: ldr             x1, [x1, #0x548]
    // 0xb65e64: r0 = AllocateClosure()
    //     0xb65e64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb65e68: mov             x2, x0
    // 0xb65e6c: ldur            x0, [fp, #-0x18]
    // 0xb65e70: stur            x2, [fp, #-0x58]
    // 0xb65e74: tbnz            w0, #4, #0xb65ea0
    // 0xb65e78: ldur            x1, [fp, #-0x10]
    // 0xb65e7c: r0 = LoadClassIdInstr(r1)
    //     0xb65e7c: ldur            x0, [x1, #-1]
    //     0xb65e80: ubfx            x0, x0, #0xc, #0x14
    // 0xb65e84: r0 = GDT[cid_x0 + 0x18751]()
    //     0xb65e84: mov             x17, #0x8751
    //     0xb65e88: movk            x17, #1, lsl #16
    //     0xb65e8c: add             lr, x0, x17
    //     0xb65e90: ldr             lr, [x21, lr, lsl #3]
    //     0xb65e94: blr             lr
    // 0xb65e98: mov             x1, x0
    // 0xb65e9c: b               #0xb65ea4
    // 0xb65ea0: ldur            x1, [fp, #-0x10]
    // 0xb65ea4: ldur            x5, [fp, #-0x20]
    // 0xb65ea8: ldur            x4, [fp, #-0x40]
    // 0xb65eac: ldur            x2, [fp, #-0x50]
    // 0xb65eb0: ldur            x3, [fp, #-0x48]
    // 0xb65eb4: r0 = LoadClassIdInstr(r1)
    //     0xb65eb4: ldur            x0, [x1, #-1]
    //     0xb65eb8: ubfx            x0, x0, #0xc, #0x14
    // 0xb65ebc: r0 = GDT[cid_x0 + 0x12641]()
    //     0xb65ebc: mov             x17, #0x2641
    //     0xb65ec0: movk            x17, #1, lsl #16
    //     0xb65ec4: add             lr, x0, x17
    //     0xb65ec8: ldr             lr, [x21, lr, lsl #3]
    //     0xb65ecc: blr             lr
    // 0xb65ed0: mov             x2, x0
    // 0xb65ed4: ldur            x0, [fp, #-0x50]
    // 0xb65ed8: stur            x2, [fp, #-0x10]
    // 0xb65edc: LoadField: d0 = r0->field_7
    //     0xb65edc: ldur            d0, [x0, #7]
    // 0xb65ee0: ldur            x0, [fp, #-0x20]
    // 0xb65ee4: LoadField: d1 = r0->field_7
    //     0xb65ee4: ldur            d1, [x0, #7]
    // 0xb65ee8: ldur            x0, [fp, #-0x40]
    // 0xb65eec: stur            d1, [fp, #-0x88]
    // 0xb65ef0: LoadField: r3 = r0->field_7
    //     0xb65ef0: ldur            x3, [x0, #7]
    // 0xb65ef4: ldur            x0, [fp, #-0x48]
    // 0xb65ef8: stur            x3, [fp, #-0x60]
    // 0xb65efc: LoadField: d2 = r0->field_7
    //     0xb65efc: ldur            d2, [x0, #7]
    // 0xb65f00: stur            d2, [fp, #-0x80]
    // 0xb65f04: ldur            x4, [fp, #-8]
    // 0xb65f08: stur            d0, [fp, #-0x78]
    // 0xb65f0c: CheckStackOverflow
    //     0xb65f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb65f10: cmp             SP, x16
    //     0xb65f14: b.ls            #0xb66190
    // 0xb65f18: r0 = LoadClassIdInstr(r2)
    //     0xb65f18: ldur            x0, [x2, #-1]
    //     0xb65f1c: ubfx            x0, x0, #0xc, #0x14
    // 0xb65f20: mov             x1, x2
    // 0xb65f24: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xb65f24: mov             x17, #0x845b
    //     0xb65f28: movk            x17, #1, lsl #16
    //     0xb65f2c: add             lr, x0, x17
    //     0xb65f30: ldr             lr, [x21, lr, lsl #3]
    //     0xb65f34: blr             lr
    // 0xb65f38: tbnz            w0, #4, #0xb66178
    // 0xb65f3c: ldur            x3, [fp, #-8]
    // 0xb65f40: ldur            x2, [fp, #-0x10]
    // 0xb65f44: ldur            d0, [fp, #-0x88]
    // 0xb65f48: r0 = LoadClassIdInstr(r2)
    //     0xb65f48: ldur            x0, [x2, #-1]
    //     0xb65f4c: ubfx            x0, x0, #0xc, #0x14
    // 0xb65f50: mov             x1, x2
    // 0xb65f54: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xb65f54: mov             x17, #0x7d4c
    //     0xb65f58: movk            x17, #1, lsl #16
    //     0xb65f5c: add             lr, x0, x17
    //     0xb65f60: ldr             lr, [x21, lr, lsl #3]
    //     0xb65f64: blr             lr
    // 0xb65f68: stur            x0, [fp, #-0x18]
    // 0xb65f6c: LoadField: r1 = r0->field_7
    //     0xb65f6c: ldur            w1, [x0, #7]
    // 0xb65f70: DecompressPointer r1
    //     0xb65f70: add             x1, x1, HEAP, lsl #32
    // 0xb65f74: LoadField: d2 = r1->field_f
    //     0xb65f74: ldur            d2, [x1, #0xf]
    // 0xb65f78: stur            d2, [fp, #-0x90]
    // 0xb65f7c: LoadField: r2 = r0->field_b
    //     0xb65f7c: ldur            x2, [x0, #0xb]
    // 0xb65f80: LoadField: d0 = r1->field_7
    //     0xb65f80: ldur            d0, [x1, #7]
    // 0xb65f84: ldur            d3, [fp, #-0x88]
    // 0xb65f88: fsub            d1, d3, d0
    // 0xb65f8c: d4 = 0.000000
    //     0xb65f8c: eor             v4.16b, v4.16b, v4.16b
    // 0xb65f90: fmax            v0.2d, v4.2d, v1.2d
    // 0xb65f94: ldur            x4, [fp, #-8]
    // 0xb65f98: LoadField: r1 = r4->field_63
    //     0xb65f98: ldur            w1, [x4, #0x63]
    // 0xb65f9c: DecompressPointer r1
    //     0xb65f9c: add             x1, x1, HEAP, lsl #32
    // 0xb65fa0: ldur            d1, [fp, #-0x70]
    // 0xb65fa4: ldur            x3, [fp, #-0x38]
    // 0xb65fa8: r0 = _distributeSpace()
    //     0xb65fa8: bl              #0xb661e0  ; [package:flutter/src/rendering/wrap.dart] WrapAlignment::_distributeSpace
    // 0xb65fac: mov             x2, x0
    // 0xb65fb0: mov             x3, x1
    // 0xb65fb4: ldur            x0, [fp, #-0x18]
    // 0xb65fb8: LoadField: r1 = r0->field_b
    //     0xb65fb8: ldur            x1, [x0, #0xb]
    // 0xb65fbc: LoadField: r4 = r0->field_13
    //     0xb65fbc: ldur            w4, [x0, #0x13]
    // 0xb65fc0: DecompressPointer r4
    //     0xb65fc0: add             x4, x4, HEAP, lsl #32
    // 0xb65fc4: LoadField: d0 = r2->field_7
    //     0xb65fc4: ldur            d0, [x2, #7]
    // 0xb65fc8: LoadField: d1 = r3->field_7
    //     0xb65fc8: ldur            d1, [x3, #7]
    // 0xb65fcc: stur            d1, [fp, #-0xa0]
    // 0xb65fd0: mov             v3.16b, v0.16b
    // 0xb65fd4: mov             x3, x4
    // 0xb65fd8: mov             x4, x1
    // 0xb65fdc: ldur            x1, [fp, #-8]
    // 0xb65fe0: ldur            d2, [fp, #-0x78]
    // 0xb65fe4: ldur            x2, [fp, #-0x60]
    // 0xb65fe8: ldur            d0, [fp, #-0x90]
    // 0xb65fec: stur            x4, [fp, #-0x68]
    // 0xb65ff0: stur            x3, [fp, #-0x18]
    // 0xb65ff4: stur            d3, [fp, #-0x98]
    // 0xb65ff8: CheckStackOverflow
    //     0xb65ff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb65ffc: cmp             SP, x16
    //     0xb66000: b.ls            #0xb66198
    // 0xb66004: cmp             w3, NULL
    // 0xb66008: b.eq            #0xb66154
    // 0xb6600c: cmp             x4, #0
    // 0xb66010: b.le            #0xb66154
    // 0xb66014: ldur            x16, [fp, #-0x30]
    // 0xb66018: stp             x3, x16, [SP]
    // 0xb6601c: ldur            x0, [fp, #-0x30]
    // 0xb66020: ClosureCall
    //     0xb66020: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb66024: ldur            x2, [x0, #0x1f]
    //     0xb66028: blr             x2
    // 0xb6602c: mov             x1, x0
    // 0xb66030: ldur            x0, [fp, #-8]
    // 0xb66034: LoadField: r2 = r0->field_5f
    //     0xb66034: ldur            w2, [x0, #0x5f]
    // 0xb66038: DecompressPointer r2
    //     0xb66038: add             x2, x2, HEAP, lsl #32
    // 0xb6603c: r0 = _AxisSize._convert()
    //     0xb6603c: bl              #0xb661a0  ; [package:flutter/src/rendering/wrap.dart] ::_AxisSize._convert
    // 0xb66040: LoadField: d0 = r0->field_7
    //     0xb66040: ldur            d0, [x0, #7]
    // 0xb66044: stur            d0, [fp, #-0xb0]
    // 0xb66048: LoadField: d1 = r0->field_f
    //     0xb66048: ldur            d1, [x0, #0xf]
    // 0xb6604c: ldur            x0, [fp, #-0x60]
    // 0xb66050: cmp             x0, #1
    // 0xb66054: b.gt            #0xb66070
    // 0xb66058: cmp             x0, #0
    // 0xb6605c: b.gt            #0xb66068
    // 0xb66060: d4 = 0.000000
    //     0xb66060: eor             v4.16b, v4.16b, v4.16b
    // 0xb66064: b               #0xb66074
    // 0xb66068: d4 = 1.000000
    //     0xb66068: fmov            d4, #1.00000000
    // 0xb6606c: b               #0xb66074
    // 0xb66070: d4 = 0.500000
    //     0xb66070: fmov            d4, #0.50000000
    // 0xb66074: ldur            x1, [fp, #-8]
    // 0xb66078: ldur            d3, [fp, #-0x78]
    // 0xb6607c: ldur            d2, [fp, #-0x90]
    // 0xb66080: fsub            d5, d2, d1
    // 0xb66084: fmul            d1, d4, d5
    // 0xb66088: fadd            d4, d3, d1
    // 0xb6608c: stur            d4, [fp, #-0xa8]
    // 0xb66090: LoadField: r2 = r1->field_5f
    //     0xb66090: ldur            w2, [x1, #0x5f]
    // 0xb66094: DecompressPointer r2
    //     0xb66094: add             x2, x2, HEAP, lsl #32
    // 0xb66098: LoadField: r3 = r2->field_7
    //     0xb66098: ldur            x3, [x2, #7]
    // 0xb6609c: cmp             x3, #0
    // 0xb660a0: b.gt            #0xb660c0
    // 0xb660a4: ldur            d1, [fp, #-0x98]
    // 0xb660a8: r0 = Offset()
    //     0xb660a8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb660ac: ldur            d0, [fp, #-0x98]
    // 0xb660b0: StoreField: r0->field_7 = d0
    //     0xb660b0: stur            d0, [x0, #7]
    // 0xb660b4: ldur            d1, [fp, #-0xa8]
    // 0xb660b8: StoreField: r0->field_f = d1
    //     0xb660b8: stur            d1, [x0, #0xf]
    // 0xb660bc: b               #0xb660dc
    // 0xb660c0: ldur            d0, [fp, #-0x98]
    // 0xb660c4: mov             v1.16b, v4.16b
    // 0xb660c8: r0 = Offset()
    //     0xb660c8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb660cc: ldur            d0, [fp, #-0xa8]
    // 0xb660d0: StoreField: r0->field_7 = d0
    //     0xb660d0: stur            d0, [x0, #7]
    // 0xb660d4: ldur            d0, [fp, #-0x98]
    // 0xb660d8: StoreField: r0->field_f = d0
    //     0xb660d8: stur            d0, [x0, #0xf]
    // 0xb660dc: ldur            x1, [fp, #-0x68]
    // 0xb660e0: ldur            d1, [fp, #-0xb0]
    // 0xb660e4: ldur            d2, [fp, #-0xa0]
    // 0xb660e8: ldur            x16, [fp, #-0x28]
    // 0xb660ec: stp             x0, x16, [SP, #8]
    // 0xb660f0: ldur            x16, [fp, #-0x18]
    // 0xb660f4: str             x16, [SP]
    // 0xb660f8: ldur            x0, [fp, #-0x28]
    // 0xb660fc: ClosureCall
    //     0xb660fc: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb66100: ldur            x2, [x0, #0x1f]
    //     0xb66104: blr             x2
    // 0xb66108: ldur            d0, [fp, #-0xb0]
    // 0xb6610c: ldur            d1, [fp, #-0xa0]
    // 0xb66110: fadd            d2, d0, d1
    // 0xb66114: ldur            d0, [fp, #-0x98]
    // 0xb66118: fadd            d3, d0, d2
    // 0xb6611c: stur            d3, [fp, #-0xa8]
    // 0xb66120: ldur            x16, [fp, #-0x58]
    // 0xb66124: ldur            lr, [fp, #-0x18]
    // 0xb66128: stp             lr, x16, [SP]
    // 0xb6612c: ldur            x0, [fp, #-0x58]
    // 0xb66130: ClosureCall
    //     0xb66130: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb66134: ldur            x2, [x0, #0x1f]
    //     0xb66138: blr             x2
    // 0xb6613c: ldur            x1, [fp, #-0x68]
    // 0xb66140: sub             x4, x1, #1
    // 0xb66144: ldur            d3, [fp, #-0xa8]
    // 0xb66148: mov             x3, x0
    // 0xb6614c: ldur            d1, [fp, #-0xa0]
    // 0xb66150: b               #0xb65fdc
    // 0xb66154: ldur            d1, [fp, #-0x78]
    // 0xb66158: ldur            d0, [fp, #-0x90]
    // 0xb6615c: ldur            d2, [fp, #-0x80]
    // 0xb66160: fadd            d3, d0, d2
    // 0xb66164: fadd            d0, d1, d3
    // 0xb66168: ldur            x2, [fp, #-0x10]
    // 0xb6616c: ldur            x3, [fp, #-0x60]
    // 0xb66170: ldur            d1, [fp, #-0x88]
    // 0xb66174: b               #0xb65f04
    // 0xb66178: r0 = Null
    //     0xb66178: mov             x0, NULL
    // 0xb6617c: LeaveFrame
    //     0xb6617c: mov             SP, fp
    //     0xb66180: ldp             fp, lr, [SP], #0x10
    // 0xb66184: ret
    //     0xb66184: ret             
    // 0xb66188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb66188: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6618c: b               #0xb65d60
    // 0xb66190: r0 = StackOverflowSharedWithFPURegs()
    //     0xb66190: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb66194: b               #0xb65f18
    // 0xb66198: r0 = StackOverflowSharedWithFPURegs()
    //     0xb66198: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb6619c: b               #0xb66004
  }
  get _ runSpacing(/* No info */) {
    // ** addr: 0xb665c0, size: 0x8
    // 0xb665c0: LoadField: d0 = r1->field_73
    //     0xb665c0: ldur            d0, [x1, #0x73]
    // 0xb665c4: ret
    //     0xb665c4: ret             
  }
  get _ runAlignment(/* No info */) {
    // ** addr: 0xb665c8, size: 0xc
    // 0xb665c8: LoadField: r0 = r1->field_6f
    //     0xb665c8: ldur            w0, [x1, #0x6f]
    // 0xb665cc: DecompressPointer r0
    //     0xb665cc: add             x0, x0, HEAP, lsl #32
    // 0xb665d0: ret
    //     0xb665d0: ret             
  }
  get _ _areAxesFlipped(/* No info */) {
    // ** addr: 0xb6660c, size: 0x84
    // 0xb6660c: EnterFrame
    //     0xb6660c: stp             fp, lr, [SP, #-0x10]!
    //     0xb66610: mov             fp, SP
    // 0xb66614: LoadField: r0 = r1->field_7f
    //     0xb66614: ldur            w0, [x1, #0x7f]
    // 0xb66618: DecompressPointer r0
    //     0xb66618: add             x0, x0, HEAP, lsl #32
    // 0xb6661c: cmp             w0, NULL
    // 0xb66620: b.ne            #0xb66628
    // 0xb66624: r0 = Instance_TextDirection
    //     0xb66624: ldr             x0, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xb66628: LoadField: r2 = r0->field_7
    //     0xb66628: ldur            x2, [x0, #7]
    // 0xb6662c: cmp             x2, #0
    // 0xb66630: b.gt            #0xb6663c
    // 0xb66634: r2 = true
    //     0xb66634: add             x2, NULL, #0x20  ; true
    // 0xb66638: b               #0xb66640
    // 0xb6663c: r2 = false
    //     0xb6663c: add             x2, NULL, #0x30  ; false
    // 0xb66640: LoadField: r0 = r1->field_5f
    //     0xb66640: ldur            w0, [x1, #0x5f]
    // 0xb66644: DecompressPointer r0
    //     0xb66644: add             x0, x0, HEAP, lsl #32
    // 0xb66648: LoadField: r1 = r0->field_7
    //     0xb66648: ldur            x1, [x0, #7]
    // 0xb6664c: cmp             x1, #0
    // 0xb66650: b.gt            #0xb66664
    // 0xb66654: r3 = false
    //     0xb66654: add             x3, NULL, #0x30  ; false
    // 0xb66658: r0 = AllocateRecord2()
    //     0xb66658: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb6665c: mov             x2, x0
    // 0xb66660: b               #0xb66674
    // 0xb66664: mov             x3, x2
    // 0xb66668: r2 = false
    //     0xb66668: add             x2, NULL, #0x30  ; false
    // 0xb6666c: r0 = AllocateRecord2()
    //     0xb6666c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb66670: mov             x2, x0
    // 0xb66674: LoadField: r0 = r2->field_f
    //     0xb66674: ldur            w0, [x2, #0xf]
    // 0xb66678: DecompressPointer r0
    //     0xb66678: add             x0, x0, HEAP, lsl #32
    // 0xb6667c: LoadField: r1 = r2->field_13
    //     0xb6667c: ldur            w1, [x2, #0x13]
    // 0xb66680: DecompressPointer r1
    //     0xb66680: add             x1, x1, HEAP, lsl #32
    // 0xb66684: LeaveFrame
    //     0xb66684: mov             SP, fp
    //     0xb66688: ldp             fp, lr, [SP], #0x10
    // 0xb6668c: ret
    //     0xb6668c: ret             
  }
  _ _computeRuns(/* No info */) {
    // ** addr: 0xb66740, size: 0x490
    // 0xb66740: EnterFrame
    //     0xb66740: stp             fp, lr, [SP, #-0x10]!
    //     0xb66744: mov             fp, SP
    // 0xb66748: AllocStack(0x98)
    //     0xb66748: sub             SP, SP, #0x98
    // 0xb6674c: SetupParameters(RenderWrap this /* r1 => r1, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x10 */)
    //     0xb6674c: mov             x0, x3
    //     0xb66750: stur            x1, [fp, #-8]
    //     0xb66754: stur            x3, [fp, #-0x10]
    // 0xb66758: CheckStackOverflow
    //     0xb66758: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6675c: cmp             SP, x16
    //     0xb66760: b.ls            #0xb66b80
    // 0xb66764: LoadField: r3 = r1->field_5f
    //     0xb66764: ldur            w3, [x1, #0x5f]
    // 0xb66768: DecompressPointer r3
    //     0xb66768: add             x3, x3, HEAP, lsl #32
    // 0xb6676c: LoadField: r4 = r3->field_7
    //     0xb6676c: ldur            x4, [x3, #7]
    // 0xb66770: cmp             x4, #0
    // 0xb66774: b.gt            #0xb667d8
    // 0xb66778: LoadField: d0 = r2->field_f
    //     0xb66778: ldur            d0, [x2, #0xf]
    // 0xb6677c: stur            d0, [fp, #-0x68]
    // 0xb66780: r0 = BoxConstraints()
    //     0xb66780: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb66784: StoreField: r0->field_7 = rZR
    //     0xb66784: stur            xzr, [x0, #7]
    // 0xb66788: ldur            d0, [fp, #-0x68]
    // 0xb6678c: StoreField: r0->field_f = d0
    //     0xb6678c: stur            d0, [x0, #0xf]
    // 0xb66790: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb66790: stur            xzr, [x0, #0x17]
    // 0xb66794: d1 = inf
    //     0xb66794: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb66798: StoreField: r0->field_1f = d1
    //     0xb66798: stur            d1, [x0, #0x1f]
    // 0xb6679c: r3 = inline_Allocate_Double()
    //     0xb6679c: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb667a0: add             x3, x3, #0x10
    //     0xb667a4: cmp             x1, x3
    //     0xb667a8: b.ls            #0xb66b88
    //     0xb667ac: str             x3, [THR, #0x60]  ; THR::top
    //     0xb667b0: sub             x3, x3, #0xf
    //     0xb667b4: mov             x1, #0xe19c
    //     0xb667b8: movk            x1, #3, lsl #16
    //     0xb667bc: stur            x1, [x3, #-1]
    // 0xb667c0: dmb             ishst
    // 0xb667c4: StoreField: r3->field_7 = d0
    //     0xb667c4: stur            d0, [x3, #7]
    // 0xb667c8: mov             x2, x0
    // 0xb667cc: r0 = AllocateRecord2()
    //     0xb667cc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb667d0: mov             x1, x0
    // 0xb667d4: b               #0xb66838
    // 0xb667d8: d1 = inf
    //     0xb667d8: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb667dc: LoadField: d0 = r2->field_1f
    //     0xb667dc: ldur            d0, [x2, #0x1f]
    // 0xb667e0: stur            d0, [fp, #-0x68]
    // 0xb667e4: r0 = BoxConstraints()
    //     0xb667e4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb667e8: StoreField: r0->field_7 = rZR
    //     0xb667e8: stur            xzr, [x0, #7]
    // 0xb667ec: d0 = inf
    //     0xb667ec: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb667f0: StoreField: r0->field_f = d0
    //     0xb667f0: stur            d0, [x0, #0xf]
    // 0xb667f4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb667f4: stur            xzr, [x0, #0x17]
    // 0xb667f8: ldur            d0, [fp, #-0x68]
    // 0xb667fc: StoreField: r0->field_1f = d0
    //     0xb667fc: stur            d0, [x0, #0x1f]
    // 0xb66800: r3 = inline_Allocate_Double()
    //     0xb66800: ldp             x3, x1, [THR, #0x60]  ; THR::top
    //     0xb66804: add             x3, x3, #0x10
    //     0xb66808: cmp             x1, x3
    //     0xb6680c: b.ls            #0xb66ba4
    //     0xb66810: str             x3, [THR, #0x60]  ; THR::top
    //     0xb66814: sub             x3, x3, #0xf
    //     0xb66818: mov             x1, #0xe19c
    //     0xb6681c: movk            x1, #3, lsl #16
    //     0xb66820: stur            x1, [x3, #-1]
    // 0xb66824: dmb             ishst
    // 0xb66828: StoreField: r3->field_7 = d0
    //     0xb66828: stur            d0, [x3, #7]
    // 0xb6682c: mov             x2, x0
    // 0xb66830: r0 = AllocateRecord2()
    //     0xb66830: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb66834: mov             x1, x0
    // 0xb66838: ldur            x0, [fp, #-8]
    // 0xb6683c: LoadField: r2 = r1->field_f
    //     0xb6683c: ldur            w2, [x1, #0xf]
    // 0xb66840: DecompressPointer r2
    //     0xb66840: add             x2, x2, HEAP, lsl #32
    // 0xb66844: stur            x2, [fp, #-0x20]
    // 0xb66848: LoadField: r3 = r1->field_13
    //     0xb66848: ldur            w3, [x1, #0x13]
    // 0xb6684c: DecompressPointer r3
    //     0xb6684c: add             x3, x3, HEAP, lsl #32
    // 0xb66850: mov             x1, x0
    // 0xb66854: stur            x3, [fp, #-0x18]
    // 0xb66858: r0 = _areAxesFlipped()
    //     0xb66858: bl              #0xb6660c  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::_areAxesFlipped
    // 0xb6685c: mov             x5, x0
    // 0xb66860: ldur            x0, [fp, #-8]
    // 0xb66864: stur            x5, [fp, #-0x28]
    // 0xb66868: LoadField: d0 = r0->field_67
    //     0xb66868: ldur            d0, [x0, #0x67]
    // 0xb6686c: stur            d0, [fp, #-0x68]
    // 0xb66870: r1 = <_RunMetrics>
    //     0xb66870: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8e5b8] TypeArguments: <_RunMetrics>
    //     0xb66874: ldr             x1, [x1, #0x5b8]
    // 0xb66878: r2 = 0
    //     0xb66878: mov             x2, #0
    // 0xb6687c: r0 = _GrowableList()
    //     0xb6687c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xb66880: mov             x2, x0
    // 0xb66884: ldur            x1, [fp, #-8]
    // 0xb66888: stur            x2, [fp, #-0x40]
    // 0xb6688c: LoadField: r0 = r1->field_57
    //     0xb6688c: ldur            w0, [x1, #0x57]
    // 0xb66890: DecompressPointer r0
    //     0xb66890: add             x0, x0, HEAP, lsl #32
    // 0xb66894: ldur            x3, [fp, #-0x18]
    // 0xb66898: LoadField: d1 = r3->field_7
    //     0xb66898: ldur            d1, [x3, #7]
    // 0xb6689c: stur            d1, [fp, #-0x70]
    // 0xb668a0: mov             x3, x0
    // 0xb668a4: r5 = Null
    //     0xb668a4: mov             x5, NULL
    // 0xb668a8: r4 = Instance_Size
    //     0xb668a8: ldr             x4, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb668ac: stur            x5, [fp, #-0x18]
    // 0xb668b0: stur            x4, [fp, #-0x30]
    // 0xb668b4: stur            x3, [fp, #-0x38]
    // 0xb668b8: CheckStackOverflow
    //     0xb668b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb668bc: cmp             SP, x16
    //     0xb668c0: b.ls            #0xb66bc0
    // 0xb668c4: cmp             w3, NULL
    // 0xb668c8: b.eq            #0xb66b00
    // 0xb668cc: ldur            x16, [fp, #-0x10]
    // 0xb668d0: stp             x3, x16, [SP, #8]
    // 0xb668d4: ldur            x16, [fp, #-0x20]
    // 0xb668d8: str             x16, [SP]
    // 0xb668dc: ldur            x0, [fp, #-0x10]
    // 0xb668e0: ClosureCall
    //     0xb668e0: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb668e4: ldur            x2, [x0, #0x1f]
    //     0xb668e8: blr             x2
    // 0xb668ec: mov             x1, x0
    // 0xb668f0: ldur            x0, [fp, #-8]
    // 0xb668f4: LoadField: r2 = r0->field_5f
    //     0xb668f4: ldur            w2, [x0, #0x5f]
    // 0xb668f8: DecompressPointer r2
    //     0xb668f8: add             x2, x2, HEAP, lsl #32
    // 0xb668fc: r0 = _AxisSize._convert()
    //     0xb668fc: bl              #0xb661a0  ; [package:flutter/src/rendering/wrap.dart] ::_AxisSize._convert
    // 0xb66900: ldur            x1, [fp, #-0x18]
    // 0xb66904: stur            x0, [fp, #-0x48]
    // 0xb66908: cmp             w1, NULL
    // 0xb6690c: b.ne            #0xb6693c
    // 0xb66910: ldur            x2, [fp, #-0x38]
    // 0xb66914: r0 = _RunMetrics()
    //     0xb66914: bl              #0xb66d38  ; Allocate_RunMetricsStub -> _RunMetrics (size=0x18)
    // 0xb66918: mov             x1, x0
    // 0xb6691c: r0 = 1
    //     0xb6691c: mov             x0, #1
    // 0xb66920: StoreField: r1->field_b = r0
    //     0xb66920: stur            x0, [x1, #0xb]
    // 0xb66924: ldur            x4, [fp, #-0x38]
    // 0xb66928: StoreField: r1->field_13 = r4
    //     0xb66928: stur            w4, [x1, #0x13]
    // 0xb6692c: ldur            x3, [fp, #-0x48]
    // 0xb66930: StoreField: r1->field_7 = r3
    //     0xb66930: stur            w3, [x1, #7]
    // 0xb66934: mov             x0, x1
    // 0xb66938: b               #0xb66960
    // 0xb6693c: ldur            x4, [fp, #-0x38]
    // 0xb66940: mov             x3, x0
    // 0xb66944: r0 = 1
    //     0xb66944: mov             x0, #1
    // 0xb66948: ldur            x1, [fp, #-0x18]
    // 0xb6694c: mov             x2, x4
    // 0xb66950: ldur            x5, [fp, #-0x28]
    // 0xb66954: ldur            d0, [fp, #-0x68]
    // 0xb66958: ldur            d1, [fp, #-0x70]
    // 0xb6695c: r0 = tryAddingNewChild()
    //     0xb6695c: bl              #0xb66bfc  ; [package:flutter/src/rendering/wrap.dart] _RunMetrics::tryAddingNewChild
    // 0xb66960: stur            x0, [fp, #-0x48]
    // 0xb66964: cmp             w0, NULL
    // 0xb66968: b.eq            #0xb66a7c
    // 0xb6696c: ldur            x2, [fp, #-0x40]
    // 0xb66970: LoadField: r1 = r2->field_b
    //     0xb66970: ldur            w1, [x2, #0xb]
    // 0xb66974: LoadField: r3 = r2->field_f
    //     0xb66974: ldur            w3, [x2, #0xf]
    // 0xb66978: DecompressPointer r3
    //     0xb66978: add             x3, x3, HEAP, lsl #32
    // 0xb6697c: LoadField: r4 = r3->field_b
    //     0xb6697c: ldur            w4, [x3, #0xb]
    // 0xb66980: r3 = LoadInt32Instr(r1)
    //     0xb66980: sbfx            x3, x1, #1, #0x1f
    // 0xb66984: stur            x3, [fp, #-0x50]
    // 0xb66988: r1 = LoadInt32Instr(r4)
    //     0xb66988: sbfx            x1, x4, #1, #0x1f
    // 0xb6698c: cmp             x3, x1
    // 0xb66990: b.ne            #0xb6699c
    // 0xb66994: mov             x1, x2
    // 0xb66998: r0 = _growToNextCapacity()
    //     0xb66998: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb6699c: ldur            x2, [fp, #-0x40]
    // 0xb669a0: ldur            x5, [fp, #-0x18]
    // 0xb669a4: ldur            x3, [fp, #-0x50]
    // 0xb669a8: add             x0, x3, #1
    // 0xb669ac: lsl             x1, x0, #1
    // 0xb669b0: StoreField: r2->field_b = r1
    //     0xb669b0: stur            w1, [x2, #0xb]
    // 0xb669b4: LoadField: r1 = r2->field_f
    //     0xb669b4: ldur            w1, [x2, #0xf]
    // 0xb669b8: DecompressPointer r1
    //     0xb669b8: add             x1, x1, HEAP, lsl #32
    // 0xb669bc: ldur            x0, [fp, #-0x48]
    // 0xb669c0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb669c0: add             x25, x1, x3, lsl #2
    //     0xb669c4: add             x25, x25, #0xf
    //     0xb669c8: str             w0, [x25]
    //     0xb669cc: tbz             w0, #0, #0xb669e8
    //     0xb669d0: ldurb           w16, [x1, #-1]
    //     0xb669d4: ldurb           w17, [x0, #-1]
    //     0xb669d8: and             x16, x17, x16, lsr #2
    //     0xb669dc: tst             x16, HEAP, lsr #32
    //     0xb669e0: b.eq            #0xb669e8
    //     0xb669e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb669e8: cmp             w5, NULL
    // 0xb669ec: b.ne            #0xb669f8
    // 0xb669f0: r0 = Null
    //     0xb669f0: mov             x0, NULL
    // 0xb669f4: b               #0xb66a24
    // 0xb669f8: LoadField: r0 = r5->field_7
    //     0xb669f8: ldur            w0, [x5, #7]
    // 0xb669fc: DecompressPointer r0
    //     0xb669fc: add             x0, x0, HEAP, lsl #32
    // 0xb66a00: LoadField: d0 = r0->field_f
    //     0xb66a00: ldur            d0, [x0, #0xf]
    // 0xb66a04: stur            d0, [fp, #-0x80]
    // 0xb66a08: LoadField: d1 = r0->field_7
    //     0xb66a08: ldur            d1, [x0, #7]
    // 0xb66a0c: stur            d1, [fp, #-0x78]
    // 0xb66a10: r0 = Size()
    //     0xb66a10: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb66a14: ldur            d0, [fp, #-0x80]
    // 0xb66a18: StoreField: r0->field_7 = d0
    //     0xb66a18: stur            d0, [x0, #7]
    // 0xb66a1c: ldur            d0, [fp, #-0x78]
    // 0xb66a20: StoreField: r0->field_f = d0
    //     0xb66a20: stur            d0, [x0, #0xf]
    // 0xb66a24: cmp             w0, NULL
    // 0xb66a28: b.ne            #0xb66a34
    // 0xb66a2c: r1 = Instance_Size
    //     0xb66a2c: ldr             x1, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb66a30: b               #0xb66a38
    // 0xb66a34: mov             x1, x0
    // 0xb66a38: ldur            x0, [fp, #-0x30]
    // 0xb66a3c: LoadField: d0 = r0->field_7
    //     0xb66a3c: ldur            d0, [x0, #7]
    // 0xb66a40: LoadField: d1 = r1->field_7
    //     0xb66a40: ldur            d1, [x1, #7]
    // 0xb66a44: fadd            d2, d0, d1
    // 0xb66a48: stur            d2, [fp, #-0x80]
    // 0xb66a4c: LoadField: d0 = r0->field_f
    //     0xb66a4c: ldur            d0, [x0, #0xf]
    // 0xb66a50: LoadField: d1 = r1->field_f
    //     0xb66a50: ldur            d1, [x1, #0xf]
    // 0xb66a54: fmax            v3.2d, v0.2d, v1.2d
    // 0xb66a58: stur            d3, [fp, #-0x78]
    // 0xb66a5c: r0 = Size()
    //     0xb66a5c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb66a60: ldur            d0, [fp, #-0x80]
    // 0xb66a64: StoreField: r0->field_7 = d0
    //     0xb66a64: stur            d0, [x0, #7]
    // 0xb66a68: ldur            d0, [fp, #-0x78]
    // 0xb66a6c: StoreField: r0->field_f = d0
    //     0xb66a6c: stur            d0, [x0, #0xf]
    // 0xb66a70: ldur            x5, [fp, #-0x48]
    // 0xb66a74: mov             x4, x0
    // 0xb66a78: b               #0xb66a88
    // 0xb66a7c: ldur            x5, [fp, #-0x18]
    // 0xb66a80: ldur            x0, [fp, #-0x30]
    // 0xb66a84: mov             x4, x0
    // 0xb66a88: ldur            x0, [fp, #-0x38]
    // 0xb66a8c: stur            x5, [fp, #-0x58]
    // 0xb66a90: stur            x4, [fp, #-0x60]
    // 0xb66a94: LoadField: r3 = r0->field_7
    //     0xb66a94: ldur            w3, [x0, #7]
    // 0xb66a98: DecompressPointer r3
    //     0xb66a98: add             x3, x3, HEAP, lsl #32
    // 0xb66a9c: stur            x3, [fp, #-0x48]
    // 0xb66aa0: cmp             w3, NULL
    // 0xb66aa4: b.eq            #0xb66bc8
    // 0xb66aa8: mov             x0, x3
    // 0xb66aac: r2 = Null
    //     0xb66aac: mov             x2, NULL
    // 0xb66ab0: r1 = Null
    //     0xb66ab0: mov             x1, NULL
    // 0xb66ab4: r4 = LoadClassIdInstr(r0)
    //     0xb66ab4: ldur            x4, [x0, #-1]
    //     0xb66ab8: ubfx            x4, x4, #0xc, #0x14
    // 0xb66abc: r17 = 4207
    //     0xb66abc: mov             x17, #0x106f
    // 0xb66ac0: cmp             x4, x17
    // 0xb66ac4: b.eq            #0xb66adc
    // 0xb66ac8: r8 = WrapParentData
    //     0xb66ac8: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e4c0] Type: WrapParentData
    //     0xb66acc: ldr             x8, [x8, #0x4c0]
    // 0xb66ad0: r3 = Null
    //     0xb66ad0: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e5c0] Null
    //     0xb66ad4: ldr             x3, [x3, #0x5c0]
    // 0xb66ad8: r0 = DefaultTypeTest()
    //     0xb66ad8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb66adc: ldur            x0, [fp, #-0x48]
    // 0xb66ae0: LoadField: r3 = r0->field_13
    //     0xb66ae0: ldur            w3, [x0, #0x13]
    // 0xb66ae4: DecompressPointer r3
    //     0xb66ae4: add             x3, x3, HEAP, lsl #32
    // 0xb66ae8: ldur            x5, [fp, #-0x58]
    // 0xb66aec: ldur            x4, [fp, #-0x60]
    // 0xb66af0: ldur            x1, [fp, #-8]
    // 0xb66af4: ldur            x2, [fp, #-0x40]
    // 0xb66af8: ldur            d1, [fp, #-0x70]
    // 0xb66afc: b               #0xb668ac
    // 0xb66b00: mov             x16, x2
    // 0xb66b04: mov             x2, x1
    // 0xb66b08: mov             x1, x16
    // 0xb66b0c: mov             x0, x4
    // 0xb66b10: LoadField: d0 = r2->field_73
    //     0xb66b10: ldur            d0, [x2, #0x73]
    // 0xb66b14: LoadField: r2 = r1->field_b
    //     0xb66b14: ldur            w2, [x1, #0xb]
    // 0xb66b18: r3 = LoadInt32Instr(r2)
    //     0xb66b18: sbfx            x3, x2, #1, #0x1f
    // 0xb66b1c: sub             x2, x3, #1
    // 0xb66b20: scvtf           d1, x2
    // 0xb66b24: fmul            d2, d0, d1
    // 0xb66b28: mov             v0.16b, v2.16b
    // 0xb66b2c: r0 = _AxisSize.()
    //     0xb66b2c: bl              #0xb66bd0  ; [package:flutter/src/rendering/wrap.dart] ::_AxisSize.
    // 0xb66b30: mov             x2, x0
    // 0xb66b34: ldur            x0, [fp, #-0x18]
    // 0xb66b38: stur            x2, [fp, #-8]
    // 0xb66b3c: cmp             w0, NULL
    // 0xb66b40: b.eq            #0xb66bcc
    // 0xb66b44: LoadField: r1 = r0->field_7
    //     0xb66b44: ldur            w1, [x0, #7]
    // 0xb66b48: DecompressPointer r1
    //     0xb66b48: add             x1, x1, HEAP, lsl #32
    // 0xb66b4c: r0 = flipped()
    //     0xb66b4c: bl              #0xb1922c  ; [dart:ui] Size::flipped
    // 0xb66b50: ldur            x1, [fp, #-8]
    // 0xb66b54: mov             x2, x0
    // 0xb66b58: r0 = _AxisSize.+()
    //     0xb66b58: bl              #0xb18b88  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.+
    // 0xb66b5c: ldur            x1, [fp, #-0x30]
    // 0xb66b60: mov             x2, x0
    // 0xb66b64: r0 = _AxisSize.+()
    //     0xb66b64: bl              #0xb18b88  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.+
    // 0xb66b68: mov             x1, x0
    // 0xb66b6c: r0 = flipped()
    //     0xb66b6c: bl              #0xb1922c  ; [dart:ui] Size::flipped
    // 0xb66b70: ldur            x1, [fp, #-0x40]
    // 0xb66b74: LeaveFrame
    //     0xb66b74: mov             SP, fp
    //     0xb66b78: ldp             fp, lr, [SP], #0x10
    // 0xb66b7c: ret
    //     0xb66b7c: ret             
    // 0xb66b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb66b80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb66b84: b               #0xb66764
    // 0xb66b88: SaveReg d0
    //     0xb66b88: str             q0, [SP, #-0x10]!
    // 0xb66b8c: SaveReg r0
    //     0xb66b8c: str             x0, [SP, #-8]!
    // 0xb66b90: r0 = AllocateDouble()
    //     0xb66b90: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb66b94: mov             x3, x0
    // 0xb66b98: RestoreReg r0
    //     0xb66b98: ldr             x0, [SP], #8
    // 0xb66b9c: RestoreReg d0
    //     0xb66b9c: ldr             q0, [SP], #0x10
    // 0xb66ba0: b               #0xb667c4
    // 0xb66ba4: SaveReg d0
    //     0xb66ba4: str             q0, [SP, #-0x10]!
    // 0xb66ba8: SaveReg r0
    //     0xb66ba8: str             x0, [SP, #-8]!
    // 0xb66bac: r0 = AllocateDouble()
    //     0xb66bac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb66bb0: mov             x3, x0
    // 0xb66bb4: RestoreReg r0
    //     0xb66bb4: ldr             x0, [SP], #8
    // 0xb66bb8: RestoreReg d0
    //     0xb66bb8: ldr             q0, [SP], #0x10
    // 0xb66bbc: b               #0xb66828
    // 0xb66bc0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb66bc0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb66bc4: b               #0xb668c4
    // 0xb66bc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb66bc8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb66bcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb66bcc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Size getChildSize(dynamic, RenderBox) {
    // ** addr: 0xb66d44, size: 0x44
    // 0xb66d44: EnterFrame
    //     0xb66d44: stp             fp, lr, [SP, #-0x10]!
    //     0xb66d48: mov             fp, SP
    // 0xb66d4c: ldr             x0, [fp, #0x18]
    // 0xb66d50: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb66d50: ldur            w1, [x0, #0x17]
    // 0xb66d54: DecompressPointer r1
    //     0xb66d54: add             x1, x1, HEAP, lsl #32
    // 0xb66d58: CheckStackOverflow
    //     0xb66d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb66d5c: cmp             SP, x16
    //     0xb66d60: b.ls            #0xb66d80
    // 0xb66d64: LoadField: r2 = r1->field_13
    //     0xb66d64: ldur            w2, [x1, #0x13]
    // 0xb66d68: DecompressPointer r2
    //     0xb66d68: add             x2, x2, HEAP, lsl #32
    // 0xb66d6c: ldr             x1, [fp, #0x10]
    // 0xb66d70: r0 = getDryLayout()
    //     0xb66d70: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb66d74: LeaveFrame
    //     0xb66d74: mov             SP, fp
    //     0xb66d78: ldp             fp, lr, [SP], #0x10
    // 0xb66d7c: ret
    //     0xb66d7c: ret             
    // 0xb66d80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb66d80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb66d84: b               #0xb66d64
  }
  [closure] void findHighestBaseline(dynamic, Offset, RenderBox) {
    // ** addr: 0xb66d88, size: 0xa0
    // 0xb66d88: EnterFrame
    //     0xb66d88: stp             fp, lr, [SP, #-0x10]!
    //     0xb66d8c: mov             fp, SP
    // 0xb66d90: AllocStack(0x10)
    //     0xb66d90: sub             SP, SP, #0x10
    // 0xb66d94: SetupParameters([dynamic _ /* r0 */])
    //     0xb66d94: ldr             x0, [fp, #0x20]
    //     0xb66d98: ldur            w4, [x0, #0x17]
    //     0xb66d9c: add             x4, x4, HEAP, lsl #32
    //     0xb66da0: stur            x4, [fp, #-0x10]
    // 0xb66da4: CheckStackOverflow
    //     0xb66da4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb66da8: cmp             SP, x16
    //     0xb66dac: b.ls            #0xb66e20
    // 0xb66db0: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xb66db0: ldur            w0, [x4, #0x17]
    // 0xb66db4: DecompressPointer r0
    //     0xb66db4: add             x0, x0, HEAP, lsl #32
    // 0xb66db8: stur            x0, [fp, #-8]
    // 0xb66dbc: LoadField: r2 = r4->field_13
    //     0xb66dbc: ldur            w2, [x4, #0x13]
    // 0xb66dc0: DecompressPointer r2
    //     0xb66dc0: add             x2, x2, HEAP, lsl #32
    // 0xb66dc4: LoadField: r3 = r4->field_f
    //     0xb66dc4: ldur            w3, [x4, #0xf]
    // 0xb66dc8: DecompressPointer r3
    //     0xb66dc8: add             x3, x3, HEAP, lsl #32
    // 0xb66dcc: ldr             x1, [fp, #0x10]
    // 0xb66dd0: r0 = getDryBaseline()
    //     0xb66dd0: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb66dd4: mov             x1, x0
    // 0xb66dd8: ldr             x0, [fp, #0x18]
    // 0xb66ddc: LoadField: d0 = r0->field_f
    //     0xb66ddc: ldur            d0, [x0, #0xf]
    // 0xb66de0: r0 = BaselineOffset.+()
    //     0xb66de0: bl              #0xb5b044  ; [package:flutter/src/rendering/box.dart] ::BaselineOffset.+
    // 0xb66de4: ldur            x1, [fp, #-8]
    // 0xb66de8: mov             x2, x0
    // 0xb66dec: r0 = BaselineOffset.minOf()
    //     0xb66dec: bl              #0xb66e28  ; [package:flutter/src/rendering/box.dart] ::BaselineOffset.minOf
    // 0xb66df0: ldur            x1, [fp, #-0x10]
    // 0xb66df4: ArrayStore: r1[0] = r0  ; List_4
    //     0xb66df4: stur            w0, [x1, #0x17]
    //     0xb66df8: ldurb           w16, [x1, #-1]
    //     0xb66dfc: ldurb           w17, [x0, #-1]
    //     0xb66e00: and             x16, x17, x16, lsr #2
    //     0xb66e04: tst             x16, HEAP, lsr #32
    //     0xb66e08: b.eq            #0xb66e10
    //     0xb66e0c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb66e10: r0 = Null
    //     0xb66e10: mov             x0, NULL
    // 0xb66e14: LeaveFrame
    //     0xb66e14: mov             SP, fp
    //     0xb66e18: ldp             fp, lr, [SP], #0x10
    // 0xb66e1c: ret
    //     0xb66e1c: ret             
    // 0xb66e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb66e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb66e24: b               #0xb66db0
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbcc554, size: 0x26c
    // 0xbcc554: EnterFrame
    //     0xbcc554: stp             fp, lr, [SP, #-0x10]!
    //     0xbcc558: mov             fp, SP
    // 0xbcc55c: AllocStack(0x20)
    //     0xbcc55c: sub             SP, SP, #0x20
    // 0xbcc560: SetupParameters(RenderWrap this /* r1 => r3, fp-0x10 */)
    //     0xbcc560: mov             x3, x1
    //     0xbcc564: stur            x1, [fp, #-0x10]
    // 0xbcc568: CheckStackOverflow
    //     0xbcc568: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcc56c: cmp             SP, x16
    //     0xbcc570: b.ls            #0xbcc7b8
    // 0xbcc574: LoadField: r4 = r3->field_27
    //     0xbcc574: ldur            w4, [x3, #0x27]
    // 0xbcc578: DecompressPointer r4
    //     0xbcc578: add             x4, x4, HEAP, lsl #32
    // 0xbcc57c: stur            x4, [fp, #-8]
    // 0xbcc580: cmp             w4, NULL
    // 0xbcc584: b.eq            #0xbcc77c
    // 0xbcc588: mov             x0, x4
    // 0xbcc58c: r2 = Null
    //     0xbcc58c: mov             x2, NULL
    // 0xbcc590: r1 = Null
    //     0xbcc590: mov             x1, NULL
    // 0xbcc594: r4 = LoadClassIdInstr(r0)
    //     0xbcc594: ldur            x4, [x0, #-1]
    //     0xbcc598: ubfx            x4, x4, #0xc, #0x14
    // 0xbcc59c: sub             x4, x4, #0xb46
    // 0xbcc5a0: cmp             x4, #1
    // 0xbcc5a4: b.ls            #0xbcc5b8
    // 0xbcc5a8: r8 = BoxConstraints
    //     0xbcc5a8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbcc5ac: r3 = Null
    //     0xbcc5ac: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4e8] Null
    //     0xbcc5b0: ldr             x3, [x3, #0x4e8]
    // 0xbcc5b4: r0 = BoxConstraints()
    //     0xbcc5b4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbcc5b8: ldur            x0, [fp, #-0x10]
    // 0xbcc5bc: LoadField: r1 = r0->field_57
    //     0xbcc5bc: ldur            w1, [x0, #0x57]
    // 0xbcc5c0: DecompressPointer r1
    //     0xbcc5c0: add             x1, x1, HEAP, lsl #32
    // 0xbcc5c4: cmp             w1, NULL
    // 0xbcc5c8: b.ne            #0xbcc60c
    // 0xbcc5cc: ldur            x1, [fp, #-8]
    // 0xbcc5d0: r0 = smallest()
    //     0xbcc5d0: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbcc5d4: ldur            x4, [fp, #-0x10]
    // 0xbcc5d8: StoreField: r4->field_4b = r0
    //     0xbcc5d8: stur            w0, [x4, #0x4b]
    //     0xbcc5dc: ldurb           w16, [x4, #-1]
    //     0xbcc5e0: ldurb           w17, [x0, #-1]
    //     0xbcc5e4: and             x16, x17, x16, lsr #2
    //     0xbcc5e8: tst             x16, HEAP, lsr #32
    //     0xbcc5ec: b.eq            #0xbcc5f4
    //     0xbcc5f0: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbcc5f4: r0 = false
    //     0xbcc5f4: add             x0, NULL, #0x30  ; false
    // 0xbcc5f8: StoreField: r4->field_8b = r0
    //     0xbcc5f8: stur            w0, [x4, #0x8b]
    // 0xbcc5fc: r0 = Null
    //     0xbcc5fc: mov             x0, NULL
    // 0xbcc600: LeaveFrame
    //     0xbcc600: mov             SP, fp
    //     0xbcc604: ldp             fp, lr, [SP], #0x10
    // 0xbcc608: ret
    //     0xbcc608: ret             
    // 0xbcc60c: mov             x4, x0
    // 0xbcc610: mov             x1, x4
    // 0xbcc614: ldur            x2, [fp, #-8]
    // 0xbcc618: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbcc618: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbcc61c: ldr             x3, [x3, #0x4f8]
    // 0xbcc620: r0 = _computeRuns()
    //     0xbcc620: bl              #0xb66740  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::_computeRuns
    // 0xbcc624: mov             x3, x0
    // 0xbcc628: stur            x3, [fp, #-0x20]
    // 0xbcc62c: mov             x4, x1
    // 0xbcc630: stur            x4, [fp, #-0x18]
    // 0xbcc634: r0 = LoadClassIdInstr(r3)
    //     0xbcc634: ldur            x0, [x3, #-1]
    //     0xbcc638: ubfx            x0, x0, #0xc, #0x14
    // 0xbcc63c: sub             x16, x0, #0xeda
    // 0xbcc640: cmp             x16, #1
    // 0xbcc644: b.hi            #0xbcc798
    // 0xbcc648: mov             x0, x4
    // 0xbcc64c: r2 = Null
    //     0xbcc64c: mov             x2, NULL
    // 0xbcc650: r1 = Null
    //     0xbcc650: mov             x1, NULL
    // 0xbcc654: cmp             w0, NULL
    // 0xbcc658: b.eq            #0xbcc6a4
    // 0xbcc65c: branchIfSmi(r0, 0xbcc6a4)
    //     0xbcc65c: tbz             w0, #0, #0xbcc6a4
    // 0xbcc660: r3 = SubtypeTestCache
    //     0xbcc660: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e500] SubtypeTestCache
    //     0xbcc664: ldr             x3, [x3, #0x500]
    // 0xbcc668: r30 = Subtype2TestCacheStub
    //     0xbcc668: ldr             lr, [PP, #0x30]  ; [pp+0x30] Stub: Subtype2TestCache (0x7d2e44)
    // 0xbcc66c: LoadField: r30 = r30->field_7
    //     0xbcc66c: ldur            lr, [lr, #7]
    // 0xbcc670: blr             lr
    // 0xbcc674: cmp             w7, NULL
    // 0xbcc678: b.eq            #0xbcc684
    // 0xbcc67c: tbnz            w7, #4, #0xbcc6a4
    // 0xbcc680: b               #0xbcc6ac
    // 0xbcc684: r8 = List<_RunMetrics>
    //     0xbcc684: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e508] Type: List<_RunMetrics>
    //     0xbcc688: ldr             x8, [x8, #0x508]
    // 0xbcc68c: r3 = SubtypeTestCache
    //     0xbcc68c: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e510] SubtypeTestCache
    //     0xbcc690: ldr             x3, [x3, #0x510]
    // 0xbcc694: r30 = InstanceOfStub
    //     0xbcc694: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xbcc698: LoadField: r30 = r30->field_7
    //     0xbcc698: ldur            lr, [lr, #7]
    // 0xbcc69c: blr             lr
    // 0xbcc6a0: b               #0xbcc6b0
    // 0xbcc6a4: r0 = false
    //     0xbcc6a4: add             x0, NULL, #0x30  ; false
    // 0xbcc6a8: b               #0xbcc6b0
    // 0xbcc6ac: r0 = true
    //     0xbcc6ac: add             x0, NULL, #0x20  ; true
    // 0xbcc6b0: tbnz            w0, #4, #0xbcc798
    // 0xbcc6b4: ldur            x0, [fp, #-0x10]
    // 0xbcc6b8: LoadField: r3 = r0->field_5f
    //     0xbcc6b8: ldur            w3, [x0, #0x5f]
    // 0xbcc6bc: DecompressPointer r3
    //     0xbcc6bc: add             x3, x3, HEAP, lsl #32
    // 0xbcc6c0: ldur            x1, [fp, #-0x20]
    // 0xbcc6c4: ldur            x2, [fp, #-8]
    // 0xbcc6c8: r0 = _AxisSize.applyConstraints()
    //     0xbcc6c8: bl              #0xb18ad0  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.applyConstraints
    // 0xbcc6cc: mov             x3, x0
    // 0xbcc6d0: ldur            x0, [fp, #-0x10]
    // 0xbcc6d4: stur            x3, [fp, #-8]
    // 0xbcc6d8: LoadField: r2 = r0->field_5f
    //     0xbcc6d8: ldur            w2, [x0, #0x5f]
    // 0xbcc6dc: DecompressPointer r2
    //     0xbcc6dc: add             x2, x2, HEAP, lsl #32
    // 0xbcc6e0: mov             x1, x3
    // 0xbcc6e4: r0 = _AxisSize._convert()
    //     0xbcc6e4: bl              #0xb661a0  ; [package:flutter/src/rendering/wrap.dart] ::_AxisSize._convert
    // 0xbcc6e8: ldur            x3, [fp, #-0x10]
    // 0xbcc6ec: StoreField: r3->field_4b = r0
    //     0xbcc6ec: stur            w0, [x3, #0x4b]
    //     0xbcc6f0: ldurb           w16, [x3, #-1]
    //     0xbcc6f4: ldurb           w17, [x0, #-1]
    //     0xbcc6f8: and             x16, x17, x16, lsr #2
    //     0xbcc6fc: tst             x16, HEAP, lsr #32
    //     0xbcc700: b.eq            #0xbcc708
    //     0xbcc704: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbcc708: ldur            x1, [fp, #-8]
    // 0xbcc70c: ldur            x2, [fp, #-0x20]
    // 0xbcc710: r0 = _AxisSize.-()
    //     0xbcc710: bl              #0xbcc7c0  ; [package:flutter/src/rendering/wrap.dart] ::_AxisSize.-
    // 0xbcc714: LoadField: d0 = r0->field_7
    //     0xbcc714: ldur            d0, [x0, #7]
    // 0xbcc718: d1 = 0.000000
    //     0xbcc718: eor             v1.16b, v1.16b, v1.16b
    // 0xbcc71c: fcmp            d1, d0
    // 0xbcc720: b.le            #0xbcc72c
    // 0xbcc724: r2 = true
    //     0xbcc724: add             x2, NULL, #0x20  ; true
    // 0xbcc728: b               #0xbcc744
    // 0xbcc72c: LoadField: d0 = r0->field_f
    //     0xbcc72c: ldur            d0, [x0, #0xf]
    // 0xbcc730: fcmp            d1, d0
    // 0xbcc734: r16 = true
    //     0xbcc734: add             x16, NULL, #0x20  ; true
    // 0xbcc738: r17 = false
    //     0xbcc738: add             x17, NULL, #0x30  ; false
    // 0xbcc73c: csel            x1, x16, x17, gt
    // 0xbcc740: mov             x2, x1
    // 0xbcc744: ldur            x1, [fp, #-0x10]
    // 0xbcc748: StoreField: r1->field_8b = r2
    //     0xbcc748: stur            w2, [x1, #0x8b]
    // 0xbcc74c: ldur            x2, [fp, #-0x18]
    // 0xbcc750: mov             x3, x0
    // 0xbcc754: ldur            x5, [fp, #-8]
    // 0xbcc758: r6 = Closure: (Offset, RenderBox) => void from Function '_setChildPosition@306302920': static.
    //     0xbcc758: add             x6, PP, #0x8e, lsl #12  ; [pp+0x8e518] Closure: (Offset, RenderBox) => void from Function '_setChildPosition@306302920': static. (0x7f2adaab383c)
    //     0xbcc75c: ldr             x6, [x6, #0x518]
    // 0xbcc760: r7 = Closure: (RenderBox) => Size from Function '_getChildSize@306302920': static.
    //     0xbcc760: add             x7, PP, #0x8e, lsl #12  ; [pp+0x8e520] Closure: (RenderBox) => Size from Function '_getChildSize@306302920': static. (0x7f2adaab380c)
    //     0xbcc764: ldr             x7, [x7, #0x520]
    // 0xbcc768: r0 = _positionChildren()
    //     0xbcc768: bl              #0xb65d20  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::_positionChildren
    // 0xbcc76c: r0 = Null
    //     0xbcc76c: mov             x0, NULL
    // 0xbcc770: LeaveFrame
    //     0xbcc770: mov             SP, fp
    //     0xbcc774: ldp             fp, lr, [SP], #0x10
    // 0xbcc778: ret
    //     0xbcc778: ret             
    // 0xbcc77c: r0 = StateError()
    //     0xbcc77c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcc780: mov             x1, x0
    // 0xbcc784: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcc784: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbcc788: StoreField: r1->field_b = r0
    //     0xbcc788: stur            w0, [x1, #0xb]
    // 0xbcc78c: mov             x0, x1
    // 0xbcc790: r0 = Throw()
    //     0xbcc790: bl              #0x13ddb2c  ; ThrowStub
    // 0xbcc794: brk             #0
    // 0xbcc798: r0 = StateError()
    //     0xbcc798: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcc79c: mov             x1, x0
    // 0xbcc7a0: r0 = "Pattern matching error"
    //     0xbcc7a0: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e528] "Pattern matching error"
    //     0xbcc7a4: ldr             x0, [x0, #0x528]
    // 0xbcc7a8: StoreField: r1->field_b = r0
    //     0xbcc7a8: stur            w0, [x1, #0xb]
    // 0xbcc7ac: mov             x0, x1
    // 0xbcc7b0: r0 = Throw()
    //     0xbcc7b0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbcc7b4: brk             #0
    // 0xbcc7b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcc7b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcc7bc: b               #0xbcc574
  }
  [closure] static Size _getChildSize(dynamic, RenderBox) {
    // ** addr: 0xbcc80c, size: 0x30
    // 0xbcc80c: EnterFrame
    //     0xbcc80c: stp             fp, lr, [SP, #-0x10]!
    //     0xbcc810: mov             fp, SP
    // 0xbcc814: CheckStackOverflow
    //     0xbcc814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcc818: cmp             SP, x16
    //     0xbcc81c: b.ls            #0xbcc834
    // 0xbcc820: ldr             x1, [fp, #0x10]
    // 0xbcc824: r0 = size()
    //     0xbcc824: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbcc828: LeaveFrame
    //     0xbcc828: mov             SP, fp
    //     0xbcc82c: ldp             fp, lr, [SP], #0x10
    // 0xbcc830: ret
    //     0xbcc830: ret             
    // 0xbcc834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcc834: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcc838: b               #0xbcc820
  }
  [closure] static void _setChildPosition(dynamic, Offset, RenderBox) {
    // ** addr: 0xbcc83c, size: 0x34
    // 0xbcc83c: EnterFrame
    //     0xbcc83c: stp             fp, lr, [SP, #-0x10]!
    //     0xbcc840: mov             fp, SP
    // 0xbcc844: CheckStackOverflow
    //     0xbcc844: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcc848: cmp             SP, x16
    //     0xbcc84c: b.ls            #0xbcc868
    // 0xbcc850: ldr             x1, [fp, #0x18]
    // 0xbcc854: ldr             x2, [fp, #0x10]
    // 0xbcc858: r0 = _setChildPosition()
    //     0xbcc858: bl              #0xbcc870  ; [package:flutter/src/rendering/wrap.dart] RenderWrap::_setChildPosition
    // 0xbcc85c: LeaveFrame
    //     0xbcc85c: mov             SP, fp
    //     0xbcc860: ldp             fp, lr, [SP], #0x10
    // 0xbcc864: ret
    //     0xbcc864: ret             
    // 0xbcc868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcc868: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcc86c: b               #0xbcc850
  }
  static _ _setChildPosition(/* No info */) {
    // ** addr: 0xbcc870, size: 0x94
    // 0xbcc870: EnterFrame
    //     0xbcc870: stp             fp, lr, [SP, #-0x10]!
    //     0xbcc874: mov             fp, SP
    // 0xbcc878: AllocStack(0x10)
    //     0xbcc878: sub             SP, SP, #0x10
    // 0xbcc87c: SetupParameters(dynamic _ /* r1 => r3, fp-0x10 */)
    //     0xbcc87c: mov             x3, x1
    //     0xbcc880: stur            x1, [fp, #-0x10]
    // 0xbcc884: LoadField: r4 = r2->field_7
    //     0xbcc884: ldur            w4, [x2, #7]
    // 0xbcc888: DecompressPointer r4
    //     0xbcc888: add             x4, x4, HEAP, lsl #32
    // 0xbcc88c: stur            x4, [fp, #-8]
    // 0xbcc890: cmp             w4, NULL
    // 0xbcc894: b.eq            #0xbcc900
    // 0xbcc898: mov             x0, x4
    // 0xbcc89c: r2 = Null
    //     0xbcc89c: mov             x2, NULL
    // 0xbcc8a0: r1 = Null
    //     0xbcc8a0: mov             x1, NULL
    // 0xbcc8a4: r4 = LoadClassIdInstr(r0)
    //     0xbcc8a4: ldur            x4, [x0, #-1]
    //     0xbcc8a8: ubfx            x4, x4, #0xc, #0x14
    // 0xbcc8ac: r17 = 4207
    //     0xbcc8ac: mov             x17, #0x106f
    // 0xbcc8b0: cmp             x4, x17
    // 0xbcc8b4: b.eq            #0xbcc8cc
    // 0xbcc8b8: r8 = WrapParentData
    //     0xbcc8b8: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e4c0] Type: WrapParentData
    //     0xbcc8bc: ldr             x8, [x8, #0x4c0]
    // 0xbcc8c0: r3 = Null
    //     0xbcc8c0: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e530] Null
    //     0xbcc8c4: ldr             x3, [x3, #0x530]
    // 0xbcc8c8: r0 = DefaultTypeTest()
    //     0xbcc8c8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbcc8cc: ldur            x0, [fp, #-0x10]
    // 0xbcc8d0: ldur            x1, [fp, #-8]
    // 0xbcc8d4: StoreField: r1->field_7 = r0
    //     0xbcc8d4: stur            w0, [x1, #7]
    //     0xbcc8d8: ldurb           w16, [x1, #-1]
    //     0xbcc8dc: ldurb           w17, [x0, #-1]
    //     0xbcc8e0: and             x16, x17, x16, lsr #2
    //     0xbcc8e4: tst             x16, HEAP, lsr #32
    //     0xbcc8e8: b.eq            #0xbcc8f0
    //     0xbcc8ec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbcc8f0: r0 = Null
    //     0xbcc8f0: mov             x0, NULL
    // 0xbcc8f4: LeaveFrame
    //     0xbcc8f4: mov             SP, fp
    //     0xbcc8f8: ldp             fp, lr, [SP], #0x10
    // 0xbcc8fc: ret
    //     0xbcc8fc: ret             
    // 0xbcc900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcc900: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc0378c, size: 0x50
    // 0xc0378c: EnterFrame
    //     0xc0378c: stp             fp, lr, [SP, #-0x10]!
    //     0xc03790: mov             fp, SP
    // 0xc03794: AllocStack(0x8)
    //     0xc03794: sub             SP, SP, #8
    // 0xc03798: SetupParameters(RenderWrap this /* r1 => r0, fp-0x8 */)
    //     0xc03798: mov             x0, x1
    //     0xc0379c: stur            x1, [fp, #-8]
    // 0xc037a0: CheckStackOverflow
    //     0xc037a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc037a4: cmp             SP, x16
    //     0xc037a8: b.ls            #0xc037d4
    // 0xc037ac: LoadField: r1 = r0->field_8f
    //     0xc037ac: ldur            w1, [x0, #0x8f]
    // 0xc037b0: DecompressPointer r1
    //     0xc037b0: add             x1, x1, HEAP, lsl #32
    // 0xc037b4: r2 = Null
    //     0xc037b4: mov             x2, NULL
    // 0xc037b8: r0 = layer=()
    //     0xc037b8: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc037bc: ldur            x1, [fp, #-8]
    // 0xc037c0: r0 = dispose()
    //     0xc037c0: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc037c4: r0 = Null
    //     0xc037c4: mov             x0, NULL
    // 0xc037c8: LeaveFrame
    //     0xc037c8: mov             SP, fp
    //     0xc037cc: ldp             fp, lr, [SP], #0x10
    // 0xc037d0: ret
    //     0xc037d0: ret             
    // 0xc037d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc037d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc037d8: b               #0xc037ac
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0e294, size: 0xb8
    // 0xc0e294: EnterFrame
    //     0xc0e294: stp             fp, lr, [SP, #-0x10]!
    //     0xc0e298: mov             fp, SP
    // 0xc0e29c: AllocStack(0x8)
    //     0xc0e29c: sub             SP, SP, #8
    // 0xc0e2a0: SetupParameters(RenderWrap this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0e2a0: mov             x0, x2
    //     0xc0e2a4: mov             x4, x1
    //     0xc0e2a8: mov             x3, x2
    //     0xc0e2ac: stur            x2, [fp, #-8]
    // 0xc0e2b0: r2 = Null
    //     0xc0e2b0: mov             x2, NULL
    // 0xc0e2b4: r1 = Null
    //     0xc0e2b4: mov             x1, NULL
    // 0xc0e2b8: r4 = 60
    //     0xc0e2b8: mov             x4, #0x3c
    // 0xc0e2bc: branchIfSmi(r0, 0xc0e2c8)
    //     0xc0e2bc: tbz             w0, #0, #0xc0e2c8
    // 0xc0e2c0: r4 = LoadClassIdInstr(r0)
    //     0xc0e2c0: ldur            x4, [x0, #-1]
    //     0xc0e2c4: ubfx            x4, x4, #0xc, #0x14
    // 0xc0e2c8: r17 = -4710
    //     0xc0e2c8: mov             x17, #-0x1266
    // 0xc0e2cc: add             x4, x4, x17
    // 0xc0e2d0: cmp             x4, #0x109
    // 0xc0e2d4: b.ls            #0xc0e2e8
    // 0xc0e2d8: r8 = RenderBox
    //     0xc0e2d8: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0e2dc: r3 = Null
    //     0xc0e2dc: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e5e0] Null
    //     0xc0e2e0: ldr             x3, [x3, #0x5e0]
    // 0xc0e2e4: r0 = RenderBox()
    //     0xc0e2e4: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0e2e8: ldur            x0, [fp, #-8]
    // 0xc0e2ec: LoadField: r1 = r0->field_7
    //     0xc0e2ec: ldur            w1, [x0, #7]
    // 0xc0e2f0: DecompressPointer r1
    //     0xc0e2f0: add             x1, x1, HEAP, lsl #32
    // 0xc0e2f4: r2 = LoadClassIdInstr(r1)
    //     0xc0e2f4: ldur            x2, [x1, #-1]
    //     0xc0e2f8: ubfx            x2, x2, #0xc, #0x14
    // 0xc0e2fc: r17 = 4207
    //     0xc0e2fc: mov             x17, #0x106f
    // 0xc0e300: cmp             x2, x17
    // 0xc0e304: b.eq            #0xc0e33c
    // 0xc0e308: r1 = <RenderBox>
    //     0xc0e308: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0e30c: ldr             x1, [x1, #0x5c8]
    // 0xc0e310: r0 = WrapParentData()
    //     0xc0e310: bl              #0xc0e34c  ; AllocateWrapParentDataStub -> WrapParentData (size=0x18)
    // 0xc0e314: r1 = Instance_Offset
    //     0xc0e314: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0e318: StoreField: r0->field_7 = r1
    //     0xc0e318: stur            w1, [x0, #7]
    // 0xc0e31c: ldur            x1, [fp, #-8]
    // 0xc0e320: StoreField: r1->field_7 = r0
    //     0xc0e320: stur            w0, [x1, #7]
    //     0xc0e324: ldurb           w16, [x1, #-1]
    //     0xc0e328: ldurb           w17, [x0, #-1]
    //     0xc0e32c: and             x16, x17, x16, lsr #2
    //     0xc0e330: tst             x16, HEAP, lsr #32
    //     0xc0e334: b.eq            #0xc0e33c
    //     0xc0e338: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0e33c: r0 = Null
    //     0xc0e33c: mov             x0, NULL
    // 0xc0e340: LeaveFrame
    //     0xc0e340: mov             SP, fp
    //     0xc0e344: ldp             fp, lr, [SP], #0x10
    // 0xc0e348: ret
    //     0xc0e348: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc28f1c, size: 0x64
    // 0xc28f1c: EnterFrame
    //     0xc28f1c: stp             fp, lr, [SP, #-0x10]!
    //     0xc28f20: mov             fp, SP
    // 0xc28f24: AllocStack(0x18)
    //     0xc28f24: sub             SP, SP, #0x18
    // 0xc28f28: SetupParameters(RenderWrap this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc28f28: mov             x4, x1
    //     0xc28f2c: mov             x0, x2
    //     0xc28f30: stur            x1, [fp, #-8]
    //     0xc28f34: stur            x2, [fp, #-0x10]
    //     0xc28f38: stur            x3, [fp, #-0x18]
    // 0xc28f3c: CheckStackOverflow
    //     0xc28f3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc28f40: cmp             SP, x16
    //     0xc28f44: b.ls            #0xc28f78
    // 0xc28f48: LoadField: r1 = r4->field_8f
    //     0xc28f48: ldur            w1, [x4, #0x8f]
    // 0xc28f4c: DecompressPointer r1
    //     0xc28f4c: add             x1, x1, HEAP, lsl #32
    // 0xc28f50: r2 = Null
    //     0xc28f50: mov             x2, NULL
    // 0xc28f54: r0 = layer=()
    //     0xc28f54: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc28f58: ldur            x1, [fp, #-8]
    // 0xc28f5c: ldur            x2, [fp, #-0x10]
    // 0xc28f60: ldur            x3, [fp, #-0x18]
    // 0xc28f64: r0 = defaultPaint()
    //     0xc28f64: bl              #0xc28f80  ; [dart:mixin_deduplication] _MixinApplication453&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0xc28f68: r0 = Null
    //     0xc28f68: mov             x0, NULL
    // 0xc28f6c: LeaveFrame
    //     0xc28f6c: mov             SP, fp
    //     0xc28f70: ldp             fp, lr, [SP], #0x10
    // 0xc28f74: ret
    //     0xc28f74: ret             
    // 0xc28f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc28f78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc28f7c: b               #0xc28f48
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcef438, size: 0x60
    // 0xcef438: EnterFrame
    //     0xcef438: stp             fp, lr, [SP, #-0x10]!
    //     0xcef43c: mov             fp, SP
    // 0xcef440: mov             x0, x2
    // 0xcef444: CheckStackOverflow
    //     0xcef444: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef448: cmp             SP, x16
    //     0xcef44c: b.ls            #0xcef490
    // 0xcef450: LoadField: r2 = r1->field_7f
    //     0xcef450: ldur            w2, [x1, #0x7f]
    // 0xcef454: DecompressPointer r2
    //     0xcef454: add             x2, x2, HEAP, lsl #32
    // 0xcef458: cmp             w2, w0
    // 0xcef45c: b.eq            #0xcef480
    // 0xcef460: StoreField: r1->field_7f = r0
    //     0xcef460: stur            w0, [x1, #0x7f]
    //     0xcef464: ldurb           w16, [x1, #-1]
    //     0xcef468: ldurb           w17, [x0, #-1]
    //     0xcef46c: and             x16, x17, x16, lsr #2
    //     0xcef470: tst             x16, HEAP, lsr #32
    //     0xcef474: b.eq            #0xcef47c
    //     0xcef478: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcef47c: r0 = markNeedsLayout()
    //     0xcef47c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcef480: r0 = Null
    //     0xcef480: mov             x0, NULL
    // 0xcef484: LeaveFrame
    //     0xcef484: mov             SP, fp
    //     0xcef488: ldp             fp, lr, [SP], #0x10
    // 0xcef48c: ret
    //     0xcef48c: ret             
    // 0xcef490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef490: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef494: b               #0xcef450
  }
  set _ runAlignment=(/* No info */) {
    // ** addr: 0xcef508, size: 0x70
    // 0xcef508: EnterFrame
    //     0xcef508: stp             fp, lr, [SP, #-0x10]!
    //     0xcef50c: mov             fp, SP
    // 0xcef510: mov             x0, x2
    // 0xcef514: CheckStackOverflow
    //     0xcef514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef518: cmp             SP, x16
    //     0xcef51c: b.ls            #0xcef570
    // 0xcef520: LoadField: r2 = r1->field_6f
    //     0xcef520: ldur            w2, [x1, #0x6f]
    // 0xcef524: DecompressPointer r2
    //     0xcef524: add             x2, x2, HEAP, lsl #32
    // 0xcef528: cmp             w2, w0
    // 0xcef52c: b.ne            #0xcef540
    // 0xcef530: r0 = Null
    //     0xcef530: mov             x0, NULL
    // 0xcef534: LeaveFrame
    //     0xcef534: mov             SP, fp
    //     0xcef538: ldp             fp, lr, [SP], #0x10
    // 0xcef53c: ret
    //     0xcef53c: ret             
    // 0xcef540: StoreField: r1->field_6f = r0
    //     0xcef540: stur            w0, [x1, #0x6f]
    //     0xcef544: ldurb           w16, [x1, #-1]
    //     0xcef548: ldurb           w17, [x0, #-1]
    //     0xcef54c: and             x16, x17, x16, lsr #2
    //     0xcef550: tst             x16, HEAP, lsr #32
    //     0xcef554: b.eq            #0xcef55c
    //     0xcef558: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcef55c: r0 = markNeedsLayout()
    //     0xcef55c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcef560: r0 = Null
    //     0xcef560: mov             x0, NULL
    // 0xcef564: LeaveFrame
    //     0xcef564: mov             SP, fp
    //     0xcef568: ldp             fp, lr, [SP], #0x10
    // 0xcef56c: ret
    //     0xcef56c: ret             
    // 0xcef570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef570: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef574: b               #0xcef520
  }
  set _ spacing=(/* No info */) {
    // ** addr: 0xcef578, size: 0x50
    // 0xcef578: EnterFrame
    //     0xcef578: stp             fp, lr, [SP, #-0x10]!
    //     0xcef57c: mov             fp, SP
    // 0xcef580: CheckStackOverflow
    //     0xcef580: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef584: cmp             SP, x16
    //     0xcef588: b.ls            #0xcef5c0
    // 0xcef58c: LoadField: d1 = r1->field_67
    //     0xcef58c: ldur            d1, [x1, #0x67]
    // 0xcef590: fcmp            d1, d0
    // 0xcef594: b.ne            #0xcef5a8
    // 0xcef598: r0 = Null
    //     0xcef598: mov             x0, NULL
    // 0xcef59c: LeaveFrame
    //     0xcef59c: mov             SP, fp
    //     0xcef5a0: ldp             fp, lr, [SP], #0x10
    // 0xcef5a4: ret
    //     0xcef5a4: ret             
    // 0xcef5a8: StoreField: r1->field_67 = d0
    //     0xcef5a8: stur            d0, [x1, #0x67]
    // 0xcef5ac: r0 = markNeedsLayout()
    //     0xcef5ac: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcef5b0: r0 = Null
    //     0xcef5b0: mov             x0, NULL
    // 0xcef5b4: LeaveFrame
    //     0xcef5b4: mov             SP, fp
    //     0xcef5b8: ldp             fp, lr, [SP], #0x10
    // 0xcef5bc: ret
    //     0xcef5bc: ret             
    // 0xcef5c0: r0 = StackOverflowSharedWithFPURegs()
    //     0xcef5c0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcef5c4: b               #0xcef58c
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ec594, size: 0x2c
    // 0x10ec594: EnterFrame
    //     0x10ec594: stp             fp, lr, [SP, #-0x10]!
    //     0x10ec598: mov             fp, SP
    // 0x10ec59c: CheckStackOverflow
    //     0x10ec59c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ec5a0: cmp             SP, x16
    //     0x10ec5a4: b.ls            #0x10ec5b8
    // 0x10ec5a8: r0 = defaultHitTestChildren()
    //     0x10ec5a8: bl              #0x10ec5c0  ; [dart:mixin_deduplication] _MixinApplication453&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultHitTestChildren
    // 0x10ec5ac: LeaveFrame
    //     0x10ec5ac: mov             SP, fp
    //     0x10ec5b0: ldp             fp, lr, [SP], #0x10
    // 0x10ec5b4: ret
    //     0x10ec5b4: ret             
    // 0x10ec5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ec5b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ec5bc: b               #0x10ec5a8
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f024c, size: 0x24
    // 0x10f024c: EnterFrame
    //     0x10f024c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0250: mov             fp, SP
    // 0x10f0254: ldr             x2, [fp, #0x10]
    // 0x10f0258: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0258: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa27a8] AnonymousClosure: (0xb25898), in [package:flutter/src/rendering/wrap.dart] RenderWrap::computeMinIntrinsicHeight (0xb25718)
    //     0x10f025c: ldr             x1, [x1, #0x7a8]
    // 0x10f0260: r0 = AllocateClosure()
    //     0x10f0260: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0264: LeaveFrame
    //     0x10f0264: mov             SP, fp
    //     0x10f0268: ldp             fp, lr, [SP], #0x10
    // 0x10f026c: ret
    //     0x10f026c: ret             
  }
  _ RenderWrap(/* No info */) {
    // ** addr: 0x11ca874, size: 0x190
    // 0x11ca874: EnterFrame
    //     0x11ca874: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca878: mov             fp, SP
    // 0x11ca87c: AllocStack(0x40)
    //     0x11ca87c: sub             SP, SP, #0x40
    // 0x11ca880: r0 = false
    //     0x11ca880: add             x0, NULL, #0x30  ; false
    // 0x11ca884: mov             x4, x5
    // 0x11ca888: stur            x5, [fp, #-0x20]
    // 0x11ca88c: mov             x5, x3
    // 0x11ca890: stur            x3, [fp, #-0x18]
    // 0x11ca894: mov             x3, x6
    // 0x11ca898: stur            x6, [fp, #-0x28]
    // 0x11ca89c: mov             x6, x2
    // 0x11ca8a0: stur            x2, [fp, #-0x10]
    // 0x11ca8a4: mov             x2, x7
    // 0x11ca8a8: stur            x7, [fp, #-0x30]
    // 0x11ca8ac: mov             x7, x1
    // 0x11ca8b0: stur            x1, [fp, #-8]
    // 0x11ca8b4: stur            d0, [fp, #-0x38]
    // 0x11ca8b8: stur            d1, [fp, #-0x40]
    // 0x11ca8bc: CheckStackOverflow
    //     0x11ca8bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca8c0: cmp             SP, x16
    //     0x11ca8c4: b.ls            #0x11ca9fc
    // 0x11ca8c8: StoreField: r7->field_8b = r0
    //     0x11ca8c8: stur            w0, [x7, #0x8b]
    // 0x11ca8cc: r1 = <ClipRectLayer>
    //     0x11ca8cc: add             x1, PP, #0x84, lsl #12  ; [pp+0x84fc8] TypeArguments: <ClipRectLayer>
    //     0x11ca8d0: ldr             x1, [x1, #0xfc8]
    // 0x11ca8d4: r0 = LayerHandle()
    //     0x11ca8d4: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11ca8d8: ldur            x1, [fp, #-8]
    // 0x11ca8dc: StoreField: r1->field_8f = r0
    //     0x11ca8dc: stur            w0, [x1, #0x8f]
    //     0x11ca8e0: ldurb           w16, [x1, #-1]
    //     0x11ca8e4: ldurb           w17, [x0, #-1]
    //     0x11ca8e8: and             x16, x17, x16, lsr #2
    //     0x11ca8ec: tst             x16, HEAP, lsr #32
    //     0x11ca8f0: b.eq            #0x11ca8f8
    //     0x11ca8f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca8f8: ldur            x0, [fp, #-0x20]
    // 0x11ca8fc: StoreField: r1->field_5f = r0
    //     0x11ca8fc: stur            w0, [x1, #0x5f]
    //     0x11ca900: ldurb           w16, [x1, #-1]
    //     0x11ca904: ldurb           w17, [x0, #-1]
    //     0x11ca908: and             x16, x17, x16, lsr #2
    //     0x11ca90c: tst             x16, HEAP, lsr #32
    //     0x11ca910: b.eq            #0x11ca918
    //     0x11ca914: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca918: ldur            x0, [fp, #-0x10]
    // 0x11ca91c: StoreField: r1->field_63 = r0
    //     0x11ca91c: stur            w0, [x1, #0x63]
    //     0x11ca920: ldurb           w16, [x1, #-1]
    //     0x11ca924: ldurb           w17, [x0, #-1]
    //     0x11ca928: and             x16, x17, x16, lsr #2
    //     0x11ca92c: tst             x16, HEAP, lsr #32
    //     0x11ca930: b.eq            #0x11ca938
    //     0x11ca934: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca938: ldur            d0, [fp, #-0x40]
    // 0x11ca93c: StoreField: r1->field_67 = d0
    //     0x11ca93c: stur            d0, [x1, #0x67]
    // 0x11ca940: ldur            x0, [fp, #-0x28]
    // 0x11ca944: StoreField: r1->field_6f = r0
    //     0x11ca944: stur            w0, [x1, #0x6f]
    //     0x11ca948: ldurb           w16, [x1, #-1]
    //     0x11ca94c: ldurb           w17, [x0, #-1]
    //     0x11ca950: and             x16, x17, x16, lsr #2
    //     0x11ca954: tst             x16, HEAP, lsr #32
    //     0x11ca958: b.eq            #0x11ca960
    //     0x11ca95c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca960: ldur            d0, [fp, #-0x38]
    // 0x11ca964: StoreField: r1->field_73 = d0
    //     0x11ca964: stur            d0, [x1, #0x73]
    // 0x11ca968: ldur            x0, [fp, #-0x18]
    // 0x11ca96c: StoreField: r1->field_7b = r0
    //     0x11ca96c: stur            w0, [x1, #0x7b]
    //     0x11ca970: ldurb           w16, [x1, #-1]
    //     0x11ca974: ldurb           w17, [x0, #-1]
    //     0x11ca978: and             x16, x17, x16, lsr #2
    //     0x11ca97c: tst             x16, HEAP, lsr #32
    //     0x11ca980: b.eq            #0x11ca988
    //     0x11ca984: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca988: ldur            x0, [fp, #-0x30]
    // 0x11ca98c: StoreField: r1->field_7f = r0
    //     0x11ca98c: stur            w0, [x1, #0x7f]
    //     0x11ca990: ldurb           w16, [x1, #-1]
    //     0x11ca994: ldurb           w17, [x0, #-1]
    //     0x11ca998: and             x16, x17, x16, lsr #2
    //     0x11ca99c: tst             x16, HEAP, lsr #32
    //     0x11ca9a0: b.eq            #0x11ca9a8
    //     0x11ca9a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca9a8: r0 = Instance_VerticalDirection
    //     0x11ca9a8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0x11ca9ac: ldr             x0, [x0, #0x838]
    // 0x11ca9b0: StoreField: r1->field_83 = r0
    //     0x11ca9b0: stur            w0, [x1, #0x83]
    // 0x11ca9b4: r0 = Instance_Clip
    //     0x11ca9b4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0x11ca9b8: ldr             x0, [x0, #0x840]
    // 0x11ca9bc: StoreField: r1->field_87 = r0
    //     0x11ca9bc: stur            w0, [x1, #0x87]
    // 0x11ca9c0: StoreField: r1->field_4f = rZR
    //     0x11ca9c0: stur            xzr, [x1, #0x4f]
    // 0x11ca9c4: r0 = _LayoutCacheStorage()
    //     0x11ca9c4: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11ca9c8: ldur            x1, [fp, #-8]
    // 0x11ca9cc: StoreField: r1->field_47 = r0
    //     0x11ca9cc: stur            w0, [x1, #0x47]
    //     0x11ca9d0: ldurb           w16, [x1, #-1]
    //     0x11ca9d4: ldurb           w17, [x0, #-1]
    //     0x11ca9d8: and             x16, x17, x16, lsr #2
    //     0x11ca9dc: tst             x16, HEAP, lsr #32
    //     0x11ca9e0: b.eq            #0x11ca9e8
    //     0x11ca9e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca9e8: r0 = RenderObject()
    //     0x11ca9e8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11ca9ec: r0 = Null
    //     0x11ca9ec: mov             x0, NULL
    // 0x11ca9f0: LeaveFrame
    //     0x11ca9f0: mov             SP, fp
    //     0x11ca9f4: ldp             fp, lr, [SP], #0x10
    // 0x11ca9f8: ret
    //     0x11ca9f8: ret             
    // 0x11ca9fc: r0 = StackOverflowSharedWithFPURegs()
    //     0x11ca9fc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11caa00: b               #0x11ca8c8
  }
}

// class id: 8214, size: 0x14, field offset: 0x14
enum WrapCrossAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  get _ _flipped(/* No info */) {
    // ** addr: 0xb665d4, size: 0x38
    // 0xb665d4: LoadField: r2 = r1->field_7
    //     0xb665d4: ldur            x2, [x1, #7]
    // 0xb665d8: cmp             x2, #1
    // 0xb665dc: b.gt            #0xb66600
    // 0xb665e0: cmp             x2, #0
    // 0xb665e4: b.gt            #0xb665f4
    // 0xb665e8: r0 = Instance_WrapCrossAlignment
    //     0xb665e8: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e5b0] Obj!WrapCrossAlignment@12c3fc1
    //     0xb665ec: ldr             x0, [x0, #0x5b0]
    // 0xb665f0: b               #0xb66608
    // 0xb665f4: r0 = Instance_WrapCrossAlignment
    //     0xb665f4: add             x0, PP, #0x18, lsl #12  ; [pp+0x18350] Obj!WrapCrossAlignment@12c4001
    //     0xb665f8: ldr             x0, [x0, #0x350]
    // 0xb665fc: b               #0xb66608
    // 0xb66600: r0 = Instance_WrapCrossAlignment
    //     0xb66600: add             x0, PP, #0x27, lsl #12  ; [pp+0x27538] Obj!WrapCrossAlignment@12c3fe1
    //     0xb66604: ldr             x0, [x0, #0x538]
    // 0xb66608: ret
    //     0xb66608: ret             
  }
  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab41c, size: 0x64
    // 0x11ab41c: EnterFrame
    //     0x11ab41c: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab420: mov             fp, SP
    // 0x11ab424: AllocStack(0x10)
    //     0x11ab424: sub             SP, SP, #0x10
    // 0x11ab428: SetupParameters(WrapCrossAlignment this /* r1 => r0, fp-0x8 */)
    //     0x11ab428: mov             x0, x1
    //     0x11ab42c: stur            x1, [fp, #-8]
    // 0x11ab430: CheckStackOverflow
    //     0x11ab430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab434: cmp             SP, x16
    //     0x11ab438: b.ls            #0x11ab478
    // 0x11ab43c: r1 = Null
    //     0x11ab43c: mov             x1, NULL
    // 0x11ab440: r2 = 4
    //     0x11ab440: mov             x2, #4
    // 0x11ab444: r0 = AllocateArray()
    //     0x11ab444: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab448: r16 = "WrapCrossAlignment."
    //     0x11ab448: add             x16, PP, #0x81, lsl #12  ; [pp+0x81cb8] "WrapCrossAlignment."
    //     0x11ab44c: ldr             x16, [x16, #0xcb8]
    // 0x11ab450: StoreField: r0->field_f = r16
    //     0x11ab450: stur            w16, [x0, #0xf]
    // 0x11ab454: ldur            x1, [fp, #-8]
    // 0x11ab458: LoadField: r2 = r1->field_f
    //     0x11ab458: ldur            w2, [x1, #0xf]
    // 0x11ab45c: DecompressPointer r2
    //     0x11ab45c: add             x2, x2, HEAP, lsl #32
    // 0x11ab460: StoreField: r0->field_13 = r2
    //     0x11ab460: stur            w2, [x0, #0x13]
    // 0x11ab464: str             x0, [SP]
    // 0x11ab468: r0 = _interpolate()
    //     0x11ab468: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab46c: LeaveFrame
    //     0x11ab46c: mov             SP, fp
    //     0x11ab470: ldp             fp, lr, [SP], #0x10
    // 0x11ab474: ret
    //     0x11ab474: ret             
    // 0x11ab478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab478: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab47c: b               #0x11ab43c
  }
}

// class id: 8215, size: 0x14, field offset: 0x14
enum WrapAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _distributeSpace(/* No info */) {
    // ** addr: 0xb661e0, size: 0x3e0
    // 0xb661e0: EnterFrame
    //     0xb661e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb661e4: mov             fp, SP
    // 0xb661e8: CheckStackOverflow
    //     0xb661e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb661ec: cmp             SP, x16
    //     0xb661f0: b.ls            #0xb664e4
    // 0xb661f4: r16 = Instance_WrapAlignment
    //     0xb661f4: add             x16, PP, #0x18, lsl #12  ; [pp+0x18348] Obj!WrapAlignment@12c40c1
    //     0xb661f8: ldr             x16, [x16, #0x348]
    // 0xb661fc: cmp             w1, w16
    // 0xb66200: b.ne            #0xb66270
    // 0xb66204: tbz             w3, #4, #0xb6620c
    // 0xb66208: d0 = 0.000000
    //     0xb66208: eor             v0.16b, v0.16b, v0.16b
    // 0xb6620c: r3 = inline_Allocate_Double()
    //     0xb6620c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb66210: add             x3, x3, #0x10
    //     0xb66214: cmp             x0, x3
    //     0xb66218: b.ls            #0xb664ec
    //     0xb6621c: str             x3, [THR, #0x60]  ; THR::top
    //     0xb66220: sub             x3, x3, #0xf
    //     0xb66224: mov             x0, #0xe19c
    //     0xb66228: movk            x0, #3, lsl #16
    //     0xb6622c: stur            x0, [x3, #-1]
    // 0xb66230: dmb             ishst
    // 0xb66234: StoreField: r3->field_7 = d1
    //     0xb66234: stur            d1, [x3, #7]
    // 0xb66238: r2 = inline_Allocate_Double()
    //     0xb66238: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb6623c: add             x2, x2, #0x10
    //     0xb66240: cmp             x0, x2
    //     0xb66244: b.ls            #0xb66500
    //     0xb66248: str             x2, [THR, #0x60]  ; THR::top
    //     0xb6624c: sub             x2, x2, #0xf
    //     0xb66250: mov             x0, #0xe19c
    //     0xb66254: movk            x0, #3, lsl #16
    //     0xb66258: stur            x0, [x2, #-1]
    // 0xb6625c: dmb             ishst
    // 0xb66260: StoreField: r2->field_7 = d0
    //     0xb66260: stur            d0, [x2, #7]
    // 0xb66264: r0 = AllocateRecord2()
    //     0xb66264: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb66268: mov             x2, x0
    // 0xb6626c: b               #0xb664c8
    // 0xb66270: r16 = Instance_WrapAlignment
    //     0xb66270: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8e590] Obj!WrapAlignment@12c4081
    //     0xb66274: ldr             x16, [x16, #0x590]
    // 0xb66278: cmp             w1, w16
    // 0xb6627c: b.ne            #0xb662a8
    // 0xb66280: eor             x0, x3, #0x10
    // 0xb66284: mov             x3, x0
    // 0xb66288: r1 = Instance_WrapAlignment
    //     0xb66288: add             x1, PP, #0x18, lsl #12  ; [pp+0x18348] Obj!WrapAlignment@12c40c1
    //     0xb6628c: ldr             x1, [x1, #0x348]
    // 0xb66290: r0 = _distributeSpace()
    //     0xb66290: bl              #0xb661e0  ; [package:flutter/src/rendering/wrap.dart] WrapAlignment::_distributeSpace
    // 0xb66294: mov             x2, x0
    // 0xb66298: mov             x3, x1
    // 0xb6629c: r0 = AllocateRecord2()
    //     0xb6629c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb662a0: mov             x2, x0
    // 0xb662a4: b               #0xb664c8
    // 0xb662a8: r16 = Instance_WrapAlignment
    //     0xb662a8: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8e598] Obj!WrapAlignment@12c4061
    //     0xb662ac: ldr             x16, [x16, #0x598]
    // 0xb662b0: cmp             w1, w16
    // 0xb662b4: r16 = true
    //     0xb662b4: add             x16, NULL, #0x20  ; true
    // 0xb662b8: r17 = false
    //     0xb662b8: add             x17, NULL, #0x30  ; false
    // 0xb662bc: csel            x0, x16, x17, eq
    // 0xb662c0: tbnz            w0, #4, #0xb662ec
    // 0xb662c4: cmp             x2, #2
    // 0xb662c8: b.ge            #0xb662ec
    // 0xb662cc: r1 = Instance_WrapAlignment
    //     0xb662cc: add             x1, PP, #0x18, lsl #12  ; [pp+0x18348] Obj!WrapAlignment@12c40c1
    //     0xb662d0: ldr             x1, [x1, #0x348]
    // 0xb662d4: r0 = _distributeSpace()
    //     0xb662d4: bl              #0xb661e0  ; [package:flutter/src/rendering/wrap.dart] WrapAlignment::_distributeSpace
    // 0xb662d8: mov             x2, x0
    // 0xb662dc: mov             x3, x1
    // 0xb662e0: r0 = AllocateRecord2()
    //     0xb662e0: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb662e4: mov             x2, x0
    // 0xb662e8: b               #0xb664c8
    // 0xb662ec: r16 = Instance_WrapAlignment
    //     0xb662ec: add             x16, PP, #0x18, lsl #12  ; [pp+0x18340] Obj!WrapAlignment@12c40a1
    //     0xb662f0: ldr             x16, [x16, #0x340]
    // 0xb662f4: cmp             w1, w16
    // 0xb662f8: b.ne            #0xb66368
    // 0xb662fc: d2 = 2.000000
    //     0xb662fc: fmov            d2, #2.00000000
    // 0xb66300: fdiv            d3, d0, d2
    // 0xb66304: r3 = inline_Allocate_Double()
    //     0xb66304: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb66308: add             x3, x3, #0x10
    //     0xb6630c: cmp             x0, x3
    //     0xb66310: b.ls            #0xb6651c
    //     0xb66314: str             x3, [THR, #0x60]  ; THR::top
    //     0xb66318: sub             x3, x3, #0xf
    //     0xb6631c: mov             x0, #0xe19c
    //     0xb66320: movk            x0, #3, lsl #16
    //     0xb66324: stur            x0, [x3, #-1]
    // 0xb66328: dmb             ishst
    // 0xb6632c: StoreField: r3->field_7 = d1
    //     0xb6632c: stur            d1, [x3, #7]
    // 0xb66330: r2 = inline_Allocate_Double()
    //     0xb66330: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb66334: add             x2, x2, #0x10
    //     0xb66338: cmp             x0, x2
    //     0xb6633c: b.ls            #0xb66530
    //     0xb66340: str             x2, [THR, #0x60]  ; THR::top
    //     0xb66344: sub             x2, x2, #0xf
    //     0xb66348: mov             x0, #0xe19c
    //     0xb6634c: movk            x0, #3, lsl #16
    //     0xb66350: stur            x0, [x2, #-1]
    // 0xb66354: dmb             ishst
    // 0xb66358: StoreField: r2->field_7 = d3
    //     0xb66358: stur            d3, [x2, #7]
    // 0xb6635c: r0 = AllocateRecord2()
    //     0xb6635c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb66360: mov             x2, x0
    // 0xb66364: b               #0xb664c8
    // 0xb66368: d2 = 2.000000
    //     0xb66368: fmov            d2, #2.00000000
    // 0xb6636c: tbnz            w0, #4, #0xb663bc
    // 0xb66370: sub             x0, x2, #1
    // 0xb66374: scvtf           d2, x0
    // 0xb66378: fdiv            d3, d0, d2
    // 0xb6637c: fadd            d0, d3, d1
    // 0xb66380: r3 = inline_Allocate_Double()
    //     0xb66380: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb66384: add             x3, x3, #0x10
    //     0xb66388: cmp             x0, x3
    //     0xb6638c: b.ls            #0xb6654c
    //     0xb66390: str             x3, [THR, #0x60]  ; THR::top
    //     0xb66394: sub             x3, x3, #0xf
    //     0xb66398: mov             x0, #0xe19c
    //     0xb6639c: movk            x0, #3, lsl #16
    //     0xb663a0: stur            x0, [x3, #-1]
    // 0xb663a4: dmb             ishst
    // 0xb663a8: StoreField: r3->field_7 = d0
    //     0xb663a8: stur            d0, [x3, #7]
    // 0xb663ac: r2 = 0.000000
    //     0xb663ac: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb663b0: r0 = AllocateRecord2()
    //     0xb663b0: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb663b4: mov             x2, x0
    // 0xb663b8: b               #0xb664c8
    // 0xb663bc: r16 = Instance_WrapAlignment
    //     0xb663bc: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8e5a0] Obj!WrapAlignment@12c4041
    //     0xb663c0: ldr             x16, [x16, #0x5a0]
    // 0xb663c4: cmp             w1, w16
    // 0xb663c8: b.ne            #0xb66440
    // 0xb663cc: scvtf           d3, x2
    // 0xb663d0: fdiv            d4, d0, d3
    // 0xb663d4: fdiv            d0, d4, d2
    // 0xb663d8: fadd            d2, d4, d1
    // 0xb663dc: r2 = inline_Allocate_Double()
    //     0xb663dc: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb663e0: add             x2, x2, #0x10
    //     0xb663e4: cmp             x0, x2
    //     0xb663e8: b.ls            #0xb66560
    //     0xb663ec: str             x2, [THR, #0x60]  ; THR::top
    //     0xb663f0: sub             x2, x2, #0xf
    //     0xb663f4: mov             x0, #0xe19c
    //     0xb663f8: movk            x0, #3, lsl #16
    //     0xb663fc: stur            x0, [x2, #-1]
    // 0xb66400: dmb             ishst
    // 0xb66404: StoreField: r2->field_7 = d0
    //     0xb66404: stur            d0, [x2, #7]
    // 0xb66408: r3 = inline_Allocate_Double()
    //     0xb66408: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb6640c: add             x3, x3, #0x10
    //     0xb66410: cmp             x0, x3
    //     0xb66414: b.ls            #0xb66574
    //     0xb66418: str             x3, [THR, #0x60]  ; THR::top
    //     0xb6641c: sub             x3, x3, #0xf
    //     0xb66420: mov             x0, #0xe19c
    //     0xb66424: movk            x0, #3, lsl #16
    //     0xb66428: stur            x0, [x3, #-1]
    // 0xb6642c: dmb             ishst
    // 0xb66430: StoreField: r3->field_7 = d2
    //     0xb66430: stur            d2, [x3, #7]
    // 0xb66434: r0 = AllocateRecord2()
    //     0xb66434: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb66438: mov             x2, x0
    // 0xb6643c: b               #0xb664c8
    // 0xb66440: r16 = Instance_WrapAlignment
    //     0xb66440: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8e5a8] Obj!WrapAlignment@12c4021
    //     0xb66444: ldr             x16, [x16, #0x5a8]
    // 0xb66448: cmp             w1, w16
    // 0xb6644c: b.ne            #0xb664c4
    // 0xb66450: add             x0, x2, #1
    // 0xb66454: scvtf           d2, x0
    // 0xb66458: fdiv            d3, d0, d2
    // 0xb6645c: fadd            d0, d3, d1
    // 0xb66460: r2 = inline_Allocate_Double()
    //     0xb66460: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb66464: add             x2, x2, #0x10
    //     0xb66468: cmp             x0, x2
    //     0xb6646c: b.ls            #0xb66590
    //     0xb66470: str             x2, [THR, #0x60]  ; THR::top
    //     0xb66474: sub             x2, x2, #0xf
    //     0xb66478: mov             x0, #0xe19c
    //     0xb6647c: movk            x0, #3, lsl #16
    //     0xb66480: stur            x0, [x2, #-1]
    // 0xb66484: dmb             ishst
    // 0xb66488: StoreField: r2->field_7 = d3
    //     0xb66488: stur            d3, [x2, #7]
    // 0xb6648c: r3 = inline_Allocate_Double()
    //     0xb6648c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb66490: add             x3, x3, #0x10
    //     0xb66494: cmp             x0, x3
    //     0xb66498: b.ls            #0xb665a4
    //     0xb6649c: str             x3, [THR, #0x60]  ; THR::top
    //     0xb664a0: sub             x3, x3, #0xf
    //     0xb664a4: mov             x0, #0xe19c
    //     0xb664a8: movk            x0, #3, lsl #16
    //     0xb664ac: stur            x0, [x3, #-1]
    // 0xb664b0: dmb             ishst
    // 0xb664b4: StoreField: r3->field_7 = d0
    //     0xb664b4: stur            d0, [x3, #7]
    // 0xb664b8: r0 = AllocateRecord2()
    //     0xb664b8: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb664bc: mov             x2, x0
    // 0xb664c0: b               #0xb664c8
    // 0xb664c4: r2 = Null
    //     0xb664c4: mov             x2, NULL
    // 0xb664c8: LoadField: r0 = r2->field_f
    //     0xb664c8: ldur            w0, [x2, #0xf]
    // 0xb664cc: DecompressPointer r0
    //     0xb664cc: add             x0, x0, HEAP, lsl #32
    // 0xb664d0: LoadField: r1 = r2->field_13
    //     0xb664d0: ldur            w1, [x2, #0x13]
    // 0xb664d4: DecompressPointer r1
    //     0xb664d4: add             x1, x1, HEAP, lsl #32
    // 0xb664d8: LeaveFrame
    //     0xb664d8: mov             SP, fp
    //     0xb664dc: ldp             fp, lr, [SP], #0x10
    // 0xb664e0: ret
    //     0xb664e0: ret             
    // 0xb664e4: r0 = StackOverflowSharedWithFPURegs()
    //     0xb664e4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb664e8: b               #0xb661f4
    // 0xb664ec: stp             q0, q1, [SP, #-0x20]!
    // 0xb664f0: r0 = AllocateDouble()
    //     0xb664f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb664f4: mov             x3, x0
    // 0xb664f8: ldp             q0, q1, [SP], #0x20
    // 0xb664fc: b               #0xb66234
    // 0xb66500: SaveReg d0
    //     0xb66500: str             q0, [SP, #-0x10]!
    // 0xb66504: SaveReg r3
    //     0xb66504: str             x3, [SP, #-8]!
    // 0xb66508: r0 = AllocateDouble()
    //     0xb66508: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6650c: mov             x2, x0
    // 0xb66510: RestoreReg r3
    //     0xb66510: ldr             x3, [SP], #8
    // 0xb66514: RestoreReg d0
    //     0xb66514: ldr             q0, [SP], #0x10
    // 0xb66518: b               #0xb66260
    // 0xb6651c: stp             q1, q3, [SP, #-0x20]!
    // 0xb66520: r0 = AllocateDouble()
    //     0xb66520: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb66524: mov             x3, x0
    // 0xb66528: ldp             q1, q3, [SP], #0x20
    // 0xb6652c: b               #0xb6632c
    // 0xb66530: SaveReg d3
    //     0xb66530: str             q3, [SP, #-0x10]!
    // 0xb66534: SaveReg r3
    //     0xb66534: str             x3, [SP, #-8]!
    // 0xb66538: r0 = AllocateDouble()
    //     0xb66538: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb6653c: mov             x2, x0
    // 0xb66540: RestoreReg r3
    //     0xb66540: ldr             x3, [SP], #8
    // 0xb66544: RestoreReg d3
    //     0xb66544: ldr             q3, [SP], #0x10
    // 0xb66548: b               #0xb66358
    // 0xb6654c: SaveReg d0
    //     0xb6654c: str             q0, [SP, #-0x10]!
    // 0xb66550: r0 = AllocateDouble()
    //     0xb66550: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb66554: mov             x3, x0
    // 0xb66558: RestoreReg d0
    //     0xb66558: ldr             q0, [SP], #0x10
    // 0xb6655c: b               #0xb663a8
    // 0xb66560: stp             q0, q2, [SP, #-0x20]!
    // 0xb66564: r0 = AllocateDouble()
    //     0xb66564: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb66568: mov             x2, x0
    // 0xb6656c: ldp             q0, q2, [SP], #0x20
    // 0xb66570: b               #0xb66404
    // 0xb66574: SaveReg d2
    //     0xb66574: str             q2, [SP, #-0x10]!
    // 0xb66578: SaveReg r2
    //     0xb66578: str             x2, [SP, #-8]!
    // 0xb6657c: r0 = AllocateDouble()
    //     0xb6657c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb66580: mov             x3, x0
    // 0xb66584: RestoreReg r2
    //     0xb66584: ldr             x2, [SP], #8
    // 0xb66588: RestoreReg d2
    //     0xb66588: ldr             q2, [SP], #0x10
    // 0xb6658c: b               #0xb66430
    // 0xb66590: stp             q0, q3, [SP, #-0x20]!
    // 0xb66594: r0 = AllocateDouble()
    //     0xb66594: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb66598: mov             x2, x0
    // 0xb6659c: ldp             q0, q3, [SP], #0x20
    // 0xb665a0: b               #0xb66488
    // 0xb665a4: SaveReg d0
    //     0xb665a4: str             q0, [SP, #-0x10]!
    // 0xb665a8: SaveReg r2
    //     0xb665a8: str             x2, [SP, #-8]!
    // 0xb665ac: r0 = AllocateDouble()
    //     0xb665ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb665b0: mov             x3, x0
    // 0xb665b4: RestoreReg r2
    //     0xb665b4: ldr             x2, [SP], #8
    // 0xb665b8: RestoreReg d0
    //     0xb665b8: ldr             q0, [SP], #0x10
    // 0xb665bc: b               #0xb664b4
  }
  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab3b8, size: 0x64
    // 0x11ab3b8: EnterFrame
    //     0x11ab3b8: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab3bc: mov             fp, SP
    // 0x11ab3c0: AllocStack(0x10)
    //     0x11ab3c0: sub             SP, SP, #0x10
    // 0x11ab3c4: SetupParameters(WrapAlignment this /* r1 => r0, fp-0x8 */)
    //     0x11ab3c4: mov             x0, x1
    //     0x11ab3c8: stur            x1, [fp, #-8]
    // 0x11ab3cc: CheckStackOverflow
    //     0x11ab3cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab3d0: cmp             SP, x16
    //     0x11ab3d4: b.ls            #0x11ab414
    // 0x11ab3d8: r1 = Null
    //     0x11ab3d8: mov             x1, NULL
    // 0x11ab3dc: r2 = 4
    //     0x11ab3dc: mov             x2, #4
    // 0x11ab3e0: r0 = AllocateArray()
    //     0x11ab3e0: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab3e4: r16 = "WrapAlignment."
    //     0x11ab3e4: add             x16, PP, #0x81, lsl #12  ; [pp+0x81cc0] "WrapAlignment."
    //     0x11ab3e8: ldr             x16, [x16, #0xcc0]
    // 0x11ab3ec: StoreField: r0->field_f = r16
    //     0x11ab3ec: stur            w16, [x0, #0xf]
    // 0x11ab3f0: ldur            x1, [fp, #-8]
    // 0x11ab3f4: LoadField: r2 = r1->field_f
    //     0x11ab3f4: ldur            w2, [x1, #0xf]
    // 0x11ab3f8: DecompressPointer r2
    //     0x11ab3f8: add             x2, x2, HEAP, lsl #32
    // 0x11ab3fc: StoreField: r0->field_13 = r2
    //     0x11ab3fc: stur            w2, [x0, #0x13]
    // 0x11ab400: str             x0, [SP]
    // 0x11ab404: r0 = _interpolate()
    //     0x11ab404: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab408: LeaveFrame
    //     0x11ab408: mov             SP, fp
    //     0x11ab40c: ldp             fp, lr, [SP], #0x10
    // 0x11ab410: ret
    //     0x11ab410: ret             
    // 0x11ab414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab414: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab418: b               #0x11ab3d8
  }
}
