// lib: , url: package:flutter/src/rendering/stack.dart

// class id: 1049049, size: 0x8
class :: {
}

// class id: 2846, size: 0x28, field offset: 0x8
//   const constructor, 
class RelativeRect extends Object {

  _Mint field_8;
  _Mint field_10;
  _Mint field_18;
  _Mint field_20;

  _ ==(/* No info */) {
    // ** addr: 0x129a324, size: 0x98
    // 0x129a324: ldr             x1, [SP]
    // 0x129a328: cmp             w1, NULL
    // 0x129a32c: b.ne            #0x129a338
    // 0x129a330: r0 = false
    //     0x129a330: add             x0, NULL, #0x30  ; false
    // 0x129a334: ret
    //     0x129a334: ret             
    // 0x129a338: ldr             x2, [SP, #8]
    // 0x129a33c: cmp             w2, w1
    // 0x129a340: b.ne            #0x129a34c
    // 0x129a344: r0 = true
    //     0x129a344: add             x0, NULL, #0x20  ; true
    // 0x129a348: ret
    //     0x129a348: ret             
    // 0x129a34c: r3 = 60
    //     0x129a34c: mov             x3, #0x3c
    // 0x129a350: branchIfSmi(r1, 0x129a35c)
    //     0x129a350: tbz             w1, #0, #0x129a35c
    // 0x129a354: r3 = LoadClassIdInstr(r1)
    //     0x129a354: ldur            x3, [x1, #-1]
    //     0x129a358: ubfx            x3, x3, #0xc, #0x14
    // 0x129a35c: cmp             x3, #0xb1e
    // 0x129a360: b.ne            #0x129a3b4
    // 0x129a364: LoadField: d0 = r1->field_7
    //     0x129a364: ldur            d0, [x1, #7]
    // 0x129a368: LoadField: d1 = r2->field_7
    //     0x129a368: ldur            d1, [x2, #7]
    // 0x129a36c: fcmp            d0, d1
    // 0x129a370: b.ne            #0x129a3b4
    // 0x129a374: LoadField: d0 = r1->field_f
    //     0x129a374: ldur            d0, [x1, #0xf]
    // 0x129a378: LoadField: d1 = r2->field_f
    //     0x129a378: ldur            d1, [x2, #0xf]
    // 0x129a37c: fcmp            d0, d1
    // 0x129a380: b.ne            #0x129a3b4
    // 0x129a384: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x129a384: ldur            d0, [x1, #0x17]
    // 0x129a388: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x129a388: ldur            d1, [x2, #0x17]
    // 0x129a38c: fcmp            d0, d1
    // 0x129a390: b.ne            #0x129a3b4
    // 0x129a394: LoadField: d0 = r1->field_1f
    //     0x129a394: ldur            d0, [x1, #0x1f]
    // 0x129a398: LoadField: d1 = r2->field_1f
    //     0x129a398: ldur            d1, [x2, #0x1f]
    // 0x129a39c: fcmp            d0, d1
    // 0x129a3a0: r16 = true
    //     0x129a3a0: add             x16, NULL, #0x20  ; true
    // 0x129a3a4: r17 = false
    //     0x129a3a4: add             x17, NULL, #0x30  ; false
    // 0x129a3a8: csel            x1, x16, x17, eq
    // 0x129a3ac: mov             x0, x1
    // 0x129a3b0: b               #0x129a3b8
    // 0x129a3b4: r0 = false
    //     0x129a3b4: add             x0, NULL, #0x30  ; false
    // 0x129a3b8: ret
    //     0x129a3b8: ret             
  }
  _ toRect(/* No info */) {
    // ** addr: 0x12e4818, size: 0x7c
    // 0x12e4818: EnterFrame
    //     0x12e4818: stp             fp, lr, [SP, #-0x10]!
    //     0x12e481c: mov             fp, SP
    // 0x12e4820: AllocStack(0x20)
    //     0x12e4820: sub             SP, SP, #0x20
    // 0x12e4824: LoadField: d0 = r1->field_7
    //     0x12e4824: ldur            d0, [x1, #7]
    // 0x12e4828: stur            d0, [fp, #-0x20]
    // 0x12e482c: LoadField: d1 = r1->field_f
    //     0x12e482c: ldur            d1, [x1, #0xf]
    // 0x12e4830: stur            d1, [fp, #-0x18]
    // 0x12e4834: ArrayLoad: d2 = r2[0]  ; List_8
    //     0x12e4834: ldur            d2, [x2, #0x17]
    // 0x12e4838: LoadField: d3 = r2->field_7
    //     0x12e4838: ldur            d3, [x2, #7]
    // 0x12e483c: fsub            d4, d2, d3
    // 0x12e4840: ArrayLoad: d2 = r1[0]  ; List_8
    //     0x12e4840: ldur            d2, [x1, #0x17]
    // 0x12e4844: fsub            d3, d4, d2
    // 0x12e4848: stur            d3, [fp, #-0x10]
    // 0x12e484c: LoadField: d2 = r2->field_1f
    //     0x12e484c: ldur            d2, [x2, #0x1f]
    // 0x12e4850: LoadField: d4 = r2->field_f
    //     0x12e4850: ldur            d4, [x2, #0xf]
    // 0x12e4854: fsub            d5, d2, d4
    // 0x12e4858: LoadField: d2 = r1->field_1f
    //     0x12e4858: ldur            d2, [x1, #0x1f]
    // 0x12e485c: fsub            d4, d5, d2
    // 0x12e4860: stur            d4, [fp, #-8]
    // 0x12e4864: r0 = Rect()
    //     0x12e4864: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x12e4868: ldur            d0, [fp, #-0x20]
    // 0x12e486c: StoreField: r0->field_7 = d0
    //     0x12e486c: stur            d0, [x0, #7]
    // 0x12e4870: ldur            d0, [fp, #-0x18]
    // 0x12e4874: StoreField: r0->field_f = d0
    //     0x12e4874: stur            d0, [x0, #0xf]
    // 0x12e4878: ldur            d0, [fp, #-0x10]
    // 0x12e487c: ArrayStore: r0[0] = d0  ; List_8
    //     0x12e487c: stur            d0, [x0, #0x17]
    // 0x12e4880: ldur            d0, [fp, #-8]
    // 0x12e4884: StoreField: r0->field_1f = d0
    //     0x12e4884: stur            d0, [x0, #0x1f]
    // 0x12e4888: LeaveFrame
    //     0x12e4888: mov             SP, fp
    //     0x12e488c: ldp             fp, lr, [SP], #0x10
    // 0x12e4890: ret
    //     0x12e4890: ret             
  }
  _ RelativeRect.fromSize(/* No info */) {
    // ** addr: 0x130e1c4, size: 0x38
    // 0x130e1c4: LoadField: d0 = r2->field_7
    //     0x130e1c4: ldur            d0, [x2, #7]
    // 0x130e1c8: StoreField: r1->field_7 = d0
    //     0x130e1c8: stur            d0, [x1, #7]
    // 0x130e1cc: LoadField: d0 = r2->field_f
    //     0x130e1cc: ldur            d0, [x2, #0xf]
    // 0x130e1d0: StoreField: r1->field_f = d0
    //     0x130e1d0: stur            d0, [x1, #0xf]
    // 0x130e1d4: LoadField: d0 = r3->field_7
    //     0x130e1d4: ldur            d0, [x3, #7]
    // 0x130e1d8: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x130e1d8: ldur            d1, [x2, #0x17]
    // 0x130e1dc: fsub            d2, d0, d1
    // 0x130e1e0: ArrayStore: r1[0] = d2  ; List_8
    //     0x130e1e0: stur            d2, [x1, #0x17]
    // 0x130e1e4: LoadField: d0 = r3->field_f
    //     0x130e1e4: ldur            d0, [x3, #0xf]
    // 0x130e1e8: LoadField: d1 = r2->field_1f
    //     0x130e1e8: ldur            d1, [x2, #0x1f]
    // 0x130e1ec: fsub            d2, d0, d1
    // 0x130e1f0: StoreField: r1->field_1f = d2
    //     0x130e1f0: stur            d2, [x1, #0x1f]
    // 0x130e1f4: r0 = Null
    //     0x130e1f4: mov             x0, NULL
    // 0x130e1f8: ret
    //     0x130e1f8: ret             
  }
}

// class id: 4208, size: 0x30, field offset: 0x18
class StackParentData extends ContainerBoxParentData<dynamic> {

  _ positionedChildConstraints(/* No info */) {
    // ** addr: 0xb5f0b4, size: 0x268
    // 0xb5f0b4: EnterFrame
    //     0xb5f0b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5f0b8: mov             fp, SP
    // 0xb5f0bc: AllocStack(0x18)
    //     0xb5f0bc: sub             SP, SP, #0x18
    // 0xb5f0c0: LoadField: r0 = r1->field_23
    //     0xb5f0c0: ldur            w0, [x1, #0x23]
    // 0xb5f0c4: DecompressPointer r0
    //     0xb5f0c4: add             x0, x0, HEAP, lsl #32
    // 0xb5f0c8: LoadField: r3 = r1->field_1b
    //     0xb5f0c8: ldur            w3, [x1, #0x1b]
    // 0xb5f0cc: DecompressPointer r3
    //     0xb5f0cc: add             x3, x3, HEAP, lsl #32
    // 0xb5f0d0: cmp             w0, NULL
    // 0xb5f0d4: b.eq            #0xb5f124
    // 0xb5f0d8: cmp             w3, NULL
    // 0xb5f0dc: b.eq            #0xb5f124
    // 0xb5f0e0: LoadField: d0 = r2->field_7
    //     0xb5f0e0: ldur            d0, [x2, #7]
    // 0xb5f0e4: LoadField: d1 = r3->field_7
    //     0xb5f0e4: ldur            d1, [x3, #7]
    // 0xb5f0e8: fsub            d2, d0, d1
    // 0xb5f0ec: LoadField: d0 = r0->field_7
    //     0xb5f0ec: ldur            d0, [x0, #7]
    // 0xb5f0f0: fsub            d1, d2, d0
    // 0xb5f0f4: r0 = inline_Allocate_Double()
    //     0xb5f0f4: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xb5f0f8: add             x0, x0, #0x10
    //     0xb5f0fc: cmp             x3, x0
    //     0xb5f100: b.ls            #0xb5f2b4
    //     0xb5f104: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5f108: sub             x0, x0, #0xf
    //     0xb5f10c: mov             x3, #0xe19c
    //     0xb5f110: movk            x3, #3, lsl #16
    //     0xb5f114: stur            x3, [x0, #-1]
    // 0xb5f118: dmb             ishst
    // 0xb5f11c: StoreField: r0->field_7 = d1
    //     0xb5f11c: stur            d1, [x0, #7]
    // 0xb5f120: b               #0xb5f12c
    // 0xb5f124: LoadField: r0 = r1->field_27
    //     0xb5f124: ldur            w0, [x1, #0x27]
    // 0xb5f128: DecompressPointer r0
    //     0xb5f128: add             x0, x0, HEAP, lsl #32
    // 0xb5f12c: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xb5f12c: ldur            w3, [x1, #0x17]
    // 0xb5f130: DecompressPointer r3
    //     0xb5f130: add             x3, x3, HEAP, lsl #32
    // 0xb5f134: LoadField: r4 = r1->field_1f
    //     0xb5f134: ldur            w4, [x1, #0x1f]
    // 0xb5f138: DecompressPointer r4
    //     0xb5f138: add             x4, x4, HEAP, lsl #32
    // 0xb5f13c: cmp             w3, NULL
    // 0xb5f140: b.eq            #0xb5f190
    // 0xb5f144: cmp             w4, NULL
    // 0xb5f148: b.eq            #0xb5f190
    // 0xb5f14c: LoadField: d0 = r2->field_f
    //     0xb5f14c: ldur            d0, [x2, #0xf]
    // 0xb5f150: LoadField: d1 = r4->field_7
    //     0xb5f150: ldur            d1, [x4, #7]
    // 0xb5f154: fsub            d2, d0, d1
    // 0xb5f158: LoadField: d0 = r3->field_7
    //     0xb5f158: ldur            d0, [x3, #7]
    // 0xb5f15c: fsub            d1, d2, d0
    // 0xb5f160: r1 = inline_Allocate_Double()
    //     0xb5f160: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb5f164: add             x1, x1, #0x10
    //     0xb5f168: cmp             x2, x1
    //     0xb5f16c: b.ls            #0xb5f2cc
    //     0xb5f170: str             x1, [THR, #0x60]  ; THR::top
    //     0xb5f174: sub             x1, x1, #0xf
    //     0xb5f178: mov             x2, #0xe19c
    //     0xb5f17c: movk            x2, #3, lsl #16
    //     0xb5f180: stur            x2, [x1, #-1]
    // 0xb5f184: dmb             ishst
    // 0xb5f188: StoreField: r1->field_7 = d1
    //     0xb5f188: stur            d1, [x1, #7]
    // 0xb5f18c: b               #0xb5f19c
    // 0xb5f190: LoadField: r2 = r1->field_2b
    //     0xb5f190: ldur            w2, [x1, #0x2b]
    // 0xb5f194: DecompressPointer r2
    //     0xb5f194: add             x2, x2, HEAP, lsl #32
    // 0xb5f198: mov             x1, x2
    // 0xb5f19c: cmp             w0, NULL
    // 0xb5f1a0: b.ne            #0xb5f1b0
    // 0xb5f1a4: r0 = Null
    //     0xb5f1a4: mov             x0, NULL
    // 0xb5f1a8: d0 = 0.000000
    //     0xb5f1a8: eor             v0.16b, v0.16b, v0.16b
    // 0xb5f1ac: b               #0xb5f1e8
    // 0xb5f1b0: d0 = 0.000000
    //     0xb5f1b0: eor             v0.16b, v0.16b, v0.16b
    // 0xb5f1b4: LoadField: d1 = r0->field_7
    //     0xb5f1b4: ldur            d1, [x0, #7]
    // 0xb5f1b8: fmax            v2.2d, v0.2d, v1.2d
    // 0xb5f1bc: r0 = inline_Allocate_Double()
    //     0xb5f1bc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb5f1c0: add             x0, x0, #0x10
    //     0xb5f1c4: cmp             x2, x0
    //     0xb5f1c8: b.ls            #0xb5f2e8
    //     0xb5f1cc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5f1d0: sub             x0, x0, #0xf
    //     0xb5f1d4: mov             x2, #0xe19c
    //     0xb5f1d8: movk            x2, #3, lsl #16
    //     0xb5f1dc: stur            x2, [x0, #-1]
    // 0xb5f1e0: dmb             ishst
    // 0xb5f1e4: StoreField: r0->field_7 = d2
    //     0xb5f1e4: stur            d2, [x0, #7]
    // 0xb5f1e8: stur            x0, [fp, #-0x10]
    // 0xb5f1ec: cmp             w1, NULL
    // 0xb5f1f0: b.ne            #0xb5f1fc
    // 0xb5f1f4: r1 = Null
    //     0xb5f1f4: mov             x1, NULL
    // 0xb5f1f8: b               #0xb5f230
    // 0xb5f1fc: LoadField: d1 = r1->field_7
    //     0xb5f1fc: ldur            d1, [x1, #7]
    // 0xb5f200: fmax            v2.2d, v0.2d, v1.2d
    // 0xb5f204: r1 = inline_Allocate_Double()
    //     0xb5f204: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb5f208: add             x1, x1, #0x10
    //     0xb5f20c: cmp             x2, x1
    //     0xb5f210: b.ls            #0xb5f300
    //     0xb5f214: str             x1, [THR, #0x60]  ; THR::top
    //     0xb5f218: sub             x1, x1, #0xf
    //     0xb5f21c: mov             x2, #0xe19c
    //     0xb5f220: movk            x2, #3, lsl #16
    //     0xb5f224: stur            x2, [x1, #-1]
    // 0xb5f228: dmb             ishst
    // 0xb5f22c: StoreField: r1->field_7 = d2
    //     0xb5f22c: stur            d2, [x1, #7]
    // 0xb5f230: stur            x1, [fp, #-8]
    // 0xb5f234: cmp             w0, NULL
    // 0xb5f238: b.ne            #0xb5f244
    // 0xb5f23c: d0 = 0.000000
    //     0xb5f23c: eor             v0.16b, v0.16b, v0.16b
    // 0xb5f240: b               #0xb5f248
    // 0xb5f244: LoadField: d0 = r0->field_7
    //     0xb5f244: ldur            d0, [x0, #7]
    // 0xb5f248: stur            d0, [fp, #-0x18]
    // 0xb5f24c: r0 = BoxConstraints()
    //     0xb5f24c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb5f250: ldur            d0, [fp, #-0x18]
    // 0xb5f254: StoreField: r0->field_7 = d0
    //     0xb5f254: stur            d0, [x0, #7]
    // 0xb5f258: ldur            x1, [fp, #-0x10]
    // 0xb5f25c: cmp             w1, NULL
    // 0xb5f260: b.ne            #0xb5f26c
    // 0xb5f264: d0 = inf
    //     0xb5f264: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb5f268: b               #0xb5f270
    // 0xb5f26c: LoadField: d0 = r1->field_7
    //     0xb5f26c: ldur            d0, [x1, #7]
    // 0xb5f270: ldur            x1, [fp, #-8]
    // 0xb5f274: StoreField: r0->field_f = d0
    //     0xb5f274: stur            d0, [x0, #0xf]
    // 0xb5f278: cmp             w1, NULL
    // 0xb5f27c: b.ne            #0xb5f288
    // 0xb5f280: d0 = 0.000000
    //     0xb5f280: eor             v0.16b, v0.16b, v0.16b
    // 0xb5f284: b               #0xb5f28c
    // 0xb5f288: LoadField: d0 = r1->field_7
    //     0xb5f288: ldur            d0, [x1, #7]
    // 0xb5f28c: ArrayStore: r0[0] = d0  ; List_8
    //     0xb5f28c: stur            d0, [x0, #0x17]
    // 0xb5f290: cmp             w1, NULL
    // 0xb5f294: b.ne            #0xb5f2a0
    // 0xb5f298: d0 = inf
    //     0xb5f298: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb5f29c: b               #0xb5f2a4
    // 0xb5f2a0: LoadField: d0 = r1->field_7
    //     0xb5f2a0: ldur            d0, [x1, #7]
    // 0xb5f2a4: StoreField: r0->field_1f = d0
    //     0xb5f2a4: stur            d0, [x0, #0x1f]
    // 0xb5f2a8: LeaveFrame
    //     0xb5f2a8: mov             SP, fp
    //     0xb5f2ac: ldp             fp, lr, [SP], #0x10
    // 0xb5f2b0: ret
    //     0xb5f2b0: ret             
    // 0xb5f2b4: SaveReg d1
    //     0xb5f2b4: str             q1, [SP, #-0x10]!
    // 0xb5f2b8: stp             x1, x2, [SP, #-0x10]!
    // 0xb5f2bc: r0 = AllocateDouble()
    //     0xb5f2bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5f2c0: ldp             x1, x2, [SP], #0x10
    // 0xb5f2c4: RestoreReg d1
    //     0xb5f2c4: ldr             q1, [SP], #0x10
    // 0xb5f2c8: b               #0xb5f11c
    // 0xb5f2cc: SaveReg d1
    //     0xb5f2cc: str             q1, [SP, #-0x10]!
    // 0xb5f2d0: SaveReg r0
    //     0xb5f2d0: str             x0, [SP, #-8]!
    // 0xb5f2d4: r0 = AllocateDouble()
    //     0xb5f2d4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5f2d8: mov             x1, x0
    // 0xb5f2dc: RestoreReg r0
    //     0xb5f2dc: ldr             x0, [SP], #8
    // 0xb5f2e0: RestoreReg d1
    //     0xb5f2e0: ldr             q1, [SP], #0x10
    // 0xb5f2e4: b               #0xb5f188
    // 0xb5f2e8: stp             q0, q2, [SP, #-0x20]!
    // 0xb5f2ec: SaveReg r1
    //     0xb5f2ec: str             x1, [SP, #-8]!
    // 0xb5f2f0: r0 = AllocateDouble()
    //     0xb5f2f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5f2f4: RestoreReg r1
    //     0xb5f2f4: ldr             x1, [SP], #8
    // 0xb5f2f8: ldp             q0, q2, [SP], #0x20
    // 0xb5f2fc: b               #0xb5f1e4
    // 0xb5f300: SaveReg d2
    //     0xb5f300: str             q2, [SP, #-0x10]!
    // 0xb5f304: SaveReg r0
    //     0xb5f304: str             x0, [SP, #-8]!
    // 0xb5f308: r0 = AllocateDouble()
    //     0xb5f308: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5f30c: mov             x1, x0
    // 0xb5f310: RestoreReg r0
    //     0xb5f310: ldr             x0, [SP], #8
    // 0xb5f314: RestoreReg d2
    //     0xb5f314: ldr             q2, [SP], #0x10
    // 0xb5f318: b               #0xb5f22c
  }
}

// class id: 4823, size: 0x7c, field offset: 0x60
class RenderStack extends _MixinApplication451&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin {

  [closure] double <anonymous closure>(dynamic, RenderBox) {
    // ** addr: 0xb1c278, size: 0x84
    // 0xb1c278: EnterFrame
    //     0xb1c278: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c27c: mov             fp, SP
    // 0xb1c280: ldr             x0, [fp, #0x18]
    // 0xb1c284: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1c284: ldur            w1, [x0, #0x17]
    // 0xb1c288: DecompressPointer r1
    //     0xb1c288: add             x1, x1, HEAP, lsl #32
    // 0xb1c28c: CheckStackOverflow
    //     0xb1c28c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c290: cmp             SP, x16
    //     0xb1c294: b.ls            #0xb1c2e4
    // 0xb1c298: LoadField: r0 = r1->field_f
    //     0xb1c298: ldur            w0, [x1, #0xf]
    // 0xb1c29c: DecompressPointer r0
    //     0xb1c29c: add             x0, x0, HEAP, lsl #32
    // 0xb1c2a0: LoadField: d0 = r0->field_7
    //     0xb1c2a0: ldur            d0, [x0, #7]
    // 0xb1c2a4: ldr             x1, [fp, #0x10]
    // 0xb1c2a8: r0 = getMinIntrinsicWidth()
    //     0xb1c2a8: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb1c2ac: r0 = inline_Allocate_Double()
    //     0xb1c2ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1c2b0: add             x0, x0, #0x10
    //     0xb1c2b4: cmp             x1, x0
    //     0xb1c2b8: b.ls            #0xb1c2ec
    //     0xb1c2bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1c2c0: sub             x0, x0, #0xf
    //     0xb1c2c4: mov             x1, #0xe19c
    //     0xb1c2c8: movk            x1, #3, lsl #16
    //     0xb1c2cc: stur            x1, [x0, #-1]
    // 0xb1c2d0: dmb             ishst
    // 0xb1c2d4: StoreField: r0->field_7 = d0
    //     0xb1c2d4: stur            d0, [x0, #7]
    // 0xb1c2d8: LeaveFrame
    //     0xb1c2d8: mov             SP, fp
    //     0xb1c2dc: ldp             fp, lr, [SP], #0x10
    // 0xb1c2e0: ret
    //     0xb1c2e0: ret             
    // 0xb1c2e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c2e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c2e8: b               #0xb1c298
    // 0xb1c2ec: SaveReg d0
    //     0xb1c2ec: str             q0, [SP, #-0x10]!
    // 0xb1c2f0: r0 = AllocateDouble()
    //     0xb1c2f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1c2f4: RestoreReg d0
    //     0xb1c2f4: ldr             q0, [SP], #0x10
    // 0xb1c2f8: b               #0xb1c2d4
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb1c2fc, size: 0x74
    // 0xb1c2fc: EnterFrame
    //     0xb1c2fc: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c300: mov             fp, SP
    // 0xb1c304: AllocStack(0x10)
    //     0xb1c304: sub             SP, SP, #0x10
    // 0xb1c308: SetupParameters(RenderStack this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb1c308: stur            x1, [fp, #-8]
    //     0xb1c30c: stur            x2, [fp, #-0x10]
    // 0xb1c310: CheckStackOverflow
    //     0xb1c310: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c314: cmp             SP, x16
    //     0xb1c318: b.ls            #0xb1c368
    // 0xb1c31c: r1 = 1
    //     0xb1c31c: mov             x1, #1
    // 0xb1c320: r0 = AllocateContext()
    //     0xb1c320: bl              #0x13de838  ; AllocateContextStub
    // 0xb1c324: mov             x1, x0
    // 0xb1c328: ldur            x0, [fp, #-0x10]
    // 0xb1c32c: StoreField: r1->field_f = r0
    //     0xb1c32c: stur            w0, [x1, #0xf]
    // 0xb1c330: ldur            x0, [fp, #-8]
    // 0xb1c334: LoadField: r3 = r0->field_57
    //     0xb1c334: ldur            w3, [x0, #0x57]
    // 0xb1c338: DecompressPointer r3
    //     0xb1c338: add             x3, x3, HEAP, lsl #32
    // 0xb1c33c: mov             x2, x1
    // 0xb1c340: stur            x3, [fp, #-0x10]
    // 0xb1c344: r1 = Function '<anonymous closure>':.
    //     0xb1c344: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4200] AnonymousClosure: (0xb1c278), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicWidth (0xb1c2fc)
    //     0xb1c348: ldr             x1, [x1, #0x200]
    // 0xb1c34c: r0 = AllocateClosure()
    //     0xb1c34c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1c350: ldur            x1, [fp, #-0x10]
    // 0xb1c354: mov             x2, x0
    // 0xb1c358: r0 = getIntrinsicDimension()
    //     0xb1c358: bl              #0xb1c370  ; [package:flutter/src/rendering/stack.dart] RenderStack::getIntrinsicDimension
    // 0xb1c35c: LeaveFrame
    //     0xb1c35c: mov             SP, fp
    //     0xb1c360: ldp             fp, lr, [SP], #0x10
    // 0xb1c364: ret
    //     0xb1c364: ret             
    // 0xb1c368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c368: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c36c: b               #0xb1c31c
  }
  static _ getIntrinsicDimension(/* No info */) {
    // ** addr: 0xb1c370, size: 0x2d8
    // 0xb1c370: EnterFrame
    //     0xb1c370: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c374: mov             fp, SP
    // 0xb1c378: AllocStack(0x30)
    //     0xb1c378: sub             SP, SP, #0x30
    // 0xb1c37c: SetupParameters(dynamic _ /* r2 => r3, fp-0x20 */)
    //     0xb1c37c: mov             x3, x2
    //     0xb1c380: stur            x2, [fp, #-0x20]
    // 0xb1c384: CheckStackOverflow
    //     0xb1c384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c388: cmp             SP, x16
    //     0xb1c38c: b.ls            #0xb1c624
    // 0xb1c390: mov             x4, x1
    // 0xb1c394: r5 = 0.000000
    //     0xb1c394: ldr             x5, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb1c398: stur            x5, [fp, #-0x10]
    // 0xb1c39c: stur            x4, [fp, #-0x18]
    // 0xb1c3a0: CheckStackOverflow
    //     0xb1c3a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c3a4: cmp             SP, x16
    //     0xb1c3a8: b.ls            #0xb1c62c
    // 0xb1c3ac: cmp             w4, NULL
    // 0xb1c3b0: b.eq            #0xb1c610
    // 0xb1c3b4: LoadField: r6 = r4->field_7
    //     0xb1c3b4: ldur            w6, [x4, #7]
    // 0xb1c3b8: DecompressPointer r6
    //     0xb1c3b8: add             x6, x6, HEAP, lsl #32
    // 0xb1c3bc: stur            x6, [fp, #-8]
    // 0xb1c3c0: cmp             w6, NULL
    // 0xb1c3c4: b.eq            #0xb1c634
    // 0xb1c3c8: mov             x0, x6
    // 0xb1c3cc: r2 = Null
    //     0xb1c3cc: mov             x2, NULL
    // 0xb1c3d0: r1 = Null
    //     0xb1c3d0: mov             x1, NULL
    // 0xb1c3d4: r4 = LoadClassIdInstr(r0)
    //     0xb1c3d4: ldur            x4, [x0, #-1]
    //     0xb1c3d8: ubfx            x4, x4, #0xc, #0x14
    // 0xb1c3dc: r17 = -4208
    //     0xb1c3dc: mov             x17, #-0x1070
    // 0xb1c3e0: add             x4, x4, x17
    // 0xb1c3e4: cmp             x4, #2
    // 0xb1c3e8: b.ls            #0xb1c400
    // 0xb1c3ec: r8 = StackParentData
    //     0xb1c3ec: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0xb1c3f0: ldr             x8, [x8, #0xaa8]
    // 0xb1c3f4: r3 = Null
    //     0xb1c3f4: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a190] Null
    //     0xb1c3f8: ldr             x3, [x3, #0x190]
    // 0xb1c3fc: r0 = DefaultTypeTest()
    //     0xb1c3fc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb1c400: ldur            x1, [fp, #-8]
    // 0xb1c404: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xb1c404: ldur            w0, [x1, #0x17]
    // 0xb1c408: DecompressPointer r0
    //     0xb1c408: add             x0, x0, HEAP, lsl #32
    // 0xb1c40c: cmp             w0, NULL
    // 0xb1c410: b.ne            #0xb1c5f8
    // 0xb1c414: LoadField: r0 = r1->field_1b
    //     0xb1c414: ldur            w0, [x1, #0x1b]
    // 0xb1c418: DecompressPointer r0
    //     0xb1c418: add             x0, x0, HEAP, lsl #32
    // 0xb1c41c: cmp             w0, NULL
    // 0xb1c420: b.ne            #0xb1c5f8
    // 0xb1c424: LoadField: r0 = r1->field_1f
    //     0xb1c424: ldur            w0, [x1, #0x1f]
    // 0xb1c428: DecompressPointer r0
    //     0xb1c428: add             x0, x0, HEAP, lsl #32
    // 0xb1c42c: cmp             w0, NULL
    // 0xb1c430: b.ne            #0xb1c5f8
    // 0xb1c434: LoadField: r0 = r1->field_23
    //     0xb1c434: ldur            w0, [x1, #0x23]
    // 0xb1c438: DecompressPointer r0
    //     0xb1c438: add             x0, x0, HEAP, lsl #32
    // 0xb1c43c: cmp             w0, NULL
    // 0xb1c440: b.ne            #0xb1c5f8
    // 0xb1c444: LoadField: r0 = r1->field_27
    //     0xb1c444: ldur            w0, [x1, #0x27]
    // 0xb1c448: DecompressPointer r0
    //     0xb1c448: add             x0, x0, HEAP, lsl #32
    // 0xb1c44c: cmp             w0, NULL
    // 0xb1c450: b.ne            #0xb1c5f8
    // 0xb1c454: LoadField: r0 = r1->field_2b
    //     0xb1c454: ldur            w0, [x1, #0x2b]
    // 0xb1c458: DecompressPointer r0
    //     0xb1c458: add             x0, x0, HEAP, lsl #32
    // 0xb1c45c: cmp             w0, NULL
    // 0xb1c460: b.ne            #0xb1c5f8
    // 0xb1c464: ldur            x2, [fp, #-0x10]
    // 0xb1c468: ldur            x16, [fp, #-0x20]
    // 0xb1c46c: ldur            lr, [fp, #-0x18]
    // 0xb1c470: stp             lr, x16, [SP]
    // 0xb1c474: ldur            x0, [fp, #-0x20]
    // 0xb1c478: ClosureCall
    //     0xb1c478: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb1c47c: ldur            x2, [x0, #0x1f]
    //     0xb1c480: blr             x2
    // 0xb1c484: mov             x2, x0
    // 0xb1c488: ldur            x1, [fp, #-0x10]
    // 0xb1c48c: stur            x2, [fp, #-0x18]
    // 0xb1c490: r0 = 60
    //     0xb1c490: mov             x0, #0x3c
    // 0xb1c494: branchIfSmi(r1, 0xb1c4a0)
    //     0xb1c494: tbz             w1, #0, #0xb1c4a0
    // 0xb1c498: r0 = LoadClassIdInstr(r1)
    //     0xb1c498: ldur            x0, [x1, #-1]
    //     0xb1c49c: ubfx            x0, x0, #0xc, #0x14
    // 0xb1c4a0: stp             x2, x1, [SP]
    // 0xb1c4a4: r0 = GDT[cid_x0 + -0xfe5]()
    //     0xb1c4a4: sub             lr, x0, #0xfe5
    //     0xb1c4a8: ldr             lr, [x21, lr, lsl #3]
    //     0xb1c4ac: blr             lr
    // 0xb1c4b0: tbnz            w0, #4, #0xb1c4bc
    // 0xb1c4b4: ldur            x0, [fp, #-0x10]
    // 0xb1c4b8: b               #0xb1c5f0
    // 0xb1c4bc: ldur            x1, [fp, #-0x10]
    // 0xb1c4c0: r0 = 60
    //     0xb1c4c0: mov             x0, #0x3c
    // 0xb1c4c4: branchIfSmi(r1, 0xb1c4d0)
    //     0xb1c4c4: tbz             w1, #0, #0xb1c4d0
    // 0xb1c4c8: r0 = LoadClassIdInstr(r1)
    //     0xb1c4c8: ldur            x0, [x1, #-1]
    //     0xb1c4cc: ubfx            x0, x0, #0xc, #0x14
    // 0xb1c4d0: ldur            x16, [fp, #-0x18]
    // 0xb1c4d4: stp             x16, x1, [SP]
    // 0xb1c4d8: r0 = GDT[cid_x0 + -0xfe8]()
    //     0xb1c4d8: sub             lr, x0, #0xfe8
    //     0xb1c4dc: ldr             lr, [x21, lr, lsl #3]
    //     0xb1c4e0: blr             lr
    // 0xb1c4e4: tbnz            w0, #4, #0xb1c4f0
    // 0xb1c4e8: ldur            x0, [fp, #-0x18]
    // 0xb1c4ec: b               #0xb1c5f0
    // 0xb1c4f0: ldur            x1, [fp, #-0x18]
    // 0xb1c4f4: r0 = 60
    //     0xb1c4f4: mov             x0, #0x3c
    // 0xb1c4f8: branchIfSmi(r1, 0xb1c504)
    //     0xb1c4f8: tbz             w1, #0, #0xb1c504
    // 0xb1c4fc: r0 = LoadClassIdInstr(r1)
    //     0xb1c4fc: ldur            x0, [x1, #-1]
    //     0xb1c500: ubfx            x0, x0, #0xc, #0x14
    // 0xb1c504: cmp             x0, #0x3e
    // 0xb1c508: b.ne            #0xb1c590
    // 0xb1c50c: ldur            x2, [fp, #-0x10]
    // 0xb1c510: r0 = 60
    //     0xb1c510: mov             x0, #0x3c
    // 0xb1c514: branchIfSmi(r2, 0xb1c520)
    //     0xb1c514: tbz             w2, #0, #0xb1c520
    // 0xb1c518: r0 = LoadClassIdInstr(r2)
    //     0xb1c518: ldur            x0, [x2, #-1]
    //     0xb1c51c: ubfx            x0, x0, #0xc, #0x14
    // 0xb1c520: cmp             x0, #0x3e
    // 0xb1c524: b.ne            #0xb1c570
    // 0xb1c528: d0 = 0.000000
    //     0xb1c528: eor             v0.16b, v0.16b, v0.16b
    // 0xb1c52c: LoadField: d1 = r2->field_7
    //     0xb1c52c: ldur            d1, [x2, #7]
    // 0xb1c530: fcmp            d1, d0
    // 0xb1c534: b.ne            #0xb1c574
    // 0xb1c538: LoadField: d2 = r1->field_7
    //     0xb1c538: ldur            d2, [x1, #7]
    // 0xb1c53c: fadd            d3, d1, d2
    // 0xb1c540: r0 = inline_Allocate_Double()
    //     0xb1c540: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1c544: add             x0, x0, #0x10
    //     0xb1c548: cmp             x1, x0
    //     0xb1c54c: b.ls            #0xb1c638
    //     0xb1c550: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1c554: sub             x0, x0, #0xf
    //     0xb1c558: mov             x1, #0xe19c
    //     0xb1c55c: movk            x1, #3, lsl #16
    //     0xb1c560: stur            x1, [x0, #-1]
    // 0xb1c564: dmb             ishst
    // 0xb1c568: StoreField: r0->field_7 = d3
    //     0xb1c568: stur            d3, [x0, #7]
    // 0xb1c56c: b               #0xb1c5f0
    // 0xb1c570: d0 = 0.000000
    //     0xb1c570: eor             v0.16b, v0.16b, v0.16b
    // 0xb1c574: LoadField: d1 = r1->field_7
    //     0xb1c574: ldur            d1, [x1, #7]
    // 0xb1c578: fcmp            d1, d1
    // 0xb1c57c: b.vc            #0xb1c588
    // 0xb1c580: mov             x0, x1
    // 0xb1c584: b               #0xb1c5f0
    // 0xb1c588: mov             x0, x2
    // 0xb1c58c: b               #0xb1c5f0
    // 0xb1c590: ldur            x2, [fp, #-0x10]
    // 0xb1c594: d0 = 0.000000
    //     0xb1c594: eor             v0.16b, v0.16b, v0.16b
    // 0xb1c598: r0 = 60
    //     0xb1c598: mov             x0, #0x3c
    // 0xb1c59c: branchIfSmi(r1, 0xb1c5a8)
    //     0xb1c59c: tbz             w1, #0, #0xb1c5a8
    // 0xb1c5a0: r0 = LoadClassIdInstr(r1)
    //     0xb1c5a0: ldur            x0, [x1, #-1]
    //     0xb1c5a4: ubfx            x0, x0, #0xc, #0x14
    // 0xb1c5a8: stp             xzr, x1, [SP]
    // 0xb1c5ac: mov             lr, x0
    // 0xb1c5b0: ldr             lr, [x21, lr, lsl #3]
    // 0xb1c5b4: blr             lr
    // 0xb1c5b8: tbnz            w0, #4, #0xb1c5ec
    // 0xb1c5bc: ldur            x1, [fp, #-0x10]
    // 0xb1c5c0: r0 = 60
    //     0xb1c5c0: mov             x0, #0x3c
    // 0xb1c5c4: branchIfSmi(r1, 0xb1c5d0)
    //     0xb1c5c4: tbz             w1, #0, #0xb1c5d0
    // 0xb1c5c8: r0 = LoadClassIdInstr(r1)
    //     0xb1c5c8: ldur            x0, [x1, #-1]
    //     0xb1c5cc: ubfx            x0, x0, #0xc, #0x14
    // 0xb1c5d0: str             x1, [SP]
    // 0xb1c5d4: r0 = GDT[cid_x0 + -0xfca]()
    //     0xb1c5d4: sub             lr, x0, #0xfca
    //     0xb1c5d8: ldr             lr, [x21, lr, lsl #3]
    //     0xb1c5dc: blr             lr
    // 0xb1c5e0: tbnz            w0, #4, #0xb1c5ec
    // 0xb1c5e4: ldur            x0, [fp, #-0x18]
    // 0xb1c5e8: b               #0xb1c5f0
    // 0xb1c5ec: ldur            x0, [fp, #-0x10]
    // 0xb1c5f0: mov             x5, x0
    // 0xb1c5f4: b               #0xb1c5fc
    // 0xb1c5f8: ldur            x5, [fp, #-0x10]
    // 0xb1c5fc: ldur            x0, [fp, #-8]
    // 0xb1c600: LoadField: r4 = r0->field_13
    //     0xb1c600: ldur            w4, [x0, #0x13]
    // 0xb1c604: DecompressPointer r4
    //     0xb1c604: add             x4, x4, HEAP, lsl #32
    // 0xb1c608: ldur            x3, [fp, #-0x20]
    // 0xb1c60c: b               #0xb1c398
    // 0xb1c610: mov             x0, x5
    // 0xb1c614: LoadField: d0 = r0->field_7
    //     0xb1c614: ldur            d0, [x0, #7]
    // 0xb1c618: LeaveFrame
    //     0xb1c618: mov             SP, fp
    //     0xb1c61c: ldp             fp, lr, [SP], #0x10
    // 0xb1c620: ret
    //     0xb1c620: ret             
    // 0xb1c624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c624: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c628: b               #0xb1c390
    // 0xb1c62c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c62c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c630: b               #0xb1c3ac
    // 0xb1c634: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1c634: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1c638: stp             q0, q3, [SP, #-0x20]!
    // 0xb1c63c: r0 = AllocateDouble()
    //     0xb1c63c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1c640: ldp             q0, q3, [SP], #0x20
    // 0xb1c644: b               #0xb1c568
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb1c648, size: 0x78
    // 0xb1c648: EnterFrame
    //     0xb1c648: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c64c: mov             fp, SP
    // 0xb1c650: ldr             x0, [fp, #0x18]
    // 0xb1c654: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1c654: ldur            w1, [x0, #0x17]
    // 0xb1c658: DecompressPointer r1
    //     0xb1c658: add             x1, x1, HEAP, lsl #32
    // 0xb1c65c: CheckStackOverflow
    //     0xb1c65c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c660: cmp             SP, x16
    //     0xb1c664: b.ls            #0xb1c6a8
    // 0xb1c668: ldr             x2, [fp, #0x10]
    // 0xb1c66c: r0 = computeMinIntrinsicWidth()
    //     0xb1c66c: bl              #0xb1c2fc  ; [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicWidth
    // 0xb1c670: r0 = inline_Allocate_Double()
    //     0xb1c670: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1c674: add             x0, x0, #0x10
    //     0xb1c678: cmp             x1, x0
    //     0xb1c67c: b.ls            #0xb1c6b0
    //     0xb1c680: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1c684: sub             x0, x0, #0xf
    //     0xb1c688: mov             x1, #0xe19c
    //     0xb1c68c: movk            x1, #3, lsl #16
    //     0xb1c690: stur            x1, [x0, #-1]
    // 0xb1c694: dmb             ishst
    // 0xb1c698: StoreField: r0->field_7 = d0
    //     0xb1c698: stur            d0, [x0, #7]
    // 0xb1c69c: LeaveFrame
    //     0xb1c69c: mov             SP, fp
    //     0xb1c6a0: ldp             fp, lr, [SP], #0x10
    // 0xb1c6a4: ret
    //     0xb1c6a4: ret             
    // 0xb1c6a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c6a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c6ac: b               #0xb1c668
    // 0xb1c6b0: SaveReg d0
    //     0xb1c6b0: str             q0, [SP, #-0x10]!
    // 0xb1c6b4: r0 = AllocateDouble()
    //     0xb1c6b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1c6b8: RestoreReg d0
    //     0xb1c6b8: ldr             q0, [SP], #0x10
    // 0xb1c6bc: b               #0xb1c698
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb2005c, size: 0x24
    // 0xb2005c: EnterFrame
    //     0xb2005c: stp             fp, lr, [SP, #-0x10]!
    //     0xb20060: mov             fp, SP
    // 0xb20064: ldr             x2, [fp, #0x10]
    // 0xb20068: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb20068: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa41f8] AnonymousClosure: (0xb1c648), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicWidth (0xb1c2fc)
    //     0xb2006c: ldr             x1, [x1, #0x1f8]
    // 0xb20070: r0 = AllocateClosure()
    //     0xb20070: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb20074: LeaveFrame
    //     0xb20074: mov             SP, fp
    //     0xb20078: ldp             fp, lr, [SP], #0x10
    // 0xb2007c: ret
    //     0xb2007c: ret             
  }
  [closure] double <anonymous closure>(dynamic, RenderBox) {
    // ** addr: 0xb24f70, size: 0x84
    // 0xb24f70: EnterFrame
    //     0xb24f70: stp             fp, lr, [SP, #-0x10]!
    //     0xb24f74: mov             fp, SP
    // 0xb24f78: ldr             x0, [fp, #0x18]
    // 0xb24f7c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb24f7c: ldur            w1, [x0, #0x17]
    // 0xb24f80: DecompressPointer r1
    //     0xb24f80: add             x1, x1, HEAP, lsl #32
    // 0xb24f84: CheckStackOverflow
    //     0xb24f84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb24f88: cmp             SP, x16
    //     0xb24f8c: b.ls            #0xb24fdc
    // 0xb24f90: LoadField: r0 = r1->field_f
    //     0xb24f90: ldur            w0, [x1, #0xf]
    // 0xb24f94: DecompressPointer r0
    //     0xb24f94: add             x0, x0, HEAP, lsl #32
    // 0xb24f98: LoadField: d0 = r0->field_7
    //     0xb24f98: ldur            d0, [x0, #7]
    // 0xb24f9c: ldr             x1, [fp, #0x10]
    // 0xb24fa0: r0 = getMinIntrinsicHeight()
    //     0xb24fa0: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb24fa4: r0 = inline_Allocate_Double()
    //     0xb24fa4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb24fa8: add             x0, x0, #0x10
    //     0xb24fac: cmp             x1, x0
    //     0xb24fb0: b.ls            #0xb24fe4
    //     0xb24fb4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb24fb8: sub             x0, x0, #0xf
    //     0xb24fbc: mov             x1, #0xe19c
    //     0xb24fc0: movk            x1, #3, lsl #16
    //     0xb24fc4: stur            x1, [x0, #-1]
    // 0xb24fc8: dmb             ishst
    // 0xb24fcc: StoreField: r0->field_7 = d0
    //     0xb24fcc: stur            d0, [x0, #7]
    // 0xb24fd0: LeaveFrame
    //     0xb24fd0: mov             SP, fp
    //     0xb24fd4: ldp             fp, lr, [SP], #0x10
    // 0xb24fd8: ret
    //     0xb24fd8: ret             
    // 0xb24fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24fdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24fe0: b               #0xb24f90
    // 0xb24fe4: SaveReg d0
    //     0xb24fe4: str             q0, [SP, #-0x10]!
    // 0xb24fe8: r0 = AllocateDouble()
    //     0xb24fe8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb24fec: RestoreReg d0
    //     0xb24fec: ldr             q0, [SP], #0x10
    // 0xb24ff0: b               #0xb24fcc
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb24ff4, size: 0x78
    // 0xb24ff4: EnterFrame
    //     0xb24ff4: stp             fp, lr, [SP, #-0x10]!
    //     0xb24ff8: mov             fp, SP
    // 0xb24ffc: ldr             x0, [fp, #0x18]
    // 0xb25000: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb25000: ldur            w1, [x0, #0x17]
    // 0xb25004: DecompressPointer r1
    //     0xb25004: add             x1, x1, HEAP, lsl #32
    // 0xb25008: CheckStackOverflow
    //     0xb25008: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2500c: cmp             SP, x16
    //     0xb25010: b.ls            #0xb25054
    // 0xb25014: ldr             x2, [fp, #0x10]
    // 0xb25018: r0 = computeMinIntrinsicHeight()
    //     0xb25018: bl              #0xb25618  ; [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicHeight
    // 0xb2501c: r0 = inline_Allocate_Double()
    //     0xb2501c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb25020: add             x0, x0, #0x10
    //     0xb25024: cmp             x1, x0
    //     0xb25028: b.ls            #0xb2505c
    //     0xb2502c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb25030: sub             x0, x0, #0xf
    //     0xb25034: mov             x1, #0xe19c
    //     0xb25038: movk            x1, #3, lsl #16
    //     0xb2503c: stur            x1, [x0, #-1]
    // 0xb25040: dmb             ishst
    // 0xb25044: StoreField: r0->field_7 = d0
    //     0xb25044: stur            d0, [x0, #7]
    // 0xb25048: LeaveFrame
    //     0xb25048: mov             SP, fp
    //     0xb2504c: ldp             fp, lr, [SP], #0x10
    // 0xb25050: ret
    //     0xb25050: ret             
    // 0xb25054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb25054: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb25058: b               #0xb25014
    // 0xb2505c: SaveReg d0
    //     0xb2505c: str             q0, [SP, #-0x10]!
    // 0xb25060: r0 = AllocateDouble()
    //     0xb25060: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb25064: RestoreReg d0
    //     0xb25064: ldr             q0, [SP], #0x10
    // 0xb25068: b               #0xb25044
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb25618, size: 0x74
    // 0xb25618: EnterFrame
    //     0xb25618: stp             fp, lr, [SP, #-0x10]!
    //     0xb2561c: mov             fp, SP
    // 0xb25620: AllocStack(0x10)
    //     0xb25620: sub             SP, SP, #0x10
    // 0xb25624: SetupParameters(RenderStack this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb25624: stur            x1, [fp, #-8]
    //     0xb25628: stur            x2, [fp, #-0x10]
    // 0xb2562c: CheckStackOverflow
    //     0xb2562c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb25630: cmp             SP, x16
    //     0xb25634: b.ls            #0xb25684
    // 0xb25638: r1 = 1
    //     0xb25638: mov             x1, #1
    // 0xb2563c: r0 = AllocateContext()
    //     0xb2563c: bl              #0x13de838  ; AllocateContextStub
    // 0xb25640: mov             x1, x0
    // 0xb25644: ldur            x0, [fp, #-0x10]
    // 0xb25648: StoreField: r1->field_f = r0
    //     0xb25648: stur            w0, [x1, #0xf]
    // 0xb2564c: ldur            x0, [fp, #-8]
    // 0xb25650: LoadField: r3 = r0->field_57
    //     0xb25650: ldur            w3, [x0, #0x57]
    // 0xb25654: DecompressPointer r3
    //     0xb25654: add             x3, x3, HEAP, lsl #32
    // 0xb25658: mov             x2, x1
    // 0xb2565c: stur            x3, [fp, #-0x10]
    // 0xb25660: r1 = Function '<anonymous closure>':.
    //     0xb25660: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa41e0] AnonymousClosure: (0xb24f70), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicHeight (0xb25618)
    //     0xb25664: ldr             x1, [x1, #0x1e0]
    // 0xb25668: r0 = AllocateClosure()
    //     0xb25668: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2566c: ldur            x1, [fp, #-0x10]
    // 0xb25670: mov             x2, x0
    // 0xb25674: r0 = getIntrinsicDimension()
    //     0xb25674: bl              #0xb1c370  ; [package:flutter/src/rendering/stack.dart] RenderStack::getIntrinsicDimension
    // 0xb25678: LeaveFrame
    //     0xb25678: mov             SP, fp
    //     0xb2567c: ldp             fp, lr, [SP], #0x10
    // 0xb25680: ret
    //     0xb25680: ret             
    // 0xb25684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb25684: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb25688: b               #0xb25638
  }
  [closure] double <anonymous closure>(dynamic, RenderBox) {
    // ** addr: 0xb2aca8, size: 0x84
    // 0xb2aca8: EnterFrame
    //     0xb2aca8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2acac: mov             fp, SP
    // 0xb2acb0: ldr             x0, [fp, #0x18]
    // 0xb2acb4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2acb4: ldur            w1, [x0, #0x17]
    // 0xb2acb8: DecompressPointer r1
    //     0xb2acb8: add             x1, x1, HEAP, lsl #32
    // 0xb2acbc: CheckStackOverflow
    //     0xb2acbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2acc0: cmp             SP, x16
    //     0xb2acc4: b.ls            #0xb2ad14
    // 0xb2acc8: LoadField: r0 = r1->field_f
    //     0xb2acc8: ldur            w0, [x1, #0xf]
    // 0xb2accc: DecompressPointer r0
    //     0xb2accc: add             x0, x0, HEAP, lsl #32
    // 0xb2acd0: LoadField: d0 = r0->field_7
    //     0xb2acd0: ldur            d0, [x0, #7]
    // 0xb2acd4: ldr             x1, [fp, #0x10]
    // 0xb2acd8: r0 = getMaxIntrinsicHeight()
    //     0xb2acd8: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2acdc: r0 = inline_Allocate_Double()
    //     0xb2acdc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2ace0: add             x0, x0, #0x10
    //     0xb2ace4: cmp             x1, x0
    //     0xb2ace8: b.ls            #0xb2ad1c
    //     0xb2acec: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2acf0: sub             x0, x0, #0xf
    //     0xb2acf4: mov             x1, #0xe19c
    //     0xb2acf8: movk            x1, #3, lsl #16
    //     0xb2acfc: stur            x1, [x0, #-1]
    // 0xb2ad00: dmb             ishst
    // 0xb2ad04: StoreField: r0->field_7 = d0
    //     0xb2ad04: stur            d0, [x0, #7]
    // 0xb2ad08: LeaveFrame
    //     0xb2ad08: mov             SP, fp
    //     0xb2ad0c: ldp             fp, lr, [SP], #0x10
    // 0xb2ad10: ret
    //     0xb2ad10: ret             
    // 0xb2ad14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ad14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ad18: b               #0xb2acc8
    // 0xb2ad1c: SaveReg d0
    //     0xb2ad1c: str             q0, [SP, #-0x10]!
    // 0xb2ad20: r0 = AllocateDouble()
    //     0xb2ad20: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2ad24: RestoreReg d0
    //     0xb2ad24: ldr             q0, [SP], #0x10
    // 0xb2ad28: b               #0xb2ad04
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2ad2c, size: 0x78
    // 0xb2ad2c: EnterFrame
    //     0xb2ad2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ad30: mov             fp, SP
    // 0xb2ad34: ldr             x0, [fp, #0x18]
    // 0xb2ad38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2ad38: ldur            w1, [x0, #0x17]
    // 0xb2ad3c: DecompressPointer r1
    //     0xb2ad3c: add             x1, x1, HEAP, lsl #32
    // 0xb2ad40: CheckStackOverflow
    //     0xb2ad40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ad44: cmp             SP, x16
    //     0xb2ad48: b.ls            #0xb2ad8c
    // 0xb2ad4c: ldr             x2, [fp, #0x10]
    // 0xb2ad50: r0 = computeMaxIntrinsicHeight()
    //     0xb2ad50: bl              #0xb2b898  ; [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicHeight
    // 0xb2ad54: r0 = inline_Allocate_Double()
    //     0xb2ad54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2ad58: add             x0, x0, #0x10
    //     0xb2ad5c: cmp             x1, x0
    //     0xb2ad60: b.ls            #0xb2ad94
    //     0xb2ad64: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2ad68: sub             x0, x0, #0xf
    //     0xb2ad6c: mov             x1, #0xe19c
    //     0xb2ad70: movk            x1, #3, lsl #16
    //     0xb2ad74: stur            x1, [x0, #-1]
    // 0xb2ad78: dmb             ishst
    // 0xb2ad7c: StoreField: r0->field_7 = d0
    //     0xb2ad7c: stur            d0, [x0, #7]
    // 0xb2ad80: LeaveFrame
    //     0xb2ad80: mov             SP, fp
    //     0xb2ad84: ldp             fp, lr, [SP], #0x10
    // 0xb2ad88: ret
    //     0xb2ad88: ret             
    // 0xb2ad8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ad8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ad90: b               #0xb2ad4c
    // 0xb2ad94: SaveReg d0
    //     0xb2ad94: str             q0, [SP, #-0x10]!
    // 0xb2ad98: r0 = AllocateDouble()
    //     0xb2ad98: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2ad9c: RestoreReg d0
    //     0xb2ad9c: ldr             q0, [SP], #0x10
    // 0xb2ada0: b               #0xb2ad7c
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2b898, size: 0x74
    // 0xb2b898: EnterFrame
    //     0xb2b898: stp             fp, lr, [SP, #-0x10]!
    //     0xb2b89c: mov             fp, SP
    // 0xb2b8a0: AllocStack(0x10)
    //     0xb2b8a0: sub             SP, SP, #0x10
    // 0xb2b8a4: SetupParameters(RenderStack this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2b8a4: stur            x1, [fp, #-8]
    //     0xb2b8a8: stur            x2, [fp, #-0x10]
    // 0xb2b8ac: CheckStackOverflow
    //     0xb2b8ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2b8b0: cmp             SP, x16
    //     0xb2b8b4: b.ls            #0xb2b904
    // 0xb2b8b8: r1 = 1
    //     0xb2b8b8: mov             x1, #1
    // 0xb2b8bc: r0 = AllocateContext()
    //     0xb2b8bc: bl              #0x13de838  ; AllocateContextStub
    // 0xb2b8c0: mov             x1, x0
    // 0xb2b8c4: ldur            x0, [fp, #-0x10]
    // 0xb2b8c8: StoreField: r1->field_f = r0
    //     0xb2b8c8: stur            w0, [x1, #0xf]
    // 0xb2b8cc: ldur            x0, [fp, #-8]
    // 0xb2b8d0: LoadField: r3 = r0->field_57
    //     0xb2b8d0: ldur            w3, [x0, #0x57]
    // 0xb2b8d4: DecompressPointer r3
    //     0xb2b8d4: add             x3, x3, HEAP, lsl #32
    // 0xb2b8d8: mov             x2, x1
    // 0xb2b8dc: stur            x3, [fp, #-0x10]
    // 0xb2b8e0: r1 = Function '<anonymous closure>':.
    //     0xb2b8e0: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a188] AnonymousClosure: (0xb2aca8), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicHeight (0xb2b898)
    //     0xb2b8e4: ldr             x1, [x1, #0x188]
    // 0xb2b8e8: r0 = AllocateClosure()
    //     0xb2b8e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2b8ec: ldur            x1, [fp, #-0x10]
    // 0xb2b8f0: mov             x2, x0
    // 0xb2b8f4: r0 = getIntrinsicDimension()
    //     0xb2b8f4: bl              #0xb1c370  ; [package:flutter/src/rendering/stack.dart] RenderStack::getIntrinsicDimension
    // 0xb2b8f8: LeaveFrame
    //     0xb2b8f8: mov             SP, fp
    //     0xb2b8fc: ldp             fp, lr, [SP], #0x10
    // 0xb2b900: ret
    //     0xb2b900: ret             
    // 0xb2b904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2b904: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2b908: b               #0xb2b8b8
  }
  [closure] double <anonymous closure>(dynamic, RenderBox) {
    // ** addr: 0xb2e370, size: 0x84
    // 0xb2e370: EnterFrame
    //     0xb2e370: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e374: mov             fp, SP
    // 0xb2e378: ldr             x0, [fp, #0x18]
    // 0xb2e37c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2e37c: ldur            w1, [x0, #0x17]
    // 0xb2e380: DecompressPointer r1
    //     0xb2e380: add             x1, x1, HEAP, lsl #32
    // 0xb2e384: CheckStackOverflow
    //     0xb2e384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e388: cmp             SP, x16
    //     0xb2e38c: b.ls            #0xb2e3dc
    // 0xb2e390: LoadField: r0 = r1->field_f
    //     0xb2e390: ldur            w0, [x1, #0xf]
    // 0xb2e394: DecompressPointer r0
    //     0xb2e394: add             x0, x0, HEAP, lsl #32
    // 0xb2e398: LoadField: d0 = r0->field_7
    //     0xb2e398: ldur            d0, [x0, #7]
    // 0xb2e39c: ldr             x1, [fp, #0x10]
    // 0xb2e3a0: r0 = getMaxIntrinsicWidth()
    //     0xb2e3a0: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2e3a4: r0 = inline_Allocate_Double()
    //     0xb2e3a4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2e3a8: add             x0, x0, #0x10
    //     0xb2e3ac: cmp             x1, x0
    //     0xb2e3b0: b.ls            #0xb2e3e4
    //     0xb2e3b4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2e3b8: sub             x0, x0, #0xf
    //     0xb2e3bc: mov             x1, #0xe19c
    //     0xb2e3c0: movk            x1, #3, lsl #16
    //     0xb2e3c4: stur            x1, [x0, #-1]
    // 0xb2e3c8: dmb             ishst
    // 0xb2e3cc: StoreField: r0->field_7 = d0
    //     0xb2e3cc: stur            d0, [x0, #7]
    // 0xb2e3d0: LeaveFrame
    //     0xb2e3d0: mov             SP, fp
    //     0xb2e3d4: ldp             fp, lr, [SP], #0x10
    // 0xb2e3d8: ret
    //     0xb2e3d8: ret             
    // 0xb2e3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e3dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e3e0: b               #0xb2e390
    // 0xb2e3e4: SaveReg d0
    //     0xb2e3e4: str             q0, [SP, #-0x10]!
    // 0xb2e3e8: r0 = AllocateDouble()
    //     0xb2e3e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2e3ec: RestoreReg d0
    //     0xb2e3ec: ldr             q0, [SP], #0x10
    // 0xb2e3f0: b               #0xb2e3cc
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2e3f4, size: 0x78
    // 0xb2e3f4: EnterFrame
    //     0xb2e3f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e3f8: mov             fp, SP
    // 0xb2e3fc: ldr             x0, [fp, #0x18]
    // 0xb2e400: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2e400: ldur            w1, [x0, #0x17]
    // 0xb2e404: DecompressPointer r1
    //     0xb2e404: add             x1, x1, HEAP, lsl #32
    // 0xb2e408: CheckStackOverflow
    //     0xb2e408: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e40c: cmp             SP, x16
    //     0xb2e410: b.ls            #0xb2e454
    // 0xb2e414: ldr             x2, [fp, #0x10]
    // 0xb2e418: r0 = computeMaxIntrinsicWidth()
    //     0xb2e418: bl              #0xb2ea1c  ; [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicWidth
    // 0xb2e41c: r0 = inline_Allocate_Double()
    //     0xb2e41c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2e420: add             x0, x0, #0x10
    //     0xb2e424: cmp             x1, x0
    //     0xb2e428: b.ls            #0xb2e45c
    //     0xb2e42c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2e430: sub             x0, x0, #0xf
    //     0xb2e434: mov             x1, #0xe19c
    //     0xb2e438: movk            x1, #3, lsl #16
    //     0xb2e43c: stur            x1, [x0, #-1]
    // 0xb2e440: dmb             ishst
    // 0xb2e444: StoreField: r0->field_7 = d0
    //     0xb2e444: stur            d0, [x0, #7]
    // 0xb2e448: LeaveFrame
    //     0xb2e448: mov             SP, fp
    //     0xb2e44c: ldp             fp, lr, [SP], #0x10
    // 0xb2e450: ret
    //     0xb2e450: ret             
    // 0xb2e454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e454: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e458: b               #0xb2e414
    // 0xb2e45c: SaveReg d0
    //     0xb2e45c: str             q0, [SP, #-0x10]!
    // 0xb2e460: r0 = AllocateDouble()
    //     0xb2e460: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2e464: RestoreReg d0
    //     0xb2e464: ldr             q0, [SP], #0x10
    // 0xb2e468: b               #0xb2e444
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2ea1c, size: 0x74
    // 0xb2ea1c: EnterFrame
    //     0xb2ea1c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ea20: mov             fp, SP
    // 0xb2ea24: AllocStack(0x10)
    //     0xb2ea24: sub             SP, SP, #0x10
    // 0xb2ea28: SetupParameters(RenderStack this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2ea28: stur            x1, [fp, #-8]
    //     0xb2ea2c: stur            x2, [fp, #-0x10]
    // 0xb2ea30: CheckStackOverflow
    //     0xb2ea30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ea34: cmp             SP, x16
    //     0xb2ea38: b.ls            #0xb2ea88
    // 0xb2ea3c: r1 = 1
    //     0xb2ea3c: mov             x1, #1
    // 0xb2ea40: r0 = AllocateContext()
    //     0xb2ea40: bl              #0x13de838  ; AllocateContextStub
    // 0xb2ea44: mov             x1, x0
    // 0xb2ea48: ldur            x0, [fp, #-0x10]
    // 0xb2ea4c: StoreField: r1->field_f = r0
    //     0xb2ea4c: stur            w0, [x1, #0xf]
    // 0xb2ea50: ldur            x0, [fp, #-8]
    // 0xb2ea54: LoadField: r3 = r0->field_57
    //     0xb2ea54: ldur            w3, [x0, #0x57]
    // 0xb2ea58: DecompressPointer r3
    //     0xb2ea58: add             x3, x3, HEAP, lsl #32
    // 0xb2ea5c: mov             x2, x1
    // 0xb2ea60: stur            x3, [fp, #-0x10]
    // 0xb2ea64: r1 = Function '<anonymous closure>':.
    //     0xb2ea64: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa41f0] AnonymousClosure: (0xb2e370), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicWidth (0xb2ea1c)
    //     0xb2ea68: ldr             x1, [x1, #0x1f0]
    // 0xb2ea6c: r0 = AllocateClosure()
    //     0xb2ea6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2ea70: ldur            x1, [fp, #-0x10]
    // 0xb2ea74: mov             x2, x0
    // 0xb2ea78: r0 = getIntrinsicDimension()
    //     0xb2ea78: bl              #0xb1c370  ; [package:flutter/src/rendering/stack.dart] RenderStack::getIntrinsicDimension
    // 0xb2ea7c: LeaveFrame
    //     0xb2ea7c: mov             SP, fp
    //     0xb2ea80: ldp             fp, lr, [SP], #0x10
    // 0xb2ea84: ret
    //     0xb2ea84: ret             
    // 0xb2ea88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ea88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ea8c: b               #0xb2ea3c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb52008, size: 0x34
    // 0xb52008: EnterFrame
    //     0xb52008: stp             fp, lr, [SP, #-0x10]!
    //     0xb5200c: mov             fp, SP
    // 0xb52010: CheckStackOverflow
    //     0xb52010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb52014: cmp             SP, x16
    //     0xb52018: b.ls            #0xb52034
    // 0xb5201c: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb5201c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb52020: ldr             x3, [x3, #0x700]
    // 0xb52024: r0 = _computeSize()
    //     0xb52024: bl              #0xb5203c  ; [package:flutter/src/rendering/stack.dart] RenderStack::_computeSize
    // 0xb52028: LeaveFrame
    //     0xb52028: mov             SP, fp
    //     0xb5202c: ldp             fp, lr, [SP], #0x10
    // 0xb52030: ret
    //     0xb52030: ret             
    // 0xb52034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb52034: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb52038: b               #0xb5201c
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0xb5203c, size: 0x334
    // 0xb5203c: EnterFrame
    //     0xb5203c: stp             fp, lr, [SP, #-0x10]!
    //     0xb52040: mov             fp, SP
    // 0xb52044: AllocStack(0x68)
    //     0xb52044: sub             SP, SP, #0x68
    // 0xb52048: SetupParameters(RenderStack this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xb52048: mov             x0, x3
    //     0xb5204c: stur            x3, [fp, #-0x18]
    //     0xb52050: mov             x3, x1
    //     0xb52054: stur            x2, [fp, #-8]
    //     0xb52058: stur            x1, [fp, #-0x10]
    // 0xb5205c: CheckStackOverflow
    //     0xb5205c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb52060: cmp             SP, x16
    //     0xb52064: b.ls            #0xb5235c
    // 0xb52068: LoadField: r1 = r3->field_4f
    //     0xb52068: ldur            x1, [x3, #0x4f]
    // 0xb5206c: cbnz            x1, #0xb520fc
    // 0xb52070: mov             x1, x2
    // 0xb52074: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb52074: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb52078: r0 = constrainWidth()
    //     0xb52078: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb5207c: ldur            x1, [fp, #-8]
    // 0xb52080: stur            d0, [fp, #-0x38]
    // 0xb52084: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb52084: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb52088: r0 = constrainHeight()
    //     0xb52088: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb5208c: stur            d0, [fp, #-0x40]
    // 0xb52090: r0 = Size()
    //     0xb52090: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb52094: ldur            d0, [fp, #-0x38]
    // 0xb52098: StoreField: r0->field_7 = d0
    //     0xb52098: stur            d0, [x0, #7]
    // 0xb5209c: ldur            d0, [fp, #-0x40]
    // 0xb520a0: StoreField: r0->field_f = d0
    //     0xb520a0: stur            d0, [x0, #0xf]
    // 0xb520a4: mov             x1, x0
    // 0xb520a8: r0 = isFinite()
    //     0xb520a8: bl              #0xb51fa8  ; [dart:ui] OffsetBase::isFinite
    // 0xb520ac: tbnz            w0, #4, #0xb520e8
    // 0xb520b0: ldur            x1, [fp, #-8]
    // 0xb520b4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb520b4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb520b8: r0 = constrainWidth()
    //     0xb520b8: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb520bc: ldur            x1, [fp, #-8]
    // 0xb520c0: stur            d0, [fp, #-0x38]
    // 0xb520c4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb520c4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb520c8: r0 = constrainHeight()
    //     0xb520c8: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb520cc: stur            d0, [fp, #-0x40]
    // 0xb520d0: r0 = Size()
    //     0xb520d0: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb520d4: ldur            d0, [fp, #-0x38]
    // 0xb520d8: StoreField: r0->field_7 = d0
    //     0xb520d8: stur            d0, [x0, #7]
    // 0xb520dc: ldur            d0, [fp, #-0x40]
    // 0xb520e0: StoreField: r0->field_f = d0
    //     0xb520e0: stur            d0, [x0, #0xf]
    // 0xb520e4: b               #0xb520f0
    // 0xb520e8: ldur            x1, [fp, #-8]
    // 0xb520ec: r0 = smallest()
    //     0xb520ec: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb520f0: LeaveFrame
    //     0xb520f0: mov             SP, fp
    //     0xb520f4: ldp             fp, lr, [SP], #0x10
    // 0xb520f8: ret
    //     0xb520f8: ret             
    // 0xb520fc: LoadField: d0 = r2->field_7
    //     0xb520fc: ldur            d0, [x2, #7]
    // 0xb52100: stur            d0, [fp, #-0x40]
    // 0xb52104: ArrayLoad: d1 = r2[0]  ; List_8
    //     0xb52104: ldur            d1, [x2, #0x17]
    // 0xb52108: stur            d1, [fp, #-0x38]
    // 0xb5210c: LoadField: r1 = r3->field_6f
    //     0xb5210c: ldur            w1, [x3, #0x6f]
    // 0xb52110: DecompressPointer r1
    //     0xb52110: add             x1, x1, HEAP, lsl #32
    // 0xb52114: LoadField: r4 = r1->field_7
    //     0xb52114: ldur            x4, [x1, #7]
    // 0xb52118: cmp             x4, #1
    // 0xb5211c: b.gt            #0xb5217c
    // 0xb52120: cmp             x4, #0
    // 0xb52124: b.gt            #0xb52138
    // 0xb52128: mov             x1, x2
    // 0xb5212c: r0 = loosen()
    //     0xb5212c: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xb52130: mov             x3, x0
    // 0xb52134: b               #0xb52180
    // 0xb52138: ldur            x1, [fp, #-8]
    // 0xb5213c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb5213c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb52140: r0 = constrainWidth()
    //     0xb52140: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb52144: ldur            x1, [fp, #-8]
    // 0xb52148: stur            d0, [fp, #-0x48]
    // 0xb5214c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb5214c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb52150: r0 = constrainHeight()
    //     0xb52150: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb52154: stur            d0, [fp, #-0x50]
    // 0xb52158: r0 = BoxConstraints()
    //     0xb52158: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb5215c: ldur            d0, [fp, #-0x48]
    // 0xb52160: StoreField: r0->field_7 = d0
    //     0xb52160: stur            d0, [x0, #7]
    // 0xb52164: StoreField: r0->field_f = d0
    //     0xb52164: stur            d0, [x0, #0xf]
    // 0xb52168: ldur            d0, [fp, #-0x50]
    // 0xb5216c: ArrayStore: r0[0] = d0  ; List_8
    //     0xb5216c: stur            d0, [x0, #0x17]
    // 0xb52170: StoreField: r0->field_1f = d0
    //     0xb52170: stur            d0, [x0, #0x1f]
    // 0xb52174: mov             x3, x0
    // 0xb52178: b               #0xb52180
    // 0xb5217c: ldur            x3, [fp, #-8]
    // 0xb52180: ldur            x0, [fp, #-0x10]
    // 0xb52184: stur            x3, [fp, #-0x30]
    // 0xb52188: LoadField: r1 = r0->field_57
    //     0xb52188: ldur            w1, [x0, #0x57]
    // 0xb5218c: DecompressPointer r1
    //     0xb5218c: add             x1, x1, HEAP, lsl #32
    // 0xb52190: ldur            d1, [fp, #-0x40]
    // 0xb52194: ldur            d0, [fp, #-0x38]
    // 0xb52198: mov             x4, x1
    // 0xb5219c: r5 = false
    //     0xb5219c: add             x5, NULL, #0x30  ; false
    // 0xb521a0: stur            x5, [fp, #-0x20]
    // 0xb521a4: stur            x4, [fp, #-0x28]
    // 0xb521a8: stur            d1, [fp, #-0x38]
    // 0xb521ac: stur            d0, [fp, #-0x40]
    // 0xb521b0: CheckStackOverflow
    //     0xb521b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb521b4: cmp             SP, x16
    //     0xb521b8: b.ls            #0xb52364
    // 0xb521bc: cmp             w4, NULL
    // 0xb521c0: b.eq            #0xb522f8
    // 0xb521c4: LoadField: r6 = r4->field_7
    //     0xb521c4: ldur            w6, [x4, #7]
    // 0xb521c8: DecompressPointer r6
    //     0xb521c8: add             x6, x6, HEAP, lsl #32
    // 0xb521cc: stur            x6, [fp, #-0x10]
    // 0xb521d0: cmp             w6, NULL
    // 0xb521d4: b.eq            #0xb5236c
    // 0xb521d8: mov             x0, x6
    // 0xb521dc: r2 = Null
    //     0xb521dc: mov             x2, NULL
    // 0xb521e0: r1 = Null
    //     0xb521e0: mov             x1, NULL
    // 0xb521e4: r4 = LoadClassIdInstr(r0)
    //     0xb521e4: ldur            x4, [x0, #-1]
    //     0xb521e8: ubfx            x4, x4, #0xc, #0x14
    // 0xb521ec: r17 = -4208
    //     0xb521ec: mov             x17, #-0x1070
    // 0xb521f0: add             x4, x4, x17
    // 0xb521f4: cmp             x4, #2
    // 0xb521f8: b.ls            #0xb52210
    // 0xb521fc: r8 = StackParentData
    //     0xb521fc: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0xb52200: ldr             x8, [x8, #0xaa8]
    // 0xb52204: r3 = Null
    //     0xb52204: add             x3, PP, #0x90, lsl #12  ; [pp+0x906f0] Null
    //     0xb52208: ldr             x3, [x3, #0x6f0]
    // 0xb5220c: r0 = DefaultTypeTest()
    //     0xb5220c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb52210: ldur            x1, [fp, #-0x10]
    // 0xb52214: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xb52214: ldur            w0, [x1, #0x17]
    // 0xb52218: DecompressPointer r0
    //     0xb52218: add             x0, x0, HEAP, lsl #32
    // 0xb5221c: cmp             w0, NULL
    // 0xb52220: b.ne            #0xb52264
    // 0xb52224: LoadField: r0 = r1->field_1b
    //     0xb52224: ldur            w0, [x1, #0x1b]
    // 0xb52228: DecompressPointer r0
    //     0xb52228: add             x0, x0, HEAP, lsl #32
    // 0xb5222c: cmp             w0, NULL
    // 0xb52230: b.ne            #0xb52264
    // 0xb52234: LoadField: r0 = r1->field_1f
    //     0xb52234: ldur            w0, [x1, #0x1f]
    // 0xb52238: DecompressPointer r0
    //     0xb52238: add             x0, x0, HEAP, lsl #32
    // 0xb5223c: cmp             w0, NULL
    // 0xb52240: b.ne            #0xb52264
    // 0xb52244: LoadField: r0 = r1->field_23
    //     0xb52244: ldur            w0, [x1, #0x23]
    // 0xb52248: DecompressPointer r0
    //     0xb52248: add             x0, x0, HEAP, lsl #32
    // 0xb5224c: cmp             w0, NULL
    // 0xb52250: b.ne            #0xb52264
    // 0xb52254: LoadField: r0 = r1->field_27
    //     0xb52254: ldur            w0, [x1, #0x27]
    // 0xb52258: DecompressPointer r0
    //     0xb52258: add             x0, x0, HEAP, lsl #32
    // 0xb5225c: cmp             w0, NULL
    // 0xb52260: b.eq            #0xb52270
    // 0xb52264: ldur            d1, [fp, #-0x38]
    // 0xb52268: ldur            d3, [fp, #-0x40]
    // 0xb5226c: b               #0xb522dc
    // 0xb52270: LoadField: r0 = r1->field_2b
    //     0xb52270: ldur            w0, [x1, #0x2b]
    // 0xb52274: DecompressPointer r0
    //     0xb52274: add             x0, x0, HEAP, lsl #32
    // 0xb52278: cmp             w0, NULL
    // 0xb5227c: b.ne            #0xb522d4
    // 0xb52280: ldur            d1, [fp, #-0x38]
    // 0xb52284: ldur            d0, [fp, #-0x40]
    // 0xb52288: ldur            x16, [fp, #-0x18]
    // 0xb5228c: ldur            lr, [fp, #-0x28]
    // 0xb52290: stp             lr, x16, [SP, #8]
    // 0xb52294: ldur            x16, [fp, #-0x30]
    // 0xb52298: str             x16, [SP]
    // 0xb5229c: ldur            x0, [fp, #-0x18]
    // 0xb522a0: ClosureCall
    //     0xb522a0: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb522a4: ldur            x2, [x0, #0x1f]
    //     0xb522a8: blr             x2
    // 0xb522ac: LoadField: d0 = r0->field_7
    //     0xb522ac: ldur            d0, [x0, #7]
    // 0xb522b0: ldur            d1, [fp, #-0x38]
    // 0xb522b4: fmax            v2.2d, v1.2d, v0.2d
    // 0xb522b8: LoadField: d0 = r0->field_f
    //     0xb522b8: ldur            d0, [x0, #0xf]
    // 0xb522bc: ldur            d3, [fp, #-0x40]
    // 0xb522c0: fmax            v4.2d, v3.2d, v0.2d
    // 0xb522c4: mov             v1.16b, v2.16b
    // 0xb522c8: mov             v0.16b, v4.16b
    // 0xb522cc: r5 = true
    //     0xb522cc: add             x5, NULL, #0x20  ; true
    // 0xb522d0: b               #0xb522e4
    // 0xb522d4: ldur            d1, [fp, #-0x38]
    // 0xb522d8: ldur            d3, [fp, #-0x40]
    // 0xb522dc: ldur            x5, [fp, #-0x20]
    // 0xb522e0: mov             v0.16b, v3.16b
    // 0xb522e4: ldur            x0, [fp, #-0x10]
    // 0xb522e8: LoadField: r4 = r0->field_13
    //     0xb522e8: ldur            w4, [x0, #0x13]
    // 0xb522ec: DecompressPointer r4
    //     0xb522ec: add             x4, x4, HEAP, lsl #32
    // 0xb522f0: ldur            x3, [fp, #-0x30]
    // 0xb522f4: b               #0xb521a0
    // 0xb522f8: mov             x0, x5
    // 0xb522fc: mov             v3.16b, v0.16b
    // 0xb52300: tbnz            w0, #4, #0xb5231c
    // 0xb52304: r0 = Size()
    //     0xb52304: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb52308: ldur            d0, [fp, #-0x38]
    // 0xb5230c: StoreField: r0->field_7 = d0
    //     0xb5230c: stur            d0, [x0, #7]
    // 0xb52310: ldur            d0, [fp, #-0x40]
    // 0xb52314: StoreField: r0->field_f = d0
    //     0xb52314: stur            d0, [x0, #0xf]
    // 0xb52318: b               #0xb52350
    // 0xb5231c: ldur            x1, [fp, #-8]
    // 0xb52320: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb52320: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb52324: r0 = constrainWidth()
    //     0xb52324: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb52328: ldur            x1, [fp, #-8]
    // 0xb5232c: stur            d0, [fp, #-0x38]
    // 0xb52330: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb52330: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb52334: r0 = constrainHeight()
    //     0xb52334: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb52338: stur            d0, [fp, #-0x40]
    // 0xb5233c: r0 = Size()
    //     0xb5233c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb52340: ldur            d0, [fp, #-0x38]
    // 0xb52344: StoreField: r0->field_7 = d0
    //     0xb52344: stur            d0, [x0, #7]
    // 0xb52348: ldur            d0, [fp, #-0x40]
    // 0xb5234c: StoreField: r0->field_f = d0
    //     0xb5234c: stur            d0, [x0, #0xf]
    // 0xb52350: LeaveFrame
    //     0xb52350: mov             SP, fp
    //     0xb52354: ldp             fp, lr, [SP], #0x10
    // 0xb52358: ret
    //     0xb52358: ret             
    // 0xb5235c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5235c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb52360: b               #0xb52068
    // 0xb52364: r0 = StackOverflowSharedWithFPURegs()
    //     0xb52364: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb52368: b               #0xb521bc
    // 0xb5236c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb5236c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb586c0, size: 0x24
    // 0xb586c0: EnterFrame
    //     0xb586c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb586c4: mov             fp, SP
    // 0xb586c8: ldr             x2, [fp, #0x10]
    // 0xb586cc: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb586cc: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa41e8] AnonymousClosure: (0xb2e3f4), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicWidth (0xb2ea1c)
    //     0xb586d0: ldr             x1, [x1, #0x1e8]
    // 0xb586d4: r0 = AllocateClosure()
    //     0xb586d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb586d8: LeaveFrame
    //     0xb586d8: mov             SP, fp
    //     0xb586dc: ldp             fp, lr, [SP], #0x10
    // 0xb586e0: ret
    //     0xb586e0: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5bda8, size: 0x2c
    // 0xb5bda8: EnterFrame
    //     0xb5bda8: stp             fp, lr, [SP, #-0x10]!
    //     0xb5bdac: mov             fp, SP
    // 0xb5bdb0: CheckStackOverflow
    //     0xb5bdb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5bdb4: cmp             SP, x16
    //     0xb5bdb8: b.ls            #0xb5bdcc
    // 0xb5bdbc: r0 = defaultComputeDistanceToHighestActualBaseline()
    //     0xb5bdbc: bl              #0xb5bdd4  ; [dart:mixin_deduplication] _MixinApplication451&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultComputeDistanceToHighestActualBaseline
    // 0xb5bdc0: LeaveFrame
    //     0xb5bdc0: mov             SP, fp
    //     0xb5bdc4: ldp             fp, lr, [SP], #0x10
    // 0xb5bdc8: ret
    //     0xb5bdc8: ret             
    // 0xb5bdcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5bdcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5bdd0: b               #0xb5bdbc
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e86c, size: 0x24
    // 0xb5e86c: EnterFrame
    //     0xb5e86c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e870: mov             fp, SP
    // 0xb5e874: ldr             x2, [fp, #0x10]
    // 0xb5e878: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e878: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a180] AnonymousClosure: (0xb2ad2c), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicHeight (0xb2b898)
    //     0xb5e87c: ldr             x1, [x1, #0x180]
    // 0xb5e880: r0 = AllocateClosure()
    //     0xb5e880: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e884: LeaveFrame
    //     0xb5e884: mov             SP, fp
    //     0xb5e888: ldp             fp, lr, [SP], #0x10
    // 0xb5e88c: ret
    //     0xb5e88c: ret             
  }
  static _ _baselineForChild(/* No info */) {
    // ** addr: 0xb649bc, size: 0x228
    // 0xb649bc: EnterFrame
    //     0xb649bc: stp             fp, lr, [SP, #-0x10]!
    //     0xb649c0: mov             fp, SP
    // 0xb649c4: AllocStack(0x38)
    //     0xb649c4: sub             SP, SP, #0x38
    // 0xb649c8: SetupParameters(dynamic _ /* r1 => r7, fp-0x10 */, dynamic _ /* r2 => r6, fp-0x18 */, dynamic _ /* r3 => r5, fp-0x20 */, dynamic _ /* r5 => r4, fp-0x28 */, dynamic _ /* r6 => r3, fp-0x30 */)
    //     0xb649c8: mov             x7, x1
    //     0xb649cc: mov             x4, x5
    //     0xb649d0: stur            x5, [fp, #-0x28]
    //     0xb649d4: mov             x5, x3
    //     0xb649d8: stur            x3, [fp, #-0x20]
    //     0xb649dc: mov             x3, x6
    //     0xb649e0: stur            x6, [fp, #-0x30]
    //     0xb649e4: mov             x6, x2
    //     0xb649e8: stur            x1, [fp, #-0x10]
    //     0xb649ec: stur            x2, [fp, #-0x18]
    // 0xb649f0: CheckStackOverflow
    //     0xb649f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb649f4: cmp             SP, x16
    //     0xb649f8: b.ls            #0xb64bc8
    // 0xb649fc: LoadField: r8 = r7->field_7
    //     0xb649fc: ldur            w8, [x7, #7]
    // 0xb64a00: DecompressPointer r8
    //     0xb64a00: add             x8, x8, HEAP, lsl #32
    // 0xb64a04: stur            x8, [fp, #-8]
    // 0xb64a08: cmp             w8, NULL
    // 0xb64a0c: b.eq            #0xb64bd0
    // 0xb64a10: mov             x0, x8
    // 0xb64a14: r2 = Null
    //     0xb64a14: mov             x2, NULL
    // 0xb64a18: r1 = Null
    //     0xb64a18: mov             x1, NULL
    // 0xb64a1c: r4 = LoadClassIdInstr(r0)
    //     0xb64a1c: ldur            x4, [x0, #-1]
    //     0xb64a20: ubfx            x4, x4, #0xc, #0x14
    // 0xb64a24: r17 = -4208
    //     0xb64a24: mov             x17, #-0x1070
    // 0xb64a28: add             x4, x4, x17
    // 0xb64a2c: cmp             x4, #2
    // 0xb64a30: b.ls            #0xb64a48
    // 0xb64a34: r8 = StackParentData
    //     0xb64a34: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0xb64a38: ldr             x8, [x8, #0xaa8]
    // 0xb64a3c: r3 = Null
    //     0xb64a3c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a1c0] Null
    //     0xb64a40: ldr             x3, [x3, #0x1c0]
    // 0xb64a44: r0 = DefaultTypeTest()
    //     0xb64a44: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb64a48: ldur            x0, [fp, #-8]
    // 0xb64a4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb64a4c: ldur            w1, [x0, #0x17]
    // 0xb64a50: DecompressPointer r1
    //     0xb64a50: add             x1, x1, HEAP, lsl #32
    // 0xb64a54: cmp             w1, NULL
    // 0xb64a58: b.ne            #0xb64aac
    // 0xb64a5c: LoadField: r1 = r0->field_1b
    //     0xb64a5c: ldur            w1, [x0, #0x1b]
    // 0xb64a60: DecompressPointer r1
    //     0xb64a60: add             x1, x1, HEAP, lsl #32
    // 0xb64a64: cmp             w1, NULL
    // 0xb64a68: b.ne            #0xb64aac
    // 0xb64a6c: LoadField: r1 = r0->field_1f
    //     0xb64a6c: ldur            w1, [x0, #0x1f]
    // 0xb64a70: DecompressPointer r1
    //     0xb64a70: add             x1, x1, HEAP, lsl #32
    // 0xb64a74: cmp             w1, NULL
    // 0xb64a78: b.ne            #0xb64aac
    // 0xb64a7c: LoadField: r1 = r0->field_23
    //     0xb64a7c: ldur            w1, [x0, #0x23]
    // 0xb64a80: DecompressPointer r1
    //     0xb64a80: add             x1, x1, HEAP, lsl #32
    // 0xb64a84: cmp             w1, NULL
    // 0xb64a88: b.ne            #0xb64aac
    // 0xb64a8c: LoadField: r1 = r0->field_27
    //     0xb64a8c: ldur            w1, [x0, #0x27]
    // 0xb64a90: DecompressPointer r1
    //     0xb64a90: add             x1, x1, HEAP, lsl #32
    // 0xb64a94: cmp             w1, NULL
    // 0xb64a98: b.ne            #0xb64aac
    // 0xb64a9c: LoadField: r1 = r0->field_2b
    //     0xb64a9c: ldur            w1, [x0, #0x2b]
    // 0xb64aa0: DecompressPointer r1
    //     0xb64aa0: add             x1, x1, HEAP, lsl #32
    // 0xb64aa4: cmp             w1, NULL
    // 0xb64aa8: b.eq            #0xb64abc
    // 0xb64aac: mov             x1, x0
    // 0xb64ab0: ldur            x2, [fp, #-0x18]
    // 0xb64ab4: r0 = positionedChildConstraints()
    //     0xb64ab4: bl              #0xb5f0b4  ; [package:flutter/src/rendering/stack.dart] StackParentData::positionedChildConstraints
    // 0xb64ab8: b               #0xb64ac0
    // 0xb64abc: ldur            x0, [fp, #-0x20]
    // 0xb64ac0: ldur            x1, [fp, #-0x10]
    // 0xb64ac4: mov             x2, x0
    // 0xb64ac8: ldur            x3, [fp, #-0x30]
    // 0xb64acc: stur            x0, [fp, #-0x20]
    // 0xb64ad0: r0 = getDryBaseline()
    //     0xb64ad0: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb64ad4: stur            x0, [fp, #-0x30]
    // 0xb64ad8: cmp             w0, NULL
    // 0xb64adc: b.ne            #0xb64af0
    // 0xb64ae0: r0 = Null
    //     0xb64ae0: mov             x0, NULL
    // 0xb64ae4: LeaveFrame
    //     0xb64ae4: mov             SP, fp
    //     0xb64ae8: ldp             fp, lr, [SP], #0x10
    // 0xb64aec: ret
    //     0xb64aec: ret             
    // 0xb64af0: ldur            x1, [fp, #-8]
    // 0xb64af4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb64af4: ldur            w2, [x1, #0x17]
    // 0xb64af8: DecompressPointer r2
    //     0xb64af8: add             x2, x2, HEAP, lsl #32
    // 0xb64afc: cmp             w2, NULL
    // 0xb64b00: b.eq            #0xb64b10
    // 0xb64b04: LoadField: d0 = r2->field_7
    //     0xb64b04: ldur            d0, [x2, #7]
    // 0xb64b08: mov             x1, x0
    // 0xb64b0c: b               #0xb64b88
    // 0xb64b10: LoadField: r2 = r1->field_1f
    //     0xb64b10: ldur            w2, [x1, #0x1f]
    // 0xb64b14: DecompressPointer r2
    //     0xb64b14: add             x2, x2, HEAP, lsl #32
    // 0xb64b18: cmp             w2, NULL
    // 0xb64b1c: b.eq            #0xb64b58
    // 0xb64b20: ldur            x3, [fp, #-0x18]
    // 0xb64b24: LoadField: d0 = r3->field_f
    //     0xb64b24: ldur            d0, [x3, #0xf]
    // 0xb64b28: LoadField: d1 = r2->field_7
    //     0xb64b28: ldur            d1, [x2, #7]
    // 0xb64b2c: fsub            d2, d0, d1
    // 0xb64b30: ldur            x1, [fp, #-0x10]
    // 0xb64b34: ldur            x2, [fp, #-0x20]
    // 0xb64b38: stur            d2, [fp, #-0x38]
    // 0xb64b3c: r0 = getDryLayout()
    //     0xb64b3c: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb64b40: LoadField: d0 = r0->field_f
    //     0xb64b40: ldur            d0, [x0, #0xf]
    // 0xb64b44: ldur            d1, [fp, #-0x38]
    // 0xb64b48: fsub            d2, d1, d0
    // 0xb64b4c: mov             v0.16b, v2.16b
    // 0xb64b50: ldur            x1, [fp, #-0x30]
    // 0xb64b54: b               #0xb64b88
    // 0xb64b58: ldur            x3, [fp, #-0x18]
    // 0xb64b5c: ldur            x1, [fp, #-0x10]
    // 0xb64b60: ldur            x2, [fp, #-0x20]
    // 0xb64b64: r0 = getDryLayout()
    //     0xb64b64: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb64b68: ldur            x1, [fp, #-0x18]
    // 0xb64b6c: mov             x2, x0
    // 0xb64b70: r0 = -()
    //     0xb64b70: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb64b74: ldur            x1, [fp, #-0x28]
    // 0xb64b78: mov             x2, x0
    // 0xb64b7c: r0 = alongOffset()
    //     0xb64b7c: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb64b80: LoadField: d0 = r0->field_f
    //     0xb64b80: ldur            d0, [x0, #0xf]
    // 0xb64b84: ldur            x1, [fp, #-0x30]
    // 0xb64b88: LoadField: d1 = r1->field_7
    //     0xb64b88: ldur            d1, [x1, #7]
    // 0xb64b8c: fadd            d2, d1, d0
    // 0xb64b90: r0 = inline_Allocate_Double()
    //     0xb64b90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb64b94: add             x0, x0, #0x10
    //     0xb64b98: cmp             x1, x0
    //     0xb64b9c: b.ls            #0xb64bd4
    //     0xb64ba0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb64ba4: sub             x0, x0, #0xf
    //     0xb64ba8: mov             x1, #0xe19c
    //     0xb64bac: movk            x1, #3, lsl #16
    //     0xb64bb0: stur            x1, [x0, #-1]
    // 0xb64bb4: dmb             ishst
    // 0xb64bb8: StoreField: r0->field_7 = d2
    //     0xb64bb8: stur            d2, [x0, #7]
    // 0xb64bbc: LeaveFrame
    //     0xb64bbc: mov             SP, fp
    //     0xb64bc0: ldp             fp, lr, [SP], #0x10
    // 0xb64bc4: ret
    //     0xb64bc4: ret             
    // 0xb64bc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb64bc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb64bcc: b               #0xb649fc
    // 0xb64bd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb64bd0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb64bd4: SaveReg d2
    //     0xb64bd4: str             q2, [SP, #-0x10]!
    // 0xb64bd8: r0 = AllocateDouble()
    //     0xb64bd8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb64bdc: RestoreReg d2
    //     0xb64bdc: ldr             q2, [SP], #0x10
    // 0xb64be0: b               #0xb64bb8
  }
  get _ _resolvedAlignment(/* No info */) {
    // ** addr: 0xb64be4, size: 0x17c
    // 0xb64be4: EnterFrame
    //     0xb64be4: stp             fp, lr, [SP, #-0x10]!
    //     0xb64be8: mov             fp, SP
    // 0xb64bec: AllocStack(0x18)
    //     0xb64bec: sub             SP, SP, #0x18
    // 0xb64bf0: SetupParameters(RenderStack this /* r1 => r1, fp-0x8 */)
    //     0xb64bf0: stur            x1, [fp, #-8]
    // 0xb64bf4: LoadField: r0 = r1->field_63
    //     0xb64bf4: ldur            w0, [x1, #0x63]
    // 0xb64bf8: DecompressPointer r0
    //     0xb64bf8: add             x0, x0, HEAP, lsl #32
    // 0xb64bfc: cmp             w0, NULL
    // 0xb64c00: b.ne            #0xb64d4c
    // 0xb64c04: LoadField: r0 = r1->field_67
    //     0xb64c04: ldur            w0, [x1, #0x67]
    // 0xb64c08: DecompressPointer r0
    //     0xb64c08: add             x0, x0, HEAP, lsl #32
    // 0xb64c0c: LoadField: r2 = r1->field_6b
    //     0xb64c0c: ldur            w2, [x1, #0x6b]
    // 0xb64c10: DecompressPointer r2
    //     0xb64c10: add             x2, x2, HEAP, lsl #32
    // 0xb64c14: r3 = LoadClassIdInstr(r0)
    //     0xb64c14: ldur            x3, [x0, #-1]
    //     0xb64c18: ubfx            x3, x3, #0xc, #0x14
    // 0xb64c1c: sub             x16, x3, #0xb8e
    // 0xb64c20: cmp             x16, #1
    // 0xb64c24: b.hi            #0xb64c30
    // 0xb64c28: mov             x2, x0
    // 0xb64c2c: b               #0xb64d28
    // 0xb64c30: cmp             x3, #0xb8c
    // 0xb64c34: b.ne            #0xb64cb4
    // 0xb64c38: cmp             w2, NULL
    // 0xb64c3c: b.eq            #0xb64d58
    // 0xb64c40: LoadField: r3 = r2->field_7
    //     0xb64c40: ldur            x3, [x2, #7]
    // 0xb64c44: cmp             x3, #0
    // 0xb64c48: b.gt            #0xb64c7c
    // 0xb64c4c: LoadField: d0 = r0->field_7
    //     0xb64c4c: ldur            d0, [x0, #7]
    // 0xb64c50: LoadField: d1 = r0->field_f
    //     0xb64c50: ldur            d1, [x0, #0xf]
    // 0xb64c54: fsub            d2, d0, d1
    // 0xb64c58: stur            d2, [fp, #-0x18]
    // 0xb64c5c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xb64c5c: ldur            d0, [x0, #0x17]
    // 0xb64c60: stur            d0, [fp, #-0x10]
    // 0xb64c64: r0 = Alignment()
    //     0xb64c64: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xb64c68: ldur            d0, [fp, #-0x18]
    // 0xb64c6c: StoreField: r0->field_7 = d0
    //     0xb64c6c: stur            d0, [x0, #7]
    // 0xb64c70: ldur            d0, [fp, #-0x10]
    // 0xb64c74: StoreField: r0->field_f = d0
    //     0xb64c74: stur            d0, [x0, #0xf]
    // 0xb64c78: b               #0xb64ca8
    // 0xb64c7c: LoadField: d0 = r0->field_7
    //     0xb64c7c: ldur            d0, [x0, #7]
    // 0xb64c80: LoadField: d1 = r0->field_f
    //     0xb64c80: ldur            d1, [x0, #0xf]
    // 0xb64c84: fadd            d2, d0, d1
    // 0xb64c88: stur            d2, [fp, #-0x18]
    // 0xb64c8c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xb64c8c: ldur            d0, [x0, #0x17]
    // 0xb64c90: stur            d0, [fp, #-0x10]
    // 0xb64c94: r0 = Alignment()
    //     0xb64c94: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xb64c98: ldur            d0, [fp, #-0x18]
    // 0xb64c9c: StoreField: r0->field_7 = d0
    //     0xb64c9c: stur            d0, [x0, #7]
    // 0xb64ca0: ldur            d0, [fp, #-0x10]
    // 0xb64ca4: StoreField: r0->field_f = d0
    //     0xb64ca4: stur            d0, [x0, #0xf]
    // 0xb64ca8: mov             x2, x0
    // 0xb64cac: ldur            x1, [fp, #-8]
    // 0xb64cb0: b               #0xb64d28
    // 0xb64cb4: cmp             w2, NULL
    // 0xb64cb8: b.eq            #0xb64d5c
    // 0xb64cbc: LoadField: r1 = r2->field_7
    //     0xb64cbc: ldur            x1, [x2, #7]
    // 0xb64cc0: cmp             x1, #0
    // 0xb64cc4: b.gt            #0xb64cf8
    // 0xb64cc8: LoadField: d0 = r0->field_7
    //     0xb64cc8: ldur            d0, [x0, #7]
    // 0xb64ccc: fneg            d1, d0
    // 0xb64cd0: stur            d1, [fp, #-0x18]
    // 0xb64cd4: LoadField: d0 = r0->field_f
    //     0xb64cd4: ldur            d0, [x0, #0xf]
    // 0xb64cd8: stur            d0, [fp, #-0x10]
    // 0xb64cdc: r0 = Alignment()
    //     0xb64cdc: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xb64ce0: ldur            d0, [fp, #-0x18]
    // 0xb64ce4: StoreField: r0->field_7 = d0
    //     0xb64ce4: stur            d0, [x0, #7]
    // 0xb64ce8: ldur            d0, [fp, #-0x10]
    // 0xb64cec: StoreField: r0->field_f = d0
    //     0xb64cec: stur            d0, [x0, #0xf]
    // 0xb64cf0: mov             x1, x0
    // 0xb64cf4: b               #0xb64d20
    // 0xb64cf8: LoadField: d0 = r0->field_7
    //     0xb64cf8: ldur            d0, [x0, #7]
    // 0xb64cfc: stur            d0, [fp, #-0x18]
    // 0xb64d00: LoadField: d1 = r0->field_f
    //     0xb64d00: ldur            d1, [x0, #0xf]
    // 0xb64d04: stur            d1, [fp, #-0x10]
    // 0xb64d08: r0 = Alignment()
    //     0xb64d08: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xb64d0c: ldur            d0, [fp, #-0x18]
    // 0xb64d10: StoreField: r0->field_7 = d0
    //     0xb64d10: stur            d0, [x0, #7]
    // 0xb64d14: ldur            d0, [fp, #-0x10]
    // 0xb64d18: StoreField: r0->field_f = d0
    //     0xb64d18: stur            d0, [x0, #0xf]
    // 0xb64d1c: mov             x1, x0
    // 0xb64d20: mov             x2, x1
    // 0xb64d24: ldur            x1, [fp, #-8]
    // 0xb64d28: mov             x0, x2
    // 0xb64d2c: StoreField: r1->field_63 = r0
    //     0xb64d2c: stur            w0, [x1, #0x63]
    //     0xb64d30: ldurb           w16, [x1, #-1]
    //     0xb64d34: ldurb           w17, [x0, #-1]
    //     0xb64d38: and             x16, x17, x16, lsr #2
    //     0xb64d3c: tst             x16, HEAP, lsr #32
    //     0xb64d40: b.eq            #0xb64d48
    //     0xb64d44: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb64d48: mov             x0, x2
    // 0xb64d4c: LeaveFrame
    //     0xb64d4c: mov             SP, fp
    //     0xb64d50: ldp             fp, lr, [SP], #0x10
    // 0xb64d54: ret
    //     0xb64d54: ret             
    // 0xb64d58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb64d58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb64d5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb64d5c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb64d60, size: 0x2d0
    // 0xb64d60: EnterFrame
    //     0xb64d60: stp             fp, lr, [SP, #-0x10]!
    //     0xb64d64: mov             fp, SP
    // 0xb64d68: AllocStack(0x50)
    //     0xb64d68: sub             SP, SP, #0x50
    // 0xb64d6c: SetupParameters(RenderStack this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r6, fp-0x18 */)
    //     0xb64d6c: mov             x4, x1
    //     0xb64d70: mov             x6, x3
    //     0xb64d74: stur            x3, [fp, #-0x18]
    //     0xb64d78: mov             x3, x2
    //     0xb64d7c: stur            x1, [fp, #-8]
    //     0xb64d80: stur            x2, [fp, #-0x10]
    // 0xb64d84: CheckStackOverflow
    //     0xb64d84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb64d88: cmp             SP, x16
    //     0xb64d8c: b.ls            #0xb65008
    // 0xb64d90: mov             x0, x3
    // 0xb64d94: r2 = Null
    //     0xb64d94: mov             x2, NULL
    // 0xb64d98: r1 = Null
    //     0xb64d98: mov             x1, NULL
    // 0xb64d9c: r4 = 60
    //     0xb64d9c: mov             x4, #0x3c
    // 0xb64da0: branchIfSmi(r0, 0xb64dac)
    //     0xb64da0: tbz             w0, #0, #0xb64dac
    // 0xb64da4: r4 = LoadClassIdInstr(r0)
    //     0xb64da4: ldur            x4, [x0, #-1]
    //     0xb64da8: ubfx            x4, x4, #0xc, #0x14
    // 0xb64dac: sub             x4, x4, #0xb46
    // 0xb64db0: cmp             x4, #1
    // 0xb64db4: b.ls            #0xb64dc8
    // 0xb64db8: r8 = BoxConstraints
    //     0xb64db8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb64dbc: r3 = Null
    //     0xb64dbc: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a1a0] Null
    //     0xb64dc0: ldr             x3, [x3, #0x1a0]
    // 0xb64dc4: r0 = BoxConstraints()
    //     0xb64dc4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb64dc8: ldur            x0, [fp, #-8]
    // 0xb64dcc: LoadField: r1 = r0->field_6f
    //     0xb64dcc: ldur            w1, [x0, #0x6f]
    // 0xb64dd0: DecompressPointer r1
    //     0xb64dd0: add             x1, x1, HEAP, lsl #32
    // 0xb64dd4: LoadField: r2 = r1->field_7
    //     0xb64dd4: ldur            x2, [x1, #7]
    // 0xb64dd8: cmp             x2, #1
    // 0xb64ddc: b.gt            #0xb64e3c
    // 0xb64de0: cmp             x2, #0
    // 0xb64de4: b.gt            #0xb64df8
    // 0xb64de8: ldur            x1, [fp, #-0x10]
    // 0xb64dec: r0 = loosen()
    //     0xb64dec: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xb64df0: mov             x3, x0
    // 0xb64df4: b               #0xb64e40
    // 0xb64df8: ldur            x1, [fp, #-0x10]
    // 0xb64dfc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb64dfc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb64e00: r0 = constrainWidth()
    //     0xb64e00: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb64e04: ldur            x1, [fp, #-0x10]
    // 0xb64e08: stur            d0, [fp, #-0x48]
    // 0xb64e0c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb64e0c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb64e10: r0 = constrainHeight()
    //     0xb64e10: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb64e14: stur            d0, [fp, #-0x50]
    // 0xb64e18: r0 = BoxConstraints()
    //     0xb64e18: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb64e1c: ldur            d0, [fp, #-0x48]
    // 0xb64e20: StoreField: r0->field_7 = d0
    //     0xb64e20: stur            d0, [x0, #7]
    // 0xb64e24: StoreField: r0->field_f = d0
    //     0xb64e24: stur            d0, [x0, #0xf]
    // 0xb64e28: ldur            d0, [fp, #-0x50]
    // 0xb64e2c: ArrayStore: r0[0] = d0  ; List_8
    //     0xb64e2c: stur            d0, [x0, #0x17]
    // 0xb64e30: StoreField: r0->field_1f = d0
    //     0xb64e30: stur            d0, [x0, #0x1f]
    // 0xb64e34: mov             x3, x0
    // 0xb64e38: b               #0xb64e40
    // 0xb64e3c: ldur            x3, [fp, #-0x10]
    // 0xb64e40: ldur            x0, [fp, #-8]
    // 0xb64e44: mov             x1, x0
    // 0xb64e48: stur            x3, [fp, #-0x20]
    // 0xb64e4c: r0 = _resolvedAlignment()
    //     0xb64e4c: bl              #0xb64be4  ; [package:flutter/src/rendering/stack.dart] RenderStack::_resolvedAlignment
    // 0xb64e50: ldur            x1, [fp, #-8]
    // 0xb64e54: ldur            x2, [fp, #-0x10]
    // 0xb64e58: stur            x0, [fp, #-0x10]
    // 0xb64e5c: r0 = getDryLayout()
    //     0xb64e5c: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb64e60: mov             x4, x0
    // 0xb64e64: ldur            x0, [fp, #-8]
    // 0xb64e68: stur            x4, [fp, #-0x30]
    // 0xb64e6c: LoadField: r1 = r0->field_57
    //     0xb64e6c: ldur            w1, [x0, #0x57]
    // 0xb64e70: DecompressPointer r1
    //     0xb64e70: add             x1, x1, HEAP, lsl #32
    // 0xb64e74: mov             x0, x1
    // 0xb64e78: r7 = Null
    //     0xb64e78: mov             x7, NULL
    // 0xb64e7c: stur            x7, [fp, #-8]
    // 0xb64e80: stur            x0, [fp, #-0x28]
    // 0xb64e84: CheckStackOverflow
    //     0xb64e84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb64e88: cmp             SP, x16
    //     0xb64e8c: b.ls            #0xb65010
    // 0xb64e90: cmp             w0, NULL
    // 0xb64e94: b.eq            #0xb64ff4
    // 0xb64e98: mov             x1, x0
    // 0xb64e9c: mov             x2, x4
    // 0xb64ea0: ldur            x3, [fp, #-0x20]
    // 0xb64ea4: ldur            x5, [fp, #-0x10]
    // 0xb64ea8: ldur            x6, [fp, #-0x18]
    // 0xb64eac: r0 = _baselineForChild()
    //     0xb64eac: bl              #0xb649bc  ; [package:flutter/src/rendering/stack.dart] RenderStack::_baselineForChild
    // 0xb64eb0: mov             x2, x0
    // 0xb64eb4: ldur            x1, [fp, #-8]
    // 0xb64eb8: cmp             w1, NULL
    // 0xb64ebc: b.eq            #0xb64f20
    // 0xb64ec0: cmp             w2, NULL
    // 0xb64ec4: b.eq            #0xb64f18
    // 0xb64ec8: LoadField: d0 = r1->field_7
    //     0xb64ec8: ldur            d0, [x1, #7]
    // 0xb64ecc: LoadField: d1 = r2->field_7
    //     0xb64ecc: ldur            d1, [x2, #7]
    // 0xb64ed0: fcmp            d0, d1
    // 0xb64ed4: b.lt            #0xb64ee0
    // 0xb64ed8: LoadField: d0 = r2->field_7
    //     0xb64ed8: ldur            d0, [x2, #7]
    // 0xb64edc: b               #0xb64ee4
    // 0xb64ee0: LoadField: d0 = r1->field_7
    //     0xb64ee0: ldur            d0, [x1, #7]
    // 0xb64ee4: r1 = inline_Allocate_Double()
    //     0xb64ee4: ldp             x1, x0, [THR, #0x60]  ; THR::top
    //     0xb64ee8: add             x1, x1, #0x10
    //     0xb64eec: cmp             x0, x1
    //     0xb64ef0: b.ls            #0xb65018
    //     0xb64ef4: str             x1, [THR, #0x60]  ; THR::top
    //     0xb64ef8: sub             x1, x1, #0xf
    //     0xb64efc: mov             x0, #0xe19c
    //     0xb64f00: movk            x0, #3, lsl #16
    //     0xb64f04: stur            x0, [x1, #-1]
    // 0xb64f08: dmb             ishst
    // 0xb64f0c: StoreField: r1->field_7 = d0
    //     0xb64f0c: stur            d0, [x1, #7]
    // 0xb64f10: mov             x7, x1
    // 0xb64f14: b               #0xb64f88
    // 0xb64f18: r3 = true
    //     0xb64f18: add             x3, NULL, #0x20  ; true
    // 0xb64f1c: b               #0xb64f24
    // 0xb64f20: r3 = false
    //     0xb64f20: add             x3, NULL, #0x30  ; false
    // 0xb64f24: cmp             w1, NULL
    // 0xb64f28: b.eq            #0xb64f5c
    // 0xb64f2c: tbnz            w3, #4, #0xb64f3c
    // 0xb64f30: r0 = Null
    //     0xb64f30: mov             x0, NULL
    // 0xb64f34: r3 = Null
    //     0xb64f34: mov             x3, NULL
    // 0xb64f38: b               #0xb64f44
    // 0xb64f3c: mov             x0, x2
    // 0xb64f40: mov             x3, x2
    // 0xb64f44: cmp             w0, NULL
    // 0xb64f48: b.ne            #0xb64f54
    // 0xb64f4c: mov             x7, x1
    // 0xb64f50: b               #0xb64f88
    // 0xb64f54: r0 = true
    //     0xb64f54: add             x0, NULL, #0x20  ; true
    // 0xb64f58: b               #0xb64f64
    // 0xb64f5c: mov             x0, x3
    // 0xb64f60: r3 = Null
    //     0xb64f60: mov             x3, NULL
    // 0xb64f64: cmp             w1, NULL
    // 0xb64f68: b.ne            #0xb64f84
    // 0xb64f6c: tbnz            w0, #4, #0xb64f78
    // 0xb64f70: mov             x1, x3
    // 0xb64f74: b               #0xb64f7c
    // 0xb64f78: mov             x1, x2
    // 0xb64f7c: mov             x7, x1
    // 0xb64f80: b               #0xb64f88
    // 0xb64f84: r7 = Null
    //     0xb64f84: mov             x7, NULL
    // 0xb64f88: ldur            x0, [fp, #-0x28]
    // 0xb64f8c: stur            x7, [fp, #-0x40]
    // 0xb64f90: LoadField: r3 = r0->field_7
    //     0xb64f90: ldur            w3, [x0, #7]
    // 0xb64f94: DecompressPointer r3
    //     0xb64f94: add             x3, x3, HEAP, lsl #32
    // 0xb64f98: stur            x3, [fp, #-0x38]
    // 0xb64f9c: cmp             w3, NULL
    // 0xb64fa0: b.eq            #0xb6502c
    // 0xb64fa4: mov             x0, x3
    // 0xb64fa8: r2 = Null
    //     0xb64fa8: mov             x2, NULL
    // 0xb64fac: r1 = Null
    //     0xb64fac: mov             x1, NULL
    // 0xb64fb0: r4 = LoadClassIdInstr(r0)
    //     0xb64fb0: ldur            x4, [x0, #-1]
    //     0xb64fb4: ubfx            x4, x4, #0xc, #0x14
    // 0xb64fb8: r17 = -4208
    //     0xb64fb8: mov             x17, #-0x1070
    // 0xb64fbc: add             x4, x4, x17
    // 0xb64fc0: cmp             x4, #2
    // 0xb64fc4: b.ls            #0xb64fdc
    // 0xb64fc8: r8 = StackParentData
    //     0xb64fc8: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0xb64fcc: ldr             x8, [x8, #0xaa8]
    // 0xb64fd0: r3 = Null
    //     0xb64fd0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a1b0] Null
    //     0xb64fd4: ldr             x3, [x3, #0x1b0]
    // 0xb64fd8: r0 = DefaultTypeTest()
    //     0xb64fd8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb64fdc: ldur            x2, [fp, #-0x38]
    // 0xb64fe0: LoadField: r0 = r2->field_13
    //     0xb64fe0: ldur            w0, [x2, #0x13]
    // 0xb64fe4: DecompressPointer r0
    //     0xb64fe4: add             x0, x0, HEAP, lsl #32
    // 0xb64fe8: ldur            x7, [fp, #-0x40]
    // 0xb64fec: ldur            x4, [fp, #-0x30]
    // 0xb64ff0: b               #0xb64e7c
    // 0xb64ff4: mov             x1, x7
    // 0xb64ff8: mov             x0, x1
    // 0xb64ffc: LeaveFrame
    //     0xb64ffc: mov             SP, fp
    //     0xb65000: ldp             fp, lr, [SP], #0x10
    // 0xb65004: ret
    //     0xb65004: ret             
    // 0xb65008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb65008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6500c: b               #0xb64d90
    // 0xb65010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb65010: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb65014: b               #0xb64e90
    // 0xb65018: SaveReg d0
    //     0xb65018: str             q0, [SP, #-0x10]!
    // 0xb6501c: r0 = AllocateDouble()
    //     0xb6501c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb65020: mov             x1, x0
    // 0xb65024: RestoreReg d0
    //     0xb65024: ldr             q0, [SP], #0x10
    // 0xb65028: b               #0xb64f0c
    // 0xb6502c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb6502c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ layoutPositionedChild(/* No info */) {
    // ** addr: 0xbb8068, size: 0x25c
    // 0xbb8068: EnterFrame
    //     0xbb8068: stp             fp, lr, [SP, #-0x10]!
    //     0xbb806c: mov             fp, SP
    // 0xbb8070: AllocStack(0x38)
    //     0xbb8070: sub             SP, SP, #0x38
    // 0xbb8074: SetupParameters(dynamic _ /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */)
    //     0xbb8074: mov             x0, x5
    //     0xbb8078: stur            x5, [fp, #-0x20]
    //     0xbb807c: mov             x5, x1
    //     0xbb8080: mov             x4, x2
    //     0xbb8084: stur            x1, [fp, #-8]
    //     0xbb8088: stur            x2, [fp, #-0x10]
    //     0xbb808c: stur            x3, [fp, #-0x18]
    // 0xbb8090: CheckStackOverflow
    //     0xbb8090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb8094: cmp             SP, x16
    //     0xbb8098: b.ls            #0xbb82bc
    // 0xbb809c: mov             x1, x4
    // 0xbb80a0: mov             x2, x3
    // 0xbb80a4: r0 = positionedChildConstraints()
    //     0xbb80a4: bl              #0xb5f0b4  ; [package:flutter/src/rendering/stack.dart] StackParentData::positionedChildConstraints
    // 0xbb80a8: ldur            x3, [fp, #-8]
    // 0xbb80ac: r1 = LoadClassIdInstr(r3)
    //     0xbb80ac: ldur            x1, [x3, #-1]
    //     0xbb80b0: ubfx            x1, x1, #0xc, #0x14
    // 0xbb80b4: r16 = true
    //     0xbb80b4: add             x16, NULL, #0x20  ; true
    // 0xbb80b8: str             x16, [SP]
    // 0xbb80bc: mov             x2, x0
    // 0xbb80c0: mov             x0, x1
    // 0xbb80c4: mov             x1, x3
    // 0xbb80c8: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbb80c8: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbb80cc: ldr             x4, [x4, #0xed0]
    // 0xbb80d0: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbb80d0: mov             x17, #0xe6b9
    //     0xbb80d4: add             lr, x0, x17
    //     0xbb80d8: ldr             lr, [x21, lr, lsl #3]
    //     0xbb80dc: blr             lr
    // 0xbb80e0: ldur            x0, [fp, #-0x10]
    // 0xbb80e4: LoadField: r1 = r0->field_23
    //     0xbb80e4: ldur            w1, [x0, #0x23]
    // 0xbb80e8: DecompressPointer r1
    //     0xbb80e8: add             x1, x1, HEAP, lsl #32
    // 0xbb80ec: cmp             w1, NULL
    // 0xbb80f0: b.eq            #0xbb80fc
    // 0xbb80f4: LoadField: d0 = r1->field_7
    //     0xbb80f4: ldur            d0, [x1, #7]
    // 0xbb80f8: b               #0xbb8168
    // 0xbb80fc: LoadField: r1 = r0->field_1b
    //     0xbb80fc: ldur            w1, [x0, #0x1b]
    // 0xbb8100: DecompressPointer r1
    //     0xbb8100: add             x1, x1, HEAP, lsl #32
    // 0xbb8104: cmp             w1, NULL
    // 0xbb8108: b.eq            #0xbb8140
    // 0xbb810c: ldur            x2, [fp, #-0x18]
    // 0xbb8110: LoadField: d0 = r2->field_7
    //     0xbb8110: ldur            d0, [x2, #7]
    // 0xbb8114: LoadField: d1 = r1->field_7
    //     0xbb8114: ldur            d1, [x1, #7]
    // 0xbb8118: fsub            d2, d0, d1
    // 0xbb811c: ldur            x1, [fp, #-8]
    // 0xbb8120: stur            d2, [fp, #-0x28]
    // 0xbb8124: r0 = size()
    //     0xbb8124: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8128: LoadField: d0 = r0->field_7
    //     0xbb8128: ldur            d0, [x0, #7]
    // 0xbb812c: ldur            d1, [fp, #-0x28]
    // 0xbb8130: fsub            d2, d1, d0
    // 0xbb8134: mov             v0.16b, v2.16b
    // 0xbb8138: ldur            x0, [fp, #-0x10]
    // 0xbb813c: b               #0xbb8168
    // 0xbb8140: ldur            x1, [fp, #-8]
    // 0xbb8144: r0 = size()
    //     0xbb8144: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8148: ldur            x1, [fp, #-0x18]
    // 0xbb814c: mov             x2, x0
    // 0xbb8150: r0 = -()
    //     0xbb8150: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xbb8154: ldur            x1, [fp, #-0x20]
    // 0xbb8158: mov             x2, x0
    // 0xbb815c: r0 = alongOffset()
    //     0xbb815c: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xbb8160: LoadField: d0 = r0->field_7
    //     0xbb8160: ldur            d0, [x0, #7]
    // 0xbb8164: ldur            x0, [fp, #-0x10]
    // 0xbb8168: stur            d0, [fp, #-0x30]
    // 0xbb816c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbb816c: ldur            w1, [x0, #0x17]
    // 0xbb8170: DecompressPointer r1
    //     0xbb8170: add             x1, x1, HEAP, lsl #32
    // 0xbb8174: cmp             w1, NULL
    // 0xbb8178: b.eq            #0xbb8184
    // 0xbb817c: LoadField: d1 = r1->field_7
    //     0xbb817c: ldur            d1, [x1, #7]
    // 0xbb8180: b               #0xbb81fc
    // 0xbb8184: LoadField: r1 = r0->field_1f
    //     0xbb8184: ldur            w1, [x0, #0x1f]
    // 0xbb8188: DecompressPointer r1
    //     0xbb8188: add             x1, x1, HEAP, lsl #32
    // 0xbb818c: cmp             w1, NULL
    // 0xbb8190: b.eq            #0xbb81cc
    // 0xbb8194: ldur            x2, [fp, #-0x18]
    // 0xbb8198: LoadField: d1 = r2->field_f
    //     0xbb8198: ldur            d1, [x2, #0xf]
    // 0xbb819c: LoadField: d2 = r1->field_7
    //     0xbb819c: ldur            d2, [x1, #7]
    // 0xbb81a0: fsub            d3, d1, d2
    // 0xbb81a4: ldur            x1, [fp, #-8]
    // 0xbb81a8: stur            d3, [fp, #-0x28]
    // 0xbb81ac: r0 = size()
    //     0xbb81ac: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb81b0: LoadField: d0 = r0->field_f
    //     0xbb81b0: ldur            d0, [x0, #0xf]
    // 0xbb81b4: ldur            d1, [fp, #-0x28]
    // 0xbb81b8: fsub            d2, d1, d0
    // 0xbb81bc: mov             v1.16b, v2.16b
    // 0xbb81c0: ldur            x0, [fp, #-0x10]
    // 0xbb81c4: ldur            d0, [fp, #-0x30]
    // 0xbb81c8: b               #0xbb81fc
    // 0xbb81cc: ldur            x1, [fp, #-8]
    // 0xbb81d0: r0 = size()
    //     0xbb81d0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb81d4: ldur            x1, [fp, #-0x18]
    // 0xbb81d8: mov             x2, x0
    // 0xbb81dc: r0 = -()
    //     0xbb81dc: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xbb81e0: ldur            x1, [fp, #-0x20]
    // 0xbb81e4: mov             x2, x0
    // 0xbb81e8: r0 = alongOffset()
    //     0xbb81e8: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xbb81ec: LoadField: d0 = r0->field_f
    //     0xbb81ec: ldur            d0, [x0, #0xf]
    // 0xbb81f0: mov             v1.16b, v0.16b
    // 0xbb81f4: ldur            x0, [fp, #-0x10]
    // 0xbb81f8: ldur            d0, [fp, #-0x30]
    // 0xbb81fc: stur            d1, [fp, #-0x28]
    // 0xbb8200: r0 = Offset()
    //     0xbb8200: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbb8204: ldur            d0, [fp, #-0x30]
    // 0xbb8208: StoreField: r0->field_7 = d0
    //     0xbb8208: stur            d0, [x0, #7]
    // 0xbb820c: ldur            d1, [fp, #-0x28]
    // 0xbb8210: StoreField: r0->field_f = d1
    //     0xbb8210: stur            d1, [x0, #0xf]
    // 0xbb8214: ldur            x1, [fp, #-0x10]
    // 0xbb8218: StoreField: r1->field_7 = r0
    //     0xbb8218: stur            w0, [x1, #7]
    //     0xbb821c: ldurb           w16, [x1, #-1]
    //     0xbb8220: ldurb           w17, [x0, #-1]
    //     0xbb8224: and             x16, x17, x16, lsr #2
    //     0xbb8228: tst             x16, HEAP, lsr #32
    //     0xbb822c: b.eq            #0xbb8234
    //     0xbb8230: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbb8234: d2 = 0.000000
    //     0xbb8234: eor             v2.16b, v2.16b, v2.16b
    // 0xbb8238: fcmp            d2, d0
    // 0xbb823c: b.gt            #0xbb8278
    // 0xbb8240: ldur            x0, [fp, #-0x18]
    // 0xbb8244: ldur            x1, [fp, #-8]
    // 0xbb8248: r0 = size()
    //     0xbb8248: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb824c: LoadField: d0 = r0->field_7
    //     0xbb824c: ldur            d0, [x0, #7]
    // 0xbb8250: ldur            d1, [fp, #-0x30]
    // 0xbb8254: fadd            d2, d1, d0
    // 0xbb8258: ldur            x0, [fp, #-0x18]
    // 0xbb825c: LoadField: d0 = r0->field_7
    //     0xbb825c: ldur            d0, [x0, #7]
    // 0xbb8260: fcmp            d2, d0
    // 0xbb8264: b.gt            #0xbb8278
    // 0xbb8268: ldur            d0, [fp, #-0x28]
    // 0xbb826c: d1 = 0.000000
    //     0xbb826c: eor             v1.16b, v1.16b, v1.16b
    // 0xbb8270: fcmp            d1, d0
    // 0xbb8274: b.le            #0xbb8280
    // 0xbb8278: r0 = true
    //     0xbb8278: add             x0, NULL, #0x20  ; true
    // 0xbb827c: b               #0xbb82b0
    // 0xbb8280: ldur            x1, [fp, #-8]
    // 0xbb8284: r0 = size()
    //     0xbb8284: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbb8288: LoadField: d0 = r0->field_f
    //     0xbb8288: ldur            d0, [x0, #0xf]
    // 0xbb828c: ldur            d1, [fp, #-0x28]
    // 0xbb8290: fadd            d2, d1, d0
    // 0xbb8294: ldur            x1, [fp, #-0x18]
    // 0xbb8298: LoadField: d0 = r1->field_f
    //     0xbb8298: ldur            d0, [x1, #0xf]
    // 0xbb829c: fcmp            d2, d0
    // 0xbb82a0: r16 = true
    //     0xbb82a0: add             x16, NULL, #0x20  ; true
    // 0xbb82a4: r17 = false
    //     0xbb82a4: add             x17, NULL, #0x30  ; false
    // 0xbb82a8: csel            x1, x16, x17, gt
    // 0xbb82ac: mov             x0, x1
    // 0xbb82b0: LeaveFrame
    //     0xbb82b0: mov             SP, fp
    //     0xbb82b4: ldp             fp, lr, [SP], #0x10
    // 0xbb82b8: ret
    //     0xbb82b8: ret             
    // 0xbb82bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb82bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb82c0: b               #0xbb809c
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbca6c4, size: 0x528
    // 0xbca6c4: EnterFrame
    //     0xbca6c4: stp             fp, lr, [SP, #-0x10]!
    //     0xbca6c8: mov             fp, SP
    // 0xbca6cc: AllocStack(0x48)
    //     0xbca6cc: sub             SP, SP, #0x48
    // 0xbca6d0: SetupParameters(RenderStack this /* r1 => r3, fp-0x10 */)
    //     0xbca6d0: mov             x3, x1
    //     0xbca6d4: stur            x1, [fp, #-0x10]
    // 0xbca6d8: CheckStackOverflow
    //     0xbca6d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbca6dc: cmp             SP, x16
    //     0xbca6e0: b.ls            #0xbcabd8
    // 0xbca6e4: LoadField: r4 = r3->field_27
    //     0xbca6e4: ldur            w4, [x3, #0x27]
    // 0xbca6e8: DecompressPointer r4
    //     0xbca6e8: add             x4, x4, HEAP, lsl #32
    // 0xbca6ec: stur            x4, [fp, #-8]
    // 0xbca6f0: cmp             w4, NULL
    // 0xbca6f4: b.eq            #0xbca99c
    // 0xbca6f8: mov             x0, x4
    // 0xbca6fc: r2 = Null
    //     0xbca6fc: mov             x2, NULL
    // 0xbca700: r1 = Null
    //     0xbca700: mov             x1, NULL
    // 0xbca704: r4 = LoadClassIdInstr(r0)
    //     0xbca704: ldur            x4, [x0, #-1]
    //     0xbca708: ubfx            x4, x4, #0xc, #0x14
    // 0xbca70c: sub             x4, x4, #0xb46
    // 0xbca710: cmp             x4, #1
    // 0xbca714: b.ls            #0xbca728
    // 0xbca718: r8 = BoxConstraints
    //     0xbca718: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbca71c: r3 = Null
    //     0xbca71c: add             x3, PP, #0x90, lsl #12  ; [pp+0x906d0] Null
    //     0xbca720: ldr             x3, [x3, #0x6d0]
    // 0xbca724: r0 = BoxConstraints()
    //     0xbca724: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbca728: ldur            x0, [fp, #-0x10]
    // 0xbca72c: r1 = false
    //     0xbca72c: add             x1, NULL, #0x30  ; false
    // 0xbca730: StoreField: r0->field_5f = r1
    //     0xbca730: stur            w1, [x0, #0x5f]
    // 0xbca734: mov             x1, x0
    // 0xbca738: ldur            x2, [fp, #-8]
    // 0xbca73c: r3 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbca73c: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbca740: ldr             x3, [x3, #0x4f8]
    // 0xbca744: r0 = _computeSize()
    //     0xbca744: bl              #0xb5203c  ; [package:flutter/src/rendering/stack.dart] RenderStack::_computeSize
    // 0xbca748: ldur            x2, [fp, #-0x10]
    // 0xbca74c: StoreField: r2->field_4b = r0
    //     0xbca74c: stur            w0, [x2, #0x4b]
    //     0xbca750: ldurb           w16, [x2, #-1]
    //     0xbca754: ldurb           w17, [x0, #-1]
    //     0xbca758: and             x16, x17, x16, lsr #2
    //     0xbca75c: tst             x16, HEAP, lsr #32
    //     0xbca760: b.eq            #0xbca768
    //     0xbca764: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbca768: mov             x1, x2
    // 0xbca76c: r0 = _resolvedAlignment()
    //     0xbca76c: bl              #0xb64be4  ; [package:flutter/src/rendering/stack.dart] RenderStack::_resolvedAlignment
    // 0xbca770: mov             x4, x0
    // 0xbca774: ldur            x3, [fp, #-0x10]
    // 0xbca778: stur            x4, [fp, #-0x20]
    // 0xbca77c: LoadField: r0 = r3->field_57
    //     0xbca77c: ldur            w0, [x3, #0x57]
    // 0xbca780: DecompressPointer r0
    //     0xbca780: add             x0, x0, HEAP, lsl #32
    // 0xbca784: LoadField: d0 = r4->field_7
    //     0xbca784: ldur            d0, [x4, #7]
    // 0xbca788: stur            d0, [fp, #-0x30]
    // 0xbca78c: LoadField: d1 = r4->field_f
    //     0xbca78c: ldur            d1, [x4, #0xf]
    // 0xbca790: stur            d1, [fp, #-0x28]
    // 0xbca794: mov             x5, x0
    // 0xbca798: stur            x5, [fp, #-0x18]
    // 0xbca79c: CheckStackOverflow
    //     0xbca79c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbca7a0: cmp             SP, x16
    //     0xbca7a4: b.ls            #0xbcabe0
    // 0xbca7a8: cmp             w5, NULL
    // 0xbca7ac: b.eq            #0xbca98c
    // 0xbca7b0: LoadField: r6 = r5->field_7
    //     0xbca7b0: ldur            w6, [x5, #7]
    // 0xbca7b4: DecompressPointer r6
    //     0xbca7b4: add             x6, x6, HEAP, lsl #32
    // 0xbca7b8: stur            x6, [fp, #-8]
    // 0xbca7bc: cmp             w6, NULL
    // 0xbca7c0: b.eq            #0xbcabe8
    // 0xbca7c4: mov             x0, x6
    // 0xbca7c8: r2 = Null
    //     0xbca7c8: mov             x2, NULL
    // 0xbca7cc: r1 = Null
    //     0xbca7cc: mov             x1, NULL
    // 0xbca7d0: r4 = LoadClassIdInstr(r0)
    //     0xbca7d0: ldur            x4, [x0, #-1]
    //     0xbca7d4: ubfx            x4, x4, #0xc, #0x14
    // 0xbca7d8: r17 = -4208
    //     0xbca7d8: mov             x17, #-0x1070
    // 0xbca7dc: add             x4, x4, x17
    // 0xbca7e0: cmp             x4, #2
    // 0xbca7e4: b.ls            #0xbca7fc
    // 0xbca7e8: r8 = StackParentData
    //     0xbca7e8: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0xbca7ec: ldr             x8, [x8, #0xaa8]
    // 0xbca7f0: r3 = Null
    //     0xbca7f0: add             x3, PP, #0x90, lsl #12  ; [pp+0x906e0] Null
    //     0xbca7f4: ldr             x3, [x3, #0x6e0]
    // 0xbca7f8: r0 = DefaultTypeTest()
    //     0xbca7f8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbca7fc: ldur            x2, [fp, #-8]
    // 0xbca800: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xbca800: ldur            w0, [x2, #0x17]
    // 0xbca804: DecompressPointer r0
    //     0xbca804: add             x0, x0, HEAP, lsl #32
    // 0xbca808: cmp             w0, NULL
    // 0xbca80c: b.ne            #0xbca850
    // 0xbca810: LoadField: r0 = r2->field_1b
    //     0xbca810: ldur            w0, [x2, #0x1b]
    // 0xbca814: DecompressPointer r0
    //     0xbca814: add             x0, x0, HEAP, lsl #32
    // 0xbca818: cmp             w0, NULL
    // 0xbca81c: b.ne            #0xbca850
    // 0xbca820: LoadField: r0 = r2->field_1f
    //     0xbca820: ldur            w0, [x2, #0x1f]
    // 0xbca824: DecompressPointer r0
    //     0xbca824: add             x0, x0, HEAP, lsl #32
    // 0xbca828: cmp             w0, NULL
    // 0xbca82c: b.ne            #0xbca850
    // 0xbca830: LoadField: r0 = r2->field_23
    //     0xbca830: ldur            w0, [x2, #0x23]
    // 0xbca834: DecompressPointer r0
    //     0xbca834: add             x0, x0, HEAP, lsl #32
    // 0xbca838: cmp             w0, NULL
    // 0xbca83c: b.ne            #0xbca850
    // 0xbca840: LoadField: r0 = r2->field_27
    //     0xbca840: ldur            w0, [x2, #0x27]
    // 0xbca844: DecompressPointer r0
    //     0xbca844: add             x0, x0, HEAP, lsl #32
    // 0xbca848: cmp             w0, NULL
    // 0xbca84c: b.eq            #0xbca85c
    // 0xbca850: ldur            x3, [fp, #-0x18]
    // 0xbca854: mov             x4, x2
    // 0xbca858: b               #0xbca920
    // 0xbca85c: LoadField: r0 = r2->field_2b
    //     0xbca85c: ldur            w0, [x2, #0x2b]
    // 0xbca860: DecompressPointer r0
    //     0xbca860: add             x0, x0, HEAP, lsl #32
    // 0xbca864: cmp             w0, NULL
    // 0xbca868: b.ne            #0xbca918
    // 0xbca86c: ldur            x1, [fp, #-0x10]
    // 0xbca870: LoadField: r0 = r1->field_4b
    //     0xbca870: ldur            w0, [x1, #0x4b]
    // 0xbca874: DecompressPointer r0
    //     0xbca874: add             x0, x0, HEAP, lsl #32
    // 0xbca878: cmp             w0, NULL
    // 0xbca87c: b.eq            #0xbcaa6c
    // 0xbca880: ldur            x3, [fp, #-0x18]
    // 0xbca884: LoadField: r4 = r3->field_4b
    //     0xbca884: ldur            w4, [x3, #0x4b]
    // 0xbca888: DecompressPointer r4
    //     0xbca888: add             x4, x4, HEAP, lsl #32
    // 0xbca88c: cmp             w4, NULL
    // 0xbca890: b.eq            #0xbca9b8
    // 0xbca894: ldur            d0, [fp, #-0x30]
    // 0xbca898: ldur            d1, [fp, #-0x28]
    // 0xbca89c: d2 = 2.000000
    //     0xbca89c: fmov            d2, #2.00000000
    // 0xbca8a0: LoadField: d3 = r0->field_7
    //     0xbca8a0: ldur            d3, [x0, #7]
    // 0xbca8a4: LoadField: d4 = r4->field_7
    //     0xbca8a4: ldur            d4, [x4, #7]
    // 0xbca8a8: fsub            d5, d3, d4
    // 0xbca8ac: LoadField: d3 = r0->field_f
    //     0xbca8ac: ldur            d3, [x0, #0xf]
    // 0xbca8b0: LoadField: d4 = r4->field_f
    //     0xbca8b0: ldur            d4, [x4, #0xf]
    // 0xbca8b4: fsub            d6, d3, d4
    // 0xbca8b8: fdiv            d3, d5, d2
    // 0xbca8bc: fdiv            d4, d6, d2
    // 0xbca8c0: fmul            d5, d0, d3
    // 0xbca8c4: fadd            d6, d3, d5
    // 0xbca8c8: stur            d6, [fp, #-0x40]
    // 0xbca8cc: fmul            d3, d1, d4
    // 0xbca8d0: fadd            d5, d4, d3
    // 0xbca8d4: stur            d5, [fp, #-0x38]
    // 0xbca8d8: r0 = Offset()
    //     0xbca8d8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbca8dc: ldur            d0, [fp, #-0x40]
    // 0xbca8e0: StoreField: r0->field_7 = d0
    //     0xbca8e0: stur            d0, [x0, #7]
    // 0xbca8e4: ldur            d0, [fp, #-0x38]
    // 0xbca8e8: StoreField: r0->field_f = d0
    //     0xbca8e8: stur            d0, [x0, #0xf]
    // 0xbca8ec: ldur            x4, [fp, #-8]
    // 0xbca8f0: StoreField: r4->field_7 = r0
    //     0xbca8f0: stur            w0, [x4, #7]
    //     0xbca8f4: ldurb           w16, [x4, #-1]
    //     0xbca8f8: ldurb           w17, [x0, #-1]
    //     0xbca8fc: and             x16, x17, x16, lsr #2
    //     0xbca900: tst             x16, HEAP, lsr #32
    //     0xbca904: b.eq            #0xbca90c
    //     0xbca908: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbca90c: ldur            x0, [fp, #-0x10]
    // 0xbca910: mov             x1, x4
    // 0xbca914: b               #0xbca970
    // 0xbca918: ldur            x3, [fp, #-0x18]
    // 0xbca91c: mov             x4, x2
    // 0xbca920: ldur            x0, [fp, #-0x10]
    // 0xbca924: LoadField: r1 = r0->field_4b
    //     0xbca924: ldur            w1, [x0, #0x4b]
    // 0xbca928: DecompressPointer r1
    //     0xbca928: add             x1, x1, HEAP, lsl #32
    // 0xbca92c: cmp             w1, NULL
    // 0xbca930: b.eq            #0xbcab24
    // 0xbca934: mov             x16, x1
    // 0xbca938: mov             x1, x3
    // 0xbca93c: mov             x3, x16
    // 0xbca940: mov             x2, x4
    // 0xbca944: ldur            x5, [fp, #-0x20]
    // 0xbca948: r0 = layoutPositionedChild()
    //     0xbca948: bl              #0xbb8068  ; [package:flutter/src/rendering/stack.dart] RenderStack::layoutPositionedChild
    // 0xbca94c: tbnz            w0, #4, #0xbca95c
    // 0xbca950: ldur            x0, [fp, #-0x10]
    // 0xbca954: r1 = true
    //     0xbca954: add             x1, NULL, #0x20  ; true
    // 0xbca958: b               #0xbca968
    // 0xbca95c: ldur            x0, [fp, #-0x10]
    // 0xbca960: LoadField: r1 = r0->field_5f
    //     0xbca960: ldur            w1, [x0, #0x5f]
    // 0xbca964: DecompressPointer r1
    //     0xbca964: add             x1, x1, HEAP, lsl #32
    // 0xbca968: StoreField: r0->field_5f = r1
    //     0xbca968: stur            w1, [x0, #0x5f]
    // 0xbca96c: ldur            x1, [fp, #-8]
    // 0xbca970: LoadField: r5 = r1->field_13
    //     0xbca970: ldur            w5, [x1, #0x13]
    // 0xbca974: DecompressPointer r5
    //     0xbca974: add             x5, x5, HEAP, lsl #32
    // 0xbca978: mov             x3, x0
    // 0xbca97c: ldur            x4, [fp, #-0x20]
    // 0xbca980: ldur            d0, [fp, #-0x30]
    // 0xbca984: ldur            d1, [fp, #-0x28]
    // 0xbca988: b               #0xbca798
    // 0xbca98c: r0 = Null
    //     0xbca98c: mov             x0, NULL
    // 0xbca990: LeaveFrame
    //     0xbca990: mov             SP, fp
    //     0xbca994: ldp             fp, lr, [SP], #0x10
    // 0xbca998: ret
    //     0xbca998: ret             
    // 0xbca99c: r0 = StateError()
    //     0xbca99c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbca9a0: mov             x1, x0
    // 0xbca9a4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbca9a4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbca9a8: StoreField: r1->field_b = r0
    //     0xbca9a8: stur            w0, [x1, #0xb]
    // 0xbca9ac: mov             x0, x1
    // 0xbca9b0: r0 = Throw()
    //     0xbca9b0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbca9b4: brk             #0
    // 0xbca9b8: r1 = Null
    //     0xbca9b8: mov             x1, NULL
    // 0xbca9bc: r2 = 8
    //     0xbca9bc: mov             x2, #8
    // 0xbca9c0: r0 = AllocateArray()
    //     0xbca9c0: bl              #0x13df928  ; AllocateArrayStub
    // 0xbca9c4: stur            x0, [fp, #-8]
    // 0xbca9c8: r16 = "RenderBox was not laid out: "
    //     0xbca9c8: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbca9cc: StoreField: r0->field_f = r16
    //     0xbca9cc: stur            w16, [x0, #0xf]
    // 0xbca9d0: ldur            x16, [fp, #-0x18]
    // 0xbca9d4: str             x16, [SP]
    // 0xbca9d8: r0 = runtimeType()
    //     0xbca9d8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbca9dc: ldur            x1, [fp, #-8]
    // 0xbca9e0: ArrayStore: r1[1] = r0  ; List_4
    //     0xbca9e0: add             x25, x1, #0x13
    //     0xbca9e4: str             w0, [x25]
    //     0xbca9e8: tbz             w0, #0, #0xbcaa04
    //     0xbca9ec: ldurb           w16, [x1, #-1]
    //     0xbca9f0: ldurb           w17, [x0, #-1]
    //     0xbca9f4: and             x16, x17, x16, lsr #2
    //     0xbca9f8: tst             x16, HEAP, lsr #32
    //     0xbca9fc: b.eq            #0xbcaa04
    //     0xbcaa00: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbcaa04: ldur            x0, [fp, #-8]
    // 0xbcaa08: r16 = "#"
    //     0xbcaa08: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbcaa0c: ArrayStore: r0[0] = r16  ; List_4
    //     0xbcaa0c: stur            w16, [x0, #0x17]
    // 0xbcaa10: ldur            x1, [fp, #-0x18]
    // 0xbcaa14: r0 = shortHash()
    //     0xbcaa14: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbcaa18: ldur            x1, [fp, #-8]
    // 0xbcaa1c: ArrayStore: r1[3] = r0  ; List_4
    //     0xbcaa1c: add             x25, x1, #0x1b
    //     0xbcaa20: str             w0, [x25]
    //     0xbcaa24: tbz             w0, #0, #0xbcaa40
    //     0xbcaa28: ldurb           w16, [x1, #-1]
    //     0xbcaa2c: ldurb           w17, [x0, #-1]
    //     0xbcaa30: and             x16, x17, x16, lsr #2
    //     0xbcaa34: tst             x16, HEAP, lsr #32
    //     0xbcaa38: b.eq            #0xbcaa40
    //     0xbcaa3c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbcaa40: ldur            x16, [fp, #-8]
    // 0xbcaa44: str             x16, [SP]
    // 0xbcaa48: r0 = _interpolate()
    //     0xbcaa48: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbcaa4c: stur            x0, [fp, #-8]
    // 0xbcaa50: r0 = StateError()
    //     0xbcaa50: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcaa54: mov             x1, x0
    // 0xbcaa58: ldur            x0, [fp, #-8]
    // 0xbcaa5c: StoreField: r1->field_b = r0
    //     0xbcaa5c: stur            w0, [x1, #0xb]
    // 0xbcaa60: mov             x0, x1
    // 0xbcaa64: r0 = Throw()
    //     0xbcaa64: bl              #0x13ddb2c  ; ThrowStub
    // 0xbcaa68: brk             #0
    // 0xbcaa6c: mov             x0, x1
    // 0xbcaa70: r1 = Null
    //     0xbcaa70: mov             x1, NULL
    // 0xbcaa74: r2 = 8
    //     0xbcaa74: mov             x2, #8
    // 0xbcaa78: r0 = AllocateArray()
    //     0xbcaa78: bl              #0x13df928  ; AllocateArrayStub
    // 0xbcaa7c: stur            x0, [fp, #-8]
    // 0xbcaa80: r16 = "RenderBox was not laid out: "
    //     0xbcaa80: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbcaa84: StoreField: r0->field_f = r16
    //     0xbcaa84: stur            w16, [x0, #0xf]
    // 0xbcaa88: ldur            x16, [fp, #-0x10]
    // 0xbcaa8c: str             x16, [SP]
    // 0xbcaa90: r0 = runtimeType()
    //     0xbcaa90: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbcaa94: ldur            x1, [fp, #-8]
    // 0xbcaa98: ArrayStore: r1[1] = r0  ; List_4
    //     0xbcaa98: add             x25, x1, #0x13
    //     0xbcaa9c: str             w0, [x25]
    //     0xbcaaa0: tbz             w0, #0, #0xbcaabc
    //     0xbcaaa4: ldurb           w16, [x1, #-1]
    //     0xbcaaa8: ldurb           w17, [x0, #-1]
    //     0xbcaaac: and             x16, x17, x16, lsr #2
    //     0xbcaab0: tst             x16, HEAP, lsr #32
    //     0xbcaab4: b.eq            #0xbcaabc
    //     0xbcaab8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbcaabc: ldur            x0, [fp, #-8]
    // 0xbcaac0: r16 = "#"
    //     0xbcaac0: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbcaac4: ArrayStore: r0[0] = r16  ; List_4
    //     0xbcaac4: stur            w16, [x0, #0x17]
    // 0xbcaac8: ldur            x1, [fp, #-0x10]
    // 0xbcaacc: r0 = shortHash()
    //     0xbcaacc: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbcaad0: ldur            x1, [fp, #-8]
    // 0xbcaad4: ArrayStore: r1[3] = r0  ; List_4
    //     0xbcaad4: add             x25, x1, #0x1b
    //     0xbcaad8: str             w0, [x25]
    //     0xbcaadc: tbz             w0, #0, #0xbcaaf8
    //     0xbcaae0: ldurb           w16, [x1, #-1]
    //     0xbcaae4: ldurb           w17, [x0, #-1]
    //     0xbcaae8: and             x16, x17, x16, lsr #2
    //     0xbcaaec: tst             x16, HEAP, lsr #32
    //     0xbcaaf0: b.eq            #0xbcaaf8
    //     0xbcaaf4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbcaaf8: ldur            x16, [fp, #-8]
    // 0xbcaafc: str             x16, [SP]
    // 0xbcab00: r0 = _interpolate()
    //     0xbcab00: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbcab04: stur            x0, [fp, #-8]
    // 0xbcab08: r0 = StateError()
    //     0xbcab08: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcab0c: mov             x1, x0
    // 0xbcab10: ldur            x0, [fp, #-8]
    // 0xbcab14: StoreField: r1->field_b = r0
    //     0xbcab14: stur            w0, [x1, #0xb]
    // 0xbcab18: mov             x0, x1
    // 0xbcab1c: r0 = Throw()
    //     0xbcab1c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbcab20: brk             #0
    // 0xbcab24: r1 = Null
    //     0xbcab24: mov             x1, NULL
    // 0xbcab28: r2 = 8
    //     0xbcab28: mov             x2, #8
    // 0xbcab2c: r0 = AllocateArray()
    //     0xbcab2c: bl              #0x13df928  ; AllocateArrayStub
    // 0xbcab30: stur            x0, [fp, #-8]
    // 0xbcab34: r16 = "RenderBox was not laid out: "
    //     0xbcab34: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbcab38: StoreField: r0->field_f = r16
    //     0xbcab38: stur            w16, [x0, #0xf]
    // 0xbcab3c: ldur            x16, [fp, #-0x10]
    // 0xbcab40: str             x16, [SP]
    // 0xbcab44: r0 = runtimeType()
    //     0xbcab44: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbcab48: ldur            x1, [fp, #-8]
    // 0xbcab4c: ArrayStore: r1[1] = r0  ; List_4
    //     0xbcab4c: add             x25, x1, #0x13
    //     0xbcab50: str             w0, [x25]
    //     0xbcab54: tbz             w0, #0, #0xbcab70
    //     0xbcab58: ldurb           w16, [x1, #-1]
    //     0xbcab5c: ldurb           w17, [x0, #-1]
    //     0xbcab60: and             x16, x17, x16, lsr #2
    //     0xbcab64: tst             x16, HEAP, lsr #32
    //     0xbcab68: b.eq            #0xbcab70
    //     0xbcab6c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbcab70: ldur            x0, [fp, #-8]
    // 0xbcab74: r16 = "#"
    //     0xbcab74: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbcab78: ArrayStore: r0[0] = r16  ; List_4
    //     0xbcab78: stur            w16, [x0, #0x17]
    // 0xbcab7c: ldur            x1, [fp, #-0x10]
    // 0xbcab80: r0 = shortHash()
    //     0xbcab80: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbcab84: ldur            x1, [fp, #-8]
    // 0xbcab88: ArrayStore: r1[3] = r0  ; List_4
    //     0xbcab88: add             x25, x1, #0x1b
    //     0xbcab8c: str             w0, [x25]
    //     0xbcab90: tbz             w0, #0, #0xbcabac
    //     0xbcab94: ldurb           w16, [x1, #-1]
    //     0xbcab98: ldurb           w17, [x0, #-1]
    //     0xbcab9c: and             x16, x17, x16, lsr #2
    //     0xbcaba0: tst             x16, HEAP, lsr #32
    //     0xbcaba4: b.eq            #0xbcabac
    //     0xbcaba8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbcabac: ldur            x16, [fp, #-8]
    // 0xbcabb0: str             x16, [SP]
    // 0xbcabb4: r0 = _interpolate()
    //     0xbcabb4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbcabb8: stur            x0, [fp, #-8]
    // 0xbcabbc: r0 = StateError()
    //     0xbcabbc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcabc0: mov             x1, x0
    // 0xbcabc4: ldur            x0, [fp, #-8]
    // 0xbcabc8: StoreField: r1->field_b = r0
    //     0xbcabc8: stur            w0, [x1, #0xb]
    // 0xbcabcc: mov             x0, x1
    // 0xbcabd0: r0 = Throw()
    //     0xbcabd0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbcabd4: brk             #0
    // 0xbcabd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcabd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcabdc: b               #0xbca6e4
    // 0xbcabe0: r0 = StackOverflowSharedWithFPURegs()
    //     0xbcabe0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbcabe4: b               #0xbca7a8
    // 0xbcabe8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbcabe8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc03548, size: 0x50
    // 0xc03548: EnterFrame
    //     0xc03548: stp             fp, lr, [SP, #-0x10]!
    //     0xc0354c: mov             fp, SP
    // 0xc03550: AllocStack(0x8)
    //     0xc03550: sub             SP, SP, #8
    // 0xc03554: SetupParameters(RenderStack this /* r1 => r0, fp-0x8 */)
    //     0xc03554: mov             x0, x1
    //     0xc03558: stur            x1, [fp, #-8]
    // 0xc0355c: CheckStackOverflow
    //     0xc0355c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc03560: cmp             SP, x16
    //     0xc03564: b.ls            #0xc03590
    // 0xc03568: LoadField: r1 = r0->field_77
    //     0xc03568: ldur            w1, [x0, #0x77]
    // 0xc0356c: DecompressPointer r1
    //     0xc0356c: add             x1, x1, HEAP, lsl #32
    // 0xc03570: r2 = Null
    //     0xc03570: mov             x2, NULL
    // 0xc03574: r0 = layer=()
    //     0xc03574: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc03578: ldur            x1, [fp, #-8]
    // 0xc0357c: r0 = dispose()
    //     0xc0357c: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc03580: r0 = Null
    //     0xc03580: mov             x0, NULL
    // 0xc03584: LeaveFrame
    //     0xc03584: mov             SP, fp
    //     0xc03588: ldp             fp, lr, [SP], #0x10
    // 0xc0358c: ret
    //     0xc0358c: ret             
    // 0xc03590: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc03590: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc03594: b               #0xc03568
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0dfd4, size: 0xbc
    // 0xc0dfd4: EnterFrame
    //     0xc0dfd4: stp             fp, lr, [SP, #-0x10]!
    //     0xc0dfd8: mov             fp, SP
    // 0xc0dfdc: AllocStack(0x8)
    //     0xc0dfdc: sub             SP, SP, #8
    // 0xc0dfe0: SetupParameters(RenderStack this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0dfe0: mov             x0, x2
    //     0xc0dfe4: mov             x4, x1
    //     0xc0dfe8: mov             x3, x2
    //     0xc0dfec: stur            x2, [fp, #-8]
    // 0xc0dff0: r2 = Null
    //     0xc0dff0: mov             x2, NULL
    // 0xc0dff4: r1 = Null
    //     0xc0dff4: mov             x1, NULL
    // 0xc0dff8: r4 = 60
    //     0xc0dff8: mov             x4, #0x3c
    // 0xc0dffc: branchIfSmi(r0, 0xc0e008)
    //     0xc0dffc: tbz             w0, #0, #0xc0e008
    // 0xc0e000: r4 = LoadClassIdInstr(r0)
    //     0xc0e000: ldur            x4, [x0, #-1]
    //     0xc0e004: ubfx            x4, x4, #0xc, #0x14
    // 0xc0e008: r17 = -4710
    //     0xc0e008: mov             x17, #-0x1266
    // 0xc0e00c: add             x4, x4, x17
    // 0xc0e010: cmp             x4, #0x109
    // 0xc0e014: b.ls            #0xc0e028
    // 0xc0e018: r8 = RenderBox
    //     0xc0e018: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0e01c: r3 = Null
    //     0xc0e01c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90708] Null
    //     0xc0e020: ldr             x3, [x3, #0x708]
    // 0xc0e024: r0 = RenderBox()
    //     0xc0e024: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0e028: ldur            x0, [fp, #-8]
    // 0xc0e02c: LoadField: r1 = r0->field_7
    //     0xc0e02c: ldur            w1, [x0, #7]
    // 0xc0e030: DecompressPointer r1
    //     0xc0e030: add             x1, x1, HEAP, lsl #32
    // 0xc0e034: r2 = LoadClassIdInstr(r1)
    //     0xc0e034: ldur            x2, [x1, #-1]
    //     0xc0e038: ubfx            x2, x2, #0xc, #0x14
    // 0xc0e03c: r17 = -4208
    //     0xc0e03c: mov             x17, #-0x1070
    // 0xc0e040: add             x16, x2, x17
    // 0xc0e044: cmp             x16, #2
    // 0xc0e048: b.ls            #0xc0e080
    // 0xc0e04c: r1 = <RenderBox>
    //     0xc0e04c: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0e050: ldr             x1, [x1, #0x5c8]
    // 0xc0e054: r0 = StackParentData()
    //     0xc0e054: bl              #0xc0d62c  ; AllocateStackParentDataStub -> StackParentData (size=0x30)
    // 0xc0e058: r1 = Instance_Offset
    //     0xc0e058: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0e05c: StoreField: r0->field_7 = r1
    //     0xc0e05c: stur            w1, [x0, #7]
    // 0xc0e060: ldur            x1, [fp, #-8]
    // 0xc0e064: StoreField: r1->field_7 = r0
    //     0xc0e064: stur            w0, [x1, #7]
    //     0xc0e068: ldurb           w16, [x1, #-1]
    //     0xc0e06c: ldurb           w17, [x0, #-1]
    //     0xc0e070: and             x16, x17, x16, lsr #2
    //     0xc0e074: tst             x16, HEAP, lsr #32
    //     0xc0e078: b.eq            #0xc0e080
    //     0xc0e07c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0e080: r0 = Null
    //     0xc0e080: mov             x0, NULL
    // 0xc0e084: LeaveFrame
    //     0xc0e084: mov             SP, fp
    //     0xc0e088: ldp             fp, lr, [SP], #0x10
    // 0xc0e08c: ret
    //     0xc0e08c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc2675c, size: 0x160
    // 0xc2675c: EnterFrame
    //     0xc2675c: stp             fp, lr, [SP, #-0x10]!
    //     0xc26760: mov             fp, SP
    // 0xc26764: AllocStack(0x40)
    //     0xc26764: sub             SP, SP, #0x40
    // 0xc26768: SetupParameters(RenderStack this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0xc26768: mov             x0, x2
    //     0xc2676c: stur            x2, [fp, #-0x20]
    //     0xc26770: mov             x2, x1
    //     0xc26774: stur            x1, [fp, #-0x18]
    //     0xc26778: stur            x3, [fp, #-0x28]
    // 0xc2677c: CheckStackOverflow
    //     0xc2677c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc26780: cmp             SP, x16
    //     0xc26784: b.ls            #0xc268ac
    // 0xc26788: LoadField: r1 = r2->field_73
    //     0xc26788: ldur            w1, [x2, #0x73]
    // 0xc2678c: DecompressPointer r1
    //     0xc2678c: add             x1, x1, HEAP, lsl #32
    // 0xc26790: r16 = Instance_Clip
    //     0xc26790: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc26794: ldr             x16, [x16, #0x840]
    // 0xc26798: cmp             w1, w16
    // 0xc2679c: b.eq            #0xc26864
    // 0xc267a0: LoadField: r1 = r2->field_5f
    //     0xc267a0: ldur            w1, [x2, #0x5f]
    // 0xc267a4: DecompressPointer r1
    //     0xc267a4: add             x1, x1, HEAP, lsl #32
    // 0xc267a8: tbnz            w1, #4, #0xc2685c
    // 0xc267ac: LoadField: r4 = r2->field_77
    //     0xc267ac: ldur            w4, [x2, #0x77]
    // 0xc267b0: DecompressPointer r4
    //     0xc267b0: add             x4, x4, HEAP, lsl #32
    // 0xc267b4: stur            x4, [fp, #-0x10]
    // 0xc267b8: LoadField: r5 = r2->field_37
    //     0xc267b8: ldur            w5, [x2, #0x37]
    // 0xc267bc: DecompressPointer r5
    //     0xc267bc: add             x5, x5, HEAP, lsl #32
    // 0xc267c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc267c4: cmp             w5, w16
    // 0xc267c8: b.eq            #0xc268b4
    // 0xc267cc: mov             x1, x2
    // 0xc267d0: stur            x5, [fp, #-8]
    // 0xc267d4: r0 = size()
    //     0xc267d4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc267d8: mov             x2, x0
    // 0xc267dc: r1 = Instance_Offset
    //     0xc267dc: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc267e0: r0 = &()
    //     0xc267e0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc267e4: mov             x2, x0
    // 0xc267e8: ldur            x1, [fp, #-0x18]
    // 0xc267ec: stur            x2, [fp, #-0x30]
    // 0xc267f0: r0 = LoadClassIdInstr(r1)
    //     0xc267f0: ldur            x0, [x1, #-1]
    //     0xc267f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc267f8: str             x1, [SP]
    // 0xc267fc: r0 = GDT[cid_x0 + 0x17d1]()
    //     0xc267fc: mov             x17, #0x17d1
    //     0xc26800: add             lr, x0, x17
    //     0xc26804: ldr             lr, [x21, lr, lsl #3]
    //     0xc26808: blr             lr
    // 0xc2680c: mov             x1, x0
    // 0xc26810: ldur            x0, [fp, #-0x18]
    // 0xc26814: LoadField: r2 = r0->field_73
    //     0xc26814: ldur            w2, [x0, #0x73]
    // 0xc26818: DecompressPointer r2
    //     0xc26818: add             x2, x2, HEAP, lsl #32
    // 0xc2681c: ldur            x0, [fp, #-0x10]
    // 0xc26820: LoadField: r3 = r0->field_b
    //     0xc26820: ldur            w3, [x0, #0xb]
    // 0xc26824: DecompressPointer r3
    //     0xc26824: add             x3, x3, HEAP, lsl #32
    // 0xc26828: stp             x3, x2, [SP]
    // 0xc2682c: mov             x6, x1
    // 0xc26830: ldur            x1, [fp, #-0x20]
    // 0xc26834: ldur            x2, [fp, #-8]
    // 0xc26838: ldur            x3, [fp, #-0x28]
    // 0xc2683c: ldur            x5, [fp, #-0x30]
    // 0xc26840: r4 = const [0, 0x7, 0x2, 0x5, clipBehavior, 0x5, oldLayer, 0x6, null]
    //     0xc26840: add             x4, PP, #0x90, lsl #12  ; [pp+0x90688] List(9) [0, 0x7, 0x2, 0x5, "clipBehavior", 0x5, "oldLayer", 0x6, Null]
    //     0xc26844: ldr             x4, [x4, #0x688]
    // 0xc26848: r0 = pushClipRect()
    //     0xc26848: bl              #0xc19194  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0xc2684c: ldur            x1, [fp, #-0x10]
    // 0xc26850: mov             x2, x0
    // 0xc26854: r0 = layer=()
    //     0xc26854: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc26858: b               #0xc2689c
    // 0xc2685c: mov             x0, x2
    // 0xc26860: b               #0xc26868
    // 0xc26864: mov             x0, x2
    // 0xc26868: LoadField: r1 = r0->field_77
    //     0xc26868: ldur            w1, [x0, #0x77]
    // 0xc2686c: DecompressPointer r1
    //     0xc2686c: add             x1, x1, HEAP, lsl #32
    // 0xc26870: r2 = Null
    //     0xc26870: mov             x2, NULL
    // 0xc26874: r0 = layer=()
    //     0xc26874: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc26878: ldur            x1, [fp, #-0x18]
    // 0xc2687c: r0 = LoadClassIdInstr(r1)
    //     0xc2687c: ldur            x0, [x1, #-1]
    //     0xc26880: ubfx            x0, x0, #0xc, #0x14
    // 0xc26884: ldur            x2, [fp, #-0x20]
    // 0xc26888: ldur            x3, [fp, #-0x28]
    // 0xc2688c: r0 = GDT[cid_x0 + 0x25d1]()
    //     0xc2688c: mov             x17, #0x25d1
    //     0xc26890: add             lr, x0, x17
    //     0xc26894: ldr             lr, [x21, lr, lsl #3]
    //     0xc26898: blr             lr
    // 0xc2689c: r0 = Null
    //     0xc2689c: mov             x0, NULL
    // 0xc268a0: LeaveFrame
    //     0xc268a0: mov             SP, fp
    //     0xc268a4: ldp             fp, lr, [SP], #0x10
    // 0xc268a8: ret
    //     0xc268a8: ret             
    // 0xc268ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc268ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc268b0: b               #0xc26788
    // 0xc268b4: r9 = _needsCompositing
    //     0xc268b4: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc268b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc268b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ describeApproximatePaintClip(/* No info */) {
    // ** addr: 0xcce310, size: 0x78
    // 0xcce310: EnterFrame
    //     0xcce310: stp             fp, lr, [SP, #-0x10]!
    //     0xcce314: mov             fp, SP
    // 0xcce318: CheckStackOverflow
    //     0xcce318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcce31c: cmp             SP, x16
    //     0xcce320: b.ls            #0xcce380
    // 0xcce324: LoadField: r0 = r1->field_73
    //     0xcce324: ldur            w0, [x1, #0x73]
    // 0xcce328: DecompressPointer r0
    //     0xcce328: add             x0, x0, HEAP, lsl #32
    // 0xcce32c: LoadField: r2 = r0->field_7
    //     0xcce32c: ldur            x2, [x0, #7]
    // 0xcce330: cmp             x2, #1
    // 0xcce334: b.gt            #0xcce350
    // 0xcce338: cmp             x2, #0
    // 0xcce33c: b.gt            #0xcce350
    // 0xcce340: r0 = Null
    //     0xcce340: mov             x0, NULL
    // 0xcce344: LeaveFrame
    //     0xcce344: mov             SP, fp
    //     0xcce348: ldp             fp, lr, [SP], #0x10
    // 0xcce34c: ret
    //     0xcce34c: ret             
    // 0xcce350: LoadField: r0 = r1->field_5f
    //     0xcce350: ldur            w0, [x1, #0x5f]
    // 0xcce354: DecompressPointer r0
    //     0xcce354: add             x0, x0, HEAP, lsl #32
    // 0xcce358: tbnz            w0, #4, #0xcce370
    // 0xcce35c: r0 = size()
    //     0xcce35c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xcce360: mov             x2, x0
    // 0xcce364: r1 = Instance_Offset
    //     0xcce364: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xcce368: r0 = &()
    //     0xcce368: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xcce36c: b               #0xcce374
    // 0xcce370: r0 = Null
    //     0xcce370: mov             x0, NULL
    // 0xcce374: LeaveFrame
    //     0xcce374: mov             SP, fp
    //     0xcce378: ldp             fp, lr, [SP], #0x10
    // 0xcce37c: ret
    //     0xcce37c: ret             
    // 0xcce380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcce380: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcce384: b               #0xcce324
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcef000, size: 0x70
    // 0xcef000: EnterFrame
    //     0xcef000: stp             fp, lr, [SP, #-0x10]!
    //     0xcef004: mov             fp, SP
    // 0xcef008: mov             x0, x2
    // 0xcef00c: CheckStackOverflow
    //     0xcef00c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef010: cmp             SP, x16
    //     0xcef014: b.ls            #0xcef068
    // 0xcef018: LoadField: r2 = r1->field_6b
    //     0xcef018: ldur            w2, [x1, #0x6b]
    // 0xcef01c: DecompressPointer r2
    //     0xcef01c: add             x2, x2, HEAP, lsl #32
    // 0xcef020: cmp             w2, w0
    // 0xcef024: b.ne            #0xcef038
    // 0xcef028: r0 = Null
    //     0xcef028: mov             x0, NULL
    // 0xcef02c: LeaveFrame
    //     0xcef02c: mov             SP, fp
    //     0xcef030: ldp             fp, lr, [SP], #0x10
    // 0xcef034: ret
    //     0xcef034: ret             
    // 0xcef038: StoreField: r1->field_6b = r0
    //     0xcef038: stur            w0, [x1, #0x6b]
    //     0xcef03c: ldurb           w16, [x1, #-1]
    //     0xcef040: ldurb           w17, [x0, #-1]
    //     0xcef044: and             x16, x17, x16, lsr #2
    //     0xcef048: tst             x16, HEAP, lsr #32
    //     0xcef04c: b.eq            #0xcef054
    //     0xcef050: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcef054: r0 = _markNeedResolution()
    //     0xcef054: bl              #0xcef070  ; [package:flutter/src/rendering/stack.dart] RenderStack::_markNeedResolution
    // 0xcef058: r0 = Null
    //     0xcef058: mov             x0, NULL
    // 0xcef05c: LeaveFrame
    //     0xcef05c: mov             SP, fp
    //     0xcef060: ldp             fp, lr, [SP], #0x10
    // 0xcef064: ret
    //     0xcef064: ret             
    // 0xcef068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef06c: b               #0xcef018
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0xcef070, size: 0x34
    // 0xcef070: EnterFrame
    //     0xcef070: stp             fp, lr, [SP, #-0x10]!
    //     0xcef074: mov             fp, SP
    // 0xcef078: CheckStackOverflow
    //     0xcef078: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef07c: cmp             SP, x16
    //     0xcef080: b.ls            #0xcef09c
    // 0xcef084: StoreField: r1->field_63 = rNULL
    //     0xcef084: stur            NULL, [x1, #0x63]
    // 0xcef088: r0 = markNeedsLayout()
    //     0xcef088: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcef08c: r0 = Null
    //     0xcef08c: mov             x0, NULL
    // 0xcef090: LeaveFrame
    //     0xcef090: mov             SP, fp
    //     0xcef094: ldp             fp, lr, [SP], #0x10
    // 0xcef098: ret
    //     0xcef098: ret             
    // 0xcef09c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef09c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef0a0: b               #0xcef084
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0xcef0a4, size: 0x88
    // 0xcef0a4: EnterFrame
    //     0xcef0a4: stp             fp, lr, [SP, #-0x10]!
    //     0xcef0a8: mov             fp, SP
    // 0xcef0ac: AllocStack(0x20)
    //     0xcef0ac: sub             SP, SP, #0x20
    // 0xcef0b0: SetupParameters(RenderStack this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcef0b0: mov             x0, x2
    //     0xcef0b4: stur            x1, [fp, #-8]
    //     0xcef0b8: stur            x2, [fp, #-0x10]
    // 0xcef0bc: CheckStackOverflow
    //     0xcef0bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef0c0: cmp             SP, x16
    //     0xcef0c4: b.ls            #0xcef124
    // 0xcef0c8: LoadField: r2 = r1->field_67
    //     0xcef0c8: ldur            w2, [x1, #0x67]
    // 0xcef0cc: DecompressPointer r2
    //     0xcef0cc: add             x2, x2, HEAP, lsl #32
    // 0xcef0d0: stp             x0, x2, [SP]
    // 0xcef0d4: r0 = ==()
    //     0xcef0d4: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xcef0d8: tbnz            w0, #4, #0xcef0ec
    // 0xcef0dc: r0 = Null
    //     0xcef0dc: mov             x0, NULL
    // 0xcef0e0: LeaveFrame
    //     0xcef0e0: mov             SP, fp
    //     0xcef0e4: ldp             fp, lr, [SP], #0x10
    // 0xcef0e8: ret
    //     0xcef0e8: ret             
    // 0xcef0ec: ldur            x1, [fp, #-8]
    // 0xcef0f0: ldur            x0, [fp, #-0x10]
    // 0xcef0f4: StoreField: r1->field_67 = r0
    //     0xcef0f4: stur            w0, [x1, #0x67]
    //     0xcef0f8: ldurb           w16, [x1, #-1]
    //     0xcef0fc: ldurb           w17, [x0, #-1]
    //     0xcef100: and             x16, x17, x16, lsr #2
    //     0xcef104: tst             x16, HEAP, lsr #32
    //     0xcef108: b.eq            #0xcef110
    //     0xcef10c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcef110: r0 = _markNeedResolution()
    //     0xcef110: bl              #0xcef070  ; [package:flutter/src/rendering/stack.dart] RenderStack::_markNeedResolution
    // 0xcef114: r0 = Null
    //     0xcef114: mov             x0, NULL
    // 0xcef118: LeaveFrame
    //     0xcef118: mov             SP, fp
    //     0xcef11c: ldp             fp, lr, [SP], #0x10
    // 0xcef120: ret
    //     0xcef120: ret             
    // 0xcef124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef124: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef128: b               #0xcef0c8
  }
  set _ clipBehavior=(/* No info */) {
    // ** addr: 0xcef12c, size: 0x78
    // 0xcef12c: EnterFrame
    //     0xcef12c: stp             fp, lr, [SP, #-0x10]!
    //     0xcef130: mov             fp, SP
    // 0xcef134: AllocStack(0x8)
    //     0xcef134: sub             SP, SP, #8
    // 0xcef138: SetupParameters(RenderStack this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xcef138: mov             x0, x2
    //     0xcef13c: mov             x2, x1
    //     0xcef140: stur            x1, [fp, #-8]
    // 0xcef144: CheckStackOverflow
    //     0xcef144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef148: cmp             SP, x16
    //     0xcef14c: b.ls            #0xcef19c
    // 0xcef150: LoadField: r1 = r2->field_73
    //     0xcef150: ldur            w1, [x2, #0x73]
    // 0xcef154: DecompressPointer r1
    //     0xcef154: add             x1, x1, HEAP, lsl #32
    // 0xcef158: cmp             w0, w1
    // 0xcef15c: b.eq            #0xcef18c
    // 0xcef160: StoreField: r2->field_73 = r0
    //     0xcef160: stur            w0, [x2, #0x73]
    //     0xcef164: ldurb           w16, [x2, #-1]
    //     0xcef168: ldurb           w17, [x0, #-1]
    //     0xcef16c: and             x16, x17, x16, lsr #2
    //     0xcef170: tst             x16, HEAP, lsr #32
    //     0xcef174: b.eq            #0xcef17c
    //     0xcef178: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcef17c: mov             x1, x2
    // 0xcef180: r0 = markNeedsPaint()
    //     0xcef180: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcef184: ldur            x1, [fp, #-8]
    // 0xcef188: r0 = markNeedsSemanticsUpdate()
    //     0xcef188: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcef18c: r0 = Null
    //     0xcef18c: mov             x0, NULL
    // 0xcef190: LeaveFrame
    //     0xcef190: mov             SP, fp
    //     0xcef194: ldp             fp, lr, [SP], #0x10
    // 0xcef198: ret
    //     0xcef198: ret             
    // 0xcef19c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef19c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef1a0: b               #0xcef150
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ebea8, size: 0x2c
    // 0x10ebea8: EnterFrame
    //     0x10ebea8: stp             fp, lr, [SP, #-0x10]!
    //     0x10ebeac: mov             fp, SP
    // 0x10ebeb0: CheckStackOverflow
    //     0x10ebeb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ebeb4: cmp             SP, x16
    //     0x10ebeb8: b.ls            #0x10ebecc
    // 0x10ebebc: r0 = defaultHitTestChildren()
    //     0x10ebebc: bl              #0x10ebed4  ; [dart:mixin_deduplication] _MixinApplication451&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultHitTestChildren
    // 0x10ebec0: LeaveFrame
    //     0x10ebec0: mov             SP, fp
    //     0x10ebec4: ldp             fp, lr, [SP], #0x10
    // 0x10ebec8: ret
    //     0x10ebec8: ret             
    // 0x10ebecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ebecc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ebed0: b               #0x10ebebc
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f0168, size: 0x24
    // 0x10f0168: EnterFrame
    //     0x10f0168: stp             fp, lr, [SP, #-0x10]!
    //     0x10f016c: mov             fp, SP
    // 0x10f0170: ldr             x2, [fp, #0x10]
    // 0x10f0174: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0174: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa41d8] AnonymousClosure: (0xb24ff4), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicHeight (0xb25618)
    //     0x10f0178: ldr             x1, [x1, #0x1d8]
    // 0x10f017c: r0 = AllocateClosure()
    //     0x10f017c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0180: LeaveFrame
    //     0x10f0180: mov             SP, fp
    //     0x10f0184: ldp             fp, lr, [SP], #0x10
    // 0x10f0188: ret
    //     0x10f0188: ret             
  }
  _ paintStack(/* No info */) {
    // ** addr: 0x119fe4c, size: 0x30
    // 0x119fe4c: EnterFrame
    //     0x119fe4c: stp             fp, lr, [SP, #-0x10]!
    //     0x119fe50: mov             fp, SP
    // 0x119fe54: CheckStackOverflow
    //     0x119fe54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fe58: cmp             SP, x16
    //     0x119fe5c: b.ls            #0x119fe74
    // 0x119fe60: r0 = defaultPaint()
    //     0x119fe60: bl              #0xc26954  ; [dart:mixin_deduplication] _MixinApplication451&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0x119fe64: r0 = Null
    //     0x119fe64: mov             x0, NULL
    // 0x119fe68: LeaveFrame
    //     0x119fe68: mov             SP, fp
    //     0x119fe6c: ldp             fp, lr, [SP], #0x10
    // 0x119fe70: ret
    //     0x119fe70: ret             
    // 0x119fe74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119fe74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119fe78: b               #0x119fe60
  }
  [closure] void paintStack(dynamic, PaintingContext, Offset) {
    // ** addr: 0x119fe7c, size: 0x44
    // 0x119fe7c: EnterFrame
    //     0x119fe7c: stp             fp, lr, [SP, #-0x10]!
    //     0x119fe80: mov             fp, SP
    // 0x119fe84: ldr             x0, [fp, #0x20]
    // 0x119fe88: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x119fe88: ldur            w1, [x0, #0x17]
    // 0x119fe8c: DecompressPointer r1
    //     0x119fe8c: add             x1, x1, HEAP, lsl #32
    // 0x119fe90: CheckStackOverflow
    //     0x119fe90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fe94: cmp             SP, x16
    //     0x119fe98: b.ls            #0x119feb8
    // 0x119fe9c: ldr             x2, [fp, #0x18]
    // 0x119fea0: ldr             x3, [fp, #0x10]
    // 0x119fea4: r0 = defaultPaint()
    //     0x119fea4: bl              #0xc26954  ; [dart:mixin_deduplication] _MixinApplication451&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0x119fea8: r0 = Null
    //     0x119fea8: mov             x0, NULL
    // 0x119feac: LeaveFrame
    //     0x119feac: mov             SP, fp
    //     0x119feb0: ldp             fp, lr, [SP], #0x10
    // 0x119feb4: ret
    //     0x119feb4: ret             
    // 0x119feb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119feb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119febc: b               #0x119fe9c
  }
  _ RenderStack(/* No info */) {
    // ** addr: 0x11ca5e8, size: 0x138
    // 0x11ca5e8: EnterFrame
    //     0x11ca5e8: stp             fp, lr, [SP, #-0x10]!
    //     0x11ca5ec: mov             fp, SP
    // 0x11ca5f0: AllocStack(0x28)
    //     0x11ca5f0: sub             SP, SP, #0x28
    // 0x11ca5f4: r0 = false
    //     0x11ca5f4: add             x0, NULL, #0x30  ; false
    // 0x11ca5f8: mov             x4, x3
    // 0x11ca5fc: stur            x3, [fp, #-0x18]
    // 0x11ca600: mov             x3, x5
    // 0x11ca604: stur            x5, [fp, #-0x20]
    // 0x11ca608: mov             x5, x2
    // 0x11ca60c: stur            x2, [fp, #-0x10]
    // 0x11ca610: mov             x2, x6
    // 0x11ca614: stur            x6, [fp, #-0x28]
    // 0x11ca618: mov             x6, x1
    // 0x11ca61c: stur            x1, [fp, #-8]
    // 0x11ca620: CheckStackOverflow
    //     0x11ca620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ca624: cmp             SP, x16
    //     0x11ca628: b.ls            #0x11ca718
    // 0x11ca62c: StoreField: r6->field_5f = r0
    //     0x11ca62c: stur            w0, [x6, #0x5f]
    // 0x11ca630: r1 = <ClipRectLayer>
    //     0x11ca630: add             x1, PP, #0x84, lsl #12  ; [pp+0x84fc8] TypeArguments: <ClipRectLayer>
    //     0x11ca634: ldr             x1, [x1, #0xfc8]
    // 0x11ca638: r0 = LayerHandle()
    //     0x11ca638: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11ca63c: ldur            x1, [fp, #-8]
    // 0x11ca640: StoreField: r1->field_77 = r0
    //     0x11ca640: stur            w0, [x1, #0x77]
    //     0x11ca644: ldurb           w16, [x1, #-1]
    //     0x11ca648: ldurb           w17, [x0, #-1]
    //     0x11ca64c: and             x16, x17, x16, lsr #2
    //     0x11ca650: tst             x16, HEAP, lsr #32
    //     0x11ca654: b.eq            #0x11ca65c
    //     0x11ca658: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca65c: ldur            x0, [fp, #-0x10]
    // 0x11ca660: StoreField: r1->field_67 = r0
    //     0x11ca660: stur            w0, [x1, #0x67]
    //     0x11ca664: ldurb           w16, [x1, #-1]
    //     0x11ca668: ldurb           w17, [x0, #-1]
    //     0x11ca66c: and             x16, x17, x16, lsr #2
    //     0x11ca670: tst             x16, HEAP, lsr #32
    //     0x11ca674: b.eq            #0x11ca67c
    //     0x11ca678: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca67c: ldur            x0, [fp, #-0x28]
    // 0x11ca680: StoreField: r1->field_6b = r0
    //     0x11ca680: stur            w0, [x1, #0x6b]
    //     0x11ca684: ldurb           w16, [x1, #-1]
    //     0x11ca688: ldurb           w17, [x0, #-1]
    //     0x11ca68c: and             x16, x17, x16, lsr #2
    //     0x11ca690: tst             x16, HEAP, lsr #32
    //     0x11ca694: b.eq            #0x11ca69c
    //     0x11ca698: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca69c: ldur            x0, [fp, #-0x20]
    // 0x11ca6a0: StoreField: r1->field_6f = r0
    //     0x11ca6a0: stur            w0, [x1, #0x6f]
    //     0x11ca6a4: ldurb           w16, [x1, #-1]
    //     0x11ca6a8: ldurb           w17, [x0, #-1]
    //     0x11ca6ac: and             x16, x17, x16, lsr #2
    //     0x11ca6b0: tst             x16, HEAP, lsr #32
    //     0x11ca6b4: b.eq            #0x11ca6bc
    //     0x11ca6b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca6bc: ldur            x0, [fp, #-0x18]
    // 0x11ca6c0: StoreField: r1->field_73 = r0
    //     0x11ca6c0: stur            w0, [x1, #0x73]
    //     0x11ca6c4: ldurb           w16, [x1, #-1]
    //     0x11ca6c8: ldurb           w17, [x0, #-1]
    //     0x11ca6cc: and             x16, x17, x16, lsr #2
    //     0x11ca6d0: tst             x16, HEAP, lsr #32
    //     0x11ca6d4: b.eq            #0x11ca6dc
    //     0x11ca6d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca6dc: StoreField: r1->field_4f = rZR
    //     0x11ca6dc: stur            xzr, [x1, #0x4f]
    // 0x11ca6e0: r0 = _LayoutCacheStorage()
    //     0x11ca6e0: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11ca6e4: ldur            x1, [fp, #-8]
    // 0x11ca6e8: StoreField: r1->field_47 = r0
    //     0x11ca6e8: stur            w0, [x1, #0x47]
    //     0x11ca6ec: ldurb           w16, [x1, #-1]
    //     0x11ca6f0: ldurb           w17, [x0, #-1]
    //     0x11ca6f4: and             x16, x17, x16, lsr #2
    //     0x11ca6f8: tst             x16, HEAP, lsr #32
    //     0x11ca6fc: b.eq            #0x11ca704
    //     0x11ca700: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11ca704: r0 = RenderObject()
    //     0x11ca704: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11ca708: r0 = Null
    //     0x11ca708: mov             x0, NULL
    // 0x11ca70c: LeaveFrame
    //     0x11ca70c: mov             SP, fp
    //     0x11ca710: ldp             fp, lr, [SP], #0x10
    // 0x11ca714: ret
    //     0x11ca714: ret             
    // 0x11ca718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ca718: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ca71c: b               #0x11ca62c
  }
  dynamic paintStack(dynamic) {
    // ** addr: 0x11f0e98, size: 0x24
    // 0x11f0e98: EnterFrame
    //     0x11f0e98: stp             fp, lr, [SP, #-0x10]!
    //     0x11f0e9c: mov             fp, SP
    // 0x11f0ea0: ldr             x2, [fp, #0x10]
    // 0x11f0ea4: r1 = Function 'paintStack':.
    //     0x11f0ea4: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a168] AnonymousClosure: (0x119fe7c), in [package:flutter/src/rendering/stack.dart] RenderStack::paintStack (0x119fe4c)
    //     0x11f0ea8: ldr             x1, [x1, #0x168]
    // 0x11f0eac: r0 = AllocateClosure()
    //     0x11f0eac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11f0eb0: LeaveFrame
    //     0x11f0eb0: mov             SP, fp
    //     0x11f0eb4: ldp             fp, lr, [SP], #0x10
    // 0x11f0eb8: ret
    //     0x11f0eb8: ret             
  }
}

// class id: 4824, size: 0x80, field offset: 0x7c
class RenderIndexedStack extends RenderStack {

  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5bbf4, size: 0xc8
    // 0xb5bbf4: EnterFrame
    //     0xb5bbf4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5bbf8: mov             fp, SP
    // 0xb5bbfc: AllocStack(0x18)
    //     0xb5bbfc: sub             SP, SP, #0x18
    // 0xb5bc00: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xb5bc00: stur            x2, [fp, #-8]
    // 0xb5bc04: CheckStackOverflow
    //     0xb5bc04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5bc08: cmp             SP, x16
    //     0xb5bc0c: b.ls            #0xb5bcb0
    // 0xb5bc10: r0 = _childAtIndex()
    //     0xb5bc10: bl              #0xb5bcbc  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0xb5bc14: mov             x3, x0
    // 0xb5bc18: stur            x3, [fp, #-0x18]
    // 0xb5bc1c: cmp             w3, NULL
    // 0xb5bc20: b.ne            #0xb5bc34
    // 0xb5bc24: r0 = Null
    //     0xb5bc24: mov             x0, NULL
    // 0xb5bc28: LeaveFrame
    //     0xb5bc28: mov             SP, fp
    //     0xb5bc2c: ldp             fp, lr, [SP], #0x10
    // 0xb5bc30: ret
    //     0xb5bc30: ret             
    // 0xb5bc34: LoadField: r4 = r3->field_7
    //     0xb5bc34: ldur            w4, [x3, #7]
    // 0xb5bc38: DecompressPointer r4
    //     0xb5bc38: add             x4, x4, HEAP, lsl #32
    // 0xb5bc3c: stur            x4, [fp, #-0x10]
    // 0xb5bc40: cmp             w4, NULL
    // 0xb5bc44: b.eq            #0xb5bcb8
    // 0xb5bc48: mov             x0, x4
    // 0xb5bc4c: r2 = Null
    //     0xb5bc4c: mov             x2, NULL
    // 0xb5bc50: r1 = Null
    //     0xb5bc50: mov             x1, NULL
    // 0xb5bc54: r4 = LoadClassIdInstr(r0)
    //     0xb5bc54: ldur            x4, [x0, #-1]
    //     0xb5bc58: ubfx            x4, x4, #0xc, #0x14
    // 0xb5bc5c: r17 = -4208
    //     0xb5bc5c: mov             x17, #-0x1070
    // 0xb5bc60: add             x4, x4, x17
    // 0xb5bc64: cmp             x4, #2
    // 0xb5bc68: b.ls            #0xb5bc80
    // 0xb5bc6c: r8 = StackParentData
    //     0xb5bc6c: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0xb5bc70: ldr             x8, [x8, #0xaa8]
    // 0xb5bc74: r3 = Null
    //     0xb5bc74: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a240] Null
    //     0xb5bc78: ldr             x3, [x3, #0x240]
    // 0xb5bc7c: r0 = DefaultTypeTest()
    //     0xb5bc7c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb5bc80: ldur            x1, [fp, #-0x18]
    // 0xb5bc84: ldur            x2, [fp, #-8]
    // 0xb5bc88: r0 = getDistanceToActualBaseline()
    //     0xb5bc88: bl              #0xb53d74  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0xb5bc8c: mov             x1, x0
    // 0xb5bc90: ldur            x0, [fp, #-0x10]
    // 0xb5bc94: LoadField: r2 = r0->field_7
    //     0xb5bc94: ldur            w2, [x0, #7]
    // 0xb5bc98: DecompressPointer r2
    //     0xb5bc98: add             x2, x2, HEAP, lsl #32
    // 0xb5bc9c: LoadField: d0 = r2->field_f
    //     0xb5bc9c: ldur            d0, [x2, #0xf]
    // 0xb5bca0: r0 = BaselineOffset.+()
    //     0xb5bca0: bl              #0xb5b044  ; [package:flutter/src/rendering/box.dart] ::BaselineOffset.+
    // 0xb5bca4: LeaveFrame
    //     0xb5bca4: mov             SP, fp
    //     0xb5bca8: ldp             fp, lr, [SP], #0x10
    // 0xb5bcac: ret
    //     0xb5bcac: ret             
    // 0xb5bcb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5bcb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5bcb4: b               #0xb5bc10
    // 0xb5bcb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5bcb8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _childAtIndex(/* No info */) {
    // ** addr: 0xb5bcbc, size: 0xec
    // 0xb5bcbc: EnterFrame
    //     0xb5bcbc: stp             fp, lr, [SP, #-0x10]!
    //     0xb5bcc0: mov             fp, SP
    // 0xb5bcc4: AllocStack(0x18)
    //     0xb5bcc4: sub             SP, SP, #0x18
    // 0xb5bcc8: LoadField: r0 = r1->field_7b
    //     0xb5bcc8: ldur            w0, [x1, #0x7b]
    // 0xb5bccc: DecompressPointer r0
    //     0xb5bccc: add             x0, x0, HEAP, lsl #32
    // 0xb5bcd0: cmp             w0, NULL
    // 0xb5bcd4: b.ne            #0xb5bce8
    // 0xb5bcd8: r0 = Null
    //     0xb5bcd8: mov             x0, NULL
    // 0xb5bcdc: LeaveFrame
    //     0xb5bcdc: mov             SP, fp
    //     0xb5bce0: ldp             fp, lr, [SP], #0x10
    // 0xb5bce4: ret
    //     0xb5bce4: ret             
    // 0xb5bce8: LoadField: r2 = r1->field_57
    //     0xb5bce8: ldur            w2, [x1, #0x57]
    // 0xb5bcec: DecompressPointer r2
    //     0xb5bcec: add             x2, x2, HEAP, lsl #32
    // 0xb5bcf0: r3 = LoadInt32Instr(r0)
    //     0xb5bcf0: sbfx            x3, x0, #1, #0x1f
    //     0xb5bcf4: tbz             w0, #0, #0xb5bcfc
    //     0xb5bcf8: ldur            x3, [x0, #7]
    // 0xb5bcfc: stur            x3, [fp, #-0x18]
    // 0xb5bd00: mov             x0, x2
    // 0xb5bd04: r4 = 0
    //     0xb5bd04: mov             x4, #0
    // 0xb5bd08: stur            x4, [fp, #-0x10]
    // 0xb5bd0c: CheckStackOverflow
    //     0xb5bd0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5bd10: cmp             SP, x16
    //     0xb5bd14: b.ls            #0xb5bd9c
    // 0xb5bd18: cmp             x4, x3
    // 0xb5bd1c: b.ge            #0xb5bd90
    // 0xb5bd20: cmp             w0, NULL
    // 0xb5bd24: b.eq            #0xb5bd90
    // 0xb5bd28: LoadField: r5 = r0->field_7
    //     0xb5bd28: ldur            w5, [x0, #7]
    // 0xb5bd2c: DecompressPointer r5
    //     0xb5bd2c: add             x5, x5, HEAP, lsl #32
    // 0xb5bd30: stur            x5, [fp, #-8]
    // 0xb5bd34: cmp             w5, NULL
    // 0xb5bd38: b.eq            #0xb5bda4
    // 0xb5bd3c: mov             x0, x5
    // 0xb5bd40: r2 = Null
    //     0xb5bd40: mov             x2, NULL
    // 0xb5bd44: r1 = Null
    //     0xb5bd44: mov             x1, NULL
    // 0xb5bd48: r4 = LoadClassIdInstr(r0)
    //     0xb5bd48: ldur            x4, [x0, #-1]
    //     0xb5bd4c: ubfx            x4, x4, #0xc, #0x14
    // 0xb5bd50: r17 = -4208
    //     0xb5bd50: mov             x17, #-0x1070
    // 0xb5bd54: add             x4, x4, x17
    // 0xb5bd58: cmp             x4, #2
    // 0xb5bd5c: b.ls            #0xb5bd74
    // 0xb5bd60: r8 = StackParentData
    //     0xb5bd60: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0xb5bd64: ldr             x8, [x8, #0xaa8]
    // 0xb5bd68: r3 = Null
    //     0xb5bd68: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a208] Null
    //     0xb5bd6c: ldr             x3, [x3, #0x208]
    // 0xb5bd70: r0 = DefaultTypeTest()
    //     0xb5bd70: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb5bd74: ldur            x1, [fp, #-8]
    // 0xb5bd78: LoadField: r0 = r1->field_13
    //     0xb5bd78: ldur            w0, [x1, #0x13]
    // 0xb5bd7c: DecompressPointer r0
    //     0xb5bd7c: add             x0, x0, HEAP, lsl #32
    // 0xb5bd80: ldur            x1, [fp, #-0x10]
    // 0xb5bd84: add             x4, x1, #1
    // 0xb5bd88: ldur            x3, [fp, #-0x18]
    // 0xb5bd8c: b               #0xb5bd08
    // 0xb5bd90: LeaveFrame
    //     0xb5bd90: mov             SP, fp
    //     0xb5bd94: ldp             fp, lr, [SP], #0x10
    // 0xb5bd98: ret
    //     0xb5bd98: ret             
    // 0xb5bd9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5bd9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5bda0: b               #0xb5bd18
    // 0xb5bda4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5bda4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb64870, size: 0x14c
    // 0xb64870: EnterFrame
    //     0xb64870: stp             fp, lr, [SP, #-0x10]!
    //     0xb64874: mov             fp, SP
    // 0xb64878: AllocStack(0x38)
    //     0xb64878: sub             SP, SP, #0x38
    // 0xb6487c: SetupParameters(RenderIndexedStack this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r6, fp-0x18 */)
    //     0xb6487c: mov             x4, x1
    //     0xb64880: mov             x6, x3
    //     0xb64884: stur            x3, [fp, #-0x18]
    //     0xb64888: mov             x3, x2
    //     0xb6488c: stur            x1, [fp, #-8]
    //     0xb64890: stur            x2, [fp, #-0x10]
    // 0xb64894: CheckStackOverflow
    //     0xb64894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb64898: cmp             SP, x16
    //     0xb6489c: b.ls            #0xb649b4
    // 0xb648a0: mov             x0, x3
    // 0xb648a4: r2 = Null
    //     0xb648a4: mov             x2, NULL
    // 0xb648a8: r1 = Null
    //     0xb648a8: mov             x1, NULL
    // 0xb648ac: r4 = 60
    //     0xb648ac: mov             x4, #0x3c
    // 0xb648b0: branchIfSmi(r0, 0xb648bc)
    //     0xb648b0: tbz             w0, #0, #0xb648bc
    // 0xb648b4: r4 = LoadClassIdInstr(r0)
    //     0xb648b4: ldur            x4, [x0, #-1]
    //     0xb648b8: ubfx            x4, x4, #0xc, #0x14
    // 0xb648bc: sub             x4, x4, #0xb46
    // 0xb648c0: cmp             x4, #1
    // 0xb648c4: b.ls            #0xb648d8
    // 0xb648c8: r8 = BoxConstraints
    //     0xb648c8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb648cc: r3 = Null
    //     0xb648cc: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a230] Null
    //     0xb648d0: ldr             x3, [x3, #0x230]
    // 0xb648d4: r0 = BoxConstraints()
    //     0xb648d4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb648d8: ldur            x1, [fp, #-8]
    // 0xb648dc: r0 = _childAtIndex()
    //     0xb648dc: bl              #0xb5bcbc  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0xb648e0: stur            x0, [fp, #-0x20]
    // 0xb648e4: cmp             w0, NULL
    // 0xb648e8: b.ne            #0xb648fc
    // 0xb648ec: r0 = Null
    //     0xb648ec: mov             x0, NULL
    // 0xb648f0: LeaveFrame
    //     0xb648f0: mov             SP, fp
    //     0xb648f4: ldp             fp, lr, [SP], #0x10
    // 0xb648f8: ret
    //     0xb648f8: ret             
    // 0xb648fc: ldur            x2, [fp, #-8]
    // 0xb64900: LoadField: r1 = r2->field_6f
    //     0xb64900: ldur            w1, [x2, #0x6f]
    // 0xb64904: DecompressPointer r1
    //     0xb64904: add             x1, x1, HEAP, lsl #32
    // 0xb64908: LoadField: r3 = r1->field_7
    //     0xb64908: ldur            x3, [x1, #7]
    // 0xb6490c: cmp             x3, #1
    // 0xb64910: b.gt            #0xb64970
    // 0xb64914: cmp             x3, #0
    // 0xb64918: b.gt            #0xb6492c
    // 0xb6491c: ldur            x1, [fp, #-0x10]
    // 0xb64920: r0 = loosen()
    //     0xb64920: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xb64924: mov             x3, x0
    // 0xb64928: b               #0xb64974
    // 0xb6492c: ldur            x1, [fp, #-0x10]
    // 0xb64930: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb64930: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb64934: r0 = constrainWidth()
    //     0xb64934: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb64938: ldur            x1, [fp, #-0x10]
    // 0xb6493c: stur            d0, [fp, #-0x30]
    // 0xb64940: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb64940: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb64944: r0 = constrainHeight()
    //     0xb64944: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb64948: stur            d0, [fp, #-0x38]
    // 0xb6494c: r0 = BoxConstraints()
    //     0xb6494c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb64950: ldur            d0, [fp, #-0x30]
    // 0xb64954: StoreField: r0->field_7 = d0
    //     0xb64954: stur            d0, [x0, #7]
    // 0xb64958: StoreField: r0->field_f = d0
    //     0xb64958: stur            d0, [x0, #0xf]
    // 0xb6495c: ldur            d0, [fp, #-0x38]
    // 0xb64960: ArrayStore: r0[0] = d0  ; List_8
    //     0xb64960: stur            d0, [x0, #0x17]
    // 0xb64964: StoreField: r0->field_1f = d0
    //     0xb64964: stur            d0, [x0, #0x1f]
    // 0xb64968: mov             x3, x0
    // 0xb6496c: b               #0xb64974
    // 0xb64970: ldur            x3, [fp, #-0x10]
    // 0xb64974: ldur            x1, [fp, #-8]
    // 0xb64978: stur            x3, [fp, #-0x28]
    // 0xb6497c: r0 = _resolvedAlignment()
    //     0xb6497c: bl              #0xb64be4  ; [package:flutter/src/rendering/stack.dart] RenderStack::_resolvedAlignment
    // 0xb64980: ldur            x1, [fp, #-8]
    // 0xb64984: ldur            x2, [fp, #-0x10]
    // 0xb64988: stur            x0, [fp, #-8]
    // 0xb6498c: r0 = getDryLayout()
    //     0xb6498c: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb64990: ldur            x1, [fp, #-0x20]
    // 0xb64994: mov             x2, x0
    // 0xb64998: ldur            x3, [fp, #-0x28]
    // 0xb6499c: ldur            x5, [fp, #-8]
    // 0xb649a0: ldur            x6, [fp, #-0x18]
    // 0xb649a4: r0 = _baselineForChild()
    //     0xb649a4: bl              #0xb649bc  ; [package:flutter/src/rendering/stack.dart] RenderStack::_baselineForChild
    // 0xb649a8: LeaveFrame
    //     0xb649a8: mov             SP, fp
    //     0xb649ac: ldp             fp, lr, [SP], #0x10
    // 0xb649b0: ret
    //     0xb649b0: ret             
    // 0xb649b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb649b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb649b8: b               #0xb648a0
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbec718, size: 0x5c
    // 0xbec718: EnterFrame
    //     0xbec718: stp             fp, lr, [SP, #-0x10]!
    //     0xbec71c: mov             fp, SP
    // 0xbec720: AllocStack(0x18)
    //     0xbec720: sub             SP, SP, #0x18
    // 0xbec724: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xbec724: mov             x0, x2
    //     0xbec728: stur            x2, [fp, #-8]
    // 0xbec72c: CheckStackOverflow
    //     0xbec72c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec730: cmp             SP, x16
    //     0xbec734: b.ls            #0xbec76c
    // 0xbec738: r0 = _childAtIndex()
    //     0xbec738: bl              #0xb5bcbc  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0xbec73c: cmp             w0, NULL
    // 0xbec740: b.eq            #0xbec75c
    // 0xbec744: ldur            x16, [fp, #-8]
    // 0xbec748: stp             x0, x16, [SP]
    // 0xbec74c: ldur            x0, [fp, #-8]
    // 0xbec750: ClosureCall
    //     0xbec750: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbec754: ldur            x2, [x0, #0x1f]
    //     0xbec758: blr             x2
    // 0xbec75c: r0 = Null
    //     0xbec75c: mov             x0, NULL
    // 0xbec760: LeaveFrame
    //     0xbec760: mov             SP, fp
    //     0xbec764: ldp             fp, lr, [SP], #0x10
    // 0xbec768: ret
    //     0xbec768: ret             
    // 0xbec76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec76c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec770: b               #0xbec738
  }
  set _ index=(/* No info */) {
    // ** addr: 0xcef1a4, size: 0x9c
    // 0xcef1a4: EnterFrame
    //     0xcef1a4: stp             fp, lr, [SP, #-0x10]!
    //     0xcef1a8: mov             fp, SP
    // 0xcef1ac: mov             x0, x2
    // 0xcef1b0: CheckStackOverflow
    //     0xcef1b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef1b4: cmp             SP, x16
    //     0xcef1b8: b.ls            #0xcef238
    // 0xcef1bc: LoadField: r2 = r1->field_7b
    //     0xcef1bc: ldur            w2, [x1, #0x7b]
    // 0xcef1c0: DecompressPointer r2
    //     0xcef1c0: add             x2, x2, HEAP, lsl #32
    // 0xcef1c4: cmp             w2, w0
    // 0xcef1c8: b.eq            #0xcef228
    // 0xcef1cc: and             w16, w2, w0
    // 0xcef1d0: branchIfSmi(r16, 0xcef204)
    //     0xcef1d0: tbz             w16, #0, #0xcef204
    // 0xcef1d4: r16 = LoadClassIdInstr(r2)
    //     0xcef1d4: ldur            x16, [x2, #-1]
    //     0xcef1d8: ubfx            x16, x16, #0xc, #0x14
    // 0xcef1dc: cmp             x16, #0x3d
    // 0xcef1e0: b.ne            #0xcef204
    // 0xcef1e4: r16 = LoadClassIdInstr(r0)
    //     0xcef1e4: ldur            x16, [x0, #-1]
    //     0xcef1e8: ubfx            x16, x16, #0xc, #0x14
    // 0xcef1ec: cmp             x16, #0x3d
    // 0xcef1f0: b.ne            #0xcef204
    // 0xcef1f4: LoadField: r16 = r2->field_7
    //     0xcef1f4: ldur            x16, [x2, #7]
    // 0xcef1f8: LoadField: r17 = r0->field_7
    //     0xcef1f8: ldur            x17, [x0, #7]
    // 0xcef1fc: cmp             x16, x17
    // 0xcef200: b.eq            #0xcef228
    // 0xcef204: StoreField: r1->field_7b = r0
    //     0xcef204: stur            w0, [x1, #0x7b]
    //     0xcef208: tbz             w0, #0, #0xcef224
    //     0xcef20c: ldurb           w16, [x1, #-1]
    //     0xcef210: ldurb           w17, [x0, #-1]
    //     0xcef214: and             x16, x17, x16, lsr #2
    //     0xcef218: tst             x16, HEAP, lsr #32
    //     0xcef21c: b.eq            #0xcef224
    //     0xcef220: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcef224: r0 = markNeedsLayout()
    //     0xcef224: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcef228: r0 = Null
    //     0xcef228: mov             x0, NULL
    // 0xcef22c: LeaveFrame
    //     0xcef22c: mov             SP, fp
    //     0xcef230: ldp             fp, lr, [SP], #0x10
    // 0xcef234: ret
    //     0xcef234: ret             
    // 0xcef238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef238: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef23c: b               #0xcef1bc
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ebdb0, size: 0xf8
    // 0x10ebdb0: EnterFrame
    //     0x10ebdb0: stp             fp, lr, [SP, #-0x10]!
    //     0x10ebdb4: mov             fp, SP
    // 0x10ebdb8: AllocStack(0x28)
    //     0x10ebdb8: sub             SP, SP, #0x28
    // 0x10ebdbc: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r5, fp-0x10 */)
    //     0x10ebdbc: mov             x0, x2
    //     0x10ebdc0: mov             x5, x3
    //     0x10ebdc4: stur            x2, [fp, #-8]
    //     0x10ebdc8: stur            x3, [fp, #-0x10]
    // 0x10ebdcc: CheckStackOverflow
    //     0x10ebdcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ebdd0: cmp             SP, x16
    //     0x10ebdd4: b.ls            #0x10ebe9c
    // 0x10ebdd8: r0 = _childAtIndex()
    //     0x10ebdd8: bl              #0xb5bcbc  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0x10ebddc: stur            x0, [fp, #-0x18]
    // 0x10ebde0: r1 = 1
    //     0x10ebde0: mov             x1, #1
    // 0x10ebde4: r0 = AllocateContext()
    //     0x10ebde4: bl              #0x13de838  ; AllocateContextStub
    // 0x10ebde8: mov             x3, x0
    // 0x10ebdec: ldur            x0, [fp, #-0x18]
    // 0x10ebdf0: stur            x3, [fp, #-0x28]
    // 0x10ebdf4: StoreField: r3->field_f = r0
    //     0x10ebdf4: stur            w0, [x3, #0xf]
    // 0x10ebdf8: cmp             w0, NULL
    // 0x10ebdfc: b.ne            #0x10ebe10
    // 0x10ebe00: r0 = false
    //     0x10ebe00: add             x0, NULL, #0x30  ; false
    // 0x10ebe04: LeaveFrame
    //     0x10ebe04: mov             SP, fp
    //     0x10ebe08: ldp             fp, lr, [SP], #0x10
    // 0x10ebe0c: ret
    //     0x10ebe0c: ret             
    // 0x10ebe10: LoadField: r4 = r0->field_7
    //     0x10ebe10: ldur            w4, [x0, #7]
    // 0x10ebe14: DecompressPointer r4
    //     0x10ebe14: add             x4, x4, HEAP, lsl #32
    // 0x10ebe18: stur            x4, [fp, #-0x20]
    // 0x10ebe1c: cmp             w4, NULL
    // 0x10ebe20: b.eq            #0x10ebea4
    // 0x10ebe24: mov             x0, x4
    // 0x10ebe28: r2 = Null
    //     0x10ebe28: mov             x2, NULL
    // 0x10ebe2c: r1 = Null
    //     0x10ebe2c: mov             x1, NULL
    // 0x10ebe30: r4 = LoadClassIdInstr(r0)
    //     0x10ebe30: ldur            x4, [x0, #-1]
    //     0x10ebe34: ubfx            x4, x4, #0xc, #0x14
    // 0x10ebe38: r17 = -4208
    //     0x10ebe38: mov             x17, #-0x1070
    // 0x10ebe3c: add             x4, x4, x17
    // 0x10ebe40: cmp             x4, #2
    // 0x10ebe44: b.ls            #0x10ebe5c
    // 0x10ebe48: r8 = StackParentData
    //     0x10ebe48: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0x10ebe4c: ldr             x8, [x8, #0xaa8]
    // 0x10ebe50: r3 = Null
    //     0x10ebe50: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a218] Null
    //     0x10ebe54: ldr             x3, [x3, #0x218]
    // 0x10ebe58: r0 = DefaultTypeTest()
    //     0x10ebe58: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10ebe5c: ldur            x0, [fp, #-0x20]
    // 0x10ebe60: LoadField: r3 = r0->field_7
    //     0x10ebe60: ldur            w3, [x0, #7]
    // 0x10ebe64: DecompressPointer r3
    //     0x10ebe64: add             x3, x3, HEAP, lsl #32
    // 0x10ebe68: ldur            x2, [fp, #-0x28]
    // 0x10ebe6c: stur            x3, [fp, #-0x18]
    // 0x10ebe70: r1 = Function '<anonymous closure>':.
    //     0x10ebe70: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a228] AnonymousClosure: (0x10e9b40), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x10e9a40)
    //     0x10ebe74: ldr             x1, [x1, #0x228]
    // 0x10ebe78: r0 = AllocateClosure()
    //     0x10ebe78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10ebe7c: ldur            x1, [fp, #-8]
    // 0x10ebe80: mov             x2, x0
    // 0x10ebe84: ldur            x3, [fp, #-0x18]
    // 0x10ebe88: ldur            x5, [fp, #-0x10]
    // 0x10ebe8c: r0 = addWithPaintOffset()
    //     0x10ebe8c: bl              #0xaf9d3c  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x10ebe90: LeaveFrame
    //     0x10ebe90: mov             SP, fp
    //     0x10ebe94: ldp             fp, lr, [SP], #0x10
    // 0x10ebe98: ret
    //     0x10ebe98: ret             
    // 0x10ebe9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ebe9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ebea0: b               #0x10ebdd8
    // 0x10ebea4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10ebea4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintStack(/* No info */) {
    // ** addr: 0x119fd34, size: 0xd8
    // 0x119fd34: EnterFrame
    //     0x119fd34: stp             fp, lr, [SP, #-0x10]!
    //     0x119fd38: mov             fp, SP
    // 0x119fd3c: AllocStack(0x20)
    //     0x119fd3c: sub             SP, SP, #0x20
    // 0x119fd40: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */, dynamic _ /* r3 => r2, fp-0x10 */)
    //     0x119fd40: mov             x0, x2
    //     0x119fd44: stur            x2, [fp, #-8]
    //     0x119fd48: mov             x2, x3
    //     0x119fd4c: stur            x3, [fp, #-0x10]
    // 0x119fd50: CheckStackOverflow
    //     0x119fd50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fd54: cmp             SP, x16
    //     0x119fd58: b.ls            #0x119fe00
    // 0x119fd5c: r0 = _childAtIndex()
    //     0x119fd5c: bl              #0xb5bcbc  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::_childAtIndex
    // 0x119fd60: mov             x3, x0
    // 0x119fd64: stur            x3, [fp, #-0x20]
    // 0x119fd68: cmp             w3, NULL
    // 0x119fd6c: b.ne            #0x119fd80
    // 0x119fd70: r0 = Null
    //     0x119fd70: mov             x0, NULL
    // 0x119fd74: LeaveFrame
    //     0x119fd74: mov             SP, fp
    //     0x119fd78: ldp             fp, lr, [SP], #0x10
    // 0x119fd7c: ret
    //     0x119fd7c: ret             
    // 0x119fd80: LoadField: r4 = r3->field_7
    //     0x119fd80: ldur            w4, [x3, #7]
    // 0x119fd84: DecompressPointer r4
    //     0x119fd84: add             x4, x4, HEAP, lsl #32
    // 0x119fd88: stur            x4, [fp, #-0x18]
    // 0x119fd8c: cmp             w4, NULL
    // 0x119fd90: b.eq            #0x119fe08
    // 0x119fd94: mov             x0, x4
    // 0x119fd98: r2 = Null
    //     0x119fd98: mov             x2, NULL
    // 0x119fd9c: r1 = Null
    //     0x119fd9c: mov             x1, NULL
    // 0x119fda0: r4 = LoadClassIdInstr(r0)
    //     0x119fda0: ldur            x4, [x0, #-1]
    //     0x119fda4: ubfx            x4, x4, #0xc, #0x14
    // 0x119fda8: r17 = -4208
    //     0x119fda8: mov             x17, #-0x1070
    // 0x119fdac: add             x4, x4, x17
    // 0x119fdb0: cmp             x4, #2
    // 0x119fdb4: b.ls            #0x119fdcc
    // 0x119fdb8: r8 = StackParentData
    //     0x119fdb8: add             x8, PP, #0x81, lsl #12  ; [pp+0x81aa8] Type: StackParentData
    //     0x119fdbc: ldr             x8, [x8, #0xaa8]
    // 0x119fdc0: r3 = Null
    //     0x119fdc0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a1f8] Null
    //     0x119fdc4: ldr             x3, [x3, #0x1f8]
    // 0x119fdc8: r0 = DefaultTypeTest()
    //     0x119fdc8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x119fdcc: ldur            x0, [fp, #-0x18]
    // 0x119fdd0: LoadField: r1 = r0->field_7
    //     0x119fdd0: ldur            w1, [x0, #7]
    // 0x119fdd4: DecompressPointer r1
    //     0x119fdd4: add             x1, x1, HEAP, lsl #32
    // 0x119fdd8: ldur            x2, [fp, #-0x10]
    // 0x119fddc: r0 = +()
    //     0x119fddc: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0x119fde0: ldur            x1, [fp, #-8]
    // 0x119fde4: ldur            x2, [fp, #-0x20]
    // 0x119fde8: mov             x3, x0
    // 0x119fdec: r0 = paintChild()
    //     0x119fdec: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x119fdf0: r0 = Null
    //     0x119fdf0: mov             x0, NULL
    // 0x119fdf4: LeaveFrame
    //     0x119fdf4: mov             SP, fp
    //     0x119fdf8: ldp             fp, lr, [SP], #0x10
    // 0x119fdfc: ret
    //     0x119fdfc: ret             
    // 0x119fe00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119fe00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119fe04: b               #0x119fd5c
    // 0x119fe08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x119fe08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void paintStack(dynamic, PaintingContext, Offset) {
    // ** addr: 0x119fe0c, size: 0x40
    // 0x119fe0c: EnterFrame
    //     0x119fe0c: stp             fp, lr, [SP, #-0x10]!
    //     0x119fe10: mov             fp, SP
    // 0x119fe14: ldr             x0, [fp, #0x20]
    // 0x119fe18: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x119fe18: ldur            w1, [x0, #0x17]
    // 0x119fe1c: DecompressPointer r1
    //     0x119fe1c: add             x1, x1, HEAP, lsl #32
    // 0x119fe20: CheckStackOverflow
    //     0x119fe20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119fe24: cmp             SP, x16
    //     0x119fe28: b.ls            #0x119fe44
    // 0x119fe2c: ldr             x2, [fp, #0x18]
    // 0x119fe30: ldr             x3, [fp, #0x10]
    // 0x119fe34: r0 = paintStack()
    //     0x119fe34: bl              #0x119fd34  ; [package:flutter/src/rendering/stack.dart] RenderIndexedStack::paintStack
    // 0x119fe38: LeaveFrame
    //     0x119fe38: mov             SP, fp
    //     0x119fe3c: ldp             fp, lr, [SP], #0x10
    // 0x119fe40: ret
    //     0x119fe40: ret             
    // 0x119fe44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119fe44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119fe48: b               #0x119fe2c
  }
  dynamic paintStack(dynamic) {
    // ** addr: 0x11f0e74, size: 0x24
    // 0x11f0e74: EnterFrame
    //     0x11f0e74: stp             fp, lr, [SP, #-0x10]!
    //     0x11f0e78: mov             fp, SP
    // 0x11f0e7c: ldr             x2, [fp, #0x10]
    // 0x11f0e80: r1 = Function 'paintStack':.
    //     0x11f0e80: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a1f0] AnonymousClosure: (0x119fe0c), in [package:flutter/src/rendering/stack.dart] RenderIndexedStack::paintStack (0x119fd34)
    //     0x11f0e84: ldr             x1, [x1, #0x1f0]
    // 0x11f0e88: r0 = AllocateClosure()
    //     0x11f0e88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11f0e8c: LeaveFrame
    //     0x11f0e8c: mov             SP, fp
    //     0x11f0e90: ldp             fp, lr, [SP], #0x10
    // 0x11f0e94: ret
    //     0x11f0e94: ret             
  }
}

// class id: 8220, size: 0x14, field offset: 0x14
enum StackFit extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
