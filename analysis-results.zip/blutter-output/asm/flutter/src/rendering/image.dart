// lib: , url: package:flutter/src/rendering/image.dart

// class id: 1049028, size: 0x8
class :: {
}

// class id: 4725, size: 0xa4, field offset: 0x50
class RenderImage extends RenderBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb20fe0, size: 0x24
    // 0xb20fe0: EnterFrame
    //     0xb20fe0: stp             fp, lr, [SP, #-0x10]!
    //     0xb20fe4: mov             fp, SP
    // 0xb20fe8: ldr             x2, [fp, #0x10]
    // 0xb20fec: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb20fec: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1368] AnonymousClosure: (0xb21004), in [package:flutter/src/rendering/image.dart] RenderImage::computeMinIntrinsicWidth (0xb2107c)
    //     0xb20ff0: ldr             x1, [x1, #0x368]
    // 0xb20ff4: r0 = AllocateClosure()
    //     0xb20ff4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb20ff8: LeaveFrame
    //     0xb20ff8: mov             SP, fp
    //     0xb20ffc: ldp             fp, lr, [SP], #0x10
    // 0xb21000: ret
    //     0xb21000: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb21004, size: 0x78
    // 0xb21004: EnterFrame
    //     0xb21004: stp             fp, lr, [SP, #-0x10]!
    //     0xb21008: mov             fp, SP
    // 0xb2100c: ldr             x0, [fp, #0x18]
    // 0xb21010: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb21010: ldur            w1, [x0, #0x17]
    // 0xb21014: DecompressPointer r1
    //     0xb21014: add             x1, x1, HEAP, lsl #32
    // 0xb21018: CheckStackOverflow
    //     0xb21018: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2101c: cmp             SP, x16
    //     0xb21020: b.ls            #0xb21064
    // 0xb21024: ldr             x2, [fp, #0x10]
    // 0xb21028: r0 = computeMinIntrinsicWidth()
    //     0xb21028: bl              #0xb2107c  ; [package:flutter/src/rendering/image.dart] RenderImage::computeMinIntrinsicWidth
    // 0xb2102c: r0 = inline_Allocate_Double()
    //     0xb2102c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb21030: add             x0, x0, #0x10
    //     0xb21034: cmp             x1, x0
    //     0xb21038: b.ls            #0xb2106c
    //     0xb2103c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb21040: sub             x0, x0, #0xf
    //     0xb21044: mov             x1, #0xe19c
    //     0xb21048: movk            x1, #3, lsl #16
    //     0xb2104c: stur            x1, [x0, #-1]
    // 0xb21050: dmb             ishst
    // 0xb21054: StoreField: r0->field_7 = d0
    //     0xb21054: stur            d0, [x0, #7]
    // 0xb21058: LeaveFrame
    //     0xb21058: mov             SP, fp
    //     0xb2105c: ldp             fp, lr, [SP], #0x10
    // 0xb21060: ret
    //     0xb21060: ret             
    // 0xb21064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21064: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21068: b               #0xb21024
    // 0xb2106c: SaveReg d0
    //     0xb2106c: str             q0, [SP, #-0x10]!
    // 0xb21070: r0 = AllocateDouble()
    //     0xb21070: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb21074: RestoreReg d0
    //     0xb21074: ldr             q0, [SP], #0x10
    // 0xb21078: b               #0xb21054
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2107c, size: 0xdc
    // 0xb2107c: EnterFrame
    //     0xb2107c: stp             fp, lr, [SP, #-0x10]!
    //     0xb21080: mov             fp, SP
    // 0xb21084: AllocStack(0x18)
    //     0xb21084: sub             SP, SP, #0x18
    // 0xb21088: SetupParameters(RenderImage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb21088: stur            x1, [fp, #-8]
    //     0xb2108c: stur            x2, [fp, #-0x10]
    // 0xb21090: CheckStackOverflow
    //     0xb21090: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21094: cmp             SP, x16
    //     0xb21098: b.ls            #0xb21150
    // 0xb2109c: LoadField: r0 = r1->field_5f
    //     0xb2109c: ldur            w0, [x1, #0x5f]
    // 0xb210a0: DecompressPointer r0
    //     0xb210a0: add             x0, x0, HEAP, lsl #32
    // 0xb210a4: cmp             w0, NULL
    // 0xb210a8: b.ne            #0xb210cc
    // 0xb210ac: LoadField: r0 = r1->field_63
    //     0xb210ac: ldur            w0, [x1, #0x63]
    // 0xb210b0: DecompressPointer r0
    //     0xb210b0: add             x0, x0, HEAP, lsl #32
    // 0xb210b4: cmp             w0, NULL
    // 0xb210b8: b.ne            #0xb210cc
    // 0xb210bc: d0 = 0.000000
    //     0xb210bc: eor             v0.16b, v0.16b, v0.16b
    // 0xb210c0: LeaveFrame
    //     0xb210c0: mov             SP, fp
    //     0xb210c4: ldp             fp, lr, [SP], #0x10
    // 0xb210c8: ret
    //     0xb210c8: ret             
    // 0xb210cc: d0 = inf
    //     0xb210cc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb210d0: fcmp            d0, d0
    // 0xb210d4: b.eq            #0xb210e0
    // 0xb210d8: d1 = inf
    //     0xb210d8: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb210dc: b               #0xb210e4
    // 0xb210e0: d1 = 0.000000
    //     0xb210e0: eor             v1.16b, v1.16b, v1.16b
    // 0xb210e4: stur            d1, [fp, #-0x18]
    // 0xb210e8: r0 = BoxConstraints()
    //     0xb210e8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb210ec: ldur            d0, [fp, #-0x18]
    // 0xb210f0: StoreField: r0->field_7 = d0
    //     0xb210f0: stur            d0, [x0, #7]
    // 0xb210f4: d0 = inf
    //     0xb210f4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb210f8: StoreField: r0->field_f = d0
    //     0xb210f8: stur            d0, [x0, #0xf]
    // 0xb210fc: ldur            x1, [fp, #-0x10]
    // 0xb21100: LoadField: d1 = r1->field_7
    //     0xb21100: ldur            d1, [x1, #7]
    // 0xb21104: fcmp            d1, d0
    // 0xb21108: b.eq            #0xb21114
    // 0xb2110c: mov             v2.16b, v1.16b
    // 0xb21110: b               #0xb21118
    // 0xb21114: d2 = 0.000000
    //     0xb21114: eor             v2.16b, v2.16b, v2.16b
    // 0xb21118: ArrayStore: r0[0] = d2  ; List_8
    //     0xb21118: stur            d2, [x0, #0x17]
    // 0xb2111c: fcmp            d1, d0
    // 0xb21120: b.eq            #0xb2112c
    // 0xb21124: mov             v0.16b, v1.16b
    // 0xb21128: b               #0xb21130
    // 0xb2112c: d0 = inf
    //     0xb2112c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb21130: StoreField: r0->field_1f = d0
    //     0xb21130: stur            d0, [x0, #0x1f]
    // 0xb21134: ldur            x1, [fp, #-8]
    // 0xb21138: mov             x2, x0
    // 0xb2113c: r0 = _sizeForConstraints()
    //     0xb2113c: bl              #0xb21158  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0xb21140: LoadField: d0 = r0->field_7
    //     0xb21140: ldur            d0, [x0, #7]
    // 0xb21144: LeaveFrame
    //     0xb21144: mov             SP, fp
    //     0xb21148: ldp             fp, lr, [SP], #0x10
    // 0xb2114c: ret
    //     0xb2114c: ret             
    // 0xb21150: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb21150: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb21154: b               #0xb2109c
  }
  _ _sizeForConstraints(/* No info */) {
    // ** addr: 0xb21158, size: 0x1a0
    // 0xb21158: EnterFrame
    //     0xb21158: stp             fp, lr, [SP, #-0x10]!
    //     0xb2115c: mov             fp, SP
    // 0xb21160: AllocStack(0x40)
    //     0xb21160: sub             SP, SP, #0x40
    // 0xb21164: SetupParameters(RenderImage this /* r1 => r1, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xb21164: stur            x1, [fp, #-0x18]
    //     0xb21168: stur            x2, [fp, #-0x20]
    // 0xb2116c: CheckStackOverflow
    //     0xb2116c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb21170: cmp             SP, x16
    //     0xb21174: b.ls            #0xb212ec
    // 0xb21178: LoadField: r0 = r1->field_5f
    //     0xb21178: ldur            w0, [x1, #0x5f]
    // 0xb2117c: DecompressPointer r0
    //     0xb2117c: add             x0, x0, HEAP, lsl #32
    // 0xb21180: stur            x0, [fp, #-0x10]
    // 0xb21184: LoadField: r3 = r1->field_63
    //     0xb21184: ldur            w3, [x1, #0x63]
    // 0xb21188: DecompressPointer r3
    //     0xb21188: add             x3, x3, HEAP, lsl #32
    // 0xb2118c: stur            x3, [fp, #-8]
    // 0xb21190: cmp             w0, NULL
    // 0xb21194: b.ne            #0xb211a0
    // 0xb21198: d0 = 0.000000
    //     0xb21198: eor             v0.16b, v0.16b, v0.16b
    // 0xb2119c: b               #0xb211a4
    // 0xb211a0: LoadField: d0 = r0->field_7
    //     0xb211a0: ldur            d0, [x0, #7]
    // 0xb211a4: stur            d0, [fp, #-0x28]
    // 0xb211a8: r0 = BoxConstraints()
    //     0xb211a8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb211ac: ldur            d0, [fp, #-0x28]
    // 0xb211b0: StoreField: r0->field_7 = d0
    //     0xb211b0: stur            d0, [x0, #7]
    // 0xb211b4: ldur            x1, [fp, #-0x10]
    // 0xb211b8: cmp             w1, NULL
    // 0xb211bc: b.ne            #0xb211c8
    // 0xb211c0: d0 = inf
    //     0xb211c0: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb211c4: b               #0xb211cc
    // 0xb211c8: LoadField: d0 = r1->field_7
    //     0xb211c8: ldur            d0, [x1, #7]
    // 0xb211cc: ldur            x1, [fp, #-8]
    // 0xb211d0: StoreField: r0->field_f = d0
    //     0xb211d0: stur            d0, [x0, #0xf]
    // 0xb211d4: cmp             w1, NULL
    // 0xb211d8: b.ne            #0xb211e4
    // 0xb211dc: d0 = 0.000000
    //     0xb211dc: eor             v0.16b, v0.16b, v0.16b
    // 0xb211e0: b               #0xb211e8
    // 0xb211e4: LoadField: d0 = r1->field_7
    //     0xb211e4: ldur            d0, [x1, #7]
    // 0xb211e8: ArrayStore: r0[0] = d0  ; List_8
    //     0xb211e8: stur            d0, [x0, #0x17]
    // 0xb211ec: cmp             w1, NULL
    // 0xb211f0: b.ne            #0xb211fc
    // 0xb211f4: d0 = inf
    //     0xb211f4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb211f8: b               #0xb21200
    // 0xb211fc: LoadField: d0 = r1->field_7
    //     0xb211fc: ldur            d0, [x1, #7]
    // 0xb21200: ldur            x3, [fp, #-0x18]
    // 0xb21204: StoreField: r0->field_1f = d0
    //     0xb21204: stur            d0, [x0, #0x1f]
    // 0xb21208: mov             x1, x0
    // 0xb2120c: ldur            x2, [fp, #-0x20]
    // 0xb21210: r0 = enforce()
    //     0xb21210: bl              #0xb2154c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0xb21214: mov             x3, x0
    // 0xb21218: ldur            x2, [fp, #-0x18]
    // 0xb2121c: stur            x3, [fp, #-8]
    // 0xb21220: LoadField: r0 = r2->field_57
    //     0xb21220: ldur            w0, [x2, #0x57]
    // 0xb21224: DecompressPointer r0
    //     0xb21224: add             x0, x0, HEAP, lsl #32
    // 0xb21228: cmp             w0, NULL
    // 0xb2122c: b.ne            #0xb21244
    // 0xb21230: mov             x1, x3
    // 0xb21234: r0 = smallest()
    //     0xb21234: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb21238: LeaveFrame
    //     0xb21238: mov             SP, fp
    //     0xb2123c: ldp             fp, lr, [SP], #0x10
    // 0xb21240: ret
    //     0xb21240: ret             
    // 0xb21244: LoadField: r4 = r0->field_f
    //     0xb21244: ldur            x4, [x0, #0xf]
    // 0xb21248: r0 = BoxInt64Instr(r4)
    //     0xb21248: sbfiz           x0, x4, #1, #0x1f
    //     0xb2124c: cmp             x4, x0, asr #1
    //     0xb21250: b.eq            #0xb2125c
    //     0xb21254: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb21258: stur            x4, [x0, #7]
    // 0xb2125c: stp             x0, NULL, [SP]
    // 0xb21260: r0 = _Double.fromInteger()
    //     0xb21260: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xb21264: ldur            x2, [fp, #-0x18]
    // 0xb21268: LoadField: d0 = r2->field_67
    //     0xb21268: ldur            d0, [x2, #0x67]
    // 0xb2126c: LoadField: d1 = r0->field_7
    //     0xb2126c: ldur            d1, [x0, #7]
    // 0xb21270: fdiv            d2, d1, d0
    // 0xb21274: stur            d2, [fp, #-0x28]
    // 0xb21278: LoadField: r0 = r2->field_57
    //     0xb21278: ldur            w0, [x2, #0x57]
    // 0xb2127c: DecompressPointer r0
    //     0xb2127c: add             x0, x0, HEAP, lsl #32
    // 0xb21280: cmp             w0, NULL
    // 0xb21284: b.eq            #0xb212f4
    // 0xb21288: ArrayLoad: r3 = r0[0]  ; List_8
    //     0xb21288: ldur            x3, [x0, #0x17]
    // 0xb2128c: r0 = BoxInt64Instr(r3)
    //     0xb2128c: sbfiz           x0, x3, #1, #0x1f
    //     0xb21290: cmp             x3, x0, asr #1
    //     0xb21294: b.eq            #0xb212a0
    //     0xb21298: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb2129c: stur            x3, [x0, #7]
    // 0xb212a0: stp             x0, NULL, [SP]
    // 0xb212a4: r0 = _Double.fromInteger()
    //     0xb212a4: bl              #0x806648  ; [dart:core] _Double::_Double.fromInteger
    // 0xb212a8: mov             x1, x0
    // 0xb212ac: ldur            x0, [fp, #-0x18]
    // 0xb212b0: LoadField: d0 = r0->field_67
    //     0xb212b0: ldur            d0, [x0, #0x67]
    // 0xb212b4: LoadField: d1 = r1->field_7
    //     0xb212b4: ldur            d1, [x1, #7]
    // 0xb212b8: fdiv            d2, d1, d0
    // 0xb212bc: stur            d2, [fp, #-0x30]
    // 0xb212c0: r0 = Size()
    //     0xb212c0: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb212c4: ldur            d0, [fp, #-0x28]
    // 0xb212c8: StoreField: r0->field_7 = d0
    //     0xb212c8: stur            d0, [x0, #7]
    // 0xb212cc: ldur            d0, [fp, #-0x30]
    // 0xb212d0: StoreField: r0->field_f = d0
    //     0xb212d0: stur            d0, [x0, #0xf]
    // 0xb212d4: ldur            x1, [fp, #-8]
    // 0xb212d8: mov             x2, x0
    // 0xb212dc: r0 = constrainSizeAndAttemptToPreserveAspectRatio()
    //     0xb212dc: bl              #0xb212f8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainSizeAndAttemptToPreserveAspectRatio
    // 0xb212e0: LeaveFrame
    //     0xb212e0: mov             SP, fp
    //     0xb212e4: ldp             fp, lr, [SP], #0x10
    // 0xb212e8: ret
    //     0xb212e8: ret             
    // 0xb212ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb212ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb212f0: b               #0xb21178
    // 0xb212f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb212f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb25fec, size: 0xd4
    // 0xb25fec: EnterFrame
    //     0xb25fec: stp             fp, lr, [SP, #-0x10]!
    //     0xb25ff0: mov             fp, SP
    // 0xb25ff4: AllocStack(0x18)
    //     0xb25ff4: sub             SP, SP, #0x18
    // 0xb25ff8: SetupParameters(RenderImage this /* r1 => r1, fp-0x8 */)
    //     0xb25ff8: stur            x1, [fp, #-8]
    // 0xb25ffc: CheckStackOverflow
    //     0xb25ffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb26000: cmp             SP, x16
    //     0xb26004: b.ls            #0xb260b8
    // 0xb26008: LoadField: r0 = r1->field_5f
    //     0xb26008: ldur            w0, [x1, #0x5f]
    // 0xb2600c: DecompressPointer r0
    //     0xb2600c: add             x0, x0, HEAP, lsl #32
    // 0xb26010: cmp             w0, NULL
    // 0xb26014: b.ne            #0xb26038
    // 0xb26018: LoadField: r0 = r1->field_63
    //     0xb26018: ldur            w0, [x1, #0x63]
    // 0xb2601c: DecompressPointer r0
    //     0xb2601c: add             x0, x0, HEAP, lsl #32
    // 0xb26020: cmp             w0, NULL
    // 0xb26024: b.ne            #0xb26038
    // 0xb26028: d0 = 0.000000
    //     0xb26028: eor             v0.16b, v0.16b, v0.16b
    // 0xb2602c: LeaveFrame
    //     0xb2602c: mov             SP, fp
    //     0xb26030: ldp             fp, lr, [SP], #0x10
    // 0xb26034: ret
    //     0xb26034: ret             
    // 0xb26038: d0 = inf
    //     0xb26038: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2603c: LoadField: d1 = r2->field_7
    //     0xb2603c: ldur            d1, [x2, #7]
    // 0xb26040: stur            d1, [fp, #-0x18]
    // 0xb26044: fcmp            d1, d0
    // 0xb26048: b.eq            #0xb26054
    // 0xb2604c: mov             v2.16b, v1.16b
    // 0xb26050: b               #0xb26058
    // 0xb26054: d2 = 0.000000
    //     0xb26054: eor             v2.16b, v2.16b, v2.16b
    // 0xb26058: stur            d2, [fp, #-0x10]
    // 0xb2605c: r0 = BoxConstraints()
    //     0xb2605c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb26060: ldur            d0, [fp, #-0x10]
    // 0xb26064: StoreField: r0->field_7 = d0
    //     0xb26064: stur            d0, [x0, #7]
    // 0xb26068: ldur            d1, [fp, #-0x18]
    // 0xb2606c: d0 = inf
    //     0xb2606c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb26070: fcmp            d1, d0
    // 0xb26074: b.ne            #0xb2607c
    // 0xb26078: d1 = inf
    //     0xb26078: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2607c: StoreField: r0->field_f = d1
    //     0xb2607c: stur            d1, [x0, #0xf]
    // 0xb26080: fcmp            d0, d0
    // 0xb26084: b.eq            #0xb26090
    // 0xb26088: d1 = inf
    //     0xb26088: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2608c: b               #0xb26094
    // 0xb26090: d1 = 0.000000
    //     0xb26090: eor             v1.16b, v1.16b, v1.16b
    // 0xb26094: ArrayStore: r0[0] = d1  ; List_8
    //     0xb26094: stur            d1, [x0, #0x17]
    // 0xb26098: StoreField: r0->field_1f = d0
    //     0xb26098: stur            d0, [x0, #0x1f]
    // 0xb2609c: ldur            x1, [fp, #-8]
    // 0xb260a0: mov             x2, x0
    // 0xb260a4: r0 = _sizeForConstraints()
    //     0xb260a4: bl              #0xb21158  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0xb260a8: LoadField: d0 = r0->field_f
    //     0xb260a8: ldur            d0, [x0, #0xf]
    // 0xb260ac: LeaveFrame
    //     0xb260ac: mov             SP, fp
    //     0xb260b0: ldp             fp, lr, [SP], #0x10
    // 0xb260b4: ret
    //     0xb260b4: ret             
    // 0xb260b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb260b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb260bc: b               #0xb26008
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb260c0, size: 0x78
    // 0xb260c0: EnterFrame
    //     0xb260c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb260c4: mov             fp, SP
    // 0xb260c8: ldr             x0, [fp, #0x18]
    // 0xb260cc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb260cc: ldur            w1, [x0, #0x17]
    // 0xb260d0: DecompressPointer r1
    //     0xb260d0: add             x1, x1, HEAP, lsl #32
    // 0xb260d4: CheckStackOverflow
    //     0xb260d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb260d8: cmp             SP, x16
    //     0xb260dc: b.ls            #0xb26120
    // 0xb260e0: ldr             x2, [fp, #0x10]
    // 0xb260e4: r0 = computeMinIntrinsicHeight()
    //     0xb260e4: bl              #0xb25fec  ; [package:flutter/src/rendering/image.dart] RenderImage::computeMinIntrinsicHeight
    // 0xb260e8: r0 = inline_Allocate_Double()
    //     0xb260e8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb260ec: add             x0, x0, #0x10
    //     0xb260f0: cmp             x1, x0
    //     0xb260f4: b.ls            #0xb26128
    //     0xb260f8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb260fc: sub             x0, x0, #0xf
    //     0xb26100: mov             x1, #0xe19c
    //     0xb26104: movk            x1, #3, lsl #16
    //     0xb26108: stur            x1, [x0, #-1]
    // 0xb2610c: dmb             ishst
    // 0xb26110: StoreField: r0->field_7 = d0
    //     0xb26110: stur            d0, [x0, #7]
    // 0xb26114: LeaveFrame
    //     0xb26114: mov             SP, fp
    //     0xb26118: ldp             fp, lr, [SP], #0x10
    // 0xb2611c: ret
    //     0xb2611c: ret             
    // 0xb26120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb26120: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb26124: b               #0xb260e0
    // 0xb26128: SaveReg d0
    //     0xb26128: str             q0, [SP, #-0x10]!
    // 0xb2612c: r0 = AllocateDouble()
    //     0xb2612c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb26130: RestoreReg d0
    //     0xb26130: ldr             q0, [SP], #0x10
    // 0xb26134: b               #0xb26110
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2c514, size: 0xa4
    // 0xb2c514: EnterFrame
    //     0xb2c514: stp             fp, lr, [SP, #-0x10]!
    //     0xb2c518: mov             fp, SP
    // 0xb2c51c: AllocStack(0x18)
    //     0xb2c51c: sub             SP, SP, #0x18
    // 0xb2c520: d0 = inf
    //     0xb2c520: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2c524: stur            x1, [fp, #-8]
    // 0xb2c528: CheckStackOverflow
    //     0xb2c528: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2c52c: cmp             SP, x16
    //     0xb2c530: b.ls            #0xb2c5b0
    // 0xb2c534: LoadField: d1 = r2->field_7
    //     0xb2c534: ldur            d1, [x2, #7]
    // 0xb2c538: stur            d1, [fp, #-0x18]
    // 0xb2c53c: fcmp            d1, d0
    // 0xb2c540: b.eq            #0xb2c54c
    // 0xb2c544: mov             v2.16b, v1.16b
    // 0xb2c548: b               #0xb2c550
    // 0xb2c54c: d2 = 0.000000
    //     0xb2c54c: eor             v2.16b, v2.16b, v2.16b
    // 0xb2c550: stur            d2, [fp, #-0x10]
    // 0xb2c554: r0 = BoxConstraints()
    //     0xb2c554: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2c558: ldur            d0, [fp, #-0x10]
    // 0xb2c55c: StoreField: r0->field_7 = d0
    //     0xb2c55c: stur            d0, [x0, #7]
    // 0xb2c560: ldur            d1, [fp, #-0x18]
    // 0xb2c564: d0 = inf
    //     0xb2c564: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2c568: fcmp            d1, d0
    // 0xb2c56c: b.ne            #0xb2c574
    // 0xb2c570: d1 = inf
    //     0xb2c570: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2c574: StoreField: r0->field_f = d1
    //     0xb2c574: stur            d1, [x0, #0xf]
    // 0xb2c578: fcmp            d0, d0
    // 0xb2c57c: b.eq            #0xb2c588
    // 0xb2c580: d1 = inf
    //     0xb2c580: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2c584: b               #0xb2c58c
    // 0xb2c588: d1 = 0.000000
    //     0xb2c588: eor             v1.16b, v1.16b, v1.16b
    // 0xb2c58c: ArrayStore: r0[0] = d1  ; List_8
    //     0xb2c58c: stur            d1, [x0, #0x17]
    // 0xb2c590: StoreField: r0->field_1f = d0
    //     0xb2c590: stur            d0, [x0, #0x1f]
    // 0xb2c594: ldur            x1, [fp, #-8]
    // 0xb2c598: mov             x2, x0
    // 0xb2c59c: r0 = _sizeForConstraints()
    //     0xb2c59c: bl              #0xb21158  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0xb2c5a0: LoadField: d0 = r0->field_f
    //     0xb2c5a0: ldur            d0, [x0, #0xf]
    // 0xb2c5a4: LeaveFrame
    //     0xb2c5a4: mov             SP, fp
    //     0xb2c5a8: ldp             fp, lr, [SP], #0x10
    // 0xb2c5ac: ret
    //     0xb2c5ac: ret             
    // 0xb2c5b0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2c5b0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2c5b4: b               #0xb2c534
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2c5b8, size: 0x78
    // 0xb2c5b8: EnterFrame
    //     0xb2c5b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2c5bc: mov             fp, SP
    // 0xb2c5c0: ldr             x0, [fp, #0x18]
    // 0xb2c5c4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2c5c4: ldur            w1, [x0, #0x17]
    // 0xb2c5c8: DecompressPointer r1
    //     0xb2c5c8: add             x1, x1, HEAP, lsl #32
    // 0xb2c5cc: CheckStackOverflow
    //     0xb2c5cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2c5d0: cmp             SP, x16
    //     0xb2c5d4: b.ls            #0xb2c618
    // 0xb2c5d8: ldr             x2, [fp, #0x10]
    // 0xb2c5dc: r0 = computeMaxIntrinsicHeight()
    //     0xb2c5dc: bl              #0xb2c514  ; [package:flutter/src/rendering/image.dart] RenderImage::computeMaxIntrinsicHeight
    // 0xb2c5e0: r0 = inline_Allocate_Double()
    //     0xb2c5e0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2c5e4: add             x0, x0, #0x10
    //     0xb2c5e8: cmp             x1, x0
    //     0xb2c5ec: b.ls            #0xb2c620
    //     0xb2c5f0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2c5f4: sub             x0, x0, #0xf
    //     0xb2c5f8: mov             x1, #0xe19c
    //     0xb2c5fc: movk            x1, #3, lsl #16
    //     0xb2c600: stur            x1, [x0, #-1]
    // 0xb2c604: dmb             ishst
    // 0xb2c608: StoreField: r0->field_7 = d0
    //     0xb2c608: stur            d0, [x0, #7]
    // 0xb2c60c: LeaveFrame
    //     0xb2c60c: mov             SP, fp
    //     0xb2c610: ldp             fp, lr, [SP], #0x10
    // 0xb2c614: ret
    //     0xb2c614: ret             
    // 0xb2c618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2c618: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2c61c: b               #0xb2c5d8
    // 0xb2c620: SaveReg d0
    //     0xb2c620: str             q0, [SP, #-0x10]!
    // 0xb2c624: r0 = AllocateDouble()
    //     0xb2c624: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2c628: RestoreReg d0
    //     0xb2c628: ldr             q0, [SP], #0x10
    // 0xb2c62c: b               #0xb2c608
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2f518, size: 0xac
    // 0xb2f518: EnterFrame
    //     0xb2f518: stp             fp, lr, [SP, #-0x10]!
    //     0xb2f51c: mov             fp, SP
    // 0xb2f520: AllocStack(0x18)
    //     0xb2f520: sub             SP, SP, #0x18
    // 0xb2f524: d0 = inf
    //     0xb2f524: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2f528: stur            x1, [fp, #-8]
    // 0xb2f52c: stur            x2, [fp, #-0x10]
    // 0xb2f530: CheckStackOverflow
    //     0xb2f530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2f534: cmp             SP, x16
    //     0xb2f538: b.ls            #0xb2f5bc
    // 0xb2f53c: fcmp            d0, d0
    // 0xb2f540: b.eq            #0xb2f54c
    // 0xb2f544: d1 = inf
    //     0xb2f544: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2f548: b               #0xb2f550
    // 0xb2f54c: d1 = 0.000000
    //     0xb2f54c: eor             v1.16b, v1.16b, v1.16b
    // 0xb2f550: stur            d1, [fp, #-0x18]
    // 0xb2f554: r0 = BoxConstraints()
    //     0xb2f554: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2f558: ldur            d0, [fp, #-0x18]
    // 0xb2f55c: StoreField: r0->field_7 = d0
    //     0xb2f55c: stur            d0, [x0, #7]
    // 0xb2f560: d0 = inf
    //     0xb2f560: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2f564: StoreField: r0->field_f = d0
    //     0xb2f564: stur            d0, [x0, #0xf]
    // 0xb2f568: ldur            x1, [fp, #-0x10]
    // 0xb2f56c: LoadField: d1 = r1->field_7
    //     0xb2f56c: ldur            d1, [x1, #7]
    // 0xb2f570: fcmp            d1, d0
    // 0xb2f574: b.eq            #0xb2f580
    // 0xb2f578: mov             v2.16b, v1.16b
    // 0xb2f57c: b               #0xb2f584
    // 0xb2f580: d2 = 0.000000
    //     0xb2f580: eor             v2.16b, v2.16b, v2.16b
    // 0xb2f584: ArrayStore: r0[0] = d2  ; List_8
    //     0xb2f584: stur            d2, [x0, #0x17]
    // 0xb2f588: fcmp            d1, d0
    // 0xb2f58c: b.eq            #0xb2f598
    // 0xb2f590: mov             v0.16b, v1.16b
    // 0xb2f594: b               #0xb2f59c
    // 0xb2f598: d0 = inf
    //     0xb2f598: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2f59c: StoreField: r0->field_1f = d0
    //     0xb2f59c: stur            d0, [x0, #0x1f]
    // 0xb2f5a0: ldur            x1, [fp, #-8]
    // 0xb2f5a4: mov             x2, x0
    // 0xb2f5a8: r0 = _sizeForConstraints()
    //     0xb2f5a8: bl              #0xb21158  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0xb2f5ac: LoadField: d0 = r0->field_7
    //     0xb2f5ac: ldur            d0, [x0, #7]
    // 0xb2f5b0: LeaveFrame
    //     0xb2f5b0: mov             SP, fp
    //     0xb2f5b4: ldp             fp, lr, [SP], #0x10
    // 0xb2f5b8: ret
    //     0xb2f5b8: ret             
    // 0xb2f5bc: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2f5bc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2f5c0: b               #0xb2f53c
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2f5c4, size: 0x78
    // 0xb2f5c4: EnterFrame
    //     0xb2f5c4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2f5c8: mov             fp, SP
    // 0xb2f5cc: ldr             x0, [fp, #0x18]
    // 0xb2f5d0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2f5d0: ldur            w1, [x0, #0x17]
    // 0xb2f5d4: DecompressPointer r1
    //     0xb2f5d4: add             x1, x1, HEAP, lsl #32
    // 0xb2f5d8: CheckStackOverflow
    //     0xb2f5d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2f5dc: cmp             SP, x16
    //     0xb2f5e0: b.ls            #0xb2f624
    // 0xb2f5e4: ldr             x2, [fp, #0x10]
    // 0xb2f5e8: r0 = computeMaxIntrinsicWidth()
    //     0xb2f5e8: bl              #0xb2f518  ; [package:flutter/src/rendering/image.dart] RenderImage::computeMaxIntrinsicWidth
    // 0xb2f5ec: r0 = inline_Allocate_Double()
    //     0xb2f5ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2f5f0: add             x0, x0, #0x10
    //     0xb2f5f4: cmp             x1, x0
    //     0xb2f5f8: b.ls            #0xb2f62c
    //     0xb2f5fc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2f600: sub             x0, x0, #0xf
    //     0xb2f604: mov             x1, #0xe19c
    //     0xb2f608: movk            x1, #3, lsl #16
    //     0xb2f60c: stur            x1, [x0, #-1]
    // 0xb2f610: dmb             ishst
    // 0xb2f614: StoreField: r0->field_7 = d0
    //     0xb2f614: stur            d0, [x0, #7]
    // 0xb2f618: LeaveFrame
    //     0xb2f618: mov             SP, fp
    //     0xb2f61c: ldp             fp, lr, [SP], #0x10
    // 0xb2f620: ret
    //     0xb2f620: ret             
    // 0xb2f624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2f624: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2f628: b               #0xb2f5e4
    // 0xb2f62c: SaveReg d0
    //     0xb2f62c: str             q0, [SP, #-0x10]!
    // 0xb2f630: r0 = AllocateDouble()
    //     0xb2f630: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2f634: RestoreReg d0
    //     0xb2f634: ldr             q0, [SP], #0x10
    // 0xb2f638: b               #0xb2f614
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb573dc, size: 0x2c
    // 0xb573dc: EnterFrame
    //     0xb573dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb573e0: mov             fp, SP
    // 0xb573e4: CheckStackOverflow
    //     0xb573e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb573e8: cmp             SP, x16
    //     0xb573ec: b.ls            #0xb57400
    // 0xb573f0: r0 = _sizeForConstraints()
    //     0xb573f0: bl              #0xb21158  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0xb573f4: LeaveFrame
    //     0xb573f4: mov             SP, fp
    //     0xb573f8: ldp             fp, lr, [SP], #0x10
    // 0xb573fc: ret
    //     0xb573fc: ret             
    // 0xb57400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb57400: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb57404: b               #0xb573f0
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58b58, size: 0x24
    // 0xb58b58: EnterFrame
    //     0xb58b58: stp             fp, lr, [SP, #-0x10]!
    //     0xb58b5c: mov             fp, SP
    // 0xb58b60: ldr             x2, [fp, #0x10]
    // 0xb58b64: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58b64: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1360] AnonymousClosure: (0xb2f5c4), in [package:flutter/src/rendering/image.dart] RenderImage::computeMaxIntrinsicWidth (0xb2f518)
    //     0xb58b68: ldr             x1, [x1, #0x360]
    // 0xb58b6c: r0 = AllocateClosure()
    //     0xb58b6c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58b70: LeaveFrame
    //     0xb58b70: mov             SP, fp
    //     0xb58b74: ldp             fp, lr, [SP], #0x10
    // 0xb58b78: ret
    //     0xb58b78: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5ec98, size: 0x24
    // 0xb5ec98: EnterFrame
    //     0xb5ec98: stp             fp, lr, [SP, #-0x10]!
    //     0xb5ec9c: mov             fp, SP
    // 0xb5eca0: ldr             x2, [fp, #0x10]
    // 0xb5eca4: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5eca4: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1350] AnonymousClosure: (0xb2c5b8), in [package:flutter/src/rendering/image.dart] RenderImage::computeMaxIntrinsicHeight (0xb2c514)
    //     0xb5eca8: ldr             x1, [x1, #0x350]
    // 0xb5ecac: r0 = AllocateClosure()
    //     0xb5ecac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5ecb0: LeaveFrame
    //     0xb5ecb0: mov             SP, fp
    //     0xb5ecb4: ldp             fp, lr, [SP], #0x10
    // 0xb5ecb8: ret
    //     0xb5ecb8: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbe1880, size: 0xc4
    // 0xbe1880: EnterFrame
    //     0xbe1880: stp             fp, lr, [SP, #-0x10]!
    //     0xbe1884: mov             fp, SP
    // 0xbe1888: AllocStack(0x10)
    //     0xbe1888: sub             SP, SP, #0x10
    // 0xbe188c: SetupParameters(RenderImage this /* r1 => r3, fp-0x10 */)
    //     0xbe188c: mov             x3, x1
    //     0xbe1890: stur            x1, [fp, #-0x10]
    // 0xbe1894: CheckStackOverflow
    //     0xbe1894: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe1898: cmp             SP, x16
    //     0xbe189c: b.ls            #0xbe193c
    // 0xbe18a0: LoadField: r4 = r3->field_27
    //     0xbe18a0: ldur            w4, [x3, #0x27]
    // 0xbe18a4: DecompressPointer r4
    //     0xbe18a4: add             x4, x4, HEAP, lsl #32
    // 0xbe18a8: stur            x4, [fp, #-8]
    // 0xbe18ac: cmp             w4, NULL
    // 0xbe18b0: b.eq            #0xbe1920
    // 0xbe18b4: mov             x0, x4
    // 0xbe18b8: r2 = Null
    //     0xbe18b8: mov             x2, NULL
    // 0xbe18bc: r1 = Null
    //     0xbe18bc: mov             x1, NULL
    // 0xbe18c0: r4 = LoadClassIdInstr(r0)
    //     0xbe18c0: ldur            x4, [x0, #-1]
    //     0xbe18c4: ubfx            x4, x4, #0xc, #0x14
    // 0xbe18c8: sub             x4, x4, #0xb46
    // 0xbe18cc: cmp             x4, #1
    // 0xbe18d0: b.ls            #0xbe18e4
    // 0xbe18d4: r8 = BoxConstraints
    //     0xbe18d4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbe18d8: r3 = Null
    //     0xbe18d8: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1398] Null
    //     0xbe18dc: ldr             x3, [x3, #0x398]
    // 0xbe18e0: r0 = BoxConstraints()
    //     0xbe18e0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbe18e4: ldur            x1, [fp, #-0x10]
    // 0xbe18e8: ldur            x2, [fp, #-8]
    // 0xbe18ec: r0 = _sizeForConstraints()
    //     0xbe18ec: bl              #0xb21158  ; [package:flutter/src/rendering/image.dart] RenderImage::_sizeForConstraints
    // 0xbe18f0: ldur            x1, [fp, #-0x10]
    // 0xbe18f4: StoreField: r1->field_4b = r0
    //     0xbe18f4: stur            w0, [x1, #0x4b]
    //     0xbe18f8: ldurb           w16, [x1, #-1]
    //     0xbe18fc: ldurb           w17, [x0, #-1]
    //     0xbe1900: and             x16, x17, x16, lsr #2
    //     0xbe1904: tst             x16, HEAP, lsr #32
    //     0xbe1908: b.eq            #0xbe1910
    //     0xbe190c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbe1910: r0 = Null
    //     0xbe1910: mov             x0, NULL
    // 0xbe1914: LeaveFrame
    //     0xbe1914: mov             SP, fp
    //     0xbe1918: ldp             fp, lr, [SP], #0x10
    // 0xbe191c: ret
    //     0xbe191c: ret             
    // 0xbe1920: r0 = StateError()
    //     0xbe1920: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbe1924: mov             x1, x0
    // 0xbe1928: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbe1928: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbe192c: StoreField: r1->field_b = r0
    //     0xbe192c: stur            w0, [x1, #0xb]
    // 0xbe1930: mov             x0, x1
    // 0xbe1934: r0 = Throw()
    //     0xbe1934: bl              #0x13ddb2c  ; ThrowStub
    // 0xbe1938: brk             #0
    // 0xbe193c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe193c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe1940: b               #0xbe18a0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc04bc8, size: 0x60
    // 0xc04bc8: EnterFrame
    //     0xc04bc8: stp             fp, lr, [SP, #-0x10]!
    //     0xc04bcc: mov             fp, SP
    // 0xc04bd0: AllocStack(0x8)
    //     0xc04bd0: sub             SP, SP, #8
    // 0xc04bd4: SetupParameters(RenderImage this /* r1 => r0, fp-0x8 */)
    //     0xc04bd4: mov             x0, x1
    //     0xc04bd8: stur            x1, [fp, #-8]
    // 0xc04bdc: CheckStackOverflow
    //     0xc04bdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc04be0: cmp             SP, x16
    //     0xc04be4: b.ls            #0xc04c20
    // 0xc04be8: LoadField: r1 = r0->field_57
    //     0xc04be8: ldur            w1, [x0, #0x57]
    // 0xc04bec: DecompressPointer r1
    //     0xc04bec: add             x1, x1, HEAP, lsl #32
    // 0xc04bf0: cmp             w1, NULL
    // 0xc04bf4: b.ne            #0xc04c00
    // 0xc04bf8: mov             x1, x0
    // 0xc04bfc: b               #0xc04c08
    // 0xc04c00: r0 = dispose()
    //     0xc04c00: bl              #0xc02d74  ; [dart:ui] Image::dispose
    // 0xc04c04: ldur            x1, [fp, #-8]
    // 0xc04c08: StoreField: r1->field_57 = rNULL
    //     0xc04c08: stur            NULL, [x1, #0x57]
    // 0xc04c0c: r0 = dispose()
    //     0xc04c0c: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc04c10: r0 = Null
    //     0xc04c10: mov             x0, NULL
    // 0xc04c14: LeaveFrame
    //     0xc04c14: mov             SP, fp
    //     0xc04c18: ldp             fp, lr, [SP], #0x10
    // 0xc04c1c: ret
    //     0xc04c1c: ret             
    // 0xc04c20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04c20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04c24: b               #0xc04be8
  }
  _ paint(/* No info */) {
    // ** addr: 0xc2eaf4, size: 0x180
    // 0xc2eaf4: EnterFrame
    //     0xc2eaf4: stp             fp, lr, [SP, #-0x10]!
    //     0xc2eaf8: mov             fp, SP
    // 0xc2eafc: AllocStack(0x58)
    //     0xc2eafc: sub             SP, SP, #0x58
    // 0xc2eb00: SetupParameters(RenderImage this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xc2eb00: mov             x0, x3
    //     0xc2eb04: stur            x3, [fp, #-0x18]
    //     0xc2eb08: mov             x3, x1
    //     0xc2eb0c: stur            x1, [fp, #-8]
    //     0xc2eb10: stur            x2, [fp, #-0x10]
    // 0xc2eb14: CheckStackOverflow
    //     0xc2eb14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2eb18: cmp             SP, x16
    //     0xc2eb1c: b.ls            #0xc2ec30
    // 0xc2eb20: LoadField: r1 = r3->field_57
    //     0xc2eb20: ldur            w1, [x3, #0x57]
    // 0xc2eb24: DecompressPointer r1
    //     0xc2eb24: add             x1, x1, HEAP, lsl #32
    // 0xc2eb28: cmp             w1, NULL
    // 0xc2eb2c: b.ne            #0xc2eb40
    // 0xc2eb30: r0 = Null
    //     0xc2eb30: mov             x0, NULL
    // 0xc2eb34: LeaveFrame
    //     0xc2eb34: mov             SP, fp
    //     0xc2eb38: ldp             fp, lr, [SP], #0x10
    // 0xc2eb3c: ret
    //     0xc2eb3c: ret             
    // 0xc2eb40: mov             x1, x3
    // 0xc2eb44: r0 = _resolve()
    //     0xc2eb44: bl              #0xc2ec74  ; [package:flutter/src/rendering/image.dart] RenderImage::_resolve
    // 0xc2eb48: ldur            x1, [fp, #-0x10]
    // 0xc2eb4c: r0 = canvas()
    //     0xc2eb4c: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc2eb50: ldur            x1, [fp, #-8]
    // 0xc2eb54: stur            x0, [fp, #-0x10]
    // 0xc2eb58: r0 = size()
    //     0xc2eb58: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2eb5c: ldur            x1, [fp, #-0x18]
    // 0xc2eb60: mov             x2, x0
    // 0xc2eb64: r0 = &()
    //     0xc2eb64: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc2eb68: mov             x1, x0
    // 0xc2eb6c: ldur            x0, [fp, #-8]
    // 0xc2eb70: LoadField: r2 = r0->field_57
    //     0xc2eb70: ldur            w2, [x0, #0x57]
    // 0xc2eb74: DecompressPointer r2
    //     0xc2eb74: add             x2, x2, HEAP, lsl #32
    // 0xc2eb78: cmp             w2, NULL
    // 0xc2eb7c: b.eq            #0xc2ec38
    // 0xc2eb80: LoadField: d0 = r0->field_67
    //     0xc2eb80: ldur            d0, [x0, #0x67]
    // 0xc2eb84: LoadField: r3 = r0->field_6f
    //     0xc2eb84: ldur            w3, [x0, #0x6f]
    // 0xc2eb88: DecompressPointer r3
    //     0xc2eb88: add             x3, x3, HEAP, lsl #32
    // 0xc2eb8c: LoadField: r4 = r0->field_83
    //     0xc2eb8c: ldur            w4, [x0, #0x83]
    // 0xc2eb90: DecompressPointer r4
    //     0xc2eb90: add             x4, x4, HEAP, lsl #32
    // 0xc2eb94: LoadField: r5 = r0->field_4f
    //     0xc2eb94: ldur            w5, [x0, #0x4f]
    // 0xc2eb98: DecompressPointer r5
    //     0xc2eb98: add             x5, x5, HEAP, lsl #32
    // 0xc2eb9c: cmp             w5, NULL
    // 0xc2eba0: b.eq            #0xc2ec3c
    // 0xc2eba4: LoadField: r6 = r0->field_53
    //     0xc2eba4: ldur            w6, [x0, #0x53]
    // 0xc2eba8: DecompressPointer r6
    //     0xc2eba8: add             x6, x6, HEAP, lsl #32
    // 0xc2ebac: cmp             w6, NULL
    // 0xc2ebb0: b.eq            #0xc2ec40
    // 0xc2ebb4: LoadField: r6 = r0->field_93
    //     0xc2ebb4: ldur            w6, [x0, #0x93]
    // 0xc2ebb8: DecompressPointer r6
    //     0xc2ebb8: add             x6, x6, HEAP, lsl #32
    // 0xc2ebbc: LoadField: r7 = r0->field_7b
    //     0xc2ebbc: ldur            w7, [x0, #0x7b]
    // 0xc2ebc0: DecompressPointer r7
    //     0xc2ebc0: add             x7, x7, HEAP, lsl #32
    // 0xc2ebc4: r0 = inline_Allocate_Double()
    //     0xc2ebc4: ldp             x0, x8, [THR, #0x60]  ; THR::top
    //     0xc2ebc8: add             x0, x0, #0x10
    //     0xc2ebcc: cmp             x8, x0
    //     0xc2ebd0: b.ls            #0xc2ec44
    //     0xc2ebd4: str             x0, [THR, #0x60]  ; THR::top
    //     0xc2ebd8: sub             x0, x0, #0xf
    //     0xc2ebdc: mov             x8, #0xe19c
    //     0xc2ebe0: movk            x8, #3, lsl #16
    //     0xc2ebe4: stur            x8, [x0, #-1]
    // 0xc2ebe8: dmb             ishst
    // 0xc2ebec: StoreField: r0->field_7 = d0
    //     0xc2ebec: stur            d0, [x0, #7]
    // 0xc2ebf0: r16 = 1.000000
    //     0xc2ebf0: ldr             x16, [PP, #0x4c60]  ; [pp+0x4c60] 1
    // 0xc2ebf4: stp             x16, x0, [SP, #0x30]
    // 0xc2ebf8: stp             x4, x3, [SP, #0x20]
    // 0xc2ebfc: r16 = Instance_ImageRepeat
    //     0xc2ebfc: add             x16, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0xc2ec00: ldr             x16, [x16, #0xfb8]
    // 0xc2ec04: stp             x16, x5, [SP, #0x10]
    // 0xc2ec08: stp             x7, x6, [SP]
    // 0xc2ec0c: mov             x3, x1
    // 0xc2ec10: ldur            x1, [fp, #-0x10]
    // 0xc2ec14: r4 = const [0, 0xb, 0x8, 0x3, alignment, 0x7, colorFilter, 0x5, filterQuality, 0xa, fit, 0x6, invertColors, 0x9, opacity, 0x4, repeat, 0x8, scale, 0x3, null]
    //     0xc2ec14: add             x4, PP, #0xa1, lsl #12  ; [pp+0xa1370] List(21) [0, 0xb, 0x8, 0x3, "alignment", 0x7, "colorFilter", 0x5, "filterQuality", 0xa, "fit", 0x6, "invertColors", 0x9, "opacity", 0x4, "repeat", 0x8, "scale", 0x3, Null]
    //     0xc2ec18: ldr             x4, [x4, #0x370]
    // 0xc2ec1c: r0 = paintImage()
    //     0xc2ec1c: bl              #0xb88fd8  ; [package:flutter/src/painting/decoration_image.dart] ::paintImage
    // 0xc2ec20: r0 = Null
    //     0xc2ec20: mov             x0, NULL
    // 0xc2ec24: LeaveFrame
    //     0xc2ec24: mov             SP, fp
    //     0xc2ec28: ldp             fp, lr, [SP], #0x10
    // 0xc2ec2c: ret
    //     0xc2ec2c: ret             
    // 0xc2ec30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2ec30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2ec34: b               #0xc2eb20
    // 0xc2ec38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc2ec38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc2ec3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc2ec3c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc2ec40: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc2ec40: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc2ec44: SaveReg d0
    //     0xc2ec44: str             q0, [SP, #-0x10]!
    // 0xc2ec48: stp             x6, x7, [SP, #-0x10]!
    // 0xc2ec4c: stp             x4, x5, [SP, #-0x10]!
    // 0xc2ec50: stp             x2, x3, [SP, #-0x10]!
    // 0xc2ec54: SaveReg r1
    //     0xc2ec54: str             x1, [SP, #-8]!
    // 0xc2ec58: r0 = AllocateDouble()
    //     0xc2ec58: bl              #0x13df878  ; AllocateDoubleStub
    // 0xc2ec5c: RestoreReg r1
    //     0xc2ec5c: ldr             x1, [SP], #8
    // 0xc2ec60: ldp             x2, x3, [SP], #0x10
    // 0xc2ec64: ldp             x4, x5, [SP], #0x10
    // 0xc2ec68: ldp             x6, x7, [SP], #0x10
    // 0xc2ec6c: RestoreReg d0
    //     0xc2ec6c: ldr             q0, [SP], #0x10
    // 0xc2ec70: b               #0xc2ebec
  }
  _ _resolve(/* No info */) {
    // ** addr: 0xc2ec74, size: 0x54
    // 0xc2ec74: LoadField: r2 = r1->field_4f
    //     0xc2ec74: ldur            w2, [x1, #0x4f]
    // 0xc2ec78: DecompressPointer r2
    //     0xc2ec78: add             x2, x2, HEAP, lsl #32
    // 0xc2ec7c: cmp             w2, NULL
    // 0xc2ec80: b.eq            #0xc2ec8c
    // 0xc2ec84: r0 = Null
    //     0xc2ec84: mov             x0, NULL
    // 0xc2ec88: ret
    //     0xc2ec88: ret             
    // 0xc2ec8c: r2 = false
    //     0xc2ec8c: add             x2, NULL, #0x30  ; false
    // 0xc2ec90: LoadField: r0 = r1->field_87
    //     0xc2ec90: ldur            w0, [x1, #0x87]
    // 0xc2ec94: DecompressPointer r0
    //     0xc2ec94: add             x0, x0, HEAP, lsl #32
    // 0xc2ec98: StoreField: r1->field_4f = r0
    //     0xc2ec98: stur            w0, [x1, #0x4f]
    //     0xc2ec9c: ldurb           w16, [x1, #-1]
    //     0xc2eca0: ldurb           w17, [x0, #-1]
    //     0xc2eca4: and             x16, x17, x16, lsr #2
    //     0xc2eca8: tst             x16, HEAP, lsr #32
    //     0xc2ecac: b.eq            #0xc2ecbc
    //     0xc2ecb0: str             lr, [SP, #-8]!
    //     0xc2ecb4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xc2ecb8: ldr             lr, [SP], #8
    // 0xc2ecbc: StoreField: r1->field_53 = r2
    //     0xc2ecbc: stur            w2, [x1, #0x53]
    // 0xc2ecc0: r0 = Null
    //     0xc2ecc0: mov             x0, NULL
    // 0xc2ecc4: ret
    //     0xc2ecc4: ret             
  }
  set _ filterQuality=(/* No info */) {
    // ** addr: 0xce31ac, size: 0x70
    // 0xce31ac: EnterFrame
    //     0xce31ac: stp             fp, lr, [SP, #-0x10]!
    //     0xce31b0: mov             fp, SP
    // 0xce31b4: mov             x0, x2
    // 0xce31b8: CheckStackOverflow
    //     0xce31b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce31bc: cmp             SP, x16
    //     0xce31c0: b.ls            #0xce3214
    // 0xce31c4: LoadField: r2 = r1->field_7b
    //     0xce31c4: ldur            w2, [x1, #0x7b]
    // 0xce31c8: DecompressPointer r2
    //     0xce31c8: add             x2, x2, HEAP, lsl #32
    // 0xce31cc: cmp             w0, w2
    // 0xce31d0: b.ne            #0xce31e4
    // 0xce31d4: r0 = Null
    //     0xce31d4: mov             x0, NULL
    // 0xce31d8: LeaveFrame
    //     0xce31d8: mov             SP, fp
    //     0xce31dc: ldp             fp, lr, [SP], #0x10
    // 0xce31e0: ret
    //     0xce31e0: ret             
    // 0xce31e4: StoreField: r1->field_7b = r0
    //     0xce31e4: stur            w0, [x1, #0x7b]
    //     0xce31e8: ldurb           w16, [x1, #-1]
    //     0xce31ec: ldurb           w17, [x0, #-1]
    //     0xce31f0: and             x16, x17, x16, lsr #2
    //     0xce31f4: tst             x16, HEAP, lsr #32
    //     0xce31f8: b.eq            #0xce3200
    //     0xce31fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce3200: r0 = markNeedsPaint()
    //     0xce3200: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce3204: r0 = Null
    //     0xce3204: mov             x0, NULL
    // 0xce3208: LeaveFrame
    //     0xce3208: mov             SP, fp
    //     0xce320c: ldp             fp, lr, [SP], #0x10
    // 0xce3210: ret
    //     0xce3210: ret             
    // 0xce3214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3214: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce3218: b               #0xce31c4
  }
  set _ invertColors=(/* No info */) {
    // ** addr: 0xce321c, size: 0x54
    // 0xce321c: EnterFrame
    //     0xce321c: stp             fp, lr, [SP, #-0x10]!
    //     0xce3220: mov             fp, SP
    // 0xce3224: CheckStackOverflow
    //     0xce3224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3228: cmp             SP, x16
    //     0xce322c: b.ls            #0xce3268
    // 0xce3230: LoadField: r0 = r1->field_93
    //     0xce3230: ldur            w0, [x1, #0x93]
    // 0xce3234: DecompressPointer r0
    //     0xce3234: add             x0, x0, HEAP, lsl #32
    // 0xce3238: cmp             w2, w0
    // 0xce323c: b.ne            #0xce3250
    // 0xce3240: r0 = Null
    //     0xce3240: mov             x0, NULL
    // 0xce3244: LeaveFrame
    //     0xce3244: mov             SP, fp
    //     0xce3248: ldp             fp, lr, [SP], #0x10
    // 0xce324c: ret
    //     0xce324c: ret             
    // 0xce3250: StoreField: r1->field_93 = r2
    //     0xce3250: stur            w2, [x1, #0x93]
    // 0xce3254: r0 = markNeedsPaint()
    //     0xce3254: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce3258: r0 = Null
    //     0xce3258: mov             x0, NULL
    // 0xce325c: LeaveFrame
    //     0xce325c: mov             SP, fp
    //     0xce3260: ldp             fp, lr, [SP], #0x10
    // 0xce3264: ret
    //     0xce3264: ret             
    // 0xce3268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3268: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce326c: b               #0xce3230
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xce3270, size: 0x70
    // 0xce3270: EnterFrame
    //     0xce3270: stp             fp, lr, [SP, #-0x10]!
    //     0xce3274: mov             fp, SP
    // 0xce3278: mov             x0, x2
    // 0xce327c: CheckStackOverflow
    //     0xce327c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3280: cmp             SP, x16
    //     0xce3284: b.ls            #0xce32d8
    // 0xce3288: LoadField: r2 = r1->field_9b
    //     0xce3288: ldur            w2, [x1, #0x9b]
    // 0xce328c: DecompressPointer r2
    //     0xce328c: add             x2, x2, HEAP, lsl #32
    // 0xce3290: cmp             w2, w0
    // 0xce3294: b.ne            #0xce32a8
    // 0xce3298: r0 = Null
    //     0xce3298: mov             x0, NULL
    // 0xce329c: LeaveFrame
    //     0xce329c: mov             SP, fp
    //     0xce32a0: ldp             fp, lr, [SP], #0x10
    // 0xce32a4: ret
    //     0xce32a4: ret             
    // 0xce32a8: StoreField: r1->field_9b = r0
    //     0xce32a8: stur            w0, [x1, #0x9b]
    //     0xce32ac: ldurb           w16, [x1, #-1]
    //     0xce32b0: ldurb           w17, [x0, #-1]
    //     0xce32b4: and             x16, x17, x16, lsr #2
    //     0xce32b8: tst             x16, HEAP, lsr #32
    //     0xce32bc: b.eq            #0xce32c4
    //     0xce32c0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce32c4: r0 = _markNeedResolution()
    //     0xce32c4: bl              #0xce32e0  ; [package:flutter/src/rendering/image.dart] RenderImage::_markNeedResolution
    // 0xce32c8: r0 = Null
    //     0xce32c8: mov             x0, NULL
    // 0xce32cc: LeaveFrame
    //     0xce32cc: mov             SP, fp
    //     0xce32d0: ldp             fp, lr, [SP], #0x10
    // 0xce32d4: ret
    //     0xce32d4: ret             
    // 0xce32d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce32d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce32dc: b               #0xce3288
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0xce32e0, size: 0x38
    // 0xce32e0: EnterFrame
    //     0xce32e0: stp             fp, lr, [SP, #-0x10]!
    //     0xce32e4: mov             fp, SP
    // 0xce32e8: CheckStackOverflow
    //     0xce32e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce32ec: cmp             SP, x16
    //     0xce32f0: b.ls            #0xce3310
    // 0xce32f4: StoreField: r1->field_4f = rNULL
    //     0xce32f4: stur            NULL, [x1, #0x4f]
    // 0xce32f8: StoreField: r1->field_53 = rNULL
    //     0xce32f8: stur            NULL, [x1, #0x53]
    // 0xce32fc: r0 = markNeedsPaint()
    //     0xce32fc: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce3300: r0 = Null
    //     0xce3300: mov             x0, NULL
    // 0xce3304: LeaveFrame
    //     0xce3304: mov             SP, fp
    //     0xce3308: ldp             fp, lr, [SP], #0x10
    // 0xce330c: ret
    //     0xce330c: ret             
    // 0xce3310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3310: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce3314: b               #0xce32f4
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0xce3318, size: 0x88
    // 0xce3318: EnterFrame
    //     0xce3318: stp             fp, lr, [SP, #-0x10]!
    //     0xce331c: mov             fp, SP
    // 0xce3320: AllocStack(0x20)
    //     0xce3320: sub             SP, SP, #0x20
    // 0xce3324: SetupParameters(RenderImage this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xce3324: mov             x0, x2
    //     0xce3328: stur            x1, [fp, #-8]
    //     0xce332c: stur            x2, [fp, #-0x10]
    // 0xce3330: CheckStackOverflow
    //     0xce3330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3334: cmp             SP, x16
    //     0xce3338: b.ls            #0xce3398
    // 0xce333c: LoadField: r2 = r1->field_87
    //     0xce333c: ldur            w2, [x1, #0x87]
    // 0xce3340: DecompressPointer r2
    //     0xce3340: add             x2, x2, HEAP, lsl #32
    // 0xce3344: stp             x2, x0, [SP]
    // 0xce3348: r0 = ==()
    //     0xce3348: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xce334c: tbnz            w0, #4, #0xce3360
    // 0xce3350: r0 = Null
    //     0xce3350: mov             x0, NULL
    // 0xce3354: LeaveFrame
    //     0xce3354: mov             SP, fp
    //     0xce3358: ldp             fp, lr, [SP], #0x10
    // 0xce335c: ret
    //     0xce335c: ret             
    // 0xce3360: ldur            x1, [fp, #-8]
    // 0xce3364: ldur            x0, [fp, #-0x10]
    // 0xce3368: StoreField: r1->field_87 = r0
    //     0xce3368: stur            w0, [x1, #0x87]
    //     0xce336c: ldurb           w16, [x1, #-1]
    //     0xce3370: ldurb           w17, [x0, #-1]
    //     0xce3374: and             x16, x17, x16, lsr #2
    //     0xce3378: tst             x16, HEAP, lsr #32
    //     0xce337c: b.eq            #0xce3384
    //     0xce3380: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce3384: r0 = _markNeedResolution()
    //     0xce3384: bl              #0xce32e0  ; [package:flutter/src/rendering/image.dart] RenderImage::_markNeedResolution
    // 0xce3388: r0 = Null
    //     0xce3388: mov             x0, NULL
    // 0xce338c: LeaveFrame
    //     0xce338c: mov             SP, fp
    //     0xce3390: ldp             fp, lr, [SP], #0x10
    // 0xce3394: ret
    //     0xce3394: ret             
    // 0xce3398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3398: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce339c: b               #0xce333c
  }
  set _ fit=(/* No info */) {
    // ** addr: 0xce33a0, size: 0x70
    // 0xce33a0: EnterFrame
    //     0xce33a0: stp             fp, lr, [SP, #-0x10]!
    //     0xce33a4: mov             fp, SP
    // 0xce33a8: mov             x0, x2
    // 0xce33ac: CheckStackOverflow
    //     0xce33ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce33b0: cmp             SP, x16
    //     0xce33b4: b.ls            #0xce3408
    // 0xce33b8: LoadField: r2 = r1->field_83
    //     0xce33b8: ldur            w2, [x1, #0x83]
    // 0xce33bc: DecompressPointer r2
    //     0xce33bc: add             x2, x2, HEAP, lsl #32
    // 0xce33c0: cmp             w0, w2
    // 0xce33c4: b.ne            #0xce33d8
    // 0xce33c8: r0 = Null
    //     0xce33c8: mov             x0, NULL
    // 0xce33cc: LeaveFrame
    //     0xce33cc: mov             SP, fp
    //     0xce33d0: ldp             fp, lr, [SP], #0x10
    // 0xce33d4: ret
    //     0xce33d4: ret             
    // 0xce33d8: StoreField: r1->field_83 = r0
    //     0xce33d8: stur            w0, [x1, #0x83]
    //     0xce33dc: ldurb           w16, [x1, #-1]
    //     0xce33e0: ldurb           w17, [x0, #-1]
    //     0xce33e4: and             x16, x17, x16, lsr #2
    //     0xce33e8: tst             x16, HEAP, lsr #32
    //     0xce33ec: b.eq            #0xce33f4
    //     0xce33f0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce33f4: r0 = markNeedsPaint()
    //     0xce33f4: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce33f8: r0 = Null
    //     0xce33f8: mov             x0, NULL
    // 0xce33fc: LeaveFrame
    //     0xce33fc: mov             SP, fp
    //     0xce3400: ldp             fp, lr, [SP], #0x10
    // 0xce3404: ret
    //     0xce3404: ret             
    // 0xce3408: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3408: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce340c: b               #0xce33b8
  }
  set _ color=(/* No info */) {
    // ** addr: 0xce3410, size: 0xb0
    // 0xce3410: EnterFrame
    //     0xce3410: stp             fp, lr, [SP, #-0x10]!
    //     0xce3414: mov             fp, SP
    // 0xce3418: AllocStack(0x20)
    //     0xce3418: sub             SP, SP, #0x20
    // 0xce341c: SetupParameters(RenderImage this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xce341c: stur            x1, [fp, #-8]
    //     0xce3420: mov             x16, x2
    //     0xce3424: mov             x2, x1
    //     0xce3428: mov             x1, x16
    //     0xce342c: stur            x1, [fp, #-0x10]
    // 0xce3430: CheckStackOverflow
    //     0xce3430: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3434: cmp             SP, x16
    //     0xce3438: b.ls            #0xce34b8
    // 0xce343c: LoadField: r0 = r2->field_73
    //     0xce343c: ldur            w0, [x2, #0x73]
    // 0xce3440: DecompressPointer r0
    //     0xce3440: add             x0, x0, HEAP, lsl #32
    // 0xce3444: r3 = LoadClassIdInstr(r1)
    //     0xce3444: ldur            x3, [x1, #-1]
    //     0xce3448: ubfx            x3, x3, #0xc, #0x14
    // 0xce344c: stp             x0, x1, [SP]
    // 0xce3450: mov             x0, x3
    // 0xce3454: mov             lr, x0
    // 0xce3458: ldr             lr, [x21, lr, lsl #3]
    // 0xce345c: blr             lr
    // 0xce3460: tbnz            w0, #4, #0xce3474
    // 0xce3464: r0 = Null
    //     0xce3464: mov             x0, NULL
    // 0xce3468: LeaveFrame
    //     0xce3468: mov             SP, fp
    //     0xce346c: ldp             fp, lr, [SP], #0x10
    // 0xce3470: ret
    //     0xce3470: ret             
    // 0xce3474: ldur            x2, [fp, #-8]
    // 0xce3478: ldur            x0, [fp, #-0x10]
    // 0xce347c: StoreField: r2->field_73 = r0
    //     0xce347c: stur            w0, [x2, #0x73]
    //     0xce3480: ldurb           w16, [x2, #-1]
    //     0xce3484: ldurb           w17, [x0, #-1]
    //     0xce3488: and             x16, x17, x16, lsr #2
    //     0xce348c: tst             x16, HEAP, lsr #32
    //     0xce3490: b.eq            #0xce3498
    //     0xce3494: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xce3498: mov             x1, x2
    // 0xce349c: r0 = _updateColorFilter()
    //     0xce349c: bl              #0xce34c0  ; [package:flutter/src/rendering/image.dart] RenderImage::_updateColorFilter
    // 0xce34a0: ldur            x1, [fp, #-8]
    // 0xce34a4: r0 = markNeedsPaint()
    //     0xce34a4: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce34a8: r0 = Null
    //     0xce34a8: mov             x0, NULL
    // 0xce34ac: LeaveFrame
    //     0xce34ac: mov             SP, fp
    //     0xce34b0: ldp             fp, lr, [SP], #0x10
    // 0xce34b4: ret
    //     0xce34b4: ret             
    // 0xce34b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce34b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce34bc: b               #0xce343c
  }
  _ _updateColorFilter(/* No info */) {
    // ** addr: 0xce34c0, size: 0x7c
    // 0xce34c0: EnterFrame
    //     0xce34c0: stp             fp, lr, [SP, #-0x10]!
    //     0xce34c4: mov             fp, SP
    // 0xce34c8: AllocStack(0x10)
    //     0xce34c8: sub             SP, SP, #0x10
    // 0xce34cc: SetupParameters(RenderImage this /* r1 => r1, fp-0x10 */)
    //     0xce34cc: stur            x1, [fp, #-0x10]
    // 0xce34d0: LoadField: r0 = r1->field_73
    //     0xce34d0: ldur            w0, [x1, #0x73]
    // 0xce34d4: DecompressPointer r0
    //     0xce34d4: add             x0, x0, HEAP, lsl #32
    // 0xce34d8: stur            x0, [fp, #-8]
    // 0xce34dc: cmp             w0, NULL
    // 0xce34e0: b.ne            #0xce34ec
    // 0xce34e4: StoreField: r1->field_6f = rNULL
    //     0xce34e4: stur            NULL, [x1, #0x6f]
    // 0xce34e8: b               #0xce352c
    // 0xce34ec: r0 = ColorFilter()
    //     0xce34ec: bl              #0xce353c  ; AllocateColorFilterStub -> ColorFilter (size=0x1c)
    // 0xce34f0: ldur            x1, [fp, #-8]
    // 0xce34f4: StoreField: r0->field_7 = r1
    //     0xce34f4: stur            w1, [x0, #7]
    // 0xce34f8: r1 = Instance_BlendMode
    //     0xce34f8: add             x1, PP, #0x17, lsl #12  ; [pp+0x176e0] Obj!BlendMode@12c82c1
    //     0xce34fc: ldr             x1, [x1, #0x6e0]
    // 0xce3500: StoreField: r0->field_b = r1
    //     0xce3500: stur            w1, [x0, #0xb]
    // 0xce3504: r1 = 1
    //     0xce3504: mov             x1, #1
    // 0xce3508: StoreField: r0->field_13 = r1
    //     0xce3508: stur            x1, [x0, #0x13]
    // 0xce350c: ldur            x1, [fp, #-0x10]
    // 0xce3510: StoreField: r1->field_6f = r0
    //     0xce3510: stur            w0, [x1, #0x6f]
    //     0xce3514: ldurb           w16, [x1, #-1]
    //     0xce3518: ldurb           w17, [x0, #-1]
    //     0xce351c: and             x16, x17, x16, lsr #2
    //     0xce3520: tst             x16, HEAP, lsr #32
    //     0xce3524: b.eq            #0xce352c
    //     0xce3528: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce352c: r0 = Null
    //     0xce352c: mov             x0, NULL
    // 0xce3530: LeaveFrame
    //     0xce3530: mov             SP, fp
    //     0xce3534: ldp             fp, lr, [SP], #0x10
    // 0xce3538: ret
    //     0xce3538: ret             
  }
  set _ scale=(/* No info */) {
    // ** addr: 0xce3548, size: 0x50
    // 0xce3548: EnterFrame
    //     0xce3548: stp             fp, lr, [SP, #-0x10]!
    //     0xce354c: mov             fp, SP
    // 0xce3550: CheckStackOverflow
    //     0xce3550: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3554: cmp             SP, x16
    //     0xce3558: b.ls            #0xce3590
    // 0xce355c: LoadField: d1 = r1->field_67
    //     0xce355c: ldur            d1, [x1, #0x67]
    // 0xce3560: fcmp            d0, d1
    // 0xce3564: b.ne            #0xce3578
    // 0xce3568: r0 = Null
    //     0xce3568: mov             x0, NULL
    // 0xce356c: LeaveFrame
    //     0xce356c: mov             SP, fp
    //     0xce3570: ldp             fp, lr, [SP], #0x10
    // 0xce3574: ret
    //     0xce3574: ret             
    // 0xce3578: StoreField: r1->field_67 = d0
    //     0xce3578: stur            d0, [x1, #0x67]
    // 0xce357c: r0 = markNeedsLayout()
    //     0xce357c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xce3580: r0 = Null
    //     0xce3580: mov             x0, NULL
    // 0xce3584: LeaveFrame
    //     0xce3584: mov             SP, fp
    //     0xce3588: ldp             fp, lr, [SP], #0x10
    // 0xce358c: ret
    //     0xce358c: ret             
    // 0xce3590: r0 = StackOverflowSharedWithFPURegs()
    //     0xce3590: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xce3594: b               #0xce355c
  }
  set _ height=(/* No info */) {
    // ** addr: 0xce3598, size: 0xa4
    // 0xce3598: EnterFrame
    //     0xce3598: stp             fp, lr, [SP, #-0x10]!
    //     0xce359c: mov             fp, SP
    // 0xce35a0: AllocStack(0x20)
    //     0xce35a0: sub             SP, SP, #0x20
    // 0xce35a4: SetupParameters(RenderImage this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xce35a4: stur            x1, [fp, #-8]
    //     0xce35a8: mov             x16, x2
    //     0xce35ac: mov             x2, x1
    //     0xce35b0: mov             x1, x16
    //     0xce35b4: stur            x1, [fp, #-0x10]
    // 0xce35b8: CheckStackOverflow
    //     0xce35b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce35bc: cmp             SP, x16
    //     0xce35c0: b.ls            #0xce3634
    // 0xce35c4: LoadField: r0 = r2->field_63
    //     0xce35c4: ldur            w0, [x2, #0x63]
    // 0xce35c8: DecompressPointer r0
    //     0xce35c8: add             x0, x0, HEAP, lsl #32
    // 0xce35cc: r3 = LoadClassIdInstr(r1)
    //     0xce35cc: ldur            x3, [x1, #-1]
    //     0xce35d0: ubfx            x3, x3, #0xc, #0x14
    // 0xce35d4: stp             x0, x1, [SP]
    // 0xce35d8: mov             x0, x3
    // 0xce35dc: mov             lr, x0
    // 0xce35e0: ldr             lr, [x21, lr, lsl #3]
    // 0xce35e4: blr             lr
    // 0xce35e8: tbnz            w0, #4, #0xce35fc
    // 0xce35ec: r0 = Null
    //     0xce35ec: mov             x0, NULL
    // 0xce35f0: LeaveFrame
    //     0xce35f0: mov             SP, fp
    //     0xce35f4: ldp             fp, lr, [SP], #0x10
    // 0xce35f8: ret
    //     0xce35f8: ret             
    // 0xce35fc: ldur            x1, [fp, #-8]
    // 0xce3600: ldur            x0, [fp, #-0x10]
    // 0xce3604: StoreField: r1->field_63 = r0
    //     0xce3604: stur            w0, [x1, #0x63]
    //     0xce3608: ldurb           w16, [x1, #-1]
    //     0xce360c: ldurb           w17, [x0, #-1]
    //     0xce3610: and             x16, x17, x16, lsr #2
    //     0xce3614: tst             x16, HEAP, lsr #32
    //     0xce3618: b.eq            #0xce3620
    //     0xce361c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce3620: r0 = markNeedsLayout()
    //     0xce3620: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xce3624: r0 = Null
    //     0xce3624: mov             x0, NULL
    // 0xce3628: LeaveFrame
    //     0xce3628: mov             SP, fp
    //     0xce362c: ldp             fp, lr, [SP], #0x10
    // 0xce3630: ret
    //     0xce3630: ret             
    // 0xce3634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3634: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce3638: b               #0xce35c4
  }
  set _ width=(/* No info */) {
    // ** addr: 0xce363c, size: 0xa4
    // 0xce363c: EnterFrame
    //     0xce363c: stp             fp, lr, [SP, #-0x10]!
    //     0xce3640: mov             fp, SP
    // 0xce3644: AllocStack(0x20)
    //     0xce3644: sub             SP, SP, #0x20
    // 0xce3648: SetupParameters(RenderImage this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xce3648: stur            x1, [fp, #-8]
    //     0xce364c: mov             x16, x2
    //     0xce3650: mov             x2, x1
    //     0xce3654: mov             x1, x16
    //     0xce3658: stur            x1, [fp, #-0x10]
    // 0xce365c: CheckStackOverflow
    //     0xce365c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3660: cmp             SP, x16
    //     0xce3664: b.ls            #0xce36d8
    // 0xce3668: LoadField: r0 = r2->field_5f
    //     0xce3668: ldur            w0, [x2, #0x5f]
    // 0xce366c: DecompressPointer r0
    //     0xce366c: add             x0, x0, HEAP, lsl #32
    // 0xce3670: r3 = LoadClassIdInstr(r1)
    //     0xce3670: ldur            x3, [x1, #-1]
    //     0xce3674: ubfx            x3, x3, #0xc, #0x14
    // 0xce3678: stp             x0, x1, [SP]
    // 0xce367c: mov             x0, x3
    // 0xce3680: mov             lr, x0
    // 0xce3684: ldr             lr, [x21, lr, lsl #3]
    // 0xce3688: blr             lr
    // 0xce368c: tbnz            w0, #4, #0xce36a0
    // 0xce3690: r0 = Null
    //     0xce3690: mov             x0, NULL
    // 0xce3694: LeaveFrame
    //     0xce3694: mov             SP, fp
    //     0xce3698: ldp             fp, lr, [SP], #0x10
    // 0xce369c: ret
    //     0xce369c: ret             
    // 0xce36a0: ldur            x1, [fp, #-8]
    // 0xce36a4: ldur            x0, [fp, #-0x10]
    // 0xce36a8: StoreField: r1->field_5f = r0
    //     0xce36a8: stur            w0, [x1, #0x5f]
    //     0xce36ac: ldurb           w16, [x1, #-1]
    //     0xce36b0: ldurb           w17, [x0, #-1]
    //     0xce36b4: and             x16, x17, x16, lsr #2
    //     0xce36b8: tst             x16, HEAP, lsr #32
    //     0xce36bc: b.eq            #0xce36c4
    //     0xce36c0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce36c4: r0 = markNeedsLayout()
    //     0xce36c4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xce36c8: r0 = Null
    //     0xce36c8: mov             x0, NULL
    // 0xce36cc: LeaveFrame
    //     0xce36cc: mov             SP, fp
    //     0xce36d0: ldp             fp, lr, [SP], #0x10
    // 0xce36d4: ret
    //     0xce36d4: ret             
    // 0xce36d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce36d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce36dc: b               #0xce3668
  }
  set _ image=(/* No info */) {
    // ** addr: 0xce36e0, size: 0x25c
    // 0xce36e0: EnterFrame
    //     0xce36e0: stp             fp, lr, [SP, #-0x10]!
    //     0xce36e4: mov             fp, SP
    // 0xce36e8: AllocStack(0x18)
    //     0xce36e8: sub             SP, SP, #0x18
    // 0xce36ec: SetupParameters(RenderImage this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xce36ec: mov             x3, x1
    //     0xce36f0: stur            x1, [fp, #-0x10]
    //     0xce36f4: stur            x2, [fp, #-0x18]
    // 0xce36f8: CheckStackOverflow
    //     0xce36f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce36fc: cmp             SP, x16
    //     0xce3700: b.ls            #0xce3934
    // 0xce3704: LoadField: r4 = r3->field_57
    //     0xce3704: ldur            w4, [x3, #0x57]
    // 0xce3708: DecompressPointer r4
    //     0xce3708: add             x4, x4, HEAP, lsl #32
    // 0xce370c: cmp             w2, w4
    // 0xce3710: b.ne            #0xce3724
    // 0xce3714: r0 = Null
    //     0xce3714: mov             x0, NULL
    // 0xce3718: LeaveFrame
    //     0xce3718: mov             SP, fp
    //     0xce371c: ldp             fp, lr, [SP], #0x10
    // 0xce3720: ret
    //     0xce3720: ret             
    // 0xce3724: cmp             w2, NULL
    // 0xce3728: b.eq            #0xce3764
    // 0xce372c: cmp             w4, NULL
    // 0xce3730: b.eq            #0xce3764
    // 0xce3734: LoadField: r0 = r4->field_7
    //     0xce3734: ldur            w0, [x4, #7]
    // 0xce3738: DecompressPointer r0
    //     0xce3738: add             x0, x0, HEAP, lsl #32
    // 0xce373c: LoadField: r1 = r2->field_7
    //     0xce373c: ldur            w1, [x2, #7]
    // 0xce3740: DecompressPointer r1
    //     0xce3740: add             x1, x1, HEAP, lsl #32
    // 0xce3744: cmp             w0, w1
    // 0xce3748: b.ne            #0xce3764
    // 0xce374c: mov             x1, x2
    // 0xce3750: r0 = dispose()
    //     0xce3750: bl              #0xc02d74  ; [dart:ui] Image::dispose
    // 0xce3754: r0 = Null
    //     0xce3754: mov             x0, NULL
    // 0xce3758: LeaveFrame
    //     0xce3758: mov             SP, fp
    //     0xce375c: ldp             fp, lr, [SP], #0x10
    // 0xce3760: ret
    //     0xce3760: ret             
    // 0xce3764: cmp             w4, NULL
    // 0xce3768: b.ne            #0xce3774
    // 0xce376c: r5 = Null
    //     0xce376c: mov             x5, NULL
    // 0xce3770: b               #0xce3790
    // 0xce3774: LoadField: r5 = r4->field_f
    //     0xce3774: ldur            x5, [x4, #0xf]
    // 0xce3778: r0 = BoxInt64Instr(r5)
    //     0xce3778: sbfiz           x0, x5, #1, #0x1f
    //     0xce377c: cmp             x5, x0, asr #1
    //     0xce3780: b.eq            #0xce378c
    //     0xce3784: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xce3788: stur            x5, [x0, #7]
    // 0xce378c: mov             x5, x0
    // 0xce3790: cmp             w2, NULL
    // 0xce3794: b.ne            #0xce37a0
    // 0xce3798: r0 = Null
    //     0xce3798: mov             x0, NULL
    // 0xce379c: b               #0xce37b8
    // 0xce37a0: LoadField: r6 = r2->field_f
    //     0xce37a0: ldur            x6, [x2, #0xf]
    // 0xce37a4: r0 = BoxInt64Instr(r6)
    //     0xce37a4: sbfiz           x0, x6, #1, #0x1f
    //     0xce37a8: cmp             x6, x0, asr #1
    //     0xce37ac: b.eq            #0xce37b8
    //     0xce37b0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xce37b4: stur            x6, [x0, #7]
    // 0xce37b8: cmp             w5, w0
    // 0xce37bc: b.eq            #0xce3800
    // 0xce37c0: and             w16, w5, w0
    // 0xce37c4: branchIfSmi(r16, 0xce37f8)
    //     0xce37c4: tbz             w16, #0, #0xce37f8
    // 0xce37c8: r16 = LoadClassIdInstr(r5)
    //     0xce37c8: ldur            x16, [x5, #-1]
    //     0xce37cc: ubfx            x16, x16, #0xc, #0x14
    // 0xce37d0: cmp             x16, #0x3d
    // 0xce37d4: b.ne            #0xce37f8
    // 0xce37d8: r16 = LoadClassIdInstr(r0)
    //     0xce37d8: ldur            x16, [x0, #-1]
    //     0xce37dc: ubfx            x16, x16, #0xc, #0x14
    // 0xce37e0: cmp             x16, #0x3d
    // 0xce37e4: b.ne            #0xce37f8
    // 0xce37e8: LoadField: r16 = r5->field_7
    //     0xce37e8: ldur            x16, [x5, #7]
    // 0xce37ec: LoadField: r17 = r0->field_7
    //     0xce37ec: ldur            x17, [x0, #7]
    // 0xce37f0: cmp             x16, x17
    // 0xce37f4: b.eq            #0xce3800
    // 0xce37f8: r0 = true
    //     0xce37f8: add             x0, NULL, #0x20  ; true
    // 0xce37fc: b               #0xce38a4
    // 0xce3800: cmp             w4, NULL
    // 0xce3804: b.ne            #0xce3810
    // 0xce3808: r5 = Null
    //     0xce3808: mov             x5, NULL
    // 0xce380c: b               #0xce382c
    // 0xce3810: ArrayLoad: r5 = r4[0]  ; List_8
    //     0xce3810: ldur            x5, [x4, #0x17]
    // 0xce3814: r0 = BoxInt64Instr(r5)
    //     0xce3814: sbfiz           x0, x5, #1, #0x1f
    //     0xce3818: cmp             x5, x0, asr #1
    //     0xce381c: b.eq            #0xce3828
    //     0xce3820: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xce3824: stur            x5, [x0, #7]
    // 0xce3828: mov             x5, x0
    // 0xce382c: cmp             w2, NULL
    // 0xce3830: b.ne            #0xce383c
    // 0xce3834: r0 = Null
    //     0xce3834: mov             x0, NULL
    // 0xce3838: b               #0xce3854
    // 0xce383c: ArrayLoad: r6 = r2[0]  ; List_8
    //     0xce383c: ldur            x6, [x2, #0x17]
    // 0xce3840: r0 = BoxInt64Instr(r6)
    //     0xce3840: sbfiz           x0, x6, #1, #0x1f
    //     0xce3844: cmp             x6, x0, asr #1
    //     0xce3848: b.eq            #0xce3854
    //     0xce384c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xce3850: stur            x6, [x0, #7]
    // 0xce3854: cmp             w5, w0
    // 0xce3858: b.eq            #0xce3894
    // 0xce385c: and             w16, w5, w0
    // 0xce3860: branchIfSmi(r16, 0xce389c)
    //     0xce3860: tbz             w16, #0, #0xce389c
    // 0xce3864: r16 = LoadClassIdInstr(r5)
    //     0xce3864: ldur            x16, [x5, #-1]
    //     0xce3868: ubfx            x16, x16, #0xc, #0x14
    // 0xce386c: cmp             x16, #0x3d
    // 0xce3870: b.ne            #0xce389c
    // 0xce3874: r16 = LoadClassIdInstr(r0)
    //     0xce3874: ldur            x16, [x0, #-1]
    //     0xce3878: ubfx            x16, x16, #0xc, #0x14
    // 0xce387c: cmp             x16, #0x3d
    // 0xce3880: b.ne            #0xce389c
    // 0xce3884: LoadField: r16 = r5->field_7
    //     0xce3884: ldur            x16, [x5, #7]
    // 0xce3888: LoadField: r17 = r0->field_7
    //     0xce3888: ldur            x17, [x0, #7]
    // 0xce388c: cmp             x16, x17
    // 0xce3890: b.ne            #0xce389c
    // 0xce3894: r1 = false
    //     0xce3894: add             x1, NULL, #0x30  ; false
    // 0xce3898: b               #0xce38a0
    // 0xce389c: r1 = true
    //     0xce389c: add             x1, NULL, #0x20  ; true
    // 0xce38a0: mov             x0, x1
    // 0xce38a4: stur            x0, [fp, #-8]
    // 0xce38a8: cmp             w4, NULL
    // 0xce38ac: b.ne            #0xce38bc
    // 0xce38b0: mov             x2, x3
    // 0xce38b4: mov             x3, x0
    // 0xce38b8: b               #0xce38cc
    // 0xce38bc: mov             x1, x4
    // 0xce38c0: r0 = dispose()
    //     0xce38c0: bl              #0xc02d74  ; [dart:ui] Image::dispose
    // 0xce38c4: ldur            x2, [fp, #-0x10]
    // 0xce38c8: ldur            x3, [fp, #-8]
    // 0xce38cc: ldur            x0, [fp, #-0x18]
    // 0xce38d0: StoreField: r2->field_57 = r0
    //     0xce38d0: stur            w0, [x2, #0x57]
    //     0xce38d4: ldurb           w16, [x2, #-1]
    //     0xce38d8: ldurb           w17, [x0, #-1]
    //     0xce38dc: and             x16, x17, x16, lsr #2
    //     0xce38e0: tst             x16, HEAP, lsr #32
    //     0xce38e4: b.eq            #0xce38ec
    //     0xce38e8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xce38ec: mov             x1, x2
    // 0xce38f0: r0 = markNeedsPaint()
    //     0xce38f0: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce38f4: ldur            x0, [fp, #-8]
    // 0xce38f8: tbnz            w0, #4, #0xce3924
    // 0xce38fc: ldur            x1, [fp, #-0x10]
    // 0xce3900: LoadField: r0 = r1->field_5f
    //     0xce3900: ldur            w0, [x1, #0x5f]
    // 0xce3904: DecompressPointer r0
    //     0xce3904: add             x0, x0, HEAP, lsl #32
    // 0xce3908: cmp             w0, NULL
    // 0xce390c: b.eq            #0xce3920
    // 0xce3910: LoadField: r0 = r1->field_63
    //     0xce3910: ldur            w0, [x1, #0x63]
    // 0xce3914: DecompressPointer r0
    //     0xce3914: add             x0, x0, HEAP, lsl #32
    // 0xce3918: cmp             w0, NULL
    // 0xce391c: b.ne            #0xce3924
    // 0xce3920: r0 = markNeedsLayout()
    //     0xce3920: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xce3924: r0 = Null
    //     0xce3924: mov             x0, NULL
    // 0xce3928: LeaveFrame
    //     0xce3928: mov             SP, fp
    //     0xce392c: ldp             fp, lr, [SP], #0x10
    // 0xce3930: ret
    //     0xce3930: ret             
    // 0xce3934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3934: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce3938: b               #0xce3704
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f02dc, size: 0x24
    // 0x10f02dc: EnterFrame
    //     0x10f02dc: stp             fp, lr, [SP, #-0x10]!
    //     0x10f02e0: mov             fp, SP
    // 0x10f02e4: ldr             x2, [fp, #0x10]
    // 0x10f02e8: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f02e8: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1358] AnonymousClosure: (0xb260c0), in [package:flutter/src/rendering/image.dart] RenderImage::computeMinIntrinsicHeight (0xb25fec)
    //     0x10f02ec: ldr             x1, [x1, #0x358]
    // 0x10f02f0: r0 = AllocateClosure()
    //     0x10f02f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f02f4: LeaveFrame
    //     0x10f02f4: mov             SP, fp
    //     0x10f02f8: ldp             fp, lr, [SP], #0x10
    // 0x10f02fc: ret
    //     0x10f02fc: ret             
  }
  _ RenderImage(/* No info */) {
    // ** addr: 0x11c0c48, size: 0x1bc
    // 0x11c0c48: EnterFrame
    //     0x11c0c48: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0c4c: mov             fp, SP
    // 0x11c0c50: AllocStack(0x8)
    //     0x11c0c50: sub             SP, SP, #8
    // 0x11c0c54: r8 = Instance_ImageRepeat
    //     0x11c0c54: add             x8, PP, #0x16, lsl #12  ; [pp+0x16fb8] Obj!ImageRepeat@12c4821
    //     0x11c0c58: ldr             x8, [x8, #0xfb8]
    // 0x11c0c5c: r4 = false
    //     0x11c0c5c: add             x4, NULL, #0x30  ; false
    // 0x11c0c60: mov             x0, x5
    // 0x11c0c64: mov             x5, x2
    // 0x11c0c68: mov             x2, x6
    // 0x11c0c6c: mov             x6, x1
    // 0x11c0c70: stur            x1, [fp, #-8]
    // 0x11c0c74: mov             x1, x7
    // 0x11c0c78: CheckStackOverflow
    //     0x11c0c78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0c7c: cmp             SP, x16
    //     0x11c0c80: b.ls            #0x11c0dfc
    // 0x11c0c84: StoreField: r6->field_5b = r0
    //     0x11c0c84: stur            w0, [x6, #0x5b]
    //     0x11c0c88: ldurb           w16, [x6, #-1]
    //     0x11c0c8c: ldurb           w17, [x0, #-1]
    //     0x11c0c90: and             x16, x17, x16, lsr #2
    //     0x11c0c94: tst             x16, HEAP, lsr #32
    //     0x11c0c98: b.eq            #0x11c0ca0
    //     0x11c0c9c: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0ca0: ldr             x0, [fp, #0x28]
    // 0x11c0ca4: StoreField: r6->field_57 = r0
    //     0x11c0ca4: stur            w0, [x6, #0x57]
    //     0x11c0ca8: ldurb           w16, [x6, #-1]
    //     0x11c0cac: ldurb           w17, [x0, #-1]
    //     0x11c0cb0: and             x16, x17, x16, lsr #2
    //     0x11c0cb4: tst             x16, HEAP, lsr #32
    //     0x11c0cb8: b.eq            #0x11c0cc0
    //     0x11c0cbc: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0cc0: ldr             x0, [fp, #0x10]
    // 0x11c0cc4: StoreField: r6->field_5f = r0
    //     0x11c0cc4: stur            w0, [x6, #0x5f]
    //     0x11c0cc8: ldurb           w16, [x6, #-1]
    //     0x11c0ccc: ldurb           w17, [x0, #-1]
    //     0x11c0cd0: and             x16, x17, x16, lsr #2
    //     0x11c0cd4: tst             x16, HEAP, lsr #32
    //     0x11c0cd8: b.eq            #0x11c0ce0
    //     0x11c0cdc: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0ce0: ldr             x0, [fp, #0x30]
    // 0x11c0ce4: StoreField: r6->field_63 = r0
    //     0x11c0ce4: stur            w0, [x6, #0x63]
    //     0x11c0ce8: ldurb           w16, [x6, #-1]
    //     0x11c0cec: ldurb           w17, [x0, #-1]
    //     0x11c0cf0: and             x16, x17, x16, lsr #2
    //     0x11c0cf4: tst             x16, HEAP, lsr #32
    //     0x11c0cf8: b.eq            #0x11c0d00
    //     0x11c0cfc: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0d00: StoreField: r6->field_67 = d0
    //     0x11c0d00: stur            d0, [x6, #0x67]
    // 0x11c0d04: mov             x0, x3
    // 0x11c0d08: StoreField: r6->field_73 = r0
    //     0x11c0d08: stur            w0, [x6, #0x73]
    //     0x11c0d0c: ldurb           w16, [x6, #-1]
    //     0x11c0d10: ldurb           w17, [x0, #-1]
    //     0x11c0d14: and             x16, x17, x16, lsr #2
    //     0x11c0d18: tst             x16, HEAP, lsr #32
    //     0x11c0d1c: b.eq            #0x11c0d24
    //     0x11c0d20: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0d24: mov             x0, x1
    // 0x11c0d28: StoreField: r6->field_83 = r0
    //     0x11c0d28: stur            w0, [x6, #0x83]
    //     0x11c0d2c: ldurb           w16, [x6, #-1]
    //     0x11c0d30: ldurb           w17, [x0, #-1]
    //     0x11c0d34: and             x16, x17, x16, lsr #2
    //     0x11c0d38: tst             x16, HEAP, lsr #32
    //     0x11c0d3c: b.eq            #0x11c0d44
    //     0x11c0d40: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0d44: mov             x0, x5
    // 0x11c0d48: StoreField: r6->field_87 = r0
    //     0x11c0d48: stur            w0, [x6, #0x87]
    //     0x11c0d4c: ldurb           w16, [x6, #-1]
    //     0x11c0d50: ldurb           w17, [x0, #-1]
    //     0x11c0d54: and             x16, x17, x16, lsr #2
    //     0x11c0d58: tst             x16, HEAP, lsr #32
    //     0x11c0d5c: b.eq            #0x11c0d64
    //     0x11c0d60: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0d64: StoreField: r6->field_8b = r8
    //     0x11c0d64: stur            w8, [x6, #0x8b]
    // 0x11c0d68: StoreField: r6->field_97 = r4
    //     0x11c0d68: stur            w4, [x6, #0x97]
    // 0x11c0d6c: ldr             x0, [fp, #0x20]
    // 0x11c0d70: StoreField: r6->field_93 = r0
    //     0x11c0d70: stur            w0, [x6, #0x93]
    // 0x11c0d74: ldr             x0, [fp, #0x18]
    // 0x11c0d78: StoreField: r6->field_9b = r0
    //     0x11c0d78: stur            w0, [x6, #0x9b]
    //     0x11c0d7c: ldurb           w16, [x6, #-1]
    //     0x11c0d80: ldurb           w17, [x0, #-1]
    //     0x11c0d84: and             x16, x17, x16, lsr #2
    //     0x11c0d88: tst             x16, HEAP, lsr #32
    //     0x11c0d8c: b.eq            #0x11c0d94
    //     0x11c0d90: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0d94: StoreField: r6->field_9f = r4
    //     0x11c0d94: stur            w4, [x6, #0x9f]
    // 0x11c0d98: mov             x0, x2
    // 0x11c0d9c: StoreField: r6->field_7b = r0
    //     0x11c0d9c: stur            w0, [x6, #0x7b]
    //     0x11c0da0: ldurb           w16, [x6, #-1]
    //     0x11c0da4: ldurb           w17, [x0, #-1]
    //     0x11c0da8: and             x16, x17, x16, lsr #2
    //     0x11c0dac: tst             x16, HEAP, lsr #32
    //     0x11c0db0: b.eq            #0x11c0db8
    //     0x11c0db4: bl              #0x13de034  ; WriteBarrierWrappersStub
    // 0x11c0db8: r0 = _LayoutCacheStorage()
    //     0x11c0db8: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11c0dbc: ldur            x2, [fp, #-8]
    // 0x11c0dc0: StoreField: r2->field_47 = r0
    //     0x11c0dc0: stur            w0, [x2, #0x47]
    //     0x11c0dc4: ldurb           w16, [x2, #-1]
    //     0x11c0dc8: ldurb           w17, [x0, #-1]
    //     0x11c0dcc: and             x16, x17, x16, lsr #2
    //     0x11c0dd0: tst             x16, HEAP, lsr #32
    //     0x11c0dd4: b.eq            #0x11c0ddc
    //     0x11c0dd8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11c0ddc: mov             x1, x2
    // 0x11c0de0: r0 = RenderObject()
    //     0x11c0de0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11c0de4: ldur            x1, [fp, #-8]
    // 0x11c0de8: r0 = _updateColorFilter()
    //     0x11c0de8: bl              #0xce34c0  ; [package:flutter/src/rendering/image.dart] RenderImage::_updateColorFilter
    // 0x11c0dec: r0 = Null
    //     0x11c0dec: mov             x0, NULL
    // 0x11c0df0: LeaveFrame
    //     0x11c0df0: mov             SP, fp
    //     0x11c0df4: ldp             fp, lr, [SP], #0x10
    // 0x11c0df8: ret
    //     0x11c0df8: ret             
    // 0x11c0dfc: r0 = StackOverflowSharedWithFPURegs()
    //     0x11c0dfc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11c0e00: b               #0x11c0c84
  }
}
