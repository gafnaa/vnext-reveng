// lib: , url: package:flutter/src/rendering/list_body.dart

// class id: 1049032, size: 0x8
class :: {
}

// class id: 4211, size: 0x18, field offset: 0x18
class ListBodyParentData extends ContainerBoxParentData<dynamic> {
}

// class id: 4852, size: 0x64, field offset: 0x60
class RenderListBody extends _MixinApplication81&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb1bd3c, size: 0x24
    // 0xb1bd3c: EnterFrame
    //     0xb1bd3c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bd40: mov             fp, SP
    // 0xb1bd44: ldr             x2, [fp, #0x10]
    // 0xb1bd48: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1bd48: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3398] AnonymousClosure: (0xb1bd60), in [package:flutter/src/rendering/list_body.dart] RenderListBody::computeMinIntrinsicWidth (0xb1bdd8)
    //     0xb1bd4c: ldr             x1, [x1, #0x398]
    // 0xb1bd50: r0 = AllocateClosure()
    //     0xb1bd50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1bd54: LeaveFrame
    //     0xb1bd54: mov             SP, fp
    //     0xb1bd58: ldp             fp, lr, [SP], #0x10
    // 0xb1bd5c: ret
    //     0xb1bd5c: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb1bd60, size: 0x78
    // 0xb1bd60: EnterFrame
    //     0xb1bd60: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bd64: mov             fp, SP
    // 0xb1bd68: ldr             x0, [fp, #0x18]
    // 0xb1bd6c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1bd6c: ldur            w1, [x0, #0x17]
    // 0xb1bd70: DecompressPointer r1
    //     0xb1bd70: add             x1, x1, HEAP, lsl #32
    // 0xb1bd74: CheckStackOverflow
    //     0xb1bd74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1bd78: cmp             SP, x16
    //     0xb1bd7c: b.ls            #0xb1bdc0
    // 0xb1bd80: ldr             x2, [fp, #0x10]
    // 0xb1bd84: r0 = computeMinIntrinsicWidth()
    //     0xb1bd84: bl              #0xb1bdd8  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::computeMinIntrinsicWidth
    // 0xb1bd88: r0 = inline_Allocate_Double()
    //     0xb1bd88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1bd8c: add             x0, x0, #0x10
    //     0xb1bd90: cmp             x1, x0
    //     0xb1bd94: b.ls            #0xb1bdc8
    //     0xb1bd98: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1bd9c: sub             x0, x0, #0xf
    //     0xb1bda0: mov             x1, #0xe19c
    //     0xb1bda4: movk            x1, #3, lsl #16
    //     0xb1bda8: stur            x1, [x0, #-1]
    // 0xb1bdac: dmb             ishst
    // 0xb1bdb0: StoreField: r0->field_7 = d0
    //     0xb1bdb0: stur            d0, [x0, #7]
    // 0xb1bdb4: LeaveFrame
    //     0xb1bdb4: mov             SP, fp
    //     0xb1bdb8: ldp             fp, lr, [SP], #0x10
    // 0xb1bdbc: ret
    //     0xb1bdbc: ret             
    // 0xb1bdc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1bdc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1bdc4: b               #0xb1bd80
    // 0xb1bdc8: SaveReg d0
    //     0xb1bdc8: str             q0, [SP, #-0x10]!
    // 0xb1bdcc: r0 = AllocateDouble()
    //     0xb1bdcc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1bdd0: RestoreReg d0
    //     0xb1bdd0: ldr             q0, [SP], #0x10
    // 0xb1bdd4: b               #0xb1bdb0
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb1bdd8, size: 0x9c
    // 0xb1bdd8: EnterFrame
    //     0xb1bdd8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1bddc: mov             fp, SP
    // 0xb1bde0: AllocStack(0x18)
    //     0xb1bde0: sub             SP, SP, #0x18
    // 0xb1bde4: SetupParameters(RenderListBody this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb1bde4: stur            x1, [fp, #-8]
    //     0xb1bde8: stur            x2, [fp, #-0x10]
    // 0xb1bdec: CheckStackOverflow
    //     0xb1bdec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1bdf0: cmp             SP, x16
    //     0xb1bdf4: b.ls            #0xb1be6c
    // 0xb1bdf8: r1 = 1
    //     0xb1bdf8: mov             x1, #1
    // 0xb1bdfc: r0 = AllocateContext()
    //     0xb1bdfc: bl              #0x13de838  ; AllocateContextStub
    // 0xb1be00: mov             x2, x0
    // 0xb1be04: ldur            x0, [fp, #-0x10]
    // 0xb1be08: stur            x2, [fp, #-0x18]
    // 0xb1be0c: StoreField: r2->field_f = r0
    //     0xb1be0c: stur            w0, [x2, #0xf]
    // 0xb1be10: ldur            x1, [fp, #-8]
    // 0xb1be14: r0 = mainAxis()
    //     0xb1be14: bl              #0xb1c228  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::mainAxis
    // 0xb1be18: LoadField: r1 = r0->field_7
    //     0xb1be18: ldur            x1, [x0, #7]
    // 0xb1be1c: cmp             x1, #0
    // 0xb1be20: b.gt            #0xb1be44
    // 0xb1be24: ldur            x2, [fp, #-0x18]
    // 0xb1be28: r1 = Function '<anonymous closure>':.
    //     0xb1be28: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd33a0] AnonymousClosure: (0xb1c278), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicWidth (0xb1c2fc)
    //     0xb1be2c: ldr             x1, [x1, #0x3a0]
    // 0xb1be30: r0 = AllocateClosure()
    //     0xb1be30: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1be34: ldur            x1, [fp, #-8]
    // 0xb1be38: mov             x2, x0
    // 0xb1be3c: r0 = _getIntrinsicMainAxis()
    //     0xb1be3c: bl              #0xb1c0e4  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::_getIntrinsicMainAxis
    // 0xb1be40: b               #0xb1be60
    // 0xb1be44: ldur            x2, [fp, #-0x18]
    // 0xb1be48: r1 = Function '<anonymous closure>':.
    //     0xb1be48: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd33a8] AnonymousClosure: (0xb1c278), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicWidth (0xb1c2fc)
    //     0xb1be4c: ldr             x1, [x1, #0x3a8]
    // 0xb1be50: r0 = AllocateClosure()
    //     0xb1be50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1be54: ldur            x1, [fp, #-8]
    // 0xb1be58: mov             x2, x0
    // 0xb1be5c: r0 = _getIntrinsicCrossAxis()
    //     0xb1be5c: bl              #0xb1be74  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::_getIntrinsicCrossAxis
    // 0xb1be60: LeaveFrame
    //     0xb1be60: mov             SP, fp
    //     0xb1be64: ldp             fp, lr, [SP], #0x10
    // 0xb1be68: ret
    //     0xb1be68: ret             
    // 0xb1be6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1be6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1be70: b               #0xb1bdf8
  }
  _ _getIntrinsicCrossAxis(/* No info */) {
    // ** addr: 0xb1be74, size: 0x270
    // 0xb1be74: EnterFrame
    //     0xb1be74: stp             fp, lr, [SP, #-0x10]!
    //     0xb1be78: mov             fp, SP
    // 0xb1be7c: AllocStack(0x38)
    //     0xb1be7c: sub             SP, SP, #0x38
    // 0xb1be80: SetupParameters(RenderListBody this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xb1be80: mov             x0, x1
    //     0xb1be84: mov             x1, x2
    //     0xb1be88: stur            x2, [fp, #-0x18]
    // 0xb1be8c: CheckStackOverflow
    //     0xb1be8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1be90: cmp             SP, x16
    //     0xb1be94: b.ls            #0xb1c0c0
    // 0xb1be98: LoadField: r2 = r0->field_57
    //     0xb1be98: ldur            w2, [x0, #0x57]
    // 0xb1be9c: DecompressPointer r2
    //     0xb1be9c: add             x2, x2, HEAP, lsl #32
    // 0xb1bea0: r3 = 0.000000
    //     0xb1bea0: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb1bea4: stur            x3, [fp, #-8]
    // 0xb1bea8: stur            x2, [fp, #-0x10]
    // 0xb1beac: CheckStackOverflow
    //     0xb1beac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1beb0: cmp             SP, x16
    //     0xb1beb4: b.ls            #0xb1c0c8
    // 0xb1beb8: cmp             w2, NULL
    // 0xb1bebc: b.eq            #0xb1c0ac
    // 0xb1bec0: stp             x2, x1, [SP]
    // 0xb1bec4: mov             x0, x1
    // 0xb1bec8: ClosureCall
    //     0xb1bec8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb1becc: ldur            x2, [x0, #0x1f]
    //     0xb1bed0: blr             x2
    // 0xb1bed4: mov             x2, x0
    // 0xb1bed8: ldur            x1, [fp, #-8]
    // 0xb1bedc: stur            x2, [fp, #-0x20]
    // 0xb1bee0: r0 = 60
    //     0xb1bee0: mov             x0, #0x3c
    // 0xb1bee4: branchIfSmi(r1, 0xb1bef0)
    //     0xb1bee4: tbz             w1, #0, #0xb1bef0
    // 0xb1bee8: r0 = LoadClassIdInstr(r1)
    //     0xb1bee8: ldur            x0, [x1, #-1]
    //     0xb1beec: ubfx            x0, x0, #0xc, #0x14
    // 0xb1bef0: stp             x2, x1, [SP]
    // 0xb1bef4: r0 = GDT[cid_x0 + -0xfe5]()
    //     0xb1bef4: sub             lr, x0, #0xfe5
    //     0xb1bef8: ldr             lr, [x21, lr, lsl #3]
    //     0xb1befc: blr             lr
    // 0xb1bf00: tbnz            w0, #4, #0xb1bf0c
    // 0xb1bf04: ldur            x3, [fp, #-8]
    // 0xb1bf08: b               #0xb1c044
    // 0xb1bf0c: ldur            x1, [fp, #-8]
    // 0xb1bf10: r0 = 60
    //     0xb1bf10: mov             x0, #0x3c
    // 0xb1bf14: branchIfSmi(r1, 0xb1bf20)
    //     0xb1bf14: tbz             w1, #0, #0xb1bf20
    // 0xb1bf18: r0 = LoadClassIdInstr(r1)
    //     0xb1bf18: ldur            x0, [x1, #-1]
    //     0xb1bf1c: ubfx            x0, x0, #0xc, #0x14
    // 0xb1bf20: ldur            x16, [fp, #-0x20]
    // 0xb1bf24: stp             x16, x1, [SP]
    // 0xb1bf28: r0 = GDT[cid_x0 + -0xfe8]()
    //     0xb1bf28: sub             lr, x0, #0xfe8
    //     0xb1bf2c: ldr             lr, [x21, lr, lsl #3]
    //     0xb1bf30: blr             lr
    // 0xb1bf34: tbnz            w0, #4, #0xb1bf40
    // 0xb1bf38: ldur            x3, [fp, #-0x20]
    // 0xb1bf3c: b               #0xb1c044
    // 0xb1bf40: ldur            x1, [fp, #-0x20]
    // 0xb1bf44: r0 = 60
    //     0xb1bf44: mov             x0, #0x3c
    // 0xb1bf48: branchIfSmi(r1, 0xb1bf54)
    //     0xb1bf48: tbz             w1, #0, #0xb1bf54
    // 0xb1bf4c: r0 = LoadClassIdInstr(r1)
    //     0xb1bf4c: ldur            x0, [x1, #-1]
    //     0xb1bf50: ubfx            x0, x0, #0xc, #0x14
    // 0xb1bf54: cmp             x0, #0x3e
    // 0xb1bf58: b.ne            #0xb1bfe4
    // 0xb1bf5c: ldur            x2, [fp, #-8]
    // 0xb1bf60: r0 = 60
    //     0xb1bf60: mov             x0, #0x3c
    // 0xb1bf64: branchIfSmi(r2, 0xb1bf70)
    //     0xb1bf64: tbz             w2, #0, #0xb1bf70
    // 0xb1bf68: r0 = LoadClassIdInstr(r2)
    //     0xb1bf68: ldur            x0, [x2, #-1]
    //     0xb1bf6c: ubfx            x0, x0, #0xc, #0x14
    // 0xb1bf70: cmp             x0, #0x3e
    // 0xb1bf74: b.ne            #0xb1bfc4
    // 0xb1bf78: d0 = 0.000000
    //     0xb1bf78: eor             v0.16b, v0.16b, v0.16b
    // 0xb1bf7c: LoadField: d1 = r2->field_7
    //     0xb1bf7c: ldur            d1, [x2, #7]
    // 0xb1bf80: fcmp            d1, d0
    // 0xb1bf84: b.ne            #0xb1bfc8
    // 0xb1bf88: LoadField: d2 = r1->field_7
    //     0xb1bf88: ldur            d2, [x1, #7]
    // 0xb1bf8c: fadd            d3, d1, d2
    // 0xb1bf90: r0 = inline_Allocate_Double()
    //     0xb1bf90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1bf94: add             x0, x0, #0x10
    //     0xb1bf98: cmp             x1, x0
    //     0xb1bf9c: b.ls            #0xb1c0d0
    //     0xb1bfa0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1bfa4: sub             x0, x0, #0xf
    //     0xb1bfa8: mov             x1, #0xe19c
    //     0xb1bfac: movk            x1, #3, lsl #16
    //     0xb1bfb0: stur            x1, [x0, #-1]
    // 0xb1bfb4: dmb             ishst
    // 0xb1bfb8: StoreField: r0->field_7 = d3
    //     0xb1bfb8: stur            d3, [x0, #7]
    // 0xb1bfbc: mov             x3, x0
    // 0xb1bfc0: b               #0xb1c044
    // 0xb1bfc4: d0 = 0.000000
    //     0xb1bfc4: eor             v0.16b, v0.16b, v0.16b
    // 0xb1bfc8: LoadField: d1 = r1->field_7
    //     0xb1bfc8: ldur            d1, [x1, #7]
    // 0xb1bfcc: fcmp            d1, d1
    // 0xb1bfd0: b.vc            #0xb1bfdc
    // 0xb1bfd4: mov             x3, x1
    // 0xb1bfd8: b               #0xb1c044
    // 0xb1bfdc: mov             x3, x2
    // 0xb1bfe0: b               #0xb1c044
    // 0xb1bfe4: ldur            x2, [fp, #-8]
    // 0xb1bfe8: d0 = 0.000000
    //     0xb1bfe8: eor             v0.16b, v0.16b, v0.16b
    // 0xb1bfec: r0 = 60
    //     0xb1bfec: mov             x0, #0x3c
    // 0xb1bff0: branchIfSmi(r1, 0xb1bffc)
    //     0xb1bff0: tbz             w1, #0, #0xb1bffc
    // 0xb1bff4: r0 = LoadClassIdInstr(r1)
    //     0xb1bff4: ldur            x0, [x1, #-1]
    //     0xb1bff8: ubfx            x0, x0, #0xc, #0x14
    // 0xb1bffc: stp             xzr, x1, [SP]
    // 0xb1c000: mov             lr, x0
    // 0xb1c004: ldr             lr, [x21, lr, lsl #3]
    // 0xb1c008: blr             lr
    // 0xb1c00c: tbnz            w0, #4, #0xb1c040
    // 0xb1c010: ldur            x1, [fp, #-8]
    // 0xb1c014: r0 = 60
    //     0xb1c014: mov             x0, #0x3c
    // 0xb1c018: branchIfSmi(r1, 0xb1c024)
    //     0xb1c018: tbz             w1, #0, #0xb1c024
    // 0xb1c01c: r0 = LoadClassIdInstr(r1)
    //     0xb1c01c: ldur            x0, [x1, #-1]
    //     0xb1c020: ubfx            x0, x0, #0xc, #0x14
    // 0xb1c024: str             x1, [SP]
    // 0xb1c028: r0 = GDT[cid_x0 + -0xfca]()
    //     0xb1c028: sub             lr, x0, #0xfca
    //     0xb1c02c: ldr             lr, [x21, lr, lsl #3]
    //     0xb1c030: blr             lr
    // 0xb1c034: tbnz            w0, #4, #0xb1c040
    // 0xb1c038: ldur            x3, [fp, #-0x20]
    // 0xb1c03c: b               #0xb1c044
    // 0xb1c040: ldur            x3, [fp, #-8]
    // 0xb1c044: ldur            x0, [fp, #-0x10]
    // 0xb1c048: stur            x3, [fp, #-0x28]
    // 0xb1c04c: LoadField: r4 = r0->field_7
    //     0xb1c04c: ldur            w4, [x0, #7]
    // 0xb1c050: DecompressPointer r4
    //     0xb1c050: add             x4, x4, HEAP, lsl #32
    // 0xb1c054: stur            x4, [fp, #-0x20]
    // 0xb1c058: cmp             w4, NULL
    // 0xb1c05c: b.eq            #0xb1c0e0
    // 0xb1c060: mov             x0, x4
    // 0xb1c064: r2 = Null
    //     0xb1c064: mov             x2, NULL
    // 0xb1c068: r1 = Null
    //     0xb1c068: mov             x1, NULL
    // 0xb1c06c: r4 = LoadClassIdInstr(r0)
    //     0xb1c06c: ldur            x4, [x0, #-1]
    //     0xb1c070: ubfx            x4, x4, #0xc, #0x14
    // 0xb1c074: r17 = 4211
    //     0xb1c074: mov             x17, #0x1073
    // 0xb1c078: cmp             x4, x17
    // 0xb1c07c: b.eq            #0xb1c094
    // 0xb1c080: r8 = ListBodyParentData
    //     0xb1c080: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xb1c084: ldr             x8, [x8, #0x3b0]
    // 0xb1c088: r3 = Null
    //     0xb1c088: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd33b8] Null
    //     0xb1c08c: ldr             x3, [x3, #0x3b8]
    // 0xb1c090: r0 = DefaultTypeTest()
    //     0xb1c090: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb1c094: ldur            x0, [fp, #-0x20]
    // 0xb1c098: LoadField: r2 = r0->field_13
    //     0xb1c098: ldur            w2, [x0, #0x13]
    // 0xb1c09c: DecompressPointer r2
    //     0xb1c09c: add             x2, x2, HEAP, lsl #32
    // 0xb1c0a0: ldur            x3, [fp, #-0x28]
    // 0xb1c0a4: ldur            x1, [fp, #-0x18]
    // 0xb1c0a8: b               #0xb1bea4
    // 0xb1c0ac: mov             x0, x3
    // 0xb1c0b0: LoadField: d0 = r0->field_7
    //     0xb1c0b0: ldur            d0, [x0, #7]
    // 0xb1c0b4: LeaveFrame
    //     0xb1c0b4: mov             SP, fp
    //     0xb1c0b8: ldp             fp, lr, [SP], #0x10
    // 0xb1c0bc: ret
    //     0xb1c0bc: ret             
    // 0xb1c0c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c0c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c0c4: b               #0xb1be98
    // 0xb1c0c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c0c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c0cc: b               #0xb1beb8
    // 0xb1c0d0: stp             q0, q3, [SP, #-0x20]!
    // 0xb1c0d4: r0 = AllocateDouble()
    //     0xb1c0d4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1c0d8: ldp             q0, q3, [SP], #0x20
    // 0xb1c0dc: b               #0xb1bfb8
    // 0xb1c0e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1c0e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getIntrinsicMainAxis(/* No info */) {
    // ** addr: 0xb1c0e4, size: 0x144
    // 0xb1c0e4: EnterFrame
    //     0xb1c0e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c0e8: mov             fp, SP
    // 0xb1c0ec: AllocStack(0x38)
    //     0xb1c0ec: sub             SP, SP, #0x38
    // 0xb1c0f0: SetupParameters(RenderListBody this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb1c0f0: mov             x0, x1
    //     0xb1c0f4: mov             x1, x2
    //     0xb1c0f8: stur            x2, [fp, #-0x10]
    // 0xb1c0fc: CheckStackOverflow
    //     0xb1c0fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c100: cmp             SP, x16
    //     0xb1c104: b.ls            #0xb1c1f8
    // 0xb1c108: LoadField: r2 = r0->field_57
    //     0xb1c108: ldur            w2, [x0, #0x57]
    // 0xb1c10c: DecompressPointer r2
    //     0xb1c10c: add             x2, x2, HEAP, lsl #32
    // 0xb1c110: d0 = 0.000000
    //     0xb1c110: eor             v0.16b, v0.16b, v0.16b
    // 0xb1c114: stur            x2, [fp, #-8]
    // 0xb1c118: stur            d0, [fp, #-0x28]
    // 0xb1c11c: CheckStackOverflow
    //     0xb1c11c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c120: cmp             SP, x16
    //     0xb1c124: b.ls            #0xb1c200
    // 0xb1c128: cmp             w2, NULL
    // 0xb1c12c: b.eq            #0xb1c1ec
    // 0xb1c130: stp             x2, x1, [SP]
    // 0xb1c134: mov             x0, x1
    // 0xb1c138: ClosureCall
    //     0xb1c138: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb1c13c: ldur            x2, [x0, #0x1f]
    //     0xb1c140: blr             x2
    // 0xb1c144: ldur            d0, [fp, #-0x28]
    // 0xb1c148: r1 = inline_Allocate_Double()
    //     0xb1c148: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb1c14c: add             x1, x1, #0x10
    //     0xb1c150: cmp             x2, x1
    //     0xb1c154: b.ls            #0xb1c208
    //     0xb1c158: str             x1, [THR, #0x60]  ; THR::top
    //     0xb1c15c: sub             x1, x1, #0xf
    //     0xb1c160: mov             x2, #0xe19c
    //     0xb1c164: movk            x2, #3, lsl #16
    //     0xb1c168: stur            x2, [x1, #-1]
    // 0xb1c16c: dmb             ishst
    // 0xb1c170: StoreField: r1->field_7 = d0
    //     0xb1c170: stur            d0, [x1, #7]
    // 0xb1c174: stp             x0, x1, [SP]
    // 0xb1c178: r0 = +()
    //     0xb1c178: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xb1c17c: mov             x3, x0
    // 0xb1c180: ldur            x0, [fp, #-8]
    // 0xb1c184: stur            x3, [fp, #-0x20]
    // 0xb1c188: LoadField: r4 = r0->field_7
    //     0xb1c188: ldur            w4, [x0, #7]
    // 0xb1c18c: DecompressPointer r4
    //     0xb1c18c: add             x4, x4, HEAP, lsl #32
    // 0xb1c190: stur            x4, [fp, #-0x18]
    // 0xb1c194: cmp             w4, NULL
    // 0xb1c198: b.eq            #0xb1c224
    // 0xb1c19c: mov             x0, x4
    // 0xb1c1a0: r2 = Null
    //     0xb1c1a0: mov             x2, NULL
    // 0xb1c1a4: r1 = Null
    //     0xb1c1a4: mov             x1, NULL
    // 0xb1c1a8: r4 = LoadClassIdInstr(r0)
    //     0xb1c1a8: ldur            x4, [x0, #-1]
    //     0xb1c1ac: ubfx            x4, x4, #0xc, #0x14
    // 0xb1c1b0: r17 = 4211
    //     0xb1c1b0: mov             x17, #0x1073
    // 0xb1c1b4: cmp             x4, x17
    // 0xb1c1b8: b.eq            #0xb1c1d0
    // 0xb1c1bc: r8 = ListBodyParentData
    //     0xb1c1bc: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xb1c1c0: ldr             x8, [x8, #0x3b0]
    // 0xb1c1c4: r3 = Null
    //     0xb1c1c4: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd33c8] Null
    //     0xb1c1c8: ldr             x3, [x3, #0x3c8]
    // 0xb1c1cc: r0 = DefaultTypeTest()
    //     0xb1c1cc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb1c1d0: ldur            x0, [fp, #-0x18]
    // 0xb1c1d4: LoadField: r2 = r0->field_13
    //     0xb1c1d4: ldur            w2, [x0, #0x13]
    // 0xb1c1d8: DecompressPointer r2
    //     0xb1c1d8: add             x2, x2, HEAP, lsl #32
    // 0xb1c1dc: ldur            x0, [fp, #-0x20]
    // 0xb1c1e0: LoadField: d0 = r0->field_7
    //     0xb1c1e0: ldur            d0, [x0, #7]
    // 0xb1c1e4: ldur            x1, [fp, #-0x10]
    // 0xb1c1e8: b               #0xb1c114
    // 0xb1c1ec: LeaveFrame
    //     0xb1c1ec: mov             SP, fp
    //     0xb1c1f0: ldp             fp, lr, [SP], #0x10
    // 0xb1c1f4: ret
    //     0xb1c1f4: ret             
    // 0xb1c1f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c1f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c1fc: b               #0xb1c108
    // 0xb1c200: r0 = StackOverflowSharedWithFPURegs()
    //     0xb1c200: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb1c204: b               #0xb1c128
    // 0xb1c208: SaveReg d0
    //     0xb1c208: str             q0, [SP, #-0x10]!
    // 0xb1c20c: SaveReg r0
    //     0xb1c20c: str             x0, [SP, #-8]!
    // 0xb1c210: r0 = AllocateDouble()
    //     0xb1c210: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1c214: mov             x1, x0
    // 0xb1c218: RestoreReg r0
    //     0xb1c218: ldr             x0, [SP], #8
    // 0xb1c21c: RestoreReg d0
    //     0xb1c21c: ldr             q0, [SP], #0x10
    // 0xb1c220: b               #0xb1c170
    // 0xb1c224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1c224: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ mainAxis(/* No info */) {
    // ** addr: 0xb1c228, size: 0x50
    // 0xb1c228: LoadField: r2 = r1->field_5f
    //     0xb1c228: ldur            w2, [x1, #0x5f]
    // 0xb1c22c: DecompressPointer r2
    //     0xb1c22c: add             x2, x2, HEAP, lsl #32
    // 0xb1c230: r16 = Instance_AxisDirection
    //     0xb1c230: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xb1c234: cmp             w2, w16
    // 0xb1c238: b.eq            #0xb1c248
    // 0xb1c23c: r16 = Instance_AxisDirection
    //     0xb1c23c: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xb1c240: cmp             w2, w16
    // 0xb1c244: b.ne            #0xb1c250
    // 0xb1c248: r0 = Instance_Axis
    //     0xb1c248: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xb1c24c: b               #0xb1c274
    // 0xb1c250: r16 = Instance_AxisDirection
    //     0xb1c250: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xb1c254: cmp             w2, w16
    // 0xb1c258: b.eq            #0xb1c268
    // 0xb1c25c: r16 = Instance_AxisDirection
    //     0xb1c25c: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xb1c260: cmp             w2, w16
    // 0xb1c264: b.ne            #0xb1c270
    // 0xb1c268: r0 = Instance_Axis
    //     0xb1c268: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xb1c26c: b               #0xb1c274
    // 0xb1c270: r0 = Null
    //     0xb1c270: mov             x0, NULL
    // 0xb1c274: ret
    //     0xb1c274: ret             
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb24e5c, size: 0x9c
    // 0xb24e5c: EnterFrame
    //     0xb24e5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb24e60: mov             fp, SP
    // 0xb24e64: AllocStack(0x18)
    //     0xb24e64: sub             SP, SP, #0x18
    // 0xb24e68: SetupParameters(RenderListBody this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb24e68: stur            x1, [fp, #-8]
    //     0xb24e6c: stur            x2, [fp, #-0x10]
    // 0xb24e70: CheckStackOverflow
    //     0xb24e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb24e74: cmp             SP, x16
    //     0xb24e78: b.ls            #0xb24ef0
    // 0xb24e7c: r1 = 1
    //     0xb24e7c: mov             x1, #1
    // 0xb24e80: r0 = AllocateContext()
    //     0xb24e80: bl              #0x13de838  ; AllocateContextStub
    // 0xb24e84: mov             x2, x0
    // 0xb24e88: ldur            x0, [fp, #-0x10]
    // 0xb24e8c: stur            x2, [fp, #-0x18]
    // 0xb24e90: StoreField: r2->field_f = r0
    //     0xb24e90: stur            w0, [x2, #0xf]
    // 0xb24e94: ldur            x1, [fp, #-8]
    // 0xb24e98: r0 = mainAxis()
    //     0xb24e98: bl              #0xb1c228  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::mainAxis
    // 0xb24e9c: LoadField: r1 = r0->field_7
    //     0xb24e9c: ldur            x1, [x0, #7]
    // 0xb24ea0: cmp             x1, #0
    // 0xb24ea4: b.gt            #0xb24ec8
    // 0xb24ea8: ldur            x2, [fp, #-0x18]
    // 0xb24eac: r1 = Function '<anonymous closure>':.
    //     0xb24eac: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3428] AnonymousClosure: (0xb24f70), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicHeight (0xb25618)
    //     0xb24eb0: ldr             x1, [x1, #0x428]
    // 0xb24eb4: r0 = AllocateClosure()
    //     0xb24eb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb24eb8: ldur            x1, [fp, #-8]
    // 0xb24ebc: mov             x2, x0
    // 0xb24ec0: r0 = _getIntrinsicMainAxis()
    //     0xb24ec0: bl              #0xb1c0e4  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::_getIntrinsicMainAxis
    // 0xb24ec4: b               #0xb24ee4
    // 0xb24ec8: ldur            x2, [fp, #-0x18]
    // 0xb24ecc: r1 = Function '<anonymous closure>':.
    //     0xb24ecc: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3430] AnonymousClosure: (0xb24f70), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMinIntrinsicHeight (0xb25618)
    //     0xb24ed0: ldr             x1, [x1, #0x430]
    // 0xb24ed4: r0 = AllocateClosure()
    //     0xb24ed4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb24ed8: ldur            x1, [fp, #-8]
    // 0xb24edc: mov             x2, x0
    // 0xb24ee0: r0 = _getIntrinsicCrossAxis()
    //     0xb24ee0: bl              #0xb1be74  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::_getIntrinsicCrossAxis
    // 0xb24ee4: LeaveFrame
    //     0xb24ee4: mov             SP, fp
    //     0xb24ee8: ldp             fp, lr, [SP], #0x10
    // 0xb24eec: ret
    //     0xb24eec: ret             
    // 0xb24ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24ef0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24ef4: b               #0xb24e7c
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb24ef8, size: 0x78
    // 0xb24ef8: EnterFrame
    //     0xb24ef8: stp             fp, lr, [SP, #-0x10]!
    //     0xb24efc: mov             fp, SP
    // 0xb24f00: ldr             x0, [fp, #0x18]
    // 0xb24f04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb24f04: ldur            w1, [x0, #0x17]
    // 0xb24f08: DecompressPointer r1
    //     0xb24f08: add             x1, x1, HEAP, lsl #32
    // 0xb24f0c: CheckStackOverflow
    //     0xb24f0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb24f10: cmp             SP, x16
    //     0xb24f14: b.ls            #0xb24f58
    // 0xb24f18: ldr             x2, [fp, #0x10]
    // 0xb24f1c: r0 = computeMinIntrinsicHeight()
    //     0xb24f1c: bl              #0xb24e5c  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::computeMinIntrinsicHeight
    // 0xb24f20: r0 = inline_Allocate_Double()
    //     0xb24f20: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb24f24: add             x0, x0, #0x10
    //     0xb24f28: cmp             x1, x0
    //     0xb24f2c: b.ls            #0xb24f60
    //     0xb24f30: str             x0, [THR, #0x60]  ; THR::top
    //     0xb24f34: sub             x0, x0, #0xf
    //     0xb24f38: mov             x1, #0xe19c
    //     0xb24f3c: movk            x1, #3, lsl #16
    //     0xb24f40: stur            x1, [x0, #-1]
    // 0xb24f44: dmb             ishst
    // 0xb24f48: StoreField: r0->field_7 = d0
    //     0xb24f48: stur            d0, [x0, #7]
    // 0xb24f4c: LeaveFrame
    //     0xb24f4c: mov             SP, fp
    //     0xb24f50: ldp             fp, lr, [SP], #0x10
    // 0xb24f54: ret
    //     0xb24f54: ret             
    // 0xb24f58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24f58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24f5c: b               #0xb24f18
    // 0xb24f60: SaveReg d0
    //     0xb24f60: str             q0, [SP, #-0x10]!
    // 0xb24f64: r0 = AllocateDouble()
    //     0xb24f64: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb24f68: RestoreReg d0
    //     0xb24f68: ldr             q0, [SP], #0x10
    // 0xb24f6c: b               #0xb24f48
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2ab94, size: 0x9c
    // 0xb2ab94: EnterFrame
    //     0xb2ab94: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ab98: mov             fp, SP
    // 0xb2ab9c: AllocStack(0x18)
    //     0xb2ab9c: sub             SP, SP, #0x18
    // 0xb2aba0: SetupParameters(RenderListBody this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2aba0: stur            x1, [fp, #-8]
    //     0xb2aba4: stur            x2, [fp, #-0x10]
    // 0xb2aba8: CheckStackOverflow
    //     0xb2aba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2abac: cmp             SP, x16
    //     0xb2abb0: b.ls            #0xb2ac28
    // 0xb2abb4: r1 = 1
    //     0xb2abb4: mov             x1, #1
    // 0xb2abb8: r0 = AllocateContext()
    //     0xb2abb8: bl              #0x13de838  ; AllocateContextStub
    // 0xb2abbc: mov             x2, x0
    // 0xb2abc0: ldur            x0, [fp, #-0x10]
    // 0xb2abc4: stur            x2, [fp, #-0x18]
    // 0xb2abc8: StoreField: r2->field_f = r0
    //     0xb2abc8: stur            w0, [x2, #0xf]
    // 0xb2abcc: ldur            x1, [fp, #-8]
    // 0xb2abd0: r0 = mainAxis()
    //     0xb2abd0: bl              #0xb1c228  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::mainAxis
    // 0xb2abd4: LoadField: r1 = r0->field_7
    //     0xb2abd4: ldur            x1, [x0, #7]
    // 0xb2abd8: cmp             x1, #0
    // 0xb2abdc: b.gt            #0xb2ac00
    // 0xb2abe0: ldur            x2, [fp, #-0x18]
    // 0xb2abe4: r1 = Function '<anonymous closure>':.
    //     0xb2abe4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3418] AnonymousClosure: (0xb2aca8), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicHeight (0xb2b898)
    //     0xb2abe8: ldr             x1, [x1, #0x418]
    // 0xb2abec: r0 = AllocateClosure()
    //     0xb2abec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2abf0: ldur            x1, [fp, #-8]
    // 0xb2abf4: mov             x2, x0
    // 0xb2abf8: r0 = _getIntrinsicMainAxis()
    //     0xb2abf8: bl              #0xb1c0e4  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::_getIntrinsicMainAxis
    // 0xb2abfc: b               #0xb2ac1c
    // 0xb2ac00: ldur            x2, [fp, #-0x18]
    // 0xb2ac04: r1 = Function '<anonymous closure>':.
    //     0xb2ac04: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3420] AnonymousClosure: (0xb2aca8), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicHeight (0xb2b898)
    //     0xb2ac08: ldr             x1, [x1, #0x420]
    // 0xb2ac0c: r0 = AllocateClosure()
    //     0xb2ac0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2ac10: ldur            x1, [fp, #-8]
    // 0xb2ac14: mov             x2, x0
    // 0xb2ac18: r0 = _getIntrinsicCrossAxis()
    //     0xb2ac18: bl              #0xb1be74  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::_getIntrinsicCrossAxis
    // 0xb2ac1c: LeaveFrame
    //     0xb2ac1c: mov             SP, fp
    //     0xb2ac20: ldp             fp, lr, [SP], #0x10
    // 0xb2ac24: ret
    //     0xb2ac24: ret             
    // 0xb2ac28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ac28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ac2c: b               #0xb2abb4
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2ac30, size: 0x78
    // 0xb2ac30: EnterFrame
    //     0xb2ac30: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ac34: mov             fp, SP
    // 0xb2ac38: ldr             x0, [fp, #0x18]
    // 0xb2ac3c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2ac3c: ldur            w1, [x0, #0x17]
    // 0xb2ac40: DecompressPointer r1
    //     0xb2ac40: add             x1, x1, HEAP, lsl #32
    // 0xb2ac44: CheckStackOverflow
    //     0xb2ac44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ac48: cmp             SP, x16
    //     0xb2ac4c: b.ls            #0xb2ac90
    // 0xb2ac50: ldr             x2, [fp, #0x10]
    // 0xb2ac54: r0 = computeMaxIntrinsicHeight()
    //     0xb2ac54: bl              #0xb2ab94  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::computeMaxIntrinsicHeight
    // 0xb2ac58: r0 = inline_Allocate_Double()
    //     0xb2ac58: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2ac5c: add             x0, x0, #0x10
    //     0xb2ac60: cmp             x1, x0
    //     0xb2ac64: b.ls            #0xb2ac98
    //     0xb2ac68: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2ac6c: sub             x0, x0, #0xf
    //     0xb2ac70: mov             x1, #0xe19c
    //     0xb2ac74: movk            x1, #3, lsl #16
    //     0xb2ac78: stur            x1, [x0, #-1]
    // 0xb2ac7c: dmb             ishst
    // 0xb2ac80: StoreField: r0->field_7 = d0
    //     0xb2ac80: stur            d0, [x0, #7]
    // 0xb2ac84: LeaveFrame
    //     0xb2ac84: mov             SP, fp
    //     0xb2ac88: ldp             fp, lr, [SP], #0x10
    // 0xb2ac8c: ret
    //     0xb2ac8c: ret             
    // 0xb2ac90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ac90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ac94: b               #0xb2ac50
    // 0xb2ac98: SaveReg d0
    //     0xb2ac98: str             q0, [SP, #-0x10]!
    // 0xb2ac9c: r0 = AllocateDouble()
    //     0xb2ac9c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2aca0: RestoreReg d0
    //     0xb2aca0: ldr             q0, [SP], #0x10
    // 0xb2aca4: b               #0xb2ac80
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2e25c, size: 0x9c
    // 0xb2e25c: EnterFrame
    //     0xb2e25c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e260: mov             fp, SP
    // 0xb2e264: AllocStack(0x18)
    //     0xb2e264: sub             SP, SP, #0x18
    // 0xb2e268: SetupParameters(RenderListBody this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2e268: stur            x1, [fp, #-8]
    //     0xb2e26c: stur            x2, [fp, #-0x10]
    // 0xb2e270: CheckStackOverflow
    //     0xb2e270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e274: cmp             SP, x16
    //     0xb2e278: b.ls            #0xb2e2f0
    // 0xb2e27c: r1 = 1
    //     0xb2e27c: mov             x1, #1
    // 0xb2e280: r0 = AllocateContext()
    //     0xb2e280: bl              #0x13de838  ; AllocateContextStub
    // 0xb2e284: mov             x2, x0
    // 0xb2e288: ldur            x0, [fp, #-0x10]
    // 0xb2e28c: stur            x2, [fp, #-0x18]
    // 0xb2e290: StoreField: r2->field_f = r0
    //     0xb2e290: stur            w0, [x2, #0xf]
    // 0xb2e294: ldur            x1, [fp, #-8]
    // 0xb2e298: r0 = mainAxis()
    //     0xb2e298: bl              #0xb1c228  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::mainAxis
    // 0xb2e29c: LoadField: r1 = r0->field_7
    //     0xb2e29c: ldur            x1, [x0, #7]
    // 0xb2e2a0: cmp             x1, #0
    // 0xb2e2a4: b.gt            #0xb2e2c8
    // 0xb2e2a8: ldur            x2, [fp, #-0x18]
    // 0xb2e2ac: r1 = Function '<anonymous closure>':.
    //     0xb2e2ac: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3438] AnonymousClosure: (0xb2e370), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicWidth (0xb2ea1c)
    //     0xb2e2b0: ldr             x1, [x1, #0x438]
    // 0xb2e2b4: r0 = AllocateClosure()
    //     0xb2e2b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2e2b8: ldur            x1, [fp, #-8]
    // 0xb2e2bc: mov             x2, x0
    // 0xb2e2c0: r0 = _getIntrinsicMainAxis()
    //     0xb2e2c0: bl              #0xb1c0e4  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::_getIntrinsicMainAxis
    // 0xb2e2c4: b               #0xb2e2e4
    // 0xb2e2c8: ldur            x2, [fp, #-0x18]
    // 0xb2e2cc: r1 = Function '<anonymous closure>':.
    //     0xb2e2cc: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3440] AnonymousClosure: (0xb2e370), in [package:flutter/src/rendering/stack.dart] RenderStack::computeMaxIntrinsicWidth (0xb2ea1c)
    //     0xb2e2d0: ldr             x1, [x1, #0x440]
    // 0xb2e2d4: r0 = AllocateClosure()
    //     0xb2e2d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2e2d8: ldur            x1, [fp, #-8]
    // 0xb2e2dc: mov             x2, x0
    // 0xb2e2e0: r0 = _getIntrinsicCrossAxis()
    //     0xb2e2e0: bl              #0xb1be74  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::_getIntrinsicCrossAxis
    // 0xb2e2e4: LeaveFrame
    //     0xb2e2e4: mov             SP, fp
    //     0xb2e2e8: ldp             fp, lr, [SP], #0x10
    // 0xb2e2ec: ret
    //     0xb2e2ec: ret             
    // 0xb2e2f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e2f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e2f4: b               #0xb2e27c
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2e2f8, size: 0x78
    // 0xb2e2f8: EnterFrame
    //     0xb2e2f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e2fc: mov             fp, SP
    // 0xb2e300: ldr             x0, [fp, #0x18]
    // 0xb2e304: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2e304: ldur            w1, [x0, #0x17]
    // 0xb2e308: DecompressPointer r1
    //     0xb2e308: add             x1, x1, HEAP, lsl #32
    // 0xb2e30c: CheckStackOverflow
    //     0xb2e30c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e310: cmp             SP, x16
    //     0xb2e314: b.ls            #0xb2e358
    // 0xb2e318: ldr             x2, [fp, #0x10]
    // 0xb2e31c: r0 = computeMaxIntrinsicWidth()
    //     0xb2e31c: bl              #0xb2e25c  ; [package:flutter/src/rendering/list_body.dart] RenderListBody::computeMaxIntrinsicWidth
    // 0xb2e320: r0 = inline_Allocate_Double()
    //     0xb2e320: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2e324: add             x0, x0, #0x10
    //     0xb2e328: cmp             x1, x0
    //     0xb2e32c: b.ls            #0xb2e360
    //     0xb2e330: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2e334: sub             x0, x0, #0xf
    //     0xb2e338: mov             x1, #0xe19c
    //     0xb2e33c: movk            x1, #3, lsl #16
    //     0xb2e340: stur            x1, [x0, #-1]
    // 0xb2e344: dmb             ishst
    // 0xb2e348: StoreField: r0->field_7 = d0
    //     0xb2e348: stur            d0, [x0, #7]
    // 0xb2e34c: LeaveFrame
    //     0xb2e34c: mov             SP, fp
    //     0xb2e350: ldp             fp, lr, [SP], #0x10
    // 0xb2e354: ret
    //     0xb2e354: ret             
    // 0xb2e358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e358: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e35c: b               #0xb2e318
    // 0xb2e360: SaveReg d0
    //     0xb2e360: str             q0, [SP, #-0x10]!
    // 0xb2e364: r0 = AllocateDouble()
    //     0xb2e364: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2e368: RestoreReg d0
    //     0xb2e368: ldr             q0, [SP], #0x10
    // 0xb2e36c: b               #0xb2e348
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb51278, size: 0x2dc
    // 0xb51278: EnterFrame
    //     0xb51278: stp             fp, lr, [SP, #-0x10]!
    //     0xb5127c: mov             fp, SP
    // 0xb51280: AllocStack(0x68)
    //     0xb51280: sub             SP, SP, #0x68
    // 0xb51284: SetupParameters(RenderListBody this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb51284: mov             x0, x1
    //     0xb51288: mov             x1, x2
    //     0xb5128c: stur            x2, [fp, #-0x10]
    // 0xb51290: CheckStackOverflow
    //     0xb51290: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb51294: cmp             SP, x16
    //     0xb51298: b.ls            #0xb51534
    // 0xb5129c: LoadField: r2 = r0->field_57
    //     0xb5129c: ldur            w2, [x0, #0x57]
    // 0xb512a0: DecompressPointer r2
    //     0xb512a0: add             x2, x2, HEAP, lsl #32
    // 0xb512a4: stur            x2, [fp, #-8]
    // 0xb512a8: LoadField: r3 = r0->field_5f
    //     0xb512a8: ldur            w3, [x0, #0x5f]
    // 0xb512ac: DecompressPointer r3
    //     0xb512ac: add             x3, x3, HEAP, lsl #32
    // 0xb512b0: LoadField: r0 = r3->field_7
    //     0xb512b0: ldur            x0, [x3, #7]
    // 0xb512b4: cmp             x0, #1
    // 0xb512b8: b.gt            #0xb512cc
    // 0xb512bc: cmp             x0, #0
    // 0xb512c0: b.le            #0xb512d4
    // 0xb512c4: d1 = inf
    //     0xb512c4: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb512c8: b               #0xb51408
    // 0xb512cc: cmp             x0, #2
    // 0xb512d0: b.gt            #0xb51400
    // 0xb512d4: LoadField: d0 = r1->field_f
    //     0xb512d4: ldur            d0, [x1, #0xf]
    // 0xb512d8: stur            d0, [fp, #-0x30]
    // 0xb512dc: r0 = BoxConstraints()
    //     0xb512dc: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb512e0: ldur            d0, [fp, #-0x30]
    // 0xb512e4: stur            x0, [fp, #-0x20]
    // 0xb512e8: StoreField: r0->field_7 = d0
    //     0xb512e8: stur            d0, [x0, #7]
    // 0xb512ec: StoreField: r0->field_f = d0
    //     0xb512ec: stur            d0, [x0, #0xf]
    // 0xb512f0: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb512f0: stur            xzr, [x0, #0x17]
    // 0xb512f4: d1 = inf
    //     0xb512f4: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb512f8: StoreField: r0->field_1f = d1
    //     0xb512f8: stur            d1, [x0, #0x1f]
    // 0xb512fc: ldur            x3, [fp, #-8]
    // 0xb51300: d1 = 0.000000
    //     0xb51300: eor             v1.16b, v1.16b, v1.16b
    // 0xb51304: stur            x3, [fp, #-0x18]
    // 0xb51308: stur            d1, [fp, #-0x38]
    // 0xb5130c: CheckStackOverflow
    //     0xb5130c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb51310: cmp             SP, x16
    //     0xb51314: b.ls            #0xb5153c
    // 0xb51318: cmp             w3, NULL
    // 0xb5131c: b.eq            #0xb513d4
    // 0xb51320: mov             x2, x3
    // 0xb51324: r1 = Function '_computeDryLayout@29392247':.
    //     0xb51324: add             x1, PP, #0x27, lsl #12  ; [pp+0x27010] AnonymousClosure: (0xb20488), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout (0xb204c4)
    //     0xb51328: ldr             x1, [x1, #0x10]
    // 0xb5132c: r0 = AllocateClosure()
    //     0xb5132c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb51330: r16 = <BoxConstraints, Size>
    //     0xb51330: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0xb51334: ldr             x16, [x16, #0x18]
    // 0xb51338: ldur            lr, [fp, #-0x18]
    // 0xb5133c: stp             lr, x16, [SP, #0x18]
    // 0xb51340: r16 = Instance__DryLayout
    //     0xb51340: add             x16, PP, #0x27, lsl #12  ; [pp+0x27020] Obj!_DryLayout@129c191
    //     0xb51344: ldr             x16, [x16, #0x20]
    // 0xb51348: ldur            lr, [fp, #-0x20]
    // 0xb5134c: stp             lr, x16, [SP, #8]
    // 0xb51350: str             x0, [SP]
    // 0xb51354: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb51354: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb51358: r0 = _computeIntrinsics()
    //     0xb51358: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb5135c: LoadField: d0 = r0->field_f
    //     0xb5135c: ldur            d0, [x0, #0xf]
    // 0xb51360: ldur            d1, [fp, #-0x38]
    // 0xb51364: fadd            d2, d1, d0
    // 0xb51368: ldur            x0, [fp, #-0x18]
    // 0xb5136c: stur            d2, [fp, #-0x40]
    // 0xb51370: LoadField: r3 = r0->field_7
    //     0xb51370: ldur            w3, [x0, #7]
    // 0xb51374: DecompressPointer r3
    //     0xb51374: add             x3, x3, HEAP, lsl #32
    // 0xb51378: stur            x3, [fp, #-0x28]
    // 0xb5137c: cmp             w3, NULL
    // 0xb51380: b.eq            #0xb51544
    // 0xb51384: mov             x0, x3
    // 0xb51388: r2 = Null
    //     0xb51388: mov             x2, NULL
    // 0xb5138c: r1 = Null
    //     0xb5138c: mov             x1, NULL
    // 0xb51390: r4 = LoadClassIdInstr(r0)
    //     0xb51390: ldur            x4, [x0, #-1]
    //     0xb51394: ubfx            x4, x4, #0xc, #0x14
    // 0xb51398: r17 = 4211
    //     0xb51398: mov             x17, #0x1073
    // 0xb5139c: cmp             x4, x17
    // 0xb513a0: b.eq            #0xb513b8
    // 0xb513a4: r8 = ListBodyParentData
    //     0xb513a4: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xb513a8: ldr             x8, [x8, #0x3b0]
    // 0xb513ac: r3 = Null
    //     0xb513ac: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd34b8] Null
    //     0xb513b0: ldr             x3, [x3, #0x4b8]
    // 0xb513b4: r0 = DefaultTypeTest()
    //     0xb513b4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb513b8: ldur            x0, [fp, #-0x28]
    // 0xb513bc: LoadField: r3 = r0->field_13
    //     0xb513bc: ldur            w3, [x0, #0x13]
    // 0xb513c0: DecompressPointer r3
    //     0xb513c0: add             x3, x3, HEAP, lsl #32
    // 0xb513c4: ldur            d1, [fp, #-0x40]
    // 0xb513c8: ldur            x0, [fp, #-0x20]
    // 0xb513cc: ldur            d0, [fp, #-0x30]
    // 0xb513d0: b               #0xb51304
    // 0xb513d4: r0 = Size()
    //     0xb513d4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb513d8: ldur            d0, [fp, #-0x30]
    // 0xb513dc: StoreField: r0->field_7 = d0
    //     0xb513dc: stur            d0, [x0, #7]
    // 0xb513e0: ldur            d0, [fp, #-0x38]
    // 0xb513e4: StoreField: r0->field_f = d0
    //     0xb513e4: stur            d0, [x0, #0xf]
    // 0xb513e8: ldur            x1, [fp, #-0x10]
    // 0xb513ec: mov             x2, x0
    // 0xb513f0: r0 = constrain()
    //     0xb513f0: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb513f4: LeaveFrame
    //     0xb513f4: mov             SP, fp
    //     0xb513f8: ldp             fp, lr, [SP], #0x10
    // 0xb513fc: ret
    //     0xb513fc: ret             
    // 0xb51400: d1 = inf
    //     0xb51400: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb51404: ldur            x1, [fp, #-0x10]
    // 0xb51408: LoadField: d0 = r1->field_1f
    //     0xb51408: ldur            d0, [x1, #0x1f]
    // 0xb5140c: stur            d0, [fp, #-0x30]
    // 0xb51410: r0 = BoxConstraints()
    //     0xb51410: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb51414: stur            x0, [fp, #-0x18]
    // 0xb51418: StoreField: r0->field_7 = rZR
    //     0xb51418: stur            xzr, [x0, #7]
    // 0xb5141c: d0 = inf
    //     0xb5141c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb51420: StoreField: r0->field_f = d0
    //     0xb51420: stur            d0, [x0, #0xf]
    // 0xb51424: ldur            d0, [fp, #-0x30]
    // 0xb51428: ArrayStore: r0[0] = d0  ; List_8
    //     0xb51428: stur            d0, [x0, #0x17]
    // 0xb5142c: StoreField: r0->field_1f = d0
    //     0xb5142c: stur            d0, [x0, #0x1f]
    // 0xb51430: ldur            x3, [fp, #-8]
    // 0xb51434: d1 = 0.000000
    //     0xb51434: eor             v1.16b, v1.16b, v1.16b
    // 0xb51438: stur            x3, [fp, #-8]
    // 0xb5143c: stur            d1, [fp, #-0x38]
    // 0xb51440: CheckStackOverflow
    //     0xb51440: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb51444: cmp             SP, x16
    //     0xb51448: b.ls            #0xb51548
    // 0xb5144c: cmp             w3, NULL
    // 0xb51450: b.eq            #0xb51508
    // 0xb51454: mov             x2, x3
    // 0xb51458: r1 = Function '_computeDryLayout@29392247':.
    //     0xb51458: add             x1, PP, #0x27, lsl #12  ; [pp+0x27010] AnonymousClosure: (0xb20488), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout (0xb204c4)
    //     0xb5145c: ldr             x1, [x1, #0x10]
    // 0xb51460: r0 = AllocateClosure()
    //     0xb51460: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb51464: r16 = <BoxConstraints, Size>
    //     0xb51464: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0xb51468: ldr             x16, [x16, #0x18]
    // 0xb5146c: ldur            lr, [fp, #-8]
    // 0xb51470: stp             lr, x16, [SP, #0x18]
    // 0xb51474: r16 = Instance__DryLayout
    //     0xb51474: add             x16, PP, #0x27, lsl #12  ; [pp+0x27020] Obj!_DryLayout@129c191
    //     0xb51478: ldr             x16, [x16, #0x20]
    // 0xb5147c: ldur            lr, [fp, #-0x18]
    // 0xb51480: stp             lr, x16, [SP, #8]
    // 0xb51484: str             x0, [SP]
    // 0xb51488: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb51488: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb5148c: r0 = _computeIntrinsics()
    //     0xb5148c: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb51490: LoadField: d0 = r0->field_7
    //     0xb51490: ldur            d0, [x0, #7]
    // 0xb51494: ldur            d1, [fp, #-0x38]
    // 0xb51498: fadd            d2, d1, d0
    // 0xb5149c: ldur            x0, [fp, #-8]
    // 0xb514a0: stur            d2, [fp, #-0x40]
    // 0xb514a4: LoadField: r3 = r0->field_7
    //     0xb514a4: ldur            w3, [x0, #7]
    // 0xb514a8: DecompressPointer r3
    //     0xb514a8: add             x3, x3, HEAP, lsl #32
    // 0xb514ac: stur            x3, [fp, #-0x20]
    // 0xb514b0: cmp             w3, NULL
    // 0xb514b4: b.eq            #0xb51550
    // 0xb514b8: mov             x0, x3
    // 0xb514bc: r2 = Null
    //     0xb514bc: mov             x2, NULL
    // 0xb514c0: r1 = Null
    //     0xb514c0: mov             x1, NULL
    // 0xb514c4: r4 = LoadClassIdInstr(r0)
    //     0xb514c4: ldur            x4, [x0, #-1]
    //     0xb514c8: ubfx            x4, x4, #0xc, #0x14
    // 0xb514cc: r17 = 4211
    //     0xb514cc: mov             x17, #0x1073
    // 0xb514d0: cmp             x4, x17
    // 0xb514d4: b.eq            #0xb514ec
    // 0xb514d8: r8 = ListBodyParentData
    //     0xb514d8: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xb514dc: ldr             x8, [x8, #0x3b0]
    // 0xb514e0: r3 = Null
    //     0xb514e0: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd34c8] Null
    //     0xb514e4: ldr             x3, [x3, #0x4c8]
    // 0xb514e8: r0 = DefaultTypeTest()
    //     0xb514e8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb514ec: ldur            x0, [fp, #-0x20]
    // 0xb514f0: LoadField: r3 = r0->field_13
    //     0xb514f0: ldur            w3, [x0, #0x13]
    // 0xb514f4: DecompressPointer r3
    //     0xb514f4: add             x3, x3, HEAP, lsl #32
    // 0xb514f8: ldur            d1, [fp, #-0x40]
    // 0xb514fc: ldur            x0, [fp, #-0x18]
    // 0xb51500: ldur            d0, [fp, #-0x30]
    // 0xb51504: b               #0xb51438
    // 0xb51508: r0 = Size()
    //     0xb51508: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb5150c: ldur            d0, [fp, #-0x38]
    // 0xb51510: StoreField: r0->field_7 = d0
    //     0xb51510: stur            d0, [x0, #7]
    // 0xb51514: ldur            d0, [fp, #-0x30]
    // 0xb51518: StoreField: r0->field_f = d0
    //     0xb51518: stur            d0, [x0, #0xf]
    // 0xb5151c: ldur            x1, [fp, #-0x10]
    // 0xb51520: mov             x2, x0
    // 0xb51524: r0 = constrain()
    //     0xb51524: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb51528: LeaveFrame
    //     0xb51528: mov             SP, fp
    //     0xb5152c: ldp             fp, lr, [SP], #0x10
    // 0xb51530: ret
    //     0xb51530: ret             
    // 0xb51534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb51534: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb51538: b               #0xb5129c
    // 0xb5153c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb5153c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb51540: b               #0xb51318
    // 0xb51544: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb51544: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb51548: r0 = StackOverflowSharedWithFPURegs()
    //     0xb51548: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb5154c: b               #0xb5144c
    // 0xb51550: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb51550: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb585e8, size: 0x24
    // 0xb585e8: EnterFrame
    //     0xb585e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb585ec: mov             fp, SP
    // 0xb585f0: ldr             x2, [fp, #0x10]
    // 0xb585f4: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb585f4: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3390] AnonymousClosure: (0xb2e2f8), in [package:flutter/src/rendering/list_body.dart] RenderListBody::computeMaxIntrinsicWidth (0xb2e25c)
    //     0xb585f8: ldr             x1, [x1, #0x390]
    // 0xb585fc: r0 = AllocateClosure()
    //     0xb585fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58600: LeaveFrame
    //     0xb58600: mov             SP, fp
    //     0xb58604: ldp             fp, lr, [SP], #0x10
    // 0xb58608: ret
    //     0xb58608: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5b0b4, size: 0x2c
    // 0xb5b0b4: EnterFrame
    //     0xb5b0b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5b0b8: mov             fp, SP
    // 0xb5b0bc: CheckStackOverflow
    //     0xb5b0bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5b0c0: cmp             SP, x16
    //     0xb5b0c4: b.ls            #0xb5b0d8
    // 0xb5b0c8: r0 = defaultComputeDistanceToFirstActualBaseline()
    //     0xb5b0c8: bl              #0xb5b0e0  ; [dart:mixin_deduplication] _MixinApplication81&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultComputeDistanceToFirstActualBaseline
    // 0xb5b0cc: LeaveFrame
    //     0xb5b0cc: mov             SP, fp
    //     0xb5b0d0: ldp             fp, lr, [SP], #0x10
    // 0xb5b0d4: ret
    //     0xb5b0d4: ret             
    // 0xb5b0d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5b0d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5b0dc: b               #0xb5b0c8
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e794, size: 0x24
    // 0xb5e794: EnterFrame
    //     0xb5e794: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e798: mov             fp, SP
    // 0xb5e79c: ldr             x2, [fp, #0x10]
    // 0xb5e7a0: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e7a0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3380] AnonymousClosure: (0xb2ac30), in [package:flutter/src/rendering/list_body.dart] RenderListBody::computeMaxIntrinsicHeight (0xb2ab94)
    //     0xb5e7a4: ldr             x1, [x1, #0x380]
    // 0xb5e7a8: r0 = AllocateClosure()
    //     0xb5e7a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e7ac: LeaveFrame
    //     0xb5e7ac: mov             SP, fp
    //     0xb5e7b0: ldp             fp, lr, [SP], #0x10
    // 0xb5e7b4: ret
    //     0xb5e7b4: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb639e8, size: 0x490
    // 0xb639e8: EnterFrame
    //     0xb639e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb639ec: mov             fp, SP
    // 0xb639f0: AllocStack(0x70)
    //     0xb639f0: sub             SP, SP, #0x70
    // 0xb639f4: SetupParameters(RenderListBody this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb639f4: mov             x5, x1
    //     0xb639f8: mov             x4, x2
    //     0xb639fc: stur            x1, [fp, #-8]
    //     0xb63a00: stur            x2, [fp, #-0x10]
    //     0xb63a04: stur            x3, [fp, #-0x18]
    // 0xb63a08: CheckStackOverflow
    //     0xb63a08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb63a0c: cmp             SP, x16
    //     0xb63a10: b.ls            #0xb63e3c
    // 0xb63a14: mov             x0, x4
    // 0xb63a18: r2 = Null
    //     0xb63a18: mov             x2, NULL
    // 0xb63a1c: r1 = Null
    //     0xb63a1c: mov             x1, NULL
    // 0xb63a20: r4 = 60
    //     0xb63a20: mov             x4, #0x3c
    // 0xb63a24: branchIfSmi(r0, 0xb63a30)
    //     0xb63a24: tbz             w0, #0, #0xb63a30
    // 0xb63a28: r4 = LoadClassIdInstr(r0)
    //     0xb63a28: ldur            x4, [x0, #-1]
    //     0xb63a2c: ubfx            x4, x4, #0xc, #0x14
    // 0xb63a30: sub             x4, x4, #0xb46
    // 0xb63a34: cmp             x4, #1
    // 0xb63a38: b.ls            #0xb63a4c
    // 0xb63a3c: r8 = BoxConstraints
    //     0xb63a3c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb63a40: r3 = Null
    //     0xb63a40: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd34d8] Null
    //     0xb63a44: ldr             x3, [x3, #0x4d8]
    // 0xb63a48: r0 = BoxConstraints()
    //     0xb63a48: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb63a4c: ldur            x2, [fp, #-8]
    // 0xb63a50: LoadField: r0 = r2->field_5f
    //     0xb63a50: ldur            w0, [x2, #0x5f]
    // 0xb63a54: DecompressPointer r0
    //     0xb63a54: add             x0, x0, HEAP, lsl #32
    // 0xb63a58: LoadField: r1 = r0->field_7
    //     0xb63a58: ldur            x1, [x0, #7]
    // 0xb63a5c: cmp             x1, #1
    // 0xb63a60: b.gt            #0xb63a9c
    // 0xb63a64: cmp             x1, #0
    // 0xb63a68: b.gt            #0xb63a90
    // 0xb63a6c: LoadField: r0 = r2->field_5b
    //     0xb63a6c: ldur            w0, [x2, #0x5b]
    // 0xb63a70: DecompressPointer r0
    //     0xb63a70: add             x0, x0, HEAP, lsl #32
    // 0xb63a74: stur            x0, [fp, #-0x20]
    // 0xb63a78: r1 = Function 'childBefore':.
    //     0xb63a78: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd34e8] AnonymousClosure: (0xb63e78), of [dart:mixin_deduplication] _MixinApplication80&RenderBox&ContainerRenderObjectMixin
    //     0xb63a7c: ldr             x1, [x1, #0x4e8]
    // 0xb63a80: r0 = AllocateClosure()
    //     0xb63a80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb63a84: ldur            x2, [fp, #-0x20]
    // 0xb63a88: mov             x1, x0
    // 0xb63a8c: b               #0xb63ac4
    // 0xb63a90: ldur            x0, [fp, #-0x10]
    // 0xb63a94: d0 = inf
    //     0xb63a94: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb63a98: b               #0xb63c48
    // 0xb63a9c: cmp             x1, #2
    // 0xb63aa0: b.gt            #0xb63c40
    // 0xb63aa4: LoadField: r0 = r2->field_57
    //     0xb63aa4: ldur            w0, [x2, #0x57]
    // 0xb63aa8: DecompressPointer r0
    //     0xb63aa8: add             x0, x0, HEAP, lsl #32
    // 0xb63aac: stur            x0, [fp, #-0x20]
    // 0xb63ab0: r1 = Function 'childAfter':.
    //     0xb63ab0: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd34f0] AnonymousClosure: (0xb51554), of [dart:mixin_deduplication] _MixinApplication80&RenderBox&ContainerRenderObjectMixin
    //     0xb63ab4: ldr             x1, [x1, #0x4f0]
    // 0xb63ab8: r0 = AllocateClosure()
    //     0xb63ab8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb63abc: ldur            x2, [fp, #-0x20]
    // 0xb63ac0: mov             x1, x0
    // 0xb63ac4: ldur            x0, [fp, #-0x10]
    // 0xb63ac8: stur            x2, [fp, #-0x20]
    // 0xb63acc: stur            x1, [fp, #-0x28]
    // 0xb63ad0: LoadField: d0 = r0->field_f
    //     0xb63ad0: ldur            d0, [x0, #0xf]
    // 0xb63ad4: stur            d0, [fp, #-0x40]
    // 0xb63ad8: r0 = BoxConstraints()
    //     0xb63ad8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb63adc: ldur            d0, [fp, #-0x40]
    // 0xb63ae0: stur            x0, [fp, #-0x30]
    // 0xb63ae4: StoreField: r0->field_7 = d0
    //     0xb63ae4: stur            d0, [x0, #7]
    // 0xb63ae8: StoreField: r0->field_f = d0
    //     0xb63ae8: stur            d0, [x0, #0xf]
    // 0xb63aec: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb63aec: stur            xzr, [x0, #0x17]
    // 0xb63af0: d0 = inf
    //     0xb63af0: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb63af4: StoreField: r0->field_1f = d0
    //     0xb63af4: stur            d0, [x0, #0x1f]
    // 0xb63af8: ldur            x1, [fp, #-0x20]
    // 0xb63afc: d0 = 0.000000
    //     0xb63afc: eor             v0.16b, v0.16b, v0.16b
    // 0xb63b00: stur            x1, [fp, #-0x20]
    // 0xb63b04: stur            d0, [fp, #-0x40]
    // 0xb63b08: CheckStackOverflow
    //     0xb63b08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb63b0c: cmp             SP, x16
    //     0xb63b10: b.ls            #0xb63e44
    // 0xb63b14: cmp             w1, NULL
    // 0xb63b18: b.eq            #0xb63c30
    // 0xb63b1c: mov             x2, x0
    // 0xb63b20: ldur            x3, [fp, #-0x18]
    // 0xb63b24: r0 = AllocateRecord2()
    //     0xb63b24: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb63b28: ldur            x2, [fp, #-0x20]
    // 0xb63b2c: r1 = Function '_computeDryBaseline@29392247':.
    //     0xb63b2c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90868] AnonymousClosure: (0xb196f0), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryBaseline (0xb1972c)
    //     0xb63b30: ldr             x1, [x1, #0x868]
    // 0xb63b34: stur            x0, [fp, #-0x38]
    // 0xb63b38: r0 = AllocateClosure()
    //     0xb63b38: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb63b3c: r16 = <(BoxConstraints, TextBaseline), double?>
    //     0xb63b3c: add             x16, PP, #0x90, lsl #12  ; [pp+0x907f8] TypeArguments: <(BoxConstraints, TextBaseline), double?>
    //     0xb63b40: ldr             x16, [x16, #0x7f8]
    // 0xb63b44: ldur            lr, [fp, #-0x20]
    // 0xb63b48: stp             lr, x16, [SP, #0x18]
    // 0xb63b4c: r16 = Instance__Baseline
    //     0xb63b4c: add             x16, PP, #0x90, lsl #12  ; [pp+0x90800] Obj!_Baseline@129c181
    //     0xb63b50: ldr             x16, [x16, #0x800]
    // 0xb63b54: ldur            lr, [fp, #-0x38]
    // 0xb63b58: stp             lr, x16, [SP, #8]
    // 0xb63b5c: str             x0, [SP]
    // 0xb63b60: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb63b60: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb63b64: r0 = _computeIntrinsics()
    //     0xb63b64: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb63b68: cmp             w0, NULL
    // 0xb63b6c: b.ne            #0xb63bec
    // 0xb63b70: ldur            d0, [fp, #-0x40]
    // 0xb63b74: ldur            x2, [fp, #-0x20]
    // 0xb63b78: r1 = Function '_computeDryLayout@29392247':.
    //     0xb63b78: add             x1, PP, #0x27, lsl #12  ; [pp+0x27010] AnonymousClosure: (0xb20488), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout (0xb204c4)
    //     0xb63b7c: ldr             x1, [x1, #0x10]
    // 0xb63b80: r0 = AllocateClosure()
    //     0xb63b80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb63b84: r16 = <BoxConstraints, Size>
    //     0xb63b84: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0xb63b88: ldr             x16, [x16, #0x18]
    // 0xb63b8c: ldur            lr, [fp, #-0x20]
    // 0xb63b90: stp             lr, x16, [SP, #0x18]
    // 0xb63b94: r16 = Instance__DryLayout
    //     0xb63b94: add             x16, PP, #0x27, lsl #12  ; [pp+0x27020] Obj!_DryLayout@129c191
    //     0xb63b98: ldr             x16, [x16, #0x20]
    // 0xb63b9c: ldur            lr, [fp, #-0x30]
    // 0xb63ba0: stp             lr, x16, [SP, #8]
    // 0xb63ba4: str             x0, [SP]
    // 0xb63ba8: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb63ba8: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb63bac: r0 = _computeIntrinsics()
    //     0xb63bac: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb63bb0: LoadField: d0 = r0->field_f
    //     0xb63bb0: ldur            d0, [x0, #0xf]
    // 0xb63bb4: ldur            d1, [fp, #-0x40]
    // 0xb63bb8: fadd            d2, d1, d0
    // 0xb63bbc: stur            d2, [fp, #-0x48]
    // 0xb63bc0: ldur            x16, [fp, #-0x28]
    // 0xb63bc4: ldur            lr, [fp, #-0x20]
    // 0xb63bc8: stp             lr, x16, [SP]
    // 0xb63bcc: ldur            x0, [fp, #-0x28]
    // 0xb63bd0: ClosureCall
    //     0xb63bd0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb63bd4: ldur            x2, [x0, #0x1f]
    //     0xb63bd8: blr             x2
    // 0xb63bdc: mov             x1, x0
    // 0xb63be0: ldur            d0, [fp, #-0x48]
    // 0xb63be4: ldur            x0, [fp, #-0x30]
    // 0xb63be8: b               #0xb63b00
    // 0xb63bec: ldur            d1, [fp, #-0x40]
    // 0xb63bf0: LoadField: d0 = r0->field_7
    //     0xb63bf0: ldur            d0, [x0, #7]
    // 0xb63bf4: fadd            d2, d0, d1
    // 0xb63bf8: r0 = inline_Allocate_Double()
    //     0xb63bf8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb63bfc: add             x0, x0, #0x10
    //     0xb63c00: cmp             x1, x0
    //     0xb63c04: b.ls            #0xb63e4c
    //     0xb63c08: str             x0, [THR, #0x60]  ; THR::top
    //     0xb63c0c: sub             x0, x0, #0xf
    //     0xb63c10: mov             x1, #0xe19c
    //     0xb63c14: movk            x1, #3, lsl #16
    //     0xb63c18: stur            x1, [x0, #-1]
    // 0xb63c1c: dmb             ishst
    // 0xb63c20: StoreField: r0->field_7 = d2
    //     0xb63c20: stur            d2, [x0, #7]
    // 0xb63c24: LeaveFrame
    //     0xb63c24: mov             SP, fp
    //     0xb63c28: ldp             fp, lr, [SP], #0x10
    // 0xb63c2c: ret
    //     0xb63c2c: ret             
    // 0xb63c30: r0 = Null
    //     0xb63c30: mov             x0, NULL
    // 0xb63c34: LeaveFrame
    //     0xb63c34: mov             SP, fp
    //     0xb63c38: ldp             fp, lr, [SP], #0x10
    // 0xb63c3c: ret
    //     0xb63c3c: ret             
    // 0xb63c40: ldur            x0, [fp, #-0x10]
    // 0xb63c44: d0 = inf
    //     0xb63c44: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb63c48: LoadField: d1 = r0->field_1f
    //     0xb63c48: ldur            d1, [x0, #0x1f]
    // 0xb63c4c: stur            d1, [fp, #-0x40]
    // 0xb63c50: r0 = BoxConstraints()
    //     0xb63c50: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb63c54: stur            x0, [fp, #-0x20]
    // 0xb63c58: StoreField: r0->field_7 = rZR
    //     0xb63c58: stur            xzr, [x0, #7]
    // 0xb63c5c: d0 = inf
    //     0xb63c5c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb63c60: StoreField: r0->field_f = d0
    //     0xb63c60: stur            d0, [x0, #0xf]
    // 0xb63c64: ldur            d0, [fp, #-0x40]
    // 0xb63c68: ArrayStore: r0[0] = d0  ; List_8
    //     0xb63c68: stur            d0, [x0, #0x17]
    // 0xb63c6c: StoreField: r0->field_1f = d0
    //     0xb63c6c: stur            d0, [x0, #0x1f]
    // 0xb63c70: ldur            x1, [fp, #-8]
    // 0xb63c74: LoadField: r2 = r1->field_57
    //     0xb63c74: ldur            w2, [x1, #0x57]
    // 0xb63c78: DecompressPointer r2
    //     0xb63c78: add             x2, x2, HEAP, lsl #32
    // 0xb63c7c: mov             x4, x2
    // 0xb63c80: r1 = Null
    //     0xb63c80: mov             x1, NULL
    // 0xb63c84: stur            x4, [fp, #-8]
    // 0xb63c88: stur            x1, [fp, #-0x10]
    // 0xb63c8c: CheckStackOverflow
    //     0xb63c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb63c90: cmp             SP, x16
    //     0xb63c94: b.ls            #0xb63e5c
    // 0xb63c98: cmp             w4, NULL
    // 0xb63c9c: b.eq            #0xb63e2c
    // 0xb63ca0: mov             x2, x0
    // 0xb63ca4: ldur            x3, [fp, #-0x18]
    // 0xb63ca8: r0 = AllocateRecord2()
    //     0xb63ca8: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb63cac: ldur            x2, [fp, #-8]
    // 0xb63cb0: r1 = Function '_computeDryBaseline@29392247':.
    //     0xb63cb0: add             x1, PP, #0x90, lsl #12  ; [pp+0x90868] AnonymousClosure: (0xb196f0), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryBaseline (0xb1972c)
    //     0xb63cb4: ldr             x1, [x1, #0x868]
    // 0xb63cb8: stur            x0, [fp, #-0x28]
    // 0xb63cbc: r0 = AllocateClosure()
    //     0xb63cbc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb63cc0: r16 = <(BoxConstraints, TextBaseline), double?>
    //     0xb63cc0: add             x16, PP, #0x90, lsl #12  ; [pp+0x907f8] TypeArguments: <(BoxConstraints, TextBaseline), double?>
    //     0xb63cc4: ldr             x16, [x16, #0x7f8]
    // 0xb63cc8: ldur            lr, [fp, #-8]
    // 0xb63ccc: stp             lr, x16, [SP, #0x18]
    // 0xb63cd0: r16 = Instance__Baseline
    //     0xb63cd0: add             x16, PP, #0x90, lsl #12  ; [pp+0x90800] Obj!_Baseline@129c181
    //     0xb63cd4: ldr             x16, [x16, #0x800]
    // 0xb63cd8: ldur            lr, [fp, #-0x28]
    // 0xb63cdc: stp             lr, x16, [SP, #8]
    // 0xb63ce0: str             x0, [SP]
    // 0xb63ce4: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb63ce4: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb63ce8: r0 = _computeIntrinsics()
    //     0xb63ce8: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb63cec: mov             x1, x0
    // 0xb63cf0: ldur            x0, [fp, #-0x10]
    // 0xb63cf4: cmp             w0, NULL
    // 0xb63cf8: b.eq            #0xb63d5c
    // 0xb63cfc: cmp             w1, NULL
    // 0xb63d00: b.eq            #0xb63d54
    // 0xb63d04: LoadField: d0 = r0->field_7
    //     0xb63d04: ldur            d0, [x0, #7]
    // 0xb63d08: LoadField: d1 = r1->field_7
    //     0xb63d08: ldur            d1, [x1, #7]
    // 0xb63d0c: fcmp            d0, d1
    // 0xb63d10: b.lt            #0xb63d1c
    // 0xb63d14: LoadField: d0 = r1->field_7
    //     0xb63d14: ldur            d0, [x1, #7]
    // 0xb63d18: b               #0xb63d20
    // 0xb63d1c: LoadField: d0 = r0->field_7
    //     0xb63d1c: ldur            d0, [x0, #7]
    // 0xb63d20: r0 = inline_Allocate_Double()
    //     0xb63d20: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb63d24: add             x0, x0, #0x10
    //     0xb63d28: cmp             x1, x0
    //     0xb63d2c: b.ls            #0xb63e64
    //     0xb63d30: str             x0, [THR, #0x60]  ; THR::top
    //     0xb63d34: sub             x0, x0, #0xf
    //     0xb63d38: mov             x1, #0xe19c
    //     0xb63d3c: movk            x1, #3, lsl #16
    //     0xb63d40: stur            x1, [x0, #-1]
    // 0xb63d44: dmb             ishst
    // 0xb63d48: StoreField: r0->field_7 = d0
    //     0xb63d48: stur            d0, [x0, #7]
    // 0xb63d4c: mov             x3, x0
    // 0xb63d50: b               #0xb63dc4
    // 0xb63d54: r2 = true
    //     0xb63d54: add             x2, NULL, #0x20  ; true
    // 0xb63d58: b               #0xb63d60
    // 0xb63d5c: r2 = false
    //     0xb63d5c: add             x2, NULL, #0x30  ; false
    // 0xb63d60: cmp             w0, NULL
    // 0xb63d64: b.eq            #0xb63d9c
    // 0xb63d68: tbnz            w2, #4, #0xb63d78
    // 0xb63d6c: r3 = Null
    //     0xb63d6c: mov             x3, NULL
    // 0xb63d70: r2 = Null
    //     0xb63d70: mov             x2, NULL
    // 0xb63d74: b               #0xb63d80
    // 0xb63d78: mov             x3, x1
    // 0xb63d7c: mov             x2, x1
    // 0xb63d80: cmp             w3, NULL
    // 0xb63d84: b.ne            #0xb63d90
    // 0xb63d88: mov             x3, x0
    // 0xb63d8c: b               #0xb63dc4
    // 0xb63d90: mov             x3, x2
    // 0xb63d94: r2 = true
    //     0xb63d94: add             x2, NULL, #0x20  ; true
    // 0xb63d98: b               #0xb63da0
    // 0xb63d9c: r3 = Null
    //     0xb63d9c: mov             x3, NULL
    // 0xb63da0: cmp             w0, NULL
    // 0xb63da4: b.ne            #0xb63dc0
    // 0xb63da8: tbnz            w2, #4, #0xb63db4
    // 0xb63dac: mov             x0, x3
    // 0xb63db0: b               #0xb63db8
    // 0xb63db4: mov             x0, x1
    // 0xb63db8: mov             x3, x0
    // 0xb63dbc: b               #0xb63dc4
    // 0xb63dc0: r3 = Null
    //     0xb63dc0: mov             x3, NULL
    // 0xb63dc4: ldur            x0, [fp, #-8]
    // 0xb63dc8: stur            x3, [fp, #-0x30]
    // 0xb63dcc: LoadField: r4 = r0->field_7
    //     0xb63dcc: ldur            w4, [x0, #7]
    // 0xb63dd0: DecompressPointer r4
    //     0xb63dd0: add             x4, x4, HEAP, lsl #32
    // 0xb63dd4: stur            x4, [fp, #-0x28]
    // 0xb63dd8: cmp             w4, NULL
    // 0xb63ddc: b.eq            #0xb63e74
    // 0xb63de0: mov             x0, x4
    // 0xb63de4: r2 = Null
    //     0xb63de4: mov             x2, NULL
    // 0xb63de8: r1 = Null
    //     0xb63de8: mov             x1, NULL
    // 0xb63dec: r4 = LoadClassIdInstr(r0)
    //     0xb63dec: ldur            x4, [x0, #-1]
    //     0xb63df0: ubfx            x4, x4, #0xc, #0x14
    // 0xb63df4: r17 = 4211
    //     0xb63df4: mov             x17, #0x1073
    // 0xb63df8: cmp             x4, x17
    // 0xb63dfc: b.eq            #0xb63e14
    // 0xb63e00: r8 = ListBodyParentData
    //     0xb63e00: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xb63e04: ldr             x8, [x8, #0x3b0]
    // 0xb63e08: r3 = Null
    //     0xb63e08: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd34f8] Null
    //     0xb63e0c: ldr             x3, [x3, #0x4f8]
    // 0xb63e10: r0 = DefaultTypeTest()
    //     0xb63e10: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb63e14: ldur            x1, [fp, #-0x28]
    // 0xb63e18: LoadField: r4 = r1->field_13
    //     0xb63e18: ldur            w4, [x1, #0x13]
    // 0xb63e1c: DecompressPointer r4
    //     0xb63e1c: add             x4, x4, HEAP, lsl #32
    // 0xb63e20: ldur            x1, [fp, #-0x30]
    // 0xb63e24: ldur            x0, [fp, #-0x20]
    // 0xb63e28: b               #0xb63c84
    // 0xb63e2c: mov             x0, x1
    // 0xb63e30: LeaveFrame
    //     0xb63e30: mov             SP, fp
    //     0xb63e34: ldp             fp, lr, [SP], #0x10
    // 0xb63e38: ret
    //     0xb63e38: ret             
    // 0xb63e3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb63e3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb63e40: b               #0xb63a14
    // 0xb63e44: r0 = StackOverflowSharedWithFPURegs()
    //     0xb63e44: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb63e48: b               #0xb63b14
    // 0xb63e4c: SaveReg d2
    //     0xb63e4c: str             q2, [SP, #-0x10]!
    // 0xb63e50: r0 = AllocateDouble()
    //     0xb63e50: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb63e54: RestoreReg d2
    //     0xb63e54: ldr             q2, [SP], #0x10
    // 0xb63e58: b               #0xb63c20
    // 0xb63e5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb63e5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb63e60: b               #0xb63c98
    // 0xb63e64: SaveReg d0
    //     0xb63e64: str             q0, [SP, #-0x10]!
    // 0xb63e68: r0 = AllocateDouble()
    //     0xb63e68: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb63e6c: RestoreReg d0
    //     0xb63e6c: ldr             q0, [SP], #0x10
    // 0xb63e70: b               #0xb63d48
    // 0xb63e74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb63e74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbc2864, size: 0xd0c
    // 0xbc2864: EnterFrame
    //     0xbc2864: stp             fp, lr, [SP, #-0x10]!
    //     0xbc2868: mov             fp, SP
    // 0xbc286c: AllocStack(0x70)
    //     0xbc286c: sub             SP, SP, #0x70
    // 0xbc2870: SetupParameters(RenderListBody this /* r1 => r3, fp-0x10 */)
    //     0xbc2870: mov             x3, x1
    //     0xbc2874: stur            x1, [fp, #-0x10]
    // 0xbc2878: CheckStackOverflow
    //     0xbc2878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc287c: cmp             SP, x16
    //     0xbc2880: b.ls            #0xbc3520
    // 0xbc2884: LoadField: r4 = r3->field_27
    //     0xbc2884: ldur            w4, [x3, #0x27]
    // 0xbc2888: DecompressPointer r4
    //     0xbc2888: add             x4, x4, HEAP, lsl #32
    // 0xbc288c: stur            x4, [fp, #-8]
    // 0xbc2890: cmp             w4, NULL
    // 0xbc2894: b.eq            #0xbc30cc
    // 0xbc2898: mov             x0, x4
    // 0xbc289c: r2 = Null
    //     0xbc289c: mov             x2, NULL
    // 0xbc28a0: r1 = Null
    //     0xbc28a0: mov             x1, NULL
    // 0xbc28a4: r4 = LoadClassIdInstr(r0)
    //     0xbc28a4: ldur            x4, [x0, #-1]
    //     0xbc28a8: ubfx            x4, x4, #0xc, #0x14
    // 0xbc28ac: sub             x4, x4, #0xb46
    // 0xbc28b0: cmp             x4, #1
    // 0xbc28b4: b.ls            #0xbc28c8
    // 0xbc28b8: r8 = BoxConstraints
    //     0xbc28b8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc28bc: r3 = Null
    //     0xbc28bc: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3448] Null
    //     0xbc28c0: ldr             x3, [x3, #0x448]
    // 0xbc28c4: r0 = BoxConstraints()
    //     0xbc28c4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc28c8: ldur            x0, [fp, #-0x10]
    // 0xbc28cc: LoadField: r1 = r0->field_57
    //     0xbc28cc: ldur            w1, [x0, #0x57]
    // 0xbc28d0: DecompressPointer r1
    //     0xbc28d0: add             x1, x1, HEAP, lsl #32
    // 0xbc28d4: stur            x1, [fp, #-0x18]
    // 0xbc28d8: LoadField: r2 = r0->field_5f
    //     0xbc28d8: ldur            w2, [x0, #0x5f]
    // 0xbc28dc: DecompressPointer r2
    //     0xbc28dc: add             x2, x2, HEAP, lsl #32
    // 0xbc28e0: LoadField: r3 = r2->field_7
    //     0xbc28e0: ldur            x3, [x2, #7]
    // 0xbc28e4: cmp             x3, #1
    // 0xbc28e8: b.gt            #0xbc2cd4
    // 0xbc28ec: cmp             x3, #0
    // 0xbc28f0: b.gt            #0xbc2b44
    // 0xbc28f4: ldur            x2, [fp, #-8]
    // 0xbc28f8: LoadField: d0 = r2->field_f
    //     0xbc28f8: ldur            d0, [x2, #0xf]
    // 0xbc28fc: stur            d0, [fp, #-0x50]
    // 0xbc2900: r0 = BoxConstraints()
    //     0xbc2900: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc2904: mov             x3, x0
    // 0xbc2908: ldur            d0, [fp, #-0x50]
    // 0xbc290c: stur            x3, [fp, #-0x28]
    // 0xbc2910: StoreField: r3->field_7 = d0
    //     0xbc2910: stur            d0, [x3, #7]
    // 0xbc2914: StoreField: r3->field_f = d0
    //     0xbc2914: stur            d0, [x3, #0xf]
    // 0xbc2918: ArrayStore: r3[0] = rZR  ; List_8
    //     0xbc2918: stur            xzr, [x3, #0x17]
    // 0xbc291c: d1 = inf
    //     0xbc291c: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbc2920: StoreField: r3->field_1f = d1
    //     0xbc2920: stur            d1, [x3, #0x1f]
    // 0xbc2924: ldur            x4, [fp, #-0x18]
    // 0xbc2928: d1 = 0.000000
    //     0xbc2928: eor             v1.16b, v1.16b, v1.16b
    // 0xbc292c: stur            x4, [fp, #-0x20]
    // 0xbc2930: stur            d1, [fp, #-0x58]
    // 0xbc2934: CheckStackOverflow
    //     0xbc2934: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc2938: cmp             SP, x16
    //     0xbc293c: b.ls            #0xbc3528
    // 0xbc2940: cmp             w4, NULL
    // 0xbc2944: b.eq            #0xbc2a00
    // 0xbc2948: r0 = LoadClassIdInstr(r4)
    //     0xbc2948: ldur            x0, [x4, #-1]
    //     0xbc294c: ubfx            x0, x0, #0xc, #0x14
    // 0xbc2950: r16 = true
    //     0xbc2950: add             x16, NULL, #0x20  ; true
    // 0xbc2954: str             x16, [SP]
    // 0xbc2958: mov             x1, x4
    // 0xbc295c: mov             x2, x3
    // 0xbc2960: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc2960: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc2964: ldr             x4, [x4, #0xed0]
    // 0xbc2968: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc2968: mov             x17, #0xe6b9
    //     0xbc296c: add             lr, x0, x17
    //     0xbc2970: ldr             lr, [x21, lr, lsl #3]
    //     0xbc2974: blr             lr
    // 0xbc2978: ldur            x3, [fp, #-0x20]
    // 0xbc297c: LoadField: r4 = r3->field_7
    //     0xbc297c: ldur            w4, [x3, #7]
    // 0xbc2980: DecompressPointer r4
    //     0xbc2980: add             x4, x4, HEAP, lsl #32
    // 0xbc2984: stur            x4, [fp, #-0x30]
    // 0xbc2988: cmp             w4, NULL
    // 0xbc298c: b.eq            #0xbc3530
    // 0xbc2990: mov             x0, x4
    // 0xbc2994: r2 = Null
    //     0xbc2994: mov             x2, NULL
    // 0xbc2998: r1 = Null
    //     0xbc2998: mov             x1, NULL
    // 0xbc299c: r4 = LoadClassIdInstr(r0)
    //     0xbc299c: ldur            x4, [x0, #-1]
    //     0xbc29a0: ubfx            x4, x4, #0xc, #0x14
    // 0xbc29a4: r17 = 4211
    //     0xbc29a4: mov             x17, #0x1073
    // 0xbc29a8: cmp             x4, x17
    // 0xbc29ac: b.eq            #0xbc29c4
    // 0xbc29b0: r8 = ListBodyParentData
    //     0xbc29b0: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xbc29b4: ldr             x8, [x8, #0x3b0]
    // 0xbc29b8: r3 = Null
    //     0xbc29b8: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3458] Null
    //     0xbc29bc: ldr             x3, [x3, #0x458]
    // 0xbc29c0: r0 = DefaultTypeTest()
    //     0xbc29c0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc29c4: ldur            x0, [fp, #-0x20]
    // 0xbc29c8: LoadField: r1 = r0->field_4b
    //     0xbc29c8: ldur            w1, [x0, #0x4b]
    // 0xbc29cc: DecompressPointer r1
    //     0xbc29cc: add             x1, x1, HEAP, lsl #32
    // 0xbc29d0: cmp             w1, NULL
    // 0xbc29d4: b.eq            #0xbc30e8
    // 0xbc29d8: ldur            d0, [fp, #-0x58]
    // 0xbc29dc: ldur            x0, [fp, #-0x30]
    // 0xbc29e0: LoadField: d1 = r1->field_f
    //     0xbc29e0: ldur            d1, [x1, #0xf]
    // 0xbc29e4: fadd            d2, d0, d1
    // 0xbc29e8: LoadField: r4 = r0->field_13
    //     0xbc29e8: ldur            w4, [x0, #0x13]
    // 0xbc29ec: DecompressPointer r4
    //     0xbc29ec: add             x4, x4, HEAP, lsl #32
    // 0xbc29f0: mov             v1.16b, v2.16b
    // 0xbc29f4: ldur            x3, [fp, #-0x28]
    // 0xbc29f8: ldur            d0, [fp, #-0x50]
    // 0xbc29fc: b               #0xbc292c
    // 0xbc2a00: ldur            x3, [fp, #-0x10]
    // 0xbc2a04: mov             v0.16b, v1.16b
    // 0xbc2a08: LoadField: r0 = r3->field_57
    //     0xbc2a08: ldur            w0, [x3, #0x57]
    // 0xbc2a0c: DecompressPointer r0
    //     0xbc2a0c: add             x0, x0, HEAP, lsl #32
    // 0xbc2a10: mov             x4, x0
    // 0xbc2a14: d1 = 0.000000
    //     0xbc2a14: eor             v1.16b, v1.16b, v1.16b
    // 0xbc2a18: stur            x4, [fp, #-0x30]
    // 0xbc2a1c: stur            d1, [fp, #-0x60]
    // 0xbc2a20: CheckStackOverflow
    //     0xbc2a20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc2a24: cmp             SP, x16
    //     0xbc2a28: b.ls            #0xbc3534
    // 0xbc2a2c: cmp             w4, NULL
    // 0xbc2a30: b.eq            #0xbc2af8
    // 0xbc2a34: LoadField: r5 = r4->field_7
    //     0xbc2a34: ldur            w5, [x4, #7]
    // 0xbc2a38: DecompressPointer r5
    //     0xbc2a38: add             x5, x5, HEAP, lsl #32
    // 0xbc2a3c: stur            x5, [fp, #-0x28]
    // 0xbc2a40: cmp             w5, NULL
    // 0xbc2a44: b.eq            #0xbc353c
    // 0xbc2a48: mov             x0, x5
    // 0xbc2a4c: r2 = Null
    //     0xbc2a4c: mov             x2, NULL
    // 0xbc2a50: r1 = Null
    //     0xbc2a50: mov             x1, NULL
    // 0xbc2a54: r4 = LoadClassIdInstr(r0)
    //     0xbc2a54: ldur            x4, [x0, #-1]
    //     0xbc2a58: ubfx            x4, x4, #0xc, #0x14
    // 0xbc2a5c: r17 = 4211
    //     0xbc2a5c: mov             x17, #0x1073
    // 0xbc2a60: cmp             x4, x17
    // 0xbc2a64: b.eq            #0xbc2a7c
    // 0xbc2a68: r8 = ListBodyParentData
    //     0xbc2a68: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xbc2a6c: ldr             x8, [x8, #0x3b0]
    // 0xbc2a70: r3 = Null
    //     0xbc2a70: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3468] Null
    //     0xbc2a74: ldr             x3, [x3, #0x468]
    // 0xbc2a78: r0 = DefaultTypeTest()
    //     0xbc2a78: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc2a7c: ldur            x0, [fp, #-0x30]
    // 0xbc2a80: LoadField: r1 = r0->field_4b
    //     0xbc2a80: ldur            w1, [x0, #0x4b]
    // 0xbc2a84: DecompressPointer r1
    //     0xbc2a84: add             x1, x1, HEAP, lsl #32
    // 0xbc2a88: cmp             w1, NULL
    // 0xbc2a8c: b.eq            #0xbc319c
    // 0xbc2a90: ldur            d0, [fp, #-0x58]
    // 0xbc2a94: ldur            d1, [fp, #-0x60]
    // 0xbc2a98: ldur            x0, [fp, #-0x28]
    // 0xbc2a9c: LoadField: d2 = r1->field_f
    //     0xbc2a9c: ldur            d2, [x1, #0xf]
    // 0xbc2aa0: fadd            d3, d1, d2
    // 0xbc2aa4: stur            d3, [fp, #-0x68]
    // 0xbc2aa8: fsub            d1, d0, d3
    // 0xbc2aac: stur            d1, [fp, #-0x60]
    // 0xbc2ab0: r0 = Offset()
    //     0xbc2ab0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc2ab4: StoreField: r0->field_7 = rZR
    //     0xbc2ab4: stur            xzr, [x0, #7]
    // 0xbc2ab8: ldur            d0, [fp, #-0x60]
    // 0xbc2abc: StoreField: r0->field_f = d0
    //     0xbc2abc: stur            d0, [x0, #0xf]
    // 0xbc2ac0: ldur            x1, [fp, #-0x28]
    // 0xbc2ac4: StoreField: r1->field_7 = r0
    //     0xbc2ac4: stur            w0, [x1, #7]
    //     0xbc2ac8: ldurb           w16, [x1, #-1]
    //     0xbc2acc: ldurb           w17, [x0, #-1]
    //     0xbc2ad0: and             x16, x17, x16, lsr #2
    //     0xbc2ad4: tst             x16, HEAP, lsr #32
    //     0xbc2ad8: b.eq            #0xbc2ae0
    //     0xbc2adc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc2ae0: LoadField: r4 = r1->field_13
    //     0xbc2ae0: ldur            w4, [x1, #0x13]
    // 0xbc2ae4: DecompressPointer r4
    //     0xbc2ae4: add             x4, x4, HEAP, lsl #32
    // 0xbc2ae8: ldur            d1, [fp, #-0x68]
    // 0xbc2aec: ldur            x3, [fp, #-0x10]
    // 0xbc2af0: ldur            d0, [fp, #-0x58]
    // 0xbc2af4: b               #0xbc2a18
    // 0xbc2af8: mov             x0, x3
    // 0xbc2afc: ldur            d1, [fp, #-0x50]
    // 0xbc2b00: r0 = Size()
    //     0xbc2b00: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc2b04: ldur            d0, [fp, #-0x50]
    // 0xbc2b08: StoreField: r0->field_7 = d0
    //     0xbc2b08: stur            d0, [x0, #7]
    // 0xbc2b0c: ldur            d0, [fp, #-0x58]
    // 0xbc2b10: StoreField: r0->field_f = d0
    //     0xbc2b10: stur            d0, [x0, #0xf]
    // 0xbc2b14: ldur            x1, [fp, #-8]
    // 0xbc2b18: mov             x2, x0
    // 0xbc2b1c: r0 = constrain()
    //     0xbc2b1c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbc2b20: ldur            x1, [fp, #-0x10]
    // 0xbc2b24: StoreField: r1->field_4b = r0
    //     0xbc2b24: stur            w0, [x1, #0x4b]
    //     0xbc2b28: ldurb           w16, [x1, #-1]
    //     0xbc2b2c: ldurb           w17, [x0, #-1]
    //     0xbc2b30: and             x16, x17, x16, lsr #2
    //     0xbc2b34: tst             x16, HEAP, lsr #32
    //     0xbc2b38: b.eq            #0xbc2b40
    //     0xbc2b3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc2b40: b               #0xbc30bc
    // 0xbc2b44: mov             x1, x0
    // 0xbc2b48: ldur            x0, [fp, #-8]
    // 0xbc2b4c: d1 = inf
    //     0xbc2b4c: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbc2b50: LoadField: d0 = r0->field_1f
    //     0xbc2b50: ldur            d0, [x0, #0x1f]
    // 0xbc2b54: stur            d0, [fp, #-0x50]
    // 0xbc2b58: r0 = BoxConstraints()
    //     0xbc2b58: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc2b5c: mov             x3, x0
    // 0xbc2b60: stur            x3, [fp, #-0x38]
    // 0xbc2b64: StoreField: r3->field_7 = rZR
    //     0xbc2b64: stur            xzr, [x3, #7]
    // 0xbc2b68: d0 = inf
    //     0xbc2b68: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbc2b6c: StoreField: r3->field_f = d0
    //     0xbc2b6c: stur            d0, [x3, #0xf]
    // 0xbc2b70: ldur            d0, [fp, #-0x50]
    // 0xbc2b74: ArrayStore: r3[0] = d0  ; List_8
    //     0xbc2b74: stur            d0, [x3, #0x17]
    // 0xbc2b78: StoreField: r3->field_1f = d0
    //     0xbc2b78: stur            d0, [x3, #0x1f]
    // 0xbc2b7c: ldur            x4, [fp, #-0x18]
    // 0xbc2b80: d1 = 0.000000
    //     0xbc2b80: eor             v1.16b, v1.16b, v1.16b
    // 0xbc2b84: stur            x4, [fp, #-0x28]
    // 0xbc2b88: stur            d1, [fp, #-0x58]
    // 0xbc2b8c: CheckStackOverflow
    //     0xbc2b8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc2b90: cmp             SP, x16
    //     0xbc2b94: b.ls            #0xbc3540
    // 0xbc2b98: cmp             w4, NULL
    // 0xbc2b9c: b.eq            #0xbc2c80
    // 0xbc2ba0: r0 = LoadClassIdInstr(r4)
    //     0xbc2ba0: ldur            x0, [x4, #-1]
    //     0xbc2ba4: ubfx            x0, x0, #0xc, #0x14
    // 0xbc2ba8: r16 = true
    //     0xbc2ba8: add             x16, NULL, #0x20  ; true
    // 0xbc2bac: str             x16, [SP]
    // 0xbc2bb0: mov             x1, x4
    // 0xbc2bb4: mov             x2, x3
    // 0xbc2bb8: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc2bb8: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc2bbc: ldr             x4, [x4, #0xed0]
    // 0xbc2bc0: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc2bc0: mov             x17, #0xe6b9
    //     0xbc2bc4: add             lr, x0, x17
    //     0xbc2bc8: ldr             lr, [x21, lr, lsl #3]
    //     0xbc2bcc: blr             lr
    // 0xbc2bd0: ldur            x3, [fp, #-0x28]
    // 0xbc2bd4: LoadField: r4 = r3->field_7
    //     0xbc2bd4: ldur            w4, [x3, #7]
    // 0xbc2bd8: DecompressPointer r4
    //     0xbc2bd8: add             x4, x4, HEAP, lsl #32
    // 0xbc2bdc: stur            x4, [fp, #-0x40]
    // 0xbc2be0: cmp             w4, NULL
    // 0xbc2be4: b.eq            #0xbc3548
    // 0xbc2be8: mov             x0, x4
    // 0xbc2bec: r2 = Null
    //     0xbc2bec: mov             x2, NULL
    // 0xbc2bf0: r1 = Null
    //     0xbc2bf0: mov             x1, NULL
    // 0xbc2bf4: r4 = LoadClassIdInstr(r0)
    //     0xbc2bf4: ldur            x4, [x0, #-1]
    //     0xbc2bf8: ubfx            x4, x4, #0xc, #0x14
    // 0xbc2bfc: r17 = 4211
    //     0xbc2bfc: mov             x17, #0x1073
    // 0xbc2c00: cmp             x4, x17
    // 0xbc2c04: b.eq            #0xbc2c1c
    // 0xbc2c08: r8 = ListBodyParentData
    //     0xbc2c08: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xbc2c0c: ldr             x8, [x8, #0x3b0]
    // 0xbc2c10: r3 = Null
    //     0xbc2c10: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3478] Null
    //     0xbc2c14: ldr             x3, [x3, #0x478]
    // 0xbc2c18: r0 = DefaultTypeTest()
    //     0xbc2c18: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc2c1c: r0 = Offset()
    //     0xbc2c1c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc2c20: ldur            d0, [fp, #-0x58]
    // 0xbc2c24: StoreField: r0->field_7 = d0
    //     0xbc2c24: stur            d0, [x0, #7]
    // 0xbc2c28: StoreField: r0->field_f = rZR
    //     0xbc2c28: stur            xzr, [x0, #0xf]
    // 0xbc2c2c: ldur            x1, [fp, #-0x40]
    // 0xbc2c30: StoreField: r1->field_7 = r0
    //     0xbc2c30: stur            w0, [x1, #7]
    //     0xbc2c34: ldurb           w16, [x1, #-1]
    //     0xbc2c38: ldurb           w17, [x0, #-1]
    //     0xbc2c3c: and             x16, x17, x16, lsr #2
    //     0xbc2c40: tst             x16, HEAP, lsr #32
    //     0xbc2c44: b.eq            #0xbc2c4c
    //     0xbc2c48: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc2c4c: ldur            x0, [fp, #-0x28]
    // 0xbc2c50: LoadField: r2 = r0->field_4b
    //     0xbc2c50: ldur            w2, [x0, #0x4b]
    // 0xbc2c54: DecompressPointer r2
    //     0xbc2c54: add             x2, x2, HEAP, lsl #32
    // 0xbc2c58: cmp             w2, NULL
    // 0xbc2c5c: b.eq            #0xbc3250
    // 0xbc2c60: LoadField: d1 = r2->field_7
    //     0xbc2c60: ldur            d1, [x2, #7]
    // 0xbc2c64: fadd            d2, d0, d1
    // 0xbc2c68: LoadField: r4 = r1->field_13
    //     0xbc2c68: ldur            w4, [x1, #0x13]
    // 0xbc2c6c: DecompressPointer r4
    //     0xbc2c6c: add             x4, x4, HEAP, lsl #32
    // 0xbc2c70: mov             v1.16b, v2.16b
    // 0xbc2c74: ldur            x3, [fp, #-0x38]
    // 0xbc2c78: ldur            d0, [fp, #-0x50]
    // 0xbc2c7c: b               #0xbc2b84
    // 0xbc2c80: ldur            x0, [fp, #-0x10]
    // 0xbc2c84: mov             v31.16b, v1.16b
    // 0xbc2c88: mov             v1.16b, v0.16b
    // 0xbc2c8c: mov             v0.16b, v31.16b
    // 0xbc2c90: r0 = Size()
    //     0xbc2c90: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc2c94: ldur            d0, [fp, #-0x58]
    // 0xbc2c98: StoreField: r0->field_7 = d0
    //     0xbc2c98: stur            d0, [x0, #7]
    // 0xbc2c9c: ldur            d0, [fp, #-0x50]
    // 0xbc2ca0: StoreField: r0->field_f = d0
    //     0xbc2ca0: stur            d0, [x0, #0xf]
    // 0xbc2ca4: ldur            x1, [fp, #-8]
    // 0xbc2ca8: mov             x2, x0
    // 0xbc2cac: r0 = constrain()
    //     0xbc2cac: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbc2cb0: ldur            x1, [fp, #-0x10]
    // 0xbc2cb4: StoreField: r1->field_4b = r0
    //     0xbc2cb4: stur            w0, [x1, #0x4b]
    //     0xbc2cb8: ldurb           w16, [x1, #-1]
    //     0xbc2cbc: ldurb           w17, [x0, #-1]
    //     0xbc2cc0: and             x16, x17, x16, lsr #2
    //     0xbc2cc4: tst             x16, HEAP, lsr #32
    //     0xbc2cc8: b.eq            #0xbc2cd0
    //     0xbc2ccc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc2cd0: b               #0xbc30bc
    // 0xbc2cd4: mov             x1, x0
    // 0xbc2cd8: d0 = inf
    //     0xbc2cd8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbc2cdc: cmp             x3, #2
    // 0xbc2ce0: b.gt            #0xbc2e6c
    // 0xbc2ce4: ldur            x0, [fp, #-8]
    // 0xbc2ce8: LoadField: d1 = r0->field_f
    //     0xbc2ce8: ldur            d1, [x0, #0xf]
    // 0xbc2cec: stur            d1, [fp, #-0x50]
    // 0xbc2cf0: r0 = BoxConstraints()
    //     0xbc2cf0: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc2cf4: mov             x3, x0
    // 0xbc2cf8: ldur            d0, [fp, #-0x50]
    // 0xbc2cfc: stur            x3, [fp, #-0x40]
    // 0xbc2d00: StoreField: r3->field_7 = d0
    //     0xbc2d00: stur            d0, [x3, #7]
    // 0xbc2d04: StoreField: r3->field_f = d0
    //     0xbc2d04: stur            d0, [x3, #0xf]
    // 0xbc2d08: ArrayStore: r3[0] = rZR  ; List_8
    //     0xbc2d08: stur            xzr, [x3, #0x17]
    // 0xbc2d0c: d1 = inf
    //     0xbc2d0c: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbc2d10: StoreField: r3->field_1f = d1
    //     0xbc2d10: stur            d1, [x3, #0x1f]
    // 0xbc2d14: ldur            x4, [fp, #-0x18]
    // 0xbc2d18: d1 = 0.000000
    //     0xbc2d18: eor             v1.16b, v1.16b, v1.16b
    // 0xbc2d1c: stur            x4, [fp, #-0x38]
    // 0xbc2d20: stur            d1, [fp, #-0x58]
    // 0xbc2d24: CheckStackOverflow
    //     0xbc2d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc2d28: cmp             SP, x16
    //     0xbc2d2c: b.ls            #0xbc354c
    // 0xbc2d30: cmp             w4, NULL
    // 0xbc2d34: b.eq            #0xbc2e18
    // 0xbc2d38: r0 = LoadClassIdInstr(r4)
    //     0xbc2d38: ldur            x0, [x4, #-1]
    //     0xbc2d3c: ubfx            x0, x0, #0xc, #0x14
    // 0xbc2d40: r16 = true
    //     0xbc2d40: add             x16, NULL, #0x20  ; true
    // 0xbc2d44: str             x16, [SP]
    // 0xbc2d48: mov             x1, x4
    // 0xbc2d4c: mov             x2, x3
    // 0xbc2d50: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc2d50: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc2d54: ldr             x4, [x4, #0xed0]
    // 0xbc2d58: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc2d58: mov             x17, #0xe6b9
    //     0xbc2d5c: add             lr, x0, x17
    //     0xbc2d60: ldr             lr, [x21, lr, lsl #3]
    //     0xbc2d64: blr             lr
    // 0xbc2d68: ldur            x3, [fp, #-0x38]
    // 0xbc2d6c: LoadField: r4 = r3->field_7
    //     0xbc2d6c: ldur            w4, [x3, #7]
    // 0xbc2d70: DecompressPointer r4
    //     0xbc2d70: add             x4, x4, HEAP, lsl #32
    // 0xbc2d74: stur            x4, [fp, #-0x48]
    // 0xbc2d78: cmp             w4, NULL
    // 0xbc2d7c: b.eq            #0xbc3554
    // 0xbc2d80: mov             x0, x4
    // 0xbc2d84: r2 = Null
    //     0xbc2d84: mov             x2, NULL
    // 0xbc2d88: r1 = Null
    //     0xbc2d88: mov             x1, NULL
    // 0xbc2d8c: r4 = LoadClassIdInstr(r0)
    //     0xbc2d8c: ldur            x4, [x0, #-1]
    //     0xbc2d90: ubfx            x4, x4, #0xc, #0x14
    // 0xbc2d94: r17 = 4211
    //     0xbc2d94: mov             x17, #0x1073
    // 0xbc2d98: cmp             x4, x17
    // 0xbc2d9c: b.eq            #0xbc2db4
    // 0xbc2da0: r8 = ListBodyParentData
    //     0xbc2da0: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xbc2da4: ldr             x8, [x8, #0x3b0]
    // 0xbc2da8: r3 = Null
    //     0xbc2da8: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3488] Null
    //     0xbc2dac: ldr             x3, [x3, #0x488]
    // 0xbc2db0: r0 = DefaultTypeTest()
    //     0xbc2db0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc2db4: r0 = Offset()
    //     0xbc2db4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc2db8: StoreField: r0->field_7 = rZR
    //     0xbc2db8: stur            xzr, [x0, #7]
    // 0xbc2dbc: ldur            d0, [fp, #-0x58]
    // 0xbc2dc0: StoreField: r0->field_f = d0
    //     0xbc2dc0: stur            d0, [x0, #0xf]
    // 0xbc2dc4: ldur            x1, [fp, #-0x48]
    // 0xbc2dc8: StoreField: r1->field_7 = r0
    //     0xbc2dc8: stur            w0, [x1, #7]
    //     0xbc2dcc: ldurb           w16, [x1, #-1]
    //     0xbc2dd0: ldurb           w17, [x0, #-1]
    //     0xbc2dd4: and             x16, x17, x16, lsr #2
    //     0xbc2dd8: tst             x16, HEAP, lsr #32
    //     0xbc2ddc: b.eq            #0xbc2de4
    //     0xbc2de0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc2de4: ldur            x0, [fp, #-0x38]
    // 0xbc2de8: LoadField: r2 = r0->field_4b
    //     0xbc2de8: ldur            w2, [x0, #0x4b]
    // 0xbc2dec: DecompressPointer r2
    //     0xbc2dec: add             x2, x2, HEAP, lsl #32
    // 0xbc2df0: cmp             w2, NULL
    // 0xbc2df4: b.eq            #0xbc3304
    // 0xbc2df8: LoadField: d1 = r2->field_f
    //     0xbc2df8: ldur            d1, [x2, #0xf]
    // 0xbc2dfc: fadd            d2, d0, d1
    // 0xbc2e00: LoadField: r4 = r1->field_13
    //     0xbc2e00: ldur            w4, [x1, #0x13]
    // 0xbc2e04: DecompressPointer r4
    //     0xbc2e04: add             x4, x4, HEAP, lsl #32
    // 0xbc2e08: mov             v1.16b, v2.16b
    // 0xbc2e0c: ldur            x3, [fp, #-0x40]
    // 0xbc2e10: ldur            d0, [fp, #-0x50]
    // 0xbc2e14: b               #0xbc2d1c
    // 0xbc2e18: ldur            x0, [fp, #-0x10]
    // 0xbc2e1c: mov             v31.16b, v1.16b
    // 0xbc2e20: mov             v1.16b, v0.16b
    // 0xbc2e24: mov             v0.16b, v31.16b
    // 0xbc2e28: r0 = Size()
    //     0xbc2e28: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc2e2c: ldur            d0, [fp, #-0x50]
    // 0xbc2e30: StoreField: r0->field_7 = d0
    //     0xbc2e30: stur            d0, [x0, #7]
    // 0xbc2e34: ldur            d0, [fp, #-0x58]
    // 0xbc2e38: StoreField: r0->field_f = d0
    //     0xbc2e38: stur            d0, [x0, #0xf]
    // 0xbc2e3c: ldur            x1, [fp, #-8]
    // 0xbc2e40: mov             x2, x0
    // 0xbc2e44: r0 = constrain()
    //     0xbc2e44: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbc2e48: ldur            x1, [fp, #-0x10]
    // 0xbc2e4c: StoreField: r1->field_4b = r0
    //     0xbc2e4c: stur            w0, [x1, #0x4b]
    //     0xbc2e50: ldurb           w16, [x1, #-1]
    //     0xbc2e54: ldurb           w17, [x0, #-1]
    //     0xbc2e58: and             x16, x17, x16, lsr #2
    //     0xbc2e5c: tst             x16, HEAP, lsr #32
    //     0xbc2e60: b.eq            #0xbc2e68
    //     0xbc2e64: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc2e68: b               #0xbc30bc
    // 0xbc2e6c: ldur            x0, [fp, #-8]
    // 0xbc2e70: mov             v1.16b, v0.16b
    // 0xbc2e74: LoadField: d0 = r0->field_1f
    //     0xbc2e74: ldur            d0, [x0, #0x1f]
    // 0xbc2e78: stur            d0, [fp, #-0x50]
    // 0xbc2e7c: r0 = BoxConstraints()
    //     0xbc2e7c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc2e80: mov             x3, x0
    // 0xbc2e84: stur            x3, [fp, #-0x40]
    // 0xbc2e88: StoreField: r3->field_7 = rZR
    //     0xbc2e88: stur            xzr, [x3, #7]
    // 0xbc2e8c: d0 = inf
    //     0xbc2e8c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbc2e90: StoreField: r3->field_f = d0
    //     0xbc2e90: stur            d0, [x3, #0xf]
    // 0xbc2e94: ldur            d0, [fp, #-0x50]
    // 0xbc2e98: ArrayStore: r3[0] = d0  ; List_8
    //     0xbc2e98: stur            d0, [x3, #0x17]
    // 0xbc2e9c: StoreField: r3->field_1f = d0
    //     0xbc2e9c: stur            d0, [x3, #0x1f]
    // 0xbc2ea0: ldur            x4, [fp, #-0x18]
    // 0xbc2ea4: d1 = 0.000000
    //     0xbc2ea4: eor             v1.16b, v1.16b, v1.16b
    // 0xbc2ea8: stur            x4, [fp, #-0x18]
    // 0xbc2eac: stur            d1, [fp, #-0x58]
    // 0xbc2eb0: CheckStackOverflow
    //     0xbc2eb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc2eb4: cmp             SP, x16
    //     0xbc2eb8: b.ls            #0xbc3558
    // 0xbc2ebc: cmp             w4, NULL
    // 0xbc2ec0: b.eq            #0xbc2f7c
    // 0xbc2ec4: r0 = LoadClassIdInstr(r4)
    //     0xbc2ec4: ldur            x0, [x4, #-1]
    //     0xbc2ec8: ubfx            x0, x0, #0xc, #0x14
    // 0xbc2ecc: r16 = true
    //     0xbc2ecc: add             x16, NULL, #0x20  ; true
    // 0xbc2ed0: str             x16, [SP]
    // 0xbc2ed4: mov             x1, x4
    // 0xbc2ed8: mov             x2, x3
    // 0xbc2edc: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc2edc: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc2ee0: ldr             x4, [x4, #0xed0]
    // 0xbc2ee4: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbc2ee4: mov             x17, #0xe6b9
    //     0xbc2ee8: add             lr, x0, x17
    //     0xbc2eec: ldr             lr, [x21, lr, lsl #3]
    //     0xbc2ef0: blr             lr
    // 0xbc2ef4: ldur            x3, [fp, #-0x18]
    // 0xbc2ef8: LoadField: r4 = r3->field_7
    //     0xbc2ef8: ldur            w4, [x3, #7]
    // 0xbc2efc: DecompressPointer r4
    //     0xbc2efc: add             x4, x4, HEAP, lsl #32
    // 0xbc2f00: stur            x4, [fp, #-0x48]
    // 0xbc2f04: cmp             w4, NULL
    // 0xbc2f08: b.eq            #0xbc3560
    // 0xbc2f0c: mov             x0, x4
    // 0xbc2f10: r2 = Null
    //     0xbc2f10: mov             x2, NULL
    // 0xbc2f14: r1 = Null
    //     0xbc2f14: mov             x1, NULL
    // 0xbc2f18: r4 = LoadClassIdInstr(r0)
    //     0xbc2f18: ldur            x4, [x0, #-1]
    //     0xbc2f1c: ubfx            x4, x4, #0xc, #0x14
    // 0xbc2f20: r17 = 4211
    //     0xbc2f20: mov             x17, #0x1073
    // 0xbc2f24: cmp             x4, x17
    // 0xbc2f28: b.eq            #0xbc2f40
    // 0xbc2f2c: r8 = ListBodyParentData
    //     0xbc2f2c: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xbc2f30: ldr             x8, [x8, #0x3b0]
    // 0xbc2f34: r3 = Null
    //     0xbc2f34: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3498] Null
    //     0xbc2f38: ldr             x3, [x3, #0x498]
    // 0xbc2f3c: r0 = DefaultTypeTest()
    //     0xbc2f3c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc2f40: ldur            x0, [fp, #-0x18]
    // 0xbc2f44: LoadField: r1 = r0->field_4b
    //     0xbc2f44: ldur            w1, [x0, #0x4b]
    // 0xbc2f48: DecompressPointer r1
    //     0xbc2f48: add             x1, x1, HEAP, lsl #32
    // 0xbc2f4c: cmp             w1, NULL
    // 0xbc2f50: b.eq            #0xbc33b8
    // 0xbc2f54: ldur            d0, [fp, #-0x58]
    // 0xbc2f58: ldur            x0, [fp, #-0x48]
    // 0xbc2f5c: LoadField: d1 = r1->field_7
    //     0xbc2f5c: ldur            d1, [x1, #7]
    // 0xbc2f60: fadd            d2, d0, d1
    // 0xbc2f64: LoadField: r4 = r0->field_13
    //     0xbc2f64: ldur            w4, [x0, #0x13]
    // 0xbc2f68: DecompressPointer r4
    //     0xbc2f68: add             x4, x4, HEAP, lsl #32
    // 0xbc2f6c: mov             v1.16b, v2.16b
    // 0xbc2f70: ldur            x3, [fp, #-0x40]
    // 0xbc2f74: ldur            d0, [fp, #-0x50]
    // 0xbc2f78: b               #0xbc2ea8
    // 0xbc2f7c: ldur            x3, [fp, #-0x10]
    // 0xbc2f80: mov             v0.16b, v1.16b
    // 0xbc2f84: LoadField: r0 = r3->field_57
    //     0xbc2f84: ldur            w0, [x3, #0x57]
    // 0xbc2f88: DecompressPointer r0
    //     0xbc2f88: add             x0, x0, HEAP, lsl #32
    // 0xbc2f8c: mov             x4, x0
    // 0xbc2f90: d1 = 0.000000
    //     0xbc2f90: eor             v1.16b, v1.16b, v1.16b
    // 0xbc2f94: stur            x4, [fp, #-0x48]
    // 0xbc2f98: stur            d1, [fp, #-0x60]
    // 0xbc2f9c: CheckStackOverflow
    //     0xbc2f9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc2fa0: cmp             SP, x16
    //     0xbc2fa4: b.ls            #0xbc3564
    // 0xbc2fa8: cmp             w4, NULL
    // 0xbc2fac: b.eq            #0xbc3074
    // 0xbc2fb0: LoadField: r5 = r4->field_7
    //     0xbc2fb0: ldur            w5, [x4, #7]
    // 0xbc2fb4: DecompressPointer r5
    //     0xbc2fb4: add             x5, x5, HEAP, lsl #32
    // 0xbc2fb8: stur            x5, [fp, #-0x40]
    // 0xbc2fbc: cmp             w5, NULL
    // 0xbc2fc0: b.eq            #0xbc356c
    // 0xbc2fc4: mov             x0, x5
    // 0xbc2fc8: r2 = Null
    //     0xbc2fc8: mov             x2, NULL
    // 0xbc2fcc: r1 = Null
    //     0xbc2fcc: mov             x1, NULL
    // 0xbc2fd0: r4 = LoadClassIdInstr(r0)
    //     0xbc2fd0: ldur            x4, [x0, #-1]
    //     0xbc2fd4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc2fd8: r17 = 4211
    //     0xbc2fd8: mov             x17, #0x1073
    // 0xbc2fdc: cmp             x4, x17
    // 0xbc2fe0: b.eq            #0xbc2ff8
    // 0xbc2fe4: r8 = ListBodyParentData
    //     0xbc2fe4: add             x8, PP, #0xd3, lsl #12  ; [pp+0xd33b0] Type: ListBodyParentData
    //     0xbc2fe8: ldr             x8, [x8, #0x3b0]
    // 0xbc2fec: r3 = Null
    //     0xbc2fec: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd34a8] Null
    //     0xbc2ff0: ldr             x3, [x3, #0x4a8]
    // 0xbc2ff4: r0 = DefaultTypeTest()
    //     0xbc2ff4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc2ff8: ldur            x0, [fp, #-0x48]
    // 0xbc2ffc: LoadField: r1 = r0->field_4b
    //     0xbc2ffc: ldur            w1, [x0, #0x4b]
    // 0xbc3000: DecompressPointer r1
    //     0xbc3000: add             x1, x1, HEAP, lsl #32
    // 0xbc3004: cmp             w1, NULL
    // 0xbc3008: b.eq            #0xbc346c
    // 0xbc300c: ldur            d0, [fp, #-0x58]
    // 0xbc3010: ldur            d1, [fp, #-0x60]
    // 0xbc3014: ldur            x0, [fp, #-0x40]
    // 0xbc3018: LoadField: d2 = r1->field_7
    //     0xbc3018: ldur            d2, [x1, #7]
    // 0xbc301c: fadd            d3, d1, d2
    // 0xbc3020: stur            d3, [fp, #-0x68]
    // 0xbc3024: fsub            d1, d0, d3
    // 0xbc3028: stur            d1, [fp, #-0x60]
    // 0xbc302c: r0 = Offset()
    //     0xbc302c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc3030: ldur            d0, [fp, #-0x60]
    // 0xbc3034: StoreField: r0->field_7 = d0
    //     0xbc3034: stur            d0, [x0, #7]
    // 0xbc3038: StoreField: r0->field_f = rZR
    //     0xbc3038: stur            xzr, [x0, #0xf]
    // 0xbc303c: ldur            x1, [fp, #-0x40]
    // 0xbc3040: StoreField: r1->field_7 = r0
    //     0xbc3040: stur            w0, [x1, #7]
    //     0xbc3044: ldurb           w16, [x1, #-1]
    //     0xbc3048: ldurb           w17, [x0, #-1]
    //     0xbc304c: and             x16, x17, x16, lsr #2
    //     0xbc3050: tst             x16, HEAP, lsr #32
    //     0xbc3054: b.eq            #0xbc305c
    //     0xbc3058: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc305c: LoadField: r4 = r1->field_13
    //     0xbc305c: ldur            w4, [x1, #0x13]
    // 0xbc3060: DecompressPointer r4
    //     0xbc3060: add             x4, x4, HEAP, lsl #32
    // 0xbc3064: ldur            d1, [fp, #-0x68]
    // 0xbc3068: ldur            x3, [fp, #-0x10]
    // 0xbc306c: ldur            d0, [fp, #-0x58]
    // 0xbc3070: b               #0xbc2f94
    // 0xbc3074: mov             x0, x3
    // 0xbc3078: ldur            d1, [fp, #-0x50]
    // 0xbc307c: r0 = Size()
    //     0xbc307c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc3080: ldur            d0, [fp, #-0x58]
    // 0xbc3084: StoreField: r0->field_7 = d0
    //     0xbc3084: stur            d0, [x0, #7]
    // 0xbc3088: ldur            d0, [fp, #-0x50]
    // 0xbc308c: StoreField: r0->field_f = d0
    //     0xbc308c: stur            d0, [x0, #0xf]
    // 0xbc3090: ldur            x1, [fp, #-8]
    // 0xbc3094: mov             x2, x0
    // 0xbc3098: r0 = constrain()
    //     0xbc3098: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbc309c: ldur            x1, [fp, #-0x10]
    // 0xbc30a0: StoreField: r1->field_4b = r0
    //     0xbc30a0: stur            w0, [x1, #0x4b]
    //     0xbc30a4: ldurb           w16, [x1, #-1]
    //     0xbc30a8: ldurb           w17, [x0, #-1]
    //     0xbc30ac: and             x16, x17, x16, lsr #2
    //     0xbc30b0: tst             x16, HEAP, lsr #32
    //     0xbc30b4: b.eq            #0xbc30bc
    //     0xbc30b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc30bc: r0 = Null
    //     0xbc30bc: mov             x0, NULL
    // 0xbc30c0: LeaveFrame
    //     0xbc30c0: mov             SP, fp
    //     0xbc30c4: ldp             fp, lr, [SP], #0x10
    // 0xbc30c8: ret
    //     0xbc30c8: ret             
    // 0xbc30cc: r0 = StateError()
    //     0xbc30cc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc30d0: mov             x1, x0
    // 0xbc30d4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc30d4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc30d8: StoreField: r1->field_b = r0
    //     0xbc30d8: stur            w0, [x1, #0xb]
    // 0xbc30dc: mov             x0, x1
    // 0xbc30e0: r0 = Throw()
    //     0xbc30e0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc30e4: brk             #0
    // 0xbc30e8: r1 = Null
    //     0xbc30e8: mov             x1, NULL
    // 0xbc30ec: r2 = 8
    //     0xbc30ec: mov             x2, #8
    // 0xbc30f0: r0 = AllocateArray()
    //     0xbc30f0: bl              #0x13df928  ; AllocateArrayStub
    // 0xbc30f4: stur            x0, [fp, #-8]
    // 0xbc30f8: r16 = "RenderBox was not laid out: "
    //     0xbc30f8: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbc30fc: StoreField: r0->field_f = r16
    //     0xbc30fc: stur            w16, [x0, #0xf]
    // 0xbc3100: ldur            x16, [fp, #-0x20]
    // 0xbc3104: str             x16, [SP]
    // 0xbc3108: r0 = runtimeType()
    //     0xbc3108: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbc310c: ldur            x1, [fp, #-8]
    // 0xbc3110: ArrayStore: r1[1] = r0  ; List_4
    //     0xbc3110: add             x25, x1, #0x13
    //     0xbc3114: str             w0, [x25]
    //     0xbc3118: tbz             w0, #0, #0xbc3134
    //     0xbc311c: ldurb           w16, [x1, #-1]
    //     0xbc3120: ldurb           w17, [x0, #-1]
    //     0xbc3124: and             x16, x17, x16, lsr #2
    //     0xbc3128: tst             x16, HEAP, lsr #32
    //     0xbc312c: b.eq            #0xbc3134
    //     0xbc3130: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc3134: ldur            x0, [fp, #-8]
    // 0xbc3138: r16 = "#"
    //     0xbc3138: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbc313c: ArrayStore: r0[0] = r16  ; List_4
    //     0xbc313c: stur            w16, [x0, #0x17]
    // 0xbc3140: ldur            x1, [fp, #-0x20]
    // 0xbc3144: r0 = shortHash()
    //     0xbc3144: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbc3148: ldur            x1, [fp, #-8]
    // 0xbc314c: ArrayStore: r1[3] = r0  ; List_4
    //     0xbc314c: add             x25, x1, #0x1b
    //     0xbc3150: str             w0, [x25]
    //     0xbc3154: tbz             w0, #0, #0xbc3170
    //     0xbc3158: ldurb           w16, [x1, #-1]
    //     0xbc315c: ldurb           w17, [x0, #-1]
    //     0xbc3160: and             x16, x17, x16, lsr #2
    //     0xbc3164: tst             x16, HEAP, lsr #32
    //     0xbc3168: b.eq            #0xbc3170
    //     0xbc316c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc3170: ldur            x16, [fp, #-8]
    // 0xbc3174: str             x16, [SP]
    // 0xbc3178: r0 = _interpolate()
    //     0xbc3178: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbc317c: stur            x0, [fp, #-8]
    // 0xbc3180: r0 = StateError()
    //     0xbc3180: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc3184: mov             x1, x0
    // 0xbc3188: ldur            x0, [fp, #-8]
    // 0xbc318c: StoreField: r1->field_b = r0
    //     0xbc318c: stur            w0, [x1, #0xb]
    // 0xbc3190: mov             x0, x1
    // 0xbc3194: r0 = Throw()
    //     0xbc3194: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc3198: brk             #0
    // 0xbc319c: r1 = Null
    //     0xbc319c: mov             x1, NULL
    // 0xbc31a0: r2 = 8
    //     0xbc31a0: mov             x2, #8
    // 0xbc31a4: r0 = AllocateArray()
    //     0xbc31a4: bl              #0x13df928  ; AllocateArrayStub
    // 0xbc31a8: stur            x0, [fp, #-8]
    // 0xbc31ac: r16 = "RenderBox was not laid out: "
    //     0xbc31ac: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbc31b0: StoreField: r0->field_f = r16
    //     0xbc31b0: stur            w16, [x0, #0xf]
    // 0xbc31b4: ldur            x16, [fp, #-0x30]
    // 0xbc31b8: str             x16, [SP]
    // 0xbc31bc: r0 = runtimeType()
    //     0xbc31bc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbc31c0: ldur            x1, [fp, #-8]
    // 0xbc31c4: ArrayStore: r1[1] = r0  ; List_4
    //     0xbc31c4: add             x25, x1, #0x13
    //     0xbc31c8: str             w0, [x25]
    //     0xbc31cc: tbz             w0, #0, #0xbc31e8
    //     0xbc31d0: ldurb           w16, [x1, #-1]
    //     0xbc31d4: ldurb           w17, [x0, #-1]
    //     0xbc31d8: and             x16, x17, x16, lsr #2
    //     0xbc31dc: tst             x16, HEAP, lsr #32
    //     0xbc31e0: b.eq            #0xbc31e8
    //     0xbc31e4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc31e8: ldur            x0, [fp, #-8]
    // 0xbc31ec: r16 = "#"
    //     0xbc31ec: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbc31f0: ArrayStore: r0[0] = r16  ; List_4
    //     0xbc31f0: stur            w16, [x0, #0x17]
    // 0xbc31f4: ldur            x1, [fp, #-0x30]
    // 0xbc31f8: r0 = shortHash()
    //     0xbc31f8: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbc31fc: ldur            x1, [fp, #-8]
    // 0xbc3200: ArrayStore: r1[3] = r0  ; List_4
    //     0xbc3200: add             x25, x1, #0x1b
    //     0xbc3204: str             w0, [x25]
    //     0xbc3208: tbz             w0, #0, #0xbc3224
    //     0xbc320c: ldurb           w16, [x1, #-1]
    //     0xbc3210: ldurb           w17, [x0, #-1]
    //     0xbc3214: and             x16, x17, x16, lsr #2
    //     0xbc3218: tst             x16, HEAP, lsr #32
    //     0xbc321c: b.eq            #0xbc3224
    //     0xbc3220: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc3224: ldur            x16, [fp, #-8]
    // 0xbc3228: str             x16, [SP]
    // 0xbc322c: r0 = _interpolate()
    //     0xbc322c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbc3230: stur            x0, [fp, #-8]
    // 0xbc3234: r0 = StateError()
    //     0xbc3234: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc3238: mov             x1, x0
    // 0xbc323c: ldur            x0, [fp, #-8]
    // 0xbc3240: StoreField: r1->field_b = r0
    //     0xbc3240: stur            w0, [x1, #0xb]
    // 0xbc3244: mov             x0, x1
    // 0xbc3248: r0 = Throw()
    //     0xbc3248: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc324c: brk             #0
    // 0xbc3250: r1 = Null
    //     0xbc3250: mov             x1, NULL
    // 0xbc3254: r2 = 8
    //     0xbc3254: mov             x2, #8
    // 0xbc3258: r0 = AllocateArray()
    //     0xbc3258: bl              #0x13df928  ; AllocateArrayStub
    // 0xbc325c: stur            x0, [fp, #-8]
    // 0xbc3260: r16 = "RenderBox was not laid out: "
    //     0xbc3260: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbc3264: StoreField: r0->field_f = r16
    //     0xbc3264: stur            w16, [x0, #0xf]
    // 0xbc3268: ldur            x16, [fp, #-0x28]
    // 0xbc326c: str             x16, [SP]
    // 0xbc3270: r0 = runtimeType()
    //     0xbc3270: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbc3274: ldur            x1, [fp, #-8]
    // 0xbc3278: ArrayStore: r1[1] = r0  ; List_4
    //     0xbc3278: add             x25, x1, #0x13
    //     0xbc327c: str             w0, [x25]
    //     0xbc3280: tbz             w0, #0, #0xbc329c
    //     0xbc3284: ldurb           w16, [x1, #-1]
    //     0xbc3288: ldurb           w17, [x0, #-1]
    //     0xbc328c: and             x16, x17, x16, lsr #2
    //     0xbc3290: tst             x16, HEAP, lsr #32
    //     0xbc3294: b.eq            #0xbc329c
    //     0xbc3298: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc329c: ldur            x0, [fp, #-8]
    // 0xbc32a0: r16 = "#"
    //     0xbc32a0: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbc32a4: ArrayStore: r0[0] = r16  ; List_4
    //     0xbc32a4: stur            w16, [x0, #0x17]
    // 0xbc32a8: ldur            x1, [fp, #-0x28]
    // 0xbc32ac: r0 = shortHash()
    //     0xbc32ac: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbc32b0: ldur            x1, [fp, #-8]
    // 0xbc32b4: ArrayStore: r1[3] = r0  ; List_4
    //     0xbc32b4: add             x25, x1, #0x1b
    //     0xbc32b8: str             w0, [x25]
    //     0xbc32bc: tbz             w0, #0, #0xbc32d8
    //     0xbc32c0: ldurb           w16, [x1, #-1]
    //     0xbc32c4: ldurb           w17, [x0, #-1]
    //     0xbc32c8: and             x16, x17, x16, lsr #2
    //     0xbc32cc: tst             x16, HEAP, lsr #32
    //     0xbc32d0: b.eq            #0xbc32d8
    //     0xbc32d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc32d8: ldur            x16, [fp, #-8]
    // 0xbc32dc: str             x16, [SP]
    // 0xbc32e0: r0 = _interpolate()
    //     0xbc32e0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbc32e4: stur            x0, [fp, #-8]
    // 0xbc32e8: r0 = StateError()
    //     0xbc32e8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc32ec: mov             x1, x0
    // 0xbc32f0: ldur            x0, [fp, #-8]
    // 0xbc32f4: StoreField: r1->field_b = r0
    //     0xbc32f4: stur            w0, [x1, #0xb]
    // 0xbc32f8: mov             x0, x1
    // 0xbc32fc: r0 = Throw()
    //     0xbc32fc: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc3300: brk             #0
    // 0xbc3304: r1 = Null
    //     0xbc3304: mov             x1, NULL
    // 0xbc3308: r2 = 8
    //     0xbc3308: mov             x2, #8
    // 0xbc330c: r0 = AllocateArray()
    //     0xbc330c: bl              #0x13df928  ; AllocateArrayStub
    // 0xbc3310: stur            x0, [fp, #-8]
    // 0xbc3314: r16 = "RenderBox was not laid out: "
    //     0xbc3314: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbc3318: StoreField: r0->field_f = r16
    //     0xbc3318: stur            w16, [x0, #0xf]
    // 0xbc331c: ldur            x16, [fp, #-0x38]
    // 0xbc3320: str             x16, [SP]
    // 0xbc3324: r0 = runtimeType()
    //     0xbc3324: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbc3328: ldur            x1, [fp, #-8]
    // 0xbc332c: ArrayStore: r1[1] = r0  ; List_4
    //     0xbc332c: add             x25, x1, #0x13
    //     0xbc3330: str             w0, [x25]
    //     0xbc3334: tbz             w0, #0, #0xbc3350
    //     0xbc3338: ldurb           w16, [x1, #-1]
    //     0xbc333c: ldurb           w17, [x0, #-1]
    //     0xbc3340: and             x16, x17, x16, lsr #2
    //     0xbc3344: tst             x16, HEAP, lsr #32
    //     0xbc3348: b.eq            #0xbc3350
    //     0xbc334c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc3350: ldur            x0, [fp, #-8]
    // 0xbc3354: r16 = "#"
    //     0xbc3354: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbc3358: ArrayStore: r0[0] = r16  ; List_4
    //     0xbc3358: stur            w16, [x0, #0x17]
    // 0xbc335c: ldur            x1, [fp, #-0x38]
    // 0xbc3360: r0 = shortHash()
    //     0xbc3360: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbc3364: ldur            x1, [fp, #-8]
    // 0xbc3368: ArrayStore: r1[3] = r0  ; List_4
    //     0xbc3368: add             x25, x1, #0x1b
    //     0xbc336c: str             w0, [x25]
    //     0xbc3370: tbz             w0, #0, #0xbc338c
    //     0xbc3374: ldurb           w16, [x1, #-1]
    //     0xbc3378: ldurb           w17, [x0, #-1]
    //     0xbc337c: and             x16, x17, x16, lsr #2
    //     0xbc3380: tst             x16, HEAP, lsr #32
    //     0xbc3384: b.eq            #0xbc338c
    //     0xbc3388: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc338c: ldur            x16, [fp, #-8]
    // 0xbc3390: str             x16, [SP]
    // 0xbc3394: r0 = _interpolate()
    //     0xbc3394: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbc3398: stur            x0, [fp, #-8]
    // 0xbc339c: r0 = StateError()
    //     0xbc339c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc33a0: mov             x1, x0
    // 0xbc33a4: ldur            x0, [fp, #-8]
    // 0xbc33a8: StoreField: r1->field_b = r0
    //     0xbc33a8: stur            w0, [x1, #0xb]
    // 0xbc33ac: mov             x0, x1
    // 0xbc33b0: r0 = Throw()
    //     0xbc33b0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc33b4: brk             #0
    // 0xbc33b8: r1 = Null
    //     0xbc33b8: mov             x1, NULL
    // 0xbc33bc: r2 = 8
    //     0xbc33bc: mov             x2, #8
    // 0xbc33c0: r0 = AllocateArray()
    //     0xbc33c0: bl              #0x13df928  ; AllocateArrayStub
    // 0xbc33c4: stur            x0, [fp, #-8]
    // 0xbc33c8: r16 = "RenderBox was not laid out: "
    //     0xbc33c8: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbc33cc: StoreField: r0->field_f = r16
    //     0xbc33cc: stur            w16, [x0, #0xf]
    // 0xbc33d0: ldur            x16, [fp, #-0x18]
    // 0xbc33d4: str             x16, [SP]
    // 0xbc33d8: r0 = runtimeType()
    //     0xbc33d8: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbc33dc: ldur            x1, [fp, #-8]
    // 0xbc33e0: ArrayStore: r1[1] = r0  ; List_4
    //     0xbc33e0: add             x25, x1, #0x13
    //     0xbc33e4: str             w0, [x25]
    //     0xbc33e8: tbz             w0, #0, #0xbc3404
    //     0xbc33ec: ldurb           w16, [x1, #-1]
    //     0xbc33f0: ldurb           w17, [x0, #-1]
    //     0xbc33f4: and             x16, x17, x16, lsr #2
    //     0xbc33f8: tst             x16, HEAP, lsr #32
    //     0xbc33fc: b.eq            #0xbc3404
    //     0xbc3400: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc3404: ldur            x0, [fp, #-8]
    // 0xbc3408: r16 = "#"
    //     0xbc3408: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbc340c: ArrayStore: r0[0] = r16  ; List_4
    //     0xbc340c: stur            w16, [x0, #0x17]
    // 0xbc3410: ldur            x1, [fp, #-0x18]
    // 0xbc3414: r0 = shortHash()
    //     0xbc3414: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbc3418: ldur            x1, [fp, #-8]
    // 0xbc341c: ArrayStore: r1[3] = r0  ; List_4
    //     0xbc341c: add             x25, x1, #0x1b
    //     0xbc3420: str             w0, [x25]
    //     0xbc3424: tbz             w0, #0, #0xbc3440
    //     0xbc3428: ldurb           w16, [x1, #-1]
    //     0xbc342c: ldurb           w17, [x0, #-1]
    //     0xbc3430: and             x16, x17, x16, lsr #2
    //     0xbc3434: tst             x16, HEAP, lsr #32
    //     0xbc3438: b.eq            #0xbc3440
    //     0xbc343c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc3440: ldur            x16, [fp, #-8]
    // 0xbc3444: str             x16, [SP]
    // 0xbc3448: r0 = _interpolate()
    //     0xbc3448: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbc344c: stur            x0, [fp, #-8]
    // 0xbc3450: r0 = StateError()
    //     0xbc3450: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc3454: mov             x1, x0
    // 0xbc3458: ldur            x0, [fp, #-8]
    // 0xbc345c: StoreField: r1->field_b = r0
    //     0xbc345c: stur            w0, [x1, #0xb]
    // 0xbc3460: mov             x0, x1
    // 0xbc3464: r0 = Throw()
    //     0xbc3464: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc3468: brk             #0
    // 0xbc346c: r1 = Null
    //     0xbc346c: mov             x1, NULL
    // 0xbc3470: r2 = 8
    //     0xbc3470: mov             x2, #8
    // 0xbc3474: r0 = AllocateArray()
    //     0xbc3474: bl              #0x13df928  ; AllocateArrayStub
    // 0xbc3478: stur            x0, [fp, #-8]
    // 0xbc347c: r16 = "RenderBox was not laid out: "
    //     0xbc347c: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbc3480: StoreField: r0->field_f = r16
    //     0xbc3480: stur            w16, [x0, #0xf]
    // 0xbc3484: ldur            x16, [fp, #-0x48]
    // 0xbc3488: str             x16, [SP]
    // 0xbc348c: r0 = runtimeType()
    //     0xbc348c: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbc3490: ldur            x1, [fp, #-8]
    // 0xbc3494: ArrayStore: r1[1] = r0  ; List_4
    //     0xbc3494: add             x25, x1, #0x13
    //     0xbc3498: str             w0, [x25]
    //     0xbc349c: tbz             w0, #0, #0xbc34b8
    //     0xbc34a0: ldurb           w16, [x1, #-1]
    //     0xbc34a4: ldurb           w17, [x0, #-1]
    //     0xbc34a8: and             x16, x17, x16, lsr #2
    //     0xbc34ac: tst             x16, HEAP, lsr #32
    //     0xbc34b0: b.eq            #0xbc34b8
    //     0xbc34b4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc34b8: ldur            x0, [fp, #-8]
    // 0xbc34bc: r16 = "#"
    //     0xbc34bc: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbc34c0: ArrayStore: r0[0] = r16  ; List_4
    //     0xbc34c0: stur            w16, [x0, #0x17]
    // 0xbc34c4: ldur            x1, [fp, #-0x48]
    // 0xbc34c8: r0 = shortHash()
    //     0xbc34c8: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbc34cc: ldur            x1, [fp, #-8]
    // 0xbc34d0: ArrayStore: r1[3] = r0  ; List_4
    //     0xbc34d0: add             x25, x1, #0x1b
    //     0xbc34d4: str             w0, [x25]
    //     0xbc34d8: tbz             w0, #0, #0xbc34f4
    //     0xbc34dc: ldurb           w16, [x1, #-1]
    //     0xbc34e0: ldurb           w17, [x0, #-1]
    //     0xbc34e4: and             x16, x17, x16, lsr #2
    //     0xbc34e8: tst             x16, HEAP, lsr #32
    //     0xbc34ec: b.eq            #0xbc34f4
    //     0xbc34f0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbc34f4: ldur            x16, [fp, #-8]
    // 0xbc34f8: str             x16, [SP]
    // 0xbc34fc: r0 = _interpolate()
    //     0xbc34fc: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbc3500: stur            x0, [fp, #-8]
    // 0xbc3504: r0 = StateError()
    //     0xbc3504: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc3508: mov             x1, x0
    // 0xbc350c: ldur            x0, [fp, #-8]
    // 0xbc3510: StoreField: r1->field_b = r0
    //     0xbc3510: stur            w0, [x1, #0xb]
    // 0xbc3514: mov             x0, x1
    // 0xbc3518: r0 = Throw()
    //     0xbc3518: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc351c: brk             #0
    // 0xbc3520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc3520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc3524: b               #0xbc2884
    // 0xbc3528: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc3528: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc352c: b               #0xbc2940
    // 0xbc3530: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc3530: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc3534: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc3534: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc3538: b               #0xbc2a2c
    // 0xbc353c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc353c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc3540: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc3540: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc3544: b               #0xbc2b98
    // 0xbc3548: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc3548: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc354c: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc354c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc3550: b               #0xbc2d30
    // 0xbc3554: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc3554: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc3558: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc3558: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc355c: b               #0xbc2ebc
    // 0xbc3560: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc3560: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc3564: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc3564: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc3568: b               #0xbc2fa8
    // 0xbc356c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc356c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0d9e4, size: 0xb8
    // 0xc0d9e4: EnterFrame
    //     0xc0d9e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc0d9e8: mov             fp, SP
    // 0xc0d9ec: AllocStack(0x8)
    //     0xc0d9ec: sub             SP, SP, #8
    // 0xc0d9f0: SetupParameters(RenderListBody this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0d9f0: mov             x0, x2
    //     0xc0d9f4: mov             x4, x1
    //     0xc0d9f8: mov             x3, x2
    //     0xc0d9fc: stur            x2, [fp, #-8]
    // 0xc0da00: r2 = Null
    //     0xc0da00: mov             x2, NULL
    // 0xc0da04: r1 = Null
    //     0xc0da04: mov             x1, NULL
    // 0xc0da08: r4 = 60
    //     0xc0da08: mov             x4, #0x3c
    // 0xc0da0c: branchIfSmi(r0, 0xc0da18)
    //     0xc0da0c: tbz             w0, #0, #0xc0da18
    // 0xc0da10: r4 = LoadClassIdInstr(r0)
    //     0xc0da10: ldur            x4, [x0, #-1]
    //     0xc0da14: ubfx            x4, x4, #0xc, #0x14
    // 0xc0da18: r17 = -4710
    //     0xc0da18: mov             x17, #-0x1266
    // 0xc0da1c: add             x4, x4, x17
    // 0xc0da20: cmp             x4, #0x109
    // 0xc0da24: b.ls            #0xc0da38
    // 0xc0da28: r8 = RenderBox
    //     0xc0da28: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0da2c: r3 = Null
    //     0xc0da2c: add             x3, PP, #0xd3, lsl #12  ; [pp+0xd3548] Null
    //     0xc0da30: ldr             x3, [x3, #0x548]
    // 0xc0da34: r0 = RenderBox()
    //     0xc0da34: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0da38: ldur            x0, [fp, #-8]
    // 0xc0da3c: LoadField: r1 = r0->field_7
    //     0xc0da3c: ldur            w1, [x0, #7]
    // 0xc0da40: DecompressPointer r1
    //     0xc0da40: add             x1, x1, HEAP, lsl #32
    // 0xc0da44: r2 = LoadClassIdInstr(r1)
    //     0xc0da44: ldur            x2, [x1, #-1]
    //     0xc0da48: ubfx            x2, x2, #0xc, #0x14
    // 0xc0da4c: r17 = 4211
    //     0xc0da4c: mov             x17, #0x1073
    // 0xc0da50: cmp             x2, x17
    // 0xc0da54: b.eq            #0xc0da8c
    // 0xc0da58: r1 = <RenderBox>
    //     0xc0da58: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0da5c: ldr             x1, [x1, #0x5c8]
    // 0xc0da60: r0 = ListBodyParentData()
    //     0xc0da60: bl              #0xc0da9c  ; AllocateListBodyParentDataStub -> ListBodyParentData (size=0x18)
    // 0xc0da64: r1 = Instance_Offset
    //     0xc0da64: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0da68: StoreField: r0->field_7 = r1
    //     0xc0da68: stur            w1, [x0, #7]
    // 0xc0da6c: ldur            x1, [fp, #-8]
    // 0xc0da70: StoreField: r1->field_7 = r0
    //     0xc0da70: stur            w0, [x1, #7]
    //     0xc0da74: ldurb           w16, [x1, #-1]
    //     0xc0da78: ldurb           w17, [x0, #-1]
    //     0xc0da7c: and             x16, x17, x16, lsr #2
    //     0xc0da80: tst             x16, HEAP, lsr #32
    //     0xc0da84: b.eq            #0xc0da8c
    //     0xc0da88: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0da8c: r0 = Null
    //     0xc0da8c: mov             x0, NULL
    // 0xc0da90: LeaveFrame
    //     0xc0da90: mov             SP, fp
    //     0xc0da94: ldp             fp, lr, [SP], #0x10
    // 0xc0da98: ret
    //     0xc0da98: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc2269c, size: 0x30
    // 0xc2269c: EnterFrame
    //     0xc2269c: stp             fp, lr, [SP, #-0x10]!
    //     0xc226a0: mov             fp, SP
    // 0xc226a4: CheckStackOverflow
    //     0xc226a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc226a8: cmp             SP, x16
    //     0xc226ac: b.ls            #0xc226c4
    // 0xc226b0: r0 = defaultPaint()
    //     0xc226b0: bl              #0xc226cc  ; [dart:mixin_deduplication] _MixinApplication81&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0xc226b4: r0 = Null
    //     0xc226b4: mov             x0, NULL
    // 0xc226b8: LeaveFrame
    //     0xc226b8: mov             SP, fp
    //     0xc226bc: ldp             fp, lr, [SP], #0x10
    // 0xc226c0: ret
    //     0xc226c0: ret             
    // 0xc226c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc226c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc226c8: b               #0xc226b0
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ea318, size: 0x2c
    // 0x10ea318: EnterFrame
    //     0x10ea318: stp             fp, lr, [SP, #-0x10]!
    //     0x10ea31c: mov             fp, SP
    // 0x10ea320: CheckStackOverflow
    //     0x10ea320: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ea324: cmp             SP, x16
    //     0x10ea328: b.ls            #0x10ea33c
    // 0x10ea32c: r0 = defaultHitTestChildren()
    //     0x10ea32c: bl              #0x10ea344  ; [dart:mixin_deduplication] _MixinApplication81&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultHitTestChildren
    // 0x10ea330: LeaveFrame
    //     0x10ea330: mov             SP, fp
    //     0x10ea334: ldp             fp, lr, [SP], #0x10
    // 0x10ea338: ret
    //     0x10ea338: ret             
    // 0x10ea33c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ea33c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ea340: b               #0x10ea32c
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f0018, size: 0x24
    // 0x10f0018: EnterFrame
    //     0x10f0018: stp             fp, lr, [SP, #-0x10]!
    //     0x10f001c: mov             fp, SP
    // 0x10f0020: ldr             x2, [fp, #0x10]
    // 0x10f0024: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0024: add             x1, PP, #0xd3, lsl #12  ; [pp+0xd3388] AnonymousClosure: (0xb24ef8), in [package:flutter/src/rendering/list_body.dart] RenderListBody::computeMinIntrinsicHeight (0xb24e5c)
    //     0x10f0028: ldr             x1, [x1, #0x388]
    // 0x10f002c: r0 = AllocateClosure()
    //     0x10f002c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0030: LeaveFrame
    //     0x10f0030: mov             SP, fp
    //     0x10f0034: ldp             fp, lr, [SP], #0x10
    // 0x10f0038: ret
    //     0x10f0038: ret             
  }
}
