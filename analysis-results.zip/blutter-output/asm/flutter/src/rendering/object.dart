// lib: , url: package:flutter/src/rendering/object.dart

// class id: 1049034, size: 0x8
class :: {
}

// class id: 2860, size: 0x1c, field offset: 0x8
//   const constructor, 
class _SemanticsGeometry extends Object {

  static _ computeChildGeometry(/* No info */) {
    // ** addr: 0x8930e4, size: 0x6d4
    // 0x8930e4: EnterFrame
    //     0x8930e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8930e8: mov             fp, SP
    // 0x8930ec: AllocStack(0x90)
    //     0x8930ec: sub             SP, SP, #0x90
    // 0x8930f0: r0 = 2
    //     0x8930f0: mov             x0, #2
    // 0x8930f4: mov             x4, x5
    // 0x8930f8: stur            x5, [fp, #-0x20]
    // 0x8930fc: mov             x5, x3
    // 0x893100: stur            x3, [fp, #-0x18]
    // 0x893104: mov             x3, x6
    // 0x893108: stur            x6, [fp, #-0x28]
    // 0x89310c: CheckStackOverflow
    //     0x89310c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x893110: cmp             SP, x16
    //     0x893114: b.ls            #0x893794
    // 0x893118: LoadField: r6 = r1->field_7
    //     0x893118: ldur            w6, [x1, #7]
    // 0x89311c: DecompressPointer r6
    //     0x89311c: add             x6, x6, HEAP, lsl #32
    // 0x893120: stur            x6, [fp, #-0x10]
    // 0x893124: LoadField: r7 = r2->field_7
    //     0x893124: ldur            w7, [x2, #7]
    // 0x893128: DecompressPointer r7
    //     0x893128: add             x7, x7, HEAP, lsl #32
    // 0x89312c: mov             x2, x0
    // 0x893130: stur            x7, [fp, #-8]
    // 0x893134: r1 = Null
    //     0x893134: mov             x1, NULL
    // 0x893138: r0 = AllocateArray()
    //     0x893138: bl              #0x13df928  ; AllocateArrayStub
    // 0x89313c: mov             x2, x0
    // 0x893140: ldur            x0, [fp, #-0x10]
    // 0x893144: stur            x2, [fp, #-0x30]
    // 0x893148: StoreField: r2->field_f = r0
    //     0x893148: stur            w0, [x2, #0xf]
    // 0x89314c: r1 = <RenderObject>
    //     0x89314c: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x893150: r0 = AllocateGrowableArray()
    //     0x893150: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x893154: mov             x2, x0
    // 0x893158: ldur            x0, [fp, #-0x30]
    // 0x89315c: stur            x2, [fp, #-0x38]
    // 0x893160: StoreField: r2->field_f = r0
    //     0x893160: stur            w0, [x2, #0xf]
    // 0x893164: r0 = 2
    //     0x893164: mov             x0, #2
    // 0x893168: StoreField: r2->field_b = r0
    //     0x893168: stur            w0, [x2, #0xb]
    // 0x89316c: ldur            x1, [fp, #-0x10]
    // 0x893170: ldur            x3, [fp, #-8]
    // 0x893174: CheckStackOverflow
    //     0x893174: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x893178: cmp             SP, x16
    //     0x89317c: b.ls            #0x89379c
    // 0x893180: LoadField: r0 = r1->field_b
    //     0x893180: ldur            x0, [x1, #0xb]
    // 0x893184: LoadField: r4 = r3->field_b
    //     0x893184: ldur            x4, [x3, #0xb]
    // 0x893188: cmp             x0, x4
    // 0x89318c: b.le            #0x89326c
    // 0x893190: r0 = LoadClassIdInstr(r1)
    //     0x893190: ldur            x0, [x1, #-1]
    //     0x893194: ubfx            x0, x0, #0xc, #0x14
    // 0x893198: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x893198: mov             x17, #0xfc0
    //     0x89319c: movk            x17, #1, lsl #16
    //     0x8931a0: add             lr, x0, x17
    //     0x8931a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8931a8: blr             lr
    // 0x8931ac: mov             x3, x0
    // 0x8931b0: stur            x3, [fp, #-0x30]
    // 0x8931b4: cmp             w3, NULL
    // 0x8931b8: b.eq            #0x8937a4
    // 0x8931bc: mov             x0, x3
    // 0x8931c0: r2 = Null
    //     0x8931c0: mov             x2, NULL
    // 0x8931c4: r1 = Null
    //     0x8931c4: mov             x1, NULL
    // 0x8931c8: r4 = LoadClassIdInstr(r0)
    //     0x8931c8: ldur            x4, [x0, #-1]
    //     0x8931cc: ubfx            x4, x4, #0xc, #0x14
    // 0x8931d0: r17 = -4679
    //     0x8931d0: mov             x17, #-0x1247
    // 0x8931d4: add             x4, x4, x17
    // 0x8931d8: cmp             x4, #0x128
    // 0x8931dc: b.ls            #0x8931ec
    // 0x8931e0: r8 = RenderObject
    //     0x8931e0: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0x8931e4: r3 = Null
    //     0x8931e4: ldr             x3, [PP, #0x2a50]  ; [pp+0x2a50] Null
    // 0x8931e8: r0 = RenderObject()
    //     0x8931e8: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0x8931ec: ldur            x0, [fp, #-0x38]
    // 0x8931f0: LoadField: r1 = r0->field_b
    //     0x8931f0: ldur            w1, [x0, #0xb]
    // 0x8931f4: LoadField: r2 = r0->field_f
    //     0x8931f4: ldur            w2, [x0, #0xf]
    // 0x8931f8: DecompressPointer r2
    //     0x8931f8: add             x2, x2, HEAP, lsl #32
    // 0x8931fc: LoadField: r3 = r2->field_b
    //     0x8931fc: ldur            w3, [x2, #0xb]
    // 0x893200: r2 = LoadInt32Instr(r1)
    //     0x893200: sbfx            x2, x1, #1, #0x1f
    // 0x893204: stur            x2, [fp, #-0x40]
    // 0x893208: r1 = LoadInt32Instr(r3)
    //     0x893208: sbfx            x1, x3, #1, #0x1f
    // 0x89320c: cmp             x2, x1
    // 0x893210: b.ne            #0x89321c
    // 0x893214: mov             x1, x0
    // 0x893218: r0 = _growToNextCapacity()
    //     0x893218: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89321c: ldur            x2, [fp, #-0x38]
    // 0x893220: ldur            x3, [fp, #-0x40]
    // 0x893224: add             x0, x3, #1
    // 0x893228: lsl             x1, x0, #1
    // 0x89322c: StoreField: r2->field_b = r1
    //     0x89322c: stur            w1, [x2, #0xb]
    // 0x893230: LoadField: r1 = r2->field_f
    //     0x893230: ldur            w1, [x2, #0xf]
    // 0x893234: DecompressPointer r1
    //     0x893234: add             x1, x1, HEAP, lsl #32
    // 0x893238: ldur            x0, [fp, #-0x30]
    // 0x89323c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x89323c: add             x25, x1, x3, lsl #2
    //     0x893240: add             x25, x25, #0xf
    //     0x893244: str             w0, [x25]
    //     0x893248: tbz             w0, #0, #0x893264
    //     0x89324c: ldurb           w16, [x1, #-1]
    //     0x893250: ldurb           w17, [x0, #-1]
    //     0x893254: and             x16, x17, x16, lsr #2
    //     0x893258: tst             x16, HEAP, lsr #32
    //     0x89325c: b.eq            #0x893264
    //     0x893260: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x893264: ldur            x1, [fp, #-0x30]
    // 0x893268: b               #0x893170
    // 0x89326c: r0 = Matrix4()
    //     0x89326c: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x893270: r4 = 32
    //     0x893270: mov             x4, #0x20
    // 0x893274: stur            x0, [fp, #-8]
    // 0x893278: r0 = AllocateFloat64Array()
    //     0x893278: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x89327c: mov             x1, x0
    // 0x893280: ldur            x0, [fp, #-8]
    // 0x893284: StoreField: r0->field_7 = r1
    //     0x893284: stur            w1, [x0, #7]
    // 0x893288: mov             x1, x0
    // 0x89328c: r0 = setIdentity()
    //     0x89328c: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x893290: ldur            x3, [fp, #-0x38]
    // 0x893294: LoadField: r0 = r3->field_b
    //     0x893294: ldur            w0, [x3, #0xb]
    // 0x893298: r1 = LoadInt32Instr(r0)
    //     0x893298: sbfx            x1, x0, #1, #0x1f
    // 0x89329c: sub             x0, x1, #1
    // 0x8932a0: mov             x2, x0
    // 0x8932a4: r5 = Null
    //     0x8932a4: mov             x5, NULL
    // 0x8932a8: r4 = Null
    //     0x8932a8: mov             x4, NULL
    // 0x8932ac: stur            x5, [fp, #-0x50]
    // 0x8932b0: stur            x4, [fp, #-0x58]
    // 0x8932b4: CheckStackOverflow
    //     0x8932b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8932b8: cmp             SP, x16
    //     0x8932bc: b.ls            #0x8937a8
    // 0x8932c0: cmp             x2, #0
    // 0x8932c4: b.le            #0x893548
    // 0x8932c8: LoadField: r0 = r3->field_b
    //     0x8932c8: ldur            w0, [x3, #0xb]
    // 0x8932cc: r6 = LoadInt32Instr(r0)
    //     0x8932cc: sbfx            x6, x0, #1, #0x1f
    // 0x8932d0: mov             x0, x6
    // 0x8932d4: mov             x1, x2
    // 0x8932d8: cmp             x1, x0
    // 0x8932dc: b.hs            #0x8937b0
    // 0x8932e0: LoadField: r7 = r3->field_f
    //     0x8932e0: ldur            w7, [x3, #0xf]
    // 0x8932e4: DecompressPointer r7
    //     0x8932e4: add             x7, x7, HEAP, lsl #32
    // 0x8932e8: ArrayLoad: r8 = r7[r2]  ; Unknown_4
    //     0x8932e8: add             x16, x7, x2, lsl #2
    //     0x8932ec: ldur            w8, [x16, #0xf]
    // 0x8932f0: DecompressPointer r8
    //     0x8932f0: add             x8, x8, HEAP, lsl #32
    // 0x8932f4: stur            x8, [fp, #-0x48]
    // 0x8932f8: sub             x9, x2, #1
    // 0x8932fc: mov             x0, x6
    // 0x893300: mov             x1, x9
    // 0x893304: stur            x9, [fp, #-0x40]
    // 0x893308: cmp             x1, x0
    // 0x89330c: b.hs            #0x8937b4
    // 0x893310: ArrayLoad: r6 = r7[r9]  ; Unknown_4
    //     0x893310: add             x16, x7, x9, lsl #2
    //     0x893314: ldur            w6, [x16, #0xf]
    // 0x893318: DecompressPointer r6
    //     0x893318: add             x6, x6, HEAP, lsl #32
    // 0x89331c: stur            x6, [fp, #-0x30]
    // 0x893320: r0 = LoadClassIdInstr(r8)
    //     0x893320: ldur            x0, [x8, #-1]
    //     0x893324: ubfx            x0, x0, #0xc, #0x14
    // 0x893328: mov             x1, x8
    // 0x89332c: mov             x2, x6
    // 0x893330: r0 = GDT[cid_x0 + 0xebd6]()
    //     0x893330: mov             x17, #0xebd6
    //     0x893334: add             lr, x0, x17
    //     0x893338: ldr             lr, [x21, lr, lsl #3]
    //     0x89333c: blr             lr
    // 0x893340: stur            x0, [fp, #-0x60]
    // 0x893344: cmp             w0, NULL
    // 0x893348: b.ne            #0x893354
    // 0x89334c: r4 = Null
    //     0x89334c: mov             x4, NULL
    // 0x893350: b               #0x893398
    // 0x893354: LoadField: d0 = r0->field_7
    //     0x893354: ldur            d0, [x0, #7]
    // 0x893358: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x893358: ldur            d1, [x0, #0x17]
    // 0x89335c: fcmp            d0, d1
    // 0x893360: b.ge            #0x893380
    // 0x893364: LoadField: d0 = r0->field_f
    //     0x893364: ldur            d0, [x0, #0xf]
    // 0x893368: LoadField: d1 = r0->field_1f
    //     0x893368: ldur            d1, [x0, #0x1f]
    // 0x89336c: fcmp            d0, d1
    // 0x893370: b.ge            #0x893380
    // 0x893374: ldur            x1, [fp, #-8]
    // 0x893378: r0 = isZero()
    //     0x893378: bl              #0x89111c  ; [package:vector_math/vector_math_64.dart] Matrix4::isZero
    // 0x89337c: tbnz            w0, #4, #0x893388
    // 0x893380: r4 = Instance_Rect
    //     0x893380: ldr             x4, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0x893384: b               #0x893398
    // 0x893388: ldur            x1, [fp, #-8]
    // 0x89338c: ldur            x2, [fp, #-0x60]
    // 0x893390: r0 = transformRect()
    //     0x893390: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x893394: mov             x4, x0
    // 0x893398: ldur            x3, [fp, #-0x48]
    // 0x89339c: stur            x4, [fp, #-0x60]
    // 0x8933a0: r0 = LoadClassIdInstr(r3)
    //     0x8933a0: ldur            x0, [x3, #-1]
    //     0x8933a4: ubfx            x0, x0, #0xc, #0x14
    // 0x8933a8: mov             x1, x3
    // 0x8933ac: ldur            x2, [fp, #-0x30]
    // 0x8933b0: r0 = GDT[cid_x0 + 0xef46]()
    //     0x8933b0: mov             x17, #0xef46
    //     0x8933b4: add             lr, x0, x17
    //     0x8933b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8933bc: blr             lr
    // 0x8933c0: stur            x0, [fp, #-0x68]
    // 0x8933c4: cmp             w0, NULL
    // 0x8933c8: b.ne            #0x8933d4
    // 0x8933cc: r3 = Null
    //     0x8933cc: mov             x3, NULL
    // 0x8933d0: b               #0x893418
    // 0x8933d4: LoadField: d0 = r0->field_7
    //     0x8933d4: ldur            d0, [x0, #7]
    // 0x8933d8: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x8933d8: ldur            d1, [x0, #0x17]
    // 0x8933dc: fcmp            d0, d1
    // 0x8933e0: b.ge            #0x893400
    // 0x8933e4: LoadField: d0 = r0->field_f
    //     0x8933e4: ldur            d0, [x0, #0xf]
    // 0x8933e8: LoadField: d1 = r0->field_1f
    //     0x8933e8: ldur            d1, [x0, #0x1f]
    // 0x8933ec: fcmp            d0, d1
    // 0x8933f0: b.ge            #0x893400
    // 0x8933f4: ldur            x1, [fp, #-8]
    // 0x8933f8: r0 = isZero()
    //     0x8933f8: bl              #0x89111c  ; [package:vector_math/vector_math_64.dart] Matrix4::isZero
    // 0x8933fc: tbnz            w0, #4, #0x893408
    // 0x893400: r3 = Instance_Rect
    //     0x893400: ldr             x3, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0x893404: b               #0x893418
    // 0x893408: ldur            x1, [fp, #-8]
    // 0x89340c: ldur            x2, [fp, #-0x68]
    // 0x893410: r0 = transformRect()
    //     0x893410: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x893414: mov             x3, x0
    // 0x893418: ldur            x0, [fp, #-0x60]
    // 0x89341c: stur            x3, [fp, #-0x68]
    // 0x893420: cmp             w0, NULL
    // 0x893424: b.ne            #0x893434
    // 0x893428: ldur            x5, [fp, #-0x50]
    // 0x89342c: mov             x0, x3
    // 0x893430: b               #0x893468
    // 0x893434: ldur            x5, [fp, #-0x50]
    // 0x893438: cmp             w5, NULL
    // 0x89343c: b.ne            #0x893448
    // 0x893440: r0 = Null
    //     0x893440: mov             x0, NULL
    // 0x893444: b               #0x893454
    // 0x893448: mov             x1, x5
    // 0x89344c: mov             x2, x0
    // 0x893450: r0 = intersect()
    //     0x893450: bl              #0x87ada4  ; [dart:ui] Rect::intersect
    // 0x893454: cmp             w0, NULL
    // 0x893458: b.ne            #0x893460
    // 0x89345c: ldur            x0, [fp, #-0x60]
    // 0x893460: mov             x5, x0
    // 0x893464: ldur            x0, [fp, #-0x68]
    // 0x893468: stur            x5, [fp, #-0x70]
    // 0x89346c: cmp             w0, NULL
    // 0x893470: b.ne            #0x893504
    // 0x893474: ldur            x0, [fp, #-0x58]
    // 0x893478: cmp             w0, NULL
    // 0x89347c: b.ne            #0x893488
    // 0x893480: r0 = Null
    //     0x893480: mov             x0, NULL
    // 0x893484: b               #0x8934fc
    // 0x893488: ldur            x1, [fp, #-0x60]
    // 0x89348c: cmp             w1, NULL
    // 0x893490: b.ne            #0x893498
    // 0x893494: mov             x1, x0
    // 0x893498: LoadField: d0 = r0->field_7
    //     0x893498: ldur            d0, [x0, #7]
    // 0x89349c: LoadField: d1 = r1->field_7
    //     0x89349c: ldur            d1, [x1, #7]
    // 0x8934a0: fmax            v2.2d, v0.2d, v1.2d
    // 0x8934a4: stur            d2, [fp, #-0x90]
    // 0x8934a8: LoadField: d0 = r0->field_f
    //     0x8934a8: ldur            d0, [x0, #0xf]
    // 0x8934ac: LoadField: d1 = r1->field_f
    //     0x8934ac: ldur            d1, [x1, #0xf]
    // 0x8934b0: fmax            v3.2d, v0.2d, v1.2d
    // 0x8934b4: stur            d3, [fp, #-0x88]
    // 0x8934b8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x8934b8: ldur            d0, [x0, #0x17]
    // 0x8934bc: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x8934bc: ldur            d1, [x1, #0x17]
    // 0x8934c0: fmin            v4.2d, v0.2d, v1.2d
    // 0x8934c4: stur            d4, [fp, #-0x80]
    // 0x8934c8: LoadField: d0 = r0->field_1f
    //     0x8934c8: ldur            d0, [x0, #0x1f]
    // 0x8934cc: LoadField: d1 = r1->field_1f
    //     0x8934cc: ldur            d1, [x1, #0x1f]
    // 0x8934d0: fmin            v5.2d, v0.2d, v1.2d
    // 0x8934d4: stur            d5, [fp, #-0x78]
    // 0x8934d8: r0 = Rect()
    //     0x8934d8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8934dc: ldur            d0, [fp, #-0x90]
    // 0x8934e0: StoreField: r0->field_7 = d0
    //     0x8934e0: stur            d0, [x0, #7]
    // 0x8934e4: ldur            d0, [fp, #-0x88]
    // 0x8934e8: StoreField: r0->field_f = d0
    //     0x8934e8: stur            d0, [x0, #0xf]
    // 0x8934ec: ldur            d0, [fp, #-0x80]
    // 0x8934f0: ArrayStore: r0[0] = d0  ; List_8
    //     0x8934f0: stur            d0, [x0, #0x17]
    // 0x8934f4: ldur            d0, [fp, #-0x78]
    // 0x8934f8: StoreField: r0->field_1f = d0
    //     0x8934f8: stur            d0, [x0, #0x1f]
    // 0x8934fc: mov             x4, x0
    // 0x893500: b               #0x893508
    // 0x893504: mov             x4, x0
    // 0x893508: ldur            x1, [fp, #-0x48]
    // 0x89350c: stur            x4, [fp, #-0x60]
    // 0x893510: r0 = LoadClassIdInstr(r1)
    //     0x893510: ldur            x0, [x1, #-1]
    //     0x893514: ubfx            x0, x0, #0xc, #0x14
    // 0x893518: ldur            x2, [fp, #-0x30]
    // 0x89351c: ldur            x3, [fp, #-8]
    // 0x893520: r0 = GDT[cid_x0 + 0x10462]()
    //     0x893520: mov             x17, #0x462
    //     0x893524: movk            x17, #1, lsl #16
    //     0x893528: add             lr, x0, x17
    //     0x89352c: ldr             lr, [x21, lr, lsl #3]
    //     0x893530: blr             lr
    // 0x893534: ldur            x5, [fp, #-0x70]
    // 0x893538: ldur            x4, [fp, #-0x60]
    // 0x89353c: ldur            x2, [fp, #-0x40]
    // 0x893540: ldur            x3, [fp, #-0x38]
    // 0x893544: b               #0x8932ac
    // 0x893548: mov             x0, x4
    // 0x89354c: cmp             w0, NULL
    // 0x893550: b.ne            #0x893560
    // 0x893554: mov             x1, x5
    // 0x893558: ldur            x2, [fp, #-0x20]
    // 0x89355c: r0 = _intersectRects()
    //     0x89355c: bl              #0x893c54  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_intersectRects
    // 0x893560: ldur            x1, [fp, #-0x50]
    // 0x893564: ldur            x2, [fp, #-0x18]
    // 0x893568: stur            x0, [fp, #-0x20]
    // 0x89356c: r0 = _intersectRects()
    //     0x89356c: bl              #0x893c54  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_intersectRects
    // 0x893570: stur            x0, [fp, #-0x18]
    // 0x893574: cmp             w0, NULL
    // 0x893578: b.eq            #0x893584
    // 0x89357c: ldur            x2, [fp, #-0x20]
    // 0x893580: b               #0x893590
    // 0x893584: ldur            x2, [fp, #-0x20]
    // 0x893588: cmp             w2, NULL
    // 0x89358c: b.eq            #0x893608
    // 0x893590: ldur            x1, [fp, #-8]
    // 0x893594: r0 = clone()
    //     0x893594: bl              #0x832afc  ; [package:vector_math/vector_math_64.dart] Matrix4::clone
    // 0x893598: mov             x1, x0
    // 0x89359c: stur            x0, [fp, #-0x30]
    // 0x8935a0: r0 = invert()
    //     0x8935a0: bl              #0x857b2c  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0x8935a4: mov             v1.16b, v0.16b
    // 0x8935a8: d0 = 0.000000
    //     0x8935a8: eor             v0.16b, v0.16b, v0.16b
    // 0x8935ac: fcmp            d1, d0
    // 0x8935b0: r16 = true
    //     0x8935b0: add             x16, NULL, #0x20  ; true
    // 0x8935b4: r17 = false
    //     0x8935b4: add             x17, NULL, #0x30  ; false
    // 0x8935b8: csel            x0, x16, x17, ne
    // 0x8935bc: stur            x0, [fp, #-0x38]
    // 0x8935c0: tbnz            w0, #4, #0x8935d8
    // 0x8935c4: ldur            x1, [fp, #-0x20]
    // 0x8935c8: ldur            x2, [fp, #-0x30]
    // 0x8935cc: r0 = _transformRect()
    //     0x8935cc: bl              #0x893bb8  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_transformRect
    // 0x8935d0: mov             x3, x0
    // 0x8935d4: b               #0x8935dc
    // 0x8935d8: r3 = Null
    //     0x8935d8: mov             x3, NULL
    // 0x8935dc: ldur            x0, [fp, #-0x38]
    // 0x8935e0: stur            x3, [fp, #-0x48]
    // 0x8935e4: tbnz            w0, #4, #0x8935f8
    // 0x8935e8: ldur            x1, [fp, #-0x18]
    // 0x8935ec: ldur            x2, [fp, #-0x30]
    // 0x8935f0: r0 = _transformRect()
    //     0x8935f0: bl              #0x893bb8  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_transformRect
    // 0x8935f4: b               #0x8935fc
    // 0x8935f8: r0 = Null
    //     0x8935f8: mov             x0, NULL
    // 0x8935fc: mov             x3, x0
    // 0x893600: ldur            x0, [fp, #-0x48]
    // 0x893604: b               #0x893610
    // 0x893608: ldur            x3, [fp, #-0x18]
    // 0x89360c: ldur            x0, [fp, #-0x20]
    // 0x893610: ldur            x1, [fp, #-0x28]
    // 0x893614: stur            x3, [fp, #-0x18]
    // 0x893618: stur            x0, [fp, #-0x20]
    // 0x89361c: cmp             w1, NULL
    // 0x893620: b.eq            #0x89362c
    // 0x893624: ldur            x2, [fp, #-8]
    // 0x893628: r0 = multiplyInPlace()
    //     0x893628: bl              #0x8937c4  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::multiplyInPlace
    // 0x89362c: ldur            x2, [fp, #-0x20]
    // 0x893630: cmp             w2, NULL
    // 0x893634: b.ne            #0x893640
    // 0x893638: r0 = Null
    //     0x893638: mov             x0, NULL
    // 0x89363c: b               #0x893670
    // 0x893640: ldur            x3, [fp, #-0x10]
    // 0x893644: r0 = LoadClassIdInstr(r3)
    //     0x893644: ldur            x0, [x3, #-1]
    //     0x893648: ubfx            x0, x0, #0xc, #0x14
    // 0x89364c: mov             x1, x3
    // 0x893650: r0 = GDT[cid_x0 + 0x1021c]()
    //     0x893650: mov             x17, #0x21c
    //     0x893654: movk            x17, #1, lsl #16
    //     0x893658: add             lr, x0, x17
    //     0x89365c: ldr             lr, [x21, lr, lsl #3]
    //     0x893660: blr             lr
    // 0x893664: ldur            x1, [fp, #-0x20]
    // 0x893668: mov             x2, x0
    // 0x89366c: r0 = intersect()
    //     0x89366c: bl              #0x87ada4  ; [dart:ui] Rect::intersect
    // 0x893670: cmp             w0, NULL
    // 0x893674: b.ne            #0x8936a0
    // 0x893678: ldur            x1, [fp, #-0x10]
    // 0x89367c: r0 = LoadClassIdInstr(r1)
    //     0x89367c: ldur            x0, [x1, #-1]
    //     0x893680: ubfx            x0, x0, #0xc, #0x14
    // 0x893684: r0 = GDT[cid_x0 + 0x1021c]()
    //     0x893684: mov             x17, #0x21c
    //     0x893688: movk            x17, #1, lsl #16
    //     0x89368c: add             lr, x0, x17
    //     0x893690: ldr             lr, [x21, lr, lsl #3]
    //     0x893694: blr             lr
    // 0x893698: mov             x3, x0
    // 0x89369c: b               #0x8936a4
    // 0x8936a0: mov             x3, x0
    // 0x8936a4: ldur            x0, [fp, #-0x18]
    // 0x8936a8: stur            x3, [fp, #-0x10]
    // 0x8936ac: cmp             w0, NULL
    // 0x8936b0: b.eq            #0x89373c
    // 0x8936b4: mov             x1, x0
    // 0x8936b8: mov             x2, x3
    // 0x8936bc: r0 = intersect()
    //     0x8936bc: bl              #0x87ada4  ; [dart:ui] Rect::intersect
    // 0x8936c0: LoadField: d0 = r0->field_7
    //     0x8936c0: ldur            d0, [x0, #7]
    // 0x8936c4: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x8936c4: ldur            d1, [x0, #0x17]
    // 0x8936c8: fcmp            d0, d1
    // 0x8936cc: b.ge            #0x8936e0
    // 0x8936d0: LoadField: d0 = r0->field_f
    //     0x8936d0: ldur            d0, [x0, #0xf]
    // 0x8936d4: LoadField: d1 = r0->field_1f
    //     0x8936d4: ldur            d1, [x0, #0x1f]
    // 0x8936d8: fcmp            d0, d1
    // 0x8936dc: b.lt            #0x893720
    // 0x8936e0: ldur            x1, [fp, #-0x10]
    // 0x8936e4: LoadField: d0 = r1->field_7
    //     0x8936e4: ldur            d0, [x1, #7]
    // 0x8936e8: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x8936e8: ldur            d1, [x1, #0x17]
    // 0x8936ec: fcmp            d0, d1
    // 0x8936f0: b.lt            #0x8936fc
    // 0x8936f4: r2 = true
    //     0x8936f4: add             x2, NULL, #0x20  ; true
    // 0x8936f8: b               #0x893714
    // 0x8936fc: LoadField: d0 = r1->field_f
    //     0x8936fc: ldur            d0, [x1, #0xf]
    // 0x893700: LoadField: d1 = r1->field_1f
    //     0x893700: ldur            d1, [x1, #0x1f]
    // 0x893704: fcmp            d0, d1
    // 0x893708: r16 = true
    //     0x893708: add             x16, NULL, #0x20  ; true
    // 0x89370c: r17 = false
    //     0x89370c: add             x17, NULL, #0x30  ; false
    // 0x893710: csel            x2, x16, x17, ge
    // 0x893714: eor             x3, x2, #0x10
    // 0x893718: mov             x2, x3
    // 0x89371c: b               #0x893728
    // 0x893720: ldur            x1, [fp, #-0x10]
    // 0x893724: r2 = false
    //     0x893724: add             x2, NULL, #0x30  ; false
    // 0x893728: tbnz            w2, #4, #0x893730
    // 0x89372c: mov             x0, x1
    // 0x893730: mov             x4, x0
    // 0x893734: mov             x3, x2
    // 0x893738: b               #0x893748
    // 0x89373c: mov             x1, x3
    // 0x893740: mov             x4, x1
    // 0x893744: r3 = false
    //     0x893744: add             x3, NULL, #0x30  ; false
    // 0x893748: ldur            x0, [fp, #-0x18]
    // 0x89374c: ldur            x1, [fp, #-0x20]
    // 0x893750: ldur            x2, [fp, #-8]
    // 0x893754: stur            x4, [fp, #-0x10]
    // 0x893758: stur            x3, [fp, #-0x28]
    // 0x89375c: r0 = _SemanticsGeometry()
    //     0x89375c: bl              #0x8937b8  ; Allocate_SemanticsGeometryStub -> _SemanticsGeometry (size=0x1c)
    // 0x893760: ldur            x1, [fp, #-0x18]
    // 0x893764: StoreField: r0->field_f = r1
    //     0x893764: stur            w1, [x0, #0xf]
    // 0x893768: ldur            x1, [fp, #-0x20]
    // 0x89376c: StoreField: r0->field_b = r1
    //     0x89376c: stur            w1, [x0, #0xb]
    // 0x893770: ldur            x1, [fp, #-8]
    // 0x893774: StoreField: r0->field_7 = r1
    //     0x893774: stur            w1, [x0, #7]
    // 0x893778: ldur            x1, [fp, #-0x10]
    // 0x89377c: StoreField: r0->field_13 = r1
    //     0x89377c: stur            w1, [x0, #0x13]
    // 0x893780: ldur            x1, [fp, #-0x28]
    // 0x893784: ArrayStore: r0[0] = r1  ; List_4
    //     0x893784: stur            w1, [x0, #0x17]
    // 0x893788: LeaveFrame
    //     0x893788: mov             SP, fp
    //     0x89378c: ldp             fp, lr, [SP], #0x10
    // 0x893790: ret
    //     0x893790: ret             
    // 0x893794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x893794: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x893798: b               #0x893118
    // 0x89379c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89379c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8937a0: b               #0x893180
    // 0x8937a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8937a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8937a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8937a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8937ac: b               #0x8932c0
    // 0x8937b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8937b0: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8937b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8937b4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _transformRect(/* No info */) {
    // ** addr: 0x893bb8, size: 0x9c
    // 0x893bb8: EnterFrame
    //     0x893bb8: stp             fp, lr, [SP, #-0x10]!
    //     0x893bbc: mov             fp, SP
    // 0x893bc0: AllocStack(0x10)
    //     0x893bc0: sub             SP, SP, #0x10
    // 0x893bc4: SetupParameters(dynamic _ /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x893bc4: mov             x0, x2
    //     0x893bc8: stur            x2, [fp, #-0x10]
    //     0x893bcc: mov             x2, x1
    //     0x893bd0: stur            x1, [fp, #-8]
    // 0x893bd4: CheckStackOverflow
    //     0x893bd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x893bd8: cmp             SP, x16
    //     0x893bdc: b.ls            #0x893c4c
    // 0x893be0: cmp             w2, NULL
    // 0x893be4: b.ne            #0x893bf8
    // 0x893be8: r0 = Null
    //     0x893be8: mov             x0, NULL
    // 0x893bec: LeaveFrame
    //     0x893bec: mov             SP, fp
    //     0x893bf0: ldp             fp, lr, [SP], #0x10
    // 0x893bf4: ret
    //     0x893bf4: ret             
    // 0x893bf8: LoadField: d0 = r2->field_7
    //     0x893bf8: ldur            d0, [x2, #7]
    // 0x893bfc: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x893bfc: ldur            d1, [x2, #0x17]
    // 0x893c00: fcmp            d0, d1
    // 0x893c04: b.ge            #0x893c24
    // 0x893c08: LoadField: d0 = r2->field_f
    //     0x893c08: ldur            d0, [x2, #0xf]
    // 0x893c0c: LoadField: d1 = r2->field_1f
    //     0x893c0c: ldur            d1, [x2, #0x1f]
    // 0x893c10: fcmp            d0, d1
    // 0x893c14: b.ge            #0x893c24
    // 0x893c18: mov             x1, x0
    // 0x893c1c: r0 = isZero()
    //     0x893c1c: bl              #0x89111c  ; [package:vector_math/vector_math_64.dart] Matrix4::isZero
    // 0x893c20: tbnz            w0, #4, #0x893c34
    // 0x893c24: r0 = Instance_Rect
    //     0x893c24: ldr             x0, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0x893c28: LeaveFrame
    //     0x893c28: mov             SP, fp
    //     0x893c2c: ldp             fp, lr, [SP], #0x10
    // 0x893c30: ret
    //     0x893c30: ret             
    // 0x893c34: ldur            x1, [fp, #-0x10]
    // 0x893c38: ldur            x2, [fp, #-8]
    // 0x893c3c: r0 = transformRect()
    //     0x893c3c: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x893c40: LeaveFrame
    //     0x893c40: mov             SP, fp
    //     0x893c44: ldp             fp, lr, [SP], #0x10
    // 0x893c48: ret
    //     0x893c48: ret             
    // 0x893c4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x893c4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x893c50: b               #0x893be0
  }
  static _ _intersectRects(/* No info */) {
    // ** addr: 0x893c54, size: 0x7c
    // 0x893c54: EnterFrame
    //     0x893c54: stp             fp, lr, [SP, #-0x10]!
    //     0x893c58: mov             fp, SP
    // 0x893c5c: AllocStack(0x8)
    //     0x893c5c: sub             SP, SP, #8
    // 0x893c60: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x893c60: mov             x0, x2
    //     0x893c64: stur            x2, [fp, #-8]
    // 0x893c68: CheckStackOverflow
    //     0x893c68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x893c6c: cmp             SP, x16
    //     0x893c70: b.ls            #0x893cc8
    // 0x893c74: cmp             w0, NULL
    // 0x893c78: b.ne            #0x893c8c
    // 0x893c7c: mov             x0, x1
    // 0x893c80: LeaveFrame
    //     0x893c80: mov             SP, fp
    //     0x893c84: ldp             fp, lr, [SP], #0x10
    // 0x893c88: ret
    //     0x893c88: ret             
    // 0x893c8c: cmp             w1, NULL
    // 0x893c90: b.ne            #0x893c9c
    // 0x893c94: r1 = Null
    //     0x893c94: mov             x1, NULL
    // 0x893c98: b               #0x893ca8
    // 0x893c9c: mov             x2, x0
    // 0x893ca0: r0 = intersect()
    //     0x893ca0: bl              #0x87ada4  ; [dart:ui] Rect::intersect
    // 0x893ca4: mov             x1, x0
    // 0x893ca8: cmp             w1, NULL
    // 0x893cac: b.ne            #0x893cb8
    // 0x893cb0: ldur            x0, [fp, #-8]
    // 0x893cb4: b               #0x893cbc
    // 0x893cb8: mov             x0, x1
    // 0x893cbc: LeaveFrame
    //     0x893cbc: mov             SP, fp
    //     0x893cc0: ldp             fp, lr, [SP], #0x10
    // 0x893cc4: ret
    //     0x893cc4: ret             
    // 0x893cc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x893cc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x893ccc: b               #0x893c74
  }
  get _ isVisible(/* No info */) {
    // ** addr: 0x895100, size: 0x7c
    // 0x895100: EnterFrame
    //     0x895100: stp             fp, lr, [SP, #-0x10]!
    //     0x895104: mov             fp, SP
    // 0x895108: CheckStackOverflow
    //     0x895108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89510c: cmp             SP, x16
    //     0x895110: b.ls            #0x895174
    // 0x895114: LoadField: r0 = r1->field_13
    //     0x895114: ldur            w0, [x1, #0x13]
    // 0x895118: DecompressPointer r0
    //     0x895118: add             x0, x0, HEAP, lsl #32
    // 0x89511c: LoadField: d0 = r0->field_7
    //     0x89511c: ldur            d0, [x0, #7]
    // 0x895120: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x895120: ldur            d1, [x0, #0x17]
    // 0x895124: fcmp            d0, d1
    // 0x895128: b.ge            #0x895164
    // 0x89512c: LoadField: d0 = r0->field_f
    //     0x89512c: ldur            d0, [x0, #0xf]
    // 0x895130: LoadField: d1 = r0->field_1f
    //     0x895130: ldur            d1, [x0, #0x1f]
    // 0x895134: fcmp            d0, d1
    // 0x895138: r16 = true
    //     0x895138: add             x16, NULL, #0x20  ; true
    // 0x89513c: r17 = false
    //     0x89513c: add             x17, NULL, #0x30  ; false
    // 0x895140: csel            x0, x16, x17, ge
    // 0x895144: tbz             w0, #4, #0x895164
    // 0x895148: LoadField: r0 = r1->field_7
    //     0x895148: ldur            w0, [x1, #7]
    // 0x89514c: DecompressPointer r0
    //     0x89514c: add             x0, x0, HEAP, lsl #32
    // 0x895150: mov             x1, x0
    // 0x895154: r0 = isZero()
    //     0x895154: bl              #0x89111c  ; [package:vector_math/vector_math_64.dart] Matrix4::isZero
    // 0x895158: eor             x1, x0, #0x10
    // 0x89515c: mov             x0, x1
    // 0x895160: b               #0x895168
    // 0x895164: r0 = false
    //     0x895164: add             x0, NULL, #0x30  ; false
    // 0x895168: LeaveFrame
    //     0x895168: mov             SP, fp
    //     0x89516c: ldp             fp, lr, [SP], #0x10
    // 0x895170: ret
    //     0x895170: ret             
    // 0x895174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895174: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895178: b               #0x895114
  }
  factory _ _SemanticsGeometry.root(/* No info */) {
    // ** addr: 0x895808, size: 0x70
    // 0x895808: EnterFrame
    //     0x895808: stp             fp, lr, [SP, #-0x10]!
    //     0x89580c: mov             fp, SP
    // 0x895810: AllocStack(0x10)
    //     0x895810: sub             SP, SP, #0x10
    // 0x895814: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x895814: stur            x2, [fp, #-8]
    // 0x895818: CheckStackOverflow
    //     0x895818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89581c: cmp             SP, x16
    //     0x895820: b.ls            #0x895870
    // 0x895824: r0 = Matrix4()
    //     0x895824: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x895828: r4 = 32
    //     0x895828: mov             x4, #0x20
    // 0x89582c: stur            x0, [fp, #-0x10]
    // 0x895830: r0 = AllocateFloat64Array()
    //     0x895830: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x895834: mov             x1, x0
    // 0x895838: ldur            x0, [fp, #-0x10]
    // 0x89583c: StoreField: r0->field_7 = r1
    //     0x89583c: stur            w1, [x0, #7]
    // 0x895840: mov             x1, x0
    // 0x895844: r0 = setIdentity()
    //     0x895844: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x895848: r0 = _SemanticsGeometry()
    //     0x895848: bl              #0x8937b8  ; Allocate_SemanticsGeometryStub -> _SemanticsGeometry (size=0x1c)
    // 0x89584c: ldur            x1, [fp, #-0x10]
    // 0x895850: StoreField: r0->field_7 = r1
    //     0x895850: stur            w1, [x0, #7]
    // 0x895854: ldur            x1, [fp, #-8]
    // 0x895858: StoreField: r0->field_13 = r1
    //     0x895858: stur            w1, [x0, #0x13]
    // 0x89585c: r1 = false
    //     0x89585c: add             x1, NULL, #0x30  ; false
    // 0x895860: ArrayStore: r0[0] = r1  ; List_4
    //     0x895860: stur            w1, [x0, #0x17]
    // 0x895864: LeaveFrame
    //     0x895864: mov             SP, fp
    //     0x895868: ldp             fp, lr, [SP], #0x10
    // 0x89586c: ret
    //     0x89586c: ret             
    // 0x895870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895870: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895874: b               #0x895824
  }
}

// class id: 2861, size: 0x18, field offset: 0x8
class _SemanticsConfigurationProvider extends Object {

  get _ effective(/* No info */) {
    // ** addr: 0x83794c, size: 0x3c
    // 0x83794c: EnterFrame
    //     0x83794c: stp             fp, lr, [SP, #-0x10]!
    //     0x837950: mov             fp, SP
    // 0x837954: CheckStackOverflow
    //     0x837954: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x837958: cmp             SP, x16
    //     0x83795c: b.ls            #0x837980
    // 0x837960: LoadField: r0 = r1->field_13
    //     0x837960: ldur            w0, [x1, #0x13]
    // 0x837964: DecompressPointer r0
    //     0x837964: add             x0, x0, HEAP, lsl #32
    // 0x837968: cmp             w0, NULL
    // 0x83796c: b.ne            #0x837974
    // 0x837970: r0 = original()
    //     0x837970: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x837974: LeaveFrame
    //     0x837974: mov             SP, fp
    //     0x837978: ldp             fp, lr, [SP], #0x10
    // 0x83797c: ret
    //     0x83797c: ret             
    // 0x837980: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x837980: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x837984: b               #0x837960
  }
  get _ original(/* No info */) {
    // ** addr: 0x837bc4, size: 0xd0
    // 0x837bc4: EnterFrame
    //     0x837bc4: stp             fp, lr, [SP, #-0x10]!
    //     0x837bc8: mov             fp, SP
    // 0x837bcc: AllocStack(0x10)
    //     0x837bcc: sub             SP, SP, #0x10
    // 0x837bd0: SetupParameters(_SemanticsConfigurationProvider this /* r1 => r1, fp-0x8 */)
    //     0x837bd0: stur            x1, [fp, #-8]
    // 0x837bd4: CheckStackOverflow
    //     0x837bd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x837bd8: cmp             SP, x16
    //     0x837bdc: b.ls            #0x837c88
    // 0x837be0: LoadField: r0 = r1->field_f
    //     0x837be0: ldur            w0, [x1, #0xf]
    // 0x837be4: DecompressPointer r0
    //     0x837be4: add             x0, x0, HEAP, lsl #32
    // 0x837be8: cmp             w0, NULL
    // 0x837bec: b.ne            #0x837c68
    // 0x837bf0: r0 = SemanticsConfiguration()
    //     0x837bf0: bl              #0x839284  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0xc8)
    // 0x837bf4: mov             x1, x0
    // 0x837bf8: stur            x0, [fp, #-0x10]
    // 0x837bfc: r0 = SemanticsConfiguration()
    //     0x837bfc: bl              #0x837c94  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0x837c00: ldur            x0, [fp, #-0x10]
    // 0x837c04: ldur            x3, [fp, #-8]
    // 0x837c08: StoreField: r3->field_f = r0
    //     0x837c08: stur            w0, [x3, #0xf]
    //     0x837c0c: ldurb           w16, [x3, #-1]
    //     0x837c10: ldurb           w17, [x0, #-1]
    //     0x837c14: and             x16, x17, x16, lsr #2
    //     0x837c18: tst             x16, HEAP, lsr #32
    //     0x837c1c: b.eq            #0x837c24
    //     0x837c20: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x837c24: ldur            x0, [fp, #-0x10]
    // 0x837c28: StoreField: r3->field_13 = r0
    //     0x837c28: stur            w0, [x3, #0x13]
    //     0x837c2c: ldurb           w16, [x3, #-1]
    //     0x837c30: ldurb           w17, [x0, #-1]
    //     0x837c34: and             x16, x17, x16, lsr #2
    //     0x837c38: tst             x16, HEAP, lsr #32
    //     0x837c3c: b.eq            #0x837c44
    //     0x837c40: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x837c44: LoadField: r1 = r3->field_7
    //     0x837c44: ldur            w1, [x3, #7]
    // 0x837c48: DecompressPointer r1
    //     0x837c48: add             x1, x1, HEAP, lsl #32
    // 0x837c4c: r0 = LoadClassIdInstr(r1)
    //     0x837c4c: ldur            x0, [x1, #-1]
    //     0x837c50: ubfx            x0, x0, #0xc, #0x14
    // 0x837c54: ldur            x2, [fp, #-0x10]
    // 0x837c58: r0 = GDT[cid_x0 + 0xfeb3]()
    //     0x837c58: mov             x17, #0xfeb3
    //     0x837c5c: add             lr, x0, x17
    //     0x837c60: ldr             lr, [x21, lr, lsl #3]
    //     0x837c64: blr             lr
    // 0x837c68: ldur            x1, [fp, #-8]
    // 0x837c6c: LoadField: r0 = r1->field_f
    //     0x837c6c: ldur            w0, [x1, #0xf]
    // 0x837c70: DecompressPointer r0
    //     0x837c70: add             x0, x0, HEAP, lsl #32
    // 0x837c74: cmp             w0, NULL
    // 0x837c78: b.eq            #0x837c90
    // 0x837c7c: LeaveFrame
    //     0x837c7c: mov             SP, fp
    //     0x837c80: ldp             fp, lr, [SP], #0x10
    // 0x837c84: ret
    //     0x837c84: ret             
    // 0x837c88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x837c88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x837c8c: b               #0x837be0
    // 0x837c90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x837c90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ clear(/* No info */) {
    // ** addr: 0x839290, size: 0x18
    // 0x839290: r2 = false
    //     0x839290: add             x2, NULL, #0x30  ; false
    // 0x839294: StoreField: r1->field_b = r2
    //     0x839294: stur            w2, [x1, #0xb]
    // 0x839298: StoreField: r1->field_13 = rNULL
    //     0x839298: stur            NULL, [x1, #0x13]
    // 0x83929c: StoreField: r1->field_f = rNULL
    //     0x83929c: stur            NULL, [x1, #0xf]
    // 0x8392a0: r0 = Null
    //     0x8392a0: mov             x0, NULL
    // 0x8392a4: ret
    //     0x8392a4: ret             
  }
  get _ wasSemanticsBoundary(/* No info */) {
    // ** addr: 0x8392a8, size: 0x38
    // 0x8392a8: LoadField: r2 = r1->field_f
    //     0x8392a8: ldur            w2, [x1, #0xf]
    // 0x8392ac: DecompressPointer r2
    //     0x8392ac: add             x2, x2, HEAP, lsl #32
    // 0x8392b0: cmp             w2, NULL
    // 0x8392b4: b.ne            #0x8392c0
    // 0x8392b8: r1 = Null
    //     0x8392b8: mov             x1, NULL
    // 0x8392bc: b               #0x8392c8
    // 0x8392c0: LoadField: r1 = r2->field_7
    //     0x8392c0: ldur            w1, [x2, #7]
    // 0x8392c4: DecompressPointer r1
    //     0x8392c4: add             x1, x1, HEAP, lsl #32
    // 0x8392c8: cmp             w1, NULL
    // 0x8392cc: b.ne            #0x8392d8
    // 0x8392d0: r0 = false
    //     0x8392d0: add             x0, NULL, #0x30  ; false
    // 0x8392d4: b               #0x8392dc
    // 0x8392d8: mov             x0, x1
    // 0x8392dc: ret
    //     0x8392dc: ret             
  }
  _ updateConfig(/* No info */) {
    // ** addr: 0x88fa6c, size: 0xb8
    // 0x88fa6c: EnterFrame
    //     0x88fa6c: stp             fp, lr, [SP, #-0x10]!
    //     0x88fa70: mov             fp, SP
    // 0x88fa74: AllocStack(0x20)
    //     0x88fa74: sub             SP, SP, #0x20
    // 0x88fa78: SetupParameters(_SemanticsConfigurationProvider this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x88fa78: mov             x0, x2
    //     0x88fa7c: stur            x2, [fp, #-0x10]
    //     0x88fa80: mov             x2, x1
    //     0x88fa84: stur            x1, [fp, #-8]
    // 0x88fa88: CheckStackOverflow
    //     0x88fa88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88fa8c: cmp             SP, x16
    //     0x88fa90: b.ls            #0x88fb18
    // 0x88fa94: LoadField: r1 = r2->field_b
    //     0x88fa94: ldur            w1, [x2, #0xb]
    // 0x88fa98: DecompressPointer r1
    //     0x88fa98: add             x1, x1, HEAP, lsl #32
    // 0x88fa9c: tbz             w1, #4, #0x88fadc
    // 0x88faa0: mov             x1, x2
    // 0x88faa4: r0 = original()
    //     0x88faa4: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x88faa8: mov             x1, x0
    // 0x88faac: r0 = copy()
    //     0x88faac: bl              #0x88fb24  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::copy
    // 0x88fab0: ldur            x1, [fp, #-8]
    // 0x88fab4: StoreField: r1->field_13 = r0
    //     0x88fab4: stur            w0, [x1, #0x13]
    //     0x88fab8: ldurb           w16, [x1, #-1]
    //     0x88fabc: ldurb           w17, [x0, #-1]
    //     0x88fac0: and             x16, x17, x16, lsr #2
    //     0x88fac4: tst             x16, HEAP, lsr #32
    //     0x88fac8: b.eq            #0x88fad0
    //     0x88facc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x88fad0: r0 = true
    //     0x88fad0: add             x0, NULL, #0x20  ; true
    // 0x88fad4: StoreField: r1->field_b = r0
    //     0x88fad4: stur            w0, [x1, #0xb]
    // 0x88fad8: b               #0x88fae0
    // 0x88fadc: mov             x1, x2
    // 0x88fae0: LoadField: r0 = r1->field_13
    //     0x88fae0: ldur            w0, [x1, #0x13]
    // 0x88fae4: DecompressPointer r0
    //     0x88fae4: add             x0, x0, HEAP, lsl #32
    // 0x88fae8: cmp             w0, NULL
    // 0x88faec: b.eq            #0x88fb20
    // 0x88faf0: ldur            x16, [fp, #-0x10]
    // 0x88faf4: stp             x0, x16, [SP]
    // 0x88faf8: ldur            x0, [fp, #-0x10]
    // 0x88fafc: ClosureCall
    //     0x88fafc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x88fb00: ldur            x2, [x0, #0x1f]
    //     0x88fb04: blr             x2
    // 0x88fb08: r0 = Null
    //     0x88fb08: mov             x0, NULL
    // 0x88fb0c: LeaveFrame
    //     0x88fb0c: mov             SP, fp
    //     0x88fb10: ldp             fp, lr, [SP], #0x10
    // 0x88fb14: ret
    //     0x88fb14: ret             
    // 0x88fb18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88fb18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88fb1c: b               #0x88fa94
    // 0x88fb20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x88fb20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ absorbAll(/* No info */) {
    // ** addr: 0x89693c, size: 0x64
    // 0x89693c: EnterFrame
    //     0x89693c: stp             fp, lr, [SP, #-0x10]!
    //     0x896940: mov             fp, SP
    // 0x896944: AllocStack(0x10)
    //     0x896944: sub             SP, SP, #0x10
    // 0x896948: SetupParameters(_SemanticsConfigurationProvider this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x896948: stur            x1, [fp, #-8]
    //     0x89694c: stur            x2, [fp, #-0x10]
    // 0x896950: CheckStackOverflow
    //     0x896950: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896954: cmp             SP, x16
    //     0x896958: b.ls            #0x896998
    // 0x89695c: r1 = 1
    //     0x89695c: mov             x1, #1
    // 0x896960: r0 = AllocateContext()
    //     0x896960: bl              #0x13de838  ; AllocateContextStub
    // 0x896964: mov             x1, x0
    // 0x896968: ldur            x0, [fp, #-0x10]
    // 0x89696c: StoreField: r1->field_f = r0
    //     0x89696c: stur            w0, [x1, #0xf]
    // 0x896970: mov             x2, x1
    // 0x896974: r1 = Function '<anonymous closure>':.
    //     0x896974: ldr             x1, [PP, #0x2b60]  ; [pp+0x2b60] AnonymousClosure: (0x8969a0), in [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::absorbAll (0x89693c)
    // 0x896978: r0 = AllocateClosure()
    //     0x896978: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x89697c: ldur            x1, [fp, #-8]
    // 0x896980: mov             x2, x0
    // 0x896984: r0 = updateConfig()
    //     0x896984: bl              #0x88fa6c  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::updateConfig
    // 0x896988: r0 = Null
    //     0x896988: mov             x0, NULL
    // 0x89698c: LeaveFrame
    //     0x89698c: mov             SP, fp
    //     0x896990: ldp             fp, lr, [SP], #0x10
    // 0x896994: ret
    //     0x896994: ret             
    // 0x896998: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896998: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89699c: b               #0x89695c
  }
  [closure] void <anonymous closure>(dynamic, SemanticsConfiguration) {
    // ** addr: 0x8969a0, size: 0x60
    // 0x8969a0: EnterFrame
    //     0x8969a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8969a4: mov             fp, SP
    // 0x8969a8: AllocStack(0x8)
    //     0x8969a8: sub             SP, SP, #8
    // 0x8969ac: SetupParameters([dynamic _ /* r0 */])
    //     0x8969ac: ldr             x0, [fp, #0x18]
    //     0x8969b0: ldur            w1, [x0, #0x17]
    //     0x8969b4: add             x1, x1, HEAP, lsl #32
    // 0x8969b8: CheckStackOverflow
    //     0x8969b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8969bc: cmp             SP, x16
    //     0x8969c0: b.ls            #0x8969f8
    // 0x8969c4: LoadField: r0 = r1->field_f
    //     0x8969c4: ldur            w0, [x1, #0xf]
    // 0x8969c8: DecompressPointer r0
    //     0x8969c8: add             x0, x0, HEAP, lsl #32
    // 0x8969cc: ldr             x2, [fp, #0x10]
    // 0x8969d0: stur            x0, [fp, #-8]
    // 0x8969d4: r1 = Function 'absorb':.
    //     0x8969d4: ldr             x1, [PP, #0x2b68]  ; [pp+0x2b68] AnonymousClosure: (0x894934), in [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::absorb (0x8940a0)
    // 0x8969d8: r0 = AllocateClosure()
    //     0x8969d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8969dc: ldur            x1, [fp, #-8]
    // 0x8969e0: mov             x2, x0
    // 0x8969e4: r0 = forEach()
    //     0x8969e4: bl              #0xaffee4  ; [dart:core] Iterable::forEach
    // 0x8969e8: r0 = Null
    //     0x8969e8: mov             x0, NULL
    // 0x8969ec: LeaveFrame
    //     0x8969ec: mov             SP, fp
    //     0x8969f0: ldp             fp, lr, [SP], #0x10
    // 0x8969f4: ret
    //     0x8969f4: ret             
    // 0x8969f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8969f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8969fc: b               #0x8969c4
  }
  _ reset(/* No info */) {
    // ** addr: 0x8982c8, size: 0x68
    // 0x8982c8: EnterFrame
    //     0x8982c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8982cc: mov             fp, SP
    // 0x8982d0: AllocStack(0x8)
    //     0x8982d0: sub             SP, SP, #8
    // 0x8982d4: SetupParameters(_SemanticsConfigurationProvider this /* r1 => r0, fp-0x8 */)
    //     0x8982d4: mov             x0, x1
    //     0x8982d8: stur            x1, [fp, #-8]
    // 0x8982dc: CheckStackOverflow
    //     0x8982dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8982e0: cmp             SP, x16
    //     0x8982e4: b.ls            #0x898328
    // 0x8982e8: mov             x1, x0
    // 0x8982ec: r0 = original()
    //     0x8982ec: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x8982f0: ldur            x1, [fp, #-8]
    // 0x8982f4: StoreField: r1->field_13 = r0
    //     0x8982f4: stur            w0, [x1, #0x13]
    //     0x8982f8: ldurb           w16, [x1, #-1]
    //     0x8982fc: ldurb           w17, [x0, #-1]
    //     0x898300: and             x16, x17, x16, lsr #2
    //     0x898304: tst             x16, HEAP, lsr #32
    //     0x898308: b.eq            #0x898310
    //     0x89830c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x898310: r2 = false
    //     0x898310: add             x2, NULL, #0x30  ; false
    // 0x898314: StoreField: r1->field_b = r2
    //     0x898314: stur            w2, [x1, #0xb]
    // 0x898318: r0 = Null
    //     0x898318: mov             x0, NULL
    // 0x89831c: LeaveFrame
    //     0x89831c: mov             SP, fp
    //     0x898320: ldp             fp, lr, [SP], #0x10
    // 0x898324: ret
    //     0x898324: ret             
    // 0x898328: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x898328: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89832c: b               #0x8982e8
  }
}

// class id: 2862, size: 0x20, field offset: 0x8
//   const constructor, 
class _SemanticsParentData extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0x114c8ac, size: 0xd0
    // 0x114c8ac: EnterFrame
    //     0x114c8ac: stp             fp, lr, [SP, #-0x10]!
    //     0x114c8b0: mov             fp, SP
    // 0x114c8b4: AllocStack(0x38)
    //     0x114c8b4: sub             SP, SP, #0x38
    // 0x114c8b8: CheckStackOverflow
    //     0x114c8b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114c8bc: cmp             SP, x16
    //     0x114c8c0: b.ls            #0x114c974
    // 0x114c8c4: ldr             x0, [fp, #0x10]
    // 0x114c8c8: LoadField: r2 = r0->field_7
    //     0x114c8c8: ldur            w2, [x0, #7]
    // 0x114c8cc: DecompressPointer r2
    //     0x114c8cc: add             x2, x2, HEAP, lsl #32
    // 0x114c8d0: stur            x2, [fp, #-0x20]
    // 0x114c8d4: LoadField: r3 = r0->field_b
    //     0x114c8d4: ldur            w3, [x0, #0xb]
    // 0x114c8d8: DecompressPointer r3
    //     0x114c8d8: add             x3, x3, HEAP, lsl #32
    // 0x114c8dc: stur            x3, [fp, #-0x18]
    // 0x114c8e0: LoadField: r4 = r0->field_13
    //     0x114c8e0: ldur            w4, [x0, #0x13]
    // 0x114c8e4: DecompressPointer r4
    //     0x114c8e4: add             x4, x4, HEAP, lsl #32
    // 0x114c8e8: stur            x4, [fp, #-0x10]
    // 0x114c8ec: LoadField: r5 = r0->field_1b
    //     0x114c8ec: ldur            w5, [x0, #0x1b]
    // 0x114c8f0: DecompressPointer r5
    //     0x114c8f0: add             x5, x5, HEAP, lsl #32
    // 0x114c8f4: stur            x5, [fp, #-8]
    // 0x114c8f8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x114c8f8: ldur            w1, [x0, #0x17]
    // 0x114c8fc: DecompressPointer r1
    //     0x114c8fc: add             x1, x1, HEAP, lsl #32
    // 0x114c900: cmp             w1, NULL
    // 0x114c904: b.ne            #0x114c910
    // 0x114c908: r1 = _ConstSet len:0
    //     0x114c908: add             x1, PP, #0xe, lsl #12  ; [pp+0xe2f8] Set<SemanticsTag>(0)
    //     0x114c90c: ldr             x1, [x1, #0x2f8]
    // 0x114c910: r0 = hashAllUnordered()
    //     0x114c910: bl              #0x114c97c  ; [dart:core] Object::hashAllUnordered
    // 0x114c914: mov             x2, x0
    // 0x114c918: r0 = BoxInt64Instr(r2)
    //     0x114c918: sbfiz           x0, x2, #1, #0x1f
    //     0x114c91c: cmp             x2, x0, asr #1
    //     0x114c920: b.eq            #0x114c92c
    //     0x114c924: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c928: stur            x2, [x0, #7]
    // 0x114c92c: ldur            x16, [fp, #-0x10]
    // 0x114c930: ldur            lr, [fp, #-8]
    // 0x114c934: stp             lr, x16, [SP, #8]
    // 0x114c938: str             x0, [SP]
    // 0x114c93c: ldur            x1, [fp, #-0x20]
    // 0x114c940: ldur            x2, [fp, #-0x18]
    // 0x114c944: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x114c944: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x114c948: ldr             x4, [x4, #0xc80]
    // 0x114c94c: r0 = hash()
    //     0x114c94c: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114c950: mov             x2, x0
    // 0x114c954: r0 = BoxInt64Instr(r2)
    //     0x114c954: sbfiz           x0, x2, #1, #0x1f
    //     0x114c958: cmp             x2, x0, asr #1
    //     0x114c95c: b.eq            #0x114c968
    //     0x114c960: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c964: stur            x2, [x0, #7]
    // 0x114c968: LeaveFrame
    //     0x114c968: mov             SP, fp
    //     0x114c96c: ldp             fp, lr, [SP], #0x10
    // 0x114c970: ret
    //     0x114c970: ret             
    // 0x114c974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114c974: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114c978: b               #0x114c8c4
  }
  _ ==(/* No info */) {
    // ** addr: 0x129a118, size: 0x110
    // 0x129a118: EnterFrame
    //     0x129a118: stp             fp, lr, [SP, #-0x10]!
    //     0x129a11c: mov             fp, SP
    // 0x129a120: AllocStack(0x18)
    //     0x129a120: sub             SP, SP, #0x18
    // 0x129a124: CheckStackOverflow
    //     0x129a124: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129a128: cmp             SP, x16
    //     0x129a12c: b.ls            #0x129a220
    // 0x129a130: ldr             x1, [fp, #0x10]
    // 0x129a134: cmp             w1, NULL
    // 0x129a138: b.ne            #0x129a14c
    // 0x129a13c: r0 = false
    //     0x129a13c: add             x0, NULL, #0x30  ; false
    // 0x129a140: LeaveFrame
    //     0x129a140: mov             SP, fp
    //     0x129a144: ldp             fp, lr, [SP], #0x10
    // 0x129a148: ret
    //     0x129a148: ret             
    // 0x129a14c: r0 = 60
    //     0x129a14c: mov             x0, #0x3c
    // 0x129a150: branchIfSmi(r1, 0x129a15c)
    //     0x129a150: tbz             w1, #0, #0x129a15c
    // 0x129a154: r0 = LoadClassIdInstr(r1)
    //     0x129a154: ldur            x0, [x1, #-1]
    //     0x129a158: ubfx            x0, x0, #0xc, #0x14
    // 0x129a15c: cmp             x0, #0xb2e
    // 0x129a160: b.ne            #0x129a210
    // 0x129a164: ldr             x2, [fp, #0x18]
    // 0x129a168: LoadField: r0 = r1->field_7
    //     0x129a168: ldur            w0, [x1, #7]
    // 0x129a16c: DecompressPointer r0
    //     0x129a16c: add             x0, x0, HEAP, lsl #32
    // 0x129a170: LoadField: r3 = r2->field_7
    //     0x129a170: ldur            w3, [x2, #7]
    // 0x129a174: DecompressPointer r3
    //     0x129a174: add             x3, x3, HEAP, lsl #32
    // 0x129a178: cmp             w0, w3
    // 0x129a17c: b.ne            #0x129a210
    // 0x129a180: LoadField: r0 = r1->field_b
    //     0x129a180: ldur            w0, [x1, #0xb]
    // 0x129a184: DecompressPointer r0
    //     0x129a184: add             x0, x0, HEAP, lsl #32
    // 0x129a188: LoadField: r3 = r2->field_b
    //     0x129a188: ldur            w3, [x2, #0xb]
    // 0x129a18c: DecompressPointer r3
    //     0x129a18c: add             x3, x3, HEAP, lsl #32
    // 0x129a190: cmp             w0, w3
    // 0x129a194: b.ne            #0x129a210
    // 0x129a198: LoadField: r0 = r1->field_13
    //     0x129a198: ldur            w0, [x1, #0x13]
    // 0x129a19c: DecompressPointer r0
    //     0x129a19c: add             x0, x0, HEAP, lsl #32
    // 0x129a1a0: LoadField: r3 = r2->field_13
    //     0x129a1a0: ldur            w3, [x2, #0x13]
    // 0x129a1a4: DecompressPointer r3
    //     0x129a1a4: add             x3, x3, HEAP, lsl #32
    // 0x129a1a8: cmp             w0, w3
    // 0x129a1ac: b.ne            #0x129a210
    // 0x129a1b0: LoadField: r0 = r1->field_1b
    //     0x129a1b0: ldur            w0, [x1, #0x1b]
    // 0x129a1b4: DecompressPointer r0
    //     0x129a1b4: add             x0, x0, HEAP, lsl #32
    // 0x129a1b8: LoadField: r3 = r2->field_1b
    //     0x129a1b8: ldur            w3, [x2, #0x1b]
    // 0x129a1bc: DecompressPointer r3
    //     0x129a1bc: add             x3, x3, HEAP, lsl #32
    // 0x129a1c0: r4 = LoadClassIdInstr(r0)
    //     0x129a1c0: ldur            x4, [x0, #-1]
    //     0x129a1c4: ubfx            x4, x4, #0xc, #0x14
    // 0x129a1c8: stp             x3, x0, [SP]
    // 0x129a1cc: mov             x0, x4
    // 0x129a1d0: mov             lr, x0
    // 0x129a1d4: ldr             lr, [x21, lr, lsl #3]
    // 0x129a1d8: blr             lr
    // 0x129a1dc: tbnz            w0, #4, #0x129a210
    // 0x129a1e0: ldr             x1, [fp, #0x18]
    // 0x129a1e4: ldr             x0, [fp, #0x10]
    // 0x129a1e8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x129a1e8: ldur            w2, [x0, #0x17]
    // 0x129a1ec: DecompressPointer r2
    //     0x129a1ec: add             x2, x2, HEAP, lsl #32
    // 0x129a1f0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x129a1f0: ldur            w0, [x1, #0x17]
    // 0x129a1f4: DecompressPointer r0
    //     0x129a1f4: add             x0, x0, HEAP, lsl #32
    // 0x129a1f8: r16 = <SemanticsTag>
    //     0x129a1f8: ldr             x16, [PP, #0x2690]  ; [pp+0x2690] TypeArguments: <SemanticsTag>
    // 0x129a1fc: stp             x2, x16, [SP, #8]
    // 0x129a200: str             x0, [SP]
    // 0x129a204: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x129a204: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x129a208: r0 = setEquals()
    //     0x129a208: bl              #0x86d470  ; [package:flutter/src/foundation/collections.dart] ::setEquals
    // 0x129a20c: b               #0x129a214
    // 0x129a210: r0 = false
    //     0x129a210: add             x0, NULL, #0x30  ; false
    // 0x129a214: LeaveFrame
    //     0x129a214: mov             SP, fp
    //     0x129a218: ldp             fp, lr, [SP], #0x10
    // 0x129a21c: ret
    //     0x129a21c: ret             
    // 0x129a220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129a220: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129a224: b               #0x129a130
  }
}

// class id: 2884, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Constraints extends Object {
}

// class id: 2888, size: 0x8, field offset: 0x8
abstract class PipelineManifold extends Object
    implements Listenable {
}

// class id: 2948, size: 0x1c, field offset: 0x8
class PaintingContext extends ClipContext {

  static _ updateLayerProperties(/* No info */) {
    // ** addr: 0x89a1bc, size: 0xc0
    // 0x89a1bc: EnterFrame
    //     0x89a1bc: stp             fp, lr, [SP, #-0x10]!
    //     0x89a1c0: mov             fp, SP
    // 0x89a1c4: AllocStack(0x10)
    //     0x89a1c4: sub             SP, SP, #0x10
    // 0x89a1c8: SetupParameters(dynamic _ /* r1 => r3, fp-0x10 */)
    //     0x89a1c8: mov             x3, x1
    //     0x89a1cc: stur            x1, [fp, #-0x10]
    // 0x89a1d0: CheckStackOverflow
    //     0x89a1d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a1d4: cmp             SP, x16
    //     0x89a1d8: b.ls            #0x89a270
    // 0x89a1dc: LoadField: r0 = r3->field_2f
    //     0x89a1dc: ldur            w0, [x3, #0x2f]
    // 0x89a1e0: DecompressPointer r0
    //     0x89a1e0: add             x0, x0, HEAP, lsl #32
    // 0x89a1e4: LoadField: r4 = r0->field_b
    //     0x89a1e4: ldur            w4, [x0, #0xb]
    // 0x89a1e8: DecompressPointer r4
    //     0x89a1e8: add             x4, x4, HEAP, lsl #32
    // 0x89a1ec: stur            x4, [fp, #-8]
    // 0x89a1f0: cmp             w4, NULL
    // 0x89a1f4: b.eq            #0x89a278
    // 0x89a1f8: mov             x0, x4
    // 0x89a1fc: r2 = Null
    //     0x89a1fc: mov             x2, NULL
    // 0x89a200: r1 = Null
    //     0x89a200: mov             x1, NULL
    // 0x89a204: r4 = LoadClassIdInstr(r0)
    //     0x89a204: ldur            x4, [x0, #-1]
    //     0x89a208: ubfx            x4, x4, #0xc, #0x14
    // 0x89a20c: r17 = -4660
    //     0x89a20c: mov             x17, #-0x1234
    // 0x89a210: add             x4, x4, x17
    // 0x89a214: cmp             x4, #3
    // 0x89a218: b.ls            #0x89a22c
    // 0x89a21c: r8 = OffsetLayer
    //     0x89a21c: ldr             x8, [PP, #0x2cf8]  ; [pp+0x2cf8] Type: OffsetLayer
    // 0x89a220: r3 = Null
    //     0x89a220: add             x3, PP, #0xd, lsl #12  ; [pp+0xdec0] Null
    //     0x89a224: ldr             x3, [x3, #0xec0]
    // 0x89a228: r0 = DefaultTypeTest()
    //     0x89a228: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x89a22c: ldur            x3, [fp, #-0x10]
    // 0x89a230: r0 = LoadClassIdInstr(r3)
    //     0x89a230: ldur            x0, [x3, #-1]
    //     0x89a234: ubfx            x0, x0, #0xc, #0x14
    // 0x89a238: mov             x1, x3
    // 0x89a23c: ldur            x2, [fp, #-8]
    // 0x89a240: r0 = GDT[cid_x0 + 0x10e9d]()
    //     0x89a240: mov             x17, #0xe9d
    //     0x89a244: movk            x17, #1, lsl #16
    //     0x89a248: add             lr, x0, x17
    //     0x89a24c: ldr             lr, [x21, lr, lsl #3]
    //     0x89a250: blr             lr
    // 0x89a254: ldur            x1, [fp, #-0x10]
    // 0x89a258: r2 = false
    //     0x89a258: add             x2, NULL, #0x30  ; false
    // 0x89a25c: StoreField: r1->field_3f = r2
    //     0x89a25c: stur            w2, [x1, #0x3f]
    // 0x89a260: r0 = Null
    //     0x89a260: mov             x0, NULL
    // 0x89a264: LeaveFrame
    //     0x89a264: mov             SP, fp
    //     0x89a268: ldp             fp, lr, [SP], #0x10
    // 0x89a26c: ret
    //     0x89a26c: ret             
    // 0x89a270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a270: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a274: b               #0x89a1dc
    // 0x89a278: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89a278: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _repaintCompositedChild(/* No info */) {
    // ** addr: 0x89a370, size: 0x16c
    // 0x89a370: EnterFrame
    //     0x89a370: stp             fp, lr, [SP, #-0x10]!
    //     0x89a374: mov             fp, SP
    // 0x89a378: AllocStack(0x20)
    //     0x89a378: sub             SP, SP, #0x20
    // 0x89a37c: SetupParameters(dynamic _ /* r1 => r3, fp-0x18 */)
    //     0x89a37c: mov             x3, x1
    //     0x89a380: stur            x1, [fp, #-0x18]
    // 0x89a384: CheckStackOverflow
    //     0x89a384: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a388: cmp             SP, x16
    //     0x89a38c: b.ls            #0x89a4d4
    // 0x89a390: LoadField: r4 = r3->field_2f
    //     0x89a390: ldur            w4, [x3, #0x2f]
    // 0x89a394: DecompressPointer r4
    //     0x89a394: add             x4, x4, HEAP, lsl #32
    // 0x89a398: stur            x4, [fp, #-0x10]
    // 0x89a39c: LoadField: r5 = r4->field_b
    //     0x89a39c: ldur            w5, [x4, #0xb]
    // 0x89a3a0: DecompressPointer r5
    //     0x89a3a0: add             x5, x5, HEAP, lsl #32
    // 0x89a3a4: mov             x0, x5
    // 0x89a3a8: stur            x5, [fp, #-8]
    // 0x89a3ac: r2 = Null
    //     0x89a3ac: mov             x2, NULL
    // 0x89a3b0: r1 = Null
    //     0x89a3b0: mov             x1, NULL
    // 0x89a3b4: r4 = LoadClassIdInstr(r0)
    //     0x89a3b4: ldur            x4, [x0, #-1]
    //     0x89a3b8: ubfx            x4, x4, #0xc, #0x14
    // 0x89a3bc: r17 = -4660
    //     0x89a3bc: mov             x17, #-0x1234
    // 0x89a3c0: add             x4, x4, x17
    // 0x89a3c4: cmp             x4, #3
    // 0x89a3c8: b.ls            #0x89a3d8
    // 0x89a3cc: r8 = OffsetLayer?
    //     0x89a3cc: ldr             x8, [PP, #0x2d20]  ; [pp+0x2d20] Type: OffsetLayer?
    // 0x89a3d0: r3 = Null
    //     0x89a3d0: ldr             x3, [PP, #0x2d28]  ; [pp+0x2d28] Null
    // 0x89a3d4: r0 = DefaultNullableTypeTest()
    //     0x89a3d4: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x89a3d8: ldur            x0, [fp, #-8]
    // 0x89a3dc: cmp             w0, NULL
    // 0x89a3e0: b.ne            #0x89a424
    // 0x89a3e4: ldur            x3, [fp, #-0x18]
    // 0x89a3e8: r0 = LoadClassIdInstr(r3)
    //     0x89a3e8: ldur            x0, [x3, #-1]
    //     0x89a3ec: ubfx            x0, x0, #0xc, #0x14
    // 0x89a3f0: mov             x1, x3
    // 0x89a3f4: r2 = Null
    //     0x89a3f4: mov             x2, NULL
    // 0x89a3f8: r0 = GDT[cid_x0 + 0x10e9d]()
    //     0x89a3f8: mov             x17, #0xe9d
    //     0x89a3fc: movk            x17, #1, lsl #16
    //     0x89a400: add             lr, x0, x17
    //     0x89a404: ldr             lr, [x21, lr, lsl #3]
    //     0x89a408: blr             lr
    // 0x89a40c: ldur            x1, [fp, #-0x10]
    // 0x89a410: mov             x2, x0
    // 0x89a414: stur            x0, [fp, #-0x10]
    // 0x89a418: r0 = layer=()
    //     0x89a418: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x89a41c: ldur            x3, [fp, #-0x10]
    // 0x89a420: b               #0x89a45c
    // 0x89a424: ldur            x2, [fp, #-0x18]
    // 0x89a428: mov             x1, x0
    // 0x89a42c: r0 = removeAllChildren()
    //     0x89a42c: bl              #0x89ad4c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::removeAllChildren
    // 0x89a430: ldur            x3, [fp, #-0x18]
    // 0x89a434: r0 = LoadClassIdInstr(r3)
    //     0x89a434: ldur            x0, [x3, #-1]
    //     0x89a438: ubfx            x0, x0, #0xc, #0x14
    // 0x89a43c: mov             x1, x3
    // 0x89a440: ldur            x2, [fp, #-8]
    // 0x89a444: r0 = GDT[cid_x0 + 0x10e9d]()
    //     0x89a444: mov             x17, #0xe9d
    //     0x89a448: movk            x17, #1, lsl #16
    //     0x89a44c: add             lr, x0, x17
    //     0x89a450: ldr             lr, [x21, lr, lsl #3]
    //     0x89a454: blr             lr
    // 0x89a458: ldur            x3, [fp, #-8]
    // 0x89a45c: ldur            x2, [fp, #-0x18]
    // 0x89a460: r0 = false
    //     0x89a460: add             x0, NULL, #0x30  ; false
    // 0x89a464: stur            x3, [fp, #-8]
    // 0x89a468: StoreField: r2->field_3f = r0
    //     0x89a468: stur            w0, [x2, #0x3f]
    // 0x89a46c: r0 = LoadClassIdInstr(r2)
    //     0x89a46c: ldur            x0, [x2, #-1]
    //     0x89a470: ubfx            x0, x0, #0xc, #0x14
    // 0x89a474: mov             x1, x2
    // 0x89a478: r0 = GDT[cid_x0 + 0x107cb]()
    //     0x89a478: mov             x17, #0x7cb
    //     0x89a47c: movk            x17, #1, lsl #16
    //     0x89a480: add             lr, x0, x17
    //     0x89a484: ldr             lr, [x21, lr, lsl #3]
    //     0x89a488: blr             lr
    // 0x89a48c: stur            x0, [fp, #-0x10]
    // 0x89a490: r0 = PaintingContext()
    //     0x89a490: bl              #0x89ad40  ; AllocatePaintingContextStub -> PaintingContext (size=0x1c)
    // 0x89a494: mov             x4, x0
    // 0x89a498: ldur            x0, [fp, #-8]
    // 0x89a49c: stur            x4, [fp, #-0x20]
    // 0x89a4a0: StoreField: r4->field_7 = r0
    //     0x89a4a0: stur            w0, [x4, #7]
    // 0x89a4a4: ldur            x0, [fp, #-0x10]
    // 0x89a4a8: StoreField: r4->field_b = r0
    //     0x89a4a8: stur            w0, [x4, #0xb]
    // 0x89a4ac: ldur            x1, [fp, #-0x18]
    // 0x89a4b0: mov             x2, x4
    // 0x89a4b4: r3 = Instance_Offset
    //     0x89a4b4: ldr             x3, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x89a4b8: r0 = _paintWithContext()
    //     0x89a4b8: bl              #0x89a9d4  ; [package:flutter/src/rendering/object.dart] RenderObject::_paintWithContext
    // 0x89a4bc: ldur            x1, [fp, #-0x20]
    // 0x89a4c0: r0 = stopRecordingIfNeeded()
    //     0x89a4c0: bl              #0x89a4dc  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0x89a4c4: r0 = Null
    //     0x89a4c4: mov             x0, NULL
    // 0x89a4c8: LeaveFrame
    //     0x89a4c8: mov             SP, fp
    //     0x89a4cc: ldp             fp, lr, [SP], #0x10
    // 0x89a4d0: ret
    //     0x89a4d0: ret             
    // 0x89a4d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a4d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a4d8: b               #0x89a390
  }
  _ stopRecordingIfNeeded(/* No info */) {
    // ** addr: 0x89a4dc, size: 0xa4
    // 0x89a4dc: EnterFrame
    //     0x89a4dc: stp             fp, lr, [SP, #-0x10]!
    //     0x89a4e0: mov             fp, SP
    // 0x89a4e4: AllocStack(0x10)
    //     0x89a4e4: sub             SP, SP, #0x10
    // 0x89a4e8: SetupParameters(PaintingContext this /* r1 => r0, fp-0x10 */)
    //     0x89a4e8: mov             x0, x1
    //     0x89a4ec: stur            x1, [fp, #-0x10]
    // 0x89a4f0: CheckStackOverflow
    //     0x89a4f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a4f4: cmp             SP, x16
    //     0x89a4f8: b.ls            #0x89a570
    // 0x89a4fc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89a4fc: ldur            w1, [x0, #0x17]
    // 0x89a500: DecompressPointer r1
    //     0x89a500: add             x1, x1, HEAP, lsl #32
    // 0x89a504: cmp             w1, NULL
    // 0x89a508: b.ne            #0x89a51c
    // 0x89a50c: r0 = Null
    //     0x89a50c: mov             x0, NULL
    // 0x89a510: LeaveFrame
    //     0x89a510: mov             SP, fp
    //     0x89a514: ldp             fp, lr, [SP], #0x10
    // 0x89a518: ret
    //     0x89a518: ret             
    // 0x89a51c: LoadField: r2 = r0->field_f
    //     0x89a51c: ldur            w2, [x0, #0xf]
    // 0x89a520: DecompressPointer r2
    //     0x89a520: add             x2, x2, HEAP, lsl #32
    // 0x89a524: stur            x2, [fp, #-8]
    // 0x89a528: cmp             w2, NULL
    // 0x89a52c: b.eq            #0x89a578
    // 0x89a530: LoadField: r1 = r0->field_13
    //     0x89a530: ldur            w1, [x0, #0x13]
    // 0x89a534: DecompressPointer r1
    //     0x89a534: add             x1, x1, HEAP, lsl #32
    // 0x89a538: cmp             w1, NULL
    // 0x89a53c: b.eq            #0x89a57c
    // 0x89a540: r0 = endRecording()
    //     0x89a540: bl              #0x89a738  ; [dart:ui] _NativePictureRecorder::endRecording
    // 0x89a544: ldur            x1, [fp, #-8]
    // 0x89a548: mov             x2, x0
    // 0x89a54c: r0 = picture=()
    //     0x89a54c: bl              #0x89a580  ; [package:flutter/src/rendering/layer.dart] PictureLayer::picture=
    // 0x89a550: ldur            x1, [fp, #-0x10]
    // 0x89a554: StoreField: r1->field_f = rNULL
    //     0x89a554: stur            NULL, [x1, #0xf]
    // 0x89a558: StoreField: r1->field_13 = rNULL
    //     0x89a558: stur            NULL, [x1, #0x13]
    // 0x89a55c: ArrayStore: r1[0] = rNULL  ; List_4
    //     0x89a55c: stur            NULL, [x1, #0x17]
    // 0x89a560: r0 = Null
    //     0x89a560: mov             x0, NULL
    // 0x89a564: LeaveFrame
    //     0x89a564: mov             SP, fp
    //     0x89a568: ldp             fp, lr, [SP], #0x10
    // 0x89a56c: ret
    //     0x89a56c: ret             
    // 0x89a570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a570: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a574: b               #0x89a4fc
    // 0x89a578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89a578: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x89a57c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89a57c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintChild(/* No info */) {
    // ** addr: 0xc169c4, size: 0xd4
    // 0xc169c4: EnterFrame
    //     0xc169c4: stp             fp, lr, [SP, #-0x10]!
    //     0xc169c8: mov             fp, SP
    // 0xc169cc: AllocStack(0x18)
    //     0xc169cc: sub             SP, SP, #0x18
    // 0xc169d0: SetupParameters(PaintingContext this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc169d0: mov             x4, x1
    //     0xc169d4: stur            x1, [fp, #-8]
    //     0xc169d8: stur            x2, [fp, #-0x10]
    //     0xc169dc: stur            x3, [fp, #-0x18]
    // 0xc169e0: CheckStackOverflow
    //     0xc169e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc169e4: cmp             SP, x16
    //     0xc169e8: b.ls            #0xc16a88
    // 0xc169ec: r0 = LoadClassIdInstr(r2)
    //     0xc169ec: ldur            x0, [x2, #-1]
    //     0xc169f0: ubfx            x0, x0, #0xc, #0x14
    // 0xc169f4: mov             x1, x2
    // 0xc169f8: r0 = GDT[cid_x0 + 0xfd90]()
    //     0xc169f8: mov             x17, #0xfd90
    //     0xc169fc: add             lr, x0, x17
    //     0xc16a00: ldr             lr, [x21, lr, lsl #3]
    //     0xc16a04: blr             lr
    // 0xc16a08: tbnz            w0, #4, #0xc16a28
    // 0xc16a0c: ldur            x1, [fp, #-8]
    // 0xc16a10: r0 = stopRecordingIfNeeded()
    //     0xc16a10: bl              #0x89a4dc  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0xc16a14: ldur            x1, [fp, #-8]
    // 0xc16a18: ldur            x2, [fp, #-0x10]
    // 0xc16a1c: ldur            x3, [fp, #-0x18]
    // 0xc16a20: r0 = _compositeChild()
    //     0xc16a20: bl              #0xc16a98  ; [package:flutter/src/rendering/object.dart] PaintingContext::_compositeChild
    // 0xc16a24: b               #0xc16a78
    // 0xc16a28: ldur            x0, [fp, #-0x10]
    // 0xc16a2c: LoadField: r1 = r0->field_2b
    //     0xc16a2c: ldur            w1, [x0, #0x2b]
    // 0xc16a30: DecompressPointer r1
    //     0xc16a30: add             x1, x1, HEAP, lsl #32
    // 0xc16a34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc16a38: cmp             w1, w16
    // 0xc16a3c: b.eq            #0xc16a90
    // 0xc16a40: tbnz            w1, #4, #0xc16a68
    // 0xc16a44: LoadField: r1 = r0->field_2f
    //     0xc16a44: ldur            w1, [x0, #0x2f]
    // 0xc16a48: DecompressPointer r1
    //     0xc16a48: add             x1, x1, HEAP, lsl #32
    // 0xc16a4c: r2 = Null
    //     0xc16a4c: mov             x2, NULL
    // 0xc16a50: r0 = layer=()
    //     0xc16a50: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc16a54: ldur            x1, [fp, #-0x10]
    // 0xc16a58: ldur            x2, [fp, #-8]
    // 0xc16a5c: ldur            x3, [fp, #-0x18]
    // 0xc16a60: r0 = _paintWithContext()
    //     0xc16a60: bl              #0x89a9d4  ; [package:flutter/src/rendering/object.dart] RenderObject::_paintWithContext
    // 0xc16a64: b               #0xc16a78
    // 0xc16a68: ldur            x1, [fp, #-0x10]
    // 0xc16a6c: ldur            x2, [fp, #-8]
    // 0xc16a70: ldur            x3, [fp, #-0x18]
    // 0xc16a74: r0 = _paintWithContext()
    //     0xc16a74: bl              #0x89a9d4  ; [package:flutter/src/rendering/object.dart] RenderObject::_paintWithContext
    // 0xc16a78: r0 = Null
    //     0xc16a78: mov             x0, NULL
    // 0xc16a7c: LeaveFrame
    //     0xc16a7c: mov             SP, fp
    //     0xc16a80: ldp             fp, lr, [SP], #0x10
    // 0xc16a84: ret
    //     0xc16a84: ret             
    // 0xc16a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16a88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16a8c: b               #0xc169ec
    // 0xc16a90: r9 = _wasRepaintBoundary
    //     0xc16a90: ldr             x9, [PP, #0x2dd8]  ; [pp+0x2dd8] Field <RenderObject._wasRepaintBoundary@30266271>: late (offset: 0x2c)
    // 0xc16a94: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc16a94: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _compositeChild(/* No info */) {
    // ** addr: 0xc16a98, size: 0x108
    // 0xc16a98: EnterFrame
    //     0xc16a98: stp             fp, lr, [SP, #-0x10]!
    //     0xc16a9c: mov             fp, SP
    // 0xc16aa0: AllocStack(0x18)
    //     0xc16aa0: sub             SP, SP, #0x18
    // 0xc16aa4: SetupParameters(PaintingContext this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xc16aa4: mov             x0, x2
    //     0xc16aa8: stur            x2, [fp, #-0x10]
    //     0xc16aac: mov             x2, x3
    //     0xc16ab0: stur            x3, [fp, #-0x18]
    //     0xc16ab4: mov             x3, x1
    //     0xc16ab8: stur            x1, [fp, #-8]
    // 0xc16abc: CheckStackOverflow
    //     0xc16abc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16ac0: cmp             SP, x16
    //     0xc16ac4: b.ls            #0xc16b8c
    // 0xc16ac8: LoadField: r1 = r0->field_3b
    //     0xc16ac8: ldur            w1, [x0, #0x3b]
    // 0xc16acc: DecompressPointer r1
    //     0xc16acc: add             x1, x1, HEAP, lsl #32
    // 0xc16ad0: tbz             w1, #4, #0xc16aec
    // 0xc16ad4: LoadField: r1 = r0->field_2b
    //     0xc16ad4: ldur            w1, [x0, #0x2b]
    // 0xc16ad8: DecompressPointer r1
    //     0xc16ad8: add             x1, x1, HEAP, lsl #32
    // 0xc16adc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc16ae0: cmp             w1, w16
    // 0xc16ae4: b.eq            #0xc16b94
    // 0xc16ae8: tbz             w1, #4, #0xc16afc
    // 0xc16aec: mov             x1, x0
    // 0xc16af0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc16af0: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc16af4: r0 = _repaintCompositedChild()
    //     0xc16af4: bl              #0x89a370  ; [package:flutter/src/rendering/object.dart] PaintingContext::_repaintCompositedChild
    // 0xc16af8: b               #0xc16b10
    // 0xc16afc: LoadField: r1 = r0->field_3f
    //     0xc16afc: ldur            w1, [x0, #0x3f]
    // 0xc16b00: DecompressPointer r1
    //     0xc16b00: add             x1, x1, HEAP, lsl #32
    // 0xc16b04: tbnz            w1, #4, #0xc16b10
    // 0xc16b08: mov             x1, x0
    // 0xc16b0c: r0 = updateLayerProperties()
    //     0xc16b0c: bl              #0x89a1bc  ; [package:flutter/src/rendering/object.dart] PaintingContext::updateLayerProperties
    // 0xc16b10: ldur            x0, [fp, #-0x10]
    // 0xc16b14: LoadField: r1 = r0->field_2f
    //     0xc16b14: ldur            w1, [x0, #0x2f]
    // 0xc16b18: DecompressPointer r1
    //     0xc16b18: add             x1, x1, HEAP, lsl #32
    // 0xc16b1c: LoadField: r3 = r1->field_b
    //     0xc16b1c: ldur            w3, [x1, #0xb]
    // 0xc16b20: DecompressPointer r3
    //     0xc16b20: add             x3, x3, HEAP, lsl #32
    // 0xc16b24: stur            x3, [fp, #-0x10]
    // 0xc16b28: cmp             w3, NULL
    // 0xc16b2c: b.eq            #0xc16b9c
    // 0xc16b30: mov             x0, x3
    // 0xc16b34: r2 = Null
    //     0xc16b34: mov             x2, NULL
    // 0xc16b38: r1 = Null
    //     0xc16b38: mov             x1, NULL
    // 0xc16b3c: r4 = LoadClassIdInstr(r0)
    //     0xc16b3c: ldur            x4, [x0, #-1]
    //     0xc16b40: ubfx            x4, x4, #0xc, #0x14
    // 0xc16b44: r17 = -4660
    //     0xc16b44: mov             x17, #-0x1234
    // 0xc16b48: add             x4, x4, x17
    // 0xc16b4c: cmp             x4, #3
    // 0xc16b50: b.ls            #0xc16b64
    // 0xc16b54: r8 = OffsetLayer
    //     0xc16b54: ldr             x8, [PP, #0x2cf8]  ; [pp+0x2cf8] Type: OffsetLayer
    // 0xc16b58: r3 = Null
    //     0xc16b58: add             x3, PP, #0xd, lsl #12  ; [pp+0xdeb0] Null
    //     0xc16b5c: ldr             x3, [x3, #0xeb0]
    // 0xc16b60: r0 = DefaultTypeTest()
    //     0xc16b60: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc16b64: ldur            x1, [fp, #-0x10]
    // 0xc16b68: ldur            x2, [fp, #-0x18]
    // 0xc16b6c: r0 = offset=()
    //     0xc16b6c: bl              #0xc16f8c  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::offset=
    // 0xc16b70: ldur            x1, [fp, #-8]
    // 0xc16b74: ldur            x2, [fp, #-0x10]
    // 0xc16b78: r0 = appendLayer()
    //     0xc16b78: bl              #0xc16ba0  ; [package:flutter/src/rendering/object.dart] PaintingContext::appendLayer
    // 0xc16b7c: r0 = Null
    //     0xc16b7c: mov             x0, NULL
    // 0xc16b80: LeaveFrame
    //     0xc16b80: mov             SP, fp
    //     0xc16b84: ldp             fp, lr, [SP], #0x10
    // 0xc16b88: ret
    //     0xc16b88: ret             
    // 0xc16b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16b8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16b90: b               #0xc16ac8
    // 0xc16b94: r9 = _wasRepaintBoundary
    //     0xc16b94: ldr             x9, [PP, #0x2dd8]  ; [pp+0x2dd8] Field <RenderObject._wasRepaintBoundary@30266271>: late (offset: 0x2c)
    // 0xc16b98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc16b98: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc16b9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc16b9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ appendLayer(/* No info */) {
    // ** addr: 0xc16ba0, size: 0x5c
    // 0xc16ba0: EnterFrame
    //     0xc16ba0: stp             fp, lr, [SP, #-0x10]!
    //     0xc16ba4: mov             fp, SP
    // 0xc16ba8: AllocStack(0x10)
    //     0xc16ba8: sub             SP, SP, #0x10
    // 0xc16bac: SetupParameters(PaintingContext this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc16bac: mov             x0, x2
    //     0xc16bb0: stur            x2, [fp, #-0x10]
    //     0xc16bb4: mov             x2, x1
    //     0xc16bb8: stur            x1, [fp, #-8]
    // 0xc16bbc: CheckStackOverflow
    //     0xc16bbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16bc0: cmp             SP, x16
    //     0xc16bc4: b.ls            #0xc16bf4
    // 0xc16bc8: mov             x1, x0
    // 0xc16bcc: r0 = remove()
    //     0xc16bcc: bl              #0xc16e3c  ; [package:flutter/src/rendering/layer.dart] Layer::remove
    // 0xc16bd0: ldur            x0, [fp, #-8]
    // 0xc16bd4: LoadField: r1 = r0->field_7
    //     0xc16bd4: ldur            w1, [x0, #7]
    // 0xc16bd8: DecompressPointer r1
    //     0xc16bd8: add             x1, x1, HEAP, lsl #32
    // 0xc16bdc: ldur            x2, [fp, #-0x10]
    // 0xc16be0: r0 = append()
    //     0xc16be0: bl              #0xc16bfc  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::append
    // 0xc16be4: r0 = Null
    //     0xc16be4: mov             x0, NULL
    // 0xc16be8: LeaveFrame
    //     0xc16be8: mov             SP, fp
    //     0xc16bec: ldp             fp, lr, [SP], #0x10
    // 0xc16bf0: ret
    //     0xc16bf0: ret             
    // 0xc16bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16bf4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16bf8: b               #0xc16bc8
  }
  get _ canvas(/* No info */) {
    // ** addr: 0xc17694, size: 0x64
    // 0xc17694: EnterFrame
    //     0xc17694: stp             fp, lr, [SP, #-0x10]!
    //     0xc17698: mov             fp, SP
    // 0xc1769c: AllocStack(0x8)
    //     0xc1769c: sub             SP, SP, #8
    // 0xc176a0: SetupParameters(PaintingContext this /* r1 => r0, fp-0x8 */)
    //     0xc176a0: mov             x0, x1
    //     0xc176a4: stur            x1, [fp, #-8]
    // 0xc176a8: CheckStackOverflow
    //     0xc176a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc176ac: cmp             SP, x16
    //     0xc176b0: b.ls            #0xc176ec
    // 0xc176b4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc176b4: ldur            w1, [x0, #0x17]
    // 0xc176b8: DecompressPointer r1
    //     0xc176b8: add             x1, x1, HEAP, lsl #32
    // 0xc176bc: cmp             w1, NULL
    // 0xc176c0: b.ne            #0xc176cc
    // 0xc176c4: mov             x1, x0
    // 0xc176c8: r0 = _startRecording()
    //     0xc176c8: bl              #0xc176f8  ; [package:flutter/src/rendering/object.dart] PaintingContext::_startRecording
    // 0xc176cc: ldur            x1, [fp, #-8]
    // 0xc176d0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xc176d0: ldur            w0, [x1, #0x17]
    // 0xc176d4: DecompressPointer r0
    //     0xc176d4: add             x0, x0, HEAP, lsl #32
    // 0xc176d8: cmp             w0, NULL
    // 0xc176dc: b.eq            #0xc176f4
    // 0xc176e0: LeaveFrame
    //     0xc176e0: mov             SP, fp
    //     0xc176e4: ldp             fp, lr, [SP], #0x10
    // 0xc176e8: ret
    //     0xc176e8: ret             
    // 0xc176ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc176ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc176f0: b               #0xc176b4
    // 0xc176f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc176f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _startRecording(/* No info */) {
    // ** addr: 0xc176f8, size: 0x118
    // 0xc176f8: EnterFrame
    //     0xc176f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc176fc: mov             fp, SP
    // 0xc17700: AllocStack(0x10)
    //     0xc17700: sub             SP, SP, #0x10
    // 0xc17704: SetupParameters(PaintingContext this /* r1 => r1, fp-0x8 */)
    //     0xc17704: stur            x1, [fp, #-8]
    // 0xc17708: CheckStackOverflow
    //     0xc17708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1770c: cmp             SP, x16
    //     0xc17710: b.ls            #0xc177fc
    // 0xc17714: r0 = PictureLayer()
    //     0xc17714: bl              #0xc1789c  ; AllocatePictureLayerStub -> PictureLayer (size=0x4c)
    // 0xc17718: mov             x2, x0
    // 0xc1771c: r0 = false
    //     0xc1771c: add             x0, NULL, #0x30  ; false
    // 0xc17720: stur            x2, [fp, #-0x10]
    // 0xc17724: StoreField: r2->field_43 = r0
    //     0xc17724: stur            w0, [x2, #0x43]
    // 0xc17728: StoreField: r2->field_47 = r0
    //     0xc17728: stur            w0, [x2, #0x47]
    // 0xc1772c: mov             x1, x2
    // 0xc17730: r0 = Layer()
    //     0xc17730: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc17734: ldur            x0, [fp, #-0x10]
    // 0xc17738: ldur            x2, [fp, #-8]
    // 0xc1773c: StoreField: r2->field_f = r0
    //     0xc1773c: stur            w0, [x2, #0xf]
    //     0xc17740: ldurb           w16, [x2, #-1]
    //     0xc17744: ldurb           w17, [x0, #-1]
    //     0xc17748: and             x16, x17, x16, lsr #2
    //     0xc1774c: tst             x16, HEAP, lsr #32
    //     0xc17750: b.eq            #0xc17758
    //     0xc17754: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc17758: r1 = LoadStaticField(0x7d8)
    //     0xc17758: ldr             x1, [THR, #0x78]  ; THR::field_table_values
    //     0xc1775c: ldr             x1, [x1, #0xfb0]
    // 0xc17760: cmp             w1, NULL
    // 0xc17764: b.eq            #0xc17804
    // 0xc17768: r0 = createPictureRecorder()
    //     0xc17768: bl              #0xc1785c  ; [dart:mixin_deduplication] _MixinApplication207&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding::createPictureRecorder
    // 0xc1776c: mov             x1, x0
    // 0xc17770: ldur            x3, [fp, #-8]
    // 0xc17774: StoreField: r3->field_13 = r0
    //     0xc17774: stur            w0, [x3, #0x13]
    //     0xc17778: ldurb           w16, [x3, #-1]
    //     0xc1777c: ldurb           w17, [x0, #-1]
    //     0xc17780: and             x16, x17, x16, lsr #2
    //     0xc17784: tst             x16, HEAP, lsr #32
    //     0xc17788: b.eq            #0xc17790
    //     0xc1778c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc17790: r0 = LoadStaticField(0x7d8)
    //     0xc17790: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xc17794: ldr             x0, [x0, #0xfb0]
    // 0xc17798: cmp             w0, NULL
    // 0xc1779c: b.eq            #0xc17808
    // 0xc177a0: mov             x2, x1
    // 0xc177a4: mov             x1, x0
    // 0xc177a8: r0 = createCanvas()
    //     0xc177a8: bl              #0xc17810  ; [dart:mixin_deduplication] _MixinApplication207&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding::createCanvas
    // 0xc177ac: ldur            x1, [fp, #-8]
    // 0xc177b0: ArrayStore: r1[0] = r0  ; List_4
    //     0xc177b0: stur            w0, [x1, #0x17]
    //     0xc177b4: ldurb           w16, [x1, #-1]
    //     0xc177b8: ldurb           w17, [x0, #-1]
    //     0xc177bc: and             x16, x17, x16, lsr #2
    //     0xc177c0: tst             x16, HEAP, lsr #32
    //     0xc177c4: b.eq            #0xc177cc
    //     0xc177c8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc177cc: LoadField: r0 = r1->field_7
    //     0xc177cc: ldur            w0, [x1, #7]
    // 0xc177d0: DecompressPointer r0
    //     0xc177d0: add             x0, x0, HEAP, lsl #32
    // 0xc177d4: LoadField: r2 = r1->field_f
    //     0xc177d4: ldur            w2, [x1, #0xf]
    // 0xc177d8: DecompressPointer r2
    //     0xc177d8: add             x2, x2, HEAP, lsl #32
    // 0xc177dc: cmp             w2, NULL
    // 0xc177e0: b.eq            #0xc1780c
    // 0xc177e4: mov             x1, x0
    // 0xc177e8: r0 = append()
    //     0xc177e8: bl              #0xc16bfc  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::append
    // 0xc177ec: r0 = Null
    //     0xc177ec: mov             x0, NULL
    // 0xc177f0: LeaveFrame
    //     0xc177f0: mov             SP, fp
    //     0xc177f4: ldp             fp, lr, [SP], #0x10
    // 0xc177f8: ret
    //     0xc177f8: ret             
    // 0xc177fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc177fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc17800: b               #0xc17714
    // 0xc17804: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc17804: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc17808: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc17808: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1780c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1780c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ pushLayer(/* No info */) {
    // ** addr: 0xc18740, size: 0x118
    // 0xc18740: EnterFrame
    //     0xc18740: stp             fp, lr, [SP, #-0x10]!
    //     0xc18744: mov             fp, SP
    // 0xc18748: AllocStack(0x40)
    //     0xc18748: sub             SP, SP, #0x40
    // 0xc1874c: SetupParameters(PaintingContext this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */, dynamic _ /* r5 => r5, fp-0x28 */, {dynamic childPaintBounds = Null /* r4, fp-0x8 */})
    //     0xc1874c: mov             x0, x3
    //     0xc18750: stur            x3, [fp, #-0x20]
    //     0xc18754: mov             x3, x1
    //     0xc18758: stur            x1, [fp, #-0x10]
    //     0xc1875c: stur            x2, [fp, #-0x18]
    //     0xc18760: stur            x5, [fp, #-0x28]
    //     0xc18764: ldur            w1, [x4, #0x13]
    //     0xc18768: ldur            w6, [x4, #0x1f]
    //     0xc1876c: add             x6, x6, HEAP, lsl #32
    //     0xc18770: add             x16, PP, #0x85, lsl #12  ; [pp+0x854e8] "childPaintBounds"
    //     0xc18774: ldr             x16, [x16, #0x4e8]
    //     0xc18778: cmp             w6, w16
    //     0xc1877c: b.ne            #0xc1879c
    //     0xc18780: ldur            w6, [x4, #0x23]
    //     0xc18784: add             x6, x6, HEAP, lsl #32
    //     0xc18788: sub             w4, w1, w6
    //     0xc1878c: add             x1, fp, w4, sxtw #2
    //     0xc18790: ldr             x1, [x1, #8]
    //     0xc18794: mov             x4, x1
    //     0xc18798: b               #0xc187a0
    //     0xc1879c: mov             x4, NULL
    //     0xc187a0: stur            x4, [fp, #-8]
    // 0xc187a4: CheckStackOverflow
    //     0xc187a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc187a8: cmp             SP, x16
    //     0xc187ac: b.ls            #0xc18850
    // 0xc187b0: LoadField: r1 = r2->field_3f
    //     0xc187b0: ldur            w1, [x2, #0x3f]
    // 0xc187b4: DecompressPointer r1
    //     0xc187b4: add             x1, x1, HEAP, lsl #32
    // 0xc187b8: cmp             w1, NULL
    // 0xc187bc: b.eq            #0xc187c8
    // 0xc187c0: mov             x1, x2
    // 0xc187c4: r0 = removeAllChildren()
    //     0xc187c4: bl              #0x89ad4c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::removeAllChildren
    // 0xc187c8: ldur            x0, [fp, #-8]
    // 0xc187cc: ldur            x1, [fp, #-0x10]
    // 0xc187d0: r0 = stopRecordingIfNeeded()
    //     0xc187d0: bl              #0x89a4dc  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0xc187d4: ldur            x1, [fp, #-0x10]
    // 0xc187d8: ldur            x2, [fp, #-0x18]
    // 0xc187dc: r0 = appendLayer()
    //     0xc187dc: bl              #0xc16ba0  ; [package:flutter/src/rendering/object.dart] PaintingContext::appendLayer
    // 0xc187e0: ldur            x0, [fp, #-8]
    // 0xc187e4: cmp             w0, NULL
    // 0xc187e8: b.ne            #0xc18800
    // 0xc187ec: ldur            x1, [fp, #-0x10]
    // 0xc187f0: LoadField: r0 = r1->field_b
    //     0xc187f0: ldur            w0, [x1, #0xb]
    // 0xc187f4: DecompressPointer r0
    //     0xc187f4: add             x0, x0, HEAP, lsl #32
    // 0xc187f8: mov             x3, x0
    // 0xc187fc: b               #0xc18808
    // 0xc18800: ldur            x1, [fp, #-0x10]
    // 0xc18804: mov             x3, x0
    // 0xc18808: ldur            x2, [fp, #-0x18]
    // 0xc1880c: r0 = createChildContext()
    //     0xc1880c: bl              #0xc18858  ; [package:flutter/src/rendering/object.dart] PaintingContext::createChildContext
    // 0xc18810: mov             x1, x0
    // 0xc18814: stur            x1, [fp, #-8]
    // 0xc18818: ldur            x16, [fp, #-0x20]
    // 0xc1881c: stp             x1, x16, [SP, #8]
    // 0xc18820: ldur            x16, [fp, #-0x28]
    // 0xc18824: str             x16, [SP]
    // 0xc18828: ldur            x0, [fp, #-0x20]
    // 0xc1882c: ClosureCall
    //     0xc1882c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc18830: ldur            x2, [x0, #0x1f]
    //     0xc18834: blr             x2
    // 0xc18838: ldur            x1, [fp, #-8]
    // 0xc1883c: r0 = stopRecordingIfNeeded()
    //     0xc1883c: bl              #0x89a4dc  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0xc18840: r0 = Null
    //     0xc18840: mov             x0, NULL
    // 0xc18844: LeaveFrame
    //     0xc18844: mov             SP, fp
    //     0xc18848: ldp             fp, lr, [SP], #0x10
    // 0xc1884c: ret
    //     0xc1884c: ret             
    // 0xc18850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18854: b               #0xc187b0
  }
  _ createChildContext(/* No info */) {
    // ** addr: 0xc18858, size: 0x34
    // 0xc18858: EnterFrame
    //     0xc18858: stp             fp, lr, [SP, #-0x10]!
    //     0xc1885c: mov             fp, SP
    // 0xc18860: AllocStack(0x10)
    //     0xc18860: sub             SP, SP, #0x10
    // 0xc18864: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xc18864: stur            x2, [fp, #-8]
    //     0xc18868: stur            x3, [fp, #-0x10]
    // 0xc1886c: r0 = PaintingContext()
    //     0xc1886c: bl              #0x89ad40  ; AllocatePaintingContextStub -> PaintingContext (size=0x1c)
    // 0xc18870: ldur            x1, [fp, #-8]
    // 0xc18874: StoreField: r0->field_7 = r1
    //     0xc18874: stur            w1, [x0, #7]
    // 0xc18878: ldur            x1, [fp, #-0x10]
    // 0xc1887c: StoreField: r0->field_b = r1
    //     0xc1887c: stur            w1, [x0, #0xb]
    // 0xc18880: LeaveFrame
    //     0xc18880: mov             SP, fp
    //     0xc18884: ldp             fp, lr, [SP], #0x10
    // 0xc18888: ret
    //     0xc18888: ret             
  }
  _ pushClipRect(/* No info */) {
    // ** addr: 0xc19194, size: 0x240
    // 0xc19194: EnterFrame
    //     0xc19194: stp             fp, lr, [SP, #-0x10]!
    //     0xc19198: mov             fp, SP
    // 0xc1919c: AllocStack(0x58)
    //     0xc1919c: sub             SP, SP, #0x58
    // 0xc191a0: SetupParameters(PaintingContext this /* r1 => r5, fp-0x20 */, dynamic _ /* r5 => r2, fp-0x30 */, [dynamic _ /* r0, fp-0x38 */])
    //     0xc191a0: stur            x1, [fp, #-0x18]
    //     0xc191a4: mov             x16, x5
    //     0xc191a8: mov             x5, x1
    //     0xc191ac: mov             x1, x16
    //     0xc191b0: stur            x2, [fp, #-0x20]
    //     0xc191b4: mov             x16, x3
    //     0xc191b8: mov             x3, x2
    //     0xc191bc: mov             x2, x16
    //     0xc191c0: mov             x0, x6
    //     0xc191c4: stur            x2, [fp, #-0x28]
    //     0xc191c8: stur            x1, [fp, #-0x30]
    //     0xc191cc: stur            x6, [fp, #-0x38]
    // 0xc191d0: LoadField: r6 = r4->field_13
    //     0xc191d0: ldur            w6, [x4, #0x13]
    // 0xc191d4: LoadField: r7 = r4->field_1f
    //     0xc191d4: ldur            w7, [x4, #0x1f]
    // 0xc191d8: DecompressPointer r7
    //     0xc191d8: add             x7, x7, HEAP, lsl #32
    // 0xc191dc: r16 = "clipBehavior"
    //     0xc191dc: add             x16, PP, #0x15, lsl #12  ; [pp+0x15988] "clipBehavior"
    //     0xc191e0: ldr             x16, [x16, #0x988]
    // 0xc191e4: cmp             w7, w16
    // 0xc191e8: b.ne            #0xc1920c
    // 0xc191ec: LoadField: r7 = r4->field_23
    //     0xc191ec: ldur            w7, [x4, #0x23]
    // 0xc191f0: DecompressPointer r7
    //     0xc191f0: add             x7, x7, HEAP, lsl #32
    // 0xc191f4: sub             w8, w6, w7
    // 0xc191f8: add             x7, fp, w8, sxtw #2
    // 0xc191fc: ldr             x7, [x7, #8]
    // 0xc19200: mov             x8, x7
    // 0xc19204: r7 = 1
    //     0xc19204: mov             x7, #1
    // 0xc19208: b               #0xc19218
    // 0xc1920c: r8 = Instance_Clip
    //     0xc1920c: add             x8, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xc19210: ldr             x8, [x8, #0x850]
    // 0xc19214: r7 = 0
    //     0xc19214: mov             x7, #0
    // 0xc19218: stur            x8, [fp, #-0x10]
    // 0xc1921c: lsl             x9, x7, #1
    // 0xc19220: lsl             w7, w9, #1
    // 0xc19224: add             w9, w7, #8
    // 0xc19228: ArrayLoad: r10 = r4[r9]  ; Unknown_4
    //     0xc19228: add             x16, x4, w9, sxtw #1
    //     0xc1922c: ldur            w10, [x16, #0xf]
    // 0xc19230: DecompressPointer r10
    //     0xc19230: add             x10, x10, HEAP, lsl #32
    // 0xc19234: r16 = "oldLayer"
    //     0xc19234: add             x16, PP, #0xd, lsl #12  ; [pp+0xde58] "oldLayer"
    //     0xc19238: ldr             x16, [x16, #0xe58]
    // 0xc1923c: cmp             w10, w16
    // 0xc19240: b.ne            #0xc19268
    // 0xc19244: add             w9, w7, #0xa
    // 0xc19248: ArrayLoad: r7 = r4[r9]  ; Unknown_4
    //     0xc19248: add             x16, x4, w9, sxtw #1
    //     0xc1924c: ldur            w7, [x16, #0xf]
    // 0xc19250: DecompressPointer r7
    //     0xc19250: add             x7, x7, HEAP, lsl #32
    // 0xc19254: sub             w4, w6, w7
    // 0xc19258: add             x6, fp, w4, sxtw #2
    // 0xc1925c: ldr             x6, [x6, #8]
    // 0xc19260: mov             x4, x6
    // 0xc19264: b               #0xc1926c
    // 0xc19268: r4 = Null
    //     0xc19268: mov             x4, NULL
    // 0xc1926c: stur            x4, [fp, #-8]
    // 0xc19270: CheckStackOverflow
    //     0xc19270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19274: cmp             SP, x16
    //     0xc19278: b.ls            #0xc193cc
    // 0xc1927c: r1 = 3
    //     0xc1927c: mov             x1, #3
    // 0xc19280: r0 = AllocateContext()
    //     0xc19280: bl              #0x13de838  ; AllocateContextStub
    // 0xc19284: mov             x3, x0
    // 0xc19288: ldur            x0, [fp, #-0x18]
    // 0xc1928c: stur            x3, [fp, #-0x40]
    // 0xc19290: StoreField: r3->field_f = r0
    //     0xc19290: stur            w0, [x3, #0xf]
    // 0xc19294: ldur            x2, [fp, #-0x28]
    // 0xc19298: StoreField: r3->field_13 = r2
    //     0xc19298: stur            w2, [x3, #0x13]
    // 0xc1929c: ldur            x1, [fp, #-0x38]
    // 0xc192a0: ArrayStore: r3[0] = r1  ; List_4
    //     0xc192a0: stur            w1, [x3, #0x17]
    // 0xc192a4: ldur            x4, [fp, #-0x10]
    // 0xc192a8: r16 = Instance_Clip
    //     0xc192a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc192ac: ldr             x16, [x16, #0x840]
    // 0xc192b0: cmp             w4, w16
    // 0xc192b4: b.ne            #0xc192e0
    // 0xc192b8: stp             x0, x1, [SP, #8]
    // 0xc192bc: str             x2, [SP]
    // 0xc192c0: mov             x0, x1
    // 0xc192c4: ClosureCall
    //     0xc192c4: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc192c8: ldur            x2, [x0, #0x1f]
    //     0xc192cc: blr             x2
    // 0xc192d0: r0 = Null
    //     0xc192d0: mov             x0, NULL
    // 0xc192d4: LeaveFrame
    //     0xc192d4: mov             SP, fp
    //     0xc192d8: ldp             fp, lr, [SP], #0x10
    // 0xc192dc: ret
    //     0xc192dc: ret             
    // 0xc192e0: ldur            x5, [fp, #-0x20]
    // 0xc192e4: ldur            x1, [fp, #-0x30]
    // 0xc192e8: r0 = shift()
    //     0xc192e8: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0xc192ec: mov             x1, x0
    // 0xc192f0: ldur            x0, [fp, #-0x20]
    // 0xc192f4: stur            x1, [fp, #-0x28]
    // 0xc192f8: tbnz            w0, #4, #0xc19394
    // 0xc192fc: ldur            x0, [fp, #-8]
    // 0xc19300: cmp             w0, NULL
    // 0xc19304: b.ne            #0xc19330
    // 0xc19308: r0 = ClipRectLayer()
    //     0xc19308: bl              #0xc19a4c  ; AllocateClipRectLayerStub -> ClipRectLayer (size=0x50)
    // 0xc1930c: mov             x2, x0
    // 0xc19310: r0 = Instance_Clip
    //     0xc19310: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xc19314: ldr             x0, [x0, #0x850]
    // 0xc19318: stur            x2, [fp, #-0x20]
    // 0xc1931c: StoreField: r2->field_4b = r0
    //     0xc1931c: stur            w0, [x2, #0x4b]
    // 0xc19320: mov             x1, x2
    // 0xc19324: r0 = Layer()
    //     0xc19324: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc19328: ldur            x3, [fp, #-0x20]
    // 0xc1932c: b               #0xc19334
    // 0xc19330: mov             x3, x0
    // 0xc19334: ldur            x0, [fp, #-0x40]
    // 0xc19338: mov             x1, x3
    // 0xc1933c: ldur            x2, [fp, #-0x28]
    // 0xc19340: stur            x3, [fp, #-8]
    // 0xc19344: r0 = clipRect=()
    //     0xc19344: bl              #0xc199d4  ; [package:flutter/src/rendering/layer.dart] ClipRectLayer::clipRect=
    // 0xc19348: ldur            x1, [fp, #-8]
    // 0xc1934c: ldur            x2, [fp, #-0x10]
    // 0xc19350: r0 = clipBehavior=()
    //     0xc19350: bl              #0xc19974  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipBehavior=
    // 0xc19354: ldur            x2, [fp, #-0x40]
    // 0xc19358: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xc19358: ldur            w3, [x2, #0x17]
    // 0xc1935c: DecompressPointer r3
    //     0xc1935c: add             x3, x3, HEAP, lsl #32
    // 0xc19360: LoadField: r5 = r2->field_13
    //     0xc19360: ldur            w5, [x2, #0x13]
    // 0xc19364: DecompressPointer r5
    //     0xc19364: add             x5, x5, HEAP, lsl #32
    // 0xc19368: ldur            x16, [fp, #-0x28]
    // 0xc1936c: str             x16, [SP]
    // 0xc19370: ldur            x1, [fp, #-0x18]
    // 0xc19374: ldur            x2, [fp, #-8]
    // 0xc19378: r4 = const [0, 0x5, 0x1, 0x4, childPaintBounds, 0x4, null]
    //     0xc19378: add             x4, PP, #0x85, lsl #12  ; [pp+0x85540] List(7) [0, 0x5, 0x1, 0x4, "childPaintBounds", 0x4, Null]
    //     0xc1937c: ldr             x4, [x4, #0x540]
    // 0xc19380: r0 = pushLayer()
    //     0xc19380: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc19384: ldur            x0, [fp, #-8]
    // 0xc19388: LeaveFrame
    //     0xc19388: mov             SP, fp
    //     0xc1938c: ldp             fp, lr, [SP], #0x10
    // 0xc19390: ret
    //     0xc19390: ret             
    // 0xc19394: ldur            x2, [fp, #-0x40]
    // 0xc19398: r1 = Function '<anonymous closure>':.
    //     0xc19398: add             x1, PP, #0x90, lsl #12  ; [pp+0x90690] AnonymousClosure: (0xc19a58), in [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect (0xc19194)
    //     0xc1939c: ldr             x1, [x1, #0x690]
    // 0xc193a0: r0 = AllocateClosure()
    //     0xc193a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc193a4: ldur            x1, [fp, #-0x18]
    // 0xc193a8: ldur            x2, [fp, #-0x28]
    // 0xc193ac: ldur            x3, [fp, #-0x10]
    // 0xc193b0: ldur            x5, [fp, #-0x28]
    // 0xc193b4: mov             x6, x0
    // 0xc193b8: r0 = clipRectAndPaint()
    //     0xc193b8: bl              #0xc193d4  ; [package:flutter/src/painting/clip.dart] ClipContext::clipRectAndPaint
    // 0xc193bc: r0 = Null
    //     0xc193bc: mov             x0, NULL
    // 0xc193c0: LeaveFrame
    //     0xc193c0: mov             SP, fp
    //     0xc193c4: ldp             fp, lr, [SP], #0x10
    // 0xc193c8: ret
    //     0xc193c8: ret             
    // 0xc193cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc193cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc193d0: b               #0xc1927c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc19a58, size: 0x64
    // 0xc19a58: EnterFrame
    //     0xc19a58: stp             fp, lr, [SP, #-0x10]!
    //     0xc19a5c: mov             fp, SP
    // 0xc19a60: AllocStack(0x18)
    //     0xc19a60: sub             SP, SP, #0x18
    // 0xc19a64: SetupParameters([dynamic _ /* r0 */])
    //     0xc19a64: ldr             x0, [fp, #0x10]
    //     0xc19a68: ldur            w1, [x0, #0x17]
    //     0xc19a6c: add             x1, x1, HEAP, lsl #32
    // 0xc19a70: CheckStackOverflow
    //     0xc19a70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19a74: cmp             SP, x16
    //     0xc19a78: b.ls            #0xc19ab4
    // 0xc19a7c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xc19a7c: ldur            w0, [x1, #0x17]
    // 0xc19a80: DecompressPointer r0
    //     0xc19a80: add             x0, x0, HEAP, lsl #32
    // 0xc19a84: LoadField: r2 = r1->field_f
    //     0xc19a84: ldur            w2, [x1, #0xf]
    // 0xc19a88: DecompressPointer r2
    //     0xc19a88: add             x2, x2, HEAP, lsl #32
    // 0xc19a8c: LoadField: r3 = r1->field_13
    //     0xc19a8c: ldur            w3, [x1, #0x13]
    // 0xc19a90: DecompressPointer r3
    //     0xc19a90: add             x3, x3, HEAP, lsl #32
    // 0xc19a94: stp             x2, x0, [SP, #8]
    // 0xc19a98: str             x3, [SP]
    // 0xc19a9c: ClosureCall
    //     0xc19a9c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc19aa0: ldur            x2, [x0, #0x1f]
    //     0xc19aa4: blr             x2
    // 0xc19aa8: LeaveFrame
    //     0xc19aa8: mov             SP, fp
    //     0xc19aac: ldp             fp, lr, [SP], #0x10
    // 0xc19ab0: ret
    //     0xc19ab0: ret             
    // 0xc19ab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc19ab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19ab8: b               #0xc19a7c
  }
  _ pushClipRRect(/* No info */) {
    // ** addr: 0xc19c70, size: 0x1b8
    // 0xc19c70: EnterFrame
    //     0xc19c70: stp             fp, lr, [SP, #-0x10]!
    //     0xc19c74: mov             fp, SP
    // 0xc19c78: AllocStack(0x50)
    //     0xc19c78: sub             SP, SP, #0x50
    // 0xc19c7c: SetupParameters(PaintingContext this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r2, fp-0x20 */, dynamic _ /* r6 => r1, fp-0x28 */, dynamic _ /* r7 => r0, fp-0x30 */)
    //     0xc19c7c: mov             x4, x2
    //     0xc19c80: stur            x2, [fp, #-0x10]
    //     0xc19c84: mov             x2, x5
    //     0xc19c88: stur            x5, [fp, #-0x20]
    //     0xc19c8c: mov             x5, x1
    //     0xc19c90: stur            x1, [fp, #-8]
    //     0xc19c94: mov             x1, x6
    //     0xc19c98: mov             x0, x7
    //     0xc19c9c: stur            x3, [fp, #-0x18]
    //     0xc19ca0: stur            x6, [fp, #-0x28]
    //     0xc19ca4: stur            x7, [fp, #-0x30]
    // 0xc19ca8: CheckStackOverflow
    //     0xc19ca8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19cac: cmp             SP, x16
    //     0xc19cb0: b.ls            #0xc19e20
    // 0xc19cb4: r1 = 3
    //     0xc19cb4: mov             x1, #3
    // 0xc19cb8: r0 = AllocateContext()
    //     0xc19cb8: bl              #0x13de838  ; AllocateContextStub
    // 0xc19cbc: mov             x3, x0
    // 0xc19cc0: ldur            x0, [fp, #-8]
    // 0xc19cc4: stur            x3, [fp, #-0x38]
    // 0xc19cc8: StoreField: r3->field_f = r0
    //     0xc19cc8: stur            w0, [x3, #0xf]
    // 0xc19ccc: ldur            x2, [fp, #-0x18]
    // 0xc19cd0: StoreField: r3->field_13 = r2
    //     0xc19cd0: stur            w2, [x3, #0x13]
    // 0xc19cd4: ldur            x1, [fp, #-0x30]
    // 0xc19cd8: ArrayStore: r3[0] = r1  ; List_4
    //     0xc19cd8: stur            w1, [x3, #0x17]
    // 0xc19cdc: ldr             x4, [fp, #0x18]
    // 0xc19ce0: r16 = Instance_Clip
    //     0xc19ce0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc19ce4: ldr             x16, [x16, #0x840]
    // 0xc19ce8: cmp             w4, w16
    // 0xc19cec: b.ne            #0xc19d18
    // 0xc19cf0: stp             x0, x1, [SP, #8]
    // 0xc19cf4: str             x2, [SP]
    // 0xc19cf8: mov             x0, x1
    // 0xc19cfc: ClosureCall
    //     0xc19cfc: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc19d00: ldur            x2, [x0, #0x1f]
    //     0xc19d04: blr             x2
    // 0xc19d08: r0 = Null
    //     0xc19d08: mov             x0, NULL
    // 0xc19d0c: LeaveFrame
    //     0xc19d0c: mov             SP, fp
    //     0xc19d10: ldp             fp, lr, [SP], #0x10
    // 0xc19d14: ret
    //     0xc19d14: ret             
    // 0xc19d18: ldur            x5, [fp, #-0x10]
    // 0xc19d1c: ldur            x1, [fp, #-0x20]
    // 0xc19d20: r0 = shift()
    //     0xc19d20: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0xc19d24: mov             x3, x0
    // 0xc19d28: ldur            x0, [fp, #-0x38]
    // 0xc19d2c: stur            x3, [fp, #-0x18]
    // 0xc19d30: LoadField: r2 = r0->field_13
    //     0xc19d30: ldur            w2, [x0, #0x13]
    // 0xc19d34: DecompressPointer r2
    //     0xc19d34: add             x2, x2, HEAP, lsl #32
    // 0xc19d38: ldur            x1, [fp, #-0x28]
    // 0xc19d3c: r0 = shift()
    //     0xc19d3c: bl              #0xb6e004  ; [dart:ui] _RRectLike::shift
    // 0xc19d40: mov             x1, x0
    // 0xc19d44: ldur            x0, [fp, #-0x10]
    // 0xc19d48: stur            x1, [fp, #-0x20]
    // 0xc19d4c: tbnz            w0, #4, #0xc19de8
    // 0xc19d50: ldr             x0, [fp, #0x10]
    // 0xc19d54: cmp             w0, NULL
    // 0xc19d58: b.ne            #0xc19d84
    // 0xc19d5c: r0 = ClipRRectLayer()
    //     0xc19d5c: bl              #0xc1a090  ; AllocateClipRRectLayerStub -> ClipRRectLayer (size=0x50)
    // 0xc19d60: mov             x2, x0
    // 0xc19d64: r0 = Instance_Clip
    //     0xc19d64: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xc19d68: ldr             x0, [x0, #0x6f0]
    // 0xc19d6c: stur            x2, [fp, #-0x10]
    // 0xc19d70: StoreField: r2->field_4b = r0
    //     0xc19d70: stur            w0, [x2, #0x4b]
    // 0xc19d74: mov             x1, x2
    // 0xc19d78: r0 = Layer()
    //     0xc19d78: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc19d7c: ldur            x3, [fp, #-0x10]
    // 0xc19d80: b               #0xc19d88
    // 0xc19d84: mov             x3, x0
    // 0xc19d88: ldur            x0, [fp, #-0x38]
    // 0xc19d8c: mov             x1, x3
    // 0xc19d90: ldur            x2, [fp, #-0x20]
    // 0xc19d94: stur            x3, [fp, #-0x10]
    // 0xc19d98: r0 = clipRSuperellipse=()
    //     0xc19d98: bl              #0xc1a018  ; [package:flutter/src/rendering/layer.dart] ClipRSuperellipseLayer::clipRSuperellipse=
    // 0xc19d9c: ldur            x1, [fp, #-0x10]
    // 0xc19da0: ldr             x2, [fp, #0x18]
    // 0xc19da4: r0 = clipBehavior=()
    //     0xc19da4: bl              #0xc19974  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipBehavior=
    // 0xc19da8: ldur            x2, [fp, #-0x38]
    // 0xc19dac: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xc19dac: ldur            w3, [x2, #0x17]
    // 0xc19db0: DecompressPointer r3
    //     0xc19db0: add             x3, x3, HEAP, lsl #32
    // 0xc19db4: LoadField: r5 = r2->field_13
    //     0xc19db4: ldur            w5, [x2, #0x13]
    // 0xc19db8: DecompressPointer r5
    //     0xc19db8: add             x5, x5, HEAP, lsl #32
    // 0xc19dbc: ldur            x16, [fp, #-0x18]
    // 0xc19dc0: str             x16, [SP]
    // 0xc19dc4: ldur            x1, [fp, #-8]
    // 0xc19dc8: ldur            x2, [fp, #-0x10]
    // 0xc19dcc: r4 = const [0, 0x5, 0x1, 0x4, childPaintBounds, 0x4, null]
    //     0xc19dcc: add             x4, PP, #0x85, lsl #12  ; [pp+0x85540] List(7) [0, 0x5, 0x1, 0x4, "childPaintBounds", 0x4, Null]
    //     0xc19dd0: ldr             x4, [x4, #0x540]
    // 0xc19dd4: r0 = pushLayer()
    //     0xc19dd4: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc19dd8: ldur            x0, [fp, #-0x10]
    // 0xc19ddc: LeaveFrame
    //     0xc19ddc: mov             SP, fp
    //     0xc19de0: ldp             fp, lr, [SP], #0x10
    // 0xc19de4: ret
    //     0xc19de4: ret             
    // 0xc19de8: ldur            x2, [fp, #-0x38]
    // 0xc19dec: r1 = Function '<anonymous closure>':.
    //     0xc19dec: add             x1, PP, #0x90, lsl #12  ; [pp+0x90c08] AnonymousClosure: (0xc19a58), in [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect (0xc19194)
    //     0xc19df0: ldr             x1, [x1, #0xc08]
    // 0xc19df4: r0 = AllocateClosure()
    //     0xc19df4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc19df8: ldur            x1, [fp, #-8]
    // 0xc19dfc: ldur            x2, [fp, #-0x20]
    // 0xc19e00: ldr             x3, [fp, #0x18]
    // 0xc19e04: ldur            x5, [fp, #-0x18]
    // 0xc19e08: mov             x6, x0
    // 0xc19e0c: r0 = clipRRectAndPaint()
    //     0xc19e0c: bl              #0xc19e28  ; [package:flutter/src/painting/clip.dart] ClipContext::clipRRectAndPaint
    // 0xc19e10: r0 = Null
    //     0xc19e10: mov             x0, NULL
    // 0xc19e14: LeaveFrame
    //     0xc19e14: mov             SP, fp
    //     0xc19e18: ldp             fp, lr, [SP], #0x10
    // 0xc19e1c: ret
    //     0xc19e1c: ret             
    // 0xc19e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc19e20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19e24: b               #0xc19cb4
  }
  _ pushClipRSuperellipse(/* No info */) {
    // ** addr: 0xc1a250, size: 0x1b8
    // 0xc1a250: EnterFrame
    //     0xc1a250: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a254: mov             fp, SP
    // 0xc1a258: AllocStack(0x40)
    //     0xc1a258: sub             SP, SP, #0x40
    // 0xc1a25c: SetupParameters(PaintingContext this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */, dynamic _ /* r6 => r1, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0xc1a25c: mov             x4, x1
    //     0xc1a260: mov             x0, x5
    //     0xc1a264: stur            x1, [fp, #-8]
    //     0xc1a268: mov             x1, x6
    //     0xc1a26c: stur            x2, [fp, #-0x10]
    //     0xc1a270: stur            x3, [fp, #-0x18]
    //     0xc1a274: stur            x5, [fp, #-0x20]
    //     0xc1a278: stur            x6, [fp, #-0x28]
    //     0xc1a27c: stur            x7, [fp, #-0x30]
    // 0xc1a280: CheckStackOverflow
    //     0xc1a280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1a284: cmp             SP, x16
    //     0xc1a288: b.ls            #0xc1a400
    // 0xc1a28c: r1 = 3
    //     0xc1a28c: mov             x1, #3
    // 0xc1a290: r0 = AllocateContext()
    //     0xc1a290: bl              #0x13de838  ; AllocateContextStub
    // 0xc1a294: mov             x3, x0
    // 0xc1a298: ldur            x0, [fp, #-8]
    // 0xc1a29c: stur            x3, [fp, #-0x38]
    // 0xc1a2a0: StoreField: r3->field_f = r0
    //     0xc1a2a0: stur            w0, [x3, #0xf]
    // 0xc1a2a4: ldur            x1, [fp, #-0x18]
    // 0xc1a2a8: StoreField: r3->field_13 = r1
    //     0xc1a2a8: stur            w1, [x3, #0x13]
    // 0xc1a2ac: ldur            x2, [fp, #-0x30]
    // 0xc1a2b0: ArrayStore: r3[0] = r2  ; List_4
    //     0xc1a2b0: stur            w2, [x3, #0x17]
    // 0xc1a2b4: ldr             x4, [fp, #0x18]
    // 0xc1a2b8: r16 = Instance_Clip
    //     0xc1a2b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc1a2bc: ldr             x16, [x16, #0x840]
    // 0xc1a2c0: cmp             w4, w16
    // 0xc1a2c4: b.ne            #0xc1a2f4
    // 0xc1a2c8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xc1a2c8: ldur            w3, [x2, #0x17]
    // 0xc1a2cc: DecompressPointer r3
    //     0xc1a2cc: add             x3, x3, HEAP, lsl #32
    // 0xc1a2d0: mov             x16, x1
    // 0xc1a2d4: mov             x1, x3
    // 0xc1a2d8: mov             x3, x16
    // 0xc1a2dc: mov             x2, x0
    // 0xc1a2e0: r0 = paint()
    //     0xc1a2e0: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc1a2e4: r0 = Null
    //     0xc1a2e4: mov             x0, NULL
    // 0xc1a2e8: LeaveFrame
    //     0xc1a2e8: mov             SP, fp
    //     0xc1a2ec: ldp             fp, lr, [SP], #0x10
    // 0xc1a2f0: ret
    //     0xc1a2f0: ret             
    // 0xc1a2f4: ldur            x5, [fp, #-0x10]
    // 0xc1a2f8: mov             x2, x1
    // 0xc1a2fc: ldur            x1, [fp, #-0x20]
    // 0xc1a300: r0 = shift()
    //     0xc1a300: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0xc1a304: mov             x3, x0
    // 0xc1a308: ldur            x0, [fp, #-0x38]
    // 0xc1a30c: stur            x3, [fp, #-0x18]
    // 0xc1a310: LoadField: r2 = r0->field_13
    //     0xc1a310: ldur            w2, [x0, #0x13]
    // 0xc1a314: DecompressPointer r2
    //     0xc1a314: add             x2, x2, HEAP, lsl #32
    // 0xc1a318: ldur            x1, [fp, #-0x28]
    // 0xc1a31c: r0 = shift()
    //     0xc1a31c: bl              #0xb6e004  ; [dart:ui] _RRectLike::shift
    // 0xc1a320: mov             x1, x0
    // 0xc1a324: ldur            x0, [fp, #-0x10]
    // 0xc1a328: stur            x1, [fp, #-0x20]
    // 0xc1a32c: tbnz            w0, #4, #0xc1a3c8
    // 0xc1a330: ldr             x0, [fp, #0x10]
    // 0xc1a334: cmp             w0, NULL
    // 0xc1a338: b.ne            #0xc1a364
    // 0xc1a33c: r0 = ClipRSuperellipseLayer()
    //     0xc1a33c: bl              #0xc1a690  ; AllocateClipRSuperellipseLayerStub -> ClipRSuperellipseLayer (size=0x50)
    // 0xc1a340: mov             x2, x0
    // 0xc1a344: r0 = Instance_Clip
    //     0xc1a344: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xc1a348: ldr             x0, [x0, #0x6f0]
    // 0xc1a34c: stur            x2, [fp, #-0x10]
    // 0xc1a350: StoreField: r2->field_4b = r0
    //     0xc1a350: stur            w0, [x2, #0x4b]
    // 0xc1a354: mov             x1, x2
    // 0xc1a358: r0 = Layer()
    //     0xc1a358: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc1a35c: ldur            x3, [fp, #-0x10]
    // 0xc1a360: b               #0xc1a368
    // 0xc1a364: mov             x3, x0
    // 0xc1a368: ldur            x0, [fp, #-0x38]
    // 0xc1a36c: mov             x1, x3
    // 0xc1a370: ldur            x2, [fp, #-0x20]
    // 0xc1a374: stur            x3, [fp, #-0x10]
    // 0xc1a378: r0 = clipRSuperellipse=()
    //     0xc1a378: bl              #0xc1a018  ; [package:flutter/src/rendering/layer.dart] ClipRSuperellipseLayer::clipRSuperellipse=
    // 0xc1a37c: ldur            x1, [fp, #-0x10]
    // 0xc1a380: ldr             x2, [fp, #0x18]
    // 0xc1a384: r0 = clipBehavior=()
    //     0xc1a384: bl              #0xc19974  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipBehavior=
    // 0xc1a388: ldur            x2, [fp, #-0x38]
    // 0xc1a38c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xc1a38c: ldur            w3, [x2, #0x17]
    // 0xc1a390: DecompressPointer r3
    //     0xc1a390: add             x3, x3, HEAP, lsl #32
    // 0xc1a394: LoadField: r5 = r2->field_13
    //     0xc1a394: ldur            w5, [x2, #0x13]
    // 0xc1a398: DecompressPointer r5
    //     0xc1a398: add             x5, x5, HEAP, lsl #32
    // 0xc1a39c: ldur            x16, [fp, #-0x18]
    // 0xc1a3a0: str             x16, [SP]
    // 0xc1a3a4: ldur            x1, [fp, #-8]
    // 0xc1a3a8: ldur            x2, [fp, #-0x10]
    // 0xc1a3ac: r4 = const [0, 0x5, 0x1, 0x4, childPaintBounds, 0x4, null]
    //     0xc1a3ac: add             x4, PP, #0x85, lsl #12  ; [pp+0x85540] List(7) [0, 0x5, 0x1, 0x4, "childPaintBounds", 0x4, Null]
    //     0xc1a3b0: ldr             x4, [x4, #0x540]
    // 0xc1a3b4: r0 = pushLayer()
    //     0xc1a3b4: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc1a3b8: ldur            x0, [fp, #-0x10]
    // 0xc1a3bc: LeaveFrame
    //     0xc1a3bc: mov             SP, fp
    //     0xc1a3c0: ldp             fp, lr, [SP], #0x10
    // 0xc1a3c4: ret
    //     0xc1a3c4: ret             
    // 0xc1a3c8: ldur            x2, [fp, #-0x38]
    // 0xc1a3cc: r1 = Function '<anonymous closure>':.
    //     0xc1a3cc: add             x1, PP, #0xd1, lsl #12  ; [pp+0xd1e80] AnonymousClosure: (0xc1a69c), in [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRSuperellipse (0xc1a250)
    //     0xc1a3d0: ldr             x1, [x1, #0xe80]
    // 0xc1a3d4: r0 = AllocateClosure()
    //     0xc1a3d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1a3d8: ldur            x1, [fp, #-8]
    // 0xc1a3dc: ldur            x2, [fp, #-0x20]
    // 0xc1a3e0: ldr             x3, [fp, #0x18]
    // 0xc1a3e4: ldur            x5, [fp, #-0x18]
    // 0xc1a3e8: mov             x6, x0
    // 0xc1a3ec: r0 = clipRSuperellipseAndPaint()
    //     0xc1a3ec: bl              #0xc1a408  ; [package:flutter/src/painting/clip.dart] ClipContext::clipRSuperellipseAndPaint
    // 0xc1a3f0: r0 = Null
    //     0xc1a3f0: mov             x0, NULL
    // 0xc1a3f4: LeaveFrame
    //     0xc1a3f4: mov             SP, fp
    //     0xc1a3f8: ldp             fp, lr, [SP], #0x10
    // 0xc1a3fc: ret
    //     0xc1a3fc: ret             
    // 0xc1a400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a400: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a404: b               #0xc1a28c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc1a69c, size: 0x5c
    // 0xc1a69c: EnterFrame
    //     0xc1a69c: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a6a0: mov             fp, SP
    // 0xc1a6a4: ldr             x0, [fp, #0x10]
    // 0xc1a6a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc1a6a8: ldur            w1, [x0, #0x17]
    // 0xc1a6ac: DecompressPointer r1
    //     0xc1a6ac: add             x1, x1, HEAP, lsl #32
    // 0xc1a6b0: CheckStackOverflow
    //     0xc1a6b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1a6b4: cmp             SP, x16
    //     0xc1a6b8: b.ls            #0xc1a6f0
    // 0xc1a6bc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xc1a6bc: ldur            w0, [x1, #0x17]
    // 0xc1a6c0: DecompressPointer r0
    //     0xc1a6c0: add             x0, x0, HEAP, lsl #32
    // 0xc1a6c4: LoadField: r2 = r1->field_f
    //     0xc1a6c4: ldur            w2, [x1, #0xf]
    // 0xc1a6c8: DecompressPointer r2
    //     0xc1a6c8: add             x2, x2, HEAP, lsl #32
    // 0xc1a6cc: LoadField: r3 = r1->field_13
    //     0xc1a6cc: ldur            w3, [x1, #0x13]
    // 0xc1a6d0: DecompressPointer r3
    //     0xc1a6d0: add             x3, x3, HEAP, lsl #32
    // 0xc1a6d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc1a6d4: ldur            w1, [x0, #0x17]
    // 0xc1a6d8: DecompressPointer r1
    //     0xc1a6d8: add             x1, x1, HEAP, lsl #32
    // 0xc1a6dc: r0 = paint()
    //     0xc1a6dc: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc1a6e0: r0 = Null
    //     0xc1a6e0: mov             x0, NULL
    // 0xc1a6e4: LeaveFrame
    //     0xc1a6e4: mov             SP, fp
    //     0xc1a6e8: ldp             fp, lr, [SP], #0x10
    // 0xc1a6ec: ret
    //     0xc1a6ec: ret             
    // 0xc1a6f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a6f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a6f4: b               #0xc1a6bc
  }
  _ pushClipPath(/* No info */) {
    // ** addr: 0xc1a8a8, size: 0x214
    // 0xc1a8a8: EnterFrame
    //     0xc1a8a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a8ac: mov             fp, SP
    // 0xc1a8b0: AllocStack(0x60)
    //     0xc1a8b0: sub             SP, SP, #0x60
    // 0xc1a8b4: SetupParameters(PaintingContext this /* r1 => r6, fp-0x20 */, dynamic _ /* r6 => r2, fp-0x38 */, [dynamic _ /* r0, fp-0x40 */, dynamic _ /* fp-0x28 */])
    //     0xc1a8b4: stur            x1, [fp, #-0x18]
    //     0xc1a8b8: mov             x16, x6
    //     0xc1a8bc: mov             x6, x1
    //     0xc1a8c0: mov             x1, x16
    //     0xc1a8c4: stur            x2, [fp, #-0x20]
    //     0xc1a8c8: mov             x16, x5
    //     0xc1a8cc: mov             x5, x2
    //     0xc1a8d0: mov             x2, x16
    //     0xc1a8d4: mov             x0, x7
    //     0xc1a8d8: stur            x3, [fp, #-0x28]
    //     0xc1a8dc: stur            x2, [fp, #-0x30]
    //     0xc1a8e0: stur            x1, [fp, #-0x38]
    //     0xc1a8e4: stur            x7, [fp, #-0x40]
    // 0xc1a8e8: LoadField: r7 = r4->field_13
    //     0xc1a8e8: ldur            w7, [x4, #0x13]
    // 0xc1a8ec: sub             x8, x7, #0xe
    // 0xc1a8f0: add             x9, fp, w8, sxtw #2
    // 0xc1a8f4: ldr             x9, [x9, #0x10]
    // 0xc1a8f8: stur            x9, [fp, #-0x10]
    // 0xc1a8fc: LoadField: r8 = r4->field_1f
    //     0xc1a8fc: ldur            w8, [x4, #0x1f]
    // 0xc1a900: DecompressPointer r8
    //     0xc1a900: add             x8, x8, HEAP, lsl #32
    // 0xc1a904: r16 = "clipBehavior"
    //     0xc1a904: add             x16, PP, #0x15, lsl #12  ; [pp+0x15988] "clipBehavior"
    //     0xc1a908: ldr             x16, [x16, #0x988]
    // 0xc1a90c: cmp             w8, w16
    // 0xc1a910: b.ne            #0xc1a930
    // 0xc1a914: LoadField: r8 = r4->field_23
    //     0xc1a914: ldur            w8, [x4, #0x23]
    // 0xc1a918: DecompressPointer r8
    //     0xc1a918: add             x8, x8, HEAP, lsl #32
    // 0xc1a91c: sub             w4, w7, w8
    // 0xc1a920: add             x7, fp, w4, sxtw #2
    // 0xc1a924: ldr             x7, [x7, #8]
    // 0xc1a928: mov             x4, x7
    // 0xc1a92c: b               #0xc1a938
    // 0xc1a930: r4 = Instance_Clip
    //     0xc1a930: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xc1a934: ldr             x4, [x4, #0x6f0]
    // 0xc1a938: stur            x4, [fp, #-8]
    // 0xc1a93c: CheckStackOverflow
    //     0xc1a93c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1a940: cmp             SP, x16
    //     0xc1a944: b.ls            #0xc1aab4
    // 0xc1a948: r1 = 3
    //     0xc1a948: mov             x1, #3
    // 0xc1a94c: r0 = AllocateContext()
    //     0xc1a94c: bl              #0x13de838  ; AllocateContextStub
    // 0xc1a950: mov             x3, x0
    // 0xc1a954: ldur            x0, [fp, #-0x18]
    // 0xc1a958: stur            x3, [fp, #-0x48]
    // 0xc1a95c: StoreField: r3->field_f = r0
    //     0xc1a95c: stur            w0, [x3, #0xf]
    // 0xc1a960: ldur            x2, [fp, #-0x28]
    // 0xc1a964: StoreField: r3->field_13 = r2
    //     0xc1a964: stur            w2, [x3, #0x13]
    // 0xc1a968: ldur            x1, [fp, #-0x40]
    // 0xc1a96c: ArrayStore: r3[0] = r1  ; List_4
    //     0xc1a96c: stur            w1, [x3, #0x17]
    // 0xc1a970: ldur            x4, [fp, #-8]
    // 0xc1a974: r16 = Instance_Clip
    //     0xc1a974: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc1a978: ldr             x16, [x16, #0x840]
    // 0xc1a97c: cmp             w4, w16
    // 0xc1a980: b.ne            #0xc1a9ac
    // 0xc1a984: stp             x0, x1, [SP, #8]
    // 0xc1a988: str             x2, [SP]
    // 0xc1a98c: mov             x0, x1
    // 0xc1a990: ClosureCall
    //     0xc1a990: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc1a994: ldur            x2, [x0, #0x1f]
    //     0xc1a998: blr             x2
    // 0xc1a99c: r0 = Null
    //     0xc1a99c: mov             x0, NULL
    // 0xc1a9a0: LeaveFrame
    //     0xc1a9a0: mov             SP, fp
    //     0xc1a9a4: ldp             fp, lr, [SP], #0x10
    // 0xc1a9a8: ret
    //     0xc1a9a8: ret             
    // 0xc1a9ac: ldur            x5, [fp, #-0x20]
    // 0xc1a9b0: ldur            x1, [fp, #-0x30]
    // 0xc1a9b4: r0 = shift()
    //     0xc1a9b4: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0xc1a9b8: mov             x3, x0
    // 0xc1a9bc: ldur            x0, [fp, #-0x48]
    // 0xc1a9c0: stur            x3, [fp, #-0x28]
    // 0xc1a9c4: LoadField: r2 = r0->field_13
    //     0xc1a9c4: ldur            w2, [x0, #0x13]
    // 0xc1a9c8: DecompressPointer r2
    //     0xc1a9c8: add             x2, x2, HEAP, lsl #32
    // 0xc1a9cc: ldur            x1, [fp, #-0x38]
    // 0xc1a9d0: r0 = shift()
    //     0xc1a9d0: bl              #0xc1ad40  ; [dart:ui] _NativePath::shift
    // 0xc1a9d4: mov             x1, x0
    // 0xc1a9d8: ldur            x0, [fp, #-0x20]
    // 0xc1a9dc: stur            x1, [fp, #-0x30]
    // 0xc1a9e0: tbnz            w0, #4, #0xc1aa7c
    // 0xc1a9e4: ldur            x0, [fp, #-0x10]
    // 0xc1a9e8: cmp             w0, NULL
    // 0xc1a9ec: b.ne            #0xc1aa18
    // 0xc1a9f0: r0 = ClipPathLayer()
    //     0xc1a9f0: bl              #0xc1ad34  ; AllocateClipPathLayerStub -> ClipPathLayer (size=0x50)
    // 0xc1a9f4: mov             x2, x0
    // 0xc1a9f8: r0 = Instance_Clip
    //     0xc1a9f8: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e6f0] Obj!Clip@12c8101
    //     0xc1a9fc: ldr             x0, [x0, #0x6f0]
    // 0xc1aa00: stur            x2, [fp, #-0x20]
    // 0xc1aa04: StoreField: r2->field_4b = r0
    //     0xc1aa04: stur            w0, [x2, #0x4b]
    // 0xc1aa08: mov             x1, x2
    // 0xc1aa0c: r0 = Layer()
    //     0xc1aa0c: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc1aa10: ldur            x3, [fp, #-0x20]
    // 0xc1aa14: b               #0xc1aa1c
    // 0xc1aa18: mov             x3, x0
    // 0xc1aa1c: ldur            x0, [fp, #-0x48]
    // 0xc1aa20: mov             x1, x3
    // 0xc1aa24: ldur            x2, [fp, #-0x30]
    // 0xc1aa28: stur            x3, [fp, #-0x10]
    // 0xc1aa2c: r0 = clipPath=()
    //     0xc1aa2c: bl              #0xc18964  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipPath=
    // 0xc1aa30: ldur            x1, [fp, #-0x10]
    // 0xc1aa34: ldur            x2, [fp, #-8]
    // 0xc1aa38: r0 = clipBehavior=()
    //     0xc1aa38: bl              #0xc19974  ; [package:flutter/src/rendering/layer.dart] ClipPathLayer::clipBehavior=
    // 0xc1aa3c: ldur            x2, [fp, #-0x48]
    // 0xc1aa40: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xc1aa40: ldur            w3, [x2, #0x17]
    // 0xc1aa44: DecompressPointer r3
    //     0xc1aa44: add             x3, x3, HEAP, lsl #32
    // 0xc1aa48: LoadField: r5 = r2->field_13
    //     0xc1aa48: ldur            w5, [x2, #0x13]
    // 0xc1aa4c: DecompressPointer r5
    //     0xc1aa4c: add             x5, x5, HEAP, lsl #32
    // 0xc1aa50: ldur            x16, [fp, #-0x28]
    // 0xc1aa54: str             x16, [SP]
    // 0xc1aa58: ldur            x1, [fp, #-0x18]
    // 0xc1aa5c: ldur            x2, [fp, #-0x10]
    // 0xc1aa60: r4 = const [0, 0x5, 0x1, 0x4, childPaintBounds, 0x4, null]
    //     0xc1aa60: add             x4, PP, #0x85, lsl #12  ; [pp+0x85540] List(7) [0, 0x5, 0x1, 0x4, "childPaintBounds", 0x4, Null]
    //     0xc1aa64: ldr             x4, [x4, #0x540]
    // 0xc1aa68: r0 = pushLayer()
    //     0xc1aa68: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc1aa6c: ldur            x0, [fp, #-0x10]
    // 0xc1aa70: LeaveFrame
    //     0xc1aa70: mov             SP, fp
    //     0xc1aa74: ldp             fp, lr, [SP], #0x10
    // 0xc1aa78: ret
    //     0xc1aa78: ret             
    // 0xc1aa7c: ldur            x2, [fp, #-0x48]
    // 0xc1aa80: r1 = Function '<anonymous closure>':.
    //     0xc1aa80: add             x1, PP, #0x90, lsl #12  ; [pp+0x90b70] AnonymousClosure: (0xc19a58), in [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect (0xc19194)
    //     0xc1aa84: ldr             x1, [x1, #0xb70]
    // 0xc1aa88: r0 = AllocateClosure()
    //     0xc1aa88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1aa8c: ldur            x1, [fp, #-0x18]
    // 0xc1aa90: ldur            x2, [fp, #-0x30]
    // 0xc1aa94: ldur            x3, [fp, #-8]
    // 0xc1aa98: ldur            x5, [fp, #-0x28]
    // 0xc1aa9c: mov             x6, x0
    // 0xc1aaa0: r0 = clipPathAndPaint()
    //     0xc1aaa0: bl              #0xc1aabc  ; [package:flutter/src/painting/clip.dart] ClipContext::clipPathAndPaint
    // 0xc1aaa4: r0 = Null
    //     0xc1aaa4: mov             x0, NULL
    // 0xc1aaa8: LeaveFrame
    //     0xc1aaa8: mov             SP, fp
    //     0xc1aaac: ldp             fp, lr, [SP], #0x10
    // 0xc1aab0: ret
    //     0xc1aab0: ret             
    // 0xc1aab4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1aab4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1aab8: b               #0xc1a948
  }
  _ setIsComplexHint(/* No info */) {
    // ** addr: 0xc1bffc, size: 0x70
    // 0xc1bffc: EnterFrame
    //     0xc1bffc: stp             fp, lr, [SP, #-0x10]!
    //     0xc1c000: mov             fp, SP
    // 0xc1c004: AllocStack(0x8)
    //     0xc1c004: sub             SP, SP, #8
    // 0xc1c008: SetupParameters(PaintingContext this /* r1 => r0, fp-0x8 */)
    //     0xc1c008: mov             x0, x1
    //     0xc1c00c: stur            x1, [fp, #-8]
    // 0xc1c010: CheckStackOverflow
    //     0xc1c010: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1c014: cmp             SP, x16
    //     0xc1c018: b.ls            #0xc1c060
    // 0xc1c01c: LoadField: r1 = r0->field_f
    //     0xc1c01c: ldur            w1, [x0, #0xf]
    // 0xc1c020: DecompressPointer r1
    //     0xc1c020: add             x1, x1, HEAP, lsl #32
    // 0xc1c024: cmp             w1, NULL
    // 0xc1c028: b.ne            #0xc1c034
    // 0xc1c02c: mov             x1, x0
    // 0xc1c030: r0 = _startRecording()
    //     0xc1c030: bl              #0xc176f8  ; [package:flutter/src/rendering/object.dart] PaintingContext::_startRecording
    // 0xc1c034: ldur            x0, [fp, #-8]
    // 0xc1c038: LoadField: r1 = r0->field_f
    //     0xc1c038: ldur            w1, [x0, #0xf]
    // 0xc1c03c: DecompressPointer r1
    //     0xc1c03c: add             x1, x1, HEAP, lsl #32
    // 0xc1c040: cmp             w1, NULL
    // 0xc1c044: b.eq            #0xc1c068
    // 0xc1c048: r2 = true
    //     0xc1c048: add             x2, NULL, #0x20  ; true
    // 0xc1c04c: r0 = isComplexHint=()
    //     0xc1c04c: bl              #0xc1c06c  ; [package:flutter/src/rendering/layer.dart] PictureLayer::isComplexHint=
    // 0xc1c050: r0 = Null
    //     0xc1c050: mov             x0, NULL
    // 0xc1c054: LeaveFrame
    //     0xc1c054: mov             SP, fp
    //     0xc1c058: ldp             fp, lr, [SP], #0x10
    // 0xc1c05c: ret
    //     0xc1c05c: ret             
    // 0xc1c060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1c060: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1c064: b               #0xc1c01c
    // 0xc1c068: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1c068: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ pushTransform(/* No info */) {
    // ** addr: 0xc1c818, size: 0x23c
    // 0xc1c818: EnterFrame
    //     0xc1c818: stp             fp, lr, [SP, #-0x10]!
    //     0xc1c81c: mov             fp, SP
    // 0xc1c820: AllocStack(0x60)
    //     0xc1c820: sub             SP, SP, #0x60
    // 0xc1c824: SetupParameters(PaintingContext this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */, dynamic _ /* r5 => r2, fp-0x20 */, dynamic _ /* r6 => r3, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0xc1c824: mov             x4, x1
    //     0xc1c828: mov             x0, x2
    //     0xc1c82c: stur            x2, [fp, #-0x10]
    //     0xc1c830: mov             x2, x5
    //     0xc1c834: stur            x5, [fp, #-0x20]
    //     0xc1c838: mov             x5, x3
    //     0xc1c83c: stur            x3, [fp, #-0x18]
    //     0xc1c840: mov             x3, x6
    //     0xc1c844: stur            x1, [fp, #-8]
    //     0xc1c848: stur            x6, [fp, #-0x28]
    //     0xc1c84c: stur            x7, [fp, #-0x30]
    // 0xc1c850: CheckStackOverflow
    //     0xc1c850: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1c854: cmp             SP, x16
    //     0xc1c858: b.ls            #0xc1ca44
    // 0xc1c85c: LoadField: d2 = r5->field_7
    //     0xc1c85c: ldur            d2, [x5, #7]
    // 0xc1c860: stur            d2, [fp, #-0x48]
    // 0xc1c864: LoadField: d3 = r5->field_f
    //     0xc1c864: ldur            d3, [x5, #0xf]
    // 0xc1c868: mov             v0.16b, v2.16b
    // 0xc1c86c: mov             v1.16b, v3.16b
    // 0xc1c870: stur            d3, [fp, #-0x40]
    // 0xc1c874: r1 = Null
    //     0xc1c874: mov             x1, NULL
    // 0xc1c878: r0 = Matrix4.translationValues()
    //     0xc1c878: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xc1c87c: mov             x1, x0
    // 0xc1c880: ldur            x2, [fp, #-0x20]
    // 0xc1c884: stur            x0, [fp, #-0x20]
    // 0xc1c888: r0 = multiply()
    //     0xc1c888: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xc1c88c: ldur            d0, [fp, #-0x48]
    // 0xc1c890: fneg            d1, d0
    // 0xc1c894: ldur            d0, [fp, #-0x40]
    // 0xc1c898: fneg            d2, d0
    // 0xc1c89c: ldur            x1, [fp, #-0x20]
    // 0xc1c8a0: mov             v0.16b, v1.16b
    // 0xc1c8a4: mov             v1.16b, v2.16b
    // 0xc1c8a8: r0 = translateByDouble()
    //     0xc1c8a8: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xc1c8ac: ldur            x0, [fp, #-0x10]
    // 0xc1c8b0: tbnz            w0, #4, #0xc1c948
    // 0xc1c8b4: ldur            x0, [fp, #-0x30]
    // 0xc1c8b8: cmp             w0, NULL
    // 0xc1c8bc: b.ne            #0xc1c8ec
    // 0xc1c8c0: r0 = TransformLayer()
    //     0xc1c8c0: bl              #0x89d124  ; AllocateTransformLayerStub -> TransformLayer (size=0x5c)
    // 0xc1c8c4: mov             x2, x0
    // 0xc1c8c8: r0 = true
    //     0xc1c8c8: add             x0, NULL, #0x20  ; true
    // 0xc1c8cc: stur            x2, [fp, #-0x10]
    // 0xc1c8d0: StoreField: r2->field_57 = r0
    //     0xc1c8d0: stur            w0, [x2, #0x57]
    // 0xc1c8d4: r0 = Instance_Offset
    //     0xc1c8d4: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1c8d8: StoreField: r2->field_47 = r0
    //     0xc1c8d8: stur            w0, [x2, #0x47]
    // 0xc1c8dc: mov             x1, x2
    // 0xc1c8e0: r0 = Layer()
    //     0xc1c8e0: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc1c8e4: ldur            x3, [fp, #-0x10]
    // 0xc1c8e8: b               #0xc1c8f0
    // 0xc1c8ec: mov             x3, x0
    // 0xc1c8f0: ldur            x0, [fp, #-8]
    // 0xc1c8f4: mov             x1, x3
    // 0xc1c8f8: ldur            x2, [fp, #-0x20]
    // 0xc1c8fc: stur            x3, [fp, #-0x10]
    // 0xc1c900: r0 = transform=()
    //     0xc1c900: bl              #0xc1cae8  ; [package:flutter/src/rendering/layer.dart] TransformLayer::transform=
    // 0xc1c904: ldur            x0, [fp, #-8]
    // 0xc1c908: LoadField: r2 = r0->field_b
    //     0xc1c908: ldur            w2, [x0, #0xb]
    // 0xc1c90c: DecompressPointer r2
    //     0xc1c90c: add             x2, x2, HEAP, lsl #32
    // 0xc1c910: ldur            x1, [fp, #-0x20]
    // 0xc1c914: r0 = inverseTransformRect()
    //     0xc1c914: bl              #0xc1ca54  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::inverseTransformRect
    // 0xc1c918: str             x0, [SP]
    // 0xc1c91c: ldur            x1, [fp, #-8]
    // 0xc1c920: ldur            x2, [fp, #-0x10]
    // 0xc1c924: ldur            x3, [fp, #-0x28]
    // 0xc1c928: ldur            x5, [fp, #-0x18]
    // 0xc1c92c: r4 = const [0, 0x5, 0x1, 0x4, childPaintBounds, 0x4, null]
    //     0xc1c92c: add             x4, PP, #0x85, lsl #12  ; [pp+0x85540] List(7) [0, 0x5, 0x1, 0x4, "childPaintBounds", 0x4, Null]
    //     0xc1c930: ldr             x4, [x4, #0x540]
    // 0xc1c934: r0 = pushLayer()
    //     0xc1c934: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc1c938: ldur            x0, [fp, #-0x10]
    // 0xc1c93c: LeaveFrame
    //     0xc1c93c: mov             SP, fp
    //     0xc1c940: ldp             fp, lr, [SP], #0x10
    // 0xc1c944: ret
    //     0xc1c944: ret             
    // 0xc1c948: ldur            x1, [fp, #-8]
    // 0xc1c94c: r0 = canvas()
    //     0xc1c94c: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1c950: stur            x0, [fp, #-0x10]
    // 0xc1c954: LoadField: r1 = r0->field_7
    //     0xc1c954: ldur            w1, [x0, #7]
    // 0xc1c958: DecompressPointer r1
    //     0xc1c958: add             x1, x1, HEAP, lsl #32
    // 0xc1c95c: cmp             w1, NULL
    // 0xc1c960: b.eq            #0xc1ca4c
    // 0xc1c964: LoadField: r2 = r1->field_7
    //     0xc1c964: ldur            x2, [x1, #7]
    // 0xc1c968: ldr             x1, [x2]
    // 0xc1c96c: cbz             x1, #0xc1ca24
    // 0xc1c970: ldur            x2, [fp, #-0x20]
    // 0xc1c974: mov             x3, x1
    // 0xc1c978: stur            x3, [fp, #-0x38]
    // 0xc1c97c: r1 = <Never>
    //     0xc1c97c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1c980: r0 = Pointer()
    //     0xc1c980: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1c984: mov             x1, x0
    // 0xc1c988: ldur            x0, [fp, #-0x38]
    // 0xc1c98c: StoreField: r1->field_7 = r0
    //     0xc1c98c: stur            x0, [x1, #7]
    // 0xc1c990: r0 = _save$Method$FfiNative()
    //     0xc1c990: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xc1c994: ldur            x0, [fp, #-0x20]
    // 0xc1c998: LoadField: r2 = r0->field_7
    //     0xc1c998: ldur            w2, [x0, #7]
    // 0xc1c99c: DecompressPointer r2
    //     0xc1c99c: add             x2, x2, HEAP, lsl #32
    // 0xc1c9a0: ldur            x1, [fp, #-0x10]
    // 0xc1c9a4: r0 = transform()
    //     0xc1c9a4: bl              #0xb755c4  ; [dart:ui] _NativeCanvas::transform
    // 0xc1c9a8: ldur            x16, [fp, #-0x28]
    // 0xc1c9ac: ldur            lr, [fp, #-8]
    // 0xc1c9b0: stp             lr, x16, [SP, #8]
    // 0xc1c9b4: ldur            x16, [fp, #-0x18]
    // 0xc1c9b8: str             x16, [SP]
    // 0xc1c9bc: ldur            x0, [fp, #-0x28]
    // 0xc1c9c0: ClosureCall
    //     0xc1c9c0: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc1c9c4: ldur            x2, [x0, #0x1f]
    //     0xc1c9c8: blr             x2
    // 0xc1c9cc: ldur            x1, [fp, #-8]
    // 0xc1c9d0: r0 = canvas()
    //     0xc1c9d0: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc1c9d4: stur            x0, [fp, #-8]
    // 0xc1c9d8: LoadField: r1 = r0->field_7
    //     0xc1c9d8: ldur            w1, [x0, #7]
    // 0xc1c9dc: DecompressPointer r1
    //     0xc1c9dc: add             x1, x1, HEAP, lsl #32
    // 0xc1c9e0: cmp             w1, NULL
    // 0xc1c9e4: b.eq            #0xc1ca50
    // 0xc1c9e8: LoadField: r2 = r1->field_7
    //     0xc1c9e8: ldur            x2, [x1, #7]
    // 0xc1c9ec: ldr             x1, [x2]
    // 0xc1c9f0: cbz             x1, #0xc1ca34
    // 0xc1c9f4: mov             x2, x1
    // 0xc1c9f8: stur            x2, [fp, #-0x38]
    // 0xc1c9fc: r1 = <Never>
    //     0xc1c9fc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1ca00: r0 = Pointer()
    //     0xc1ca00: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1ca04: mov             x1, x0
    // 0xc1ca08: ldur            x0, [fp, #-0x38]
    // 0xc1ca0c: StoreField: r1->field_7 = r0
    //     0xc1ca0c: stur            x0, [x1, #7]
    // 0xc1ca10: r0 = _restore$Method$FfiNative()
    //     0xc1ca10: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xc1ca14: r0 = Null
    //     0xc1ca14: mov             x0, NULL
    // 0xc1ca18: LeaveFrame
    //     0xc1ca18: mov             SP, fp
    //     0xc1ca1c: ldp             fp, lr, [SP], #0x10
    // 0xc1ca20: ret
    //     0xc1ca20: ret             
    // 0xc1ca24: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1ca24: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1ca28: str             x16, [SP]
    // 0xc1ca2c: r0 = _throwNew()
    //     0xc1ca2c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1ca30: brk             #0
    // 0xc1ca34: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1ca34: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1ca38: str             x16, [SP]
    // 0xc1ca3c: r0 = _throwNew()
    //     0xc1ca3c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1ca40: brk             #0
    // 0xc1ca44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1ca44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1ca48: b               #0xc1c85c
    // 0xc1ca4c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1ca4c: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc1ca50: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1ca50: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ addCompositionCallback(/* No info */) {
    // ** addr: 0xc1d9ac, size: 0x38
    // 0xc1d9ac: EnterFrame
    //     0xc1d9ac: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d9b0: mov             fp, SP
    // 0xc1d9b4: CheckStackOverflow
    //     0xc1d9b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d9b8: cmp             SP, x16
    //     0xc1d9bc: b.ls            #0xc1d9dc
    // 0xc1d9c0: LoadField: r0 = r1->field_7
    //     0xc1d9c0: ldur            w0, [x1, #7]
    // 0xc1d9c4: DecompressPointer r0
    //     0xc1d9c4: add             x0, x0, HEAP, lsl #32
    // 0xc1d9c8: mov             x1, x0
    // 0xc1d9cc: r0 = addCompositionCallback()
    //     0xc1d9cc: bl              #0xc1d9e4  ; [package:flutter/src/rendering/layer.dart] Layer::addCompositionCallback
    // 0xc1d9d0: LeaveFrame
    //     0xc1d9d0: mov             SP, fp
    //     0xc1d9d4: ldp             fp, lr, [SP], #0x10
    // 0xc1d9d8: ret
    //     0xc1d9d8: ret             
    // 0xc1d9dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d9dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d9e0: b               #0xc1d9c0
  }
  _ addLayer(/* No info */) {
    // ** addr: 0xc28ddc, size: 0x50
    // 0xc28ddc: EnterFrame
    //     0xc28ddc: stp             fp, lr, [SP, #-0x10]!
    //     0xc28de0: mov             fp, SP
    // 0xc28de4: AllocStack(0x10)
    //     0xc28de4: sub             SP, SP, #0x10
    // 0xc28de8: SetupParameters(PaintingContext this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xc28de8: mov             x0, x1
    //     0xc28dec: stur            x1, [fp, #-8]
    //     0xc28df0: stur            x2, [fp, #-0x10]
    // 0xc28df4: CheckStackOverflow
    //     0xc28df4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc28df8: cmp             SP, x16
    //     0xc28dfc: b.ls            #0xc28e24
    // 0xc28e00: mov             x1, x0
    // 0xc28e04: r0 = stopRecordingIfNeeded()
    //     0xc28e04: bl              #0x89a4dc  ; [package:flutter/src/rendering/object.dart] PaintingContext::stopRecordingIfNeeded
    // 0xc28e08: ldur            x1, [fp, #-8]
    // 0xc28e0c: ldur            x2, [fp, #-0x10]
    // 0xc28e10: r0 = appendLayer()
    //     0xc28e10: bl              #0xc16ba0  ; [package:flutter/src/rendering/object.dart] PaintingContext::appendLayer
    // 0xc28e14: r0 = Null
    //     0xc28e14: mov             x0, NULL
    // 0xc28e18: LeaveFrame
    //     0xc28e18: mov             SP, fp
    //     0xc28e1c: ldp             fp, lr, [SP], #0x10
    // 0xc28e20: ret
    //     0xc28e20: ret             
    // 0xc28e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc28e24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc28e28: b               #0xc28e00
  }
  _ pushOpacity(/* No info */) {
    // ** addr: 0x128243c, size: 0xc0
    // 0x128243c: EnterFrame
    //     0x128243c: stp             fp, lr, [SP, #-0x10]!
    //     0x1282440: mov             fp, SP
    // 0x1282444: AllocStack(0x28)
    //     0x1282444: sub             SP, SP, #0x28
    // 0x1282448: SetupParameters(PaintingContext this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r3, fp-0x20 */)
    //     0x1282448: mov             x0, x3
    //     0x128244c: stur            x3, [fp, #-0x18]
    //     0x1282450: mov             x3, x5
    //     0x1282454: stur            x1, [fp, #-8]
    //     0x1282458: stur            x2, [fp, #-0x10]
    //     0x128245c: stur            x5, [fp, #-0x20]
    // 0x1282460: CheckStackOverflow
    //     0x1282460: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1282464: cmp             SP, x16
    //     0x1282468: b.ls            #0x12824f4
    // 0x128246c: cmp             w6, NULL
    // 0x1282470: b.ne            #0x1282494
    // 0x1282474: r0 = OpacityLayer()
    //     0x1282474: bl              #0xbed1ac  ; AllocateOpacityLayerStub -> OpacityLayer (size=0x50)
    // 0x1282478: r5 = Instance_Offset
    //     0x1282478: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x128247c: stur            x0, [fp, #-0x28]
    // 0x1282480: StoreField: r0->field_47 = r5
    //     0x1282480: stur            w5, [x0, #0x47]
    // 0x1282484: mov             x1, x0
    // 0x1282488: r0 = Layer()
    //     0x1282488: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x128248c: ldur            x3, [fp, #-0x28]
    // 0x1282490: b               #0x1282498
    // 0x1282494: mov             x3, x6
    // 0x1282498: ldur            x2, [fp, #-0x18]
    // 0x128249c: stur            x3, [fp, #-0x28]
    // 0x12824a0: r0 = BoxInt64Instr(r2)
    //     0x12824a0: sbfiz           x0, x2, #1, #0x1f
    //     0x12824a4: cmp             x2, x0, asr #1
    //     0x12824a8: b.eq            #0x12824b4
    //     0x12824ac: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x12824b0: stur            x2, [x0, #7]
    // 0x12824b4: mov             x1, x3
    // 0x12824b8: mov             x2, x0
    // 0x12824bc: r0 = alpha=()
    //     0x12824bc: bl              #0xbecedc  ; [package:flutter/src/rendering/layer.dart] OpacityLayer::alpha=
    // 0x12824c0: ldur            x1, [fp, #-0x28]
    // 0x12824c4: ldur            x2, [fp, #-0x10]
    // 0x12824c8: r0 = offset=()
    //     0x12824c8: bl              #0xc16f8c  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::offset=
    // 0x12824cc: ldur            x1, [fp, #-8]
    // 0x12824d0: ldur            x2, [fp, #-0x28]
    // 0x12824d4: ldur            x3, [fp, #-0x20]
    // 0x12824d8: r5 = Instance_Offset
    //     0x12824d8: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x12824dc: r4 = const [0, 0x4, 0, 0x4, null]
    //     0x12824dc: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0x12824e0: r0 = pushLayer()
    //     0x12824e0: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x12824e4: ldur            x0, [fp, #-0x28]
    // 0x12824e8: LeaveFrame
    //     0x12824e8: mov             SP, fp
    //     0x12824ec: ldp             fp, lr, [SP], #0x10
    // 0x12824f0: ret
    //     0x12824f0: ret             
    // 0x12824f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12824f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12824f8: b               #0x128246c
  }
}

// class id: 4176, size: 0x8, field offset: 0x8
class ParentData extends Object {
}

// class id: 4189, size: 0xc, field offset: 0x8
abstract class ContainerParentDataMixin<X0 bound RenderObject> extends ParentData {
}

// class id: 4214, size: 0x8, field offset: 0x8
abstract class _SemanticsFragment extends Object {
}

// class id: 4215, size: 0x10, field offset: 0x8
class _IncompleteSemanticsFragment extends _SemanticsFragment {
}

// class id: 4217, size: 0x4c, field offset: 0x8
class _RenderObjectSemantics extends _MixinApplication432&_SemanticsFragment&DiagnosticableTreeMixin {

  _ markNeedsUpdate(/* No info */) {
    // ** addr: 0x837480, size: 0x480
    // 0x837480: EnterFrame
    //     0x837480: stp             fp, lr, [SP, #-0x10]!
    //     0x837484: mov             fp, SP
    // 0x837488: AllocStack(0x30)
    //     0x837488: sub             SP, SP, #0x30
    // 0x83748c: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x10 */)
    //     0x83748c: mov             x0, x1
    //     0x837490: stur            x1, [fp, #-0x10]
    // 0x837494: CheckStackOverflow
    //     0x837494: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x837498: cmp             SP, x16
    //     0x83749c: b.ls            #0x8378e0
    // 0x8374a0: LoadField: r3 = r0->field_7
    //     0x8374a0: ldur            w3, [x0, #7]
    // 0x8374a4: DecompressPointer r3
    //     0x8374a4: add             x3, x3, HEAP, lsl #32
    // 0x8374a8: stur            x3, [fp, #-8]
    // 0x8374ac: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x8374ac: ldur            w1, [x3, #0x17]
    // 0x8374b0: DecompressPointer r1
    //     0x8374b0: add             x1, x1, HEAP, lsl #32
    // 0x8374b4: cmp             w1, NULL
    // 0x8374b8: b.eq            #0x8378e8
    // 0x8374bc: LoadField: r2 = r1->field_3b
    //     0x8374bc: ldur            w2, [x1, #0x3b]
    // 0x8374c0: DecompressPointer r2
    //     0x8374c0: add             x2, x2, HEAP, lsl #32
    // 0x8374c4: mov             x1, x2
    // 0x8374c8: mov             x2, x3
    // 0x8374cc: r0 = add()
    //     0x8374cc: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x8374d0: ldur            x0, [fp, #-0x10]
    // 0x8374d4: LoadField: r2 = r0->field_1b
    //     0x8374d4: ldur            w2, [x0, #0x1b]
    // 0x8374d8: DecompressPointer r2
    //     0x8374d8: add             x2, x2, HEAP, lsl #32
    // 0x8374dc: stur            x2, [fp, #-0x18]
    // 0x8374e0: cmp             w2, NULL
    // 0x8374e4: b.eq            #0x8374fc
    // 0x8374e8: LoadField: r1 = r0->field_3b
    //     0x8374e8: ldur            w1, [x0, #0x3b]
    // 0x8374ec: DecompressPointer r1
    //     0x8374ec: add             x1, x1, HEAP, lsl #32
    // 0x8374f0: r0 = wasSemanticsBoundary()
    //     0x8374f0: bl              #0x8392a8  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::wasSemanticsBoundary
    // 0x8374f4: mov             x2, x0
    // 0x8374f8: b               #0x837500
    // 0x8374fc: r2 = false
    //     0x8374fc: add             x2, NULL, #0x30  ; false
    // 0x837500: ldur            x0, [fp, #-0x10]
    // 0x837504: stur            x2, [fp, #-0x28]
    // 0x837508: LoadField: r3 = r0->field_3b
    //     0x837508: ldur            w3, [x0, #0x3b]
    // 0x83750c: DecompressPointer r3
    //     0x83750c: add             x3, x3, HEAP, lsl #32
    // 0x837510: mov             x1, x3
    // 0x837514: stur            x3, [fp, #-0x20]
    // 0x837518: r0 = clear()
    //     0x837518: bl              #0x839290  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::clear
    // 0x83751c: ldur            x0, [fp, #-0x10]
    // 0x837520: r1 = false
    //     0x837520: add             x1, NULL, #0x30  ; false
    // 0x837524: StoreField: r0->field_13 = r1
    //     0x837524: stur            w1, [x0, #0x13]
    // 0x837528: ldur            x0, [fp, #-0x20]
    // 0x83752c: LoadField: r1 = r0->field_13
    //     0x83752c: ldur            w1, [x0, #0x13]
    // 0x837530: DecompressPointer r1
    //     0x837530: add             x1, x1, HEAP, lsl #32
    // 0x837534: cmp             w1, NULL
    // 0x837538: b.ne            #0x837548
    // 0x83753c: mov             x1, x0
    // 0x837540: r0 = original()
    //     0x837540: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x837544: b               #0x83754c
    // 0x837548: mov             x0, x1
    // 0x83754c: ldur            x1, [fp, #-0x20]
    // 0x837550: LoadField: r2 = r0->field_2f
    //     0x837550: ldur            w2, [x0, #0x2f]
    // 0x837554: DecompressPointer r2
    //     0x837554: add             x2, x2, HEAP, lsl #32
    // 0x837558: cmp             w2, NULL
    // 0x83755c: r16 = true
    //     0x83755c: add             x16, NULL, #0x20  ; true
    // 0x837560: r17 = false
    //     0x837560: add             x17, NULL, #0x30  ; false
    // 0x837564: csel            x0, x16, x17, ne
    // 0x837568: stur            x0, [fp, #-0x10]
    // 0x83756c: LoadField: r2 = r1->field_13
    //     0x83756c: ldur            w2, [x1, #0x13]
    // 0x837570: DecompressPointer r2
    //     0x837570: add             x2, x2, HEAP, lsl #32
    // 0x837574: cmp             w2, NULL
    // 0x837578: b.ne            #0x837584
    // 0x83757c: r0 = original()
    //     0x83757c: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x837580: b               #0x837588
    // 0x837584: mov             x0, x2
    // 0x837588: LoadField: r1 = r0->field_7
    //     0x837588: ldur            w1, [x0, #7]
    // 0x83758c: DecompressPointer r1
    //     0x83758c: add             x1, x1, HEAP, lsl #32
    // 0x837590: tbnz            w1, #4, #0x83759c
    // 0x837594: ldur            x0, [fp, #-0x28]
    // 0x837598: b               #0x8375a0
    // 0x83759c: r0 = false
    //     0x83759c: add             x0, NULL, #0x30  ; false
    // 0x8375a0: ldur            x5, [fp, #-0x10]
    // 0x8375a4: mov             x4, x0
    // 0x8375a8: ldur            x3, [fp, #-8]
    // 0x8375ac: ldur            x2, [fp, #-8]
    // 0x8375b0: stur            x5, [fp, #-0x10]
    // 0x8375b4: stur            x4, [fp, #-0x20]
    // 0x8375b8: stur            x3, [fp, #-0x28]
    // 0x8375bc: CheckStackOverflow
    //     0x8375bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8375c0: cmp             SP, x16
    //     0x8375c4: b.ls            #0x8378ec
    // 0x8375c8: r0 = LoadClassIdInstr(r3)
    //     0x8375c8: ldur            x0, [x3, #-1]
    //     0x8375cc: ubfx            x0, x0, #0xc, #0x14
    // 0x8375d0: mov             x1, x3
    // 0x8375d4: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x8375d4: mov             x17, #0xfc0
    //     0x8375d8: movk            x17, #1, lsl #16
    //     0x8375dc: add             lr, x0, x17
    //     0x8375e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8375e4: blr             lr
    // 0x8375e8: cmp             w0, NULL
    // 0x8375ec: b.eq            #0x8377ac
    // 0x8375f0: ldur            x0, [fp, #-0x10]
    // 0x8375f4: tbnz            w0, #4, #0x837600
    // 0x8375f8: ldur            x2, [fp, #-0x20]
    // 0x8375fc: b               #0x837608
    // 0x837600: ldur            x2, [fp, #-0x20]
    // 0x837604: tbz             w2, #4, #0x8377a4
    // 0x837608: ldur            x3, [fp, #-8]
    // 0x83760c: ldur            x4, [fp, #-0x28]
    // 0x837610: cmp             w4, w3
    // 0x837614: b.eq            #0x837678
    // 0x837618: mov             x1, x4
    // 0x83761c: LoadField: r0 = r1->field_43
    //     0x83761c: ldur            w0, [x1, #0x43]
    // 0x837620: DecompressPointer r0
    //     0x837620: add             x0, x0, HEAP, lsl #32
    // 0x837624: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x837628: cmp             w0, w16
    // 0x83762c: b.ne            #0x837638
    // 0x837630: r2 = _semantics
    //     0x837630: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x837634: r0 = InitLateFinalInstanceField()
    //     0x837634: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x837638: mov             x1, x0
    // 0x83763c: stur            x0, [fp, #-0x30]
    // 0x837640: r0 = isRoot()
    //     0x837640: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x837644: tbnz            w0, #4, #0x837650
    // 0x837648: ldur            x0, [fp, #-0x10]
    // 0x83764c: b               #0x837678
    // 0x837650: ldur            x0, [fp, #-0x30]
    // 0x837654: LoadField: r1 = r0->field_33
    //     0x837654: ldur            w1, [x0, #0x33]
    // 0x837658: DecompressPointer r1
    //     0x837658: add             x1, x1, HEAP, lsl #32
    // 0x83765c: cmp             w1, NULL
    // 0x837660: b.ne            #0x837674
    // 0x837664: ldur            x0, [fp, #-0x10]
    // 0x837668: tbz             w0, #4, #0x837678
    // 0x83766c: ldur            x0, [fp, #-0x28]
    // 0x837670: b               #0x8377b0
    // 0x837674: ldur            x0, [fp, #-0x10]
    // 0x837678: ldur            x2, [fp, #-0x20]
    // 0x83767c: ldur            x1, [fp, #-0x28]
    // 0x837680: LoadField: r0 = r1->field_43
    //     0x837680: ldur            w0, [x1, #0x43]
    // 0x837684: DecompressPointer r0
    //     0x837684: add             x0, x0, HEAP, lsl #32
    // 0x837688: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x83768c: cmp             w0, w16
    // 0x837690: b.ne            #0x83769c
    // 0x837694: r2 = _semantics
    //     0x837694: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x837698: r0 = InitLateFinalInstanceField()
    //     0x837698: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x83769c: StoreField: r0->field_33 = rNULL
    //     0x83769c: stur            NULL, [x0, #0x33]
    // 0x8376a0: StoreField: r0->field_f = rNULL
    //     0x8376a0: stur            NULL, [x0, #0xf]
    // 0x8376a4: ldur            x1, [fp, #-0x20]
    // 0x8376a8: tbnz            w1, #4, #0x8376b4
    // 0x8376ac: r2 = false
    //     0x8376ac: add             x2, NULL, #0x30  ; false
    // 0x8376b0: b               #0x8376b8
    // 0x8376b4: ldur            x2, [fp, #-0x10]
    // 0x8376b8: stur            x2, [fp, #-0x10]
    // 0x8376bc: LoadField: r1 = r0->field_3b
    //     0x8376bc: ldur            w1, [x0, #0x3b]
    // 0x8376c0: DecompressPointer r1
    //     0x8376c0: add             x1, x1, HEAP, lsl #32
    // 0x8376c4: LoadField: r0 = r1->field_13
    //     0x8376c4: ldur            w0, [x1, #0x13]
    // 0x8376c8: DecompressPointer r0
    //     0x8376c8: add             x0, x0, HEAP, lsl #32
    // 0x8376cc: cmp             w0, NULL
    // 0x8376d0: b.ne            #0x8376d8
    // 0x8376d4: r0 = original()
    //     0x8376d4: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x8376d8: LoadField: r1 = r0->field_2f
    //     0x8376d8: ldur            w1, [x0, #0x2f]
    // 0x8376dc: DecompressPointer r1
    //     0x8376dc: add             x1, x1, HEAP, lsl #32
    // 0x8376e0: cmp             w1, NULL
    // 0x8376e4: b.eq            #0x8376f0
    // 0x8376e8: r5 = true
    //     0x8376e8: add             x5, NULL, #0x20  ; true
    // 0x8376ec: b               #0x8376f4
    // 0x8376f0: ldur            x5, [fp, #-0x10]
    // 0x8376f4: ldur            x0, [fp, #-0x28]
    // 0x8376f8: stur            x5, [fp, #-0x10]
    // 0x8376fc: r1 = LoadClassIdInstr(r0)
    //     0x8376fc: ldur            x1, [x0, #-1]
    //     0x837700: ubfx            x1, x1, #0xc, #0x14
    // 0x837704: mov             x16, x0
    // 0x837708: mov             x0, x1
    // 0x83770c: mov             x1, x16
    // 0x837710: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x837710: mov             x17, #0xfc0
    //     0x837714: movk            x17, #1, lsl #16
    //     0x837718: add             lr, x0, x17
    //     0x83771c: ldr             lr, [x21, lr, lsl #3]
    //     0x837720: blr             lr
    // 0x837724: stur            x0, [fp, #-0x20]
    // 0x837728: cmp             w0, NULL
    // 0x83772c: b.eq            #0x8378f4
    // 0x837730: mov             x1, x0
    // 0x837734: LoadField: r0 = r1->field_43
    //     0x837734: ldur            w0, [x1, #0x43]
    // 0x837738: DecompressPointer r0
    //     0x837738: add             x0, x0, HEAP, lsl #32
    // 0x83773c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x837740: cmp             w0, w16
    // 0x837744: b.ne            #0x837750
    // 0x837748: r2 = _semantics
    //     0x837748: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x83774c: r0 = InitLateFinalInstanceField()
    //     0x83774c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x837750: LoadField: r1 = r0->field_3b
    //     0x837750: ldur            w1, [x0, #0x3b]
    // 0x837754: DecompressPointer r1
    //     0x837754: add             x1, x1, HEAP, lsl #32
    // 0x837758: LoadField: r0 = r1->field_13
    //     0x837758: ldur            w0, [x1, #0x13]
    // 0x83775c: DecompressPointer r0
    //     0x83775c: add             x0, x0, HEAP, lsl #32
    // 0x837760: cmp             w0, NULL
    // 0x837764: b.ne            #0x83776c
    // 0x837768: r0 = original()
    //     0x837768: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x83776c: LoadField: r1 = r0->field_7
    //     0x83776c: ldur            w1, [x0, #7]
    // 0x837770: DecompressPointer r1
    //     0x837770: add             x1, x1, HEAP, lsl #32
    // 0x837774: tbnz            w1, #4, #0x837794
    // 0x837778: ldur            x3, [fp, #-0x20]
    // 0x83777c: LoadField: r0 = r3->field_43
    //     0x83777c: ldur            w0, [x3, #0x43]
    // 0x837780: DecompressPointer r0
    //     0x837780: add             x0, x0, HEAP, lsl #32
    // 0x837784: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x837784: ldur            w1, [x0, #0x17]
    // 0x837788: DecompressPointer r1
    //     0x837788: add             x1, x1, HEAP, lsl #32
    // 0x83778c: mov             x4, x1
    // 0x837790: b               #0x83779c
    // 0x837794: ldur            x3, [fp, #-0x20]
    // 0x837798: r4 = false
    //     0x837798: add             x4, NULL, #0x30  ; false
    // 0x83779c: ldur            x5, [fp, #-0x10]
    // 0x8377a0: b               #0x8375ac
    // 0x8377a4: ldur            x0, [fp, #-0x28]
    // 0x8377a8: b               #0x8377b0
    // 0x8377ac: ldur            x0, [fp, #-0x28]
    // 0x8377b0: ldur            x2, [fp, #-8]
    // 0x8377b4: cmp             w0, w2
    // 0x8377b8: b.eq            #0x837834
    // 0x8377bc: ldur            x1, [fp, #-0x18]
    // 0x8377c0: cmp             w1, NULL
    // 0x8377c4: b.eq            #0x837834
    // 0x8377c8: mov             x1, x0
    // 0x8377cc: LoadField: r0 = r1->field_43
    //     0x8377cc: ldur            w0, [x1, #0x43]
    // 0x8377d0: DecompressPointer r0
    //     0x8377d0: add             x0, x0, HEAP, lsl #32
    // 0x8377d4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8377d8: cmp             w0, w16
    // 0x8377dc: b.ne            #0x8377e8
    // 0x8377e0: r2 = _semantics
    //     0x8377e0: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x8377e4: r0 = InitLateFinalInstanceField()
    //     0x8377e4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x8377e8: mov             x1, x0
    // 0x8377ec: stur            x0, [fp, #-0x10]
    // 0x8377f0: r0 = isRoot()
    //     0x8377f0: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x8377f4: tbz             w0, #4, #0x837834
    // 0x8377f8: ldur            x0, [fp, #-0x10]
    // 0x8377fc: LoadField: r1 = r0->field_33
    //     0x8377fc: ldur            w1, [x0, #0x33]
    // 0x837800: DecompressPointer r1
    //     0x837800: add             x1, x1, HEAP, lsl #32
    // 0x837804: cmp             w1, NULL
    // 0x837808: b.ne            #0x837834
    // 0x83780c: ldur            x0, [fp, #-8]
    // 0x837810: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x837810: ldur            w1, [x0, #0x17]
    // 0x837814: DecompressPointer r1
    //     0x837814: add             x1, x1, HEAP, lsl #32
    // 0x837818: cmp             w1, NULL
    // 0x83781c: b.eq            #0x8378f8
    // 0x837820: LoadField: r2 = r1->field_37
    //     0x837820: ldur            w2, [x1, #0x37]
    // 0x837824: DecompressPointer r2
    //     0x837824: add             x2, x2, HEAP, lsl #32
    // 0x837828: mov             x1, x2
    // 0x83782c: mov             x2, x0
    // 0x837830: r0 = remove()
    //     0x837830: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x837834: ldur            x1, [fp, #-0x28]
    // 0x837838: LoadField: r0 = r1->field_43
    //     0x837838: ldur            w0, [x1, #0x43]
    // 0x83783c: DecompressPointer r0
    //     0x83783c: add             x0, x0, HEAP, lsl #32
    // 0x837840: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x837844: cmp             w0, w16
    // 0x837848: b.ne            #0x837854
    // 0x83784c: r2 = _semantics
    //     0x83784c: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x837850: r0 = InitLateFinalInstanceField()
    //     0x837850: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x837854: mov             x1, x0
    // 0x837858: stur            x0, [fp, #-0x10]
    // 0x83785c: r0 = isRoot()
    //     0x83785c: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x837860: tbz             w0, #4, #0x83788c
    // 0x837864: ldur            x0, [fp, #-0x10]
    // 0x837868: LoadField: r1 = r0->field_33
    //     0x837868: ldur            w1, [x0, #0x33]
    // 0x83786c: DecompressPointer r1
    //     0x83786c: add             x1, x1, HEAP, lsl #32
    // 0x837870: cmp             w1, NULL
    // 0x837874: b.ne            #0x83788c
    // 0x837878: ldur            x2, [fp, #-0x28]
    // 0x83787c: LoadField: r1 = r2->field_43
    //     0x83787c: ldur            w1, [x2, #0x43]
    // 0x837880: DecompressPointer r1
    //     0x837880: add             x1, x1, HEAP, lsl #32
    // 0x837884: r0 = isRoot()
    //     0x837884: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x837888: tbnz            w0, #4, #0x8378d0
    // 0x83788c: ldur            x0, [fp, #-8]
    // 0x837890: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x837890: ldur            w1, [x0, #0x17]
    // 0x837894: DecompressPointer r1
    //     0x837894: add             x1, x1, HEAP, lsl #32
    // 0x837898: cmp             w1, NULL
    // 0x83789c: b.eq            #0x8378d0
    // 0x8378a0: LoadField: r2 = r1->field_37
    //     0x8378a0: ldur            w2, [x1, #0x37]
    // 0x8378a4: DecompressPointer r2
    //     0x8378a4: add             x2, x2, HEAP, lsl #32
    // 0x8378a8: mov             x1, x2
    // 0x8378ac: ldur            x2, [fp, #-0x28]
    // 0x8378b0: r0 = add()
    //     0x8378b0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x8378b4: tbnz            w0, #4, #0x8378d0
    // 0x8378b8: ldur            x0, [fp, #-8]
    // 0x8378bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8378bc: ldur            w1, [x0, #0x17]
    // 0x8378c0: DecompressPointer r1
    //     0x8378c0: add             x1, x1, HEAP, lsl #32
    // 0x8378c4: cmp             w1, NULL
    // 0x8378c8: b.eq            #0x8378fc
    // 0x8378cc: r0 = requestVisualUpdate()
    //     0x8378cc: bl              #0x837988  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0x8378d0: r0 = Null
    //     0x8378d0: mov             x0, NULL
    // 0x8378d4: LeaveFrame
    //     0x8378d4: mov             SP, fp
    //     0x8378d8: ldp             fp, lr, [SP], #0x10
    // 0x8378dc: ret
    //     0x8378dc: ret             
    // 0x8378e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8378e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8378e4: b               #0x8374a0
    // 0x8378e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8378e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8378ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8378ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8378f0: b               #0x8375c8
    // 0x8378f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8378f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8378f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8378f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8378fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8378fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ isRoot(/* No info */) {
    // ** addr: 0x837aa0, size: 0x9c
    // 0x837aa0: EnterFrame
    //     0x837aa0: stp             fp, lr, [SP, #-0x10]!
    //     0x837aa4: mov             fp, SP
    // 0x837aa8: CheckStackOverflow
    //     0x837aa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x837aac: cmp             SP, x16
    //     0x837ab0: b.ls            #0x837b34
    // 0x837ab4: LoadField: r0 = r1->field_7
    //     0x837ab4: ldur            w0, [x1, #7]
    // 0x837ab8: DecompressPointer r0
    //     0x837ab8: add             x0, x0, HEAP, lsl #32
    // 0x837abc: r1 = LoadClassIdInstr(r0)
    //     0x837abc: ldur            x1, [x0, #-1]
    //     0x837ac0: ubfx            x1, x1, #0xc, #0x14
    // 0x837ac4: mov             x16, x0
    // 0x837ac8: mov             x0, x1
    // 0x837acc: mov             x1, x16
    // 0x837ad0: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x837ad0: mov             x17, #0xfc0
    //     0x837ad4: movk            x17, #1, lsl #16
    //     0x837ad8: add             lr, x0, x17
    //     0x837adc: ldr             lr, [x21, lr, lsl #3]
    //     0x837ae0: blr             lr
    // 0x837ae4: cmp             w0, NULL
    // 0x837ae8: b.ne            #0x837af4
    // 0x837aec: r1 = Null
    //     0x837aec: mov             x1, NULL
    // 0x837af0: b               #0x837b18
    // 0x837af4: mov             x1, x0
    // 0x837af8: LoadField: r0 = r1->field_43
    //     0x837af8: ldur            w0, [x1, #0x43]
    // 0x837afc: DecompressPointer r0
    //     0x837afc: add             x0, x0, HEAP, lsl #32
    // 0x837b00: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x837b04: cmp             w0, w16
    // 0x837b08: b.ne            #0x837b14
    // 0x837b0c: r2 = _semantics
    //     0x837b0c: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x837b10: r0 = InitLateFinalInstanceField()
    //     0x837b10: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x837b14: mov             x1, x0
    // 0x837b18: cmp             w1, NULL
    // 0x837b1c: r16 = true
    //     0x837b1c: add             x16, NULL, #0x20  ; true
    // 0x837b20: r17 = false
    //     0x837b20: add             x17, NULL, #0x30  ; false
    // 0x837b24: csel            x0, x16, x17, eq
    // 0x837b28: LeaveFrame
    //     0x837b28: mov             SP, fp
    //     0x837b2c: ldp             fp, lr, [SP], #0x10
    // 0x837b30: ret
    //     0x837b30: ret             
    // 0x837b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x837b34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x837b38: b               #0x837ab4
  }
  get _ parent(/* No info */) {
    // ** addr: 0x837b3c, size: 0x88
    // 0x837b3c: EnterFrame
    //     0x837b3c: stp             fp, lr, [SP, #-0x10]!
    //     0x837b40: mov             fp, SP
    // 0x837b44: CheckStackOverflow
    //     0x837b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x837b48: cmp             SP, x16
    //     0x837b4c: b.ls            #0x837bbc
    // 0x837b50: LoadField: r0 = r1->field_7
    //     0x837b50: ldur            w0, [x1, #7]
    // 0x837b54: DecompressPointer r0
    //     0x837b54: add             x0, x0, HEAP, lsl #32
    // 0x837b58: r1 = LoadClassIdInstr(r0)
    //     0x837b58: ldur            x1, [x0, #-1]
    //     0x837b5c: ubfx            x1, x1, #0xc, #0x14
    // 0x837b60: mov             x16, x0
    // 0x837b64: mov             x0, x1
    // 0x837b68: mov             x1, x16
    // 0x837b6c: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x837b6c: mov             x17, #0xfc0
    //     0x837b70: movk            x17, #1, lsl #16
    //     0x837b74: add             lr, x0, x17
    //     0x837b78: ldr             lr, [x21, lr, lsl #3]
    //     0x837b7c: blr             lr
    // 0x837b80: cmp             w0, NULL
    // 0x837b84: b.ne            #0x837b90
    // 0x837b88: r0 = Null
    //     0x837b88: mov             x0, NULL
    // 0x837b8c: b               #0x837bb0
    // 0x837b90: mov             x1, x0
    // 0x837b94: LoadField: r0 = r1->field_43
    //     0x837b94: ldur            w0, [x1, #0x43]
    // 0x837b98: DecompressPointer r0
    //     0x837b98: add             x0, x0, HEAP, lsl #32
    // 0x837b9c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x837ba0: cmp             w0, w16
    // 0x837ba4: b.ne            #0x837bb0
    // 0x837ba8: r2 = _semantics
    //     0x837ba8: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x837bac: r0 = InitLateFinalInstanceField()
    //     0x837bac: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x837bb0: LeaveFrame
    //     0x837bb0: mov             SP, fp
    //     0x837bb4: ldp             fp, lr, [SP], #0x10
    // 0x837bb8: ret
    //     0x837bb8: ret             
    // 0x837bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x837bbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x837bc0: b               #0x837b50
  }
  _ _RenderObjectSemantics(/* No info */) {
    // ** addr: 0x839324, size: 0x18c
    // 0x839324: EnterFrame
    //     0x839324: stp             fp, lr, [SP, #-0x10]!
    //     0x839328: mov             fp, SP
    // 0x83932c: AllocStack(0x20)
    //     0x83932c: sub             SP, SP, #0x20
    // 0x839330: r3 = false
    //     0x839330: add             x3, NULL, #0x30  ; false
    // 0x839334: r0 = Instance_Object
    //     0x839334: ldr             x0, [PP, #0x23b0]  ; [pp+0x23b0] Obj!Object@10f5891
    // 0x839338: mov             x5, x1
    // 0x83933c: mov             x4, x2
    // 0x839340: stur            x1, [fp, #-8]
    // 0x839344: stur            x2, [fp, #-0x10]
    // 0x839348: CheckStackOverflow
    //     0x839348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x83934c: cmp             SP, x16
    //     0x839350: b.ls            #0x8394a8
    // 0x839354: StoreField: r5->field_b = r3
    //     0x839354: stur            w3, [x5, #0xb]
    // 0x839358: StoreField: r5->field_13 = r3
    //     0x839358: stur            w3, [x5, #0x13]
    // 0x83935c: ArrayStore: r5[0] = r3  ; List_4
    //     0x83935c: stur            w3, [x5, #0x17]
    // 0x839360: StoreField: r5->field_43 = r0
    //     0x839360: stur            w0, [x5, #0x43]
    // 0x839364: r1 = <SemanticsNode>
    //     0x839364: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0x839368: r2 = 0
    //     0x839368: mov             x2, #0
    // 0x83936c: r0 = _GrowableList()
    //     0x83936c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x839370: ldur            x3, [fp, #-8]
    // 0x839374: StoreField: r3->field_1f = r0
    //     0x839374: stur            w0, [x3, #0x1f]
    //     0x839378: ldurb           w16, [x3, #-1]
    //     0x83937c: ldurb           w17, [x0, #-1]
    //     0x839380: and             x16, x17, x16, lsr #2
    //     0x839384: tst             x16, HEAP, lsr #32
    //     0x839388: b.eq            #0x839390
    //     0x83938c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x839390: r1 = <_SemanticsFragment>
    //     0x839390: ldr             x1, [PP, #0x23c0]  ; [pp+0x23c0] TypeArguments: <_SemanticsFragment>
    // 0x839394: r2 = 0
    //     0x839394: mov             x2, #0
    // 0x839398: r0 = _GrowableList()
    //     0x839398: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x83939c: ldur            x3, [fp, #-8]
    // 0x8393a0: StoreField: r3->field_23 = r0
    //     0x8393a0: stur            w0, [x3, #0x23]
    //     0x8393a4: ldurb           w16, [x3, #-1]
    //     0x8393a8: ldurb           w17, [x0, #-1]
    //     0x8393ac: and             x16, x17, x16, lsr #2
    //     0x8393b0: tst             x16, HEAP, lsr #32
    //     0x8393b4: b.eq            #0x8393bc
    //     0x8393b8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8393bc: r1 = <_RenderObjectSemantics>
    //     0x8393bc: ldr             x1, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x8393c0: r2 = 0
    //     0x8393c0: mov             x2, #0
    // 0x8393c4: r0 = _GrowableList()
    //     0x8393c4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8393c8: ldur            x3, [fp, #-8]
    // 0x8393cc: StoreField: r3->field_27 = r0
    //     0x8393cc: stur            w0, [x3, #0x27]
    //     0x8393d0: ldurb           w16, [x3, #-1]
    //     0x8393d4: ldurb           w17, [x0, #-1]
    //     0x8393d8: and             x16, x17, x16, lsr #2
    //     0x8393dc: tst             x16, HEAP, lsr #32
    //     0x8393e0: b.eq            #0x8393e8
    //     0x8393e4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8393e8: r1 = <List<_SemanticsFragment>>
    //     0x8393e8: ldr             x1, [PP, #0x23c8]  ; [pp+0x23c8] TypeArguments: <List<_SemanticsFragment>>
    // 0x8393ec: r2 = 0
    //     0x8393ec: mov             x2, #0
    // 0x8393f0: r0 = _GrowableList()
    //     0x8393f0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8393f4: ldur            x1, [fp, #-8]
    // 0x8393f8: StoreField: r1->field_2b = r0
    //     0x8393f8: stur            w0, [x1, #0x2b]
    //     0x8393fc: ldurb           w16, [x1, #-1]
    //     0x839400: ldurb           w17, [x0, #-1]
    //     0x839404: and             x16, x17, x16, lsr #2
    //     0x839408: tst             x16, HEAP, lsr #32
    //     0x83940c: b.eq            #0x839414
    //     0x839410: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x839414: r16 = <SemanticsNode, List<_SemanticsFragment>>
    //     0x839414: ldr             x16, [PP, #0x23d0]  ; [pp+0x23d0] TypeArguments: <SemanticsNode, List<_SemanticsFragment>>
    // 0x839418: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x83941c: stp             lr, x16, [SP]
    // 0x839420: r0 = Map._fromLiteral()
    //     0x839420: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x839424: ldur            x1, [fp, #-8]
    // 0x839428: StoreField: r1->field_2f = r0
    //     0x839428: stur            w0, [x1, #0x2f]
    //     0x83942c: ldurb           w16, [x1, #-1]
    //     0x839430: ldurb           w17, [x0, #-1]
    //     0x839434: and             x16, x17, x16, lsr #2
    //     0x839438: tst             x16, HEAP, lsr #32
    //     0x83943c: b.eq            #0x839444
    //     0x839440: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x839444: ldur            x0, [fp, #-0x10]
    // 0x839448: StoreField: r1->field_7 = r0
    //     0x839448: stur            w0, [x1, #7]
    //     0x83944c: ldurb           w16, [x1, #-1]
    //     0x839450: ldurb           w17, [x0, #-1]
    //     0x839454: and             x16, x17, x16, lsr #2
    //     0x839458: tst             x16, HEAP, lsr #32
    //     0x83945c: b.eq            #0x839464
    //     0x839460: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x839464: r0 = _SemanticsConfigurationProvider()
    //     0x839464: bl              #0x8394b0  ; Allocate_SemanticsConfigurationProviderStub -> _SemanticsConfigurationProvider (size=0x18)
    // 0x839468: r1 = false
    //     0x839468: add             x1, NULL, #0x30  ; false
    // 0x83946c: StoreField: r0->field_b = r1
    //     0x83946c: stur            w1, [x0, #0xb]
    // 0x839470: ldur            x1, [fp, #-0x10]
    // 0x839474: StoreField: r0->field_7 = r1
    //     0x839474: stur            w1, [x0, #7]
    // 0x839478: ldur            x1, [fp, #-8]
    // 0x83947c: StoreField: r1->field_3b = r0
    //     0x83947c: stur            w0, [x1, #0x3b]
    //     0x839480: ldurb           w16, [x1, #-1]
    //     0x839484: ldurb           w17, [x0, #-1]
    //     0x839488: and             x16, x17, x16, lsr #2
    //     0x83948c: tst             x16, HEAP, lsr #32
    //     0x839490: b.eq            #0x839498
    //     0x839494: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x839498: r0 = Null
    //     0x839498: mov             x0, NULL
    // 0x83949c: LeaveFrame
    //     0x83949c: mov             SP, fp
    //     0x8394a0: ldp             fp, lr, [SP], #0x10
    // 0x8394a4: ret
    //     0x8394a4: ret             
    // 0x8394a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8394a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8394ac: b               #0x839354
  }
  _ _buildSemanticsSubtree(/* No info */) {
    // ** addr: 0x88deb8, size: 0x3f0
    // 0x88deb8: EnterFrame
    //     0x88deb8: stp             fp, lr, [SP, #-0x10]!
    //     0x88debc: mov             fp, SP
    // 0x88dec0: AllocStack(0x50)
    //     0x88dec0: sub             SP, SP, #0x50
    // 0x88dec4: SetupParameters(_RenderObjectSemantics this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x88dec4: mov             x3, x1
    //     0x88dec8: mov             x0, x2
    //     0x88decc: stur            x1, [fp, #-8]
    //     0x88ded0: stur            x2, [fp, #-0x10]
    // 0x88ded4: CheckStackOverflow
    //     0x88ded4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88ded8: cmp             SP, x16
    //     0x88dedc: b.ls            #0x88e290
    // 0x88dee0: r1 = <SemanticsNode>
    //     0x88dee0: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0x88dee4: r2 = 0
    //     0x88dee4: mov             x2, #0
    // 0x88dee8: r0 = _GrowableList()
    //     0x88dee8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x88deec: mov             x3, x0
    // 0x88def0: ldur            x2, [fp, #-8]
    // 0x88def4: stur            x3, [fp, #-0x38]
    // 0x88def8: LoadField: r4 = r2->field_27
    //     0x88def8: ldur            w4, [x2, #0x27]
    // 0x88defc: DecompressPointer r4
    //     0x88defc: add             x4, x4, HEAP, lsl #32
    // 0x88df00: stur            x4, [fp, #-0x30]
    // 0x88df04: LoadField: r0 = r4->field_b
    //     0x88df04: ldur            w0, [x4, #0xb]
    // 0x88df08: r5 = LoadInt32Instr(r0)
    //     0x88df08: sbfx            x5, x0, #1, #0x1f
    // 0x88df0c: stur            x5, [fp, #-0x28]
    // 0x88df10: r0 = 0
    //     0x88df10: mov             x0, #0
    // 0x88df14: ldur            x6, [fp, #-0x10]
    // 0x88df18: CheckStackOverflow
    //     0x88df18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x88df1c: cmp             SP, x16
    //     0x88df20: b.ls            #0x88e298
    // 0x88df24: LoadField: r1 = r4->field_b
    //     0x88df24: ldur            w1, [x4, #0xb]
    // 0x88df28: r7 = LoadInt32Instr(r1)
    //     0x88df28: sbfx            x7, x1, #1, #0x1f
    // 0x88df2c: cmp             x5, x7
    // 0x88df30: b.ne            #0x88e270
    // 0x88df34: cmp             x0, x7
    // 0x88df38: b.ge            #0x88e078
    // 0x88df3c: LoadField: r1 = r4->field_f
    //     0x88df3c: ldur            w1, [x4, #0xf]
    // 0x88df40: DecompressPointer r1
    //     0x88df40: add             x1, x1, HEAP, lsl #32
    // 0x88df44: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0x88df44: add             x16, x1, x0, lsl #2
    //     0x88df48: ldur            w7, [x16, #0xf]
    // 0x88df4c: DecompressPointer r7
    //     0x88df4c: add             x7, x7, HEAP, lsl #32
    // 0x88df50: stur            x7, [fp, #-0x20]
    // 0x88df54: add             x8, x0, #1
    // 0x88df58: stur            x8, [fp, #-0x18]
    // 0x88df5c: LoadField: r1 = r7->field_7
    //     0x88df5c: ldur            w1, [x7, #7]
    // 0x88df60: DecompressPointer r1
    //     0x88df60: add             x1, x1, HEAP, lsl #32
    // 0x88df64: r0 = LoadClassIdInstr(r1)
    //     0x88df64: ldur            x0, [x1, #-1]
    //     0x88df68: ubfx            x0, x0, #0xc, #0x14
    // 0x88df6c: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x88df6c: mov             x17, #0xfc0
    //     0x88df70: movk            x17, #1, lsl #16
    //     0x88df74: add             lr, x0, x17
    //     0x88df78: ldr             lr, [x21, lr, lsl #3]
    //     0x88df7c: blr             lr
    // 0x88df80: cmp             w0, NULL
    // 0x88df84: b.ne            #0x88df90
    // 0x88df88: ldur            x3, [fp, #-0x20]
    // 0x88df8c: b               #0x88dfc8
    // 0x88df90: ldur            x2, [fp, #-0x20]
    // 0x88df94: mov             x1, x0
    // 0x88df98: LoadField: r0 = r1->field_43
    //     0x88df98: ldur            w0, [x1, #0x43]
    // 0x88df9c: DecompressPointer r0
    //     0x88df9c: add             x0, x0, HEAP, lsl #32
    // 0x88dfa0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x88dfa4: cmp             w0, w16
    // 0x88dfa8: b.ne            #0x88dfb4
    // 0x88dfac: r2 = _semantics
    //     0x88dfac: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x88dfb0: r0 = InitLateFinalInstanceField()
    //     0x88dfb0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x88dfb4: ldur            x3, [fp, #-0x20]
    // 0x88dfb8: LoadField: r0 = r3->field_33
    //     0x88dfb8: ldur            w0, [x3, #0x33]
    // 0x88dfbc: DecompressPointer r0
    //     0x88dfbc: add             x0, x0, HEAP, lsl #32
    // 0x88dfc0: cmp             w0, NULL
    // 0x88dfc4: b.eq            #0x88e060
    // 0x88dfc8: LoadField: r0 = r3->field_1b
    //     0x88dfc8: ldur            w0, [x3, #0x1b]
    // 0x88dfcc: DecompressPointer r0
    //     0x88dfcc: add             x0, x0, HEAP, lsl #32
    // 0x88dfd0: cmp             w0, NULL
    // 0x88dfd4: b.eq            #0x88e03c
    // 0x88dfd8: ldur            x4, [fp, #-0x10]
    // 0x88dfdc: LoadField: r2 = r0->field_b
    //     0x88dfdc: ldur            x2, [x0, #0xb]
    // 0x88dfe0: LoadField: r5 = r4->field_f
    //     0x88dfe0: ldur            w5, [x4, #0xf]
    // 0x88dfe4: DecompressPointer r5
    //     0x88dfe4: add             x5, x5, HEAP, lsl #32
    // 0x88dfe8: stur            x5, [fp, #-0x40]
    // 0x88dfec: r0 = BoxInt64Instr(r2)
    //     0x88dfec: sbfiz           x0, x2, #1, #0x1f
    //     0x88dff0: cmp             x2, x0, asr #1
    //     0x88dff4: b.eq            #0x88e000
    //     0x88dff8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x88dffc: stur            x2, [x0, #7]
    // 0x88e000: mov             x1, x4
    // 0x88e004: mov             x2, x0
    // 0x88e008: r0 = _getKeyOrData()
    //     0x88e008: bl              #0x84b72c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x88e00c: mov             x1, x0
    // 0x88e010: ldur            x0, [fp, #-0x40]
    // 0x88e014: cmp             w0, w1
    // 0x88e018: b.eq            #0x88e034
    // 0x88e01c: ldur            x0, [fp, #-0x20]
    // 0x88e020: mov             x1, x0
    // 0x88e024: r0 = markNeedsBuild()
    //     0x88e024: bl              #0x890088  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::markNeedsBuild
    // 0x88e028: ldur            x0, [fp, #-0x20]
    // 0x88e02c: StoreField: r0->field_1b = rNULL
    //     0x88e02c: stur            NULL, [x0, #0x1b]
    // 0x88e030: b               #0x88e040
    // 0x88e034: ldur            x0, [fp, #-0x20]
    // 0x88e038: b               #0x88e040
    // 0x88e03c: mov             x0, x3
    // 0x88e040: mov             x1, x0
    // 0x88e044: ldur            x2, [fp, #-0x10]
    // 0x88e048: r0 = _buildSemantics()
    //     0x88e048: bl              #0x891358  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_buildSemantics
    // 0x88e04c: ldur            x0, [fp, #-0x20]
    // 0x88e050: LoadField: r2 = r0->field_1f
    //     0x88e050: ldur            w2, [x0, #0x1f]
    // 0x88e054: DecompressPointer r2
    //     0x88e054: add             x2, x2, HEAP, lsl #32
    // 0x88e058: ldur            x1, [fp, #-0x38]
    // 0x88e05c: r0 = addAll()
    //     0x88e05c: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x88e060: ldur            x0, [fp, #-0x18]
    // 0x88e064: ldur            x2, [fp, #-8]
    // 0x88e068: ldur            x3, [fp, #-0x38]
    // 0x88e06c: ldur            x4, [fp, #-0x30]
    // 0x88e070: ldur            x5, [fp, #-0x28]
    // 0x88e074: b               #0x88df14
    // 0x88e078: mov             x0, x2
    // 0x88e07c: LoadField: r3 = r0->field_1b
    //     0x88e07c: ldur            w3, [x0, #0x1b]
    // 0x88e080: DecompressPointer r3
    //     0x88e080: add             x3, x3, HEAP, lsl #32
    // 0x88e084: stur            x3, [fp, #-0x10]
    // 0x88e088: cmp             w3, NULL
    // 0x88e08c: b.eq            #0x88e2a0
    // 0x88e090: ldur            x1, [fp, #-0x38]
    // 0x88e094: r2 = Closure: (SemanticsNode) => bool from Function 'shouldDrop': static.
    //     0x88e094: ldr             x2, [PP, #0x28a8]  ; [pp+0x28a8] Closure: (SemanticsNode) => bool from Function 'shouldDrop': static. (0x7f2ada77804c)
    // 0x88e098: r0 = removeWhere()
    //     0x88e098: bl              #0x843124  ; [dart:collection] ListBase::removeWhere
    // 0x88e09c: ldur            x0, [fp, #-8]
    // 0x88e0a0: LoadField: r2 = r0->field_3b
    //     0x88e0a0: ldur            w2, [x0, #0x3b]
    // 0x88e0a4: DecompressPointer r2
    //     0x88e0a4: add             x2, x2, HEAP, lsl #32
    // 0x88e0a8: mov             x1, x2
    // 0x88e0ac: stur            x2, [fp, #-0x20]
    // 0x88e0b0: r0 = original()
    //     0x88e0b0: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x88e0b4: LoadField: r1 = r0->field_c3
    //     0x88e0b4: ldur            w1, [x0, #0xc3]
    // 0x88e0b8: DecompressPointer r1
    //     0x88e0b8: add             x1, x1, HEAP, lsl #32
    // 0x88e0bc: LoadField: r0 = r1->field_47
    //     0x88e0bc: ldur            w0, [x1, #0x47]
    // 0x88e0c0: DecompressPointer r0
    //     0x88e0c0: add             x0, x0, HEAP, lsl #32
    // 0x88e0c4: tbnz            w0, #4, #0x88e0d4
    // 0x88e0c8: ldur            x0, [fp, #-8]
    // 0x88e0cc: r2 = true
    //     0x88e0cc: add             x2, NULL, #0x20  ; true
    // 0x88e0d0: b               #0x88e128
    // 0x88e0d4: ldur            x0, [fp, #-8]
    // 0x88e0d8: LoadField: r1 = r0->field_33
    //     0x88e0d8: ldur            w1, [x0, #0x33]
    // 0x88e0dc: DecompressPointer r1
    //     0x88e0dc: add             x1, x1, HEAP, lsl #32
    // 0x88e0e0: cmp             w1, NULL
    // 0x88e0e4: b.ne            #0x88e0f0
    // 0x88e0e8: r1 = Null
    //     0x88e0e8: mov             x1, NULL
    // 0x88e0ec: b               #0x88e0fc
    // 0x88e0f0: LoadField: r2 = r1->field_7
    //     0x88e0f0: ldur            w2, [x1, #7]
    // 0x88e0f4: DecompressPointer r2
    //     0x88e0f4: add             x2, x2, HEAP, lsl #32
    // 0x88e0f8: mov             x1, x2
    // 0x88e0fc: cmp             w1, NULL
    // 0x88e100: b.eq            #0x88e108
    // 0x88e104: tbz             w1, #4, #0x88e124
    // 0x88e108: LoadField: r1 = r0->field_37
    //     0x88e108: ldur            w1, [x0, #0x37]
    // 0x88e10c: DecompressPointer r1
    //     0x88e10c: add             x1, x1, HEAP, lsl #32
    // 0x88e110: cmp             w1, NULL
    // 0x88e114: b.eq            #0x88e2a4
    // 0x88e118: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x88e118: ldur            w2, [x1, #0x17]
    // 0x88e11c: DecompressPointer r2
    //     0x88e11c: add             x2, x2, HEAP, lsl #32
    // 0x88e120: b               #0x88e128
    // 0x88e124: r2 = false
    //     0x88e124: add             x2, NULL, #0x30  ; false
    // 0x88e128: ldur            x1, [fp, #-0x20]
    // 0x88e12c: stur            x2, [fp, #-0x40]
    // 0x88e130: r1 = 1
    //     0x88e130: mov             x1, #1
    // 0x88e134: r0 = AllocateContext()
    //     0x88e134: bl              #0x13de838  ; AllocateContextStub
    // 0x88e138: mov             x2, x0
    // 0x88e13c: ldur            x0, [fp, #-0x40]
    // 0x88e140: stur            x2, [fp, #-0x48]
    // 0x88e144: StoreField: r2->field_f = r0
    //     0x88e144: stur            w0, [x2, #0xf]
    // 0x88e148: ldur            x3, [fp, #-0x20]
    // 0x88e14c: LoadField: r1 = r3->field_13
    //     0x88e14c: ldur            w1, [x3, #0x13]
    // 0x88e150: DecompressPointer r1
    //     0x88e150: add             x1, x1, HEAP, lsl #32
    // 0x88e154: cmp             w1, NULL
    // 0x88e158: b.ne            #0x88e168
    // 0x88e15c: mov             x1, x3
    // 0x88e160: r0 = original()
    //     0x88e160: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x88e164: mov             x1, x0
    // 0x88e168: ldur            x0, [fp, #-0x40]
    // 0x88e16c: LoadField: r2 = r1->field_c3
    //     0x88e16c: ldur            w2, [x1, #0xc3]
    // 0x88e170: DecompressPointer r2
    //     0x88e170: add             x2, x2, HEAP, lsl #32
    // 0x88e174: LoadField: r1 = r2->field_47
    //     0x88e174: ldur            w1, [x2, #0x47]
    // 0x88e178: DecompressPointer r1
    //     0x88e178: add             x1, x1, HEAP, lsl #32
    // 0x88e17c: cmp             w1, w0
    // 0x88e180: b.eq            #0x88e19c
    // 0x88e184: ldur            x2, [fp, #-0x48]
    // 0x88e188: r1 = Function '<anonymous closure>':.
    //     0x88e188: ldr             x1, [PP, #0x28b0]  ; [pp+0x28b0] AnonymousClosure: (0x8904f4), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_buildSemanticsSubtree (0x88deb8)
    // 0x88e18c: r0 = AllocateClosure()
    //     0x88e18c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x88e190: ldur            x1, [fp, #-0x20]
    // 0x88e194: mov             x2, x0
    // 0x88e198: r0 = updateConfig()
    //     0x88e198: bl              #0x88fa6c  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::updateConfig
    // 0x88e19c: ldur            x0, [fp, #-0x20]
    // 0x88e1a0: LoadField: r1 = r0->field_13
    //     0x88e1a0: ldur            w1, [x0, #0x13]
    // 0x88e1a4: DecompressPointer r1
    //     0x88e1a4: add             x1, x1, HEAP, lsl #32
    // 0x88e1a8: cmp             w1, NULL
    // 0x88e1ac: b.ne            #0x88e1bc
    // 0x88e1b0: mov             x1, x0
    // 0x88e1b4: r0 = original()
    //     0x88e1b4: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x88e1b8: b               #0x88e1c0
    // 0x88e1bc: mov             x0, x1
    // 0x88e1c0: LoadField: r1 = r0->field_7
    //     0x88e1c0: ldur            w1, [x0, #7]
    // 0x88e1c4: DecompressPointer r1
    //     0x88e1c4: add             x1, x1, HEAP, lsl #32
    // 0x88e1c8: tbnz            w1, #4, #0x88e228
    // 0x88e1cc: ldur            x0, [fp, #-8]
    // 0x88e1d0: ldur            x1, [fp, #-0x20]
    // 0x88e1d4: LoadField: r2 = r0->field_7
    //     0x88e1d4: ldur            w2, [x0, #7]
    // 0x88e1d8: DecompressPointer r2
    //     0x88e1d8: add             x2, x2, HEAP, lsl #32
    // 0x88e1dc: stur            x2, [fp, #-0x40]
    // 0x88e1e0: LoadField: r0 = r1->field_13
    //     0x88e1e0: ldur            w0, [x1, #0x13]
    // 0x88e1e4: DecompressPointer r0
    //     0x88e1e4: add             x0, x0, HEAP, lsl #32
    // 0x88e1e8: cmp             w0, NULL
    // 0x88e1ec: b.ne            #0x88e1fc
    // 0x88e1f0: r0 = original()
    //     0x88e1f0: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x88e1f4: mov             x3, x0
    // 0x88e1f8: b               #0x88e200
    // 0x88e1fc: mov             x3, x0
    // 0x88e200: ldur            x1, [fp, #-0x40]
    // 0x88e204: r0 = LoadClassIdInstr(r1)
    //     0x88e204: ldur            x0, [x1, #-1]
    //     0x88e208: ubfx            x0, x0, #0xc, #0x14
    // 0x88e20c: ldur            x2, [fp, #-0x10]
    // 0x88e210: ldur            x5, [fp, #-0x38]
    // 0x88e214: r0 = GDT[cid_x0 + 0xf069]()
    //     0x88e214: mov             x17, #0xf069
    //     0x88e218: add             lr, x0, x17
    //     0x88e21c: ldr             lr, [x21, lr, lsl #3]
    //     0x88e220: blr             lr
    // 0x88e224: b               #0x88e260
    // 0x88e228: ldur            x1, [fp, #-0x20]
    // 0x88e22c: LoadField: r0 = r1->field_13
    //     0x88e22c: ldur            w0, [x1, #0x13]
    // 0x88e230: DecompressPointer r0
    //     0x88e230: add             x0, x0, HEAP, lsl #32
    // 0x88e234: cmp             w0, NULL
    // 0x88e238: b.ne            #0x88e248
    // 0x88e23c: r0 = original()
    //     0x88e23c: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x88e240: mov             x2, x0
    // 0x88e244: b               #0x88e24c
    // 0x88e248: mov             x2, x0
    // 0x88e24c: ldur            x16, [fp, #-0x38]
    // 0x88e250: str             x16, [SP]
    // 0x88e254: ldur            x1, [fp, #-0x10]
    // 0x88e258: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0x88e258: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0x88e25c: r0 = updateWith()
    //     0x88e25c: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0x88e260: r0 = Null
    //     0x88e260: mov             x0, NULL
    // 0x88e264: LeaveFrame
    //     0x88e264: mov             SP, fp
    //     0x88e268: ldp             fp, lr, [SP], #0x10
    // 0x88e26c: ret
    //     0x88e26c: ret             
    // 0x88e270: mov             x0, x4
    // 0x88e274: r0 = ConcurrentModificationError()
    //     0x88e274: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x88e278: mov             x1, x0
    // 0x88e27c: ldur            x0, [fp, #-0x30]
    // 0x88e280: StoreField: r1->field_b = r0
    //     0x88e280: stur            w0, [x1, #0xb]
    // 0x88e284: mov             x0, x1
    // 0x88e288: r0 = Throw()
    //     0x88e288: bl              #0x13ddb2c  ; ThrowStub
    // 0x88e28c: brk             #0
    // 0x88e290: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88e290: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88e294: b               #0x88dee0
    // 0x88e298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x88e298: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x88e29c: b               #0x88df24
    // 0x88e2a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x88e2a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x88e2a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x88e2a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsBuild(/* No info */) {
    // ** addr: 0x890088, size: 0x46c
    // 0x890088: EnterFrame
    //     0x890088: stp             fp, lr, [SP, #-0x10]!
    //     0x89008c: mov             fp, SP
    // 0x890090: AllocStack(0x48)
    //     0x890090: sub             SP, SP, #0x48
    // 0x890094: r0 = false
    //     0x890094: add             x0, NULL, #0x30  ; false
    // 0x890098: mov             x2, x1
    // 0x89009c: stur            x1, [fp, #-8]
    // 0x8900a0: CheckStackOverflow
    //     0x8900a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8900a4: cmp             SP, x16
    //     0x8900a8: b.ls            #0x8904d0
    // 0x8900ac: ArrayStore: r2[0] = r0  ; List_4
    //     0x8900ac: stur            w0, [x2, #0x17]
    // 0x8900b0: LoadField: r1 = r2->field_7
    //     0x8900b0: ldur            w1, [x2, #7]
    // 0x8900b4: DecompressPointer r1
    //     0x8900b4: add             x1, x1, HEAP, lsl #32
    // 0x8900b8: r0 = LoadClassIdInstr(r1)
    //     0x8900b8: ldur            x0, [x1, #-1]
    //     0x8900bc: ubfx            x0, x0, #0xc, #0x14
    // 0x8900c0: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x8900c0: mov             x17, #0xfc0
    //     0x8900c4: movk            x17, #1, lsl #16
    //     0x8900c8: add             lr, x0, x17
    //     0x8900cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8900d0: blr             lr
    // 0x8900d4: cmp             w0, NULL
    // 0x8900d8: b.ne            #0x8900e4
    // 0x8900dc: ldur            x0, [fp, #-8]
    // 0x8900e0: b               #0x89011c
    // 0x8900e4: ldur            x2, [fp, #-8]
    // 0x8900e8: mov             x1, x0
    // 0x8900ec: LoadField: r0 = r1->field_43
    //     0x8900ec: ldur            w0, [x1, #0x43]
    // 0x8900f0: DecompressPointer r0
    //     0x8900f0: add             x0, x0, HEAP, lsl #32
    // 0x8900f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8900f8: cmp             w0, w16
    // 0x8900fc: b.ne            #0x890108
    // 0x890100: r2 = _semantics
    //     0x890100: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x890104: r0 = InitLateFinalInstanceField()
    //     0x890104: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x890108: ldur            x0, [fp, #-8]
    // 0x89010c: LoadField: r1 = r0->field_33
    //     0x89010c: ldur            w1, [x0, #0x33]
    // 0x890110: DecompressPointer r1
    //     0x890110: add             x1, x1, HEAP, lsl #32
    // 0x890114: cmp             w1, NULL
    // 0x890118: b.eq            #0x890138
    // 0x89011c: mov             x1, x0
    // 0x890120: r0 = shouldFormSemanticsNode()
    //     0x890120: bl              #0x895ca4  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::shouldFormSemanticsNode
    // 0x890124: tbz             w0, #4, #0x890138
    // 0x890128: r0 = Null
    //     0x890128: mov             x0, NULL
    // 0x89012c: LeaveFrame
    //     0x89012c: mov             SP, fp
    //     0x890130: ldp             fp, lr, [SP], #0x10
    // 0x890134: ret
    //     0x890134: ret             
    // 0x890138: ldur            x0, [fp, #-8]
    // 0x89013c: LoadField: r1 = r0->field_2b
    //     0x89013c: ldur            w1, [x0, #0x2b]
    // 0x890140: DecompressPointer r1
    //     0x890140: add             x1, x1, HEAP, lsl #32
    // 0x890144: stur            x1, [fp, #-0x20]
    // 0x890148: LoadField: r0 = r1->field_b
    //     0x890148: ldur            w0, [x1, #0xb]
    // 0x89014c: r2 = LoadInt32Instr(r0)
    //     0x89014c: sbfx            x2, x0, #1, #0x1f
    // 0x890150: stur            x2, [fp, #-0x18]
    // 0x890154: r0 = 0
    //     0x890154: mov             x0, #0
    // 0x890158: CheckStackOverflow
    //     0x890158: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89015c: cmp             SP, x16
    //     0x890160: b.ls            #0x8904d8
    // 0x890164: LoadField: r3 = r1->field_b
    //     0x890164: ldur            w3, [x1, #0xb]
    // 0x890168: r4 = LoadInt32Instr(r3)
    //     0x890168: sbfx            x4, x3, #1, #0x1f
    // 0x89016c: cmp             x2, x4
    // 0x890170: b.ne            #0x8904b0
    // 0x890174: cmp             x0, x4
    // 0x890178: b.ge            #0x8904a0
    // 0x89017c: LoadField: r3 = r1->field_f
    //     0x89017c: ldur            w3, [x1, #0xf]
    // 0x890180: DecompressPointer r3
    //     0x890180: add             x3, x3, HEAP, lsl #32
    // 0x890184: ArrayLoad: r4 = r3[r0]  ; Unknown_4
    //     0x890184: add             x16, x3, x0, lsl #2
    //     0x890188: ldur            w4, [x16, #0xf]
    // 0x89018c: DecompressPointer r4
    //     0x89018c: add             x4, x4, HEAP, lsl #32
    // 0x890190: add             x3, x0, #1
    // 0x890194: stur            x3, [fp, #-0x10]
    // 0x890198: r0 = LoadClassIdInstr(r4)
    //     0x890198: ldur            x0, [x4, #-1]
    //     0x89019c: ubfx            x0, x0, #0xc, #0x14
    // 0x8901a0: r16 = <_RenderObjectSemantics>
    //     0x8901a0: ldr             x16, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x8901a4: stp             x4, x16, [SP]
    // 0x8901a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8901a8: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8901ac: r0 = GDT[cid_x0 + 0x10d40]()
    //     0x8901ac: mov             x17, #0xd40
    //     0x8901b0: movk            x17, #1, lsl #16
    //     0x8901b4: add             lr, x0, x17
    //     0x8901b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8901bc: blr             lr
    // 0x8901c0: LoadField: r2 = r0->field_7
    //     0x8901c0: ldur            w2, [x0, #7]
    // 0x8901c4: DecompressPointer r2
    //     0x8901c4: add             x2, x2, HEAP, lsl #32
    // 0x8901c8: stur            x2, [fp, #-8]
    // 0x8901cc: LoadField: r1 = r0->field_b
    //     0x8901cc: ldur            w1, [x0, #0xb]
    // 0x8901d0: DecompressPointer r1
    //     0x8901d0: add             x1, x1, HEAP, lsl #32
    // 0x8901d4: r0 = LoadClassIdInstr(r1)
    //     0x8901d4: ldur            x0, [x1, #-1]
    //     0x8901d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8901dc: r0 = GDT[cid_x0 + 0x12641]()
    //     0x8901dc: mov             x17, #0x2641
    //     0x8901e0: movk            x17, #1, lsl #16
    //     0x8901e4: add             lr, x0, x17
    //     0x8901e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8901ec: blr             lr
    // 0x8901f0: mov             x2, x0
    // 0x8901f4: stur            x2, [fp, #-0x28]
    // 0x8901f8: CheckStackOverflow
    //     0x8901f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8901fc: cmp             SP, x16
    //     0x890200: b.ls            #0x8904e0
    // 0x890204: CheckStackOverflow
    //     0x890204: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x890208: cmp             SP, x16
    //     0x89020c: b.ls            #0x8904e8
    // 0x890210: r0 = LoadClassIdInstr(r2)
    //     0x890210: ldur            x0, [x2, #-1]
    //     0x890214: ubfx            x0, x0, #0xc, #0x14
    // 0x890218: mov             x1, x2
    // 0x89021c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x89021c: mov             x17, #0x845b
    //     0x890220: movk            x17, #1, lsl #16
    //     0x890224: add             lr, x0, x17
    //     0x890228: ldr             lr, [x21, lr, lsl #3]
    //     0x89022c: blr             lr
    // 0x890230: tbnz            w0, #4, #0x890490
    // 0x890234: ldur            x2, [fp, #-0x28]
    // 0x890238: r0 = LoadClassIdInstr(r2)
    //     0x890238: ldur            x0, [x2, #-1]
    //     0x89023c: ubfx            x0, x0, #0xc, #0x14
    // 0x890240: mov             x1, x2
    // 0x890244: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x890244: mov             x17, #0x7d4c
    //     0x890248: movk            x17, #1, lsl #16
    //     0x89024c: add             lr, x0, x17
    //     0x890250: ldr             lr, [x21, lr, lsl #3]
    //     0x890254: blr             lr
    // 0x890258: ldur            x2, [fp, #-8]
    // 0x89025c: r1 = Null
    //     0x89025c: mov             x1, NULL
    // 0x890260: cmp             w2, NULL
    // 0x890264: b.eq            #0x8902f0
    // 0x890268: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x890268: ldur            w3, [x2, #0x17]
    // 0x89026c: DecompressPointer r3
    //     0x89026c: add             x3, x3, HEAP, lsl #32
    // 0x890270: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x890274: cmp             w3, w16
    // 0x890278: b.eq            #0x8902f0
    // 0x89027c: r16 = Object?
    //     0x89027c: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x890280: cmp             w3, w16
    // 0x890284: b.eq            #0x8902f0
    // 0x890288: r16 = void?
    //     0x890288: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x89028c: cmp             w3, w16
    // 0x890290: b.eq            #0x8902f0
    // 0x890294: tbnz            w0, #0, #0x8902b0
    // 0x890298: r16 = int
    //     0x890298: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x89029c: cmp             w3, w16
    // 0x8902a0: b.eq            #0x8902f0
    // 0x8902a4: r16 = num
    //     0x8902a4: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x8902a8: cmp             w3, w16
    // 0x8902ac: b.eq            #0x8902f0
    // 0x8902b0: r3 = SubtypeTestCache
    //     0x8902b0: ldr             x3, [PP, #0x2988]  ; [pp+0x2988] SubtypeTestCache
    // 0x8902b4: r30 = Subtype6TestCacheStub
    //     0x8902b4: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0x8902b8: LoadField: r30 = r30->field_7
    //     0x8902b8: ldur            lr, [lr, #7]
    // 0x8902bc: blr             lr
    // 0x8902c0: cmp             w7, NULL
    // 0x8902c4: b.eq            #0x8902d0
    // 0x8902c8: tbnz            w7, #4, #0x8902e8
    // 0x8902cc: b               #0x8902f0
    // 0x8902d0: r8 = X0
    //     0x8902d0: ldr             x8, [PP, #0x2990]  ; [pp+0x2990] TypeParameter: X0
    // 0x8902d4: r3 = SubtypeTestCache
    //     0x8902d4: ldr             x3, [PP, #0x2998]  ; [pp+0x2998] SubtypeTestCache
    // 0x8902d8: r30 = InstanceOfStub
    //     0x8902d8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x8902dc: LoadField: r30 = r30->field_7
    //     0x8902dc: ldur            lr, [lr, #7]
    // 0x8902e0: blr             lr
    // 0x8902e4: b               #0x8902f4
    // 0x8902e8: r0 = false
    //     0x8902e8: add             x0, NULL, #0x30  ; false
    // 0x8902ec: b               #0x8902f4
    // 0x8902f0: r0 = true
    //     0x8902f0: add             x0, NULL, #0x20  ; true
    // 0x8902f4: tbz             w0, #4, #0x890300
    // 0x8902f8: ldur            x2, [fp, #-0x28]
    // 0x8902fc: b               #0x890204
    // 0x890300: ldur            x2, [fp, #-0x28]
    // 0x890304: r0 = LoadClassIdInstr(r2)
    //     0x890304: ldur            x0, [x2, #-1]
    //     0x890308: ubfx            x0, x0, #0xc, #0x14
    // 0x89030c: mov             x1, x2
    // 0x890310: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x890310: mov             x17, #0x7d4c
    //     0x890314: movk            x17, #1, lsl #16
    //     0x890318: add             lr, x0, x17
    //     0x89031c: ldr             lr, [x21, lr, lsl #3]
    //     0x890320: blr             lr
    // 0x890324: ldur            x2, [fp, #-8]
    // 0x890328: mov             x3, x0
    // 0x89032c: r1 = Null
    //     0x89032c: mov             x1, NULL
    // 0x890330: stur            x3, [fp, #-0x30]
    // 0x890334: cmp             w2, NULL
    // 0x890338: b.eq            #0x890354
    // 0x89033c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x89033c: ldur            w4, [x2, #0x17]
    // 0x890340: DecompressPointer r4
    //     0x890340: add             x4, x4, HEAP, lsl #32
    // 0x890344: r8 = X0
    //     0x890344: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x890348: LoadField: r9 = r4->field_7
    //     0x890348: ldur            x9, [x4, #7]
    // 0x89034c: r3 = Null
    //     0x89034c: ldr             x3, [PP, #0x29a0]  ; [pp+0x29a0] Null
    // 0x890350: blr             x9
    // 0x890354: ldur            x2, [fp, #-0x30]
    // 0x890358: LoadField: r3 = r2->field_7
    //     0x890358: ldur            w3, [x2, #7]
    // 0x89035c: DecompressPointer r3
    //     0x89035c: add             x3, x3, HEAP, lsl #32
    // 0x890360: stur            x3, [fp, #-0x38]
    // 0x890364: r0 = LoadClassIdInstr(r3)
    //     0x890364: ldur            x0, [x3, #-1]
    //     0x890368: ubfx            x0, x0, #0xc, #0x14
    // 0x89036c: mov             x1, x3
    // 0x890370: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x890370: mov             x17, #0xfc0
    //     0x890374: movk            x17, #1, lsl #16
    //     0x890378: add             lr, x0, x17
    //     0x89037c: ldr             lr, [x21, lr, lsl #3]
    //     0x890380: blr             lr
    // 0x890384: cmp             w0, NULL
    // 0x890388: b.ne            #0x890394
    // 0x89038c: ldur            x0, [fp, #-0x30]
    // 0x890390: b               #0x8903cc
    // 0x890394: ldur            x2, [fp, #-0x30]
    // 0x890398: mov             x1, x0
    // 0x89039c: LoadField: r0 = r1->field_43
    //     0x89039c: ldur            w0, [x1, #0x43]
    // 0x8903a0: DecompressPointer r0
    //     0x8903a0: add             x0, x0, HEAP, lsl #32
    // 0x8903a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8903a8: cmp             w0, w16
    // 0x8903ac: b.ne            #0x8903b8
    // 0x8903b0: r2 = _semantics
    //     0x8903b0: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x8903b4: r0 = InitLateFinalInstanceField()
    //     0x8903b4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x8903b8: ldur            x0, [fp, #-0x30]
    // 0x8903bc: LoadField: r1 = r0->field_33
    //     0x8903bc: ldur            w1, [x0, #0x33]
    // 0x8903c0: DecompressPointer r1
    //     0x8903c0: add             x1, x1, HEAP, lsl #32
    // 0x8903c4: cmp             w1, NULL
    // 0x8903c8: b.eq            #0x890488
    // 0x8903cc: LoadField: r1 = r0->field_3b
    //     0x8903cc: ldur            w1, [x0, #0x3b]
    // 0x8903d0: DecompressPointer r1
    //     0x8903d0: add             x1, x1, HEAP, lsl #32
    // 0x8903d4: LoadField: r2 = r1->field_13
    //     0x8903d4: ldur            w2, [x1, #0x13]
    // 0x8903d8: DecompressPointer r2
    //     0x8903d8: add             x2, x2, HEAP, lsl #32
    // 0x8903dc: cmp             w2, NULL
    // 0x8903e0: b.ne            #0x8903ec
    // 0x8903e4: r0 = original()
    //     0x8903e4: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x8903e8: b               #0x8903f0
    // 0x8903ec: mov             x0, x2
    // 0x8903f0: LoadField: r1 = r0->field_7
    //     0x8903f0: ldur            w1, [x0, #7]
    // 0x8903f4: DecompressPointer r1
    //     0x8903f4: add             x1, x1, HEAP, lsl #32
    // 0x8903f8: tbz             w1, #4, #0x890488
    // 0x8903fc: ldur            x1, [fp, #-0x38]
    // 0x890400: r0 = LoadClassIdInstr(r1)
    //     0x890400: ldur            x0, [x1, #-1]
    //     0x890404: ubfx            x0, x0, #0xc, #0x14
    // 0x890408: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x890408: mov             x17, #0xfc0
    //     0x89040c: movk            x17, #1, lsl #16
    //     0x890410: add             lr, x0, x17
    //     0x890414: ldr             lr, [x21, lr, lsl #3]
    //     0x890418: blr             lr
    // 0x89041c: cmp             w0, NULL
    // 0x890420: b.eq            #0x890488
    // 0x890424: mov             x1, x0
    // 0x890428: LoadField: r0 = r1->field_43
    //     0x890428: ldur            w0, [x1, #0x43]
    // 0x89042c: DecompressPointer r0
    //     0x89042c: add             x0, x0, HEAP, lsl #32
    // 0x890430: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x890434: cmp             w0, w16
    // 0x890438: b.ne            #0x890444
    // 0x89043c: r2 = _semantics
    //     0x89043c: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x890440: r0 = InitLateFinalInstanceField()
    //     0x890440: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x890444: ldur            x1, [fp, #-0x30]
    // 0x890448: r0 = contributesToSemanticsTree()
    //     0x890448: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x89044c: tbz             w0, #4, #0x890458
    // 0x890450: ldur            x1, [fp, #-0x30]
    // 0x890454: b               #0x890484
    // 0x890458: ldur            x1, [fp, #-0x30]
    // 0x89045c: LoadField: r0 = r1->field_33
    //     0x89045c: ldur            w0, [x1, #0x33]
    // 0x890460: DecompressPointer r0
    //     0x890460: add             x0, x0, HEAP, lsl #32
    // 0x890464: cmp             w0, NULL
    // 0x890468: b.eq            #0x8904f0
    // 0x89046c: LoadField: r2 = r0->field_13
    //     0x89046c: ldur            w2, [x0, #0x13]
    // 0x890470: DecompressPointer r2
    //     0x890470: add             x2, x2, HEAP, lsl #32
    // 0x890474: tbz             w2, #4, #0x890488
    // 0x890478: LoadField: r0 = r1->field_b
    //     0x890478: ldur            w0, [x1, #0xb]
    // 0x89047c: DecompressPointer r0
    //     0x89047c: add             x0, x0, HEAP, lsl #32
    // 0x890480: tbz             w0, #4, #0x890488
    // 0x890484: r0 = markNeedsBuild()
    //     0x890484: bl              #0x890088  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::markNeedsBuild
    // 0x890488: ldur            x2, [fp, #-0x28]
    // 0x89048c: b               #0x8901f8
    // 0x890490: ldur            x0, [fp, #-0x10]
    // 0x890494: ldur            x1, [fp, #-0x20]
    // 0x890498: ldur            x2, [fp, #-0x18]
    // 0x89049c: b               #0x890158
    // 0x8904a0: r0 = Null
    //     0x8904a0: mov             x0, NULL
    // 0x8904a4: LeaveFrame
    //     0x8904a4: mov             SP, fp
    //     0x8904a8: ldp             fp, lr, [SP], #0x10
    // 0x8904ac: ret
    //     0x8904ac: ret             
    // 0x8904b0: mov             x0, x1
    // 0x8904b4: r0 = ConcurrentModificationError()
    //     0x8904b4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x8904b8: mov             x1, x0
    // 0x8904bc: ldur            x0, [fp, #-0x20]
    // 0x8904c0: StoreField: r1->field_b = r0
    //     0x8904c0: stur            w0, [x1, #0xb]
    // 0x8904c4: mov             x0, x1
    // 0x8904c8: r0 = Throw()
    //     0x8904c8: bl              #0x13ddb2c  ; ThrowStub
    // 0x8904cc: brk             #0
    // 0x8904d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8904d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8904d4: b               #0x8900ac
    // 0x8904d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8904d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8904dc: b               #0x890164
    // 0x8904e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8904e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8904e4: b               #0x890204
    // 0x8904e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8904e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8904ec: b               #0x890210
    // 0x8904f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8904f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, SemanticsConfiguration) {
    // ** addr: 0x8904f4, size: 0x48
    // 0x8904f4: EnterFrame
    //     0x8904f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8904f8: mov             fp, SP
    // 0x8904fc: ldr             x0, [fp, #0x18]
    // 0x890500: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x890500: ldur            w1, [x0, #0x17]
    // 0x890504: DecompressPointer r1
    //     0x890504: add             x1, x1, HEAP, lsl #32
    // 0x890508: CheckStackOverflow
    //     0x890508: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89050c: cmp             SP, x16
    //     0x890510: b.ls            #0x890534
    // 0x890514: LoadField: r2 = r1->field_f
    //     0x890514: ldur            w2, [x1, #0xf]
    // 0x890518: DecompressPointer r2
    //     0x890518: add             x2, x2, HEAP, lsl #32
    // 0x89051c: ldr             x1, [fp, #0x10]
    // 0x890520: r0 = isHidden=()
    //     0x890520: bl              #0x89053c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isHidden=
    // 0x890524: r0 = Null
    //     0x890524: mov             x0, NULL
    // 0x890528: LeaveFrame
    //     0x890528: mov             SP, fp
    //     0x89052c: ldp             fp, lr, [SP], #0x10
    // 0x890530: ret
    //     0x890530: ret             
    // 0x890534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x890534: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x890538: b               #0x890514
  }
  [closure] static bool shouldDrop(dynamic, SemanticsNode) {
    // ** addr: 0x89104c, size: 0x30
    // 0x89104c: EnterFrame
    //     0x89104c: stp             fp, lr, [SP, #-0x10]!
    //     0x891050: mov             fp, SP
    // 0x891054: CheckStackOverflow
    //     0x891054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891058: cmp             SP, x16
    //     0x89105c: b.ls            #0x891074
    // 0x891060: ldr             x1, [fp, #0x10]
    // 0x891064: r0 = isInvisible()
    //     0x891064: bl              #0x89107c  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::isInvisible
    // 0x891068: LeaveFrame
    //     0x891068: mov             SP, fp
    //     0x89106c: ldp             fp, lr, [SP], #0x10
    // 0x891070: ret
    //     0x891070: ret             
    // 0x891074: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x891074: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x891078: b               #0x891060
  }
  _ _buildSemantics(/* No info */) {
    // ** addr: 0x891358, size: 0x2f8
    // 0x891358: EnterFrame
    //     0x891358: stp             fp, lr, [SP, #-0x10]!
    //     0x89135c: mov             fp, SP
    // 0x891360: AllocStack(0x40)
    //     0x891360: sub             SP, SP, #0x40
    // 0x891364: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x891364: mov             x0, x1
    //     0x891368: stur            x1, [fp, #-8]
    //     0x89136c: stur            x2, [fp, #-0x10]
    // 0x891370: CheckStackOverflow
    //     0x891370: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891374: cmp             SP, x16
    //     0x891378: b.ls            #0x891634
    // 0x89137c: LoadField: r1 = r0->field_1b
    //     0x89137c: ldur            w1, [x0, #0x1b]
    // 0x891380: DecompressPointer r1
    //     0x891380: add             x1, x1, HEAP, lsl #32
    // 0x891384: cmp             w1, NULL
    // 0x891388: b.eq            #0x8913e0
    // 0x89138c: LoadField: r3 = r0->field_1f
    //     0x89138c: ldur            w3, [x0, #0x1f]
    // 0x891390: DecompressPointer r3
    //     0x891390: add             x3, x3, HEAP, lsl #32
    // 0x891394: LoadField: r4 = r3->field_b
    //     0x891394: ldur            w4, [x3, #0xb]
    // 0x891398: r5 = LoadInt32Instr(r4)
    //     0x891398: sbfx            x5, x4, #1, #0x1f
    // 0x89139c: LoadField: r4 = r3->field_f
    //     0x89139c: ldur            w4, [x3, #0xf]
    // 0x8913a0: DecompressPointer r4
    //     0x8913a0: add             x4, x4, HEAP, lsl #32
    // 0x8913a4: r3 = 0
    //     0x8913a4: mov             x3, #0
    // 0x8913a8: CheckStackOverflow
    //     0x8913a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8913ac: cmp             SP, x16
    //     0x8913b0: b.ls            #0x89163c
    // 0x8913b4: cmp             x3, x5
    // 0x8913b8: b.ge            #0x8913e0
    // 0x8913bc: ArrayLoad: r6 = r4[r3]  ; Unknown_4
    //     0x8913bc: add             x16, x4, x3, lsl #2
    //     0x8913c0: ldur            w6, [x16, #0xf]
    // 0x8913c4: DecompressPointer r6
    //     0x8913c4: add             x6, x6, HEAP, lsl #32
    // 0x8913c8: add             x7, x3, #1
    // 0x8913cc: cmp             w6, w1
    // 0x8913d0: b.eq            #0x8913d8
    // 0x8913d4: StoreField: r6->field_6b = rNULL
    //     0x8913d4: stur            NULL, [x6, #0x6b]
    // 0x8913d8: mov             x3, x7
    // 0x8913dc: b               #0x8913a8
    // 0x8913e0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8913e0: ldur            w1, [x0, #0x17]
    // 0x8913e4: DecompressPointer r1
    //     0x8913e4: add             x1, x1, HEAP, lsl #32
    // 0x8913e8: tbz             w1, #4, #0x891414
    // 0x8913ec: LoadField: r1 = r0->field_1f
    //     0x8913ec: ldur            w1, [x0, #0x1f]
    // 0x8913f0: DecompressPointer r1
    //     0x8913f0: add             x1, x1, HEAP, lsl #32
    // 0x8913f4: r0 = clear()
    //     0x8913f4: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x8913f8: ldur            x0, [fp, #-8]
    // 0x8913fc: LoadField: r1 = r0->field_2f
    //     0x8913fc: ldur            w1, [x0, #0x2f]
    // 0x891400: DecompressPointer r1
    //     0x891400: add             x1, x1, HEAP, lsl #32
    // 0x891404: r0 = clear()
    //     0x891404: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x891408: ldur            x1, [fp, #-8]
    // 0x89140c: ldur            x2, [fp, #-0x10]
    // 0x891410: r0 = _produceSemanticsNode()
    //     0x891410: bl              #0x891650  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_produceSemanticsNode
    // 0x891414: ldur            x0, [fp, #-8]
    // 0x891418: LoadField: r2 = r0->field_1b
    //     0x891418: ldur            w2, [x0, #0x1b]
    // 0x89141c: DecompressPointer r2
    //     0x89141c: add             x2, x2, HEAP, lsl #32
    // 0x891420: stur            x2, [fp, #-0x38]
    // 0x891424: cmp             w2, NULL
    // 0x891428: b.eq            #0x891644
    // 0x89142c: LoadField: r3 = r0->field_1f
    //     0x89142c: ldur            w3, [x0, #0x1f]
    // 0x891430: DecompressPointer r3
    //     0x891430: add             x3, x3, HEAP, lsl #32
    // 0x891434: stur            x3, [fp, #-0x30]
    // 0x891438: LoadField: r1 = r3->field_b
    //     0x891438: ldur            w1, [x3, #0xb]
    // 0x89143c: r4 = LoadInt32Instr(r1)
    //     0x89143c: sbfx            x4, x1, #1, #0x1f
    // 0x891440: stur            x4, [fp, #-0x28]
    // 0x891444: r1 = 0
    //     0x891444: mov             x1, #0
    // 0x891448: CheckStackOverflow
    //     0x891448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89144c: cmp             SP, x16
    //     0x891450: b.ls            #0x891648
    // 0x891454: LoadField: r5 = r3->field_b
    //     0x891454: ldur            w5, [x3, #0xb]
    // 0x891458: r6 = LoadInt32Instr(r5)
    //     0x891458: sbfx            x6, x5, #1, #0x1f
    // 0x89145c: cmp             x4, x6
    // 0x891460: b.ne            #0x891614
    // 0x891464: cmp             x1, x6
    // 0x891468: b.ge            #0x891604
    // 0x89146c: LoadField: r5 = r3->field_f
    //     0x89146c: ldur            w5, [x3, #0xf]
    // 0x891470: DecompressPointer r5
    //     0x891470: add             x5, x5, HEAP, lsl #32
    // 0x891474: ArrayLoad: r6 = r5[r1]  ; Unknown_4
    //     0x891474: add             x16, x5, x1, lsl #2
    //     0x891478: ldur            w6, [x16, #0xf]
    // 0x89147c: DecompressPointer r6
    //     0x89147c: add             x6, x6, HEAP, lsl #32
    // 0x891480: stur            x6, [fp, #-0x20]
    // 0x891484: add             x5, x1, #1
    // 0x891488: stur            x5, [fp, #-0x18]
    // 0x89148c: cmp             w6, w2
    // 0x891490: b.eq            #0x8915ec
    // 0x891494: LoadField: r1 = r0->field_33
    //     0x891494: ldur            w1, [x0, #0x33]
    // 0x891498: DecompressPointer r1
    //     0x891498: add             x1, x1, HEAP, lsl #32
    // 0x89149c: cmp             w1, NULL
    // 0x8914a0: b.ne            #0x8914ac
    // 0x8914a4: mov             x1, x6
    // 0x8914a8: b               #0x8915a0
    // 0x8914ac: ArrayLoad: r7 = r1[0]  ; List_4
    //     0x8914ac: ldur            w7, [x1, #0x17]
    // 0x8914b0: DecompressPointer r7
    //     0x8914b0: add             x7, x7, HEAP, lsl #32
    // 0x8914b4: stur            x7, [fp, #-0x10]
    // 0x8914b8: cmp             w7, NULL
    // 0x8914bc: b.eq            #0x89159c
    // 0x8914c0: LoadField: r8 = r6->field_6b
    //     0x8914c0: ldur            w8, [x6, #0x6b]
    // 0x8914c4: DecompressPointer r8
    //     0x8914c4: add             x8, x8, HEAP, lsl #32
    // 0x8914c8: cmp             w8, NULL
    // 0x8914cc: b.ne            #0x891524
    // 0x8914d0: r1 = <SemanticsTag>
    //     0x8914d0: ldr             x1, [PP, #0x2690]  ; [pp+0x2690] TypeArguments: <SemanticsTag>
    // 0x8914d4: r0 = _Set()
    //     0x8914d4: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x8914d8: mov             x2, x0
    // 0x8914dc: r3 = _Uint32List
    //     0x8914dc: ldr             x3, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x8914e0: StoreField: r2->field_1b = r3
    //     0x8914e0: stur            w3, [x2, #0x1b]
    // 0x8914e4: StoreField: r2->field_b = rZR
    //     0x8914e4: stur            wzr, [x2, #0xb]
    // 0x8914e8: r4 = const []
    //     0x8914e8: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x8914ec: StoreField: r2->field_f = r4
    //     0x8914ec: stur            w4, [x2, #0xf]
    // 0x8914f0: StoreField: r2->field_13 = rZR
    //     0x8914f0: stur            wzr, [x2, #0x13]
    // 0x8914f4: ArrayStore: r2[0] = rZR  ; List_4
    //     0x8914f4: stur            wzr, [x2, #0x17]
    // 0x8914f8: mov             x0, x2
    // 0x8914fc: ldur            x1, [fp, #-0x20]
    // 0x891500: StoreField: r1->field_6b = r0
    //     0x891500: stur            w0, [x1, #0x6b]
    //     0x891504: ldurb           w16, [x1, #-1]
    //     0x891508: ldurb           w17, [x0, #-1]
    //     0x89150c: and             x16, x17, x16, lsr #2
    //     0x891510: tst             x16, HEAP, lsr #32
    //     0x891514: b.eq            #0x89151c
    //     0x891518: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x89151c: mov             x5, x2
    // 0x891520: b               #0x891530
    // 0x891524: r3 = _Uint32List
    //     0x891524: ldr             x3, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x891528: r4 = const []
    //     0x891528: ldr             x4, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x89152c: mov             x5, x8
    // 0x891530: stur            x5, [fp, #-0x40]
    // 0x891534: LoadField: r2 = r5->field_7
    //     0x891534: ldur            w2, [x5, #7]
    // 0x891538: DecompressPointer r2
    //     0x891538: add             x2, x2, HEAP, lsl #32
    // 0x89153c: ldur            x0, [fp, #-0x10]
    // 0x891540: r1 = Null
    //     0x891540: mov             x1, NULL
    // 0x891544: r8 = Iterable<X0>
    //     0x891544: ldr             x8, [PP, #0xbb0]  ; [pp+0xbb0] Type: Iterable<X0>
    // 0x891548: LoadField: r9 = r8->field_7
    //     0x891548: ldur            x9, [x8, #7]
    // 0x89154c: r3 = Null
    //     0x89154c: ldr             x3, [PP, #0x29b0]  ; [pp+0x29b0] Null
    // 0x891550: blr             x9
    // 0x891554: r0 = 88
    //     0x891554: mov             x0, #0x58
    // 0x891558: cmp             x0, #0x58
    // 0x89155c: b.ne            #0x89158c
    // 0x891560: ldur            x3, [fp, #-0x40]
    // 0x891564: LoadField: r1 = r3->field_13
    //     0x891564: ldur            w1, [x3, #0x13]
    // 0x891568: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x891568: ldur            w2, [x3, #0x17]
    // 0x89156c: r4 = LoadInt32Instr(r1)
    //     0x89156c: sbfx            x4, x1, #1, #0x1f
    // 0x891570: r1 = LoadInt32Instr(r2)
    //     0x891570: sbfx            x1, x2, #1, #0x1f
    // 0x891574: sub             x2, x4, x1
    // 0x891578: cbnz            x2, #0x89158c
    // 0x89157c: mov             x1, x3
    // 0x891580: ldur            x2, [fp, #-0x10]
    // 0x891584: r0 = _quickCopy()
    //     0x891584: bl              #0x84bf9c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase::_quickCopy
    // 0x891588: tbz             w0, #4, #0x8915ec
    // 0x89158c: ldur            x1, [fp, #-0x40]
    // 0x891590: ldur            x2, [fp, #-0x10]
    // 0x891594: r0 = addAll()
    //     0x891594: bl              #0x84b954  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::addAll
    // 0x891598: b               #0x8915ec
    // 0x89159c: mov             x1, x6
    // 0x8915a0: LoadField: r0 = r1->field_6b
    //     0x8915a0: ldur            w0, [x1, #0x6b]
    // 0x8915a4: DecompressPointer r0
    //     0x8915a4: add             x0, x0, HEAP, lsl #32
    // 0x8915a8: cmp             w0, NULL
    // 0x8915ac: b.ne            #0x8915b8
    // 0x8915b0: r0 = Null
    //     0x8915b0: mov             x0, NULL
    // 0x8915b4: b               #0x8915dc
    // 0x8915b8: LoadField: r2 = r0->field_13
    //     0x8915b8: ldur            w2, [x0, #0x13]
    // 0x8915bc: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x8915bc: ldur            w3, [x0, #0x17]
    // 0x8915c0: r0 = LoadInt32Instr(r2)
    //     0x8915c0: sbfx            x0, x2, #1, #0x1f
    // 0x8915c4: r2 = LoadInt32Instr(r3)
    //     0x8915c4: sbfx            x2, x3, #1, #0x1f
    // 0x8915c8: sub             x3, x0, x2
    // 0x8915cc: cbz             x3, #0x8915d8
    // 0x8915d0: r0 = false
    //     0x8915d0: add             x0, NULL, #0x30  ; false
    // 0x8915d4: b               #0x8915dc
    // 0x8915d8: r0 = true
    //     0x8915d8: add             x0, NULL, #0x20  ; true
    // 0x8915dc: cmp             w0, NULL
    // 0x8915e0: b.eq            #0x8915ec
    // 0x8915e4: tbnz            w0, #4, #0x8915ec
    // 0x8915e8: StoreField: r1->field_6b = rNULL
    //     0x8915e8: stur            NULL, [x1, #0x6b]
    // 0x8915ec: ldur            x1, [fp, #-0x18]
    // 0x8915f0: ldur            x0, [fp, #-8]
    // 0x8915f4: ldur            x2, [fp, #-0x38]
    // 0x8915f8: ldur            x3, [fp, #-0x30]
    // 0x8915fc: ldur            x4, [fp, #-0x28]
    // 0x891600: b               #0x891448
    // 0x891604: r0 = Null
    //     0x891604: mov             x0, NULL
    // 0x891608: LeaveFrame
    //     0x891608: mov             SP, fp
    //     0x89160c: ldp             fp, lr, [SP], #0x10
    // 0x891610: ret
    //     0x891610: ret             
    // 0x891614: mov             x0, x3
    // 0x891618: r0 = ConcurrentModificationError()
    //     0x891618: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x89161c: mov             x1, x0
    // 0x891620: ldur            x0, [fp, #-0x30]
    // 0x891624: StoreField: r1->field_b = r0
    //     0x891624: stur            w0, [x1, #0xb]
    // 0x891628: mov             x0, x1
    // 0x89162c: r0 = Throw()
    //     0x89162c: bl              #0x13ddb2c  ; ThrowStub
    // 0x891630: brk             #0
    // 0x891634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x891634: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x891638: b               #0x89137c
    // 0x89163c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89163c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x891640: b               #0x8913b4
    // 0x891644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x891644: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x891648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x891648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89164c: b               #0x891454
  }
  _ _produceSemanticsNode(/* No info */) {
    // ** addr: 0x891650, size: 0x1c4
    // 0x891650: EnterFrame
    //     0x891650: stp             fp, lr, [SP, #-0x10]!
    //     0x891654: mov             fp, SP
    // 0x891658: AllocStack(0x28)
    //     0x891658: sub             SP, SP, #0x28
    // 0x89165c: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x89165c: mov             x0, x1
    //     0x891660: stur            x1, [fp, #-8]
    //     0x891664: stur            x2, [fp, #-0x10]
    // 0x891668: CheckStackOverflow
    //     0x891668: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89166c: cmp             SP, x16
    //     0x891670: b.ls            #0x89180c
    // 0x891674: LoadField: r1 = r0->field_1b
    //     0x891674: ldur            w1, [x0, #0x1b]
    // 0x891678: DecompressPointer r1
    //     0x891678: add             x1, x1, HEAP, lsl #32
    // 0x89167c: cmp             w1, NULL
    // 0x891680: b.ne            #0x8916b8
    // 0x891684: mov             x1, x0
    // 0x891688: r0 = _createSemanticsNode()
    //     0x891688: bl              #0x894cdc  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_createSemanticsNode
    // 0x89168c: mov             x1, x0
    // 0x891690: ldur            x2, [fp, #-8]
    // 0x891694: StoreField: r2->field_1b = r0
    //     0x891694: stur            w0, [x2, #0x1b]
    //     0x891698: ldurb           w16, [x2, #-1]
    //     0x89169c: ldurb           w17, [x0, #-1]
    //     0x8916a0: and             x16, x17, x16, lsr #2
    //     0x8916a4: tst             x16, HEAP, lsr #32
    //     0x8916a8: b.eq            #0x8916b0
    //     0x8916ac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8916b0: mov             x0, x1
    // 0x8916b4: b               #0x8916c0
    // 0x8916b8: mov             x2, x0
    // 0x8916bc: mov             x0, x1
    // 0x8916c0: stur            x0, [fp, #-0x28]
    // 0x8916c4: LoadField: r3 = r2->field_1f
    //     0x8916c4: ldur            w3, [x2, #0x1f]
    // 0x8916c8: DecompressPointer r3
    //     0x8916c8: add             x3, x3, HEAP, lsl #32
    // 0x8916cc: stur            x3, [fp, #-0x20]
    // 0x8916d0: LoadField: r1 = r3->field_b
    //     0x8916d0: ldur            w1, [x3, #0xb]
    // 0x8916d4: LoadField: r4 = r3->field_f
    //     0x8916d4: ldur            w4, [x3, #0xf]
    // 0x8916d8: DecompressPointer r4
    //     0x8916d8: add             x4, x4, HEAP, lsl #32
    // 0x8916dc: LoadField: r5 = r4->field_b
    //     0x8916dc: ldur            w5, [x4, #0xb]
    // 0x8916e0: r4 = LoadInt32Instr(r1)
    //     0x8916e0: sbfx            x4, x1, #1, #0x1f
    // 0x8916e4: stur            x4, [fp, #-0x18]
    // 0x8916e8: r1 = LoadInt32Instr(r5)
    //     0x8916e8: sbfx            x1, x5, #1, #0x1f
    // 0x8916ec: cmp             x4, x1
    // 0x8916f0: b.ne            #0x8916fc
    // 0x8916f4: mov             x1, x3
    // 0x8916f8: r0 = _growToNextCapacity()
    //     0x8916f8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8916fc: ldur            x3, [fp, #-8]
    // 0x891700: ldur            x0, [fp, #-0x20]
    // 0x891704: ldur            x2, [fp, #-0x18]
    // 0x891708: add             x1, x2, #1
    // 0x89170c: lsl             x4, x1, #1
    // 0x891710: StoreField: r0->field_b = r4
    //     0x891710: stur            w4, [x0, #0xb]
    // 0x891714: LoadField: r1 = r0->field_f
    //     0x891714: ldur            w1, [x0, #0xf]
    // 0x891718: DecompressPointer r1
    //     0x891718: add             x1, x1, HEAP, lsl #32
    // 0x89171c: ldur            x0, [fp, #-0x28]
    // 0x891720: ArrayStore: r1[r2] = r0  ; List_4
    //     0x891720: add             x25, x1, x2, lsl #2
    //     0x891724: add             x25, x25, #0xf
    //     0x891728: str             w0, [x25]
    //     0x89172c: tbz             w0, #0, #0x891748
    //     0x891730: ldurb           w16, [x1, #-1]
    //     0x891734: ldurb           w17, [x0, #-1]
    //     0x891738: and             x16, x17, x16, lsr #2
    //     0x89173c: tst             x16, HEAP, lsr #32
    //     0x891740: b.eq            #0x891748
    //     0x891744: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x891748: LoadField: r0 = r3->field_33
    //     0x891748: ldur            w0, [x3, #0x33]
    // 0x89174c: DecompressPointer r0
    //     0x89174c: add             x0, x0, HEAP, lsl #32
    // 0x891750: cmp             w0, NULL
    // 0x891754: b.ne            #0x891760
    // 0x891758: r0 = Null
    //     0x891758: mov             x0, NULL
    // 0x89175c: b               #0x89176c
    // 0x891760: LoadField: r1 = r0->field_7
    //     0x891760: ldur            w1, [x0, #7]
    // 0x891764: DecompressPointer r1
    //     0x891764: add             x1, x1, HEAP, lsl #32
    // 0x891768: mov             x0, x1
    // 0x89176c: cmp             w0, NULL
    // 0x891770: b.ne            #0x89177c
    // 0x891774: r2 = false
    //     0x891774: add             x2, NULL, #0x30  ; false
    // 0x891778: b               #0x891780
    // 0x89177c: mov             x2, x0
    // 0x891780: ldur            x1, [fp, #-0x28]
    // 0x891784: r0 = isMergedIntoParent=()
    //     0x891784: bl              #0x88e9b4  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::isMergedIntoParent=
    // 0x891788: ldur            x2, [fp, #-8]
    // 0x89178c: LoadField: r0 = r2->field_33
    //     0x89178c: ldur            w0, [x2, #0x33]
    // 0x891790: DecompressPointer r0
    //     0x891790: add             x0, x0, HEAP, lsl #32
    // 0x891794: cmp             w0, NULL
    // 0x891798: b.ne            #0x8917a4
    // 0x89179c: r0 = Null
    //     0x89179c: mov             x0, NULL
    // 0x8917a0: b               #0x8917b0
    // 0x8917a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8917a4: ldur            w1, [x0, #0x17]
    // 0x8917a8: DecompressPointer r1
    //     0x8917a8: add             x1, x1, HEAP, lsl #32
    // 0x8917ac: mov             x0, x1
    // 0x8917b0: ldur            x1, [fp, #-0x28]
    // 0x8917b4: StoreField: r1->field_6b = r0
    //     0x8917b4: stur            w0, [x1, #0x6b]
    //     0x8917b8: ldurb           w16, [x1, #-1]
    //     0x8917bc: ldurb           w17, [x0, #-1]
    //     0x8917c0: and             x16, x17, x16, lsr #2
    //     0x8917c4: tst             x16, HEAP, lsr #32
    //     0x8917c8: b.eq            #0x8917d0
    //     0x8917cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8917d0: mov             x1, x2
    // 0x8917d4: r0 = _updateSemanticsNodeGeometry()
    //     0x8917d4: bl              #0x894c2c  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_updateSemanticsNodeGeometry
    // 0x8917d8: ldur            x1, [fp, #-8]
    // 0x8917dc: ldur            x2, [fp, #-0x10]
    // 0x8917e0: r0 = _mergeSiblingGroup()
    //     0x8917e0: bl              #0x891814  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_mergeSiblingGroup
    // 0x8917e4: ldur            x1, [fp, #-8]
    // 0x8917e8: ldur            x2, [fp, #-0x10]
    // 0x8917ec: r0 = _buildSemanticsSubtree()
    //     0x8917ec: bl              #0x88deb8  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_buildSemanticsSubtree
    // 0x8917f0: ldur            x1, [fp, #-8]
    // 0x8917f4: r2 = true
    //     0x8917f4: add             x2, NULL, #0x20  ; true
    // 0x8917f8: ArrayStore: r1[0] = r2  ; List_4
    //     0x8917f8: stur            w2, [x1, #0x17]
    // 0x8917fc: r0 = Null
    //     0x8917fc: mov             x0, NULL
    // 0x891800: LeaveFrame
    //     0x891800: mov             SP, fp
    //     0x891804: ldp             fp, lr, [SP], #0x10
    // 0x891808: ret
    //     0x891808: ret             
    // 0x89180c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89180c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x891810: b               #0x891674
  }
  _ _mergeSiblingGroup(/* No info */) {
    // ** addr: 0x891814, size: 0x9c4
    // 0x891814: EnterFrame
    //     0x891814: stp             fp, lr, [SP, #-0x10]!
    //     0x891818: mov             fp, SP
    // 0x89181c: AllocStack(0xa8)
    //     0x89181c: sub             SP, SP, #0xa8
    // 0x891820: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x40 */, dynamic _ /* r2 => r2, fp-0x48 */)
    //     0x891820: mov             x0, x1
    //     0x891824: stur            x1, [fp, #-0x40]
    //     0x891828: stur            x2, [fp, #-0x48]
    // 0x89182c: CheckStackOverflow
    //     0x89182c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891830: cmp             SP, x16
    //     0x891834: b.ls            #0x8921a8
    // 0x891838: LoadField: r3 = r0->field_2b
    //     0x891838: ldur            w3, [x0, #0x2b]
    // 0x89183c: DecompressPointer r3
    //     0x89183c: add             x3, x3, HEAP, lsl #32
    // 0x891840: stur            x3, [fp, #-0x38]
    // 0x891844: LoadField: r1 = r3->field_b
    //     0x891844: ldur            w1, [x3, #0xb]
    // 0x891848: r4 = LoadInt32Instr(r1)
    //     0x891848: sbfx            x4, x1, #1, #0x1f
    // 0x89184c: stur            x4, [fp, #-0x30]
    // 0x891850: LoadField: r5 = r0->field_2f
    //     0x891850: ldur            w5, [x0, #0x2f]
    // 0x891854: DecompressPointer r5
    //     0x891854: add             x5, x5, HEAP, lsl #32
    // 0x891858: stur            x5, [fp, #-0x28]
    // 0x89185c: LoadField: r6 = r0->field_1f
    //     0x89185c: ldur            w6, [x0, #0x1f]
    // 0x891860: DecompressPointer r6
    //     0x891860: add             x6, x6, HEAP, lsl #32
    // 0x891864: stur            x6, [fp, #-0x20]
    // 0x891868: LoadField: r7 = r0->field_7
    //     0x891868: ldur            w7, [x0, #7]
    // 0x89186c: DecompressPointer r7
    //     0x89186c: add             x7, x7, HEAP, lsl #32
    // 0x891870: stur            x7, [fp, #-0x18]
    // 0x891874: r1 = 0
    //     0x891874: mov             x1, #0
    // 0x891878: CheckStackOverflow
    //     0x891878: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89187c: cmp             SP, x16
    //     0x891880: b.ls            #0x8921b0
    // 0x891884: LoadField: r8 = r3->field_b
    //     0x891884: ldur            w8, [x3, #0xb]
    // 0x891888: r9 = LoadInt32Instr(r8)
    //     0x891888: sbfx            x9, x8, #1, #0x1f
    // 0x89188c: cmp             x4, x9
    // 0x891890: b.ne            #0x892188
    // 0x891894: cmp             x1, x9
    // 0x891898: b.ge            #0x892150
    // 0x89189c: LoadField: r8 = r3->field_f
    //     0x89189c: ldur            w8, [x3, #0xf]
    // 0x8918a0: DecompressPointer r8
    //     0x8918a0: add             x8, x8, HEAP, lsl #32
    // 0x8918a4: ArrayLoad: r9 = r8[r1]  ; Unknown_4
    //     0x8918a4: add             x16, x8, x1, lsl #2
    //     0x8918a8: ldur            w9, [x16, #0xf]
    // 0x8918ac: DecompressPointer r9
    //     0x8918ac: add             x9, x9, HEAP, lsl #32
    // 0x8918b0: stur            x9, [fp, #-0x10]
    // 0x8918b4: add             x8, x1, #1
    // 0x8918b8: stur            x8, [fp, #-8]
    // 0x8918bc: r1 = <_RenderObjectSemantics>
    //     0x8918bc: ldr             x1, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x8918c0: r0 = AllocateGrowableArray()
    //     0x8918c0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x8918c4: mov             x3, x0
    // 0x8918c8: r2 = const []
    //     0x8918c8: ldr             x2, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0x8918cc: stur            x3, [fp, #-0x50]
    // 0x8918d0: StoreField: r3->field_f = r2
    //     0x8918d0: stur            w2, [x3, #0xf]
    // 0x8918d4: StoreField: r3->field_b = rZR
    //     0x8918d4: stur            wzr, [x3, #0xb]
    // 0x8918d8: ldur            x4, [fp, #-0x10]
    // 0x8918dc: r0 = LoadClassIdInstr(r4)
    //     0x8918dc: ldur            x0, [x4, #-1]
    //     0x8918e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8918e4: mov             x1, x4
    // 0x8918e8: r0 = GDT[cid_x0 + 0x12641]()
    //     0x8918e8: mov             x17, #0x2641
    //     0x8918ec: movk            x17, #1, lsl #16
    //     0x8918f0: add             lr, x0, x17
    //     0x8918f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8918f8: blr             lr
    // 0x8918fc: mov             x2, x0
    // 0x891900: stur            x2, [fp, #-0x68]
    // 0x891904: r5 = Null
    //     0x891904: mov             x5, NULL
    // 0x891908: r4 = Null
    //     0x891908: mov             x4, NULL
    // 0x89190c: ldur            x3, [fp, #-0x50]
    // 0x891910: stur            x5, [fp, #-0x58]
    // 0x891914: stur            x4, [fp, #-0x60]
    // 0x891918: CheckStackOverflow
    //     0x891918: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89191c: cmp             SP, x16
    //     0x891920: b.ls            #0x8921b8
    // 0x891924: r0 = LoadClassIdInstr(r2)
    //     0x891924: ldur            x0, [x2, #-1]
    //     0x891928: ubfx            x0, x0, #0xc, #0x14
    // 0x89192c: mov             x1, x2
    // 0x891930: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x891930: mov             x17, #0x845b
    //     0x891934: movk            x17, #1, lsl #16
    //     0x891938: add             lr, x0, x17
    //     0x89193c: ldr             lr, [x21, lr, lsl #3]
    //     0x891940: blr             lr
    // 0x891944: tbnz            w0, #4, #0x891bcc
    // 0x891948: ldur            x2, [fp, #-0x68]
    // 0x89194c: r0 = LoadClassIdInstr(r2)
    //     0x89194c: ldur            x0, [x2, #-1]
    //     0x891950: ubfx            x0, x0, #0xc, #0x14
    // 0x891954: mov             x1, x2
    // 0x891958: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x891958: mov             x17, #0x7d4c
    //     0x89195c: movk            x17, #1, lsl #16
    //     0x891960: add             lr, x0, x17
    //     0x891964: ldr             lr, [x21, lr, lsl #3]
    //     0x891968: blr             lr
    // 0x89196c: stur            x0, [fp, #-0x70]
    // 0x891970: r1 = 60
    //     0x891970: mov             x1, #0x3c
    // 0x891974: branchIfSmi(r0, 0x891980)
    //     0x891974: tbz             w0, #0, #0x891980
    // 0x891978: r1 = LoadClassIdInstr(r0)
    //     0x891978: ldur            x1, [x0, #-1]
    //     0x89197c: ubfx            x1, x1, #0xc, #0x14
    // 0x891980: r17 = 4217
    //     0x891980: mov             x17, #0x1079
    // 0x891984: cmp             x1, x17
    // 0x891988: b.ne            #0x891af8
    // 0x89198c: LoadField: r1 = r0->field_3b
    //     0x89198c: ldur            w1, [x0, #0x3b]
    // 0x891990: DecompressPointer r1
    //     0x891990: add             x1, x1, HEAP, lsl #32
    // 0x891994: LoadField: r2 = r1->field_13
    //     0x891994: ldur            w2, [x1, #0x13]
    // 0x891998: DecompressPointer r2
    //     0x891998: add             x2, x2, HEAP, lsl #32
    // 0x89199c: cmp             w2, NULL
    // 0x8919a0: b.ne            #0x8919ac
    // 0x8919a4: r0 = original()
    //     0x8919a4: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x8919a8: b               #0x8919b0
    // 0x8919ac: mov             x0, x2
    // 0x8919b0: LoadField: r1 = r0->field_7
    //     0x8919b0: ldur            w1, [x0, #7]
    // 0x8919b4: DecompressPointer r1
    //     0x8919b4: add             x1, x1, HEAP, lsl #32
    // 0x8919b8: tbnz            w1, #4, #0x8919c4
    // 0x8919bc: ldur            x0, [fp, #-0x70]
    // 0x8919c0: b               #0x891a5c
    // 0x8919c4: ldur            x2, [fp, #-0x70]
    // 0x8919c8: LoadField: r1 = r2->field_7
    //     0x8919c8: ldur            w1, [x2, #7]
    // 0x8919cc: DecompressPointer r1
    //     0x8919cc: add             x1, x1, HEAP, lsl #32
    // 0x8919d0: r0 = LoadClassIdInstr(r1)
    //     0x8919d0: ldur            x0, [x1, #-1]
    //     0x8919d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8919d8: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x8919d8: mov             x17, #0xfc0
    //     0x8919dc: movk            x17, #1, lsl #16
    //     0x8919e0: add             lr, x0, x17
    //     0x8919e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8919e8: blr             lr
    // 0x8919ec: cmp             w0, NULL
    // 0x8919f0: b.ne            #0x8919fc
    // 0x8919f4: ldur            x0, [fp, #-0x70]
    // 0x8919f8: b               #0x891a5c
    // 0x8919fc: mov             x1, x0
    // 0x891a00: LoadField: r0 = r1->field_43
    //     0x891a00: ldur            w0, [x1, #0x43]
    // 0x891a04: DecompressPointer r0
    //     0x891a04: add             x0, x0, HEAP, lsl #32
    // 0x891a08: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x891a0c: cmp             w0, w16
    // 0x891a10: b.ne            #0x891a1c
    // 0x891a14: r2 = _semantics
    //     0x891a14: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x891a18: r0 = InitLateFinalInstanceField()
    //     0x891a18: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x891a1c: ldur            x1, [fp, #-0x70]
    // 0x891a20: r0 = contributesToSemanticsTree()
    //     0x891a20: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x891a24: tbz             w0, #4, #0x891a30
    // 0x891a28: ldur            x3, [fp, #-0x50]
    // 0x891a2c: b               #0x891ae4
    // 0x891a30: ldur            x0, [fp, #-0x70]
    // 0x891a34: LoadField: r1 = r0->field_33
    //     0x891a34: ldur            w1, [x0, #0x33]
    // 0x891a38: DecompressPointer r1
    //     0x891a38: add             x1, x1, HEAP, lsl #32
    // 0x891a3c: cmp             w1, NULL
    // 0x891a40: b.eq            #0x8921c0
    // 0x891a44: LoadField: r2 = r1->field_13
    //     0x891a44: ldur            w2, [x1, #0x13]
    // 0x891a48: DecompressPointer r2
    //     0x891a48: add             x2, x2, HEAP, lsl #32
    // 0x891a4c: tbz             w2, #4, #0x891a5c
    // 0x891a50: LoadField: r1 = r0->field_b
    //     0x891a50: ldur            w1, [x0, #0xb]
    // 0x891a54: DecompressPointer r1
    //     0x891a54: add             x1, x1, HEAP, lsl #32
    // 0x891a58: tbnz            w1, #4, #0x891ae0
    // 0x891a5c: ldur            x2, [fp, #-0x50]
    // 0x891a60: LoadField: r1 = r2->field_b
    //     0x891a60: ldur            w1, [x2, #0xb]
    // 0x891a64: LoadField: r3 = r2->field_f
    //     0x891a64: ldur            w3, [x2, #0xf]
    // 0x891a68: DecompressPointer r3
    //     0x891a68: add             x3, x3, HEAP, lsl #32
    // 0x891a6c: LoadField: r4 = r3->field_b
    //     0x891a6c: ldur            w4, [x3, #0xb]
    // 0x891a70: r3 = LoadInt32Instr(r1)
    //     0x891a70: sbfx            x3, x1, #1, #0x1f
    // 0x891a74: stur            x3, [fp, #-0x78]
    // 0x891a78: r1 = LoadInt32Instr(r4)
    //     0x891a78: sbfx            x1, x4, #1, #0x1f
    // 0x891a7c: cmp             x3, x1
    // 0x891a80: b.ne            #0x891a8c
    // 0x891a84: mov             x1, x2
    // 0x891a88: r0 = _growToNextCapacity()
    //     0x891a88: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x891a8c: ldur            x3, [fp, #-0x50]
    // 0x891a90: ldur            x2, [fp, #-0x78]
    // 0x891a94: add             x0, x2, #1
    // 0x891a98: lsl             x1, x0, #1
    // 0x891a9c: StoreField: r3->field_b = r1
    //     0x891a9c: stur            w1, [x3, #0xb]
    // 0x891aa0: LoadField: r1 = r3->field_f
    //     0x891aa0: ldur            w1, [x3, #0xf]
    // 0x891aa4: DecompressPointer r1
    //     0x891aa4: add             x1, x1, HEAP, lsl #32
    // 0x891aa8: ldur            x0, [fp, #-0x70]
    // 0x891aac: ArrayStore: r1[r2] = r0  ; List_4
    //     0x891aac: add             x25, x1, x2, lsl #2
    //     0x891ab0: add             x25, x25, #0xf
    //     0x891ab4: str             w0, [x25]
    //     0x891ab8: tbz             w0, #0, #0x891ad4
    //     0x891abc: ldurb           w16, [x1, #-1]
    //     0x891ac0: ldurb           w17, [x0, #-1]
    //     0x891ac4: and             x16, x17, x16, lsr #2
    //     0x891ac8: tst             x16, HEAP, lsr #32
    //     0x891acc: b.eq            #0x891ad4
    //     0x891ad0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x891ad4: ldur            x5, [fp, #-0x58]
    // 0x891ad8: ldur            x4, [fp, #-0x60]
    // 0x891adc: b               #0x891bc4
    // 0x891ae0: ldur            x3, [fp, #-0x50]
    // 0x891ae4: ldur            x0, [fp, #-0x70]
    // 0x891ae8: LoadField: r2 = r0->field_27
    //     0x891ae8: ldur            w2, [x0, #0x27]
    // 0x891aec: DecompressPointer r2
    //     0x891aec: add             x2, x2, HEAP, lsl #32
    // 0x891af0: mov             x1, x3
    // 0x891af4: r0 = addAll()
    //     0x891af4: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x891af8: ldur            x2, [fp, #-0x70]
    // 0x891afc: r0 = LoadClassIdInstr(r2)
    //     0x891afc: ldur            x0, [x2, #-1]
    //     0x891b00: ubfx            x0, x0, #0xc, #0x14
    // 0x891b04: mov             x1, x2
    // 0x891b08: r0 = GDT[cid_x0 + -0xf66]()
    //     0x891b08: sub             lr, x0, #0xf66
    //     0x891b0c: ldr             lr, [x21, lr, lsl #3]
    //     0x891b10: blr             lr
    // 0x891b14: cmp             w0, NULL
    // 0x891b18: b.eq            #0x891bb0
    // 0x891b1c: ldur            x0, [fp, #-0x60]
    // 0x891b20: cmp             w0, NULL
    // 0x891b24: b.ne            #0x891b50
    // 0x891b28: ldur            x2, [fp, #-0x70]
    // 0x891b2c: r0 = LoadClassIdInstr(r2)
    //     0x891b2c: ldur            x0, [x2, #-1]
    //     0x891b30: ubfx            x0, x0, #0xc, #0x14
    // 0x891b34: mov             x1, x2
    // 0x891b38: r0 = GDT[cid_x0 + -0xeeb]()
    //     0x891b38: sub             lr, x0, #0xeeb
    //     0x891b3c: ldr             lr, [x21, lr, lsl #3]
    //     0x891b40: blr             lr
    // 0x891b44: LoadField: r1 = r0->field_1b
    //     0x891b44: ldur            w1, [x0, #0x1b]
    // 0x891b48: DecompressPointer r1
    //     0x891b48: add             x1, x1, HEAP, lsl #32
    // 0x891b4c: mov             x0, x1
    // 0x891b50: ldur            x2, [fp, #-0x58]
    // 0x891b54: stur            x0, [fp, #-0x80]
    // 0x891b58: cmp             w2, NULL
    // 0x891b5c: b.ne            #0x891b74
    // 0x891b60: r0 = SemanticsConfiguration()
    //     0x891b60: bl              #0x839284  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0xc8)
    // 0x891b64: mov             x1, x0
    // 0x891b68: stur            x0, [fp, #-0x88]
    // 0x891b6c: r0 = SemanticsConfiguration()
    //     0x891b6c: bl              #0x837c94  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0x891b70: ldur            x2, [fp, #-0x88]
    // 0x891b74: ldur            x1, [fp, #-0x70]
    // 0x891b78: stur            x2, [fp, #-0x88]
    // 0x891b7c: r0 = LoadClassIdInstr(r1)
    //     0x891b7c: ldur            x0, [x1, #-1]
    //     0x891b80: ubfx            x0, x0, #0xc, #0x14
    // 0x891b84: r0 = GDT[cid_x0 + -0xf66]()
    //     0x891b84: sub             lr, x0, #0xf66
    //     0x891b88: ldr             lr, [x21, lr, lsl #3]
    //     0x891b8c: blr             lr
    // 0x891b90: cmp             w0, NULL
    // 0x891b94: b.eq            #0x8921c4
    // 0x891b98: ldur            x1, [fp, #-0x88]
    // 0x891b9c: mov             x2, x0
    // 0x891ba0: r0 = absorb()
    //     0x891ba0: bl              #0x8940a0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::absorb
    // 0x891ba4: ldur            x1, [fp, #-0x88]
    // 0x891ba8: ldur            x0, [fp, #-0x80]
    // 0x891bac: b               #0x891bbc
    // 0x891bb0: ldur            x2, [fp, #-0x58]
    // 0x891bb4: ldur            x0, [fp, #-0x60]
    // 0x891bb8: mov             x1, x2
    // 0x891bbc: mov             x5, x1
    // 0x891bc0: mov             x4, x0
    // 0x891bc4: ldur            x2, [fp, #-0x68]
    // 0x891bc8: b               #0x89190c
    // 0x891bcc: ldur            x2, [fp, #-0x58]
    // 0x891bd0: ldur            x0, [fp, #-0x60]
    // 0x891bd4: ldur            x3, [fp, #-0x50]
    // 0x891bd8: r1 = <SemanticsNode>
    //     0x891bd8: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0x891bdc: r0 = AllocateGrowableArray()
    //     0x891bdc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x891be0: mov             x4, x0
    // 0x891be4: r3 = const []
    //     0x891be4: ldr             x3, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0x891be8: stur            x4, [fp, #-0x70]
    // 0x891bec: StoreField: r4->field_f = r3
    //     0x891bec: stur            w3, [x4, #0xf]
    // 0x891bf0: StoreField: r4->field_b = rZR
    //     0x891bf0: stur            wzr, [x4, #0xb]
    // 0x891bf4: ldur            x5, [fp, #-0x50]
    // 0x891bf8: LoadField: r0 = r5->field_b
    //     0x891bf8: ldur            w0, [x5, #0xb]
    // 0x891bfc: r6 = LoadInt32Instr(r0)
    //     0x891bfc: sbfx            x6, x0, #1, #0x1f
    // 0x891c00: stur            x6, [fp, #-0x90]
    // 0x891c04: r0 = 0
    //     0x891c04: mov             x0, #0
    // 0x891c08: CheckStackOverflow
    //     0x891c08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891c0c: cmp             SP, x16
    //     0x891c10: b.ls            #0x8921c8
    // 0x891c14: LoadField: r1 = r5->field_b
    //     0x891c14: ldur            w1, [x5, #0xb]
    // 0x891c18: r2 = LoadInt32Instr(r1)
    //     0x891c18: sbfx            x2, x1, #1, #0x1f
    // 0x891c1c: cmp             x6, x2
    // 0x891c20: b.ne            #0x892168
    // 0x891c24: cmp             x0, x2
    // 0x891c28: b.ge            #0x891cc4
    // 0x891c2c: LoadField: r1 = r5->field_f
    //     0x891c2c: ldur            w1, [x5, #0xf]
    // 0x891c30: DecompressPointer r1
    //     0x891c30: add             x1, x1, HEAP, lsl #32
    // 0x891c34: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0x891c34: add             x16, x1, x0, lsl #2
    //     0x891c38: ldur            w7, [x16, #0xf]
    // 0x891c3c: DecompressPointer r7
    //     0x891c3c: add             x7, x7, HEAP, lsl #32
    // 0x891c40: stur            x7, [fp, #-0x68]
    // 0x891c44: add             x8, x0, #1
    // 0x891c48: stur            x8, [fp, #-0x78]
    // 0x891c4c: cmp             w7, NULL
    // 0x891c50: b.ne            #0x891c88
    // 0x891c54: mov             x0, x7
    // 0x891c58: r2 = Null
    //     0x891c58: mov             x2, NULL
    // 0x891c5c: r1 = Null
    //     0x891c5c: mov             x1, NULL
    // 0x891c60: r4 = 60
    //     0x891c60: mov             x4, #0x3c
    // 0x891c64: branchIfSmi(r0, 0x891c70)
    //     0x891c64: tbz             w0, #0, #0x891c70
    // 0x891c68: r4 = LoadClassIdInstr(r0)
    //     0x891c68: ldur            x4, [x0, #-1]
    //     0x891c6c: ubfx            x4, x4, #0xc, #0x14
    // 0x891c70: r17 = 4217
    //     0x891c70: mov             x17, #0x1079
    // 0x891c74: cmp             x4, x17
    // 0x891c78: b.eq            #0x891c88
    // 0x891c7c: r8 = _RenderObjectSemantics
    //     0x891c7c: ldr             x8, [PP, #0x29c0]  ; [pp+0x29c0] Type: _RenderObjectSemantics
    // 0x891c80: r3 = Null
    //     0x891c80: ldr             x3, [PP, #0x29c8]  ; [pp+0x29c8] Null
    // 0x891c84: r0 = _RenderObjectSemantics()
    //     0x891c84: bl              #0x837900  ; IsType__RenderObjectSemantics_Stub
    // 0x891c88: ldur            x0, [fp, #-0x68]
    // 0x891c8c: mov             x1, x0
    // 0x891c90: ldur            x2, [fp, #-0x48]
    // 0x891c94: r0 = _buildSemantics()
    //     0x891c94: bl              #0x891358  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_buildSemantics
    // 0x891c98: ldur            x0, [fp, #-0x68]
    // 0x891c9c: LoadField: r2 = r0->field_1f
    //     0x891c9c: ldur            w2, [x0, #0x1f]
    // 0x891ca0: DecompressPointer r2
    //     0x891ca0: add             x2, x2, HEAP, lsl #32
    // 0x891ca4: ldur            x1, [fp, #-0x70]
    // 0x891ca8: r0 = addAll()
    //     0x891ca8: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x891cac: ldur            x0, [fp, #-0x78]
    // 0x891cb0: ldur            x4, [fp, #-0x70]
    // 0x891cb4: ldur            x5, [fp, #-0x50]
    // 0x891cb8: ldur            x6, [fp, #-0x90]
    // 0x891cbc: r3 = const []
    //     0x891cbc: ldr             x3, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0x891cc0: b               #0x891c08
    // 0x891cc4: ldur            x3, [fp, #-0x58]
    // 0x891cc8: cmp             w3, NULL
    // 0x891ccc: b.eq            #0x89212c
    // 0x891cd0: ldur            x4, [fp, #-0x60]
    // 0x891cd4: cmp             w4, NULL
    // 0x891cd8: b.eq            #0x891d20
    // 0x891cdc: ldur            x5, [fp, #-0x48]
    // 0x891ce0: LoadField: r2 = r4->field_b
    //     0x891ce0: ldur            x2, [x4, #0xb]
    // 0x891ce4: LoadField: r6 = r5->field_f
    //     0x891ce4: ldur            w6, [x5, #0xf]
    // 0x891ce8: DecompressPointer r6
    //     0x891ce8: add             x6, x6, HEAP, lsl #32
    // 0x891cec: stur            x6, [fp, #-0x68]
    // 0x891cf0: r0 = BoxInt64Instr(r2)
    //     0x891cf0: sbfiz           x0, x2, #1, #0x1f
    //     0x891cf4: cmp             x2, x0, asr #1
    //     0x891cf8: b.eq            #0x891d04
    //     0x891cfc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x891d00: stur            x2, [x0, #7]
    // 0x891d04: mov             x1, x5
    // 0x891d08: mov             x2, x0
    // 0x891d0c: r0 = _getKeyOrData()
    //     0x891d0c: bl              #0x84b72c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_getKeyOrData
    // 0x891d10: mov             x1, x0
    // 0x891d14: ldur            x0, [fp, #-0x68]
    // 0x891d18: cmp             w0, w1
    // 0x891d1c: b.eq            #0x891d6c
    // 0x891d20: ldur            x1, [fp, #-0x18]
    // 0x891d24: r0 = LoadClassIdInstr(r1)
    //     0x891d24: ldur            x0, [x1, #-1]
    //     0x891d28: ubfx            x0, x0, #0xc, #0x14
    // 0x891d2c: str             x1, [SP]
    // 0x891d30: r0 = GDT[cid_x0 + 0x10d7a]()
    //     0x891d30: mov             x17, #0xd7a
    //     0x891d34: movk            x17, #1, lsl #16
    //     0x891d38: add             lr, x0, x17
    //     0x891d3c: ldr             lr, [x21, lr, lsl #3]
    //     0x891d40: blr             lr
    // 0x891d44: stur            x0, [fp, #-0x68]
    // 0x891d48: r0 = SemanticsNode()
    //     0x891d48: bl              #0x894094  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xf0)
    // 0x891d4c: stur            x0, [fp, #-0x80]
    // 0x891d50: ldur            x16, [fp, #-0x68]
    // 0x891d54: str             x16, [SP]
    // 0x891d58: mov             x1, x0
    // 0x891d5c: r4 = const [0, 0x2, 0x1, 0x1, showOnScreen, 0x1, null]
    //     0x891d5c: ldr             x4, [PP, #0x29d8]  ; [pp+0x29d8] List(7) [0, 0x2, 0x1, 0x1, "showOnScreen", 0x1, Null]
    // 0x891d60: r0 = SemanticsNode()
    //     0x891d60: bl              #0x893ce8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0x891d64: ldur            x4, [fp, #-0x80]
    // 0x891d68: b               #0x891d70
    // 0x891d6c: ldur            x4, [fp, #-0x60]
    // 0x891d70: ldur            x3, [fp, #-0x10]
    // 0x891d74: stur            x4, [fp, #-0x68]
    // 0x891d78: LoadField: r2 = r4->field_b
    //     0x891d78: ldur            x2, [x4, #0xb]
    // 0x891d7c: r0 = BoxInt64Instr(r2)
    //     0x891d7c: sbfiz           x0, x2, #1, #0x1f
    //     0x891d80: cmp             x2, x0, asr #1
    //     0x891d84: b.eq            #0x891d90
    //     0x891d88: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x891d8c: stur            x2, [x0, #7]
    // 0x891d90: ldur            x1, [fp, #-0x48]
    // 0x891d94: mov             x2, x0
    // 0x891d98: stur            x0, [fp, #-0x60]
    // 0x891d9c: r0 = _hashCode()
    //     0x891d9c: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x891da0: ldur            x1, [fp, #-0x48]
    // 0x891da4: ldur            x2, [fp, #-0x60]
    // 0x891da8: mov             x3, x0
    // 0x891dac: r0 = _add()
    //     0x891dac: bl              #0x84ba3c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x891db0: ldur            x2, [fp, #-0x10]
    // 0x891db4: r0 = LoadClassIdInstr(r2)
    //     0x891db4: ldur            x0, [x2, #-1]
    //     0x891db8: ubfx            x0, x0, #0xc, #0x14
    // 0x891dbc: mov             x1, x2
    // 0x891dc0: r0 = GDT[cid_x0 + 0x12641]()
    //     0x891dc0: mov             x17, #0x2641
    //     0x891dc4: movk            x17, #1, lsl #16
    //     0x891dc8: add             lr, x0, x17
    //     0x891dcc: ldr             lr, [x21, lr, lsl #3]
    //     0x891dd0: blr             lr
    // 0x891dd4: mov             x2, x0
    // 0x891dd8: stur            x2, [fp, #-0x60]
    // 0x891ddc: CheckStackOverflow
    //     0x891ddc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x891de0: cmp             SP, x16
    //     0x891de4: b.ls            #0x8921d0
    // 0x891de8: r0 = LoadClassIdInstr(r2)
    //     0x891de8: ldur            x0, [x2, #-1]
    //     0x891dec: ubfx            x0, x0, #0xc, #0x14
    // 0x891df0: mov             x1, x2
    // 0x891df4: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x891df4: mov             x17, #0x845b
    //     0x891df8: movk            x17, #1, lsl #16
    //     0x891dfc: add             lr, x0, x17
    //     0x891e00: ldr             lr, [x21, lr, lsl #3]
    //     0x891e04: blr             lr
    // 0x891e08: tbnz            w0, #4, #0x891ec0
    // 0x891e0c: ldur            x2, [fp, #-0x60]
    // 0x891e10: r0 = LoadClassIdInstr(r2)
    //     0x891e10: ldur            x0, [x2, #-1]
    //     0x891e14: ubfx            x0, x0, #0xc, #0x14
    // 0x891e18: mov             x1, x2
    // 0x891e1c: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x891e1c: mov             x17, #0x7d4c
    //     0x891e20: movk            x17, #1, lsl #16
    //     0x891e24: add             lr, x0, x17
    //     0x891e28: ldr             lr, [x21, lr, lsl #3]
    //     0x891e2c: blr             lr
    // 0x891e30: mov             x2, x0
    // 0x891e34: stur            x2, [fp, #-0x80]
    // 0x891e38: r0 = LoadClassIdInstr(r2)
    //     0x891e38: ldur            x0, [x2, #-1]
    //     0x891e3c: ubfx            x0, x0, #0xc, #0x14
    // 0x891e40: mov             x1, x2
    // 0x891e44: r0 = GDT[cid_x0 + -0xf66]()
    //     0x891e44: sub             lr, x0, #0xf66
    //     0x891e48: ldr             lr, [x21, lr, lsl #3]
    //     0x891e4c: blr             lr
    // 0x891e50: cmp             w0, NULL
    // 0x891e54: b.eq            #0x891eb8
    // 0x891e58: ldur            x2, [fp, #-0x80]
    // 0x891e5c: r0 = LoadClassIdInstr(r2)
    //     0x891e5c: ldur            x0, [x2, #-1]
    //     0x891e60: ubfx            x0, x0, #0xc, #0x14
    // 0x891e64: mov             x1, x2
    // 0x891e68: r0 = GDT[cid_x0 + -0xeeb]()
    //     0x891e68: sub             lr, x0, #0xeeb
    //     0x891e6c: ldr             lr, [x21, lr, lsl #3]
    //     0x891e70: blr             lr
    // 0x891e74: r2 = true
    //     0x891e74: add             x2, NULL, #0x20  ; true
    // 0x891e78: ArrayStore: r0[0] = r2  ; List_4
    //     0x891e78: stur            w2, [x0, #0x17]
    // 0x891e7c: ldur            x1, [fp, #-0x80]
    // 0x891e80: r0 = LoadClassIdInstr(r1)
    //     0x891e80: ldur            x0, [x1, #-1]
    //     0x891e84: ubfx            x0, x0, #0xc, #0x14
    // 0x891e88: r0 = GDT[cid_x0 + -0xeeb]()
    //     0x891e88: sub             lr, x0, #0xeeb
    //     0x891e8c: ldr             lr, [x21, lr, lsl #3]
    //     0x891e90: blr             lr
    // 0x891e94: mov             x1, x0
    // 0x891e98: ldur            x0, [fp, #-0x68]
    // 0x891e9c: StoreField: r1->field_1b = r0
    //     0x891e9c: stur            w0, [x1, #0x1b]
    //     0x891ea0: ldurb           w16, [x1, #-1]
    //     0x891ea4: ldurb           w17, [x0, #-1]
    //     0x891ea8: and             x16, x17, x16, lsr #2
    //     0x891eac: tst             x16, HEAP, lsr #32
    //     0x891eb0: b.eq            #0x891eb8
    //     0x891eb4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x891eb8: ldur            x2, [fp, #-0x60]
    // 0x891ebc: b               #0x891ddc
    // 0x891ec0: ldur            x0, [fp, #-0x20]
    // 0x891ec4: ldur            x16, [fp, #-0x70]
    // 0x891ec8: str             x16, [SP]
    // 0x891ecc: ldur            x1, [fp, #-0x68]
    // 0x891ed0: ldur            x2, [fp, #-0x58]
    // 0x891ed4: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0x891ed4: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0x891ed8: r0 = updateWith()
    //     0x891ed8: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0x891edc: ldur            x16, [fp, #-0x68]
    // 0x891ee0: str             x16, [SP]
    // 0x891ee4: r0 = _getHash()
    //     0x891ee4: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x891ee8: ldur            x1, [fp, #-0x28]
    // 0x891eec: ldur            x2, [fp, #-0x68]
    // 0x891ef0: ldur            x3, [fp, #-0x10]
    // 0x891ef4: mov             x5, x0
    // 0x891ef8: r0 = _set()
    //     0x891ef8: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x891efc: ldur            x0, [fp, #-0x20]
    // 0x891f00: LoadField: r1 = r0->field_b
    //     0x891f00: ldur            w1, [x0, #0xb]
    // 0x891f04: LoadField: r2 = r0->field_f
    //     0x891f04: ldur            w2, [x0, #0xf]
    // 0x891f08: DecompressPointer r2
    //     0x891f08: add             x2, x2, HEAP, lsl #32
    // 0x891f0c: LoadField: r3 = r2->field_b
    //     0x891f0c: ldur            w3, [x2, #0xb]
    // 0x891f10: r2 = LoadInt32Instr(r1)
    //     0x891f10: sbfx            x2, x1, #1, #0x1f
    // 0x891f14: stur            x2, [fp, #-0x78]
    // 0x891f18: r1 = LoadInt32Instr(r3)
    //     0x891f18: sbfx            x1, x3, #1, #0x1f
    // 0x891f1c: cmp             x2, x1
    // 0x891f20: b.ne            #0x891f2c
    // 0x891f24: mov             x1, x0
    // 0x891f28: r0 = _growToNextCapacity()
    //     0x891f28: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x891f2c: ldur            x3, [fp, #-0x20]
    // 0x891f30: ldur            x2, [fp, #-0x78]
    // 0x891f34: ldur            x4, [fp, #-0x10]
    // 0x891f38: add             x0, x2, #1
    // 0x891f3c: lsl             x1, x0, #1
    // 0x891f40: StoreField: r3->field_b = r1
    //     0x891f40: stur            w1, [x3, #0xb]
    // 0x891f44: LoadField: r1 = r3->field_f
    //     0x891f44: ldur            w1, [x3, #0xf]
    // 0x891f48: DecompressPointer r1
    //     0x891f48: add             x1, x1, HEAP, lsl #32
    // 0x891f4c: ldur            x0, [fp, #-0x68]
    // 0x891f50: ArrayStore: r1[r2] = r0  ; List_4
    //     0x891f50: add             x25, x1, x2, lsl #2
    //     0x891f54: add             x25, x25, #0xf
    //     0x891f58: str             w0, [x25]
    //     0x891f5c: tbz             w0, #0, #0x891f78
    //     0x891f60: ldurb           w16, [x1, #-1]
    //     0x891f64: ldurb           w17, [x0, #-1]
    //     0x891f68: and             x16, x17, x16, lsr #2
    //     0x891f6c: tst             x16, HEAP, lsr #32
    //     0x891f70: b.eq            #0x891f78
    //     0x891f74: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x891f78: r1 = Function '<anonymous closure>':.
    //     0x891f78: ldr             x1, [PP, #0x29e0]  ; [pp+0x29e0] AnonymousClosure: (0x894be0), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_mergeSiblingGroup (0x891814)
    // 0x891f7c: r2 = Null
    //     0x891f7c: mov             x2, NULL
    // 0x891f80: r0 = AllocateClosure()
    //     0x891f80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x891f84: mov             x1, x0
    // 0x891f88: ldur            x0, [fp, #-0x10]
    // 0x891f8c: r2 = LoadClassIdInstr(r0)
    //     0x891f8c: ldur            x2, [x0, #-1]
    //     0x891f90: ubfx            x2, x2, #0xc, #0x14
    // 0x891f94: r16 = <Set<SemanticsTag>?>
    //     0x891f94: ldr             x16, [PP, #0x29e8]  ; [pp+0x29e8] TypeArguments: <Set<SemanticsTag>?>
    // 0x891f98: stp             x0, x16, [SP, #8]
    // 0x891f9c: str             x1, [SP]
    // 0x891fa0: mov             x0, x2
    // 0x891fa4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x891fa4: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x891fa8: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x891fa8: mov             x17, #0x2caa
    //     0x891fac: movk            x17, #1, lsl #16
    //     0x891fb0: add             lr, x0, x17
    //     0x891fb4: ldr             lr, [x21, lr, lsl #3]
    //     0x891fb8: blr             lr
    // 0x891fbc: r1 = <Set<SemanticsTag>>
    //     0x891fbc: ldr             x1, [PP, #0x29f0]  ; [pp+0x29f0] TypeArguments: <Set<SemanticsTag>>
    // 0x891fc0: stur            x0, [fp, #-0x10]
    // 0x891fc4: r0 = WhereTypeIterable()
    //     0x891fc4: bl              #0x893cdc  ; AllocateWhereTypeIterableStub -> WhereTypeIterable<X0> (size=0x10)
    // 0x891fc8: mov             x2, x0
    // 0x891fcc: ldur            x0, [fp, #-0x10]
    // 0x891fd0: stur            x2, [fp, #-0x58]
    // 0x891fd4: StoreField: r2->field_b = r0
    //     0x891fd4: stur            w0, [x2, #0xb]
    // 0x891fd8: r1 = <SemanticsTag, Set<SemanticsTag>, SemanticsTag>
    //     0x891fd8: ldr             x1, [PP, #0x29f8]  ; [pp+0x29f8] TypeArguments: <SemanticsTag, Set<SemanticsTag>, SemanticsTag>
    // 0x891fdc: r0 = ExpandIterable()
    //     0x891fdc: bl              #0x82af1c  ; AllocateExpandIterableStub -> ExpandIterable<C1X0, C1X1> (size=0x14)
    // 0x891fe0: mov             x3, x0
    // 0x891fe4: ldur            x0, [fp, #-0x58]
    // 0x891fe8: stur            x3, [fp, #-0x10]
    // 0x891fec: StoreField: r3->field_b = r0
    //     0x891fec: stur            w0, [x3, #0xb]
    // 0x891ff0: r1 = Function '<anonymous closure>':.
    //     0x891ff0: ldr             x1, [PP, #0x2a00]  ; [pp+0x2a00] AnonymousClosure: (0x13dae90), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_mergeSiblingGroup (0x891814)
    // 0x891ff4: r2 = Null
    //     0x891ff4: mov             x2, NULL
    // 0x891ff8: r0 = AllocateClosure()
    //     0x891ff8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x891ffc: ldur            x2, [fp, #-0x10]
    // 0x892000: StoreField: r2->field_f = r0
    //     0x892000: stur            w0, [x2, #0xf]
    // 0x892004: r1 = <SemanticsTag, Set<SemanticsTag>, SemanticsTag>
    //     0x892004: ldr             x1, [PP, #0x29f8]  ; [pp+0x29f8] TypeArguments: <SemanticsTag, Set<SemanticsTag>, SemanticsTag>
    // 0x892008: r0 = LinkedHashSet.of()
    //     0x892008: bl              #0x83a460  ; [dart:collection] LinkedHashSet::LinkedHashSet.of
    // 0x89200c: mov             x3, x0
    // 0x892010: stur            x3, [fp, #-0x58]
    // 0x892014: LoadField: r0 = r3->field_13
    //     0x892014: ldur            w0, [x3, #0x13]
    // 0x892018: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x892018: ldur            w1, [x3, #0x17]
    // 0x89201c: r2 = LoadInt32Instr(r0)
    //     0x89201c: sbfx            x2, x0, #1, #0x1f
    // 0x892020: r0 = LoadInt32Instr(r1)
    //     0x892020: sbfx            x0, x1, #1, #0x1f
    // 0x892024: sub             x1, x2, x0
    // 0x892028: cbz             x1, #0x8920cc
    // 0x89202c: ldur            x4, [fp, #-0x68]
    // 0x892030: LoadField: r5 = r4->field_6b
    //     0x892030: ldur            w5, [x4, #0x6b]
    // 0x892034: DecompressPointer r5
    //     0x892034: add             x5, x5, HEAP, lsl #32
    // 0x892038: stur            x5, [fp, #-0x10]
    // 0x89203c: cmp             w5, NULL
    // 0x892040: b.ne            #0x892068
    // 0x892044: mov             x0, x3
    // 0x892048: StoreField: r4->field_6b = r0
    //     0x892048: stur            w0, [x4, #0x6b]
    //     0x89204c: ldurb           w16, [x4, #-1]
    //     0x892050: ldurb           w17, [x0, #-1]
    //     0x892054: and             x16, x17, x16, lsr #2
    //     0x892058: tst             x16, HEAP, lsr #32
    //     0x89205c: b.eq            #0x892064
    //     0x892060: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x892064: b               #0x8920cc
    // 0x892068: LoadField: r2 = r5->field_7
    //     0x892068: ldur            w2, [x5, #7]
    // 0x89206c: DecompressPointer r2
    //     0x89206c: add             x2, x2, HEAP, lsl #32
    // 0x892070: mov             x0, x3
    // 0x892074: r1 = Null
    //     0x892074: mov             x1, NULL
    // 0x892078: r8 = Iterable<X0>
    //     0x892078: ldr             x8, [PP, #0xbb0]  ; [pp+0xbb0] Type: Iterable<X0>
    // 0x89207c: LoadField: r9 = r8->field_7
    //     0x89207c: ldur            x9, [x8, #7]
    // 0x892080: r3 = Null
    //     0x892080: ldr             x3, [PP, #0x2a08]  ; [pp+0x2a08] Null
    // 0x892084: blr             x9
    // 0x892088: r0 = 88
    //     0x892088: mov             x0, #0x58
    // 0x89208c: cmp             x0, #0x58
    // 0x892090: b.ne            #0x8920c0
    // 0x892094: ldur            x3, [fp, #-0x10]
    // 0x892098: LoadField: r1 = r3->field_13
    //     0x892098: ldur            w1, [x3, #0x13]
    // 0x89209c: ArrayLoad: r2 = r3[0]  ; List_4
    //     0x89209c: ldur            w2, [x3, #0x17]
    // 0x8920a0: r4 = LoadInt32Instr(r1)
    //     0x8920a0: sbfx            x4, x1, #1, #0x1f
    // 0x8920a4: r1 = LoadInt32Instr(r2)
    //     0x8920a4: sbfx            x1, x2, #1, #0x1f
    // 0x8920a8: sub             x2, x4, x1
    // 0x8920ac: cbnz            x2, #0x8920c0
    // 0x8920b0: mov             x1, x3
    // 0x8920b4: ldur            x2, [fp, #-0x58]
    // 0x8920b8: r0 = _quickCopy()
    //     0x8920b8: bl              #0x84bf9c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase::_quickCopy
    // 0x8920bc: tbz             w0, #4, #0x8920cc
    // 0x8920c0: ldur            x1, [fp, #-0x10]
    // 0x8920c4: ldur            x2, [fp, #-0x58]
    // 0x8920c8: r0 = addAll()
    //     0x8920c8: bl              #0x84b954  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::addAll
    // 0x8920cc: ldur            x0, [fp, #-0x40]
    // 0x8920d0: LoadField: r1 = r0->field_33
    //     0x8920d0: ldur            w1, [x0, #0x33]
    // 0x8920d4: DecompressPointer r1
    //     0x8920d4: add             x1, x1, HEAP, lsl #32
    // 0x8920d8: cmp             w1, NULL
    // 0x8920dc: b.ne            #0x8920e8
    // 0x8920e0: r2 = Null
    //     0x8920e0: mov             x2, NULL
    // 0x8920e4: b               #0x8920f0
    // 0x8920e8: LoadField: r2 = r1->field_7
    //     0x8920e8: ldur            w2, [x1, #7]
    // 0x8920ec: DecompressPointer r2
    //     0x8920ec: add             x2, x2, HEAP, lsl #32
    // 0x8920f0: cmp             w2, NULL
    // 0x8920f4: b.ne            #0x8920fc
    // 0x8920f8: r2 = false
    //     0x8920f8: add             x2, NULL, #0x30  ; false
    // 0x8920fc: ldur            x1, [fp, #-0x68]
    // 0x892100: LoadField: r3 = r1->field_2b
    //     0x892100: ldur            w3, [x1, #0x2b]
    // 0x892104: DecompressPointer r3
    //     0x892104: add             x3, x3, HEAP, lsl #32
    // 0x892108: cmp             w3, w2
    // 0x89210c: b.eq            #0x89212c
    // 0x892110: StoreField: r1->field_2b = r2
    //     0x892110: stur            w2, [x1, #0x2b]
    // 0x892114: LoadField: r2 = r1->field_43
    //     0x892114: ldur            w2, [x1, #0x43]
    // 0x892118: DecompressPointer r2
    //     0x892118: add             x2, x2, HEAP, lsl #32
    // 0x89211c: cmp             w2, NULL
    // 0x892120: b.eq            #0x89212c
    // 0x892124: mov             x1, x2
    // 0x892128: r0 = _markDirty()
    //     0x892128: bl              #0x87ffac  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::_markDirty
    // 0x89212c: ldur            x1, [fp, #-8]
    // 0x892130: ldur            x0, [fp, #-0x40]
    // 0x892134: ldur            x2, [fp, #-0x48]
    // 0x892138: ldur            x3, [fp, #-0x38]
    // 0x89213c: ldur            x5, [fp, #-0x28]
    // 0x892140: ldur            x6, [fp, #-0x20]
    // 0x892144: ldur            x7, [fp, #-0x18]
    // 0x892148: ldur            x4, [fp, #-0x30]
    // 0x89214c: b               #0x891878
    // 0x892150: ldur            x1, [fp, #-0x40]
    // 0x892154: r0 = _updateSiblingNodesGeometries()
    //     0x892154: bl              #0x8921d8  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_updateSiblingNodesGeometries
    // 0x892158: r0 = Null
    //     0x892158: mov             x0, NULL
    // 0x89215c: LeaveFrame
    //     0x89215c: mov             SP, fp
    //     0x892160: ldp             fp, lr, [SP], #0x10
    // 0x892164: ret
    //     0x892164: ret             
    // 0x892168: mov             x0, x5
    // 0x89216c: r0 = ConcurrentModificationError()
    //     0x89216c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x892170: mov             x1, x0
    // 0x892174: ldur            x0, [fp, #-0x50]
    // 0x892178: StoreField: r1->field_b = r0
    //     0x892178: stur            w0, [x1, #0xb]
    // 0x89217c: mov             x0, x1
    // 0x892180: r0 = Throw()
    //     0x892180: bl              #0x13ddb2c  ; ThrowStub
    // 0x892184: brk             #0
    // 0x892188: mov             x0, x3
    // 0x89218c: r0 = ConcurrentModificationError()
    //     0x89218c: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x892190: mov             x1, x0
    // 0x892194: ldur            x0, [fp, #-0x38]
    // 0x892198: StoreField: r1->field_b = r0
    //     0x892198: stur            w0, [x1, #0xb]
    // 0x89219c: mov             x0, x1
    // 0x8921a0: r0 = Throw()
    //     0x8921a0: bl              #0x13ddb2c  ; ThrowStub
    // 0x8921a4: brk             #0
    // 0x8921a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8921a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8921ac: b               #0x891838
    // 0x8921b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8921b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8921b4: b               #0x891884
    // 0x8921b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8921b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8921bc: b               #0x891924
    // 0x8921c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8921c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8921c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8921c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8921c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8921c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8921cc: b               #0x891c14
    // 0x8921d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8921d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8921d4: b               #0x891de8
  }
  _ _updateSiblingNodesGeometries(/* No info */) {
    // ** addr: 0x8921d8, size: 0x724
    // 0x8921d8: EnterFrame
    //     0x8921d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8921dc: mov             fp, SP
    // 0x8921e0: AllocStack(0xa0)
    //     0x8921e0: sub             SP, SP, #0xa0
    // 0x8921e4: SetupParameters(_RenderObjectSemantics this /* r1 => r2, fp-0x18 */)
    //     0x8921e4: mov             x2, x1
    //     0x8921e8: stur            x1, [fp, #-0x18]
    // 0x8921ec: CheckStackOverflow
    //     0x8921ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8921f0: cmp             SP, x16
    //     0x8921f4: b.ls            #0x8928d4
    // 0x8921f8: LoadField: r0 = r2->field_37
    //     0x8921f8: ldur            w0, [x2, #0x37]
    // 0x8921fc: DecompressPointer r0
    //     0x8921fc: add             x0, x0, HEAP, lsl #32
    // 0x892200: stur            x0, [fp, #-0x10]
    // 0x892204: cmp             w0, NULL
    // 0x892208: b.eq            #0x8928dc
    // 0x89220c: LoadField: r3 = r2->field_2f
    //     0x89220c: ldur            w3, [x2, #0x2f]
    // 0x892210: DecompressPointer r3
    //     0x892210: add             x3, x3, HEAP, lsl #32
    // 0x892214: stur            x3, [fp, #-8]
    // 0x892218: r1 = <MapEntry<SemanticsNode, List<_SemanticsFragment>>, SemanticsNode, List<_SemanticsFragment>>
    //     0x892218: ldr             x1, [PP, #0x2a18]  ; [pp+0x2a18] TypeArguments: <MapEntry<SemanticsNode, List<_SemanticsFragment>>, SemanticsNode, List<_SemanticsFragment>>
    // 0x89221c: r0 = _CompactEntriesIterable()
    //     0x89221c: bl              #0x893cd0  ; Allocate_CompactEntriesIterableStub -> _CompactEntriesIterable<C1X0, C1X1> (size=0x10)
    // 0x892220: mov             x1, x0
    // 0x892224: ldur            x0, [fp, #-8]
    // 0x892228: StoreField: r1->field_b = r0
    //     0x892228: stur            w0, [x1, #0xb]
    // 0x89222c: r0 = iterator()
    //     0x89222c: bl              #0xb09bdc  ; [dart:_compact_hash] _CompactEntriesIterable::iterator
    // 0x892230: mov             x2, x0
    // 0x892234: ldur            x0, [fp, #-0x10]
    // 0x892238: stur            x2, [fp, #-0x30]
    // 0x89223c: LoadField: r6 = r0->field_7
    //     0x89223c: ldur            w6, [x0, #7]
    // 0x892240: DecompressPointer r6
    //     0x892240: add             x6, x6, HEAP, lsl #32
    // 0x892244: stur            x6, [fp, #-0x28]
    // 0x892248: LoadField: r5 = r0->field_b
    //     0x892248: ldur            w5, [x0, #0xb]
    // 0x89224c: DecompressPointer r5
    //     0x89224c: add             x5, x5, HEAP, lsl #32
    // 0x892250: stur            x5, [fp, #-0x20]
    // 0x892254: LoadField: r3 = r0->field_f
    //     0x892254: ldur            w3, [x0, #0xf]
    // 0x892258: DecompressPointer r3
    //     0x892258: add             x3, x3, HEAP, lsl #32
    // 0x89225c: stur            x3, [fp, #-8]
    // 0x892260: CheckStackOverflow
    //     0x892260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x892264: cmp             SP, x16
    //     0x892268: b.ls            #0x8928e0
    // 0x89226c: mov             x1, x2
    // 0x892270: r0 = moveNext()
    //     0x892270: bl              #0x80261c  ; [dart:_compact_hash] _CompactEntriesIterator::moveNext
    // 0x892274: tbnz            w0, #4, #0x8928b8
    // 0x892278: ldur            x2, [fp, #-0x30]
    // 0x89227c: LoadField: r3 = r2->field_2b
    //     0x89227c: ldur            w3, [x2, #0x2b]
    // 0x892280: DecompressPointer r3
    //     0x892280: add             x3, x3, HEAP, lsl #32
    // 0x892284: stur            x3, [fp, #-0x10]
    // 0x892288: cmp             w3, NULL
    // 0x89228c: b.eq            #0x8928c8
    // 0x892290: LoadField: r1 = r3->field_f
    //     0x892290: ldur            w1, [x3, #0xf]
    // 0x892294: DecompressPointer r1
    //     0x892294: add             x1, x1, HEAP, lsl #32
    // 0x892298: r0 = LoadClassIdInstr(r1)
    //     0x892298: ldur            x0, [x1, #-1]
    //     0x89229c: ubfx            x0, x0, #0xc, #0x14
    // 0x8922a0: r0 = GDT[cid_x0 + 0x12641]()
    //     0x8922a0: mov             x17, #0x2641
    //     0x8922a4: movk            x17, #1, lsl #16
    //     0x8922a8: add             lr, x0, x17
    //     0x8922ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8922b0: blr             lr
    // 0x8922b4: mov             x2, x0
    // 0x8922b8: stur            x2, [fp, #-0x50]
    // 0x8922bc: r5 = Null
    //     0x8922bc: mov             x5, NULL
    // 0x8922c0: r4 = Null
    //     0x8922c0: mov             x4, NULL
    // 0x8922c4: r3 = Null
    //     0x8922c4: mov             x3, NULL
    // 0x8922c8: stur            x5, [fp, #-0x38]
    // 0x8922cc: stur            x4, [fp, #-0x40]
    // 0x8922d0: stur            x3, [fp, #-0x48]
    // 0x8922d4: CheckStackOverflow
    //     0x8922d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8922d8: cmp             SP, x16
    //     0x8922dc: b.ls            #0x8928e8
    // 0x8922e0: r0 = LoadClassIdInstr(r2)
    //     0x8922e0: ldur            x0, [x2, #-1]
    //     0x8922e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8922e8: mov             x1, x2
    // 0x8922ec: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x8922ec: mov             x17, #0x845b
    //     0x8922f0: movk            x17, #1, lsl #16
    //     0x8922f4: add             lr, x0, x17
    //     0x8922f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8922fc: blr             lr
    // 0x892300: tbnz            w0, #4, #0x892790
    // 0x892304: ldur            x2, [fp, #-0x50]
    // 0x892308: r0 = LoadClassIdInstr(r2)
    //     0x892308: ldur            x0, [x2, #-1]
    //     0x89230c: ubfx            x0, x0, #0xc, #0x14
    // 0x892310: mov             x1, x2
    // 0x892314: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x892314: mov             x17, #0x7d4c
    //     0x892318: movk            x17, #1, lsl #16
    //     0x89231c: add             lr, x0, x17
    //     0x892320: ldr             lr, [x21, lr, lsl #3]
    //     0x892324: blr             lr
    // 0x892328: mov             x2, x0
    // 0x89232c: stur            x2, [fp, #-0x58]
    // 0x892330: r0 = LoadClassIdInstr(r2)
    //     0x892330: ldur            x0, [x2, #-1]
    //     0x892334: ubfx            x0, x0, #0xc, #0x14
    // 0x892338: mov             x1, x2
    // 0x89233c: r0 = GDT[cid_x0 + -0xeeb]()
    //     0x89233c: sub             lr, x0, #0xeeb
    //     0x892340: ldr             lr, [x21, lr, lsl #3]
    //     0x892344: blr             lr
    // 0x892348: stur            x0, [fp, #-0x60]
    // 0x89234c: LoadField: r1 = r0->field_3b
    //     0x89234c: ldur            w1, [x0, #0x3b]
    // 0x892350: DecompressPointer r1
    //     0x892350: add             x1, x1, HEAP, lsl #32
    // 0x892354: LoadField: r2 = r1->field_13
    //     0x892354: ldur            w2, [x1, #0x13]
    // 0x892358: DecompressPointer r2
    //     0x892358: add             x2, x2, HEAP, lsl #32
    // 0x89235c: cmp             w2, NULL
    // 0x892360: b.ne            #0x89236c
    // 0x892364: r0 = original()
    //     0x892364: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x892368: b               #0x892370
    // 0x89236c: mov             x0, x2
    // 0x892370: LoadField: r1 = r0->field_7
    //     0x892370: ldur            w1, [x0, #7]
    // 0x892374: DecompressPointer r1
    //     0x892374: add             x1, x1, HEAP, lsl #32
    // 0x892378: tbz             w1, #4, #0x892404
    // 0x89237c: ldur            x2, [fp, #-0x60]
    // 0x892380: LoadField: r1 = r2->field_7
    //     0x892380: ldur            w1, [x2, #7]
    // 0x892384: DecompressPointer r1
    //     0x892384: add             x1, x1, HEAP, lsl #32
    // 0x892388: r0 = LoadClassIdInstr(r1)
    //     0x892388: ldur            x0, [x1, #-1]
    //     0x89238c: ubfx            x0, x0, #0xc, #0x14
    // 0x892390: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x892390: mov             x17, #0xfc0
    //     0x892394: movk            x17, #1, lsl #16
    //     0x892398: add             lr, x0, x17
    //     0x89239c: ldr             lr, [x21, lr, lsl #3]
    //     0x8923a0: blr             lr
    // 0x8923a4: cmp             w0, NULL
    // 0x8923a8: b.eq            #0x892404
    // 0x8923ac: mov             x1, x0
    // 0x8923b0: LoadField: r0 = r1->field_43
    //     0x8923b0: ldur            w0, [x1, #0x43]
    // 0x8923b4: DecompressPointer r0
    //     0x8923b4: add             x0, x0, HEAP, lsl #32
    // 0x8923b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8923bc: cmp             w0, w16
    // 0x8923c0: b.ne            #0x8923cc
    // 0x8923c4: r2 = _semantics
    //     0x8923c4: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x8923c8: r0 = InitLateFinalInstanceField()
    //     0x8923c8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x8923cc: ldur            x1, [fp, #-0x60]
    // 0x8923d0: r0 = contributesToSemanticsTree()
    //     0x8923d0: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x8923d4: tbnz            w0, #4, #0x892414
    // 0x8923d8: ldur            x0, [fp, #-0x60]
    // 0x8923dc: LoadField: r1 = r0->field_33
    //     0x8923dc: ldur            w1, [x0, #0x33]
    // 0x8923e0: DecompressPointer r1
    //     0x8923e0: add             x1, x1, HEAP, lsl #32
    // 0x8923e4: cmp             w1, NULL
    // 0x8923e8: b.eq            #0x8928f0
    // 0x8923ec: LoadField: r2 = r1->field_13
    //     0x8923ec: ldur            w2, [x1, #0x13]
    // 0x8923f0: DecompressPointer r2
    //     0x8923f0: add             x2, x2, HEAP, lsl #32
    // 0x8923f4: tbz             w2, #4, #0x892404
    // 0x8923f8: LoadField: r1 = r0->field_b
    //     0x8923f8: ldur            w1, [x0, #0xb]
    // 0x8923fc: DecompressPointer r1
    //     0x8923fc: add             x1, x1, HEAP, lsl #32
    // 0x892400: tbnz            w1, #4, #0x892414
    // 0x892404: ldur            x5, [fp, #-0x38]
    // 0x892408: ldur            x4, [fp, #-0x40]
    // 0x89240c: ldur            x3, [fp, #-0x48]
    // 0x892410: b               #0x892788
    // 0x892414: ldur            x2, [fp, #-0x58]
    // 0x892418: r0 = LoadClassIdInstr(r2)
    //     0x892418: ldur            x0, [x2, #-1]
    //     0x89241c: ubfx            x0, x0, #0xc, #0x14
    // 0x892420: mov             x1, x2
    // 0x892424: r0 = GDT[cid_x0 + -0xeeb]()
    //     0x892424: sub             lr, x0, #0xeeb
    //     0x892428: ldr             lr, [x21, lr, lsl #3]
    //     0x89242c: blr             lr
    // 0x892430: mov             x1, x0
    // 0x892434: ldur            x2, [fp, #-0x18]
    // 0x892438: ldur            x3, [fp, #-8]
    // 0x89243c: ldur            x5, [fp, #-0x20]
    // 0x892440: ldur            x6, [fp, #-0x28]
    // 0x892444: r0 = computeChildGeometry()
    //     0x892444: bl              #0x8930e4  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::computeChildGeometry
    // 0x892448: mov             x2, x0
    // 0x89244c: stur            x2, [fp, #-0x68]
    // 0x892450: LoadField: r3 = r2->field_b
    //     0x892450: ldur            w3, [x2, #0xb]
    // 0x892454: DecompressPointer r3
    //     0x892454: add             x3, x3, HEAP, lsl #32
    // 0x892458: stur            x3, [fp, #-0x60]
    // 0x89245c: cmp             w3, NULL
    // 0x892460: b.ne            #0x89246c
    // 0x892464: r0 = Null
    //     0x892464: mov             x0, NULL
    // 0x892468: b               #0x892514
    // 0x89246c: ldur            x4, [fp, #-0x58]
    // 0x892470: r0 = LoadClassIdInstr(r4)
    //     0x892470: ldur            x0, [x4, #-1]
    //     0x892474: ubfx            x0, x0, #0xc, #0x14
    // 0x892478: mov             x1, x4
    // 0x89247c: r0 = GDT[cid_x0 + -0xeeb]()
    //     0x89247c: sub             lr, x0, #0xeeb
    //     0x892480: ldr             lr, [x21, lr, lsl #3]
    //     0x892484: blr             lr
    // 0x892488: LoadField: r1 = r0->field_7
    //     0x892488: ldur            w1, [x0, #7]
    // 0x89248c: DecompressPointer r1
    //     0x89248c: add             x1, x1, HEAP, lsl #32
    // 0x892490: r0 = LoadClassIdInstr(r1)
    //     0x892490: ldur            x0, [x1, #-1]
    //     0x892494: ubfx            x0, x0, #0xc, #0x14
    // 0x892498: r0 = GDT[cid_x0 + 0x1021c]()
    //     0x892498: mov             x17, #0x21c
    //     0x89249c: movk            x17, #1, lsl #16
    //     0x8924a0: add             lr, x0, x17
    //     0x8924a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8924a8: blr             lr
    // 0x8924ac: ldur            x2, [fp, #-0x60]
    // 0x8924b0: LoadField: d0 = r2->field_7
    //     0x8924b0: ldur            d0, [x2, #7]
    // 0x8924b4: LoadField: d1 = r0->field_7
    //     0x8924b4: ldur            d1, [x0, #7]
    // 0x8924b8: fmax            v2.2d, v0.2d, v1.2d
    // 0x8924bc: stur            d2, [fp, #-0x90]
    // 0x8924c0: LoadField: d0 = r2->field_f
    //     0x8924c0: ldur            d0, [x2, #0xf]
    // 0x8924c4: LoadField: d1 = r0->field_f
    //     0x8924c4: ldur            d1, [x0, #0xf]
    // 0x8924c8: fmax            v3.2d, v0.2d, v1.2d
    // 0x8924cc: stur            d3, [fp, #-0x88]
    // 0x8924d0: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x8924d0: ldur            d0, [x2, #0x17]
    // 0x8924d4: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x8924d4: ldur            d1, [x0, #0x17]
    // 0x8924d8: fmin            v4.2d, v0.2d, v1.2d
    // 0x8924dc: stur            d4, [fp, #-0x80]
    // 0x8924e0: LoadField: d0 = r2->field_1f
    //     0x8924e0: ldur            d0, [x2, #0x1f]
    // 0x8924e4: LoadField: d1 = r0->field_1f
    //     0x8924e4: ldur            d1, [x0, #0x1f]
    // 0x8924e8: fmin            v5.2d, v0.2d, v1.2d
    // 0x8924ec: stur            d5, [fp, #-0x78]
    // 0x8924f0: r0 = Rect()
    //     0x8924f0: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8924f4: ldur            d0, [fp, #-0x90]
    // 0x8924f8: StoreField: r0->field_7 = d0
    //     0x8924f8: stur            d0, [x0, #7]
    // 0x8924fc: ldur            d0, [fp, #-0x88]
    // 0x892500: StoreField: r0->field_f = d0
    //     0x892500: stur            d0, [x0, #0xf]
    // 0x892504: ldur            d0, [fp, #-0x80]
    // 0x892508: ArrayStore: r0[0] = d0  ; List_8
    //     0x892508: stur            d0, [x0, #0x17]
    // 0x89250c: ldur            d0, [fp, #-0x78]
    // 0x892510: StoreField: r0->field_1f = d0
    //     0x892510: stur            d0, [x0, #0x1f]
    // 0x892514: cmp             w0, NULL
    // 0x892518: b.ne            #0x892560
    // 0x89251c: ldur            x1, [fp, #-0x58]
    // 0x892520: r0 = LoadClassIdInstr(r1)
    //     0x892520: ldur            x0, [x1, #-1]
    //     0x892524: ubfx            x0, x0, #0xc, #0x14
    // 0x892528: r0 = GDT[cid_x0 + -0xeeb]()
    //     0x892528: sub             lr, x0, #0xeeb
    //     0x89252c: ldr             lr, [x21, lr, lsl #3]
    //     0x892530: blr             lr
    // 0x892534: LoadField: r1 = r0->field_7
    //     0x892534: ldur            w1, [x0, #7]
    // 0x892538: DecompressPointer r1
    //     0x892538: add             x1, x1, HEAP, lsl #32
    // 0x89253c: r0 = LoadClassIdInstr(r1)
    //     0x89253c: ldur            x0, [x1, #-1]
    //     0x892540: ubfx            x0, x0, #0xc, #0x14
    // 0x892544: r0 = GDT[cid_x0 + 0x1021c]()
    //     0x892544: mov             x17, #0x21c
    //     0x892548: movk            x17, #1, lsl #16
    //     0x89254c: add             lr, x0, x17
    //     0x892550: ldr             lr, [x21, lr, lsl #3]
    //     0x892554: blr             lr
    // 0x892558: mov             x2, x0
    // 0x89255c: b               #0x892564
    // 0x892560: mov             x2, x0
    // 0x892564: ldur            x3, [fp, #-0x38]
    // 0x892568: ldur            x0, [fp, #-0x68]
    // 0x89256c: LoadField: r4 = r0->field_7
    //     0x89256c: ldur            w4, [x0, #7]
    // 0x892570: DecompressPointer r4
    //     0x892570: add             x4, x4, HEAP, lsl #32
    // 0x892574: mov             x1, x4
    // 0x892578: stur            x4, [fp, #-0x58]
    // 0x89257c: r0 = transformRect()
    //     0x89257c: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x892580: mov             x1, x0
    // 0x892584: ldur            x0, [fp, #-0x38]
    // 0x892588: stur            x1, [fp, #-0x70]
    // 0x89258c: cmp             w0, NULL
    // 0x892590: b.ne            #0x89259c
    // 0x892594: r0 = Null
    //     0x892594: mov             x0, NULL
    // 0x892598: b               #0x892600
    // 0x89259c: LoadField: d0 = r0->field_7
    //     0x89259c: ldur            d0, [x0, #7]
    // 0x8925a0: LoadField: d1 = r1->field_7
    //     0x8925a0: ldur            d1, [x1, #7]
    // 0x8925a4: fmin            v2.2d, v0.2d, v1.2d
    // 0x8925a8: stur            d2, [fp, #-0x90]
    // 0x8925ac: LoadField: d0 = r0->field_f
    //     0x8925ac: ldur            d0, [x0, #0xf]
    // 0x8925b0: LoadField: d1 = r1->field_f
    //     0x8925b0: ldur            d1, [x1, #0xf]
    // 0x8925b4: fmin            v3.2d, v0.2d, v1.2d
    // 0x8925b8: stur            d3, [fp, #-0x88]
    // 0x8925bc: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x8925bc: ldur            d0, [x0, #0x17]
    // 0x8925c0: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x8925c0: ldur            d1, [x1, #0x17]
    // 0x8925c4: fmax            v4.2d, v0.2d, v1.2d
    // 0x8925c8: stur            d4, [fp, #-0x80]
    // 0x8925cc: LoadField: d0 = r0->field_1f
    //     0x8925cc: ldur            d0, [x0, #0x1f]
    // 0x8925d0: LoadField: d1 = r1->field_1f
    //     0x8925d0: ldur            d1, [x1, #0x1f]
    // 0x8925d4: fmax            v5.2d, v0.2d, v1.2d
    // 0x8925d8: stur            d5, [fp, #-0x78]
    // 0x8925dc: r0 = Rect()
    //     0x8925dc: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x8925e0: ldur            d0, [fp, #-0x90]
    // 0x8925e4: StoreField: r0->field_7 = d0
    //     0x8925e4: stur            d0, [x0, #7]
    // 0x8925e8: ldur            d0, [fp, #-0x88]
    // 0x8925ec: StoreField: r0->field_f = d0
    //     0x8925ec: stur            d0, [x0, #0xf]
    // 0x8925f0: ldur            d0, [fp, #-0x80]
    // 0x8925f4: ArrayStore: r0[0] = d0  ; List_8
    //     0x8925f4: stur            d0, [x0, #0x17]
    // 0x8925f8: ldur            d0, [fp, #-0x78]
    // 0x8925fc: StoreField: r0->field_1f = d0
    //     0x8925fc: stur            d0, [x0, #0x1f]
    // 0x892600: cmp             w0, NULL
    // 0x892604: b.ne            #0x89260c
    // 0x892608: ldur            x0, [fp, #-0x70]
    // 0x89260c: ldur            x2, [fp, #-0x60]
    // 0x892610: stur            x0, [fp, #-0x70]
    // 0x892614: cmp             w2, NULL
    // 0x892618: b.eq            #0x8926bc
    // 0x89261c: ldur            x3, [fp, #-0x40]
    // 0x892620: ldur            x1, [fp, #-0x58]
    // 0x892624: r0 = transformRect()
    //     0x892624: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x892628: mov             x1, x0
    // 0x89262c: ldur            x0, [fp, #-0x40]
    // 0x892630: stur            x1, [fp, #-0x60]
    // 0x892634: cmp             w0, NULL
    // 0x892638: b.ne            #0x892644
    // 0x89263c: r0 = Null
    //     0x89263c: mov             x0, NULL
    // 0x892640: b               #0x8926a8
    // 0x892644: LoadField: d0 = r0->field_7
    //     0x892644: ldur            d0, [x0, #7]
    // 0x892648: LoadField: d1 = r1->field_7
    //     0x892648: ldur            d1, [x1, #7]
    // 0x89264c: fmax            v2.2d, v0.2d, v1.2d
    // 0x892650: stur            d2, [fp, #-0x90]
    // 0x892654: LoadField: d0 = r0->field_f
    //     0x892654: ldur            d0, [x0, #0xf]
    // 0x892658: LoadField: d1 = r1->field_f
    //     0x892658: ldur            d1, [x1, #0xf]
    // 0x89265c: fmax            v3.2d, v0.2d, v1.2d
    // 0x892660: stur            d3, [fp, #-0x88]
    // 0x892664: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x892664: ldur            d0, [x0, #0x17]
    // 0x892668: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x892668: ldur            d1, [x1, #0x17]
    // 0x89266c: fmin            v4.2d, v0.2d, v1.2d
    // 0x892670: stur            d4, [fp, #-0x80]
    // 0x892674: LoadField: d0 = r0->field_1f
    //     0x892674: ldur            d0, [x0, #0x1f]
    // 0x892678: LoadField: d1 = r1->field_1f
    //     0x892678: ldur            d1, [x1, #0x1f]
    // 0x89267c: fmin            v5.2d, v0.2d, v1.2d
    // 0x892680: stur            d5, [fp, #-0x78]
    // 0x892684: r0 = Rect()
    //     0x892684: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x892688: ldur            d0, [fp, #-0x90]
    // 0x89268c: StoreField: r0->field_7 = d0
    //     0x89268c: stur            d0, [x0, #7]
    // 0x892690: ldur            d0, [fp, #-0x88]
    // 0x892694: StoreField: r0->field_f = d0
    //     0x892694: stur            d0, [x0, #0xf]
    // 0x892698: ldur            d0, [fp, #-0x80]
    // 0x89269c: ArrayStore: r0[0] = d0  ; List_8
    //     0x89269c: stur            d0, [x0, #0x17]
    // 0x8926a0: ldur            d0, [fp, #-0x78]
    // 0x8926a4: StoreField: r0->field_1f = d0
    //     0x8926a4: stur            d0, [x0, #0x1f]
    // 0x8926a8: cmp             w0, NULL
    // 0x8926ac: b.ne            #0x8926b4
    // 0x8926b0: ldur            x0, [fp, #-0x60]
    // 0x8926b4: mov             x3, x0
    // 0x8926b8: b               #0x8926c4
    // 0x8926bc: ldur            x0, [fp, #-0x40]
    // 0x8926c0: mov             x3, x0
    // 0x8926c4: ldur            x0, [fp, #-0x68]
    // 0x8926c8: stur            x3, [fp, #-0x40]
    // 0x8926cc: LoadField: r2 = r0->field_f
    //     0x8926cc: ldur            w2, [x0, #0xf]
    // 0x8926d0: DecompressPointer r2
    //     0x8926d0: add             x2, x2, HEAP, lsl #32
    // 0x8926d4: cmp             w2, NULL
    // 0x8926d8: b.eq            #0x892774
    // 0x8926dc: ldur            x0, [fp, #-0x48]
    // 0x8926e0: ldur            x1, [fp, #-0x58]
    // 0x8926e4: r0 = transformRect()
    //     0x8926e4: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x8926e8: ldur            x1, [fp, #-0x48]
    // 0x8926ec: stur            x0, [fp, #-0x58]
    // 0x8926f0: cmp             w1, NULL
    // 0x8926f4: b.ne            #0x892700
    // 0x8926f8: r0 = Null
    //     0x8926f8: mov             x0, NULL
    // 0x8926fc: b               #0x892764
    // 0x892700: LoadField: d0 = r1->field_7
    //     0x892700: ldur            d0, [x1, #7]
    // 0x892704: LoadField: d1 = r0->field_7
    //     0x892704: ldur            d1, [x0, #7]
    // 0x892708: fmax            v2.2d, v0.2d, v1.2d
    // 0x89270c: stur            d2, [fp, #-0x90]
    // 0x892710: LoadField: d0 = r1->field_f
    //     0x892710: ldur            d0, [x1, #0xf]
    // 0x892714: LoadField: d1 = r0->field_f
    //     0x892714: ldur            d1, [x0, #0xf]
    // 0x892718: fmax            v3.2d, v0.2d, v1.2d
    // 0x89271c: stur            d3, [fp, #-0x88]
    // 0x892720: ArrayLoad: d0 = r1[0]  ; List_8
    //     0x892720: ldur            d0, [x1, #0x17]
    // 0x892724: ArrayLoad: d1 = r0[0]  ; List_8
    //     0x892724: ldur            d1, [x0, #0x17]
    // 0x892728: fmin            v4.2d, v0.2d, v1.2d
    // 0x89272c: stur            d4, [fp, #-0x80]
    // 0x892730: LoadField: d0 = r1->field_1f
    //     0x892730: ldur            d0, [x1, #0x1f]
    // 0x892734: LoadField: d1 = r0->field_1f
    //     0x892734: ldur            d1, [x0, #0x1f]
    // 0x892738: fmin            v5.2d, v0.2d, v1.2d
    // 0x89273c: stur            d5, [fp, #-0x78]
    // 0x892740: r0 = Rect()
    //     0x892740: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x892744: ldur            d0, [fp, #-0x90]
    // 0x892748: StoreField: r0->field_7 = d0
    //     0x892748: stur            d0, [x0, #7]
    // 0x89274c: ldur            d0, [fp, #-0x88]
    // 0x892750: StoreField: r0->field_f = d0
    //     0x892750: stur            d0, [x0, #0xf]
    // 0x892754: ldur            d0, [fp, #-0x80]
    // 0x892758: ArrayStore: r0[0] = d0  ; List_8
    //     0x892758: stur            d0, [x0, #0x17]
    // 0x89275c: ldur            d0, [fp, #-0x78]
    // 0x892760: StoreField: r0->field_1f = d0
    //     0x892760: stur            d0, [x0, #0x1f]
    // 0x892764: cmp             w0, NULL
    // 0x892768: b.ne            #0x89277c
    // 0x89276c: ldur            x0, [fp, #-0x58]
    // 0x892770: b               #0x89277c
    // 0x892774: ldur            x1, [fp, #-0x48]
    // 0x892778: mov             x0, x1
    // 0x89277c: ldur            x5, [fp, #-0x70]
    // 0x892780: ldur            x4, [fp, #-0x40]
    // 0x892784: mov             x3, x0
    // 0x892788: ldur            x2, [fp, #-0x50]
    // 0x89278c: b               #0x8922c8
    // 0x892790: ldur            x0, [fp, #-0x38]
    // 0x892794: ldur            x1, [fp, #-0x48]
    // 0x892798: ldur            x2, [fp, #-0x10]
    // 0x89279c: LoadField: r3 = r2->field_b
    //     0x89279c: ldur            w3, [x2, #0xb]
    // 0x8927a0: DecompressPointer r3
    //     0x8927a0: add             x3, x3, HEAP, lsl #32
    // 0x8927a4: stur            x3, [fp, #-0x40]
    // 0x8927a8: cmp             w0, NULL
    // 0x8927ac: b.eq            #0x8928f4
    // 0x8927b0: cmp             w3, NULL
    // 0x8927b4: b.eq            #0x8928f8
    // 0x8927b8: LoadField: r2 = r3->field_1f
    //     0x8927b8: ldur            w2, [x3, #0x1f]
    // 0x8927bc: DecompressPointer r2
    //     0x8927bc: add             x2, x2, HEAP, lsl #32
    // 0x8927c0: stur            x2, [fp, #-0x10]
    // 0x8927c4: cmp             w2, w0
    // 0x8927c8: b.eq            #0x892858
    // 0x8927cc: r16 = Rect
    //     0x8927cc: ldr             x16, [PP, #0x2a28]  ; [pp+0x2a28] Type: Rect
    // 0x8927d0: r30 = Rect
    //     0x8927d0: ldr             lr, [PP, #0x2a28]  ; [pp+0x2a28] Type: Rect
    // 0x8927d4: stp             lr, x16, [SP]
    // 0x8927d8: r0 = ==()
    //     0x8927d8: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0x8927dc: tbz             w0, #4, #0x8927e8
    // 0x8927e0: ldur            x0, [fp, #-0x38]
    // 0x8927e4: b               #0x892830
    // 0x8927e8: ldur            x0, [fp, #-0x38]
    // 0x8927ec: ldur            x1, [fp, #-0x10]
    // 0x8927f0: LoadField: d0 = r0->field_7
    //     0x8927f0: ldur            d0, [x0, #7]
    // 0x8927f4: LoadField: d1 = r1->field_7
    //     0x8927f4: ldur            d1, [x1, #7]
    // 0x8927f8: fcmp            d0, d1
    // 0x8927fc: b.ne            #0x892830
    // 0x892800: LoadField: d0 = r0->field_f
    //     0x892800: ldur            d0, [x0, #0xf]
    // 0x892804: LoadField: d1 = r1->field_f
    //     0x892804: ldur            d1, [x1, #0xf]
    // 0x892808: fcmp            d0, d1
    // 0x89280c: b.ne            #0x892830
    // 0x892810: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x892810: ldur            d0, [x0, #0x17]
    // 0x892814: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x892814: ldur            d1, [x1, #0x17]
    // 0x892818: fcmp            d0, d1
    // 0x89281c: b.ne            #0x892830
    // 0x892820: LoadField: d0 = r0->field_1f
    //     0x892820: ldur            d0, [x0, #0x1f]
    // 0x892824: LoadField: d1 = r1->field_1f
    //     0x892824: ldur            d1, [x1, #0x1f]
    // 0x892828: fcmp            d0, d1
    // 0x89282c: b.eq            #0x892858
    // 0x892830: ldur            x2, [fp, #-0x40]
    // 0x892834: StoreField: r2->field_1f = r0
    //     0x892834: stur            w0, [x2, #0x1f]
    //     0x892838: ldurb           w16, [x2, #-1]
    //     0x89283c: ldurb           w17, [x0, #-1]
    //     0x892840: and             x16, x17, x16, lsr #2
    //     0x892844: tst             x16, HEAP, lsr #32
    //     0x892848: b.eq            #0x892850
    //     0x89284c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x892850: mov             x1, x2
    // 0x892854: r0 = _markDirty()
    //     0x892854: bl              #0x87ffac  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::_markDirty
    // 0x892858: ldur            x0, [fp, #-0x40]
    // 0x89285c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89285c: ldur            w1, [x0, #0x17]
    // 0x892860: DecompressPointer r1
    //     0x892860: add             x1, x1, HEAP, lsl #32
    // 0x892864: r2 = Null
    //     0x892864: mov             x2, NULL
    // 0x892868: r0 = matrixEquals()
    //     0x892868: bl              #0x892cb0  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::matrixEquals
    // 0x89286c: tbz             w0, #4, #0x892880
    // 0x892870: ldur            x0, [fp, #-0x40]
    // 0x892874: ArrayStore: r0[0] = rNULL  ; List_4
    //     0x892874: stur            NULL, [x0, #0x17]
    // 0x892878: mov             x1, x0
    // 0x89287c: r0 = _markDirty()
    //     0x89287c: bl              #0x87ffac  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::_markDirty
    // 0x892880: ldur            x1, [fp, #-0x40]
    // 0x892884: ldur            x0, [fp, #-0x48]
    // 0x892888: StoreField: r1->field_23 = r0
    //     0x892888: stur            w0, [x1, #0x23]
    //     0x89288c: ldurb           w16, [x1, #-1]
    //     0x892890: ldurb           w17, [x0, #-1]
    //     0x892894: and             x16, x17, x16, lsr #2
    //     0x892898: tst             x16, HEAP, lsr #32
    //     0x89289c: b.eq            #0x8928a4
    //     0x8928a0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8928a4: ldur            x2, [fp, #-0x30]
    // 0x8928a8: ldur            x6, [fp, #-0x28]
    // 0x8928ac: ldur            x5, [fp, #-0x20]
    // 0x8928b0: ldur            x3, [fp, #-8]
    // 0x8928b4: b               #0x892260
    // 0x8928b8: r0 = Null
    //     0x8928b8: mov             x0, NULL
    // 0x8928bc: LeaveFrame
    //     0x8928bc: mov             SP, fp
    //     0x8928c0: ldp             fp, lr, [SP], #0x10
    // 0x8928c4: ret
    //     0x8928c4: ret             
    // 0x8928c8: r0 = noElement()
    //     0x8928c8: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0x8928cc: r0 = Throw()
    //     0x8928cc: bl              #0x13ddb2c  ; ThrowStub
    // 0x8928d0: brk             #0
    // 0x8928d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8928d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8928d8: b               #0x8921f8
    // 0x8928dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8928dc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8928e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8928e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8928e4: b               #0x89226c
    // 0x8928e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8928e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8928ec: b               #0x8922e0
    // 0x8928f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8928f0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8928f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8928f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8928f8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x8928f8: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Set<SemanticsTag>? <anonymous closure>(dynamic, _SemanticsFragment) {
    // ** addr: 0x894be0, size: 0x4c
    // 0x894be0: ldr             x1, [SP]
    // 0x894be4: r2 = LoadClassIdInstr(r1)
    //     0x894be4: ldur            x2, [x1, #-1]
    //     0x894be8: ubfx            x2, x2, #0xc, #0x14
    // 0x894bec: r17 = 4215
    //     0x894bec: mov             x17, #0x1077
    // 0x894bf0: cmp             x2, x17
    // 0x894bf4: b.ne            #0x894c04
    // 0x894bf8: LoadField: r2 = r1->field_b
    //     0x894bf8: ldur            w2, [x1, #0xb]
    // 0x894bfc: DecompressPointer r2
    //     0x894bfc: add             x2, x2, HEAP, lsl #32
    // 0x894c00: mov             x1, x2
    // 0x894c04: LoadField: r2 = r1->field_33
    //     0x894c04: ldur            w2, [x1, #0x33]
    // 0x894c08: DecompressPointer r2
    //     0x894c08: add             x2, x2, HEAP, lsl #32
    // 0x894c0c: cmp             w2, NULL
    // 0x894c10: b.eq            #0x894c20
    // 0x894c14: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x894c14: ldur            w0, [x2, #0x17]
    // 0x894c18: DecompressPointer r0
    //     0x894c18: add             x0, x0, HEAP, lsl #32
    // 0x894c1c: ret
    //     0x894c1c: ret             
    // 0x894c20: EnterFrame
    //     0x894c20: stp             fp, lr, [SP, #-0x10]!
    //     0x894c24: mov             fp, SP
    // 0x894c28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x894c28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateSemanticsNodeGeometry(/* No info */) {
    // ** addr: 0x894c2c, size: 0xb0
    // 0x894c2c: EnterFrame
    //     0x894c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x894c30: mov             fp, SP
    // 0x894c34: AllocStack(0x10)
    //     0x894c34: sub             SP, SP, #0x10
    // 0x894c38: CheckStackOverflow
    //     0x894c38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x894c3c: cmp             SP, x16
    //     0x894c40: b.ls            #0x894ccc
    // 0x894c44: LoadField: r0 = r1->field_1b
    //     0x894c44: ldur            w0, [x1, #0x1b]
    // 0x894c48: DecompressPointer r0
    //     0x894c48: add             x0, x0, HEAP, lsl #32
    // 0x894c4c: stur            x0, [fp, #-0x10]
    // 0x894c50: cmp             w0, NULL
    // 0x894c54: b.eq            #0x894cd4
    // 0x894c58: LoadField: r3 = r1->field_37
    //     0x894c58: ldur            w3, [x1, #0x37]
    // 0x894c5c: DecompressPointer r3
    //     0x894c5c: add             x3, x3, HEAP, lsl #32
    // 0x894c60: stur            x3, [fp, #-8]
    // 0x894c64: cmp             w3, NULL
    // 0x894c68: b.eq            #0x894cd8
    // 0x894c6c: LoadField: r2 = r3->field_13
    //     0x894c6c: ldur            w2, [x3, #0x13]
    // 0x894c70: DecompressPointer r2
    //     0x894c70: add             x2, x2, HEAP, lsl #32
    // 0x894c74: mov             x1, x0
    // 0x894c78: r0 = rect=()
    //     0x894c78: bl              #0x892bd8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0x894c7c: ldur            x0, [fp, #-8]
    // 0x894c80: LoadField: r2 = r0->field_7
    //     0x894c80: ldur            w2, [x0, #7]
    // 0x894c84: DecompressPointer r2
    //     0x894c84: add             x2, x2, HEAP, lsl #32
    // 0x894c88: ldur            x1, [fp, #-0x10]
    // 0x894c8c: r0 = transform=()
    //     0x894c8c: bl              #0x8928fc  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::transform=
    // 0x894c90: ldur            x1, [fp, #-8]
    // 0x894c94: LoadField: r0 = r1->field_f
    //     0x894c94: ldur            w0, [x1, #0xf]
    // 0x894c98: DecompressPointer r0
    //     0x894c98: add             x0, x0, HEAP, lsl #32
    // 0x894c9c: ldur            x1, [fp, #-0x10]
    // 0x894ca0: StoreField: r1->field_23 = r0
    //     0x894ca0: stur            w0, [x1, #0x23]
    //     0x894ca4: ldurb           w16, [x1, #-1]
    //     0x894ca8: ldurb           w17, [x0, #-1]
    //     0x894cac: and             x16, x17, x16, lsr #2
    //     0x894cb0: tst             x16, HEAP, lsr #32
    //     0x894cb4: b.eq            #0x894cbc
    //     0x894cb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x894cbc: r0 = Null
    //     0x894cbc: mov             x0, NULL
    // 0x894cc0: LeaveFrame
    //     0x894cc0: mov             SP, fp
    //     0x894cc4: ldp             fp, lr, [SP], #0x10
    // 0x894cc8: ret
    //     0x894cc8: ret             
    // 0x894ccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x894ccc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x894cd0: b               #0x894c44
    // 0x894cd4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x894cd4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x894cd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x894cd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _createSemanticsNode(/* No info */) {
    // ** addr: 0x894cdc, size: 0x150
    // 0x894cdc: EnterFrame
    //     0x894cdc: stp             fp, lr, [SP, #-0x10]!
    //     0x894ce0: mov             fp, SP
    // 0x894ce4: AllocStack(0x20)
    //     0x894ce4: sub             SP, SP, #0x20
    // 0x894ce8: CheckStackOverflow
    //     0x894ce8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x894cec: cmp             SP, x16
    //     0x894cf0: b.ls            #0x894e1c
    // 0x894cf4: LoadField: r2 = r1->field_7
    //     0x894cf4: ldur            w2, [x1, #7]
    // 0x894cf8: DecompressPointer r2
    //     0x894cf8: add             x2, x2, HEAP, lsl #32
    // 0x894cfc: stur            x2, [fp, #-8]
    // 0x894d00: r0 = LoadClassIdInstr(r2)
    //     0x894d00: ldur            x0, [x2, #-1]
    //     0x894d04: ubfx            x0, x0, #0xc, #0x14
    // 0x894d08: mov             x1, x2
    // 0x894d0c: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x894d0c: mov             x17, #0xfc0
    //     0x894d10: movk            x17, #1, lsl #16
    //     0x894d14: add             lr, x0, x17
    //     0x894d18: ldr             lr, [x21, lr, lsl #3]
    //     0x894d1c: blr             lr
    // 0x894d20: cmp             w0, NULL
    // 0x894d24: b.ne            #0x894da0
    // 0x894d28: ldur            x1, [fp, #-8]
    // 0x894d2c: r0 = LoadClassIdInstr(r1)
    //     0x894d2c: ldur            x0, [x1, #-1]
    //     0x894d30: ubfx            x0, x0, #0xc, #0x14
    // 0x894d34: str             x1, [SP]
    // 0x894d38: r0 = GDT[cid_x0 + 0x10d7a]()
    //     0x894d38: mov             x17, #0xd7a
    //     0x894d3c: movk            x17, #1, lsl #16
    //     0x894d40: add             lr, x0, x17
    //     0x894d44: ldr             lr, [x21, lr, lsl #3]
    //     0x894d48: blr             lr
    // 0x894d4c: ldur            x2, [fp, #-8]
    // 0x894d50: stur            x0, [fp, #-0x18]
    // 0x894d54: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x894d54: ldur            w1, [x2, #0x17]
    // 0x894d58: DecompressPointer r1
    //     0x894d58: add             x1, x1, HEAP, lsl #32
    // 0x894d5c: cmp             w1, NULL
    // 0x894d60: b.eq            #0x894e24
    // 0x894d64: LoadField: r2 = r1->field_2b
    //     0x894d64: ldur            w2, [x1, #0x2b]
    // 0x894d68: DecompressPointer r2
    //     0x894d68: add             x2, x2, HEAP, lsl #32
    // 0x894d6c: stur            x2, [fp, #-0x10]
    // 0x894d70: cmp             w2, NULL
    // 0x894d74: b.eq            #0x894e28
    // 0x894d78: r0 = SemanticsNode()
    //     0x894d78: bl              #0x894094  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xf0)
    // 0x894d7c: mov             x1, x0
    // 0x894d80: ldur            x2, [fp, #-0x10]
    // 0x894d84: ldur            x3, [fp, #-0x18]
    // 0x894d88: stur            x0, [fp, #-0x10]
    // 0x894d8c: r0 = SemanticsNode.root()
    //     0x894d8c: bl              #0x894e2c  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode.root
    // 0x894d90: ldur            x0, [fp, #-0x10]
    // 0x894d94: LeaveFrame
    //     0x894d94: mov             SP, fp
    //     0x894d98: ldp             fp, lr, [SP], #0x10
    // 0x894d9c: ret
    //     0x894d9c: ret             
    // 0x894da0: ldur            x2, [fp, #-8]
    // 0x894da4: mov             x1, x0
    // 0x894da8: LoadField: r0 = r1->field_43
    //     0x894da8: ldur            w0, [x1, #0x43]
    // 0x894dac: DecompressPointer r0
    //     0x894dac: add             x0, x0, HEAP, lsl #32
    // 0x894db0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x894db4: cmp             w0, w16
    // 0x894db8: b.ne            #0x894dc4
    // 0x894dbc: r2 = _semantics
    //     0x894dbc: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x894dc0: r0 = InitLateFinalInstanceField()
    //     0x894dc0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x894dc4: ldur            x0, [fp, #-8]
    // 0x894dc8: r1 = LoadClassIdInstr(r0)
    //     0x894dc8: ldur            x1, [x0, #-1]
    //     0x894dcc: ubfx            x1, x1, #0xc, #0x14
    // 0x894dd0: str             x0, [SP]
    // 0x894dd4: mov             x0, x1
    // 0x894dd8: r0 = GDT[cid_x0 + 0x10d7a]()
    //     0x894dd8: mov             x17, #0xd7a
    //     0x894ddc: movk            x17, #1, lsl #16
    //     0x894de0: add             lr, x0, x17
    //     0x894de4: ldr             lr, [x21, lr, lsl #3]
    //     0x894de8: blr             lr
    // 0x894dec: stur            x0, [fp, #-8]
    // 0x894df0: r0 = SemanticsNode()
    //     0x894df0: bl              #0x894094  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xf0)
    // 0x894df4: stur            x0, [fp, #-0x10]
    // 0x894df8: ldur            x16, [fp, #-8]
    // 0x894dfc: str             x16, [SP]
    // 0x894e00: mov             x1, x0
    // 0x894e04: r4 = const [0, 0x2, 0x1, 0x1, showOnScreen, 0x1, null]
    //     0x894e04: ldr             x4, [PP, #0x29d8]  ; [pp+0x29d8] List(7) [0, 0x2, 0x1, 0x1, "showOnScreen", 0x1, Null]
    // 0x894e08: r0 = SemanticsNode()
    //     0x894e08: bl              #0x893ce8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0x894e0c: ldur            x0, [fp, #-0x10]
    // 0x894e10: LeaveFrame
    //     0x894e10: mov             SP, fp
    //     0x894e14: ldp             fp, lr, [SP], #0x10
    // 0x894e18: ret
    //     0x894e18: ret             
    // 0x894e1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x894e1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x894e20: b               #0x894cf4
    // 0x894e24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x894e24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x894e28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x894e28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ensureGeometry(/* No info */) {
    // ** addr: 0x89517c, size: 0x134
    // 0x89517c: EnterFrame
    //     0x89517c: stp             fp, lr, [SP, #-0x10]!
    //     0x895180: mov             fp, SP
    // 0x895184: AllocStack(0x28)
    //     0x895184: sub             SP, SP, #0x28
    // 0x895188: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x8 */)
    //     0x895188: mov             x0, x1
    //     0x89518c: stur            x1, [fp, #-8]
    // 0x895190: CheckStackOverflow
    //     0x895190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895194: cmp             SP, x16
    //     0x895198: b.ls            #0x8952a8
    // 0x89519c: mov             x1, x0
    // 0x8951a0: r0 = isRoot()
    //     0x8951a0: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x8951a4: tbnz            w0, #4, #0x895284
    // 0x8951a8: ldur            x2, [fp, #-8]
    // 0x8951ac: LoadField: r0 = r2->field_37
    //     0x8951ac: ldur            w0, [x2, #0x37]
    // 0x8951b0: DecompressPointer r0
    //     0x8951b0: add             x0, x0, HEAP, lsl #32
    // 0x8951b4: cmp             w0, NULL
    // 0x8951b8: b.ne            #0x8951c4
    // 0x8951bc: r3 = Null
    //     0x8951bc: mov             x3, NULL
    // 0x8951c0: b               #0x8951d0
    // 0x8951c4: LoadField: r1 = r0->field_13
    //     0x8951c4: ldur            w1, [x0, #0x13]
    // 0x8951c8: DecompressPointer r1
    //     0x8951c8: add             x1, x1, HEAP, lsl #32
    // 0x8951cc: mov             x3, x1
    // 0x8951d0: stur            x3, [fp, #-0x18]
    // 0x8951d4: LoadField: r4 = r2->field_7
    //     0x8951d4: ldur            w4, [x2, #7]
    // 0x8951d8: DecompressPointer r4
    //     0x8951d8: add             x4, x4, HEAP, lsl #32
    // 0x8951dc: stur            x4, [fp, #-0x10]
    // 0x8951e0: r0 = LoadClassIdInstr(r4)
    //     0x8951e0: ldur            x0, [x4, #-1]
    //     0x8951e4: ubfx            x0, x0, #0xc, #0x14
    // 0x8951e8: mov             x1, x4
    // 0x8951ec: r0 = GDT[cid_x0 + 0x1021c]()
    //     0x8951ec: mov             x17, #0x21c
    //     0x8951f0: movk            x17, #1, lsl #16
    //     0x8951f4: add             lr, x0, x17
    //     0x8951f8: ldr             lr, [x21, lr, lsl #3]
    //     0x8951fc: blr             lr
    // 0x895200: mov             x1, x0
    // 0x895204: ldur            x0, [fp, #-0x18]
    // 0x895208: r2 = LoadClassIdInstr(r0)
    //     0x895208: ldur            x2, [x0, #-1]
    //     0x89520c: ubfx            x2, x2, #0xc, #0x14
    // 0x895210: stp             x1, x0, [SP]
    // 0x895214: mov             x0, x2
    // 0x895218: mov             lr, x0
    // 0x89521c: ldr             lr, [x21, lr, lsl #3]
    // 0x895220: blr             lr
    // 0x895224: tbz             w0, #4, #0x895230
    // 0x895228: ldur            x1, [fp, #-8]
    // 0x89522c: r0 = markNeedsBuild()
    //     0x89522c: bl              #0x890088  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::markNeedsBuild
    // 0x895230: ldur            x2, [fp, #-8]
    // 0x895234: ldur            x1, [fp, #-0x10]
    // 0x895238: r0 = LoadClassIdInstr(r1)
    //     0x895238: ldur            x0, [x1, #-1]
    //     0x89523c: ubfx            x0, x0, #0xc, #0x14
    // 0x895240: r0 = GDT[cid_x0 + 0x1021c]()
    //     0x895240: mov             x17, #0x21c
    //     0x895244: movk            x17, #1, lsl #16
    //     0x895248: add             lr, x0, x17
    //     0x89524c: ldr             lr, [x21, lr, lsl #3]
    //     0x895250: blr             lr
    // 0x895254: mov             x2, x0
    // 0x895258: r1 = Null
    //     0x895258: mov             x1, NULL
    // 0x89525c: r0 = _SemanticsGeometry.root()
    //     0x89525c: bl              #0x895808  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::_SemanticsGeometry.root
    // 0x895260: ldur            x1, [fp, #-8]
    // 0x895264: StoreField: r1->field_37 = r0
    //     0x895264: stur            w0, [x1, #0x37]
    //     0x895268: ldurb           w16, [x1, #-1]
    //     0x89526c: ldurb           w17, [x0, #-1]
    //     0x895270: and             x16, x17, x16, lsr #2
    //     0x895274: tst             x16, HEAP, lsr #32
    //     0x895278: b.eq            #0x895280
    //     0x89527c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x895280: b               #0x895288
    // 0x895284: ldur            x1, [fp, #-8]
    // 0x895288: r16 = true
    //     0x895288: add             x16, NULL, #0x20  ; true
    // 0x89528c: str             x16, [SP]
    // 0x895290: r4 = const [0, 0x2, 0x1, 0x1, onlyDirtyChildren, 0x1, null]
    //     0x895290: ldr             x4, [PP, #0x2ab0]  ; [pp+0x2ab0] List(7) [0, 0x2, 0x1, 0x1, "onlyDirtyChildren", 0x1, Null]
    // 0x895294: r0 = _updateChildGeometry()
    //     0x895294: bl              #0x8952b0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_updateChildGeometry
    // 0x895298: r0 = Null
    //     0x895298: mov             x0, NULL
    // 0x89529c: LeaveFrame
    //     0x89529c: mov             SP, fp
    //     0x8952a0: ldp             fp, lr, [SP], #0x10
    // 0x8952a4: ret
    //     0x8952a4: ret             
    // 0x8952a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8952a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8952ac: b               #0x89519c
  }
  _ _updateChildGeometry(/* No info */) {
    // ** addr: 0x8952b0, size: 0x300
    // 0x8952b0: EnterFrame
    //     0x8952b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8952b4: mov             fp, SP
    // 0x8952b8: AllocStack(0x70)
    //     0x8952b8: sub             SP, SP, #0x70
    // 0x8952bc: SetupParameters(_RenderObjectSemantics this /* r1 => r2, fp-0x48 */, {dynamic onlyDirtyChildren = false /* r0, fp-0x40 */})
    //     0x8952bc: mov             x2, x1
    //     0x8952c0: stur            x1, [fp, #-0x48]
    //     0x8952c4: ldur            w0, [x4, #0x13]
    //     0x8952c8: ldur            w1, [x4, #0x1f]
    //     0x8952cc: add             x1, x1, HEAP, lsl #32
    //     0x8952d0: ldr             x16, [PP, #0x2ab8]  ; [pp+0x2ab8] "onlyDirtyChildren"
    //     0x8952d4: cmp             w1, w16
    //     0x8952d8: b.ne            #0x8952f4
    //     0x8952dc: ldur            w1, [x4, #0x23]
    //     0x8952e0: add             x1, x1, HEAP, lsl #32
    //     0x8952e4: sub             w3, w0, w1
    //     0x8952e8: add             x0, fp, w3, sxtw #2
    //     0x8952ec: ldr             x0, [x0, #8]
    //     0x8952f0: b               #0x8952f8
    //     0x8952f4: add             x0, NULL, #0x30  ; false
    //     0x8952f8: stur            x0, [fp, #-0x40]
    // 0x8952fc: CheckStackOverflow
    //     0x8952fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895300: cmp             SP, x16
    //     0x895304: b.ls            #0x895594
    // 0x895308: LoadField: r3 = r2->field_37
    //     0x895308: ldur            w3, [x2, #0x37]
    // 0x89530c: DecompressPointer r3
    //     0x89530c: add             x3, x3, HEAP, lsl #32
    // 0x895310: stur            x3, [fp, #-0x38]
    // 0x895314: cmp             w3, NULL
    // 0x895318: b.eq            #0x89559c
    // 0x89531c: LoadField: r4 = r2->field_27
    //     0x89531c: ldur            w4, [x2, #0x27]
    // 0x895320: DecompressPointer r4
    //     0x895320: add             x4, x4, HEAP, lsl #32
    // 0x895324: stur            x4, [fp, #-0x30]
    // 0x895328: LoadField: r1 = r4->field_b
    //     0x895328: ldur            w1, [x4, #0xb]
    // 0x89532c: r5 = LoadInt32Instr(r1)
    //     0x89532c: sbfx            x5, x1, #1, #0x1f
    // 0x895330: stur            x5, [fp, #-0x28]
    // 0x895334: LoadField: r6 = r3->field_f
    //     0x895334: ldur            w6, [x3, #0xf]
    // 0x895338: DecompressPointer r6
    //     0x895338: add             x6, x6, HEAP, lsl #32
    // 0x89533c: stur            x6, [fp, #-0x20]
    // 0x895340: LoadField: r7 = r3->field_b
    //     0x895340: ldur            w7, [x3, #0xb]
    // 0x895344: DecompressPointer r7
    //     0x895344: add             x7, x7, HEAP, lsl #32
    // 0x895348: stur            x7, [fp, #-0x18]
    // 0x89534c: r1 = 0
    //     0x89534c: mov             x1, #0
    // 0x895350: CheckStackOverflow
    //     0x895350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895354: cmp             SP, x16
    //     0x895358: b.ls            #0x8955a0
    // 0x89535c: LoadField: r8 = r4->field_b
    //     0x89535c: ldur            w8, [x4, #0xb]
    // 0x895360: r9 = LoadInt32Instr(r8)
    //     0x895360: sbfx            x9, x8, #1, #0x1f
    // 0x895364: cmp             x5, x9
    // 0x895368: b.ne            #0x895574
    // 0x89536c: cmp             x1, x9
    // 0x895370: b.ge            #0x895408
    // 0x895374: LoadField: r8 = r4->field_f
    //     0x895374: ldur            w8, [x4, #0xf]
    // 0x895378: DecompressPointer r8
    //     0x895378: add             x8, x8, HEAP, lsl #32
    // 0x89537c: ArrayLoad: r9 = r8[r1]  ; Unknown_4
    //     0x89537c: add             x16, x8, x1, lsl #2
    //     0x895380: ldur            w9, [x16, #0xf]
    // 0x895384: DecompressPointer r9
    //     0x895384: add             x9, x9, HEAP, lsl #32
    // 0x895388: stur            x9, [fp, #-0x10]
    // 0x89538c: add             x8, x1, #1
    // 0x895390: stur            x8, [fp, #-8]
    // 0x895394: tbnz            w0, #4, #0x8953bc
    // 0x895398: mov             x1, x9
    // 0x89539c: r0 = isRoot()
    //     0x89539c: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x8953a0: tbz             w0, #4, #0x8953e4
    // 0x8953a4: ldur            x0, [fp, #-0x10]
    // 0x8953a8: LoadField: r1 = r0->field_37
    //     0x8953a8: ldur            w1, [x0, #0x37]
    // 0x8953ac: DecompressPointer r1
    //     0x8953ac: add             x1, x1, HEAP, lsl #32
    // 0x8953b0: cmp             w1, NULL
    // 0x8953b4: b.eq            #0x8953c0
    // 0x8953b8: b               #0x8953e4
    // 0x8953bc: mov             x0, x9
    // 0x8953c0: mov             x1, x0
    // 0x8953c4: ldur            x2, [fp, #-0x48]
    // 0x8953c8: ldur            x3, [fp, #-0x20]
    // 0x8953cc: ldur            x5, [fp, #-0x18]
    // 0x8953d0: r6 = Null
    //     0x8953d0: mov             x6, NULL
    // 0x8953d4: r0 = computeChildGeometry()
    //     0x8953d4: bl              #0x8930e4  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::computeChildGeometry
    // 0x8953d8: ldur            x1, [fp, #-0x10]
    // 0x8953dc: mov             x2, x0
    // 0x8953e0: r0 = _updateGeometry()
    //     0x8953e0: bl              #0x8955b0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_updateGeometry
    // 0x8953e4: ldur            x1, [fp, #-8]
    // 0x8953e8: ldur            x2, [fp, #-0x48]
    // 0x8953ec: ldur            x0, [fp, #-0x40]
    // 0x8953f0: ldur            x3, [fp, #-0x38]
    // 0x8953f4: ldur            x4, [fp, #-0x30]
    // 0x8953f8: ldur            x6, [fp, #-0x20]
    // 0x8953fc: ldur            x7, [fp, #-0x18]
    // 0x895400: ldur            x5, [fp, #-0x28]
    // 0x895404: b               #0x895350
    // 0x895408: mov             x0, x2
    // 0x89540c: LoadField: r4 = r0->field_2b
    //     0x89540c: ldur            w4, [x0, #0x2b]
    // 0x895410: DecompressPointer r4
    //     0x895410: add             x4, x4, HEAP, lsl #32
    // 0x895414: stur            x4, [fp, #-0x10]
    // 0x895418: r1 = Function '<anonymous closure>':.
    //     0x895418: ldr             x1, [PP, #0x2ac0]  ; [pp+0x2ac0] AnonymousClosure: (0x13dae90), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_mergeSiblingGroup (0x891814)
    // 0x89541c: r2 = Null
    //     0x89541c: mov             x2, NULL
    // 0x895420: r0 = AllocateClosure()
    //     0x895420: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x895424: r16 = <_SemanticsFragment>
    //     0x895424: ldr             x16, [PP, #0x23c0]  ; [pp+0x23c0] TypeArguments: <_SemanticsFragment>
    // 0x895428: ldur            lr, [fp, #-0x10]
    // 0x89542c: stp             lr, x16, [SP, #8]
    // 0x895430: str             x0, [SP]
    // 0x895434: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x895434: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x895438: r0 = expand()
    //     0x895438: bl              #0x82aea0  ; [dart:collection] ListBase::expand
    // 0x89543c: r16 = <_RenderObjectSemantics>
    //     0x89543c: ldr             x16, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x895440: stp             x0, x16, [SP]
    // 0x895444: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x895444: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x895448: r0 = whereType()
    //     0x895448: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x89544c: r1 = Function '<anonymous closure>':.
    //     0x89544c: ldr             x1, [PP, #0x2ac8]  ; [pp+0x2ac8] AnonymousClosure: (0x895780), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_updateChildGeometry (0x8952b0)
    // 0x895450: r2 = Null
    //     0x895450: mov             x2, NULL
    // 0x895454: stur            x0, [fp, #-0x10]
    // 0x895458: r0 = AllocateClosure()
    //     0x895458: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x89545c: r16 = <_RenderObjectSemantics>
    //     0x89545c: ldr             x16, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x895460: ldur            lr, [fp, #-0x10]
    // 0x895464: stp             lr, x16, [SP, #8]
    // 0x895468: str             x0, [SP]
    // 0x89546c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x89546c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x895470: r0 = expand()
    //     0x895470: bl              #0x851010  ; [dart:core] Iterable::expand
    // 0x895474: mov             x1, x0
    // 0x895478: r0 = iterator()
    //     0x895478: bl              #0xb0a1a4  ; [dart:_internal] ExpandIterable::iterator
    // 0x89547c: mov             x2, x0
    // 0x895480: ldur            x0, [fp, #-0x38]
    // 0x895484: stur            x2, [fp, #-0x58]
    // 0x895488: LoadField: r6 = r0->field_7
    //     0x895488: ldur            w6, [x0, #7]
    // 0x89548c: DecompressPointer r6
    //     0x89548c: add             x6, x6, HEAP, lsl #32
    // 0x895490: stur            x6, [fp, #-0x50]
    // 0x895494: LoadField: r0 = r2->field_7
    //     0x895494: ldur            w0, [x2, #7]
    // 0x895498: DecompressPointer r0
    //     0x895498: add             x0, x0, HEAP, lsl #32
    // 0x89549c: stur            x0, [fp, #-0x10]
    // 0x8954a0: ldur            x3, [fp, #-0x40]
    // 0x8954a4: CheckStackOverflow
    //     0x8954a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8954a8: cmp             SP, x16
    //     0x8954ac: b.ls            #0x8955a8
    // 0x8954b0: mov             x1, x2
    // 0x8954b4: r0 = moveNext()
    //     0x8954b4: bl              #0x80f120  ; [dart:_internal] ExpandIterator::moveNext
    // 0x8954b8: tbnz            w0, #4, #0x895564
    // 0x8954bc: ldur            x3, [fp, #-0x58]
    // 0x8954c0: ArrayLoad: r4 = r3[0]  ; List_4
    //     0x8954c0: ldur            w4, [x3, #0x17]
    // 0x8954c4: DecompressPointer r4
    //     0x8954c4: add             x4, x4, HEAP, lsl #32
    // 0x8954c8: stur            x4, [fp, #-0x38]
    // 0x8954cc: cmp             w4, NULL
    // 0x8954d0: b.ne            #0x895500
    // 0x8954d4: mov             x0, x4
    // 0x8954d8: ldur            x2, [fp, #-0x10]
    // 0x8954dc: r1 = Null
    //     0x8954dc: mov             x1, NULL
    // 0x8954e0: cmp             w2, NULL
    // 0x8954e4: b.eq            #0x895500
    // 0x8954e8: LoadField: r4 = r2->field_1b
    //     0x8954e8: ldur            w4, [x2, #0x1b]
    // 0x8954ec: DecompressPointer r4
    //     0x8954ec: add             x4, x4, HEAP, lsl #32
    // 0x8954f0: r8 = X1
    //     0x8954f0: ldr             x8, [PP, #0xf00]  ; [pp+0xf00] TypeParameter: X1
    // 0x8954f4: LoadField: r9 = r4->field_7
    //     0x8954f4: ldur            x9, [x4, #7]
    // 0x8954f8: r3 = Null
    //     0x8954f8: ldr             x3, [PP, #0x2ad0]  ; [pp+0x2ad0] Null
    // 0x8954fc: blr             x9
    // 0x895500: ldur            x0, [fp, #-0x40]
    // 0x895504: tbnz            w0, #4, #0x89552c
    // 0x895508: ldur            x1, [fp, #-0x38]
    // 0x89550c: r0 = isRoot()
    //     0x89550c: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x895510: tbz             w0, #4, #0x895554
    // 0x895514: ldur            x0, [fp, #-0x38]
    // 0x895518: LoadField: r1 = r0->field_37
    //     0x895518: ldur            w1, [x0, #0x37]
    // 0x89551c: DecompressPointer r1
    //     0x89551c: add             x1, x1, HEAP, lsl #32
    // 0x895520: cmp             w1, NULL
    // 0x895524: b.eq            #0x895530
    // 0x895528: b               #0x895554
    // 0x89552c: ldur            x0, [fp, #-0x38]
    // 0x895530: mov             x1, x0
    // 0x895534: ldur            x2, [fp, #-0x48]
    // 0x895538: ldur            x3, [fp, #-0x20]
    // 0x89553c: ldur            x5, [fp, #-0x18]
    // 0x895540: ldur            x6, [fp, #-0x50]
    // 0x895544: r0 = computeChildGeometry()
    //     0x895544: bl              #0x8930e4  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::computeChildGeometry
    // 0x895548: ldur            x1, [fp, #-0x38]
    // 0x89554c: mov             x2, x0
    // 0x895550: r0 = _updateGeometry()
    //     0x895550: bl              #0x8955b0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_updateGeometry
    // 0x895554: ldur            x2, [fp, #-0x58]
    // 0x895558: ldur            x6, [fp, #-0x50]
    // 0x89555c: ldur            x0, [fp, #-0x10]
    // 0x895560: b               #0x8954a0
    // 0x895564: r0 = Null
    //     0x895564: mov             x0, NULL
    // 0x895568: LeaveFrame
    //     0x895568: mov             SP, fp
    //     0x89556c: ldp             fp, lr, [SP], #0x10
    // 0x895570: ret
    //     0x895570: ret             
    // 0x895574: mov             x0, x4
    // 0x895578: r0 = ConcurrentModificationError()
    //     0x895578: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x89557c: mov             x1, x0
    // 0x895580: ldur            x0, [fp, #-0x30]
    // 0x895584: StoreField: r1->field_b = r0
    //     0x895584: stur            w0, [x1, #0xb]
    // 0x895588: mov             x0, x1
    // 0x89558c: r0 = Throw()
    //     0x89558c: bl              #0x13ddb2c  ; ThrowStub
    // 0x895590: brk             #0
    // 0x895594: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895594: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895598: b               #0x895308
    // 0x89559c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89559c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8955a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8955a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8955a4: b               #0x89535c
    // 0x8955a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8955a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8955ac: b               #0x8954b0
  }
  _ _updateGeometry(/* No info */) {
    // ** addr: 0x8955b0, size: 0x1d0
    // 0x8955b0: EnterFrame
    //     0x8955b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8955b4: mov             fp, SP
    // 0x8955b8: AllocStack(0x28)
    //     0x8955b8: sub             SP, SP, #0x28
    // 0x8955bc: SetupParameters(_RenderObjectSemantics this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x8955bc: mov             x3, x1
    //     0x8955c0: stur            x1, [fp, #-0x18]
    //     0x8955c4: stur            x2, [fp, #-0x20]
    // 0x8955c8: CheckStackOverflow
    //     0x8955c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8955cc: cmp             SP, x16
    //     0x8955d0: b.ls            #0x895778
    // 0x8955d4: LoadField: r4 = r3->field_37
    //     0x8955d4: ldur            w4, [x3, #0x37]
    // 0x8955d8: DecompressPointer r4
    //     0x8955d8: add             x4, x4, HEAP, lsl #32
    // 0x8955dc: mov             x0, x2
    // 0x8955e0: stur            x4, [fp, #-0x10]
    // 0x8955e4: StoreField: r3->field_37 = r0
    //     0x8955e4: stur            w0, [x3, #0x37]
    //     0x8955e8: ldurb           w16, [x3, #-1]
    //     0x8955ec: ldurb           w17, [x0, #-1]
    //     0x8955f0: and             x16, x17, x16, lsr #2
    //     0x8955f4: tst             x16, HEAP, lsr #32
    //     0x8955f8: b.eq            #0x895600
    //     0x8955fc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x895600: cmp             w4, NULL
    // 0x895604: b.eq            #0x895754
    // 0x895608: LoadField: r0 = r3->field_3b
    //     0x895608: ldur            w0, [x3, #0x3b]
    // 0x89560c: DecompressPointer r0
    //     0x89560c: add             x0, x0, HEAP, lsl #32
    // 0x895610: mov             x1, x0
    // 0x895614: stur            x0, [fp, #-8]
    // 0x895618: r0 = original()
    //     0x895618: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x89561c: LoadField: r1 = r0->field_c3
    //     0x89561c: ldur            w1, [x0, #0xc3]
    // 0x895620: DecompressPointer r1
    //     0x895620: add             x1, x1, HEAP, lsl #32
    // 0x895624: LoadField: r0 = r1->field_47
    //     0x895624: ldur            w0, [x1, #0x47]
    // 0x895628: DecompressPointer r0
    //     0x895628: add             x0, x0, HEAP, lsl #32
    // 0x89562c: tbnz            w0, #4, #0x895640
    // 0x895630: ldur            x0, [fp, #-0x18]
    // 0x895634: ldur            x2, [fp, #-0x20]
    // 0x895638: r3 = true
    //     0x895638: add             x3, NULL, #0x20  ; true
    // 0x89563c: b               #0x895690
    // 0x895640: ldur            x0, [fp, #-0x18]
    // 0x895644: LoadField: r1 = r0->field_33
    //     0x895644: ldur            w1, [x0, #0x33]
    // 0x895648: DecompressPointer r1
    //     0x895648: add             x1, x1, HEAP, lsl #32
    // 0x89564c: cmp             w1, NULL
    // 0x895650: b.ne            #0x89565c
    // 0x895654: r1 = Null
    //     0x895654: mov             x1, NULL
    // 0x895658: b               #0x895668
    // 0x89565c: LoadField: r2 = r1->field_7
    //     0x89565c: ldur            w2, [x1, #7]
    // 0x895660: DecompressPointer r2
    //     0x895660: add             x2, x2, HEAP, lsl #32
    // 0x895664: mov             x1, x2
    // 0x895668: cmp             w1, NULL
    // 0x89566c: b.eq            #0x895674
    // 0x895670: tbz             w1, #4, #0x895688
    // 0x895674: ldur            x2, [fp, #-0x20]
    // 0x895678: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x895678: ldur            w1, [x2, #0x17]
    // 0x89567c: DecompressPointer r1
    //     0x89567c: add             x1, x1, HEAP, lsl #32
    // 0x895680: mov             x3, x1
    // 0x895684: b               #0x895690
    // 0x895688: ldur            x2, [fp, #-0x20]
    // 0x89568c: r3 = false
    //     0x89568c: add             x3, NULL, #0x30  ; false
    // 0x895690: ldur            x1, [fp, #-0x10]
    // 0x895694: stur            x3, [fp, #-0x28]
    // 0x895698: LoadField: r4 = r1->field_13
    //     0x895698: ldur            w4, [x1, #0x13]
    // 0x89569c: DecompressPointer r4
    //     0x89569c: add             x4, x4, HEAP, lsl #32
    // 0x8956a0: mov             x1, x4
    // 0x8956a4: r0 = size()
    //     0x8956a4: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0x8956a8: mov             x2, x0
    // 0x8956ac: ldur            x0, [fp, #-0x20]
    // 0x8956b0: stur            x2, [fp, #-0x10]
    // 0x8956b4: LoadField: r1 = r0->field_13
    //     0x8956b4: ldur            w1, [x0, #0x13]
    // 0x8956b8: DecompressPointer r1
    //     0x8956b8: add             x1, x1, HEAP, lsl #32
    // 0x8956bc: r0 = size()
    //     0x8956bc: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0x8956c0: LoadField: d0 = r0->field_7
    //     0x8956c0: ldur            d0, [x0, #7]
    // 0x8956c4: ldur            x1, [fp, #-0x10]
    // 0x8956c8: LoadField: d1 = r1->field_7
    //     0x8956c8: ldur            d1, [x1, #7]
    // 0x8956cc: fcmp            d0, d1
    // 0x8956d0: b.ne            #0x8956f0
    // 0x8956d4: LoadField: d0 = r0->field_f
    //     0x8956d4: ldur            d0, [x0, #0xf]
    // 0x8956d8: LoadField: d1 = r1->field_f
    //     0x8956d8: ldur            d1, [x1, #0xf]
    // 0x8956dc: fcmp            d0, d1
    // 0x8956e0: r16 = true
    //     0x8956e0: add             x16, NULL, #0x20  ; true
    // 0x8956e4: r17 = false
    //     0x8956e4: add             x17, NULL, #0x30  ; false
    // 0x8956e8: csel            x0, x16, x17, eq
    // 0x8956ec: b               #0x8956f4
    // 0x8956f0: r0 = false
    //     0x8956f0: add             x0, NULL, #0x30  ; false
    // 0x8956f4: ldur            x1, [fp, #-8]
    // 0x8956f8: eor             x2, x0, #0x10
    // 0x8956fc: stur            x2, [fp, #-0x10]
    // 0x895700: LoadField: r0 = r1->field_13
    //     0x895700: ldur            w0, [x1, #0x13]
    // 0x895704: DecompressPointer r0
    //     0x895704: add             x0, x0, HEAP, lsl #32
    // 0x895708: cmp             w0, NULL
    // 0x89570c: b.ne            #0x89571c
    // 0x895710: r0 = original()
    //     0x895710: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895714: mov             x1, x0
    // 0x895718: b               #0x895720
    // 0x89571c: mov             x1, x0
    // 0x895720: ldur            x0, [fp, #-0x10]
    // 0x895724: LoadField: r2 = r1->field_c3
    //     0x895724: ldur            w2, [x1, #0xc3]
    // 0x895728: DecompressPointer r2
    //     0x895728: add             x2, x2, HEAP, lsl #32
    // 0x89572c: LoadField: r1 = r2->field_47
    //     0x89572c: ldur            w1, [x2, #0x47]
    // 0x895730: DecompressPointer r1
    //     0x895730: add             x1, x1, HEAP, lsl #32
    // 0x895734: tbz             w0, #4, #0x895754
    // 0x895738: ldur            x0, [fp, #-0x28]
    // 0x89573c: cmp             w1, w0
    // 0x895740: b.ne            #0x895754
    // 0x895744: r0 = Null
    //     0x895744: mov             x0, NULL
    // 0x895748: LeaveFrame
    //     0x895748: mov             SP, fp
    //     0x89574c: ldp             fp, lr, [SP], #0x10
    // 0x895750: ret
    //     0x895750: ret             
    // 0x895754: ldur            x1, [fp, #-0x18]
    // 0x895758: r0 = markNeedsBuild()
    //     0x895758: bl              #0x890088  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::markNeedsBuild
    // 0x89575c: ldur            x1, [fp, #-0x18]
    // 0x895760: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x895760: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x895764: r0 = _updateChildGeometry()
    //     0x895764: bl              #0x8952b0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_updateChildGeometry
    // 0x895768: r0 = Null
    //     0x895768: mov             x0, NULL
    // 0x89576c: LeaveFrame
    //     0x89576c: mov             SP, fp
    //     0x895770: ldp             fp, lr, [SP], #0x10
    // 0x895774: ret
    //     0x895774: ret             
    // 0x895778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895778: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89577c: b               #0x8955d4
  }
  [closure] List<_RenderObjectSemantics> <anonymous closure>(dynamic, _RenderObjectSemantics) {
    // ** addr: 0x895780, size: 0x88
    // 0x895780: EnterFrame
    //     0x895780: stp             fp, lr, [SP, #-0x10]!
    //     0x895784: mov             fp, SP
    // 0x895788: AllocStack(0x8)
    //     0x895788: sub             SP, SP, #8
    // 0x89578c: CheckStackOverflow
    //     0x89578c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895790: cmp             SP, x16
    //     0x895794: b.ls            #0x895800
    // 0x895798: ldr             x1, [fp, #0x10]
    // 0x89579c: r0 = shouldFormSemanticsNode()
    //     0x89579c: bl              #0x895ca4  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::shouldFormSemanticsNode
    // 0x8957a0: tbnz            w0, #4, #0x8957e4
    // 0x8957a4: ldr             x3, [fp, #0x10]
    // 0x8957a8: r0 = 2
    //     0x8957a8: mov             x0, #2
    // 0x8957ac: mov             x2, x0
    // 0x8957b0: r1 = Null
    //     0x8957b0: mov             x1, NULL
    // 0x8957b4: r0 = AllocateArray()
    //     0x8957b4: bl              #0x13df928  ; AllocateArrayStub
    // 0x8957b8: mov             x2, x0
    // 0x8957bc: ldr             x0, [fp, #0x10]
    // 0x8957c0: stur            x2, [fp, #-8]
    // 0x8957c4: StoreField: r2->field_f = r0
    //     0x8957c4: stur            w0, [x2, #0xf]
    // 0x8957c8: r1 = <_RenderObjectSemantics>
    //     0x8957c8: ldr             x1, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x8957cc: r0 = AllocateGrowableArray()
    //     0x8957cc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x8957d0: ldur            x1, [fp, #-8]
    // 0x8957d4: StoreField: r0->field_f = r1
    //     0x8957d4: stur            w1, [x0, #0xf]
    // 0x8957d8: r1 = 2
    //     0x8957d8: mov             x1, #2
    // 0x8957dc: StoreField: r0->field_b = r1
    //     0x8957dc: stur            w1, [x0, #0xb]
    // 0x8957e0: b               #0x8957f4
    // 0x8957e4: ldr             x0, [fp, #0x10]
    // 0x8957e8: LoadField: r1 = r0->field_27
    //     0x8957e8: ldur            w1, [x0, #0x27]
    // 0x8957ec: DecompressPointer r1
    //     0x8957ec: add             x1, x1, HEAP, lsl #32
    // 0x8957f0: mov             x0, x1
    // 0x8957f4: LeaveFrame
    //     0x8957f4: mov             SP, fp
    //     0x8957f8: ldp             fp, lr, [SP], #0x10
    // 0x8957fc: ret
    //     0x8957fc: ret             
    // 0x895800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895800: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895804: b               #0x895798
  }
  _ computeAncestorInfo(/* No info */) {
    // ** addr: 0x895878, size: 0x308
    // 0x895878: EnterFrame
    //     0x895878: stp             fp, lr, [SP, #-0x10]!
    //     0x89587c: mov             fp, SP
    // 0x895880: AllocStack(0x18)
    //     0x895880: sub             SP, SP, #0x18
    // 0x895884: SetupParameters(_RenderObjectSemantics this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x895884: mov             x3, x1
    //     0x895888: stur            x1, [fp, #-8]
    //     0x89588c: stur            x2, [fp, #-0x10]
    // 0x895890: CheckStackOverflow
    //     0x895890: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895894: cmp             SP, x16
    //     0x895898: b.ls            #0x895b68
    // 0x89589c: LoadField: r0 = r3->field_43
    //     0x89589c: ldur            w0, [x3, #0x43]
    // 0x8958a0: DecompressPointer r0
    //     0x8958a0: add             x0, x0, HEAP, lsl #32
    // 0x8958a4: cmp             w2, w0
    // 0x8958a8: b.ne            #0x8958bc
    // 0x8958ac: r0 = Null
    //     0x8958ac: mov             x0, NULL
    // 0x8958b0: LeaveFrame
    //     0x8958b0: mov             SP, fp
    //     0x8958b4: ldp             fp, lr, [SP], #0x10
    // 0x8958b8: ret
    //     0x8958b8: ret             
    // 0x8958bc: mov             x0, x2
    // 0x8958c0: StoreField: r3->field_43 = r0
    //     0x8958c0: stur            w0, [x3, #0x43]
    //     0x8958c4: ldurb           w16, [x3, #-1]
    //     0x8958c8: ldurb           w17, [x0, #-1]
    //     0x8958cc: and             x16, x17, x16, lsr #2
    //     0x8958d0: tst             x16, HEAP, lsr #32
    //     0x8958d4: b.eq            #0x8958dc
    //     0x8958d8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8958dc: mov             x1, x3
    // 0x8958e0: r0 = isRoot()
    //     0x8958e0: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x8958e4: tbnz            w0, #4, #0x89591c
    // 0x8958e8: ldur            x2, [fp, #-8]
    // 0x8958ec: mov             x0, x2
    // 0x8958f0: StoreField: r2->field_47 = r0
    //     0x8958f0: stur            w0, [x2, #0x47]
    //     0x8958f4: ldurb           w16, [x2, #-1]
    //     0x8958f8: ldurb           w17, [x0, #-1]
    //     0x8958fc: and             x16, x17, x16, lsr #2
    //     0x895900: tst             x16, HEAP, lsr #32
    //     0x895904: b.eq            #0x89590c
    //     0x895908: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x89590c: r0 = Null
    //     0x89590c: mov             x0, NULL
    // 0x895910: LeaveFrame
    //     0x895910: mov             SP, fp
    //     0x895914: ldp             fp, lr, [SP], #0x10
    // 0x895918: ret
    //     0x895918: ret             
    // 0x89591c: ldur            x2, [fp, #-8]
    // 0x895920: StoreField: r2->field_47 = rNULL
    //     0x895920: stur            NULL, [x2, #0x47]
    // 0x895924: mov             x1, x2
    // 0x895928: r0 = isRoot()
    //     0x895928: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x89592c: tbnz            w0, #4, #0x895938
    // 0x895930: ldur            x0, [fp, #-8]
    // 0x895934: b               #0x89595c
    // 0x895938: ldur            x0, [fp, #-8]
    // 0x89593c: LoadField: r1 = r0->field_33
    //     0x89593c: ldur            w1, [x0, #0x33]
    // 0x895940: DecompressPointer r1
    //     0x895940: add             x1, x1, HEAP, lsl #32
    // 0x895944: cmp             w1, NULL
    // 0x895948: b.ne            #0x89595c
    // 0x89594c: r0 = Null
    //     0x89594c: mov             x0, NULL
    // 0x895950: LeaveFrame
    //     0x895950: mov             SP, fp
    //     0x895954: ldp             fp, lr, [SP], #0x10
    // 0x895958: ret
    //     0x895958: ret             
    // 0x89595c: mov             x1, x0
    // 0x895960: r0 = shouldFormSemanticsNode()
    //     0x895960: bl              #0x895ca4  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::shouldFormSemanticsNode
    // 0x895964: tbnz            w0, #4, #0x8959bc
    // 0x895968: ldur            x1, [fp, #-8]
    // 0x89596c: r0 = isRoot()
    //     0x89596c: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x895970: tbnz            w0, #4, #0x89597c
    // 0x895974: ldur            x2, [fp, #-8]
    // 0x895978: b               #0x895990
    // 0x89597c: ldur            x2, [fp, #-8]
    // 0x895980: LoadField: r0 = r2->field_37
    //     0x895980: ldur            w0, [x2, #0x37]
    // 0x895984: DecompressPointer r0
    //     0x895984: add             x0, x0, HEAP, lsl #32
    // 0x895988: cmp             w0, NULL
    // 0x89598c: b.eq            #0x8959b0
    // 0x895990: mov             x0, x2
    // 0x895994: StoreField: r2->field_47 = r0
    //     0x895994: stur            w0, [x2, #0x47]
    //     0x895998: ldurb           w16, [x2, #-1]
    //     0x89599c: ldurb           w17, [x0, #-1]
    //     0x8959a0: and             x16, x17, x16, lsr #2
    //     0x8959a4: tst             x16, HEAP, lsr #32
    //     0x8959a8: b.eq            #0x8959b0
    //     0x8959ac: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8959b0: LoadField: r0 = r2->field_3f
    //     0x8959b0: ldur            w0, [x2, #0x3f]
    // 0x8959b4: DecompressPointer r0
    //     0x8959b4: add             x0, x0, HEAP, lsl #32
    // 0x8959b8: b               #0x895af0
    // 0x8959bc: ldur            x2, [fp, #-8]
    // 0x8959c0: mov             x0, x2
    // 0x8959c4: stur            x0, [fp, #-0x18]
    // 0x8959c8: CheckStackOverflow
    //     0x8959c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8959cc: cmp             SP, x16
    //     0x8959d0: b.ls            #0x895b70
    // 0x8959d4: cmp             w0, NULL
    // 0x8959d8: b.eq            #0x895b78
    // 0x8959dc: mov             x1, x0
    // 0x8959e0: r0 = isRoot()
    //     0x8959e0: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x8959e4: tbnz            w0, #4, #0x8959f0
    // 0x8959e8: ldur            x0, [fp, #-0x18]
    // 0x8959ec: b               #0x895a04
    // 0x8959f0: ldur            x0, [fp, #-0x18]
    // 0x8959f4: LoadField: r1 = r0->field_33
    //     0x8959f4: ldur            w1, [x0, #0x33]
    // 0x8959f8: DecompressPointer r1
    //     0x8959f8: add             x1, x1, HEAP, lsl #32
    // 0x8959fc: cmp             w1, NULL
    // 0x895a00: b.eq            #0x895af0
    // 0x895a04: LoadField: r1 = r0->field_3b
    //     0x895a04: ldur            w1, [x0, #0x3b]
    // 0x895a08: DecompressPointer r1
    //     0x895a08: add             x1, x1, HEAP, lsl #32
    // 0x895a0c: LoadField: r2 = r1->field_13
    //     0x895a0c: ldur            w2, [x1, #0x13]
    // 0x895a10: DecompressPointer r2
    //     0x895a10: add             x2, x2, HEAP, lsl #32
    // 0x895a14: cmp             w2, NULL
    // 0x895a18: b.ne            #0x895a2c
    // 0x895a1c: r0 = original()
    //     0x895a1c: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895a20: mov             x1, x0
    // 0x895a24: mov             x0, x1
    // 0x895a28: b               #0x895a30
    // 0x895a2c: mov             x0, x2
    // 0x895a30: LoadField: r1 = r0->field_7
    //     0x895a30: ldur            w1, [x0, #7]
    // 0x895a34: DecompressPointer r1
    //     0x895a34: add             x1, x1, HEAP, lsl #32
    // 0x895a38: tbz             w1, #4, #0x895aec
    // 0x895a3c: ldur            x1, [fp, #-0x18]
    // 0x895a40: r0 = isRoot()
    //     0x895a40: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x895a44: tbz             w0, #4, #0x895ae4
    // 0x895a48: ldur            x1, [fp, #-0x18]
    // 0x895a4c: r0 = contributesToSemanticsTree()
    //     0x895a4c: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x895a50: tbz             w0, #4, #0x895a5c
    // 0x895a54: ldur            x0, [fp, #-0x18]
    // 0x895a58: b               #0x895a88
    // 0x895a5c: ldur            x0, [fp, #-0x18]
    // 0x895a60: LoadField: r1 = r0->field_33
    //     0x895a60: ldur            w1, [x0, #0x33]
    // 0x895a64: DecompressPointer r1
    //     0x895a64: add             x1, x1, HEAP, lsl #32
    // 0x895a68: cmp             w1, NULL
    // 0x895a6c: b.eq            #0x895b7c
    // 0x895a70: LoadField: r2 = r1->field_13
    //     0x895a70: ldur            w2, [x1, #0x13]
    // 0x895a74: DecompressPointer r2
    //     0x895a74: add             x2, x2, HEAP, lsl #32
    // 0x895a78: tbz             w2, #4, #0x895af0
    // 0x895a7c: LoadField: r1 = r0->field_b
    //     0x895a7c: ldur            w1, [x0, #0xb]
    // 0x895a80: DecompressPointer r1
    //     0x895a80: add             x1, x1, HEAP, lsl #32
    // 0x895a84: tbz             w1, #4, #0x895af0
    // 0x895a88: LoadField: r1 = r0->field_7
    //     0x895a88: ldur            w1, [x0, #7]
    // 0x895a8c: DecompressPointer r1
    //     0x895a8c: add             x1, x1, HEAP, lsl #32
    // 0x895a90: r0 = LoadClassIdInstr(r1)
    //     0x895a90: ldur            x0, [x1, #-1]
    //     0x895a94: ubfx            x0, x0, #0xc, #0x14
    // 0x895a98: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x895a98: mov             x17, #0xfc0
    //     0x895a9c: movk            x17, #1, lsl #16
    //     0x895aa0: add             lr, x0, x17
    //     0x895aa4: ldr             lr, [x21, lr, lsl #3]
    //     0x895aa8: blr             lr
    // 0x895aac: cmp             w0, NULL
    // 0x895ab0: b.ne            #0x895abc
    // 0x895ab4: r0 = Null
    //     0x895ab4: mov             x0, NULL
    // 0x895ab8: b               #0x895adc
    // 0x895abc: mov             x1, x0
    // 0x895ac0: LoadField: r0 = r1->field_43
    //     0x895ac0: ldur            w0, [x1, #0x43]
    // 0x895ac4: DecompressPointer r0
    //     0x895ac4: add             x0, x0, HEAP, lsl #32
    // 0x895ac8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x895acc: cmp             w0, w16
    // 0x895ad0: b.ne            #0x895adc
    // 0x895ad4: r2 = _semantics
    //     0x895ad4: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x895ad8: r0 = InitLateFinalInstanceField()
    //     0x895ad8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x895adc: ldur            x2, [fp, #-8]
    // 0x895ae0: b               #0x8959c4
    // 0x895ae4: ldur            x0, [fp, #-0x18]
    // 0x895ae8: b               #0x895af0
    // 0x895aec: ldur            x0, [fp, #-0x18]
    // 0x895af0: stur            x0, [fp, #-0x18]
    // 0x895af4: cmp             w0, NULL
    // 0x895af8: b.ne            #0x895b0c
    // 0x895afc: r0 = Null
    //     0x895afc: mov             x0, NULL
    // 0x895b00: LeaveFrame
    //     0x895b00: mov             SP, fp
    //     0x895b04: ldp             fp, lr, [SP], #0x10
    // 0x895b08: ret
    //     0x895b08: ret             
    // 0x895b0c: ldur            x3, [fp, #-8]
    // 0x895b10: LoadField: r1 = r3->field_47
    //     0x895b10: ldur            w1, [x3, #0x47]
    // 0x895b14: DecompressPointer r1
    //     0x895b14: add             x1, x1, HEAP, lsl #32
    // 0x895b18: cmp             w1, NULL
    // 0x895b1c: b.ne            #0x895b58
    // 0x895b20: mov             x1, x0
    // 0x895b24: ldur            x2, [fp, #-0x10]
    // 0x895b28: r0 = computeAncestorInfo()
    //     0x895b28: bl              #0x895878  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::computeAncestorInfo
    // 0x895b2c: ldur            x1, [fp, #-0x18]
    // 0x895b30: LoadField: r0 = r1->field_47
    //     0x895b30: ldur            w0, [x1, #0x47]
    // 0x895b34: DecompressPointer r0
    //     0x895b34: add             x0, x0, HEAP, lsl #32
    // 0x895b38: ldur            x1, [fp, #-8]
    // 0x895b3c: StoreField: r1->field_47 = r0
    //     0x895b3c: stur            w0, [x1, #0x47]
    //     0x895b40: ldurb           w16, [x1, #-1]
    //     0x895b44: ldurb           w17, [x0, #-1]
    //     0x895b48: and             x16, x17, x16, lsr #2
    //     0x895b4c: tst             x16, HEAP, lsr #32
    //     0x895b50: b.eq            #0x895b58
    //     0x895b54: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x895b58: r0 = Null
    //     0x895b58: mov             x0, NULL
    // 0x895b5c: LeaveFrame
    //     0x895b5c: mov             SP, fp
    //     0x895b60: ldp             fp, lr, [SP], #0x10
    // 0x895b64: ret
    //     0x895b64: ret             
    // 0x895b68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895b68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895b6c: b               #0x89589c
    // 0x895b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895b70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895b74: b               #0x8959d4
    // 0x895b78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x895b78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x895b7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x895b7c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ contributesToSemanticsTree(/* No info */) {
    // ** addr: 0x895b80, size: 0xb8
    // 0x895b80: EnterFrame
    //     0x895b80: stp             fp, lr, [SP, #-0x10]!
    //     0x895b84: mov             fp, SP
    // 0x895b88: AllocStack(0x10)
    //     0x895b88: sub             SP, SP, #0x10
    // 0x895b8c: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x10 */)
    //     0x895b8c: mov             x0, x1
    //     0x895b90: stur            x1, [fp, #-0x10]
    // 0x895b94: CheckStackOverflow
    //     0x895b94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895b98: cmp             SP, x16
    //     0x895b9c: b.ls            #0x895c30
    // 0x895ba0: LoadField: r2 = r0->field_3b
    //     0x895ba0: ldur            w2, [x0, #0x3b]
    // 0x895ba4: DecompressPointer r2
    //     0x895ba4: add             x2, x2, HEAP, lsl #32
    // 0x895ba8: stur            x2, [fp, #-8]
    // 0x895bac: LoadField: r1 = r2->field_13
    //     0x895bac: ldur            w1, [x2, #0x13]
    // 0x895bb0: DecompressPointer r1
    //     0x895bb0: add             x1, x1, HEAP, lsl #32
    // 0x895bb4: cmp             w1, NULL
    // 0x895bb8: b.ne            #0x895bc8
    // 0x895bbc: mov             x1, x2
    // 0x895bc0: r0 = original()
    //     0x895bc0: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895bc4: b               #0x895bcc
    // 0x895bc8: mov             x0, x1
    // 0x895bcc: LoadField: r1 = r0->field_1f
    //     0x895bcc: ldur            w1, [x0, #0x1f]
    // 0x895bd0: DecompressPointer r1
    //     0x895bd0: add             x1, x1, HEAP, lsl #32
    // 0x895bd4: tbz             w1, #4, #0x895c14
    // 0x895bd8: ldur            x0, [fp, #-0x10]
    // 0x895bdc: LoadField: r1 = r0->field_13
    //     0x895bdc: ldur            w1, [x0, #0x13]
    // 0x895be0: DecompressPointer r1
    //     0x895be0: add             x1, x1, HEAP, lsl #32
    // 0x895be4: tbz             w1, #4, #0x895c14
    // 0x895be8: ldur            x1, [fp, #-8]
    // 0x895bec: LoadField: r2 = r1->field_13
    //     0x895bec: ldur            w2, [x1, #0x13]
    // 0x895bf0: DecompressPointer r2
    //     0x895bf0: add             x2, x2, HEAP, lsl #32
    // 0x895bf4: cmp             w2, NULL
    // 0x895bf8: b.ne            #0x895c04
    // 0x895bfc: r0 = original()
    //     0x895bfc: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895c00: b               #0x895c08
    // 0x895c04: mov             x0, x2
    // 0x895c08: LoadField: r1 = r0->field_7
    //     0x895c08: ldur            w1, [x0, #7]
    // 0x895c0c: DecompressPointer r1
    //     0x895c0c: add             x1, x1, HEAP, lsl #32
    // 0x895c10: tbnz            w1, #4, #0x895c1c
    // 0x895c14: r0 = true
    //     0x895c14: add             x0, NULL, #0x20  ; true
    // 0x895c18: b               #0x895c24
    // 0x895c1c: ldur            x1, [fp, #-0x10]
    // 0x895c20: r0 = isRoot()
    //     0x895c20: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x895c24: LeaveFrame
    //     0x895c24: mov             SP, fp
    //     0x895c28: ldp             fp, lr, [SP], #0x10
    // 0x895c2c: ret
    //     0x895c2c: ret             
    // 0x895c30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895c30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895c34: b               #0x895ba0
  }
  get _ geometryDirty(/* No info */) {
    // ** addr: 0x895c38, size: 0x6c
    // 0x895c38: EnterFrame
    //     0x895c38: stp             fp, lr, [SP, #-0x10]!
    //     0x895c3c: mov             fp, SP
    // 0x895c40: AllocStack(0x8)
    //     0x895c40: sub             SP, SP, #8
    // 0x895c44: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x8 */)
    //     0x895c44: mov             x0, x1
    //     0x895c48: stur            x1, [fp, #-8]
    // 0x895c4c: CheckStackOverflow
    //     0x895c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895c50: cmp             SP, x16
    //     0x895c54: b.ls            #0x895c9c
    // 0x895c58: mov             x1, x0
    // 0x895c5c: r0 = isRoot()
    //     0x895c5c: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x895c60: tbnz            w0, #4, #0x895c74
    // 0x895c64: r0 = false
    //     0x895c64: add             x0, NULL, #0x30  ; false
    // 0x895c68: LeaveFrame
    //     0x895c68: mov             SP, fp
    //     0x895c6c: ldp             fp, lr, [SP], #0x10
    // 0x895c70: ret
    //     0x895c70: ret             
    // 0x895c74: ldur            x1, [fp, #-8]
    // 0x895c78: LoadField: r2 = r1->field_37
    //     0x895c78: ldur            w2, [x1, #0x37]
    // 0x895c7c: DecompressPointer r2
    //     0x895c7c: add             x2, x2, HEAP, lsl #32
    // 0x895c80: cmp             w2, NULL
    // 0x895c84: r16 = true
    //     0x895c84: add             x16, NULL, #0x20  ; true
    // 0x895c88: r17 = false
    //     0x895c88: add             x17, NULL, #0x30  ; false
    // 0x895c8c: csel            x0, x16, x17, eq
    // 0x895c90: LeaveFrame
    //     0x895c90: mov             SP, fp
    //     0x895c94: ldp             fp, lr, [SP], #0x10
    // 0x895c98: ret
    //     0x895c98: ret             
    // 0x895c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895c9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895ca0: b               #0x895c58
  }
  get _ shouldFormSemanticsNode(/* No info */) {
    // ** addr: 0x895ca4, size: 0xe4
    // 0x895ca4: EnterFrame
    //     0x895ca4: stp             fp, lr, [SP, #-0x10]!
    //     0x895ca8: mov             fp, SP
    // 0x895cac: AllocStack(0x8)
    //     0x895cac: sub             SP, SP, #8
    // 0x895cb0: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x8 */)
    //     0x895cb0: mov             x0, x1
    //     0x895cb4: stur            x1, [fp, #-8]
    // 0x895cb8: CheckStackOverflow
    //     0x895cb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895cbc: cmp             SP, x16
    //     0x895cc0: b.ls            #0x895d7c
    // 0x895cc4: LoadField: r1 = r0->field_3b
    //     0x895cc4: ldur            w1, [x0, #0x3b]
    // 0x895cc8: DecompressPointer r1
    //     0x895cc8: add             x1, x1, HEAP, lsl #32
    // 0x895ccc: LoadField: r2 = r1->field_13
    //     0x895ccc: ldur            w2, [x1, #0x13]
    // 0x895cd0: DecompressPointer r2
    //     0x895cd0: add             x2, x2, HEAP, lsl #32
    // 0x895cd4: cmp             w2, NULL
    // 0x895cd8: b.ne            #0x895ce4
    // 0x895cdc: r0 = original()
    //     0x895cdc: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895ce0: b               #0x895ce8
    // 0x895ce4: mov             x0, x2
    // 0x895ce8: LoadField: r1 = r0->field_7
    //     0x895ce8: ldur            w1, [x0, #7]
    // 0x895cec: DecompressPointer r1
    //     0x895cec: add             x1, x1, HEAP, lsl #32
    // 0x895cf0: tbnz            w1, #4, #0x895d04
    // 0x895cf4: r0 = true
    //     0x895cf4: add             x0, NULL, #0x20  ; true
    // 0x895cf8: LeaveFrame
    //     0x895cf8: mov             SP, fp
    //     0x895cfc: ldp             fp, lr, [SP], #0x10
    // 0x895d00: ret
    //     0x895d00: ret             
    // 0x895d04: ldur            x1, [fp, #-8]
    // 0x895d08: r0 = isRoot()
    //     0x895d08: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x895d0c: tbnz            w0, #4, #0x895d20
    // 0x895d10: r0 = true
    //     0x895d10: add             x0, NULL, #0x20  ; true
    // 0x895d14: LeaveFrame
    //     0x895d14: mov             SP, fp
    //     0x895d18: ldp             fp, lr, [SP], #0x10
    // 0x895d1c: ret
    //     0x895d1c: ret             
    // 0x895d20: ldur            x1, [fp, #-8]
    // 0x895d24: r0 = contributesToSemanticsTree()
    //     0x895d24: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x895d28: tbz             w0, #4, #0x895d3c
    // 0x895d2c: r0 = false
    //     0x895d2c: add             x0, NULL, #0x30  ; false
    // 0x895d30: LeaveFrame
    //     0x895d30: mov             SP, fp
    //     0x895d34: ldp             fp, lr, [SP], #0x10
    // 0x895d38: ret
    //     0x895d38: ret             
    // 0x895d3c: ldur            x1, [fp, #-8]
    // 0x895d40: LoadField: r2 = r1->field_33
    //     0x895d40: ldur            w2, [x1, #0x33]
    // 0x895d44: DecompressPointer r2
    //     0x895d44: add             x2, x2, HEAP, lsl #32
    // 0x895d48: cmp             w2, NULL
    // 0x895d4c: b.eq            #0x895d84
    // 0x895d50: LoadField: r3 = r2->field_13
    //     0x895d50: ldur            w3, [x2, #0x13]
    // 0x895d54: DecompressPointer r3
    //     0x895d54: add             x3, x3, HEAP, lsl #32
    // 0x895d58: tbnz            w3, #4, #0x895d64
    // 0x895d5c: r0 = true
    //     0x895d5c: add             x0, NULL, #0x20  ; true
    // 0x895d60: b               #0x895d70
    // 0x895d64: LoadField: r2 = r1->field_b
    //     0x895d64: ldur            w2, [x1, #0xb]
    // 0x895d68: DecompressPointer r2
    //     0x895d68: add             x2, x2, HEAP, lsl #32
    // 0x895d6c: mov             x0, x2
    // 0x895d70: LeaveFrame
    //     0x895d70: mov             SP, fp
    //     0x895d74: ldp             fp, lr, [SP], #0x10
    // 0x895d78: ret
    //     0x895d78: ret             
    // 0x895d7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x895d7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x895d80: b               #0x895cc4
    // 0x895d84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x895d84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateChildren(/* No info */) {
    // ** addr: 0x895d88, size: 0xae0
    // 0x895d88: EnterFrame
    //     0x895d88: stp             fp, lr, [SP, #-0x10]!
    //     0x895d8c: mov             fp, SP
    // 0x895d90: AllocStack(0x88)
    //     0x895d90: sub             SP, SP, #0x88
    // 0x895d94: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x10 */)
    //     0x895d94: mov             x0, x1
    //     0x895d98: stur            x1, [fp, #-0x10]
    // 0x895d9c: CheckStackOverflow
    //     0x895d9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x895da0: cmp             SP, x16
    //     0x895da4: b.ls            #0x896830
    // 0x895da8: LoadField: r2 = r0->field_3b
    //     0x895da8: ldur            w2, [x0, #0x3b]
    // 0x895dac: DecompressPointer r2
    //     0x895dac: add             x2, x2, HEAP, lsl #32
    // 0x895db0: mov             x1, x2
    // 0x895db4: stur            x2, [fp, #-8]
    // 0x895db8: r0 = reset()
    //     0x895db8: bl              #0x8982c8  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::reset
    // 0x895dbc: ldur            x1, [fp, #-0x10]
    // 0x895dc0: r0 = _getTagsForChildren()
    //     0x895dc0: bl              #0x8981a8  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_getTagsForChildren
    // 0x895dc4: ldur            x1, [fp, #-0x10]
    // 0x895dc8: stur            x0, [fp, #-0x18]
    // 0x895dcc: r0 = isRoot()
    //     0x895dcc: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x895dd0: tbz             w0, #4, #0x895e04
    // 0x895dd4: ldur            x0, [fp, #-8]
    // 0x895dd8: LoadField: r1 = r0->field_13
    //     0x895dd8: ldur            w1, [x0, #0x13]
    // 0x895ddc: DecompressPointer r1
    //     0x895ddc: add             x1, x1, HEAP, lsl #32
    // 0x895de0: cmp             w1, NULL
    // 0x895de4: b.ne            #0x895df4
    // 0x895de8: mov             x1, x0
    // 0x895dec: r0 = original()
    //     0x895dec: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895df0: b               #0x895df8
    // 0x895df4: mov             x0, x1
    // 0x895df8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x895df8: ldur            w1, [x0, #0x17]
    // 0x895dfc: DecompressPointer r1
    //     0x895dfc: add             x1, x1, HEAP, lsl #32
    // 0x895e00: tbnz            w1, #4, #0x895e10
    // 0x895e04: ldur            x0, [fp, #-0x10]
    // 0x895e08: r2 = true
    //     0x895e08: add             x2, NULL, #0x20  ; true
    // 0x895e0c: b               #0x895e60
    // 0x895e10: ldur            x1, [fp, #-0x10]
    // 0x895e14: r0 = contributesToSemanticsTree()
    //     0x895e14: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x895e18: tbz             w0, #4, #0x895e58
    // 0x895e1c: ldur            x0, [fp, #-0x10]
    // 0x895e20: LoadField: r1 = r0->field_33
    //     0x895e20: ldur            w1, [x0, #0x33]
    // 0x895e24: DecompressPointer r1
    //     0x895e24: add             x1, x1, HEAP, lsl #32
    // 0x895e28: cmp             w1, NULL
    // 0x895e2c: b.ne            #0x895e38
    // 0x895e30: r1 = Null
    //     0x895e30: mov             x1, NULL
    // 0x895e34: b               #0x895e44
    // 0x895e38: LoadField: r2 = r1->field_13
    //     0x895e38: ldur            w2, [x1, #0x13]
    // 0x895e3c: DecompressPointer r2
    //     0x895e3c: add             x2, x2, HEAP, lsl #32
    // 0x895e40: mov             x1, x2
    // 0x895e44: cmp             w1, NULL
    // 0x895e48: b.ne            #0x895e50
    // 0x895e4c: r1 = true
    //     0x895e4c: add             x1, NULL, #0x20  ; true
    // 0x895e50: mov             x2, x1
    // 0x895e54: b               #0x895e60
    // 0x895e58: ldur            x0, [fp, #-0x10]
    // 0x895e5c: r2 = false
    //     0x895e5c: add             x2, NULL, #0x30  ; false
    // 0x895e60: stur            x2, [fp, #-0x20]
    // 0x895e64: LoadField: r1 = r0->field_33
    //     0x895e64: ldur            w1, [x0, #0x33]
    // 0x895e68: DecompressPointer r1
    //     0x895e68: add             x1, x1, HEAP, lsl #32
    // 0x895e6c: cmp             w1, NULL
    // 0x895e70: b.ne            #0x895e7c
    // 0x895e74: r1 = Null
    //     0x895e74: mov             x1, NULL
    // 0x895e78: b               #0x895e88
    // 0x895e7c: LoadField: r3 = r1->field_b
    //     0x895e7c: ldur            w3, [x1, #0xb]
    // 0x895e80: DecompressPointer r3
    //     0x895e80: add             x3, x3, HEAP, lsl #32
    // 0x895e84: mov             x1, x3
    // 0x895e88: cmp             w1, NULL
    // 0x895e8c: b.eq            #0x895ea0
    // 0x895e90: tbnz            w1, #4, #0x895ea0
    // 0x895e94: mov             x1, x0
    // 0x895e98: r0 = true
    //     0x895e98: add             x0, NULL, #0x20  ; true
    // 0x895e9c: b               #0x895ed4
    // 0x895ea0: ldur            x3, [fp, #-8]
    // 0x895ea4: LoadField: r1 = r3->field_13
    //     0x895ea4: ldur            w1, [x3, #0x13]
    // 0x895ea8: DecompressPointer r1
    //     0x895ea8: add             x1, x1, HEAP, lsl #32
    // 0x895eac: cmp             w1, NULL
    // 0x895eb0: b.ne            #0x895ec0
    // 0x895eb4: mov             x1, x3
    // 0x895eb8: r0 = original()
    //     0x895eb8: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895ebc: b               #0x895ec4
    // 0x895ec0: mov             x0, x1
    // 0x895ec4: LoadField: r1 = r0->field_13
    //     0x895ec4: ldur            w1, [x0, #0x13]
    // 0x895ec8: DecompressPointer r1
    //     0x895ec8: add             x1, x1, HEAP, lsl #32
    // 0x895ecc: mov             x0, x1
    // 0x895ed0: ldur            x1, [fp, #-0x10]
    // 0x895ed4: stur            x0, [fp, #-0x28]
    // 0x895ed8: r1 = 4
    //     0x895ed8: mov             x1, #4
    // 0x895edc: r0 = AllocateContext()
    //     0x895edc: bl              #0x13de838  ; AllocateContextStub
    // 0x895ee0: mov             x2, x0
    // 0x895ee4: ldur            x0, [fp, #-0x28]
    // 0x895ee8: stur            x2, [fp, #-0x30]
    // 0x895eec: StoreField: r2->field_f = r0
    //     0x895eec: stur            w0, [x2, #0xf]
    // 0x895ef0: ldur            x3, [fp, #-0x10]
    // 0x895ef4: LoadField: r1 = r3->field_33
    //     0x895ef4: ldur            w1, [x3, #0x33]
    // 0x895ef8: DecompressPointer r1
    //     0x895ef8: add             x1, x1, HEAP, lsl #32
    // 0x895efc: cmp             w1, NULL
    // 0x895f00: b.eq            #0x895f24
    // 0x895f04: LoadField: r4 = r1->field_f
    //     0x895f04: ldur            w4, [x1, #0xf]
    // 0x895f08: DecompressPointer r4
    //     0x895f08: add             x4, x4, HEAP, lsl #32
    // 0x895f0c: r16 = Instance_AccessibilityFocusBlockType
    //     0x895f0c: ldr             x16, [PP, #0x2a80]  ; [pp+0x2a80] Obj!AccessibilityFocusBlockType@12c3f01
    // 0x895f10: cmp             w4, w16
    // 0x895f14: b.ne            #0x895f24
    // 0x895f18: r1 = Instance_AccessibilityFocusBlockType
    //     0x895f18: ldr             x1, [PP, #0x2a80]  ; [pp+0x2a80] Obj!AccessibilityFocusBlockType@12c3f01
    // 0x895f1c: StoreField: r2->field_13 = r1
    //     0x895f1c: stur            w1, [x2, #0x13]
    // 0x895f20: b               #0x895f6c
    // 0x895f24: ldur            x4, [fp, #-8]
    // 0x895f28: LoadField: r1 = r4->field_13
    //     0x895f28: ldur            w1, [x4, #0x13]
    // 0x895f2c: DecompressPointer r1
    //     0x895f2c: add             x1, x1, HEAP, lsl #32
    // 0x895f30: cmp             w1, NULL
    // 0x895f34: b.ne            #0x895f44
    // 0x895f38: mov             x1, x4
    // 0x895f3c: r0 = original()
    //     0x895f3c: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895f40: mov             x1, x0
    // 0x895f44: ldur            x2, [fp, #-0x30]
    // 0x895f48: r0 = accessibilityFocusBlockType()
    //     0x895f48: bl              #0x89819c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::accessibilityFocusBlockType
    // 0x895f4c: ldur            x2, [fp, #-0x30]
    // 0x895f50: StoreField: r2->field_13 = r0
    //     0x895f50: stur            w0, [x2, #0x13]
    //     0x895f54: ldurb           w16, [x2, #-1]
    //     0x895f58: ldurb           w17, [x0, #-1]
    //     0x895f5c: and             x16, x17, x16, lsr #2
    //     0x895f60: tst             x16, HEAP, lsr #32
    //     0x895f64: b.eq            #0x895f6c
    //     0x895f68: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x895f6c: ldur            x0, [fp, #-8]
    // 0x895f70: LoadField: r1 = r0->field_13
    //     0x895f70: ldur            w1, [x0, #0x13]
    // 0x895f74: DecompressPointer r1
    //     0x895f74: add             x1, x1, HEAP, lsl #32
    // 0x895f78: cmp             w1, NULL
    // 0x895f7c: b.ne            #0x895f8c
    // 0x895f80: mov             x1, x0
    // 0x895f84: r0 = original()
    //     0x895f84: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x895f88: mov             x1, x0
    // 0x895f8c: r0 = line()
    //     0x895f8c: bl              #0x13aeee0  ; [package:stack_trace/src/unparsed_frame.dart] UnparsedFrame::line
    // 0x895f90: cmp             w0, NULL
    // 0x895f94: b.ne            #0x895fc8
    // 0x895f98: ldur            x2, [fp, #-0x10]
    // 0x895f9c: LoadField: r0 = r2->field_33
    //     0x895f9c: ldur            w0, [x2, #0x33]
    // 0x895fa0: DecompressPointer r0
    //     0x895fa0: add             x0, x0, HEAP, lsl #32
    // 0x895fa4: cmp             w0, NULL
    // 0x895fa8: b.ne            #0x895fb4
    // 0x895fac: r0 = Null
    //     0x895fac: mov             x0, NULL
    // 0x895fb0: b               #0x895fc0
    // 0x895fb4: LoadField: r1 = r0->field_1b
    //     0x895fb4: ldur            w1, [x0, #0x1b]
    // 0x895fb8: DecompressPointer r1
    //     0x895fb8: add             x1, x1, HEAP, lsl #32
    // 0x895fbc: mov             x0, x1
    // 0x895fc0: mov             x4, x0
    // 0x895fc4: b               #0x895fd0
    // 0x895fc8: ldur            x2, [fp, #-0x10]
    // 0x895fcc: mov             x4, x0
    // 0x895fd0: ldur            x3, [fp, #-0x30]
    // 0x895fd4: mov             x0, x4
    // 0x895fd8: stur            x4, [fp, #-0x40]
    // 0x895fdc: ArrayStore: r3[0] = r0  ; List_4
    //     0x895fdc: stur            w0, [x3, #0x17]
    //     0x895fe0: ldurb           w16, [x3, #-1]
    //     0x895fe4: ldurb           w17, [x0, #-1]
    //     0x895fe8: and             x16, x17, x16, lsr #2
    //     0x895fec: tst             x16, HEAP, lsr #32
    //     0x895ff0: b.eq            #0x895ff8
    //     0x895ff4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x895ff8: LoadField: r0 = r2->field_2b
    //     0x895ff8: ldur            w0, [x2, #0x2b]
    // 0x895ffc: DecompressPointer r0
    //     0x895ffc: add             x0, x0, HEAP, lsl #32
    // 0x896000: mov             x1, x0
    // 0x896004: stur            x0, [fp, #-0x38]
    // 0x896008: r0 = clear()
    //     0x896008: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x89600c: ldur            x0, [fp, #-0x10]
    // 0x896010: LoadField: r2 = r0->field_23
    //     0x896010: ldur            w2, [x0, #0x23]
    // 0x896014: DecompressPointer r2
    //     0x896014: add             x2, x2, HEAP, lsl #32
    // 0x896018: mov             x1, x2
    // 0x89601c: stur            x2, [fp, #-0x48]
    // 0x896020: r0 = clear()
    //     0x896020: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x896024: ldur            x0, [fp, #-0x10]
    // 0x896028: LoadField: r1 = r0->field_33
    //     0x896028: ldur            w1, [x0, #0x33]
    // 0x89602c: DecompressPointer r1
    //     0x89602c: add             x1, x1, HEAP, lsl #32
    // 0x896030: cmp             w1, NULL
    // 0x896034: b.ne            #0x896040
    // 0x896038: r1 = Null
    //     0x896038: mov             x1, NULL
    // 0x89603c: b               #0x89604c
    // 0x896040: LoadField: r2 = r1->field_7
    //     0x896040: ldur            w2, [x1, #7]
    // 0x896044: DecompressPointer r2
    //     0x896044: add             x2, x2, HEAP, lsl #32
    // 0x896048: mov             x1, x2
    // 0x89604c: cmp             w1, NULL
    // 0x896050: b.eq            #0x896064
    // 0x896054: tbnz            w1, #4, #0x896064
    // 0x896058: mov             x1, x0
    // 0x89605c: r6 = true
    //     0x89605c: add             x6, NULL, #0x20  ; true
    // 0x896060: b               #0x896098
    // 0x896064: ldur            x2, [fp, #-8]
    // 0x896068: LoadField: r1 = r2->field_13
    //     0x896068: ldur            w1, [x2, #0x13]
    // 0x89606c: DecompressPointer r1
    //     0x89606c: add             x1, x1, HEAP, lsl #32
    // 0x896070: cmp             w1, NULL
    // 0x896074: b.ne            #0x896084
    // 0x896078: mov             x1, x2
    // 0x89607c: r0 = original()
    //     0x89607c: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x896080: b               #0x896088
    // 0x896084: mov             x0, x1
    // 0x896088: LoadField: r1 = r0->field_4f
    //     0x896088: ldur            w1, [x0, #0x4f]
    // 0x89608c: DecompressPointer r1
    //     0x89608c: add             x1, x1, HEAP, lsl #32
    // 0x896090: mov             x6, x1
    // 0x896094: ldur            x1, [fp, #-0x10]
    // 0x896098: ldur            x2, [fp, #-0x30]
    // 0x89609c: ldur            x5, [fp, #-0x18]
    // 0x8960a0: ldur            x4, [fp, #-0x20]
    // 0x8960a4: ldur            x3, [fp, #-0x28]
    // 0x8960a8: ldur            x0, [fp, #-0x40]
    // 0x8960ac: stur            x6, [fp, #-0x58]
    // 0x8960b0: LoadField: r7 = r2->field_13
    //     0x8960b0: ldur            w7, [x2, #0x13]
    // 0x8960b4: DecompressPointer r7
    //     0x8960b4: add             x7, x7, HEAP, lsl #32
    // 0x8960b8: stur            x7, [fp, #-0x50]
    // 0x8960bc: r0 = _SemanticsParentData()
    //     0x8960bc: bl              #0x898190  ; Allocate_SemanticsParentDataStub -> _SemanticsParentData (size=0x20)
    // 0x8960c0: mov             x1, x0
    // 0x8960c4: ldur            x0, [fp, #-0x58]
    // 0x8960c8: StoreField: r1->field_7 = r0
    //     0x8960c8: stur            w0, [x1, #7]
    // 0x8960cc: ldur            x0, [fp, #-0x28]
    // 0x8960d0: StoreField: r1->field_b = r0
    //     0x8960d0: stur            w0, [x1, #0xb]
    // 0x8960d4: ldur            x2, [fp, #-0x20]
    // 0x8960d8: StoreField: r1->field_13 = r2
    //     0x8960d8: stur            w2, [x1, #0x13]
    // 0x8960dc: ldur            x2, [fp, #-0x18]
    // 0x8960e0: ArrayStore: r1[0] = r2  ; List_4
    //     0x8960e0: stur            w2, [x1, #0x17]
    // 0x8960e4: ldur            x3, [fp, #-0x40]
    // 0x8960e8: StoreField: r1->field_1b = r3
    //     0x8960e8: stur            w3, [x1, #0x1b]
    // 0x8960ec: ldur            x2, [fp, #-0x50]
    // 0x8960f0: StoreField: r1->field_f = r2
    //     0x8960f0: stur            w2, [x1, #0xf]
    // 0x8960f4: mov             x2, x1
    // 0x8960f8: ldur            x1, [fp, #-0x10]
    // 0x8960fc: r0 = _collectChildMergeUpAndSiblingGroup()
    //     0x8960fc: bl              #0x89748c  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_collectChildMergeUpAndSiblingGroup
    // 0x896100: mov             x3, x0
    // 0x896104: stur            x3, [fp, #-0x20]
    // 0x896108: mov             x4, x1
    // 0x89610c: ldur            x1, [fp, #-0x48]
    // 0x896110: mov             x2, x3
    // 0x896114: stur            x4, [fp, #-0x18]
    // 0x896118: r0 = addAll()
    //     0x896118: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x89611c: ldur            x1, [fp, #-0x38]
    // 0x896120: ldur            x2, [fp, #-0x18]
    // 0x896124: r0 = addAll()
    //     0x896124: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x896128: ldur            x0, [fp, #-0x10]
    // 0x89612c: LoadField: r2 = r0->field_27
    //     0x89612c: ldur            w2, [x0, #0x27]
    // 0x896130: DecompressPointer r2
    //     0x896130: add             x2, x2, HEAP, lsl #32
    // 0x896134: mov             x1, x2
    // 0x896138: stur            x2, [fp, #-0x18]
    // 0x89613c: r0 = toSet()
    //     0x89613c: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0x896140: ldur            x1, [fp, #-0x18]
    // 0x896144: stur            x0, [fp, #-0x50]
    // 0x896148: r0 = clear()
    //     0x896148: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x89614c: ldur            x1, [fp, #-0x10]
    // 0x896150: r0 = contributesToSemanticsTree()
    //     0x896150: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x896154: tbz             w0, #4, #0x896168
    // 0x896158: r0 = Null
    //     0x896158: mov             x0, NULL
    // 0x89615c: LeaveFrame
    //     0x89615c: mov             SP, fp
    //     0x896160: ldp             fp, lr, [SP], #0x10
    // 0x896164: ret
    //     0x896164: ret             
    // 0x896168: ldur            x0, [fp, #-0x38]
    // 0x89616c: r16 = true
    //     0x89616c: add             x16, NULL, #0x20  ; true
    // 0x896170: str             x16, [SP]
    // 0x896174: ldur            x1, [fp, #-0x10]
    // 0x896178: ldur            x2, [fp, #-0x48]
    // 0x89617c: r4 = const [0, 0x3, 0x1, 0x2, isMergeUp, 0x2, null]
    //     0x89617c: ldr             x4, [PP, #0x2af0]  ; [pp+0x2af0] List(7) [0, 0x3, 0x1, 0x2, "isMergeUp", 0x2, Null]
    // 0x896180: r0 = _marksConflictsInMergeGroup()
    //     0x896180: bl              #0x896a00  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_marksConflictsInMergeGroup
    // 0x896184: ldur            x3, [fp, #-0x38]
    // 0x896188: LoadField: r4 = r3->field_b
    //     0x896188: ldur            w4, [x3, #0xb]
    // 0x89618c: stur            x4, [fp, #-0x58]
    // 0x896190: r0 = LoadInt32Instr(r4)
    //     0x896190: sbfx            x0, x4, #1, #0x1f
    // 0x896194: r5 = 0
    //     0x896194: mov             x5, #0
    // 0x896198: stur            x5, [fp, #-0x60]
    // 0x89619c: CheckStackOverflow
    //     0x89619c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8961a0: cmp             SP, x16
    //     0x8961a4: b.ls            #0x896838
    // 0x8961a8: cmp             x5, x0
    // 0x8961ac: b.ge            #0x896210
    // 0x8961b0: mov             x1, x5
    // 0x8961b4: cmp             x1, x0
    // 0x8961b8: b.hs            #0x896840
    // 0x8961bc: LoadField: r0 = r3->field_f
    //     0x8961bc: ldur            w0, [x3, #0xf]
    // 0x8961c0: DecompressPointer r0
    //     0x8961c0: add             x0, x0, HEAP, lsl #32
    // 0x8961c4: ArrayLoad: r2 = r0[r5]  ; Unknown_4
    //     0x8961c4: add             x16, x0, x5, lsl #2
    //     0x8961c8: ldur            w2, [x16, #0xf]
    // 0x8961cc: DecompressPointer r2
    //     0x8961cc: add             x2, x2, HEAP, lsl #32
    // 0x8961d0: r16 = false
    //     0x8961d0: add             x16, NULL, #0x30  ; false
    // 0x8961d4: str             x16, [SP]
    // 0x8961d8: ldur            x1, [fp, #-0x10]
    // 0x8961dc: r4 = const [0, 0x3, 0x1, 0x2, isMergeUp, 0x2, null]
    //     0x8961dc: ldr             x4, [PP, #0x2af0]  ; [pp+0x2af0] List(7) [0, 0x3, 0x1, 0x2, "isMergeUp", 0x2, Null]
    // 0x8961e0: r0 = _marksConflictsInMergeGroup()
    //     0x8961e0: bl              #0x896a00  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_marksConflictsInMergeGroup
    // 0x8961e4: ldur            x3, [fp, #-0x38]
    // 0x8961e8: LoadField: r0 = r3->field_b
    //     0x8961e8: ldur            w0, [x3, #0xb]
    // 0x8961ec: ldur            x1, [fp, #-0x58]
    // 0x8961f0: cmp             w0, w1
    // 0x8961f4: b.ne            #0x896810
    // 0x8961f8: ldur            x2, [fp, #-0x60]
    // 0x8961fc: add             x5, x2, #1
    // 0x896200: r2 = LoadInt32Instr(r0)
    //     0x896200: sbfx            x2, x0, #1, #0x1f
    // 0x896204: mov             x0, x2
    // 0x896208: mov             x4, x1
    // 0x89620c: b               #0x896198
    // 0x896210: ldur            x0, [fp, #-0x48]
    // 0x896214: r1 = Function '<anonymous closure>':.
    //     0x896214: ldr             x1, [PP, #0x2af8]  ; [pp+0x2af8] AnonymousClosure: (0x8985d0), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::updateChildren (0x895d88)
    // 0x896218: r2 = Null
    //     0x896218: mov             x2, NULL
    // 0x89621c: r0 = AllocateClosure()
    //     0x89621c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x896220: r16 = <SemanticsConfiguration?>
    //     0x896220: ldr             x16, [PP, #0x2b00]  ; [pp+0x2b00] TypeArguments: <SemanticsConfiguration?>
    // 0x896224: ldur            lr, [fp, #-0x48]
    // 0x896228: stp             lr, x16, [SP, #8]
    // 0x89622c: str             x0, [SP]
    // 0x896230: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x896230: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x896234: r0 = map()
    //     0x896234: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x896238: r16 = <SemanticsConfiguration>
    //     0x896238: ldr             x16, [PP, #0x2b08]  ; [pp+0x2b08] TypeArguments: <SemanticsConfiguration>
    // 0x89623c: stp             x0, x16, [SP]
    // 0x896240: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x896240: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x896244: r0 = whereType()
    //     0x896244: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x896248: ldur            x1, [fp, #-8]
    // 0x89624c: mov             x2, x0
    // 0x896250: r0 = absorbAll()
    //     0x896250: bl              #0x89693c  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::absorbAll
    // 0x896254: ldur            x1, [fp, #-0x48]
    // 0x896258: r0 = clear()
    //     0x896258: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x89625c: ldur            x0, [fp, #-0x48]
    // 0x896260: LoadField: r1 = r0->field_b
    //     0x896260: ldur            w1, [x0, #0xb]
    // 0x896264: LoadField: r2 = r0->field_f
    //     0x896264: ldur            w2, [x0, #0xf]
    // 0x896268: DecompressPointer r2
    //     0x896268: add             x2, x2, HEAP, lsl #32
    // 0x89626c: LoadField: r3 = r2->field_b
    //     0x89626c: ldur            w3, [x2, #0xb]
    // 0x896270: r2 = LoadInt32Instr(r1)
    //     0x896270: sbfx            x2, x1, #1, #0x1f
    // 0x896274: stur            x2, [fp, #-0x60]
    // 0x896278: r1 = LoadInt32Instr(r3)
    //     0x896278: sbfx            x1, x3, #1, #0x1f
    // 0x89627c: cmp             x2, x1
    // 0x896280: b.ne            #0x89628c
    // 0x896284: mov             x1, x0
    // 0x896288: r0 = _growToNextCapacity()
    //     0x896288: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89628c: ldur            x3, [fp, #-0x10]
    // 0x896290: ldur            x0, [fp, #-0x48]
    // 0x896294: ldur            x4, [fp, #-0x20]
    // 0x896298: ldur            x2, [fp, #-0x60]
    // 0x89629c: add             x1, x2, #1
    // 0x8962a0: lsl             x5, x1, #1
    // 0x8962a4: StoreField: r0->field_b = r5
    //     0x8962a4: stur            w5, [x0, #0xb]
    // 0x8962a8: LoadField: r1 = r0->field_f
    //     0x8962a8: ldur            w1, [x0, #0xf]
    // 0x8962ac: DecompressPointer r1
    //     0x8962ac: add             x1, x1, HEAP, lsl #32
    // 0x8962b0: mov             x0, x3
    // 0x8962b4: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8962b4: add             x25, x1, x2, lsl #2
    //     0x8962b8: add             x25, x25, #0xf
    //     0x8962bc: str             w0, [x25]
    //     0x8962c0: tbz             w0, #0, #0x8962dc
    //     0x8962c4: ldurb           w16, [x1, #-1]
    //     0x8962c8: ldurb           w17, [x0, #-1]
    //     0x8962cc: and             x16, x17, x16, lsr #2
    //     0x8962d0: tst             x16, HEAP, lsr #32
    //     0x8962d4: b.eq            #0x8962dc
    //     0x8962d8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8962dc: r0 = LoadClassIdInstr(r4)
    //     0x8962dc: ldur            x0, [x4, #-1]
    //     0x8962e0: ubfx            x0, x0, #0xc, #0x14
    // 0x8962e4: r16 = <_RenderObjectSemantics>
    //     0x8962e4: ldr             x16, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x8962e8: stp             x4, x16, [SP]
    // 0x8962ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x8962ec: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x8962f0: r0 = GDT[cid_x0 + 0x10d40]()
    //     0x8962f0: mov             x17, #0xd40
    //     0x8962f4: movk            x17, #1, lsl #16
    //     0x8962f8: add             lr, x0, x17
    //     0x8962fc: ldr             lr, [x21, lr, lsl #3]
    //     0x896300: blr             lr
    // 0x896304: r1 = LoadClassIdInstr(r0)
    //     0x896304: ldur            x1, [x0, #-1]
    //     0x896308: ubfx            x1, x1, #0xc, #0x14
    // 0x89630c: mov             x16, x0
    // 0x896310: mov             x0, x1
    // 0x896314: mov             x1, x16
    // 0x896318: r0 = GDT[cid_x0 + 0x12641]()
    //     0x896318: mov             x17, #0x2641
    //     0x89631c: movk            x17, #1, lsl #16
    //     0x896320: add             lr, x0, x17
    //     0x896324: ldr             lr, [x21, lr, lsl #3]
    //     0x896328: blr             lr
    // 0x89632c: mov             x3, x0
    // 0x896330: ldur            x2, [fp, #-0x10]
    // 0x896334: stur            x3, [fp, #-0x48]
    // 0x896338: LoadField: r4 = r2->field_7
    //     0x896338: ldur            w4, [x2, #7]
    // 0x89633c: DecompressPointer r4
    //     0x89633c: add             x4, x4, HEAP, lsl #32
    // 0x896340: stur            x4, [fp, #-0x20]
    // 0x896344: ldur            x5, [fp, #-0x18]
    // 0x896348: CheckStackOverflow
    //     0x896348: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89634c: cmp             SP, x16
    //     0x896350: b.ls            #0x896844
    // 0x896354: r0 = LoadClassIdInstr(r3)
    //     0x896354: ldur            x0, [x3, #-1]
    //     0x896358: ubfx            x0, x0, #0xc, #0x14
    // 0x89635c: mov             x1, x3
    // 0x896360: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x896360: mov             x17, #0x845b
    //     0x896364: movk            x17, #1, lsl #16
    //     0x896368: add             lr, x0, x17
    //     0x89636c: ldr             lr, [x21, lr, lsl #3]
    //     0x896370: blr             lr
    // 0x896374: tbnz            w0, #4, #0x896538
    // 0x896378: ldur            x2, [fp, #-0x48]
    // 0x89637c: r0 = LoadClassIdInstr(r2)
    //     0x89637c: ldur            x0, [x2, #-1]
    //     0x896380: ubfx            x0, x0, #0xc, #0x14
    // 0x896384: mov             x1, x2
    // 0x896388: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x896388: mov             x17, #0x7d4c
    //     0x89638c: movk            x17, #1, lsl #16
    //     0x896390: add             lr, x0, x17
    //     0x896394: ldr             lr, [x21, lr, lsl #3]
    //     0x896398: blr             lr
    // 0x89639c: mov             x1, x0
    // 0x8963a0: stur            x0, [fp, #-0x58]
    // 0x8963a4: r0 = shouldFormSemanticsNode()
    //     0x8963a4: bl              #0x895ca4  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::shouldFormSemanticsNode
    // 0x8963a8: tbnz            w0, #4, #0x8964fc
    // 0x8963ac: ldur            x2, [fp, #-0x58]
    // 0x8963b0: LoadField: r0 = r2->field_27
    //     0x8963b0: ldur            w0, [x2, #0x27]
    // 0x8963b4: DecompressPointer r0
    //     0x8963b4: add             x0, x0, HEAP, lsl #32
    // 0x8963b8: LoadField: r1 = r0->field_b
    //     0x8963b8: ldur            w1, [x0, #0xb]
    // 0x8963bc: r3 = LoadInt32Instr(r1)
    //     0x8963bc: sbfx            x3, x1, #1, #0x1f
    // 0x8963c0: LoadField: r1 = r0->field_f
    //     0x8963c0: ldur            w1, [x0, #0xf]
    // 0x8963c4: DecompressPointer r1
    //     0x8963c4: add             x1, x1, HEAP, lsl #32
    // 0x8963c8: r0 = 0
    //     0x8963c8: mov             x0, #0
    // 0x8963cc: CheckStackOverflow
    //     0x8963cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8963d0: cmp             SP, x16
    //     0x8963d4: b.ls            #0x89684c
    // 0x8963d8: cmp             x0, x3
    // 0x8963dc: b.ge            #0x896418
    // 0x8963e0: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0x8963e0: add             x16, x1, x0, lsl #2
    //     0x8963e4: ldur            w4, [x16, #0xf]
    // 0x8963e8: DecompressPointer r4
    //     0x8963e8: add             x4, x4, HEAP, lsl #32
    // 0x8963ec: add             x5, x0, #1
    // 0x8963f0: mov             x0, x2
    // 0x8963f4: StoreField: r4->field_3f = r0
    //     0x8963f4: stur            w0, [x4, #0x3f]
    //     0x8963f8: ldurb           w16, [x4, #-1]
    //     0x8963fc: ldurb           w17, [x0, #-1]
    //     0x896400: and             x16, x17, x16, lsr #2
    //     0x896404: tst             x16, HEAP, lsr #32
    //     0x896408: b.eq            #0x896410
    //     0x89640c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x896410: mov             x0, x5
    // 0x896414: b               #0x8963cc
    // 0x896418: mov             x1, x2
    // 0x89641c: r0 = isRoot()
    //     0x89641c: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x896420: tbz             w0, #4, #0x896480
    // 0x896424: ldur            x0, [fp, #-0x58]
    // 0x896428: LoadField: r1 = r0->field_37
    //     0x896428: ldur            w1, [x0, #0x37]
    // 0x89642c: DecompressPointer r1
    //     0x89642c: add             x1, x1, HEAP, lsl #32
    // 0x896430: cmp             w1, NULL
    // 0x896434: b.ne            #0x896480
    // 0x896438: ldur            x3, [fp, #-0x20]
    // 0x89643c: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x89643c: ldur            w1, [x3, #0x17]
    // 0x896440: DecompressPointer r1
    //     0x896440: add             x1, x1, HEAP, lsl #32
    // 0x896444: cmp             w1, NULL
    // 0x896448: b.eq            #0x896854
    // 0x89644c: LoadField: r4 = r1->field_3b
    //     0x89644c: ldur            w4, [x1, #0x3b]
    // 0x896450: DecompressPointer r4
    //     0x896450: add             x4, x4, HEAP, lsl #32
    // 0x896454: stur            x4, [fp, #-0x70]
    // 0x896458: LoadField: r5 = r0->field_7
    //     0x896458: ldur            w5, [x0, #7]
    // 0x89645c: DecompressPointer r5
    //     0x89645c: add             x5, x5, HEAP, lsl #32
    // 0x896460: mov             x1, x4
    // 0x896464: mov             x2, x5
    // 0x896468: stur            x5, [fp, #-0x68]
    // 0x89646c: r0 = _hashCode()
    //     0x89646c: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x896470: ldur            x1, [fp, #-0x70]
    // 0x896474: ldur            x2, [fp, #-0x68]
    // 0x896478: mov             x3, x0
    // 0x89647c: r0 = _add()
    //     0x89647c: bl              #0x84ba3c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x896480: ldur            x0, [fp, #-0x18]
    // 0x896484: LoadField: r1 = r0->field_b
    //     0x896484: ldur            w1, [x0, #0xb]
    // 0x896488: LoadField: r2 = r0->field_f
    //     0x896488: ldur            w2, [x0, #0xf]
    // 0x89648c: DecompressPointer r2
    //     0x89648c: add             x2, x2, HEAP, lsl #32
    // 0x896490: LoadField: r3 = r2->field_b
    //     0x896490: ldur            w3, [x2, #0xb]
    // 0x896494: r2 = LoadInt32Instr(r1)
    //     0x896494: sbfx            x2, x1, #1, #0x1f
    // 0x896498: stur            x2, [fp, #-0x60]
    // 0x89649c: r1 = LoadInt32Instr(r3)
    //     0x89649c: sbfx            x1, x3, #1, #0x1f
    // 0x8964a0: cmp             x2, x1
    // 0x8964a4: b.ne            #0x8964b0
    // 0x8964a8: mov             x1, x0
    // 0x8964ac: r0 = _growToNextCapacity()
    //     0x8964ac: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8964b0: ldur            x3, [fp, #-0x18]
    // 0x8964b4: ldur            x2, [fp, #-0x60]
    // 0x8964b8: add             x0, x2, #1
    // 0x8964bc: lsl             x1, x0, #1
    // 0x8964c0: StoreField: r3->field_b = r1
    //     0x8964c0: stur            w1, [x3, #0xb]
    // 0x8964c4: LoadField: r1 = r3->field_f
    //     0x8964c4: ldur            w1, [x3, #0xf]
    // 0x8964c8: DecompressPointer r1
    //     0x8964c8: add             x1, x1, HEAP, lsl #32
    // 0x8964cc: ldur            x0, [fp, #-0x58]
    // 0x8964d0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x8964d0: add             x25, x1, x2, lsl #2
    //     0x8964d4: add             x25, x25, #0xf
    //     0x8964d8: str             w0, [x25]
    //     0x8964dc: tbz             w0, #0, #0x8964f8
    //     0x8964e0: ldurb           w16, [x1, #-1]
    //     0x8964e4: ldurb           w17, [x0, #-1]
    //     0x8964e8: and             x16, x17, x16, lsr #2
    //     0x8964ec: tst             x16, HEAP, lsr #32
    //     0x8964f0: b.eq            #0x8964f8
    //     0x8964f4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8964f8: b               #0x896528
    // 0x8964fc: ldur            x3, [fp, #-0x18]
    // 0x896500: ldur            x0, [fp, #-0x58]
    // 0x896504: LoadField: r2 = r0->field_27
    //     0x896504: ldur            w2, [x0, #0x27]
    // 0x896508: DecompressPointer r2
    //     0x896508: add             x2, x2, HEAP, lsl #32
    // 0x89650c: mov             x1, x3
    // 0x896510: r0 = addAll()
    //     0x896510: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x896514: ldur            x0, [fp, #-0x58]
    // 0x896518: LoadField: r2 = r0->field_2b
    //     0x896518: ldur            w2, [x0, #0x2b]
    // 0x89651c: DecompressPointer r2
    //     0x89651c: add             x2, x2, HEAP, lsl #32
    // 0x896520: ldur            x1, [fp, #-0x38]
    // 0x896524: r0 = addAll()
    //     0x896524: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x896528: ldur            x2, [fp, #-0x10]
    // 0x89652c: ldur            x3, [fp, #-0x48]
    // 0x896530: ldur            x4, [fp, #-0x20]
    // 0x896534: b               #0x896344
    // 0x896538: ldur            x1, [fp, #-0x10]
    // 0x89653c: r0 = isRoot()
    //     0x89653c: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x896540: tbz             w0, #4, #0x896574
    // 0x896544: ldur            x0, [fp, #-8]
    // 0x896548: LoadField: r1 = r0->field_13
    //     0x896548: ldur            w1, [x0, #0x13]
    // 0x89654c: DecompressPointer r1
    //     0x89654c: add             x1, x1, HEAP, lsl #32
    // 0x896550: cmp             w1, NULL
    // 0x896554: b.ne            #0x896564
    // 0x896558: mov             x1, x0
    // 0x89655c: r0 = original()
    //     0x89655c: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x896560: b               #0x896568
    // 0x896564: mov             x0, x1
    // 0x896568: LoadField: r1 = r0->field_7
    //     0x896568: ldur            w1, [x0, #7]
    // 0x89656c: DecompressPointer r1
    //     0x89656c: add             x1, x1, HEAP, lsl #32
    // 0x896570: tbnz            w1, #4, #0x8965d8
    // 0x896574: ldur            x2, [fp, #-0x18]
    // 0x896578: LoadField: r0 = r2->field_b
    //     0x896578: ldur            w0, [x2, #0xb]
    // 0x89657c: r1 = LoadInt32Instr(r0)
    //     0x89657c: sbfx            x1, x0, #1, #0x1f
    // 0x896580: LoadField: r3 = r2->field_f
    //     0x896580: ldur            w3, [x2, #0xf]
    // 0x896584: DecompressPointer r3
    //     0x896584: add             x3, x3, HEAP, lsl #32
    // 0x896588: r0 = 0
    //     0x896588: mov             x0, #0
    // 0x89658c: CheckStackOverflow
    //     0x89658c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896590: cmp             SP, x16
    //     0x896594: b.ls            #0x896858
    // 0x896598: cmp             x0, x1
    // 0x89659c: b.ge            #0x8965dc
    // 0x8965a0: ArrayLoad: r4 = r3[r0]  ; Unknown_4
    //     0x8965a0: add             x16, x3, x0, lsl #2
    //     0x8965a4: ldur            w4, [x16, #0xf]
    // 0x8965a8: DecompressPointer r4
    //     0x8965a8: add             x4, x4, HEAP, lsl #32
    // 0x8965ac: add             x5, x0, #1
    // 0x8965b0: ldur            x0, [fp, #-0x10]
    // 0x8965b4: StoreField: r4->field_3f = r0
    //     0x8965b4: stur            w0, [x4, #0x3f]
    //     0x8965b8: ldurb           w16, [x4, #-1]
    //     0x8965bc: ldurb           w17, [x0, #-1]
    //     0x8965c0: and             x16, x17, x16, lsr #2
    //     0x8965c4: tst             x16, HEAP, lsr #32
    //     0x8965c8: b.eq            #0x8965d0
    //     0x8965cc: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x8965d0: mov             x0, x5
    // 0x8965d4: b               #0x89658c
    // 0x8965d8: ldur            x2, [fp, #-0x18]
    // 0x8965dc: ldur            x1, [fp, #-0x50]
    // 0x8965e0: r0 = removeAll()
    //     0x8965e0: bl              #0x896868  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::removeAll
    // 0x8965e4: ldur            x1, [fp, #-0x50]
    // 0x8965e8: r0 = iterator()
    //     0x8965e8: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x8965ec: stur            x0, [fp, #-0x20]
    // 0x8965f0: LoadField: r2 = r0->field_7
    //     0x8965f0: ldur            w2, [x0, #7]
    // 0x8965f4: DecompressPointer r2
    //     0x8965f4: add             x2, x2, HEAP, lsl #32
    // 0x8965f8: stur            x2, [fp, #-0x18]
    // 0x8965fc: ldur            x3, [fp, #-0x10]
    // 0x896600: CheckStackOverflow
    //     0x896600: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896604: cmp             SP, x16
    //     0x896608: b.ls            #0x896860
    // 0x89660c: mov             x1, x0
    // 0x896610: r0 = moveNext()
    //     0x896610: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x896614: tbnz            w0, #4, #0x896688
    // 0x896618: ldur            x3, [fp, #-0x20]
    // 0x89661c: LoadField: r4 = r3->field_33
    //     0x89661c: ldur            w4, [x3, #0x33]
    // 0x896620: DecompressPointer r4
    //     0x896620: add             x4, x4, HEAP, lsl #32
    // 0x896624: stur            x4, [fp, #-0x48]
    // 0x896628: cmp             w4, NULL
    // 0x89662c: b.ne            #0x89665c
    // 0x896630: mov             x0, x4
    // 0x896634: ldur            x2, [fp, #-0x18]
    // 0x896638: r1 = Null
    //     0x896638: mov             x1, NULL
    // 0x89663c: cmp             w2, NULL
    // 0x896640: b.eq            #0x89665c
    // 0x896644: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x896644: ldur            w4, [x2, #0x17]
    // 0x896648: DecompressPointer r4
    //     0x896648: add             x4, x4, HEAP, lsl #32
    // 0x89664c: r8 = X0
    //     0x89664c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x896650: LoadField: r9 = r4->field_7
    //     0x896650: ldur            x9, [x4, #7]
    // 0x896654: r3 = Null
    //     0x896654: ldr             x3, [PP, #0x2b10]  ; [pp+0x2b10] Null
    // 0x896658: blr             x9
    // 0x89665c: ldur            x1, [fp, #-0x10]
    // 0x896660: ldur            x0, [fp, #-0x48]
    // 0x896664: LoadField: r2 = r0->field_3f
    //     0x896664: ldur            w2, [x0, #0x3f]
    // 0x896668: DecompressPointer r2
    //     0x896668: add             x2, x2, HEAP, lsl #32
    // 0x89666c: cmp             w2, w1
    // 0x896670: b.ne            #0x896678
    // 0x896674: StoreField: r0->field_3f = rNULL
    //     0x896674: stur            NULL, [x0, #0x3f]
    // 0x896678: mov             x3, x1
    // 0x89667c: ldur            x0, [fp, #-0x20]
    // 0x896680: ldur            x2, [fp, #-0x18]
    // 0x896684: b               #0x896600
    // 0x896688: ldur            x1, [fp, #-0x10]
    // 0x89668c: LoadField: r0 = r1->field_33
    //     0x89668c: ldur            w0, [x1, #0x33]
    // 0x896690: DecompressPointer r0
    //     0x896690: add             x0, x0, HEAP, lsl #32
    // 0x896694: cmp             w0, NULL
    // 0x896698: b.ne            #0x8966a4
    // 0x89669c: r1 = Null
    //     0x89669c: mov             x1, NULL
    // 0x8966a0: b               #0x8966ac
    // 0x8966a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8966a4: ldur            w1, [x0, #0x17]
    // 0x8966a8: DecompressPointer r1
    //     0x8966a8: add             x1, x1, HEAP, lsl #32
    // 0x8966ac: ldur            x3, [fp, #-0x30]
    // 0x8966b0: mov             x0, x1
    // 0x8966b4: StoreField: r3->field_1b = r0
    //     0x8966b4: stur            w0, [x3, #0x1b]
    //     0x8966b8: ldurb           w16, [x3, #-1]
    //     0x8966bc: ldurb           w17, [x0, #-1]
    //     0x8966c0: and             x16, x17, x16, lsr #2
    //     0x8966c4: tst             x16, HEAP, lsr #32
    //     0x8966c8: b.eq            #0x8966d0
    //     0x8966cc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x8966d0: cmp             w1, NULL
    // 0x8966d4: b.eq            #0x8966f0
    // 0x8966d8: mov             x2, x3
    // 0x8966dc: r1 = Function '<anonymous closure>':.
    //     0x8966dc: ldr             x1, [PP, #0x2b20]  ; [pp+0x2b20] AnonymousClosure: (0x898494), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::updateChildren (0x895d88)
    // 0x8966e0: r0 = AllocateClosure()
    //     0x8966e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8966e4: ldur            x1, [fp, #-8]
    // 0x8966e8: mov             x2, x0
    // 0x8966ec: r0 = updateConfig()
    //     0x8966ec: bl              #0x88fa6c  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::updateConfig
    // 0x8966f0: ldur            x2, [fp, #-0x30]
    // 0x8966f4: ldur            x0, [fp, #-8]
    // 0x8966f8: LoadField: r3 = r2->field_13
    //     0x8966f8: ldur            w3, [x2, #0x13]
    // 0x8966fc: DecompressPointer r3
    //     0x8966fc: add             x3, x3, HEAP, lsl #32
    // 0x896700: stur            x3, [fp, #-0x10]
    // 0x896704: LoadField: r1 = r0->field_13
    //     0x896704: ldur            w1, [x0, #0x13]
    // 0x896708: DecompressPointer r1
    //     0x896708: add             x1, x1, HEAP, lsl #32
    // 0x89670c: cmp             w1, NULL
    // 0x896710: b.ne            #0x896720
    // 0x896714: mov             x1, x0
    // 0x896718: r0 = original()
    //     0x896718: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x89671c: mov             x1, x0
    // 0x896720: ldur            x0, [fp, #-0x10]
    // 0x896724: r0 = accessibilityFocusBlockType()
    //     0x896724: bl              #0x89819c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::accessibilityFocusBlockType
    // 0x896728: mov             x1, x0
    // 0x89672c: ldur            x0, [fp, #-0x10]
    // 0x896730: cmp             w0, w1
    // 0x896734: b.eq            #0x896750
    // 0x896738: ldur            x2, [fp, #-0x30]
    // 0x89673c: r1 = Function '<anonymous closure>':.
    //     0x89673c: ldr             x1, [PP, #0x2b28]  ; [pp+0x2b28] AnonymousClosure: (0x898398), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::updateChildren (0x895d88)
    // 0x896740: r0 = AllocateClosure()
    //     0x896740: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x896744: ldur            x1, [fp, #-8]
    // 0x896748: mov             x2, x0
    // 0x89674c: r0 = updateConfig()
    //     0x89674c: bl              #0x88fa6c  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::updateConfig
    // 0x896750: ldur            x0, [fp, #-8]
    // 0x896754: LoadField: r1 = r0->field_13
    //     0x896754: ldur            w1, [x0, #0x13]
    // 0x896758: DecompressPointer r1
    //     0x896758: add             x1, x1, HEAP, lsl #32
    // 0x89675c: cmp             w1, NULL
    // 0x896760: b.ne            #0x896770
    // 0x896764: mov             x1, x0
    // 0x896768: r0 = original()
    //     0x896768: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x89676c: mov             x1, x0
    // 0x896770: ldur            x0, [fp, #-0x28]
    // 0x896774: LoadField: r2 = r1->field_13
    //     0x896774: ldur            w2, [x1, #0x13]
    // 0x896778: DecompressPointer r2
    //     0x896778: add             x2, x2, HEAP, lsl #32
    // 0x89677c: cmp             w0, w2
    // 0x896780: b.eq            #0x89679c
    // 0x896784: ldur            x2, [fp, #-0x30]
    // 0x896788: r1 = Function '<anonymous closure>':.
    //     0x896788: ldr             x1, [PP, #0x2b30]  ; [pp+0x2b30] AnonymousClosure: (0x898374), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::updateChildren (0x895d88)
    // 0x89678c: r0 = AllocateClosure()
    //     0x89678c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x896790: ldur            x1, [fp, #-8]
    // 0x896794: mov             x2, x0
    // 0x896798: r0 = updateConfig()
    //     0x896798: bl              #0x88fa6c  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::updateConfig
    // 0x89679c: ldur            x0, [fp, #-8]
    // 0x8967a0: LoadField: r1 = r0->field_13
    //     0x8967a0: ldur            w1, [x0, #0x13]
    // 0x8967a4: DecompressPointer r1
    //     0x8967a4: add             x1, x1, HEAP, lsl #32
    // 0x8967a8: cmp             w1, NULL
    // 0x8967ac: b.ne            #0x8967bc
    // 0x8967b0: mov             x1, x0
    // 0x8967b4: r0 = original()
    //     0x8967b4: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x8967b8: mov             x1, x0
    // 0x8967bc: ldur            x0, [fp, #-0x40]
    // 0x8967c0: LoadField: r2 = r1->field_f
    //     0x8967c0: ldur            w2, [x1, #0xf]
    // 0x8967c4: DecompressPointer r2
    //     0x8967c4: add             x2, x2, HEAP, lsl #32
    // 0x8967c8: r1 = LoadClassIdInstr(r0)
    //     0x8967c8: ldur            x1, [x0, #-1]
    //     0x8967cc: ubfx            x1, x1, #0xc, #0x14
    // 0x8967d0: stp             x2, x0, [SP]
    // 0x8967d4: mov             x0, x1
    // 0x8967d8: mov             lr, x0
    // 0x8967dc: ldr             lr, [x21, lr, lsl #3]
    // 0x8967e0: blr             lr
    // 0x8967e4: tbz             w0, #4, #0x896800
    // 0x8967e8: ldur            x2, [fp, #-0x30]
    // 0x8967ec: r1 = Function '<anonymous closure>':.
    //     0x8967ec: ldr             x1, [PP, #0x2b38]  ; [pp+0x2b38] AnonymousClosure: (0x898330), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::updateChildren (0x895d88)
    // 0x8967f0: r0 = AllocateClosure()
    //     0x8967f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8967f4: ldur            x1, [fp, #-8]
    // 0x8967f8: mov             x2, x0
    // 0x8967fc: r0 = updateConfig()
    //     0x8967fc: bl              #0x88fa6c  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::updateConfig
    // 0x896800: r0 = Null
    //     0x896800: mov             x0, NULL
    // 0x896804: LeaveFrame
    //     0x896804: mov             SP, fp
    //     0x896808: ldp             fp, lr, [SP], #0x10
    // 0x89680c: ret
    //     0x89680c: ret             
    // 0x896810: mov             x0, x3
    // 0x896814: r0 = ConcurrentModificationError()
    //     0x896814: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x896818: mov             x1, x0
    // 0x89681c: ldur            x0, [fp, #-0x38]
    // 0x896820: StoreField: r1->field_b = r0
    //     0x896820: stur            w0, [x1, #0xb]
    // 0x896824: mov             x0, x1
    // 0x896828: r0 = Throw()
    //     0x896828: bl              #0x13ddb2c  ; ThrowStub
    // 0x89682c: brk             #0
    // 0x896830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896834: b               #0x895da8
    // 0x896838: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896838: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89683c: b               #0x8961a8
    // 0x896840: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x896840: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x896844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896844: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896848: b               #0x896354
    // 0x89684c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89684c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896850: b               #0x8963d8
    // 0x896854: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x896854: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x896858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896858: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89685c: b               #0x896598
    // 0x896860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896860: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896864: b               #0x89660c
  }
  _ _marksConflictsInMergeGroup(/* No info */) {
    // ** addr: 0x896a00, size: 0x454
    // 0x896a00: EnterFrame
    //     0x896a00: stp             fp, lr, [SP, #-0x10]!
    //     0x896a04: mov             fp, SP
    // 0x896a08: AllocStack(0x60)
    //     0x896a08: sub             SP, SP, #0x60
    // 0x896a0c: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, {dynamic isMergeUp = false /* r3, fp-0x8 */})
    //     0x896a0c: mov             x0, x1
    //     0x896a10: stur            x1, [fp, #-0x10]
    //     0x896a14: stur            x2, [fp, #-0x18]
    //     0x896a18: ldur            w1, [x4, #0x13]
    //     0x896a1c: ldur            w3, [x4, #0x1f]
    //     0x896a20: add             x3, x3, HEAP, lsl #32
    //     0x896a24: ldr             x16, [PP, #0x2b70]  ; [pp+0x2b70] "isMergeUp"
    //     0x896a28: cmp             w3, w16
    //     0x896a2c: b.ne            #0x896a4c
    //     0x896a30: ldur            w3, [x4, #0x23]
    //     0x896a34: add             x3, x3, HEAP, lsl #32
    //     0x896a38: sub             w4, w1, w3
    //     0x896a3c: add             x1, fp, w4, sxtw #2
    //     0x896a40: ldr             x1, [x1, #8]
    //     0x896a44: mov             x3, x1
    //     0x896a48: b               #0x896a50
    //     0x896a4c: add             x3, NULL, #0x30  ; false
    //     0x896a50: stur            x3, [fp, #-8]
    // 0x896a54: CheckStackOverflow
    //     0x896a54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896a58: cmp             SP, x16
    //     0x896a5c: b.ls            #0x896e2c
    // 0x896a60: r1 = <_SemanticsFragment>
    //     0x896a60: ldr             x1, [PP, #0x23c0]  ; [pp+0x23c0] TypeArguments: <_SemanticsFragment>
    // 0x896a64: r0 = _Set()
    //     0x896a64: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x896a68: mov             x1, x0
    // 0x896a6c: r0 = _Uint32List
    //     0x896a6c: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x896a70: stur            x1, [fp, #-0x30]
    // 0x896a74: StoreField: r1->field_1b = r0
    //     0x896a74: stur            w0, [x1, #0x1b]
    // 0x896a78: StoreField: r1->field_b = rZR
    //     0x896a78: stur            wzr, [x1, #0xb]
    // 0x896a7c: r0 = const []
    //     0x896a7c: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x896a80: StoreField: r1->field_f = r0
    //     0x896a80: stur            w0, [x1, #0xf]
    // 0x896a84: StoreField: r1->field_13 = rZR
    //     0x896a84: stur            wzr, [x1, #0x13]
    // 0x896a88: ArrayStore: r1[0] = rZR  ; List_4
    //     0x896a88: stur            wzr, [x1, #0x17]
    // 0x896a8c: ldur            x0, [fp, #-0x10]
    // 0x896a90: LoadField: r2 = r0->field_3b
    //     0x896a90: ldur            w2, [x0, #0x3b]
    // 0x896a94: DecompressPointer r2
    //     0x896a94: add             x2, x2, HEAP, lsl #32
    // 0x896a98: stur            x2, [fp, #-0x28]
    // 0x896a9c: LoadField: r3 = r2->field_7
    //     0x896a9c: ldur            w3, [x2, #7]
    // 0x896aa0: DecompressPointer r3
    //     0x896aa0: add             x3, x3, HEAP, lsl #32
    // 0x896aa4: stur            x3, [fp, #-0x10]
    // 0x896aa8: r6 = 0
    //     0x896aa8: mov             x6, #0
    // 0x896aac: ldur            x4, [fp, #-0x18]
    // 0x896ab0: ldur            x5, [fp, #-8]
    // 0x896ab4: stur            x6, [fp, #-0x20]
    // 0x896ab8: CheckStackOverflow
    //     0x896ab8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896abc: cmp             SP, x16
    //     0x896ac0: b.ls            #0x896e34
    // 0x896ac4: r0 = LoadClassIdInstr(r4)
    //     0x896ac4: ldur            x0, [x4, #-1]
    //     0x896ac8: ubfx            x0, x0, #0xc, #0x14
    // 0x896acc: str             x4, [SP]
    // 0x896ad0: r0 = GDT[cid_x0 + 0xf078]()
    //     0x896ad0: mov             x17, #0xf078
    //     0x896ad4: add             lr, x0, x17
    //     0x896ad8: ldr             lr, [x21, lr, lsl #3]
    //     0x896adc: blr             lr
    // 0x896ae0: r1 = LoadInt32Instr(r0)
    //     0x896ae0: sbfx            x1, x0, #1, #0x1f
    //     0x896ae4: tbz             w0, #0, #0x896aec
    //     0x896ae8: ldur            x1, [x0, #7]
    // 0x896aec: ldur            x2, [fp, #-0x20]
    // 0x896af0: cmp             x2, x1
    // 0x896af4: b.ge            #0x896d80
    // 0x896af8: ldur            x3, [fp, #-0x18]
    // 0x896afc: r0 = BoxInt64Instr(r2)
    //     0x896afc: sbfiz           x0, x2, #1, #0x1f
    //     0x896b00: cmp             x2, x0, asr #1
    //     0x896b04: b.eq            #0x896b10
    //     0x896b08: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x896b0c: stur            x2, [x0, #7]
    // 0x896b10: r1 = LoadClassIdInstr(r3)
    //     0x896b10: ldur            x1, [x3, #-1]
    //     0x896b14: ubfx            x1, x1, #0xc, #0x14
    // 0x896b18: stp             x0, x3, [SP]
    // 0x896b1c: mov             x0, x1
    // 0x896b20: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x896b20: sub             lr, x0, #0xdfd
    //     0x896b24: ldr             lr, [x21, lr, lsl #3]
    //     0x896b28: blr             lr
    // 0x896b2c: mov             x3, x0
    // 0x896b30: stur            x3, [fp, #-0x38]
    // 0x896b34: r0 = LoadClassIdInstr(r3)
    //     0x896b34: ldur            x0, [x3, #-1]
    //     0x896b38: ubfx            x0, x0, #0xc, #0x14
    // 0x896b3c: mov             x1, x3
    // 0x896b40: r2 = false
    //     0x896b40: add             x2, NULL, #0x30  ; false
    // 0x896b44: r0 = GDT[cid_x0 + -0xe8c]()
    //     0x896b44: sub             lr, x0, #0xe8c
    //     0x896b48: ldr             lr, [x21, lr, lsl #3]
    //     0x896b4c: blr             lr
    // 0x896b50: ldur            x2, [fp, #-0x38]
    // 0x896b54: r0 = LoadClassIdInstr(r2)
    //     0x896b54: ldur            x0, [x2, #-1]
    //     0x896b58: ubfx            x0, x0, #0xc, #0x14
    // 0x896b5c: mov             x1, x2
    // 0x896b60: r0 = GDT[cid_x0 + -0xf66]()
    //     0x896b60: sub             lr, x0, #0xf66
    //     0x896b64: ldr             lr, [x21, lr, lsl #3]
    //     0x896b68: blr             lr
    // 0x896b6c: cmp             w0, NULL
    // 0x896b70: b.eq            #0x896d68
    // 0x896b74: ldur            x0, [fp, #-8]
    // 0x896b78: tbnz            w0, #4, #0x896c6c
    // 0x896b7c: ldur            x1, [fp, #-0x28]
    // 0x896b80: LoadField: r2 = r1->field_f
    //     0x896b80: ldur            w2, [x1, #0xf]
    // 0x896b84: DecompressPointer r2
    //     0x896b84: add             x2, x2, HEAP, lsl #32
    // 0x896b88: cmp             w2, NULL
    // 0x896b8c: b.ne            #0x896c0c
    // 0x896b90: ldur            x2, [fp, #-0x10]
    // 0x896b94: r0 = SemanticsConfiguration()
    //     0x896b94: bl              #0x839284  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0xc8)
    // 0x896b98: mov             x1, x0
    // 0x896b9c: stur            x0, [fp, #-0x40]
    // 0x896ba0: r0 = SemanticsConfiguration()
    //     0x896ba0: bl              #0x837c94  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0x896ba4: ldur            x0, [fp, #-0x40]
    // 0x896ba8: ldur            x3, [fp, #-0x28]
    // 0x896bac: StoreField: r3->field_f = r0
    //     0x896bac: stur            w0, [x3, #0xf]
    //     0x896bb0: ldurb           w16, [x3, #-1]
    //     0x896bb4: ldurb           w17, [x0, #-1]
    //     0x896bb8: and             x16, x17, x16, lsr #2
    //     0x896bbc: tst             x16, HEAP, lsr #32
    //     0x896bc0: b.eq            #0x896bc8
    //     0x896bc4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x896bc8: ldur            x0, [fp, #-0x40]
    // 0x896bcc: StoreField: r3->field_13 = r0
    //     0x896bcc: stur            w0, [x3, #0x13]
    //     0x896bd0: ldurb           w16, [x3, #-1]
    //     0x896bd4: ldurb           w17, [x0, #-1]
    //     0x896bd8: and             x16, x17, x16, lsr #2
    //     0x896bdc: tst             x16, HEAP, lsr #32
    //     0x896be0: b.eq            #0x896be8
    //     0x896be4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x896be8: ldur            x4, [fp, #-0x10]
    // 0x896bec: r0 = LoadClassIdInstr(r4)
    //     0x896bec: ldur            x0, [x4, #-1]
    //     0x896bf0: ubfx            x0, x0, #0xc, #0x14
    // 0x896bf4: mov             x1, x4
    // 0x896bf8: ldur            x2, [fp, #-0x40]
    // 0x896bfc: r0 = GDT[cid_x0 + 0xfeb3]()
    //     0x896bfc: mov             x17, #0xfeb3
    //     0x896c00: add             lr, x0, x17
    //     0x896c04: ldr             lr, [x21, lr, lsl #3]
    //     0x896c08: blr             lr
    // 0x896c0c: ldur            x3, [fp, #-0x38]
    // 0x896c10: ldur            x2, [fp, #-0x28]
    // 0x896c14: LoadField: r4 = r2->field_f
    //     0x896c14: ldur            w4, [x2, #0xf]
    // 0x896c18: DecompressPointer r4
    //     0x896c18: add             x4, x4, HEAP, lsl #32
    // 0x896c1c: stur            x4, [fp, #-0x40]
    // 0x896c20: cmp             w4, NULL
    // 0x896c24: b.eq            #0x896e3c
    // 0x896c28: r0 = LoadClassIdInstr(r3)
    //     0x896c28: ldur            x0, [x3, #-1]
    //     0x896c2c: ubfx            x0, x0, #0xc, #0x14
    // 0x896c30: mov             x1, x3
    // 0x896c34: r0 = GDT[cid_x0 + -0xf66]()
    //     0x896c34: sub             lr, x0, #0xf66
    //     0x896c38: ldr             lr, [x21, lr, lsl #3]
    //     0x896c3c: blr             lr
    // 0x896c40: ldur            x1, [fp, #-0x40]
    // 0x896c44: mov             x2, x0
    // 0x896c48: r0 = isCompatibleWith()
    //     0x896c48: bl              #0x896e54  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isCompatibleWith
    // 0x896c4c: tbz             w0, #4, #0x896c6c
    // 0x896c50: ldur            x1, [fp, #-0x30]
    // 0x896c54: ldur            x2, [fp, #-0x38]
    // 0x896c58: r0 = _hashCode()
    //     0x896c58: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x896c5c: ldur            x1, [fp, #-0x30]
    // 0x896c60: ldur            x2, [fp, #-0x38]
    // 0x896c64: mov             x3, x0
    // 0x896c68: r0 = _add()
    //     0x896c68: bl              #0x84ba3c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x896c6c: r5 = 0
    //     0x896c6c: mov             x5, #0
    // 0x896c70: ldur            x4, [fp, #-0x18]
    // 0x896c74: ldur            x3, [fp, #-0x20]
    // 0x896c78: ldur            x2, [fp, #-0x38]
    // 0x896c7c: stur            x5, [fp, #-0x48]
    // 0x896c80: CheckStackOverflow
    //     0x896c80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896c84: cmp             SP, x16
    //     0x896c88: b.ls            #0x896e40
    // 0x896c8c: cmp             x5, x3
    // 0x896c90: b.ge            #0x896d68
    // 0x896c94: r0 = BoxInt64Instr(r5)
    //     0x896c94: sbfiz           x0, x5, #1, #0x1f
    //     0x896c98: cmp             x5, x0, asr #1
    //     0x896c9c: b.eq            #0x896ca8
    //     0x896ca0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x896ca4: stur            x5, [x0, #7]
    // 0x896ca8: r1 = LoadClassIdInstr(r4)
    //     0x896ca8: ldur            x1, [x4, #-1]
    //     0x896cac: ubfx            x1, x1, #0xc, #0x14
    // 0x896cb0: stp             x0, x4, [SP]
    // 0x896cb4: mov             x0, x1
    // 0x896cb8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x896cb8: sub             lr, x0, #0xdfd
    //     0x896cbc: ldr             lr, [x21, lr, lsl #3]
    //     0x896cc0: blr             lr
    // 0x896cc4: mov             x3, x0
    // 0x896cc8: ldur            x2, [fp, #-0x38]
    // 0x896ccc: stur            x3, [fp, #-0x40]
    // 0x896cd0: r0 = LoadClassIdInstr(r2)
    //     0x896cd0: ldur            x0, [x2, #-1]
    //     0x896cd4: ubfx            x0, x0, #0xc, #0x14
    // 0x896cd8: mov             x1, x2
    // 0x896cdc: r0 = GDT[cid_x0 + -0xf66]()
    //     0x896cdc: sub             lr, x0, #0xf66
    //     0x896ce0: ldr             lr, [x21, lr, lsl #3]
    //     0x896ce4: blr             lr
    // 0x896ce8: mov             x2, x0
    // 0x896cec: stur            x2, [fp, #-0x50]
    // 0x896cf0: cmp             w2, NULL
    // 0x896cf4: b.eq            #0x896e48
    // 0x896cf8: ldur            x3, [fp, #-0x40]
    // 0x896cfc: r0 = LoadClassIdInstr(r3)
    //     0x896cfc: ldur            x0, [x3, #-1]
    //     0x896d00: ubfx            x0, x0, #0xc, #0x14
    // 0x896d04: mov             x1, x3
    // 0x896d08: r0 = GDT[cid_x0 + -0xf66]()
    //     0x896d08: sub             lr, x0, #0xf66
    //     0x896d0c: ldr             lr, [x21, lr, lsl #3]
    //     0x896d10: blr             lr
    // 0x896d14: ldur            x1, [fp, #-0x50]
    // 0x896d18: mov             x2, x0
    // 0x896d1c: r0 = isCompatibleWith()
    //     0x896d1c: bl              #0x896e54  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isCompatibleWith
    // 0x896d20: tbz             w0, #4, #0x896d5c
    // 0x896d24: ldur            x1, [fp, #-0x30]
    // 0x896d28: ldur            x2, [fp, #-0x38]
    // 0x896d2c: r0 = _hashCode()
    //     0x896d2c: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x896d30: ldur            x1, [fp, #-0x30]
    // 0x896d34: ldur            x2, [fp, #-0x38]
    // 0x896d38: mov             x3, x0
    // 0x896d3c: r0 = _add()
    //     0x896d3c: bl              #0x84ba3c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x896d40: ldur            x1, [fp, #-0x30]
    // 0x896d44: ldur            x2, [fp, #-0x40]
    // 0x896d48: r0 = _hashCode()
    //     0x896d48: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0x896d4c: ldur            x1, [fp, #-0x30]
    // 0x896d50: ldur            x2, [fp, #-0x40]
    // 0x896d54: mov             x3, x0
    // 0x896d58: r0 = _add()
    //     0x896d58: bl              #0x84ba3c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x896d5c: ldur            x0, [fp, #-0x48]
    // 0x896d60: add             x5, x0, #1
    // 0x896d64: b               #0x896c70
    // 0x896d68: ldur            x0, [fp, #-0x20]
    // 0x896d6c: add             x6, x0, #1
    // 0x896d70: ldur            x1, [fp, #-0x30]
    // 0x896d74: ldur            x2, [fp, #-0x28]
    // 0x896d78: ldur            x3, [fp, #-0x10]
    // 0x896d7c: b               #0x896aac
    // 0x896d80: ldur            x1, [fp, #-0x30]
    // 0x896d84: r0 = iterator()
    //     0x896d84: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x896d88: stur            x0, [fp, #-0x10]
    // 0x896d8c: LoadField: r2 = r0->field_7
    //     0x896d8c: ldur            w2, [x0, #7]
    // 0x896d90: DecompressPointer r2
    //     0x896d90: add             x2, x2, HEAP, lsl #32
    // 0x896d94: stur            x2, [fp, #-8]
    // 0x896d98: CheckStackOverflow
    //     0x896d98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x896d9c: cmp             SP, x16
    //     0x896da0: b.ls            #0x896e4c
    // 0x896da4: mov             x1, x0
    // 0x896da8: r0 = moveNext()
    //     0x896da8: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x896dac: tbnz            w0, #4, #0x896e1c
    // 0x896db0: ldur            x3, [fp, #-0x10]
    // 0x896db4: LoadField: r4 = r3->field_33
    //     0x896db4: ldur            w4, [x3, #0x33]
    // 0x896db8: DecompressPointer r4
    //     0x896db8: add             x4, x4, HEAP, lsl #32
    // 0x896dbc: stur            x4, [fp, #-0x18]
    // 0x896dc0: cmp             w4, NULL
    // 0x896dc4: b.ne            #0x896df4
    // 0x896dc8: mov             x0, x4
    // 0x896dcc: ldur            x2, [fp, #-8]
    // 0x896dd0: r1 = Null
    //     0x896dd0: mov             x1, NULL
    // 0x896dd4: cmp             w2, NULL
    // 0x896dd8: b.eq            #0x896df4
    // 0x896ddc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x896ddc: ldur            w4, [x2, #0x17]
    // 0x896de0: DecompressPointer r4
    //     0x896de0: add             x4, x4, HEAP, lsl #32
    // 0x896de4: r8 = X0
    //     0x896de4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x896de8: LoadField: r9 = r4->field_7
    //     0x896de8: ldur            x9, [x4, #7]
    // 0x896dec: r3 = Null
    //     0x896dec: ldr             x3, [PP, #0x2b78]  ; [pp+0x2b78] Null
    // 0x896df0: blr             x9
    // 0x896df4: ldur            x1, [fp, #-0x18]
    // 0x896df8: r0 = LoadClassIdInstr(r1)
    //     0x896df8: ldur            x0, [x1, #-1]
    //     0x896dfc: ubfx            x0, x0, #0xc, #0x14
    // 0x896e00: r2 = true
    //     0x896e00: add             x2, NULL, #0x20  ; true
    // 0x896e04: r0 = GDT[cid_x0 + -0xe8c]()
    //     0x896e04: sub             lr, x0, #0xe8c
    //     0x896e08: ldr             lr, [x21, lr, lsl #3]
    //     0x896e0c: blr             lr
    // 0x896e10: ldur            x0, [fp, #-0x10]
    // 0x896e14: ldur            x2, [fp, #-8]
    // 0x896e18: b               #0x896d98
    // 0x896e1c: r0 = Null
    //     0x896e1c: mov             x0, NULL
    // 0x896e20: LeaveFrame
    //     0x896e20: mov             SP, fp
    //     0x896e24: ldp             fp, lr, [SP], #0x10
    // 0x896e28: ret
    //     0x896e28: ret             
    // 0x896e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896e2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896e30: b               #0x896a60
    // 0x896e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896e38: b               #0x896ac4
    // 0x896e3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x896e3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x896e40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896e40: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896e44: b               #0x896c8c
    // 0x896e48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x896e48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x896e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x896e4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x896e50: b               #0x896da4
  }
  _ _collectChildMergeUpAndSiblingGroup(/* No info */) {
    // ** addr: 0x89748c, size: 0x8b8
    // 0x89748c: EnterFrame
    //     0x89748c: stp             fp, lr, [SP, #-0x10]!
    //     0x897490: mov             fp, SP
    // 0x897494: AllocStack(0xc0)
    //     0x897494: sub             SP, SP, #0xc0
    // 0x897498: SetupParameters(_RenderObjectSemantics this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x897498: stur            x1, [fp, #-8]
    //     0x89749c: stur            x2, [fp, #-0x10]
    // 0x8974a0: CheckStackOverflow
    //     0x8974a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8974a4: cmp             SP, x16
    //     0x8974a8: b.ls            #0x897d10
    // 0x8974ac: r1 = 2
    //     0x8974ac: mov             x1, #2
    // 0x8974b0: r0 = AllocateContext()
    //     0x8974b0: bl              #0x13de838  ; AllocateContextStub
    // 0x8974b4: mov             x3, x0
    // 0x8974b8: ldur            x0, [fp, #-8]
    // 0x8974bc: stur            x3, [fp, #-0x18]
    // 0x8974c0: StoreField: r3->field_f = r0
    //     0x8974c0: stur            w0, [x3, #0xf]
    // 0x8974c4: r1 = <_SemanticsFragment>
    //     0x8974c4: ldr             x1, [PP, #0x23c0]  ; [pp+0x23c0] TypeArguments: <_SemanticsFragment>
    // 0x8974c8: r2 = 0
    //     0x8974c8: mov             x2, #0
    // 0x8974cc: r0 = _GrowableList()
    //     0x8974cc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8974d0: r1 = <List<_SemanticsFragment>>
    //     0x8974d0: ldr             x1, [PP, #0x23c8]  ; [pp+0x23c8] TypeArguments: <List<_SemanticsFragment>>
    // 0x8974d4: r2 = 0
    //     0x8974d4: mov             x2, #0
    // 0x8974d8: stur            x0, [fp, #-0x20]
    // 0x8974dc: r0 = _GrowableList()
    //     0x8974dc: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8974e0: r1 = <SemanticsConfiguration>
    //     0x8974e0: ldr             x1, [PP, #0x2b08]  ; [pp+0x2b08] TypeArguments: <SemanticsConfiguration>
    // 0x8974e4: r2 = 0
    //     0x8974e4: mov             x2, #0
    // 0x8974e8: stur            x0, [fp, #-0x28]
    // 0x8974ec: r0 = _GrowableList()
    //     0x8974ec: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8974f0: mov             x2, x0
    // 0x8974f4: ldur            x0, [fp, #-8]
    // 0x8974f8: stur            x2, [fp, #-0x30]
    // 0x8974fc: LoadField: r1 = r0->field_3b
    //     0x8974fc: ldur            w1, [x0, #0x3b]
    // 0x897500: DecompressPointer r1
    //     0x897500: add             x1, x1, HEAP, lsl #32
    // 0x897504: LoadField: r3 = r1->field_13
    //     0x897504: ldur            w3, [x1, #0x13]
    // 0x897508: DecompressPointer r3
    //     0x897508: add             x3, x3, HEAP, lsl #32
    // 0x89750c: cmp             w3, NULL
    // 0x897510: b.ne            #0x897520
    // 0x897514: r0 = original()
    //     0x897514: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x897518: mov             x1, x0
    // 0x89751c: b               #0x897524
    // 0x897520: mov             x1, x3
    // 0x897524: ldur            x2, [fp, #-0x18]
    // 0x897528: r0 = palette()
    //     0x897528: bl              #0x122ab9c  ; [package:image/src/image/image_data_uint4.dart] ImageDataUint4::palette
    // 0x89752c: stur            x0, [fp, #-0x40]
    // 0x897530: cmp             w0, NULL
    // 0x897534: r16 = true
    //     0x897534: add             x16, NULL, #0x20  ; true
    // 0x897538: r17 = false
    //     0x897538: add             x17, NULL, #0x30  ; false
    // 0x89753c: csel            x1, x16, x17, ne
    // 0x897540: stur            x1, [fp, #-0x38]
    // 0x897544: r16 = <SemanticsConfiguration, _SemanticsFragment>
    //     0x897544: ldr             x16, [PP, #0x2b88]  ; [pp+0x2b88] TypeArguments: <SemanticsConfiguration, _SemanticsFragment>
    // 0x897548: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x89754c: stp             lr, x16, [SP]
    // 0x897550: r0 = Map._fromLiteral()
    //     0x897550: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x897554: mov             x1, x0
    // 0x897558: ldur            x2, [fp, #-0x18]
    // 0x89755c: stur            x1, [fp, #-0x78]
    // 0x897560: StoreField: r2->field_13 = r0
    //     0x897560: stur            w0, [x2, #0x13]
    //     0x897564: ldurb           w16, [x2, #-1]
    //     0x897568: ldurb           w17, [x0, #-1]
    //     0x89756c: and             x16, x17, x16, lsr #2
    //     0x897570: tst             x16, HEAP, lsr #32
    //     0x897574: b.eq            #0x89757c
    //     0x897578: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x89757c: ldur            x0, [fp, #-0x38]
    // 0x897580: tbnz            w0, #4, #0x897594
    // 0x897584: ldur            x3, [fp, #-0x10]
    // 0x897588: LoadField: r4 = r3->field_13
    //     0x897588: ldur            w4, [x3, #0x13]
    // 0x89758c: DecompressPointer r4
    //     0x89758c: add             x4, x4, HEAP, lsl #32
    // 0x897590: b               #0x89759c
    // 0x897594: ldur            x3, [fp, #-0x10]
    // 0x897598: r4 = false
    //     0x897598: add             x4, NULL, #0x30  ; false
    // 0x89759c: stur            x4, [fp, #-0x70]
    // 0x8975a0: tbnz            w4, #4, #0x897620
    // 0x8975a4: LoadField: r5 = r3->field_7
    //     0x8975a4: ldur            w5, [x3, #7]
    // 0x8975a8: DecompressPointer r5
    //     0x8975a8: add             x5, x5, HEAP, lsl #32
    // 0x8975ac: stur            x5, [fp, #-0x68]
    // 0x8975b0: LoadField: r6 = r3->field_b
    //     0x8975b0: ldur            w6, [x3, #0xb]
    // 0x8975b4: DecompressPointer r6
    //     0x8975b4: add             x6, x6, HEAP, lsl #32
    // 0x8975b8: stur            x6, [fp, #-0x60]
    // 0x8975bc: LoadField: r7 = r3->field_f
    //     0x8975bc: ldur            w7, [x3, #0xf]
    // 0x8975c0: DecompressPointer r7
    //     0x8975c0: add             x7, x7, HEAP, lsl #32
    // 0x8975c4: stur            x7, [fp, #-0x58]
    // 0x8975c8: ArrayLoad: r8 = r3[0]  ; List_4
    //     0x8975c8: ldur            w8, [x3, #0x17]
    // 0x8975cc: DecompressPointer r8
    //     0x8975cc: add             x8, x8, HEAP, lsl #32
    // 0x8975d0: stur            x8, [fp, #-0x50]
    // 0x8975d4: LoadField: r9 = r3->field_1b
    //     0x8975d4: ldur            w9, [x3, #0x1b]
    // 0x8975d8: DecompressPointer r9
    //     0x8975d8: add             x9, x9, HEAP, lsl #32
    // 0x8975dc: stur            x9, [fp, #-0x48]
    // 0x8975e0: r0 = _SemanticsParentData()
    //     0x8975e0: bl              #0x898190  ; Allocate_SemanticsParentDataStub -> _SemanticsParentData (size=0x20)
    // 0x8975e4: mov             x1, x0
    // 0x8975e8: ldur            x0, [fp, #-0x68]
    // 0x8975ec: StoreField: r1->field_7 = r0
    //     0x8975ec: stur            w0, [x1, #7]
    // 0x8975f0: ldur            x0, [fp, #-0x60]
    // 0x8975f4: StoreField: r1->field_b = r0
    //     0x8975f4: stur            w0, [x1, #0xb]
    // 0x8975f8: r0 = false
    //     0x8975f8: add             x0, NULL, #0x30  ; false
    // 0x8975fc: StoreField: r1->field_13 = r0
    //     0x8975fc: stur            w0, [x1, #0x13]
    // 0x897600: ldur            x2, [fp, #-0x50]
    // 0x897604: ArrayStore: r1[0] = r2  ; List_4
    //     0x897604: stur            w2, [x1, #0x17]
    // 0x897608: ldur            x2, [fp, #-0x48]
    // 0x89760c: StoreField: r1->field_1b = r2
    //     0x89760c: stur            w2, [x1, #0x1b]
    // 0x897610: ldur            x2, [fp, #-0x58]
    // 0x897614: StoreField: r1->field_f = r2
    //     0x897614: stur            w2, [x1, #0xf]
    // 0x897618: mov             x2, x1
    // 0x89761c: b               #0x897628
    // 0x897620: r0 = false
    //     0x897620: add             x0, NULL, #0x30  ; false
    // 0x897624: ldur            x2, [fp, #-0x10]
    // 0x897628: ldur            x1, [fp, #-8]
    // 0x89762c: stur            x2, [fp, #-0x48]
    // 0x897630: r0 = _getNonBlockedChildren()
    //     0x897630: bl              #0x897d44  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_getNonBlockedChildren
    // 0x897634: mov             x1, x0
    // 0x897638: stur            x1, [fp, #-0x58]
    // 0x89763c: LoadField: r0 = r1->field_b
    //     0x89763c: ldur            w0, [x1, #0xb]
    // 0x897640: r2 = LoadInt32Instr(r0)
    //     0x897640: sbfx            x2, x0, #1, #0x1f
    // 0x897644: stur            x2, [fp, #-0x88]
    // 0x897648: r0 = 0
    //     0x897648: mov             x0, #0
    // 0x89764c: ldur            x5, [fp, #-0x20]
    // 0x897650: ldur            x4, [fp, #-0x30]
    // 0x897654: ldur            x3, [fp, #-0x38]
    // 0x897658: CheckStackOverflow
    //     0x897658: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89765c: cmp             SP, x16
    //     0x897660: b.ls            #0x897d18
    // 0x897664: LoadField: r6 = r1->field_b
    //     0x897664: ldur            w6, [x1, #0xb]
    // 0x897668: r7 = LoadInt32Instr(r6)
    //     0x897668: sbfx            x7, x6, #1, #0x1f
    // 0x89766c: cmp             x2, x7
    // 0x897670: b.ne            #0x897cf0
    // 0x897674: cmp             x0, x7
    // 0x897678: b.ge            #0x897948
    // 0x89767c: LoadField: r6 = r1->field_f
    //     0x89767c: ldur            w6, [x1, #0xf]
    // 0x897680: DecompressPointer r6
    //     0x897680: add             x6, x6, HEAP, lsl #32
    // 0x897684: ArrayLoad: r7 = r6[r0]  ; Unknown_4
    //     0x897684: add             x16, x6, x0, lsl #2
    //     0x897688: ldur            w7, [x16, #0xf]
    // 0x89768c: DecompressPointer r7
    //     0x89768c: add             x7, x7, HEAP, lsl #32
    // 0x897690: stur            x7, [fp, #-0x50]
    // 0x897694: add             x6, x0, #1
    // 0x897698: stur            x6, [fp, #-0x80]
    // 0x89769c: LoadField: r0 = r7->field_33
    //     0x89769c: ldur            w0, [x7, #0x33]
    // 0x8976a0: DecompressPointer r0
    //     0x8976a0: add             x0, x0, HEAP, lsl #32
    // 0x8976a4: r8 = LoadClassIdInstr(r0)
    //     0x8976a4: ldur            x8, [x0, #-1]
    //     0x8976a8: ubfx            x8, x8, #0xc, #0x14
    // 0x8976ac: ldur            x16, [fp, #-0x48]
    // 0x8976b0: stp             x16, x0, [SP]
    // 0x8976b4: mov             x0, x8
    // 0x8976b8: mov             lr, x0
    // 0x8976bc: ldr             lr, [x21, lr, lsl #3]
    // 0x8976c0: blr             lr
    // 0x8976c4: tbz             w0, #4, #0x897700
    // 0x8976c8: ldur            x0, [fp, #-0x50]
    // 0x8976cc: mov             x1, x0
    // 0x8976d0: r0 = markNeedsBuild()
    //     0x8976d0: bl              #0x890088  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::markNeedsBuild
    // 0x8976d4: ldur            x0, [fp, #-0x48]
    // 0x8976d8: ldur            x2, [fp, #-0x50]
    // 0x8976dc: StoreField: r2->field_33 = r0
    //     0x8976dc: stur            w0, [x2, #0x33]
    //     0x8976e0: ldurb           w16, [x2, #-1]
    //     0x8976e4: ldurb           w17, [x0, #-1]
    //     0x8976e8: and             x16, x17, x16, lsr #2
    //     0x8976ec: tst             x16, HEAP, lsr #32
    //     0x8976f0: b.eq            #0x8976f8
    //     0x8976f4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x8976f8: mov             x1, x2
    // 0x8976fc: r0 = updateChildren()
    //     0x8976fc: bl              #0x895d88  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::updateChildren
    // 0x897700: ldur            x2, [fp, #-0x50]
    // 0x897704: LoadField: r3 = r2->field_23
    //     0x897704: ldur            w3, [x2, #0x23]
    // 0x897708: DecompressPointer r3
    //     0x897708: add             x3, x3, HEAP, lsl #32
    // 0x89770c: stur            x3, [fp, #-0x68]
    // 0x897710: LoadField: r0 = r3->field_b
    //     0x897710: ldur            w0, [x3, #0xb]
    // 0x897714: r4 = LoadInt32Instr(r0)
    //     0x897714: sbfx            x4, x0, #1, #0x1f
    // 0x897718: stur            x4, [fp, #-0x98]
    // 0x89771c: ldur            x7, [fp, #-0x20]
    // 0x897720: r0 = 0
    //     0x897720: mov             x0, #0
    // 0x897724: ldur            x6, [fp, #-0x30]
    // 0x897728: ldur            x5, [fp, #-0x38]
    // 0x89772c: CheckStackOverflow
    //     0x89772c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x897730: cmp             SP, x16
    //     0x897734: b.ls            #0x897d20
    // 0x897738: LoadField: r1 = r3->field_b
    //     0x897738: ldur            w1, [x3, #0xb]
    // 0x89773c: r8 = LoadInt32Instr(r1)
    //     0x89773c: sbfx            x8, x1, #1, #0x1f
    // 0x897740: cmp             x4, x8
    // 0x897744: b.ne            #0x897c90
    // 0x897748: cmp             x0, x8
    // 0x89774c: b.ge            #0x897914
    // 0x897750: LoadField: r1 = r3->field_f
    //     0x897750: ldur            w1, [x3, #0xf]
    // 0x897754: DecompressPointer r1
    //     0x897754: add             x1, x1, HEAP, lsl #32
    // 0x897758: ArrayLoad: r8 = r1[r0]  ; Unknown_4
    //     0x897758: add             x16, x1, x0, lsl #2
    //     0x89775c: ldur            w8, [x16, #0xf]
    // 0x897760: DecompressPointer r8
    //     0x897760: add             x8, x8, HEAP, lsl #32
    // 0x897764: stur            x8, [fp, #-0x60]
    // 0x897768: add             x9, x0, #1
    // 0x89776c: stur            x9, [fp, #-0x90]
    // 0x897770: tbnz            w5, #4, #0x897884
    // 0x897774: r0 = LoadClassIdInstr(r8)
    //     0x897774: ldur            x0, [x8, #-1]
    //     0x897778: ubfx            x0, x0, #0xc, #0x14
    // 0x89777c: mov             x1, x8
    // 0x897780: r0 = GDT[cid_x0 + -0xf66]()
    //     0x897780: sub             lr, x0, #0xf66
    //     0x897784: ldr             lr, [x21, lr, lsl #3]
    //     0x897788: blr             lr
    // 0x89778c: cmp             w0, NULL
    // 0x897790: b.eq            #0x897884
    // 0x897794: ldur            x2, [fp, #-0x30]
    // 0x897798: ldur            x3, [fp, #-0x60]
    // 0x89779c: r0 = LoadClassIdInstr(r3)
    //     0x89779c: ldur            x0, [x3, #-1]
    //     0x8977a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8977a4: mov             x1, x3
    // 0x8977a8: r0 = GDT[cid_x0 + -0xf66]()
    //     0x8977a8: sub             lr, x0, #0xf66
    //     0x8977ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8977b0: blr             lr
    // 0x8977b4: stur            x0, [fp, #-0xa8]
    // 0x8977b8: cmp             w0, NULL
    // 0x8977bc: b.eq            #0x897d28
    // 0x8977c0: ldur            x2, [fp, #-0x30]
    // 0x8977c4: LoadField: r1 = r2->field_b
    //     0x8977c4: ldur            w1, [x2, #0xb]
    // 0x8977c8: LoadField: r3 = r2->field_f
    //     0x8977c8: ldur            w3, [x2, #0xf]
    // 0x8977cc: DecompressPointer r3
    //     0x8977cc: add             x3, x3, HEAP, lsl #32
    // 0x8977d0: LoadField: r4 = r3->field_b
    //     0x8977d0: ldur            w4, [x3, #0xb]
    // 0x8977d4: r3 = LoadInt32Instr(r1)
    //     0x8977d4: sbfx            x3, x1, #1, #0x1f
    // 0x8977d8: stur            x3, [fp, #-0xa0]
    // 0x8977dc: r1 = LoadInt32Instr(r4)
    //     0x8977dc: sbfx            x1, x4, #1, #0x1f
    // 0x8977e0: cmp             x3, x1
    // 0x8977e4: b.ne            #0x8977f0
    // 0x8977e8: mov             x1, x2
    // 0x8977ec: r0 = _growToNextCapacity()
    //     0x8977ec: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8977f0: ldur            x2, [fp, #-0x30]
    // 0x8977f4: ldur            x3, [fp, #-0xa0]
    // 0x8977f8: ldur            x4, [fp, #-0x60]
    // 0x8977fc: add             x0, x3, #1
    // 0x897800: lsl             x1, x0, #1
    // 0x897804: StoreField: r2->field_b = r1
    //     0x897804: stur            w1, [x2, #0xb]
    // 0x897808: LoadField: r1 = r2->field_f
    //     0x897808: ldur            w1, [x2, #0xf]
    // 0x89780c: DecompressPointer r1
    //     0x89780c: add             x1, x1, HEAP, lsl #32
    // 0x897810: ldur            x0, [fp, #-0xa8]
    // 0x897814: ArrayStore: r1[r3] = r0  ; List_4
    //     0x897814: add             x25, x1, x3, lsl #2
    //     0x897818: add             x25, x25, #0xf
    //     0x89781c: str             w0, [x25]
    //     0x897820: tbz             w0, #0, #0x89783c
    //     0x897824: ldurb           w16, [x1, #-1]
    //     0x897828: ldurb           w17, [x0, #-1]
    //     0x89782c: and             x16, x17, x16, lsr #2
    //     0x897830: tst             x16, HEAP, lsr #32
    //     0x897834: b.eq            #0x89783c
    //     0x897838: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x89783c: r0 = LoadClassIdInstr(r4)
    //     0x89783c: ldur            x0, [x4, #-1]
    //     0x897840: ubfx            x0, x0, #0xc, #0x14
    // 0x897844: mov             x1, x4
    // 0x897848: r0 = GDT[cid_x0 + -0xf66]()
    //     0x897848: sub             lr, x0, #0xf66
    //     0x89784c: ldr             lr, [x21, lr, lsl #3]
    //     0x897850: blr             lr
    // 0x897854: stur            x0, [fp, #-0xa8]
    // 0x897858: cmp             w0, NULL
    // 0x89785c: b.eq            #0x897d2c
    // 0x897860: str             x0, [SP]
    // 0x897864: r0 = _getHash()
    //     0x897864: bl              #0x84c644  ; [dart:core] ::_getHash
    // 0x897868: ldur            x1, [fp, #-0x78]
    // 0x89786c: ldur            x2, [fp, #-0xa8]
    // 0x897870: ldur            x3, [fp, #-0x60]
    // 0x897874: mov             x5, x0
    // 0x897878: r0 = _set()
    //     0x897878: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x89787c: ldur            x2, [fp, #-0x20]
    // 0x897880: b               #0x8978fc
    // 0x897884: ldur            x0, [fp, #-0x20]
    // 0x897888: LoadField: r1 = r0->field_b
    //     0x897888: ldur            w1, [x0, #0xb]
    // 0x89788c: LoadField: r2 = r0->field_f
    //     0x89788c: ldur            w2, [x0, #0xf]
    // 0x897890: DecompressPointer r2
    //     0x897890: add             x2, x2, HEAP, lsl #32
    // 0x897894: LoadField: r3 = r2->field_b
    //     0x897894: ldur            w3, [x2, #0xb]
    // 0x897898: r2 = LoadInt32Instr(r1)
    //     0x897898: sbfx            x2, x1, #1, #0x1f
    // 0x89789c: stur            x2, [fp, #-0xa0]
    // 0x8978a0: r1 = LoadInt32Instr(r3)
    //     0x8978a0: sbfx            x1, x3, #1, #0x1f
    // 0x8978a4: cmp             x2, x1
    // 0x8978a8: b.ne            #0x8978b4
    // 0x8978ac: mov             x1, x0
    // 0x8978b0: r0 = _growToNextCapacity()
    //     0x8978b0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8978b4: ldur            x2, [fp, #-0x20]
    // 0x8978b8: ldur            x3, [fp, #-0xa0]
    // 0x8978bc: add             x0, x3, #1
    // 0x8978c0: lsl             x1, x0, #1
    // 0x8978c4: StoreField: r2->field_b = r1
    //     0x8978c4: stur            w1, [x2, #0xb]
    // 0x8978c8: LoadField: r1 = r2->field_f
    //     0x8978c8: ldur            w1, [x2, #0xf]
    // 0x8978cc: DecompressPointer r1
    //     0x8978cc: add             x1, x1, HEAP, lsl #32
    // 0x8978d0: ldur            x0, [fp, #-0x60]
    // 0x8978d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8978d4: add             x25, x1, x3, lsl #2
    //     0x8978d8: add             x25, x25, #0xf
    //     0x8978dc: str             w0, [x25]
    //     0x8978e0: tbz             w0, #0, #0x8978fc
    //     0x8978e4: ldurb           w16, [x1, #-1]
    //     0x8978e8: ldurb           w17, [x0, #-1]
    //     0x8978ec: and             x16, x17, x16, lsr #2
    //     0x8978f0: tst             x16, HEAP, lsr #32
    //     0x8978f4: b.eq            #0x8978fc
    //     0x8978f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x8978fc: ldur            x0, [fp, #-0x90]
    // 0x897900: mov             x7, x2
    // 0x897904: ldur            x3, [fp, #-0x68]
    // 0x897908: ldur            x4, [fp, #-0x98]
    // 0x89790c: ldur            x2, [fp, #-0x50]
    // 0x897910: b               #0x897724
    // 0x897914: mov             x2, x7
    // 0x897918: ldur            x1, [fp, #-0x50]
    // 0x89791c: r0 = contributesToSemanticsTree()
    //     0x89791c: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x897920: tbz             w0, #4, #0x897938
    // 0x897924: ldur            x0, [fp, #-0x50]
    // 0x897928: LoadField: r2 = r0->field_2b
    //     0x897928: ldur            w2, [x0, #0x2b]
    // 0x89792c: DecompressPointer r2
    //     0x89792c: add             x2, x2, HEAP, lsl #32
    // 0x897930: ldur            x1, [fp, #-0x28]
    // 0x897934: r0 = addAll()
    //     0x897934: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x897938: ldur            x0, [fp, #-0x80]
    // 0x89793c: ldur            x1, [fp, #-0x58]
    // 0x897940: ldur            x2, [fp, #-0x88]
    // 0x897944: b               #0x89764c
    // 0x897948: ldur            x2, [fp, #-8]
    // 0x89794c: mov             x0, x3
    // 0x897950: r1 = false
    //     0x897950: add             x1, NULL, #0x30  ; false
    // 0x897954: StoreField: r2->field_13 = r1
    //     0x897954: stur            w1, [x2, #0x13]
    // 0x897958: tbnz            w0, #4, #0x897b44
    // 0x89795c: ldur            x0, [fp, #-0x40]
    // 0x897960: cmp             w0, NULL
    // 0x897964: b.eq            #0x897d30
    // 0x897968: ldur            x16, [fp, #-0x30]
    // 0x89796c: stp             x16, x0, [SP]
    // 0x897970: ClosureCall
    //     0x897970: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x897974: ldur            x2, [x0, #0x1f]
    //     0x897978: blr             x2
    // 0x89797c: stur            x0, [fp, #-0x38]
    // 0x897980: LoadField: r3 = r0->field_7
    //     0x897980: ldur            w3, [x0, #7]
    // 0x897984: DecompressPointer r3
    //     0x897984: add             x3, x3, HEAP, lsl #32
    // 0x897988: ldur            x2, [fp, #-0x18]
    // 0x89798c: stur            x3, [fp, #-0x30]
    // 0x897990: r1 = Function '<anonymous closure>':.
    //     0x897990: ldr             x1, [PP, #0x2b90]  ; [pp+0x2b90] AnonymousClosure: (0x8980c8), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_collectChildMergeUpAndSiblingGroup (0x89748c)
    // 0x897994: r0 = AllocateClosure()
    //     0x897994: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x897998: r16 = <_SemanticsFragment>
    //     0x897998: ldr             x16, [PP, #0x23c0]  ; [pp+0x23c0] TypeArguments: <_SemanticsFragment>
    // 0x89799c: ldur            lr, [fp, #-0x30]
    // 0x8979a0: stp             lr, x16, [SP, #8]
    // 0x8979a4: str             x0, [SP]
    // 0x8979a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8979a8: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8979ac: r0 = map()
    //     0x8979ac: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x8979b0: ldur            x1, [fp, #-0x20]
    // 0x8979b4: mov             x2, x0
    // 0x8979b8: r0 = addAll()
    //     0x8979b8: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x8979bc: ldur            x0, [fp, #-0x38]
    // 0x8979c0: LoadField: r3 = r0->field_b
    //     0x8979c0: ldur            w3, [x0, #0xb]
    // 0x8979c4: DecompressPointer r3
    //     0x8979c4: add             x3, x3, HEAP, lsl #32
    // 0x8979c8: stur            x3, [fp, #-0x40]
    // 0x8979cc: LoadField: r0 = r3->field_b
    //     0x8979cc: ldur            w0, [x3, #0xb]
    // 0x8979d0: r4 = LoadInt32Instr(r0)
    //     0x8979d0: sbfx            x4, x0, #1, #0x1f
    // 0x8979d4: stur            x4, [fp, #-0x88]
    // 0x8979d8: ldur            x0, [fp, #-0x28]
    // 0x8979dc: r1 = 0
    //     0x8979dc: mov             x1, #0
    // 0x8979e0: CheckStackOverflow
    //     0x8979e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8979e4: cmp             SP, x16
    //     0x8979e8: b.ls            #0x897d34
    // 0x8979ec: LoadField: r2 = r3->field_b
    //     0x8979ec: ldur            w2, [x3, #0xb]
    // 0x8979f0: r5 = LoadInt32Instr(r2)
    //     0x8979f0: sbfx            x5, x2, #1, #0x1f
    // 0x8979f4: cmp             x4, x5
    // 0x8979f8: b.ne            #0x897cb0
    // 0x8979fc: cmp             x1, x5
    // 0x897a00: b.ge            #0x897b3c
    // 0x897a04: LoadField: r2 = r3->field_f
    //     0x897a04: ldur            w2, [x3, #0xf]
    // 0x897a08: DecompressPointer r2
    //     0x897a08: add             x2, x2, HEAP, lsl #32
    // 0x897a0c: ArrayLoad: r5 = r2[r1]  ; Unknown_4
    //     0x897a0c: add             x16, x2, x1, lsl #2
    //     0x897a10: ldur            w5, [x16, #0xf]
    // 0x897a14: DecompressPointer r5
    //     0x897a14: add             x5, x5, HEAP, lsl #32
    // 0x897a18: stur            x5, [fp, #-0x30]
    // 0x897a1c: add             x6, x1, #1
    // 0x897a20: ldur            x2, [fp, #-0x18]
    // 0x897a24: stur            x6, [fp, #-0x80]
    // 0x897a28: r1 = Function '<anonymous closure>':.
    //     0x897a28: ldr             x1, [PP, #0x2b98]  ; [pp+0x2b98] AnonymousClosure: (0x8980c8), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_collectChildMergeUpAndSiblingGroup (0x89748c)
    // 0x897a2c: r0 = AllocateClosure()
    //     0x897a2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x897a30: mov             x1, x0
    // 0x897a34: ldur            x0, [fp, #-0x30]
    // 0x897a38: r2 = LoadClassIdInstr(r0)
    //     0x897a38: ldur            x2, [x0, #-1]
    //     0x897a3c: ubfx            x2, x2, #0xc, #0x14
    // 0x897a40: r16 = <_SemanticsFragment>
    //     0x897a40: ldr             x16, [PP, #0x23c0]  ; [pp+0x23c0] TypeArguments: <_SemanticsFragment>
    // 0x897a44: stp             x0, x16, [SP, #8]
    // 0x897a48: str             x1, [SP]
    // 0x897a4c: mov             x0, x2
    // 0x897a50: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x897a50: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x897a54: r0 = GDT[cid_x0 + 0x12caa]()
    //     0x897a54: mov             x17, #0x2caa
    //     0x897a58: movk            x17, #1, lsl #16
    //     0x897a5c: add             lr, x0, x17
    //     0x897a60: ldr             lr, [x21, lr, lsl #3]
    //     0x897a64: blr             lr
    // 0x897a68: r1 = LoadClassIdInstr(r0)
    //     0x897a68: ldur            x1, [x0, #-1]
    //     0x897a6c: ubfx            x1, x1, #0xc, #0x14
    // 0x897a70: mov             x16, x0
    // 0x897a74: mov             x0, x1
    // 0x897a78: mov             x1, x16
    // 0x897a7c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x897a7c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x897a80: r0 = GDT[cid_x0 + 0x126dc]()
    //     0x897a80: mov             x17, #0x26dc
    //     0x897a84: movk            x17, #1, lsl #16
    //     0x897a88: add             lr, x0, x17
    //     0x897a8c: ldr             lr, [x21, lr, lsl #3]
    //     0x897a90: blr             lr
    // 0x897a94: mov             x3, x0
    // 0x897a98: r2 = Null
    //     0x897a98: mov             x2, NULL
    // 0x897a9c: r1 = Null
    //     0x897a9c: mov             x1, NULL
    // 0x897aa0: stur            x3, [fp, #-0x30]
    // 0x897aa4: r8 = List<_SemanticsFragment>
    //     0x897aa4: ldr             x8, [PP, #0x2ba0]  ; [pp+0x2ba0] Type: List<_SemanticsFragment>
    // 0x897aa8: r3 = Null
    //     0x897aa8: ldr             x3, [PP, #0x2ba8]  ; [pp+0x2ba8] Null
    // 0x897aac: r0 = List<_SemanticsFragment>()
    //     0x897aac: bl              #0x8394bc  ; IsType_List<_SemanticsFragment>_Stub
    // 0x897ab0: ldur            x0, [fp, #-0x28]
    // 0x897ab4: LoadField: r1 = r0->field_b
    //     0x897ab4: ldur            w1, [x0, #0xb]
    // 0x897ab8: LoadField: r2 = r0->field_f
    //     0x897ab8: ldur            w2, [x0, #0xf]
    // 0x897abc: DecompressPointer r2
    //     0x897abc: add             x2, x2, HEAP, lsl #32
    // 0x897ac0: LoadField: r3 = r2->field_b
    //     0x897ac0: ldur            w3, [x2, #0xb]
    // 0x897ac4: r2 = LoadInt32Instr(r1)
    //     0x897ac4: sbfx            x2, x1, #1, #0x1f
    // 0x897ac8: stur            x2, [fp, #-0x90]
    // 0x897acc: r1 = LoadInt32Instr(r3)
    //     0x897acc: sbfx            x1, x3, #1, #0x1f
    // 0x897ad0: cmp             x2, x1
    // 0x897ad4: b.ne            #0x897ae0
    // 0x897ad8: mov             x1, x0
    // 0x897adc: r0 = _growToNextCapacity()
    //     0x897adc: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x897ae0: ldur            x2, [fp, #-0x28]
    // 0x897ae4: ldur            x3, [fp, #-0x90]
    // 0x897ae8: add             x0, x3, #1
    // 0x897aec: lsl             x1, x0, #1
    // 0x897af0: StoreField: r2->field_b = r1
    //     0x897af0: stur            w1, [x2, #0xb]
    // 0x897af4: LoadField: r1 = r2->field_f
    //     0x897af4: ldur            w1, [x2, #0xf]
    // 0x897af8: DecompressPointer r1
    //     0x897af8: add             x1, x1, HEAP, lsl #32
    // 0x897afc: ldur            x0, [fp, #-0x30]
    // 0x897b00: ArrayStore: r1[r3] = r0  ; List_4
    //     0x897b00: add             x25, x1, x3, lsl #2
    //     0x897b04: add             x25, x25, #0xf
    //     0x897b08: str             w0, [x25]
    //     0x897b0c: tbz             w0, #0, #0x897b28
    //     0x897b10: ldurb           w16, [x1, #-1]
    //     0x897b14: ldurb           w17, [x0, #-1]
    //     0x897b18: and             x16, x17, x16, lsr #2
    //     0x897b1c: tst             x16, HEAP, lsr #32
    //     0x897b20: b.eq            #0x897b28
    //     0x897b24: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x897b28: ldur            x1, [fp, #-0x80]
    // 0x897b2c: mov             x0, x2
    // 0x897b30: ldur            x3, [fp, #-0x40]
    // 0x897b34: ldur            x4, [fp, #-0x88]
    // 0x897b38: b               #0x8979e0
    // 0x897b3c: mov             x2, x0
    // 0x897b40: b               #0x897b48
    // 0x897b44: ldur            x2, [fp, #-0x28]
    // 0x897b48: ldur            x0, [fp, #-8]
    // 0x897b4c: LoadField: r1 = r0->field_13
    //     0x897b4c: ldur            w1, [x0, #0x13]
    // 0x897b50: DecompressPointer r1
    //     0x897b50: add             x1, x1, HEAP, lsl #32
    // 0x897b54: tbz             w1, #4, #0x897c7c
    // 0x897b58: ldur            x1, [fp, #-0x70]
    // 0x897b5c: tbnz            w1, #4, #0x897c7c
    // 0x897b60: ldur            x1, [fp, #-0x20]
    // 0x897b64: r0 = clear()
    //     0x897b64: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x897b68: ldur            x1, [fp, #-0x28]
    // 0x897b6c: r0 = clear()
    //     0x897b6c: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x897b70: ldur            x1, [fp, #-8]
    // 0x897b74: r0 = _getNonBlockedChildren()
    //     0x897b74: bl              #0x897d44  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_getNonBlockedChildren
    // 0x897b78: mov             x1, x0
    // 0x897b7c: stur            x1, [fp, #-0x18]
    // 0x897b80: LoadField: r0 = r1->field_b
    //     0x897b80: ldur            w0, [x1, #0xb]
    // 0x897b84: r2 = LoadInt32Instr(r0)
    //     0x897b84: sbfx            x2, x0, #1, #0x1f
    // 0x897b88: stur            x2, [fp, #-0x88]
    // 0x897b8c: r0 = 0
    //     0x897b8c: mov             x0, #0
    // 0x897b90: CheckStackOverflow
    //     0x897b90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x897b94: cmp             SP, x16
    //     0x897b98: b.ls            #0x897d3c
    // 0x897b9c: LoadField: r3 = r1->field_b
    //     0x897b9c: ldur            w3, [x1, #0xb]
    // 0x897ba0: r4 = LoadInt32Instr(r3)
    //     0x897ba0: sbfx            x4, x3, #1, #0x1f
    // 0x897ba4: cmp             x2, x4
    // 0x897ba8: b.ne            #0x897cd0
    // 0x897bac: cmp             x0, x4
    // 0x897bb0: b.ge            #0x897c7c
    // 0x897bb4: LoadField: r3 = r1->field_f
    //     0x897bb4: ldur            w3, [x1, #0xf]
    // 0x897bb8: DecompressPointer r3
    //     0x897bb8: add             x3, x3, HEAP, lsl #32
    // 0x897bbc: ArrayLoad: r4 = r3[r0]  ; Unknown_4
    //     0x897bbc: add             x16, x3, x0, lsl #2
    //     0x897bc0: ldur            w4, [x16, #0xf]
    // 0x897bc4: DecompressPointer r4
    //     0x897bc4: add             x4, x4, HEAP, lsl #32
    // 0x897bc8: stur            x4, [fp, #-8]
    // 0x897bcc: add             x3, x0, #1
    // 0x897bd0: stur            x3, [fp, #-0x80]
    // 0x897bd4: LoadField: r0 = r4->field_33
    //     0x897bd4: ldur            w0, [x4, #0x33]
    // 0x897bd8: DecompressPointer r0
    //     0x897bd8: add             x0, x0, HEAP, lsl #32
    // 0x897bdc: r5 = LoadClassIdInstr(r0)
    //     0x897bdc: ldur            x5, [x0, #-1]
    //     0x897be0: ubfx            x5, x5, #0xc, #0x14
    // 0x897be4: ldur            x16, [fp, #-0x10]
    // 0x897be8: stp             x16, x0, [SP]
    // 0x897bec: mov             x0, x5
    // 0x897bf0: mov             lr, x0
    // 0x897bf4: ldr             lr, [x21, lr, lsl #3]
    // 0x897bf8: blr             lr
    // 0x897bfc: tbz             w0, #4, #0x897c38
    // 0x897c00: ldur            x0, [fp, #-8]
    // 0x897c04: mov             x1, x0
    // 0x897c08: r0 = markNeedsBuild()
    //     0x897c08: bl              #0x890088  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::markNeedsBuild
    // 0x897c0c: ldur            x0, [fp, #-0x10]
    // 0x897c10: ldur            x2, [fp, #-8]
    // 0x897c14: StoreField: r2->field_33 = r0
    //     0x897c14: stur            w0, [x2, #0x33]
    //     0x897c18: ldurb           w16, [x2, #-1]
    //     0x897c1c: ldurb           w17, [x0, #-1]
    //     0x897c20: and             x16, x17, x16, lsr #2
    //     0x897c24: tst             x16, HEAP, lsr #32
    //     0x897c28: b.eq            #0x897c30
    //     0x897c2c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x897c30: mov             x1, x2
    // 0x897c34: r0 = updateChildren()
    //     0x897c34: bl              #0x895d88  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::updateChildren
    // 0x897c38: ldur            x0, [fp, #-8]
    // 0x897c3c: LoadField: r2 = r0->field_23
    //     0x897c3c: ldur            w2, [x0, #0x23]
    // 0x897c40: DecompressPointer r2
    //     0x897c40: add             x2, x2, HEAP, lsl #32
    // 0x897c44: ldur            x1, [fp, #-0x20]
    // 0x897c48: r0 = addAll()
    //     0x897c48: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x897c4c: ldur            x1, [fp, #-8]
    // 0x897c50: r0 = contributesToSemanticsTree()
    //     0x897c50: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x897c54: tbz             w0, #4, #0x897c6c
    // 0x897c58: ldur            x0, [fp, #-8]
    // 0x897c5c: LoadField: r2 = r0->field_2b
    //     0x897c5c: ldur            w2, [x0, #0x2b]
    // 0x897c60: DecompressPointer r2
    //     0x897c60: add             x2, x2, HEAP, lsl #32
    // 0x897c64: ldur            x1, [fp, #-0x28]
    // 0x897c68: r0 = addAll()
    //     0x897c68: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x897c6c: ldur            x0, [fp, #-0x80]
    // 0x897c70: ldur            x1, [fp, #-0x18]
    // 0x897c74: ldur            x2, [fp, #-0x88]
    // 0x897c78: b               #0x897b90
    // 0x897c7c: ldur            x0, [fp, #-0x20]
    // 0x897c80: ldur            x1, [fp, #-0x28]
    // 0x897c84: LeaveFrame
    //     0x897c84: mov             SP, fp
    //     0x897c88: ldp             fp, lr, [SP], #0x10
    // 0x897c8c: ret
    //     0x897c8c: ret             
    // 0x897c90: mov             x0, x3
    // 0x897c94: r0 = ConcurrentModificationError()
    //     0x897c94: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x897c98: mov             x1, x0
    // 0x897c9c: ldur            x0, [fp, #-0x68]
    // 0x897ca0: StoreField: r1->field_b = r0
    //     0x897ca0: stur            w0, [x1, #0xb]
    // 0x897ca4: mov             x0, x1
    // 0x897ca8: r0 = Throw()
    //     0x897ca8: bl              #0x13ddb2c  ; ThrowStub
    // 0x897cac: brk             #0
    // 0x897cb0: mov             x0, x3
    // 0x897cb4: r0 = ConcurrentModificationError()
    //     0x897cb4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x897cb8: mov             x1, x0
    // 0x897cbc: ldur            x0, [fp, #-0x40]
    // 0x897cc0: StoreField: r1->field_b = r0
    //     0x897cc0: stur            w0, [x1, #0xb]
    // 0x897cc4: mov             x0, x1
    // 0x897cc8: r0 = Throw()
    //     0x897cc8: bl              #0x13ddb2c  ; ThrowStub
    // 0x897ccc: brk             #0
    // 0x897cd0: mov             x0, x1
    // 0x897cd4: r0 = ConcurrentModificationError()
    //     0x897cd4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x897cd8: mov             x1, x0
    // 0x897cdc: ldur            x0, [fp, #-0x18]
    // 0x897ce0: StoreField: r1->field_b = r0
    //     0x897ce0: stur            w0, [x1, #0xb]
    // 0x897ce4: mov             x0, x1
    // 0x897ce8: r0 = Throw()
    //     0x897ce8: bl              #0x13ddb2c  ; ThrowStub
    // 0x897cec: brk             #0
    // 0x897cf0: mov             x0, x1
    // 0x897cf4: r0 = ConcurrentModificationError()
    //     0x897cf4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x897cf8: mov             x1, x0
    // 0x897cfc: ldur            x0, [fp, #-0x58]
    // 0x897d00: StoreField: r1->field_b = r0
    //     0x897d00: stur            w0, [x1, #0xb]
    // 0x897d04: mov             x0, x1
    // 0x897d08: r0 = Throw()
    //     0x897d08: bl              #0x13ddb2c  ; ThrowStub
    // 0x897d0c: brk             #0
    // 0x897d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897d10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897d14: b               #0x8974ac
    // 0x897d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897d18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897d1c: b               #0x897664
    // 0x897d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897d20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897d24: b               #0x897738
    // 0x897d28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x897d28: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x897d2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x897d2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x897d30: r0 = NullErrorSharedWithoutFPURegs()
    //     0x897d30: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0x897d34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897d34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897d38: b               #0x8979ec
    // 0x897d3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897d3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897d40: b               #0x897b9c
  }
  _ _getNonBlockedChildren(/* No info */) {
    // ** addr: 0x897d44, size: 0xa4
    // 0x897d44: EnterFrame
    //     0x897d44: stp             fp, lr, [SP, #-0x10]!
    //     0x897d48: mov             fp, SP
    // 0x897d4c: AllocStack(0x18)
    //     0x897d4c: sub             SP, SP, #0x18
    // 0x897d50: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x8 */)
    //     0x897d50: mov             x0, x1
    //     0x897d54: stur            x1, [fp, #-8]
    // 0x897d58: CheckStackOverflow
    //     0x897d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x897d5c: cmp             SP, x16
    //     0x897d60: b.ls            #0x897de0
    // 0x897d64: r1 = <_RenderObjectSemantics>
    //     0x897d64: ldr             x1, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x897d68: r2 = 0
    //     0x897d68: mov             x2, #0
    // 0x897d6c: r0 = _GrowableList()
    //     0x897d6c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x897d70: stur            x0, [fp, #-0x10]
    // 0x897d74: r1 = 1
    //     0x897d74: mov             x1, #1
    // 0x897d78: r0 = AllocateContext()
    //     0x897d78: bl              #0x13de838  ; AllocateContextStub
    // 0x897d7c: mov             x1, x0
    // 0x897d80: ldur            x0, [fp, #-0x10]
    // 0x897d84: StoreField: r1->field_f = r0
    //     0x897d84: stur            w0, [x1, #0xf]
    // 0x897d88: ldur            x2, [fp, #-8]
    // 0x897d8c: LoadField: r3 = r2->field_7
    //     0x897d8c: ldur            w3, [x2, #7]
    // 0x897d90: DecompressPointer r3
    //     0x897d90: add             x3, x3, HEAP, lsl #32
    // 0x897d94: mov             x2, x1
    // 0x897d98: stur            x3, [fp, #-0x18]
    // 0x897d9c: r1 = Function '<anonymous closure>':.
    //     0x897d9c: ldr             x1, [PP, #0x2bb8]  ; [pp+0x2bb8] AnonymousClosure: (0x897de8), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_getNonBlockedChildren (0x897d44)
    // 0x897da0: r0 = AllocateClosure()
    //     0x897da0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x897da4: ldur            x1, [fp, #-0x18]
    // 0x897da8: r2 = LoadClassIdInstr(r1)
    //     0x897da8: ldur            x2, [x1, #-1]
    //     0x897dac: ubfx            x2, x2, #0xc, #0x14
    // 0x897db0: mov             x16, x0
    // 0x897db4: mov             x0, x2
    // 0x897db8: mov             x2, x16
    // 0x897dbc: r0 = GDT[cid_x0 + 0x110e3]()
    //     0x897dbc: mov             x17, #0x10e3
    //     0x897dc0: movk            x17, #1, lsl #16
    //     0x897dc4: add             lr, x0, x17
    //     0x897dc8: ldr             lr, [x21, lr, lsl #3]
    //     0x897dcc: blr             lr
    // 0x897dd0: ldur            x0, [fp, #-0x10]
    // 0x897dd4: LeaveFrame
    //     0x897dd4: mov             SP, fp
    //     0x897dd8: ldp             fp, lr, [SP], #0x10
    // 0x897ddc: ret
    //     0x897ddc: ret             
    // 0x897de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897de0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897de4: b               #0x897d64
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x897de8, size: 0x110
    // 0x897de8: EnterFrame
    //     0x897de8: stp             fp, lr, [SP, #-0x10]!
    //     0x897dec: mov             fp, SP
    // 0x897df0: AllocStack(0x18)
    //     0x897df0: sub             SP, SP, #0x18
    // 0x897df4: SetupParameters([dynamic _ /* r0 */])
    //     0x897df4: ldr             x0, [fp, #0x18]
    //     0x897df8: ldur            w2, [x0, #0x17]
    //     0x897dfc: add             x2, x2, HEAP, lsl #32
    //     0x897e00: stur            x2, [fp, #-8]
    // 0x897e04: CheckStackOverflow
    //     0x897e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x897e08: cmp             SP, x16
    //     0x897e0c: b.ls            #0x897ef0
    // 0x897e10: ldr             x1, [fp, #0x10]
    // 0x897e14: LoadField: r0 = r1->field_43
    //     0x897e14: ldur            w0, [x1, #0x43]
    // 0x897e18: DecompressPointer r0
    //     0x897e18: add             x0, x0, HEAP, lsl #32
    // 0x897e1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x897e20: cmp             w0, w16
    // 0x897e24: b.ne            #0x897e30
    // 0x897e28: r2 = _semantics
    //     0x897e28: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x897e2c: r0 = InitLateFinalInstanceField()
    //     0x897e2c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x897e30: mov             x1, x0
    // 0x897e34: r0 = isBlockingPreviousSibling()
    //     0x897e34: bl              #0x897ef8  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isBlockingPreviousSibling
    // 0x897e38: tbnz            w0, #4, #0x897e4c
    // 0x897e3c: ldur            x0, [fp, #-8]
    // 0x897e40: LoadField: r1 = r0->field_f
    //     0x897e40: ldur            w1, [x0, #0xf]
    // 0x897e44: DecompressPointer r1
    //     0x897e44: add             x1, x1, HEAP, lsl #32
    // 0x897e48: r0 = clear()
    //     0x897e48: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x897e4c: ldr             x1, [fp, #0x10]
    // 0x897e50: ldur            x0, [fp, #-8]
    // 0x897e54: LoadField: r2 = r0->field_f
    //     0x897e54: ldur            w2, [x0, #0xf]
    // 0x897e58: DecompressPointer r2
    //     0x897e58: add             x2, x2, HEAP, lsl #32
    // 0x897e5c: stur            x2, [fp, #-0x18]
    // 0x897e60: LoadField: r0 = r1->field_43
    //     0x897e60: ldur            w0, [x1, #0x43]
    // 0x897e64: DecompressPointer r0
    //     0x897e64: add             x0, x0, HEAP, lsl #32
    // 0x897e68: stur            x0, [fp, #-8]
    // 0x897e6c: LoadField: r1 = r2->field_b
    //     0x897e6c: ldur            w1, [x2, #0xb]
    // 0x897e70: LoadField: r3 = r2->field_f
    //     0x897e70: ldur            w3, [x2, #0xf]
    // 0x897e74: DecompressPointer r3
    //     0x897e74: add             x3, x3, HEAP, lsl #32
    // 0x897e78: LoadField: r4 = r3->field_b
    //     0x897e78: ldur            w4, [x3, #0xb]
    // 0x897e7c: r3 = LoadInt32Instr(r1)
    //     0x897e7c: sbfx            x3, x1, #1, #0x1f
    // 0x897e80: stur            x3, [fp, #-0x10]
    // 0x897e84: r1 = LoadInt32Instr(r4)
    //     0x897e84: sbfx            x1, x4, #1, #0x1f
    // 0x897e88: cmp             x3, x1
    // 0x897e8c: b.ne            #0x897e98
    // 0x897e90: mov             x1, x2
    // 0x897e94: r0 = _growToNextCapacity()
    //     0x897e94: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x897e98: ldur            x2, [fp, #-0x18]
    // 0x897e9c: ldur            x3, [fp, #-0x10]
    // 0x897ea0: add             x4, x3, #1
    // 0x897ea4: lsl             x5, x4, #1
    // 0x897ea8: StoreField: r2->field_b = r5
    //     0x897ea8: stur            w5, [x2, #0xb]
    // 0x897eac: LoadField: r1 = r2->field_f
    //     0x897eac: ldur            w1, [x2, #0xf]
    // 0x897eb0: DecompressPointer r1
    //     0x897eb0: add             x1, x1, HEAP, lsl #32
    // 0x897eb4: ldur            x0, [fp, #-8]
    // 0x897eb8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x897eb8: add             x25, x1, x3, lsl #2
    //     0x897ebc: add             x25, x25, #0xf
    //     0x897ec0: str             w0, [x25]
    //     0x897ec4: tbz             w0, #0, #0x897ee0
    //     0x897ec8: ldurb           w16, [x1, #-1]
    //     0x897ecc: ldurb           w17, [x0, #-1]
    //     0x897ed0: and             x16, x17, x16, lsr #2
    //     0x897ed4: tst             x16, HEAP, lsr #32
    //     0x897ed8: b.eq            #0x897ee0
    //     0x897edc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x897ee0: r0 = Null
    //     0x897ee0: mov             x0, NULL
    // 0x897ee4: LeaveFrame
    //     0x897ee4: mov             SP, fp
    //     0x897ee8: ldp             fp, lr, [SP], #0x10
    // 0x897eec: ret
    //     0x897eec: ret             
    // 0x897ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x897ef0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x897ef4: b               #0x897e10
  }
  get _ isBlockingPreviousSibling(/* No info */) {
    // ** addr: 0x897ef8, size: 0x150
    // 0x897ef8: EnterFrame
    //     0x897ef8: stp             fp, lr, [SP, #-0x10]!
    //     0x897efc: mov             fp, SP
    // 0x897f00: AllocStack(0x18)
    //     0x897f00: sub             SP, SP, #0x18
    // 0x897f04: SetupParameters(_RenderObjectSemantics this /* r1 => r1, fp-0x8 */)
    //     0x897f04: stur            x1, [fp, #-8]
    // 0x897f08: CheckStackOverflow
    //     0x897f08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x897f0c: cmp             SP, x16
    //     0x897f10: b.ls            #0x89803c
    // 0x897f14: r1 = 1
    //     0x897f14: mov             x1, #1
    // 0x897f18: r0 = AllocateContext()
    //     0x897f18: bl              #0x13de838  ; AllocateContextStub
    // 0x897f1c: mov             x2, x0
    // 0x897f20: ldur            x0, [fp, #-8]
    // 0x897f24: stur            x2, [fp, #-0x18]
    // 0x897f28: StoreField: r2->field_f = r0
    //     0x897f28: stur            w0, [x2, #0xf]
    // 0x897f2c: LoadField: r1 = r0->field_f
    //     0x897f2c: ldur            w1, [x0, #0xf]
    // 0x897f30: DecompressPointer r1
    //     0x897f30: add             x1, x1, HEAP, lsl #32
    // 0x897f34: cmp             w1, NULL
    // 0x897f38: b.eq            #0x897f4c
    // 0x897f3c: mov             x0, x1
    // 0x897f40: LeaveFrame
    //     0x897f40: mov             SP, fp
    //     0x897f44: ldp             fp, lr, [SP], #0x10
    // 0x897f48: ret
    //     0x897f48: ret             
    // 0x897f4c: LoadField: r3 = r0->field_3b
    //     0x897f4c: ldur            w3, [x0, #0x3b]
    // 0x897f50: DecompressPointer r3
    //     0x897f50: add             x3, x3, HEAP, lsl #32
    // 0x897f54: stur            x3, [fp, #-0x10]
    // 0x897f58: LoadField: r1 = r3->field_13
    //     0x897f58: ldur            w1, [x3, #0x13]
    // 0x897f5c: DecompressPointer r1
    //     0x897f5c: add             x1, x1, HEAP, lsl #32
    // 0x897f60: cmp             w1, NULL
    // 0x897f64: b.ne            #0x897f74
    // 0x897f68: mov             x1, x3
    // 0x897f6c: r0 = original()
    //     0x897f6c: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x897f70: mov             x1, x0
    // 0x897f74: ldur            x0, [fp, #-8]
    // 0x897f78: LoadField: r2 = r1->field_1b
    //     0x897f78: ldur            w2, [x1, #0x1b]
    // 0x897f7c: DecompressPointer r2
    //     0x897f7c: add             x2, x2, HEAP, lsl #32
    // 0x897f80: StoreField: r0->field_f = r2
    //     0x897f80: stur            w2, [x0, #0xf]
    // 0x897f84: tbnz            w2, #4, #0x897f98
    // 0x897f88: r0 = true
    //     0x897f88: add             x0, NULL, #0x20  ; true
    // 0x897f8c: LeaveFrame
    //     0x897f8c: mov             SP, fp
    //     0x897f90: ldp             fp, lr, [SP], #0x10
    // 0x897f94: ret
    //     0x897f94: ret             
    // 0x897f98: ldur            x1, [fp, #-0x10]
    // 0x897f9c: LoadField: r2 = r1->field_13
    //     0x897f9c: ldur            w2, [x1, #0x13]
    // 0x897fa0: DecompressPointer r2
    //     0x897fa0: add             x2, x2, HEAP, lsl #32
    // 0x897fa4: cmp             w2, NULL
    // 0x897fa8: b.ne            #0x897fb4
    // 0x897fac: r0 = original()
    //     0x897fac: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x897fb0: b               #0x897fb8
    // 0x897fb4: mov             x0, x2
    // 0x897fb8: LoadField: r1 = r0->field_7
    //     0x897fb8: ldur            w1, [x0, #7]
    // 0x897fbc: DecompressPointer r1
    //     0x897fbc: add             x1, x1, HEAP, lsl #32
    // 0x897fc0: tbnz            w1, #4, #0x897fd4
    // 0x897fc4: r0 = false
    //     0x897fc4: add             x0, NULL, #0x30  ; false
    // 0x897fc8: LeaveFrame
    //     0x897fc8: mov             SP, fp
    //     0x897fcc: ldp             fp, lr, [SP], #0x10
    // 0x897fd0: ret
    //     0x897fd0: ret             
    // 0x897fd4: ldur            x0, [fp, #-8]
    // 0x897fd8: LoadField: r3 = r0->field_7
    //     0x897fd8: ldur            w3, [x0, #7]
    // 0x897fdc: DecompressPointer r3
    //     0x897fdc: add             x3, x3, HEAP, lsl #32
    // 0x897fe0: ldur            x2, [fp, #-0x18]
    // 0x897fe4: stur            x3, [fp, #-0x10]
    // 0x897fe8: r1 = Function '<anonymous closure>':.
    //     0x897fe8: ldr             x1, [PP, #0x2bc0]  ; [pp+0x2bc0] AnonymousClosure: (0x898048), in [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isBlockingPreviousSibling (0x897ef8)
    // 0x897fec: r0 = AllocateClosure()
    //     0x897fec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x897ff0: ldur            x1, [fp, #-0x10]
    // 0x897ff4: r2 = LoadClassIdInstr(r1)
    //     0x897ff4: ldur            x2, [x1, #-1]
    //     0x897ff8: ubfx            x2, x2, #0xc, #0x14
    // 0x897ffc: mov             x16, x0
    // 0x898000: mov             x0, x2
    // 0x898004: mov             x2, x16
    // 0x898008: r0 = GDT[cid_x0 + 0x110e3]()
    //     0x898008: mov             x17, #0x10e3
    //     0x89800c: movk            x17, #1, lsl #16
    //     0x898010: add             lr, x0, x17
    //     0x898014: ldr             lr, [x21, lr, lsl #3]
    //     0x898018: blr             lr
    // 0x89801c: ldur            x1, [fp, #-8]
    // 0x898020: LoadField: r0 = r1->field_f
    //     0x898020: ldur            w0, [x1, #0xf]
    // 0x898024: DecompressPointer r0
    //     0x898024: add             x0, x0, HEAP, lsl #32
    // 0x898028: cmp             w0, NULL
    // 0x89802c: b.eq            #0x898044
    // 0x898030: LeaveFrame
    //     0x898030: mov             SP, fp
    //     0x898034: ldp             fp, lr, [SP], #0x10
    // 0x898038: ret
    //     0x898038: ret             
    // 0x89803c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89803c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898040: b               #0x897f14
    // 0x898044: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x898044: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x898048, size: 0x80
    // 0x898048: EnterFrame
    //     0x898048: stp             fp, lr, [SP, #-0x10]!
    //     0x89804c: mov             fp, SP
    // 0x898050: AllocStack(0x8)
    //     0x898050: sub             SP, SP, #8
    // 0x898054: SetupParameters([dynamic _ /* r0 */])
    //     0x898054: ldr             x0, [fp, #0x18]
    //     0x898058: ldur            w2, [x0, #0x17]
    //     0x89805c: add             x2, x2, HEAP, lsl #32
    //     0x898060: stur            x2, [fp, #-8]
    // 0x898064: CheckStackOverflow
    //     0x898064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x898068: cmp             SP, x16
    //     0x89806c: b.ls            #0x8980c0
    // 0x898070: ldr             x1, [fp, #0x10]
    // 0x898074: LoadField: r0 = r1->field_43
    //     0x898074: ldur            w0, [x1, #0x43]
    // 0x898078: DecompressPointer r0
    //     0x898078: add             x0, x0, HEAP, lsl #32
    // 0x89807c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x898080: cmp             w0, w16
    // 0x898084: b.ne            #0x898090
    // 0x898088: r2 = _semantics
    //     0x898088: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x89808c: r0 = InitLateFinalInstanceField()
    //     0x89808c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x898090: mov             x1, x0
    // 0x898094: r0 = isBlockingPreviousSibling()
    //     0x898094: bl              #0x897ef8  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isBlockingPreviousSibling
    // 0x898098: tbnz            w0, #4, #0x8980b0
    // 0x89809c: ldur            x1, [fp, #-8]
    // 0x8980a0: r2 = true
    //     0x8980a0: add             x2, NULL, #0x20  ; true
    // 0x8980a4: LoadField: r3 = r1->field_f
    //     0x8980a4: ldur            w3, [x1, #0xf]
    // 0x8980a8: DecompressPointer r3
    //     0x8980a8: add             x3, x3, HEAP, lsl #32
    // 0x8980ac: StoreField: r3->field_f = r2
    //     0x8980ac: stur            w2, [x3, #0xf]
    // 0x8980b0: r0 = Null
    //     0x8980b0: mov             x0, NULL
    // 0x8980b4: LeaveFrame
    //     0x8980b4: mov             SP, fp
    //     0x8980b8: ldp             fp, lr, [SP], #0x10
    // 0x8980bc: ret
    //     0x8980bc: ret             
    // 0x8980c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8980c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8980c4: b               #0x898070
  }
  [closure] _SemanticsFragment <anonymous closure>(dynamic, SemanticsConfiguration) {
    // ** addr: 0x8980c8, size: 0xbc
    // 0x8980c8: EnterFrame
    //     0x8980c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8980cc: mov             fp, SP
    // 0x8980d0: AllocStack(0x10)
    //     0x8980d0: sub             SP, SP, #0x10
    // 0x8980d4: SetupParameters([dynamic _ /* r0 */])
    //     0x8980d4: ldr             x0, [fp, #0x18]
    //     0x8980d8: ldur            w3, [x0, #0x17]
    //     0x8980dc: add             x3, x3, HEAP, lsl #32
    //     0x8980e0: stur            x3, [fp, #-0x10]
    // 0x8980e4: CheckStackOverflow
    //     0x8980e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8980e8: cmp             SP, x16
    //     0x8980ec: b.ls            #0x89817c
    // 0x8980f0: LoadField: r0 = r3->field_13
    //     0x8980f0: ldur            w0, [x3, #0x13]
    // 0x8980f4: DecompressPointer r0
    //     0x8980f4: add             x0, x0, HEAP, lsl #32
    // 0x8980f8: mov             x1, x0
    // 0x8980fc: ldr             x2, [fp, #0x10]
    // 0x898100: stur            x0, [fp, #-8]
    // 0x898104: r0 = _getValueOrData()
    //     0x898104: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x898108: mov             x1, x0
    // 0x89810c: ldur            x0, [fp, #-8]
    // 0x898110: LoadField: r2 = r0->field_f
    //     0x898110: ldur            w2, [x0, #0xf]
    // 0x898114: DecompressPointer r2
    //     0x898114: add             x2, x2, HEAP, lsl #32
    // 0x898118: cmp             w2, w1
    // 0x89811c: b.ne            #0x898128
    // 0x898120: r0 = Null
    //     0x898120: mov             x0, NULL
    // 0x898124: b               #0x89812c
    // 0x898128: mov             x0, x1
    // 0x89812c: cmp             w0, NULL
    // 0x898130: b.eq            #0x898140
    // 0x898134: LeaveFrame
    //     0x898134: mov             SP, fp
    //     0x898138: ldp             fp, lr, [SP], #0x10
    // 0x89813c: ret
    //     0x89813c: ret             
    // 0x898140: ldr             x2, [fp, #0x10]
    // 0x898144: ldur            x0, [fp, #-0x10]
    // 0x898148: r1 = true
    //     0x898148: add             x1, NULL, #0x20  ; true
    // 0x89814c: LoadField: r3 = r0->field_f
    //     0x89814c: ldur            w3, [x0, #0xf]
    // 0x898150: DecompressPointer r3
    //     0x898150: add             x3, x3, HEAP, lsl #32
    // 0x898154: stur            x3, [fp, #-8]
    // 0x898158: StoreField: r3->field_13 = r1
    //     0x898158: stur            w1, [x3, #0x13]
    // 0x89815c: r0 = _IncompleteSemanticsFragment()
    //     0x89815c: bl              #0x898184  ; Allocate_IncompleteSemanticsFragmentStub -> _IncompleteSemanticsFragment (size=0x10)
    // 0x898160: ldr             x1, [fp, #0x10]
    // 0x898164: StoreField: r0->field_7 = r1
    //     0x898164: stur            w1, [x0, #7]
    // 0x898168: ldur            x1, [fp, #-8]
    // 0x89816c: StoreField: r0->field_b = r1
    //     0x89816c: stur            w1, [x0, #0xb]
    // 0x898170: LeaveFrame
    //     0x898170: mov             SP, fp
    //     0x898174: ldp             fp, lr, [SP], #0x10
    // 0x898178: ret
    //     0x898178: ret             
    // 0x89817c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89817c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898180: b               #0x8980f0
  }
  _ _getTagsForChildren(/* No info */) {
    // ** addr: 0x8981a8, size: 0x120
    // 0x8981a8: EnterFrame
    //     0x8981a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8981ac: mov             fp, SP
    // 0x8981b0: AllocStack(0x10)
    //     0x8981b0: sub             SP, SP, #0x10
    // 0x8981b4: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x8 */)
    //     0x8981b4: mov             x0, x1
    //     0x8981b8: stur            x1, [fp, #-8]
    // 0x8981bc: CheckStackOverflow
    //     0x8981bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8981c0: cmp             SP, x16
    //     0x8981c4: b.ls            #0x8982bc
    // 0x8981c8: mov             x1, x0
    // 0x8981cc: r0 = contributesToSemanticsTree()
    //     0x8981cc: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x8981d0: tbnz            w0, #4, #0x89820c
    // 0x8981d4: ldur            x0, [fp, #-8]
    // 0x8981d8: LoadField: r1 = r0->field_3b
    //     0x8981d8: ldur            w1, [x0, #0x3b]
    // 0x8981dc: DecompressPointer r1
    //     0x8981dc: add             x1, x1, HEAP, lsl #32
    // 0x8981e0: r0 = original()
    //     0x8981e0: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x8981e4: LoadField: r1 = r0->field_bf
    //     0x8981e4: ldur            w1, [x0, #0xbf]
    // 0x8981e8: DecompressPointer r1
    //     0x8981e8: add             x1, x1, HEAP, lsl #32
    // 0x8981ec: cmp             w1, NULL
    // 0x8981f0: b.ne            #0x8981fc
    // 0x8981f4: r0 = Null
    //     0x8981f4: mov             x0, NULL
    // 0x8981f8: b               #0x898200
    // 0x8981fc: r0 = toSet()
    //     0x8981fc: bl              #0xba6270  ; [dart:_compact_hash] _Set::toSet
    // 0x898200: LeaveFrame
    //     0x898200: mov             SP, fp
    //     0x898204: ldp             fp, lr, [SP], #0x10
    // 0x898208: ret
    //     0x898208: ret             
    // 0x89820c: ldur            x0, [fp, #-8]
    // 0x898210: LoadField: r2 = r0->field_3b
    //     0x898210: ldur            w2, [x0, #0x3b]
    // 0x898214: DecompressPointer r2
    //     0x898214: add             x2, x2, HEAP, lsl #32
    // 0x898218: mov             x1, x2
    // 0x89821c: stur            x2, [fp, #-0x10]
    // 0x898220: r0 = original()
    //     0x898220: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x898224: LoadField: r1 = r0->field_bf
    //     0x898224: ldur            w1, [x0, #0xbf]
    // 0x898228: DecompressPointer r1
    //     0x898228: add             x1, x1, HEAP, lsl #32
    // 0x89822c: cmp             w1, NULL
    // 0x898230: b.eq            #0x898258
    // 0x898234: ldur            x1, [fp, #-0x10]
    // 0x898238: r0 = original()
    //     0x898238: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x89823c: LoadField: r1 = r0->field_bf
    //     0x89823c: ldur            w1, [x0, #0xbf]
    // 0x898240: DecompressPointer r1
    //     0x898240: add             x1, x1, HEAP, lsl #32
    // 0x898244: cmp             w1, NULL
    // 0x898248: b.eq            #0x8982c4
    // 0x89824c: r0 = toSet()
    //     0x89824c: bl              #0xba6270  ; [dart:_compact_hash] _Set::toSet
    // 0x898250: mov             x3, x0
    // 0x898254: b               #0x89825c
    // 0x898258: r3 = Null
    //     0x898258: mov             x3, NULL
    // 0x89825c: ldur            x0, [fp, #-8]
    // 0x898260: stur            x3, [fp, #-0x10]
    // 0x898264: LoadField: r1 = r0->field_33
    //     0x898264: ldur            w1, [x0, #0x33]
    // 0x898268: DecompressPointer r1
    //     0x898268: add             x1, x1, HEAP, lsl #32
    // 0x89826c: cmp             w1, NULL
    // 0x898270: b.eq            #0x8982ac
    // 0x898274: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x898274: ldur            w0, [x1, #0x17]
    // 0x898278: DecompressPointer r0
    //     0x898278: add             x0, x0, HEAP, lsl #32
    // 0x89827c: cmp             w0, NULL
    // 0x898280: b.eq            #0x8982ac
    // 0x898284: cmp             w3, NULL
    // 0x898288: b.ne            #0x898294
    // 0x89828c: mov             x1, x0
    // 0x898290: b               #0x8982a4
    // 0x898294: mov             x1, x3
    // 0x898298: mov             x2, x0
    // 0x89829c: r0 = addAll()
    //     0x89829c: bl              #0x11850e8  ; [dart:_compact_hash] _Set::addAll
    // 0x8982a0: ldur            x1, [fp, #-0x10]
    // 0x8982a4: mov             x0, x1
    // 0x8982a8: b               #0x8982b0
    // 0x8982ac: ldur            x0, [fp, #-0x10]
    // 0x8982b0: LeaveFrame
    //     0x8982b0: mov             SP, fp
    //     0x8982b4: ldp             fp, lr, [SP], #0x10
    // 0x8982b8: ret
    //     0x8982b8: ret             
    // 0x8982bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8982bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8982c0: b               #0x8981c8
    // 0x8982c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8982c4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, SemanticsConfiguration) {
    // ** addr: 0x898330, size: 0x44
    // 0x898330: ldr             x1, [SP, #8]
    // 0x898334: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x898334: ldur            w2, [x1, #0x17]
    // 0x898338: DecompressPointer r2
    //     0x898338: add             x2, x2, HEAP, lsl #32
    // 0x89833c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x89833c: ldur            w0, [x2, #0x17]
    // 0x898340: DecompressPointer r0
    //     0x898340: add             x0, x0, HEAP, lsl #32
    // 0x898344: ldr             x1, [SP]
    // 0x898348: StoreField: r1->field_f = r0
    //     0x898348: stur            w0, [x1, #0xf]
    //     0x89834c: ldurb           w16, [x1, #-1]
    //     0x898350: ldurb           w17, [x0, #-1]
    //     0x898354: and             x16, x17, x16, lsr #2
    //     0x898358: tst             x16, HEAP, lsr #32
    //     0x89835c: b.eq            #0x89836c
    //     0x898360: str             lr, [SP, #-8]!
    //     0x898364: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0x898368: ldr             lr, [SP], #8
    // 0x89836c: r0 = Null
    //     0x89836c: mov             x0, NULL
    // 0x898370: ret
    //     0x898370: ret             
  }
  [closure] void <anonymous closure>(dynamic, SemanticsConfiguration) {
    // ** addr: 0x898374, size: 0x24
    // 0x898374: ldr             x1, [SP, #8]
    // 0x898378: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x898378: ldur            w2, [x1, #0x17]
    // 0x89837c: DecompressPointer r2
    //     0x89837c: add             x2, x2, HEAP, lsl #32
    // 0x898380: LoadField: r1 = r2->field_f
    //     0x898380: ldur            w1, [x2, #0xf]
    // 0x898384: DecompressPointer r1
    //     0x898384: add             x1, x1, HEAP, lsl #32
    // 0x898388: ldr             x2, [SP]
    // 0x89838c: StoreField: r2->field_13 = r1
    //     0x89838c: stur            w1, [x2, #0x13]
    // 0x898390: r0 = Null
    //     0x898390: mov             x0, NULL
    // 0x898394: ret
    //     0x898394: ret             
  }
  [closure] void <anonymous closure>(dynamic, SemanticsConfiguration) {
    // ** addr: 0x898398, size: 0x48
    // 0x898398: EnterFrame
    //     0x898398: stp             fp, lr, [SP, #-0x10]!
    //     0x89839c: mov             fp, SP
    // 0x8983a0: ldr             x0, [fp, #0x18]
    // 0x8983a4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8983a4: ldur            w1, [x0, #0x17]
    // 0x8983a8: DecompressPointer r1
    //     0x8983a8: add             x1, x1, HEAP, lsl #32
    // 0x8983ac: CheckStackOverflow
    //     0x8983ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8983b0: cmp             SP, x16
    //     0x8983b4: b.ls            #0x8983d8
    // 0x8983b8: LoadField: r2 = r1->field_13
    //     0x8983b8: ldur            w2, [x1, #0x13]
    // 0x8983bc: DecompressPointer r2
    //     0x8983bc: add             x2, x2, HEAP, lsl #32
    // 0x8983c0: ldr             x1, [fp, #0x10]
    // 0x8983c4: r0 = accessibilityFocusBlockType=()
    //     0x8983c4: bl              #0x8983e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::accessibilityFocusBlockType=
    // 0x8983c8: r0 = Null
    //     0x8983c8: mov             x0, NULL
    // 0x8983cc: LeaveFrame
    //     0x8983cc: mov             SP, fp
    //     0x8983d0: ldp             fp, lr, [SP], #0x10
    // 0x8983d4: ret
    //     0x8983d4: ret             
    // 0x8983d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8983d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8983dc: b               #0x8983b8
  }
  [closure] void <anonymous closure>(dynamic, SemanticsConfiguration) {
    // ** addr: 0x898494, size: 0x60
    // 0x898494: EnterFrame
    //     0x898494: stp             fp, lr, [SP, #-0x10]!
    //     0x898498: mov             fp, SP
    // 0x89849c: AllocStack(0x8)
    //     0x89849c: sub             SP, SP, #8
    // 0x8984a0: SetupParameters([dynamic _ /* r0 */])
    //     0x8984a0: ldr             x0, [fp, #0x18]
    //     0x8984a4: ldur            w1, [x0, #0x17]
    //     0x8984a8: add             x1, x1, HEAP, lsl #32
    // 0x8984ac: CheckStackOverflow
    //     0x8984ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8984b0: cmp             SP, x16
    //     0x8984b4: b.ls            #0x8984ec
    // 0x8984b8: LoadField: r0 = r1->field_1b
    //     0x8984b8: ldur            w0, [x1, #0x1b]
    // 0x8984bc: DecompressPointer r0
    //     0x8984bc: add             x0, x0, HEAP, lsl #32
    // 0x8984c0: ldr             x2, [fp, #0x10]
    // 0x8984c4: stur            x0, [fp, #-8]
    // 0x8984c8: r1 = Function 'addTagForChildren':.
    //     0x8984c8: ldr             x1, [PP, #0x2b48]  ; [pp+0x2b48] AnonymousClosure: (0x8984f4), in [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::addTagForChildren (0x898530)
    // 0x8984cc: r0 = AllocateClosure()
    //     0x8984cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x8984d0: ldur            x1, [fp, #-8]
    // 0x8984d4: mov             x2, x0
    // 0x8984d8: r0 = forEach()
    //     0x8984d8: bl              #0xb9bccc  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::forEach
    // 0x8984dc: r0 = Null
    //     0x8984dc: mov             x0, NULL
    // 0x8984e0: LeaveFrame
    //     0x8984e0: mov             SP, fp
    //     0x8984e4: ldp             fp, lr, [SP], #0x10
    // 0x8984e8: ret
    //     0x8984e8: ret             
    // 0x8984ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8984ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8984f0: b               #0x8984b8
  }
  [closure] SemanticsConfiguration? <anonymous closure>(dynamic, _SemanticsFragment) {
    // ** addr: 0x8985d0, size: 0x94
    // 0x8985d0: EnterFrame
    //     0x8985d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8985d4: mov             fp, SP
    // 0x8985d8: CheckStackOverflow
    //     0x8985d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8985dc: cmp             SP, x16
    //     0x8985e0: b.ls            #0x89865c
    // 0x8985e4: ldr             x0, [fp, #0x10]
    // 0x8985e8: r1 = LoadClassIdInstr(r0)
    //     0x8985e8: ldur            x1, [x0, #-1]
    //     0x8985ec: ubfx            x1, x1, #0xc, #0x14
    // 0x8985f0: r17 = 4215
    //     0x8985f0: mov             x17, #0x1077
    // 0x8985f4: cmp             x1, x17
    // 0x8985f8: b.ne            #0x89860c
    // 0x8985fc: LoadField: r1 = r0->field_7
    //     0x8985fc: ldur            w1, [x0, #7]
    // 0x898600: DecompressPointer r1
    //     0x898600: add             x1, x1, HEAP, lsl #32
    // 0x898604: mov             x0, x1
    // 0x898608: b               #0x898650
    // 0x89860c: mov             x1, x0
    // 0x898610: r0 = shouldFormSemanticsNode()
    //     0x898610: bl              #0x895ca4  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::shouldFormSemanticsNode
    // 0x898614: tbnz            w0, #4, #0x898620
    // 0x898618: r1 = Null
    //     0x898618: mov             x1, NULL
    // 0x89861c: b               #0x89864c
    // 0x898620: ldr             x0, [fp, #0x10]
    // 0x898624: LoadField: r1 = r0->field_3b
    //     0x898624: ldur            w1, [x0, #0x3b]
    // 0x898628: DecompressPointer r1
    //     0x898628: add             x1, x1, HEAP, lsl #32
    // 0x89862c: LoadField: r0 = r1->field_13
    //     0x89862c: ldur            w0, [x1, #0x13]
    // 0x898630: DecompressPointer r0
    //     0x898630: add             x0, x0, HEAP, lsl #32
    // 0x898634: cmp             w0, NULL
    // 0x898638: b.ne            #0x898648
    // 0x89863c: r0 = original()
    //     0x89863c: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x898640: mov             x1, x0
    // 0x898644: b               #0x89864c
    // 0x898648: mov             x1, x0
    // 0x89864c: mov             x0, x1
    // 0x898650: LeaveFrame
    //     0x898650: mov             SP, fp
    //     0x898654: ldp             fp, lr, [SP], #0x10
    // 0x898658: ret
    //     0x898658: ret             
    // 0x89865c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89865c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x898660: b               #0x8985e4
  }
  _ clear(/* No info */) {
    // ** addr: 0xcd0680, size: 0xa0
    // 0xcd0680: EnterFrame
    //     0xcd0680: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0684: mov             fp, SP
    // 0xcd0688: AllocStack(0x8)
    //     0xcd0688: sub             SP, SP, #8
    // 0xcd068c: r0 = false
    //     0xcd068c: add             x0, NULL, #0x30  ; false
    // 0xcd0690: mov             x2, x1
    // 0xcd0694: stur            x1, [fp, #-8]
    // 0xcd0698: CheckStackOverflow
    //     0xcd0698: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd069c: cmp             SP, x16
    //     0xcd06a0: b.ls            #0xcd0718
    // 0xcd06a4: ArrayStore: r2[0] = r0  ; List_4
    //     0xcd06a4: stur            w0, [x2, #0x17]
    // 0xcd06a8: StoreField: r2->field_1b = rNULL
    //     0xcd06a8: stur            NULL, [x2, #0x1b]
    // 0xcd06ac: StoreField: r2->field_33 = rNULL
    //     0xcd06ac: stur            NULL, [x2, #0x33]
    // 0xcd06b0: StoreField: r2->field_37 = rNULL
    //     0xcd06b0: stur            NULL, [x2, #0x37]
    // 0xcd06b4: StoreField: r2->field_f = rNULL
    //     0xcd06b4: stur            NULL, [x2, #0xf]
    // 0xcd06b8: StoreField: r2->field_13 = r0
    //     0xcd06b8: stur            w0, [x2, #0x13]
    // 0xcd06bc: LoadField: r1 = r2->field_23
    //     0xcd06bc: ldur            w1, [x2, #0x23]
    // 0xcd06c0: DecompressPointer r1
    //     0xcd06c0: add             x1, x1, HEAP, lsl #32
    // 0xcd06c4: r0 = clear()
    //     0xcd06c4: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xcd06c8: ldur            x0, [fp, #-8]
    // 0xcd06cc: LoadField: r1 = r0->field_2b
    //     0xcd06cc: ldur            w1, [x0, #0x2b]
    // 0xcd06d0: DecompressPointer r1
    //     0xcd06d0: add             x1, x1, HEAP, lsl #32
    // 0xcd06d4: r0 = clear()
    //     0xcd06d4: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xcd06d8: ldur            x0, [fp, #-8]
    // 0xcd06dc: LoadField: r1 = r0->field_27
    //     0xcd06dc: ldur            w1, [x0, #0x27]
    // 0xcd06e0: DecompressPointer r1
    //     0xcd06e0: add             x1, x1, HEAP, lsl #32
    // 0xcd06e4: r0 = clear()
    //     0xcd06e4: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xcd06e8: ldur            x0, [fp, #-8]
    // 0xcd06ec: LoadField: r1 = r0->field_1f
    //     0xcd06ec: ldur            w1, [x0, #0x1f]
    // 0xcd06f0: DecompressPointer r1
    //     0xcd06f0: add             x1, x1, HEAP, lsl #32
    // 0xcd06f4: r0 = clear()
    //     0xcd06f4: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0xcd06f8: ldur            x0, [fp, #-8]
    // 0xcd06fc: LoadField: r1 = r0->field_3b
    //     0xcd06fc: ldur            w1, [x0, #0x3b]
    // 0xcd0700: DecompressPointer r1
    //     0xcd0700: add             x1, x1, HEAP, lsl #32
    // 0xcd0704: r0 = clear()
    //     0xcd0704: bl              #0x839290  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::clear
    // 0xcd0708: r0 = Null
    //     0xcd0708: mov             x0, NULL
    // 0xcd070c: LeaveFrame
    //     0xcd070c: mov             SP, fp
    //     0xcd0710: ldp             fp, lr, [SP], #0x10
    // 0xcd0714: ret
    //     0xcd0714: ret             
    // 0xcd0718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0718: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd071c: b               #0xcd06a4
  }
  get _ configToMergeUp(/* No info */) {
    // ** addr: 0x12b6738, size: 0x78
    // 0x12b6738: EnterFrame
    //     0x12b6738: stp             fp, lr, [SP, #-0x10]!
    //     0x12b673c: mov             fp, SP
    // 0x12b6740: AllocStack(0x8)
    //     0x12b6740: sub             SP, SP, #8
    // 0x12b6744: SetupParameters(_RenderObjectSemantics this /* r1 => r0, fp-0x8 */)
    //     0x12b6744: mov             x0, x1
    //     0x12b6748: stur            x1, [fp, #-8]
    // 0x12b674c: CheckStackOverflow
    //     0x12b674c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12b6750: cmp             SP, x16
    //     0x12b6754: b.ls            #0x12b67a8
    // 0x12b6758: mov             x1, x0
    // 0x12b675c: r0 = shouldFormSemanticsNode()
    //     0x12b675c: bl              #0x895ca4  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::shouldFormSemanticsNode
    // 0x12b6760: tbnz            w0, #4, #0x12b676c
    // 0x12b6764: r0 = Null
    //     0x12b6764: mov             x0, NULL
    // 0x12b6768: b               #0x12b679c
    // 0x12b676c: ldur            x0, [fp, #-8]
    // 0x12b6770: LoadField: r1 = r0->field_3b
    //     0x12b6770: ldur            w1, [x0, #0x3b]
    // 0x12b6774: DecompressPointer r1
    //     0x12b6774: add             x1, x1, HEAP, lsl #32
    // 0x12b6778: LoadField: r0 = r1->field_13
    //     0x12b6778: ldur            w0, [x1, #0x13]
    // 0x12b677c: DecompressPointer r0
    //     0x12b677c: add             x0, x0, HEAP, lsl #32
    // 0x12b6780: cmp             w0, NULL
    // 0x12b6784: b.ne            #0x12b6794
    // 0x12b6788: r0 = original()
    //     0x12b6788: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0x12b678c: mov             x1, x0
    // 0x12b6790: b               #0x12b6798
    // 0x12b6794: mov             x1, x0
    // 0x12b6798: mov             x0, x1
    // 0x12b679c: LeaveFrame
    //     0x12b679c: mov             SP, fp
    //     0x12b67a0: ldp             fp, lr, [SP], #0x10
    // 0x12b67a4: ret
    //     0x12b67a4: ret             
    // 0x12b67a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12b67a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12b67ac: b               #0x12b6758
  }
  [closure] Set<SemanticsTag> <anonymous closure>(dynamic, Set<SemanticsTag>) {
    // ** addr: 0x13dae90, size: 0x8
    // 0x13dae90: ldr             x0, [SP]
    // 0x13dae94: ret
    //     0x13dae94: ret             
  }
}

// class id: 4668, size: 0x48, field offset: 0x8
class PipelineOwner extends _MixinApplication5&Object&DiagnosticableTreeMixin {

  _ requestVisualUpdate(/* No info */) {
    // ** addr: 0x837988, size: 0x44
    // 0x837988: EnterFrame
    //     0x837988: stp             fp, lr, [SP, #-0x10]!
    //     0x83798c: mov             fp, SP
    // 0x837990: CheckStackOverflow
    //     0x837990: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x837994: cmp             SP, x16
    //     0x837998: b.ls            #0x8379c4
    // 0x83799c: LoadField: r0 = r1->field_43
    //     0x83799c: ldur            w0, [x1, #0x43]
    // 0x8379a0: DecompressPointer r0
    //     0x8379a0: add             x0, x0, HEAP, lsl #32
    // 0x8379a4: cmp             w0, NULL
    // 0x8379a8: b.eq            #0x8379b4
    // 0x8379ac: mov             x1, x0
    // 0x8379b0: r0 = requestVisualUpdate()
    //     0x8379b0: bl              #0x8379f4  ; [package:flutter/src/rendering/binding.dart] _BindingPipelineManifold::requestVisualUpdate
    // 0x8379b4: r0 = Null
    //     0x8379b4: mov             x0, NULL
    // 0x8379b8: LeaveFrame
    //     0x8379b8: mov             SP, fp
    //     0x8379bc: ldp             fp, lr, [SP], #0x10
    // 0x8379c0: ret
    //     0x8379c0: ret             
    // 0x8379c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8379c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8379c8: b               #0x83799c
  }
  _ attach(/* No info */) {
    // ** addr: 0x8440c0, size: 0x11c
    // 0x8440c0: EnterFrame
    //     0x8440c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8440c4: mov             fp, SP
    // 0x8440c8: AllocStack(0x20)
    //     0x8440c8: sub             SP, SP, #0x20
    // 0x8440cc: SetupParameters(PipelineOwner this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x8440cc: mov             x4, x1
    //     0x8440d0: mov             x3, x2
    //     0x8440d4: stur            x1, [fp, #-8]
    //     0x8440d8: stur            x2, [fp, #-0x10]
    // 0x8440dc: CheckStackOverflow
    //     0x8440dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8440e0: cmp             SP, x16
    //     0x8440e4: b.ls            #0x8441cc
    // 0x8440e8: mov             x0, x3
    // 0x8440ec: StoreField: r4->field_43 = r0
    //     0x8440ec: stur            w0, [x4, #0x43]
    //     0x8440f0: ldurb           w16, [x4, #-1]
    //     0x8440f4: ldurb           w17, [x0, #-1]
    //     0x8440f8: and             x16, x17, x16, lsr #2
    //     0x8440fc: tst             x16, HEAP, lsr #32
    //     0x844100: b.eq            #0x844108
    //     0x844104: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x844108: mov             x2, x4
    // 0x84410c: r1 = Function '_updateSemanticsOwner@30266271':.
    //     0x84410c: ldr             x1, [PP, #0x2ec0]  ; [pp+0x2ec0] AnonymousClosure: (0x844704), in [package:flutter/src/rendering/object.dart] PipelineOwner::_updateSemanticsOwner (0x8441dc)
    // 0x844110: r0 = AllocateClosure()
    //     0x844110: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x844114: ldur            x1, [fp, #-0x10]
    // 0x844118: mov             x2, x0
    // 0x84411c: r0 = addListener()
    //     0x84411c: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x844120: ldur            x1, [fp, #-8]
    // 0x844124: r0 = _updateSemanticsOwner()
    //     0x844124: bl              #0x8441dc  ; [package:flutter/src/rendering/object.dart] PipelineOwner::_updateSemanticsOwner
    // 0x844128: ldur            x0, [fp, #-8]
    // 0x84412c: LoadField: r1 = r0->field_3f
    //     0x84412c: ldur            w1, [x0, #0x3f]
    // 0x844130: DecompressPointer r1
    //     0x844130: add             x1, x1, HEAP, lsl #32
    // 0x844134: r0 = iterator()
    //     0x844134: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x844138: stur            x0, [fp, #-0x18]
    // 0x84413c: LoadField: r2 = r0->field_7
    //     0x84413c: ldur            w2, [x0, #7]
    // 0x844140: DecompressPointer r2
    //     0x844140: add             x2, x2, HEAP, lsl #32
    // 0x844144: stur            x2, [fp, #-8]
    // 0x844148: CheckStackOverflow
    //     0x844148: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84414c: cmp             SP, x16
    //     0x844150: b.ls            #0x8441d4
    // 0x844154: mov             x1, x0
    // 0x844158: r0 = moveNext()
    //     0x844158: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x84415c: tbnz            w0, #4, #0x8441bc
    // 0x844160: ldur            x3, [fp, #-0x18]
    // 0x844164: LoadField: r4 = r3->field_33
    //     0x844164: ldur            w4, [x3, #0x33]
    // 0x844168: DecompressPointer r4
    //     0x844168: add             x4, x4, HEAP, lsl #32
    // 0x84416c: stur            x4, [fp, #-0x20]
    // 0x844170: cmp             w4, NULL
    // 0x844174: b.ne            #0x8441a4
    // 0x844178: mov             x0, x4
    // 0x84417c: ldur            x2, [fp, #-8]
    // 0x844180: r1 = Null
    //     0x844180: mov             x1, NULL
    // 0x844184: cmp             w2, NULL
    // 0x844188: b.eq            #0x8441a4
    // 0x84418c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x84418c: ldur            w4, [x2, #0x17]
    // 0x844190: DecompressPointer r4
    //     0x844190: add             x4, x4, HEAP, lsl #32
    // 0x844194: r8 = X0
    //     0x844194: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x844198: LoadField: r9 = r4->field_7
    //     0x844198: ldur            x9, [x4, #7]
    // 0x84419c: r3 = Null
    //     0x84419c: ldr             x3, [PP, #0x2ec8]  ; [pp+0x2ec8] Null
    // 0x8441a0: blr             x9
    // 0x8441a4: ldur            x1, [fp, #-0x20]
    // 0x8441a8: ldur            x2, [fp, #-0x10]
    // 0x8441ac: r0 = attach()
    //     0x8441ac: bl              #0x8440c0  ; [package:flutter/src/rendering/object.dart] PipelineOwner::attach
    // 0x8441b0: ldur            x0, [fp, #-0x18]
    // 0x8441b4: ldur            x2, [fp, #-8]
    // 0x8441b8: b               #0x844148
    // 0x8441bc: r0 = Null
    //     0x8441bc: mov             x0, NULL
    // 0x8441c0: LeaveFrame
    //     0x8441c0: mov             SP, fp
    //     0x8441c4: ldp             fp, lr, [SP], #0x10
    // 0x8441c8: ret
    //     0x8441c8: ret             
    // 0x8441cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8441cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8441d0: b               #0x8440e8
    // 0x8441d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8441d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8441d8: b               #0x844154
  }
  _ _updateSemanticsOwner(/* No info */) {
    // ** addr: 0x8441dc, size: 0x128
    // 0x8441dc: EnterFrame
    //     0x8441dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8441e0: mov             fp, SP
    // 0x8441e4: AllocStack(0x18)
    //     0x8441e4: sub             SP, SP, #0x18
    // 0x8441e8: SetupParameters(PipelineOwner this /* r1 => r0, fp-0x8 */)
    //     0x8441e8: mov             x0, x1
    //     0x8441ec: stur            x1, [fp, #-8]
    // 0x8441f0: CheckStackOverflow
    //     0x8441f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8441f4: cmp             SP, x16
    //     0x8441f8: b.ls            #0x8442fc
    // 0x8441fc: LoadField: r1 = r0->field_43
    //     0x8441fc: ldur            w1, [x0, #0x43]
    // 0x844200: DecompressPointer r1
    //     0x844200: add             x1, x1, HEAP, lsl #32
    // 0x844204: cmp             w1, NULL
    // 0x844208: b.ne            #0x844214
    // 0x84420c: r0 = Null
    //     0x84420c: mov             x0, NULL
    // 0x844210: b               #0x844218
    // 0x844214: r0 = semanticsEnabled()
    //     0x844214: bl              #0x844560  ; [package:flutter/src/rendering/binding.dart] _BindingPipelineManifold::semanticsEnabled
    // 0x844218: cmp             w0, NULL
    // 0x84421c: b.ne            #0x844228
    // 0x844220: ldur            x2, [fp, #-8]
    // 0x844224: b               #0x8442ac
    // 0x844228: tbnz            w0, #4, #0x8442a8
    // 0x84422c: ldur            x0, [fp, #-8]
    // 0x844230: LoadField: r1 = r0->field_2b
    //     0x844230: ldur            w1, [x0, #0x2b]
    // 0x844234: DecompressPointer r1
    //     0x844234: add             x1, x1, HEAP, lsl #32
    // 0x844238: cmp             w1, NULL
    // 0x84423c: b.ne            #0x8442ec
    // 0x844240: LoadField: r2 = r0->field_f
    //     0x844240: ldur            w2, [x0, #0xf]
    // 0x844244: DecompressPointer r2
    //     0x844244: add             x2, x2, HEAP, lsl #32
    // 0x844248: stur            x2, [fp, #-0x10]
    // 0x84424c: r0 = SemanticsOwner()
    //     0x84424c: bl              #0x844554  ; AllocateSemanticsOwnerStub -> SemanticsOwner (size=0x3c)
    // 0x844250: mov             x1, x0
    // 0x844254: ldur            x2, [fp, #-0x10]
    // 0x844258: stur            x0, [fp, #-0x10]
    // 0x84425c: r0 = SemanticsOwner()
    //     0x84425c: bl              #0x844304  ; [package:flutter/src/semantics/semantics.dart] SemanticsOwner::SemanticsOwner
    // 0x844260: ldur            x0, [fp, #-0x10]
    // 0x844264: ldur            x2, [fp, #-8]
    // 0x844268: StoreField: r2->field_2b = r0
    //     0x844268: stur            w0, [x2, #0x2b]
    //     0x84426c: ldurb           w16, [x2, #-1]
    //     0x844270: ldurb           w17, [x0, #-1]
    //     0x844274: and             x16, x17, x16, lsr #2
    //     0x844278: tst             x16, HEAP, lsr #32
    //     0x84427c: b.eq            #0x844284
    //     0x844280: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x844284: LoadField: r0 = r2->field_b
    //     0x844284: ldur            w0, [x2, #0xb]
    // 0x844288: DecompressPointer r0
    //     0x844288: add             x0, x0, HEAP, lsl #32
    // 0x84428c: cmp             w0, NULL
    // 0x844290: b.eq            #0x8442ec
    // 0x844294: str             x0, [SP]
    // 0x844298: ClosureCall
    //     0x844298: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x84429c: ldur            x2, [x0, #0x1f]
    //     0x8442a0: blr             x2
    // 0x8442a4: b               #0x8442ec
    // 0x8442a8: ldur            x2, [fp, #-8]
    // 0x8442ac: LoadField: r1 = r2->field_2b
    //     0x8442ac: ldur            w1, [x2, #0x2b]
    // 0x8442b0: DecompressPointer r1
    //     0x8442b0: add             x1, x1, HEAP, lsl #32
    // 0x8442b4: cmp             w1, NULL
    // 0x8442b8: b.eq            #0x8442ec
    // 0x8442bc: r0 = dispose()
    //     0x8442bc: bl              #0x10ef634  ; [package:flutter/src/semantics/semantics.dart] SemanticsOwner::dispose
    // 0x8442c0: ldur            x0, [fp, #-8]
    // 0x8442c4: StoreField: r0->field_2b = rNULL
    //     0x8442c4: stur            NULL, [x0, #0x2b]
    // 0x8442c8: LoadField: r1 = r0->field_13
    //     0x8442c8: ldur            w1, [x0, #0x13]
    // 0x8442cc: DecompressPointer r1
    //     0x8442cc: add             x1, x1, HEAP, lsl #32
    // 0x8442d0: cmp             w1, NULL
    // 0x8442d4: b.eq            #0x8442ec
    // 0x8442d8: str             x1, [SP]
    // 0x8442dc: mov             x0, x1
    // 0x8442e0: ClosureCall
    //     0x8442e0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8442e4: ldur            x2, [x0, #0x1f]
    //     0x8442e8: blr             x2
    // 0x8442ec: r0 = Null
    //     0x8442ec: mov             x0, NULL
    // 0x8442f0: LeaveFrame
    //     0x8442f0: mov             SP, fp
    //     0x8442f4: ldp             fp, lr, [SP], #0x10
    // 0x8442f8: ret
    //     0x8442f8: ret             
    // 0x8442fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8442fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844300: b               #0x8441fc
  }
  [closure] void _updateSemanticsOwner(dynamic) {
    // ** addr: 0x844704, size: 0x38
    // 0x844704: EnterFrame
    //     0x844704: stp             fp, lr, [SP, #-0x10]!
    //     0x844708: mov             fp, SP
    // 0x84470c: ldr             x0, [fp, #0x10]
    // 0x844710: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x844710: ldur            w1, [x0, #0x17]
    // 0x844714: DecompressPointer r1
    //     0x844714: add             x1, x1, HEAP, lsl #32
    // 0x844718: CheckStackOverflow
    //     0x844718: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x84471c: cmp             SP, x16
    //     0x844720: b.ls            #0x844734
    // 0x844724: r0 = _updateSemanticsOwner()
    //     0x844724: bl              #0x8441dc  ; [package:flutter/src/rendering/object.dart] PipelineOwner::_updateSemanticsOwner
    // 0x844728: LeaveFrame
    //     0x844728: mov             SP, fp
    //     0x84472c: ldp             fp, lr, [SP], #0x10
    // 0x844730: ret
    //     0x844730: ret             
    // 0x844734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844734: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844738: b               #0x844724
  }
  _ PipelineOwner(/* No info */) {
    // ** addr: 0x844b90, size: 0x290
    // 0x844b90: EnterFrame
    //     0x844b90: stp             fp, lr, [SP, #-0x10]!
    //     0x844b94: mov             fp, SP
    // 0x844b98: AllocStack(0x20)
    //     0x844b98: sub             SP, SP, #0x20
    // 0x844b9c: SetupParameters(PipelineOwner this /* r1 => r3, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */, {dynamic onSemanticsOwnerCreated = Null /* r5, fp-0x10 */, dynamic onSemanticsOwnerDisposed = Null /* r4, fp-0x8 */})
    //     0x844b9c: mov             x3, x1
    //     0x844ba0: mov             x0, x2
    //     0x844ba4: stur            x1, [fp, #-0x18]
    //     0x844ba8: stur            x2, [fp, #-0x20]
    //     0x844bac: ldur            w1, [x4, #0x13]
    //     0x844bb0: ldur            w2, [x4, #0x1f]
    //     0x844bb4: add             x2, x2, HEAP, lsl #32
    //     0x844bb8: ldr             x16, [PP, #0x2f28]  ; [pp+0x2f28] "onSemanticsOwnerCreated"
    //     0x844bbc: cmp             w2, w16
    //     0x844bc0: b.ne            #0x844be4
    //     0x844bc4: ldur            w2, [x4, #0x23]
    //     0x844bc8: add             x2, x2, HEAP, lsl #32
    //     0x844bcc: sub             w5, w1, w2
    //     0x844bd0: add             x2, fp, w5, sxtw #2
    //     0x844bd4: ldr             x2, [x2, #8]
    //     0x844bd8: mov             x5, x2
    //     0x844bdc: mov             x2, #1
    //     0x844be0: b               #0x844bec
    //     0x844be4: mov             x5, NULL
    //     0x844be8: mov             x2, #0
    //     0x844bec: stur            x5, [fp, #-0x10]
    //     0x844bf0: lsl             x6, x2, #1
    //     0x844bf4: lsl             w2, w6, #1
    //     0x844bf8: add             w6, w2, #8
    //     0x844bfc: add             x16, x4, w6, sxtw #1
    //     0x844c00: ldur            w7, [x16, #0xf]
    //     0x844c04: add             x7, x7, HEAP, lsl #32
    //     0x844c08: ldr             x16, [PP, #0x2f30]  ; [pp+0x2f30] "onSemanticsOwnerDisposed"
    //     0x844c0c: cmp             w7, w16
    //     0x844c10: b.ne            #0x844c38
    //     0x844c14: add             w6, w2, #0xa
    //     0x844c18: add             x16, x4, w6, sxtw #1
    //     0x844c1c: ldur            w2, [x16, #0xf]
    //     0x844c20: add             x2, x2, HEAP, lsl #32
    //     0x844c24: sub             w4, w1, w2
    //     0x844c28: add             x1, fp, w4, sxtw #2
    //     0x844c2c: ldr             x1, [x1, #8]
    //     0x844c30: mov             x4, x1
    //     0x844c34: b               #0x844c3c
    //     0x844c38: mov             x4, NULL
    //     0x844c3c: add             x1, NULL, #0x30  ; false
    //     0x844c40: stur            x4, [fp, #-8]
    // 0x844c3c: r1 = false
    // 0x844c44: CheckStackOverflow
    //     0x844c44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x844c48: cmp             SP, x16
    //     0x844c4c: b.ls            #0x844e18
    // 0x844c50: StoreField: r3->field_1b = r1
    //     0x844c50: stur            w1, [x3, #0x1b]
    // 0x844c54: StoreField: r3->field_2f = rZR
    //     0x844c54: stur            xzr, [x3, #0x2f]
    // 0x844c58: r1 = <RenderObject>
    //     0x844c58: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x844c5c: r2 = 0
    //     0x844c5c: mov             x2, #0
    // 0x844c60: r0 = _GrowableList()
    //     0x844c60: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x844c64: ldur            x3, [fp, #-0x18]
    // 0x844c68: StoreField: r3->field_1f = r0
    //     0x844c68: stur            w0, [x3, #0x1f]
    //     0x844c6c: ldurb           w16, [x3, #-1]
    //     0x844c70: ldurb           w17, [x0, #-1]
    //     0x844c74: and             x16, x17, x16, lsr #2
    //     0x844c78: tst             x16, HEAP, lsr #32
    //     0x844c7c: b.eq            #0x844c84
    //     0x844c80: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x844c84: r1 = <RenderObject>
    //     0x844c84: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x844c88: r2 = 0
    //     0x844c88: mov             x2, #0
    // 0x844c8c: r0 = _GrowableList()
    //     0x844c8c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x844c90: ldur            x3, [fp, #-0x18]
    // 0x844c94: StoreField: r3->field_23 = r0
    //     0x844c94: stur            w0, [x3, #0x23]
    //     0x844c98: ldurb           w16, [x3, #-1]
    //     0x844c9c: ldurb           w17, [x0, #-1]
    //     0x844ca0: and             x16, x17, x16, lsr #2
    //     0x844ca4: tst             x16, HEAP, lsr #32
    //     0x844ca8: b.eq            #0x844cb0
    //     0x844cac: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x844cb0: r1 = <RenderObject>
    //     0x844cb0: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x844cb4: r2 = 0
    //     0x844cb4: mov             x2, #0
    // 0x844cb8: r0 = _GrowableList()
    //     0x844cb8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x844cbc: ldur            x2, [fp, #-0x18]
    // 0x844cc0: StoreField: r2->field_27 = r0
    //     0x844cc0: stur            w0, [x2, #0x27]
    //     0x844cc4: ldurb           w16, [x2, #-1]
    //     0x844cc8: ldurb           w17, [x0, #-1]
    //     0x844ccc: and             x16, x17, x16, lsr #2
    //     0x844cd0: tst             x16, HEAP, lsr #32
    //     0x844cd4: b.eq            #0x844cdc
    //     0x844cd8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x844cdc: r1 = <RenderObject>
    //     0x844cdc: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x844ce0: r0 = _Set()
    //     0x844ce0: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x844ce4: r2 = _Uint32List
    //     0x844ce4: ldr             x2, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x844ce8: StoreField: r0->field_1b = r2
    //     0x844ce8: stur            w2, [x0, #0x1b]
    // 0x844cec: StoreField: r0->field_b = rZR
    //     0x844cec: stur            wzr, [x0, #0xb]
    // 0x844cf0: r3 = const []
    //     0x844cf0: ldr             x3, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x844cf4: StoreField: r0->field_f = r3
    //     0x844cf4: stur            w3, [x0, #0xf]
    // 0x844cf8: StoreField: r0->field_13 = rZR
    //     0x844cf8: stur            wzr, [x0, #0x13]
    // 0x844cfc: ArrayStore: r0[0] = rZR  ; List_4
    //     0x844cfc: stur            wzr, [x0, #0x17]
    // 0x844d00: ldur            x4, [fp, #-0x18]
    // 0x844d04: StoreField: r4->field_37 = r0
    //     0x844d04: stur            w0, [x4, #0x37]
    //     0x844d08: ldurb           w16, [x4, #-1]
    //     0x844d0c: ldurb           w17, [x0, #-1]
    //     0x844d10: and             x16, x17, x16, lsr #2
    //     0x844d14: tst             x16, HEAP, lsr #32
    //     0x844d18: b.eq            #0x844d20
    //     0x844d1c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x844d20: r1 = <RenderObject>
    //     0x844d20: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x844d24: r0 = _Set()
    //     0x844d24: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x844d28: r2 = _Uint32List
    //     0x844d28: ldr             x2, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x844d2c: StoreField: r0->field_1b = r2
    //     0x844d2c: stur            w2, [x0, #0x1b]
    // 0x844d30: StoreField: r0->field_b = rZR
    //     0x844d30: stur            wzr, [x0, #0xb]
    // 0x844d34: r3 = const []
    //     0x844d34: ldr             x3, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x844d38: StoreField: r0->field_f = r3
    //     0x844d38: stur            w3, [x0, #0xf]
    // 0x844d3c: StoreField: r0->field_13 = rZR
    //     0x844d3c: stur            wzr, [x0, #0x13]
    // 0x844d40: ArrayStore: r0[0] = rZR  ; List_4
    //     0x844d40: stur            wzr, [x0, #0x17]
    // 0x844d44: ldur            x4, [fp, #-0x18]
    // 0x844d48: StoreField: r4->field_3b = r0
    //     0x844d48: stur            w0, [x4, #0x3b]
    //     0x844d4c: ldurb           w16, [x4, #-1]
    //     0x844d50: ldurb           w17, [x0, #-1]
    //     0x844d54: and             x16, x17, x16, lsr #2
    //     0x844d58: tst             x16, HEAP, lsr #32
    //     0x844d5c: b.eq            #0x844d64
    //     0x844d60: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x844d64: r1 = <PipelineOwner>
    //     0x844d64: ldr             x1, [PP, #0x2f38]  ; [pp+0x2f38] TypeArguments: <PipelineOwner>
    // 0x844d68: r0 = _Set()
    //     0x844d68: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x844d6c: r1 = _Uint32List
    //     0x844d6c: ldr             x1, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x844d70: StoreField: r0->field_1b = r1
    //     0x844d70: stur            w1, [x0, #0x1b]
    // 0x844d74: StoreField: r0->field_b = rZR
    //     0x844d74: stur            wzr, [x0, #0xb]
    // 0x844d78: r1 = const []
    //     0x844d78: ldr             x1, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x844d7c: StoreField: r0->field_f = r1
    //     0x844d7c: stur            w1, [x0, #0xf]
    // 0x844d80: StoreField: r0->field_13 = rZR
    //     0x844d80: stur            wzr, [x0, #0x13]
    // 0x844d84: ArrayStore: r0[0] = rZR  ; List_4
    //     0x844d84: stur            wzr, [x0, #0x17]
    // 0x844d88: ldur            x1, [fp, #-0x18]
    // 0x844d8c: StoreField: r1->field_3f = r0
    //     0x844d8c: stur            w0, [x1, #0x3f]
    //     0x844d90: ldurb           w16, [x1, #-1]
    //     0x844d94: ldurb           w17, [x0, #-1]
    //     0x844d98: and             x16, x17, x16, lsr #2
    //     0x844d9c: tst             x16, HEAP, lsr #32
    //     0x844da0: b.eq            #0x844da8
    //     0x844da4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x844da8: ldur            x0, [fp, #-0x10]
    // 0x844dac: StoreField: r1->field_b = r0
    //     0x844dac: stur            w0, [x1, #0xb]
    //     0x844db0: ldurb           w16, [x1, #-1]
    //     0x844db4: ldurb           w17, [x0, #-1]
    //     0x844db8: and             x16, x17, x16, lsr #2
    //     0x844dbc: tst             x16, HEAP, lsr #32
    //     0x844dc0: b.eq            #0x844dc8
    //     0x844dc4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x844dc8: ldur            x0, [fp, #-0x20]
    // 0x844dcc: StoreField: r1->field_f = r0
    //     0x844dcc: stur            w0, [x1, #0xf]
    //     0x844dd0: ldurb           w16, [x1, #-1]
    //     0x844dd4: ldurb           w17, [x0, #-1]
    //     0x844dd8: and             x16, x17, x16, lsr #2
    //     0x844ddc: tst             x16, HEAP, lsr #32
    //     0x844de0: b.eq            #0x844de8
    //     0x844de4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x844de8: ldur            x0, [fp, #-8]
    // 0x844dec: StoreField: r1->field_13 = r0
    //     0x844dec: stur            w0, [x1, #0x13]
    //     0x844df0: ldurb           w16, [x1, #-1]
    //     0x844df4: ldurb           w17, [x0, #-1]
    //     0x844df8: and             x16, x17, x16, lsr #2
    //     0x844dfc: tst             x16, HEAP, lsr #32
    //     0x844e00: b.eq            #0x844e08
    //     0x844e04: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x844e08: r0 = Null
    //     0x844e08: mov             x0, NULL
    // 0x844e0c: LeaveFrame
    //     0x844e0c: mov             SP, fp
    //     0x844e10: ldp             fp, lr, [SP], #0x10
    // 0x844e14: ret
    //     0x844e14: ret             
    // 0x844e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844e18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844e1c: b               #0x844c50
  }
  _ flushSemantics(/* No info */) {
    // ** addr: 0x87e550, size: 0xf9c
    // 0x87e550: EnterFrame
    //     0x87e550: stp             fp, lr, [SP, #-0x10]!
    //     0x87e554: mov             fp, SP
    // 0x87e558: AllocStack(0x88)
    //     0x87e558: sub             SP, SP, #0x88
    // 0x87e55c: SetupParameters(PipelineOwner this /* r1 => r1, fp-0x8 */)
    //     0x87e55c: stur            x1, [fp, #-8]
    // 0x87e560: CheckStackOverflow
    //     0x87e560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87e564: cmp             SP, x16
    //     0x87e568: b.ls            #0x87f480
    // 0x87e56c: r1 = 1
    //     0x87e56c: mov             x1, #1
    // 0x87e570: r0 = AllocateContext()
    //     0x87e570: bl              #0x13de838  ; AllocateContextStub
    // 0x87e574: mov             x3, x0
    // 0x87e578: ldur            x0, [fp, #-8]
    // 0x87e57c: stur            x3, [fp, #-0x18]
    // 0x87e580: StoreField: r3->field_f = r0
    //     0x87e580: stur            w0, [x3, #0xf]
    // 0x87e584: LoadField: r1 = r0->field_2b
    //     0x87e584: ldur            w1, [x0, #0x2b]
    // 0x87e588: DecompressPointer r1
    //     0x87e588: add             x1, x1, HEAP, lsl #32
    // 0x87e58c: cmp             w1, NULL
    // 0x87e590: b.ne            #0x87e5a4
    // 0x87e594: r0 = Null
    //     0x87e594: mov             x0, NULL
    // 0x87e598: LeaveFrame
    //     0x87e598: mov             SP, fp
    //     0x87e59c: ldp             fp, lr, [SP], #0x10
    // 0x87e5a0: ret
    //     0x87e5a0: ret             
    // 0x87e5a4: LoadField: r4 = r0->field_37
    //     0x87e5a4: ldur            w4, [x0, #0x37]
    // 0x87e5a8: DecompressPointer r4
    //     0x87e5a8: add             x4, x4, HEAP, lsl #32
    // 0x87e5ac: mov             x2, x3
    // 0x87e5b0: stur            x4, [fp, #-0x10]
    // 0x87e5b4: r1 = Function '<anonymous closure>':.
    //     0x87e5b4: ldr             x1, [PP, #0x22f8]  ; [pp+0x22f8] AnonymousClosure: (0x8987f8), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x87e550)
    // 0x87e5b8: r0 = AllocateClosure()
    //     0x87e5b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87e5bc: ldur            x1, [fp, #-0x10]
    // 0x87e5c0: mov             x2, x0
    // 0x87e5c4: r0 = where()
    //     0x87e5c4: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x87e5c8: mov             x1, x0
    // 0x87e5cc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x87e5cc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x87e5d0: r0 = toList()
    //     0x87e5d0: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0x87e5d4: r1 = Function '<anonymous closure>':.
    //     0x87e5d4: ldr             x1, [PP, #0x2300]  ; [pp+0x2300] AnonymousClosure: (0x8987bc), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x87e550)
    // 0x87e5d8: r2 = Null
    //     0x87e5d8: mov             x2, NULL
    // 0x87e5dc: stur            x0, [fp, #-0x20]
    // 0x87e5e0: r0 = AllocateClosure()
    //     0x87e5e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87e5e4: str             x0, [SP]
    // 0x87e5e8: ldur            x1, [fp, #-0x20]
    // 0x87e5ec: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x87e5ec: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x87e5f0: r0 = sort()
    //     0x87e5f0: bl              #0x9f9bf0  ; [dart:collection] ListBase::sort
    // 0x87e5f4: ldur            x1, [fp, #-0x10]
    // 0x87e5f8: r0 = clear()
    //     0x87e5f8: bl              #0x83d960  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x87e5fc: ldur            x1, [fp, #-8]
    // 0x87e600: r0 = library()
    //     0x87e600: bl              #0x13aeec8  ; [package:stack_trace/src/unparsed_frame.dart] UnparsedFrame::library
    // 0x87e604: ldur            x3, [fp, #-0x20]
    // 0x87e608: LoadField: r4 = r3->field_7
    //     0x87e608: ldur            w4, [x3, #7]
    // 0x87e60c: DecompressPointer r4
    //     0x87e60c: add             x4, x4, HEAP, lsl #32
    // 0x87e610: stur            x4, [fp, #-0x38]
    // 0x87e614: LoadField: r0 = r3->field_b
    //     0x87e614: ldur            w0, [x3, #0xb]
    // 0x87e618: r5 = LoadInt32Instr(r0)
    //     0x87e618: sbfx            x5, x0, #1, #0x1f
    // 0x87e61c: stur            x5, [fp, #-0x30]
    // 0x87e620: r0 = 0
    //     0x87e620: mov             x0, #0
    // 0x87e624: CheckStackOverflow
    //     0x87e624: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87e628: cmp             SP, x16
    //     0x87e62c: b.ls            #0x87f488
    // 0x87e630: LoadField: r1 = r3->field_b
    //     0x87e630: ldur            w1, [x3, #0xb]
    // 0x87e634: r2 = LoadInt32Instr(r1)
    //     0x87e634: sbfx            x2, x1, #1, #0x1f
    // 0x87e638: cmp             x5, x2
    // 0x87e63c: b.ne            #0x87f460
    // 0x87e640: cmp             x0, x2
    // 0x87e644: b.ge            #0x87e74c
    // 0x87e648: LoadField: r1 = r3->field_f
    //     0x87e648: ldur            w1, [x3, #0xf]
    // 0x87e64c: DecompressPointer r1
    //     0x87e64c: add             x1, x1, HEAP, lsl #32
    // 0x87e650: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x87e650: add             x16, x1, x0, lsl #2
    //     0x87e654: ldur            w6, [x16, #0xf]
    // 0x87e658: DecompressPointer r6
    //     0x87e658: add             x6, x6, HEAP, lsl #32
    // 0x87e65c: stur            x6, [fp, #-0x10]
    // 0x87e660: add             x7, x0, #1
    // 0x87e664: stur            x7, [fp, #-0x28]
    // 0x87e668: cmp             w6, NULL
    // 0x87e66c: b.ne            #0x87e69c
    // 0x87e670: mov             x0, x6
    // 0x87e674: mov             x2, x4
    // 0x87e678: r1 = Null
    //     0x87e678: mov             x1, NULL
    // 0x87e67c: cmp             w2, NULL
    // 0x87e680: b.eq            #0x87e69c
    // 0x87e684: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87e684: ldur            w4, [x2, #0x17]
    // 0x87e688: DecompressPointer r4
    //     0x87e688: add             x4, x4, HEAP, lsl #32
    // 0x87e68c: r8 = X0
    //     0x87e68c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87e690: LoadField: r9 = r4->field_7
    //     0x87e690: ldur            x9, [x4, #7]
    // 0x87e694: r3 = Null
    //     0x87e694: ldr             x3, [PP, #0x2308]  ; [pp+0x2308] Null
    // 0x87e698: blr             x9
    // 0x87e69c: ldur            x1, [fp, #-0x10]
    // 0x87e6a0: LoadField: r0 = r1->field_43
    //     0x87e6a0: ldur            w0, [x1, #0x43]
    // 0x87e6a4: DecompressPointer r0
    //     0x87e6a4: add             x0, x0, HEAP, lsl #32
    // 0x87e6a8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87e6ac: cmp             w0, w16
    // 0x87e6b0: b.ne            #0x87e6bc
    // 0x87e6b4: r2 = _semantics
    //     0x87e6b4: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x87e6b8: r0 = InitLateFinalInstanceField()
    //     0x87e6b8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x87e6bc: mov             x2, x0
    // 0x87e6c0: stur            x2, [fp, #-0x40]
    // 0x87e6c4: LoadField: r1 = r2->field_7
    //     0x87e6c4: ldur            w1, [x2, #7]
    // 0x87e6c8: DecompressPointer r1
    //     0x87e6c8: add             x1, x1, HEAP, lsl #32
    // 0x87e6cc: r0 = LoadClassIdInstr(r1)
    //     0x87e6cc: ldur            x0, [x1, #-1]
    //     0x87e6d0: ubfx            x0, x0, #0xc, #0x14
    // 0x87e6d4: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x87e6d4: mov             x17, #0xfc0
    //     0x87e6d8: movk            x17, #1, lsl #16
    //     0x87e6dc: add             lr, x0, x17
    //     0x87e6e0: ldr             lr, [x21, lr, lsl #3]
    //     0x87e6e4: blr             lr
    // 0x87e6e8: cmp             w0, NULL
    // 0x87e6ec: b.eq            #0x87e728
    // 0x87e6f0: ldur            x2, [fp, #-0x40]
    // 0x87e6f4: mov             x1, x0
    // 0x87e6f8: LoadField: r0 = r1->field_43
    //     0x87e6f8: ldur            w0, [x1, #0x43]
    // 0x87e6fc: DecompressPointer r0
    //     0x87e6fc: add             x0, x0, HEAP, lsl #32
    // 0x87e700: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87e704: cmp             w0, w16
    // 0x87e708: b.ne            #0x87e714
    // 0x87e70c: r2 = _semantics
    //     0x87e70c: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x87e710: r0 = InitLateFinalInstanceField()
    //     0x87e710: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x87e714: ldur            x0, [fp, #-0x40]
    // 0x87e718: LoadField: r1 = r0->field_33
    //     0x87e718: ldur            w1, [x0, #0x33]
    // 0x87e71c: DecompressPointer r1
    //     0x87e71c: add             x1, x1, HEAP, lsl #32
    // 0x87e720: cmp             w1, NULL
    // 0x87e724: b.eq            #0x87e738
    // 0x87e728: ldur            x0, [fp, #-0x10]
    // 0x87e72c: LoadField: r1 = r0->field_43
    //     0x87e72c: ldur            w1, [x0, #0x43]
    // 0x87e730: DecompressPointer r1
    //     0x87e730: add             x1, x1, HEAP, lsl #32
    // 0x87e734: r0 = updateChildren()
    //     0x87e734: bl              #0x895d88  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::updateChildren
    // 0x87e738: ldur            x0, [fp, #-0x28]
    // 0x87e73c: ldur            x3, [fp, #-0x20]
    // 0x87e740: ldur            x4, [fp, #-0x38]
    // 0x87e744: ldur            x5, [fp, #-0x30]
    // 0x87e748: b               #0x87e624
    // 0x87e74c: ldur            x0, [fp, #-8]
    // 0x87e750: LoadField: r3 = r0->field_3b
    //     0x87e750: ldur            w3, [x0, #0x3b]
    // 0x87e754: DecompressPointer r3
    //     0x87e754: add             x3, x3, HEAP, lsl #32
    // 0x87e758: ldur            x2, [fp, #-0x18]
    // 0x87e75c: stur            x3, [fp, #-0x10]
    // 0x87e760: r1 = Function '<anonymous closure>':.
    //     0x87e760: ldr             x1, [PP, #0x2320]  ; [pp+0x2320] AnonymousClosure: (0x8986b0), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x87e550)
    // 0x87e764: r0 = AllocateClosure()
    //     0x87e764: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87e768: ldur            x1, [fp, #-0x10]
    // 0x87e76c: mov             x2, x0
    // 0x87e770: r0 = where()
    //     0x87e770: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0x87e774: mov             x1, x0
    // 0x87e778: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x87e778: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x87e77c: r0 = toList()
    //     0x87e77c: bl              #0xb08ca4  ; [dart:core] Iterable::toList
    // 0x87e780: ldur            x1, [fp, #-0x10]
    // 0x87e784: stur            x0, [fp, #-0x10]
    // 0x87e788: r0 = clear()
    //     0x87e788: bl              #0x83d960  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0x87e78c: ldur            x3, [fp, #-0x10]
    // 0x87e790: LoadField: r4 = r3->field_7
    //     0x87e790: ldur            w4, [x3, #7]
    // 0x87e794: DecompressPointer r4
    //     0x87e794: add             x4, x4, HEAP, lsl #32
    // 0x87e798: stur            x4, [fp, #-0x40]
    // 0x87e79c: LoadField: r0 = r3->field_b
    //     0x87e79c: ldur            w0, [x3, #0xb]
    // 0x87e7a0: r5 = LoadInt32Instr(r0)
    //     0x87e7a0: sbfx            x5, x0, #1, #0x1f
    // 0x87e7a4: stur            x5, [fp, #-0x30]
    // 0x87e7a8: r0 = 0
    //     0x87e7a8: mov             x0, #0
    // 0x87e7ac: CheckStackOverflow
    //     0x87e7ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87e7b0: cmp             SP, x16
    //     0x87e7b4: b.ls            #0x87f490
    // 0x87e7b8: LoadField: r1 = r3->field_b
    //     0x87e7b8: ldur            w1, [x3, #0xb]
    // 0x87e7bc: r2 = LoadInt32Instr(r1)
    //     0x87e7bc: sbfx            x2, x1, #1, #0x1f
    // 0x87e7c0: stur            x2, [fp, #-0x60]
    // 0x87e7c4: cmp             x5, x2
    // 0x87e7c8: b.ne            #0x87f440
    // 0x87e7cc: cmp             x0, x2
    // 0x87e7d0: b.ge            #0x87eba4
    // 0x87e7d4: LoadField: r1 = r3->field_f
    //     0x87e7d4: ldur            w1, [x3, #0xf]
    // 0x87e7d8: DecompressPointer r1
    //     0x87e7d8: add             x1, x1, HEAP, lsl #32
    // 0x87e7dc: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x87e7dc: add             x16, x1, x0, lsl #2
    //     0x87e7e0: ldur            w6, [x16, #0xf]
    // 0x87e7e4: DecompressPointer r6
    //     0x87e7e4: add             x6, x6, HEAP, lsl #32
    // 0x87e7e8: stur            x6, [fp, #-0x18]
    // 0x87e7ec: add             x7, x0, #1
    // 0x87e7f0: stur            x7, [fp, #-0x28]
    // 0x87e7f4: cmp             w6, NULL
    // 0x87e7f8: b.ne            #0x87e828
    // 0x87e7fc: mov             x0, x6
    // 0x87e800: mov             x2, x4
    // 0x87e804: r1 = Null
    //     0x87e804: mov             x1, NULL
    // 0x87e808: cmp             w2, NULL
    // 0x87e80c: b.eq            #0x87e828
    // 0x87e810: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87e810: ldur            w4, [x2, #0x17]
    // 0x87e814: DecompressPointer r4
    //     0x87e814: add             x4, x4, HEAP, lsl #32
    // 0x87e818: r8 = X0
    //     0x87e818: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87e81c: LoadField: r9 = r4->field_7
    //     0x87e81c: ldur            x9, [x4, #7]
    // 0x87e820: r3 = Null
    //     0x87e820: ldr             x3, [PP, #0x2328]  ; [pp+0x2328] Null
    // 0x87e824: blr             x9
    // 0x87e828: ldur            x1, [fp, #-0x18]
    // 0x87e82c: LoadField: r0 = r1->field_43
    //     0x87e82c: ldur            w0, [x1, #0x43]
    // 0x87e830: DecompressPointer r0
    //     0x87e830: add             x0, x0, HEAP, lsl #32
    // 0x87e834: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87e838: cmp             w0, w16
    // 0x87e83c: b.ne            #0x87e848
    // 0x87e840: r2 = _semantics
    //     0x87e840: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x87e844: r0 = InitLateFinalInstanceField()
    //     0x87e844: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x87e848: mov             x1, x0
    // 0x87e84c: r0 = shouldFormSemanticsNode()
    //     0x87e84c: bl              #0x895ca4  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::shouldFormSemanticsNode
    // 0x87e850: tbnz            w0, #4, #0x87e868
    // 0x87e854: ldur            x0, [fp, #-0x18]
    // 0x87e858: LoadField: r1 = r0->field_43
    //     0x87e858: ldur            w1, [x0, #0x43]
    // 0x87e85c: DecompressPointer r1
    //     0x87e85c: add             x1, x1, HEAP, lsl #32
    // 0x87e860: r0 = geometryDirty()
    //     0x87e860: bl              #0x895c38  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::geometryDirty
    // 0x87e864: tbz             w0, #4, #0x87eb90
    // 0x87e868: ldur            x0, [fp, #-0x18]
    // 0x87e86c: LoadField: r1 = r0->field_43
    //     0x87e86c: ldur            w1, [x0, #0x43]
    // 0x87e870: DecompressPointer r1
    //     0x87e870: add             x1, x1, HEAP, lsl #32
    // 0x87e874: r0 = shouldFormSemanticsNode()
    //     0x87e874: bl              #0x895ca4  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::shouldFormSemanticsNode
    // 0x87e878: tbnz            w0, #4, #0x87e8a4
    // 0x87e87c: ldur            x0, [fp, #-0x18]
    // 0x87e880: LoadField: r1 = r0->field_1f
    //     0x87e880: ldur            w1, [x0, #0x1f]
    // 0x87e884: DecompressPointer r1
    //     0x87e884: add             x1, x1, HEAP, lsl #32
    // 0x87e888: cmp             w1, NULL
    // 0x87e88c: b.eq            #0x87e8a8
    // 0x87e890: tbnz            w1, #4, #0x87e8a8
    // 0x87e894: LoadField: r1 = r0->field_43
    //     0x87e894: ldur            w1, [x0, #0x43]
    // 0x87e898: DecompressPointer r1
    //     0x87e898: add             x1, x1, HEAP, lsl #32
    // 0x87e89c: StoreField: r1->field_37 = rNULL
    //     0x87e89c: stur            NULL, [x1, #0x37]
    // 0x87e8a0: b               #0x87eb90
    // 0x87e8a4: ldur            x0, [fp, #-0x18]
    // 0x87e8a8: LoadField: r1 = r0->field_43
    //     0x87e8a8: ldur            w1, [x0, #0x43]
    // 0x87e8ac: DecompressPointer r1
    //     0x87e8ac: add             x1, x1, HEAP, lsl #32
    // 0x87e8b0: r0 = contributesToSemanticsTree()
    //     0x87e8b0: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x87e8b4: tbz             w0, #4, #0x87eb38
    // 0x87e8b8: ldur            x0, [fp, #-0x18]
    // 0x87e8bc: LoadField: r1 = r0->field_43
    //     0x87e8bc: ldur            w1, [x0, #0x43]
    // 0x87e8c0: DecompressPointer r1
    //     0x87e8c0: add             x1, x1, HEAP, lsl #32
    // 0x87e8c4: LoadField: r0 = r1->field_23
    //     0x87e8c4: ldur            w0, [x1, #0x23]
    // 0x87e8c8: DecompressPointer r0
    //     0x87e8c8: add             x0, x0, HEAP, lsl #32
    // 0x87e8cc: r16 = <_RenderObjectSemantics>
    //     0x87e8cc: ldr             x16, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x87e8d0: stp             x0, x16, [SP]
    // 0x87e8d4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x87e8d4: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x87e8d8: r0 = whereType()
    //     0x87e8d8: bl              #0xbfff48  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::whereType
    // 0x87e8dc: mov             x1, x0
    // 0x87e8e0: r0 = iterator()
    //     0x87e8e0: bl              #0xb0a4d8  ; [dart:_internal] WhereTypeIterable::iterator
    // 0x87e8e4: LoadField: r2 = r0->field_b
    //     0x87e8e4: ldur            w2, [x0, #0xb]
    // 0x87e8e8: DecompressPointer r2
    //     0x87e8e8: add             x2, x2, HEAP, lsl #32
    // 0x87e8ec: stur            x2, [fp, #-0x50]
    // 0x87e8f0: LoadField: r3 = r0->field_7
    //     0x87e8f0: ldur            w3, [x0, #7]
    // 0x87e8f4: DecompressPointer r3
    //     0x87e8f4: add             x3, x3, HEAP, lsl #32
    // 0x87e8f8: stur            x3, [fp, #-0x48]
    // 0x87e8fc: CheckStackOverflow
    //     0x87e8fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87e900: cmp             SP, x16
    //     0x87e904: b.ls            #0x87f498
    // 0x87e908: CheckStackOverflow
    //     0x87e908: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87e90c: cmp             SP, x16
    //     0x87e910: b.ls            #0x87f4a0
    // 0x87e914: r0 = LoadClassIdInstr(r2)
    //     0x87e914: ldur            x0, [x2, #-1]
    //     0x87e918: ubfx            x0, x0, #0xc, #0x14
    // 0x87e91c: mov             x1, x2
    // 0x87e920: r0 = GDT[cid_x0 + 0x1845b]()
    //     0x87e920: mov             x17, #0x845b
    //     0x87e924: movk            x17, #1, lsl #16
    //     0x87e928: add             lr, x0, x17
    //     0x87e92c: ldr             lr, [x21, lr, lsl #3]
    //     0x87e930: blr             lr
    // 0x87e934: tbnz            w0, #4, #0x87eb90
    // 0x87e938: ldur            x2, [fp, #-0x50]
    // 0x87e93c: r0 = LoadClassIdInstr(r2)
    //     0x87e93c: ldur            x0, [x2, #-1]
    //     0x87e940: ubfx            x0, x0, #0xc, #0x14
    // 0x87e944: mov             x1, x2
    // 0x87e948: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x87e948: mov             x17, #0x7d4c
    //     0x87e94c: movk            x17, #1, lsl #16
    //     0x87e950: add             lr, x0, x17
    //     0x87e954: ldr             lr, [x21, lr, lsl #3]
    //     0x87e958: blr             lr
    // 0x87e95c: ldur            x2, [fp, #-0x48]
    // 0x87e960: r1 = Null
    //     0x87e960: mov             x1, NULL
    // 0x87e964: cmp             w2, NULL
    // 0x87e968: b.eq            #0x87e9f4
    // 0x87e96c: ArrayLoad: r3 = r2[0]  ; List_4
    //     0x87e96c: ldur            w3, [x2, #0x17]
    // 0x87e970: DecompressPointer r3
    //     0x87e970: add             x3, x3, HEAP, lsl #32
    // 0x87e974: ldr             x16, [THR, #0xb8]  ; THR::dynamic_type
    // 0x87e978: cmp             w3, w16
    // 0x87e97c: b.eq            #0x87e9f4
    // 0x87e980: r16 = Object?
    //     0x87e980: ldr             x16, [PP, #0x380]  ; [pp+0x380] Type: Object?
    // 0x87e984: cmp             w3, w16
    // 0x87e988: b.eq            #0x87e9f4
    // 0x87e98c: r16 = void?
    //     0x87e98c: ldr             x16, [PP, #0x388]  ; [pp+0x388] Type: void?
    // 0x87e990: cmp             w3, w16
    // 0x87e994: b.eq            #0x87e9f4
    // 0x87e998: tbnz            w0, #0, #0x87e9b4
    // 0x87e99c: r16 = int
    //     0x87e99c: ldr             x16, [PP, #0x390]  ; [pp+0x390] Type: int
    // 0x87e9a0: cmp             w3, w16
    // 0x87e9a4: b.eq            #0x87e9f4
    // 0x87e9a8: r16 = num
    //     0x87e9a8: ldr             x16, [PP, #0x398]  ; [pp+0x398] Type: num
    // 0x87e9ac: cmp             w3, w16
    // 0x87e9b0: b.eq            #0x87e9f4
    // 0x87e9b4: r3 = SubtypeTestCache
    //     0x87e9b4: ldr             x3, [PP, #0x2340]  ; [pp+0x2340] SubtypeTestCache
    // 0x87e9b8: r30 = Subtype6TestCacheStub
    //     0x87e9b8: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0x87e9bc: LoadField: r30 = r30->field_7
    //     0x87e9bc: ldur            lr, [lr, #7]
    // 0x87e9c0: blr             lr
    // 0x87e9c4: cmp             w7, NULL
    // 0x87e9c8: b.eq            #0x87e9d4
    // 0x87e9cc: tbnz            w7, #4, #0x87e9ec
    // 0x87e9d0: b               #0x87e9f4
    // 0x87e9d4: r8 = X0
    //     0x87e9d4: ldr             x8, [PP, #0x2348]  ; [pp+0x2348] TypeParameter: X0
    // 0x87e9d8: r3 = SubtypeTestCache
    //     0x87e9d8: ldr             x3, [PP, #0x2350]  ; [pp+0x2350] SubtypeTestCache
    // 0x87e9dc: r30 = InstanceOfStub
    //     0x87e9dc: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x87e9e0: LoadField: r30 = r30->field_7
    //     0x87e9e0: ldur            lr, [lr, #7]
    // 0x87e9e4: blr             lr
    // 0x87e9e8: b               #0x87e9f8
    // 0x87e9ec: r0 = false
    //     0x87e9ec: add             x0, NULL, #0x30  ; false
    // 0x87e9f0: b               #0x87e9f8
    // 0x87e9f4: r0 = true
    //     0x87e9f4: add             x0, NULL, #0x20  ; true
    // 0x87e9f8: tbz             w0, #4, #0x87ea08
    // 0x87e9fc: ldur            x2, [fp, #-0x50]
    // 0x87ea00: ldur            x3, [fp, #-0x48]
    // 0x87ea04: b               #0x87e908
    // 0x87ea08: ldur            x2, [fp, #-0x50]
    // 0x87ea0c: r0 = LoadClassIdInstr(r2)
    //     0x87ea0c: ldur            x0, [x2, #-1]
    //     0x87ea10: ubfx            x0, x0, #0xc, #0x14
    // 0x87ea14: mov             x1, x2
    // 0x87ea18: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0x87ea18: mov             x17, #0x7d4c
    //     0x87ea1c: movk            x17, #1, lsl #16
    //     0x87ea20: add             lr, x0, x17
    //     0x87ea24: ldr             lr, [x21, lr, lsl #3]
    //     0x87ea28: blr             lr
    // 0x87ea2c: ldur            x2, [fp, #-0x48]
    // 0x87ea30: mov             x3, x0
    // 0x87ea34: r1 = Null
    //     0x87ea34: mov             x1, NULL
    // 0x87ea38: stur            x3, [fp, #-0x58]
    // 0x87ea3c: cmp             w2, NULL
    // 0x87ea40: b.eq            #0x87ea5c
    // 0x87ea44: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87ea44: ldur            w4, [x2, #0x17]
    // 0x87ea48: DecompressPointer r4
    //     0x87ea48: add             x4, x4, HEAP, lsl #32
    // 0x87ea4c: r8 = X0
    //     0x87ea4c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87ea50: LoadField: r9 = r4->field_7
    //     0x87ea50: ldur            x9, [x4, #7]
    // 0x87ea54: r3 = Null
    //     0x87ea54: ldr             x3, [PP, #0x2358]  ; [pp+0x2358] Null
    // 0x87ea58: blr             x9
    // 0x87ea5c: ldur            x0, [fp, #-0x58]
    // 0x87ea60: LoadField: r1 = r0->field_3b
    //     0x87ea60: ldur            w1, [x0, #0x3b]
    // 0x87ea64: DecompressPointer r1
    //     0x87ea64: add             x1, x1, HEAP, lsl #32
    // 0x87ea68: r0 = effective()
    //     0x87ea68: bl              #0x83794c  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::effective
    // 0x87ea6c: LoadField: r1 = r0->field_7
    //     0x87ea6c: ldur            w1, [x0, #7]
    // 0x87ea70: DecompressPointer r1
    //     0x87ea70: add             x1, x1, HEAP, lsl #32
    // 0x87ea74: tbnz            w1, #4, #0x87ea80
    // 0x87ea78: ldur            x0, [fp, #-0x58]
    // 0x87ea7c: b               #0x87ead8
    // 0x87ea80: ldur            x1, [fp, #-0x58]
    // 0x87ea84: r0 = parent()
    //     0x87ea84: bl              #0x837b3c  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::parent
    // 0x87ea88: cmp             w0, NULL
    // 0x87ea8c: b.ne            #0x87ea98
    // 0x87ea90: ldur            x0, [fp, #-0x58]
    // 0x87ea94: b               #0x87ead8
    // 0x87ea98: ldur            x1, [fp, #-0x58]
    // 0x87ea9c: r0 = contributesToSemanticsTree()
    //     0x87ea9c: bl              #0x895b80  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::contributesToSemanticsTree
    // 0x87eaa0: tbz             w0, #4, #0x87eaac
    // 0x87eaa4: ldur            x0, [fp, #-0x58]
    // 0x87eaa8: b               #0x87eae0
    // 0x87eaac: ldur            x0, [fp, #-0x58]
    // 0x87eab0: LoadField: r1 = r0->field_33
    //     0x87eab0: ldur            w1, [x0, #0x33]
    // 0x87eab4: DecompressPointer r1
    //     0x87eab4: add             x1, x1, HEAP, lsl #32
    // 0x87eab8: cmp             w1, NULL
    // 0x87eabc: b.eq            #0x87f4a8
    // 0x87eac0: LoadField: r2 = r1->field_13
    //     0x87eac0: ldur            w2, [x1, #0x13]
    // 0x87eac4: DecompressPointer r2
    //     0x87eac4: add             x2, x2, HEAP, lsl #32
    // 0x87eac8: tbz             w2, #4, #0x87ead8
    // 0x87eacc: LoadField: r1 = r0->field_b
    //     0x87eacc: ldur            w1, [x0, #0xb]
    // 0x87ead0: DecompressPointer r1
    //     0x87ead0: add             x1, x1, HEAP, lsl #32
    // 0x87ead4: tbnz            w1, #4, #0x87eae0
    // 0x87ead8: StoreField: r0->field_37 = rNULL
    //     0x87ead8: stur            NULL, [x0, #0x37]
    // 0x87eadc: b               #0x87eb2c
    // 0x87eae0: LoadField: r1 = r0->field_27
    //     0x87eae0: ldur            w1, [x0, #0x27]
    // 0x87eae4: DecompressPointer r1
    //     0x87eae4: add             x1, x1, HEAP, lsl #32
    // 0x87eae8: LoadField: r0 = r1->field_b
    //     0x87eae8: ldur            w0, [x1, #0xb]
    // 0x87eaec: r2 = LoadInt32Instr(r0)
    //     0x87eaec: sbfx            x2, x0, #1, #0x1f
    // 0x87eaf0: LoadField: r0 = r1->field_f
    //     0x87eaf0: ldur            w0, [x1, #0xf]
    // 0x87eaf4: DecompressPointer r0
    //     0x87eaf4: add             x0, x0, HEAP, lsl #32
    // 0x87eaf8: r1 = 0
    //     0x87eaf8: mov             x1, #0
    // 0x87eafc: CheckStackOverflow
    //     0x87eafc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87eb00: cmp             SP, x16
    //     0x87eb04: b.ls            #0x87f4ac
    // 0x87eb08: cmp             x1, x2
    // 0x87eb0c: b.ge            #0x87eb2c
    // 0x87eb10: ArrayLoad: r3 = r0[r1]  ; Unknown_4
    //     0x87eb10: add             x16, x0, x1, lsl #2
    //     0x87eb14: ldur            w3, [x16, #0xf]
    // 0x87eb18: DecompressPointer r3
    //     0x87eb18: add             x3, x3, HEAP, lsl #32
    // 0x87eb1c: add             x4, x1, #1
    // 0x87eb20: StoreField: r3->field_37 = rNULL
    //     0x87eb20: stur            NULL, [x3, #0x37]
    // 0x87eb24: mov             x1, x4
    // 0x87eb28: b               #0x87eafc
    // 0x87eb2c: ldur            x2, [fp, #-0x50]
    // 0x87eb30: ldur            x3, [fp, #-0x48]
    // 0x87eb34: b               #0x87e8fc
    // 0x87eb38: ldur            x0, [fp, #-0x18]
    // 0x87eb3c: LoadField: r1 = r0->field_43
    //     0x87eb3c: ldur            w1, [x0, #0x43]
    // 0x87eb40: DecompressPointer r1
    //     0x87eb40: add             x1, x1, HEAP, lsl #32
    // 0x87eb44: LoadField: r0 = r1->field_27
    //     0x87eb44: ldur            w0, [x1, #0x27]
    // 0x87eb48: DecompressPointer r0
    //     0x87eb48: add             x0, x0, HEAP, lsl #32
    // 0x87eb4c: LoadField: r1 = r0->field_b
    //     0x87eb4c: ldur            w1, [x0, #0xb]
    // 0x87eb50: r2 = LoadInt32Instr(r1)
    //     0x87eb50: sbfx            x2, x1, #1, #0x1f
    // 0x87eb54: LoadField: r1 = r0->field_f
    //     0x87eb54: ldur            w1, [x0, #0xf]
    // 0x87eb58: DecompressPointer r1
    //     0x87eb58: add             x1, x1, HEAP, lsl #32
    // 0x87eb5c: r0 = 0
    //     0x87eb5c: mov             x0, #0
    // 0x87eb60: CheckStackOverflow
    //     0x87eb60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87eb64: cmp             SP, x16
    //     0x87eb68: b.ls            #0x87f4b4
    // 0x87eb6c: cmp             x0, x2
    // 0x87eb70: b.ge            #0x87eb90
    // 0x87eb74: ArrayLoad: r3 = r1[r0]  ; Unknown_4
    //     0x87eb74: add             x16, x1, x0, lsl #2
    //     0x87eb78: ldur            w3, [x16, #0xf]
    // 0x87eb7c: DecompressPointer r3
    //     0x87eb7c: add             x3, x3, HEAP, lsl #32
    // 0x87eb80: add             x4, x0, #1
    // 0x87eb84: StoreField: r3->field_37 = rNULL
    //     0x87eb84: stur            NULL, [x3, #0x37]
    // 0x87eb88: mov             x0, x4
    // 0x87eb8c: b               #0x87eb60
    // 0x87eb90: ldur            x0, [fp, #-0x28]
    // 0x87eb94: ldur            x3, [fp, #-0x10]
    // 0x87eb98: ldur            x4, [fp, #-0x40]
    // 0x87eb9c: ldur            x5, [fp, #-0x30]
    // 0x87eba0: b               #0x87e7ac
    // 0x87eba4: r0 = Object()
    //     0x87eba4: bl              #0x7ed2a0  ; AllocateObjectStub -> Object (size=0x8)
    // 0x87eba8: r1 = <_RenderObjectSemantics>
    //     0x87eba8: ldr             x1, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x87ebac: stur            x0, [fp, #-0x18]
    // 0x87ebb0: r0 = _Set()
    //     0x87ebb0: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x87ebb4: mov             x4, x0
    // 0x87ebb8: r3 = _Uint32List
    //     0x87ebb8: ldr             x3, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x87ebbc: stur            x4, [fp, #-0x50]
    // 0x87ebc0: StoreField: r4->field_1b = r3
    //     0x87ebc0: stur            w3, [x4, #0x1b]
    // 0x87ebc4: StoreField: r4->field_b = rZR
    //     0x87ebc4: stur            wzr, [x4, #0xb]
    // 0x87ebc8: r5 = const []
    //     0x87ebc8: ldr             x5, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x87ebcc: StoreField: r4->field_f = r5
    //     0x87ebcc: stur            w5, [x4, #0xf]
    // 0x87ebd0: StoreField: r4->field_13 = rZR
    //     0x87ebd0: stur            wzr, [x4, #0x13]
    // 0x87ebd4: ArrayStore: r4[0] = rZR  ; List_4
    //     0x87ebd4: stur            wzr, [x4, #0x17]
    // 0x87ebd8: r0 = 0
    //     0x87ebd8: mov             x0, #0
    // 0x87ebdc: ldur            x7, [fp, #-0x10]
    // 0x87ebe0: ldur            x6, [fp, #-0x60]
    // 0x87ebe4: CheckStackOverflow
    //     0x87ebe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87ebe8: cmp             SP, x16
    //     0x87ebec: b.ls            #0x87f4bc
    // 0x87ebf0: LoadField: r1 = r7->field_b
    //     0x87ebf0: ldur            w1, [x7, #0xb]
    // 0x87ebf4: r2 = LoadInt32Instr(r1)
    //     0x87ebf4: sbfx            x2, x1, #1, #0x1f
    // 0x87ebf8: cmp             x6, x2
    // 0x87ebfc: b.ne            #0x87f420
    // 0x87ec00: cmp             x0, x2
    // 0x87ec04: b.ge            #0x87ecc4
    // 0x87ec08: LoadField: r1 = r7->field_f
    //     0x87ec08: ldur            w1, [x7, #0xf]
    // 0x87ec0c: DecompressPointer r1
    //     0x87ec0c: add             x1, x1, HEAP, lsl #32
    // 0x87ec10: ArrayLoad: r8 = r1[r0]  ; Unknown_4
    //     0x87ec10: add             x16, x1, x0, lsl #2
    //     0x87ec14: ldur            w8, [x16, #0xf]
    // 0x87ec18: DecompressPointer r8
    //     0x87ec18: add             x8, x8, HEAP, lsl #32
    // 0x87ec1c: stur            x8, [fp, #-0x48]
    // 0x87ec20: add             x9, x0, #1
    // 0x87ec24: stur            x9, [fp, #-0x28]
    // 0x87ec28: cmp             w8, NULL
    // 0x87ec2c: b.ne            #0x87ec5c
    // 0x87ec30: mov             x0, x8
    // 0x87ec34: ldur            x2, [fp, #-0x40]
    // 0x87ec38: r1 = Null
    //     0x87ec38: mov             x1, NULL
    // 0x87ec3c: cmp             w2, NULL
    // 0x87ec40: b.eq            #0x87ec5c
    // 0x87ec44: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87ec44: ldur            w4, [x2, #0x17]
    // 0x87ec48: DecompressPointer r4
    //     0x87ec48: add             x4, x4, HEAP, lsl #32
    // 0x87ec4c: r8 = X0
    //     0x87ec4c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87ec50: LoadField: r9 = r4->field_7
    //     0x87ec50: ldur            x9, [x4, #7]
    // 0x87ec54: r3 = Null
    //     0x87ec54: ldr             x3, [PP, #0x2368]  ; [pp+0x2368] Null
    // 0x87ec58: blr             x9
    // 0x87ec5c: ldur            x0, [fp, #-0x48]
    // 0x87ec60: mov             x1, x0
    // 0x87ec64: LoadField: r0 = r1->field_43
    //     0x87ec64: ldur            w0, [x1, #0x43]
    // 0x87ec68: DecompressPointer r0
    //     0x87ec68: add             x0, x0, HEAP, lsl #32
    // 0x87ec6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87ec70: cmp             w0, w16
    // 0x87ec74: b.ne            #0x87ec80
    // 0x87ec78: r2 = _semantics
    //     0x87ec78: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x87ec7c: r0 = InitLateFinalInstanceField()
    //     0x87ec7c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x87ec80: mov             x1, x0
    // 0x87ec84: ldur            x2, [fp, #-0x18]
    // 0x87ec88: r0 = computeAncestorInfo()
    //     0x87ec88: bl              #0x895878  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::computeAncestorInfo
    // 0x87ec8c: ldur            x0, [fp, #-0x48]
    // 0x87ec90: LoadField: r1 = r0->field_43
    //     0x87ec90: ldur            w1, [x0, #0x43]
    // 0x87ec94: DecompressPointer r1
    //     0x87ec94: add             x1, x1, HEAP, lsl #32
    // 0x87ec98: LoadField: r2 = r1->field_47
    //     0x87ec98: ldur            w2, [x1, #0x47]
    // 0x87ec9c: DecompressPointer r2
    //     0x87ec9c: add             x2, x2, HEAP, lsl #32
    // 0x87eca0: cmp             w2, NULL
    // 0x87eca4: b.eq            #0x87ecb0
    // 0x87eca8: ldur            x1, [fp, #-0x50]
    // 0x87ecac: r0 = add()
    //     0x87ecac: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x87ecb0: ldur            x0, [fp, #-0x28]
    // 0x87ecb4: ldur            x4, [fp, #-0x50]
    // 0x87ecb8: r3 = _Uint32List
    //     0x87ecb8: ldr             x3, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x87ecbc: r5 = const []
    //     0x87ecbc: ldr             x5, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x87ecc0: b               #0x87ebdc
    // 0x87ecc4: ldur            x1, [fp, #-0x50]
    // 0x87ecc8: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x87ecc8: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x87eccc: r0 = toList()
    //     0x87eccc: bl              #0xbb6638  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::toList
    // 0x87ecd0: r1 = Function '<anonymous closure>':.
    //     0x87ecd0: ldr             x1, [PP, #0x2378]  ; [pp+0x2378] AnonymousClosure: (0x898664), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x87e550)
    // 0x87ecd4: r2 = Null
    //     0x87ecd4: mov             x2, NULL
    // 0x87ecd8: stur            x0, [fp, #-0x40]
    // 0x87ecdc: r0 = AllocateClosure()
    //     0x87ecdc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x87ece0: str             x0, [SP]
    // 0x87ece4: ldur            x1, [fp, #-0x40]
    // 0x87ece8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x87ece8: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x87ecec: r0 = sort()
    //     0x87ecec: bl              #0x9f9bf0  ; [dart:collection] ListBase::sort
    // 0x87ecf0: ldur            x3, [fp, #-0x40]
    // 0x87ecf4: LoadField: r4 = r3->field_7
    //     0x87ecf4: ldur            w4, [x3, #7]
    // 0x87ecf8: DecompressPointer r4
    //     0x87ecf8: add             x4, x4, HEAP, lsl #32
    // 0x87ecfc: stur            x4, [fp, #-0x50]
    // 0x87ed00: LoadField: r0 = r3->field_b
    //     0x87ed00: ldur            w0, [x3, #0xb]
    // 0x87ed04: r5 = LoadInt32Instr(r0)
    //     0x87ed04: sbfx            x5, x0, #1, #0x1f
    // 0x87ed08: stur            x5, [fp, #-0x30]
    // 0x87ed0c: r0 = 0
    //     0x87ed0c: mov             x0, #0
    // 0x87ed10: CheckStackOverflow
    //     0x87ed10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87ed14: cmp             SP, x16
    //     0x87ed18: b.ls            #0x87f4c4
    // 0x87ed1c: LoadField: r1 = r3->field_b
    //     0x87ed1c: ldur            w1, [x3, #0xb]
    // 0x87ed20: r2 = LoadInt32Instr(r1)
    //     0x87ed20: sbfx            x2, x1, #1, #0x1f
    // 0x87ed24: cmp             x5, x2
    // 0x87ed28: b.ne            #0x87f400
    // 0x87ed2c: cmp             x0, x2
    // 0x87ed30: b.ge            #0x87eda4
    // 0x87ed34: LoadField: r1 = r3->field_f
    //     0x87ed34: ldur            w1, [x3, #0xf]
    // 0x87ed38: DecompressPointer r1
    //     0x87ed38: add             x1, x1, HEAP, lsl #32
    // 0x87ed3c: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x87ed3c: add             x16, x1, x0, lsl #2
    //     0x87ed40: ldur            w6, [x16, #0xf]
    // 0x87ed44: DecompressPointer r6
    //     0x87ed44: add             x6, x6, HEAP, lsl #32
    // 0x87ed48: stur            x6, [fp, #-0x48]
    // 0x87ed4c: add             x7, x0, #1
    // 0x87ed50: stur            x7, [fp, #-0x28]
    // 0x87ed54: cmp             w6, NULL
    // 0x87ed58: b.ne            #0x87ed88
    // 0x87ed5c: mov             x0, x6
    // 0x87ed60: mov             x2, x4
    // 0x87ed64: r1 = Null
    //     0x87ed64: mov             x1, NULL
    // 0x87ed68: cmp             w2, NULL
    // 0x87ed6c: b.eq            #0x87ed88
    // 0x87ed70: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87ed70: ldur            w4, [x2, #0x17]
    // 0x87ed74: DecompressPointer r4
    //     0x87ed74: add             x4, x4, HEAP, lsl #32
    // 0x87ed78: r8 = X0
    //     0x87ed78: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87ed7c: LoadField: r9 = r4->field_7
    //     0x87ed7c: ldur            x9, [x4, #7]
    // 0x87ed80: r3 = Null
    //     0x87ed80: ldr             x3, [PP, #0x2380]  ; [pp+0x2380] Null
    // 0x87ed84: blr             x9
    // 0x87ed88: ldur            x1, [fp, #-0x48]
    // 0x87ed8c: r0 = ensureGeometry()
    //     0x87ed8c: bl              #0x89517c  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::ensureGeometry
    // 0x87ed90: ldur            x0, [fp, #-0x28]
    // 0x87ed94: ldur            x3, [fp, #-0x40]
    // 0x87ed98: ldur            x4, [fp, #-0x50]
    // 0x87ed9c: ldur            x5, [fp, #-0x30]
    // 0x87eda0: b               #0x87ed10
    // 0x87eda4: ldur            x0, [fp, #-0x20]
    // 0x87eda8: ldur            x1, [fp, #-0x38]
    // 0x87edac: r0 = ReversedListIterable()
    //     0x87edac: bl              #0x7da320  ; AllocateReversedListIterableStub -> ReversedListIterable<X0> (size=0x10)
    // 0x87edb0: mov             x1, x0
    // 0x87edb4: ldur            x0, [fp, #-0x20]
    // 0x87edb8: StoreField: r1->field_b = r0
    //     0x87edb8: stur            w0, [x1, #0xb]
    // 0x87edbc: r0 = iterator()
    //     0x87edbc: bl              #0xb12cf4  ; [dart:collection] ListBase::iterator
    // 0x87edc0: mov             x1, x0
    // 0x87edc4: stur            x1, [fp, #-0x50]
    // 0x87edc8: LoadField: r2 = r1->field_b
    //     0x87edc8: ldur            w2, [x1, #0xb]
    // 0x87edcc: DecompressPointer r2
    //     0x87edcc: add             x2, x2, HEAP, lsl #32
    // 0x87edd0: stur            x2, [fp, #-0x48]
    // 0x87edd4: LoadField: r3 = r1->field_f
    //     0x87edd4: ldur            x3, [x1, #0xf]
    // 0x87edd8: stur            x3, [fp, #-0x28]
    // 0x87eddc: LoadField: r4 = r1->field_7
    //     0x87eddc: ldur            w4, [x1, #7]
    // 0x87ede0: DecompressPointer r4
    //     0x87ede0: add             x4, x4, HEAP, lsl #32
    // 0x87ede4: stur            x4, [fp, #-0x38]
    // 0x87ede8: CheckStackOverflow
    //     0x87ede8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87edec: cmp             SP, x16
    //     0x87edf0: b.ls            #0x87f4cc
    // 0x87edf4: r0 = LoadClassIdInstr(r2)
    //     0x87edf4: ldur            x0, [x2, #-1]
    //     0x87edf8: ubfx            x0, x0, #0xc, #0x14
    // 0x87edfc: str             x2, [SP]
    // 0x87ee00: r0 = GDT[cid_x0 + 0xf078]()
    //     0x87ee00: mov             x17, #0xf078
    //     0x87ee04: add             lr, x0, x17
    //     0x87ee08: ldr             lr, [x21, lr, lsl #3]
    //     0x87ee0c: blr             lr
    // 0x87ee10: r1 = LoadInt32Instr(r0)
    //     0x87ee10: sbfx            x1, x0, #1, #0x1f
    //     0x87ee14: tbz             w0, #0, #0x87ee1c
    //     0x87ee18: ldur            x1, [x0, #7]
    // 0x87ee1c: ldur            x3, [fp, #-0x28]
    // 0x87ee20: cmp             x3, x1
    // 0x87ee24: b.ne            #0x87f3e0
    // 0x87ee28: ldur            x4, [fp, #-0x50]
    // 0x87ee2c: ArrayLoad: r2 = r4[0]  ; List_8
    //     0x87ee2c: ldur            x2, [x4, #0x17]
    // 0x87ee30: cmp             x2, x1
    // 0x87ee34: b.ge            #0x87f300
    // 0x87ee38: ldur            x5, [fp, #-0x48]
    // 0x87ee3c: r0 = LoadClassIdInstr(r5)
    //     0x87ee3c: ldur            x0, [x5, #-1]
    //     0x87ee40: ubfx            x0, x0, #0xc, #0x14
    // 0x87ee44: mov             x1, x5
    // 0x87ee48: r0 = GDT[cid_x0 + 0x12eb9]()
    //     0x87ee48: mov             x17, #0x2eb9
    //     0x87ee4c: movk            x17, #1, lsl #16
    //     0x87ee50: add             lr, x0, x17
    //     0x87ee54: ldr             lr, [x21, lr, lsl #3]
    //     0x87ee58: blr             lr
    // 0x87ee5c: mov             x4, x0
    // 0x87ee60: ldur            x3, [fp, #-0x50]
    // 0x87ee64: stur            x4, [fp, #-0x58]
    // 0x87ee68: StoreField: r3->field_1f = r0
    //     0x87ee68: stur            w0, [x3, #0x1f]
    //     0x87ee6c: tbz             w0, #0, #0x87ee88
    //     0x87ee70: ldurb           w16, [x3, #-1]
    //     0x87ee74: ldurb           w17, [x0, #-1]
    //     0x87ee78: and             x16, x17, x16, lsr #2
    //     0x87ee7c: tst             x16, HEAP, lsr #32
    //     0x87ee80: b.eq            #0x87ee88
    //     0x87ee84: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x87ee88: ArrayLoad: r0 = r3[0]  ; List_8
    //     0x87ee88: ldur            x0, [x3, #0x17]
    // 0x87ee8c: add             x1, x0, #1
    // 0x87ee90: ArrayStore: r3[0] = r1  ; List_8
    //     0x87ee90: stur            x1, [x3, #0x17]
    // 0x87ee94: cmp             w4, NULL
    // 0x87ee98: b.ne            #0x87eec8
    // 0x87ee9c: mov             x0, x4
    // 0x87eea0: ldur            x2, [fp, #-0x38]
    // 0x87eea4: r1 = Null
    //     0x87eea4: mov             x1, NULL
    // 0x87eea8: cmp             w2, NULL
    // 0x87eeac: b.eq            #0x87eec8
    // 0x87eeb0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87eeb0: ldur            w4, [x2, #0x17]
    // 0x87eeb4: DecompressPointer r4
    //     0x87eeb4: add             x4, x4, HEAP, lsl #32
    // 0x87eeb8: r8 = X0
    //     0x87eeb8: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87eebc: LoadField: r9 = r4->field_7
    //     0x87eebc: ldur            x9, [x4, #7]
    // 0x87eec0: r3 = Null
    //     0x87eec0: ldr             x3, [PP, #0x2390]  ; [pp+0x2390] Null
    // 0x87eec4: blr             x9
    // 0x87eec8: ldur            x0, [fp, #-0x58]
    // 0x87eecc: mov             x1, x0
    // 0x87eed0: LoadField: r0 = r1->field_43
    //     0x87eed0: ldur            w0, [x1, #0x43]
    // 0x87eed4: DecompressPointer r0
    //     0x87eed4: add             x0, x0, HEAP, lsl #32
    // 0x87eed8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x87eedc: cmp             w0, w16
    // 0x87eee0: b.ne            #0x87eeec
    // 0x87eee4: r2 = _semantics
    //     0x87eee4: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x87eee8: r0 = InitLateFinalInstanceField()
    //     0x87eee8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x87eeec: mov             x1, x0
    // 0x87eef0: ldur            x2, [fp, #-0x18]
    // 0x87eef4: r0 = computeAncestorInfo()
    //     0x87eef4: bl              #0x895878  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::computeAncestorInfo
    // 0x87eef8: r1 = <_RenderObjectSemantics>
    //     0x87eef8: ldr             x1, [PP, #0x2338]  ; [pp+0x2338] TypeArguments: <_RenderObjectSemantics>
    // 0x87eefc: r2 = 0
    //     0x87eefc: mov             x2, #0
    // 0x87ef00: r0 = _GrowableList()
    //     0x87ef00: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x87ef04: mov             x2, x0
    // 0x87ef08: ldur            x0, [fp, #-0x58]
    // 0x87ef0c: stur            x2, [fp, #-0x68]
    // 0x87ef10: LoadField: r1 = r0->field_43
    //     0x87ef10: ldur            w1, [x0, #0x43]
    // 0x87ef14: DecompressPointer r1
    //     0x87ef14: add             x1, x1, HEAP, lsl #32
    // 0x87ef18: r0 = geometryDirty()
    //     0x87ef18: bl              #0x895c38  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::geometryDirty
    // 0x87ef1c: tbnz            w0, #4, #0x87efc4
    // 0x87ef20: ldur            x0, [fp, #-0x58]
    // 0x87ef24: LoadField: r1 = r0->field_43
    //     0x87ef24: ldur            w1, [x0, #0x43]
    // 0x87ef28: DecompressPointer r1
    //     0x87ef28: add             x1, x1, HEAP, lsl #32
    // 0x87ef2c: LoadField: r0 = r1->field_47
    //     0x87ef2c: ldur            w0, [x1, #0x47]
    // 0x87ef30: DecompressPointer r0
    //     0x87ef30: add             x0, x0, HEAP, lsl #32
    // 0x87ef34: stur            x0, [fp, #-0x70]
    // 0x87ef38: cmp             w0, NULL
    // 0x87ef3c: b.eq            #0x87efbc
    // 0x87ef40: ldur            x2, [fp, #-0x68]
    // 0x87ef44: LoadField: r1 = r2->field_b
    //     0x87ef44: ldur            w1, [x2, #0xb]
    // 0x87ef48: LoadField: r3 = r2->field_f
    //     0x87ef48: ldur            w3, [x2, #0xf]
    // 0x87ef4c: DecompressPointer r3
    //     0x87ef4c: add             x3, x3, HEAP, lsl #32
    // 0x87ef50: LoadField: r4 = r3->field_b
    //     0x87ef50: ldur            w4, [x3, #0xb]
    // 0x87ef54: r3 = LoadInt32Instr(r1)
    //     0x87ef54: sbfx            x3, x1, #1, #0x1f
    // 0x87ef58: stur            x3, [fp, #-0x30]
    // 0x87ef5c: r1 = LoadInt32Instr(r4)
    //     0x87ef5c: sbfx            x1, x4, #1, #0x1f
    // 0x87ef60: cmp             x3, x1
    // 0x87ef64: b.ne            #0x87ef70
    // 0x87ef68: mov             x1, x2
    // 0x87ef6c: r0 = _growToNextCapacity()
    //     0x87ef6c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87ef70: ldur            x2, [fp, #-0x68]
    // 0x87ef74: ldur            x3, [fp, #-0x30]
    // 0x87ef78: add             x0, x3, #1
    // 0x87ef7c: lsl             x1, x0, #1
    // 0x87ef80: StoreField: r2->field_b = r1
    //     0x87ef80: stur            w1, [x2, #0xb]
    // 0x87ef84: LoadField: r1 = r2->field_f
    //     0x87ef84: ldur            w1, [x2, #0xf]
    // 0x87ef88: DecompressPointer r1
    //     0x87ef88: add             x1, x1, HEAP, lsl #32
    // 0x87ef8c: ldur            x0, [fp, #-0x70]
    // 0x87ef90: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87ef90: add             x25, x1, x3, lsl #2
    //     0x87ef94: add             x25, x25, #0xf
    //     0x87ef98: str             w0, [x25]
    //     0x87ef9c: tbz             w0, #0, #0x87efb8
    //     0x87efa0: ldurb           w16, [x1, #-1]
    //     0x87efa4: ldurb           w17, [x0, #-1]
    //     0x87efa8: and             x16, x17, x16, lsr #2
    //     0x87efac: tst             x16, HEAP, lsr #32
    //     0x87efb0: b.eq            #0x87efb8
    //     0x87efb4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x87efb8: b               #0x87f1d8
    // 0x87efbc: ldur            x2, [fp, #-0x68]
    // 0x87efc0: b               #0x87f1d8
    // 0x87efc4: ldur            x2, [fp, #-0x68]
    // 0x87efc8: ldur            x0, [fp, #-0x58]
    // 0x87efcc: LoadField: r1 = r0->field_43
    //     0x87efcc: ldur            w1, [x0, #0x43]
    // 0x87efd0: DecompressPointer r1
    //     0x87efd0: add             x1, x1, HEAP, lsl #32
    // 0x87efd4: LoadField: r3 = r1->field_37
    //     0x87efd4: ldur            w3, [x1, #0x37]
    // 0x87efd8: DecompressPointer r3
    //     0x87efd8: add             x3, x3, HEAP, lsl #32
    // 0x87efdc: cmp             w3, NULL
    // 0x87efe0: b.eq            #0x87f4d4
    // 0x87efe4: mov             x1, x3
    // 0x87efe8: r0 = isVisible()
    //     0x87efe8: bl              #0x895100  ; [package:flutter/src/rendering/object.dart] _SemanticsGeometry::isVisible
    // 0x87efec: tbz             w0, #4, #0x87f150
    // 0x87eff0: ldur            x0, [fp, #-0x58]
    // 0x87eff4: LoadField: r1 = r0->field_43
    //     0x87eff4: ldur            w1, [x0, #0x43]
    // 0x87eff8: DecompressPointer r1
    //     0x87eff8: add             x1, x1, HEAP, lsl #32
    // 0x87effc: r0 = isRoot()
    //     0x87effc: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x87f000: tbz             w0, #4, #0x87f148
    // 0x87f004: ldur            x0, [fp, #-0x58]
    // 0x87f008: LoadField: r1 = r0->field_43
    //     0x87f008: ldur            w1, [x0, #0x43]
    // 0x87f00c: DecompressPointer r1
    //     0x87f00c: add             x1, x1, HEAP, lsl #32
    // 0x87f010: LoadField: r2 = r1->field_3f
    //     0x87f010: ldur            w2, [x1, #0x3f]
    // 0x87f014: DecompressPointer r2
    //     0x87f014: add             x2, x2, HEAP, lsl #32
    // 0x87f018: stur            x2, [fp, #-0x70]
    // 0x87f01c: cmp             w2, NULL
    // 0x87f020: b.eq            #0x87f140
    // 0x87f024: mov             x1, x2
    // 0x87f028: r0 = geometryDirty()
    //     0x87f028: bl              #0x895c38  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::geometryDirty
    // 0x87f02c: tbz             w0, #4, #0x87f0ac
    // 0x87f030: ldur            x0, [fp, #-0x68]
    // 0x87f034: LoadField: r1 = r0->field_b
    //     0x87f034: ldur            w1, [x0, #0xb]
    // 0x87f038: LoadField: r2 = r0->field_f
    //     0x87f038: ldur            w2, [x0, #0xf]
    // 0x87f03c: DecompressPointer r2
    //     0x87f03c: add             x2, x2, HEAP, lsl #32
    // 0x87f040: LoadField: r3 = r2->field_b
    //     0x87f040: ldur            w3, [x2, #0xb]
    // 0x87f044: r2 = LoadInt32Instr(r1)
    //     0x87f044: sbfx            x2, x1, #1, #0x1f
    // 0x87f048: stur            x2, [fp, #-0x30]
    // 0x87f04c: r1 = LoadInt32Instr(r3)
    //     0x87f04c: sbfx            x1, x3, #1, #0x1f
    // 0x87f050: cmp             x2, x1
    // 0x87f054: b.ne            #0x87f060
    // 0x87f058: mov             x1, x0
    // 0x87f05c: r0 = _growToNextCapacity()
    //     0x87f05c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87f060: ldur            x2, [fp, #-0x68]
    // 0x87f064: ldur            x3, [fp, #-0x30]
    // 0x87f068: add             x0, x3, #1
    // 0x87f06c: lsl             x1, x0, #1
    // 0x87f070: StoreField: r2->field_b = r1
    //     0x87f070: stur            w1, [x2, #0xb]
    // 0x87f074: LoadField: r1 = r2->field_f
    //     0x87f074: ldur            w1, [x2, #0xf]
    // 0x87f078: DecompressPointer r1
    //     0x87f078: add             x1, x1, HEAP, lsl #32
    // 0x87f07c: ldur            x0, [fp, #-0x70]
    // 0x87f080: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87f080: add             x25, x1, x3, lsl #2
    //     0x87f084: add             x25, x25, #0xf
    //     0x87f088: str             w0, [x25]
    //     0x87f08c: tbz             w0, #0, #0x87f0a8
    //     0x87f090: ldurb           w16, [x1, #-1]
    //     0x87f094: ldurb           w17, [x0, #-1]
    //     0x87f098: and             x16, x17, x16, lsr #2
    //     0x87f09c: tst             x16, HEAP, lsr #32
    //     0x87f0a0: b.eq            #0x87f0a8
    //     0x87f0a4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x87f0a8: b               #0x87f154
    // 0x87f0ac: ldur            x2, [fp, #-0x68]
    // 0x87f0b0: ldur            x0, [fp, #-0x70]
    // 0x87f0b4: LoadField: r3 = r0->field_47
    //     0x87f0b4: ldur            w3, [x0, #0x47]
    // 0x87f0b8: DecompressPointer r3
    //     0x87f0b8: add             x3, x3, HEAP, lsl #32
    // 0x87f0bc: stur            x3, [fp, #-0x78]
    // 0x87f0c0: cmp             w3, NULL
    // 0x87f0c4: b.eq            #0x87f154
    // 0x87f0c8: LoadField: r0 = r2->field_b
    //     0x87f0c8: ldur            w0, [x2, #0xb]
    // 0x87f0cc: LoadField: r1 = r2->field_f
    //     0x87f0cc: ldur            w1, [x2, #0xf]
    // 0x87f0d0: DecompressPointer r1
    //     0x87f0d0: add             x1, x1, HEAP, lsl #32
    // 0x87f0d4: LoadField: r4 = r1->field_b
    //     0x87f0d4: ldur            w4, [x1, #0xb]
    // 0x87f0d8: r5 = LoadInt32Instr(r0)
    //     0x87f0d8: sbfx            x5, x0, #1, #0x1f
    // 0x87f0dc: stur            x5, [fp, #-0x30]
    // 0x87f0e0: r0 = LoadInt32Instr(r4)
    //     0x87f0e0: sbfx            x0, x4, #1, #0x1f
    // 0x87f0e4: cmp             x5, x0
    // 0x87f0e8: b.ne            #0x87f0f4
    // 0x87f0ec: mov             x1, x2
    // 0x87f0f0: r0 = _growToNextCapacity()
    //     0x87f0f0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87f0f4: ldur            x2, [fp, #-0x68]
    // 0x87f0f8: ldur            x3, [fp, #-0x30]
    // 0x87f0fc: add             x0, x3, #1
    // 0x87f100: lsl             x1, x0, #1
    // 0x87f104: StoreField: r2->field_b = r1
    //     0x87f104: stur            w1, [x2, #0xb]
    // 0x87f108: LoadField: r1 = r2->field_f
    //     0x87f108: ldur            w1, [x2, #0xf]
    // 0x87f10c: DecompressPointer r1
    //     0x87f10c: add             x1, x1, HEAP, lsl #32
    // 0x87f110: ldur            x0, [fp, #-0x78]
    // 0x87f114: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87f114: add             x25, x1, x3, lsl #2
    //     0x87f118: add             x25, x25, #0xf
    //     0x87f11c: str             w0, [x25]
    //     0x87f120: tbz             w0, #0, #0x87f13c
    //     0x87f124: ldurb           w16, [x1, #-1]
    //     0x87f128: ldurb           w17, [x0, #-1]
    //     0x87f12c: and             x16, x17, x16, lsr #2
    //     0x87f130: tst             x16, HEAP, lsr #32
    //     0x87f134: b.eq            #0x87f13c
    //     0x87f138: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x87f13c: b               #0x87f154
    // 0x87f140: ldur            x2, [fp, #-0x68]
    // 0x87f144: b               #0x87f154
    // 0x87f148: ldur            x2, [fp, #-0x68]
    // 0x87f14c: b               #0x87f154
    // 0x87f150: ldur            x2, [fp, #-0x68]
    // 0x87f154: ldur            x0, [fp, #-0x58]
    // 0x87f158: LoadField: r3 = r0->field_43
    //     0x87f158: ldur            w3, [x0, #0x43]
    // 0x87f15c: DecompressPointer r3
    //     0x87f15c: add             x3, x3, HEAP, lsl #32
    // 0x87f160: stur            x3, [fp, #-0x70]
    // 0x87f164: LoadField: r0 = r2->field_b
    //     0x87f164: ldur            w0, [x2, #0xb]
    // 0x87f168: LoadField: r1 = r2->field_f
    //     0x87f168: ldur            w1, [x2, #0xf]
    // 0x87f16c: DecompressPointer r1
    //     0x87f16c: add             x1, x1, HEAP, lsl #32
    // 0x87f170: LoadField: r4 = r1->field_b
    //     0x87f170: ldur            w4, [x1, #0xb]
    // 0x87f174: r5 = LoadInt32Instr(r0)
    //     0x87f174: sbfx            x5, x0, #1, #0x1f
    // 0x87f178: stur            x5, [fp, #-0x30]
    // 0x87f17c: r0 = LoadInt32Instr(r4)
    //     0x87f17c: sbfx            x0, x4, #1, #0x1f
    // 0x87f180: cmp             x5, x0
    // 0x87f184: b.ne            #0x87f190
    // 0x87f188: mov             x1, x2
    // 0x87f18c: r0 = _growToNextCapacity()
    //     0x87f18c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87f190: ldur            x2, [fp, #-0x68]
    // 0x87f194: ldur            x3, [fp, #-0x30]
    // 0x87f198: add             x0, x3, #1
    // 0x87f19c: lsl             x1, x0, #1
    // 0x87f1a0: StoreField: r2->field_b = r1
    //     0x87f1a0: stur            w1, [x2, #0xb]
    // 0x87f1a4: LoadField: r1 = r2->field_f
    //     0x87f1a4: ldur            w1, [x2, #0xf]
    // 0x87f1a8: DecompressPointer r1
    //     0x87f1a8: add             x1, x1, HEAP, lsl #32
    // 0x87f1ac: ldur            x0, [fp, #-0x70]
    // 0x87f1b0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x87f1b0: add             x25, x1, x3, lsl #2
    //     0x87f1b4: add             x25, x25, #0xf
    //     0x87f1b8: str             w0, [x25]
    //     0x87f1bc: tbz             w0, #0, #0x87f1d8
    //     0x87f1c0: ldurb           w16, [x1, #-1]
    //     0x87f1c4: ldurb           w17, [x0, #-1]
    //     0x87f1c8: and             x16, x17, x16, lsr #2
    //     0x87f1cc: tst             x16, HEAP, lsr #32
    //     0x87f1d0: b.eq            #0x87f1d8
    //     0x87f1d4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x87f1d8: LoadField: r0 = r2->field_b
    //     0x87f1d8: ldur            w0, [x2, #0xb]
    // 0x87f1dc: r3 = LoadInt32Instr(r0)
    //     0x87f1dc: sbfx            x3, x0, #1, #0x1f
    // 0x87f1e0: stur            x3, [fp, #-0x60]
    // 0x87f1e4: r0 = 0
    //     0x87f1e4: mov             x0, #0
    // 0x87f1e8: CheckStackOverflow
    //     0x87f1e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f1ec: cmp             SP, x16
    //     0x87f1f0: b.ls            #0x87f4d8
    // 0x87f1f4: LoadField: r1 = r2->field_b
    //     0x87f1f4: ldur            w1, [x2, #0xb]
    // 0x87f1f8: r4 = LoadInt32Instr(r1)
    //     0x87f1f8: sbfx            x4, x1, #1, #0x1f
    // 0x87f1fc: cmp             x3, x4
    // 0x87f200: b.ne            #0x87f3c0
    // 0x87f204: cmp             x0, x4
    // 0x87f208: b.ge            #0x87f2ec
    // 0x87f20c: LoadField: r1 = r2->field_f
    //     0x87f20c: ldur            w1, [x2, #0xf]
    // 0x87f210: DecompressPointer r1
    //     0x87f210: add             x1, x1, HEAP, lsl #32
    // 0x87f214: ArrayLoad: r4 = r1[r0]  ; Unknown_4
    //     0x87f214: add             x16, x1, x0, lsl #2
    //     0x87f218: ldur            w4, [x16, #0xf]
    // 0x87f21c: DecompressPointer r4
    //     0x87f21c: add             x4, x4, HEAP, lsl #32
    // 0x87f220: stur            x4, [fp, #-0x58]
    // 0x87f224: add             x5, x0, #1
    // 0x87f228: mov             x1, x4
    // 0x87f22c: stur            x5, [fp, #-0x30]
    // 0x87f230: r0 = isRoot()
    //     0x87f230: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0x87f234: tbnz            w0, #4, #0x87f240
    // 0x87f238: ldur            x0, [fp, #-0x58]
    // 0x87f23c: b               #0x87f254
    // 0x87f240: ldur            x0, [fp, #-0x58]
    // 0x87f244: LoadField: r1 = r0->field_33
    //     0x87f244: ldur            w1, [x0, #0x33]
    // 0x87f248: DecompressPointer r1
    //     0x87f248: add             x1, x1, HEAP, lsl #32
    // 0x87f24c: cmp             w1, NULL
    // 0x87f250: b.eq            #0x87f2dc
    // 0x87f254: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x87f254: ldur            w1, [x0, #0x17]
    // 0x87f258: DecompressPointer r1
    //     0x87f258: add             x1, x1, HEAP, lsl #32
    // 0x87f25c: tbz             w1, #4, #0x87f2a0
    // 0x87f260: r1 = <int>
    //     0x87f260: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x87f264: r0 = _Set()
    //     0x87f264: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x87f268: mov             x1, x0
    // 0x87f26c: stur            x0, [fp, #-0x70]
    // 0x87f270: r0 = Shader._()
    //     0x87f270: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0x87f274: ldur            x2, [fp, #-0x70]
    // 0x87f278: r0 = _Uint32List
    //     0x87f278: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x87f27c: StoreField: r2->field_1b = r0
    //     0x87f27c: stur            w0, [x2, #0x1b]
    // 0x87f280: StoreField: r2->field_b = rZR
    //     0x87f280: stur            wzr, [x2, #0xb]
    // 0x87f284: r3 = const []
    //     0x87f284: ldr             x3, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x87f288: StoreField: r2->field_f = r3
    //     0x87f288: stur            w3, [x2, #0xf]
    // 0x87f28c: StoreField: r2->field_13 = rZR
    //     0x87f28c: stur            wzr, [x2, #0x13]
    // 0x87f290: ArrayStore: r2[0] = rZR  ; List_4
    //     0x87f290: stur            wzr, [x2, #0x17]
    // 0x87f294: ldur            x1, [fp, #-0x58]
    // 0x87f298: r0 = _buildSemantics()
    //     0x87f298: bl              #0x891358  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_buildSemantics
    // 0x87f29c: b               #0x87f2dc
    // 0x87f2a0: r1 = <int>
    //     0x87f2a0: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0x87f2a4: r0 = _Set()
    //     0x87f2a4: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x87f2a8: mov             x1, x0
    // 0x87f2ac: stur            x0, [fp, #-0x70]
    // 0x87f2b0: r0 = Shader._()
    //     0x87f2b0: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0x87f2b4: ldur            x2, [fp, #-0x70]
    // 0x87f2b8: r0 = _Uint32List
    //     0x87f2b8: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0x87f2bc: StoreField: r2->field_1b = r0
    //     0x87f2bc: stur            w0, [x2, #0x1b]
    // 0x87f2c0: StoreField: r2->field_b = rZR
    //     0x87f2c0: stur            wzr, [x2, #0xb]
    // 0x87f2c4: r3 = const []
    //     0x87f2c4: ldr             x3, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0x87f2c8: StoreField: r2->field_f = r3
    //     0x87f2c8: stur            w3, [x2, #0xf]
    // 0x87f2cc: StoreField: r2->field_13 = rZR
    //     0x87f2cc: stur            wzr, [x2, #0x13]
    // 0x87f2d0: ArrayStore: r2[0] = rZR  ; List_4
    //     0x87f2d0: stur            wzr, [x2, #0x17]
    // 0x87f2d4: ldur            x1, [fp, #-0x58]
    // 0x87f2d8: r0 = _buildSemanticsSubtree()
    //     0x87f2d8: bl              #0x88deb8  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_buildSemanticsSubtree
    // 0x87f2dc: ldur            x0, [fp, #-0x30]
    // 0x87f2e0: ldur            x2, [fp, #-0x68]
    // 0x87f2e4: ldur            x3, [fp, #-0x60]
    // 0x87f2e8: b               #0x87f1e8
    // 0x87f2ec: ldur            x1, [fp, #-0x50]
    // 0x87f2f0: ldur            x4, [fp, #-0x38]
    // 0x87f2f4: ldur            x2, [fp, #-0x48]
    // 0x87f2f8: ldur            x3, [fp, #-0x28]
    // 0x87f2fc: b               #0x87ede8
    // 0x87f300: ldur            x2, [fp, #-8]
    // 0x87f304: mov             x0, x4
    // 0x87f308: StoreField: r0->field_1f = rNULL
    //     0x87f308: stur            NULL, [x0, #0x1f]
    // 0x87f30c: LoadField: r1 = r2->field_2b
    //     0x87f30c: ldur            w1, [x2, #0x2b]
    // 0x87f310: DecompressPointer r1
    //     0x87f310: add             x1, x1, HEAP, lsl #32
    // 0x87f314: cmp             w1, NULL
    // 0x87f318: b.eq            #0x87f4e0
    // 0x87f31c: r0 = sendSemanticsUpdate()
    //     0x87f31c: bl              #0x87f4ec  ; [package:flutter/src/semantics/semantics.dart] SemanticsOwner::sendSemanticsUpdate
    // 0x87f320: ldur            x0, [fp, #-8]
    // 0x87f324: LoadField: r1 = r0->field_3f
    //     0x87f324: ldur            w1, [x0, #0x3f]
    // 0x87f328: DecompressPointer r1
    //     0x87f328: add             x1, x1, HEAP, lsl #32
    // 0x87f32c: r0 = iterator()
    //     0x87f32c: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x87f330: stur            x0, [fp, #-0x18]
    // 0x87f334: LoadField: r2 = r0->field_7
    //     0x87f334: ldur            w2, [x0, #7]
    // 0x87f338: DecompressPointer r2
    //     0x87f338: add             x2, x2, HEAP, lsl #32
    // 0x87f33c: stur            x2, [fp, #-8]
    // 0x87f340: CheckStackOverflow
    //     0x87f340: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x87f344: cmp             SP, x16
    //     0x87f348: b.ls            #0x87f4e4
    // 0x87f34c: mov             x1, x0
    // 0x87f350: r0 = moveNext()
    //     0x87f350: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x87f354: tbnz            w0, #4, #0x87f3b0
    // 0x87f358: ldur            x3, [fp, #-0x18]
    // 0x87f35c: LoadField: r4 = r3->field_33
    //     0x87f35c: ldur            w4, [x3, #0x33]
    // 0x87f360: DecompressPointer r4
    //     0x87f360: add             x4, x4, HEAP, lsl #32
    // 0x87f364: stur            x4, [fp, #-0x38]
    // 0x87f368: cmp             w4, NULL
    // 0x87f36c: b.ne            #0x87f39c
    // 0x87f370: mov             x0, x4
    // 0x87f374: ldur            x2, [fp, #-8]
    // 0x87f378: r1 = Null
    //     0x87f378: mov             x1, NULL
    // 0x87f37c: cmp             w2, NULL
    // 0x87f380: b.eq            #0x87f39c
    // 0x87f384: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x87f384: ldur            w4, [x2, #0x17]
    // 0x87f388: DecompressPointer r4
    //     0x87f388: add             x4, x4, HEAP, lsl #32
    // 0x87f38c: r8 = X0
    //     0x87f38c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x87f390: LoadField: r9 = r4->field_7
    //     0x87f390: ldur            x9, [x4, #7]
    // 0x87f394: r3 = Null
    //     0x87f394: ldr             x3, [PP, #0x23a0]  ; [pp+0x23a0] Null
    // 0x87f398: blr             x9
    // 0x87f39c: ldur            x1, [fp, #-0x38]
    // 0x87f3a0: r0 = flushSemantics()
    //     0x87f3a0: bl              #0x87e550  ; [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics
    // 0x87f3a4: ldur            x0, [fp, #-0x18]
    // 0x87f3a8: ldur            x2, [fp, #-8]
    // 0x87f3ac: b               #0x87f340
    // 0x87f3b0: r0 = Null
    //     0x87f3b0: mov             x0, NULL
    // 0x87f3b4: LeaveFrame
    //     0x87f3b4: mov             SP, fp
    //     0x87f3b8: ldp             fp, lr, [SP], #0x10
    // 0x87f3bc: ret
    //     0x87f3bc: ret             
    // 0x87f3c0: mov             x0, x2
    // 0x87f3c4: r0 = ConcurrentModificationError()
    //     0x87f3c4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87f3c8: mov             x1, x0
    // 0x87f3cc: ldur            x0, [fp, #-0x68]
    // 0x87f3d0: StoreField: r1->field_b = r0
    //     0x87f3d0: stur            w0, [x1, #0xb]
    // 0x87f3d4: mov             x0, x1
    // 0x87f3d8: r0 = Throw()
    //     0x87f3d8: bl              #0x13ddb2c  ; ThrowStub
    // 0x87f3dc: brk             #0
    // 0x87f3e0: ldur            x0, [fp, #-0x48]
    // 0x87f3e4: r0 = ConcurrentModificationError()
    //     0x87f3e4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87f3e8: mov             x1, x0
    // 0x87f3ec: ldur            x0, [fp, #-0x48]
    // 0x87f3f0: StoreField: r1->field_b = r0
    //     0x87f3f0: stur            w0, [x1, #0xb]
    // 0x87f3f4: mov             x0, x1
    // 0x87f3f8: r0 = Throw()
    //     0x87f3f8: bl              #0x13ddb2c  ; ThrowStub
    // 0x87f3fc: brk             #0
    // 0x87f400: mov             x0, x3
    // 0x87f404: r0 = ConcurrentModificationError()
    //     0x87f404: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87f408: mov             x1, x0
    // 0x87f40c: ldur            x0, [fp, #-0x40]
    // 0x87f410: StoreField: r1->field_b = r0
    //     0x87f410: stur            w0, [x1, #0xb]
    // 0x87f414: mov             x0, x1
    // 0x87f418: r0 = Throw()
    //     0x87f418: bl              #0x13ddb2c  ; ThrowStub
    // 0x87f41c: brk             #0
    // 0x87f420: mov             x0, x7
    // 0x87f424: r0 = ConcurrentModificationError()
    //     0x87f424: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87f428: mov             x1, x0
    // 0x87f42c: ldur            x0, [fp, #-0x10]
    // 0x87f430: StoreField: r1->field_b = r0
    //     0x87f430: stur            w0, [x1, #0xb]
    // 0x87f434: mov             x0, x1
    // 0x87f438: r0 = Throw()
    //     0x87f438: bl              #0x13ddb2c  ; ThrowStub
    // 0x87f43c: brk             #0
    // 0x87f440: mov             x0, x3
    // 0x87f444: r0 = ConcurrentModificationError()
    //     0x87f444: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87f448: mov             x1, x0
    // 0x87f44c: ldur            x0, [fp, #-0x10]
    // 0x87f450: StoreField: r1->field_b = r0
    //     0x87f450: stur            w0, [x1, #0xb]
    // 0x87f454: mov             x0, x1
    // 0x87f458: r0 = Throw()
    //     0x87f458: bl              #0x13ddb2c  ; ThrowStub
    // 0x87f45c: brk             #0
    // 0x87f460: mov             x0, x3
    // 0x87f464: r0 = ConcurrentModificationError()
    //     0x87f464: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x87f468: mov             x1, x0
    // 0x87f46c: ldur            x0, [fp, #-0x20]
    // 0x87f470: StoreField: r1->field_b = r0
    //     0x87f470: stur            w0, [x1, #0xb]
    // 0x87f474: mov             x0, x1
    // 0x87f478: r0 = Throw()
    //     0x87f478: bl              #0x13ddb2c  ; ThrowStub
    // 0x87f47c: brk             #0
    // 0x87f480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f480: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f484: b               #0x87e56c
    // 0x87f488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f488: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f48c: b               #0x87e630
    // 0x87f490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f490: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f494: b               #0x87e7b8
    // 0x87f498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f498: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f49c: b               #0x87e908
    // 0x87f4a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f4a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f4a4: b               #0x87e914
    // 0x87f4a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87f4a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87f4ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f4ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f4b0: b               #0x87eb08
    // 0x87f4b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f4b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f4b8: b               #0x87eb6c
    // 0x87f4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f4bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f4c0: b               #0x87ebf0
    // 0x87f4c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f4c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f4c8: b               #0x87ed1c
    // 0x87f4cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f4cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f4d0: b               #0x87edf4
    // 0x87f4d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87f4d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87f4d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f4d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f4dc: b               #0x87f1f4
    // 0x87f4e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87f4e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87f4e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87f4e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87f4e8: b               #0x87f34c
  }
  [closure] int <anonymous closure>(dynamic, _RenderObjectSemantics, _RenderObjectSemantics) {
    // ** addr: 0x898664, size: 0x4c
    // 0x898664: ldr             x2, [SP, #8]
    // 0x898668: LoadField: r3 = r2->field_7
    //     0x898668: ldur            w3, [x2, #7]
    // 0x89866c: DecompressPointer r3
    //     0x89866c: add             x3, x3, HEAP, lsl #32
    // 0x898670: LoadField: r2 = r3->field_b
    //     0x898670: ldur            x2, [x3, #0xb]
    // 0x898674: ldr             x3, [SP]
    // 0x898678: LoadField: r4 = r3->field_7
    //     0x898678: ldur            w4, [x3, #7]
    // 0x89867c: DecompressPointer r4
    //     0x89867c: add             x4, x4, HEAP, lsl #32
    // 0x898680: LoadField: r3 = r4->field_b
    //     0x898680: ldur            x3, [x4, #0xb]
    // 0x898684: sub             x4, x2, x3
    // 0x898688: r0 = BoxInt64Instr(r4)
    //     0x898688: sbfiz           x0, x4, #1, #0x1f
    //     0x89868c: cmp             x4, x0, asr #1
    //     0x898690: b.eq            #0x8986ac
    //     0x898694: stp             fp, lr, [SP, #-0x10]!
    //     0x898698: mov             fp, SP
    //     0x89869c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8986a0: mov             SP, fp
    //     0x8986a4: ldp             fp, lr, [SP], #0x10
    //     0x8986a8: stur            x4, [x0, #7]
    // 0x8986ac: ret
    //     0x8986ac: ret             
  }
  [closure] bool <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x8986b0, size: 0x10c
    // 0x8986b0: EnterFrame
    //     0x8986b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8986b4: mov             fp, SP
    // 0x8986b8: AllocStack(0x8)
    //     0x8986b8: sub             SP, SP, #8
    // 0x8986bc: SetupParameters([dynamic _ /* r0 */])
    //     0x8986bc: ldr             x0, [fp, #0x18]
    //     0x8986c0: ldur            w1, [x0, #0x17]
    //     0x8986c4: add             x1, x1, HEAP, lsl #32
    // 0x8986c8: CheckStackOverflow
    //     0x8986c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8986cc: cmp             SP, x16
    //     0x8986d0: b.ls            #0x8987b4
    // 0x8986d4: ldr             x0, [fp, #0x10]
    // 0x8986d8: LoadField: r2 = r0->field_1b
    //     0x8986d8: ldur            w2, [x0, #0x1b]
    // 0x8986dc: DecompressPointer r2
    //     0x8986dc: add             x2, x2, HEAP, lsl #32
    // 0x8986e0: tbz             w2, #4, #0x8987a4
    // 0x8986e4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x8986e4: ldur            w2, [x0, #0x17]
    // 0x8986e8: DecompressPointer r2
    //     0x8986e8: add             x2, x2, HEAP, lsl #32
    // 0x8986ec: LoadField: r3 = r1->field_f
    //     0x8986ec: ldur            w3, [x1, #0xf]
    // 0x8986f0: DecompressPointer r3
    //     0x8986f0: add             x3, x3, HEAP, lsl #32
    // 0x8986f4: cmp             w2, w3
    // 0x8986f8: b.ne            #0x8987a4
    // 0x8986fc: mov             x1, x0
    // 0x898700: LoadField: r0 = r1->field_43
    //     0x898700: ldur            w0, [x1, #0x43]
    // 0x898704: DecompressPointer r0
    //     0x898704: add             x0, x0, HEAP, lsl #32
    // 0x898708: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x89870c: cmp             w0, w16
    // 0x898710: b.ne            #0x89871c
    // 0x898714: r2 = _semantics
    //     0x898714: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x898718: r0 = InitLateFinalInstanceField()
    //     0x898718: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x89871c: mov             x2, x0
    // 0x898720: stur            x2, [fp, #-8]
    // 0x898724: LoadField: r1 = r2->field_7
    //     0x898724: ldur            w1, [x2, #7]
    // 0x898728: DecompressPointer r1
    //     0x898728: add             x1, x1, HEAP, lsl #32
    // 0x89872c: r0 = LoadClassIdInstr(r1)
    //     0x89872c: ldur            x0, [x1, #-1]
    //     0x898730: ubfx            x0, x0, #0xc, #0x14
    // 0x898734: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x898734: mov             x17, #0xfc0
    //     0x898738: movk            x17, #1, lsl #16
    //     0x89873c: add             lr, x0, x17
    //     0x898740: ldr             lr, [x21, lr, lsl #3]
    //     0x898744: blr             lr
    // 0x898748: cmp             w0, NULL
    // 0x89874c: b.ne            #0x898758
    // 0x898750: r1 = false
    //     0x898750: add             x1, NULL, #0x30  ; false
    // 0x898754: b               #0x898798
    // 0x898758: ldur            x2, [fp, #-8]
    // 0x89875c: mov             x1, x0
    // 0x898760: LoadField: r0 = r1->field_43
    //     0x898760: ldur            w0, [x1, #0x43]
    // 0x898764: DecompressPointer r0
    //     0x898764: add             x0, x0, HEAP, lsl #32
    // 0x898768: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x89876c: cmp             w0, w16
    // 0x898770: b.ne            #0x89877c
    // 0x898774: r2 = _semantics
    //     0x898774: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x898778: r0 = InitLateFinalInstanceField()
    //     0x898778: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x89877c: ldur            x1, [fp, #-8]
    // 0x898780: LoadField: r2 = r1->field_33
    //     0x898780: ldur            w2, [x1, #0x33]
    // 0x898784: DecompressPointer r2
    //     0x898784: add             x2, x2, HEAP, lsl #32
    // 0x898788: cmp             w2, NULL
    // 0x89878c: r16 = true
    //     0x89878c: add             x16, NULL, #0x20  ; true
    // 0x898790: r17 = false
    //     0x898790: add             x17, NULL, #0x30  ; false
    // 0x898794: csel            x1, x16, x17, eq
    // 0x898798: eor             x2, x1, #0x10
    // 0x89879c: mov             x0, x2
    // 0x8987a0: b               #0x8987a8
    // 0x8987a4: r0 = false
    //     0x8987a4: add             x0, NULL, #0x30  ; false
    // 0x8987a8: LeaveFrame
    //     0x8987a8: mov             SP, fp
    //     0x8987ac: ldp             fp, lr, [SP], #0x10
    // 0x8987b0: ret
    //     0x8987b0: ret             
    // 0x8987b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8987b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8987b8: b               #0x8986d4
  }
  [closure] int <anonymous closure>(dynamic, RenderObject, RenderObject) {
    // ** addr: 0x8987bc, size: 0x3c
    // 0x8987bc: ldr             x2, [SP, #8]
    // 0x8987c0: LoadField: r3 = r2->field_b
    //     0x8987c0: ldur            x3, [x2, #0xb]
    // 0x8987c4: ldr             x2, [SP]
    // 0x8987c8: LoadField: r4 = r2->field_b
    //     0x8987c8: ldur            x4, [x2, #0xb]
    // 0x8987cc: sub             x2, x3, x4
    // 0x8987d0: r0 = BoxInt64Instr(r2)
    //     0x8987d0: sbfiz           x0, x2, #1, #0x1f
    //     0x8987d4: cmp             x2, x0, asr #1
    //     0x8987d8: b.eq            #0x8987f4
    //     0x8987dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8987e0: mov             fp, SP
    //     0x8987e4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8987e8: mov             SP, fp
    //     0x8987ec: ldp             fp, lr, [SP], #0x10
    //     0x8987f0: stur            x2, [x0, #7]
    // 0x8987f4: ret
    //     0x8987f4: ret             
  }
  [closure] bool <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x8987f8, size: 0x4c
    // 0x8987f8: ldr             x1, [SP, #8]
    // 0x8987fc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x8987fc: ldur            w2, [x1, #0x17]
    // 0x898800: DecompressPointer r2
    //     0x898800: add             x2, x2, HEAP, lsl #32
    // 0x898804: ldr             x1, [SP]
    // 0x898808: LoadField: r3 = r1->field_1b
    //     0x898808: ldur            w3, [x1, #0x1b]
    // 0x89880c: DecompressPointer r3
    //     0x89880c: add             x3, x3, HEAP, lsl #32
    // 0x898810: tbz             w3, #4, #0x89883c
    // 0x898814: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x898814: ldur            w3, [x1, #0x17]
    // 0x898818: DecompressPointer r3
    //     0x898818: add             x3, x3, HEAP, lsl #32
    // 0x89881c: LoadField: r1 = r2->field_f
    //     0x89881c: ldur            w1, [x2, #0xf]
    // 0x898820: DecompressPointer r1
    //     0x898820: add             x1, x1, HEAP, lsl #32
    // 0x898824: cmp             w3, w1
    // 0x898828: r16 = true
    //     0x898828: add             x16, NULL, #0x20  ; true
    // 0x89882c: r17 = false
    //     0x89882c: add             x17, NULL, #0x30  ; false
    // 0x898830: csel            x2, x16, x17, eq
    // 0x898834: mov             x0, x2
    // 0x898838: b               #0x898840
    // 0x89883c: r0 = false
    //     0x89883c: add             x0, NULL, #0x30  ; false
    // 0x898840: ret
    //     0x898840: ret             
  }
  _ flushPaint(/* No info */) {
    // ** addr: 0x899f24, size: 0x298
    // 0x899f24: EnterFrame
    //     0x899f24: stp             fp, lr, [SP, #-0x10]!
    //     0x899f28: mov             fp, SP
    // 0x899f2c: AllocStack(0x38)
    //     0x899f2c: sub             SP, SP, #0x38
    // 0x899f30: SetupParameters(PipelineOwner this /* r1 => r0, fp-0x10 */)
    //     0x899f30: mov             x0, x1
    //     0x899f34: stur            x1, [fp, #-0x10]
    // 0x899f38: CheckStackOverflow
    //     0x899f38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x899f3c: cmp             SP, x16
    //     0x899f40: b.ls            #0x89a1a0
    // 0x899f44: LoadField: r3 = r0->field_27
    //     0x899f44: ldur            w3, [x0, #0x27]
    // 0x899f48: DecompressPointer r3
    //     0x899f48: add             x3, x3, HEAP, lsl #32
    // 0x899f4c: stur            x3, [fp, #-8]
    // 0x899f50: r1 = <RenderObject>
    //     0x899f50: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x899f54: r2 = 0
    //     0x899f54: mov             x2, #0
    // 0x899f58: r0 = _GrowableList()
    //     0x899f58: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x899f5c: ldur            x3, [fp, #-0x10]
    // 0x899f60: StoreField: r3->field_27 = r0
    //     0x899f60: stur            w0, [x3, #0x27]
    //     0x899f64: ldurb           w16, [x3, #-1]
    //     0x899f68: ldurb           w17, [x0, #-1]
    //     0x899f6c: and             x16, x17, x16, lsr #2
    //     0x899f70: tst             x16, HEAP, lsr #32
    //     0x899f74: b.eq            #0x899f7c
    //     0x899f78: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x899f7c: r1 = Function '<anonymous closure>':.
    //     0x899f7c: ldr             x1, [PP, #0x2cf0]  ; [pp+0x2cf0] AnonymousClosure: (0x89b06c), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushPaint (0x899f24)
    // 0x899f80: r2 = Null
    //     0x899f80: mov             x2, NULL
    // 0x899f84: r0 = AllocateClosure()
    //     0x899f84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x899f88: str             x0, [SP]
    // 0x899f8c: ldur            x1, [fp, #-8]
    // 0x899f90: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x899f90: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x899f94: r0 = sort()
    //     0x899f94: bl              #0x9f9bf0  ; [dart:collection] ListBase::sort
    // 0x899f98: ldur            x0, [fp, #-8]
    // 0x899f9c: LoadField: r1 = r0->field_b
    //     0x899f9c: ldur            w1, [x0, #0xb]
    // 0x899fa0: r2 = LoadInt32Instr(r1)
    //     0x899fa0: sbfx            x2, x1, #1, #0x1f
    // 0x899fa4: stur            x2, [fp, #-0x20]
    // 0x899fa8: r1 = 0
    //     0x899fa8: mov             x1, #0
    // 0x899fac: ldur            x3, [fp, #-0x10]
    // 0x899fb0: CheckStackOverflow
    //     0x899fb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x899fb4: cmp             SP, x16
    //     0x899fb8: b.ls            #0x89a1a8
    // 0x899fbc: LoadField: r4 = r0->field_b
    //     0x899fbc: ldur            w4, [x0, #0xb]
    // 0x899fc0: r5 = LoadInt32Instr(r4)
    //     0x899fc0: sbfx            x5, x4, #1, #0x1f
    // 0x899fc4: cmp             x2, x5
    // 0x899fc8: b.ne            #0x89a184
    // 0x899fcc: cmp             x1, x5
    // 0x899fd0: b.ge            #0x89a0e4
    // 0x899fd4: LoadField: r4 = r0->field_f
    //     0x899fd4: ldur            w4, [x0, #0xf]
    // 0x899fd8: DecompressPointer r4
    //     0x899fd8: add             x4, x4, HEAP, lsl #32
    // 0x899fdc: ArrayLoad: r5 = r4[r1]  ; Unknown_4
    //     0x899fdc: add             x16, x4, x1, lsl #2
    //     0x899fe0: ldur            w5, [x16, #0xf]
    // 0x899fe4: DecompressPointer r5
    //     0x899fe4: add             x5, x5, HEAP, lsl #32
    // 0x899fe8: stur            x5, [fp, #-0x30]
    // 0x899fec: add             x4, x1, #1
    // 0x899ff0: stur            x4, [fp, #-0x18]
    // 0x899ff4: LoadField: r1 = r5->field_3b
    //     0x899ff4: ldur            w1, [x5, #0x3b]
    // 0x899ff8: DecompressPointer r1
    //     0x899ff8: add             x1, x1, HEAP, lsl #32
    // 0x899ffc: tbz             w1, #4, #0x89a00c
    // 0x89a000: LoadField: r6 = r5->field_3f
    //     0x89a000: ldur            w6, [x5, #0x3f]
    // 0x89a004: DecompressPointer r6
    //     0x89a004: add             x6, x6, HEAP, lsl #32
    // 0x89a008: tbnz            w6, #4, #0x89a0d4
    // 0x89a00c: ArrayLoad: r6 = r5[0]  ; List_4
    //     0x89a00c: ldur            w6, [x5, #0x17]
    // 0x89a010: DecompressPointer r6
    //     0x89a010: add             x6, x6, HEAP, lsl #32
    // 0x89a014: cmp             w6, w3
    // 0x89a018: b.ne            #0x89a0d4
    // 0x89a01c: LoadField: r6 = r5->field_2f
    //     0x89a01c: ldur            w6, [x5, #0x2f]
    // 0x89a020: DecompressPointer r6
    //     0x89a020: add             x6, x6, HEAP, lsl #32
    // 0x89a024: LoadField: r7 = r6->field_b
    //     0x89a024: ldur            w7, [x6, #0xb]
    // 0x89a028: DecompressPointer r7
    //     0x89a028: add             x7, x7, HEAP, lsl #32
    // 0x89a02c: stur            x7, [fp, #-0x28]
    // 0x89a030: cmp             w7, NULL
    // 0x89a034: b.eq            #0x89a1b0
    // 0x89a038: LoadField: r6 = r7->field_2b
    //     0x89a038: ldur            w6, [x7, #0x2b]
    // 0x89a03c: DecompressPointer r6
    //     0x89a03c: add             x6, x6, HEAP, lsl #32
    // 0x89a040: cmp             w6, NULL
    // 0x89a044: b.eq            #0x89a0c8
    // 0x89a048: tbnz            w1, #4, #0x89a060
    // 0x89a04c: mov             x1, x5
    // 0x89a050: r4 = const [0, 0x1, 0, 0x1, null]
    //     0x89a050: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0x89a054: r0 = _repaintCompositedChild()
    //     0x89a054: bl              #0x89a370  ; [package:flutter/src/rendering/object.dart] PaintingContext::_repaintCompositedChild
    // 0x89a058: r0 = false
    //     0x89a058: add             x0, NULL, #0x30  ; false
    // 0x89a05c: b               #0x89a0d4
    // 0x89a060: mov             x0, x7
    // 0x89a064: r2 = Null
    //     0x89a064: mov             x2, NULL
    // 0x89a068: r1 = Null
    //     0x89a068: mov             x1, NULL
    // 0x89a06c: r4 = LoadClassIdInstr(r0)
    //     0x89a06c: ldur            x4, [x0, #-1]
    //     0x89a070: ubfx            x4, x4, #0xc, #0x14
    // 0x89a074: r17 = -4660
    //     0x89a074: mov             x17, #-0x1234
    // 0x89a078: add             x4, x4, x17
    // 0x89a07c: cmp             x4, #3
    // 0x89a080: b.ls            #0x89a090
    // 0x89a084: r8 = OffsetLayer
    //     0x89a084: ldr             x8, [PP, #0x2cf8]  ; [pp+0x2cf8] Type: OffsetLayer
    // 0x89a088: r3 = Null
    //     0x89a088: ldr             x3, [PP, #0x2d00]  ; [pp+0x2d00] Null
    // 0x89a08c: r0 = DefaultTypeTest()
    //     0x89a08c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x89a090: ldur            x3, [fp, #-0x30]
    // 0x89a094: r0 = LoadClassIdInstr(r3)
    //     0x89a094: ldur            x0, [x3, #-1]
    //     0x89a098: ubfx            x0, x0, #0xc, #0x14
    // 0x89a09c: mov             x1, x3
    // 0x89a0a0: ldur            x2, [fp, #-0x28]
    // 0x89a0a4: r0 = GDT[cid_x0 + 0x10e9d]()
    //     0x89a0a4: mov             x17, #0xe9d
    //     0x89a0a8: movk            x17, #1, lsl #16
    //     0x89a0ac: add             lr, x0, x17
    //     0x89a0b0: ldr             lr, [x21, lr, lsl #3]
    //     0x89a0b4: blr             lr
    // 0x89a0b8: ldur            x1, [fp, #-0x30]
    // 0x89a0bc: r0 = false
    //     0x89a0bc: add             x0, NULL, #0x30  ; false
    // 0x89a0c0: StoreField: r1->field_3f = r0
    //     0x89a0c0: stur            w0, [x1, #0x3f]
    // 0x89a0c4: b               #0x89a0d4
    // 0x89a0c8: mov             x1, x5
    // 0x89a0cc: r0 = false
    //     0x89a0cc: add             x0, NULL, #0x30  ; false
    // 0x89a0d0: r0 = _skippedPaintingOnLayer()
    //     0x89a0d0: bl              #0x89a27c  ; [package:flutter/src/rendering/object.dart] RenderObject::_skippedPaintingOnLayer
    // 0x89a0d4: ldur            x1, [fp, #-0x18]
    // 0x89a0d8: ldur            x0, [fp, #-8]
    // 0x89a0dc: ldur            x2, [fp, #-0x20]
    // 0x89a0e0: b               #0x899fac
    // 0x89a0e4: mov             x0, x3
    // 0x89a0e8: LoadField: r1 = r0->field_3f
    //     0x89a0e8: ldur            w1, [x0, #0x3f]
    // 0x89a0ec: DecompressPointer r1
    //     0x89a0ec: add             x1, x1, HEAP, lsl #32
    // 0x89a0f0: r0 = iterator()
    //     0x89a0f0: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x89a0f4: stur            x0, [fp, #-0x28]
    // 0x89a0f8: LoadField: r2 = r0->field_7
    //     0x89a0f8: ldur            w2, [x0, #7]
    // 0x89a0fc: DecompressPointer r2
    //     0x89a0fc: add             x2, x2, HEAP, lsl #32
    // 0x89a100: stur            x2, [fp, #-0x10]
    // 0x89a104: CheckStackOverflow
    //     0x89a104: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a108: cmp             SP, x16
    //     0x89a10c: b.ls            #0x89a1b4
    // 0x89a110: mov             x1, x0
    // 0x89a114: r0 = moveNext()
    //     0x89a114: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x89a118: tbnz            w0, #4, #0x89a174
    // 0x89a11c: ldur            x3, [fp, #-0x28]
    // 0x89a120: LoadField: r4 = r3->field_33
    //     0x89a120: ldur            w4, [x3, #0x33]
    // 0x89a124: DecompressPointer r4
    //     0x89a124: add             x4, x4, HEAP, lsl #32
    // 0x89a128: stur            x4, [fp, #-0x30]
    // 0x89a12c: cmp             w4, NULL
    // 0x89a130: b.ne            #0x89a160
    // 0x89a134: mov             x0, x4
    // 0x89a138: ldur            x2, [fp, #-0x10]
    // 0x89a13c: r1 = Null
    //     0x89a13c: mov             x1, NULL
    // 0x89a140: cmp             w2, NULL
    // 0x89a144: b.eq            #0x89a160
    // 0x89a148: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x89a148: ldur            w4, [x2, #0x17]
    // 0x89a14c: DecompressPointer r4
    //     0x89a14c: add             x4, x4, HEAP, lsl #32
    // 0x89a150: r8 = X0
    //     0x89a150: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x89a154: LoadField: r9 = r4->field_7
    //     0x89a154: ldur            x9, [x4, #7]
    // 0x89a158: r3 = Null
    //     0x89a158: ldr             x3, [PP, #0x2d10]  ; [pp+0x2d10] Null
    // 0x89a15c: blr             x9
    // 0x89a160: ldur            x1, [fp, #-0x30]
    // 0x89a164: r0 = flushPaint()
    //     0x89a164: bl              #0x899f24  ; [package:flutter/src/rendering/object.dart] PipelineOwner::flushPaint
    // 0x89a168: ldur            x0, [fp, #-0x28]
    // 0x89a16c: ldur            x2, [fp, #-0x10]
    // 0x89a170: b               #0x89a104
    // 0x89a174: r0 = Null
    //     0x89a174: mov             x0, NULL
    // 0x89a178: LeaveFrame
    //     0x89a178: mov             SP, fp
    //     0x89a17c: ldp             fp, lr, [SP], #0x10
    // 0x89a180: ret
    //     0x89a180: ret             
    // 0x89a184: r0 = ConcurrentModificationError()
    //     0x89a184: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x89a188: mov             x1, x0
    // 0x89a18c: ldur            x0, [fp, #-8]
    // 0x89a190: StoreField: r1->field_b = r0
    //     0x89a190: stur            w0, [x1, #0xb]
    // 0x89a194: mov             x0, x1
    // 0x89a198: r0 = Throw()
    //     0x89a198: bl              #0x13ddb2c  ; ThrowStub
    // 0x89a19c: brk             #0
    // 0x89a1a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a1a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a1a4: b               #0x899f44
    // 0x89a1a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a1a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a1ac: b               #0x899fbc
    // 0x89a1b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89a1b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x89a1b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a1b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a1b8: b               #0x89a110
  }
  [closure] int <anonymous closure>(dynamic, RenderObject, RenderObject) {
    // ** addr: 0x89b06c, size: 0x3c
    // 0x89b06c: ldr             x2, [SP]
    // 0x89b070: LoadField: r3 = r2->field_b
    //     0x89b070: ldur            x3, [x2, #0xb]
    // 0x89b074: ldr             x2, [SP, #8]
    // 0x89b078: LoadField: r4 = r2->field_b
    //     0x89b078: ldur            x4, [x2, #0xb]
    // 0x89b07c: sub             x2, x3, x4
    // 0x89b080: r0 = BoxInt64Instr(r2)
    //     0x89b080: sbfiz           x0, x2, #1, #0x1f
    //     0x89b084: cmp             x2, x0, asr #1
    //     0x89b088: b.eq            #0x89b0a4
    //     0x89b08c: stp             fp, lr, [SP, #-0x10]!
    //     0x89b090: mov             fp, SP
    //     0x89b094: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x89b098: mov             SP, fp
    //     0x89b09c: ldp             fp, lr, [SP], #0x10
    //     0x89b0a0: stur            x2, [x0, #7]
    // 0x89b0a4: ret
    //     0x89b0a4: ret             
  }
  _ flushCompositingBits(/* No info */) {
    // ** addr: 0x89b0a8, size: 0x1b4
    // 0x89b0a8: EnterFrame
    //     0x89b0a8: stp             fp, lr, [SP, #-0x10]!
    //     0x89b0ac: mov             fp, SP
    // 0x89b0b0: AllocStack(0x38)
    //     0x89b0b0: sub             SP, SP, #0x38
    // 0x89b0b4: SetupParameters(PipelineOwner this /* r1 => r0, fp-0x10 */)
    //     0x89b0b4: mov             x0, x1
    //     0x89b0b8: stur            x1, [fp, #-0x10]
    // 0x89b0bc: CheckStackOverflow
    //     0x89b0bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b0c0: cmp             SP, x16
    //     0x89b0c4: b.ls            #0x89b244
    // 0x89b0c8: LoadField: r3 = r0->field_23
    //     0x89b0c8: ldur            w3, [x0, #0x23]
    // 0x89b0cc: DecompressPointer r3
    //     0x89b0cc: add             x3, x3, HEAP, lsl #32
    // 0x89b0d0: stur            x3, [fp, #-8]
    // 0x89b0d4: r1 = Function '<anonymous closure>':.
    //     0x89b0d4: ldr             x1, [PP, #0x2da8]  ; [pp+0x2da8] AnonymousClosure: (0x8987bc), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x87e550)
    // 0x89b0d8: r2 = Null
    //     0x89b0d8: mov             x2, NULL
    // 0x89b0dc: r0 = AllocateClosure()
    //     0x89b0dc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x89b0e0: str             x0, [SP]
    // 0x89b0e4: ldur            x1, [fp, #-8]
    // 0x89b0e8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0x89b0e8: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0x89b0ec: r0 = sort()
    //     0x89b0ec: bl              #0x9f9bf0  ; [dart:collection] ListBase::sort
    // 0x89b0f0: ldur            x0, [fp, #-8]
    // 0x89b0f4: LoadField: r1 = r0->field_b
    //     0x89b0f4: ldur            w1, [x0, #0xb]
    // 0x89b0f8: r2 = LoadInt32Instr(r1)
    //     0x89b0f8: sbfx            x2, x1, #1, #0x1f
    // 0x89b0fc: stur            x2, [fp, #-0x20]
    // 0x89b100: r1 = 0
    //     0x89b100: mov             x1, #0
    // 0x89b104: ldur            x3, [fp, #-0x10]
    // 0x89b108: CheckStackOverflow
    //     0x89b108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b10c: cmp             SP, x16
    //     0x89b110: b.ls            #0x89b24c
    // 0x89b114: LoadField: r4 = r0->field_b
    //     0x89b114: ldur            w4, [x0, #0xb]
    // 0x89b118: r5 = LoadInt32Instr(r4)
    //     0x89b118: sbfx            x5, x4, #1, #0x1f
    // 0x89b11c: cmp             x2, x5
    // 0x89b120: b.ne            #0x89b228
    // 0x89b124: cmp             x1, x5
    // 0x89b128: b.ge            #0x89b17c
    // 0x89b12c: LoadField: r4 = r0->field_f
    //     0x89b12c: ldur            w4, [x0, #0xf]
    // 0x89b130: DecompressPointer r4
    //     0x89b130: add             x4, x4, HEAP, lsl #32
    // 0x89b134: ArrayLoad: r5 = r4[r1]  ; Unknown_4
    //     0x89b134: add             x16, x4, x1, lsl #2
    //     0x89b138: ldur            w5, [x16, #0xf]
    // 0x89b13c: DecompressPointer r5
    //     0x89b13c: add             x5, x5, HEAP, lsl #32
    // 0x89b140: add             x4, x1, #1
    // 0x89b144: stur            x4, [fp, #-0x18]
    // 0x89b148: LoadField: r1 = r5->field_33
    //     0x89b148: ldur            w1, [x5, #0x33]
    // 0x89b14c: DecompressPointer r1
    //     0x89b14c: add             x1, x1, HEAP, lsl #32
    // 0x89b150: tbnz            w1, #4, #0x89b16c
    // 0x89b154: ArrayLoad: r1 = r5[0]  ; List_4
    //     0x89b154: ldur            w1, [x5, #0x17]
    // 0x89b158: DecompressPointer r1
    //     0x89b158: add             x1, x1, HEAP, lsl #32
    // 0x89b15c: cmp             w1, w3
    // 0x89b160: b.ne            #0x89b16c
    // 0x89b164: mov             x1, x5
    // 0x89b168: r0 = _updateCompositingBits()
    //     0x89b168: bl              #0x89b25c  ; [package:flutter/src/rendering/object.dart] RenderObject::_updateCompositingBits
    // 0x89b16c: ldur            x1, [fp, #-0x18]
    // 0x89b170: ldur            x0, [fp, #-8]
    // 0x89b174: ldur            x2, [fp, #-0x20]
    // 0x89b178: b               #0x89b104
    // 0x89b17c: mov             x0, x3
    // 0x89b180: ldur            x1, [fp, #-8]
    // 0x89b184: r0 = clear()
    //     0x89b184: bl              #0xa16074  ; [dart:core] _GrowableList::clear
    // 0x89b188: ldur            x0, [fp, #-0x10]
    // 0x89b18c: LoadField: r1 = r0->field_3f
    //     0x89b18c: ldur            w1, [x0, #0x3f]
    // 0x89b190: DecompressPointer r1
    //     0x89b190: add             x1, x1, HEAP, lsl #32
    // 0x89b194: r0 = iterator()
    //     0x89b194: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x89b198: stur            x0, [fp, #-0x28]
    // 0x89b19c: LoadField: r2 = r0->field_7
    //     0x89b19c: ldur            w2, [x0, #7]
    // 0x89b1a0: DecompressPointer r2
    //     0x89b1a0: add             x2, x2, HEAP, lsl #32
    // 0x89b1a4: stur            x2, [fp, #-0x10]
    // 0x89b1a8: CheckStackOverflow
    //     0x89b1a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b1ac: cmp             SP, x16
    //     0x89b1b0: b.ls            #0x89b254
    // 0x89b1b4: mov             x1, x0
    // 0x89b1b8: r0 = moveNext()
    //     0x89b1b8: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x89b1bc: tbnz            w0, #4, #0x89b218
    // 0x89b1c0: ldur            x3, [fp, #-0x28]
    // 0x89b1c4: LoadField: r4 = r3->field_33
    //     0x89b1c4: ldur            w4, [x3, #0x33]
    // 0x89b1c8: DecompressPointer r4
    //     0x89b1c8: add             x4, x4, HEAP, lsl #32
    // 0x89b1cc: stur            x4, [fp, #-0x30]
    // 0x89b1d0: cmp             w4, NULL
    // 0x89b1d4: b.ne            #0x89b204
    // 0x89b1d8: mov             x0, x4
    // 0x89b1dc: ldur            x2, [fp, #-0x10]
    // 0x89b1e0: r1 = Null
    //     0x89b1e0: mov             x1, NULL
    // 0x89b1e4: cmp             w2, NULL
    // 0x89b1e8: b.eq            #0x89b204
    // 0x89b1ec: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x89b1ec: ldur            w4, [x2, #0x17]
    // 0x89b1f0: DecompressPointer r4
    //     0x89b1f0: add             x4, x4, HEAP, lsl #32
    // 0x89b1f4: r8 = X0
    //     0x89b1f4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x89b1f8: LoadField: r9 = r4->field_7
    //     0x89b1f8: ldur            x9, [x4, #7]
    // 0x89b1fc: r3 = Null
    //     0x89b1fc: ldr             x3, [PP, #0x2db0]  ; [pp+0x2db0] Null
    // 0x89b200: blr             x9
    // 0x89b204: ldur            x1, [fp, #-0x30]
    // 0x89b208: r0 = flushCompositingBits()
    //     0x89b208: bl              #0x89b0a8  ; [package:flutter/src/rendering/object.dart] PipelineOwner::flushCompositingBits
    // 0x89b20c: ldur            x0, [fp, #-0x28]
    // 0x89b210: ldur            x2, [fp, #-0x10]
    // 0x89b214: b               #0x89b1a8
    // 0x89b218: r0 = Null
    //     0x89b218: mov             x0, NULL
    // 0x89b21c: LeaveFrame
    //     0x89b21c: mov             SP, fp
    //     0x89b220: ldp             fp, lr, [SP], #0x10
    // 0x89b224: ret
    //     0x89b224: ret             
    // 0x89b228: r0 = ConcurrentModificationError()
    //     0x89b228: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x89b22c: mov             x1, x0
    // 0x89b230: ldur            x0, [fp, #-8]
    // 0x89b234: StoreField: r1->field_b = r0
    //     0x89b234: stur            w0, [x1, #0xb]
    // 0x89b238: mov             x0, x1
    // 0x89b23c: r0 = Throw()
    //     0x89b23c: bl              #0x13ddb2c  ; ThrowStub
    // 0x89b240: brk             #0
    // 0x89b244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b248: b               #0x89b0c8
    // 0x89b24c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b24c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b250: b               #0x89b114
    // 0x89b254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b254: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b258: b               #0x89b1b4
  }
  _ flushLayout(/* No info */) {
    // ** addr: 0x89b50c, size: 0x288
    // 0x89b50c: EnterFrame
    //     0x89b50c: stp             fp, lr, [SP, #-0x10]!
    //     0x89b510: mov             fp, SP
    // 0x89b514: AllocStack(0x98)
    //     0x89b514: sub             SP, SP, #0x98
    // 0x89b518: SetupParameters(PipelineOwner this /* r1 => r0, fp-0x68 */)
    //     0x89b518: mov             x0, x1
    //     0x89b51c: stur            x1, [fp, #-0x68]
    // 0x89b520: CheckStackOverflow
    //     0x89b520: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b524: cmp             SP, x16
    //     0x89b528: b.ls            #0x89b774
    // 0x89b52c: CheckStackOverflow
    //     0x89b52c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b530: cmp             SP, x16
    //     0x89b534: b.ls            #0x89b77c
    // 0x89b538: LoadField: r2 = r0->field_1f
    //     0x89b538: ldur            w2, [x0, #0x1f]
    // 0x89b53c: DecompressPointer r2
    //     0x89b53c: add             x2, x2, HEAP, lsl #32
    // 0x89b540: stur            x2, [fp, #-0x60]
    // 0x89b544: LoadField: r1 = r2->field_b
    //     0x89b544: ldur            w1, [x2, #0xb]
    // 0x89b548: cbz             w1, #0x89b6b0
    // 0x89b54c: r1 = <RenderObject>
    //     0x89b54c: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x89b550: r0 = AllocateGrowableArray()
    //     0x89b550: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x89b554: r3 = const []
    //     0x89b554: ldr             x3, [PP, #0x940]  ; [pp+0x940] List(0) []
    // 0x89b558: StoreField: r0->field_f = r3
    //     0x89b558: stur            w3, [x0, #0xf]
    // 0x89b55c: StoreField: r0->field_b = rZR
    //     0x89b55c: stur            wzr, [x0, #0xb]
    // 0x89b560: ldur            x4, [fp, #-0x68]
    // 0x89b564: StoreField: r4->field_1f = r0
    //     0x89b564: stur            w0, [x4, #0x1f]
    //     0x89b568: ldurb           w16, [x4, #-1]
    //     0x89b56c: ldurb           w17, [x0, #-1]
    //     0x89b570: and             x16, x17, x16, lsr #2
    //     0x89b574: tst             x16, HEAP, lsr #32
    //     0x89b578: b.eq            #0x89b580
    //     0x89b57c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x89b580: r1 = Function '<anonymous closure>':.
    //     0x89b580: ldr             x1, [PP, #0x2de0]  ; [pp+0x2de0] AnonymousClosure: (0x8987bc), in [package:flutter/src/rendering/object.dart] PipelineOwner::flushSemantics (0x87e550)
    // 0x89b584: r2 = Null
    //     0x89b584: mov             x2, NULL
    // 0x89b588: r0 = AllocateClosure()
    //     0x89b588: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x89b58c: stur            x0, [fp, #-0x70]
    // 0x89b590: r16 = <RenderObject>
    //     0x89b590: ldr             x16, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x89b594: ldur            lr, [fp, #-0x60]
    // 0x89b598: stp             lr, x16, [SP, #8]
    // 0x89b59c: str             x0, [SP]
    // 0x89b5a0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x89b5a0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x89b5a4: r0 = sort()
    //     0x89b5a4: bl              #0x8248dc  ; [dart:_internal] Sort::sort
    // 0x89b5a8: r6 = 0
    //     0x89b5a8: mov             x6, #0
    // 0x89b5ac: ldur            x0, [fp, #-0x68]
    // 0x89b5b0: ldur            x5, [fp, #-0x60]
    // 0x89b5b4: r4 = false
    //     0x89b5b4: add             x4, NULL, #0x30  ; false
    // 0x89b5b8: stur            x6, [fp, #-0x80]
    // 0x89b5bc: CheckStackOverflow
    //     0x89b5bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b5c0: cmp             SP, x16
    //     0x89b5c4: b.ls            #0x89b784
    // 0x89b5c8: LoadField: r7 = r5->field_b
    //     0x89b5c8: ldur            w7, [x5, #0xb]
    // 0x89b5cc: stur            x7, [fp, #-0x78]
    // 0x89b5d0: r3 = LoadInt32Instr(r7)
    //     0x89b5d0: sbfx            x3, x7, #1, #0x1f
    // 0x89b5d4: cmp             x6, x3
    // 0x89b5d8: b.ge            #0x89b6a0
    // 0x89b5dc: LoadField: r1 = r0->field_1b
    //     0x89b5dc: ldur            w1, [x0, #0x1b]
    // 0x89b5e0: DecompressPointer r1
    //     0x89b5e0: add             x1, x1, HEAP, lsl #32
    // 0x89b5e4: tbnz            w1, #4, #0x89b64c
    // 0x89b5e8: StoreField: r0->field_1b = r4
    //     0x89b5e8: stur            w4, [x0, #0x1b]
    // 0x89b5ec: LoadField: r8 = r0->field_1f
    //     0x89b5ec: ldur            w8, [x0, #0x1f]
    // 0x89b5f0: DecompressPointer r8
    //     0x89b5f0: add             x8, x8, HEAP, lsl #32
    // 0x89b5f4: stur            x8, [fp, #-0x70]
    // 0x89b5f8: LoadField: r1 = r8->field_b
    //     0x89b5f8: ldur            w1, [x8, #0xb]
    // 0x89b5fc: cbnz            w1, #0x89b60c
    // 0x89b600: mov             x0, x5
    // 0x89b604: mov             x2, x6
    // 0x89b608: b               #0x89b654
    // 0x89b60c: mov             x1, x6
    // 0x89b610: mov             x2, x7
    // 0x89b614: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x89b614: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x89b618: r0 = checkValidRange()
    //     0x89b618: bl              #0x7db068  ; [dart:core] RangeError::checkValidRange
    // 0x89b61c: r1 = <RenderObject>
    //     0x89b61c: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x89b620: r0 = SubListIterable()
    //     0x89b620: bl              #0x82e540  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0x89b624: mov             x1, x0
    // 0x89b628: ldur            x2, [fp, #-0x60]
    // 0x89b62c: ldur            x3, [fp, #-0x80]
    // 0x89b630: ldur            x5, [fp, #-0x78]
    // 0x89b634: stur            x0, [fp, #-0x78]
    // 0x89b638: r0 = SubListIterable()
    //     0x89b638: bl              #0x82e364  ; [dart:_internal] SubListIterable::SubListIterable
    // 0x89b63c: ldur            x1, [fp, #-0x70]
    // 0x89b640: ldur            x2, [fp, #-0x78]
    // 0x89b644: r0 = addAll()
    //     0x89b644: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0x89b648: b               #0x89b6a0
    // 0x89b64c: ldur            x0, [fp, #-0x60]
    // 0x89b650: ldur            x2, [fp, #-0x80]
    // 0x89b654: LoadField: r1 = r0->field_f
    //     0x89b654: ldur            w1, [x0, #0xf]
    // 0x89b658: DecompressPointer r1
    //     0x89b658: add             x1, x1, HEAP, lsl #32
    // 0x89b65c: ArrayLoad: r3 = r1[r2]  ; Unknown_4
    //     0x89b65c: add             x16, x1, x2, lsl #2
    //     0x89b660: ldur            w3, [x16, #0xf]
    // 0x89b664: DecompressPointer r3
    //     0x89b664: add             x3, x3, HEAP, lsl #32
    // 0x89b668: stur            x3, [fp, #-0x70]
    // 0x89b66c: LoadField: r1 = r3->field_1b
    //     0x89b66c: ldur            w1, [x3, #0x1b]
    // 0x89b670: DecompressPointer r1
    //     0x89b670: add             x1, x1, HEAP, lsl #32
    // 0x89b674: tbnz            w1, #4, #0x89b694
    // 0x89b678: ldur            x4, [fp, #-0x68]
    // 0x89b67c: ArrayLoad: r1 = r3[0]  ; List_4
    //     0x89b67c: ldur            w1, [x3, #0x17]
    // 0x89b680: DecompressPointer r1
    //     0x89b680: add             x1, x1, HEAP, lsl #32
    // 0x89b684: cmp             w1, w4
    // 0x89b688: b.ne            #0x89b694
    // 0x89b68c: mov             x1, x3
    // 0x89b690: r0 = _layoutWithoutResize()
    //     0x89b690: bl              #0x89b794  ; [package:flutter/src/rendering/object.dart] RenderObject::_layoutWithoutResize
    // 0x89b694: ldur            x0, [fp, #-0x80]
    // 0x89b698: add             x6, x0, #1
    // 0x89b69c: b               #0x89b5ac
    // 0x89b6a0: ldur            x0, [fp, #-0x68]
    // 0x89b6a4: r2 = false
    //     0x89b6a4: add             x2, NULL, #0x30  ; false
    // 0x89b6a8: StoreField: r0->field_1b = r2
    //     0x89b6a8: stur            w2, [x0, #0x1b]
    // 0x89b6ac: b               #0x89b52c
    // 0x89b6b0: r2 = false
    //     0x89b6b0: add             x2, NULL, #0x30  ; false
    // 0x89b6b4: LoadField: r1 = r0->field_3f
    //     0x89b6b4: ldur            w1, [x0, #0x3f]
    // 0x89b6b8: DecompressPointer r1
    //     0x89b6b8: add             x1, x1, HEAP, lsl #32
    // 0x89b6bc: r0 = iterator()
    //     0x89b6bc: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x89b6c0: stur            x0, [fp, #-0x70]
    // 0x89b6c4: LoadField: r2 = r0->field_7
    //     0x89b6c4: ldur            w2, [x0, #7]
    // 0x89b6c8: DecompressPointer r2
    //     0x89b6c8: add             x2, x2, HEAP, lsl #32
    // 0x89b6cc: stur            x2, [fp, #-0x60]
    // 0x89b6d0: CheckStackOverflow
    //     0x89b6d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b6d4: cmp             SP, x16
    //     0x89b6d8: b.ls            #0x89b78c
    // 0x89b6dc: mov             x1, x0
    // 0x89b6e0: r0 = moveNext()
    //     0x89b6e0: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x89b6e4: tbnz            w0, #4, #0x89b740
    // 0x89b6e8: ldur            x3, [fp, #-0x70]
    // 0x89b6ec: LoadField: r4 = r3->field_33
    //     0x89b6ec: ldur            w4, [x3, #0x33]
    // 0x89b6f0: DecompressPointer r4
    //     0x89b6f0: add             x4, x4, HEAP, lsl #32
    // 0x89b6f4: stur            x4, [fp, #-0x78]
    // 0x89b6f8: cmp             w4, NULL
    // 0x89b6fc: b.ne            #0x89b72c
    // 0x89b700: mov             x0, x4
    // 0x89b704: ldur            x2, [fp, #-0x60]
    // 0x89b708: r1 = Null
    //     0x89b708: mov             x1, NULL
    // 0x89b70c: cmp             w2, NULL
    // 0x89b710: b.eq            #0x89b72c
    // 0x89b714: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x89b714: ldur            w4, [x2, #0x17]
    // 0x89b718: DecompressPointer r4
    //     0x89b718: add             x4, x4, HEAP, lsl #32
    // 0x89b71c: r8 = X0
    //     0x89b71c: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x89b720: LoadField: r9 = r4->field_7
    //     0x89b720: ldur            x9, [x4, #7]
    // 0x89b724: r3 = Null
    //     0x89b724: ldr             x3, [PP, #0x2de8]  ; [pp+0x2de8] Null
    // 0x89b728: blr             x9
    // 0x89b72c: ldur            x1, [fp, #-0x78]
    // 0x89b730: r0 = flushLayout()
    //     0x89b730: bl              #0x89b50c  ; [package:flutter/src/rendering/object.dart] PipelineOwner::flushLayout
    // 0x89b734: ldur            x0, [fp, #-0x70]
    // 0x89b738: ldur            x2, [fp, #-0x60]
    // 0x89b73c: b               #0x89b6d0
    // 0x89b740: ldur            x2, [fp, #-0x68]
    // 0x89b744: r3 = false
    //     0x89b744: add             x3, NULL, #0x30  ; false
    // 0x89b748: StoreField: r2->field_1b = r3
    //     0x89b748: stur            w3, [x2, #0x1b]
    // 0x89b74c: r0 = Null
    //     0x89b74c: mov             x0, NULL
    // 0x89b750: LeaveFrame
    //     0x89b750: mov             SP, fp
    //     0x89b754: ldp             fp, lr, [SP], #0x10
    // 0x89b758: ret
    //     0x89b758: ret             
    // 0x89b75c: sub             SP, fp, #0x98
    // 0x89b760: ldur            x2, [fp, #-0x68]
    // 0x89b764: r3 = false
    //     0x89b764: add             x3, NULL, #0x30  ; false
    // 0x89b768: StoreField: r2->field_1b = r3
    //     0x89b768: stur            w3, [x2, #0x1b]
    // 0x89b76c: r0 = ReThrow()
    //     0x89b76c: bl              #0x13ddb00  ; ReThrowStub
    // 0x89b770: brk             #0
    // 0x89b774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b774: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b778: b               #0x89b52c
    // 0x89b77c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b77c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b780: b               #0x89b538
    // 0x89b784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b784: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b788: b               #0x89b5c8
    // 0x89b78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b78c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b790: b               #0x89b6dc
  }
  _ adoptChild(/* No info */) {
    // ** addr: 0xb8f554, size: 0x6c
    // 0xb8f554: EnterFrame
    //     0xb8f554: stp             fp, lr, [SP, #-0x10]!
    //     0xb8f558: mov             fp, SP
    // 0xb8f55c: AllocStack(0x10)
    //     0xb8f55c: sub             SP, SP, #0x10
    // 0xb8f560: SetupParameters(PipelineOwner this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb8f560: mov             x3, x1
    //     0xb8f564: mov             x0, x2
    //     0xb8f568: stur            x1, [fp, #-8]
    //     0xb8f56c: stur            x2, [fp, #-0x10]
    // 0xb8f570: CheckStackOverflow
    //     0xb8f570: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8f574: cmp             SP, x16
    //     0xb8f578: b.ls            #0xb8f5b8
    // 0xb8f57c: LoadField: r1 = r3->field_3f
    //     0xb8f57c: ldur            w1, [x3, #0x3f]
    // 0xb8f580: DecompressPointer r1
    //     0xb8f580: add             x1, x1, HEAP, lsl #32
    // 0xb8f584: mov             x2, x0
    // 0xb8f588: r0 = add()
    //     0xb8f588: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xb8f58c: ldur            x0, [fp, #-8]
    // 0xb8f590: LoadField: r2 = r0->field_43
    //     0xb8f590: ldur            w2, [x0, #0x43]
    // 0xb8f594: DecompressPointer r2
    //     0xb8f594: add             x2, x2, HEAP, lsl #32
    // 0xb8f598: cmp             w2, NULL
    // 0xb8f59c: b.eq            #0xb8f5a8
    // 0xb8f5a0: ldur            x1, [fp, #-0x10]
    // 0xb8f5a4: r0 = attach()
    //     0xb8f5a4: bl              #0x8440c0  ; [package:flutter/src/rendering/object.dart] PipelineOwner::attach
    // 0xb8f5a8: r0 = Null
    //     0xb8f5a8: mov             x0, NULL
    // 0xb8f5ac: LeaveFrame
    //     0xb8f5ac: mov             SP, fp
    //     0xb8f5b0: ldp             fp, lr, [SP], #0x10
    // 0xb8f5b4: ret
    //     0xb8f5b4: ret             
    // 0xb8f5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8f5b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8f5bc: b               #0xb8f57c
  }
  set _ rootNode=(/* No info */) {
    // ** addr: 0xb8f65c, size: 0xa8
    // 0xb8f65c: EnterFrame
    //     0xb8f65c: stp             fp, lr, [SP, #-0x10]!
    //     0xb8f660: mov             fp, SP
    // 0xb8f664: AllocStack(0x10)
    //     0xb8f664: sub             SP, SP, #0x10
    // 0xb8f668: SetupParameters(PipelineOwner this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb8f668: mov             x0, x2
    //     0xb8f66c: stur            x2, [fp, #-0x10]
    //     0xb8f670: mov             x2, x1
    //     0xb8f674: stur            x1, [fp, #-8]
    // 0xb8f678: CheckStackOverflow
    //     0xb8f678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8f67c: cmp             SP, x16
    //     0xb8f680: b.ls            #0xb8f6fc
    // 0xb8f684: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xb8f684: ldur            w1, [x2, #0x17]
    // 0xb8f688: DecompressPointer r1
    //     0xb8f688: add             x1, x1, HEAP, lsl #32
    // 0xb8f68c: cmp             w1, w0
    // 0xb8f690: b.ne            #0xb8f6a4
    // 0xb8f694: r0 = Null
    //     0xb8f694: mov             x0, NULL
    // 0xb8f698: LeaveFrame
    //     0xb8f698: mov             SP, fp
    //     0xb8f69c: ldp             fp, lr, [SP], #0x10
    // 0xb8f6a0: ret
    //     0xb8f6a0: ret             
    // 0xb8f6a4: cmp             w1, NULL
    // 0xb8f6a8: b.ne            #0xb8f6b4
    // 0xb8f6ac: mov             x1, x0
    // 0xb8f6b0: b               #0xb8f6c0
    // 0xb8f6b4: r0 = detach()
    //     0xb8f6b4: bl              #0xc09570  ; [dart:mixin_deduplication] _MixinApplication423&RenderObject&RenderObjectWithChildMixin::detach
    // 0xb8f6b8: ldur            x2, [fp, #-8]
    // 0xb8f6bc: ldur            x1, [fp, #-0x10]
    // 0xb8f6c0: mov             x0, x1
    // 0xb8f6c4: ArrayStore: r2[0] = r0  ; List_4
    //     0xb8f6c4: stur            w0, [x2, #0x17]
    //     0xb8f6c8: ldurb           w16, [x2, #-1]
    //     0xb8f6cc: ldurb           w17, [x0, #-1]
    //     0xb8f6d0: and             x16, x17, x16, lsr #2
    //     0xb8f6d4: tst             x16, HEAP, lsr #32
    //     0xb8f6d8: b.eq            #0xb8f6e0
    //     0xb8f6dc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb8f6e0: cmp             w1, NULL
    // 0xb8f6e4: b.eq            #0xb8f6ec
    // 0xb8f6e8: r0 = attach()
    //     0xb8f6e8: bl              #0xc0d4f4  ; [dart:mixin_deduplication] _MixinApplication423&RenderObject&RenderObjectWithChildMixin::attach
    // 0xb8f6ec: r0 = Null
    //     0xb8f6ec: mov             x0, NULL
    // 0xb8f6f0: LeaveFrame
    //     0xb8f6f0: mov             SP, fp
    //     0xb8f6f4: ldp             fp, lr, [SP], #0x10
    // 0xb8f6f8: ret
    //     0xb8f6f8: ret             
    // 0xb8f6fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8f6fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8f700: b               #0xb8f684
  }
  _ _enableMutationsToDirtySubtrees(/* No info */) {
    // ** addr: 0xbb85a4, size: 0x7c
    // 0xbb85a4: EnterFrame
    //     0xbb85a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbb85a8: mov             fp, SP
    // 0xbb85ac: AllocStack(0x58)
    //     0xbb85ac: sub             SP, SP, #0x58
    // 0xbb85b0: SetupParameters(PipelineOwner this /* r1 => r2, fp-0x48 */, dynamic _ /* r2 => r1, fp-0x50 */)
    //     0xbb85b0: stur            x1, [fp, #-0x48]
    //     0xbb85b4: mov             x16, x2
    //     0xbb85b8: mov             x2, x1
    //     0xbb85bc: mov             x1, x16
    //     0xbb85c0: stur            x1, [fp, #-0x50]
    // 0xbb85c4: CheckStackOverflow
    //     0xbb85c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb85c8: cmp             SP, x16
    //     0xbb85cc: b.ls            #0xbb8618
    // 0xbb85d0: str             x1, [SP]
    // 0xbb85d4: mov             x0, x1
    // 0xbb85d8: ClosureCall
    //     0xbb85d8: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbb85dc: ldur            x2, [x0, #0x1f]
    //     0xbb85e0: blr             x2
    // 0xbb85e4: ldur            x2, [fp, #-0x48]
    // 0xbb85e8: r3 = true
    //     0xbb85e8: add             x3, NULL, #0x20  ; true
    // 0xbb85ec: StoreField: r2->field_1b = r3
    //     0xbb85ec: stur            w3, [x2, #0x1b]
    // 0xbb85f0: r0 = Null
    //     0xbb85f0: mov             x0, NULL
    // 0xbb85f4: LeaveFrame
    //     0xbb85f4: mov             SP, fp
    //     0xbb85f8: ldp             fp, lr, [SP], #0x10
    // 0xbb85fc: ret
    //     0xbb85fc: ret             
    // 0xbb8600: sub             SP, fp, #0x58
    // 0xbb8604: ldur            x2, [fp, #-0x48]
    // 0xbb8608: r3 = true
    //     0xbb8608: add             x3, NULL, #0x20  ; true
    // 0xbb860c: StoreField: r2->field_1b = r3
    //     0xbb860c: stur            w3, [x2, #0x1b]
    // 0xbb8610: r0 = ReThrow()
    //     0xbb8610: bl              #0x13ddb00  ; ReThrowStub
    // 0xbb8614: brk             #0
    // 0xbb8618: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb8618: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb861c: b               #0xbb85d0
  }
  _ dropChild(/* No info */) {
    // ** addr: 0x10f3584, size: 0x6c
    // 0x10f3584: EnterFrame
    //     0x10f3584: stp             fp, lr, [SP, #-0x10]!
    //     0x10f3588: mov             fp, SP
    // 0x10f358c: AllocStack(0x10)
    //     0x10f358c: sub             SP, SP, #0x10
    // 0x10f3590: SetupParameters(PipelineOwner this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x10f3590: mov             x3, x1
    //     0x10f3594: mov             x0, x2
    //     0x10f3598: stur            x1, [fp, #-8]
    //     0x10f359c: stur            x2, [fp, #-0x10]
    // 0x10f35a0: CheckStackOverflow
    //     0x10f35a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f35a4: cmp             SP, x16
    //     0x10f35a8: b.ls            #0x10f35e8
    // 0x10f35ac: LoadField: r1 = r3->field_3f
    //     0x10f35ac: ldur            w1, [x3, #0x3f]
    // 0x10f35b0: DecompressPointer r1
    //     0x10f35b0: add             x1, x1, HEAP, lsl #32
    // 0x10f35b4: mov             x2, x0
    // 0x10f35b8: r0 = remove()
    //     0x10f35b8: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x10f35bc: ldur            x0, [fp, #-8]
    // 0x10f35c0: LoadField: r1 = r0->field_43
    //     0x10f35c0: ldur            w1, [x0, #0x43]
    // 0x10f35c4: DecompressPointer r1
    //     0x10f35c4: add             x1, x1, HEAP, lsl #32
    // 0x10f35c8: cmp             w1, NULL
    // 0x10f35cc: b.eq            #0x10f35d8
    // 0x10f35d0: ldur            x1, [fp, #-0x10]
    // 0x10f35d4: r0 = detach()
    //     0x10f35d4: bl              #0x10f35f0  ; [package:flutter/src/rendering/object.dart] PipelineOwner::detach
    // 0x10f35d8: r0 = Null
    //     0x10f35d8: mov             x0, NULL
    // 0x10f35dc: LeaveFrame
    //     0x10f35dc: mov             SP, fp
    //     0x10f35e0: ldp             fp, lr, [SP], #0x10
    // 0x10f35e4: ret
    //     0x10f35e4: ret             
    // 0x10f35e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f35e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f35ec: b               #0x10f35ac
  }
  _ detach(/* No info */) {
    // ** addr: 0x10f35f0, size: 0x1d4
    // 0x10f35f0: EnterFrame
    //     0x10f35f0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f35f4: mov             fp, SP
    // 0x10f35f8: AllocStack(0x28)
    //     0x10f35f8: sub             SP, SP, #0x28
    // 0x10f35fc: SetupParameters(PipelineOwner this /* r1 => r0, fp-0x10 */)
    //     0x10f35fc: mov             x0, x1
    //     0x10f3600: stur            x1, [fp, #-0x10]
    // 0x10f3604: CheckStackOverflow
    //     0x10f3604: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f3608: cmp             SP, x16
    //     0x10f360c: b.ls            #0x10f37a4
    // 0x10f3610: LoadField: r3 = r0->field_43
    //     0x10f3610: ldur            w3, [x0, #0x43]
    // 0x10f3614: DecompressPointer r3
    //     0x10f3614: add             x3, x3, HEAP, lsl #32
    // 0x10f3618: stur            x3, [fp, #-8]
    // 0x10f361c: cmp             w3, NULL
    // 0x10f3620: b.eq            #0x10f37ac
    // 0x10f3624: mov             x2, x0
    // 0x10f3628: r1 = Function '_updateSemanticsOwner@30266271':.
    //     0x10f3628: ldr             x1, [PP, #0x2ec0]  ; [pp+0x2ec0] AnonymousClosure: (0x844704), in [package:flutter/src/rendering/object.dart] PipelineOwner::_updateSemanticsOwner (0x8441dc)
    // 0x10f362c: r0 = AllocateClosure()
    //     0x10f362c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f3630: ldur            x1, [fp, #-8]
    // 0x10f3634: mov             x2, x0
    // 0x10f3638: r0 = removeListener()
    //     0x10f3638: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10f363c: ldur            x0, [fp, #-0x10]
    // 0x10f3640: StoreField: r0->field_43 = rNULL
    //     0x10f3640: stur            NULL, [x0, #0x43]
    // 0x10f3644: LoadField: r1 = r0->field_3f
    //     0x10f3644: ldur            w1, [x0, #0x3f]
    // 0x10f3648: DecompressPointer r1
    //     0x10f3648: add             x1, x1, HEAP, lsl #32
    // 0x10f364c: r0 = iterator()
    //     0x10f364c: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x10f3650: stur            x0, [fp, #-0x10]
    // 0x10f3654: LoadField: r2 = r0->field_7
    //     0x10f3654: ldur            w2, [x0, #7]
    // 0x10f3658: DecompressPointer r2
    //     0x10f3658: add             x2, x2, HEAP, lsl #32
    // 0x10f365c: stur            x2, [fp, #-8]
    // 0x10f3660: CheckStackOverflow
    //     0x10f3660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f3664: cmp             SP, x16
    //     0x10f3668: b.ls            #0x10f37b0
    // 0x10f366c: mov             x1, x0
    // 0x10f3670: r0 = moveNext()
    //     0x10f3670: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x10f3674: tbnz            w0, #4, #0x10f3794
    // 0x10f3678: ldur            x3, [fp, #-0x10]
    // 0x10f367c: LoadField: r4 = r3->field_33
    //     0x10f367c: ldur            w4, [x3, #0x33]
    // 0x10f3680: DecompressPointer r4
    //     0x10f3680: add             x4, x4, HEAP, lsl #32
    // 0x10f3684: stur            x4, [fp, #-0x18]
    // 0x10f3688: cmp             w4, NULL
    // 0x10f368c: b.ne            #0x10f36c0
    // 0x10f3690: mov             x0, x4
    // 0x10f3694: ldur            x2, [fp, #-8]
    // 0x10f3698: r1 = Null
    //     0x10f3698: mov             x1, NULL
    // 0x10f369c: cmp             w2, NULL
    // 0x10f36a0: b.eq            #0x10f36c0
    // 0x10f36a4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x10f36a4: ldur            w4, [x2, #0x17]
    // 0x10f36a8: DecompressPointer r4
    //     0x10f36a8: add             x4, x4, HEAP, lsl #32
    // 0x10f36ac: r8 = X0
    //     0x10f36ac: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x10f36b0: LoadField: r9 = r4->field_7
    //     0x10f36b0: ldur            x9, [x4, #7]
    // 0x10f36b4: r3 = Null
    //     0x10f36b4: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f310] Null
    //     0x10f36b8: ldr             x3, [x3, #0x310]
    // 0x10f36bc: blr             x9
    // 0x10f36c0: ldur            x0, [fp, #-0x18]
    // 0x10f36c4: LoadField: r3 = r0->field_43
    //     0x10f36c4: ldur            w3, [x0, #0x43]
    // 0x10f36c8: DecompressPointer r3
    //     0x10f36c8: add             x3, x3, HEAP, lsl #32
    // 0x10f36cc: stur            x3, [fp, #-0x20]
    // 0x10f36d0: cmp             w3, NULL
    // 0x10f36d4: b.eq            #0x10f37b8
    // 0x10f36d8: mov             x2, x0
    // 0x10f36dc: r1 = Function '_updateSemanticsOwner@30266271':.
    //     0x10f36dc: ldr             x1, [PP, #0x2ec0]  ; [pp+0x2ec0] AnonymousClosure: (0x844704), in [package:flutter/src/rendering/object.dart] PipelineOwner::_updateSemanticsOwner (0x8441dc)
    // 0x10f36e0: r0 = AllocateClosure()
    //     0x10f36e0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f36e4: ldur            x1, [fp, #-0x20]
    // 0x10f36e8: mov             x2, x0
    // 0x10f36ec: r0 = removeListener()
    //     0x10f36ec: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x10f36f0: ldur            x0, [fp, #-0x18]
    // 0x10f36f4: StoreField: r0->field_43 = rNULL
    //     0x10f36f4: stur            NULL, [x0, #0x43]
    // 0x10f36f8: LoadField: r1 = r0->field_3f
    //     0x10f36f8: ldur            w1, [x0, #0x3f]
    // 0x10f36fc: DecompressPointer r1
    //     0x10f36fc: add             x1, x1, HEAP, lsl #32
    // 0x10f3700: r0 = iterator()
    //     0x10f3700: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x10f3704: stur            x0, [fp, #-0x20]
    // 0x10f3708: LoadField: r2 = r0->field_7
    //     0x10f3708: ldur            w2, [x0, #7]
    // 0x10f370c: DecompressPointer r2
    //     0x10f370c: add             x2, x2, HEAP, lsl #32
    // 0x10f3710: stur            x2, [fp, #-0x18]
    // 0x10f3714: CheckStackOverflow
    //     0x10f3714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f3718: cmp             SP, x16
    //     0x10f371c: b.ls            #0x10f37bc
    // 0x10f3720: mov             x1, x0
    // 0x10f3724: r0 = moveNext()
    //     0x10f3724: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x10f3728: tbnz            w0, #4, #0x10f3788
    // 0x10f372c: ldur            x3, [fp, #-0x20]
    // 0x10f3730: LoadField: r4 = r3->field_33
    //     0x10f3730: ldur            w4, [x3, #0x33]
    // 0x10f3734: DecompressPointer r4
    //     0x10f3734: add             x4, x4, HEAP, lsl #32
    // 0x10f3738: stur            x4, [fp, #-0x28]
    // 0x10f373c: cmp             w4, NULL
    // 0x10f3740: b.ne            #0x10f3774
    // 0x10f3744: mov             x0, x4
    // 0x10f3748: ldur            x2, [fp, #-0x18]
    // 0x10f374c: r1 = Null
    //     0x10f374c: mov             x1, NULL
    // 0x10f3750: cmp             w2, NULL
    // 0x10f3754: b.eq            #0x10f3774
    // 0x10f3758: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x10f3758: ldur            w4, [x2, #0x17]
    // 0x10f375c: DecompressPointer r4
    //     0x10f375c: add             x4, x4, HEAP, lsl #32
    // 0x10f3760: r8 = X0
    //     0x10f3760: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x10f3764: LoadField: r9 = r4->field_7
    //     0x10f3764: ldur            x9, [x4, #7]
    // 0x10f3768: r3 = Null
    //     0x10f3768: add             x3, PP, #0x8f, lsl #12  ; [pp+0x8f320] Null
    //     0x10f376c: ldr             x3, [x3, #0x320]
    // 0x10f3770: blr             x9
    // 0x10f3774: ldur            x1, [fp, #-0x28]
    // 0x10f3778: r0 = detach()
    //     0x10f3778: bl              #0x10f35f0  ; [package:flutter/src/rendering/object.dart] PipelineOwner::detach
    // 0x10f377c: ldur            x0, [fp, #-0x20]
    // 0x10f3780: ldur            x2, [fp, #-0x18]
    // 0x10f3784: b               #0x10f3714
    // 0x10f3788: ldur            x0, [fp, #-0x10]
    // 0x10f378c: ldur            x2, [fp, #-8]
    // 0x10f3790: b               #0x10f3660
    // 0x10f3794: r0 = Null
    //     0x10f3794: mov             x0, NULL
    // 0x10f3798: LeaveFrame
    //     0x10f3798: mov             SP, fp
    //     0x10f379c: ldp             fp, lr, [SP], #0x10
    // 0x10f37a0: ret
    //     0x10f37a0: ret             
    // 0x10f37a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f37a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f37a8: b               #0x10f3610
    // 0x10f37ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f37ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f37b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f37b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f37b4: b               #0x10f366c
    // 0x10f37b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10f37b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10f37bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f37bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f37c0: b               #0x10f3720
  }
}

// class id: 4675, size: 0x48, field offset: 0x8
abstract class RenderObject extends _MixinApplication5&Object&DiagnosticableTreeMixin
    implements HitTestTarget {

  late final _RenderObjectSemantics _semantics; // offset: 0x44
  late bool _needsCompositing; // offset: 0x38
  late bool _wasRepaintBoundary; // offset: 0x2c

  _ markNeedsSemanticsUpdate(/* No info */) {
    // ** addr: 0x8373c8, size: 0x80
    // 0x8373c8: EnterFrame
    //     0x8373c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8373cc: mov             fp, SP
    // 0x8373d0: CheckStackOverflow
    //     0x8373d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8373d4: cmp             SP, x16
    //     0x8373d8: b.ls            #0x837440
    // 0x8373dc: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x8373dc: ldur            w0, [x1, #0x17]
    // 0x8373e0: DecompressPointer r0
    //     0x8373e0: add             x0, x0, HEAP, lsl #32
    // 0x8373e4: cmp             w0, NULL
    // 0x8373e8: b.eq            #0x8373fc
    // 0x8373ec: LoadField: r2 = r0->field_2b
    //     0x8373ec: ldur            w2, [x0, #0x2b]
    // 0x8373f0: DecompressPointer r2
    //     0x8373f0: add             x2, x2, HEAP, lsl #32
    // 0x8373f4: cmp             w2, NULL
    // 0x8373f8: b.ne            #0x83740c
    // 0x8373fc: r0 = Null
    //     0x8373fc: mov             x0, NULL
    // 0x837400: LeaveFrame
    //     0x837400: mov             SP, fp
    //     0x837404: ldp             fp, lr, [SP], #0x10
    // 0x837408: ret
    //     0x837408: ret             
    // 0x83740c: LoadField: r0 = r1->field_43
    //     0x83740c: ldur            w0, [x1, #0x43]
    // 0x837410: DecompressPointer r0
    //     0x837410: add             x0, x0, HEAP, lsl #32
    // 0x837414: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x837418: cmp             w0, w16
    // 0x83741c: b.ne            #0x837428
    // 0x837420: r2 = _semantics
    //     0x837420: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0x837424: r0 = InitLateFinalInstanceField()
    //     0x837424: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x837428: mov             x1, x0
    // 0x83742c: r0 = markNeedsUpdate()
    //     0x83742c: bl              #0x837480  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::markNeedsUpdate
    // 0x837430: r0 = Null
    //     0x837430: mov             x0, NULL
    // 0x837434: LeaveFrame
    //     0x837434: mov             SP, fp
    //     0x837438: ldp             fp, lr, [SP], #0x10
    // 0x83743c: ret
    //     0x83743c: ret             
    // 0x837440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x837440: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x837444: b               #0x8373dc
  }
  [closure] void markNeedsSemanticsUpdate(dynamic) {
    // ** addr: 0x837448, size: 0x38
    // 0x837448: EnterFrame
    //     0x837448: stp             fp, lr, [SP, #-0x10]!
    //     0x83744c: mov             fp, SP
    // 0x837450: ldr             x0, [fp, #0x10]
    // 0x837454: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x837454: ldur            w1, [x0, #0x17]
    // 0x837458: DecompressPointer r1
    //     0x837458: add             x1, x1, HEAP, lsl #32
    // 0x83745c: CheckStackOverflow
    //     0x83745c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x837460: cmp             SP, x16
    //     0x837464: b.ls            #0x837478
    // 0x837468: r0 = markNeedsSemanticsUpdate()
    //     0x837468: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x83746c: LeaveFrame
    //     0x83746c: mov             SP, fp
    //     0x837470: ldp             fp, lr, [SP], #0x10
    // 0x837474: ret
    //     0x837474: ret             
    // 0x837478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x837478: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83747c: b               #0x837468
  }
  _RenderObjectSemantics _semantics(RenderObject) {
    // ** addr: 0x8392e0, size: 0x44
    // 0x8392e0: EnterFrame
    //     0x8392e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8392e4: mov             fp, SP
    // 0x8392e8: AllocStack(0x8)
    //     0x8392e8: sub             SP, SP, #8
    // 0x8392ec: CheckStackOverflow
    //     0x8392ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8392f0: cmp             SP, x16
    //     0x8392f4: b.ls            #0x83931c
    // 0x8392f8: r0 = _RenderObjectSemantics()
    //     0x8392f8: bl              #0x8395bc  ; Allocate_RenderObjectSemanticsStub -> _RenderObjectSemantics (size=0x4c)
    // 0x8392fc: mov             x1, x0
    // 0x839300: ldr             x2, [fp, #0x10]
    // 0x839304: stur            x0, [fp, #-8]
    // 0x839308: r0 = _RenderObjectSemantics()
    //     0x839308: bl              #0x839324  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::_RenderObjectSemantics
    // 0x83930c: ldur            x0, [fp, #-8]
    // 0x839310: LeaveFrame
    //     0x839310: mov             SP, fp
    //     0x839314: ldp             fp, lr, [SP], #0x10
    // 0x839318: ret
    //     0x839318: ret             
    // 0x83931c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83931c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x839320: b               #0x8392f8
  }
  _ markNeedsCompositingBitsUpdate(/* No info */) {
    // ** addr: 0x8395c8, size: 0x1bc
    // 0x8395c8: EnterFrame
    //     0x8395c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8395cc: mov             fp, SP
    // 0x8395d0: AllocStack(0x18)
    //     0x8395d0: sub             SP, SP, #0x18
    // 0x8395d4: SetupParameters(RenderObject this /* r1 => r2, fp-0x8 */)
    //     0x8395d4: mov             x2, x1
    //     0x8395d8: stur            x1, [fp, #-8]
    // 0x8395dc: CheckStackOverflow
    //     0x8395dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8395e0: cmp             SP, x16
    //     0x8395e4: b.ls            #0x839774
    // 0x8395e8: LoadField: r0 = r2->field_33
    //     0x8395e8: ldur            w0, [x2, #0x33]
    // 0x8395ec: DecompressPointer r0
    //     0x8395ec: add             x0, x0, HEAP, lsl #32
    // 0x8395f0: tbnz            w0, #4, #0x839604
    // 0x8395f4: r0 = Null
    //     0x8395f4: mov             x0, NULL
    // 0x8395f8: LeaveFrame
    //     0x8395f8: mov             SP, fp
    //     0x8395fc: ldp             fp, lr, [SP], #0x10
    // 0x839600: ret
    //     0x839600: ret             
    // 0x839604: r0 = true
    //     0x839604: add             x0, NULL, #0x20  ; true
    // 0x839608: StoreField: r2->field_33 = r0
    //     0x839608: stur            w0, [x2, #0x33]
    // 0x83960c: r0 = LoadClassIdInstr(r2)
    //     0x83960c: ldur            x0, [x2, #-1]
    //     0x839610: ubfx            x0, x0, #0xc, #0x14
    // 0x839614: mov             x1, x2
    // 0x839618: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x839618: mov             x17, #0xfc0
    //     0x83961c: movk            x17, #1, lsl #16
    //     0x839620: add             lr, x0, x17
    //     0x839624: ldr             lr, [x21, lr, lsl #3]
    //     0x839628: blr             lr
    // 0x83962c: mov             x2, x0
    // 0x839630: stur            x2, [fp, #-0x10]
    // 0x839634: cmp             w2, NULL
    // 0x839638: b.eq            #0x8396d0
    // 0x83963c: LoadField: r0 = r2->field_33
    //     0x83963c: ldur            w0, [x2, #0x33]
    // 0x839640: DecompressPointer r0
    //     0x839640: add             x0, x0, HEAP, lsl #32
    // 0x839644: tbnz            w0, #4, #0x839658
    // 0x839648: r0 = Null
    //     0x839648: mov             x0, NULL
    // 0x83964c: LeaveFrame
    //     0x83964c: mov             SP, fp
    //     0x839650: ldp             fp, lr, [SP], #0x10
    // 0x839654: ret
    //     0x839654: ret             
    // 0x839658: ldur            x3, [fp, #-8]
    // 0x83965c: LoadField: r0 = r3->field_2b
    //     0x83965c: ldur            w0, [x3, #0x2b]
    // 0x839660: DecompressPointer r0
    //     0x839660: add             x0, x0, HEAP, lsl #32
    // 0x839664: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x839668: cmp             w0, w16
    // 0x83966c: b.eq            #0x83977c
    // 0x839670: tbnz            w0, #4, #0x839698
    // 0x839674: r0 = LoadClassIdInstr(r3)
    //     0x839674: ldur            x0, [x3, #-1]
    //     0x839678: ubfx            x0, x0, #0xc, #0x14
    // 0x83967c: mov             x1, x3
    // 0x839680: r0 = GDT[cid_x0 + 0xfd90]()
    //     0x839680: mov             x17, #0xfd90
    //     0x839684: add             lr, x0, x17
    //     0x839688: ldr             lr, [x21, lr, lsl #3]
    //     0x83968c: blr             lr
    // 0x839690: tbz             w0, #4, #0x8396d0
    // 0x839694: ldur            x2, [fp, #-0x10]
    // 0x839698: r0 = LoadClassIdInstr(r2)
    //     0x839698: ldur            x0, [x2, #-1]
    //     0x83969c: ubfx            x0, x0, #0xc, #0x14
    // 0x8396a0: mov             x1, x2
    // 0x8396a4: r0 = GDT[cid_x0 + 0xfd90]()
    //     0x8396a4: mov             x17, #0xfd90
    //     0x8396a8: add             lr, x0, x17
    //     0x8396ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8396b0: blr             lr
    // 0x8396b4: tbz             w0, #4, #0x8396d0
    // 0x8396b8: ldur            x1, [fp, #-0x10]
    // 0x8396bc: r0 = markNeedsCompositingBitsUpdate()
    //     0x8396bc: bl              #0x8395c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0x8396c0: r0 = Null
    //     0x8396c0: mov             x0, NULL
    // 0x8396c4: LeaveFrame
    //     0x8396c4: mov             SP, fp
    //     0x8396c8: ldp             fp, lr, [SP], #0x10
    // 0x8396cc: ret
    //     0x8396cc: ret             
    // 0x8396d0: ldur            x0, [fp, #-8]
    // 0x8396d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8396d4: ldur            w1, [x0, #0x17]
    // 0x8396d8: DecompressPointer r1
    //     0x8396d8: add             x1, x1, HEAP, lsl #32
    // 0x8396dc: cmp             w1, NULL
    // 0x8396e0: b.eq            #0x839764
    // 0x8396e4: LoadField: r2 = r1->field_23
    //     0x8396e4: ldur            w2, [x1, #0x23]
    // 0x8396e8: DecompressPointer r2
    //     0x8396e8: add             x2, x2, HEAP, lsl #32
    // 0x8396ec: stur            x2, [fp, #-0x10]
    // 0x8396f0: LoadField: r1 = r2->field_b
    //     0x8396f0: ldur            w1, [x2, #0xb]
    // 0x8396f4: LoadField: r3 = r2->field_f
    //     0x8396f4: ldur            w3, [x2, #0xf]
    // 0x8396f8: DecompressPointer r3
    //     0x8396f8: add             x3, x3, HEAP, lsl #32
    // 0x8396fc: LoadField: r4 = r3->field_b
    //     0x8396fc: ldur            w4, [x3, #0xb]
    // 0x839700: r3 = LoadInt32Instr(r1)
    //     0x839700: sbfx            x3, x1, #1, #0x1f
    // 0x839704: stur            x3, [fp, #-0x18]
    // 0x839708: r1 = LoadInt32Instr(r4)
    //     0x839708: sbfx            x1, x4, #1, #0x1f
    // 0x83970c: cmp             x3, x1
    // 0x839710: b.ne            #0x83971c
    // 0x839714: mov             x1, x2
    // 0x839718: r0 = _growToNextCapacity()
    //     0x839718: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x83971c: ldur            x2, [fp, #-0x10]
    // 0x839720: ldur            x3, [fp, #-0x18]
    // 0x839724: add             x4, x3, #1
    // 0x839728: lsl             x5, x4, #1
    // 0x83972c: StoreField: r2->field_b = r5
    //     0x83972c: stur            w5, [x2, #0xb]
    // 0x839730: LoadField: r1 = r2->field_f
    //     0x839730: ldur            w1, [x2, #0xf]
    // 0x839734: DecompressPointer r1
    //     0x839734: add             x1, x1, HEAP, lsl #32
    // 0x839738: ldur            x0, [fp, #-8]
    // 0x83973c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x83973c: add             x25, x1, x3, lsl #2
    //     0x839740: add             x25, x25, #0xf
    //     0x839744: str             w0, [x25]
    //     0x839748: tbz             w0, #0, #0x839764
    //     0x83974c: ldurb           w16, [x1, #-1]
    //     0x839750: ldurb           w17, [x0, #-1]
    //     0x839754: and             x16, x17, x16, lsr #2
    //     0x839758: tst             x16, HEAP, lsr #32
    //     0x83975c: b.eq            #0x839764
    //     0x839760: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x839764: r0 = Null
    //     0x839764: mov             x0, NULL
    // 0x839768: LeaveFrame
    //     0x839768: mov             SP, fp
    //     0x83976c: ldp             fp, lr, [SP], #0x10
    // 0x839770: ret
    //     0x839770: ret             
    // 0x839774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x839774: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x839778: b               #0x8395e8
    // 0x83977c: r9 = _wasRepaintBoundary
    //     0x83977c: ldr             x9, [PP, #0x2dd8]  ; [pp+0x2dd8] Field <RenderObject._wasRepaintBoundary@30266271>: late (offset: 0x2c)
    // 0x839780: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x839780: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x839784, size: 0x48
    // 0x839784: EnterFrame
    //     0x839784: stp             fp, lr, [SP, #-0x10]!
    //     0x839788: mov             fp, SP
    // 0x83978c: CheckStackOverflow
    //     0x83978c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x839790: cmp             SP, x16
    //     0x839794: b.ls            #0x8397c4
    // 0x839798: ldr             x1, [fp, #0x10]
    // 0x83979c: r0 = LoadClassIdInstr(r1)
    //     0x83979c: ldur            x0, [x1, #-1]
    //     0x8397a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8397a4: r0 = GDT[cid_x0 + 0xee23]()
    //     0x8397a4: mov             x17, #0xee23
    //     0x8397a8: add             lr, x0, x17
    //     0x8397ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8397b0: blr             lr
    // 0x8397b4: r0 = Null
    //     0x8397b4: mov             x0, NULL
    // 0x8397b8: LeaveFrame
    //     0x8397b8: mov             SP, fp
    //     0x8397bc: ldp             fp, lr, [SP], #0x10
    // 0x8397c0: ret
    //     0x8397c0: ret             
    // 0x8397c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8397c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8397c8: b               #0x839798
  }
  _ getTransformTo(/* No info */) {
    // ** addr: 0x857070, size: 0x6c8
    // 0x857070: EnterFrame
    //     0x857070: stp             fp, lr, [SP, #-0x10]!
    //     0x857074: mov             fp, SP
    // 0x857078: AllocStack(0x68)
    //     0x857078: sub             SP, SP, #0x68
    // 0x85707c: SetupParameters(RenderObject this /* r1 => r3, fp-0x30 */, dynamic _ /* r2 => r2, fp-0x38 */)
    //     0x85707c: mov             x3, x1
    //     0x857080: stur            x1, [fp, #-0x30]
    //     0x857084: stur            x2, [fp, #-0x38]
    // 0x857088: CheckStackOverflow
    //     0x857088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85708c: cmp             SP, x16
    //     0x857090: b.ls            #0x85770c
    // 0x857094: cmp             w2, NULL
    // 0x857098: b.ne            #0x8570c4
    // 0x85709c: ArrayLoad: r0 = r3[0]  ; List_4
    //     0x85709c: ldur            w0, [x3, #0x17]
    // 0x8570a0: DecompressPointer r0
    //     0x8570a0: add             x0, x0, HEAP, lsl #32
    // 0x8570a4: cmp             w0, NULL
    // 0x8570a8: b.eq            #0x857714
    // 0x8570ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x8570ac: ldur            w1, [x0, #0x17]
    // 0x8570b0: DecompressPointer r1
    //     0x8570b0: add             x1, x1, HEAP, lsl #32
    // 0x8570b4: cmp             w1, NULL
    // 0x8570b8: b.eq            #0x857718
    // 0x8570bc: mov             x0, x1
    // 0x8570c0: b               #0x8570c8
    // 0x8570c4: mov             x0, x2
    // 0x8570c8: mov             x1, x3
    // 0x8570cc: mov             x4, x0
    // 0x8570d0: r6 = Null
    //     0x8570d0: mov             x6, NULL
    // 0x8570d4: r5 = Null
    //     0x8570d4: mov             x5, NULL
    // 0x8570d8: stur            x6, [fp, #-0x18]
    // 0x8570dc: stur            x5, [fp, #-0x20]
    // 0x8570e0: stur            x4, [fp, #-0x28]
    // 0x8570e4: CheckStackOverflow
    //     0x8570e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8570e8: cmp             SP, x16
    //     0x8570ec: b.ls            #0x85771c
    // 0x8570f0: cmp             w1, w4
    // 0x8570f4: b.eq            #0x8572ec
    // 0x8570f8: LoadField: r7 = r1->field_b
    //     0x8570f8: ldur            x7, [x1, #0xb]
    // 0x8570fc: stur            x7, [fp, #-0x10]
    // 0x857100: LoadField: r8 = r4->field_b
    //     0x857100: ldur            x8, [x4, #0xb]
    // 0x857104: stur            x8, [fp, #-8]
    // 0x857108: cmp             x7, x8
    // 0x85710c: b.lt            #0x8571cc
    // 0x857110: r0 = LoadClassIdInstr(r1)
    //     0x857110: ldur            x0, [x1, #-1]
    //     0x857114: ubfx            x0, x0, #0xc, #0x14
    // 0x857118: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x857118: mov             x17, #0xfc0
    //     0x85711c: movk            x17, #1, lsl #16
    //     0x857120: add             lr, x0, x17
    //     0x857124: ldr             lr, [x21, lr, lsl #3]
    //     0x857128: blr             lr
    // 0x85712c: stur            x0, [fp, #-0x40]
    // 0x857130: cmp             w0, NULL
    // 0x857134: b.eq            #0x857664
    // 0x857138: ldur            x2, [fp, #-0x18]
    // 0x85713c: cmp             w2, NULL
    // 0x857140: b.ne            #0x85718c
    // 0x857144: ldur            x3, [fp, #-0x30]
    // 0x857148: r4 = 2
    //     0x857148: mov             x4, #2
    // 0x85714c: mov             x2, x4
    // 0x857150: r1 = Null
    //     0x857150: mov             x1, NULL
    // 0x857154: r0 = AllocateArray()
    //     0x857154: bl              #0x13df928  ; AllocateArrayStub
    // 0x857158: mov             x2, x0
    // 0x85715c: ldur            x0, [fp, #-0x30]
    // 0x857160: stur            x2, [fp, #-0x48]
    // 0x857164: StoreField: r2->field_f = r0
    //     0x857164: stur            w0, [x2, #0xf]
    // 0x857168: r1 = <RenderObject>
    //     0x857168: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x85716c: r0 = AllocateGrowableArray()
    //     0x85716c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x857170: mov             x2, x0
    // 0x857174: ldur            x0, [fp, #-0x48]
    // 0x857178: StoreField: r2->field_f = r0
    //     0x857178: stur            w0, [x2, #0xf]
    // 0x85717c: r1 = 2
    //     0x85717c: mov             x1, #2
    // 0x857180: StoreField: r2->field_b = r1
    //     0x857180: stur            w1, [x2, #0xb]
    // 0x857184: mov             x0, x2
    // 0x857188: b               #0x857194
    // 0x85718c: r1 = 2
    //     0x85718c: mov             x1, #2
    // 0x857190: mov             x0, x2
    // 0x857194: stur            x2, [fp, #-0x48]
    // 0x857198: r3 = LoadClassIdInstr(r0)
    //     0x857198: ldur            x3, [x0, #-1]
    //     0x85719c: ubfx            x3, x3, #0xc, #0x14
    // 0x8571a0: ldur            x16, [fp, #-0x40]
    // 0x8571a4: stp             x16, x0, [SP]
    // 0x8571a8: mov             x0, x3
    // 0x8571ac: r0 = GDT[cid_x0 + 0x175da]()
    //     0x8571ac: mov             x17, #0x75da
    //     0x8571b0: movk            x17, #1, lsl #16
    //     0x8571b4: add             lr, x0, x17
    //     0x8571b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8571bc: blr             lr
    // 0x8571c0: ldur            x6, [fp, #-0x48]
    // 0x8571c4: ldur            x2, [fp, #-0x40]
    // 0x8571c8: b               #0x8571d8
    // 0x8571cc: mov             x2, x6
    // 0x8571d0: mov             x6, x2
    // 0x8571d4: mov             x2, x1
    // 0x8571d8: ldur            x0, [fp, #-0x10]
    // 0x8571dc: ldur            x1, [fp, #-8]
    // 0x8571e0: stur            x6, [fp, #-0x40]
    // 0x8571e4: stur            x2, [fp, #-0x48]
    // 0x8571e8: cmp             x0, x1
    // 0x8571ec: b.gt            #0x8572c8
    // 0x8571f0: ldur            x0, [fp, #-0x28]
    // 0x8571f4: r1 = LoadClassIdInstr(r0)
    //     0x8571f4: ldur            x1, [x0, #-1]
    //     0x8571f8: ubfx            x1, x1, #0xc, #0x14
    // 0x8571fc: mov             x16, x0
    // 0x857200: mov             x0, x1
    // 0x857204: mov             x1, x16
    // 0x857208: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x857208: mov             x17, #0xfc0
    //     0x85720c: movk            x17, #1, lsl #16
    //     0x857210: add             lr, x0, x17
    //     0x857214: ldr             lr, [x21, lr, lsl #3]
    //     0x857218: blr             lr
    // 0x85721c: stur            x0, [fp, #-0x50]
    // 0x857220: cmp             w0, NULL
    // 0x857224: b.eq            #0x8576b8
    // 0x857228: ldur            x3, [fp, #-0x20]
    // 0x85722c: cmp             w3, NULL
    // 0x857230: b.ne            #0x857284
    // 0x857234: ldur            x4, [fp, #-0x38]
    // 0x857238: r3 = 2
    //     0x857238: mov             x3, #2
    // 0x85723c: cmp             w4, NULL
    // 0x857240: b.eq            #0x857724
    // 0x857244: mov             x2, x3
    // 0x857248: r1 = Null
    //     0x857248: mov             x1, NULL
    // 0x85724c: r0 = AllocateArray()
    //     0x85724c: bl              #0x13df928  ; AllocateArrayStub
    // 0x857250: mov             x2, x0
    // 0x857254: ldur            x0, [fp, #-0x38]
    // 0x857258: stur            x2, [fp, #-0x58]
    // 0x85725c: StoreField: r2->field_f = r0
    //     0x85725c: stur            w0, [x2, #0xf]
    // 0x857260: r1 = <RenderObject>
    //     0x857260: ldr             x1, [PP, #0x2a40]  ; [pp+0x2a40] TypeArguments: <RenderObject>
    // 0x857264: r0 = AllocateGrowableArray()
    //     0x857264: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x857268: mov             x2, x0
    // 0x85726c: ldur            x0, [fp, #-0x58]
    // 0x857270: StoreField: r2->field_f = r0
    //     0x857270: stur            w0, [x2, #0xf]
    // 0x857274: r1 = 2
    //     0x857274: mov             x1, #2
    // 0x857278: StoreField: r2->field_b = r1
    //     0x857278: stur            w1, [x2, #0xb]
    // 0x85727c: mov             x0, x2
    // 0x857280: b               #0x857290
    // 0x857284: r1 = 2
    //     0x857284: mov             x1, #2
    // 0x857288: mov             x0, x3
    // 0x85728c: mov             x2, x3
    // 0x857290: stur            x2, [fp, #-0x58]
    // 0x857294: r3 = LoadClassIdInstr(r0)
    //     0x857294: ldur            x3, [x0, #-1]
    //     0x857298: ubfx            x3, x3, #0xc, #0x14
    // 0x85729c: ldur            x16, [fp, #-0x50]
    // 0x8572a0: stp             x16, x0, [SP]
    // 0x8572a4: mov             x0, x3
    // 0x8572a8: r0 = GDT[cid_x0 + 0x175da]()
    //     0x8572a8: mov             x17, #0x75da
    //     0x8572ac: movk            x17, #1, lsl #16
    //     0x8572b0: add             lr, x0, x17
    //     0x8572b4: ldr             lr, [x21, lr, lsl #3]
    //     0x8572b8: blr             lr
    // 0x8572bc: ldur            x5, [fp, #-0x58]
    // 0x8572c0: ldur            x4, [fp, #-0x50]
    // 0x8572c4: b               #0x8572d8
    // 0x8572c8: ldur            x3, [fp, #-0x20]
    // 0x8572cc: ldur            x0, [fp, #-0x28]
    // 0x8572d0: mov             x5, x3
    // 0x8572d4: mov             x4, x0
    // 0x8572d8: ldur            x6, [fp, #-0x40]
    // 0x8572dc: ldur            x1, [fp, #-0x48]
    // 0x8572e0: ldur            x3, [fp, #-0x30]
    // 0x8572e4: ldur            x2, [fp, #-0x38]
    // 0x8572e8: b               #0x8570d8
    // 0x8572ec: mov             x2, x6
    // 0x8572f0: mov             x3, x5
    // 0x8572f4: cmp             w2, NULL
    // 0x8572f8: b.eq            #0x85746c
    // 0x8572fc: ldur            x0, [fp, #-0x38]
    // 0x857300: r0 = Matrix4()
    //     0x857300: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x857304: r4 = 32
    //     0x857304: mov             x4, #0x20
    // 0x857308: stur            x0, [fp, #-0x28]
    // 0x85730c: r0 = AllocateFloat64Array()
    //     0x85730c: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x857310: mov             x1, x0
    // 0x857314: ldur            x0, [fp, #-0x28]
    // 0x857318: StoreField: r0->field_7 = r1
    //     0x857318: stur            w1, [x0, #7]
    // 0x85731c: mov             x1, x0
    // 0x857320: r0 = setIdentity()
    //     0x857320: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x857324: ldur            x0, [fp, #-0x38]
    // 0x857328: cmp             w0, NULL
    // 0x85732c: b.ne            #0x857364
    // 0x857330: ldur            x1, [fp, #-0x18]
    // 0x857334: r0 = LoadClassIdInstr(r1)
    //     0x857334: ldur            x0, [x1, #-1]
    //     0x857338: ubfx            x0, x0, #0xc, #0x14
    // 0x85733c: str             x1, [SP]
    // 0x857340: r0 = GDT[cid_x0 + 0xf078]()
    //     0x857340: mov             x17, #0xf078
    //     0x857344: add             lr, x0, x17
    //     0x857348: ldr             lr, [x21, lr, lsl #3]
    //     0x85734c: blr             lr
    // 0x857350: r1 = LoadInt32Instr(r0)
    //     0x857350: sbfx            x1, x0, #1, #0x1f
    //     0x857354: tbz             w0, #0, #0x85735c
    //     0x857358: ldur            x1, [x0, #7]
    // 0x85735c: sub             x0, x1, #2
    // 0x857360: b               #0x857394
    // 0x857364: ldur            x1, [fp, #-0x18]
    // 0x857368: r0 = LoadClassIdInstr(r1)
    //     0x857368: ldur            x0, [x1, #-1]
    //     0x85736c: ubfx            x0, x0, #0xc, #0x14
    // 0x857370: str             x1, [SP]
    // 0x857374: r0 = GDT[cid_x0 + 0xf078]()
    //     0x857374: mov             x17, #0xf078
    //     0x857378: add             lr, x0, x17
    //     0x85737c: ldr             lr, [x21, lr, lsl #3]
    //     0x857380: blr             lr
    // 0x857384: r1 = LoadInt32Instr(r0)
    //     0x857384: sbfx            x1, x0, #1, #0x1f
    //     0x857388: tbz             w0, #0, #0x857390
    //     0x85738c: ldur            x1, [x0, #7]
    // 0x857390: sub             x0, x1, #1
    // 0x857394: mov             x3, x0
    // 0x857398: ldur            x2, [fp, #-0x18]
    // 0x85739c: stur            x3, [fp, #-8]
    // 0x8573a0: CheckStackOverflow
    //     0x8573a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8573a4: cmp             SP, x16
    //     0x8573a8: b.ls            #0x857728
    // 0x8573ac: cmp             x3, #0
    // 0x8573b0: b.le            #0x857464
    // 0x8573b4: r0 = BoxInt64Instr(r3)
    //     0x8573b4: sbfiz           x0, x3, #1, #0x1f
    //     0x8573b8: cmp             x3, x0, asr #1
    //     0x8573bc: b.eq            #0x8573c8
    //     0x8573c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8573c4: stur            x3, [x0, #7]
    // 0x8573c8: r1 = LoadClassIdInstr(r2)
    //     0x8573c8: ldur            x1, [x2, #-1]
    //     0x8573cc: ubfx            x1, x1, #0xc, #0x14
    // 0x8573d0: stp             x0, x2, [SP]
    // 0x8573d4: mov             x0, x1
    // 0x8573d8: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8573d8: sub             lr, x0, #0xdfd
    //     0x8573dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8573e0: blr             lr
    // 0x8573e4: mov             x2, x0
    // 0x8573e8: ldur            x0, [fp, #-8]
    // 0x8573ec: stur            x2, [fp, #-0x40]
    // 0x8573f0: sub             x3, x0, #1
    // 0x8573f4: stur            x3, [fp, #-0x10]
    // 0x8573f8: r0 = BoxInt64Instr(r3)
    //     0x8573f8: sbfiz           x0, x3, #1, #0x1f
    //     0x8573fc: cmp             x3, x0, asr #1
    //     0x857400: b.eq            #0x85740c
    //     0x857404: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x857408: stur            x3, [x0, #7]
    // 0x85740c: ldur            x1, [fp, #-0x18]
    // 0x857410: r4 = LoadClassIdInstr(r1)
    //     0x857410: ldur            x4, [x1, #-1]
    //     0x857414: ubfx            x4, x4, #0xc, #0x14
    // 0x857418: stp             x0, x1, [SP]
    // 0x85741c: mov             x0, x4
    // 0x857420: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x857420: sub             lr, x0, #0xdfd
    //     0x857424: ldr             lr, [x21, lr, lsl #3]
    //     0x857428: blr             lr
    // 0x85742c: ldur            x1, [fp, #-0x40]
    // 0x857430: r2 = LoadClassIdInstr(r1)
    //     0x857430: ldur            x2, [x1, #-1]
    //     0x857434: ubfx            x2, x2, #0xc, #0x14
    // 0x857438: mov             x16, x0
    // 0x85743c: mov             x0, x2
    // 0x857440: mov             x2, x16
    // 0x857444: ldur            x3, [fp, #-0x28]
    // 0x857448: r0 = GDT[cid_x0 + 0x10462]()
    //     0x857448: mov             x17, #0x462
    //     0x85744c: movk            x17, #1, lsl #16
    //     0x857450: add             lr, x0, x17
    //     0x857454: ldr             lr, [x21, lr, lsl #3]
    //     0x857458: blr             lr
    // 0x85745c: ldur            x3, [fp, #-0x10]
    // 0x857460: b               #0x857398
    // 0x857464: ldur            x1, [fp, #-0x28]
    // 0x857468: b               #0x857470
    // 0x85746c: r1 = Null
    //     0x85746c: mov             x1, NULL
    // 0x857470: ldur            x0, [fp, #-0x20]
    // 0x857474: stur            x1, [fp, #-0x28]
    // 0x857478: cmp             w0, NULL
    // 0x85747c: b.ne            #0x8574c4
    // 0x857480: cmp             w1, NULL
    // 0x857484: b.ne            #0x8574b4
    // 0x857488: r0 = Matrix4()
    //     0x857488: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x85748c: r4 = 32
    //     0x85748c: mov             x4, #0x20
    // 0x857490: stur            x0, [fp, #-0x18]
    // 0x857494: r0 = AllocateFloat64Array()
    //     0x857494: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x857498: mov             x1, x0
    // 0x85749c: ldur            x0, [fp, #-0x18]
    // 0x8574a0: StoreField: r0->field_7 = r1
    //     0x8574a0: stur            w1, [x0, #7]
    // 0x8574a4: mov             x1, x0
    // 0x8574a8: r0 = setIdentity()
    //     0x8574a8: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x8574ac: ldur            x0, [fp, #-0x18]
    // 0x8574b0: b               #0x8574b8
    // 0x8574b4: mov             x0, x1
    // 0x8574b8: LeaveFrame
    //     0x8574b8: mov             SP, fp
    //     0x8574bc: ldp             fp, lr, [SP], #0x10
    // 0x8574c0: ret
    //     0x8574c0: ret             
    // 0x8574c4: r0 = Matrix4()
    //     0x8574c4: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x8574c8: r4 = 32
    //     0x8574c8: mov             x4, #0x20
    // 0x8574cc: stur            x0, [fp, #-0x18]
    // 0x8574d0: r0 = AllocateFloat64Array()
    //     0x8574d0: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x8574d4: mov             x1, x0
    // 0x8574d8: ldur            x0, [fp, #-0x18]
    // 0x8574dc: StoreField: r0->field_7 = r1
    //     0x8574dc: stur            w1, [x0, #7]
    // 0x8574e0: mov             x1, x0
    // 0x8574e4: r0 = setIdentity()
    //     0x8574e4: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x8574e8: ldur            x1, [fp, #-0x20]
    // 0x8574ec: r0 = LoadClassIdInstr(r1)
    //     0x8574ec: ldur            x0, [x1, #-1]
    //     0x8574f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8574f4: str             x1, [SP]
    // 0x8574f8: r0 = GDT[cid_x0 + 0xf078]()
    //     0x8574f8: mov             x17, #0xf078
    //     0x8574fc: add             lr, x0, x17
    //     0x857500: ldr             lr, [x21, lr, lsl #3]
    //     0x857504: blr             lr
    // 0x857508: r1 = LoadInt32Instr(r0)
    //     0x857508: sbfx            x1, x0, #1, #0x1f
    //     0x85750c: tbz             w0, #0, #0x857514
    //     0x857510: ldur            x1, [x0, #7]
    // 0x857514: sub             x0, x1, #1
    // 0x857518: mov             x3, x0
    // 0x85751c: ldur            x2, [fp, #-0x20]
    // 0x857520: stur            x3, [fp, #-8]
    // 0x857524: CheckStackOverflow
    //     0x857524: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x857528: cmp             SP, x16
    //     0x85752c: b.ls            #0x857730
    // 0x857530: cmp             x3, #0
    // 0x857534: b.le            #0x8575e8
    // 0x857538: r0 = BoxInt64Instr(r3)
    //     0x857538: sbfiz           x0, x3, #1, #0x1f
    //     0x85753c: cmp             x3, x0, asr #1
    //     0x857540: b.eq            #0x85754c
    //     0x857544: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x857548: stur            x3, [x0, #7]
    // 0x85754c: r1 = LoadClassIdInstr(r2)
    //     0x85754c: ldur            x1, [x2, #-1]
    //     0x857550: ubfx            x1, x1, #0xc, #0x14
    // 0x857554: stp             x0, x2, [SP]
    // 0x857558: mov             x0, x1
    // 0x85755c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x85755c: sub             lr, x0, #0xdfd
    //     0x857560: ldr             lr, [x21, lr, lsl #3]
    //     0x857564: blr             lr
    // 0x857568: mov             x2, x0
    // 0x85756c: ldur            x0, [fp, #-8]
    // 0x857570: stur            x2, [fp, #-0x40]
    // 0x857574: sub             x3, x0, #1
    // 0x857578: stur            x3, [fp, #-0x10]
    // 0x85757c: r0 = BoxInt64Instr(r3)
    //     0x85757c: sbfiz           x0, x3, #1, #0x1f
    //     0x857580: cmp             x3, x0, asr #1
    //     0x857584: b.eq            #0x857590
    //     0x857588: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x85758c: stur            x3, [x0, #7]
    // 0x857590: ldur            x1, [fp, #-0x20]
    // 0x857594: r4 = LoadClassIdInstr(r1)
    //     0x857594: ldur            x4, [x1, #-1]
    //     0x857598: ubfx            x4, x4, #0xc, #0x14
    // 0x85759c: stp             x0, x1, [SP]
    // 0x8575a0: mov             x0, x4
    // 0x8575a4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x8575a4: sub             lr, x0, #0xdfd
    //     0x8575a8: ldr             lr, [x21, lr, lsl #3]
    //     0x8575ac: blr             lr
    // 0x8575b0: ldur            x1, [fp, #-0x40]
    // 0x8575b4: r2 = LoadClassIdInstr(r1)
    //     0x8575b4: ldur            x2, [x1, #-1]
    //     0x8575b8: ubfx            x2, x2, #0xc, #0x14
    // 0x8575bc: mov             x16, x0
    // 0x8575c0: mov             x0, x2
    // 0x8575c4: mov             x2, x16
    // 0x8575c8: ldur            x3, [fp, #-0x18]
    // 0x8575cc: r0 = GDT[cid_x0 + 0x10462]()
    //     0x8575cc: mov             x17, #0x462
    //     0x8575d0: movk            x17, #1, lsl #16
    //     0x8575d4: add             lr, x0, x17
    //     0x8575d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8575dc: blr             lr
    // 0x8575e0: ldur            x3, [fp, #-0x10]
    // 0x8575e4: b               #0x85751c
    // 0x8575e8: ldur            x1, [fp, #-0x18]
    // 0x8575ec: r0 = invert()
    //     0x8575ec: bl              #0x857b2c  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0x8575f0: mov             v1.16b, v0.16b
    // 0x8575f4: d0 = 0.000000
    //     0x8575f4: eor             v0.16b, v0.16b, v0.16b
    // 0x8575f8: fcmp            d1, d0
    // 0x8575fc: b.ne            #0x857628
    // 0x857600: r0 = Matrix4()
    //     0x857600: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x857604: r4 = 32
    //     0x857604: mov             x4, #0x20
    // 0x857608: stur            x0, [fp, #-0x20]
    // 0x85760c: r0 = AllocateFloat64Array()
    //     0x85760c: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x857610: mov             x1, x0
    // 0x857614: ldur            x0, [fp, #-0x20]
    // 0x857618: StoreField: r0->field_7 = r1
    //     0x857618: stur            w1, [x0, #7]
    // 0x85761c: LeaveFrame
    //     0x85761c: mov             SP, fp
    //     0x857620: ldp             fp, lr, [SP], #0x10
    // 0x857624: ret
    //     0x857624: ret             
    // 0x857628: ldur            x0, [fp, #-0x28]
    // 0x85762c: cmp             w0, NULL
    // 0x857630: b.ne            #0x85763c
    // 0x857634: r0 = Null
    //     0x857634: mov             x0, NULL
    // 0x857638: b               #0x85764c
    // 0x85763c: mov             x1, x0
    // 0x857640: ldur            x2, [fp, #-0x18]
    // 0x857644: r0 = multiply()
    //     0x857644: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x857648: ldur            x0, [fp, #-0x28]
    // 0x85764c: cmp             w0, NULL
    // 0x857650: b.ne            #0x857658
    // 0x857654: ldur            x0, [fp, #-0x18]
    // 0x857658: LeaveFrame
    //     0x857658: mov             SP, fp
    //     0x85765c: ldp             fp, lr, [SP], #0x10
    // 0x857660: ret
    //     0x857660: ret             
    // 0x857664: ldur            x3, [fp, #-0x30]
    // 0x857668: ldur            x0, [fp, #-0x38]
    // 0x85766c: r1 = Null
    //     0x85766c: mov             x1, NULL
    // 0x857670: r2 = 8
    //     0x857670: mov             x2, #8
    // 0x857674: r0 = AllocateArray()
    //     0x857674: bl              #0x13df928  ; AllocateArrayStub
    // 0x857678: mov             x1, x0
    // 0x85767c: ldur            x0, [fp, #-0x38]
    // 0x857680: StoreField: r1->field_f = r0
    //     0x857680: stur            w0, [x1, #0xf]
    // 0x857684: r16 = " and "
    //     0x857684: ldr             x16, [PP, #0x47f8]  ; [pp+0x47f8] " and "
    // 0x857688: StoreField: r1->field_13 = r16
    //     0x857688: stur            w16, [x1, #0x13]
    // 0x85768c: ldur            x3, [fp, #-0x30]
    // 0x857690: ArrayStore: r1[0] = r3  ; List_4
    //     0x857690: stur            w3, [x1, #0x17]
    // 0x857694: r16 = " are not in the same render tree."
    //     0x857694: ldr             x16, [PP, #0x4800]  ; [pp+0x4800] " are not in the same render tree."
    // 0x857698: StoreField: r1->field_1b = r16
    //     0x857698: stur            w16, [x1, #0x1b]
    // 0x85769c: str             x1, [SP]
    // 0x8576a0: r0 = _interpolate()
    //     0x8576a0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8576a4: mov             x2, x0
    // 0x8576a8: r1 = Null
    //     0x8576a8: mov             x1, NULL
    // 0x8576ac: r0 = FlutterError()
    //     0x8576ac: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0x8576b0: r0 = Throw()
    //     0x8576b0: bl              #0x13ddb2c  ; ThrowStub
    // 0x8576b4: brk             #0
    // 0x8576b8: ldur            x3, [fp, #-0x30]
    // 0x8576bc: ldur            x0, [fp, #-0x38]
    // 0x8576c0: r1 = Null
    //     0x8576c0: mov             x1, NULL
    // 0x8576c4: r2 = 8
    //     0x8576c4: mov             x2, #8
    // 0x8576c8: r0 = AllocateArray()
    //     0x8576c8: bl              #0x13df928  ; AllocateArrayStub
    // 0x8576cc: mov             x1, x0
    // 0x8576d0: ldur            x0, [fp, #-0x38]
    // 0x8576d4: StoreField: r1->field_f = r0
    //     0x8576d4: stur            w0, [x1, #0xf]
    // 0x8576d8: r16 = " and "
    //     0x8576d8: ldr             x16, [PP, #0x47f8]  ; [pp+0x47f8] " and "
    // 0x8576dc: StoreField: r1->field_13 = r16
    //     0x8576dc: stur            w16, [x1, #0x13]
    // 0x8576e0: ldur            x0, [fp, #-0x30]
    // 0x8576e4: ArrayStore: r1[0] = r0  ; List_4
    //     0x8576e4: stur            w0, [x1, #0x17]
    // 0x8576e8: r16 = " are not in the same render tree."
    //     0x8576e8: ldr             x16, [PP, #0x4800]  ; [pp+0x4800] " are not in the same render tree."
    // 0x8576ec: StoreField: r1->field_1b = r16
    //     0x8576ec: stur            w16, [x1, #0x1b]
    // 0x8576f0: str             x1, [SP]
    // 0x8576f4: r0 = _interpolate()
    //     0x8576f4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x8576f8: mov             x2, x0
    // 0x8576fc: r1 = Null
    //     0x8576fc: mov             x1, NULL
    // 0x857700: r0 = FlutterError()
    //     0x857700: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0x857704: r0 = Throw()
    //     0x857704: bl              #0x13ddb2c  ; ThrowStub
    // 0x857708: brk             #0
    // 0x85770c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85770c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857710: b               #0x857094
    // 0x857714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857714: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x857718: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857718: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85771c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85771c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857720: b               #0x8570f0
    // 0x857724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857724: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x857728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85772c: b               #0x8573ac
    // 0x857730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857734: b               #0x857530
  }
  get _ constraints(/* No info */) {
    // ** addr: 0x860ce4, size: 0x40
    // 0x860ce4: EnterFrame
    //     0x860ce4: stp             fp, lr, [SP, #-0x10]!
    //     0x860ce8: mov             fp, SP
    // 0x860cec: LoadField: r0 = r1->field_27
    //     0x860cec: ldur            w0, [x1, #0x27]
    // 0x860cf0: DecompressPointer r0
    //     0x860cf0: add             x0, x0, HEAP, lsl #32
    // 0x860cf4: cmp             w0, NULL
    // 0x860cf8: b.eq            #0x860d08
    // 0x860cfc: LeaveFrame
    //     0x860cfc: mov             SP, fp
    //     0x860d00: ldp             fp, lr, [SP], #0x10
    // 0x860d04: ret
    //     0x860d04: ret             
    // 0x860d08: r0 = StateError()
    //     0x860d08: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x860d0c: mov             x1, x0
    // 0x860d10: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x860d10: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x860d14: StoreField: r1->field_b = r0
    //     0x860d14: stur            w0, [x1, #0xb]
    // 0x860d18: mov             x0, x1
    // 0x860d1c: r0 = Throw()
    //     0x860d1c: bl              #0x13ddb2c  ; ThrowStub
    // 0x860d20: brk             #0
  }
  get _ layer(/* No info */) {
    // ** addr: 0x899c4c, size: 0x14
    // 0x899c4c: LoadField: r2 = r1->field_2f
    //     0x899c4c: ldur            w2, [x1, #0x2f]
    // 0x899c50: DecompressPointer r2
    //     0x899c50: add             x2, x2, HEAP, lsl #32
    // 0x899c54: LoadField: r0 = r2->field_b
    //     0x899c54: ldur            w0, [x2, #0xb]
    // 0x899c58: DecompressPointer r0
    //     0x899c58: add             x0, x0, HEAP, lsl #32
    // 0x899c5c: ret
    //     0x899c5c: ret             
  }
  _ _skippedPaintingOnLayer(/* No info */) {
    // ** addr: 0x89a27c, size: 0xf4
    // 0x89a27c: EnterFrame
    //     0x89a27c: stp             fp, lr, [SP, #-0x10]!
    //     0x89a280: mov             fp, SP
    // 0x89a284: AllocStack(0x8)
    //     0x89a284: sub             SP, SP, #8
    // 0x89a288: CheckStackOverflow
    //     0x89a288: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a28c: cmp             SP, x16
    //     0x89a290: b.ls            #0x89a360
    // 0x89a294: r0 = LoadClassIdInstr(r1)
    //     0x89a294: ldur            x0, [x1, #-1]
    //     0x89a298: ubfx            x0, x0, #0xc, #0x14
    // 0x89a29c: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x89a29c: mov             x17, #0xfc0
    //     0x89a2a0: movk            x17, #1, lsl #16
    //     0x89a2a4: add             lr, x0, x17
    //     0x89a2a8: ldr             lr, [x21, lr, lsl #3]
    //     0x89a2ac: blr             lr
    // 0x89a2b0: mov             x2, x0
    // 0x89a2b4: stur            x2, [fp, #-8]
    // 0x89a2b8: CheckStackOverflow
    //     0x89a2b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a2bc: cmp             SP, x16
    //     0x89a2c0: b.ls            #0x89a368
    // 0x89a2c4: cmp             w2, NULL
    // 0x89a2c8: b.eq            #0x89a350
    // 0x89a2cc: r0 = LoadClassIdInstr(r2)
    //     0x89a2cc: ldur            x0, [x2, #-1]
    //     0x89a2d0: ubfx            x0, x0, #0xc, #0x14
    // 0x89a2d4: mov             x1, x2
    // 0x89a2d8: r0 = GDT[cid_x0 + 0xfd90]()
    //     0x89a2d8: mov             x17, #0xfd90
    //     0x89a2dc: add             lr, x0, x17
    //     0x89a2e0: ldr             lr, [x21, lr, lsl #3]
    //     0x89a2e4: blr             lr
    // 0x89a2e8: tbnz            w0, #4, #0x89a324
    // 0x89a2ec: ldur            x1, [fp, #-8]
    // 0x89a2f0: LoadField: r0 = r1->field_2f
    //     0x89a2f0: ldur            w0, [x1, #0x2f]
    // 0x89a2f4: DecompressPointer r0
    //     0x89a2f4: add             x0, x0, HEAP, lsl #32
    // 0x89a2f8: LoadField: r2 = r0->field_b
    //     0x89a2f8: ldur            w2, [x0, #0xb]
    // 0x89a2fc: DecompressPointer r2
    //     0x89a2fc: add             x2, x2, HEAP, lsl #32
    // 0x89a300: cmp             w2, NULL
    // 0x89a304: b.eq            #0x89a350
    // 0x89a308: LoadField: r0 = r2->field_2b
    //     0x89a308: ldur            w0, [x2, #0x2b]
    // 0x89a30c: DecompressPointer r0
    //     0x89a30c: add             x0, x0, HEAP, lsl #32
    // 0x89a310: cmp             w0, NULL
    // 0x89a314: b.ne            #0x89a350
    // 0x89a318: r2 = true
    //     0x89a318: add             x2, NULL, #0x20  ; true
    // 0x89a31c: StoreField: r1->field_3b = r2
    //     0x89a31c: stur            w2, [x1, #0x3b]
    // 0x89a320: b               #0x89a32c
    // 0x89a324: ldur            x1, [fp, #-8]
    // 0x89a328: r2 = true
    //     0x89a328: add             x2, NULL, #0x20  ; true
    // 0x89a32c: r0 = LoadClassIdInstr(r1)
    //     0x89a32c: ldur            x0, [x1, #-1]
    //     0x89a330: ubfx            x0, x0, #0xc, #0x14
    // 0x89a334: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x89a334: mov             x17, #0xfc0
    //     0x89a338: movk            x17, #1, lsl #16
    //     0x89a33c: add             lr, x0, x17
    //     0x89a340: ldr             lr, [x21, lr, lsl #3]
    //     0x89a344: blr             lr
    // 0x89a348: mov             x2, x0
    // 0x89a34c: b               #0x89a2b4
    // 0x89a350: r0 = Null
    //     0x89a350: mov             x0, NULL
    // 0x89a354: LeaveFrame
    //     0x89a354: mov             SP, fp
    //     0x89a358: ldp             fp, lr, [SP], #0x10
    // 0x89a35c: ret
    //     0x89a35c: ret             
    // 0x89a360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a360: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a364: b               #0x89a294
    // 0x89a368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a368: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a36c: b               #0x89a2c4
  }
  _ _paintWithContext(/* No info */) {
    // ** addr: 0x89a9d4, size: 0xcc
    // 0x89a9d4: EnterFrame
    //     0x89a9d4: stp             fp, lr, [SP, #-0x10]!
    //     0x89a9d8: mov             fp, SP
    // 0x89a9dc: AllocStack(0x68)
    //     0x89a9dc: sub             SP, SP, #0x68
    // 0x89a9e0: SetupParameters(RenderObject this /* r1 => r4, fp-0x58 */, dynamic _ /* r2 => r2, fp-0x60 */, dynamic _ /* r3 => r3, fp-0x68 */)
    //     0x89a9e0: mov             x4, x1
    //     0x89a9e4: stur            x1, [fp, #-0x58]
    //     0x89a9e8: stur            x2, [fp, #-0x60]
    //     0x89a9ec: stur            x3, [fp, #-0x68]
    // 0x89a9f0: CheckStackOverflow
    //     0x89a9f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a9f4: cmp             SP, x16
    //     0x89a9f8: b.ls            #0x89aa98
    // 0x89a9fc: LoadField: r0 = r4->field_1b
    //     0x89a9fc: ldur            w0, [x4, #0x1b]
    // 0x89aa00: DecompressPointer r0
    //     0x89aa00: add             x0, x0, HEAP, lsl #32
    // 0x89aa04: tbnz            w0, #4, #0x89aa18
    // 0x89aa08: r0 = Null
    //     0x89aa08: mov             x0, NULL
    // 0x89aa0c: LeaveFrame
    //     0x89aa0c: mov             SP, fp
    //     0x89aa10: ldp             fp, lr, [SP], #0x10
    // 0x89aa14: ret
    //     0x89aa14: ret             
    // 0x89aa18: r0 = false
    //     0x89aa18: add             x0, NULL, #0x30  ; false
    // 0x89aa1c: StoreField: r4->field_3b = r0
    //     0x89aa1c: stur            w0, [x4, #0x3b]
    // 0x89aa20: StoreField: r4->field_3f = r0
    //     0x89aa20: stur            w0, [x4, #0x3f]
    // 0x89aa24: r0 = LoadClassIdInstr(r4)
    //     0x89aa24: ldur            x0, [x4, #-1]
    //     0x89aa28: ubfx            x0, x0, #0xc, #0x14
    // 0x89aa2c: mov             x1, x4
    // 0x89aa30: r0 = GDT[cid_x0 + 0xfd90]()
    //     0x89aa30: mov             x17, #0xfd90
    //     0x89aa34: add             lr, x0, x17
    //     0x89aa38: ldr             lr, [x21, lr, lsl #3]
    //     0x89aa3c: blr             lr
    // 0x89aa40: ldur            x4, [fp, #-0x58]
    // 0x89aa44: StoreField: r4->field_2b = r0
    //     0x89aa44: stur            w0, [x4, #0x2b]
    // 0x89aa48: r0 = LoadClassIdInstr(r4)
    //     0x89aa48: ldur            x0, [x4, #-1]
    //     0x89aa4c: ubfx            x0, x0, #0xc, #0x14
    // 0x89aa50: mov             x1, x4
    // 0x89aa54: ldur            x2, [fp, #-0x60]
    // 0x89aa58: ldur            x3, [fp, #-0x68]
    // 0x89aa5c: r0 = GDT[cid_x0 + 0xecf9]()
    //     0x89aa5c: mov             x17, #0xecf9
    //     0x89aa60: add             lr, x0, x17
    //     0x89aa64: ldr             lr, [x21, lr, lsl #3]
    //     0x89aa68: blr             lr
    // 0x89aa6c: b               #0x89aa88
    // 0x89aa70: sub             SP, fp, #0x68
    // 0x89aa74: mov             x5, x1
    // 0x89aa78: ldur            x1, [fp, #-0x58]
    // 0x89aa7c: mov             x3, x0
    // 0x89aa80: r2 = "paint"
    //     0x89aa80: ldr             x2, [PP, #0x2d60]  ; [pp+0x2d60] "paint"
    // 0x89aa84: r0 = _reportException()
    //     0x89aa84: bl              #0x89aaa0  ; [package:flutter/src/rendering/object.dart] RenderObject::_reportException
    // 0x89aa88: r0 = Null
    //     0x89aa88: mov             x0, NULL
    // 0x89aa8c: LeaveFrame
    //     0x89aa8c: mov             SP, fp
    //     0x89aa90: ldp             fp, lr, [SP], #0x10
    // 0x89aa94: ret
    //     0x89aa94: ret             
    // 0x89aa98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89aa98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89aa9c: b               #0x89a9fc
  }
  _ _reportException(/* No info */) {
    // ** addr: 0x89aaa0, size: 0xf0
    // 0x89aaa0: EnterFrame
    //     0x89aaa0: stp             fp, lr, [SP, #-0x10]!
    //     0x89aaa4: mov             fp, SP
    // 0x89aaa8: AllocStack(0x30)
    //     0x89aaa8: sub             SP, SP, #0x30
    // 0x89aaac: SetupParameters(RenderObject this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0x89aaac: stur            x1, [fp, #-8]
    //     0x89aab0: stur            x2, [fp, #-0x10]
    //     0x89aab4: stur            x3, [fp, #-0x18]
    //     0x89aab8: stur            x5, [fp, #-0x20]
    // 0x89aabc: CheckStackOverflow
    //     0x89aabc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89aac0: cmp             SP, x16
    //     0x89aac4: b.ls            #0x89ab88
    // 0x89aac8: r1 = 1
    //     0x89aac8: mov             x1, #1
    // 0x89aacc: r0 = AllocateContext()
    //     0x89aacc: bl              #0x13de838  ; AllocateContextStub
    // 0x89aad0: mov             x3, x0
    // 0x89aad4: ldur            x0, [fp, #-8]
    // 0x89aad8: stur            x3, [fp, #-0x28]
    // 0x89aadc: StoreField: r3->field_f = r0
    //     0x89aadc: stur            w0, [x3, #0xf]
    // 0x89aae0: r1 = Null
    //     0x89aae0: mov             x1, NULL
    // 0x89aae4: r2 = 6
    //     0x89aae4: mov             x2, #6
    // 0x89aae8: r0 = AllocateArray()
    //     0x89aae8: bl              #0x13df928  ; AllocateArrayStub
    // 0x89aaec: r16 = "during "
    //     0x89aaec: ldr             x16, [PP, #0x2d68]  ; [pp+0x2d68] "during "
    // 0x89aaf0: StoreField: r0->field_f = r16
    //     0x89aaf0: stur            w16, [x0, #0xf]
    // 0x89aaf4: ldur            x1, [fp, #-0x10]
    // 0x89aaf8: StoreField: r0->field_13 = r1
    //     0x89aaf8: stur            w1, [x0, #0x13]
    // 0x89aafc: r16 = "()"
    //     0x89aafc: ldr             x16, [PP, #0x2d70]  ; [pp+0x2d70] "()"
    // 0x89ab00: ArrayStore: r0[0] = r16  ; List_4
    //     0x89ab00: stur            w16, [x0, #0x17]
    // 0x89ab04: str             x0, [SP]
    // 0x89ab08: r0 = _interpolate()
    //     0x89ab08: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x89ab0c: r1 = <List<Object>>
    //     0x89ab0c: ldr             x1, [PP, #0x860]  ; [pp+0x860] TypeArguments: <List<Object>>
    // 0x89ab10: stur            x0, [fp, #-8]
    // 0x89ab14: r0 = ErrorDescription()
    //     0x89ab14: bl              #0x829ca4  ; AllocateErrorDescriptionStub -> ErrorDescription (size=0x2c)
    // 0x89ab18: mov             x1, x0
    // 0x89ab1c: ldur            x2, [fp, #-8]
    // 0x89ab20: r3 = Instance_DiagnosticLevel
    //     0x89ab20: ldr             x3, [PP, #0x868]  ; [pp+0x868] Obj!DiagnosticLevel@12c5f41
    // 0x89ab24: stur            x0, [fp, #-8]
    // 0x89ab28: r0 = _ErrorDiagnostic()
    //     0x89ab28: bl              #0x829bec  ; [package:flutter/src/foundation/assertions.dart] _ErrorDiagnostic::_ErrorDiagnostic
    // 0x89ab2c: r0 = FlutterErrorDetails()
    //     0x89ab2c: bl              #0x829be0  ; AllocateFlutterErrorDetailsStub -> FlutterErrorDetails (size=0x20)
    // 0x89ab30: mov             x3, x0
    // 0x89ab34: ldur            x0, [fp, #-0x18]
    // 0x89ab38: stur            x3, [fp, #-0x10]
    // 0x89ab3c: StoreField: r3->field_7 = r0
    //     0x89ab3c: stur            w0, [x3, #7]
    // 0x89ab40: ldur            x0, [fp, #-0x20]
    // 0x89ab44: StoreField: r3->field_b = r0
    //     0x89ab44: stur            w0, [x3, #0xb]
    // 0x89ab48: r0 = "rendering library"
    //     0x89ab48: ldr             x0, [PP, #0x2d78]  ; [pp+0x2d78] "rendering library"
    // 0x89ab4c: StoreField: r3->field_f = r0
    //     0x89ab4c: stur            w0, [x3, #0xf]
    // 0x89ab50: ldur            x0, [fp, #-8]
    // 0x89ab54: StoreField: r3->field_13 = r0
    //     0x89ab54: stur            w0, [x3, #0x13]
    // 0x89ab58: ldur            x2, [fp, #-0x28]
    // 0x89ab5c: r1 = Function '<anonymous closure>':.
    //     0x89ab5c: ldr             x1, [PP, #0x2d80]  ; [pp+0x2d80] AnonymousClosure: (0x89ab90), in [package:flutter/src/rendering/object.dart] RenderObject::_reportException (0x89aaa0)
    // 0x89ab60: r0 = AllocateClosure()
    //     0x89ab60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x89ab64: ldur            x1, [fp, #-0x10]
    // 0x89ab68: ArrayStore: r1[0] = r0  ; List_4
    //     0x89ab68: stur            w0, [x1, #0x17]
    // 0x89ab6c: r0 = false
    //     0x89ab6c: add             x0, NULL, #0x30  ; false
    // 0x89ab70: StoreField: r1->field_1b = r0
    //     0x89ab70: stur            w0, [x1, #0x1b]
    // 0x89ab74: r0 = reportError()
    //     0x89ab74: bl              #0x829a24  ; [package:flutter/src/foundation/assertions.dart] FlutterError::reportError
    // 0x89ab78: r0 = Null
    //     0x89ab78: mov             x0, NULL
    // 0x89ab7c: LeaveFrame
    //     0x89ab7c: mov             SP, fp
    //     0x89ab80: ldp             fp, lr, [SP], #0x10
    // 0x89ab84: ret
    //     0x89ab84: ret             
    // 0x89ab88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89ab88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89ab8c: b               #0x89aac8
  }
  [closure] List<DiagnosticsNode> <anonymous closure>(dynamic) {
    // ** addr: 0x89ab90, size: 0x174
    // 0x89ab90: EnterFrame
    //     0x89ab90: stp             fp, lr, [SP, #-0x10]!
    //     0x89ab94: mov             fp, SP
    // 0x89ab98: AllocStack(0x20)
    //     0x89ab98: sub             SP, SP, #0x20
    // 0x89ab9c: SetupParameters([dynamic _ /* r0 */])
    //     0x89ab9c: ldr             x0, [fp, #0x10]
    //     0x89aba0: ldur            w3, [x0, #0x17]
    //     0x89aba4: add             x3, x3, HEAP, lsl #32
    //     0x89aba8: stur            x3, [fp, #-8]
    // 0x89abac: CheckStackOverflow
    //     0x89abac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89abb0: cmp             SP, x16
    //     0x89abb4: b.ls            #0x89acfc
    // 0x89abb8: r1 = <DiagnosticsNode>
    //     0x89abb8: ldr             x1, [PP, #0x1ea8]  ; [pp+0x1ea8] TypeArguments: <DiagnosticsNode>
    // 0x89abbc: r2 = 0
    //     0x89abbc: mov             x2, #0
    // 0x89abc0: r0 = _GrowableList()
    //     0x89abc0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x89abc4: mov             x2, x0
    // 0x89abc8: ldur            x0, [fp, #-8]
    // 0x89abcc: stur            x2, [fp, #-0x10]
    // 0x89abd0: LoadField: r1 = r0->field_f
    //     0x89abd0: ldur            w1, [x0, #0xf]
    // 0x89abd4: DecompressPointer r1
    //     0x89abd4: add             x1, x1, HEAP, lsl #32
    // 0x89abd8: r0 = toDiagnosticsNode()
    //     0x89abd8: bl              #0x89ad04  ; [dart:mixin_deduplication] _MixinApplication5&Object&DiagnosticableTreeMixin::toDiagnosticsNode
    // 0x89abdc: mov             x2, x0
    // 0x89abe0: ldur            x0, [fp, #-0x10]
    // 0x89abe4: stur            x2, [fp, #-0x20]
    // 0x89abe8: LoadField: r1 = r0->field_b
    //     0x89abe8: ldur            w1, [x0, #0xb]
    // 0x89abec: LoadField: r3 = r0->field_f
    //     0x89abec: ldur            w3, [x0, #0xf]
    // 0x89abf0: DecompressPointer r3
    //     0x89abf0: add             x3, x3, HEAP, lsl #32
    // 0x89abf4: LoadField: r4 = r3->field_b
    //     0x89abf4: ldur            w4, [x3, #0xb]
    // 0x89abf8: r3 = LoadInt32Instr(r1)
    //     0x89abf8: sbfx            x3, x1, #1, #0x1f
    // 0x89abfc: stur            x3, [fp, #-0x18]
    // 0x89ac00: r1 = LoadInt32Instr(r4)
    //     0x89ac00: sbfx            x1, x4, #1, #0x1f
    // 0x89ac04: cmp             x3, x1
    // 0x89ac08: b.ne            #0x89ac14
    // 0x89ac0c: mov             x1, x0
    // 0x89ac10: r0 = _growToNextCapacity()
    //     0x89ac10: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89ac14: ldur            x4, [fp, #-8]
    // 0x89ac18: ldur            x2, [fp, #-0x10]
    // 0x89ac1c: ldur            x3, [fp, #-0x18]
    // 0x89ac20: add             x0, x3, #1
    // 0x89ac24: lsl             x1, x0, #1
    // 0x89ac28: StoreField: r2->field_b = r1
    //     0x89ac28: stur            w1, [x2, #0xb]
    // 0x89ac2c: LoadField: r1 = r2->field_f
    //     0x89ac2c: ldur            w1, [x2, #0xf]
    // 0x89ac30: DecompressPointer r1
    //     0x89ac30: add             x1, x1, HEAP, lsl #32
    // 0x89ac34: ldur            x0, [fp, #-0x20]
    // 0x89ac38: ArrayStore: r1[r3] = r0  ; List_4
    //     0x89ac38: add             x25, x1, x3, lsl #2
    //     0x89ac3c: add             x25, x25, #0xf
    //     0x89ac40: str             w0, [x25]
    //     0x89ac44: tbz             w0, #0, #0x89ac60
    //     0x89ac48: ldurb           w16, [x1, #-1]
    //     0x89ac4c: ldurb           w17, [x0, #-1]
    //     0x89ac50: and             x16, x17, x16, lsr #2
    //     0x89ac54: tst             x16, HEAP, lsr #32
    //     0x89ac58: b.eq            #0x89ac60
    //     0x89ac5c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x89ac60: LoadField: r1 = r4->field_f
    //     0x89ac60: ldur            w1, [x4, #0xf]
    // 0x89ac64: DecompressPointer r1
    //     0x89ac64: add             x1, x1, HEAP, lsl #32
    // 0x89ac68: r0 = toDiagnosticsNode()
    //     0x89ac68: bl              #0x89ad04  ; [dart:mixin_deduplication] _MixinApplication5&Object&DiagnosticableTreeMixin::toDiagnosticsNode
    // 0x89ac6c: mov             x2, x0
    // 0x89ac70: ldur            x0, [fp, #-0x10]
    // 0x89ac74: stur            x2, [fp, #-8]
    // 0x89ac78: LoadField: r1 = r0->field_b
    //     0x89ac78: ldur            w1, [x0, #0xb]
    // 0x89ac7c: LoadField: r3 = r0->field_f
    //     0x89ac7c: ldur            w3, [x0, #0xf]
    // 0x89ac80: DecompressPointer r3
    //     0x89ac80: add             x3, x3, HEAP, lsl #32
    // 0x89ac84: LoadField: r4 = r3->field_b
    //     0x89ac84: ldur            w4, [x3, #0xb]
    // 0x89ac88: r3 = LoadInt32Instr(r1)
    //     0x89ac88: sbfx            x3, x1, #1, #0x1f
    // 0x89ac8c: stur            x3, [fp, #-0x18]
    // 0x89ac90: r1 = LoadInt32Instr(r4)
    //     0x89ac90: sbfx            x1, x4, #1, #0x1f
    // 0x89ac94: cmp             x3, x1
    // 0x89ac98: b.ne            #0x89aca4
    // 0x89ac9c: mov             x1, x0
    // 0x89aca0: r0 = _growToNextCapacity()
    //     0x89aca0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x89aca4: ldur            x2, [fp, #-0x10]
    // 0x89aca8: ldur            x3, [fp, #-0x18]
    // 0x89acac: add             x4, x3, #1
    // 0x89acb0: lsl             x5, x4, #1
    // 0x89acb4: StoreField: r2->field_b = r5
    //     0x89acb4: stur            w5, [x2, #0xb]
    // 0x89acb8: LoadField: r1 = r2->field_f
    //     0x89acb8: ldur            w1, [x2, #0xf]
    // 0x89acbc: DecompressPointer r1
    //     0x89acbc: add             x1, x1, HEAP, lsl #32
    // 0x89acc0: ldur            x0, [fp, #-8]
    // 0x89acc4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x89acc4: add             x25, x1, x3, lsl #2
    //     0x89acc8: add             x25, x25, #0xf
    //     0x89accc: str             w0, [x25]
    //     0x89acd0: tbz             w0, #0, #0x89acec
    //     0x89acd4: ldurb           w16, [x1, #-1]
    //     0x89acd8: ldurb           w17, [x0, #-1]
    //     0x89acdc: and             x16, x17, x16, lsr #2
    //     0x89ace0: tst             x16, HEAP, lsr #32
    //     0x89ace4: b.eq            #0x89acec
    //     0x89ace8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x89acec: mov             x0, x2
    // 0x89acf0: LeaveFrame
    //     0x89acf0: mov             SP, fp
    //     0x89acf4: ldp             fp, lr, [SP], #0x10
    // 0x89acf8: ret
    //     0x89acf8: ret             
    // 0x89acfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89acfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89ad00: b               #0x89abb8
  }
  _ _updateCompositingBits(/* No info */) {
    // ** addr: 0x89b25c, size: 0x230
    // 0x89b25c: EnterFrame
    //     0x89b25c: stp             fp, lr, [SP, #-0x10]!
    //     0x89b260: mov             fp, SP
    // 0x89b264: AllocStack(0x20)
    //     0x89b264: sub             SP, SP, #0x20
    // 0x89b268: SetupParameters(RenderObject this /* r1 => r1, fp-0x8 */)
    //     0x89b268: stur            x1, [fp, #-8]
    // 0x89b26c: CheckStackOverflow
    //     0x89b26c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b270: cmp             SP, x16
    //     0x89b274: b.ls            #0x89b474
    // 0x89b278: r1 = 1
    //     0x89b278: mov             x1, #1
    // 0x89b27c: r0 = AllocateContext()
    //     0x89b27c: bl              #0x13de838  ; AllocateContextStub
    // 0x89b280: mov             x3, x0
    // 0x89b284: ldur            x0, [fp, #-8]
    // 0x89b288: stur            x3, [fp, #-0x18]
    // 0x89b28c: StoreField: r3->field_f = r0
    //     0x89b28c: stur            w0, [x3, #0xf]
    // 0x89b290: LoadField: r1 = r0->field_33
    //     0x89b290: ldur            w1, [x0, #0x33]
    // 0x89b294: DecompressPointer r1
    //     0x89b294: add             x1, x1, HEAP, lsl #32
    // 0x89b298: tbz             w1, #4, #0x89b2ac
    // 0x89b29c: r0 = Null
    //     0x89b29c: mov             x0, NULL
    // 0x89b2a0: LeaveFrame
    //     0x89b2a0: mov             SP, fp
    //     0x89b2a4: ldp             fp, lr, [SP], #0x10
    // 0x89b2a8: ret
    //     0x89b2a8: ret             
    // 0x89b2ac: r4 = false
    //     0x89b2ac: add             x4, NULL, #0x30  ; false
    // 0x89b2b0: LoadField: r5 = r0->field_37
    //     0x89b2b0: ldur            w5, [x0, #0x37]
    // 0x89b2b4: DecompressPointer r5
    //     0x89b2b4: add             x5, x5, HEAP, lsl #32
    // 0x89b2b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x89b2bc: cmp             w5, w16
    // 0x89b2c0: b.eq            #0x89b47c
    // 0x89b2c4: stur            x5, [fp, #-0x10]
    // 0x89b2c8: StoreField: r0->field_37 = r4
    //     0x89b2c8: stur            w4, [x0, #0x37]
    // 0x89b2cc: mov             x2, x3
    // 0x89b2d0: r1 = Function '<anonymous closure>':.
    //     0x89b2d0: ldr             x1, [PP, #0x2dc0]  ; [pp+0x2dc0] AnonymousClosure: (0x89b48c), in [package:flutter/src/rendering/object.dart] RenderObject::_updateCompositingBits (0x89b25c)
    // 0x89b2d4: r0 = AllocateClosure()
    //     0x89b2d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x89b2d8: ldur            x3, [fp, #-8]
    // 0x89b2dc: r1 = LoadClassIdInstr(r3)
    //     0x89b2dc: ldur            x1, [x3, #-1]
    //     0x89b2e0: ubfx            x1, x1, #0xc, #0x14
    // 0x89b2e4: mov             x2, x0
    // 0x89b2e8: mov             x0, x1
    // 0x89b2ec: mov             x1, x3
    // 0x89b2f0: r0 = GDT[cid_x0 + 0x10a11]()
    //     0x89b2f0: mov             x17, #0xa11
    //     0x89b2f4: movk            x17, #1, lsl #16
    //     0x89b2f8: add             lr, x0, x17
    //     0x89b2fc: ldr             lr, [x21, lr, lsl #3]
    //     0x89b300: blr             lr
    // 0x89b304: ldur            x2, [fp, #-8]
    // 0x89b308: r0 = LoadClassIdInstr(r2)
    //     0x89b308: ldur            x0, [x2, #-1]
    //     0x89b30c: ubfx            x0, x0, #0xc, #0x14
    // 0x89b310: mov             x1, x2
    // 0x89b314: r0 = GDT[cid_x0 + 0xfd90]()
    //     0x89b314: mov             x17, #0xfd90
    //     0x89b318: add             lr, x0, x17
    //     0x89b31c: ldr             lr, [x21, lr, lsl #3]
    //     0x89b320: blr             lr
    // 0x89b324: tbz             w0, #4, #0x89b34c
    // 0x89b328: ldur            x2, [fp, #-8]
    // 0x89b32c: r0 = LoadClassIdInstr(r2)
    //     0x89b32c: ldur            x0, [x2, #-1]
    //     0x89b330: ubfx            x0, x0, #0xc, #0x14
    // 0x89b334: mov             x1, x2
    // 0x89b338: r0 = GDT[cid_x0 + 0xf73b]()
    //     0x89b338: mov             x17, #0xf73b
    //     0x89b33c: add             lr, x0, x17
    //     0x89b340: ldr             lr, [x21, lr, lsl #3]
    //     0x89b344: blr             lr
    // 0x89b348: tbnz            w0, #4, #0x89b35c
    // 0x89b34c: ldur            x2, [fp, #-8]
    // 0x89b350: r0 = true
    //     0x89b350: add             x0, NULL, #0x20  ; true
    // 0x89b354: StoreField: r2->field_37 = r0
    //     0x89b354: stur            w0, [x2, #0x37]
    // 0x89b358: b               #0x89b360
    // 0x89b35c: ldur            x2, [fp, #-8]
    // 0x89b360: r0 = LoadClassIdInstr(r2)
    //     0x89b360: ldur            x0, [x2, #-1]
    //     0x89b364: ubfx            x0, x0, #0xc, #0x14
    // 0x89b368: mov             x1, x2
    // 0x89b36c: r0 = GDT[cid_x0 + 0xfd90]()
    //     0x89b36c: mov             x17, #0xfd90
    //     0x89b370: add             lr, x0, x17
    //     0x89b374: ldr             lr, [x21, lr, lsl #3]
    //     0x89b378: blr             lr
    // 0x89b37c: tbz             w0, #4, #0x89b420
    // 0x89b380: ldur            x0, [fp, #-8]
    // 0x89b384: LoadField: r1 = r0->field_2b
    //     0x89b384: ldur            w1, [x0, #0x2b]
    // 0x89b388: DecompressPointer r1
    //     0x89b388: add             x1, x1, HEAP, lsl #32
    // 0x89b38c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x89b390: cmp             w1, w16
    // 0x89b394: b.eq            #0x89b484
    // 0x89b398: tbnz            w1, #4, #0x89b414
    // 0x89b39c: r3 = false
    //     0x89b39c: add             x3, NULL, #0x30  ; false
    // 0x89b3a0: StoreField: r0->field_3b = r3
    //     0x89b3a0: stur            w3, [x0, #0x3b]
    // 0x89b3a4: StoreField: r0->field_3f = r3
    //     0x89b3a4: stur            w3, [x0, #0x3f]
    // 0x89b3a8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x89b3a8: ldur            w1, [x0, #0x17]
    // 0x89b3ac: DecompressPointer r1
    //     0x89b3ac: add             x1, x1, HEAP, lsl #32
    // 0x89b3b0: cmp             w1, NULL
    // 0x89b3b4: b.ne            #0x89b3c4
    // 0x89b3b8: mov             x1, x0
    // 0x89b3bc: mov             x0, x3
    // 0x89b3c0: b               #0x89b3f0
    // 0x89b3c4: LoadField: r4 = r1->field_27
    //     0x89b3c4: ldur            w4, [x1, #0x27]
    // 0x89b3c8: DecompressPointer r4
    //     0x89b3c8: add             x4, x4, HEAP, lsl #32
    // 0x89b3cc: ldur            x2, [fp, #-0x18]
    // 0x89b3d0: stur            x4, [fp, #-0x20]
    // 0x89b3d4: r1 = Function '<anonymous closure>':.
    //     0x89b3d4: ldr             x1, [PP, #0x2dc8]  ; [pp+0x2dc8] AnonymousClosure: (0x88f550), in [package:flutter/src/semantics/semantics.dart] SemanticsNode::detach (0x88f298)
    // 0x89b3d8: r0 = AllocateClosure()
    //     0x89b3d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x89b3dc: ldur            x1, [fp, #-0x20]
    // 0x89b3e0: mov             x2, x0
    // 0x89b3e4: r0 = removeWhere()
    //     0x89b3e4: bl              #0x843124  ; [dart:collection] ListBase::removeWhere
    // 0x89b3e8: ldur            x1, [fp, #-8]
    // 0x89b3ec: r0 = false
    //     0x89b3ec: add             x0, NULL, #0x30  ; false
    // 0x89b3f0: StoreField: r1->field_33 = r0
    //     0x89b3f0: stur            w0, [x1, #0x33]
    // 0x89b3f4: r0 = LoadClassIdInstr(r1)
    //     0x89b3f4: ldur            x0, [x1, #-1]
    //     0x89b3f8: ubfx            x0, x0, #0xc, #0x14
    // 0x89b3fc: r0 = GDT[cid_x0 + 0x10585]()
    //     0x89b3fc: mov             x17, #0x585
    //     0x89b400: movk            x17, #1, lsl #16
    //     0x89b404: add             lr, x0, x17
    //     0x89b408: ldr             lr, [x21, lr, lsl #3]
    //     0x89b40c: blr             lr
    // 0x89b410: b               #0x89b464
    // 0x89b414: mov             x1, x0
    // 0x89b418: r0 = false
    //     0x89b418: add             x0, NULL, #0x30  ; false
    // 0x89b41c: b               #0x89b428
    // 0x89b420: ldur            x1, [fp, #-8]
    // 0x89b424: r0 = false
    //     0x89b424: add             x0, NULL, #0x30  ; false
    // 0x89b428: ldur            x2, [fp, #-0x10]
    // 0x89b42c: LoadField: r3 = r1->field_37
    //     0x89b42c: ldur            w3, [x1, #0x37]
    // 0x89b430: DecompressPointer r3
    //     0x89b430: add             x3, x3, HEAP, lsl #32
    // 0x89b434: cmp             w2, w3
    // 0x89b438: b.eq            #0x89b460
    // 0x89b43c: StoreField: r1->field_33 = r0
    //     0x89b43c: stur            w0, [x1, #0x33]
    // 0x89b440: r0 = LoadClassIdInstr(r1)
    //     0x89b440: ldur            x0, [x1, #-1]
    //     0x89b444: ubfx            x0, x0, #0xc, #0x14
    // 0x89b448: r0 = GDT[cid_x0 + 0x10585]()
    //     0x89b448: mov             x17, #0x585
    //     0x89b44c: movk            x17, #1, lsl #16
    //     0x89b450: add             lr, x0, x17
    //     0x89b454: ldr             lr, [x21, lr, lsl #3]
    //     0x89b458: blr             lr
    // 0x89b45c: b               #0x89b464
    // 0x89b460: StoreField: r1->field_33 = r0
    //     0x89b460: stur            w0, [x1, #0x33]
    // 0x89b464: r0 = Null
    //     0x89b464: mov             x0, NULL
    // 0x89b468: LeaveFrame
    //     0x89b468: mov             SP, fp
    //     0x89b46c: ldp             fp, lr, [SP], #0x10
    // 0x89b470: ret
    //     0x89b470: ret             
    // 0x89b474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b474: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b478: b               #0x89b278
    // 0x89b47c: r9 = _needsCompositing
    //     0x89b47c: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0x89b480: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x89b480: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x89b484: r9 = _wasRepaintBoundary
    //     0x89b484: ldr             x9, [PP, #0x2dd8]  ; [pp+0x2dd8] Field <RenderObject._wasRepaintBoundary@30266271>: late (offset: 0x2c)
    // 0x89b488: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x89b488: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x89b48c, size: 0x80
    // 0x89b48c: EnterFrame
    //     0x89b48c: stp             fp, lr, [SP, #-0x10]!
    //     0x89b490: mov             fp, SP
    // 0x89b494: AllocStack(0x8)
    //     0x89b494: sub             SP, SP, #8
    // 0x89b498: SetupParameters([dynamic _ /* r0 */])
    //     0x89b498: ldr             x0, [fp, #0x18]
    //     0x89b49c: ldur            w2, [x0, #0x17]
    //     0x89b4a0: add             x2, x2, HEAP, lsl #32
    //     0x89b4a4: stur            x2, [fp, #-8]
    // 0x89b4a8: CheckStackOverflow
    //     0x89b4a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b4ac: cmp             SP, x16
    //     0x89b4b0: b.ls            #0x89b4fc
    // 0x89b4b4: ldr             x1, [fp, #0x10]
    // 0x89b4b8: r0 = _updateCompositingBits()
    //     0x89b4b8: bl              #0x89b25c  ; [package:flutter/src/rendering/object.dart] RenderObject::_updateCompositingBits
    // 0x89b4bc: ldr             x1, [fp, #0x10]
    // 0x89b4c0: LoadField: r2 = r1->field_37
    //     0x89b4c0: ldur            w2, [x1, #0x37]
    // 0x89b4c4: DecompressPointer r2
    //     0x89b4c4: add             x2, x2, HEAP, lsl #32
    // 0x89b4c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x89b4cc: cmp             w2, w16
    // 0x89b4d0: b.eq            #0x89b504
    // 0x89b4d4: tbnz            w2, #4, #0x89b4ec
    // 0x89b4d8: ldur            x1, [fp, #-8]
    // 0x89b4dc: r2 = true
    //     0x89b4dc: add             x2, NULL, #0x20  ; true
    // 0x89b4e0: LoadField: r3 = r1->field_f
    //     0x89b4e0: ldur            w3, [x1, #0xf]
    // 0x89b4e4: DecompressPointer r3
    //     0x89b4e4: add             x3, x3, HEAP, lsl #32
    // 0x89b4e8: StoreField: r3->field_37 = r2
    //     0x89b4e8: stur            w2, [x3, #0x37]
    // 0x89b4ec: r0 = Null
    //     0x89b4ec: mov             x0, NULL
    // 0x89b4f0: LeaveFrame
    //     0x89b4f0: mov             SP, fp
    //     0x89b4f4: ldp             fp, lr, [SP], #0x10
    // 0x89b4f8: ret
    //     0x89b4f8: ret             
    // 0x89b4fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b4fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b500: b               #0x89b4b4
    // 0x89b504: r9 = _needsCompositing
    //     0x89b504: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0x89b508: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x89b508: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _layoutWithoutResize(/* No info */) {
    // ** addr: 0x89b794, size: 0xa4
    // 0x89b794: EnterFrame
    //     0x89b794: stp             fp, lr, [SP, #-0x10]!
    //     0x89b798: mov             fp, SP
    // 0x89b79c: AllocStack(0x58)
    //     0x89b79c: sub             SP, SP, #0x58
    // 0x89b7a0: SetupParameters(RenderObject this /* r1 => r2, fp-0x58 */)
    //     0x89b7a0: mov             x2, x1
    //     0x89b7a4: stur            x1, [fp, #-0x58]
    // 0x89b7a8: CheckStackOverflow
    //     0x89b7a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89b7ac: cmp             SP, x16
    //     0x89b7b0: b.ls            #0x89b830
    // 0x89b7b4: r0 = LoadClassIdInstr(r2)
    //     0x89b7b4: ldur            x0, [x2, #-1]
    //     0x89b7b8: ubfx            x0, x0, #0xc, #0x14
    // 0x89b7bc: mov             x1, x2
    // 0x89b7c0: r0 = GDT[cid_x0 + 0x11329]()
    //     0x89b7c0: mov             x17, #0x1329
    //     0x89b7c4: movk            x17, #1, lsl #16
    //     0x89b7c8: add             lr, x0, x17
    //     0x89b7cc: ldr             lr, [x21, lr, lsl #3]
    //     0x89b7d0: blr             lr
    // 0x89b7d4: ldur            x1, [fp, #-0x58]
    // 0x89b7d8: r0 = markNeedsSemanticsUpdate()
    //     0x89b7d8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x89b7dc: b               #0x89b7f8
    // 0x89b7e0: sub             SP, fp, #0x58
    // 0x89b7e4: mov             x5, x1
    // 0x89b7e8: ldur            x1, [fp, #-0x58]
    // 0x89b7ec: mov             x3, x0
    // 0x89b7f0: r2 = "performLayout"
    //     0x89b7f0: ldr             x2, [PP, #0x2df8]  ; [pp+0x2df8] "performLayout"
    // 0x89b7f4: r0 = _reportException()
    //     0x89b7f4: bl              #0x89aaa0  ; [package:flutter/src/rendering/object.dart] RenderObject::_reportException
    // 0x89b7f8: ldur            x1, [fp, #-0x58]
    // 0x89b7fc: r0 = false
    //     0x89b7fc: add             x0, NULL, #0x30  ; false
    // 0x89b800: StoreField: r1->field_1b = r0
    //     0x89b800: stur            w0, [x1, #0x1b]
    // 0x89b804: r0 = LoadClassIdInstr(r1)
    //     0x89b804: ldur            x0, [x1, #-1]
    //     0x89b808: ubfx            x0, x0, #0xc, #0x14
    // 0x89b80c: r0 = GDT[cid_x0 + 0x10585]()
    //     0x89b80c: mov             x17, #0x585
    //     0x89b810: movk            x17, #1, lsl #16
    //     0x89b814: add             lr, x0, x17
    //     0x89b818: ldr             lr, [x21, lr, lsl #3]
    //     0x89b81c: blr             lr
    // 0x89b820: r0 = Null
    //     0x89b820: mov             x0, NULL
    // 0x89b824: LeaveFrame
    //     0x89b824: mov             SP, fp
    //     0x89b828: ldp             fp, lr, [SP], #0x10
    // 0x89b82c: ret
    //     0x89b82c: ret             
    // 0x89b830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b830: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b834: b               #0x89b7b4
  }
  _ replaceRootLayer(/* No info */) {
    // ** addr: 0x89cf40, size: 0x88
    // 0x89cf40: EnterFrame
    //     0x89cf40: stp             fp, lr, [SP, #-0x10]!
    //     0x89cf44: mov             fp, SP
    // 0x89cf48: AllocStack(0x18)
    //     0x89cf48: sub             SP, SP, #0x18
    // 0x89cf4c: SetupParameters(RenderObject this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x89cf4c: mov             x3, x1
    //     0x89cf50: stur            x1, [fp, #-0x10]
    //     0x89cf54: stur            x2, [fp, #-0x18]
    // 0x89cf58: CheckStackOverflow
    //     0x89cf58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89cf5c: cmp             SP, x16
    //     0x89cf60: b.ls            #0x89cfbc
    // 0x89cf64: LoadField: r4 = r3->field_2f
    //     0x89cf64: ldur            w4, [x3, #0x2f]
    // 0x89cf68: DecompressPointer r4
    //     0x89cf68: add             x4, x4, HEAP, lsl #32
    // 0x89cf6c: stur            x4, [fp, #-8]
    // 0x89cf70: LoadField: r1 = r4->field_b
    //     0x89cf70: ldur            w1, [x4, #0xb]
    // 0x89cf74: DecompressPointer r1
    //     0x89cf74: add             x1, x1, HEAP, lsl #32
    // 0x89cf78: cmp             w1, NULL
    // 0x89cf7c: b.eq            #0x89cfc4
    // 0x89cf80: r0 = LoadClassIdInstr(r1)
    //     0x89cf80: ldur            x0, [x1, #-1]
    //     0x89cf84: ubfx            x0, x0, #0xc, #0x14
    // 0x89cf88: r0 = GDT[cid_x0 + 0x8ed7]()
    //     0x89cf88: mov             x17, #0x8ed7
    //     0x89cf8c: add             lr, x0, x17
    //     0x89cf90: ldr             lr, [x21, lr, lsl #3]
    //     0x89cf94: blr             lr
    // 0x89cf98: ldur            x1, [fp, #-8]
    // 0x89cf9c: ldur            x2, [fp, #-0x18]
    // 0x89cfa0: r0 = layer=()
    //     0x89cfa0: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x89cfa4: ldur            x1, [fp, #-0x10]
    // 0x89cfa8: r0 = markNeedsPaint()
    //     0x89cfa8: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x89cfac: r0 = Null
    //     0x89cfac: mov             x0, NULL
    // 0x89cfb0: LeaveFrame
    //     0x89cfb0: mov             SP, fp
    //     0x89cfb4: ldp             fp, lr, [SP], #0x10
    // 0x89cfb8: ret
    //     0x89cfb8: ret             
    // 0x89cfbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89cfbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89cfc0: b               #0x89cf64
    // 0x89cfc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x89cfc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scheduleInitialSemantics(/* No info */) {
    // ** addr: 0xb8ec48, size: 0xa8
    // 0xb8ec48: EnterFrame
    //     0xb8ec48: stp             fp, lr, [SP, #-0x10]!
    //     0xb8ec4c: mov             fp, SP
    // 0xb8ec50: AllocStack(0x8)
    //     0xb8ec50: sub             SP, SP, #8
    // 0xb8ec54: SetupParameters(RenderObject this /* r1 => r0, fp-0x8 */)
    //     0xb8ec54: mov             x0, x1
    //     0xb8ec58: stur            x1, [fp, #-8]
    // 0xb8ec5c: CheckStackOverflow
    //     0xb8ec5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8ec60: cmp             SP, x16
    //     0xb8ec64: b.ls            #0xb8ecdc
    // 0xb8ec68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb8ec68: ldur            w1, [x0, #0x17]
    // 0xb8ec6c: DecompressPointer r1
    //     0xb8ec6c: add             x1, x1, HEAP, lsl #32
    // 0xb8ec70: cmp             w1, NULL
    // 0xb8ec74: b.eq            #0xb8ece4
    // 0xb8ec78: LoadField: r2 = r1->field_37
    //     0xb8ec78: ldur            w2, [x1, #0x37]
    // 0xb8ec7c: DecompressPointer r2
    //     0xb8ec7c: add             x2, x2, HEAP, lsl #32
    // 0xb8ec80: mov             x1, x2
    // 0xb8ec84: mov             x2, x0
    // 0xb8ec88: r0 = add()
    //     0xb8ec88: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xb8ec8c: ldur            x0, [fp, #-8]
    // 0xb8ec90: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb8ec90: ldur            w1, [x0, #0x17]
    // 0xb8ec94: DecompressPointer r1
    //     0xb8ec94: add             x1, x1, HEAP, lsl #32
    // 0xb8ec98: cmp             w1, NULL
    // 0xb8ec9c: b.eq            #0xb8ece8
    // 0xb8eca0: LoadField: r2 = r1->field_3b
    //     0xb8eca0: ldur            w2, [x1, #0x3b]
    // 0xb8eca4: DecompressPointer r2
    //     0xb8eca4: add             x2, x2, HEAP, lsl #32
    // 0xb8eca8: mov             x1, x2
    // 0xb8ecac: mov             x2, x0
    // 0xb8ecb0: r0 = add()
    //     0xb8ecb0: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xb8ecb4: ldur            x0, [fp, #-8]
    // 0xb8ecb8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb8ecb8: ldur            w1, [x0, #0x17]
    // 0xb8ecbc: DecompressPointer r1
    //     0xb8ecbc: add             x1, x1, HEAP, lsl #32
    // 0xb8ecc0: cmp             w1, NULL
    // 0xb8ecc4: b.eq            #0xb8ecec
    // 0xb8ecc8: r0 = requestVisualUpdate()
    //     0xb8ecc8: bl              #0x837988  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0xb8eccc: r0 = Null
    //     0xb8eccc: mov             x0, NULL
    // 0xb8ecd0: LeaveFrame
    //     0xb8ecd0: mov             SP, fp
    //     0xb8ecd4: ldp             fp, lr, [SP], #0x10
    // 0xb8ecd8: ret
    //     0xb8ecd8: ret             
    // 0xb8ecdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8ecdc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8ece0: b               #0xb8ec68
    // 0xb8ece4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8ece4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb8ece8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8ece8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb8ecec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8ecec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scheduleInitialPaint(/* No info */) {
    // ** addr: 0xb8edac, size: 0xdc
    // 0xb8edac: EnterFrame
    //     0xb8edac: stp             fp, lr, [SP, #-0x10]!
    //     0xb8edb0: mov             fp, SP
    // 0xb8edb4: AllocStack(0x18)
    //     0xb8edb4: sub             SP, SP, #0x18
    // 0xb8edb8: SetupParameters(RenderObject this /* r1 => r0, fp-0x8 */)
    //     0xb8edb8: mov             x0, x1
    //     0xb8edbc: stur            x1, [fp, #-8]
    // 0xb8edc0: CheckStackOverflow
    //     0xb8edc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8edc4: cmp             SP, x16
    //     0xb8edc8: b.ls            #0xb8ee7c
    // 0xb8edcc: LoadField: r1 = r0->field_2f
    //     0xb8edcc: ldur            w1, [x0, #0x2f]
    // 0xb8edd0: DecompressPointer r1
    //     0xb8edd0: add             x1, x1, HEAP, lsl #32
    // 0xb8edd4: r0 = layer=()
    //     0xb8edd4: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xb8edd8: ldur            x0, [fp, #-8]
    // 0xb8eddc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb8eddc: ldur            w1, [x0, #0x17]
    // 0xb8ede0: DecompressPointer r1
    //     0xb8ede0: add             x1, x1, HEAP, lsl #32
    // 0xb8ede4: cmp             w1, NULL
    // 0xb8ede8: b.eq            #0xb8ee84
    // 0xb8edec: LoadField: r2 = r1->field_27
    //     0xb8edec: ldur            w2, [x1, #0x27]
    // 0xb8edf0: DecompressPointer r2
    //     0xb8edf0: add             x2, x2, HEAP, lsl #32
    // 0xb8edf4: stur            x2, [fp, #-0x18]
    // 0xb8edf8: LoadField: r1 = r2->field_b
    //     0xb8edf8: ldur            w1, [x2, #0xb]
    // 0xb8edfc: LoadField: r3 = r2->field_f
    //     0xb8edfc: ldur            w3, [x2, #0xf]
    // 0xb8ee00: DecompressPointer r3
    //     0xb8ee00: add             x3, x3, HEAP, lsl #32
    // 0xb8ee04: LoadField: r4 = r3->field_b
    //     0xb8ee04: ldur            w4, [x3, #0xb]
    // 0xb8ee08: r3 = LoadInt32Instr(r1)
    //     0xb8ee08: sbfx            x3, x1, #1, #0x1f
    // 0xb8ee0c: stur            x3, [fp, #-0x10]
    // 0xb8ee10: r1 = LoadInt32Instr(r4)
    //     0xb8ee10: sbfx            x1, x4, #1, #0x1f
    // 0xb8ee14: cmp             x3, x1
    // 0xb8ee18: b.ne            #0xb8ee24
    // 0xb8ee1c: mov             x1, x2
    // 0xb8ee20: r0 = _growToNextCapacity()
    //     0xb8ee20: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb8ee24: ldur            x2, [fp, #-0x18]
    // 0xb8ee28: ldur            x3, [fp, #-0x10]
    // 0xb8ee2c: add             x4, x3, #1
    // 0xb8ee30: lsl             x5, x4, #1
    // 0xb8ee34: StoreField: r2->field_b = r5
    //     0xb8ee34: stur            w5, [x2, #0xb]
    // 0xb8ee38: LoadField: r1 = r2->field_f
    //     0xb8ee38: ldur            w1, [x2, #0xf]
    // 0xb8ee3c: DecompressPointer r1
    //     0xb8ee3c: add             x1, x1, HEAP, lsl #32
    // 0xb8ee40: ldur            x0, [fp, #-8]
    // 0xb8ee44: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb8ee44: add             x25, x1, x3, lsl #2
    //     0xb8ee48: add             x25, x25, #0xf
    //     0xb8ee4c: str             w0, [x25]
    //     0xb8ee50: tbz             w0, #0, #0xb8ee6c
    //     0xb8ee54: ldurb           w16, [x1, #-1]
    //     0xb8ee58: ldurb           w17, [x0, #-1]
    //     0xb8ee5c: and             x16, x17, x16, lsr #2
    //     0xb8ee60: tst             x16, HEAP, lsr #32
    //     0xb8ee64: b.eq            #0xb8ee6c
    //     0xb8ee68: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb8ee6c: r0 = Null
    //     0xb8ee6c: mov             x0, NULL
    // 0xb8ee70: LeaveFrame
    //     0xb8ee70: mov             SP, fp
    //     0xb8ee74: ldp             fp, lr, [SP], #0x10
    // 0xb8ee78: ret
    //     0xb8ee78: ret             
    // 0xb8ee7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8ee7c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8ee80: b               #0xb8edcc
    // 0xb8ee84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8ee84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scheduleInitialLayout(/* No info */) {
    // ** addr: 0xb8ee88, size: 0xd4
    // 0xb8ee88: EnterFrame
    //     0xb8ee88: stp             fp, lr, [SP, #-0x10]!
    //     0xb8ee8c: mov             fp, SP
    // 0xb8ee90: AllocStack(0x18)
    //     0xb8ee90: sub             SP, SP, #0x18
    // 0xb8ee94: r0 = true
    //     0xb8ee94: add             x0, NULL, #0x20  ; true
    // 0xb8ee98: mov             x2, x1
    // 0xb8ee9c: stur            x1, [fp, #-0x18]
    // 0xb8eea0: CheckStackOverflow
    //     0xb8eea0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8eea4: cmp             SP, x16
    //     0xb8eea8: b.ls            #0xb8ef50
    // 0xb8eeac: StoreField: r2->field_1f = r0
    //     0xb8eeac: stur            w0, [x2, #0x1f]
    // 0xb8eeb0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xb8eeb0: ldur            w0, [x2, #0x17]
    // 0xb8eeb4: DecompressPointer r0
    //     0xb8eeb4: add             x0, x0, HEAP, lsl #32
    // 0xb8eeb8: cmp             w0, NULL
    // 0xb8eebc: b.eq            #0xb8ef58
    // 0xb8eec0: LoadField: r3 = r0->field_1f
    //     0xb8eec0: ldur            w3, [x0, #0x1f]
    // 0xb8eec4: DecompressPointer r3
    //     0xb8eec4: add             x3, x3, HEAP, lsl #32
    // 0xb8eec8: stur            x3, [fp, #-0x10]
    // 0xb8eecc: LoadField: r0 = r3->field_b
    //     0xb8eecc: ldur            w0, [x3, #0xb]
    // 0xb8eed0: LoadField: r1 = r3->field_f
    //     0xb8eed0: ldur            w1, [x3, #0xf]
    // 0xb8eed4: DecompressPointer r1
    //     0xb8eed4: add             x1, x1, HEAP, lsl #32
    // 0xb8eed8: LoadField: r4 = r1->field_b
    //     0xb8eed8: ldur            w4, [x1, #0xb]
    // 0xb8eedc: r5 = LoadInt32Instr(r0)
    //     0xb8eedc: sbfx            x5, x0, #1, #0x1f
    // 0xb8eee0: stur            x5, [fp, #-8]
    // 0xb8eee4: r0 = LoadInt32Instr(r4)
    //     0xb8eee4: sbfx            x0, x4, #1, #0x1f
    // 0xb8eee8: cmp             x5, x0
    // 0xb8eeec: b.ne            #0xb8eef8
    // 0xb8eef0: mov             x1, x3
    // 0xb8eef4: r0 = _growToNextCapacity()
    //     0xb8eef4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb8eef8: ldur            x2, [fp, #-0x10]
    // 0xb8eefc: ldur            x3, [fp, #-8]
    // 0xb8ef00: add             x4, x3, #1
    // 0xb8ef04: lsl             x5, x4, #1
    // 0xb8ef08: StoreField: r2->field_b = r5
    //     0xb8ef08: stur            w5, [x2, #0xb]
    // 0xb8ef0c: LoadField: r1 = r2->field_f
    //     0xb8ef0c: ldur            w1, [x2, #0xf]
    // 0xb8ef10: DecompressPointer r1
    //     0xb8ef10: add             x1, x1, HEAP, lsl #32
    // 0xb8ef14: ldur            x0, [fp, #-0x18]
    // 0xb8ef18: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb8ef18: add             x25, x1, x3, lsl #2
    //     0xb8ef1c: add             x25, x25, #0xf
    //     0xb8ef20: str             w0, [x25]
    //     0xb8ef24: tbz             w0, #0, #0xb8ef40
    //     0xb8ef28: ldurb           w16, [x1, #-1]
    //     0xb8ef2c: ldurb           w17, [x0, #-1]
    //     0xb8ef30: and             x16, x17, x16, lsr #2
    //     0xb8ef34: tst             x16, HEAP, lsr #32
    //     0xb8ef38: b.eq            #0xb8ef40
    //     0xb8ef3c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xb8ef40: r0 = Null
    //     0xb8ef40: mov             x0, NULL
    // 0xb8ef44: LeaveFrame
    //     0xb8ef44: mov             SP, fp
    //     0xb8ef48: ldp             fp, lr, [SP], #0x10
    // 0xb8ef4c: ret
    //     0xb8ef4c: ret             
    // 0xb8ef50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8ef50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8ef54: b               #0xb8eeac
    // 0xb8ef58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb8ef58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void dropChild(dynamic, RenderObject) {
    // ** addr: 0xb918c8, size: 0x3c
    // 0xb918c8: EnterFrame
    //     0xb918c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb918cc: mov             fp, SP
    // 0xb918d0: ldr             x0, [fp, #0x18]
    // 0xb918d4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb918d4: ldur            w1, [x0, #0x17]
    // 0xb918d8: DecompressPointer r1
    //     0xb918d8: add             x1, x1, HEAP, lsl #32
    // 0xb918dc: CheckStackOverflow
    //     0xb918dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb918e0: cmp             SP, x16
    //     0xb918e4: b.ls            #0xb918fc
    // 0xb918e8: ldr             x2, [fp, #0x10]
    // 0xb918ec: r0 = dropChild()
    //     0xb918ec: bl              #0xbee868  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0xb918f0: LeaveFrame
    //     0xb918f0: mov             SP, fp
    //     0xb918f4: ldp             fp, lr, [SP], #0x10
    // 0xb918f8: ret
    //     0xb918f8: ret             
    // 0xb918fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb918fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb91900: b               #0xb918e8
  }
  void invokeLayoutCallback<Y0 extends Constraints>(RenderObject, (dynamic, Y0) => void) {
    // ** addr: 0xbb849c, size: 0x108
    // 0xbb849c: EnterFrame
    //     0xbb849c: stp             fp, lr, [SP, #-0x10]!
    //     0xbb84a0: mov             fp, SP
    // 0xbb84a4: AllocStack(0x60)
    //     0xbb84a4: sub             SP, SP, #0x60
    // 0xbb84a8: SetupParameters([dynamic _ /* r1 */, dynamic _ /* r2 */])
    //     0xbb84a8: ldur            w0, [x4, #0xf]
    //     0xbb84ac: stur            x0, [fp, #-0x58]
    //     0xbb84b0: cbnz            w0, #0xbb84bc
    //     0xbb84b4: mov             x3, NULL
    //     0xbb84b8: b               #0xbb84cc
    //     0xbb84bc: ldur            w1, [x4, #0x17]
    //     0xbb84c0: add             x2, fp, w1, sxtw #2
    //     0xbb84c4: ldr             x2, [x2, #0x10]
    //     0xbb84c8: mov             x3, x2
    //     0xbb84cc: ldr             x2, [fp, #0x18]
    //     0xbb84d0: ldr             x1, [fp, #0x10]
    //     0xbb84d4: stur            x3, [fp, #-0x50]
    // 0xbb84d8: CheckStackOverflow
    //     0xbb84d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb84dc: cmp             SP, x16
    //     0xbb84e0: b.ls            #0xbb8598
    // 0xbb84e4: r1 = 2
    //     0xbb84e4: mov             x1, #2
    // 0xbb84e8: r0 = AllocateContext()
    //     0xbb84e8: bl              #0x13de838  ; AllocateContextStub
    // 0xbb84ec: mov             x3, x0
    // 0xbb84f0: ldr             x0, [fp, #0x18]
    // 0xbb84f4: stur            x3, [fp, #-0x60]
    // 0xbb84f8: StoreField: r3->field_f = r0
    //     0xbb84f8: stur            w0, [x3, #0xf]
    // 0xbb84fc: ldr             x1, [fp, #0x10]
    // 0xbb8500: StoreField: r3->field_13 = r1
    //     0xbb8500: stur            w1, [x3, #0x13]
    // 0xbb8504: ldur            x1, [fp, #-0x58]
    // 0xbb8508: cbnz            w1, #0xbb8518
    // 0xbb850c: r4 = <Constraints>
    //     0xbb850c: add             x4, PP, #0x8d, lsl #12  ; [pp+0x8d670] TypeArguments: <Constraints>
    //     0xbb8510: ldr             x4, [x4, #0x670]
    // 0xbb8514: b               #0xbb851c
    // 0xbb8518: ldur            x4, [fp, #-0x50]
    // 0xbb851c: r1 = true
    //     0xbb851c: add             x1, NULL, #0x20  ; true
    // 0xbb8520: stur            x4, [fp, #-0x58]
    // 0xbb8524: StoreField: r0->field_23 = r1
    //     0xbb8524: stur            w1, [x0, #0x23]
    // 0xbb8528: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xbb8528: ldur            w5, [x0, #0x17]
    // 0xbb852c: DecompressPointer r5
    //     0xbb852c: add             x5, x5, HEAP, lsl #32
    // 0xbb8530: stur            x5, [fp, #-0x50]
    // 0xbb8534: cmp             w5, NULL
    // 0xbb8538: b.eq            #0xbb85a0
    // 0xbb853c: mov             x2, x3
    // 0xbb8540: r1 = Function '<anonymous closure>':.
    //     0xbb8540: add             x1, PP, #0x8d, lsl #12  ; [pp+0x8d678] AnonymousClosure: (0xbb8620), in [package:flutter/src/rendering/object.dart] RenderObject::invokeLayoutCallback (0xbb849c)
    //     0xbb8544: ldr             x1, [x1, #0x678]
    // 0xbb8548: r0 = AllocateClosure()
    //     0xbb8548: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbb854c: mov             x1, x0
    // 0xbb8550: ldur            x0, [fp, #-0x58]
    // 0xbb8554: StoreField: r1->field_b = r0
    //     0xbb8554: stur            w0, [x1, #0xb]
    // 0xbb8558: mov             x2, x1
    // 0xbb855c: ldur            x1, [fp, #-0x50]
    // 0xbb8560: r0 = _enableMutationsToDirtySubtrees()
    //     0xbb8560: bl              #0xbb85a4  ; [package:flutter/src/rendering/object.dart] PipelineOwner::_enableMutationsToDirtySubtrees
    // 0xbb8564: ldr             x2, [fp, #0x18]
    // 0xbb8568: r3 = false
    //     0xbb8568: add             x3, NULL, #0x30  ; false
    // 0xbb856c: StoreField: r2->field_23 = r3
    //     0xbb856c: stur            w3, [x2, #0x23]
    // 0xbb8570: r0 = Null
    //     0xbb8570: mov             x0, NULL
    // 0xbb8574: LeaveFrame
    //     0xbb8574: mov             SP, fp
    //     0xbb8578: ldp             fp, lr, [SP], #0x10
    // 0xbb857c: ret
    //     0xbb857c: ret             
    // 0xbb8580: sub             SP, fp, #0x60
    // 0xbb8584: ldr             x2, [fp, #0x18]
    // 0xbb8588: r3 = false
    //     0xbb8588: add             x3, NULL, #0x30  ; false
    // 0xbb858c: StoreField: r2->field_23 = r3
    //     0xbb858c: stur            w3, [x2, #0x23]
    // 0xbb8590: r0 = ReThrow()
    //     0xbb8590: bl              #0x13ddb00  ; ReThrowStub
    // 0xbb8594: brk             #0
    // 0xbb8598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb8598: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb859c: b               #0xbb84e4
    // 0xbb85a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb85a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xbb8620, size: 0xd4
    // 0xbb8620: EnterFrame
    //     0xbb8620: stp             fp, lr, [SP, #-0x10]!
    //     0xbb8624: mov             fp, SP
    // 0xbb8628: AllocStack(0x20)
    //     0xbb8628: sub             SP, SP, #0x20
    // 0xbb862c: SetupParameters([dynamic _ /* r0 */])
    //     0xbb862c: ldr             x0, [fp, #0x10]
    //     0xbb8630: ldur            w1, [x0, #0x17]
    //     0xbb8634: add             x1, x1, HEAP, lsl #32
    // 0xbb8638: CheckStackOverflow
    //     0xbb8638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb863c: cmp             SP, x16
    //     0xbb8640: b.ls            #0xbb86ec
    // 0xbb8644: LoadField: r2 = r0->field_b
    //     0xbb8644: ldur            w2, [x0, #0xb]
    // 0xbb8648: DecompressPointer r2
    //     0xbb8648: add             x2, x2, HEAP, lsl #32
    // 0xbb864c: stur            x2, [fp, #-0x10]
    // 0xbb8650: LoadField: r3 = r1->field_13
    //     0xbb8650: ldur            w3, [x1, #0x13]
    // 0xbb8654: DecompressPointer r3
    //     0xbb8654: add             x3, x3, HEAP, lsl #32
    // 0xbb8658: stur            x3, [fp, #-8]
    // 0xbb865c: LoadField: r0 = r1->field_f
    //     0xbb865c: ldur            w0, [x1, #0xf]
    // 0xbb8660: DecompressPointer r0
    //     0xbb8660: add             x0, x0, HEAP, lsl #32
    // 0xbb8664: r1 = LoadClassIdInstr(r0)
    //     0xbb8664: ldur            x1, [x0, #-1]
    //     0xbb8668: ubfx            x1, x1, #0xc, #0x14
    // 0xbb866c: mov             x16, x0
    // 0xbb8670: mov             x0, x1
    // 0xbb8674: mov             x1, x16
    // 0xbb8678: r0 = GDT[cid_x0 + 0xe9d5]()
    //     0xbb8678: mov             x17, #0xe9d5
    //     0xbb867c: add             lr, x0, x17
    //     0xbb8680: ldr             lr, [x21, lr, lsl #3]
    //     0xbb8684: blr             lr
    // 0xbb8688: ldur            x1, [fp, #-0x10]
    // 0xbb868c: mov             x3, x0
    // 0xbb8690: r2 = Null
    //     0xbb8690: mov             x2, NULL
    // 0xbb8694: stur            x3, [fp, #-0x10]
    // 0xbb8698: cmp             w1, NULL
    // 0xbb869c: b.eq            #0xbb86c0
    // 0xbb86a0: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xbb86a0: ldur            w4, [x1, #0x17]
    // 0xbb86a4: DecompressPointer r4
    //     0xbb86a4: add             x4, x4, HEAP, lsl #32
    // 0xbb86a8: r8 = Y0 bound Constraints
    //     0xbb86a8: add             x8, PP, #0x8d, lsl #12  ; [pp+0x8d680] TypeParameter: Y0 bound Constraints
    //     0xbb86ac: ldr             x8, [x8, #0x680]
    // 0xbb86b0: LoadField: r9 = r4->field_7
    //     0xbb86b0: ldur            x9, [x4, #7]
    // 0xbb86b4: r3 = Null
    //     0xbb86b4: add             x3, PP, #0x8d, lsl #12  ; [pp+0x8d688] Null
    //     0xbb86b8: ldr             x3, [x3, #0x688]
    // 0xbb86bc: blr             x9
    // 0xbb86c0: ldur            x16, [fp, #-8]
    // 0xbb86c4: ldur            lr, [fp, #-0x10]
    // 0xbb86c8: stp             lr, x16, [SP]
    // 0xbb86cc: ldur            x0, [fp, #-8]
    // 0xbb86d0: ClosureCall
    //     0xbb86d0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbb86d4: ldur            x2, [x0, #0x1f]
    //     0xbb86d8: blr             x2
    // 0xbb86dc: r0 = Null
    //     0xbb86dc: mov             x0, NULL
    // 0xbb86e0: LeaveFrame
    //     0xbb86e0: mov             SP, fp
    //     0xbb86e4: ldp             fp, lr, [SP], #0x10
    // 0xbb86e8: ret
    //     0xbb86e8: ret             
    // 0xbb86ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb86ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb86f0: b               #0xbb8644
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbecbe8, size: 0x48
    // 0xbecbe8: EnterFrame
    //     0xbecbe8: stp             fp, lr, [SP, #-0x10]!
    //     0xbecbec: mov             fp, SP
    // 0xbecbf0: CheckStackOverflow
    //     0xbecbf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbecbf4: cmp             SP, x16
    //     0xbecbf8: b.ls            #0xbecc28
    // 0xbecbfc: r0 = LoadClassIdInstr(r1)
    //     0xbecbfc: ldur            x0, [x1, #-1]
    //     0xbecc00: ubfx            x0, x0, #0xc, #0x14
    // 0xbecc04: r0 = GDT[cid_x0 + 0x10a11]()
    //     0xbecc04: mov             x17, #0xa11
    //     0xbecc08: movk            x17, #1, lsl #16
    //     0xbecc0c: add             lr, x0, x17
    //     0xbecc10: ldr             lr, [x21, lr, lsl #3]
    //     0xbecc14: blr             lr
    // 0xbecc18: r0 = Null
    //     0xbecc18: mov             x0, NULL
    // 0xbecc1c: LeaveFrame
    //     0xbecc1c: mov             SP, fp
    //     0xbecc20: ldp             fp, lr, [SP], #0x10
    // 0xbecc24: ret
    //     0xbecc24: ret             
    // 0xbecc28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbecc28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbecc2c: b               #0xbecbfc
  }
  _ updateCompositedLayer(/* No info */) {
    // ** addr: 0xbed3fc, size: 0x9c
    // 0xbed3fc: EnterFrame
    //     0xbed3fc: stp             fp, lr, [SP, #-0x10]!
    //     0xbed400: mov             fp, SP
    // 0xbed404: AllocStack(0x10)
    //     0xbed404: sub             SP, SP, #0x10
    // 0xbed408: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xbed408: mov             x3, x2
    //     0xbed40c: stur            x2, [fp, #-8]
    // 0xbed410: CheckStackOverflow
    //     0xbed410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbed414: cmp             SP, x16
    //     0xbed418: b.ls            #0xbed490
    // 0xbed41c: mov             x0, x3
    // 0xbed420: r2 = Null
    //     0xbed420: mov             x2, NULL
    // 0xbed424: r1 = Null
    //     0xbed424: mov             x1, NULL
    // 0xbed428: r4 = 60
    //     0xbed428: mov             x4, #0x3c
    // 0xbed42c: branchIfSmi(r0, 0xbed438)
    //     0xbed42c: tbz             w0, #0, #0xbed438
    // 0xbed430: r4 = LoadClassIdInstr(r0)
    //     0xbed430: ldur            x4, [x0, #-1]
    //     0xbed434: ubfx            x4, x4, #0xc, #0x14
    // 0xbed438: r17 = -4660
    //     0xbed438: mov             x17, #-0x1234
    // 0xbed43c: add             x4, x4, x17
    // 0xbed440: cmp             x4, #3
    // 0xbed444: b.ls            #0xbed458
    // 0xbed448: r8 = OffsetLayer?
    //     0xbed448: ldr             x8, [PP, #0x2d20]  ; [pp+0x2d20] Type: OffsetLayer?
    // 0xbed44c: r3 = Null
    //     0xbed44c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe2d8] Null
    //     0xbed450: ldr             x3, [x3, #0x2d8]
    // 0xbed454: r0 = DefaultNullableTypeTest()
    //     0xbed454: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xbed458: ldur            x0, [fp, #-8]
    // 0xbed45c: cmp             w0, NULL
    // 0xbed460: b.ne            #0xbed484
    // 0xbed464: r0 = OffsetLayer()
    //     0xbed464: bl              #0xbed498  ; AllocateOffsetLayerStub -> OffsetLayer (size=0x4c)
    // 0xbed468: mov             x2, x0
    // 0xbed46c: r0 = Instance_Offset
    //     0xbed46c: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbed470: stur            x2, [fp, #-0x10]
    // 0xbed474: StoreField: r2->field_47 = r0
    //     0xbed474: stur            w0, [x2, #0x47]
    // 0xbed478: mov             x1, x2
    // 0xbed47c: r0 = Layer()
    //     0xbed47c: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xbed480: ldur            x0, [fp, #-0x10]
    // 0xbed484: LeaveFrame
    //     0xbed484: mov             SP, fp
    //     0xbed488: ldp             fp, lr, [SP], #0x10
    // 0xbed48c: ret
    //     0xbed48c: ret             
    // 0xbed490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbed490: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbed494: b               #0xbed41c
  }
  dynamic showOnScreen(dynamic) {
    // ** addr: 0xbed7fc, size: 0x24
    // 0xbed7fc: EnterFrame
    //     0xbed7fc: stp             fp, lr, [SP, #-0x10]!
    //     0xbed800: mov             fp, SP
    // 0xbed804: ldr             x2, [fp, #0x10]
    // 0xbed808: r1 = Function 'showOnScreen':.
    //     0xbed808: add             x1, PP, #0xe, lsl #12  ; [pp+0xe2b8] AnonymousClosure: (0xbed820), in [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen (0xbee008)
    //     0xbed80c: ldr             x1, [x1, #0x2b8]
    // 0xbed810: r0 = AllocateClosure()
    //     0xbed810: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbed814: LeaveFrame
    //     0xbed814: mov             SP, fp
    //     0xbed818: ldp             fp, lr, [SP], #0x10
    // 0xbed81c: ret
    //     0xbed81c: ret             
  }
  [closure] void showOnScreen(dynamic, {RenderObject? descendant, Rect? rect, Duration duration, Curve curve}) {
    // ** addr: 0xbed820, size: 0x188
    // 0xbed820: EnterFrame
    //     0xbed820: stp             fp, lr, [SP, #-0x10]!
    //     0xbed824: mov             fp, SP
    // 0xbed828: AllocStack(0x20)
    //     0xbed828: sub             SP, SP, #0x20
    // 0xbed82c: SetupParameters(RenderObject this /* r2 */, {dynamic curve = Instance_Cubic /* r3 */, dynamic descendant = Null /* r5 */, dynamic duration = Instance_Duration /* r6 */, dynamic rect = Null /* r0 */})
    //     0xbed82c: ldur            w0, [x4, #0x13]
    //     0xbed830: sub             x1, x0, #2
    //     0xbed834: add             x2, fp, w1, sxtw #2
    //     0xbed838: ldr             x2, [x2, #0x10]
    //     0xbed83c: ldur            w1, [x4, #0x1f]
    //     0xbed840: add             x1, x1, HEAP, lsl #32
    //     0xbed844: ldr             x16, [PP, #0x5160]  ; [pp+0x5160] "curve"
    //     0xbed848: cmp             w1, w16
    //     0xbed84c: b.ne            #0xbed870
    //     0xbed850: ldur            w1, [x4, #0x23]
    //     0xbed854: add             x1, x1, HEAP, lsl #32
    //     0xbed858: sub             w3, w0, w1
    //     0xbed85c: add             x1, fp, w3, sxtw #2
    //     0xbed860: ldr             x1, [x1, #8]
    //     0xbed864: mov             x3, x1
    //     0xbed868: mov             x1, #1
    //     0xbed86c: b               #0xbed878
    //     0xbed870: ldr             x3, [PP, #0x53e8]  ; [pp+0x53e8] Obj!Cubic@129f421
    //     0xbed874: mov             x1, #0
    //     0xbed878: lsl             x5, x1, #1
    //     0xbed87c: lsl             w6, w5, #1
    //     0xbed880: add             w7, w6, #8
    //     0xbed884: add             x16, x4, w7, sxtw #1
    //     0xbed888: ldur            w8, [x16, #0xf]
    //     0xbed88c: add             x8, x8, HEAP, lsl #32
    //     0xbed890: ldr             x16, [PP, #0x53f0]  ; [pp+0x53f0] "descendant"
    //     0xbed894: cmp             w8, w16
    //     0xbed898: b.ne            #0xbed8cc
    //     0xbed89c: add             w1, w6, #0xa
    //     0xbed8a0: add             x16, x4, w1, sxtw #1
    //     0xbed8a4: ldur            w6, [x16, #0xf]
    //     0xbed8a8: add             x6, x6, HEAP, lsl #32
    //     0xbed8ac: sub             w1, w0, w6
    //     0xbed8b0: add             x6, fp, w1, sxtw #2
    //     0xbed8b4: ldr             x6, [x6, #8]
    //     0xbed8b8: add             w1, w5, #2
    //     0xbed8bc: sbfx            x5, x1, #1, #0x1f
    //     0xbed8c0: mov             x1, x5
    //     0xbed8c4: mov             x5, x6
    //     0xbed8c8: b               #0xbed8d0
    //     0xbed8cc: mov             x5, NULL
    //     0xbed8d0: lsl             x6, x1, #1
    //     0xbed8d4: lsl             w7, w6, #1
    //     0xbed8d8: add             w8, w7, #8
    //     0xbed8dc: add             x16, x4, w8, sxtw #1
    //     0xbed8e0: ldur            w9, [x16, #0xf]
    //     0xbed8e4: add             x9, x9, HEAP, lsl #32
    //     0xbed8e8: ldr             x16, [PP, #0x5170]  ; [pp+0x5170] "duration"
    //     0xbed8ec: cmp             w9, w16
    //     0xbed8f0: b.ne            #0xbed924
    //     0xbed8f4: add             w1, w7, #0xa
    //     0xbed8f8: add             x16, x4, w1, sxtw #1
    //     0xbed8fc: ldur            w7, [x16, #0xf]
    //     0xbed900: add             x7, x7, HEAP, lsl #32
    //     0xbed904: sub             w1, w0, w7
    //     0xbed908: add             x7, fp, w1, sxtw #2
    //     0xbed90c: ldr             x7, [x7, #8]
    //     0xbed910: add             w1, w6, #2
    //     0xbed914: sbfx            x6, x1, #1, #0x1f
    //     0xbed918: mov             x1, x6
    //     0xbed91c: mov             x6, x7
    //     0xbed920: b               #0xbed928
    //     0xbed924: ldr             x6, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    //     0xbed928: lsl             x7, x1, #1
    //     0xbed92c: lsl             w1, w7, #1
    //     0xbed930: add             w7, w1, #8
    //     0xbed934: add             x16, x4, w7, sxtw #1
    //     0xbed938: ldur            w8, [x16, #0xf]
    //     0xbed93c: add             x8, x8, HEAP, lsl #32
    //     0xbed940: ldr             x16, [PP, #0x53f8]  ; [pp+0x53f8] "rect"
    //     0xbed944: cmp             w8, w16
    //     0xbed948: b.ne            #0xbed96c
    //     0xbed94c: add             w7, w1, #0xa
    //     0xbed950: add             x16, x4, w7, sxtw #1
    //     0xbed954: ldur            w1, [x16, #0xf]
    //     0xbed958: add             x1, x1, HEAP, lsl #32
    //     0xbed95c: sub             w4, w0, w1
    //     0xbed960: add             x0, fp, w4, sxtw #2
    //     0xbed964: ldr             x0, [x0, #8]
    //     0xbed968: b               #0xbed970
    //     0xbed96c: mov             x0, NULL
    //     0xbed970: ldur            w1, [x2, #0x17]
    //     0xbed974: add             x1, x1, HEAP, lsl #32
    // 0xbed978: CheckStackOverflow
    //     0xbed978: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbed97c: cmp             SP, x16
    //     0xbed980: b.ls            #0xbed9a0
    // 0xbed984: stp             x0, x5, [SP, #0x10]
    // 0xbed988: stp             x3, x6, [SP]
    // 0xbed98c: r4 = const [0, 0x5, 0x4, 0x1, curve, 0x4, descendant, 0x1, duration, 0x3, rect, 0x2, null]
    //     0xbed98c: ldr             x4, [PP, #0x5400]  ; [pp+0x5400] List(13) [0, 0x5, 0x4, 0x1, "curve", 0x4, "descendant", 0x1, "duration", 0x3, "rect", 0x2, Null]
    // 0xbed990: r0 = showOnScreen()
    //     0xbed990: bl              #0xbee008  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0xbed994: LeaveFrame
    //     0xbed994: mov             SP, fp
    //     0xbed998: ldp             fp, lr, [SP], #0x10
    // 0xbed99c: ret
    //     0xbed99c: ret             
    // 0xbed9a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbed9a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbed9a4: b               #0xbed984
  }
  _ showOnScreen(/* No info */) {
    // ** addr: 0xbee008, size: 0x1f8
    // 0xbee008: EnterFrame
    //     0xbee008: stp             fp, lr, [SP, #-0x10]!
    //     0xbee00c: mov             fp, SP
    // 0xbee010: AllocStack(0x48)
    //     0xbee010: sub             SP, SP, #0x48
    // 0xbee014: SetupParameters(RenderObject this /* r1 => r2, fp-0x28 */, {dynamic curve = Instance_Cubic /* r3, fp-0x20 */, dynamic descendant = Null /* r5, fp-0x18 */, dynamic duration = Instance_Duration /* r6, fp-0x10 */, dynamic rect = Null /* r4, fp-0x8 */})
    //     0xbee014: mov             x2, x1
    //     0xbee018: stur            x1, [fp, #-0x28]
    //     0xbee01c: ldur            w0, [x4, #0x13]
    //     0xbee020: ldur            w1, [x4, #0x1f]
    //     0xbee024: add             x1, x1, HEAP, lsl #32
    //     0xbee028: ldr             x16, [PP, #0x5160]  ; [pp+0x5160] "curve"
    //     0xbee02c: cmp             w1, w16
    //     0xbee030: b.ne            #0xbee054
    //     0xbee034: ldur            w1, [x4, #0x23]
    //     0xbee038: add             x1, x1, HEAP, lsl #32
    //     0xbee03c: sub             w3, w0, w1
    //     0xbee040: add             x1, fp, w3, sxtw #2
    //     0xbee044: ldr             x1, [x1, #8]
    //     0xbee048: mov             x3, x1
    //     0xbee04c: mov             x1, #1
    //     0xbee050: b               #0xbee05c
    //     0xbee054: ldr             x3, [PP, #0x53e8]  ; [pp+0x53e8] Obj!Cubic@129f421
    //     0xbee058: mov             x1, #0
    //     0xbee05c: stur            x3, [fp, #-0x20]
    //     0xbee060: lsl             x5, x1, #1
    //     0xbee064: lsl             w6, w5, #1
    //     0xbee068: add             w7, w6, #8
    //     0xbee06c: add             x16, x4, w7, sxtw #1
    //     0xbee070: ldur            w8, [x16, #0xf]
    //     0xbee074: add             x8, x8, HEAP, lsl #32
    //     0xbee078: ldr             x16, [PP, #0x53f0]  ; [pp+0x53f0] "descendant"
    //     0xbee07c: cmp             w8, w16
    //     0xbee080: b.ne            #0xbee0b4
    //     0xbee084: add             w1, w6, #0xa
    //     0xbee088: add             x16, x4, w1, sxtw #1
    //     0xbee08c: ldur            w6, [x16, #0xf]
    //     0xbee090: add             x6, x6, HEAP, lsl #32
    //     0xbee094: sub             w1, w0, w6
    //     0xbee098: add             x6, fp, w1, sxtw #2
    //     0xbee09c: ldr             x6, [x6, #8]
    //     0xbee0a0: add             w1, w5, #2
    //     0xbee0a4: sbfx            x5, x1, #1, #0x1f
    //     0xbee0a8: mov             x1, x5
    //     0xbee0ac: mov             x5, x6
    //     0xbee0b0: b               #0xbee0b8
    //     0xbee0b4: mov             x5, NULL
    //     0xbee0b8: stur            x5, [fp, #-0x18]
    //     0xbee0bc: lsl             x6, x1, #1
    //     0xbee0c0: lsl             w7, w6, #1
    //     0xbee0c4: add             w8, w7, #8
    //     0xbee0c8: add             x16, x4, w8, sxtw #1
    //     0xbee0cc: ldur            w9, [x16, #0xf]
    //     0xbee0d0: add             x9, x9, HEAP, lsl #32
    //     0xbee0d4: ldr             x16, [PP, #0x5170]  ; [pp+0x5170] "duration"
    //     0xbee0d8: cmp             w9, w16
    //     0xbee0dc: b.ne            #0xbee110
    //     0xbee0e0: add             w1, w7, #0xa
    //     0xbee0e4: add             x16, x4, w1, sxtw #1
    //     0xbee0e8: ldur            w7, [x16, #0xf]
    //     0xbee0ec: add             x7, x7, HEAP, lsl #32
    //     0xbee0f0: sub             w1, w0, w7
    //     0xbee0f4: add             x7, fp, w1, sxtw #2
    //     0xbee0f8: ldr             x7, [x7, #8]
    //     0xbee0fc: add             w1, w6, #2
    //     0xbee100: sbfx            x6, x1, #1, #0x1f
    //     0xbee104: mov             x1, x6
    //     0xbee108: mov             x6, x7
    //     0xbee10c: b               #0xbee114
    //     0xbee110: ldr             x6, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    //     0xbee114: stur            x6, [fp, #-0x10]
    //     0xbee118: lsl             x7, x1, #1
    //     0xbee11c: lsl             w1, w7, #1
    //     0xbee120: add             w7, w1, #8
    //     0xbee124: add             x16, x4, w7, sxtw #1
    //     0xbee128: ldur            w8, [x16, #0xf]
    //     0xbee12c: add             x8, x8, HEAP, lsl #32
    //     0xbee130: ldr             x16, [PP, #0x53f8]  ; [pp+0x53f8] "rect"
    //     0xbee134: cmp             w8, w16
    //     0xbee138: b.ne            #0xbee160
    //     0xbee13c: add             w7, w1, #0xa
    //     0xbee140: add             x16, x4, w7, sxtw #1
    //     0xbee144: ldur            w1, [x16, #0xf]
    //     0xbee148: add             x1, x1, HEAP, lsl #32
    //     0xbee14c: sub             w4, w0, w1
    //     0xbee150: add             x0, fp, w4, sxtw #2
    //     0xbee154: ldr             x0, [x0, #8]
    //     0xbee158: mov             x4, x0
    //     0xbee15c: b               #0xbee164
    //     0xbee160: mov             x4, NULL
    //     0xbee164: stur            x4, [fp, #-8]
    // 0xbee168: CheckStackOverflow
    //     0xbee168: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbee16c: cmp             SP, x16
    //     0xbee170: b.ls            #0xbee1f8
    // 0xbee174: r0 = LoadClassIdInstr(r2)
    //     0xbee174: ldur            x0, [x2, #-1]
    //     0xbee178: ubfx            x0, x0, #0xc, #0x14
    // 0xbee17c: mov             x1, x2
    // 0xbee180: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xbee180: mov             x17, #0xfc0
    //     0xbee184: movk            x17, #1, lsl #16
    //     0xbee188: add             lr, x0, x17
    //     0xbee18c: ldr             lr, [x21, lr, lsl #3]
    //     0xbee190: blr             lr
    // 0xbee194: cmp             w0, NULL
    // 0xbee198: b.eq            #0xbee1e8
    // 0xbee19c: ldur            x1, [fp, #-0x18]
    // 0xbee1a0: cmp             w1, NULL
    // 0xbee1a4: b.ne            #0xbee1ac
    // 0xbee1a8: ldur            x1, [fp, #-0x28]
    // 0xbee1ac: r2 = LoadClassIdInstr(r0)
    //     0xbee1ac: ldur            x2, [x0, #-1]
    //     0xbee1b0: ubfx            x2, x2, #0xc, #0x14
    // 0xbee1b4: ldur            x16, [fp, #-8]
    // 0xbee1b8: stp             x16, x1, [SP, #0x10]
    // 0xbee1bc: ldur            x16, [fp, #-0x10]
    // 0xbee1c0: ldur            lr, [fp, #-0x20]
    // 0xbee1c4: stp             lr, x16, [SP]
    // 0xbee1c8: mov             x1, x0
    // 0xbee1cc: mov             x0, x2
    // 0xbee1d0: r4 = const [0, 0x5, 0x4, 0x1, curve, 0x4, descendant, 0x1, duration, 0x3, rect, 0x2, null]
    //     0xbee1d0: ldr             x4, [PP, #0x5400]  ; [pp+0x5400] List(13) [0, 0x5, 0x4, 0x1, "curve", 0x4, "descendant", 0x1, "duration", 0x3, "rect", 0x2, Null]
    // 0xbee1d4: r0 = GDT[cid_x0 + 0x10c57]()
    //     0xbee1d4: mov             x17, #0xc57
    //     0xbee1d8: movk            x17, #1, lsl #16
    //     0xbee1dc: add             lr, x0, x17
    //     0xbee1e0: ldr             lr, [x21, lr, lsl #3]
    //     0xbee1e4: blr             lr
    // 0xbee1e8: r0 = Null
    //     0xbee1e8: mov             x0, NULL
    // 0xbee1ec: LeaveFrame
    //     0xbee1ec: mov             SP, fp
    //     0xbee1f0: ldp             fp, lr, [SP], #0x10
    // 0xbee1f4: ret
    //     0xbee1f4: ret             
    // 0xbee1f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbee1f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbee1fc: b               #0xbee174
  }
  _ dropChild(/* No info */) {
    // ** addr: 0xbee868, size: 0xe8
    // 0xbee868: EnterFrame
    //     0xbee868: stp             fp, lr, [SP, #-0x10]!
    //     0xbee86c: mov             fp, SP
    // 0xbee870: AllocStack(0x10)
    //     0xbee870: sub             SP, SP, #0x10
    // 0xbee874: SetupParameters(RenderObject this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbee874: mov             x3, x1
    //     0xbee878: stur            x1, [fp, #-8]
    //     0xbee87c: stur            x2, [fp, #-0x10]
    // 0xbee880: CheckStackOverflow
    //     0xbee880: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbee884: cmp             SP, x16
    //     0xbee888: b.ls            #0xbee944
    // 0xbee88c: LoadField: r0 = r2->field_1f
    //     0xbee88c: ldur            w0, [x2, #0x1f]
    // 0xbee890: DecompressPointer r0
    //     0xbee890: add             x0, x0, HEAP, lsl #32
    // 0xbee894: cmp             w0, NULL
    // 0xbee898: b.eq            #0xbee8a4
    // 0xbee89c: tbz             w0, #4, #0xbee8a4
    // 0xbee8a0: StoreField: r2->field_1f = rNULL
    //     0xbee8a0: stur            NULL, [x2, #0x1f]
    // 0xbee8a4: LoadField: r1 = r2->field_7
    //     0xbee8a4: ldur            w1, [x2, #7]
    // 0xbee8a8: DecompressPointer r1
    //     0xbee8a8: add             x1, x1, HEAP, lsl #32
    // 0xbee8ac: cmp             w1, NULL
    // 0xbee8b0: b.eq            #0xbee94c
    // 0xbee8b4: r0 = LoadClassIdInstr(r1)
    //     0xbee8b4: ldur            x0, [x1, #-1]
    //     0xbee8b8: ubfx            x0, x0, #0xc, #0x14
    // 0xbee8bc: r0 = GDT[cid_x0 + 0xc8fe]()
    //     0xbee8bc: mov             x17, #0xc8fe
    //     0xbee8c0: add             lr, x0, x17
    //     0xbee8c4: ldr             lr, [x21, lr, lsl #3]
    //     0xbee8c8: blr             lr
    // 0xbee8cc: ldur            x1, [fp, #-0x10]
    // 0xbee8d0: StoreField: r1->field_7 = rNULL
    //     0xbee8d0: stur            NULL, [x1, #7]
    // 0xbee8d4: StoreField: r1->field_13 = rNULL
    //     0xbee8d4: stur            NULL, [x1, #0x13]
    // 0xbee8d8: ldur            x2, [fp, #-8]
    // 0xbee8dc: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xbee8dc: ldur            w0, [x2, #0x17]
    // 0xbee8e0: DecompressPointer r0
    //     0xbee8e0: add             x0, x0, HEAP, lsl #32
    // 0xbee8e4: cmp             w0, NULL
    // 0xbee8e8: b.eq            #0xbee904
    // 0xbee8ec: r0 = LoadClassIdInstr(r1)
    //     0xbee8ec: ldur            x0, [x1, #-1]
    //     0xbee8f0: ubfx            x0, x0, #0xc, #0x14
    // 0xbee8f4: r0 = GDT[cid_x0 + 0xf618]()
    //     0xbee8f4: mov             x17, #0xf618
    //     0xbee8f8: add             lr, x0, x17
    //     0xbee8fc: ldr             lr, [x21, lr, lsl #3]
    //     0xbee900: blr             lr
    // 0xbee904: ldur            x2, [fp, #-8]
    // 0xbee908: r0 = LoadClassIdInstr(r2)
    //     0xbee908: ldur            x0, [x2, #-1]
    //     0xbee90c: ubfx            x0, x0, #0xc, #0x14
    // 0xbee910: mov             x1, x2
    // 0xbee914: r0 = GDT[cid_x0 + 0xfc6d]()
    //     0xbee914: mov             x17, #0xfc6d
    //     0xbee918: add             lr, x0, x17
    //     0xbee91c: ldr             lr, [x21, lr, lsl #3]
    //     0xbee920: blr             lr
    // 0xbee924: ldur            x1, [fp, #-8]
    // 0xbee928: r0 = markNeedsCompositingBitsUpdate()
    //     0xbee928: bl              #0x8395c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0xbee92c: ldur            x1, [fp, #-8]
    // 0xbee930: r0 = markNeedsSemanticsUpdate()
    //     0xbee930: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xbee934: r0 = Null
    //     0xbee934: mov             x0, NULL
    // 0xbee938: LeaveFrame
    //     0xbee938: mov             SP, fp
    //     0xbee93c: ldp             fp, lr, [SP], #0x10
    // 0xbee940: ret
    //     0xbee940: ret             
    // 0xbee944: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbee944: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbee948: b               #0xbee88c
    // 0xbee94c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbee94c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsPaint(/* No info */) {
    // ** addr: 0xbf0858, size: 0x1f8
    // 0xbf0858: EnterFrame
    //     0xbf0858: stp             fp, lr, [SP, #-0x10]!
    //     0xbf085c: mov             fp, SP
    // 0xbf0860: AllocStack(0x18)
    //     0xbf0860: sub             SP, SP, #0x18
    // 0xbf0864: SetupParameters(RenderObject this /* r1 => r2, fp-0x8 */)
    //     0xbf0864: mov             x2, x1
    //     0xbf0868: stur            x1, [fp, #-8]
    // 0xbf086c: CheckStackOverflow
    //     0xbf086c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0870: cmp             SP, x16
    //     0xbf0874: b.ls            #0xbf0a38
    // 0xbf0878: LoadField: r0 = r2->field_3b
    //     0xbf0878: ldur            w0, [x2, #0x3b]
    // 0xbf087c: DecompressPointer r0
    //     0xbf087c: add             x0, x0, HEAP, lsl #32
    // 0xbf0880: tbnz            w0, #4, #0xbf0894
    // 0xbf0884: r0 = Null
    //     0xbf0884: mov             x0, NULL
    // 0xbf0888: LeaveFrame
    //     0xbf0888: mov             SP, fp
    //     0xbf088c: ldp             fp, lr, [SP], #0x10
    // 0xbf0890: ret
    //     0xbf0890: ret             
    // 0xbf0894: r0 = true
    //     0xbf0894: add             x0, NULL, #0x20  ; true
    // 0xbf0898: StoreField: r2->field_3b = r0
    //     0xbf0898: stur            w0, [x2, #0x3b]
    // 0xbf089c: r0 = LoadClassIdInstr(r2)
    //     0xbf089c: ldur            x0, [x2, #-1]
    //     0xbf08a0: ubfx            x0, x0, #0xc, #0x14
    // 0xbf08a4: mov             x1, x2
    // 0xbf08a8: r0 = GDT[cid_x0 + 0xfd90]()
    //     0xbf08a8: mov             x17, #0xfd90
    //     0xbf08ac: add             lr, x0, x17
    //     0xbf08b0: ldr             lr, [x21, lr, lsl #3]
    //     0xbf08b4: blr             lr
    // 0xbf08b8: tbnz            w0, #4, #0xbf098c
    // 0xbf08bc: ldur            x0, [fp, #-8]
    // 0xbf08c0: LoadField: r1 = r0->field_2b
    //     0xbf08c0: ldur            w1, [x0, #0x2b]
    // 0xbf08c4: DecompressPointer r1
    //     0xbf08c4: add             x1, x1, HEAP, lsl #32
    // 0xbf08c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbf08cc: cmp             w1, w16
    // 0xbf08d0: b.eq            #0xbf0a40
    // 0xbf08d4: tbnz            w1, #4, #0xbf0984
    // 0xbf08d8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf08d8: ldur            w1, [x0, #0x17]
    // 0xbf08dc: DecompressPointer r1
    //     0xbf08dc: add             x1, x1, HEAP, lsl #32
    // 0xbf08e0: cmp             w1, NULL
    // 0xbf08e4: b.eq            #0xbf0a28
    // 0xbf08e8: LoadField: r2 = r1->field_27
    //     0xbf08e8: ldur            w2, [x1, #0x27]
    // 0xbf08ec: DecompressPointer r2
    //     0xbf08ec: add             x2, x2, HEAP, lsl #32
    // 0xbf08f0: stur            x2, [fp, #-0x18]
    // 0xbf08f4: LoadField: r1 = r2->field_b
    //     0xbf08f4: ldur            w1, [x2, #0xb]
    // 0xbf08f8: LoadField: r3 = r2->field_f
    //     0xbf08f8: ldur            w3, [x2, #0xf]
    // 0xbf08fc: DecompressPointer r3
    //     0xbf08fc: add             x3, x3, HEAP, lsl #32
    // 0xbf0900: LoadField: r4 = r3->field_b
    //     0xbf0900: ldur            w4, [x3, #0xb]
    // 0xbf0904: r3 = LoadInt32Instr(r1)
    //     0xbf0904: sbfx            x3, x1, #1, #0x1f
    // 0xbf0908: stur            x3, [fp, #-0x10]
    // 0xbf090c: r1 = LoadInt32Instr(r4)
    //     0xbf090c: sbfx            x1, x4, #1, #0x1f
    // 0xbf0910: cmp             x3, x1
    // 0xbf0914: b.ne            #0xbf0920
    // 0xbf0918: mov             x1, x2
    // 0xbf091c: r0 = _growToNextCapacity()
    //     0xbf091c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbf0920: ldur            x2, [fp, #-8]
    // 0xbf0924: ldur            x0, [fp, #-0x18]
    // 0xbf0928: ldur            x3, [fp, #-0x10]
    // 0xbf092c: add             x1, x3, #1
    // 0xbf0930: lsl             x4, x1, #1
    // 0xbf0934: StoreField: r0->field_b = r4
    //     0xbf0934: stur            w4, [x0, #0xb]
    // 0xbf0938: LoadField: r1 = r0->field_f
    //     0xbf0938: ldur            w1, [x0, #0xf]
    // 0xbf093c: DecompressPointer r1
    //     0xbf093c: add             x1, x1, HEAP, lsl #32
    // 0xbf0940: mov             x0, x2
    // 0xbf0944: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbf0944: add             x25, x1, x3, lsl #2
    //     0xbf0948: add             x25, x25, #0xf
    //     0xbf094c: str             w0, [x25]
    //     0xbf0950: tbz             w0, #0, #0xbf096c
    //     0xbf0954: ldurb           w16, [x1, #-1]
    //     0xbf0958: ldurb           w17, [x0, #-1]
    //     0xbf095c: and             x16, x17, x16, lsr #2
    //     0xbf0960: tst             x16, HEAP, lsr #32
    //     0xbf0964: b.eq            #0xbf096c
    //     0xbf0968: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbf096c: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xbf096c: ldur            w1, [x2, #0x17]
    // 0xbf0970: DecompressPointer r1
    //     0xbf0970: add             x1, x1, HEAP, lsl #32
    // 0xbf0974: cmp             w1, NULL
    // 0xbf0978: b.eq            #0xbf0a48
    // 0xbf097c: r0 = requestVisualUpdate()
    //     0xbf097c: bl              #0x837988  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0xbf0980: b               #0xbf0a28
    // 0xbf0984: mov             x2, x0
    // 0xbf0988: b               #0xbf0990
    // 0xbf098c: ldur            x2, [fp, #-8]
    // 0xbf0990: r0 = LoadClassIdInstr(r2)
    //     0xbf0990: ldur            x0, [x2, #-1]
    //     0xbf0994: ubfx            x0, x0, #0xc, #0x14
    // 0xbf0998: mov             x1, x2
    // 0xbf099c: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xbf099c: mov             x17, #0xfc0
    //     0xbf09a0: movk            x17, #1, lsl #16
    //     0xbf09a4: add             lr, x0, x17
    //     0xbf09a8: ldr             lr, [x21, lr, lsl #3]
    //     0xbf09ac: blr             lr
    // 0xbf09b0: cmp             w0, NULL
    // 0xbf09b4: b.eq            #0xbf0a0c
    // 0xbf09b8: ldur            x1, [fp, #-8]
    // 0xbf09bc: r0 = LoadClassIdInstr(r1)
    //     0xbf09bc: ldur            x0, [x1, #-1]
    //     0xbf09c0: ubfx            x0, x0, #0xc, #0x14
    // 0xbf09c4: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xbf09c4: mov             x17, #0xfc0
    //     0xbf09c8: movk            x17, #1, lsl #16
    //     0xbf09cc: add             lr, x0, x17
    //     0xbf09d0: ldr             lr, [x21, lr, lsl #3]
    //     0xbf09d4: blr             lr
    // 0xbf09d8: cmp             w0, NULL
    // 0xbf09dc: b.eq            #0xbf0a4c
    // 0xbf09e0: r1 = LoadClassIdInstr(r0)
    //     0xbf09e0: ldur            x1, [x0, #-1]
    //     0xbf09e4: ubfx            x1, x1, #0xc, #0x14
    // 0xbf09e8: mov             x16, x0
    // 0xbf09ec: mov             x0, x1
    // 0xbf09f0: mov             x1, x16
    // 0xbf09f4: r0 = GDT[cid_x0 + 0x10585]()
    //     0xbf09f4: mov             x17, #0x585
    //     0xbf09f8: movk            x17, #1, lsl #16
    //     0xbf09fc: add             lr, x0, x17
    //     0xbf0a00: ldr             lr, [x21, lr, lsl #3]
    //     0xbf0a04: blr             lr
    // 0xbf0a08: b               #0xbf0a28
    // 0xbf0a0c: ldur            x1, [fp, #-8]
    // 0xbf0a10: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xbf0a10: ldur            w0, [x1, #0x17]
    // 0xbf0a14: DecompressPointer r0
    //     0xbf0a14: add             x0, x0, HEAP, lsl #32
    // 0xbf0a18: cmp             w0, NULL
    // 0xbf0a1c: b.eq            #0xbf0a28
    // 0xbf0a20: mov             x1, x0
    // 0xbf0a24: r0 = requestVisualUpdate()
    //     0xbf0a24: bl              #0x837988  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0xbf0a28: r0 = Null
    //     0xbf0a28: mov             x0, NULL
    // 0xbf0a2c: LeaveFrame
    //     0xbf0a2c: mov             SP, fp
    //     0xbf0a30: ldp             fp, lr, [SP], #0x10
    // 0xbf0a34: ret
    //     0xbf0a34: ret             
    // 0xbf0a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0a38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0a3c: b               #0xbf0878
    // 0xbf0a40: r9 = _wasRepaintBoundary
    //     0xbf0a40: ldr             x9, [PP, #0x2dd8]  ; [pp+0x2dd8] Field <RenderObject._wasRepaintBoundary@30266271>: late (offset: 0x2c)
    // 0xbf0a44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbf0a44: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbf0a48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0a48: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0a4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf0a4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void markNeedsPaint(dynamic) {
    // ** addr: 0xbf0a50, size: 0x38
    // 0xbf0a50: EnterFrame
    //     0xbf0a50: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0a54: mov             fp, SP
    // 0xbf0a58: ldr             x0, [fp, #0x10]
    // 0xbf0a5c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf0a5c: ldur            w1, [x0, #0x17]
    // 0xbf0a60: DecompressPointer r1
    //     0xbf0a60: add             x1, x1, HEAP, lsl #32
    // 0xbf0a64: CheckStackOverflow
    //     0xbf0a64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0a68: cmp             SP, x16
    //     0xbf0a6c: b.ls            #0xbf0a80
    // 0xbf0a70: r0 = markNeedsPaint()
    //     0xbf0a70: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xbf0a74: LeaveFrame
    //     0xbf0a74: mov             SP, fp
    //     0xbf0a78: ldp             fp, lr, [SP], #0x10
    // 0xbf0a7c: ret
    //     0xbf0a7c: ret             
    // 0xbf0a80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0a80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0a84: b               #0xbf0a70
  }
  _ markParentNeedsLayout(/* No info */) {
    // ** addr: 0xbfb594, size: 0xa0
    // 0xbfb594: EnterFrame
    //     0xbfb594: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb598: mov             fp, SP
    // 0xbfb59c: AllocStack(0x8)
    //     0xbfb59c: sub             SP, SP, #8
    // 0xbfb5a0: r0 = true
    //     0xbfb5a0: add             x0, NULL, #0x20  ; true
    // 0xbfb5a4: mov             x2, x1
    // 0xbfb5a8: stur            x1, [fp, #-8]
    // 0xbfb5ac: CheckStackOverflow
    //     0xbfb5ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfb5b0: cmp             SP, x16
    //     0xbfb5b4: b.ls            #0xbfb628
    // 0xbfb5b8: StoreField: r2->field_1b = r0
    //     0xbfb5b8: stur            w0, [x2, #0x1b]
    // 0xbfb5bc: r0 = LoadClassIdInstr(r2)
    //     0xbfb5bc: ldur            x0, [x2, #-1]
    //     0xbfb5c0: ubfx            x0, x0, #0xc, #0x14
    // 0xbfb5c4: mov             x1, x2
    // 0xbfb5c8: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xbfb5c8: mov             x17, #0xfc0
    //     0xbfb5cc: movk            x17, #1, lsl #16
    //     0xbfb5d0: add             lr, x0, x17
    //     0xbfb5d4: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb5d8: blr             lr
    // 0xbfb5dc: cmp             w0, NULL
    // 0xbfb5e0: b.eq            #0xbfb630
    // 0xbfb5e4: ldur            x1, [fp, #-8]
    // 0xbfb5e8: LoadField: r2 = r1->field_23
    //     0xbfb5e8: ldur            w2, [x1, #0x23]
    // 0xbfb5ec: DecompressPointer r2
    //     0xbfb5ec: add             x2, x2, HEAP, lsl #32
    // 0xbfb5f0: tbz             w2, #4, #0xbfb618
    // 0xbfb5f4: r1 = LoadClassIdInstr(r0)
    //     0xbfb5f4: ldur            x1, [x0, #-1]
    //     0xbfb5f8: ubfx            x1, x1, #0xc, #0x14
    // 0xbfb5fc: mov             x16, x0
    // 0xbfb600: mov             x0, x1
    // 0xbfb604: mov             x1, x16
    // 0xbfb608: r0 = GDT[cid_x0 + 0xfc6d]()
    //     0xbfb608: mov             x17, #0xfc6d
    //     0xbfb60c: add             lr, x0, x17
    //     0xbfb610: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb614: blr             lr
    // 0xbfb618: r0 = Null
    //     0xbfb618: mov             x0, NULL
    // 0xbfb61c: LeaveFrame
    //     0xbfb61c: mov             SP, fp
    //     0xbfb620: ldp             fp, lr, [SP], #0x10
    // 0xbfb624: ret
    //     0xbfb624: ret             
    // 0xbfb628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb628: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb62c: b               #0xbfb5b8
    // 0xbfb630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfb630: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0xbfb800, size: 0x144
    // 0xbfb800: EnterFrame
    //     0xbfb800: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb804: mov             fp, SP
    // 0xbfb808: AllocStack(0x20)
    //     0xbfb808: sub             SP, SP, #0x20
    // 0xbfb80c: SetupParameters(RenderObject this /* r1 => r0, fp-0x20 */)
    //     0xbfb80c: mov             x0, x1
    //     0xbfb810: stur            x1, [fp, #-0x20]
    // 0xbfb814: CheckStackOverflow
    //     0xbfb814: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfb818: cmp             SP, x16
    //     0xbfb81c: b.ls            #0xbfb93c
    // 0xbfb820: LoadField: r1 = r0->field_1b
    //     0xbfb820: ldur            w1, [x0, #0x1b]
    // 0xbfb824: DecompressPointer r1
    //     0xbfb824: add             x1, x1, HEAP, lsl #32
    // 0xbfb828: tbnz            w1, #4, #0xbfb83c
    // 0xbfb82c: r0 = Null
    //     0xbfb82c: mov             x0, NULL
    // 0xbfb830: LeaveFrame
    //     0xbfb830: mov             SP, fp
    //     0xbfb834: ldp             fp, lr, [SP], #0x10
    // 0xbfb838: ret
    //     0xbfb838: ret             
    // 0xbfb83c: r1 = true
    //     0xbfb83c: add             x1, NULL, #0x20  ; true
    // 0xbfb840: StoreField: r0->field_1b = r1
    //     0xbfb840: stur            w1, [x0, #0x1b]
    // 0xbfb844: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xbfb844: ldur            w2, [x0, #0x17]
    // 0xbfb848: DecompressPointer r2
    //     0xbfb848: add             x2, x2, HEAP, lsl #32
    // 0xbfb84c: stur            x2, [fp, #-0x18]
    // 0xbfb850: cmp             w2, NULL
    // 0xbfb854: b.eq            #0xbfb8f8
    // 0xbfb858: LoadField: r1 = r0->field_1f
    //     0xbfb858: ldur            w1, [x0, #0x1f]
    // 0xbfb85c: DecompressPointer r1
    //     0xbfb85c: add             x1, x1, HEAP, lsl #32
    // 0xbfb860: cmp             w1, NULL
    // 0xbfb864: b.eq            #0xbfb8f8
    // 0xbfb868: tbnz            w1, #4, #0xbfb8f8
    // 0xbfb86c: LoadField: r3 = r2->field_1f
    //     0xbfb86c: ldur            w3, [x2, #0x1f]
    // 0xbfb870: DecompressPointer r3
    //     0xbfb870: add             x3, x3, HEAP, lsl #32
    // 0xbfb874: stur            x3, [fp, #-0x10]
    // 0xbfb878: LoadField: r1 = r3->field_b
    //     0xbfb878: ldur            w1, [x3, #0xb]
    // 0xbfb87c: LoadField: r4 = r3->field_f
    //     0xbfb87c: ldur            w4, [x3, #0xf]
    // 0xbfb880: DecompressPointer r4
    //     0xbfb880: add             x4, x4, HEAP, lsl #32
    // 0xbfb884: LoadField: r5 = r4->field_b
    //     0xbfb884: ldur            w5, [x4, #0xb]
    // 0xbfb888: r4 = LoadInt32Instr(r1)
    //     0xbfb888: sbfx            x4, x1, #1, #0x1f
    // 0xbfb88c: stur            x4, [fp, #-8]
    // 0xbfb890: r1 = LoadInt32Instr(r5)
    //     0xbfb890: sbfx            x1, x5, #1, #0x1f
    // 0xbfb894: cmp             x4, x1
    // 0xbfb898: b.ne            #0xbfb8a4
    // 0xbfb89c: mov             x1, x3
    // 0xbfb8a0: r0 = _growToNextCapacity()
    //     0xbfb8a0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbfb8a4: ldur            x0, [fp, #-0x10]
    // 0xbfb8a8: ldur            x2, [fp, #-8]
    // 0xbfb8ac: add             x1, x2, #1
    // 0xbfb8b0: lsl             x3, x1, #1
    // 0xbfb8b4: StoreField: r0->field_b = r3
    //     0xbfb8b4: stur            w3, [x0, #0xb]
    // 0xbfb8b8: LoadField: r1 = r0->field_f
    //     0xbfb8b8: ldur            w1, [x0, #0xf]
    // 0xbfb8bc: DecompressPointer r1
    //     0xbfb8bc: add             x1, x1, HEAP, lsl #32
    // 0xbfb8c0: ldur            x0, [fp, #-0x20]
    // 0xbfb8c4: ArrayStore: r1[r2] = r0  ; List_4
    //     0xbfb8c4: add             x25, x1, x2, lsl #2
    //     0xbfb8c8: add             x25, x25, #0xf
    //     0xbfb8cc: str             w0, [x25]
    //     0xbfb8d0: tbz             w0, #0, #0xbfb8ec
    //     0xbfb8d4: ldurb           w16, [x1, #-1]
    //     0xbfb8d8: ldurb           w17, [x0, #-1]
    //     0xbfb8dc: and             x16, x17, x16, lsr #2
    //     0xbfb8e0: tst             x16, HEAP, lsr #32
    //     0xbfb8e4: b.eq            #0xbfb8ec
    //     0xbfb8e8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbfb8ec: ldur            x1, [fp, #-0x18]
    // 0xbfb8f0: r0 = requestVisualUpdate()
    //     0xbfb8f0: bl              #0x837988  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0xbfb8f4: b               #0xbfb92c
    // 0xbfb8f8: ldur            x2, [fp, #-0x20]
    // 0xbfb8fc: r0 = LoadClassIdInstr(r2)
    //     0xbfb8fc: ldur            x0, [x2, #-1]
    //     0xbfb900: ubfx            x0, x0, #0xc, #0x14
    // 0xbfb904: mov             x1, x2
    // 0xbfb908: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xbfb908: mov             x17, #0xfc0
    //     0xbfb90c: movk            x17, #1, lsl #16
    //     0xbfb910: add             lr, x0, x17
    //     0xbfb914: ldr             lr, [x21, lr, lsl #3]
    //     0xbfb918: blr             lr
    // 0xbfb91c: cmp             w0, NULL
    // 0xbfb920: b.eq            #0xbfb92c
    // 0xbfb924: ldur            x1, [fp, #-0x20]
    // 0xbfb928: r0 = markParentNeedsLayout()
    //     0xbfb928: bl              #0xbfb594  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0xbfb92c: r0 = Null
    //     0xbfb92c: mov             x0, NULL
    // 0xbfb930: LeaveFrame
    //     0xbfb930: mov             SP, fp
    //     0xbfb934: ldp             fp, lr, [SP], #0x10
    // 0xbfb938: ret
    //     0xbfb938: ret             
    // 0xbfb93c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb93c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb940: b               #0xbfb820
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc04c8c, size: 0x40
    // 0xc04c8c: EnterFrame
    //     0xc04c8c: stp             fp, lr, [SP, #-0x10]!
    //     0xc04c90: mov             fp, SP
    // 0xc04c94: CheckStackOverflow
    //     0xc04c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc04c98: cmp             SP, x16
    //     0xc04c9c: b.ls            #0xc04cc4
    // 0xc04ca0: LoadField: r0 = r1->field_2f
    //     0xc04ca0: ldur            w0, [x1, #0x2f]
    // 0xc04ca4: DecompressPointer r0
    //     0xc04ca4: add             x0, x0, HEAP, lsl #32
    // 0xc04ca8: mov             x1, x0
    // 0xc04cac: r2 = Null
    //     0xc04cac: mov             x2, NULL
    // 0xc04cb0: r0 = layer=()
    //     0xc04cb0: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc04cb4: r0 = Null
    //     0xc04cb4: mov             x0, NULL
    // 0xc04cb8: LeaveFrame
    //     0xc04cb8: mov             SP, fp
    //     0xc04cbc: ldp             fp, lr, [SP], #0x10
    // 0xc04cc0: ret
    //     0xc04cc0: ret             
    // 0xc04cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc04cc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc04cc8: b               #0xc04ca0
  }
  _ adoptChild(/* No info */) {
    // ** addr: 0xc05494, size: 0xf0
    // 0xc05494: EnterFrame
    //     0xc05494: stp             fp, lr, [SP, #-0x10]!
    //     0xc05498: mov             fp, SP
    // 0xc0549c: AllocStack(0x10)
    //     0xc0549c: sub             SP, SP, #0x10
    // 0xc054a0: SetupParameters(RenderObject this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xc054a0: mov             x4, x1
    //     0xc054a4: mov             x3, x2
    //     0xc054a8: stur            x1, [fp, #-8]
    //     0xc054ac: stur            x2, [fp, #-0x10]
    // 0xc054b0: CheckStackOverflow
    //     0xc054b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc054b4: cmp             SP, x16
    //     0xc054b8: b.ls            #0xc0557c
    // 0xc054bc: r0 = LoadClassIdInstr(r4)
    //     0xc054bc: ldur            x0, [x4, #-1]
    //     0xc054c0: ubfx            x0, x0, #0xc, #0x14
    // 0xc054c4: mov             x1, x4
    // 0xc054c8: mov             x2, x3
    // 0xc054cc: r0 = GDT[cid_x0 + 0xf2af]()
    //     0xc054cc: mov             x17, #0xf2af
    //     0xc054d0: add             lr, x0, x17
    //     0xc054d4: ldr             lr, [x21, lr, lsl #3]
    //     0xc054d8: blr             lr
    // 0xc054dc: ldur            x2, [fp, #-8]
    // 0xc054e0: r0 = LoadClassIdInstr(r2)
    //     0xc054e0: ldur            x0, [x2, #-1]
    //     0xc054e4: ubfx            x0, x0, #0xc, #0x14
    // 0xc054e8: mov             x1, x2
    // 0xc054ec: r0 = GDT[cid_x0 + 0xfc6d]()
    //     0xc054ec: mov             x17, #0xfc6d
    //     0xc054f0: add             lr, x0, x17
    //     0xc054f4: ldr             lr, [x21, lr, lsl #3]
    //     0xc054f8: blr             lr
    // 0xc054fc: ldur            x1, [fp, #-8]
    // 0xc05500: r0 = markNeedsCompositingBitsUpdate()
    //     0xc05500: bl              #0x8395c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0xc05504: ldur            x1, [fp, #-8]
    // 0xc05508: r0 = markNeedsSemanticsUpdate()
    //     0xc05508: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xc0550c: ldur            x0, [fp, #-8]
    // 0xc05510: ldur            x3, [fp, #-0x10]
    // 0xc05514: StoreField: r3->field_13 = r0
    //     0xc05514: stur            w0, [x3, #0x13]
    //     0xc05518: ldurb           w16, [x3, #-1]
    //     0xc0551c: ldurb           w17, [x0, #-1]
    //     0xc05520: and             x16, x17, x16, lsr #2
    //     0xc05524: tst             x16, HEAP, lsr #32
    //     0xc05528: b.eq            #0xc05530
    //     0xc0552c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc05530: ldur            x4, [fp, #-8]
    // 0xc05534: ArrayLoad: r2 = r4[0]  ; List_4
    //     0xc05534: ldur            w2, [x4, #0x17]
    // 0xc05538: DecompressPointer r2
    //     0xc05538: add             x2, x2, HEAP, lsl #32
    // 0xc0553c: cmp             w2, NULL
    // 0xc05540: b.eq            #0xc05560
    // 0xc05544: r0 = LoadClassIdInstr(r3)
    //     0xc05544: ldur            x0, [x3, #-1]
    //     0xc05548: ubfx            x0, x0, #0xc, #0x14
    // 0xc0554c: mov             x1, x3
    // 0xc05550: r0 = GDT[cid_x0 + 0xf4f5]()
    //     0xc05550: mov             x17, #0xf4f5
    //     0xc05554: add             lr, x0, x17
    //     0xc05558: ldr             lr, [x21, lr, lsl #3]
    //     0xc0555c: blr             lr
    // 0xc05560: ldur            x1, [fp, #-8]
    // 0xc05564: ldur            x2, [fp, #-0x10]
    // 0xc05568: r0 = redepthChild()
    //     0xc05568: bl              #0xc05584  ; [package:flutter/src/rendering/object.dart] RenderObject::redepthChild
    // 0xc0556c: r0 = Null
    //     0xc0556c: mov             x0, NULL
    // 0xc05570: LeaveFrame
    //     0xc05570: mov             SP, fp
    //     0xc05574: ldp             fp, lr, [SP], #0x10
    // 0xc05578: ret
    //     0xc05578: ret             
    // 0xc0557c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0557c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05580: b               #0xc054bc
  }
  _ redepthChild(/* No info */) {
    // ** addr: 0xc05584, size: 0x64
    // 0xc05584: EnterFrame
    //     0xc05584: stp             fp, lr, [SP, #-0x10]!
    //     0xc05588: mov             fp, SP
    // 0xc0558c: mov             x0, x1
    // 0xc05590: mov             x1, x2
    // 0xc05594: CheckStackOverflow
    //     0xc05594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05598: cmp             SP, x16
    //     0xc0559c: b.ls            #0xc055e0
    // 0xc055a0: LoadField: r2 = r1->field_b
    //     0xc055a0: ldur            x2, [x1, #0xb]
    // 0xc055a4: LoadField: r3 = r0->field_b
    //     0xc055a4: ldur            x3, [x0, #0xb]
    // 0xc055a8: cmp             x2, x3
    // 0xc055ac: b.gt            #0xc055d0
    // 0xc055b0: add             x0, x3, #1
    // 0xc055b4: StoreField: r1->field_b = r0
    //     0xc055b4: stur            x0, [x1, #0xb]
    // 0xc055b8: r0 = LoadClassIdInstr(r1)
    //     0xc055b8: ldur            x0, [x1, #-1]
    //     0xc055bc: ubfx            x0, x0, #0xc, #0x14
    // 0xc055c0: r0 = GDT[cid_x0 + 0xf18c]()
    //     0xc055c0: mov             x17, #0xf18c
    //     0xc055c4: add             lr, x0, x17
    //     0xc055c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc055cc: blr             lr
    // 0xc055d0: r0 = Null
    //     0xc055d0: mov             x0, NULL
    // 0xc055d4: LeaveFrame
    //     0xc055d4: mov             SP, fp
    //     0xc055d8: ldp             fp, lr, [SP], #0x10
    // 0xc055dc: ret
    //     0xc055dc: ret             
    // 0xc055e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc055e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc055e4: b               #0xc055a0
  }
  [closure] void redepthChild(dynamic, RenderObject) {
    // ** addr: 0xc055e8, size: 0x3c
    // 0xc055e8: EnterFrame
    //     0xc055e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc055ec: mov             fp, SP
    // 0xc055f0: ldr             x0, [fp, #0x18]
    // 0xc055f4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc055f4: ldur            w1, [x0, #0x17]
    // 0xc055f8: DecompressPointer r1
    //     0xc055f8: add             x1, x1, HEAP, lsl #32
    // 0xc055fc: CheckStackOverflow
    //     0xc055fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05600: cmp             SP, x16
    //     0xc05604: b.ls            #0xc0561c
    // 0xc05608: ldr             x2, [fp, #0x10]
    // 0xc0560c: r0 = redepthChild()
    //     0xc0560c: bl              #0xc05584  ; [package:flutter/src/rendering/object.dart] RenderObject::redepthChild
    // 0xc05610: LeaveFrame
    //     0xc05610: mov             SP, fp
    //     0xc05614: ldp             fp, lr, [SP], #0x10
    // 0xc05618: ret
    //     0xc05618: ret             
    // 0xc0561c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0561c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05620: b               #0xc05608
  }
  _ markNeedsCompositedLayerUpdate(/* No info */) {
    // ** addr: 0xc05908, size: 0x170
    // 0xc05908: EnterFrame
    //     0xc05908: stp             fp, lr, [SP, #-0x10]!
    //     0xc0590c: mov             fp, SP
    // 0xc05910: AllocStack(0x18)
    //     0xc05910: sub             SP, SP, #0x18
    // 0xc05914: SetupParameters(RenderObject this /* r1 => r2, fp-0x8 */)
    //     0xc05914: mov             x2, x1
    //     0xc05918: stur            x1, [fp, #-8]
    // 0xc0591c: CheckStackOverflow
    //     0xc0591c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05920: cmp             SP, x16
    //     0xc05924: b.ls            #0xc05a64
    // 0xc05928: LoadField: r0 = r2->field_3f
    //     0xc05928: ldur            w0, [x2, #0x3f]
    // 0xc0592c: DecompressPointer r0
    //     0xc0592c: add             x0, x0, HEAP, lsl #32
    // 0xc05930: tbz             w0, #4, #0xc05940
    // 0xc05934: LoadField: r0 = r2->field_3b
    //     0xc05934: ldur            w0, [x2, #0x3b]
    // 0xc05938: DecompressPointer r0
    //     0xc05938: add             x0, x0, HEAP, lsl #32
    // 0xc0593c: tbnz            w0, #4, #0xc05950
    // 0xc05940: r0 = Null
    //     0xc05940: mov             x0, NULL
    // 0xc05944: LeaveFrame
    //     0xc05944: mov             SP, fp
    //     0xc05948: ldp             fp, lr, [SP], #0x10
    // 0xc0594c: ret
    //     0xc0594c: ret             
    // 0xc05950: r0 = true
    //     0xc05950: add             x0, NULL, #0x20  ; true
    // 0xc05954: StoreField: r2->field_3f = r0
    //     0xc05954: stur            w0, [x2, #0x3f]
    // 0xc05958: r0 = LoadClassIdInstr(r2)
    //     0xc05958: ldur            x0, [x2, #-1]
    //     0xc0595c: ubfx            x0, x0, #0xc, #0x14
    // 0xc05960: mov             x1, x2
    // 0xc05964: r0 = GDT[cid_x0 + 0xfd90]()
    //     0xc05964: mov             x17, #0xfd90
    //     0xc05968: add             lr, x0, x17
    //     0xc0596c: ldr             lr, [x21, lr, lsl #3]
    //     0xc05970: blr             lr
    // 0xc05974: tbnz            w0, #4, #0xc05a48
    // 0xc05978: ldur            x0, [fp, #-8]
    // 0xc0597c: LoadField: r1 = r0->field_2b
    //     0xc0597c: ldur            w1, [x0, #0x2b]
    // 0xc05980: DecompressPointer r1
    //     0xc05980: add             x1, x1, HEAP, lsl #32
    // 0xc05984: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc05988: cmp             w1, w16
    // 0xc0598c: b.eq            #0xc05a6c
    // 0xc05990: tbnz            w1, #4, #0xc05a40
    // 0xc05994: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc05994: ldur            w1, [x0, #0x17]
    // 0xc05998: DecompressPointer r1
    //     0xc05998: add             x1, x1, HEAP, lsl #32
    // 0xc0599c: cmp             w1, NULL
    // 0xc059a0: b.eq            #0xc05a54
    // 0xc059a4: LoadField: r2 = r1->field_27
    //     0xc059a4: ldur            w2, [x1, #0x27]
    // 0xc059a8: DecompressPointer r2
    //     0xc059a8: add             x2, x2, HEAP, lsl #32
    // 0xc059ac: stur            x2, [fp, #-0x18]
    // 0xc059b0: LoadField: r1 = r2->field_b
    //     0xc059b0: ldur            w1, [x2, #0xb]
    // 0xc059b4: LoadField: r3 = r2->field_f
    //     0xc059b4: ldur            w3, [x2, #0xf]
    // 0xc059b8: DecompressPointer r3
    //     0xc059b8: add             x3, x3, HEAP, lsl #32
    // 0xc059bc: LoadField: r4 = r3->field_b
    //     0xc059bc: ldur            w4, [x3, #0xb]
    // 0xc059c0: r3 = LoadInt32Instr(r1)
    //     0xc059c0: sbfx            x3, x1, #1, #0x1f
    // 0xc059c4: stur            x3, [fp, #-0x10]
    // 0xc059c8: r1 = LoadInt32Instr(r4)
    //     0xc059c8: sbfx            x1, x4, #1, #0x1f
    // 0xc059cc: cmp             x3, x1
    // 0xc059d0: b.ne            #0xc059dc
    // 0xc059d4: mov             x1, x2
    // 0xc059d8: r0 = _growToNextCapacity()
    //     0xc059d8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc059dc: ldur            x2, [fp, #-8]
    // 0xc059e0: ldur            x0, [fp, #-0x18]
    // 0xc059e4: ldur            x3, [fp, #-0x10]
    // 0xc059e8: add             x1, x3, #1
    // 0xc059ec: lsl             x4, x1, #1
    // 0xc059f0: StoreField: r0->field_b = r4
    //     0xc059f0: stur            w4, [x0, #0xb]
    // 0xc059f4: LoadField: r1 = r0->field_f
    //     0xc059f4: ldur            w1, [x0, #0xf]
    // 0xc059f8: DecompressPointer r1
    //     0xc059f8: add             x1, x1, HEAP, lsl #32
    // 0xc059fc: mov             x0, x2
    // 0xc05a00: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc05a00: add             x25, x1, x3, lsl #2
    //     0xc05a04: add             x25, x25, #0xf
    //     0xc05a08: str             w0, [x25]
    //     0xc05a0c: tbz             w0, #0, #0xc05a28
    //     0xc05a10: ldurb           w16, [x1, #-1]
    //     0xc05a14: ldurb           w17, [x0, #-1]
    //     0xc05a18: and             x16, x17, x16, lsr #2
    //     0xc05a1c: tst             x16, HEAP, lsr #32
    //     0xc05a20: b.eq            #0xc05a28
    //     0xc05a24: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc05a28: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xc05a28: ldur            w1, [x2, #0x17]
    // 0xc05a2c: DecompressPointer r1
    //     0xc05a2c: add             x1, x1, HEAP, lsl #32
    // 0xc05a30: cmp             w1, NULL
    // 0xc05a34: b.eq            #0xc05a74
    // 0xc05a38: r0 = requestVisualUpdate()
    //     0xc05a38: bl              #0x837988  ; [package:flutter/src/rendering/object.dart] PipelineOwner::requestVisualUpdate
    // 0xc05a3c: b               #0xc05a54
    // 0xc05a40: mov             x2, x0
    // 0xc05a44: b               #0xc05a4c
    // 0xc05a48: ldur            x2, [fp, #-8]
    // 0xc05a4c: mov             x1, x2
    // 0xc05a50: r0 = markNeedsPaint()
    //     0xc05a50: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xc05a54: r0 = Null
    //     0xc05a54: mov             x0, NULL
    // 0xc05a58: LeaveFrame
    //     0xc05a58: mov             SP, fp
    //     0xc05a5c: ldp             fp, lr, [SP], #0x10
    // 0xc05a60: ret
    //     0xc05a60: ret             
    // 0xc05a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05a64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05a68: b               #0xc05928
    // 0xc05a6c: r9 = _wasRepaintBoundary
    //     0xc05a6c: ldr             x9, [PP, #0x2dd8]  ; [pp+0x2dd8] Field <RenderObject._wasRepaintBoundary@30266271>: late (offset: 0x2c)
    // 0xc05a70: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc05a70: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc05a74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc05a74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ layer=(/* No info */) {
    // ** addr: 0xc05e78, size: 0x3c
    // 0xc05e78: EnterFrame
    //     0xc05e78: stp             fp, lr, [SP, #-0x10]!
    //     0xc05e7c: mov             fp, SP
    // 0xc05e80: CheckStackOverflow
    //     0xc05e80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05e84: cmp             SP, x16
    //     0xc05e88: b.ls            #0xc05eac
    // 0xc05e8c: LoadField: r0 = r1->field_2f
    //     0xc05e8c: ldur            w0, [x1, #0x2f]
    // 0xc05e90: DecompressPointer r0
    //     0xc05e90: add             x0, x0, HEAP, lsl #32
    // 0xc05e94: mov             x1, x0
    // 0xc05e98: r0 = layer=()
    //     0xc05e98: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc05e9c: r0 = Null
    //     0xc05e9c: mov             x0, NULL
    // 0xc05ea0: LeaveFrame
    //     0xc05ea0: mov             SP, fp
    //     0xc05ea4: ldp             fp, lr, [SP], #0x10
    // 0xc05ea8: ret
    //     0xc05ea8: ret             
    // 0xc05eac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05eac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05eb0: b               #0xc05e8c
  }
  _ detach(/* No info */) {
    // ** addr: 0xc09564, size: 0xc
    // 0xc09564: ArrayStore: r1[0] = rNULL  ; List_4
    //     0xc09564: stur            NULL, [x1, #0x17]
    // 0xc09568: r0 = Null
    //     0xc09568: mov             x0, NULL
    // 0xc0956c: ret
    //     0xc0956c: ret             
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0d350, size: 0x1a4
    // 0xc0d350: EnterFrame
    //     0xc0d350: stp             fp, lr, [SP, #-0x10]!
    //     0xc0d354: mov             fp, SP
    // 0xc0d358: AllocStack(0x10)
    //     0xc0d358: sub             SP, SP, #0x10
    // 0xc0d35c: SetupParameters(RenderObject this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xc0d35c: mov             x0, x2
    //     0xc0d360: mov             x2, x1
    //     0xc0d364: stur            x1, [fp, #-8]
    // 0xc0d368: CheckStackOverflow
    //     0xc0d368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0d36c: cmp             SP, x16
    //     0xc0d370: b.ls            #0xc0d4ec
    // 0xc0d374: ArrayStore: r2[0] = r0  ; List_4
    //     0xc0d374: stur            w0, [x2, #0x17]
    //     0xc0d378: ldurb           w16, [x2, #-1]
    //     0xc0d37c: ldurb           w17, [x0, #-1]
    //     0xc0d380: and             x16, x17, x16, lsr #2
    //     0xc0d384: tst             x16, HEAP, lsr #32
    //     0xc0d388: b.eq            #0xc0d390
    //     0xc0d38c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc0d390: LoadField: r0 = r2->field_1b
    //     0xc0d390: ldur            w0, [x2, #0x1b]
    // 0xc0d394: DecompressPointer r0
    //     0xc0d394: add             x0, x0, HEAP, lsl #32
    // 0xc0d398: tbnz            w0, #4, #0xc0d3d0
    // 0xc0d39c: LoadField: r0 = r2->field_1f
    //     0xc0d39c: ldur            w0, [x2, #0x1f]
    // 0xc0d3a0: DecompressPointer r0
    //     0xc0d3a0: add             x0, x0, HEAP, lsl #32
    // 0xc0d3a4: cmp             w0, NULL
    // 0xc0d3a8: b.eq            #0xc0d3d0
    // 0xc0d3ac: r3 = false
    //     0xc0d3ac: add             x3, NULL, #0x30  ; false
    // 0xc0d3b0: StoreField: r2->field_1b = r3
    //     0xc0d3b0: stur            w3, [x2, #0x1b]
    // 0xc0d3b4: r0 = LoadClassIdInstr(r2)
    //     0xc0d3b4: ldur            x0, [x2, #-1]
    //     0xc0d3b8: ubfx            x0, x0, #0xc, #0x14
    // 0xc0d3bc: mov             x1, x2
    // 0xc0d3c0: r0 = GDT[cid_x0 + 0xfc6d]()
    //     0xc0d3c0: mov             x17, #0xfc6d
    //     0xc0d3c4: add             lr, x0, x17
    //     0xc0d3c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc0d3cc: blr             lr
    // 0xc0d3d0: ldur            x0, [fp, #-8]
    // 0xc0d3d4: LoadField: r1 = r0->field_33
    //     0xc0d3d4: ldur            w1, [x0, #0x33]
    // 0xc0d3d8: DecompressPointer r1
    //     0xc0d3d8: add             x1, x1, HEAP, lsl #32
    // 0xc0d3dc: tbnz            w1, #4, #0xc0d3f0
    // 0xc0d3e0: r2 = false
    //     0xc0d3e0: add             x2, NULL, #0x30  ; false
    // 0xc0d3e4: StoreField: r0->field_33 = r2
    //     0xc0d3e4: stur            w2, [x0, #0x33]
    // 0xc0d3e8: mov             x1, x0
    // 0xc0d3ec: r0 = markNeedsCompositingBitsUpdate()
    //     0xc0d3ec: bl              #0x8395c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0xc0d3f0: ldur            x2, [fp, #-8]
    // 0xc0d3f4: LoadField: r0 = r2->field_3b
    //     0xc0d3f4: ldur            w0, [x2, #0x3b]
    // 0xc0d3f8: DecompressPointer r0
    //     0xc0d3f8: add             x0, x0, HEAP, lsl #32
    // 0xc0d3fc: tbnz            w0, #4, #0xc0d440
    // 0xc0d400: LoadField: r0 = r2->field_2f
    //     0xc0d400: ldur            w0, [x2, #0x2f]
    // 0xc0d404: DecompressPointer r0
    //     0xc0d404: add             x0, x0, HEAP, lsl #32
    // 0xc0d408: LoadField: r1 = r0->field_b
    //     0xc0d408: ldur            w1, [x0, #0xb]
    // 0xc0d40c: DecompressPointer r1
    //     0xc0d40c: add             x1, x1, HEAP, lsl #32
    // 0xc0d410: cmp             w1, NULL
    // 0xc0d414: b.eq            #0xc0d440
    // 0xc0d418: r0 = false
    //     0xc0d418: add             x0, NULL, #0x30  ; false
    // 0xc0d41c: StoreField: r2->field_3b = r0
    //     0xc0d41c: stur            w0, [x2, #0x3b]
    // 0xc0d420: r0 = LoadClassIdInstr(r2)
    //     0xc0d420: ldur            x0, [x2, #-1]
    //     0xc0d424: ubfx            x0, x0, #0xc, #0x14
    // 0xc0d428: mov             x1, x2
    // 0xc0d42c: r0 = GDT[cid_x0 + 0x10585]()
    //     0xc0d42c: mov             x17, #0x585
    //     0xc0d430: movk            x17, #1, lsl #16
    //     0xc0d434: add             lr, x0, x17
    //     0xc0d438: ldr             lr, [x21, lr, lsl #3]
    //     0xc0d43c: blr             lr
    // 0xc0d440: ldur            x1, [fp, #-8]
    // 0xc0d444: LoadField: r0 = r1->field_43
    //     0xc0d444: ldur            w0, [x1, #0x43]
    // 0xc0d448: DecompressPointer r0
    //     0xc0d448: add             x0, x0, HEAP, lsl #32
    // 0xc0d44c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0d450: cmp             w0, w16
    // 0xc0d454: b.ne            #0xc0d460
    // 0xc0d458: r2 = _semantics
    //     0xc0d458: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0xc0d45c: r0 = InitLateFinalInstanceField()
    //     0xc0d45c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xc0d460: LoadField: r1 = r0->field_3b
    //     0xc0d460: ldur            w1, [x0, #0x3b]
    // 0xc0d464: DecompressPointer r1
    //     0xc0d464: add             x1, x1, HEAP, lsl #32
    // 0xc0d468: LoadField: r0 = r1->field_13
    //     0xc0d468: ldur            w0, [x1, #0x13]
    // 0xc0d46c: DecompressPointer r0
    //     0xc0d46c: add             x0, x0, HEAP, lsl #32
    // 0xc0d470: cmp             w0, NULL
    // 0xc0d474: b.ne            #0xc0d47c
    // 0xc0d478: r0 = original()
    //     0xc0d478: bl              #0x837bc4  ; [package:flutter/src/rendering/object.dart] _SemanticsConfigurationProvider::original
    // 0xc0d47c: LoadField: r1 = r0->field_7
    //     0xc0d47c: ldur            w1, [x0, #7]
    // 0xc0d480: DecompressPointer r1
    //     0xc0d480: add             x1, x1, HEAP, lsl #32
    // 0xc0d484: tbnz            w1, #4, #0xc0d4dc
    // 0xc0d488: ldur            x0, [fp, #-8]
    // 0xc0d48c: LoadField: r2 = r0->field_43
    //     0xc0d48c: ldur            w2, [x0, #0x43]
    // 0xc0d490: DecompressPointer r2
    //     0xc0d490: add             x2, x2, HEAP, lsl #32
    // 0xc0d494: mov             x1, x2
    // 0xc0d498: stur            x2, [fp, #-0x10]
    // 0xc0d49c: r0 = isRoot()
    //     0xc0d49c: bl              #0x837aa0  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::isRoot
    // 0xc0d4a0: tbz             w0, #4, #0xc0d4c0
    // 0xc0d4a4: ldur            x0, [fp, #-0x10]
    // 0xc0d4a8: LoadField: r1 = r0->field_33
    //     0xc0d4a8: ldur            w1, [x0, #0x33]
    // 0xc0d4ac: DecompressPointer r1
    //     0xc0d4ac: add             x1, x1, HEAP, lsl #32
    // 0xc0d4b0: cmp             w1, NULL
    // 0xc0d4b4: b.ne            #0xc0d4c0
    // 0xc0d4b8: ldur            x1, [fp, #-8]
    // 0xc0d4bc: b               #0xc0d4d8
    // 0xc0d4c0: ldur            x1, [fp, #-8]
    // 0xc0d4c4: LoadField: r0 = r1->field_43
    //     0xc0d4c4: ldur            w0, [x1, #0x43]
    // 0xc0d4c8: DecompressPointer r0
    //     0xc0d4c8: add             x0, x0, HEAP, lsl #32
    // 0xc0d4cc: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xc0d4cc: ldur            w2, [x0, #0x17]
    // 0xc0d4d0: DecompressPointer r2
    //     0xc0d4d0: add             x2, x2, HEAP, lsl #32
    // 0xc0d4d4: tbz             w2, #4, #0xc0d4dc
    // 0xc0d4d8: r0 = markNeedsSemanticsUpdate()
    //     0xc0d4d8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xc0d4dc: r0 = Null
    //     0xc0d4dc: mov             x0, NULL
    // 0xc0d4e0: LeaveFrame
    //     0xc0d4e0: mov             SP, fp
    //     0xc0d4e4: ldp             fp, lr, [SP], #0x10
    // 0xc0d4e8: ret
    //     0xc0d4e8: ret             
    // 0xc0d4ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0d4ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0d4f0: b               #0xc0d374
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0ef54, size: 0xac
    // 0xc0ef54: EnterFrame
    //     0xc0ef54: stp             fp, lr, [SP, #-0x10]!
    //     0xc0ef58: mov             fp, SP
    // 0xc0ef5c: AllocStack(0x8)
    //     0xc0ef5c: sub             SP, SP, #8
    // 0xc0ef60: SetupParameters(RenderObject this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0ef60: mov             x0, x2
    //     0xc0ef64: mov             x4, x1
    //     0xc0ef68: mov             x3, x2
    //     0xc0ef6c: stur            x2, [fp, #-8]
    // 0xc0ef70: r2 = Null
    //     0xc0ef70: mov             x2, NULL
    // 0xc0ef74: r1 = Null
    //     0xc0ef74: mov             x1, NULL
    // 0xc0ef78: r4 = 60
    //     0xc0ef78: mov             x4, #0x3c
    // 0xc0ef7c: branchIfSmi(r0, 0xc0ef88)
    //     0xc0ef7c: tbz             w0, #0, #0xc0ef88
    // 0xc0ef80: r4 = LoadClassIdInstr(r0)
    //     0xc0ef80: ldur            x4, [x0, #-1]
    //     0xc0ef84: ubfx            x4, x4, #0xc, #0x14
    // 0xc0ef88: r17 = -4679
    //     0xc0ef88: mov             x17, #-0x1247
    // 0xc0ef8c: add             x4, x4, x17
    // 0xc0ef90: cmp             x4, #0x128
    // 0xc0ef94: b.ls            #0xc0efa8
    // 0xc0ef98: r8 = RenderObject
    //     0xc0ef98: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0xc0ef9c: r3 = Null
    //     0xc0ef9c: add             x3, PP, #0xe, lsl #12  ; [pp+0xe2e8] Null
    //     0xc0efa0: ldr             x3, [x3, #0x2e8]
    // 0xc0efa4: r0 = RenderObject()
    //     0xc0efa4: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0xc0efa8: ldur            x0, [fp, #-8]
    // 0xc0efac: LoadField: r1 = r0->field_7
    //     0xc0efac: ldur            w1, [x0, #7]
    // 0xc0efb0: DecompressPointer r1
    //     0xc0efb0: add             x1, x1, HEAP, lsl #32
    // 0xc0efb4: r2 = LoadClassIdInstr(r1)
    //     0xc0efb4: ldur            x2, [x1, #-1]
    //     0xc0efb8: ubfx            x2, x2, #0xc, #0x14
    // 0xc0efbc: r17 = -4176
    //     0xc0efbc: mov             x17, #-0x1050
    // 0xc0efc0: add             x16, x2, x17
    // 0xc0efc4: cmp             x16, #0x25
    // 0xc0efc8: b.ls            #0xc0eff0
    // 0xc0efcc: r0 = ParentData()
    //     0xc0efcc: bl              #0xc0d7b0  ; AllocateParentDataStub -> ParentData (size=0x8)
    // 0xc0efd0: ldur            x1, [fp, #-8]
    // 0xc0efd4: StoreField: r1->field_7 = r0
    //     0xc0efd4: stur            w0, [x1, #7]
    //     0xc0efd8: ldurb           w16, [x1, #-1]
    //     0xc0efdc: ldurb           w17, [x0, #-1]
    //     0xc0efe0: and             x16, x17, x16, lsr #2
    //     0xc0efe4: tst             x16, HEAP, lsr #32
    //     0xc0efe8: b.eq            #0xc0eff0
    //     0xc0efec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0eff0: r0 = Null
    //     0xc0eff0: mov             x0, NULL
    // 0xc0eff4: LeaveFrame
    //     0xc0eff4: mov             SP, fp
    //     0xc0eff8: ldp             fp, lr, [SP], #0x10
    // 0xc0effc: ret
    //     0xc0effc: ret             
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0xc158c4, size: 0x48
    // 0xc158c4: EnterFrame
    //     0xc158c4: stp             fp, lr, [SP, #-0x10]!
    //     0xc158c8: mov             fp, SP
    // 0xc158cc: AllocStack(0x8)
    //     0xc158cc: sub             SP, SP, #8
    // 0xc158d0: SetupParameters(RenderObject this /* r1 => r0 */, dynamic _ /* r2 => r1 */, dynamic _ /* r3 => r2 */)
    //     0xc158d0: mov             x0, x1
    //     0xc158d4: mov             x1, x2
    //     0xc158d8: mov             x2, x3
    // 0xc158dc: CheckStackOverflow
    //     0xc158dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc158e0: cmp             SP, x16
    //     0xc158e4: b.ls            #0xc15904
    // 0xc158e8: str             x5, [SP]
    // 0xc158ec: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xc158ec: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xc158f0: r0 = updateWith()
    //     0xc158f0: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc158f4: r0 = Null
    //     0xc158f4: mov             x0, NULL
    // 0xc158f8: LeaveFrame
    //     0xc158f8: mov             SP, fp
    //     0xc158fc: ldp             fp, lr, [SP], #0x10
    // 0xc15900: ret
    //     0xc15900: ret             
    // 0xc15904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc15904: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc15908: b               #0xc158e8
  }
  _ reassemble(/* No info */) {
    // ** addr: 0xc1661c, size: 0xc4
    // 0xc1661c: EnterFrame
    //     0xc1661c: stp             fp, lr, [SP, #-0x10]!
    //     0xc16620: mov             fp, SP
    // 0xc16624: AllocStack(0x8)
    //     0xc16624: sub             SP, SP, #8
    // 0xc16628: SetupParameters(RenderObject this /* r1 => r2, fp-0x8 */)
    //     0xc16628: mov             x2, x1
    //     0xc1662c: stur            x1, [fp, #-8]
    // 0xc16630: CheckStackOverflow
    //     0xc16630: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16634: cmp             SP, x16
    //     0xc16638: b.ls            #0xc166d8
    // 0xc1663c: r0 = LoadClassIdInstr(r2)
    //     0xc1663c: ldur            x0, [x2, #-1]
    //     0xc16640: ubfx            x0, x0, #0xc, #0x14
    // 0xc16644: mov             x1, x2
    // 0xc16648: r0 = GDT[cid_x0 + 0xfc6d]()
    //     0xc16648: mov             x17, #0xfc6d
    //     0xc1664c: add             lr, x0, x17
    //     0xc16650: ldr             lr, [x21, lr, lsl #3]
    //     0xc16654: blr             lr
    // 0xc16658: ldur            x1, [fp, #-8]
    // 0xc1665c: r0 = markNeedsCompositingBitsUpdate()
    //     0xc1665c: bl              #0x8395c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsCompositingBitsUpdate
    // 0xc16660: ldur            x2, [fp, #-8]
    // 0xc16664: r0 = LoadClassIdInstr(r2)
    //     0xc16664: ldur            x0, [x2, #-1]
    //     0xc16668: ubfx            x0, x0, #0xc, #0x14
    // 0xc1666c: mov             x1, x2
    // 0xc16670: r0 = GDT[cid_x0 + 0x10585]()
    //     0xc16670: mov             x17, #0x585
    //     0xc16674: movk            x17, #1, lsl #16
    //     0xc16678: add             lr, x0, x17
    //     0xc1667c: ldr             lr, [x21, lr, lsl #3]
    //     0xc16680: blr             lr
    // 0xc16684: ldur            x1, [fp, #-8]
    // 0xc16688: r0 = markNeedsSemanticsUpdate()
    //     0xc16688: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xc1668c: r1 = Function '<anonymous closure>':.
    //     0xc1668c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcad0] AnonymousClosure: (0x839784), in [package:flutter/src/rendering/object.dart] RenderObject::reassemble (0xc1661c)
    //     0xc16690: ldr             x1, [x1, #0xad0]
    // 0xc16694: r2 = Null
    //     0xc16694: mov             x2, NULL
    // 0xc16698: r0 = AllocateClosure()
    //     0xc16698: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1669c: ldur            x1, [fp, #-8]
    // 0xc166a0: r2 = LoadClassIdInstr(r1)
    //     0xc166a0: ldur            x2, [x1, #-1]
    //     0xc166a4: ubfx            x2, x2, #0xc, #0x14
    // 0xc166a8: mov             x16, x0
    // 0xc166ac: mov             x0, x2
    // 0xc166b0: mov             x2, x16
    // 0xc166b4: r0 = GDT[cid_x0 + 0x10a11]()
    //     0xc166b4: mov             x17, #0xa11
    //     0xc166b8: movk            x17, #1, lsl #16
    //     0xc166bc: add             lr, x0, x17
    //     0xc166c0: ldr             lr, [x21, lr, lsl #3]
    //     0xc166c4: blr             lr
    // 0xc166c8: r0 = Null
    //     0xc166c8: mov             x0, NULL
    // 0xc166cc: LeaveFrame
    //     0xc166cc: mov             SP, fp
    //     0xc166d0: ldp             fp, lr, [SP], #0x10
    // 0xc166d4: ret
    //     0xc166d4: ret             
    // 0xc166d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc166d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc166dc: b               #0xc1663c
  }
  _ layout(/* No info */) {
    // ** addr: 0xcd00ac, size: 0x3b0
    // 0xcd00ac: EnterFrame
    //     0xcd00ac: stp             fp, lr, [SP, #-0x10]!
    //     0xcd00b0: mov             fp, SP
    // 0xcd00b4: AllocStack(0xa0)
    //     0xcd00b4: sub             SP, SP, #0xa0
    // 0xcd00b8: SetupParameters(RenderObject this /* r1 => r3, fp-0x80 */, dynamic _ /* r2 => r2, fp-0x88 */, {dynamic parentUsesSize = false /* r0 */})
    //     0xcd00b8: mov             x3, x1
    //     0xcd00bc: stur            x1, [fp, #-0x80]
    //     0xcd00c0: stur            x2, [fp, #-0x88]
    //     0xcd00c4: ldur            w0, [x4, #0x13]
    //     0xcd00c8: ldur            w1, [x4, #0x1f]
    //     0xcd00cc: add             x1, x1, HEAP, lsl #32
    //     0xcd00d0: add             x16, PP, #0x10, lsl #12  ; [pp+0x10fa8] "parentUsesSize"
    //     0xcd00d4: ldr             x16, [x16, #0xfa8]
    //     0xcd00d8: cmp             w1, w16
    //     0xcd00dc: b.ne            #0xcd00f8
    //     0xcd00e0: ldur            w1, [x4, #0x23]
    //     0xcd00e4: add             x1, x1, HEAP, lsl #32
    //     0xcd00e8: sub             w4, w0, w1
    //     0xcd00ec: add             x0, fp, w4, sxtw #2
    //     0xcd00f0: ldr             x0, [x0, #8]
    //     0xcd00f4: b               #0xcd00fc
    //     0xcd00f8: add             x0, NULL, #0x30  ; false
    // 0xcd00fc: CheckStackOverflow
    //     0xcd00fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd0100: cmp             SP, x16
    //     0xcd0104: b.ls            #0xcd0454
    // 0xcd0108: tbnz            w0, #4, #0xcd0170
    // 0xcd010c: r0 = LoadClassIdInstr(r3)
    //     0xcd010c: ldur            x0, [x3, #-1]
    //     0xcd0110: ubfx            x0, x0, #0xc, #0x14
    // 0xcd0114: mov             x1, x3
    // 0xcd0118: r0 = GDT[cid_x0 + 0x11206]()
    //     0xcd0118: mov             x17, #0x1206
    //     0xcd011c: movk            x17, #1, lsl #16
    //     0xcd0120: add             lr, x0, x17
    //     0xcd0124: ldr             lr, [x21, lr, lsl #3]
    //     0xcd0128: blr             lr
    // 0xcd012c: tbnz            w0, #4, #0xcd0138
    // 0xcd0130: ldur            x2, [fp, #-0x88]
    // 0xcd0134: b               #0xcd0170
    // 0xcd0138: ldur            x2, [fp, #-0x88]
    // 0xcd013c: r0 = LoadClassIdInstr(r2)
    //     0xcd013c: ldur            x0, [x2, #-1]
    //     0xcd0140: ubfx            x0, x0, #0xc, #0x14
    // 0xcd0144: sub             x16, x0, #0xb46
    // 0xcd0148: cmp             x16, #1
    // 0xcd014c: b.hi            #0xcd0178
    // 0xcd0150: LoadField: d0 = r2->field_7
    //     0xcd0150: ldur            d0, [x2, #7]
    // 0xcd0154: LoadField: d1 = r2->field_f
    //     0xcd0154: ldur            d1, [x2, #0xf]
    // 0xcd0158: fcmp            d0, d1
    // 0xcd015c: b.lt            #0xcd0178
    // 0xcd0160: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xcd0160: ldur            d0, [x2, #0x17]
    // 0xcd0164: LoadField: d1 = r2->field_1f
    //     0xcd0164: ldur            d1, [x2, #0x1f]
    // 0xcd0168: fcmp            d0, d1
    // 0xcd016c: b.lt            #0xcd0178
    // 0xcd0170: r0 = true
    //     0xcd0170: add             x0, NULL, #0x20  ; true
    // 0xcd0174: b               #0xcd01b0
    // 0xcd0178: ldur            x3, [fp, #-0x80]
    // 0xcd017c: r0 = LoadClassIdInstr(r3)
    //     0xcd017c: ldur            x0, [x3, #-1]
    //     0xcd0180: ubfx            x0, x0, #0xc, #0x14
    // 0xcd0184: mov             x1, x3
    // 0xcd0188: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xcd0188: mov             x17, #0xfc0
    //     0xcd018c: movk            x17, #1, lsl #16
    //     0xcd0190: add             lr, x0, x17
    //     0xcd0194: ldr             lr, [x21, lr, lsl #3]
    //     0xcd0198: blr             lr
    // 0xcd019c: cmp             w0, NULL
    // 0xcd01a0: r16 = true
    //     0xcd01a0: add             x16, NULL, #0x20  ; true
    // 0xcd01a4: r17 = false
    //     0xcd01a4: add             x17, NULL, #0x30  ; false
    // 0xcd01a8: csel            x1, x16, x17, eq
    // 0xcd01ac: mov             x0, x1
    // 0xcd01b0: ldur            x1, [fp, #-0x80]
    // 0xcd01b4: StoreField: r1->field_1f = r0
    //     0xcd01b4: stur            w0, [x1, #0x1f]
    // 0xcd01b8: LoadField: r0 = r1->field_1b
    //     0xcd01b8: ldur            w0, [x1, #0x1b]
    // 0xcd01bc: DecompressPointer r0
    //     0xcd01bc: add             x0, x0, HEAP, lsl #32
    // 0xcd01c0: tbz             w0, #4, #0xcd0310
    // 0xcd01c4: ldur            x0, [fp, #-0x88]
    // 0xcd01c8: LoadField: r2 = r1->field_27
    //     0xcd01c8: ldur            w2, [x1, #0x27]
    // 0xcd01cc: DecompressPointer r2
    //     0xcd01cc: add             x2, x2, HEAP, lsl #32
    // 0xcd01d0: stur            x2, [fp, #-0x90]
    // 0xcd01d4: r3 = LoadClassIdInstr(r0)
    //     0xcd01d4: ldur            x3, [x0, #-1]
    //     0xcd01d8: ubfx            x3, x3, #0xc, #0x14
    // 0xcd01dc: cmp             x3, #0xb46
    // 0xcd01e0: b.ne            #0xcd0268
    // 0xcd01e4: cmp             w2, NULL
    // 0xcd01e8: b.eq            #0xcd0310
    // 0xcd01ec: cmp             w0, w2
    // 0xcd01f0: b.eq            #0xcd0300
    // 0xcd01f4: stp             x0, x2, [SP]
    // 0xcd01f8: r0 = _haveSameRuntimeType()
    //     0xcd01f8: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0xcd01fc: tbnz            w0, #4, #0xcd0310
    // 0xcd0200: ldur            x0, [fp, #-0x90]
    // 0xcd0204: r1 = LoadClassIdInstr(r0)
    //     0xcd0204: ldur            x1, [x0, #-1]
    //     0xcd0208: ubfx            x1, x1, #0xc, #0x14
    // 0xcd020c: sub             x16, x1, #0xb46
    // 0xcd0210: cmp             x16, #1
    // 0xcd0214: b.hi            #0xcd0260
    // 0xcd0218: ldur            x1, [fp, #-0x88]
    // 0xcd021c: LoadField: d0 = r0->field_7
    //     0xcd021c: ldur            d0, [x0, #7]
    // 0xcd0220: LoadField: d1 = r1->field_7
    //     0xcd0220: ldur            d1, [x1, #7]
    // 0xcd0224: fcmp            d0, d1
    // 0xcd0228: b.ne            #0xcd0310
    // 0xcd022c: LoadField: d0 = r0->field_f
    //     0xcd022c: ldur            d0, [x0, #0xf]
    // 0xcd0230: LoadField: d1 = r1->field_f
    //     0xcd0230: ldur            d1, [x1, #0xf]
    // 0xcd0234: fcmp            d0, d1
    // 0xcd0238: b.ne            #0xcd0310
    // 0xcd023c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xcd023c: ldur            d0, [x0, #0x17]
    // 0xcd0240: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xcd0240: ldur            d1, [x1, #0x17]
    // 0xcd0244: fcmp            d0, d1
    // 0xcd0248: b.ne            #0xcd0310
    // 0xcd024c: LoadField: d0 = r0->field_1f
    //     0xcd024c: ldur            d0, [x0, #0x1f]
    // 0xcd0250: LoadField: d1 = r1->field_1f
    //     0xcd0250: ldur            d1, [x1, #0x1f]
    // 0xcd0254: fcmp            d0, d1
    // 0xcd0258: b.ne            #0xcd0310
    // 0xcd025c: b               #0xcd0300
    // 0xcd0260: ldur            x1, [fp, #-0x88]
    // 0xcd0264: b               #0xcd0310
    // 0xcd0268: mov             x1, x0
    // 0xcd026c: mov             x0, x2
    // 0xcd0270: cmp             x3, #0xb47
    // 0xcd0274: b.ne            #0xcd02e0
    // 0xcd0278: cmp             w0, NULL
    // 0xcd027c: b.eq            #0xcd0310
    // 0xcd0280: stp             x0, x1, [SP]
    // 0xcd0284: r0 = ==()
    //     0xcd0284: bl              #0x1299aec  ; [package:flutter/src/rendering/box.dart] BoxConstraints::==
    // 0xcd0288: tbnz            w0, #4, #0xcd0310
    // 0xcd028c: ldur            x0, [fp, #-0x90]
    // 0xcd0290: r1 = LoadClassIdInstr(r0)
    //     0xcd0290: ldur            x1, [x0, #-1]
    //     0xcd0294: ubfx            x1, x1, #0xc, #0x14
    // 0xcd0298: cmp             x1, #0xb47
    // 0xcd029c: b.ne            #0xcd02d8
    // 0xcd02a0: ldur            x1, [fp, #-0x88]
    // 0xcd02a4: LoadField: d0 = r0->field_37
    //     0xcd02a4: ldur            d0, [x0, #0x37]
    // 0xcd02a8: LoadField: d1 = r1->field_37
    //     0xcd02a8: ldur            d1, [x1, #0x37]
    // 0xcd02ac: fcmp            d0, d1
    // 0xcd02b0: b.ne            #0xcd0310
    // 0xcd02b4: LoadField: d0 = r0->field_27
    //     0xcd02b4: ldur            d0, [x0, #0x27]
    // 0xcd02b8: LoadField: d1 = r1->field_27
    //     0xcd02b8: ldur            d1, [x1, #0x27]
    // 0xcd02bc: fcmp            d0, d1
    // 0xcd02c0: b.ne            #0xcd0310
    // 0xcd02c4: LoadField: d0 = r0->field_2f
    //     0xcd02c4: ldur            d0, [x0, #0x2f]
    // 0xcd02c8: LoadField: d1 = r1->field_2f
    //     0xcd02c8: ldur            d1, [x1, #0x2f]
    // 0xcd02cc: fcmp            d0, d1
    // 0xcd02d0: b.ne            #0xcd0310
    // 0xcd02d4: b               #0xcd0300
    // 0xcd02d8: ldur            x1, [fp, #-0x88]
    // 0xcd02dc: b               #0xcd0310
    // 0xcd02e0: r2 = LoadClassIdInstr(r1)
    //     0xcd02e0: ldur            x2, [x1, #-1]
    //     0xcd02e4: ubfx            x2, x2, #0xc, #0x14
    // 0xcd02e8: stp             x0, x1, [SP]
    // 0xcd02ec: mov             x0, x2
    // 0xcd02f0: mov             lr, x0
    // 0xcd02f4: ldr             lr, [x21, lr, lsl #3]
    // 0xcd02f8: blr             lr
    // 0xcd02fc: tbnz            w0, #4, #0xcd0310
    // 0xcd0300: r0 = Null
    //     0xcd0300: mov             x0, NULL
    // 0xcd0304: LeaveFrame
    //     0xcd0304: mov             SP, fp
    //     0xcd0308: ldp             fp, lr, [SP], #0x10
    // 0xcd030c: ret
    //     0xcd030c: ret             
    // 0xcd0310: ldur            x2, [fp, #-0x80]
    // 0xcd0314: ldur            x0, [fp, #-0x88]
    // 0xcd0318: StoreField: r2->field_27 = r0
    //     0xcd0318: stur            w0, [x2, #0x27]
    //     0xcd031c: ldurb           w16, [x2, #-1]
    //     0xcd0320: ldurb           w17, [x0, #-1]
    //     0xcd0324: and             x16, x17, x16, lsr #2
    //     0xcd0328: tst             x16, HEAP, lsr #32
    //     0xcd032c: b.eq            #0xcd0334
    //     0xcd0330: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcd0334: r0 = LoadClassIdInstr(r2)
    //     0xcd0334: ldur            x0, [x2, #-1]
    //     0xcd0338: ubfx            x0, x0, #0xc, #0x14
    // 0xcd033c: mov             x1, x2
    // 0xcd0340: r0 = GDT[cid_x0 + 0x11206]()
    //     0xcd0340: mov             x17, #0x1206
    //     0xcd0344: movk            x17, #1, lsl #16
    //     0xcd0348: add             lr, x0, x17
    //     0xcd034c: ldr             lr, [x21, lr, lsl #3]
    //     0xcd0350: blr             lr
    // 0xcd0354: tbnz            w0, #4, #0xcd03c4
    // 0xcd0358: ldur            x2, [fp, #-0x80]
    // 0xcd035c: r0 = LoadClassIdInstr(r2)
    //     0xcd035c: ldur            x0, [x2, #-1]
    //     0xcd0360: ubfx            x0, x0, #0xc, #0x14
    // 0xcd0364: mov             x1, x2
    // 0xcd0368: r0 = GDT[cid_x0 + 0xe7e7]()
    //     0xcd0368: mov             x17, #0xe7e7
    //     0xcd036c: add             lr, x0, x17
    //     0xcd0370: ldr             lr, [x21, lr, lsl #3]
    //     0xcd0374: blr             lr
    // 0xcd0378: r1 = Null
    //     0xcd0378: mov             x1, NULL
    // 0xcd037c: r0 = Null
    //     0xcd037c: mov             x0, NULL
    // 0xcd0380: b               #0xcd03b8
    // 0xcd0384: sub             SP, fp, #0xa0
    // 0xcd0388: mov             x5, x1
    // 0xcd038c: mov             x3, x0
    // 0xcd0390: mov             x4, x0
    // 0xcd0394: stur            x0, [fp, #-0x88]
    // 0xcd0398: mov             x0, x1
    // 0xcd039c: stur            x1, [fp, #-0x90]
    // 0xcd03a0: ldur            x1, [fp, #-0x80]
    // 0xcd03a4: r2 = "performResize"
    //     0xcd03a4: add             x2, PP, #0x10, lsl #12  ; [pp+0x10fb0] "performResize"
    //     0xcd03a8: ldr             x2, [x2, #0xfb0]
    // 0xcd03ac: r0 = _reportException()
    //     0xcd03ac: bl              #0x89aaa0  ; [package:flutter/src/rendering/object.dart] RenderObject::_reportException
    // 0xcd03b0: ldur            x1, [fp, #-0x90]
    // 0xcd03b4: ldur            x0, [fp, #-0x88]
    // 0xcd03b8: mov             x3, x1
    // 0xcd03bc: mov             x2, x0
    // 0xcd03c0: b               #0xcd03cc
    // 0xcd03c4: r3 = Null
    //     0xcd03c4: mov             x3, NULL
    // 0xcd03c8: r2 = Null
    //     0xcd03c8: mov             x2, NULL
    // 0xcd03cc: stur            x3, [fp, #-0x88]
    // 0xcd03d0: stur            x2, [fp, #-0x90]
    // 0xcd03d4: ldur            x4, [fp, #-0x80]
    // 0xcd03d8: r0 = LoadClassIdInstr(r4)
    //     0xcd03d8: ldur            x0, [x4, #-1]
    //     0xcd03dc: ubfx            x0, x0, #0xc, #0x14
    // 0xcd03e0: mov             x1, x4
    // 0xcd03e4: r0 = GDT[cid_x0 + 0x11329]()
    //     0xcd03e4: mov             x17, #0x1329
    //     0xcd03e8: movk            x17, #1, lsl #16
    //     0xcd03ec: add             lr, x0, x17
    //     0xcd03f0: ldr             lr, [x21, lr, lsl #3]
    //     0xcd03f4: blr             lr
    // 0xcd03f8: ldur            x1, [fp, #-0x80]
    // 0xcd03fc: r0 = markNeedsSemanticsUpdate()
    //     0xcd03fc: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcd0400: b               #0xcd041c
    // 0xcd0404: sub             SP, fp, #0xa0
    // 0xcd0408: mov             x5, x1
    // 0xcd040c: ldur            x1, [fp, #-0x80]
    // 0xcd0410: mov             x3, x0
    // 0xcd0414: r2 = "performLayout"
    //     0xcd0414: ldr             x2, [PP, #0x2df8]  ; [pp+0x2df8] "performLayout"
    // 0xcd0418: r0 = _reportException()
    //     0xcd0418: bl              #0x89aaa0  ; [package:flutter/src/rendering/object.dart] RenderObject::_reportException
    // 0xcd041c: ldur            x1, [fp, #-0x80]
    // 0xcd0420: r0 = false
    //     0xcd0420: add             x0, NULL, #0x30  ; false
    // 0xcd0424: StoreField: r1->field_1b = r0
    //     0xcd0424: stur            w0, [x1, #0x1b]
    // 0xcd0428: r0 = LoadClassIdInstr(r1)
    //     0xcd0428: ldur            x0, [x1, #-1]
    //     0xcd042c: ubfx            x0, x0, #0xc, #0x14
    // 0xcd0430: r0 = GDT[cid_x0 + 0x10585]()
    //     0xcd0430: mov             x17, #0x585
    //     0xcd0434: movk            x17, #1, lsl #16
    //     0xcd0438: add             lr, x0, x17
    //     0xcd043c: ldr             lr, [x21, lr, lsl #3]
    //     0xcd0440: blr             lr
    // 0xcd0444: r0 = Null
    //     0xcd0444: mov             x0, NULL
    // 0xcd0448: LeaveFrame
    //     0xcd0448: mov             SP, fp
    //     0xcd044c: ldp             fp, lr, [SP], #0x10
    // 0xcd0450: ret
    //     0xcd0450: ret             
    // 0xcd0454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0454: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd0458: b               #0xcd0108
  }
  _ clearSemantics(/* No info */) {
    // ** addr: 0xcd05e8, size: 0x98
    // 0xcd05e8: EnterFrame
    //     0xcd05e8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd05ec: mov             fp, SP
    // 0xcd05f0: AllocStack(0x8)
    //     0xcd05f0: sub             SP, SP, #8
    // 0xcd05f4: SetupParameters(RenderObject this /* r1 => r0, fp-0x8 */)
    //     0xcd05f4: mov             x0, x1
    //     0xcd05f8: stur            x1, [fp, #-8]
    // 0xcd05fc: CheckStackOverflow
    //     0xcd05fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd0600: cmp             SP, x16
    //     0xcd0604: b.ls            #0xcd0678
    // 0xcd0608: mov             x1, x0
    // 0xcd060c: LoadField: r0 = r1->field_43
    //     0xcd060c: ldur            w0, [x1, #0x43]
    // 0xcd0610: DecompressPointer r0
    //     0xcd0610: add             x0, x0, HEAP, lsl #32
    // 0xcd0614: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcd0618: cmp             w0, w16
    // 0xcd061c: b.ne            #0xcd0628
    // 0xcd0620: r2 = _semantics
    //     0xcd0620: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0xcd0624: r0 = InitLateFinalInstanceField()
    //     0xcd0624: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xcd0628: mov             x1, x0
    // 0xcd062c: r0 = clear()
    //     0xcd062c: bl              #0xcd0680  ; [package:flutter/src/rendering/object.dart] _RenderObjectSemantics::clear
    // 0xcd0630: r1 = Function '<anonymous closure>':.
    //     0xcd0630: ldr             x1, [PP, #0x7f68]  ; [pp+0x7f68] AnonymousClosure: (0xcd0720), in [package:flutter/src/rendering/object.dart] RenderObject::clearSemantics (0xcd05e8)
    // 0xcd0634: r2 = Null
    //     0xcd0634: mov             x2, NULL
    // 0xcd0638: r0 = AllocateClosure()
    //     0xcd0638: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcd063c: ldur            x1, [fp, #-8]
    // 0xcd0640: r2 = LoadClassIdInstr(r1)
    //     0xcd0640: ldur            x2, [x1, #-1]
    //     0xcd0644: ubfx            x2, x2, #0xc, #0x14
    // 0xcd0648: mov             x16, x0
    // 0xcd064c: mov             x0, x2
    // 0xcd0650: mov             x2, x16
    // 0xcd0654: r0 = GDT[cid_x0 + 0x10a11]()
    //     0xcd0654: mov             x17, #0xa11
    //     0xcd0658: movk            x17, #1, lsl #16
    //     0xcd065c: add             lr, x0, x17
    //     0xcd0660: ldr             lr, [x21, lr, lsl #3]
    //     0xcd0664: blr             lr
    // 0xcd0668: r0 = Null
    //     0xcd0668: mov             x0, NULL
    // 0xcd066c: LeaveFrame
    //     0xcd066c: mov             SP, fp
    //     0xcd0670: ldp             fp, lr, [SP], #0x10
    // 0xcd0674: ret
    //     0xcd0674: ret             
    // 0xcd0678: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0678: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd067c: b               #0xcd0608
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0xcd0720, size: 0x48
    // 0xcd0720: EnterFrame
    //     0xcd0720: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0724: mov             fp, SP
    // 0xcd0728: CheckStackOverflow
    //     0xcd0728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd072c: cmp             SP, x16
    //     0xcd0730: b.ls            #0xcd0760
    // 0xcd0734: ldr             x1, [fp, #0x10]
    // 0xcd0738: r0 = LoadClassIdInstr(r1)
    //     0xcd0738: ldur            x0, [x1, #-1]
    //     0xcd073c: ubfx            x0, x0, #0xc, #0x14
    // 0xcd0740: r0 = GDT[cid_x0 + 0xe596]()
    //     0xcd0740: mov             x17, #0xe596
    //     0xcd0744: add             lr, x0, x17
    //     0xcd0748: ldr             lr, [x21, lr, lsl #3]
    //     0xcd074c: blr             lr
    // 0xcd0750: r0 = Null
    //     0xcd0750: mov             x0, NULL
    // 0xcd0754: LeaveFrame
    //     0xcd0754: mov             SP, fp
    //     0xcd0758: ldp             fp, lr, [SP], #0x10
    // 0xcd075c: ret
    //     0xcd075c: ret             
    // 0xcd0760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0760: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd0764: b               #0xcd0734
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xcdd414, size: 0x5c
    // 0xcdd414: EnterFrame
    //     0xcdd414: stp             fp, lr, [SP, #-0x10]!
    //     0xcdd418: mov             fp, SP
    // 0xcdd41c: mov             x0, x3
    // 0xcdd420: mov             x5, x1
    // 0xcdd424: mov             x4, x2
    // 0xcdd428: r2 = Null
    //     0xcdd428: mov             x2, NULL
    // 0xcdd42c: r1 = Null
    //     0xcdd42c: mov             x1, NULL
    // 0xcdd430: r4 = 60
    //     0xcdd430: mov             x4, #0x3c
    // 0xcdd434: branchIfSmi(r0, 0xcdd440)
    //     0xcdd434: tbz             w0, #0, #0xcdd440
    // 0xcdd438: r4 = LoadClassIdInstr(r0)
    //     0xcdd438: ldur            x4, [x0, #-1]
    //     0xcdd43c: ubfx            x4, x4, #0xc, #0x14
    // 0xcdd440: sub             x4, x4, #0xc63
    // 0xcdd444: cmp             x4, #2
    // 0xcdd448: b.ls            #0xcdd460
    // 0xcdd44c: r8 = HitTestEntry<HitTestTarget>
    //     0xcdd44c: add             x8, PP, #0xe, lsl #12  ; [pp+0xe2c0] Type: HitTestEntry<HitTestTarget>
    //     0xcdd450: ldr             x8, [x8, #0x2c0]
    // 0xcdd454: r3 = Null
    //     0xcdd454: add             x3, PP, #0xe, lsl #12  ; [pp+0xe2c8] Null
    //     0xcdd458: ldr             x3, [x3, #0x2c8]
    // 0xcdd45c: r0 = HitTestEntry<HitTestTarget>()
    //     0xcdd45c: bl              #0x833728  ; IsType_HitTestEntry<HitTestTarget>_Stub
    // 0xcdd460: r0 = Null
    //     0xcdd460: mov             x0, NULL
    // 0xcdd464: LeaveFrame
    //     0xcdd464: mov             SP, fp
    //     0xcdd468: ldp             fp, lr, [SP], #0x10
    // 0xcdd46c: ret
    //     0xcdd46c: ret             
  }
  _ RenderObject(/* No info */) {
    // ** addr: 0xcf04b0, size: 0x104
    // 0xcf04b0: EnterFrame
    //     0xcf04b0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf04b4: mov             fp, SP
    // 0xcf04b8: AllocStack(0x8)
    //     0xcf04b8: sub             SP, SP, #8
    // 0xcf04bc: r3 = true
    //     0xcf04bc: add             x3, NULL, #0x20  ; true
    // 0xcf04c0: r2 = false
    //     0xcf04c0: add             x2, NULL, #0x30  ; false
    // 0xcf04c4: ldr             x0, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf04c8: mov             x4, x1
    // 0xcf04cc: stur            x1, [fp, #-8]
    // 0xcf04d0: CheckStackOverflow
    //     0xcf04d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf04d4: cmp             SP, x16
    //     0xcf04d8: b.ls            #0xcf05ac
    // 0xcf04dc: StoreField: r4->field_b = rZR
    //     0xcf04dc: stur            xzr, [x4, #0xb]
    // 0xcf04e0: StoreField: r4->field_1b = r3
    //     0xcf04e0: stur            w3, [x4, #0x1b]
    // 0xcf04e4: StoreField: r4->field_23 = r2
    //     0xcf04e4: stur            w2, [x4, #0x23]
    // 0xcf04e8: StoreField: r4->field_2b = r0
    //     0xcf04e8: stur            w0, [x4, #0x2b]
    // 0xcf04ec: StoreField: r4->field_33 = r2
    //     0xcf04ec: stur            w2, [x4, #0x33]
    // 0xcf04f0: StoreField: r4->field_37 = r0
    //     0xcf04f0: stur            w0, [x4, #0x37]
    // 0xcf04f4: StoreField: r4->field_3b = r3
    //     0xcf04f4: stur            w3, [x4, #0x3b]
    // 0xcf04f8: StoreField: r4->field_3f = r2
    //     0xcf04f8: stur            w2, [x4, #0x3f]
    // 0xcf04fc: StoreField: r4->field_43 = r0
    //     0xcf04fc: stur            w0, [x4, #0x43]
    // 0xcf0500: r1 = <ContainerLayer>
    //     0xcf0500: ldr             x1, [PP, #0x7f40]  ; [pp+0x7f40] TypeArguments: <ContainerLayer>
    // 0xcf0504: r0 = LayerHandle()
    //     0xcf0504: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0xcf0508: ldur            x2, [fp, #-8]
    // 0xcf050c: StoreField: r2->field_2f = r0
    //     0xcf050c: stur            w0, [x2, #0x2f]
    //     0xcf0510: ldurb           w16, [x2, #-1]
    //     0xcf0514: ldurb           w17, [x0, #-1]
    //     0xcf0518: and             x16, x17, x16, lsr #2
    //     0xcf051c: tst             x16, HEAP, lsr #32
    //     0xcf0520: b.eq            #0xcf0528
    //     0xcf0524: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf0528: r0 = LoadClassIdInstr(r2)
    //     0xcf0528: ldur            x0, [x2, #-1]
    //     0xcf052c: ubfx            x0, x0, #0xc, #0x14
    // 0xcf0530: mov             x1, x2
    // 0xcf0534: r0 = GDT[cid_x0 + 0xfd90]()
    //     0xcf0534: mov             x17, #0xfd90
    //     0xcf0538: add             lr, x0, x17
    //     0xcf053c: ldr             lr, [x21, lr, lsl #3]
    //     0xcf0540: blr             lr
    // 0xcf0544: tbnz            w0, #4, #0xcf0550
    // 0xcf0548: r0 = true
    //     0xcf0548: add             x0, NULL, #0x20  ; true
    // 0xcf054c: b               #0xcf0570
    // 0xcf0550: ldur            x2, [fp, #-8]
    // 0xcf0554: r0 = LoadClassIdInstr(r2)
    //     0xcf0554: ldur            x0, [x2, #-1]
    //     0xcf0558: ubfx            x0, x0, #0xc, #0x14
    // 0xcf055c: mov             x1, x2
    // 0xcf0560: r0 = GDT[cid_x0 + 0xf73b]()
    //     0xcf0560: mov             x17, #0xf73b
    //     0xcf0564: add             lr, x0, x17
    //     0xcf0568: ldr             lr, [x21, lr, lsl #3]
    //     0xcf056c: blr             lr
    // 0xcf0570: ldur            x2, [fp, #-8]
    // 0xcf0574: StoreField: r2->field_37 = r0
    //     0xcf0574: stur            w0, [x2, #0x37]
    // 0xcf0578: r0 = LoadClassIdInstr(r2)
    //     0xcf0578: ldur            x0, [x2, #-1]
    //     0xcf057c: ubfx            x0, x0, #0xc, #0x14
    // 0xcf0580: mov             x1, x2
    // 0xcf0584: r0 = GDT[cid_x0 + 0xfd90]()
    //     0xcf0584: mov             x17, #0xfd90
    //     0xcf0588: add             lr, x0, x17
    //     0xcf058c: ldr             lr, [x21, lr, lsl #3]
    //     0xcf0590: blr             lr
    // 0xcf0594: ldur            x1, [fp, #-8]
    // 0xcf0598: StoreField: r1->field_2b = r0
    //     0xcf0598: stur            w0, [x1, #0x2b]
    // 0xcf059c: r0 = Null
    //     0xcf059c: mov             x0, NULL
    // 0xcf05a0: LeaveFrame
    //     0xcf05a0: mov             SP, fp
    //     0xcf05a4: ldp             fp, lr, [SP], #0x10
    // 0xcf05a8: ret
    //     0xcf05a8: ret             
    // 0xcf05ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf05ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf05b0: b               #0xcf04dc
  }
  _ markNeedsLayoutForSizedByParentChange(/* No info */) {
    // ** addr: 0xcf8994, size: 0x48
    // 0xcf8994: EnterFrame
    //     0xcf8994: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8998: mov             fp, SP
    // 0xcf899c: AllocStack(0x8)
    //     0xcf899c: sub             SP, SP, #8
    // 0xcf89a0: SetupParameters(RenderObject this /* r1 => r0, fp-0x8 */)
    //     0xcf89a0: mov             x0, x1
    //     0xcf89a4: stur            x1, [fp, #-8]
    // 0xcf89a8: CheckStackOverflow
    //     0xcf89a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf89ac: cmp             SP, x16
    //     0xcf89b0: b.ls            #0xcf89d4
    // 0xcf89b4: mov             x1, x0
    // 0xcf89b8: r0 = markNeedsLayout()
    //     0xcf89b8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf89bc: ldur            x1, [fp, #-8]
    // 0xcf89c0: r0 = markParentNeedsLayout()
    //     0xcf89c0: bl              #0xbfb594  ; [package:flutter/src/rendering/object.dart] RenderObject::markParentNeedsLayout
    // 0xcf89c4: r0 = Null
    //     0xcf89c4: mov             x0, NULL
    // 0xcf89c8: LeaveFrame
    //     0xcf89c8: mov             SP, fp
    //     0xcf89cc: ldp             fp, lr, [SP], #0x10
    // 0xcf89d0: ret
    //     0xcf89d0: ret             
    // 0xcf89d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf89d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf89d8: b               #0xcf89b4
  }
  _ sendSemanticsEvent(/* No info */) {
    // ** addr: 0xd12090, size: 0x11c
    // 0xd12090: EnterFrame
    //     0xd12090: stp             fp, lr, [SP, #-0x10]!
    //     0xd12094: mov             fp, SP
    // 0xd12098: AllocStack(0x10)
    //     0xd12098: sub             SP, SP, #0x10
    // 0xd1209c: SetupParameters(RenderObject this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xd1209c: mov             x0, x1
    //     0xd120a0: stur            x1, [fp, #-8]
    //     0xd120a4: stur            x2, [fp, #-0x10]
    // 0xd120a8: CheckStackOverflow
    //     0xd120a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd120ac: cmp             SP, x16
    //     0xd120b0: b.ls            #0xd1219c
    // 0xd120b4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xd120b4: ldur            w1, [x0, #0x17]
    // 0xd120b8: DecompressPointer r1
    //     0xd120b8: add             x1, x1, HEAP, lsl #32
    // 0xd120bc: cmp             w1, NULL
    // 0xd120c0: b.eq            #0xd121a4
    // 0xd120c4: LoadField: r3 = r1->field_2b
    //     0xd120c4: ldur            w3, [x1, #0x2b]
    // 0xd120c8: DecompressPointer r3
    //     0xd120c8: add             x3, x3, HEAP, lsl #32
    // 0xd120cc: cmp             w3, NULL
    // 0xd120d0: b.ne            #0xd120e4
    // 0xd120d4: r0 = Null
    //     0xd120d4: mov             x0, NULL
    // 0xd120d8: LeaveFrame
    //     0xd120d8: mov             SP, fp
    //     0xd120dc: ldp             fp, lr, [SP], #0x10
    // 0xd120e0: ret
    //     0xd120e0: ret             
    // 0xd120e4: mov             x1, x0
    // 0xd120e8: LoadField: r0 = r1->field_43
    //     0xd120e8: ldur            w0, [x1, #0x43]
    // 0xd120ec: DecompressPointer r0
    //     0xd120ec: add             x0, x0, HEAP, lsl #32
    // 0xd120f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xd120f4: cmp             w0, w16
    // 0xd120f8: b.ne            #0xd12104
    // 0xd120fc: r2 = _semantics
    //     0xd120fc: ldr             x2, [PP, #0x2318]  ; [pp+0x2318] Field <RenderObject._semantics@30266271>: late final (offset: 0x44)
    // 0xd12100: r0 = InitLateFinalInstanceField()
    //     0xd12100: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xd12104: LoadField: r1 = r0->field_1b
    //     0xd12104: ldur            w1, [x0, #0x1b]
    // 0xd12108: DecompressPointer r1
    //     0xd12108: add             x1, x1, HEAP, lsl #32
    // 0xd1210c: cmp             w1, NULL
    // 0xd12110: b.eq            #0xd1212c
    // 0xd12114: LoadField: r0 = r1->field_2b
    //     0xd12114: ldur            w0, [x1, #0x2b]
    // 0xd12118: DecompressPointer r0
    //     0xd12118: add             x0, x0, HEAP, lsl #32
    // 0xd1211c: tbz             w0, #4, #0xd1212c
    // 0xd12120: ldur            x2, [fp, #-0x10]
    // 0xd12124: r0 = sendEvent()
    //     0xd12124: bl              #0xd121ac  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::sendEvent
    // 0xd12128: b               #0xd1218c
    // 0xd1212c: ldur            x2, [fp, #-8]
    // 0xd12130: r0 = LoadClassIdInstr(r2)
    //     0xd12130: ldur            x0, [x2, #-1]
    //     0xd12134: ubfx            x0, x0, #0xc, #0x14
    // 0xd12138: mov             x1, x2
    // 0xd1213c: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xd1213c: mov             x17, #0xfc0
    //     0xd12140: movk            x17, #1, lsl #16
    //     0xd12144: add             lr, x0, x17
    //     0xd12148: ldr             lr, [x21, lr, lsl #3]
    //     0xd1214c: blr             lr
    // 0xd12150: cmp             w0, NULL
    // 0xd12154: b.eq            #0xd1218c
    // 0xd12158: ldur            x1, [fp, #-8]
    // 0xd1215c: r0 = LoadClassIdInstr(r1)
    //     0xd1215c: ldur            x0, [x1, #-1]
    //     0xd12160: ubfx            x0, x0, #0xc, #0x14
    // 0xd12164: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0xd12164: mov             x17, #0xfc0
    //     0xd12168: movk            x17, #1, lsl #16
    //     0xd1216c: add             lr, x0, x17
    //     0xd12170: ldr             lr, [x21, lr, lsl #3]
    //     0xd12174: blr             lr
    // 0xd12178: cmp             w0, NULL
    // 0xd1217c: b.eq            #0xd121a8
    // 0xd12180: mov             x1, x0
    // 0xd12184: ldur            x2, [fp, #-0x10]
    // 0xd12188: r0 = sendSemanticsEvent()
    //     0xd12188: bl              #0xd12090  ; [package:flutter/src/rendering/object.dart] RenderObject::sendSemanticsEvent
    // 0xd1218c: r0 = Null
    //     0xd1218c: mov             x0, NULL
    // 0xd12190: LeaveFrame
    //     0xd12190: mov             SP, fp
    //     0xd12194: ldp             fp, lr, [SP], #0x10
    // 0xd12198: ret
    //     0xd12198: ret             
    // 0xd1219c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd1219c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd121a0: b               #0xd120b4
    // 0xd121a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd121a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xd121a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xd121a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4677, size: 0x48, field offset: 0x48
abstract class SemanticsAnnotationsMixin extends RenderObject {
}

// class id: 4681, size: 0x48, field offset: 0x48
abstract class RenderObjectWithLayoutCallbackMixin extends RenderObject {
}

// class id: 4682, size: 0x48, field offset: 0x48
abstract class RelayoutWhenSystemFontsChangeMixin extends RenderObject {
}

// class id: 4705, size: 0x4c, field offset: 0x48
abstract class ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin> extends RenderObject {
}

// class id: 4706, size: 0x4c, field offset: 0x48
abstract class RenderObjectWithChildMixin<X0 bound RenderObject> extends RenderObject {
}
