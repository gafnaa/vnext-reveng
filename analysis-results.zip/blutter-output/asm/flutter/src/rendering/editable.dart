// lib: , url: package:flutter/src/rendering/editable.dart

// class id: 1049025, size: 0x8
class :: {
}

// class id: 2877, size: 0x28, field offset: 0x8
class VerticalCaretMovementRun extends Object
    implements Iterator<X0> {

  _ moveNext(/* No info */) {
    // ** addr: 0x9ed340, size: 0xf8
    // 0x9ed340: EnterFrame
    //     0x9ed340: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed344: mov             fp, SP
    // 0x9ed348: AllocStack(0x18)
    //     0x9ed348: sub             SP, SP, #0x18
    // 0x9ed34c: SetupParameters(VerticalCaretMovementRun this /* r1 => r1, fp-0x10 */)
    //     0x9ed34c: stur            x1, [fp, #-0x10]
    // 0x9ed350: CheckStackOverflow
    //     0x9ed350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ed354: cmp             SP, x16
    //     0x9ed358: b.ls            #0x9ed430
    // 0x9ed35c: LoadField: r0 = r1->field_b
    //     0x9ed35c: ldur            x0, [x1, #0xb]
    // 0x9ed360: add             x2, x0, #1
    // 0x9ed364: stur            x2, [fp, #-8]
    // 0x9ed368: ArrayLoad: r0 = r1[0]  ; List_4
    //     0x9ed368: ldur            w0, [x1, #0x17]
    // 0x9ed36c: DecompressPointer r0
    //     0x9ed36c: add             x0, x0, HEAP, lsl #32
    // 0x9ed370: r3 = LoadClassIdInstr(r0)
    //     0x9ed370: ldur            x3, [x0, #-1]
    //     0x9ed374: ubfx            x3, x3, #0xc, #0x14
    // 0x9ed378: str             x0, [SP]
    // 0x9ed37c: mov             x0, x3
    // 0x9ed380: r0 = GDT[cid_x0 + 0xf078]()
    //     0x9ed380: mov             x17, #0xf078
    //     0x9ed384: add             lr, x0, x17
    //     0x9ed388: ldr             lr, [x21, lr, lsl #3]
    //     0x9ed38c: blr             lr
    // 0x9ed390: r1 = LoadInt32Instr(r0)
    //     0x9ed390: sbfx            x1, x0, #1, #0x1f
    // 0x9ed394: ldur            x0, [fp, #-8]
    // 0x9ed398: cmp             x0, x1
    // 0x9ed39c: b.lt            #0x9ed3b0
    // 0x9ed3a0: r0 = false
    //     0x9ed3a0: add             x0, NULL, #0x30  ; false
    // 0x9ed3a4: LeaveFrame
    //     0x9ed3a4: mov             SP, fp
    //     0x9ed3a8: ldp             fp, lr, [SP], #0x10
    // 0x9ed3ac: ret
    //     0x9ed3ac: ret             
    // 0x9ed3b0: ldur            x0, [fp, #-0x10]
    // 0x9ed3b4: LoadField: r1 = r0->field_b
    //     0x9ed3b4: ldur            x1, [x0, #0xb]
    // 0x9ed3b8: add             x2, x1, #1
    // 0x9ed3bc: mov             x1, x0
    // 0x9ed3c0: r0 = _getTextPositionForLine()
    //     0x9ed3c0: bl              #0x9ed438  ; [package:flutter/src/rendering/editable.dart] VerticalCaretMovementRun::_getTextPositionForLine
    // 0x9ed3c4: mov             x2, x0
    // 0x9ed3c8: ldur            x1, [fp, #-0x10]
    // 0x9ed3cc: LoadField: r3 = r1->field_b
    //     0x9ed3cc: ldur            x3, [x1, #0xb]
    // 0x9ed3d0: add             x4, x3, #1
    // 0x9ed3d4: StoreField: r1->field_b = r4
    //     0x9ed3d4: stur            x4, [x1, #0xb]
    // 0x9ed3d8: LoadField: r0 = r2->field_b
    //     0x9ed3d8: ldur            w0, [x2, #0xb]
    // 0x9ed3dc: DecompressPointer r0
    //     0x9ed3dc: add             x0, x0, HEAP, lsl #32
    // 0x9ed3e0: StoreField: r1->field_7 = r0
    //     0x9ed3e0: stur            w0, [x1, #7]
    //     0x9ed3e4: ldurb           w16, [x1, #-1]
    //     0x9ed3e8: ldurb           w17, [x0, #-1]
    //     0x9ed3ec: and             x16, x17, x16, lsr #2
    //     0x9ed3f0: tst             x16, HEAP, lsr #32
    //     0x9ed3f4: b.eq            #0x9ed3fc
    //     0x9ed3f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x9ed3fc: LoadField: r0 = r2->field_f
    //     0x9ed3fc: ldur            w0, [x2, #0xf]
    // 0x9ed400: DecompressPointer r0
    //     0x9ed400: add             x0, x0, HEAP, lsl #32
    // 0x9ed404: StoreField: r1->field_13 = r0
    //     0x9ed404: stur            w0, [x1, #0x13]
    //     0x9ed408: ldurb           w16, [x1, #-1]
    //     0x9ed40c: ldurb           w17, [x0, #-1]
    //     0x9ed410: and             x16, x17, x16, lsr #2
    //     0x9ed414: tst             x16, HEAP, lsr #32
    //     0x9ed418: b.eq            #0x9ed420
    //     0x9ed41c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x9ed420: r0 = true
    //     0x9ed420: add             x0, NULL, #0x20  ; true
    // 0x9ed424: LeaveFrame
    //     0x9ed424: mov             SP, fp
    //     0x9ed428: ldp             fp, lr, [SP], #0x10
    // 0x9ed42c: ret
    //     0x9ed42c: ret             
    // 0x9ed430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed430: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed434: b               #0x9ed35c
  }
  _ _getTextPositionForLine(/* No info */) {
    // ** addr: 0x9ed438, size: 0x144
    // 0x9ed438: EnterFrame
    //     0x9ed438: stp             fp, lr, [SP, #-0x10]!
    //     0x9ed43c: mov             fp, SP
    // 0x9ed440: AllocStack(0x48)
    //     0x9ed440: sub             SP, SP, #0x48
    // 0x9ed444: SetupParameters(VerticalCaretMovementRun this /* r1 => r3, fp-0x18 */)
    //     0x9ed444: mov             x3, x1
    //     0x9ed448: stur            x1, [fp, #-0x18]
    // 0x9ed44c: CheckStackOverflow
    //     0x9ed44c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x9ed450: cmp             SP, x16
    //     0x9ed454: b.ls            #0x9ed574
    // 0x9ed458: LoadField: r4 = r3->field_23
    //     0x9ed458: ldur            w4, [x3, #0x23]
    // 0x9ed45c: DecompressPointer r4
    //     0x9ed45c: add             x4, x4, HEAP, lsl #32
    // 0x9ed460: stur            x4, [fp, #-0x10]
    // 0x9ed464: r0 = BoxInt64Instr(r2)
    //     0x9ed464: sbfiz           x0, x2, #1, #0x1f
    //     0x9ed468: cmp             x2, x0, asr #1
    //     0x9ed46c: b.eq            #0x9ed478
    //     0x9ed470: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x9ed474: stur            x2, [x0, #7]
    // 0x9ed478: mov             x1, x4
    // 0x9ed47c: mov             x2, x0
    // 0x9ed480: stur            x0, [fp, #-8]
    // 0x9ed484: r0 = _getValueOrData()
    //     0x9ed484: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x9ed488: ldur            x1, [fp, #-0x10]
    // 0x9ed48c: LoadField: r2 = r1->field_f
    //     0x9ed48c: ldur            w2, [x1, #0xf]
    // 0x9ed490: DecompressPointer r2
    //     0x9ed490: add             x2, x2, HEAP, lsl #32
    // 0x9ed494: cmp             w2, w0
    // 0x9ed498: b.ne            #0x9ed4a0
    // 0x9ed49c: r0 = Null
    //     0x9ed49c: mov             x0, NULL
    // 0x9ed4a0: cmp             w0, NULL
    // 0x9ed4a4: b.eq            #0x9ed4b4
    // 0x9ed4a8: LeaveFrame
    //     0x9ed4a8: mov             SP, fp
    //     0x9ed4ac: ldp             fp, lr, [SP], #0x10
    // 0x9ed4b0: ret
    //     0x9ed4b0: ret             
    // 0x9ed4b4: ldur            x2, [fp, #-0x18]
    // 0x9ed4b8: LoadField: r0 = r2->field_7
    //     0x9ed4b8: ldur            w0, [x2, #7]
    // 0x9ed4bc: DecompressPointer r0
    //     0x9ed4bc: add             x0, x0, HEAP, lsl #32
    // 0x9ed4c0: LoadField: d0 = r0->field_7
    //     0x9ed4c0: ldur            d0, [x0, #7]
    // 0x9ed4c4: stur            d0, [fp, #-0x30]
    // 0x9ed4c8: ArrayLoad: r0 = r2[0]  ; List_4
    //     0x9ed4c8: ldur            w0, [x2, #0x17]
    // 0x9ed4cc: DecompressPointer r0
    //     0x9ed4cc: add             x0, x0, HEAP, lsl #32
    // 0x9ed4d0: r3 = LoadClassIdInstr(r0)
    //     0x9ed4d0: ldur            x3, [x0, #-1]
    //     0x9ed4d4: ubfx            x3, x3, #0xc, #0x14
    // 0x9ed4d8: ldur            x16, [fp, #-8]
    // 0x9ed4dc: stp             x16, x0, [SP]
    // 0x9ed4e0: mov             x0, x3
    // 0x9ed4e4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0x9ed4e4: sub             lr, x0, #0xdfd
    //     0x9ed4e8: ldr             lr, [x21, lr, lsl #3]
    //     0x9ed4ec: blr             lr
    // 0x9ed4f0: LoadField: d0 = r0->field_3b
    //     0x9ed4f0: ldur            d0, [x0, #0x3b]
    // 0x9ed4f4: stur            d0, [fp, #-0x38]
    // 0x9ed4f8: r0 = Offset()
    //     0x9ed4f8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x9ed4fc: ldur            d0, [fp, #-0x30]
    // 0x9ed500: stur            x0, [fp, #-0x20]
    // 0x9ed504: StoreField: r0->field_7 = d0
    //     0x9ed504: stur            d0, [x0, #7]
    // 0x9ed508: ldur            d0, [fp, #-0x38]
    // 0x9ed50c: StoreField: r0->field_f = d0
    //     0x9ed50c: stur            d0, [x0, #0xf]
    // 0x9ed510: ldur            x1, [fp, #-0x18]
    // 0x9ed514: LoadField: r2 = r1->field_1b
    //     0x9ed514: ldur            w2, [x1, #0x1b]
    // 0x9ed518: DecompressPointer r2
    //     0x9ed518: add             x2, x2, HEAP, lsl #32
    // 0x9ed51c: LoadField: r1 = r2->field_a7
    //     0x9ed51c: ldur            w1, [x2, #0xa7]
    // 0x9ed520: DecompressPointer r1
    //     0x9ed520: add             x1, x1, HEAP, lsl #32
    // 0x9ed524: mov             x2, x0
    // 0x9ed528: r0 = getPositionForOffset()
    //     0x9ed528: bl              #0x86749c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x9ed52c: r1 = <Offset, TextPosition>
    //     0x9ed52c: add             x1, PP, #0x82, lsl #12  ; [pp+0x82880] TypeArguments: <Offset, TextPosition>
    //     0x9ed530: ldr             x1, [x1, #0x880]
    // 0x9ed534: stur            x0, [fp, #-0x18]
    // 0x9ed538: r0 = MapEntry()
    //     0x9ed538: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x9ed53c: mov             x4, x0
    // 0x9ed540: ldur            x0, [fp, #-0x20]
    // 0x9ed544: stur            x4, [fp, #-0x28]
    // 0x9ed548: StoreField: r4->field_b = r0
    //     0x9ed548: stur            w0, [x4, #0xb]
    // 0x9ed54c: ldur            x0, [fp, #-0x18]
    // 0x9ed550: StoreField: r4->field_f = r0
    //     0x9ed550: stur            w0, [x4, #0xf]
    // 0x9ed554: ldur            x1, [fp, #-0x10]
    // 0x9ed558: ldur            x2, [fp, #-8]
    // 0x9ed55c: mov             x3, x4
    // 0x9ed560: r0 = []=()
    //     0x9ed560: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x9ed564: ldur            x0, [fp, #-0x28]
    // 0x9ed568: LeaveFrame
    //     0x9ed568: mov             SP, fp
    //     0x9ed56c: ldp             fp, lr, [SP], #0x10
    // 0x9ed570: ret
    //     0x9ed570: ret             
    // 0x9ed574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ed574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ed578: b               #0x9ed458
  }
  _ movePrevious(/* No info */) {
    // ** addr: 0xb31bc0, size: 0xbc
    // 0xb31bc0: EnterFrame
    //     0xb31bc0: stp             fp, lr, [SP, #-0x10]!
    //     0xb31bc4: mov             fp, SP
    // 0xb31bc8: AllocStack(0x8)
    //     0xb31bc8: sub             SP, SP, #8
    // 0xb31bcc: SetupParameters(VerticalCaretMovementRun this /* r1 => r0, fp-0x8 */)
    //     0xb31bcc: mov             x0, x1
    //     0xb31bd0: stur            x1, [fp, #-8]
    // 0xb31bd4: CheckStackOverflow
    //     0xb31bd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb31bd8: cmp             SP, x16
    //     0xb31bdc: b.ls            #0xb31c74
    // 0xb31be0: LoadField: r1 = r0->field_b
    //     0xb31be0: ldur            x1, [x0, #0xb]
    // 0xb31be4: cmp             x1, #0
    // 0xb31be8: b.gt            #0xb31bfc
    // 0xb31bec: r0 = false
    //     0xb31bec: add             x0, NULL, #0x30  ; false
    // 0xb31bf0: LeaveFrame
    //     0xb31bf0: mov             SP, fp
    //     0xb31bf4: ldp             fp, lr, [SP], #0x10
    // 0xb31bf8: ret
    //     0xb31bf8: ret             
    // 0xb31bfc: sub             x2, x1, #1
    // 0xb31c00: mov             x1, x0
    // 0xb31c04: r0 = _getTextPositionForLine()
    //     0xb31c04: bl              #0x9ed438  ; [package:flutter/src/rendering/editable.dart] VerticalCaretMovementRun::_getTextPositionForLine
    // 0xb31c08: mov             x2, x0
    // 0xb31c0c: ldur            x1, [fp, #-8]
    // 0xb31c10: LoadField: r3 = r1->field_b
    //     0xb31c10: ldur            x3, [x1, #0xb]
    // 0xb31c14: sub             x4, x3, #1
    // 0xb31c18: StoreField: r1->field_b = r4
    //     0xb31c18: stur            x4, [x1, #0xb]
    // 0xb31c1c: LoadField: r0 = r2->field_b
    //     0xb31c1c: ldur            w0, [x2, #0xb]
    // 0xb31c20: DecompressPointer r0
    //     0xb31c20: add             x0, x0, HEAP, lsl #32
    // 0xb31c24: StoreField: r1->field_7 = r0
    //     0xb31c24: stur            w0, [x1, #7]
    //     0xb31c28: ldurb           w16, [x1, #-1]
    //     0xb31c2c: ldurb           w17, [x0, #-1]
    //     0xb31c30: and             x16, x17, x16, lsr #2
    //     0xb31c34: tst             x16, HEAP, lsr #32
    //     0xb31c38: b.eq            #0xb31c40
    //     0xb31c3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb31c40: LoadField: r0 = r2->field_f
    //     0xb31c40: ldur            w0, [x2, #0xf]
    // 0xb31c44: DecompressPointer r0
    //     0xb31c44: add             x0, x0, HEAP, lsl #32
    // 0xb31c48: StoreField: r1->field_13 = r0
    //     0xb31c48: stur            w0, [x1, #0x13]
    //     0xb31c4c: ldurb           w16, [x1, #-1]
    //     0xb31c50: ldurb           w17, [x0, #-1]
    //     0xb31c54: and             x16, x17, x16, lsr #2
    //     0xb31c58: tst             x16, HEAP, lsr #32
    //     0xb31c5c: b.eq            #0xb31c64
    //     0xb31c60: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb31c64: r0 = true
    //     0xb31c64: add             x0, NULL, #0x20  ; true
    // 0xb31c68: LeaveFrame
    //     0xb31c68: mov             SP, fp
    //     0xb31c6c: ldp             fp, lr, [SP], #0x10
    // 0xb31c70: ret
    //     0xb31c70: ret             
    // 0xb31c74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb31c74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb31c78: b               #0xb31be0
  }
  _ moveByOffset(/* No info */) {
    // ** addr: 0xb31c7c, size: 0x190
    // 0xb31c7c: EnterFrame
    //     0xb31c7c: stp             fp, lr, [SP, #-0x10]!
    //     0xb31c80: mov             fp, SP
    // 0xb31c84: AllocStack(0x28)
    //     0xb31c84: sub             SP, SP, #0x28
    // 0xb31c88: d1 = 0.000000
    //     0xb31c88: eor             v1.16b, v1.16b, v1.16b
    // 0xb31c8c: mov             x0, x1
    // 0xb31c90: stur            x1, [fp, #-0x10]
    // 0xb31c94: CheckStackOverflow
    //     0xb31c94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb31c98: cmp             SP, x16
    //     0xb31c9c: b.ls            #0xb31df4
    // 0xb31ca0: LoadField: r2 = r0->field_7
    //     0xb31ca0: ldur            w2, [x0, #7]
    // 0xb31ca4: DecompressPointer r2
    //     0xb31ca4: add             x2, x2, HEAP, lsl #32
    // 0xb31ca8: stur            x2, [fp, #-8]
    // 0xb31cac: fcmp            d0, d1
    // 0xb31cb0: b.lt            #0xb31d04
    // 0xb31cb4: LoadField: d1 = r2->field_f
    //     0xb31cb4: ldur            d1, [x2, #0xf]
    // 0xb31cb8: fadd            d2, d1, d0
    // 0xb31cbc: stur            d2, [fp, #-0x18]
    // 0xb31cc0: CheckStackOverflow
    //     0xb31cc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb31cc4: cmp             SP, x16
    //     0xb31cc8: b.ls            #0xb31dfc
    // 0xb31ccc: LoadField: r1 = r0->field_7
    //     0xb31ccc: ldur            w1, [x0, #7]
    // 0xb31cd0: DecompressPointer r1
    //     0xb31cd0: add             x1, x1, HEAP, lsl #32
    // 0xb31cd4: LoadField: d0 = r1->field_f
    //     0xb31cd4: ldur            d0, [x1, #0xf]
    // 0xb31cd8: fcmp            d2, d0
    // 0xb31cdc: b.le            #0xb31cfc
    // 0xb31ce0: mov             x1, x0
    // 0xb31ce4: r0 = moveNext()
    //     0xb31ce4: bl              #0x9ed340  ; [package:flutter/src/rendering/editable.dart] VerticalCaretMovementRun::moveNext
    // 0xb31ce8: tbnz            w0, #4, #0xb31cfc
    // 0xb31cec: ldur            x0, [fp, #-0x10]
    // 0xb31cf0: ldur            x2, [fp, #-8]
    // 0xb31cf4: ldur            d2, [fp, #-0x18]
    // 0xb31cf8: b               #0xb31cc0
    // 0xb31cfc: ldur            x2, [fp, #-0x10]
    // 0xb31d00: b               #0xb31dcc
    // 0xb31d04: mov             x0, x2
    // 0xb31d08: LoadField: d1 = r0->field_f
    //     0xb31d08: ldur            d1, [x0, #0xf]
    // 0xb31d0c: fadd            d2, d1, d0
    // 0xb31d10: stur            d2, [fp, #-0x18]
    // 0xb31d14: mov             x1, x0
    // 0xb31d18: ldur            x3, [fp, #-0x10]
    // 0xb31d1c: CheckStackOverflow
    //     0xb31d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb31d20: cmp             SP, x16
    //     0xb31d24: b.ls            #0xb31e04
    // 0xb31d28: LoadField: d0 = r1->field_f
    //     0xb31d28: ldur            d0, [x1, #0xf]
    // 0xb31d2c: fcmp            d0, d2
    // 0xb31d30: b.le            #0xb31dc8
    // 0xb31d34: LoadField: r1 = r3->field_b
    //     0xb31d34: ldur            x1, [x3, #0xb]
    // 0xb31d38: cmp             x1, #0
    // 0xb31d3c: b.le            #0xb31dc0
    // 0xb31d40: sub             x2, x1, #1
    // 0xb31d44: mov             x1, x3
    // 0xb31d48: r0 = _getTextPositionForLine()
    //     0xb31d48: bl              #0x9ed438  ; [package:flutter/src/rendering/editable.dart] VerticalCaretMovementRun::_getTextPositionForLine
    // 0xb31d4c: mov             x1, x0
    // 0xb31d50: ldur            x2, [fp, #-0x10]
    // 0xb31d54: LoadField: r0 = r2->field_b
    //     0xb31d54: ldur            x0, [x2, #0xb]
    // 0xb31d58: sub             x3, x0, #1
    // 0xb31d5c: StoreField: r2->field_b = r3
    //     0xb31d5c: stur            x3, [x2, #0xb]
    // 0xb31d60: LoadField: r3 = r1->field_b
    //     0xb31d60: ldur            w3, [x1, #0xb]
    // 0xb31d64: DecompressPointer r3
    //     0xb31d64: add             x3, x3, HEAP, lsl #32
    // 0xb31d68: mov             x0, x3
    // 0xb31d6c: StoreField: r2->field_7 = r0
    //     0xb31d6c: stur            w0, [x2, #7]
    //     0xb31d70: ldurb           w16, [x2, #-1]
    //     0xb31d74: ldurb           w17, [x0, #-1]
    //     0xb31d78: and             x16, x17, x16, lsr #2
    //     0xb31d7c: tst             x16, HEAP, lsr #32
    //     0xb31d80: b.eq            #0xb31d88
    //     0xb31d84: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb31d88: LoadField: r0 = r1->field_f
    //     0xb31d88: ldur            w0, [x1, #0xf]
    // 0xb31d8c: DecompressPointer r0
    //     0xb31d8c: add             x0, x0, HEAP, lsl #32
    // 0xb31d90: StoreField: r2->field_13 = r0
    //     0xb31d90: stur            w0, [x2, #0x13]
    //     0xb31d94: ldurb           w16, [x2, #-1]
    //     0xb31d98: ldurb           w17, [x0, #-1]
    //     0xb31d9c: and             x16, x17, x16, lsr #2
    //     0xb31da0: tst             x16, HEAP, lsr #32
    //     0xb31da4: b.eq            #0xb31dac
    //     0xb31da8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xb31dac: mov             x1, x3
    // 0xb31db0: mov             x3, x2
    // 0xb31db4: ldur            x0, [fp, #-8]
    // 0xb31db8: ldur            d2, [fp, #-0x18]
    // 0xb31dbc: b               #0xb31d1c
    // 0xb31dc0: mov             x2, x3
    // 0xb31dc4: b               #0xb31dcc
    // 0xb31dc8: mov             x2, x3
    // 0xb31dcc: LoadField: r0 = r2->field_7
    //     0xb31dcc: ldur            w0, [x2, #7]
    // 0xb31dd0: DecompressPointer r0
    //     0xb31dd0: add             x0, x0, HEAP, lsl #32
    // 0xb31dd4: ldur            x16, [fp, #-8]
    // 0xb31dd8: stp             x0, x16, [SP]
    // 0xb31ddc: r0 = ==()
    //     0xb31ddc: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xb31de0: eor             x1, x0, #0x10
    // 0xb31de4: mov             x0, x1
    // 0xb31de8: LeaveFrame
    //     0xb31de8: mov             SP, fp
    //     0xb31dec: ldp             fp, lr, [SP], #0x10
    // 0xb31df0: ret
    //     0xb31df0: ret             
    // 0xb31df4: r0 = StackOverflowSharedWithFPURegs()
    //     0xb31df4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb31df8: b               #0xb31ca0
    // 0xb31dfc: r0 = StackOverflowSharedWithFPURegs()
    //     0xb31dfc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb31e00: b               #0xb31ccc
    // 0xb31e04: r0 = StackOverflowSharedWithFPURegs()
    //     0xb31e04: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb31e08: b               #0xb31d28
  }
  _ VerticalCaretMovementRun._(/* No info */) {
    // ** addr: 0xb31ea4, size: 0x128
    // 0xb31ea4: EnterFrame
    //     0xb31ea4: stp             fp, lr, [SP, #-0x10]!
    //     0xb31ea8: mov             fp, SP
    // 0xb31eac: AllocStack(0x40)
    //     0xb31eac: sub             SP, SP, #0x40
    // 0xb31eb0: r0 = true
    //     0xb31eb0: add             x0, NULL, #0x20  ; true
    // 0xb31eb4: mov             x4, x2
    // 0xb31eb8: stur            x2, [fp, #-0x10]
    // 0xb31ebc: mov             x2, x5
    // 0xb31ec0: stur            x5, [fp, #-0x20]
    // 0xb31ec4: mov             x5, x1
    // 0xb31ec8: stur            x1, [fp, #-8]
    // 0xb31ecc: mov             x1, x7
    // 0xb31ed0: stur            x3, [fp, #-0x18]
    // 0xb31ed4: stur            x6, [fp, #-0x28]
    // 0xb31ed8: stur            x7, [fp, #-0x30]
    // 0xb31edc: CheckStackOverflow
    //     0xb31edc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb31ee0: cmp             SP, x16
    //     0xb31ee4: b.ls            #0xb31fc4
    // 0xb31ee8: StoreField: r5->field_1f = r0
    //     0xb31ee8: stur            w0, [x5, #0x1f]
    // 0xb31eec: r16 = <int, MapEntry<Offset, TextPosition>>
    //     0xb31eec: add             x16, PP, #0x82, lsl #12  ; [pp+0x82888] TypeArguments: <int, MapEntry<Offset, TextPosition>>
    //     0xb31ef0: ldr             x16, [x16, #0x888]
    // 0xb31ef4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xb31ef8: stp             lr, x16, [SP]
    // 0xb31efc: r0 = Map._fromLiteral()
    //     0xb31efc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xb31f00: ldur            x1, [fp, #-8]
    // 0xb31f04: StoreField: r1->field_23 = r0
    //     0xb31f04: stur            w0, [x1, #0x23]
    //     0xb31f08: ldurb           w16, [x1, #-1]
    //     0xb31f0c: ldurb           w17, [x0, #-1]
    //     0xb31f10: and             x16, x17, x16, lsr #2
    //     0xb31f14: tst             x16, HEAP, lsr #32
    //     0xb31f18: b.eq            #0xb31f20
    //     0xb31f1c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb31f20: ldur            x0, [fp, #-0x10]
    // 0xb31f24: StoreField: r1->field_1b = r0
    //     0xb31f24: stur            w0, [x1, #0x1b]
    //     0xb31f28: ldurb           w16, [x1, #-1]
    //     0xb31f2c: ldurb           w17, [x0, #-1]
    //     0xb31f30: and             x16, x17, x16, lsr #2
    //     0xb31f34: tst             x16, HEAP, lsr #32
    //     0xb31f38: b.eq            #0xb31f40
    //     0xb31f3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb31f40: ldur            x0, [fp, #-0x18]
    // 0xb31f44: ArrayStore: r1[0] = r0  ; List_4
    //     0xb31f44: stur            w0, [x1, #0x17]
    //     0xb31f48: ldurb           w16, [x1, #-1]
    //     0xb31f4c: ldurb           w17, [x0, #-1]
    //     0xb31f50: and             x16, x17, x16, lsr #2
    //     0xb31f54: tst             x16, HEAP, lsr #32
    //     0xb31f58: b.eq            #0xb31f60
    //     0xb31f5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb31f60: ldur            x0, [fp, #-0x20]
    // 0xb31f64: StoreField: r1->field_13 = r0
    //     0xb31f64: stur            w0, [x1, #0x13]
    //     0xb31f68: ldurb           w16, [x1, #-1]
    //     0xb31f6c: ldurb           w17, [x0, #-1]
    //     0xb31f70: and             x16, x17, x16, lsr #2
    //     0xb31f74: tst             x16, HEAP, lsr #32
    //     0xb31f78: b.eq            #0xb31f80
    //     0xb31f7c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb31f80: ldur            x2, [fp, #-0x28]
    // 0xb31f84: r3 = LoadInt32Instr(r2)
    //     0xb31f84: sbfx            x3, x2, #1, #0x1f
    //     0xb31f88: tbz             w2, #0, #0xb31f90
    //     0xb31f8c: ldur            x3, [x2, #7]
    // 0xb31f90: StoreField: r1->field_b = r3
    //     0xb31f90: stur            x3, [x1, #0xb]
    // 0xb31f94: ldur            x0, [fp, #-0x30]
    // 0xb31f98: StoreField: r1->field_7 = r0
    //     0xb31f98: stur            w0, [x1, #7]
    //     0xb31f9c: ldurb           w16, [x1, #-1]
    //     0xb31fa0: ldurb           w17, [x0, #-1]
    //     0xb31fa4: and             x16, x17, x16, lsr #2
    //     0xb31fa8: tst             x16, HEAP, lsr #32
    //     0xb31fac: b.eq            #0xb31fb4
    //     0xb31fb0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb31fb4: r0 = Null
    //     0xb31fb4: mov             x0, NULL
    // 0xb31fb8: LeaveFrame
    //     0xb31fb8: mov             SP, fp
    //     0xb31fbc: ldp             fp, lr, [SP], #0x10
    // 0xb31fc0: ret
    //     0xb31fc0: ret             
    // 0xb31fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb31fc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb31fc8: b               #0xb31ee8
  }
  get _ isValid(/* No info */) {
    // ** addr: 0xb32b9c, size: 0x8c
    // 0xb32b9c: EnterFrame
    //     0xb32b9c: stp             fp, lr, [SP, #-0x10]!
    //     0xb32ba0: mov             fp, SP
    // 0xb32ba4: AllocStack(0x8)
    //     0xb32ba4: sub             SP, SP, #8
    // 0xb32ba8: SetupParameters(VerticalCaretMovementRun this /* r1 => r0, fp-0x8 */)
    //     0xb32ba8: mov             x0, x1
    //     0xb32bac: stur            x1, [fp, #-8]
    // 0xb32bb0: CheckStackOverflow
    //     0xb32bb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb32bb4: cmp             SP, x16
    //     0xb32bb8: b.ls            #0xb32c20
    // 0xb32bbc: LoadField: r1 = r0->field_1f
    //     0xb32bbc: ldur            w1, [x0, #0x1f]
    // 0xb32bc0: DecompressPointer r1
    //     0xb32bc0: add             x1, x1, HEAP, lsl #32
    // 0xb32bc4: tbz             w1, #4, #0xb32bd8
    // 0xb32bc8: r0 = false
    //     0xb32bc8: add             x0, NULL, #0x30  ; false
    // 0xb32bcc: LeaveFrame
    //     0xb32bcc: mov             SP, fp
    //     0xb32bd0: ldp             fp, lr, [SP], #0x10
    // 0xb32bd4: ret
    //     0xb32bd4: ret             
    // 0xb32bd8: LoadField: r1 = r0->field_1b
    //     0xb32bd8: ldur            w1, [x0, #0x1b]
    // 0xb32bdc: DecompressPointer r1
    //     0xb32bdc: add             x1, x1, HEAP, lsl #32
    // 0xb32be0: LoadField: r2 = r1->field_a7
    //     0xb32be0: ldur            w2, [x1, #0xa7]
    // 0xb32be4: DecompressPointer r2
    //     0xb32be4: add             x2, x2, HEAP, lsl #32
    // 0xb32be8: mov             x1, x2
    // 0xb32bec: r0 = computeLineMetrics()
    //     0xb32bec: bl              #0xb3234c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeLineMetrics
    // 0xb32bf0: ldur            x1, [fp, #-8]
    // 0xb32bf4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb32bf4: ldur            w2, [x1, #0x17]
    // 0xb32bf8: DecompressPointer r2
    //     0xb32bf8: add             x2, x2, HEAP, lsl #32
    // 0xb32bfc: cmp             w0, w2
    // 0xb32c00: b.eq            #0xb32c0c
    // 0xb32c04: r2 = false
    //     0xb32c04: add             x2, NULL, #0x30  ; false
    // 0xb32c08: StoreField: r1->field_1f = r2
    //     0xb32c08: stur            w2, [x1, #0x1f]
    // 0xb32c0c: LoadField: r0 = r1->field_1f
    //     0xb32c0c: ldur            w0, [x1, #0x1f]
    // 0xb32c10: DecompressPointer r0
    //     0xb32c10: add             x0, x0, HEAP, lsl #32
    // 0xb32c14: LeaveFrame
    //     0xb32c14: mov             SP, fp
    //     0xb32c18: ldp             fp, lr, [SP], #0x10
    // 0xb32c1c: ret
    //     0xb32c1c: ret             
    // 0xb32c20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb32c20: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb32c24: b               #0xb32bbc
  }
}

// class id: 2878, size: 0x10, field offset: 0x8
//   const constructor, 
class TextSelectionPoint extends Object {

  _ ==(/* No info */) {
    // ** addr: 0x1299d24, size: 0x114
    // 0x1299d24: EnterFrame
    //     0x1299d24: stp             fp, lr, [SP, #-0x10]!
    //     0x1299d28: mov             fp, SP
    // 0x1299d2c: AllocStack(0x10)
    //     0x1299d2c: sub             SP, SP, #0x10
    // 0x1299d30: CheckStackOverflow
    //     0x1299d30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1299d34: cmp             SP, x16
    //     0x1299d38: b.ls            #0x1299e30
    // 0x1299d3c: ldr             x0, [fp, #0x10]
    // 0x1299d40: cmp             w0, NULL
    // 0x1299d44: b.ne            #0x1299d58
    // 0x1299d48: r0 = false
    //     0x1299d48: add             x0, NULL, #0x30  ; false
    // 0x1299d4c: LeaveFrame
    //     0x1299d4c: mov             SP, fp
    //     0x1299d50: ldp             fp, lr, [SP], #0x10
    // 0x1299d54: ret
    //     0x1299d54: ret             
    // 0x1299d58: ldr             x1, [fp, #0x18]
    // 0x1299d5c: cmp             w1, w0
    // 0x1299d60: b.ne            #0x1299d74
    // 0x1299d64: r0 = true
    //     0x1299d64: add             x0, NULL, #0x20  ; true
    // 0x1299d68: LeaveFrame
    //     0x1299d68: mov             SP, fp
    //     0x1299d6c: ldp             fp, lr, [SP], #0x10
    // 0x1299d70: ret
    //     0x1299d70: ret             
    // 0x1299d74: str             x0, [SP]
    // 0x1299d78: r0 = runtimeType()
    //     0x1299d78: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1299d7c: r1 = LoadClassIdInstr(r0)
    //     0x1299d7c: ldur            x1, [x0, #-1]
    //     0x1299d80: ubfx            x1, x1, #0xc, #0x14
    // 0x1299d84: r16 = TextSelectionPoint
    //     0x1299d84: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1e0] Type: TextSelectionPoint
    //     0x1299d88: ldr             x16, [x16, #0x1e0]
    // 0x1299d8c: stp             x16, x0, [SP]
    // 0x1299d90: mov             x0, x1
    // 0x1299d94: mov             lr, x0
    // 0x1299d98: ldr             lr, [x21, lr, lsl #3]
    // 0x1299d9c: blr             lr
    // 0x1299da0: tbz             w0, #4, #0x1299db4
    // 0x1299da4: r0 = false
    //     0x1299da4: add             x0, NULL, #0x30  ; false
    // 0x1299da8: LeaveFrame
    //     0x1299da8: mov             SP, fp
    //     0x1299dac: ldp             fp, lr, [SP], #0x10
    // 0x1299db0: ret
    //     0x1299db0: ret             
    // 0x1299db4: ldr             x0, [fp, #0x10]
    // 0x1299db8: r1 = 60
    //     0x1299db8: mov             x1, #0x3c
    // 0x1299dbc: branchIfSmi(r0, 0x1299dc8)
    //     0x1299dbc: tbz             w0, #0, #0x1299dc8
    // 0x1299dc0: r1 = LoadClassIdInstr(r0)
    //     0x1299dc0: ldur            x1, [x0, #-1]
    //     0x1299dc4: ubfx            x1, x1, #0xc, #0x14
    // 0x1299dc8: cmp             x1, #0xb3e
    // 0x1299dcc: b.ne            #0x1299e20
    // 0x1299dd0: ldr             x1, [fp, #0x18]
    // 0x1299dd4: LoadField: r2 = r0->field_7
    //     0x1299dd4: ldur            w2, [x0, #7]
    // 0x1299dd8: DecompressPointer r2
    //     0x1299dd8: add             x2, x2, HEAP, lsl #32
    // 0x1299ddc: LoadField: r3 = r1->field_7
    //     0x1299ddc: ldur            w3, [x1, #7]
    // 0x1299de0: DecompressPointer r3
    //     0x1299de0: add             x3, x3, HEAP, lsl #32
    // 0x1299de4: stp             x3, x2, [SP]
    // 0x1299de8: r0 = ==()
    //     0x1299de8: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x1299dec: tbnz            w0, #4, #0x1299e20
    // 0x1299df0: ldr             x2, [fp, #0x18]
    // 0x1299df4: ldr             x1, [fp, #0x10]
    // 0x1299df8: LoadField: r3 = r1->field_b
    //     0x1299df8: ldur            w3, [x1, #0xb]
    // 0x1299dfc: DecompressPointer r3
    //     0x1299dfc: add             x3, x3, HEAP, lsl #32
    // 0x1299e00: LoadField: r1 = r2->field_b
    //     0x1299e00: ldur            w1, [x2, #0xb]
    // 0x1299e04: DecompressPointer r1
    //     0x1299e04: add             x1, x1, HEAP, lsl #32
    // 0x1299e08: cmp             w3, w1
    // 0x1299e0c: r16 = true
    //     0x1299e0c: add             x16, NULL, #0x20  ; true
    // 0x1299e10: r17 = false
    //     0x1299e10: add             x17, NULL, #0x30  ; false
    // 0x1299e14: csel            x2, x16, x17, eq
    // 0x1299e18: mov             x0, x2
    // 0x1299e1c: b               #0x1299e24
    // 0x1299e20: r0 = false
    //     0x1299e20: add             x0, NULL, #0x30  ; false
    // 0x1299e24: LeaveFrame
    //     0x1299e24: mov             SP, fp
    //     0x1299e28: ldp             fp, lr, [SP], #0x10
    // 0x1299e2c: ret
    //     0x1299e2c: ret             
    // 0x1299e30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1299e30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1299e34: b               #0x1299d3c
  }
}

// class id: 4479, size: 0x24, field offset: 0x24
abstract class RenderEditablePainter extends ChangeNotifier {
}

// class id: 4480, size: 0x28, field offset: 0x24
class _CompositeRenderEditablePainter extends RenderEditablePainter {

  _ removeListener(/* No info */) {
    // ** addr: 0xcff7c0, size: 0xf0
    // 0xcff7c0: EnterFrame
    //     0xcff7c0: stp             fp, lr, [SP, #-0x10]!
    //     0xcff7c4: mov             fp, SP
    // 0xcff7c8: AllocStack(0x20)
    //     0xcff7c8: sub             SP, SP, #0x20
    // 0xcff7cc: SetupParameters(dynamic _ /* r2 => r3, fp-0x20 */)
    //     0xcff7cc: mov             x3, x2
    //     0xcff7d0: stur            x2, [fp, #-0x20]
    // 0xcff7d4: CheckStackOverflow
    //     0xcff7d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff7d8: cmp             SP, x16
    //     0xcff7dc: b.ls            #0xcff8a0
    // 0xcff7e0: LoadField: r4 = r1->field_23
    //     0xcff7e0: ldur            w4, [x1, #0x23]
    // 0xcff7e4: DecompressPointer r4
    //     0xcff7e4: add             x4, x4, HEAP, lsl #32
    // 0xcff7e8: stur            x4, [fp, #-0x18]
    // 0xcff7ec: LoadField: r0 = r4->field_b
    //     0xcff7ec: ldur            w0, [x4, #0xb]
    // 0xcff7f0: r5 = LoadInt32Instr(r0)
    //     0xcff7f0: sbfx            x5, x0, #1, #0x1f
    // 0xcff7f4: stur            x5, [fp, #-0x10]
    // 0xcff7f8: r0 = 0
    //     0xcff7f8: mov             x0, #0
    // 0xcff7fc: CheckStackOverflow
    //     0xcff7fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcff800: cmp             SP, x16
    //     0xcff804: b.ls            #0xcff8a8
    // 0xcff808: LoadField: r1 = r4->field_b
    //     0xcff808: ldur            w1, [x4, #0xb]
    // 0xcff80c: r2 = LoadInt32Instr(r1)
    //     0xcff80c: sbfx            x2, x1, #1, #0x1f
    // 0xcff810: cmp             x5, x2
    // 0xcff814: b.ne            #0xcff880
    // 0xcff818: cmp             x0, x2
    // 0xcff81c: b.ge            #0xcff870
    // 0xcff820: LoadField: r1 = r4->field_f
    //     0xcff820: ldur            w1, [x4, #0xf]
    // 0xcff824: DecompressPointer r1
    //     0xcff824: add             x1, x1, HEAP, lsl #32
    // 0xcff828: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0xcff828: add             x16, x1, x0, lsl #2
    //     0xcff82c: ldur            w2, [x16, #0xf]
    // 0xcff830: DecompressPointer r2
    //     0xcff830: add             x2, x2, HEAP, lsl #32
    // 0xcff834: add             x6, x0, #1
    // 0xcff838: stur            x6, [fp, #-8]
    // 0xcff83c: r0 = LoadClassIdInstr(r2)
    //     0xcff83c: ldur            x0, [x2, #-1]
    //     0xcff840: ubfx            x0, x0, #0xc, #0x14
    // 0xcff844: mov             x1, x2
    // 0xcff848: mov             x2, x3
    // 0xcff84c: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xcff84c: mov             x17, #0xe2a3
    //     0xcff850: add             lr, x0, x17
    //     0xcff854: ldr             lr, [x21, lr, lsl #3]
    //     0xcff858: blr             lr
    // 0xcff85c: ldur            x0, [fp, #-8]
    // 0xcff860: ldur            x3, [fp, #-0x20]
    // 0xcff864: ldur            x4, [fp, #-0x18]
    // 0xcff868: ldur            x5, [fp, #-0x10]
    // 0xcff86c: b               #0xcff7fc
    // 0xcff870: r0 = Null
    //     0xcff870: mov             x0, NULL
    // 0xcff874: LeaveFrame
    //     0xcff874: mov             SP, fp
    //     0xcff878: ldp             fp, lr, [SP], #0x10
    // 0xcff87c: ret
    //     0xcff87c: ret             
    // 0xcff880: mov             x0, x4
    // 0xcff884: r0 = ConcurrentModificationError()
    //     0xcff884: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xcff888: mov             x1, x0
    // 0xcff88c: ldur            x0, [fp, #-0x18]
    // 0xcff890: StoreField: r1->field_b = r0
    //     0xcff890: stur            w0, [x1, #0xb]
    // 0xcff894: mov             x0, x1
    // 0xcff898: r0 = Throw()
    //     0xcff898: bl              #0x13ddb2c  ; ThrowStub
    // 0xcff89c: brk             #0
    // 0xcff8a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcff8a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcff8a4: b               #0xcff7e0
    // 0xcff8a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcff8a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcff8ac: b               #0xcff808
  }
  _ addListener(/* No info */) {
    // ** addr: 0xd037f0, size: 0xf0
    // 0xd037f0: EnterFrame
    //     0xd037f0: stp             fp, lr, [SP, #-0x10]!
    //     0xd037f4: mov             fp, SP
    // 0xd037f8: AllocStack(0x20)
    //     0xd037f8: sub             SP, SP, #0x20
    // 0xd037fc: SetupParameters(dynamic _ /* r2 => r3, fp-0x20 */)
    //     0xd037fc: mov             x3, x2
    //     0xd03800: stur            x2, [fp, #-0x20]
    // 0xd03804: CheckStackOverflow
    //     0xd03804: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03808: cmp             SP, x16
    //     0xd0380c: b.ls            #0xd038d0
    // 0xd03810: LoadField: r4 = r1->field_23
    //     0xd03810: ldur            w4, [x1, #0x23]
    // 0xd03814: DecompressPointer r4
    //     0xd03814: add             x4, x4, HEAP, lsl #32
    // 0xd03818: stur            x4, [fp, #-0x18]
    // 0xd0381c: LoadField: r0 = r4->field_b
    //     0xd0381c: ldur            w0, [x4, #0xb]
    // 0xd03820: r5 = LoadInt32Instr(r0)
    //     0xd03820: sbfx            x5, x0, #1, #0x1f
    // 0xd03824: stur            x5, [fp, #-0x10]
    // 0xd03828: r0 = 0
    //     0xd03828: mov             x0, #0
    // 0xd0382c: CheckStackOverflow
    //     0xd0382c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd03830: cmp             SP, x16
    //     0xd03834: b.ls            #0xd038d8
    // 0xd03838: LoadField: r1 = r4->field_b
    //     0xd03838: ldur            w1, [x4, #0xb]
    // 0xd0383c: r2 = LoadInt32Instr(r1)
    //     0xd0383c: sbfx            x2, x1, #1, #0x1f
    // 0xd03840: cmp             x5, x2
    // 0xd03844: b.ne            #0xd038b0
    // 0xd03848: cmp             x0, x2
    // 0xd0384c: b.ge            #0xd038a0
    // 0xd03850: LoadField: r1 = r4->field_f
    //     0xd03850: ldur            w1, [x4, #0xf]
    // 0xd03854: DecompressPointer r1
    //     0xd03854: add             x1, x1, HEAP, lsl #32
    // 0xd03858: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0xd03858: add             x16, x1, x0, lsl #2
    //     0xd0385c: ldur            w2, [x16, #0xf]
    // 0xd03860: DecompressPointer r2
    //     0xd03860: add             x2, x2, HEAP, lsl #32
    // 0xd03864: add             x6, x0, #1
    // 0xd03868: stur            x6, [fp, #-8]
    // 0xd0386c: r0 = LoadClassIdInstr(r2)
    //     0xd0386c: ldur            x0, [x2, #-1]
    //     0xd03870: ubfx            x0, x0, #0xc, #0x14
    // 0xd03874: mov             x1, x2
    // 0xd03878: mov             x2, x3
    // 0xd0387c: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xd0387c: mov             x17, #0xe0ec
    //     0xd03880: add             lr, x0, x17
    //     0xd03884: ldr             lr, [x21, lr, lsl #3]
    //     0xd03888: blr             lr
    // 0xd0388c: ldur            x0, [fp, #-8]
    // 0xd03890: ldur            x3, [fp, #-0x20]
    // 0xd03894: ldur            x4, [fp, #-0x18]
    // 0xd03898: ldur            x5, [fp, #-0x10]
    // 0xd0389c: b               #0xd0382c
    // 0xd038a0: r0 = Null
    //     0xd038a0: mov             x0, NULL
    // 0xd038a4: LeaveFrame
    //     0xd038a4: mov             SP, fp
    //     0xd038a8: ldp             fp, lr, [SP], #0x10
    // 0xd038ac: ret
    //     0xd038ac: ret             
    // 0xd038b0: mov             x0, x4
    // 0xd038b4: r0 = ConcurrentModificationError()
    //     0xd038b4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xd038b8: mov             x1, x0
    // 0xd038bc: ldur            x0, [fp, #-0x18]
    // 0xd038c0: StoreField: r1->field_b = r0
    //     0xd038c0: stur            w0, [x1, #0xb]
    // 0xd038c4: mov             x0, x1
    // 0xd038c8: r0 = Throw()
    //     0xd038c8: bl              #0x13ddb2c  ; ThrowStub
    // 0xd038cc: brk             #0
    // 0xd038d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd038d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd038d4: b               #0xd03810
    // 0xd038d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd038d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd038dc: b               #0xd03838
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x11a17f8, size: 0x1b8
    // 0x11a17f8: EnterFrame
    //     0x11a17f8: stp             fp, lr, [SP, #-0x10]!
    //     0x11a17fc: mov             fp, SP
    // 0x11a1800: AllocStack(0x28)
    //     0x11a1800: sub             SP, SP, #0x28
    // 0x11a1804: CheckStackOverflow
    //     0x11a1804: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a1808: cmp             SP, x16
    //     0x11a180c: b.ls            #0x11a199c
    // 0x11a1810: cmp             w2, w1
    // 0x11a1814: b.ne            #0x11a1828
    // 0x11a1818: r0 = false
    //     0x11a1818: add             x0, NULL, #0x30  ; false
    // 0x11a181c: LeaveFrame
    //     0x11a181c: mov             SP, fp
    //     0x11a1820: ldp             fp, lr, [SP], #0x10
    // 0x11a1824: ret
    //     0x11a1824: ret             
    // 0x11a1828: r0 = LoadClassIdInstr(r2)
    //     0x11a1828: ldur            x0, [x2, #-1]
    //     0x11a182c: ubfx            x0, x0, #0xc, #0x14
    // 0x11a1830: r17 = 4480
    //     0x11a1830: mov             x17, #0x1180
    // 0x11a1834: cmp             x0, x17
    // 0x11a1838: b.ne            #0x11a1874
    // 0x11a183c: LoadField: r3 = r2->field_23
    //     0x11a183c: ldur            w3, [x2, #0x23]
    // 0x11a1840: DecompressPointer r3
    //     0x11a1840: add             x3, x3, HEAP, lsl #32
    // 0x11a1844: stur            x3, [fp, #-0x28]
    // 0x11a1848: LoadField: r0 = r3->field_b
    //     0x11a1848: ldur            w0, [x3, #0xb]
    // 0x11a184c: LoadField: r4 = r1->field_23
    //     0x11a184c: ldur            w4, [x1, #0x23]
    // 0x11a1850: DecompressPointer r4
    //     0x11a1850: add             x4, x4, HEAP, lsl #32
    // 0x11a1854: stur            x4, [fp, #-0x20]
    // 0x11a1858: LoadField: r1 = r4->field_b
    //     0x11a1858: ldur            w1, [x4, #0xb]
    // 0x11a185c: r5 = LoadInt32Instr(r0)
    //     0x11a185c: sbfx            x5, x0, #1, #0x1f
    // 0x11a1860: stur            x5, [fp, #-0x18]
    // 0x11a1864: r6 = LoadInt32Instr(r1)
    //     0x11a1864: sbfx            x6, x1, #1, #0x1f
    // 0x11a1868: stur            x6, [fp, #-0x10]
    // 0x11a186c: cmp             w0, w1
    // 0x11a1870: b.eq            #0x11a1884
    // 0x11a1874: r0 = true
    //     0x11a1874: add             x0, NULL, #0x20  ; true
    // 0x11a1878: LeaveFrame
    //     0x11a1878: mov             SP, fp
    //     0x11a187c: ldp             fp, lr, [SP], #0x10
    // 0x11a1880: ret
    //     0x11a1880: ret             
    // 0x11a1884: r2 = 0
    //     0x11a1884: mov             x2, #0
    // 0x11a1888: CheckStackOverflow
    //     0x11a1888: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a188c: cmp             SP, x16
    //     0x11a1890: b.ls            #0x11a19a4
    // 0x11a1894: LoadField: r0 = r3->field_b
    //     0x11a1894: ldur            w0, [x3, #0xb]
    // 0x11a1898: r1 = LoadInt32Instr(r0)
    //     0x11a1898: sbfx            x1, x0, #1, #0x1f
    // 0x11a189c: cmp             x5, x1
    // 0x11a18a0: b.ne            #0x11a197c
    // 0x11a18a4: cmp             x2, x1
    // 0x11a18a8: b.ge            #0x11a194c
    // 0x11a18ac: LoadField: r0 = r3->field_f
    //     0x11a18ac: ldur            w0, [x3, #0xf]
    // 0x11a18b0: DecompressPointer r0
    //     0x11a18b0: add             x0, x0, HEAP, lsl #32
    // 0x11a18b4: ArrayLoad: r7 = r0[r2]  ; Unknown_4
    //     0x11a18b4: add             x16, x0, x2, lsl #2
    //     0x11a18b8: ldur            w7, [x16, #0xf]
    // 0x11a18bc: DecompressPointer r7
    //     0x11a18bc: add             x7, x7, HEAP, lsl #32
    // 0x11a18c0: add             x8, x2, #1
    // 0x11a18c4: stur            x8, [fp, #-8]
    // 0x11a18c8: LoadField: r0 = r4->field_b
    //     0x11a18c8: ldur            w0, [x4, #0xb]
    // 0x11a18cc: r1 = LoadInt32Instr(r0)
    //     0x11a18cc: sbfx            x1, x0, #1, #0x1f
    // 0x11a18d0: cmp             x6, x1
    // 0x11a18d4: b.ne            #0x11a195c
    // 0x11a18d8: cmp             x2, x1
    // 0x11a18dc: b.ge            #0x11a194c
    // 0x11a18e0: mov             x0, x1
    // 0x11a18e4: mov             x1, x2
    // 0x11a18e8: cmp             x1, x0
    // 0x11a18ec: b.hs            #0x11a19ac
    // 0x11a18f0: LoadField: r0 = r4->field_f
    //     0x11a18f0: ldur            w0, [x4, #0xf]
    // 0x11a18f4: DecompressPointer r0
    //     0x11a18f4: add             x0, x0, HEAP, lsl #32
    // 0x11a18f8: ArrayLoad: r1 = r0[r2]  ; Unknown_4
    //     0x11a18f8: add             x16, x0, x2, lsl #2
    //     0x11a18fc: ldur            w1, [x16, #0xf]
    // 0x11a1900: DecompressPointer r1
    //     0x11a1900: add             x1, x1, HEAP, lsl #32
    // 0x11a1904: r0 = LoadClassIdInstr(r1)
    //     0x11a1904: ldur            x0, [x1, #-1]
    //     0x11a1908: ubfx            x0, x0, #0xc, #0x14
    // 0x11a190c: mov             x2, x7
    // 0x11a1910: r0 = GDT[cid_x0 + 0x223a]()
    //     0x11a1910: mov             x17, #0x223a
    //     0x11a1914: add             lr, x0, x17
    //     0x11a1918: ldr             lr, [x21, lr, lsl #3]
    //     0x11a191c: blr             lr
    // 0x11a1920: tbz             w0, #4, #0x11a193c
    // 0x11a1924: ldur            x2, [fp, #-8]
    // 0x11a1928: ldur            x3, [fp, #-0x28]
    // 0x11a192c: ldur            x4, [fp, #-0x20]
    // 0x11a1930: ldur            x5, [fp, #-0x18]
    // 0x11a1934: ldur            x6, [fp, #-0x10]
    // 0x11a1938: b               #0x11a1888
    // 0x11a193c: r0 = true
    //     0x11a193c: add             x0, NULL, #0x20  ; true
    // 0x11a1940: LeaveFrame
    //     0x11a1940: mov             SP, fp
    //     0x11a1944: ldp             fp, lr, [SP], #0x10
    // 0x11a1948: ret
    //     0x11a1948: ret             
    // 0x11a194c: r0 = false
    //     0x11a194c: add             x0, NULL, #0x30  ; false
    // 0x11a1950: LeaveFrame
    //     0x11a1950: mov             SP, fp
    //     0x11a1954: ldp             fp, lr, [SP], #0x10
    // 0x11a1958: ret
    //     0x11a1958: ret             
    // 0x11a195c: mov             x0, x4
    // 0x11a1960: r0 = ConcurrentModificationError()
    //     0x11a1960: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x11a1964: mov             x1, x0
    // 0x11a1968: ldur            x0, [fp, #-0x20]
    // 0x11a196c: StoreField: r1->field_b = r0
    //     0x11a196c: stur            w0, [x1, #0xb]
    // 0x11a1970: mov             x0, x1
    // 0x11a1974: r0 = Throw()
    //     0x11a1974: bl              #0x13ddb2c  ; ThrowStub
    // 0x11a1978: brk             #0
    // 0x11a197c: mov             x0, x3
    // 0x11a1980: r0 = ConcurrentModificationError()
    //     0x11a1980: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x11a1984: mov             x1, x0
    // 0x11a1988: ldur            x0, [fp, #-0x28]
    // 0x11a198c: StoreField: r1->field_b = r0
    //     0x11a198c: stur            w0, [x1, #0xb]
    // 0x11a1990: mov             x0, x1
    // 0x11a1994: r0 = Throw()
    //     0x11a1994: bl              #0x13ddb2c  ; ThrowStub
    // 0x11a1998: brk             #0
    // 0x11a199c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a199c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a19a0: b               #0x11a1810
    // 0x11a19a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a19a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a19a8: b               #0x11a1894
    // 0x11a19ac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x11a19ac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x122f2a0, size: 0x100
    // 0x122f2a0: EnterFrame
    //     0x122f2a0: stp             fp, lr, [SP, #-0x10]!
    //     0x122f2a4: mov             fp, SP
    // 0x122f2a8: AllocStack(0x28)
    //     0x122f2a8: sub             SP, SP, #0x28
    // 0x122f2ac: SetupParameters(dynamic _ /* r2 => r5, fp-0x20 */, dynamic _ /* r3 => r4, fp-0x28 */)
    //     0x122f2ac: mov             x5, x2
    //     0x122f2b0: mov             x4, x3
    //     0x122f2b4: stur            x2, [fp, #-0x20]
    //     0x122f2b8: stur            x3, [fp, #-0x28]
    // 0x122f2bc: CheckStackOverflow
    //     0x122f2bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122f2c0: cmp             SP, x16
    //     0x122f2c4: b.ls            #0x122f390
    // 0x122f2c8: LoadField: r6 = r1->field_23
    //     0x122f2c8: ldur            w6, [x1, #0x23]
    // 0x122f2cc: DecompressPointer r6
    //     0x122f2cc: add             x6, x6, HEAP, lsl #32
    // 0x122f2d0: stur            x6, [fp, #-0x18]
    // 0x122f2d4: LoadField: r0 = r6->field_b
    //     0x122f2d4: ldur            w0, [x6, #0xb]
    // 0x122f2d8: r7 = LoadInt32Instr(r0)
    //     0x122f2d8: sbfx            x7, x0, #1, #0x1f
    // 0x122f2dc: stur            x7, [fp, #-0x10]
    // 0x122f2e0: r0 = 0
    //     0x122f2e0: mov             x0, #0
    // 0x122f2e4: CheckStackOverflow
    //     0x122f2e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122f2e8: cmp             SP, x16
    //     0x122f2ec: b.ls            #0x122f398
    // 0x122f2f0: LoadField: r1 = r6->field_b
    //     0x122f2f0: ldur            w1, [x6, #0xb]
    // 0x122f2f4: r2 = LoadInt32Instr(r1)
    //     0x122f2f4: sbfx            x2, x1, #1, #0x1f
    // 0x122f2f8: cmp             x7, x2
    // 0x122f2fc: b.ne            #0x122f370
    // 0x122f300: cmp             x0, x2
    // 0x122f304: b.ge            #0x122f360
    // 0x122f308: LoadField: r1 = r6->field_f
    //     0x122f308: ldur            w1, [x6, #0xf]
    // 0x122f30c: DecompressPointer r1
    //     0x122f30c: add             x1, x1, HEAP, lsl #32
    // 0x122f310: ArrayLoad: r2 = r1[r0]  ; Unknown_4
    //     0x122f310: add             x16, x1, x0, lsl #2
    //     0x122f314: ldur            w2, [x16, #0xf]
    // 0x122f318: DecompressPointer r2
    //     0x122f318: add             x2, x2, HEAP, lsl #32
    // 0x122f31c: add             x8, x0, #1
    // 0x122f320: stur            x8, [fp, #-8]
    // 0x122f324: r0 = LoadClassIdInstr(r2)
    //     0x122f324: ldur            x0, [x2, #-1]
    //     0x122f328: ubfx            x0, x0, #0xc, #0x14
    // 0x122f32c: mov             x1, x2
    // 0x122f330: mov             x2, x5
    // 0x122f334: mov             x3, x4
    // 0x122f338: r0 = GDT[cid_x0 + 0x14a5]()
    //     0x122f338: mov             x17, #0x14a5
    //     0x122f33c: add             lr, x0, x17
    //     0x122f340: ldr             lr, [x21, lr, lsl #3]
    //     0x122f344: blr             lr
    // 0x122f348: ldur            x0, [fp, #-8]
    // 0x122f34c: ldur            x5, [fp, #-0x20]
    // 0x122f350: ldur            x4, [fp, #-0x28]
    // 0x122f354: ldur            x6, [fp, #-0x18]
    // 0x122f358: ldur            x7, [fp, #-0x10]
    // 0x122f35c: b               #0x122f2e4
    // 0x122f360: r0 = Null
    //     0x122f360: mov             x0, NULL
    // 0x122f364: LeaveFrame
    //     0x122f364: mov             SP, fp
    //     0x122f368: ldp             fp, lr, [SP], #0x10
    // 0x122f36c: ret
    //     0x122f36c: ret             
    // 0x122f370: mov             x0, x6
    // 0x122f374: r0 = ConcurrentModificationError()
    //     0x122f374: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x122f378: mov             x1, x0
    // 0x122f37c: ldur            x0, [fp, #-0x18]
    // 0x122f380: StoreField: r1->field_b = r0
    //     0x122f380: stur            w0, [x1, #0xb]
    // 0x122f384: mov             x0, x1
    // 0x122f388: r0 = Throw()
    //     0x122f388: bl              #0x13ddb2c  ; ThrowStub
    // 0x122f38c: brk             #0
    // 0x122f390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122f390: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122f394: b               #0x122f2c8
    // 0x122f398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122f398: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122f39c: b               #0x122f2f0
  }
}

// class id: 4481, size: 0x48, field offset: 0x24
class _CaretPainter extends RenderEditablePainter {

  late final Paint floatingCursorPaint; // offset: 0x30

  _ _CaretPainter(/* No info */) {
    // ** addr: 0x8633bc, size: 0xe0
    // 0x8633bc: EnterFrame
    //     0x8633bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8633c0: mov             fp, SP
    // 0x8633c4: AllocStack(0x20)
    //     0x8633c4: sub             SP, SP, #0x20
    // 0x8633c8: r4 = true
    //     0x8633c8: add             x4, NULL, #0x20  ; true
    // 0x8633cc: r3 = false
    //     0x8633cc: add             x3, NULL, #0x30  ; false
    // 0x8633d0: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x8633d4: r0 = Instance_Offset
    //     0x8633d4: ldr             x0, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x8633d8: stur            x1, [fp, #-8]
    // 0x8633dc: CheckStackOverflow
    //     0x8633dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8633e0: cmp             SP, x16
    //     0x8633e4: b.ls            #0x863494
    // 0x8633e8: StoreField: r1->field_23 = r4
    //     0x8633e8: stur            w4, [x1, #0x23]
    // 0x8633ec: StoreField: r1->field_27 = r3
    //     0x8633ec: stur            w3, [x1, #0x27]
    // 0x8633f0: StoreField: r1->field_2f = r2
    //     0x8633f0: stur            w2, [x1, #0x2f]
    // 0x8633f4: StoreField: r1->field_3b = r0
    //     0x8633f4: stur            w0, [x1, #0x3b]
    // 0x8633f8: r16 = 136
    //     0x8633f8: mov             x16, #0x88
    // 0x8633fc: stp             x16, NULL, [SP]
    // 0x863400: r0 = ByteData()
    //     0x863400: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x863404: stur            x0, [fp, #-0x10]
    // 0x863408: r0 = Paint()
    //     0x863408: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x86340c: mov             x1, x0
    // 0x863410: ldur            x0, [fp, #-0x10]
    // 0x863414: StoreField: r1->field_7 = r0
    //     0x863414: stur            w0, [x1, #7]
    // 0x863418: mov             x0, x1
    // 0x86341c: ldur            x1, [fp, #-8]
    // 0x863420: StoreField: r1->field_2b = r0
    //     0x863420: stur            w0, [x1, #0x2b]
    //     0x863424: ldurb           w16, [x1, #-1]
    //     0x863428: ldurb           w17, [x0, #-1]
    //     0x86342c: and             x16, x17, x16, lsr #2
    //     0x863430: tst             x16, HEAP, lsr #32
    //     0x863434: b.eq            #0x86343c
    //     0x863438: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x86343c: StoreField: r1->field_7 = rZR
    //     0x86343c: stur            xzr, [x1, #7]
    // 0x863440: StoreField: r1->field_13 = rZR
    //     0x863440: stur            xzr, [x1, #0x13]
    // 0x863444: StoreField: r1->field_1b = rZR
    //     0x863444: stur            xzr, [x1, #0x1b]
    // 0x863448: r0 = LoadStaticField(0x45c)
    //     0x863448: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x86344c: ldr             x0, [x0, #0x8b8]
    // 0x863450: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x863454: cmp             w0, w16
    // 0x863458: b.ne            #0x863464
    // 0x86345c: r2 = _emptyListeners
    //     0x86345c: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0x863460: r0 = InitLateFinalStaticField()
    //     0x863460: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x863464: ldur            x1, [fp, #-8]
    // 0x863468: StoreField: r1->field_f = r0
    //     0x863468: stur            w0, [x1, #0xf]
    //     0x86346c: ldurb           w16, [x1, #-1]
    //     0x863470: ldurb           w17, [x0, #-1]
    //     0x863474: and             x16, x17, x16, lsr #2
    //     0x863478: tst             x16, HEAP, lsr #32
    //     0x86347c: b.eq            #0x863484
    //     0x863480: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x863484: r0 = Null
    //     0x863484: mov             x0, NULL
    // 0x863488: LeaveFrame
    //     0x863488: mov             SP, fp
    //     0x86348c: ldp             fp, lr, [SP], #0x10
    // 0x863490: ret
    //     0x863490: ret             
    // 0x863494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863494: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863498: b               #0x8633e8
  }
  set _ floatingCursorRect=(/* No info */) {
    // ** addr: 0x868520, size: 0xa4
    // 0x868520: EnterFrame
    //     0x868520: stp             fp, lr, [SP, #-0x10]!
    //     0x868524: mov             fp, SP
    // 0x868528: AllocStack(0x20)
    //     0x868528: sub             SP, SP, #0x20
    // 0x86852c: SetupParameters(_CaretPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x86852c: stur            x1, [fp, #-8]
    //     0x868530: mov             x16, x2
    //     0x868534: mov             x2, x1
    //     0x868538: mov             x1, x16
    //     0x86853c: stur            x1, [fp, #-0x10]
    // 0x868540: CheckStackOverflow
    //     0x868540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x868544: cmp             SP, x16
    //     0x868548: b.ls            #0x8685bc
    // 0x86854c: LoadField: r0 = r2->field_43
    //     0x86854c: ldur            w0, [x2, #0x43]
    // 0x868550: DecompressPointer r0
    //     0x868550: add             x0, x0, HEAP, lsl #32
    // 0x868554: r3 = LoadClassIdInstr(r0)
    //     0x868554: ldur            x3, [x0, #-1]
    //     0x868558: ubfx            x3, x3, #0xc, #0x14
    // 0x86855c: stp             x1, x0, [SP]
    // 0x868560: mov             x0, x3
    // 0x868564: mov             lr, x0
    // 0x868568: ldr             lr, [x21, lr, lsl #3]
    // 0x86856c: blr             lr
    // 0x868570: tbnz            w0, #4, #0x868584
    // 0x868574: r0 = Null
    //     0x868574: mov             x0, NULL
    // 0x868578: LeaveFrame
    //     0x868578: mov             SP, fp
    //     0x86857c: ldp             fp, lr, [SP], #0x10
    // 0x868580: ret
    //     0x868580: ret             
    // 0x868584: ldur            x1, [fp, #-8]
    // 0x868588: ldur            x0, [fp, #-0x10]
    // 0x86858c: StoreField: r1->field_43 = r0
    //     0x86858c: stur            w0, [x1, #0x43]
    //     0x868590: ldurb           w16, [x1, #-1]
    //     0x868594: ldurb           w17, [x0, #-1]
    //     0x868598: and             x16, x17, x16, lsr #2
    //     0x86859c: tst             x16, HEAP, lsr #32
    //     0x8685a0: b.eq            #0x8685a8
    //     0x8685a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8685a8: r0 = notifyListeners()
    //     0x8685a8: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x8685ac: r0 = Null
    //     0x8685ac: mov             x0, NULL
    // 0x8685b0: LeaveFrame
    //     0x8685b0: mov             SP, fp
    //     0x8685b4: ldp             fp, lr, [SP], #0x10
    // 0x8685b8: ret
    //     0x8685b8: ret             
    // 0x8685bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8685bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8685c0: b               #0x86854c
  }
  set _ caretColor=(/* No info */) {
    // ** addr: 0x869678, size: 0x13c
    // 0x869678: EnterFrame
    //     0x869678: stp             fp, lr, [SP, #-0x10]!
    //     0x86967c: mov             fp, SP
    // 0x869680: AllocStack(0x18)
    //     0x869680: sub             SP, SP, #0x18
    // 0x869684: SetupParameters(_CaretPainter this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x869684: mov             x3, x1
    //     0x869688: stur            x1, [fp, #-8]
    //     0x86968c: stur            x2, [fp, #-0x10]
    // 0x869690: CheckStackOverflow
    //     0x869690: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x869694: cmp             SP, x16
    //     0x869698: b.ls            #0x8697ac
    // 0x86969c: LoadField: r1 = r3->field_33
    //     0x86969c: ldur            w1, [x3, #0x33]
    // 0x8696a0: DecompressPointer r1
    //     0x8696a0: add             x1, x1, HEAP, lsl #32
    // 0x8696a4: cmp             w1, NULL
    // 0x8696a8: b.ne            #0x8696b4
    // 0x8696ac: r3 = Null
    //     0x8696ac: mov             x3, NULL
    // 0x8696b0: b               #0x8696e8
    // 0x8696b4: r0 = LoadClassIdInstr(r1)
    //     0x8696b4: ldur            x0, [x1, #-1]
    //     0x8696b8: ubfx            x0, x0, #0xc, #0x14
    // 0x8696bc: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x8696bc: sub             lr, x0, #0xfb8
    //     0x8696c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8696c4: blr             lr
    // 0x8696c8: mov             x2, x0
    // 0x8696cc: r0 = BoxInt64Instr(r2)
    //     0x8696cc: sbfiz           x0, x2, #1, #0x1f
    //     0x8696d0: cmp             x2, x0, asr #1
    //     0x8696d4: b.eq            #0x8696e0
    //     0x8696d8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8696dc: stur            x2, [x0, #7]
    // 0x8696e0: mov             x3, x0
    // 0x8696e4: ldur            x2, [fp, #-0x10]
    // 0x8696e8: stur            x3, [fp, #-0x18]
    // 0x8696ec: r0 = LoadClassIdInstr(r2)
    //     0x8696ec: ldur            x0, [x2, #-1]
    //     0x8696f0: ubfx            x0, x0, #0xc, #0x14
    // 0x8696f4: mov             x1, x2
    // 0x8696f8: r0 = GDT[cid_x0 + -0xfb8]()
    //     0x8696f8: sub             lr, x0, #0xfb8
    //     0x8696fc: ldr             lr, [x21, lr, lsl #3]
    //     0x869700: blr             lr
    // 0x869704: mov             x2, x0
    // 0x869708: r0 = BoxInt64Instr(r2)
    //     0x869708: sbfiz           x0, x2, #1, #0x1f
    //     0x86970c: cmp             x2, x0, asr #1
    //     0x869710: b.eq            #0x86971c
    //     0x869714: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x869718: stur            x2, [x0, #7]
    // 0x86971c: mov             x1, x0
    // 0x869720: ldur            x0, [fp, #-0x18]
    // 0x869724: cmp             w0, w1
    // 0x869728: b.eq            #0x869764
    // 0x86972c: and             w16, w0, w1
    // 0x869730: branchIfSmi(r16, 0x869774)
    //     0x869730: tbz             w16, #0, #0x869774
    // 0x869734: r16 = LoadClassIdInstr(r0)
    //     0x869734: ldur            x16, [x0, #-1]
    //     0x869738: ubfx            x16, x16, #0xc, #0x14
    // 0x86973c: cmp             x16, #0x3d
    // 0x869740: b.ne            #0x869774
    // 0x869744: r16 = LoadClassIdInstr(r1)
    //     0x869744: ldur            x16, [x1, #-1]
    //     0x869748: ubfx            x16, x16, #0xc, #0x14
    // 0x86974c: cmp             x16, #0x3d
    // 0x869750: b.ne            #0x869774
    // 0x869754: LoadField: r16 = r0->field_7
    //     0x869754: ldur            x16, [x0, #7]
    // 0x869758: LoadField: r17 = r1->field_7
    //     0x869758: ldur            x17, [x1, #7]
    // 0x86975c: cmp             x16, x17
    // 0x869760: b.ne            #0x869774
    // 0x869764: r0 = Null
    //     0x869764: mov             x0, NULL
    // 0x869768: LeaveFrame
    //     0x869768: mov             SP, fp
    //     0x86976c: ldp             fp, lr, [SP], #0x10
    // 0x869770: ret
    //     0x869770: ret             
    // 0x869774: ldur            x1, [fp, #-8]
    // 0x869778: ldur            x0, [fp, #-0x10]
    // 0x86977c: StoreField: r1->field_33 = r0
    //     0x86977c: stur            w0, [x1, #0x33]
    //     0x869780: ldurb           w16, [x1, #-1]
    //     0x869784: ldurb           w17, [x0, #-1]
    //     0x869788: and             x16, x17, x16, lsr #2
    //     0x86978c: tst             x16, HEAP, lsr #32
    //     0x869790: b.eq            #0x869798
    //     0x869794: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x869798: r0 = notifyListeners()
    //     0x869798: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x86979c: r0 = Null
    //     0x86979c: mov             x0, NULL
    // 0x8697a0: LeaveFrame
    //     0x8697a0: mov             SP, fp
    //     0x8697a4: ldp             fp, lr, [SP], #0x10
    // 0x8697a8: ret
    //     0x8697a8: ret             
    // 0x8697ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8697ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8697b0: b               #0x86969c
  }
  set _ shouldPaint=(/* No info */) {
    // ** addr: 0xc06c24, size: 0x54
    // 0xc06c24: EnterFrame
    //     0xc06c24: stp             fp, lr, [SP, #-0x10]!
    //     0xc06c28: mov             fp, SP
    // 0xc06c2c: CheckStackOverflow
    //     0xc06c2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06c30: cmp             SP, x16
    //     0xc06c34: b.ls            #0xc06c70
    // 0xc06c38: LoadField: r0 = r1->field_23
    //     0xc06c38: ldur            w0, [x1, #0x23]
    // 0xc06c3c: DecompressPointer r0
    //     0xc06c3c: add             x0, x0, HEAP, lsl #32
    // 0xc06c40: cmp             w0, w2
    // 0xc06c44: b.ne            #0xc06c58
    // 0xc06c48: r0 = Null
    //     0xc06c48: mov             x0, NULL
    // 0xc06c4c: LeaveFrame
    //     0xc06c4c: mov             SP, fp
    //     0xc06c50: ldp             fp, lr, [SP], #0x10
    // 0xc06c54: ret
    //     0xc06c54: ret             
    // 0xc06c58: StoreField: r1->field_23 = r2
    //     0xc06c58: stur            w2, [x1, #0x23]
    // 0xc06c5c: r0 = notifyListeners()
    //     0xc06c5c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xc06c60: r0 = Null
    //     0xc06c60: mov             x0, NULL
    // 0xc06c64: LeaveFrame
    //     0xc06c64: mov             SP, fp
    //     0xc06c68: ldp             fp, lr, [SP], #0x10
    // 0xc06c6c: ret
    //     0xc06c6c: ret             
    // 0xc06c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06c70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06c74: b               #0xc06c38
  }
  set _ cursorOffset=(/* No info */) {
    // ** addr: 0xcf0c94, size: 0x88
    // 0xcf0c94: EnterFrame
    //     0xcf0c94: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0c98: mov             fp, SP
    // 0xcf0c9c: AllocStack(0x20)
    //     0xcf0c9c: sub             SP, SP, #0x20
    // 0xcf0ca0: SetupParameters(_CaretPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf0ca0: mov             x0, x2
    //     0xcf0ca4: stur            x1, [fp, #-8]
    //     0xcf0ca8: stur            x2, [fp, #-0x10]
    // 0xcf0cac: CheckStackOverflow
    //     0xcf0cac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0cb0: cmp             SP, x16
    //     0xcf0cb4: b.ls            #0xcf0d14
    // 0xcf0cb8: LoadField: r2 = r1->field_3b
    //     0xcf0cb8: ldur            w2, [x1, #0x3b]
    // 0xcf0cbc: DecompressPointer r2
    //     0xcf0cbc: add             x2, x2, HEAP, lsl #32
    // 0xcf0cc0: stp             x0, x2, [SP]
    // 0xcf0cc4: r0 = ==()
    //     0xcf0cc4: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xcf0cc8: tbnz            w0, #4, #0xcf0cdc
    // 0xcf0ccc: r0 = Null
    //     0xcf0ccc: mov             x0, NULL
    // 0xcf0cd0: LeaveFrame
    //     0xcf0cd0: mov             SP, fp
    //     0xcf0cd4: ldp             fp, lr, [SP], #0x10
    // 0xcf0cd8: ret
    //     0xcf0cd8: ret             
    // 0xcf0cdc: ldur            x1, [fp, #-8]
    // 0xcf0ce0: ldur            x0, [fp, #-0x10]
    // 0xcf0ce4: StoreField: r1->field_3b = r0
    //     0xcf0ce4: stur            w0, [x1, #0x3b]
    //     0xcf0ce8: ldurb           w16, [x1, #-1]
    //     0xcf0cec: ldurb           w17, [x0, #-1]
    //     0xcf0cf0: and             x16, x17, x16, lsr #2
    //     0xcf0cf4: tst             x16, HEAP, lsr #32
    //     0xcf0cf8: b.eq            #0xcf0d00
    //     0xcf0cfc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf0d00: r0 = notifyListeners()
    //     0xcf0d00: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcf0d04: r0 = Null
    //     0xcf0d04: mov             x0, NULL
    // 0xcf0d08: LeaveFrame
    //     0xcf0d08: mov             SP, fp
    //     0xcf0d0c: ldp             fp, lr, [SP], #0x10
    // 0xcf0d10: ret
    //     0xcf0d10: ret             
    // 0xcf0d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0d14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0d18: b               #0xcf0cb8
  }
  set _ backgroundCursorColor=(/* No info */) {
    // ** addr: 0xcf1770, size: 0x124
    // 0xcf1770: EnterFrame
    //     0xcf1770: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1774: mov             fp, SP
    // 0xcf1778: AllocStack(0x10)
    //     0xcf1778: sub             SP, SP, #0x10
    // 0xcf177c: SetupParameters(_CaretPainter this /* r1 => r3, fp-0x8 */)
    //     0xcf177c: mov             x3, x1
    //     0xcf1780: stur            x1, [fp, #-8]
    // 0xcf1784: CheckStackOverflow
    //     0xcf1784: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1788: cmp             SP, x16
    //     0xcf178c: b.ls            #0xcf188c
    // 0xcf1790: LoadField: r0 = r3->field_3f
    //     0xcf1790: ldur            w0, [x3, #0x3f]
    // 0xcf1794: DecompressPointer r0
    //     0xcf1794: add             x0, x0, HEAP, lsl #32
    // 0xcf1798: cmp             w0, NULL
    // 0xcf179c: b.ne            #0xcf17a8
    // 0xcf17a0: r0 = Null
    //     0xcf17a0: mov             x0, NULL
    // 0xcf17a4: b               #0xcf17dc
    // 0xcf17a8: LoadField: r1 = r0->field_7
    //     0xcf17a8: ldur            w1, [x0, #7]
    // 0xcf17ac: DecompressPointer r1
    //     0xcf17ac: add             x1, x1, HEAP, lsl #32
    // 0xcf17b0: r0 = LoadClassIdInstr(r1)
    //     0xcf17b0: ldur            x0, [x1, #-1]
    //     0xcf17b4: ubfx            x0, x0, #0xc, #0x14
    // 0xcf17b8: r0 = GDT[cid_x0 + -0xfb8]()
    //     0xcf17b8: sub             lr, x0, #0xfb8
    //     0xcf17bc: ldr             lr, [x21, lr, lsl #3]
    //     0xcf17c0: blr             lr
    // 0xcf17c4: mov             x2, x0
    // 0xcf17c8: r0 = BoxInt64Instr(r2)
    //     0xcf17c8: sbfiz           x0, x2, #1, #0x1f
    //     0xcf17cc: cmp             x2, x0, asr #1
    //     0xcf17d0: b.eq            #0xcf17dc
    //     0xcf17d4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xcf17d8: stur            x2, [x0, #7]
    // 0xcf17dc: stur            x0, [fp, #-0x10]
    // 0xcf17e0: r1 = Instance_Color
    //     0xcf17e0: add             x1, PP, #0x14, lsl #12  ; [pp+0x14218] Obj!Color@12a2911
    //     0xcf17e4: ldr             x1, [x1, #0x218]
    // 0xcf17e8: r0 = toARGB32()
    //     0xcf17e8: bl              #0x119defc  ; [dart:ui] Color::toARGB32
    // 0xcf17ec: mov             x2, x0
    // 0xcf17f0: r0 = BoxInt64Instr(r2)
    //     0xcf17f0: sbfiz           x0, x2, #1, #0x1f
    //     0xcf17f4: cmp             x2, x0, asr #1
    //     0xcf17f8: b.eq            #0xcf1804
    //     0xcf17fc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xcf1800: stur            x2, [x0, #7]
    // 0xcf1804: mov             x1, x0
    // 0xcf1808: ldur            x0, [fp, #-0x10]
    // 0xcf180c: cmp             w0, w1
    // 0xcf1810: b.eq            #0xcf184c
    // 0xcf1814: and             w16, w0, w1
    // 0xcf1818: branchIfSmi(r16, 0xcf185c)
    //     0xcf1818: tbz             w16, #0, #0xcf185c
    // 0xcf181c: r16 = LoadClassIdInstr(r0)
    //     0xcf181c: ldur            x16, [x0, #-1]
    //     0xcf1820: ubfx            x16, x16, #0xc, #0x14
    // 0xcf1824: cmp             x16, #0x3d
    // 0xcf1828: b.ne            #0xcf185c
    // 0xcf182c: r16 = LoadClassIdInstr(r1)
    //     0xcf182c: ldur            x16, [x1, #-1]
    //     0xcf1830: ubfx            x16, x16, #0xc, #0x14
    // 0xcf1834: cmp             x16, #0x3d
    // 0xcf1838: b.ne            #0xcf185c
    // 0xcf183c: LoadField: r16 = r0->field_7
    //     0xcf183c: ldur            x16, [x0, #7]
    // 0xcf1840: LoadField: r17 = r1->field_7
    //     0xcf1840: ldur            x17, [x1, #7]
    // 0xcf1844: cmp             x16, x17
    // 0xcf1848: b.ne            #0xcf185c
    // 0xcf184c: r0 = Null
    //     0xcf184c: mov             x0, NULL
    // 0xcf1850: LeaveFrame
    //     0xcf1850: mov             SP, fp
    //     0xcf1854: ldp             fp, lr, [SP], #0x10
    // 0xcf1858: ret
    //     0xcf1858: ret             
    // 0xcf185c: ldur            x1, [fp, #-8]
    // 0xcf1860: r0 = Instance_CupertinoDynamicColor
    //     0xcf1860: add             x0, PP, #0x26, lsl #12  ; [pp+0x26b50] Obj!CupertinoDynamicColor@12b36f1
    //     0xcf1864: ldr             x0, [x0, #0xb50]
    // 0xcf1868: StoreField: r1->field_3f = r0
    //     0xcf1868: stur            w0, [x1, #0x3f]
    // 0xcf186c: LoadField: r0 = r1->field_27
    //     0xcf186c: ldur            w0, [x1, #0x27]
    // 0xcf1870: DecompressPointer r0
    //     0xcf1870: add             x0, x0, HEAP, lsl #32
    // 0xcf1874: tbnz            w0, #4, #0xcf187c
    // 0xcf1878: r0 = notifyListeners()
    //     0xcf1878: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcf187c: r0 = Null
    //     0xcf187c: mov             x0, NULL
    // 0xcf1880: LeaveFrame
    //     0xcf1880: mov             SP, fp
    //     0xcf1884: ldp             fp, lr, [SP], #0x10
    // 0xcf1888: ret
    //     0xcf1888: ret             
    // 0xcf188c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf188c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1890: b               #0xcf1790
  }
  Paint floatingCursorPaint(_CaretPainter) {
    // ** addr: 0xf34608, size: 0x48
    // 0xf34608: EnterFrame
    //     0xf34608: stp             fp, lr, [SP, #-0x10]!
    //     0xf3460c: mov             fp, SP
    // 0xf34610: AllocStack(0x18)
    //     0xf34610: sub             SP, SP, #0x18
    // 0xf34614: CheckStackOverflow
    //     0xf34614: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xf34618: cmp             SP, x16
    //     0xf3461c: b.ls            #0xf34648
    // 0xf34620: r16 = 136
    //     0xf34620: mov             x16, #0x88
    // 0xf34624: stp             x16, NULL, [SP]
    // 0xf34628: r0 = ByteData()
    //     0xf34628: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xf3462c: stur            x0, [fp, #-8]
    // 0xf34630: r0 = Paint()
    //     0xf34630: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xf34634: ldur            x1, [fp, #-8]
    // 0xf34638: StoreField: r0->field_7 = r1
    //     0xf34638: stur            w1, [x0, #7]
    // 0xf3463c: LeaveFrame
    //     0xf3463c: mov             SP, fp
    //     0xf34640: ldp             fp, lr, [SP], #0x10
    // 0xf34644: ret
    //     0xf34644: ret             
    // 0xf34648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xf34648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xf3464c: b               #0xf34620
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x11a1660, size: 0x198
    // 0x11a1660: EnterFrame
    //     0x11a1660: stp             fp, lr, [SP, #-0x10]!
    //     0x11a1664: mov             fp, SP
    // 0x11a1668: AllocStack(0x20)
    //     0x11a1668: sub             SP, SP, #0x20
    // 0x11a166c: SetupParameters(_CaretPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11a166c: stur            x1, [fp, #-8]
    //     0x11a1670: stur            x2, [fp, #-0x10]
    // 0x11a1674: CheckStackOverflow
    //     0x11a1674: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a1678: cmp             SP, x16
    //     0x11a167c: b.ls            #0x11a17f0
    // 0x11a1680: cmp             w1, w2
    // 0x11a1684: b.ne            #0x11a1698
    // 0x11a1688: r0 = false
    //     0x11a1688: add             x0, NULL, #0x30  ; false
    // 0x11a168c: LeaveFrame
    //     0x11a168c: mov             SP, fp
    //     0x11a1690: ldp             fp, lr, [SP], #0x10
    // 0x11a1694: ret
    //     0x11a1694: ret             
    // 0x11a1698: r0 = LoadClassIdInstr(r2)
    //     0x11a1698: ldur            x0, [x2, #-1]
    //     0x11a169c: ubfx            x0, x0, #0xc, #0x14
    // 0x11a16a0: r17 = 4481
    //     0x11a16a0: mov             x17, #0x1181
    // 0x11a16a4: cmp             x0, x17
    // 0x11a16a8: b.ne            #0x11a17a0
    // 0x11a16ac: LoadField: r0 = r2->field_23
    //     0x11a16ac: ldur            w0, [x2, #0x23]
    // 0x11a16b0: DecompressPointer r0
    //     0x11a16b0: add             x0, x0, HEAP, lsl #32
    // 0x11a16b4: LoadField: r3 = r1->field_23
    //     0x11a16b4: ldur            w3, [x1, #0x23]
    // 0x11a16b8: DecompressPointer r3
    //     0x11a16b8: add             x3, x3, HEAP, lsl #32
    // 0x11a16bc: cmp             w0, w3
    // 0x11a16c0: b.ne            #0x11a17a0
    // 0x11a16c4: LoadField: r0 = r2->field_27
    //     0x11a16c4: ldur            w0, [x2, #0x27]
    // 0x11a16c8: DecompressPointer r0
    //     0x11a16c8: add             x0, x0, HEAP, lsl #32
    // 0x11a16cc: LoadField: r3 = r1->field_27
    //     0x11a16cc: ldur            w3, [x1, #0x27]
    // 0x11a16d0: DecompressPointer r3
    //     0x11a16d0: add             x3, x3, HEAP, lsl #32
    // 0x11a16d4: cmp             w0, w3
    // 0x11a16d8: b.ne            #0x11a17a0
    // 0x11a16dc: LoadField: r0 = r2->field_33
    //     0x11a16dc: ldur            w0, [x2, #0x33]
    // 0x11a16e0: DecompressPointer r0
    //     0x11a16e0: add             x0, x0, HEAP, lsl #32
    // 0x11a16e4: LoadField: r3 = r1->field_33
    //     0x11a16e4: ldur            w3, [x1, #0x33]
    // 0x11a16e8: DecompressPointer r3
    //     0x11a16e8: add             x3, x3, HEAP, lsl #32
    // 0x11a16ec: r4 = LoadClassIdInstr(r0)
    //     0x11a16ec: ldur            x4, [x0, #-1]
    //     0x11a16f0: ubfx            x4, x4, #0xc, #0x14
    // 0x11a16f4: stp             x3, x0, [SP]
    // 0x11a16f8: mov             x0, x4
    // 0x11a16fc: mov             lr, x0
    // 0x11a1700: ldr             lr, [x21, lr, lsl #3]
    // 0x11a1704: blr             lr
    // 0x11a1708: tbnz            w0, #4, #0x11a17a0
    // 0x11a170c: ldur            x2, [fp, #-8]
    // 0x11a1710: ldur            x1, [fp, #-0x10]
    // 0x11a1714: LoadField: r0 = r1->field_37
    //     0x11a1714: ldur            w0, [x1, #0x37]
    // 0x11a1718: DecompressPointer r0
    //     0x11a1718: add             x0, x0, HEAP, lsl #32
    // 0x11a171c: LoadField: r3 = r2->field_37
    //     0x11a171c: ldur            w3, [x2, #0x37]
    // 0x11a1720: DecompressPointer r3
    //     0x11a1720: add             x3, x3, HEAP, lsl #32
    // 0x11a1724: r4 = LoadClassIdInstr(r0)
    //     0x11a1724: ldur            x4, [x0, #-1]
    //     0x11a1728: ubfx            x4, x4, #0xc, #0x14
    // 0x11a172c: stp             x3, x0, [SP]
    // 0x11a1730: mov             x0, x4
    // 0x11a1734: mov             lr, x0
    // 0x11a1738: ldr             lr, [x21, lr, lsl #3]
    // 0x11a173c: blr             lr
    // 0x11a1740: tbnz            w0, #4, #0x11a17a0
    // 0x11a1744: ldur            x1, [fp, #-8]
    // 0x11a1748: ldur            x0, [fp, #-0x10]
    // 0x11a174c: LoadField: r2 = r0->field_3b
    //     0x11a174c: ldur            w2, [x0, #0x3b]
    // 0x11a1750: DecompressPointer r2
    //     0x11a1750: add             x2, x2, HEAP, lsl #32
    // 0x11a1754: LoadField: r3 = r1->field_3b
    //     0x11a1754: ldur            w3, [x1, #0x3b]
    // 0x11a1758: DecompressPointer r3
    //     0x11a1758: add             x3, x3, HEAP, lsl #32
    // 0x11a175c: stp             x3, x2, [SP]
    // 0x11a1760: r0 = ==()
    //     0x11a1760: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x11a1764: tbnz            w0, #4, #0x11a17a0
    // 0x11a1768: ldur            x2, [fp, #-8]
    // 0x11a176c: ldur            x1, [fp, #-0x10]
    // 0x11a1770: LoadField: r0 = r1->field_3f
    //     0x11a1770: ldur            w0, [x1, #0x3f]
    // 0x11a1774: DecompressPointer r0
    //     0x11a1774: add             x0, x0, HEAP, lsl #32
    // 0x11a1778: LoadField: r3 = r2->field_3f
    //     0x11a1778: ldur            w3, [x2, #0x3f]
    // 0x11a177c: DecompressPointer r3
    //     0x11a177c: add             x3, x3, HEAP, lsl #32
    // 0x11a1780: r4 = LoadClassIdInstr(r0)
    //     0x11a1780: ldur            x4, [x0, #-1]
    //     0x11a1784: ubfx            x4, x4, #0xc, #0x14
    // 0x11a1788: stp             x3, x0, [SP]
    // 0x11a178c: mov             x0, x4
    // 0x11a1790: mov             lr, x0
    // 0x11a1794: ldr             lr, [x21, lr, lsl #3]
    // 0x11a1798: blr             lr
    // 0x11a179c: tbz             w0, #4, #0x11a17a8
    // 0x11a17a0: r0 = true
    //     0x11a17a0: add             x0, NULL, #0x20  ; true
    // 0x11a17a4: b               #0x11a17e4
    // 0x11a17a8: ldur            x1, [fp, #-8]
    // 0x11a17ac: ldur            x0, [fp, #-0x10]
    // 0x11a17b0: LoadField: r2 = r0->field_43
    //     0x11a17b0: ldur            w2, [x0, #0x43]
    // 0x11a17b4: DecompressPointer r2
    //     0x11a17b4: add             x2, x2, HEAP, lsl #32
    // 0x11a17b8: LoadField: r0 = r1->field_43
    //     0x11a17b8: ldur            w0, [x1, #0x43]
    // 0x11a17bc: DecompressPointer r0
    //     0x11a17bc: add             x0, x0, HEAP, lsl #32
    // 0x11a17c0: r1 = LoadClassIdInstr(r2)
    //     0x11a17c0: ldur            x1, [x2, #-1]
    //     0x11a17c4: ubfx            x1, x1, #0xc, #0x14
    // 0x11a17c8: stp             x0, x2, [SP]
    // 0x11a17cc: mov             x0, x1
    // 0x11a17d0: mov             lr, x0
    // 0x11a17d4: ldr             lr, [x21, lr, lsl #3]
    // 0x11a17d8: blr             lr
    // 0x11a17dc: eor             x1, x0, #0x10
    // 0x11a17e0: mov             x0, x1
    // 0x11a17e4: LeaveFrame
    //     0x11a17e4: mov             SP, fp
    //     0x11a17e8: ldp             fp, lr, [SP], #0x10
    // 0x11a17ec: ret
    //     0x11a17ec: ret             
    // 0x11a17f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a17f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a17f4: b               #0x11a1680
  }
  _ paint(/* No info */) {
    // ** addr: 0x122ef84, size: 0x1d8
    // 0x122ef84: EnterFrame
    //     0x122ef84: stp             fp, lr, [SP, #-0x10]!
    //     0x122ef88: mov             fp, SP
    // 0x122ef8c: AllocStack(0x28)
    //     0x122ef8c: sub             SP, SP, #0x28
    // 0x122ef90: SetupParameters(_CaretPainter this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0x122ef90: mov             x0, x1
    //     0x122ef94: stur            x1, [fp, #-0x18]
    //     0x122ef98: stur            x2, [fp, #-0x20]
    //     0x122ef9c: stur            x3, [fp, #-0x28]
    // 0x122efa0: CheckStackOverflow
    //     0x122efa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122efa4: cmp             SP, x16
    //     0x122efa8: b.ls            #0x122f148
    // 0x122efac: LoadField: r1 = r3->field_d7
    //     0x122efac: ldur            w1, [x3, #0xd7]
    // 0x122efb0: DecompressPointer r1
    //     0x122efb0: add             x1, x1, HEAP, lsl #32
    // 0x122efb4: LoadField: r4 = r1->field_7
    //     0x122efb4: ldur            x4, [x1, #7]
    // 0x122efb8: LoadField: r5 = r1->field_f
    //     0x122efb8: ldur            x5, [x1, #0xf]
    // 0x122efbc: cmp             x4, x5
    // 0x122efc0: b.ne            #0x122f138
    // 0x122efc4: tbnz            x4, #0x3f, #0x122f138
    // 0x122efc8: tbnz            x5, #0x3f, #0x122f138
    // 0x122efcc: LoadField: r4 = r0->field_43
    //     0x122efcc: ldur            w4, [x0, #0x43]
    // 0x122efd0: DecompressPointer r4
    //     0x122efd0: add             x4, x4, HEAP, lsl #32
    // 0x122efd4: stur            x4, [fp, #-0x10]
    // 0x122efd8: cmp             w4, NULL
    // 0x122efdc: b.ne            #0x122efec
    // 0x122efe0: LoadField: r5 = r0->field_33
    //     0x122efe0: ldur            w5, [x0, #0x33]
    // 0x122efe4: DecompressPointer r5
    //     0x122efe4: add             x5, x5, HEAP, lsl #32
    // 0x122efe8: b               #0x122f008
    // 0x122efec: LoadField: r5 = r0->field_27
    //     0x122efec: ldur            w5, [x0, #0x27]
    // 0x122eff0: DecompressPointer r5
    //     0x122eff0: add             x5, x5, HEAP, lsl #32
    // 0x122eff4: tbnz            w5, #4, #0x122f004
    // 0x122eff8: LoadField: r5 = r0->field_3f
    //     0x122eff8: ldur            w5, [x0, #0x3f]
    // 0x122effc: DecompressPointer r5
    //     0x122effc: add             x5, x5, HEAP, lsl #32
    // 0x122f000: b               #0x122f008
    // 0x122f004: r5 = Null
    //     0x122f004: mov             x5, NULL
    // 0x122f008: stur            x5, [fp, #-8]
    // 0x122f00c: cmp             w4, NULL
    // 0x122f010: b.ne            #0x122f024
    // 0x122f014: r0 = extent()
    //     0x122f014: bl              #0x85fb94  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x122f018: mov             x6, x0
    // 0x122f01c: ldur            x3, [fp, #-0x28]
    // 0x122f020: b               #0x122f03c
    // 0x122f024: LoadField: r0 = r3->field_ff
    //     0x122f024: ldur            w0, [x3, #0xff]
    // 0x122f028: DecompressPointer r0
    //     0x122f028: add             x0, x0, HEAP, lsl #32
    // 0x122f02c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x122f030: cmp             w0, w16
    // 0x122f034: b.eq            #0x122f150
    // 0x122f038: mov             x6, x0
    // 0x122f03c: ldur            x5, [fp, #-8]
    // 0x122f040: cmp             w5, NULL
    // 0x122f044: b.eq            #0x122f054
    // 0x122f048: ldur            x1, [fp, #-0x18]
    // 0x122f04c: ldur            x2, [fp, #-0x20]
    // 0x122f050: r0 = paintRegularCursor()
    //     0x122f050: bl              #0x122f15c  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::paintRegularCursor
    // 0x122f054: ldur            x2, [fp, #-0x18]
    // 0x122f058: LoadField: r1 = r2->field_33
    //     0x122f058: ldur            w1, [x2, #0x33]
    // 0x122f05c: DecompressPointer r1
    //     0x122f05c: add             x1, x1, HEAP, lsl #32
    // 0x122f060: cmp             w1, NULL
    // 0x122f064: b.ne            #0x122f070
    // 0x122f068: r0 = Null
    //     0x122f068: mov             x0, NULL
    // 0x122f06c: b               #0x122f088
    // 0x122f070: r0 = LoadClassIdInstr(r1)
    //     0x122f070: ldur            x0, [x1, #-1]
    //     0x122f074: ubfx            x0, x0, #0xc, #0x14
    // 0x122f078: d0 = 0.750000
    //     0x122f078: fmov            d0, #0.75000000
    // 0x122f07c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x122f07c: sub             lr, x0, #1, lsl #12
    //     0x122f080: ldr             lr, [x21, lr, lsl #3]
    //     0x122f084: blr             lr
    // 0x122f088: ldur            x2, [fp, #-0x10]
    // 0x122f08c: stur            x0, [fp, #-8]
    // 0x122f090: cmp             w2, NULL
    // 0x122f094: b.eq            #0x122f0b0
    // 0x122f098: cmp             w0, NULL
    // 0x122f09c: b.eq            #0x122f0b0
    // 0x122f0a0: ldur            x3, [fp, #-0x18]
    // 0x122f0a4: LoadField: r1 = r3->field_23
    //     0x122f0a4: ldur            w1, [x3, #0x23]
    // 0x122f0a8: DecompressPointer r1
    //     0x122f0a8: add             x1, x1, HEAP, lsl #32
    // 0x122f0ac: tbz             w1, #4, #0x122f0c0
    // 0x122f0b0: r0 = Null
    //     0x122f0b0: mov             x0, NULL
    // 0x122f0b4: LeaveFrame
    //     0x122f0b4: mov             SP, fp
    //     0x122f0b8: ldp             fp, lr, [SP], #0x10
    // 0x122f0bc: ret
    //     0x122f0bc: ret             
    // 0x122f0c0: r1 = <RRect>
    //     0x122f0c0: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x122f0c4: ldr             x1, [x1, #0x108]
    // 0x122f0c8: r0 = RRect()
    //     0x122f0c8: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x122f0cc: mov             x1, x0
    // 0x122f0d0: ldur            x2, [fp, #-0x10]
    // 0x122f0d4: r3 = Instance_Radius
    //     0x122f0d4: add             x3, PP, #0xa0, lsl #12  ; [pp+0xa0fe8] Obj!Radius@12a7141
    //     0x122f0d8: ldr             x3, [x3, #0xfe8]
    // 0x122f0dc: stur            x0, [fp, #-0x10]
    // 0x122f0e0: r0 = RRect.fromRectAndRadius()
    //     0x122f0e0: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x122f0e4: ldur            x1, [fp, #-0x18]
    // 0x122f0e8: LoadField: r0 = r1->field_2f
    //     0x122f0e8: ldur            w0, [x1, #0x2f]
    // 0x122f0ec: DecompressPointer r0
    //     0x122f0ec: add             x0, x0, HEAP, lsl #32
    // 0x122f0f0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x122f0f4: cmp             w0, w16
    // 0x122f0f8: b.ne            #0x122f108
    // 0x122f0fc: r2 = floatingCursorPaint
    //     0x122f0fc: add             x2, PP, #0xd0, lsl #12  ; [pp+0xd05d0] Field <_CaretPainter@80245603.floatingCursorPaint>: late final (offset: 0x30)
    //     0x122f100: ldr             x2, [x2, #0x5d0]
    // 0x122f104: r0 = InitLateFinalInstanceField()
    //     0x122f104: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x122f108: mov             x1, x0
    // 0x122f10c: ldur            x2, [fp, #-8]
    // 0x122f110: stur            x0, [fp, #-8]
    // 0x122f114: r0 = color=()
    //     0x122f114: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x122f118: ldur            x1, [fp, #-0x20]
    // 0x122f11c: ldur            x2, [fp, #-0x10]
    // 0x122f120: ldur            x3, [fp, #-8]
    // 0x122f124: r0 = drawRRect()
    //     0x122f124: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x122f128: r0 = Null
    //     0x122f128: mov             x0, NULL
    // 0x122f12c: LeaveFrame
    //     0x122f12c: mov             SP, fp
    //     0x122f130: ldp             fp, lr, [SP], #0x10
    // 0x122f134: ret
    //     0x122f134: ret             
    // 0x122f138: r0 = Null
    //     0x122f138: mov             x0, NULL
    // 0x122f13c: LeaveFrame
    //     0x122f13c: mov             SP, fp
    //     0x122f140: ldp             fp, lr, [SP], #0x10
    // 0x122f144: ret
    //     0x122f144: ret             
    // 0x122f148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122f148: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122f14c: b               #0x122efac
    // 0x122f150: r9 = _floatingCursorTextPosition
    //     0x122f150: add             x9, PP, #0xd0, lsl #12  ; [pp+0xd05d8] Field <RenderEditable._floatingCursorTextPosition@80245603>: late (offset: 0x100)
    //     0x122f154: ldr             x9, [x9, #0x5d8]
    // 0x122f158: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x122f158: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ paintRegularCursor(/* No info */) {
    // ** addr: 0x122f15c, size: 0x144
    // 0x122f15c: EnterFrame
    //     0x122f15c: stp             fp, lr, [SP, #-0x10]!
    //     0x122f160: mov             fp, SP
    // 0x122f164: AllocStack(0x30)
    //     0x122f164: sub             SP, SP, #0x30
    // 0x122f168: SetupParameters(_CaretPainter this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r1 */, dynamic _ /* r5 => r0, fp-0x18 */, dynamic _ /* r6 => r2 */)
    //     0x122f168: mov             x4, x1
    //     0x122f16c: stur            x1, [fp, #-8]
    //     0x122f170: mov             x1, x3
    //     0x122f174: mov             x3, x2
    //     0x122f178: mov             x0, x5
    //     0x122f17c: stur            x2, [fp, #-0x10]
    //     0x122f180: mov             x2, x6
    //     0x122f184: stur            x5, [fp, #-0x18]
    // 0x122f188: CheckStackOverflow
    //     0x122f188: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122f18c: cmp             SP, x16
    //     0x122f190: b.ls            #0x122f298
    // 0x122f194: r0 = getLocalRectForCaret()
    //     0x122f194: bl              #0x862c30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::getLocalRectForCaret
    // 0x122f198: mov             x2, x0
    // 0x122f19c: ldur            x0, [fp, #-8]
    // 0x122f1a0: stur            x2, [fp, #-0x20]
    // 0x122f1a4: LoadField: r1 = r0->field_23
    //     0x122f1a4: ldur            w1, [x0, #0x23]
    // 0x122f1a8: DecompressPointer r1
    //     0x122f1a8: add             x1, x1, HEAP, lsl #32
    // 0x122f1ac: tbnz            w1, #4, #0x122f288
    // 0x122f1b0: LoadField: r1 = r0->field_43
    //     0x122f1b0: ldur            w1, [x0, #0x43]
    // 0x122f1b4: DecompressPointer r1
    //     0x122f1b4: add             x1, x1, HEAP, lsl #32
    // 0x122f1b8: cmp             w1, NULL
    // 0x122f1bc: b.eq            #0x122f210
    // 0x122f1c0: r0 = center()
    //     0x122f1c0: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x122f1c4: ldur            x1, [fp, #-0x20]
    // 0x122f1c8: stur            x0, [fp, #-0x28]
    // 0x122f1cc: r0 = center()
    //     0x122f1cc: bl              #0x869350  ; [dart:ui] Rect::center
    // 0x122f1d0: ldur            x1, [fp, #-0x28]
    // 0x122f1d4: mov             x2, x0
    // 0x122f1d8: r0 = -()
    //     0x122f1d8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x122f1dc: LoadField: d0 = r0->field_7
    //     0x122f1dc: ldur            d0, [x0, #7]
    // 0x122f1e0: fmul            d1, d0, d0
    // 0x122f1e4: LoadField: d0 = r0->field_f
    //     0x122f1e4: ldur            d0, [x0, #0xf]
    // 0x122f1e8: fmul            d2, d0, d0
    // 0x122f1ec: fadd            d0, d1, d2
    // 0x122f1f0: d1 = 225.000000
    //     0x122f1f0: add             x17, PP, #0xc8, lsl #12  ; [pp+0xc85f8] IMM: double(225) from 0x406c200000000000
    //     0x122f1f4: ldr             d1, [x17, #0x5f8]
    // 0x122f1f8: fcmp            d1, d0
    // 0x122f1fc: b.le            #0x122f210
    // 0x122f200: r0 = Null
    //     0x122f200: mov             x0, NULL
    // 0x122f204: LeaveFrame
    //     0x122f204: mov             SP, fp
    //     0x122f208: ldp             fp, lr, [SP], #0x10
    // 0x122f20c: ret
    //     0x122f20c: ret             
    // 0x122f210: ldur            x0, [fp, #-8]
    // 0x122f214: LoadField: r3 = r0->field_37
    //     0x122f214: ldur            w3, [x0, #0x37]
    // 0x122f218: DecompressPointer r3
    //     0x122f218: add             x3, x3, HEAP, lsl #32
    // 0x122f21c: stur            x3, [fp, #-0x30]
    // 0x122f220: LoadField: r4 = r0->field_2b
    //     0x122f220: ldur            w4, [x0, #0x2b]
    // 0x122f224: DecompressPointer r4
    //     0x122f224: add             x4, x4, HEAP, lsl #32
    // 0x122f228: mov             x1, x4
    // 0x122f22c: ldur            x2, [fp, #-0x18]
    // 0x122f230: stur            x4, [fp, #-0x28]
    // 0x122f234: r0 = color=()
    //     0x122f234: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x122f238: ldur            x3, [fp, #-0x30]
    // 0x122f23c: cmp             w3, NULL
    // 0x122f240: b.ne            #0x122f258
    // 0x122f244: ldur            x1, [fp, #-0x10]
    // 0x122f248: ldur            x2, [fp, #-0x20]
    // 0x122f24c: ldur            x3, [fp, #-0x28]
    // 0x122f250: r0 = drawRect()
    //     0x122f250: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x122f254: b               #0x122f288
    // 0x122f258: r1 = <RRect>
    //     0x122f258: add             x1, PP, #0x85, lsl #12  ; [pp+0x85108] TypeArguments: <RRect>
    //     0x122f25c: ldr             x1, [x1, #0x108]
    // 0x122f260: r0 = RRect()
    //     0x122f260: bl              #0xb6e214  ; AllocateRRectStub -> RRect (size=0x6c)
    // 0x122f264: mov             x1, x0
    // 0x122f268: ldur            x2, [fp, #-0x20]
    // 0x122f26c: ldur            x3, [fp, #-0x30]
    // 0x122f270: stur            x0, [fp, #-8]
    // 0x122f274: r0 = RRect.fromRectAndRadius()
    //     0x122f274: bl              #0xb6e920  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x122f278: ldur            x1, [fp, #-0x10]
    // 0x122f27c: ldur            x2, [fp, #-8]
    // 0x122f280: ldur            x3, [fp, #-0x28]
    // 0x122f284: r0 = drawRRect()
    //     0x122f284: bl              #0xb6dce0  ; [dart:ui] _NativeCanvas::drawRRect
    // 0x122f288: r0 = Null
    //     0x122f288: mov             x0, NULL
    // 0x122f28c: LeaveFrame
    //     0x122f28c: mov             SP, fp
    //     0x122f290: ldp             fp, lr, [SP], #0x10
    // 0x122f294: ret
    //     0x122f294: ret             
    // 0x122f298: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122f298: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122f29c: b               #0x122f194
  }
}

// class id: 4482, size: 0x38, field offset: 0x24
class _TextHighlightPainter extends RenderEditablePainter {

  set _ highlightedRange=(/* No info */) {
    // ** addr: 0xcf010c, size: 0xa4
    // 0xcf010c: EnterFrame
    //     0xcf010c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0110: mov             fp, SP
    // 0xcf0114: AllocStack(0x20)
    //     0xcf0114: sub             SP, SP, #0x20
    // 0xcf0118: SetupParameters(_TextHighlightPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf0118: stur            x1, [fp, #-8]
    //     0xcf011c: mov             x16, x2
    //     0xcf0120: mov             x2, x1
    //     0xcf0124: mov             x1, x16
    //     0xcf0128: stur            x1, [fp, #-0x10]
    // 0xcf012c: CheckStackOverflow
    //     0xcf012c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0130: cmp             SP, x16
    //     0xcf0134: b.ls            #0xcf01a8
    // 0xcf0138: LoadField: r0 = r2->field_2b
    //     0xcf0138: ldur            w0, [x2, #0x2b]
    // 0xcf013c: DecompressPointer r0
    //     0xcf013c: add             x0, x0, HEAP, lsl #32
    // 0xcf0140: r3 = LoadClassIdInstr(r1)
    //     0xcf0140: ldur            x3, [x1, #-1]
    //     0xcf0144: ubfx            x3, x3, #0xc, #0x14
    // 0xcf0148: stp             x0, x1, [SP]
    // 0xcf014c: mov             x0, x3
    // 0xcf0150: mov             lr, x0
    // 0xcf0154: ldr             lr, [x21, lr, lsl #3]
    // 0xcf0158: blr             lr
    // 0xcf015c: tbnz            w0, #4, #0xcf0170
    // 0xcf0160: r0 = Null
    //     0xcf0160: mov             x0, NULL
    // 0xcf0164: LeaveFrame
    //     0xcf0164: mov             SP, fp
    //     0xcf0168: ldp             fp, lr, [SP], #0x10
    // 0xcf016c: ret
    //     0xcf016c: ret             
    // 0xcf0170: ldur            x1, [fp, #-8]
    // 0xcf0174: ldur            x0, [fp, #-0x10]
    // 0xcf0178: StoreField: r1->field_2b = r0
    //     0xcf0178: stur            w0, [x1, #0x2b]
    //     0xcf017c: ldurb           w16, [x1, #-1]
    //     0xcf0180: ldurb           w17, [x0, #-1]
    //     0xcf0184: and             x16, x17, x16, lsr #2
    //     0xcf0188: tst             x16, HEAP, lsr #32
    //     0xcf018c: b.eq            #0xcf0194
    //     0xcf0190: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf0194: r0 = notifyListeners()
    //     0xcf0194: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcf0198: r0 = Null
    //     0xcf0198: mov             x0, NULL
    // 0xcf019c: LeaveFrame
    //     0xcf019c: mov             SP, fp
    //     0xcf01a0: ldp             fp, lr, [SP], #0x10
    // 0xcf01a4: ret
    //     0xcf01a4: ret             
    // 0xcf01a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf01a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf01ac: b               #0xcf0138
  }
  set _ highlightColor=(/* No info */) {
    // ** addr: 0xcf01ec, size: 0xa4
    // 0xcf01ec: EnterFrame
    //     0xcf01ec: stp             fp, lr, [SP, #-0x10]!
    //     0xcf01f0: mov             fp, SP
    // 0xcf01f4: AllocStack(0x20)
    //     0xcf01f4: sub             SP, SP, #0x20
    // 0xcf01f8: SetupParameters(_TextHighlightPainter this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf01f8: stur            x1, [fp, #-8]
    //     0xcf01fc: mov             x16, x2
    //     0xcf0200: mov             x2, x1
    //     0xcf0204: mov             x1, x16
    //     0xcf0208: stur            x1, [fp, #-0x10]
    // 0xcf020c: CheckStackOverflow
    //     0xcf020c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0210: cmp             SP, x16
    //     0xcf0214: b.ls            #0xcf0288
    // 0xcf0218: LoadField: r0 = r2->field_27
    //     0xcf0218: ldur            w0, [x2, #0x27]
    // 0xcf021c: DecompressPointer r0
    //     0xcf021c: add             x0, x0, HEAP, lsl #32
    // 0xcf0220: r3 = LoadClassIdInstr(r1)
    //     0xcf0220: ldur            x3, [x1, #-1]
    //     0xcf0224: ubfx            x3, x3, #0xc, #0x14
    // 0xcf0228: stp             x0, x1, [SP]
    // 0xcf022c: mov             x0, x3
    // 0xcf0230: mov             lr, x0
    // 0xcf0234: ldr             lr, [x21, lr, lsl #3]
    // 0xcf0238: blr             lr
    // 0xcf023c: tbnz            w0, #4, #0xcf0250
    // 0xcf0240: r0 = Null
    //     0xcf0240: mov             x0, NULL
    // 0xcf0244: LeaveFrame
    //     0xcf0244: mov             SP, fp
    //     0xcf0248: ldp             fp, lr, [SP], #0x10
    // 0xcf024c: ret
    //     0xcf024c: ret             
    // 0xcf0250: ldur            x1, [fp, #-8]
    // 0xcf0254: ldur            x0, [fp, #-0x10]
    // 0xcf0258: StoreField: r1->field_27 = r0
    //     0xcf0258: stur            w0, [x1, #0x27]
    //     0xcf025c: ldurb           w16, [x1, #-1]
    //     0xcf0260: ldurb           w17, [x0, #-1]
    //     0xcf0264: and             x16, x17, x16, lsr #2
    //     0xcf0268: tst             x16, HEAP, lsr #32
    //     0xcf026c: b.eq            #0xcf0274
    //     0xcf0270: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf0274: r0 = notifyListeners()
    //     0xcf0274: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcf0278: r0 = Null
    //     0xcf0278: mov             x0, NULL
    // 0xcf027c: LeaveFrame
    //     0xcf027c: mov             SP, fp
    //     0xcf0280: ldp             fp, lr, [SP], #0x10
    // 0xcf0284: ret
    //     0xcf0284: ret             
    // 0xcf0288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0288: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf028c: b               #0xcf0218
  }
  set _ selectionWidthStyle=(/* No info */) {
    // ** addr: 0xcf0b2c, size: 0x64
    // 0xcf0b2c: EnterFrame
    //     0xcf0b2c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0b30: mov             fp, SP
    // 0xcf0b34: CheckStackOverflow
    //     0xcf0b34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0b38: cmp             SP, x16
    //     0xcf0b3c: b.ls            #0xcf0b88
    // 0xcf0b40: LoadField: r0 = r1->field_33
    //     0xcf0b40: ldur            w0, [x1, #0x33]
    // 0xcf0b44: DecompressPointer r0
    //     0xcf0b44: add             x0, x0, HEAP, lsl #32
    // 0xcf0b48: r16 = Instance_BoxWidthStyle
    //     0xcf0b48: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a668] Obj!BoxWidthStyle@12c72e1
    //     0xcf0b4c: ldr             x16, [x16, #0x668]
    // 0xcf0b50: cmp             w0, w16
    // 0xcf0b54: b.ne            #0xcf0b68
    // 0xcf0b58: r0 = Null
    //     0xcf0b58: mov             x0, NULL
    // 0xcf0b5c: LeaveFrame
    //     0xcf0b5c: mov             SP, fp
    //     0xcf0b60: ldp             fp, lr, [SP], #0x10
    // 0xcf0b64: ret
    //     0xcf0b64: ret             
    // 0xcf0b68: r0 = Instance_BoxWidthStyle
    //     0xcf0b68: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a668] Obj!BoxWidthStyle@12c72e1
    //     0xcf0b6c: ldr             x0, [x0, #0x668]
    // 0xcf0b70: StoreField: r1->field_33 = r0
    //     0xcf0b70: stur            w0, [x1, #0x33]
    // 0xcf0b74: r0 = notifyListeners()
    //     0xcf0b74: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcf0b78: r0 = Null
    //     0xcf0b78: mov             x0, NULL
    // 0xcf0b7c: LeaveFrame
    //     0xcf0b7c: mov             SP, fp
    //     0xcf0b80: ldp             fp, lr, [SP], #0x10
    // 0xcf0b84: ret
    //     0xcf0b84: ret             
    // 0xcf0b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0b88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0b8c: b               #0xcf0b40
  }
  set _ selectionHeightStyle=(/* No info */) {
    // ** addr: 0xcf0bd4, size: 0x64
    // 0xcf0bd4: EnterFrame
    //     0xcf0bd4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0bd8: mov             fp, SP
    // 0xcf0bdc: CheckStackOverflow
    //     0xcf0bdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0be0: cmp             SP, x16
    //     0xcf0be4: b.ls            #0xcf0c30
    // 0xcf0be8: LoadField: r0 = r1->field_2f
    //     0xcf0be8: ldur            w0, [x1, #0x2f]
    // 0xcf0bec: DecompressPointer r0
    //     0xcf0bec: add             x0, x0, HEAP, lsl #32
    // 0xcf0bf0: r16 = Instance_BoxHeightStyle
    //     0xcf0bf0: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a660] Obj!BoxHeightStyle@12c7321
    //     0xcf0bf4: ldr             x16, [x16, #0x660]
    // 0xcf0bf8: cmp             w0, w16
    // 0xcf0bfc: b.ne            #0xcf0c10
    // 0xcf0c00: r0 = Null
    //     0xcf0c00: mov             x0, NULL
    // 0xcf0c04: LeaveFrame
    //     0xcf0c04: mov             SP, fp
    //     0xcf0c08: ldp             fp, lr, [SP], #0x10
    // 0xcf0c0c: ret
    //     0xcf0c0c: ret             
    // 0xcf0c10: r0 = Instance_BoxHeightStyle
    //     0xcf0c10: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a660] Obj!BoxHeightStyle@12c7321
    //     0xcf0c14: ldr             x0, [x0, #0x660]
    // 0xcf0c18: StoreField: r1->field_2f = r0
    //     0xcf0c18: stur            w0, [x1, #0x2f]
    // 0xcf0c1c: r0 = notifyListeners()
    //     0xcf0c1c: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcf0c20: r0 = Null
    //     0xcf0c20: mov             x0, NULL
    // 0xcf0c24: LeaveFrame
    //     0xcf0c24: mov             SP, fp
    //     0xcf0c28: ldp             fp, lr, [SP], #0x10
    // 0xcf0c2c: ret
    //     0xcf0c2c: ret             
    // 0xcf0c30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0c30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0c34: b               #0xcf0be8
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0x11a154c, size: 0x114
    // 0x11a154c: EnterFrame
    //     0x11a154c: stp             fp, lr, [SP, #-0x10]!
    //     0x11a1550: mov             fp, SP
    // 0x11a1554: AllocStack(0x20)
    //     0x11a1554: sub             SP, SP, #0x20
    // 0x11a1558: SetupParameters(_TextHighlightPainter this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11a1558: stur            x1, [fp, #-8]
    //     0x11a155c: stur            x2, [fp, #-0x10]
    // 0x11a1560: CheckStackOverflow
    //     0x11a1560: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11a1564: cmp             SP, x16
    //     0x11a1568: b.ls            #0x11a1658
    // 0x11a156c: cmp             w2, w1
    // 0x11a1570: b.ne            #0x11a1584
    // 0x11a1574: r0 = false
    //     0x11a1574: add             x0, NULL, #0x30  ; false
    // 0x11a1578: LeaveFrame
    //     0x11a1578: mov             SP, fp
    //     0x11a157c: ldp             fp, lr, [SP], #0x10
    // 0x11a1580: ret
    //     0x11a1580: ret             
    // 0x11a1584: r0 = LoadClassIdInstr(r2)
    //     0x11a1584: ldur            x0, [x2, #-1]
    //     0x11a1588: ubfx            x0, x0, #0xc, #0x14
    // 0x11a158c: r17 = 4482
    //     0x11a158c: mov             x17, #0x1182
    // 0x11a1590: cmp             x0, x17
    // 0x11a1594: b.ne            #0x11a1620
    // 0x11a1598: LoadField: r0 = r2->field_27
    //     0x11a1598: ldur            w0, [x2, #0x27]
    // 0x11a159c: DecompressPointer r0
    //     0x11a159c: add             x0, x0, HEAP, lsl #32
    // 0x11a15a0: LoadField: r3 = r1->field_27
    //     0x11a15a0: ldur            w3, [x1, #0x27]
    // 0x11a15a4: DecompressPointer r3
    //     0x11a15a4: add             x3, x3, HEAP, lsl #32
    // 0x11a15a8: r4 = LoadClassIdInstr(r0)
    //     0x11a15a8: ldur            x4, [x0, #-1]
    //     0x11a15ac: ubfx            x4, x4, #0xc, #0x14
    // 0x11a15b0: stp             x3, x0, [SP]
    // 0x11a15b4: mov             x0, x4
    // 0x11a15b8: mov             lr, x0
    // 0x11a15bc: ldr             lr, [x21, lr, lsl #3]
    // 0x11a15c0: blr             lr
    // 0x11a15c4: tbnz            w0, #4, #0x11a1620
    // 0x11a15c8: ldur            x2, [fp, #-8]
    // 0x11a15cc: ldur            x1, [fp, #-0x10]
    // 0x11a15d0: LoadField: r0 = r1->field_2b
    //     0x11a15d0: ldur            w0, [x1, #0x2b]
    // 0x11a15d4: DecompressPointer r0
    //     0x11a15d4: add             x0, x0, HEAP, lsl #32
    // 0x11a15d8: LoadField: r3 = r2->field_2b
    //     0x11a15d8: ldur            w3, [x2, #0x2b]
    // 0x11a15dc: DecompressPointer r3
    //     0x11a15dc: add             x3, x3, HEAP, lsl #32
    // 0x11a15e0: r4 = LoadClassIdInstr(r0)
    //     0x11a15e0: ldur            x4, [x0, #-1]
    //     0x11a15e4: ubfx            x4, x4, #0xc, #0x14
    // 0x11a15e8: stp             x3, x0, [SP]
    // 0x11a15ec: mov             x0, x4
    // 0x11a15f0: mov             lr, x0
    // 0x11a15f4: ldr             lr, [x21, lr, lsl #3]
    // 0x11a15f8: blr             lr
    // 0x11a15fc: tbnz            w0, #4, #0x11a1620
    // 0x11a1600: ldur            x2, [fp, #-8]
    // 0x11a1604: ldur            x1, [fp, #-0x10]
    // 0x11a1608: LoadField: r3 = r1->field_2f
    //     0x11a1608: ldur            w3, [x1, #0x2f]
    // 0x11a160c: DecompressPointer r3
    //     0x11a160c: add             x3, x3, HEAP, lsl #32
    // 0x11a1610: LoadField: r4 = r2->field_2f
    //     0x11a1610: ldur            w4, [x2, #0x2f]
    // 0x11a1614: DecompressPointer r4
    //     0x11a1614: add             x4, x4, HEAP, lsl #32
    // 0x11a1618: cmp             w3, w4
    // 0x11a161c: b.eq            #0x11a1628
    // 0x11a1620: r0 = true
    //     0x11a1620: add             x0, NULL, #0x20  ; true
    // 0x11a1624: b               #0x11a164c
    // 0x11a1628: LoadField: r3 = r1->field_33
    //     0x11a1628: ldur            w3, [x1, #0x33]
    // 0x11a162c: DecompressPointer r3
    //     0x11a162c: add             x3, x3, HEAP, lsl #32
    // 0x11a1630: LoadField: r1 = r2->field_33
    //     0x11a1630: ldur            w1, [x2, #0x33]
    // 0x11a1634: DecompressPointer r1
    //     0x11a1634: add             x1, x1, HEAP, lsl #32
    // 0x11a1638: cmp             w3, w1
    // 0x11a163c: r16 = true
    //     0x11a163c: add             x16, NULL, #0x20  ; true
    // 0x11a1640: r17 = false
    //     0x11a1640: add             x17, NULL, #0x30  ; false
    // 0x11a1644: csel            x2, x16, x17, ne
    // 0x11a1648: mov             x0, x2
    // 0x11a164c: LeaveFrame
    //     0x11a164c: mov             SP, fp
    //     0x11a1650: ldp             fp, lr, [SP], #0x10
    // 0x11a1654: ret
    //     0x11a1654: ret             
    // 0x11a1658: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11a1658: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11a165c: b               #0x11a156c
  }
  _ _TextHighlightPainter(/* No info */) {
    // ** addr: 0x11cb518, size: 0xd0
    // 0x11cb518: EnterFrame
    //     0x11cb518: stp             fp, lr, [SP, #-0x10]!
    //     0x11cb51c: mov             fp, SP
    // 0x11cb520: AllocStack(0x20)
    //     0x11cb520: sub             SP, SP, #0x20
    // 0x11cb524: r2 = Instance_BoxHeightStyle
    //     0x11cb524: ldr             x2, [PP, #0x4d30]  ; [pp+0x4d30] Obj!BoxHeightStyle@12c7301
    // 0x11cb528: r0 = Instance_BoxWidthStyle
    //     0x11cb528: ldr             x0, [PP, #0x4d40]  ; [pp+0x4d40] Obj!BoxWidthStyle@12c72c1
    // 0x11cb52c: stur            x1, [fp, #-8]
    // 0x11cb530: CheckStackOverflow
    //     0x11cb530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cb534: cmp             SP, x16
    //     0x11cb538: b.ls            #0x11cb5e0
    // 0x11cb53c: StoreField: r1->field_2f = r2
    //     0x11cb53c: stur            w2, [x1, #0x2f]
    // 0x11cb540: StoreField: r1->field_33 = r0
    //     0x11cb540: stur            w0, [x1, #0x33]
    // 0x11cb544: r16 = 136
    //     0x11cb544: mov             x16, #0x88
    // 0x11cb548: stp             x16, NULL, [SP]
    // 0x11cb54c: r0 = ByteData()
    //     0x11cb54c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0x11cb550: stur            x0, [fp, #-0x10]
    // 0x11cb554: r0 = Paint()
    //     0x11cb554: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x11cb558: mov             x1, x0
    // 0x11cb55c: ldur            x0, [fp, #-0x10]
    // 0x11cb560: StoreField: r1->field_7 = r0
    //     0x11cb560: stur            w0, [x1, #7]
    // 0x11cb564: mov             x0, x1
    // 0x11cb568: ldur            x1, [fp, #-8]
    // 0x11cb56c: StoreField: r1->field_23 = r0
    //     0x11cb56c: stur            w0, [x1, #0x23]
    //     0x11cb570: ldurb           w16, [x1, #-1]
    //     0x11cb574: ldurb           w17, [x0, #-1]
    //     0x11cb578: and             x16, x17, x16, lsr #2
    //     0x11cb57c: tst             x16, HEAP, lsr #32
    //     0x11cb580: b.eq            #0x11cb588
    //     0x11cb584: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb588: StoreField: r1->field_7 = rZR
    //     0x11cb588: stur            xzr, [x1, #7]
    // 0x11cb58c: StoreField: r1->field_13 = rZR
    //     0x11cb58c: stur            xzr, [x1, #0x13]
    // 0x11cb590: StoreField: r1->field_1b = rZR
    //     0x11cb590: stur            xzr, [x1, #0x1b]
    // 0x11cb594: r0 = LoadStaticField(0x45c)
    //     0x11cb594: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x11cb598: ldr             x0, [x0, #0x8b8]
    // 0x11cb59c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11cb5a0: cmp             w0, w16
    // 0x11cb5a4: b.ne            #0x11cb5b0
    // 0x11cb5a8: r2 = _emptyListeners
    //     0x11cb5a8: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0x11cb5ac: r0 = InitLateFinalStaticField()
    //     0x11cb5ac: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x11cb5b0: ldur            x1, [fp, #-8]
    // 0x11cb5b4: StoreField: r1->field_f = r0
    //     0x11cb5b4: stur            w0, [x1, #0xf]
    //     0x11cb5b8: ldurb           w16, [x1, #-1]
    //     0x11cb5bc: ldurb           w17, [x0, #-1]
    //     0x11cb5c0: and             x16, x17, x16, lsr #2
    //     0x11cb5c4: tst             x16, HEAP, lsr #32
    //     0x11cb5c8: b.eq            #0x11cb5d0
    //     0x11cb5cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb5d0: r0 = Null
    //     0x11cb5d0: mov             x0, NULL
    // 0x11cb5d4: LeaveFrame
    //     0x11cb5d4: mov             SP, fp
    //     0x11cb5d8: ldp             fp, lr, [SP], #0x10
    // 0x11cb5dc: ret
    //     0x11cb5dc: ret             
    // 0x11cb5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cb5e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cb5e4: b               #0x11cb53c
  }
  _ paint(/* No info */) {
    // ** addr: 0x122ec40, size: 0x344
    // 0x122ec40: EnterFrame
    //     0x122ec40: stp             fp, lr, [SP, #-0x10]!
    //     0x122ec44: mov             fp, SP
    // 0x122ec48: AllocStack(0x88)
    //     0x122ec48: sub             SP, SP, #0x88
    // 0x122ec4c: SetupParameters(_TextHighlightPainter this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x28 */, dynamic _ /* r3 => r0, fp-0x30 */)
    //     0x122ec4c: mov             x4, x1
    //     0x122ec50: mov             x0, x3
    //     0x122ec54: stur            x3, [fp, #-0x30]
    //     0x122ec58: mov             x3, x2
    //     0x122ec5c: stur            x1, [fp, #-0x20]
    //     0x122ec60: stur            x2, [fp, #-0x28]
    // 0x122ec64: CheckStackOverflow
    //     0x122ec64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122ec68: cmp             SP, x16
    //     0x122ec6c: b.ls            #0x122ef6c
    // 0x122ec70: LoadField: r1 = r4->field_2b
    //     0x122ec70: ldur            w1, [x4, #0x2b]
    // 0x122ec74: DecompressPointer r1
    //     0x122ec74: add             x1, x1, HEAP, lsl #32
    // 0x122ec78: LoadField: r2 = r4->field_27
    //     0x122ec78: ldur            w2, [x4, #0x27]
    // 0x122ec7c: DecompressPointer r2
    //     0x122ec7c: add             x2, x2, HEAP, lsl #32
    // 0x122ec80: cmp             w1, NULL
    // 0x122ec84: b.eq            #0x122eca8
    // 0x122ec88: cmp             w2, NULL
    // 0x122ec8c: b.eq            #0x122eca8
    // 0x122ec90: LoadField: r5 = r1->field_7
    //     0x122ec90: ldur            x5, [x1, #7]
    // 0x122ec94: stur            x5, [fp, #-0x18]
    // 0x122ec98: LoadField: r6 = r1->field_f
    //     0x122ec98: ldur            x6, [x1, #0xf]
    // 0x122ec9c: stur            x6, [fp, #-0x10]
    // 0x122eca0: cmp             x5, x6
    // 0x122eca4: b.ne            #0x122ecb8
    // 0x122eca8: r0 = Null
    //     0x122eca8: mov             x0, NULL
    // 0x122ecac: LeaveFrame
    //     0x122ecac: mov             SP, fp
    //     0x122ecb0: ldp             fp, lr, [SP], #0x10
    // 0x122ecb4: ret
    //     0x122ecb4: ret             
    // 0x122ecb8: LoadField: r7 = r4->field_23
    //     0x122ecb8: ldur            w7, [x4, #0x23]
    // 0x122ecbc: DecompressPointer r7
    //     0x122ecbc: add             x7, x7, HEAP, lsl #32
    // 0x122ecc0: mov             x1, x7
    // 0x122ecc4: stur            x7, [fp, #-8]
    // 0x122ecc8: r0 = color=()
    //     0x122ecc8: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0x122eccc: ldur            x1, [fp, #-0x30]
    // 0x122ecd0: LoadField: r0 = r1->field_a7
    //     0x122ecd0: ldur            w0, [x1, #0xa7]
    // 0x122ecd4: DecompressPointer r0
    //     0x122ecd4: add             x0, x0, HEAP, lsl #32
    // 0x122ecd8: stur            x0, [fp, #-0x38]
    // 0x122ecdc: r0 = TextSelection()
    //     0x122ecdc: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x122ece0: mov             x1, x0
    // 0x122ece4: ldur            x0, [fp, #-0x18]
    // 0x122ece8: ArrayStore: r1[0] = r0  ; List_8
    //     0x122ece8: stur            x0, [x1, #0x17]
    // 0x122ecec: ldur            x2, [fp, #-0x10]
    // 0x122ecf0: StoreField: r1->field_1f = r2
    //     0x122ecf0: stur            x2, [x1, #0x1f]
    // 0x122ecf4: r3 = Instance_TextAffinity
    //     0x122ecf4: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x122ecf8: StoreField: r1->field_27 = r3
    //     0x122ecf8: stur            w3, [x1, #0x27]
    // 0x122ecfc: r3 = false
    //     0x122ecfc: add             x3, NULL, #0x30  ; false
    // 0x122ed00: StoreField: r1->field_2b = r3
    //     0x122ed00: stur            w3, [x1, #0x2b]
    // 0x122ed04: cmp             x0, x2
    // 0x122ed08: b.ge            #0x122ed14
    // 0x122ed0c: mov             x3, x0
    // 0x122ed10: b               #0x122ed18
    // 0x122ed14: mov             x3, x2
    // 0x122ed18: cmp             x0, x2
    // 0x122ed1c: b.lt            #0x122ed24
    // 0x122ed20: mov             x2, x0
    // 0x122ed24: ldur            x0, [fp, #-0x20]
    // 0x122ed28: StoreField: r1->field_7 = r3
    //     0x122ed28: stur            x3, [x1, #7]
    // 0x122ed2c: StoreField: r1->field_f = r2
    //     0x122ed2c: stur            x2, [x1, #0xf]
    // 0x122ed30: LoadField: r2 = r0->field_2f
    //     0x122ed30: ldur            w2, [x0, #0x2f]
    // 0x122ed34: DecompressPointer r2
    //     0x122ed34: add             x2, x2, HEAP, lsl #32
    // 0x122ed38: LoadField: r3 = r0->field_33
    //     0x122ed38: ldur            w3, [x0, #0x33]
    // 0x122ed3c: DecompressPointer r3
    //     0x122ed3c: add             x3, x3, HEAP, lsl #32
    // 0x122ed40: stp             x3, x2, [SP]
    // 0x122ed44: mov             x2, x1
    // 0x122ed48: ldur            x1, [fp, #-0x38]
    // 0x122ed4c: r4 = const [0, 0x4, 0x2, 0x2, boxHeightStyle, 0x2, boxWidthStyle, 0x3, null]
    //     0x122ed4c: ldr             x4, [PP, #0x4d00]  ; [pp+0x4d00] List(9) [0, 0x4, 0x2, 0x2, "boxHeightStyle", 0x2, "boxWidthStyle", 0x3, Null]
    // 0x122ed50: r0 = getBoxesForSelection()
    //     0x122ed50: bl              #0x85fc0c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x122ed54: r1 = LoadClassIdInstr(r0)
    //     0x122ed54: ldur            x1, [x0, #-1]
    //     0x122ed58: ubfx            x1, x1, #0xc, #0x14
    // 0x122ed5c: mov             x16, x0
    // 0x122ed60: mov             x0, x1
    // 0x122ed64: mov             x1, x16
    // 0x122ed68: r0 = GDT[cid_x0 + 0x12bd1]()
    //     0x122ed68: mov             x17, #0x2bd1
    //     0x122ed6c: movk            x17, #1, lsl #16
    //     0x122ed70: add             lr, x0, x17
    //     0x122ed74: ldr             lr, [x21, lr, lsl #3]
    //     0x122ed78: blr             lr
    // 0x122ed7c: mov             x1, x0
    // 0x122ed80: r0 = iterator()
    //     0x122ed80: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x122ed84: stur            x0, [fp, #-0x40]
    // 0x122ed88: LoadField: r2 = r0->field_7
    //     0x122ed88: ldur            w2, [x0, #7]
    // 0x122ed8c: DecompressPointer r2
    //     0x122ed8c: add             x2, x2, HEAP, lsl #32
    // 0x122ed90: stur            x2, [fp, #-0x20]
    // 0x122ed94: ldur            x3, [fp, #-0x38]
    // 0x122ed98: CheckStackOverflow
    //     0x122ed98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x122ed9c: cmp             SP, x16
    //     0x122eda0: b.ls            #0x122ef74
    // 0x122eda4: mov             x1, x0
    // 0x122eda8: r0 = moveNext()
    //     0x122eda8: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0x122edac: tbnz            w0, #4, #0x122ef4c
    // 0x122edb0: ldur            x3, [fp, #-0x40]
    // 0x122edb4: LoadField: r4 = r3->field_33
    //     0x122edb4: ldur            w4, [x3, #0x33]
    // 0x122edb8: DecompressPointer r4
    //     0x122edb8: add             x4, x4, HEAP, lsl #32
    // 0x122edbc: stur            x4, [fp, #-0x48]
    // 0x122edc0: cmp             w4, NULL
    // 0x122edc4: b.ne            #0x122edf8
    // 0x122edc8: mov             x0, x4
    // 0x122edcc: ldur            x2, [fp, #-0x20]
    // 0x122edd0: r1 = Null
    //     0x122edd0: mov             x1, NULL
    // 0x122edd4: cmp             w2, NULL
    // 0x122edd8: b.eq            #0x122edf8
    // 0x122eddc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x122eddc: ldur            w4, [x2, #0x17]
    // 0x122ede0: DecompressPointer r4
    //     0x122ede0: add             x4, x4, HEAP, lsl #32
    // 0x122ede4: r8 = X0
    //     0x122ede4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x122ede8: LoadField: r9 = r4->field_7
    //     0x122ede8: ldur            x9, [x4, #7]
    // 0x122edec: r3 = Null
    //     0x122edec: add             x3, PP, #0xd0, lsl #12  ; [pp+0xd05c0] Null
    //     0x122edf0: ldr             x3, [x3, #0x5c0]
    // 0x122edf4: blr             x9
    // 0x122edf8: ldur            x2, [fp, #-0x38]
    // 0x122edfc: ldur            x0, [fp, #-0x48]
    // 0x122ee00: LoadField: d0 = r0->field_7
    //     0x122ee00: ldur            d0, [x0, #7]
    // 0x122ee04: stur            d0, [fp, #-0x68]
    // 0x122ee08: LoadField: d1 = r0->field_f
    //     0x122ee08: ldur            d1, [x0, #0xf]
    // 0x122ee0c: stur            d1, [fp, #-0x60]
    // 0x122ee10: ArrayLoad: d2 = r0[0]  ; List_8
    //     0x122ee10: ldur            d2, [x0, #0x17]
    // 0x122ee14: stur            d2, [fp, #-0x58]
    // 0x122ee18: LoadField: d3 = r0->field_1f
    //     0x122ee18: ldur            d3, [x0, #0x1f]
    // 0x122ee1c: ldur            x1, [fp, #-0x30]
    // 0x122ee20: stur            d3, [fp, #-0x50]
    // 0x122ee24: r0 = _paintOffset()
    //     0x122ee24: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x122ee28: LoadField: d0 = r0->field_7
    //     0x122ee28: ldur            d0, [x0, #7]
    // 0x122ee2c: ldur            d1, [fp, #-0x68]
    // 0x122ee30: fadd            d2, d1, d0
    // 0x122ee34: stur            d2, [fp, #-0x70]
    // 0x122ee38: LoadField: d1 = r0->field_f
    //     0x122ee38: ldur            d1, [x0, #0xf]
    // 0x122ee3c: ldur            d3, [fp, #-0x60]
    // 0x122ee40: fadd            d4, d3, d1
    // 0x122ee44: ldur            d3, [fp, #-0x58]
    // 0x122ee48: stur            d4, [fp, #-0x68]
    // 0x122ee4c: fadd            d5, d3, d0
    // 0x122ee50: ldur            d0, [fp, #-0x50]
    // 0x122ee54: stur            d5, [fp, #-0x60]
    // 0x122ee58: fadd            d3, d0, d1
    // 0x122ee5c: ldur            x0, [fp, #-0x38]
    // 0x122ee60: stur            d3, [fp, #-0x58]
    // 0x122ee64: LoadField: r1 = r0->field_7
    //     0x122ee64: ldur            w1, [x0, #7]
    // 0x122ee68: DecompressPointer r1
    //     0x122ee68: add             x1, x1, HEAP, lsl #32
    // 0x122ee6c: cmp             w1, NULL
    // 0x122ee70: b.eq            #0x122ef7c
    // 0x122ee74: LoadField: d0 = r1->field_13
    //     0x122ee74: ldur            d0, [x1, #0x13]
    // 0x122ee78: stur            d0, [fp, #-0x50]
    // 0x122ee7c: LoadField: r2 = r1->field_7
    //     0x122ee7c: ldur            w2, [x1, #7]
    // 0x122ee80: DecompressPointer r2
    //     0x122ee80: add             x2, x2, HEAP, lsl #32
    // 0x122ee84: LoadField: r3 = r2->field_f
    //     0x122ee84: ldur            w3, [x2, #0xf]
    // 0x122ee88: DecompressPointer r3
    //     0x122ee88: add             x3, x3, HEAP, lsl #32
    // 0x122ee8c: stur            x3, [fp, #-0x48]
    // 0x122ee90: LoadField: r1 = r3->field_7
    //     0x122ee90: ldur            w1, [x3, #7]
    // 0x122ee94: DecompressPointer r1
    //     0x122ee94: add             x1, x1, HEAP, lsl #32
    // 0x122ee98: cmp             w1, NULL
    // 0x122ee9c: b.eq            #0x122ef80
    // 0x122eea0: LoadField: r2 = r1->field_7
    //     0x122eea0: ldur            x2, [x1, #7]
    // 0x122eea4: ldr             x1, [x2]
    // 0x122eea8: cbz             x1, #0x122ef5c
    // 0x122eeac: mov             x2, x1
    // 0x122eeb0: stur            x2, [fp, #-0x10]
    // 0x122eeb4: r1 = <Never>
    //     0x122eeb4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x122eeb8: r0 = Pointer()
    //     0x122eeb8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x122eebc: mov             x1, x0
    // 0x122eec0: ldur            x0, [fp, #-0x10]
    // 0x122eec4: StoreField: r1->field_7 = r0
    //     0x122eec4: stur            x0, [x1, #7]
    // 0x122eec8: r0 = _height$Getter$FfiNative()
    //     0x122eec8: bl              #0x859d8c  ; [dart:ui] _NativeParagraph::_height$Getter$FfiNative
    // 0x122eecc: ldur            d1, [fp, #-0x50]
    // 0x122eed0: d2 = 0.000000
    //     0x122eed0: eor             v2.16b, v2.16b, v2.16b
    // 0x122eed4: fadd            d3, d1, d2
    // 0x122eed8: fadd            d1, d0, d2
    // 0x122eedc: ldur            d0, [fp, #-0x70]
    // 0x122eee0: fmax            v4.2d, v0.2d, v2.2d
    // 0x122eee4: ldur            d0, [fp, #-0x68]
    // 0x122eee8: stur            d4, [fp, #-0x78]
    // 0x122eeec: fmax            v5.2d, v0.2d, v2.2d
    // 0x122eef0: ldur            d0, [fp, #-0x60]
    // 0x122eef4: stur            d5, [fp, #-0x70]
    // 0x122eef8: fmin            v6.2d, v0.2d, v3.2d
    // 0x122eefc: ldur            d0, [fp, #-0x58]
    // 0x122ef00: stur            d6, [fp, #-0x68]
    // 0x122ef04: fmin            v3.2d, v0.2d, v1.2d
    // 0x122ef08: stur            d3, [fp, #-0x50]
    // 0x122ef0c: r0 = Rect()
    //     0x122ef0c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x122ef10: ldur            d0, [fp, #-0x78]
    // 0x122ef14: StoreField: r0->field_7 = d0
    //     0x122ef14: stur            d0, [x0, #7]
    // 0x122ef18: ldur            d0, [fp, #-0x70]
    // 0x122ef1c: StoreField: r0->field_f = d0
    //     0x122ef1c: stur            d0, [x0, #0xf]
    // 0x122ef20: ldur            d0, [fp, #-0x68]
    // 0x122ef24: ArrayStore: r0[0] = d0  ; List_8
    //     0x122ef24: stur            d0, [x0, #0x17]
    // 0x122ef28: ldur            d0, [fp, #-0x50]
    // 0x122ef2c: StoreField: r0->field_1f = d0
    //     0x122ef2c: stur            d0, [x0, #0x1f]
    // 0x122ef30: ldur            x1, [fp, #-0x28]
    // 0x122ef34: mov             x2, x0
    // 0x122ef38: ldur            x3, [fp, #-8]
    // 0x122ef3c: r0 = drawRect()
    //     0x122ef3c: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0x122ef40: ldur            x0, [fp, #-0x40]
    // 0x122ef44: ldur            x2, [fp, #-0x20]
    // 0x122ef48: b               #0x122ed94
    // 0x122ef4c: r0 = Null
    //     0x122ef4c: mov             x0, NULL
    // 0x122ef50: LeaveFrame
    //     0x122ef50: mov             SP, fp
    //     0x122ef54: ldp             fp, lr, [SP], #0x10
    // 0x122ef58: ret
    //     0x122ef58: ret             
    // 0x122ef5c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x122ef5c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x122ef60: str             x16, [SP]
    // 0x122ef64: r0 = _throwNew()
    //     0x122ef64: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x122ef68: brk             #0
    // 0x122ef6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122ef6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122ef70: b               #0x122ec70
    // 0x122ef74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x122ef74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x122ef78: b               #0x122eda4
    // 0x122ef7c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x122ef7c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x122ef80: r0 = NullErrorSharedWithFPURegs()
    //     0x122ef80: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 4727, size: 0x54, field offset: 0x50
class _RenderEditableCustomPaint extends RenderBox {

  get _ parent(/* No info */) {
    // ** addr: 0xbecdbc, size: 0x58
    // 0xbecdbc: EnterFrame
    //     0xbecdbc: stp             fp, lr, [SP, #-0x10]!
    //     0xbecdc0: mov             fp, SP
    // 0xbecdc4: AllocStack(0x8)
    //     0xbecdc4: sub             SP, SP, #8
    // 0xbecdc8: LoadField: r3 = r1->field_13
    //     0xbecdc8: ldur            w3, [x1, #0x13]
    // 0xbecdcc: DecompressPointer r3
    //     0xbecdcc: add             x3, x3, HEAP, lsl #32
    // 0xbecdd0: mov             x0, x3
    // 0xbecdd4: stur            x3, [fp, #-8]
    // 0xbecdd8: r2 = Null
    //     0xbecdd8: mov             x2, NULL
    // 0xbecddc: r1 = Null
    //     0xbecddc: mov             x1, NULL
    // 0xbecde0: r4 = LoadClassIdInstr(r0)
    //     0xbecde0: ldur            x4, [x0, #-1]
    //     0xbecde4: ubfx            x4, x4, #0xc, #0x14
    // 0xbecde8: r17 = 4849
    //     0xbecde8: mov             x17, #0x12f1
    // 0xbecdec: cmp             x4, x17
    // 0xbecdf0: b.eq            #0xbece04
    // 0xbecdf4: r8 = RenderEditable?
    //     0xbecdf4: ldr             x8, [PP, #0x4850]  ; [pp+0x4850] Type: RenderEditable?
    // 0xbecdf8: r3 = Null
    //     0xbecdf8: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd810] Null
    //     0xbecdfc: ldr             x3, [x3, #0x810]
    // 0xbece00: r0 = DefaultNullableTypeTest()
    //     0xbece00: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xbece04: ldur            x0, [fp, #-8]
    // 0xbece08: LeaveFrame
    //     0xbece08: mov             SP, fp
    //     0xbece0c: ldp             fp, lr, [SP], #0x10
    // 0xbece10: ret
    //     0xbece10: ret             
  }
  _ detach(/* No info */) {
    // ** addr: 0xc09054, size: 0x68
    // 0xc09054: EnterFrame
    //     0xc09054: stp             fp, lr, [SP, #-0x10]!
    //     0xc09058: mov             fp, SP
    // 0xc0905c: AllocStack(0x10)
    //     0xc0905c: sub             SP, SP, #0x10
    // 0xc09060: SetupParameters(_RenderEditableCustomPaint this /* r1 => r0, fp-0x10 */)
    //     0xc09060: mov             x0, x1
    //     0xc09064: stur            x1, [fp, #-0x10]
    // 0xc09068: CheckStackOverflow
    //     0xc09068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0906c: cmp             SP, x16
    //     0xc09070: b.ls            #0xc090b4
    // 0xc09074: LoadField: r3 = r0->field_4f
    //     0xc09074: ldur            w3, [x0, #0x4f]
    // 0xc09078: DecompressPointer r3
    //     0xc09078: add             x3, x3, HEAP, lsl #32
    // 0xc0907c: mov             x2, x0
    // 0xc09080: stur            x3, [fp, #-8]
    // 0xc09084: r1 = Function 'markNeedsPaint':.
    //     0xc09084: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc09088: ldr             x1, [x1, #0x1f0]
    // 0xc0908c: r0 = AllocateClosure()
    //     0xc0908c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc09090: ldur            x1, [fp, #-8]
    // 0xc09094: mov             x2, x0
    // 0xc09098: r0 = removeListener()
    //     0xc09098: bl              #0xcff7c0  ; [package:flutter/src/rendering/editable.dart] _CompositeRenderEditablePainter::removeListener
    // 0xc0909c: ldur            x1, [fp, #-0x10]
    // 0xc090a0: r0 = detach()
    //     0xc090a0: bl              #0xc09564  ; [package:flutter/src/rendering/object.dart] RenderObject::detach
    // 0xc090a4: r0 = Null
    //     0xc090a4: mov             x0, NULL
    // 0xc090a8: LeaveFrame
    //     0xc090a8: mov             SP, fp
    //     0xc090ac: ldp             fp, lr, [SP], #0x10
    // 0xc090b0: ret
    //     0xc090b0: ret             
    // 0xc090b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc090b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc090b8: b               #0xc09074
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0cf10, size: 0x68
    // 0xc0cf10: EnterFrame
    //     0xc0cf10: stp             fp, lr, [SP, #-0x10]!
    //     0xc0cf14: mov             fp, SP
    // 0xc0cf18: AllocStack(0x10)
    //     0xc0cf18: sub             SP, SP, #0x10
    // 0xc0cf1c: SetupParameters(_RenderEditableCustomPaint this /* r1 => r0, fp-0x8 */)
    //     0xc0cf1c: mov             x0, x1
    //     0xc0cf20: stur            x1, [fp, #-8]
    // 0xc0cf24: CheckStackOverflow
    //     0xc0cf24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0cf28: cmp             SP, x16
    //     0xc0cf2c: b.ls            #0xc0cf70
    // 0xc0cf30: mov             x1, x0
    // 0xc0cf34: r0 = attach()
    //     0xc0cf34: bl              #0xc0d350  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0xc0cf38: ldur            x2, [fp, #-8]
    // 0xc0cf3c: LoadField: r0 = r2->field_4f
    //     0xc0cf3c: ldur            w0, [x2, #0x4f]
    // 0xc0cf40: DecompressPointer r0
    //     0xc0cf40: add             x0, x0, HEAP, lsl #32
    // 0xc0cf44: stur            x0, [fp, #-0x10]
    // 0xc0cf48: r1 = Function 'markNeedsPaint':.
    //     0xc0cf48: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc0cf4c: ldr             x1, [x1, #0x1f0]
    // 0xc0cf50: r0 = AllocateClosure()
    //     0xc0cf50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0cf54: ldur            x1, [fp, #-0x10]
    // 0xc0cf58: mov             x2, x0
    // 0xc0cf5c: r0 = addListener()
    //     0xc0cf5c: bl              #0xd037f0  ; [package:flutter/src/rendering/editable.dart] _CompositeRenderEditablePainter::addListener
    // 0xc0cf60: r0 = Null
    //     0xc0cf60: mov             x0, NULL
    // 0xc0cf64: LeaveFrame
    //     0xc0cf64: mov             SP, fp
    //     0xc0cf68: ldp             fp, lr, [SP], #0x10
    // 0xc0cf6c: ret
    //     0xc0cf6c: ret             
    // 0xc0cf70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0cf70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0cf74: b               #0xc0cf30
  }
  _ paint(/* No info */) {
    // ** addr: 0xc2e70c, size: 0x94
    // 0xc2e70c: EnterFrame
    //     0xc2e70c: stp             fp, lr, [SP, #-0x10]!
    //     0xc2e710: mov             fp, SP
    // 0xc2e714: AllocStack(0x20)
    //     0xc2e714: sub             SP, SP, #0x20
    // 0xc2e718: SetupParameters(_RenderEditableCustomPaint this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc2e718: mov             x0, x2
    //     0xc2e71c: stur            x2, [fp, #-0x10]
    //     0xc2e720: mov             x2, x1
    //     0xc2e724: stur            x1, [fp, #-8]
    // 0xc2e728: CheckStackOverflow
    //     0xc2e728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2e72c: cmp             SP, x16
    //     0xc2e730: b.ls            #0xc2e798
    // 0xc2e734: mov             x1, x2
    // 0xc2e738: r0 = parent()
    //     0xc2e738: bl              #0xbecdbc  ; [package:flutter/src/rendering/editable.dart] _RenderEditableCustomPaint::parent
    // 0xc2e73c: mov             x2, x0
    // 0xc2e740: ldur            x0, [fp, #-8]
    // 0xc2e744: stur            x2, [fp, #-0x20]
    // 0xc2e748: LoadField: r3 = r0->field_4f
    //     0xc2e748: ldur            w3, [x0, #0x4f]
    // 0xc2e74c: DecompressPointer r3
    //     0xc2e74c: add             x3, x3, HEAP, lsl #32
    // 0xc2e750: stur            x3, [fp, #-0x18]
    // 0xc2e754: cmp             w2, NULL
    // 0xc2e758: b.eq            #0xc2e788
    // 0xc2e75c: mov             x1, x2
    // 0xc2e760: r0 = _computeTextMetricsIfNeeded()
    //     0xc2e760: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0xc2e764: ldur            x1, [fp, #-0x10]
    // 0xc2e768: r0 = canvas()
    //     0xc2e768: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc2e76c: ldur            x1, [fp, #-8]
    // 0xc2e770: stur            x0, [fp, #-8]
    // 0xc2e774: r0 = size()
    //     0xc2e774: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2e778: ldur            x1, [fp, #-0x18]
    // 0xc2e77c: ldur            x2, [fp, #-8]
    // 0xc2e780: ldur            x3, [fp, #-0x20]
    // 0xc2e784: r0 = paint()
    //     0xc2e784: bl              #0x122f2a0  ; [package:flutter/src/rendering/editable.dart] _CompositeRenderEditablePainter::paint
    // 0xc2e788: r0 = Null
    //     0xc2e788: mov             x0, NULL
    // 0xc2e78c: LeaveFrame
    //     0xc2e78c: mov             SP, fp
    //     0xc2e790: ldp             fp, lr, [SP], #0x10
    // 0xc2e794: ret
    //     0xc2e794: ret             
    // 0xc2e798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2e798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2e79c: b               #0xc2e734
  }
  set _ painter=(/* No info */) {
    // ** addr: 0xcf03d8, size: 0xd8
    // 0xcf03d8: EnterFrame
    //     0xcf03d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf03dc: mov             fp, SP
    // 0xcf03e0: AllocStack(0x18)
    //     0xcf03e0: sub             SP, SP, #0x18
    // 0xcf03e4: SetupParameters(_RenderEditableCustomPaint this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xcf03e4: mov             x4, x1
    //     0xcf03e8: mov             x3, x2
    //     0xcf03ec: stur            x1, [fp, #-0x10]
    //     0xcf03f0: stur            x2, [fp, #-0x18]
    // 0xcf03f4: CheckStackOverflow
    //     0xcf03f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf03f8: cmp             SP, x16
    //     0xcf03fc: b.ls            #0xcf04a8
    // 0xcf0400: LoadField: r5 = r4->field_4f
    //     0xcf0400: ldur            w5, [x4, #0x4f]
    // 0xcf0404: DecompressPointer r5
    //     0xcf0404: add             x5, x5, HEAP, lsl #32
    // 0xcf0408: stur            x5, [fp, #-8]
    // 0xcf040c: cmp             w3, w5
    // 0xcf0410: b.ne            #0xcf0424
    // 0xcf0414: r0 = Null
    //     0xcf0414: mov             x0, NULL
    // 0xcf0418: LeaveFrame
    //     0xcf0418: mov             SP, fp
    //     0xcf041c: ldp             fp, lr, [SP], #0x10
    // 0xcf0420: ret
    //     0xcf0420: ret             
    // 0xcf0424: mov             x0, x3
    // 0xcf0428: StoreField: r4->field_4f = r0
    //     0xcf0428: stur            w0, [x4, #0x4f]
    //     0xcf042c: ldurb           w16, [x4, #-1]
    //     0xcf0430: ldurb           w17, [x0, #-1]
    //     0xcf0434: and             x16, x17, x16, lsr #2
    //     0xcf0438: tst             x16, HEAP, lsr #32
    //     0xcf043c: b.eq            #0xcf0444
    //     0xcf0440: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xcf0444: mov             x1, x3
    // 0xcf0448: mov             x2, x5
    // 0xcf044c: r0 = shouldRepaint()
    //     0xcf044c: bl              #0x11a17f8  ; [package:flutter/src/rendering/editable.dart] _CompositeRenderEditablePainter::shouldRepaint
    // 0xcf0450: tbnz            w0, #4, #0xcf045c
    // 0xcf0454: ldur            x1, [fp, #-0x10]
    // 0xcf0458: r0 = markNeedsPaint()
    //     0xcf0458: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf045c: ldur            x2, [fp, #-0x10]
    // 0xcf0460: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xcf0460: ldur            w0, [x2, #0x17]
    // 0xcf0464: DecompressPointer r0
    //     0xcf0464: add             x0, x0, HEAP, lsl #32
    // 0xcf0468: cmp             w0, NULL
    // 0xcf046c: b.eq            #0xcf0498
    // 0xcf0470: r1 = Function 'markNeedsPaint':.
    //     0xcf0470: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xcf0474: ldr             x1, [x1, #0x1f0]
    // 0xcf0478: r0 = AllocateClosure()
    //     0xcf0478: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf047c: ldur            x1, [fp, #-8]
    // 0xcf0480: mov             x2, x0
    // 0xcf0484: stur            x0, [fp, #-8]
    // 0xcf0488: r0 = removeListener()
    //     0xcf0488: bl              #0xcff7c0  ; [package:flutter/src/rendering/editable.dart] _CompositeRenderEditablePainter::removeListener
    // 0xcf048c: ldur            x1, [fp, #-0x18]
    // 0xcf0490: ldur            x2, [fp, #-8]
    // 0xcf0494: r0 = addListener()
    //     0xcf0494: bl              #0xd037f0  ; [package:flutter/src/rendering/editable.dart] _CompositeRenderEditablePainter::addListener
    // 0xcf0498: r0 = Null
    //     0xcf0498: mov             x0, NULL
    // 0xcf049c: LeaveFrame
    //     0xcf049c: mov             SP, fp
    //     0xcf04a0: ldp             fp, lr, [SP], #0x10
    // 0xcf04a4: ret
    //     0xcf04a4: ret             
    // 0xcf04a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf04a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf04ac: b               #0xcf0400
  }
}

// class id: 4849, size: 0x15c, field offset: 0x64
class RenderEditable extends _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults
    implements TextLayoutMetrics {

  late Rect _caretPrototype; // offset: 0x130
  late final _CaretPainter _caretPainter; // offset: 0x74
  late TapGestureRecognizer _tap; // offset: 0x11c
  late LongPressGestureRecognizer _longPress; // offset: 0x120
  late TextPosition _floatingCursorTextPosition; // offset: 0x100

  _ getEndpointsForSelection(/* No info */) {
    // ** addr: 0x8597dc, size: 0x450
    // 0x8597dc: EnterFrame
    //     0x8597dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8597e0: mov             fp, SP
    // 0x8597e4: AllocStack(0x48)
    //     0x8597e4: sub             SP, SP, #0x48
    // 0x8597e8: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8597e8: mov             x0, x1
    //     0x8597ec: stur            x1, [fp, #-8]
    //     0x8597f0: stur            x2, [fp, #-0x10]
    // 0x8597f4: CheckStackOverflow
    //     0x8597f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8597f8: cmp             SP, x16
    //     0x8597fc: b.ls            #0x859c1c
    // 0x859800: mov             x1, x0
    // 0x859804: r0 = _computeTextMetricsIfNeeded()
    //     0x859804: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0x859808: ldur            x1, [fp, #-8]
    // 0x85980c: r0 = _paintOffset()
    //     0x85980c: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x859810: mov             x3, x0
    // 0x859814: ldur            x0, [fp, #-0x10]
    // 0x859818: stur            x3, [fp, #-0x18]
    // 0x85981c: LoadField: r1 = r0->field_7
    //     0x85981c: ldur            x1, [x0, #7]
    // 0x859820: LoadField: r2 = r0->field_f
    //     0x859820: ldur            x2, [x0, #0xf]
    // 0x859824: cmp             x1, x2
    // 0x859828: b.ne            #0x859840
    // 0x85982c: r1 = <TextBox>
    //     0x85982c: ldr             x1, [PP, #0x4b90]  ; [pp+0x4b90] TypeArguments: <TextBox>
    // 0x859830: r2 = 0
    //     0x859830: mov             x2, #0
    // 0x859834: r0 = _GrowableList()
    //     0x859834: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x859838: mov             x2, x0
    // 0x85983c: b               #0x859878
    // 0x859840: ldur            x0, [fp, #-8]
    // 0x859844: LoadField: r1 = r0->field_a7
    //     0x859844: ldur            w1, [x0, #0xa7]
    // 0x859848: DecompressPointer r1
    //     0x859848: add             x1, x1, HEAP, lsl #32
    // 0x85984c: LoadField: r2 = r0->field_77
    //     0x85984c: ldur            w2, [x0, #0x77]
    // 0x859850: DecompressPointer r2
    //     0x859850: add             x2, x2, HEAP, lsl #32
    // 0x859854: LoadField: r3 = r2->field_2f
    //     0x859854: ldur            w3, [x2, #0x2f]
    // 0x859858: DecompressPointer r3
    //     0x859858: add             x3, x3, HEAP, lsl #32
    // 0x85985c: LoadField: r4 = r2->field_33
    //     0x85985c: ldur            w4, [x2, #0x33]
    // 0x859860: DecompressPointer r4
    //     0x859860: add             x4, x4, HEAP, lsl #32
    // 0x859864: stp             x4, x3, [SP]
    // 0x859868: ldur            x2, [fp, #-0x10]
    // 0x85986c: r4 = const [0, 0x4, 0x2, 0x2, boxHeightStyle, 0x2, boxWidthStyle, 0x3, null]
    //     0x85986c: ldr             x4, [PP, #0x4d00]  ; [pp+0x4d00] List(9) [0, 0x4, 0x2, 0x2, "boxHeightStyle", 0x2, "boxWidthStyle", 0x3, Null]
    // 0x859870: r0 = getBoxesForSelection()
    //     0x859870: bl              #0x85fc0c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x859874: mov             x2, x0
    // 0x859878: stur            x2, [fp, #-0x20]
    // 0x85987c: r0 = LoadClassIdInstr(r2)
    //     0x85987c: ldur            x0, [x2, #-1]
    //     0x859880: ubfx            x0, x0, #0xc, #0x14
    // 0x859884: mov             x1, x2
    // 0x859888: r0 = GDT[cid_x0 + 0x12b36]()
    //     0x859888: mov             x17, #0x2b36
    //     0x85988c: movk            x17, #1, lsl #16
    //     0x859890: add             lr, x0, x17
    //     0x859894: ldr             lr, [x21, lr, lsl #3]
    //     0x859898: blr             lr
    // 0x85989c: tbnz            w0, #4, #0x859978
    // 0x8598a0: ldur            x0, [fp, #-8]
    // 0x8598a4: LoadField: r2 = r0->field_a7
    //     0x8598a4: ldur            w2, [x0, #0xa7]
    // 0x8598a8: DecompressPointer r2
    //     0x8598a8: add             x2, x2, HEAP, lsl #32
    // 0x8598ac: ldur            x1, [fp, #-0x10]
    // 0x8598b0: stur            x2, [fp, #-0x28]
    // 0x8598b4: r0 = extent()
    //     0x8598b4: bl              #0x85fb94  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x8598b8: ldur            x2, [fp, #-8]
    // 0x8598bc: r17 = 303
    //     0x8598bc: mov             x17, #0x12f
    // 0x8598c0: ldr             w3, [x2, x17]
    // 0x8598c4: DecompressPointer r3
    //     0x8598c4: add             x3, x3, HEAP, lsl #32
    // 0x8598c8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8598cc: cmp             w3, w16
    // 0x8598d0: b.eq            #0x859c24
    // 0x8598d4: ldur            x1, [fp, #-0x28]
    // 0x8598d8: mov             x2, x0
    // 0x8598dc: r0 = getOffsetForCaret()
    //     0x8598dc: bl              #0x85dc3c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetForCaret
    // 0x8598e0: ldur            x1, [fp, #-0x28]
    // 0x8598e4: stur            x0, [fp, #-0x10]
    // 0x8598e8: r0 = preferredLineHeight()
    //     0x8598e8: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x8598ec: stur            d0, [fp, #-0x30]
    // 0x8598f0: r0 = Offset()
    //     0x8598f0: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8598f4: StoreField: r0->field_7 = rZR
    //     0x8598f4: stur            xzr, [x0, #7]
    // 0x8598f8: ldur            d0, [fp, #-0x30]
    // 0x8598fc: StoreField: r0->field_f = d0
    //     0x8598fc: stur            d0, [x0, #0xf]
    // 0x859900: mov             x1, x0
    // 0x859904: ldur            x2, [fp, #-0x10]
    // 0x859908: r0 = +()
    //     0x859908: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0x85990c: mov             x1, x0
    // 0x859910: ldur            x2, [fp, #-0x18]
    // 0x859914: r0 = +()
    //     0x859914: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0x859918: stur            x0, [fp, #-0x10]
    // 0x85991c: r0 = TextSelectionPoint()
    //     0x85991c: bl              #0x859e10  ; AllocateTextSelectionPointStub -> TextSelectionPoint (size=0x10)
    // 0x859920: mov             x3, x0
    // 0x859924: ldur            x0, [fp, #-0x10]
    // 0x859928: stur            x3, [fp, #-0x28]
    // 0x85992c: StoreField: r3->field_7 = r0
    //     0x85992c: stur            w0, [x3, #7]
    // 0x859930: r1 = Null
    //     0x859930: mov             x1, NULL
    // 0x859934: r2 = 2
    //     0x859934: mov             x2, #2
    // 0x859938: r0 = AllocateArray()
    //     0x859938: bl              #0x13df928  ; AllocateArrayStub
    // 0x85993c: mov             x2, x0
    // 0x859940: ldur            x0, [fp, #-0x28]
    // 0x859944: stur            x2, [fp, #-0x10]
    // 0x859948: StoreField: r2->field_f = r0
    //     0x859948: stur            w0, [x2, #0xf]
    // 0x85994c: r1 = <TextSelectionPoint>
    //     0x85994c: ldr             x1, [PP, #0x4d98]  ; [pp+0x4d98] TypeArguments: <TextSelectionPoint>
    // 0x859950: r0 = AllocateGrowableArray()
    //     0x859950: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x859954: mov             x1, x0
    // 0x859958: ldur            x0, [fp, #-0x10]
    // 0x85995c: StoreField: r1->field_f = r0
    //     0x85995c: stur            w0, [x1, #0xf]
    // 0x859960: r0 = 2
    //     0x859960: mov             x0, #2
    // 0x859964: StoreField: r1->field_b = r0
    //     0x859964: stur            w0, [x1, #0xb]
    // 0x859968: mov             x0, x1
    // 0x85996c: LeaveFrame
    //     0x85996c: mov             SP, fp
    //     0x859970: ldp             fp, lr, [SP], #0x10
    // 0x859974: ret
    //     0x859974: ret             
    // 0x859978: ldur            x2, [fp, #-8]
    // 0x85997c: ldur            x3, [fp, #-0x20]
    // 0x859980: r0 = LoadClassIdInstr(r3)
    //     0x859980: ldur            x0, [x3, #-1]
    //     0x859984: ubfx            x0, x0, #0xc, #0x14
    // 0x859988: mov             x1, x3
    // 0x85998c: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x85998c: mov             x17, #0x27b5
    //     0x859990: movk            x17, #1, lsl #16
    //     0x859994: add             lr, x0, x17
    //     0x859998: ldr             lr, [x21, lr, lsl #3]
    //     0x85999c: blr             lr
    // 0x8599a0: LoadField: r1 = r0->field_27
    //     0x8599a0: ldur            w1, [x0, #0x27]
    // 0x8599a4: DecompressPointer r1
    //     0x8599a4: add             x1, x1, HEAP, lsl #32
    // 0x8599a8: r16 = Instance_TextDirection
    //     0x8599a8: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0x8599ac: cmp             w1, w16
    // 0x8599b0: b.ne            #0x8599bc
    // 0x8599b4: LoadField: d0 = r0->field_7
    //     0x8599b4: ldur            d0, [x0, #7]
    // 0x8599b8: b               #0x8599c0
    // 0x8599bc: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x8599bc: ldur            d0, [x0, #0x17]
    // 0x8599c0: ldur            x0, [fp, #-8]
    // 0x8599c4: stur            d0, [fp, #-0x30]
    // 0x8599c8: LoadField: r2 = r0->field_a7
    //     0x8599c8: ldur            w2, [x0, #0xa7]
    // 0x8599cc: DecompressPointer r2
    //     0x8599cc: add             x2, x2, HEAP, lsl #32
    // 0x8599d0: mov             x1, x2
    // 0x8599d4: stur            x2, [fp, #-0x10]
    // 0x8599d8: r0 = size()
    //     0x8599d8: bl              #0x859c64  ; [package:flutter/src/painting/text_painter.dart] TextPainter::size
    // 0x8599dc: LoadField: d0 = r0->field_7
    //     0x8599dc: ldur            d0, [x0, #7]
    // 0x8599e0: ldur            d2, [fp, #-0x30]
    // 0x8599e4: d1 = 0.000000
    //     0x8599e4: eor             v1.16b, v1.16b, v1.16b
    // 0x8599e8: fcmp            d1, d2
    // 0x8599ec: b.le            #0x8599f8
    // 0x8599f0: d0 = 0.000000
    //     0x8599f0: eor             v0.16b, v0.16b, v0.16b
    // 0x8599f4: b               #0x859a0c
    // 0x8599f8: fcmp            d2, d0
    // 0x8599fc: b.gt            #0x859a0c
    // 0x859a00: fcmp            d2, d2
    // 0x859a04: b.vs            #0x859a0c
    // 0x859a08: mov             v0.16b, v2.16b
    // 0x859a0c: ldur            x2, [fp, #-0x20]
    // 0x859a10: stur            d0, [fp, #-0x30]
    // 0x859a14: r0 = LoadClassIdInstr(r2)
    //     0x859a14: ldur            x0, [x2, #-1]
    //     0x859a18: ubfx            x0, x0, #0xc, #0x14
    // 0x859a1c: mov             x1, x2
    // 0x859a20: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x859a20: mov             x17, #0x27b5
    //     0x859a24: movk            x17, #1, lsl #16
    //     0x859a28: add             lr, x0, x17
    //     0x859a2c: ldr             lr, [x21, lr, lsl #3]
    //     0x859a30: blr             lr
    // 0x859a34: LoadField: d0 = r0->field_1f
    //     0x859a34: ldur            d0, [x0, #0x1f]
    // 0x859a38: stur            d0, [fp, #-0x38]
    // 0x859a3c: r0 = Offset()
    //     0x859a3c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x859a40: ldur            d0, [fp, #-0x30]
    // 0x859a44: StoreField: r0->field_7 = d0
    //     0x859a44: stur            d0, [x0, #7]
    // 0x859a48: ldur            d0, [fp, #-0x38]
    // 0x859a4c: StoreField: r0->field_f = d0
    //     0x859a4c: stur            d0, [x0, #0xf]
    // 0x859a50: mov             x1, x0
    // 0x859a54: ldur            x2, [fp, #-0x18]
    // 0x859a58: r0 = +()
    //     0x859a58: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0x859a5c: mov             x3, x0
    // 0x859a60: ldur            x2, [fp, #-0x20]
    // 0x859a64: stur            x3, [fp, #-8]
    // 0x859a68: r0 = LoadClassIdInstr(r2)
    //     0x859a68: ldur            x0, [x2, #-1]
    //     0x859a6c: ubfx            x0, x0, #0xc, #0x14
    // 0x859a70: mov             x1, x2
    // 0x859a74: r0 = GDT[cid_x0 + 0x140c8]()
    //     0x859a74: mov             x17, #0x40c8
    //     0x859a78: movk            x17, #1, lsl #16
    //     0x859a7c: add             lr, x0, x17
    //     0x859a80: ldr             lr, [x21, lr, lsl #3]
    //     0x859a84: blr             lr
    // 0x859a88: LoadField: r1 = r0->field_27
    //     0x859a88: ldur            w1, [x0, #0x27]
    // 0x859a8c: DecompressPointer r1
    //     0x859a8c: add             x1, x1, HEAP, lsl #32
    // 0x859a90: r16 = Instance_TextDirection
    //     0x859a90: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0x859a94: cmp             w1, w16
    // 0x859a98: b.ne            #0x859aa4
    // 0x859a9c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x859a9c: ldur            d0, [x0, #0x17]
    // 0x859aa0: b               #0x859aa8
    // 0x859aa4: LoadField: d0 = r0->field_7
    //     0x859aa4: ldur            d0, [x0, #7]
    // 0x859aa8: ldur            x1, [fp, #-0x10]
    // 0x859aac: stur            d0, [fp, #-0x30]
    // 0x859ab0: r0 = size()
    //     0x859ab0: bl              #0x859c64  ; [package:flutter/src/painting/text_painter.dart] TextPainter::size
    // 0x859ab4: LoadField: d0 = r0->field_7
    //     0x859ab4: ldur            d0, [x0, #7]
    // 0x859ab8: ldur            d2, [fp, #-0x30]
    // 0x859abc: d1 = 0.000000
    //     0x859abc: eor             v1.16b, v1.16b, v1.16b
    // 0x859ac0: fcmp            d1, d2
    // 0x859ac4: b.le            #0x859ad0
    // 0x859ac8: d0 = 0.000000
    //     0x859ac8: eor             v0.16b, v0.16b, v0.16b
    // 0x859acc: b               #0x859ae4
    // 0x859ad0: fcmp            d2, d0
    // 0x859ad4: b.gt            #0x859ae4
    // 0x859ad8: fcmp            d2, d2
    // 0x859adc: b.vs            #0x859ae4
    // 0x859ae0: mov             v0.16b, v2.16b
    // 0x859ae4: ldur            x2, [fp, #-0x20]
    // 0x859ae8: ldur            x3, [fp, #-8]
    // 0x859aec: stur            d0, [fp, #-0x30]
    // 0x859af0: r0 = LoadClassIdInstr(r2)
    //     0x859af0: ldur            x0, [x2, #-1]
    //     0x859af4: ubfx            x0, x0, #0xc, #0x14
    // 0x859af8: mov             x1, x2
    // 0x859afc: r0 = GDT[cid_x0 + 0x140c8]()
    //     0x859afc: mov             x17, #0x40c8
    //     0x859b00: movk            x17, #1, lsl #16
    //     0x859b04: add             lr, x0, x17
    //     0x859b08: ldr             lr, [x21, lr, lsl #3]
    //     0x859b0c: blr             lr
    // 0x859b10: LoadField: d0 = r0->field_1f
    //     0x859b10: ldur            d0, [x0, #0x1f]
    // 0x859b14: stur            d0, [fp, #-0x38]
    // 0x859b18: r0 = Offset()
    //     0x859b18: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x859b1c: ldur            d0, [fp, #-0x30]
    // 0x859b20: StoreField: r0->field_7 = d0
    //     0x859b20: stur            d0, [x0, #7]
    // 0x859b24: ldur            d0, [fp, #-0x38]
    // 0x859b28: StoreField: r0->field_f = d0
    //     0x859b28: stur            d0, [x0, #0xf]
    // 0x859b2c: mov             x1, x0
    // 0x859b30: ldur            x2, [fp, #-0x18]
    // 0x859b34: r0 = +()
    //     0x859b34: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0x859b38: mov             x3, x0
    // 0x859b3c: ldur            x2, [fp, #-0x20]
    // 0x859b40: stur            x3, [fp, #-0x10]
    // 0x859b44: r0 = LoadClassIdInstr(r2)
    //     0x859b44: ldur            x0, [x2, #-1]
    //     0x859b48: ubfx            x0, x0, #0xc, #0x14
    // 0x859b4c: mov             x1, x2
    // 0x859b50: r0 = GDT[cid_x0 + 0x127b5]()
    //     0x859b50: mov             x17, #0x27b5
    //     0x859b54: movk            x17, #1, lsl #16
    //     0x859b58: add             lr, x0, x17
    //     0x859b5c: ldr             lr, [x21, lr, lsl #3]
    //     0x859b60: blr             lr
    // 0x859b64: LoadField: r1 = r0->field_27
    //     0x859b64: ldur            w1, [x0, #0x27]
    // 0x859b68: DecompressPointer r1
    //     0x859b68: add             x1, x1, HEAP, lsl #32
    // 0x859b6c: stur            x1, [fp, #-0x18]
    // 0x859b70: r0 = TextSelectionPoint()
    //     0x859b70: bl              #0x859e10  ; AllocateTextSelectionPointStub -> TextSelectionPoint (size=0x10)
    // 0x859b74: mov             x2, x0
    // 0x859b78: ldur            x0, [fp, #-8]
    // 0x859b7c: stur            x2, [fp, #-0x28]
    // 0x859b80: StoreField: r2->field_7 = r0
    //     0x859b80: stur            w0, [x2, #7]
    // 0x859b84: ldur            x0, [fp, #-0x18]
    // 0x859b88: StoreField: r2->field_b = r0
    //     0x859b88: stur            w0, [x2, #0xb]
    // 0x859b8c: ldur            x1, [fp, #-0x20]
    // 0x859b90: r0 = LoadClassIdInstr(r1)
    //     0x859b90: ldur            x0, [x1, #-1]
    //     0x859b94: ubfx            x0, x0, #0xc, #0x14
    // 0x859b98: r0 = GDT[cid_x0 + 0x140c8]()
    //     0x859b98: mov             x17, #0x40c8
    //     0x859b9c: movk            x17, #1, lsl #16
    //     0x859ba0: add             lr, x0, x17
    //     0x859ba4: ldr             lr, [x21, lr, lsl #3]
    //     0x859ba8: blr             lr
    // 0x859bac: LoadField: r1 = r0->field_27
    //     0x859bac: ldur            w1, [x0, #0x27]
    // 0x859bb0: DecompressPointer r1
    //     0x859bb0: add             x1, x1, HEAP, lsl #32
    // 0x859bb4: stur            x1, [fp, #-8]
    // 0x859bb8: r0 = TextSelectionPoint()
    //     0x859bb8: bl              #0x859e10  ; AllocateTextSelectionPointStub -> TextSelectionPoint (size=0x10)
    // 0x859bbc: mov             x3, x0
    // 0x859bc0: ldur            x0, [fp, #-0x10]
    // 0x859bc4: stur            x3, [fp, #-0x18]
    // 0x859bc8: StoreField: r3->field_7 = r0
    //     0x859bc8: stur            w0, [x3, #7]
    // 0x859bcc: ldur            x0, [fp, #-8]
    // 0x859bd0: StoreField: r3->field_b = r0
    //     0x859bd0: stur            w0, [x3, #0xb]
    // 0x859bd4: r1 = Null
    //     0x859bd4: mov             x1, NULL
    // 0x859bd8: r2 = 4
    //     0x859bd8: mov             x2, #4
    // 0x859bdc: r0 = AllocateArray()
    //     0x859bdc: bl              #0x13df928  ; AllocateArrayStub
    // 0x859be0: mov             x2, x0
    // 0x859be4: ldur            x0, [fp, #-0x28]
    // 0x859be8: stur            x2, [fp, #-8]
    // 0x859bec: StoreField: r2->field_f = r0
    //     0x859bec: stur            w0, [x2, #0xf]
    // 0x859bf0: ldur            x0, [fp, #-0x18]
    // 0x859bf4: StoreField: r2->field_13 = r0
    //     0x859bf4: stur            w0, [x2, #0x13]
    // 0x859bf8: r1 = <TextSelectionPoint>
    //     0x859bf8: ldr             x1, [PP, #0x4d98]  ; [pp+0x4d98] TypeArguments: <TextSelectionPoint>
    // 0x859bfc: r0 = AllocateGrowableArray()
    //     0x859bfc: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x859c00: ldur            x1, [fp, #-8]
    // 0x859c04: StoreField: r0->field_f = r1
    //     0x859c04: stur            w1, [x0, #0xf]
    // 0x859c08: r1 = 4
    //     0x859c08: mov             x1, #4
    // 0x859c0c: StoreField: r0->field_b = r1
    //     0x859c0c: stur            w1, [x0, #0xb]
    // 0x859c10: LeaveFrame
    //     0x859c10: mov             SP, fp
    //     0x859c14: ldp             fp, lr, [SP], #0x10
    // 0x859c18: ret
    //     0x859c18: ret             
    // 0x859c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859c1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859c20: b               #0x859800
    // 0x859c24: r9 = _caretPrototype
    //     0x859c24: ldr             x9, [PP, #0x49b0]  ; [pp+0x49b0] Field <RenderEditable._caretPrototype@80245603>: late (offset: 0x130)
    // 0x859c28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x859c28: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ preferredLineHeight(/* No info */) {
    // ** addr: 0x859c2c, size: 0x38
    // 0x859c2c: EnterFrame
    //     0x859c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x859c30: mov             fp, SP
    // 0x859c34: CheckStackOverflow
    //     0x859c34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x859c38: cmp             SP, x16
    //     0x859c3c: b.ls            #0x859c5c
    // 0x859c40: LoadField: r0 = r1->field_a7
    //     0x859c40: ldur            w0, [x1, #0xa7]
    // 0x859c44: DecompressPointer r0
    //     0x859c44: add             x0, x0, HEAP, lsl #32
    // 0x859c48: mov             x1, x0
    // 0x859c4c: r0 = preferredLineHeight()
    //     0x859c4c: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x859c50: LeaveFrame
    //     0x859c50: mov             SP, fp
    //     0x859c54: ldp             fp, lr, [SP], #0x10
    // 0x859c58: ret
    //     0x859c58: ret             
    // 0x859c5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859c5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859c60: b               #0x859c40
  }
  get _ _paintOffset(/* No info */) {
    // ** addr: 0x85ff30, size: 0xc4
    // 0x85ff30: EnterFrame
    //     0x85ff30: stp             fp, lr, [SP, #-0x10]!
    //     0x85ff34: mov             fp, SP
    // 0x85ff38: AllocStack(0x10)
    //     0x85ff38: sub             SP, SP, #0x10
    // 0x85ff3c: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0x85ff3c: mov             x0, x1
    //     0x85ff40: stur            x1, [fp, #-8]
    // 0x85ff44: CheckStackOverflow
    //     0x85ff44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x85ff48: cmp             SP, x16
    //     0x85ff4c: b.ls            #0x85ffe4
    // 0x85ff50: mov             x1, x0
    // 0x85ff54: r0 = _viewportAxis()
    //     0x85ff54: bl              #0x85fff4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_viewportAxis
    // 0x85ff58: LoadField: r1 = r0->field_7
    //     0x85ff58: ldur            x1, [x0, #7]
    // 0x85ff5c: cmp             x1, #0
    // 0x85ff60: b.gt            #0x85ffa0
    // 0x85ff64: ldur            x0, [fp, #-8]
    // 0x85ff68: LoadField: r1 = r0->field_db
    //     0x85ff68: ldur            w1, [x0, #0xdb]
    // 0x85ff6c: DecompressPointer r1
    //     0x85ff6c: add             x1, x1, HEAP, lsl #32
    // 0x85ff70: LoadField: r0 = r1->field_3f
    //     0x85ff70: ldur            w0, [x1, #0x3f]
    // 0x85ff74: DecompressPointer r0
    //     0x85ff74: add             x0, x0, HEAP, lsl #32
    // 0x85ff78: cmp             w0, NULL
    // 0x85ff7c: b.eq            #0x85ffec
    // 0x85ff80: LoadField: d0 = r0->field_7
    //     0x85ff80: ldur            d0, [x0, #7]
    // 0x85ff84: fneg            d1, d0
    // 0x85ff88: stur            d1, [fp, #-0x10]
    // 0x85ff8c: r0 = Offset()
    //     0x85ff8c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85ff90: ldur            d0, [fp, #-0x10]
    // 0x85ff94: StoreField: r0->field_7 = d0
    //     0x85ff94: stur            d0, [x0, #7]
    // 0x85ff98: StoreField: r0->field_f = rZR
    //     0x85ff98: stur            xzr, [x0, #0xf]
    // 0x85ff9c: b               #0x85ffd8
    // 0x85ffa0: ldur            x0, [fp, #-8]
    // 0x85ffa4: LoadField: r1 = r0->field_db
    //     0x85ffa4: ldur            w1, [x0, #0xdb]
    // 0x85ffa8: DecompressPointer r1
    //     0x85ffa8: add             x1, x1, HEAP, lsl #32
    // 0x85ffac: LoadField: r0 = r1->field_3f
    //     0x85ffac: ldur            w0, [x1, #0x3f]
    // 0x85ffb0: DecompressPointer r0
    //     0x85ffb0: add             x0, x0, HEAP, lsl #32
    // 0x85ffb4: cmp             w0, NULL
    // 0x85ffb8: b.eq            #0x85fff0
    // 0x85ffbc: LoadField: d0 = r0->field_7
    //     0x85ffbc: ldur            d0, [x0, #7]
    // 0x85ffc0: fneg            d1, d0
    // 0x85ffc4: stur            d1, [fp, #-0x10]
    // 0x85ffc8: r0 = Offset()
    //     0x85ffc8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85ffcc: StoreField: r0->field_7 = rZR
    //     0x85ffcc: stur            xzr, [x0, #7]
    // 0x85ffd0: ldur            d0, [fp, #-0x10]
    // 0x85ffd4: StoreField: r0->field_f = d0
    //     0x85ffd4: stur            d0, [x0, #0xf]
    // 0x85ffd8: LeaveFrame
    //     0x85ffd8: mov             SP, fp
    //     0x85ffdc: ldp             fp, lr, [SP], #0x10
    // 0x85ffe0: ret
    //     0x85ffe0: ret             
    // 0x85ffe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85ffe4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85ffe8: b               #0x85ff50
    // 0x85ffec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85ffec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85fff0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85fff0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _viewportAxis(/* No info */) {
    // ** addr: 0x85fff4, size: 0x3c
    // 0x85fff4: EnterFrame
    //     0x85fff4: stp             fp, lr, [SP, #-0x10]!
    //     0x85fff8: mov             fp, SP
    // 0x85fffc: CheckStackOverflow
    //     0x85fffc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x860000: cmp             SP, x16
    //     0x860004: b.ls            #0x860028
    // 0x860008: r0 = _isMultiline()
    //     0x860008: bl              #0x860030  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_isMultiline
    // 0x86000c: tbnz            w0, #4, #0x860018
    // 0x860010: r0 = Instance_Axis
    //     0x860010: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0x860014: b               #0x86001c
    // 0x860018: r0 = Instance_Axis
    //     0x860018: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0x86001c: LeaveFrame
    //     0x86001c: mov             SP, fp
    //     0x860020: ldp             fp, lr, [SP], #0x10
    // 0x860024: ret
    //     0x860024: ret             
    // 0x860028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860028: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86002c: b               #0x860008
  }
  get _ _isMultiline(/* No info */) {
    // ** addr: 0x860030, size: 0x1c
    // 0x860030: LoadField: r2 = r1->field_cb
    //     0x860030: ldur            w2, [x1, #0xcb]
    // 0x860034: DecompressPointer r2
    //     0x860034: add             x2, x2, HEAP, lsl #32
    // 0x860038: cmp             w2, #2
    // 0x86003c: r16 = true
    //     0x86003c: add             x16, NULL, #0x20  ; true
    // 0x860040: r17 = false
    //     0x860040: add             x17, NULL, #0x30  ; false
    // 0x860044: csel            x0, x16, x17, ne
    // 0x860048: ret
    //     0x860048: ret             
  }
  _ _computeTextMetricsIfNeeded(/* No info */) {
    // ** addr: 0x86004c, size: 0x140
    // 0x86004c: EnterFrame
    //     0x86004c: stp             fp, lr, [SP, #-0x10]!
    //     0x860050: mov             fp, SP
    // 0x860054: AllocStack(0x28)
    //     0x860054: sub             SP, SP, #0x28
    // 0x860058: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0x860058: mov             x0, x1
    //     0x86005c: stur            x1, [fp, #-8]
    // 0x860060: CheckStackOverflow
    //     0x860060: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x860064: cmp             SP, x16
    //     0x860068: b.ls            #0x860158
    // 0x86006c: mov             x1, x0
    // 0x860070: r0 = constraints()
    //     0x860070: bl              #0xcce9b0  ; [package:flutter/src/rendering/box.dart] RenderBox::constraints
    // 0x860074: LoadField: d0 = r0->field_7
    //     0x860074: ldur            d0, [x0, #7]
    // 0x860078: ldur            x1, [fp, #-8]
    // 0x86007c: stur            d0, [fp, #-0x18]
    // 0x860080: r0 = constraints()
    //     0x860080: bl              #0x860ce4  ; [package:flutter/src/rendering/object.dart] RenderObject::constraints
    // 0x860084: mov             x3, x0
    // 0x860088: r2 = Null
    //     0x860088: mov             x2, NULL
    // 0x86008c: r1 = Null
    //     0x86008c: mov             x1, NULL
    // 0x860090: stur            x3, [fp, #-0x10]
    // 0x860094: r4 = LoadClassIdInstr(r0)
    //     0x860094: ldur            x4, [x0, #-1]
    //     0x860098: ubfx            x4, x4, #0xc, #0x14
    // 0x86009c: sub             x4, x4, #0xb46
    // 0x8600a0: cmp             x4, #1
    // 0x8600a4: b.ls            #0x8600b4
    // 0x8600a8: r8 = BoxConstraints
    //     0x8600a8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0x8600ac: r3 = Null
    //     0x8600ac: ldr             x3, [PP, #0x4c98]  ; [pp+0x4c98] Null
    // 0x8600b0: r0 = BoxConstraints()
    //     0x8600b0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0x8600b4: ldur            x0, [fp, #-0x10]
    // 0x8600b8: LoadField: d0 = r0->field_f
    //     0x8600b8: ldur            d0, [x0, #0xf]
    // 0x8600bc: ldur            d1, [fp, #-0x18]
    // 0x8600c0: r0 = inline_Allocate_Double()
    //     0x8600c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8600c4: add             x0, x0, #0x10
    //     0x8600c8: cmp             x1, x0
    //     0x8600cc: b.ls            #0x860160
    //     0x8600d0: str             x0, [THR, #0x60]  ; THR::top
    //     0x8600d4: sub             x0, x0, #0xf
    //     0x8600d8: mov             x1, #0xe19c
    //     0x8600dc: movk            x1, #3, lsl #16
    //     0x8600e0: stur            x1, [x0, #-1]
    // 0x8600e4: dmb             ishst
    // 0x8600e8: StoreField: r0->field_7 = d1
    //     0x8600e8: stur            d1, [x0, #7]
    // 0x8600ec: r1 = inline_Allocate_Double()
    //     0x8600ec: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x8600f0: add             x1, x1, #0x10
    //     0x8600f4: cmp             x2, x1
    //     0x8600f8: b.ls            #0x860170
    //     0x8600fc: str             x1, [THR, #0x60]  ; THR::top
    //     0x860100: sub             x1, x1, #0xf
    //     0x860104: mov             x2, #0xe19c
    //     0x860108: movk            x2, #3, lsl #16
    //     0x86010c: stur            x2, [x1, #-1]
    // 0x860110: dmb             ishst
    // 0x860114: StoreField: r1->field_7 = d0
    //     0x860114: stur            d0, [x1, #7]
    // 0x860118: stp             x1, x0, [SP]
    // 0x86011c: ldur            x1, [fp, #-8]
    // 0x860120: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x860120: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0x860124: r0 = _adjustConstraints()
    //     0x860124: bl              #0x860b7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_adjustConstraints
    // 0x860128: mov             x2, x0
    // 0x86012c: mov             x3, x1
    // 0x860130: ldur            x0, [fp, #-8]
    // 0x860134: LoadField: r1 = r0->field_a7
    //     0x860134: ldur            w1, [x0, #0xa7]
    // 0x860138: DecompressPointer r1
    //     0x860138: add             x1, x1, HEAP, lsl #32
    // 0x86013c: stp             x3, x2, [SP]
    // 0x860140: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x860140: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0x860144: r0 = layout()
    //     0x860144: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0x860148: r0 = Null
    //     0x860148: mov             x0, NULL
    // 0x86014c: LeaveFrame
    //     0x86014c: mov             SP, fp
    //     0x860150: ldp             fp, lr, [SP], #0x10
    // 0x860154: ret
    //     0x860154: ret             
    // 0x860158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860158: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86015c: b               #0x86006c
    // 0x860160: stp             q0, q1, [SP, #-0x20]!
    // 0x860164: r0 = AllocateDouble()
    //     0x860164: bl              #0x13df878  ; AllocateDoubleStub
    // 0x860168: ldp             q0, q1, [SP], #0x20
    // 0x86016c: b               #0x8600e8
    // 0x860170: SaveReg d0
    //     0x860170: str             q0, [SP, #-0x10]!
    // 0x860174: SaveReg r0
    //     0x860174: str             x0, [SP, #-8]!
    // 0x860178: r0 = AllocateDouble()
    //     0x860178: bl              #0x13df878  ; AllocateDoubleStub
    // 0x86017c: mov             x1, x0
    // 0x860180: RestoreReg r0
    //     0x860180: ldr             x0, [SP], #8
    // 0x860184: RestoreReg d0
    //     0x860184: ldr             q0, [SP], #0x10
    // 0x860188: b               #0x860114
  }
  _ _adjustConstraints(/* No info */) {
    // ** addr: 0x860b7c, size: 0x168
    // 0x860b7c: EnterFrame
    //     0x860b7c: stp             fp, lr, [SP, #-0x10]!
    //     0x860b80: mov             fp, SP
    // 0x860b84: LoadField: r2 = r4->field_13
    //     0x860b84: ldur            w2, [x4, #0x13]
    // 0x860b88: LoadField: r3 = r4->field_1f
    //     0x860b88: ldur            w3, [x4, #0x1f]
    // 0x860b8c: DecompressPointer r3
    //     0x860b8c: add             x3, x3, HEAP, lsl #32
    // 0x860b90: r16 = "maxWidth"
    //     0x860b90: ldr             x16, [PP, #0x4cb0]  ; [pp+0x4cb0] "maxWidth"
    // 0x860b94: cmp             w3, w16
    // 0x860b98: b.ne            #0x860bbc
    // 0x860b9c: LoadField: r3 = r4->field_23
    //     0x860b9c: ldur            w3, [x4, #0x23]
    // 0x860ba0: DecompressPointer r3
    //     0x860ba0: add             x3, x3, HEAP, lsl #32
    // 0x860ba4: sub             w5, w2, w3
    // 0x860ba8: add             x3, fp, w5, sxtw #2
    // 0x860bac: ldr             x3, [x3, #8]
    // 0x860bb0: LoadField: d0 = r3->field_7
    //     0x860bb0: ldur            d0, [x3, #7]
    // 0x860bb4: r3 = 1
    //     0x860bb4: mov             x3, #1
    // 0x860bb8: b               #0x860bc4
    // 0x860bbc: d0 = inf
    //     0x860bbc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x860bc0: r3 = 0
    //     0x860bc0: mov             x3, #0
    // 0x860bc4: lsl             x5, x3, #1
    // 0x860bc8: lsl             w3, w5, #1
    // 0x860bcc: add             w5, w3, #8
    // 0x860bd0: ArrayLoad: r6 = r4[r5]  ; Unknown_4
    //     0x860bd0: add             x16, x4, w5, sxtw #1
    //     0x860bd4: ldur            w6, [x16, #0xf]
    // 0x860bd8: DecompressPointer r6
    //     0x860bd8: add             x6, x6, HEAP, lsl #32
    // 0x860bdc: r16 = "minWidth"
    //     0x860bdc: ldr             x16, [PP, #0x4cb8]  ; [pp+0x4cb8] "minWidth"
    // 0x860be0: cmp             w6, w16
    // 0x860be4: b.ne            #0x860c10
    // 0x860be8: add             w5, w3, #0xa
    // 0x860bec: ArrayLoad: r3 = r4[r5]  ; Unknown_4
    //     0x860bec: add             x16, x4, w5, sxtw #1
    //     0x860bf0: ldur            w3, [x16, #0xf]
    // 0x860bf4: DecompressPointer r3
    //     0x860bf4: add             x3, x3, HEAP, lsl #32
    // 0x860bf8: sub             w4, w2, w3
    // 0x860bfc: add             x2, fp, w4, sxtw #2
    // 0x860c00: ldr             x2, [x2, #8]
    // 0x860c04: LoadField: d1 = r2->field_7
    //     0x860c04: ldur            d1, [x2, #7]
    // 0x860c08: mov             v3.16b, v1.16b
    // 0x860c0c: b               #0x860c14
    // 0x860c10: d3 = 0.000000
    //     0x860c10: eor             v3.16b, v3.16b, v3.16b
    // 0x860c14: d2 = 0.000000
    //     0x860c14: eor             v2.16b, v2.16b, v2.16b
    // 0x860c18: d1 = 1.000000
    //     0x860c18: fmov            d1, #1.00000000
    // 0x860c1c: LoadField: d4 = r1->field_df
    //     0x860c1c: ldur            d4, [x1, #0xdf]
    // 0x860c20: fadd            d5, d4, d1
    // 0x860c24: fsub            d1, d0, d5
    // 0x860c28: fmax            v0.2d, v2.2d, v1.2d
    // 0x860c2c: fmin            v1.2d, v3.2d, v0.2d
    // 0x860c30: LoadField: r2 = r1->field_c3
    //     0x860c30: ldur            w2, [x1, #0xc3]
    // 0x860c34: DecompressPointer r2
    //     0x860c34: add             x2, x2, HEAP, lsl #32
    // 0x860c38: tbnz            w2, #4, #0x860c40
    // 0x860c3c: mov             v1.16b, v0.16b
    // 0x860c40: LoadField: r2 = r1->field_cb
    //     0x860c40: ldur            w2, [x1, #0xcb]
    // 0x860c44: DecompressPointer r2
    //     0x860c44: add             x2, x2, HEAP, lsl #32
    // 0x860c48: cmp             w2, #2
    // 0x860c4c: b.ne            #0x860c54
    // 0x860c50: d0 = inf
    //     0x860c50: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x860c54: r0 = inline_Allocate_Double()
    //     0x860c54: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x860c58: add             x0, x0, #0x10
    //     0x860c5c: cmp             x2, x0
    //     0x860c60: b.ls            #0x860cb8
    //     0x860c64: str             x0, [THR, #0x60]  ; THR::top
    //     0x860c68: sub             x0, x0, #0xf
    //     0x860c6c: mov             x2, #0xe19c
    //     0x860c70: movk            x2, #3, lsl #16
    //     0x860c74: stur            x2, [x0, #-1]
    // 0x860c78: dmb             ishst
    // 0x860c7c: StoreField: r0->field_7 = d1
    //     0x860c7c: stur            d1, [x0, #7]
    // 0x860c80: r1 = inline_Allocate_Double()
    //     0x860c80: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x860c84: add             x1, x1, #0x10
    //     0x860c88: cmp             x2, x1
    //     0x860c8c: b.ls            #0x860cc8
    //     0x860c90: str             x1, [THR, #0x60]  ; THR::top
    //     0x860c94: sub             x1, x1, #0xf
    //     0x860c98: mov             x2, #0xe19c
    //     0x860c9c: movk            x2, #3, lsl #16
    //     0x860ca0: stur            x2, [x1, #-1]
    // 0x860ca4: dmb             ishst
    // 0x860ca8: StoreField: r1->field_7 = d0
    //     0x860ca8: stur            d0, [x1, #7]
    // 0x860cac: LeaveFrame
    //     0x860cac: mov             SP, fp
    //     0x860cb0: ldp             fp, lr, [SP], #0x10
    // 0x860cb4: ret
    //     0x860cb4: ret             
    // 0x860cb8: stp             q0, q1, [SP, #-0x20]!
    // 0x860cbc: r0 = AllocateDouble()
    //     0x860cbc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x860cc0: ldp             q0, q1, [SP], #0x20
    // 0x860cc4: b               #0x860c7c
    // 0x860cc8: SaveReg d0
    //     0x860cc8: str             q0, [SP, #-0x10]!
    // 0x860ccc: SaveReg r0
    //     0x860ccc: str             x0, [SP, #-8]!
    // 0x860cd0: r0 = AllocateDouble()
    //     0x860cd0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x860cd4: mov             x1, x0
    // 0x860cd8: RestoreReg r0
    //     0x860cd8: ldr             x0, [SP], #8
    // 0x860cdc: RestoreReg d0
    //     0x860cdc: ldr             q0, [SP], #0x10
    // 0x860ce0: b               #0x860ca8
  }
  _ getRectForComposingRange(/* No info */) {
    // ** addr: 0x860f58, size: 0x14c
    // 0x860f58: EnterFrame
    //     0x860f58: stp             fp, lr, [SP, #-0x10]!
    //     0x860f5c: mov             fp, SP
    // 0x860f60: AllocStack(0x40)
    //     0x860f60: sub             SP, SP, #0x40
    // 0x860f64: SetupParameters(RenderEditable this /* r1 => r0, fp-0x18 */)
    //     0x860f64: mov             x0, x1
    //     0x860f68: stur            x1, [fp, #-0x18]
    // 0x860f6c: CheckStackOverflow
    //     0x860f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x860f70: cmp             SP, x16
    //     0x860f74: b.ls            #0x86109c
    // 0x860f78: LoadField: r3 = r2->field_7
    //     0x860f78: ldur            x3, [x2, #7]
    // 0x860f7c: stur            x3, [fp, #-0x10]
    // 0x860f80: tbnz            x3, #0x3f, #0x86108c
    // 0x860f84: LoadField: r4 = r2->field_f
    //     0x860f84: ldur            x4, [x2, #0xf]
    // 0x860f88: stur            x4, [fp, #-8]
    // 0x860f8c: tbnz            x4, #0x3f, #0x86108c
    // 0x860f90: cmp             x3, x4
    // 0x860f94: b.eq            #0x86108c
    // 0x860f98: mov             x1, x0
    // 0x860f9c: r0 = _computeTextMetricsIfNeeded()
    //     0x860f9c: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0x860fa0: ldur            x1, [fp, #-0x18]
    // 0x860fa4: LoadField: r0 = r1->field_a7
    //     0x860fa4: ldur            w0, [x1, #0xa7]
    // 0x860fa8: DecompressPointer r0
    //     0x860fa8: add             x0, x0, HEAP, lsl #32
    // 0x860fac: stur            x0, [fp, #-0x20]
    // 0x860fb0: r0 = TextSelection()
    //     0x860fb0: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x860fb4: mov             x1, x0
    // 0x860fb8: ldur            x0, [fp, #-0x10]
    // 0x860fbc: ArrayStore: r1[0] = r0  ; List_8
    //     0x860fbc: stur            x0, [x1, #0x17]
    // 0x860fc0: ldur            x2, [fp, #-8]
    // 0x860fc4: StoreField: r1->field_1f = r2
    //     0x860fc4: stur            x2, [x1, #0x1f]
    // 0x860fc8: r3 = Instance_TextAffinity
    //     0x860fc8: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x860fcc: StoreField: r1->field_27 = r3
    //     0x860fcc: stur            w3, [x1, #0x27]
    // 0x860fd0: r3 = false
    //     0x860fd0: add             x3, NULL, #0x30  ; false
    // 0x860fd4: StoreField: r1->field_2b = r3
    //     0x860fd4: stur            w3, [x1, #0x2b]
    // 0x860fd8: cmp             x0, x2
    // 0x860fdc: b.ge            #0x860fe8
    // 0x860fe0: mov             x3, x0
    // 0x860fe4: b               #0x860fec
    // 0x860fe8: mov             x3, x2
    // 0x860fec: cmp             x0, x2
    // 0x860ff0: b.lt            #0x860ff8
    // 0x860ff4: mov             x2, x0
    // 0x860ff8: ldur            x0, [fp, #-0x18]
    // 0x860ffc: StoreField: r1->field_7 = r3
    //     0x860ffc: stur            x3, [x1, #7]
    // 0x861000: StoreField: r1->field_f = r2
    //     0x861000: stur            x2, [x1, #0xf]
    // 0x861004: LoadField: r2 = r0->field_77
    //     0x861004: ldur            w2, [x0, #0x77]
    // 0x861008: DecompressPointer r2
    //     0x861008: add             x2, x2, HEAP, lsl #32
    // 0x86100c: LoadField: r3 = r2->field_2f
    //     0x86100c: ldur            w3, [x2, #0x2f]
    // 0x861010: DecompressPointer r3
    //     0x861010: add             x3, x3, HEAP, lsl #32
    // 0x861014: LoadField: r4 = r2->field_33
    //     0x861014: ldur            w4, [x2, #0x33]
    // 0x861018: DecompressPointer r4
    //     0x861018: add             x4, x4, HEAP, lsl #32
    // 0x86101c: stp             x4, x3, [SP]
    // 0x861020: mov             x2, x1
    // 0x861024: ldur            x1, [fp, #-0x20]
    // 0x861028: r4 = const [0, 0x4, 0x2, 0x2, boxHeightStyle, 0x2, boxWidthStyle, 0x3, null]
    //     0x861028: ldr             x4, [PP, #0x4d00]  ; [pp+0x4d00] List(9) [0, 0x4, 0x2, 0x2, "boxHeightStyle", 0x2, "boxWidthStyle", 0x3, Null]
    // 0x86102c: r0 = getBoxesForSelection()
    //     0x86102c: bl              #0x85fc0c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x861030: r1 = Function '<anonymous closure>':.
    //     0x861030: ldr             x1, [PP, #0x4db0]  ; [pp+0x4db0] AnonymousClosure: (0x861298), in [package:flutter/src/rendering/editable.dart] RenderEditable::getRectForComposingRange (0x860f58)
    // 0x861034: r2 = Null
    //     0x861034: mov             x2, NULL
    // 0x861038: stur            x0, [fp, #-0x20]
    // 0x86103c: r0 = AllocateClosure()
    //     0x86103c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x861040: r16 = <Rect?>
    //     0x861040: ldr             x16, [PP, #0x4db8]  ; [pp+0x4db8] TypeArguments: <Rect?>
    // 0x861044: ldur            lr, [fp, #-0x20]
    // 0x861048: stp             lr, x16, [SP, #0x10]
    // 0x86104c: stp             x0, NULL, [SP]
    // 0x861050: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x861050: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x861054: r0 = fold()
    //     0x861054: bl              #0x861118  ; [dart:collection] ListBase::fold
    // 0x861058: stur            x0, [fp, #-0x20]
    // 0x86105c: cmp             w0, NULL
    // 0x861060: b.ne            #0x86106c
    // 0x861064: r0 = Null
    //     0x861064: mov             x0, NULL
    // 0x861068: b               #0x861080
    // 0x86106c: ldur            x1, [fp, #-0x18]
    // 0x861070: r0 = _paintOffset()
    //     0x861070: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x861074: ldur            x1, [fp, #-0x20]
    // 0x861078: mov             x2, x0
    // 0x86107c: r0 = shift()
    //     0x86107c: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x861080: LeaveFrame
    //     0x861080: mov             SP, fp
    //     0x861084: ldp             fp, lr, [SP], #0x10
    // 0x861088: ret
    //     0x861088: ret             
    // 0x86108c: r0 = Null
    //     0x86108c: mov             x0, NULL
    // 0x861090: LeaveFrame
    //     0x861090: mov             SP, fp
    //     0x861094: ldp             fp, lr, [SP], #0x10
    // 0x861098: ret
    //     0x861098: ret             
    // 0x86109c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86109c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8610a0: b               #0x860f78
  }
  [closure] Rect <anonymous closure>(dynamic, Rect?, TextBox) {
    // ** addr: 0x861298, size: 0x60
    // 0x861298: EnterFrame
    //     0x861298: stp             fp, lr, [SP, #-0x10]!
    //     0x86129c: mov             fp, SP
    // 0x8612a0: CheckStackOverflow
    //     0x8612a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8612a4: cmp             SP, x16
    //     0x8612a8: b.ls            #0x8612f0
    // 0x8612ac: ldr             x0, [fp, #0x18]
    // 0x8612b0: cmp             w0, NULL
    // 0x8612b4: b.ne            #0x8612c0
    // 0x8612b8: r0 = Null
    //     0x8612b8: mov             x0, NULL
    // 0x8612bc: b               #0x8612d4
    // 0x8612c0: ldr             x1, [fp, #0x10]
    // 0x8612c4: r0 = toRect()
    //     0x8612c4: bl              #0x861374  ; [dart:ui] TextBox::toRect
    // 0x8612c8: ldr             x1, [fp, #0x18]
    // 0x8612cc: mov             x2, x0
    // 0x8612d0: r0 = expandToInclude()
    //     0x8612d0: bl              #0x8612f8  ; [dart:ui] Rect::expandToInclude
    // 0x8612d4: cmp             w0, NULL
    // 0x8612d8: b.ne            #0x8612e4
    // 0x8612dc: ldr             x1, [fp, #0x10]
    // 0x8612e0: r0 = toRect()
    //     0x8612e0: bl              #0x861374  ; [dart:ui] TextBox::toRect
    // 0x8612e4: LeaveFrame
    //     0x8612e4: mov             SP, fp
    //     0x8612e8: ldp             fp, lr, [SP], #0x10
    // 0x8612ec: ret
    //     0x8612ec: ret             
    // 0x8612f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8612f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8612f4: b               #0x8612ac
  }
  get _ plainText(/* No info */) {
    // ** addr: 0x861ca8, size: 0x38
    // 0x861ca8: EnterFrame
    //     0x861ca8: stp             fp, lr, [SP, #-0x10]!
    //     0x861cac: mov             fp, SP
    // 0x861cb0: CheckStackOverflow
    //     0x861cb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x861cb4: cmp             SP, x16
    //     0x861cb8: b.ls            #0x861cd8
    // 0x861cbc: LoadField: r0 = r1->field_a7
    //     0x861cbc: ldur            w0, [x1, #0xa7]
    // 0x861cc0: DecompressPointer r0
    //     0x861cc0: add             x0, x0, HEAP, lsl #32
    // 0x861cc4: mov             x1, x0
    // 0x861cc8: r0 = plainText()
    //     0x861cc8: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x861ccc: LeaveFrame
    //     0x861ccc: mov             SP, fp
    //     0x861cd0: ldp             fp, lr, [SP], #0x10
    // 0x861cd4: ret
    //     0x861cd4: ret             
    // 0x861cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x861cd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x861cdc: b               #0x861cbc
  }
  get _ textDirection(/* No info */) {
    // ** addr: 0x862018, size: 0x28
    // 0x862018: LoadField: r2 = r1->field_a7
    //     0x862018: ldur            w2, [x1, #0xa7]
    // 0x86201c: DecompressPointer r2
    //     0x86201c: add             x2, x2, HEAP, lsl #32
    // 0x862020: LoadField: r0 = r2->field_1b
    //     0x862020: ldur            w0, [x2, #0x1b]
    // 0x862024: DecompressPointer r0
    //     0x862024: add             x0, x0, HEAP, lsl #32
    // 0x862028: cmp             w0, NULL
    // 0x86202c: b.eq            #0x862034
    // 0x862030: ret
    //     0x862030: ret             
    // 0x862034: EnterFrame
    //     0x862034: stp             fp, lr, [SP, #-0x10]!
    //     0x862038: mov             fp, SP
    // 0x86203c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86203c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getLocalRectForCaret(/* No info */) {
    // ** addr: 0x862c30, size: 0x264
    // 0x862c30: EnterFrame
    //     0x862c30: stp             fp, lr, [SP, #-0x10]!
    //     0x862c34: mov             fp, SP
    // 0x862c38: AllocStack(0x48)
    //     0x862c38: sub             SP, SP, #0x48
    // 0x862c3c: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x862c3c: mov             x0, x1
    //     0x862c40: stur            x1, [fp, #-8]
    //     0x862c44: stur            x2, [fp, #-0x10]
    // 0x862c48: CheckStackOverflow
    //     0x862c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x862c4c: cmp             SP, x16
    //     0x862c50: b.ls            #0x862e80
    // 0x862c54: mov             x1, x0
    // 0x862c58: r0 = _computeTextMetricsIfNeeded()
    //     0x862c58: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0x862c5c: ldur            x0, [fp, #-8]
    // 0x862c60: r17 = 303
    //     0x862c60: mov             x17, #0x12f
    // 0x862c64: ldr             w4, [x0, x17]
    // 0x862c68: DecompressPointer r4
    //     0x862c68: add             x4, x4, HEAP, lsl #32
    // 0x862c6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x862c70: cmp             w4, w16
    // 0x862c74: b.eq            #0x862e88
    // 0x862c78: stur            x4, [fp, #-0x20]
    // 0x862c7c: LoadField: r5 = r0->field_a7
    //     0x862c7c: ldur            w5, [x0, #0xa7]
    // 0x862c80: DecompressPointer r5
    //     0x862c80: add             x5, x5, HEAP, lsl #32
    // 0x862c84: mov             x1, x5
    // 0x862c88: ldur            x2, [fp, #-0x10]
    // 0x862c8c: mov             x3, x4
    // 0x862c90: stur            x5, [fp, #-0x18]
    // 0x862c94: r0 = getOffsetForCaret()
    //     0x862c94: bl              #0x85dc3c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetForCaret
    // 0x862c98: ldur            x1, [fp, #-8]
    // 0x862c9c: stur            x0, [fp, #-0x28]
    // 0x862ca0: r0 = cursorOffset()
    //     0x862ca0: bl              #0x86332c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::cursorOffset
    // 0x862ca4: ldur            x1, [fp, #-0x28]
    // 0x862ca8: mov             x2, x0
    // 0x862cac: r0 = +()
    //     0x862cac: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0x862cb0: ldur            x1, [fp, #-0x20]
    // 0x862cb4: mov             x2, x0
    // 0x862cb8: r0 = shift()
    //     0x862cb8: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x862cbc: mov             x2, x0
    // 0x862cc0: ldur            x0, [fp, #-0x18]
    // 0x862cc4: stur            x2, [fp, #-0x20]
    // 0x862cc8: LoadField: r1 = r0->field_7
    //     0x862cc8: ldur            w1, [x0, #7]
    // 0x862ccc: DecompressPointer r1
    //     0x862ccc: add             x1, x1, HEAP, lsl #32
    // 0x862cd0: cmp             w1, NULL
    // 0x862cd4: b.eq            #0x862e90
    // 0x862cd8: LoadField: d0 = r1->field_13
    //     0x862cd8: ldur            d0, [x1, #0x13]
    // 0x862cdc: ldur            x1, [fp, #-8]
    // 0x862ce0: stur            d0, [fp, #-0x30]
    // 0x862ce4: r0 = _caretMargin()
    //     0x862ce4: bl              #0x86331c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_caretMargin
    // 0x862ce8: mov             v1.16b, v0.16b
    // 0x862cec: ldur            d0, [fp, #-0x30]
    // 0x862cf0: fadd            d2, d0, d1
    // 0x862cf4: ldur            x1, [fp, #-8]
    // 0x862cf8: stur            d2, [fp, #-0x38]
    // 0x862cfc: r0 = size()
    //     0x862cfc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x862d00: LoadField: d0 = r0->field_7
    //     0x862d00: ldur            d0, [x0, #7]
    // 0x862d04: ldur            d1, [fp, #-0x38]
    // 0x862d08: fmax            v2.2d, v1.2d, v0.2d
    // 0x862d0c: ldur            x1, [fp, #-0x20]
    // 0x862d10: LoadField: d0 = r1->field_7
    //     0x862d10: ldur            d0, [x1, #7]
    // 0x862d14: ldur            x0, [fp, #-8]
    // 0x862d18: LoadField: d1 = r0->field_df
    //     0x862d18: ldur            d1, [x0, #0xdf]
    // 0x862d1c: d3 = 1.000000
    //     0x862d1c: fmov            d3, #1.00000000
    // 0x862d20: fadd            d4, d1, d3
    // 0x862d24: fsub            d1, d2, d4
    // 0x862d28: d2 = 0.000000
    //     0x862d28: eor             v2.16b, v2.16b, v2.16b
    // 0x862d2c: fmax            v3.2d, v1.2d, v2.2d
    // 0x862d30: fcmp            d2, d0
    // 0x862d34: b.le            #0x862d40
    // 0x862d38: d0 = 0.000000
    //     0x862d38: eor             v0.16b, v0.16b, v0.16b
    // 0x862d3c: b               #0x862d5c
    // 0x862d40: fcmp            d0, d3
    // 0x862d44: b.le            #0x862d50
    // 0x862d48: mov             v0.16b, v3.16b
    // 0x862d4c: b               #0x862d5c
    // 0x862d50: fcmp            d0, d0
    // 0x862d54: b.vc            #0x862d5c
    // 0x862d58: mov             v0.16b, v3.16b
    // 0x862d5c: stur            d0, [fp, #-0x38]
    // 0x862d60: LoadField: d1 = r1->field_f
    //     0x862d60: ldur            d1, [x1, #0xf]
    // 0x862d64: stur            d1, [fp, #-0x30]
    // 0x862d68: r0 = Offset()
    //     0x862d68: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x862d6c: ldur            d0, [fp, #-0x38]
    // 0x862d70: stur            x0, [fp, #-0x28]
    // 0x862d74: StoreField: r0->field_7 = d0
    //     0x862d74: stur            d0, [x0, #7]
    // 0x862d78: ldur            d0, [fp, #-0x30]
    // 0x862d7c: StoreField: r0->field_f = d0
    //     0x862d7c: stur            d0, [x0, #0xf]
    // 0x862d80: ldur            x1, [fp, #-0x20]
    // 0x862d84: r0 = size()
    //     0x862d84: bl              #0x8632d0  ; [dart:ui] Rect::size
    // 0x862d88: ldur            x1, [fp, #-0x28]
    // 0x862d8c: mov             x2, x0
    // 0x862d90: r0 = &()
    //     0x862d90: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x862d94: ldur            x1, [fp, #-0x18]
    // 0x862d98: ldur            x2, [fp, #-0x10]
    // 0x862d9c: stur            x0, [fp, #-0x10]
    // 0x862da0: r0 = getFullHeightForCaret()
    //     0x862da0: bl              #0x86309c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getFullHeightForCaret
    // 0x862da4: ldur            x1, [fp, #-8]
    // 0x862da8: stur            d0, [fp, #-0x30]
    // 0x862dac: r0 = preferredLineHeight()
    //     0x862dac: bl              #0x859c2c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::preferredLineHeight
    // 0x862db0: mov             v1.16b, v0.16b
    // 0x862db4: ldur            d0, [fp, #-0x30]
    // 0x862db8: fsub            d2, d0, d1
    // 0x862dbc: ldur            x0, [fp, #-0x10]
    // 0x862dc0: LoadField: d0 = r0->field_7
    //     0x862dc0: ldur            d0, [x0, #7]
    // 0x862dc4: stur            d0, [fp, #-0x48]
    // 0x862dc8: LoadField: d3 = r0->field_f
    //     0x862dc8: ldur            d3, [x0, #0xf]
    // 0x862dcc: d4 = 2.000000
    //     0x862dcc: fmov            d4, #2.00000000
    // 0x862dd0: fsub            d5, d3, d4
    // 0x862dd4: fdiv            d3, d2, d4
    // 0x862dd8: fadd            d2, d5, d3
    // 0x862ddc: stur            d2, [fp, #-0x40]
    // 0x862de0: ArrayLoad: d3 = r0[0]  ; List_8
    //     0x862de0: ldur            d3, [x0, #0x17]
    // 0x862de4: fsub            d4, d3, d0
    // 0x862de8: fadd            d3, d0, d4
    // 0x862dec: stur            d3, [fp, #-0x38]
    // 0x862df0: fadd            d4, d2, d1
    // 0x862df4: stur            d4, [fp, #-0x30]
    // 0x862df8: r0 = Rect()
    //     0x862df8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x862dfc: ldur            d0, [fp, #-0x48]
    // 0x862e00: stur            x0, [fp, #-0x10]
    // 0x862e04: StoreField: r0->field_7 = d0
    //     0x862e04: stur            d0, [x0, #7]
    // 0x862e08: ldur            d0, [fp, #-0x40]
    // 0x862e0c: StoreField: r0->field_f = d0
    //     0x862e0c: stur            d0, [x0, #0xf]
    // 0x862e10: ldur            d0, [fp, #-0x38]
    // 0x862e14: ArrayStore: r0[0] = d0  ; List_8
    //     0x862e14: stur            d0, [x0, #0x17]
    // 0x862e18: ldur            d0, [fp, #-0x30]
    // 0x862e1c: StoreField: r0->field_1f = d0
    //     0x862e1c: stur            d0, [x0, #0x1f]
    // 0x862e20: ldur            x1, [fp, #-8]
    // 0x862e24: r0 = _paintOffset()
    //     0x862e24: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x862e28: ldur            x1, [fp, #-0x10]
    // 0x862e2c: mov             x2, x0
    // 0x862e30: r0 = shift()
    //     0x862e30: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x862e34: stur            x0, [fp, #-0x10]
    // 0x862e38: LoadField: d0 = r0->field_7
    //     0x862e38: ldur            d0, [x0, #7]
    // 0x862e3c: stur            d0, [fp, #-0x38]
    // 0x862e40: LoadField: d1 = r0->field_f
    //     0x862e40: ldur            d1, [x0, #0xf]
    // 0x862e44: stur            d1, [fp, #-0x30]
    // 0x862e48: r0 = Offset()
    //     0x862e48: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x862e4c: ldur            d0, [fp, #-0x38]
    // 0x862e50: StoreField: r0->field_7 = d0
    //     0x862e50: stur            d0, [x0, #7]
    // 0x862e54: ldur            d0, [fp, #-0x30]
    // 0x862e58: StoreField: r0->field_f = d0
    //     0x862e58: stur            d0, [x0, #0xf]
    // 0x862e5c: ldur            x1, [fp, #-8]
    // 0x862e60: mov             x2, x0
    // 0x862e64: r0 = _snapToPhysicalPixel()
    //     0x862e64: bl              #0x862e94  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_snapToPhysicalPixel
    // 0x862e68: ldur            x1, [fp, #-0x10]
    // 0x862e6c: mov             x2, x0
    // 0x862e70: r0 = shift()
    //     0x862e70: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x862e74: LeaveFrame
    //     0x862e74: mov             SP, fp
    //     0x862e78: ldp             fp, lr, [SP], #0x10
    // 0x862e7c: ret
    //     0x862e7c: ret             
    // 0x862e80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862e80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862e84: b               #0x862c54
    // 0x862e88: r9 = _caretPrototype
    //     0x862e88: ldr             x9, [PP, #0x49b0]  ; [pp+0x49b0] Field <RenderEditable._caretPrototype@80245603>: late (offset: 0x130)
    // 0x862e8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862e8c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x862e90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x862e90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _snapToPhysicalPixel(/* No info */) {
    // ** addr: 0x862e94, size: 0x208
    // 0x862e94: EnterFrame
    //     0x862e94: stp             fp, lr, [SP, #-0x10]!
    //     0x862e98: mov             fp, SP
    // 0x862e9c: AllocStack(0x20)
    //     0x862e9c: sub             SP, SP, #0x20
    // 0x862ea0: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0x862ea0: mov             x0, x1
    //     0x862ea4: stur            x1, [fp, #-8]
    // 0x862ea8: CheckStackOverflow
    //     0x862ea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x862eac: cmp             SP, x16
    //     0x862eb0: b.ls            #0x863054
    // 0x862eb4: mov             x1, x0
    // 0x862eb8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x862eb8: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x862ebc: r0 = localToGlobal()
    //     0x862ebc: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x862ec0: mov             x19, x0
    // 0x862ec4: ldur            x0, [fp, #-8]
    // 0x862ec8: LoadField: d0 = r0->field_8b
    //     0x862ec8: ldur            d0, [x0, #0x8b]
    // 0x862ecc: d1 = 1.000000
    //     0x862ecc: fmov            d1, #1.00000000
    // 0x862ed0: fdiv            d2, d1, d0
    // 0x862ed4: stur            d2, [fp, #-0x18]
    // 0x862ed8: LoadField: d1 = r19->field_7
    //     0x862ed8: ldur            d1, [x19, #7]
    // 0x862edc: stur            d1, [fp, #-0x10]
    // 0x862ee0: mov             x0, v1.d[0]
    // 0x862ee4: and             x0, x0, #0x7fffffffffffffff
    // 0x862ee8: r17 = 9218868437227405312
    //     0x862ee8: mov             x17, #0x7ff0000000000000
    // 0x862eec: cmp             x0, x17
    // 0x862ef0: b.eq            #0x862f80
    // 0x862ef4: fcmp            d1, d1
    // 0x862ef8: b.vs            #0x862f78
    // 0x862efc: fdiv            d0, d1, d2
    // 0x862f00: stp             fp, lr, [SP, #-0x10]!
    // 0x862f04: mov             fp, SP
    // 0x862f08: CallRuntime_LibcRound(double) -> double
    //     0x862f08: and             SP, SP, #0xfffffffffffffff0
    //     0x862f0c: mov             sp, SP
    //     0x862f10: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x862f14: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x862f18: blr             x16
    //     0x862f1c: mov             x16, #8
    //     0x862f20: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x862f24: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x862f28: sub             sp, x16, #1, lsl #12
    //     0x862f2c: mov             SP, fp
    //     0x862f30: ldp             fp, lr, [SP], #0x10
    // 0x862f34: fcmp            d0, d0
    // 0x862f38: b.vs            #0x86305c
    // 0x862f3c: fcvtzs          x0, d0
    // 0x862f40: asr             x16, x0, #0x1e
    // 0x862f44: cmp             x16, x0, asr #63
    // 0x862f48: b.ne            #0x86305c
    // 0x862f4c: lsl             x0, x0, #1
    // 0x862f50: r1 = LoadInt32Instr(r0)
    //     0x862f50: sbfx            x1, x0, #1, #0x1f
    //     0x862f54: tbz             w0, #0, #0x862f5c
    //     0x862f58: ldur            x1, [x0, #7]
    // 0x862f5c: scvtf           d0, x1
    // 0x862f60: ldur            d1, [fp, #-0x18]
    // 0x862f64: fmul            d2, d0, d1
    // 0x862f68: ldur            d0, [fp, #-0x10]
    // 0x862f6c: fsub            d3, d2, d0
    // 0x862f70: mov             v2.16b, v3.16b
    // 0x862f74: b               #0x862f88
    // 0x862f78: mov             v1.16b, v2.16b
    // 0x862f7c: b               #0x862f84
    // 0x862f80: mov             v1.16b, v2.16b
    // 0x862f84: d2 = 0.000000
    //     0x862f84: eor             v2.16b, v2.16b, v2.16b
    // 0x862f88: stur            d2, [fp, #-0x20]
    // 0x862f8c: LoadField: d3 = r19->field_f
    //     0x862f8c: ldur            d3, [x19, #0xf]
    // 0x862f90: stur            d3, [fp, #-0x10]
    // 0x862f94: mov             x0, v3.d[0]
    // 0x862f98: and             x0, x0, #0x7fffffffffffffff
    // 0x862f9c: r17 = 9218868437227405312
    //     0x862f9c: mov             x17, #0x7ff0000000000000
    // 0x862fa0: cmp             x0, x17
    // 0x862fa4: b.eq            #0x863028
    // 0x862fa8: fcmp            d3, d3
    // 0x862fac: b.vs            #0x863028
    // 0x862fb0: fdiv            d0, d3, d1
    // 0x862fb4: stp             fp, lr, [SP, #-0x10]!
    // 0x862fb8: mov             fp, SP
    // 0x862fbc: CallRuntime_LibcRound(double) -> double
    //     0x862fbc: and             SP, SP, #0xfffffffffffffff0
    //     0x862fc0: mov             sp, SP
    //     0x862fc4: ldr             x16, [THR, #0x770]  ; THR::LibcRound
    //     0x862fc8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x862fcc: blr             x16
    //     0x862fd0: mov             x16, #8
    //     0x862fd4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0x862fd8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0x862fdc: sub             sp, x16, #1, lsl #12
    //     0x862fe0: mov             SP, fp
    //     0x862fe4: ldp             fp, lr, [SP], #0x10
    // 0x862fe8: fcmp            d0, d0
    // 0x862fec: b.vs            #0x863080
    // 0x862ff0: fcvtzs          x0, d0
    // 0x862ff4: asr             x16, x0, #0x1e
    // 0x862ff8: cmp             x16, x0, asr #63
    // 0x862ffc: b.ne            #0x863080
    // 0x863000: lsl             x0, x0, #1
    // 0x863004: r1 = LoadInt32Instr(r0)
    //     0x863004: sbfx            x1, x0, #1, #0x1f
    //     0x863008: tbz             w0, #0, #0x863010
    //     0x86300c: ldur            x1, [x0, #7]
    // 0x863010: scvtf           d0, x1
    // 0x863014: ldur            d1, [fp, #-0x18]
    // 0x863018: fmul            d2, d0, d1
    // 0x86301c: ldur            d0, [fp, #-0x10]
    // 0x863020: fsub            d1, d2, d0
    // 0x863024: b               #0x86302c
    // 0x863028: d1 = 0.000000
    //     0x863028: eor             v1.16b, v1.16b, v1.16b
    // 0x86302c: ldur            d0, [fp, #-0x20]
    // 0x863030: stur            d1, [fp, #-0x10]
    // 0x863034: r0 = Offset()
    //     0x863034: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x863038: ldur            d0, [fp, #-0x20]
    // 0x86303c: StoreField: r0->field_7 = d0
    //     0x86303c: stur            d0, [x0, #7]
    // 0x863040: ldur            d0, [fp, #-0x10]
    // 0x863044: StoreField: r0->field_f = d0
    //     0x863044: stur            d0, [x0, #0xf]
    // 0x863048: LeaveFrame
    //     0x863048: mov             SP, fp
    //     0x86304c: ldp             fp, lr, [SP], #0x10
    // 0x863050: ret
    //     0x863050: ret             
    // 0x863054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863054: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863058: b               #0x862eb4
    // 0x86305c: SaveReg d0
    //     0x86305c: str             q0, [SP, #-0x10]!
    // 0x863060: SaveReg r19
    //     0x863060: str             x19, [SP, #-8]!
    // 0x863064: r0 = 76
    //     0x863064: mov             x0, #0x4c
    // 0x863068: r30 = DoubleToIntegerStub
    //     0x863068: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0x86306c: LoadField: r30 = r30->field_7
    //     0x86306c: ldur            lr, [lr, #7]
    // 0x863070: blr             lr
    // 0x863074: RestoreReg r19
    //     0x863074: ldr             x19, [SP], #8
    // 0x863078: RestoreReg d0
    //     0x863078: ldr             q0, [SP], #0x10
    // 0x86307c: b               #0x862f50
    // 0x863080: SaveReg d0
    //     0x863080: str             q0, [SP, #-0x10]!
    // 0x863084: r0 = 76
    //     0x863084: mov             x0, #0x4c
    // 0x863088: r30 = DoubleToIntegerStub
    //     0x863088: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0x86308c: LoadField: r30 = r30->field_7
    //     0x86308c: ldur            lr, [lr, #7]
    // 0x863090: blr             lr
    // 0x863094: RestoreReg d0
    //     0x863094: ldr             q0, [SP], #0x10
    // 0x863098: b               #0x863004
  }
  get _ _caretMargin(/* No info */) {
    // ** addr: 0x86331c, size: 0x10
    // 0x86331c: d1 = 1.000000
    //     0x86331c: fmov            d1, #1.00000000
    // 0x863320: LoadField: d2 = r1->field_df
    //     0x863320: ldur            d2, [x1, #0xdf]
    // 0x863324: fadd            d0, d2, d1
    // 0x863328: ret
    //     0x863328: ret             
  }
  get _ cursorOffset(/* No info */) {
    // ** addr: 0x86332c, size: 0x50
    // 0x86332c: EnterFrame
    //     0x86332c: stp             fp, lr, [SP, #-0x10]!
    //     0x863330: mov             fp, SP
    // 0x863334: CheckStackOverflow
    //     0x863334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x863338: cmp             SP, x16
    //     0x86333c: b.ls            #0x863374
    // 0x863340: LoadField: r0 = r1->field_73
    //     0x863340: ldur            w0, [x1, #0x73]
    // 0x863344: DecompressPointer r0
    //     0x863344: add             x0, x0, HEAP, lsl #32
    // 0x863348: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x86334c: cmp             w0, w16
    // 0x863350: b.ne            #0x86335c
    // 0x863354: r2 = _caretPainter
    //     0x863354: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0x863358: r0 = InitLateFinalInstanceField()
    //     0x863358: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x86335c: LoadField: r1 = r0->field_3b
    //     0x86335c: ldur            w1, [x0, #0x3b]
    // 0x863360: DecompressPointer r1
    //     0x863360: add             x1, x1, HEAP, lsl #32
    // 0x863364: mov             x0, x1
    // 0x863368: LeaveFrame
    //     0x863368: mov             SP, fp
    //     0x86336c: ldp             fp, lr, [SP], #0x10
    // 0x863370: ret
    //     0x863370: ret             
    // 0x863374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863374: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863378: b               #0x863340
  }
  _CaretPainter _caretPainter(RenderEditable) {
    // ** addr: 0x86337c, size: 0x40
    // 0x86337c: EnterFrame
    //     0x86337c: stp             fp, lr, [SP, #-0x10]!
    //     0x863380: mov             fp, SP
    // 0x863384: AllocStack(0x8)
    //     0x863384: sub             SP, SP, #8
    // 0x863388: CheckStackOverflow
    //     0x863388: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x86338c: cmp             SP, x16
    //     0x863390: b.ls            #0x8633b4
    // 0x863394: r0 = _CaretPainter()
    //     0x863394: bl              #0x8634c4  ; Allocate_CaretPainterStub -> _CaretPainter (size=0x48)
    // 0x863398: mov             x1, x0
    // 0x86339c: stur            x0, [fp, #-8]
    // 0x8633a0: r0 = _CaretPainter()
    //     0x8633a0: bl              #0x8633bc  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::_CaretPainter
    // 0x8633a4: ldur            x0, [fp, #-8]
    // 0x8633a8: LeaveFrame
    //     0x8633a8: mov             SP, fp
    //     0x8633ac: ldp             fp, lr, [SP], #0x10
    // 0x8633b0: ret
    //     0x8633b0: ret             
    // 0x8633b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8633b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8633b8: b               #0x863394
  }
  _ getBoxesForSelection(/* No info */) {
    // ** addr: 0x8634d0, size: 0x194
    // 0x8634d0: EnterFrame
    //     0x8634d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8634d4: mov             fp, SP
    // 0x8634d8: AllocStack(0x38)
    //     0x8634d8: sub             SP, SP, #0x38
    // 0x8634dc: SetupParameters(RenderEditable this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x8634dc: stur            x1, [fp, #-8]
    //     0x8634e0: stur            x2, [fp, #-0x10]
    // 0x8634e4: CheckStackOverflow
    //     0x8634e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8634e8: cmp             SP, x16
    //     0x8634ec: b.ls            #0x86365c
    // 0x8634f0: r1 = 1
    //     0x8634f0: mov             x1, #1
    // 0x8634f4: r0 = AllocateContext()
    //     0x8634f4: bl              #0x13de838  ; AllocateContextStub
    // 0x8634f8: mov             x2, x0
    // 0x8634fc: ldur            x0, [fp, #-8]
    // 0x863500: stur            x2, [fp, #-0x18]
    // 0x863504: StoreField: r2->field_f = r0
    //     0x863504: stur            w0, [x2, #0xf]
    // 0x863508: mov             x1, x0
    // 0x86350c: r0 = _computeTextMetricsIfNeeded()
    //     0x86350c: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0x863510: ldur            x0, [fp, #-8]
    // 0x863514: LoadField: r2 = r0->field_a7
    //     0x863514: ldur            w2, [x0, #0xa7]
    // 0x863518: DecompressPointer r2
    //     0x863518: add             x2, x2, HEAP, lsl #32
    // 0x86351c: mov             x1, x0
    // 0x863520: stur            x2, [fp, #-0x20]
    // 0x863524: r0 = selectionHeightStyle()
    //     0x863524: bl              #0x863678  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectionHeightStyle
    // 0x863528: ldur            x1, [fp, #-8]
    // 0x86352c: stur            x0, [fp, #-8]
    // 0x863530: r0 = selectionWidthStyle()
    //     0x863530: bl              #0x863664  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectionWidthStyle
    // 0x863534: ldur            x16, [fp, #-8]
    // 0x863538: stp             x0, x16, [SP]
    // 0x86353c: ldur            x1, [fp, #-0x20]
    // 0x863540: ldur            x2, [fp, #-0x10]
    // 0x863544: r4 = const [0, 0x4, 0x2, 0x2, boxHeightStyle, 0x2, boxWidthStyle, 0x3, null]
    //     0x863544: ldr             x4, [PP, #0x4d00]  ; [pp+0x4d00] List(9) [0, 0x4, 0x2, 0x2, "boxHeightStyle", 0x2, "boxWidthStyle", 0x3, Null]
    // 0x863548: r0 = getBoxesForSelection()
    //     0x863548: bl              #0x85fc0c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x86354c: ldur            x2, [fp, #-0x18]
    // 0x863550: r1 = Function '<anonymous closure>':.
    //     0x863550: ldr             x1, [PP, #0x4d08]  ; [pp+0x4d08] AnonymousClosure: (0x86368c), in [package:flutter/src/rendering/editable.dart] RenderEditable::getBoxesForSelection (0x8634d0)
    // 0x863554: stur            x0, [fp, #-8]
    // 0x863558: r0 = AllocateClosure()
    //     0x863558: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x86355c: r16 = <TextBox>
    //     0x86355c: ldr             x16, [PP, #0x4b90]  ; [pp+0x4b90] TypeArguments: <TextBox>
    // 0x863560: ldur            lr, [fp, #-8]
    // 0x863564: stp             lr, x16, [SP, #8]
    // 0x863568: str             x0, [SP]
    // 0x86356c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x86356c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x863570: r0 = map()
    //     0x863570: bl              #0xba574c  ; [dart:collection] ListBase::map
    // 0x863574: mov             x3, x0
    // 0x863578: stur            x3, [fp, #-0x10]
    // 0x86357c: LoadField: r4 = r3->field_7
    //     0x86357c: ldur            w4, [x3, #7]
    // 0x863580: DecompressPointer r4
    //     0x863580: add             x4, x4, HEAP, lsl #32
    // 0x863584: mov             x0, x3
    // 0x863588: stur            x4, [fp, #-8]
    // 0x86358c: r2 = Null
    //     0x86358c: mov             x2, NULL
    // 0x863590: r1 = Null
    //     0x863590: mov             x1, NULL
    // 0x863594: cmp             w0, NULL
    // 0x863598: b.eq            #0x863624
    // 0x86359c: branchIfSmi(r0, 0x863624)
    //     0x86359c: tbz             w0, #0, #0x863624
    // 0x8635a0: r3 = LoadClassIdInstr(r0)
    //     0x8635a0: ldur            x3, [x0, #-1]
    //     0x8635a4: ubfx            x3, x3, #0xc, #0x14
    // 0x8635a8: r17 = 7724
    //     0x8635a8: mov             x17, #0x1e2c
    // 0x8635ac: cmp             x3, x17
    // 0x8635b0: b.eq            #0x86362c
    // 0x8635b4: r4 = LoadClassIdInstr(r0)
    //     0x8635b4: ldur            x4, [x0, #-1]
    //     0x8635b8: ubfx            x4, x4, #0xc, #0x14
    // 0x8635bc: ldr             x3, [THR, #0x688]  ; THR::isolate_group
    // 0x8635c0: ldr             x3, [x3, #0x18]
    // 0x8635c4: ldr             x3, [x3, x4, lsl #3]
    // 0x8635c8: LoadField: r3 = r3->field_2b
    //     0x8635c8: ldur            w3, [x3, #0x2b]
    // 0x8635cc: DecompressPointer r3
    //     0x8635cc: add             x3, x3, HEAP, lsl #32
    // 0x8635d0: cmp             w3, NULL
    // 0x8635d4: b.eq            #0x863624
    // 0x8635d8: LoadField: r3 = r3->field_f
    //     0x8635d8: ldur            w3, [x3, #0xf]
    // 0x8635dc: lsr             x3, x3, #3
    // 0x8635e0: r17 = 7724
    //     0x8635e0: mov             x17, #0x1e2c
    // 0x8635e4: cmp             x3, x17
    // 0x8635e8: b.eq            #0x86362c
    // 0x8635ec: r3 = SubtypeTestCache
    //     0x8635ec: ldr             x3, [PP, #0x4d10]  ; [pp+0x4d10] SubtypeTestCache
    // 0x8635f0: r30 = Subtype1TestCacheStub
    //     0x8635f0: ldr             lr, [PP, #0x350]  ; [pp+0x350] Stub: Subtype1TestCache (0x7d2fcc)
    // 0x8635f4: LoadField: r30 = r30->field_7
    //     0x8635f4: ldur            lr, [lr, #7]
    // 0x8635f8: blr             lr
    // 0x8635fc: cmp             w7, NULL
    // 0x863600: b.eq            #0x86360c
    // 0x863604: tbnz            w7, #4, #0x863624
    // 0x863608: b               #0x86362c
    // 0x86360c: r8 = EfficientLengthIterable
    //     0x86360c: ldr             x8, [PP, #0x4d18]  ; [pp+0x4d18] Type: EfficientLengthIterable
    // 0x863610: r3 = SubtypeTestCache
    //     0x863610: ldr             x3, [PP, #0x4d20]  ; [pp+0x4d20] SubtypeTestCache
    // 0x863614: r30 = InstanceOfStub
    //     0x863614: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0x863618: LoadField: r30 = r30->field_7
    //     0x863618: ldur            lr, [lr, #7]
    // 0x86361c: blr             lr
    // 0x863620: b               #0x863630
    // 0x863624: r0 = false
    //     0x863624: add             x0, NULL, #0x30  ; false
    // 0x863628: b               #0x863630
    // 0x86362c: r0 = true
    //     0x86362c: add             x0, NULL, #0x20  ; true
    // 0x863630: tbnz            w0, #4, #0x863644
    // 0x863634: ldur            x1, [fp, #-8]
    // 0x863638: ldur            x2, [fp, #-0x10]
    // 0x86363c: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x86363c: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x863640: b               #0x863650
    // 0x863644: ldur            x1, [fp, #-8]
    // 0x863648: ldur            x2, [fp, #-0x10]
    // 0x86364c: r0 = _GrowableList._ofOther()
    //     0x86364c: bl              #0x7d94b4  ; [dart:core] _GrowableList::_GrowableList._ofOther
    // 0x863650: LeaveFrame
    //     0x863650: mov             SP, fp
    //     0x863654: ldp             fp, lr, [SP], #0x10
    // 0x863658: ret
    //     0x863658: ret             
    // 0x86365c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86365c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863660: b               #0x8634f0
  }
  get _ selectionWidthStyle(/* No info */) {
    // ** addr: 0x863664, size: 0x14
    // 0x863664: LoadField: r2 = r1->field_77
    //     0x863664: ldur            w2, [x1, #0x77]
    // 0x863668: DecompressPointer r2
    //     0x863668: add             x2, x2, HEAP, lsl #32
    // 0x86366c: LoadField: r0 = r2->field_33
    //     0x86366c: ldur            w0, [x2, #0x33]
    // 0x863670: DecompressPointer r0
    //     0x863670: add             x0, x0, HEAP, lsl #32
    // 0x863674: ret
    //     0x863674: ret             
  }
  get _ selectionHeightStyle(/* No info */) {
    // ** addr: 0x863678, size: 0x14
    // 0x863678: LoadField: r2 = r1->field_77
    //     0x863678: ldur            w2, [x1, #0x77]
    // 0x86367c: DecompressPointer r2
    //     0x86367c: add             x2, x2, HEAP, lsl #32
    // 0x863680: LoadField: r0 = r2->field_2f
    //     0x863680: ldur            w0, [x2, #0x2f]
    // 0x863684: DecompressPointer r0
    //     0x863684: add             x0, x0, HEAP, lsl #32
    // 0x863688: ret
    //     0x863688: ret             
  }
  [closure] TextBox <anonymous closure>(dynamic, TextBox) {
    // ** addr: 0x86368c, size: 0x128
    // 0x86368c: EnterFrame
    //     0x86368c: stp             fp, lr, [SP, #-0x10]!
    //     0x863690: mov             fp, SP
    // 0x863694: AllocStack(0x30)
    //     0x863694: sub             SP, SP, #0x30
    // 0x863698: SetupParameters([dynamic _ /* r0 */])
    //     0x863698: ldr             x0, [fp, #0x18]
    //     0x86369c: ldur            w2, [x0, #0x17]
    //     0x8636a0: add             x2, x2, HEAP, lsl #32
    //     0x8636a4: stur            x2, [fp, #-8]
    // 0x8636a8: CheckStackOverflow
    //     0x8636a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8636ac: cmp             SP, x16
    //     0x8636b0: b.ls            #0x8637ac
    // 0x8636b4: ldr             x0, [fp, #0x10]
    // 0x8636b8: LoadField: d0 = r0->field_7
    //     0x8636b8: ldur            d0, [x0, #7]
    // 0x8636bc: stur            d0, [fp, #-0x10]
    // 0x8636c0: LoadField: r1 = r2->field_f
    //     0x8636c0: ldur            w1, [x2, #0xf]
    // 0x8636c4: DecompressPointer r1
    //     0x8636c4: add             x1, x1, HEAP, lsl #32
    // 0x8636c8: r0 = _paintOffset()
    //     0x8636c8: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x8636cc: LoadField: d0 = r0->field_7
    //     0x8636cc: ldur            d0, [x0, #7]
    // 0x8636d0: ldur            d1, [fp, #-0x10]
    // 0x8636d4: fadd            d2, d1, d0
    // 0x8636d8: ldr             x0, [fp, #0x10]
    // 0x8636dc: stur            d2, [fp, #-0x18]
    // 0x8636e0: LoadField: d0 = r0->field_f
    //     0x8636e0: ldur            d0, [x0, #0xf]
    // 0x8636e4: ldur            x2, [fp, #-8]
    // 0x8636e8: stur            d0, [fp, #-0x10]
    // 0x8636ec: LoadField: r1 = r2->field_f
    //     0x8636ec: ldur            w1, [x2, #0xf]
    // 0x8636f0: DecompressPointer r1
    //     0x8636f0: add             x1, x1, HEAP, lsl #32
    // 0x8636f4: r0 = _paintOffset()
    //     0x8636f4: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x8636f8: LoadField: d0 = r0->field_f
    //     0x8636f8: ldur            d0, [x0, #0xf]
    // 0x8636fc: ldur            d1, [fp, #-0x10]
    // 0x863700: fadd            d2, d1, d0
    // 0x863704: ldr             x0, [fp, #0x10]
    // 0x863708: stur            d2, [fp, #-0x20]
    // 0x86370c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x86370c: ldur            d0, [x0, #0x17]
    // 0x863710: ldur            x2, [fp, #-8]
    // 0x863714: stur            d0, [fp, #-0x10]
    // 0x863718: LoadField: r1 = r2->field_f
    //     0x863718: ldur            w1, [x2, #0xf]
    // 0x86371c: DecompressPointer r1
    //     0x86371c: add             x1, x1, HEAP, lsl #32
    // 0x863720: r0 = _paintOffset()
    //     0x863720: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x863724: LoadField: d0 = r0->field_7
    //     0x863724: ldur            d0, [x0, #7]
    // 0x863728: ldur            d1, [fp, #-0x10]
    // 0x86372c: fadd            d2, d1, d0
    // 0x863730: ldr             x0, [fp, #0x10]
    // 0x863734: stur            d2, [fp, #-0x28]
    // 0x863738: LoadField: d0 = r0->field_1f
    //     0x863738: ldur            d0, [x0, #0x1f]
    // 0x86373c: ldur            x1, [fp, #-8]
    // 0x863740: stur            d0, [fp, #-0x10]
    // 0x863744: LoadField: r2 = r1->field_f
    //     0x863744: ldur            w2, [x1, #0xf]
    // 0x863748: DecompressPointer r2
    //     0x863748: add             x2, x2, HEAP, lsl #32
    // 0x86374c: mov             x1, x2
    // 0x863750: r0 = _paintOffset()
    //     0x863750: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x863754: LoadField: d0 = r0->field_f
    //     0x863754: ldur            d0, [x0, #0xf]
    // 0x863758: ldur            d1, [fp, #-0x10]
    // 0x86375c: fadd            d2, d1, d0
    // 0x863760: ldr             x0, [fp, #0x10]
    // 0x863764: stur            d2, [fp, #-0x30]
    // 0x863768: LoadField: r1 = r0->field_27
    //     0x863768: ldur            w1, [x0, #0x27]
    // 0x86376c: DecompressPointer r1
    //     0x86376c: add             x1, x1, HEAP, lsl #32
    // 0x863770: stur            x1, [fp, #-8]
    // 0x863774: r0 = TextBox()
    //     0x863774: bl              #0x85eb2c  ; AllocateTextBoxStub -> TextBox (size=0x2c)
    // 0x863778: ldur            d0, [fp, #-0x18]
    // 0x86377c: StoreField: r0->field_7 = d0
    //     0x86377c: stur            d0, [x0, #7]
    // 0x863780: ldur            d0, [fp, #-0x20]
    // 0x863784: StoreField: r0->field_f = d0
    //     0x863784: stur            d0, [x0, #0xf]
    // 0x863788: ldur            d0, [fp, #-0x28]
    // 0x86378c: ArrayStore: r0[0] = d0  ; List_8
    //     0x86378c: stur            d0, [x0, #0x17]
    // 0x863790: ldur            d0, [fp, #-0x30]
    // 0x863794: StoreField: r0->field_1f = d0
    //     0x863794: stur            d0, [x0, #0x1f]
    // 0x863798: ldur            x1, [fp, #-8]
    // 0x86379c: StoreField: r0->field_27 = r1
    //     0x86379c: stur            w1, [x0, #0x27]
    // 0x8637a0: LeaveFrame
    //     0x8637a0: mov             SP, fp
    //     0x8637a4: ldp             fp, lr, [SP], #0x10
    // 0x8637a8: ret
    //     0x8637a8: ret             
    // 0x8637ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8637ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8637b0: b               #0x8636b4
  }
  _ getPositionForPoint(/* No info */) {
    // ** addr: 0x86741c, size: 0x80
    // 0x86741c: EnterFrame
    //     0x86741c: stp             fp, lr, [SP, #-0x10]!
    //     0x867420: mov             fp, SP
    // 0x867424: AllocStack(0x18)
    //     0x867424: sub             SP, SP, #0x18
    // 0x867428: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x867428: mov             x0, x1
    //     0x86742c: stur            x1, [fp, #-8]
    //     0x867430: stur            x2, [fp, #-0x10]
    // 0x867434: CheckStackOverflow
    //     0x867434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x867438: cmp             SP, x16
    //     0x86743c: b.ls            #0x867494
    // 0x867440: mov             x1, x0
    // 0x867444: r0 = _computeTextMetricsIfNeeded()
    //     0x867444: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0x867448: ldur            x0, [fp, #-8]
    // 0x86744c: LoadField: r3 = r0->field_a7
    //     0x86744c: ldur            w3, [x0, #0xa7]
    // 0x867450: DecompressPointer r3
    //     0x867450: add             x3, x3, HEAP, lsl #32
    // 0x867454: mov             x1, x0
    // 0x867458: ldur            x2, [fp, #-0x10]
    // 0x86745c: stur            x3, [fp, #-0x18]
    // 0x867460: r0 = globalToLocal()
    //     0x867460: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x867464: ldur            x1, [fp, #-8]
    // 0x867468: stur            x0, [fp, #-8]
    // 0x86746c: r0 = _paintOffset()
    //     0x86746c: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x867470: ldur            x1, [fp, #-8]
    // 0x867474: mov             x2, x0
    // 0x867478: r0 = -()
    //     0x867478: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x86747c: ldur            x1, [fp, #-0x18]
    // 0x867480: mov             x2, x0
    // 0x867484: r0 = getPositionForOffset()
    //     0x867484: bl              #0x86749c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x867488: LeaveFrame
    //     0x867488: mov             SP, fp
    //     0x86748c: ldp             fp, lr, [SP], #0x10
    // 0x867490: ret
    //     0x867490: ret             
    // 0x867494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x867494: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x867498: b               #0x867440
  }
  _ setFloatingCursor(/* No info */) {
    // ** addr: 0x868308, size: 0x218
    // 0x868308: EnterFrame
    //     0x868308: stp             fp, lr, [SP, #-0x10]!
    //     0x86830c: mov             fp, SP
    // 0x868310: AllocStack(0x20)
    //     0x868310: sub             SP, SP, #0x20
    // 0x868314: SetupParameters(RenderEditable this /* r1 => r5, fp-0x10 */, dynamic _ /* r5 => r1 */)
    //     0x868314: stur            x1, [fp, #-8]
    //     0x868318: mov             x16, x5
    //     0x86831c: mov             x5, x1
    //     0x868320: mov             x1, x16
    //     0x868324: stur            x3, [fp, #-0x10]
    // 0x868328: LoadField: r0 = r4->field_13
    //     0x868328: ldur            w0, [x4, #0x13]
    // 0x86832c: LoadField: r6 = r4->field_1f
    //     0x86832c: ldur            w6, [x4, #0x1f]
    // 0x868330: DecompressPointer r6
    //     0x868330: add             x6, x6, HEAP, lsl #32
    // 0x868334: r16 = "resetLerpValue"
    //     0x868334: ldr             x16, [PP, #0x5298]  ; [pp+0x5298] "resetLerpValue"
    // 0x868338: cmp             w6, w16
    // 0x86833c: b.ne            #0x86835c
    // 0x868340: LoadField: r6 = r4->field_23
    //     0x868340: ldur            w6, [x4, #0x23]
    // 0x868344: DecompressPointer r6
    //     0x868344: add             x6, x6, HEAP, lsl #32
    // 0x868348: sub             w4, w0, w6
    // 0x86834c: add             x0, fp, w4, sxtw #2
    // 0x868350: ldr             x0, [x0, #8]
    // 0x868354: mov             x4, x0
    // 0x868358: b               #0x868360
    // 0x86835c: r4 = Null
    //     0x86835c: mov             x4, NULL
    // 0x868360: CheckStackOverflow
    //     0x868360: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x868364: cmp             SP, x16
    //     0x868368: b.ls            #0x868510
    // 0x86836c: r16 = Instance_FloatingCursorDragState
    //     0x86836c: ldr             x16, [PP, #0x52a0]  ; [pp+0x52a0] Obj!FloatingCursorDragState@12c3761
    // 0x868370: cmp             w2, w16
    // 0x868374: b.ne            #0x8683b4
    // 0x868378: r7 = true
    //     0x868378: add             x7, NULL, #0x20  ; true
    // 0x86837c: r6 = Instance_Offset
    //     0x86837c: ldr             x6, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x868380: r0 = false
    //     0x868380: add             x0, NULL, #0x30  ; false
    // 0x868384: r17 = 307
    //     0x868384: mov             x17, #0x133
    // 0x868388: str             w6, [x5, x17]
    // 0x86838c: r17 = 311
    //     0x86838c: mov             x17, #0x137
    // 0x868390: str             NULL, [x5, x17]
    // 0x868394: r17 = 315
    //     0x868394: mov             x17, #0x13b
    // 0x868398: str             w7, [x5, x17]
    // 0x86839c: r17 = 331
    //     0x86839c: mov             x17, #0x14b
    // 0x8683a0: str             w0, [x5, x17]
    // 0x8683a4: r17 = 327
    //     0x8683a4: mov             x17, #0x147
    // 0x8683a8: str             w0, [x5, x17]
    // 0x8683ac: r17 = 323
    //     0x8683ac: mov             x17, #0x143
    // 0x8683b0: str             w0, [x5, x17]
    // 0x8683b4: r16 = Instance_FloatingCursorDragState
    //     0x8683b4: ldr             x16, [PP, #0x52a0]  ; [pp+0x52a0] Obj!FloatingCursorDragState@12c3761
    // 0x8683b8: cmp             w2, w16
    // 0x8683bc: r16 = true
    //     0x8683bc: add             x16, NULL, #0x20  ; true
    // 0x8683c0: r17 = false
    //     0x8683c0: add             x17, NULL, #0x30  ; false
    // 0x8683c4: csel            x6, x16, x17, ne
    // 0x8683c8: StoreField: r5->field_fb = r6
    //     0x8683c8: stur            w6, [x5, #0xfb]
    // 0x8683cc: mov             x0, x4
    // 0x8683d0: r17 = 335
    //     0x8683d0: mov             x17, #0x14f
    // 0x8683d4: str             w0, [x5, x17]
    // 0x8683d8: WriteBarrierInstr(obj = r5, val = r0)
    //     0x8683d8: ldurb           w16, [x5, #-1]
    //     0x8683dc: ldurb           w17, [x0, #-1]
    //     0x8683e0: and             x16, x17, x16, lsr #2
    //     0x8683e4: tst             x16, HEAP, lsr #32
    //     0x8683e8: b.eq            #0x8683f0
    //     0x8683ec: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x8683f0: tbnz            w6, #4, #0x8684a8
    // 0x8683f4: mov             x0, x1
    // 0x8683f8: StoreField: r5->field_ff = r0
    //     0x8683f8: stur            w0, [x5, #0xff]
    //     0x8683fc: ldurb           w16, [x5, #-1]
    //     0x868400: ldurb           w17, [x0, #-1]
    //     0x868404: and             x16, x17, x16, lsr #2
    //     0x868408: tst             x16, HEAP, lsr #32
    //     0x86840c: b.eq            #0x868414
    //     0x868410: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0x868414: cmp             w4, NULL
    // 0x868418: b.eq            #0x868434
    // 0x86841c: LoadField: d0 = r4->field_7
    //     0x86841c: ldur            d0, [x4, #7]
    // 0x868420: r1 = Instance_EdgeInsets
    //     0x868420: ldr             x1, [PP, #0x52a8]  ; [pp+0x52a8] Obj!EdgeInsets@129cc01
    // 0x868424: r2 = Instance_EdgeInsets
    //     0x868424: ldr             x2, [PP, #0x52b0]  ; [pp+0x52b0] Obj!EdgeInsets@129cbd1
    // 0x868428: r0 = lerp()
    //     0x868428: bl              #0x868640  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::lerp
    // 0x86842c: mov             x2, x0
    // 0x868430: b               #0x868438
    // 0x868434: r2 = Instance_EdgeInsets
    //     0x868434: ldr             x2, [PP, #0x52a8]  ; [pp+0x52a8] Obj!EdgeInsets@129cc01
    // 0x868438: ldur            x0, [fp, #-8]
    // 0x86843c: mov             x1, x0
    // 0x868440: stur            x2, [fp, #-0x18]
    // 0x868444: LoadField: r0 = r1->field_73
    //     0x868444: ldur            w0, [x1, #0x73]
    // 0x868448: DecompressPointer r0
    //     0x868448: add             x0, x0, HEAP, lsl #32
    // 0x86844c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x868450: cmp             w0, w16
    // 0x868454: b.ne            #0x868460
    // 0x868458: r2 = _caretPainter
    //     0x868458: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0x86845c: r0 = InitLateFinalInstanceField()
    //     0x86845c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x868460: mov             x3, x0
    // 0x868464: ldur            x0, [fp, #-8]
    // 0x868468: stur            x3, [fp, #-0x20]
    // 0x86846c: r17 = 303
    //     0x86846c: mov             x17, #0x12f
    // 0x868470: ldr             w2, [x0, x17]
    // 0x868474: DecompressPointer r2
    //     0x868474: add             x2, x2, HEAP, lsl #32
    // 0x868478: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x86847c: cmp             w2, w16
    // 0x868480: b.eq            #0x868518
    // 0x868484: ldur            x1, [fp, #-0x18]
    // 0x868488: r0 = inflateRect()
    //     0x868488: bl              #0x8685c4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::inflateRect
    // 0x86848c: mov             x1, x0
    // 0x868490: ldur            x2, [fp, #-0x10]
    // 0x868494: r0 = shift()
    //     0x868494: bl              #0x8610a4  ; [dart:ui] Rect::shift
    // 0x868498: ldur            x1, [fp, #-0x20]
    // 0x86849c: mov             x2, x0
    // 0x8684a0: r0 = floatingCursorRect=()
    //     0x8684a0: bl              #0x868520  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::floatingCursorRect=
    // 0x8684a4: b               #0x8684d4
    // 0x8684a8: ldur            x1, [fp, #-8]
    // 0x8684ac: LoadField: r0 = r1->field_73
    //     0x8684ac: ldur            w0, [x1, #0x73]
    // 0x8684b0: DecompressPointer r0
    //     0x8684b0: add             x0, x0, HEAP, lsl #32
    // 0x8684b4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x8684b8: cmp             w0, w16
    // 0x8684bc: b.ne            #0x8684c8
    // 0x8684c0: r2 = _caretPainter
    //     0x8684c0: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0x8684c4: r0 = InitLateFinalInstanceField()
    //     0x8684c4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x8684c8: mov             x1, x0
    // 0x8684cc: r2 = Null
    //     0x8684cc: mov             x2, NULL
    // 0x8684d0: r0 = floatingCursorRect=()
    //     0x8684d0: bl              #0x868520  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::floatingCursorRect=
    // 0x8684d4: ldur            x1, [fp, #-8]
    // 0x8684d8: LoadField: r2 = r1->field_73
    //     0x8684d8: ldur            w2, [x1, #0x73]
    // 0x8684dc: DecompressPointer r2
    //     0x8684dc: add             x2, x2, HEAP, lsl #32
    // 0x8684e0: r17 = 335
    //     0x8684e0: mov             x17, #0x14f
    // 0x8684e4: ldr             w3, [x1, x17]
    // 0x8684e8: DecompressPointer r3
    //     0x8684e8: add             x3, x3, HEAP, lsl #32
    // 0x8684ec: cmp             w3, NULL
    // 0x8684f0: r16 = true
    //     0x8684f0: add             x16, NULL, #0x20  ; true
    // 0x8684f4: r17 = false
    //     0x8684f4: add             x17, NULL, #0x30  ; false
    // 0x8684f8: csel            x1, x16, x17, eq
    // 0x8684fc: StoreField: r2->field_27 = r1
    //     0x8684fc: stur            w1, [x2, #0x27]
    // 0x868500: r0 = Null
    //     0x868500: mov             x0, NULL
    // 0x868504: LeaveFrame
    //     0x868504: mov             SP, fp
    //     0x868508: ldp             fp, lr, [SP], #0x10
    // 0x86850c: ret
    //     0x86850c: ret             
    // 0x868510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x868510: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x868514: b               #0x86836c
    // 0x868518: r9 = _caretPrototype
    //     0x868518: ldr             x9, [PP, #0x49b0]  ; [pp+0x49b0] Field <RenderEditable._caretPrototype@80245603>: late (offset: 0x130)
    // 0x86851c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86851c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ calculateBoundedFloatingCursorOffset(/* No info */) {
    // ** addr: 0x868d00, size: 0x538
    // 0x868d00: EnterFrame
    //     0x868d00: stp             fp, lr, [SP, #-0x10]!
    //     0x868d04: mov             fp, SP
    // 0x868d08: AllocStack(0x40)
    //     0x868d08: sub             SP, SP, #0x40
    // 0x868d0c: SetupParameters(RenderEditable this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */, {dynamic shouldResetOrigin = Null /* r3, fp-0x8 */})
    //     0x868d0c: mov             x0, x2
    //     0x868d10: stur            x2, [fp, #-0x18]
    //     0x868d14: mov             x2, x1
    //     0x868d18: stur            x1, [fp, #-0x10]
    //     0x868d1c: ldur            w1, [x4, #0x13]
    //     0x868d20: ldur            w3, [x4, #0x1f]
    //     0x868d24: add             x3, x3, HEAP, lsl #32
    //     0x868d28: ldr             x16, [PP, #0x52b8]  ; [pp+0x52b8] "shouldResetOrigin"
    //     0x868d2c: cmp             w3, w16
    //     0x868d30: b.ne            #0x868d50
    //     0x868d34: ldur            w3, [x4, #0x23]
    //     0x868d38: add             x3, x3, HEAP, lsl #32
    //     0x868d3c: sub             w4, w1, w3
    //     0x868d40: add             x1, fp, w4, sxtw #2
    //     0x868d44: ldr             x1, [x1, #8]
    //     0x868d48: mov             x3, x1
    //     0x868d4c: b               #0x868d54
    //     0x868d50: mov             x3, NULL
    //     0x868d54: stur            x3, [fp, #-8]
    // 0x868d58: CheckStackOverflow
    //     0x868d58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x868d5c: cmp             SP, x16
    //     0x868d60: b.ls            #0x86922c
    // 0x868d64: mov             x1, x2
    // 0x868d68: r0 = size()
    //     0x868d68: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x868d6c: LoadField: d0 = r0->field_f
    //     0x868d6c: ldur            d0, [x0, #0xf]
    // 0x868d70: ldur            x0, [fp, #-0x10]
    // 0x868d74: stur            d0, [fp, #-0x28]
    // 0x868d78: LoadField: r2 = r0->field_a7
    //     0x868d78: ldur            w2, [x0, #0xa7]
    // 0x868d7c: DecompressPointer r2
    //     0x868d7c: add             x2, x2, HEAP, lsl #32
    // 0x868d80: mov             x1, x2
    // 0x868d84: stur            x2, [fp, #-0x20]
    // 0x868d88: r0 = height()
    //     0x868d88: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0x868d8c: mov             v1.16b, v0.16b
    // 0x868d90: ldur            d0, [fp, #-0x28]
    // 0x868d94: fmin            v2.2d, v0.2d, v1.2d
    // 0x868d98: ldur            x1, [fp, #-0x20]
    // 0x868d9c: stur            d2, [fp, #-0x30]
    // 0x868da0: r0 = preferredLineHeight()
    //     0x868da0: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x868da4: mov             v1.16b, v0.16b
    // 0x868da8: ldur            d0, [fp, #-0x30]
    // 0x868dac: fsub            d2, d0, d1
    // 0x868db0: r0 = Instance_EdgeInsets
    //     0x868db0: ldr             x0, [PP, #0x52c0]  ; [pp+0x52c0] Obj!EdgeInsets@129cc31
    // 0x868db4: LoadField: d0 = r0->field_1f
    //     0x868db4: ldur            d0, [x0, #0x1f]
    // 0x868db8: fadd            d1, d2, d0
    // 0x868dbc: ldur            x1, [fp, #-0x10]
    // 0x868dc0: stur            d1, [fp, #-0x28]
    // 0x868dc4: r0 = size()
    //     0x868dc4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x868dc8: LoadField: d0 = r0->field_7
    //     0x868dc8: ldur            d0, [x0, #7]
    // 0x868dcc: ldur            x0, [fp, #-0x20]
    // 0x868dd0: LoadField: r1 = r0->field_7
    //     0x868dd0: ldur            w1, [x0, #7]
    // 0x868dd4: DecompressPointer r1
    //     0x868dd4: add             x1, x1, HEAP, lsl #32
    // 0x868dd8: cmp             w1, NULL
    // 0x868ddc: b.eq            #0x869234
    // 0x868de0: LoadField: d1 = r1->field_13
    //     0x868de0: ldur            d1, [x1, #0x13]
    // 0x868de4: fmin            v2.2d, v0.2d, v1.2d
    // 0x868de8: r0 = Instance_EdgeInsets
    //     0x868de8: ldr             x0, [PP, #0x52c0]  ; [pp+0x52c0] Obj!EdgeInsets@129cc31
    // 0x868dec: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x868dec: ldur            d0, [x0, #0x17]
    // 0x868df0: fadd            d1, d2, d0
    // 0x868df4: stur            d1, [fp, #-0x30]
    // 0x868df8: r0 = Rect()
    //     0x868df8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x868dfc: d0 = -4.000000
    //     0x868dfc: fmov            d0, #-4.00000000
    // 0x868e00: stur            x0, [fp, #-0x20]
    // 0x868e04: StoreField: r0->field_7 = d0
    //     0x868e04: stur            d0, [x0, #7]
    // 0x868e08: StoreField: r0->field_f = d0
    //     0x868e08: stur            d0, [x0, #0xf]
    // 0x868e0c: ldur            d1, [fp, #-0x30]
    // 0x868e10: ArrayStore: r0[0] = d1  ; List_8
    //     0x868e10: stur            d1, [x0, #0x17]
    // 0x868e14: ldur            d2, [fp, #-0x28]
    // 0x868e18: StoreField: r0->field_1f = d2
    //     0x868e18: stur            d2, [x0, #0x1f]
    // 0x868e1c: ldur            x1, [fp, #-8]
    // 0x868e20: cmp             w1, NULL
    // 0x868e24: b.eq            #0x868e38
    // 0x868e28: ldur            x3, [fp, #-0x10]
    // 0x868e2c: r17 = 315
    //     0x868e2c: mov             x17, #0x13b
    // 0x868e30: str             w1, [x3, x17]
    // 0x868e34: b               #0x868e3c
    // 0x868e38: ldur            x3, [fp, #-0x10]
    // 0x868e3c: r17 = 315
    //     0x868e3c: mov             x17, #0x13b
    // 0x868e40: ldr             w1, [x3, x17]
    // 0x868e44: DecompressPointer r1
    //     0x868e44: add             x1, x1, HEAP, lsl #32
    // 0x868e48: tbz             w1, #4, #0x868e64
    // 0x868e4c: ldur            x1, [fp, #-0x18]
    // 0x868e50: mov             x2, x0
    // 0x868e54: r0 = _calculateAdjustedCursorOffset()
    //     0x868e54: bl              #0x869238  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_calculateAdjustedCursorOffset
    // 0x868e58: LeaveFrame
    //     0x868e58: mov             SP, fp
    //     0x868e5c: ldp             fp, lr, [SP], #0x10
    // 0x868e60: ret
    //     0x868e60: ret             
    // 0x868e64: r17 = 311
    //     0x868e64: mov             x17, #0x137
    // 0x868e68: ldr             w2, [x3, x17]
    // 0x868e6c: DecompressPointer r2
    //     0x868e6c: add             x2, x2, HEAP, lsl #32
    // 0x868e70: cmp             w2, NULL
    // 0x868e74: b.eq            #0x868e88
    // 0x868e78: ldur            x1, [fp, #-0x18]
    // 0x868e7c: r0 = -()
    //     0x868e7c: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x868e80: mov             x1, x0
    // 0x868e84: b               #0x868e8c
    // 0x868e88: r1 = Instance_Offset
    //     0x868e88: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x868e8c: ldur            x0, [fp, #-0x10]
    // 0x868e90: stur            x1, [fp, #-8]
    // 0x868e94: r17 = 319
    //     0x868e94: mov             x17, #0x13f
    // 0x868e98: ldr             w2, [x0, x17]
    // 0x868e9c: DecompressPointer r2
    //     0x868e9c: add             x2, x2, HEAP, lsl #32
    // 0x868ea0: tbnz            w2, #4, #0x868f30
    // 0x868ea4: d0 = 0.000000
    //     0x868ea4: eor             v0.16b, v0.16b, v0.16b
    // 0x868ea8: LoadField: d1 = r1->field_7
    //     0x868ea8: ldur            d1, [x1, #7]
    // 0x868eac: fcmp            d1, d0
    // 0x868eb0: b.le            #0x868f24
    // 0x868eb4: ldur            x2, [fp, #-0x18]
    // 0x868eb8: d1 = -4.000000
    //     0x868eb8: fmov            d1, #-4.00000000
    // 0x868ebc: LoadField: d2 = r2->field_7
    //     0x868ebc: ldur            d2, [x2, #7]
    // 0x868ec0: fsub            d3, d2, d1
    // 0x868ec4: stur            d3, [fp, #-0x40]
    // 0x868ec8: r17 = 307
    //     0x868ec8: mov             x17, #0x133
    // 0x868ecc: ldr             w3, [x0, x17]
    // 0x868ed0: DecompressPointer r3
    //     0x868ed0: add             x3, x3, HEAP, lsl #32
    // 0x868ed4: LoadField: d2 = r3->field_f
    //     0x868ed4: ldur            d2, [x3, #0xf]
    // 0x868ed8: stur            d2, [fp, #-0x38]
    // 0x868edc: r0 = Offset()
    //     0x868edc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x868ee0: ldur            d0, [fp, #-0x40]
    // 0x868ee4: StoreField: r0->field_7 = d0
    //     0x868ee4: stur            d0, [x0, #7]
    // 0x868ee8: ldur            d0, [fp, #-0x38]
    // 0x868eec: StoreField: r0->field_f = d0
    //     0x868eec: stur            d0, [x0, #0xf]
    // 0x868ef0: ldur            x1, [fp, #-0x10]
    // 0x868ef4: r17 = 307
    //     0x868ef4: mov             x17, #0x133
    // 0x868ef8: str             w0, [x1, x17]
    // 0x868efc: WriteBarrierInstr(obj = r1, val = r0)
    //     0x868efc: ldurb           w16, [x1, #-1]
    //     0x868f00: ldurb           w17, [x0, #-1]
    //     0x868f04: and             x16, x17, x16, lsr #2
    //     0x868f08: tst             x16, HEAP, lsr #32
    //     0x868f0c: b.eq            #0x868f14
    //     0x868f10: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x868f14: r0 = false
    //     0x868f14: add             x0, NULL, #0x30  ; false
    // 0x868f18: r17 = 319
    //     0x868f18: mov             x17, #0x13f
    // 0x868f1c: str             w0, [x1, x17]
    // 0x868f20: b               #0x868fc8
    // 0x868f24: mov             x1, x0
    // 0x868f28: r0 = false
    //     0x868f28: add             x0, NULL, #0x30  ; false
    // 0x868f2c: b               #0x868f38
    // 0x868f30: mov             x1, x0
    // 0x868f34: r0 = false
    //     0x868f34: add             x0, NULL, #0x30  ; false
    // 0x868f38: r17 = 323
    //     0x868f38: mov             x17, #0x143
    // 0x868f3c: ldr             w2, [x1, x17]
    // 0x868f40: DecompressPointer r2
    //     0x868f40: add             x2, x2, HEAP, lsl #32
    // 0x868f44: tbnz            w2, #4, #0x868fc8
    // 0x868f48: ldur            x2, [fp, #-8]
    // 0x868f4c: d0 = 0.000000
    //     0x868f4c: eor             v0.16b, v0.16b, v0.16b
    // 0x868f50: LoadField: d1 = r2->field_7
    //     0x868f50: ldur            d1, [x2, #7]
    // 0x868f54: fcmp            d0, d1
    // 0x868f58: b.le            #0x868fc8
    // 0x868f5c: ldur            x3, [fp, #-0x18]
    // 0x868f60: ldur            d1, [fp, #-0x30]
    // 0x868f64: LoadField: d2 = r3->field_7
    //     0x868f64: ldur            d2, [x3, #7]
    // 0x868f68: fsub            d3, d2, d1
    // 0x868f6c: stur            d3, [fp, #-0x40]
    // 0x868f70: r17 = 307
    //     0x868f70: mov             x17, #0x133
    // 0x868f74: ldr             w4, [x1, x17]
    // 0x868f78: DecompressPointer r4
    //     0x868f78: add             x4, x4, HEAP, lsl #32
    // 0x868f7c: LoadField: d2 = r4->field_f
    //     0x868f7c: ldur            d2, [x4, #0xf]
    // 0x868f80: stur            d2, [fp, #-0x38]
    // 0x868f84: r0 = Offset()
    //     0x868f84: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x868f88: ldur            d0, [fp, #-0x40]
    // 0x868f8c: StoreField: r0->field_7 = d0
    //     0x868f8c: stur            d0, [x0, #7]
    // 0x868f90: ldur            d0, [fp, #-0x38]
    // 0x868f94: StoreField: r0->field_f = d0
    //     0x868f94: stur            d0, [x0, #0xf]
    // 0x868f98: ldur            x1, [fp, #-0x10]
    // 0x868f9c: r17 = 307
    //     0x868f9c: mov             x17, #0x133
    // 0x868fa0: str             w0, [x1, x17]
    // 0x868fa4: WriteBarrierInstr(obj = r1, val = r0)
    //     0x868fa4: ldurb           w16, [x1, #-1]
    //     0x868fa8: ldurb           w17, [x0, #-1]
    //     0x868fac: and             x16, x17, x16, lsr #2
    //     0x868fb0: tst             x16, HEAP, lsr #32
    //     0x868fb4: b.eq            #0x868fbc
    //     0x868fb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x868fbc: r0 = false
    //     0x868fbc: add             x0, NULL, #0x30  ; false
    // 0x868fc0: r17 = 323
    //     0x868fc0: mov             x17, #0x143
    // 0x868fc4: str             w0, [x1, x17]
    // 0x868fc8: r17 = 327
    //     0x868fc8: mov             x17, #0x147
    // 0x868fcc: ldr             w2, [x1, x17]
    // 0x868fd0: DecompressPointer r2
    //     0x868fd0: add             x2, x2, HEAP, lsl #32
    // 0x868fd4: tbnz            w2, #4, #0x86905c
    // 0x868fd8: ldur            x2, [fp, #-8]
    // 0x868fdc: d0 = 0.000000
    //     0x868fdc: eor             v0.16b, v0.16b, v0.16b
    // 0x868fe0: LoadField: d1 = r2->field_f
    //     0x868fe0: ldur            d1, [x2, #0xf]
    // 0x868fe4: fcmp            d1, d0
    // 0x868fe8: b.le            #0x86905c
    // 0x868fec: ldur            x3, [fp, #-0x18]
    // 0x868ff0: d1 = -4.000000
    //     0x868ff0: fmov            d1, #-4.00000000
    // 0x868ff4: r17 = 307
    //     0x868ff4: mov             x17, #0x133
    // 0x868ff8: ldr             w4, [x1, x17]
    // 0x868ffc: DecompressPointer r4
    //     0x868ffc: add             x4, x4, HEAP, lsl #32
    // 0x869000: LoadField: d2 = r4->field_7
    //     0x869000: ldur            d2, [x4, #7]
    // 0x869004: stur            d2, [fp, #-0x40]
    // 0x869008: LoadField: d3 = r3->field_f
    //     0x869008: ldur            d3, [x3, #0xf]
    // 0x86900c: fsub            d4, d3, d1
    // 0x869010: stur            d4, [fp, #-0x38]
    // 0x869014: r0 = Offset()
    //     0x869014: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x869018: ldur            d0, [fp, #-0x40]
    // 0x86901c: StoreField: r0->field_7 = d0
    //     0x86901c: stur            d0, [x0, #7]
    // 0x869020: ldur            d0, [fp, #-0x38]
    // 0x869024: StoreField: r0->field_f = d0
    //     0x869024: stur            d0, [x0, #0xf]
    // 0x869028: ldur            x1, [fp, #-0x10]
    // 0x86902c: r17 = 307
    //     0x86902c: mov             x17, #0x133
    // 0x869030: str             w0, [x1, x17]
    // 0x869034: WriteBarrierInstr(obj = r1, val = r0)
    //     0x869034: ldurb           w16, [x1, #-1]
    //     0x869038: ldurb           w17, [x0, #-1]
    //     0x86903c: and             x16, x17, x16, lsr #2
    //     0x869040: tst             x16, HEAP, lsr #32
    //     0x869044: b.eq            #0x86904c
    //     0x869048: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x86904c: r0 = false
    //     0x86904c: add             x0, NULL, #0x30  ; false
    // 0x869050: r17 = 327
    //     0x869050: mov             x17, #0x147
    // 0x869054: str             w0, [x1, x17]
    // 0x869058: b               #0x8690ec
    // 0x86905c: r17 = 331
    //     0x86905c: mov             x17, #0x14b
    // 0x869060: ldr             w2, [x1, x17]
    // 0x869064: DecompressPointer r2
    //     0x869064: add             x2, x2, HEAP, lsl #32
    // 0x869068: tbnz            w2, #4, #0x8690ec
    // 0x86906c: ldur            x2, [fp, #-8]
    // 0x869070: d0 = 0.000000
    //     0x869070: eor             v0.16b, v0.16b, v0.16b
    // 0x869074: LoadField: d1 = r2->field_f
    //     0x869074: ldur            d1, [x2, #0xf]
    // 0x869078: fcmp            d0, d1
    // 0x86907c: b.le            #0x8690ec
    // 0x869080: ldur            x3, [fp, #-0x18]
    // 0x869084: ldur            d1, [fp, #-0x28]
    // 0x869088: r17 = 307
    //     0x869088: mov             x17, #0x133
    // 0x86908c: ldr             w4, [x1, x17]
    // 0x869090: DecompressPointer r4
    //     0x869090: add             x4, x4, HEAP, lsl #32
    // 0x869094: LoadField: d2 = r4->field_7
    //     0x869094: ldur            d2, [x4, #7]
    // 0x869098: stur            d2, [fp, #-0x40]
    // 0x86909c: LoadField: d3 = r3->field_f
    //     0x86909c: ldur            d3, [x3, #0xf]
    // 0x8690a0: fsub            d4, d3, d1
    // 0x8690a4: stur            d4, [fp, #-0x38]
    // 0x8690a8: r0 = Offset()
    //     0x8690a8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8690ac: ldur            d0, [fp, #-0x40]
    // 0x8690b0: StoreField: r0->field_7 = d0
    //     0x8690b0: stur            d0, [x0, #7]
    // 0x8690b4: ldur            d0, [fp, #-0x38]
    // 0x8690b8: StoreField: r0->field_f = d0
    //     0x8690b8: stur            d0, [x0, #0xf]
    // 0x8690bc: ldur            x1, [fp, #-0x10]
    // 0x8690c0: r17 = 307
    //     0x8690c0: mov             x17, #0x133
    // 0x8690c4: str             w0, [x1, x17]
    // 0x8690c8: WriteBarrierInstr(obj = r1, val = r0)
    //     0x8690c8: ldurb           w16, [x1, #-1]
    //     0x8690cc: ldurb           w17, [x0, #-1]
    //     0x8690d0: and             x16, x17, x16, lsr #2
    //     0x8690d4: tst             x16, HEAP, lsr #32
    //     0x8690d8: b.eq            #0x8690e0
    //     0x8690dc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x8690e0: r0 = false
    //     0x8690e0: add             x0, NULL, #0x30  ; false
    // 0x8690e4: r17 = 331
    //     0x8690e4: mov             x17, #0x14b
    // 0x8690e8: str             w0, [x1, x17]
    // 0x8690ec: ldur            x0, [fp, #-0x18]
    // 0x8690f0: LoadField: d0 = r0->field_7
    //     0x8690f0: ldur            d0, [x0, #7]
    // 0x8690f4: r17 = 307
    //     0x8690f4: mov             x17, #0x133
    // 0x8690f8: ldr             w2, [x1, x17]
    // 0x8690fc: DecompressPointer r2
    //     0x8690fc: add             x2, x2, HEAP, lsl #32
    // 0x869100: LoadField: d1 = r2->field_7
    //     0x869100: ldur            d1, [x2, #7]
    // 0x869104: fsub            d2, d0, d1
    // 0x869108: stur            d2, [fp, #-0x40]
    // 0x86910c: LoadField: d0 = r0->field_f
    //     0x86910c: ldur            d0, [x0, #0xf]
    // 0x869110: LoadField: d1 = r2->field_f
    //     0x869110: ldur            d1, [x2, #0xf]
    // 0x869114: fsub            d3, d0, d1
    // 0x869118: stur            d3, [fp, #-0x38]
    // 0x86911c: r0 = Offset()
    //     0x86911c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x869120: ldur            d0, [fp, #-0x40]
    // 0x869124: StoreField: r0->field_7 = d0
    //     0x869124: stur            d0, [x0, #7]
    // 0x869128: ldur            d1, [fp, #-0x38]
    // 0x86912c: StoreField: r0->field_f = d1
    //     0x86912c: stur            d1, [x0, #0xf]
    // 0x869130: mov             x1, x0
    // 0x869134: ldur            x2, [fp, #-0x20]
    // 0x869138: r0 = _calculateAdjustedCursorOffset()
    //     0x869138: bl              #0x869238  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_calculateAdjustedCursorOffset
    // 0x86913c: mov             x1, x0
    // 0x869140: ldur            d0, [fp, #-0x40]
    // 0x869144: d1 = -4.000000
    //     0x869144: fmov            d1, #-4.00000000
    // 0x869148: fcmp            d1, d0
    // 0x86914c: b.le            #0x869184
    // 0x869150: ldur            x2, [fp, #-8]
    // 0x869154: d2 = 0.000000
    //     0x869154: eor             v2.16b, v2.16b, v2.16b
    // 0x869158: LoadField: d3 = r2->field_7
    //     0x869158: ldur            d3, [x2, #7]
    // 0x86915c: fcmp            d2, d3
    // 0x869160: b.le            #0x869178
    // 0x869164: ldur            x3, [fp, #-0x10]
    // 0x869168: r4 = true
    //     0x869168: add             x4, NULL, #0x20  ; true
    // 0x86916c: r17 = 319
    //     0x86916c: mov             x17, #0x13f
    // 0x869170: str             w4, [x3, x17]
    // 0x869174: b               #0x8691b4
    // 0x869178: ldur            x3, [fp, #-0x10]
    // 0x86917c: r4 = true
    //     0x86917c: add             x4, NULL, #0x20  ; true
    // 0x869180: b               #0x869194
    // 0x869184: ldur            x3, [fp, #-0x10]
    // 0x869188: ldur            x2, [fp, #-8]
    // 0x86918c: r4 = true
    //     0x86918c: add             x4, NULL, #0x20  ; true
    // 0x869190: d2 = 0.000000
    //     0x869190: eor             v2.16b, v2.16b, v2.16b
    // 0x869194: ldur            d3, [fp, #-0x30]
    // 0x869198: fcmp            d0, d3
    // 0x86919c: b.le            #0x8691b4
    // 0x8691a0: LoadField: d0 = r2->field_7
    //     0x8691a0: ldur            d0, [x2, #7]
    // 0x8691a4: fcmp            d0, d2
    // 0x8691a8: b.le            #0x8691b4
    // 0x8691ac: r17 = 323
    //     0x8691ac: mov             x17, #0x143
    // 0x8691b0: str             w4, [x3, x17]
    // 0x8691b4: ldur            d0, [fp, #-0x38]
    // 0x8691b8: fcmp            d1, d0
    // 0x8691bc: b.le            #0x8691d8
    // 0x8691c0: LoadField: d1 = r2->field_f
    //     0x8691c0: ldur            d1, [x2, #0xf]
    // 0x8691c4: fcmp            d2, d1
    // 0x8691c8: b.le            #0x8691d8
    // 0x8691cc: r17 = 327
    //     0x8691cc: mov             x17, #0x147
    // 0x8691d0: str             w4, [x3, x17]
    // 0x8691d4: b               #0x8691f8
    // 0x8691d8: ldur            d1, [fp, #-0x28]
    // 0x8691dc: fcmp            d0, d1
    // 0x8691e0: b.le            #0x8691f8
    // 0x8691e4: LoadField: d0 = r2->field_f
    //     0x8691e4: ldur            d0, [x2, #0xf]
    // 0x8691e8: fcmp            d0, d2
    // 0x8691ec: b.le            #0x8691f8
    // 0x8691f0: r17 = 331
    //     0x8691f0: mov             x17, #0x14b
    // 0x8691f4: str             w4, [x3, x17]
    // 0x8691f8: ldur            x0, [fp, #-0x18]
    // 0x8691fc: r17 = 311
    //     0x8691fc: mov             x17, #0x137
    // 0x869200: str             w0, [x3, x17]
    // 0x869204: WriteBarrierInstr(obj = r3, val = r0)
    //     0x869204: ldurb           w16, [x3, #-1]
    //     0x869208: ldurb           w17, [x0, #-1]
    //     0x86920c: and             x16, x17, x16, lsr #2
    //     0x869210: tst             x16, HEAP, lsr #32
    //     0x869214: b.eq            #0x86921c
    //     0x869218: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x86921c: mov             x0, x1
    // 0x869220: LeaveFrame
    //     0x869220: mov             SP, fp
    //     0x869224: ldp             fp, lr, [SP], #0x10
    // 0x869228: ret
    //     0x869228: ret             
    // 0x86922c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86922c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869230: b               #0x868d64
    // 0x869234: r0 = NullCastErrorSharedWithFPURegs()
    //     0x869234: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  static _ _calculateAdjustedCursorOffset(/* No info */) {
    // ** addr: 0x869238, size: 0xa4
    // 0x869238: EnterFrame
    //     0x869238: stp             fp, lr, [SP, #-0x10]!
    //     0x86923c: mov             fp, SP
    // 0x869240: AllocStack(0x10)
    //     0x869240: sub             SP, SP, #0x10
    // 0x869244: LoadField: d0 = r1->field_7
    //     0x869244: ldur            d0, [x1, #7]
    // 0x869248: LoadField: d1 = r2->field_7
    //     0x869248: ldur            d1, [x2, #7]
    // 0x86924c: ArrayLoad: d2 = r2[0]  ; List_8
    //     0x86924c: ldur            d2, [x2, #0x17]
    // 0x869250: fcmp            d1, d0
    // 0x869254: b.le            #0x869260
    // 0x869258: mov             v0.16b, v1.16b
    // 0x86925c: b               #0x86927c
    // 0x869260: fcmp            d0, d2
    // 0x869264: b.le            #0x869270
    // 0x869268: mov             v0.16b, v2.16b
    // 0x86926c: b               #0x86927c
    // 0x869270: fcmp            d0, d0
    // 0x869274: b.vc            #0x86927c
    // 0x869278: mov             v0.16b, v2.16b
    // 0x86927c: stur            d0, [fp, #-0x10]
    // 0x869280: LoadField: d1 = r1->field_f
    //     0x869280: ldur            d1, [x1, #0xf]
    // 0x869284: LoadField: d2 = r2->field_f
    //     0x869284: ldur            d2, [x2, #0xf]
    // 0x869288: LoadField: d3 = r2->field_1f
    //     0x869288: ldur            d3, [x2, #0x1f]
    // 0x86928c: fcmp            d2, d1
    // 0x869290: b.le            #0x86929c
    // 0x869294: mov             v1.16b, v2.16b
    // 0x869298: b               #0x8692b8
    // 0x86929c: fcmp            d1, d3
    // 0x8692a0: b.le            #0x8692ac
    // 0x8692a4: mov             v1.16b, v3.16b
    // 0x8692a8: b               #0x8692b8
    // 0x8692ac: fcmp            d1, d1
    // 0x8692b0: b.vc            #0x8692b8
    // 0x8692b4: mov             v1.16b, v3.16b
    // 0x8692b8: stur            d1, [fp, #-8]
    // 0x8692bc: r0 = Offset()
    //     0x8692bc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8692c0: ldur            d0, [fp, #-0x10]
    // 0x8692c4: StoreField: r0->field_7 = d0
    //     0x8692c4: stur            d0, [x0, #7]
    // 0x8692c8: ldur            d0, [fp, #-8]
    // 0x8692cc: StoreField: r0->field_f = d0
    //     0x8692cc: stur            d0, [x0, #0xf]
    // 0x8692d0: LeaveFrame
    //     0x8692d0: mov             SP, fp
    //     0x8692d4: ldp             fp, lr, [SP], #0x10
    // 0x8692d8: ret
    //     0x8692d8: ret             
  }
  set _ cursorColor=(/* No info */) {
    // ** addr: 0x86961c, size: 0x5c
    // 0x86961c: EnterFrame
    //     0x86961c: stp             fp, lr, [SP, #-0x10]!
    //     0x869620: mov             fp, SP
    // 0x869624: AllocStack(0x8)
    //     0x869624: sub             SP, SP, #8
    // 0x869628: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0x869628: stur            x2, [fp, #-8]
    // 0x86962c: CheckStackOverflow
    //     0x86962c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x869630: cmp             SP, x16
    //     0x869634: b.ls            #0x869670
    // 0x869638: LoadField: r0 = r1->field_73
    //     0x869638: ldur            w0, [x1, #0x73]
    // 0x86963c: DecompressPointer r0
    //     0x86963c: add             x0, x0, HEAP, lsl #32
    // 0x869640: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x869644: cmp             w0, w16
    // 0x869648: b.ne            #0x869654
    // 0x86964c: r2 = _caretPainter
    //     0x86964c: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0x869650: r0 = InitLateFinalInstanceField()
    //     0x869650: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x869654: mov             x1, x0
    // 0x869658: ldur            x2, [fp, #-8]
    // 0x86965c: r0 = caretColor=()
    //     0x86965c: bl              #0x869678  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::caretColor=
    // 0x869660: r0 = Null
    //     0x869660: mov             x0, NULL
    // 0x869664: LeaveFrame
    //     0x869664: mov             SP, fp
    //     0x869668: ldp             fp, lr, [SP], #0x10
    // 0x86966c: ret
    //     0x86966c: ret             
    // 0x869670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x869670: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869674: b               #0x869638
  }
  _ getLineAtOffset(/* No info */) {
    // ** addr: 0x870408, size: 0x128
    // 0x870408: EnterFrame
    //     0x870408: stp             fp, lr, [SP, #-0x10]!
    //     0x87040c: mov             fp, SP
    // 0x870410: AllocStack(0x20)
    //     0x870410: sub             SP, SP, #0x20
    // 0x870414: SetupParameters(RenderEditable this /* r1 => r0, fp-0x10 */)
    //     0x870414: mov             x0, x1
    //     0x870418: stur            x1, [fp, #-0x10]
    // 0x87041c: CheckStackOverflow
    //     0x87041c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x870420: cmp             SP, x16
    //     0x870424: b.ls            #0x870528
    // 0x870428: LoadField: r3 = r0->field_a7
    //     0x870428: ldur            w3, [x0, #0xa7]
    // 0x87042c: DecompressPointer r3
    //     0x87042c: add             x3, x3, HEAP, lsl #32
    // 0x870430: mov             x1, x3
    // 0x870434: stur            x3, [fp, #-8]
    // 0x870438: r0 = getLineBoundary()
    //     0x870438: bl              #0x870530  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getLineBoundary
    // 0x87043c: mov             x1, x0
    // 0x870440: ldur            x0, [fp, #-0x10]
    // 0x870444: LoadField: r2 = r0->field_97
    //     0x870444: ldur            w2, [x0, #0x97]
    // 0x870448: DecompressPointer r2
    //     0x870448: add             x2, x2, HEAP, lsl #32
    // 0x87044c: tbnz            w2, #4, #0x8704b8
    // 0x870450: ldur            x1, [fp, #-8]
    // 0x870454: r0 = plainText()
    //     0x870454: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0x870458: LoadField: r1 = r0->field_7
    //     0x870458: ldur            w1, [x0, #7]
    // 0x87045c: stur            x1, [fp, #-8]
    // 0x870460: r0 = TextSelection()
    //     0x870460: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x870464: ArrayStore: r0[0] = rZR  ; List_8
    //     0x870464: stur            xzr, [x0, #0x17]
    // 0x870468: ldur            x1, [fp, #-8]
    // 0x87046c: r2 = LoadInt32Instr(r1)
    //     0x87046c: sbfx            x2, x1, #1, #0x1f
    // 0x870470: StoreField: r0->field_1f = r2
    //     0x870470: stur            x2, [x0, #0x1f]
    // 0x870474: r3 = Instance_TextAffinity
    //     0x870474: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x870478: StoreField: r0->field_27 = r3
    //     0x870478: stur            w3, [x0, #0x27]
    // 0x87047c: r4 = false
    //     0x87047c: add             x4, NULL, #0x30  ; false
    // 0x870480: StoreField: r0->field_2b = r4
    //     0x870480: stur            w4, [x0, #0x2b]
    // 0x870484: cmp             x2, #0
    // 0x870488: b.le            #0x870494
    // 0x87048c: r1 = 0
    //     0x87048c: mov             x1, #0
    // 0x870490: b               #0x870498
    // 0x870494: mov             x1, x2
    // 0x870498: cmp             x2, #0
    // 0x87049c: b.gt            #0x8704a4
    // 0x8704a0: r2 = 0
    //     0x8704a0: mov             x2, #0
    // 0x8704a4: StoreField: r0->field_7 = r1
    //     0x8704a4: stur            x1, [x0, #7]
    // 0x8704a8: StoreField: r0->field_f = r2
    //     0x8704a8: stur            x2, [x0, #0xf]
    // 0x8704ac: LeaveFrame
    //     0x8704ac: mov             SP, fp
    //     0x8704b0: ldp             fp, lr, [SP], #0x10
    // 0x8704b4: ret
    //     0x8704b4: ret             
    // 0x8704b8: r3 = Instance_TextAffinity
    //     0x8704b8: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x8704bc: r4 = false
    //     0x8704bc: add             x4, NULL, #0x30  ; false
    // 0x8704c0: LoadField: r0 = r1->field_7
    //     0x8704c0: ldur            x0, [x1, #7]
    // 0x8704c4: stur            x0, [fp, #-0x20]
    // 0x8704c8: LoadField: r2 = r1->field_f
    //     0x8704c8: ldur            x2, [x1, #0xf]
    // 0x8704cc: stur            x2, [fp, #-0x18]
    // 0x8704d0: r0 = TextSelection()
    //     0x8704d0: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x8704d4: ldur            x1, [fp, #-0x20]
    // 0x8704d8: ArrayStore: r0[0] = r1  ; List_8
    //     0x8704d8: stur            x1, [x0, #0x17]
    // 0x8704dc: ldur            x2, [fp, #-0x18]
    // 0x8704e0: StoreField: r0->field_1f = r2
    //     0x8704e0: stur            x2, [x0, #0x1f]
    // 0x8704e4: r3 = Instance_TextAffinity
    //     0x8704e4: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x8704e8: StoreField: r0->field_27 = r3
    //     0x8704e8: stur            w3, [x0, #0x27]
    // 0x8704ec: r3 = false
    //     0x8704ec: add             x3, NULL, #0x30  ; false
    // 0x8704f0: StoreField: r0->field_2b = r3
    //     0x8704f0: stur            w3, [x0, #0x2b]
    // 0x8704f4: cmp             x1, x2
    // 0x8704f8: b.ge            #0x870504
    // 0x8704fc: mov             x3, x1
    // 0x870500: b               #0x870508
    // 0x870504: mov             x3, x2
    // 0x870508: cmp             x1, x2
    // 0x87050c: b.ge            #0x870514
    // 0x870510: mov             x1, x2
    // 0x870514: StoreField: r0->field_7 = r3
    //     0x870514: stur            x3, [x0, #7]
    // 0x870518: StoreField: r0->field_f = r1
    //     0x870518: stur            x1, [x0, #0xf]
    // 0x87051c: LeaveFrame
    //     0x87051c: mov             SP, fp
    //     0x870520: ldp             fp, lr, [SP], #0x10
    // 0x870524: ret
    //     0x870524: ret             
    // 0x870528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870528: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87052c: b               #0x870428
  }
  _ selectPositionAt(/* No info */) {
    // ** addr: 0x8793a0, size: 0x1dc
    // 0x8793a0: EnterFrame
    //     0x8793a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8793a4: mov             fp, SP
    // 0x8793a8: AllocStack(0x38)
    //     0x8793a8: sub             SP, SP, #0x38
    // 0x8793ac: SetupParameters(RenderEditable this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */)
    //     0x8793ac: mov             x0, x1
    //     0x8793b0: stur            x2, [fp, #-0x18]
    //     0x8793b4: mov             x16, x3
    //     0x8793b8: mov             x3, x2
    //     0x8793bc: mov             x2, x16
    //     0x8793c0: stur            x1, [fp, #-0x10]
    //     0x8793c4: stur            x2, [fp, #-0x20]
    // 0x8793c8: LoadField: r1 = r4->field_13
    //     0x8793c8: ldur            w1, [x4, #0x13]
    // 0x8793cc: LoadField: r5 = r4->field_1f
    //     0x8793cc: ldur            w5, [x4, #0x1f]
    // 0x8793d0: DecompressPointer r5
    //     0x8793d0: add             x5, x5, HEAP, lsl #32
    // 0x8793d4: r16 = "to"
    //     0x8793d4: ldr             x16, [PP, #0x6220]  ; [pp+0x6220] "to"
    // 0x8793d8: cmp             w5, w16
    // 0x8793dc: b.ne            #0x8793fc
    // 0x8793e0: LoadField: r5 = r4->field_23
    //     0x8793e0: ldur            w5, [x4, #0x23]
    // 0x8793e4: DecompressPointer r5
    //     0x8793e4: add             x5, x5, HEAP, lsl #32
    // 0x8793e8: sub             w4, w1, w5
    // 0x8793ec: add             x1, fp, w4, sxtw #2
    // 0x8793f0: ldr             x1, [x1, #8]
    // 0x8793f4: mov             x4, x1
    // 0x8793f8: b               #0x879400
    // 0x8793fc: r4 = Null
    //     0x8793fc: mov             x4, NULL
    // 0x879400: stur            x4, [fp, #-8]
    // 0x879404: CheckStackOverflow
    //     0x879404: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879408: cmp             SP, x16
    //     0x87940c: b.ls            #0x879574
    // 0x879410: mov             x1, x0
    // 0x879414: r0 = _computeTextMetricsIfNeeded()
    //     0x879414: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0x879418: ldur            x0, [fp, #-0x10]
    // 0x87941c: LoadField: r3 = r0->field_a7
    //     0x87941c: ldur            w3, [x0, #0xa7]
    // 0x879420: DecompressPointer r3
    //     0x879420: add             x3, x3, HEAP, lsl #32
    // 0x879424: mov             x1, x0
    // 0x879428: ldur            x2, [fp, #-0x20]
    // 0x87942c: stur            x3, [fp, #-0x28]
    // 0x879430: r0 = globalToLocal()
    //     0x879430: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x879434: ldur            x1, [fp, #-0x10]
    // 0x879438: stur            x0, [fp, #-0x20]
    // 0x87943c: r0 = _paintOffset()
    //     0x87943c: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x879440: ldur            x1, [fp, #-0x20]
    // 0x879444: mov             x2, x0
    // 0x879448: r0 = -()
    //     0x879448: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x87944c: ldur            x1, [fp, #-0x28]
    // 0x879450: mov             x2, x0
    // 0x879454: r0 = getPositionForOffset()
    //     0x879454: bl              #0x86749c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x879458: ldur            x2, [fp, #-8]
    // 0x87945c: stur            x0, [fp, #-0x20]
    // 0x879460: cmp             w2, NULL
    // 0x879464: b.ne            #0x879474
    // 0x879468: mov             x2, x0
    // 0x87946c: r0 = Null
    //     0x87946c: mov             x0, NULL
    // 0x879470: b               #0x8794a4
    // 0x879474: ldur            x1, [fp, #-0x10]
    // 0x879478: r0 = globalToLocal()
    //     0x879478: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x87947c: ldur            x1, [fp, #-0x10]
    // 0x879480: stur            x0, [fp, #-8]
    // 0x879484: r0 = _paintOffset()
    //     0x879484: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x879488: ldur            x1, [fp, #-8]
    // 0x87948c: mov             x2, x0
    // 0x879490: r0 = -()
    //     0x879490: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x879494: ldur            x1, [fp, #-0x28]
    // 0x879498: mov             x2, x0
    // 0x87949c: r0 = getPositionForOffset()
    //     0x87949c: bl              #0x86749c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x8794a0: ldur            x2, [fp, #-0x20]
    // 0x8794a4: LoadField: r3 = r2->field_7
    //     0x8794a4: ldur            x3, [x2, #7]
    // 0x8794a8: stur            x3, [fp, #-0x38]
    // 0x8794ac: cmp             w0, NULL
    // 0x8794b0: b.ne            #0x8794bc
    // 0x8794b4: r0 = Null
    //     0x8794b4: mov             x0, NULL
    // 0x8794b8: b               #0x8794d4
    // 0x8794bc: LoadField: r4 = r0->field_7
    //     0x8794bc: ldur            x4, [x0, #7]
    // 0x8794c0: r0 = BoxInt64Instr(r4)
    //     0x8794c0: sbfiz           x0, x4, #1, #0x1f
    //     0x8794c4: cmp             x4, x0, asr #1
    //     0x8794c8: b.eq            #0x8794d4
    //     0x8794cc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x8794d0: stur            x4, [x0, #7]
    // 0x8794d4: cmp             w0, NULL
    // 0x8794d8: b.ne            #0x8794e4
    // 0x8794dc: mov             x0, x3
    // 0x8794e0: b               #0x8794f4
    // 0x8794e4: r1 = LoadInt32Instr(r0)
    //     0x8794e4: sbfx            x1, x0, #1, #0x1f
    //     0x8794e8: tbz             w0, #0, #0x8794f0
    //     0x8794ec: ldur            x1, [x0, #7]
    // 0x8794f0: mov             x0, x1
    // 0x8794f4: stur            x0, [fp, #-0x30]
    // 0x8794f8: LoadField: r1 = r2->field_f
    //     0x8794f8: ldur            w1, [x2, #0xf]
    // 0x8794fc: DecompressPointer r1
    //     0x8794fc: add             x1, x1, HEAP, lsl #32
    // 0x879500: stur            x1, [fp, #-8]
    // 0x879504: r0 = TextSelection()
    //     0x879504: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x879508: mov             x1, x0
    // 0x87950c: ldur            x0, [fp, #-0x38]
    // 0x879510: ArrayStore: r1[0] = r0  ; List_8
    //     0x879510: stur            x0, [x1, #0x17]
    // 0x879514: ldur            x2, [fp, #-0x30]
    // 0x879518: StoreField: r1->field_1f = r2
    //     0x879518: stur            x2, [x1, #0x1f]
    // 0x87951c: ldur            x3, [fp, #-8]
    // 0x879520: StoreField: r1->field_27 = r3
    //     0x879520: stur            w3, [x1, #0x27]
    // 0x879524: r3 = false
    //     0x879524: add             x3, NULL, #0x30  ; false
    // 0x879528: StoreField: r1->field_2b = r3
    //     0x879528: stur            w3, [x1, #0x2b]
    // 0x87952c: cmp             x0, x2
    // 0x879530: b.ge            #0x87953c
    // 0x879534: mov             x3, x0
    // 0x879538: b               #0x879540
    // 0x87953c: mov             x3, x2
    // 0x879540: cmp             x0, x2
    // 0x879544: b.ge            #0x87954c
    // 0x879548: mov             x0, x2
    // 0x87954c: StoreField: r1->field_7 = r3
    //     0x87954c: stur            x3, [x1, #7]
    // 0x879550: StoreField: r1->field_f = r0
    //     0x879550: stur            x0, [x1, #0xf]
    // 0x879554: mov             x2, x1
    // 0x879558: ldur            x1, [fp, #-0x10]
    // 0x87955c: ldur            x3, [fp, #-0x18]
    // 0x879560: r0 = _setSelection()
    //     0x879560: bl              #0x87957c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_setSelection
    // 0x879564: r0 = Null
    //     0x879564: mov             x0, NULL
    // 0x879568: LeaveFrame
    //     0x879568: mov             SP, fp
    //     0x87956c: ldp             fp, lr, [SP], #0x10
    // 0x879570: ret
    //     0x879570: ret             
    // 0x879574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x879574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x879578: b               #0x879410
  }
  _ _setSelection(/* No info */) {
    // ** addr: 0x87957c, size: 0x138
    // 0x87957c: EnterFrame
    //     0x87957c: stp             fp, lr, [SP, #-0x10]!
    //     0x879580: mov             fp, SP
    // 0x879584: AllocStack(0x20)
    //     0x879584: sub             SP, SP, #0x20
    // 0x879588: SetupParameters(RenderEditable this /* r1 => r4, fp-0x8 */, dynamic _ /* r3 => r3, fp-0x10 */)
    //     0x879588: mov             x4, x1
    //     0x87958c: stur            x1, [fp, #-8]
    //     0x879590: stur            x3, [fp, #-0x10]
    // 0x879594: CheckStackOverflow
    //     0x879594: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x879598: cmp             SP, x16
    //     0x87959c: b.ls            #0x8796a4
    // 0x8795a0: LoadField: r0 = r2->field_7
    //     0x8795a0: ldur            x0, [x2, #7]
    // 0x8795a4: tbnz            x0, #0x3f, #0x879644
    // 0x8795a8: LoadField: r0 = r2->field_f
    //     0x8795a8: ldur            x0, [x2, #0xf]
    // 0x8795ac: tbnz            x0, #0x3f, #0x879644
    // 0x8795b0: LoadField: r0 = r4->field_9b
    //     0x8795b0: ldur            w0, [x4, #0x9b]
    // 0x8795b4: DecompressPointer r0
    //     0x8795b4: add             x0, x0, HEAP, lsl #32
    // 0x8795b8: LoadField: r1 = r0->field_b
    //     0x8795b8: ldur            w1, [x0, #0xb]
    // 0x8795bc: DecompressPointer r1
    //     0x8795bc: add             x1, x1, HEAP, lsl #32
    // 0x8795c0: cmp             w1, NULL
    // 0x8795c4: b.eq            #0x8796ac
    // 0x8795c8: LoadField: r0 = r1->field_b
    //     0x8795c8: ldur            w0, [x1, #0xb]
    // 0x8795cc: DecompressPointer r0
    //     0x8795cc: add             x0, x0, HEAP, lsl #32
    // 0x8795d0: LoadField: r1 = r0->field_27
    //     0x8795d0: ldur            w1, [x0, #0x27]
    // 0x8795d4: DecompressPointer r1
    //     0x8795d4: add             x1, x1, HEAP, lsl #32
    // 0x8795d8: LoadField: r0 = r1->field_7
    //     0x8795d8: ldur            w0, [x1, #7]
    // 0x8795dc: DecompressPointer r0
    //     0x8795dc: add             x0, x0, HEAP, lsl #32
    // 0x8795e0: LoadField: r1 = r0->field_7
    //     0x8795e0: ldur            w1, [x0, #7]
    // 0x8795e4: ArrayLoad: r0 = r2[0]  ; List_8
    //     0x8795e4: ldur            x0, [x2, #0x17]
    // 0x8795e8: r5 = LoadInt32Instr(r1)
    //     0x8795e8: sbfx            x5, x1, #1, #0x1f
    // 0x8795ec: cmp             x0, x5
    // 0x8795f0: csel            x6, x5, x0, gt
    // 0x8795f4: LoadField: r0 = r2->field_1f
    //     0x8795f4: ldur            x0, [x2, #0x1f]
    // 0x8795f8: cmp             x0, x5
    // 0x8795fc: csel            x7, x5, x0, gt
    // 0x879600: r0 = BoxInt64Instr(r6)
    //     0x879600: sbfiz           x0, x6, #1, #0x1f
    //     0x879604: cmp             x6, x0, asr #1
    //     0x879608: b.eq            #0x879614
    //     0x87960c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x879610: stur            x6, [x0, #7]
    // 0x879614: mov             x5, x0
    // 0x879618: r0 = BoxInt64Instr(r7)
    //     0x879618: sbfiz           x0, x7, #1, #0x1f
    //     0x87961c: cmp             x7, x0, asr #1
    //     0x879620: b.eq            #0x87962c
    //     0x879624: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x879628: stur            x7, [x0, #7]
    // 0x87962c: stp             x0, x5, [SP]
    // 0x879630: mov             x1, x2
    // 0x879634: r4 = const [0, 0x3, 0x2, 0x1, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0x879634: ldr             x4, [PP, #0x6228]  ; [pp+0x6228] List(9) [0, 0x3, 0x2, 0x1, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    // 0x879638: r0 = copyWith()
    //     0x879638: bl              #0x877a64  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x87963c: mov             x1, x0
    // 0x879640: b               #0x879648
    // 0x879644: mov             x1, x2
    // 0x879648: ldur            x0, [fp, #-8]
    // 0x87964c: LoadField: r2 = r0->field_9b
    //     0x87964c: ldur            w2, [x0, #0x9b]
    // 0x879650: DecompressPointer r2
    //     0x879650: add             x2, x2, HEAP, lsl #32
    // 0x879654: LoadField: r3 = r2->field_b
    //     0x879654: ldur            w3, [x2, #0xb]
    // 0x879658: DecompressPointer r3
    //     0x879658: add             x3, x3, HEAP, lsl #32
    // 0x87965c: cmp             w3, NULL
    // 0x879660: b.eq            #0x8796b0
    // 0x879664: LoadField: r2 = r3->field_b
    //     0x879664: ldur            w2, [x3, #0xb]
    // 0x879668: DecompressPointer r2
    //     0x879668: add             x2, x2, HEAP, lsl #32
    // 0x87966c: LoadField: r3 = r2->field_27
    //     0x87966c: ldur            w3, [x2, #0x27]
    // 0x879670: DecompressPointer r3
    //     0x879670: add             x3, x3, HEAP, lsl #32
    // 0x879674: str             x1, [SP]
    // 0x879678: mov             x1, x3
    // 0x87967c: r4 = const [0, 0x2, 0x1, 0x1, selection, 0x1, null]
    //     0x87967c: ldr             x4, [PP, #0x5398]  ; [pp+0x5398] List(7) [0, 0x2, 0x1, 0x1, "selection", 0x1, Null]
    // 0x879680: r0 = copyWith()
    //     0x879680: bl              #0x86ff64  ; [package:flutter/src/services/text_input.dart] TextEditingValue::copyWith
    // 0x879684: ldur            x1, [fp, #-8]
    // 0x879688: mov             x2, x0
    // 0x87968c: ldur            x3, [fp, #-0x10]
    // 0x879690: r0 = _setTextEditingValue()
    //     0x879690: bl              #0x8796b4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_setTextEditingValue
    // 0x879694: r0 = Null
    //     0x879694: mov             x0, NULL
    // 0x879698: LeaveFrame
    //     0x879698: mov             SP, fp
    //     0x87969c: ldp             fp, lr, [SP], #0x10
    // 0x8796a0: ret
    //     0x8796a0: ret             
    // 0x8796a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8796a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8796a8: b               #0x8795a0
    // 0x8796ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8796ac: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8796b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8796b0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _setTextEditingValue(/* No info */) {
    // ** addr: 0x8796b4, size: 0x3c
    // 0x8796b4: EnterFrame
    //     0x8796b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8796b8: mov             fp, SP
    // 0x8796bc: CheckStackOverflow
    //     0x8796bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x8796c0: cmp             SP, x16
    //     0x8796c4: b.ls            #0x8796e8
    // 0x8796c8: LoadField: r0 = r1->field_9b
    //     0x8796c8: ldur            w0, [x1, #0x9b]
    // 0x8796cc: DecompressPointer r0
    //     0x8796cc: add             x0, x0, HEAP, lsl #32
    // 0x8796d0: mov             x1, x0
    // 0x8796d4: r0 = userUpdateTextEditingValue()
    //     0x8796d4: bl              #0x86b020  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::userUpdateTextEditingValue
    // 0x8796d8: r0 = Null
    //     0x8796d8: mov             x0, NULL
    // 0x8796dc: LeaveFrame
    //     0x8796dc: mov             SP, fp
    //     0x8796e0: ldp             fp, lr, [SP], #0x10
    // 0x8796e4: ret
    //     0x8796e4: ret             
    // 0x8796e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8796e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8796ec: b               #0x8796c8
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb1c708, size: 0x24
    // 0xb1c708: EnterFrame
    //     0xb1c708: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c70c: mov             fp, SP
    // 0xb1c710: ldr             x2, [fp, #0x10]
    // 0xb1c714: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1c714: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd598] AnonymousClosure: (0xb1c72c), in [package:flutter/src/rendering/editable.dart] RenderEditable::computeMinIntrinsicWidth (0xb1c7a4)
    //     0xb1c718: ldr             x1, [x1, #0x598]
    // 0xb1c71c: r0 = AllocateClosure()
    //     0xb1c71c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1c720: LeaveFrame
    //     0xb1c720: mov             SP, fp
    //     0xb1c724: ldp             fp, lr, [SP], #0x10
    // 0xb1c728: ret
    //     0xb1c728: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb1c72c, size: 0x78
    // 0xb1c72c: EnterFrame
    //     0xb1c72c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c730: mov             fp, SP
    // 0xb1c734: ldr             x0, [fp, #0x18]
    // 0xb1c738: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1c738: ldur            w1, [x0, #0x17]
    // 0xb1c73c: DecompressPointer r1
    //     0xb1c73c: add             x1, x1, HEAP, lsl #32
    // 0xb1c740: CheckStackOverflow
    //     0xb1c740: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c744: cmp             SP, x16
    //     0xb1c748: b.ls            #0xb1c78c
    // 0xb1c74c: ldr             x2, [fp, #0x10]
    // 0xb1c750: r0 = computeMinIntrinsicWidth()
    //     0xb1c750: bl              #0xb1c7a4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::computeMinIntrinsicWidth
    // 0xb1c754: r0 = inline_Allocate_Double()
    //     0xb1c754: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1c758: add             x0, x0, #0x10
    //     0xb1c75c: cmp             x1, x0
    //     0xb1c760: b.ls            #0xb1c794
    //     0xb1c764: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1c768: sub             x0, x0, #0xf
    //     0xb1c76c: mov             x1, #0xe19c
    //     0xb1c770: movk            x1, #3, lsl #16
    //     0xb1c774: stur            x1, [x0, #-1]
    // 0xb1c778: dmb             ishst
    // 0xb1c77c: StoreField: r0->field_7 = d0
    //     0xb1c77c: stur            d0, [x0, #7]
    // 0xb1c780: LeaveFrame
    //     0xb1c780: mov             SP, fp
    //     0xb1c784: ldp             fp, lr, [SP], #0x10
    // 0xb1c788: ret
    //     0xb1c788: ret             
    // 0xb1c78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c78c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c790: b               #0xb1c74c
    // 0xb1c794: SaveReg d0
    //     0xb1c794: str             q0, [SP, #-0x10]!
    // 0xb1c798: r0 = AllocateDouble()
    //     0xb1c798: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1c79c: RestoreReg d0
    //     0xb1c79c: ldr             q0, [SP], #0x10
    // 0xb1c7a0: b               #0xb1c77c
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb1c7a4, size: 0xb4
    // 0xb1c7a4: EnterFrame
    //     0xb1c7a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb1c7a8: mov             fp, SP
    // 0xb1c7ac: AllocStack(0x30)
    //     0xb1c7ac: sub             SP, SP, #0x30
    // 0xb1c7b0: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xb1c7b0: mov             x0, x1
    //     0xb1c7b4: stur            x1, [fp, #-8]
    // 0xb1c7b8: CheckStackOverflow
    //     0xb1c7b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1c7bc: cmp             SP, x16
    //     0xb1c7c0: b.ls            #0xb1c850
    // 0xb1c7c4: r1 = Function '<anonymous closure>':.
    //     0xb1c7c4: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd5a0] AnonymousClosure: (0xb1d860), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMinIntrinsicWidth (0xb1d8ac)
    //     0xb1c7c8: ldr             x1, [x1, #0x5a0]
    // 0xb1c7cc: r2 = Null
    //     0xb1c7cc: mov             x2, NULL
    // 0xb1c7d0: r0 = AllocateClosure()
    //     0xb1c7d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1c7d4: ldur            x1, [fp, #-8]
    // 0xb1c7d8: mov             x2, x0
    // 0xb1c7dc: d0 = inf
    //     0xb1c7dc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb1c7e0: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb1c7e0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb1c7e4: ldr             x3, [x3, #0x860]
    // 0xb1c7e8: r0 = layoutInlineChildren()
    //     0xb1c7e8: bl              #0xb1d4b8  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb1c7ec: ldur            x1, [fp, #-8]
    // 0xb1c7f0: stur            x0, [fp, #-0x10]
    // 0xb1c7f4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb1c7f4: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb1c7f8: r0 = _adjustConstraints()
    //     0xb1c7f8: bl              #0x860b7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_adjustConstraints
    // 0xb1c7fc: mov             x2, x0
    // 0xb1c800: stur            x2, [fp, #-0x20]
    // 0xb1c804: mov             x3, x1
    // 0xb1c808: ldur            x1, [fp, #-8]
    // 0xb1c80c: stur            x3, [fp, #-0x18]
    // 0xb1c810: r0 = _textIntrinsics()
    //     0xb1c810: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb1c814: mov             x1, x0
    // 0xb1c818: ldur            x2, [fp, #-0x10]
    // 0xb1c81c: stur            x0, [fp, #-8]
    // 0xb1c820: r0 = setPlaceholderDimensions()
    //     0xb1c820: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb1c824: ldur            x16, [fp, #-0x20]
    // 0xb1c828: ldur            lr, [fp, #-0x18]
    // 0xb1c82c: stp             lr, x16, [SP]
    // 0xb1c830: ldur            x1, [fp, #-8]
    // 0xb1c834: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb1c834: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb1c838: r0 = layout()
    //     0xb1c838: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb1c83c: ldur            x1, [fp, #-8]
    // 0xb1c840: r0 = minIntrinsicWidth()
    //     0xb1c840: bl              #0xb1c858  ; [package:flutter/src/painting/text_painter.dart] TextPainter::minIntrinsicWidth
    // 0xb1c844: LeaveFrame
    //     0xb1c844: mov             SP, fp
    //     0xb1c848: ldp             fp, lr, [SP], #0x10
    // 0xb1c84c: ret
    //     0xb1c84c: ret             
    // 0xb1c850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1c850: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1c854: b               #0xb1c7c4
  }
  get _ _textIntrinsics(/* No info */) {
    // ** addr: 0xb1cbcc, size: 0x1dc
    // 0xb1cbcc: EnterFrame
    //     0xb1cbcc: stp             fp, lr, [SP, #-0x10]!
    //     0xb1cbd0: mov             fp, SP
    // 0xb1cbd4: AllocStack(0x18)
    //     0xb1cbd4: sub             SP, SP, #0x18
    // 0xb1cbd8: SetupParameters(RenderEditable this /* r1 => r1, fp-0x8 */)
    //     0xb1cbd8: stur            x1, [fp, #-8]
    // 0xb1cbdc: CheckStackOverflow
    //     0xb1cbdc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1cbe0: cmp             SP, x16
    //     0xb1cbe4: b.ls            #0xb1cda0
    // 0xb1cbe8: LoadField: r0 = r1->field_b3
    //     0xb1cbe8: ldur            w0, [x1, #0xb3]
    // 0xb1cbec: DecompressPointer r0
    //     0xb1cbec: add             x0, x0, HEAP, lsl #32
    // 0xb1cbf0: cmp             w0, NULL
    // 0xb1cbf4: b.ne            #0xb1cc34
    // 0xb1cbf8: r0 = TextPainter()
    //     0xb1cbf8: bl              #0xb13a1c  ; AllocateTextPainterStub -> TextPainter (size=0x48)
    // 0xb1cbfc: mov             x1, x0
    // 0xb1cc00: stur            x0, [fp, #-0x10]
    // 0xb1cc04: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb1cc04: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb1cc08: r0 = TextPainter()
    //     0xb1cc08: bl              #0xb135d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::TextPainter
    // 0xb1cc0c: ldur            x0, [fp, #-0x10]
    // 0xb1cc10: ldur            x1, [fp, #-8]
    // 0xb1cc14: StoreField: r1->field_b3 = r0
    //     0xb1cc14: stur            w0, [x1, #0xb3]
    //     0xb1cc18: ldurb           w16, [x1, #-1]
    //     0xb1cc1c: ldurb           w17, [x0, #-1]
    //     0xb1cc20: and             x16, x17, x16, lsr #2
    //     0xb1cc24: tst             x16, HEAP, lsr #32
    //     0xb1cc28: b.eq            #0xb1cc30
    //     0xb1cc2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1cc30: ldur            x0, [fp, #-0x10]
    // 0xb1cc34: stur            x0, [fp, #-0x18]
    // 0xb1cc38: LoadField: r3 = r1->field_a7
    //     0xb1cc38: ldur            w3, [x1, #0xa7]
    // 0xb1cc3c: DecompressPointer r3
    //     0xb1cc3c: add             x3, x3, HEAP, lsl #32
    // 0xb1cc40: stur            x3, [fp, #-0x10]
    // 0xb1cc44: LoadField: r2 = r3->field_f
    //     0xb1cc44: ldur            w2, [x3, #0xf]
    // 0xb1cc48: DecompressPointer r2
    //     0xb1cc48: add             x2, x2, HEAP, lsl #32
    // 0xb1cc4c: mov             x1, x0
    // 0xb1cc50: r0 = text=()
    //     0xb1cc50: bl              #0xb1d2b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0xb1cc54: ldur            x2, [fp, #-0x10]
    // 0xb1cc58: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xb1cc58: ldur            w0, [x2, #0x17]
    // 0xb1cc5c: DecompressPointer r0
    //     0xb1cc5c: add             x0, x0, HEAP, lsl #32
    // 0xb1cc60: ldur            x3, [fp, #-0x18]
    // 0xb1cc64: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xb1cc64: ldur            w1, [x3, #0x17]
    // 0xb1cc68: DecompressPointer r1
    //     0xb1cc68: add             x1, x1, HEAP, lsl #32
    // 0xb1cc6c: cmp             w1, w0
    // 0xb1cc70: b.ne            #0xb1cc7c
    // 0xb1cc74: mov             x0, x2
    // 0xb1cc78: b               #0xb1cca8
    // 0xb1cc7c: ArrayStore: r3[0] = r0  ; List_4
    //     0xb1cc7c: stur            w0, [x3, #0x17]
    //     0xb1cc80: ldurb           w16, [x3, #-1]
    //     0xb1cc84: ldurb           w17, [x0, #-1]
    //     0xb1cc88: and             x16, x17, x16, lsr #2
    //     0xb1cc8c: tst             x16, HEAP, lsr #32
    //     0xb1cc90: b.eq            #0xb1cc98
    //     0xb1cc94: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb1cc98: mov             x1, x3
    // 0xb1cc9c: r0 = markNeedsLayout()
    //     0xb1cc9c: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1cca0: ldur            x3, [fp, #-0x18]
    // 0xb1cca4: ldur            x0, [fp, #-0x10]
    // 0xb1cca8: LoadField: r2 = r0->field_1b
    //     0xb1cca8: ldur            w2, [x0, #0x1b]
    // 0xb1ccac: DecompressPointer r2
    //     0xb1ccac: add             x2, x2, HEAP, lsl #32
    // 0xb1ccb0: mov             x1, x3
    // 0xb1ccb4: r0 = textDirection=()
    //     0xb1ccb4: bl              #0xb1d1c8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textDirection=
    // 0xb1ccb8: ldur            x0, [fp, #-0x10]
    // 0xb1ccbc: LoadField: r2 = r0->field_1f
    //     0xb1ccbc: ldur            w2, [x0, #0x1f]
    // 0xb1ccc0: DecompressPointer r2
    //     0xb1ccc0: add             x2, x2, HEAP, lsl #32
    // 0xb1ccc4: ldur            x1, [fp, #-0x18]
    // 0xb1ccc8: r0 = textScaler=()
    //     0xb1ccc8: bl              #0xb1d0b0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textScaler=
    // 0xb1cccc: ldur            x2, [fp, #-0x10]
    // 0xb1ccd0: LoadField: r0 = r2->field_2b
    //     0xb1ccd0: ldur            w0, [x2, #0x2b]
    // 0xb1ccd4: DecompressPointer r0
    //     0xb1ccd4: add             x0, x0, HEAP, lsl #32
    // 0xb1ccd8: ldur            x3, [fp, #-0x18]
    // 0xb1ccdc: LoadField: r1 = r3->field_2b
    //     0xb1ccdc: ldur            w1, [x3, #0x2b]
    // 0xb1cce0: DecompressPointer r1
    //     0xb1cce0: add             x1, x1, HEAP, lsl #32
    // 0xb1cce4: cmp             w1, w0
    // 0xb1cce8: b.eq            #0xb1cd24
    // 0xb1ccec: and             w16, w1, w0
    // 0xb1ccf0: branchIfSmi(r16, 0xb1cd2c)
    //     0xb1ccf0: tbz             w16, #0, #0xb1cd2c
    // 0xb1ccf4: r16 = LoadClassIdInstr(r1)
    //     0xb1ccf4: ldur            x16, [x1, #-1]
    //     0xb1ccf8: ubfx            x16, x16, #0xc, #0x14
    // 0xb1ccfc: cmp             x16, #0x3d
    // 0xb1cd00: b.ne            #0xb1cd2c
    // 0xb1cd04: r16 = LoadClassIdInstr(r0)
    //     0xb1cd04: ldur            x16, [x0, #-1]
    //     0xb1cd08: ubfx            x16, x16, #0xc, #0x14
    // 0xb1cd0c: cmp             x16, #0x3d
    // 0xb1cd10: b.ne            #0xb1cd2c
    // 0xb1cd14: LoadField: r16 = r1->field_7
    //     0xb1cd14: ldur            x16, [x1, #7]
    // 0xb1cd18: LoadField: r17 = r0->field_7
    //     0xb1cd18: ldur            x17, [x0, #7]
    // 0xb1cd1c: cmp             x16, x17
    // 0xb1cd20: b.ne            #0xb1cd2c
    // 0xb1cd24: mov             x0, x2
    // 0xb1cd28: b               #0xb1cd58
    // 0xb1cd2c: StoreField: r3->field_2b = r0
    //     0xb1cd2c: stur            w0, [x3, #0x2b]
    //     0xb1cd30: tbz             w0, #0, #0xb1cd4c
    //     0xb1cd34: ldurb           w16, [x3, #-1]
    //     0xb1cd38: ldurb           w17, [x0, #-1]
    //     0xb1cd3c: and             x16, x17, x16, lsr #2
    //     0xb1cd40: tst             x16, HEAP, lsr #32
    //     0xb1cd44: b.eq            #0xb1cd4c
    //     0xb1cd48: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb1cd4c: mov             x1, x3
    // 0xb1cd50: r0 = markNeedsLayout()
    //     0xb1cd50: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1cd54: ldur            x0, [fp, #-0x10]
    // 0xb1cd58: LoadField: r2 = r0->field_23
    //     0xb1cd58: ldur            w2, [x0, #0x23]
    // 0xb1cd5c: DecompressPointer r2
    //     0xb1cd5c: add             x2, x2, HEAP, lsl #32
    // 0xb1cd60: ldur            x1, [fp, #-0x18]
    // 0xb1cd64: r0 = ellipsis=()
    //     0xb1cd64: bl              #0xb1d00c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::ellipsis=
    // 0xb1cd68: ldur            x0, [fp, #-0x10]
    // 0xb1cd6c: LoadField: r2 = r0->field_27
    //     0xb1cd6c: ldur            w2, [x0, #0x27]
    // 0xb1cd70: DecompressPointer r2
    //     0xb1cd70: add             x2, x2, HEAP, lsl #32
    // 0xb1cd74: ldur            x1, [fp, #-0x18]
    // 0xb1cd78: r0 = locale=()
    //     0xb1cd78: bl              #0xb1cf68  ; [package:flutter/src/painting/text_painter.dart] TextPainter::locale=
    // 0xb1cd7c: ldur            x0, [fp, #-0x10]
    // 0xb1cd80: LoadField: r2 = r0->field_2f
    //     0xb1cd80: ldur            w2, [x0, #0x2f]
    // 0xb1cd84: DecompressPointer r2
    //     0xb1cd84: add             x2, x2, HEAP, lsl #32
    // 0xb1cd88: ldur            x1, [fp, #-0x18]
    // 0xb1cd8c: r0 = strutStyle=()
    //     0xb1cd8c: bl              #0xb1cec4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::strutStyle=
    // 0xb1cd90: ldur            x0, [fp, #-0x18]
    // 0xb1cd94: LeaveFrame
    //     0xb1cd94: mov             SP, fp
    //     0xb1cd98: ldp             fp, lr, [SP], #0x10
    // 0xb1cd9c: ret
    //     0xb1cd9c: ret             
    // 0xb1cda0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1cda0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1cda4: b               #0xb1cbe8
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2506c, size: 0x30
    // 0xb2506c: EnterFrame
    //     0xb2506c: stp             fp, lr, [SP, #-0x10]!
    //     0xb25070: mov             fp, SP
    // 0xb25074: CheckStackOverflow
    //     0xb25074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb25078: cmp             SP, x16
    //     0xb2507c: b.ls            #0xb25094
    // 0xb25080: LoadField: d0 = r2->field_7
    //     0xb25080: ldur            d0, [x2, #7]
    // 0xb25084: r0 = getMaxIntrinsicHeight()
    //     0xb25084: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb25088: LeaveFrame
    //     0xb25088: mov             SP, fp
    //     0xb2508c: ldp             fp, lr, [SP], #0x10
    // 0xb25090: ret
    //     0xb25090: ret             
    // 0xb25094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb25094: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb25098: b               #0xb25080
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2ada4, size: 0x88
    // 0xb2ada4: EnterFrame
    //     0xb2ada4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ada8: mov             fp, SP
    // 0xb2adac: AllocStack(0x20)
    //     0xb2adac: sub             SP, SP, #0x20
    // 0xb2adb0: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2adb0: mov             x0, x1
    //     0xb2adb4: stur            x1, [fp, #-8]
    //     0xb2adb8: stur            x2, [fp, #-0x10]
    // 0xb2adbc: CheckStackOverflow
    //     0xb2adbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2adc0: cmp             SP, x16
    //     0xb2adc4: b.ls            #0xb2ae24
    // 0xb2adc8: mov             x1, x0
    // 0xb2adcc: r0 = _textIntrinsics()
    //     0xb2adcc: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb2add0: mov             x4, x0
    // 0xb2add4: ldur            x0, [fp, #-0x10]
    // 0xb2add8: stur            x4, [fp, #-0x18]
    // 0xb2addc: LoadField: d1 = r0->field_7
    //     0xb2addc: ldur            d1, [x0, #7]
    // 0xb2ade0: ldur            x1, [fp, #-8]
    // 0xb2ade4: mov             v0.16b, v1.16b
    // 0xb2ade8: stur            d1, [fp, #-0x20]
    // 0xb2adec: r2 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb2adec: add             x2, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb2adf0: ldr             x2, [x2, #0x700]
    // 0xb2adf4: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb2adf4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb2adf8: ldr             x3, [x3, #0x860]
    // 0xb2adfc: r0 = layoutInlineChildren()
    //     0xb2adfc: bl              #0xb1d4b8  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb2ae00: ldur            x1, [fp, #-0x18]
    // 0xb2ae04: mov             x2, x0
    // 0xb2ae08: r0 = setPlaceholderDimensions()
    //     0xb2ae08: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb2ae0c: ldur            x1, [fp, #-8]
    // 0xb2ae10: ldur            d0, [fp, #-0x20]
    // 0xb2ae14: r0 = _preferredHeight()
    //     0xb2ae14: bl              #0xb2aea4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_preferredHeight
    // 0xb2ae18: LeaveFrame
    //     0xb2ae18: mov             SP, fp
    //     0xb2ae1c: ldp             fp, lr, [SP], #0x10
    // 0xb2ae20: ret
    //     0xb2ae20: ret             
    // 0xb2ae24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ae24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ae28: b               #0xb2adc8
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2ae2c, size: 0x78
    // 0xb2ae2c: EnterFrame
    //     0xb2ae2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ae30: mov             fp, SP
    // 0xb2ae34: ldr             x0, [fp, #0x18]
    // 0xb2ae38: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2ae38: ldur            w1, [x0, #0x17]
    // 0xb2ae3c: DecompressPointer r1
    //     0xb2ae3c: add             x1, x1, HEAP, lsl #32
    // 0xb2ae40: CheckStackOverflow
    //     0xb2ae40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ae44: cmp             SP, x16
    //     0xb2ae48: b.ls            #0xb2ae8c
    // 0xb2ae4c: ldr             x2, [fp, #0x10]
    // 0xb2ae50: r0 = computeMaxIntrinsicHeight()
    //     0xb2ae50: bl              #0xb2ada4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::computeMaxIntrinsicHeight
    // 0xb2ae54: r0 = inline_Allocate_Double()
    //     0xb2ae54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2ae58: add             x0, x0, #0x10
    //     0xb2ae5c: cmp             x1, x0
    //     0xb2ae60: b.ls            #0xb2ae94
    //     0xb2ae64: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2ae68: sub             x0, x0, #0xf
    //     0xb2ae6c: mov             x1, #0xe19c
    //     0xb2ae70: movk            x1, #3, lsl #16
    //     0xb2ae74: stur            x1, [x0, #-1]
    // 0xb2ae78: dmb             ishst
    // 0xb2ae7c: StoreField: r0->field_7 = d0
    //     0xb2ae7c: stur            d0, [x0, #7]
    // 0xb2ae80: LeaveFrame
    //     0xb2ae80: mov             SP, fp
    //     0xb2ae84: ldp             fp, lr, [SP], #0x10
    // 0xb2ae88: ret
    //     0xb2ae88: ret             
    // 0xb2ae8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ae8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ae90: b               #0xb2ae4c
    // 0xb2ae94: SaveReg d0
    //     0xb2ae94: str             q0, [SP, #-0x10]!
    // 0xb2ae98: r0 = AllocateDouble()
    //     0xb2ae98: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2ae9c: RestoreReg d0
    //     0xb2ae9c: ldr             q0, [SP], #0x10
    // 0xb2aea0: b               #0xb2ae7c
  }
  _ _preferredHeight(/* No info */) {
    // ** addr: 0xb2aea4, size: 0x224
    // 0xb2aea4: EnterFrame
    //     0xb2aea4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2aea8: mov             fp, SP
    // 0xb2aeac: AllocStack(0x50)
    //     0xb2aeac: sub             SP, SP, #0x50
    // 0xb2aeb0: SetupParameters(RenderEditable this /* r1 => r0, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0xb2aeb0: mov             x0, x1
    //     0xb2aeb4: stur            x1, [fp, #-0x18]
    //     0xb2aeb8: stur            d0, [fp, #-0x30]
    // 0xb2aebc: CheckStackOverflow
    //     0xb2aebc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2aec0: cmp             SP, x16
    //     0xb2aec4: b.ls            #0xb2b0a0
    // 0xb2aec8: LoadField: r2 = r0->field_cb
    //     0xb2aec8: ldur            w2, [x0, #0xcb]
    // 0xb2aecc: DecompressPointer r2
    //     0xb2aecc: add             x2, x2, HEAP, lsl #32
    // 0xb2aed0: stur            x2, [fp, #-0x10]
    // 0xb2aed4: LoadField: r3 = r0->field_a7
    //     0xb2aed4: ldur            w3, [x0, #0xa7]
    // 0xb2aed8: DecompressPointer r3
    //     0xb2aed8: add             x3, x3, HEAP, lsl #32
    // 0xb2aedc: mov             x1, x3
    // 0xb2aee0: stur            x3, [fp, #-8]
    // 0xb2aee4: r0 = preferredLineHeight()
    //     0xb2aee4: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0xb2aee8: ldur            x0, [fp, #-0x10]
    // 0xb2aeec: cmp             w0, NULL
    // 0xb2aef0: b.ne            #0xb2aefc
    // 0xb2aef4: r1 = 0
    //     0xb2aef4: mov             x1, #0
    // 0xb2aef8: b               #0xb2af00
    // 0xb2aefc: r1 = LoadInt32Instr(r0)
    //     0xb2aefc: sbfx            x1, x0, #1, #0x1f
    // 0xb2af00: lsl             x2, x1, #1
    // 0xb2af04: r16 = LoadInt32Instr(r2)
    //     0xb2af04: sbfx            x16, x2, #1, #0x1f
    // 0xb2af08: scvtf           d1, w16
    // 0xb2af0c: fmul            d2, d0, d1
    // 0xb2af10: stur            d2, [fp, #-0x38]
    // 0xb2af14: cmp             w0, NULL
    // 0xb2af18: b.ne            #0xb2aff8
    // 0xb2af1c: ldur            d0, [fp, #-0x30]
    // 0xb2af20: d1 = inf
    //     0xb2af20: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2af24: fcmp            d0, d1
    // 0xb2af28: b.ne            #0xb2af64
    // 0xb2af2c: ldur            x1, [fp, #-8]
    // 0xb2af30: r0 = preferredLineHeight()
    //     0xb2af30: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0xb2af34: ldur            x1, [fp, #-8]
    // 0xb2af38: stur            d0, [fp, #-0x40]
    // 0xb2af3c: r0 = plainText()
    //     0xb2af3c: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0xb2af40: ldur            x1, [fp, #-0x18]
    // 0xb2af44: mov             x2, x0
    // 0xb2af48: r0 = _countHardLineBreaks()
    //     0xb2af48: bl              #0xb2b0c8  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_countHardLineBreaks
    // 0xb2af4c: add             x1, x0, #1
    // 0xb2af50: scvtf           d0, x1
    // 0xb2af54: ldur            d1, [fp, #-0x40]
    // 0xb2af58: fmul            d2, d1, d0
    // 0xb2af5c: mov             v0.16b, v2.16b
    // 0xb2af60: b               #0xb2afe0
    // 0xb2af64: r0 = inline_Allocate_Double()
    //     0xb2af64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2af68: add             x0, x0, #0x10
    //     0xb2af6c: cmp             x1, x0
    //     0xb2af70: b.ls            #0xb2b0a8
    //     0xb2af74: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2af78: sub             x0, x0, #0xf
    //     0xb2af7c: mov             x1, #0xe19c
    //     0xb2af80: movk            x1, #3, lsl #16
    //     0xb2af84: stur            x1, [x0, #-1]
    // 0xb2af88: dmb             ishst
    // 0xb2af8c: StoreField: r0->field_7 = d0
    //     0xb2af8c: stur            d0, [x0, #7]
    // 0xb2af90: str             x0, [SP]
    // 0xb2af94: ldur            x1, [fp, #-0x18]
    // 0xb2af98: r4 = const [0, 0x2, 0x1, 0x1, maxWidth, 0x1, null]
    //     0xb2af98: add             x4, PP, #0x22, lsl #12  ; [pp+0x22020] List(7) [0, 0x2, 0x1, 0x1, "maxWidth", 0x1, Null]
    //     0xb2af9c: ldr             x4, [x4, #0x20]
    // 0xb2afa0: r0 = _adjustConstraints()
    //     0xb2afa0: bl              #0x860b7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_adjustConstraints
    // 0xb2afa4: mov             x2, x0
    // 0xb2afa8: stur            x2, [fp, #-0x20]
    // 0xb2afac: mov             x3, x1
    // 0xb2afb0: ldur            x1, [fp, #-0x18]
    // 0xb2afb4: stur            x3, [fp, #-8]
    // 0xb2afb8: r0 = _textIntrinsics()
    //     0xb2afb8: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb2afbc: stur            x0, [fp, #-0x28]
    // 0xb2afc0: ldur            x16, [fp, #-0x20]
    // 0xb2afc4: ldur            lr, [fp, #-8]
    // 0xb2afc8: stp             lr, x16, [SP]
    // 0xb2afcc: mov             x1, x0
    // 0xb2afd0: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb2afd0: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb2afd4: r0 = layout()
    //     0xb2afd4: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb2afd8: ldur            x1, [fp, #-0x28]
    // 0xb2afdc: r0 = height()
    //     0xb2afdc: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0xb2afe0: ldur            d1, [fp, #-0x38]
    // 0xb2afe4: fmax            v2.2d, v0.2d, v1.2d
    // 0xb2afe8: mov             v0.16b, v2.16b
    // 0xb2afec: LeaveFrame
    //     0xb2afec: mov             SP, fp
    //     0xb2aff0: ldp             fp, lr, [SP], #0x10
    // 0xb2aff4: ret
    //     0xb2aff4: ret             
    // 0xb2aff8: ldur            d0, [fp, #-0x30]
    // 0xb2affc: mov             v1.16b, v2.16b
    // 0xb2b000: cmp             w0, #2
    // 0xb2b004: b.ne            #0xb2b090
    // 0xb2b008: r0 = inline_Allocate_Double()
    //     0xb2b008: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2b00c: add             x0, x0, #0x10
    //     0xb2b010: cmp             x1, x0
    //     0xb2b014: b.ls            #0xb2b0b8
    //     0xb2b018: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2b01c: sub             x0, x0, #0xf
    //     0xb2b020: mov             x1, #0xe19c
    //     0xb2b024: movk            x1, #3, lsl #16
    //     0xb2b028: stur            x1, [x0, #-1]
    // 0xb2b02c: dmb             ishst
    // 0xb2b030: StoreField: r0->field_7 = d0
    //     0xb2b030: stur            d0, [x0, #7]
    // 0xb2b034: str             x0, [SP]
    // 0xb2b038: ldur            x1, [fp, #-0x18]
    // 0xb2b03c: r4 = const [0, 0x2, 0x1, 0x1, maxWidth, 0x1, null]
    //     0xb2b03c: add             x4, PP, #0x22, lsl #12  ; [pp+0x22020] List(7) [0, 0x2, 0x1, 0x1, "maxWidth", 0x1, Null]
    //     0xb2b040: ldr             x4, [x4, #0x20]
    // 0xb2b044: r0 = _adjustConstraints()
    //     0xb2b044: bl              #0x860b7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_adjustConstraints
    // 0xb2b048: mov             x2, x0
    // 0xb2b04c: stur            x2, [fp, #-0x10]
    // 0xb2b050: mov             x3, x1
    // 0xb2b054: ldur            x1, [fp, #-0x18]
    // 0xb2b058: stur            x3, [fp, #-8]
    // 0xb2b05c: r0 = _textIntrinsics()
    //     0xb2b05c: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb2b060: stur            x0, [fp, #-0x18]
    // 0xb2b064: ldur            x16, [fp, #-0x10]
    // 0xb2b068: ldur            lr, [fp, #-8]
    // 0xb2b06c: stp             lr, x16, [SP]
    // 0xb2b070: mov             x1, x0
    // 0xb2b074: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb2b074: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb2b078: r0 = layout()
    //     0xb2b078: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb2b07c: ldur            x1, [fp, #-0x18]
    // 0xb2b080: r0 = height()
    //     0xb2b080: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0xb2b084: LeaveFrame
    //     0xb2b084: mov             SP, fp
    //     0xb2b088: ldp             fp, lr, [SP], #0x10
    // 0xb2b08c: ret
    //     0xb2b08c: ret             
    // 0xb2b090: mov             v0.16b, v1.16b
    // 0xb2b094: LeaveFrame
    //     0xb2b094: mov             SP, fp
    //     0xb2b098: ldp             fp, lr, [SP], #0x10
    // 0xb2b09c: ret
    //     0xb2b09c: ret             
    // 0xb2b0a0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2b0a0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2b0a4: b               #0xb2aec8
    // 0xb2b0a8: SaveReg d0
    //     0xb2b0a8: str             q0, [SP, #-0x10]!
    // 0xb2b0ac: r0 = AllocateDouble()
    //     0xb2b0ac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2b0b0: RestoreReg d0
    //     0xb2b0b0: ldr             q0, [SP], #0x10
    // 0xb2b0b4: b               #0xb2af8c
    // 0xb2b0b8: SaveReg d0
    //     0xb2b0b8: str             q0, [SP, #-0x10]!
    // 0xb2b0bc: r0 = AllocateDouble()
    //     0xb2b0bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2b0c0: RestoreReg d0
    //     0xb2b0c0: ldr             q0, [SP], #0x10
    // 0xb2b0c4: b               #0xb2b030
  }
  _ _countHardLineBreaks(/* No info */) {
    // ** addr: 0xb2b0c8, size: 0x14c
    // 0xb2b0c8: EnterFrame
    //     0xb2b0c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2b0cc: mov             fp, SP
    // 0xb2b0d0: mov             x3, x1
    // 0xb2b0d4: r17 = 279
    //     0xb2b0d4: mov             x17, #0x117
    // 0xb2b0d8: ldr             w4, [x3, x17]
    // 0xb2b0dc: DecompressPointer r4
    //     0xb2b0dc: add             x4, x4, HEAP, lsl #32
    // 0xb2b0e0: cmp             w4, NULL
    // 0xb2b0e4: b.eq            #0xb2b100
    // 0xb2b0e8: r0 = LoadInt32Instr(r4)
    //     0xb2b0e8: sbfx            x0, x4, #1, #0x1f
    //     0xb2b0ec: tbz             w4, #0, #0xb2b0f4
    //     0xb2b0f0: ldur            x0, [x4, #7]
    // 0xb2b0f4: LeaveFrame
    //     0xb2b0f4: mov             SP, fp
    //     0xb2b0f8: ldp             fp, lr, [SP], #0x10
    // 0xb2b0fc: ret
    //     0xb2b0fc: ret             
    // 0xb2b100: LoadField: r4 = r2->field_7
    //     0xb2b100: ldur            w4, [x2, #7]
    // 0xb2b104: r5 = LoadInt32Instr(r4)
    //     0xb2b104: sbfx            x5, x4, #1, #0x1f
    // 0xb2b108: r4 = LoadClassIdInstr(r2)
    //     0xb2b108: ldur            x4, [x2, #-1]
    //     0xb2b10c: ubfx            x4, x4, #0xc, #0x14
    // 0xb2b110: lsl             x4, x4, #1
    // 0xb2b114: r7 = 0
    //     0xb2b114: mov             x7, #0
    // 0xb2b118: r6 = 0
    //     0xb2b118: mov             x6, #0
    // 0xb2b11c: CheckStackOverflow
    //     0xb2b11c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2b120: cmp             SP, x16
    //     0xb2b124: b.ls            #0xb2b20c
    // 0xb2b128: cmp             x6, x5
    // 0xb2b12c: b.ge            #0xb2b1c4
    // 0xb2b130: cmp             w4, #0xbc
    // 0xb2b134: b.ne            #0xb2b144
    // 0xb2b138: ArrayLoad: r8 = r2[r6]  ; TypedUnsigned_1
    //     0xb2b138: add             x16, x2, x6
    //     0xb2b13c: ldrb            w8, [x16, #0xf]
    // 0xb2b140: b               #0xb2b14c
    // 0xb2b144: add             x16, x2, x6, lsl #1
    // 0xb2b148: ldurh           w8, [x16, #0xf]
    // 0xb2b14c: cmp             x8, #0xc
    // 0xb2b150: b.gt            #0xb2b174
    // 0xb2b154: cmp             x8, #0xb
    // 0xb2b158: b.gt            #0xb2b1b0
    // 0xb2b15c: cmp             x8, #0xa
    // 0xb2b160: b.gt            #0xb2b1b0
    // 0xb2b164: lsl             x9, x8, #1
    // 0xb2b168: cmp             w9, #0x14
    // 0xb2b16c: b.ne            #0xb2b1b8
    // 0xb2b170: b               #0xb2b1b0
    // 0xb2b174: cmp             x8, #0x85
    // 0xb2b178: b.lt            #0xb2b1b8
    // 0xb2b17c: r17 = 8232
    //     0xb2b17c: mov             x17, #0x2028
    // 0xb2b180: cmp             x8, x17
    // 0xb2b184: b.gt            #0xb2b1a0
    // 0xb2b188: cmp             x8, #0x85
    // 0xb2b18c: b.le            #0xb2b1b0
    // 0xb2b190: r17 = 8232
    //     0xb2b190: mov             x17, #0x2028
    // 0xb2b194: cmp             x8, x17
    // 0xb2b198: b.lt            #0xb2b1b8
    // 0xb2b19c: b               #0xb2b1b0
    // 0xb2b1a0: lsl             x9, x8, #1
    // 0xb2b1a4: r17 = 16466
    //     0xb2b1a4: mov             x17, #0x4052
    // 0xb2b1a8: cmp             w9, w17
    // 0xb2b1ac: b.ne            #0xb2b1b8
    // 0xb2b1b0: add             x8, x7, #1
    // 0xb2b1b4: mov             x7, x8
    // 0xb2b1b8: add             x0, x6, #1
    // 0xb2b1bc: mov             x6, x0
    // 0xb2b1c0: b               #0xb2b11c
    // 0xb2b1c4: r0 = BoxInt64Instr(r7)
    //     0xb2b1c4: sbfiz           x0, x7, #1, #0x1f
    //     0xb2b1c8: cmp             x7, x0, asr #1
    //     0xb2b1cc: b.eq            #0xb2b1d8
    //     0xb2b1d0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb2b1d4: stur            x7, [x0, #7]
    // 0xb2b1d8: r17 = 279
    //     0xb2b1d8: mov             x17, #0x117
    // 0xb2b1dc: str             w0, [x3, x17]
    // 0xb2b1e0: branchIfSmi(r0, 0xb2b1fc)
    //     0xb2b1e0: tbz             w0, #0, #0xb2b1fc
    // 0xb2b1e4: WriteBarrierInstr(obj = r3, val = r0)
    //     0xb2b1e4: ldurb           w16, [x3, #-1]
    //     0xb2b1e8: ldurb           w17, [x0, #-1]
    //     0xb2b1ec: and             x16, x17, x16, lsr #2
    //     0xb2b1f0: tst             x16, HEAP, lsr #32
    //     0xb2b1f4: b.eq            #0xb2b1fc
    //     0xb2b1f8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb2b1fc: mov             x0, x7
    // 0xb2b200: LeaveFrame
    //     0xb2b200: mov             SP, fp
    //     0xb2b204: ldp             fp, lr, [SP], #0x10
    // 0xb2b208: ret
    //     0xb2b208: ret             
    // 0xb2b20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2b20c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2b210: b               #0xb2b128
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2e46c, size: 0xcc
    // 0xb2e46c: EnterFrame
    //     0xb2e46c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e470: mov             fp, SP
    // 0xb2e474: AllocStack(0x30)
    //     0xb2e474: sub             SP, SP, #0x30
    // 0xb2e478: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xb2e478: mov             x0, x1
    //     0xb2e47c: stur            x1, [fp, #-8]
    // 0xb2e480: CheckStackOverflow
    //     0xb2e480: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e484: cmp             SP, x16
    //     0xb2e488: b.ls            #0xb2e530
    // 0xb2e48c: r1 = Function '<anonymous closure>':.
    //     0xb2e48c: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd678] AnonymousClosure: (0xb2e654), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMaxIntrinsicWidth (0xb2ebe0)
    //     0xb2e490: ldr             x1, [x1, #0x678]
    // 0xb2e494: r2 = Null
    //     0xb2e494: mov             x2, NULL
    // 0xb2e498: r0 = AllocateClosure()
    //     0xb2e498: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2e49c: ldur            x1, [fp, #-8]
    // 0xb2e4a0: mov             x2, x0
    // 0xb2e4a4: d0 = inf
    //     0xb2e4a4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2e4a8: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb2e4a8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb2e4ac: ldr             x3, [x3, #0x860]
    // 0xb2e4b0: r0 = layoutInlineChildren()
    //     0xb2e4b0: bl              #0xb1d4b8  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb2e4b4: ldur            x1, [fp, #-8]
    // 0xb2e4b8: stur            x0, [fp, #-0x10]
    // 0xb2e4bc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb2e4bc: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb2e4c0: r0 = _adjustConstraints()
    //     0xb2e4c0: bl              #0x860b7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_adjustConstraints
    // 0xb2e4c4: mov             x2, x0
    // 0xb2e4c8: stur            x2, [fp, #-0x20]
    // 0xb2e4cc: mov             x3, x1
    // 0xb2e4d0: ldur            x1, [fp, #-8]
    // 0xb2e4d4: stur            x3, [fp, #-0x18]
    // 0xb2e4d8: r0 = _textIntrinsics()
    //     0xb2e4d8: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb2e4dc: mov             x1, x0
    // 0xb2e4e0: ldur            x2, [fp, #-0x10]
    // 0xb2e4e4: stur            x0, [fp, #-0x10]
    // 0xb2e4e8: r0 = setPlaceholderDimensions()
    //     0xb2e4e8: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb2e4ec: ldur            x16, [fp, #-0x20]
    // 0xb2e4f0: ldur            lr, [fp, #-0x18]
    // 0xb2e4f4: stp             lr, x16, [SP]
    // 0xb2e4f8: ldur            x1, [fp, #-0x10]
    // 0xb2e4fc: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb2e4fc: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb2e500: r0 = layout()
    //     0xb2e500: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb2e504: ldur            x1, [fp, #-0x10]
    // 0xb2e508: r0 = maxIntrinsicWidth()
    //     0xb2e508: bl              #0xb2e5b0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::maxIntrinsicWidth
    // 0xb2e50c: ldur            x0, [fp, #-8]
    // 0xb2e510: LoadField: d1 = r0->field_df
    //     0xb2e510: ldur            d1, [x0, #0xdf]
    // 0xb2e514: d2 = 1.000000
    //     0xb2e514: fmov            d2, #1.00000000
    // 0xb2e518: fadd            d3, d1, d2
    // 0xb2e51c: fadd            d1, d0, d3
    // 0xb2e520: mov             v0.16b, v1.16b
    // 0xb2e524: LeaveFrame
    //     0xb2e524: mov             SP, fp
    //     0xb2e528: ldp             fp, lr, [SP], #0x10
    // 0xb2e52c: ret
    //     0xb2e52c: ret             
    // 0xb2e530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e530: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e534: b               #0xb2e48c
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2e538, size: 0x78
    // 0xb2e538: EnterFrame
    //     0xb2e538: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e53c: mov             fp, SP
    // 0xb2e540: ldr             x0, [fp, #0x18]
    // 0xb2e544: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2e544: ldur            w1, [x0, #0x17]
    // 0xb2e548: DecompressPointer r1
    //     0xb2e548: add             x1, x1, HEAP, lsl #32
    // 0xb2e54c: CheckStackOverflow
    //     0xb2e54c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e550: cmp             SP, x16
    //     0xb2e554: b.ls            #0xb2e598
    // 0xb2e558: ldr             x2, [fp, #0x10]
    // 0xb2e55c: r0 = computeMaxIntrinsicWidth()
    //     0xb2e55c: bl              #0xb2e46c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::computeMaxIntrinsicWidth
    // 0xb2e560: r0 = inline_Allocate_Double()
    //     0xb2e560: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2e564: add             x0, x0, #0x10
    //     0xb2e568: cmp             x1, x0
    //     0xb2e56c: b.ls            #0xb2e5a0
    //     0xb2e570: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2e574: sub             x0, x0, #0xf
    //     0xb2e578: mov             x1, #0xe19c
    //     0xb2e57c: movk            x1, #3, lsl #16
    //     0xb2e580: stur            x1, [x0, #-1]
    // 0xb2e584: dmb             ishst
    // 0xb2e588: StoreField: r0->field_7 = d0
    //     0xb2e588: stur            d0, [x0, #7]
    // 0xb2e58c: LeaveFrame
    //     0xb2e58c: mov             SP, fp
    //     0xb2e590: ldp             fp, lr, [SP], #0x10
    // 0xb2e594: ret
    //     0xb2e594: ret             
    // 0xb2e598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e598: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e59c: b               #0xb2e558
    // 0xb2e5a0: SaveReg d0
    //     0xb2e5a0: str             q0, [SP, #-0x10]!
    // 0xb2e5a4: r0 = AllocateDouble()
    //     0xb2e5a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2e5a8: RestoreReg d0
    //     0xb2e5a8: ldr             q0, [SP], #0x10
    // 0xb2e5ac: b               #0xb2e588
  }
  _ startVerticalCaretMovement(/* No info */) {
    // ** addr: 0xb31e0c, size: 0x98
    // 0xb31e0c: EnterFrame
    //     0xb31e0c: stp             fp, lr, [SP, #-0x10]!
    //     0xb31e10: mov             fp, SP
    // 0xb31e14: AllocStack(0x28)
    //     0xb31e14: sub             SP, SP, #0x28
    // 0xb31e18: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb31e18: mov             x0, x1
    //     0xb31e1c: stur            x1, [fp, #-8]
    //     0xb31e20: stur            x2, [fp, #-0x10]
    // 0xb31e24: CheckStackOverflow
    //     0xb31e24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb31e28: cmp             SP, x16
    //     0xb31e2c: b.ls            #0xb31e9c
    // 0xb31e30: LoadField: r1 = r0->field_a7
    //     0xb31e30: ldur            w1, [x0, #0xa7]
    // 0xb31e34: DecompressPointer r1
    //     0xb31e34: add             x1, x1, HEAP, lsl #32
    // 0xb31e38: r0 = computeLineMetrics()
    //     0xb31e38: bl              #0xb3234c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeLineMetrics
    // 0xb31e3c: ldur            x1, [fp, #-8]
    // 0xb31e40: ldur            x2, [fp, #-0x10]
    // 0xb31e44: mov             x3, x0
    // 0xb31e48: stur            x0, [fp, #-0x18]
    // 0xb31e4c: r0 = _lineNumberFor()
    //     0xb31e4c: bl              #0xb32090  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_lineNumberFor
    // 0xb31e50: LoadField: r6 = r0->field_b
    //     0xb31e50: ldur            w6, [x0, #0xb]
    // 0xb31e54: DecompressPointer r6
    //     0xb31e54: add             x6, x6, HEAP, lsl #32
    // 0xb31e58: stur            x6, [fp, #-0x28]
    // 0xb31e5c: LoadField: r7 = r0->field_f
    //     0xb31e5c: ldur            w7, [x0, #0xf]
    // 0xb31e60: DecompressPointer r7
    //     0xb31e60: add             x7, x7, HEAP, lsl #32
    // 0xb31e64: stur            x7, [fp, #-0x20]
    // 0xb31e68: r0 = VerticalCaretMovementRun()
    //     0xb31e68: bl              #0xb32084  ; AllocateVerticalCaretMovementRunStub -> VerticalCaretMovementRun (size=0x28)
    // 0xb31e6c: mov             x1, x0
    // 0xb31e70: ldur            x2, [fp, #-8]
    // 0xb31e74: ldur            x3, [fp, #-0x18]
    // 0xb31e78: ldur            x5, [fp, #-0x10]
    // 0xb31e7c: ldur            x6, [fp, #-0x28]
    // 0xb31e80: ldur            x7, [fp, #-0x20]
    // 0xb31e84: stur            x0, [fp, #-8]
    // 0xb31e88: r0 = VerticalCaretMovementRun._()
    //     0xb31e88: bl              #0xb31ea4  ; [package:flutter/src/rendering/editable.dart] VerticalCaretMovementRun::VerticalCaretMovementRun._
    // 0xb31e8c: ldur            x0, [fp, #-8]
    // 0xb31e90: LeaveFrame
    //     0xb31e90: mov             SP, fp
    //     0xb31e94: ldp             fp, lr, [SP], #0x10
    // 0xb31e98: ret
    //     0xb31e98: ret             
    // 0xb31e9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb31e9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb31ea0: b               #0xb31e30
  }
  _ _lineNumberFor(/* No info */) {
    // ** addr: 0xb32090, size: 0x2bc
    // 0xb32090: EnterFrame
    //     0xb32090: stp             fp, lr, [SP, #-0x10]!
    //     0xb32094: mov             fp, SP
    // 0xb32098: AllocStack(0x40)
    //     0xb32098: sub             SP, SP, #0x40
    // 0xb3209c: SetupParameters(dynamic _ /* r3 => r0, fp-0x8 */)
    //     0xb3209c: mov             x0, x3
    //     0xb320a0: stur            x3, [fp, #-8]
    // 0xb320a4: CheckStackOverflow
    //     0xb320a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb320a8: cmp             SP, x16
    //     0xb320ac: b.ls            #0xb3233c
    // 0xb320b0: LoadField: r3 = r1->field_a7
    //     0xb320b0: ldur            w3, [x1, #0xa7]
    // 0xb320b4: DecompressPointer r3
    //     0xb320b4: add             x3, x3, HEAP, lsl #32
    // 0xb320b8: mov             x1, x3
    // 0xb320bc: r3 = Instance_Rect
    //     0xb320bc: ldr             x3, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0xb320c0: r0 = getOffsetForCaret()
    //     0xb320c0: bl              #0x85dc3c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetForCaret
    // 0xb320c4: mov             x3, x0
    // 0xb320c8: ldur            x2, [fp, #-8]
    // 0xb320cc: stur            x3, [fp, #-0x10]
    // 0xb320d0: r0 = LoadClassIdInstr(r2)
    //     0xb320d0: ldur            x0, [x2, #-1]
    //     0xb320d4: ubfx            x0, x0, #0xc, #0x14
    // 0xb320d8: mov             x1, x2
    // 0xb320dc: r0 = GDT[cid_x0 + 0x12641]()
    //     0xb320dc: mov             x17, #0x2641
    //     0xb320e0: movk            x17, #1, lsl #16
    //     0xb320e4: add             lr, x0, x17
    //     0xb320e8: ldr             lr, [x21, lr, lsl #3]
    //     0xb320ec: blr             lr
    // 0xb320f0: mov             x3, x0
    // 0xb320f4: ldur            x2, [fp, #-0x10]
    // 0xb320f8: stur            x3, [fp, #-0x18]
    // 0xb320fc: LoadField: d0 = r2->field_f
    //     0xb320fc: ldur            d0, [x2, #0xf]
    // 0xb32100: stur            d0, [fp, #-0x30]
    // 0xb32104: CheckStackOverflow
    //     0xb32104: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb32108: cmp             SP, x16
    //     0xb3210c: b.ls            #0xb32344
    // 0xb32110: r0 = LoadClassIdInstr(r3)
    //     0xb32110: ldur            x0, [x3, #-1]
    //     0xb32114: ubfx            x0, x0, #0xc, #0x14
    // 0xb32118: mov             x1, x3
    // 0xb3211c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xb3211c: mov             x17, #0x845b
    //     0xb32120: movk            x17, #1, lsl #16
    //     0xb32124: add             lr, x0, x17
    //     0xb32128: ldr             lr, [x21, lr, lsl #3]
    //     0xb3212c: blr             lr
    // 0xb32130: tbnz            w0, #4, #0xb321fc
    // 0xb32134: ldur            x2, [fp, #-0x18]
    // 0xb32138: ldur            d0, [fp, #-0x30]
    // 0xb3213c: r0 = LoadClassIdInstr(r2)
    //     0xb3213c: ldur            x0, [x2, #-1]
    //     0xb32140: ubfx            x0, x0, #0xc, #0x14
    // 0xb32144: mov             x1, x2
    // 0xb32148: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xb32148: mov             x17, #0x7d4c
    //     0xb3214c: movk            x17, #1, lsl #16
    //     0xb32150: add             lr, x0, x17
    //     0xb32154: ldr             lr, [x21, lr, lsl #3]
    //     0xb32158: blr             lr
    // 0xb3215c: LoadField: d0 = r0->field_3b
    //     0xb3215c: ldur            d0, [x0, #0x3b]
    // 0xb32160: ldur            d1, [fp, #-0x30]
    // 0xb32164: stur            d0, [fp, #-0x38]
    // 0xb32168: fcmp            d0, d1
    // 0xb3216c: b.gt            #0xb32180
    // 0xb32170: ldur            x2, [fp, #-0x10]
    // 0xb32174: ldur            x3, [fp, #-0x18]
    // 0xb32178: mov             v0.16b, v1.16b
    // 0xb3217c: b               #0xb32104
    // 0xb32180: ldur            x1, [fp, #-0x10]
    // 0xb32184: LoadField: r2 = r0->field_43
    //     0xb32184: ldur            x2, [x0, #0x43]
    // 0xb32188: stur            x2, [fp, #-0x20]
    // 0xb3218c: LoadField: d1 = r1->field_7
    //     0xb3218c: ldur            d1, [x1, #7]
    // 0xb32190: stur            d1, [fp, #-0x30]
    // 0xb32194: r0 = Offset()
    //     0xb32194: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb32198: mov             x2, x0
    // 0xb3219c: ldur            d0, [fp, #-0x30]
    // 0xb321a0: stur            x2, [fp, #-0x28]
    // 0xb321a4: StoreField: r2->field_7 = d0
    //     0xb321a4: stur            d0, [x2, #7]
    // 0xb321a8: ldur            d0, [fp, #-0x38]
    // 0xb321ac: StoreField: r2->field_f = d0
    //     0xb321ac: stur            d0, [x2, #0xf]
    // 0xb321b0: ldur            x3, [fp, #-0x20]
    // 0xb321b4: r0 = BoxInt64Instr(r3)
    //     0xb321b4: sbfiz           x0, x3, #1, #0x1f
    //     0xb321b8: cmp             x3, x0, asr #1
    //     0xb321bc: b.eq            #0xb321c8
    //     0xb321c0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb321c4: stur            x3, [x0, #7]
    // 0xb321c8: r1 = <int, Offset>
    //     0xb321c8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15540] TypeArguments: <int, Offset>
    //     0xb321cc: ldr             x1, [x1, #0x540]
    // 0xb321d0: stur            x0, [fp, #-0x18]
    // 0xb321d4: r0 = MapEntry()
    //     0xb321d4: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xb321d8: mov             x1, x0
    // 0xb321dc: ldur            x0, [fp, #-0x18]
    // 0xb321e0: StoreField: r1->field_b = r0
    //     0xb321e0: stur            w0, [x1, #0xb]
    // 0xb321e4: ldur            x0, [fp, #-0x28]
    // 0xb321e8: StoreField: r1->field_f = r0
    //     0xb321e8: stur            w0, [x1, #0xf]
    // 0xb321ec: mov             x0, x1
    // 0xb321f0: LeaveFrame
    //     0xb321f0: mov             SP, fp
    //     0xb321f4: ldp             fp, lr, [SP], #0x10
    // 0xb321f8: ret
    //     0xb321f8: ret             
    // 0xb321fc: ldur            x2, [fp, #-8]
    // 0xb32200: ldur            x1, [fp, #-0x10]
    // 0xb32204: r0 = LoadClassIdInstr(r2)
    //     0xb32204: ldur            x0, [x2, #-1]
    //     0xb32208: ubfx            x0, x0, #0xc, #0x14
    // 0xb3220c: str             x2, [SP]
    // 0xb32210: r0 = GDT[cid_x0 + 0xf078]()
    //     0xb32210: mov             x17, #0xf078
    //     0xb32214: add             lr, x0, x17
    //     0xb32218: ldr             lr, [x21, lr, lsl #3]
    //     0xb3221c: blr             lr
    // 0xb32220: r1 = LoadInt32Instr(r0)
    //     0xb32220: sbfx            x1, x0, #1, #0x1f
    // 0xb32224: sub             x0, x1, #1
    // 0xb32228: r1 = 0
    //     0xb32228: mov             x1, #0
    // 0xb3222c: cmp             x1, x0
    // 0xb32230: csel            x2, x0, x1, lt
    // 0xb32234: ldur            x0, [fp, #-0x10]
    // 0xb32238: stur            x2, [fp, #-0x20]
    // 0xb3223c: LoadField: d0 = r0->field_7
    //     0xb3223c: ldur            d0, [x0, #7]
    // 0xb32240: ldur            x3, [fp, #-8]
    // 0xb32244: stur            d0, [fp, #-0x30]
    // 0xb32248: r0 = LoadClassIdInstr(r3)
    //     0xb32248: ldur            x0, [x3, #-1]
    //     0xb3224c: ubfx            x0, x0, #0xc, #0x14
    // 0xb32250: mov             x1, x3
    // 0xb32254: r0 = GDT[cid_x0 + 0x131a1]()
    //     0xb32254: mov             x17, #0x31a1
    //     0xb32258: movk            x17, #1, lsl #16
    //     0xb3225c: add             lr, x0, x17
    //     0xb32260: ldr             lr, [x21, lr, lsl #3]
    //     0xb32264: blr             lr
    // 0xb32268: tbnz            w0, #4, #0xb322cc
    // 0xb3226c: ldur            x2, [fp, #-8]
    // 0xb32270: r0 = LoadClassIdInstr(r2)
    //     0xb32270: ldur            x0, [x2, #-1]
    //     0xb32274: ubfx            x0, x0, #0xc, #0x14
    // 0xb32278: mov             x1, x2
    // 0xb3227c: r0 = GDT[cid_x0 + 0x140c8]()
    //     0xb3227c: mov             x17, #0x40c8
    //     0xb32280: movk            x17, #1, lsl #16
    //     0xb32284: add             lr, x0, x17
    //     0xb32288: ldr             lr, [x21, lr, lsl #3]
    //     0xb3228c: blr             lr
    // 0xb32290: LoadField: d0 = r0->field_3b
    //     0xb32290: ldur            d0, [x0, #0x3b]
    // 0xb32294: ldur            x1, [fp, #-8]
    // 0xb32298: stur            d0, [fp, #-0x38]
    // 0xb3229c: r0 = LoadClassIdInstr(r1)
    //     0xb3229c: ldur            x0, [x1, #-1]
    //     0xb322a0: ubfx            x0, x0, #0xc, #0x14
    // 0xb322a4: r0 = GDT[cid_x0 + 0x140c8]()
    //     0xb322a4: mov             x17, #0x40c8
    //     0xb322a8: movk            x17, #1, lsl #16
    //     0xb322ac: add             lr, x0, x17
    //     0xb322b0: ldr             lr, [x21, lr, lsl #3]
    //     0xb322b4: blr             lr
    // 0xb322b8: LoadField: d0 = r0->field_13
    //     0xb322b8: ldur            d0, [x0, #0x13]
    // 0xb322bc: ldur            d1, [fp, #-0x38]
    // 0xb322c0: fadd            d2, d1, d0
    // 0xb322c4: mov             v1.16b, v2.16b
    // 0xb322c8: b               #0xb322d0
    // 0xb322cc: d1 = 0.000000
    //     0xb322cc: eor             v1.16b, v1.16b, v1.16b
    // 0xb322d0: ldur            x0, [fp, #-0x20]
    // 0xb322d4: ldur            d0, [fp, #-0x30]
    // 0xb322d8: stur            d1, [fp, #-0x38]
    // 0xb322dc: r0 = Offset()
    //     0xb322dc: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb322e0: mov             x2, x0
    // 0xb322e4: ldur            d0, [fp, #-0x30]
    // 0xb322e8: stur            x2, [fp, #-0x10]
    // 0xb322ec: StoreField: r2->field_7 = d0
    //     0xb322ec: stur            d0, [x2, #7]
    // 0xb322f0: ldur            d0, [fp, #-0x38]
    // 0xb322f4: StoreField: r2->field_f = d0
    //     0xb322f4: stur            d0, [x2, #0xf]
    // 0xb322f8: ldur            x3, [fp, #-0x20]
    // 0xb322fc: r0 = BoxInt64Instr(r3)
    //     0xb322fc: sbfiz           x0, x3, #1, #0x1f
    //     0xb32300: cmp             x3, x0, asr #1
    //     0xb32304: b.eq            #0xb32310
    //     0xb32308: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb3230c: stur            x3, [x0, #7]
    // 0xb32310: r1 = <int, Offset>
    //     0xb32310: add             x1, PP, #0x15, lsl #12  ; [pp+0x15540] TypeArguments: <int, Offset>
    //     0xb32314: ldr             x1, [x1, #0x540]
    // 0xb32318: stur            x0, [fp, #-8]
    // 0xb3231c: r0 = MapEntry()
    //     0xb3231c: bl              #0x8027cc  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0xb32320: ldur            x1, [fp, #-8]
    // 0xb32324: StoreField: r0->field_b = r1
    //     0xb32324: stur            w1, [x0, #0xb]
    // 0xb32328: ldur            x1, [fp, #-0x10]
    // 0xb3232c: StoreField: r0->field_f = r1
    //     0xb3232c: stur            w1, [x0, #0xf]
    // 0xb32330: LeaveFrame
    //     0xb32330: mov             SP, fp
    //     0xb32334: ldp             fp, lr, [SP], #0x10
    // 0xb32338: ret
    //     0xb32338: ret             
    // 0xb3233c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb3233c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb32340: b               #0xb320b0
    // 0xb32344: r0 = StackOverflowSharedWithFPURegs()
    //     0xb32344: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb32348: b               #0xb32110
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb51604, size: 0x25c
    // 0xb51604: EnterFrame
    //     0xb51604: stp             fp, lr, [SP, #-0x10]!
    //     0xb51608: mov             fp, SP
    // 0xb5160c: AllocStack(0x48)
    //     0xb5160c: sub             SP, SP, #0x48
    // 0xb51610: SetupParameters(RenderEditable this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb51610: mov             x0, x2
    //     0xb51614: stur            x2, [fp, #-0x10]
    //     0xb51618: mov             x2, x1
    //     0xb5161c: stur            x1, [fp, #-8]
    // 0xb51620: CheckStackOverflow
    //     0xb51620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb51624: cmp             SP, x16
    //     0xb51628: b.ls            #0xb517ec
    // 0xb5162c: LoadField: d0 = r0->field_7
    //     0xb5162c: ldur            d0, [x0, #7]
    // 0xb51630: LoadField: d1 = r0->field_f
    //     0xb51630: ldur            d1, [x0, #0xf]
    // 0xb51634: stur            d1, [fp, #-0x30]
    // 0xb51638: r1 = inline_Allocate_Double()
    //     0xb51638: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xb5163c: add             x1, x1, #0x10
    //     0xb51640: cmp             x3, x1
    //     0xb51644: b.ls            #0xb517f4
    //     0xb51648: str             x1, [THR, #0x60]  ; THR::top
    //     0xb5164c: sub             x1, x1, #0xf
    //     0xb51650: mov             x3, #0xe19c
    //     0xb51654: movk            x3, #3, lsl #16
    //     0xb51658: stur            x3, [x1, #-1]
    // 0xb5165c: dmb             ishst
    // 0xb51660: StoreField: r1->field_7 = d0
    //     0xb51660: stur            d0, [x1, #7]
    // 0xb51664: r3 = inline_Allocate_Double()
    //     0xb51664: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb51668: add             x3, x3, #0x10
    //     0xb5166c: cmp             x4, x3
    //     0xb51670: b.ls            #0xb51810
    //     0xb51674: str             x3, [THR, #0x60]  ; THR::top
    //     0xb51678: sub             x3, x3, #0xf
    //     0xb5167c: mov             x4, #0xe19c
    //     0xb51680: movk            x4, #3, lsl #16
    //     0xb51684: stur            x4, [x3, #-1]
    // 0xb51688: dmb             ishst
    // 0xb5168c: StoreField: r3->field_7 = d1
    //     0xb5168c: stur            d1, [x3, #7]
    // 0xb51690: stp             x3, x1, [SP]
    // 0xb51694: mov             x1, x2
    // 0xb51698: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb51698: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb5169c: r0 = _adjustConstraints()
    //     0xb5169c: bl              #0x860b7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_adjustConstraints
    // 0xb516a0: mov             x2, x0
    // 0xb516a4: stur            x2, [fp, #-0x20]
    // 0xb516a8: mov             x3, x1
    // 0xb516ac: ldur            x1, [fp, #-8]
    // 0xb516b0: stur            x3, [fp, #-0x18]
    // 0xb516b4: r0 = _textIntrinsics()
    //     0xb516b4: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb516b8: ldur            x1, [fp, #-8]
    // 0xb516bc: ldur            d0, [fp, #-0x30]
    // 0xb516c0: r2 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb516c0: add             x2, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb516c4: ldr             x2, [x2, #0x700]
    // 0xb516c8: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb516c8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb516cc: ldr             x3, [x3, #0x860]
    // 0xb516d0: stur            x0, [fp, #-0x28]
    // 0xb516d4: r0 = layoutInlineChildren()
    //     0xb516d4: bl              #0xb1d4b8  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb516d8: ldur            x1, [fp, #-0x28]
    // 0xb516dc: mov             x2, x0
    // 0xb516e0: r0 = setPlaceholderDimensions()
    //     0xb516e0: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb516e4: ldur            x16, [fp, #-0x20]
    // 0xb516e8: ldur            lr, [fp, #-0x18]
    // 0xb516ec: stp             lr, x16, [SP]
    // 0xb516f0: ldur            x1, [fp, #-0x28]
    // 0xb516f4: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb516f4: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb516f8: r0 = layout()
    //     0xb516f8: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb516fc: ldur            x0, [fp, #-8]
    // 0xb51700: LoadField: r1 = r0->field_c3
    //     0xb51700: ldur            w1, [x0, #0xc3]
    // 0xb51704: DecompressPointer r1
    //     0xb51704: add             x1, x1, HEAP, lsl #32
    // 0xb51708: tbnz            w1, #4, #0xb51714
    // 0xb5170c: ldur            d1, [fp, #-0x30]
    // 0xb51710: b               #0xb5177c
    // 0xb51714: mov             x1, x0
    // 0xb51718: r0 = _textIntrinsics()
    //     0xb51718: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb5171c: mov             x1, x0
    // 0xb51720: r0 = size()
    //     0xb51720: bl              #0x859c64  ; [package:flutter/src/painting/text_painter.dart] TextPainter::size
    // 0xb51724: LoadField: d0 = r0->field_7
    //     0xb51724: ldur            d0, [x0, #7]
    // 0xb51728: ldur            x0, [fp, #-8]
    // 0xb5172c: LoadField: d1 = r0->field_df
    //     0xb5172c: ldur            d1, [x0, #0xdf]
    // 0xb51730: d2 = 1.000000
    //     0xb51730: fmov            d2, #1.00000000
    // 0xb51734: fadd            d3, d1, d2
    // 0xb51738: fadd            d1, d0, d3
    // 0xb5173c: r1 = inline_Allocate_Double()
    //     0xb5173c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb51740: add             x1, x1, #0x10
    //     0xb51744: cmp             x2, x1
    //     0xb51748: b.ls            #0xb51834
    //     0xb5174c: str             x1, [THR, #0x60]  ; THR::top
    //     0xb51750: sub             x1, x1, #0xf
    //     0xb51754: mov             x2, #0xe19c
    //     0xb51758: movk            x2, #3, lsl #16
    //     0xb5175c: stur            x2, [x1, #-1]
    // 0xb51760: dmb             ishst
    // 0xb51764: StoreField: r1->field_7 = d1
    //     0xb51764: stur            d1, [x1, #7]
    // 0xb51768: str             x1, [SP]
    // 0xb5176c: ldur            x1, [fp, #-0x10]
    // 0xb51770: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb51770: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb51774: r0 = constrainWidth()
    //     0xb51774: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb51778: mov             v1.16b, v0.16b
    // 0xb5177c: ldur            x1, [fp, #-8]
    // 0xb51780: ldur            d0, [fp, #-0x30]
    // 0xb51784: stur            d1, [fp, #-0x38]
    // 0xb51788: r0 = _preferredHeight()
    //     0xb51788: bl              #0xb2aea4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_preferredHeight
    // 0xb5178c: r0 = inline_Allocate_Double()
    //     0xb5178c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb51790: add             x0, x0, #0x10
    //     0xb51794: cmp             x1, x0
    //     0xb51798: b.ls            #0xb51850
    //     0xb5179c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb517a0: sub             x0, x0, #0xf
    //     0xb517a4: mov             x1, #0xe19c
    //     0xb517a8: movk            x1, #3, lsl #16
    //     0xb517ac: stur            x1, [x0, #-1]
    // 0xb517b0: dmb             ishst
    // 0xb517b4: StoreField: r0->field_7 = d0
    //     0xb517b4: stur            d0, [x0, #7]
    // 0xb517b8: str             x0, [SP]
    // 0xb517bc: ldur            x1, [fp, #-0x10]
    // 0xb517c0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xb517c0: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xb517c4: r0 = constrainHeight()
    //     0xb517c4: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb517c8: stur            d0, [fp, #-0x30]
    // 0xb517cc: r0 = Size()
    //     0xb517cc: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb517d0: ldur            d0, [fp, #-0x38]
    // 0xb517d4: StoreField: r0->field_7 = d0
    //     0xb517d4: stur            d0, [x0, #7]
    // 0xb517d8: ldur            d0, [fp, #-0x30]
    // 0xb517dc: StoreField: r0->field_f = d0
    //     0xb517dc: stur            d0, [x0, #0xf]
    // 0xb517e0: LeaveFrame
    //     0xb517e0: mov             SP, fp
    //     0xb517e4: ldp             fp, lr, [SP], #0x10
    // 0xb517e8: ret
    //     0xb517e8: ret             
    // 0xb517ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb517ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb517f0: b               #0xb5162c
    // 0xb517f4: stp             q0, q1, [SP, #-0x20]!
    // 0xb517f8: stp             x0, x2, [SP, #-0x10]!
    // 0xb517fc: r0 = AllocateDouble()
    //     0xb517fc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb51800: mov             x1, x0
    // 0xb51804: ldp             x0, x2, [SP], #0x10
    // 0xb51808: ldp             q0, q1, [SP], #0x20
    // 0xb5180c: b               #0xb51660
    // 0xb51810: SaveReg d1
    //     0xb51810: str             q1, [SP, #-0x10]!
    // 0xb51814: stp             x1, x2, [SP, #-0x10]!
    // 0xb51818: SaveReg r0
    //     0xb51818: str             x0, [SP, #-8]!
    // 0xb5181c: r0 = AllocateDouble()
    //     0xb5181c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb51820: mov             x3, x0
    // 0xb51824: RestoreReg r0
    //     0xb51824: ldr             x0, [SP], #8
    // 0xb51828: ldp             x1, x2, [SP], #0x10
    // 0xb5182c: RestoreReg d1
    //     0xb5182c: ldr             q1, [SP], #0x10
    // 0xb51830: b               #0xb5168c
    // 0xb51834: SaveReg d1
    //     0xb51834: str             q1, [SP, #-0x10]!
    // 0xb51838: SaveReg r0
    //     0xb51838: str             x0, [SP, #-8]!
    // 0xb5183c: r0 = AllocateDouble()
    //     0xb5183c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb51840: mov             x1, x0
    // 0xb51844: RestoreReg r0
    //     0xb51844: ldr             x0, [SP], #8
    // 0xb51848: RestoreReg d1
    //     0xb51848: ldr             q1, [SP], #0x10
    // 0xb5184c: b               #0xb51764
    // 0xb51850: SaveReg d0
    //     0xb51850: str             q0, [SP, #-0x10]!
    // 0xb51854: r0 = AllocateDouble()
    //     0xb51854: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb51858: RestoreReg d0
    //     0xb51858: ldr             q0, [SP], #0x10
    // 0xb5185c: b               #0xb517b4
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb5860c, size: 0x24
    // 0xb5860c: EnterFrame
    //     0xb5860c: stp             fp, lr, [SP, #-0x10]!
    //     0xb58610: mov             fp, SP
    // 0xb58614: ldr             x2, [fp, #0x10]
    // 0xb58618: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58618: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd590] AnonymousClosure: (0xb2e538), in [package:flutter/src/rendering/editable.dart] RenderEditable::computeMaxIntrinsicWidth (0xb2e46c)
    //     0xb5861c: ldr             x1, [x1, #0x590]
    // 0xb58620: r0 = AllocateClosure()
    //     0xb58620: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58624: LeaveFrame
    //     0xb58624: mov             SP, fp
    //     0xb58628: ldp             fp, lr, [SP], #0x10
    // 0xb5862c: ret
    //     0xb5862c: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5b2d0, size: 0x90
    // 0xb5b2d0: EnterFrame
    //     0xb5b2d0: stp             fp, lr, [SP, #-0x10]!
    //     0xb5b2d4: mov             fp, SP
    // 0xb5b2d8: AllocStack(0x10)
    //     0xb5b2d8: sub             SP, SP, #0x10
    // 0xb5b2dc: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb5b2dc: mov             x0, x1
    //     0xb5b2e0: stur            x1, [fp, #-8]
    //     0xb5b2e4: stur            x2, [fp, #-0x10]
    // 0xb5b2e8: CheckStackOverflow
    //     0xb5b2e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5b2ec: cmp             SP, x16
    //     0xb5b2f0: b.ls            #0xb5b348
    // 0xb5b2f4: mov             x1, x0
    // 0xb5b2f8: r0 = _computeTextMetricsIfNeeded()
    //     0xb5b2f8: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0xb5b2fc: ldur            x0, [fp, #-8]
    // 0xb5b300: LoadField: r1 = r0->field_a7
    //     0xb5b300: ldur            w1, [x0, #0xa7]
    // 0xb5b304: DecompressPointer r1
    //     0xb5b304: add             x1, x1, HEAP, lsl #32
    // 0xb5b308: ldur            x2, [fp, #-0x10]
    // 0xb5b30c: r0 = computeDistanceToActualBaseline()
    //     0xb5b30c: bl              #0xb5b360  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeDistanceToActualBaseline
    // 0xb5b310: r0 = inline_Allocate_Double()
    //     0xb5b310: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5b314: add             x0, x0, #0x10
    //     0xb5b318: cmp             x1, x0
    //     0xb5b31c: b.ls            #0xb5b350
    //     0xb5b320: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5b324: sub             x0, x0, #0xf
    //     0xb5b328: mov             x1, #0xe19c
    //     0xb5b32c: movk            x1, #3, lsl #16
    //     0xb5b330: stur            x1, [x0, #-1]
    // 0xb5b334: dmb             ishst
    // 0xb5b338: StoreField: r0->field_7 = d0
    //     0xb5b338: stur            d0, [x0, #7]
    // 0xb5b33c: LeaveFrame
    //     0xb5b33c: mov             SP, fp
    //     0xb5b340: ldp             fp, lr, [SP], #0x10
    // 0xb5b344: ret
    //     0xb5b344: ret             
    // 0xb5b348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5b348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5b34c: b               #0xb5b2f4
    // 0xb5b350: SaveReg d0
    //     0xb5b350: str             q0, [SP, #-0x10]!
    // 0xb5b354: r0 = AllocateDouble()
    //     0xb5b354: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5b358: RestoreReg d0
    //     0xb5b358: ldr             q0, [SP], #0x10
    // 0xb5b35c: b               #0xb5b338
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e7b8, size: 0x24
    // 0xb5e7b8: EnterFrame
    //     0xb5e7b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e7bc: mov             fp, SP
    // 0xb5e7c0: ldr             x2, [fp, #0x10]
    // 0xb5e7c4: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e7c4: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd580] AnonymousClosure: (0xb2ae2c), in [package:flutter/src/rendering/editable.dart] RenderEditable::computeMaxIntrinsicHeight (0xb2ada4)
    //     0xb5e7c8: ldr             x1, [x1, #0x580]
    // 0xb5e7cc: r0 = AllocateClosure()
    //     0xb5e7cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e7d0: LeaveFrame
    //     0xb5e7d0: mov             SP, fp
    //     0xb5e7d4: ldp             fp, lr, [SP], #0x10
    // 0xb5e7d8: ret
    //     0xb5e7d8: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb63f28, size: 0x1c8
    // 0xb63f28: EnterFrame
    //     0xb63f28: stp             fp, lr, [SP, #-0x10]!
    //     0xb63f2c: mov             fp, SP
    // 0xb63f30: AllocStack(0x40)
    //     0xb63f30: sub             SP, SP, #0x40
    // 0xb63f34: SetupParameters(RenderEditable this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb63f34: mov             x5, x1
    //     0xb63f38: mov             x4, x2
    //     0xb63f3c: stur            x1, [fp, #-8]
    //     0xb63f40: stur            x2, [fp, #-0x10]
    //     0xb63f44: stur            x3, [fp, #-0x18]
    // 0xb63f48: CheckStackOverflow
    //     0xb63f48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb63f4c: cmp             SP, x16
    //     0xb63f50: b.ls            #0xb640ac
    // 0xb63f54: mov             x0, x4
    // 0xb63f58: r2 = Null
    //     0xb63f58: mov             x2, NULL
    // 0xb63f5c: r1 = Null
    //     0xb63f5c: mov             x1, NULL
    // 0xb63f60: r4 = 60
    //     0xb63f60: mov             x4, #0x3c
    // 0xb63f64: branchIfSmi(r0, 0xb63f70)
    //     0xb63f64: tbz             w0, #0, #0xb63f70
    // 0xb63f68: r4 = LoadClassIdInstr(r0)
    //     0xb63f68: ldur            x4, [x0, #-1]
    //     0xb63f6c: ubfx            x4, x4, #0xc, #0x14
    // 0xb63f70: sub             x4, x4, #0xb46
    // 0xb63f74: cmp             x4, #1
    // 0xb63f78: b.ls            #0xb63f8c
    // 0xb63f7c: r8 = BoxConstraints
    //     0xb63f7c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb63f80: r3 = Null
    //     0xb63f80: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd638] Null
    //     0xb63f84: ldr             x3, [x3, #0x638]
    // 0xb63f88: r0 = BoxConstraints()
    //     0xb63f88: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb63f8c: ldur            x0, [fp, #-0x10]
    // 0xb63f90: LoadField: d0 = r0->field_7
    //     0xb63f90: ldur            d0, [x0, #7]
    // 0xb63f94: LoadField: d1 = r0->field_f
    //     0xb63f94: ldur            d1, [x0, #0xf]
    // 0xb63f98: stur            d1, [fp, #-0x30]
    // 0xb63f9c: r0 = inline_Allocate_Double()
    //     0xb63f9c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb63fa0: add             x0, x0, #0x10
    //     0xb63fa4: cmp             x1, x0
    //     0xb63fa8: b.ls            #0xb640b4
    //     0xb63fac: str             x0, [THR, #0x60]  ; THR::top
    //     0xb63fb0: sub             x0, x0, #0xf
    //     0xb63fb4: mov             x1, #0xe19c
    //     0xb63fb8: movk            x1, #3, lsl #16
    //     0xb63fbc: stur            x1, [x0, #-1]
    // 0xb63fc0: dmb             ishst
    // 0xb63fc4: StoreField: r0->field_7 = d0
    //     0xb63fc4: stur            d0, [x0, #7]
    // 0xb63fc8: r1 = inline_Allocate_Double()
    //     0xb63fc8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb63fcc: add             x1, x1, #0x10
    //     0xb63fd0: cmp             x2, x1
    //     0xb63fd4: b.ls            #0xb640c4
    //     0xb63fd8: str             x1, [THR, #0x60]  ; THR::top
    //     0xb63fdc: sub             x1, x1, #0xf
    //     0xb63fe0: mov             x2, #0xe19c
    //     0xb63fe4: movk            x2, #3, lsl #16
    //     0xb63fe8: stur            x2, [x1, #-1]
    // 0xb63fec: dmb             ishst
    // 0xb63ff0: StoreField: r1->field_7 = d1
    //     0xb63ff0: stur            d1, [x1, #7]
    // 0xb63ff4: stp             x1, x0, [SP]
    // 0xb63ff8: ldur            x1, [fp, #-8]
    // 0xb63ffc: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb63ffc: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb64000: r0 = _adjustConstraints()
    //     0xb64000: bl              #0x860b7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_adjustConstraints
    // 0xb64004: mov             x2, x0
    // 0xb64008: stur            x2, [fp, #-0x20]
    // 0xb6400c: mov             x3, x1
    // 0xb64010: ldur            x1, [fp, #-8]
    // 0xb64014: stur            x3, [fp, #-0x10]
    // 0xb64018: r0 = _textIntrinsics()
    //     0xb64018: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb6401c: ldur            x1, [fp, #-8]
    // 0xb64020: ldur            d0, [fp, #-0x30]
    // 0xb64024: r2 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb64024: add             x2, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb64028: ldr             x2, [x2, #0x700]
    // 0xb6402c: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb6402c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb64030: ldr             x3, [x3, #0x860]
    // 0xb64034: stur            x0, [fp, #-0x28]
    // 0xb64038: r0 = layoutInlineChildren()
    //     0xb64038: bl              #0xb1d4b8  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb6403c: ldur            x1, [fp, #-0x28]
    // 0xb64040: mov             x2, x0
    // 0xb64044: r0 = setPlaceholderDimensions()
    //     0xb64044: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb64048: ldur            x16, [fp, #-0x20]
    // 0xb6404c: ldur            lr, [fp, #-0x10]
    // 0xb64050: stp             lr, x16, [SP]
    // 0xb64054: ldur            x1, [fp, #-0x28]
    // 0xb64058: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb64058: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb6405c: r0 = layout()
    //     0xb6405c: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb64060: ldur            x1, [fp, #-8]
    // 0xb64064: r0 = _textIntrinsics()
    //     0xb64064: bl              #0xb1cbcc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_textIntrinsics
    // 0xb64068: mov             x1, x0
    // 0xb6406c: ldur            x2, [fp, #-0x18]
    // 0xb64070: r0 = computeDistanceToActualBaseline()
    //     0xb64070: bl              #0xb5b360  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeDistanceToActualBaseline
    // 0xb64074: r0 = inline_Allocate_Double()
    //     0xb64074: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb64078: add             x0, x0, #0x10
    //     0xb6407c: cmp             x1, x0
    //     0xb64080: b.ls            #0xb640e0
    //     0xb64084: str             x0, [THR, #0x60]  ; THR::top
    //     0xb64088: sub             x0, x0, #0xf
    //     0xb6408c: mov             x1, #0xe19c
    //     0xb64090: movk            x1, #3, lsl #16
    //     0xb64094: stur            x1, [x0, #-1]
    // 0xb64098: dmb             ishst
    // 0xb6409c: StoreField: r0->field_7 = d0
    //     0xb6409c: stur            d0, [x0, #7]
    // 0xb640a0: LeaveFrame
    //     0xb640a0: mov             SP, fp
    //     0xb640a4: ldp             fp, lr, [SP], #0x10
    // 0xb640a8: ret
    //     0xb640a8: ret             
    // 0xb640ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb640ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb640b0: b               #0xb63f54
    // 0xb640b4: stp             q0, q1, [SP, #-0x20]!
    // 0xb640b8: r0 = AllocateDouble()
    //     0xb640b8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb640bc: ldp             q0, q1, [SP], #0x20
    // 0xb640c0: b               #0xb63fc4
    // 0xb640c4: SaveReg d1
    //     0xb640c4: str             q1, [SP, #-0x10]!
    // 0xb640c8: SaveReg r0
    //     0xb640c8: str             x0, [SP, #-8]!
    // 0xb640cc: r0 = AllocateDouble()
    //     0xb640cc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb640d0: mov             x1, x0
    // 0xb640d4: RestoreReg r0
    //     0xb640d4: ldr             x0, [SP], #8
    // 0xb640d8: RestoreReg d1
    //     0xb640d8: ldr             q1, [SP], #0x10
    // 0xb640dc: b               #0xb63ff0
    // 0xb640e0: SaveReg d0
    //     0xb640e0: str             q0, [SP, #-0x10]!
    // 0xb640e4: r0 = AllocateDouble()
    //     0xb640e4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb640e8: RestoreReg d0
    //     0xb640e8: ldr             q0, [SP], #0x10
    // 0xb640ec: b               #0xb6409c
  }
  _ selectWordsInRange(/* No info */) {
    // ** addr: 0xb974a8, size: 0x288
    // 0xb974a8: EnterFrame
    //     0xb974a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb974ac: mov             fp, SP
    // 0xb974b0: AllocStack(0x50)
    //     0xb974b0: sub             SP, SP, #0x50
    // 0xb974b4: SetupParameters(RenderEditable this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* r3 => r2, fp-0x20 */)
    //     0xb974b4: mov             x0, x1
    //     0xb974b8: stur            x2, [fp, #-0x18]
    //     0xb974bc: mov             x16, x3
    //     0xb974c0: mov             x3, x2
    //     0xb974c4: mov             x2, x16
    //     0xb974c8: stur            x1, [fp, #-0x10]
    //     0xb974cc: stur            x2, [fp, #-0x20]
    // 0xb974d0: LoadField: r1 = r4->field_13
    //     0xb974d0: ldur            w1, [x4, #0x13]
    // 0xb974d4: LoadField: r5 = r4->field_1f
    //     0xb974d4: ldur            w5, [x4, #0x1f]
    // 0xb974d8: DecompressPointer r5
    //     0xb974d8: add             x5, x5, HEAP, lsl #32
    // 0xb974dc: r16 = "to"
    //     0xb974dc: ldr             x16, [PP, #0x6220]  ; [pp+0x6220] "to"
    // 0xb974e0: cmp             w5, w16
    // 0xb974e4: b.ne            #0xb97504
    // 0xb974e8: LoadField: r5 = r4->field_23
    //     0xb974e8: ldur            w5, [x4, #0x23]
    // 0xb974ec: DecompressPointer r5
    //     0xb974ec: add             x5, x5, HEAP, lsl #32
    // 0xb974f0: sub             w4, w1, w5
    // 0xb974f4: add             x1, fp, w4, sxtw #2
    // 0xb974f8: ldr             x1, [x1, #8]
    // 0xb974fc: mov             x4, x1
    // 0xb97500: b               #0xb97508
    // 0xb97504: r4 = Null
    //     0xb97504: mov             x4, NULL
    // 0xb97508: stur            x4, [fp, #-8]
    // 0xb9750c: CheckStackOverflow
    //     0xb9750c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb97510: cmp             SP, x16
    //     0xb97514: b.ls            #0xb97728
    // 0xb97518: mov             x1, x0
    // 0xb9751c: r0 = _computeTextMetricsIfNeeded()
    //     0xb9751c: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0xb97520: ldur            x0, [fp, #-0x10]
    // 0xb97524: LoadField: r3 = r0->field_a7
    //     0xb97524: ldur            w3, [x0, #0xa7]
    // 0xb97528: DecompressPointer r3
    //     0xb97528: add             x3, x3, HEAP, lsl #32
    // 0xb9752c: mov             x1, x0
    // 0xb97530: ldur            x2, [fp, #-0x20]
    // 0xb97534: stur            x3, [fp, #-0x28]
    // 0xb97538: r0 = globalToLocal()
    //     0xb97538: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0xb9753c: ldur            x1, [fp, #-0x10]
    // 0xb97540: stur            x0, [fp, #-0x20]
    // 0xb97544: r0 = _paintOffset()
    //     0xb97544: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0xb97548: ldur            x1, [fp, #-0x20]
    // 0xb9754c: mov             x2, x0
    // 0xb97550: r0 = -()
    //     0xb97550: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xb97554: ldur            x1, [fp, #-0x28]
    // 0xb97558: mov             x2, x0
    // 0xb9755c: r0 = getPositionForOffset()
    //     0xb9755c: bl              #0x86749c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0xb97560: ldur            x1, [fp, #-0x10]
    // 0xb97564: mov             x2, x0
    // 0xb97568: stur            x0, [fp, #-0x20]
    // 0xb9756c: r0 = getWordAtOffset()
    //     0xb9756c: bl              #0xb97730  ; [package:flutter/src/rendering/editable.dart] RenderEditable::getWordAtOffset
    // 0xb97570: ldur            x2, [fp, #-8]
    // 0xb97574: stur            x0, [fp, #-0x30]
    // 0xb97578: cmp             w2, NULL
    // 0xb9757c: b.ne            #0xb97588
    // 0xb97580: ldur            x2, [fp, #-0x20]
    // 0xb97584: b               #0xb975b8
    // 0xb97588: ldur            x1, [fp, #-0x10]
    // 0xb9758c: r0 = globalToLocal()
    //     0xb9758c: bl              #0x867840  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0xb97590: ldur            x1, [fp, #-0x10]
    // 0xb97594: stur            x0, [fp, #-8]
    // 0xb97598: r0 = _paintOffset()
    //     0xb97598: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0xb9759c: ldur            x1, [fp, #-8]
    // 0xb975a0: mov             x2, x0
    // 0xb975a4: r0 = -()
    //     0xb975a4: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0xb975a8: ldur            x1, [fp, #-0x28]
    // 0xb975ac: mov             x2, x0
    // 0xb975b0: r0 = getPositionForOffset()
    //     0xb975b0: bl              #0x86749c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0xb975b4: mov             x2, x0
    // 0xb975b8: stur            x2, [fp, #-8]
    // 0xb975bc: r16 = TextPosition
    //     0xb975bc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe270] Type: TextPosition
    //     0xb975c0: ldr             x16, [x16, #0x270]
    // 0xb975c4: r30 = TextPosition
    //     0xb975c4: add             lr, PP, #0xe, lsl #12  ; [pp+0xe270] Type: TextPosition
    //     0xb975c8: ldr             lr, [lr, #0x270]
    // 0xb975cc: stp             lr, x16, [SP]
    // 0xb975d0: r0 = ==()
    //     0xb975d0: bl              #0x12b7fbc  ; [dart:core] _Type::==
    // 0xb975d4: tbz             w0, #4, #0xb975e0
    // 0xb975d8: ldur            x2, [fp, #-8]
    // 0xb975dc: b               #0xb97618
    // 0xb975e0: ldur            x0, [fp, #-0x20]
    // 0xb975e4: ldur            x2, [fp, #-8]
    // 0xb975e8: LoadField: r1 = r0->field_7
    //     0xb975e8: ldur            x1, [x0, #7]
    // 0xb975ec: LoadField: r3 = r2->field_7
    //     0xb975ec: ldur            x3, [x2, #7]
    // 0xb975f0: cmp             x1, x3
    // 0xb975f4: b.ne            #0xb97618
    // 0xb975f8: LoadField: r1 = r0->field_f
    //     0xb975f8: ldur            w1, [x0, #0xf]
    // 0xb975fc: DecompressPointer r1
    //     0xb975fc: add             x1, x1, HEAP, lsl #32
    // 0xb97600: LoadField: r0 = r2->field_f
    //     0xb97600: ldur            w0, [x2, #0xf]
    // 0xb97604: DecompressPointer r0
    //     0xb97604: add             x0, x0, HEAP, lsl #32
    // 0xb97608: cmp             w1, w0
    // 0xb9760c: b.ne            #0xb97618
    // 0xb97610: ldur            x2, [fp, #-0x30]
    // 0xb97614: b               #0xb97624
    // 0xb97618: ldur            x1, [fp, #-0x10]
    // 0xb9761c: r0 = getWordAtOffset()
    //     0xb9761c: bl              #0xb97730  ; [package:flutter/src/rendering/editable.dart] RenderEditable::getWordAtOffset
    // 0xb97620: mov             x2, x0
    // 0xb97624: ldur            x0, [fp, #-0x30]
    // 0xb97628: stur            x2, [fp, #-0x20]
    // 0xb9762c: LoadField: r1 = r0->field_7
    //     0xb9762c: ldur            x1, [x0, #7]
    // 0xb97630: LoadField: r3 = r2->field_f
    //     0xb97630: ldur            x3, [x2, #0xf]
    // 0xb97634: cmp             x1, x3
    // 0xb97638: r16 = true
    //     0xb97638: add             x16, NULL, #0x20  ; true
    // 0xb9763c: r17 = false
    //     0xb9763c: add             x17, NULL, #0x30  ; false
    // 0xb97640: csel            x4, x16, x17, lt
    // 0xb97644: stur            x4, [fp, #-8]
    // 0xb97648: tbnz            w4, #4, #0xb97660
    // 0xb9764c: mov             x1, x0
    // 0xb97650: r0 = base()
    //     0xb97650: bl              #0x86de9c  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0xb97654: LoadField: r1 = r0->field_7
    //     0xb97654: ldur            x1, [x0, #7]
    // 0xb97658: mov             x2, x1
    // 0xb9765c: b               #0xb97670
    // 0xb97660: ldur            x1, [fp, #-0x30]
    // 0xb97664: r0 = extent()
    //     0xb97664: bl              #0x85fb94  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xb97668: LoadField: r1 = r0->field_7
    //     0xb97668: ldur            x1, [x0, #7]
    // 0xb9766c: mov             x2, x1
    // 0xb97670: ldur            x0, [fp, #-8]
    // 0xb97674: stur            x2, [fp, #-0x38]
    // 0xb97678: tbnz            w0, #4, #0xb97690
    // 0xb9767c: ldur            x1, [fp, #-0x20]
    // 0xb97680: r0 = extent()
    //     0xb97680: bl              #0x85fb94  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xb97684: LoadField: r1 = r0->field_7
    //     0xb97684: ldur            x1, [x0, #7]
    // 0xb97688: mov             x2, x1
    // 0xb9768c: b               #0xb976a0
    // 0xb97690: ldur            x1, [fp, #-0x20]
    // 0xb97694: r0 = base()
    //     0xb97694: bl              #0x86de9c  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0xb97698: LoadField: r1 = r0->field_7
    //     0xb97698: ldur            x1, [x0, #7]
    // 0xb9769c: mov             x2, x1
    // 0xb976a0: ldur            x1, [fp, #-0x30]
    // 0xb976a4: ldur            x0, [fp, #-0x38]
    // 0xb976a8: stur            x2, [fp, #-0x40]
    // 0xb976ac: LoadField: r3 = r1->field_27
    //     0xb976ac: ldur            w3, [x1, #0x27]
    // 0xb976b0: DecompressPointer r3
    //     0xb976b0: add             x3, x3, HEAP, lsl #32
    // 0xb976b4: stur            x3, [fp, #-8]
    // 0xb976b8: r0 = TextSelection()
    //     0xb976b8: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xb976bc: mov             x1, x0
    // 0xb976c0: ldur            x0, [fp, #-0x38]
    // 0xb976c4: ArrayStore: r1[0] = r0  ; List_8
    //     0xb976c4: stur            x0, [x1, #0x17]
    // 0xb976c8: ldur            x2, [fp, #-0x40]
    // 0xb976cc: StoreField: r1->field_1f = r2
    //     0xb976cc: stur            x2, [x1, #0x1f]
    // 0xb976d0: ldur            x3, [fp, #-8]
    // 0xb976d4: StoreField: r1->field_27 = r3
    //     0xb976d4: stur            w3, [x1, #0x27]
    // 0xb976d8: r3 = false
    //     0xb976d8: add             x3, NULL, #0x30  ; false
    // 0xb976dc: StoreField: r1->field_2b = r3
    //     0xb976dc: stur            w3, [x1, #0x2b]
    // 0xb976e0: cmp             x0, x2
    // 0xb976e4: b.ge            #0xb976f0
    // 0xb976e8: mov             x3, x0
    // 0xb976ec: b               #0xb976f4
    // 0xb976f0: mov             x3, x2
    // 0xb976f4: cmp             x0, x2
    // 0xb976f8: b.ge            #0xb97700
    // 0xb976fc: mov             x0, x2
    // 0xb97700: StoreField: r1->field_7 = r3
    //     0xb97700: stur            x3, [x1, #7]
    // 0xb97704: StoreField: r1->field_f = r0
    //     0xb97704: stur            x0, [x1, #0xf]
    // 0xb97708: mov             x2, x1
    // 0xb9770c: ldur            x1, [fp, #-0x10]
    // 0xb97710: ldur            x3, [fp, #-0x18]
    // 0xb97714: r0 = _setSelection()
    //     0xb97714: bl              #0x87957c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_setSelection
    // 0xb97718: r0 = Null
    //     0xb97718: mov             x0, NULL
    // 0xb9771c: LeaveFrame
    //     0xb9771c: mov             SP, fp
    //     0xb97720: ldp             fp, lr, [SP], #0x10
    // 0xb97724: ret
    //     0xb97724: ret             
    // 0xb97728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb97728: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9772c: b               #0xb97518
  }
  _ getWordAtOffset(/* No info */) {
    // ** addr: 0xb97730, size: 0x380
    // 0xb97730: EnterFrame
    //     0xb97730: stp             fp, lr, [SP, #-0x10]!
    //     0xb97734: mov             fp, SP
    // 0xb97738: AllocStack(0x30)
    //     0xb97738: sub             SP, SP, #0x30
    // 0xb9773c: SetupParameters(RenderEditable this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */)
    //     0xb9773c: mov             x0, x1
    //     0xb97740: stur            x1, [fp, #-0x18]
    //     0xb97744: stur            x2, [fp, #-0x20]
    // 0xb97748: CheckStackOverflow
    //     0xb97748: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb9774c: cmp             SP, x16
    //     0xb97750: b.ls            #0xb97aa4
    // 0xb97754: LoadField: r3 = r2->field_7
    //     0xb97754: ldur            x3, [x2, #7]
    // 0xb97758: stur            x3, [fp, #-0x10]
    // 0xb9775c: LoadField: r4 = r0->field_a7
    //     0xb9775c: ldur            w4, [x0, #0xa7]
    // 0xb97760: DecompressPointer r4
    //     0xb97760: add             x4, x4, HEAP, lsl #32
    // 0xb97764: mov             x1, x4
    // 0xb97768: stur            x4, [fp, #-8]
    // 0xb9776c: r0 = plainText()
    //     0xb9776c: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0xb97770: LoadField: r1 = r0->field_7
    //     0xb97770: ldur            w1, [x0, #7]
    // 0xb97774: r0 = LoadInt32Instr(r1)
    //     0xb97774: sbfx            x0, x1, #1, #0x1f
    // 0xb97778: ldur            x3, [fp, #-0x10]
    // 0xb9777c: cmp             x3, x0
    // 0xb97780: b.lt            #0xb977d4
    // 0xb97784: ldur            x1, [fp, #-8]
    // 0xb97788: r0 = plainText()
    //     0xb97788: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0xb9778c: LoadField: r1 = r0->field_7
    //     0xb9778c: ldur            w1, [x0, #7]
    // 0xb97790: r0 = LoadInt32Instr(r1)
    //     0xb97790: sbfx            x0, x1, #1, #0x1f
    // 0xb97794: stur            x0, [fp, #-0x28]
    // 0xb97798: r0 = TextSelection()
    //     0xb97798: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xb9779c: mov             x1, x0
    // 0xb977a0: ldur            x0, [fp, #-0x28]
    // 0xb977a4: ArrayStore: r1[0] = r0  ; List_8
    //     0xb977a4: stur            x0, [x1, #0x17]
    // 0xb977a8: StoreField: r1->field_1f = r0
    //     0xb977a8: stur            x0, [x1, #0x1f]
    // 0xb977ac: r2 = Instance_TextAffinity
    //     0xb977ac: ldr             x2, [PP, #0x4bb8]  ; [pp+0x4bb8] Obj!TextAffinity@12c7341
    // 0xb977b0: StoreField: r1->field_27 = r2
    //     0xb977b0: stur            w2, [x1, #0x27]
    // 0xb977b4: r2 = false
    //     0xb977b4: add             x2, NULL, #0x30  ; false
    // 0xb977b8: StoreField: r1->field_2b = r2
    //     0xb977b8: stur            w2, [x1, #0x2b]
    // 0xb977bc: StoreField: r1->field_7 = r0
    //     0xb977bc: stur            x0, [x1, #7]
    // 0xb977c0: StoreField: r1->field_f = r0
    //     0xb977c0: stur            x0, [x1, #0xf]
    // 0xb977c4: mov             x0, x1
    // 0xb977c8: LeaveFrame
    //     0xb977c8: mov             SP, fp
    //     0xb977cc: ldp             fp, lr, [SP], #0x10
    // 0xb977d0: ret
    //     0xb977d0: ret             
    // 0xb977d4: ldur            x0, [fp, #-0x18]
    // 0xb977d8: r2 = false
    //     0xb977d8: add             x2, NULL, #0x30  ; false
    // 0xb977dc: LoadField: r1 = r0->field_97
    //     0xb977dc: ldur            w1, [x0, #0x97]
    // 0xb977e0: DecompressPointer r1
    //     0xb977e0: add             x1, x1, HEAP, lsl #32
    // 0xb977e4: tbnz            w1, #4, #0xb97850
    // 0xb977e8: ldur            x1, [fp, #-8]
    // 0xb977ec: r0 = plainText()
    //     0xb977ec: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0xb977f0: LoadField: r1 = r0->field_7
    //     0xb977f0: ldur            w1, [x0, #7]
    // 0xb977f4: stur            x1, [fp, #-0x30]
    // 0xb977f8: r0 = TextSelection()
    //     0xb977f8: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xb977fc: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb977fc: stur            xzr, [x0, #0x17]
    // 0xb97800: ldur            x1, [fp, #-0x30]
    // 0xb97804: r2 = LoadInt32Instr(r1)
    //     0xb97804: sbfx            x2, x1, #1, #0x1f
    // 0xb97808: StoreField: r0->field_1f = r2
    //     0xb97808: stur            x2, [x0, #0x1f]
    // 0xb9780c: r4 = Instance_TextAffinity
    //     0xb9780c: ldr             x4, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb97810: StoreField: r0->field_27 = r4
    //     0xb97810: stur            w4, [x0, #0x27]
    // 0xb97814: r5 = false
    //     0xb97814: add             x5, NULL, #0x30  ; false
    // 0xb97818: StoreField: r0->field_2b = r5
    //     0xb97818: stur            w5, [x0, #0x2b]
    // 0xb9781c: cmp             x2, #0
    // 0xb97820: b.le            #0xb9782c
    // 0xb97824: r1 = 0
    //     0xb97824: mov             x1, #0
    // 0xb97828: b               #0xb97830
    // 0xb9782c: mov             x1, x2
    // 0xb97830: cmp             x2, #0
    // 0xb97834: b.gt            #0xb9783c
    // 0xb97838: r2 = 0
    //     0xb97838: mov             x2, #0
    // 0xb9783c: StoreField: r0->field_7 = r1
    //     0xb9783c: stur            x1, [x0, #7]
    // 0xb97840: StoreField: r0->field_f = r2
    //     0xb97840: stur            x2, [x0, #0xf]
    // 0xb97844: LeaveFrame
    //     0xb97844: mov             SP, fp
    //     0xb97848: ldp             fp, lr, [SP], #0x10
    // 0xb9784c: ret
    //     0xb9784c: ret             
    // 0xb97850: ldur            x6, [fp, #-0x20]
    // 0xb97854: mov             x5, x2
    // 0xb97858: r4 = Instance_TextAffinity
    //     0xb97858: ldr             x4, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb9785c: ldur            x1, [fp, #-8]
    // 0xb97860: mov             x2, x6
    // 0xb97864: r0 = getWordBoundary()
    //     0xb97864: bl              #0xb984a8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getWordBoundary
    // 0xb97868: mov             x2, x0
    // 0xb9786c: ldur            x0, [fp, #-0x20]
    // 0xb97870: stur            x2, [fp, #-0x30]
    // 0xb97874: LoadField: r1 = r0->field_f
    //     0xb97874: ldur            w1, [x0, #0xf]
    // 0xb97878: DecompressPointer r1
    //     0xb97878: add             x1, x1, HEAP, lsl #32
    // 0xb9787c: LoadField: r0 = r1->field_7
    //     0xb9787c: ldur            x0, [x1, #7]
    // 0xb97880: cmp             x0, #0
    // 0xb97884: b.gt            #0xb97898
    // 0xb97888: ldur            x0, [fp, #-0x10]
    // 0xb9788c: sub             x1, x0, #1
    // 0xb97890: mov             x3, x1
    // 0xb97894: b               #0xb978a0
    // 0xb97898: ldur            x0, [fp, #-0x10]
    // 0xb9789c: mov             x3, x0
    // 0xb978a0: stur            x3, [fp, #-0x28]
    // 0xb978a4: cmp             x3, #0
    // 0xb978a8: b.le            #0xb97a30
    // 0xb978ac: ldur            x1, [fp, #-8]
    // 0xb978b0: r0 = plainText()
    //     0xb978b0: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0xb978b4: mov             x2, x0
    // 0xb978b8: LoadField: r0 = r2->field_7
    //     0xb978b8: ldur            w0, [x2, #7]
    // 0xb978bc: r1 = LoadInt32Instr(r0)
    //     0xb978bc: sbfx            x1, x0, #1, #0x1f
    // 0xb978c0: mov             x0, x1
    // 0xb978c4: ldur            x1, [fp, #-0x28]
    // 0xb978c8: cmp             x1, x0
    // 0xb978cc: b.hs            #0xb97aac
    // 0xb978d0: r0 = LoadClassIdInstr(r2)
    //     0xb978d0: ldur            x0, [x2, #-1]
    //     0xb978d4: ubfx            x0, x0, #0xc, #0x14
    // 0xb978d8: lsl             x0, x0, #1
    // 0xb978dc: cmp             w0, #0xbc
    // 0xb978e0: b.ne            #0xb978f4
    // 0xb978e4: ldur            x0, [fp, #-0x28]
    // 0xb978e8: ArrayLoad: r1 = r2[r0]  ; TypedUnsigned_1
    //     0xb978e8: add             x16, x2, x0
    //     0xb978ec: ldrb            w1, [x16, #0xf]
    // 0xb978f0: b               #0xb97900
    // 0xb978f4: ldur            x0, [fp, #-0x28]
    // 0xb978f8: add             x16, x2, x0, lsl #1
    // 0xb978fc: ldurh           w1, [x16, #0xf]
    // 0xb97900: r0 = isWhitespace()
    //     0xb97900: bl              #0xb983a4  ; [package:flutter/src/services/text_layout_metrics.dart] TextLayoutMetrics::isWhitespace
    // 0xb97904: tbnz            w0, #4, #0xb97a24
    // 0xb97908: ldur            x3, [fp, #-0x18]
    // 0xb9790c: ldur            x0, [fp, #-0x30]
    // 0xb97910: LoadField: r2 = r0->field_7
    //     0xb97910: ldur            x2, [x0, #7]
    // 0xb97914: mov             x1, x3
    // 0xb97918: r0 = _getPreviousWord()
    //     0xb97918: bl              #0xb97ab0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_getPreviousWord
    // 0xb9791c: mov             x1, x0
    // 0xb97920: ldur            x0, [fp, #-0x18]
    // 0xb97924: LoadField: r2 = r0->field_c7
    //     0xb97924: ldur            w2, [x0, #0xc7]
    // 0xb97928: DecompressPointer r2
    //     0xb97928: add             x2, x2, HEAP, lsl #32
    // 0xb9792c: tbnz            w2, #4, #0xb97a18
    // 0xb97930: cmp             w1, NULL
    // 0xb97934: b.ne            #0xb979a4
    // 0xb97938: ldur            x0, [fp, #-0x10]
    // 0xb9793c: add             x1, x0, #1
    // 0xb97940: stur            x1, [fp, #-0x28]
    // 0xb97944: r0 = TextSelection()
    //     0xb97944: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xb97948: mov             x1, x0
    // 0xb9794c: ldur            x0, [fp, #-0x10]
    // 0xb97950: ArrayStore: r1[0] = r0  ; List_8
    //     0xb97950: stur            x0, [x1, #0x17]
    // 0xb97954: ldur            x2, [fp, #-0x28]
    // 0xb97958: StoreField: r1->field_1f = r2
    //     0xb97958: stur            x2, [x1, #0x1f]
    // 0xb9795c: r3 = Instance_TextAffinity
    //     0xb9795c: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb97960: StoreField: r1->field_27 = r3
    //     0xb97960: stur            w3, [x1, #0x27]
    // 0xb97964: r4 = false
    //     0xb97964: add             x4, NULL, #0x30  ; false
    // 0xb97968: StoreField: r1->field_2b = r4
    //     0xb97968: stur            w4, [x1, #0x2b]
    // 0xb9796c: cmp             x0, x2
    // 0xb97970: b.ge            #0xb9797c
    // 0xb97974: mov             x3, x0
    // 0xb97978: b               #0xb97980
    // 0xb9797c: mov             x3, x2
    // 0xb97980: cmp             x0, x2
    // 0xb97984: b.ge            #0xb9798c
    // 0xb97988: mov             x0, x2
    // 0xb9798c: StoreField: r1->field_7 = r3
    //     0xb9798c: stur            x3, [x1, #7]
    // 0xb97990: StoreField: r1->field_f = r0
    //     0xb97990: stur            x0, [x1, #0xf]
    // 0xb97994: mov             x0, x1
    // 0xb97998: LeaveFrame
    //     0xb97998: mov             SP, fp
    //     0xb9799c: ldp             fp, lr, [SP], #0x10
    // 0xb979a0: ret
    //     0xb979a0: ret             
    // 0xb979a4: ldur            x0, [fp, #-0x10]
    // 0xb979a8: r3 = Instance_TextAffinity
    //     0xb979a8: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb979ac: r4 = false
    //     0xb979ac: add             x4, NULL, #0x30  ; false
    // 0xb979b0: LoadField: r2 = r1->field_7
    //     0xb979b0: ldur            x2, [x1, #7]
    // 0xb979b4: stur            x2, [fp, #-0x28]
    // 0xb979b8: r0 = TextSelection()
    //     0xb979b8: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xb979bc: mov             x1, x0
    // 0xb979c0: ldur            x0, [fp, #-0x28]
    // 0xb979c4: ArrayStore: r1[0] = r0  ; List_8
    //     0xb979c4: stur            x0, [x1, #0x17]
    // 0xb979c8: ldur            x2, [fp, #-0x10]
    // 0xb979cc: StoreField: r1->field_1f = r2
    //     0xb979cc: stur            x2, [x1, #0x1f]
    // 0xb979d0: r3 = Instance_TextAffinity
    //     0xb979d0: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb979d4: StoreField: r1->field_27 = r3
    //     0xb979d4: stur            w3, [x1, #0x27]
    // 0xb979d8: r4 = false
    //     0xb979d8: add             x4, NULL, #0x30  ; false
    // 0xb979dc: StoreField: r1->field_2b = r4
    //     0xb979dc: stur            w4, [x1, #0x2b]
    // 0xb979e0: cmp             x0, x2
    // 0xb979e4: b.ge            #0xb979f0
    // 0xb979e8: mov             x3, x0
    // 0xb979ec: b               #0xb979f4
    // 0xb979f0: mov             x3, x2
    // 0xb979f4: cmp             x0, x2
    // 0xb979f8: b.ge            #0xb97a00
    // 0xb979fc: mov             x0, x2
    // 0xb97a00: StoreField: r1->field_7 = r3
    //     0xb97a00: stur            x3, [x1, #7]
    // 0xb97a04: StoreField: r1->field_f = r0
    //     0xb97a04: stur            x0, [x1, #0xf]
    // 0xb97a08: mov             x0, x1
    // 0xb97a0c: LeaveFrame
    //     0xb97a0c: mov             SP, fp
    //     0xb97a10: ldp             fp, lr, [SP], #0x10
    // 0xb97a14: ret
    //     0xb97a14: ret             
    // 0xb97a18: r3 = Instance_TextAffinity
    //     0xb97a18: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb97a1c: r4 = false
    //     0xb97a1c: add             x4, NULL, #0x30  ; false
    // 0xb97a20: b               #0xb97a38
    // 0xb97a24: r3 = Instance_TextAffinity
    //     0xb97a24: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb97a28: r4 = false
    //     0xb97a28: add             x4, NULL, #0x30  ; false
    // 0xb97a2c: b               #0xb97a38
    // 0xb97a30: r3 = Instance_TextAffinity
    //     0xb97a30: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb97a34: r4 = false
    //     0xb97a34: add             x4, NULL, #0x30  ; false
    // 0xb97a38: ldur            x0, [fp, #-0x30]
    // 0xb97a3c: LoadField: r1 = r0->field_7
    //     0xb97a3c: ldur            x1, [x0, #7]
    // 0xb97a40: stur            x1, [fp, #-0x28]
    // 0xb97a44: LoadField: r2 = r0->field_f
    //     0xb97a44: ldur            x2, [x0, #0xf]
    // 0xb97a48: stur            x2, [fp, #-0x10]
    // 0xb97a4c: r0 = TextSelection()
    //     0xb97a4c: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xb97a50: ldur            x1, [fp, #-0x28]
    // 0xb97a54: ArrayStore: r0[0] = r1  ; List_8
    //     0xb97a54: stur            x1, [x0, #0x17]
    // 0xb97a58: ldur            x2, [fp, #-0x10]
    // 0xb97a5c: StoreField: r0->field_1f = r2
    //     0xb97a5c: stur            x2, [x0, #0x1f]
    // 0xb97a60: r3 = Instance_TextAffinity
    //     0xb97a60: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb97a64: StoreField: r0->field_27 = r3
    //     0xb97a64: stur            w3, [x0, #0x27]
    // 0xb97a68: r3 = false
    //     0xb97a68: add             x3, NULL, #0x30  ; false
    // 0xb97a6c: StoreField: r0->field_2b = r3
    //     0xb97a6c: stur            w3, [x0, #0x2b]
    // 0xb97a70: cmp             x1, x2
    // 0xb97a74: b.ge            #0xb97a80
    // 0xb97a78: mov             x3, x1
    // 0xb97a7c: b               #0xb97a84
    // 0xb97a80: mov             x3, x2
    // 0xb97a84: cmp             x1, x2
    // 0xb97a88: b.ge            #0xb97a90
    // 0xb97a8c: mov             x1, x2
    // 0xb97a90: StoreField: r0->field_7 = r3
    //     0xb97a90: stur            x3, [x0, #7]
    // 0xb97a94: StoreField: r0->field_f = r1
    //     0xb97a94: stur            x1, [x0, #0xf]
    // 0xb97a98: LeaveFrame
    //     0xb97a98: mov             SP, fp
    //     0xb97a9c: ldp             fp, lr, [SP], #0x10
    // 0xb97aa0: ret
    //     0xb97aa0: ret             
    // 0xb97aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb97aa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb97aa8: b               #0xb97754
    // 0xb97aac: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb97aac: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _getPreviousWord(/* No info */) {
    // ** addr: 0xb97ab0, size: 0x33c
    // 0xb97ab0: EnterFrame
    //     0xb97ab0: stp             fp, lr, [SP, #-0x10]!
    //     0xb97ab4: mov             fp, SP
    // 0xb97ab8: AllocStack(0x40)
    //     0xb97ab8: sub             SP, SP, #0x40
    // 0xb97abc: CheckStackOverflow
    //     0xb97abc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb97ac0: cmp             SP, x16
    //     0xb97ac4: b.ls            #0xb97dc8
    // 0xb97ac8: LoadField: r0 = r1->field_a7
    //     0xb97ac8: ldur            w0, [x1, #0xa7]
    // 0xb97acc: DecompressPointer r0
    //     0xb97acc: add             x0, x0, HEAP, lsl #32
    // 0xb97ad0: stur            x0, [fp, #-0x10]
    // 0xb97ad4: mov             x1, x2
    // 0xb97ad8: stur            x1, [fp, #-8]
    // 0xb97adc: CheckStackOverflow
    //     0xb97adc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb97ae0: cmp             SP, x16
    //     0xb97ae4: b.ls            #0xb97dd0
    // 0xb97ae8: tbnz            x1, #0x3f, #0xb97db8
    // 0xb97aec: r0 = TextPosition()
    //     0xb97aec: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0xb97af0: mov             x1, x0
    // 0xb97af4: ldur            x0, [fp, #-8]
    // 0xb97af8: StoreField: r1->field_7 = r0
    //     0xb97af8: stur            x0, [x1, #7]
    // 0xb97afc: r0 = Instance_TextAffinity
    //     0xb97afc: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xb97b00: StoreField: r1->field_f = r0
    //     0xb97b00: stur            w0, [x1, #0xf]
    // 0xb97b04: ldur            x3, [fp, #-0x10]
    // 0xb97b08: LoadField: r2 = r3->field_7
    //     0xb97b08: ldur            w2, [x3, #7]
    // 0xb97b0c: DecompressPointer r2
    //     0xb97b0c: add             x2, x2, HEAP, lsl #32
    // 0xb97b10: cmp             w2, NULL
    // 0xb97b14: b.eq            #0xb97dd8
    // 0xb97b18: LoadField: r4 = r2->field_7
    //     0xb97b18: ldur            w4, [x2, #7]
    // 0xb97b1c: DecompressPointer r4
    //     0xb97b1c: add             x4, x4, HEAP, lsl #32
    // 0xb97b20: LoadField: r2 = r4->field_f
    //     0xb97b20: ldur            w2, [x4, #0xf]
    // 0xb97b24: DecompressPointer r2
    //     0xb97b24: add             x2, x2, HEAP, lsl #32
    // 0xb97b28: mov             x16, x1
    // 0xb97b2c: mov             x1, x2
    // 0xb97b30: mov             x2, x16
    // 0xb97b34: r0 = getWordBoundary()
    //     0xb97b34: bl              #0xb97efc  ; [dart:ui] _NativeParagraph::getWordBoundary
    // 0xb97b38: mov             x2, x0
    // 0xb97b3c: stur            x2, [fp, #-0x38]
    // 0xb97b40: LoadField: r3 = r2->field_7
    //     0xb97b40: ldur            x3, [x2, #7]
    // 0xb97b44: stur            x3, [fp, #-0x30]
    // 0xb97b48: tbnz            x3, #0x3f, #0xb97da8
    // 0xb97b4c: LoadField: r4 = r2->field_f
    //     0xb97b4c: ldur            x4, [x2, #0xf]
    // 0xb97b50: stur            x4, [fp, #-0x28]
    // 0xb97b54: tbnz            x4, #0x3f, #0xb97da8
    // 0xb97b58: cmp             x3, x4
    // 0xb97b5c: b.eq            #0xb97da8
    // 0xb97b60: mov             x6, x3
    // 0xb97b64: ldur            x5, [fp, #-0x10]
    // 0xb97b68: stur            x6, [fp, #-8]
    // 0xb97b6c: CheckStackOverflow
    //     0xb97b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb97b70: cmp             SP, x16
    //     0xb97b74: b.ls            #0xb97ddc
    // 0xb97b78: cmp             x6, x4
    // 0xb97b7c: b.ge            #0xb97d94
    // 0xb97b80: LoadField: r7 = r5->field_f
    //     0xb97b80: ldur            w7, [x5, #0xf]
    // 0xb97b84: DecompressPointer r7
    //     0xb97b84: add             x7, x7, HEAP, lsl #32
    // 0xb97b88: stur            x7, [fp, #-0x20]
    // 0xb97b8c: cmp             w7, NULL
    // 0xb97b90: b.eq            #0xb97de4
    // 0xb97b94: r0 = BoxInt64Instr(r6)
    //     0xb97b94: sbfiz           x0, x6, #1, #0x1f
    //     0xb97b98: cmp             x6, x0, asr #1
    //     0xb97b9c: b.eq            #0xb97ba8
    //     0xb97ba0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb97ba4: stur            x6, [x0, #7]
    // 0xb97ba8: stur            x0, [fp, #-0x18]
    // 0xb97bac: r1 = 3
    //     0xb97bac: mov             x1, #3
    // 0xb97bb0: r0 = AllocateContext()
    //     0xb97bb0: bl              #0x13de838  ; AllocateContextStub
    // 0xb97bb4: mov             x1, x0
    // 0xb97bb8: ldur            x0, [fp, #-0x18]
    // 0xb97bbc: stur            x1, [fp, #-0x40]
    // 0xb97bc0: StoreField: r1->field_f = r0
    //     0xb97bc0: stur            w0, [x1, #0xf]
    // 0xb97bc4: ldur            x2, [fp, #-8]
    // 0xb97bc8: tbz             x2, #0x3f, #0xb97bd4
    // 0xb97bcc: r1 = Null
    //     0xb97bcc: mov             x1, NULL
    // 0xb97bd0: b               #0xb97c74
    // 0xb97bd4: ldur            x0, [fp, #-0x20]
    // 0xb97bd8: r0 = Accumulator()
    //     0xb97bd8: bl              #0xb97ef0  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0xb97bdc: StoreField: r0->field_7 = rZR
    //     0xb97bdc: stur            xzr, [x0, #7]
    // 0xb97be0: ldur            x4, [fp, #-0x40]
    // 0xb97be4: StoreField: r4->field_13 = r0
    //     0xb97be4: stur            w0, [x4, #0x13]
    // 0xb97be8: ArrayStore: r4[0] = rNULL  ; List_4
    //     0xb97be8: stur            NULL, [x4, #0x17]
    // 0xb97bec: ldur            x3, [fp, #-0x20]
    // 0xb97bf0: r1 = LoadClassIdInstr(r3)
    //     0xb97bf0: ldur            x1, [x3, #-1]
    //     0xb97bf4: ubfx            x1, x1, #0xc, #0x14
    // 0xb97bf8: r17 = -5790
    //     0xb97bf8: mov             x17, #-0x169e
    // 0xb97bfc: add             x16, x1, x17
    // 0xb97c00: cmp             x16, #1
    // 0xb97c04: b.hi            #0xb97c2c
    // 0xb97c08: mov             x1, x3
    // 0xb97c0c: ldur            x2, [fp, #-8]
    // 0xb97c10: mov             x3, x0
    // 0xb97c14: r0 = codeUnitAtVisitor()
    //     0xb97c14: bl              #0x12401a8  ; [package:flutter/src/widgets/widget_span.dart] WidgetSpan::codeUnitAtVisitor
    // 0xb97c18: mov             x1, x0
    // 0xb97c1c: ldur            x0, [fp, #-0x40]
    // 0xb97c20: ArrayStore: r0[0] = r1  ; List_4
    //     0xb97c20: stur            w1, [x0, #0x17]
    // 0xb97c24: mov             x1, x0
    // 0xb97c28: b               #0xb97c68
    // 0xb97c2c: mov             x0, x4
    // 0xb97c30: mov             x2, x0
    // 0xb97c34: r1 = Function '<anonymous closure>':.
    //     0xb97c34: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f7e0] AnonymousClosure: (0xb9822c), in [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt (0xb97dec)
    //     0xb97c38: ldr             x1, [x1, #0x7e0]
    // 0xb97c3c: r0 = AllocateClosure()
    //     0xb97c3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb97c40: ldur            x1, [fp, #-0x20]
    // 0xb97c44: r2 = LoadClassIdInstr(r1)
    //     0xb97c44: ldur            x2, [x1, #-1]
    //     0xb97c48: ubfx            x2, x2, #0xc, #0x14
    // 0xb97c4c: mov             x16, x0
    // 0xb97c50: mov             x0, x2
    // 0xb97c54: mov             x2, x16
    // 0xb97c58: r0 = GDT[cid_x0 + -0x18]()
    //     0xb97c58: sub             lr, x0, #0x18
    //     0xb97c5c: ldr             lr, [x21, lr, lsl #3]
    //     0xb97c60: blr             lr
    // 0xb97c64: ldur            x1, [fp, #-0x40]
    // 0xb97c68: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb97c68: ldur            w2, [x1, #0x17]
    // 0xb97c6c: DecompressPointer r2
    //     0xb97c6c: add             x2, x2, HEAP, lsl #32
    // 0xb97c70: mov             x1, x2
    // 0xb97c74: cmp             w1, NULL
    // 0xb97c78: b.eq            #0xb97de8
    // 0xb97c7c: r2 = LoadInt32Instr(r1)
    //     0xb97c7c: sbfx            x2, x1, #1, #0x1f
    // 0xb97c80: cmp             x2, #2, lsl #12
    // 0xb97c84: b.gt            #0xb97d10
    // 0xb97c88: cmp             x2, #0x1d
    // 0xb97c8c: b.gt            #0xb97cd0
    // 0xb97c90: cmp             x2, #0xc
    // 0xb97c94: b.gt            #0xb97cb4
    // 0xb97c98: cmp             x2, #0xa
    // 0xb97c9c: b.gt            #0xb97d6c
    // 0xb97ca0: cmp             x2, #9
    // 0xb97ca4: b.gt            #0xb97d6c
    // 0xb97ca8: cmp             w1, #0x12
    // 0xb97cac: b.ne            #0xb97d84
    // 0xb97cb0: b               #0xb97d6c
    // 0xb97cb4: cmp             x2, #0x1c
    // 0xb97cb8: b.gt            #0xb97d6c
    // 0xb97cbc: cmp             x2, #0xd
    // 0xb97cc0: b.le            #0xb97d6c
    // 0xb97cc4: cmp             x2, #0x1c
    // 0xb97cc8: b.lt            #0xb97d84
    // 0xb97ccc: b               #0xb97d6c
    // 0xb97cd0: cmp             x2, #0x20
    // 0xb97cd4: b.le            #0xb97d6c
    // 0xb97cd8: cmp             x2, #0xa0
    // 0xb97cdc: b.lt            #0xb97d84
    // 0xb97ce0: r17 = 5760
    //     0xb97ce0: mov             x17, #0x1680
    // 0xb97ce4: cmp             x2, x17
    // 0xb97ce8: b.gt            #0xb97d04
    // 0xb97cec: cmp             x2, #0xa0
    // 0xb97cf0: b.le            #0xb97d6c
    // 0xb97cf4: r17 = 5760
    //     0xb97cf4: mov             x17, #0x1680
    // 0xb97cf8: cmp             x2, x17
    // 0xb97cfc: b.lt            #0xb97d84
    // 0xb97d00: b               #0xb97d6c
    // 0xb97d04: cmp             x2, #2, lsl #12
    // 0xb97d08: b.lt            #0xb97d84
    // 0xb97d0c: b               #0xb97d6c
    // 0xb97d10: r17 = 8199
    //     0xb97d10: mov             x17, #0x2007
    // 0xb97d14: cmp             x2, x17
    // 0xb97d18: b.le            #0xb97d6c
    // 0xb97d1c: r17 = 8202
    //     0xb97d1c: mov             x17, #0x200a
    // 0xb97d20: cmp             x2, x17
    // 0xb97d24: b.le            #0xb97d6c
    // 0xb97d28: r17 = 8239
    //     0xb97d28: mov             x17, #0x202f
    // 0xb97d2c: cmp             x2, x17
    // 0xb97d30: b.lt            #0xb97d84
    // 0xb97d34: r17 = 8287
    //     0xb97d34: mov             x17, #0x205f
    // 0xb97d38: cmp             x2, x17
    // 0xb97d3c: b.gt            #0xb97d5c
    // 0xb97d40: r17 = 8239
    //     0xb97d40: mov             x17, #0x202f
    // 0xb97d44: cmp             x2, x17
    // 0xb97d48: b.le            #0xb97d6c
    // 0xb97d4c: r17 = 8287
    //     0xb97d4c: mov             x17, #0x205f
    // 0xb97d50: cmp             x2, x17
    // 0xb97d54: b.lt            #0xb97d84
    // 0xb97d58: b               #0xb97d6c
    // 0xb97d5c: cmp             x2, #3, lsl #12
    // 0xb97d60: b.lt            #0xb97d84
    // 0xb97d64: cmp             w1, #6, lsl #12
    // 0xb97d68: b.ne            #0xb97d84
    // 0xb97d6c: ldur            x1, [fp, #-8]
    // 0xb97d70: add             x6, x1, #1
    // 0xb97d74: ldur            x2, [fp, #-0x38]
    // 0xb97d78: ldur            x3, [fp, #-0x30]
    // 0xb97d7c: ldur            x4, [fp, #-0x28]
    // 0xb97d80: b               #0xb97b64
    // 0xb97d84: ldur            x0, [fp, #-0x38]
    // 0xb97d88: LeaveFrame
    //     0xb97d88: mov             SP, fp
    //     0xb97d8c: ldp             fp, lr, [SP], #0x10
    // 0xb97d90: ret
    //     0xb97d90: ret             
    // 0xb97d94: mov             x1, x3
    // 0xb97d98: sub             x0, x1, #1
    // 0xb97d9c: mov             x1, x0
    // 0xb97da0: ldur            x0, [fp, #-0x10]
    // 0xb97da4: b               #0xb97ad8
    // 0xb97da8: r0 = Null
    //     0xb97da8: mov             x0, NULL
    // 0xb97dac: LeaveFrame
    //     0xb97dac: mov             SP, fp
    //     0xb97db0: ldp             fp, lr, [SP], #0x10
    // 0xb97db4: ret
    //     0xb97db4: ret             
    // 0xb97db8: r0 = Null
    //     0xb97db8: mov             x0, NULL
    // 0xb97dbc: LeaveFrame
    //     0xb97dbc: mov             SP, fp
    //     0xb97dc0: ldp             fp, lr, [SP], #0x10
    // 0xb97dc4: ret
    //     0xb97dc4: ret             
    // 0xb97dc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb97dc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb97dcc: b               #0xb97ac8
    // 0xb97dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb97dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb97dd4: b               #0xb97ae8
    // 0xb97dd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb97dd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb97ddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb97ddc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb97de0: b               #0xb97b78
    // 0xb97de4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb97de4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb97de8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb97de8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ selectWord(/* No info */) {
    // ** addr: 0xba7480, size: 0x4c
    // 0xba7480: EnterFrame
    //     0xba7480: stp             fp, lr, [SP, #-0x10]!
    //     0xba7484: mov             fp, SP
    // 0xba7488: CheckStackOverflow
    //     0xba7488: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba748c: cmp             SP, x16
    //     0xba7490: b.ls            #0xba74c0
    // 0xba7494: r17 = 291
    //     0xba7494: mov             x17, #0x123
    // 0xba7498: ldr             w3, [x1, x17]
    // 0xba749c: DecompressPointer r3
    //     0xba749c: add             x3, x3, HEAP, lsl #32
    // 0xba74a0: cmp             w3, NULL
    // 0xba74a4: b.eq            #0xba74c8
    // 0xba74a8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xba74a8: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xba74ac: r0 = selectWordsInRange()
    //     0xba74ac: bl              #0xb974a8  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectWordsInRange
    // 0xba74b0: r0 = Null
    //     0xba74b0: mov             x0, NULL
    // 0xba74b4: LeaveFrame
    //     0xba74b4: mov             SP, fp
    //     0xba74b8: ldp             fp, lr, [SP], #0x10
    // 0xba74bc: ret
    //     0xba74bc: ret             
    // 0xba74c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba74c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba74c4: b               #0xba7494
    // 0xba74c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba74c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleTapDown(/* No info */) {
    // ** addr: 0xba77e0, size: 0x38
    // 0xba77e0: LoadField: r0 = r2->field_7
    //     0xba77e0: ldur            w0, [x2, #7]
    // 0xba77e4: DecompressPointer r0
    //     0xba77e4: add             x0, x0, HEAP, lsl #32
    // 0xba77e8: r17 = 291
    //     0xba77e8: mov             x17, #0x123
    // 0xba77ec: str             w0, [x1, x17]
    // 0xba77f0: WriteBarrierInstr(obj = r1, val = r0)
    //     0xba77f0: ldurb           w16, [x1, #-1]
    //     0xba77f4: ldurb           w17, [x0, #-1]
    //     0xba77f8: and             x16, x17, x16, lsr #2
    //     0xba77fc: tst             x16, HEAP, lsr #32
    //     0xba7800: b.eq            #0xba7810
    //     0xba7804: str             lr, [SP, #-8]!
    //     0xba7808: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0xba780c: ldr             lr, [SP], #8
    // 0xba7810: r0 = Null
    //     0xba7810: mov             x0, NULL
    // 0xba7814: ret
    //     0xba7814: ret             
  }
  _ selectPosition(/* No info */) {
    // ** addr: 0xba791c, size: 0x4c
    // 0xba791c: EnterFrame
    //     0xba791c: stp             fp, lr, [SP, #-0x10]!
    //     0xba7920: mov             fp, SP
    // 0xba7924: CheckStackOverflow
    //     0xba7924: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba7928: cmp             SP, x16
    //     0xba792c: b.ls            #0xba795c
    // 0xba7930: r17 = 291
    //     0xba7930: mov             x17, #0x123
    // 0xba7934: ldr             w3, [x1, x17]
    // 0xba7938: DecompressPointer r3
    //     0xba7938: add             x3, x3, HEAP, lsl #32
    // 0xba793c: cmp             w3, NULL
    // 0xba7940: b.eq            #0xba7964
    // 0xba7944: r4 = const [0, 0x3, 0, 0x3, null]
    //     0xba7944: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0xba7948: r0 = selectPositionAt()
    //     0xba7948: bl              #0x8793a0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectPositionAt
    // 0xba794c: r0 = Null
    //     0xba794c: mov             x0, NULL
    // 0xba7950: LeaveFrame
    //     0xba7950: mov             SP, fp
    //     0xba7954: ldp             fp, lr, [SP], #0x10
    // 0xba7958: ret
    //     0xba7958: ret             
    // 0xba795c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba795c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7960: b               #0xba7930
    // 0xba7964: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba7964: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbc3570, size: 0x6d0
    // 0xbc3570: EnterFrame
    //     0xbc3570: stp             fp, lr, [SP, #-0x10]!
    //     0xbc3574: mov             fp, SP
    // 0xbc3578: AllocStack(0x58)
    //     0xbc3578: sub             SP, SP, #0x58
    // 0xbc357c: SetupParameters(RenderEditable this /* r1 => r3, fp-0x10 */)
    //     0xbc357c: mov             x3, x1
    //     0xbc3580: stur            x1, [fp, #-0x10]
    // 0xbc3584: CheckStackOverflow
    //     0xbc3584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc3588: cmp             SP, x16
    //     0xbc358c: b.ls            #0xbc3b84
    // 0xbc3590: LoadField: r4 = r3->field_27
    //     0xbc3590: ldur            w4, [x3, #0x27]
    // 0xbc3594: DecompressPointer r4
    //     0xbc3594: add             x4, x4, HEAP, lsl #32
    // 0xbc3598: stur            x4, [fp, #-8]
    // 0xbc359c: cmp             w4, NULL
    // 0xbc35a0: b.eq            #0xbc3b68
    // 0xbc35a4: mov             x0, x4
    // 0xbc35a8: r2 = Null
    //     0xbc35a8: mov             x2, NULL
    // 0xbc35ac: r1 = Null
    //     0xbc35ac: mov             x1, NULL
    // 0xbc35b0: r4 = LoadClassIdInstr(r0)
    //     0xbc35b0: ldur            x4, [x0, #-1]
    //     0xbc35b4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc35b8: sub             x4, x4, #0xb46
    // 0xbc35bc: cmp             x4, #1
    // 0xbc35c0: b.ls            #0xbc35d4
    // 0xbc35c4: r8 = BoxConstraints
    //     0xbc35c4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc35c8: r3 = Null
    //     0xbc35c8: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd608] Null
    //     0xbc35cc: ldr             x3, [x3, #0x608]
    // 0xbc35d0: r0 = BoxConstraints()
    //     0xbc35d0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc35d4: ldur            x0, [fp, #-8]
    // 0xbc35d8: LoadField: d1 = r0->field_f
    //     0xbc35d8: ldur            d1, [x0, #0xf]
    // 0xbc35dc: ldur            x1, [fp, #-0x10]
    // 0xbc35e0: mov             v0.16b, v1.16b
    // 0xbc35e4: stur            d1, [fp, #-0x30]
    // 0xbc35e8: r2 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbc35e8: add             x2, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbc35ec: ldr             x2, [x2, #0x4f8]
    // 0xbc35f0: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getBaseline': static.
    //     0xbc35f0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90750] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getBaseline': static. (0x7f2adaaa6ca0)
    //     0xbc35f4: ldr             x3, [x3, #0x750]
    // 0xbc35f8: r0 = layoutInlineChildren()
    //     0xbc35f8: bl              #0xb1d4b8  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xbc35fc: ldur            x2, [fp, #-0x10]
    // 0xbc3600: r17 = 299
    //     0xbc3600: mov             x17, #0x12b
    // 0xbc3604: str             w0, [x2, x17]
    // 0xbc3608: WriteBarrierInstr(obj = r2, val = r0)
    //     0xbc3608: ldurb           w16, [x2, #-1]
    //     0xbc360c: ldurb           w17, [x0, #-1]
    //     0xbc3610: and             x16, x17, x16, lsr #2
    //     0xbc3614: tst             x16, HEAP, lsr #32
    //     0xbc3618: b.eq            #0xbc3620
    //     0xbc361c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc3620: ldur            x0, [fp, #-8]
    // 0xbc3624: LoadField: d0 = r0->field_7
    //     0xbc3624: ldur            d0, [x0, #7]
    // 0xbc3628: r1 = inline_Allocate_Double()
    //     0xbc3628: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xbc362c: add             x1, x1, #0x10
    //     0xbc3630: cmp             x3, x1
    //     0xbc3634: b.ls            #0xbc3b8c
    //     0xbc3638: str             x1, [THR, #0x60]  ; THR::top
    //     0xbc363c: sub             x1, x1, #0xf
    //     0xbc3640: mov             x3, #0xe19c
    //     0xbc3644: movk            x3, #3, lsl #16
    //     0xbc3648: stur            x3, [x1, #-1]
    // 0xbc364c: dmb             ishst
    // 0xbc3650: StoreField: r1->field_7 = d0
    //     0xbc3650: stur            d0, [x1, #7]
    // 0xbc3654: ldur            d0, [fp, #-0x30]
    // 0xbc3658: r3 = inline_Allocate_Double()
    //     0xbc3658: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbc365c: add             x3, x3, #0x10
    //     0xbc3660: cmp             x4, x3
    //     0xbc3664: b.ls            #0xbc3ba8
    //     0xbc3668: str             x3, [THR, #0x60]  ; THR::top
    //     0xbc366c: sub             x3, x3, #0xf
    //     0xbc3670: mov             x4, #0xe19c
    //     0xbc3674: movk            x4, #3, lsl #16
    //     0xbc3678: stur            x4, [x3, #-1]
    // 0xbc367c: dmb             ishst
    // 0xbc3680: StoreField: r3->field_7 = d0
    //     0xbc3680: stur            d0, [x3, #7]
    // 0xbc3684: stp             x3, x1, [SP]
    // 0xbc3688: mov             x1, x2
    // 0xbc368c: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xbc368c: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xbc3690: r0 = _adjustConstraints()
    //     0xbc3690: bl              #0x860b7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_adjustConstraints
    // 0xbc3694: mov             x3, x0
    // 0xbc3698: stur            x3, [fp, #-0x28]
    // 0xbc369c: mov             x4, x1
    // 0xbc36a0: ldur            x0, [fp, #-0x10]
    // 0xbc36a4: stur            x4, [fp, #-0x20]
    // 0xbc36a8: LoadField: r5 = r0->field_a7
    //     0xbc36a8: ldur            w5, [x0, #0xa7]
    // 0xbc36ac: DecompressPointer r5
    //     0xbc36ac: add             x5, x5, HEAP, lsl #32
    // 0xbc36b0: stur            x5, [fp, #-0x18]
    // 0xbc36b4: r17 = 299
    //     0xbc36b4: mov             x17, #0x12b
    // 0xbc36b8: ldr             w2, [x0, x17]
    // 0xbc36bc: DecompressPointer r2
    //     0xbc36bc: add             x2, x2, HEAP, lsl #32
    // 0xbc36c0: mov             x1, x5
    // 0xbc36c4: r0 = setPlaceholderDimensions()
    //     0xbc36c4: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xbc36c8: ldur            x16, [fp, #-0x28]
    // 0xbc36cc: ldur            lr, [fp, #-0x20]
    // 0xbc36d0: stp             lr, x16, [SP]
    // 0xbc36d4: ldur            x1, [fp, #-0x18]
    // 0xbc36d8: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xbc36d8: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xbc36dc: r0 = layout()
    //     0xbc36dc: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xbc36e0: ldur            x1, [fp, #-0x18]
    // 0xbc36e4: r0 = inlinePlaceholderBoxes()
    //     0xbc36e4: bl              #0xbc401c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::inlinePlaceholderBoxes
    // 0xbc36e8: cmp             w0, NULL
    // 0xbc36ec: b.eq            #0xbc3bcc
    // 0xbc36f0: ldur            x1, [fp, #-0x10]
    // 0xbc36f4: mov             x2, x0
    // 0xbc36f8: r0 = positionInlineChildren()
    //     0xbc36f8: bl              #0xbc3e04  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::positionInlineChildren
    // 0xbc36fc: ldur            x1, [fp, #-0x10]
    // 0xbc3700: r0 = _computeCaretPrototype()
    //     0xbc3700: bl              #0xbc3d4c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeCaretPrototype
    // 0xbc3704: ldur            x0, [fp, #-0x10]
    // 0xbc3708: LoadField: r1 = r0->field_c3
    //     0xbc3708: ldur            w1, [x0, #0xc3]
    // 0xbc370c: DecompressPointer r1
    //     0xbc370c: add             x1, x1, HEAP, lsl #32
    // 0xbc3710: tbnz            w1, #4, #0xbc371c
    // 0xbc3714: ldur            d0, [fp, #-0x30]
    // 0xbc3718: b               #0xbc3784
    // 0xbc371c: ldur            x2, [fp, #-0x18]
    // 0xbc3720: d0 = 1.000000
    //     0xbc3720: fmov            d0, #1.00000000
    // 0xbc3724: LoadField: r1 = r2->field_7
    //     0xbc3724: ldur            w1, [x2, #7]
    // 0xbc3728: DecompressPointer r1
    //     0xbc3728: add             x1, x1, HEAP, lsl #32
    // 0xbc372c: cmp             w1, NULL
    // 0xbc3730: b.eq            #0xbc3bd0
    // 0xbc3734: LoadField: d1 = r1->field_13
    //     0xbc3734: ldur            d1, [x1, #0x13]
    // 0xbc3738: LoadField: d2 = r0->field_df
    //     0xbc3738: ldur            d2, [x0, #0xdf]
    // 0xbc373c: fadd            d3, d2, d0
    // 0xbc3740: fadd            d2, d1, d3
    // 0xbc3744: r1 = inline_Allocate_Double()
    //     0xbc3744: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xbc3748: add             x1, x1, #0x10
    //     0xbc374c: cmp             x3, x1
    //     0xbc3750: b.ls            #0xbc3bd4
    //     0xbc3754: str             x1, [THR, #0x60]  ; THR::top
    //     0xbc3758: sub             x1, x1, #0xf
    //     0xbc375c: mov             x3, #0xe19c
    //     0xbc3760: movk            x3, #3, lsl #16
    //     0xbc3764: stur            x3, [x1, #-1]
    // 0xbc3768: dmb             ishst
    // 0xbc376c: StoreField: r1->field_7 = d2
    //     0xbc376c: stur            d2, [x1, #7]
    // 0xbc3770: str             x1, [SP]
    // 0xbc3774: ldur            x1, [fp, #-8]
    // 0xbc3778: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbc3778: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbc377c: r0 = constrainWidth()
    //     0xbc377c: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xbc3780: ldur            x0, [fp, #-0x10]
    // 0xbc3784: stur            d0, [fp, #-0x30]
    // 0xbc3788: LoadField: r2 = r0->field_cb
    //     0xbc3788: ldur            w2, [x0, #0xcb]
    // 0xbc378c: DecompressPointer r2
    //     0xbc378c: add             x2, x2, HEAP, lsl #32
    // 0xbc3790: stur            x2, [fp, #-0x20]
    // 0xbc3794: cmp             w2, NULL
    // 0xbc3798: b.ne            #0xbc37cc
    // 0xbc379c: ldur            x1, [fp, #-0x18]
    // 0xbc37a0: r0 = height()
    //     0xbc37a0: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0xbc37a4: ldur            x1, [fp, #-0x18]
    // 0xbc37a8: stur            d0, [fp, #-0x38]
    // 0xbc37ac: r0 = preferredLineHeight()
    //     0xbc37ac: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0xbc37b0: mov             v1.16b, v0.16b
    // 0xbc37b4: d0 = 0.000000
    //     0xbc37b4: eor             v0.16b, v0.16b, v0.16b
    // 0xbc37b8: fmul            d2, d1, d0
    // 0xbc37bc: ldur            d1, [fp, #-0x38]
    // 0xbc37c0: fmax            v3.2d, v1.2d, v2.2d
    // 0xbc37c4: mov             v1.16b, v3.16b
    // 0xbc37c8: b               #0xbc3860
    // 0xbc37cc: d0 = 0.000000
    //     0xbc37cc: eor             v0.16b, v0.16b, v0.16b
    // 0xbc37d0: cmp             w2, #2
    // 0xbc37d4: b.ne            #0xbc37e8
    // 0xbc37d8: ldur            x1, [fp, #-0x18]
    // 0xbc37dc: r0 = height()
    //     0xbc37dc: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0xbc37e0: mov             v1.16b, v0.16b
    // 0xbc37e4: b               #0xbc3860
    // 0xbc37e8: ldur            x1, [fp, #-0x18]
    // 0xbc37ec: r0 = height()
    //     0xbc37ec: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0xbc37f0: ldur            x1, [fp, #-0x18]
    // 0xbc37f4: stur            d0, [fp, #-0x38]
    // 0xbc37f8: r0 = preferredLineHeight()
    //     0xbc37f8: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0xbc37fc: ldur            x0, [fp, #-0x20]
    // 0xbc3800: r16 = LoadInt32Instr(r0)
    //     0xbc3800: sbfx            x16, x0, #1, #0x1f
    // 0xbc3804: scvtf           d1, w16
    // 0xbc3808: stur            d1, [fp, #-0x48]
    // 0xbc380c: fmul            d2, d0, d1
    // 0xbc3810: ldur            x1, [fp, #-0x18]
    // 0xbc3814: stur            d2, [fp, #-0x40]
    // 0xbc3818: r0 = preferredLineHeight()
    //     0xbc3818: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0xbc381c: mov             v1.16b, v0.16b
    // 0xbc3820: ldur            d0, [fp, #-0x48]
    // 0xbc3824: fmul            d2, d1, d0
    // 0xbc3828: ldur            d1, [fp, #-0x38]
    // 0xbc382c: ldur            d0, [fp, #-0x40]
    // 0xbc3830: fcmp            d0, d1
    // 0xbc3834: b.gt            #0xbc385c
    // 0xbc3838: fcmp            d1, d2
    // 0xbc383c: b.le            #0xbc3848
    // 0xbc3840: mov             v0.16b, v2.16b
    // 0xbc3844: b               #0xbc385c
    // 0xbc3848: fcmp            d1, d1
    // 0xbc384c: b.vc            #0xbc3858
    // 0xbc3850: mov             v0.16b, v2.16b
    // 0xbc3854: b               #0xbc385c
    // 0xbc3858: mov             v0.16b, v1.16b
    // 0xbc385c: mov             v1.16b, v0.16b
    // 0xbc3860: ldur            x0, [fp, #-0x10]
    // 0xbc3864: ldur            x2, [fp, #-0x18]
    // 0xbc3868: ldur            d0, [fp, #-0x30]
    // 0xbc386c: r1 = inline_Allocate_Double()
    //     0xbc386c: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xbc3870: add             x1, x1, #0x10
    //     0xbc3874: cmp             x3, x1
    //     0xbc3878: b.ls            #0xbc3bf0
    //     0xbc387c: str             x1, [THR, #0x60]  ; THR::top
    //     0xbc3880: sub             x1, x1, #0xf
    //     0xbc3884: mov             x3, #0xe19c
    //     0xbc3888: movk            x3, #3, lsl #16
    //     0xbc388c: stur            x3, [x1, #-1]
    // 0xbc3890: dmb             ishst
    // 0xbc3894: StoreField: r1->field_7 = d1
    //     0xbc3894: stur            d1, [x1, #7]
    // 0xbc3898: str             x1, [SP]
    // 0xbc389c: ldur            x1, [fp, #-8]
    // 0xbc38a0: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbc38a0: ldr             x4, [PP, #0xd00]  ; [pp+0xd00] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbc38a4: r0 = constrainHeight()
    //     0xbc38a4: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xbc38a8: stur            d0, [fp, #-0x38]
    // 0xbc38ac: r0 = Size()
    //     0xbc38ac: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc38b0: ldur            d0, [fp, #-0x30]
    // 0xbc38b4: StoreField: r0->field_7 = d0
    //     0xbc38b4: stur            d0, [x0, #7]
    // 0xbc38b8: ldur            d0, [fp, #-0x38]
    // 0xbc38bc: StoreField: r0->field_f = d0
    //     0xbc38bc: stur            d0, [x0, #0xf]
    // 0xbc38c0: ldur            x2, [fp, #-0x10]
    // 0xbc38c4: StoreField: r2->field_4b = r0
    //     0xbc38c4: stur            w0, [x2, #0x4b]
    //     0xbc38c8: ldurb           w16, [x2, #-1]
    //     0xbc38cc: ldurb           w17, [x0, #-1]
    //     0xbc38d0: and             x16, x17, x16, lsr #2
    //     0xbc38d4: tst             x16, HEAP, lsr #32
    //     0xbc38d8: b.eq            #0xbc38e0
    //     0xbc38dc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc38e0: ldur            x1, [fp, #-0x18]
    // 0xbc38e4: LoadField: r0 = r1->field_7
    //     0xbc38e4: ldur            w0, [x1, #7]
    // 0xbc38e8: DecompressPointer r0
    //     0xbc38e8: add             x0, x0, HEAP, lsl #32
    // 0xbc38ec: cmp             w0, NULL
    // 0xbc38f0: b.eq            #0xbc3c0c
    // 0xbc38f4: LoadField: d0 = r0->field_13
    //     0xbc38f4: ldur            d0, [x0, #0x13]
    // 0xbc38f8: LoadField: d1 = r2->field_df
    //     0xbc38f8: ldur            d1, [x2, #0xdf]
    // 0xbc38fc: d2 = 1.000000
    //     0xbc38fc: fmov            d2, #1.00000000
    // 0xbc3900: fadd            d3, d1, d2
    // 0xbc3904: fadd            d1, d0, d3
    // 0xbc3908: stur            d1, [fp, #-0x30]
    // 0xbc390c: r0 = height()
    //     0xbc390c: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0xbc3910: stur            d0, [fp, #-0x38]
    // 0xbc3914: r0 = Size()
    //     0xbc3914: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc3918: ldur            d0, [fp, #-0x30]
    // 0xbc391c: stur            x0, [fp, #-8]
    // 0xbc3920: StoreField: r0->field_7 = d0
    //     0xbc3920: stur            d0, [x0, #7]
    // 0xbc3924: ldur            d1, [fp, #-0x38]
    // 0xbc3928: StoreField: r0->field_f = d1
    //     0xbc3928: stur            d1, [x0, #0xf]
    // 0xbc392c: r0 = BoxConstraints()
    //     0xbc392c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbc3930: ldur            d0, [fp, #-0x30]
    // 0xbc3934: stur            x0, [fp, #-0x18]
    // 0xbc3938: StoreField: r0->field_7 = d0
    //     0xbc3938: stur            d0, [x0, #7]
    // 0xbc393c: StoreField: r0->field_f = d0
    //     0xbc393c: stur            d0, [x0, #0xf]
    // 0xbc3940: ldur            d0, [fp, #-0x38]
    // 0xbc3944: ArrayStore: r0[0] = d0  ; List_8
    //     0xbc3944: stur            d0, [x0, #0x17]
    // 0xbc3948: StoreField: r0->field_1f = d0
    //     0xbc3948: stur            d0, [x0, #0x1f]
    // 0xbc394c: ldur            x3, [fp, #-0x10]
    // 0xbc3950: LoadField: r1 = r3->field_63
    //     0xbc3950: ldur            w1, [x3, #0x63]
    // 0xbc3954: DecompressPointer r1
    //     0xbc3954: add             x1, x1, HEAP, lsl #32
    // 0xbc3958: cmp             w1, NULL
    // 0xbc395c: b.ne            #0xbc3968
    // 0xbc3960: mov             x0, x3
    // 0xbc3964: b               #0xbc3978
    // 0xbc3968: mov             x2, x0
    // 0xbc396c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbc396c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbc3970: r0 = layout()
    //     0xbc3970: bl              #0xcd00ac  ; [package:flutter/src/rendering/object.dart] RenderObject::layout
    // 0xbc3974: ldur            x0, [fp, #-0x10]
    // 0xbc3978: LoadField: r1 = r0->field_67
    //     0xbc3978: ldur            w1, [x0, #0x67]
    // 0xbc397c: DecompressPointer r1
    //     0xbc397c: add             x1, x1, HEAP, lsl #32
    // 0xbc3980: cmp             w1, NULL
    // 0xbc3984: b.eq            #0xbc3998
    // 0xbc3988: ldur            x2, [fp, #-0x18]
    // 0xbc398c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbc398c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbc3990: r0 = layout()
    //     0xbc3990: bl              #0xcd00ac  ; [package:flutter/src/rendering/object.dart] RenderObject::layout
    // 0xbc3994: ldur            x0, [fp, #-0x10]
    // 0xbc3998: mov             x1, x0
    // 0xbc399c: ldur            x2, [fp, #-8]
    // 0xbc39a0: r0 = _getMaxScrollExtent()
    //     0xbc39a0: bl              #0xbc3ca8  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_getMaxScrollExtent
    // 0xbc39a4: r0 = inline_Allocate_Double()
    //     0xbc39a4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc39a8: add             x0, x0, #0x10
    //     0xbc39ac: cmp             x1, x0
    //     0xbc39b0: b.ls            #0xbc3c10
    //     0xbc39b4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc39b8: sub             x0, x0, #0xf
    //     0xbc39bc: mov             x1, #0xe19c
    //     0xbc39c0: movk            x1, #3, lsl #16
    //     0xbc39c4: stur            x1, [x0, #-1]
    // 0xbc39c8: dmb             ishst
    // 0xbc39cc: StoreField: r0->field_7 = d0
    //     0xbc39cc: stur            d0, [x0, #7]
    // 0xbc39d0: ldur            x2, [fp, #-0x10]
    // 0xbc39d4: r17 = 263
    //     0xbc39d4: mov             x17, #0x107
    // 0xbc39d8: str             w0, [x2, x17]
    // 0xbc39dc: WriteBarrierInstr(obj = r2, val = r0)
    //     0xbc39dc: ldurb           w16, [x2, #-1]
    //     0xbc39e0: ldurb           w17, [x0, #-1]
    //     0xbc39e4: and             x16, x17, x16, lsr #2
    //     0xbc39e8: tst             x16, HEAP, lsr #32
    //     0xbc39ec: b.eq            #0xbc39f4
    //     0xbc39f0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbc39f4: LoadField: r0 = r2->field_db
    //     0xbc39f4: ldur            w0, [x2, #0xdb]
    // 0xbc39f8: DecompressPointer r0
    //     0xbc39f8: add             x0, x0, HEAP, lsl #32
    // 0xbc39fc: mov             x1, x2
    // 0xbc3a00: stur            x0, [fp, #-8]
    // 0xbc3a04: r0 = _viewportExtent()
    //     0xbc3a04: bl              #0xbc3c40  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_viewportExtent
    // 0xbc3a08: ldur            x1, [fp, #-8]
    // 0xbc3a0c: r0 = LoadClassIdInstr(r1)
    //     0xbc3a0c: ldur            x0, [x1, #-1]
    //     0xbc3a10: ubfx            x0, x0, #0xc, #0x14
    // 0xbc3a14: r17 = -4542
    //     0xbc3a14: mov             x17, #-0x11be
    // 0xbc3a18: add             x16, x0, x17
    // 0xbc3a1c: cmp             x16, #1
    // 0xbc3a20: b.ls            #0xbc3a30
    // 0xbc3a24: r17 = 4540
    //     0xbc3a24: mov             x17, #0x11bc
    // 0xbc3a28: cmp             x0, x17
    // 0xbc3a2c: b.ne            #0xbc3ab8
    // 0xbc3a30: LoadField: r0 = r1->field_43
    //     0xbc3a30: ldur            w0, [x1, #0x43]
    // 0xbc3a34: DecompressPointer r0
    //     0xbc3a34: add             x0, x0, HEAP, lsl #32
    // 0xbc3a38: r2 = inline_Allocate_Double()
    //     0xbc3a38: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbc3a3c: add             x2, x2, #0x10
    //     0xbc3a40: cmp             x3, x2
    //     0xbc3a44: b.ls            #0xbc3c20
    //     0xbc3a48: str             x2, [THR, #0x60]  ; THR::top
    //     0xbc3a4c: sub             x2, x2, #0xf
    //     0xbc3a50: mov             x3, #0xe19c
    //     0xbc3a54: movk            x3, #3, lsl #16
    //     0xbc3a58: stur            x3, [x2, #-1]
    // 0xbc3a5c: dmb             ishst
    // 0xbc3a60: StoreField: r2->field_7 = d0
    //     0xbc3a60: stur            d0, [x2, #7]
    // 0xbc3a64: stur            x2, [fp, #-0x18]
    // 0xbc3a68: r3 = LoadClassIdInstr(r0)
    //     0xbc3a68: ldur            x3, [x0, #-1]
    //     0xbc3a6c: ubfx            x3, x3, #0xc, #0x14
    // 0xbc3a70: stp             x2, x0, [SP]
    // 0xbc3a74: mov             x0, x3
    // 0xbc3a78: mov             lr, x0
    // 0xbc3a7c: ldr             lr, [x21, lr, lsl #3]
    // 0xbc3a80: blr             lr
    // 0xbc3a84: tbz             w0, #4, #0xbc3acc
    // 0xbc3a88: ldur            x1, [fp, #-8]
    // 0xbc3a8c: r2 = true
    //     0xbc3a8c: add             x2, NULL, #0x20  ; true
    // 0xbc3a90: ldur            x0, [fp, #-0x18]
    // 0xbc3a94: StoreField: r1->field_43 = r0
    //     0xbc3a94: stur            w0, [x1, #0x43]
    //     0xbc3a98: ldurb           w16, [x1, #-1]
    //     0xbc3a9c: ldurb           w17, [x0, #-1]
    //     0xbc3aa0: and             x16, x17, x16, lsr #2
    //     0xbc3aa4: tst             x16, HEAP, lsr #32
    //     0xbc3aa8: b.eq            #0xbc3ab0
    //     0xbc3aac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc3ab0: StoreField: r1->field_4b = r2
    //     0xbc3ab0: stur            w2, [x1, #0x4b]
    // 0xbc3ab4: b               #0xbc3acc
    // 0xbc3ab8: r0 = LoadClassIdInstr(r1)
    //     0xbc3ab8: ldur            x0, [x1, #-1]
    //     0xbc3abc: ubfx            x0, x0, #0xc, #0x14
    // 0xbc3ac0: r0 = GDT[cid_x0 + -0x1b0]()
    //     0xbc3ac0: sub             lr, x0, #0x1b0
    //     0xbc3ac4: ldr             lr, [x21, lr, lsl #3]
    //     0xbc3ac8: blr             lr
    // 0xbc3acc: ldur            x0, [fp, #-0x10]
    // 0xbc3ad0: LoadField: r1 = r0->field_db
    //     0xbc3ad0: ldur            w1, [x0, #0xdb]
    // 0xbc3ad4: DecompressPointer r1
    //     0xbc3ad4: add             x1, x1, HEAP, lsl #32
    // 0xbc3ad8: r17 = 263
    //     0xbc3ad8: mov             x17, #0x107
    // 0xbc3adc: ldr             w2, [x0, x17]
    // 0xbc3ae0: DecompressPointer r2
    //     0xbc3ae0: add             x2, x2, HEAP, lsl #32
    // 0xbc3ae4: r0 = LoadClassIdInstr(r1)
    //     0xbc3ae4: ldur            x0, [x1, #-1]
    //     0xbc3ae8: ubfx            x0, x0, #0xc, #0x14
    // 0xbc3aec: r17 = 4541
    //     0xbc3aec: mov             x17, #0x11bd
    // 0xbc3af0: cmp             x0, x17
    // 0xbc3af4: b.ne            #0xbc3b3c
    // 0xbc3af8: d0 = 0.000000
    //     0xbc3af8: eor             v0.16b, v0.16b, v0.16b
    // 0xbc3afc: d1 = 2.000000
    //     0xbc3afc: fmov            d1, #2.00000000
    // 0xbc3b00: LoadField: r0 = r1->field_43
    //     0xbc3b00: ldur            w0, [x1, #0x43]
    // 0xbc3b04: DecompressPointer r0
    //     0xbc3b04: add             x0, x0, HEAP, lsl #32
    // 0xbc3b08: cmp             w0, NULL
    // 0xbc3b0c: b.eq            #0xbc3c3c
    // 0xbc3b10: LoadField: d2 = r0->field_7
    //     0xbc3b10: ldur            d2, [x0, #7]
    // 0xbc3b14: fmul            d3, d2, d0
    // 0xbc3b18: fdiv            d2, d3, d1
    // 0xbc3b1c: fmax            v1.2d, v0.2d, v2.2d
    // 0xbc3b20: fadd            d2, d1, d0
    // 0xbc3b24: LoadField: d0 = r2->field_7
    //     0xbc3b24: ldur            d0, [x2, #7]
    // 0xbc3b28: fsub            d3, d0, d1
    // 0xbc3b2c: fmax            v1.2d, v2.2d, v3.2d
    // 0xbc3b30: mov             v0.16b, v2.16b
    // 0xbc3b34: r0 = applyContentDimensions()
    //     0xbc3b34: bl              #0x12859f8  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xbc3b38: b               #0xbc3b58
    // 0xbc3b3c: d0 = 0.000000
    //     0xbc3b3c: eor             v0.16b, v0.16b, v0.16b
    // 0xbc3b40: LoadField: d1 = r2->field_7
    //     0xbc3b40: ldur            d1, [x2, #7]
    // 0xbc3b44: r0 = LoadClassIdInstr(r1)
    //     0xbc3b44: ldur            x0, [x1, #-1]
    //     0xbc3b48: ubfx            x0, x0, #0xc, #0x14
    // 0xbc3b4c: r0 = GDT[cid_x0 + -0x1cd]()
    //     0xbc3b4c: sub             lr, x0, #0x1cd
    //     0xbc3b50: ldr             lr, [x21, lr, lsl #3]
    //     0xbc3b54: blr             lr
    // 0xbc3b58: r0 = Null
    //     0xbc3b58: mov             x0, NULL
    // 0xbc3b5c: LeaveFrame
    //     0xbc3b5c: mov             SP, fp
    //     0xbc3b60: ldp             fp, lr, [SP], #0x10
    // 0xbc3b64: ret
    //     0xbc3b64: ret             
    // 0xbc3b68: r0 = StateError()
    //     0xbc3b68: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc3b6c: mov             x1, x0
    // 0xbc3b70: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc3b70: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc3b74: StoreField: r1->field_b = r0
    //     0xbc3b74: stur            w0, [x1, #0xb]
    // 0xbc3b78: mov             x0, x1
    // 0xbc3b7c: r0 = Throw()
    //     0xbc3b7c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc3b80: brk             #0
    // 0xbc3b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc3b84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc3b88: b               #0xbc3590
    // 0xbc3b8c: SaveReg d0
    //     0xbc3b8c: str             q0, [SP, #-0x10]!
    // 0xbc3b90: stp             x0, x2, [SP, #-0x10]!
    // 0xbc3b94: r0 = AllocateDouble()
    //     0xbc3b94: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc3b98: mov             x1, x0
    // 0xbc3b9c: ldp             x0, x2, [SP], #0x10
    // 0xbc3ba0: RestoreReg d0
    //     0xbc3ba0: ldr             q0, [SP], #0x10
    // 0xbc3ba4: b               #0xbc3650
    // 0xbc3ba8: SaveReg d0
    //     0xbc3ba8: str             q0, [SP, #-0x10]!
    // 0xbc3bac: stp             x1, x2, [SP, #-0x10]!
    // 0xbc3bb0: SaveReg r0
    //     0xbc3bb0: str             x0, [SP, #-8]!
    // 0xbc3bb4: r0 = AllocateDouble()
    //     0xbc3bb4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc3bb8: mov             x3, x0
    // 0xbc3bbc: RestoreReg r0
    //     0xbc3bbc: ldr             x0, [SP], #8
    // 0xbc3bc0: ldp             x1, x2, [SP], #0x10
    // 0xbc3bc4: RestoreReg d0
    //     0xbc3bc4: ldr             q0, [SP], #0x10
    // 0xbc3bc8: b               #0xbc3680
    // 0xbc3bcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc3bcc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc3bd0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc3bd0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc3bd4: stp             q0, q2, [SP, #-0x20]!
    // 0xbc3bd8: stp             x0, x2, [SP, #-0x10]!
    // 0xbc3bdc: r0 = AllocateDouble()
    //     0xbc3bdc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc3be0: mov             x1, x0
    // 0xbc3be4: ldp             x0, x2, [SP], #0x10
    // 0xbc3be8: ldp             q0, q2, [SP], #0x20
    // 0xbc3bec: b               #0xbc376c
    // 0xbc3bf0: stp             q0, q1, [SP, #-0x20]!
    // 0xbc3bf4: stp             x0, x2, [SP, #-0x10]!
    // 0xbc3bf8: r0 = AllocateDouble()
    //     0xbc3bf8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc3bfc: mov             x1, x0
    // 0xbc3c00: ldp             x0, x2, [SP], #0x10
    // 0xbc3c04: ldp             q0, q1, [SP], #0x20
    // 0xbc3c08: b               #0xbc3894
    // 0xbc3c0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc3c0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc3c10: SaveReg d0
    //     0xbc3c10: str             q0, [SP, #-0x10]!
    // 0xbc3c14: r0 = AllocateDouble()
    //     0xbc3c14: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc3c18: RestoreReg d0
    //     0xbc3c18: ldr             q0, [SP], #0x10
    // 0xbc3c1c: b               #0xbc39cc
    // 0xbc3c20: SaveReg d0
    //     0xbc3c20: str             q0, [SP, #-0x10]!
    // 0xbc3c24: stp             x0, x1, [SP, #-0x10]!
    // 0xbc3c28: r0 = AllocateDouble()
    //     0xbc3c28: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc3c2c: mov             x2, x0
    // 0xbc3c30: ldp             x0, x1, [SP], #0x10
    // 0xbc3c34: RestoreReg d0
    //     0xbc3c34: ldr             q0, [SP], #0x10
    // 0xbc3c38: b               #0xbc3a60
    // 0xbc3c3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc3c3c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ _viewportExtent(/* No info */) {
    // ** addr: 0xbc3c40, size: 0x68
    // 0xbc3c40: EnterFrame
    //     0xbc3c40: stp             fp, lr, [SP, #-0x10]!
    //     0xbc3c44: mov             fp, SP
    // 0xbc3c48: CheckStackOverflow
    //     0xbc3c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc3c4c: cmp             SP, x16
    //     0xbc3c50: b.ls            #0xbc3ca0
    // 0xbc3c54: LoadField: r0 = r1->field_cb
    //     0xbc3c54: ldur            w0, [x1, #0xcb]
    // 0xbc3c58: DecompressPointer r0
    //     0xbc3c58: add             x0, x0, HEAP, lsl #32
    // 0xbc3c5c: cmp             w0, #2
    // 0xbc3c60: b.eq            #0xbc3c6c
    // 0xbc3c64: r0 = Instance_Axis
    //     0xbc3c64: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbc3c68: b               #0xbc3c70
    // 0xbc3c6c: r0 = Instance_Axis
    //     0xbc3c6c: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xbc3c70: LoadField: r2 = r0->field_7
    //     0xbc3c70: ldur            x2, [x0, #7]
    // 0xbc3c74: cmp             x2, #0
    // 0xbc3c78: b.gt            #0xbc3c88
    // 0xbc3c7c: r0 = size()
    //     0xbc3c7c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc3c80: LoadField: d0 = r0->field_7
    //     0xbc3c80: ldur            d0, [x0, #7]
    // 0xbc3c84: b               #0xbc3c94
    // 0xbc3c88: r0 = size()
    //     0xbc3c88: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc3c8c: LoadField: d1 = r0->field_f
    //     0xbc3c8c: ldur            d1, [x0, #0xf]
    // 0xbc3c90: mov             v0.16b, v1.16b
    // 0xbc3c94: LeaveFrame
    //     0xbc3c94: mov             SP, fp
    //     0xbc3c98: ldp             fp, lr, [SP], #0x10
    // 0xbc3c9c: ret
    //     0xbc3c9c: ret             
    // 0xbc3ca0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc3ca0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc3ca4: b               #0xbc3c54
  }
  _ _getMaxScrollExtent(/* No info */) {
    // ** addr: 0xbc3ca8, size: 0xa4
    // 0xbc3ca8: EnterFrame
    //     0xbc3ca8: stp             fp, lr, [SP, #-0x10]!
    //     0xbc3cac: mov             fp, SP
    // 0xbc3cb0: AllocStack(0x8)
    //     0xbc3cb0: sub             SP, SP, #8
    // 0xbc3cb4: CheckStackOverflow
    //     0xbc3cb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc3cb8: cmp             SP, x16
    //     0xbc3cbc: b.ls            #0xbc3d44
    // 0xbc3cc0: LoadField: r0 = r1->field_cb
    //     0xbc3cc0: ldur            w0, [x1, #0xcb]
    // 0xbc3cc4: DecompressPointer r0
    //     0xbc3cc4: add             x0, x0, HEAP, lsl #32
    // 0xbc3cc8: cmp             w0, #2
    // 0xbc3ccc: b.eq            #0xbc3cd8
    // 0xbc3cd0: r0 = Instance_Axis
    //     0xbc3cd0: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbc3cd4: b               #0xbc3cdc
    // 0xbc3cd8: r0 = Instance_Axis
    //     0xbc3cd8: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xbc3cdc: LoadField: r3 = r0->field_7
    //     0xbc3cdc: ldur            x3, [x0, #7]
    // 0xbc3ce0: cmp             x3, #0
    // 0xbc3ce4: b.gt            #0xbc3d10
    // 0xbc3ce8: LoadField: d0 = r2->field_7
    //     0xbc3ce8: ldur            d0, [x2, #7]
    // 0xbc3cec: stur            d0, [fp, #-8]
    // 0xbc3cf0: r0 = size()
    //     0xbc3cf0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc3cf4: LoadField: d0 = r0->field_7
    //     0xbc3cf4: ldur            d0, [x0, #7]
    // 0xbc3cf8: ldur            d1, [fp, #-8]
    // 0xbc3cfc: fsub            d2, d1, d0
    // 0xbc3d00: d0 = 0.000000
    //     0xbc3d00: eor             v0.16b, v0.16b, v0.16b
    // 0xbc3d04: fmax            v1.2d, v0.2d, v2.2d
    // 0xbc3d08: mov             v0.16b, v1.16b
    // 0xbc3d0c: b               #0xbc3d38
    // 0xbc3d10: d0 = 0.000000
    //     0xbc3d10: eor             v0.16b, v0.16b, v0.16b
    // 0xbc3d14: LoadField: d1 = r2->field_f
    //     0xbc3d14: ldur            d1, [x2, #0xf]
    // 0xbc3d18: stur            d1, [fp, #-8]
    // 0xbc3d1c: r0 = size()
    //     0xbc3d1c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc3d20: LoadField: d1 = r0->field_f
    //     0xbc3d20: ldur            d1, [x0, #0xf]
    // 0xbc3d24: ldur            d2, [fp, #-8]
    // 0xbc3d28: fsub            d3, d2, d1
    // 0xbc3d2c: d1 = 0.000000
    //     0xbc3d2c: eor             v1.16b, v1.16b, v1.16b
    // 0xbc3d30: fmax            v2.2d, v1.2d, v3.2d
    // 0xbc3d34: mov             v0.16b, v2.16b
    // 0xbc3d38: LeaveFrame
    //     0xbc3d38: mov             SP, fp
    //     0xbc3d3c: ldp             fp, lr, [SP], #0x10
    // 0xbc3d40: ret
    //     0xbc3d40: ret             
    // 0xbc3d44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc3d44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc3d48: b               #0xbc3cc0
  }
  _ _computeCaretPrototype(/* No info */) {
    // ** addr: 0xbc3d4c, size: 0xb8
    // 0xbc3d4c: EnterFrame
    //     0xbc3d4c: stp             fp, lr, [SP, #-0x10]!
    //     0xbc3d50: mov             fp, SP
    // 0xbc3d54: AllocStack(0x18)
    //     0xbc3d54: sub             SP, SP, #0x18
    // 0xbc3d58: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xbc3d58: mov             x0, x1
    //     0xbc3d5c: stur            x1, [fp, #-8]
    // 0xbc3d60: CheckStackOverflow
    //     0xbc3d60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc3d64: cmp             SP, x16
    //     0xbc3d68: b.ls            #0xbc3dfc
    // 0xbc3d6c: LoadField: d0 = r0->field_df
    //     0xbc3d6c: ldur            d0, [x0, #0xdf]
    // 0xbc3d70: stur            d0, [fp, #-0x10]
    // 0xbc3d74: LoadField: r1 = r0->field_a7
    //     0xbc3d74: ldur            w1, [x0, #0xa7]
    // 0xbc3d78: DecompressPointer r1
    //     0xbc3d78: add             x1, x1, HEAP, lsl #32
    // 0xbc3d7c: r0 = preferredLineHeight()
    //     0xbc3d7c: bl              #0x859e1c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0xbc3d80: mov             v1.16b, v0.16b
    // 0xbc3d84: d0 = 4.000000
    //     0xbc3d84: fmov            d0, #4.00000000
    // 0xbc3d88: fsub            d2, d1, d0
    // 0xbc3d8c: ldur            d1, [fp, #-0x10]
    // 0xbc3d90: d0 = 0.000000
    //     0xbc3d90: eor             v0.16b, v0.16b, v0.16b
    // 0xbc3d94: fadd            d3, d1, d0
    // 0xbc3d98: stur            d3, [fp, #-0x18]
    // 0xbc3d9c: d0 = 2.000000
    //     0xbc3d9c: fmov            d0, #2.00000000
    // 0xbc3da0: fadd            d1, d2, d0
    // 0xbc3da4: stur            d1, [fp, #-0x10]
    // 0xbc3da8: r0 = Rect()
    //     0xbc3da8: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbc3dac: StoreField: r0->field_7 = rZR
    //     0xbc3dac: stur            xzr, [x0, #7]
    // 0xbc3db0: d0 = 2.000000
    //     0xbc3db0: fmov            d0, #2.00000000
    // 0xbc3db4: StoreField: r0->field_f = d0
    //     0xbc3db4: stur            d0, [x0, #0xf]
    // 0xbc3db8: ldur            d0, [fp, #-0x18]
    // 0xbc3dbc: ArrayStore: r0[0] = d0  ; List_8
    //     0xbc3dbc: stur            d0, [x0, #0x17]
    // 0xbc3dc0: ldur            d0, [fp, #-0x10]
    // 0xbc3dc4: StoreField: r0->field_1f = d0
    //     0xbc3dc4: stur            d0, [x0, #0x1f]
    // 0xbc3dc8: ldur            x1, [fp, #-8]
    // 0xbc3dcc: r17 = 303
    //     0xbc3dcc: mov             x17, #0x12f
    // 0xbc3dd0: str             w0, [x1, x17]
    // 0xbc3dd4: WriteBarrierInstr(obj = r1, val = r0)
    //     0xbc3dd4: ldurb           w16, [x1, #-1]
    //     0xbc3dd8: ldurb           w17, [x0, #-1]
    //     0xbc3ddc: and             x16, x17, x16, lsr #2
    //     0xbc3de0: tst             x16, HEAP, lsr #32
    //     0xbc3de4: b.eq            #0xbc3dec
    //     0xbc3de8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc3dec: r0 = Null
    //     0xbc3dec: mov             x0, NULL
    // 0xbc3df0: LeaveFrame
    //     0xbc3df0: mov             SP, fp
    //     0xbc3df4: ldp             fp, lr, [SP], #0x10
    // 0xbc3df8: ret
    //     0xbc3df8: ret             
    // 0xbc3dfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc3dfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc3e00: b               #0xbc3d6c
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0xbeed54, size: 0xa4
    // 0xbeed54: EnterFrame
    //     0xbeed54: stp             fp, lr, [SP, #-0x10]!
    //     0xbeed58: mov             fp, SP
    // 0xbeed5c: AllocStack(0x28)
    //     0xbeed5c: sub             SP, SP, #0x28
    // 0xbeed60: SetupParameters(RenderEditable this /* r1 => r2, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xbeed60: stur            x1, [fp, #-0x10]
    //     0xbeed64: mov             x16, x2
    //     0xbeed68: mov             x2, x1
    //     0xbeed6c: mov             x1, x16
    //     0xbeed70: stur            x1, [fp, #-0x18]
    // 0xbeed74: CheckStackOverflow
    //     0xbeed74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbeed78: cmp             SP, x16
    //     0xbeed7c: b.ls            #0xbeedf0
    // 0xbeed80: LoadField: r0 = r2->field_63
    //     0xbeed80: ldur            w0, [x2, #0x63]
    // 0xbeed84: DecompressPointer r0
    //     0xbeed84: add             x0, x0, HEAP, lsl #32
    // 0xbeed88: LoadField: r3 = r2->field_67
    //     0xbeed88: ldur            w3, [x2, #0x67]
    // 0xbeed8c: DecompressPointer r3
    //     0xbeed8c: add             x3, x3, HEAP, lsl #32
    // 0xbeed90: stur            x3, [fp, #-8]
    // 0xbeed94: cmp             w0, NULL
    // 0xbeed98: b.eq            #0xbeedb0
    // 0xbeed9c: stp             x0, x1, [SP]
    // 0xbeeda0: mov             x0, x1
    // 0xbeeda4: ClosureCall
    //     0xbeeda4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbeeda8: ldur            x2, [x0, #0x1f]
    //     0xbeedac: blr             x2
    // 0xbeedb0: ldur            x0, [fp, #-8]
    // 0xbeedb4: cmp             w0, NULL
    // 0xbeedb8: b.eq            #0xbeedd4
    // 0xbeedbc: ldur            x16, [fp, #-0x18]
    // 0xbeedc0: stp             x0, x16, [SP]
    // 0xbeedc4: ldur            x0, [fp, #-0x18]
    // 0xbeedc8: ClosureCall
    //     0xbeedc8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbeedcc: ldur            x2, [x0, #0x1f]
    //     0xbeedd0: blr             x2
    // 0xbeedd4: ldur            x1, [fp, #-0x10]
    // 0xbeedd8: ldur            x2, [fp, #-0x18]
    // 0xbeeddc: r0 = visitChildren()
    //     0xbeeddc: bl              #0xbeedf8  ; [dart:mixin_deduplication] _MixinApplication426&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin::visitChildren
    // 0xbeede0: r0 = Null
    //     0xbeede0: mov             x0, NULL
    // 0xbeede4: LeaveFrame
    //     0xbeede4: mov             SP, fp
    //     0xbeede8: ldp             fp, lr, [SP], #0x10
    // 0xbeedec: ret
    //     0xbeedec: ret             
    // 0xbeedf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeedf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeedf4: b               #0xbeed80
  }
  _ markNeedsPaint(/* No info */) {
    // ** addr: 0xbf05e0, size: 0x70
    // 0xbf05e0: EnterFrame
    //     0xbf05e0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf05e4: mov             fp, SP
    // 0xbf05e8: AllocStack(0x8)
    //     0xbf05e8: sub             SP, SP, #8
    // 0xbf05ec: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xbf05ec: mov             x0, x1
    //     0xbf05f0: stur            x1, [fp, #-8]
    // 0xbf05f4: CheckStackOverflow
    //     0xbf05f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf05f8: cmp             SP, x16
    //     0xbf05fc: b.ls            #0xbf0648
    // 0xbf0600: mov             x1, x0
    // 0xbf0604: r0 = markNeedsPaint()
    //     0xbf0604: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xbf0608: ldur            x0, [fp, #-8]
    // 0xbf060c: LoadField: r1 = r0->field_63
    //     0xbf060c: ldur            w1, [x0, #0x63]
    // 0xbf0610: DecompressPointer r1
    //     0xbf0610: add             x1, x1, HEAP, lsl #32
    // 0xbf0614: cmp             w1, NULL
    // 0xbf0618: b.eq            #0xbf0624
    // 0xbf061c: r0 = markNeedsPaint()
    //     0xbf061c: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xbf0620: ldur            x0, [fp, #-8]
    // 0xbf0624: LoadField: r1 = r0->field_67
    //     0xbf0624: ldur            w1, [x0, #0x67]
    // 0xbf0628: DecompressPointer r1
    //     0xbf0628: add             x1, x1, HEAP, lsl #32
    // 0xbf062c: cmp             w1, NULL
    // 0xbf0630: b.eq            #0xbf0638
    // 0xbf0634: r0 = markNeedsPaint()
    //     0xbf0634: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xbf0638: r0 = Null
    //     0xbf0638: mov             x0, NULL
    // 0xbf063c: LeaveFrame
    //     0xbf063c: mov             SP, fp
    //     0xbf0640: ldp             fp, lr, [SP], #0x10
    // 0xbf0644: ret
    //     0xbf0644: ret             
    // 0xbf0648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf064c: b               #0xbf0600
  }
  [closure] void markNeedsPaint(dynamic) {
    // ** addr: 0xbf0650, size: 0x38
    // 0xbf0650: EnterFrame
    //     0xbf0650: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0654: mov             fp, SP
    // 0xbf0658: ldr             x0, [fp, #0x10]
    // 0xbf065c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf065c: ldur            w1, [x0, #0x17]
    // 0xbf0660: DecompressPointer r1
    //     0xbf0660: add             x1, x1, HEAP, lsl #32
    // 0xbf0664: CheckStackOverflow
    //     0xbf0664: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0668: cmp             SP, x16
    //     0xbf066c: b.ls            #0xbf0680
    // 0xbf0670: r0 = markNeedsPaint()
    //     0xbf0670: bl              #0xbf05e0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::markNeedsPaint
    // 0xbf0674: LeaveFrame
    //     0xbf0674: mov             SP, fp
    //     0xbf0678: ldp             fp, lr, [SP], #0x10
    // 0xbf067c: ret
    //     0xbf067c: ret             
    // 0xbf0680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0684: b               #0xbf0670
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf19ec, size: 0xc0
    // 0xbf19ec: EnterFrame
    //     0xbf19ec: stp             fp, lr, [SP, #-0x10]!
    //     0xbf19f0: mov             fp, SP
    // 0xbf19f4: AllocStack(0x18)
    //     0xbf19f4: sub             SP, SP, #0x18
    // 0xbf19f8: SetupParameters(RenderEditable this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xbf19f8: mov             x5, x1
    //     0xbf19fc: mov             x4, x2
    //     0xbf1a00: stur            x1, [fp, #-8]
    //     0xbf1a04: stur            x2, [fp, #-0x10]
    //     0xbf1a08: stur            x3, [fp, #-0x18]
    // 0xbf1a0c: CheckStackOverflow
    //     0xbf1a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1a10: cmp             SP, x16
    //     0xbf1a14: b.ls            #0xbf1aa4
    // 0xbf1a18: mov             x0, x4
    // 0xbf1a1c: r2 = Null
    //     0xbf1a1c: mov             x2, NULL
    // 0xbf1a20: r1 = Null
    //     0xbf1a20: mov             x1, NULL
    // 0xbf1a24: r4 = 60
    //     0xbf1a24: mov             x4, #0x3c
    // 0xbf1a28: branchIfSmi(r0, 0xbf1a34)
    //     0xbf1a28: tbz             w0, #0, #0xbf1a34
    // 0xbf1a2c: r4 = LoadClassIdInstr(r0)
    //     0xbf1a2c: ldur            x4, [x0, #-1]
    //     0xbf1a30: ubfx            x4, x4, #0xc, #0x14
    // 0xbf1a34: r17 = -4710
    //     0xbf1a34: mov             x17, #-0x1266
    // 0xbf1a38: add             x4, x4, x17
    // 0xbf1a3c: cmp             x4, #0x109
    // 0xbf1a40: b.ls            #0xbf1a54
    // 0xbf1a44: r8 = RenderBox
    //     0xbf1a44: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf1a48: r3 = Null
    //     0xbf1a48: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd5e8] Null
    //     0xbf1a4c: ldr             x3, [x3, #0x5e8]
    // 0xbf1a50: r0 = RenderBox()
    //     0xbf1a50: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf1a54: ldur            x1, [fp, #-8]
    // 0xbf1a58: LoadField: r0 = r1->field_63
    //     0xbf1a58: ldur            w0, [x1, #0x63]
    // 0xbf1a5c: DecompressPointer r0
    //     0xbf1a5c: add             x0, x0, HEAP, lsl #32
    // 0xbf1a60: ldur            x2, [fp, #-0x10]
    // 0xbf1a64: cmp             w2, w0
    // 0xbf1a68: b.eq            #0xbf1a7c
    // 0xbf1a6c: LoadField: r0 = r1->field_67
    //     0xbf1a6c: ldur            w0, [x1, #0x67]
    // 0xbf1a70: DecompressPointer r0
    //     0xbf1a70: add             x0, x0, HEAP, lsl #32
    // 0xbf1a74: cmp             w2, w0
    // 0xbf1a78: b.ne            #0xbf1a8c
    // 0xbf1a7c: r0 = Null
    //     0xbf1a7c: mov             x0, NULL
    // 0xbf1a80: LeaveFrame
    //     0xbf1a80: mov             SP, fp
    //     0xbf1a84: ldp             fp, lr, [SP], #0x10
    // 0xbf1a88: ret
    //     0xbf1a88: ret             
    // 0xbf1a8c: ldur            x3, [fp, #-0x18]
    // 0xbf1a90: r0 = defaultApplyPaintTransform()
    //     0xbf1a90: bl              #0xbf1aac  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::defaultApplyPaintTransform
    // 0xbf1a94: r0 = Null
    //     0xbf1a94: mov             x0, NULL
    // 0xbf1a98: LeaveFrame
    //     0xbf1a98: mov             SP, fp
    //     0xbf1a9c: ldp             fp, lr, [SP], #0x10
    // 0xbf1aa0: ret
    //     0xbf1aa0: ret             
    // 0xbf1aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf1aa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1aa8: b               #0xbf1a18
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf7018, size: 0x720
    // 0xbf7018: EnterFrame
    //     0xbf7018: stp             fp, lr, [SP, #-0x10]!
    //     0xbf701c: mov             fp, SP
    // 0xbf7020: AllocStack(0x78)
    //     0xbf7020: sub             SP, SP, #0x78
    // 0xbf7024: SetupParameters(RenderEditable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbf7024: mov             x3, x1
    //     0xbf7028: mov             x0, x2
    //     0xbf702c: stur            x1, [fp, #-8]
    //     0xbf7030: stur            x2, [fp, #-0x10]
    // 0xbf7034: CheckStackOverflow
    //     0xbf7034: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf7038: cmp             SP, x16
    //     0xbf703c: b.ls            #0xbf7714
    // 0xbf7040: mov             x1, x3
    // 0xbf7044: mov             x2, x0
    // 0xbf7048: r0 = Shader._()
    //     0xbf7048: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xbf704c: ldur            x0, [fp, #-8]
    // 0xbf7050: LoadField: r2 = r0->field_a7
    //     0xbf7050: ldur            w2, [x0, #0xa7]
    // 0xbf7054: DecompressPointer r2
    //     0xbf7054: add             x2, x2, HEAP, lsl #32
    // 0xbf7058: stur            x2, [fp, #-0x18]
    // 0xbf705c: LoadField: r1 = r2->field_f
    //     0xbf705c: ldur            w1, [x2, #0xf]
    // 0xbf7060: DecompressPointer r1
    //     0xbf7060: add             x1, x1, HEAP, lsl #32
    // 0xbf7064: cmp             w1, NULL
    // 0xbf7068: b.eq            #0xbf771c
    // 0xbf706c: r0 = getSemanticsInformation()
    //     0xbf706c: bl              #0xbf8a84  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::getSemanticsInformation
    // 0xbf7070: mov             x4, x0
    // 0xbf7074: ldur            x3, [fp, #-8]
    // 0xbf7078: stur            x4, [fp, #-0x20]
    // 0xbf707c: r17 = 271
    //     0xbf707c: mov             x17, #0x10f
    // 0xbf7080: str             w0, [x3, x17]
    // 0xbf7084: WriteBarrierInstr(obj = r3, val = r0)
    //     0xbf7084: ldurb           w16, [x3, #-1]
    //     0xbf7088: ldurb           w17, [x0, #-1]
    //     0xbf708c: and             x16, x17, x16, lsr #2
    //     0xbf7090: tst             x16, HEAP, lsr #32
    //     0xbf7094: b.eq            #0xbf709c
    //     0xbf7098: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbf709c: r1 = Function '<anonymous closure>':.
    //     0xbf709c: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd6f0] AnonymousClosure: (0xbf8cf0), in [package:flutter/src/rendering/editable.dart] RenderEditable::describeSemanticsConfiguration (0xbf7018)
    //     0xbf70a0: ldr             x1, [x1, #0x6f0]
    // 0xbf70a4: r2 = Null
    //     0xbf70a4: mov             x2, NULL
    // 0xbf70a8: r0 = AllocateClosure()
    //     0xbf70a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf70ac: ldur            x1, [fp, #-0x20]
    // 0xbf70b0: mov             x2, x0
    // 0xbf70b4: r0 = any()
    //     0xbf70b4: bl              #0xbae1ac  ; [dart:collection] ListBase::any
    // 0xbf70b8: tbnz            w0, #4, #0xbf70dc
    // 0xbf70bc: ldur            x0, [fp, #-0x10]
    // 0xbf70c0: r2 = true
    //     0xbf70c0: add             x2, NULL, #0x20  ; true
    // 0xbf70c4: StoreField: r0->field_7 = r2
    //     0xbf70c4: stur            w2, [x0, #7]
    // 0xbf70c8: ArrayStore: r0[0] = r2  ; List_4
    //     0xbf70c8: stur            w2, [x0, #0x17]
    // 0xbf70cc: r0 = Null
    //     0xbf70cc: mov             x0, NULL
    // 0xbf70d0: LeaveFrame
    //     0xbf70d0: mov             SP, fp
    //     0xbf70d4: ldp             fp, lr, [SP], #0x10
    // 0xbf70d8: ret
    //     0xbf70d8: ret             
    // 0xbf70dc: ldur            x3, [fp, #-8]
    // 0xbf70e0: ldur            x0, [fp, #-0x10]
    // 0xbf70e4: r2 = true
    //     0xbf70e4: add             x2, NULL, #0x20  ; true
    // 0xbf70e8: LoadField: r1 = r3->field_ab
    //     0xbf70e8: ldur            w1, [x3, #0xab]
    // 0xbf70ec: DecompressPointer r1
    //     0xbf70ec: add             x1, x1, HEAP, lsl #32
    // 0xbf70f0: cmp             w1, NULL
    // 0xbf70f4: b.ne            #0xbf749c
    // 0xbf70f8: LoadField: r1 = r3->field_97
    //     0xbf70f8: ldur            w1, [x3, #0x97]
    // 0xbf70fc: DecompressPointer r1
    //     0xbf70fc: add             x1, x1, HEAP, lsl #32
    // 0xbf7100: tbnz            w1, #4, #0xbf7184
    // 0xbf7104: mov             x1, x3
    // 0xbf7108: r0 = computeDistanceToActualBaseline()
    //     0xbf7108: bl              #0xb5cbfc  ; [package:flutter/src/rendering/table.dart] RenderTable::computeDistanceToActualBaseline
    // 0xbf710c: ldur            x1, [fp, #-0x18]
    // 0xbf7110: stur            x0, [fp, #-0x20]
    // 0xbf7114: r0 = plainText()
    //     0xbf7114: bl              #0x85f334  ; [package:flutter/src/painting/text_painter.dart] TextPainter::plainText
    // 0xbf7118: LoadField: r1 = r0->field_7
    //     0xbf7118: ldur            w1, [x0, #7]
    // 0xbf711c: r2 = LoadInt32Instr(r1)
    //     0xbf711c: sbfx            x2, x1, #1, #0x1f
    // 0xbf7120: ldur            x1, [fp, #-0x20]
    // 0xbf7124: r0 = LoadClassIdInstr(r1)
    //     0xbf7124: ldur            x0, [x1, #-1]
    //     0xbf7128: ubfx            x0, x0, #0xc, #0x14
    // 0xbf712c: r0 = GDT[cid_x0 + -0xfd6]()
    //     0xbf712c: sub             lr, x0, #0xfd6
    //     0xbf7130: ldr             lr, [x21, lr, lsl #3]
    //     0xbf7134: blr             lr
    // 0xbf7138: stur            x0, [fp, #-0x20]
    // 0xbf713c: r0 = AttributedString()
    //     0xbf713c: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xbf7140: mov             x1, x0
    // 0xbf7144: ldur            x0, [fp, #-0x20]
    // 0xbf7148: StoreField: r1->field_7 = r0
    //     0xbf7148: stur            w0, [x1, #7]
    // 0xbf714c: r0 = const []
    //     0xbf714c: ldr             x0, [PP, #0x2708]  ; [pp+0x2708] List<StringAttribute>(0)
    // 0xbf7150: StoreField: r1->field_b = r0
    //     0xbf7150: stur            w0, [x1, #0xb]
    // 0xbf7154: mov             x0, x1
    // 0xbf7158: ldur            x2, [fp, #-8]
    // 0xbf715c: StoreField: r2->field_ab = r0
    //     0xbf715c: stur            w0, [x2, #0xab]
    //     0xbf7160: ldurb           w16, [x2, #-1]
    //     0xbf7164: ldurb           w17, [x0, #-1]
    //     0xbf7168: and             x16, x17, x16, lsr #2
    //     0xbf716c: tst             x16, HEAP, lsr #32
    //     0xbf7170: b.eq            #0xbf7178
    //     0xbf7174: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbf7178: mov             x0, x1
    // 0xbf717c: mov             x3, x2
    // 0xbf7180: b               #0xbf74a0
    // 0xbf7184: mov             x2, x3
    // 0xbf7188: r0 = StringBuffer()
    //     0xbf7188: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xbf718c: mov             x1, x0
    // 0xbf7190: stur            x0, [fp, #-0x20]
    // 0xbf7194: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbf7194: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbf7198: r0 = StringBuffer()
    //     0xbf7198: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0xbf719c: r1 = <StringAttribute>
    //     0xbf719c: ldr             x1, [PP, #0x2720]  ; [pp+0x2720] TypeArguments: <StringAttribute>
    // 0xbf71a0: r2 = 0
    //     0xbf71a0: mov             x2, #0
    // 0xbf71a4: r0 = _GrowableList()
    //     0xbf71a4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbf71a8: mov             x3, x0
    // 0xbf71ac: ldur            x2, [fp, #-8]
    // 0xbf71b0: stur            x3, [fp, #-0x50]
    // 0xbf71b4: r17 = 271
    //     0xbf71b4: mov             x17, #0x10f
    // 0xbf71b8: ldr             w4, [x2, x17]
    // 0xbf71bc: DecompressPointer r4
    //     0xbf71bc: add             x4, x4, HEAP, lsl #32
    // 0xbf71c0: stur            x4, [fp, #-0x48]
    // 0xbf71c4: cmp             w4, NULL
    // 0xbf71c8: b.eq            #0xbf7720
    // 0xbf71cc: LoadField: r0 = r4->field_b
    //     0xbf71cc: ldur            w0, [x4, #0xb]
    // 0xbf71d0: r5 = LoadInt32Instr(r0)
    //     0xbf71d0: sbfx            x5, x0, #1, #0x1f
    // 0xbf71d4: stur            x5, [fp, #-0x40]
    // 0xbf71d8: r6 = 0
    //     0xbf71d8: mov             x6, #0
    // 0xbf71dc: r0 = 0
    //     0xbf71dc: mov             x0, #0
    // 0xbf71e0: stur            x6, [fp, #-0x38]
    // 0xbf71e4: CheckStackOverflow
    //     0xbf71e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf71e8: cmp             SP, x16
    //     0xbf71ec: b.ls            #0xbf7724
    // 0xbf71f0: LoadField: r1 = r4->field_b
    //     0xbf71f0: ldur            w1, [x4, #0xb]
    // 0xbf71f4: r7 = LoadInt32Instr(r1)
    //     0xbf71f4: sbfx            x7, x1, #1, #0x1f
    // 0xbf71f8: cmp             x5, x7
    // 0xbf71fc: b.ne            #0xbf76f4
    // 0xbf7200: cmp             x0, x7
    // 0xbf7204: b.ge            #0xbf7440
    // 0xbf7208: LoadField: r1 = r4->field_f
    //     0xbf7208: ldur            w1, [x4, #0xf]
    // 0xbf720c: DecompressPointer r1
    //     0xbf720c: add             x1, x1, HEAP, lsl #32
    // 0xbf7210: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0xbf7210: add             x16, x1, x0, lsl #2
    //     0xbf7214: ldur            w7, [x16, #0xf]
    // 0xbf7218: DecompressPointer r7
    //     0xbf7218: add             x7, x7, HEAP, lsl #32
    // 0xbf721c: add             x8, x0, #1
    // 0xbf7220: stur            x8, [fp, #-0x30]
    // 0xbf7224: LoadField: r0 = r7->field_b
    //     0xbf7224: ldur            w0, [x7, #0xb]
    // 0xbf7228: DecompressPointer r0
    //     0xbf7228: add             x0, x0, HEAP, lsl #32
    // 0xbf722c: cmp             w0, NULL
    // 0xbf7230: b.ne            #0xbf7244
    // 0xbf7234: LoadField: r0 = r7->field_7
    //     0xbf7234: ldur            w0, [x7, #7]
    // 0xbf7238: DecompressPointer r0
    //     0xbf7238: add             x0, x0, HEAP, lsl #32
    // 0xbf723c: mov             x9, x0
    // 0xbf7240: b               #0xbf7248
    // 0xbf7244: mov             x9, x0
    // 0xbf7248: stur            x9, [fp, #-0x28]
    // 0xbf724c: LoadField: r1 = r7->field_1f
    //     0xbf724c: ldur            w1, [x7, #0x1f]
    // 0xbf7250: DecompressPointer r1
    //     0xbf7250: add             x1, x1, HEAP, lsl #32
    // 0xbf7254: r0 = LoadClassIdInstr(r1)
    //     0xbf7254: ldur            x0, [x1, #-1]
    //     0xbf7258: ubfx            x0, x0, #0xc, #0x14
    // 0xbf725c: r0 = GDT[cid_x0 + 0x12641]()
    //     0xbf725c: mov             x17, #0x2641
    //     0xbf7260: movk            x17, #1, lsl #16
    //     0xbf7264: add             lr, x0, x17
    //     0xbf7268: ldr             lr, [x21, lr, lsl #3]
    //     0xbf726c: blr             lr
    // 0xbf7270: mov             x2, x0
    // 0xbf7274: stur            x2, [fp, #-0x58]
    // 0xbf7278: ldur            x3, [fp, #-0x50]
    // 0xbf727c: ldur            x4, [fp, #-0x38]
    // 0xbf7280: CheckStackOverflow
    //     0xbf7280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf7284: cmp             SP, x16
    //     0xbf7288: b.ls            #0xbf772c
    // 0xbf728c: r0 = LoadClassIdInstr(r2)
    //     0xbf728c: ldur            x0, [x2, #-1]
    //     0xbf7290: ubfx            x0, x0, #0xc, #0x14
    // 0xbf7294: mov             x1, x2
    // 0xbf7298: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xbf7298: mov             x17, #0x845b
    //     0xbf729c: movk            x17, #1, lsl #16
    //     0xbf72a0: add             lr, x0, x17
    //     0xbf72a4: ldr             lr, [x21, lr, lsl #3]
    //     0xbf72a8: blr             lr
    // 0xbf72ac: tbnz            w0, #4, #0xbf73d8
    // 0xbf72b0: ldur            x3, [fp, #-0x50]
    // 0xbf72b4: ldur            x4, [fp, #-0x38]
    // 0xbf72b8: ldur            x2, [fp, #-0x58]
    // 0xbf72bc: r0 = LoadClassIdInstr(r2)
    //     0xbf72bc: ldur            x0, [x2, #-1]
    //     0xbf72c0: ubfx            x0, x0, #0xc, #0x14
    // 0xbf72c4: mov             x1, x2
    // 0xbf72c8: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xbf72c8: mov             x17, #0x7d4c
    //     0xbf72cc: movk            x17, #1, lsl #16
    //     0xbf72d0: add             lr, x0, x17
    //     0xbf72d4: ldr             lr, [x21, lr, lsl #3]
    //     0xbf72d8: blr             lr
    // 0xbf72dc: stur            x0, [fp, #-0x70]
    // 0xbf72e0: LoadField: r1 = r0->field_b
    //     0xbf72e0: ldur            w1, [x0, #0xb]
    // 0xbf72e4: DecompressPointer r1
    //     0xbf72e4: add             x1, x1, HEAP, lsl #32
    // 0xbf72e8: LoadField: r2 = r1->field_7
    //     0xbf72e8: ldur            x2, [x1, #7]
    // 0xbf72ec: ldur            x3, [fp, #-0x38]
    // 0xbf72f0: add             x4, x3, x2
    // 0xbf72f4: stur            x4, [fp, #-0x68]
    // 0xbf72f8: LoadField: r2 = r1->field_f
    //     0xbf72f8: ldur            x2, [x1, #0xf]
    // 0xbf72fc: add             x1, x3, x2
    // 0xbf7300: stur            x1, [fp, #-0x60]
    // 0xbf7304: r0 = TextRange()
    //     0xbf7304: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0xbf7308: mov             x1, x0
    // 0xbf730c: ldur            x0, [fp, #-0x68]
    // 0xbf7310: StoreField: r1->field_7 = r0
    //     0xbf7310: stur            x0, [x1, #7]
    // 0xbf7314: ldur            x0, [fp, #-0x60]
    // 0xbf7318: StoreField: r1->field_f = r0
    //     0xbf7318: stur            x0, [x1, #0xf]
    // 0xbf731c: ldur            x0, [fp, #-0x70]
    // 0xbf7320: r2 = LoadClassIdInstr(r0)
    //     0xbf7320: ldur            x2, [x0, #-1]
    //     0xbf7324: ubfx            x2, x2, #0xc, #0x14
    // 0xbf7328: mov             x16, x1
    // 0xbf732c: mov             x1, x2
    // 0xbf7330: mov             x2, x16
    // 0xbf7334: mov             x16, x0
    // 0xbf7338: mov             x0, x1
    // 0xbf733c: mov             x1, x16
    // 0xbf7340: r0 = GDT[cid_x0 + -0xfec]()
    //     0xbf7340: sub             lr, x0, #0xfec
    //     0xbf7344: ldr             lr, [x21, lr, lsl #3]
    //     0xbf7348: blr             lr
    // 0xbf734c: mov             x2, x0
    // 0xbf7350: ldur            x0, [fp, #-0x50]
    // 0xbf7354: stur            x2, [fp, #-0x70]
    // 0xbf7358: LoadField: r1 = r0->field_b
    //     0xbf7358: ldur            w1, [x0, #0xb]
    // 0xbf735c: LoadField: r3 = r0->field_f
    //     0xbf735c: ldur            w3, [x0, #0xf]
    // 0xbf7360: DecompressPointer r3
    //     0xbf7360: add             x3, x3, HEAP, lsl #32
    // 0xbf7364: LoadField: r4 = r3->field_b
    //     0xbf7364: ldur            w4, [x3, #0xb]
    // 0xbf7368: r3 = LoadInt32Instr(r1)
    //     0xbf7368: sbfx            x3, x1, #1, #0x1f
    // 0xbf736c: stur            x3, [fp, #-0x60]
    // 0xbf7370: r1 = LoadInt32Instr(r4)
    //     0xbf7370: sbfx            x1, x4, #1, #0x1f
    // 0xbf7374: cmp             x3, x1
    // 0xbf7378: b.ne            #0xbf7384
    // 0xbf737c: mov             x1, x0
    // 0xbf7380: r0 = _growToNextCapacity()
    //     0xbf7380: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbf7384: ldur            x2, [fp, #-0x50]
    // 0xbf7388: ldur            x3, [fp, #-0x60]
    // 0xbf738c: add             x0, x3, #1
    // 0xbf7390: lsl             x1, x0, #1
    // 0xbf7394: StoreField: r2->field_b = r1
    //     0xbf7394: stur            w1, [x2, #0xb]
    // 0xbf7398: LoadField: r1 = r2->field_f
    //     0xbf7398: ldur            w1, [x2, #0xf]
    // 0xbf739c: DecompressPointer r1
    //     0xbf739c: add             x1, x1, HEAP, lsl #32
    // 0xbf73a0: ldur            x0, [fp, #-0x70]
    // 0xbf73a4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbf73a4: add             x25, x1, x3, lsl #2
    //     0xbf73a8: add             x25, x25, #0xf
    //     0xbf73ac: str             w0, [x25]
    //     0xbf73b0: tbz             w0, #0, #0xbf73cc
    //     0xbf73b4: ldurb           w16, [x1, #-1]
    //     0xbf73b8: ldurb           w17, [x0, #-1]
    //     0xbf73bc: and             x16, x17, x16, lsr #2
    //     0xbf73c0: tst             x16, HEAP, lsr #32
    //     0xbf73c4: b.eq            #0xbf73cc
    //     0xbf73c8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbf73cc: mov             x3, x2
    // 0xbf73d0: ldur            x2, [fp, #-0x58]
    // 0xbf73d4: b               #0xbf727c
    // 0xbf73d8: ldur            x2, [fp, #-0x50]
    // 0xbf73dc: ldur            x1, [fp, #-0x28]
    // 0xbf73e0: r0 = LoadClassIdInstr(r1)
    //     0xbf73e0: ldur            x0, [x1, #-1]
    //     0xbf73e4: ubfx            x0, x0, #0xc, #0x14
    // 0xbf73e8: str             x1, [SP]
    // 0xbf73ec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xbf73ec: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xbf73f0: r0 = GDT[cid_x0 + 0x91c1]()
    //     0xbf73f0: mov             x17, #0x91c1
    //     0xbf73f4: add             lr, x0, x17
    //     0xbf73f8: ldr             lr, [x21, lr, lsl #3]
    //     0xbf73fc: blr             lr
    // 0xbf7400: LoadField: r1 = r0->field_7
    //     0xbf7400: ldur            w1, [x0, #7]
    // 0xbf7404: cbz             w1, #0xbf7414
    // 0xbf7408: ldur            x1, [fp, #-0x20]
    // 0xbf740c: mov             x2, x0
    // 0xbf7410: r0 = _writeString()
    //     0xbf7410: bl              #0x7e4c0c  ; [dart:core] StringBuffer::_writeString
    // 0xbf7414: ldur            x1, [fp, #-0x38]
    // 0xbf7418: ldur            x0, [fp, #-0x28]
    // 0xbf741c: LoadField: r2 = r0->field_7
    //     0xbf741c: ldur            w2, [x0, #7]
    // 0xbf7420: r0 = LoadInt32Instr(r2)
    //     0xbf7420: sbfx            x0, x2, #1, #0x1f
    // 0xbf7424: add             x6, x1, x0
    // 0xbf7428: ldur            x0, [fp, #-0x30]
    // 0xbf742c: ldur            x2, [fp, #-8]
    // 0xbf7430: ldur            x3, [fp, #-0x50]
    // 0xbf7434: ldur            x4, [fp, #-0x48]
    // 0xbf7438: ldur            x5, [fp, #-0x40]
    // 0xbf743c: b               #0xbf71e0
    // 0xbf7440: mov             x1, x2
    // 0xbf7444: mov             x0, x3
    // 0xbf7448: ldur            x16, [fp, #-0x20]
    // 0xbf744c: str             x16, [SP]
    // 0xbf7450: r0 = toString()
    //     0xbf7450: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0xbf7454: stur            x0, [fp, #-0x20]
    // 0xbf7458: r0 = AttributedString()
    //     0xbf7458: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xbf745c: mov             x1, x0
    // 0xbf7460: ldur            x0, [fp, #-0x20]
    // 0xbf7464: StoreField: r1->field_7 = r0
    //     0xbf7464: stur            w0, [x1, #7]
    // 0xbf7468: ldur            x0, [fp, #-0x50]
    // 0xbf746c: StoreField: r1->field_b = r0
    //     0xbf746c: stur            w0, [x1, #0xb]
    // 0xbf7470: mov             x0, x1
    // 0xbf7474: ldur            x3, [fp, #-8]
    // 0xbf7478: StoreField: r3->field_ab = r0
    //     0xbf7478: stur            w0, [x3, #0xab]
    //     0xbf747c: ldurb           w16, [x3, #-1]
    //     0xbf7480: ldurb           w17, [x0, #-1]
    //     0xbf7484: and             x16, x17, x16, lsr #2
    //     0xbf7488: tst             x16, HEAP, lsr #32
    //     0xbf748c: b.eq            #0xbf7494
    //     0xbf7490: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbf7494: mov             x0, x1
    // 0xbf7498: b               #0xbf74a0
    // 0xbf749c: mov             x0, x1
    // 0xbf74a0: ldur            x4, [fp, #-0x10]
    // 0xbf74a4: ldur            x6, [fp, #-0x18]
    // 0xbf74a8: r5 = true
    //     0xbf74a8: add             x5, NULL, #0x20  ; true
    // 0xbf74ac: StoreField: r4->field_6b = r0
    //     0xbf74ac: stur            w0, [x4, #0x6b]
    //     0xbf74b0: ldurb           w16, [x4, #-1]
    //     0xbf74b4: ldurb           w17, [x0, #-1]
    //     0xbf74b8: and             x16, x17, x16, lsr #2
    //     0xbf74bc: tst             x16, HEAP, lsr #32
    //     0xbf74c0: b.eq            #0xbf74c8
    //     0xbf74c4: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbf74c8: StoreField: r4->field_1f = r5
    //     0xbf74c8: stur            w5, [x4, #0x1f]
    // 0xbf74cc: LoadField: r2 = r3->field_97
    //     0xbf74cc: ldur            w2, [x3, #0x97]
    // 0xbf74d0: DecompressPointer r2
    //     0xbf74d0: add             x2, x2, HEAP, lsl #32
    // 0xbf74d4: mov             x1, x4
    // 0xbf74d8: r0 = isObscured=()
    //     0xbf74d8: bl              #0xbf8a0c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isObscured=
    // 0xbf74dc: ldur            x0, [fp, #-8]
    // 0xbf74e0: LoadField: r1 = r0->field_cb
    //     0xbf74e0: ldur            w1, [x0, #0xcb]
    // 0xbf74e4: DecompressPointer r1
    //     0xbf74e4: add             x1, x1, HEAP, lsl #32
    // 0xbf74e8: cmp             w1, #2
    // 0xbf74ec: r16 = true
    //     0xbf74ec: add             x16, NULL, #0x20  ; true
    // 0xbf74f0: r17 = false
    //     0xbf74f0: add             x17, NULL, #0x30  ; false
    // 0xbf74f4: csel            x2, x16, x17, ne
    // 0xbf74f8: ldur            x1, [fp, #-0x10]
    // 0xbf74fc: r0 = isMultiline=()
    //     0xbf74fc: bl              #0xbf8994  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isMultiline=
    // 0xbf7500: ldur            x3, [fp, #-0x18]
    // 0xbf7504: LoadField: r0 = r3->field_1b
    //     0xbf7504: ldur            w0, [x3, #0x1b]
    // 0xbf7508: DecompressPointer r0
    //     0xbf7508: add             x0, x0, HEAP, lsl #32
    // 0xbf750c: cmp             w0, NULL
    // 0xbf7510: b.eq            #0xbf7734
    // 0xbf7514: ldur            x4, [fp, #-0x10]
    // 0xbf7518: StoreField: r4->field_83 = r0
    //     0xbf7518: stur            w0, [x4, #0x83]
    //     0xbf751c: ldurb           w16, [x4, #-1]
    //     0xbf7520: ldurb           w17, [x0, #-1]
    //     0xbf7524: and             x16, x17, x16, lsr #2
    //     0xbf7528: tst             x16, HEAP, lsr #32
    //     0xbf752c: b.eq            #0xbf7534
    //     0xbf7530: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbf7534: r0 = true
    //     0xbf7534: add             x0, NULL, #0x20  ; true
    // 0xbf7538: StoreField: r4->field_1f = r0
    //     0xbf7538: stur            w0, [x4, #0x1f]
    // 0xbf753c: ldur            x5, [fp, #-8]
    // 0xbf7540: LoadField: r2 = r5->field_bf
    //     0xbf7540: ldur            w2, [x5, #0xbf]
    // 0xbf7544: DecompressPointer r2
    //     0xbf7544: add             x2, x2, HEAP, lsl #32
    // 0xbf7548: mov             x1, x4
    // 0xbf754c: r0 = isFocused=()
    //     0xbf754c: bl              #0xbf3fc8  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isFocused=
    // 0xbf7550: ldur            x1, [fp, #-0x10]
    // 0xbf7554: r2 = true
    //     0xbf7554: add             x2, NULL, #0x20  ; true
    // 0xbf7558: r0 = isFocusable=()
    //     0xbf7558: bl              #0xbf4060  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isFocusable=
    // 0xbf755c: ldur            x1, [fp, #-0x10]
    // 0xbf7560: r2 = true
    //     0xbf7560: add             x2, NULL, #0x20  ; true
    // 0xbf7564: r0 = isTextField=()
    //     0xbf7564: bl              #0xbf8918  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isTextField=
    // 0xbf7568: ldur            x0, [fp, #-8]
    // 0xbf756c: LoadField: r2 = r0->field_c7
    //     0xbf756c: ldur            w2, [x0, #0xc7]
    // 0xbf7570: DecompressPointer r2
    //     0xbf7570: add             x2, x2, HEAP, lsl #32
    // 0xbf7574: ldur            x1, [fp, #-0x10]
    // 0xbf7578: r0 = isReadOnly=()
    //     0xbf7578: bl              #0xbf88a0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isReadOnly=
    // 0xbf757c: ldur            x0, [fp, #-0x10]
    // 0xbf7580: r1 = Instance_SemanticsInputType
    //     0xbf7580: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2f58] Obj!SemanticsInputType@12c77a1
    //     0xbf7584: ldr             x1, [x1, #0xf58]
    // 0xbf7588: StoreField: r0->field_b3 = r1
    //     0xbf7588: stur            w1, [x0, #0xb3]
    // 0xbf758c: r1 = true
    //     0xbf758c: add             x1, NULL, #0x20  ; true
    // 0xbf7590: StoreField: r0->field_1f = r1
    //     0xbf7590: stur            w1, [x0, #0x1f]
    // 0xbf7594: ldur            x2, [fp, #-8]
    // 0xbf7598: LoadField: r1 = r2->field_bf
    //     0xbf7598: ldur            w1, [x2, #0xbf]
    // 0xbf759c: DecompressPointer r1
    //     0xbf759c: add             x1, x1, HEAP, lsl #32
    // 0xbf75a0: tbnz            w1, #4, #0xbf75cc
    // 0xbf75a4: mov             x1, x2
    // 0xbf75a8: r0 = selectionEnabled()
    //     0xbf75a8: bl              #0xbf8890  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectionEnabled
    // 0xbf75ac: tbnz            w0, #4, #0xbf75cc
    // 0xbf75b0: ldur            x2, [fp, #-8]
    // 0xbf75b4: r1 = Function '_handleSetSelection@80245603':.
    //     0xbf75b4: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd6f8] AnonymousClosure: (0xbf8cb4), in [package:flutter/src/rendering/editable.dart] RenderEditable::_handleSetSelection (0xbf885c)
    //     0xbf75b8: ldr             x1, [x1, #0x6f8]
    // 0xbf75bc: r0 = AllocateClosure()
    //     0xbf75bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf75c0: ldur            x1, [fp, #-0x10]
    // 0xbf75c4: mov             x2, x0
    // 0xbf75c8: r0 = onSetSelection=()
    //     0xbf75c8: bl              #0xbf8650  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onSetSelection=
    // 0xbf75cc: ldur            x0, [fp, #-8]
    // 0xbf75d0: LoadField: r1 = r0->field_bf
    //     0xbf75d0: ldur            w1, [x0, #0xbf]
    // 0xbf75d4: DecompressPointer r1
    //     0xbf75d4: add             x1, x1, HEAP, lsl #32
    // 0xbf75d8: tbnz            w1, #4, #0xbf7604
    // 0xbf75dc: LoadField: r1 = r0->field_c7
    //     0xbf75dc: ldur            w1, [x0, #0xc7]
    // 0xbf75e0: DecompressPointer r1
    //     0xbf75e0: add             x1, x1, HEAP, lsl #32
    // 0xbf75e4: tbz             w1, #4, #0xbf7604
    // 0xbf75e8: mov             x2, x0
    // 0xbf75ec: r1 = Function '_handleSetText@80245603':.
    //     0xbf75ec: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd700] AnonymousClosure: (0xbf8c78), in [package:flutter/src/rendering/editable.dart] RenderEditable::_handleSetText (0xbf85a4)
    //     0xbf75f0: ldr             x1, [x1, #0x700]
    // 0xbf75f4: r0 = AllocateClosure()
    //     0xbf75f4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf75f8: ldur            x1, [fp, #-0x10]
    // 0xbf75fc: mov             x2, x0
    // 0xbf7600: r0 = onSetText=()
    //     0xbf7600: bl              #0xbf848c  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onSetText=
    // 0xbf7604: ldur            x1, [fp, #-8]
    // 0xbf7608: r0 = selectionEnabled()
    //     0xbf7608: bl              #0xbf8890  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectionEnabled
    // 0xbf760c: tbnz            w0, #4, #0xbf76e4
    // 0xbf7610: ldur            x0, [fp, #-8]
    // 0xbf7614: LoadField: r2 = r0->field_d7
    //     0xbf7614: ldur            w2, [x0, #0xd7]
    // 0xbf7618: DecompressPointer r2
    //     0xbf7618: add             x2, x2, HEAP, lsl #32
    // 0xbf761c: LoadField: r1 = r2->field_7
    //     0xbf761c: ldur            x1, [x2, #7]
    // 0xbf7620: tbnz            x1, #0x3f, #0xbf76e4
    // 0xbf7624: LoadField: r1 = r2->field_f
    //     0xbf7624: ldur            x1, [x2, #0xf]
    // 0xbf7628: tbnz            x1, #0x3f, #0xbf76e4
    // 0xbf762c: ldur            x1, [fp, #-0x10]
    // 0xbf7630: r0 = textSelection=()
    //     0xbf7630: bl              #0xbf8454  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::textSelection=
    // 0xbf7634: ldur            x0, [fp, #-8]
    // 0xbf7638: LoadField: r1 = r0->field_d7
    //     0xbf7638: ldur            w1, [x0, #0xd7]
    // 0xbf763c: DecompressPointer r1
    //     0xbf763c: add             x1, x1, HEAP, lsl #32
    // 0xbf7640: LoadField: r2 = r1->field_1f
    //     0xbf7640: ldur            x2, [x1, #0x1f]
    // 0xbf7644: ldur            x1, [fp, #-0x18]
    // 0xbf7648: r0 = getOffsetBefore()
    //     0xbf7648: bl              #0xbf83a4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetBefore
    // 0xbf764c: cmp             w0, NULL
    // 0xbf7650: b.eq            #0xbf768c
    // 0xbf7654: ldur            x2, [fp, #-8]
    // 0xbf7658: r1 = Function '_handleMoveCursorBackwardByWord@80245603':.
    //     0xbf7658: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd708] AnonymousClosure: (0xbf8c3c), in [package:flutter/src/rendering/editable.dart] RenderEditable::_handleMoveCursorBackwardByWord (0xbf8288)
    //     0xbf765c: ldr             x1, [x1, #0x708]
    // 0xbf7660: r0 = AllocateClosure()
    //     0xbf7660: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf7664: ldur            x1, [fp, #-0x10]
    // 0xbf7668: mov             x2, x0
    // 0xbf766c: r0 = onMoveCursorBackwardByWord=()
    //     0xbf766c: bl              #0xbf8174  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onMoveCursorBackwardByWord=
    // 0xbf7670: ldur            x2, [fp, #-8]
    // 0xbf7674: r1 = Function '_handleMoveCursorBackwardByCharacter@80245603':.
    //     0xbf7674: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd710] AnonymousClosure: (0xbf8c00), in [package:flutter/src/rendering/editable.dart] RenderEditable::_handleMoveCursorBackwardByCharacter (0xbf8058)
    //     0xbf7678: ldr             x1, [x1, #0x710]
    // 0xbf767c: r0 = AllocateClosure()
    //     0xbf767c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf7680: ldur            x1, [fp, #-0x10]
    // 0xbf7684: mov             x2, x0
    // 0xbf7688: r0 = onMoveCursorBackwardByCharacter=()
    //     0xbf7688: bl              #0xbf7f44  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onMoveCursorBackwardByCharacter=
    // 0xbf768c: ldur            x0, [fp, #-8]
    // 0xbf7690: LoadField: r1 = r0->field_d7
    //     0xbf7690: ldur            w1, [x0, #0xd7]
    // 0xbf7694: DecompressPointer r1
    //     0xbf7694: add             x1, x1, HEAP, lsl #32
    // 0xbf7698: LoadField: r2 = r1->field_1f
    //     0xbf7698: ldur            x2, [x1, #0x1f]
    // 0xbf769c: ldur            x1, [fp, #-0x18]
    // 0xbf76a0: r0 = getOffsetAfter()
    //     0xbf76a0: bl              #0xbf7e94  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetAfter
    // 0xbf76a4: cmp             w0, NULL
    // 0xbf76a8: b.eq            #0xbf76e4
    // 0xbf76ac: ldur            x2, [fp, #-8]
    // 0xbf76b0: r1 = Function '_handleMoveCursorForwardByWord@80245603':.
    //     0xbf76b0: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd718] AnonymousClosure: (0xbf8bc4), in [package:flutter/src/rendering/editable.dart] RenderEditable::_handleMoveCursorForwardByWord (0xbf7a7c)
    //     0xbf76b4: ldr             x1, [x1, #0x718]
    // 0xbf76b8: r0 = AllocateClosure()
    //     0xbf76b8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf76bc: ldur            x1, [fp, #-0x10]
    // 0xbf76c0: mov             x2, x0
    // 0xbf76c4: r0 = onMoveCursorForwardByWord=()
    //     0xbf76c4: bl              #0xbf7968  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onMoveCursorForwardByWord=
    // 0xbf76c8: ldur            x2, [fp, #-8]
    // 0xbf76cc: r1 = Function '_handleMoveCursorForwardByCharacter@80245603':.
    //     0xbf76cc: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd720] AnonymousClosure: (0xbf8b88), in [package:flutter/src/rendering/editable.dart] RenderEditable::_handleMoveCursorForwardByCharacter (0xbf784c)
    //     0xbf76d0: ldr             x1, [x1, #0x720]
    // 0xbf76d4: r0 = AllocateClosure()
    //     0xbf76d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf76d8: ldur            x1, [fp, #-0x10]
    // 0xbf76dc: mov             x2, x0
    // 0xbf76e0: r0 = onMoveCursorForwardByCharacter=()
    //     0xbf76e0: bl              #0xbf7738  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::onMoveCursorForwardByCharacter=
    // 0xbf76e4: r0 = Null
    //     0xbf76e4: mov             x0, NULL
    // 0xbf76e8: LeaveFrame
    //     0xbf76e8: mov             SP, fp
    //     0xbf76ec: ldp             fp, lr, [SP], #0x10
    // 0xbf76f0: ret
    //     0xbf76f0: ret             
    // 0xbf76f4: mov             x0, x4
    // 0xbf76f8: r0 = ConcurrentModificationError()
    //     0xbf76f8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbf76fc: mov             x1, x0
    // 0xbf7700: ldur            x0, [fp, #-0x48]
    // 0xbf7704: StoreField: r1->field_b = r0
    //     0xbf7704: stur            w0, [x1, #0xb]
    // 0xbf7708: mov             x0, x1
    // 0xbf770c: r0 = Throw()
    //     0xbf770c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbf7710: brk             #0
    // 0xbf7714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7714: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7718: b               #0xbf7040
    // 0xbf771c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf771c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf7720: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf7720: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf7724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7728: b               #0xbf71f0
    // 0xbf772c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf772c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7730: b               #0xbf728c
    // 0xbf7734: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf7734: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleMoveCursorForwardByCharacter(/* No info */) {
    // ** addr: 0xbf784c, size: 0x11c
    // 0xbf784c: EnterFrame
    //     0xbf784c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf7850: mov             fp, SP
    // 0xbf7854: AllocStack(0x20)
    //     0xbf7854: sub             SP, SP, #0x20
    // 0xbf7858: SetupParameters(RenderEditable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbf7858: mov             x3, x1
    //     0xbf785c: mov             x0, x2
    //     0xbf7860: stur            x1, [fp, #-8]
    //     0xbf7864: stur            x2, [fp, #-0x10]
    // 0xbf7868: CheckStackOverflow
    //     0xbf7868: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf786c: cmp             SP, x16
    //     0xbf7870: b.ls            #0xbf7960
    // 0xbf7874: LoadField: r1 = r3->field_a7
    //     0xbf7874: ldur            w1, [x3, #0xa7]
    // 0xbf7878: DecompressPointer r1
    //     0xbf7878: add             x1, x1, HEAP, lsl #32
    // 0xbf787c: LoadField: r2 = r3->field_d7
    //     0xbf787c: ldur            w2, [x3, #0xd7]
    // 0xbf7880: DecompressPointer r2
    //     0xbf7880: add             x2, x2, HEAP, lsl #32
    // 0xbf7884: LoadField: r4 = r2->field_1f
    //     0xbf7884: ldur            x4, [x2, #0x1f]
    // 0xbf7888: mov             x2, x4
    // 0xbf788c: r0 = getOffsetAfter()
    //     0xbf788c: bl              #0xbf7e94  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetAfter
    // 0xbf7890: stur            x0, [fp, #-0x20]
    // 0xbf7894: cmp             w0, NULL
    // 0xbf7898: b.ne            #0xbf78ac
    // 0xbf789c: r0 = Null
    //     0xbf789c: mov             x0, NULL
    // 0xbf78a0: LeaveFrame
    //     0xbf78a0: mov             SP, fp
    //     0xbf78a4: ldp             fp, lr, [SP], #0x10
    // 0xbf78a8: ret
    //     0xbf78a8: ret             
    // 0xbf78ac: ldur            x1, [fp, #-0x10]
    // 0xbf78b0: tbz             w1, #4, #0xbf78cc
    // 0xbf78b4: r1 = LoadInt32Instr(r0)
    //     0xbf78b4: sbfx            x1, x0, #1, #0x1f
    //     0xbf78b8: tbz             w0, #0, #0xbf78c0
    //     0xbf78bc: ldur            x1, [x0, #7]
    // 0xbf78c0: mov             x2, x1
    // 0xbf78c4: ldur            x1, [fp, #-8]
    // 0xbf78c8: b               #0xbf78e0
    // 0xbf78cc: ldur            x1, [fp, #-8]
    // 0xbf78d0: LoadField: r2 = r1->field_d7
    //     0xbf78d0: ldur            w2, [x1, #0xd7]
    // 0xbf78d4: DecompressPointer r2
    //     0xbf78d4: add             x2, x2, HEAP, lsl #32
    // 0xbf78d8: ArrayLoad: r3 = r2[0]  ; List_8
    //     0xbf78d8: ldur            x3, [x2, #0x17]
    // 0xbf78dc: mov             x2, x3
    // 0xbf78e0: stur            x2, [fp, #-0x18]
    // 0xbf78e4: r0 = TextSelection()
    //     0xbf78e4: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xbf78e8: mov             x1, x0
    // 0xbf78ec: ldur            x0, [fp, #-0x18]
    // 0xbf78f0: ArrayStore: r1[0] = r0  ; List_8
    //     0xbf78f0: stur            x0, [x1, #0x17]
    // 0xbf78f4: ldur            x2, [fp, #-0x20]
    // 0xbf78f8: r3 = LoadInt32Instr(r2)
    //     0xbf78f8: sbfx            x3, x2, #1, #0x1f
    //     0xbf78fc: tbz             w2, #0, #0xbf7904
    //     0xbf7900: ldur            x3, [x2, #7]
    // 0xbf7904: StoreField: r1->field_1f = r3
    //     0xbf7904: stur            x3, [x1, #0x1f]
    // 0xbf7908: r2 = Instance_TextAffinity
    //     0xbf7908: ldr             x2, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xbf790c: StoreField: r1->field_27 = r2
    //     0xbf790c: stur            w2, [x1, #0x27]
    // 0xbf7910: r2 = false
    //     0xbf7910: add             x2, NULL, #0x30  ; false
    // 0xbf7914: StoreField: r1->field_2b = r2
    //     0xbf7914: stur            w2, [x1, #0x2b]
    // 0xbf7918: cmp             x0, x3
    // 0xbf791c: b.ge            #0xbf7928
    // 0xbf7920: mov             x2, x0
    // 0xbf7924: b               #0xbf792c
    // 0xbf7928: mov             x2, x3
    // 0xbf792c: cmp             x0, x3
    // 0xbf7930: b.ge            #0xbf7938
    // 0xbf7934: mov             x0, x3
    // 0xbf7938: StoreField: r1->field_7 = r2
    //     0xbf7938: stur            x2, [x1, #7]
    // 0xbf793c: StoreField: r1->field_f = r0
    //     0xbf793c: stur            x0, [x1, #0xf]
    // 0xbf7940: mov             x2, x1
    // 0xbf7944: ldur            x1, [fp, #-8]
    // 0xbf7948: r3 = Instance_SelectionChangedCause
    //     0xbf7948: ldr             x3, [PP, #0x53c8]  ; [pp+0x53c8] Obj!SelectionChangedCause@12c3661
    // 0xbf794c: r0 = _setSelection()
    //     0xbf794c: bl              #0x87957c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_setSelection
    // 0xbf7950: r0 = Null
    //     0xbf7950: mov             x0, NULL
    // 0xbf7954: LeaveFrame
    //     0xbf7954: mov             SP, fp
    //     0xbf7958: ldp             fp, lr, [SP], #0x10
    // 0xbf795c: ret
    //     0xbf795c: ret             
    // 0xbf7960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7960: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7964: b               #0xbf7874
  }
  _ _handleMoveCursorForwardByWord(/* No info */) {
    // ** addr: 0xbf7a7c, size: 0x118
    // 0xbf7a7c: EnterFrame
    //     0xbf7a7c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf7a80: mov             fp, SP
    // 0xbf7a84: AllocStack(0x28)
    //     0xbf7a84: sub             SP, SP, #0x28
    // 0xbf7a88: SetupParameters(RenderEditable this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xbf7a88: mov             x0, x1
    //     0xbf7a8c: stur            x1, [fp, #-0x10]
    //     0xbf7a90: stur            x2, [fp, #-0x18]
    // 0xbf7a94: CheckStackOverflow
    //     0xbf7a94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf7a98: cmp             SP, x16
    //     0xbf7a9c: b.ls            #0xbf7b8c
    // 0xbf7aa0: LoadField: r3 = r0->field_a7
    //     0xbf7aa0: ldur            w3, [x0, #0xa7]
    // 0xbf7aa4: DecompressPointer r3
    //     0xbf7aa4: add             x3, x3, HEAP, lsl #32
    // 0xbf7aa8: stur            x3, [fp, #-8]
    // 0xbf7aac: LoadField: r1 = r0->field_d7
    //     0xbf7aac: ldur            w1, [x0, #0xd7]
    // 0xbf7ab0: DecompressPointer r1
    //     0xbf7ab0: add             x1, x1, HEAP, lsl #32
    // 0xbf7ab4: r0 = extent()
    //     0xbf7ab4: bl              #0x85fb94  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xbf7ab8: ldur            x1, [fp, #-8]
    // 0xbf7abc: mov             x2, x0
    // 0xbf7ac0: r0 = getWordBoundary()
    //     0xbf7ac0: bl              #0xb984a8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getWordBoundary
    // 0xbf7ac4: LoadField: r2 = r0->field_f
    //     0xbf7ac4: ldur            x2, [x0, #0xf]
    // 0xbf7ac8: ldur            x1, [fp, #-0x10]
    // 0xbf7acc: r0 = _getNextWord()
    //     0xbf7acc: bl              #0xbf7b94  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_getNextWord
    // 0xbf7ad0: cmp             w0, NULL
    // 0xbf7ad4: b.ne            #0xbf7ae8
    // 0xbf7ad8: r0 = Null
    //     0xbf7ad8: mov             x0, NULL
    // 0xbf7adc: LeaveFrame
    //     0xbf7adc: mov             SP, fp
    //     0xbf7ae0: ldp             fp, lr, [SP], #0x10
    // 0xbf7ae4: ret
    //     0xbf7ae4: ret             
    // 0xbf7ae8: ldur            x1, [fp, #-0x18]
    // 0xbf7aec: tbnz            w1, #4, #0xbf7b08
    // 0xbf7af0: ldur            x1, [fp, #-0x10]
    // 0xbf7af4: LoadField: r2 = r1->field_d7
    //     0xbf7af4: ldur            w2, [x1, #0xd7]
    // 0xbf7af8: DecompressPointer r2
    //     0xbf7af8: add             x2, x2, HEAP, lsl #32
    // 0xbf7afc: ArrayLoad: r3 = r2[0]  ; List_8
    //     0xbf7afc: ldur            x3, [x2, #0x17]
    // 0xbf7b00: mov             x2, x3
    // 0xbf7b04: b               #0xbf7b10
    // 0xbf7b08: ldur            x1, [fp, #-0x10]
    // 0xbf7b0c: LoadField: r2 = r0->field_7
    //     0xbf7b0c: ldur            x2, [x0, #7]
    // 0xbf7b10: stur            x2, [fp, #-0x28]
    // 0xbf7b14: LoadField: r3 = r0->field_7
    //     0xbf7b14: ldur            x3, [x0, #7]
    // 0xbf7b18: stur            x3, [fp, #-0x20]
    // 0xbf7b1c: r0 = TextSelection()
    //     0xbf7b1c: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xbf7b20: mov             x1, x0
    // 0xbf7b24: ldur            x0, [fp, #-0x28]
    // 0xbf7b28: ArrayStore: r1[0] = r0  ; List_8
    //     0xbf7b28: stur            x0, [x1, #0x17]
    // 0xbf7b2c: ldur            x2, [fp, #-0x20]
    // 0xbf7b30: StoreField: r1->field_1f = r2
    //     0xbf7b30: stur            x2, [x1, #0x1f]
    // 0xbf7b34: r3 = Instance_TextAffinity
    //     0xbf7b34: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xbf7b38: StoreField: r1->field_27 = r3
    //     0xbf7b38: stur            w3, [x1, #0x27]
    // 0xbf7b3c: r3 = false
    //     0xbf7b3c: add             x3, NULL, #0x30  ; false
    // 0xbf7b40: StoreField: r1->field_2b = r3
    //     0xbf7b40: stur            w3, [x1, #0x2b]
    // 0xbf7b44: cmp             x0, x2
    // 0xbf7b48: b.ge            #0xbf7b54
    // 0xbf7b4c: mov             x3, x0
    // 0xbf7b50: b               #0xbf7b58
    // 0xbf7b54: mov             x3, x2
    // 0xbf7b58: cmp             x0, x2
    // 0xbf7b5c: b.ge            #0xbf7b64
    // 0xbf7b60: mov             x0, x2
    // 0xbf7b64: StoreField: r1->field_7 = r3
    //     0xbf7b64: stur            x3, [x1, #7]
    // 0xbf7b68: StoreField: r1->field_f = r0
    //     0xbf7b68: stur            x0, [x1, #0xf]
    // 0xbf7b6c: mov             x2, x1
    // 0xbf7b70: ldur            x1, [fp, #-0x10]
    // 0xbf7b74: r3 = Instance_SelectionChangedCause
    //     0xbf7b74: ldr             x3, [PP, #0x53c8]  ; [pp+0x53c8] Obj!SelectionChangedCause@12c3661
    // 0xbf7b78: r0 = _setSelection()
    //     0xbf7b78: bl              #0x87957c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_setSelection
    // 0xbf7b7c: r0 = Null
    //     0xbf7b7c: mov             x0, NULL
    // 0xbf7b80: LeaveFrame
    //     0xbf7b80: mov             SP, fp
    //     0xbf7b84: ldp             fp, lr, [SP], #0x10
    // 0xbf7b88: ret
    //     0xbf7b88: ret             
    // 0xbf7b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7b8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7b90: b               #0xbf7aa0
  }
  _ _getNextWord(/* No info */) {
    // ** addr: 0xbf7b94, size: 0x300
    // 0xbf7b94: EnterFrame
    //     0xbf7b94: stp             fp, lr, [SP, #-0x10]!
    //     0xbf7b98: mov             fp, SP
    // 0xbf7b9c: AllocStack(0x48)
    //     0xbf7b9c: sub             SP, SP, #0x48
    // 0xbf7ba0: CheckStackOverflow
    //     0xbf7ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf7ba4: cmp             SP, x16
    //     0xbf7ba8: b.ls            #0xbf7e70
    // 0xbf7bac: LoadField: r0 = r1->field_a7
    //     0xbf7bac: ldur            w0, [x1, #0xa7]
    // 0xbf7bb0: DecompressPointer r0
    //     0xbf7bb0: add             x0, x0, HEAP, lsl #32
    // 0xbf7bb4: stur            x0, [fp, #-0x10]
    // 0xbf7bb8: mov             x1, x2
    // 0xbf7bbc: stur            x1, [fp, #-8]
    // 0xbf7bc0: CheckStackOverflow
    //     0xbf7bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf7bc4: cmp             SP, x16
    //     0xbf7bc8: b.ls            #0xbf7e78
    // 0xbf7bcc: r0 = TextPosition()
    //     0xbf7bcc: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0xbf7bd0: mov             x1, x0
    // 0xbf7bd4: ldur            x0, [fp, #-8]
    // 0xbf7bd8: StoreField: r1->field_7 = r0
    //     0xbf7bd8: stur            x0, [x1, #7]
    // 0xbf7bdc: r0 = Instance_TextAffinity
    //     0xbf7bdc: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xbf7be0: StoreField: r1->field_f = r0
    //     0xbf7be0: stur            w0, [x1, #0xf]
    // 0xbf7be4: ldur            x3, [fp, #-0x10]
    // 0xbf7be8: LoadField: r2 = r3->field_7
    //     0xbf7be8: ldur            w2, [x3, #7]
    // 0xbf7bec: DecompressPointer r2
    //     0xbf7bec: add             x2, x2, HEAP, lsl #32
    // 0xbf7bf0: cmp             w2, NULL
    // 0xbf7bf4: b.eq            #0xbf7e80
    // 0xbf7bf8: LoadField: r4 = r2->field_7
    //     0xbf7bf8: ldur            w4, [x2, #7]
    // 0xbf7bfc: DecompressPointer r4
    //     0xbf7bfc: add             x4, x4, HEAP, lsl #32
    // 0xbf7c00: LoadField: r2 = r4->field_f
    //     0xbf7c00: ldur            w2, [x4, #0xf]
    // 0xbf7c04: DecompressPointer r2
    //     0xbf7c04: add             x2, x2, HEAP, lsl #32
    // 0xbf7c08: mov             x16, x1
    // 0xbf7c0c: mov             x1, x2
    // 0xbf7c10: mov             x2, x16
    // 0xbf7c14: r0 = getWordBoundary()
    //     0xbf7c14: bl              #0xb97efc  ; [dart:ui] _NativeParagraph::getWordBoundary
    // 0xbf7c18: mov             x2, x0
    // 0xbf7c1c: stur            x2, [fp, #-0x30]
    // 0xbf7c20: LoadField: r0 = r2->field_7
    //     0xbf7c20: ldur            x0, [x2, #7]
    // 0xbf7c24: tbnz            x0, #0x3f, #0xbf7e60
    // 0xbf7c28: LoadField: r3 = r2->field_f
    //     0xbf7c28: ldur            x3, [x2, #0xf]
    // 0xbf7c2c: stur            x3, [fp, #-0x28]
    // 0xbf7c30: tbnz            x3, #0x3f, #0xbf7e60
    // 0xbf7c34: cmp             x0, x3
    // 0xbf7c38: b.eq            #0xbf7e60
    // 0xbf7c3c: mov             x5, x0
    // 0xbf7c40: ldur            x4, [fp, #-0x10]
    // 0xbf7c44: stur            x5, [fp, #-8]
    // 0xbf7c48: CheckStackOverflow
    //     0xbf7c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf7c4c: cmp             SP, x16
    //     0xbf7c50: b.ls            #0xbf7e84
    // 0xbf7c54: cmp             x5, x3
    // 0xbf7c58: b.ge            #0xbf7e54
    // 0xbf7c5c: LoadField: r6 = r4->field_f
    //     0xbf7c5c: ldur            w6, [x4, #0xf]
    // 0xbf7c60: DecompressPointer r6
    //     0xbf7c60: add             x6, x6, HEAP, lsl #32
    // 0xbf7c64: stur            x6, [fp, #-0x20]
    // 0xbf7c68: cmp             w6, NULL
    // 0xbf7c6c: b.eq            #0xbf7e8c
    // 0xbf7c70: r0 = BoxInt64Instr(r5)
    //     0xbf7c70: sbfiz           x0, x5, #1, #0x1f
    //     0xbf7c74: cmp             x5, x0, asr #1
    //     0xbf7c78: b.eq            #0xbf7c84
    //     0xbf7c7c: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf7c80: stur            x5, [x0, #7]
    // 0xbf7c84: stur            x0, [fp, #-0x18]
    // 0xbf7c88: r1 = 3
    //     0xbf7c88: mov             x1, #3
    // 0xbf7c8c: r0 = AllocateContext()
    //     0xbf7c8c: bl              #0x13de838  ; AllocateContextStub
    // 0xbf7c90: mov             x1, x0
    // 0xbf7c94: ldur            x0, [fp, #-0x18]
    // 0xbf7c98: stur            x1, [fp, #-0x38]
    // 0xbf7c9c: StoreField: r1->field_f = r0
    //     0xbf7c9c: stur            w0, [x1, #0xf]
    // 0xbf7ca0: ldur            x0, [fp, #-8]
    // 0xbf7ca4: tbz             x0, #0x3f, #0xbf7cb0
    // 0xbf7ca8: r1 = Null
    //     0xbf7ca8: mov             x1, NULL
    // 0xbf7cac: b               #0xbf7d38
    // 0xbf7cb0: ldur            x2, [fp, #-0x20]
    // 0xbf7cb4: r0 = Accumulator()
    //     0xbf7cb4: bl              #0xb97ef0  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0xbf7cb8: StoreField: r0->field_7 = rZR
    //     0xbf7cb8: stur            xzr, [x0, #7]
    // 0xbf7cbc: ldur            x3, [fp, #-0x38]
    // 0xbf7cc0: StoreField: r3->field_13 = r0
    //     0xbf7cc0: stur            w0, [x3, #0x13]
    // 0xbf7cc4: ArrayStore: r3[0] = rNULL  ; List_4
    //     0xbf7cc4: stur            NULL, [x3, #0x17]
    // 0xbf7cc8: mov             x2, x3
    // 0xbf7ccc: r1 = Function '<anonymous closure>':.
    //     0xbf7ccc: add             x1, PP, #0x8f, lsl #12  ; [pp+0x8f7e0] AnonymousClosure: (0xb9822c), in [package:flutter/src/painting/inline_span.dart] InlineSpan::codeUnitAt (0xb97dec)
    //     0xbf7cd0: ldr             x1, [x1, #0x7e0]
    // 0xbf7cd4: r0 = AllocateClosure()
    //     0xbf7cd4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf7cd8: ldur            x1, [fp, #-0x20]
    // 0xbf7cdc: r2 = LoadClassIdInstr(r1)
    //     0xbf7cdc: ldur            x2, [x1, #-1]
    //     0xbf7ce0: ubfx            x2, x2, #0xc, #0x14
    // 0xbf7ce4: r17 = -5790
    //     0xbf7ce4: mov             x17, #-0x169e
    // 0xbf7ce8: add             x16, x2, x17
    // 0xbf7cec: cmp             x16, #1
    // 0xbf7cf0: b.hi            #0xbf7d08
    // 0xbf7cf4: stp             x1, x0, [SP]
    // 0xbf7cf8: ClosureCall
    //     0xbf7cf8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbf7cfc: ldur            x2, [x0, #0x1f]
    //     0xbf7d00: blr             x2
    // 0xbf7d04: b               #0xbf7d28
    // 0xbf7d08: r2 = LoadClassIdInstr(r1)
    //     0xbf7d08: ldur            x2, [x1, #-1]
    //     0xbf7d0c: ubfx            x2, x2, #0xc, #0x14
    // 0xbf7d10: mov             x16, x0
    // 0xbf7d14: mov             x0, x2
    // 0xbf7d18: mov             x2, x16
    // 0xbf7d1c: r0 = GDT[cid_x0 + -0x18]()
    //     0xbf7d1c: sub             lr, x0, #0x18
    //     0xbf7d20: ldr             lr, [x21, lr, lsl #3]
    //     0xbf7d24: blr             lr
    // 0xbf7d28: ldur            x1, [fp, #-0x38]
    // 0xbf7d2c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf7d2c: ldur            w2, [x1, #0x17]
    // 0xbf7d30: DecompressPointer r2
    //     0xbf7d30: add             x2, x2, HEAP, lsl #32
    // 0xbf7d34: mov             x1, x2
    // 0xbf7d38: cmp             w1, NULL
    // 0xbf7d3c: b.eq            #0xbf7e90
    // 0xbf7d40: r2 = LoadInt32Instr(r1)
    //     0xbf7d40: sbfx            x2, x1, #1, #0x1f
    // 0xbf7d44: cmp             x2, #2, lsl #12
    // 0xbf7d48: b.gt            #0xbf7dd4
    // 0xbf7d4c: cmp             x2, #0x1d
    // 0xbf7d50: b.gt            #0xbf7d94
    // 0xbf7d54: cmp             x2, #0xc
    // 0xbf7d58: b.gt            #0xbf7d78
    // 0xbf7d5c: cmp             x2, #0xa
    // 0xbf7d60: b.gt            #0xbf7e30
    // 0xbf7d64: cmp             x2, #9
    // 0xbf7d68: b.gt            #0xbf7e30
    // 0xbf7d6c: cmp             w1, #0x12
    // 0xbf7d70: b.ne            #0xbf7e44
    // 0xbf7d74: b               #0xbf7e30
    // 0xbf7d78: cmp             x2, #0x1c
    // 0xbf7d7c: b.gt            #0xbf7e30
    // 0xbf7d80: cmp             x2, #0xd
    // 0xbf7d84: b.le            #0xbf7e30
    // 0xbf7d88: cmp             x2, #0x1c
    // 0xbf7d8c: b.lt            #0xbf7e44
    // 0xbf7d90: b               #0xbf7e30
    // 0xbf7d94: cmp             x2, #0x20
    // 0xbf7d98: b.le            #0xbf7e30
    // 0xbf7d9c: cmp             x2, #0xa0
    // 0xbf7da0: b.lt            #0xbf7e44
    // 0xbf7da4: r17 = 5760
    //     0xbf7da4: mov             x17, #0x1680
    // 0xbf7da8: cmp             x2, x17
    // 0xbf7dac: b.gt            #0xbf7dc8
    // 0xbf7db0: cmp             x2, #0xa0
    // 0xbf7db4: b.le            #0xbf7e30
    // 0xbf7db8: r17 = 5760
    //     0xbf7db8: mov             x17, #0x1680
    // 0xbf7dbc: cmp             x2, x17
    // 0xbf7dc0: b.lt            #0xbf7e44
    // 0xbf7dc4: b               #0xbf7e30
    // 0xbf7dc8: cmp             x2, #2, lsl #12
    // 0xbf7dcc: b.lt            #0xbf7e44
    // 0xbf7dd0: b               #0xbf7e30
    // 0xbf7dd4: r17 = 8199
    //     0xbf7dd4: mov             x17, #0x2007
    // 0xbf7dd8: cmp             x2, x17
    // 0xbf7ddc: b.le            #0xbf7e30
    // 0xbf7de0: r17 = 8202
    //     0xbf7de0: mov             x17, #0x200a
    // 0xbf7de4: cmp             x2, x17
    // 0xbf7de8: b.le            #0xbf7e30
    // 0xbf7dec: r17 = 8239
    //     0xbf7dec: mov             x17, #0x202f
    // 0xbf7df0: cmp             x2, x17
    // 0xbf7df4: b.lt            #0xbf7e44
    // 0xbf7df8: r17 = 8287
    //     0xbf7df8: mov             x17, #0x205f
    // 0xbf7dfc: cmp             x2, x17
    // 0xbf7e00: b.gt            #0xbf7e20
    // 0xbf7e04: r17 = 8239
    //     0xbf7e04: mov             x17, #0x202f
    // 0xbf7e08: cmp             x2, x17
    // 0xbf7e0c: b.le            #0xbf7e30
    // 0xbf7e10: r17 = 8287
    //     0xbf7e10: mov             x17, #0x205f
    // 0xbf7e14: cmp             x2, x17
    // 0xbf7e18: b.lt            #0xbf7e44
    // 0xbf7e1c: b               #0xbf7e30
    // 0xbf7e20: cmp             x2, #3, lsl #12
    // 0xbf7e24: b.lt            #0xbf7e44
    // 0xbf7e28: cmp             w1, #6, lsl #12
    // 0xbf7e2c: b.ne            #0xbf7e44
    // 0xbf7e30: ldur            x1, [fp, #-8]
    // 0xbf7e34: add             x5, x1, #1
    // 0xbf7e38: ldur            x2, [fp, #-0x30]
    // 0xbf7e3c: ldur            x3, [fp, #-0x28]
    // 0xbf7e40: b               #0xbf7c40
    // 0xbf7e44: ldur            x0, [fp, #-0x30]
    // 0xbf7e48: LeaveFrame
    //     0xbf7e48: mov             SP, fp
    //     0xbf7e4c: ldp             fp, lr, [SP], #0x10
    // 0xbf7e50: ret
    //     0xbf7e50: ret             
    // 0xbf7e54: ldur            x1, [fp, #-0x28]
    // 0xbf7e58: ldur            x0, [fp, #-0x10]
    // 0xbf7e5c: b               #0xbf7bbc
    // 0xbf7e60: r0 = Null
    //     0xbf7e60: mov             x0, NULL
    // 0xbf7e64: LeaveFrame
    //     0xbf7e64: mov             SP, fp
    //     0xbf7e68: ldp             fp, lr, [SP], #0x10
    // 0xbf7e6c: ret
    //     0xbf7e6c: ret             
    // 0xbf7e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7e70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7e74: b               #0xbf7bac
    // 0xbf7e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7e78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7e7c: b               #0xbf7bcc
    // 0xbf7e80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf7e80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf7e84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7e84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7e88: b               #0xbf7c54
    // 0xbf7e8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf7e8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf7e90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf7e90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleMoveCursorBackwardByCharacter(/* No info */) {
    // ** addr: 0xbf8058, size: 0x11c
    // 0xbf8058: EnterFrame
    //     0xbf8058: stp             fp, lr, [SP, #-0x10]!
    //     0xbf805c: mov             fp, SP
    // 0xbf8060: AllocStack(0x20)
    //     0xbf8060: sub             SP, SP, #0x20
    // 0xbf8064: SetupParameters(RenderEditable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbf8064: mov             x3, x1
    //     0xbf8068: mov             x0, x2
    //     0xbf806c: stur            x1, [fp, #-8]
    //     0xbf8070: stur            x2, [fp, #-0x10]
    // 0xbf8074: CheckStackOverflow
    //     0xbf8074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8078: cmp             SP, x16
    //     0xbf807c: b.ls            #0xbf816c
    // 0xbf8080: LoadField: r1 = r3->field_a7
    //     0xbf8080: ldur            w1, [x3, #0xa7]
    // 0xbf8084: DecompressPointer r1
    //     0xbf8084: add             x1, x1, HEAP, lsl #32
    // 0xbf8088: LoadField: r2 = r3->field_d7
    //     0xbf8088: ldur            w2, [x3, #0xd7]
    // 0xbf808c: DecompressPointer r2
    //     0xbf808c: add             x2, x2, HEAP, lsl #32
    // 0xbf8090: LoadField: r4 = r2->field_1f
    //     0xbf8090: ldur            x4, [x2, #0x1f]
    // 0xbf8094: mov             x2, x4
    // 0xbf8098: r0 = getOffsetBefore()
    //     0xbf8098: bl              #0xbf83a4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetBefore
    // 0xbf809c: stur            x0, [fp, #-0x20]
    // 0xbf80a0: cmp             w0, NULL
    // 0xbf80a4: b.ne            #0xbf80b8
    // 0xbf80a8: r0 = Null
    //     0xbf80a8: mov             x0, NULL
    // 0xbf80ac: LeaveFrame
    //     0xbf80ac: mov             SP, fp
    //     0xbf80b0: ldp             fp, lr, [SP], #0x10
    // 0xbf80b4: ret
    //     0xbf80b4: ret             
    // 0xbf80b8: ldur            x1, [fp, #-0x10]
    // 0xbf80bc: tbz             w1, #4, #0xbf80d8
    // 0xbf80c0: r1 = LoadInt32Instr(r0)
    //     0xbf80c0: sbfx            x1, x0, #1, #0x1f
    //     0xbf80c4: tbz             w0, #0, #0xbf80cc
    //     0xbf80c8: ldur            x1, [x0, #7]
    // 0xbf80cc: mov             x2, x1
    // 0xbf80d0: ldur            x1, [fp, #-8]
    // 0xbf80d4: b               #0xbf80ec
    // 0xbf80d8: ldur            x1, [fp, #-8]
    // 0xbf80dc: LoadField: r2 = r1->field_d7
    //     0xbf80dc: ldur            w2, [x1, #0xd7]
    // 0xbf80e0: DecompressPointer r2
    //     0xbf80e0: add             x2, x2, HEAP, lsl #32
    // 0xbf80e4: ArrayLoad: r3 = r2[0]  ; List_8
    //     0xbf80e4: ldur            x3, [x2, #0x17]
    // 0xbf80e8: mov             x2, x3
    // 0xbf80ec: stur            x2, [fp, #-0x18]
    // 0xbf80f0: r0 = TextSelection()
    //     0xbf80f0: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xbf80f4: mov             x1, x0
    // 0xbf80f8: ldur            x0, [fp, #-0x18]
    // 0xbf80fc: ArrayStore: r1[0] = r0  ; List_8
    //     0xbf80fc: stur            x0, [x1, #0x17]
    // 0xbf8100: ldur            x2, [fp, #-0x20]
    // 0xbf8104: r3 = LoadInt32Instr(r2)
    //     0xbf8104: sbfx            x3, x2, #1, #0x1f
    //     0xbf8108: tbz             w2, #0, #0xbf8110
    //     0xbf810c: ldur            x3, [x2, #7]
    // 0xbf8110: StoreField: r1->field_1f = r3
    //     0xbf8110: stur            x3, [x1, #0x1f]
    // 0xbf8114: r2 = Instance_TextAffinity
    //     0xbf8114: ldr             x2, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xbf8118: StoreField: r1->field_27 = r2
    //     0xbf8118: stur            w2, [x1, #0x27]
    // 0xbf811c: r2 = false
    //     0xbf811c: add             x2, NULL, #0x30  ; false
    // 0xbf8120: StoreField: r1->field_2b = r2
    //     0xbf8120: stur            w2, [x1, #0x2b]
    // 0xbf8124: cmp             x0, x3
    // 0xbf8128: b.ge            #0xbf8134
    // 0xbf812c: mov             x2, x0
    // 0xbf8130: b               #0xbf8138
    // 0xbf8134: mov             x2, x3
    // 0xbf8138: cmp             x0, x3
    // 0xbf813c: b.ge            #0xbf8144
    // 0xbf8140: mov             x0, x3
    // 0xbf8144: StoreField: r1->field_7 = r2
    //     0xbf8144: stur            x2, [x1, #7]
    // 0xbf8148: StoreField: r1->field_f = r0
    //     0xbf8148: stur            x0, [x1, #0xf]
    // 0xbf814c: mov             x2, x1
    // 0xbf8150: ldur            x1, [fp, #-8]
    // 0xbf8154: r3 = Instance_SelectionChangedCause
    //     0xbf8154: ldr             x3, [PP, #0x53c8]  ; [pp+0x53c8] Obj!SelectionChangedCause@12c3661
    // 0xbf8158: r0 = _setSelection()
    //     0xbf8158: bl              #0x87957c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_setSelection
    // 0xbf815c: r0 = Null
    //     0xbf815c: mov             x0, NULL
    // 0xbf8160: LeaveFrame
    //     0xbf8160: mov             SP, fp
    //     0xbf8164: ldp             fp, lr, [SP], #0x10
    // 0xbf8168: ret
    //     0xbf8168: ret             
    // 0xbf816c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf816c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8170: b               #0xbf8080
  }
  _ _handleMoveCursorBackwardByWord(/* No info */) {
    // ** addr: 0xbf8288, size: 0x11c
    // 0xbf8288: EnterFrame
    //     0xbf8288: stp             fp, lr, [SP, #-0x10]!
    //     0xbf828c: mov             fp, SP
    // 0xbf8290: AllocStack(0x28)
    //     0xbf8290: sub             SP, SP, #0x28
    // 0xbf8294: SetupParameters(RenderEditable this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xbf8294: mov             x0, x1
    //     0xbf8298: stur            x1, [fp, #-0x10]
    //     0xbf829c: stur            x2, [fp, #-0x18]
    // 0xbf82a0: CheckStackOverflow
    //     0xbf82a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf82a4: cmp             SP, x16
    //     0xbf82a8: b.ls            #0xbf839c
    // 0xbf82ac: LoadField: r3 = r0->field_a7
    //     0xbf82ac: ldur            w3, [x0, #0xa7]
    // 0xbf82b0: DecompressPointer r3
    //     0xbf82b0: add             x3, x3, HEAP, lsl #32
    // 0xbf82b4: stur            x3, [fp, #-8]
    // 0xbf82b8: LoadField: r1 = r0->field_d7
    //     0xbf82b8: ldur            w1, [x0, #0xd7]
    // 0xbf82bc: DecompressPointer r1
    //     0xbf82bc: add             x1, x1, HEAP, lsl #32
    // 0xbf82c0: r0 = extent()
    //     0xbf82c0: bl              #0x85fb94  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0xbf82c4: ldur            x1, [fp, #-8]
    // 0xbf82c8: mov             x2, x0
    // 0xbf82cc: r0 = getWordBoundary()
    //     0xbf82cc: bl              #0xb984a8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getWordBoundary
    // 0xbf82d0: LoadField: r1 = r0->field_7
    //     0xbf82d0: ldur            x1, [x0, #7]
    // 0xbf82d4: sub             x2, x1, #1
    // 0xbf82d8: ldur            x1, [fp, #-0x10]
    // 0xbf82dc: r0 = _getPreviousWord()
    //     0xbf82dc: bl              #0xb97ab0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_getPreviousWord
    // 0xbf82e0: cmp             w0, NULL
    // 0xbf82e4: b.ne            #0xbf82f8
    // 0xbf82e8: r0 = Null
    //     0xbf82e8: mov             x0, NULL
    // 0xbf82ec: LeaveFrame
    //     0xbf82ec: mov             SP, fp
    //     0xbf82f0: ldp             fp, lr, [SP], #0x10
    // 0xbf82f4: ret
    //     0xbf82f4: ret             
    // 0xbf82f8: ldur            x1, [fp, #-0x18]
    // 0xbf82fc: tbnz            w1, #4, #0xbf8318
    // 0xbf8300: ldur            x1, [fp, #-0x10]
    // 0xbf8304: LoadField: r2 = r1->field_d7
    //     0xbf8304: ldur            w2, [x1, #0xd7]
    // 0xbf8308: DecompressPointer r2
    //     0xbf8308: add             x2, x2, HEAP, lsl #32
    // 0xbf830c: ArrayLoad: r3 = r2[0]  ; List_8
    //     0xbf830c: ldur            x3, [x2, #0x17]
    // 0xbf8310: mov             x2, x3
    // 0xbf8314: b               #0xbf8320
    // 0xbf8318: ldur            x1, [fp, #-0x10]
    // 0xbf831c: LoadField: r2 = r0->field_7
    //     0xbf831c: ldur            x2, [x0, #7]
    // 0xbf8320: stur            x2, [fp, #-0x28]
    // 0xbf8324: LoadField: r3 = r0->field_7
    //     0xbf8324: ldur            x3, [x0, #7]
    // 0xbf8328: stur            x3, [fp, #-0x20]
    // 0xbf832c: r0 = TextSelection()
    //     0xbf832c: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xbf8330: mov             x1, x0
    // 0xbf8334: ldur            x0, [fp, #-0x28]
    // 0xbf8338: ArrayStore: r1[0] = r0  ; List_8
    //     0xbf8338: stur            x0, [x1, #0x17]
    // 0xbf833c: ldur            x2, [fp, #-0x20]
    // 0xbf8340: StoreField: r1->field_1f = r2
    //     0xbf8340: stur            x2, [x1, #0x1f]
    // 0xbf8344: r3 = Instance_TextAffinity
    //     0xbf8344: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xbf8348: StoreField: r1->field_27 = r3
    //     0xbf8348: stur            w3, [x1, #0x27]
    // 0xbf834c: r3 = false
    //     0xbf834c: add             x3, NULL, #0x30  ; false
    // 0xbf8350: StoreField: r1->field_2b = r3
    //     0xbf8350: stur            w3, [x1, #0x2b]
    // 0xbf8354: cmp             x0, x2
    // 0xbf8358: b.ge            #0xbf8364
    // 0xbf835c: mov             x3, x0
    // 0xbf8360: b               #0xbf8368
    // 0xbf8364: mov             x3, x2
    // 0xbf8368: cmp             x0, x2
    // 0xbf836c: b.ge            #0xbf8374
    // 0xbf8370: mov             x0, x2
    // 0xbf8374: StoreField: r1->field_7 = r3
    //     0xbf8374: stur            x3, [x1, #7]
    // 0xbf8378: StoreField: r1->field_f = r0
    //     0xbf8378: stur            x0, [x1, #0xf]
    // 0xbf837c: mov             x2, x1
    // 0xbf8380: ldur            x1, [fp, #-0x10]
    // 0xbf8384: r3 = Instance_SelectionChangedCause
    //     0xbf8384: ldr             x3, [PP, #0x53c8]  ; [pp+0x53c8] Obj!SelectionChangedCause@12c3661
    // 0xbf8388: r0 = _setSelection()
    //     0xbf8388: bl              #0x87957c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_setSelection
    // 0xbf838c: r0 = Null
    //     0xbf838c: mov             x0, NULL
    // 0xbf8390: LeaveFrame
    //     0xbf8390: mov             SP, fp
    //     0xbf8394: ldp             fp, lr, [SP], #0x10
    // 0xbf8398: ret
    //     0xbf8398: ret             
    // 0xbf839c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf839c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf83a0: b               #0xbf82ac
  }
  _ _handleSetText(/* No info */) {
    // ** addr: 0xbf85a4, size: 0xac
    // 0xbf85a4: EnterFrame
    //     0xbf85a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf85a8: mov             fp, SP
    // 0xbf85ac: AllocStack(0x20)
    //     0xbf85ac: sub             SP, SP, #0x20
    // 0xbf85b0: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xbf85b0: stur            x2, [fp, #-0x18]
    // 0xbf85b4: CheckStackOverflow
    //     0xbf85b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf85b8: cmp             SP, x16
    //     0xbf85bc: b.ls            #0xbf8648
    // 0xbf85c0: LoadField: r0 = r1->field_9b
    //     0xbf85c0: ldur            w0, [x1, #0x9b]
    // 0xbf85c4: DecompressPointer r0
    //     0xbf85c4: add             x0, x0, HEAP, lsl #32
    // 0xbf85c8: stur            x0, [fp, #-0x10]
    // 0xbf85cc: LoadField: r1 = r2->field_7
    //     0xbf85cc: ldur            w1, [x2, #7]
    // 0xbf85d0: stur            x1, [fp, #-8]
    // 0xbf85d4: r0 = TextSelection()
    //     0xbf85d4: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xbf85d8: mov             x1, x0
    // 0xbf85dc: r0 = Instance_TextAffinity
    //     0xbf85dc: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xbf85e0: stur            x1, [fp, #-0x20]
    // 0xbf85e4: StoreField: r1->field_27 = r0
    //     0xbf85e4: stur            w0, [x1, #0x27]
    // 0xbf85e8: ldur            x0, [fp, #-8]
    // 0xbf85ec: r2 = LoadInt32Instr(r0)
    //     0xbf85ec: sbfx            x2, x0, #1, #0x1f
    // 0xbf85f0: ArrayStore: r1[0] = r2  ; List_8
    //     0xbf85f0: stur            x2, [x1, #0x17]
    // 0xbf85f4: StoreField: r1->field_1f = r2
    //     0xbf85f4: stur            x2, [x1, #0x1f]
    // 0xbf85f8: r0 = false
    //     0xbf85f8: add             x0, NULL, #0x30  ; false
    // 0xbf85fc: StoreField: r1->field_2b = r0
    //     0xbf85fc: stur            w0, [x1, #0x2b]
    // 0xbf8600: StoreField: r1->field_7 = r2
    //     0xbf8600: stur            x2, [x1, #7]
    // 0xbf8604: StoreField: r1->field_f = r2
    //     0xbf8604: stur            x2, [x1, #0xf]
    // 0xbf8608: r0 = TextEditingValue()
    //     0xbf8608: bl              #0x86e1d4  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0xbf860c: mov             x1, x0
    // 0xbf8610: ldur            x0, [fp, #-0x18]
    // 0xbf8614: StoreField: r1->field_7 = r0
    //     0xbf8614: stur            w0, [x1, #7]
    // 0xbf8618: ldur            x0, [fp, #-0x20]
    // 0xbf861c: StoreField: r1->field_b = r0
    //     0xbf861c: stur            w0, [x1, #0xb]
    // 0xbf8620: r0 = Instance_TextRange
    //     0xbf8620: ldr             x0, [PP, #0x53d8]  ; [pp+0x53d8] Obj!TextRange@12a0471
    // 0xbf8624: StoreField: r1->field_f = r0
    //     0xbf8624: stur            w0, [x1, #0xf]
    // 0xbf8628: mov             x2, x1
    // 0xbf862c: ldur            x1, [fp, #-0x10]
    // 0xbf8630: r3 = Instance_SelectionChangedCause
    //     0xbf8630: ldr             x3, [PP, #0x53c8]  ; [pp+0x53c8] Obj!SelectionChangedCause@12c3661
    // 0xbf8634: r0 = userUpdateTextEditingValue()
    //     0xbf8634: bl              #0x86b020  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::userUpdateTextEditingValue
    // 0xbf8638: r0 = Null
    //     0xbf8638: mov             x0, NULL
    // 0xbf863c: LeaveFrame
    //     0xbf863c: mov             SP, fp
    //     0xbf8640: ldp             fp, lr, [SP], #0x10
    // 0xbf8644: ret
    //     0xbf8644: ret             
    // 0xbf8648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8648: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf864c: b               #0xbf85c0
  }
  _ _handleSetSelection(/* No info */) {
    // ** addr: 0xbf885c, size: 0x34
    // 0xbf885c: EnterFrame
    //     0xbf885c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8860: mov             fp, SP
    // 0xbf8864: CheckStackOverflow
    //     0xbf8864: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8868: cmp             SP, x16
    //     0xbf886c: b.ls            #0xbf8888
    // 0xbf8870: r3 = Instance_SelectionChangedCause
    //     0xbf8870: ldr             x3, [PP, #0x53c8]  ; [pp+0x53c8] Obj!SelectionChangedCause@12c3661
    // 0xbf8874: r0 = _setSelection()
    //     0xbf8874: bl              #0x87957c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_setSelection
    // 0xbf8878: r0 = Null
    //     0xbf8878: mov             x0, NULL
    // 0xbf887c: LeaveFrame
    //     0xbf887c: mov             SP, fp
    //     0xbf8880: ldp             fp, lr, [SP], #0x10
    // 0xbf8884: ret
    //     0xbf8884: ret             
    // 0xbf8888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8888: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf888c: b               #0xbf8870
  }
  get _ selectionEnabled(/* No info */) {
    // ** addr: 0xbf8890, size: 0x10
    // 0xbf8890: r17 = 259
    //     0xbf8890: mov             x17, #0x103
    // 0xbf8894: ldr             w0, [x1, x17]
    // 0xbf8898: DecompressPointer r0
    //     0xbf8898: add             x0, x0, HEAP, lsl #32
    // 0xbf889c: ret
    //     0xbf889c: ret             
  }
  [closure] void _handleMoveCursorForwardByCharacter(dynamic, bool) {
    // ** addr: 0xbf8b88, size: 0x3c
    // 0xbf8b88: EnterFrame
    //     0xbf8b88: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8b8c: mov             fp, SP
    // 0xbf8b90: ldr             x0, [fp, #0x18]
    // 0xbf8b94: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf8b94: ldur            w1, [x0, #0x17]
    // 0xbf8b98: DecompressPointer r1
    //     0xbf8b98: add             x1, x1, HEAP, lsl #32
    // 0xbf8b9c: CheckStackOverflow
    //     0xbf8b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8ba0: cmp             SP, x16
    //     0xbf8ba4: b.ls            #0xbf8bbc
    // 0xbf8ba8: ldr             x2, [fp, #0x10]
    // 0xbf8bac: r0 = _handleMoveCursorForwardByCharacter()
    //     0xbf8bac: bl              #0xbf784c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_handleMoveCursorForwardByCharacter
    // 0xbf8bb0: LeaveFrame
    //     0xbf8bb0: mov             SP, fp
    //     0xbf8bb4: ldp             fp, lr, [SP], #0x10
    // 0xbf8bb8: ret
    //     0xbf8bb8: ret             
    // 0xbf8bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8bbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8bc0: b               #0xbf8ba8
  }
  [closure] void _handleMoveCursorForwardByWord(dynamic, bool) {
    // ** addr: 0xbf8bc4, size: 0x3c
    // 0xbf8bc4: EnterFrame
    //     0xbf8bc4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8bc8: mov             fp, SP
    // 0xbf8bcc: ldr             x0, [fp, #0x18]
    // 0xbf8bd0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf8bd0: ldur            w1, [x0, #0x17]
    // 0xbf8bd4: DecompressPointer r1
    //     0xbf8bd4: add             x1, x1, HEAP, lsl #32
    // 0xbf8bd8: CheckStackOverflow
    //     0xbf8bd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8bdc: cmp             SP, x16
    //     0xbf8be0: b.ls            #0xbf8bf8
    // 0xbf8be4: ldr             x2, [fp, #0x10]
    // 0xbf8be8: r0 = _handleMoveCursorForwardByWord()
    //     0xbf8be8: bl              #0xbf7a7c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_handleMoveCursorForwardByWord
    // 0xbf8bec: LeaveFrame
    //     0xbf8bec: mov             SP, fp
    //     0xbf8bf0: ldp             fp, lr, [SP], #0x10
    // 0xbf8bf4: ret
    //     0xbf8bf4: ret             
    // 0xbf8bf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8bf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8bfc: b               #0xbf8be4
  }
  [closure] void _handleMoveCursorBackwardByCharacter(dynamic, bool) {
    // ** addr: 0xbf8c00, size: 0x3c
    // 0xbf8c00: EnterFrame
    //     0xbf8c00: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8c04: mov             fp, SP
    // 0xbf8c08: ldr             x0, [fp, #0x18]
    // 0xbf8c0c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf8c0c: ldur            w1, [x0, #0x17]
    // 0xbf8c10: DecompressPointer r1
    //     0xbf8c10: add             x1, x1, HEAP, lsl #32
    // 0xbf8c14: CheckStackOverflow
    //     0xbf8c14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8c18: cmp             SP, x16
    //     0xbf8c1c: b.ls            #0xbf8c34
    // 0xbf8c20: ldr             x2, [fp, #0x10]
    // 0xbf8c24: r0 = _handleMoveCursorBackwardByCharacter()
    //     0xbf8c24: bl              #0xbf8058  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_handleMoveCursorBackwardByCharacter
    // 0xbf8c28: LeaveFrame
    //     0xbf8c28: mov             SP, fp
    //     0xbf8c2c: ldp             fp, lr, [SP], #0x10
    // 0xbf8c30: ret
    //     0xbf8c30: ret             
    // 0xbf8c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8c34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8c38: b               #0xbf8c20
  }
  [closure] void _handleMoveCursorBackwardByWord(dynamic, bool) {
    // ** addr: 0xbf8c3c, size: 0x3c
    // 0xbf8c3c: EnterFrame
    //     0xbf8c3c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8c40: mov             fp, SP
    // 0xbf8c44: ldr             x0, [fp, #0x18]
    // 0xbf8c48: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf8c48: ldur            w1, [x0, #0x17]
    // 0xbf8c4c: DecompressPointer r1
    //     0xbf8c4c: add             x1, x1, HEAP, lsl #32
    // 0xbf8c50: CheckStackOverflow
    //     0xbf8c50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8c54: cmp             SP, x16
    //     0xbf8c58: b.ls            #0xbf8c70
    // 0xbf8c5c: ldr             x2, [fp, #0x10]
    // 0xbf8c60: r0 = _handleMoveCursorBackwardByWord()
    //     0xbf8c60: bl              #0xbf8288  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_handleMoveCursorBackwardByWord
    // 0xbf8c64: LeaveFrame
    //     0xbf8c64: mov             SP, fp
    //     0xbf8c68: ldp             fp, lr, [SP], #0x10
    // 0xbf8c6c: ret
    //     0xbf8c6c: ret             
    // 0xbf8c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8c70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8c74: b               #0xbf8c5c
  }
  [closure] void _handleSetText(dynamic, String) {
    // ** addr: 0xbf8c78, size: 0x3c
    // 0xbf8c78: EnterFrame
    //     0xbf8c78: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8c7c: mov             fp, SP
    // 0xbf8c80: ldr             x0, [fp, #0x18]
    // 0xbf8c84: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf8c84: ldur            w1, [x0, #0x17]
    // 0xbf8c88: DecompressPointer r1
    //     0xbf8c88: add             x1, x1, HEAP, lsl #32
    // 0xbf8c8c: CheckStackOverflow
    //     0xbf8c8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8c90: cmp             SP, x16
    //     0xbf8c94: b.ls            #0xbf8cac
    // 0xbf8c98: ldr             x2, [fp, #0x10]
    // 0xbf8c9c: r0 = _handleSetText()
    //     0xbf8c9c: bl              #0xbf85a4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_handleSetText
    // 0xbf8ca0: LeaveFrame
    //     0xbf8ca0: mov             SP, fp
    //     0xbf8ca4: ldp             fp, lr, [SP], #0x10
    // 0xbf8ca8: ret
    //     0xbf8ca8: ret             
    // 0xbf8cac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8cac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8cb0: b               #0xbf8c98
  }
  [closure] void _handleSetSelection(dynamic, TextSelection) {
    // ** addr: 0xbf8cb4, size: 0x3c
    // 0xbf8cb4: EnterFrame
    //     0xbf8cb4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8cb8: mov             fp, SP
    // 0xbf8cbc: ldr             x0, [fp, #0x18]
    // 0xbf8cc0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbf8cc0: ldur            w1, [x0, #0x17]
    // 0xbf8cc4: DecompressPointer r1
    //     0xbf8cc4: add             x1, x1, HEAP, lsl #32
    // 0xbf8cc8: CheckStackOverflow
    //     0xbf8cc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf8ccc: cmp             SP, x16
    //     0xbf8cd0: b.ls            #0xbf8ce8
    // 0xbf8cd4: ldr             x2, [fp, #0x10]
    // 0xbf8cd8: r0 = _handleSetSelection()
    //     0xbf8cd8: bl              #0xbf885c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_handleSetSelection
    // 0xbf8cdc: LeaveFrame
    //     0xbf8cdc: mov             SP, fp
    //     0xbf8ce0: ldp             fp, lr, [SP], #0x10
    // 0xbf8ce4: ret
    //     0xbf8ce4: ret             
    // 0xbf8ce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8ce8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8cec: b               #0xbf8cd4
  }
  [closure] bool <anonymous closure>(dynamic, InlineSpanSemanticsInformation) {
    // ** addr: 0xbf8cf0, size: 0x20
    // 0xbf8cf0: ldr             x1, [SP]
    // 0xbf8cf4: LoadField: r2 = r1->field_13
    //     0xbf8cf4: ldur            w2, [x1, #0x13]
    // 0xbf8cf8: DecompressPointer r2
    //     0xbf8cf8: add             x2, x2, HEAP, lsl #32
    // 0xbf8cfc: cmp             w2, NULL
    // 0xbf8d00: r16 = true
    //     0xbf8d00: add             x16, NULL, #0x20  ; true
    // 0xbf8d04: r17 = false
    //     0xbf8d04: add             x17, NULL, #0x30  ; false
    // 0xbf8d08: csel            x0, x16, x17, ne
    // 0xbf8d0c: ret
    //     0xbf8d0c: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc0321c, size: 0x164
    // 0xc0321c: EnterFrame
    //     0xc0321c: stp             fp, lr, [SP, #-0x10]!
    //     0xc03220: mov             fp, SP
    // 0xc03224: AllocStack(0x8)
    //     0xc03224: sub             SP, SP, #8
    // 0xc03228: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xc03228: mov             x0, x1
    //     0xc0322c: stur            x1, [fp, #-8]
    // 0xc03230: CheckStackOverflow
    //     0xc03230: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc03234: cmp             SP, x16
    //     0xc03238: b.ls            #0xc03378
    // 0xc0323c: r17 = 339
    //     0xc0323c: mov             x17, #0x153
    // 0xc03240: ldr             w1, [x0, x17]
    // 0xc03244: DecompressPointer r1
    //     0xc03244: add             x1, x1, HEAP, lsl #32
    // 0xc03248: r2 = Null
    //     0xc03248: mov             x2, NULL
    // 0xc0324c: r0 = layer=()
    //     0xc0324c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc03250: ldur            x0, [fp, #-8]
    // 0xc03254: LoadField: r1 = r0->field_63
    //     0xc03254: ldur            w1, [x0, #0x63]
    // 0xc03258: DecompressPointer r1
    //     0xc03258: add             x1, x1, HEAP, lsl #32
    // 0xc0325c: cmp             w1, NULL
    // 0xc03260: b.eq            #0xc0326c
    // 0xc03264: r0 = dispose()
    //     0xc03264: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc03268: ldur            x0, [fp, #-8]
    // 0xc0326c: StoreField: r0->field_63 = rNULL
    //     0xc0326c: stur            NULL, [x0, #0x63]
    // 0xc03270: LoadField: r1 = r0->field_67
    //     0xc03270: ldur            w1, [x0, #0x67]
    // 0xc03274: DecompressPointer r1
    //     0xc03274: add             x1, x1, HEAP, lsl #32
    // 0xc03278: cmp             w1, NULL
    // 0xc0327c: b.eq            #0xc03288
    // 0xc03280: r0 = dispose()
    //     0xc03280: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc03284: ldur            x0, [fp, #-8]
    // 0xc03288: StoreField: r0->field_67 = rNULL
    //     0xc03288: stur            NULL, [x0, #0x67]
    // 0xc0328c: r17 = 343
    //     0xc0328c: mov             x17, #0x157
    // 0xc03290: ldr             w1, [x0, x17]
    // 0xc03294: DecompressPointer r1
    //     0xc03294: add             x1, x1, HEAP, lsl #32
    // 0xc03298: r2 = Null
    //     0xc03298: mov             x2, NULL
    // 0xc0329c: r0 = layer=()
    //     0xc0329c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc032a0: ldur            x0, [fp, #-8]
    // 0xc032a4: LoadField: r1 = r0->field_7f
    //     0xc032a4: ldur            w1, [x0, #0x7f]
    // 0xc032a8: DecompressPointer r1
    //     0xc032a8: add             x1, x1, HEAP, lsl #32
    // 0xc032ac: cmp             w1, NULL
    // 0xc032b0: b.eq            #0xc032bc
    // 0xc032b4: r0 = dispose()
    //     0xc032b4: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xc032b8: ldur            x0, [fp, #-8]
    // 0xc032bc: LoadField: r1 = r0->field_83
    //     0xc032bc: ldur            w1, [x0, #0x83]
    // 0xc032c0: DecompressPointer r1
    //     0xc032c0: add             x1, x1, HEAP, lsl #32
    // 0xc032c4: cmp             w1, NULL
    // 0xc032c8: b.eq            #0xc032d4
    // 0xc032cc: r0 = dispose()
    //     0xc032cc: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xc032d0: ldur            x0, [fp, #-8]
    // 0xc032d4: LoadField: r1 = r0->field_9f
    //     0xc032d4: ldur            w1, [x0, #0x9f]
    // 0xc032d8: DecompressPointer r1
    //     0xc032d8: add             x1, x1, HEAP, lsl #32
    // 0xc032dc: r0 = dispose()
    //     0xc032dc: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xc032e0: ldur            x0, [fp, #-8]
    // 0xc032e4: LoadField: r1 = r0->field_a3
    //     0xc032e4: ldur            w1, [x0, #0xa3]
    // 0xc032e8: DecompressPointer r1
    //     0xc032e8: add             x1, x1, HEAP, lsl #32
    // 0xc032ec: r0 = dispose()
    //     0xc032ec: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xc032f0: ldur            x0, [fp, #-8]
    // 0xc032f4: LoadField: r1 = r0->field_7b
    //     0xc032f4: ldur            w1, [x0, #0x7b]
    // 0xc032f8: DecompressPointer r1
    //     0xc032f8: add             x1, x1, HEAP, lsl #32
    // 0xc032fc: r0 = dispose()
    //     0xc032fc: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xc03300: ldur            x0, [fp, #-8]
    // 0xc03304: LoadField: r1 = r0->field_77
    //     0xc03304: ldur            w1, [x0, #0x77]
    // 0xc03308: DecompressPointer r1
    //     0xc03308: add             x1, x1, HEAP, lsl #32
    // 0xc0330c: r0 = dispose()
    //     0xc0330c: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xc03310: ldur            x1, [fp, #-8]
    // 0xc03314: LoadField: r0 = r1->field_73
    //     0xc03314: ldur            w0, [x1, #0x73]
    // 0xc03318: DecompressPointer r0
    //     0xc03318: add             x0, x0, HEAP, lsl #32
    // 0xc0331c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc03320: cmp             w0, w16
    // 0xc03324: b.ne            #0xc03330
    // 0xc03328: r2 = _caretPainter
    //     0xc03328: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0xc0332c: r0 = InitLateFinalInstanceField()
    //     0xc0332c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xc03330: mov             x1, x0
    // 0xc03334: r0 = dispose()
    //     0xc03334: bl              #0x10ef878  ; [dart:mixin_deduplication] _MixinApplication276&Object&ChangeNotifier::dispose
    // 0xc03338: ldur            x0, [fp, #-8]
    // 0xc0333c: LoadField: r1 = r0->field_a7
    //     0xc0333c: ldur            w1, [x0, #0xa7]
    // 0xc03340: DecompressPointer r1
    //     0xc03340: add             x1, x1, HEAP, lsl #32
    // 0xc03344: r0 = dispose()
    //     0xc03344: bl              #0xbcb780  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0xc03348: ldur            x0, [fp, #-8]
    // 0xc0334c: LoadField: r1 = r0->field_b3
    //     0xc0334c: ldur            w1, [x0, #0xb3]
    // 0xc03350: DecompressPointer r1
    //     0xc03350: add             x1, x1, HEAP, lsl #32
    // 0xc03354: cmp             w1, NULL
    // 0xc03358: b.eq            #0xc03360
    // 0xc0335c: r0 = dispose()
    //     0xc0335c: bl              #0xbcb780  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0xc03360: ldur            x1, [fp, #-8]
    // 0xc03364: r0 = dispose()
    //     0xc03364: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc03368: r0 = Null
    //     0xc03368: mov             x0, NULL
    // 0xc0336c: LeaveFrame
    //     0xc0336c: mov             SP, fp
    //     0xc03370: ldp             fp, lr, [SP], #0x10
    // 0xc03374: ret
    //     0xc03374: ret             
    // 0xc03378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc03378: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0337c: b               #0xc0323c
  }
  _ detach(/* No info */) {
    // ** addr: 0xc065f4, size: 0x11c
    // 0xc065f4: EnterFrame
    //     0xc065f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc065f8: mov             fp, SP
    // 0xc065fc: AllocStack(0x10)
    //     0xc065fc: sub             SP, SP, #0x10
    // 0xc06600: SetupParameters(RenderEditable this /* r1 => r2, fp-0x8 */)
    //     0xc06600: mov             x2, x1
    //     0xc06604: stur            x1, [fp, #-8]
    // 0xc06608: CheckStackOverflow
    //     0xc06608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0660c: cmp             SP, x16
    //     0xc06610: b.ls            #0xc066f0
    // 0xc06614: r17 = 283
    //     0xc06614: mov             x17, #0x11b
    // 0xc06618: ldr             w1, [x2, x17]
    // 0xc0661c: DecompressPointer r1
    //     0xc0661c: add             x1, x1, HEAP, lsl #32
    // 0xc06620: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06624: cmp             w1, w16
    // 0xc06628: b.eq            #0xc066f8
    // 0xc0662c: r0 = dispose()
    //     0xc0662c: bl              #0xbb1708  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::dispose
    // 0xc06630: ldur            x2, [fp, #-8]
    // 0xc06634: r17 = 287
    //     0xc06634: mov             x17, #0x11f
    // 0xc06638: ldr             w1, [x2, x17]
    // 0xc0663c: DecompressPointer r1
    //     0xc0663c: add             x1, x1, HEAP, lsl #32
    // 0xc06640: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06644: cmp             w1, w16
    // 0xc06648: b.eq            #0xc06704
    // 0xc0664c: r0 = dispose()
    //     0xc0664c: bl              #0xbb1708  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::dispose
    // 0xc06650: ldur            x0, [fp, #-8]
    // 0xc06654: LoadField: r3 = r0->field_db
    //     0xc06654: ldur            w3, [x0, #0xdb]
    // 0xc06658: DecompressPointer r3
    //     0xc06658: add             x3, x3, HEAP, lsl #32
    // 0xc0665c: mov             x2, x0
    // 0xc06660: stur            x3, [fp, #-0x10]
    // 0xc06664: r1 = Function 'markNeedsPaint':.
    //     0xc06664: add             x1, PP, #0xad, lsl #12  ; [pp+0xad650] AnonymousClosure: (0xbf0650), in [package:flutter/src/rendering/editable.dart] RenderEditable::markNeedsPaint (0xbf05e0)
    //     0xc06668: ldr             x1, [x1, #0x650]
    // 0xc0666c: r0 = AllocateClosure()
    //     0xc0666c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc06670: ldur            x1, [fp, #-0x10]
    // 0xc06674: mov             x2, x0
    // 0xc06678: r0 = removeListener()
    //     0xc06678: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xc0667c: ldur            x0, [fp, #-8]
    // 0xc06680: LoadField: r3 = r0->field_bb
    //     0xc06680: ldur            w3, [x0, #0xbb]
    // 0xc06684: DecompressPointer r3
    //     0xc06684: add             x3, x3, HEAP, lsl #32
    // 0xc06688: mov             x2, x0
    // 0xc0668c: stur            x3, [fp, #-0x10]
    // 0xc06690: r1 = Function '_showHideCursor@80245603':.
    //     0xc06690: add             x1, PP, #0xad, lsl #12  ; [pp+0xad658] AnonymousClosure: (0xc06b74), in [package:flutter/src/rendering/editable.dart] RenderEditable::_showHideCursor (0xc06bac)
    //     0xc06694: ldr             x1, [x1, #0x658]
    // 0xc06698: r0 = AllocateClosure()
    //     0xc06698: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0669c: ldur            x1, [fp, #-0x10]
    // 0xc066a0: mov             x2, x0
    // 0xc066a4: r0 = removeListener()
    //     0xc066a4: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xc066a8: ldur            x1, [fp, #-8]
    // 0xc066ac: r0 = detach()
    //     0xc066ac: bl              #0xc06710  ; [dart:mixin_deduplication] _MixinApplication426&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin::detach
    // 0xc066b0: ldur            x0, [fp, #-8]
    // 0xc066b4: LoadField: r1 = r0->field_63
    //     0xc066b4: ldur            w1, [x0, #0x63]
    // 0xc066b8: DecompressPointer r1
    //     0xc066b8: add             x1, x1, HEAP, lsl #32
    // 0xc066bc: cmp             w1, NULL
    // 0xc066c0: b.eq            #0xc066cc
    // 0xc066c4: r0 = detach()
    //     0xc066c4: bl              #0xc09054  ; [package:flutter/src/rendering/editable.dart] _RenderEditableCustomPaint::detach
    // 0xc066c8: ldur            x0, [fp, #-8]
    // 0xc066cc: LoadField: r1 = r0->field_67
    //     0xc066cc: ldur            w1, [x0, #0x67]
    // 0xc066d0: DecompressPointer r1
    //     0xc066d0: add             x1, x1, HEAP, lsl #32
    // 0xc066d4: cmp             w1, NULL
    // 0xc066d8: b.eq            #0xc066e0
    // 0xc066dc: r0 = detach()
    //     0xc066dc: bl              #0xc09054  ; [package:flutter/src/rendering/editable.dart] _RenderEditableCustomPaint::detach
    // 0xc066e0: r0 = Null
    //     0xc066e0: mov             x0, NULL
    // 0xc066e4: LeaveFrame
    //     0xc066e4: mov             SP, fp
    //     0xc066e8: ldp             fp, lr, [SP], #0x10
    // 0xc066ec: ret
    //     0xc066ec: ret             
    // 0xc066f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc066f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc066f4: b               #0xc06614
    // 0xc066f8: r9 = _tap
    //     0xc066f8: add             x9, PP, #0xcd, lsl #12  ; [pp+0xcd680] Field <RenderEditable._tap@80245603>: late (offset: 0x11c)
    //     0xc066fc: ldr             x9, [x9, #0x680]
    // 0xc06700: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc06700: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc06704: r9 = _longPress
    //     0xc06704: add             x9, PP, #0xcd, lsl #12  ; [pp+0xcd688] Field <RenderEditable._longPress@80245603>: late (offset: 0x120)
    //     0xc06708: ldr             x9, [x9, #0x688]
    // 0xc0670c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0670c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _showHideCursor(dynamic) {
    // ** addr: 0xc06b74, size: 0x38
    // 0xc06b74: EnterFrame
    //     0xc06b74: stp             fp, lr, [SP, #-0x10]!
    //     0xc06b78: mov             fp, SP
    // 0xc06b7c: ldr             x0, [fp, #0x10]
    // 0xc06b80: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc06b80: ldur            w1, [x0, #0x17]
    // 0xc06b84: DecompressPointer r1
    //     0xc06b84: add             x1, x1, HEAP, lsl #32
    // 0xc06b88: CheckStackOverflow
    //     0xc06b88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06b8c: cmp             SP, x16
    //     0xc06b90: b.ls            #0xc06ba4
    // 0xc06b94: r0 = _showHideCursor()
    //     0xc06b94: bl              #0xc06bac  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_showHideCursor
    // 0xc06b98: LeaveFrame
    //     0xc06b98: mov             SP, fp
    //     0xc06b9c: ldp             fp, lr, [SP], #0x10
    // 0xc06ba0: ret
    //     0xc06ba0: ret             
    // 0xc06ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06ba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06ba8: b               #0xc06b94
  }
  _ _showHideCursor(/* No info */) {
    // ** addr: 0xc06bac, size: 0x78
    // 0xc06bac: EnterFrame
    //     0xc06bac: stp             fp, lr, [SP, #-0x10]!
    //     0xc06bb0: mov             fp, SP
    // 0xc06bb4: AllocStack(0x8)
    //     0xc06bb4: sub             SP, SP, #8
    // 0xc06bb8: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xc06bb8: mov             x0, x1
    //     0xc06bbc: stur            x1, [fp, #-8]
    // 0xc06bc0: CheckStackOverflow
    //     0xc06bc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc06bc4: cmp             SP, x16
    //     0xc06bc8: b.ls            #0xc06c1c
    // 0xc06bcc: mov             x1, x0
    // 0xc06bd0: LoadField: r0 = r1->field_73
    //     0xc06bd0: ldur            w0, [x1, #0x73]
    // 0xc06bd4: DecompressPointer r0
    //     0xc06bd4: add             x0, x0, HEAP, lsl #32
    // 0xc06bd8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc06bdc: cmp             w0, w16
    // 0xc06be0: b.ne            #0xc06bec
    // 0xc06be4: r2 = _caretPainter
    //     0xc06be4: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0xc06be8: r0 = InitLateFinalInstanceField()
    //     0xc06be8: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xc06bec: mov             x1, x0
    // 0xc06bf0: ldur            x0, [fp, #-8]
    // 0xc06bf4: LoadField: r2 = r0->field_bb
    //     0xc06bf4: ldur            w2, [x0, #0xbb]
    // 0xc06bf8: DecompressPointer r2
    //     0xc06bf8: add             x2, x2, HEAP, lsl #32
    // 0xc06bfc: LoadField: r0 = r2->field_27
    //     0xc06bfc: ldur            w0, [x2, #0x27]
    // 0xc06c00: DecompressPointer r0
    //     0xc06c00: add             x0, x0, HEAP, lsl #32
    // 0xc06c04: mov             x2, x0
    // 0xc06c08: r0 = shouldPaint=()
    //     0xc06c08: bl              #0xc06c24  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::shouldPaint=
    // 0xc06c0c: r0 = Null
    //     0xc06c0c: mov             x0, NULL
    // 0xc06c10: LeaveFrame
    //     0xc06c10: mov             SP, fp
    //     0xc06c14: ldp             fp, lr, [SP], #0x10
    // 0xc06c18: ret
    //     0xc06c18: ret             
    // 0xc06c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06c1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06c20: b               #0xc06bcc
  }
  _ attach(/* No info */) {
    // ** addr: 0xc09edc, size: 0x21c
    // 0xc09edc: EnterFrame
    //     0xc09edc: stp             fp, lr, [SP, #-0x10]!
    //     0xc09ee0: mov             fp, SP
    // 0xc09ee4: AllocStack(0x20)
    //     0xc09ee4: sub             SP, SP, #0x20
    // 0xc09ee8: SetupParameters(RenderEditable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc09ee8: mov             x3, x1
    //     0xc09eec: mov             x0, x2
    //     0xc09ef0: stur            x1, [fp, #-8]
    //     0xc09ef4: stur            x2, [fp, #-0x10]
    // 0xc09ef8: CheckStackOverflow
    //     0xc09ef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc09efc: cmp             SP, x16
    //     0xc09f00: b.ls            #0xc0a0f0
    // 0xc09f04: mov             x1, x3
    // 0xc09f08: mov             x2, x0
    // 0xc09f0c: r0 = attach()
    //     0xc09f0c: bl              #0xc0a2a8  ; [dart:mixin_deduplication] _MixinApplication426&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin::attach
    // 0xc09f10: ldur            x0, [fp, #-8]
    // 0xc09f14: LoadField: r1 = r0->field_63
    //     0xc09f14: ldur            w1, [x0, #0x63]
    // 0xc09f18: DecompressPointer r1
    //     0xc09f18: add             x1, x1, HEAP, lsl #32
    // 0xc09f1c: cmp             w1, NULL
    // 0xc09f20: b.eq            #0xc09f30
    // 0xc09f24: ldur            x2, [fp, #-0x10]
    // 0xc09f28: r0 = attach()
    //     0xc09f28: bl              #0xc0cf10  ; [package:flutter/src/rendering/editable.dart] _RenderEditableCustomPaint::attach
    // 0xc09f2c: ldur            x0, [fp, #-8]
    // 0xc09f30: LoadField: r1 = r0->field_67
    //     0xc09f30: ldur            w1, [x0, #0x67]
    // 0xc09f34: DecompressPointer r1
    //     0xc09f34: add             x1, x1, HEAP, lsl #32
    // 0xc09f38: cmp             w1, NULL
    // 0xc09f3c: b.ne            #0xc09f48
    // 0xc09f40: mov             x2, x0
    // 0xc09f44: b               #0xc09f54
    // 0xc09f48: ldur            x2, [fp, #-0x10]
    // 0xc09f4c: r0 = attach()
    //     0xc09f4c: bl              #0xc0cf10  ; [package:flutter/src/rendering/editable.dart] _RenderEditableCustomPaint::attach
    // 0xc09f50: ldur            x2, [fp, #-8]
    // 0xc09f54: r0 = TapGestureRecognizer()
    //     0xc09f54: bl              #0xc0a29c  ; AllocateTapGestureRecognizerStub -> TapGestureRecognizer (size=0x88)
    // 0xc09f58: stur            x0, [fp, #-0x10]
    // 0xc09f5c: r16 = -1.000000
    //     0xc09f5c: add             x16, PP, #0x13, lsl #12  ; [pp+0x132a8] -1
    //     0xc09f60: ldr             x16, [x16, #0x2a8]
    // 0xc09f64: stp             x16, NULL, [SP]
    // 0xc09f68: mov             x1, x0
    // 0xc09f6c: r4 = const [0, 0x3, 0x2, 0x1, postAcceptSlopTolerance, 0x2, supportedDevices, 0x1, null]
    //     0xc09f6c: add             x4, PP, #0x7a, lsl #12  ; [pp+0x7ab70] List(9) [0, 0x3, 0x2, 0x1, "postAcceptSlopTolerance", 0x2, "supportedDevices", 0x1, Null]
    //     0xc09f70: ldr             x4, [x4, #0xb70]
    // 0xc09f74: r0 = BaseTapGestureRecognizer()
    //     0xc09f74: bl              #0xc0a1bc  ; [package:flutter/src/gestures/tap.dart] BaseTapGestureRecognizer::BaseTapGestureRecognizer
    // 0xc09f78: ldur            x2, [fp, #-8]
    // 0xc09f7c: r1 = Function '_handleTapDown@80245603':.
    //     0xc09f7c: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd690] AnonymousClosure: (0xc0a500), of [package:flutter/src/rendering/editable.dart] RenderEditable
    //     0xc09f80: ldr             x1, [x1, #0x690]
    // 0xc09f84: r0 = AllocateClosure()
    //     0xc09f84: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc09f88: ldur            x3, [fp, #-0x10]
    // 0xc09f8c: StoreField: r3->field_57 = r0
    //     0xc09f8c: stur            w0, [x3, #0x57]
    //     0xc09f90: ldurb           w16, [x3, #-1]
    //     0xc09f94: ldurb           w17, [x0, #-1]
    //     0xc09f98: and             x16, x17, x16, lsr #2
    //     0xc09f9c: tst             x16, HEAP, lsr #32
    //     0xc09fa0: b.eq            #0xc09fa8
    //     0xc09fa4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc09fa8: ldur            x2, [fp, #-8]
    // 0xc09fac: r1 = Function '_handleTap@80245603':.
    //     0xc09fac: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd698] AnonymousClosure: (0xc0a490), of [package:flutter/src/rendering/editable.dart] RenderEditable
    //     0xc09fb0: ldr             x1, [x1, #0x698]
    // 0xc09fb4: r0 = AllocateClosure()
    //     0xc09fb4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc09fb8: ldur            x1, [fp, #-0x10]
    // 0xc09fbc: StoreField: r1->field_5f = r0
    //     0xc09fbc: stur            w0, [x1, #0x5f]
    //     0xc09fc0: ldurb           w16, [x1, #-1]
    //     0xc09fc4: ldurb           w17, [x0, #-1]
    //     0xc09fc8: and             x16, x17, x16, lsr #2
    //     0xc09fcc: tst             x16, HEAP, lsr #32
    //     0xc09fd0: b.eq            #0xc09fd8
    //     0xc09fd4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc09fd8: mov             x0, x1
    // 0xc09fdc: ldur            x2, [fp, #-8]
    // 0xc09fe0: r17 = 283
    //     0xc09fe0: mov             x17, #0x11b
    // 0xc09fe4: str             w0, [x2, x17]
    // 0xc09fe8: WriteBarrierInstr(obj = r2, val = r0)
    //     0xc09fe8: ldurb           w16, [x2, #-1]
    //     0xc09fec: ldurb           w17, [x0, #-1]
    //     0xc09ff0: and             x16, x17, x16, lsr #2
    //     0xc09ff4: tst             x16, HEAP, lsr #32
    //     0xc09ff8: b.eq            #0xc0a000
    //     0xc09ffc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc0a000: r0 = LongPressGestureRecognizer()
    //     0xc0a000: bl              #0xc0a1b0  ; AllocateLongPressGestureRecognizerStub -> LongPressGestureRecognizer (size=0xac)
    // 0xc0a004: mov             x4, x0
    // 0xc0a008: r0 = false
    //     0xc0a008: add             x0, NULL, #0x30  ; false
    // 0xc0a00c: stur            x4, [fp, #-0x10]
    // 0xc0a010: StoreField: r4->field_47 = r0
    //     0xc0a010: stur            w0, [x4, #0x47]
    // 0xc0a014: mov             x1, x4
    // 0xc0a018: r2 = Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@656232524': static.
    //     0xc0a018: add             x2, PP, #0x84, lsl #12  ; [pp+0x84e28] Closure: (int) => bool from Function '_defaultButtonAcceptBehavior@656232524': static. (0x7f2adaaf1540)
    //     0xc0a01c: ldr             x2, [x2, #0xe28]
    // 0xc0a020: r3 = Instance_Duration
    //     0xc0a020: ldr             x3, [PP, #0x5248]  ; [pp+0x5248] Obj!Duration@12c8931
    // 0xc0a024: r5 = Null
    //     0xc0a024: mov             x5, NULL
    // 0xc0a028: r6 = Null
    //     0xc0a028: mov             x6, NULL
    // 0xc0a02c: r0 = PrimaryPointerGestureRecognizer()
    //     0xc0a02c: bl              #0xc0a0f8  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::PrimaryPointerGestureRecognizer
    // 0xc0a030: ldur            x2, [fp, #-8]
    // 0xc0a034: r1 = Function '_handleLongPress@80245603':.
    //     0xc0a034: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd6a0] AnonymousClosure: (0xc0a420), of [package:flutter/src/rendering/editable.dart] RenderEditable
    //     0xc0a038: ldr             x1, [x1, #0x6a0]
    // 0xc0a03c: r0 = AllocateClosure()
    //     0xc0a03c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0a040: ldur            x1, [fp, #-0x10]
    // 0xc0a044: StoreField: r1->field_5b = r0
    //     0xc0a044: stur            w0, [x1, #0x5b]
    //     0xc0a048: ldurb           w16, [x1, #-1]
    //     0xc0a04c: ldurb           w17, [x0, #-1]
    //     0xc0a050: and             x16, x17, x16, lsr #2
    //     0xc0a054: tst             x16, HEAP, lsr #32
    //     0xc0a058: b.eq            #0xc0a060
    //     0xc0a05c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0a060: mov             x0, x1
    // 0xc0a064: ldur            x3, [fp, #-8]
    // 0xc0a068: r17 = 287
    //     0xc0a068: mov             x17, #0x11f
    // 0xc0a06c: str             w0, [x3, x17]
    // 0xc0a070: WriteBarrierInstr(obj = r3, val = r0)
    //     0xc0a070: ldurb           w16, [x3, #-1]
    //     0xc0a074: ldurb           w17, [x0, #-1]
    //     0xc0a078: and             x16, x17, x16, lsr #2
    //     0xc0a07c: tst             x16, HEAP, lsr #32
    //     0xc0a080: b.eq            #0xc0a088
    //     0xc0a084: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc0a088: LoadField: r0 = r3->field_db
    //     0xc0a088: ldur            w0, [x3, #0xdb]
    // 0xc0a08c: DecompressPointer r0
    //     0xc0a08c: add             x0, x0, HEAP, lsl #32
    // 0xc0a090: mov             x2, x3
    // 0xc0a094: stur            x0, [fp, #-0x10]
    // 0xc0a098: r1 = Function 'markNeedsPaint':.
    //     0xc0a098: add             x1, PP, #0xad, lsl #12  ; [pp+0xad650] AnonymousClosure: (0xbf0650), in [package:flutter/src/rendering/editable.dart] RenderEditable::markNeedsPaint (0xbf05e0)
    //     0xc0a09c: ldr             x1, [x1, #0x650]
    // 0xc0a0a0: r0 = AllocateClosure()
    //     0xc0a0a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0a0a4: ldur            x1, [fp, #-0x10]
    // 0xc0a0a8: mov             x2, x0
    // 0xc0a0ac: r0 = addListener()
    //     0xc0a0ac: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xc0a0b0: ldur            x1, [fp, #-8]
    // 0xc0a0b4: r0 = _showHideCursor()
    //     0xc0a0b4: bl              #0xc06bac  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_showHideCursor
    // 0xc0a0b8: ldur            x2, [fp, #-8]
    // 0xc0a0bc: LoadField: r0 = r2->field_bb
    //     0xc0a0bc: ldur            w0, [x2, #0xbb]
    // 0xc0a0c0: DecompressPointer r0
    //     0xc0a0c0: add             x0, x0, HEAP, lsl #32
    // 0xc0a0c4: stur            x0, [fp, #-0x10]
    // 0xc0a0c8: r1 = Function '_showHideCursor@80245603':.
    //     0xc0a0c8: add             x1, PP, #0xad, lsl #12  ; [pp+0xad658] AnonymousClosure: (0xc06b74), in [package:flutter/src/rendering/editable.dart] RenderEditable::_showHideCursor (0xc06bac)
    //     0xc0a0cc: ldr             x1, [x1, #0x658]
    // 0xc0a0d0: r0 = AllocateClosure()
    //     0xc0a0d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0a0d4: ldur            x1, [fp, #-0x10]
    // 0xc0a0d8: mov             x2, x0
    // 0xc0a0dc: r0 = addListener()
    //     0xc0a0dc: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xc0a0e0: r0 = Null
    //     0xc0a0e0: mov             x0, NULL
    // 0xc0a0e4: LeaveFrame
    //     0xc0a0e4: mov             SP, fp
    //     0xc0a0e8: ldp             fp, lr, [SP], #0x10
    // 0xc0a0ec: ret
    //     0xc0a0ec: ret             
    // 0xc0a0f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a0f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a0f4: b               #0xc09f04
  }
  [closure] void _handleLongPress(dynamic) {
    // ** addr: 0xc0a420, size: 0x3c
    // 0xc0a420: EnterFrame
    //     0xc0a420: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a424: mov             fp, SP
    // 0xc0a428: ldr             x0, [fp, #0x10]
    // 0xc0a42c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc0a42c: ldur            w1, [x0, #0x17]
    // 0xc0a430: DecompressPointer r1
    //     0xc0a430: add             x1, x1, HEAP, lsl #32
    // 0xc0a434: CheckStackOverflow
    //     0xc0a434: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a438: cmp             SP, x16
    //     0xc0a43c: b.ls            #0xc0a454
    // 0xc0a440: r0 = handleLongPress()
    //     0xc0a440: bl              #0xc0a45c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::handleLongPress
    // 0xc0a444: r0 = Null
    //     0xc0a444: mov             x0, NULL
    // 0xc0a448: LeaveFrame
    //     0xc0a448: mov             SP, fp
    //     0xc0a44c: ldp             fp, lr, [SP], #0x10
    // 0xc0a450: ret
    //     0xc0a450: ret             
    // 0xc0a454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a454: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a458: b               #0xc0a440
  }
  _ handleLongPress(/* No info */) {
    // ** addr: 0xc0a45c, size: 0x34
    // 0xc0a45c: EnterFrame
    //     0xc0a45c: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a460: mov             fp, SP
    // 0xc0a464: CheckStackOverflow
    //     0xc0a464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a468: cmp             SP, x16
    //     0xc0a46c: b.ls            #0xc0a488
    // 0xc0a470: r2 = Instance_SelectionChangedCause
    //     0xc0a470: ldr             x2, [PP, #0x5300]  ; [pp+0x5300] Obj!SelectionChangedCause@12c36e1
    // 0xc0a474: r0 = selectWord()
    //     0xc0a474: bl              #0xba7480  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectWord
    // 0xc0a478: r0 = Null
    //     0xc0a478: mov             x0, NULL
    // 0xc0a47c: LeaveFrame
    //     0xc0a47c: mov             SP, fp
    //     0xc0a480: ldp             fp, lr, [SP], #0x10
    // 0xc0a484: ret
    //     0xc0a484: ret             
    // 0xc0a488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a488: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a48c: b               #0xc0a470
  }
  [closure] void _handleTap(dynamic) {
    // ** addr: 0xc0a490, size: 0x3c
    // 0xc0a490: EnterFrame
    //     0xc0a490: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a494: mov             fp, SP
    // 0xc0a498: ldr             x0, [fp, #0x10]
    // 0xc0a49c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc0a49c: ldur            w1, [x0, #0x17]
    // 0xc0a4a0: DecompressPointer r1
    //     0xc0a4a0: add             x1, x1, HEAP, lsl #32
    // 0xc0a4a4: CheckStackOverflow
    //     0xc0a4a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a4a8: cmp             SP, x16
    //     0xc0a4ac: b.ls            #0xc0a4c4
    // 0xc0a4b0: r0 = handleTap()
    //     0xc0a4b0: bl              #0xc0a4cc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::handleTap
    // 0xc0a4b4: r0 = Null
    //     0xc0a4b4: mov             x0, NULL
    // 0xc0a4b8: LeaveFrame
    //     0xc0a4b8: mov             SP, fp
    //     0xc0a4bc: ldp             fp, lr, [SP], #0x10
    // 0xc0a4c0: ret
    //     0xc0a4c0: ret             
    // 0xc0a4c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a4c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a4c8: b               #0xc0a4b0
  }
  _ handleTap(/* No info */) {
    // ** addr: 0xc0a4cc, size: 0x34
    // 0xc0a4cc: EnterFrame
    //     0xc0a4cc: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a4d0: mov             fp, SP
    // 0xc0a4d4: CheckStackOverflow
    //     0xc0a4d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a4d8: cmp             SP, x16
    //     0xc0a4dc: b.ls            #0xc0a4f8
    // 0xc0a4e0: r2 = Instance_SelectionChangedCause
    //     0xc0a4e0: ldr             x2, [PP, #0x5310]  ; [pp+0x5310] Obj!SelectionChangedCause@12c36a1
    // 0xc0a4e4: r0 = selectPosition()
    //     0xc0a4e4: bl              #0xba791c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectPosition
    // 0xc0a4e8: r0 = Null
    //     0xc0a4e8: mov             x0, NULL
    // 0xc0a4ec: LeaveFrame
    //     0xc0a4ec: mov             SP, fp
    //     0xc0a4f0: ldp             fp, lr, [SP], #0x10
    // 0xc0a4f4: ret
    //     0xc0a4f4: ret             
    // 0xc0a4f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a4f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a4fc: b               #0xc0a4e0
  }
  [closure] void _handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0xc0a500, size: 0x40
    // 0xc0a500: EnterFrame
    //     0xc0a500: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a504: mov             fp, SP
    // 0xc0a508: ldr             x0, [fp, #0x18]
    // 0xc0a50c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc0a50c: ldur            w1, [x0, #0x17]
    // 0xc0a510: DecompressPointer r1
    //     0xc0a510: add             x1, x1, HEAP, lsl #32
    // 0xc0a514: CheckStackOverflow
    //     0xc0a514: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a518: cmp             SP, x16
    //     0xc0a51c: b.ls            #0xc0a538
    // 0xc0a520: ldr             x2, [fp, #0x10]
    // 0xc0a524: r0 = handleTapDown()
    //     0xc0a524: bl              #0xba77e0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::handleTapDown
    // 0xc0a528: r0 = Null
    //     0xc0a528: mov             x0, NULL
    // 0xc0a52c: LeaveFrame
    //     0xc0a52c: mov             SP, fp
    //     0xc0a530: ldp             fp, lr, [SP], #0x10
    // 0xc0a534: ret
    //     0xc0a534: ret             
    // 0xc0a538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a53c: b               #0xc0a520
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0xc0f480, size: 0x78
    // 0xc0f480: EnterFrame
    //     0xc0f480: stp             fp, lr, [SP, #-0x10]!
    //     0xc0f484: mov             fp, SP
    // 0xc0f488: AllocStack(0x10)
    //     0xc0f488: sub             SP, SP, #0x10
    // 0xc0f48c: SetupParameters(RenderEditable this /* r1 => r0, fp-0x10 */)
    //     0xc0f48c: mov             x0, x1
    //     0xc0f490: stur            x1, [fp, #-0x10]
    // 0xc0f494: CheckStackOverflow
    //     0xc0f494: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0f498: cmp             SP, x16
    //     0xc0f49c: b.ls            #0xc0f4f0
    // 0xc0f4a0: LoadField: r2 = r0->field_63
    //     0xc0f4a0: ldur            w2, [x0, #0x63]
    // 0xc0f4a4: DecompressPointer r2
    //     0xc0f4a4: add             x2, x2, HEAP, lsl #32
    // 0xc0f4a8: LoadField: r3 = r0->field_67
    //     0xc0f4a8: ldur            w3, [x0, #0x67]
    // 0xc0f4ac: DecompressPointer r3
    //     0xc0f4ac: add             x3, x3, HEAP, lsl #32
    // 0xc0f4b0: stur            x3, [fp, #-8]
    // 0xc0f4b4: cmp             w2, NULL
    // 0xc0f4b8: b.eq            #0xc0f4c4
    // 0xc0f4bc: mov             x1, x0
    // 0xc0f4c0: r0 = redepthChild()
    //     0xc0f4c0: bl              #0xc05584  ; [package:flutter/src/rendering/object.dart] RenderObject::redepthChild
    // 0xc0f4c4: ldur            x2, [fp, #-8]
    // 0xc0f4c8: cmp             w2, NULL
    // 0xc0f4cc: b.eq            #0xc0f4d8
    // 0xc0f4d0: ldur            x1, [fp, #-0x10]
    // 0xc0f4d4: r0 = redepthChild()
    //     0xc0f4d4: bl              #0xc05584  ; [package:flutter/src/rendering/object.dart] RenderObject::redepthChild
    // 0xc0f4d8: ldur            x1, [fp, #-0x10]
    // 0xc0f4dc: r0 = redepthChildren()
    //     0xc0f4dc: bl              #0xc0f4f8  ; [dart:mixin_deduplication] _MixinApplication426&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin::redepthChildren
    // 0xc0f4e0: r0 = Null
    //     0xc0f4e0: mov             x0, NULL
    // 0xc0f4e4: LeaveFrame
    //     0xc0f4e4: mov             SP, fp
    //     0xc0f4e8: ldp             fp, lr, [SP], #0x10
    // 0xc0f4ec: ret
    //     0xc0f4ec: ret             
    // 0xc0f4f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0f4f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0f4f4: b               #0xc0f4a0
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0xc112d0, size: 0xed8
    // 0xc112d0: EnterFrame
    //     0xc112d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc112d4: mov             fp, SP
    // 0xc112d8: AllocStack(0x110)
    //     0xc112d8: sub             SP, SP, #0x110
    // 0xc112dc: SetupParameters(RenderEditable this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0xc112dc: mov             x4, x1
    //     0xc112e0: mov             x0, x3
    //     0xc112e4: stur            x3, [fp, #-0x18]
    //     0xc112e8: mov             x3, x2
    //     0xc112ec: stur            x1, [fp, #-8]
    //     0xc112f0: stur            x2, [fp, #-0x10]
    //     0xc112f4: stur            x5, [fp, #-0x20]
    // 0xc112f8: CheckStackOverflow
    //     0xc112f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc112fc: cmp             SP, x16
    //     0xc11300: b.ls            #0xc12160
    // 0xc11304: r1 = <SemanticsNode>
    //     0xc11304: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0xc11308: r2 = 0
    //     0xc11308: mov             x2, #0
    // 0xc1130c: r0 = _GrowableList()
    //     0xc1130c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xc11310: mov             x1, x0
    // 0xc11314: ldur            x0, [fp, #-8]
    // 0xc11318: stur            x1, [fp, #-0x40]
    // 0xc1131c: LoadField: r2 = r0->field_a7
    //     0xc1131c: ldur            w2, [x0, #0xa7]
    // 0xc11320: DecompressPointer r2
    //     0xc11320: add             x2, x2, HEAP, lsl #32
    // 0xc11324: stur            x2, [fp, #-0x38]
    // 0xc11328: LoadField: r3 = r2->field_1b
    //     0xc11328: ldur            w3, [x2, #0x1b]
    // 0xc1132c: DecompressPointer r3
    //     0xc1132c: add             x3, x3, HEAP, lsl #32
    // 0xc11330: stur            x3, [fp, #-0x30]
    // 0xc11334: cmp             w3, NULL
    // 0xc11338: b.eq            #0xc12168
    // 0xc1133c: LoadField: r4 = r0->field_5b
    //     0xc1133c: ldur            w4, [x0, #0x5b]
    // 0xc11340: DecompressPointer r4
    //     0xc11340: add             x4, x4, HEAP, lsl #32
    // 0xc11344: stur            x4, [fp, #-0x28]
    // 0xc11348: r16 = <Key, SemanticsNode>
    //     0xc11348: add             x16, PP, #0x98, lsl #12  ; [pp+0x98850] TypeArguments: <Key, SemanticsNode>
    //     0xc1134c: ldr             x16, [x16, #0x850]
    // 0xc11350: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xc11354: stp             lr, x16, [SP]
    // 0xc11358: r0 = Map._fromLiteral()
    //     0xc11358: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xc1135c: mov             x2, x0
    // 0xc11360: ldur            x0, [fp, #-8]
    // 0xc11364: stur            x2, [fp, #-0x48]
    // 0xc11368: LoadField: r1 = r0->field_af
    //     0xc11368: ldur            w1, [x0, #0xaf]
    // 0xc1136c: DecompressPointer r1
    //     0xc1136c: add             x1, x1, HEAP, lsl #32
    // 0xc11370: cmp             w1, NULL
    // 0xc11374: b.ne            #0xc113bc
    // 0xc11378: r17 = 271
    //     0xc11378: mov             x17, #0x10f
    // 0xc1137c: ldr             w1, [x0, x17]
    // 0xc11380: DecompressPointer r1
    //     0xc11380: add             x1, x1, HEAP, lsl #32
    // 0xc11384: cmp             w1, NULL
    // 0xc11388: b.eq            #0xc1216c
    // 0xc1138c: r0 = combineSemanticsInfo()
    //     0xc1138c: bl              #0xbfa964  ; [package:flutter/src/painting/inline_span.dart] ::combineSemanticsInfo
    // 0xc11390: mov             x1, x0
    // 0xc11394: ldur            x2, [fp, #-8]
    // 0xc11398: StoreField: r2->field_af = r0
    //     0xc11398: stur            w0, [x2, #0xaf]
    //     0xc1139c: ldurb           w16, [x2, #-1]
    //     0xc113a0: ldurb           w17, [x0, #-1]
    //     0xc113a4: and             x16, x17, x16, lsr #2
    //     0xc113a8: tst             x16, HEAP, lsr #32
    //     0xc113ac: b.eq            #0xc113b4
    //     0xc113b0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc113b4: mov             x0, x1
    // 0xc113b8: b               #0xc113c4
    // 0xc113bc: mov             x2, x0
    // 0xc113c0: mov             x0, x1
    // 0xc113c4: stur            x0, [fp, #-0x90]
    // 0xc113c8: LoadField: r1 = r0->field_b
    //     0xc113c8: ldur            w1, [x0, #0xb]
    // 0xc113cc: r3 = LoadInt32Instr(r1)
    //     0xc113cc: sbfx            x3, x1, #1, #0x1f
    // 0xc113d0: stur            x3, [fp, #-0x88]
    // 0xc113d4: ldur            x12, [fp, #-0x30]
    // 0xc113d8: ldur            x8, [fp, #-0x28]
    // 0xc113dc: ldur            x4, [fp, #-0x40]
    // 0xc113e0: d0 = 0.000000
    //     0xc113e0: eor             v0.16b, v0.16b, v0.16b
    // 0xc113e4: r11 = 0
    //     0xc113e4: mov             x11, #0
    // 0xc113e8: r10 = 0
    //     0xc113e8: mov             x10, #0
    // 0xc113ec: r9 = 0
    //     0xc113ec: mov             x9, #0
    // 0xc113f0: r7 = 0
    //     0xc113f0: mov             x7, #0
    // 0xc113f4: ldur            x6, [fp, #-0x10]
    // 0xc113f8: ldur            x5, [fp, #-0x20]
    // 0xc113fc: ldur            x1, [fp, #-0x48]
    // 0xc11400: stur            x12, [fp, #-0x60]
    // 0xc11404: stur            x11, [fp, #-0x68]
    // 0xc11408: stur            x10, [fp, #-0x70]
    // 0xc1140c: stur            x9, [fp, #-0x78]
    // 0xc11410: stur            x8, [fp, #-0x80]
    // 0xc11414: stur            d0, [fp, #-0xc8]
    // 0xc11418: CheckStackOverflow
    //     0xc11418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1141c: cmp             SP, x16
    //     0xc11420: b.ls            #0xc12170
    // 0xc11424: LoadField: r13 = r0->field_b
    //     0xc11424: ldur            w13, [x0, #0xb]
    // 0xc11428: r14 = LoadInt32Instr(r13)
    //     0xc11428: sbfx            x14, x13, #1, #0x1f
    // 0xc1142c: cmp             x3, x14
    // 0xc11430: b.ne            #0xc12144
    // 0xc11434: cmp             x7, x14
    // 0xc11438: b.ge            #0xc120ac
    // 0xc1143c: LoadField: r13 = r0->field_f
    //     0xc1143c: ldur            w13, [x0, #0xf]
    // 0xc11440: DecompressPointer r13
    //     0xc11440: add             x13, x13, HEAP, lsl #32
    // 0xc11444: ArrayLoad: r14 = r13[r7]  ; Unknown_4
    //     0xc11444: add             x16, x13, x7, lsl #2
    //     0xc11448: ldur            w14, [x16, #0xf]
    // 0xc1144c: DecompressPointer r14
    //     0xc1144c: add             x14, x14, HEAP, lsl #32
    // 0xc11450: stur            x14, [fp, #-0x30]
    // 0xc11454: add             x13, x7, #1
    // 0xc11458: stur            x13, [fp, #-0x58]
    // 0xc1145c: LoadField: r7 = r14->field_7
    //     0xc1145c: ldur            w7, [x14, #7]
    // 0xc11460: DecompressPointer r7
    //     0xc11460: add             x7, x7, HEAP, lsl #32
    // 0xc11464: stur            x7, [fp, #-0x28]
    // 0xc11468: LoadField: r19 = r7->field_7
    //     0xc11468: ldur            w19, [x7, #7]
    // 0xc1146c: r20 = LoadInt32Instr(r19)
    //     0xc1146c: sbfx            x20, x19, #1, #0x1f
    // 0xc11470: add             x19, x11, x20
    // 0xc11474: stur            x19, [fp, #-0x50]
    // 0xc11478: r0 = TextSelection()
    //     0xc11478: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xc1147c: mov             x1, x0
    // 0xc11480: ldur            x0, [fp, #-0x68]
    // 0xc11484: ArrayStore: r1[0] = r0  ; List_8
    //     0xc11484: stur            x0, [x1, #0x17]
    // 0xc11488: ldur            x2, [fp, #-0x50]
    // 0xc1148c: StoreField: r1->field_1f = r2
    //     0xc1148c: stur            x2, [x1, #0x1f]
    // 0xc11490: r3 = Instance_TextAffinity
    //     0xc11490: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xc11494: StoreField: r1->field_27 = r3
    //     0xc11494: stur            w3, [x1, #0x27]
    // 0xc11498: r4 = false
    //     0xc11498: add             x4, NULL, #0x30  ; false
    // 0xc1149c: StoreField: r1->field_2b = r4
    //     0xc1149c: stur            w4, [x1, #0x2b]
    // 0xc114a0: cmp             x0, x2
    // 0xc114a4: b.ge            #0xc114b0
    // 0xc114a8: mov             x5, x0
    // 0xc114ac: b               #0xc114b4
    // 0xc114b0: mov             x5, x2
    // 0xc114b4: cmp             x0, x2
    // 0xc114b8: b.ge            #0xc114c4
    // 0xc114bc: mov             x6, x2
    // 0xc114c0: b               #0xc114c8
    // 0xc114c4: mov             x6, x0
    // 0xc114c8: ldur            x0, [fp, #-0x30]
    // 0xc114cc: StoreField: r1->field_7 = r5
    //     0xc114cc: stur            x5, [x1, #7]
    // 0xc114d0: StoreField: r1->field_f = r6
    //     0xc114d0: stur            x6, [x1, #0xf]
    // 0xc114d4: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xc114d4: ldur            w5, [x0, #0x17]
    // 0xc114d8: DecompressPointer r5
    //     0xc114d8: add             x5, x5, HEAP, lsl #32
    // 0xc114dc: tbnz            w5, #4, #0xc11790
    // 0xc114e0: ldur            x5, [fp, #-0x70]
    // 0xc114e4: r0 = BoxInt64Instr(r5)
    //     0xc114e4: sbfiz           x0, x5, #1, #0x1f
    //     0xc114e8: cmp             x5, x0, asr #1
    //     0xc114ec: b.eq            #0xc114f8
    //     0xc114f0: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc114f4: stur            x5, [x0, #7]
    // 0xc114f8: stur            x0, [fp, #-0xa0]
    // 0xc114fc: ldur            x8, [fp, #-0x78]
    // 0xc11500: ldur            x1, [fp, #-0x40]
    // 0xc11504: ldur            x6, [fp, #-0x20]
    // 0xc11508: ldur            x7, [fp, #-0x80]
    // 0xc1150c: stur            x8, [fp, #-0x68]
    // 0xc11510: CheckStackOverflow
    //     0xc11510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc11514: cmp             SP, x16
    //     0xc11518: b.ls            #0xc12178
    // 0xc1151c: LoadField: r9 = r6->field_b
    //     0xc1151c: ldur            w9, [x6, #0xb]
    // 0xc11520: r10 = LoadInt32Instr(r9)
    //     0xc11520: sbfx            x10, x9, #1, #0x1f
    // 0xc11524: cmp             x10, x8
    // 0xc11528: b.le            #0xc11700
    // 0xc1152c: LoadField: r9 = r6->field_f
    //     0xc1152c: ldur            w9, [x6, #0xf]
    // 0xc11530: DecompressPointer r9
    //     0xc11530: add             x9, x9, HEAP, lsl #32
    // 0xc11534: ArrayLoad: r10 = r9[r8]  ; Unknown_4
    //     0xc11534: add             x16, x9, x8, lsl #2
    //     0xc11538: ldur            w10, [x16, #0xf]
    // 0xc1153c: DecompressPointer r10
    //     0xc1153c: add             x10, x10, HEAP, lsl #32
    // 0xc11540: stur            x10, [fp, #-0x98]
    // 0xc11544: r0 = PlaceholderSpanIndexSemanticsTag()
    //     0xc11544: bl              #0xbfa6fc  ; AllocatePlaceholderSpanIndexSemanticsTagStub -> PlaceholderSpanIndexSemanticsTag (size=0x14)
    // 0xc11548: mov             x3, x0
    // 0xc1154c: ldur            x0, [fp, #-0x70]
    // 0xc11550: stur            x3, [fp, #-0xa8]
    // 0xc11554: StoreField: r3->field_b = r0
    //     0xc11554: stur            x0, [x3, #0xb]
    // 0xc11558: r1 = Null
    //     0xc11558: mov             x1, NULL
    // 0xc1155c: r2 = 6
    //     0xc1155c: mov             x2, #6
    // 0xc11560: r0 = AllocateArray()
    //     0xc11560: bl              #0x13df928  ; AllocateArrayStub
    // 0xc11564: r16 = "PlaceholderSpanIndexSemanticsTag("
    //     0xc11564: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7cf00] "PlaceholderSpanIndexSemanticsTag("
    //     0xc11568: ldr             x16, [x16, #0xf00]
    // 0xc1156c: StoreField: r0->field_f = r16
    //     0xc1156c: stur            w16, [x0, #0xf]
    // 0xc11570: ldur            x1, [fp, #-0xa0]
    // 0xc11574: StoreField: r0->field_13 = r1
    //     0xc11574: stur            w1, [x0, #0x13]
    // 0xc11578: r16 = ")"
    //     0xc11578: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0xc1157c: ArrayStore: r0[0] = r16  ; List_4
    //     0xc1157c: stur            w16, [x0, #0x17]
    // 0xc11580: str             x0, [SP]
    // 0xc11584: r0 = _interpolate()
    //     0xc11584: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xc11588: ldur            x2, [fp, #-0xa8]
    // 0xc1158c: StoreField: r2->field_7 = r0
    //     0xc1158c: stur            w0, [x2, #7]
    //     0xc11590: ldurb           w16, [x2, #-1]
    //     0xc11594: ldurb           w17, [x0, #-1]
    //     0xc11598: and             x16, x17, x16, lsr #2
    //     0xc1159c: tst             x16, HEAP, lsr #32
    //     0xc115a0: b.eq            #0xc115a8
    //     0xc115a4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc115a8: ldur            x0, [fp, #-0x98]
    // 0xc115ac: LoadField: r1 = r0->field_6b
    //     0xc115ac: ldur            w1, [x0, #0x6b]
    // 0xc115b0: DecompressPointer r1
    //     0xc115b0: add             x1, x1, HEAP, lsl #32
    // 0xc115b4: cmp             w1, NULL
    // 0xc115b8: b.eq            #0xc116f4
    // 0xc115bc: r0 = contains()
    //     0xc115bc: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xc115c0: tbnz            w0, #4, #0xc116e8
    // 0xc115c4: ldur            x4, [fp, #-0x20]
    // 0xc115c8: ldur            x3, [fp, #-0x40]
    // 0xc115cc: ldur            x5, [fp, #-0x80]
    // 0xc115d0: ldur            x6, [fp, #-0x68]
    // 0xc115d4: LoadField: r0 = r4->field_b
    //     0xc115d4: ldur            w0, [x4, #0xb]
    // 0xc115d8: r1 = LoadInt32Instr(r0)
    //     0xc115d8: sbfx            x1, x0, #1, #0x1f
    // 0xc115dc: mov             x0, x1
    // 0xc115e0: mov             x1, x6
    // 0xc115e4: cmp             x1, x0
    // 0xc115e8: b.hs            #0xc12180
    // 0xc115ec: LoadField: r0 = r4->field_f
    //     0xc115ec: ldur            w0, [x4, #0xf]
    // 0xc115f0: DecompressPointer r0
    //     0xc115f0: add             x0, x0, HEAP, lsl #32
    // 0xc115f4: ArrayLoad: r7 = r0[r6]  ; Unknown_4
    //     0xc115f4: add             x16, x0, x6, lsl #2
    //     0xc115f8: ldur            w7, [x16, #0xf]
    // 0xc115fc: DecompressPointer r7
    //     0xc115fc: add             x7, x7, HEAP, lsl #32
    // 0xc11600: stur            x7, [fp, #-0x98]
    // 0xc11604: cmp             w5, NULL
    // 0xc11608: b.eq            #0xc12184
    // 0xc1160c: LoadField: r0 = r5->field_7
    //     0xc1160c: ldur            w0, [x5, #7]
    // 0xc11610: DecompressPointer r0
    //     0xc11610: add             x0, x0, HEAP, lsl #32
    // 0xc11614: cmp             w0, NULL
    // 0xc11618: b.eq            #0xc12188
    // 0xc1161c: r2 = Null
    //     0xc1161c: mov             x2, NULL
    // 0xc11620: r1 = Null
    //     0xc11620: mov             x1, NULL
    // 0xc11624: r4 = LoadClassIdInstr(r0)
    //     0xc11624: ldur            x4, [x0, #-1]
    //     0xc11628: ubfx            x4, x4, #0xc, #0x14
    // 0xc1162c: r17 = 4188
    //     0xc1162c: mov             x17, #0x105c
    // 0xc11630: cmp             x4, x17
    // 0xc11634: b.eq            #0xc1164c
    // 0xc11638: r8 = TextParentData
    //     0xc11638: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cee0] Type: TextParentData
    //     0xc1163c: ldr             x8, [x8, #0xee0]
    // 0xc11640: r3 = Null
    //     0xc11640: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd6a8] Null
    //     0xc11644: ldr             x3, [x3, #0x6a8]
    // 0xc11648: r0 = DefaultTypeTest()
    //     0xc11648: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc1164c: ldur            x0, [fp, #-0x40]
    // 0xc11650: LoadField: r1 = r0->field_b
    //     0xc11650: ldur            w1, [x0, #0xb]
    // 0xc11654: LoadField: r2 = r0->field_f
    //     0xc11654: ldur            w2, [x0, #0xf]
    // 0xc11658: DecompressPointer r2
    //     0xc11658: add             x2, x2, HEAP, lsl #32
    // 0xc1165c: LoadField: r3 = r2->field_b
    //     0xc1165c: ldur            w3, [x2, #0xb]
    // 0xc11660: r2 = LoadInt32Instr(r1)
    //     0xc11660: sbfx            x2, x1, #1, #0x1f
    // 0xc11664: stur            x2, [fp, #-0xb0]
    // 0xc11668: r1 = LoadInt32Instr(r3)
    //     0xc11668: sbfx            x1, x3, #1, #0x1f
    // 0xc1166c: cmp             x2, x1
    // 0xc11670: b.ne            #0xc1167c
    // 0xc11674: mov             x1, x0
    // 0xc11678: r0 = _growToNextCapacity()
    //     0xc11678: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc1167c: ldur            x3, [fp, #-0x40]
    // 0xc11680: ldur            x4, [fp, #-0x68]
    // 0xc11684: ldur            x2, [fp, #-0xb0]
    // 0xc11688: add             x0, x2, #1
    // 0xc1168c: lsl             x1, x0, #1
    // 0xc11690: StoreField: r3->field_b = r1
    //     0xc11690: stur            w1, [x3, #0xb]
    // 0xc11694: LoadField: r1 = r3->field_f
    //     0xc11694: ldur            w1, [x3, #0xf]
    // 0xc11698: DecompressPointer r1
    //     0xc11698: add             x1, x1, HEAP, lsl #32
    // 0xc1169c: ldur            x0, [fp, #-0x98]
    // 0xc116a0: ArrayStore: r1[r2] = r0  ; List_4
    //     0xc116a0: add             x25, x1, x2, lsl #2
    //     0xc116a4: add             x25, x25, #0xf
    //     0xc116a8: str             w0, [x25]
    //     0xc116ac: tbz             w0, #0, #0xc116c8
    //     0xc116b0: ldurb           w16, [x1, #-1]
    //     0xc116b4: ldurb           w17, [x0, #-1]
    //     0xc116b8: and             x16, x17, x16, lsr #2
    //     0xc116bc: tst             x16, HEAP, lsr #32
    //     0xc116c0: b.eq            #0xc116c8
    //     0xc116c4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc116c8: add             x8, x4, #1
    // 0xc116cc: mov             x1, x3
    // 0xc116d0: ldur            x5, [fp, #-0x70]
    // 0xc116d4: ldur            x2, [fp, #-0x50]
    // 0xc116d8: ldur            x0, [fp, #-0xa0]
    // 0xc116dc: r4 = false
    //     0xc116dc: add             x4, NULL, #0x30  ; false
    // 0xc116e0: r3 = Instance_TextAffinity
    //     0xc116e0: ldr             x3, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xc116e4: b               #0xc11504
    // 0xc116e8: ldur            x3, [fp, #-0x40]
    // 0xc116ec: ldur            x4, [fp, #-0x68]
    // 0xc116f0: b               #0xc11708
    // 0xc116f4: ldur            x3, [fp, #-0x40]
    // 0xc116f8: ldur            x4, [fp, #-0x68]
    // 0xc116fc: b               #0xc11708
    // 0xc11700: mov             x3, x1
    // 0xc11704: mov             x4, x8
    // 0xc11708: ldur            x6, [fp, #-0x70]
    // 0xc1170c: ldur            x5, [fp, #-0x80]
    // 0xc11710: cmp             w5, NULL
    // 0xc11714: b.eq            #0xc1218c
    // 0xc11718: LoadField: r7 = r5->field_7
    //     0xc11718: ldur            w7, [x5, #7]
    // 0xc1171c: DecompressPointer r7
    //     0xc1171c: add             x7, x7, HEAP, lsl #32
    // 0xc11720: stur            x7, [fp, #-0x98]
    // 0xc11724: cmp             w7, NULL
    // 0xc11728: b.eq            #0xc12190
    // 0xc1172c: mov             x0, x7
    // 0xc11730: r2 = Null
    //     0xc11730: mov             x2, NULL
    // 0xc11734: r1 = Null
    //     0xc11734: mov             x1, NULL
    // 0xc11738: r4 = LoadClassIdInstr(r0)
    //     0xc11738: ldur            x4, [x0, #-1]
    //     0xc1173c: ubfx            x4, x4, #0xc, #0x14
    // 0xc11740: r17 = 4188
    //     0xc11740: mov             x17, #0x105c
    // 0xc11744: cmp             x4, x17
    // 0xc11748: b.eq            #0xc11760
    // 0xc1174c: r8 = TextParentData
    //     0xc1174c: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cee0] Type: TextParentData
    //     0xc11750: ldr             x8, [x8, #0xee0]
    // 0xc11754: r3 = Null
    //     0xc11754: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd6b8] Null
    //     0xc11758: ldr             x3, [x3, #0x6b8]
    // 0xc1175c: r0 = DefaultTypeTest()
    //     0xc1175c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc11760: ldur            x0, [fp, #-0x98]
    // 0xc11764: LoadField: r1 = r0->field_b
    //     0xc11764: ldur            w1, [x0, #0xb]
    // 0xc11768: DecompressPointer r1
    //     0xc11768: add             x1, x1, HEAP, lsl #32
    // 0xc1176c: ldur            x3, [fp, #-0x70]
    // 0xc11770: add             x0, x3, #1
    // 0xc11774: ldur            x4, [fp, #-0x60]
    // 0xc11778: ldur            d0, [fp, #-0xc8]
    // 0xc1177c: mov             x3, x0
    // 0xc11780: mov             x0, x1
    // 0xc11784: ldur            x1, [fp, #-0x68]
    // 0xc11788: ldur            x2, [fp, #-0x40]
    // 0xc1178c: b               #0xc12080
    // 0xc11790: ldur            x3, [fp, #-0x70]
    // 0xc11794: ldur            x5, [fp, #-0x80]
    // 0xc11798: mov             x2, x1
    // 0xc1179c: ldur            x1, [fp, #-0x38]
    // 0xc117a0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc117a0: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc117a4: r0 = getBoxesForSelection()
    //     0xc117a4: bl              #0x85fc0c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0xc117a8: mov             x2, x0
    // 0xc117ac: stur            x2, [fp, #-0x98]
    // 0xc117b0: r0 = LoadClassIdInstr(r2)
    //     0xc117b0: ldur            x0, [x2, #-1]
    //     0xc117b4: ubfx            x0, x0, #0xc, #0x14
    // 0xc117b8: mov             x1, x2
    // 0xc117bc: r0 = GDT[cid_x0 + 0x12b36]()
    //     0xc117bc: mov             x17, #0x2b36
    //     0xc117c0: movk            x17, #1, lsl #16
    //     0xc117c4: add             lr, x0, x17
    //     0xc117c8: ldr             lr, [x21, lr, lsl #3]
    //     0xc117cc: blr             lr
    // 0xc117d0: tbnz            w0, #4, #0xc117f0
    // 0xc117d4: ldur            x12, [fp, #-0x60]
    // 0xc117d8: ldur            d0, [fp, #-0xc8]
    // 0xc117dc: ldur            x10, [fp, #-0x70]
    // 0xc117e0: ldur            x9, [fp, #-0x78]
    // 0xc117e4: ldur            x8, [fp, #-0x80]
    // 0xc117e8: ldur            x2, [fp, #-0x40]
    // 0xc117ec: b               #0xc12090
    // 0xc117f0: ldur            x2, [fp, #-0x98]
    // 0xc117f4: r0 = LoadClassIdInstr(r2)
    //     0xc117f4: ldur            x0, [x2, #-1]
    //     0xc117f8: ubfx            x0, x0, #0xc, #0x14
    // 0xc117fc: mov             x1, x2
    // 0xc11800: r0 = GDT[cid_x0 + 0x127b5]()
    //     0xc11800: mov             x17, #0x27b5
    //     0xc11804: movk            x17, #1, lsl #16
    //     0xc11808: add             lr, x0, x17
    //     0xc1180c: ldr             lr, [x21, lr, lsl #3]
    //     0xc11810: blr             lr
    // 0xc11814: LoadField: d0 = r0->field_7
    //     0xc11814: ldur            d0, [x0, #7]
    // 0xc11818: stur            d0, [fp, #-0xe8]
    // 0xc1181c: LoadField: d1 = r0->field_f
    //     0xc1181c: ldur            d1, [x0, #0xf]
    // 0xc11820: stur            d1, [fp, #-0xe0]
    // 0xc11824: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xc11824: ldur            d2, [x0, #0x17]
    // 0xc11828: stur            d2, [fp, #-0xd8]
    // 0xc1182c: LoadField: d3 = r0->field_1f
    //     0xc1182c: ldur            d3, [x0, #0x1f]
    // 0xc11830: ldur            x2, [fp, #-0x98]
    // 0xc11834: stur            d3, [fp, #-0xd0]
    // 0xc11838: r0 = LoadClassIdInstr(r2)
    //     0xc11838: ldur            x0, [x2, #-1]
    //     0xc1183c: ubfx            x0, x0, #0xc, #0x14
    // 0xc11840: mov             x1, x2
    // 0xc11844: r0 = GDT[cid_x0 + 0x127b5]()
    //     0xc11844: mov             x17, #0x27b5
    //     0xc11848: movk            x17, #1, lsl #16
    //     0xc1184c: add             lr, x0, x17
    //     0xc11850: ldr             lr, [x21, lr, lsl #3]
    //     0xc11854: blr             lr
    // 0xc11858: LoadField: r2 = r0->field_27
    //     0xc11858: ldur            w2, [x0, #0x27]
    // 0xc1185c: DecompressPointer r2
    //     0xc1185c: add             x2, x2, HEAP, lsl #32
    // 0xc11860: ldur            x0, [fp, #-0x98]
    // 0xc11864: stur            x2, [fp, #-0xa8]
    // 0xc11868: LoadField: r3 = r0->field_7
    //     0xc11868: ldur            w3, [x0, #7]
    // 0xc1186c: DecompressPointer r3
    //     0xc1186c: add             x3, x3, HEAP, lsl #32
    // 0xc11870: mov             x1, x3
    // 0xc11874: stur            x3, [fp, #-0xa0]
    // 0xc11878: r0 = SubListIterable()
    //     0xc11878: bl              #0x82e540  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0xc1187c: mov             x1, x0
    // 0xc11880: ldur            x2, [fp, #-0x98]
    // 0xc11884: r3 = 1
    //     0xc11884: mov             x3, #1
    // 0xc11888: r5 = Null
    //     0xc11888: mov             x5, NULL
    // 0xc1188c: stur            x0, [fp, #-0x98]
    // 0xc11890: r0 = SubListIterable()
    //     0xc11890: bl              #0x82e364  ; [dart:_internal] SubListIterable::SubListIterable
    // 0xc11894: ldur            x16, [fp, #-0x98]
    // 0xc11898: str             x16, [SP]
    // 0xc1189c: r0 = length()
    //     0xc1189c: bl              #0xbfb9c4  ; [dart:_internal] SubListIterable::length
    // 0xc118a0: r1 = LoadInt32Instr(r0)
    //     0xc118a0: sbfx            x1, x0, #1, #0x1f
    //     0xc118a4: tbz             w0, #0, #0xc118ac
    //     0xc118a8: ldur            x1, [x0, #7]
    // 0xc118ac: stur            x1, [fp, #-0xb0]
    // 0xc118b0: ldur            x0, [fp, #-0xa8]
    // 0xc118b4: ldur            d3, [fp, #-0xe8]
    // 0xc118b8: ldur            d2, [fp, #-0xe0]
    // 0xc118bc: ldur            d1, [fp, #-0xd8]
    // 0xc118c0: ldur            d0, [fp, #-0xd0]
    // 0xc118c4: r2 = 0
    //     0xc118c4: mov             x2, #0
    // 0xc118c8: stur            x0, [fp, #-0xa8]
    // 0xc118cc: stur            x2, [fp, #-0x68]
    // 0xc118d0: stur            d3, [fp, #-0xd0]
    // 0xc118d4: stur            d2, [fp, #-0xd8]
    // 0xc118d8: stur            d1, [fp, #-0xe0]
    // 0xc118dc: stur            d0, [fp, #-0xe8]
    // 0xc118e0: CheckStackOverflow
    //     0xc118e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc118e4: cmp             SP, x16
    //     0xc118e8: b.ls            #0xc12194
    // 0xc118ec: ldur            x16, [fp, #-0x98]
    // 0xc118f0: str             x16, [SP]
    // 0xc118f4: r0 = length()
    //     0xc118f4: bl              #0xbfb9c4  ; [dart:_internal] SubListIterable::length
    // 0xc118f8: r1 = LoadInt32Instr(r0)
    //     0xc118f8: sbfx            x1, x0, #1, #0x1f
    //     0xc118fc: tbz             w0, #0, #0xc11904
    //     0xc11900: ldur            x1, [x0, #7]
    // 0xc11904: ldur            x0, [fp, #-0xb0]
    // 0xc11908: cmp             x0, x1
    // 0xc1190c: b.ne            #0xc12124
    // 0xc11910: ldur            x3, [fp, #-0x68]
    // 0xc11914: cmp             x3, x1
    // 0xc11918: b.ge            #0xc119d0
    // 0xc1191c: ldur            x1, [fp, #-0x98]
    // 0xc11920: mov             x2, x3
    // 0xc11924: r0 = elementAt()
    //     0xc11924: bl              #0xafd898  ; [dart:_internal] SubListIterable::elementAt
    // 0xc11928: mov             x3, x0
    // 0xc1192c: ldur            x0, [fp, #-0x68]
    // 0xc11930: stur            x3, [fp, #-0xc0]
    // 0xc11934: add             x4, x0, #1
    // 0xc11938: stur            x4, [fp, #-0xb8]
    // 0xc1193c: cmp             w3, NULL
    // 0xc11940: b.ne            #0xc11974
    // 0xc11944: mov             x0, x3
    // 0xc11948: ldur            x2, [fp, #-0xa0]
    // 0xc1194c: r1 = Null
    //     0xc1194c: mov             x1, NULL
    // 0xc11950: cmp             w2, NULL
    // 0xc11954: b.eq            #0xc11974
    // 0xc11958: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc11958: ldur            w4, [x2, #0x17]
    // 0xc1195c: DecompressPointer r4
    //     0xc1195c: add             x4, x4, HEAP, lsl #32
    // 0xc11960: r8 = X0
    //     0xc11960: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xc11964: LoadField: r9 = r4->field_7
    //     0xc11964: ldur            x9, [x4, #7]
    // 0xc11968: r3 = Null
    //     0xc11968: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd6c8] Null
    //     0xc1196c: ldr             x3, [x3, #0x6c8]
    // 0xc11970: blr             x9
    // 0xc11974: ldur            x0, [fp, #-0xc0]
    // 0xc11978: ldur            d3, [fp, #-0xd0]
    // 0xc1197c: ldur            d2, [fp, #-0xd8]
    // 0xc11980: ldur            d1, [fp, #-0xe0]
    // 0xc11984: ldur            d0, [fp, #-0xe8]
    // 0xc11988: LoadField: d4 = r0->field_7
    //     0xc11988: ldur            d4, [x0, #7]
    // 0xc1198c: LoadField: d5 = r0->field_f
    //     0xc1198c: ldur            d5, [x0, #0xf]
    // 0xc11990: ArrayLoad: d6 = r0[0]  ; List_8
    //     0xc11990: ldur            d6, [x0, #0x17]
    // 0xc11994: LoadField: d7 = r0->field_1f
    //     0xc11994: ldur            d7, [x0, #0x1f]
    // 0xc11998: fmin            v8.2d, v3.2d, v4.2d
    // 0xc1199c: fmin            v4.2d, v2.2d, v5.2d
    // 0xc119a0: fmax            v5.2d, v1.2d, v6.2d
    // 0xc119a4: fmax            v6.2d, v0.2d, v7.2d
    // 0xc119a8: LoadField: r1 = r0->field_27
    //     0xc119a8: ldur            w1, [x0, #0x27]
    // 0xc119ac: DecompressPointer r1
    //     0xc119ac: add             x1, x1, HEAP, lsl #32
    // 0xc119b0: mov             x0, x1
    // 0xc119b4: ldur            x2, [fp, #-0xb8]
    // 0xc119b8: mov             v3.16b, v8.16b
    // 0xc119bc: mov             v2.16b, v4.16b
    // 0xc119c0: mov             v1.16b, v5.16b
    // 0xc119c4: mov             v0.16b, v6.16b
    // 0xc119c8: ldur            x1, [fp, #-0xb0]
    // 0xc119cc: b               #0xc118c8
    // 0xc119d0: ldur            x3, [fp, #-8]
    // 0xc119d4: ldur            d3, [fp, #-0xd0]
    // 0xc119d8: ldur            d2, [fp, #-0xd8]
    // 0xc119dc: ldur            d1, [fp, #-0xe0]
    // 0xc119e0: ldur            d0, [fp, #-0xe8]
    // 0xc119e4: d4 = 0.000000
    //     0xc119e4: eor             v4.16b, v4.16b, v4.16b
    // 0xc119e8: fmax            v5.2d, v4.2d, v3.2d
    // 0xc119ec: stur            d5, [fp, #-0x100]
    // 0xc119f0: fmax            v6.2d, v4.2d, v2.2d
    // 0xc119f4: stur            d6, [fp, #-0xf8]
    // 0xc119f8: fsub            d7, d1, d3
    // 0xc119fc: stur            d7, [fp, #-0xf0]
    // 0xc11a00: LoadField: r4 = r3->field_27
    //     0xc11a00: ldur            w4, [x3, #0x27]
    // 0xc11a04: DecompressPointer r4
    //     0xc11a04: add             x4, x4, HEAP, lsl #32
    // 0xc11a08: stur            x4, [fp, #-0xa0]
    // 0xc11a0c: cmp             w4, NULL
    // 0xc11a10: b.eq            #0xc12108
    // 0xc11a14: ldur            d1, [fp, #-0xc8]
    // 0xc11a18: ldur            x5, [fp, #-0x30]
    // 0xc11a1c: mov             x0, x4
    // 0xc11a20: r2 = Null
    //     0xc11a20: mov             x2, NULL
    // 0xc11a24: r1 = Null
    //     0xc11a24: mov             x1, NULL
    // 0xc11a28: r4 = LoadClassIdInstr(r0)
    //     0xc11a28: ldur            x4, [x0, #-1]
    //     0xc11a2c: ubfx            x4, x4, #0xc, #0x14
    // 0xc11a30: sub             x4, x4, #0xb46
    // 0xc11a34: cmp             x4, #1
    // 0xc11a38: b.ls            #0xc11a4c
    // 0xc11a3c: r8 = BoxConstraints
    //     0xc11a3c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xc11a40: r3 = Null
    //     0xc11a40: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd6d8] Null
    //     0xc11a44: ldr             x3, [x3, #0x6d8]
    // 0xc11a48: r0 = BoxConstraints()
    //     0xc11a48: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xc11a4c: ldur            x0, [fp, #-0xa0]
    // 0xc11a50: LoadField: d0 = r0->field_f
    //     0xc11a50: ldur            d0, [x0, #0xf]
    // 0xc11a54: ldur            d1, [fp, #-0xf0]
    // 0xc11a58: fmin            v2.2d, v1.2d, v0.2d
    // 0xc11a5c: ldur            d1, [fp, #-0xd8]
    // 0xc11a60: ldur            d0, [fp, #-0xe8]
    // 0xc11a64: fsub            d3, d0, d1
    // 0xc11a68: LoadField: d0 = r0->field_1f
    //     0xc11a68: ldur            d0, [x0, #0x1f]
    // 0xc11a6c: fmin            v1.2d, v3.2d, v0.2d
    // 0xc11a70: ldur            d0, [fp, #-0x100]
    // 0xc11a74: fadd            d3, d0, d2
    // 0xc11a78: ldur            d2, [fp, #-0xf8]
    // 0xc11a7c: stur            d3, [fp, #-0xd8]
    // 0xc11a80: fadd            d4, d2, d1
    // 0xc11a84: stur            d4, [fp, #-0xd0]
    // 0xc11a88: stp             fp, lr, [SP, #-0x10]!
    // 0xc11a8c: mov             fp, SP
    // 0xc11a90: CallRuntime_LibcFloor(double) -> double
    //     0xc11a90: and             SP, SP, #0xfffffffffffffff0
    //     0xc11a94: mov             sp, SP
    //     0xc11a98: ldr             x16, [THR, #0x758]  ; THR::LibcFloor
    //     0xc11a9c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc11aa0: blr             x16
    //     0xc11aa4: mov             x16, #8
    //     0xc11aa8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc11aac: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc11ab0: sub             sp, x16, #1, lsl #12
    //     0xc11ab4: mov             SP, fp
    //     0xc11ab8: ldp             fp, lr, [SP], #0x10
    // 0xc11abc: d1 = 4.000000
    //     0xc11abc: fmov            d1, #4.00000000
    // 0xc11ac0: fsub            d2, d0, d1
    // 0xc11ac4: ldur            d0, [fp, #-0xf8]
    // 0xc11ac8: stur            d2, [fp, #-0xe0]
    // 0xc11acc: stp             fp, lr, [SP, #-0x10]!
    // 0xc11ad0: mov             fp, SP
    // 0xc11ad4: CallRuntime_LibcFloor(double) -> double
    //     0xc11ad4: and             SP, SP, #0xfffffffffffffff0
    //     0xc11ad8: mov             sp, SP
    //     0xc11adc: ldr             x16, [THR, #0x758]  ; THR::LibcFloor
    //     0xc11ae0: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc11ae4: blr             x16
    //     0xc11ae8: mov             x16, #8
    //     0xc11aec: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc11af0: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc11af4: sub             sp, x16, #1, lsl #12
    //     0xc11af8: mov             SP, fp
    //     0xc11afc: ldp             fp, lr, [SP], #0x10
    // 0xc11b00: d1 = 4.000000
    //     0xc11b00: fmov            d1, #4.00000000
    // 0xc11b04: fsub            d2, d0, d1
    // 0xc11b08: ldur            d0, [fp, #-0xd8]
    // 0xc11b0c: stur            d2, [fp, #-0xe8]
    // 0xc11b10: stp             fp, lr, [SP, #-0x10]!
    // 0xc11b14: mov             fp, SP
    // 0xc11b18: CallRuntime_LibcCeil(double) -> double
    //     0xc11b18: and             SP, SP, #0xfffffffffffffff0
    //     0xc11b1c: mov             sp, SP
    //     0xc11b20: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xc11b24: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc11b28: blr             x16
    //     0xc11b2c: mov             x16, #8
    //     0xc11b30: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc11b34: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc11b38: sub             sp, x16, #1, lsl #12
    //     0xc11b3c: mov             SP, fp
    //     0xc11b40: ldp             fp, lr, [SP], #0x10
    // 0xc11b44: d1 = 4.000000
    //     0xc11b44: fmov            d1, #4.00000000
    // 0xc11b48: fadd            d2, d0, d1
    // 0xc11b4c: ldur            d0, [fp, #-0xd0]
    // 0xc11b50: stur            d2, [fp, #-0xd8]
    // 0xc11b54: stp             fp, lr, [SP, #-0x10]!
    // 0xc11b58: mov             fp, SP
    // 0xc11b5c: CallRuntime_LibcCeil(double) -> double
    //     0xc11b5c: and             SP, SP, #0xfffffffffffffff0
    //     0xc11b60: mov             sp, SP
    //     0xc11b64: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xc11b68: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc11b6c: blr             x16
    //     0xc11b70: mov             x16, #8
    //     0xc11b74: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc11b78: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc11b7c: sub             sp, x16, #1, lsl #12
    //     0xc11b80: mov             SP, fp
    //     0xc11b84: ldp             fp, lr, [SP], #0x10
    // 0xc11b88: mov             v1.16b, v0.16b
    // 0xc11b8c: d0 = 4.000000
    //     0xc11b8c: fmov            d0, #4.00000000
    // 0xc11b90: fadd            d2, d1, d0
    // 0xc11b94: stur            d2, [fp, #-0xd0]
    // 0xc11b98: r0 = Rect()
    //     0xc11b98: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc11b9c: ldur            d0, [fp, #-0xe0]
    // 0xc11ba0: stur            x0, [fp, #-0xa0]
    // 0xc11ba4: StoreField: r0->field_7 = d0
    //     0xc11ba4: stur            d0, [x0, #7]
    // 0xc11ba8: ldur            d1, [fp, #-0xe8]
    // 0xc11bac: StoreField: r0->field_f = d1
    //     0xc11bac: stur            d1, [x0, #0xf]
    // 0xc11bb0: ldur            d2, [fp, #-0xd8]
    // 0xc11bb4: ArrayStore: r0[0] = d2  ; List_8
    //     0xc11bb4: stur            d2, [x0, #0x17]
    // 0xc11bb8: ldur            d3, [fp, #-0xd0]
    // 0xc11bbc: StoreField: r0->field_1f = d3
    //     0xc11bbc: stur            d3, [x0, #0x1f]
    // 0xc11bc0: r0 = SemanticsConfiguration()
    //     0xc11bc0: bl              #0x839284  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0xc8)
    // 0xc11bc4: mov             x1, x0
    // 0xc11bc8: stur            x0, [fp, #-0xc0]
    // 0xc11bcc: r0 = SemanticsConfiguration()
    //     0xc11bcc: bl              #0x837c94  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0xc11bd0: ldur            d1, [fp, #-0xc8]
    // 0xc11bd4: d0 = 1.000000
    //     0xc11bd4: fmov            d0, #1.00000000
    // 0xc11bd8: fadd            d2, d1, d0
    // 0xc11bdc: stur            d2, [fp, #-0xf0]
    // 0xc11be0: r0 = OrdinalSortKey()
    //     0xc11be0: bl              #0xc121a8  ; AllocateOrdinalSortKeyStub -> OrdinalSortKey (size=0x14)
    // 0xc11be4: ldur            d0, [fp, #-0xc8]
    // 0xc11be8: StoreField: r0->field_b = d0
    //     0xc11be8: stur            d0, [x0, #0xb]
    // 0xc11bec: ldur            x1, [fp, #-0xc0]
    // 0xc11bf0: StoreField: r1->field_33 = r0
    //     0xc11bf0: stur            w0, [x1, #0x33]
    //     0xc11bf4: ldurb           w16, [x1, #-1]
    //     0xc11bf8: ldurb           w17, [x0, #-1]
    //     0xc11bfc: and             x16, x17, x16, lsr #2
    //     0xc11c00: tst             x16, HEAP, lsr #32
    //     0xc11c04: b.eq            #0xc11c0c
    //     0xc11c08: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc11c0c: r2 = true
    //     0xc11c0c: add             x2, NULL, #0x20  ; true
    // 0xc11c10: StoreField: r1->field_1f = r2
    //     0xc11c10: stur            w2, [x1, #0x1f]
    // 0xc11c14: ldur            x0, [fp, #-0x60]
    // 0xc11c18: StoreField: r1->field_83 = r0
    //     0xc11c18: stur            w0, [x1, #0x83]
    //     0xc11c1c: ldurb           w16, [x1, #-1]
    //     0xc11c20: ldurb           w17, [x0, #-1]
    //     0xc11c24: and             x16, x17, x16, lsr #2
    //     0xc11c28: tst             x16, HEAP, lsr #32
    //     0xc11c2c: b.eq            #0xc11c34
    //     0xc11c30: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc11c34: ldur            x0, [fp, #-0x30]
    // 0xc11c38: LoadField: r3 = r0->field_b
    //     0xc11c38: ldur            w3, [x0, #0xb]
    // 0xc11c3c: DecompressPointer r3
    //     0xc11c3c: add             x3, x3, HEAP, lsl #32
    // 0xc11c40: cmp             w3, NULL
    // 0xc11c44: b.ne            #0xc11c4c
    // 0xc11c48: ldur            x3, [fp, #-0x28]
    // 0xc11c4c: stur            x3, [fp, #-0x60]
    // 0xc11c50: LoadField: r4 = r0->field_1f
    //     0xc11c50: ldur            w4, [x0, #0x1f]
    // 0xc11c54: DecompressPointer r4
    //     0xc11c54: add             x4, x4, HEAP, lsl #32
    // 0xc11c58: stur            x4, [fp, #-0x28]
    // 0xc11c5c: r0 = AttributedString()
    //     0xc11c5c: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xc11c60: mov             x1, x0
    // 0xc11c64: ldur            x0, [fp, #-0x60]
    // 0xc11c68: StoreField: r1->field_7 = r0
    //     0xc11c68: stur            w0, [x1, #7]
    // 0xc11c6c: ldur            x0, [fp, #-0x28]
    // 0xc11c70: StoreField: r1->field_b = r0
    //     0xc11c70: stur            w0, [x1, #0xb]
    // 0xc11c74: mov             x0, x1
    // 0xc11c78: ldur            x4, [fp, #-0xc0]
    // 0xc11c7c: StoreField: r4->field_67 = r0
    //     0xc11c7c: stur            w0, [x4, #0x67]
    //     0xc11c80: ldurb           w16, [x4, #-1]
    //     0xc11c84: ldurb           w17, [x0, #-1]
    //     0xc11c88: and             x16, x17, x16, lsr #2
    //     0xc11c8c: tst             x16, HEAP, lsr #32
    //     0xc11c90: b.eq            #0xc11c98
    //     0xc11c94: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xc11c98: r0 = true
    //     0xc11c98: add             x0, NULL, #0x20  ; true
    // 0xc11c9c: StoreField: r4->field_1f = r0
    //     0xc11c9c: stur            w0, [x4, #0x1f]
    // 0xc11ca0: ldur            x1, [fp, #-0x30]
    // 0xc11ca4: LoadField: r2 = r1->field_13
    //     0xc11ca4: ldur            w2, [x1, #0x13]
    // 0xc11ca8: DecompressPointer r2
    //     0xc11ca8: add             x2, x2, HEAP, lsl #32
    // 0xc11cac: r1 = LoadClassIdInstr(r2)
    //     0xc11cac: ldur            x1, [x2, #-1]
    //     0xc11cb0: ubfx            x1, x1, #0xc, #0x14
    // 0xc11cb4: r17 = -4437
    //     0xc11cb4: mov             x17, #-0x1155
    // 0xc11cb8: add             x16, x1, x17
    // 0xc11cbc: cmp             x16, #1
    // 0xc11cc0: b.hi            #0xc11cd4
    // 0xc11cc4: LoadField: r1 = r2->field_5f
    //     0xc11cc4: ldur            w1, [x2, #0x5f]
    // 0xc11cc8: DecompressPointer r1
    //     0xc11cc8: add             x1, x1, HEAP, lsl #32
    // 0xc11ccc: mov             x3, x1
    // 0xc11cd0: b               #0xc11cec
    // 0xc11cd4: r17 = 4429
    //     0xc11cd4: mov             x17, #0x114d
    // 0xc11cd8: cmp             x1, x17
    // 0xc11cdc: b.ne            #0xc11d4c
    // 0xc11ce0: LoadField: r1 = r2->field_1b
    //     0xc11ce0: ldur            w1, [x2, #0x1b]
    // 0xc11ce4: DecompressPointer r1
    //     0xc11ce4: add             x1, x1, HEAP, lsl #32
    // 0xc11ce8: mov             x3, x1
    // 0xc11cec: cmp             w3, NULL
    // 0xc11cf0: b.eq            #0xc11d78
    // 0xc11cf4: mov             x1, x4
    // 0xc11cf8: r2 = Instance_SemanticsAction
    //     0xc11cf8: ldr             x2, [PP, #0x26b0]  ; [pp+0x26b0] Obj!SemanticsAction@12a0901
    // 0xc11cfc: r0 = _addArgumentlessAction()
    //     0xc11cfc: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xc11d00: ldur            x0, [fp, #-0xc0]
    // 0xc11d04: LoadField: r1 = r0->field_c3
    //     0xc11d04: ldur            w1, [x0, #0xc3]
    // 0xc11d08: DecompressPointer r1
    //     0xc11d08: add             x1, x1, HEAP, lsl #32
    // 0xc11d0c: r16 = true
    //     0xc11d0c: add             x16, NULL, #0x20  ; true
    // 0xc11d10: str             x16, [SP]
    // 0xc11d14: r4 = const [0, 0x2, 0x1, 0x1, isLink, 0x1, null]
    //     0xc11d14: add             x4, PP, #0x98, lsl #12  ; [pp+0x988a8] List(7) [0, 0x2, 0x1, 0x1, "isLink", 0x1, Null]
    //     0xc11d18: ldr             x4, [x4, #0x8a8]
    // 0xc11d1c: r0 = copyWith()
    //     0xc11d1c: bl              #0x8905b0  ; [dart:ui] SemanticsFlags::copyWith
    // 0xc11d20: ldur            x4, [fp, #-0xc0]
    // 0xc11d24: StoreField: r4->field_c3 = r0
    //     0xc11d24: stur            w0, [x4, #0xc3]
    //     0xc11d28: ldurb           w16, [x4, #-1]
    //     0xc11d2c: ldurb           w17, [x0, #-1]
    //     0xc11d30: and             x16, x17, x16, lsr #2
    //     0xc11d34: tst             x16, HEAP, lsr #32
    //     0xc11d38: b.eq            #0xc11d40
    //     0xc11d3c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xc11d40: r0 = true
    //     0xc11d40: add             x0, NULL, #0x20  ; true
    // 0xc11d44: StoreField: r4->field_1f = r0
    //     0xc11d44: stur            w0, [x4, #0x1f]
    // 0xc11d48: b               #0xc11d78
    // 0xc11d4c: r17 = 4439
    //     0xc11d4c: mov             x17, #0x1157
    // 0xc11d50: cmp             x1, x17
    // 0xc11d54: b.ne            #0xc11d78
    // 0xc11d58: LoadField: r3 = r2->field_5b
    //     0xc11d58: ldur            w3, [x2, #0x5b]
    // 0xc11d5c: DecompressPointer r3
    //     0xc11d5c: add             x3, x3, HEAP, lsl #32
    // 0xc11d60: cmp             w3, NULL
    // 0xc11d64: b.eq            #0xc11d78
    // 0xc11d68: mov             x1, x4
    // 0xc11d6c: r2 = Instance_SemanticsAction
    //     0xc11d6c: add             x2, PP, #0x85, lsl #12  ; [pp+0x85768] Obj!SemanticsAction@12a08e1
    //     0xc11d70: ldr             x2, [x2, #0x768]
    // 0xc11d74: r0 = _addArgumentlessAction()
    //     0xc11d74: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xc11d78: ldur            x0, [fp, #-0x10]
    // 0xc11d7c: LoadField: r1 = r0->field_23
    //     0xc11d7c: ldur            w1, [x0, #0x23]
    // 0xc11d80: DecompressPointer r1
    //     0xc11d80: add             x1, x1, HEAP, lsl #32
    // 0xc11d84: cmp             w1, NULL
    // 0xc11d88: b.eq            #0xc11e44
    // 0xc11d8c: ldur            d0, [fp, #-0xe0]
    // 0xc11d90: ldur            d1, [fp, #-0xe8]
    // 0xc11d94: ldur            d2, [fp, #-0xd8]
    // 0xc11d98: ldur            d3, [fp, #-0xd0]
    // 0xc11d9c: LoadField: d4 = r1->field_7
    //     0xc11d9c: ldur            d4, [x1, #7]
    // 0xc11da0: fmax            v5.2d, v4.2d, v0.2d
    // 0xc11da4: LoadField: d4 = r1->field_f
    //     0xc11da4: ldur            d4, [x1, #0xf]
    // 0xc11da8: fmax            v6.2d, v4.2d, v1.2d
    // 0xc11dac: ArrayLoad: d4 = r1[0]  ; List_8
    //     0xc11dac: ldur            d4, [x1, #0x17]
    // 0xc11db0: fmin            v7.2d, v4.2d, v2.2d
    // 0xc11db4: LoadField: d4 = r1->field_1f
    //     0xc11db4: ldur            d4, [x1, #0x1f]
    // 0xc11db8: fmin            v8.2d, v4.2d, v3.2d
    // 0xc11dbc: fcmp            d5, d7
    // 0xc11dc0: b.ge            #0xc11dcc
    // 0xc11dc4: fcmp            d6, d8
    // 0xc11dc8: b.lt            #0xc11df8
    // 0xc11dcc: fcmp            d0, d2
    // 0xc11dd0: b.lt            #0xc11ddc
    // 0xc11dd4: r1 = true
    //     0xc11dd4: add             x1, NULL, #0x20  ; true
    // 0xc11dd8: b               #0xc11dec
    // 0xc11ddc: fcmp            d1, d3
    // 0xc11de0: r16 = true
    //     0xc11de0: add             x16, NULL, #0x20  ; true
    // 0xc11de4: r17 = false
    //     0xc11de4: add             x17, NULL, #0x30  ; false
    // 0xc11de8: csel            x1, x16, x17, ge
    // 0xc11dec: eor             x2, x1, #0x10
    // 0xc11df0: mov             x1, x2
    // 0xc11df4: b               #0xc11dfc
    // 0xc11df8: r1 = false
    //     0xc11df8: add             x1, NULL, #0x30  ; false
    // 0xc11dfc: ldur            x2, [fp, #-0xc0]
    // 0xc11e00: LoadField: r3 = r2->field_c3
    //     0xc11e00: ldur            w3, [x2, #0xc3]
    // 0xc11e04: DecompressPointer r3
    //     0xc11e04: add             x3, x3, HEAP, lsl #32
    // 0xc11e08: str             x1, [SP]
    // 0xc11e0c: mov             x1, x3
    // 0xc11e10: r4 = const [0, 0x2, 0x1, 0x1, isHidden, 0x1, null]
    //     0xc11e10: ldr             x4, [PP, #0x28c0]  ; [pp+0x28c0] List(7) [0, 0x2, 0x1, 0x1, "isHidden", 0x1, Null]
    // 0xc11e14: r0 = copyWith()
    //     0xc11e14: bl              #0x8905b0  ; [dart:ui] SemanticsFlags::copyWith
    // 0xc11e18: ldur            x2, [fp, #-0xc0]
    // 0xc11e1c: StoreField: r2->field_c3 = r0
    //     0xc11e1c: stur            w0, [x2, #0xc3]
    //     0xc11e20: ldurb           w16, [x2, #-1]
    //     0xc11e24: ldurb           w17, [x0, #-1]
    //     0xc11e28: and             x16, x17, x16, lsr #2
    //     0xc11e2c: tst             x16, HEAP, lsr #32
    //     0xc11e30: b.eq            #0xc11e38
    //     0xc11e34: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc11e38: r0 = true
    //     0xc11e38: add             x0, NULL, #0x20  ; true
    // 0xc11e3c: StoreField: r2->field_1f = r0
    //     0xc11e3c: stur            w0, [x2, #0x1f]
    // 0xc11e40: b               #0xc11e4c
    // 0xc11e44: ldur            x2, [fp, #-0xc0]
    // 0xc11e48: r0 = true
    //     0xc11e48: add             x0, NULL, #0x20  ; true
    // 0xc11e4c: ldur            x3, [fp, #-8]
    // 0xc11e50: r17 = 275
    //     0xc11e50: mov             x17, #0x113
    // 0xc11e54: ldr             w4, [x3, x17]
    // 0xc11e58: DecompressPointer r4
    //     0xc11e58: add             x4, x4, HEAP, lsl #32
    // 0xc11e5c: stur            x4, [fp, #-0x28]
    // 0xc11e60: cmp             w4, NULL
    // 0xc11e64: b.ne            #0xc11e70
    // 0xc11e68: r1 = Null
    //     0xc11e68: mov             x1, NULL
    // 0xc11e6c: b               #0xc11e98
    // 0xc11e70: LoadField: r1 = r4->field_13
    //     0xc11e70: ldur            w1, [x4, #0x13]
    // 0xc11e74: r5 = LoadInt32Instr(r1)
    //     0xc11e74: sbfx            x5, x1, #1, #0x1f
    // 0xc11e78: asr             x1, x5, #1
    // 0xc11e7c: ArrayLoad: r5 = r4[0]  ; List_4
    //     0xc11e7c: ldur            w5, [x4, #0x17]
    // 0xc11e80: r6 = LoadInt32Instr(r5)
    //     0xc11e80: sbfx            x6, x5, #1, #0x1f
    // 0xc11e84: sub             x5, x1, x6
    // 0xc11e88: cbnz            x5, #0xc11e94
    // 0xc11e8c: r1 = false
    //     0xc11e8c: add             x1, NULL, #0x30  ; false
    // 0xc11e90: b               #0xc11e98
    // 0xc11e94: r1 = true
    //     0xc11e94: add             x1, NULL, #0x20  ; true
    // 0xc11e98: cmp             w1, NULL
    // 0xc11e9c: b.ne            #0xc11ea8
    // 0xc11ea0: mov             x0, x3
    // 0xc11ea4: b               #0xc11f3c
    // 0xc11ea8: tbnz            w1, #4, #0xc11f38
    // 0xc11eac: cmp             w4, NULL
    // 0xc11eb0: b.eq            #0xc1219c
    // 0xc11eb4: r1 = <Key, SemanticsNode>
    //     0xc11eb4: add             x1, PP, #0x98, lsl #12  ; [pp+0x98850] TypeArguments: <Key, SemanticsNode>
    //     0xc11eb8: ldr             x1, [x1, #0x850]
    // 0xc11ebc: r0 = _CompactKeysIterable()
    //     0xc11ebc: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xc11ec0: mov             x1, x0
    // 0xc11ec4: ldur            x0, [fp, #-0x28]
    // 0xc11ec8: StoreField: r1->field_b = r0
    //     0xc11ec8: stur            w0, [x1, #0xb]
    // 0xc11ecc: r0 = iterator()
    //     0xc11ecc: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xc11ed0: mov             x2, x0
    // 0xc11ed4: stur            x2, [fp, #-0x30]
    // 0xc11ed8: r0 = LoadClassIdInstr(r2)
    //     0xc11ed8: ldur            x0, [x2, #-1]
    //     0xc11edc: ubfx            x0, x0, #0xc, #0x14
    // 0xc11ee0: mov             x1, x2
    // 0xc11ee4: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xc11ee4: mov             x17, #0x845b
    //     0xc11ee8: movk            x17, #1, lsl #16
    //     0xc11eec: add             lr, x0, x17
    //     0xc11ef0: ldr             lr, [x21, lr, lsl #3]
    //     0xc11ef4: blr             lr
    // 0xc11ef8: tbnz            w0, #4, #0xc120fc
    // 0xc11efc: ldur            x1, [fp, #-0x30]
    // 0xc11f00: r0 = LoadClassIdInstr(r1)
    //     0xc11f00: ldur            x0, [x1, #-1]
    //     0xc11f04: ubfx            x0, x0, #0xc, #0x14
    // 0xc11f08: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xc11f08: mov             x17, #0x7d4c
    //     0xc11f0c: movk            x17, #1, lsl #16
    //     0xc11f10: add             lr, x0, x17
    //     0xc11f14: ldr             lr, [x21, lr, lsl #3]
    //     0xc11f18: blr             lr
    // 0xc11f1c: ldur            x1, [fp, #-0x28]
    // 0xc11f20: mov             x2, x0
    // 0xc11f24: r0 = remove()
    //     0xc11f24: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc11f28: cmp             w0, NULL
    // 0xc11f2c: b.eq            #0xc121a0
    // 0xc11f30: mov             x4, x0
    // 0xc11f34: b               #0xc11f98
    // 0xc11f38: ldur            x0, [fp, #-8]
    // 0xc11f3c: r1 = 2
    //     0xc11f3c: mov             x1, #2
    // 0xc11f40: r0 = AllocateContext()
    //     0xc11f40: bl              #0x13de838  ; AllocateContextStub
    // 0xc11f44: mov             x1, x0
    // 0xc11f48: ldur            x0, [fp, #-8]
    // 0xc11f4c: stur            x1, [fp, #-0x28]
    // 0xc11f50: StoreField: r1->field_f = r0
    //     0xc11f50: stur            w0, [x1, #0xf]
    // 0xc11f54: r0 = UniqueKey()
    //     0xc11f54: bl              #0xb8f328  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0xc11f58: ldur            x2, [fp, #-0x28]
    // 0xc11f5c: stur            x0, [fp, #-0x30]
    // 0xc11f60: StoreField: r2->field_13 = r0
    //     0xc11f60: stur            w0, [x2, #0x13]
    // 0xc11f64: r0 = SemanticsNode()
    //     0xc11f64: bl              #0x894094  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xf0)
    // 0xc11f68: ldur            x2, [fp, #-0x28]
    // 0xc11f6c: r1 = Function '<anonymous closure>':.
    //     0xc11f6c: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd6e8] AnonymousClosure: (0xc121b4), of [package:flutter/src/rendering/editable.dart] RenderEditable
    //     0xc11f70: ldr             x1, [x1, #0x6e8]
    // 0xc11f74: stur            x0, [fp, #-0x28]
    // 0xc11f78: r0 = AllocateClosure()
    //     0xc11f78: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc11f7c: ldur            x16, [fp, #-0x30]
    // 0xc11f80: stp             x0, x16, [SP]
    // 0xc11f84: ldur            x1, [fp, #-0x28]
    // 0xc11f88: r4 = const [0, 0x3, 0x2, 0x1, key, 0x1, showOnScreen, 0x2, null]
    //     0xc11f88: add             x4, PP, #0x98, lsl #12  ; [pp+0x988b8] List(9) [0, 0x3, 0x2, 0x1, "key", 0x1, "showOnScreen", 0x2, Null]
    //     0xc11f8c: ldr             x4, [x4, #0x8b8]
    // 0xc11f90: r0 = SemanticsNode()
    //     0xc11f90: bl              #0x893ce8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0xc11f94: ldur            x4, [fp, #-0x28]
    // 0xc11f98: ldur            x0, [fp, #-0x40]
    // 0xc11f9c: ldur            x3, [fp, #-0x48]
    // 0xc11fa0: mov             x1, x4
    // 0xc11fa4: ldur            x2, [fp, #-0xc0]
    // 0xc11fa8: stur            x4, [fp, #-0x28]
    // 0xc11fac: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc11fac: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc11fb0: r0 = updateWith()
    //     0xc11fb0: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc11fb4: ldur            x1, [fp, #-0x28]
    // 0xc11fb8: ldur            x2, [fp, #-0xa0]
    // 0xc11fbc: r0 = rect=()
    //     0xc11fbc: bl              #0x892bd8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0xc11fc0: ldur            x4, [fp, #-0x28]
    // 0xc11fc4: LoadField: r2 = r4->field_7
    //     0xc11fc4: ldur            w2, [x4, #7]
    // 0xc11fc8: DecompressPointer r2
    //     0xc11fc8: add             x2, x2, HEAP, lsl #32
    // 0xc11fcc: cmp             w2, NULL
    // 0xc11fd0: b.eq            #0xc121a4
    // 0xc11fd4: ldur            x5, [fp, #-0x48]
    // 0xc11fd8: r0 = LoadClassIdInstr(r5)
    //     0xc11fd8: ldur            x0, [x5, #-1]
    //     0xc11fdc: ubfx            x0, x0, #0xc, #0x14
    // 0xc11fe0: mov             x1, x5
    // 0xc11fe4: mov             x3, x4
    // 0xc11fe8: r0 = GDT[cid_x0 + -0xd50]()
    //     0xc11fe8: sub             lr, x0, #0xd50
    //     0xc11fec: ldr             lr, [x21, lr, lsl #3]
    //     0xc11ff0: blr             lr
    // 0xc11ff4: ldur            x0, [fp, #-0x40]
    // 0xc11ff8: LoadField: r1 = r0->field_b
    //     0xc11ff8: ldur            w1, [x0, #0xb]
    // 0xc11ffc: LoadField: r2 = r0->field_f
    //     0xc11ffc: ldur            w2, [x0, #0xf]
    // 0xc12000: DecompressPointer r2
    //     0xc12000: add             x2, x2, HEAP, lsl #32
    // 0xc12004: LoadField: r3 = r2->field_b
    //     0xc12004: ldur            w3, [x2, #0xb]
    // 0xc12008: r2 = LoadInt32Instr(r1)
    //     0xc12008: sbfx            x2, x1, #1, #0x1f
    // 0xc1200c: stur            x2, [fp, #-0x68]
    // 0xc12010: r1 = LoadInt32Instr(r3)
    //     0xc12010: sbfx            x1, x3, #1, #0x1f
    // 0xc12014: cmp             x2, x1
    // 0xc12018: b.ne            #0xc12024
    // 0xc1201c: mov             x1, x0
    // 0xc12020: r0 = _growToNextCapacity()
    //     0xc12020: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc12024: ldur            x2, [fp, #-0x40]
    // 0xc12028: ldur            x3, [fp, #-0x68]
    // 0xc1202c: add             x0, x3, #1
    // 0xc12030: lsl             x1, x0, #1
    // 0xc12034: StoreField: r2->field_b = r1
    //     0xc12034: stur            w1, [x2, #0xb]
    // 0xc12038: LoadField: r1 = r2->field_f
    //     0xc12038: ldur            w1, [x2, #0xf]
    // 0xc1203c: DecompressPointer r1
    //     0xc1203c: add             x1, x1, HEAP, lsl #32
    // 0xc12040: ldur            x0, [fp, #-0x28]
    // 0xc12044: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc12044: add             x25, x1, x3, lsl #2
    //     0xc12048: add             x25, x25, #0xf
    //     0xc1204c: str             w0, [x25]
    //     0xc12050: tbz             w0, #0, #0xc1206c
    //     0xc12054: ldurb           w16, [x1, #-1]
    //     0xc12058: ldurb           w17, [x0, #-1]
    //     0xc1205c: and             x16, x17, x16, lsr #2
    //     0xc12060: tst             x16, HEAP, lsr #32
    //     0xc12064: b.eq            #0xc1206c
    //     0xc12068: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc1206c: ldur            x4, [fp, #-0xa8]
    // 0xc12070: ldur            d0, [fp, #-0xf0]
    // 0xc12074: ldur            x3, [fp, #-0x70]
    // 0xc12078: ldur            x1, [fp, #-0x78]
    // 0xc1207c: ldur            x0, [fp, #-0x80]
    // 0xc12080: mov             x12, x4
    // 0xc12084: mov             x10, x3
    // 0xc12088: mov             x9, x1
    // 0xc1208c: mov             x8, x0
    // 0xc12090: ldur            x11, [fp, #-0x50]
    // 0xc12094: ldur            x7, [fp, #-0x58]
    // 0xc12098: mov             x4, x2
    // 0xc1209c: ldur            x2, [fp, #-8]
    // 0xc120a0: ldur            x3, [fp, #-0x88]
    // 0xc120a4: ldur            x0, [fp, #-0x90]
    // 0xc120a8: b               #0xc113f4
    // 0xc120ac: mov             x1, x2
    // 0xc120b0: mov             x2, x4
    // 0xc120b4: ldur            x0, [fp, #-0x48]
    // 0xc120b8: r17 = 275
    //     0xc120b8: mov             x17, #0x113
    // 0xc120bc: str             w0, [x1, x17]
    // 0xc120c0: WriteBarrierInstr(obj = r1, val = r0)
    //     0xc120c0: ldurb           w16, [x1, #-1]
    //     0xc120c4: ldurb           w17, [x0, #-1]
    //     0xc120c8: and             x16, x17, x16, lsr #2
    //     0xc120cc: tst             x16, HEAP, lsr #32
    //     0xc120d0: b.eq            #0xc120d8
    //     0xc120d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc120d8: str             x2, [SP]
    // 0xc120dc: ldur            x1, [fp, #-0x10]
    // 0xc120e0: ldur            x2, [fp, #-0x18]
    // 0xc120e4: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xc120e4: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xc120e8: r0 = updateWith()
    //     0xc120e8: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc120ec: r0 = Null
    //     0xc120ec: mov             x0, NULL
    // 0xc120f0: LeaveFrame
    //     0xc120f0: mov             SP, fp
    //     0xc120f4: ldp             fp, lr, [SP], #0x10
    // 0xc120f8: ret
    //     0xc120f8: ret             
    // 0xc120fc: r0 = noElement()
    //     0xc120fc: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0xc12100: r0 = Throw()
    //     0xc12100: bl              #0x13ddb2c  ; ThrowStub
    // 0xc12104: brk             #0
    // 0xc12108: r0 = StateError()
    //     0xc12108: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc1210c: mov             x1, x0
    // 0xc12110: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xc12110: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xc12114: StoreField: r1->field_b = r0
    //     0xc12114: stur            w0, [x1, #0xb]
    // 0xc12118: mov             x0, x1
    // 0xc1211c: r0 = Throw()
    //     0xc1211c: bl              #0x13ddb2c  ; ThrowStub
    // 0xc12120: brk             #0
    // 0xc12124: ldur            x0, [fp, #-0x98]
    // 0xc12128: r0 = ConcurrentModificationError()
    //     0xc12128: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc1212c: mov             x1, x0
    // 0xc12130: ldur            x0, [fp, #-0x98]
    // 0xc12134: StoreField: r1->field_b = r0
    //     0xc12134: stur            w0, [x1, #0xb]
    // 0xc12138: mov             x0, x1
    // 0xc1213c: r0 = Throw()
    //     0xc1213c: bl              #0x13ddb2c  ; ThrowStub
    // 0xc12140: brk             #0
    // 0xc12144: r0 = ConcurrentModificationError()
    //     0xc12144: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc12148: mov             x1, x0
    // 0xc1214c: ldur            x0, [fp, #-0x90]
    // 0xc12150: StoreField: r1->field_b = r0
    //     0xc12150: stur            w0, [x1, #0xb]
    // 0xc12154: mov             x0, x1
    // 0xc12158: r0 = Throw()
    //     0xc12158: bl              #0x13ddb2c  ; ThrowStub
    // 0xc1215c: brk             #0
    // 0xc12160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12160: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc12164: b               #0xc11304
    // 0xc12168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc12168: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1216c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1216c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc12170: r0 = StackOverflowSharedWithFPURegs()
    //     0xc12170: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc12174: b               #0xc11424
    // 0xc12178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12178: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1217c: b               #0xc1151c
    // 0xc12180: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc12180: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc12184: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc12184: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc12188: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc12188: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1218c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1218c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc12190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc12190: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc12194: r0 = StackOverflowSharedWithFPURegs()
    //     0xc12194: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc12198: b               #0xc118ec
    // 0xc1219c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1219c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc121a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc121a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc121a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc121a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc121b4, size: 0xc4
    // 0xc121b4: EnterFrame
    //     0xc121b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc121b8: mov             fp, SP
    // 0xc121bc: AllocStack(0x20)
    //     0xc121bc: sub             SP, SP, #0x20
    // 0xc121c0: SetupParameters([dynamic _ /* r0 */])
    //     0xc121c0: ldr             x0, [fp, #0x10]
    //     0xc121c4: ldur            w3, [x0, #0x17]
    //     0xc121c8: add             x3, x3, HEAP, lsl #32
    //     0xc121cc: stur            x3, [fp, #-0x10]
    // 0xc121d0: CheckStackOverflow
    //     0xc121d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc121d4: cmp             SP, x16
    //     0xc121d8: b.ls            #0xc12268
    // 0xc121dc: LoadField: r0 = r3->field_f
    //     0xc121dc: ldur            w0, [x3, #0xf]
    // 0xc121e0: DecompressPointer r0
    //     0xc121e0: add             x0, x0, HEAP, lsl #32
    // 0xc121e4: r17 = 275
    //     0xc121e4: mov             x17, #0x113
    // 0xc121e8: ldr             w4, [x0, x17]
    // 0xc121ec: DecompressPointer r4
    //     0xc121ec: add             x4, x4, HEAP, lsl #32
    // 0xc121f0: stur            x4, [fp, #-8]
    // 0xc121f4: cmp             w4, NULL
    // 0xc121f8: b.eq            #0xc12270
    // 0xc121fc: LoadField: r2 = r3->field_13
    //     0xc121fc: ldur            w2, [x3, #0x13]
    // 0xc12200: DecompressPointer r2
    //     0xc12200: add             x2, x2, HEAP, lsl #32
    // 0xc12204: mov             x1, x4
    // 0xc12208: r0 = _getValueOrData()
    //     0xc12208: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc1220c: mov             x1, x0
    // 0xc12210: ldur            x0, [fp, #-8]
    // 0xc12214: LoadField: r2 = r0->field_f
    //     0xc12214: ldur            w2, [x0, #0xf]
    // 0xc12218: DecompressPointer r2
    //     0xc12218: add             x2, x2, HEAP, lsl #32
    // 0xc1221c: cmp             w2, w1
    // 0xc12220: b.ne            #0xc12228
    // 0xc12224: r1 = Null
    //     0xc12224: mov             x1, NULL
    // 0xc12228: ldur            x0, [fp, #-0x10]
    // 0xc1222c: cmp             w1, NULL
    // 0xc12230: b.eq            #0xc12274
    // 0xc12234: LoadField: r2 = r0->field_f
    //     0xc12234: ldur            w2, [x0, #0xf]
    // 0xc12238: DecompressPointer r2
    //     0xc12238: add             x2, x2, HEAP, lsl #32
    // 0xc1223c: LoadField: r0 = r1->field_1f
    //     0xc1223c: ldur            w0, [x1, #0x1f]
    // 0xc12240: DecompressPointer r0
    //     0xc12240: add             x0, x0, HEAP, lsl #32
    // 0xc12244: stp             x0, x2, [SP]
    // 0xc12248: mov             x1, x2
    // 0xc1224c: r4 = const [0, 0x3, 0x2, 0x1, descendant, 0x1, rect, 0x2, null]
    //     0xc1224c: add             x4, PP, #0x98, lsl #12  ; [pp+0x988c0] List(9) [0, 0x3, 0x2, 0x1, "descendant", 0x1, "rect", 0x2, Null]
    //     0xc12250: ldr             x4, [x4, #0x8c0]
    // 0xc12254: r0 = showOnScreen()
    //     0xc12254: bl              #0xbee008  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0xc12258: r0 = Null
    //     0xc12258: mov             x0, NULL
    // 0xc1225c: LeaveFrame
    //     0xc1225c: mov             SP, fp
    //     0xc12260: ldp             fp, lr, [SP], #0x10
    // 0xc12264: ret
    //     0xc12264: ret             
    // 0xc12268: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12268: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1226c: b               #0xc121dc
    // 0xc12270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc12270: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc12274: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc12274: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc227f8, size: 0x168
    // 0xc227f8: EnterFrame
    //     0xc227f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc227fc: mov             fp, SP
    // 0xc22800: AllocStack(0x48)
    //     0xc22800: sub             SP, SP, #0x48
    // 0xc22804: SetupParameters(RenderEditable this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc22804: mov             x0, x2
    //     0xc22808: stur            x2, [fp, #-0x10]
    //     0xc2280c: mov             x2, x1
    //     0xc22810: stur            x1, [fp, #-8]
    //     0xc22814: stur            x3, [fp, #-0x18]
    // 0xc22818: CheckStackOverflow
    //     0xc22818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2281c: cmp             SP, x16
    //     0xc22820: b.ls            #0xc22950
    // 0xc22824: mov             x1, x2
    // 0xc22828: r0 = _computeTextMetricsIfNeeded()
    //     0xc22828: bl              #0x86004c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_computeTextMetricsIfNeeded
    // 0xc2282c: ldur            x1, [fp, #-8]
    // 0xc22830: r0 = _hasVisualOverflow()
    //     0xc22830: bl              #0xc235bc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_hasVisualOverflow
    // 0xc22834: tbnz            w0, #4, #0xc228e0
    // 0xc22838: ldur            x0, [fp, #-8]
    // 0xc2283c: r17 = 343
    //     0xc2283c: mov             x17, #0x157
    // 0xc22840: ldr             w2, [x0, x17]
    // 0xc22844: DecompressPointer r2
    //     0xc22844: add             x2, x2, HEAP, lsl #32
    // 0xc22848: stur            x2, [fp, #-0x28]
    // 0xc2284c: LoadField: r3 = r0->field_37
    //     0xc2284c: ldur            w3, [x0, #0x37]
    // 0xc22850: DecompressPointer r3
    //     0xc22850: add             x3, x3, HEAP, lsl #32
    // 0xc22854: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc22858: cmp             w3, w16
    // 0xc2285c: b.eq            #0xc22958
    // 0xc22860: mov             x1, x0
    // 0xc22864: stur            x3, [fp, #-0x20]
    // 0xc22868: r0 = size()
    //     0xc22868: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2286c: mov             x2, x0
    // 0xc22870: r1 = Instance_Offset
    //     0xc22870: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc22874: r0 = &()
    //     0xc22874: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc22878: mov             x3, x0
    // 0xc2287c: ldur            x0, [fp, #-0x28]
    // 0xc22880: stur            x3, [fp, #-0x38]
    // 0xc22884: LoadField: r4 = r0->field_b
    //     0xc22884: ldur            w4, [x0, #0xb]
    // 0xc22888: DecompressPointer r4
    //     0xc22888: add             x4, x4, HEAP, lsl #32
    // 0xc2288c: ldur            x2, [fp, #-8]
    // 0xc22890: stur            x4, [fp, #-0x30]
    // 0xc22894: r1 = Function '_paintContents@80245603':.
    //     0xc22894: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd5b8] AnonymousClosure: (0xc23624), in [package:flutter/src/rendering/editable.dart] RenderEditable::_paintContents (0xc22d14)
    //     0xc22898: ldr             x1, [x1, #0x5b8]
    // 0xc2289c: r0 = AllocateClosure()
    //     0xc2289c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc228a0: r16 = Instance_Clip
    //     0xc228a0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xc228a4: ldr             x16, [x16, #0x850]
    // 0xc228a8: ldur            lr, [fp, #-0x30]
    // 0xc228ac: stp             lr, x16, [SP]
    // 0xc228b0: ldur            x1, [fp, #-0x10]
    // 0xc228b4: ldur            x2, [fp, #-0x20]
    // 0xc228b8: ldur            x3, [fp, #-0x18]
    // 0xc228bc: ldur            x5, [fp, #-0x38]
    // 0xc228c0: mov             x6, x0
    // 0xc228c4: r4 = const [0, 0x7, 0x2, 0x5, clipBehavior, 0x5, oldLayer, 0x6, null]
    //     0xc228c4: add             x4, PP, #0x90, lsl #12  ; [pp+0x90688] List(9) [0, 0x7, 0x2, 0x5, "clipBehavior", 0x5, "oldLayer", 0x6, Null]
    //     0xc228c8: ldr             x4, [x4, #0x688]
    // 0xc228cc: r0 = pushClipRect()
    //     0xc228cc: bl              #0xc19194  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0xc228d0: ldur            x1, [fp, #-0x28]
    // 0xc228d4: mov             x2, x0
    // 0xc228d8: r0 = layer=()
    //     0xc228d8: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc228dc: b               #0xc22908
    // 0xc228e0: ldur            x0, [fp, #-8]
    // 0xc228e4: r17 = 343
    //     0xc228e4: mov             x17, #0x157
    // 0xc228e8: ldr             w1, [x0, x17]
    // 0xc228ec: DecompressPointer r1
    //     0xc228ec: add             x1, x1, HEAP, lsl #32
    // 0xc228f0: r2 = Null
    //     0xc228f0: mov             x2, NULL
    // 0xc228f4: r0 = layer=()
    //     0xc228f4: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc228f8: ldur            x1, [fp, #-8]
    // 0xc228fc: ldur            x2, [fp, #-0x10]
    // 0xc22900: ldur            x3, [fp, #-0x18]
    // 0xc22904: r0 = _paintContents()
    //     0xc22904: bl              #0xc22d14  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintContents
    // 0xc22908: ldur            x0, [fp, #-8]
    // 0xc2290c: LoadField: r2 = r0->field_d7
    //     0xc2290c: ldur            w2, [x0, #0xd7]
    // 0xc22910: DecompressPointer r2
    //     0xc22910: add             x2, x2, HEAP, lsl #32
    // 0xc22914: LoadField: r1 = r2->field_7
    //     0xc22914: ldur            x1, [x2, #7]
    // 0xc22918: tbnz            x1, #0x3f, #0xc22940
    // 0xc2291c: LoadField: r1 = r2->field_f
    //     0xc2291c: ldur            x1, [x2, #0xf]
    // 0xc22920: tbnz            x1, #0x3f, #0xc22940
    // 0xc22924: mov             x1, x0
    // 0xc22928: r0 = getEndpointsForSelection()
    //     0xc22928: bl              #0x8597dc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::getEndpointsForSelection
    // 0xc2292c: ldur            x1, [fp, #-8]
    // 0xc22930: ldur            x2, [fp, #-0x10]
    // 0xc22934: mov             x3, x0
    // 0xc22938: ldur            x5, [fp, #-0x18]
    // 0xc2293c: r0 = _paintHandleLayers()
    //     0xc2293c: bl              #0xc22960  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintHandleLayers
    // 0xc22940: r0 = Null
    //     0xc22940: mov             x0, NULL
    // 0xc22944: LeaveFrame
    //     0xc22944: mov             SP, fp
    //     0xc22948: ldp             fp, lr, [SP], #0x10
    // 0xc2294c: ret
    //     0xc2294c: ret             
    // 0xc22950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc22950: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc22954: b               #0xc22824
    // 0xc22958: r9 = _needsCompositing
    //     0xc22958: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc2295c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc2295c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _paintHandleLayers(/* No info */) {
    // ** addr: 0xc22960, size: 0x3b4
    // 0xc22960: EnterFrame
    //     0xc22960: stp             fp, lr, [SP, #-0x10]!
    //     0xc22964: mov             fp, SP
    // 0xc22968: AllocStack(0x58)
    //     0xc22968: sub             SP, SP, #0x58
    // 0xc2296c: SetupParameters(RenderEditable this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r2, fp-0x28 */)
    //     0xc2296c: mov             x4, x2
    //     0xc22970: stur            x2, [fp, #-0x18]
    //     0xc22974: mov             x2, x5
    //     0xc22978: stur            x5, [fp, #-0x28]
    //     0xc2297c: mov             x5, x1
    //     0xc22980: stur            x1, [fp, #-0x10]
    //     0xc22984: stur            x3, [fp, #-0x20]
    // 0xc22988: CheckStackOverflow
    //     0xc22988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2298c: cmp             SP, x16
    //     0xc22990: b.ls            #0xc22d00
    // 0xc22994: LoadField: r0 = r3->field_b
    //     0xc22994: ldur            w0, [x3, #0xb]
    // 0xc22998: r1 = LoadInt32Instr(r0)
    //     0xc22998: sbfx            x1, x0, #1, #0x1f
    // 0xc2299c: mov             x0, x1
    // 0xc229a0: r1 = 0
    //     0xc229a0: mov             x1, #0
    // 0xc229a4: cmp             x1, x0
    // 0xc229a8: b.hs            #0xc22d08
    // 0xc229ac: LoadField: r0 = r3->field_f
    //     0xc229ac: ldur            w0, [x3, #0xf]
    // 0xc229b0: DecompressPointer r0
    //     0xc229b0: add             x0, x0, HEAP, lsl #32
    // 0xc229b4: LoadField: r1 = r0->field_f
    //     0xc229b4: ldur            w1, [x0, #0xf]
    // 0xc229b8: DecompressPointer r1
    //     0xc229b8: add             x1, x1, HEAP, lsl #32
    // 0xc229bc: LoadField: r0 = r1->field_7
    //     0xc229bc: ldur            w0, [x1, #7]
    // 0xc229c0: DecompressPointer r0
    //     0xc229c0: add             x0, x0, HEAP, lsl #32
    // 0xc229c4: stur            x0, [fp, #-8]
    // 0xc229c8: LoadField: d0 = r0->field_7
    //     0xc229c8: ldur            d0, [x0, #7]
    // 0xc229cc: mov             x1, x5
    // 0xc229d0: stur            d0, [fp, #-0x50]
    // 0xc229d4: r0 = size()
    //     0xc229d4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc229d8: LoadField: d0 = r0->field_7
    //     0xc229d8: ldur            d0, [x0, #7]
    // 0xc229dc: ldur            d2, [fp, #-0x50]
    // 0xc229e0: d1 = 0.000000
    //     0xc229e0: eor             v1.16b, v1.16b, v1.16b
    // 0xc229e4: fcmp            d1, d2
    // 0xc229e8: b.le            #0xc229f4
    // 0xc229ec: d0 = 0.000000
    //     0xc229ec: eor             v0.16b, v0.16b, v0.16b
    // 0xc229f0: b               #0xc22a08
    // 0xc229f4: fcmp            d2, d0
    // 0xc229f8: b.gt            #0xc22a08
    // 0xc229fc: fcmp            d2, d2
    // 0xc22a00: b.vs            #0xc22a08
    // 0xc22a04: mov             v0.16b, v2.16b
    // 0xc22a08: ldur            x0, [fp, #-8]
    // 0xc22a0c: stur            d0, [fp, #-0x58]
    // 0xc22a10: LoadField: d2 = r0->field_f
    //     0xc22a10: ldur            d2, [x0, #0xf]
    // 0xc22a14: ldur            x1, [fp, #-0x10]
    // 0xc22a18: stur            d2, [fp, #-0x50]
    // 0xc22a1c: r0 = size()
    //     0xc22a1c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc22a20: LoadField: d0 = r0->field_f
    //     0xc22a20: ldur            d0, [x0, #0xf]
    // 0xc22a24: ldur            d2, [fp, #-0x50]
    // 0xc22a28: d1 = 0.000000
    //     0xc22a28: eor             v1.16b, v1.16b, v1.16b
    // 0xc22a2c: fcmp            d1, d2
    // 0xc22a30: b.le            #0xc22a3c
    // 0xc22a34: d2 = 0.000000
    //     0xc22a34: eor             v2.16b, v2.16b, v2.16b
    // 0xc22a38: b               #0xc22a58
    // 0xc22a3c: fcmp            d2, d0
    // 0xc22a40: b.le            #0xc22a4c
    // 0xc22a44: mov             v2.16b, v0.16b
    // 0xc22a48: b               #0xc22a58
    // 0xc22a4c: fcmp            d2, d2
    // 0xc22a50: b.vc            #0xc22a58
    // 0xc22a54: mov             v2.16b, v0.16b
    // 0xc22a58: ldur            x2, [fp, #-0x10]
    // 0xc22a5c: ldur            x0, [fp, #-0x20]
    // 0xc22a60: ldur            d0, [fp, #-0x58]
    // 0xc22a64: stur            d2, [fp, #-0x50]
    // 0xc22a68: r0 = Offset()
    //     0xc22a68: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc22a6c: ldur            d0, [fp, #-0x58]
    // 0xc22a70: stur            x0, [fp, #-0x38]
    // 0xc22a74: StoreField: r0->field_7 = d0
    //     0xc22a74: stur            d0, [x0, #7]
    // 0xc22a78: ldur            d0, [fp, #-0x50]
    // 0xc22a7c: StoreField: r0->field_f = d0
    //     0xc22a7c: stur            d0, [x0, #0xf]
    // 0xc22a80: ldur            x3, [fp, #-0x10]
    // 0xc22a84: r17 = 339
    //     0xc22a84: mov             x17, #0x153
    // 0xc22a88: ldr             w4, [x3, x17]
    // 0xc22a8c: DecompressPointer r4
    //     0xc22a8c: add             x4, x4, HEAP, lsl #32
    // 0xc22a90: stur            x4, [fp, #-0x30]
    // 0xc22a94: LoadField: r5 = r3->field_ef
    //     0xc22a94: ldur            w5, [x3, #0xef]
    // 0xc22a98: DecompressPointer r5
    //     0xc22a98: add             x5, x5, HEAP, lsl #32
    // 0xc22a9c: mov             x1, x0
    // 0xc22aa0: ldur            x2, [fp, #-0x28]
    // 0xc22aa4: stur            x5, [fp, #-8]
    // 0xc22aa8: r0 = +()
    //     0xc22aa8: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc22aac: stur            x0, [fp, #-0x40]
    // 0xc22ab0: r0 = LeaderLayer()
    //     0xc22ab0: bl              #0xc1d564  ; AllocateLeaderLayerStub -> LeaderLayer (size=0x50)
    // 0xc22ab4: mov             x2, x0
    // 0xc22ab8: ldur            x0, [fp, #-8]
    // 0xc22abc: stur            x2, [fp, #-0x48]
    // 0xc22ac0: StoreField: r2->field_47 = r0
    //     0xc22ac0: stur            w0, [x2, #0x47]
    // 0xc22ac4: ldur            x0, [fp, #-0x40]
    // 0xc22ac8: StoreField: r2->field_4b = r0
    //     0xc22ac8: stur            w0, [x2, #0x4b]
    // 0xc22acc: mov             x1, x2
    // 0xc22ad0: r0 = Layer()
    //     0xc22ad0: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc22ad4: ldur            x1, [fp, #-0x30]
    // 0xc22ad8: ldur            x2, [fp, #-0x48]
    // 0xc22adc: r0 = layer=()
    //     0xc22adc: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc22ae0: ldur            x0, [fp, #-0x30]
    // 0xc22ae4: LoadField: r3 = r0->field_b
    //     0xc22ae4: ldur            w3, [x0, #0xb]
    // 0xc22ae8: DecompressPointer r3
    //     0xc22ae8: add             x3, x3, HEAP, lsl #32
    // 0xc22aec: stur            x3, [fp, #-8]
    // 0xc22af0: cmp             w3, NULL
    // 0xc22af4: b.eq            #0xc22d0c
    // 0xc22af8: ldur            x2, [fp, #-0x10]
    // 0xc22afc: r1 = Function 'paint':.
    //     0xc22afc: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd5c0] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xc22b00: ldr             x1, [x1, #0x5c0]
    // 0xc22b04: r0 = AllocateClosure()
    //     0xc22b04: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc22b08: ldur            x1, [fp, #-0x18]
    // 0xc22b0c: ldur            x2, [fp, #-8]
    // 0xc22b10: mov             x3, x0
    // 0xc22b14: r5 = Instance_Offset
    //     0xc22b14: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc22b18: stur            x0, [fp, #-8]
    // 0xc22b1c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xc22b1c: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xc22b20: r0 = pushLayer()
    //     0xc22b20: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc22b24: ldur            x2, [fp, #-0x20]
    // 0xc22b28: LoadField: r0 = r2->field_b
    //     0xc22b28: ldur            w0, [x2, #0xb]
    // 0xc22b2c: r1 = LoadInt32Instr(r0)
    //     0xc22b2c: sbfx            x1, x0, #1, #0x1f
    // 0xc22b30: cmp             x1, #2
    // 0xc22b34: b.ne            #0xc22c7c
    // 0xc22b38: mov             x0, x1
    // 0xc22b3c: r1 = 1
    //     0xc22b3c: mov             x1, #1
    // 0xc22b40: cmp             x1, x0
    // 0xc22b44: b.hs            #0xc22d10
    // 0xc22b48: LoadField: r0 = r2->field_f
    //     0xc22b48: ldur            w0, [x2, #0xf]
    // 0xc22b4c: DecompressPointer r0
    //     0xc22b4c: add             x0, x0, HEAP, lsl #32
    // 0xc22b50: LoadField: r1 = r0->field_13
    //     0xc22b50: ldur            w1, [x0, #0x13]
    // 0xc22b54: DecompressPointer r1
    //     0xc22b54: add             x1, x1, HEAP, lsl #32
    // 0xc22b58: LoadField: r0 = r1->field_7
    //     0xc22b58: ldur            w0, [x1, #7]
    // 0xc22b5c: DecompressPointer r0
    //     0xc22b5c: add             x0, x0, HEAP, lsl #32
    // 0xc22b60: stur            x0, [fp, #-0x20]
    // 0xc22b64: LoadField: d0 = r0->field_7
    //     0xc22b64: ldur            d0, [x0, #7]
    // 0xc22b68: ldur            x1, [fp, #-0x10]
    // 0xc22b6c: stur            d0, [fp, #-0x50]
    // 0xc22b70: r0 = size()
    //     0xc22b70: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc22b74: LoadField: d0 = r0->field_7
    //     0xc22b74: ldur            d0, [x0, #7]
    // 0xc22b78: ldur            d2, [fp, #-0x50]
    // 0xc22b7c: d1 = 0.000000
    //     0xc22b7c: eor             v1.16b, v1.16b, v1.16b
    // 0xc22b80: fcmp            d1, d2
    // 0xc22b84: b.le            #0xc22b90
    // 0xc22b88: d0 = 0.000000
    //     0xc22b88: eor             v0.16b, v0.16b, v0.16b
    // 0xc22b8c: b               #0xc22ba4
    // 0xc22b90: fcmp            d2, d0
    // 0xc22b94: b.gt            #0xc22ba4
    // 0xc22b98: fcmp            d2, d2
    // 0xc22b9c: b.vs            #0xc22ba4
    // 0xc22ba0: mov             v0.16b, v2.16b
    // 0xc22ba4: ldur            x0, [fp, #-0x20]
    // 0xc22ba8: stur            d0, [fp, #-0x58]
    // 0xc22bac: LoadField: d2 = r0->field_f
    //     0xc22bac: ldur            d2, [x0, #0xf]
    // 0xc22bb0: ldur            x1, [fp, #-0x10]
    // 0xc22bb4: stur            d2, [fp, #-0x50]
    // 0xc22bb8: r0 = size()
    //     0xc22bb8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc22bbc: LoadField: d0 = r0->field_f
    //     0xc22bbc: ldur            d0, [x0, #0xf]
    // 0xc22bc0: ldur            d2, [fp, #-0x50]
    // 0xc22bc4: d1 = 0.000000
    //     0xc22bc4: eor             v1.16b, v1.16b, v1.16b
    // 0xc22bc8: fcmp            d1, d2
    // 0xc22bcc: b.le            #0xc22bd8
    // 0xc22bd0: d1 = 0.000000
    //     0xc22bd0: eor             v1.16b, v1.16b, v1.16b
    // 0xc22bd4: b               #0xc22bfc
    // 0xc22bd8: fcmp            d2, d0
    // 0xc22bdc: b.le            #0xc22be8
    // 0xc22be0: mov             v1.16b, v0.16b
    // 0xc22be4: b               #0xc22bfc
    // 0xc22be8: fcmp            d2, d2
    // 0xc22bec: b.vc            #0xc22bf8
    // 0xc22bf0: mov             v1.16b, v0.16b
    // 0xc22bf4: b               #0xc22bfc
    // 0xc22bf8: mov             v1.16b, v2.16b
    // 0xc22bfc: ldur            x0, [fp, #-0x10]
    // 0xc22c00: ldur            d0, [fp, #-0x58]
    // 0xc22c04: stur            d1, [fp, #-0x50]
    // 0xc22c08: r0 = Offset()
    //     0xc22c08: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc22c0c: ldur            d0, [fp, #-0x58]
    // 0xc22c10: StoreField: r0->field_7 = d0
    //     0xc22c10: stur            d0, [x0, #7]
    // 0xc22c14: ldur            d0, [fp, #-0x50]
    // 0xc22c18: StoreField: r0->field_f = d0
    //     0xc22c18: stur            d0, [x0, #0xf]
    // 0xc22c1c: ldur            x1, [fp, #-0x10]
    // 0xc22c20: LoadField: r3 = r1->field_f3
    //     0xc22c20: ldur            w3, [x1, #0xf3]
    // 0xc22c24: DecompressPointer r3
    //     0xc22c24: add             x3, x3, HEAP, lsl #32
    // 0xc22c28: mov             x1, x0
    // 0xc22c2c: ldur            x2, [fp, #-0x28]
    // 0xc22c30: stur            x3, [fp, #-0x20]
    // 0xc22c34: r0 = +()
    //     0xc22c34: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc22c38: stur            x0, [fp, #-0x30]
    // 0xc22c3c: r0 = LeaderLayer()
    //     0xc22c3c: bl              #0xc1d564  ; AllocateLeaderLayerStub -> LeaderLayer (size=0x50)
    // 0xc22c40: mov             x2, x0
    // 0xc22c44: ldur            x0, [fp, #-0x20]
    // 0xc22c48: stur            x2, [fp, #-0x40]
    // 0xc22c4c: StoreField: r2->field_47 = r0
    //     0xc22c4c: stur            w0, [x2, #0x47]
    // 0xc22c50: ldur            x0, [fp, #-0x30]
    // 0xc22c54: StoreField: r2->field_4b = r0
    //     0xc22c54: stur            w0, [x2, #0x4b]
    // 0xc22c58: mov             x1, x2
    // 0xc22c5c: r0 = Layer()
    //     0xc22c5c: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc22c60: ldur            x1, [fp, #-0x18]
    // 0xc22c64: ldur            x2, [fp, #-0x40]
    // 0xc22c68: ldur            x3, [fp, #-8]
    // 0xc22c6c: r5 = Instance_Offset
    //     0xc22c6c: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc22c70: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xc22c70: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xc22c74: r0 = pushLayer()
    //     0xc22c74: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc22c78: b               #0xc22cf0
    // 0xc22c7c: ldur            x1, [fp, #-0x10]
    // 0xc22c80: LoadField: r0 = r1->field_d7
    //     0xc22c80: ldur            w0, [x1, #0xd7]
    // 0xc22c84: DecompressPointer r0
    //     0xc22c84: add             x0, x0, HEAP, lsl #32
    // 0xc22c88: LoadField: r2 = r0->field_7
    //     0xc22c88: ldur            x2, [x0, #7]
    // 0xc22c8c: LoadField: r3 = r0->field_f
    //     0xc22c8c: ldur            x3, [x0, #0xf]
    // 0xc22c90: cmp             x2, x3
    // 0xc22c94: b.ne            #0xc22cf0
    // 0xc22c98: LoadField: r0 = r1->field_f3
    //     0xc22c98: ldur            w0, [x1, #0xf3]
    // 0xc22c9c: DecompressPointer r0
    //     0xc22c9c: add             x0, x0, HEAP, lsl #32
    // 0xc22ca0: ldur            x1, [fp, #-0x38]
    // 0xc22ca4: ldur            x2, [fp, #-0x28]
    // 0xc22ca8: stur            x0, [fp, #-0x20]
    // 0xc22cac: r0 = +()
    //     0xc22cac: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc22cb0: stur            x0, [fp, #-0x10]
    // 0xc22cb4: r0 = LeaderLayer()
    //     0xc22cb4: bl              #0xc1d564  ; AllocateLeaderLayerStub -> LeaderLayer (size=0x50)
    // 0xc22cb8: mov             x2, x0
    // 0xc22cbc: ldur            x0, [fp, #-0x20]
    // 0xc22cc0: stur            x2, [fp, #-0x28]
    // 0xc22cc4: StoreField: r2->field_47 = r0
    //     0xc22cc4: stur            w0, [x2, #0x47]
    // 0xc22cc8: ldur            x0, [fp, #-0x10]
    // 0xc22ccc: StoreField: r2->field_4b = r0
    //     0xc22ccc: stur            w0, [x2, #0x4b]
    // 0xc22cd0: mov             x1, x2
    // 0xc22cd4: r0 = Layer()
    //     0xc22cd4: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc22cd8: ldur            x1, [fp, #-0x18]
    // 0xc22cdc: ldur            x2, [fp, #-0x28]
    // 0xc22ce0: ldur            x3, [fp, #-8]
    // 0xc22ce4: r5 = Instance_Offset
    //     0xc22ce4: ldr             x5, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc22ce8: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xc22ce8: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xc22cec: r0 = pushLayer()
    //     0xc22cec: bl              #0xc18740  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0xc22cf0: r0 = Null
    //     0xc22cf0: mov             x0, NULL
    // 0xc22cf4: LeaveFrame
    //     0xc22cf4: mov             SP, fp
    //     0xc22cf8: ldp             fp, lr, [SP], #0x10
    // 0xc22cfc: ret
    //     0xc22cfc: ret             
    // 0xc22d00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc22d00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc22d04: b               #0xc22994
    // 0xc22d08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc22d08: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc22d0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc22d0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc22d10: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc22d10: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _paintContents(/* No info */) {
    // ** addr: 0xc22d14, size: 0x100
    // 0xc22d14: EnterFrame
    //     0xc22d14: stp             fp, lr, [SP, #-0x10]!
    //     0xc22d18: mov             fp, SP
    // 0xc22d1c: AllocStack(0x30)
    //     0xc22d1c: sub             SP, SP, #0x30
    // 0xc22d20: SetupParameters(RenderEditable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xc22d20: mov             x0, x3
    //     0xc22d24: stur            x3, [fp, #-0x18]
    //     0xc22d28: mov             x3, x1
    //     0xc22d2c: stur            x1, [fp, #-8]
    //     0xc22d30: stur            x2, [fp, #-0x10]
    // 0xc22d34: CheckStackOverflow
    //     0xc22d34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc22d38: cmp             SP, x16
    //     0xc22d3c: b.ls            #0xc22e0c
    // 0xc22d40: mov             x1, x3
    // 0xc22d44: r0 = _paintOffset()
    //     0xc22d44: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0xc22d48: ldur            x1, [fp, #-0x18]
    // 0xc22d4c: mov             x2, x0
    // 0xc22d50: r0 = +()
    //     0xc22d50: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc22d54: mov             x3, x0
    // 0xc22d58: ldur            x0, [fp, #-8]
    // 0xc22d5c: stur            x3, [fp, #-0x20]
    // 0xc22d60: LoadField: r1 = r0->field_fb
    //     0xc22d60: ldur            w1, [x0, #0xfb]
    // 0xc22d64: DecompressPointer r1
    //     0xc22d64: add             x1, x1, HEAP, lsl #32
    // 0xc22d68: eor             x2, x1, #0x10
    // 0xc22d6c: tbnz            w2, #4, #0xc22d7c
    // 0xc22d70: mov             x1, x0
    // 0xc22d74: mov             x2, x3
    // 0xc22d78: r0 = _updateSelectionExtentsVisibility()
    //     0xc22d78: bl              #0xc233b8  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_updateSelectionExtentsVisibility
    // 0xc22d7c: ldur            x0, [fp, #-8]
    // 0xc22d80: LoadField: r4 = r0->field_63
    //     0xc22d80: ldur            w4, [x0, #0x63]
    // 0xc22d84: DecompressPointer r4
    //     0xc22d84: add             x4, x4, HEAP, lsl #32
    // 0xc22d88: stur            x4, [fp, #-0x28]
    // 0xc22d8c: LoadField: r2 = r0->field_67
    //     0xc22d8c: ldur            w2, [x0, #0x67]
    // 0xc22d90: DecompressPointer r2
    //     0xc22d90: add             x2, x2, HEAP, lsl #32
    // 0xc22d94: cmp             w2, NULL
    // 0xc22d98: b.eq            #0xc22da8
    // 0xc22d9c: ldur            x1, [fp, #-0x10]
    // 0xc22da0: ldur            x3, [fp, #-0x18]
    // 0xc22da4: r0 = paintChild()
    //     0xc22da4: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc22da8: ldur            x0, [fp, #-8]
    // 0xc22dac: ldur            x2, [fp, #-0x28]
    // 0xc22db0: LoadField: r3 = r0->field_a7
    //     0xc22db0: ldur            w3, [x0, #0xa7]
    // 0xc22db4: DecompressPointer r3
    //     0xc22db4: add             x3, x3, HEAP, lsl #32
    // 0xc22db8: ldur            x1, [fp, #-0x10]
    // 0xc22dbc: stur            x3, [fp, #-0x30]
    // 0xc22dc0: r0 = canvas()
    //     0xc22dc0: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc22dc4: ldur            x1, [fp, #-0x30]
    // 0xc22dc8: mov             x2, x0
    // 0xc22dcc: ldur            x3, [fp, #-0x20]
    // 0xc22dd0: r0 = paint()
    //     0xc22dd0: bl              #0xc22fac  ; [package:flutter/src/painting/text_painter.dart] TextPainter::paint
    // 0xc22dd4: ldur            x1, [fp, #-8]
    // 0xc22dd8: ldur            x2, [fp, #-0x10]
    // 0xc22ddc: ldur            x3, [fp, #-0x20]
    // 0xc22de0: r0 = paintInlineChildren()
    //     0xc22de0: bl              #0xc22e14  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::paintInlineChildren
    // 0xc22de4: ldur            x2, [fp, #-0x28]
    // 0xc22de8: cmp             w2, NULL
    // 0xc22dec: b.eq            #0xc22dfc
    // 0xc22df0: ldur            x1, [fp, #-0x10]
    // 0xc22df4: ldur            x3, [fp, #-0x18]
    // 0xc22df8: r0 = paintChild()
    //     0xc22df8: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc22dfc: r0 = Null
    //     0xc22dfc: mov             x0, NULL
    // 0xc22e00: LeaveFrame
    //     0xc22e00: mov             SP, fp
    //     0xc22e04: ldp             fp, lr, [SP], #0x10
    // 0xc22e08: ret
    //     0xc22e08: ret             
    // 0xc22e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc22e0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc22e10: b               #0xc22d40
  }
  _ _updateSelectionExtentsVisibility(/* No info */) {
    // ** addr: 0xc233b8, size: 0x204
    // 0xc233b8: EnterFrame
    //     0xc233b8: stp             fp, lr, [SP, #-0x10]!
    //     0xc233bc: mov             fp, SP
    // 0xc233c0: AllocStack(0x38)
    //     0xc233c0: sub             SP, SP, #0x38
    // 0xc233c4: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xc233c4: mov             x0, x1
    //     0xc233c8: stur            x1, [fp, #-8]
    //     0xc233cc: stur            x2, [fp, #-0x10]
    // 0xc233d0: CheckStackOverflow
    //     0xc233d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc233d4: cmp             SP, x16
    //     0xc233d8: b.ls            #0xc235ac
    // 0xc233dc: LoadField: r1 = r0->field_d7
    //     0xc233dc: ldur            w1, [x0, #0xd7]
    // 0xc233e0: DecompressPointer r1
    //     0xc233e0: add             x1, x1, HEAP, lsl #32
    // 0xc233e4: LoadField: r3 = r1->field_7
    //     0xc233e4: ldur            x3, [x1, #7]
    // 0xc233e8: tbnz            x3, #0x3f, #0xc23578
    // 0xc233ec: LoadField: r3 = r1->field_f
    //     0xc233ec: ldur            x3, [x1, #0xf]
    // 0xc233f0: tbnz            x3, #0x3f, #0xc23578
    // 0xc233f4: mov             x1, x0
    // 0xc233f8: r0 = size()
    //     0xc233f8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc233fc: mov             x2, x0
    // 0xc23400: r1 = Instance_Offset
    //     0xc23400: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc23404: r0 = &()
    //     0xc23404: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc23408: mov             x1, x0
    // 0xc2340c: ldur            x0, [fp, #-8]
    // 0xc23410: stur            x1, [fp, #-0x30]
    // 0xc23414: LoadField: r2 = r0->field_a7
    //     0xc23414: ldur            w2, [x0, #0xa7]
    // 0xc23418: DecompressPointer r2
    //     0xc23418: add             x2, x2, HEAP, lsl #32
    // 0xc2341c: stur            x2, [fp, #-0x28]
    // 0xc23420: LoadField: r3 = r0->field_d7
    //     0xc23420: ldur            w3, [x0, #0xd7]
    // 0xc23424: DecompressPointer r3
    //     0xc23424: add             x3, x3, HEAP, lsl #32
    // 0xc23428: LoadField: r4 = r3->field_7
    //     0xc23428: ldur            x4, [x3, #7]
    // 0xc2342c: stur            x4, [fp, #-0x20]
    // 0xc23430: LoadField: r5 = r3->field_27
    //     0xc23430: ldur            w5, [x3, #0x27]
    // 0xc23434: DecompressPointer r5
    //     0xc23434: add             x5, x5, HEAP, lsl #32
    // 0xc23438: stur            x5, [fp, #-0x18]
    // 0xc2343c: r0 = TextPosition()
    //     0xc2343c: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0xc23440: mov             x1, x0
    // 0xc23444: ldur            x0, [fp, #-0x20]
    // 0xc23448: StoreField: r1->field_7 = r0
    //     0xc23448: stur            x0, [x1, #7]
    // 0xc2344c: ldur            x0, [fp, #-0x18]
    // 0xc23450: StoreField: r1->field_f = r0
    //     0xc23450: stur            w0, [x1, #0xf]
    // 0xc23454: ldur            x0, [fp, #-8]
    // 0xc23458: r17 = 303
    //     0xc23458: mov             x17, #0x12f
    // 0xc2345c: ldr             w3, [x0, x17]
    // 0xc23460: DecompressPointer r3
    //     0xc23460: add             x3, x3, HEAP, lsl #32
    // 0xc23464: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc23468: cmp             w3, w16
    // 0xc2346c: b.eq            #0xc235b4
    // 0xc23470: mov             x2, x1
    // 0xc23474: ldur            x1, [fp, #-0x28]
    // 0xc23478: r0 = getOffsetForCaret()
    //     0xc23478: bl              #0x85dc3c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetForCaret
    // 0xc2347c: mov             x2, x0
    // 0xc23480: ldur            x0, [fp, #-8]
    // 0xc23484: stur            x2, [fp, #-0x38]
    // 0xc23488: LoadField: r3 = r0->field_9f
    //     0xc23488: ldur            w3, [x0, #0x9f]
    // 0xc2348c: DecompressPointer r3
    //     0xc2348c: add             x3, x3, HEAP, lsl #32
    // 0xc23490: ldur            x1, [fp, #-0x30]
    // 0xc23494: stur            x3, [fp, #-0x18]
    // 0xc23498: d0 = 0.500000
    //     0xc23498: fmov            d0, #0.50000000
    // 0xc2349c: r0 = inflate()
    //     0xc2349c: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0xc234a0: ldur            x1, [fp, #-0x38]
    // 0xc234a4: ldur            x2, [fp, #-0x10]
    // 0xc234a8: stur            x0, [fp, #-0x38]
    // 0xc234ac: r0 = +()
    //     0xc234ac: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc234b0: ldur            x1, [fp, #-0x38]
    // 0xc234b4: mov             x2, x0
    // 0xc234b8: r0 = contains()
    //     0xc234b8: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0xc234bc: ldur            x1, [fp, #-0x18]
    // 0xc234c0: mov             x2, x0
    // 0xc234c4: r0 = value=()
    //     0xc234c4: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xc234c8: ldur            x0, [fp, #-8]
    // 0xc234cc: LoadField: r1 = r0->field_d7
    //     0xc234cc: ldur            w1, [x0, #0xd7]
    // 0xc234d0: DecompressPointer r1
    //     0xc234d0: add             x1, x1, HEAP, lsl #32
    // 0xc234d4: LoadField: r2 = r1->field_f
    //     0xc234d4: ldur            x2, [x1, #0xf]
    // 0xc234d8: stur            x2, [fp, #-0x20]
    // 0xc234dc: LoadField: r3 = r1->field_27
    //     0xc234dc: ldur            w3, [x1, #0x27]
    // 0xc234e0: DecompressPointer r3
    //     0xc234e0: add             x3, x3, HEAP, lsl #32
    // 0xc234e4: stur            x3, [fp, #-0x18]
    // 0xc234e8: r0 = TextPosition()
    //     0xc234e8: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0xc234ec: mov             x1, x0
    // 0xc234f0: ldur            x0, [fp, #-0x20]
    // 0xc234f4: StoreField: r1->field_7 = r0
    //     0xc234f4: stur            x0, [x1, #7]
    // 0xc234f8: ldur            x0, [fp, #-0x18]
    // 0xc234fc: StoreField: r1->field_f = r0
    //     0xc234fc: stur            w0, [x1, #0xf]
    // 0xc23500: ldur            x0, [fp, #-8]
    // 0xc23504: r17 = 303
    //     0xc23504: mov             x17, #0x12f
    // 0xc23508: ldr             w3, [x0, x17]
    // 0xc2350c: DecompressPointer r3
    //     0xc2350c: add             x3, x3, HEAP, lsl #32
    // 0xc23510: mov             x2, x1
    // 0xc23514: ldur            x1, [fp, #-0x28]
    // 0xc23518: r0 = getOffsetForCaret()
    //     0xc23518: bl              #0x85dc3c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetForCaret
    // 0xc2351c: mov             x2, x0
    // 0xc23520: ldur            x0, [fp, #-8]
    // 0xc23524: stur            x2, [fp, #-0x28]
    // 0xc23528: LoadField: r3 = r0->field_a3
    //     0xc23528: ldur            w3, [x0, #0xa3]
    // 0xc2352c: DecompressPointer r3
    //     0xc2352c: add             x3, x3, HEAP, lsl #32
    // 0xc23530: ldur            x1, [fp, #-0x30]
    // 0xc23534: stur            x3, [fp, #-0x18]
    // 0xc23538: d0 = 0.500000
    //     0xc23538: fmov            d0, #0.50000000
    // 0xc2353c: r0 = inflate()
    //     0xc2353c: bl              #0x882f50  ; [dart:ui] Rect::inflate
    // 0xc23540: ldur            x1, [fp, #-0x28]
    // 0xc23544: ldur            x2, [fp, #-0x10]
    // 0xc23548: stur            x0, [fp, #-0x10]
    // 0xc2354c: r0 = +()
    //     0xc2354c: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc23550: ldur            x1, [fp, #-0x10]
    // 0xc23554: mov             x2, x0
    // 0xc23558: r0 = contains()
    //     0xc23558: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0xc2355c: ldur            x1, [fp, #-0x18]
    // 0xc23560: mov             x2, x0
    // 0xc23564: r0 = value=()
    //     0xc23564: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xc23568: r0 = Null
    //     0xc23568: mov             x0, NULL
    // 0xc2356c: LeaveFrame
    //     0xc2356c: mov             SP, fp
    //     0xc23570: ldp             fp, lr, [SP], #0x10
    // 0xc23574: ret
    //     0xc23574: ret             
    // 0xc23578: LoadField: r1 = r0->field_9f
    //     0xc23578: ldur            w1, [x0, #0x9f]
    // 0xc2357c: DecompressPointer r1
    //     0xc2357c: add             x1, x1, HEAP, lsl #32
    // 0xc23580: r2 = false
    //     0xc23580: add             x2, NULL, #0x30  ; false
    // 0xc23584: r0 = value=()
    //     0xc23584: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xc23588: ldur            x0, [fp, #-8]
    // 0xc2358c: LoadField: r1 = r0->field_a3
    //     0xc2358c: ldur            w1, [x0, #0xa3]
    // 0xc23590: DecompressPointer r1
    //     0xc23590: add             x1, x1, HEAP, lsl #32
    // 0xc23594: r2 = false
    //     0xc23594: add             x2, NULL, #0x30  ; false
    // 0xc23598: r0 = value=()
    //     0xc23598: bl              #0xb68ce8  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0xc2359c: r0 = Null
    //     0xc2359c: mov             x0, NULL
    // 0xc235a0: LeaveFrame
    //     0xc235a0: mov             SP, fp
    //     0xc235a4: ldp             fp, lr, [SP], #0x10
    // 0xc235a8: ret
    //     0xc235a8: ret             
    // 0xc235ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc235ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc235b0: b               #0xc233dc
    // 0xc235b4: r9 = _caretPrototype
    //     0xc235b4: ldr             x9, [PP, #0x49b0]  ; [pp+0x49b0] Field <RenderEditable._caretPrototype@80245603>: late (offset: 0x130)
    // 0xc235b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc235b8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _hasVisualOverflow(/* No info */) {
    // ** addr: 0xc235bc, size: 0x68
    // 0xc235bc: EnterFrame
    //     0xc235bc: stp             fp, lr, [SP, #-0x10]!
    //     0xc235c0: mov             fp, SP
    // 0xc235c4: AllocStack(0x10)
    //     0xc235c4: sub             SP, SP, #0x10
    // 0xc235c8: d0 = 0.000000
    //     0xc235c8: eor             v0.16b, v0.16b, v0.16b
    // 0xc235cc: CheckStackOverflow
    //     0xc235cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc235d0: cmp             SP, x16
    //     0xc235d4: b.ls            #0xc2361c
    // 0xc235d8: r17 = 263
    //     0xc235d8: mov             x17, #0x107
    // 0xc235dc: ldr             w0, [x1, x17]
    // 0xc235e0: DecompressPointer r0
    //     0xc235e0: add             x0, x0, HEAP, lsl #32
    // 0xc235e4: LoadField: d1 = r0->field_7
    //     0xc235e4: ldur            d1, [x0, #7]
    // 0xc235e8: fcmp            d1, d0
    // 0xc235ec: b.le            #0xc235f8
    // 0xc235f0: r0 = true
    //     0xc235f0: add             x0, NULL, #0x20  ; true
    // 0xc235f4: b               #0xc23610
    // 0xc235f8: r0 = _paintOffset()
    //     0xc235f8: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0xc235fc: r16 = Instance_Offset
    //     0xc235fc: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc23600: stp             x16, x0, [SP]
    // 0xc23604: r0 = ==()
    //     0xc23604: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xc23608: eor             x1, x0, #0x10
    // 0xc2360c: mov             x0, x1
    // 0xc23610: LeaveFrame
    //     0xc23610: mov             SP, fp
    //     0xc23614: ldp             fp, lr, [SP], #0x10
    // 0xc23618: ret
    //     0xc23618: ret             
    // 0xc2361c: r0 = StackOverflowSharedWithFPURegs()
    //     0xc2361c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc23620: b               #0xc235d8
  }
  [closure] void _paintContents(dynamic, PaintingContext, Offset) {
    // ** addr: 0xc23624, size: 0x40
    // 0xc23624: EnterFrame
    //     0xc23624: stp             fp, lr, [SP, #-0x10]!
    //     0xc23628: mov             fp, SP
    // 0xc2362c: ldr             x0, [fp, #0x20]
    // 0xc23630: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc23630: ldur            w1, [x0, #0x17]
    // 0xc23634: DecompressPointer r1
    //     0xc23634: add             x1, x1, HEAP, lsl #32
    // 0xc23638: CheckStackOverflow
    //     0xc23638: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2363c: cmp             SP, x16
    //     0xc23640: b.ls            #0xc2365c
    // 0xc23644: ldr             x2, [fp, #0x18]
    // 0xc23648: ldr             x3, [fp, #0x10]
    // 0xc2364c: r0 = _paintContents()
    //     0xc2364c: bl              #0xc22d14  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintContents
    // 0xc23650: LeaveFrame
    //     0xc23650: mov             SP, fp
    //     0xc23654: ldp             fp, lr, [SP], #0x10
    // 0xc23658: ret
    //     0xc23658: ret             
    // 0xc2365c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2365c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc23660: b               #0xc23644
  }
  _ describeApproximatePaintClip(/* No info */) {
    // ** addr: 0xccdfb4, size: 0x5c
    // 0xccdfb4: EnterFrame
    //     0xccdfb4: stp             fp, lr, [SP, #-0x10]!
    //     0xccdfb8: mov             fp, SP
    // 0xccdfbc: AllocStack(0x8)
    //     0xccdfbc: sub             SP, SP, #8
    // 0xccdfc0: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xccdfc0: mov             x0, x1
    //     0xccdfc4: stur            x1, [fp, #-8]
    // 0xccdfc8: CheckStackOverflow
    //     0xccdfc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccdfcc: cmp             SP, x16
    //     0xccdfd0: b.ls            #0xcce008
    // 0xccdfd4: mov             x1, x0
    // 0xccdfd8: r0 = _hasVisualOverflow()
    //     0xccdfd8: bl              #0xc235bc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_hasVisualOverflow
    // 0xccdfdc: tbnz            w0, #4, #0xccdff8
    // 0xccdfe0: ldur            x1, [fp, #-8]
    // 0xccdfe4: r0 = size()
    //     0xccdfe4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xccdfe8: mov             x2, x0
    // 0xccdfec: r1 = Instance_Offset
    //     0xccdfec: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xccdff0: r0 = &()
    //     0xccdff0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xccdff4: b               #0xccdffc
    // 0xccdff8: r0 = Null
    //     0xccdff8: mov             x0, NULL
    // 0xccdffc: LeaveFrame
    //     0xccdffc: mov             SP, fp
    //     0xcce000: ldp             fp, lr, [SP], #0x10
    // 0xcce004: ret
    //     0xcce004: ret             
    // 0xcce008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcce008: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcce00c: b               #0xccdfd4
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xcd1b84, size: 0xa4
    // 0xcd1b84: EnterFrame
    //     0xcd1b84: stp             fp, lr, [SP, #-0x10]!
    //     0xcd1b88: mov             fp, SP
    // 0xcd1b8c: AllocStack(0x8)
    //     0xcd1b8c: sub             SP, SP, #8
    // 0xcd1b90: SetupParameters(RenderEditable this /* r1 => r5 */, dynamic _ /* r2 => r4, fp-0x8 */, dynamic _ /* r3 => r0 */)
    //     0xcd1b90: mov             x0, x3
    //     0xcd1b94: mov             x5, x1
    //     0xcd1b98: mov             x4, x2
    //     0xcd1b9c: stur            x2, [fp, #-8]
    // 0xcd1ba0: r2 = Null
    //     0xcd1ba0: mov             x2, NULL
    // 0xcd1ba4: r1 = Null
    //     0xcd1ba4: mov             x1, NULL
    // 0xcd1ba8: r4 = 60
    //     0xcd1ba8: mov             x4, #0x3c
    // 0xcd1bac: branchIfSmi(r0, 0xcd1bb8)
    //     0xcd1bac: tbz             w0, #0, #0xcd1bb8
    // 0xcd1bb0: r4 = LoadClassIdInstr(r0)
    //     0xcd1bb0: ldur            x4, [x0, #-1]
    //     0xcd1bb4: ubfx            x4, x4, #0xc, #0x14
    // 0xcd1bb8: cmp             x4, #0xc65
    // 0xcd1bbc: b.eq            #0xcd1bd4
    // 0xcd1bc0: r8 = BoxHitTestEntry
    //     0xcd1bc0: add             x8, PP, #0x15, lsl #12  ; [pp+0x155d0] Type: BoxHitTestEntry
    //     0xcd1bc4: ldr             x8, [x8, #0x5d0]
    // 0xcd1bc8: r3 = Null
    //     0xcd1bc8: add             x3, PP, #0xcd, lsl #12  ; [pp+0xcd648] Null
    //     0xcd1bcc: ldr             x3, [x3, #0x648]
    // 0xcd1bd0: r0 = DefaultTypeTest()
    //     0xcd1bd0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcd1bd4: ldur            x0, [fp, #-8]
    // 0xcd1bd8: r2 = Null
    //     0xcd1bd8: mov             x2, NULL
    // 0xcd1bdc: r1 = Null
    //     0xcd1bdc: mov             x1, NULL
    // 0xcd1be0: cmp             w0, NULL
    // 0xcd1be4: b.eq            #0xcd1c0c
    // 0xcd1be8: branchIfSmi(r0, 0xcd1c0c)
    //     0xcd1be8: tbz             w0, #0, #0xcd1c0c
    // 0xcd1bec: r3 = LoadClassIdInstr(r0)
    //     0xcd1bec: ldur            x3, [x0, #-1]
    //     0xcd1bf0: ubfx            x3, x3, #0xc, #0x14
    // 0xcd1bf4: r17 = 4159
    //     0xcd1bf4: mov             x17, #0x103f
    // 0xcd1bf8: cmp             x3, x17
    // 0xcd1bfc: b.eq            #0xcd1c14
    // 0xcd1c00: r17 = 5288
    //     0xcd1c00: mov             x17, #0x14a8
    // 0xcd1c04: cmp             x3, x17
    // 0xcd1c08: b.eq            #0xcd1c14
    // 0xcd1c0c: r0 = false
    //     0xcd1c0c: add             x0, NULL, #0x30  ; false
    // 0xcd1c10: b               #0xcd1c18
    // 0xcd1c14: r0 = true
    //     0xcd1c14: add             x0, NULL, #0x20  ; true
    // 0xcd1c18: r0 = Null
    //     0xcd1c18: mov             x0, NULL
    // 0xcd1c1c: LeaveFrame
    //     0xcd1c1c: mov             SP, fp
    //     0xcd1c20: ldp             fp, lr, [SP], #0x10
    // 0xcd1c24: ret
    //     0xcd1c24: ret             
  }
  _ setPromptRectRange(/* No info */) {
    // ** addr: 0xcf00d0, size: 0x3c
    // 0xcf00d0: EnterFrame
    //     0xcf00d0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf00d4: mov             fp, SP
    // 0xcf00d8: CheckStackOverflow
    //     0xcf00d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf00dc: cmp             SP, x16
    //     0xcf00e0: b.ls            #0xcf0104
    // 0xcf00e4: LoadField: r0 = r1->field_7b
    //     0xcf00e4: ldur            w0, [x1, #0x7b]
    // 0xcf00e8: DecompressPointer r0
    //     0xcf00e8: add             x0, x0, HEAP, lsl #32
    // 0xcf00ec: mov             x1, x0
    // 0xcf00f0: r0 = highlightedRange=()
    //     0xcf00f0: bl              #0xcf010c  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::highlightedRange=
    // 0xcf00f4: r0 = Null
    //     0xcf00f4: mov             x0, NULL
    // 0xcf00f8: LeaveFrame
    //     0xcf00f8: mov             SP, fp
    //     0xcf00fc: ldp             fp, lr, [SP], #0x10
    // 0xcf0100: ret
    //     0xcf0100: ret             
    // 0xcf0104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0108: b               #0xcf00e4
  }
  set _ promptRectColor=(/* No info */) {
    // ** addr: 0xcf01b0, size: 0x3c
    // 0xcf01b0: EnterFrame
    //     0xcf01b0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf01b4: mov             fp, SP
    // 0xcf01b8: CheckStackOverflow
    //     0xcf01b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf01bc: cmp             SP, x16
    //     0xcf01c0: b.ls            #0xcf01e4
    // 0xcf01c4: LoadField: r0 = r1->field_7b
    //     0xcf01c4: ldur            w0, [x1, #0x7b]
    // 0xcf01c8: DecompressPointer r0
    //     0xcf01c8: add             x0, x0, HEAP, lsl #32
    // 0xcf01cc: mov             x1, x0
    // 0xcf01d0: r0 = highlightColor=()
    //     0xcf01d0: bl              #0xcf01ec  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::highlightColor=
    // 0xcf01d4: r0 = Null
    //     0xcf01d4: mov             x0, NULL
    // 0xcf01d8: LeaveFrame
    //     0xcf01d8: mov             SP, fp
    //     0xcf01dc: ldp             fp, lr, [SP], #0x10
    // 0xcf01e0: ret
    //     0xcf01e0: ret             
    // 0xcf01e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf01e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf01e8: b               #0xcf01c4
  }
  set _ paintCursorAboveText=(/* No info */) {
    // ** addr: 0xcf0290, size: 0x74
    // 0xcf0290: EnterFrame
    //     0xcf0290: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0294: mov             fp, SP
    // 0xcf0298: AllocStack(0x8)
    //     0xcf0298: sub             SP, SP, #8
    // 0xcf029c: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xcf029c: mov             x0, x1
    //     0xcf02a0: stur            x1, [fp, #-8]
    // 0xcf02a4: CheckStackOverflow
    //     0xcf02a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf02a8: cmp             SP, x16
    //     0xcf02ac: b.ls            #0xcf02fc
    // 0xcf02b0: LoadField: r1 = r0->field_eb
    //     0xcf02b0: ldur            w1, [x0, #0xeb]
    // 0xcf02b4: DecompressPointer r1
    //     0xcf02b4: add             x1, x1, HEAP, lsl #32
    // 0xcf02b8: cmp             w1, w2
    // 0xcf02bc: b.ne            #0xcf02d0
    // 0xcf02c0: r0 = Null
    //     0xcf02c0: mov             x0, NULL
    // 0xcf02c4: LeaveFrame
    //     0xcf02c4: mov             SP, fp
    //     0xcf02c8: ldp             fp, lr, [SP], #0x10
    // 0xcf02cc: ret
    //     0xcf02cc: ret             
    // 0xcf02d0: StoreField: r0->field_eb = r2
    //     0xcf02d0: stur            w2, [x0, #0xeb]
    // 0xcf02d4: StoreField: r0->field_7f = rNULL
    //     0xcf02d4: stur            NULL, [x0, #0x7f]
    // 0xcf02d8: StoreField: r0->field_83 = rNULL
    //     0xcf02d8: stur            NULL, [x0, #0x83]
    // 0xcf02dc: mov             x1, x0
    // 0xcf02e0: r0 = _updateForegroundPainter()
    //     0xcf02e0: bl              #0xcf07e0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_updateForegroundPainter
    // 0xcf02e4: ldur            x1, [fp, #-8]
    // 0xcf02e8: r0 = _updatePainter()
    //     0xcf02e8: bl              #0xcf0304  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_updatePainter
    // 0xcf02ec: r0 = Null
    //     0xcf02ec: mov             x0, NULL
    // 0xcf02f0: LeaveFrame
    //     0xcf02f0: mov             SP, fp
    //     0xcf02f4: ldp             fp, lr, [SP], #0x10
    // 0xcf02f8: ret
    //     0xcf02f8: ret             
    // 0xcf02fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf02fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0300: b               #0xcf02b0
  }
  _ _updatePainter(/* No info */) {
    // ** addr: 0xcf0304, size: 0xd4
    // 0xcf0304: EnterFrame
    //     0xcf0304: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0308: mov             fp, SP
    // 0xcf030c: AllocStack(0x18)
    //     0xcf030c: sub             SP, SP, #0x18
    // 0xcf0310: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xcf0310: mov             x0, x1
    //     0xcf0314: stur            x1, [fp, #-8]
    // 0xcf0318: CheckStackOverflow
    //     0xcf0318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf031c: cmp             SP, x16
    //     0xcf0320: b.ls            #0xcf03d0
    // 0xcf0324: mov             x1, x0
    // 0xcf0328: r0 = _builtInPainters()
    //     0xcf0328: bl              #0xcf05cc  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_builtInPainters
    // 0xcf032c: ldur            x1, [fp, #-8]
    // 0xcf0330: stur            x0, [fp, #-0x10]
    // 0xcf0334: LoadField: r2 = r1->field_67
    //     0xcf0334: ldur            w2, [x1, #0x67]
    // 0xcf0338: DecompressPointer r2
    //     0xcf0338: add             x2, x2, HEAP, lsl #32
    // 0xcf033c: cmp             w2, NULL
    // 0xcf0340: b.ne            #0xcf03a8
    // 0xcf0344: r0 = _RenderEditableCustomPaint()
    //     0xcf0344: bl              #0xcf05c0  ; Allocate_RenderEditableCustomPaintStub -> _RenderEditableCustomPaint (size=0x54)
    // 0xcf0348: mov             x1, x0
    // 0xcf034c: ldur            x0, [fp, #-0x10]
    // 0xcf0350: stur            x1, [fp, #-0x18]
    // 0xcf0354: StoreField: r1->field_4f = r0
    //     0xcf0354: stur            w0, [x1, #0x4f]
    // 0xcf0358: r0 = _LayoutCacheStorage()
    //     0xcf0358: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0xcf035c: mov             x1, x0
    // 0xcf0360: ldur            x0, [fp, #-0x18]
    // 0xcf0364: StoreField: r0->field_47 = r1
    //     0xcf0364: stur            w1, [x0, #0x47]
    // 0xcf0368: mov             x1, x0
    // 0xcf036c: r0 = RenderObject()
    //     0xcf036c: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0xcf0370: ldur            x1, [fp, #-8]
    // 0xcf0374: ldur            x2, [fp, #-0x18]
    // 0xcf0378: r0 = adoptChild()
    //     0xcf0378: bl              #0xc05494  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0xcf037c: ldur            x0, [fp, #-0x18]
    // 0xcf0380: ldur            x3, [fp, #-8]
    // 0xcf0384: StoreField: r3->field_67 = r0
    //     0xcf0384: stur            w0, [x3, #0x67]
    //     0xcf0388: ldurb           w16, [x3, #-1]
    //     0xcf038c: ldurb           w17, [x0, #-1]
    //     0xcf0390: and             x16, x17, x16, lsr #2
    //     0xcf0394: tst             x16, HEAP, lsr #32
    //     0xcf0398: b.eq            #0xcf03a0
    //     0xcf039c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf03a0: mov             x1, x3
    // 0xcf03a4: b               #0xcf03bc
    // 0xcf03a8: mov             x3, x1
    // 0xcf03ac: mov             x1, x2
    // 0xcf03b0: mov             x2, x0
    // 0xcf03b4: r0 = painter=()
    //     0xcf03b4: bl              #0xcf03d8  ; [package:flutter/src/rendering/editable.dart] _RenderEditableCustomPaint::painter=
    // 0xcf03b8: ldur            x1, [fp, #-8]
    // 0xcf03bc: StoreField: r1->field_6f = rNULL
    //     0xcf03bc: stur            NULL, [x1, #0x6f]
    // 0xcf03c0: r0 = Null
    //     0xcf03c0: mov             x0, NULL
    // 0xcf03c4: LeaveFrame
    //     0xcf03c4: mov             SP, fp
    //     0xcf03c8: ldp             fp, lr, [SP], #0x10
    // 0xcf03cc: ret
    //     0xcf03cc: ret             
    // 0xcf03d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf03d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf03d4: b               #0xcf0324
  }
  get _ _builtInPainters(/* No info */) {
    // ** addr: 0xcf05cc, size: 0x7c
    // 0xcf05cc: EnterFrame
    //     0xcf05cc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf05d0: mov             fp, SP
    // 0xcf05d4: AllocStack(0x8)
    //     0xcf05d4: sub             SP, SP, #8
    // 0xcf05d8: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xcf05d8: mov             x0, x1
    //     0xcf05dc: stur            x1, [fp, #-8]
    // 0xcf05e0: CheckStackOverflow
    //     0xcf05e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf05e4: cmp             SP, x16
    //     0xcf05e8: b.ls            #0xcf0640
    // 0xcf05ec: LoadField: r1 = r0->field_83
    //     0xcf05ec: ldur            w1, [x0, #0x83]
    // 0xcf05f0: DecompressPointer r1
    //     0xcf05f0: add             x1, x1, HEAP, lsl #32
    // 0xcf05f4: cmp             w1, NULL
    // 0xcf05f8: b.ne            #0xcf0630
    // 0xcf05fc: mov             x1, x0
    // 0xcf0600: r0 = _createBuiltInPainters()
    //     0xcf0600: bl              #0xcf0648  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_createBuiltInPainters
    // 0xcf0604: mov             x1, x0
    // 0xcf0608: ldur            x2, [fp, #-8]
    // 0xcf060c: StoreField: r2->field_83 = r0
    //     0xcf060c: stur            w0, [x2, #0x83]
    //     0xcf0610: ldurb           w16, [x2, #-1]
    //     0xcf0614: ldurb           w17, [x0, #-1]
    //     0xcf0618: and             x16, x17, x16, lsr #2
    //     0xcf061c: tst             x16, HEAP, lsr #32
    //     0xcf0620: b.eq            #0xcf0628
    //     0xcf0624: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf0628: mov             x0, x1
    // 0xcf062c: b               #0xcf0634
    // 0xcf0630: mov             x0, x1
    // 0xcf0634: LeaveFrame
    //     0xcf0634: mov             SP, fp
    //     0xcf0638: ldp             fp, lr, [SP], #0x10
    // 0xcf063c: ret
    //     0xcf063c: ret             
    // 0xcf0640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0640: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0644: b               #0xcf05ec
  }
  _ _createBuiltInPainters(/* No info */) {
    // ** addr: 0xcf0648, size: 0x18c
    // 0xcf0648: EnterFrame
    //     0xcf0648: stp             fp, lr, [SP, #-0x10]!
    //     0xcf064c: mov             fp, SP
    // 0xcf0650: AllocStack(0x28)
    //     0xcf0650: sub             SP, SP, #0x28
    // 0xcf0654: r0 = 4
    //     0xcf0654: mov             x0, #4
    // 0xcf0658: mov             x3, x1
    // 0xcf065c: stur            x1, [fp, #-0x18]
    // 0xcf0660: CheckStackOverflow
    //     0xcf0660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0664: cmp             SP, x16
    //     0xcf0668: b.ls            #0xcf07cc
    // 0xcf066c: LoadField: r4 = r3->field_7b
    //     0xcf066c: ldur            w4, [x3, #0x7b]
    // 0xcf0670: DecompressPointer r4
    //     0xcf0670: add             x4, x4, HEAP, lsl #32
    // 0xcf0674: stur            x4, [fp, #-0x10]
    // 0xcf0678: LoadField: r5 = r3->field_77
    //     0xcf0678: ldur            w5, [x3, #0x77]
    // 0xcf067c: DecompressPointer r5
    //     0xcf067c: add             x5, x5, HEAP, lsl #32
    // 0xcf0680: mov             x2, x0
    // 0xcf0684: stur            x5, [fp, #-8]
    // 0xcf0688: r1 = Null
    //     0xcf0688: mov             x1, NULL
    // 0xcf068c: r0 = AllocateArray()
    //     0xcf068c: bl              #0x13df928  ; AllocateArrayStub
    // 0xcf0690: mov             x2, x0
    // 0xcf0694: ldur            x0, [fp, #-0x10]
    // 0xcf0698: stur            x2, [fp, #-0x20]
    // 0xcf069c: StoreField: r2->field_f = r0
    //     0xcf069c: stur            w0, [x2, #0xf]
    // 0xcf06a0: ldur            x0, [fp, #-8]
    // 0xcf06a4: StoreField: r2->field_13 = r0
    //     0xcf06a4: stur            w0, [x2, #0x13]
    // 0xcf06a8: r1 = <RenderEditablePainter>
    //     0xcf06a8: add             x1, PP, #0xad, lsl #12  ; [pp+0xad648] TypeArguments: <RenderEditablePainter>
    //     0xcf06ac: ldr             x1, [x1, #0x648]
    // 0xcf06b0: r0 = AllocateGrowableArray()
    //     0xcf06b0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xcf06b4: mov             x2, x0
    // 0xcf06b8: ldur            x0, [fp, #-0x20]
    // 0xcf06bc: stur            x2, [fp, #-8]
    // 0xcf06c0: StoreField: r2->field_f = r0
    //     0xcf06c0: stur            w0, [x2, #0xf]
    // 0xcf06c4: r0 = 4
    //     0xcf06c4: mov             x0, #4
    // 0xcf06c8: StoreField: r2->field_b = r0
    //     0xcf06c8: stur            w0, [x2, #0xb]
    // 0xcf06cc: ldur            x1, [fp, #-0x18]
    // 0xcf06d0: LoadField: r0 = r1->field_eb
    //     0xcf06d0: ldur            w0, [x1, #0xeb]
    // 0xcf06d4: DecompressPointer r0
    //     0xcf06d4: add             x0, x0, HEAP, lsl #32
    // 0xcf06d8: tbz             w0, #4, #0xcf0778
    // 0xcf06dc: LoadField: r0 = r1->field_73
    //     0xcf06dc: ldur            w0, [x1, #0x73]
    // 0xcf06e0: DecompressPointer r0
    //     0xcf06e0: add             x0, x0, HEAP, lsl #32
    // 0xcf06e4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf06e8: cmp             w0, w16
    // 0xcf06ec: b.ne            #0xcf06f8
    // 0xcf06f0: r2 = _caretPainter
    //     0xcf06f0: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0xcf06f4: r0 = InitLateFinalInstanceField()
    //     0xcf06f4: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xcf06f8: mov             x2, x0
    // 0xcf06fc: ldur            x0, [fp, #-8]
    // 0xcf0700: stur            x2, [fp, #-0x10]
    // 0xcf0704: LoadField: r1 = r0->field_b
    //     0xcf0704: ldur            w1, [x0, #0xb]
    // 0xcf0708: LoadField: r3 = r0->field_f
    //     0xcf0708: ldur            w3, [x0, #0xf]
    // 0xcf070c: DecompressPointer r3
    //     0xcf070c: add             x3, x3, HEAP, lsl #32
    // 0xcf0710: LoadField: r4 = r3->field_b
    //     0xcf0710: ldur            w4, [x3, #0xb]
    // 0xcf0714: r3 = LoadInt32Instr(r1)
    //     0xcf0714: sbfx            x3, x1, #1, #0x1f
    // 0xcf0718: stur            x3, [fp, #-0x28]
    // 0xcf071c: r1 = LoadInt32Instr(r4)
    //     0xcf071c: sbfx            x1, x4, #1, #0x1f
    // 0xcf0720: cmp             x3, x1
    // 0xcf0724: b.ne            #0xcf0730
    // 0xcf0728: mov             x1, x0
    // 0xcf072c: r0 = _growToNextCapacity()
    //     0xcf072c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcf0730: ldur            x2, [fp, #-8]
    // 0xcf0734: ldur            x3, [fp, #-0x28]
    // 0xcf0738: add             x0, x3, #1
    // 0xcf073c: lsl             x1, x0, #1
    // 0xcf0740: StoreField: r2->field_b = r1
    //     0xcf0740: stur            w1, [x2, #0xb]
    // 0xcf0744: LoadField: r1 = r2->field_f
    //     0xcf0744: ldur            w1, [x2, #0xf]
    // 0xcf0748: DecompressPointer r1
    //     0xcf0748: add             x1, x1, HEAP, lsl #32
    // 0xcf074c: ldur            x0, [fp, #-0x10]
    // 0xcf0750: ArrayStore: r1[r3] = r0  ; List_4
    //     0xcf0750: add             x25, x1, x3, lsl #2
    //     0xcf0754: add             x25, x25, #0xf
    //     0xcf0758: str             w0, [x25]
    //     0xcf075c: tbz             w0, #0, #0xcf0778
    //     0xcf0760: ldurb           w16, [x1, #-1]
    //     0xcf0764: ldurb           w17, [x0, #-1]
    //     0xcf0768: and             x16, x17, x16, lsr #2
    //     0xcf076c: tst             x16, HEAP, lsr #32
    //     0xcf0770: b.eq            #0xcf0778
    //     0xcf0774: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xcf0778: r0 = _CompositeRenderEditablePainter()
    //     0xcf0778: bl              #0xcf07d4  ; Allocate_CompositeRenderEditablePainterStub -> _CompositeRenderEditablePainter (size=0x28)
    // 0xcf077c: mov             x1, x0
    // 0xcf0780: ldur            x0, [fp, #-8]
    // 0xcf0784: stur            x1, [fp, #-0x10]
    // 0xcf0788: StoreField: r1->field_23 = r0
    //     0xcf0788: stur            w0, [x1, #0x23]
    // 0xcf078c: StoreField: r1->field_7 = rZR
    //     0xcf078c: stur            xzr, [x1, #7]
    // 0xcf0790: StoreField: r1->field_13 = rZR
    //     0xcf0790: stur            xzr, [x1, #0x13]
    // 0xcf0794: StoreField: r1->field_1b = rZR
    //     0xcf0794: stur            xzr, [x1, #0x1b]
    // 0xcf0798: r0 = LoadStaticField(0x45c)
    //     0xcf0798: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xcf079c: ldr             x0, [x0, #0x8b8]
    // 0xcf07a0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf07a4: cmp             w0, w16
    // 0xcf07a8: b.ne            #0xcf07b4
    // 0xcf07ac: r2 = _emptyListeners
    //     0xcf07ac: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xcf07b0: r0 = InitLateFinalStaticField()
    //     0xcf07b0: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xcf07b4: mov             x1, x0
    // 0xcf07b8: ldur            x0, [fp, #-0x10]
    // 0xcf07bc: StoreField: r0->field_f = r1
    //     0xcf07bc: stur            w1, [x0, #0xf]
    // 0xcf07c0: LeaveFrame
    //     0xcf07c0: mov             SP, fp
    //     0xcf07c4: ldp             fp, lr, [SP], #0x10
    // 0xcf07c8: ret
    //     0xcf07c8: ret             
    // 0xcf07cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf07cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf07d0: b               #0xcf066c
  }
  _ _updateForegroundPainter(/* No info */) {
    // ** addr: 0xcf07e0, size: 0xd4
    // 0xcf07e0: EnterFrame
    //     0xcf07e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf07e4: mov             fp, SP
    // 0xcf07e8: AllocStack(0x18)
    //     0xcf07e8: sub             SP, SP, #0x18
    // 0xcf07ec: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xcf07ec: mov             x0, x1
    //     0xcf07f0: stur            x1, [fp, #-8]
    // 0xcf07f4: CheckStackOverflow
    //     0xcf07f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf07f8: cmp             SP, x16
    //     0xcf07fc: b.ls            #0xcf08ac
    // 0xcf0800: mov             x1, x0
    // 0xcf0804: r0 = _builtInForegroundPainters()
    //     0xcf0804: bl              #0xcf08b4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_builtInForegroundPainters
    // 0xcf0808: ldur            x1, [fp, #-8]
    // 0xcf080c: stur            x0, [fp, #-0x10]
    // 0xcf0810: LoadField: r2 = r1->field_63
    //     0xcf0810: ldur            w2, [x1, #0x63]
    // 0xcf0814: DecompressPointer r2
    //     0xcf0814: add             x2, x2, HEAP, lsl #32
    // 0xcf0818: cmp             w2, NULL
    // 0xcf081c: b.ne            #0xcf0884
    // 0xcf0820: r0 = _RenderEditableCustomPaint()
    //     0xcf0820: bl              #0xcf05c0  ; Allocate_RenderEditableCustomPaintStub -> _RenderEditableCustomPaint (size=0x54)
    // 0xcf0824: mov             x1, x0
    // 0xcf0828: ldur            x0, [fp, #-0x10]
    // 0xcf082c: stur            x1, [fp, #-0x18]
    // 0xcf0830: StoreField: r1->field_4f = r0
    //     0xcf0830: stur            w0, [x1, #0x4f]
    // 0xcf0834: r0 = _LayoutCacheStorage()
    //     0xcf0834: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0xcf0838: mov             x1, x0
    // 0xcf083c: ldur            x0, [fp, #-0x18]
    // 0xcf0840: StoreField: r0->field_47 = r1
    //     0xcf0840: stur            w1, [x0, #0x47]
    // 0xcf0844: mov             x1, x0
    // 0xcf0848: r0 = RenderObject()
    //     0xcf0848: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0xcf084c: ldur            x1, [fp, #-8]
    // 0xcf0850: ldur            x2, [fp, #-0x18]
    // 0xcf0854: r0 = adoptChild()
    //     0xcf0854: bl              #0xc05494  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0xcf0858: ldur            x0, [fp, #-0x18]
    // 0xcf085c: ldur            x3, [fp, #-8]
    // 0xcf0860: StoreField: r3->field_63 = r0
    //     0xcf0860: stur            w0, [x3, #0x63]
    //     0xcf0864: ldurb           w16, [x3, #-1]
    //     0xcf0868: ldurb           w17, [x0, #-1]
    //     0xcf086c: and             x16, x17, x16, lsr #2
    //     0xcf0870: tst             x16, HEAP, lsr #32
    //     0xcf0874: b.eq            #0xcf087c
    //     0xcf0878: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf087c: mov             x1, x3
    // 0xcf0880: b               #0xcf0898
    // 0xcf0884: mov             x3, x1
    // 0xcf0888: mov             x1, x2
    // 0xcf088c: mov             x2, x0
    // 0xcf0890: r0 = painter=()
    //     0xcf0890: bl              #0xcf03d8  ; [package:flutter/src/rendering/editable.dart] _RenderEditableCustomPaint::painter=
    // 0xcf0894: ldur            x1, [fp, #-8]
    // 0xcf0898: StoreField: r1->field_6b = rNULL
    //     0xcf0898: stur            NULL, [x1, #0x6b]
    // 0xcf089c: r0 = Null
    //     0xcf089c: mov             x0, NULL
    // 0xcf08a0: LeaveFrame
    //     0xcf08a0: mov             SP, fp
    //     0xcf08a4: ldp             fp, lr, [SP], #0x10
    // 0xcf08a8: ret
    //     0xcf08a8: ret             
    // 0xcf08ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf08ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf08b0: b               #0xcf0800
  }
  get _ _builtInForegroundPainters(/* No info */) {
    // ** addr: 0xcf08b4, size: 0x7c
    // 0xcf08b4: EnterFrame
    //     0xcf08b4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf08b8: mov             fp, SP
    // 0xcf08bc: AllocStack(0x8)
    //     0xcf08bc: sub             SP, SP, #8
    // 0xcf08c0: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xcf08c0: mov             x0, x1
    //     0xcf08c4: stur            x1, [fp, #-8]
    // 0xcf08c8: CheckStackOverflow
    //     0xcf08c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf08cc: cmp             SP, x16
    //     0xcf08d0: b.ls            #0xcf0928
    // 0xcf08d4: LoadField: r1 = r0->field_7f
    //     0xcf08d4: ldur            w1, [x0, #0x7f]
    // 0xcf08d8: DecompressPointer r1
    //     0xcf08d8: add             x1, x1, HEAP, lsl #32
    // 0xcf08dc: cmp             w1, NULL
    // 0xcf08e0: b.ne            #0xcf0918
    // 0xcf08e4: mov             x1, x0
    // 0xcf08e8: r0 = _createBuiltInForegroundPainters()
    //     0xcf08e8: bl              #0xcf0930  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_createBuiltInForegroundPainters
    // 0xcf08ec: mov             x1, x0
    // 0xcf08f0: ldur            x2, [fp, #-8]
    // 0xcf08f4: StoreField: r2->field_7f = r0
    //     0xcf08f4: stur            w0, [x2, #0x7f]
    //     0xcf08f8: ldurb           w16, [x2, #-1]
    //     0xcf08fc: ldurb           w17, [x0, #-1]
    //     0xcf0900: and             x16, x17, x16, lsr #2
    //     0xcf0904: tst             x16, HEAP, lsr #32
    //     0xcf0908: b.eq            #0xcf0910
    //     0xcf090c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf0910: mov             x0, x1
    // 0xcf0914: b               #0xcf091c
    // 0xcf0918: mov             x0, x1
    // 0xcf091c: LeaveFrame
    //     0xcf091c: mov             SP, fp
    //     0xcf0920: ldp             fp, lr, [SP], #0x10
    // 0xcf0924: ret
    //     0xcf0924: ret             
    // 0xcf0928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0928: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf092c: b               #0xcf08d4
  }
  _ _createBuiltInForegroundPainters(/* No info */) {
    // ** addr: 0xcf0930, size: 0x144
    // 0xcf0930: EnterFrame
    //     0xcf0930: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0934: mov             fp, SP
    // 0xcf0938: AllocStack(0x18)
    //     0xcf0938: sub             SP, SP, #0x18
    // 0xcf093c: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xcf093c: mov             x0, x1
    //     0xcf0940: stur            x1, [fp, #-8]
    // 0xcf0944: CheckStackOverflow
    //     0xcf0944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0948: cmp             SP, x16
    //     0xcf094c: b.ls            #0xcf0a6c
    // 0xcf0950: r1 = <RenderEditablePainter>
    //     0xcf0950: add             x1, PP, #0xad, lsl #12  ; [pp+0xad648] TypeArguments: <RenderEditablePainter>
    //     0xcf0954: ldr             x1, [x1, #0x648]
    // 0xcf0958: r2 = 0
    //     0xcf0958: mov             x2, #0
    // 0xcf095c: r0 = _GrowableList()
    //     0xcf095c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xcf0960: ldur            x1, [fp, #-8]
    // 0xcf0964: stur            x0, [fp, #-0x10]
    // 0xcf0968: LoadField: r2 = r1->field_eb
    //     0xcf0968: ldur            w2, [x1, #0xeb]
    // 0xcf096c: DecompressPointer r2
    //     0xcf096c: add             x2, x2, HEAP, lsl #32
    // 0xcf0970: tbnz            w2, #4, #0xcf0a14
    // 0xcf0974: LoadField: r0 = r1->field_73
    //     0xcf0974: ldur            w0, [x1, #0x73]
    // 0xcf0978: DecompressPointer r0
    //     0xcf0978: add             x0, x0, HEAP, lsl #32
    // 0xcf097c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf0980: cmp             w0, w16
    // 0xcf0984: b.ne            #0xcf0990
    // 0xcf0988: r2 = _caretPainter
    //     0xcf0988: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0xcf098c: r0 = InitLateFinalInstanceField()
    //     0xcf098c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xcf0990: mov             x2, x0
    // 0xcf0994: ldur            x0, [fp, #-0x10]
    // 0xcf0998: stur            x2, [fp, #-8]
    // 0xcf099c: LoadField: r1 = r0->field_b
    //     0xcf099c: ldur            w1, [x0, #0xb]
    // 0xcf09a0: LoadField: r3 = r0->field_f
    //     0xcf09a0: ldur            w3, [x0, #0xf]
    // 0xcf09a4: DecompressPointer r3
    //     0xcf09a4: add             x3, x3, HEAP, lsl #32
    // 0xcf09a8: LoadField: r4 = r3->field_b
    //     0xcf09a8: ldur            w4, [x3, #0xb]
    // 0xcf09ac: r3 = LoadInt32Instr(r1)
    //     0xcf09ac: sbfx            x3, x1, #1, #0x1f
    // 0xcf09b0: stur            x3, [fp, #-0x18]
    // 0xcf09b4: r1 = LoadInt32Instr(r4)
    //     0xcf09b4: sbfx            x1, x4, #1, #0x1f
    // 0xcf09b8: cmp             x3, x1
    // 0xcf09bc: b.ne            #0xcf09c8
    // 0xcf09c0: mov             x1, x0
    // 0xcf09c4: r0 = _growToNextCapacity()
    //     0xcf09c4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcf09c8: ldur            x2, [fp, #-0x10]
    // 0xcf09cc: ldur            x3, [fp, #-0x18]
    // 0xcf09d0: add             x0, x3, #1
    // 0xcf09d4: lsl             x1, x0, #1
    // 0xcf09d8: StoreField: r2->field_b = r1
    //     0xcf09d8: stur            w1, [x2, #0xb]
    // 0xcf09dc: LoadField: r1 = r2->field_f
    //     0xcf09dc: ldur            w1, [x2, #0xf]
    // 0xcf09e0: DecompressPointer r1
    //     0xcf09e0: add             x1, x1, HEAP, lsl #32
    // 0xcf09e4: ldur            x0, [fp, #-8]
    // 0xcf09e8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xcf09e8: add             x25, x1, x3, lsl #2
    //     0xcf09ec: add             x25, x25, #0xf
    //     0xcf09f0: str             w0, [x25]
    //     0xcf09f4: tbz             w0, #0, #0xcf0a10
    //     0xcf09f8: ldurb           w16, [x1, #-1]
    //     0xcf09fc: ldurb           w17, [x0, #-1]
    //     0xcf0a00: and             x16, x17, x16, lsr #2
    //     0xcf0a04: tst             x16, HEAP, lsr #32
    //     0xcf0a08: b.eq            #0xcf0a10
    //     0xcf0a0c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xcf0a10: b               #0xcf0a18
    // 0xcf0a14: mov             x2, x0
    // 0xcf0a18: r0 = _CompositeRenderEditablePainter()
    //     0xcf0a18: bl              #0xcf07d4  ; Allocate_CompositeRenderEditablePainterStub -> _CompositeRenderEditablePainter (size=0x28)
    // 0xcf0a1c: mov             x1, x0
    // 0xcf0a20: ldur            x0, [fp, #-0x10]
    // 0xcf0a24: stur            x1, [fp, #-8]
    // 0xcf0a28: StoreField: r1->field_23 = r0
    //     0xcf0a28: stur            w0, [x1, #0x23]
    // 0xcf0a2c: StoreField: r1->field_7 = rZR
    //     0xcf0a2c: stur            xzr, [x1, #7]
    // 0xcf0a30: StoreField: r1->field_13 = rZR
    //     0xcf0a30: stur            xzr, [x1, #0x13]
    // 0xcf0a34: StoreField: r1->field_1b = rZR
    //     0xcf0a34: stur            xzr, [x1, #0x1b]
    // 0xcf0a38: r0 = LoadStaticField(0x45c)
    //     0xcf0a38: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xcf0a3c: ldr             x0, [x0, #0x8b8]
    // 0xcf0a40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf0a44: cmp             w0, w16
    // 0xcf0a48: b.ne            #0xcf0a54
    // 0xcf0a4c: r2 = _emptyListeners
    //     0xcf0a4c: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0xcf0a50: r0 = InitLateFinalStaticField()
    //     0xcf0a50: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0xcf0a54: mov             x1, x0
    // 0xcf0a58: ldur            x0, [fp, #-8]
    // 0xcf0a5c: StoreField: r0->field_f = r1
    //     0xcf0a5c: stur            w1, [x0, #0xf]
    // 0xcf0a60: LeaveFrame
    //     0xcf0a60: mov             SP, fp
    //     0xcf0a64: ldp             fp, lr, [SP], #0x10
    // 0xcf0a68: ret
    //     0xcf0a68: ret             
    // 0xcf0a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0a6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0a70: b               #0xcf0950
  }
  set _ enableInteractiveSelection=(/* No info */) {
    // ** addr: 0xcf0a74, size: 0x74
    // 0xcf0a74: EnterFrame
    //     0xcf0a74: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0a78: mov             fp, SP
    // 0xcf0a7c: AllocStack(0x8)
    //     0xcf0a7c: sub             SP, SP, #8
    // 0xcf0a80: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xcf0a80: mov             x0, x1
    //     0xcf0a84: stur            x1, [fp, #-8]
    // 0xcf0a88: CheckStackOverflow
    //     0xcf0a88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0a8c: cmp             SP, x16
    //     0xcf0a90: b.ls            #0xcf0ae0
    // 0xcf0a94: r17 = 259
    //     0xcf0a94: mov             x17, #0x103
    // 0xcf0a98: ldr             w1, [x0, x17]
    // 0xcf0a9c: DecompressPointer r1
    //     0xcf0a9c: add             x1, x1, HEAP, lsl #32
    // 0xcf0aa0: cmp             w1, w2
    // 0xcf0aa4: b.ne            #0xcf0ab8
    // 0xcf0aa8: r0 = Null
    //     0xcf0aa8: mov             x0, NULL
    // 0xcf0aac: LeaveFrame
    //     0xcf0aac: mov             SP, fp
    //     0xcf0ab0: ldp             fp, lr, [SP], #0x10
    // 0xcf0ab4: ret
    //     0xcf0ab4: ret             
    // 0xcf0ab8: r17 = 259
    //     0xcf0ab8: mov             x17, #0x103
    // 0xcf0abc: str             w2, [x0, x17]
    // 0xcf0ac0: mov             x1, x0
    // 0xcf0ac4: r0 = markNeedsLayout()
    //     0xcf0ac4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf0ac8: ldur            x1, [fp, #-8]
    // 0xcf0acc: r0 = markNeedsSemanticsUpdate()
    //     0xcf0acc: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf0ad0: r0 = Null
    //     0xcf0ad0: mov             x0, NULL
    // 0xcf0ad4: LeaveFrame
    //     0xcf0ad4: mov             SP, fp
    //     0xcf0ad8: ldp             fp, lr, [SP], #0x10
    // 0xcf0adc: ret
    //     0xcf0adc: ret             
    // 0xcf0ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0ae0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0ae4: b               #0xcf0a94
  }
  set _ selectionWidthStyle=(/* No info */) {
    // ** addr: 0xcf0ae8, size: 0x44
    // 0xcf0ae8: EnterFrame
    //     0xcf0ae8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0aec: mov             fp, SP
    // 0xcf0af0: CheckStackOverflow
    //     0xcf0af0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0af4: cmp             SP, x16
    //     0xcf0af8: b.ls            #0xcf0b24
    // 0xcf0afc: LoadField: r0 = r1->field_77
    //     0xcf0afc: ldur            w0, [x1, #0x77]
    // 0xcf0b00: DecompressPointer r0
    //     0xcf0b00: add             x0, x0, HEAP, lsl #32
    // 0xcf0b04: mov             x1, x0
    // 0xcf0b08: r2 = Instance_BoxWidthStyle
    //     0xcf0b08: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a668] Obj!BoxWidthStyle@12c72e1
    //     0xcf0b0c: ldr             x2, [x2, #0x668]
    // 0xcf0b10: r0 = selectionWidthStyle=()
    //     0xcf0b10: bl              #0xcf0b2c  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::selectionWidthStyle=
    // 0xcf0b14: r0 = Null
    //     0xcf0b14: mov             x0, NULL
    // 0xcf0b18: LeaveFrame
    //     0xcf0b18: mov             SP, fp
    //     0xcf0b1c: ldp             fp, lr, [SP], #0x10
    // 0xcf0b20: ret
    //     0xcf0b20: ret             
    // 0xcf0b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0b24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0b28: b               #0xcf0afc
  }
  set _ selectionHeightStyle=(/* No info */) {
    // ** addr: 0xcf0b90, size: 0x44
    // 0xcf0b90: EnterFrame
    //     0xcf0b90: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0b94: mov             fp, SP
    // 0xcf0b98: CheckStackOverflow
    //     0xcf0b98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0b9c: cmp             SP, x16
    //     0xcf0ba0: b.ls            #0xcf0bcc
    // 0xcf0ba4: LoadField: r0 = r1->field_77
    //     0xcf0ba4: ldur            w0, [x1, #0x77]
    // 0xcf0ba8: DecompressPointer r0
    //     0xcf0ba8: add             x0, x0, HEAP, lsl #32
    // 0xcf0bac: mov             x1, x0
    // 0xcf0bb0: r2 = Instance_BoxHeightStyle
    //     0xcf0bb0: add             x2, PP, #0x1a, lsl #12  ; [pp+0x1a660] Obj!BoxHeightStyle@12c7321
    //     0xcf0bb4: ldr             x2, [x2, #0x660]
    // 0xcf0bb8: r0 = selectionHeightStyle=()
    //     0xcf0bb8: bl              #0xcf0bd4  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::selectionHeightStyle=
    // 0xcf0bbc: r0 = Null
    //     0xcf0bbc: mov             x0, NULL
    // 0xcf0bc0: LeaveFrame
    //     0xcf0bc0: mov             SP, fp
    //     0xcf0bc4: ldp             fp, lr, [SP], #0x10
    // 0xcf0bc8: ret
    //     0xcf0bc8: ret             
    // 0xcf0bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0bcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0bd0: b               #0xcf0ba4
  }
  set _ cursorOffset=(/* No info */) {
    // ** addr: 0xcf0c38, size: 0x5c
    // 0xcf0c38: EnterFrame
    //     0xcf0c38: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0c3c: mov             fp, SP
    // 0xcf0c40: AllocStack(0x8)
    //     0xcf0c40: sub             SP, SP, #8
    // 0xcf0c44: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xcf0c44: stur            x2, [fp, #-8]
    // 0xcf0c48: CheckStackOverflow
    //     0xcf0c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0c4c: cmp             SP, x16
    //     0xcf0c50: b.ls            #0xcf0c8c
    // 0xcf0c54: LoadField: r0 = r1->field_73
    //     0xcf0c54: ldur            w0, [x1, #0x73]
    // 0xcf0c58: DecompressPointer r0
    //     0xcf0c58: add             x0, x0, HEAP, lsl #32
    // 0xcf0c5c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf0c60: cmp             w0, w16
    // 0xcf0c64: b.ne            #0xcf0c70
    // 0xcf0c68: r2 = _caretPainter
    //     0xcf0c68: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0xcf0c6c: r0 = InitLateFinalInstanceField()
    //     0xcf0c6c: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xcf0c70: mov             x1, x0
    // 0xcf0c74: ldur            x2, [fp, #-8]
    // 0xcf0c78: r0 = cursorOffset=()
    //     0xcf0c78: bl              #0xcf0c94  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::cursorOffset=
    // 0xcf0c7c: r0 = Null
    //     0xcf0c7c: mov             x0, NULL
    // 0xcf0c80: LeaveFrame
    //     0xcf0c80: mov             SP, fp
    //     0xcf0c84: ldp             fp, lr, [SP], #0x10
    // 0xcf0c88: ret
    //     0xcf0c88: ret             
    // 0xcf0c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0c8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0c90: b               #0xcf0c54
  }
  set _ cursorRadius=(/* No info */) {
    // ** addr: 0xcf0d1c, size: 0x5c
    // 0xcf0d1c: EnterFrame
    //     0xcf0d1c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0d20: mov             fp, SP
    // 0xcf0d24: AllocStack(0x8)
    //     0xcf0d24: sub             SP, SP, #8
    // 0xcf0d28: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xcf0d28: stur            x2, [fp, #-8]
    // 0xcf0d2c: CheckStackOverflow
    //     0xcf0d2c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0d30: cmp             SP, x16
    //     0xcf0d34: b.ls            #0xcf0d70
    // 0xcf0d38: LoadField: r0 = r1->field_73
    //     0xcf0d38: ldur            w0, [x1, #0x73]
    // 0xcf0d3c: DecompressPointer r0
    //     0xcf0d3c: add             x0, x0, HEAP, lsl #32
    // 0xcf0d40: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf0d44: cmp             w0, w16
    // 0xcf0d48: b.ne            #0xcf0d54
    // 0xcf0d4c: r2 = _caretPainter
    //     0xcf0d4c: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0xcf0d50: r0 = InitLateFinalInstanceField()
    //     0xcf0d50: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xcf0d54: mov             x1, x0
    // 0xcf0d58: ldur            x2, [fp, #-8]
    // 0xcf0d5c: r0 = inactiveColor=()
    //     0xcf0d5c: bl              #0xcf0d78  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveColor=
    // 0xcf0d60: r0 = Null
    //     0xcf0d60: mov             x0, NULL
    // 0xcf0d64: LeaveFrame
    //     0xcf0d64: mov             SP, fp
    //     0xcf0d68: ldp             fp, lr, [SP], #0x10
    // 0xcf0d6c: ret
    //     0xcf0d6c: ret             
    // 0xcf0d70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0d70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0d74: b               #0xcf0d38
  }
  set _ cursorWidth=(/* No info */) {
    // ** addr: 0xcf0e1c, size: 0x50
    // 0xcf0e1c: EnterFrame
    //     0xcf0e1c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0e20: mov             fp, SP
    // 0xcf0e24: CheckStackOverflow
    //     0xcf0e24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0e28: cmp             SP, x16
    //     0xcf0e2c: b.ls            #0xcf0e64
    // 0xcf0e30: LoadField: d1 = r1->field_df
    //     0xcf0e30: ldur            d1, [x1, #0xdf]
    // 0xcf0e34: fcmp            d1, d0
    // 0xcf0e38: b.ne            #0xcf0e4c
    // 0xcf0e3c: r0 = Null
    //     0xcf0e3c: mov             x0, NULL
    // 0xcf0e40: LeaveFrame
    //     0xcf0e40: mov             SP, fp
    //     0xcf0e44: ldp             fp, lr, [SP], #0x10
    // 0xcf0e48: ret
    //     0xcf0e48: ret             
    // 0xcf0e4c: StoreField: r1->field_df = d0
    //     0xcf0e4c: stur            d0, [x1, #0xdf]
    // 0xcf0e50: r0 = markNeedsLayout()
    //     0xcf0e50: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf0e54: r0 = Null
    //     0xcf0e54: mov             x0, NULL
    // 0xcf0e58: LeaveFrame
    //     0xcf0e58: mov             SP, fp
    //     0xcf0e5c: ldp             fp, lr, [SP], #0x10
    // 0xcf0e60: ret
    //     0xcf0e60: ret             
    // 0xcf0e64: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf0e64: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf0e68: b               #0xcf0e30
  }
  set _ obscureText=(/* No info */) {
    // ** addr: 0xcf0e6c, size: 0x58
    // 0xcf0e6c: EnterFrame
    //     0xcf0e6c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0e70: mov             fp, SP
    // 0xcf0e74: CheckStackOverflow
    //     0xcf0e74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0e78: cmp             SP, x16
    //     0xcf0e7c: b.ls            #0xcf0ebc
    // 0xcf0e80: LoadField: r0 = r1->field_97
    //     0xcf0e80: ldur            w0, [x1, #0x97]
    // 0xcf0e84: DecompressPointer r0
    //     0xcf0e84: add             x0, x0, HEAP, lsl #32
    // 0xcf0e88: cmp             w0, w2
    // 0xcf0e8c: b.ne            #0xcf0ea0
    // 0xcf0e90: r0 = Null
    //     0xcf0e90: mov             x0, NULL
    // 0xcf0e94: LeaveFrame
    //     0xcf0e94: mov             SP, fp
    //     0xcf0e98: ldp             fp, lr, [SP], #0x10
    // 0xcf0e9c: ret
    //     0xcf0e9c: ret             
    // 0xcf0ea0: StoreField: r1->field_97 = r2
    //     0xcf0ea0: stur            w2, [x1, #0x97]
    // 0xcf0ea4: StoreField: r1->field_ab = rNULL
    //     0xcf0ea4: stur            NULL, [x1, #0xab]
    // 0xcf0ea8: r0 = markNeedsSemanticsUpdate()
    //     0xcf0ea8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf0eac: r0 = Null
    //     0xcf0eac: mov             x0, NULL
    // 0xcf0eb0: LeaveFrame
    //     0xcf0eb0: mov             SP, fp
    //     0xcf0eb4: ldp             fp, lr, [SP], #0x10
    // 0xcf0eb8: ret
    //     0xcf0eb8: ret             
    // 0xcf0ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0ebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0ec0: b               #0xcf0e80
  }
  set _ obscuringCharacter=(/* No info */) {
    // ** addr: 0xcf0ec4, size: 0xa4
    // 0xcf0ec4: EnterFrame
    //     0xcf0ec4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0ec8: mov             fp, SP
    // 0xcf0ecc: AllocStack(0x20)
    //     0xcf0ecc: sub             SP, SP, #0x20
    // 0xcf0ed0: SetupParameters(RenderEditable this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf0ed0: stur            x1, [fp, #-8]
    //     0xcf0ed4: mov             x16, x2
    //     0xcf0ed8: mov             x2, x1
    //     0xcf0edc: mov             x1, x16
    //     0xcf0ee0: stur            x1, [fp, #-0x10]
    // 0xcf0ee4: CheckStackOverflow
    //     0xcf0ee4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0ee8: cmp             SP, x16
    //     0xcf0eec: b.ls            #0xcf0f60
    // 0xcf0ef0: LoadField: r0 = r2->field_93
    //     0xcf0ef0: ldur            w0, [x2, #0x93]
    // 0xcf0ef4: DecompressPointer r0
    //     0xcf0ef4: add             x0, x0, HEAP, lsl #32
    // 0xcf0ef8: r3 = LoadClassIdInstr(r0)
    //     0xcf0ef8: ldur            x3, [x0, #-1]
    //     0xcf0efc: ubfx            x3, x3, #0xc, #0x14
    // 0xcf0f00: stp             x1, x0, [SP]
    // 0xcf0f04: mov             x0, x3
    // 0xcf0f08: mov             lr, x0
    // 0xcf0f0c: ldr             lr, [x21, lr, lsl #3]
    // 0xcf0f10: blr             lr
    // 0xcf0f14: tbnz            w0, #4, #0xcf0f28
    // 0xcf0f18: r0 = Null
    //     0xcf0f18: mov             x0, NULL
    // 0xcf0f1c: LeaveFrame
    //     0xcf0f1c: mov             SP, fp
    //     0xcf0f20: ldp             fp, lr, [SP], #0x10
    // 0xcf0f24: ret
    //     0xcf0f24: ret             
    // 0xcf0f28: ldur            x1, [fp, #-8]
    // 0xcf0f2c: ldur            x0, [fp, #-0x10]
    // 0xcf0f30: StoreField: r1->field_93 = r0
    //     0xcf0f30: stur            w0, [x1, #0x93]
    //     0xcf0f34: ldurb           w16, [x1, #-1]
    //     0xcf0f38: ldurb           w17, [x0, #-1]
    //     0xcf0f3c: and             x16, x17, x16, lsr #2
    //     0xcf0f40: tst             x16, HEAP, lsr #32
    //     0xcf0f44: b.eq            #0xcf0f4c
    //     0xcf0f48: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf0f4c: r0 = markNeedsLayout()
    //     0xcf0f4c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf0f50: r0 = Null
    //     0xcf0f50: mov             x0, NULL
    // 0xcf0f54: LeaveFrame
    //     0xcf0f54: mov             SP, fp
    //     0xcf0f58: ldp             fp, lr, [SP], #0x10
    // 0xcf0f5c: ret
    //     0xcf0f5c: ret             
    // 0xcf0f60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0f60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0f64: b               #0xcf0ef0
  }
  set _ offset=(/* No info */) {
    // ** addr: 0xcf0f68, size: 0xe8
    // 0xcf0f68: EnterFrame
    //     0xcf0f68: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0f6c: mov             fp, SP
    // 0xcf0f70: AllocStack(0x18)
    //     0xcf0f70: sub             SP, SP, #0x18
    // 0xcf0f74: SetupParameters(RenderEditable this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xcf0f74: mov             x3, x1
    //     0xcf0f78: mov             x0, x2
    //     0xcf0f7c: stur            x1, [fp, #-0x10]
    //     0xcf0f80: stur            x2, [fp, #-0x18]
    // 0xcf0f84: CheckStackOverflow
    //     0xcf0f84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf0f88: cmp             SP, x16
    //     0xcf0f8c: b.ls            #0xcf1048
    // 0xcf0f90: LoadField: r4 = r3->field_db
    //     0xcf0f90: ldur            w4, [x3, #0xdb]
    // 0xcf0f94: DecompressPointer r4
    //     0xcf0f94: add             x4, x4, HEAP, lsl #32
    // 0xcf0f98: stur            x4, [fp, #-8]
    // 0xcf0f9c: cmp             w4, w0
    // 0xcf0fa0: b.ne            #0xcf0fb4
    // 0xcf0fa4: r0 = Null
    //     0xcf0fa4: mov             x0, NULL
    // 0xcf0fa8: LeaveFrame
    //     0xcf0fa8: mov             SP, fp
    //     0xcf0fac: ldp             fp, lr, [SP], #0x10
    // 0xcf0fb0: ret
    //     0xcf0fb0: ret             
    // 0xcf0fb4: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xcf0fb4: ldur            w1, [x3, #0x17]
    // 0xcf0fb8: DecompressPointer r1
    //     0xcf0fb8: add             x1, x1, HEAP, lsl #32
    // 0xcf0fbc: cmp             w1, NULL
    // 0xcf0fc0: b.eq            #0xcf0fe0
    // 0xcf0fc4: mov             x2, x3
    // 0xcf0fc8: r1 = Function 'markNeedsPaint':.
    //     0xcf0fc8: add             x1, PP, #0xad, lsl #12  ; [pp+0xad650] AnonymousClosure: (0xbf0650), in [package:flutter/src/rendering/editable.dart] RenderEditable::markNeedsPaint (0xbf05e0)
    //     0xcf0fcc: ldr             x1, [x1, #0x650]
    // 0xcf0fd0: r0 = AllocateClosure()
    //     0xcf0fd0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf0fd4: ldur            x1, [fp, #-8]
    // 0xcf0fd8: mov             x2, x0
    // 0xcf0fdc: r0 = removeListener()
    //     0xcf0fdc: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xcf0fe0: ldur            x3, [fp, #-0x10]
    // 0xcf0fe4: ldur            x0, [fp, #-0x18]
    // 0xcf0fe8: StoreField: r3->field_db = r0
    //     0xcf0fe8: stur            w0, [x3, #0xdb]
    //     0xcf0fec: ldurb           w16, [x3, #-1]
    //     0xcf0ff0: ldurb           w17, [x0, #-1]
    //     0xcf0ff4: and             x16, x17, x16, lsr #2
    //     0xcf0ff8: tst             x16, HEAP, lsr #32
    //     0xcf0ffc: b.eq            #0xcf1004
    //     0xcf1000: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf1004: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xcf1004: ldur            w0, [x3, #0x17]
    // 0xcf1008: DecompressPointer r0
    //     0xcf1008: add             x0, x0, HEAP, lsl #32
    // 0xcf100c: cmp             w0, NULL
    // 0xcf1010: b.eq            #0xcf1030
    // 0xcf1014: mov             x2, x3
    // 0xcf1018: r1 = Function 'markNeedsPaint':.
    //     0xcf1018: add             x1, PP, #0xad, lsl #12  ; [pp+0xad650] AnonymousClosure: (0xbf0650), in [package:flutter/src/rendering/editable.dart] RenderEditable::markNeedsPaint (0xbf05e0)
    //     0xcf101c: ldr             x1, [x1, #0x650]
    // 0xcf1020: r0 = AllocateClosure()
    //     0xcf1020: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf1024: ldur            x1, [fp, #-0x18]
    // 0xcf1028: mov             x2, x0
    // 0xcf102c: r0 = addListener()
    //     0xcf102c: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xcf1030: ldur            x1, [fp, #-0x10]
    // 0xcf1034: r0 = markNeedsLayout()
    //     0xcf1034: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf1038: r0 = Null
    //     0xcf1038: mov             x0, NULL
    // 0xcf103c: LeaveFrame
    //     0xcf103c: mov             SP, fp
    //     0xcf1040: ldp             fp, lr, [SP], #0x10
    // 0xcf1044: ret
    //     0xcf1044: ret             
    // 0xcf1048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf104c: b               #0xcf0f90
  }
  set _ selection=(/* No info */) {
    // ** addr: 0xcf1050, size: 0xa4
    // 0xcf1050: EnterFrame
    //     0xcf1050: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1054: mov             fp, SP
    // 0xcf1058: AllocStack(0x20)
    //     0xcf1058: sub             SP, SP, #0x20
    // 0xcf105c: SetupParameters(RenderEditable this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf105c: mov             x0, x2
    //     0xcf1060: stur            x1, [fp, #-8]
    //     0xcf1064: stur            x2, [fp, #-0x10]
    // 0xcf1068: CheckStackOverflow
    //     0xcf1068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf106c: cmp             SP, x16
    //     0xcf1070: b.ls            #0xcf10ec
    // 0xcf1074: LoadField: r2 = r1->field_d7
    //     0xcf1074: ldur            w2, [x1, #0xd7]
    // 0xcf1078: DecompressPointer r2
    //     0xcf1078: add             x2, x2, HEAP, lsl #32
    // 0xcf107c: stp             x0, x2, [SP]
    // 0xcf1080: r0 = ==()
    //     0xcf1080: bl              #0x128f7e8  ; [package:flutter/src/services/text_editing.dart] TextSelection::==
    // 0xcf1084: tbnz            w0, #4, #0xcf1098
    // 0xcf1088: r0 = Null
    //     0xcf1088: mov             x0, NULL
    // 0xcf108c: LeaveFrame
    //     0xcf108c: mov             SP, fp
    //     0xcf1090: ldp             fp, lr, [SP], #0x10
    // 0xcf1094: ret
    //     0xcf1094: ret             
    // 0xcf1098: ldur            x3, [fp, #-8]
    // 0xcf109c: ldur            x0, [fp, #-0x10]
    // 0xcf10a0: StoreField: r3->field_d7 = r0
    //     0xcf10a0: stur            w0, [x3, #0xd7]
    //     0xcf10a4: ldurb           w16, [x3, #-1]
    //     0xcf10a8: ldurb           w17, [x0, #-1]
    //     0xcf10ac: and             x16, x17, x16, lsr #2
    //     0xcf10b0: tst             x16, HEAP, lsr #32
    //     0xcf10b4: b.eq            #0xcf10bc
    //     0xcf10b8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf10bc: LoadField: r1 = r3->field_77
    //     0xcf10bc: ldur            w1, [x3, #0x77]
    // 0xcf10c0: DecompressPointer r1
    //     0xcf10c0: add             x1, x1, HEAP, lsl #32
    // 0xcf10c4: ldur            x2, [fp, #-0x10]
    // 0xcf10c8: r0 = highlightedRange=()
    //     0xcf10c8: bl              #0xcf010c  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::highlightedRange=
    // 0xcf10cc: ldur            x1, [fp, #-8]
    // 0xcf10d0: r0 = markNeedsPaint()
    //     0xcf10d0: bl              #0xbf05e0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::markNeedsPaint
    // 0xcf10d4: ldur            x1, [fp, #-8]
    // 0xcf10d8: r0 = markNeedsSemanticsUpdate()
    //     0xcf10d8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf10dc: r0 = Null
    //     0xcf10dc: mov             x0, NULL
    // 0xcf10e0: LeaveFrame
    //     0xcf10e0: mov             SP, fp
    //     0xcf10e4: ldp             fp, lr, [SP], #0x10
    // 0xcf10e8: ret
    //     0xcf10e8: ret             
    // 0xcf10ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf10ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf10f0: b               #0xcf1074
  }
  set _ locale=(/* No info */) {
    // ** addr: 0xcf10f4, size: 0x90
    // 0xcf10f4: EnterFrame
    //     0xcf10f4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf10f8: mov             fp, SP
    // 0xcf10fc: AllocStack(0x28)
    //     0xcf10fc: sub             SP, SP, #0x28
    // 0xcf1100: SetupParameters(RenderEditable this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xcf1100: stur            x1, [fp, #-0x10]
    //     0xcf1104: stur            x2, [fp, #-0x18]
    // 0xcf1108: CheckStackOverflow
    //     0xcf1108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf110c: cmp             SP, x16
    //     0xcf1110: b.ls            #0xcf117c
    // 0xcf1114: LoadField: r3 = r1->field_a7
    //     0xcf1114: ldur            w3, [x1, #0xa7]
    // 0xcf1118: DecompressPointer r3
    //     0xcf1118: add             x3, x3, HEAP, lsl #32
    // 0xcf111c: stur            x3, [fp, #-8]
    // 0xcf1120: LoadField: r0 = r3->field_27
    //     0xcf1120: ldur            w0, [x3, #0x27]
    // 0xcf1124: DecompressPointer r0
    //     0xcf1124: add             x0, x0, HEAP, lsl #32
    // 0xcf1128: r4 = LoadClassIdInstr(r0)
    //     0xcf1128: ldur            x4, [x0, #-1]
    //     0xcf112c: ubfx            x4, x4, #0xc, #0x14
    // 0xcf1130: stp             x2, x0, [SP]
    // 0xcf1134: mov             x0, x4
    // 0xcf1138: mov             lr, x0
    // 0xcf113c: ldr             lr, [x21, lr, lsl #3]
    // 0xcf1140: blr             lr
    // 0xcf1144: tbnz            w0, #4, #0xcf1158
    // 0xcf1148: r0 = Null
    //     0xcf1148: mov             x0, NULL
    // 0xcf114c: LeaveFrame
    //     0xcf114c: mov             SP, fp
    //     0xcf1150: ldp             fp, lr, [SP], #0x10
    // 0xcf1154: ret
    //     0xcf1154: ret             
    // 0xcf1158: ldur            x1, [fp, #-8]
    // 0xcf115c: ldur            x2, [fp, #-0x18]
    // 0xcf1160: r0 = locale=()
    //     0xcf1160: bl              #0xb1cf68  ; [package:flutter/src/painting/text_painter.dart] TextPainter::locale=
    // 0xcf1164: ldur            x1, [fp, #-0x10]
    // 0xcf1168: r0 = markNeedsLayout()
    //     0xcf1168: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf116c: r0 = Null
    //     0xcf116c: mov             x0, NULL
    // 0xcf1170: LeaveFrame
    //     0xcf1170: mov             SP, fp
    //     0xcf1174: ldp             fp, lr, [SP], #0x10
    // 0xcf1178: ret
    //     0xcf1178: ret             
    // 0xcf117c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf117c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1180: b               #0xcf1114
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcf1184, size: 0x74
    // 0xcf1184: EnterFrame
    //     0xcf1184: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1188: mov             fp, SP
    // 0xcf118c: AllocStack(0x8)
    //     0xcf118c: sub             SP, SP, #8
    // 0xcf1190: SetupParameters(RenderEditable this /* r1 => r0, fp-0x8 */)
    //     0xcf1190: mov             x0, x1
    //     0xcf1194: stur            x1, [fp, #-8]
    // 0xcf1198: CheckStackOverflow
    //     0xcf1198: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf119c: cmp             SP, x16
    //     0xcf11a0: b.ls            #0xcf11f0
    // 0xcf11a4: LoadField: r1 = r0->field_a7
    //     0xcf11a4: ldur            w1, [x0, #0xa7]
    // 0xcf11a8: DecompressPointer r1
    //     0xcf11a8: add             x1, x1, HEAP, lsl #32
    // 0xcf11ac: LoadField: r3 = r1->field_1b
    //     0xcf11ac: ldur            w3, [x1, #0x1b]
    // 0xcf11b0: DecompressPointer r3
    //     0xcf11b0: add             x3, x3, HEAP, lsl #32
    // 0xcf11b4: cmp             w3, w2
    // 0xcf11b8: b.ne            #0xcf11cc
    // 0xcf11bc: r0 = Null
    //     0xcf11bc: mov             x0, NULL
    // 0xcf11c0: LeaveFrame
    //     0xcf11c0: mov             SP, fp
    //     0xcf11c4: ldp             fp, lr, [SP], #0x10
    // 0xcf11c8: ret
    //     0xcf11c8: ret             
    // 0xcf11cc: r0 = textDirection=()
    //     0xcf11cc: bl              #0xb1d1c8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textDirection=
    // 0xcf11d0: ldur            x1, [fp, #-8]
    // 0xcf11d4: r0 = markNeedsLayout()
    //     0xcf11d4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf11d8: ldur            x1, [fp, #-8]
    // 0xcf11dc: r0 = markNeedsSemanticsUpdate()
    //     0xcf11dc: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf11e0: r0 = Null
    //     0xcf11e0: mov             x0, NULL
    // 0xcf11e4: LeaveFrame
    //     0xcf11e4: mov             SP, fp
    //     0xcf11e8: ldp             fp, lr, [SP], #0x10
    // 0xcf11ec: ret
    //     0xcf11ec: ret             
    // 0xcf11f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf11f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf11f4: b               #0xcf11a4
  }
  set _ textAlign=(/* No info */) {
    // ** addr: 0xcf11f8, size: 0x94
    // 0xcf11f8: EnterFrame
    //     0xcf11f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf11fc: mov             fp, SP
    // 0xcf1200: AllocStack(0x8)
    //     0xcf1200: sub             SP, SP, #8
    // 0xcf1204: SetupParameters(RenderEditable this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xcf1204: mov             x0, x2
    //     0xcf1208: mov             x2, x1
    //     0xcf120c: stur            x1, [fp, #-8]
    // 0xcf1210: CheckStackOverflow
    //     0xcf1210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1214: cmp             SP, x16
    //     0xcf1218: b.ls            #0xcf1284
    // 0xcf121c: LoadField: r1 = r2->field_a7
    //     0xcf121c: ldur            w1, [x2, #0xa7]
    // 0xcf1220: DecompressPointer r1
    //     0xcf1220: add             x1, x1, HEAP, lsl #32
    // 0xcf1224: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xcf1224: ldur            w3, [x1, #0x17]
    // 0xcf1228: DecompressPointer r3
    //     0xcf1228: add             x3, x3, HEAP, lsl #32
    // 0xcf122c: cmp             w3, w0
    // 0xcf1230: b.ne            #0xcf1244
    // 0xcf1234: r0 = Null
    //     0xcf1234: mov             x0, NULL
    // 0xcf1238: LeaveFrame
    //     0xcf1238: mov             SP, fp
    //     0xcf123c: ldp             fp, lr, [SP], #0x10
    // 0xcf1240: ret
    //     0xcf1240: ret             
    // 0xcf1244: cmp             w3, w0
    // 0xcf1248: b.eq            #0xcf126c
    // 0xcf124c: ArrayStore: r1[0] = r0  ; List_4
    //     0xcf124c: stur            w0, [x1, #0x17]
    //     0xcf1250: ldurb           w16, [x1, #-1]
    //     0xcf1254: ldurb           w17, [x0, #-1]
    //     0xcf1258: and             x16, x17, x16, lsr #2
    //     0xcf125c: tst             x16, HEAP, lsr #32
    //     0xcf1260: b.eq            #0xcf1268
    //     0xcf1264: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf1268: r0 = markNeedsLayout()
    //     0xcf1268: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xcf126c: ldur            x1, [fp, #-8]
    // 0xcf1270: r0 = markNeedsLayout()
    //     0xcf1270: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf1274: r0 = Null
    //     0xcf1274: mov             x0, NULL
    // 0xcf1278: LeaveFrame
    //     0xcf1278: mov             SP, fp
    //     0xcf127c: ldp             fp, lr, [SP], #0x10
    // 0xcf1280: ret
    //     0xcf1280: ret             
    // 0xcf1284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1284: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1288: b               #0xcf121c
  }
  set _ textScaler=(/* No info */) {
    // ** addr: 0xcf128c, size: 0x90
    // 0xcf128c: EnterFrame
    //     0xcf128c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1290: mov             fp, SP
    // 0xcf1294: AllocStack(0x28)
    //     0xcf1294: sub             SP, SP, #0x28
    // 0xcf1298: SetupParameters(RenderEditable this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xcf1298: stur            x1, [fp, #-0x10]
    //     0xcf129c: stur            x2, [fp, #-0x18]
    // 0xcf12a0: CheckStackOverflow
    //     0xcf12a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf12a4: cmp             SP, x16
    //     0xcf12a8: b.ls            #0xcf1314
    // 0xcf12ac: LoadField: r3 = r1->field_a7
    //     0xcf12ac: ldur            w3, [x1, #0xa7]
    // 0xcf12b0: DecompressPointer r3
    //     0xcf12b0: add             x3, x3, HEAP, lsl #32
    // 0xcf12b4: stur            x3, [fp, #-8]
    // 0xcf12b8: LoadField: r0 = r3->field_1f
    //     0xcf12b8: ldur            w0, [x3, #0x1f]
    // 0xcf12bc: DecompressPointer r0
    //     0xcf12bc: add             x0, x0, HEAP, lsl #32
    // 0xcf12c0: r4 = LoadClassIdInstr(r0)
    //     0xcf12c0: ldur            x4, [x0, #-1]
    //     0xcf12c4: ubfx            x4, x4, #0xc, #0x14
    // 0xcf12c8: stp             x2, x0, [SP]
    // 0xcf12cc: mov             x0, x4
    // 0xcf12d0: mov             lr, x0
    // 0xcf12d4: ldr             lr, [x21, lr, lsl #3]
    // 0xcf12d8: blr             lr
    // 0xcf12dc: tbnz            w0, #4, #0xcf12f0
    // 0xcf12e0: r0 = Null
    //     0xcf12e0: mov             x0, NULL
    // 0xcf12e4: LeaveFrame
    //     0xcf12e4: mov             SP, fp
    //     0xcf12e8: ldp             fp, lr, [SP], #0x10
    // 0xcf12ec: ret
    //     0xcf12ec: ret             
    // 0xcf12f0: ldur            x1, [fp, #-8]
    // 0xcf12f4: ldur            x2, [fp, #-0x18]
    // 0xcf12f8: r0 = textScaler=()
    //     0xcf12f8: bl              #0xb1d0b0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textScaler=
    // 0xcf12fc: ldur            x1, [fp, #-0x10]
    // 0xcf1300: r0 = markNeedsLayout()
    //     0xcf1300: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf1304: r0 = Null
    //     0xcf1304: mov             x0, NULL
    // 0xcf1308: LeaveFrame
    //     0xcf1308: mov             SP, fp
    //     0xcf130c: ldp             fp, lr, [SP], #0x10
    // 0xcf1310: ret
    //     0xcf1310: ret             
    // 0xcf1314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1314: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1318: b               #0xcf12ac
  }
  set _ selectionColor=(/* No info */) {
    // ** addr: 0xcf131c, size: 0x3c
    // 0xcf131c: EnterFrame
    //     0xcf131c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1320: mov             fp, SP
    // 0xcf1324: CheckStackOverflow
    //     0xcf1324: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1328: cmp             SP, x16
    //     0xcf132c: b.ls            #0xcf1350
    // 0xcf1330: LoadField: r0 = r1->field_77
    //     0xcf1330: ldur            w0, [x1, #0x77]
    // 0xcf1334: DecompressPointer r0
    //     0xcf1334: add             x0, x0, HEAP, lsl #32
    // 0xcf1338: mov             x1, x0
    // 0xcf133c: r0 = highlightColor=()
    //     0xcf133c: bl              #0xcf01ec  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::highlightColor=
    // 0xcf1340: r0 = Null
    //     0xcf1340: mov             x0, NULL
    // 0xcf1344: LeaveFrame
    //     0xcf1344: mov             SP, fp
    //     0xcf1348: ldp             fp, lr, [SP], #0x10
    // 0xcf134c: ret
    //     0xcf134c: ret             
    // 0xcf1350: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1350: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1354: b               #0xcf1330
  }
  set _ strutStyle=(/* No info */) {
    // ** addr: 0xcf1358, size: 0x90
    // 0xcf1358: EnterFrame
    //     0xcf1358: stp             fp, lr, [SP, #-0x10]!
    //     0xcf135c: mov             fp, SP
    // 0xcf1360: AllocStack(0x28)
    //     0xcf1360: sub             SP, SP, #0x28
    // 0xcf1364: SetupParameters(RenderEditable this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xcf1364: stur            x1, [fp, #-0x10]
    //     0xcf1368: stur            x2, [fp, #-0x18]
    // 0xcf136c: CheckStackOverflow
    //     0xcf136c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1370: cmp             SP, x16
    //     0xcf1374: b.ls            #0xcf13e0
    // 0xcf1378: LoadField: r3 = r1->field_a7
    //     0xcf1378: ldur            w3, [x1, #0xa7]
    // 0xcf137c: DecompressPointer r3
    //     0xcf137c: add             x3, x3, HEAP, lsl #32
    // 0xcf1380: stur            x3, [fp, #-8]
    // 0xcf1384: LoadField: r0 = r3->field_2f
    //     0xcf1384: ldur            w0, [x3, #0x2f]
    // 0xcf1388: DecompressPointer r0
    //     0xcf1388: add             x0, x0, HEAP, lsl #32
    // 0xcf138c: r4 = LoadClassIdInstr(r0)
    //     0xcf138c: ldur            x4, [x0, #-1]
    //     0xcf1390: ubfx            x4, x4, #0xc, #0x14
    // 0xcf1394: stp             x2, x0, [SP]
    // 0xcf1398: mov             x0, x4
    // 0xcf139c: mov             lr, x0
    // 0xcf13a0: ldr             lr, [x21, lr, lsl #3]
    // 0xcf13a4: blr             lr
    // 0xcf13a8: tbnz            w0, #4, #0xcf13bc
    // 0xcf13ac: r0 = Null
    //     0xcf13ac: mov             x0, NULL
    // 0xcf13b0: LeaveFrame
    //     0xcf13b0: mov             SP, fp
    //     0xcf13b4: ldp             fp, lr, [SP], #0x10
    // 0xcf13b8: ret
    //     0xcf13b8: ret             
    // 0xcf13bc: ldur            x1, [fp, #-8]
    // 0xcf13c0: ldur            x2, [fp, #-0x18]
    // 0xcf13c4: r0 = strutStyle=()
    //     0xcf13c4: bl              #0xb1cec4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::strutStyle=
    // 0xcf13c8: ldur            x1, [fp, #-0x10]
    // 0xcf13cc: r0 = markNeedsLayout()
    //     0xcf13cc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf13d0: r0 = Null
    //     0xcf13d0: mov             x0, NULL
    // 0xcf13d4: LeaveFrame
    //     0xcf13d4: mov             SP, fp
    //     0xcf13d8: ldp             fp, lr, [SP], #0x10
    // 0xcf13dc: ret
    //     0xcf13dc: ret             
    // 0xcf13e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf13e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf13e4: b               #0xcf1378
  }
  set _ expands=(/* No info */) {
    // ** addr: 0xcf13e8, size: 0x54
    // 0xcf13e8: EnterFrame
    //     0xcf13e8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf13ec: mov             fp, SP
    // 0xcf13f0: CheckStackOverflow
    //     0xcf13f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf13f4: cmp             SP, x16
    //     0xcf13f8: b.ls            #0xcf1434
    // 0xcf13fc: LoadField: r0 = r1->field_d3
    //     0xcf13fc: ldur            w0, [x1, #0xd3]
    // 0xcf1400: DecompressPointer r0
    //     0xcf1400: add             x0, x0, HEAP, lsl #32
    // 0xcf1404: cmp             w0, w2
    // 0xcf1408: b.ne            #0xcf141c
    // 0xcf140c: r0 = Null
    //     0xcf140c: mov             x0, NULL
    // 0xcf1410: LeaveFrame
    //     0xcf1410: mov             SP, fp
    //     0xcf1414: ldp             fp, lr, [SP], #0x10
    // 0xcf1418: ret
    //     0xcf1418: ret             
    // 0xcf141c: StoreField: r1->field_d3 = r2
    //     0xcf141c: stur            w2, [x1, #0xd3]
    // 0xcf1420: r0 = markNeedsLayout()
    //     0xcf1420: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf1424: r0 = Null
    //     0xcf1424: mov             x0, NULL
    // 0xcf1428: LeaveFrame
    //     0xcf1428: mov             SP, fp
    //     0xcf142c: ldp             fp, lr, [SP], #0x10
    // 0xcf1430: ret
    //     0xcf1430: ret             
    // 0xcf1434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1434: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1438: b               #0xcf13fc
  }
  set _ maxLines=(/* No info */) {
    // ** addr: 0xcf143c, size: 0xec
    // 0xcf143c: EnterFrame
    //     0xcf143c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1440: mov             fp, SP
    // 0xcf1444: AllocStack(0x8)
    //     0xcf1444: sub             SP, SP, #8
    // 0xcf1448: SetupParameters(RenderEditable this /* r1 => r3, fp-0x8 */)
    //     0xcf1448: mov             x3, x1
    //     0xcf144c: stur            x1, [fp, #-8]
    // 0xcf1450: CheckStackOverflow
    //     0xcf1450: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1454: cmp             SP, x16
    //     0xcf1458: b.ls            #0xcf1520
    // 0xcf145c: LoadField: r0 = r3->field_cb
    //     0xcf145c: ldur            w0, [x3, #0xcb]
    // 0xcf1460: DecompressPointer r0
    //     0xcf1460: add             x0, x0, HEAP, lsl #32
    // 0xcf1464: cmp             w0, w2
    // 0xcf1468: b.ne            #0xcf147c
    // 0xcf146c: r0 = Null
    //     0xcf146c: mov             x0, NULL
    // 0xcf1470: LeaveFrame
    //     0xcf1470: mov             SP, fp
    //     0xcf1474: ldp             fp, lr, [SP], #0x10
    // 0xcf1478: ret
    //     0xcf1478: ret             
    // 0xcf147c: StoreField: r3->field_cb = r2
    //     0xcf147c: stur            w2, [x3, #0xcb]
    // 0xcf1480: LoadField: r1 = r3->field_a7
    //     0xcf1480: ldur            w1, [x3, #0xa7]
    // 0xcf1484: DecompressPointer r1
    //     0xcf1484: add             x1, x1, HEAP, lsl #32
    // 0xcf1488: cmp             w2, #2
    // 0xcf148c: b.ne            #0xcf1498
    // 0xcf1490: r0 = 2
    //     0xcf1490: mov             x0, #2
    // 0xcf1494: b               #0xcf149c
    // 0xcf1498: r0 = Null
    //     0xcf1498: mov             x0, NULL
    // 0xcf149c: LoadField: r2 = r1->field_2b
    //     0xcf149c: ldur            w2, [x1, #0x2b]
    // 0xcf14a0: DecompressPointer r2
    //     0xcf14a0: add             x2, x2, HEAP, lsl #32
    // 0xcf14a4: cmp             w2, w0
    // 0xcf14a8: b.eq            #0xcf1508
    // 0xcf14ac: and             w16, w2, w0
    // 0xcf14b0: branchIfSmi(r16, 0xcf14e4)
    //     0xcf14b0: tbz             w16, #0, #0xcf14e4
    // 0xcf14b4: r16 = LoadClassIdInstr(r2)
    //     0xcf14b4: ldur            x16, [x2, #-1]
    //     0xcf14b8: ubfx            x16, x16, #0xc, #0x14
    // 0xcf14bc: cmp             x16, #0x3d
    // 0xcf14c0: b.ne            #0xcf14e4
    // 0xcf14c4: r16 = LoadClassIdInstr(r0)
    //     0xcf14c4: ldur            x16, [x0, #-1]
    //     0xcf14c8: ubfx            x16, x16, #0xc, #0x14
    // 0xcf14cc: cmp             x16, #0x3d
    // 0xcf14d0: b.ne            #0xcf14e4
    // 0xcf14d4: LoadField: r16 = r2->field_7
    //     0xcf14d4: ldur            x16, [x2, #7]
    // 0xcf14d8: LoadField: r17 = r0->field_7
    //     0xcf14d8: ldur            x17, [x0, #7]
    // 0xcf14dc: cmp             x16, x17
    // 0xcf14e0: b.eq            #0xcf1508
    // 0xcf14e4: StoreField: r1->field_2b = r0
    //     0xcf14e4: stur            w0, [x1, #0x2b]
    //     0xcf14e8: tbz             w0, #0, #0xcf1504
    //     0xcf14ec: ldurb           w16, [x1, #-1]
    //     0xcf14f0: ldurb           w17, [x0, #-1]
    //     0xcf14f4: and             x16, x17, x16, lsr #2
    //     0xcf14f8: tst             x16, HEAP, lsr #32
    //     0xcf14fc: b.eq            #0xcf1504
    //     0xcf1500: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf1504: r0 = markNeedsLayout()
    //     0xcf1504: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xcf1508: ldur            x1, [fp, #-8]
    // 0xcf150c: r0 = markNeedsLayout()
    //     0xcf150c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf1510: r0 = Null
    //     0xcf1510: mov             x0, NULL
    // 0xcf1514: LeaveFrame
    //     0xcf1514: mov             SP, fp
    //     0xcf1518: ldp             fp, lr, [SP], #0x10
    // 0xcf151c: ret
    //     0xcf151c: ret             
    // 0xcf1520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1520: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1524: b               #0xcf145c
  }
  set _ hasFocus=(/* No info */) {
    // ** addr: 0xcf1528, size: 0x54
    // 0xcf1528: EnterFrame
    //     0xcf1528: stp             fp, lr, [SP, #-0x10]!
    //     0xcf152c: mov             fp, SP
    // 0xcf1530: CheckStackOverflow
    //     0xcf1530: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1534: cmp             SP, x16
    //     0xcf1538: b.ls            #0xcf1574
    // 0xcf153c: LoadField: r0 = r1->field_bf
    //     0xcf153c: ldur            w0, [x1, #0xbf]
    // 0xcf1540: DecompressPointer r0
    //     0xcf1540: add             x0, x0, HEAP, lsl #32
    // 0xcf1544: cmp             w0, w2
    // 0xcf1548: b.ne            #0xcf155c
    // 0xcf154c: r0 = Null
    //     0xcf154c: mov             x0, NULL
    // 0xcf1550: LeaveFrame
    //     0xcf1550: mov             SP, fp
    //     0xcf1554: ldp             fp, lr, [SP], #0x10
    // 0xcf1558: ret
    //     0xcf1558: ret             
    // 0xcf155c: StoreField: r1->field_bf = r2
    //     0xcf155c: stur            w2, [x1, #0xbf]
    // 0xcf1560: r0 = markNeedsSemanticsUpdate()
    //     0xcf1560: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf1564: r0 = Null
    //     0xcf1564: mov             x0, NULL
    // 0xcf1568: LeaveFrame
    //     0xcf1568: mov             SP, fp
    //     0xcf156c: ldp             fp, lr, [SP], #0x10
    // 0xcf1570: ret
    //     0xcf1570: ret             
    // 0xcf1574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1578: b               #0xcf153c
  }
  set _ readOnly=(/* No info */) {
    // ** addr: 0xcf157c, size: 0x54
    // 0xcf157c: EnterFrame
    //     0xcf157c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1580: mov             fp, SP
    // 0xcf1584: CheckStackOverflow
    //     0xcf1584: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1588: cmp             SP, x16
    //     0xcf158c: b.ls            #0xcf15c8
    // 0xcf1590: LoadField: r0 = r1->field_c7
    //     0xcf1590: ldur            w0, [x1, #0xc7]
    // 0xcf1594: DecompressPointer r0
    //     0xcf1594: add             x0, x0, HEAP, lsl #32
    // 0xcf1598: cmp             w0, w2
    // 0xcf159c: b.ne            #0xcf15b0
    // 0xcf15a0: r0 = Null
    //     0xcf15a0: mov             x0, NULL
    // 0xcf15a4: LeaveFrame
    //     0xcf15a4: mov             SP, fp
    //     0xcf15a8: ldp             fp, lr, [SP], #0x10
    // 0xcf15ac: ret
    //     0xcf15ac: ret             
    // 0xcf15b0: StoreField: r1->field_c7 = r2
    //     0xcf15b0: stur            w2, [x1, #0xc7]
    // 0xcf15b4: r0 = markNeedsSemanticsUpdate()
    //     0xcf15b4: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf15b8: r0 = Null
    //     0xcf15b8: mov             x0, NULL
    // 0xcf15bc: LeaveFrame
    //     0xcf15bc: mov             SP, fp
    //     0xcf15c0: ldp             fp, lr, [SP], #0x10
    // 0xcf15c4: ret
    //     0xcf15c4: ret             
    // 0xcf15c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf15c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf15cc: b               #0xcf1590
  }
  set _ forceLine=(/* No info */) {
    // ** addr: 0xcf15d0, size: 0x54
    // 0xcf15d0: EnterFrame
    //     0xcf15d0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf15d4: mov             fp, SP
    // 0xcf15d8: CheckStackOverflow
    //     0xcf15d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf15dc: cmp             SP, x16
    //     0xcf15e0: b.ls            #0xcf161c
    // 0xcf15e4: LoadField: r0 = r1->field_c3
    //     0xcf15e4: ldur            w0, [x1, #0xc3]
    // 0xcf15e8: DecompressPointer r0
    //     0xcf15e8: add             x0, x0, HEAP, lsl #32
    // 0xcf15ec: cmp             w0, w2
    // 0xcf15f0: b.ne            #0xcf1604
    // 0xcf15f4: r0 = Null
    //     0xcf15f4: mov             x0, NULL
    // 0xcf15f8: LeaveFrame
    //     0xcf15f8: mov             SP, fp
    //     0xcf15fc: ldp             fp, lr, [SP], #0x10
    // 0xcf1600: ret
    //     0xcf1600: ret             
    // 0xcf1604: StoreField: r1->field_c3 = r2
    //     0xcf1604: stur            w2, [x1, #0xc3]
    // 0xcf1608: r0 = markNeedsLayout()
    //     0xcf1608: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf160c: r0 = Null
    //     0xcf160c: mov             x0, NULL
    // 0xcf1610: LeaveFrame
    //     0xcf1610: mov             SP, fp
    //     0xcf1614: ldp             fp, lr, [SP], #0x10
    // 0xcf1618: ret
    //     0xcf1618: ret             
    // 0xcf161c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf161c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1620: b               #0xcf15e4
  }
  set _ showCursor=(/* No info */) {
    // ** addr: 0xcf1624, size: 0xf4
    // 0xcf1624: EnterFrame
    //     0xcf1624: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1628: mov             fp, SP
    // 0xcf162c: AllocStack(0x18)
    //     0xcf162c: sub             SP, SP, #0x18
    // 0xcf1630: SetupParameters(RenderEditable this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xcf1630: mov             x3, x1
    //     0xcf1634: mov             x0, x2
    //     0xcf1638: stur            x1, [fp, #-0x10]
    //     0xcf163c: stur            x2, [fp, #-0x18]
    // 0xcf1640: CheckStackOverflow
    //     0xcf1640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1644: cmp             SP, x16
    //     0xcf1648: b.ls            #0xcf1710
    // 0xcf164c: LoadField: r4 = r3->field_bb
    //     0xcf164c: ldur            w4, [x3, #0xbb]
    // 0xcf1650: DecompressPointer r4
    //     0xcf1650: add             x4, x4, HEAP, lsl #32
    // 0xcf1654: stur            x4, [fp, #-8]
    // 0xcf1658: cmp             w4, w0
    // 0xcf165c: b.ne            #0xcf1670
    // 0xcf1660: r0 = Null
    //     0xcf1660: mov             x0, NULL
    // 0xcf1664: LeaveFrame
    //     0xcf1664: mov             SP, fp
    //     0xcf1668: ldp             fp, lr, [SP], #0x10
    // 0xcf166c: ret
    //     0xcf166c: ret             
    // 0xcf1670: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xcf1670: ldur            w1, [x3, #0x17]
    // 0xcf1674: DecompressPointer r1
    //     0xcf1674: add             x1, x1, HEAP, lsl #32
    // 0xcf1678: cmp             w1, NULL
    // 0xcf167c: b.eq            #0xcf169c
    // 0xcf1680: mov             x2, x3
    // 0xcf1684: r1 = Function '_showHideCursor@80245603':.
    //     0xcf1684: add             x1, PP, #0xad, lsl #12  ; [pp+0xad658] AnonymousClosure: (0xc06b74), in [package:flutter/src/rendering/editable.dart] RenderEditable::_showHideCursor (0xc06bac)
    //     0xcf1688: ldr             x1, [x1, #0x658]
    // 0xcf168c: r0 = AllocateClosure()
    //     0xcf168c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf1690: ldur            x1, [fp, #-8]
    // 0xcf1694: mov             x2, x0
    // 0xcf1698: r0 = removeListener()
    //     0xcf1698: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xcf169c: ldur            x2, [fp, #-0x10]
    // 0xcf16a0: ldur            x0, [fp, #-0x18]
    // 0xcf16a4: StoreField: r2->field_bb = r0
    //     0xcf16a4: stur            w0, [x2, #0xbb]
    //     0xcf16a8: ldurb           w16, [x2, #-1]
    //     0xcf16ac: ldurb           w17, [x0, #-1]
    //     0xcf16b0: and             x16, x17, x16, lsr #2
    //     0xcf16b4: tst             x16, HEAP, lsr #32
    //     0xcf16b8: b.eq            #0xcf16c0
    //     0xcf16bc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf16c0: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xcf16c0: ldur            w0, [x2, #0x17]
    // 0xcf16c4: DecompressPointer r0
    //     0xcf16c4: add             x0, x0, HEAP, lsl #32
    // 0xcf16c8: cmp             w0, NULL
    // 0xcf16cc: b.eq            #0xcf1700
    // 0xcf16d0: mov             x1, x2
    // 0xcf16d4: r0 = _showHideCursor()
    //     0xcf16d4: bl              #0xc06bac  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_showHideCursor
    // 0xcf16d8: ldur            x2, [fp, #-0x10]
    // 0xcf16dc: LoadField: r0 = r2->field_bb
    //     0xcf16dc: ldur            w0, [x2, #0xbb]
    // 0xcf16e0: DecompressPointer r0
    //     0xcf16e0: add             x0, x0, HEAP, lsl #32
    // 0xcf16e4: stur            x0, [fp, #-8]
    // 0xcf16e8: r1 = Function '_showHideCursor@80245603':.
    //     0xcf16e8: add             x1, PP, #0xad, lsl #12  ; [pp+0xad658] AnonymousClosure: (0xc06b74), in [package:flutter/src/rendering/editable.dart] RenderEditable::_showHideCursor (0xc06bac)
    //     0xcf16ec: ldr             x1, [x1, #0x658]
    // 0xcf16f0: r0 = AllocateClosure()
    //     0xcf16f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf16f4: ldur            x1, [fp, #-8]
    // 0xcf16f8: mov             x2, x0
    // 0xcf16fc: r0 = addListener()
    //     0xcf16fc: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xcf1700: r0 = Null
    //     0xcf1700: mov             x0, NULL
    // 0xcf1704: LeaveFrame
    //     0xcf1704: mov             SP, fp
    //     0xcf1708: ldp             fp, lr, [SP], #0x10
    // 0xcf170c: ret
    //     0xcf170c: ret             
    // 0xcf1710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1714: b               #0xcf164c
  }
  set _ backgroundCursorColor=(/* No info */) {
    // ** addr: 0xcf1718, size: 0x58
    // 0xcf1718: EnterFrame
    //     0xcf1718: stp             fp, lr, [SP, #-0x10]!
    //     0xcf171c: mov             fp, SP
    // 0xcf1720: CheckStackOverflow
    //     0xcf1720: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1724: cmp             SP, x16
    //     0xcf1728: b.ls            #0xcf1768
    // 0xcf172c: LoadField: r0 = r1->field_73
    //     0xcf172c: ldur            w0, [x1, #0x73]
    // 0xcf1730: DecompressPointer r0
    //     0xcf1730: add             x0, x0, HEAP, lsl #32
    // 0xcf1734: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf1738: cmp             w0, w16
    // 0xcf173c: b.ne            #0xcf1748
    // 0xcf1740: r2 = _caretPainter
    //     0xcf1740: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0xcf1744: r0 = InitLateFinalInstanceField()
    //     0xcf1744: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0xcf1748: mov             x1, x0
    // 0xcf174c: r2 = Instance_CupertinoDynamicColor
    //     0xcf174c: add             x2, PP, #0x26, lsl #12  ; [pp+0x26b50] Obj!CupertinoDynamicColor@12b36f1
    //     0xcf1750: ldr             x2, [x2, #0xb50]
    // 0xcf1754: r0 = backgroundCursorColor=()
    //     0xcf1754: bl              #0xcf1770  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::backgroundCursorColor=
    // 0xcf1758: r0 = Null
    //     0xcf1758: mov             x0, NULL
    // 0xcf175c: LeaveFrame
    //     0xcf175c: mov             SP, fp
    //     0xcf1760: ldp             fp, lr, [SP], #0x10
    // 0xcf1764: ret
    //     0xcf1764: ret             
    // 0xcf1768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1768: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf176c: b               #0xcf172c
  }
  set _ endHandleLayerLink=(/* No info */) {
    // ** addr: 0xcf1894, size: 0x70
    // 0xcf1894: EnterFrame
    //     0xcf1894: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1898: mov             fp, SP
    // 0xcf189c: mov             x0, x2
    // 0xcf18a0: CheckStackOverflow
    //     0xcf18a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf18a4: cmp             SP, x16
    //     0xcf18a8: b.ls            #0xcf18fc
    // 0xcf18ac: LoadField: r2 = r1->field_f3
    //     0xcf18ac: ldur            w2, [x1, #0xf3]
    // 0xcf18b0: DecompressPointer r2
    //     0xcf18b0: add             x2, x2, HEAP, lsl #32
    // 0xcf18b4: cmp             w2, w0
    // 0xcf18b8: b.ne            #0xcf18cc
    // 0xcf18bc: r0 = Null
    //     0xcf18bc: mov             x0, NULL
    // 0xcf18c0: LeaveFrame
    //     0xcf18c0: mov             SP, fp
    //     0xcf18c4: ldp             fp, lr, [SP], #0x10
    // 0xcf18c8: ret
    //     0xcf18c8: ret             
    // 0xcf18cc: StoreField: r1->field_f3 = r0
    //     0xcf18cc: stur            w0, [x1, #0xf3]
    //     0xcf18d0: ldurb           w16, [x1, #-1]
    //     0xcf18d4: ldurb           w17, [x0, #-1]
    //     0xcf18d8: and             x16, x17, x16, lsr #2
    //     0xcf18dc: tst             x16, HEAP, lsr #32
    //     0xcf18e0: b.eq            #0xcf18e8
    //     0xcf18e4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf18e8: r0 = markNeedsPaint()
    //     0xcf18e8: bl              #0xbf05e0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::markNeedsPaint
    // 0xcf18ec: r0 = Null
    //     0xcf18ec: mov             x0, NULL
    // 0xcf18f0: LeaveFrame
    //     0xcf18f0: mov             SP, fp
    //     0xcf18f4: ldp             fp, lr, [SP], #0x10
    // 0xcf18f8: ret
    //     0xcf18f8: ret             
    // 0xcf18fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf18fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1900: b               #0xcf18ac
  }
  set _ startHandleLayerLink=(/* No info */) {
    // ** addr: 0xcf1904, size: 0x70
    // 0xcf1904: EnterFrame
    //     0xcf1904: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1908: mov             fp, SP
    // 0xcf190c: mov             x0, x2
    // 0xcf1910: CheckStackOverflow
    //     0xcf1910: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1914: cmp             SP, x16
    //     0xcf1918: b.ls            #0xcf196c
    // 0xcf191c: LoadField: r2 = r1->field_ef
    //     0xcf191c: ldur            w2, [x1, #0xef]
    // 0xcf1920: DecompressPointer r2
    //     0xcf1920: add             x2, x2, HEAP, lsl #32
    // 0xcf1924: cmp             w2, w0
    // 0xcf1928: b.ne            #0xcf193c
    // 0xcf192c: r0 = Null
    //     0xcf192c: mov             x0, NULL
    // 0xcf1930: LeaveFrame
    //     0xcf1930: mov             SP, fp
    //     0xcf1934: ldp             fp, lr, [SP], #0x10
    // 0xcf1938: ret
    //     0xcf1938: ret             
    // 0xcf193c: StoreField: r1->field_ef = r0
    //     0xcf193c: stur            w0, [x1, #0xef]
    //     0xcf1940: ldurb           w16, [x1, #-1]
    //     0xcf1944: ldurb           w17, [x0, #-1]
    //     0xcf1948: and             x16, x17, x16, lsr #2
    //     0xcf194c: tst             x16, HEAP, lsr #32
    //     0xcf1950: b.eq            #0xcf1958
    //     0xcf1954: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf1958: r0 = markNeedsPaint()
    //     0xcf1958: bl              #0xbf05e0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::markNeedsPaint
    // 0xcf195c: r0 = Null
    //     0xcf195c: mov             x0, NULL
    // 0xcf1960: LeaveFrame
    //     0xcf1960: mov             SP, fp
    //     0xcf1964: ldp             fp, lr, [SP], #0x10
    // 0xcf1968: ret
    //     0xcf1968: ret             
    // 0xcf196c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf196c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1970: b               #0xcf191c
  }
  set _ text=(/* No info */) {
    // ** addr: 0xcf1974, size: 0xb0
    // 0xcf1974: EnterFrame
    //     0xcf1974: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1978: mov             fp, SP
    // 0xcf197c: AllocStack(0x28)
    //     0xcf197c: sub             SP, SP, #0x28
    // 0xcf1980: SetupParameters(RenderEditable this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xcf1980: stur            x1, [fp, #-0x10]
    //     0xcf1984: stur            x2, [fp, #-0x18]
    // 0xcf1988: CheckStackOverflow
    //     0xcf1988: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf198c: cmp             SP, x16
    //     0xcf1990: b.ls            #0xcf1a1c
    // 0xcf1994: LoadField: r3 = r1->field_a7
    //     0xcf1994: ldur            w3, [x1, #0xa7]
    // 0xcf1998: DecompressPointer r3
    //     0xcf1998: add             x3, x3, HEAP, lsl #32
    // 0xcf199c: stur            x3, [fp, #-8]
    // 0xcf19a0: LoadField: r0 = r3->field_f
    //     0xcf19a0: ldur            w0, [x3, #0xf]
    // 0xcf19a4: DecompressPointer r0
    //     0xcf19a4: add             x0, x0, HEAP, lsl #32
    // 0xcf19a8: r4 = LoadClassIdInstr(r0)
    //     0xcf19a8: ldur            x4, [x0, #-1]
    //     0xcf19ac: ubfx            x4, x4, #0xc, #0x14
    // 0xcf19b0: stp             x2, x0, [SP]
    // 0xcf19b4: mov             x0, x4
    // 0xcf19b8: mov             lr, x0
    // 0xcf19bc: ldr             lr, [x21, lr, lsl #3]
    // 0xcf19c0: blr             lr
    // 0xcf19c4: tbnz            w0, #4, #0xcf19d8
    // 0xcf19c8: r0 = Null
    //     0xcf19c8: mov             x0, NULL
    // 0xcf19cc: LeaveFrame
    //     0xcf19cc: mov             SP, fp
    //     0xcf19d0: ldp             fp, lr, [SP], #0x10
    // 0xcf19d4: ret
    //     0xcf19d4: ret             
    // 0xcf19d8: ldur            x0, [fp, #-0x10]
    // 0xcf19dc: r17 = 279
    //     0xcf19dc: mov             x17, #0x117
    // 0xcf19e0: str             NULL, [x0, x17]
    // 0xcf19e4: ldur            x1, [fp, #-8]
    // 0xcf19e8: ldur            x2, [fp, #-0x18]
    // 0xcf19ec: r0 = text=()
    //     0xcf19ec: bl              #0xb1d2b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0xcf19f0: ldur            x0, [fp, #-0x10]
    // 0xcf19f4: StoreField: r0->field_ab = rNULL
    //     0xcf19f4: stur            NULL, [x0, #0xab]
    // 0xcf19f8: StoreField: r0->field_af = rNULL
    //     0xcf19f8: stur            NULL, [x0, #0xaf]
    // 0xcf19fc: mov             x1, x0
    // 0xcf1a00: r0 = markNeedsLayout()
    //     0xcf1a00: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf1a04: ldur            x1, [fp, #-0x10]
    // 0xcf1a08: r0 = markNeedsSemanticsUpdate()
    //     0xcf1a08: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf1a0c: r0 = Null
    //     0xcf1a0c: mov             x0, NULL
    // 0xcf1a10: LeaveFrame
    //     0xcf1a10: mov             SP, fp
    //     0xcf1a14: ldp             fp, lr, [SP], #0x10
    // 0xcf1a18: ret
    //     0xcf1a18: ret             
    // 0xcf1a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1a1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1a20: b               #0xcf1994
  }
  _ handleSecondaryTapDown(/* No info */) {
    // ** addr: 0xd474c4, size: 0x68
    // 0xd474c4: EnterFrame
    //     0xd474c4: stp             fp, lr, [SP, #-0x10]!
    //     0xd474c8: mov             fp, SP
    // 0xd474cc: LoadField: r3 = r2->field_7
    //     0xd474cc: ldur            w3, [x2, #7]
    // 0xd474d0: DecompressPointer r3
    //     0xd474d0: add             x3, x3, HEAP, lsl #32
    // 0xd474d4: mov             x0, x3
    // 0xd474d8: r17 = 291
    //     0xd474d8: mov             x17, #0x123
    // 0xd474dc: str             w0, [x1, x17]
    // 0xd474e0: WriteBarrierInstr(obj = r1, val = r0)
    //     0xd474e0: ldurb           w16, [x1, #-1]
    //     0xd474e4: ldurb           w17, [x0, #-1]
    //     0xd474e8: and             x16, x17, x16, lsr #2
    //     0xd474ec: tst             x16, HEAP, lsr #32
    //     0xd474f0: b.eq            #0xd474f8
    //     0xd474f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd474f8: mov             x0, x3
    // 0xd474fc: r17 = 295
    //     0xd474fc: mov             x17, #0x127
    // 0xd47500: str             w0, [x1, x17]
    // 0xd47504: WriteBarrierInstr(obj = r1, val = r0)
    //     0xd47504: ldurb           w16, [x1, #-1]
    //     0xd47508: ldurb           w17, [x0, #-1]
    //     0xd4750c: and             x16, x17, x16, lsr #2
    //     0xd47510: tst             x16, HEAP, lsr #32
    //     0xd47514: b.eq            #0xd4751c
    //     0xd47518: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xd4751c: r0 = Null
    //     0xd4751c: mov             x0, NULL
    // 0xd47520: LeaveFrame
    //     0xd47520: mov             SP, fp
    //     0xd47524: ldp             fp, lr, [SP], #0x10
    // 0xd47528: ret
    //     0xd47528: ret             
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ea490, size: 0x204
    // 0x10ea490: EnterFrame
    //     0x10ea490: stp             fp, lr, [SP, #-0x10]!
    //     0x10ea494: mov             fp, SP
    // 0x10ea498: AllocStack(0x38)
    //     0x10ea498: sub             SP, SP, #0x38
    // 0x10ea49c: SetupParameters(RenderEditable this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x10ea49c: mov             x0, x3
    //     0x10ea4a0: stur            x3, [fp, #-0x18]
    //     0x10ea4a4: mov             x3, x1
    //     0x10ea4a8: stur            x1, [fp, #-8]
    //     0x10ea4ac: stur            x2, [fp, #-0x10]
    // 0x10ea4b0: CheckStackOverflow
    //     0x10ea4b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ea4b4: cmp             SP, x16
    //     0x10ea4b8: b.ls            #0x10ea688
    // 0x10ea4bc: mov             x1, x3
    // 0x10ea4c0: r0 = _paintOffset()
    //     0x10ea4c0: bl              #0x85ff30  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_paintOffset
    // 0x10ea4c4: ldur            x1, [fp, #-0x18]
    // 0x10ea4c8: mov             x2, x0
    // 0x10ea4cc: r0 = -()
    //     0x10ea4cc: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x10ea4d0: mov             x3, x0
    // 0x10ea4d4: ldur            x0, [fp, #-8]
    // 0x10ea4d8: stur            x3, [fp, #-0x20]
    // 0x10ea4dc: LoadField: r4 = r0->field_a7
    //     0x10ea4dc: ldur            w4, [x0, #0xa7]
    // 0x10ea4e0: DecompressPointer r4
    //     0x10ea4e0: add             x4, x4, HEAP, lsl #32
    // 0x10ea4e4: mov             x1, x4
    // 0x10ea4e8: mov             x2, x3
    // 0x10ea4ec: stur            x4, [fp, #-0x18]
    // 0x10ea4f0: r0 = getClosestGlyphForOffset()
    //     0x10ea4f0: bl              #0x10ea850  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getClosestGlyphForOffset
    // 0x10ea4f4: stur            x0, [fp, #-0x28]
    // 0x10ea4f8: cmp             w0, NULL
    // 0x10ea4fc: b.eq            #0x10ea5dc
    // 0x10ea500: LoadField: r1 = r0->field_7
    //     0x10ea500: ldur            w1, [x0, #7]
    // 0x10ea504: DecompressPointer r1
    //     0x10ea504: add             x1, x1, HEAP, lsl #32
    // 0x10ea508: ldur            x2, [fp, #-0x20]
    // 0x10ea50c: r0 = contains()
    //     0x10ea50c: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0x10ea510: tbnz            w0, #4, #0x10ea5dc
    // 0x10ea514: ldur            x1, [fp, #-0x18]
    // 0x10ea518: ldur            x0, [fp, #-0x28]
    // 0x10ea51c: LoadField: r2 = r1->field_f
    //     0x10ea51c: ldur            w2, [x1, #0xf]
    // 0x10ea520: DecompressPointer r2
    //     0x10ea520: add             x2, x2, HEAP, lsl #32
    // 0x10ea524: stur            x2, [fp, #-0x38]
    // 0x10ea528: cmp             w2, NULL
    // 0x10ea52c: b.eq            #0x10ea690
    // 0x10ea530: LoadField: r1 = r0->field_b
    //     0x10ea530: ldur            w1, [x0, #0xb]
    // 0x10ea534: DecompressPointer r1
    //     0x10ea534: add             x1, x1, HEAP, lsl #32
    // 0x10ea538: LoadField: r0 = r1->field_7
    //     0x10ea538: ldur            x0, [x1, #7]
    // 0x10ea53c: stur            x0, [fp, #-0x30]
    // 0x10ea540: r0 = TextPosition()
    //     0x10ea540: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x10ea544: mov             x1, x0
    // 0x10ea548: ldur            x0, [fp, #-0x30]
    // 0x10ea54c: stur            x1, [fp, #-0x18]
    // 0x10ea550: StoreField: r1->field_7 = r0
    //     0x10ea550: stur            x0, [x1, #7]
    // 0x10ea554: r0 = Instance_TextAffinity
    //     0x10ea554: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x10ea558: StoreField: r1->field_f = r0
    //     0x10ea558: stur            w0, [x1, #0xf]
    // 0x10ea55c: ldur            x0, [fp, #-0x38]
    // 0x10ea560: r2 = LoadClassIdInstr(r0)
    //     0x10ea560: ldur            x2, [x0, #-1]
    //     0x10ea564: ubfx            x2, x2, #0xc, #0x14
    // 0x10ea568: r17 = -5790
    //     0x10ea568: mov             x17, #-0x169e
    // 0x10ea56c: add             x16, x2, x17
    // 0x10ea570: cmp             x16, #1
    // 0x10ea574: b.hi            #0x10ea580
    // 0x10ea578: r0 = Null
    //     0x10ea578: mov             x0, NULL
    // 0x10ea57c: b               #0x10ea5d4
    // 0x10ea580: r1 = 3
    //     0x10ea580: mov             x1, #3
    // 0x10ea584: r0 = AllocateContext()
    //     0x10ea584: bl              #0x13de838  ; AllocateContextStub
    // 0x10ea588: mov             x1, x0
    // 0x10ea58c: ldur            x0, [fp, #-0x18]
    // 0x10ea590: stur            x1, [fp, #-0x28]
    // 0x10ea594: StoreField: r1->field_f = r0
    //     0x10ea594: stur            w0, [x1, #0xf]
    // 0x10ea598: r0 = Accumulator()
    //     0x10ea598: bl              #0xb97ef0  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0x10ea59c: StoreField: r0->field_7 = rZR
    //     0x10ea59c: stur            xzr, [x0, #7]
    // 0x10ea5a0: ldur            x3, [fp, #-0x28]
    // 0x10ea5a4: StoreField: r3->field_13 = r0
    //     0x10ea5a4: stur            w0, [x3, #0x13]
    // 0x10ea5a8: mov             x2, x3
    // 0x10ea5ac: r1 = Function '<anonymous closure>':.
    //     0x10ea5ac: add             x1, PP, #0x98, lsl #12  ; [pp+0x989f0] AnonymousClosure: (0x10eac04), of [package:flutter/src/painting/inline_span.dart] InlineSpan
    //     0x10ea5b0: ldr             x1, [x1, #0x9f0]
    // 0x10ea5b4: r0 = AllocateClosure()
    //     0x10ea5b4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10ea5b8: ldur            x1, [fp, #-0x38]
    // 0x10ea5bc: mov             x2, x0
    // 0x10ea5c0: r0 = visitChildren()
    //     0x10ea5c0: bl              #0x125eb34  ; [package:flutter/src/painting/text_span.dart] TextSpan::visitChildren
    // 0x10ea5c4: ldur            x0, [fp, #-0x28]
    // 0x10ea5c8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10ea5c8: ldur            w1, [x0, #0x17]
    // 0x10ea5cc: DecompressPointer r1
    //     0x10ea5cc: add             x1, x1, HEAP, lsl #32
    // 0x10ea5d0: mov             x0, x1
    // 0x10ea5d4: mov             x3, x0
    // 0x10ea5d8: b               #0x10ea5e0
    // 0x10ea5dc: r3 = Null
    //     0x10ea5dc: mov             x3, NULL
    // 0x10ea5e0: mov             x0, x3
    // 0x10ea5e4: stur            x3, [fp, #-0x18]
    // 0x10ea5e8: r2 = Null
    //     0x10ea5e8: mov             x2, NULL
    // 0x10ea5ec: r1 = Null
    //     0x10ea5ec: mov             x1, NULL
    // 0x10ea5f0: cmp             w0, NULL
    // 0x10ea5f4: b.eq            #0x10ea628
    // 0x10ea5f8: branchIfSmi(r0, 0x10ea628)
    //     0x10ea5f8: tbz             w0, #0, #0x10ea628
    // 0x10ea5fc: r3 = LoadClassIdInstr(r0)
    //     0x10ea5fc: ldur            x3, [x0, #-1]
    //     0x10ea600: ubfx            x3, x3, #0xc, #0x14
    // 0x10ea604: r17 = 4609
    //     0x10ea604: mov             x17, #0x1201
    // 0x10ea608: cmp             x3, x17
    // 0x10ea60c: b.eq            #0x10ea630
    // 0x10ea610: r17 = -4679
    //     0x10ea610: mov             x17, #-0x1247
    // 0x10ea614: add             x3, x3, x17
    // 0x10ea618: cmp             x3, #0x128
    // 0x10ea61c: b.ls            #0x10ea630
    // 0x10ea620: cmp             x3, #0x455
    // 0x10ea624: b.eq            #0x10ea630
    // 0x10ea628: r0 = false
    //     0x10ea628: add             x0, NULL, #0x30  ; false
    // 0x10ea62c: b               #0x10ea634
    // 0x10ea630: r0 = true
    //     0x10ea630: add             x0, NULL, #0x20  ; true
    // 0x10ea634: tbnz            w0, #4, #0x10ea66c
    // 0x10ea638: ldur            x0, [fp, #-0x18]
    // 0x10ea63c: r1 = <HitTestTarget>
    //     0x10ea63c: ldr             x1, [PP, #0x2ef0]  ; [pp+0x2ef0] TypeArguments: <HitTestTarget>
    // 0x10ea640: r0 = HitTestEntry()
    //     0x10ea640: bl              #0x836a54  ; AllocateHitTestEntryStub -> HitTestEntry<X0 bound HitTestTarget> (size=0x14)
    // 0x10ea644: mov             x1, x0
    // 0x10ea648: ldur            x0, [fp, #-0x18]
    // 0x10ea64c: StoreField: r1->field_b = r0
    //     0x10ea64c: stur            w0, [x1, #0xb]
    // 0x10ea650: mov             x2, x1
    // 0x10ea654: ldur            x1, [fp, #-0x10]
    // 0x10ea658: r0 = add()
    //     0x10ea658: bl              #0x836754  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x10ea65c: r0 = true
    //     0x10ea65c: add             x0, NULL, #0x20  ; true
    // 0x10ea660: LeaveFrame
    //     0x10ea660: mov             SP, fp
    //     0x10ea664: ldp             fp, lr, [SP], #0x10
    // 0x10ea668: ret
    //     0x10ea668: ret             
    // 0x10ea66c: ldur            x1, [fp, #-8]
    // 0x10ea670: ldur            x2, [fp, #-0x10]
    // 0x10ea674: ldur            x3, [fp, #-0x20]
    // 0x10ea678: r0 = hitTestInlineChildren()
    //     0x10ea678: bl              #0x10ea694  ; [dart:mixin_deduplication] _MixinApplication428&RenderBox&RelayoutWhenSystemFontsChangeMixin&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::hitTestInlineChildren
    // 0x10ea67c: LeaveFrame
    //     0x10ea67c: mov             SP, fp
    //     0x10ea680: ldp             fp, lr, [SP], #0x10
    // 0x10ea684: ret
    //     0x10ea684: ret             
    // 0x10ea688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ea688: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ea68c: b               #0x10ea4bc
    // 0x10ea690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10ea690: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f003c, size: 0x24
    // 0x10f003c: EnterFrame
    //     0x10f003c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0040: mov             fp, SP
    // 0x10f0044: ldr             x2, [fp, #0x10]
    // 0x10f0048: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0048: add             x1, PP, #0xcd, lsl #12  ; [pp+0xcd588] AnonymousClosure: (0xb2509c), in [package:flutter/src/rendering/editable.dart] RenderEditable::computeMinIntrinsicHeight (0xb2506c)
    //     0x10f004c: ldr             x1, [x1, #0x588]
    // 0x10f0050: r0 = AllocateClosure()
    //     0x10f0050: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0054: LeaveFrame
    //     0x10f0054: mov             SP, fp
    //     0x10f0058: ldp             fp, lr, [SP], #0x10
    // 0x10f005c: ret
    //     0x10f005c: ret             
  }
  _ RenderEditable(/* No info */) {
    // ** addr: 0x11caf30, size: 0x5e8
    // 0x11caf30: EnterFrame
    //     0x11caf30: stp             fp, lr, [SP, #-0x10]!
    //     0x11caf34: mov             fp, SP
    // 0x11caf38: AllocStack(0xa0)
    //     0x11caf38: sub             SP, SP, #0xa0
    // 0x11caf3c: ldr             x10, [THR, #0x90]  ; THR::object_sentinel
    // 0x11caf40: r9 = false
    //     0x11caf40: add             x9, NULL, #0x30  ; false
    // 0x11caf44: r8 = 0.000000
    //     0x11caf44: ldr             x8, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0x11caf48: r4 = Instance_Offset
    //     0x11caf48: ldr             x4, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11caf4c: r0 = true
    //     0x11caf4c: add             x0, NULL, #0x20  ; true
    // 0x11caf50: stur            x1, [fp, #-8]
    // 0x11caf54: mov             x16, x7
    // 0x11caf58: mov             x7, x1
    // 0x11caf5c: mov             x1, x16
    // 0x11caf60: stur            x2, [fp, #-0x10]
    // 0x11caf64: mov             x16, x5
    // 0x11caf68: mov             x5, x2
    // 0x11caf6c: mov             x2, x16
    // 0x11caf70: stur            x3, [fp, #-0x18]
    // 0x11caf74: stur            x2, [fp, #-0x20]
    // 0x11caf78: stur            x6, [fp, #-0x28]
    // 0x11caf7c: stur            x1, [fp, #-0x30]
    // 0x11caf80: stur            d0, [fp, #-0x60]
    // 0x11caf84: stur            d1, [fp, #-0x68]
    // 0x11caf88: CheckStackOverflow
    //     0x11caf88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11caf8c: cmp             SP, x16
    //     0x11caf90: b.ls            #0x11cb510
    // 0x11caf94: StoreField: r7->field_73 = r10
    //     0x11caf94: stur            w10, [x7, #0x73]
    // 0x11caf98: StoreField: r7->field_fb = r9
    //     0x11caf98: stur            w9, [x7, #0xfb]
    // 0x11caf9c: StoreField: r7->field_ff = r10
    //     0x11caf9c: stur            w10, [x7, #0xff]
    // 0x11cafa0: r17 = 263
    //     0x11cafa0: mov             x17, #0x107
    // 0x11cafa4: str             w8, [x7, x17]
    // 0x11cafa8: r17 = 283
    //     0x11cafa8: mov             x17, #0x11b
    // 0x11cafac: str             w10, [x7, x17]
    // 0x11cafb0: r17 = 287
    //     0x11cafb0: mov             x17, #0x11f
    // 0x11cafb4: str             w10, [x7, x17]
    // 0x11cafb8: r17 = 303
    //     0x11cafb8: mov             x17, #0x12f
    // 0x11cafbc: str             w10, [x7, x17]
    // 0x11cafc0: r17 = 307
    //     0x11cafc0: mov             x17, #0x133
    // 0x11cafc4: str             w4, [x7, x17]
    // 0x11cafc8: r17 = 315
    //     0x11cafc8: mov             x17, #0x13b
    // 0x11cafcc: str             w0, [x7, x17]
    // 0x11cafd0: r17 = 319
    //     0x11cafd0: mov             x17, #0x13f
    // 0x11cafd4: str             w9, [x7, x17]
    // 0x11cafd8: r17 = 323
    //     0x11cafd8: mov             x17, #0x143
    // 0x11cafdc: str             w9, [x7, x17]
    // 0x11cafe0: r17 = 327
    //     0x11cafe0: mov             x17, #0x147
    // 0x11cafe4: str             w9, [x7, x17]
    // 0x11cafe8: r17 = 331
    //     0x11cafe8: mov             x17, #0x14b
    // 0x11cafec: str             w9, [x7, x17]
    // 0x11caff0: r0 = _TextHighlightPainter()
    //     0x11caff0: bl              #0x11cb5e8  ; Allocate_TextHighlightPainterStub -> _TextHighlightPainter (size=0x38)
    // 0x11caff4: mov             x1, x0
    // 0x11caff8: stur            x0, [fp, #-0x38]
    // 0x11caffc: r0 = _TextHighlightPainter()
    //     0x11caffc: bl              #0x11cb518  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::_TextHighlightPainter
    // 0x11cb000: ldur            x0, [fp, #-0x38]
    // 0x11cb004: ldur            x1, [fp, #-8]
    // 0x11cb008: StoreField: r1->field_77 = r0
    //     0x11cb008: stur            w0, [x1, #0x77]
    //     0x11cb00c: ldurb           w16, [x1, #-1]
    //     0x11cb010: ldurb           w17, [x0, #-1]
    //     0x11cb014: and             x16, x17, x16, lsr #2
    //     0x11cb018: tst             x16, HEAP, lsr #32
    //     0x11cb01c: b.eq            #0x11cb024
    //     0x11cb020: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb024: r0 = _TextHighlightPainter()
    //     0x11cb024: bl              #0x11cb5e8  ; Allocate_TextHighlightPainterStub -> _TextHighlightPainter (size=0x38)
    // 0x11cb028: mov             x1, x0
    // 0x11cb02c: stur            x0, [fp, #-0x40]
    // 0x11cb030: r0 = _TextHighlightPainter()
    //     0x11cb030: bl              #0x11cb518  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::_TextHighlightPainter
    // 0x11cb034: ldur            x0, [fp, #-0x40]
    // 0x11cb038: ldur            x2, [fp, #-8]
    // 0x11cb03c: StoreField: r2->field_7b = r0
    //     0x11cb03c: stur            w0, [x2, #0x7b]
    //     0x11cb040: ldurb           w16, [x2, #-1]
    //     0x11cb044: ldurb           w17, [x0, #-1]
    //     0x11cb048: and             x16, x17, x16, lsr #2
    //     0x11cb04c: tst             x16, HEAP, lsr #32
    //     0x11cb050: b.eq            #0x11cb058
    //     0x11cb054: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cb058: r1 = <bool>
    //     0x11cb058: ldr             x1, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x11cb05c: r0 = ValueNotifier()
    //     0x11cb05c: bl              #0x89f884  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0x11cb060: mov             x1, x0
    // 0x11cb064: r0 = true
    //     0x11cb064: add             x0, NULL, #0x20  ; true
    // 0x11cb068: stur            x1, [fp, #-0x48]
    // 0x11cb06c: StoreField: r1->field_27 = r0
    //     0x11cb06c: stur            w0, [x1, #0x27]
    // 0x11cb070: StoreField: r1->field_7 = rZR
    //     0x11cb070: stur            xzr, [x1, #7]
    // 0x11cb074: StoreField: r1->field_13 = rZR
    //     0x11cb074: stur            xzr, [x1, #0x13]
    // 0x11cb078: StoreField: r1->field_1b = rZR
    //     0x11cb078: stur            xzr, [x1, #0x1b]
    // 0x11cb07c: r0 = LoadStaticField(0x45c)
    //     0x11cb07c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x11cb080: ldr             x0, [x0, #0x8b8]
    // 0x11cb084: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11cb088: cmp             w0, w16
    // 0x11cb08c: b.ne            #0x11cb098
    // 0x11cb090: r2 = _emptyListeners
    //     0x11cb090: ldr             x2, [PP, #0x17f0]  ; [pp+0x17f0] Field <ChangeNotifier._emptyListeners@28329750>: static late final (offset: 0x45c)
    // 0x11cb094: r0 = InitLateFinalStaticField()
    //     0x11cb094: bl              #0x13dd9ec  ; InitLateFinalStaticFieldStub
    // 0x11cb098: mov             x2, x0
    // 0x11cb09c: ldur            x0, [fp, #-0x48]
    // 0x11cb0a0: stur            x2, [fp, #-0x50]
    // 0x11cb0a4: StoreField: r0->field_f = r2
    //     0x11cb0a4: stur            w2, [x0, #0xf]
    // 0x11cb0a8: ldur            x3, [fp, #-8]
    // 0x11cb0ac: StoreField: r3->field_9f = r0
    //     0x11cb0ac: stur            w0, [x3, #0x9f]
    //     0x11cb0b0: ldurb           w16, [x3, #-1]
    //     0x11cb0b4: ldurb           w17, [x0, #-1]
    //     0x11cb0b8: and             x16, x17, x16, lsr #2
    //     0x11cb0bc: tst             x16, HEAP, lsr #32
    //     0x11cb0c0: b.eq            #0x11cb0c8
    //     0x11cb0c4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11cb0c8: r1 = <bool>
    //     0x11cb0c8: ldr             x1, [PP, #0x1918]  ; [pp+0x1918] TypeArguments: <bool>
    // 0x11cb0cc: r0 = ValueNotifier()
    //     0x11cb0cc: bl              #0x89f884  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0x11cb0d0: r2 = true
    //     0x11cb0d0: add             x2, NULL, #0x20  ; true
    // 0x11cb0d4: StoreField: r0->field_27 = r2
    //     0x11cb0d4: stur            w2, [x0, #0x27]
    // 0x11cb0d8: StoreField: r0->field_7 = rZR
    //     0x11cb0d8: stur            xzr, [x0, #7]
    // 0x11cb0dc: StoreField: r0->field_13 = rZR
    //     0x11cb0dc: stur            xzr, [x0, #0x13]
    // 0x11cb0e0: StoreField: r0->field_1b = rZR
    //     0x11cb0e0: stur            xzr, [x0, #0x1b]
    // 0x11cb0e4: ldur            x1, [fp, #-0x50]
    // 0x11cb0e8: StoreField: r0->field_f = r1
    //     0x11cb0e8: stur            w1, [x0, #0xf]
    // 0x11cb0ec: ldur            x3, [fp, #-8]
    // 0x11cb0f0: StoreField: r3->field_a3 = r0
    //     0x11cb0f0: stur            w0, [x3, #0xa3]
    //     0x11cb0f4: ldurb           w16, [x3, #-1]
    //     0x11cb0f8: ldurb           w17, [x0, #-1]
    //     0x11cb0fc: and             x16, x17, x16, lsr #2
    //     0x11cb100: tst             x16, HEAP, lsr #32
    //     0x11cb104: b.eq            #0x11cb10c
    //     0x11cb108: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11cb10c: r1 = <LeaderLayer>
    //     0x11cb10c: add             x1, PP, #0xad, lsl #12  ; [pp+0xad660] TypeArguments: <LeaderLayer>
    //     0x11cb110: ldr             x1, [x1, #0x660]
    // 0x11cb114: r0 = LayerHandle()
    //     0x11cb114: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11cb118: ldur            x2, [fp, #-8]
    // 0x11cb11c: r17 = 339
    //     0x11cb11c: mov             x17, #0x153
    // 0x11cb120: str             w0, [x2, x17]
    // 0x11cb124: WriteBarrierInstr(obj = r2, val = r0)
    //     0x11cb124: ldurb           w16, [x2, #-1]
    //     0x11cb128: ldurb           w17, [x0, #-1]
    //     0x11cb12c: and             x16, x17, x16, lsr #2
    //     0x11cb130: tst             x16, HEAP, lsr #32
    //     0x11cb134: b.eq            #0x11cb13c
    //     0x11cb138: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cb13c: r1 = <ClipRectLayer>
    //     0x11cb13c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84fc8] TypeArguments: <ClipRectLayer>
    //     0x11cb140: ldr             x1, [x1, #0xfc8]
    // 0x11cb144: r0 = LayerHandle()
    //     0x11cb144: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11cb148: ldur            x1, [fp, #-8]
    // 0x11cb14c: r17 = 343
    //     0x11cb14c: mov             x17, #0x157
    // 0x11cb150: str             w0, [x1, x17]
    // 0x11cb154: WriteBarrierInstr(obj = r1, val = r0)
    //     0x11cb154: ldurb           w16, [x1, #-1]
    //     0x11cb158: ldurb           w17, [x0, #-1]
    //     0x11cb15c: and             x16, x17, x16, lsr #2
    //     0x11cb160: tst             x16, HEAP, lsr #32
    //     0x11cb164: b.eq            #0x11cb16c
    //     0x11cb168: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb16c: r0 = true
    //     0x11cb16c: add             x0, NULL, #0x20  ; true
    // 0x11cb170: StoreField: r1->field_87 = r0
    //     0x11cb170: stur            w0, [x1, #0x87]
    // 0x11cb174: r0 = Instance_EdgeInsets
    //     0x11cb174: ldr             x0, [PP, #0x52c0]  ; [pp+0x52c0] Obj!EdgeInsets@129cc31
    // 0x11cb178: StoreField: r1->field_f7 = r0
    //     0x11cb178: stur            w0, [x1, #0xf7]
    // 0x11cb17c: ldr             x0, [fp, #0x10]
    // 0x11cb180: StoreField: r1->field_9b = r0
    //     0x11cb180: stur            w0, [x1, #0x9b]
    //     0x11cb184: ldurb           w16, [x1, #-1]
    //     0x11cb188: ldurb           w17, [x0, #-1]
    //     0x11cb18c: and             x16, x17, x16, lsr #2
    //     0x11cb190: tst             x16, HEAP, lsr #32
    //     0x11cb194: b.eq            #0x11cb19c
    //     0x11cb198: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb19c: ldr             x2, [fp, #0x18]
    // 0x11cb1a0: r0 = LoadClassIdInstr(r2)
    //     0x11cb1a0: ldur            x0, [x2, #-1]
    //     0x11cb1a4: ubfx            x0, x0, #0xc, #0x14
    // 0x11cb1a8: r16 = Instance__LinearTextScaler
    //     0x11cb1a8: ldr             x16, [PP, #0x4a58]  ; [pp+0x4a58] Obj!_LinearTextScaler@129c641
    // 0x11cb1ac: stp             x16, x2, [SP]
    // 0x11cb1b0: mov             lr, x0
    // 0x11cb1b4: ldr             lr, [x21, lr, lsl #3]
    // 0x11cb1b8: blr             lr
    // 0x11cb1bc: tbnz            w0, #4, #0x11cb1d4
    // 0x11cb1c0: r0 = _LinearTextScaler()
    //     0x11cb1c0: bl              #0x8cf878  ; Allocate_LinearTextScalerStub -> _LinearTextScaler (size=0x10)
    // 0x11cb1c4: d0 = 1.000000
    //     0x11cb1c4: fmov            d0, #1.00000000
    // 0x11cb1c8: StoreField: r0->field_7 = d0
    //     0x11cb1c8: stur            d0, [x0, #7]
    // 0x11cb1cc: mov             x1, x0
    // 0x11cb1d0: b               #0x11cb1d8
    // 0x11cb1d4: ldr             x1, [fp, #0x18]
    // 0x11cb1d8: ldr             x0, [fp, #0x98]
    // 0x11cb1dc: stur            x1, [fp, #-0x50]
    // 0x11cb1e0: cmp             w0, #2
    // 0x11cb1e4: b.ne            #0x11cb1f0
    // 0x11cb1e8: r11 = 2
    //     0x11cb1e8: mov             x11, #2
    // 0x11cb1ec: b               #0x11cb1f4
    // 0x11cb1f0: r11 = Null
    //     0x11cb1f0: mov             x11, NULL
    // 0x11cb1f4: ldur            x2, [fp, #-8]
    // 0x11cb1f8: ldur            d1, [fp, #-0x60]
    // 0x11cb1fc: ldur            d0, [fp, #-0x68]
    // 0x11cb200: ldur            x4, [fp, #-0x28]
    // 0x11cb204: ldr             x10, [fp, #0xb8]
    // 0x11cb208: ldr             x9, [fp, #0xb0]
    // 0x11cb20c: ldr             x8, [fp, #0xa8]
    // 0x11cb210: ldr             x7, [fp, #0x90]
    // 0x11cb214: ldr             x6, [fp, #0x78]
    // 0x11cb218: ldr             x5, [fp, #0x60]
    // 0x11cb21c: ldur            x3, [fp, #-0x38]
    // 0x11cb220: stur            x11, [fp, #-0x48]
    // 0x11cb224: r0 = TextPainter()
    //     0x11cb224: bl              #0xb13a1c  ; AllocateTextPainterStub -> TextPainter (size=0x48)
    // 0x11cb228: stur            x0, [fp, #-0x58]
    // 0x11cb22c: ldr             x16, [fp, #0x30]
    // 0x11cb230: ldr             lr, [fp, #0x28]
    // 0x11cb234: stp             lr, x16, [SP, #0x28]
    // 0x11cb238: ldr             x16, [fp, #0x20]
    // 0x11cb23c: ldur            lr, [fp, #-0x50]
    // 0x11cb240: stp             lr, x16, [SP, #0x18]
    // 0x11cb244: ldr             x16, [fp, #0xa0]
    // 0x11cb248: ldur            lr, [fp, #-0x48]
    // 0x11cb24c: stp             lr, x16, [SP, #8]
    // 0x11cb250: ldr             x16, [fp, #0x38]
    // 0x11cb254: str             x16, [SP]
    // 0x11cb258: mov             x1, x0
    // 0x11cb25c: r4 = const [0, 0x8, 0x7, 0x1, locale, 0x5, maxLines, 0x6, strutStyle, 0x7, text, 0x1, textAlign, 0x2, textDirection, 0x3, textScaler, 0x4, null]
    //     0x11cb25c: add             x4, PP, #0xad, lsl #12  ; [pp+0xad668] List(19) [0, 0x8, 0x7, 0x1, "locale", 0x5, "maxLines", 0x6, "strutStyle", 0x7, "text", 0x1, "textAlign", 0x2, "textDirection", 0x3, "textScaler", 0x4, Null]
    //     0x11cb260: ldr             x4, [x4, #0x668]
    // 0x11cb264: r0 = TextPainter()
    //     0x11cb264: bl              #0xb135d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::TextPainter
    // 0x11cb268: ldur            x0, [fp, #-0x58]
    // 0x11cb26c: ldur            x1, [fp, #-8]
    // 0x11cb270: StoreField: r1->field_a7 = r0
    //     0x11cb270: stur            w0, [x1, #0xa7]
    //     0x11cb274: ldurb           w16, [x1, #-1]
    //     0x11cb278: ldurb           w17, [x0, #-1]
    //     0x11cb27c: and             x16, x17, x16, lsr #2
    //     0x11cb280: tst             x16, HEAP, lsr #32
    //     0x11cb284: b.eq            #0x11cb28c
    //     0x11cb288: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb28c: ldr             x0, [fp, #0x48]
    // 0x11cb290: StoreField: r1->field_bb = r0
    //     0x11cb290: stur            w0, [x1, #0xbb]
    //     0x11cb294: ldurb           w16, [x1, #-1]
    //     0x11cb298: ldurb           w17, [x0, #-1]
    //     0x11cb29c: and             x16, x17, x16, lsr #2
    //     0x11cb2a0: tst             x16, HEAP, lsr #32
    //     0x11cb2a4: b.eq            #0x11cb2ac
    //     0x11cb2a8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb2ac: ldr             x0, [fp, #0x98]
    // 0x11cb2b0: StoreField: r1->field_cb = r0
    //     0x11cb2b0: stur            w0, [x1, #0xcb]
    // 0x11cb2b4: ldr             x0, [fp, #0xb8]
    // 0x11cb2b8: StoreField: r1->field_d3 = r0
    //     0x11cb2b8: stur            w0, [x1, #0xd3]
    // 0x11cb2bc: ldr             x0, [fp, #0x58]
    // 0x11cb2c0: StoreField: r1->field_d7 = r0
    //     0x11cb2c0: stur            w0, [x1, #0xd7]
    //     0x11cb2c4: ldurb           w16, [x1, #-1]
    //     0x11cb2c8: ldurb           w17, [x0, #-1]
    //     0x11cb2cc: and             x16, x17, x16, lsr #2
    //     0x11cb2d0: tst             x16, HEAP, lsr #32
    //     0x11cb2d4: b.eq            #0x11cb2dc
    //     0x11cb2d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb2dc: ldr             x0, [fp, #0x80]
    // 0x11cb2e0: StoreField: r1->field_db = r0
    //     0x11cb2e0: stur            w0, [x1, #0xdb]
    //     0x11cb2e4: ldurb           w16, [x1, #-1]
    //     0x11cb2e8: ldurb           w17, [x0, #-1]
    //     0x11cb2ec: and             x16, x17, x16, lsr #2
    //     0x11cb2f0: tst             x16, HEAP, lsr #32
    //     0x11cb2f4: b.eq            #0x11cb2fc
    //     0x11cb2f8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb2fc: ldur            d0, [fp, #-0x60]
    // 0x11cb300: StoreField: r1->field_df = d0
    //     0x11cb300: stur            d0, [x1, #0xdf]
    // 0x11cb304: ldr             x0, [fp, #0x78]
    // 0x11cb308: StoreField: r1->field_eb = r0
    //     0x11cb308: stur            w0, [x1, #0xeb]
    // 0x11cb30c: ldur            x0, [fp, #-0x28]
    // 0x11cb310: r17 = 259
    //     0x11cb310: mov             x17, #0x103
    // 0x11cb314: str             w0, [x1, x17]
    // 0x11cb318: ldur            d0, [fp, #-0x68]
    // 0x11cb31c: StoreField: r1->field_8b = d0
    //     0x11cb31c: stur            d0, [x1, #0x8b]
    // 0x11cb320: ldr             x0, [fp, #0x40]
    // 0x11cb324: StoreField: r1->field_ef = r0
    //     0x11cb324: stur            w0, [x1, #0xef]
    //     0x11cb328: ldurb           w16, [x1, #-1]
    //     0x11cb32c: ldurb           w17, [x0, #-1]
    //     0x11cb330: and             x16, x17, x16, lsr #2
    //     0x11cb334: tst             x16, HEAP, lsr #32
    //     0x11cb338: b.eq            #0x11cb340
    //     0x11cb33c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb340: ldur            x0, [fp, #-0x30]
    // 0x11cb344: StoreField: r1->field_f3 = r0
    //     0x11cb344: stur            w0, [x1, #0xf3]
    //     0x11cb348: ldurb           w16, [x1, #-1]
    //     0x11cb34c: ldurb           w17, [x0, #-1]
    //     0x11cb350: and             x16, x17, x16, lsr #2
    //     0x11cb354: tst             x16, HEAP, lsr #32
    //     0x11cb358: b.eq            #0x11cb360
    //     0x11cb35c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb360: ldr             x0, [fp, #0x88]
    // 0x11cb364: StoreField: r1->field_93 = r0
    //     0x11cb364: stur            w0, [x1, #0x93]
    //     0x11cb368: ldurb           w16, [x1, #-1]
    //     0x11cb36c: ldurb           w17, [x0, #-1]
    //     0x11cb370: and             x16, x17, x16, lsr #2
    //     0x11cb374: tst             x16, HEAP, lsr #32
    //     0x11cb378: b.eq            #0x11cb380
    //     0x11cb37c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cb380: ldr             x0, [fp, #0x90]
    // 0x11cb384: StoreField: r1->field_97 = r0
    //     0x11cb384: stur            w0, [x1, #0x97]
    // 0x11cb388: ldr             x0, [fp, #0x60]
    // 0x11cb38c: StoreField: r1->field_c7 = r0
    //     0x11cb38c: stur            w0, [x1, #0xc7]
    // 0x11cb390: ldr             x0, [fp, #0xb0]
    // 0x11cb394: StoreField: r1->field_c3 = r0
    //     0x11cb394: stur            w0, [x1, #0xc3]
    // 0x11cb398: r0 = Instance_Clip
    //     0x11cb398: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0x11cb39c: ldr             x0, [x0, #0x850]
    // 0x11cb3a0: r17 = 267
    //     0x11cb3a0: mov             x17, #0x10b
    // 0x11cb3a4: str             w0, [x1, x17]
    // 0x11cb3a8: ldr             x0, [fp, #0xa8]
    // 0x11cb3ac: StoreField: r1->field_bf = r0
    //     0x11cb3ac: stur            w0, [x1, #0xbf]
    // 0x11cb3b0: r0 = false
    //     0x11cb3b0: add             x0, NULL, #0x30  ; false
    // 0x11cb3b4: StoreField: r1->field_b7 = r0
    //     0x11cb3b4: stur            w0, [x1, #0xb7]
    // 0x11cb3b8: StoreField: r1->field_53 = rZR
    //     0x11cb3b8: stur            xzr, [x1, #0x53]
    // 0x11cb3bc: StoreField: r1->field_4f = r0
    //     0x11cb3bc: stur            w0, [x1, #0x4f]
    // 0x11cb3c0: r0 = _LayoutCacheStorage()
    //     0x11cb3c0: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cb3c4: ldur            x2, [fp, #-8]
    // 0x11cb3c8: StoreField: r2->field_47 = r0
    //     0x11cb3c8: stur            w0, [x2, #0x47]
    //     0x11cb3cc: ldurb           w16, [x2, #-1]
    //     0x11cb3d0: ldurb           w17, [x0, #-1]
    //     0x11cb3d4: and             x16, x17, x16, lsr #2
    //     0x11cb3d8: tst             x16, HEAP, lsr #32
    //     0x11cb3dc: b.eq            #0x11cb3e4
    //     0x11cb3e0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cb3e4: mov             x1, x2
    // 0x11cb3e8: r0 = RenderObject()
    //     0x11cb3e8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cb3ec: ldur            x1, [fp, #-0x38]
    // 0x11cb3f0: ldr             x2, [fp, #0x50]
    // 0x11cb3f4: r0 = highlightColor=()
    //     0x11cb3f4: bl              #0xcf01ec  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::highlightColor=
    // 0x11cb3f8: ldur            x1, [fp, #-0x38]
    // 0x11cb3fc: ldr             x2, [fp, #0x58]
    // 0x11cb400: r0 = highlightedRange=()
    //     0x11cb400: bl              #0xcf010c  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::highlightedRange=
    // 0x11cb404: ldur            x0, [fp, #-0x38]
    // 0x11cb408: LoadField: r1 = r0->field_2f
    //     0x11cb408: ldur            w1, [x0, #0x2f]
    // 0x11cb40c: DecompressPointer r1
    //     0x11cb40c: add             x1, x1, HEAP, lsl #32
    // 0x11cb410: r16 = Instance_BoxHeightStyle
    //     0x11cb410: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a660] Obj!BoxHeightStyle@12c7321
    //     0x11cb414: ldr             x16, [x16, #0x660]
    // 0x11cb418: cmp             w1, w16
    // 0x11cb41c: b.ne            #0x11cb428
    // 0x11cb420: mov             x1, x0
    // 0x11cb424: b               #0x11cb440
    // 0x11cb428: r1 = Instance_BoxHeightStyle
    //     0x11cb428: add             x1, PP, #0x1a, lsl #12  ; [pp+0x1a660] Obj!BoxHeightStyle@12c7321
    //     0x11cb42c: ldr             x1, [x1, #0x660]
    // 0x11cb430: StoreField: r0->field_2f = r1
    //     0x11cb430: stur            w1, [x0, #0x2f]
    // 0x11cb434: mov             x1, x0
    // 0x11cb438: r0 = notifyListeners()
    //     0x11cb438: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x11cb43c: ldur            x1, [fp, #-0x38]
    // 0x11cb440: LoadField: r0 = r1->field_33
    //     0x11cb440: ldur            w0, [x1, #0x33]
    // 0x11cb444: DecompressPointer r0
    //     0x11cb444: add             x0, x0, HEAP, lsl #32
    // 0x11cb448: r16 = Instance_BoxWidthStyle
    //     0x11cb448: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1a668] Obj!BoxWidthStyle@12c72e1
    //     0x11cb44c: ldr             x16, [x16, #0x668]
    // 0x11cb450: cmp             w0, w16
    // 0x11cb454: b.eq            #0x11cb468
    // 0x11cb458: r0 = Instance_BoxWidthStyle
    //     0x11cb458: add             x0, PP, #0x1a, lsl #12  ; [pp+0x1a668] Obj!BoxWidthStyle@12c72e1
    //     0x11cb45c: ldr             x0, [x0, #0x668]
    // 0x11cb460: StoreField: r1->field_33 = r0
    //     0x11cb460: stur            w0, [x1, #0x33]
    // 0x11cb464: r0 = notifyListeners()
    //     0x11cb464: bl              #0x833be0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x11cb468: ldur            x0, [fp, #-8]
    // 0x11cb46c: ldur            x1, [fp, #-0x40]
    // 0x11cb470: ldr             x2, [fp, #0x70]
    // 0x11cb474: r0 = highlightColor=()
    //     0x11cb474: bl              #0xcf01ec  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::highlightColor=
    // 0x11cb478: ldur            x1, [fp, #-0x40]
    // 0x11cb47c: ldr             x2, [fp, #0x68]
    // 0x11cb480: r0 = highlightedRange=()
    //     0x11cb480: bl              #0xcf010c  ; [package:flutter/src/rendering/editable.dart] _TextHighlightPainter::highlightedRange=
    // 0x11cb484: ldur            x1, [fp, #-8]
    // 0x11cb488: LoadField: r0 = r1->field_73
    //     0x11cb488: ldur            w0, [x1, #0x73]
    // 0x11cb48c: DecompressPointer r0
    //     0x11cb48c: add             x0, x0, HEAP, lsl #32
    // 0x11cb490: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11cb494: cmp             w0, w16
    // 0x11cb498: b.ne            #0x11cb4a4
    // 0x11cb49c: r2 = _caretPainter
    //     0x11cb49c: ldr             x2, [PP, #0x4c38]  ; [pp+0x4c38] Field <RenderEditable._caretPainter@80245603>: late final (offset: 0x74)
    // 0x11cb4a0: r0 = InitLateFinalInstanceField()
    //     0x11cb4a0: bl              #0x13dd8a8  ; InitLateFinalInstanceFieldStub
    // 0x11cb4a4: mov             x1, x0
    // 0x11cb4a8: ldur            x2, [fp, #-0x10]
    // 0x11cb4ac: r0 = caretColor=()
    //     0x11cb4ac: bl              #0x869678  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::caretColor=
    // 0x11cb4b0: ldur            x0, [fp, #-8]
    // 0x11cb4b4: LoadField: r1 = r0->field_73
    //     0x11cb4b4: ldur            w1, [x0, #0x73]
    // 0x11cb4b8: DecompressPointer r1
    //     0x11cb4b8: add             x1, x1, HEAP, lsl #32
    // 0x11cb4bc: ldur            x2, [fp, #-0x20]
    // 0x11cb4c0: r0 = inactiveColor=()
    //     0x11cb4c0: bl              #0xcf0d78  ; [package:flutter/src/widgets/toggleable.dart] ToggleablePainter::inactiveColor=
    // 0x11cb4c4: ldur            x0, [fp, #-8]
    // 0x11cb4c8: LoadField: r1 = r0->field_73
    //     0x11cb4c8: ldur            w1, [x0, #0x73]
    // 0x11cb4cc: DecompressPointer r1
    //     0x11cb4cc: add             x1, x1, HEAP, lsl #32
    // 0x11cb4d0: ldur            x2, [fp, #-0x18]
    // 0x11cb4d4: r0 = cursorOffset=()
    //     0x11cb4d4: bl              #0xcf0c94  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::cursorOffset=
    // 0x11cb4d8: ldur            x0, [fp, #-8]
    // 0x11cb4dc: LoadField: r1 = r0->field_73
    //     0x11cb4dc: ldur            w1, [x0, #0x73]
    // 0x11cb4e0: DecompressPointer r1
    //     0x11cb4e0: add             x1, x1, HEAP, lsl #32
    // 0x11cb4e4: r2 = Instance_CupertinoDynamicColor
    //     0x11cb4e4: add             x2, PP, #0x26, lsl #12  ; [pp+0x26b50] Obj!CupertinoDynamicColor@12b36f1
    //     0x11cb4e8: ldr             x2, [x2, #0xb50]
    // 0x11cb4ec: r0 = backgroundCursorColor=()
    //     0x11cb4ec: bl              #0xcf1770  ; [package:flutter/src/rendering/editable.dart] _CaretPainter::backgroundCursorColor=
    // 0x11cb4f0: ldur            x1, [fp, #-8]
    // 0x11cb4f4: r0 = _updateForegroundPainter()
    //     0x11cb4f4: bl              #0xcf07e0  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_updateForegroundPainter
    // 0x11cb4f8: ldur            x1, [fp, #-8]
    // 0x11cb4fc: r0 = _updatePainter()
    //     0x11cb4fc: bl              #0xcf0304  ; [package:flutter/src/rendering/editable.dart] RenderEditable::_updatePainter
    // 0x11cb500: r0 = Null
    //     0x11cb500: mov             x0, NULL
    // 0x11cb504: LeaveFrame
    //     0x11cb504: mov             SP, fp
    //     0x11cb508: ldp             fp, lr, [SP], #0x10
    // 0x11cb50c: ret
    //     0x11cb50c: ret             
    // 0x11cb510: r0 = StackOverflowSharedWithFPURegs()
    //     0x11cb510: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11cb514: b               #0x11caf94
  }
  get _ wordBoundaries(/* No info */) {
    // ** addr: 0x12a20dc, size: 0x38
    // 0x12a20dc: EnterFrame
    //     0x12a20dc: stp             fp, lr, [SP, #-0x10]!
    //     0x12a20e0: mov             fp, SP
    // 0x12a20e4: CheckStackOverflow
    //     0x12a20e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12a20e8: cmp             SP, x16
    //     0x12a20ec: b.ls            #0x12a210c
    // 0x12a20f0: LoadField: r0 = r1->field_a7
    //     0x12a20f0: ldur            w0, [x1, #0xa7]
    // 0x12a20f4: DecompressPointer r0
    //     0x12a20f4: add             x0, x0, HEAP, lsl #32
    // 0x12a20f8: mov             x1, x0
    // 0x12a20fc: r0 = wordBoundaries()
    //     0x12a20fc: bl              #0x12a2114  ; [package:flutter/src/painting/text_painter.dart] TextPainter::wordBoundaries
    // 0x12a2100: LeaveFrame
    //     0x12a2100: mov             SP, fp
    //     0x12a2104: ldp             fp, lr, [SP], #0x10
    // 0x12a2108: ret
    //     0x12a2108: ret             
    // 0x12a210c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12a210c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12a2110: b               #0x12a20f0
  }
}
