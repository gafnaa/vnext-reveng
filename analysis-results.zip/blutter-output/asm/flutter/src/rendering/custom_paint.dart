// lib: , url: package:flutter/src/rendering/custom_paint.dart

// class id: 1049023, size: 0x8
class :: {
}

// class id: 2879, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class CustomPainterSemantics extends Object {
}

// class id: 4311, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class CustomPainter extends Listenable {

  _ removeListener(/* No info */) {
    // ** addr: 0xd0126c, size: 0x64
    // 0xd0126c: EnterFrame
    //     0xd0126c: stp             fp, lr, [SP, #-0x10]!
    //     0xd01270: mov             fp, SP
    // 0xd01274: CheckStackOverflow
    //     0xd01274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd01278: cmp             SP, x16
    //     0xd0127c: b.ls            #0xd012c8
    // 0xd01280: LoadField: r0 = r1->field_7
    //     0xd01280: ldur            w0, [x1, #7]
    // 0xd01284: DecompressPointer r0
    //     0xd01284: add             x0, x0, HEAP, lsl #32
    // 0xd01288: cmp             w0, NULL
    // 0xd0128c: b.ne            #0xd01298
    // 0xd01290: r0 = Null
    //     0xd01290: mov             x0, NULL
    // 0xd01294: b               #0xd012bc
    // 0xd01298: r1 = LoadClassIdInstr(r0)
    //     0xd01298: ldur            x1, [x0, #-1]
    //     0xd0129c: ubfx            x1, x1, #0xc, #0x14
    // 0xd012a0: mov             x16, x0
    // 0xd012a4: mov             x0, x1
    // 0xd012a8: mov             x1, x16
    // 0xd012ac: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xd012ac: mov             x17, #0xe2a3
    //     0xd012b0: add             lr, x0, x17
    //     0xd012b4: ldr             lr, [x21, lr, lsl #3]
    //     0xd012b8: blr             lr
    // 0xd012bc: LeaveFrame
    //     0xd012bc: mov             SP, fp
    //     0xd012c0: ldp             fp, lr, [SP], #0x10
    // 0xd012c4: ret
    //     0xd012c4: ret             
    // 0xd012c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd012c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd012cc: b               #0xd01280
  }
  _ shouldRebuildSemantics(/* No info */) {
    // ** addr: 0xd014d0, size: 0x44
    // 0xd014d0: EnterFrame
    //     0xd014d0: stp             fp, lr, [SP, #-0x10]!
    //     0xd014d4: mov             fp, SP
    // 0xd014d8: CheckStackOverflow
    //     0xd014d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd014dc: cmp             SP, x16
    //     0xd014e0: b.ls            #0xd0150c
    // 0xd014e4: r0 = LoadClassIdInstr(r1)
    //     0xd014e4: ldur            x0, [x1, #-1]
    //     0xd014e8: ubfx            x0, x0, #0xc, #0x14
    // 0xd014ec: r0 = GDT[cid_x0 + 0x11eeb]()
    //     0xd014ec: mov             x17, #0x1eeb
    //     0xd014f0: movk            x17, #1, lsl #16
    //     0xd014f4: add             lr, x0, x17
    //     0xd014f8: ldr             lr, [x21, lr, lsl #3]
    //     0xd014fc: blr             lr
    // 0xd01500: LeaveFrame
    //     0xd01500: mov             SP, fp
    //     0xd01504: ldp             fp, lr, [SP], #0x10
    // 0xd01508: ret
    //     0xd01508: ret             
    // 0xd0150c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd0150c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd01510: b               #0xd014e4
  }
  _ addListener(/* No info */) {
    // ** addr: 0xd0481c, size: 0x64
    // 0xd0481c: EnterFrame
    //     0xd0481c: stp             fp, lr, [SP, #-0x10]!
    //     0xd04820: mov             fp, SP
    // 0xd04824: CheckStackOverflow
    //     0xd04824: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xd04828: cmp             SP, x16
    //     0xd0482c: b.ls            #0xd04878
    // 0xd04830: LoadField: r0 = r1->field_7
    //     0xd04830: ldur            w0, [x1, #7]
    // 0xd04834: DecompressPointer r0
    //     0xd04834: add             x0, x0, HEAP, lsl #32
    // 0xd04838: cmp             w0, NULL
    // 0xd0483c: b.ne            #0xd04848
    // 0xd04840: r0 = Null
    //     0xd04840: mov             x0, NULL
    // 0xd04844: b               #0xd0486c
    // 0xd04848: r1 = LoadClassIdInstr(r0)
    //     0xd04848: ldur            x1, [x0, #-1]
    //     0xd0484c: ubfx            x1, x1, #0xc, #0x14
    // 0xd04850: mov             x16, x0
    // 0xd04854: mov             x0, x1
    // 0xd04858: mov             x1, x16
    // 0xd0485c: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xd0485c: mov             x17, #0xe0ec
    //     0xd04860: add             lr, x0, x17
    //     0xd04864: ldr             lr, [x21, lr, lsl #3]
    //     0xd04868: blr             lr
    // 0xd0486c: LeaveFrame
    //     0xd0486c: mov             SP, fp
    //     0xd04870: ldp             fp, lr, [SP], #0x10
    // 0xd04874: ret
    //     0xd04874: ret             
    // 0xd04878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd04878: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd0487c: b               #0xd04830
  }
}

// class id: 4956, size: 0x78, field offset: 0x54
class RenderCustomPaint extends RenderProxyBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16430, size: 0x24
    // 0xb16430: EnterFrame
    //     0xb16430: stp             fp, lr, [SP, #-0x10]!
    //     0xb16434: mov             fp, SP
    // 0xb16438: ldr             x2, [fp, #0x10]
    // 0xb1643c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1643c: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f48] AnonymousClosure: (0xb16454), in [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMinIntrinsicWidth (0xb164cc)
    //     0xb16440: ldr             x1, [x1, #0xf48]
    // 0xb16444: r0 = AllocateClosure()
    //     0xb16444: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16448: LeaveFrame
    //     0xb16448: mov             SP, fp
    //     0xb1644c: ldp             fp, lr, [SP], #0x10
    // 0xb16450: ret
    //     0xb16450: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16454, size: 0x78
    // 0xb16454: EnterFrame
    //     0xb16454: stp             fp, lr, [SP, #-0x10]!
    //     0xb16458: mov             fp, SP
    // 0xb1645c: ldr             x0, [fp, #0x18]
    // 0xb16460: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb16460: ldur            w1, [x0, #0x17]
    // 0xb16464: DecompressPointer r1
    //     0xb16464: add             x1, x1, HEAP, lsl #32
    // 0xb16468: CheckStackOverflow
    //     0xb16468: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1646c: cmp             SP, x16
    //     0xb16470: b.ls            #0xb164b4
    // 0xb16474: ldr             x2, [fp, #0x10]
    // 0xb16478: r0 = computeMinIntrinsicWidth()
    //     0xb16478: bl              #0xb164cc  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMinIntrinsicWidth
    // 0xb1647c: r0 = inline_Allocate_Double()
    //     0xb1647c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16480: add             x0, x0, #0x10
    //     0xb16484: cmp             x1, x0
    //     0xb16488: b.ls            #0xb164bc
    //     0xb1648c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16490: sub             x0, x0, #0xf
    //     0xb16494: mov             x1, #0xe19c
    //     0xb16498: movk            x1, #3, lsl #16
    //     0xb1649c: stur            x1, [x0, #-1]
    // 0xb164a0: dmb             ishst
    // 0xb164a4: StoreField: r0->field_7 = d0
    //     0xb164a4: stur            d0, [x0, #7]
    // 0xb164a8: LeaveFrame
    //     0xb164a8: mov             SP, fp
    //     0xb164ac: ldp             fp, lr, [SP], #0x10
    // 0xb164b0: ret
    //     0xb164b0: ret             
    // 0xb164b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb164b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb164b8: b               #0xb16474
    // 0xb164bc: SaveReg d0
    //     0xb164bc: str             q0, [SP, #-0x10]!
    // 0xb164c0: r0 = AllocateDouble()
    //     0xb164c0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb164c4: RestoreReg d0
    //     0xb164c4: ldr             q0, [SP], #0x10
    // 0xb164c8: b               #0xb164a4
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb164cc, size: 0x74
    // 0xb164cc: EnterFrame
    //     0xb164cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb164d0: mov             fp, SP
    // 0xb164d4: CheckStackOverflow
    //     0xb164d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb164d8: cmp             SP, x16
    //     0xb164dc: b.ls            #0xb16538
    // 0xb164e0: LoadField: r0 = r1->field_4f
    //     0xb164e0: ldur            w0, [x1, #0x4f]
    // 0xb164e4: DecompressPointer r0
    //     0xb164e4: add             x0, x0, HEAP, lsl #32
    // 0xb164e8: cmp             w0, NULL
    // 0xb164ec: b.ne            #0xb16528
    // 0xb164f0: LoadField: r0 = r1->field_5b
    //     0xb164f0: ldur            w0, [x1, #0x5b]
    // 0xb164f4: DecompressPointer r0
    //     0xb164f4: add             x0, x0, HEAP, lsl #32
    // 0xb164f8: LoadField: d0 = r0->field_7
    //     0xb164f8: ldur            d0, [x0, #7]
    // 0xb164fc: mov             x0, v0.d[0]
    // 0xb16500: and             x0, x0, #0x7fffffffffffffff
    // 0xb16504: r17 = 9218868437227405312
    //     0xb16504: mov             x17, #0x7ff0000000000000
    // 0xb16508: cmp             x0, x17
    // 0xb1650c: b.eq            #0xb16518
    // 0xb16510: fcmp            d0, d0
    // 0xb16514: b.vc            #0xb1651c
    // 0xb16518: d0 = 0.000000
    //     0xb16518: eor             v0.16b, v0.16b, v0.16b
    // 0xb1651c: LeaveFrame
    //     0xb1651c: mov             SP, fp
    //     0xb16520: ldp             fp, lr, [SP], #0x10
    // 0xb16524: ret
    //     0xb16524: ret             
    // 0xb16528: r0 = computeMinIntrinsicWidth()
    //     0xb16528: bl              #0xb16174  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0xb1652c: LeaveFrame
    //     0xb1652c: mov             SP, fp
    //     0xb16530: ldp             fp, lr, [SP], #0x10
    // 0xb16534: ret
    //     0xb16534: ret             
    // 0xb16538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16538: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1653c: b               #0xb164e0
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb22b1c, size: 0x74
    // 0xb22b1c: EnterFrame
    //     0xb22b1c: stp             fp, lr, [SP, #-0x10]!
    //     0xb22b20: mov             fp, SP
    // 0xb22b24: CheckStackOverflow
    //     0xb22b24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22b28: cmp             SP, x16
    //     0xb22b2c: b.ls            #0xb22b88
    // 0xb22b30: LoadField: r0 = r1->field_4f
    //     0xb22b30: ldur            w0, [x1, #0x4f]
    // 0xb22b34: DecompressPointer r0
    //     0xb22b34: add             x0, x0, HEAP, lsl #32
    // 0xb22b38: cmp             w0, NULL
    // 0xb22b3c: b.ne            #0xb22b78
    // 0xb22b40: LoadField: r0 = r1->field_5b
    //     0xb22b40: ldur            w0, [x1, #0x5b]
    // 0xb22b44: DecompressPointer r0
    //     0xb22b44: add             x0, x0, HEAP, lsl #32
    // 0xb22b48: LoadField: d0 = r0->field_f
    //     0xb22b48: ldur            d0, [x0, #0xf]
    // 0xb22b4c: mov             x0, v0.d[0]
    // 0xb22b50: and             x0, x0, #0x7fffffffffffffff
    // 0xb22b54: r17 = 9218868437227405312
    //     0xb22b54: mov             x17, #0x7ff0000000000000
    // 0xb22b58: cmp             x0, x17
    // 0xb22b5c: b.eq            #0xb22b68
    // 0xb22b60: fcmp            d0, d0
    // 0xb22b64: b.vc            #0xb22b6c
    // 0xb22b68: d0 = 0.000000
    //     0xb22b68: eor             v0.16b, v0.16b, v0.16b
    // 0xb22b6c: LeaveFrame
    //     0xb22b6c: mov             SP, fp
    //     0xb22b70: ldp             fp, lr, [SP], #0x10
    // 0xb22b74: ret
    //     0xb22b74: ret             
    // 0xb22b78: r0 = computeMinIntrinsicHeight()
    //     0xb22b78: bl              #0xb23590  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMinIntrinsicHeight
    // 0xb22b7c: LeaveFrame
    //     0xb22b7c: mov             SP, fp
    //     0xb22b80: ldp             fp, lr, [SP], #0x10
    // 0xb22b84: ret
    //     0xb22b84: ret             
    // 0xb22b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22b88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22b8c: b               #0xb22b30
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb22b90, size: 0x78
    // 0xb22b90: EnterFrame
    //     0xb22b90: stp             fp, lr, [SP, #-0x10]!
    //     0xb22b94: mov             fp, SP
    // 0xb22b98: ldr             x0, [fp, #0x18]
    // 0xb22b9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb22b9c: ldur            w1, [x0, #0x17]
    // 0xb22ba0: DecompressPointer r1
    //     0xb22ba0: add             x1, x1, HEAP, lsl #32
    // 0xb22ba4: CheckStackOverflow
    //     0xb22ba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22ba8: cmp             SP, x16
    //     0xb22bac: b.ls            #0xb22bf0
    // 0xb22bb0: ldr             x2, [fp, #0x10]
    // 0xb22bb4: r0 = computeMinIntrinsicHeight()
    //     0xb22bb4: bl              #0xb22b1c  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMinIntrinsicHeight
    // 0xb22bb8: r0 = inline_Allocate_Double()
    //     0xb22bb8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb22bbc: add             x0, x0, #0x10
    //     0xb22bc0: cmp             x1, x0
    //     0xb22bc4: b.ls            #0xb22bf8
    //     0xb22bc8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb22bcc: sub             x0, x0, #0xf
    //     0xb22bd0: mov             x1, #0xe19c
    //     0xb22bd4: movk            x1, #3, lsl #16
    //     0xb22bd8: stur            x1, [x0, #-1]
    // 0xb22bdc: dmb             ishst
    // 0xb22be0: StoreField: r0->field_7 = d0
    //     0xb22be0: stur            d0, [x0, #7]
    // 0xb22be4: LeaveFrame
    //     0xb22be4: mov             SP, fp
    //     0xb22be8: ldp             fp, lr, [SP], #0x10
    // 0xb22bec: ret
    //     0xb22bec: ret             
    // 0xb22bf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22bf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22bf4: b               #0xb22bb0
    // 0xb22bf8: SaveReg d0
    //     0xb22bf8: str             q0, [SP, #-0x10]!
    // 0xb22bfc: r0 = AllocateDouble()
    //     0xb22bfc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb22c00: RestoreReg d0
    //     0xb22c00: ldr             q0, [SP], #0x10
    // 0xb22c04: b               #0xb22be0
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2972c, size: 0x74
    // 0xb2972c: EnterFrame
    //     0xb2972c: stp             fp, lr, [SP, #-0x10]!
    //     0xb29730: mov             fp, SP
    // 0xb29734: CheckStackOverflow
    //     0xb29734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29738: cmp             SP, x16
    //     0xb2973c: b.ls            #0xb29798
    // 0xb29740: LoadField: r0 = r1->field_4f
    //     0xb29740: ldur            w0, [x1, #0x4f]
    // 0xb29744: DecompressPointer r0
    //     0xb29744: add             x0, x0, HEAP, lsl #32
    // 0xb29748: cmp             w0, NULL
    // 0xb2974c: b.ne            #0xb29788
    // 0xb29750: LoadField: r0 = r1->field_5b
    //     0xb29750: ldur            w0, [x1, #0x5b]
    // 0xb29754: DecompressPointer r0
    //     0xb29754: add             x0, x0, HEAP, lsl #32
    // 0xb29758: LoadField: d0 = r0->field_f
    //     0xb29758: ldur            d0, [x0, #0xf]
    // 0xb2975c: mov             x0, v0.d[0]
    // 0xb29760: and             x0, x0, #0x7fffffffffffffff
    // 0xb29764: r17 = 9218868437227405312
    //     0xb29764: mov             x17, #0x7ff0000000000000
    // 0xb29768: cmp             x0, x17
    // 0xb2976c: b.eq            #0xb29778
    // 0xb29770: fcmp            d0, d0
    // 0xb29774: b.vc            #0xb2977c
    // 0xb29778: d0 = 0.000000
    //     0xb29778: eor             v0.16b, v0.16b, v0.16b
    // 0xb2977c: LeaveFrame
    //     0xb2977c: mov             SP, fp
    //     0xb29780: ldp             fp, lr, [SP], #0x10
    // 0xb29784: ret
    //     0xb29784: ret             
    // 0xb29788: r0 = computeMaxIntrinsicHeight()
    //     0xb29788: bl              #0xb2a3e0  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicHeight
    // 0xb2978c: LeaveFrame
    //     0xb2978c: mov             SP, fp
    //     0xb29790: ldp             fp, lr, [SP], #0x10
    // 0xb29794: ret
    //     0xb29794: ret             
    // 0xb29798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29798: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2979c: b               #0xb29740
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb297a0, size: 0x78
    // 0xb297a0: EnterFrame
    //     0xb297a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb297a4: mov             fp, SP
    // 0xb297a8: ldr             x0, [fp, #0x18]
    // 0xb297ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb297ac: ldur            w1, [x0, #0x17]
    // 0xb297b0: DecompressPointer r1
    //     0xb297b0: add             x1, x1, HEAP, lsl #32
    // 0xb297b4: CheckStackOverflow
    //     0xb297b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb297b8: cmp             SP, x16
    //     0xb297bc: b.ls            #0xb29800
    // 0xb297c0: ldr             x2, [fp, #0x10]
    // 0xb297c4: r0 = computeMaxIntrinsicHeight()
    //     0xb297c4: bl              #0xb2972c  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMaxIntrinsicHeight
    // 0xb297c8: r0 = inline_Allocate_Double()
    //     0xb297c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb297cc: add             x0, x0, #0x10
    //     0xb297d0: cmp             x1, x0
    //     0xb297d4: b.ls            #0xb29808
    //     0xb297d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb297dc: sub             x0, x0, #0xf
    //     0xb297e0: mov             x1, #0xe19c
    //     0xb297e4: movk            x1, #3, lsl #16
    //     0xb297e8: stur            x1, [x0, #-1]
    // 0xb297ec: dmb             ishst
    // 0xb297f0: StoreField: r0->field_7 = d0
    //     0xb297f0: stur            d0, [x0, #7]
    // 0xb297f4: LeaveFrame
    //     0xb297f4: mov             SP, fp
    //     0xb297f8: ldp             fp, lr, [SP], #0x10
    // 0xb297fc: ret
    //     0xb297fc: ret             
    // 0xb29800: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29800: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29804: b               #0xb297c0
    // 0xb29808: SaveReg d0
    //     0xb29808: str             q0, [SP, #-0x10]!
    // 0xb2980c: r0 = AllocateDouble()
    //     0xb2980c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29810: RestoreReg d0
    //     0xb29810: ldr             q0, [SP], #0x10
    // 0xb29814: b               #0xb297f0
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2ca18, size: 0x74
    // 0xb2ca18: EnterFrame
    //     0xb2ca18: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ca1c: mov             fp, SP
    // 0xb2ca20: CheckStackOverflow
    //     0xb2ca20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ca24: cmp             SP, x16
    //     0xb2ca28: b.ls            #0xb2ca84
    // 0xb2ca2c: LoadField: r0 = r1->field_4f
    //     0xb2ca2c: ldur            w0, [x1, #0x4f]
    // 0xb2ca30: DecompressPointer r0
    //     0xb2ca30: add             x0, x0, HEAP, lsl #32
    // 0xb2ca34: cmp             w0, NULL
    // 0xb2ca38: b.ne            #0xb2ca74
    // 0xb2ca3c: LoadField: r0 = r1->field_5b
    //     0xb2ca3c: ldur            w0, [x1, #0x5b]
    // 0xb2ca40: DecompressPointer r0
    //     0xb2ca40: add             x0, x0, HEAP, lsl #32
    // 0xb2ca44: LoadField: d0 = r0->field_7
    //     0xb2ca44: ldur            d0, [x0, #7]
    // 0xb2ca48: mov             x0, v0.d[0]
    // 0xb2ca4c: and             x0, x0, #0x7fffffffffffffff
    // 0xb2ca50: r17 = 9218868437227405312
    //     0xb2ca50: mov             x17, #0x7ff0000000000000
    // 0xb2ca54: cmp             x0, x17
    // 0xb2ca58: b.eq            #0xb2ca64
    // 0xb2ca5c: fcmp            d0, d0
    // 0xb2ca60: b.vc            #0xb2ca68
    // 0xb2ca64: d0 = 0.000000
    //     0xb2ca64: eor             v0.16b, v0.16b, v0.16b
    // 0xb2ca68: LeaveFrame
    //     0xb2ca68: mov             SP, fp
    //     0xb2ca6c: ldp             fp, lr, [SP], #0x10
    // 0xb2ca70: ret
    //     0xb2ca70: ret             
    // 0xb2ca74: r0 = computeMaxIntrinsicWidth()
    //     0xb2ca74: bl              #0xb2d828  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicWidth
    // 0xb2ca78: LeaveFrame
    //     0xb2ca78: mov             SP, fp
    //     0xb2ca7c: ldp             fp, lr, [SP], #0x10
    // 0xb2ca80: ret
    //     0xb2ca80: ret             
    // 0xb2ca84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ca84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ca88: b               #0xb2ca2c
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2ca8c, size: 0x78
    // 0xb2ca8c: EnterFrame
    //     0xb2ca8c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ca90: mov             fp, SP
    // 0xb2ca94: ldr             x0, [fp, #0x18]
    // 0xb2ca98: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2ca98: ldur            w1, [x0, #0x17]
    // 0xb2ca9c: DecompressPointer r1
    //     0xb2ca9c: add             x1, x1, HEAP, lsl #32
    // 0xb2caa0: CheckStackOverflow
    //     0xb2caa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2caa4: cmp             SP, x16
    //     0xb2caa8: b.ls            #0xb2caec
    // 0xb2caac: ldr             x2, [fp, #0x10]
    // 0xb2cab0: r0 = computeMaxIntrinsicWidth()
    //     0xb2cab0: bl              #0xb2ca18  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMaxIntrinsicWidth
    // 0xb2cab4: r0 = inline_Allocate_Double()
    //     0xb2cab4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2cab8: add             x0, x0, #0x10
    //     0xb2cabc: cmp             x1, x0
    //     0xb2cac0: b.ls            #0xb2caf4
    //     0xb2cac4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2cac8: sub             x0, x0, #0xf
    //     0xb2cacc: mov             x1, #0xe19c
    //     0xb2cad0: movk            x1, #3, lsl #16
    //     0xb2cad4: stur            x1, [x0, #-1]
    // 0xb2cad8: dmb             ishst
    // 0xb2cadc: StoreField: r0->field_7 = d0
    //     0xb2cadc: stur            d0, [x0, #7]
    // 0xb2cae0: LeaveFrame
    //     0xb2cae0: mov             SP, fp
    //     0xb2cae4: ldp             fp, lr, [SP], #0x10
    // 0xb2cae8: ret
    //     0xb2cae8: ret             
    // 0xb2caec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2caec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2caf0: b               #0xb2caac
    // 0xb2caf4: SaveReg d0
    //     0xb2caf4: str             q0, [SP, #-0x10]!
    // 0xb2caf8: r0 = AllocateDouble()
    //     0xb2caf8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2cafc: RestoreReg d0
    //     0xb2cafc: ldr             q0, [SP], #0x10
    // 0xb2cb00: b               #0xb2cadc
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb57f28, size: 0x24
    // 0xb57f28: EnterFrame
    //     0xb57f28: stp             fp, lr, [SP, #-0x10]!
    //     0xb57f2c: mov             fp, SP
    // 0xb57f30: ldr             x2, [fp, #0x10]
    // 0xb57f34: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb57f34: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f40] AnonymousClosure: (0xb2ca8c), in [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMaxIntrinsicWidth (0xb2ca18)
    //     0xb57f38: ldr             x1, [x1, #0xf40]
    // 0xb57f3c: r0 = AllocateClosure()
    //     0xb57f3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb57f40: LeaveFrame
    //     0xb57f40: mov             SP, fp
    //     0xb57f44: ldp             fp, lr, [SP], #0x10
    // 0xb57f48: ret
    //     0xb57f48: ret             
  }
  _ hitTestSelf(/* No info */) {
    // ** addr: 0xb5d1a4, size: 0x68
    // 0xb5d1a4: EnterFrame
    //     0xb5d1a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5d1a8: mov             fp, SP
    // 0xb5d1ac: CheckStackOverflow
    //     0xb5d1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5d1b0: cmp             SP, x16
    //     0xb5d1b4: b.ls            #0xb5d204
    // 0xb5d1b8: LoadField: r0 = r1->field_53
    //     0xb5d1b8: ldur            w0, [x1, #0x53]
    // 0xb5d1bc: DecompressPointer r0
    //     0xb5d1bc: add             x0, x0, HEAP, lsl #32
    // 0xb5d1c0: cmp             w0, NULL
    // 0xb5d1c4: b.eq            #0xb5d1f4
    // 0xb5d1c8: r1 = LoadClassIdInstr(r0)
    //     0xb5d1c8: ldur            x1, [x0, #-1]
    //     0xb5d1cc: ubfx            x1, x1, #0xc, #0x14
    // 0xb5d1d0: mov             x16, x0
    // 0xb5d1d4: mov             x0, x1
    // 0xb5d1d8: mov             x1, x16
    // 0xb5d1dc: r0 = GDT[cid_x0 + 0xfc88]()
    //     0xb5d1dc: mov             x17, #0xfc88
    //     0xb5d1e0: add             lr, x0, x17
    //     0xb5d1e4: ldr             lr, [x21, lr, lsl #3]
    //     0xb5d1e8: blr             lr
    // 0xb5d1ec: r0 = true
    //     0xb5d1ec: add             x0, NULL, #0x20  ; true
    // 0xb5d1f0: b               #0xb5d1f8
    // 0xb5d1f4: r0 = false
    //     0xb5d1f4: add             x0, NULL, #0x30  ; false
    // 0xb5d1f8: LeaveFrame
    //     0xb5d1f8: mov             SP, fp
    //     0xb5d1fc: ldp             fp, lr, [SP], #0x10
    // 0xb5d200: ret
    //     0xb5d200: ret             
    // 0xb5d204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5d204: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5d208: b               #0xb5d1b8
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e23c, size: 0x24
    // 0xb5e23c: EnterFrame
    //     0xb5e23c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e240: mov             fp, SP
    // 0xb5e244: ldr             x2, [fp, #0x10]
    // 0xb5e248: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e248: add             x1, PP, #0x99, lsl #12  ; [pp+0x99e80] AnonymousClosure: (0xb297a0), in [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMaxIntrinsicHeight (0xb2972c)
    //     0xb5e24c: ldr             x1, [x1, #0xe80]
    // 0xb5e250: r0 = AllocateClosure()
    //     0xb5e250: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e254: LeaveFrame
    //     0xb5e254: mov             SP, fp
    //     0xb5e258: ldp             fp, lr, [SP], #0x10
    // 0xb5e25c: ret
    //     0xb5e25c: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbb9128, size: 0x48
    // 0xbb9128: EnterFrame
    //     0xbb9128: stp             fp, lr, [SP, #-0x10]!
    //     0xbb912c: mov             fp, SP
    // 0xbb9130: AllocStack(0x8)
    //     0xbb9130: sub             SP, SP, #8
    // 0xbb9134: SetupParameters(RenderCustomPaint this /* r1 => r0, fp-0x8 */)
    //     0xbb9134: mov             x0, x1
    //     0xbb9138: stur            x1, [fp, #-8]
    // 0xbb913c: CheckStackOverflow
    //     0xbb913c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbb9140: cmp             SP, x16
    //     0xbb9144: b.ls            #0xbb9168
    // 0xbb9148: mov             x1, x0
    // 0xbb914c: r0 = performLayout()
    //     0xbb914c: bl              #0xbba2a4  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::performLayout
    // 0xbb9150: ldur            x1, [fp, #-8]
    // 0xbb9154: r0 = markNeedsSemanticsUpdate()
    //     0xbb9154: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xbb9158: r0 = Null
    //     0xbb9158: mov             x0, NULL
    // 0xbb915c: LeaveFrame
    //     0xbb915c: mov             SP, fp
    //     0xbb9160: ldp             fp, lr, [SP], #0x10
    // 0xbb9164: ret
    //     0xbb9164: ret             
    // 0xbb9168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb9168: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb916c: b               #0xbb9148
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf55d0, size: 0xb8
    // 0xbf55d0: EnterFrame
    //     0xbf55d0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf55d4: mov             fp, SP
    // 0xbf55d8: AllocStack(0x10)
    //     0xbf55d8: sub             SP, SP, #0x10
    // 0xbf55dc: SetupParameters(RenderCustomPaint this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbf55dc: mov             x3, x1
    //     0xbf55e0: stur            x1, [fp, #-8]
    //     0xbf55e4: stur            x2, [fp, #-0x10]
    // 0xbf55e8: CheckStackOverflow
    //     0xbf55e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf55ec: cmp             SP, x16
    //     0xbf55f0: b.ls            #0xbf5680
    // 0xbf55f4: LoadField: r1 = r3->field_53
    //     0xbf55f4: ldur            w1, [x3, #0x53]
    // 0xbf55f8: DecompressPointer r1
    //     0xbf55f8: add             x1, x1, HEAP, lsl #32
    // 0xbf55fc: cmp             w1, NULL
    // 0xbf5600: b.ne            #0xbf560c
    // 0xbf5604: mov             x2, x3
    // 0xbf5608: b               #0xbf5628
    // 0xbf560c: r0 = LoadClassIdInstr(r1)
    //     0xbf560c: ldur            x0, [x1, #-1]
    //     0xbf5610: ubfx            x0, x0, #0xc, #0x14
    // 0xbf5614: r0 = GDT[cid_x0 + 0xec6d]()
    //     0xbf5614: mov             x17, #0xec6d
    //     0xbf5618: add             lr, x0, x17
    //     0xbf561c: ldr             lr, [x21, lr, lsl #3]
    //     0xbf5620: blr             lr
    // 0xbf5624: ldur            x2, [fp, #-8]
    // 0xbf5628: StoreField: r2->field_67 = rNULL
    //     0xbf5628: stur            NULL, [x2, #0x67]
    // 0xbf562c: LoadField: r1 = r2->field_57
    //     0xbf562c: ldur            w1, [x2, #0x57]
    // 0xbf5630: DecompressPointer r1
    //     0xbf5630: add             x1, x1, HEAP, lsl #32
    // 0xbf5634: cmp             w1, NULL
    // 0xbf5638: b.ne            #0xbf5644
    // 0xbf563c: mov             x1, x2
    // 0xbf5640: b               #0xbf5660
    // 0xbf5644: r0 = LoadClassIdInstr(r1)
    //     0xbf5644: ldur            x0, [x1, #-1]
    //     0xbf5648: ubfx            x0, x0, #0xc, #0x14
    // 0xbf564c: r0 = GDT[cid_x0 + 0xec6d]()
    //     0xbf564c: mov             x17, #0xec6d
    //     0xbf5650: add             lr, x0, x17
    //     0xbf5654: ldr             lr, [x21, lr, lsl #3]
    //     0xbf5658: blr             lr
    // 0xbf565c: ldur            x1, [fp, #-8]
    // 0xbf5660: ldur            x2, [fp, #-0x10]
    // 0xbf5664: r3 = false
    //     0xbf5664: add             x3, NULL, #0x30  ; false
    // 0xbf5668: StoreField: r1->field_6b = rNULL
    //     0xbf5668: stur            NULL, [x1, #0x6b]
    // 0xbf566c: StoreField: r2->field_7 = r3
    //     0xbf566c: stur            w3, [x2, #7]
    // 0xbf5670: r0 = Null
    //     0xbf5670: mov             x0, NULL
    // 0xbf5674: LeaveFrame
    //     0xbf5674: mov             SP, fp
    //     0xbf5678: ldp             fp, lr, [SP], #0x10
    // 0xbf567c: ret
    //     0xbf567c: ret             
    // 0xbf5680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5680: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5684: b               #0xbf55f4
  }
  _ detach(/* No info */) {
    // ** addr: 0xc05b50, size: 0xdc
    // 0xc05b50: EnterFrame
    //     0xc05b50: stp             fp, lr, [SP, #-0x10]!
    //     0xc05b54: mov             fp, SP
    // 0xc05b58: AllocStack(0x10)
    //     0xc05b58: sub             SP, SP, #0x10
    // 0xc05b5c: SetupParameters(RenderCustomPaint this /* r1 => r0, fp-0x10 */)
    //     0xc05b5c: mov             x0, x1
    //     0xc05b60: stur            x1, [fp, #-0x10]
    // 0xc05b64: CheckStackOverflow
    //     0xc05b64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05b68: cmp             SP, x16
    //     0xc05b6c: b.ls            #0xc05c24
    // 0xc05b70: LoadField: r3 = r0->field_53
    //     0xc05b70: ldur            w3, [x0, #0x53]
    // 0xc05b74: DecompressPointer r3
    //     0xc05b74: add             x3, x3, HEAP, lsl #32
    // 0xc05b78: stur            x3, [fp, #-8]
    // 0xc05b7c: cmp             w3, NULL
    // 0xc05b80: b.eq            #0xc05bc0
    // 0xc05b84: mov             x2, x0
    // 0xc05b88: r1 = Function 'markNeedsPaint':.
    //     0xc05b88: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc05b8c: ldr             x1, [x1, #0x1f0]
    // 0xc05b90: r0 = AllocateClosure()
    //     0xc05b90: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc05b94: ldur            x1, [fp, #-8]
    // 0xc05b98: r2 = LoadClassIdInstr(r1)
    //     0xc05b98: ldur            x2, [x1, #-1]
    //     0xc05b9c: ubfx            x2, x2, #0xc, #0x14
    // 0xc05ba0: mov             x16, x0
    // 0xc05ba4: mov             x0, x2
    // 0xc05ba8: mov             x2, x16
    // 0xc05bac: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xc05bac: mov             x17, #0xe2a3
    //     0xc05bb0: add             lr, x0, x17
    //     0xc05bb4: ldr             lr, [x21, lr, lsl #3]
    //     0xc05bb8: blr             lr
    // 0xc05bbc: ldur            x0, [fp, #-0x10]
    // 0xc05bc0: LoadField: r3 = r0->field_57
    //     0xc05bc0: ldur            w3, [x0, #0x57]
    // 0xc05bc4: DecompressPointer r3
    //     0xc05bc4: add             x3, x3, HEAP, lsl #32
    // 0xc05bc8: stur            x3, [fp, #-8]
    // 0xc05bcc: cmp             w3, NULL
    // 0xc05bd0: b.eq            #0xc05c0c
    // 0xc05bd4: mov             x2, x0
    // 0xc05bd8: r1 = Function 'markNeedsPaint':.
    //     0xc05bd8: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc05bdc: ldr             x1, [x1, #0x1f0]
    // 0xc05be0: r0 = AllocateClosure()
    //     0xc05be0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc05be4: ldur            x1, [fp, #-8]
    // 0xc05be8: r2 = LoadClassIdInstr(r1)
    //     0xc05be8: ldur            x2, [x1, #-1]
    //     0xc05bec: ubfx            x2, x2, #0xc, #0x14
    // 0xc05bf0: mov             x16, x0
    // 0xc05bf4: mov             x0, x2
    // 0xc05bf8: mov             x2, x16
    // 0xc05bfc: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xc05bfc: mov             x17, #0xe2a3
    //     0xc05c00: add             lr, x0, x17
    //     0xc05c04: ldr             lr, [x21, lr, lsl #3]
    //     0xc05c08: blr             lr
    // 0xc05c0c: ldur            x1, [fp, #-0x10]
    // 0xc05c10: r0 = detach()
    //     0xc05c10: bl              #0xc061c8  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::detach
    // 0xc05c14: r0 = Null
    //     0xc05c14: mov             x0, NULL
    // 0xc05c18: LeaveFrame
    //     0xc05c18: mov             SP, fp
    //     0xc05c1c: ldp             fp, lr, [SP], #0x10
    // 0xc05c20: ret
    //     0xc05c20: ret             
    // 0xc05c24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc05c24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc05c28: b               #0xc05b70
  }
  _ attach(/* No info */) {
    // ** addr: 0xc09678, size: 0xe4
    // 0xc09678: EnterFrame
    //     0xc09678: stp             fp, lr, [SP, #-0x10]!
    //     0xc0967c: mov             fp, SP
    // 0xc09680: AllocStack(0x10)
    //     0xc09680: sub             SP, SP, #0x10
    // 0xc09684: SetupParameters(RenderCustomPaint this /* r1 => r0, fp-0x8 */)
    //     0xc09684: mov             x0, x1
    //     0xc09688: stur            x1, [fp, #-8]
    // 0xc0968c: CheckStackOverflow
    //     0xc0968c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc09690: cmp             SP, x16
    //     0xc09694: b.ls            #0xc09754
    // 0xc09698: mov             x1, x0
    // 0xc0969c: r0 = attach()
    //     0xc0969c: bl              #0xc09a60  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::attach
    // 0xc096a0: ldur            x0, [fp, #-8]
    // 0xc096a4: LoadField: r3 = r0->field_53
    //     0xc096a4: ldur            w3, [x0, #0x53]
    // 0xc096a8: DecompressPointer r3
    //     0xc096a8: add             x3, x3, HEAP, lsl #32
    // 0xc096ac: stur            x3, [fp, #-0x10]
    // 0xc096b0: cmp             w3, NULL
    // 0xc096b4: b.ne            #0xc096c0
    // 0xc096b8: mov             x2, x0
    // 0xc096bc: b               #0xc096fc
    // 0xc096c0: mov             x2, x0
    // 0xc096c4: r1 = Function 'markNeedsPaint':.
    //     0xc096c4: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc096c8: ldr             x1, [x1, #0x1f0]
    // 0xc096cc: r0 = AllocateClosure()
    //     0xc096cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc096d0: ldur            x1, [fp, #-0x10]
    // 0xc096d4: r2 = LoadClassIdInstr(r1)
    //     0xc096d4: ldur            x2, [x1, #-1]
    //     0xc096d8: ubfx            x2, x2, #0xc, #0x14
    // 0xc096dc: mov             x16, x0
    // 0xc096e0: mov             x0, x2
    // 0xc096e4: mov             x2, x16
    // 0xc096e8: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xc096e8: mov             x17, #0xe0ec
    //     0xc096ec: add             lr, x0, x17
    //     0xc096f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc096f4: blr             lr
    // 0xc096f8: ldur            x2, [fp, #-8]
    // 0xc096fc: LoadField: r0 = r2->field_57
    //     0xc096fc: ldur            w0, [x2, #0x57]
    // 0xc09700: DecompressPointer r0
    //     0xc09700: add             x0, x0, HEAP, lsl #32
    // 0xc09704: stur            x0, [fp, #-0x10]
    // 0xc09708: cmp             w0, NULL
    // 0xc0970c: b.eq            #0xc09744
    // 0xc09710: r1 = Function 'markNeedsPaint':.
    //     0xc09710: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xc09714: ldr             x1, [x1, #0x1f0]
    // 0xc09718: r0 = AllocateClosure()
    //     0xc09718: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0971c: ldur            x1, [fp, #-0x10]
    // 0xc09720: r2 = LoadClassIdInstr(r1)
    //     0xc09720: ldur            x2, [x1, #-1]
    //     0xc09724: ubfx            x2, x2, #0xc, #0x14
    // 0xc09728: mov             x16, x0
    // 0xc0972c: mov             x0, x2
    // 0xc09730: mov             x2, x16
    // 0xc09734: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xc09734: mov             x17, #0xe0ec
    //     0xc09738: add             lr, x0, x17
    //     0xc0973c: ldr             lr, [x21, lr, lsl #3]
    //     0xc09740: blr             lr
    // 0xc09744: r0 = Null
    //     0xc09744: mov             x0, NULL
    // 0xc09748: LeaveFrame
    //     0xc09748: mov             SP, fp
    //     0xc0974c: ldp             fp, lr, [SP], #0x10
    // 0xc09750: ret
    //     0xc09750: ret             
    // 0xc09754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc09754: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc09758: b               #0xc09698
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0xc10a90, size: 0x1b4
    // 0xc10a90: EnterFrame
    //     0xc10a90: stp             fp, lr, [SP, #-0x10]!
    //     0xc10a94: mov             fp, SP
    // 0xc10a98: AllocStack(0x40)
    //     0xc10a98: sub             SP, SP, #0x40
    // 0xc10a9c: SetupParameters(RenderCustomPaint this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */)
    //     0xc10a9c: mov             x0, x5
    //     0xc10aa0: stur            x5, [fp, #-0x20]
    //     0xc10aa4: mov             x5, x1
    //     0xc10aa8: mov             x4, x2
    //     0xc10aac: stur            x1, [fp, #-8]
    //     0xc10ab0: stur            x2, [fp, #-0x10]
    //     0xc10ab4: stur            x3, [fp, #-0x18]
    // 0xc10ab8: CheckStackOverflow
    //     0xc10ab8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc10abc: cmp             SP, x16
    //     0xc10ac0: b.ls            #0xc10c34
    // 0xc10ac4: LoadField: r1 = r5->field_6f
    //     0xc10ac4: ldur            w1, [x5, #0x6f]
    // 0xc10ac8: DecompressPointer r1
    //     0xc10ac8: add             x1, x1, HEAP, lsl #32
    // 0xc10acc: r2 = const []
    //     0xc10acc: add             x2, PP, #0x99, lsl #12  ; [pp+0x99e88] List<CustomPainterSemantics>(0)
    //     0xc10ad0: ldr             x2, [x2, #0xe88]
    // 0xc10ad4: r0 = _updateSemanticsChildren()
    //     0xc10ad4: bl              #0xc10c44  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_updateSemanticsChildren
    // 0xc10ad8: ldur            x3, [fp, #-8]
    // 0xc10adc: StoreField: r3->field_6f = r0
    //     0xc10adc: stur            w0, [x3, #0x6f]
    //     0xc10ae0: ldurb           w16, [x3, #-1]
    //     0xc10ae4: ldurb           w17, [x0, #-1]
    //     0xc10ae8: and             x16, x17, x16, lsr #2
    //     0xc10aec: tst             x16, HEAP, lsr #32
    //     0xc10af0: b.eq            #0xc10af8
    //     0xc10af4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc10af8: LoadField: r1 = r3->field_73
    //     0xc10af8: ldur            w1, [x3, #0x73]
    // 0xc10afc: DecompressPointer r1
    //     0xc10afc: add             x1, x1, HEAP, lsl #32
    // 0xc10b00: r2 = const []
    //     0xc10b00: add             x2, PP, #0x99, lsl #12  ; [pp+0x99e88] List<CustomPainterSemantics>(0)
    //     0xc10b04: ldr             x2, [x2, #0xe88]
    // 0xc10b08: r0 = _updateSemanticsChildren()
    //     0xc10b08: bl              #0xc10c44  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_updateSemanticsChildren
    // 0xc10b0c: ldur            x1, [fp, #-8]
    // 0xc10b10: StoreField: r1->field_73 = r0
    //     0xc10b10: stur            w0, [x1, #0x73]
    //     0xc10b14: ldurb           w16, [x1, #-1]
    //     0xc10b18: ldurb           w17, [x0, #-1]
    //     0xc10b1c: and             x16, x17, x16, lsr #2
    //     0xc10b20: tst             x16, HEAP, lsr #32
    //     0xc10b24: b.eq            #0xc10b2c
    //     0xc10b28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc10b2c: LoadField: r0 = r1->field_6f
    //     0xc10b2c: ldur            w0, [x1, #0x6f]
    // 0xc10b30: DecompressPointer r0
    //     0xc10b30: add             x0, x0, HEAP, lsl #32
    // 0xc10b34: cmp             w0, NULL
    // 0xc10b38: b.eq            #0xc10b58
    // 0xc10b3c: str             x0, [SP]
    // 0xc10b40: r0 = length()
    //     0xc10b40: bl              #0xbfbc30  ; [dart:_internal] _CastIterableBase::length
    // 0xc10b44: cbnz            w0, #0xc10b50
    // 0xc10b48: r1 = false
    //     0xc10b48: add             x1, NULL, #0x30  ; false
    // 0xc10b4c: b               #0xc10b54
    // 0xc10b50: r1 = true
    //     0xc10b50: add             x1, NULL, #0x20  ; true
    // 0xc10b54: b               #0xc10b5c
    // 0xc10b58: r1 = false
    //     0xc10b58: add             x1, NULL, #0x30  ; false
    // 0xc10b5c: ldur            x0, [fp, #-8]
    // 0xc10b60: stur            x1, [fp, #-0x28]
    // 0xc10b64: LoadField: r2 = r0->field_73
    //     0xc10b64: ldur            w2, [x0, #0x73]
    // 0xc10b68: DecompressPointer r2
    //     0xc10b68: add             x2, x2, HEAP, lsl #32
    // 0xc10b6c: cmp             w2, NULL
    // 0xc10b70: b.eq            #0xc10b94
    // 0xc10b74: str             x2, [SP]
    // 0xc10b78: r0 = length()
    //     0xc10b78: bl              #0xbfbc30  ; [dart:_internal] _CastIterableBase::length
    // 0xc10b7c: cbnz            w0, #0xc10b88
    // 0xc10b80: r1 = false
    //     0xc10b80: add             x1, NULL, #0x30  ; false
    // 0xc10b84: b               #0xc10b8c
    // 0xc10b88: r1 = true
    //     0xc10b88: add             x1, NULL, #0x20  ; true
    // 0xc10b8c: mov             x3, x1
    // 0xc10b90: b               #0xc10b98
    // 0xc10b94: r3 = false
    //     0xc10b94: add             x3, NULL, #0x30  ; false
    // 0xc10b98: ldur            x0, [fp, #-0x28]
    // 0xc10b9c: stur            x3, [fp, #-0x30]
    // 0xc10ba0: r1 = <SemanticsNode>
    //     0xc10ba0: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0xc10ba4: r2 = 0
    //     0xc10ba4: mov             x2, #0
    // 0xc10ba8: r0 = _GrowableList()
    //     0xc10ba8: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xc10bac: mov             x3, x0
    // 0xc10bb0: ldur            x0, [fp, #-0x28]
    // 0xc10bb4: stur            x3, [fp, #-0x38]
    // 0xc10bb8: tbnz            w0, #4, #0xc10bd8
    // 0xc10bbc: ldur            x0, [fp, #-8]
    // 0xc10bc0: LoadField: r2 = r0->field_6f
    //     0xc10bc0: ldur            w2, [x0, #0x6f]
    // 0xc10bc4: DecompressPointer r2
    //     0xc10bc4: add             x2, x2, HEAP, lsl #32
    // 0xc10bc8: cmp             w2, NULL
    // 0xc10bcc: b.eq            #0xc10c3c
    // 0xc10bd0: mov             x1, x3
    // 0xc10bd4: r0 = addAll()
    //     0xc10bd4: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xc10bd8: ldur            x0, [fp, #-0x30]
    // 0xc10bdc: ldur            x1, [fp, #-0x38]
    // 0xc10be0: ldur            x2, [fp, #-0x20]
    // 0xc10be4: r0 = addAll()
    //     0xc10be4: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xc10be8: ldur            x0, [fp, #-0x30]
    // 0xc10bec: tbnz            w0, #4, #0xc10c0c
    // 0xc10bf0: ldur            x0, [fp, #-8]
    // 0xc10bf4: LoadField: r2 = r0->field_73
    //     0xc10bf4: ldur            w2, [x0, #0x73]
    // 0xc10bf8: DecompressPointer r2
    //     0xc10bf8: add             x2, x2, HEAP, lsl #32
    // 0xc10bfc: cmp             w2, NULL
    // 0xc10c00: b.eq            #0xc10c40
    // 0xc10c04: ldur            x1, [fp, #-0x38]
    // 0xc10c08: r0 = addAll()
    //     0xc10c08: bl              #0xa115e4  ; [dart:core] _GrowableList::addAll
    // 0xc10c0c: ldur            x16, [fp, #-0x38]
    // 0xc10c10: str             x16, [SP]
    // 0xc10c14: ldur            x1, [fp, #-0x10]
    // 0xc10c18: ldur            x2, [fp, #-0x18]
    // 0xc10c1c: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xc10c1c: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xc10c20: r0 = updateWith()
    //     0xc10c20: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc10c24: r0 = Null
    //     0xc10c24: mov             x0, NULL
    // 0xc10c28: LeaveFrame
    //     0xc10c28: mov             SP, fp
    //     0xc10c2c: ldp             fp, lr, [SP], #0x10
    // 0xc10c30: ret
    //     0xc10c30: ret             
    // 0xc10c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc10c34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc10c38: b               #0xc10ac4
    // 0xc10c3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc10c3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc10c40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc10c40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _updateSemanticsChildren(/* No info */) {
    // ** addr: 0xc10c44, size: 0x184
    // 0xc10c44: EnterFrame
    //     0xc10c44: stp             fp, lr, [SP, #-0x10]!
    //     0xc10c48: mov             fp, SP
    // 0xc10c4c: AllocStack(0x30)
    //     0xc10c4c: sub             SP, SP, #0x30
    // 0xc10c50: CheckStackOverflow
    //     0xc10c50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc10c54: cmp             SP, x16
    //     0xc10c58: b.ls            #0xc10db0
    // 0xc10c5c: cmp             w1, NULL
    // 0xc10c60: b.ne            #0xc10c68
    // 0xc10c64: r1 = const []
    //     0xc10c64: ldr             x1, [PP, #0x28f0]  ; [pp+0x28f0] List<SemanticsNode>(0)
    // 0xc10c68: stur            x1, [fp, #-8]
    // 0xc10c6c: r0 = LoadClassIdInstr(r1)
    //     0xc10c6c: ldur            x0, [x1, #-1]
    //     0xc10c70: ubfx            x0, x0, #0xc, #0x14
    // 0xc10c74: str             x1, [SP]
    // 0xc10c78: r0 = GDT[cid_x0 + 0xf078]()
    //     0xc10c78: mov             x17, #0xf078
    //     0xc10c7c: add             lr, x0, x17
    //     0xc10c80: ldr             lr, [x21, lr, lsl #3]
    //     0xc10c84: blr             lr
    // 0xc10c88: r1 = LoadInt32Instr(r0)
    //     0xc10c88: sbfx            x1, x0, #1, #0x1f
    //     0xc10c8c: tbz             w0, #0, #0xc10c94
    //     0xc10c90: ldur            x1, [x0, #7]
    // 0xc10c94: sub             x0, x1, #1
    // 0xc10c98: stur            x0, [fp, #-0x10]
    // 0xc10c9c: CheckStackOverflow
    //     0xc10c9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc10ca0: cmp             SP, x16
    //     0xc10ca4: b.ls            #0xc10db8
    // 0xc10ca8: tbnz            x0, #0x3f, #0xc10d60
    // 0xc10cac: r16 = <Key, SemanticsNode>
    //     0xc10cac: add             x16, PP, #0x98, lsl #12  ; [pp+0x98850] TypeArguments: <Key, SemanticsNode>
    //     0xc10cb0: ldr             x16, [x16, #0x850]
    // 0xc10cb4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xc10cb8: stp             lr, x16, [SP]
    // 0xc10cbc: r0 = Map._fromLiteral()
    //     0xc10cbc: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xc10cc0: mov             x2, x0
    // 0xc10cc4: stur            x2, [fp, #-0x20]
    // 0xc10cc8: r5 = 0
    //     0xc10cc8: mov             x5, #0
    // 0xc10ccc: ldur            x4, [fp, #-8]
    // 0xc10cd0: ldur            x3, [fp, #-0x10]
    // 0xc10cd4: stur            x5, [fp, #-0x18]
    // 0xc10cd8: CheckStackOverflow
    //     0xc10cd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc10cdc: cmp             SP, x16
    //     0xc10ce0: b.ls            #0xc10dc0
    // 0xc10ce4: cmp             x5, x3
    // 0xc10ce8: b.gt            #0xc10d60
    // 0xc10cec: r0 = BoxInt64Instr(r5)
    //     0xc10cec: sbfiz           x0, x5, #1, #0x1f
    //     0xc10cf0: cmp             x5, x0, asr #1
    //     0xc10cf4: b.eq            #0xc10d00
    //     0xc10cf8: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc10cfc: stur            x5, [x0, #7]
    // 0xc10d00: r1 = LoadClassIdInstr(r4)
    //     0xc10d00: ldur            x1, [x4, #-1]
    //     0xc10d04: ubfx            x1, x1, #0xc, #0x14
    // 0xc10d08: stp             x0, x4, [SP]
    // 0xc10d0c: mov             x0, x1
    // 0xc10d10: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xc10d10: sub             lr, x0, #0xdfd
    //     0xc10d14: ldr             lr, [x21, lr, lsl #3]
    //     0xc10d18: blr             lr
    // 0xc10d1c: LoadField: r2 = r0->field_7
    //     0xc10d1c: ldur            w2, [x0, #7]
    // 0xc10d20: DecompressPointer r2
    //     0xc10d20: add             x2, x2, HEAP, lsl #32
    // 0xc10d24: cmp             w2, NULL
    // 0xc10d28: b.eq            #0xc10d50
    // 0xc10d2c: ldur            x4, [fp, #-0x20]
    // 0xc10d30: r1 = LoadClassIdInstr(r4)
    //     0xc10d30: ldur            x1, [x4, #-1]
    //     0xc10d34: ubfx            x1, x1, #0xc, #0x14
    // 0xc10d38: mov             x3, x0
    // 0xc10d3c: mov             x0, x1
    // 0xc10d40: mov             x1, x4
    // 0xc10d44: r0 = GDT[cid_x0 + -0xd50]()
    //     0xc10d44: sub             lr, x0, #0xd50
    //     0xc10d48: ldr             lr, [x21, lr, lsl #3]
    //     0xc10d4c: blr             lr
    // 0xc10d50: ldur            x0, [fp, #-0x18]
    // 0xc10d54: add             x5, x0, #1
    // 0xc10d58: ldur            x2, [fp, #-0x20]
    // 0xc10d5c: b               #0xc10ccc
    // 0xc10d60: ldur            x0, [fp, #-8]
    // 0xc10d64: r1 = LoadClassIdInstr(r0)
    //     0xc10d64: ldur            x1, [x0, #-1]
    //     0xc10d68: ubfx            x1, x1, #0xc, #0x14
    // 0xc10d6c: str             x0, [SP]
    // 0xc10d70: mov             x0, x1
    // 0xc10d74: r0 = GDT[cid_x0 + 0xf078]()
    //     0xc10d74: mov             x17, #0xf078
    //     0xc10d78: add             lr, x0, x17
    //     0xc10d7c: ldr             lr, [x21, lr, lsl #3]
    //     0xc10d80: blr             lr
    // 0xc10d84: r1 = <SemanticsNode?>
    //     0xc10d84: add             x1, PP, #0x99, lsl #12  ; [pp+0x99e90] TypeArguments: <SemanticsNode?>
    //     0xc10d88: ldr             x1, [x1, #0xe90]
    // 0xc10d8c: r2 = 0
    //     0xc10d8c: mov             x2, #0
    // 0xc10d90: r0 = AllocateArray()
    //     0xc10d90: bl              #0x13df928  ; AllocateArrayStub
    // 0xc10d94: r16 = <SemanticsNode>
    //     0xc10d94: ldr             x16, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0xc10d98: stp             x0, x16, [SP]
    // 0xc10d9c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc10d9c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc10da0: r0 = cast()
    //     0xc10da0: bl              #0xb73994  ; [dart:collection] ListBase::cast
    // 0xc10da4: LeaveFrame
    //     0xc10da4: mov             SP, fp
    //     0xc10da8: ldp             fp, lr, [SP], #0x10
    // 0xc10dac: ret
    //     0xc10dac: ret             
    // 0xc10db0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc10db0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc10db4: b               #0xc10c5c
    // 0xc10db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc10db8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc10dbc: b               #0xc10ca8
    // 0xc10dc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc10dc0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc10dc4: b               #0xc10ce4
  }
  _ paint(/* No info */) {
    // ** addr: 0xc18164, size: 0xdc
    // 0xc18164: EnterFrame
    //     0xc18164: stp             fp, lr, [SP, #-0x10]!
    //     0xc18168: mov             fp, SP
    // 0xc1816c: AllocStack(0x18)
    //     0xc1816c: sub             SP, SP, #0x18
    // 0xc18170: SetupParameters(RenderCustomPaint this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc18170: mov             x0, x2
    //     0xc18174: stur            x2, [fp, #-0x10]
    //     0xc18178: mov             x2, x1
    //     0xc1817c: stur            x1, [fp, #-8]
    //     0xc18180: stur            x3, [fp, #-0x18]
    // 0xc18184: CheckStackOverflow
    //     0xc18184: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18188: cmp             SP, x16
    //     0xc1818c: b.ls            #0xc18230
    // 0xc18190: LoadField: r1 = r2->field_53
    //     0xc18190: ldur            w1, [x2, #0x53]
    // 0xc18194: DecompressPointer r1
    //     0xc18194: add             x1, x1, HEAP, lsl #32
    // 0xc18198: cmp             w1, NULL
    // 0xc1819c: b.eq            #0xc181d0
    // 0xc181a0: mov             x1, x0
    // 0xc181a4: r0 = canvas()
    //     0xc181a4: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc181a8: mov             x1, x0
    // 0xc181ac: ldur            x0, [fp, #-8]
    // 0xc181b0: LoadField: r5 = r0->field_53
    //     0xc181b0: ldur            w5, [x0, #0x53]
    // 0xc181b4: DecompressPointer r5
    //     0xc181b4: add             x5, x5, HEAP, lsl #32
    // 0xc181b8: cmp             w5, NULL
    // 0xc181bc: b.eq            #0xc18238
    // 0xc181c0: mov             x2, x1
    // 0xc181c4: mov             x1, x0
    // 0xc181c8: ldur            x3, [fp, #-0x18]
    // 0xc181cc: r0 = _paintWithPainter()
    //     0xc181cc: bl              #0xc18240  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_paintWithPainter
    // 0xc181d0: ldur            x0, [fp, #-8]
    // 0xc181d4: mov             x1, x0
    // 0xc181d8: ldur            x2, [fp, #-0x10]
    // 0xc181dc: ldur            x3, [fp, #-0x18]
    // 0xc181e0: r0 = paint()
    //     0xc181e0: bl              #0xc1faf0  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::paint
    // 0xc181e4: ldur            x0, [fp, #-8]
    // 0xc181e8: LoadField: r1 = r0->field_57
    //     0xc181e8: ldur            w1, [x0, #0x57]
    // 0xc181ec: DecompressPointer r1
    //     0xc181ec: add             x1, x1, HEAP, lsl #32
    // 0xc181f0: cmp             w1, NULL
    // 0xc181f4: b.eq            #0xc18220
    // 0xc181f8: ldur            x1, [fp, #-0x10]
    // 0xc181fc: r0 = canvas()
    //     0xc181fc: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc18200: ldur            x1, [fp, #-8]
    // 0xc18204: LoadField: r5 = r1->field_57
    //     0xc18204: ldur            w5, [x1, #0x57]
    // 0xc18208: DecompressPointer r5
    //     0xc18208: add             x5, x5, HEAP, lsl #32
    // 0xc1820c: cmp             w5, NULL
    // 0xc18210: b.eq            #0xc1823c
    // 0xc18214: mov             x2, x0
    // 0xc18218: ldur            x3, [fp, #-0x18]
    // 0xc1821c: r0 = _paintWithPainter()
    //     0xc1821c: bl              #0xc18240  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_paintWithPainter
    // 0xc18220: r0 = Null
    //     0xc18220: mov             x0, NULL
    // 0xc18224: LeaveFrame
    //     0xc18224: mov             SP, fp
    //     0xc18228: ldp             fp, lr, [SP], #0x10
    // 0xc1822c: ret
    //     0xc1822c: ret             
    // 0xc18230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18230: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18234: b               #0xc18190
    // 0xc18238: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc18238: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc1823c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc1823c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintWithPainter(/* No info */) {
    // ** addr: 0xc18240, size: 0x1a8
    // 0xc18240: EnterFrame
    //     0xc18240: stp             fp, lr, [SP, #-0x10]!
    //     0xc18244: mov             fp, SP
    // 0xc18248: AllocStack(0x48)
    //     0xc18248: sub             SP, SP, #0x48
    // 0xc1824c: SetupParameters(RenderCustomPaint this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */, dynamic _ /* r5 => r0, fp-0x28 */)
    //     0xc1824c: mov             x4, x1
    //     0xc18250: mov             x0, x5
    //     0xc18254: stur            x1, [fp, #-0x10]
    //     0xc18258: stur            x2, [fp, #-0x18]
    //     0xc1825c: stur            x3, [fp, #-0x20]
    //     0xc18260: stur            x5, [fp, #-0x28]
    // 0xc18264: CheckStackOverflow
    //     0xc18264: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18268: cmp             SP, x16
    //     0xc1826c: b.ls            #0xc183d4
    // 0xc18270: LoadField: r1 = r2->field_7
    //     0xc18270: ldur            w1, [x2, #7]
    // 0xc18274: DecompressPointer r1
    //     0xc18274: add             x1, x1, HEAP, lsl #32
    // 0xc18278: cmp             w1, NULL
    // 0xc1827c: b.eq            #0xc183dc
    // 0xc18280: LoadField: r5 = r1->field_7
    //     0xc18280: ldur            x5, [x1, #7]
    // 0xc18284: ldr             x1, [x5]
    // 0xc18288: cbz             x1, #0xc183a4
    // 0xc1828c: mov             x5, x1
    // 0xc18290: stur            x5, [fp, #-8]
    // 0xc18294: r1 = <Never>
    //     0xc18294: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc18298: r0 = Pointer()
    //     0xc18298: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1829c: mov             x1, x0
    // 0xc182a0: ldur            x0, [fp, #-8]
    // 0xc182a4: StoreField: r1->field_7 = r0
    //     0xc182a4: stur            x0, [x1, #7]
    // 0xc182a8: r0 = _save$Method$FfiNative()
    //     0xc182a8: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xc182ac: ldur            x16, [fp, #-0x20]
    // 0xc182b0: r30 = Instance_Offset
    //     0xc182b0: ldr             lr, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc182b4: stp             lr, x16, [SP]
    // 0xc182b8: r0 = ==()
    //     0xc182b8: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xc182bc: tbz             w0, #4, #0xc18318
    // 0xc182c0: ldur            x2, [fp, #-0x18]
    // 0xc182c4: ldur            x0, [fp, #-0x20]
    // 0xc182c8: LoadField: d0 = r0->field_7
    //     0xc182c8: ldur            d0, [x0, #7]
    // 0xc182cc: stur            d0, [fp, #-0x38]
    // 0xc182d0: LoadField: d1 = r0->field_f
    //     0xc182d0: ldur            d1, [x0, #0xf]
    // 0xc182d4: stur            d1, [fp, #-0x30]
    // 0xc182d8: LoadField: r0 = r2->field_7
    //     0xc182d8: ldur            w0, [x2, #7]
    // 0xc182dc: DecompressPointer r0
    //     0xc182dc: add             x0, x0, HEAP, lsl #32
    // 0xc182e0: cmp             w0, NULL
    // 0xc182e4: b.eq            #0xc183e0
    // 0xc182e8: LoadField: r1 = r0->field_7
    //     0xc182e8: ldur            x1, [x0, #7]
    // 0xc182ec: ldr             x0, [x1]
    // 0xc182f0: cbz             x0, #0xc183b4
    // 0xc182f4: stur            x0, [fp, #-8]
    // 0xc182f8: r1 = <Never>
    //     0xc182f8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc182fc: r0 = Pointer()
    //     0xc182fc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc18300: mov             x1, x0
    // 0xc18304: ldur            x0, [fp, #-8]
    // 0xc18308: StoreField: r1->field_7 = r0
    //     0xc18308: stur            x0, [x1, #7]
    // 0xc1830c: ldur            d0, [fp, #-0x38]
    // 0xc18310: ldur            d1, [fp, #-0x30]
    // 0xc18314: r0 = _translate$Method$FfiNative()
    //     0xc18314: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0xc18318: ldur            x2, [fp, #-0x18]
    // 0xc1831c: ldur            x0, [fp, #-0x28]
    // 0xc18320: ldur            x1, [fp, #-0x10]
    // 0xc18324: r0 = size()
    //     0xc18324: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc18328: ldur            x1, [fp, #-0x28]
    // 0xc1832c: r2 = LoadClassIdInstr(r1)
    //     0xc1832c: ldur            x2, [x1, #-1]
    //     0xc18330: ubfx            x2, x2, #0xc, #0x14
    // 0xc18334: mov             x3, x0
    // 0xc18338: mov             x0, x2
    // 0xc1833c: ldur            x2, [fp, #-0x18]
    // 0xc18340: r0 = GDT[cid_x0 + 0x1205f]()
    //     0xc18340: mov             x17, #0x205f
    //     0xc18344: movk            x17, #1, lsl #16
    //     0xc18348: add             lr, x0, x17
    //     0xc1834c: ldr             lr, [x21, lr, lsl #3]
    //     0xc18350: blr             lr
    // 0xc18354: ldur            x0, [fp, #-0x18]
    // 0xc18358: LoadField: r1 = r0->field_7
    //     0xc18358: ldur            w1, [x0, #7]
    // 0xc1835c: DecompressPointer r1
    //     0xc1835c: add             x1, x1, HEAP, lsl #32
    // 0xc18360: cmp             w1, NULL
    // 0xc18364: b.eq            #0xc183e4
    // 0xc18368: LoadField: r2 = r1->field_7
    //     0xc18368: ldur            x2, [x1, #7]
    // 0xc1836c: ldr             x1, [x2]
    // 0xc18370: cbz             x1, #0xc183c4
    // 0xc18374: mov             x2, x1
    // 0xc18378: stur            x2, [fp, #-8]
    // 0xc1837c: r1 = <Never>
    //     0xc1837c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc18380: r0 = Pointer()
    //     0xc18380: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc18384: mov             x1, x0
    // 0xc18388: ldur            x0, [fp, #-8]
    // 0xc1838c: StoreField: r1->field_7 = r0
    //     0xc1838c: stur            x0, [x1, #7]
    // 0xc18390: r0 = _restore$Method$FfiNative()
    //     0xc18390: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xc18394: r0 = Null
    //     0xc18394: mov             x0, NULL
    // 0xc18398: LeaveFrame
    //     0xc18398: mov             SP, fp
    //     0xc1839c: ldp             fp, lr, [SP], #0x10
    // 0xc183a0: ret
    //     0xc183a0: ret             
    // 0xc183a4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc183a4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc183a8: str             x16, [SP]
    // 0xc183ac: r0 = _throwNew()
    //     0xc183ac: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc183b0: brk             #0
    // 0xc183b4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc183b4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc183b8: str             x16, [SP]
    // 0xc183bc: r0 = _throwNew()
    //     0xc183bc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc183c0: brk             #0
    // 0xc183c4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc183c4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc183c8: str             x16, [SP]
    // 0xc183cc: r0 = _throwNew()
    //     0xc183cc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc183d0: brk             #0
    // 0xc183d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc183d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc183d8: b               #0xc18270
    // 0xc183dc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc183dc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc183e0: r0 = NullErrorSharedWithFPURegs()
    //     0xc183e0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc183e4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc183e4: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ clearSemantics(/* No info */) {
    // ** addr: 0xcd045c, size: 0x4c
    // 0xcd045c: EnterFrame
    //     0xcd045c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0460: mov             fp, SP
    // 0xcd0464: AllocStack(0x8)
    //     0xcd0464: sub             SP, SP, #8
    // 0xcd0468: SetupParameters(RenderCustomPaint this /* r1 => r0, fp-0x8 */)
    //     0xcd0468: mov             x0, x1
    //     0xcd046c: stur            x1, [fp, #-8]
    // 0xcd0470: CheckStackOverflow
    //     0xcd0470: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd0474: cmp             SP, x16
    //     0xcd0478: b.ls            #0xcd04a0
    // 0xcd047c: mov             x1, x0
    // 0xcd0480: r0 = clearSemantics()
    //     0xcd0480: bl              #0xcd05e8  ; [package:flutter/src/rendering/object.dart] RenderObject::clearSemantics
    // 0xcd0484: ldur            x1, [fp, #-8]
    // 0xcd0488: StoreField: r1->field_6f = rNULL
    //     0xcd0488: stur            NULL, [x1, #0x6f]
    // 0xcd048c: StoreField: r1->field_73 = rNULL
    //     0xcd048c: stur            NULL, [x1, #0x73]
    // 0xcd0490: r0 = Null
    //     0xcd0490: mov             x0, NULL
    // 0xcd0494: LeaveFrame
    //     0xcd0494: mov             SP, fp
    //     0xcd0498: ldp             fp, lr, [SP], #0x10
    // 0xcd049c: ret
    //     0xcd049c: ret             
    // 0xcd04a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd04a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd04a4: b               #0xcd047c
  }
  set _ preferredSize=(/* No info */) {
    // ** addr: 0xcf5bd4, size: 0x88
    // 0xcf5bd4: EnterFrame
    //     0xcf5bd4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5bd8: mov             fp, SP
    // 0xcf5bdc: mov             x0, x2
    // 0xcf5be0: CheckStackOverflow
    //     0xcf5be0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5be4: cmp             SP, x16
    //     0xcf5be8: b.ls            #0xcf5c54
    // 0xcf5bec: LoadField: r2 = r1->field_5b
    //     0xcf5bec: ldur            w2, [x1, #0x5b]
    // 0xcf5bf0: DecompressPointer r2
    //     0xcf5bf0: add             x2, x2, HEAP, lsl #32
    // 0xcf5bf4: LoadField: d0 = r0->field_7
    //     0xcf5bf4: ldur            d0, [x0, #7]
    // 0xcf5bf8: LoadField: d1 = r2->field_7
    //     0xcf5bf8: ldur            d1, [x2, #7]
    // 0xcf5bfc: fcmp            d0, d1
    // 0xcf5c00: b.ne            #0xcf5c24
    // 0xcf5c04: LoadField: d0 = r0->field_f
    //     0xcf5c04: ldur            d0, [x0, #0xf]
    // 0xcf5c08: LoadField: d1 = r2->field_f
    //     0xcf5c08: ldur            d1, [x2, #0xf]
    // 0xcf5c0c: fcmp            d0, d1
    // 0xcf5c10: b.ne            #0xcf5c24
    // 0xcf5c14: r0 = Null
    //     0xcf5c14: mov             x0, NULL
    // 0xcf5c18: LeaveFrame
    //     0xcf5c18: mov             SP, fp
    //     0xcf5c1c: ldp             fp, lr, [SP], #0x10
    // 0xcf5c20: ret
    //     0xcf5c20: ret             
    // 0xcf5c24: StoreField: r1->field_5b = r0
    //     0xcf5c24: stur            w0, [x1, #0x5b]
    //     0xcf5c28: ldurb           w16, [x1, #-1]
    //     0xcf5c2c: ldurb           w17, [x0, #-1]
    //     0xcf5c30: and             x16, x17, x16, lsr #2
    //     0xcf5c34: tst             x16, HEAP, lsr #32
    //     0xcf5c38: b.eq            #0xcf5c40
    //     0xcf5c3c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf5c40: r0 = markNeedsLayout()
    //     0xcf5c40: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf5c44: r0 = Null
    //     0xcf5c44: mov             x0, NULL
    // 0xcf5c48: LeaveFrame
    //     0xcf5c48: mov             SP, fp
    //     0xcf5c4c: ldp             fp, lr, [SP], #0x10
    // 0xcf5c50: ret
    //     0xcf5c50: ret             
    // 0xcf5c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5c54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5c58: b               #0xcf5bec
  }
  set _ foregroundPainter=(/* No info */) {
    // ** addr: 0xcf5c5c, size: 0xb0
    // 0xcf5c5c: EnterFrame
    //     0xcf5c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5c60: mov             fp, SP
    // 0xcf5c64: AllocStack(0x20)
    //     0xcf5c64: sub             SP, SP, #0x20
    // 0xcf5c68: SetupParameters(RenderCustomPaint this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf5c68: stur            x1, [fp, #-8]
    //     0xcf5c6c: mov             x16, x2
    //     0xcf5c70: mov             x2, x1
    //     0xcf5c74: mov             x1, x16
    //     0xcf5c78: stur            x1, [fp, #-0x10]
    // 0xcf5c7c: CheckStackOverflow
    //     0xcf5c7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5c80: cmp             SP, x16
    //     0xcf5c84: b.ls            #0xcf5d04
    // 0xcf5c88: LoadField: r0 = r2->field_57
    //     0xcf5c88: ldur            w0, [x2, #0x57]
    // 0xcf5c8c: DecompressPointer r0
    //     0xcf5c8c: add             x0, x0, HEAP, lsl #32
    // 0xcf5c90: r3 = LoadClassIdInstr(r0)
    //     0xcf5c90: ldur            x3, [x0, #-1]
    //     0xcf5c94: ubfx            x3, x3, #0xc, #0x14
    // 0xcf5c98: stp             x1, x0, [SP]
    // 0xcf5c9c: mov             x0, x3
    // 0xcf5ca0: mov             lr, x0
    // 0xcf5ca4: ldr             lr, [x21, lr, lsl #3]
    // 0xcf5ca8: blr             lr
    // 0xcf5cac: tbnz            w0, #4, #0xcf5cc0
    // 0xcf5cb0: r0 = Null
    //     0xcf5cb0: mov             x0, NULL
    // 0xcf5cb4: LeaveFrame
    //     0xcf5cb4: mov             SP, fp
    //     0xcf5cb8: ldp             fp, lr, [SP], #0x10
    // 0xcf5cbc: ret
    //     0xcf5cbc: ret             
    // 0xcf5cc0: ldur            x1, [fp, #-8]
    // 0xcf5cc4: LoadField: r3 = r1->field_57
    //     0xcf5cc4: ldur            w3, [x1, #0x57]
    // 0xcf5cc8: DecompressPointer r3
    //     0xcf5cc8: add             x3, x3, HEAP, lsl #32
    // 0xcf5ccc: ldur            x0, [fp, #-0x10]
    // 0xcf5cd0: StoreField: r1->field_57 = r0
    //     0xcf5cd0: stur            w0, [x1, #0x57]
    //     0xcf5cd4: ldurb           w16, [x1, #-1]
    //     0xcf5cd8: ldurb           w17, [x0, #-1]
    //     0xcf5cdc: and             x16, x17, x16, lsr #2
    //     0xcf5ce0: tst             x16, HEAP, lsr #32
    //     0xcf5ce4: b.eq            #0xcf5cec
    //     0xcf5ce8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf5cec: ldur            x2, [fp, #-0x10]
    // 0xcf5cf0: r0 = _didUpdatePainter()
    //     0xcf5cf0: bl              #0xcf5d0c  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_didUpdatePainter
    // 0xcf5cf4: r0 = Null
    //     0xcf5cf4: mov             x0, NULL
    // 0xcf5cf8: LeaveFrame
    //     0xcf5cf8: mov             SP, fp
    //     0xcf5cfc: ldp             fp, lr, [SP], #0x10
    // 0xcf5d00: ret
    //     0xcf5d00: ret             
    // 0xcf5d04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5d04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5d08: b               #0xcf5c88
  }
  _ _didUpdatePainter(/* No info */) {
    // ** addr: 0xcf5d0c, size: 0x1b8
    // 0xcf5d0c: EnterFrame
    //     0xcf5d0c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5d10: mov             fp, SP
    // 0xcf5d14: AllocStack(0x28)
    //     0xcf5d14: sub             SP, SP, #0x28
    // 0xcf5d18: SetupParameters(RenderCustomPaint this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xcf5d18: mov             x0, x2
    //     0xcf5d1c: stur            x2, [fp, #-0x10]
    //     0xcf5d20: mov             x2, x3
    //     0xcf5d24: stur            x3, [fp, #-0x18]
    //     0xcf5d28: mov             x3, x1
    //     0xcf5d2c: stur            x1, [fp, #-8]
    // 0xcf5d30: CheckStackOverflow
    //     0xcf5d30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5d34: cmp             SP, x16
    //     0xcf5d38: b.ls            #0xcf5ebc
    // 0xcf5d3c: cmp             w0, NULL
    // 0xcf5d40: b.ne            #0xcf5d50
    // 0xcf5d44: mov             x1, x3
    // 0xcf5d48: r0 = markNeedsPaint()
    //     0xcf5d48: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf5d4c: b               #0xcf5d9c
    // 0xcf5d50: cmp             w2, NULL
    // 0xcf5d54: b.eq            #0xcf5d94
    // 0xcf5d58: ldur            x16, [fp, #-0x10]
    // 0xcf5d5c: stp             x2, x16, [SP]
    // 0xcf5d60: r0 = _haveSameRuntimeType()
    //     0xcf5d60: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0xcf5d64: tbnz            w0, #4, #0xcf5d94
    // 0xcf5d68: ldur            x3, [fp, #-0x10]
    // 0xcf5d6c: r0 = LoadClassIdInstr(r3)
    //     0xcf5d6c: ldur            x0, [x3, #-1]
    //     0xcf5d70: ubfx            x0, x0, #0xc, #0x14
    // 0xcf5d74: mov             x1, x3
    // 0xcf5d78: ldur            x2, [fp, #-0x18]
    // 0xcf5d7c: r0 = GDT[cid_x0 + 0x11eeb]()
    //     0xcf5d7c: mov             x17, #0x1eeb
    //     0xcf5d80: movk            x17, #1, lsl #16
    //     0xcf5d84: add             lr, x0, x17
    //     0xcf5d88: ldr             lr, [x21, lr, lsl #3]
    //     0xcf5d8c: blr             lr
    // 0xcf5d90: tbnz            w0, #4, #0xcf5d9c
    // 0xcf5d94: ldur            x1, [fp, #-8]
    // 0xcf5d98: r0 = markNeedsPaint()
    //     0xcf5d98: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf5d9c: ldur            x0, [fp, #-8]
    // 0xcf5da0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xcf5da0: ldur            w1, [x0, #0x17]
    // 0xcf5da4: DecompressPointer r1
    //     0xcf5da4: add             x1, x1, HEAP, lsl #32
    // 0xcf5da8: cmp             w1, NULL
    // 0xcf5dac: b.eq            #0xcf5e38
    // 0xcf5db0: ldur            x3, [fp, #-0x18]
    // 0xcf5db4: cmp             w3, NULL
    // 0xcf5db8: b.eq            #0xcf5df4
    // 0xcf5dbc: mov             x2, x0
    // 0xcf5dc0: r1 = Function 'markNeedsPaint':.
    //     0xcf5dc0: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xcf5dc4: ldr             x1, [x1, #0x1f0]
    // 0xcf5dc8: r0 = AllocateClosure()
    //     0xcf5dc8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf5dcc: ldur            x3, [fp, #-0x18]
    // 0xcf5dd0: r1 = LoadClassIdInstr(r3)
    //     0xcf5dd0: ldur            x1, [x3, #-1]
    //     0xcf5dd4: ubfx            x1, x1, #0xc, #0x14
    // 0xcf5dd8: mov             x2, x0
    // 0xcf5ddc: mov             x0, x1
    // 0xcf5de0: mov             x1, x3
    // 0xcf5de4: r0 = GDT[cid_x0 + 0xe2a3]()
    //     0xcf5de4: mov             x17, #0xe2a3
    //     0xcf5de8: add             lr, x0, x17
    //     0xcf5dec: ldr             lr, [x21, lr, lsl #3]
    //     0xcf5df0: blr             lr
    // 0xcf5df4: ldur            x0, [fp, #-0x10]
    // 0xcf5df8: cmp             w0, NULL
    // 0xcf5dfc: b.eq            #0xcf5e38
    // 0xcf5e00: ldur            x2, [fp, #-8]
    // 0xcf5e04: r1 = Function 'markNeedsPaint':.
    //     0xcf5e04: add             x1, PP, #0x90, lsl #12  ; [pp+0x901f0] AnonymousClosure: (0xbf0a50), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0xbf0858)
    //     0xcf5e08: ldr             x1, [x1, #0x1f0]
    // 0xcf5e0c: r0 = AllocateClosure()
    //     0xcf5e0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf5e10: ldur            x3, [fp, #-0x10]
    // 0xcf5e14: r1 = LoadClassIdInstr(r3)
    //     0xcf5e14: ldur            x1, [x3, #-1]
    //     0xcf5e18: ubfx            x1, x1, #0xc, #0x14
    // 0xcf5e1c: mov             x2, x0
    // 0xcf5e20: mov             x0, x1
    // 0xcf5e24: mov             x1, x3
    // 0xcf5e28: r0 = GDT[cid_x0 + 0xe0ec]()
    //     0xcf5e28: mov             x17, #0xe0ec
    //     0xcf5e2c: add             lr, x0, x17
    //     0xcf5e30: ldr             lr, [x21, lr, lsl #3]
    //     0xcf5e34: blr             lr
    // 0xcf5e38: ldur            x1, [fp, #-0x10]
    // 0xcf5e3c: cmp             w1, NULL
    // 0xcf5e40: b.ne            #0xcf5e64
    // 0xcf5e44: ldur            x0, [fp, #-8]
    // 0xcf5e48: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xcf5e48: ldur            w1, [x0, #0x17]
    // 0xcf5e4c: DecompressPointer r1
    //     0xcf5e4c: add             x1, x1, HEAP, lsl #32
    // 0xcf5e50: cmp             w1, NULL
    // 0xcf5e54: b.eq            #0xcf5eac
    // 0xcf5e58: mov             x1, x0
    // 0xcf5e5c: r0 = markNeedsSemanticsUpdate()
    //     0xcf5e5c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf5e60: b               #0xcf5eac
    // 0xcf5e64: ldur            x0, [fp, #-8]
    // 0xcf5e68: ldur            x2, [fp, #-0x18]
    // 0xcf5e6c: cmp             w2, NULL
    // 0xcf5e70: b.eq            #0xcf5ea4
    // 0xcf5e74: stp             x2, x1, [SP]
    // 0xcf5e78: r0 = _haveSameRuntimeType()
    //     0xcf5e78: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0xcf5e7c: tbnz            w0, #4, #0xcf5ea4
    // 0xcf5e80: ldur            x1, [fp, #-0x10]
    // 0xcf5e84: r0 = LoadClassIdInstr(r1)
    //     0xcf5e84: ldur            x0, [x1, #-1]
    //     0xcf5e88: ubfx            x0, x0, #0xc, #0x14
    // 0xcf5e8c: ldur            x2, [fp, #-0x18]
    // 0xcf5e90: r0 = GDT[cid_x0 + 0xe257]()
    //     0xcf5e90: mov             x17, #0xe257
    //     0xcf5e94: add             lr, x0, x17
    //     0xcf5e98: ldr             lr, [x21, lr, lsl #3]
    //     0xcf5e9c: blr             lr
    // 0xcf5ea0: tbnz            w0, #4, #0xcf5eac
    // 0xcf5ea4: ldur            x1, [fp, #-8]
    // 0xcf5ea8: r0 = markNeedsSemanticsUpdate()
    //     0xcf5ea8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf5eac: r0 = Null
    //     0xcf5eac: mov             x0, NULL
    // 0xcf5eb0: LeaveFrame
    //     0xcf5eb0: mov             SP, fp
    //     0xcf5eb4: ldp             fp, lr, [SP], #0x10
    // 0xcf5eb8: ret
    //     0xcf5eb8: ret             
    // 0xcf5ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5ebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5ec0: b               #0xcf5d3c
  }
  set _ painter=(/* No info */) {
    // ** addr: 0xcf5ec4, size: 0xb0
    // 0xcf5ec4: EnterFrame
    //     0xcf5ec4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5ec8: mov             fp, SP
    // 0xcf5ecc: AllocStack(0x20)
    //     0xcf5ecc: sub             SP, SP, #0x20
    // 0xcf5ed0: SetupParameters(RenderCustomPaint this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf5ed0: stur            x1, [fp, #-8]
    //     0xcf5ed4: mov             x16, x2
    //     0xcf5ed8: mov             x2, x1
    //     0xcf5edc: mov             x1, x16
    //     0xcf5ee0: stur            x1, [fp, #-0x10]
    // 0xcf5ee4: CheckStackOverflow
    //     0xcf5ee4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5ee8: cmp             SP, x16
    //     0xcf5eec: b.ls            #0xcf5f6c
    // 0xcf5ef0: LoadField: r0 = r2->field_53
    //     0xcf5ef0: ldur            w0, [x2, #0x53]
    // 0xcf5ef4: DecompressPointer r0
    //     0xcf5ef4: add             x0, x0, HEAP, lsl #32
    // 0xcf5ef8: r3 = LoadClassIdInstr(r0)
    //     0xcf5ef8: ldur            x3, [x0, #-1]
    //     0xcf5efc: ubfx            x3, x3, #0xc, #0x14
    // 0xcf5f00: stp             x1, x0, [SP]
    // 0xcf5f04: mov             x0, x3
    // 0xcf5f08: mov             lr, x0
    // 0xcf5f0c: ldr             lr, [x21, lr, lsl #3]
    // 0xcf5f10: blr             lr
    // 0xcf5f14: tbnz            w0, #4, #0xcf5f28
    // 0xcf5f18: r0 = Null
    //     0xcf5f18: mov             x0, NULL
    // 0xcf5f1c: LeaveFrame
    //     0xcf5f1c: mov             SP, fp
    //     0xcf5f20: ldp             fp, lr, [SP], #0x10
    // 0xcf5f24: ret
    //     0xcf5f24: ret             
    // 0xcf5f28: ldur            x1, [fp, #-8]
    // 0xcf5f2c: LoadField: r3 = r1->field_53
    //     0xcf5f2c: ldur            w3, [x1, #0x53]
    // 0xcf5f30: DecompressPointer r3
    //     0xcf5f30: add             x3, x3, HEAP, lsl #32
    // 0xcf5f34: ldur            x0, [fp, #-0x10]
    // 0xcf5f38: StoreField: r1->field_53 = r0
    //     0xcf5f38: stur            w0, [x1, #0x53]
    //     0xcf5f3c: ldurb           w16, [x1, #-1]
    //     0xcf5f40: ldurb           w17, [x0, #-1]
    //     0xcf5f44: and             x16, x17, x16, lsr #2
    //     0xcf5f48: tst             x16, HEAP, lsr #32
    //     0xcf5f4c: b.eq            #0xcf5f54
    //     0xcf5f50: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf5f54: ldur            x2, [fp, #-0x10]
    // 0xcf5f58: r0 = _didUpdatePainter()
    //     0xcf5f58: bl              #0xcf5d0c  ; [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::_didUpdatePainter
    // 0xcf5f5c: r0 = Null
    //     0xcf5f5c: mov             x0, NULL
    // 0xcf5f60: LeaveFrame
    //     0xcf5f60: mov             SP, fp
    //     0xcf5f64: ldp             fp, lr, [SP], #0x10
    // 0xcf5f68: ret
    //     0xcf5f68: ret             
    // 0xcf5f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5f6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5f70: b               #0xcf5ef0
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e8b7c, size: 0x98
    // 0x10e8b7c: EnterFrame
    //     0x10e8b7c: stp             fp, lr, [SP, #-0x10]!
    //     0x10e8b80: mov             fp, SP
    // 0x10e8b84: AllocStack(0x18)
    //     0x10e8b84: sub             SP, SP, #0x18
    // 0x10e8b88: SetupParameters(RenderCustomPaint this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x10e8b88: mov             x5, x1
    //     0x10e8b8c: mov             x4, x2
    //     0x10e8b90: stur            x1, [fp, #-8]
    //     0x10e8b94: stur            x2, [fp, #-0x10]
    //     0x10e8b98: stur            x3, [fp, #-0x18]
    // 0x10e8b9c: CheckStackOverflow
    //     0x10e8b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e8ba0: cmp             SP, x16
    //     0x10e8ba4: b.ls            #0x10e8c0c
    // 0x10e8ba8: LoadField: r1 = r5->field_57
    //     0x10e8ba8: ldur            w1, [x5, #0x57]
    // 0x10e8bac: DecompressPointer r1
    //     0x10e8bac: add             x1, x1, HEAP, lsl #32
    // 0x10e8bb0: cmp             w1, NULL
    // 0x10e8bb4: b.eq            #0x10e8bf0
    // 0x10e8bb8: r0 = LoadClassIdInstr(r1)
    //     0x10e8bb8: ldur            x0, [x1, #-1]
    //     0x10e8bbc: ubfx            x0, x0, #0xc, #0x14
    // 0x10e8bc0: mov             x2, x3
    // 0x10e8bc4: r0 = GDT[cid_x0 + 0xfc88]()
    //     0x10e8bc4: mov             x17, #0xfc88
    //     0x10e8bc8: add             lr, x0, x17
    //     0x10e8bcc: ldr             lr, [x21, lr, lsl #3]
    //     0x10e8bd0: blr             lr
    // 0x10e8bd4: cmp             w0, NULL
    // 0x10e8bd8: b.eq            #0x10e8bf0
    // 0x10e8bdc: tbnz            w0, #4, #0x10e8bf0
    // 0x10e8be0: r0 = true
    //     0x10e8be0: add             x0, NULL, #0x20  ; true
    // 0x10e8be4: LeaveFrame
    //     0x10e8be4: mov             SP, fp
    //     0x10e8be8: ldp             fp, lr, [SP], #0x10
    // 0x10e8bec: ret
    //     0x10e8bec: ret             
    // 0x10e8bf0: ldur            x1, [fp, #-8]
    // 0x10e8bf4: ldur            x2, [fp, #-0x10]
    // 0x10e8bf8: ldur            x3, [fp, #-0x18]
    // 0x10e8bfc: r0 = hitTestChildren()
    //     0x10e8bfc: bl              #0x10e9bac  ; [package:syncfusion_flutter_charts/src/charts/common/element_widget.dart] CustomRenderLayoutBuilder::hitTestChildren
    // 0x10e8c00: LeaveFrame
    //     0x10e8c00: mov             SP, fp
    //     0x10e8c04: ldp             fp, lr, [SP], #0x10
    // 0x10e8c08: ret
    //     0x10e8c08: ret             
    // 0x10e8c0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e8c0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e8c10: b               #0x10e8ba8
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efa48, size: 0x24
    // 0x10efa48: EnterFrame
    //     0x10efa48: stp             fp, lr, [SP, #-0x10]!
    //     0x10efa4c: mov             fp, SP
    // 0x10efa50: ldr             x2, [fp, #0x10]
    // 0x10efa54: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efa54: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa3f38] AnonymousClosure: (0xb22b90), in [package:flutter/src/rendering/custom_paint.dart] RenderCustomPaint::computeMinIntrinsicHeight (0xb22b1c)
    //     0x10efa58: ldr             x1, [x1, #0xf38]
    // 0x10efa5c: r0 = AllocateClosure()
    //     0x10efa5c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efa60: LeaveFrame
    //     0x10efa60: mov             SP, fp
    //     0x10efa64: ldp             fp, lr, [SP], #0x10
    // 0x10efa68: ret
    //     0x10efa68: ret             
  }
  _ computeSizeForNoChild(/* No info */) {
    // ** addr: 0x11bcb98, size: 0x3c
    // 0x11bcb98: EnterFrame
    //     0x11bcb98: stp             fp, lr, [SP, #-0x10]!
    //     0x11bcb9c: mov             fp, SP
    // 0x11bcba0: mov             x0, x1
    // 0x11bcba4: mov             x1, x2
    // 0x11bcba8: CheckStackOverflow
    //     0x11bcba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11bcbac: cmp             SP, x16
    //     0x11bcbb0: b.ls            #0x11bcbcc
    // 0x11bcbb4: LoadField: r2 = r0->field_5b
    //     0x11bcbb4: ldur            w2, [x0, #0x5b]
    // 0x11bcbb8: DecompressPointer r2
    //     0x11bcbb8: add             x2, x2, HEAP, lsl #32
    // 0x11bcbbc: r0 = constrain()
    //     0x11bcbbc: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x11bcbc0: LeaveFrame
    //     0x11bcbc0: mov             SP, fp
    //     0x11bcbc4: ldp             fp, lr, [SP], #0x10
    // 0x11bcbc8: ret
    //     0x11bcbc8: ret             
    // 0x11bcbcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11bcbcc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11bcbd0: b               #0x11bcbb4
  }
  _ RenderCustomPaint(/* No info */) {
    // ** addr: 0x11d05e0, size: 0xec
    // 0x11d05e0: EnterFrame
    //     0x11d05e0: stp             fp, lr, [SP, #-0x10]!
    //     0x11d05e4: mov             fp, SP
    // 0x11d05e8: AllocStack(0x8)
    //     0x11d05e8: sub             SP, SP, #8
    // 0x11d05ec: r0 = false
    //     0x11d05ec: add             x0, NULL, #0x30  ; false
    // 0x11d05f0: mov             x4, x1
    // 0x11d05f4: mov             x16, x3
    // 0x11d05f8: mov             x3, x2
    // 0x11d05fc: mov             x2, x16
    // 0x11d0600: stur            x1, [fp, #-8]
    // 0x11d0604: mov             x1, x5
    // 0x11d0608: CheckStackOverflow
    //     0x11d0608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d060c: cmp             SP, x16
    //     0x11d0610: b.ls            #0x11d06c4
    // 0x11d0614: StoreField: r4->field_5f = r0
    //     0x11d0614: stur            w0, [x4, #0x5f]
    // 0x11d0618: StoreField: r4->field_63 = r0
    //     0x11d0618: stur            w0, [x4, #0x63]
    // 0x11d061c: mov             x0, x2
    // 0x11d0620: StoreField: r4->field_53 = r0
    //     0x11d0620: stur            w0, [x4, #0x53]
    //     0x11d0624: ldurb           w16, [x4, #-1]
    //     0x11d0628: ldurb           w17, [x0, #-1]
    //     0x11d062c: and             x16, x17, x16, lsr #2
    //     0x11d0630: tst             x16, HEAP, lsr #32
    //     0x11d0634: b.eq            #0x11d063c
    //     0x11d0638: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11d063c: mov             x0, x3
    // 0x11d0640: StoreField: r4->field_57 = r0
    //     0x11d0640: stur            w0, [x4, #0x57]
    //     0x11d0644: ldurb           w16, [x4, #-1]
    //     0x11d0648: ldurb           w17, [x0, #-1]
    //     0x11d064c: and             x16, x17, x16, lsr #2
    //     0x11d0650: tst             x16, HEAP, lsr #32
    //     0x11d0654: b.eq            #0x11d065c
    //     0x11d0658: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11d065c: mov             x0, x1
    // 0x11d0660: StoreField: r4->field_5b = r0
    //     0x11d0660: stur            w0, [x4, #0x5b]
    //     0x11d0664: ldurb           w16, [x4, #-1]
    //     0x11d0668: ldurb           w17, [x0, #-1]
    //     0x11d066c: and             x16, x17, x16, lsr #2
    //     0x11d0670: tst             x16, HEAP, lsr #32
    //     0x11d0674: b.eq            #0x11d067c
    //     0x11d0678: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11d067c: r0 = _LayoutCacheStorage()
    //     0x11d067c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d0680: ldur            x2, [fp, #-8]
    // 0x11d0684: StoreField: r2->field_47 = r0
    //     0x11d0684: stur            w0, [x2, #0x47]
    //     0x11d0688: ldurb           w16, [x2, #-1]
    //     0x11d068c: ldurb           w17, [x0, #-1]
    //     0x11d0690: and             x16, x17, x16, lsr #2
    //     0x11d0694: tst             x16, HEAP, lsr #32
    //     0x11d0698: b.eq            #0x11d06a0
    //     0x11d069c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d06a0: mov             x1, x2
    // 0x11d06a4: r0 = RenderObject()
    //     0x11d06a4: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d06a8: ldur            x1, [fp, #-8]
    // 0x11d06ac: r2 = Null
    //     0x11d06ac: mov             x2, NULL
    // 0x11d06b0: r0 = child=()
    //     0x11d06b0: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d06b4: r0 = Null
    //     0x11d06b4: mov             x0, NULL
    // 0x11d06b8: LeaveFrame
    //     0x11d06b8: mov             SP, fp
    //     0x11d06bc: ldp             fp, lr, [SP], #0x10
    // 0x11d06c0: ret
    //     0x11d06c0: ret             
    // 0x11d06c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d06c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d06c8: b               #0x11d0614
  }
}
