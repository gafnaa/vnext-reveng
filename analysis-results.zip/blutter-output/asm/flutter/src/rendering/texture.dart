// lib: , url: package:flutter/src/rendering/texture.dart

// class id: 1049052, size: 0x8
class :: {
}

// class id: 4722, size: 0x60, field offset: 0x50
class TextureBox extends RenderBox {

  _ paint(/* No info */) {
    // ** addr: 0xc2f318, size: 0x100
    // 0xc2f318: EnterFrame
    //     0xc2f318: stp             fp, lr, [SP, #-0x10]!
    //     0xc2f31c: mov             fp, SP
    // 0xc2f320: AllocStack(0x40)
    //     0xc2f320: sub             SP, SP, #0x40
    // 0xc2f324: SetupParameters(TextureBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc2f324: mov             x0, x2
    //     0xc2f328: stur            x2, [fp, #-0x10]
    //     0xc2f32c: mov             x2, x1
    //     0xc2f330: stur            x1, [fp, #-8]
    // 0xc2f334: CheckStackOverflow
    //     0xc2f334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2f338: cmp             SP, x16
    //     0xc2f33c: b.ls            #0xc2f410
    // 0xc2f340: LoadField: d0 = r3->field_7
    //     0xc2f340: ldur            d0, [x3, #7]
    // 0xc2f344: stur            d0, [fp, #-0x30]
    // 0xc2f348: LoadField: d1 = r3->field_f
    //     0xc2f348: ldur            d1, [x3, #0xf]
    // 0xc2f34c: mov             x1, x2
    // 0xc2f350: stur            d1, [fp, #-0x28]
    // 0xc2f354: r0 = size()
    //     0xc2f354: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2f358: LoadField: d0 = r0->field_7
    //     0xc2f358: ldur            d0, [x0, #7]
    // 0xc2f35c: ldur            x1, [fp, #-8]
    // 0xc2f360: stur            d0, [fp, #-0x38]
    // 0xc2f364: r0 = size()
    //     0xc2f364: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2f368: LoadField: d0 = r0->field_f
    //     0xc2f368: ldur            d0, [x0, #0xf]
    // 0xc2f36c: ldur            d2, [fp, #-0x30]
    // 0xc2f370: ldur            d1, [fp, #-0x38]
    // 0xc2f374: fadd            d3, d2, d1
    // 0xc2f378: ldur            d1, [fp, #-0x28]
    // 0xc2f37c: stur            d3, [fp, #-0x40]
    // 0xc2f380: fadd            d4, d1, d0
    // 0xc2f384: stur            d4, [fp, #-0x38]
    // 0xc2f388: r0 = Rect()
    //     0xc2f388: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc2f38c: ldur            d0, [fp, #-0x30]
    // 0xc2f390: stur            x0, [fp, #-0x20]
    // 0xc2f394: StoreField: r0->field_7 = d0
    //     0xc2f394: stur            d0, [x0, #7]
    // 0xc2f398: ldur            d0, [fp, #-0x28]
    // 0xc2f39c: StoreField: r0->field_f = d0
    //     0xc2f39c: stur            d0, [x0, #0xf]
    // 0xc2f3a0: ldur            d0, [fp, #-0x40]
    // 0xc2f3a4: ArrayStore: r0[0] = d0  ; List_8
    //     0xc2f3a4: stur            d0, [x0, #0x17]
    // 0xc2f3a8: ldur            d0, [fp, #-0x38]
    // 0xc2f3ac: StoreField: r0->field_1f = d0
    //     0xc2f3ac: stur            d0, [x0, #0x1f]
    // 0xc2f3b0: ldur            x1, [fp, #-8]
    // 0xc2f3b4: LoadField: r2 = r1->field_4f
    //     0xc2f3b4: ldur            x2, [x1, #0x4f]
    // 0xc2f3b8: stur            x2, [fp, #-0x18]
    // 0xc2f3bc: r0 = TextureLayer()
    //     0xc2f3bc: bl              #0xc28dd0  ; AllocateTextureLayerStub -> TextureLayer (size=0x54)
    // 0xc2f3c0: mov             x2, x0
    // 0xc2f3c4: ldur            x0, [fp, #-0x20]
    // 0xc2f3c8: stur            x2, [fp, #-8]
    // 0xc2f3cc: StoreField: r2->field_3f = r0
    //     0xc2f3cc: stur            w0, [x2, #0x3f]
    // 0xc2f3d0: ldur            x0, [fp, #-0x18]
    // 0xc2f3d4: StoreField: r2->field_43 = r0
    //     0xc2f3d4: stur            x0, [x2, #0x43]
    // 0xc2f3d8: r0 = false
    //     0xc2f3d8: add             x0, NULL, #0x30  ; false
    // 0xc2f3dc: StoreField: r2->field_4b = r0
    //     0xc2f3dc: stur            w0, [x2, #0x4b]
    // 0xc2f3e0: r0 = Instance_FilterQuality
    //     0xc2f3e0: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e990] Obj!FilterQuality@12c8281
    //     0xc2f3e4: ldr             x0, [x0, #0x990]
    // 0xc2f3e8: StoreField: r2->field_4f = r0
    //     0xc2f3e8: stur            w0, [x2, #0x4f]
    // 0xc2f3ec: mov             x1, x2
    // 0xc2f3f0: r0 = Layer()
    //     0xc2f3f0: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc2f3f4: ldur            x1, [fp, #-0x10]
    // 0xc2f3f8: ldur            x2, [fp, #-8]
    // 0xc2f3fc: r0 = addLayer()
    //     0xc2f3fc: bl              #0xc28ddc  ; [package:flutter/src/rendering/object.dart] PaintingContext::addLayer
    // 0xc2f400: r0 = Null
    //     0xc2f400: mov             x0, NULL
    // 0xc2f404: LeaveFrame
    //     0xc2f404: mov             SP, fp
    //     0xc2f408: ldp             fp, lr, [SP], #0x10
    // 0xc2f40c: ret
    //     0xc2f40c: ret             
    // 0xc2f410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2f410: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2f414: b               #0xc2f340
  }
  set _ textureId=(/* No info */) {
    // ** addr: 0xce43a4, size: 0x40
    // 0xce43a4: EnterFrame
    //     0xce43a4: stp             fp, lr, [SP, #-0x10]!
    //     0xce43a8: mov             fp, SP
    // 0xce43ac: CheckStackOverflow
    //     0xce43ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce43b0: cmp             SP, x16
    //     0xce43b4: b.ls            #0xce43dc
    // 0xce43b8: LoadField: r0 = r1->field_4f
    //     0xce43b8: ldur            x0, [x1, #0x4f]
    // 0xce43bc: cmp             x2, x0
    // 0xce43c0: b.eq            #0xce43cc
    // 0xce43c4: StoreField: r1->field_4f = r2
    //     0xce43c4: stur            x2, [x1, #0x4f]
    // 0xce43c8: r0 = markNeedsPaint()
    //     0xce43c8: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xce43cc: r0 = Null
    //     0xce43cc: mov             x0, NULL
    // 0xce43d0: LeaveFrame
    //     0xce43d0: mov             SP, fp
    //     0xce43d4: ldp             fp, lr, [SP], #0x10
    // 0xce43d8: ret
    //     0xce43d8: ret             
    // 0xce43dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce43dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce43e0: b               #0xce43b8
  }
}
