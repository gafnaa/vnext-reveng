// lib: , url: package:flutter/src/rendering/sliver.dart

// class id: 1049042, size: 0x8
class :: {

  static _ applyGrowthDirectionToAxisDirection(/* No info */) {
    // ** addr: 0xb7b568, size: 0x54
    // 0xb7b568: LoadField: r3 = r2->field_7
    //     0xb7b568: ldur            x3, [x2, #7]
    // 0xb7b56c: cmp             x3, #0
    // 0xb7b570: b.gt            #0xb7b57c
    // 0xb7b574: mov             x0, x1
    // 0xb7b578: b               #0xb7b5b8
    // 0xb7b57c: LoadField: r2 = r1->field_7
    //     0xb7b57c: ldur            x2, [x1, #7]
    // 0xb7b580: cmp             x2, #1
    // 0xb7b584: b.gt            #0xb7b5a0
    // 0xb7b588: cmp             x2, #0
    // 0xb7b58c: b.gt            #0xb7b598
    // 0xb7b590: r1 = Instance_AxisDirection
    //     0xb7b590: ldr             x1, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xb7b594: b               #0xb7b5b4
    // 0xb7b598: r1 = Instance_AxisDirection
    //     0xb7b598: ldr             x1, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xb7b59c: b               #0xb7b5b4
    // 0xb7b5a0: cmp             x2, #2
    // 0xb7b5a4: b.gt            #0xb7b5b0
    // 0xb7b5a8: r1 = Instance_AxisDirection
    //     0xb7b5a8: ldr             x1, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xb7b5ac: b               #0xb7b5b4
    // 0xb7b5b0: r1 = Instance_AxisDirection
    //     0xb7b5b0: ldr             x1, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xb7b5b4: mov             x0, x1
    // 0xb7b5b8: ret
    //     0xb7b5b8: ret             
  }
  static _ applyGrowthDirectionToScrollDirection(/* No info */) {
    // ** addr: 0xbc7f68, size: 0x4c
    // 0xbc7f68: LoadField: r3 = r2->field_7
    //     0xbc7f68: ldur            x3, [x2, #7]
    // 0xbc7f6c: cmp             x3, #0
    // 0xbc7f70: b.gt            #0xbc7f7c
    // 0xbc7f74: mov             x0, x1
    // 0xbc7f78: b               #0xbc7fb0
    // 0xbc7f7c: LoadField: r2 = r1->field_7
    //     0xbc7f7c: ldur            x2, [x1, #7]
    // 0xbc7f80: cmp             x2, #1
    // 0xbc7f84: b.gt            #0xbc7fa4
    // 0xbc7f88: cmp             x2, #0
    // 0xbc7f8c: b.gt            #0xbc7f98
    // 0xbc7f90: r1 = Instance_ScrollDirection
    //     0xbc7f90: ldr             x1, [PP, #0x5578]  ; [pp+0x5578] Obj!ScrollDirection@12c4121
    // 0xbc7f94: b               #0xbc7fac
    // 0xbc7f98: r1 = Instance_ScrollDirection
    //     0xbc7f98: add             x1, PP, #0x96, lsl #12  ; [pp+0x96278] Obj!ScrollDirection@12c4101
    //     0xbc7f9c: ldr             x1, [x1, #0x278]
    // 0xbc7fa0: b               #0xbc7fac
    // 0xbc7fa4: r1 = Instance_ScrollDirection
    //     0xbc7fa4: add             x1, PP, #0x96, lsl #12  ; [pp+0x96280] Obj!ScrollDirection@12c40e1
    //     0xbc7fa8: ldr             x1, [x1, #0x280]
    // 0xbc7fac: mov             x0, x1
    // 0xbc7fb0: ret
    //     0xbc7fb0: ret             
  }
}

// class id: 2885, size: 0x58, field offset: 0x8
//   const constructor, 
class SliverConstraints extends Constraints {

  _ asBoxConstraints(/* No info */) {
    // ** addr: 0xbe58b0, size: 0x1b0
    // 0xbe58b0: EnterFrame
    //     0xbe58b0: stp             fp, lr, [SP, #-0x10]!
    //     0xbe58b4: mov             fp, SP
    // 0xbe58b8: AllocStack(0x18)
    //     0xbe58b8: sub             SP, SP, #0x18
    // 0xbe58bc: SetupParameters({dynamic crossAxisExtent = Null /* r3 */, _Double maxExtent = inf /* d0, fp-0x18 */, _Double minExtent = 0.000000 /* d1, fp-0x10 */})
    //     0xbe58bc: ldur            w0, [x4, #0x13]
    //     0xbe58c0: ldur            w2, [x4, #0x1f]
    //     0xbe58c4: add             x2, x2, HEAP, lsl #32
    //     0xbe58c8: add             x16, PP, #0x96, lsl #12  ; [pp+0x968b8] "crossAxisExtent"
    //     0xbe58cc: ldr             x16, [x16, #0x8b8]
    //     0xbe58d0: cmp             w2, w16
    //     0xbe58d4: b.ne            #0xbe58f8
    //     0xbe58d8: ldur            w2, [x4, #0x23]
    //     0xbe58dc: add             x2, x2, HEAP, lsl #32
    //     0xbe58e0: sub             w3, w0, w2
    //     0xbe58e4: add             x2, fp, w3, sxtw #2
    //     0xbe58e8: ldr             x2, [x2, #8]
    //     0xbe58ec: mov             x3, x2
    //     0xbe58f0: mov             x2, #1
    //     0xbe58f4: b               #0xbe5900
    //     0xbe58f8: mov             x3, NULL
    //     0xbe58fc: mov             x2, #0
    //     0xbe5900: lsl             x5, x2, #1
    //     0xbe5904: lsl             w6, w5, #1
    //     0xbe5908: add             w7, w6, #8
    //     0xbe590c: add             x16, x4, w7, sxtw #1
    //     0xbe5910: ldur            w8, [x16, #0xf]
    //     0xbe5914: add             x8, x8, HEAP, lsl #32
    //     0xbe5918: add             x16, PP, #0x96, lsl #12  ; [pp+0x968c0] "maxExtent"
    //     0xbe591c: ldr             x16, [x16, #0x8c0]
    //     0xbe5920: cmp             w8, w16
    //     0xbe5924: b.ne            #0xbe5958
    //     0xbe5928: add             w2, w6, #0xa
    //     0xbe592c: add             x16, x4, w2, sxtw #1
    //     0xbe5930: ldur            w6, [x16, #0xf]
    //     0xbe5934: add             x6, x6, HEAP, lsl #32
    //     0xbe5938: sub             w2, w0, w6
    //     0xbe593c: add             x6, fp, w2, sxtw #2
    //     0xbe5940: ldr             x6, [x6, #8]
    //     0xbe5944: add             w2, w5, #2
    //     0xbe5948: ldur            d0, [x6, #7]
    //     0xbe594c: sbfx            x5, x2, #1, #0x1f
    //     0xbe5950: mov             x2, x5
    //     0xbe5954: b               #0xbe595c
    //     0xbe5958: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    //     0xbe595c: stur            d0, [fp, #-0x18]
    //     0xbe5960: lsl             x5, x2, #1
    //     0xbe5964: lsl             w2, w5, #1
    //     0xbe5968: add             w5, w2, #8
    //     0xbe596c: add             x16, x4, w5, sxtw #1
    //     0xbe5970: ldur            w6, [x16, #0xf]
    //     0xbe5974: add             x6, x6, HEAP, lsl #32
    //     0xbe5978: add             x16, PP, #0x96, lsl #12  ; [pp+0x968c8] "minExtent"
    //     0xbe597c: ldr             x16, [x16, #0x8c8]
    //     0xbe5980: cmp             w6, w16
    //     0xbe5984: b.ne            #0xbe59ac
    //     0xbe5988: add             w5, w2, #0xa
    //     0xbe598c: add             x16, x4, w5, sxtw #1
    //     0xbe5990: ldur            w2, [x16, #0xf]
    //     0xbe5994: add             x2, x2, HEAP, lsl #32
    //     0xbe5998: sub             w4, w0, w2
    //     0xbe599c: add             x0, fp, w4, sxtw #2
    //     0xbe59a0: ldr             x0, [x0, #8]
    //     0xbe59a4: ldur            d1, [x0, #7]
    //     0xbe59a8: b               #0xbe59b0
    //     0xbe59ac: eor             v1.16b, v1.16b, v1.16b
    //     0xbe59b0: stur            d1, [fp, #-0x10]
    // 0xbe59b4: CheckStackOverflow
    //     0xbe59b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbe59b8: cmp             SP, x16
    //     0xbe59bc: b.ls            #0xbe5a58
    // 0xbe59c0: cmp             w3, NULL
    // 0xbe59c4: b.ne            #0xbe59d0
    // 0xbe59c8: LoadField: d2 = r1->field_33
    //     0xbe59c8: ldur            d2, [x1, #0x33]
    // 0xbe59cc: b               #0xbe59d4
    // 0xbe59d0: LoadField: d2 = r3->field_7
    //     0xbe59d0: ldur            d2, [x3, #7]
    // 0xbe59d4: stur            d2, [fp, #-8]
    // 0xbe59d8: r0 = axis()
    //     0xbe59d8: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbe59dc: LoadField: r1 = r0->field_7
    //     0xbe59dc: ldur            x1, [x0, #7]
    // 0xbe59e0: cmp             x1, #0
    // 0xbe59e4: b.gt            #0xbe5a20
    // 0xbe59e8: ldur            d0, [fp, #-0x18]
    // 0xbe59ec: ldur            d1, [fp, #-0x10]
    // 0xbe59f0: ldur            d2, [fp, #-8]
    // 0xbe59f4: r0 = BoxConstraints()
    //     0xbe59f4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbe59f8: ldur            d0, [fp, #-0x10]
    // 0xbe59fc: StoreField: r0->field_7 = d0
    //     0xbe59fc: stur            d0, [x0, #7]
    // 0xbe5a00: ldur            d1, [fp, #-0x18]
    // 0xbe5a04: StoreField: r0->field_f = d1
    //     0xbe5a04: stur            d1, [x0, #0xf]
    // 0xbe5a08: ldur            d2, [fp, #-8]
    // 0xbe5a0c: ArrayStore: r0[0] = d2  ; List_8
    //     0xbe5a0c: stur            d2, [x0, #0x17]
    // 0xbe5a10: StoreField: r0->field_1f = d2
    //     0xbe5a10: stur            d2, [x0, #0x1f]
    // 0xbe5a14: LeaveFrame
    //     0xbe5a14: mov             SP, fp
    //     0xbe5a18: ldp             fp, lr, [SP], #0x10
    // 0xbe5a1c: ret
    //     0xbe5a1c: ret             
    // 0xbe5a20: ldur            d1, [fp, #-0x18]
    // 0xbe5a24: ldur            d0, [fp, #-0x10]
    // 0xbe5a28: ldur            d2, [fp, #-8]
    // 0xbe5a2c: r0 = BoxConstraints()
    //     0xbe5a2c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xbe5a30: ldur            d0, [fp, #-8]
    // 0xbe5a34: StoreField: r0->field_7 = d0
    //     0xbe5a34: stur            d0, [x0, #7]
    // 0xbe5a38: StoreField: r0->field_f = d0
    //     0xbe5a38: stur            d0, [x0, #0xf]
    // 0xbe5a3c: ldur            d0, [fp, #-0x10]
    // 0xbe5a40: ArrayStore: r0[0] = d0  ; List_8
    //     0xbe5a40: stur            d0, [x0, #0x17]
    // 0xbe5a44: ldur            d0, [fp, #-0x18]
    // 0xbe5a48: StoreField: r0->field_1f = d0
    //     0xbe5a48: stur            d0, [x0, #0x1f]
    // 0xbe5a4c: LeaveFrame
    //     0xbe5a4c: mov             SP, fp
    //     0xbe5a50: ldp             fp, lr, [SP], #0x10
    // 0xbe5a54: ret
    //     0xbe5a54: ret             
    // 0xbe5a58: r0 = StackOverflowSharedWithFPURegs()
    //     0xbe5a58: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbe5a5c: b               #0xbe59c0
  }
  get _ axis(/* No info */) {
    // ** addr: 0xbe5a60, size: 0x50
    // 0xbe5a60: LoadField: r2 = r1->field_7
    //     0xbe5a60: ldur            w2, [x1, #7]
    // 0xbe5a64: DecompressPointer r2
    //     0xbe5a64: add             x2, x2, HEAP, lsl #32
    // 0xbe5a68: r16 = Instance_AxisDirection
    //     0xbe5a68: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xbe5a6c: cmp             w2, w16
    // 0xbe5a70: b.eq            #0xbe5a80
    // 0xbe5a74: r16 = Instance_AxisDirection
    //     0xbe5a74: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xbe5a78: cmp             w2, w16
    // 0xbe5a7c: b.ne            #0xbe5a88
    // 0xbe5a80: r0 = Instance_Axis
    //     0xbe5a80: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbe5a84: b               #0xbe5aac
    // 0xbe5a88: r16 = Instance_AxisDirection
    //     0xbe5a88: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xbe5a8c: cmp             w2, w16
    // 0xbe5a90: b.eq            #0xbe5aa0
    // 0xbe5a94: r16 = Instance_AxisDirection
    //     0xbe5a94: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xbe5a98: cmp             w2, w16
    // 0xbe5a9c: b.ne            #0xbe5aa8
    // 0xbe5aa0: r0 = Instance_Axis
    //     0xbe5aa0: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xbe5aa4: b               #0xbe5aac
    // 0xbe5aa8: r0 = Null
    //     0xbe5aa8: mov             x0, NULL
    // 0xbe5aac: ret
    //     0xbe5aac: ret             
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xbead44, size: 0xcc
    // 0xbead44: EnterFrame
    //     0xbead44: stp             fp, lr, [SP, #-0x10]!
    //     0xbead48: mov             fp, SP
    // 0xbead4c: AllocStack(0x58)
    //     0xbead4c: sub             SP, SP, #0x58
    // 0xbead50: SetupParameters(dynamic _ /* d0 => d0, fp-0x30 */, dynamic _ /* d1 => d1, fp-0x38 */, dynamic _ /* d2 => d2, fp-0x40 */, dynamic _ /* d3 => d3, fp-0x48 */, dynamic _ /* d4 => d4, fp-0x50 */, dynamic _ /* d5 => d5, fp-0x58 */)
    //     0xbead50: stur            d0, [fp, #-0x30]
    //     0xbead54: stur            d1, [fp, #-0x38]
    //     0xbead58: stur            d2, [fp, #-0x40]
    //     0xbead5c: stur            d3, [fp, #-0x48]
    //     0xbead60: stur            d4, [fp, #-0x50]
    //     0xbead64: stur            d5, [fp, #-0x58]
    // 0xbead68: LoadField: r0 = r1->field_7
    //     0xbead68: ldur            w0, [x1, #7]
    // 0xbead6c: DecompressPointer r0
    //     0xbead6c: add             x0, x0, HEAP, lsl #32
    // 0xbead70: stur            x0, [fp, #-0x20]
    // 0xbead74: LoadField: r2 = r1->field_b
    //     0xbead74: ldur            w2, [x1, #0xb]
    // 0xbead78: DecompressPointer r2
    //     0xbead78: add             x2, x2, HEAP, lsl #32
    // 0xbead7c: stur            x2, [fp, #-0x18]
    // 0xbead80: LoadField: r3 = r1->field_f
    //     0xbead80: ldur            w3, [x1, #0xf]
    // 0xbead84: DecompressPointer r3
    //     0xbead84: add             x3, x3, HEAP, lsl #32
    // 0xbead88: stur            x3, [fp, #-0x10]
    // 0xbead8c: LoadField: r4 = r1->field_3b
    //     0xbead8c: ldur            w4, [x1, #0x3b]
    // 0xbead90: DecompressPointer r4
    //     0xbead90: add             x4, x4, HEAP, lsl #32
    // 0xbead94: stur            x4, [fp, #-8]
    // 0xbead98: LoadField: d6 = r1->field_3f
    //     0xbead98: ldur            d6, [x1, #0x3f]
    // 0xbead9c: stur            d6, [fp, #-0x28]
    // 0xbeada0: r0 = SliverConstraints()
    //     0xbeada0: bl              #0xbc7f5c  ; AllocateSliverConstraintsStub -> SliverConstraints (size=0x58)
    // 0xbeada4: ldur            x1, [fp, #-0x20]
    // 0xbeada8: StoreField: r0->field_7 = r1
    //     0xbeada8: stur            w1, [x0, #7]
    // 0xbeadac: ldur            x1, [fp, #-0x18]
    // 0xbeadb0: StoreField: r0->field_b = r1
    //     0xbeadb0: stur            w1, [x0, #0xb]
    // 0xbeadb4: ldur            x1, [fp, #-0x10]
    // 0xbeadb8: StoreField: r0->field_f = r1
    //     0xbeadb8: stur            w1, [x0, #0xf]
    // 0xbeadbc: ldr             d0, [fp, #0x10]
    // 0xbeadc0: StoreField: r0->field_13 = d0
    //     0xbeadc0: stur            d0, [x0, #0x13]
    // 0xbeadc4: ldur            d0, [fp, #-0x48]
    // 0xbeadc8: StoreField: r0->field_1b = d0
    //     0xbeadc8: stur            d0, [x0, #0x1b]
    // 0xbeadcc: ldur            d0, [fp, #-0x40]
    // 0xbeadd0: StoreField: r0->field_23 = d0
    //     0xbeadd0: stur            d0, [x0, #0x23]
    // 0xbeadd4: ldur            d0, [fp, #-0x58]
    // 0xbeadd8: StoreField: r0->field_2b = d0
    //     0xbeadd8: stur            d0, [x0, #0x2b]
    // 0xbeaddc: ldur            d0, [fp, #-0x38]
    // 0xbeade0: StoreField: r0->field_33 = d0
    //     0xbeade0: stur            d0, [x0, #0x33]
    // 0xbeade4: ldur            x1, [fp, #-8]
    // 0xbeade8: StoreField: r0->field_3b = r1
    //     0xbeade8: stur            w1, [x0, #0x3b]
    // 0xbeadec: ldur            d0, [fp, #-0x28]
    // 0xbeadf0: StoreField: r0->field_3f = d0
    //     0xbeadf0: stur            d0, [x0, #0x3f]
    // 0xbeadf4: ldur            d0, [fp, #-0x50]
    // 0xbeadf8: StoreField: r0->field_4f = d0
    //     0xbeadf8: stur            d0, [x0, #0x4f]
    // 0xbeadfc: ldur            d0, [fp, #-0x30]
    // 0xbeae00: StoreField: r0->field_47 = d0
    //     0xbeae00: stur            d0, [x0, #0x47]
    // 0xbeae04: LeaveFrame
    //     0xbeae04: mov             SP, fp
    //     0xbeae08: ldp             fp, lr, [SP], #0x10
    // 0xbeae0c: ret
    //     0xbeae0c: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114c43c, size: 0x404
    // 0x114c43c: EnterFrame
    //     0x114c43c: stp             fp, lr, [SP, #-0x10]!
    //     0x114c440: mov             fp, SP
    // 0x114c444: AllocStack(0x50)
    //     0x114c444: sub             SP, SP, #0x50
    // 0x114c448: CheckStackOverflow
    //     0x114c448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114c44c: cmp             SP, x16
    //     0x114c450: b.ls            #0x114c63c
    // 0x114c454: ldr             x0, [fp, #0x10]
    // 0x114c458: LoadField: r1 = r0->field_7
    //     0x114c458: ldur            w1, [x0, #7]
    // 0x114c45c: DecompressPointer r1
    //     0x114c45c: add             x1, x1, HEAP, lsl #32
    // 0x114c460: LoadField: r2 = r0->field_b
    //     0x114c460: ldur            w2, [x0, #0xb]
    // 0x114c464: DecompressPointer r2
    //     0x114c464: add             x2, x2, HEAP, lsl #32
    // 0x114c468: LoadField: r3 = r0->field_f
    //     0x114c468: ldur            w3, [x0, #0xf]
    // 0x114c46c: DecompressPointer r3
    //     0x114c46c: add             x3, x3, HEAP, lsl #32
    // 0x114c470: LoadField: d0 = r0->field_13
    //     0x114c470: ldur            d0, [x0, #0x13]
    // 0x114c474: LoadField: d1 = r0->field_1b
    //     0x114c474: ldur            d1, [x0, #0x1b]
    // 0x114c478: LoadField: d2 = r0->field_23
    //     0x114c478: ldur            d2, [x0, #0x23]
    // 0x114c47c: LoadField: d3 = r0->field_2b
    //     0x114c47c: ldur            d3, [x0, #0x2b]
    // 0x114c480: LoadField: d4 = r0->field_33
    //     0x114c480: ldur            d4, [x0, #0x33]
    // 0x114c484: LoadField: r4 = r0->field_3b
    //     0x114c484: ldur            w4, [x0, #0x3b]
    // 0x114c488: DecompressPointer r4
    //     0x114c488: add             x4, x4, HEAP, lsl #32
    // 0x114c48c: LoadField: d5 = r0->field_3f
    //     0x114c48c: ldur            d5, [x0, #0x3f]
    // 0x114c490: LoadField: d6 = r0->field_4f
    //     0x114c490: ldur            d6, [x0, #0x4f]
    // 0x114c494: LoadField: d7 = r0->field_47
    //     0x114c494: ldur            d7, [x0, #0x47]
    // 0x114c498: r0 = inline_Allocate_Double()
    //     0x114c498: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0x114c49c: add             x0, x0, #0x10
    //     0x114c4a0: cmp             x5, x0
    //     0x114c4a4: b.ls            #0x114c644
    //     0x114c4a8: str             x0, [THR, #0x60]  ; THR::top
    //     0x114c4ac: sub             x0, x0, #0xf
    //     0x114c4b0: mov             x5, #0xe19c
    //     0x114c4b4: movk            x5, #3, lsl #16
    //     0x114c4b8: stur            x5, [x0, #-1]
    // 0x114c4bc: dmb             ishst
    // 0x114c4c0: StoreField: r0->field_7 = d0
    //     0x114c4c0: stur            d0, [x0, #7]
    // 0x114c4c4: r5 = inline_Allocate_Double()
    //     0x114c4c4: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x114c4c8: add             x5, x5, #0x10
    //     0x114c4cc: cmp             x6, x5
    //     0x114c4d0: b.ls            #0x114c67c
    //     0x114c4d4: str             x5, [THR, #0x60]  ; THR::top
    //     0x114c4d8: sub             x5, x5, #0xf
    //     0x114c4dc: mov             x6, #0xe19c
    //     0x114c4e0: movk            x6, #3, lsl #16
    //     0x114c4e4: stur            x6, [x5, #-1]
    // 0x114c4e8: dmb             ishst
    // 0x114c4ec: StoreField: r5->field_7 = d1
    //     0x114c4ec: stur            d1, [x5, #7]
    // 0x114c4f0: r6 = inline_Allocate_Double()
    //     0x114c4f0: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x114c4f4: add             x6, x6, #0x10
    //     0x114c4f8: cmp             x7, x6
    //     0x114c4fc: b.ls            #0x114c6c0
    //     0x114c500: str             x6, [THR, #0x60]  ; THR::top
    //     0x114c504: sub             x6, x6, #0xf
    //     0x114c508: mov             x7, #0xe19c
    //     0x114c50c: movk            x7, #3, lsl #16
    //     0x114c510: stur            x7, [x6, #-1]
    // 0x114c514: dmb             ishst
    // 0x114c518: StoreField: r6->field_7 = d2
    //     0x114c518: stur            d2, [x6, #7]
    // 0x114c51c: r7 = inline_Allocate_Double()
    //     0x114c51c: ldp             x7, x8, [THR, #0x60]  ; THR::top
    //     0x114c520: add             x7, x7, #0x10
    //     0x114c524: cmp             x8, x7
    //     0x114c528: b.ls            #0x114c6fc
    //     0x114c52c: str             x7, [THR, #0x60]  ; THR::top
    //     0x114c530: sub             x7, x7, #0xf
    //     0x114c534: mov             x8, #0xe19c
    //     0x114c538: movk            x8, #3, lsl #16
    //     0x114c53c: stur            x8, [x7, #-1]
    // 0x114c540: dmb             ishst
    // 0x114c544: StoreField: r7->field_7 = d3
    //     0x114c544: stur            d3, [x7, #7]
    // 0x114c548: r8 = inline_Allocate_Double()
    //     0x114c548: ldp             x8, x9, [THR, #0x60]  ; THR::top
    //     0x114c54c: add             x8, x8, #0x10
    //     0x114c550: cmp             x9, x8
    //     0x114c554: b.ls            #0x114c740
    //     0x114c558: str             x8, [THR, #0x60]  ; THR::top
    //     0x114c55c: sub             x8, x8, #0xf
    //     0x114c560: mov             x9, #0xe19c
    //     0x114c564: movk            x9, #3, lsl #16
    //     0x114c568: stur            x9, [x8, #-1]
    // 0x114c56c: dmb             ishst
    // 0x114c570: StoreField: r8->field_7 = d4
    //     0x114c570: stur            d4, [x8, #7]
    // 0x114c574: r9 = inline_Allocate_Double()
    //     0x114c574: ldp             x9, x10, [THR, #0x60]  ; THR::top
    //     0x114c578: add             x9, x9, #0x10
    //     0x114c57c: cmp             x10, x9
    //     0x114c580: b.ls            #0x114c77c
    //     0x114c584: str             x9, [THR, #0x60]  ; THR::top
    //     0x114c588: sub             x9, x9, #0xf
    //     0x114c58c: mov             x10, #0xe19c
    //     0x114c590: movk            x10, #3, lsl #16
    //     0x114c594: stur            x10, [x9, #-1]
    // 0x114c598: dmb             ishst
    // 0x114c59c: StoreField: r9->field_7 = d5
    //     0x114c59c: stur            d5, [x9, #7]
    // 0x114c5a0: r10 = inline_Allocate_Double()
    //     0x114c5a0: ldp             x10, x11, [THR, #0x60]  ; THR::top
    //     0x114c5a4: add             x10, x10, #0x10
    //     0x114c5a8: cmp             x11, x10
    //     0x114c5ac: b.ls            #0x114c7c0
    //     0x114c5b0: str             x10, [THR, #0x60]  ; THR::top
    //     0x114c5b4: sub             x10, x10, #0xf
    //     0x114c5b8: mov             x11, #0xe19c
    //     0x114c5bc: movk            x11, #3, lsl #16
    //     0x114c5c0: stur            x11, [x10, #-1]
    // 0x114c5c4: dmb             ishst
    // 0x114c5c8: StoreField: r10->field_7 = d6
    //     0x114c5c8: stur            d6, [x10, #7]
    // 0x114c5cc: r11 = inline_Allocate_Double()
    //     0x114c5cc: ldp             x11, x12, [THR, #0x60]  ; THR::top
    //     0x114c5d0: add             x11, x11, #0x10
    //     0x114c5d4: cmp             x12, x11
    //     0x114c5d8: b.ls            #0x114c7fc
    //     0x114c5dc: str             x11, [THR, #0x60]  ; THR::top
    //     0x114c5e0: sub             x11, x11, #0xf
    //     0x114c5e4: mov             x12, #0xe19c
    //     0x114c5e8: movk            x12, #3, lsl #16
    //     0x114c5ec: stur            x12, [x11, #-1]
    // 0x114c5f0: dmb             ishst
    // 0x114c5f4: StoreField: r11->field_7 = d7
    //     0x114c5f4: stur            d7, [x11, #7]
    // 0x114c5f8: stp             x0, x3, [SP, #0x40]
    // 0x114c5fc: stp             x6, x5, [SP, #0x30]
    // 0x114c600: stp             x8, x7, [SP, #0x20]
    // 0x114c604: stp             x9, x4, [SP, #0x10]
    // 0x114c608: stp             x11, x10, [SP]
    // 0x114c60c: r4 = const [0, 0xc, 0xa, 0xc, null]
    //     0x114c60c: add             x4, PP, #0x26, lsl #12  ; [pp+0x26270] List(5) [0, 0xc, 0xa, 0xc, Null]
    //     0x114c610: ldr             x4, [x4, #0x270]
    // 0x114c614: r0 = hash()
    //     0x114c614: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114c618: mov             x2, x0
    // 0x114c61c: r0 = BoxInt64Instr(r2)
    //     0x114c61c: sbfiz           x0, x2, #1, #0x1f
    //     0x114c620: cmp             x2, x0, asr #1
    //     0x114c624: b.eq            #0x114c630
    //     0x114c628: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114c62c: stur            x2, [x0, #7]
    // 0x114c630: LeaveFrame
    //     0x114c630: mov             SP, fp
    //     0x114c634: ldp             fp, lr, [SP], #0x10
    // 0x114c638: ret
    //     0x114c638: ret             
    // 0x114c63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114c63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114c640: b               #0x114c454
    // 0x114c644: stp             q6, q7, [SP, #-0x20]!
    // 0x114c648: stp             q4, q5, [SP, #-0x20]!
    // 0x114c64c: stp             q2, q3, [SP, #-0x20]!
    // 0x114c650: stp             q0, q1, [SP, #-0x20]!
    // 0x114c654: stp             x3, x4, [SP, #-0x10]!
    // 0x114c658: stp             x1, x2, [SP, #-0x10]!
    // 0x114c65c: r0 = AllocateDouble()
    //     0x114c65c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c660: ldp             x1, x2, [SP], #0x10
    // 0x114c664: ldp             x3, x4, [SP], #0x10
    // 0x114c668: ldp             q0, q1, [SP], #0x20
    // 0x114c66c: ldp             q2, q3, [SP], #0x20
    // 0x114c670: ldp             q4, q5, [SP], #0x20
    // 0x114c674: ldp             q6, q7, [SP], #0x20
    // 0x114c678: b               #0x114c4c0
    // 0x114c67c: stp             q6, q7, [SP, #-0x20]!
    // 0x114c680: stp             q4, q5, [SP, #-0x20]!
    // 0x114c684: stp             q2, q3, [SP, #-0x20]!
    // 0x114c688: SaveReg d1
    //     0x114c688: str             q1, [SP, #-0x10]!
    // 0x114c68c: stp             x3, x4, [SP, #-0x10]!
    // 0x114c690: stp             x1, x2, [SP, #-0x10]!
    // 0x114c694: SaveReg r0
    //     0x114c694: str             x0, [SP, #-8]!
    // 0x114c698: r0 = AllocateDouble()
    //     0x114c698: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c69c: mov             x5, x0
    // 0x114c6a0: RestoreReg r0
    //     0x114c6a0: ldr             x0, [SP], #8
    // 0x114c6a4: ldp             x1, x2, [SP], #0x10
    // 0x114c6a8: ldp             x3, x4, [SP], #0x10
    // 0x114c6ac: RestoreReg d1
    //     0x114c6ac: ldr             q1, [SP], #0x10
    // 0x114c6b0: ldp             q2, q3, [SP], #0x20
    // 0x114c6b4: ldp             q4, q5, [SP], #0x20
    // 0x114c6b8: ldp             q6, q7, [SP], #0x20
    // 0x114c6bc: b               #0x114c4ec
    // 0x114c6c0: stp             q6, q7, [SP, #-0x20]!
    // 0x114c6c4: stp             q4, q5, [SP, #-0x20]!
    // 0x114c6c8: stp             q2, q3, [SP, #-0x20]!
    // 0x114c6cc: stp             x4, x5, [SP, #-0x10]!
    // 0x114c6d0: stp             x2, x3, [SP, #-0x10]!
    // 0x114c6d4: stp             x0, x1, [SP, #-0x10]!
    // 0x114c6d8: r0 = AllocateDouble()
    //     0x114c6d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c6dc: mov             x6, x0
    // 0x114c6e0: ldp             x0, x1, [SP], #0x10
    // 0x114c6e4: ldp             x2, x3, [SP], #0x10
    // 0x114c6e8: ldp             x4, x5, [SP], #0x10
    // 0x114c6ec: ldp             q2, q3, [SP], #0x20
    // 0x114c6f0: ldp             q4, q5, [SP], #0x20
    // 0x114c6f4: ldp             q6, q7, [SP], #0x20
    // 0x114c6f8: b               #0x114c518
    // 0x114c6fc: stp             q6, q7, [SP, #-0x20]!
    // 0x114c700: stp             q4, q5, [SP, #-0x20]!
    // 0x114c704: SaveReg d3
    //     0x114c704: str             q3, [SP, #-0x10]!
    // 0x114c708: stp             x5, x6, [SP, #-0x10]!
    // 0x114c70c: stp             x3, x4, [SP, #-0x10]!
    // 0x114c710: stp             x1, x2, [SP, #-0x10]!
    // 0x114c714: SaveReg r0
    //     0x114c714: str             x0, [SP, #-8]!
    // 0x114c718: r0 = AllocateDouble()
    //     0x114c718: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c71c: mov             x7, x0
    // 0x114c720: RestoreReg r0
    //     0x114c720: ldr             x0, [SP], #8
    // 0x114c724: ldp             x1, x2, [SP], #0x10
    // 0x114c728: ldp             x3, x4, [SP], #0x10
    // 0x114c72c: ldp             x5, x6, [SP], #0x10
    // 0x114c730: RestoreReg d3
    //     0x114c730: ldr             q3, [SP], #0x10
    // 0x114c734: ldp             q4, q5, [SP], #0x20
    // 0x114c738: ldp             q6, q7, [SP], #0x20
    // 0x114c73c: b               #0x114c544
    // 0x114c740: stp             q6, q7, [SP, #-0x20]!
    // 0x114c744: stp             q4, q5, [SP, #-0x20]!
    // 0x114c748: stp             x6, x7, [SP, #-0x10]!
    // 0x114c74c: stp             x4, x5, [SP, #-0x10]!
    // 0x114c750: stp             x2, x3, [SP, #-0x10]!
    // 0x114c754: stp             x0, x1, [SP, #-0x10]!
    // 0x114c758: r0 = AllocateDouble()
    //     0x114c758: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c75c: mov             x8, x0
    // 0x114c760: ldp             x0, x1, [SP], #0x10
    // 0x114c764: ldp             x2, x3, [SP], #0x10
    // 0x114c768: ldp             x4, x5, [SP], #0x10
    // 0x114c76c: ldp             x6, x7, [SP], #0x10
    // 0x114c770: ldp             q4, q5, [SP], #0x20
    // 0x114c774: ldp             q6, q7, [SP], #0x20
    // 0x114c778: b               #0x114c570
    // 0x114c77c: stp             q6, q7, [SP, #-0x20]!
    // 0x114c780: SaveReg d5
    //     0x114c780: str             q5, [SP, #-0x10]!
    // 0x114c784: stp             x7, x8, [SP, #-0x10]!
    // 0x114c788: stp             x5, x6, [SP, #-0x10]!
    // 0x114c78c: stp             x3, x4, [SP, #-0x10]!
    // 0x114c790: stp             x1, x2, [SP, #-0x10]!
    // 0x114c794: SaveReg r0
    //     0x114c794: str             x0, [SP, #-8]!
    // 0x114c798: r0 = AllocateDouble()
    //     0x114c798: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c79c: mov             x9, x0
    // 0x114c7a0: RestoreReg r0
    //     0x114c7a0: ldr             x0, [SP], #8
    // 0x114c7a4: ldp             x1, x2, [SP], #0x10
    // 0x114c7a8: ldp             x3, x4, [SP], #0x10
    // 0x114c7ac: ldp             x5, x6, [SP], #0x10
    // 0x114c7b0: ldp             x7, x8, [SP], #0x10
    // 0x114c7b4: RestoreReg d5
    //     0x114c7b4: ldr             q5, [SP], #0x10
    // 0x114c7b8: ldp             q6, q7, [SP], #0x20
    // 0x114c7bc: b               #0x114c59c
    // 0x114c7c0: stp             q6, q7, [SP, #-0x20]!
    // 0x114c7c4: stp             x8, x9, [SP, #-0x10]!
    // 0x114c7c8: stp             x6, x7, [SP, #-0x10]!
    // 0x114c7cc: stp             x4, x5, [SP, #-0x10]!
    // 0x114c7d0: stp             x2, x3, [SP, #-0x10]!
    // 0x114c7d4: stp             x0, x1, [SP, #-0x10]!
    // 0x114c7d8: r0 = AllocateDouble()
    //     0x114c7d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c7dc: mov             x10, x0
    // 0x114c7e0: ldp             x0, x1, [SP], #0x10
    // 0x114c7e4: ldp             x2, x3, [SP], #0x10
    // 0x114c7e8: ldp             x4, x5, [SP], #0x10
    // 0x114c7ec: ldp             x6, x7, [SP], #0x10
    // 0x114c7f0: ldp             x8, x9, [SP], #0x10
    // 0x114c7f4: ldp             q6, q7, [SP], #0x20
    // 0x114c7f8: b               #0x114c5c8
    // 0x114c7fc: SaveReg d7
    //     0x114c7fc: str             q7, [SP, #-0x10]!
    // 0x114c800: stp             x9, x10, [SP, #-0x10]!
    // 0x114c804: stp             x7, x8, [SP, #-0x10]!
    // 0x114c808: stp             x5, x6, [SP, #-0x10]!
    // 0x114c80c: stp             x3, x4, [SP, #-0x10]!
    // 0x114c810: stp             x1, x2, [SP, #-0x10]!
    // 0x114c814: SaveReg r0
    //     0x114c814: str             x0, [SP, #-8]!
    // 0x114c818: r0 = AllocateDouble()
    //     0x114c818: bl              #0x13df878  ; AllocateDoubleStub
    // 0x114c81c: mov             x11, x0
    // 0x114c820: RestoreReg r0
    //     0x114c820: ldr             x0, [SP], #8
    // 0x114c824: ldp             x1, x2, [SP], #0x10
    // 0x114c828: ldp             x3, x4, [SP], #0x10
    // 0x114c82c: ldp             x5, x6, [SP], #0x10
    // 0x114c830: ldp             x7, x8, [SP], #0x10
    // 0x114c834: ldp             x9, x10, [SP], #0x10
    // 0x114c838: RestoreReg d7
    //     0x114c838: ldr             q7, [SP], #0x10
    // 0x114c83c: b               #0x114c5f4
  }
  _ ==(/* No info */) {
    // ** addr: 0x1299be4, size: 0x140
    // 0x1299be4: ldr             x1, [SP]
    // 0x1299be8: cmp             w1, NULL
    // 0x1299bec: b.ne            #0x1299bf8
    // 0x1299bf0: r0 = false
    //     0x1299bf0: add             x0, NULL, #0x30  ; false
    // 0x1299bf4: ret
    //     0x1299bf4: ret             
    // 0x1299bf8: ldr             x2, [SP, #8]
    // 0x1299bfc: cmp             w2, w1
    // 0x1299c00: b.ne            #0x1299c0c
    // 0x1299c04: r0 = true
    //     0x1299c04: add             x0, NULL, #0x20  ; true
    // 0x1299c08: ret
    //     0x1299c08: ret             
    // 0x1299c0c: r3 = 60
    //     0x1299c0c: mov             x3, #0x3c
    // 0x1299c10: branchIfSmi(r1, 0x1299c1c)
    //     0x1299c10: tbz             w1, #0, #0x1299c1c
    // 0x1299c14: r3 = LoadClassIdInstr(r1)
    //     0x1299c14: ldur            x3, [x1, #-1]
    //     0x1299c18: ubfx            x3, x3, #0xc, #0x14
    // 0x1299c1c: cmp             x3, #0xb45
    // 0x1299c20: b.eq            #0x1299c2c
    // 0x1299c24: r0 = false
    //     0x1299c24: add             x0, NULL, #0x30  ; false
    // 0x1299c28: ret
    //     0x1299c28: ret             
    // 0x1299c2c: LoadField: r3 = r1->field_7
    //     0x1299c2c: ldur            w3, [x1, #7]
    // 0x1299c30: DecompressPointer r3
    //     0x1299c30: add             x3, x3, HEAP, lsl #32
    // 0x1299c34: LoadField: r4 = r2->field_7
    //     0x1299c34: ldur            w4, [x2, #7]
    // 0x1299c38: DecompressPointer r4
    //     0x1299c38: add             x4, x4, HEAP, lsl #32
    // 0x1299c3c: cmp             w3, w4
    // 0x1299c40: b.ne            #0x1299d1c
    // 0x1299c44: LoadField: r3 = r1->field_b
    //     0x1299c44: ldur            w3, [x1, #0xb]
    // 0x1299c48: DecompressPointer r3
    //     0x1299c48: add             x3, x3, HEAP, lsl #32
    // 0x1299c4c: LoadField: r4 = r2->field_b
    //     0x1299c4c: ldur            w4, [x2, #0xb]
    // 0x1299c50: DecompressPointer r4
    //     0x1299c50: add             x4, x4, HEAP, lsl #32
    // 0x1299c54: cmp             w3, w4
    // 0x1299c58: b.ne            #0x1299d1c
    // 0x1299c5c: LoadField: r3 = r1->field_f
    //     0x1299c5c: ldur            w3, [x1, #0xf]
    // 0x1299c60: DecompressPointer r3
    //     0x1299c60: add             x3, x3, HEAP, lsl #32
    // 0x1299c64: LoadField: r4 = r2->field_f
    //     0x1299c64: ldur            w4, [x2, #0xf]
    // 0x1299c68: DecompressPointer r4
    //     0x1299c68: add             x4, x4, HEAP, lsl #32
    // 0x1299c6c: cmp             w3, w4
    // 0x1299c70: b.ne            #0x1299d1c
    // 0x1299c74: LoadField: d0 = r1->field_13
    //     0x1299c74: ldur            d0, [x1, #0x13]
    // 0x1299c78: LoadField: d1 = r2->field_13
    //     0x1299c78: ldur            d1, [x2, #0x13]
    // 0x1299c7c: fcmp            d0, d1
    // 0x1299c80: b.ne            #0x1299d1c
    // 0x1299c84: LoadField: d0 = r1->field_1b
    //     0x1299c84: ldur            d0, [x1, #0x1b]
    // 0x1299c88: LoadField: d1 = r2->field_1b
    //     0x1299c88: ldur            d1, [x2, #0x1b]
    // 0x1299c8c: fcmp            d0, d1
    // 0x1299c90: b.ne            #0x1299d1c
    // 0x1299c94: LoadField: d0 = r1->field_23
    //     0x1299c94: ldur            d0, [x1, #0x23]
    // 0x1299c98: LoadField: d1 = r2->field_23
    //     0x1299c98: ldur            d1, [x2, #0x23]
    // 0x1299c9c: fcmp            d0, d1
    // 0x1299ca0: b.ne            #0x1299d1c
    // 0x1299ca4: LoadField: d0 = r1->field_2b
    //     0x1299ca4: ldur            d0, [x1, #0x2b]
    // 0x1299ca8: LoadField: d1 = r2->field_2b
    //     0x1299ca8: ldur            d1, [x2, #0x2b]
    // 0x1299cac: fcmp            d0, d1
    // 0x1299cb0: b.ne            #0x1299d1c
    // 0x1299cb4: LoadField: d0 = r1->field_33
    //     0x1299cb4: ldur            d0, [x1, #0x33]
    // 0x1299cb8: LoadField: d1 = r2->field_33
    //     0x1299cb8: ldur            d1, [x2, #0x33]
    // 0x1299cbc: fcmp            d0, d1
    // 0x1299cc0: b.ne            #0x1299d1c
    // 0x1299cc4: LoadField: r3 = r1->field_3b
    //     0x1299cc4: ldur            w3, [x1, #0x3b]
    // 0x1299cc8: DecompressPointer r3
    //     0x1299cc8: add             x3, x3, HEAP, lsl #32
    // 0x1299ccc: LoadField: r4 = r2->field_3b
    //     0x1299ccc: ldur            w4, [x2, #0x3b]
    // 0x1299cd0: DecompressPointer r4
    //     0x1299cd0: add             x4, x4, HEAP, lsl #32
    // 0x1299cd4: cmp             w3, w4
    // 0x1299cd8: b.ne            #0x1299d1c
    // 0x1299cdc: LoadField: d0 = r1->field_3f
    //     0x1299cdc: ldur            d0, [x1, #0x3f]
    // 0x1299ce0: LoadField: d1 = r2->field_3f
    //     0x1299ce0: ldur            d1, [x2, #0x3f]
    // 0x1299ce4: fcmp            d0, d1
    // 0x1299ce8: b.ne            #0x1299d1c
    // 0x1299cec: LoadField: d0 = r1->field_4f
    //     0x1299cec: ldur            d0, [x1, #0x4f]
    // 0x1299cf0: LoadField: d1 = r2->field_4f
    //     0x1299cf0: ldur            d1, [x2, #0x4f]
    // 0x1299cf4: fcmp            d0, d1
    // 0x1299cf8: b.ne            #0x1299d1c
    // 0x1299cfc: LoadField: d0 = r1->field_47
    //     0x1299cfc: ldur            d0, [x1, #0x47]
    // 0x1299d00: LoadField: d1 = r2->field_47
    //     0x1299d00: ldur            d1, [x2, #0x47]
    // 0x1299d04: fcmp            d0, d1
    // 0x1299d08: r16 = true
    //     0x1299d08: add             x16, NULL, #0x20  ; true
    // 0x1299d0c: r17 = false
    //     0x1299d0c: add             x17, NULL, #0x30  ; false
    // 0x1299d10: csel            x1, x16, x17, eq
    // 0x1299d14: mov             x0, x1
    // 0x1299d18: b               #0x1299d20
    // 0x1299d1c: r0 = false
    //     0x1299d1c: add             x0, NULL, #0x30  ; false
    // 0x1299d20: ret
    //     0x1299d20: ret             
  }
}

// class id: 3166, size: 0x14, field offset: 0x14
class SliverHitTestResult extends HitTestResult {

  _ addWithAxisOffset(/* No info */) {
    // ** addr: 0x11445f4, size: 0x130
    // 0x11445f4: EnterFrame
    //     0x11445f4: stp             fp, lr, [SP, #-0x10]!
    //     0x11445f8: mov             fp, SP
    // 0x11445fc: AllocStack(0x40)
    //     0x11445fc: sub             SP, SP, #0x40
    // 0x1144600: SetupParameters(SliverHitTestResult this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r1 */, dynamic _ /* d0 => d0, fp-0x18 */, dynamic _ /* d1 => d1, fp-0x20 */, dynamic _ /* d2 => d2, fp-0x28 */, dynamic _ /* d3 => d3, fp-0x30 */)
    //     0x1144600: mov             x0, x1
    //     0x1144604: stur            x1, [fp, #-8]
    //     0x1144608: mov             x1, x3
    //     0x114460c: stur            x2, [fp, #-0x10]
    //     0x1144610: stur            d0, [fp, #-0x18]
    //     0x1144614: stur            d1, [fp, #-0x20]
    //     0x1144618: stur            d2, [fp, #-0x28]
    //     0x114461c: stur            d3, [fp, #-0x30]
    // 0x1144620: CheckStackOverflow
    //     0x1144620: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1144624: cmp             SP, x16
    //     0x1144628: b.ls            #0x11446e8
    // 0x114462c: r0 = unary-()
    //     0x114462c: bl              #0x856e6c  ; [dart:ui] Offset::unary-
    // 0x1144630: ldur            x1, [fp, #-8]
    // 0x1144634: mov             x2, x0
    // 0x1144638: r0 = pushOffset()
    //     0x1144638: bl              #0xaf9e0c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x114463c: ldur            d1, [fp, #-0x28]
    // 0x1144640: ldur            d0, [fp, #-0x30]
    // 0x1144644: fsub            d2, d0, d1
    // 0x1144648: ldur            d1, [fp, #-0x18]
    // 0x114464c: ldur            d0, [fp, #-0x20]
    // 0x1144650: fsub            d3, d0, d1
    // 0x1144654: ldur            x0, [fp, #-0x10]
    // 0x1144658: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x1144658: ldur            w1, [x0, #0x17]
    // 0x114465c: DecompressPointer r1
    //     0x114465c: add             x1, x1, HEAP, lsl #32
    // 0x1144660: r0 = inline_Allocate_Double()
    //     0x1144660: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x1144664: add             x0, x0, #0x10
    //     0x1144668: cmp             x2, x0
    //     0x114466c: b.ls            #0x11446f0
    //     0x1144670: str             x0, [THR, #0x60]  ; THR::top
    //     0x1144674: sub             x0, x0, #0xf
    //     0x1144678: mov             x2, #0xe19c
    //     0x114467c: movk            x2, #3, lsl #16
    //     0x1144680: stur            x2, [x0, #-1]
    // 0x1144684: dmb             ishst
    // 0x1144688: StoreField: r0->field_7 = d2
    //     0x1144688: stur            d2, [x0, #7]
    // 0x114468c: r2 = inline_Allocate_Double()
    //     0x114468c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x1144690: add             x2, x2, #0x10
    //     0x1144694: cmp             x3, x2
    //     0x1144698: b.ls            #0x1144708
    //     0x114469c: str             x2, [THR, #0x60]  ; THR::top
    //     0x11446a0: sub             x2, x2, #0xf
    //     0x11446a4: mov             x3, #0xe19c
    //     0x11446a8: movk            x3, #3, lsl #16
    //     0x11446ac: stur            x3, [x2, #-1]
    // 0x11446b0: dmb             ishst
    // 0x11446b4: StoreField: r2->field_7 = d3
    //     0x11446b4: stur            d3, [x2, #7]
    // 0x11446b8: stp             x2, x0, [SP]
    // 0x11446bc: ldur            x2, [fp, #-8]
    // 0x11446c0: r4 = const [0, 0x4, 0x2, 0x2, crossAxisPosition, 0x3, mainAxisPosition, 0x2, null]
    //     0x11446c0: add             x4, PP, #0x96, lsl #12  ; [pp+0x96438] List(9) [0, 0x4, 0x2, 0x2, "crossAxisPosition", 0x3, "mainAxisPosition", 0x2, Null]
    //     0x11446c4: ldr             x4, [x4, #0x438]
    // 0x11446c8: r0 = hitTest()
    //     0x11446c8: bl              #0x10eb6cc  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::hitTest
    // 0x11446cc: ldur            x1, [fp, #-8]
    // 0x11446d0: stur            x0, [fp, #-8]
    // 0x11446d4: r0 = popTransform()
    //     0x11446d4: bl              #0xaf9850  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x11446d8: ldur            x0, [fp, #-8]
    // 0x11446dc: LeaveFrame
    //     0x11446dc: mov             SP, fp
    //     0x11446e0: ldp             fp, lr, [SP], #0x10
    // 0x11446e4: ret
    //     0x11446e4: ret             
    // 0x11446e8: r0 = StackOverflowSharedWithFPURegs()
    //     0x11446e8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11446ec: b               #0x114462c
    // 0x11446f0: stp             q2, q3, [SP, #-0x20]!
    // 0x11446f4: SaveReg r1
    //     0x11446f4: str             x1, [SP, #-8]!
    // 0x11446f8: r0 = AllocateDouble()
    //     0x11446f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0x11446fc: RestoreReg r1
    //     0x11446fc: ldr             x1, [SP], #8
    // 0x1144700: ldp             q2, q3, [SP], #0x20
    // 0x1144704: b               #0x1144688
    // 0x1144708: SaveReg d3
    //     0x1144708: str             q3, [SP, #-0x10]!
    // 0x114470c: stp             x0, x1, [SP, #-0x10]!
    // 0x1144710: r0 = AllocateDouble()
    //     0x1144710: bl              #0x13df878  ; AllocateDoubleStub
    // 0x1144714: mov             x2, x0
    // 0x1144718: ldp             x0, x1, [SP], #0x10
    // 0x114471c: RestoreReg d3
    //     0x114471c: ldr             q3, [SP], #0x10
    // 0x1144720: b               #0x11446b4
  }
}

// class id: 3172, size: 0x14, field offset: 0x14
class SliverHitTestEntry extends HitTestEntry<dynamic> {
}

// class id: 4177, size: 0xc, field offset: 0x8
class SliverPhysicalParentData extends ParentData {

  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf1bec, size: 0x48
    // 0xbf1bec: EnterFrame
    //     0xbf1bec: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1bf0: mov             fp, SP
    // 0xbf1bf4: mov             x0, x1
    // 0xbf1bf8: mov             x1, x2
    // 0xbf1bfc: CheckStackOverflow
    //     0xbf1bfc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1c00: cmp             SP, x16
    //     0xbf1c04: b.ls            #0xbf1c2c
    // 0xbf1c08: LoadField: r2 = r0->field_7
    //     0xbf1c08: ldur            w2, [x0, #7]
    // 0xbf1c0c: DecompressPointer r2
    //     0xbf1c0c: add             x2, x2, HEAP, lsl #32
    // 0xbf1c10: LoadField: d0 = r2->field_7
    //     0xbf1c10: ldur            d0, [x2, #7]
    // 0xbf1c14: LoadField: d1 = r2->field_f
    //     0xbf1c14: ldur            d1, [x2, #0xf]
    // 0xbf1c18: r0 = translateByDouble()
    //     0xbf1c18: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf1c1c: r0 = Null
    //     0xbf1c1c: mov             x0, NULL
    // 0xbf1c20: LeaveFrame
    //     0xbf1c20: mov             SP, fp
    //     0xbf1c24: ldp             fp, lr, [SP], #0x10
    // 0xbf1c28: ret
    //     0xbf1c28: ret             
    // 0xbf1c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf1c2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1c30: b               #0xbf1c08
  }
}

// class id: 4179, size: 0x14, field offset: 0x14
class SliverPhysicalContainerParentData extends _MixinApplication447&SliverPhysicalParentData&ContainerParentDataMixin {
}

// class id: 4180, size: 0xc, field offset: 0x8
abstract class SliverLogicalParentData extends ParentData {
}

// class id: 4186, size: 0x14, field offset: 0x14
class SliverLogicalContainerParentData extends _MixinApplication446&SliverLogicalParentData&ContainerParentDataMixin {
}

// class id: 4641, size: 0x8, field offset: 0x8
abstract class RenderSliverHelpers extends Object
    implements RenderSliver {
}

// class id: 4684, size: 0x4c, field offset: 0x48
abstract class RenderSliver extends RenderObject {

  _ calculateCacheOffset(/* No info */) {
    // ** addr: 0xbe4790, size: 0xac
    // 0xbe4790: LoadField: d2 = r2->field_13
    //     0xbe4790: ldur            d2, [x2, #0x13]
    // 0xbe4794: LoadField: d3 = r2->field_47
    //     0xbe4794: ldur            d3, [x2, #0x47]
    // 0xbe4798: fadd            d4, d2, d3
    // 0xbe479c: LoadField: d3 = r2->field_4f
    //     0xbe479c: ldur            d3, [x2, #0x4f]
    // 0xbe47a0: fadd            d5, d2, d3
    // 0xbe47a4: fcmp            d4, d1
    // 0xbe47a8: b.le            #0xbe47b4
    // 0xbe47ac: mov             v1.16b, v4.16b
    // 0xbe47b0: b               #0xbe47d0
    // 0xbe47b4: fcmp            d1, d5
    // 0xbe47b8: b.le            #0xbe47c4
    // 0xbe47bc: mov             v1.16b, v5.16b
    // 0xbe47c0: b               #0xbe47d0
    // 0xbe47c4: fcmp            d1, d1
    // 0xbe47c8: b.vc            #0xbe47d0
    // 0xbe47cc: mov             v1.16b, v5.16b
    // 0xbe47d0: fcmp            d4, d0
    // 0xbe47d4: b.gt            #0xbe47fc
    // 0xbe47d8: fcmp            d0, d5
    // 0xbe47dc: b.le            #0xbe47e8
    // 0xbe47e0: mov             v4.16b, v5.16b
    // 0xbe47e4: b               #0xbe47fc
    // 0xbe47e8: fcmp            d0, d0
    // 0xbe47ec: b.vc            #0xbe47f8
    // 0xbe47f0: mov             v4.16b, v5.16b
    // 0xbe47f4: b               #0xbe47fc
    // 0xbe47f8: mov             v4.16b, v0.16b
    // 0xbe47fc: d2 = 0.000000
    //     0xbe47fc: eor             v2.16b, v2.16b, v2.16b
    // 0xbe4800: fsub            d5, d1, d4
    // 0xbe4804: fcmp            d2, d5
    // 0xbe4808: b.le            #0xbe4814
    // 0xbe480c: d0 = 0.000000
    //     0xbe480c: eor             v0.16b, v0.16b, v0.16b
    // 0xbe4810: b               #0xbe4838
    // 0xbe4814: fcmp            d5, d3
    // 0xbe4818: b.le            #0xbe4824
    // 0xbe481c: mov             v0.16b, v3.16b
    // 0xbe4820: b               #0xbe4838
    // 0xbe4824: fcmp            d5, d5
    // 0xbe4828: b.vc            #0xbe4834
    // 0xbe482c: mov             v0.16b, v3.16b
    // 0xbe4830: b               #0xbe4838
    // 0xbe4834: mov             v0.16b, v5.16b
    // 0xbe4838: ret
    //     0xbe4838: ret             
  }
  _ calculatePaintOffset(/* No info */) {
    // ** addr: 0xbe483c, size: 0x9c
    // 0xbe483c: LoadField: d2 = r2->field_13
    //     0xbe483c: ldur            d2, [x2, #0x13]
    // 0xbe4840: LoadField: d3 = r2->field_2b
    //     0xbe4840: ldur            d3, [x2, #0x2b]
    // 0xbe4844: fadd            d4, d2, d3
    // 0xbe4848: fcmp            d2, d1
    // 0xbe484c: b.le            #0xbe4858
    // 0xbe4850: mov             v1.16b, v2.16b
    // 0xbe4854: b               #0xbe4874
    // 0xbe4858: fcmp            d1, d4
    // 0xbe485c: b.le            #0xbe4868
    // 0xbe4860: mov             v1.16b, v4.16b
    // 0xbe4864: b               #0xbe4874
    // 0xbe4868: fcmp            d1, d1
    // 0xbe486c: b.vc            #0xbe4874
    // 0xbe4870: mov             v1.16b, v4.16b
    // 0xbe4874: fcmp            d2, d0
    // 0xbe4878: b.le            #0xbe4884
    // 0xbe487c: mov             v4.16b, v2.16b
    // 0xbe4880: b               #0xbe4898
    // 0xbe4884: fcmp            d0, d4
    // 0xbe4888: b.gt            #0xbe4898
    // 0xbe488c: fcmp            d0, d0
    // 0xbe4890: b.vs            #0xbe4898
    // 0xbe4894: mov             v4.16b, v0.16b
    // 0xbe4898: d2 = 0.000000
    //     0xbe4898: eor             v2.16b, v2.16b, v2.16b
    // 0xbe489c: fsub            d5, d1, d4
    // 0xbe48a0: fcmp            d2, d5
    // 0xbe48a4: b.le            #0xbe48b0
    // 0xbe48a8: d0 = 0.000000
    //     0xbe48a8: eor             v0.16b, v0.16b, v0.16b
    // 0xbe48ac: b               #0xbe48d4
    // 0xbe48b0: fcmp            d5, d3
    // 0xbe48b4: b.le            #0xbe48c0
    // 0xbe48b8: mov             v0.16b, v3.16b
    // 0xbe48bc: b               #0xbe48d4
    // 0xbe48c0: fcmp            d5, d5
    // 0xbe48c4: b.vc            #0xbe48d0
    // 0xbe48c8: mov             v0.16b, v3.16b
    // 0xbe48cc: b               #0xbe48d4
    // 0xbe48d0: mov             v0.16b, v5.16b
    // 0xbe48d4: ret
    //     0xbe48d4: ret             
  }
  get _ paintBounds(/* No info */) {
    // ** addr: 0xbf0350, size: 0x234
    // 0xbf0350: EnterFrame
    //     0xbf0350: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0354: mov             fp, SP
    // 0xbf0358: AllocStack(0x20)
    //     0xbf0358: sub             SP, SP, #0x20
    // 0xbf035c: SetupParameters(RenderSliver this /* r1 => r3, fp-0x10 */)
    //     0xbf035c: mov             x3, x1
    //     0xbf0360: stur            x1, [fp, #-0x10]
    // 0xbf0364: CheckStackOverflow
    //     0xbf0364: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf0368: cmp             SP, x16
    //     0xbf036c: b.ls            #0xbf0574
    // 0xbf0370: LoadField: r4 = r3->field_27
    //     0xbf0370: ldur            w4, [x3, #0x27]
    // 0xbf0374: DecompressPointer r4
    //     0xbf0374: add             x4, x4, HEAP, lsl #32
    // 0xbf0378: stur            x4, [fp, #-8]
    // 0xbf037c: cmp             w4, NULL
    // 0xbf0380: b.eq            #0xbf0518
    // 0xbf0384: mov             x0, x4
    // 0xbf0388: r2 = Null
    //     0xbf0388: mov             x2, NULL
    // 0xbf038c: r1 = Null
    //     0xbf038c: mov             x1, NULL
    // 0xbf0390: r4 = LoadClassIdInstr(r0)
    //     0xbf0390: ldur            x4, [x0, #-1]
    //     0xbf0394: ubfx            x4, x4, #0xc, #0x14
    // 0xbf0398: cmp             x4, #0xb45
    // 0xbf039c: b.eq            #0xbf03b4
    // 0xbf03a0: r8 = SliverConstraints
    //     0xbf03a0: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbf03a4: ldr             x8, [x8, #0x3c0]
    // 0xbf03a8: r3 = Null
    //     0xbf03a8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a0d8] Null
    //     0xbf03ac: ldr             x3, [x3, #0xd8]
    // 0xbf03b0: r0 = DefaultTypeTest()
    //     0xbf03b0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf03b4: ldur            x1, [fp, #-8]
    // 0xbf03b8: r0 = axis()
    //     0xbf03b8: bl              #0xbe5a60  ; [package:flutter/src/rendering/sliver.dart] SliverConstraints::axis
    // 0xbf03bc: LoadField: r1 = r0->field_7
    //     0xbf03bc: ldur            x1, [x0, #7]
    // 0xbf03c0: cmp             x1, #0
    // 0xbf03c4: b.gt            #0xbf0470
    // 0xbf03c8: ldur            x3, [fp, #-0x10]
    // 0xbf03cc: LoadField: r0 = r3->field_47
    //     0xbf03cc: ldur            w0, [x3, #0x47]
    // 0xbf03d0: DecompressPointer r0
    //     0xbf03d0: add             x0, x0, HEAP, lsl #32
    // 0xbf03d4: cmp             w0, NULL
    // 0xbf03d8: b.eq            #0xbf057c
    // 0xbf03dc: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xbf03dc: ldur            d0, [x0, #0x17]
    // 0xbf03e0: stur            d0, [fp, #-0x18]
    // 0xbf03e4: LoadField: r4 = r3->field_27
    //     0xbf03e4: ldur            w4, [x3, #0x27]
    // 0xbf03e8: DecompressPointer r4
    //     0xbf03e8: add             x4, x4, HEAP, lsl #32
    // 0xbf03ec: stur            x4, [fp, #-8]
    // 0xbf03f0: cmp             w4, NULL
    // 0xbf03f4: b.eq            #0xbf0534
    // 0xbf03f8: mov             x0, x4
    // 0xbf03fc: r2 = Null
    //     0xbf03fc: mov             x2, NULL
    // 0xbf0400: r1 = Null
    //     0xbf0400: mov             x1, NULL
    // 0xbf0404: r4 = LoadClassIdInstr(r0)
    //     0xbf0404: ldur            x4, [x0, #-1]
    //     0xbf0408: ubfx            x4, x4, #0xc, #0x14
    // 0xbf040c: cmp             x4, #0xb45
    // 0xbf0410: b.eq            #0xbf0428
    // 0xbf0414: r8 = SliverConstraints
    //     0xbf0414: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbf0418: ldr             x8, [x8, #0x3c0]
    // 0xbf041c: r3 = Null
    //     0xbf041c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a0e8] Null
    //     0xbf0420: ldr             x3, [x3, #0xe8]
    // 0xbf0424: r0 = DefaultTypeTest()
    //     0xbf0424: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf0428: ldur            x0, [fp, #-8]
    // 0xbf042c: LoadField: d0 = r0->field_33
    //     0xbf042c: ldur            d0, [x0, #0x33]
    // 0xbf0430: ldur            d1, [fp, #-0x18]
    // 0xbf0434: d2 = 0.000000
    //     0xbf0434: eor             v2.16b, v2.16b, v2.16b
    // 0xbf0438: fadd            d3, d1, d2
    // 0xbf043c: stur            d3, [fp, #-0x20]
    // 0xbf0440: fadd            d1, d0, d2
    // 0xbf0444: stur            d1, [fp, #-0x18]
    // 0xbf0448: r0 = Rect()
    //     0xbf0448: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbf044c: StoreField: r0->field_7 = rZR
    //     0xbf044c: stur            xzr, [x0, #7]
    // 0xbf0450: StoreField: r0->field_f = rZR
    //     0xbf0450: stur            xzr, [x0, #0xf]
    // 0xbf0454: ldur            d0, [fp, #-0x20]
    // 0xbf0458: ArrayStore: r0[0] = d0  ; List_8
    //     0xbf0458: stur            d0, [x0, #0x17]
    // 0xbf045c: ldur            d0, [fp, #-0x18]
    // 0xbf0460: StoreField: r0->field_1f = d0
    //     0xbf0460: stur            d0, [x0, #0x1f]
    // 0xbf0464: LeaveFrame
    //     0xbf0464: mov             SP, fp
    //     0xbf0468: ldp             fp, lr, [SP], #0x10
    // 0xbf046c: ret
    //     0xbf046c: ret             
    // 0xbf0470: ldur            x3, [fp, #-0x10]
    // 0xbf0474: d2 = 0.000000
    //     0xbf0474: eor             v2.16b, v2.16b, v2.16b
    // 0xbf0478: LoadField: r4 = r3->field_27
    //     0xbf0478: ldur            w4, [x3, #0x27]
    // 0xbf047c: DecompressPointer r4
    //     0xbf047c: add             x4, x4, HEAP, lsl #32
    // 0xbf0480: stur            x4, [fp, #-8]
    // 0xbf0484: cmp             w4, NULL
    // 0xbf0488: b.eq            #0xbf0554
    // 0xbf048c: mov             x0, x4
    // 0xbf0490: r2 = Null
    //     0xbf0490: mov             x2, NULL
    // 0xbf0494: r1 = Null
    //     0xbf0494: mov             x1, NULL
    // 0xbf0498: r4 = LoadClassIdInstr(r0)
    //     0xbf0498: ldur            x4, [x0, #-1]
    //     0xbf049c: ubfx            x4, x4, #0xc, #0x14
    // 0xbf04a0: cmp             x4, #0xb45
    // 0xbf04a4: b.eq            #0xbf04bc
    // 0xbf04a8: r8 = SliverConstraints
    //     0xbf04a8: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xbf04ac: ldr             x8, [x8, #0x3c0]
    // 0xbf04b0: r3 = Null
    //     0xbf04b0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a0f8] Null
    //     0xbf04b4: ldr             x3, [x3, #0xf8]
    // 0xbf04b8: r0 = DefaultTypeTest()
    //     0xbf04b8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf04bc: ldur            x0, [fp, #-8]
    // 0xbf04c0: LoadField: d0 = r0->field_33
    //     0xbf04c0: ldur            d0, [x0, #0x33]
    // 0xbf04c4: ldur            x0, [fp, #-0x10]
    // 0xbf04c8: LoadField: r1 = r0->field_47
    //     0xbf04c8: ldur            w1, [x0, #0x47]
    // 0xbf04cc: DecompressPointer r1
    //     0xbf04cc: add             x1, x1, HEAP, lsl #32
    // 0xbf04d0: cmp             w1, NULL
    // 0xbf04d4: b.eq            #0xbf0580
    // 0xbf04d8: ArrayLoad: d1 = r1[0]  ; List_8
    //     0xbf04d8: ldur            d1, [x1, #0x17]
    // 0xbf04dc: d2 = 0.000000
    //     0xbf04dc: eor             v2.16b, v2.16b, v2.16b
    // 0xbf04e0: fadd            d3, d0, d2
    // 0xbf04e4: stur            d3, [fp, #-0x20]
    // 0xbf04e8: fadd            d0, d1, d2
    // 0xbf04ec: stur            d0, [fp, #-0x18]
    // 0xbf04f0: r0 = Rect()
    //     0xbf04f0: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbf04f4: StoreField: r0->field_7 = rZR
    //     0xbf04f4: stur            xzr, [x0, #7]
    // 0xbf04f8: StoreField: r0->field_f = rZR
    //     0xbf04f8: stur            xzr, [x0, #0xf]
    // 0xbf04fc: ldur            d0, [fp, #-0x20]
    // 0xbf0500: ArrayStore: r0[0] = d0  ; List_8
    //     0xbf0500: stur            d0, [x0, #0x17]
    // 0xbf0504: ldur            d0, [fp, #-0x18]
    // 0xbf0508: StoreField: r0->field_1f = d0
    //     0xbf0508: stur            d0, [x0, #0x1f]
    // 0xbf050c: LeaveFrame
    //     0xbf050c: mov             SP, fp
    //     0xbf0510: ldp             fp, lr, [SP], #0x10
    // 0xbf0514: ret
    //     0xbf0514: ret             
    // 0xbf0518: r0 = StateError()
    //     0xbf0518: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbf051c: mov             x1, x0
    // 0xbf0520: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbf0520: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbf0524: StoreField: r1->field_b = r0
    //     0xbf0524: stur            w0, [x1, #0xb]
    // 0xbf0528: mov             x0, x1
    // 0xbf052c: r0 = Throw()
    //     0xbf052c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbf0530: brk             #0
    // 0xbf0534: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbf0534: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbf0538: r0 = StateError()
    //     0xbf0538: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbf053c: mov             x1, x0
    // 0xbf0540: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbf0540: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbf0544: StoreField: r1->field_b = r0
    //     0xbf0544: stur            w0, [x1, #0xb]
    // 0xbf0548: mov             x0, x1
    // 0xbf054c: r0 = Throw()
    //     0xbf054c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbf0550: brk             #0
    // 0xbf0554: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbf0554: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbf0558: r0 = StateError()
    //     0xbf0558: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbf055c: mov             x1, x0
    // 0xbf0560: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbf0560: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbf0564: StoreField: r1->field_b = r0
    //     0xbf0564: stur            w0, [x1, #0xb]
    // 0xbf0568: mov             x0, x1
    // 0xbf056c: r0 = Throw()
    //     0xbf056c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbf0570: brk             #0
    // 0xbf0574: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf0574: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf0578: b               #0xbf0370
    // 0xbf057c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf057c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf0580: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbf0580: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ semanticBounds(/* No info */) {
    // ** addr: 0xbf2a34, size: 0x2c
    // 0xbf2a34: EnterFrame
    //     0xbf2a34: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2a38: mov             fp, SP
    // 0xbf2a3c: CheckStackOverflow
    //     0xbf2a3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf2a40: cmp             SP, x16
    //     0xbf2a44: b.ls            #0xbf2a58
    // 0xbf2a48: r0 = paintBounds()
    //     0xbf2a48: bl              #0xbf0350  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::paintBounds
    // 0xbf2a4c: LeaveFrame
    //     0xbf2a4c: mov             SP, fp
    //     0xbf2a50: ldp             fp, lr, [SP], #0x10
    // 0xbf2a54: ret
    //     0xbf2a54: ret             
    // 0xbf2a58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf2a58: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf2a5c: b               #0xbf2a48
  }
  get _ constraints(/* No info */) {
    // ** addr: 0xccea28, size: 0x7c
    // 0xccea28: EnterFrame
    //     0xccea28: stp             fp, lr, [SP, #-0x10]!
    //     0xccea2c: mov             fp, SP
    // 0xccea30: AllocStack(0x8)
    //     0xccea30: sub             SP, SP, #8
    // 0xccea34: LoadField: r3 = r1->field_27
    //     0xccea34: ldur            w3, [x1, #0x27]
    // 0xccea38: DecompressPointer r3
    //     0xccea38: add             x3, x3, HEAP, lsl #32
    // 0xccea3c: stur            x3, [fp, #-8]
    // 0xccea40: cmp             w3, NULL
    // 0xccea44: b.eq            #0xccea88
    // 0xccea48: mov             x0, x3
    // 0xccea4c: r2 = Null
    //     0xccea4c: mov             x2, NULL
    // 0xccea50: r1 = Null
    //     0xccea50: mov             x1, NULL
    // 0xccea54: r4 = LoadClassIdInstr(r0)
    //     0xccea54: ldur            x4, [x0, #-1]
    //     0xccea58: ubfx            x4, x4, #0xc, #0x14
    // 0xccea5c: cmp             x4, #0xb45
    // 0xccea60: b.eq            #0xccea78
    // 0xccea64: r8 = SliverConstraints
    //     0xccea64: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xccea68: ldr             x8, [x8, #0x3c0]
    // 0xccea6c: r3 = Null
    //     0xccea6c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a108] Null
    //     0xccea70: ldr             x3, [x3, #0x108]
    // 0xccea74: r0 = DefaultTypeTest()
    //     0xccea74: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xccea78: ldur            x0, [fp, #-8]
    // 0xccea7c: LeaveFrame
    //     0xccea7c: mov             SP, fp
    //     0xccea80: ldp             fp, lr, [SP], #0x10
    // 0xccea84: ret
    //     0xccea84: ret             
    // 0xccea88: r0 = StateError()
    //     0xccea88: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccea8c: mov             x1, x0
    // 0xccea90: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xccea90: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xccea94: StoreField: r1->field_b = r0
    //     0xccea94: stur            w0, [x1, #0xb]
    // 0xccea98: mov             x0, x1
    // 0xccea9c: r0 = Throw()
    //     0xccea9c: bl              #0x13ddb2c  ; ThrowStub
    // 0xcceaa0: brk             #0
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xcdd3bc, size: 0x58
    // 0xcdd3bc: EnterFrame
    //     0xcdd3bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcdd3c0: mov             fp, SP
    // 0xcdd3c4: mov             x0, x3
    // 0xcdd3c8: mov             x5, x1
    // 0xcdd3cc: mov             x4, x2
    // 0xcdd3d0: r2 = Null
    //     0xcdd3d0: mov             x2, NULL
    // 0xcdd3d4: r1 = Null
    //     0xcdd3d4: mov             x1, NULL
    // 0xcdd3d8: r4 = 60
    //     0xcdd3d8: mov             x4, #0x3c
    // 0xcdd3dc: branchIfSmi(r0, 0xcdd3e8)
    //     0xcdd3dc: tbz             w0, #0, #0xcdd3e8
    // 0xcdd3e0: r4 = LoadClassIdInstr(r0)
    //     0xcdd3e0: ldur            x4, [x0, #-1]
    //     0xcdd3e4: ubfx            x4, x4, #0xc, #0x14
    // 0xcdd3e8: cmp             x4, #0xc64
    // 0xcdd3ec: b.eq            #0xcdd404
    // 0xcdd3f0: r8 = SliverHitTestEntry
    //     0xcdd3f0: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a0c0] Type: SliverHitTestEntry
    //     0xcdd3f4: ldr             x8, [x8, #0xc0]
    // 0xcdd3f8: r3 = Null
    //     0xcdd3f8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a0c8] Null
    //     0xcdd3fc: ldr             x3, [x3, #0xc8]
    // 0xcdd400: r0 = DefaultTypeTest()
    //     0xcdd400: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcdd404: r0 = Null
    //     0xcdd404: mov             x0, NULL
    // 0xcdd408: LeaveFrame
    //     0xcdd408: mov             SP, fp
    //     0xcdd40c: ldp             fp, lr, [SP], #0x10
    // 0xcdd410: ret
    //     0xcdd410: ret             
  }
  bool hitTest(RenderSliver, SliverHitTestResult, {required double mainAxisPosition, required double crossAxisPosition}) {
    // ** addr: 0x10eb6cc, size: 0x18c
    // 0x10eb6cc: EnterFrame
    //     0x10eb6cc: stp             fp, lr, [SP, #-0x10]!
    //     0x10eb6d0: mov             fp, SP
    // 0x10eb6d4: AllocStack(0x28)
    //     0x10eb6d4: sub             SP, SP, #0x28
    // 0x10eb6d8: d0 = 0.000000
    //     0x10eb6d8: eor             v0.16b, v0.16b, v0.16b
    // 0x10eb6dc: mov             x5, x1
    // 0x10eb6e0: mov             x3, x2
    // 0x10eb6e4: stur            x1, [fp, #-0x10]
    // 0x10eb6e8: stur            x2, [fp, #-0x18]
    // 0x10eb6ec: LoadField: r0 = r4->field_13
    //     0x10eb6ec: ldur            w0, [x4, #0x13]
    // 0x10eb6f0: LoadField: r1 = r4->field_23
    //     0x10eb6f0: ldur            w1, [x4, #0x23]
    // 0x10eb6f4: DecompressPointer r1
    //     0x10eb6f4: add             x1, x1, HEAP, lsl #32
    // 0x10eb6f8: sub             w2, w0, w1
    // 0x10eb6fc: add             x1, fp, w2, sxtw #2
    // 0x10eb700: ldr             x1, [x1, #8]
    // 0x10eb704: LoadField: r2 = r4->field_2b
    //     0x10eb704: ldur            w2, [x4, #0x2b]
    // 0x10eb708: DecompressPointer r2
    //     0x10eb708: add             x2, x2, HEAP, lsl #32
    // 0x10eb70c: sub             w4, w0, w2
    // 0x10eb710: add             x0, fp, w4, sxtw #2
    // 0x10eb714: ldr             x0, [x0, #8]
    // 0x10eb718: CheckStackOverflow
    //     0x10eb718: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb71c: cmp             SP, x16
    //     0x10eb720: b.ls            #0x10eb84c
    // 0x10eb724: LoadField: d1 = r0->field_7
    //     0x10eb724: ldur            d1, [x0, #7]
    // 0x10eb728: stur            d1, [fp, #-0x28]
    // 0x10eb72c: fcmp            d1, d0
    // 0x10eb730: b.lt            #0x10eb820
    // 0x10eb734: LoadField: r0 = r5->field_47
    //     0x10eb734: ldur            w0, [x5, #0x47]
    // 0x10eb738: DecompressPointer r0
    //     0x10eb738: add             x0, x0, HEAP, lsl #32
    // 0x10eb73c: cmp             w0, NULL
    // 0x10eb740: b.eq            #0x10eb854
    // 0x10eb744: LoadField: d2 = r0->field_37
    //     0x10eb744: ldur            d2, [x0, #0x37]
    // 0x10eb748: fcmp            d2, d1
    // 0x10eb74c: b.le            #0x10eb820
    // 0x10eb750: LoadField: d2 = r1->field_7
    //     0x10eb750: ldur            d2, [x1, #7]
    // 0x10eb754: stur            d2, [fp, #-0x20]
    // 0x10eb758: fcmp            d2, d0
    // 0x10eb75c: b.lt            #0x10eb820
    // 0x10eb760: LoadField: r4 = r5->field_27
    //     0x10eb760: ldur            w4, [x5, #0x27]
    // 0x10eb764: DecompressPointer r4
    //     0x10eb764: add             x4, x4, HEAP, lsl #32
    // 0x10eb768: stur            x4, [fp, #-8]
    // 0x10eb76c: cmp             w4, NULL
    // 0x10eb770: b.eq            #0x10eb830
    // 0x10eb774: mov             x0, x4
    // 0x10eb778: r2 = Null
    //     0x10eb778: mov             x2, NULL
    // 0x10eb77c: r1 = Null
    //     0x10eb77c: mov             x1, NULL
    // 0x10eb780: r4 = LoadClassIdInstr(r0)
    //     0x10eb780: ldur            x4, [x0, #-1]
    //     0x10eb784: ubfx            x4, x4, #0xc, #0x14
    // 0x10eb788: cmp             x4, #0xb45
    // 0x10eb78c: b.eq            #0x10eb7a4
    // 0x10eb790: r8 = SliverConstraints
    //     0x10eb790: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x10eb794: ldr             x8, [x8, #0x3c0]
    // 0x10eb798: r3 = Null
    //     0x10eb798: add             x3, PP, #0x96, lsl #12  ; [pp+0x96440] Null
    //     0x10eb79c: ldr             x3, [x3, #0x440]
    // 0x10eb7a0: r0 = DefaultTypeTest()
    //     0x10eb7a0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10eb7a4: ldur            x0, [fp, #-8]
    // 0x10eb7a8: LoadField: d0 = r0->field_33
    //     0x10eb7a8: ldur            d0, [x0, #0x33]
    // 0x10eb7ac: ldur            d1, [fp, #-0x20]
    // 0x10eb7b0: fcmp            d0, d1
    // 0x10eb7b4: b.le            #0x10eb820
    // 0x10eb7b8: ldur            x3, [fp, #-0x10]
    // 0x10eb7bc: r0 = LoadClassIdInstr(r3)
    //     0x10eb7bc: ldur            x0, [x3, #-1]
    //     0x10eb7c0: ubfx            x0, x0, #0xc, #0x14
    // 0x10eb7c4: mov             x1, x3
    // 0x10eb7c8: ldur            x2, [fp, #-0x18]
    // 0x10eb7cc: mov             v0.16b, v1.16b
    // 0x10eb7d0: ldur            d1, [fp, #-0x28]
    // 0x10eb7d4: r0 = GDT[cid_x0 + 0x7084]()
    //     0x10eb7d4: mov             x17, #0x7084
    //     0x10eb7d8: add             lr, x0, x17
    //     0x10eb7dc: ldr             lr, [x21, lr, lsl #3]
    //     0x10eb7e0: blr             lr
    // 0x10eb7e4: tbnz            w0, #4, #0x10eb820
    // 0x10eb7e8: ldur            x0, [fp, #-0x10]
    // 0x10eb7ec: r1 = <RenderSliver>
    //     0x10eb7ec: add             x1, PP, #0x96, lsl #12  ; [pp+0x96450] TypeArguments: <RenderSliver>
    //     0x10eb7f0: ldr             x1, [x1, #0x450]
    // 0x10eb7f4: r0 = SliverHitTestEntry()
    //     0x10eb7f4: bl              #0x10eb8e4  ; AllocateSliverHitTestEntryStub -> SliverHitTestEntry (size=0x14)
    // 0x10eb7f8: mov             x1, x0
    // 0x10eb7fc: ldur            x0, [fp, #-0x10]
    // 0x10eb800: StoreField: r1->field_b = r0
    //     0x10eb800: stur            w0, [x1, #0xb]
    // 0x10eb804: mov             x2, x1
    // 0x10eb808: ldur            x1, [fp, #-0x18]
    // 0x10eb80c: r0 = add()
    //     0x10eb80c: bl              #0x836754  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x10eb810: r0 = true
    //     0x10eb810: add             x0, NULL, #0x20  ; true
    // 0x10eb814: LeaveFrame
    //     0x10eb814: mov             SP, fp
    //     0x10eb818: ldp             fp, lr, [SP], #0x10
    // 0x10eb81c: ret
    //     0x10eb81c: ret             
    // 0x10eb820: r0 = false
    //     0x10eb820: add             x0, NULL, #0x30  ; false
    // 0x10eb824: LeaveFrame
    //     0x10eb824: mov             SP, fp
    //     0x10eb828: ldp             fp, lr, [SP], #0x10
    // 0x10eb82c: ret
    //     0x10eb82c: ret             
    // 0x10eb830: r0 = StateError()
    //     0x10eb830: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x10eb834: mov             x1, x0
    // 0x10eb838: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x10eb838: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x10eb83c: StoreField: r1->field_b = r0
    //     0x10eb83c: stur            w0, [x1, #0xb]
    // 0x10eb840: mov             x0, x1
    // 0x10eb844: r0 = Throw()
    //     0x10eb844: bl              #0x13ddb2c  ; ThrowStub
    // 0x10eb848: brk             #0
    // 0x10eb84c: r0 = StackOverflowSharedWithFPURegs()
    //     0x10eb84c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10eb850: b               #0x10eb724
    // 0x10eb854: r0 = NullCastErrorSharedWithFPURegs()
    //     0x10eb854: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] bool hitTest(dynamic, SliverHitTestResult, {required double mainAxisPosition, required double crossAxisPosition}) {
    // ** addr: 0x10eb858, size: 0x8c
    // 0x10eb858: EnterFrame
    //     0x10eb858: stp             fp, lr, [SP, #-0x10]!
    //     0x10eb85c: mov             fp, SP
    // 0x10eb860: AllocStack(0x10)
    //     0x10eb860: sub             SP, SP, #0x10
    // 0x10eb864: SetupParameters(RenderSliver this /* r2 */, dynamic _ /* r3 */, {dynamic required /* r1 */, dynamic required /* r0 */})
    //     0x10eb864: ldur            w0, [x4, #0x13]
    //     0x10eb868: sub             x1, x0, #4
    //     0x10eb86c: add             x2, fp, w1, sxtw #2
    //     0x10eb870: ldr             x2, [x2, #0x18]
    //     0x10eb874: add             x3, fp, w1, sxtw #2
    //     0x10eb878: ldr             x3, [x3, #0x10]
    //     0x10eb87c: ldur            w1, [x4, #0x23]
    //     0x10eb880: add             x1, x1, HEAP, lsl #32
    //     0x10eb884: sub             w5, w0, w1
    //     0x10eb888: add             x1, fp, w5, sxtw #2
    //     0x10eb88c: ldr             x1, [x1, #8]
    //     0x10eb890: ldur            w5, [x4, #0x2b]
    //     0x10eb894: add             x5, x5, HEAP, lsl #32
    //     0x10eb898: sub             w4, w0, w5
    //     0x10eb89c: add             x0, fp, w4, sxtw #2
    //     0x10eb8a0: ldr             x0, [x0, #8]
    //     0x10eb8a4: ldur            w4, [x2, #0x17]
    //     0x10eb8a8: add             x4, x4, HEAP, lsl #32
    // 0x10eb8ac: CheckStackOverflow
    //     0x10eb8ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb8b0: cmp             SP, x16
    //     0x10eb8b4: b.ls            #0x10eb8dc
    // 0x10eb8b8: stp             x1, x0, [SP]
    // 0x10eb8bc: mov             x1, x4
    // 0x10eb8c0: mov             x2, x3
    // 0x10eb8c4: r4 = const [0, 0x4, 0x2, 0x2, crossAxisPosition, 0x3, mainAxisPosition, 0x2, null]
    //     0x10eb8c4: add             x4, PP, #0x96, lsl #12  ; [pp+0x96438] List(9) [0, 0x4, 0x2, 0x2, "crossAxisPosition", 0x3, "mainAxisPosition", 0x2, Null]
    //     0x10eb8c8: ldr             x4, [x4, #0x438]
    // 0x10eb8cc: r0 = hitTest()
    //     0x10eb8cc: bl              #0x10eb6cc  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::hitTest
    // 0x10eb8d0: LeaveFrame
    //     0x10eb8d0: mov             SP, fp
    //     0x10eb8d4: ldp             fp, lr, [SP], #0x10
    // 0x10eb8d8: ret
    //     0x10eb8d8: ret             
    // 0x10eb8dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eb8dc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eb8e0: b               #0x10eb8b8
  }
  dynamic hitTest(dynamic) {
    // ** addr: 0x1159e28, size: 0x24
    // 0x1159e28: EnterFrame
    //     0x1159e28: stp             fp, lr, [SP, #-0x10]!
    //     0x1159e2c: mov             fp, SP
    // 0x1159e30: ldr             x2, [fp, #0x10]
    // 0x1159e34: r1 = Function 'hitTest':.
    //     0x1159e34: add             x1, PP, #0xad, lsl #12  ; [pp+0xadf10] AnonymousClosure: (0x10eb858), in [package:flutter/src/rendering/sliver.dart] RenderSliver::hitTest (0x10eb6cc)
    //     0x1159e38: ldr             x1, [x1, #0xf10]
    // 0x1159e3c: r0 = AllocateClosure()
    //     0x1159e3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1159e40: LeaveFrame
    //     0x1159e40: mov             SP, fp
    //     0x1159e44: ldp             fp, lr, [SP], #0x10
    // 0x1159e48: ret
    //     0x1159e48: ret             
  }
}

// class id: 5036, size: 0x58, field offset: 0x8
//   const constructor, 
class SliverGeometry extends _MixinApplication3&Object&Diagnosticable {

  _Mint field_8;
  _Mint field_10;
  _Mint field_18;
  _Mint field_20;
  _Mint field_28;
  _Mint field_30;
  _Mint field_38;
  bool field_40;
  bool field_44;
  _Mint field_4c;
}

// class id: 8221, size: 0x14, field offset: 0x14
enum GrowthDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab228, size: 0x64
    // 0x11ab228: EnterFrame
    //     0x11ab228: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab22c: mov             fp, SP
    // 0x11ab230: AllocStack(0x10)
    //     0x11ab230: sub             SP, SP, #0x10
    // 0x11ab234: SetupParameters(GrowthDirection this /* r1 => r0, fp-0x8 */)
    //     0x11ab234: mov             x0, x1
    //     0x11ab238: stur            x1, [fp, #-8]
    // 0x11ab23c: CheckStackOverflow
    //     0x11ab23c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab240: cmp             SP, x16
    //     0x11ab244: b.ls            #0x11ab284
    // 0x11ab248: r1 = Null
    //     0x11ab248: mov             x1, NULL
    // 0x11ab24c: r2 = 4
    //     0x11ab24c: mov             x2, #4
    // 0x11ab250: r0 = AllocateArray()
    //     0x11ab250: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab254: r16 = "GrowthDirection."
    //     0x11ab254: add             x16, PP, #0xa4, lsl #12  ; [pp+0xa4130] "GrowthDirection."
    //     0x11ab258: ldr             x16, [x16, #0x130]
    // 0x11ab25c: StoreField: r0->field_f = r16
    //     0x11ab25c: stur            w16, [x0, #0xf]
    // 0x11ab260: ldur            x1, [fp, #-8]
    // 0x11ab264: LoadField: r2 = r1->field_f
    //     0x11ab264: ldur            w2, [x1, #0xf]
    // 0x11ab268: DecompressPointer r2
    //     0x11ab268: add             x2, x2, HEAP, lsl #32
    // 0x11ab26c: StoreField: r0->field_13 = r2
    //     0x11ab26c: stur            w2, [x0, #0x13]
    // 0x11ab270: str             x0, [SP]
    // 0x11ab274: r0 = _interpolate()
    //     0x11ab274: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab278: LeaveFrame
    //     0x11ab278: mov             SP, fp
    //     0x11ab27c: ldp             fp, lr, [SP], #0x10
    // 0x11ab280: ret
    //     0x11ab280: ret             
    // 0x11ab284: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab284: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab288: b               #0x11ab248
  }
}
