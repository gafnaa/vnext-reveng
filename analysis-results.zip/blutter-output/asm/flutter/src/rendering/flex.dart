// lib: , url: package:flutter/src/rendering/flex.dart

// class id: 1049027, size: 0x8
class :: {

  static _ _AxisSize.applyConstraints(/* No info */) {
    // ** addr: 0xb18ad0, size: 0x5c
    // 0xb18ad0: EnterFrame
    //     0xb18ad0: stp             fp, lr, [SP, #-0x10]!
    //     0xb18ad4: mov             fp, SP
    // 0xb18ad8: AllocStack(0x8)
    //     0xb18ad8: sub             SP, SP, #8
    // 0xb18adc: SetupParameters(dynamic _ /* r1 => r0, fp-0x8 */)
    //     0xb18adc: mov             x0, x1
    //     0xb18ae0: stur            x1, [fp, #-8]
    // 0xb18ae4: CheckStackOverflow
    //     0xb18ae4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb18ae8: cmp             SP, x16
    //     0xb18aec: b.ls            #0xb18b24
    // 0xb18af0: LoadField: r1 = r3->field_7
    //     0xb18af0: ldur            x1, [x3, #7]
    // 0xb18af4: cmp             x1, #0
    // 0xb18af8: b.gt            #0xb18b04
    // 0xb18afc: mov             x1, x2
    // 0xb18b00: b               #0xb18b10
    // 0xb18b04: mov             x1, x2
    // 0xb18b08: r0 = flipped()
    //     0xb18b08: bl              #0xb18b2c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::flipped
    // 0xb18b0c: mov             x1, x0
    // 0xb18b10: ldur            x2, [fp, #-8]
    // 0xb18b14: r0 = constrain()
    //     0xb18b14: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb18b18: LeaveFrame
    //     0xb18b18: mov             SP, fp
    //     0xb18b1c: ldp             fp, lr, [SP], #0x10
    // 0xb18b20: ret
    //     0xb18b20: ret             
    // 0xb18b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb18b24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb18b28: b               #0xb18af0
  }
  static _ _AxisSize.+(/* No info */) {
    // ** addr: 0xb18b88, size: 0x4c
    // 0xb18b88: EnterFrame
    //     0xb18b88: stp             fp, lr, [SP, #-0x10]!
    //     0xb18b8c: mov             fp, SP
    // 0xb18b90: AllocStack(0x10)
    //     0xb18b90: sub             SP, SP, #0x10
    // 0xb18b94: LoadField: d0 = r1->field_7
    //     0xb18b94: ldur            d0, [x1, #7]
    // 0xb18b98: LoadField: d1 = r2->field_7
    //     0xb18b98: ldur            d1, [x2, #7]
    // 0xb18b9c: fadd            d2, d0, d1
    // 0xb18ba0: stur            d2, [fp, #-0x10]
    // 0xb18ba4: LoadField: d0 = r1->field_f
    //     0xb18ba4: ldur            d0, [x1, #0xf]
    // 0xb18ba8: LoadField: d1 = r2->field_f
    //     0xb18ba8: ldur            d1, [x2, #0xf]
    // 0xb18bac: fmax            v3.2d, v0.2d, v1.2d
    // 0xb18bb0: stur            d3, [fp, #-8]
    // 0xb18bb4: r0 = Size()
    //     0xb18bb4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb18bb8: ldur            d0, [fp, #-0x10]
    // 0xb18bbc: StoreField: r0->field_7 = d0
    //     0xb18bbc: stur            d0, [x0, #7]
    // 0xb18bc0: ldur            d0, [fp, #-8]
    // 0xb18bc4: StoreField: r0->field_f = d0
    //     0xb18bc4: stur            d0, [x0, #0xf]
    // 0xb18bc8: LeaveFrame
    //     0xb18bc8: mov             SP, fp
    //     0xb18bcc: ldp             fp, lr, [SP], #0x10
    // 0xb18bd0: ret
    //     0xb18bd0: ret             
  }
  static _ _AxisSize.(/* No info */) {
    // ** addr: 0xb18bd4, size: 0x34
    // 0xb18bd4: EnterFrame
    //     0xb18bd4: stp             fp, lr, [SP, #-0x10]!
    //     0xb18bd8: mov             fp, SP
    // 0xb18bdc: AllocStack(0x10)
    //     0xb18bdc: sub             SP, SP, #0x10
    // 0xb18be0: SetupParameters(dynamic _ /* d0 => d0, fp-0x8 */, dynamic _ /* d1 => d1, fp-0x10 */)
    //     0xb18be0: stur            d0, [fp, #-8]
    //     0xb18be4: stur            d1, [fp, #-0x10]
    // 0xb18be8: r0 = Size()
    //     0xb18be8: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb18bec: ldur            d0, [fp, #-0x10]
    // 0xb18bf0: StoreField: r0->field_7 = d0
    //     0xb18bf0: stur            d0, [x0, #7]
    // 0xb18bf4: ldur            d0, [fp, #-8]
    // 0xb18bf8: StoreField: r0->field_f = d0
    //     0xb18bf8: stur            d0, [x0, #0xf]
    // 0xb18bfc: LeaveFrame
    //     0xb18bfc: mov             SP, fp
    //     0xb18c00: ldp             fp, lr, [SP], #0x10
    // 0xb18c04: ret
    //     0xb18c04: ret             
  }
  static _ _AscentDescent.+(/* No info */) {
    // ** addr: 0xb18dec, size: 0x3f0
    // 0xb18dec: EnterFrame
    //     0xb18dec: stp             fp, lr, [SP, #-0x10]!
    //     0xb18df0: mov             fp, SP
    // 0xb18df4: AllocStack(0x30)
    //     0xb18df4: sub             SP, SP, #0x30
    // 0xb18df8: CheckStackOverflow
    //     0xb18df8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb18dfc: cmp             SP, x16
    //     0xb18e00: b.ls            #0xb191b4
    // 0xb18e04: cmp             w1, NULL
    // 0xb18e08: b.ne            #0xb18e74
    // 0xb18e0c: cmp             w2, NULL
    // 0xb18e10: b.eq            #0xb18e60
    // 0xb18e14: LoadField: r0 = r2->field_b
    //     0xb18e14: ldur            w0, [x2, #0xb]
    // 0xb18e18: cmp             w0, #4
    // 0xb18e1c: b.ne            #0xb18e68
    // 0xb18e20: LoadField: r0 = r2->field_f
    //     0xb18e20: ldur            w0, [x2, #0xf]
    // 0xb18e24: DecompressPointer r0
    //     0xb18e24: add             x0, x0, HEAP, lsl #32
    // 0xb18e28: r3 = 60
    //     0xb18e28: mov             x3, #0x3c
    // 0xb18e2c: branchIfSmi(r0, 0xb18e38)
    //     0xb18e2c: tbz             w0, #0, #0xb18e38
    // 0xb18e30: r3 = LoadClassIdInstr(r0)
    //     0xb18e30: ldur            x3, [x0, #-1]
    //     0xb18e34: ubfx            x3, x3, #0xc, #0x14
    // 0xb18e38: cmp             x3, #0x3e
    // 0xb18e3c: b.ne            #0xb18e68
    // 0xb18e40: LoadField: r0 = r2->field_13
    //     0xb18e40: ldur            w0, [x2, #0x13]
    // 0xb18e44: DecompressPointer r0
    //     0xb18e44: add             x0, x0, HEAP, lsl #32
    // 0xb18e48: r3 = 60
    //     0xb18e48: mov             x3, #0x3c
    // 0xb18e4c: branchIfSmi(r0, 0xb18e58)
    //     0xb18e4c: tbz             w0, #0, #0xb18e58
    // 0xb18e50: r3 = LoadClassIdInstr(r0)
    //     0xb18e50: ldur            x3, [x0, #-1]
    //     0xb18e54: ubfx            x3, x3, #0xc, #0x14
    // 0xb18e58: cmp             x3, #0x3e
    // 0xb18e5c: b.ne            #0xb18e68
    // 0xb18e60: mov             x0, x2
    // 0xb18e64: b               #0xb191a8
    // 0xb18e68: mov             x3, x2
    // 0xb18e6c: r0 = true
    //     0xb18e6c: add             x0, NULL, #0x20  ; true
    // 0xb18e70: b               #0xb18e7c
    // 0xb18e74: r3 = Null
    //     0xb18e74: mov             x3, NULL
    // 0xb18e78: r0 = false
    //     0xb18e78: add             x0, NULL, #0x30  ; false
    // 0xb18e7c: cmp             w1, NULL
    // 0xb18e80: b.eq            #0xb18ed0
    // 0xb18e84: LoadField: r4 = r1->field_b
    //     0xb18e84: ldur            w4, [x1, #0xb]
    // 0xb18e88: cmp             w4, #4
    // 0xb18e8c: b.ne            #0xb18efc
    // 0xb18e90: LoadField: r4 = r1->field_f
    //     0xb18e90: ldur            w4, [x1, #0xf]
    // 0xb18e94: DecompressPointer r4
    //     0xb18e94: add             x4, x4, HEAP, lsl #32
    // 0xb18e98: r5 = 60
    //     0xb18e98: mov             x5, #0x3c
    // 0xb18e9c: branchIfSmi(r4, 0xb18ea8)
    //     0xb18e9c: tbz             w4, #0, #0xb18ea8
    // 0xb18ea0: r5 = LoadClassIdInstr(r4)
    //     0xb18ea0: ldur            x5, [x4, #-1]
    //     0xb18ea4: ubfx            x5, x5, #0xc, #0x14
    // 0xb18ea8: cmp             x5, #0x3e
    // 0xb18eac: b.ne            #0xb18efc
    // 0xb18eb0: LoadField: r4 = r1->field_13
    //     0xb18eb0: ldur            w4, [x1, #0x13]
    // 0xb18eb4: DecompressPointer r4
    //     0xb18eb4: add             x4, x4, HEAP, lsl #32
    // 0xb18eb8: r5 = 60
    //     0xb18eb8: mov             x5, #0x3c
    // 0xb18ebc: branchIfSmi(r4, 0xb18ec8)
    //     0xb18ebc: tbz             w4, #0, #0xb18ec8
    // 0xb18ec0: r5 = LoadClassIdInstr(r4)
    //     0xb18ec0: ldur            x5, [x4, #-1]
    //     0xb18ec4: ubfx            x5, x5, #0xc, #0x14
    // 0xb18ec8: cmp             x5, #0x3e
    // 0xb18ecc: b.ne            #0xb18efc
    // 0xb18ed0: tbnz            w0, #4, #0xb18edc
    // 0xb18ed4: mov             x0, x3
    // 0xb18ed8: b               #0xb18ee4
    // 0xb18edc: mov             x3, x2
    // 0xb18ee0: mov             x0, x2
    // 0xb18ee4: cmp             w3, NULL
    // 0xb18ee8: b.ne            #0xb18ef4
    // 0xb18eec: mov             x0, x1
    // 0xb18ef0: b               #0xb191a8
    // 0xb18ef4: mov             x3, x0
    // 0xb18ef8: r0 = true
    //     0xb18ef8: add             x0, NULL, #0x20  ; true
    // 0xb18efc: r4 = LoadClassIdInstr(r1)
    //     0xb18efc: ldur            x4, [x1, #-1]
    //     0xb18f00: ubfx            x4, x4, #0xc, #0x14
    // 0xb18f04: lsl             x4, x4, #1
    // 0xb18f08: cmp             w4, #0x86
    // 0xb18f0c: b.ne            #0xb191a4
    // 0xb18f10: LoadField: r4 = r1->field_b
    //     0xb18f10: ldur            w4, [x1, #0xb]
    // 0xb18f14: cmp             w4, #4
    // 0xb18f18: b.ne            #0xb191a4
    // 0xb18f1c: LoadField: r4 = r1->field_f
    //     0xb18f1c: ldur            w4, [x1, #0xf]
    // 0xb18f20: DecompressPointer r4
    //     0xb18f20: add             x4, x4, HEAP, lsl #32
    // 0xb18f24: stur            x4, [fp, #-0x20]
    // 0xb18f28: r5 = 60
    //     0xb18f28: mov             x5, #0x3c
    // 0xb18f2c: branchIfSmi(r4, 0xb18f38)
    //     0xb18f2c: tbz             w4, #0, #0xb18f38
    // 0xb18f30: r5 = LoadClassIdInstr(r4)
    //     0xb18f30: ldur            x5, [x4, #-1]
    //     0xb18f34: ubfx            x5, x5, #0xc, #0x14
    // 0xb18f38: cmp             x5, #0x3e
    // 0xb18f3c: b.ne            #0xb191a4
    // 0xb18f40: LoadField: r5 = r1->field_13
    //     0xb18f40: ldur            w5, [x1, #0x13]
    // 0xb18f44: DecompressPointer r5
    //     0xb18f44: add             x5, x5, HEAP, lsl #32
    // 0xb18f48: stur            x5, [fp, #-0x18]
    // 0xb18f4c: r1 = 60
    //     0xb18f4c: mov             x1, #0x3c
    // 0xb18f50: branchIfSmi(r5, 0xb18f5c)
    //     0xb18f50: tbz             w5, #0, #0xb18f5c
    // 0xb18f54: r1 = LoadClassIdInstr(r5)
    //     0xb18f54: ldur            x1, [x5, #-1]
    //     0xb18f58: ubfx            x1, x1, #0xc, #0x14
    // 0xb18f5c: cmp             x1, #0x3e
    // 0xb18f60: b.ne            #0xb191a4
    // 0xb18f64: tbnz            w0, #4, #0xb18f74
    // 0xb18f68: mov             x1, x3
    // 0xb18f6c: mov             x0, x3
    // 0xb18f70: b               #0xb18f7c
    // 0xb18f74: mov             x1, x2
    // 0xb18f78: mov             x0, x2
    // 0xb18f7c: r2 = LoadClassIdInstr(r1)
    //     0xb18f7c: ldur            x2, [x1, #-1]
    //     0xb18f80: ubfx            x2, x2, #0xc, #0x14
    // 0xb18f84: lsl             x2, x2, #1
    // 0xb18f88: cmp             w2, #0x86
    // 0xb18f8c: b.ne            #0xb191a4
    // 0xb18f90: LoadField: r2 = r1->field_b
    //     0xb18f90: ldur            w2, [x1, #0xb]
    // 0xb18f94: cmp             w2, #4
    // 0xb18f98: b.ne            #0xb191a4
    // 0xb18f9c: LoadField: r1 = r0->field_f
    //     0xb18f9c: ldur            w1, [x0, #0xf]
    // 0xb18fa0: DecompressPointer r1
    //     0xb18fa0: add             x1, x1, HEAP, lsl #32
    // 0xb18fa4: stur            x1, [fp, #-0x10]
    // 0xb18fa8: r2 = 60
    //     0xb18fa8: mov             x2, #0x3c
    // 0xb18fac: branchIfSmi(r1, 0xb18fb8)
    //     0xb18fac: tbz             w1, #0, #0xb18fb8
    // 0xb18fb0: r2 = LoadClassIdInstr(r1)
    //     0xb18fb0: ldur            x2, [x1, #-1]
    //     0xb18fb4: ubfx            x2, x2, #0xc, #0x14
    // 0xb18fb8: cmp             x2, #0x3e
    // 0xb18fbc: b.ne            #0xb191a4
    // 0xb18fc0: LoadField: r2 = r0->field_13
    //     0xb18fc0: ldur            w2, [x0, #0x13]
    // 0xb18fc4: DecompressPointer r2
    //     0xb18fc4: add             x2, x2, HEAP, lsl #32
    // 0xb18fc8: stur            x2, [fp, #-8]
    // 0xb18fcc: r0 = 60
    //     0xb18fcc: mov             x0, #0x3c
    // 0xb18fd0: branchIfSmi(r2, 0xb18fdc)
    //     0xb18fd0: tbz             w2, #0, #0xb18fdc
    // 0xb18fd4: r0 = LoadClassIdInstr(r2)
    //     0xb18fd4: ldur            x0, [x2, #-1]
    //     0xb18fd8: ubfx            x0, x0, #0xc, #0x14
    // 0xb18fdc: cmp             x0, #0x3e
    // 0xb18fe0: b.ne            #0xb191a4
    // 0xb18fe4: r0 = 60
    //     0xb18fe4: mov             x0, #0x3c
    // 0xb18fe8: branchIfSmi(r4, 0xb18ff4)
    //     0xb18fe8: tbz             w4, #0, #0xb18ff4
    // 0xb18fec: r0 = LoadClassIdInstr(r4)
    //     0xb18fec: ldur            x0, [x4, #-1]
    //     0xb18ff0: ubfx            x0, x0, #0xc, #0x14
    // 0xb18ff4: stp             x1, x4, [SP]
    // 0xb18ff8: r0 = GDT[cid_x0 + -0xfe5]()
    //     0xb18ff8: sub             lr, x0, #0xfe5
    //     0xb18ffc: ldr             lr, [x21, lr, lsl #3]
    //     0xb19000: blr             lr
    // 0xb19004: tbnz            w0, #4, #0xb19014
    // 0xb19008: ldur            x2, [fp, #-0x20]
    // 0xb1900c: d0 = 0.000000
    //     0xb1900c: eor             v0.16b, v0.16b, v0.16b
    // 0xb19010: b               #0xb190bc
    // 0xb19014: ldur            x1, [fp, #-0x20]
    // 0xb19018: r0 = 60
    //     0xb19018: mov             x0, #0x3c
    // 0xb1901c: branchIfSmi(r1, 0xb19028)
    //     0xb1901c: tbz             w1, #0, #0xb19028
    // 0xb19020: r0 = LoadClassIdInstr(r1)
    //     0xb19020: ldur            x0, [x1, #-1]
    //     0xb19024: ubfx            x0, x0, #0xc, #0x14
    // 0xb19028: ldur            x16, [fp, #-0x10]
    // 0xb1902c: stp             x16, x1, [SP]
    // 0xb19030: r0 = GDT[cid_x0 + -0xfe8]()
    //     0xb19030: sub             lr, x0, #0xfe8
    //     0xb19034: ldr             lr, [x21, lr, lsl #3]
    //     0xb19038: blr             lr
    // 0xb1903c: tbnz            w0, #4, #0xb1904c
    // 0xb19040: ldur            x2, [fp, #-0x10]
    // 0xb19044: d0 = 0.000000
    //     0xb19044: eor             v0.16b, v0.16b, v0.16b
    // 0xb19048: b               #0xb190bc
    // 0xb1904c: ldur            x0, [fp, #-0x20]
    // 0xb19050: d0 = 0.000000
    //     0xb19050: eor             v0.16b, v0.16b, v0.16b
    // 0xb19054: LoadField: d1 = r0->field_7
    //     0xb19054: ldur            d1, [x0, #7]
    // 0xb19058: fcmp            d1, d0
    // 0xb1905c: b.ne            #0xb190a0
    // 0xb19060: ldur            x1, [fp, #-0x10]
    // 0xb19064: LoadField: d2 = r1->field_7
    //     0xb19064: ldur            d2, [x1, #7]
    // 0xb19068: fadd            d3, d1, d2
    // 0xb1906c: r0 = inline_Allocate_Double()
    //     0xb1906c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb19070: add             x0, x0, #0x10
    //     0xb19074: cmp             x1, x0
    //     0xb19078: b.ls            #0xb191bc
    //     0xb1907c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb19080: sub             x0, x0, #0xf
    //     0xb19084: mov             x1, #0xe19c
    //     0xb19088: movk            x1, #3, lsl #16
    //     0xb1908c: stur            x1, [x0, #-1]
    // 0xb19090: dmb             ishst
    // 0xb19094: StoreField: r0->field_7 = d3
    //     0xb19094: stur            d3, [x0, #7]
    // 0xb19098: mov             x2, x0
    // 0xb1909c: b               #0xb190bc
    // 0xb190a0: ldur            x1, [fp, #-0x10]
    // 0xb190a4: LoadField: d1 = r1->field_7
    //     0xb190a4: ldur            d1, [x1, #7]
    // 0xb190a8: fcmp            d1, d1
    // 0xb190ac: b.vc            #0xb190b8
    // 0xb190b0: mov             x2, x1
    // 0xb190b4: b               #0xb190bc
    // 0xb190b8: mov             x2, x0
    // 0xb190bc: ldur            x1, [fp, #-0x18]
    // 0xb190c0: stur            x2, [fp, #-0x10]
    // 0xb190c4: r0 = 60
    //     0xb190c4: mov             x0, #0x3c
    // 0xb190c8: branchIfSmi(r1, 0xb190d4)
    //     0xb190c8: tbz             w1, #0, #0xb190d4
    // 0xb190cc: r0 = LoadClassIdInstr(r1)
    //     0xb190cc: ldur            x0, [x1, #-1]
    //     0xb190d0: ubfx            x0, x0, #0xc, #0x14
    // 0xb190d4: ldur            x16, [fp, #-8]
    // 0xb190d8: stp             x16, x1, [SP]
    // 0xb190dc: r0 = GDT[cid_x0 + -0xfe5]()
    //     0xb190dc: sub             lr, x0, #0xfe5
    //     0xb190e0: ldr             lr, [x21, lr, lsl #3]
    //     0xb190e4: blr             lr
    // 0xb190e8: tbnz            w0, #4, #0xb190f4
    // 0xb190ec: ldur            x3, [fp, #-0x18]
    // 0xb190f0: b               #0xb19198
    // 0xb190f4: ldur            x1, [fp, #-0x18]
    // 0xb190f8: r0 = 60
    //     0xb190f8: mov             x0, #0x3c
    // 0xb190fc: branchIfSmi(r1, 0xb19108)
    //     0xb190fc: tbz             w1, #0, #0xb19108
    // 0xb19100: r0 = LoadClassIdInstr(r1)
    //     0xb19100: ldur            x0, [x1, #-1]
    //     0xb19104: ubfx            x0, x0, #0xc, #0x14
    // 0xb19108: ldur            x16, [fp, #-8]
    // 0xb1910c: stp             x16, x1, [SP]
    // 0xb19110: r0 = GDT[cid_x0 + -0xfe8]()
    //     0xb19110: sub             lr, x0, #0xfe8
    //     0xb19114: ldr             lr, [x21, lr, lsl #3]
    //     0xb19118: blr             lr
    // 0xb1911c: tbnz            w0, #4, #0xb19128
    // 0xb19120: ldur            x3, [fp, #-8]
    // 0xb19124: b               #0xb19198
    // 0xb19128: ldur            x0, [fp, #-0x18]
    // 0xb1912c: d0 = 0.000000
    //     0xb1912c: eor             v0.16b, v0.16b, v0.16b
    // 0xb19130: LoadField: d1 = r0->field_7
    //     0xb19130: ldur            d1, [x0, #7]
    // 0xb19134: fcmp            d1, d0
    // 0xb19138: b.ne            #0xb1917c
    // 0xb1913c: ldur            x1, [fp, #-8]
    // 0xb19140: LoadField: d0 = r1->field_7
    //     0xb19140: ldur            d0, [x1, #7]
    // 0xb19144: fadd            d2, d1, d0
    // 0xb19148: r0 = inline_Allocate_Double()
    //     0xb19148: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1914c: add             x0, x0, #0x10
    //     0xb19150: cmp             x1, x0
    //     0xb19154: b.ls            #0xb191cc
    //     0xb19158: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1915c: sub             x0, x0, #0xf
    //     0xb19160: mov             x1, #0xe19c
    //     0xb19164: movk            x1, #3, lsl #16
    //     0xb19168: stur            x1, [x0, #-1]
    // 0xb1916c: dmb             ishst
    // 0xb19170: StoreField: r0->field_7 = d2
    //     0xb19170: stur            d2, [x0, #7]
    // 0xb19174: mov             x3, x0
    // 0xb19178: b               #0xb19198
    // 0xb1917c: ldur            x1, [fp, #-8]
    // 0xb19180: LoadField: d0 = r1->field_7
    //     0xb19180: ldur            d0, [x1, #7]
    // 0xb19184: fcmp            d0, d0
    // 0xb19188: b.vc            #0xb19194
    // 0xb1918c: mov             x3, x1
    // 0xb19190: b               #0xb19198
    // 0xb19194: mov             x3, x0
    // 0xb19198: ldur            x2, [fp, #-0x10]
    // 0xb1919c: r0 = AllocateRecord2()
    //     0xb1919c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb191a0: b               #0xb191a8
    // 0xb191a4: r0 = Null
    //     0xb191a4: mov             x0, NULL
    // 0xb191a8: LeaveFrame
    //     0xb191a8: mov             SP, fp
    //     0xb191ac: ldp             fp, lr, [SP], #0x10
    // 0xb191b0: ret
    //     0xb191b0: ret             
    // 0xb191b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb191b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb191b8: b               #0xb18e04
    // 0xb191bc: stp             q0, q3, [SP, #-0x20]!
    // 0xb191c0: r0 = AllocateDouble()
    //     0xb191c0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb191c4: ldp             q0, q3, [SP], #0x20
    // 0xb191c8: b               #0xb19094
    // 0xb191cc: SaveReg d2
    //     0xb191cc: str             q2, [SP, #-0x10]!
    // 0xb191d0: r0 = AllocateDouble()
    //     0xb191d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb191d4: RestoreReg d2
    //     0xb191d4: ldr             q2, [SP], #0x10
    // 0xb191d8: b               #0xb19170
  }
  static _ _AxisSize._convert(/* No info */) {
    // ** addr: 0xb191dc, size: 0x50
    // 0xb191dc: EnterFrame
    //     0xb191dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb191e0: mov             fp, SP
    // 0xb191e4: AllocStack(0x10)
    //     0xb191e4: sub             SP, SP, #0x10
    // 0xb191e8: LoadField: r0 = r2->field_7
    //     0xb191e8: ldur            x0, [x2, #7]
    // 0xb191ec: cmp             x0, #0
    // 0xb191f0: b.gt            #0xb191fc
    // 0xb191f4: mov             x0, x1
    // 0xb191f8: b               #0xb19220
    // 0xb191fc: LoadField: d0 = r1->field_f
    //     0xb191fc: ldur            d0, [x1, #0xf]
    // 0xb19200: stur            d0, [fp, #-0x10]
    // 0xb19204: LoadField: d1 = r1->field_7
    //     0xb19204: ldur            d1, [x1, #7]
    // 0xb19208: stur            d1, [fp, #-8]
    // 0xb1920c: r0 = Size()
    //     0xb1920c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb19210: ldur            d0, [fp, #-0x10]
    // 0xb19214: StoreField: r0->field_7 = d0
    //     0xb19214: stur            d0, [x0, #7]
    // 0xb19218: ldur            d0, [fp, #-8]
    // 0xb1921c: StoreField: r0->field_f = d0
    //     0xb1921c: stur            d0, [x0, #0xf]
    // 0xb19220: LeaveFrame
    //     0xb19220: mov             SP, fp
    //     0xb19224: ldp             fp, lr, [SP], #0x10
    // 0xb19228: ret
    //     0xb19228: ret             
  }
}

// class id: 2875, size: 0x1c, field offset: 0x8
class _LayoutSizes extends Object {
}

// class id: 4212, size: 0x20, field offset: 0x18
class FlexParentData extends ContainerBoxParentData<dynamic> {
}

// class id: 4861, size: 0x98, field offset: 0x64
class RenderFlex extends _MixinApplication16&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb17a94, size: 0x24
    // 0xb17a94: EnterFrame
    //     0xb17a94: stp             fp, lr, [SP, #-0x10]!
    //     0xb17a98: mov             fp, SP
    // 0xb17a9c: ldr             x2, [fp, #0x10]
    // 0xb17aa0: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb17aa0: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4228] AnonymousClosure: (0xb17ab8), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicWidth (0xb17b30)
    //     0xb17aa4: ldr             x1, [x1, #0x228]
    // 0xb17aa8: r0 = AllocateClosure()
    //     0xb17aa8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb17aac: LeaveFrame
    //     0xb17aac: mov             SP, fp
    //     0xb17ab0: ldp             fp, lr, [SP], #0x10
    // 0xb17ab4: ret
    //     0xb17ab4: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb17ab8, size: 0x78
    // 0xb17ab8: EnterFrame
    //     0xb17ab8: stp             fp, lr, [SP, #-0x10]!
    //     0xb17abc: mov             fp, SP
    // 0xb17ac0: ldr             x0, [fp, #0x18]
    // 0xb17ac4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb17ac4: ldur            w1, [x0, #0x17]
    // 0xb17ac8: DecompressPointer r1
    //     0xb17ac8: add             x1, x1, HEAP, lsl #32
    // 0xb17acc: CheckStackOverflow
    //     0xb17acc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb17ad0: cmp             SP, x16
    //     0xb17ad4: b.ls            #0xb17b18
    // 0xb17ad8: ldr             x2, [fp, #0x10]
    // 0xb17adc: r0 = computeMinIntrinsicWidth()
    //     0xb17adc: bl              #0xb17b30  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicWidth
    // 0xb17ae0: r0 = inline_Allocate_Double()
    //     0xb17ae0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb17ae4: add             x0, x0, #0x10
    //     0xb17ae8: cmp             x1, x0
    //     0xb17aec: b.ls            #0xb17b20
    //     0xb17af0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb17af4: sub             x0, x0, #0xf
    //     0xb17af8: mov             x1, #0xe19c
    //     0xb17afc: movk            x1, #3, lsl #16
    //     0xb17b00: stur            x1, [x0, #-1]
    // 0xb17b04: dmb             ishst
    // 0xb17b08: StoreField: r0->field_7 = d0
    //     0xb17b08: stur            d0, [x0, #7]
    // 0xb17b0c: LeaveFrame
    //     0xb17b0c: mov             SP, fp
    //     0xb17b10: ldp             fp, lr, [SP], #0x10
    // 0xb17b14: ret
    //     0xb17b14: ret             
    // 0xb17b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb17b18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb17b1c: b               #0xb17ad8
    // 0xb17b20: SaveReg d0
    //     0xb17b20: str             q0, [SP, #-0x10]!
    // 0xb17b24: r0 = AllocateDouble()
    //     0xb17b24: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb17b28: RestoreReg d0
    //     0xb17b28: ldr             q0, [SP], #0x10
    // 0xb17b2c: b               #0xb17b08
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb17b30, size: 0x60
    // 0xb17b30: EnterFrame
    //     0xb17b30: stp             fp, lr, [SP, #-0x10]!
    //     0xb17b34: mov             fp, SP
    // 0xb17b38: AllocStack(0x10)
    //     0xb17b38: sub             SP, SP, #0x10
    // 0xb17b3c: SetupParameters(RenderFlex this /* r1 => r0, fp-0x8 */)
    //     0xb17b3c: mov             x0, x1
    //     0xb17b40: stur            x1, [fp, #-8]
    // 0xb17b44: CheckStackOverflow
    //     0xb17b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb17b48: cmp             SP, x16
    //     0xb17b4c: b.ls            #0xb17b88
    // 0xb17b50: LoadField: d0 = r2->field_7
    //     0xb17b50: ldur            d0, [x2, #7]
    // 0xb17b54: stur            d0, [fp, #-0x10]
    // 0xb17b58: r1 = Function '<anonymous closure>':.
    //     0xb17b58: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4230] AnonymousClosure: (0xb197f8), in [package:flutter_widget_from_html_core/src/widgets/html_flex.dart] RenderHtmlFlex::computeMinIntrinsicWidth (0xb1986c)
    //     0xb17b5c: ldr             x1, [x1, #0x230]
    // 0xb17b60: r2 = Null
    //     0xb17b60: mov             x2, NULL
    // 0xb17b64: r0 = AllocateClosure()
    //     0xb17b64: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb17b68: ldur            x1, [fp, #-8]
    // 0xb17b6c: mov             x2, x0
    // 0xb17b70: ldur            d0, [fp, #-0x10]
    // 0xb17b74: r3 = Instance_Axis
    //     0xb17b74: ldr             x3, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xb17b78: r0 = _getIntrinsicSize()
    //     0xb17b78: bl              #0xb17b90  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize
    // 0xb17b7c: LeaveFrame
    //     0xb17b7c: mov             SP, fp
    //     0xb17b80: ldp             fp, lr, [SP], #0x10
    // 0xb17b84: ret
    //     0xb17b84: ret             
    // 0xb17b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb17b88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb17b8c: b               #0xb17b50
  }
  _ _getIntrinsicSize(/* No info */) {
    // ** addr: 0xb17b90, size: 0x41c
    // 0xb17b90: EnterFrame
    //     0xb17b90: stp             fp, lr, [SP, #-0x10]!
    //     0xb17b94: mov             fp, SP
    // 0xb17b98: AllocStack(0x80)
    //     0xb17b98: sub             SP, SP, #0x80
    // 0xb17b9c: SetupParameters(RenderFlex this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x38 */)
    //     0xb17b9c: stur            x1, [fp, #-8]
    //     0xb17ba0: stur            x2, [fp, #-0x10]
    //     0xb17ba4: stur            x3, [fp, #-0x18]
    //     0xb17ba8: stur            d0, [fp, #-0x38]
    // 0xb17bac: CheckStackOverflow
    //     0xb17bac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb17bb0: cmp             SP, x16
    //     0xb17bb4: b.ls            #0xb17f34
    // 0xb17bb8: r1 = 2
    //     0xb17bb8: mov             x1, #2
    // 0xb17bbc: r0 = AllocateContext()
    //     0xb17bbc: bl              #0x13de838  ; AllocateContextStub
    // 0xb17bc0: mov             x3, x0
    // 0xb17bc4: ldur            x0, [fp, #-0x10]
    // 0xb17bc8: stur            x3, [fp, #-0x30]
    // 0xb17bcc: StoreField: r3->field_f = r0
    //     0xb17bcc: stur            w0, [x3, #0xf]
    // 0xb17bd0: ldur            x1, [fp, #-8]
    // 0xb17bd4: LoadField: r0 = r1->field_63
    //     0xb17bd4: ldur            w0, [x1, #0x63]
    // 0xb17bd8: DecompressPointer r0
    //     0xb17bd8: add             x0, x0, HEAP, lsl #32
    // 0xb17bdc: ldur            x2, [fp, #-0x18]
    // 0xb17be0: cmp             w0, w2
    // 0xb17be4: b.ne            #0xb17e88
    // 0xb17be8: ldur            d0, [fp, #-0x38]
    // 0xb17bec: LoadField: d1 = r1->field_8b
    //     0xb17bec: ldur            d1, [x1, #0x8b]
    // 0xb17bf0: LoadField: r0 = r1->field_4f
    //     0xb17bf0: ldur            x0, [x1, #0x4f]
    // 0xb17bf4: sub             x2, x0, #1
    // 0xb17bf8: scvtf           d2, x2
    // 0xb17bfc: fmul            d3, d1, d2
    // 0xb17c00: LoadField: r0 = r1->field_57
    //     0xb17c00: ldur            w0, [x1, #0x57]
    // 0xb17c04: DecompressPointer r0
    //     0xb17c04: add             x0, x0, HEAP, lsl #32
    // 0xb17c08: r4 = inline_Allocate_Double()
    //     0xb17c08: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0xb17c0c: add             x4, x4, #0x10
    //     0xb17c10: cmp             x1, x4
    //     0xb17c14: b.ls            #0xb17f3c
    //     0xb17c18: str             x4, [THR, #0x60]  ; THR::top
    //     0xb17c1c: sub             x4, x4, #0xf
    //     0xb17c20: mov             x1, #0xe19c
    //     0xb17c24: movk            x1, #3, lsl #16
    //     0xb17c28: stur            x1, [x4, #-1]
    // 0xb17c2c: dmb             ishst
    // 0xb17c30: StoreField: r4->field_7 = d0
    //     0xb17c30: stur            d0, [x4, #7]
    // 0xb17c34: stur            x4, [fp, #-0x28]
    // 0xb17c38: r5 = inline_Allocate_Double()
    //     0xb17c38: ldp             x5, x1, [THR, #0x60]  ; THR::top
    //     0xb17c3c: add             x5, x5, #0x10
    //     0xb17c40: cmp             x1, x5
    //     0xb17c44: b.ls            #0xb17f58
    //     0xb17c48: str             x5, [THR, #0x60]  ; THR::top
    //     0xb17c4c: sub             x5, x5, #0xf
    //     0xb17c50: mov             x1, #0xe19c
    //     0xb17c54: movk            x1, #3, lsl #16
    //     0xb17c58: stur            x1, [x5, #-1]
    // 0xb17c5c: dmb             ishst
    // 0xb17c60: StoreField: r5->field_7 = d0
    //     0xb17c60: stur            d0, [x5, #7]
    // 0xb17c64: stur            x5, [fp, #-0x20]
    // 0xb17c68: mov             v1.16b, v3.16b
    // 0xb17c6c: mov             x6, x0
    // 0xb17c70: d2 = 0.000000
    //     0xb17c70: eor             v2.16b, v2.16b, v2.16b
    // 0xb17c74: d0 = 0.000000
    //     0xb17c74: eor             v0.16b, v0.16b, v0.16b
    // 0xb17c78: stur            x6, [fp, #-0x18]
    // 0xb17c7c: stur            d2, [fp, #-0x40]
    // 0xb17c80: stur            d1, [fp, #-0x48]
    // 0xb17c84: stur            d0, [fp, #-0x50]
    // 0xb17c88: CheckStackOverflow
    //     0xb17c88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb17c8c: cmp             SP, x16
    //     0xb17c90: b.ls            #0xb17f7c
    // 0xb17c94: cmp             w6, NULL
    // 0xb17c98: b.eq            #0xb17e68
    // 0xb17c9c: LoadField: r7 = r6->field_7
    //     0xb17c9c: ldur            w7, [x6, #7]
    // 0xb17ca0: DecompressPointer r7
    //     0xb17ca0: add             x7, x7, HEAP, lsl #32
    // 0xb17ca4: stur            x7, [fp, #-0x10]
    // 0xb17ca8: cmp             w7, NULL
    // 0xb17cac: b.eq            #0xb17f84
    // 0xb17cb0: mov             x0, x7
    // 0xb17cb4: r2 = Null
    //     0xb17cb4: mov             x2, NULL
    // 0xb17cb8: r1 = Null
    //     0xb17cb8: mov             x1, NULL
    // 0xb17cbc: r4 = LoadClassIdInstr(r0)
    //     0xb17cbc: ldur            x4, [x0, #-1]
    //     0xb17cc0: ubfx            x4, x4, #0xc, #0x14
    // 0xb17cc4: r17 = 4212
    //     0xb17cc4: mov             x17, #0x1074
    // 0xb17cc8: cmp             x4, x17
    // 0xb17ccc: b.eq            #0xb17ce4
    // 0xb17cd0: r8 = FlexParentData
    //     0xb17cd0: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb17cd4: ldr             x8, [x8, #0x10]
    // 0xb17cd8: r3 = Null
    //     0xb17cd8: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a260] Null
    //     0xb17cdc: ldr             x3, [x3, #0x260]
    // 0xb17ce0: r0 = DefaultTypeTest()
    //     0xb17ce0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb17ce4: ldur            x0, [fp, #-0x10]
    // 0xb17ce8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb17ce8: ldur            w1, [x0, #0x17]
    // 0xb17cec: DecompressPointer r1
    //     0xb17cec: add             x1, x1, HEAP, lsl #32
    // 0xb17cf0: cmp             w1, NULL
    // 0xb17cf4: b.ne            #0xb17d00
    // 0xb17cf8: r0 = 0
    //     0xb17cf8: mov             x0, #0
    // 0xb17cfc: b               #0xb17d0c
    // 0xb17d00: r0 = LoadInt32Instr(r1)
    //     0xb17d00: sbfx            x0, x1, #1, #0x1f
    //     0xb17d04: tbz             w1, #0, #0xb17d0c
    //     0xb17d08: ldur            x0, [x1, #7]
    // 0xb17d0c: ldur            d0, [fp, #-0x40]
    // 0xb17d10: scvtf           d1, x0
    // 0xb17d14: stur            d1, [fp, #-0x60]
    // 0xb17d18: fadd            d2, d0, d1
    // 0xb17d1c: stur            d2, [fp, #-0x58]
    // 0xb17d20: cmp             x0, #0
    // 0xb17d24: b.le            #0xb17d7c
    // 0xb17d28: ldur            x2, [fp, #-0x30]
    // 0xb17d2c: ldur            d0, [fp, #-0x50]
    // 0xb17d30: LoadField: r0 = r2->field_f
    //     0xb17d30: ldur            w0, [x2, #0xf]
    // 0xb17d34: DecompressPointer r0
    //     0xb17d34: add             x0, x0, HEAP, lsl #32
    // 0xb17d38: ldur            x16, [fp, #-0x18]
    // 0xb17d3c: stp             x16, x0, [SP, #8]
    // 0xb17d40: ldur            x16, [fp, #-0x20]
    // 0xb17d44: str             x16, [SP]
    // 0xb17d48: ClosureCall
    //     0xb17d48: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb17d4c: ldur            x2, [x0, #0x1f]
    //     0xb17d50: blr             x2
    // 0xb17d54: cmp             w0, NULL
    // 0xb17d58: b.eq            #0xb17f88
    // 0xb17d5c: LoadField: d0 = r0->field_7
    //     0xb17d5c: ldur            d0, [x0, #7]
    // 0xb17d60: ldur            d1, [fp, #-0x60]
    // 0xb17d64: fdiv            d2, d0, d1
    // 0xb17d68: ldur            d0, [fp, #-0x50]
    // 0xb17d6c: fmax            v3.2d, v0.2d, v2.2d
    // 0xb17d70: ldur            d1, [fp, #-0x48]
    // 0xb17d74: mov             v0.16b, v3.16b
    // 0xb17d78: b               #0xb17dec
    // 0xb17d7c: ldur            x2, [fp, #-0x30]
    // 0xb17d80: ldur            d1, [fp, #-0x48]
    // 0xb17d84: ldur            d0, [fp, #-0x50]
    // 0xb17d88: LoadField: r0 = r2->field_f
    //     0xb17d88: ldur            w0, [x2, #0xf]
    // 0xb17d8c: DecompressPointer r0
    //     0xb17d8c: add             x0, x0, HEAP, lsl #32
    // 0xb17d90: ldur            x16, [fp, #-0x18]
    // 0xb17d94: stp             x16, x0, [SP, #8]
    // 0xb17d98: ldur            x16, [fp, #-0x28]
    // 0xb17d9c: str             x16, [SP]
    // 0xb17da0: ClosureCall
    //     0xb17da0: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb17da4: ldur            x2, [x0, #0x1f]
    //     0xb17da8: blr             x2
    // 0xb17dac: ldur            d1, [fp, #-0x48]
    // 0xb17db0: r1 = inline_Allocate_Double()
    //     0xb17db0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb17db4: add             x1, x1, #0x10
    //     0xb17db8: cmp             x2, x1
    //     0xb17dbc: b.ls            #0xb17f8c
    //     0xb17dc0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb17dc4: sub             x1, x1, #0xf
    //     0xb17dc8: mov             x2, #0xe19c
    //     0xb17dcc: movk            x2, #3, lsl #16
    //     0xb17dd0: stur            x2, [x1, #-1]
    // 0xb17dd4: dmb             ishst
    // 0xb17dd8: StoreField: r1->field_7 = d1
    //     0xb17dd8: stur            d1, [x1, #7]
    // 0xb17ddc: stp             x0, x1, [SP]
    // 0xb17de0: r0 = +()
    //     0xb17de0: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xb17de4: LoadField: d1 = r0->field_7
    //     0xb17de4: ldur            d1, [x0, #7]
    // 0xb17de8: ldur            d0, [fp, #-0x50]
    // 0xb17dec: ldur            x0, [fp, #-0x18]
    // 0xb17df0: stur            d1, [fp, #-0x60]
    // 0xb17df4: stur            d0, [fp, #-0x68]
    // 0xb17df8: LoadField: r3 = r0->field_7
    //     0xb17df8: ldur            w3, [x0, #7]
    // 0xb17dfc: DecompressPointer r3
    //     0xb17dfc: add             x3, x3, HEAP, lsl #32
    // 0xb17e00: stur            x3, [fp, #-0x10]
    // 0xb17e04: cmp             w3, NULL
    // 0xb17e08: b.eq            #0xb17fa8
    // 0xb17e0c: mov             x0, x3
    // 0xb17e10: r2 = Null
    //     0xb17e10: mov             x2, NULL
    // 0xb17e14: r1 = Null
    //     0xb17e14: mov             x1, NULL
    // 0xb17e18: r4 = LoadClassIdInstr(r0)
    //     0xb17e18: ldur            x4, [x0, #-1]
    //     0xb17e1c: ubfx            x4, x4, #0xc, #0x14
    // 0xb17e20: r17 = 4212
    //     0xb17e20: mov             x17, #0x1074
    // 0xb17e24: cmp             x4, x17
    // 0xb17e28: b.eq            #0xb17e40
    // 0xb17e2c: r8 = FlexParentData
    //     0xb17e2c: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb17e30: ldr             x8, [x8, #0x10]
    // 0xb17e34: r3 = Null
    //     0xb17e34: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a270] Null
    //     0xb17e38: ldr             x3, [x3, #0x270]
    // 0xb17e3c: r0 = DefaultTypeTest()
    //     0xb17e3c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb17e40: ldur            x0, [fp, #-0x10]
    // 0xb17e44: LoadField: r6 = r0->field_13
    //     0xb17e44: ldur            w6, [x0, #0x13]
    // 0xb17e48: DecompressPointer r6
    //     0xb17e48: add             x6, x6, HEAP, lsl #32
    // 0xb17e4c: ldur            d2, [fp, #-0x58]
    // 0xb17e50: ldur            d1, [fp, #-0x60]
    // 0xb17e54: ldur            d0, [fp, #-0x68]
    // 0xb17e58: ldur            x3, [fp, #-0x30]
    // 0xb17e5c: ldur            x5, [fp, #-0x20]
    // 0xb17e60: ldur            x4, [fp, #-0x28]
    // 0xb17e64: b               #0xb17c78
    // 0xb17e68: mov             v31.16b, v0.16b
    // 0xb17e6c: mov             v0.16b, v2.16b
    // 0xb17e70: mov             v2.16b, v31.16b
    // 0xb17e74: fmul            d3, d2, d0
    // 0xb17e78: fadd            d0, d3, d1
    // 0xb17e7c: LeaveFrame
    //     0xb17e7c: mov             SP, fp
    //     0xb17e80: ldp             fp, lr, [SP], #0x10
    // 0xb17e84: ret
    //     0xb17e84: ret             
    // 0xb17e88: ldur            d0, [fp, #-0x38]
    // 0xb17e8c: LoadField: r2 = r0->field_7
    //     0xb17e8c: ldur            x2, [x0, #7]
    // 0xb17e90: cmp             x2, #0
    // 0xb17e94: b.gt            #0xb17ea0
    // 0xb17e98: r0 = true
    //     0xb17e98: add             x0, NULL, #0x20  ; true
    // 0xb17e9c: b               #0xb17ea4
    // 0xb17ea0: r0 = false
    //     0xb17ea0: add             x0, NULL, #0x30  ; false
    // 0xb17ea4: ldur            x2, [fp, #-0x30]
    // 0xb17ea8: StoreField: r2->field_13 = r0
    //     0xb17ea8: stur            w0, [x2, #0x13]
    // 0xb17eac: tbnz            w0, #4, #0xb17ed0
    // 0xb17eb0: r0 = BoxConstraints()
    //     0xb17eb0: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb17eb4: StoreField: r0->field_7 = rZR
    //     0xb17eb4: stur            xzr, [x0, #7]
    // 0xb17eb8: ldur            d0, [fp, #-0x38]
    // 0xb17ebc: StoreField: r0->field_f = d0
    //     0xb17ebc: stur            d0, [x0, #0xf]
    // 0xb17ec0: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb17ec0: stur            xzr, [x0, #0x17]
    // 0xb17ec4: d1 = inf
    //     0xb17ec4: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb17ec8: StoreField: r0->field_1f = d1
    //     0xb17ec8: stur            d1, [x0, #0x1f]
    // 0xb17ecc: b               #0xb17ef0
    // 0xb17ed0: d1 = inf
    //     0xb17ed0: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb17ed4: r0 = BoxConstraints()
    //     0xb17ed4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb17ed8: StoreField: r0->field_7 = rZR
    //     0xb17ed8: stur            xzr, [x0, #7]
    // 0xb17edc: d0 = inf
    //     0xb17edc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb17ee0: StoreField: r0->field_f = d0
    //     0xb17ee0: stur            d0, [x0, #0xf]
    // 0xb17ee4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb17ee4: stur            xzr, [x0, #0x17]
    // 0xb17ee8: ldur            d0, [fp, #-0x38]
    // 0xb17eec: StoreField: r0->field_1f = d0
    //     0xb17eec: stur            d0, [x0, #0x1f]
    // 0xb17ef0: ldur            x2, [fp, #-0x30]
    // 0xb17ef4: stur            x0, [fp, #-0x10]
    // 0xb17ef8: r1 = Function 'layoutChild':.
    //     0xb17ef8: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a280] AnonymousClosure: (0xb19484), in [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize (0xb17b90)
    //     0xb17efc: ldr             x1, [x1, #0x280]
    // 0xb17f00: r0 = AllocateClosure()
    //     0xb17f00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb17f04: ldur            x1, [fp, #-8]
    // 0xb17f08: ldur            x2, [fp, #-0x10]
    // 0xb17f0c: mov             x5, x0
    // 0xb17f10: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb17f10: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb17f14: ldr             x3, [x3, #0x860]
    // 0xb17f18: r0 = _computeSizes()
    //     0xb17f18: bl              #0xb1805c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_computeSizes
    // 0xb17f1c: LoadField: r1 = r0->field_7
    //     0xb17f1c: ldur            w1, [x0, #7]
    // 0xb17f20: DecompressPointer r1
    //     0xb17f20: add             x1, x1, HEAP, lsl #32
    // 0xb17f24: LoadField: d0 = r1->field_f
    //     0xb17f24: ldur            d0, [x1, #0xf]
    // 0xb17f28: LeaveFrame
    //     0xb17f28: mov             SP, fp
    //     0xb17f2c: ldp             fp, lr, [SP], #0x10
    // 0xb17f30: ret
    //     0xb17f30: ret             
    // 0xb17f34: r0 = StackOverflowSharedWithFPURegs()
    //     0xb17f34: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb17f38: b               #0xb17bb8
    // 0xb17f3c: stp             q0, q3, [SP, #-0x20]!
    // 0xb17f40: stp             x0, x3, [SP, #-0x10]!
    // 0xb17f44: r0 = AllocateDouble()
    //     0xb17f44: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb17f48: mov             x4, x0
    // 0xb17f4c: ldp             x0, x3, [SP], #0x10
    // 0xb17f50: ldp             q0, q3, [SP], #0x20
    // 0xb17f54: b               #0xb17c30
    // 0xb17f58: stp             q0, q3, [SP, #-0x20]!
    // 0xb17f5c: stp             x3, x4, [SP, #-0x10]!
    // 0xb17f60: SaveReg r0
    //     0xb17f60: str             x0, [SP, #-8]!
    // 0xb17f64: r0 = AllocateDouble()
    //     0xb17f64: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb17f68: mov             x5, x0
    // 0xb17f6c: RestoreReg r0
    //     0xb17f6c: ldr             x0, [SP], #8
    // 0xb17f70: ldp             x3, x4, [SP], #0x10
    // 0xb17f74: ldp             q0, q3, [SP], #0x20
    // 0xb17f78: b               #0xb17c60
    // 0xb17f7c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb17f7c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb17f80: b               #0xb17c94
    // 0xb17f84: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb17f84: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb17f88: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb17f88: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xb17f8c: SaveReg d1
    //     0xb17f8c: str             q1, [SP, #-0x10]!
    // 0xb17f90: SaveReg r0
    //     0xb17f90: str             x0, [SP, #-8]!
    // 0xb17f94: r0 = AllocateDouble()
    //     0xb17f94: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb17f98: mov             x1, x0
    // 0xb17f9c: RestoreReg r0
    //     0xb17f9c: ldr             x0, [SP], #8
    // 0xb17fa0: RestoreReg d1
    //     0xb17fa0: ldr             q1, [SP], #0x10
    // 0xb17fa4: b               #0xb17dd8
    // 0xb17fa8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb17fa8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _computeSizes(/* No info */) {
    // ** addr: 0xb1805c, size: 0xa00
    // 0xb1805c: EnterFrame
    //     0xb1805c: stp             fp, lr, [SP, #-0x10]!
    //     0xb18060: mov             fp, SP
    // 0xb18064: AllocStack(0xd8)
    //     0xb18064: sub             SP, SP, #0xd8
    // 0xb18068: SetupParameters(RenderFlex this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r2, fp-0x18 */)
    //     0xb18068: mov             x4, x1
    //     0xb1806c: stur            x2, [fp, #-0x10]
    //     0xb18070: mov             x16, x3
    //     0xb18074: mov             x3, x2
    //     0xb18078: mov             x2, x16
    //     0xb1807c: mov             x0, x5
    //     0xb18080: stur            x1, [fp, #-8]
    //     0xb18084: stur            x2, [fp, #-0x18]
    //     0xb18088: stur            x5, [fp, #-0x20]
    // 0xb1808c: CheckStackOverflow
    //     0xb1808c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb18090: cmp             SP, x16
    //     0xb18094: b.ls            #0xb189a8
    // 0xb18098: mov             x1, x3
    // 0xb1809c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb1809c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb180a0: r0 = constrainWidth()
    //     0xb180a0: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb180a4: ldur            x1, [fp, #-0x10]
    // 0xb180a8: stur            d0, [fp, #-0x90]
    // 0xb180ac: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb180ac: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb180b0: r0 = constrainHeight()
    //     0xb180b0: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb180b4: stur            d0, [fp, #-0x98]
    // 0xb180b8: r0 = Size()
    //     0xb180b8: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb180bc: ldur            d0, [fp, #-0x90]
    // 0xb180c0: StoreField: r0->field_7 = d0
    //     0xb180c0: stur            d0, [x0, #7]
    // 0xb180c4: ldur            d0, [fp, #-0x98]
    // 0xb180c8: StoreField: r0->field_f = d0
    //     0xb180c8: stur            d0, [x0, #0xf]
    // 0xb180cc: ldur            x1, [fp, #-8]
    // 0xb180d0: mov             x2, x0
    // 0xb180d4: r0 = _getMainSize()
    //     0xb180d4: bl              #0xb19458  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getMainSize
    // 0xb180d8: stur            d0, [fp, #-0x90]
    // 0xb180dc: mov             x0, v0.d[0]
    // 0xb180e0: and             x0, x0, #0x7fffffffffffffff
    // 0xb180e4: r17 = 9218868437227405312
    //     0xb180e4: mov             x17, #0x7ff0000000000000
    // 0xb180e8: cmp             x0, x17
    // 0xb180ec: b.eq            #0xb18104
    // 0xb180f0: fcmp            d0, d0
    // 0xb180f4: r16 = true
    //     0xb180f4: add             x16, NULL, #0x20  ; true
    // 0xb180f8: r17 = false
    //     0xb180f8: add             x17, NULL, #0x30  ; false
    // 0xb180fc: csel            x0, x16, x17, vc
    // 0xb18100: b               #0xb18108
    // 0xb18104: r0 = false
    //     0xb18104: add             x0, NULL, #0x30  ; false
    // 0xb18108: ldur            x1, [fp, #-8]
    // 0xb1810c: ldur            x2, [fp, #-0x10]
    // 0xb18110: stur            x0, [fp, #-0x28]
    // 0xb18114: r0 = _constraintsForNonFlexChild()
    //     0xb18114: bl              #0xb192f8  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_constraintsForNonFlexChild
    // 0xb18118: ldur            x1, [fp, #-8]
    // 0xb1811c: stur            x0, [fp, #-0x30]
    // 0xb18120: r0 = _isBaselineAligned()
    //     0xb18120: bl              #0xb19268  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_isBaselineAligned
    // 0xb18124: tbnz            w0, #4, #0xb18140
    // 0xb18128: ldur            x1, [fp, #-8]
    // 0xb1812c: LoadField: r0 = r1->field_7b
    //     0xb1812c: ldur            w0, [x1, #0x7b]
    // 0xb18130: DecompressPointer r0
    //     0xb18130: add             x0, x0, HEAP, lsl #32
    // 0xb18134: cmp             w0, NULL
    // 0xb18138: b.ne            #0xb18148
    // 0xb1813c: b               #0xb18990
    // 0xb18140: ldur            x1, [fp, #-8]
    // 0xb18144: r0 = Null
    //     0xb18144: mov             x0, NULL
    // 0xb18148: stur            x0, [fp, #-0x38]
    // 0xb1814c: LoadField: d0 = r1->field_8b
    //     0xb1814c: ldur            d0, [x1, #0x8b]
    // 0xb18150: LoadField: r2 = r1->field_4f
    //     0xb18150: ldur            x2, [x1, #0x4f]
    // 0xb18154: sub             x3, x2, #1
    // 0xb18158: scvtf           d1, x3
    // 0xb1815c: fmul            d2, d0, d1
    // 0xb18160: stur            d2, [fp, #-0x98]
    // 0xb18164: r0 = Size()
    //     0xb18164: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb18168: ldur            d0, [fp, #-0x98]
    // 0xb1816c: StoreField: r0->field_7 = d0
    //     0xb1816c: stur            d0, [x0, #7]
    // 0xb18170: StoreField: r0->field_f = rZR
    //     0xb18170: stur            xzr, [x0, #0xf]
    // 0xb18174: ldur            x3, [fp, #-8]
    // 0xb18178: LoadField: r1 = r3->field_57
    //     0xb18178: ldur            w1, [x3, #0x57]
    // 0xb1817c: DecompressPointer r1
    //     0xb1817c: add             x1, x1, HEAP, lsl #32
    // 0xb18180: mov             x7, x0
    // 0xb18184: mov             x6, x1
    // 0xb18188: mov             v1.16b, v0.16b
    // 0xb1818c: r10 = 0
    //     0xb1818c: mov             x10, #0
    // 0xb18190: r9 = Null
    //     0xb18190: mov             x9, NULL
    // 0xb18194: r8 = Null
    //     0xb18194: mov             x8, NULL
    // 0xb18198: d0 = 0.000000
    //     0xb18198: eor             v0.16b, v0.16b, v0.16b
    // 0xb1819c: ldur            x4, [fp, #-0x38]
    // 0xb181a0: ldur            x5, [fp, #-0x28]
    // 0xb181a4: stur            x10, [fp, #-0x48]
    // 0xb181a8: stur            x9, [fp, #-0x50]
    // 0xb181ac: stur            x8, [fp, #-0x58]
    // 0xb181b0: stur            x7, [fp, #-0x60]
    // 0xb181b4: stur            x6, [fp, #-0x68]
    // 0xb181b8: stur            d1, [fp, #-0x98]
    // 0xb181bc: stur            d0, [fp, #-0xa0]
    // 0xb181c0: CheckStackOverflow
    //     0xb181c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb181c4: cmp             SP, x16
    //     0xb181c8: b.ls            #0xb189b0
    // 0xb181cc: cmp             w6, NULL
    // 0xb181d0: b.eq            #0xb18464
    // 0xb181d4: tbnz            w5, #4, #0xb18298
    // 0xb181d8: LoadField: r11 = r6->field_7
    //     0xb181d8: ldur            w11, [x6, #7]
    // 0xb181dc: DecompressPointer r11
    //     0xb181dc: add             x11, x11, HEAP, lsl #32
    // 0xb181e0: stur            x11, [fp, #-0x40]
    // 0xb181e4: cmp             w11, NULL
    // 0xb181e8: b.eq            #0xb189b8
    // 0xb181ec: mov             x0, x11
    // 0xb181f0: r2 = Null
    //     0xb181f0: mov             x2, NULL
    // 0xb181f4: r1 = Null
    //     0xb181f4: mov             x1, NULL
    // 0xb181f8: r4 = LoadClassIdInstr(r0)
    //     0xb181f8: ldur            x4, [x0, #-1]
    //     0xb181fc: ubfx            x4, x4, #0xc, #0x14
    // 0xb18200: r17 = 4212
    //     0xb18200: mov             x17, #0x1074
    // 0xb18204: cmp             x4, x17
    // 0xb18208: b.eq            #0xb18220
    // 0xb1820c: r8 = FlexParentData
    //     0xb1820c: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb18210: ldr             x8, [x8, #0x10]
    // 0xb18214: r3 = Null
    //     0xb18214: add             x3, PP, #0x90, lsl #12  ; [pp+0x90808] Null
    //     0xb18218: ldr             x3, [x3, #0x808]
    // 0xb1821c: r0 = DefaultTypeTest()
    //     0xb1821c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb18220: ldur            x0, [fp, #-0x40]
    // 0xb18224: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb18224: ldur            w1, [x0, #0x17]
    // 0xb18228: DecompressPointer r1
    //     0xb18228: add             x1, x1, HEAP, lsl #32
    // 0xb1822c: cmp             w1, NULL
    // 0xb18230: b.ne            #0xb1823c
    // 0xb18234: r0 = 0
    //     0xb18234: mov             x0, #0
    // 0xb18238: b               #0xb18248
    // 0xb1823c: r0 = LoadInt32Instr(r1)
    //     0xb1823c: sbfx            x0, x1, #1, #0x1f
    //     0xb18240: tbz             w1, #0, #0xb18248
    //     0xb18244: ldur            x0, [x1, #7]
    // 0xb18248: cmp             x0, #0
    // 0xb1824c: b.le            #0xb1828c
    // 0xb18250: ldur            x2, [fp, #-0x48]
    // 0xb18254: ldur            x1, [fp, #-0x50]
    // 0xb18258: add             x3, x2, x0
    // 0xb1825c: cmp             w1, NULL
    // 0xb18260: b.ne            #0xb1826c
    // 0xb18264: ldur            x0, [fp, #-0x68]
    // 0xb18268: b               #0xb18270
    // 0xb1826c: mov             x0, x1
    // 0xb18270: mov             x10, x3
    // 0xb18274: mov             x9, x0
    // 0xb18278: ldur            x8, [fp, #-0x58]
    // 0xb1827c: ldur            x7, [fp, #-0x60]
    // 0xb18280: ldur            d1, [fp, #-0x98]
    // 0xb18284: ldur            d0, [fp, #-0xa0]
    // 0xb18288: b               #0xb183d4
    // 0xb1828c: ldur            x2, [fp, #-0x48]
    // 0xb18290: ldur            x1, [fp, #-0x50]
    // 0xb18294: b               #0xb182a0
    // 0xb18298: mov             x2, x10
    // 0xb1829c: mov             x1, x9
    // 0xb182a0: ldur            x3, [fp, #-8]
    // 0xb182a4: ldur            x4, [fp, #-0x38]
    // 0xb182a8: ldur            d1, [fp, #-0x98]
    // 0xb182ac: ldur            d0, [fp, #-0xa0]
    // 0xb182b0: ldur            x16, [fp, #-0x20]
    // 0xb182b4: ldur            lr, [fp, #-0x68]
    // 0xb182b8: stp             lr, x16, [SP, #8]
    // 0xb182bc: ldur            x16, [fp, #-0x30]
    // 0xb182c0: str             x16, [SP]
    // 0xb182c4: ldur            x0, [fp, #-0x20]
    // 0xb182c8: ClosureCall
    //     0xb182c8: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb182cc: ldur            x2, [x0, #0x1f]
    //     0xb182d0: blr             x2
    // 0xb182d4: mov             x1, x0
    // 0xb182d8: ldur            x0, [fp, #-8]
    // 0xb182dc: LoadField: r2 = r0->field_63
    //     0xb182dc: ldur            w2, [x0, #0x63]
    // 0xb182e0: DecompressPointer r2
    //     0xb182e0: add             x2, x2, HEAP, lsl #32
    // 0xb182e4: r0 = _AxisSize._convert()
    //     0xb182e4: bl              #0xb191dc  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize._convert
    // 0xb182e8: LoadField: d0 = r0->field_7
    //     0xb182e8: ldur            d0, [x0, #7]
    // 0xb182ec: ldur            d1, [fp, #-0x98]
    // 0xb182f0: fadd            d2, d1, d0
    // 0xb182f4: stur            d2, [fp, #-0xb8]
    // 0xb182f8: LoadField: d0 = r0->field_f
    //     0xb182f8: ldur            d0, [x0, #0xf]
    // 0xb182fc: ldur            d3, [fp, #-0xa0]
    // 0xb18300: stur            d0, [fp, #-0xb0]
    // 0xb18304: fmax            v1.2d, v3.2d, v0.2d
    // 0xb18308: stur            d1, [fp, #-0xa8]
    // 0xb1830c: r0 = Size()
    //     0xb1830c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb18310: mov             x1, x0
    // 0xb18314: ldur            d0, [fp, #-0xb8]
    // 0xb18318: stur            x1, [fp, #-0x40]
    // 0xb1831c: StoreField: r1->field_7 = d0
    //     0xb1831c: stur            d0, [x1, #7]
    // 0xb18320: ldur            d1, [fp, #-0xa8]
    // 0xb18324: StoreField: r1->field_f = d1
    //     0xb18324: stur            d1, [x1, #0xf]
    // 0xb18328: ldur            x2, [fp, #-0x38]
    // 0xb1832c: cmp             w2, NULL
    // 0xb18330: b.ne            #0xb1833c
    // 0xb18334: r2 = Null
    //     0xb18334: mov             x2, NULL
    // 0xb18338: b               #0xb18364
    // 0xb1833c: ldur            x16, [fp, #-0x18]
    // 0xb18340: ldur            lr, [fp, #-0x68]
    // 0xb18344: stp             lr, x16, [SP, #0x10]
    // 0xb18348: ldur            x16, [fp, #-0x30]
    // 0xb1834c: stp             x2, x16, [SP]
    // 0xb18350: ldur            x0, [fp, #-0x18]
    // 0xb18354: ClosureCall
    //     0xb18354: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xb18358: ldur            x2, [x0, #0x1f]
    //     0xb1835c: blr             x2
    // 0xb18360: mov             x2, x0
    // 0xb18364: cmp             w2, NULL
    // 0xb18368: b.ne            #0xb18374
    // 0xb1836c: r2 = Null
    //     0xb1836c: mov             x2, NULL
    // 0xb18370: b               #0xb183b4
    // 0xb18374: ldur            d0, [fp, #-0xb0]
    // 0xb18378: LoadField: d1 = r2->field_7
    //     0xb18378: ldur            d1, [x2, #7]
    // 0xb1837c: fsub            d2, d0, d1
    // 0xb18380: r3 = inline_Allocate_Double()
    //     0xb18380: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb18384: add             x3, x3, #0x10
    //     0xb18388: cmp             x0, x3
    //     0xb1838c: b.ls            #0xb189bc
    //     0xb18390: str             x3, [THR, #0x60]  ; THR::top
    //     0xb18394: sub             x3, x3, #0xf
    //     0xb18398: mov             x0, #0xe19c
    //     0xb1839c: movk            x0, #3, lsl #16
    //     0xb183a0: stur            x0, [x3, #-1]
    // 0xb183a4: dmb             ishst
    // 0xb183a8: StoreField: r3->field_7 = d2
    //     0xb183a8: stur            d2, [x3, #7]
    // 0xb183ac: r0 = AllocateRecord2()
    //     0xb183ac: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb183b0: mov             x2, x0
    // 0xb183b4: ldur            x1, [fp, #-0x58]
    // 0xb183b8: r0 = _AscentDescent.+()
    //     0xb183b8: bl              #0xb18dec  ; [package:flutter/src/rendering/flex.dart] ::_AscentDescent.+
    // 0xb183bc: ldur            x10, [fp, #-0x48]
    // 0xb183c0: ldur            x9, [fp, #-0x50]
    // 0xb183c4: mov             x8, x0
    // 0xb183c8: ldur            x7, [fp, #-0x40]
    // 0xb183cc: ldur            d1, [fp, #-0xb8]
    // 0xb183d0: ldur            d0, [fp, #-0xa8]
    // 0xb183d4: ldur            x0, [fp, #-0x68]
    // 0xb183d8: stur            x10, [fp, #-0x70]
    // 0xb183dc: stur            x9, [fp, #-0x78]
    // 0xb183e0: stur            x8, [fp, #-0x80]
    // 0xb183e4: stur            x7, [fp, #-0x88]
    // 0xb183e8: stur            d1, [fp, #-0xa8]
    // 0xb183ec: stur            d0, [fp, #-0xb0]
    // 0xb183f0: LoadField: r3 = r0->field_7
    //     0xb183f0: ldur            w3, [x0, #7]
    // 0xb183f4: DecompressPointer r3
    //     0xb183f4: add             x3, x3, HEAP, lsl #32
    // 0xb183f8: stur            x3, [fp, #-0x40]
    // 0xb183fc: cmp             w3, NULL
    // 0xb18400: b.eq            #0xb189d8
    // 0xb18404: mov             x0, x3
    // 0xb18408: r2 = Null
    //     0xb18408: mov             x2, NULL
    // 0xb1840c: r1 = Null
    //     0xb1840c: mov             x1, NULL
    // 0xb18410: r4 = LoadClassIdInstr(r0)
    //     0xb18410: ldur            x4, [x0, #-1]
    //     0xb18414: ubfx            x4, x4, #0xc, #0x14
    // 0xb18418: r17 = 4212
    //     0xb18418: mov             x17, #0x1074
    // 0xb1841c: cmp             x4, x17
    // 0xb18420: b.eq            #0xb18438
    // 0xb18424: r8 = FlexParentData
    //     0xb18424: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb18428: ldr             x8, [x8, #0x10]
    // 0xb1842c: r3 = Null
    //     0xb1842c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90818] Null
    //     0xb18430: ldr             x3, [x3, #0x818]
    // 0xb18434: r0 = DefaultTypeTest()
    //     0xb18434: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb18438: ldur            x0, [fp, #-0x40]
    // 0xb1843c: LoadField: r6 = r0->field_13
    //     0xb1843c: ldur            w6, [x0, #0x13]
    // 0xb18440: DecompressPointer r6
    //     0xb18440: add             x6, x6, HEAP, lsl #32
    // 0xb18444: ldur            x10, [fp, #-0x70]
    // 0xb18448: ldur            x9, [fp, #-0x78]
    // 0xb1844c: ldur            x8, [fp, #-0x80]
    // 0xb18450: ldur            x7, [fp, #-0x88]
    // 0xb18454: ldur            d1, [fp, #-0xa8]
    // 0xb18458: ldur            d0, [fp, #-0xb0]
    // 0xb1845c: ldur            x3, [fp, #-8]
    // 0xb18460: b               #0xb1819c
    // 0xb18464: mov             v3.16b, v0.16b
    // 0xb18468: ldur            d0, [fp, #-0x90]
    // 0xb1846c: mov             x0, x10
    // 0xb18470: d2 = 0.000000
    //     0xb18470: eor             v2.16b, v2.16b, v2.16b
    // 0xb18474: fsub            d4, d0, d1
    // 0xb18478: fmax            v5.2d, v2.2d, v4.2d
    // 0xb1847c: scvtf           d4, x0
    // 0xb18480: fdiv            d6, d5, d4
    // 0xb18484: stur            d6, [fp, #-0xa8]
    // 0xb18488: mov             x8, x0
    // 0xb1848c: ldur            x7, [fp, #-0x58]
    // 0xb18490: ldur            x6, [fp, #-0x60]
    // 0xb18494: ldur            x5, [fp, #-0x50]
    // 0xb18498: ldur            x4, [fp, #-8]
    // 0xb1849c: ldur            x3, [fp, #-0x38]
    // 0xb184a0: stur            x8, [fp, #-0x48]
    // 0xb184a4: stur            x7, [fp, #-0x30]
    // 0xb184a8: stur            x6, [fp, #-0x40]
    // 0xb184ac: stur            x5, [fp, #-0x58]
    // 0xb184b0: stur            d3, [fp, #-0x98]
    // 0xb184b4: stur            d1, [fp, #-0xa0]
    // 0xb184b8: CheckStackOverflow
    //     0xb184b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb184bc: cmp             SP, x16
    //     0xb184c0: b.ls            #0xb189dc
    // 0xb184c4: cmp             w5, NULL
    // 0xb184c8: b.eq            #0xb18750
    // 0xb184cc: cmp             x8, #0
    // 0xb184d0: b.le            #0xb18750
    // 0xb184d4: LoadField: r9 = r5->field_7
    //     0xb184d4: ldur            w9, [x5, #7]
    // 0xb184d8: DecompressPointer r9
    //     0xb184d8: add             x9, x9, HEAP, lsl #32
    // 0xb184dc: stur            x9, [fp, #-0x28]
    // 0xb184e0: cmp             w9, NULL
    // 0xb184e4: b.eq            #0xb189e4
    // 0xb184e8: mov             x0, x9
    // 0xb184ec: r2 = Null
    //     0xb184ec: mov             x2, NULL
    // 0xb184f0: r1 = Null
    //     0xb184f0: mov             x1, NULL
    // 0xb184f4: r4 = LoadClassIdInstr(r0)
    //     0xb184f4: ldur            x4, [x0, #-1]
    //     0xb184f8: ubfx            x4, x4, #0xc, #0x14
    // 0xb184fc: r17 = 4212
    //     0xb184fc: mov             x17, #0x1074
    // 0xb18500: cmp             x4, x17
    // 0xb18504: b.eq            #0xb1851c
    // 0xb18508: r8 = FlexParentData
    //     0xb18508: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb1850c: ldr             x8, [x8, #0x10]
    // 0xb18510: r3 = Null
    //     0xb18510: add             x3, PP, #0x90, lsl #12  ; [pp+0x90828] Null
    //     0xb18514: ldr             x3, [x3, #0x828]
    // 0xb18518: r0 = DefaultTypeTest()
    //     0xb18518: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb1851c: ldur            x0, [fp, #-0x28]
    // 0xb18520: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb18520: ldur            w1, [x0, #0x17]
    // 0xb18524: DecompressPointer r1
    //     0xb18524: add             x1, x1, HEAP, lsl #32
    // 0xb18528: cmp             w1, NULL
    // 0xb1852c: b.ne            #0xb18538
    // 0xb18530: r0 = 0
    //     0xb18530: mov             x0, #0
    // 0xb18534: b               #0xb18544
    // 0xb18538: r0 = LoadInt32Instr(r1)
    //     0xb18538: sbfx            x0, x1, #1, #0x1f
    //     0xb1853c: tbz             w1, #0, #0xb18544
    //     0xb18540: ldur            x0, [x1, #7]
    // 0xb18544: cbnz            x0, #0xb18560
    // 0xb18548: ldur            x8, [fp, #-0x48]
    // 0xb1854c: ldur            x7, [fp, #-0x30]
    // 0xb18550: ldur            x6, [fp, #-0x40]
    // 0xb18554: ldur            d1, [fp, #-0xa0]
    // 0xb18558: ldur            d3, [fp, #-0x98]
    // 0xb1855c: b               #0xb186c0
    // 0xb18560: ldur            x5, [fp, #-8]
    // 0xb18564: ldur            x4, [fp, #-0x38]
    // 0xb18568: ldur            d1, [fp, #-0xa8]
    // 0xb1856c: ldur            x1, [fp, #-0x48]
    // 0xb18570: ldur            d2, [fp, #-0xa0]
    // 0xb18574: ldur            d3, [fp, #-0x98]
    // 0xb18578: sub             x6, x1, x0
    // 0xb1857c: stur            x6, [fp, #-0x70]
    // 0xb18580: scvtf           d0, x0
    // 0xb18584: fmul            d4, d1, d0
    // 0xb18588: mov             x1, x5
    // 0xb1858c: ldur            x2, [fp, #-0x58]
    // 0xb18590: ldur            x3, [fp, #-0x10]
    // 0xb18594: mov             v0.16b, v4.16b
    // 0xb18598: r0 = _constraintsForFlexChild()
    //     0xb18598: bl              #0xb18c08  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_constraintsForFlexChild
    // 0xb1859c: mov             x1, x0
    // 0xb185a0: stur            x1, [fp, #-0x28]
    // 0xb185a4: ldur            x16, [fp, #-0x20]
    // 0xb185a8: ldur            lr, [fp, #-0x58]
    // 0xb185ac: stp             lr, x16, [SP, #8]
    // 0xb185b0: str             x1, [SP]
    // 0xb185b4: ldur            x0, [fp, #-0x20]
    // 0xb185b8: ClosureCall
    //     0xb185b8: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb185bc: ldur            x2, [x0, #0x1f]
    //     0xb185c0: blr             x2
    // 0xb185c4: mov             x1, x0
    // 0xb185c8: ldur            x0, [fp, #-8]
    // 0xb185cc: LoadField: r2 = r0->field_63
    //     0xb185cc: ldur            w2, [x0, #0x63]
    // 0xb185d0: DecompressPointer r2
    //     0xb185d0: add             x2, x2, HEAP, lsl #32
    // 0xb185d4: r0 = _AxisSize._convert()
    //     0xb185d4: bl              #0xb191dc  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize._convert
    // 0xb185d8: LoadField: d0 = r0->field_7
    //     0xb185d8: ldur            d0, [x0, #7]
    // 0xb185dc: ldur            d1, [fp, #-0xa0]
    // 0xb185e0: fadd            d2, d1, d0
    // 0xb185e4: stur            d2, [fp, #-0xb8]
    // 0xb185e8: LoadField: d0 = r0->field_f
    //     0xb185e8: ldur            d0, [x0, #0xf]
    // 0xb185ec: ldur            d3, [fp, #-0x98]
    // 0xb185f0: stur            d0, [fp, #-0xb0]
    // 0xb185f4: fmax            v1.2d, v3.2d, v0.2d
    // 0xb185f8: stur            d1, [fp, #-0xa0]
    // 0xb185fc: r0 = Size()
    //     0xb185fc: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb18600: mov             x1, x0
    // 0xb18604: ldur            d0, [fp, #-0xb8]
    // 0xb18608: stur            x1, [fp, #-0x60]
    // 0xb1860c: StoreField: r1->field_7 = d0
    //     0xb1860c: stur            d0, [x1, #7]
    // 0xb18610: ldur            d1, [fp, #-0xa0]
    // 0xb18614: StoreField: r1->field_f = d1
    //     0xb18614: stur            d1, [x1, #0xf]
    // 0xb18618: ldur            x2, [fp, #-0x38]
    // 0xb1861c: cmp             w2, NULL
    // 0xb18620: b.ne            #0xb1862c
    // 0xb18624: r2 = Null
    //     0xb18624: mov             x2, NULL
    // 0xb18628: b               #0xb18654
    // 0xb1862c: ldur            x16, [fp, #-0x18]
    // 0xb18630: ldur            lr, [fp, #-0x58]
    // 0xb18634: stp             lr, x16, [SP, #0x10]
    // 0xb18638: ldur            x16, [fp, #-0x28]
    // 0xb1863c: stp             x2, x16, [SP]
    // 0xb18640: ldur            x0, [fp, #-0x18]
    // 0xb18644: ClosureCall
    //     0xb18644: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xb18648: ldur            x2, [x0, #0x1f]
    //     0xb1864c: blr             x2
    // 0xb18650: mov             x2, x0
    // 0xb18654: cmp             w2, NULL
    // 0xb18658: b.ne            #0xb18664
    // 0xb1865c: r2 = Null
    //     0xb1865c: mov             x2, NULL
    // 0xb18660: b               #0xb186a4
    // 0xb18664: ldur            d0, [fp, #-0xb0]
    // 0xb18668: LoadField: d1 = r2->field_7
    //     0xb18668: ldur            d1, [x2, #7]
    // 0xb1866c: fsub            d2, d0, d1
    // 0xb18670: r3 = inline_Allocate_Double()
    //     0xb18670: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb18674: add             x3, x3, #0x10
    //     0xb18678: cmp             x0, x3
    //     0xb1867c: b.ls            #0xb189e8
    //     0xb18680: str             x3, [THR, #0x60]  ; THR::top
    //     0xb18684: sub             x3, x3, #0xf
    //     0xb18688: mov             x0, #0xe19c
    //     0xb1868c: movk            x0, #3, lsl #16
    //     0xb18690: stur            x0, [x3, #-1]
    // 0xb18694: dmb             ishst
    // 0xb18698: StoreField: r3->field_7 = d2
    //     0xb18698: stur            d2, [x3, #7]
    // 0xb1869c: r0 = AllocateRecord2()
    //     0xb1869c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb186a0: mov             x2, x0
    // 0xb186a4: ldur            x1, [fp, #-0x30]
    // 0xb186a8: r0 = _AscentDescent.+()
    //     0xb186a8: bl              #0xb18dec  ; [package:flutter/src/rendering/flex.dart] ::_AscentDescent.+
    // 0xb186ac: ldur            x8, [fp, #-0x70]
    // 0xb186b0: mov             x7, x0
    // 0xb186b4: ldur            x6, [fp, #-0x60]
    // 0xb186b8: ldur            d1, [fp, #-0xb8]
    // 0xb186bc: ldur            d3, [fp, #-0xa0]
    // 0xb186c0: ldur            x0, [fp, #-0x58]
    // 0xb186c4: stur            x8, [fp, #-0x48]
    // 0xb186c8: stur            x7, [fp, #-0x60]
    // 0xb186cc: stur            x6, [fp, #-0x68]
    // 0xb186d0: stur            d1, [fp, #-0x98]
    // 0xb186d4: stur            d3, [fp, #-0xa0]
    // 0xb186d8: LoadField: r3 = r0->field_7
    //     0xb186d8: ldur            w3, [x0, #7]
    // 0xb186dc: DecompressPointer r3
    //     0xb186dc: add             x3, x3, HEAP, lsl #32
    // 0xb186e0: stur            x3, [fp, #-0x28]
    // 0xb186e4: cmp             w3, NULL
    // 0xb186e8: b.eq            #0xb18a04
    // 0xb186ec: mov             x0, x3
    // 0xb186f0: r2 = Null
    //     0xb186f0: mov             x2, NULL
    // 0xb186f4: r1 = Null
    //     0xb186f4: mov             x1, NULL
    // 0xb186f8: r4 = LoadClassIdInstr(r0)
    //     0xb186f8: ldur            x4, [x0, #-1]
    //     0xb186fc: ubfx            x4, x4, #0xc, #0x14
    // 0xb18700: r17 = 4212
    //     0xb18700: mov             x17, #0x1074
    // 0xb18704: cmp             x4, x17
    // 0xb18708: b.eq            #0xb18720
    // 0xb1870c: r8 = FlexParentData
    //     0xb1870c: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb18710: ldr             x8, [x8, #0x10]
    // 0xb18714: r3 = Null
    //     0xb18714: add             x3, PP, #0x90, lsl #12  ; [pp+0x90838] Null
    //     0xb18718: ldr             x3, [x3, #0x838]
    // 0xb1871c: r0 = DefaultTypeTest()
    //     0xb1871c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb18720: ldur            x0, [fp, #-0x28]
    // 0xb18724: LoadField: r5 = r0->field_13
    //     0xb18724: ldur            w5, [x0, #0x13]
    // 0xb18728: DecompressPointer r5
    //     0xb18728: add             x5, x5, HEAP, lsl #32
    // 0xb1872c: ldur            x8, [fp, #-0x48]
    // 0xb18730: ldur            x7, [fp, #-0x60]
    // 0xb18734: ldur            x6, [fp, #-0x68]
    // 0xb18738: ldur            d3, [fp, #-0xa0]
    // 0xb1873c: ldur            d1, [fp, #-0x98]
    // 0xb18740: ldur            d0, [fp, #-0x90]
    // 0xb18744: ldur            d6, [fp, #-0xa8]
    // 0xb18748: d2 = 0.000000
    //     0xb18748: eor             v2.16b, v2.16b, v2.16b
    // 0xb1874c: b               #0xb18498
    // 0xb18750: ldur            x0, [fp, #-0x30]
    // 0xb18754: cmp             w0, NULL
    // 0xb18758: b.ne            #0xb18764
    // 0xb1875c: r2 = Instance_Size
    //     0xb1875c: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb18760: b               #0xb187d0
    // 0xb18764: LoadField: r1 = r0->field_b
    //     0xb18764: ldur            w1, [x0, #0xb]
    // 0xb18768: cmp             w1, #4
    // 0xb1876c: b.ne            #0xb187cc
    // 0xb18770: LoadField: r1 = r0->field_f
    //     0xb18770: ldur            w1, [x0, #0xf]
    // 0xb18774: DecompressPointer r1
    //     0xb18774: add             x1, x1, HEAP, lsl #32
    // 0xb18778: r2 = 60
    //     0xb18778: mov             x2, #0x3c
    // 0xb1877c: branchIfSmi(r1, 0xb18788)
    //     0xb1877c: tbz             w1, #0, #0xb18788
    // 0xb18780: r2 = LoadClassIdInstr(r1)
    //     0xb18780: ldur            x2, [x1, #-1]
    //     0xb18784: ubfx            x2, x2, #0xc, #0x14
    // 0xb18788: cmp             x2, #0x3e
    // 0xb1878c: b.ne            #0xb187cc
    // 0xb18790: LoadField: r2 = r0->field_13
    //     0xb18790: ldur            w2, [x0, #0x13]
    // 0xb18794: DecompressPointer r2
    //     0xb18794: add             x2, x2, HEAP, lsl #32
    // 0xb18798: r3 = 60
    //     0xb18798: mov             x3, #0x3c
    // 0xb1879c: branchIfSmi(r2, 0xb187a8)
    //     0xb1879c: tbz             w2, #0, #0xb187a8
    // 0xb187a0: r3 = LoadClassIdInstr(r2)
    //     0xb187a0: ldur            x3, [x2, #-1]
    //     0xb187a4: ubfx            x3, x3, #0xc, #0x14
    // 0xb187a8: cmp             x3, #0x3e
    // 0xb187ac: b.ne            #0xb187cc
    // 0xb187b0: stp             x2, x1, [SP]
    // 0xb187b4: r0 = +()
    //     0xb187b4: bl              #0x13dce50  ; [dart:core] _Double::+
    // 0xb187b8: LoadField: d0 = r0->field_7
    //     0xb187b8: ldur            d0, [x0, #7]
    // 0xb187bc: d1 = 0.000000
    //     0xb187bc: eor             v1.16b, v1.16b, v1.16b
    // 0xb187c0: r0 = _AxisSize.()
    //     0xb187c0: bl              #0xb18bd4  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.
    // 0xb187c4: mov             x2, x0
    // 0xb187c8: b               #0xb187d0
    // 0xb187cc: r2 = Null
    //     0xb187cc: mov             x2, NULL
    // 0xb187d0: ldur            x0, [fp, #-8]
    // 0xb187d4: ldur            x1, [fp, #-0x40]
    // 0xb187d8: r0 = _AxisSize.+()
    //     0xb187d8: bl              #0xb18b88  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.+
    // 0xb187dc: mov             x1, x0
    // 0xb187e0: ldur            x0, [fp, #-8]
    // 0xb187e4: stur            x1, [fp, #-0x18]
    // 0xb187e8: LoadField: r2 = r0->field_6b
    //     0xb187e8: ldur            w2, [x0, #0x6b]
    // 0xb187ec: DecompressPointer r2
    //     0xb187ec: add             x2, x2, HEAP, lsl #32
    // 0xb187f0: r16 = Instance_MainAxisSize
    //     0xb187f0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15828] Obj!MainAxisSize@12c4621
    //     0xb187f4: ldr             x16, [x16, #0x828]
    // 0xb187f8: cmp             w2, w16
    // 0xb187fc: r16 = true
    //     0xb187fc: add             x16, NULL, #0x20  ; true
    // 0xb18800: r17 = false
    //     0xb18800: add             x17, NULL, #0x30  ; false
    // 0xb18804: csel            x3, x16, x17, eq
    // 0xb18808: tbnz            w3, #4, #0xb18860
    // 0xb1880c: ldur            d0, [fp, #-0x90]
    // 0xb18810: mov             x4, v0.d[0]
    // 0xb18814: and             x4, x4, #0x7fffffffffffffff
    // 0xb18818: r17 = 9218868437227405312
    //     0xb18818: mov             x17, #0x7ff0000000000000
    // 0xb1881c: cmp             x4, x17
    // 0xb18820: b.eq            #0xb18860
    // 0xb18824: fcmp            d0, d0
    // 0xb18828: b.vs            #0xb18860
    // 0xb1882c: r2 = inline_Allocate_Double()
    //     0xb1882c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb18830: add             x2, x2, #0x10
    //     0xb18834: cmp             x3, x2
    //     0xb18838: b.ls            #0xb18a08
    //     0xb1883c: str             x2, [THR, #0x60]  ; THR::top
    //     0xb18840: sub             x2, x2, #0xf
    //     0xb18844: mov             x3, #0xe19c
    //     0xb18848: movk            x3, #3, lsl #16
    //     0xb1884c: stur            x3, [x2, #-1]
    // 0xb18850: dmb             ishst
    // 0xb18854: StoreField: r2->field_7 = d0
    //     0xb18854: stur            d0, [x2, #7]
    // 0xb18858: mov             x3, x2
    // 0xb1885c: b               #0xb188b0
    // 0xb18860: tbz             w3, #4, #0xb18874
    // 0xb18864: r16 = Instance_MainAxisSize
    //     0xb18864: add             x16, PP, #0x17, lsl #12  ; [pp+0x17200] Obj!MainAxisSize@12c4601
    //     0xb18868: ldr             x16, [x16, #0x200]
    // 0xb1886c: cmp             w2, w16
    // 0xb18870: b.ne            #0xb188ac
    // 0xb18874: LoadField: d0 = r1->field_7
    //     0xb18874: ldur            d0, [x1, #7]
    // 0xb18878: r2 = inline_Allocate_Double()
    //     0xb18878: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb1887c: add             x2, x2, #0x10
    //     0xb18880: cmp             x3, x2
    //     0xb18884: b.ls            #0xb18a24
    //     0xb18888: str             x2, [THR, #0x60]  ; THR::top
    //     0xb1888c: sub             x2, x2, #0xf
    //     0xb18890: mov             x3, #0xe19c
    //     0xb18894: movk            x3, #3, lsl #16
    //     0xb18898: stur            x3, [x2, #-1]
    // 0xb1889c: dmb             ishst
    // 0xb188a0: StoreField: r2->field_7 = d0
    //     0xb188a0: stur            d0, [x2, #7]
    // 0xb188a4: mov             x3, x2
    // 0xb188a8: b               #0xb188b0
    // 0xb188ac: r3 = Null
    //     0xb188ac: mov             x3, NULL
    // 0xb188b0: ldur            x2, [fp, #-0x30]
    // 0xb188b4: LoadField: d0 = r1->field_f
    //     0xb188b4: ldur            d0, [x1, #0xf]
    // 0xb188b8: LoadField: d1 = r3->field_7
    //     0xb188b8: ldur            d1, [x3, #7]
    // 0xb188bc: r0 = _AxisSize.()
    //     0xb188bc: bl              #0xb18bd4  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.
    // 0xb188c0: mov             x1, x0
    // 0xb188c4: ldur            x0, [fp, #-8]
    // 0xb188c8: LoadField: r3 = r0->field_63
    //     0xb188c8: ldur            w3, [x0, #0x63]
    // 0xb188cc: DecompressPointer r3
    //     0xb188cc: add             x3, x3, HEAP, lsl #32
    // 0xb188d0: ldur            x2, [fp, #-0x10]
    // 0xb188d4: r0 = _AxisSize.applyConstraints()
    //     0xb188d4: bl              #0xb18ad0  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize.applyConstraints
    // 0xb188d8: stur            x0, [fp, #-0x20]
    // 0xb188dc: LoadField: d0 = r0->field_7
    //     0xb188dc: ldur            d0, [x0, #7]
    // 0xb188e0: ldur            x1, [fp, #-0x18]
    // 0xb188e4: LoadField: d1 = r1->field_7
    //     0xb188e4: ldur            d1, [x1, #7]
    // 0xb188e8: fsub            d2, d0, d1
    // 0xb188ec: ldur            x1, [fp, #-0x30]
    // 0xb188f0: stur            d2, [fp, #-0x90]
    // 0xb188f4: cmp             w1, NULL
    // 0xb188f8: b.ne            #0xb18904
    // 0xb188fc: r2 = Null
    //     0xb188fc: mov             x2, NULL
    // 0xb18900: b               #0xb1890c
    // 0xb18904: LoadField: r2 = r1->field_f
    //     0xb18904: ldur            w2, [x1, #0xf]
    // 0xb18908: DecompressPointer r2
    //     0xb18908: add             x2, x2, HEAP, lsl #32
    // 0xb1890c: ldur            x1, [fp, #-0x50]
    // 0xb18910: stur            x2, [fp, #-0x10]
    // 0xb18914: cmp             w1, NULL
    // 0xb18918: b.ne            #0xb18924
    // 0xb1891c: r1 = Null
    //     0xb1891c: mov             x1, NULL
    // 0xb18920: b               #0xb18954
    // 0xb18924: ldur            d0, [fp, #-0xa8]
    // 0xb18928: r1 = inline_Allocate_Double()
    //     0xb18928: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xb1892c: add             x1, x1, #0x10
    //     0xb18930: cmp             x3, x1
    //     0xb18934: b.ls            #0xb18a40
    //     0xb18938: str             x1, [THR, #0x60]  ; THR::top
    //     0xb1893c: sub             x1, x1, #0xf
    //     0xb18940: mov             x3, #0xe19c
    //     0xb18944: movk            x3, #3, lsl #16
    //     0xb18948: stur            x3, [x1, #-1]
    // 0xb1894c: dmb             ishst
    // 0xb18950: StoreField: r1->field_7 = d0
    //     0xb18950: stur            d0, [x1, #7]
    // 0xb18954: stur            x1, [fp, #-8]
    // 0xb18958: r0 = _LayoutSizes()
    //     0xb18958: bl              #0xb18ac4  ; Allocate_LayoutSizesStub -> _LayoutSizes (size=0x1c)
    // 0xb1895c: mov             x1, x0
    // 0xb18960: ldur            x0, [fp, #-0x20]
    // 0xb18964: StoreField: r1->field_7 = r0
    //     0xb18964: stur            w0, [x1, #7]
    // 0xb18968: ldur            x0, [fp, #-0x10]
    // 0xb1896c: StoreField: r1->field_13 = r0
    //     0xb1896c: stur            w0, [x1, #0x13]
    // 0xb18970: ldur            d0, [fp, #-0x90]
    // 0xb18974: StoreField: r1->field_b = d0
    //     0xb18974: stur            d0, [x1, #0xb]
    // 0xb18978: ldur            x0, [fp, #-8]
    // 0xb1897c: ArrayStore: r1[0] = r0  ; List_4
    //     0xb1897c: stur            w0, [x1, #0x17]
    // 0xb18980: mov             x0, x1
    // 0xb18984: LeaveFrame
    //     0xb18984: mov             SP, fp
    //     0xb18988: ldp             fp, lr, [SP], #0x10
    // 0xb1898c: ret
    //     0xb1898c: ret             
    // 0xb18990: r1 = Null
    //     0xb18990: mov             x1, NULL
    // 0xb18994: r2 = "To use CrossAxisAlignment.baseline, you must also specify which baseline to use using the \"textBaseline\" argument."
    //     0xb18994: add             x2, PP, #0x90, lsl #12  ; [pp+0x90848] "To use CrossAxisAlignment.baseline, you must also specify which baseline to use using the \"textBaseline\" argument."
    //     0xb18998: ldr             x2, [x2, #0x848]
    // 0xb1899c: r0 = FlutterError()
    //     0xb1899c: bl              #0x84eb60  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0xb189a0: r0 = Throw()
    //     0xb189a0: bl              #0x13ddb2c  ; ThrowStub
    // 0xb189a4: brk             #0
    // 0xb189a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb189a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb189ac: b               #0xb18098
    // 0xb189b0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb189b0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb189b4: b               #0xb181cc
    // 0xb189b8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb189b8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb189bc: SaveReg d2
    //     0xb189bc: str             q2, [SP, #-0x10]!
    // 0xb189c0: SaveReg r2
    //     0xb189c0: str             x2, [SP, #-8]!
    // 0xb189c4: r0 = AllocateDouble()
    //     0xb189c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb189c8: mov             x3, x0
    // 0xb189cc: RestoreReg r2
    //     0xb189cc: ldr             x2, [SP], #8
    // 0xb189d0: RestoreReg d2
    //     0xb189d0: ldr             q2, [SP], #0x10
    // 0xb189d4: b               #0xb183a8
    // 0xb189d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb189d8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb189dc: r0 = StackOverflowSharedWithFPURegs()
    //     0xb189dc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb189e0: b               #0xb184c4
    // 0xb189e4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb189e4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb189e8: SaveReg d2
    //     0xb189e8: str             q2, [SP, #-0x10]!
    // 0xb189ec: SaveReg r2
    //     0xb189ec: str             x2, [SP, #-8]!
    // 0xb189f0: r0 = AllocateDouble()
    //     0xb189f0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb189f4: mov             x3, x0
    // 0xb189f8: RestoreReg r2
    //     0xb189f8: ldr             x2, [SP], #8
    // 0xb189fc: RestoreReg d2
    //     0xb189fc: ldr             q2, [SP], #0x10
    // 0xb18a00: b               #0xb18698
    // 0xb18a04: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb18a04: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb18a08: SaveReg d0
    //     0xb18a08: str             q0, [SP, #-0x10]!
    // 0xb18a0c: stp             x0, x1, [SP, #-0x10]!
    // 0xb18a10: r0 = AllocateDouble()
    //     0xb18a10: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb18a14: mov             x2, x0
    // 0xb18a18: ldp             x0, x1, [SP], #0x10
    // 0xb18a1c: RestoreReg d0
    //     0xb18a1c: ldr             q0, [SP], #0x10
    // 0xb18a20: b               #0xb18854
    // 0xb18a24: SaveReg d0
    //     0xb18a24: str             q0, [SP, #-0x10]!
    // 0xb18a28: stp             x0, x1, [SP, #-0x10]!
    // 0xb18a2c: r0 = AllocateDouble()
    //     0xb18a2c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb18a30: mov             x2, x0
    // 0xb18a34: ldp             x0, x1, [SP], #0x10
    // 0xb18a38: RestoreReg d0
    //     0xb18a38: ldr             q0, [SP], #0x10
    // 0xb18a3c: b               #0xb188a0
    // 0xb18a40: stp             q0, q2, [SP, #-0x20]!
    // 0xb18a44: stp             x0, x2, [SP, #-0x10]!
    // 0xb18a48: r0 = AllocateDouble()
    //     0xb18a48: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb18a4c: mov             x1, x0
    // 0xb18a50: ldp             x0, x2, [SP], #0x10
    // 0xb18a54: ldp             q0, q2, [SP], #0x20
    // 0xb18a58: b               #0xb18950
  }
  _ _constraintsForFlexChild(/* No info */) {
    // ** addr: 0xb18c08, size: 0x1e4
    // 0xb18c08: EnterFrame
    //     0xb18c08: stp             fp, lr, [SP, #-0x10]!
    //     0xb18c0c: mov             fp, SP
    // 0xb18c10: AllocStack(0x38)
    //     0xb18c10: sub             SP, SP, #0x38
    // 0xb18c14: SetupParameters(RenderFlex this /* r1 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0xb18c14: mov             x4, x1
    //     0xb18c18: stur            x1, [fp, #-0x10]
    //     0xb18c1c: stur            x3, [fp, #-0x18]
    //     0xb18c20: stur            d0, [fp, #-0x20]
    // 0xb18c24: LoadField: r5 = r2->field_7
    //     0xb18c24: ldur            w5, [x2, #7]
    // 0xb18c28: DecompressPointer r5
    //     0xb18c28: add             x5, x5, HEAP, lsl #32
    // 0xb18c2c: stur            x5, [fp, #-8]
    // 0xb18c30: cmp             w5, NULL
    // 0xb18c34: b.eq            #0xb18de8
    // 0xb18c38: mov             x0, x5
    // 0xb18c3c: r2 = Null
    //     0xb18c3c: mov             x2, NULL
    // 0xb18c40: r1 = Null
    //     0xb18c40: mov             x1, NULL
    // 0xb18c44: r4 = LoadClassIdInstr(r0)
    //     0xb18c44: ldur            x4, [x0, #-1]
    //     0xb18c48: ubfx            x4, x4, #0xc, #0x14
    // 0xb18c4c: r17 = 4212
    //     0xb18c4c: mov             x17, #0x1074
    // 0xb18c50: cmp             x4, x17
    // 0xb18c54: b.eq            #0xb18c6c
    // 0xb18c58: r8 = FlexParentData
    //     0xb18c58: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb18c5c: ldr             x8, [x8, #0x10]
    // 0xb18c60: r3 = Null
    //     0xb18c60: add             x3, PP, #0x90, lsl #12  ; [pp+0x90850] Null
    //     0xb18c64: ldr             x3, [x3, #0x850]
    // 0xb18c68: r0 = DefaultTypeTest()
    //     0xb18c68: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb18c6c: ldur            x0, [fp, #-8]
    // 0xb18c70: LoadField: r1 = r0->field_1b
    //     0xb18c70: ldur            w1, [x0, #0x1b]
    // 0xb18c74: DecompressPointer r1
    //     0xb18c74: add             x1, x1, HEAP, lsl #32
    // 0xb18c78: cmp             w1, NULL
    // 0xb18c7c: b.ne            #0xb18c8c
    // 0xb18c80: r0 = Instance_FlexFit
    //     0xb18c80: add             x0, PP, #0x15, lsl #12  ; [pp+0x15880] Obj!FlexFit@12c4641
    //     0xb18c84: ldr             x0, [x0, #0x880]
    // 0xb18c88: b               #0xb18c90
    // 0xb18c8c: mov             x0, x1
    // 0xb18c90: LoadField: r1 = r0->field_7
    //     0xb18c90: ldur            x1, [x0, #7]
    // 0xb18c94: cmp             x1, #0
    // 0xb18c98: b.gt            #0xb18ca4
    // 0xb18c9c: ldur            d0, [fp, #-0x20]
    // 0xb18ca0: b               #0xb18ca8
    // 0xb18ca4: d0 = 0.000000
    //     0xb18ca4: eor             v0.16b, v0.16b, v0.16b
    // 0xb18ca8: ldur            x0, [fp, #-0x10]
    // 0xb18cac: stur            d0, [fp, #-0x38]
    // 0xb18cb0: LoadField: r1 = r0->field_6f
    //     0xb18cb0: ldur            w1, [x0, #0x6f]
    // 0xb18cb4: DecompressPointer r1
    //     0xb18cb4: add             x1, x1, HEAP, lsl #32
    // 0xb18cb8: r16 = Instance_CrossAxisAlignment
    //     0xb18cb8: add             x16, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xb18cbc: ldr             x16, [x16, #0xc40]
    // 0xb18cc0: cmp             w1, w16
    // 0xb18cc4: b.ne            #0xb18cd0
    // 0xb18cc8: r1 = true
    //     0xb18cc8: add             x1, NULL, #0x20  ; true
    // 0xb18ccc: b               #0xb18d1c
    // 0xb18cd0: r16 = Instance_CrossAxisAlignment
    //     0xb18cd0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xb18cd4: ldr             x16, [x16, #0x830]
    // 0xb18cd8: cmp             w1, w16
    // 0xb18cdc: b.eq            #0xb18d10
    // 0xb18ce0: r16 = Instance_CrossAxisAlignment
    //     0xb18ce0: add             x16, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xb18ce4: ldr             x16, [x16, #0x888]
    // 0xb18ce8: cmp             w1, w16
    // 0xb18cec: b.eq            #0xb18d10
    // 0xb18cf0: r16 = Instance_CrossAxisAlignment
    //     0xb18cf0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] Obj!CrossAxisAlignment@12c4501
    //     0xb18cf4: ldr             x16, [x16, #0xbd8]
    // 0xb18cf8: cmp             w1, w16
    // 0xb18cfc: b.eq            #0xb18d10
    // 0xb18d00: r16 = Instance_CrossAxisAlignment
    //     0xb18d00: add             x16, PP, #0x89, lsl #12  ; [pp+0x89a68] Obj!CrossAxisAlignment@12c44e1
    //     0xb18d04: ldr             x16, [x16, #0xa68]
    // 0xb18d08: cmp             w1, w16
    // 0xb18d0c: b.ne            #0xb18d18
    // 0xb18d10: r1 = false
    //     0xb18d10: add             x1, NULL, #0x30  ; false
    // 0xb18d14: b               #0xb18d1c
    // 0xb18d18: r1 = Null
    //     0xb18d18: mov             x1, NULL
    // 0xb18d1c: LoadField: r2 = r0->field_63
    //     0xb18d1c: ldur            w2, [x0, #0x63]
    // 0xb18d20: DecompressPointer r2
    //     0xb18d20: add             x2, x2, HEAP, lsl #32
    // 0xb18d24: LoadField: r0 = r2->field_7
    //     0xb18d24: ldur            x0, [x2, #7]
    // 0xb18d28: cmp             x0, #0
    // 0xb18d2c: b.gt            #0xb18d8c
    // 0xb18d30: r16 = true
    //     0xb18d30: add             x16, NULL, #0x20  ; true
    // 0xb18d34: cmp             w1, w16
    // 0xb18d38: b.ne            #0xb18d4c
    // 0xb18d3c: ldur            x0, [fp, #-0x18]
    // 0xb18d40: LoadField: d1 = r0->field_1f
    //     0xb18d40: ldur            d1, [x0, #0x1f]
    // 0xb18d44: mov             v2.16b, v1.16b
    // 0xb18d48: b               #0xb18d54
    // 0xb18d4c: ldur            x0, [fp, #-0x18]
    // 0xb18d50: d2 = 0.000000
    //     0xb18d50: eor             v2.16b, v2.16b, v2.16b
    // 0xb18d54: ldur            d1, [fp, #-0x20]
    // 0xb18d58: stur            d2, [fp, #-0x30]
    // 0xb18d5c: LoadField: d3 = r0->field_1f
    //     0xb18d5c: ldur            d3, [x0, #0x1f]
    // 0xb18d60: stur            d3, [fp, #-0x28]
    // 0xb18d64: r0 = BoxConstraints()
    //     0xb18d64: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb18d68: ldur            d0, [fp, #-0x38]
    // 0xb18d6c: StoreField: r0->field_7 = d0
    //     0xb18d6c: stur            d0, [x0, #7]
    // 0xb18d70: ldur            d1, [fp, #-0x20]
    // 0xb18d74: StoreField: r0->field_f = d1
    //     0xb18d74: stur            d1, [x0, #0xf]
    // 0xb18d78: ldur            d0, [fp, #-0x30]
    // 0xb18d7c: ArrayStore: r0[0] = d0  ; List_8
    //     0xb18d7c: stur            d0, [x0, #0x17]
    // 0xb18d80: ldur            d0, [fp, #-0x28]
    // 0xb18d84: StoreField: r0->field_1f = d0
    //     0xb18d84: stur            d0, [x0, #0x1f]
    // 0xb18d88: b               #0xb18ddc
    // 0xb18d8c: ldur            x0, [fp, #-0x18]
    // 0xb18d90: ldur            d1, [fp, #-0x20]
    // 0xb18d94: r16 = true
    //     0xb18d94: add             x16, NULL, #0x20  ; true
    // 0xb18d98: cmp             w1, w16
    // 0xb18d9c: b.ne            #0xb18da8
    // 0xb18da0: LoadField: d2 = r0->field_f
    //     0xb18da0: ldur            d2, [x0, #0xf]
    // 0xb18da4: b               #0xb18dac
    // 0xb18da8: d2 = 0.000000
    //     0xb18da8: eor             v2.16b, v2.16b, v2.16b
    // 0xb18dac: stur            d2, [fp, #-0x30]
    // 0xb18db0: LoadField: d3 = r0->field_f
    //     0xb18db0: ldur            d3, [x0, #0xf]
    // 0xb18db4: stur            d3, [fp, #-0x28]
    // 0xb18db8: r0 = BoxConstraints()
    //     0xb18db8: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb18dbc: ldur            d0, [fp, #-0x30]
    // 0xb18dc0: StoreField: r0->field_7 = d0
    //     0xb18dc0: stur            d0, [x0, #7]
    // 0xb18dc4: ldur            d0, [fp, #-0x28]
    // 0xb18dc8: StoreField: r0->field_f = d0
    //     0xb18dc8: stur            d0, [x0, #0xf]
    // 0xb18dcc: ldur            d0, [fp, #-0x38]
    // 0xb18dd0: ArrayStore: r0[0] = d0  ; List_8
    //     0xb18dd0: stur            d0, [x0, #0x17]
    // 0xb18dd4: ldur            d0, [fp, #-0x20]
    // 0xb18dd8: StoreField: r0->field_1f = d0
    //     0xb18dd8: stur            d0, [x0, #0x1f]
    // 0xb18ddc: LeaveFrame
    //     0xb18ddc: mov             SP, fp
    //     0xb18de0: ldp             fp, lr, [SP], #0x10
    // 0xb18de4: ret
    //     0xb18de4: ret             
    // 0xb18de8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb18de8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ _isBaselineAligned(/* No info */) {
    // ** addr: 0xb19268, size: 0x90
    // 0xb19268: LoadField: r2 = r1->field_6f
    //     0xb19268: ldur            w2, [x1, #0x6f]
    // 0xb1926c: DecompressPointer r2
    //     0xb1926c: add             x2, x2, HEAP, lsl #32
    // 0xb19270: r16 = Instance_CrossAxisAlignment
    //     0xb19270: add             x16, PP, #0x89, lsl #12  ; [pp+0x89a68] Obj!CrossAxisAlignment@12c44e1
    //     0xb19274: ldr             x16, [x16, #0xa68]
    // 0xb19278: cmp             w2, w16
    // 0xb1927c: b.ne            #0xb192a8
    // 0xb19280: LoadField: r3 = r1->field_63
    //     0xb19280: ldur            w3, [x1, #0x63]
    // 0xb19284: DecompressPointer r3
    //     0xb19284: add             x3, x3, HEAP, lsl #32
    // 0xb19288: LoadField: r1 = r3->field_7
    //     0xb19288: ldur            x1, [x3, #7]
    // 0xb1928c: cmp             x1, #0
    // 0xb19290: b.gt            #0xb1929c
    // 0xb19294: r1 = true
    //     0xb19294: add             x1, NULL, #0x20  ; true
    // 0xb19298: b               #0xb192a0
    // 0xb1929c: r1 = false
    //     0xb1929c: add             x1, NULL, #0x30  ; false
    // 0xb192a0: mov             x0, x1
    // 0xb192a4: b               #0xb192f4
    // 0xb192a8: r16 = Instance_CrossAxisAlignment
    //     0xb192a8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xb192ac: ldr             x16, [x16, #0x830]
    // 0xb192b0: cmp             w2, w16
    // 0xb192b4: b.eq            #0xb192e8
    // 0xb192b8: r16 = Instance_CrossAxisAlignment
    //     0xb192b8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xb192bc: ldr             x16, [x16, #0x888]
    // 0xb192c0: cmp             w2, w16
    // 0xb192c4: b.eq            #0xb192e8
    // 0xb192c8: r16 = Instance_CrossAxisAlignment
    //     0xb192c8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] Obj!CrossAxisAlignment@12c4501
    //     0xb192cc: ldr             x16, [x16, #0xbd8]
    // 0xb192d0: cmp             w2, w16
    // 0xb192d4: b.eq            #0xb192e8
    // 0xb192d8: r16 = Instance_CrossAxisAlignment
    //     0xb192d8: add             x16, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xb192dc: ldr             x16, [x16, #0xc40]
    // 0xb192e0: cmp             w2, w16
    // 0xb192e4: b.ne            #0xb192f0
    // 0xb192e8: r0 = false
    //     0xb192e8: add             x0, NULL, #0x30  ; false
    // 0xb192ec: b               #0xb192f4
    // 0xb192f0: r0 = Null
    //     0xb192f0: mov             x0, NULL
    // 0xb192f4: ret
    //     0xb192f4: ret             
  }
  _ _constraintsForNonFlexChild(/* No info */) {
    // ** addr: 0xb192f8, size: 0x160
    // 0xb192f8: EnterFrame
    //     0xb192f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb192fc: mov             fp, SP
    // 0xb19300: AllocStack(0x8)
    //     0xb19300: sub             SP, SP, #8
    // 0xb19304: LoadField: r0 = r1->field_6f
    //     0xb19304: ldur            w0, [x1, #0x6f]
    // 0xb19308: DecompressPointer r0
    //     0xb19308: add             x0, x0, HEAP, lsl #32
    // 0xb1930c: r16 = Instance_CrossAxisAlignment
    //     0xb1930c: add             x16, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xb19310: ldr             x16, [x16, #0xc40]
    // 0xb19314: cmp             w0, w16
    // 0xb19318: b.ne            #0xb19324
    // 0xb1931c: r0 = true
    //     0xb1931c: add             x0, NULL, #0x20  ; true
    // 0xb19320: b               #0xb19370
    // 0xb19324: r16 = Instance_CrossAxisAlignment
    //     0xb19324: add             x16, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xb19328: ldr             x16, [x16, #0x830]
    // 0xb1932c: cmp             w0, w16
    // 0xb19330: b.eq            #0xb19364
    // 0xb19334: r16 = Instance_CrossAxisAlignment
    //     0xb19334: add             x16, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xb19338: ldr             x16, [x16, #0x888]
    // 0xb1933c: cmp             w0, w16
    // 0xb19340: b.eq            #0xb19364
    // 0xb19344: r16 = Instance_CrossAxisAlignment
    //     0xb19344: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] Obj!CrossAxisAlignment@12c4501
    //     0xb19348: ldr             x16, [x16, #0xbd8]
    // 0xb1934c: cmp             w0, w16
    // 0xb19350: b.eq            #0xb19364
    // 0xb19354: r16 = Instance_CrossAxisAlignment
    //     0xb19354: add             x16, PP, #0x89, lsl #12  ; [pp+0x89a68] Obj!CrossAxisAlignment@12c44e1
    //     0xb19358: ldr             x16, [x16, #0xa68]
    // 0xb1935c: cmp             w0, w16
    // 0xb19360: b.ne            #0xb1936c
    // 0xb19364: r0 = false
    //     0xb19364: add             x0, NULL, #0x30  ; false
    // 0xb19368: b               #0xb19370
    // 0xb1936c: r0 = Null
    //     0xb1936c: mov             x0, NULL
    // 0xb19370: LoadField: r3 = r1->field_63
    //     0xb19370: ldur            w3, [x1, #0x63]
    // 0xb19374: DecompressPointer r3
    //     0xb19374: add             x3, x3, HEAP, lsl #32
    // 0xb19378: LoadField: r1 = r3->field_7
    //     0xb19378: ldur            x1, [x3, #7]
    // 0xb1937c: cmp             x1, #0
    // 0xb19380: b.gt            #0xb193e4
    // 0xb19384: r16 = true
    //     0xb19384: add             x16, NULL, #0x20  ; true
    // 0xb19388: cmp             w0, w16
    // 0xb1938c: b.ne            #0xb193b8
    // 0xb19390: LoadField: d0 = r2->field_1f
    //     0xb19390: ldur            d0, [x2, #0x1f]
    // 0xb19394: stur            d0, [fp, #-8]
    // 0xb19398: r0 = BoxConstraints()
    //     0xb19398: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb1939c: StoreField: r0->field_7 = rZR
    //     0xb1939c: stur            xzr, [x0, #7]
    // 0xb193a0: d0 = inf
    //     0xb193a0: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb193a4: StoreField: r0->field_f = d0
    //     0xb193a4: stur            d0, [x0, #0xf]
    // 0xb193a8: ldur            d0, [fp, #-8]
    // 0xb193ac: ArrayStore: r0[0] = d0  ; List_8
    //     0xb193ac: stur            d0, [x0, #0x17]
    // 0xb193b0: StoreField: r0->field_1f = d0
    //     0xb193b0: stur            d0, [x0, #0x1f]
    // 0xb193b4: b               #0xb1944c
    // 0xb193b8: d0 = inf
    //     0xb193b8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb193bc: LoadField: d1 = r2->field_1f
    //     0xb193bc: ldur            d1, [x2, #0x1f]
    // 0xb193c0: stur            d1, [fp, #-8]
    // 0xb193c4: r0 = BoxConstraints()
    //     0xb193c4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb193c8: StoreField: r0->field_7 = rZR
    //     0xb193c8: stur            xzr, [x0, #7]
    // 0xb193cc: d0 = inf
    //     0xb193cc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb193d0: StoreField: r0->field_f = d0
    //     0xb193d0: stur            d0, [x0, #0xf]
    // 0xb193d4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb193d4: stur            xzr, [x0, #0x17]
    // 0xb193d8: ldur            d0, [fp, #-8]
    // 0xb193dc: StoreField: r0->field_1f = d0
    //     0xb193dc: stur            d0, [x0, #0x1f]
    // 0xb193e0: b               #0xb1944c
    // 0xb193e4: d0 = inf
    //     0xb193e4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb193e8: r16 = true
    //     0xb193e8: add             x16, NULL, #0x20  ; true
    // 0xb193ec: cmp             w0, w16
    // 0xb193f0: b.ne            #0xb19420
    // 0xb193f4: LoadField: d1 = r2->field_f
    //     0xb193f4: ldur            d1, [x2, #0xf]
    // 0xb193f8: stur            d1, [fp, #-8]
    // 0xb193fc: r0 = BoxConstraints()
    //     0xb193fc: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb19400: ldur            d0, [fp, #-8]
    // 0xb19404: StoreField: r0->field_7 = d0
    //     0xb19404: stur            d0, [x0, #7]
    // 0xb19408: StoreField: r0->field_f = d0
    //     0xb19408: stur            d0, [x0, #0xf]
    // 0xb1940c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb1940c: stur            xzr, [x0, #0x17]
    // 0xb19410: d0 = inf
    //     0xb19410: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb19414: StoreField: r0->field_1f = d0
    //     0xb19414: stur            d0, [x0, #0x1f]
    // 0xb19418: mov             x1, x0
    // 0xb1941c: b               #0xb19448
    // 0xb19420: LoadField: d1 = r2->field_f
    //     0xb19420: ldur            d1, [x2, #0xf]
    // 0xb19424: stur            d1, [fp, #-8]
    // 0xb19428: r0 = BoxConstraints()
    //     0xb19428: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb1942c: StoreField: r0->field_7 = rZR
    //     0xb1942c: stur            xzr, [x0, #7]
    // 0xb19430: ldur            d0, [fp, #-8]
    // 0xb19434: StoreField: r0->field_f = d0
    //     0xb19434: stur            d0, [x0, #0xf]
    // 0xb19438: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb19438: stur            xzr, [x0, #0x17]
    // 0xb1943c: d0 = inf
    //     0xb1943c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb19440: StoreField: r0->field_1f = d0
    //     0xb19440: stur            d0, [x0, #0x1f]
    // 0xb19444: mov             x1, x0
    // 0xb19448: mov             x0, x1
    // 0xb1944c: LeaveFrame
    //     0xb1944c: mov             SP, fp
    //     0xb19450: ldp             fp, lr, [SP], #0x10
    // 0xb19454: ret
    //     0xb19454: ret             
  }
  _ _getMainSize(/* No info */) {
    // ** addr: 0xb19458, size: 0x2c
    // 0xb19458: LoadField: r0 = r1->field_63
    //     0xb19458: ldur            w0, [x1, #0x63]
    // 0xb1945c: DecompressPointer r0
    //     0xb1945c: add             x0, x0, HEAP, lsl #32
    // 0xb19460: LoadField: r1 = r0->field_7
    //     0xb19460: ldur            x1, [x0, #7]
    // 0xb19464: cmp             x1, #0
    // 0xb19468: b.gt            #0xb19478
    // 0xb1946c: LoadField: d1 = r2->field_7
    //     0xb1946c: ldur            d1, [x2, #7]
    // 0xb19470: mov             v0.16b, v1.16b
    // 0xb19474: b               #0xb19480
    // 0xb19478: LoadField: d1 = r2->field_f
    //     0xb19478: ldur            d1, [x2, #0xf]
    // 0xb1947c: mov             v0.16b, v1.16b
    // 0xb19480: ret
    //     0xb19480: ret             
  }
  [closure] Size layoutChild(dynamic, RenderBox, BoxConstraints) {
    // ** addr: 0xb19484, size: 0x1bc
    // 0xb19484: EnterFrame
    //     0xb19484: stp             fp, lr, [SP, #-0x10]!
    //     0xb19488: mov             fp, SP
    // 0xb1948c: AllocStack(0x38)
    //     0xb1948c: sub             SP, SP, #0x38
    // 0xb19490: SetupParameters([dynamic _ /* r0 */])
    //     0xb19490: ldr             x0, [fp, #0x20]
    //     0xb19494: ldur            w2, [x0, #0x17]
    //     0xb19498: add             x2, x2, HEAP, lsl #32
    //     0xb1949c: stur            x2, [fp, #-0x10]
    // 0xb194a0: CheckStackOverflow
    //     0xb194a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb194a4: cmp             SP, x16
    //     0xb194a8: b.ls            #0xb19608
    // 0xb194ac: LoadField: r0 = r2->field_13
    //     0xb194ac: ldur            w0, [x2, #0x13]
    // 0xb194b0: DecompressPointer r0
    //     0xb194b0: add             x0, x0, HEAP, lsl #32
    // 0xb194b4: stur            x0, [fp, #-8]
    // 0xb194b8: tbnz            w0, #4, #0xb194c8
    // 0xb194bc: ldr             x1, [fp, #0x10]
    // 0xb194c0: LoadField: d0 = r1->field_f
    //     0xb194c0: ldur            d0, [x1, #0xf]
    // 0xb194c4: b               #0xb194d0
    // 0xb194c8: ldr             x1, [fp, #0x10]
    // 0xb194cc: LoadField: d0 = r1->field_1f
    //     0xb194cc: ldur            d0, [x1, #0x1f]
    // 0xb194d0: mov             x1, v0.d[0]
    // 0xb194d4: and             x1, x1, #0x7fffffffffffffff
    // 0xb194d8: r17 = 9218868437227405312
    //     0xb194d8: mov             x17, #0x7ff0000000000000
    // 0xb194dc: cmp             x1, x17
    // 0xb194e0: b.eq            #0xb194ec
    // 0xb194e4: fcmp            d0, d0
    // 0xb194e8: b.vc            #0xb19510
    // 0xb194ec: tbnz            w0, #4, #0xb19500
    // 0xb194f0: ldr             x1, [fp, #0x18]
    // 0xb194f4: d0 = inf
    //     0xb194f4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb194f8: r0 = getMaxIntrinsicWidth()
    //     0xb194f8: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb194fc: b               #0xb1950c
    // 0xb19500: ldr             x1, [fp, #0x18]
    // 0xb19504: d0 = inf
    //     0xb19504: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb19508: r0 = getMaxIntrinsicHeight()
    //     0xb19508: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb1950c: ldur            x0, [fp, #-8]
    // 0xb19510: stur            d0, [fp, #-0x18]
    // 0xb19514: tbnz            w0, #4, #0xb1958c
    // 0xb19518: ldur            x0, [fp, #-0x10]
    // 0xb1951c: LoadField: r1 = r0->field_f
    //     0xb1951c: ldur            w1, [x0, #0xf]
    // 0xb19520: DecompressPointer r1
    //     0xb19520: add             x1, x1, HEAP, lsl #32
    // 0xb19524: r0 = inline_Allocate_Double()
    //     0xb19524: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb19528: add             x0, x0, #0x10
    //     0xb1952c: cmp             x2, x0
    //     0xb19530: b.ls            #0xb19610
    //     0xb19534: str             x0, [THR, #0x60]  ; THR::top
    //     0xb19538: sub             x0, x0, #0xf
    //     0xb1953c: mov             x2, #0xe19c
    //     0xb19540: movk            x2, #3, lsl #16
    //     0xb19544: stur            x2, [x0, #-1]
    // 0xb19548: dmb             ishst
    // 0xb1954c: StoreField: r0->field_7 = d0
    //     0xb1954c: stur            d0, [x0, #7]
    // 0xb19550: ldr             x16, [fp, #0x18]
    // 0xb19554: stp             x16, x1, [SP, #8]
    // 0xb19558: str             x0, [SP]
    // 0xb1955c: mov             x0, x1
    // 0xb19560: ClosureCall
    //     0xb19560: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb19564: ldur            x2, [x0, #0x1f]
    //     0xb19568: blr             x2
    // 0xb1956c: stur            x0, [fp, #-8]
    // 0xb19570: r0 = Size()
    //     0xb19570: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb19574: ldur            d0, [fp, #-0x18]
    // 0xb19578: StoreField: r0->field_7 = d0
    //     0xb19578: stur            d0, [x0, #7]
    // 0xb1957c: ldur            x1, [fp, #-8]
    // 0xb19580: LoadField: d0 = r1->field_7
    //     0xb19580: ldur            d0, [x1, #7]
    // 0xb19584: StoreField: r0->field_f = d0
    //     0xb19584: stur            d0, [x0, #0xf]
    // 0xb19588: b               #0xb195fc
    // 0xb1958c: ldur            x0, [fp, #-0x10]
    // 0xb19590: LoadField: r1 = r0->field_f
    //     0xb19590: ldur            w1, [x0, #0xf]
    // 0xb19594: DecompressPointer r1
    //     0xb19594: add             x1, x1, HEAP, lsl #32
    // 0xb19598: r0 = inline_Allocate_Double()
    //     0xb19598: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb1959c: add             x0, x0, #0x10
    //     0xb195a0: cmp             x2, x0
    //     0xb195a4: b.ls            #0xb19628
    //     0xb195a8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb195ac: sub             x0, x0, #0xf
    //     0xb195b0: mov             x2, #0xe19c
    //     0xb195b4: movk            x2, #3, lsl #16
    //     0xb195b8: stur            x2, [x0, #-1]
    // 0xb195bc: dmb             ishst
    // 0xb195c0: StoreField: r0->field_7 = d0
    //     0xb195c0: stur            d0, [x0, #7]
    // 0xb195c4: ldr             x16, [fp, #0x18]
    // 0xb195c8: stp             x16, x1, [SP, #8]
    // 0xb195cc: str             x0, [SP]
    // 0xb195d0: mov             x0, x1
    // 0xb195d4: ClosureCall
    //     0xb195d4: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb195d8: ldur            x2, [x0, #0x1f]
    //     0xb195dc: blr             x2
    // 0xb195e0: LoadField: d0 = r0->field_7
    //     0xb195e0: ldur            d0, [x0, #7]
    // 0xb195e4: stur            d0, [fp, #-0x20]
    // 0xb195e8: r0 = Size()
    //     0xb195e8: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb195ec: ldur            d0, [fp, #-0x20]
    // 0xb195f0: StoreField: r0->field_7 = d0
    //     0xb195f0: stur            d0, [x0, #7]
    // 0xb195f4: ldur            d0, [fp, #-0x18]
    // 0xb195f8: StoreField: r0->field_f = d0
    //     0xb195f8: stur            d0, [x0, #0xf]
    // 0xb195fc: LeaveFrame
    //     0xb195fc: mov             SP, fp
    //     0xb19600: ldp             fp, lr, [SP], #0x10
    // 0xb19604: ret
    //     0xb19604: ret             
    // 0xb19608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb19608: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1960c: b               #0xb194ac
    // 0xb19610: SaveReg d0
    //     0xb19610: str             q0, [SP, #-0x10]!
    // 0xb19614: SaveReg r1
    //     0xb19614: str             x1, [SP, #-8]!
    // 0xb19618: r0 = AllocateDouble()
    //     0xb19618: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1961c: RestoreReg r1
    //     0xb1961c: ldr             x1, [SP], #8
    // 0xb19620: RestoreReg d0
    //     0xb19620: ldr             q0, [SP], #0x10
    // 0xb19624: b               #0xb1954c
    // 0xb19628: SaveReg d0
    //     0xb19628: str             q0, [SP, #-0x10]!
    // 0xb1962c: SaveReg r1
    //     0xb1962c: str             x1, [SP, #-8]!
    // 0xb19630: r0 = AllocateDouble()
    //     0xb19630: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb19634: RestoreReg r1
    //     0xb19634: ldr             x1, [SP], #8
    // 0xb19638: RestoreReg d0
    //     0xb19638: ldr             q0, [SP], #0x10
    // 0xb1963c: b               #0xb195c0
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb23e58, size: 0x60
    // 0xb23e58: EnterFrame
    //     0xb23e58: stp             fp, lr, [SP, #-0x10]!
    //     0xb23e5c: mov             fp, SP
    // 0xb23e60: AllocStack(0x10)
    //     0xb23e60: sub             SP, SP, #0x10
    // 0xb23e64: SetupParameters(RenderFlex this /* r1 => r0, fp-0x8 */)
    //     0xb23e64: mov             x0, x1
    //     0xb23e68: stur            x1, [fp, #-8]
    // 0xb23e6c: CheckStackOverflow
    //     0xb23e6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23e70: cmp             SP, x16
    //     0xb23e74: b.ls            #0xb23eb0
    // 0xb23e78: LoadField: d0 = r2->field_7
    //     0xb23e78: ldur            d0, [x2, #7]
    // 0xb23e7c: stur            d0, [fp, #-0x10]
    // 0xb23e80: r1 = Function '<anonymous closure>':.
    //     0xb23e80: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4210] AnonymousClosure: (0xb23f30), in [package:flutter_widget_from_html_core/src/widgets/html_flex.dart] RenderHtmlFlex::computeMinIntrinsicHeight (0xb2401c)
    //     0xb23e84: ldr             x1, [x1, #0x210]
    // 0xb23e88: r2 = Null
    //     0xb23e88: mov             x2, NULL
    // 0xb23e8c: r0 = AllocateClosure()
    //     0xb23e8c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb23e90: ldur            x1, [fp, #-8]
    // 0xb23e94: mov             x2, x0
    // 0xb23e98: ldur            d0, [fp, #-0x10]
    // 0xb23e9c: r3 = Instance_Axis
    //     0xb23e9c: ldr             x3, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xb23ea0: r0 = _getIntrinsicSize()
    //     0xb23ea0: bl              #0xb17b90  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize
    // 0xb23ea4: LeaveFrame
    //     0xb23ea4: mov             SP, fp
    //     0xb23ea8: ldp             fp, lr, [SP], #0x10
    // 0xb23eac: ret
    //     0xb23eac: ret             
    // 0xb23eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23eb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23eb4: b               #0xb23e78
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb23eb8, size: 0x78
    // 0xb23eb8: EnterFrame
    //     0xb23eb8: stp             fp, lr, [SP, #-0x10]!
    //     0xb23ebc: mov             fp, SP
    // 0xb23ec0: ldr             x0, [fp, #0x18]
    // 0xb23ec4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb23ec4: ldur            w1, [x0, #0x17]
    // 0xb23ec8: DecompressPointer r1
    //     0xb23ec8: add             x1, x1, HEAP, lsl #32
    // 0xb23ecc: CheckStackOverflow
    //     0xb23ecc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23ed0: cmp             SP, x16
    //     0xb23ed4: b.ls            #0xb23f18
    // 0xb23ed8: ldr             x2, [fp, #0x10]
    // 0xb23edc: r0 = computeMinIntrinsicHeight()
    //     0xb23edc: bl              #0xb23e58  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicHeight
    // 0xb23ee0: r0 = inline_Allocate_Double()
    //     0xb23ee0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23ee4: add             x0, x0, #0x10
    //     0xb23ee8: cmp             x1, x0
    //     0xb23eec: b.ls            #0xb23f20
    //     0xb23ef0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23ef4: sub             x0, x0, #0xf
    //     0xb23ef8: mov             x1, #0xe19c
    //     0xb23efc: movk            x1, #3, lsl #16
    //     0xb23f00: stur            x1, [x0, #-1]
    // 0xb23f04: dmb             ishst
    // 0xb23f08: StoreField: r0->field_7 = d0
    //     0xb23f08: stur            d0, [x0, #7]
    // 0xb23f0c: LeaveFrame
    //     0xb23f0c: mov             SP, fp
    //     0xb23f10: ldp             fp, lr, [SP], #0x10
    // 0xb23f14: ret
    //     0xb23f14: ret             
    // 0xb23f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23f18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23f1c: b               #0xb23ed8
    // 0xb23f20: SaveReg d0
    //     0xb23f20: str             q0, [SP, #-0x10]!
    // 0xb23f24: r0 = AllocateDouble()
    //     0xb23f24: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb23f28: RestoreReg d0
    //     0xb23f28: ldr             q0, [SP], #0x10
    // 0xb23f2c: b               #0xb23f08
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2a970, size: 0x60
    // 0xb2a970: EnterFrame
    //     0xb2a970: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a974: mov             fp, SP
    // 0xb2a978: AllocStack(0x10)
    //     0xb2a978: sub             SP, SP, #0x10
    // 0xb2a97c: SetupParameters(RenderFlex this /* r1 => r0, fp-0x8 */)
    //     0xb2a97c: mov             x0, x1
    //     0xb2a980: stur            x1, [fp, #-8]
    // 0xb2a984: CheckStackOverflow
    //     0xb2a984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a988: cmp             SP, x16
    //     0xb2a98c: b.ls            #0xb2a9c8
    // 0xb2a990: LoadField: d0 = r2->field_7
    //     0xb2a990: ldur            d0, [x2, #7]
    // 0xb2a994: stur            d0, [fp, #-0x10]
    // 0xb2a998: r1 = Function '<anonymous closure>':.
    //     0xb2a998: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a258] AnonymousClosure: (0xb2aa48), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicHeight (0xb2a970)
    //     0xb2a99c: ldr             x1, [x1, #0x258]
    // 0xb2a9a0: r2 = Null
    //     0xb2a9a0: mov             x2, NULL
    // 0xb2a9a4: r0 = AllocateClosure()
    //     0xb2a9a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2a9a8: ldur            x1, [fp, #-8]
    // 0xb2a9ac: mov             x2, x0
    // 0xb2a9b0: ldur            d0, [fp, #-0x10]
    // 0xb2a9b4: r3 = Instance_Axis
    //     0xb2a9b4: ldr             x3, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xb2a9b8: r0 = _getIntrinsicSize()
    //     0xb2a9b8: bl              #0xb17b90  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize
    // 0xb2a9bc: LeaveFrame
    //     0xb2a9bc: mov             SP, fp
    //     0xb2a9c0: ldp             fp, lr, [SP], #0x10
    // 0xb2a9c4: ret
    //     0xb2a9c4: ret             
    // 0xb2a9c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a9c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a9cc: b               #0xb2a990
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2a9d0, size: 0x78
    // 0xb2a9d0: EnterFrame
    //     0xb2a9d0: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a9d4: mov             fp, SP
    // 0xb2a9d8: ldr             x0, [fp, #0x18]
    // 0xb2a9dc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2a9dc: ldur            w1, [x0, #0x17]
    // 0xb2a9e0: DecompressPointer r1
    //     0xb2a9e0: add             x1, x1, HEAP, lsl #32
    // 0xb2a9e4: CheckStackOverflow
    //     0xb2a9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a9e8: cmp             SP, x16
    //     0xb2a9ec: b.ls            #0xb2aa30
    // 0xb2a9f0: ldr             x2, [fp, #0x10]
    // 0xb2a9f4: r0 = computeMaxIntrinsicHeight()
    //     0xb2a9f4: bl              #0xb2a970  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicHeight
    // 0xb2a9f8: r0 = inline_Allocate_Double()
    //     0xb2a9f8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2a9fc: add             x0, x0, #0x10
    //     0xb2aa00: cmp             x1, x0
    //     0xb2aa04: b.ls            #0xb2aa38
    //     0xb2aa08: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2aa0c: sub             x0, x0, #0xf
    //     0xb2aa10: mov             x1, #0xe19c
    //     0xb2aa14: movk            x1, #3, lsl #16
    //     0xb2aa18: stur            x1, [x0, #-1]
    // 0xb2aa1c: dmb             ishst
    // 0xb2aa20: StoreField: r0->field_7 = d0
    //     0xb2aa20: stur            d0, [x0, #7]
    // 0xb2aa24: LeaveFrame
    //     0xb2aa24: mov             SP, fp
    //     0xb2aa28: ldp             fp, lr, [SP], #0x10
    // 0xb2aa2c: ret
    //     0xb2aa2c: ret             
    // 0xb2aa30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2aa30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2aa34: b               #0xb2a9f0
    // 0xb2aa38: SaveReg d0
    //     0xb2aa38: str             q0, [SP, #-0x10]!
    // 0xb2aa3c: r0 = AllocateDouble()
    //     0xb2aa3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2aa40: RestoreReg d0
    //     0xb2aa40: ldr             q0, [SP], #0x10
    // 0xb2aa44: b               #0xb2aa20
  }
  [closure] double <anonymous closure>(dynamic, RenderBox, double) {
    // ** addr: 0xb2aa48, size: 0x74
    // 0xb2aa48: EnterFrame
    //     0xb2aa48: stp             fp, lr, [SP, #-0x10]!
    //     0xb2aa4c: mov             fp, SP
    // 0xb2aa50: CheckStackOverflow
    //     0xb2aa50: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2aa54: cmp             SP, x16
    //     0xb2aa58: b.ls            #0xb2aaa4
    // 0xb2aa5c: ldr             x0, [fp, #0x10]
    // 0xb2aa60: LoadField: d0 = r0->field_7
    //     0xb2aa60: ldur            d0, [x0, #7]
    // 0xb2aa64: ldr             x1, [fp, #0x18]
    // 0xb2aa68: r0 = getMaxIntrinsicHeight()
    //     0xb2aa68: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2aa6c: r0 = inline_Allocate_Double()
    //     0xb2aa6c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2aa70: add             x0, x0, #0x10
    //     0xb2aa74: cmp             x1, x0
    //     0xb2aa78: b.ls            #0xb2aaac
    //     0xb2aa7c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2aa80: sub             x0, x0, #0xf
    //     0xb2aa84: mov             x1, #0xe19c
    //     0xb2aa88: movk            x1, #3, lsl #16
    //     0xb2aa8c: stur            x1, [x0, #-1]
    // 0xb2aa90: dmb             ishst
    // 0xb2aa94: StoreField: r0->field_7 = d0
    //     0xb2aa94: stur            d0, [x0, #7]
    // 0xb2aa98: LeaveFrame
    //     0xb2aa98: mov             SP, fp
    //     0xb2aa9c: ldp             fp, lr, [SP], #0x10
    // 0xb2aaa0: ret
    //     0xb2aaa0: ret             
    // 0xb2aaa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2aaa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2aaa8: b               #0xb2aa5c
    // 0xb2aaac: SaveReg d0
    //     0xb2aaac: str             q0, [SP, #-0x10]!
    // 0xb2aab0: r0 = AllocateDouble()
    //     0xb2aab0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2aab4: RestoreReg d0
    //     0xb2aab4: ldr             q0, [SP], #0x10
    // 0xb2aab8: b               #0xb2aa94
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2da74, size: 0x60
    // 0xb2da74: EnterFrame
    //     0xb2da74: stp             fp, lr, [SP, #-0x10]!
    //     0xb2da78: mov             fp, SP
    // 0xb2da7c: AllocStack(0x10)
    //     0xb2da7c: sub             SP, SP, #0x10
    // 0xb2da80: SetupParameters(RenderFlex this /* r1 => r0, fp-0x8 */)
    //     0xb2da80: mov             x0, x1
    //     0xb2da84: stur            x1, [fp, #-8]
    // 0xb2da88: CheckStackOverflow
    //     0xb2da88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2da8c: cmp             SP, x16
    //     0xb2da90: b.ls            #0xb2dacc
    // 0xb2da94: LoadField: d0 = r2->field_7
    //     0xb2da94: ldur            d0, [x2, #7]
    // 0xb2da98: stur            d0, [fp, #-0x10]
    // 0xb2da9c: r1 = Function '<anonymous closure>':.
    //     0xb2da9c: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4220] AnonymousClosure: (0xb2db4c), in [package:flutter_widget_from_html_core/src/widgets/html_flex.dart] RenderHtmlFlex::computeMaxIntrinsicWidth (0xb2dc38)
    //     0xb2daa0: ldr             x1, [x1, #0x220]
    // 0xb2daa4: r2 = Null
    //     0xb2daa4: mov             x2, NULL
    // 0xb2daa8: r0 = AllocateClosure()
    //     0xb2daa8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2daac: ldur            x1, [fp, #-8]
    // 0xb2dab0: mov             x2, x0
    // 0xb2dab4: ldur            d0, [fp, #-0x10]
    // 0xb2dab8: r3 = Instance_Axis
    //     0xb2dab8: ldr             x3, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xb2dabc: r0 = _getIntrinsicSize()
    //     0xb2dabc: bl              #0xb17b90  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_getIntrinsicSize
    // 0xb2dac0: LeaveFrame
    //     0xb2dac0: mov             SP, fp
    //     0xb2dac4: ldp             fp, lr, [SP], #0x10
    // 0xb2dac8: ret
    //     0xb2dac8: ret             
    // 0xb2dacc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2dacc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2dad0: b               #0xb2da94
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2dad4, size: 0x78
    // 0xb2dad4: EnterFrame
    //     0xb2dad4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2dad8: mov             fp, SP
    // 0xb2dadc: ldr             x0, [fp, #0x18]
    // 0xb2dae0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2dae0: ldur            w1, [x0, #0x17]
    // 0xb2dae4: DecompressPointer r1
    //     0xb2dae4: add             x1, x1, HEAP, lsl #32
    // 0xb2dae8: CheckStackOverflow
    //     0xb2dae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2daec: cmp             SP, x16
    //     0xb2daf0: b.ls            #0xb2db34
    // 0xb2daf4: ldr             x2, [fp, #0x10]
    // 0xb2daf8: r0 = computeMaxIntrinsicWidth()
    //     0xb2daf8: bl              #0xb2da74  ; [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicWidth
    // 0xb2dafc: r0 = inline_Allocate_Double()
    //     0xb2dafc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2db00: add             x0, x0, #0x10
    //     0xb2db04: cmp             x1, x0
    //     0xb2db08: b.ls            #0xb2db3c
    //     0xb2db0c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2db10: sub             x0, x0, #0xf
    //     0xb2db14: mov             x1, #0xe19c
    //     0xb2db18: movk            x1, #3, lsl #16
    //     0xb2db1c: stur            x1, [x0, #-1]
    // 0xb2db20: dmb             ishst
    // 0xb2db24: StoreField: r0->field_7 = d0
    //     0xb2db24: stur            d0, [x0, #7]
    // 0xb2db28: LeaveFrame
    //     0xb2db28: mov             SP, fp
    //     0xb2db2c: ldp             fp, lr, [SP], #0x10
    // 0xb2db30: ret
    //     0xb2db30: ret             
    // 0xb2db34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2db34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2db38: b               #0xb2daf4
    // 0xb2db3c: SaveReg d0
    //     0xb2db3c: str             q0, [SP, #-0x10]!
    // 0xb2db40: r0 = AllocateDouble()
    //     0xb2db40: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2db44: RestoreReg d0
    //     0xb2db44: ldr             q0, [SP], #0x10
    // 0xb2db48: b               #0xb2db24
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4e58c, size: 0x64
    // 0xb4e58c: EnterFrame
    //     0xb4e58c: stp             fp, lr, [SP, #-0x10]!
    //     0xb4e590: mov             fp, SP
    // 0xb4e594: AllocStack(0x8)
    //     0xb4e594: sub             SP, SP, #8
    // 0xb4e598: SetupParameters(RenderFlex this /* r1 => r0, fp-0x8 */)
    //     0xb4e598: mov             x0, x1
    //     0xb4e59c: stur            x1, [fp, #-8]
    // 0xb4e5a0: CheckStackOverflow
    //     0xb4e5a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4e5a4: cmp             SP, x16
    //     0xb4e5a8: b.ls            #0xb4e5e8
    // 0xb4e5ac: mov             x1, x0
    // 0xb4e5b0: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb4e5b0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb4e5b4: ldr             x3, [x3, #0x860]
    // 0xb4e5b8: r5 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb4e5b8: add             x5, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb4e5bc: ldr             x5, [x5, #0x700]
    // 0xb4e5c0: r0 = _computeSizes()
    //     0xb4e5c0: bl              #0xb1805c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_computeSizes
    // 0xb4e5c4: LoadField: r1 = r0->field_7
    //     0xb4e5c4: ldur            w1, [x0, #7]
    // 0xb4e5c8: DecompressPointer r1
    //     0xb4e5c8: add             x1, x1, HEAP, lsl #32
    // 0xb4e5cc: ldur            x0, [fp, #-8]
    // 0xb4e5d0: LoadField: r2 = r0->field_63
    //     0xb4e5d0: ldur            w2, [x0, #0x63]
    // 0xb4e5d4: DecompressPointer r2
    //     0xb4e5d4: add             x2, x2, HEAP, lsl #32
    // 0xb4e5d8: r0 = _AxisSize._convert()
    //     0xb4e5d8: bl              #0xb191dc  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize._convert
    // 0xb4e5dc: LeaveFrame
    //     0xb4e5dc: mov             SP, fp
    //     0xb4e5e0: ldp             fp, lr, [SP], #0x10
    // 0xb4e5e4: ret
    //     0xb4e5e4: ret             
    // 0xb4e5e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4e5e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4e5ec: b               #0xb4e5ac
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58558, size: 0x24
    // 0xb58558: EnterFrame
    //     0xb58558: stp             fp, lr, [SP, #-0x10]!
    //     0xb5855c: mov             fp, SP
    // 0xb58560: ldr             x2, [fp, #0x10]
    // 0xb58564: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58564: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4218] AnonymousClosure: (0xb2dad4), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicWidth (0xb2da74)
    //     0xb58568: ldr             x1, [x1, #0x218]
    // 0xb5856c: r0 = AllocateClosure()
    //     0xb5856c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58570: LeaveFrame
    //     0xb58570: mov             SP, fp
    //     0xb58574: ldp             fp, lr, [SP], #0x10
    // 0xb58578: ret
    //     0xb58578: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e704, size: 0x24
    // 0xb5e704: EnterFrame
    //     0xb5e704: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e708: mov             fp, SP
    // 0xb5e70c: ldr             x2, [fp, #0x10]
    // 0xb5e710: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e710: add             x1, PP, #0x9a, lsl #12  ; [pp+0x9a250] AnonymousClosure: (0xb2a9d0), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMaxIntrinsicHeight (0xb2a970)
    //     0xb5e714: ldr             x1, [x1, #0x250]
    // 0xb5e718: r0 = AllocateClosure()
    //     0xb5e718: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e71c: LeaveFrame
    //     0xb5e71c: mov             SP, fp
    //     0xb5e720: ldp             fp, lr, [SP], #0x10
    // 0xb5e724: ret
    //     0xb5e724: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb61458, size: 0xf4
    // 0xb61458: EnterFrame
    //     0xb61458: stp             fp, lr, [SP, #-0x10]!
    //     0xb6145c: mov             fp, SP
    // 0xb61460: AllocStack(0x20)
    //     0xb61460: sub             SP, SP, #0x20
    // 0xb61464: SetupParameters(RenderFlex this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb61464: mov             x5, x1
    //     0xb61468: mov             x4, x2
    //     0xb6146c: stur            x1, [fp, #-8]
    //     0xb61470: stur            x2, [fp, #-0x10]
    //     0xb61474: stur            x3, [fp, #-0x18]
    // 0xb61478: CheckStackOverflow
    //     0xb61478: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6147c: cmp             SP, x16
    //     0xb61480: b.ls            #0xb61544
    // 0xb61484: mov             x0, x4
    // 0xb61488: r2 = Null
    //     0xb61488: mov             x2, NULL
    // 0xb6148c: r1 = Null
    //     0xb6148c: mov             x1, NULL
    // 0xb61490: r4 = 60
    //     0xb61490: mov             x4, #0x3c
    // 0xb61494: branchIfSmi(r0, 0xb614a0)
    //     0xb61494: tbz             w0, #0, #0xb614a0
    // 0xb61498: r4 = LoadClassIdInstr(r0)
    //     0xb61498: ldur            x4, [x0, #-1]
    //     0xb6149c: ubfx            x4, x4, #0xc, #0x14
    // 0xb614a0: sub             x4, x4, #0xb46
    // 0xb614a4: cmp             x4, #1
    // 0xb614a8: b.ls            #0xb614bc
    // 0xb614ac: r8 = BoxConstraints
    //     0xb614ac: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb614b0: r3 = Null
    //     0xb614b0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a288] Null
    //     0xb614b4: ldr             x3, [x3, #0x288]
    // 0xb614b8: r0 = BoxConstraints()
    //     0xb614b8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb614bc: ldur            x1, [fp, #-8]
    // 0xb614c0: ldur            x2, [fp, #-0x10]
    // 0xb614c4: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb614c4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb614c8: ldr             x3, [x3, #0x860]
    // 0xb614cc: r5 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb614cc: add             x5, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb614d0: ldr             x5, [x5, #0x700]
    // 0xb614d4: r0 = _computeSizes()
    //     0xb614d4: bl              #0xb1805c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_computeSizes
    // 0xb614d8: ldur            x1, [fp, #-8]
    // 0xb614dc: stur            x0, [fp, #-0x20]
    // 0xb614e0: r0 = _isBaselineAligned()
    //     0xb614e0: bl              #0xb19268  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_isBaselineAligned
    // 0xb614e4: tbnz            w0, #4, #0xb61500
    // 0xb614e8: ldur            x5, [fp, #-0x20]
    // 0xb614ec: LoadField: r0 = r5->field_13
    //     0xb614ec: ldur            w0, [x5, #0x13]
    // 0xb614f0: DecompressPointer r0
    //     0xb614f0: add             x0, x0, HEAP, lsl #32
    // 0xb614f4: LeaveFrame
    //     0xb614f4: mov             SP, fp
    //     0xb614f8: ldp             fp, lr, [SP], #0x10
    // 0xb614fc: ret
    //     0xb614fc: ret             
    // 0xb61500: ldur            x1, [fp, #-8]
    // 0xb61504: ldur            x5, [fp, #-0x20]
    // 0xb61508: LoadField: r0 = r1->field_63
    //     0xb61508: ldur            w0, [x1, #0x63]
    // 0xb6150c: DecompressPointer r0
    //     0xb6150c: add             x0, x0, HEAP, lsl #32
    // 0xb61510: LoadField: r2 = r0->field_7
    //     0xb61510: ldur            x2, [x0, #7]
    // 0xb61514: cmp             x2, #0
    // 0xb61518: b.gt            #0xb6152c
    // 0xb6151c: ldur            x2, [fp, #-0x10]
    // 0xb61520: ldur            x3, [fp, #-0x18]
    // 0xb61524: r0 = _computeDryDistanceToHighestBaseline()
    //     0xb61524: bl              #0xb6213c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_computeDryDistanceToHighestBaseline
    // 0xb61528: b               #0xb61538
    // 0xb6152c: ldur            x2, [fp, #-0x10]
    // 0xb61530: ldur            x3, [fp, #-0x18]
    // 0xb61534: r0 = _computeDryDistanceToFirstBaseline()
    //     0xb61534: bl              #0xb6154c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_computeDryDistanceToFirstBaseline
    // 0xb61538: LeaveFrame
    //     0xb61538: mov             SP, fp
    //     0xb6153c: ldp             fp, lr, [SP], #0x10
    // 0xb61540: ret
    //     0xb61540: ret             
    // 0xb61544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb61544: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb61548: b               #0xb61484
  }
  _ _computeDryDistanceToFirstBaseline(/* No info */) {
    // ** addr: 0xb6154c, size: 0x64c
    // 0xb6154c: EnterFrame
    //     0xb6154c: stp             fp, lr, [SP, #-0x10]!
    //     0xb61550: mov             fp, SP
    // 0xb61554: AllocStack(0x98)
    //     0xb61554: sub             SP, SP, #0x98
    // 0xb61558: SetupParameters(RenderFlex this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0xb61558: mov             x4, x1
    //     0xb6155c: mov             x0, x2
    //     0xb61560: stur            x1, [fp, #-8]
    //     0xb61564: stur            x2, [fp, #-0x10]
    //     0xb61568: stur            x3, [fp, #-0x18]
    //     0xb6156c: stur            x5, [fp, #-0x20]
    // 0xb61570: CheckStackOverflow
    //     0xb61570: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb61574: cmp             SP, x16
    //     0xb61578: b.ls            #0xb61b48
    // 0xb6157c: mov             x1, x4
    // 0xb61580: mov             x2, x0
    // 0xb61584: r0 = _constraintsForNonFlexChild()
    //     0xb61584: bl              #0xb192f8  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_constraintsForNonFlexChild
    // 0xb61588: mov             x2, x0
    // 0xb6158c: ldur            x0, [fp, #-0x20]
    // 0xb61590: stur            x2, [fp, #-0x28]
    // 0xb61594: LoadField: d0 = r0->field_b
    //     0xb61594: ldur            d0, [x0, #0xb]
    // 0xb61598: d1 = 0.000000
    //     0xb61598: eor             v1.16b, v1.16b, v1.16b
    // 0xb6159c: fmax            v2.2d, v1.2d, v0.2d
    // 0xb615a0: ldur            x1, [fp, #-8]
    // 0xb615a4: stur            d2, [fp, #-0x58]
    // 0xb615a8: r0 = _flipMainAxis()
    //     0xb615a8: bl              #0xb61ff4  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_flipMainAxis
    // 0xb615ac: mov             x4, x0
    // 0xb615b0: ldur            x0, [fp, #-8]
    // 0xb615b4: stur            x4, [fp, #-0x30]
    // 0xb615b8: LoadField: r1 = r0->field_67
    //     0xb615b8: ldur            w1, [x0, #0x67]
    // 0xb615bc: DecompressPointer r1
    //     0xb615bc: add             x1, x1, HEAP, lsl #32
    // 0xb615c0: LoadField: r2 = r0->field_4f
    //     0xb615c0: ldur            x2, [x0, #0x4f]
    // 0xb615c4: LoadField: d1 = r0->field_8b
    //     0xb615c4: ldur            d1, [x0, #0x8b]
    // 0xb615c8: ldur            d0, [fp, #-0x58]
    // 0xb615cc: mov             x3, x4
    // 0xb615d0: r0 = _distributeSpace()
    //     0xb615d0: bl              #0xb61b98  ; [package:flutter/src/rendering/flex.dart] MainAxisAlignment::_distributeSpace
    // 0xb615d4: mov             x2, x0
    // 0xb615d8: stur            x2, [fp, #-0x40]
    // 0xb615dc: mov             x3, x1
    // 0xb615e0: stur            x3, [fp, #-0x38]
    // 0xb615e4: r16 = <RenderBox, double>
    //     0xb615e4: add             x16, PP, #0x9a, lsl #12  ; [pp+0x9a298] TypeArguments: <RenderBox, double>
    //     0xb615e8: ldr             x16, [x16, #0x298]
    // 0xb615ec: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xb615f0: stp             lr, x16, [SP]
    // 0xb615f4: r0 = Map._fromLiteral()
    //     0xb615f4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xb615f8: mov             x3, x0
    // 0xb615fc: ldur            x0, [fp, #-0x30]
    // 0xb61600: stur            x3, [fp, #-0x48]
    // 0xb61604: tbnz            w0, #4, #0xb6163c
    // 0xb61608: ldur            x0, [fp, #-8]
    // 0xb6160c: LoadField: r4 = r0->field_5b
    //     0xb6160c: ldur            w4, [x0, #0x5b]
    // 0xb61610: DecompressPointer r4
    //     0xb61610: add             x4, x4, HEAP, lsl #32
    // 0xb61614: mov             x2, x0
    // 0xb61618: stur            x4, [fp, #-0x30]
    // 0xb6161c: r1 = Function 'childBefore':.
    //     0xb6161c: add             x1, PP, #0x90, lsl #12  ; [pp+0x90758] AnonymousClosure: (0xb6208c), of [dart:mixin_deduplication] _MixinApplication14&RenderBox&ContainerRenderObjectMixin
    //     0xb61620: ldr             x1, [x1, #0x758]
    // 0xb61624: r0 = AllocateClosure()
    //     0xb61624: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb61628: mov             x2, x0
    // 0xb6162c: ldur            x3, [fp, #-0x30]
    // 0xb61630: r0 = AllocateRecord2()
    //     0xb61630: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61634: mov             x3, x0
    // 0xb61638: b               #0xb6166c
    // 0xb6163c: ldur            x0, [fp, #-8]
    // 0xb61640: LoadField: r3 = r0->field_57
    //     0xb61640: ldur            w3, [x0, #0x57]
    // 0xb61644: DecompressPointer r3
    //     0xb61644: add             x3, x3, HEAP, lsl #32
    // 0xb61648: mov             x2, x0
    // 0xb6164c: stur            x3, [fp, #-0x30]
    // 0xb61650: r1 = Function 'childAfter':.
    //     0xb61650: add             x1, PP, #0x90, lsl #12  ; [pp+0x90760] AnonymousClosure: (0xb17fac), of [dart:mixin_deduplication] _MixinApplication14&RenderBox&ContainerRenderObjectMixin
    //     0xb61654: ldr             x1, [x1, #0x760]
    // 0xb61658: r0 = AllocateClosure()
    //     0xb61658: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb6165c: mov             x2, x0
    // 0xb61660: ldur            x3, [fp, #-0x30]
    // 0xb61664: r0 = AllocateRecord2()
    //     0xb61664: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61668: mov             x3, x0
    // 0xb6166c: stur            x3, [fp, #-0x50]
    // 0xb61670: LoadField: r4 = r3->field_f
    //     0xb61670: ldur            w4, [x3, #0xf]
    // 0xb61674: DecompressPointer r4
    //     0xb61674: add             x4, x4, HEAP, lsl #32
    // 0xb61678: mov             x0, x4
    // 0xb6167c: stur            x4, [fp, #-0x30]
    // 0xb61680: r2 = Null
    //     0xb61680: mov             x2, NULL
    // 0xb61684: r1 = Null
    //     0xb61684: mov             x1, NULL
    // 0xb61688: cmp             w0, NULL
    // 0xb6168c: b.eq            #0xb616d8
    // 0xb61690: branchIfSmi(r0, 0xb616d8)
    //     0xb61690: tbz             w0, #0, #0xb616d8
    // 0xb61694: r3 = SubtypeTestCache
    //     0xb61694: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a2a0] SubtypeTestCache
    //     0xb61698: ldr             x3, [x3, #0x2a0]
    // 0xb6169c: r30 = Subtype6TestCacheStub
    //     0xb6169c: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0xb616a0: LoadField: r30 = r30->field_7
    //     0xb616a0: ldur            lr, [lr, #7]
    // 0xb616a4: blr             lr
    // 0xb616a8: cmp             w7, NULL
    // 0xb616ac: b.eq            #0xb616b8
    // 0xb616b0: tbnz            w7, #4, #0xb616d8
    // 0xb616b4: b               #0xb616e0
    // 0xb616b8: r8 = (dynamic this, RenderBox) => RenderBox?
    //     0xb616b8: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a2a8] FunctionType: (dynamic this, RenderBox) => RenderBox?
    //     0xb616bc: ldr             x8, [x8, #0x2a8]
    // 0xb616c0: r3 = SubtypeTestCache
    //     0xb616c0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a2b0] SubtypeTestCache
    //     0xb616c4: ldr             x3, [x3, #0x2b0]
    // 0xb616c8: r30 = InstanceOfStub
    //     0xb616c8: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xb616cc: LoadField: r30 = r30->field_7
    //     0xb616cc: ldur            lr, [lr, #7]
    // 0xb616d0: blr             lr
    // 0xb616d4: b               #0xb616e4
    // 0xb616d8: r0 = false
    //     0xb616d8: add             x0, NULL, #0x30  ; false
    // 0xb616dc: b               #0xb616e4
    // 0xb616e0: r0 = true
    //     0xb616e0: add             x0, NULL, #0x20  ; true
    // 0xb616e4: tbnz            w0, #4, #0xb61b28
    // 0xb616e8: ldur            x3, [fp, #-0x20]
    // 0xb616ec: ldur            x0, [fp, #-0x50]
    // 0xb616f0: ldur            x1, [fp, #-0x40]
    // 0xb616f4: ldur            x2, [fp, #-0x38]
    // 0xb616f8: LoadField: r4 = r0->field_13
    //     0xb616f8: ldur            w4, [x0, #0x13]
    // 0xb616fc: DecompressPointer r4
    //     0xb616fc: add             x4, x4, HEAP, lsl #32
    // 0xb61700: LoadField: d0 = r1->field_7
    //     0xb61700: ldur            d0, [x1, #7]
    // 0xb61704: stur            d0, [fp, #-0x68]
    // 0xb61708: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xb61708: ldur            w0, [x3, #0x17]
    // 0xb6170c: DecompressPointer r0
    //     0xb6170c: add             x0, x0, HEAP, lsl #32
    // 0xb61710: stur            x0, [fp, #-0x40]
    // 0xb61714: LoadField: d1 = r2->field_7
    //     0xb61714: ldur            d1, [x2, #7]
    // 0xb61718: stur            d1, [fp, #-0x60]
    // 0xb6171c: mov             v2.16b, v0.16b
    // 0xb61720: ldur            x3, [fp, #-8]
    // 0xb61724: stur            x4, [fp, #-0x20]
    // 0xb61728: stur            d2, [fp, #-0x58]
    // 0xb6172c: CheckStackOverflow
    //     0xb6172c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb61730: cmp             SP, x16
    //     0xb61734: b.ls            #0xb61b50
    // 0xb61738: cmp             w4, NULL
    // 0xb6173c: b.eq            #0xb61914
    // 0xb61740: ldur            x1, [fp, #-0x48]
    // 0xb61744: mov             x2, x4
    // 0xb61748: r0 = _hashCode()
    //     0xb61748: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0xb6174c: mov             x2, x0
    // 0xb61750: ldur            d0, [fp, #-0x58]
    // 0xb61754: r3 = inline_Allocate_Double()
    //     0xb61754: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb61758: add             x3, x3, #0x10
    //     0xb6175c: cmp             x0, x3
    //     0xb61760: b.ls            #0xb61b58
    //     0xb61764: str             x3, [THR, #0x60]  ; THR::top
    //     0xb61768: sub             x3, x3, #0xf
    //     0xb6176c: mov             x0, #0xe19c
    //     0xb61770: movk            x0, #3, lsl #16
    //     0xb61774: stur            x0, [x3, #-1]
    // 0xb61778: dmb             ishst
    // 0xb6177c: StoreField: r3->field_7 = d0
    //     0xb6177c: stur            d0, [x3, #7]
    // 0xb61780: r0 = BoxInt64Instr(r2)
    //     0xb61780: sbfiz           x0, x2, #1, #0x1f
    //     0xb61784: cmp             x2, x0, asr #1
    //     0xb61788: b.eq            #0xb61794
    //     0xb6178c: bl              #0x13dfc6c  ; AllocateMintSharedWithFPURegsStub
    //     0xb61790: stur            x2, [x0, #7]
    // 0xb61794: ldur            x1, [fp, #-0x48]
    // 0xb61798: ldur            x2, [fp, #-0x20]
    // 0xb6179c: mov             x5, x0
    // 0xb617a0: r0 = _set()
    //     0xb617a0: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xb617a4: ldur            x3, [fp, #-0x40]
    // 0xb617a8: cmp             w3, NULL
    // 0xb617ac: b.eq            #0xb61858
    // 0xb617b0: ldur            x4, [fp, #-0x20]
    // 0xb617b4: LoadField: r5 = r4->field_7
    //     0xb617b4: ldur            w5, [x4, #7]
    // 0xb617b8: DecompressPointer r5
    //     0xb617b8: add             x5, x5, HEAP, lsl #32
    // 0xb617bc: stur            x5, [fp, #-0x38]
    // 0xb617c0: cmp             w5, NULL
    // 0xb617c4: b.eq            #0xb61b74
    // 0xb617c8: mov             x0, x5
    // 0xb617cc: r2 = Null
    //     0xb617cc: mov             x2, NULL
    // 0xb617d0: r1 = Null
    //     0xb617d0: mov             x1, NULL
    // 0xb617d4: r4 = LoadClassIdInstr(r0)
    //     0xb617d4: ldur            x4, [x0, #-1]
    //     0xb617d8: ubfx            x4, x4, #0xc, #0x14
    // 0xb617dc: r17 = 4212
    //     0xb617dc: mov             x17, #0x1074
    // 0xb617e0: cmp             x4, x17
    // 0xb617e4: b.eq            #0xb617fc
    // 0xb617e8: r8 = FlexParentData
    //     0xb617e8: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb617ec: ldr             x8, [x8, #0x10]
    // 0xb617f0: r3 = Null
    //     0xb617f0: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a2b8] Null
    //     0xb617f4: ldr             x3, [x3, #0x2b8]
    // 0xb617f8: r0 = DefaultTypeTest()
    //     0xb617f8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb617fc: ldur            x0, [fp, #-0x38]
    // 0xb61800: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb61800: ldur            w1, [x0, #0x17]
    // 0xb61804: DecompressPointer r1
    //     0xb61804: add             x1, x1, HEAP, lsl #32
    // 0xb61808: cmp             w1, NULL
    // 0xb6180c: b.ne            #0xb61818
    // 0xb61810: r0 = 0
    //     0xb61810: mov             x0, #0
    // 0xb61814: b               #0xb61824
    // 0xb61818: r0 = LoadInt32Instr(r1)
    //     0xb61818: sbfx            x0, x1, #1, #0x1f
    //     0xb6181c: tbz             w1, #0, #0xb61824
    //     0xb61820: ldur            x0, [x1, #7]
    // 0xb61824: cmp             x0, #0
    // 0xb61828: b.le            #0xb61858
    // 0xb6182c: ldur            x4, [fp, #-0x40]
    // 0xb61830: scvtf           d0, x0
    // 0xb61834: LoadField: d1 = r4->field_7
    //     0xb61834: ldur            d1, [x4, #7]
    // 0xb61838: fmul            d2, d0, d1
    // 0xb6183c: ldur            x1, [fp, #-8]
    // 0xb61840: ldur            x2, [fp, #-0x20]
    // 0xb61844: ldur            x3, [fp, #-0x10]
    // 0xb61848: mov             v0.16b, v2.16b
    // 0xb6184c: r0 = _constraintsForFlexChild()
    //     0xb6184c: bl              #0xb18c08  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_constraintsForFlexChild
    // 0xb61850: mov             x3, x0
    // 0xb61854: b               #0xb6185c
    // 0xb61858: ldur            x3, [fp, #-0x28]
    // 0xb6185c: ldur            x0, [fp, #-8]
    // 0xb61860: ldur            x2, [fp, #-0x20]
    // 0xb61864: stur            x3, [fp, #-0x38]
    // 0xb61868: r1 = Function '_computeDryLayout@29392247':.
    //     0xb61868: add             x1, PP, #0x27, lsl #12  ; [pp+0x27010] AnonymousClosure: (0xb20488), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout (0xb204c4)
    //     0xb6186c: ldr             x1, [x1, #0x10]
    // 0xb61870: r0 = AllocateClosure()
    //     0xb61870: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb61874: r16 = <BoxConstraints, Size>
    //     0xb61874: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0xb61878: ldr             x16, [x16, #0x18]
    // 0xb6187c: ldur            lr, [fp, #-0x20]
    // 0xb61880: stp             lr, x16, [SP, #0x18]
    // 0xb61884: r16 = Instance__DryLayout
    //     0xb61884: add             x16, PP, #0x27, lsl #12  ; [pp+0x27020] Obj!_DryLayout@129c191
    //     0xb61888: ldr             x16, [x16, #0x20]
    // 0xb6188c: ldur            lr, [fp, #-0x38]
    // 0xb61890: stp             lr, x16, [SP, #8]
    // 0xb61894: str             x0, [SP]
    // 0xb61898: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb61898: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb6189c: r0 = _computeIntrinsics()
    //     0xb6189c: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb618a0: ldur            x1, [fp, #-8]
    // 0xb618a4: LoadField: r2 = r1->field_63
    //     0xb618a4: ldur            w2, [x1, #0x63]
    // 0xb618a8: DecompressPointer r2
    //     0xb618a8: add             x2, x2, HEAP, lsl #32
    // 0xb618ac: LoadField: r3 = r2->field_7
    //     0xb618ac: ldur            x3, [x2, #7]
    // 0xb618b0: cmp             x3, #0
    // 0xb618b4: b.gt            #0xb618c4
    // 0xb618b8: LoadField: d0 = r0->field_7
    //     0xb618b8: ldur            d0, [x0, #7]
    // 0xb618bc: mov             v2.16b, v0.16b
    // 0xb618c0: b               #0xb618cc
    // 0xb618c4: LoadField: d0 = r0->field_f
    //     0xb618c4: ldur            d0, [x0, #0xf]
    // 0xb618c8: mov             v2.16b, v0.16b
    // 0xb618cc: ldur            d0, [fp, #-0x58]
    // 0xb618d0: ldur            d1, [fp, #-0x60]
    // 0xb618d4: fadd            d3, d2, d1
    // 0xb618d8: fadd            d2, d0, d3
    // 0xb618dc: stur            d2, [fp, #-0x70]
    // 0xb618e0: ldur            x16, [fp, #-0x30]
    // 0xb618e4: ldur            lr, [fp, #-0x20]
    // 0xb618e8: stp             lr, x16, [SP]
    // 0xb618ec: ldur            x0, [fp, #-0x30]
    // 0xb618f0: ClosureCall
    //     0xb618f0: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb618f4: ldur            x2, [x0, #0x1f]
    //     0xb618f8: blr             x2
    // 0xb618fc: ldur            d2, [fp, #-0x70]
    // 0xb61900: mov             x4, x0
    // 0xb61904: ldur            x0, [fp, #-0x40]
    // 0xb61908: ldur            d0, [fp, #-0x68]
    // 0xb6190c: ldur            d1, [fp, #-0x60]
    // 0xb61910: b               #0xb61720
    // 0xb61914: LoadField: r0 = r3->field_57
    //     0xb61914: ldur            w0, [x3, #0x57]
    // 0xb61918: DecompressPointer r0
    //     0xb61918: add             x0, x0, HEAP, lsl #32
    // 0xb6191c: mov             x5, x0
    // 0xb61920: ldur            x4, [fp, #-0x40]
    // 0xb61924: stur            x5, [fp, #-0x30]
    // 0xb61928: CheckStackOverflow
    //     0xb61928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6192c: cmp             SP, x16
    //     0xb61930: b.ls            #0xb61b78
    // 0xb61934: cmp             w5, NULL
    // 0xb61938: b.eq            #0xb61b18
    // 0xb6193c: cmp             w4, NULL
    // 0xb61940: b.eq            #0xb619e8
    // 0xb61944: LoadField: r6 = r5->field_7
    //     0xb61944: ldur            w6, [x5, #7]
    // 0xb61948: DecompressPointer r6
    //     0xb61948: add             x6, x6, HEAP, lsl #32
    // 0xb6194c: stur            x6, [fp, #-0x20]
    // 0xb61950: cmp             w6, NULL
    // 0xb61954: b.eq            #0xb61b80
    // 0xb61958: mov             x0, x6
    // 0xb6195c: r2 = Null
    //     0xb6195c: mov             x2, NULL
    // 0xb61960: r1 = Null
    //     0xb61960: mov             x1, NULL
    // 0xb61964: r4 = LoadClassIdInstr(r0)
    //     0xb61964: ldur            x4, [x0, #-1]
    //     0xb61968: ubfx            x4, x4, #0xc, #0x14
    // 0xb6196c: r17 = 4212
    //     0xb6196c: mov             x17, #0x1074
    // 0xb61970: cmp             x4, x17
    // 0xb61974: b.eq            #0xb6198c
    // 0xb61978: r8 = FlexParentData
    //     0xb61978: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb6197c: ldr             x8, [x8, #0x10]
    // 0xb61980: r3 = Null
    //     0xb61980: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a2c8] Null
    //     0xb61984: ldr             x3, [x3, #0x2c8]
    // 0xb61988: r0 = DefaultTypeTest()
    //     0xb61988: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb6198c: ldur            x0, [fp, #-0x20]
    // 0xb61990: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb61990: ldur            w1, [x0, #0x17]
    // 0xb61994: DecompressPointer r1
    //     0xb61994: add             x1, x1, HEAP, lsl #32
    // 0xb61998: cmp             w1, NULL
    // 0xb6199c: b.ne            #0xb619a8
    // 0xb619a0: r0 = 0
    //     0xb619a0: mov             x0, #0
    // 0xb619a4: b               #0xb619b4
    // 0xb619a8: r0 = LoadInt32Instr(r1)
    //     0xb619a8: sbfx            x0, x1, #1, #0x1f
    //     0xb619ac: tbz             w1, #0, #0xb619b4
    //     0xb619b0: ldur            x0, [x1, #7]
    // 0xb619b4: cmp             x0, #0
    // 0xb619b8: b.le            #0xb619e8
    // 0xb619bc: ldur            x4, [fp, #-0x40]
    // 0xb619c0: scvtf           d0, x0
    // 0xb619c4: LoadField: d1 = r4->field_7
    //     0xb619c4: ldur            d1, [x4, #7]
    // 0xb619c8: fmul            d2, d0, d1
    // 0xb619cc: ldur            x1, [fp, #-8]
    // 0xb619d0: ldur            x2, [fp, #-0x30]
    // 0xb619d4: ldur            x3, [fp, #-0x10]
    // 0xb619d8: mov             v0.16b, v2.16b
    // 0xb619dc: r0 = _constraintsForFlexChild()
    //     0xb619dc: bl              #0xb18c08  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_constraintsForFlexChild
    // 0xb619e0: mov             x2, x0
    // 0xb619e4: b               #0xb619ec
    // 0xb619e8: ldur            x2, [fp, #-0x28]
    // 0xb619ec: ldur            x3, [fp, #-0x18]
    // 0xb619f0: r0 = AllocateRecord2()
    //     0xb619f0: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb619f4: ldur            x2, [fp, #-0x30]
    // 0xb619f8: r1 = Function '_computeDryBaseline@29392247':.
    //     0xb619f8: add             x1, PP, #0x90, lsl #12  ; [pp+0x90868] AnonymousClosure: (0xb196f0), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryBaseline (0xb1972c)
    //     0xb619fc: ldr             x1, [x1, #0x868]
    // 0xb61a00: stur            x0, [fp, #-0x20]
    // 0xb61a04: r0 = AllocateClosure()
    //     0xb61a04: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb61a08: r16 = <(BoxConstraints, TextBaseline), double?>
    //     0xb61a08: add             x16, PP, #0x90, lsl #12  ; [pp+0x907f8] TypeArguments: <(BoxConstraints, TextBaseline), double?>
    //     0xb61a0c: ldr             x16, [x16, #0x7f8]
    // 0xb61a10: ldur            lr, [fp, #-0x30]
    // 0xb61a14: stp             lr, x16, [SP, #0x18]
    // 0xb61a18: r16 = Instance__Baseline
    //     0xb61a18: add             x16, PP, #0x90, lsl #12  ; [pp+0x90800] Obj!_Baseline@129c181
    //     0xb61a1c: ldr             x16, [x16, #0x800]
    // 0xb61a20: ldur            lr, [fp, #-0x20]
    // 0xb61a24: stp             lr, x16, [SP, #8]
    // 0xb61a28: str             x0, [SP]
    // 0xb61a2c: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb61a2c: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb61a30: r0 = _computeIntrinsics()
    //     0xb61a30: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb61a34: mov             x3, x0
    // 0xb61a38: stur            x3, [fp, #-0x38]
    // 0xb61a3c: cmp             w3, NULL
    // 0xb61a40: b.ne            #0xb61aa4
    // 0xb61a44: ldur            x2, [fp, #-0x30]
    // 0xb61a48: LoadField: r3 = r2->field_7
    //     0xb61a48: ldur            w3, [x2, #7]
    // 0xb61a4c: DecompressPointer r3
    //     0xb61a4c: add             x3, x3, HEAP, lsl #32
    // 0xb61a50: stur            x3, [fp, #-0x20]
    // 0xb61a54: cmp             w3, NULL
    // 0xb61a58: b.eq            #0xb61b84
    // 0xb61a5c: mov             x0, x3
    // 0xb61a60: r2 = Null
    //     0xb61a60: mov             x2, NULL
    // 0xb61a64: r1 = Null
    //     0xb61a64: mov             x1, NULL
    // 0xb61a68: r4 = LoadClassIdInstr(r0)
    //     0xb61a68: ldur            x4, [x0, #-1]
    //     0xb61a6c: ubfx            x4, x4, #0xc, #0x14
    // 0xb61a70: r17 = 4212
    //     0xb61a70: mov             x17, #0x1074
    // 0xb61a74: cmp             x4, x17
    // 0xb61a78: b.eq            #0xb61a90
    // 0xb61a7c: r8 = FlexParentData
    //     0xb61a7c: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb61a80: ldr             x8, [x8, #0x10]
    // 0xb61a84: r3 = Null
    //     0xb61a84: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a2d8] Null
    //     0xb61a88: ldr             x3, [x3, #0x2d8]
    // 0xb61a8c: r0 = DefaultTypeTest()
    //     0xb61a8c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb61a90: ldur            x0, [fp, #-0x20]
    // 0xb61a94: LoadField: r5 = r0->field_13
    //     0xb61a94: ldur            w5, [x0, #0x13]
    // 0xb61a98: DecompressPointer r5
    //     0xb61a98: add             x5, x5, HEAP, lsl #32
    // 0xb61a9c: ldur            x3, [fp, #-8]
    // 0xb61aa0: b               #0xb61920
    // 0xb61aa4: ldur            x1, [fp, #-0x48]
    // 0xb61aa8: ldur            x2, [fp, #-0x30]
    // 0xb61aac: r0 = LoadClassIdInstr(r1)
    //     0xb61aac: ldur            x0, [x1, #-1]
    //     0xb61ab0: ubfx            x0, x0, #0xc, #0x14
    // 0xb61ab4: r0 = GDT[cid_x0 + -0xd48]()
    //     0xb61ab4: sub             lr, x0, #0xd48
    //     0xb61ab8: ldr             lr, [x21, lr, lsl #3]
    //     0xb61abc: blr             lr
    // 0xb61ac0: cmp             w0, NULL
    // 0xb61ac4: b.ne            #0xb61ad0
    // 0xb61ac8: ldur            d0, [fp, #-0x68]
    // 0xb61acc: b               #0xb61ad4
    // 0xb61ad0: LoadField: d0 = r0->field_7
    //     0xb61ad0: ldur            d0, [x0, #7]
    // 0xb61ad4: ldur            x0, [fp, #-0x38]
    // 0xb61ad8: LoadField: d1 = r0->field_7
    //     0xb61ad8: ldur            d1, [x0, #7]
    // 0xb61adc: fadd            d2, d1, d0
    // 0xb61ae0: r0 = inline_Allocate_Double()
    //     0xb61ae0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb61ae4: add             x0, x0, #0x10
    //     0xb61ae8: cmp             x1, x0
    //     0xb61aec: b.ls            #0xb61b88
    //     0xb61af0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb61af4: sub             x0, x0, #0xf
    //     0xb61af8: mov             x1, #0xe19c
    //     0xb61afc: movk            x1, #3, lsl #16
    //     0xb61b00: stur            x1, [x0, #-1]
    // 0xb61b04: dmb             ishst
    // 0xb61b08: StoreField: r0->field_7 = d2
    //     0xb61b08: stur            d2, [x0, #7]
    // 0xb61b0c: LeaveFrame
    //     0xb61b0c: mov             SP, fp
    //     0xb61b10: ldp             fp, lr, [SP], #0x10
    // 0xb61b14: ret
    //     0xb61b14: ret             
    // 0xb61b18: r0 = Null
    //     0xb61b18: mov             x0, NULL
    // 0xb61b1c: LeaveFrame
    //     0xb61b1c: mov             SP, fp
    //     0xb61b20: ldp             fp, lr, [SP], #0x10
    // 0xb61b24: ret
    //     0xb61b24: ret             
    // 0xb61b28: r0 = StateError()
    //     0xb61b28: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb61b2c: mov             x1, x0
    // 0xb61b30: r0 = "Pattern matching error"
    //     0xb61b30: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e528] "Pattern matching error"
    //     0xb61b34: ldr             x0, [x0, #0x528]
    // 0xb61b38: StoreField: r1->field_b = r0
    //     0xb61b38: stur            w0, [x1, #0xb]
    // 0xb61b3c: mov             x0, x1
    // 0xb61b40: r0 = Throw()
    //     0xb61b40: bl              #0x13ddb2c  ; ThrowStub
    // 0xb61b44: brk             #0
    // 0xb61b48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb61b48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb61b4c: b               #0xb6157c
    // 0xb61b50: r0 = StackOverflowSharedWithFPURegs()
    //     0xb61b50: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb61b54: b               #0xb61738
    // 0xb61b58: SaveReg d0
    //     0xb61b58: str             q0, [SP, #-0x10]!
    // 0xb61b5c: SaveReg r2
    //     0xb61b5c: str             x2, [SP, #-8]!
    // 0xb61b60: r0 = AllocateDouble()
    //     0xb61b60: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61b64: mov             x3, x0
    // 0xb61b68: RestoreReg r2
    //     0xb61b68: ldr             x2, [SP], #8
    // 0xb61b6c: RestoreReg d0
    //     0xb61b6c: ldr             q0, [SP], #0x10
    // 0xb61b70: b               #0xb6177c
    // 0xb61b74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb61b74: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb61b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb61b78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb61b7c: b               #0xb61934
    // 0xb61b80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb61b80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb61b84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb61b84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb61b88: SaveReg d2
    //     0xb61b88: str             q2, [SP, #-0x10]!
    // 0xb61b8c: r0 = AllocateDouble()
    //     0xb61b8c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61b90: RestoreReg d2
    //     0xb61b90: ldr             q2, [SP], #0x10
    // 0xb61b94: b               #0xb61b08
  }
  get _ _flipMainAxis(/* No info */) {
    // ** addr: 0xb61ff4, size: 0x98
    // 0xb61ff4: LoadField: r2 = r1->field_57
    //     0xb61ff4: ldur            w2, [x1, #0x57]
    // 0xb61ff8: DecompressPointer r2
    //     0xb61ff8: add             x2, x2, HEAP, lsl #32
    // 0xb61ffc: cmp             w2, NULL
    // 0xb62000: b.eq            #0xb62084
    // 0xb62004: LoadField: r2 = r1->field_63
    //     0xb62004: ldur            w2, [x1, #0x63]
    // 0xb62008: DecompressPointer r2
    //     0xb62008: add             x2, x2, HEAP, lsl #32
    // 0xb6200c: LoadField: r3 = r2->field_7
    //     0xb6200c: ldur            x3, [x2, #7]
    // 0xb62010: cmp             x3, #0
    // 0xb62014: b.gt            #0xb6205c
    // 0xb62018: LoadField: r2 = r1->field_73
    //     0xb62018: ldur            w2, [x1, #0x73]
    // 0xb6201c: DecompressPointer r2
    //     0xb6201c: add             x2, x2, HEAP, lsl #32
    // 0xb62020: cmp             w2, NULL
    // 0xb62024: b.eq            #0xb62034
    // 0xb62028: r16 = Instance_TextDirection
    //     0xb62028: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xb6202c: cmp             w2, w16
    // 0xb62030: b.ne            #0xb6203c
    // 0xb62034: r2 = false
    //     0xb62034: add             x2, NULL, #0x30  ; false
    // 0xb62038: b               #0xb62054
    // 0xb6203c: r16 = Instance_TextDirection
    //     0xb6203c: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xb62040: cmp             w2, w16
    // 0xb62044: b.ne            #0xb62050
    // 0xb62048: r2 = true
    //     0xb62048: add             x2, NULL, #0x20  ; true
    // 0xb6204c: b               #0xb62054
    // 0xb62050: r2 = Null
    //     0xb62050: mov             x2, NULL
    // 0xb62054: mov             x1, x2
    // 0xb62058: b               #0xb6207c
    // 0xb6205c: LoadField: r2 = r1->field_77
    //     0xb6205c: ldur            w2, [x1, #0x77]
    // 0xb62060: DecompressPointer r2
    //     0xb62060: add             x2, x2, HEAP, lsl #32
    // 0xb62064: LoadField: r1 = r2->field_7
    //     0xb62064: ldur            x1, [x2, #7]
    // 0xb62068: cmp             x1, #0
    // 0xb6206c: b.gt            #0xb62078
    // 0xb62070: r1 = true
    //     0xb62070: add             x1, NULL, #0x20  ; true
    // 0xb62074: b               #0xb6207c
    // 0xb62078: r1 = false
    //     0xb62078: add             x1, NULL, #0x30  ; false
    // 0xb6207c: mov             x0, x1
    // 0xb62080: b               #0xb62088
    // 0xb62084: r0 = false
    //     0xb62084: add             x0, NULL, #0x30  ; false
    // 0xb62088: ret
    //     0xb62088: ret             
  }
  _ _computeDryDistanceToHighestBaseline(/* No info */) {
    // ** addr: 0xb6213c, size: 0x5b8
    // 0xb6213c: EnterFrame
    //     0xb6213c: stp             fp, lr, [SP, #-0x10]!
    //     0xb62140: mov             fp, SP
    // 0xb62144: AllocStack(0x98)
    //     0xb62144: sub             SP, SP, #0x98
    // 0xb62148: SetupParameters(RenderFlex this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0xb62148: mov             x4, x1
    //     0xb6214c: mov             x0, x2
    //     0xb62150: stur            x1, [fp, #-8]
    //     0xb62154: stur            x2, [fp, #-0x10]
    //     0xb62158: stur            x3, [fp, #-0x18]
    //     0xb6215c: stur            x5, [fp, #-0x20]
    // 0xb62160: CheckStackOverflow
    //     0xb62160: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb62164: cmp             SP, x16
    //     0xb62168: b.ls            #0xb626d0
    // 0xb6216c: mov             x1, x4
    // 0xb62170: mov             x2, x0
    // 0xb62174: r0 = _constraintsForNonFlexChild()
    //     0xb62174: bl              #0xb192f8  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_constraintsForNonFlexChild
    // 0xb62178: ldur            x1, [fp, #-8]
    // 0xb6217c: stur            x0, [fp, #-0x28]
    // 0xb62180: r0 = _flipMainAxis()
    //     0xb62180: bl              #0xb61ff4  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_flipMainAxis
    // 0xb62184: ldur            x1, [fp, #-8]
    // 0xb62188: stur            x0, [fp, #-0x30]
    // 0xb6218c: r0 = _flipCrossAxis()
    //     0xb6218c: bl              #0xb62860  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_flipCrossAxis
    // 0xb62190: mov             x3, x0
    // 0xb62194: ldur            x0, [fp, #-0x30]
    // 0xb62198: stur            x3, [fp, #-0x38]
    // 0xb6219c: tbnz            w0, #4, #0xb621d4
    // 0xb621a0: ldur            x0, [fp, #-8]
    // 0xb621a4: LoadField: r4 = r0->field_5b
    //     0xb621a4: ldur            w4, [x0, #0x5b]
    // 0xb621a8: DecompressPointer r4
    //     0xb621a8: add             x4, x4, HEAP, lsl #32
    // 0xb621ac: mov             x2, x0
    // 0xb621b0: stur            x4, [fp, #-0x30]
    // 0xb621b4: r1 = Function 'childBefore':.
    //     0xb621b4: add             x1, PP, #0x90, lsl #12  ; [pp+0x90758] AnonymousClosure: (0xb6208c), of [dart:mixin_deduplication] _MixinApplication14&RenderBox&ContainerRenderObjectMixin
    //     0xb621b8: ldr             x1, [x1, #0x758]
    // 0xb621bc: r0 = AllocateClosure()
    //     0xb621bc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb621c0: mov             x2, x0
    // 0xb621c4: ldur            x3, [fp, #-0x30]
    // 0xb621c8: r0 = AllocateRecord2()
    //     0xb621c8: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb621cc: mov             x3, x0
    // 0xb621d0: b               #0xb62204
    // 0xb621d4: ldur            x0, [fp, #-8]
    // 0xb621d8: LoadField: r3 = r0->field_57
    //     0xb621d8: ldur            w3, [x0, #0x57]
    // 0xb621dc: DecompressPointer r3
    //     0xb621dc: add             x3, x3, HEAP, lsl #32
    // 0xb621e0: mov             x2, x0
    // 0xb621e4: stur            x3, [fp, #-0x30]
    // 0xb621e8: r1 = Function 'childAfter':.
    //     0xb621e8: add             x1, PP, #0x90, lsl #12  ; [pp+0x90760] AnonymousClosure: (0xb17fac), of [dart:mixin_deduplication] _MixinApplication14&RenderBox&ContainerRenderObjectMixin
    //     0xb621ec: ldr             x1, [x1, #0x760]
    // 0xb621f0: r0 = AllocateClosure()
    //     0xb621f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb621f4: mov             x2, x0
    // 0xb621f8: ldur            x3, [fp, #-0x30]
    // 0xb621fc: r0 = AllocateRecord2()
    //     0xb621fc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb62200: mov             x3, x0
    // 0xb62204: stur            x3, [fp, #-0x40]
    // 0xb62208: LoadField: r4 = r3->field_f
    //     0xb62208: ldur            w4, [x3, #0xf]
    // 0xb6220c: DecompressPointer r4
    //     0xb6220c: add             x4, x4, HEAP, lsl #32
    // 0xb62210: mov             x0, x4
    // 0xb62214: stur            x4, [fp, #-0x30]
    // 0xb62218: r2 = Null
    //     0xb62218: mov             x2, NULL
    // 0xb6221c: r1 = Null
    //     0xb6221c: mov             x1, NULL
    // 0xb62220: cmp             w0, NULL
    // 0xb62224: b.eq            #0xb62270
    // 0xb62228: branchIfSmi(r0, 0xb62270)
    //     0xb62228: tbz             w0, #0, #0xb62270
    // 0xb6222c: r3 = SubtypeTestCache
    //     0xb6222c: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a2e8] SubtypeTestCache
    //     0xb62230: ldr             x3, [x3, #0x2e8]
    // 0xb62234: r30 = Subtype6TestCacheStub
    //     0xb62234: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0xb62238: LoadField: r30 = r30->field_7
    //     0xb62238: ldur            lr, [lr, #7]
    // 0xb6223c: blr             lr
    // 0xb62240: cmp             w7, NULL
    // 0xb62244: b.eq            #0xb62250
    // 0xb62248: tbnz            w7, #4, #0xb62270
    // 0xb6224c: b               #0xb62278
    // 0xb62250: r8 = (dynamic this, RenderBox) => RenderBox?
    //     0xb62250: add             x8, PP, #0x9a, lsl #12  ; [pp+0x9a2f0] FunctionType: (dynamic this, RenderBox) => RenderBox?
    //     0xb62254: ldr             x8, [x8, #0x2f0]
    // 0xb62258: r3 = SubtypeTestCache
    //     0xb62258: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a2f8] SubtypeTestCache
    //     0xb6225c: ldr             x3, [x3, #0x2f8]
    // 0xb62260: r30 = InstanceOfStub
    //     0xb62260: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xb62264: LoadField: r30 = r30->field_7
    //     0xb62264: ldur            lr, [lr, #7]
    // 0xb62268: blr             lr
    // 0xb6226c: b               #0xb6227c
    // 0xb62270: r0 = false
    //     0xb62270: add             x0, NULL, #0x30  ; false
    // 0xb62274: b               #0xb6227c
    // 0xb62278: r0 = true
    //     0xb62278: add             x0, NULL, #0x20  ; true
    // 0xb6227c: tbnz            w0, #4, #0xb626b0
    // 0xb62280: ldur            x0, [fp, #-0x40]
    // 0xb62284: LoadField: r2 = r0->field_13
    //     0xb62284: ldur            w2, [x0, #0x13]
    // 0xb62288: DecompressPointer r2
    //     0xb62288: add             x2, x2, HEAP, lsl #32
    // 0xb6228c: ldur            x1, [fp, #-8]
    // 0xb62290: stur            x2, [fp, #-0x48]
    // 0xb62294: r0 = _isBaselineAligned()
    //     0xb62294: bl              #0xb19268  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_isBaselineAligned
    // 0xb62298: tbnz            w0, #4, #0xb622cc
    // 0xb6229c: ldur            x3, [fp, #-8]
    // 0xb622a0: LoadField: r0 = r3->field_7b
    //     0xb622a0: ldur            w0, [x3, #0x7b]
    // 0xb622a4: DecompressPointer r0
    //     0xb622a4: add             x0, x0, HEAP, lsl #32
    // 0xb622a8: cmp             w0, NULL
    // 0xb622ac: b.eq            #0xb622c4
    // 0xb622b0: ldur            x0, [fp, #-0x20]
    // 0xb622b4: LoadField: r1 = r0->field_13
    //     0xb622b4: ldur            w1, [x0, #0x13]
    // 0xb622b8: DecompressPointer r1
    //     0xb622b8: add             x1, x1, HEAP, lsl #32
    // 0xb622bc: mov             x4, x1
    // 0xb622c0: b               #0xb622d8
    // 0xb622c4: ldur            x0, [fp, #-0x20]
    // 0xb622c8: b               #0xb622d4
    // 0xb622cc: ldur            x3, [fp, #-8]
    // 0xb622d0: ldur            x0, [fp, #-0x20]
    // 0xb622d4: r4 = Null
    //     0xb622d4: mov             x4, NULL
    // 0xb622d8: stur            x4, [fp, #-0x58]
    // 0xb622dc: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xb622dc: ldur            w5, [x0, #0x17]
    // 0xb622e0: DecompressPointer r5
    //     0xb622e0: add             x5, x5, HEAP, lsl #32
    // 0xb622e4: stur            x5, [fp, #-0x50]
    // 0xb622e8: LoadField: r1 = r0->field_7
    //     0xb622e8: ldur            w1, [x0, #7]
    // 0xb622ec: DecompressPointer r1
    //     0xb622ec: add             x1, x1, HEAP, lsl #32
    // 0xb622f0: LoadField: d0 = r1->field_f
    //     0xb622f0: ldur            d0, [x1, #0xf]
    // 0xb622f4: stur            d0, [fp, #-0x70]
    // 0xb622f8: ldur            x6, [fp, #-0x48]
    // 0xb622fc: r7 = Null
    //     0xb622fc: mov             x7, NULL
    // 0xb62300: stur            x7, [fp, #-0x40]
    // 0xb62304: stur            x6, [fp, #-0x48]
    // 0xb62308: CheckStackOverflow
    //     0xb62308: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6230c: cmp             SP, x16
    //     0xb62310: b.ls            #0xb626d8
    // 0xb62314: cmp             w6, NULL
    // 0xb62318: b.eq            #0xb6269c
    // 0xb6231c: cmp             w5, NULL
    // 0xb62320: b.eq            #0xb623c4
    // 0xb62324: LoadField: r8 = r6->field_7
    //     0xb62324: ldur            w8, [x6, #7]
    // 0xb62328: DecompressPointer r8
    //     0xb62328: add             x8, x8, HEAP, lsl #32
    // 0xb6232c: stur            x8, [fp, #-0x20]
    // 0xb62330: cmp             w8, NULL
    // 0xb62334: b.eq            #0xb626e0
    // 0xb62338: mov             x0, x8
    // 0xb6233c: r2 = Null
    //     0xb6233c: mov             x2, NULL
    // 0xb62340: r1 = Null
    //     0xb62340: mov             x1, NULL
    // 0xb62344: r4 = LoadClassIdInstr(r0)
    //     0xb62344: ldur            x4, [x0, #-1]
    //     0xb62348: ubfx            x4, x4, #0xc, #0x14
    // 0xb6234c: r17 = 4212
    //     0xb6234c: mov             x17, #0x1074
    // 0xb62350: cmp             x4, x17
    // 0xb62354: b.eq            #0xb6236c
    // 0xb62358: r8 = FlexParentData
    //     0xb62358: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xb6235c: ldr             x8, [x8, #0x10]
    // 0xb62360: r3 = Null
    //     0xb62360: add             x3, PP, #0x9a, lsl #12  ; [pp+0x9a300] Null
    //     0xb62364: ldr             x3, [x3, #0x300]
    // 0xb62368: r0 = DefaultTypeTest()
    //     0xb62368: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb6236c: ldur            x0, [fp, #-0x20]
    // 0xb62370: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb62370: ldur            w1, [x0, #0x17]
    // 0xb62374: DecompressPointer r1
    //     0xb62374: add             x1, x1, HEAP, lsl #32
    // 0xb62378: cmp             w1, NULL
    // 0xb6237c: b.ne            #0xb62388
    // 0xb62380: r0 = 0
    //     0xb62380: mov             x0, #0
    // 0xb62384: b               #0xb62394
    // 0xb62388: r0 = LoadInt32Instr(r1)
    //     0xb62388: sbfx            x0, x1, #1, #0x1f
    //     0xb6238c: tbz             w1, #0, #0xb62394
    //     0xb62390: ldur            x0, [x1, #7]
    // 0xb62394: cmp             x0, #0
    // 0xb62398: b.le            #0xb623c4
    // 0xb6239c: ldur            x4, [fp, #-0x50]
    // 0xb623a0: scvtf           d0, x0
    // 0xb623a4: LoadField: d1 = r4->field_7
    //     0xb623a4: ldur            d1, [x4, #7]
    // 0xb623a8: fmul            d2, d0, d1
    // 0xb623ac: ldur            x1, [fp, #-8]
    // 0xb623b0: ldur            x2, [fp, #-0x48]
    // 0xb623b4: ldur            x3, [fp, #-0x10]
    // 0xb623b8: mov             v0.16b, v2.16b
    // 0xb623bc: r0 = _constraintsForFlexChild()
    //     0xb623bc: bl              #0xb18c08  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_constraintsForFlexChild
    // 0xb623c0: b               #0xb623c8
    // 0xb623c4: ldur            x0, [fp, #-0x28]
    // 0xb623c8: mov             x2, x0
    // 0xb623cc: ldur            x3, [fp, #-0x18]
    // 0xb623d0: stur            x0, [fp, #-0x20]
    // 0xb623d4: r0 = AllocateRecord2()
    //     0xb623d4: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb623d8: ldur            x2, [fp, #-0x48]
    // 0xb623dc: r1 = Function '_computeDryBaseline@29392247':.
    //     0xb623dc: add             x1, PP, #0x90, lsl #12  ; [pp+0x90868] AnonymousClosure: (0xb196f0), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryBaseline (0xb1972c)
    //     0xb623e0: ldr             x1, [x1, #0x868]
    // 0xb623e4: stur            x0, [fp, #-0x60]
    // 0xb623e8: r0 = AllocateClosure()
    //     0xb623e8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb623ec: stur            x0, [fp, #-0x68]
    // 0xb623f0: r16 = <(BoxConstraints, TextBaseline), double?>
    //     0xb623f0: add             x16, PP, #0x90, lsl #12  ; [pp+0x907f8] TypeArguments: <(BoxConstraints, TextBaseline), double?>
    //     0xb623f4: ldr             x16, [x16, #0x7f8]
    // 0xb623f8: ldur            lr, [fp, #-0x48]
    // 0xb623fc: stp             lr, x16, [SP, #0x18]
    // 0xb62400: r16 = Instance__Baseline
    //     0xb62400: add             x16, PP, #0x90, lsl #12  ; [pp+0x90800] Obj!_Baseline@129c181
    //     0xb62404: ldr             x16, [x16, #0x800]
    // 0xb62408: ldur            lr, [fp, #-0x60]
    // 0xb6240c: stp             lr, x16, [SP, #8]
    // 0xb62410: str             x0, [SP]
    // 0xb62414: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb62414: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb62418: r0 = _computeIntrinsics()
    //     0xb62418: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb6241c: stur            x0, [fp, #-0x60]
    // 0xb62420: cmp             w0, NULL
    // 0xb62424: b.eq            #0xb62658
    // 0xb62428: ldur            x1, [fp, #-8]
    // 0xb6242c: r0 = _isBaselineAligned()
    //     0xb6242c: bl              #0xb19268  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_isBaselineAligned
    // 0xb62430: tbnz            w0, #4, #0xb62484
    // 0xb62434: ldur            x0, [fp, #-8]
    // 0xb62438: LoadField: r3 = r0->field_7b
    //     0xb62438: ldur            w3, [x0, #0x7b]
    // 0xb6243c: DecompressPointer r3
    //     0xb6243c: add             x3, x3, HEAP, lsl #32
    // 0xb62440: cmp             w3, NULL
    // 0xb62444: b.eq            #0xb62484
    // 0xb62448: ldur            x2, [fp, #-0x20]
    // 0xb6244c: r0 = AllocateRecord2()
    //     0xb6244c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb62450: r16 = <(BoxConstraints, TextBaseline), double?>
    //     0xb62450: add             x16, PP, #0x90, lsl #12  ; [pp+0x907f8] TypeArguments: <(BoxConstraints, TextBaseline), double?>
    //     0xb62454: ldr             x16, [x16, #0x7f8]
    // 0xb62458: ldur            lr, [fp, #-0x48]
    // 0xb6245c: stp             lr, x16, [SP, #0x18]
    // 0xb62460: r16 = Instance__Baseline
    //     0xb62460: add             x16, PP, #0x90, lsl #12  ; [pp+0x90800] Obj!_Baseline@129c181
    //     0xb62464: ldr             x16, [x16, #0x800]
    // 0xb62468: stp             x0, x16, [SP, #8]
    // 0xb6246c: ldur            x16, [fp, #-0x68]
    // 0xb62470: str             x16, [SP]
    // 0xb62474: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb62474: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb62478: r0 = _computeIntrinsics()
    //     0xb62478: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb6247c: mov             x1, x0
    // 0xb62480: b               #0xb62488
    // 0xb62484: r1 = Null
    //     0xb62484: mov             x1, NULL
    // 0xb62488: ldur            x0, [fp, #-0x58]
    // 0xb6248c: cmp             w0, NULL
    // 0xb62490: b.eq            #0xb624b0
    // 0xb62494: cmp             w1, NULL
    // 0xb62498: b.eq            #0xb624b0
    // 0xb6249c: LoadField: d0 = r0->field_7
    //     0xb6249c: ldur            d0, [x0, #7]
    // 0xb624a0: LoadField: d1 = r1->field_7
    //     0xb624a0: ldur            d1, [x1, #7]
    // 0xb624a4: fsub            d2, d0, d1
    // 0xb624a8: mov             v0.16b, v2.16b
    // 0xb624ac: b               #0xb625ec
    // 0xb624b0: ldur            x3, [fp, #-8]
    // 0xb624b4: LoadField: r1 = r3->field_6f
    //     0xb624b4: ldur            w1, [x3, #0x6f]
    // 0xb624b8: DecompressPointer r1
    //     0xb624b8: add             x1, x1, HEAP, lsl #32
    // 0xb624bc: r16 = Instance_CrossAxisAlignment
    //     0xb624bc: add             x16, PP, #0x89, lsl #12  ; [pp+0x89a68] Obj!CrossAxisAlignment@12c44e1
    //     0xb624c0: ldr             x16, [x16, #0xa68]
    // 0xb624c4: cmp             w1, w16
    // 0xb624c8: b.ne            #0xb62564
    // 0xb624cc: LoadField: r1 = r3->field_63
    //     0xb624cc: ldur            w1, [x3, #0x63]
    // 0xb624d0: DecompressPointer r1
    //     0xb624d0: add             x1, x1, HEAP, lsl #32
    // 0xb624d4: r16 = Instance_Axis
    //     0xb624d4: ldr             x16, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xb624d8: cmp             w1, w16
    // 0xb624dc: b.ne            #0xb62564
    // 0xb624e0: ldur            x2, [fp, #-0x48]
    // 0xb624e4: r1 = Function '_computeDryLayout@29392247':.
    //     0xb624e4: add             x1, PP, #0x27, lsl #12  ; [pp+0x27010] AnonymousClosure: (0xb20488), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout (0xb204c4)
    //     0xb624e8: ldr             x1, [x1, #0x10]
    // 0xb624ec: r0 = AllocateClosure()
    //     0xb624ec: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb624f0: r16 = <BoxConstraints, Size>
    //     0xb624f0: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0xb624f4: ldr             x16, [x16, #0x18]
    // 0xb624f8: ldur            lr, [fp, #-0x48]
    // 0xb624fc: stp             lr, x16, [SP, #0x18]
    // 0xb62500: r16 = Instance__DryLayout
    //     0xb62500: add             x16, PP, #0x27, lsl #12  ; [pp+0x27020] Obj!_DryLayout@129c191
    //     0xb62504: ldr             x16, [x16, #0x20]
    // 0xb62508: ldur            lr, [fp, #-0x20]
    // 0xb6250c: stp             lr, x16, [SP, #8]
    // 0xb62510: str             x0, [SP]
    // 0xb62514: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb62514: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb62518: r0 = _computeIntrinsics()
    //     0xb62518: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb6251c: mov             x1, x0
    // 0xb62520: ldur            x0, [fp, #-8]
    // 0xb62524: LoadField: r2 = r0->field_63
    //     0xb62524: ldur            w2, [x0, #0x63]
    // 0xb62528: DecompressPointer r2
    //     0xb62528: add             x2, x2, HEAP, lsl #32
    // 0xb6252c: LoadField: r3 = r2->field_7
    //     0xb6252c: ldur            x3, [x2, #7]
    // 0xb62530: cmp             x3, #0
    // 0xb62534: b.gt            #0xb62540
    // 0xb62538: LoadField: d0 = r1->field_f
    //     0xb62538: ldur            d0, [x1, #0xf]
    // 0xb6253c: b               #0xb62544
    // 0xb62540: LoadField: d0 = r1->field_7
    //     0xb62540: ldur            d0, [x1, #7]
    // 0xb62544: ldur            d1, [fp, #-0x70]
    // 0xb62548: fsub            d2, d1, d0
    // 0xb6254c: mov             v0.16b, v2.16b
    // 0xb62550: r1 = Instance_CrossAxisAlignment
    //     0xb62550: add             x1, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xb62554: ldr             x1, [x1, #0x830]
    // 0xb62558: r2 = false
    //     0xb62558: add             x2, NULL, #0x30  ; false
    // 0xb6255c: r0 = _getChildCrossAxisOffset()
    //     0xb6255c: bl              #0xb626f4  ; [package:flutter/src/rendering/flex.dart] CrossAxisAlignment::_getChildCrossAxisOffset
    // 0xb62560: b               #0xb625ec
    // 0xb62564: ldur            x0, [fp, #-8]
    // 0xb62568: ldur            x2, [fp, #-0x48]
    // 0xb6256c: r1 = Function '_computeDryLayout@29392247':.
    //     0xb6256c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27010] AnonymousClosure: (0xb20488), in [package:flutter/src/rendering/box.dart] RenderBox::_computeDryLayout (0xb204c4)
    //     0xb62570: ldr             x1, [x1, #0x10]
    // 0xb62574: r0 = AllocateClosure()
    //     0xb62574: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb62578: r16 = <BoxConstraints, Size>
    //     0xb62578: add             x16, PP, #0x27, lsl #12  ; [pp+0x27018] TypeArguments: <BoxConstraints, Size>
    //     0xb6257c: ldr             x16, [x16, #0x18]
    // 0xb62580: ldur            lr, [fp, #-0x48]
    // 0xb62584: stp             lr, x16, [SP, #0x18]
    // 0xb62588: r16 = Instance__DryLayout
    //     0xb62588: add             x16, PP, #0x27, lsl #12  ; [pp+0x27020] Obj!_DryLayout@129c191
    //     0xb6258c: ldr             x16, [x16, #0x20]
    // 0xb62590: ldur            lr, [fp, #-0x20]
    // 0xb62594: stp             lr, x16, [SP, #8]
    // 0xb62598: str             x0, [SP]
    // 0xb6259c: r4 = const [0x2, 0x4, 0x4, 0x4, null]
    //     0xb6259c: ldr             x4, [PP, #0x700]  ; [pp+0x700] List(5) [0x2, 0x4, 0x4, 0x4, Null]
    // 0xb625a0: r0 = _computeIntrinsics()
    //     0xb625a0: bl              #0xb16358  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsics
    // 0xb625a4: mov             x1, x0
    // 0xb625a8: ldur            x0, [fp, #-8]
    // 0xb625ac: LoadField: r2 = r0->field_6f
    //     0xb625ac: ldur            w2, [x0, #0x6f]
    // 0xb625b0: DecompressPointer r2
    //     0xb625b0: add             x2, x2, HEAP, lsl #32
    // 0xb625b4: LoadField: r3 = r0->field_63
    //     0xb625b4: ldur            w3, [x0, #0x63]
    // 0xb625b8: DecompressPointer r3
    //     0xb625b8: add             x3, x3, HEAP, lsl #32
    // 0xb625bc: LoadField: r4 = r3->field_7
    //     0xb625bc: ldur            x4, [x3, #7]
    // 0xb625c0: cmp             x4, #0
    // 0xb625c4: b.gt            #0xb625d0
    // 0xb625c8: LoadField: d0 = r1->field_f
    //     0xb625c8: ldur            d0, [x1, #0xf]
    // 0xb625cc: b               #0xb625d4
    // 0xb625d0: LoadField: d0 = r1->field_7
    //     0xb625d0: ldur            d0, [x1, #7]
    // 0xb625d4: ldur            d1, [fp, #-0x70]
    // 0xb625d8: fsub            d2, d1, d0
    // 0xb625dc: mov             x1, x2
    // 0xb625e0: mov             v0.16b, v2.16b
    // 0xb625e4: ldur            x2, [fp, #-0x38]
    // 0xb625e8: r0 = _getChildCrossAxisOffset()
    //     0xb625e8: bl              #0xb626f4  ; [package:flutter/src/rendering/flex.dart] CrossAxisAlignment::_getChildCrossAxisOffset
    // 0xb625ec: ldur            x1, [fp, #-0x40]
    // 0xb625f0: ldur            x0, [fp, #-0x60]
    // 0xb625f4: LoadField: d1 = r0->field_7
    //     0xb625f4: ldur            d1, [x0, #7]
    // 0xb625f8: fadd            d2, d1, d0
    // 0xb625fc: cmp             w1, NULL
    // 0xb62600: b.eq            #0xb62620
    // 0xb62604: LoadField: d0 = r1->field_7
    //     0xb62604: ldur            d0, [x1, #7]
    // 0xb62608: fcmp            d0, d2
    // 0xb6260c: b.lt            #0xb62618
    // 0xb62610: mov             v0.16b, v2.16b
    // 0xb62614: b               #0xb62624
    // 0xb62618: LoadField: d0 = r1->field_7
    //     0xb62618: ldur            d0, [x1, #7]
    // 0xb6261c: b               #0xb62624
    // 0xb62620: mov             v0.16b, v2.16b
    // 0xb62624: r0 = inline_Allocate_Double()
    //     0xb62624: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb62628: add             x0, x0, #0x10
    //     0xb6262c: cmp             x1, x0
    //     0xb62630: b.ls            #0xb626e4
    //     0xb62634: str             x0, [THR, #0x60]  ; THR::top
    //     0xb62638: sub             x0, x0, #0xf
    //     0xb6263c: mov             x1, #0xe19c
    //     0xb62640: movk            x1, #3, lsl #16
    //     0xb62644: stur            x1, [x0, #-1]
    // 0xb62648: dmb             ishst
    // 0xb6264c: StoreField: r0->field_7 = d0
    //     0xb6264c: stur            d0, [x0, #7]
    // 0xb62650: mov             x7, x0
    // 0xb62654: b               #0xb62660
    // 0xb62658: ldur            x1, [fp, #-0x40]
    // 0xb6265c: mov             x7, x1
    // 0xb62660: stur            x7, [fp, #-0x20]
    // 0xb62664: ldur            x16, [fp, #-0x30]
    // 0xb62668: ldur            lr, [fp, #-0x48]
    // 0xb6266c: stp             lr, x16, [SP]
    // 0xb62670: ldur            x0, [fp, #-0x30]
    // 0xb62674: ClosureCall
    //     0xb62674: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb62678: ldur            x2, [x0, #0x1f]
    //     0xb6267c: blr             x2
    // 0xb62680: ldur            x7, [fp, #-0x20]
    // 0xb62684: mov             x6, x0
    // 0xb62688: ldur            x3, [fp, #-8]
    // 0xb6268c: ldur            x4, [fp, #-0x58]
    // 0xb62690: ldur            x5, [fp, #-0x50]
    // 0xb62694: ldur            d0, [fp, #-0x70]
    // 0xb62698: b               #0xb62300
    // 0xb6269c: mov             x1, x7
    // 0xb626a0: mov             x0, x1
    // 0xb626a4: LeaveFrame
    //     0xb626a4: mov             SP, fp
    //     0xb626a8: ldp             fp, lr, [SP], #0x10
    // 0xb626ac: ret
    //     0xb626ac: ret             
    // 0xb626b0: r0 = StateError()
    //     0xb626b0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb626b4: mov             x1, x0
    // 0xb626b8: r0 = "Pattern matching error"
    //     0xb626b8: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e528] "Pattern matching error"
    //     0xb626bc: ldr             x0, [x0, #0x528]
    // 0xb626c0: StoreField: r1->field_b = r0
    //     0xb626c0: stur            w0, [x1, #0xb]
    // 0xb626c4: mov             x0, x1
    // 0xb626c8: r0 = Throw()
    //     0xb626c8: bl              #0x13ddb2c  ; ThrowStub
    // 0xb626cc: brk             #0
    // 0xb626d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb626d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb626d4: b               #0xb6216c
    // 0xb626d8: r0 = StackOverflowSharedWithFPURegs()
    //     0xb626d8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb626dc: b               #0xb62314
    // 0xb626e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xb626e0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xb626e4: SaveReg d0
    //     0xb626e4: str             q0, [SP, #-0x10]!
    // 0xb626e8: r0 = AllocateDouble()
    //     0xb626e8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb626ec: RestoreReg d0
    //     0xb626ec: ldr             q0, [SP], #0x10
    // 0xb626f0: b               #0xb6264c
  }
  get _ _flipCrossAxis(/* No info */) {
    // ** addr: 0xb62860, size: 0x98
    // 0xb62860: LoadField: r2 = r1->field_57
    //     0xb62860: ldur            w2, [x1, #0x57]
    // 0xb62864: DecompressPointer r2
    //     0xb62864: add             x2, x2, HEAP, lsl #32
    // 0xb62868: cmp             w2, NULL
    // 0xb6286c: b.eq            #0xb628f0
    // 0xb62870: LoadField: r2 = r1->field_63
    //     0xb62870: ldur            w2, [x1, #0x63]
    // 0xb62874: DecompressPointer r2
    //     0xb62874: add             x2, x2, HEAP, lsl #32
    // 0xb62878: LoadField: r3 = r2->field_7
    //     0xb62878: ldur            x3, [x2, #7]
    // 0xb6287c: cmp             x3, #0
    // 0xb62880: b.gt            #0xb628ac
    // 0xb62884: LoadField: r2 = r1->field_77
    //     0xb62884: ldur            w2, [x1, #0x77]
    // 0xb62888: DecompressPointer r2
    //     0xb62888: add             x2, x2, HEAP, lsl #32
    // 0xb6288c: LoadField: r3 = r2->field_7
    //     0xb6288c: ldur            x3, [x2, #7]
    // 0xb62890: cmp             x3, #0
    // 0xb62894: b.gt            #0xb628a0
    // 0xb62898: r2 = true
    //     0xb62898: add             x2, NULL, #0x20  ; true
    // 0xb6289c: b               #0xb628a4
    // 0xb628a0: r2 = false
    //     0xb628a0: add             x2, NULL, #0x30  ; false
    // 0xb628a4: mov             x1, x2
    // 0xb628a8: b               #0xb628e8
    // 0xb628ac: LoadField: r2 = r1->field_73
    //     0xb628ac: ldur            w2, [x1, #0x73]
    // 0xb628b0: DecompressPointer r2
    //     0xb628b0: add             x2, x2, HEAP, lsl #32
    // 0xb628b4: cmp             w2, NULL
    // 0xb628b8: b.eq            #0xb628c8
    // 0xb628bc: r16 = Instance_TextDirection
    //     0xb628bc: ldr             x16, [PP, #0x25b0]  ; [pp+0x25b0] Obj!TextDirection@12c73a1
    // 0xb628c0: cmp             w2, w16
    // 0xb628c4: b.ne            #0xb628d0
    // 0xb628c8: r1 = false
    //     0xb628c8: add             x1, NULL, #0x30  ; false
    // 0xb628cc: b               #0xb628e8
    // 0xb628d0: r16 = Instance_TextDirection
    //     0xb628d0: ldr             x16, [PP, #0x2578]  ; [pp+0x2578] Obj!TextDirection@12c7381
    // 0xb628d4: cmp             w2, w16
    // 0xb628d8: b.ne            #0xb628e4
    // 0xb628dc: r1 = true
    //     0xb628dc: add             x1, NULL, #0x20  ; true
    // 0xb628e0: b               #0xb628e8
    // 0xb628e4: r1 = Null
    //     0xb628e4: mov             x1, NULL
    // 0xb628e8: mov             x0, x1
    // 0xb628ec: b               #0xb628f4
    // 0xb628f0: r0 = false
    //     0xb628f0: add             x0, NULL, #0x30  ; false
    // 0xb628f4: ret
    //     0xb628f4: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbf548, size: 0x758
    // 0xbbf548: EnterFrame
    //     0xbbf548: stp             fp, lr, [SP, #-0x10]!
    //     0xbbf54c: mov             fp, SP
    // 0xbbf550: AllocStack(0x70)
    //     0xbbf550: sub             SP, SP, #0x70
    // 0xbbf554: SetupParameters(RenderFlex this /* r1 => r3, fp-0x10 */)
    //     0xbbf554: mov             x3, x1
    //     0xbbf558: stur            x1, [fp, #-0x10]
    // 0xbbf55c: CheckStackOverflow
    //     0xbbf55c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbf560: cmp             SP, x16
    //     0xbbf564: b.ls            #0xbbfc80
    // 0xbbf568: LoadField: r4 = r3->field_27
    //     0xbbf568: ldur            w4, [x3, #0x27]
    // 0xbbf56c: DecompressPointer r4
    //     0xbbf56c: add             x4, x4, HEAP, lsl #32
    // 0xbbf570: stur            x4, [fp, #-8]
    // 0xbbf574: cmp             w4, NULL
    // 0xbbf578: b.eq            #0xbbfa24
    // 0xbbf57c: mov             x0, x4
    // 0xbbf580: r2 = Null
    //     0xbbf580: mov             x2, NULL
    // 0xbbf584: r1 = Null
    //     0xbbf584: mov             x1, NULL
    // 0xbbf588: r4 = LoadClassIdInstr(r0)
    //     0xbbf588: ldur            x4, [x0, #-1]
    //     0xbbf58c: ubfx            x4, x4, #0xc, #0x14
    // 0xbbf590: sub             x4, x4, #0xb46
    // 0xbbf594: cmp             x4, #1
    // 0xbbf598: b.ls            #0xbbf5ac
    // 0xbbf59c: r8 = BoxConstraints
    //     0xbbf59c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbf5a0: r3 = Null
    //     0xbbf5a0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90740] Null
    //     0xbbf5a4: ldr             x3, [x3, #0x740]
    // 0xbbf5a8: r0 = BoxConstraints()
    //     0xbbf5a8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbf5ac: ldur            x1, [fp, #-0x10]
    // 0xbbf5b0: ldur            x2, [fp, #-8]
    // 0xbbf5b4: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getBaseline': static.
    //     0xbbf5b4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90750] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getBaseline': static. (0x7f2adaaa6ca0)
    //     0xbbf5b8: ldr             x3, [x3, #0x750]
    // 0xbbf5bc: r5 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbbf5bc: add             x5, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbbf5c0: ldr             x5, [x5, #0x4f8]
    // 0xbbf5c4: r0 = _computeSizes()
    //     0xbbf5c4: bl              #0xb1805c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_computeSizes
    // 0xbbf5c8: stur            x0, [fp, #-8]
    // 0xbbf5cc: LoadField: r1 = r0->field_7
    //     0xbbf5cc: ldur            w1, [x0, #7]
    // 0xbbf5d0: DecompressPointer r1
    //     0xbbf5d0: add             x1, x1, HEAP, lsl #32
    // 0xbbf5d4: LoadField: d0 = r1->field_f
    //     0xbbf5d4: ldur            d0, [x1, #0xf]
    // 0xbbf5d8: ldur            x3, [fp, #-0x10]
    // 0xbbf5dc: stur            d0, [fp, #-0x48]
    // 0xbbf5e0: LoadField: r2 = r3->field_63
    //     0xbbf5e0: ldur            w2, [x3, #0x63]
    // 0xbbf5e4: DecompressPointer r2
    //     0xbbf5e4: add             x2, x2, HEAP, lsl #32
    // 0xbbf5e8: r0 = _AxisSize._convert()
    //     0xbbf5e8: bl              #0xb191dc  ; [package:flutter/src/rendering/flex.dart] ::_AxisSize._convert
    // 0xbbf5ec: ldur            x2, [fp, #-0x10]
    // 0xbbf5f0: StoreField: r2->field_4b = r0
    //     0xbbf5f0: stur            w0, [x2, #0x4b]
    //     0xbbf5f4: ldurb           w16, [x2, #-1]
    //     0xbbf5f8: ldurb           w17, [x0, #-1]
    //     0xbbf5fc: and             x16, x17, x16, lsr #2
    //     0xbbf600: tst             x16, HEAP, lsr #32
    //     0xbbf604: b.eq            #0xbbf60c
    //     0xbbf608: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbf60c: ldur            x0, [fp, #-8]
    // 0xbbf610: LoadField: d0 = r0->field_b
    //     0xbbf610: ldur            d0, [x0, #0xb]
    // 0xbbf614: fneg            d1, d0
    // 0xbbf618: d2 = 0.000000
    //     0xbbf618: eor             v2.16b, v2.16b, v2.16b
    // 0xbbf61c: fmax            v3.2d, v2.2d, v1.2d
    // 0xbbf620: StoreField: r2->field_7f = d3
    //     0xbbf620: stur            d3, [x2, #0x7f]
    // 0xbbf624: fmax            v1.2d, v2.2d, v0.2d
    // 0xbbf628: mov             x1, x2
    // 0xbbf62c: stur            d1, [fp, #-0x50]
    // 0xbbf630: r0 = _flipMainAxis()
    //     0xbbf630: bl              #0xb61ff4  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_flipMainAxis
    // 0xbbf634: ldur            x1, [fp, #-0x10]
    // 0xbbf638: stur            x0, [fp, #-0x18]
    // 0xbbf63c: r0 = _flipCrossAxis()
    //     0xbbf63c: bl              #0xb62860  ; [package:flutter/src/rendering/flex.dart] RenderFlex::_flipCrossAxis
    // 0xbbf640: mov             x4, x0
    // 0xbbf644: ldur            x0, [fp, #-0x10]
    // 0xbbf648: stur            x4, [fp, #-0x20]
    // 0xbbf64c: LoadField: r1 = r0->field_67
    //     0xbbf64c: ldur            w1, [x0, #0x67]
    // 0xbbf650: DecompressPointer r1
    //     0xbbf650: add             x1, x1, HEAP, lsl #32
    // 0xbbf654: LoadField: r2 = r0->field_4f
    //     0xbbf654: ldur            x2, [x0, #0x4f]
    // 0xbbf658: LoadField: d1 = r0->field_8b
    //     0xbbf658: ldur            d1, [x0, #0x8b]
    // 0xbbf65c: ldur            d0, [fp, #-0x50]
    // 0xbbf660: ldur            x3, [fp, #-0x18]
    // 0xbbf664: r0 = _distributeSpace()
    //     0xbbf664: bl              #0xb61b98  ; [package:flutter/src/rendering/flex.dart] MainAxisAlignment::_distributeSpace
    // 0xbbf668: mov             x3, x0
    // 0xbbf66c: stur            x3, [fp, #-0x30]
    // 0xbbf670: mov             x4, x1
    // 0xbbf674: ldur            x0, [fp, #-0x18]
    // 0xbbf678: stur            x4, [fp, #-0x28]
    // 0xbbf67c: tbnz            w0, #4, #0xbbf6b4
    // 0xbbf680: ldur            x0, [fp, #-0x10]
    // 0xbbf684: LoadField: r5 = r0->field_5b
    //     0xbbf684: ldur            w5, [x0, #0x5b]
    // 0xbbf688: DecompressPointer r5
    //     0xbbf688: add             x5, x5, HEAP, lsl #32
    // 0xbbf68c: mov             x2, x0
    // 0xbbf690: stur            x5, [fp, #-0x18]
    // 0xbbf694: r1 = Function 'childBefore':.
    //     0xbbf694: add             x1, PP, #0x90, lsl #12  ; [pp+0x90758] AnonymousClosure: (0xb6208c), of [dart:mixin_deduplication] _MixinApplication14&RenderBox&ContainerRenderObjectMixin
    //     0xbbf698: ldr             x1, [x1, #0x758]
    // 0xbbf69c: r0 = AllocateClosure()
    //     0xbbf69c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbbf6a0: mov             x2, x0
    // 0xbbf6a4: ldur            x3, [fp, #-0x18]
    // 0xbbf6a8: r0 = AllocateRecord2()
    //     0xbbf6a8: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbbf6ac: mov             x3, x0
    // 0xbbf6b0: b               #0xbbf6e4
    // 0xbbf6b4: ldur            x0, [fp, #-0x10]
    // 0xbbf6b8: LoadField: r3 = r0->field_57
    //     0xbbf6b8: ldur            w3, [x0, #0x57]
    // 0xbbf6bc: DecompressPointer r3
    //     0xbbf6bc: add             x3, x3, HEAP, lsl #32
    // 0xbbf6c0: mov             x2, x0
    // 0xbbf6c4: stur            x3, [fp, #-0x18]
    // 0xbbf6c8: r1 = Function 'childAfter':.
    //     0xbbf6c8: add             x1, PP, #0x90, lsl #12  ; [pp+0x90760] AnonymousClosure: (0xb17fac), of [dart:mixin_deduplication] _MixinApplication14&RenderBox&ContainerRenderObjectMixin
    //     0xbbf6cc: ldr             x1, [x1, #0x760]
    // 0xbbf6d0: r0 = AllocateClosure()
    //     0xbbf6d0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbbf6d4: mov             x2, x0
    // 0xbbf6d8: ldur            x3, [fp, #-0x18]
    // 0xbbf6dc: r0 = AllocateRecord2()
    //     0xbbf6dc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbbf6e0: mov             x3, x0
    // 0xbbf6e4: stur            x3, [fp, #-0x38]
    // 0xbbf6e8: LoadField: r4 = r3->field_f
    //     0xbbf6e8: ldur            w4, [x3, #0xf]
    // 0xbbf6ec: DecompressPointer r4
    //     0xbbf6ec: add             x4, x4, HEAP, lsl #32
    // 0xbbf6f0: mov             x0, x4
    // 0xbbf6f4: stur            x4, [fp, #-0x18]
    // 0xbbf6f8: r2 = Null
    //     0xbbf6f8: mov             x2, NULL
    // 0xbbf6fc: r1 = Null
    //     0xbbf6fc: mov             x1, NULL
    // 0xbbf700: cmp             w0, NULL
    // 0xbbf704: b.eq            #0xbbf750
    // 0xbbf708: branchIfSmi(r0, 0xbbf750)
    //     0xbbf708: tbz             w0, #0, #0xbbf750
    // 0xbbf70c: r3 = SubtypeTestCache
    //     0xbbf70c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90768] SubtypeTestCache
    //     0xbbf710: ldr             x3, [x3, #0x768]
    // 0xbbf714: r30 = Subtype6TestCacheStub
    //     0xbbf714: ldr             lr, [PP, #0x18]  ; [pp+0x18] Stub: Subtype6TestCache (0x7d27bc)
    // 0xbbf718: LoadField: r30 = r30->field_7
    //     0xbbf718: ldur            lr, [lr, #7]
    // 0xbbf71c: blr             lr
    // 0xbbf720: cmp             w7, NULL
    // 0xbbf724: b.eq            #0xbbf730
    // 0xbbf728: tbnz            w7, #4, #0xbbf750
    // 0xbbf72c: b               #0xbbf758
    // 0xbbf730: r8 = (dynamic this, RenderBox) => RenderBox?
    //     0xbbf730: add             x8, PP, #0x90, lsl #12  ; [pp+0x90770] FunctionType: (dynamic this, RenderBox) => RenderBox?
    //     0xbbf734: ldr             x8, [x8, #0x770]
    // 0xbbf738: r3 = SubtypeTestCache
    //     0xbbf738: add             x3, PP, #0x90, lsl #12  ; [pp+0x90778] SubtypeTestCache
    //     0xbbf73c: ldr             x3, [x3, #0x778]
    // 0xbbf740: r30 = InstanceOfStub
    //     0xbbf740: ldr             lr, [PP, #0x2f8]  ; [pp+0x2f8] Stub: InstanceOf (0x7c12f4)
    // 0xbbf744: LoadField: r30 = r30->field_7
    //     0xbbf744: ldur            lr, [lr, #7]
    // 0xbbf748: blr             lr
    // 0xbbf74c: b               #0xbbf75c
    // 0xbbf750: r0 = false
    //     0xbbf750: add             x0, NULL, #0x30  ; false
    // 0xbbf754: b               #0xbbf75c
    // 0xbbf758: r0 = true
    //     0xbbf758: add             x0, NULL, #0x20  ; true
    // 0xbbf75c: tbnz            w0, #4, #0xbbfc60
    // 0xbbf760: ldur            x3, [fp, #-8]
    // 0xbbf764: ldur            x0, [fp, #-0x38]
    // 0xbbf768: ldur            x1, [fp, #-0x30]
    // 0xbbf76c: ldur            x2, [fp, #-0x28]
    // 0xbbf770: LoadField: r4 = r0->field_13
    //     0xbbf770: ldur            w4, [x0, #0x13]
    // 0xbbf774: DecompressPointer r4
    //     0xbbf774: add             x4, x4, HEAP, lsl #32
    // 0xbbf778: LoadField: r0 = r3->field_13
    //     0xbbf778: ldur            w0, [x3, #0x13]
    // 0xbbf77c: DecompressPointer r0
    //     0xbbf77c: add             x0, x0, HEAP, lsl #32
    // 0xbbf780: stur            x0, [fp, #-0x38]
    // 0xbbf784: LoadField: d0 = r1->field_7
    //     0xbbf784: ldur            d0, [x1, #7]
    // 0xbbf788: LoadField: d1 = r2->field_7
    //     0xbbf788: ldur            d1, [x2, #7]
    // 0xbbf78c: stur            d1, [fp, #-0x58]
    // 0xbbf790: mov             v2.16b, v0.16b
    // 0xbbf794: ldur            x3, [fp, #-0x10]
    // 0xbbf798: ldur            d0, [fp, #-0x48]
    // 0xbbf79c: stur            x4, [fp, #-8]
    // 0xbbf7a0: stur            d2, [fp, #-0x50]
    // 0xbbf7a4: CheckStackOverflow
    //     0xbbf7a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbf7a8: cmp             SP, x16
    //     0xbbf7ac: b.ls            #0xbbfc88
    // 0xbbf7b0: cmp             w4, NULL
    // 0xbbf7b4: b.eq            #0xbbfa14
    // 0xbbf7b8: cmp             w0, NULL
    // 0xbbf7bc: b.eq            #0xbbf7ec
    // 0xbbf7c0: LoadField: r2 = r3->field_7b
    //     0xbbf7c0: ldur            w2, [x3, #0x7b]
    // 0xbbf7c4: DecompressPointer r2
    //     0xbbf7c4: add             x2, x2, HEAP, lsl #32
    // 0xbbf7c8: cmp             w2, NULL
    // 0xbbf7cc: b.eq            #0xbbfc90
    // 0xbbf7d0: mov             x1, x4
    // 0xbbf7d4: r0 = getDistanceToActualBaseline()
    //     0xbbf7d4: bl              #0xb53d74  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0xbbf7d8: cmp             w0, NULL
    // 0xbbf7dc: r16 = true
    //     0xbbf7dc: add             x16, NULL, #0x20  ; true
    // 0xbbf7e0: r17 = false
    //     0xbbf7e0: add             x17, NULL, #0x30  ; false
    // 0xbbf7e4: csel            x1, x16, x17, ne
    // 0xbbf7e8: b               #0xbbf7f4
    // 0xbbf7ec: r1 = false
    //     0xbbf7ec: add             x1, NULL, #0x30  ; false
    // 0xbbf7f0: r0 = Null
    //     0xbbf7f0: mov             x0, NULL
    // 0xbbf7f4: tbnz            w1, #4, #0xbbf820
    // 0xbbf7f8: ldur            x3, [fp, #-0x38]
    // 0xbbf7fc: cmp             w0, NULL
    // 0xbbf800: b.eq            #0xbbfc94
    // 0xbbf804: cmp             w3, NULL
    // 0xbbf808: b.eq            #0xbbfc98
    // 0xbbf80c: LoadField: d0 = r0->field_7
    //     0xbbf80c: ldur            d0, [x0, #7]
    // 0xbbf810: LoadField: d1 = r3->field_7
    //     0xbbf810: ldur            d1, [x3, #7]
    // 0xbbf814: fsub            d3, d1, d0
    // 0xbbf818: mov             v0.16b, v3.16b
    // 0xbbf81c: b               #0xbbf8d8
    // 0xbbf820: ldur            x0, [fp, #-0x10]
    // 0xbbf824: ldur            x3, [fp, #-0x38]
    // 0xbbf828: LoadField: r1 = r0->field_6f
    //     0xbbf828: ldur            w1, [x0, #0x6f]
    // 0xbbf82c: DecompressPointer r1
    //     0xbbf82c: add             x1, x1, HEAP, lsl #32
    // 0xbbf830: r16 = Instance_CrossAxisAlignment
    //     0xbbf830: add             x16, PP, #0x89, lsl #12  ; [pp+0x89a68] Obj!CrossAxisAlignment@12c44e1
    //     0xbbf834: ldr             x16, [x16, #0xa68]
    // 0xbbf838: cmp             w1, w16
    // 0xbbf83c: b.ne            #0xbbf88c
    // 0xbbf840: LoadField: r2 = r0->field_63
    //     0xbbf840: ldur            w2, [x0, #0x63]
    // 0xbbf844: DecompressPointer r2
    //     0xbbf844: add             x2, x2, HEAP, lsl #32
    // 0xbbf848: r16 = Instance_Axis
    //     0xbbf848: ldr             x16, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xbbf84c: cmp             w2, w16
    // 0xbbf850: b.ne            #0xbbf88c
    // 0xbbf854: ldur            x4, [fp, #-8]
    // 0xbbf858: LoadField: r1 = r4->field_4b
    //     0xbbf858: ldur            w1, [x4, #0x4b]
    // 0xbbf85c: DecompressPointer r1
    //     0xbbf85c: add             x1, x1, HEAP, lsl #32
    // 0xbbf860: cmp             w1, NULL
    // 0xbbf864: b.eq            #0xbbfa40
    // 0xbbf868: ldur            d1, [fp, #-0x48]
    // 0xbbf86c: LoadField: d0 = r1->field_f
    //     0xbbf86c: ldur            d0, [x1, #0xf]
    // 0xbbf870: fsub            d2, d1, d0
    // 0xbbf874: mov             v0.16b, v2.16b
    // 0xbbf878: r1 = Instance_CrossAxisAlignment
    //     0xbbf878: add             x1, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xbbf87c: ldr             x1, [x1, #0x830]
    // 0xbbf880: r2 = false
    //     0xbbf880: add             x2, NULL, #0x30  ; false
    // 0xbbf884: r0 = _getChildCrossAxisOffset()
    //     0xbbf884: bl              #0xb626f4  ; [package:flutter/src/rendering/flex.dart] CrossAxisAlignment::_getChildCrossAxisOffset
    // 0xbbf888: b               #0xbbf8d8
    // 0xbbf88c: ldur            x0, [fp, #-8]
    // 0xbbf890: LoadField: r2 = r0->field_4b
    //     0xbbf890: ldur            w2, [x0, #0x4b]
    // 0xbbf894: DecompressPointer r2
    //     0xbbf894: add             x2, x2, HEAP, lsl #32
    // 0xbbf898: cmp             w2, NULL
    // 0xbbf89c: b.eq            #0xbbfbac
    // 0xbbf8a0: ldur            x3, [fp, #-0x10]
    // 0xbbf8a4: LoadField: r4 = r3->field_63
    //     0xbbf8a4: ldur            w4, [x3, #0x63]
    // 0xbbf8a8: DecompressPointer r4
    //     0xbbf8a8: add             x4, x4, HEAP, lsl #32
    // 0xbbf8ac: LoadField: r5 = r4->field_7
    //     0xbbf8ac: ldur            x5, [x4, #7]
    // 0xbbf8b0: cmp             x5, #0
    // 0xbbf8b4: b.gt            #0xbbf8c0
    // 0xbbf8b8: LoadField: d0 = r2->field_f
    //     0xbbf8b8: ldur            d0, [x2, #0xf]
    // 0xbbf8bc: b               #0xbbf8c4
    // 0xbbf8c0: LoadField: d0 = r2->field_7
    //     0xbbf8c0: ldur            d0, [x2, #7]
    // 0xbbf8c4: ldur            d1, [fp, #-0x48]
    // 0xbbf8c8: fsub            d2, d1, d0
    // 0xbbf8cc: mov             v0.16b, v2.16b
    // 0xbbf8d0: ldur            x2, [fp, #-0x20]
    // 0xbbf8d4: r0 = _getChildCrossAxisOffset()
    //     0xbbf8d4: bl              #0xb626f4  ; [package:flutter/src/rendering/flex.dart] CrossAxisAlignment::_getChildCrossAxisOffset
    // 0xbbf8d8: ldur            x4, [fp, #-0x10]
    // 0xbbf8dc: ldur            x3, [fp, #-8]
    // 0xbbf8e0: stur            d0, [fp, #-0x60]
    // 0xbbf8e4: LoadField: r5 = r3->field_7
    //     0xbbf8e4: ldur            w5, [x3, #7]
    // 0xbbf8e8: DecompressPointer r5
    //     0xbbf8e8: add             x5, x5, HEAP, lsl #32
    // 0xbbf8ec: stur            x5, [fp, #-0x28]
    // 0xbbf8f0: cmp             w5, NULL
    // 0xbbf8f4: b.eq            #0xbbfc9c
    // 0xbbf8f8: mov             x0, x5
    // 0xbbf8fc: r2 = Null
    //     0xbbf8fc: mov             x2, NULL
    // 0xbbf900: r1 = Null
    //     0xbbf900: mov             x1, NULL
    // 0xbbf904: r4 = LoadClassIdInstr(r0)
    //     0xbbf904: ldur            x4, [x0, #-1]
    //     0xbbf908: ubfx            x4, x4, #0xc, #0x14
    // 0xbbf90c: r17 = 4212
    //     0xbbf90c: mov             x17, #0x1074
    // 0xbbf910: cmp             x4, x17
    // 0xbbf914: b.eq            #0xbbf92c
    // 0xbbf918: r8 = FlexParentData
    //     0xbbf918: add             x8, PP, #0x85, lsl #12  ; [pp+0x85010] Type: FlexParentData
    //     0xbbf91c: ldr             x8, [x8, #0x10]
    // 0xbbf920: r3 = Null
    //     0xbbf920: add             x3, PP, #0x90, lsl #12  ; [pp+0x90780] Null
    //     0xbbf924: ldr             x3, [x3, #0x780]
    // 0xbbf928: r0 = DefaultTypeTest()
    //     0xbbf928: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbf92c: ldur            x0, [fp, #-0x10]
    // 0xbbf930: LoadField: r1 = r0->field_63
    //     0xbbf930: ldur            w1, [x0, #0x63]
    // 0xbbf934: DecompressPointer r1
    //     0xbbf934: add             x1, x1, HEAP, lsl #32
    // 0xbbf938: LoadField: r2 = r1->field_7
    //     0xbbf938: ldur            x2, [x1, #7]
    // 0xbbf93c: stur            x2, [fp, #-0x40]
    // 0xbbf940: cmp             x2, #0
    // 0xbbf944: b.gt            #0xbbf968
    // 0xbbf948: ldur            d1, [fp, #-0x50]
    // 0xbbf94c: ldur            d0, [fp, #-0x60]
    // 0xbbf950: r0 = Offset()
    //     0xbbf950: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbbf954: ldur            d0, [fp, #-0x50]
    // 0xbbf958: StoreField: r0->field_7 = d0
    //     0xbbf958: stur            d0, [x0, #7]
    // 0xbbf95c: ldur            d1, [fp, #-0x60]
    // 0xbbf960: StoreField: r0->field_f = d1
    //     0xbbf960: stur            d1, [x0, #0xf]
    // 0xbbf964: b               #0xbbf984
    // 0xbbf968: ldur            d0, [fp, #-0x50]
    // 0xbbf96c: ldur            d1, [fp, #-0x60]
    // 0xbbf970: r0 = Offset()
    //     0xbbf970: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbbf974: ldur            d0, [fp, #-0x60]
    // 0xbbf978: StoreField: r0->field_7 = d0
    //     0xbbf978: stur            d0, [x0, #7]
    // 0xbbf97c: ldur            d0, [fp, #-0x50]
    // 0xbbf980: StoreField: r0->field_f = d0
    //     0xbbf980: stur            d0, [x0, #0xf]
    // 0xbbf984: ldur            x3, [fp, #-8]
    // 0xbbf988: ldur            x1, [fp, #-0x28]
    // 0xbbf98c: StoreField: r1->field_7 = r0
    //     0xbbf98c: stur            w0, [x1, #7]
    //     0xbbf990: ldurb           w16, [x1, #-1]
    //     0xbbf994: ldurb           w17, [x0, #-1]
    //     0xbbf998: and             x16, x17, x16, lsr #2
    //     0xbbf99c: tst             x16, HEAP, lsr #32
    //     0xbbf9a0: b.eq            #0xbbf9a8
    //     0xbbf9a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbf9a8: LoadField: r0 = r3->field_4b
    //     0xbbf9a8: ldur            w0, [x3, #0x4b]
    // 0xbbf9ac: DecompressPointer r0
    //     0xbbf9ac: add             x0, x0, HEAP, lsl #32
    // 0xbbf9b0: cmp             w0, NULL
    // 0xbbf9b4: b.eq            #0xbbfaf8
    // 0xbbf9b8: ldur            x1, [fp, #-0x40]
    // 0xbbf9bc: cmp             x1, #0
    // 0xbbf9c0: b.gt            #0xbbf9d0
    // 0xbbf9c4: LoadField: d1 = r0->field_7
    //     0xbbf9c4: ldur            d1, [x0, #7]
    // 0xbbf9c8: mov             v2.16b, v1.16b
    // 0xbbf9cc: b               #0xbbf9d8
    // 0xbbf9d0: LoadField: d1 = r0->field_f
    //     0xbbf9d0: ldur            d1, [x0, #0xf]
    // 0xbbf9d4: mov             v2.16b, v1.16b
    // 0xbbf9d8: ldur            d1, [fp, #-0x58]
    // 0xbbf9dc: fadd            d3, d2, d1
    // 0xbbf9e0: fadd            d2, d0, d3
    // 0xbbf9e4: stur            d2, [fp, #-0x60]
    // 0xbbf9e8: ldur            x16, [fp, #-0x18]
    // 0xbbf9ec: stp             x3, x16, [SP]
    // 0xbbf9f0: ldur            x0, [fp, #-0x18]
    // 0xbbf9f4: ClosureCall
    //     0xbbf9f4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbbf9f8: ldur            x2, [x0, #0x1f]
    //     0xbbf9fc: blr             x2
    // 0xbbfa00: ldur            d2, [fp, #-0x60]
    // 0xbbfa04: mov             x4, x0
    // 0xbbfa08: ldur            x0, [fp, #-0x38]
    // 0xbbfa0c: ldur            d1, [fp, #-0x58]
    // 0xbbfa10: b               #0xbbf794
    // 0xbbfa14: r0 = Null
    //     0xbbfa14: mov             x0, NULL
    // 0xbbfa18: LeaveFrame
    //     0xbbfa18: mov             SP, fp
    //     0xbbfa1c: ldp             fp, lr, [SP], #0x10
    // 0xbbfa20: ret
    //     0xbbfa20: ret             
    // 0xbbfa24: r0 = StateError()
    //     0xbbfa24: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbfa28: mov             x1, x0
    // 0xbbfa2c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbfa2c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbfa30: StoreField: r1->field_b = r0
    //     0xbbfa30: stur            w0, [x1, #0xb]
    // 0xbbfa34: mov             x0, x1
    // 0xbbfa38: r0 = Throw()
    //     0xbbfa38: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbfa3c: brk             #0
    // 0xbbfa40: mov             x3, x4
    // 0xbbfa44: r1 = Null
    //     0xbbfa44: mov             x1, NULL
    // 0xbbfa48: r2 = 8
    //     0xbbfa48: mov             x2, #8
    // 0xbbfa4c: r0 = AllocateArray()
    //     0xbbfa4c: bl              #0x13df928  ; AllocateArrayStub
    // 0xbbfa50: stur            x0, [fp, #-0x10]
    // 0xbbfa54: r16 = "RenderBox was not laid out: "
    //     0xbbfa54: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbbfa58: StoreField: r0->field_f = r16
    //     0xbbfa58: stur            w16, [x0, #0xf]
    // 0xbbfa5c: ldur            x16, [fp, #-8]
    // 0xbbfa60: str             x16, [SP]
    // 0xbbfa64: r0 = runtimeType()
    //     0xbbfa64: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbbfa68: ldur            x1, [fp, #-0x10]
    // 0xbbfa6c: ArrayStore: r1[1] = r0  ; List_4
    //     0xbbfa6c: add             x25, x1, #0x13
    //     0xbbfa70: str             w0, [x25]
    //     0xbbfa74: tbz             w0, #0, #0xbbfa90
    //     0xbbfa78: ldurb           w16, [x1, #-1]
    //     0xbbfa7c: ldurb           w17, [x0, #-1]
    //     0xbbfa80: and             x16, x17, x16, lsr #2
    //     0xbbfa84: tst             x16, HEAP, lsr #32
    //     0xbbfa88: b.eq            #0xbbfa90
    //     0xbbfa8c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbfa90: ldur            x0, [fp, #-0x10]
    // 0xbbfa94: r16 = "#"
    //     0xbbfa94: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbbfa98: ArrayStore: r0[0] = r16  ; List_4
    //     0xbbfa98: stur            w16, [x0, #0x17]
    // 0xbbfa9c: ldur            x1, [fp, #-8]
    // 0xbbfaa0: r0 = shortHash()
    //     0xbbfaa0: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbbfaa4: ldur            x1, [fp, #-0x10]
    // 0xbbfaa8: ArrayStore: r1[3] = r0  ; List_4
    //     0xbbfaa8: add             x25, x1, #0x1b
    //     0xbbfaac: str             w0, [x25]
    //     0xbbfab0: tbz             w0, #0, #0xbbfacc
    //     0xbbfab4: ldurb           w16, [x1, #-1]
    //     0xbbfab8: ldurb           w17, [x0, #-1]
    //     0xbbfabc: and             x16, x17, x16, lsr #2
    //     0xbbfac0: tst             x16, HEAP, lsr #32
    //     0xbbfac4: b.eq            #0xbbfacc
    //     0xbbfac8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbfacc: ldur            x16, [fp, #-0x10]
    // 0xbbfad0: str             x16, [SP]
    // 0xbbfad4: r0 = _interpolate()
    //     0xbbfad4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbbfad8: stur            x0, [fp, #-0x10]
    // 0xbbfadc: r0 = StateError()
    //     0xbbfadc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbfae0: mov             x1, x0
    // 0xbbfae4: ldur            x0, [fp, #-0x10]
    // 0xbbfae8: StoreField: r1->field_b = r0
    //     0xbbfae8: stur            w0, [x1, #0xb]
    // 0xbbfaec: mov             x0, x1
    // 0xbbfaf0: r0 = Throw()
    //     0xbbfaf0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbfaf4: brk             #0
    // 0xbbfaf8: r1 = Null
    //     0xbbfaf8: mov             x1, NULL
    // 0xbbfafc: r2 = 8
    //     0xbbfafc: mov             x2, #8
    // 0xbbfb00: r0 = AllocateArray()
    //     0xbbfb00: bl              #0x13df928  ; AllocateArrayStub
    // 0xbbfb04: stur            x0, [fp, #-0x10]
    // 0xbbfb08: r16 = "RenderBox was not laid out: "
    //     0xbbfb08: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbbfb0c: StoreField: r0->field_f = r16
    //     0xbbfb0c: stur            w16, [x0, #0xf]
    // 0xbbfb10: ldur            x16, [fp, #-8]
    // 0xbbfb14: str             x16, [SP]
    // 0xbbfb18: r0 = runtimeType()
    //     0xbbfb18: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbbfb1c: ldur            x1, [fp, #-0x10]
    // 0xbbfb20: ArrayStore: r1[1] = r0  ; List_4
    //     0xbbfb20: add             x25, x1, #0x13
    //     0xbbfb24: str             w0, [x25]
    //     0xbbfb28: tbz             w0, #0, #0xbbfb44
    //     0xbbfb2c: ldurb           w16, [x1, #-1]
    //     0xbbfb30: ldurb           w17, [x0, #-1]
    //     0xbbfb34: and             x16, x17, x16, lsr #2
    //     0xbbfb38: tst             x16, HEAP, lsr #32
    //     0xbbfb3c: b.eq            #0xbbfb44
    //     0xbbfb40: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbfb44: ldur            x0, [fp, #-0x10]
    // 0xbbfb48: r16 = "#"
    //     0xbbfb48: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbbfb4c: ArrayStore: r0[0] = r16  ; List_4
    //     0xbbfb4c: stur            w16, [x0, #0x17]
    // 0xbbfb50: ldur            x1, [fp, #-8]
    // 0xbbfb54: r0 = shortHash()
    //     0xbbfb54: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbbfb58: ldur            x1, [fp, #-0x10]
    // 0xbbfb5c: ArrayStore: r1[3] = r0  ; List_4
    //     0xbbfb5c: add             x25, x1, #0x1b
    //     0xbbfb60: str             w0, [x25]
    //     0xbbfb64: tbz             w0, #0, #0xbbfb80
    //     0xbbfb68: ldurb           w16, [x1, #-1]
    //     0xbbfb6c: ldurb           w17, [x0, #-1]
    //     0xbbfb70: and             x16, x17, x16, lsr #2
    //     0xbbfb74: tst             x16, HEAP, lsr #32
    //     0xbbfb78: b.eq            #0xbbfb80
    //     0xbbfb7c: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbfb80: ldur            x16, [fp, #-0x10]
    // 0xbbfb84: str             x16, [SP]
    // 0xbbfb88: r0 = _interpolate()
    //     0xbbfb88: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbbfb8c: stur            x0, [fp, #-0x10]
    // 0xbbfb90: r0 = StateError()
    //     0xbbfb90: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbfb94: mov             x1, x0
    // 0xbbfb98: ldur            x0, [fp, #-0x10]
    // 0xbbfb9c: StoreField: r1->field_b = r0
    //     0xbbfb9c: stur            w0, [x1, #0xb]
    // 0xbbfba0: mov             x0, x1
    // 0xbbfba4: r0 = Throw()
    //     0xbbfba4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbfba8: brk             #0
    // 0xbbfbac: r1 = Null
    //     0xbbfbac: mov             x1, NULL
    // 0xbbfbb0: r2 = 8
    //     0xbbfbb0: mov             x2, #8
    // 0xbbfbb4: r0 = AllocateArray()
    //     0xbbfbb4: bl              #0x13df928  ; AllocateArrayStub
    // 0xbbfbb8: stur            x0, [fp, #-0x10]
    // 0xbbfbbc: r16 = "RenderBox was not laid out: "
    //     0xbbfbbc: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xbbfbc0: StoreField: r0->field_f = r16
    //     0xbbfbc0: stur            w16, [x0, #0xf]
    // 0xbbfbc4: ldur            x16, [fp, #-8]
    // 0xbbfbc8: str             x16, [SP]
    // 0xbbfbcc: r0 = runtimeType()
    //     0xbbfbcc: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0xbbfbd0: ldur            x1, [fp, #-0x10]
    // 0xbbfbd4: ArrayStore: r1[1] = r0  ; List_4
    //     0xbbfbd4: add             x25, x1, #0x13
    //     0xbbfbd8: str             w0, [x25]
    //     0xbbfbdc: tbz             w0, #0, #0xbbfbf8
    //     0xbbfbe0: ldurb           w16, [x1, #-1]
    //     0xbbfbe4: ldurb           w17, [x0, #-1]
    //     0xbbfbe8: and             x16, x17, x16, lsr #2
    //     0xbbfbec: tst             x16, HEAP, lsr #32
    //     0xbbfbf0: b.eq            #0xbbfbf8
    //     0xbbfbf4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbfbf8: ldur            x0, [fp, #-0x10]
    // 0xbbfbfc: r16 = "#"
    //     0xbbfbfc: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xbbfc00: ArrayStore: r0[0] = r16  ; List_4
    //     0xbbfc00: stur            w16, [x0, #0x17]
    // 0xbbfc04: ldur            x1, [fp, #-8]
    // 0xbbfc08: r0 = shortHash()
    //     0xbbfc08: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xbbfc0c: ldur            x1, [fp, #-0x10]
    // 0xbbfc10: ArrayStore: r1[3] = r0  ; List_4
    //     0xbbfc10: add             x25, x1, #0x1b
    //     0xbbfc14: str             w0, [x25]
    //     0xbbfc18: tbz             w0, #0, #0xbbfc34
    //     0xbbfc1c: ldurb           w16, [x1, #-1]
    //     0xbbfc20: ldurb           w17, [x0, #-1]
    //     0xbbfc24: and             x16, x17, x16, lsr #2
    //     0xbbfc28: tst             x16, HEAP, lsr #32
    //     0xbbfc2c: b.eq            #0xbbfc34
    //     0xbbfc30: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbbfc34: ldur            x16, [fp, #-0x10]
    // 0xbbfc38: str             x16, [SP]
    // 0xbbfc3c: r0 = _interpolate()
    //     0xbbfc3c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbbfc40: stur            x0, [fp, #-8]
    // 0xbbfc44: r0 = StateError()
    //     0xbbfc44: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbfc48: mov             x1, x0
    // 0xbbfc4c: ldur            x0, [fp, #-8]
    // 0xbbfc50: StoreField: r1->field_b = r0
    //     0xbbfc50: stur            w0, [x1, #0xb]
    // 0xbbfc54: mov             x0, x1
    // 0xbbfc58: r0 = Throw()
    //     0xbbfc58: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbfc5c: brk             #0
    // 0xbbfc60: r0 = StateError()
    //     0xbbfc60: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbfc64: mov             x1, x0
    // 0xbbfc68: r0 = "Pattern matching error"
    //     0xbbfc68: add             x0, PP, #0x8e, lsl #12  ; [pp+0x8e528] "Pattern matching error"
    //     0xbbfc6c: ldr             x0, [x0, #0x528]
    // 0xbbfc70: StoreField: r1->field_b = r0
    //     0xbbfc70: stur            w0, [x1, #0xb]
    // 0xbbfc74: mov             x0, x1
    // 0xbbfc78: r0 = Throw()
    //     0xbbfc78: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbfc7c: brk             #0
    // 0xbbfc80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbfc80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbfc84: b               #0xbbf568
    // 0xbbfc88: r0 = StackOverflowSharedWithFPURegs()
    //     0xbbfc88: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbbfc8c: b               #0xbbf7b0
    // 0xbbfc90: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbfc90: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbbfc94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbfc94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbfc98: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbbfc98: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xbbfc9c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbfc9c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0d868, size: 0xb8
    // 0xc0d868: EnterFrame
    //     0xc0d868: stp             fp, lr, [SP, #-0x10]!
    //     0xc0d86c: mov             fp, SP
    // 0xc0d870: AllocStack(0x8)
    //     0xc0d870: sub             SP, SP, #8
    // 0xc0d874: SetupParameters(RenderFlex this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0d874: mov             x0, x2
    //     0xc0d878: mov             x4, x1
    //     0xc0d87c: mov             x3, x2
    //     0xc0d880: stur            x2, [fp, #-8]
    // 0xc0d884: r2 = Null
    //     0xc0d884: mov             x2, NULL
    // 0xc0d888: r1 = Null
    //     0xc0d888: mov             x1, NULL
    // 0xc0d88c: r4 = 60
    //     0xc0d88c: mov             x4, #0x3c
    // 0xc0d890: branchIfSmi(r0, 0xc0d89c)
    //     0xc0d890: tbz             w0, #0, #0xc0d89c
    // 0xc0d894: r4 = LoadClassIdInstr(r0)
    //     0xc0d894: ldur            x4, [x0, #-1]
    //     0xc0d898: ubfx            x4, x4, #0xc, #0x14
    // 0xc0d89c: r17 = -4710
    //     0xc0d89c: mov             x17, #-0x1266
    // 0xc0d8a0: add             x4, x4, x17
    // 0xc0d8a4: cmp             x4, #0x109
    // 0xc0d8a8: b.ls            #0xc0d8bc
    // 0xc0d8ac: r8 = RenderBox
    //     0xc0d8ac: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0d8b0: r3 = Null
    //     0xc0d8b0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90870] Null
    //     0xc0d8b4: ldr             x3, [x3, #0x870]
    // 0xc0d8b8: r0 = RenderBox()
    //     0xc0d8b8: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0d8bc: ldur            x0, [fp, #-8]
    // 0xc0d8c0: LoadField: r1 = r0->field_7
    //     0xc0d8c0: ldur            w1, [x0, #7]
    // 0xc0d8c4: DecompressPointer r1
    //     0xc0d8c4: add             x1, x1, HEAP, lsl #32
    // 0xc0d8c8: r2 = LoadClassIdInstr(r1)
    //     0xc0d8c8: ldur            x2, [x1, #-1]
    //     0xc0d8cc: ubfx            x2, x2, #0xc, #0x14
    // 0xc0d8d0: r17 = 4212
    //     0xc0d8d0: mov             x17, #0x1074
    // 0xc0d8d4: cmp             x2, x17
    // 0xc0d8d8: b.eq            #0xc0d910
    // 0xc0d8dc: r1 = <RenderBox>
    //     0xc0d8dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0d8e0: ldr             x1, [x1, #0x5c8]
    // 0xc0d8e4: r0 = FlexParentData()
    //     0xc0d8e4: bl              #0xc0d920  ; AllocateFlexParentDataStub -> FlexParentData (size=0x20)
    // 0xc0d8e8: r1 = Instance_Offset
    //     0xc0d8e8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0d8ec: StoreField: r0->field_7 = r1
    //     0xc0d8ec: stur            w1, [x0, #7]
    // 0xc0d8f0: ldur            x1, [fp, #-8]
    // 0xc0d8f4: StoreField: r1->field_7 = r0
    //     0xc0d8f4: stur            w0, [x1, #7]
    //     0xc0d8f8: ldurb           w16, [x1, #-1]
    //     0xc0d8fc: ldurb           w17, [x0, #-1]
    //     0xc0d900: and             x16, x17, x16, lsr #2
    //     0xc0d904: tst             x16, HEAP, lsr #32
    //     0xc0d908: b.eq            #0xc0d910
    //     0xc0d90c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0d910: r0 = Null
    //     0xc0d910: mov             x0, NULL
    // 0xc0d914: LeaveFrame
    //     0xc0d914: mov             SP, fp
    //     0xc0d918: ldp             fp, lr, [SP], #0x10
    // 0xc0d91c: ret
    //     0xc0d91c: ret             
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcee31c, size: 0x60
    // 0xcee31c: EnterFrame
    //     0xcee31c: stp             fp, lr, [SP, #-0x10]!
    //     0xcee320: mov             fp, SP
    // 0xcee324: mov             x0, x2
    // 0xcee328: CheckStackOverflow
    //     0xcee328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee32c: cmp             SP, x16
    //     0xcee330: b.ls            #0xcee374
    // 0xcee334: LoadField: r2 = r1->field_73
    //     0xcee334: ldur            w2, [x1, #0x73]
    // 0xcee338: DecompressPointer r2
    //     0xcee338: add             x2, x2, HEAP, lsl #32
    // 0xcee33c: cmp             w2, w0
    // 0xcee340: b.eq            #0xcee364
    // 0xcee344: StoreField: r1->field_73 = r0
    //     0xcee344: stur            w0, [x1, #0x73]
    //     0xcee348: ldurb           w16, [x1, #-1]
    //     0xcee34c: ldurb           w17, [x0, #-1]
    //     0xcee350: and             x16, x17, x16, lsr #2
    //     0xcee354: tst             x16, HEAP, lsr #32
    //     0xcee358: b.eq            #0xcee360
    //     0xcee35c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee360: r0 = markNeedsLayout()
    //     0xcee360: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee364: r0 = Null
    //     0xcee364: mov             x0, NULL
    // 0xcee368: LeaveFrame
    //     0xcee368: mov             SP, fp
    //     0xcee36c: ldp             fp, lr, [SP], #0x10
    // 0xcee370: ret
    //     0xcee370: ret             
    // 0xcee374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee374: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee378: b               #0xcee334
  }
  set _ spacing=(/* No info */) {
    // ** addr: 0xcee678, size: 0x50
    // 0xcee678: EnterFrame
    //     0xcee678: stp             fp, lr, [SP, #-0x10]!
    //     0xcee67c: mov             fp, SP
    // 0xcee680: CheckStackOverflow
    //     0xcee680: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee684: cmp             SP, x16
    //     0xcee688: b.ls            #0xcee6c0
    // 0xcee68c: LoadField: d1 = r1->field_8b
    //     0xcee68c: ldur            d1, [x1, #0x8b]
    // 0xcee690: fcmp            d1, d0
    // 0xcee694: b.ne            #0xcee6a8
    // 0xcee698: r0 = Null
    //     0xcee698: mov             x0, NULL
    // 0xcee69c: LeaveFrame
    //     0xcee69c: mov             SP, fp
    //     0xcee6a0: ldp             fp, lr, [SP], #0x10
    // 0xcee6a4: ret
    //     0xcee6a4: ret             
    // 0xcee6a8: StoreField: r1->field_8b = d0
    //     0xcee6a8: stur            d0, [x1, #0x8b]
    // 0xcee6ac: r0 = markNeedsLayout()
    //     0xcee6ac: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee6b0: r0 = Null
    //     0xcee6b0: mov             x0, NULL
    // 0xcee6b4: LeaveFrame
    //     0xcee6b4: mov             SP, fp
    //     0xcee6b8: ldp             fp, lr, [SP], #0x10
    // 0xcee6bc: ret
    //     0xcee6bc: ret             
    // 0xcee6c0: r0 = StackOverflowSharedWithFPURegs()
    //     0xcee6c0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcee6c4: b               #0xcee68c
  }
  set _ textBaseline=(/* No info */) {
    // ** addr: 0xcee6c8, size: 0x60
    // 0xcee6c8: EnterFrame
    //     0xcee6c8: stp             fp, lr, [SP, #-0x10]!
    //     0xcee6cc: mov             fp, SP
    // 0xcee6d0: mov             x0, x2
    // 0xcee6d4: CheckStackOverflow
    //     0xcee6d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee6d8: cmp             SP, x16
    //     0xcee6dc: b.ls            #0xcee720
    // 0xcee6e0: LoadField: r2 = r1->field_7b
    //     0xcee6e0: ldur            w2, [x1, #0x7b]
    // 0xcee6e4: DecompressPointer r2
    //     0xcee6e4: add             x2, x2, HEAP, lsl #32
    // 0xcee6e8: cmp             w2, w0
    // 0xcee6ec: b.eq            #0xcee710
    // 0xcee6f0: StoreField: r1->field_7b = r0
    //     0xcee6f0: stur            w0, [x1, #0x7b]
    //     0xcee6f4: ldurb           w16, [x1, #-1]
    //     0xcee6f8: ldurb           w17, [x0, #-1]
    //     0xcee6fc: and             x16, x17, x16, lsr #2
    //     0xcee700: tst             x16, HEAP, lsr #32
    //     0xcee704: b.eq            #0xcee70c
    //     0xcee708: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee70c: r0 = markNeedsLayout()
    //     0xcee70c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee710: r0 = Null
    //     0xcee710: mov             x0, NULL
    // 0xcee714: LeaveFrame
    //     0xcee714: mov             SP, fp
    //     0xcee718: ldp             fp, lr, [SP], #0x10
    // 0xcee71c: ret
    //     0xcee71c: ret             
    // 0xcee720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee720: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee724: b               #0xcee6e0
  }
  set _ verticalDirection=(/* No info */) {
    // ** addr: 0xcee728, size: 0x60
    // 0xcee728: EnterFrame
    //     0xcee728: stp             fp, lr, [SP, #-0x10]!
    //     0xcee72c: mov             fp, SP
    // 0xcee730: mov             x0, x2
    // 0xcee734: CheckStackOverflow
    //     0xcee734: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee738: cmp             SP, x16
    //     0xcee73c: b.ls            #0xcee780
    // 0xcee740: LoadField: r2 = r1->field_77
    //     0xcee740: ldur            w2, [x1, #0x77]
    // 0xcee744: DecompressPointer r2
    //     0xcee744: add             x2, x2, HEAP, lsl #32
    // 0xcee748: cmp             w2, w0
    // 0xcee74c: b.eq            #0xcee770
    // 0xcee750: StoreField: r1->field_77 = r0
    //     0xcee750: stur            w0, [x1, #0x77]
    //     0xcee754: ldurb           w16, [x1, #-1]
    //     0xcee758: ldurb           w17, [x0, #-1]
    //     0xcee75c: and             x16, x17, x16, lsr #2
    //     0xcee760: tst             x16, HEAP, lsr #32
    //     0xcee764: b.eq            #0xcee76c
    //     0xcee768: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee76c: r0 = markNeedsLayout()
    //     0xcee76c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee770: r0 = Null
    //     0xcee770: mov             x0, NULL
    // 0xcee774: LeaveFrame
    //     0xcee774: mov             SP, fp
    //     0xcee778: ldp             fp, lr, [SP], #0x10
    // 0xcee77c: ret
    //     0xcee77c: ret             
    // 0xcee780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee780: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee784: b               #0xcee740
  }
  set _ crossAxisAlignment=(/* No info */) {
    // ** addr: 0xcee878, size: 0x60
    // 0xcee878: EnterFrame
    //     0xcee878: stp             fp, lr, [SP, #-0x10]!
    //     0xcee87c: mov             fp, SP
    // 0xcee880: mov             x0, x2
    // 0xcee884: CheckStackOverflow
    //     0xcee884: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee888: cmp             SP, x16
    //     0xcee88c: b.ls            #0xcee8d0
    // 0xcee890: LoadField: r2 = r1->field_6f
    //     0xcee890: ldur            w2, [x1, #0x6f]
    // 0xcee894: DecompressPointer r2
    //     0xcee894: add             x2, x2, HEAP, lsl #32
    // 0xcee898: cmp             w2, w0
    // 0xcee89c: b.eq            #0xcee8c0
    // 0xcee8a0: StoreField: r1->field_6f = r0
    //     0xcee8a0: stur            w0, [x1, #0x6f]
    //     0xcee8a4: ldurb           w16, [x1, #-1]
    //     0xcee8a8: ldurb           w17, [x0, #-1]
    //     0xcee8ac: and             x16, x17, x16, lsr #2
    //     0xcee8b0: tst             x16, HEAP, lsr #32
    //     0xcee8b4: b.eq            #0xcee8bc
    //     0xcee8b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee8bc: r0 = markNeedsLayout()
    //     0xcee8bc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee8c0: r0 = Null
    //     0xcee8c0: mov             x0, NULL
    // 0xcee8c4: LeaveFrame
    //     0xcee8c4: mov             SP, fp
    //     0xcee8c8: ldp             fp, lr, [SP], #0x10
    // 0xcee8cc: ret
    //     0xcee8cc: ret             
    // 0xcee8d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee8d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee8d4: b               #0xcee890
  }
  set _ mainAxisSize=(/* No info */) {
    // ** addr: 0xcee8d8, size: 0x60
    // 0xcee8d8: EnterFrame
    //     0xcee8d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcee8dc: mov             fp, SP
    // 0xcee8e0: mov             x0, x2
    // 0xcee8e4: CheckStackOverflow
    //     0xcee8e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee8e8: cmp             SP, x16
    //     0xcee8ec: b.ls            #0xcee930
    // 0xcee8f0: LoadField: r2 = r1->field_6b
    //     0xcee8f0: ldur            w2, [x1, #0x6b]
    // 0xcee8f4: DecompressPointer r2
    //     0xcee8f4: add             x2, x2, HEAP, lsl #32
    // 0xcee8f8: cmp             w2, w0
    // 0xcee8fc: b.eq            #0xcee920
    // 0xcee900: StoreField: r1->field_6b = r0
    //     0xcee900: stur            w0, [x1, #0x6b]
    //     0xcee904: ldurb           w16, [x1, #-1]
    //     0xcee908: ldurb           w17, [x0, #-1]
    //     0xcee90c: and             x16, x17, x16, lsr #2
    //     0xcee910: tst             x16, HEAP, lsr #32
    //     0xcee914: b.eq            #0xcee91c
    //     0xcee918: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee91c: r0 = markNeedsLayout()
    //     0xcee91c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee920: r0 = Null
    //     0xcee920: mov             x0, NULL
    // 0xcee924: LeaveFrame
    //     0xcee924: mov             SP, fp
    //     0xcee928: ldp             fp, lr, [SP], #0x10
    // 0xcee92c: ret
    //     0xcee92c: ret             
    // 0xcee930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee934: b               #0xcee8f0
  }
  set _ mainAxisAlignment=(/* No info */) {
    // ** addr: 0xcee938, size: 0x60
    // 0xcee938: EnterFrame
    //     0xcee938: stp             fp, lr, [SP, #-0x10]!
    //     0xcee93c: mov             fp, SP
    // 0xcee940: mov             x0, x2
    // 0xcee944: CheckStackOverflow
    //     0xcee944: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee948: cmp             SP, x16
    //     0xcee94c: b.ls            #0xcee990
    // 0xcee950: LoadField: r2 = r1->field_67
    //     0xcee950: ldur            w2, [x1, #0x67]
    // 0xcee954: DecompressPointer r2
    //     0xcee954: add             x2, x2, HEAP, lsl #32
    // 0xcee958: cmp             w2, w0
    // 0xcee95c: b.eq            #0xcee980
    // 0xcee960: StoreField: r1->field_67 = r0
    //     0xcee960: stur            w0, [x1, #0x67]
    //     0xcee964: ldurb           w16, [x1, #-1]
    //     0xcee968: ldurb           w17, [x0, #-1]
    //     0xcee96c: and             x16, x17, x16, lsr #2
    //     0xcee970: tst             x16, HEAP, lsr #32
    //     0xcee974: b.eq            #0xcee97c
    //     0xcee978: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee97c: r0 = markNeedsLayout()
    //     0xcee97c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee980: r0 = Null
    //     0xcee980: mov             x0, NULL
    // 0xcee984: LeaveFrame
    //     0xcee984: mov             SP, fp
    //     0xcee988: ldp             fp, lr, [SP], #0x10
    // 0xcee98c: ret
    //     0xcee98c: ret             
    // 0xcee990: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee990: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee994: b               #0xcee950
  }
  set _ direction=(/* No info */) {
    // ** addr: 0xcee998, size: 0x60
    // 0xcee998: EnterFrame
    //     0xcee998: stp             fp, lr, [SP, #-0x10]!
    //     0xcee99c: mov             fp, SP
    // 0xcee9a0: mov             x0, x2
    // 0xcee9a4: CheckStackOverflow
    //     0xcee9a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcee9a8: cmp             SP, x16
    //     0xcee9ac: b.ls            #0xcee9f0
    // 0xcee9b0: LoadField: r2 = r1->field_63
    //     0xcee9b0: ldur            w2, [x1, #0x63]
    // 0xcee9b4: DecompressPointer r2
    //     0xcee9b4: add             x2, x2, HEAP, lsl #32
    // 0xcee9b8: cmp             w2, w0
    // 0xcee9bc: b.eq            #0xcee9e0
    // 0xcee9c0: StoreField: r1->field_63 = r0
    //     0xcee9c0: stur            w0, [x1, #0x63]
    //     0xcee9c4: ldurb           w16, [x1, #-1]
    //     0xcee9c8: ldurb           w17, [x0, #-1]
    //     0xcee9cc: and             x16, x17, x16, lsr #2
    //     0xcee9d0: tst             x16, HEAP, lsr #32
    //     0xcee9d4: b.eq            #0xcee9dc
    //     0xcee9d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcee9dc: r0 = markNeedsLayout()
    //     0xcee9dc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcee9e0: r0 = Null
    //     0xcee9e0: mov             x0, NULL
    // 0xcee9e4: LeaveFrame
    //     0xcee9e4: mov             SP, fp
    //     0xcee9e8: ldp             fp, lr, [SP], #0x10
    // 0xcee9ec: ret
    //     0xcee9ec: ret             
    // 0xcee9f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcee9f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcee9f4: b               #0xcee9b0
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10eff88, size: 0x24
    // 0x10eff88: EnterFrame
    //     0x10eff88: stp             fp, lr, [SP, #-0x10]!
    //     0x10eff8c: mov             fp, SP
    // 0x10eff90: ldr             x2, [fp, #0x10]
    // 0x10eff94: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10eff94: add             x1, PP, #0xa4, lsl #12  ; [pp+0xa4208] AnonymousClosure: (0xb23eb8), in [package:flutter/src/rendering/flex.dart] RenderFlex::computeMinIntrinsicHeight (0xb23e58)
    //     0x10eff98: ldr             x1, [x1, #0x208]
    // 0x10eff9c: r0 = AllocateClosure()
    //     0x10eff9c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10effa0: LeaveFrame
    //     0x10effa0: mov             SP, fp
    //     0x10effa4: ldp             fp, lr, [SP], #0x10
    // 0x10effa8: ret
    //     0x10effa8: ret             
  }
  _ RenderFlex(/* No info */) {
    // ** addr: 0x11c9c4c, size: 0x33c
    // 0x11c9c4c: EnterFrame
    //     0x11c9c4c: stp             fp, lr, [SP, #-0x10]!
    //     0x11c9c50: mov             fp, SP
    // 0x11c9c54: AllocStack(0x48)
    //     0x11c9c54: sub             SP, SP, #0x48
    // 0x11c9c58: SetupParameters(RenderFlex this /* r1 => r5, fp-0x28 */, dynamic _ /* r2 => r3, fp-0x30 */, dynamic _ /* r3 => r2, fp-0x38 */, dynamic _ /* r5 => r0, fp-0x40 */)
    //     0x11c9c58: mov             x0, x5
    //     0x11c9c5c: stur            x5, [fp, #-0x40]
    //     0x11c9c60: mov             x5, x1
    //     0x11c9c64: stur            x2, [fp, #-0x30]
    //     0x11c9c68: mov             x16, x3
    //     0x11c9c6c: mov             x3, x2
    //     0x11c9c70: mov             x2, x16
    //     0x11c9c74: stur            x1, [fp, #-0x28]
    //     0x11c9c78: stur            x2, [fp, #-0x38]
    // 0x11c9c7c: LoadField: r1 = r4->field_13
    //     0x11c9c7c: ldur            w1, [x4, #0x13]
    // 0x11c9c80: LoadField: r6 = r4->field_1f
    //     0x11c9c80: ldur            w6, [x4, #0x1f]
    // 0x11c9c84: DecompressPointer r6
    //     0x11c9c84: add             x6, x6, HEAP, lsl #32
    // 0x11c9c88: r16 = "mainAxisAlignment"
    //     0x11c9c88: add             x16, PP, #0x84, lsl #12  ; [pp+0x84ff0] "mainAxisAlignment"
    //     0x11c9c8c: ldr             x16, [x16, #0xff0]
    // 0x11c9c90: cmp             w6, w16
    // 0x11c9c94: b.ne            #0x11c9cb8
    // 0x11c9c98: LoadField: r6 = r4->field_23
    //     0x11c9c98: ldur            w6, [x4, #0x23]
    // 0x11c9c9c: DecompressPointer r6
    //     0x11c9c9c: add             x6, x6, HEAP, lsl #32
    // 0x11c9ca0: sub             w7, w1, w6
    // 0x11c9ca4: add             x6, fp, w7, sxtw #2
    // 0x11c9ca8: ldr             x6, [x6, #8]
    // 0x11c9cac: mov             x7, x6
    // 0x11c9cb0: r6 = 1
    //     0x11c9cb0: mov             x6, #1
    // 0x11c9cb4: b               #0x11c9cc4
    // 0x11c9cb8: r7 = Instance_MainAxisAlignment
    //     0x11c9cb8: add             x7, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0x11c9cbc: ldr             x7, [x7, #0x820]
    // 0x11c9cc0: r6 = 0
    //     0x11c9cc0: mov             x6, #0
    // 0x11c9cc4: stur            x7, [fp, #-0x20]
    // 0x11c9cc8: lsl             x8, x6, #1
    // 0x11c9ccc: lsl             w9, w8, #1
    // 0x11c9cd0: add             w10, w9, #8
    // 0x11c9cd4: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0x11c9cd4: add             x16, x4, w10, sxtw #1
    //     0x11c9cd8: ldur            w11, [x16, #0xf]
    // 0x11c9cdc: DecompressPointer r11
    //     0x11c9cdc: add             x11, x11, HEAP, lsl #32
    // 0x11c9ce0: r16 = "spacing"
    //     0x11c9ce0: add             x16, PP, #0x80, lsl #12  ; [pp+0x80450] "spacing"
    //     0x11c9ce4: ldr             x16, [x16, #0x450]
    // 0x11c9ce8: cmp             w11, w16
    // 0x11c9cec: b.ne            #0x11c9d20
    // 0x11c9cf0: add             w6, w9, #0xa
    // 0x11c9cf4: ArrayLoad: r9 = r4[r6]  ; Unknown_4
    //     0x11c9cf4: add             x16, x4, w6, sxtw #1
    //     0x11c9cf8: ldur            w9, [x16, #0xf]
    // 0x11c9cfc: DecompressPointer r9
    //     0x11c9cfc: add             x9, x9, HEAP, lsl #32
    // 0x11c9d00: sub             w6, w1, w9
    // 0x11c9d04: add             x9, fp, w6, sxtw #2
    // 0x11c9d08: ldr             x9, [x9, #8]
    // 0x11c9d0c: add             w6, w8, #2
    // 0x11c9d10: LoadField: d0 = r9->field_7
    //     0x11c9d10: ldur            d0, [x9, #7]
    // 0x11c9d14: r8 = LoadInt32Instr(r6)
    //     0x11c9d14: sbfx            x8, x6, #1, #0x1f
    // 0x11c9d18: mov             x6, x8
    // 0x11c9d1c: b               #0x11c9d24
    // 0x11c9d20: d0 = 0.000000
    //     0x11c9d20: eor             v0.16b, v0.16b, v0.16b
    // 0x11c9d24: stur            d0, [fp, #-0x48]
    // 0x11c9d28: lsl             x8, x6, #1
    // 0x11c9d2c: lsl             w9, w8, #1
    // 0x11c9d30: add             w10, w9, #8
    // 0x11c9d34: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0x11c9d34: add             x16, x4, w10, sxtw #1
    //     0x11c9d38: ldur            w11, [x16, #0xf]
    // 0x11c9d3c: DecompressPointer r11
    //     0x11c9d3c: add             x11, x11, HEAP, lsl #32
    // 0x11c9d40: r16 = "textBaseline"
    //     0x11c9d40: ldr             x16, [PP, #0x4af0]  ; [pp+0x4af0] "textBaseline"
    // 0x11c9d44: cmp             w11, w16
    // 0x11c9d48: b.ne            #0x11c9d7c
    // 0x11c9d4c: add             w6, w9, #0xa
    // 0x11c9d50: ArrayLoad: r9 = r4[r6]  ; Unknown_4
    //     0x11c9d50: add             x16, x4, w6, sxtw #1
    //     0x11c9d54: ldur            w9, [x16, #0xf]
    // 0x11c9d58: DecompressPointer r9
    //     0x11c9d58: add             x9, x9, HEAP, lsl #32
    // 0x11c9d5c: sub             w6, w1, w9
    // 0x11c9d60: add             x9, fp, w6, sxtw #2
    // 0x11c9d64: ldr             x9, [x9, #8]
    // 0x11c9d68: add             w6, w8, #2
    // 0x11c9d6c: r8 = LoadInt32Instr(r6)
    //     0x11c9d6c: sbfx            x8, x6, #1, #0x1f
    // 0x11c9d70: mov             x6, x8
    // 0x11c9d74: mov             x8, x9
    // 0x11c9d78: b               #0x11c9d80
    // 0x11c9d7c: r8 = Null
    //     0x11c9d7c: mov             x8, NULL
    // 0x11c9d80: stur            x8, [fp, #-0x18]
    // 0x11c9d84: lsl             x9, x6, #1
    // 0x11c9d88: lsl             w10, w9, #1
    // 0x11c9d8c: add             w11, w10, #8
    // 0x11c9d90: ArrayLoad: r12 = r4[r11]  ; Unknown_4
    //     0x11c9d90: add             x16, x4, w11, sxtw #1
    //     0x11c9d94: ldur            w12, [x16, #0xf]
    // 0x11c9d98: DecompressPointer r12
    //     0x11c9d98: add             x12, x12, HEAP, lsl #32
    // 0x11c9d9c: r16 = "textDirection"
    //     0x11c9d9c: add             x16, PP, #0x15, lsl #12  ; [pp+0x15210] "textDirection"
    //     0x11c9da0: ldr             x16, [x16, #0x210]
    // 0x11c9da4: cmp             w12, w16
    // 0x11c9da8: b.ne            #0x11c9ddc
    // 0x11c9dac: add             w6, w10, #0xa
    // 0x11c9db0: ArrayLoad: r10 = r4[r6]  ; Unknown_4
    //     0x11c9db0: add             x16, x4, w6, sxtw #1
    //     0x11c9db4: ldur            w10, [x16, #0xf]
    // 0x11c9db8: DecompressPointer r10
    //     0x11c9db8: add             x10, x10, HEAP, lsl #32
    // 0x11c9dbc: sub             w6, w1, w10
    // 0x11c9dc0: add             x10, fp, w6, sxtw #2
    // 0x11c9dc4: ldr             x10, [x10, #8]
    // 0x11c9dc8: add             w6, w9, #2
    // 0x11c9dcc: r9 = LoadInt32Instr(r6)
    //     0x11c9dcc: sbfx            x9, x6, #1, #0x1f
    // 0x11c9dd0: mov             x6, x9
    // 0x11c9dd4: mov             x9, x10
    // 0x11c9dd8: b               #0x11c9de0
    // 0x11c9ddc: r9 = Null
    //     0x11c9ddc: mov             x9, NULL
    // 0x11c9de0: stur            x9, [fp, #-0x10]
    // 0x11c9de4: lsl             x10, x6, #1
    // 0x11c9de8: lsl             w6, w10, #1
    // 0x11c9dec: add             w10, w6, #8
    // 0x11c9df0: ArrayLoad: r11 = r4[r10]  ; Unknown_4
    //     0x11c9df0: add             x16, x4, w10, sxtw #1
    //     0x11c9df4: ldur            w11, [x16, #0xf]
    // 0x11c9df8: DecompressPointer r11
    //     0x11c9df8: add             x11, x11, HEAP, lsl #32
    // 0x11c9dfc: r16 = "verticalDirection"
    //     0x11c9dfc: add             x16, PP, #0x84, lsl #12  ; [pp+0x84ff8] "verticalDirection"
    //     0x11c9e00: ldr             x16, [x16, #0xff8]
    // 0x11c9e04: cmp             w11, w16
    // 0x11c9e08: b.ne            #0x11c9e30
    // 0x11c9e0c: add             w10, w6, #0xa
    // 0x11c9e10: ArrayLoad: r6 = r4[r10]  ; Unknown_4
    //     0x11c9e10: add             x16, x4, w10, sxtw #1
    //     0x11c9e14: ldur            w6, [x16, #0xf]
    // 0x11c9e18: DecompressPointer r6
    //     0x11c9e18: add             x6, x6, HEAP, lsl #32
    // 0x11c9e1c: sub             w4, w1, w6
    // 0x11c9e20: add             x1, fp, w4, sxtw #2
    // 0x11c9e24: ldr             x1, [x1, #8]
    // 0x11c9e28: mov             x4, x1
    // 0x11c9e2c: b               #0x11c9e38
    // 0x11c9e30: r4 = Instance_VerticalDirection
    //     0x11c9e30: add             x4, PP, #0x15, lsl #12  ; [pp+0x15838] Obj!VerticalDirection@12c4a21
    //     0x11c9e34: ldr             x4, [x4, #0x838]
    // 0x11c9e38: stur            x4, [fp, #-8]
    // 0x11c9e3c: CheckStackOverflow
    //     0x11c9e3c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c9e40: cmp             SP, x16
    //     0x11c9e44: b.ls            #0x11c9f80
    // 0x11c9e48: StoreField: r5->field_7f = rZR
    //     0x11c9e48: stur            xzr, [x5, #0x7f]
    // 0x11c9e4c: r1 = <ClipRectLayer>
    //     0x11c9e4c: add             x1, PP, #0x84, lsl #12  ; [pp+0x84fc8] TypeArguments: <ClipRectLayer>
    //     0x11c9e50: ldr             x1, [x1, #0xfc8]
    // 0x11c9e54: r0 = LayerHandle()
    //     0x11c9e54: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11c9e58: ldur            x1, [fp, #-0x28]
    // 0x11c9e5c: StoreField: r1->field_93 = r0
    //     0x11c9e5c: stur            w0, [x1, #0x93]
    //     0x11c9e60: ldurb           w16, [x1, #-1]
    //     0x11c9e64: ldurb           w17, [x0, #-1]
    //     0x11c9e68: and             x16, x17, x16, lsr #2
    //     0x11c9e6c: tst             x16, HEAP, lsr #32
    //     0x11c9e70: b.eq            #0x11c9e78
    //     0x11c9e74: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c9e78: ldur            x0, [fp, #-0x38]
    // 0x11c9e7c: StoreField: r1->field_63 = r0
    //     0x11c9e7c: stur            w0, [x1, #0x63]
    //     0x11c9e80: ldurb           w16, [x1, #-1]
    //     0x11c9e84: ldurb           w17, [x0, #-1]
    //     0x11c9e88: and             x16, x17, x16, lsr #2
    //     0x11c9e8c: tst             x16, HEAP, lsr #32
    //     0x11c9e90: b.eq            #0x11c9e98
    //     0x11c9e94: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c9e98: ldur            x0, [fp, #-0x20]
    // 0x11c9e9c: StoreField: r1->field_67 = r0
    //     0x11c9e9c: stur            w0, [x1, #0x67]
    //     0x11c9ea0: ldurb           w16, [x1, #-1]
    //     0x11c9ea4: ldurb           w17, [x0, #-1]
    //     0x11c9ea8: and             x16, x17, x16, lsr #2
    //     0x11c9eac: tst             x16, HEAP, lsr #32
    //     0x11c9eb0: b.eq            #0x11c9eb8
    //     0x11c9eb4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c9eb8: ldur            x0, [fp, #-0x40]
    // 0x11c9ebc: StoreField: r1->field_6b = r0
    //     0x11c9ebc: stur            w0, [x1, #0x6b]
    //     0x11c9ec0: ldurb           w16, [x1, #-1]
    //     0x11c9ec4: ldurb           w17, [x0, #-1]
    //     0x11c9ec8: and             x16, x17, x16, lsr #2
    //     0x11c9ecc: tst             x16, HEAP, lsr #32
    //     0x11c9ed0: b.eq            #0x11c9ed8
    //     0x11c9ed4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c9ed8: ldur            x0, [fp, #-0x30]
    // 0x11c9edc: StoreField: r1->field_6f = r0
    //     0x11c9edc: stur            w0, [x1, #0x6f]
    //     0x11c9ee0: ldurb           w16, [x1, #-1]
    //     0x11c9ee4: ldurb           w17, [x0, #-1]
    //     0x11c9ee8: and             x16, x17, x16, lsr #2
    //     0x11c9eec: tst             x16, HEAP, lsr #32
    //     0x11c9ef0: b.eq            #0x11c9ef8
    //     0x11c9ef4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c9ef8: ldur            x0, [fp, #-0x10]
    // 0x11c9efc: StoreField: r1->field_73 = r0
    //     0x11c9efc: stur            w0, [x1, #0x73]
    //     0x11c9f00: ldurb           w16, [x1, #-1]
    //     0x11c9f04: ldurb           w17, [x0, #-1]
    //     0x11c9f08: and             x16, x17, x16, lsr #2
    //     0x11c9f0c: tst             x16, HEAP, lsr #32
    //     0x11c9f10: b.eq            #0x11c9f18
    //     0x11c9f14: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c9f18: ldur            x0, [fp, #-8]
    // 0x11c9f1c: StoreField: r1->field_77 = r0
    //     0x11c9f1c: stur            w0, [x1, #0x77]
    //     0x11c9f20: ldurb           w16, [x1, #-1]
    //     0x11c9f24: ldurb           w17, [x0, #-1]
    //     0x11c9f28: and             x16, x17, x16, lsr #2
    //     0x11c9f2c: tst             x16, HEAP, lsr #32
    //     0x11c9f30: b.eq            #0x11c9f38
    //     0x11c9f34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c9f38: ldur            x0, [fp, #-0x18]
    // 0x11c9f3c: StoreField: r1->field_7b = r0
    //     0x11c9f3c: stur            w0, [x1, #0x7b]
    //     0x11c9f40: ldurb           w16, [x1, #-1]
    //     0x11c9f44: ldurb           w17, [x0, #-1]
    //     0x11c9f48: and             x16, x17, x16, lsr #2
    //     0x11c9f4c: tst             x16, HEAP, lsr #32
    //     0x11c9f50: b.eq            #0x11c9f58
    //     0x11c9f54: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c9f58: r0 = Instance_Clip
    //     0x11c9f58: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0x11c9f5c: ldr             x0, [x0, #0x840]
    // 0x11c9f60: StoreField: r1->field_87 = r0
    //     0x11c9f60: stur            w0, [x1, #0x87]
    // 0x11c9f64: ldur            d0, [fp, #-0x48]
    // 0x11c9f68: StoreField: r1->field_8b = d0
    //     0x11c9f68: stur            d0, [x1, #0x8b]
    // 0x11c9f6c: r0 = _MixinApplication16&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin()
    //     0x11c9f6c: bl              #0x11c9f88  ; [dart:mixin_deduplication] _MixinApplication16&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin::_MixinApplication16&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin
    // 0x11c9f70: r0 = Null
    //     0x11c9f70: mov             x0, NULL
    // 0x11c9f74: LeaveFrame
    //     0x11c9f74: mov             SP, fp
    //     0x11c9f78: ldp             fp, lr, [SP], #0x10
    // 0x11c9f7c: ret
    //     0x11c9f7c: ret             
    // 0x11c9f80: r0 = StackOverflowSharedWithFPURegs()
    //     0x11c9f80: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11c9f84: b               #0x11c9e48
  }
}

// class id: 8234, size: 0x14, field offset: 0x14
enum CrossAxisAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _getChildCrossAxisOffset(/* No info */) {
    // ** addr: 0xb626f4, size: 0x16c
    // 0xb626f4: EnterFrame
    //     0xb626f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb626f8: mov             fp, SP
    // 0xb626fc: CheckStackOverflow
    //     0xb626fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb62700: cmp             SP, x16
    //     0xb62704: b.ls            #0xb62828
    // 0xb62708: r16 = Instance_CrossAxisAlignment
    //     0xb62708: add             x16, PP, #0x7b, lsl #12  ; [pp+0x7bc40] Obj!CrossAxisAlignment@12c4521
    //     0xb6270c: ldr             x16, [x16, #0xc40]
    // 0xb62710: cmp             w1, w16
    // 0xb62714: b.eq            #0xb62728
    // 0xb62718: r16 = Instance_CrossAxisAlignment
    //     0xb62718: add             x16, PP, #0x89, lsl #12  ; [pp+0x89a68] Obj!CrossAxisAlignment@12c44e1
    //     0xb6271c: ldr             x16, [x16, #0xa68]
    // 0xb62720: cmp             w1, w16
    // 0xb62724: b.ne            #0xb62730
    // 0xb62728: r0 = 0.000000
    //     0xb62728: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb6272c: b               #0xb62818
    // 0xb62730: r16 = Instance_CrossAxisAlignment
    //     0xb62730: add             x16, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xb62734: ldr             x16, [x16, #0x830]
    // 0xb62738: cmp             w1, w16
    // 0xb6273c: b.ne            #0xb62778
    // 0xb62740: tbz             w2, #4, #0xb62748
    // 0xb62744: d0 = 0.000000
    //     0xb62744: eor             v0.16b, v0.16b, v0.16b
    // 0xb62748: r0 = inline_Allocate_Double()
    //     0xb62748: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb6274c: add             x0, x0, #0x10
    //     0xb62750: cmp             x1, x0
    //     0xb62754: b.ls            #0xb62830
    //     0xb62758: str             x0, [THR, #0x60]  ; THR::top
    //     0xb6275c: sub             x0, x0, #0xf
    //     0xb62760: mov             x1, #0xe19c
    //     0xb62764: movk            x1, #3, lsl #16
    //     0xb62768: stur            x1, [x0, #-1]
    // 0xb6276c: dmb             ishst
    // 0xb62770: StoreField: r0->field_7 = d0
    //     0xb62770: stur            d0, [x0, #7]
    // 0xb62774: b               #0xb62818
    // 0xb62778: r16 = Instance_CrossAxisAlignment
    //     0xb62778: add             x16, PP, #0x15, lsl #12  ; [pp+0x15888] Obj!CrossAxisAlignment@12c44a1
    //     0xb6277c: ldr             x16, [x16, #0x888]
    // 0xb62780: cmp             w1, w16
    // 0xb62784: b.ne            #0xb627c0
    // 0xb62788: d1 = 2.000000
    //     0xb62788: fmov            d1, #2.00000000
    // 0xb6278c: fdiv            d2, d0, d1
    // 0xb62790: r0 = inline_Allocate_Double()
    //     0xb62790: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb62794: add             x0, x0, #0x10
    //     0xb62798: cmp             x1, x0
    //     0xb6279c: b.ls            #0xb62840
    //     0xb627a0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb627a4: sub             x0, x0, #0xf
    //     0xb627a8: mov             x1, #0xe19c
    //     0xb627ac: movk            x1, #3, lsl #16
    //     0xb627b0: stur            x1, [x0, #-1]
    // 0xb627b4: dmb             ishst
    // 0xb627b8: StoreField: r0->field_7 = d2
    //     0xb627b8: stur            d2, [x0, #7]
    // 0xb627bc: b               #0xb62818
    // 0xb627c0: r16 = Instance_CrossAxisAlignment
    //     0xb627c0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fbd8] Obj!CrossAxisAlignment@12c4501
    //     0xb627c4: ldr             x16, [x16, #0xbd8]
    // 0xb627c8: cmp             w1, w16
    // 0xb627cc: b.ne            #0xb62814
    // 0xb627d0: eor             x0, x2, #0x10
    // 0xb627d4: mov             x2, x0
    // 0xb627d8: r1 = Instance_CrossAxisAlignment
    //     0xb627d8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15830] Obj!CrossAxisAlignment@12c44c1
    //     0xb627dc: ldr             x1, [x1, #0x830]
    // 0xb627e0: r0 = _getChildCrossAxisOffset()
    //     0xb627e0: bl              #0xb626f4  ; [package:flutter/src/rendering/flex.dart] CrossAxisAlignment::_getChildCrossAxisOffset
    // 0xb627e4: r0 = inline_Allocate_Double()
    //     0xb627e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb627e8: add             x0, x0, #0x10
    //     0xb627ec: cmp             x1, x0
    //     0xb627f0: b.ls            #0xb62850
    //     0xb627f4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb627f8: sub             x0, x0, #0xf
    //     0xb627fc: mov             x1, #0xe19c
    //     0xb62800: movk            x1, #3, lsl #16
    //     0xb62804: stur            x1, [x0, #-1]
    // 0xb62808: dmb             ishst
    // 0xb6280c: StoreField: r0->field_7 = d0
    //     0xb6280c: stur            d0, [x0, #7]
    // 0xb62810: b               #0xb62818
    // 0xb62814: r0 = Null
    //     0xb62814: mov             x0, NULL
    // 0xb62818: LoadField: d0 = r0->field_7
    //     0xb62818: ldur            d0, [x0, #7]
    // 0xb6281c: LeaveFrame
    //     0xb6281c: mov             SP, fp
    //     0xb62820: ldp             fp, lr, [SP], #0x10
    // 0xb62824: ret
    //     0xb62824: ret             
    // 0xb62828: r0 = StackOverflowSharedWithFPURegs()
    //     0xb62828: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb6282c: b               #0xb62708
    // 0xb62830: SaveReg d0
    //     0xb62830: str             q0, [SP, #-0x10]!
    // 0xb62834: r0 = AllocateDouble()
    //     0xb62834: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb62838: RestoreReg d0
    //     0xb62838: ldr             q0, [SP], #0x10
    // 0xb6283c: b               #0xb62770
    // 0xb62840: SaveReg d2
    //     0xb62840: str             q2, [SP, #-0x10]!
    // 0xb62844: r0 = AllocateDouble()
    //     0xb62844: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb62848: RestoreReg d2
    //     0xb62848: ldr             q2, [SP], #0x10
    // 0xb6284c: b               #0xb627b8
    // 0xb62850: SaveReg d0
    //     0xb62850: str             q0, [SP, #-0x10]!
    // 0xb62854: r0 = AllocateDouble()
    //     0xb62854: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb62858: RestoreReg d0
    //     0xb62858: ldr             q0, [SP], #0x10
    // 0xb6285c: b               #0xb6280c
  }
}

// class id: 8235, size: 0x14, field offset: 0x14
enum MainAxisAlignment extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _distributeSpace(/* No info */) {
    // ** addr: 0xb61b98, size: 0x45c
    // 0xb61b98: EnterFrame
    //     0xb61b98: stp             fp, lr, [SP, #-0x10]!
    //     0xb61b9c: mov             fp, SP
    // 0xb61ba0: CheckStackOverflow
    //     0xb61ba0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb61ba4: cmp             SP, x16
    //     0xb61ba8: b.ls            #0xb61f04
    // 0xb61bac: r16 = Instance_MainAxisAlignment
    //     0xb61bac: add             x16, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xb61bb0: ldr             x16, [x16, #0x820]
    // 0xb61bb4: cmp             w1, w16
    // 0xb61bb8: b.ne            #0xb61c5c
    // 0xb61bbc: tbnz            w3, #4, #0xb61c20
    // 0xb61bc0: r2 = inline_Allocate_Double()
    //     0xb61bc0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb61bc4: add             x2, x2, #0x10
    //     0xb61bc8: cmp             x0, x2
    //     0xb61bcc: b.ls            #0xb61f0c
    //     0xb61bd0: str             x2, [THR, #0x60]  ; THR::top
    //     0xb61bd4: sub             x2, x2, #0xf
    //     0xb61bd8: mov             x0, #0xe19c
    //     0xb61bdc: movk            x0, #3, lsl #16
    //     0xb61be0: stur            x0, [x2, #-1]
    // 0xb61be4: dmb             ishst
    // 0xb61be8: StoreField: r2->field_7 = d0
    //     0xb61be8: stur            d0, [x2, #7]
    // 0xb61bec: r3 = inline_Allocate_Double()
    //     0xb61bec: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb61bf0: add             x3, x3, #0x10
    //     0xb61bf4: cmp             x0, x3
    //     0xb61bf8: b.ls            #0xb61f20
    //     0xb61bfc: str             x3, [THR, #0x60]  ; THR::top
    //     0xb61c00: sub             x3, x3, #0xf
    //     0xb61c04: mov             x0, #0xe19c
    //     0xb61c08: movk            x0, #3, lsl #16
    //     0xb61c0c: stur            x0, [x3, #-1]
    // 0xb61c10: dmb             ishst
    // 0xb61c14: StoreField: r3->field_7 = d1
    //     0xb61c14: stur            d1, [x3, #7]
    // 0xb61c18: r0 = AllocateRecord2()
    //     0xb61c18: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61c1c: b               #0xb61c54
    // 0xb61c20: r3 = inline_Allocate_Double()
    //     0xb61c20: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb61c24: add             x3, x3, #0x10
    //     0xb61c28: cmp             x0, x3
    //     0xb61c2c: b.ls            #0xb61f3c
    //     0xb61c30: str             x3, [THR, #0x60]  ; THR::top
    //     0xb61c34: sub             x3, x3, #0xf
    //     0xb61c38: mov             x0, #0xe19c
    //     0xb61c3c: movk            x0, #3, lsl #16
    //     0xb61c40: stur            x0, [x3, #-1]
    // 0xb61c44: dmb             ishst
    // 0xb61c48: StoreField: r3->field_7 = d1
    //     0xb61c48: stur            d1, [x3, #7]
    // 0xb61c4c: r2 = 0.000000
    //     0xb61c4c: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb61c50: r0 = AllocateRecord2()
    //     0xb61c50: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61c54: mov             x2, x0
    // 0xb61c58: b               #0xb61ee8
    // 0xb61c5c: r16 = Instance_MainAxisAlignment
    //     0xb61c5c: add             x16, PP, #0x18, lsl #12  ; [pp+0x182b8] Obj!MainAxisAlignment@12c45e1
    //     0xb61c60: ldr             x16, [x16, #0x2b8]
    // 0xb61c64: cmp             w1, w16
    // 0xb61c68: b.ne            #0xb61c94
    // 0xb61c6c: eor             x0, x3, #0x10
    // 0xb61c70: mov             x3, x0
    // 0xb61c74: r1 = Instance_MainAxisAlignment
    //     0xb61c74: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xb61c78: ldr             x1, [x1, #0x820]
    // 0xb61c7c: r0 = _distributeSpace()
    //     0xb61c7c: bl              #0xb61b98  ; [package:flutter/src/rendering/flex.dart] MainAxisAlignment::_distributeSpace
    // 0xb61c80: mov             x2, x0
    // 0xb61c84: mov             x3, x1
    // 0xb61c88: r0 = AllocateRecord2()
    //     0xb61c88: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61c8c: mov             x2, x0
    // 0xb61c90: b               #0xb61ee8
    // 0xb61c94: r16 = Instance_MainAxisAlignment
    //     0xb61c94: add             x16, PP, #0x17, lsl #12  ; [pp+0x177b0] Obj!MainAxisAlignment@12c45c1
    //     0xb61c98: ldr             x16, [x16, #0x7b0]
    // 0xb61c9c: cmp             w1, w16
    // 0xb61ca0: r16 = true
    //     0xb61ca0: add             x16, NULL, #0x20  ; true
    // 0xb61ca4: r17 = false
    //     0xb61ca4: add             x17, NULL, #0x30  ; false
    // 0xb61ca8: csel            x0, x16, x17, eq
    // 0xb61cac: tbnz            w0, #4, #0xb61cd8
    // 0xb61cb0: cmp             x2, #2
    // 0xb61cb4: b.ge            #0xb61cd8
    // 0xb61cb8: r1 = Instance_MainAxisAlignment
    //     0xb61cb8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xb61cbc: ldr             x1, [x1, #0x820]
    // 0xb61cc0: r0 = _distributeSpace()
    //     0xb61cc0: bl              #0xb61b98  ; [package:flutter/src/rendering/flex.dart] MainAxisAlignment::_distributeSpace
    // 0xb61cc4: mov             x2, x0
    // 0xb61cc8: mov             x3, x1
    // 0xb61ccc: r0 = AllocateRecord2()
    //     0xb61ccc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61cd0: mov             x2, x0
    // 0xb61cd4: b               #0xb61ee8
    // 0xb61cd8: r16 = Instance_MainAxisAlignment
    //     0xb61cd8: add             x16, PP, #0x7a, lsl #12  ; [pp+0x7aaa0] Obj!MainAxisAlignment@12c45a1
    //     0xb61cdc: ldr             x16, [x16, #0xaa0]
    // 0xb61ce0: cmp             w1, w16
    // 0xb61ce4: r16 = true
    //     0xb61ce4: add             x16, NULL, #0x20  ; true
    // 0xb61ce8: r17 = false
    //     0xb61ce8: add             x17, NULL, #0x30  ; false
    // 0xb61cec: csel            x4, x16, x17, eq
    // 0xb61cf0: tbnz            w4, #4, #0xb61d18
    // 0xb61cf4: cbnz            x2, #0xb61d18
    // 0xb61cf8: r1 = Instance_MainAxisAlignment
    //     0xb61cf8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15820] Obj!MainAxisAlignment@12c4541
    //     0xb61cfc: ldr             x1, [x1, #0x820]
    // 0xb61d00: r0 = _distributeSpace()
    //     0xb61d00: bl              #0xb61b98  ; [package:flutter/src/rendering/flex.dart] MainAxisAlignment::_distributeSpace
    // 0xb61d04: mov             x2, x0
    // 0xb61d08: mov             x3, x1
    // 0xb61d0c: r0 = AllocateRecord2()
    //     0xb61d0c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61d10: mov             x2, x0
    // 0xb61d14: b               #0xb61ee8
    // 0xb61d18: r16 = Instance_MainAxisAlignment
    //     0xb61d18: add             x16, PP, #0x18, lsl #12  ; [pp+0x180f0] Obj!MainAxisAlignment@12c4581
    //     0xb61d1c: ldr             x16, [x16, #0xf0]
    // 0xb61d20: cmp             w1, w16
    // 0xb61d24: b.ne            #0xb61d94
    // 0xb61d28: d2 = 2.000000
    //     0xb61d28: fmov            d2, #2.00000000
    // 0xb61d2c: fdiv            d3, d0, d2
    // 0xb61d30: r3 = inline_Allocate_Double()
    //     0xb61d30: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb61d34: add             x3, x3, #0x10
    //     0xb61d38: cmp             x0, x3
    //     0xb61d3c: b.ls            #0xb61f50
    //     0xb61d40: str             x3, [THR, #0x60]  ; THR::top
    //     0xb61d44: sub             x3, x3, #0xf
    //     0xb61d48: mov             x0, #0xe19c
    //     0xb61d4c: movk            x0, #3, lsl #16
    //     0xb61d50: stur            x0, [x3, #-1]
    // 0xb61d54: dmb             ishst
    // 0xb61d58: StoreField: r3->field_7 = d1
    //     0xb61d58: stur            d1, [x3, #7]
    // 0xb61d5c: r2 = inline_Allocate_Double()
    //     0xb61d5c: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb61d60: add             x2, x2, #0x10
    //     0xb61d64: cmp             x0, x2
    //     0xb61d68: b.ls            #0xb61f64
    //     0xb61d6c: str             x2, [THR, #0x60]  ; THR::top
    //     0xb61d70: sub             x2, x2, #0xf
    //     0xb61d74: mov             x0, #0xe19c
    //     0xb61d78: movk            x0, #3, lsl #16
    //     0xb61d7c: stur            x0, [x2, #-1]
    // 0xb61d80: dmb             ishst
    // 0xb61d84: StoreField: r2->field_7 = d3
    //     0xb61d84: stur            d3, [x2, #7]
    // 0xb61d88: r0 = AllocateRecord2()
    //     0xb61d88: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61d8c: mov             x2, x0
    // 0xb61d90: b               #0xb61ee8
    // 0xb61d94: d2 = 2.000000
    //     0xb61d94: fmov            d2, #2.00000000
    // 0xb61d98: tbnz            w0, #4, #0xb61de8
    // 0xb61d9c: sub             x0, x2, #1
    // 0xb61da0: scvtf           d2, x0
    // 0xb61da4: fdiv            d3, d0, d2
    // 0xb61da8: fadd            d0, d3, d1
    // 0xb61dac: r3 = inline_Allocate_Double()
    //     0xb61dac: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb61db0: add             x3, x3, #0x10
    //     0xb61db4: cmp             x0, x3
    //     0xb61db8: b.ls            #0xb61f80
    //     0xb61dbc: str             x3, [THR, #0x60]  ; THR::top
    //     0xb61dc0: sub             x3, x3, #0xf
    //     0xb61dc4: mov             x0, #0xe19c
    //     0xb61dc8: movk            x0, #3, lsl #16
    //     0xb61dcc: stur            x0, [x3, #-1]
    // 0xb61dd0: dmb             ishst
    // 0xb61dd4: StoreField: r3->field_7 = d0
    //     0xb61dd4: stur            d0, [x3, #7]
    // 0xb61dd8: r2 = 0.000000
    //     0xb61dd8: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xb61ddc: r0 = AllocateRecord2()
    //     0xb61ddc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61de0: mov             x2, x0
    // 0xb61de4: b               #0xb61ee8
    // 0xb61de8: tbnz            w4, #4, #0xb61e60
    // 0xb61dec: scvtf           d3, x2
    // 0xb61df0: fdiv            d4, d0, d3
    // 0xb61df4: fdiv            d0, d4, d2
    // 0xb61df8: fadd            d2, d4, d1
    // 0xb61dfc: r2 = inline_Allocate_Double()
    //     0xb61dfc: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb61e00: add             x2, x2, #0x10
    //     0xb61e04: cmp             x0, x2
    //     0xb61e08: b.ls            #0xb61f94
    //     0xb61e0c: str             x2, [THR, #0x60]  ; THR::top
    //     0xb61e10: sub             x2, x2, #0xf
    //     0xb61e14: mov             x0, #0xe19c
    //     0xb61e18: movk            x0, #3, lsl #16
    //     0xb61e1c: stur            x0, [x2, #-1]
    // 0xb61e20: dmb             ishst
    // 0xb61e24: StoreField: r2->field_7 = d0
    //     0xb61e24: stur            d0, [x2, #7]
    // 0xb61e28: r3 = inline_Allocate_Double()
    //     0xb61e28: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb61e2c: add             x3, x3, #0x10
    //     0xb61e30: cmp             x0, x3
    //     0xb61e34: b.ls            #0xb61fa8
    //     0xb61e38: str             x3, [THR, #0x60]  ; THR::top
    //     0xb61e3c: sub             x3, x3, #0xf
    //     0xb61e40: mov             x0, #0xe19c
    //     0xb61e44: movk            x0, #3, lsl #16
    //     0xb61e48: stur            x0, [x3, #-1]
    // 0xb61e4c: dmb             ishst
    // 0xb61e50: StoreField: r3->field_7 = d2
    //     0xb61e50: stur            d2, [x3, #7]
    // 0xb61e54: r0 = AllocateRecord2()
    //     0xb61e54: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61e58: mov             x2, x0
    // 0xb61e5c: b               #0xb61ee8
    // 0xb61e60: r16 = Instance_MainAxisAlignment
    //     0xb61e60: add             x16, PP, #0x18, lsl #12  ; [pp+0x180f8] Obj!MainAxisAlignment@12c4561
    //     0xb61e64: ldr             x16, [x16, #0xf8]
    // 0xb61e68: cmp             w1, w16
    // 0xb61e6c: b.ne            #0xb61ee4
    // 0xb61e70: add             x0, x2, #1
    // 0xb61e74: scvtf           d2, x0
    // 0xb61e78: fdiv            d3, d0, d2
    // 0xb61e7c: fadd            d0, d3, d1
    // 0xb61e80: r2 = inline_Allocate_Double()
    //     0xb61e80: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb61e84: add             x2, x2, #0x10
    //     0xb61e88: cmp             x0, x2
    //     0xb61e8c: b.ls            #0xb61fc4
    //     0xb61e90: str             x2, [THR, #0x60]  ; THR::top
    //     0xb61e94: sub             x2, x2, #0xf
    //     0xb61e98: mov             x0, #0xe19c
    //     0xb61e9c: movk            x0, #3, lsl #16
    //     0xb61ea0: stur            x0, [x2, #-1]
    // 0xb61ea4: dmb             ishst
    // 0xb61ea8: StoreField: r2->field_7 = d3
    //     0xb61ea8: stur            d3, [x2, #7]
    // 0xb61eac: r3 = inline_Allocate_Double()
    //     0xb61eac: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xb61eb0: add             x3, x3, #0x10
    //     0xb61eb4: cmp             x0, x3
    //     0xb61eb8: b.ls            #0xb61fd8
    //     0xb61ebc: str             x3, [THR, #0x60]  ; THR::top
    //     0xb61ec0: sub             x3, x3, #0xf
    //     0xb61ec4: mov             x0, #0xe19c
    //     0xb61ec8: movk            x0, #3, lsl #16
    //     0xb61ecc: stur            x0, [x3, #-1]
    // 0xb61ed0: dmb             ishst
    // 0xb61ed4: StoreField: r3->field_7 = d0
    //     0xb61ed4: stur            d0, [x3, #7]
    // 0xb61ed8: r0 = AllocateRecord2()
    //     0xb61ed8: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xb61edc: mov             x2, x0
    // 0xb61ee0: b               #0xb61ee8
    // 0xb61ee4: r2 = Null
    //     0xb61ee4: mov             x2, NULL
    // 0xb61ee8: LoadField: r0 = r2->field_f
    //     0xb61ee8: ldur            w0, [x2, #0xf]
    // 0xb61eec: DecompressPointer r0
    //     0xb61eec: add             x0, x0, HEAP, lsl #32
    // 0xb61ef0: LoadField: r1 = r2->field_13
    //     0xb61ef0: ldur            w1, [x2, #0x13]
    // 0xb61ef4: DecompressPointer r1
    //     0xb61ef4: add             x1, x1, HEAP, lsl #32
    // 0xb61ef8: LeaveFrame
    //     0xb61ef8: mov             SP, fp
    //     0xb61efc: ldp             fp, lr, [SP], #0x10
    // 0xb61f00: ret
    //     0xb61f00: ret             
    // 0xb61f04: r0 = StackOverflowSharedWithFPURegs()
    //     0xb61f04: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb61f08: b               #0xb61bac
    // 0xb61f0c: stp             q0, q1, [SP, #-0x20]!
    // 0xb61f10: r0 = AllocateDouble()
    //     0xb61f10: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61f14: mov             x2, x0
    // 0xb61f18: ldp             q0, q1, [SP], #0x20
    // 0xb61f1c: b               #0xb61be8
    // 0xb61f20: SaveReg d1
    //     0xb61f20: str             q1, [SP, #-0x10]!
    // 0xb61f24: SaveReg r2
    //     0xb61f24: str             x2, [SP, #-8]!
    // 0xb61f28: r0 = AllocateDouble()
    //     0xb61f28: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61f2c: mov             x3, x0
    // 0xb61f30: RestoreReg r2
    //     0xb61f30: ldr             x2, [SP], #8
    // 0xb61f34: RestoreReg d1
    //     0xb61f34: ldr             q1, [SP], #0x10
    // 0xb61f38: b               #0xb61c14
    // 0xb61f3c: SaveReg d1
    //     0xb61f3c: str             q1, [SP, #-0x10]!
    // 0xb61f40: r0 = AllocateDouble()
    //     0xb61f40: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61f44: mov             x3, x0
    // 0xb61f48: RestoreReg d1
    //     0xb61f48: ldr             q1, [SP], #0x10
    // 0xb61f4c: b               #0xb61c48
    // 0xb61f50: stp             q1, q3, [SP, #-0x20]!
    // 0xb61f54: r0 = AllocateDouble()
    //     0xb61f54: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61f58: mov             x3, x0
    // 0xb61f5c: ldp             q1, q3, [SP], #0x20
    // 0xb61f60: b               #0xb61d58
    // 0xb61f64: SaveReg d3
    //     0xb61f64: str             q3, [SP, #-0x10]!
    // 0xb61f68: SaveReg r3
    //     0xb61f68: str             x3, [SP, #-8]!
    // 0xb61f6c: r0 = AllocateDouble()
    //     0xb61f6c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61f70: mov             x2, x0
    // 0xb61f74: RestoreReg r3
    //     0xb61f74: ldr             x3, [SP], #8
    // 0xb61f78: RestoreReg d3
    //     0xb61f78: ldr             q3, [SP], #0x10
    // 0xb61f7c: b               #0xb61d84
    // 0xb61f80: SaveReg d0
    //     0xb61f80: str             q0, [SP, #-0x10]!
    // 0xb61f84: r0 = AllocateDouble()
    //     0xb61f84: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61f88: mov             x3, x0
    // 0xb61f8c: RestoreReg d0
    //     0xb61f8c: ldr             q0, [SP], #0x10
    // 0xb61f90: b               #0xb61dd4
    // 0xb61f94: stp             q0, q2, [SP, #-0x20]!
    // 0xb61f98: r0 = AllocateDouble()
    //     0xb61f98: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61f9c: mov             x2, x0
    // 0xb61fa0: ldp             q0, q2, [SP], #0x20
    // 0xb61fa4: b               #0xb61e24
    // 0xb61fa8: SaveReg d2
    //     0xb61fa8: str             q2, [SP, #-0x10]!
    // 0xb61fac: SaveReg r2
    //     0xb61fac: str             x2, [SP, #-8]!
    // 0xb61fb0: r0 = AllocateDouble()
    //     0xb61fb0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61fb4: mov             x3, x0
    // 0xb61fb8: RestoreReg r2
    //     0xb61fb8: ldr             x2, [SP], #8
    // 0xb61fbc: RestoreReg d2
    //     0xb61fbc: ldr             q2, [SP], #0x10
    // 0xb61fc0: b               #0xb61e50
    // 0xb61fc4: stp             q0, q3, [SP, #-0x20]!
    // 0xb61fc8: r0 = AllocateDouble()
    //     0xb61fc8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61fcc: mov             x2, x0
    // 0xb61fd0: ldp             q0, q3, [SP], #0x20
    // 0xb61fd4: b               #0xb61ea8
    // 0xb61fd8: SaveReg d0
    //     0xb61fd8: str             q0, [SP, #-0x10]!
    // 0xb61fdc: SaveReg r2
    //     0xb61fdc: str             x2, [SP, #-8]!
    // 0xb61fe0: r0 = AllocateDouble()
    //     0xb61fe0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61fe4: mov             x3, x0
    // 0xb61fe8: RestoreReg r2
    //     0xb61fe8: ldr             x2, [SP], #8
    // 0xb61fec: RestoreReg d0
    //     0xb61fec: ldr             q0, [SP], #0x10
    // 0xb61ff0: b               #0xb61ed4
  }
}

// class id: 8236, size: 0x14, field offset: 0x14
enum MainAxisSize extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 8237, size: 0x14, field offset: 0x14
enum FlexFit extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
