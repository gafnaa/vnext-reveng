// lib: , url: package:flutter/src/rendering/selection.dart

// class id: 1049040, size: 0x8
class :: {
}

// class id: 2852, size: 0x8, field offset: 0x8
abstract class SelectionRegistrar extends Object {
}

// class id: 2857, size: 0x8, field offset: 0x8
abstract class SelectionHandler extends Object
    implements ValueListenable<X0> {
}

// class id: 4415, size: 0x8, field offset: 0x8
abstract class Selectable extends Object
    implements SelectionHandler {
}

// class id: 4416, size: 0x8, field offset: 0x8
abstract class SelectionRegistrant extends Selectable {
}

// class id: 5038, size: 0x1c, field offset: 0x8
//   const constructor, 
class SelectionGeometry extends _MixinApplication3&Object&Diagnosticable {

  SelectionStatus field_10;
  _ImmutableList<Rect> field_14;
  bool field_18;

  get _ hashCode(/* No info */) {
    // ** addr: 0x113b708, size: 0x7c
    // 0x113b708: EnterFrame
    //     0x113b708: stp             fp, lr, [SP, #-0x10]!
    //     0x113b70c: mov             fp, SP
    // 0x113b710: AllocStack(0x18)
    //     0x113b710: sub             SP, SP, #0x18
    // 0x113b714: CheckStackOverflow
    //     0x113b714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x113b718: cmp             SP, x16
    //     0x113b71c: b.ls            #0x113b77c
    // 0x113b720: ldr             x0, [fp, #0x10]
    // 0x113b724: LoadField: r1 = r0->field_13
    //     0x113b724: ldur            w1, [x0, #0x13]
    // 0x113b728: DecompressPointer r1
    //     0x113b728: add             x1, x1, HEAP, lsl #32
    // 0x113b72c: LoadField: r2 = r0->field_f
    //     0x113b72c: ldur            w2, [x0, #0xf]
    // 0x113b730: DecompressPointer r2
    //     0x113b730: add             x2, x2, HEAP, lsl #32
    // 0x113b734: ArrayLoad: r3 = r0[0]  ; List_4
    //     0x113b734: ldur            w3, [x0, #0x17]
    // 0x113b738: DecompressPointer r3
    //     0x113b738: add             x3, x3, HEAP, lsl #32
    // 0x113b73c: stp             x2, x1, [SP, #8]
    // 0x113b740: str             x3, [SP]
    // 0x113b744: r1 = Null
    //     0x113b744: mov             x1, NULL
    // 0x113b748: r2 = Null
    //     0x113b748: mov             x2, NULL
    // 0x113b74c: r4 = const [0, 0x5, 0x3, 0x5, null]
    //     0x113b74c: add             x4, PP, #0xd, lsl #12  ; [pp+0xdc80] List(5) [0, 0x5, 0x3, 0x5, Null]
    //     0x113b750: ldr             x4, [x4, #0xc80]
    // 0x113b754: r0 = hash()
    //     0x113b754: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x113b758: mov             x2, x0
    // 0x113b75c: r0 = BoxInt64Instr(r2)
    //     0x113b75c: sbfiz           x0, x2, #1, #0x1f
    //     0x113b760: cmp             x2, x0, asr #1
    //     0x113b764: b.eq            #0x113b770
    //     0x113b768: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x113b76c: stur            x2, [x0, #7]
    // 0x113b770: LeaveFrame
    //     0x113b770: mov             SP, fp
    //     0x113b774: ldp             fp, lr, [SP], #0x10
    // 0x113b778: ret
    //     0x113b778: ret             
    // 0x113b77c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x113b77c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x113b780: b               #0x113b720
  }
  _ ==(/* No info */) {
    // ** addr: 0x1279100, size: 0x13c
    // 0x1279100: EnterFrame
    //     0x1279100: stp             fp, lr, [SP, #-0x10]!
    //     0x1279104: mov             fp, SP
    // 0x1279108: AllocStack(0x18)
    //     0x1279108: sub             SP, SP, #0x18
    // 0x127910c: CheckStackOverflow
    //     0x127910c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1279110: cmp             SP, x16
    //     0x1279114: b.ls            #0x1279234
    // 0x1279118: ldr             x0, [fp, #0x10]
    // 0x127911c: cmp             w0, NULL
    // 0x1279120: b.ne            #0x1279134
    // 0x1279124: r0 = false
    //     0x1279124: add             x0, NULL, #0x30  ; false
    // 0x1279128: LeaveFrame
    //     0x1279128: mov             SP, fp
    //     0x127912c: ldp             fp, lr, [SP], #0x10
    // 0x1279130: ret
    //     0x1279130: ret             
    // 0x1279134: ldr             x1, [fp, #0x18]
    // 0x1279138: cmp             w1, w0
    // 0x127913c: b.ne            #0x1279150
    // 0x1279140: r0 = true
    //     0x1279140: add             x0, NULL, #0x20  ; true
    // 0x1279144: LeaveFrame
    //     0x1279144: mov             SP, fp
    //     0x1279148: ldp             fp, lr, [SP], #0x10
    // 0x127914c: ret
    //     0x127914c: ret             
    // 0x1279150: str             x0, [SP]
    // 0x1279154: r0 = runtimeType()
    //     0x1279154: bl              #0x10fc4c4  ; [dart:core] Object::runtimeType
    // 0x1279158: r1 = LoadClassIdInstr(r0)
    //     0x1279158: ldur            x1, [x0, #-1]
    //     0x127915c: ubfx            x1, x1, #0xc, #0x14
    // 0x1279160: r16 = SelectionGeometry
    //     0x1279160: add             x16, PP, #0xad, lsl #12  ; [pp+0xad008] Type: SelectionGeometry
    //     0x1279164: ldr             x16, [x16, #8]
    // 0x1279168: stp             x16, x0, [SP]
    // 0x127916c: mov             x0, x1
    // 0x1279170: mov             lr, x0
    // 0x1279174: ldr             lr, [x21, lr, lsl #3]
    // 0x1279178: blr             lr
    // 0x127917c: tbz             w0, #4, #0x1279190
    // 0x1279180: r0 = false
    //     0x1279180: add             x0, NULL, #0x30  ; false
    // 0x1279184: LeaveFrame
    //     0x1279184: mov             SP, fp
    //     0x1279188: ldp             fp, lr, [SP], #0x10
    // 0x127918c: ret
    //     0x127918c: ret             
    // 0x1279190: ldr             x0, [fp, #0x10]
    // 0x1279194: r1 = 60
    //     0x1279194: mov             x1, #0x3c
    // 0x1279198: branchIfSmi(r0, 0x12791a4)
    //     0x1279198: tbz             w0, #0, #0x12791a4
    // 0x127919c: r1 = LoadClassIdInstr(r0)
    //     0x127919c: ldur            x1, [x0, #-1]
    //     0x12791a0: ubfx            x1, x1, #0xc, #0x14
    // 0x12791a4: r17 = 5038
    //     0x12791a4: mov             x17, #0x13ae
    // 0x12791a8: cmp             x1, x17
    // 0x12791ac: b.ne            #0x1279224
    // 0x12791b0: ldr             x1, [fp, #0x18]
    // 0x12791b4: LoadField: r2 = r0->field_13
    //     0x12791b4: ldur            w2, [x0, #0x13]
    // 0x12791b8: DecompressPointer r2
    //     0x12791b8: add             x2, x2, HEAP, lsl #32
    // 0x12791bc: LoadField: r3 = r1->field_13
    //     0x12791bc: ldur            w3, [x1, #0x13]
    // 0x12791c0: DecompressPointer r3
    //     0x12791c0: add             x3, x3, HEAP, lsl #32
    // 0x12791c4: r16 = <Rect>
    //     0x12791c4: ldr             x16, [PP, #0x48d0]  ; [pp+0x48d0] TypeArguments: <Rect>
    // 0x12791c8: stp             x2, x16, [SP, #8]
    // 0x12791cc: str             x3, [SP]
    // 0x12791d0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x12791d0: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x12791d4: r0 = listEquals()
    //     0x12791d4: bl              #0x8595b0  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x12791d8: tbnz            w0, #4, #0x1279224
    // 0x12791dc: ldr             x2, [fp, #0x18]
    // 0x12791e0: ldr             x1, [fp, #0x10]
    // 0x12791e4: LoadField: r3 = r1->field_f
    //     0x12791e4: ldur            w3, [x1, #0xf]
    // 0x12791e8: DecompressPointer r3
    //     0x12791e8: add             x3, x3, HEAP, lsl #32
    // 0x12791ec: LoadField: r4 = r2->field_f
    //     0x12791ec: ldur            w4, [x2, #0xf]
    // 0x12791f0: DecompressPointer r4
    //     0x12791f0: add             x4, x4, HEAP, lsl #32
    // 0x12791f4: cmp             w3, w4
    // 0x12791f8: b.ne            #0x1279224
    // 0x12791fc: ArrayLoad: r3 = r1[0]  ; List_4
    //     0x12791fc: ldur            w3, [x1, #0x17]
    // 0x1279200: DecompressPointer r3
    //     0x1279200: add             x3, x3, HEAP, lsl #32
    // 0x1279204: ArrayLoad: r1 = r2[0]  ; List_4
    //     0x1279204: ldur            w1, [x2, #0x17]
    // 0x1279208: DecompressPointer r1
    //     0x1279208: add             x1, x1, HEAP, lsl #32
    // 0x127920c: cmp             w3, w1
    // 0x1279210: r16 = true
    //     0x1279210: add             x16, NULL, #0x20  ; true
    // 0x1279214: r17 = false
    //     0x1279214: add             x17, NULL, #0x30  ; false
    // 0x1279218: csel            x2, x16, x17, eq
    // 0x127921c: mov             x0, x2
    // 0x1279220: b               #0x1279228
    // 0x1279224: r0 = false
    //     0x1279224: add             x0, NULL, #0x30  ; false
    // 0x1279228: LeaveFrame
    //     0x1279228: mov             SP, fp
    //     0x127922c: ldp             fp, lr, [SP], #0x10
    // 0x1279230: ret
    //     0x1279230: ret             
    // 0x1279234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1279234: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1279238: b               #0x1279118
  }
}

// class id: 8223, size: 0x14, field offset: 0x14
enum TextSelectionHandleType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab160, size: 0x64
    // 0x11ab160: EnterFrame
    //     0x11ab160: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab164: mov             fp, SP
    // 0x11ab168: AllocStack(0x10)
    //     0x11ab168: sub             SP, SP, #0x10
    // 0x11ab16c: SetupParameters(TextSelectionHandleType this /* r1 => r0, fp-0x8 */)
    //     0x11ab16c: mov             x0, x1
    //     0x11ab170: stur            x1, [fp, #-8]
    // 0x11ab174: CheckStackOverflow
    //     0x11ab174: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab178: cmp             SP, x16
    //     0x11ab17c: b.ls            #0x11ab1bc
    // 0x11ab180: r1 = Null
    //     0x11ab180: mov             x1, NULL
    // 0x11ab184: r2 = 4
    //     0x11ab184: mov             x2, #4
    // 0x11ab188: r0 = AllocateArray()
    //     0x11ab188: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab18c: r16 = "TextSelectionHandleType."
    //     0x11ab18c: add             x16, PP, #0x10, lsl #12  ; [pp+0x10db8] "TextSelectionHandleType."
    //     0x11ab190: ldr             x16, [x16, #0xdb8]
    // 0x11ab194: StoreField: r0->field_f = r16
    //     0x11ab194: stur            w16, [x0, #0xf]
    // 0x11ab198: ldur            x1, [fp, #-8]
    // 0x11ab19c: LoadField: r2 = r1->field_f
    //     0x11ab19c: ldur            w2, [x1, #0xf]
    // 0x11ab1a0: DecompressPointer r2
    //     0x11ab1a0: add             x2, x2, HEAP, lsl #32
    // 0x11ab1a4: StoreField: r0->field_13 = r2
    //     0x11ab1a4: stur            w2, [x0, #0x13]
    // 0x11ab1a8: str             x0, [SP]
    // 0x11ab1ac: r0 = _interpolate()
    //     0x11ab1ac: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab1b0: LeaveFrame
    //     0x11ab1b0: mov             SP, fp
    //     0x11ab1b4: ldp             fp, lr, [SP], #0x10
    // 0x11ab1b8: ret
    //     0x11ab1b8: ret             
    // 0x11ab1bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab1bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab1c0: b               #0x11ab180
  }
}

// class id: 8224, size: 0x14, field offset: 0x14
enum SelectionStatus extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab0fc, size: 0x64
    // 0x11ab0fc: EnterFrame
    //     0x11ab0fc: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab100: mov             fp, SP
    // 0x11ab104: AllocStack(0x10)
    //     0x11ab104: sub             SP, SP, #0x10
    // 0x11ab108: SetupParameters(SelectionStatus this /* r1 => r0, fp-0x8 */)
    //     0x11ab108: mov             x0, x1
    //     0x11ab10c: stur            x1, [fp, #-8]
    // 0x11ab110: CheckStackOverflow
    //     0x11ab110: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab114: cmp             SP, x16
    //     0x11ab118: b.ls            #0x11ab158
    // 0x11ab11c: r1 = Null
    //     0x11ab11c: mov             x1, NULL
    // 0x11ab120: r2 = 4
    //     0x11ab120: mov             x2, #4
    // 0x11ab124: r0 = AllocateArray()
    //     0x11ab124: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab128: r16 = "SelectionStatus."
    //     0x11ab128: add             x16, PP, #0xad, lsl #12  ; [pp+0xad010] "SelectionStatus."
    //     0x11ab12c: ldr             x16, [x16, #0x10]
    // 0x11ab130: StoreField: r0->field_f = r16
    //     0x11ab130: stur            w16, [x0, #0xf]
    // 0x11ab134: ldur            x1, [fp, #-8]
    // 0x11ab138: LoadField: r2 = r1->field_f
    //     0x11ab138: ldur            w2, [x1, #0xf]
    // 0x11ab13c: DecompressPointer r2
    //     0x11ab13c: add             x2, x2, HEAP, lsl #32
    // 0x11ab140: StoreField: r0->field_13 = r2
    //     0x11ab140: stur            w2, [x0, #0x13]
    // 0x11ab144: str             x0, [SP]
    // 0x11ab148: r0 = _interpolate()
    //     0x11ab148: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab14c: LeaveFrame
    //     0x11ab14c: mov             SP, fp
    //     0x11ab150: ldp             fp, lr, [SP], #0x10
    // 0x11ab154: ret
    //     0x11ab154: ret             
    // 0x11ab158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab158: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab15c: b               #0x11ab11c
  }
}
