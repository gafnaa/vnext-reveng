// lib: , url: package:flutter/src/rendering/debug_overflow_indicator.dart

// class id: 1049024, size: 0x8
class :: {
}

// class id: 4704, size: 0x48, field offset: 0x48
abstract class DebugOverflowIndicatorMixin extends RenderObject {
}
