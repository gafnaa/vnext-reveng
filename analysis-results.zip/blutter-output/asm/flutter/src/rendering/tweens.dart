// lib: , url: package:flutter/src/rendering/tweens.dart

// class id: 1049053, size: 0x8
class :: {
}

// class id: 3306, size: 0x14, field offset: 0x14
class AlignmentGeometryTween extends Tween<dynamic> {

  _ lerp(/* No info */) {
    // ** addr: 0x116ac90, size: 0x40
    // 0x116ac90: EnterFrame
    //     0x116ac90: stp             fp, lr, [SP, #-0x10]!
    //     0x116ac94: mov             fp, SP
    // 0x116ac98: CheckStackOverflow
    //     0x116ac98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116ac9c: cmp             SP, x16
    //     0x116aca0: b.ls            #0x116acc8
    // 0x116aca4: LoadField: r0 = r1->field_b
    //     0x116aca4: ldur            w0, [x1, #0xb]
    // 0x116aca8: DecompressPointer r0
    //     0x116aca8: add             x0, x0, HEAP, lsl #32
    // 0x116acac: LoadField: r2 = r1->field_f
    //     0x116acac: ldur            w2, [x1, #0xf]
    // 0x116acb0: DecompressPointer r2
    //     0x116acb0: add             x2, x2, HEAP, lsl #32
    // 0x116acb4: mov             x1, x0
    // 0x116acb8: r0 = lerp()
    //     0x116acb8: bl              #0x1160c48  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0x116acbc: LeaveFrame
    //     0x116acbc: mov             SP, fp
    //     0x116acc0: ldp             fp, lr, [SP], #0x10
    // 0x116acc4: ret
    //     0x116acc4: ret             
    // 0x116acc8: r0 = StackOverflowSharedWithFPURegs()
    //     0x116acc8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116accc: b               #0x116aca4
  }
}

// class id: 3307, size: 0x14, field offset: 0x14
class AlignmentTween extends Tween<dynamic> {

  _ lerp(/* No info */) {
    // ** addr: 0x116ac44, size: 0x4c
    // 0x116ac44: EnterFrame
    //     0x116ac44: stp             fp, lr, [SP, #-0x10]!
    //     0x116ac48: mov             fp, SP
    // 0x116ac4c: CheckStackOverflow
    //     0x116ac4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116ac50: cmp             SP, x16
    //     0x116ac54: b.ls            #0x116ac84
    // 0x116ac58: LoadField: r0 = r1->field_b
    //     0x116ac58: ldur            w0, [x1, #0xb]
    // 0x116ac5c: DecompressPointer r0
    //     0x116ac5c: add             x0, x0, HEAP, lsl #32
    // 0x116ac60: LoadField: r2 = r1->field_f
    //     0x116ac60: ldur            w2, [x1, #0xf]
    // 0x116ac64: DecompressPointer r2
    //     0x116ac64: add             x2, x2, HEAP, lsl #32
    // 0x116ac68: mov             x1, x0
    // 0x116ac6c: r0 = lerp()
    //     0x116ac6c: bl              #0x1161598  ; [package:flutter/src/painting/alignment.dart] Alignment::lerp
    // 0x116ac70: cmp             w0, NULL
    // 0x116ac74: b.eq            #0x116ac8c
    // 0x116ac78: LeaveFrame
    //     0x116ac78: mov             SP, fp
    //     0x116ac7c: ldp             fp, lr, [SP], #0x10
    // 0x116ac80: ret
    //     0x116ac80: ret             
    // 0x116ac84: r0 = StackOverflowSharedWithFPURegs()
    //     0x116ac84: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x116ac88: b               #0x116ac58
    // 0x116ac8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x116ac8c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
