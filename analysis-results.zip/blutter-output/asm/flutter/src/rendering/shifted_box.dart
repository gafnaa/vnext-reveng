// lib: , url: package:flutter/src/rendering/shifted_box.dart

// class id: 1049041, size: 0x8
class :: {
}

// class id: 3126, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class SingleChildLayoutDelegate extends Object {
}

// class id: 4873, size: 0x54, field offset: 0x54
abstract class RenderShiftedBox extends _MixinApplication6&RenderBox&RenderObjectWithChildMixin {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb17610, size: 0x24
    // 0xb17610: EnterFrame
    //     0xb17610: stp             fp, lr, [SP, #-0x10]!
    //     0xb17614: mov             fp, SP
    // 0xb17618: ldr             x2, [fp, #0x10]
    // 0xb1761c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1761c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2948] AnonymousClosure: (0xb17634), in [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeMinIntrinsicWidth (0xb16174)
    //     0xb17620: ldr             x1, [x1, #0x948]
    // 0xb17624: r0 = AllocateClosure()
    //     0xb17624: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb17628: LeaveFrame
    //     0xb17628: mov             SP, fp
    //     0xb1762c: ldp             fp, lr, [SP], #0x10
    // 0xb17630: ret
    //     0xb17630: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb17634, size: 0x78
    // 0xb17634: EnterFrame
    //     0xb17634: stp             fp, lr, [SP, #-0x10]!
    //     0xb17638: mov             fp, SP
    // 0xb1763c: ldr             x0, [fp, #0x18]
    // 0xb17640: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb17640: ldur            w1, [x0, #0x17]
    // 0xb17644: DecompressPointer r1
    //     0xb17644: add             x1, x1, HEAP, lsl #32
    // 0xb17648: CheckStackOverflow
    //     0xb17648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1764c: cmp             SP, x16
    //     0xb17650: b.ls            #0xb17694
    // 0xb17654: ldr             x2, [fp, #0x10]
    // 0xb17658: r0 = computeMinIntrinsicWidth()
    //     0xb17658: bl              #0xb16174  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0xb1765c: r0 = inline_Allocate_Double()
    //     0xb1765c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb17660: add             x0, x0, #0x10
    //     0xb17664: cmp             x1, x0
    //     0xb17668: b.ls            #0xb1769c
    //     0xb1766c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb17670: sub             x0, x0, #0xf
    //     0xb17674: mov             x1, #0xe19c
    //     0xb17678: movk            x1, #3, lsl #16
    //     0xb1767c: stur            x1, [x0, #-1]
    // 0xb17680: dmb             ishst
    // 0xb17684: StoreField: r0->field_7 = d0
    //     0xb17684: stur            d0, [x0, #7]
    // 0xb17688: LeaveFrame
    //     0xb17688: mov             SP, fp
    //     0xb1768c: ldp             fp, lr, [SP], #0x10
    // 0xb17690: ret
    //     0xb17690: ret             
    // 0xb17694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb17694: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb17698: b               #0xb17654
    // 0xb1769c: SaveReg d0
    //     0xb1769c: str             q0, [SP, #-0x10]!
    // 0xb176a0: r0 = AllocateDouble()
    //     0xb176a0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb176a4: RestoreReg d0
    //     0xb176a4: ldr             q0, [SP], #0x10
    // 0xb176a8: b               #0xb17684
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb5842c, size: 0x24
    // 0xb5842c: EnterFrame
    //     0xb5842c: stp             fp, lr, [SP, #-0x10]!
    //     0xb58430: mov             fp, SP
    // 0xb58434: ldr             x2, [fp, #0x10]
    // 0xb58438: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58438: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2940] AnonymousClosure: (0xb58450), in [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicWidth (0xb2d828)
    //     0xb5843c: ldr             x1, [x1, #0x940]
    // 0xb58440: r0 = AllocateClosure()
    //     0xb58440: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58444: LeaveFrame
    //     0xb58444: mov             SP, fp
    //     0xb58448: ldp             fp, lr, [SP], #0x10
    // 0xb5844c: ret
    //     0xb5844c: ret             
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb58450, size: 0x78
    // 0xb58450: EnterFrame
    //     0xb58450: stp             fp, lr, [SP, #-0x10]!
    //     0xb58454: mov             fp, SP
    // 0xb58458: ldr             x0, [fp, #0x18]
    // 0xb5845c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb5845c: ldur            w1, [x0, #0x17]
    // 0xb58460: DecompressPointer r1
    //     0xb58460: add             x1, x1, HEAP, lsl #32
    // 0xb58464: CheckStackOverflow
    //     0xb58464: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb58468: cmp             SP, x16
    //     0xb5846c: b.ls            #0xb584b0
    // 0xb58470: ldr             x2, [fp, #0x10]
    // 0xb58474: r0 = computeMaxIntrinsicWidth()
    //     0xb58474: bl              #0xb2d828  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicWidth
    // 0xb58478: r0 = inline_Allocate_Double()
    //     0xb58478: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5847c: add             x0, x0, #0x10
    //     0xb58480: cmp             x1, x0
    //     0xb58484: b.ls            #0xb584b8
    //     0xb58488: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5848c: sub             x0, x0, #0xf
    //     0xb58490: mov             x1, #0xe19c
    //     0xb58494: movk            x1, #3, lsl #16
    //     0xb58498: stur            x1, [x0, #-1]
    // 0xb5849c: dmb             ishst
    // 0xb584a0: StoreField: r0->field_7 = d0
    //     0xb584a0: stur            d0, [x0, #7]
    // 0xb584a4: LeaveFrame
    //     0xb584a4: mov             SP, fp
    //     0xb584a8: ldp             fp, lr, [SP], #0x10
    // 0xb584ac: ret
    //     0xb584ac: ret             
    // 0xb584b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb584b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb584b4: b               #0xb58470
    // 0xb584b8: SaveReg d0
    //     0xb584b8: str             q0, [SP, #-0x10]!
    // 0xb584bc: r0 = AllocateDouble()
    //     0xb584bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb584c0: RestoreReg d0
    //     0xb584c0: ldr             q0, [SP], #0x10
    // 0xb584c4: b               #0xb584a0
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5a6d0, size: 0x118
    // 0xb5a6d0: EnterFrame
    //     0xb5a6d0: stp             fp, lr, [SP, #-0x10]!
    //     0xb5a6d4: mov             fp, SP
    // 0xb5a6d8: AllocStack(0x18)
    //     0xb5a6d8: sub             SP, SP, #0x18
    // 0xb5a6dc: CheckStackOverflow
    //     0xb5a6dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5a6e0: cmp             SP, x16
    //     0xb5a6e4: b.ls            #0xb5a7c8
    // 0xb5a6e8: LoadField: r0 = r1->field_4f
    //     0xb5a6e8: ldur            w0, [x1, #0x4f]
    // 0xb5a6ec: DecompressPointer r0
    //     0xb5a6ec: add             x0, x0, HEAP, lsl #32
    // 0xb5a6f0: stur            x0, [fp, #-8]
    // 0xb5a6f4: cmp             w0, NULL
    // 0xb5a6f8: b.eq            #0xb5a7b8
    // 0xb5a6fc: mov             x1, x0
    // 0xb5a700: r0 = getDistanceToActualBaseline()
    //     0xb5a700: bl              #0xb53d74  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0xb5a704: mov             x3, x0
    // 0xb5a708: ldur            x0, [fp, #-8]
    // 0xb5a70c: stur            x3, [fp, #-0x18]
    // 0xb5a710: LoadField: r4 = r0->field_7
    //     0xb5a710: ldur            w4, [x0, #7]
    // 0xb5a714: DecompressPointer r4
    //     0xb5a714: add             x4, x4, HEAP, lsl #32
    // 0xb5a718: stur            x4, [fp, #-0x10]
    // 0xb5a71c: cmp             w4, NULL
    // 0xb5a720: b.eq            #0xb5a7d0
    // 0xb5a724: mov             x0, x4
    // 0xb5a728: r2 = Null
    //     0xb5a728: mov             x2, NULL
    // 0xb5a72c: r1 = Null
    //     0xb5a72c: mov             x1, NULL
    // 0xb5a730: r4 = LoadClassIdInstr(r0)
    //     0xb5a730: ldur            x4, [x0, #-1]
    //     0xb5a734: ubfx            x4, x4, #0xc, #0x14
    // 0xb5a738: r17 = -4190
    //     0xb5a738: mov             x17, #-0x105e
    // 0xb5a73c: add             x4, x4, x17
    // 0xb5a740: cmp             x4, #0x17
    // 0xb5a744: b.ls            #0xb5a75c
    // 0xb5a748: r8 = BoxParentData
    //     0xb5a748: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xb5a74c: ldr             x8, [x8, #0x5e8]
    // 0xb5a750: r3 = Null
    //     0xb5a750: add             x3, PP, #0x98, lsl #12  ; [pp+0x98560] Null
    //     0xb5a754: ldr             x3, [x3, #0x560]
    // 0xb5a758: r0 = DefaultTypeTest()
    //     0xb5a758: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb5a75c: ldur            x1, [fp, #-0x18]
    // 0xb5a760: cmp             w1, NULL
    // 0xb5a764: b.eq            #0xb5a7b0
    // 0xb5a768: ldur            x2, [fp, #-0x10]
    // 0xb5a76c: LoadField: r3 = r2->field_7
    //     0xb5a76c: ldur            w3, [x2, #7]
    // 0xb5a770: DecompressPointer r3
    //     0xb5a770: add             x3, x3, HEAP, lsl #32
    // 0xb5a774: LoadField: d0 = r3->field_f
    //     0xb5a774: ldur            d0, [x3, #0xf]
    // 0xb5a778: LoadField: d1 = r1->field_7
    //     0xb5a778: ldur            d1, [x1, #7]
    // 0xb5a77c: fadd            d2, d1, d0
    // 0xb5a780: r2 = inline_Allocate_Double()
    //     0xb5a780: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb5a784: add             x2, x2, #0x10
    //     0xb5a788: cmp             x3, x2
    //     0xb5a78c: b.ls            #0xb5a7d4
    //     0xb5a790: str             x2, [THR, #0x60]  ; THR::top
    //     0xb5a794: sub             x2, x2, #0xf
    //     0xb5a798: mov             x3, #0xe19c
    //     0xb5a79c: movk            x3, #3, lsl #16
    //     0xb5a7a0: stur            x3, [x2, #-1]
    // 0xb5a7a4: dmb             ishst
    // 0xb5a7a8: StoreField: r2->field_7 = d2
    //     0xb5a7a8: stur            d2, [x2, #7]
    // 0xb5a7ac: mov             x1, x2
    // 0xb5a7b0: mov             x0, x1
    // 0xb5a7b4: b               #0xb5a7bc
    // 0xb5a7b8: r0 = Null
    //     0xb5a7b8: mov             x0, NULL
    // 0xb5a7bc: LeaveFrame
    //     0xb5a7bc: mov             SP, fp
    //     0xb5a7c0: ldp             fp, lr, [SP], #0x10
    // 0xb5a7c4: ret
    //     0xb5a7c4: ret             
    // 0xb5a7c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5a7c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5a7cc: b               #0xb5a6e8
    // 0xb5a7d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5a7d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb5a7d4: SaveReg d2
    //     0xb5a7d4: str             q2, [SP, #-0x10]!
    // 0xb5a7d8: r0 = AllocateDouble()
    //     0xb5a7d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5a7dc: mov             x2, x0
    // 0xb5a7e0: RestoreReg d2
    //     0xb5a7e0: ldr             q2, [SP], #0x10
    // 0xb5a7e4: b               #0xb5a7a8
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e590, size: 0x24
    // 0xb5e590: EnterFrame
    //     0xb5e590: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e594: mov             fp, SP
    // 0xb5e598: ldr             x2, [fp, #0x10]
    // 0xb5e59c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e59c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98548] AnonymousClosure: (0xb5e5b4), in [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicHeight (0xb2a3e0)
    //     0xb5e5a0: ldr             x1, [x1, #0x548]
    // 0xb5e5a4: r0 = AllocateClosure()
    //     0xb5e5a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e5a8: LeaveFrame
    //     0xb5e5a8: mov             SP, fp
    //     0xb5e5ac: ldp             fp, lr, [SP], #0x10
    // 0xb5e5b0: ret
    //     0xb5e5b0: ret             
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb5e5b4, size: 0x78
    // 0xb5e5b4: EnterFrame
    //     0xb5e5b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e5b8: mov             fp, SP
    // 0xb5e5bc: ldr             x0, [fp, #0x18]
    // 0xb5e5c0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb5e5c0: ldur            w1, [x0, #0x17]
    // 0xb5e5c4: DecompressPointer r1
    //     0xb5e5c4: add             x1, x1, HEAP, lsl #32
    // 0xb5e5c8: CheckStackOverflow
    //     0xb5e5c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5e5cc: cmp             SP, x16
    //     0xb5e5d0: b.ls            #0xb5e614
    // 0xb5e5d4: ldr             x2, [fp, #0x10]
    // 0xb5e5d8: r0 = computeMaxIntrinsicHeight()
    //     0xb5e5d8: bl              #0xb2a3e0  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicHeight
    // 0xb5e5dc: r0 = inline_Allocate_Double()
    //     0xb5e5dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5e5e0: add             x0, x0, #0x10
    //     0xb5e5e4: cmp             x1, x0
    //     0xb5e5e8: b.ls            #0xb5e61c
    //     0xb5e5ec: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5e5f0: sub             x0, x0, #0xf
    //     0xb5e5f4: mov             x1, #0xe19c
    //     0xb5e5f8: movk            x1, #3, lsl #16
    //     0xb5e5fc: stur            x1, [x0, #-1]
    // 0xb5e600: dmb             ishst
    // 0xb5e604: StoreField: r0->field_7 = d0
    //     0xb5e604: stur            d0, [x0, #7]
    // 0xb5e608: LeaveFrame
    //     0xb5e608: mov             SP, fp
    //     0xb5e60c: ldp             fp, lr, [SP], #0x10
    // 0xb5e610: ret
    //     0xb5e610: ret             
    // 0xb5e614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5e614: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5e618: b               #0xb5e5d4
    // 0xb5e61c: SaveReg d0
    //     0xb5e61c: str             q0, [SP, #-0x10]!
    // 0xb5e620: r0 = AllocateDouble()
    //     0xb5e620: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5e624: RestoreReg d0
    //     0xb5e624: ldr             q0, [SP], #0x10
    // 0xb5e628: b               #0xb5e604
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb61258, size: 0xc0
    // 0xb61258: EnterFrame
    //     0xb61258: stp             fp, lr, [SP, #-0x10]!
    //     0xb6125c: mov             fp, SP
    // 0xb61260: AllocStack(0x18)
    //     0xb61260: sub             SP, SP, #0x18
    // 0xb61264: SetupParameters(RenderShiftedBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb61264: mov             x5, x1
    //     0xb61268: mov             x4, x2
    //     0xb6126c: stur            x1, [fp, #-8]
    //     0xb61270: stur            x2, [fp, #-0x10]
    //     0xb61274: stur            x3, [fp, #-0x18]
    // 0xb61278: CheckStackOverflow
    //     0xb61278: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6127c: cmp             SP, x16
    //     0xb61280: b.ls            #0xb61310
    // 0xb61284: mov             x0, x4
    // 0xb61288: r2 = Null
    //     0xb61288: mov             x2, NULL
    // 0xb6128c: r1 = Null
    //     0xb6128c: mov             x1, NULL
    // 0xb61290: r4 = 60
    //     0xb61290: mov             x4, #0x3c
    // 0xb61294: branchIfSmi(r0, 0xb612a0)
    //     0xb61294: tbz             w0, #0, #0xb612a0
    // 0xb61298: r4 = LoadClassIdInstr(r0)
    //     0xb61298: ldur            x4, [x0, #-1]
    //     0xb6129c: ubfx            x4, x4, #0xc, #0x14
    // 0xb612a0: sub             x4, x4, #0xb46
    // 0xb612a4: cmp             x4, #1
    // 0xb612a8: b.ls            #0xb612bc
    // 0xb612ac: r8 = BoxConstraints
    //     0xb612ac: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb612b0: r3 = Null
    //     0xb612b0: add             x3, PP, #0x98, lsl #12  ; [pp+0x98550] Null
    //     0xb612b4: ldr             x3, [x3, #0x550]
    // 0xb612b8: r0 = BoxConstraints()
    //     0xb612b8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb612bc: ldur            x0, [fp, #-8]
    // 0xb612c0: LoadField: r1 = r0->field_4f
    //     0xb612c0: ldur            w1, [x0, #0x4f]
    // 0xb612c4: DecompressPointer r1
    //     0xb612c4: add             x1, x1, HEAP, lsl #32
    // 0xb612c8: cmp             w1, NULL
    // 0xb612cc: b.ne            #0xb612e0
    // 0xb612d0: r0 = Null
    //     0xb612d0: mov             x0, NULL
    // 0xb612d4: LeaveFrame
    //     0xb612d4: mov             SP, fp
    //     0xb612d8: ldp             fp, lr, [SP], #0x10
    // 0xb612dc: ret
    //     0xb612dc: ret             
    // 0xb612e0: ldur            x2, [fp, #-0x10]
    // 0xb612e4: ldur            x3, [fp, #-0x18]
    // 0xb612e8: r0 = getDryBaseline()
    //     0xb612e8: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb612ec: cmp             w0, NULL
    // 0xb612f0: b.ne            #0xb61304
    // 0xb612f4: r0 = Null
    //     0xb612f4: mov             x0, NULL
    // 0xb612f8: LeaveFrame
    //     0xb612f8: mov             SP, fp
    //     0xb612fc: ldp             fp, lr, [SP], #0x10
    // 0xb61300: ret
    //     0xb61300: ret             
    // 0xb61304: LeaveFrame
    //     0xb61304: mov             SP, fp
    //     0xb61308: ldp             fp, lr, [SP], #0x10
    // 0xb6130c: ret
    //     0xb6130c: ret             
    // 0xb61310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb61310: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb61314: b               #0xb61284
  }
  [closure] void paint(dynamic, PaintingContext, Offset) {
    // ** addr: 0xc1fc70, size: 0x40
    // 0xc1fc70: EnterFrame
    //     0xc1fc70: stp             fp, lr, [SP, #-0x10]!
    //     0xc1fc74: mov             fp, SP
    // 0xc1fc78: ldr             x0, [fp, #0x20]
    // 0xc1fc7c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc1fc7c: ldur            w1, [x0, #0x17]
    // 0xc1fc80: DecompressPointer r1
    //     0xc1fc80: add             x1, x1, HEAP, lsl #32
    // 0xc1fc84: CheckStackOverflow
    //     0xc1fc84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1fc88: cmp             SP, x16
    //     0xc1fc8c: b.ls            #0xc1fca8
    // 0xc1fc90: ldr             x2, [fp, #0x18]
    // 0xc1fc94: ldr             x3, [fp, #0x10]
    // 0xc1fc98: r0 = paint()
    //     0xc1fc98: bl              #0xc20b90  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint
    // 0xc1fc9c: LeaveFrame
    //     0xc1fc9c: mov             SP, fp
    //     0xc1fca0: ldp             fp, lr, [SP], #0x10
    // 0xc1fca4: ret
    //     0xc1fca4: ret             
    // 0xc1fca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1fca8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1fcac: b               #0xc1fc90
  }
  _ paint(/* No info */) {
    // ** addr: 0xc20b90, size: 0xc4
    // 0xc20b90: EnterFrame
    //     0xc20b90: stp             fp, lr, [SP, #-0x10]!
    //     0xc20b94: mov             fp, SP
    // 0xc20b98: AllocStack(0x20)
    //     0xc20b98: sub             SP, SP, #0x20
    // 0xc20b9c: SetupParameters(dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xc20b9c: mov             x4, x2
    //     0xc20ba0: stur            x2, [fp, #-0x18]
    //     0xc20ba4: stur            x3, [fp, #-0x20]
    // 0xc20ba8: CheckStackOverflow
    //     0xc20ba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc20bac: cmp             SP, x16
    //     0xc20bb0: b.ls            #0xc20c48
    // 0xc20bb4: LoadField: r5 = r1->field_4f
    //     0xc20bb4: ldur            w5, [x1, #0x4f]
    // 0xc20bb8: DecompressPointer r5
    //     0xc20bb8: add             x5, x5, HEAP, lsl #32
    // 0xc20bbc: stur            x5, [fp, #-0x10]
    // 0xc20bc0: cmp             w5, NULL
    // 0xc20bc4: b.eq            #0xc20c38
    // 0xc20bc8: LoadField: r6 = r5->field_7
    //     0xc20bc8: ldur            w6, [x5, #7]
    // 0xc20bcc: DecompressPointer r6
    //     0xc20bcc: add             x6, x6, HEAP, lsl #32
    // 0xc20bd0: stur            x6, [fp, #-8]
    // 0xc20bd4: cmp             w6, NULL
    // 0xc20bd8: b.eq            #0xc20c50
    // 0xc20bdc: mov             x0, x6
    // 0xc20be0: r2 = Null
    //     0xc20be0: mov             x2, NULL
    // 0xc20be4: r1 = Null
    //     0xc20be4: mov             x1, NULL
    // 0xc20be8: r4 = LoadClassIdInstr(r0)
    //     0xc20be8: ldur            x4, [x0, #-1]
    //     0xc20bec: ubfx            x4, x4, #0xc, #0x14
    // 0xc20bf0: r17 = -4190
    //     0xc20bf0: mov             x17, #-0x105e
    // 0xc20bf4: add             x4, x4, x17
    // 0xc20bf8: cmp             x4, #0x17
    // 0xc20bfc: b.ls            #0xc20c14
    // 0xc20c00: r8 = BoxParentData
    //     0xc20c00: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xc20c04: ldr             x8, [x8, #0x5e8]
    // 0xc20c08: r3 = Null
    //     0xc20c08: add             x3, PP, #0x81, lsl #12  ; [pp+0x81d20] Null
    //     0xc20c0c: ldr             x3, [x3, #0xd20]
    // 0xc20c10: r0 = DefaultTypeTest()
    //     0xc20c10: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc20c14: ldur            x0, [fp, #-8]
    // 0xc20c18: LoadField: r1 = r0->field_7
    //     0xc20c18: ldur            w1, [x0, #7]
    // 0xc20c1c: DecompressPointer r1
    //     0xc20c1c: add             x1, x1, HEAP, lsl #32
    // 0xc20c20: ldur            x2, [fp, #-0x20]
    // 0xc20c24: r0 = +()
    //     0xc20c24: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc20c28: ldur            x1, [fp, #-0x18]
    // 0xc20c2c: ldur            x2, [fp, #-0x10]
    // 0xc20c30: mov             x3, x0
    // 0xc20c34: r0 = paintChild()
    //     0xc20c34: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc20c38: r0 = Null
    //     0xc20c38: mov             x0, NULL
    // 0xc20c3c: LeaveFrame
    //     0xc20c3c: mov             SP, fp
    //     0xc20c40: ldp             fp, lr, [SP], #0x10
    // 0xc20c44: ret
    //     0xc20c44: ret             
    // 0xc20c48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20c48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20c4c: b               #0xc20bb4
    // 0xc20c50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc20c50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e9a40, size: 0x100
    // 0x10e9a40: EnterFrame
    //     0x10e9a40: stp             fp, lr, [SP, #-0x10]!
    //     0x10e9a44: mov             fp, SP
    // 0x10e9a48: AllocStack(0x28)
    //     0x10e9a48: sub             SP, SP, #0x28
    // 0x10e9a4c: SetupParameters(RenderShiftedBox this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r5, fp-0x18 */)
    //     0x10e9a4c: mov             x0, x1
    //     0x10e9a50: mov             x1, x2
    //     0x10e9a54: mov             x5, x3
    //     0x10e9a58: stur            x2, [fp, #-0x10]
    //     0x10e9a5c: stur            x3, [fp, #-0x18]
    // 0x10e9a60: CheckStackOverflow
    //     0x10e9a60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e9a64: cmp             SP, x16
    //     0x10e9a68: b.ls            #0x10e9b34
    // 0x10e9a6c: LoadField: r2 = r0->field_4f
    //     0x10e9a6c: ldur            w2, [x0, #0x4f]
    // 0x10e9a70: DecompressPointer r2
    //     0x10e9a70: add             x2, x2, HEAP, lsl #32
    // 0x10e9a74: stur            x2, [fp, #-8]
    // 0x10e9a78: r1 = 1
    //     0x10e9a78: mov             x1, #1
    // 0x10e9a7c: r0 = AllocateContext()
    //     0x10e9a7c: bl              #0x13de838  ; AllocateContextStub
    // 0x10e9a80: mov             x3, x0
    // 0x10e9a84: ldur            x0, [fp, #-8]
    // 0x10e9a88: stur            x3, [fp, #-0x28]
    // 0x10e9a8c: StoreField: r3->field_f = r0
    //     0x10e9a8c: stur            w0, [x3, #0xf]
    // 0x10e9a90: cmp             w0, NULL
    // 0x10e9a94: b.eq            #0x10e9b24
    // 0x10e9a98: LoadField: r4 = r0->field_7
    //     0x10e9a98: ldur            w4, [x0, #7]
    // 0x10e9a9c: DecompressPointer r4
    //     0x10e9a9c: add             x4, x4, HEAP, lsl #32
    // 0x10e9aa0: stur            x4, [fp, #-0x20]
    // 0x10e9aa4: cmp             w4, NULL
    // 0x10e9aa8: b.eq            #0x10e9b3c
    // 0x10e9aac: mov             x0, x4
    // 0x10e9ab0: r2 = Null
    //     0x10e9ab0: mov             x2, NULL
    // 0x10e9ab4: r1 = Null
    //     0x10e9ab4: mov             x1, NULL
    // 0x10e9ab8: r4 = LoadClassIdInstr(r0)
    //     0x10e9ab8: ldur            x4, [x0, #-1]
    //     0x10e9abc: ubfx            x4, x4, #0xc, #0x14
    // 0x10e9ac0: r17 = -4190
    //     0x10e9ac0: mov             x17, #-0x105e
    // 0x10e9ac4: add             x4, x4, x17
    // 0x10e9ac8: cmp             x4, #0x17
    // 0x10e9acc: b.ls            #0x10e9ae4
    // 0x10e9ad0: r8 = BoxParentData
    //     0x10e9ad0: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0x10e9ad4: ldr             x8, [x8, #0x5e8]
    // 0x10e9ad8: r3 = Null
    //     0x10e9ad8: add             x3, PP, #0x81, lsl #12  ; [pp+0x81d08] Null
    //     0x10e9adc: ldr             x3, [x3, #0xd08]
    // 0x10e9ae0: r0 = DefaultTypeTest()
    //     0x10e9ae0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10e9ae4: ldur            x0, [fp, #-0x20]
    // 0x10e9ae8: LoadField: r3 = r0->field_7
    //     0x10e9ae8: ldur            w3, [x0, #7]
    // 0x10e9aec: DecompressPointer r3
    //     0x10e9aec: add             x3, x3, HEAP, lsl #32
    // 0x10e9af0: ldur            x2, [fp, #-0x28]
    // 0x10e9af4: stur            x3, [fp, #-8]
    // 0x10e9af8: r1 = Function '<anonymous closure>':.
    //     0x10e9af8: add             x1, PP, #0x81, lsl #12  ; [pp+0x81d18] AnonymousClosure: (0x10e9b40), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x10e9a40)
    //     0x10e9afc: ldr             x1, [x1, #0xd18]
    // 0x10e9b00: r0 = AllocateClosure()
    //     0x10e9b00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e9b04: ldur            x1, [fp, #-0x10]
    // 0x10e9b08: mov             x2, x0
    // 0x10e9b0c: ldur            x3, [fp, #-8]
    // 0x10e9b10: ldur            x5, [fp, #-0x18]
    // 0x10e9b14: r0 = addWithPaintOffset()
    //     0x10e9b14: bl              #0xaf9d3c  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x10e9b18: LeaveFrame
    //     0x10e9b18: mov             SP, fp
    //     0x10e9b1c: ldp             fp, lr, [SP], #0x10
    // 0x10e9b20: ret
    //     0x10e9b20: ret             
    // 0x10e9b24: r0 = false
    //     0x10e9b24: add             x0, NULL, #0x30  ; false
    // 0x10e9b28: LeaveFrame
    //     0x10e9b28: mov             SP, fp
    //     0x10e9b2c: ldp             fp, lr, [SP], #0x10
    // 0x10e9b30: ret
    //     0x10e9b30: ret             
    // 0x10e9b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e9b34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e9b38: b               #0x10e9a6c
    // 0x10e9b3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e9b3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult, Offset) {
    // ** addr: 0x10e9b40, size: 0x6c
    // 0x10e9b40: EnterFrame
    //     0x10e9b40: stp             fp, lr, [SP, #-0x10]!
    //     0x10e9b44: mov             fp, SP
    // 0x10e9b48: ldr             x0, [fp, #0x20]
    // 0x10e9b4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e9b4c: ldur            w1, [x0, #0x17]
    // 0x10e9b50: DecompressPointer r1
    //     0x10e9b50: add             x1, x1, HEAP, lsl #32
    // 0x10e9b54: CheckStackOverflow
    //     0x10e9b54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e9b58: cmp             SP, x16
    //     0x10e9b5c: b.ls            #0x10e9ba4
    // 0x10e9b60: LoadField: r0 = r1->field_f
    //     0x10e9b60: ldur            w0, [x1, #0xf]
    // 0x10e9b64: DecompressPointer r0
    //     0x10e9b64: add             x0, x0, HEAP, lsl #32
    // 0x10e9b68: r1 = LoadClassIdInstr(r0)
    //     0x10e9b68: ldur            x1, [x0, #-1]
    //     0x10e9b6c: ubfx            x1, x1, #0xc, #0x14
    // 0x10e9b70: mov             x16, x0
    // 0x10e9b74: mov             x0, x1
    // 0x10e9b78: mov             x1, x16
    // 0x10e9b7c: ldr             x2, [fp, #0x18]
    // 0x10e9b80: ldr             x3, [fp, #0x10]
    // 0x10e9b84: r0 = GDT[cid_x0 + 0x13d77]()
    //     0x10e9b84: mov             x17, #0x3d77
    //     0x10e9b88: movk            x17, #1, lsl #16
    //     0x10e9b8c: add             lr, x0, x17
    //     0x10e9b90: ldr             lr, [x21, lr, lsl #3]
    //     0x10e9b94: blr             lr
    // 0x10e9b98: LeaveFrame
    //     0x10e9b98: mov             SP, fp
    //     0x10e9b9c: ldp             fp, lr, [SP], #0x10
    // 0x10e9ba0: ret
    //     0x10e9ba0: ret             
    // 0x10e9ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e9ba4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e9ba8: b               #0x10e9b60
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efe14, size: 0x24
    // 0x10efe14: EnterFrame
    //     0x10efe14: stp             fp, lr, [SP, #-0x10]!
    //     0x10efe18: mov             fp, SP
    // 0x10efe1c: ldr             x2, [fp, #0x10]
    // 0x10efe20: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efe20: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2938] AnonymousClosure: (0x10efe38), in [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMinIntrinsicHeight (0xb23590)
    //     0x10efe24: ldr             x1, [x1, #0x938]
    // 0x10efe28: r0 = AllocateClosure()
    //     0x10efe28: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efe2c: LeaveFrame
    //     0x10efe2c: mov             SP, fp
    //     0x10efe30: ldp             fp, lr, [SP], #0x10
    // 0x10efe34: ret
    //     0x10efe34: ret             
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x10efe38, size: 0x78
    // 0x10efe38: EnterFrame
    //     0x10efe38: stp             fp, lr, [SP, #-0x10]!
    //     0x10efe3c: mov             fp, SP
    // 0x10efe40: ldr             x0, [fp, #0x18]
    // 0x10efe44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10efe44: ldur            w1, [x0, #0x17]
    // 0x10efe48: DecompressPointer r1
    //     0x10efe48: add             x1, x1, HEAP, lsl #32
    // 0x10efe4c: CheckStackOverflow
    //     0x10efe4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10efe50: cmp             SP, x16
    //     0x10efe54: b.ls            #0x10efe98
    // 0x10efe58: ldr             x2, [fp, #0x10]
    // 0x10efe5c: r0 = computeMinIntrinsicHeight()
    //     0x10efe5c: bl              #0xb23590  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMinIntrinsicHeight
    // 0x10efe60: r0 = inline_Allocate_Double()
    //     0x10efe60: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x10efe64: add             x0, x0, #0x10
    //     0x10efe68: cmp             x1, x0
    //     0x10efe6c: b.ls            #0x10efea0
    //     0x10efe70: str             x0, [THR, #0x60]  ; THR::top
    //     0x10efe74: sub             x0, x0, #0xf
    //     0x10efe78: mov             x1, #0xe19c
    //     0x10efe7c: movk            x1, #3, lsl #16
    //     0x10efe80: stur            x1, [x0, #-1]
    // 0x10efe84: dmb             ishst
    // 0x10efe88: StoreField: r0->field_7 = d0
    //     0x10efe88: stur            d0, [x0, #7]
    // 0x10efe8c: LeaveFrame
    //     0x10efe8c: mov             SP, fp
    //     0x10efe90: ldp             fp, lr, [SP], #0x10
    // 0x10efe94: ret
    //     0x10efe94: ret             
    // 0x10efe98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10efe98: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10efe9c: b               #0x10efe58
    // 0x10efea0: SaveReg d0
    //     0x10efea0: str             q0, [SP, #-0x10]!
    // 0x10efea4: r0 = AllocateDouble()
    //     0x10efea4: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10efea8: RestoreReg d0
    //     0x10efea8: ldr             q0, [SP], #0x10
    // 0x10efeac: b               #0x10efe88
  }
}

// class id: 4876, size: 0x58, field offset: 0x54
class RenderCustomSingleChildLayoutBox extends RenderShiftedBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb17420, size: 0x24
    // 0xb17420: EnterFrame
    //     0xb17420: stp             fp, lr, [SP, #-0x10]!
    //     0xb17424: mov             fp, SP
    // 0xb17428: ldr             x2, [fp, #0x10]
    // 0xb1742c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1742c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2880] AnonymousClosure: (0xb17444), in [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMaxIntrinsicWidth (0xb2d504)
    //     0xb17430: ldr             x1, [x1, #0x880]
    // 0xb17434: r0 = AllocateClosure()
    //     0xb17434: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb17438: LeaveFrame
    //     0xb17438: mov             SP, fp
    //     0xb1743c: ldp             fp, lr, [SP], #0x10
    // 0xb17440: ret
    //     0xb17440: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb17444, size: 0x78
    // 0xb17444: EnterFrame
    //     0xb17444: stp             fp, lr, [SP, #-0x10]!
    //     0xb17448: mov             fp, SP
    // 0xb1744c: ldr             x0, [fp, #0x18]
    // 0xb17450: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb17450: ldur            w1, [x0, #0x17]
    // 0xb17454: DecompressPointer r1
    //     0xb17454: add             x1, x1, HEAP, lsl #32
    // 0xb17458: CheckStackOverflow
    //     0xb17458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1745c: cmp             SP, x16
    //     0xb17460: b.ls            #0xb174a4
    // 0xb17464: ldr             x2, [fp, #0x10]
    // 0xb17468: r0 = computeMaxIntrinsicWidth()
    //     0xb17468: bl              #0xb2d504  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMaxIntrinsicWidth
    // 0xb1746c: r0 = inline_Allocate_Double()
    //     0xb1746c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb17470: add             x0, x0, #0x10
    //     0xb17474: cmp             x1, x0
    //     0xb17478: b.ls            #0xb174ac
    //     0xb1747c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb17480: sub             x0, x0, #0xf
    //     0xb17484: mov             x1, #0xe19c
    //     0xb17488: movk            x1, #3, lsl #16
    //     0xb1748c: stur            x1, [x0, #-1]
    // 0xb17490: dmb             ishst
    // 0xb17494: StoreField: r0->field_7 = d0
    //     0xb17494: stur            d0, [x0, #7]
    // 0xb17498: LeaveFrame
    //     0xb17498: mov             SP, fp
    //     0xb1749c: ldp             fp, lr, [SP], #0x10
    // 0xb174a0: ret
    //     0xb174a0: ret             
    // 0xb174a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb174a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb174a8: b               #0xb17464
    // 0xb174ac: SaveReg d0
    //     0xb174ac: str             q0, [SP, #-0x10]!
    // 0xb174b0: r0 = AllocateDouble()
    //     0xb174b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb174b4: RestoreReg d0
    //     0xb174b4: ldr             q0, [SP], #0x10
    // 0xb174b8: b               #0xb17494
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2a0d8, size: 0xd0
    // 0xb2a0d8: EnterFrame
    //     0xb2a0d8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a0dc: mov             fp, SP
    // 0xb2a0e0: AllocStack(0x18)
    //     0xb2a0e0: sub             SP, SP, #0x18
    // 0xb2a0e4: d0 = inf
    //     0xb2a0e4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2a0e8: stur            x1, [fp, #-8]
    // 0xb2a0ec: CheckStackOverflow
    //     0xb2a0ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a0f0: cmp             SP, x16
    //     0xb2a0f4: b.ls            #0xb2a1a0
    // 0xb2a0f8: LoadField: d1 = r2->field_7
    //     0xb2a0f8: ldur            d1, [x2, #7]
    // 0xb2a0fc: stur            d1, [fp, #-0x18]
    // 0xb2a100: fcmp            d1, d0
    // 0xb2a104: b.eq            #0xb2a110
    // 0xb2a108: mov             v2.16b, v1.16b
    // 0xb2a10c: b               #0xb2a114
    // 0xb2a110: d2 = 0.000000
    //     0xb2a110: eor             v2.16b, v2.16b, v2.16b
    // 0xb2a114: stur            d2, [fp, #-0x10]
    // 0xb2a118: r0 = BoxConstraints()
    //     0xb2a118: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2a11c: ldur            d0, [fp, #-0x10]
    // 0xb2a120: StoreField: r0->field_7 = d0
    //     0xb2a120: stur            d0, [x0, #7]
    // 0xb2a124: ldur            d1, [fp, #-0x18]
    // 0xb2a128: d0 = inf
    //     0xb2a128: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2a12c: fcmp            d1, d0
    // 0xb2a130: b.ne            #0xb2a138
    // 0xb2a134: d1 = inf
    //     0xb2a134: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2a138: StoreField: r0->field_f = d1
    //     0xb2a138: stur            d1, [x0, #0xf]
    // 0xb2a13c: fcmp            d0, d0
    // 0xb2a140: b.eq            #0xb2a14c
    // 0xb2a144: d1 = inf
    //     0xb2a144: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2a148: b               #0xb2a150
    // 0xb2a14c: d1 = 0.000000
    //     0xb2a14c: eor             v1.16b, v1.16b, v1.16b
    // 0xb2a150: ArrayStore: r0[0] = d1  ; List_8
    //     0xb2a150: stur            d1, [x0, #0x17]
    // 0xb2a154: StoreField: r0->field_1f = d0
    //     0xb2a154: stur            d0, [x0, #0x1f]
    // 0xb2a158: ldur            x1, [fp, #-8]
    // 0xb2a15c: mov             x2, x0
    // 0xb2a160: r0 = _getSize()
    //     0xb2a160: bl              #0xb2a220  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0xb2a164: LoadField: d0 = r0->field_f
    //     0xb2a164: ldur            d0, [x0, #0xf]
    // 0xb2a168: mov             x0, v0.d[0]
    // 0xb2a16c: and             x0, x0, #0x7fffffffffffffff
    // 0xb2a170: r17 = 9218868437227405312
    //     0xb2a170: mov             x17, #0x7ff0000000000000
    // 0xb2a174: cmp             x0, x17
    // 0xb2a178: b.eq            #0xb2a190
    // 0xb2a17c: fcmp            d0, d0
    // 0xb2a180: b.vs            #0xb2a190
    // 0xb2a184: LeaveFrame
    //     0xb2a184: mov             SP, fp
    //     0xb2a188: ldp             fp, lr, [SP], #0x10
    // 0xb2a18c: ret
    //     0xb2a18c: ret             
    // 0xb2a190: d0 = 0.000000
    //     0xb2a190: eor             v0.16b, v0.16b, v0.16b
    // 0xb2a194: LeaveFrame
    //     0xb2a194: mov             SP, fp
    //     0xb2a198: ldp             fp, lr, [SP], #0x10
    // 0xb2a19c: ret
    //     0xb2a19c: ret             
    // 0xb2a1a0: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2a1a0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2a1a4: b               #0xb2a0f8
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2a1a8, size: 0x78
    // 0xb2a1a8: EnterFrame
    //     0xb2a1a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a1ac: mov             fp, SP
    // 0xb2a1b0: ldr             x0, [fp, #0x18]
    // 0xb2a1b4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2a1b4: ldur            w1, [x0, #0x17]
    // 0xb2a1b8: DecompressPointer r1
    //     0xb2a1b8: add             x1, x1, HEAP, lsl #32
    // 0xb2a1bc: CheckStackOverflow
    //     0xb2a1bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a1c0: cmp             SP, x16
    //     0xb2a1c4: b.ls            #0xb2a208
    // 0xb2a1c8: ldr             x2, [fp, #0x10]
    // 0xb2a1cc: r0 = computeMaxIntrinsicHeight()
    //     0xb2a1cc: bl              #0xb2a0d8  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMaxIntrinsicHeight
    // 0xb2a1d0: r0 = inline_Allocate_Double()
    //     0xb2a1d0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2a1d4: add             x0, x0, #0x10
    //     0xb2a1d8: cmp             x1, x0
    //     0xb2a1dc: b.ls            #0xb2a210
    //     0xb2a1e0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2a1e4: sub             x0, x0, #0xf
    //     0xb2a1e8: mov             x1, #0xe19c
    //     0xb2a1ec: movk            x1, #3, lsl #16
    //     0xb2a1f0: stur            x1, [x0, #-1]
    // 0xb2a1f4: dmb             ishst
    // 0xb2a1f8: StoreField: r0->field_7 = d0
    //     0xb2a1f8: stur            d0, [x0, #7]
    // 0xb2a1fc: LeaveFrame
    //     0xb2a1fc: mov             SP, fp
    //     0xb2a200: ldp             fp, lr, [SP], #0x10
    // 0xb2a204: ret
    //     0xb2a204: ret             
    // 0xb2a208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a208: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a20c: b               #0xb2a1c8
    // 0xb2a210: SaveReg d0
    //     0xb2a210: str             q0, [SP, #-0x10]!
    // 0xb2a214: r0 = AllocateDouble()
    //     0xb2a214: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2a218: RestoreReg d0
    //     0xb2a218: ldr             q0, [SP], #0x10
    // 0xb2a21c: b               #0xb2a1f8
  }
  _ _getSize(/* No info */) {
    // ** addr: 0xb2a220, size: 0x70
    // 0xb2a220: EnterFrame
    //     0xb2a220: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a224: mov             fp, SP
    // 0xb2a228: AllocStack(0x8)
    //     0xb2a228: sub             SP, SP, #8
    // 0xb2a22c: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xb2a22c: mov             x3, x2
    //     0xb2a230: stur            x2, [fp, #-8]
    // 0xb2a234: CheckStackOverflow
    //     0xb2a234: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a238: cmp             SP, x16
    //     0xb2a23c: b.ls            #0xb2a288
    // 0xb2a240: LoadField: r0 = r1->field_53
    //     0xb2a240: ldur            w0, [x1, #0x53]
    // 0xb2a244: DecompressPointer r0
    //     0xb2a244: add             x0, x0, HEAP, lsl #32
    // 0xb2a248: r1 = LoadClassIdInstr(r0)
    //     0xb2a248: ldur            x1, [x0, #-1]
    //     0xb2a24c: ubfx            x1, x1, #0xc, #0x14
    // 0xb2a250: mov             x16, x0
    // 0xb2a254: mov             x0, x1
    // 0xb2a258: mov             x1, x16
    // 0xb2a25c: mov             x2, x3
    // 0xb2a260: r0 = GDT[cid_x0 + 0x7927]()
    //     0xb2a260: mov             x17, #0x7927
    //     0xb2a264: add             lr, x0, x17
    //     0xb2a268: ldr             lr, [x21, lr, lsl #3]
    //     0xb2a26c: blr             lr
    // 0xb2a270: ldur            x1, [fp, #-8]
    // 0xb2a274: mov             x2, x0
    // 0xb2a278: r0 = constrain()
    //     0xb2a278: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb2a27c: LeaveFrame
    //     0xb2a27c: mov             SP, fp
    //     0xb2a280: ldp             fp, lr, [SP], #0x10
    // 0xb2a284: ret
    //     0xb2a284: ret             
    // 0xb2a288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a288: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a28c: b               #0xb2a240
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2d504, size: 0xd8
    // 0xb2d504: EnterFrame
    //     0xb2d504: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d508: mov             fp, SP
    // 0xb2d50c: AllocStack(0x18)
    //     0xb2d50c: sub             SP, SP, #0x18
    // 0xb2d510: d0 = inf
    //     0xb2d510: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2d514: stur            x1, [fp, #-8]
    // 0xb2d518: stur            x2, [fp, #-0x10]
    // 0xb2d51c: CheckStackOverflow
    //     0xb2d51c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d520: cmp             SP, x16
    //     0xb2d524: b.ls            #0xb2d5d4
    // 0xb2d528: fcmp            d0, d0
    // 0xb2d52c: b.eq            #0xb2d538
    // 0xb2d530: d1 = inf
    //     0xb2d530: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2d534: b               #0xb2d53c
    // 0xb2d538: d1 = 0.000000
    //     0xb2d538: eor             v1.16b, v1.16b, v1.16b
    // 0xb2d53c: stur            d1, [fp, #-0x18]
    // 0xb2d540: r0 = BoxConstraints()
    //     0xb2d540: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2d544: ldur            d0, [fp, #-0x18]
    // 0xb2d548: StoreField: r0->field_7 = d0
    //     0xb2d548: stur            d0, [x0, #7]
    // 0xb2d54c: d0 = inf
    //     0xb2d54c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2d550: StoreField: r0->field_f = d0
    //     0xb2d550: stur            d0, [x0, #0xf]
    // 0xb2d554: ldur            x1, [fp, #-0x10]
    // 0xb2d558: LoadField: d1 = r1->field_7
    //     0xb2d558: ldur            d1, [x1, #7]
    // 0xb2d55c: fcmp            d1, d0
    // 0xb2d560: b.eq            #0xb2d56c
    // 0xb2d564: mov             v2.16b, v1.16b
    // 0xb2d568: b               #0xb2d570
    // 0xb2d56c: d2 = 0.000000
    //     0xb2d56c: eor             v2.16b, v2.16b, v2.16b
    // 0xb2d570: ArrayStore: r0[0] = d2  ; List_8
    //     0xb2d570: stur            d2, [x0, #0x17]
    // 0xb2d574: fcmp            d1, d0
    // 0xb2d578: b.eq            #0xb2d584
    // 0xb2d57c: mov             v0.16b, v1.16b
    // 0xb2d580: b               #0xb2d588
    // 0xb2d584: d0 = inf
    //     0xb2d584: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2d588: StoreField: r0->field_1f = d0
    //     0xb2d588: stur            d0, [x0, #0x1f]
    // 0xb2d58c: ldur            x1, [fp, #-8]
    // 0xb2d590: mov             x2, x0
    // 0xb2d594: r0 = _getSize()
    //     0xb2d594: bl              #0xb2a220  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0xb2d598: LoadField: d0 = r0->field_7
    //     0xb2d598: ldur            d0, [x0, #7]
    // 0xb2d59c: mov             x0, v0.d[0]
    // 0xb2d5a0: and             x0, x0, #0x7fffffffffffffff
    // 0xb2d5a4: r17 = 9218868437227405312
    //     0xb2d5a4: mov             x17, #0x7ff0000000000000
    // 0xb2d5a8: cmp             x0, x17
    // 0xb2d5ac: b.eq            #0xb2d5c4
    // 0xb2d5b0: fcmp            d0, d0
    // 0xb2d5b4: b.vs            #0xb2d5c4
    // 0xb2d5b8: LeaveFrame
    //     0xb2d5b8: mov             SP, fp
    //     0xb2d5bc: ldp             fp, lr, [SP], #0x10
    // 0xb2d5c0: ret
    //     0xb2d5c0: ret             
    // 0xb2d5c4: d0 = 0.000000
    //     0xb2d5c4: eor             v0.16b, v0.16b, v0.16b
    // 0xb2d5c8: LeaveFrame
    //     0xb2d5c8: mov             SP, fp
    //     0xb2d5cc: ldp             fp, lr, [SP], #0x10
    // 0xb2d5d0: ret
    //     0xb2d5d0: ret             
    // 0xb2d5d4: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2d5d4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2d5d8: b               #0xb2d528
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2d5dc, size: 0x78
    // 0xb2d5dc: EnterFrame
    //     0xb2d5dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d5e0: mov             fp, SP
    // 0xb2d5e4: ldr             x0, [fp, #0x18]
    // 0xb2d5e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2d5e8: ldur            w1, [x0, #0x17]
    // 0xb2d5ec: DecompressPointer r1
    //     0xb2d5ec: add             x1, x1, HEAP, lsl #32
    // 0xb2d5f0: CheckStackOverflow
    //     0xb2d5f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d5f4: cmp             SP, x16
    //     0xb2d5f8: b.ls            #0xb2d63c
    // 0xb2d5fc: ldr             x2, [fp, #0x10]
    // 0xb2d600: r0 = computeMaxIntrinsicWidth()
    //     0xb2d600: bl              #0xb2d504  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMaxIntrinsicWidth
    // 0xb2d604: r0 = inline_Allocate_Double()
    //     0xb2d604: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2d608: add             x0, x0, #0x10
    //     0xb2d60c: cmp             x1, x0
    //     0xb2d610: b.ls            #0xb2d644
    //     0xb2d614: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2d618: sub             x0, x0, #0xf
    //     0xb2d61c: mov             x1, #0xe19c
    //     0xb2d620: movk            x1, #3, lsl #16
    //     0xb2d624: stur            x1, [x0, #-1]
    // 0xb2d628: dmb             ishst
    // 0xb2d62c: StoreField: r0->field_7 = d0
    //     0xb2d62c: stur            d0, [x0, #7]
    // 0xb2d630: LeaveFrame
    //     0xb2d630: mov             SP, fp
    //     0xb2d634: ldp             fp, lr, [SP], #0x10
    // 0xb2d638: ret
    //     0xb2d638: ret             
    // 0xb2d63c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d63c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d640: b               #0xb2d5fc
    // 0xb2d644: SaveReg d0
    //     0xb2d644: str             q0, [SP, #-0x10]!
    // 0xb2d648: r0 = AllocateDouble()
    //     0xb2d648: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d64c: RestoreReg d0
    //     0xb2d64c: ldr             q0, [SP], #0x10
    // 0xb2d650: b               #0xb2d62c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4da70, size: 0x2c
    // 0xb4da70: EnterFrame
    //     0xb4da70: stp             fp, lr, [SP, #-0x10]!
    //     0xb4da74: mov             fp, SP
    // 0xb4da78: CheckStackOverflow
    //     0xb4da78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4da7c: cmp             SP, x16
    //     0xb4da80: b.ls            #0xb4da94
    // 0xb4da84: r0 = _getSize()
    //     0xb4da84: bl              #0xb2a220  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0xb4da88: LeaveFrame
    //     0xb4da88: mov             SP, fp
    //     0xb4da8c: ldp             fp, lr, [SP], #0x10
    // 0xb4da90: ret
    //     0xb4da90: ret             
    // 0xb4da94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4da94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4da98: b               #0xb4da84
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb583e4, size: 0x24
    // 0xb583e4: EnterFrame
    //     0xb583e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb583e8: mov             fp, SP
    // 0xb583ec: ldr             x2, [fp, #0x10]
    // 0xb583f0: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb583f0: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2878] AnonymousClosure: (0xb2d5dc), in [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMaxIntrinsicWidth (0xb2d504)
    //     0xb583f4: ldr             x1, [x1, #0x878]
    // 0xb583f8: r0 = AllocateClosure()
    //     0xb583f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb583fc: LeaveFrame
    //     0xb583fc: mov             SP, fp
    //     0xb58400: ldp             fp, lr, [SP], #0x10
    // 0xb58404: ret
    //     0xb58404: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e56c, size: 0x24
    // 0xb5e56c: EnterFrame
    //     0xb5e56c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e570: mov             fp, SP
    // 0xb5e574: ldr             x2, [fp, #0x10]
    // 0xb5e578: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e578: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2868] AnonymousClosure: (0xb2a1a8), in [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMaxIntrinsicHeight (0xb2a0d8)
    //     0xb5e57c: ldr             x1, [x1, #0x868]
    // 0xb5e580: r0 = AllocateClosure()
    //     0xb5e580: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e584: LeaveFrame
    //     0xb5e584: mov             SP, fp
    //     0xb5e588: ldp             fp, lr, [SP], #0x10
    // 0xb5e58c: ret
    //     0xb5e58c: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb6109c, size: 0x1bc
    // 0xb6109c: EnterFrame
    //     0xb6109c: stp             fp, lr, [SP, #-0x10]!
    //     0xb610a0: mov             fp, SP
    // 0xb610a4: AllocStack(0x30)
    //     0xb610a4: sub             SP, SP, #0x30
    // 0xb610a8: SetupParameters(RenderCustomSingleChildLayoutBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb610a8: mov             x5, x1
    //     0xb610ac: mov             x4, x2
    //     0xb610b0: stur            x1, [fp, #-8]
    //     0xb610b4: stur            x2, [fp, #-0x10]
    //     0xb610b8: stur            x3, [fp, #-0x18]
    // 0xb610bc: CheckStackOverflow
    //     0xb610bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb610c0: cmp             SP, x16
    //     0xb610c4: b.ls            #0xb61240
    // 0xb610c8: mov             x0, x4
    // 0xb610cc: r2 = Null
    //     0xb610cc: mov             x2, NULL
    // 0xb610d0: r1 = Null
    //     0xb610d0: mov             x1, NULL
    // 0xb610d4: r4 = 60
    //     0xb610d4: mov             x4, #0x3c
    // 0xb610d8: branchIfSmi(r0, 0xb610e4)
    //     0xb610d8: tbz             w0, #0, #0xb610e4
    // 0xb610dc: r4 = LoadClassIdInstr(r0)
    //     0xb610dc: ldur            x4, [x0, #-1]
    //     0xb610e0: ubfx            x4, x4, #0xc, #0x14
    // 0xb610e4: sub             x4, x4, #0xb46
    // 0xb610e8: cmp             x4, #1
    // 0xb610ec: b.ls            #0xb61100
    // 0xb610f0: r8 = BoxConstraints
    //     0xb610f0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb610f4: r3 = Null
    //     0xb610f4: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa28b8] Null
    //     0xb610f8: ldr             x3, [x3, #0x8b8]
    // 0xb610fc: r0 = BoxConstraints()
    //     0xb610fc: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb61100: ldur            x3, [fp, #-8]
    // 0xb61104: LoadField: r4 = r3->field_4f
    //     0xb61104: ldur            w4, [x3, #0x4f]
    // 0xb61108: DecompressPointer r4
    //     0xb61108: add             x4, x4, HEAP, lsl #32
    // 0xb6110c: stur            x4, [fp, #-0x20]
    // 0xb61110: cmp             w4, NULL
    // 0xb61114: b.ne            #0xb61128
    // 0xb61118: r0 = Null
    //     0xb61118: mov             x0, NULL
    // 0xb6111c: LeaveFrame
    //     0xb6111c: mov             SP, fp
    //     0xb61120: ldp             fp, lr, [SP], #0x10
    // 0xb61124: ret
    //     0xb61124: ret             
    // 0xb61128: LoadField: r1 = r3->field_53
    //     0xb61128: ldur            w1, [x3, #0x53]
    // 0xb6112c: DecompressPointer r1
    //     0xb6112c: add             x1, x1, HEAP, lsl #32
    // 0xb61130: r0 = LoadClassIdInstr(r1)
    //     0xb61130: ldur            x0, [x1, #-1]
    //     0xb61134: ubfx            x0, x0, #0xc, #0x14
    // 0xb61138: ldur            x2, [fp, #-0x10]
    // 0xb6113c: r0 = GDT[cid_x0 + -0xdab]()
    //     0xb6113c: sub             lr, x0, #0xdab
    //     0xb61140: ldr             lr, [x21, lr, lsl #3]
    //     0xb61144: blr             lr
    // 0xb61148: ldur            x1, [fp, #-0x20]
    // 0xb6114c: mov             x2, x0
    // 0xb61150: ldur            x3, [fp, #-0x18]
    // 0xb61154: stur            x0, [fp, #-0x18]
    // 0xb61158: r0 = getDryBaseline()
    //     0xb61158: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb6115c: stur            x0, [fp, #-0x30]
    // 0xb61160: cmp             w0, NULL
    // 0xb61164: b.ne            #0xb61178
    // 0xb61168: r0 = Null
    //     0xb61168: mov             x0, NULL
    // 0xb6116c: LeaveFrame
    //     0xb6116c: mov             SP, fp
    //     0xb61170: ldp             fp, lr, [SP], #0x10
    // 0xb61174: ret
    //     0xb61174: ret             
    // 0xb61178: ldur            x1, [fp, #-8]
    // 0xb6117c: ldur            x3, [fp, #-0x18]
    // 0xb61180: LoadField: r4 = r1->field_53
    //     0xb61180: ldur            w4, [x1, #0x53]
    // 0xb61184: DecompressPointer r4
    //     0xb61184: add             x4, x4, HEAP, lsl #32
    // 0xb61188: ldur            x2, [fp, #-0x10]
    // 0xb6118c: stur            x4, [fp, #-0x28]
    // 0xb61190: r0 = _getSize()
    //     0xb61190: bl              #0xb2a220  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0xb61194: ldur            x1, [fp, #-0x18]
    // 0xb61198: stur            x0, [fp, #-8]
    // 0xb6119c: LoadField: d0 = r1->field_7
    //     0xb6119c: ldur            d0, [x1, #7]
    // 0xb611a0: LoadField: d1 = r1->field_f
    //     0xb611a0: ldur            d1, [x1, #0xf]
    // 0xb611a4: fcmp            d0, d1
    // 0xb611a8: b.lt            #0xb611c8
    // 0xb611ac: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xb611ac: ldur            d0, [x1, #0x17]
    // 0xb611b0: LoadField: d1 = r1->field_1f
    //     0xb611b0: ldur            d1, [x1, #0x1f]
    // 0xb611b4: fcmp            d0, d1
    // 0xb611b8: b.lt            #0xb611c8
    // 0xb611bc: r0 = smallest()
    //     0xb611bc: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb611c0: mov             x3, x0
    // 0xb611c4: b               #0xb611d8
    // 0xb611c8: mov             x2, x1
    // 0xb611cc: ldur            x1, [fp, #-0x20]
    // 0xb611d0: r0 = getDryLayout()
    //     0xb611d0: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb611d4: mov             x3, x0
    // 0xb611d8: ldur            x4, [fp, #-0x30]
    // 0xb611dc: ldur            x1, [fp, #-0x28]
    // 0xb611e0: r0 = LoadClassIdInstr(r1)
    //     0xb611e0: ldur            x0, [x1, #-1]
    //     0xb611e4: ubfx            x0, x0, #0xc, #0x14
    // 0xb611e8: ldur            x2, [fp, #-8]
    // 0xb611ec: r0 = GDT[cid_x0 + -0xe0d]()
    //     0xb611ec: sub             lr, x0, #0xe0d
    //     0xb611f0: ldr             lr, [x21, lr, lsl #3]
    //     0xb611f4: blr             lr
    // 0xb611f8: LoadField: d0 = r0->field_f
    //     0xb611f8: ldur            d0, [x0, #0xf]
    // 0xb611fc: ldur            x1, [fp, #-0x30]
    // 0xb61200: LoadField: d1 = r1->field_7
    //     0xb61200: ldur            d1, [x1, #7]
    // 0xb61204: fadd            d2, d1, d0
    // 0xb61208: r0 = inline_Allocate_Double()
    //     0xb61208: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb6120c: add             x0, x0, #0x10
    //     0xb61210: cmp             x1, x0
    //     0xb61214: b.ls            #0xb61248
    //     0xb61218: str             x0, [THR, #0x60]  ; THR::top
    //     0xb6121c: sub             x0, x0, #0xf
    //     0xb61220: mov             x1, #0xe19c
    //     0xb61224: movk            x1, #3, lsl #16
    //     0xb61228: stur            x1, [x0, #-1]
    // 0xb6122c: dmb             ishst
    // 0xb61230: StoreField: r0->field_7 = d2
    //     0xb61230: stur            d2, [x0, #7]
    // 0xb61234: LeaveFrame
    //     0xb61234: mov             SP, fp
    //     0xb61238: ldp             fp, lr, [SP], #0x10
    // 0xb6123c: ret
    //     0xb6123c: ret             
    // 0xb61240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb61240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb61244: b               #0xb610c8
    // 0xb61248: SaveReg d2
    //     0xb61248: str             q2, [SP, #-0x10]!
    // 0xb6124c: r0 = AllocateDouble()
    //     0xb6124c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61250: RestoreReg d2
    //     0xb61250: ldr             q2, [SP], #0x10
    // 0xb61254: b               #0xb61230
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbd124, size: 0x2f8
    // 0xbbd124: EnterFrame
    //     0xbbd124: stp             fp, lr, [SP, #-0x10]!
    //     0xbbd128: mov             fp, SP
    // 0xbbd12c: AllocStack(0x40)
    //     0xbbd12c: sub             SP, SP, #0x40
    // 0xbbd130: SetupParameters(RenderCustomSingleChildLayoutBox this /* r1 => r3, fp-0x10 */)
    //     0xbbd130: mov             x3, x1
    //     0xbbd134: stur            x1, [fp, #-0x10]
    // 0xbbd138: CheckStackOverflow
    //     0xbbd138: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbd13c: cmp             SP, x16
    //     0xbbd140: b.ls            #0xbbd404
    // 0xbbd144: LoadField: r4 = r3->field_27
    //     0xbbd144: ldur            w4, [x3, #0x27]
    // 0xbbd148: DecompressPointer r4
    //     0xbbd148: add             x4, x4, HEAP, lsl #32
    // 0xbbd14c: stur            x4, [fp, #-8]
    // 0xbbd150: cmp             w4, NULL
    // 0xbbd154: b.eq            #0xbbd3c8
    // 0xbbd158: mov             x0, x4
    // 0xbbd15c: r2 = Null
    //     0xbbd15c: mov             x2, NULL
    // 0xbbd160: r1 = Null
    //     0xbbd160: mov             x1, NULL
    // 0xbbd164: r4 = LoadClassIdInstr(r0)
    //     0xbbd164: ldur            x4, [x0, #-1]
    //     0xbbd168: ubfx            x4, x4, #0xc, #0x14
    // 0xbbd16c: sub             x4, x4, #0xb46
    // 0xbbd170: cmp             x4, #1
    // 0xbbd174: b.ls            #0xbbd188
    // 0xbbd178: r8 = BoxConstraints
    //     0xbbd178: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbd17c: r3 = Null
    //     0xbbd17c: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2888] Null
    //     0xbbd180: ldr             x3, [x3, #0x888]
    // 0xbbd184: r0 = BoxConstraints()
    //     0xbbd184: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbd188: ldur            x1, [fp, #-0x10]
    // 0xbbd18c: ldur            x2, [fp, #-8]
    // 0xbbd190: r0 = _getSize()
    //     0xbbd190: bl              #0xb2a220  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::_getSize
    // 0xbbd194: ldur            x3, [fp, #-0x10]
    // 0xbbd198: StoreField: r3->field_4b = r0
    //     0xbbd198: stur            w0, [x3, #0x4b]
    //     0xbbd19c: ldurb           w16, [x3, #-1]
    //     0xbbd1a0: ldurb           w17, [x0, #-1]
    //     0xbbd1a4: and             x16, x17, x16, lsr #2
    //     0xbbd1a8: tst             x16, HEAP, lsr #32
    //     0xbbd1ac: b.eq            #0xbbd1b4
    //     0xbbd1b0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbd1b4: LoadField: r0 = r3->field_4f
    //     0xbbd1b4: ldur            w0, [x3, #0x4f]
    // 0xbbd1b8: DecompressPointer r0
    //     0xbbd1b8: add             x0, x0, HEAP, lsl #32
    // 0xbbd1bc: cmp             w0, NULL
    // 0xbbd1c0: b.eq            #0xbbd3b8
    // 0xbbd1c4: LoadField: r4 = r3->field_53
    //     0xbbd1c4: ldur            w4, [x3, #0x53]
    // 0xbbd1c8: DecompressPointer r4
    //     0xbbd1c8: add             x4, x4, HEAP, lsl #32
    // 0xbbd1cc: stur            x4, [fp, #-0x18]
    // 0xbbd1d0: LoadField: r5 = r3->field_27
    //     0xbbd1d0: ldur            w5, [x3, #0x27]
    // 0xbbd1d4: DecompressPointer r5
    //     0xbbd1d4: add             x5, x5, HEAP, lsl #32
    // 0xbbd1d8: stur            x5, [fp, #-8]
    // 0xbbd1dc: cmp             w5, NULL
    // 0xbbd1e0: b.eq            #0xbbd3e4
    // 0xbbd1e4: mov             x0, x5
    // 0xbbd1e8: r2 = Null
    //     0xbbd1e8: mov             x2, NULL
    // 0xbbd1ec: r1 = Null
    //     0xbbd1ec: mov             x1, NULL
    // 0xbbd1f0: r4 = LoadClassIdInstr(r0)
    //     0xbbd1f0: ldur            x4, [x0, #-1]
    //     0xbbd1f4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbd1f8: sub             x4, x4, #0xb46
    // 0xbbd1fc: cmp             x4, #1
    // 0xbbd200: b.ls            #0xbbd214
    // 0xbbd204: r8 = BoxConstraints
    //     0xbbd204: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbd208: r3 = Null
    //     0xbbd208: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2898] Null
    //     0xbbd20c: ldr             x3, [x3, #0x898]
    // 0xbbd210: r0 = BoxConstraints()
    //     0xbbd210: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbd214: ldur            x1, [fp, #-0x18]
    // 0xbbd218: r0 = LoadClassIdInstr(r1)
    //     0xbbd218: ldur            x0, [x1, #-1]
    //     0xbbd21c: ubfx            x0, x0, #0xc, #0x14
    // 0xbbd220: ldur            x2, [fp, #-8]
    // 0xbbd224: r0 = GDT[cid_x0 + -0xdab]()
    //     0xbbd224: sub             lr, x0, #0xdab
    //     0xbbd228: ldr             lr, [x21, lr, lsl #3]
    //     0xbbd22c: blr             lr
    // 0xbbd230: mov             x4, x0
    // 0xbbd234: ldur            x3, [fp, #-0x10]
    // 0xbbd238: stur            x4, [fp, #-8]
    // 0xbbd23c: LoadField: r1 = r3->field_4f
    //     0xbbd23c: ldur            w1, [x3, #0x4f]
    // 0xbbd240: DecompressPointer r1
    //     0xbbd240: add             x1, x1, HEAP, lsl #32
    // 0xbbd244: cmp             w1, NULL
    // 0xbbd248: b.eq            #0xbbd40c
    // 0xbbd24c: LoadField: d0 = r4->field_7
    //     0xbbd24c: ldur            d0, [x4, #7]
    // 0xbbd250: stur            d0, [fp, #-0x38]
    // 0xbbd254: LoadField: d1 = r4->field_f
    //     0xbbd254: ldur            d1, [x4, #0xf]
    // 0xbbd258: stur            d1, [fp, #-0x30]
    // 0xbbd25c: fcmp            d0, d1
    // 0xbbd260: b.lt            #0xbbd280
    // 0xbbd264: ArrayLoad: d2 = r4[0]  ; List_8
    //     0xbbd264: ldur            d2, [x4, #0x17]
    // 0xbbd268: LoadField: d3 = r4->field_1f
    //     0xbbd268: ldur            d3, [x4, #0x1f]
    // 0xbbd26c: fcmp            d2, d3
    // 0xbbd270: r16 = true
    //     0xbbd270: add             x16, NULL, #0x20  ; true
    // 0xbbd274: r17 = false
    //     0xbbd274: add             x17, NULL, #0x30  ; false
    // 0xbbd278: csel            x0, x16, x17, ge
    // 0xbbd27c: b               #0xbbd284
    // 0xbbd280: r0 = false
    //     0xbbd280: add             x0, NULL, #0x30  ; false
    // 0xbbd284: eor             x2, x0, #0x10
    // 0xbbd288: r0 = LoadClassIdInstr(r1)
    //     0xbbd288: ldur            x0, [x1, #-1]
    //     0xbbd28c: ubfx            x0, x0, #0xc, #0x14
    // 0xbbd290: str             x2, [SP]
    // 0xbbd294: mov             x2, x4
    // 0xbbd298: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbd298: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbd29c: ldr             x4, [x4, #0xed0]
    // 0xbbd2a0: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbd2a0: mov             x17, #0xe6b9
    //     0xbbd2a4: add             lr, x0, x17
    //     0xbbd2a8: ldr             lr, [x21, lr, lsl #3]
    //     0xbbd2ac: blr             lr
    // 0xbbd2b0: ldur            x3, [fp, #-0x10]
    // 0xbbd2b4: LoadField: r0 = r3->field_4f
    //     0xbbd2b4: ldur            w0, [x3, #0x4f]
    // 0xbbd2b8: DecompressPointer r0
    //     0xbbd2b8: add             x0, x0, HEAP, lsl #32
    // 0xbbd2bc: cmp             w0, NULL
    // 0xbbd2c0: b.eq            #0xbbd410
    // 0xbbd2c4: LoadField: r4 = r0->field_7
    //     0xbbd2c4: ldur            w4, [x0, #7]
    // 0xbbd2c8: DecompressPointer r4
    //     0xbbd2c8: add             x4, x4, HEAP, lsl #32
    // 0xbbd2cc: stur            x4, [fp, #-0x18]
    // 0xbbd2d0: cmp             w4, NULL
    // 0xbbd2d4: b.eq            #0xbbd414
    // 0xbbd2d8: mov             x0, x4
    // 0xbbd2dc: r2 = Null
    //     0xbbd2dc: mov             x2, NULL
    // 0xbbd2e0: r1 = Null
    //     0xbbd2e0: mov             x1, NULL
    // 0xbbd2e4: r4 = LoadClassIdInstr(r0)
    //     0xbbd2e4: ldur            x4, [x0, #-1]
    //     0xbbd2e8: ubfx            x4, x4, #0xc, #0x14
    // 0xbbd2ec: r17 = -4190
    //     0xbbd2ec: mov             x17, #-0x105e
    // 0xbbd2f0: add             x4, x4, x17
    // 0xbbd2f4: cmp             x4, #0x17
    // 0xbbd2f8: b.ls            #0xbbd310
    // 0xbbd2fc: r8 = BoxParentData
    //     0xbbd2fc: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbd300: ldr             x8, [x8, #0x5e8]
    // 0xbbd304: r3 = Null
    //     0xbbd304: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa28a8] Null
    //     0xbbd308: ldr             x3, [x3, #0x8a8]
    // 0xbbd30c: r0 = DefaultTypeTest()
    //     0xbbd30c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbd310: ldur            x0, [fp, #-0x10]
    // 0xbbd314: LoadField: r2 = r0->field_53
    //     0xbbd314: ldur            w2, [x0, #0x53]
    // 0xbbd318: DecompressPointer r2
    //     0xbbd318: add             x2, x2, HEAP, lsl #32
    // 0xbbd31c: mov             x1, x0
    // 0xbbd320: stur            x2, [fp, #-0x20]
    // 0xbbd324: r0 = size()
    //     0xbbd324: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbd328: ldur            d0, [fp, #-0x38]
    // 0xbbd32c: ldur            d1, [fp, #-0x30]
    // 0xbbd330: stur            x0, [fp, #-0x28]
    // 0xbbd334: fcmp            d0, d1
    // 0xbbd338: b.lt            #0xbbd35c
    // 0xbbd33c: ldur            x1, [fp, #-8]
    // 0xbbd340: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xbbd340: ldur            d0, [x1, #0x17]
    // 0xbbd344: LoadField: d1 = r1->field_1f
    //     0xbbd344: ldur            d1, [x1, #0x1f]
    // 0xbbd348: fcmp            d0, d1
    // 0xbbd34c: b.lt            #0xbbd35c
    // 0xbbd350: r0 = smallest()
    //     0xbbd350: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbbd354: mov             x3, x0
    // 0xbbd358: b               #0xbbd378
    // 0xbbd35c: ldur            x0, [fp, #-0x10]
    // 0xbbd360: LoadField: r1 = r0->field_4f
    //     0xbbd360: ldur            w1, [x0, #0x4f]
    // 0xbbd364: DecompressPointer r1
    //     0xbbd364: add             x1, x1, HEAP, lsl #32
    // 0xbbd368: cmp             w1, NULL
    // 0xbbd36c: b.eq            #0xbbd418
    // 0xbbd370: r0 = size()
    //     0xbbd370: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbd374: mov             x3, x0
    // 0xbbd378: ldur            x4, [fp, #-0x18]
    // 0xbbd37c: ldur            x1, [fp, #-0x20]
    // 0xbbd380: r0 = LoadClassIdInstr(r1)
    //     0xbbd380: ldur            x0, [x1, #-1]
    //     0xbbd384: ubfx            x0, x0, #0xc, #0x14
    // 0xbbd388: ldur            x2, [fp, #-0x28]
    // 0xbbd38c: r0 = GDT[cid_x0 + -0xe0d]()
    //     0xbbd38c: sub             lr, x0, #0xe0d
    //     0xbbd390: ldr             lr, [x21, lr, lsl #3]
    //     0xbbd394: blr             lr
    // 0xbbd398: ldur            x1, [fp, #-0x18]
    // 0xbbd39c: StoreField: r1->field_7 = r0
    //     0xbbd39c: stur            w0, [x1, #7]
    //     0xbbd3a0: ldurb           w16, [x1, #-1]
    //     0xbbd3a4: ldurb           w17, [x0, #-1]
    //     0xbbd3a8: and             x16, x17, x16, lsr #2
    //     0xbbd3ac: tst             x16, HEAP, lsr #32
    //     0xbbd3b0: b.eq            #0xbbd3b8
    //     0xbbd3b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbd3b8: r0 = Null
    //     0xbbd3b8: mov             x0, NULL
    // 0xbbd3bc: LeaveFrame
    //     0xbbd3bc: mov             SP, fp
    //     0xbbd3c0: ldp             fp, lr, [SP], #0x10
    // 0xbbd3c4: ret
    //     0xbbd3c4: ret             
    // 0xbbd3c8: r0 = StateError()
    //     0xbbd3c8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbd3cc: mov             x1, x0
    // 0xbbd3d0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbd3d0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbd3d4: StoreField: r1->field_b = r0
    //     0xbbd3d4: stur            w0, [x1, #0xb]
    // 0xbbd3d8: mov             x0, x1
    // 0xbbd3dc: r0 = Throw()
    //     0xbbd3dc: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbd3e0: brk             #0
    // 0xbbd3e4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbd3e4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbd3e8: r0 = StateError()
    //     0xbbd3e8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbd3ec: mov             x1, x0
    // 0xbbd3f0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbd3f0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbd3f4: StoreField: r1->field_b = r0
    //     0xbbd3f4: stur            w0, [x1, #0xb]
    // 0xbbd3f8: mov             x0, x1
    // 0xbbd3fc: r0 = Throw()
    //     0xbbd3fc: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbd400: brk             #0
    // 0xbbd404: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbd404: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbd408: b               #0xbbd144
    // 0xbbd40c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbd40c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbd410: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbd410: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbd414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbd414: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbd418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbd418: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xc060b0, size: 0x30
    // 0xc060b0: EnterFrame
    //     0xc060b0: stp             fp, lr, [SP, #-0x10]!
    //     0xc060b4: mov             fp, SP
    // 0xc060b8: CheckStackOverflow
    //     0xc060b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc060bc: cmp             SP, x16
    //     0xc060c0: b.ls            #0xc060d8
    // 0xc060c4: r0 = detach()
    //     0xc060c4: bl              #0xc061c8  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::detach
    // 0xc060c8: r0 = Null
    //     0xc060c8: mov             x0, NULL
    // 0xc060cc: LeaveFrame
    //     0xc060cc: mov             SP, fp
    //     0xc060d0: ldp             fp, lr, [SP], #0x10
    // 0xc060d4: ret
    //     0xc060d4: ret             
    // 0xc060d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc060d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc060dc: b               #0xc060c4
  }
  _ attach(/* No info */) {
    // ** addr: 0xc099c8, size: 0x30
    // 0xc099c8: EnterFrame
    //     0xc099c8: stp             fp, lr, [SP, #-0x10]!
    //     0xc099cc: mov             fp, SP
    // 0xc099d0: CheckStackOverflow
    //     0xc099d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc099d4: cmp             SP, x16
    //     0xc099d8: b.ls            #0xc099f0
    // 0xc099dc: r0 = attach()
    //     0xc099dc: bl              #0xc09a60  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::attach
    // 0xc099e0: r0 = Null
    //     0xc099e0: mov             x0, NULL
    // 0xc099e4: LeaveFrame
    //     0xc099e4: mov             SP, fp
    //     0xc099e8: ldp             fp, lr, [SP], #0x10
    // 0xc099ec: ret
    //     0xc099ec: ret             
    // 0xc099f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc099f0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc099f4: b               #0xc099dc
  }
  set _ delegate=(/* No info */) {
    // ** addr: 0xcf7e30, size: 0xc4
    // 0xcf7e30: EnterFrame
    //     0xcf7e30: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7e34: mov             fp, SP
    // 0xcf7e38: AllocStack(0x28)
    //     0xcf7e38: sub             SP, SP, #0x28
    // 0xcf7e3c: SetupParameters(RenderCustomSingleChildLayoutBox this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xcf7e3c: mov             x0, x1
    //     0xcf7e40: stur            x1, [fp, #-0x10]
    //     0xcf7e44: mov             x1, x2
    //     0xcf7e48: stur            x2, [fp, #-0x18]
    // 0xcf7e4c: CheckStackOverflow
    //     0xcf7e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7e50: cmp             SP, x16
    //     0xcf7e54: b.ls            #0xcf7eec
    // 0xcf7e58: LoadField: r2 = r0->field_53
    //     0xcf7e58: ldur            w2, [x0, #0x53]
    // 0xcf7e5c: DecompressPointer r2
    //     0xcf7e5c: add             x2, x2, HEAP, lsl #32
    // 0xcf7e60: stur            x2, [fp, #-8]
    // 0xcf7e64: cmp             w2, w1
    // 0xcf7e68: b.ne            #0xcf7e7c
    // 0xcf7e6c: r0 = Null
    //     0xcf7e6c: mov             x0, NULL
    // 0xcf7e70: LeaveFrame
    //     0xcf7e70: mov             SP, fp
    //     0xcf7e74: ldp             fp, lr, [SP], #0x10
    // 0xcf7e78: ret
    //     0xcf7e78: ret             
    // 0xcf7e7c: stp             x2, x1, [SP]
    // 0xcf7e80: r0 = _haveSameRuntimeType()
    //     0xcf7e80: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0xcf7e84: tbnz            w0, #4, #0xcf7eb0
    // 0xcf7e88: ldur            x3, [fp, #-0x18]
    // 0xcf7e8c: r0 = LoadClassIdInstr(r3)
    //     0xcf7e8c: ldur            x0, [x3, #-1]
    //     0xcf7e90: ubfx            x0, x0, #0xc, #0x14
    // 0xcf7e94: mov             x1, x3
    // 0xcf7e98: ldur            x2, [fp, #-8]
    // 0xcf7e9c: r0 = GDT[cid_x0 + 0x7739]()
    //     0xcf7e9c: mov             x17, #0x7739
    //     0xcf7ea0: add             lr, x0, x17
    //     0xcf7ea4: ldr             lr, [x21, lr, lsl #3]
    //     0xcf7ea8: blr             lr
    // 0xcf7eac: tbnz            w0, #4, #0xcf7eb8
    // 0xcf7eb0: ldur            x1, [fp, #-0x10]
    // 0xcf7eb4: r0 = markNeedsLayout()
    //     0xcf7eb4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf7eb8: ldur            x1, [fp, #-0x10]
    // 0xcf7ebc: ldur            x0, [fp, #-0x18]
    // 0xcf7ec0: StoreField: r1->field_53 = r0
    //     0xcf7ec0: stur            w0, [x1, #0x53]
    //     0xcf7ec4: ldurb           w16, [x1, #-1]
    //     0xcf7ec8: ldurb           w17, [x0, #-1]
    //     0xcf7ecc: and             x16, x17, x16, lsr #2
    //     0xcf7ed0: tst             x16, HEAP, lsr #32
    //     0xcf7ed4: b.eq            #0xcf7edc
    //     0xcf7ed8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf7edc: r0 = Null
    //     0xcf7edc: mov             x0, NULL
    // 0xcf7ee0: LeaveFrame
    //     0xcf7ee0: mov             SP, fp
    //     0xcf7ee4: ldp             fp, lr, [SP], #0x10
    // 0xcf7ee8: ret
    //     0xcf7ee8: ret             
    // 0xcf7eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7eec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7ef0: b               #0xcf7e58
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efd78, size: 0x24
    // 0x10efd78: EnterFrame
    //     0x10efd78: stp             fp, lr, [SP, #-0x10]!
    //     0x10efd7c: mov             fp, SP
    // 0x10efd80: ldr             x2, [fp, #0x10]
    // 0x10efd84: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efd84: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2870] AnonymousClosure: (0x10efd9c), in [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMaxIntrinsicHeight (0xb2a0d8)
    //     0x10efd88: ldr             x1, [x1, #0x870]
    // 0x10efd8c: r0 = AllocateClosure()
    //     0x10efd8c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efd90: LeaveFrame
    //     0x10efd90: mov             SP, fp
    //     0x10efd94: ldp             fp, lr, [SP], #0x10
    // 0x10efd98: ret
    //     0x10efd98: ret             
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x10efd9c, size: 0x78
    // 0x10efd9c: EnterFrame
    //     0x10efd9c: stp             fp, lr, [SP, #-0x10]!
    //     0x10efda0: mov             fp, SP
    // 0x10efda4: ldr             x0, [fp, #0x18]
    // 0x10efda8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10efda8: ldur            w1, [x0, #0x17]
    // 0x10efdac: DecompressPointer r1
    //     0x10efdac: add             x1, x1, HEAP, lsl #32
    // 0x10efdb0: CheckStackOverflow
    //     0x10efdb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10efdb4: cmp             SP, x16
    //     0x10efdb8: b.ls            #0x10efdfc
    // 0x10efdbc: ldr             x2, [fp, #0x10]
    // 0x10efdc0: r0 = computeMaxIntrinsicHeight()
    //     0x10efdc0: bl              #0xb2a0d8  ; [package:flutter/src/rendering/shifted_box.dart] RenderCustomSingleChildLayoutBox::computeMaxIntrinsicHeight
    // 0x10efdc4: r0 = inline_Allocate_Double()
    //     0x10efdc4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x10efdc8: add             x0, x0, #0x10
    //     0x10efdcc: cmp             x1, x0
    //     0x10efdd0: b.ls            #0x10efe04
    //     0x10efdd4: str             x0, [THR, #0x60]  ; THR::top
    //     0x10efdd8: sub             x0, x0, #0xf
    //     0x10efddc: mov             x1, #0xe19c
    //     0x10efde0: movk            x1, #3, lsl #16
    //     0x10efde4: stur            x1, [x0, #-1]
    // 0x10efde8: dmb             ishst
    // 0x10efdec: StoreField: r0->field_7 = d0
    //     0x10efdec: stur            d0, [x0, #7]
    // 0x10efdf0: LeaveFrame
    //     0x10efdf0: mov             SP, fp
    //     0x10efdf4: ldp             fp, lr, [SP], #0x10
    // 0x10efdf8: ret
    //     0x10efdf8: ret             
    // 0x10efdfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10efdfc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10efe00: b               #0x10efdbc
    // 0x10efe04: SaveReg d0
    //     0x10efe04: str             q0, [SP, #-0x10]!
    // 0x10efe08: r0 = AllocateDouble()
    //     0x10efe08: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10efe0c: RestoreReg d0
    //     0x10efe0c: ldr             q0, [SP], #0x10
    // 0x10efe10: b               #0x10efdec
  }
}

// class id: 4877, size: 0x60, field offset: 0x54
class RenderPadding extends RenderShiftedBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb1710c, size: 0x24
    // 0xb1710c: EnterFrame
    //     0xb1710c: stp             fp, lr, [SP, #-0x10]!
    //     0xb17110: mov             fp, SP
    // 0xb17114: ldr             x2, [fp, #0x10]
    // 0xb17118: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb17118: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa28d8] AnonymousClosure: (0xb17130), in [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMinIntrinsicWidth (0xb171a8)
    //     0xb1711c: ldr             x1, [x1, #0x8d8]
    // 0xb17120: r0 = AllocateClosure()
    //     0xb17120: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb17124: LeaveFrame
    //     0xb17124: mov             SP, fp
    //     0xb17128: ldp             fp, lr, [SP], #0x10
    // 0xb1712c: ret
    //     0xb1712c: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb17130, size: 0x78
    // 0xb17130: EnterFrame
    //     0xb17130: stp             fp, lr, [SP, #-0x10]!
    //     0xb17134: mov             fp, SP
    // 0xb17138: ldr             x0, [fp, #0x18]
    // 0xb1713c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1713c: ldur            w1, [x0, #0x17]
    // 0xb17140: DecompressPointer r1
    //     0xb17140: add             x1, x1, HEAP, lsl #32
    // 0xb17144: CheckStackOverflow
    //     0xb17144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb17148: cmp             SP, x16
    //     0xb1714c: b.ls            #0xb17190
    // 0xb17150: ldr             x2, [fp, #0x10]
    // 0xb17154: r0 = computeMinIntrinsicWidth()
    //     0xb17154: bl              #0xb171a8  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMinIntrinsicWidth
    // 0xb17158: r0 = inline_Allocate_Double()
    //     0xb17158: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1715c: add             x0, x0, #0x10
    //     0xb17160: cmp             x1, x0
    //     0xb17164: b.ls            #0xb17198
    //     0xb17168: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1716c: sub             x0, x0, #0xf
    //     0xb17170: mov             x1, #0xe19c
    //     0xb17174: movk            x1, #3, lsl #16
    //     0xb17178: stur            x1, [x0, #-1]
    // 0xb1717c: dmb             ishst
    // 0xb17180: StoreField: r0->field_7 = d0
    //     0xb17180: stur            d0, [x0, #7]
    // 0xb17184: LeaveFrame
    //     0xb17184: mov             SP, fp
    //     0xb17188: ldp             fp, lr, [SP], #0x10
    // 0xb1718c: ret
    //     0xb1718c: ret             
    // 0xb17190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb17190: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb17194: b               #0xb17150
    // 0xb17198: SaveReg d0
    //     0xb17198: str             q0, [SP, #-0x10]!
    // 0xb1719c: r0 = AllocateDouble()
    //     0xb1719c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb171a0: RestoreReg d0
    //     0xb171a0: ldr             q0, [SP], #0x10
    // 0xb171a4: b               #0xb17180
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb171a8, size: 0xbc
    // 0xb171a8: EnterFrame
    //     0xb171a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb171ac: mov             fp, SP
    // 0xb171b0: AllocStack(0x28)
    //     0xb171b0: sub             SP, SP, #0x28
    // 0xb171b4: SetupParameters(RenderPadding this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb171b4: mov             x0, x1
    //     0xb171b8: stur            x1, [fp, #-8]
    //     0xb171bc: stur            x2, [fp, #-0x10]
    // 0xb171c0: CheckStackOverflow
    //     0xb171c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb171c4: cmp             SP, x16
    //     0xb171c8: b.ls            #0xb1725c
    // 0xb171cc: mov             x1, x0
    // 0xb171d0: r0 = _resolvedPadding()
    //     0xb171d0: bl              #0xb17364  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolvedPadding
    // 0xb171d4: mov             x2, x0
    // 0xb171d8: ldur            x0, [fp, #-8]
    // 0xb171dc: stur            x2, [fp, #-0x20]
    // 0xb171e0: LoadField: r3 = r0->field_4f
    //     0xb171e0: ldur            w3, [x0, #0x4f]
    // 0xb171e4: DecompressPointer r3
    //     0xb171e4: add             x3, x3, HEAP, lsl #32
    // 0xb171e8: stur            x3, [fp, #-0x18]
    // 0xb171ec: cmp             w3, NULL
    // 0xb171f0: b.eq            #0xb17248
    // 0xb171f4: ldur            x0, [fp, #-0x10]
    // 0xb171f8: mov             x1, x2
    // 0xb171fc: r0 = vertical()
    //     0xb171fc: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb17200: ldur            x0, [fp, #-0x10]
    // 0xb17204: LoadField: d1 = r0->field_7
    //     0xb17204: ldur            d1, [x0, #7]
    // 0xb17208: fsub            d2, d1, d0
    // 0xb1720c: d0 = 0.000000
    //     0xb1720c: eor             v0.16b, v0.16b, v0.16b
    // 0xb17210: fmax            v1.2d, v0.2d, v2.2d
    // 0xb17214: ldur            x1, [fp, #-0x18]
    // 0xb17218: mov             v0.16b, v1.16b
    // 0xb1721c: r0 = getMinIntrinsicWidth()
    //     0xb1721c: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb17220: ldur            x1, [fp, #-0x20]
    // 0xb17224: stur            d0, [fp, #-0x28]
    // 0xb17228: r0 = horizontal()
    //     0xb17228: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb1722c: mov             v1.16b, v0.16b
    // 0xb17230: ldur            d0, [fp, #-0x28]
    // 0xb17234: fadd            d2, d0, d1
    // 0xb17238: mov             v0.16b, v2.16b
    // 0xb1723c: LeaveFrame
    //     0xb1723c: mov             SP, fp
    //     0xb17240: ldp             fp, lr, [SP], #0x10
    // 0xb17244: ret
    //     0xb17244: ret             
    // 0xb17248: ldur            x1, [fp, #-0x20]
    // 0xb1724c: r0 = horizontal()
    //     0xb1724c: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb17250: LeaveFrame
    //     0xb17250: mov             SP, fp
    //     0xb17254: ldp             fp, lr, [SP], #0x10
    // 0xb17258: ret
    //     0xb17258: ret             
    // 0xb1725c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1725c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb17260: b               #0xb171cc
  }
  get _ _resolvedPadding(/* No info */) {
    // ** addr: 0xb17364, size: 0xbc
    // 0xb17364: EnterFrame
    //     0xb17364: stp             fp, lr, [SP, #-0x10]!
    //     0xb17368: mov             fp, SP
    // 0xb1736c: AllocStack(0x8)
    //     0xb1736c: sub             SP, SP, #8
    // 0xb17370: SetupParameters(RenderPadding this /* r1 => r3, fp-0x8 */)
    //     0xb17370: mov             x3, x1
    //     0xb17374: stur            x1, [fp, #-8]
    // 0xb17378: CheckStackOverflow
    //     0xb17378: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1737c: cmp             SP, x16
    //     0xb17380: b.ls            #0xb17418
    // 0xb17384: LoadField: r0 = r3->field_53
    //     0xb17384: ldur            w0, [x3, #0x53]
    // 0xb17388: DecompressPointer r0
    //     0xb17388: add             x0, x0, HEAP, lsl #32
    // 0xb1738c: cmp             w0, NULL
    // 0xb17390: b.ne            #0xb1740c
    // 0xb17394: LoadField: r0 = r3->field_57
    //     0xb17394: ldur            w0, [x3, #0x57]
    // 0xb17398: DecompressPointer r0
    //     0xb17398: add             x0, x0, HEAP, lsl #32
    // 0xb1739c: LoadField: r2 = r3->field_5b
    //     0xb1739c: ldur            w2, [x3, #0x5b]
    // 0xb173a0: DecompressPointer r2
    //     0xb173a0: add             x2, x2, HEAP, lsl #32
    // 0xb173a4: r1 = LoadClassIdInstr(r0)
    //     0xb173a4: ldur            x1, [x0, #-1]
    //     0xb173a8: ubfx            x1, x1, #0xc, #0x14
    // 0xb173ac: cmp             x1, #0xb7c
    // 0xb173b0: b.ne            #0xb173c0
    // 0xb173b4: mov             x2, x0
    // 0xb173b8: mov             x1, x3
    // 0xb173bc: b               #0xb173e8
    // 0xb173c0: r1 = LoadClassIdInstr(r0)
    //     0xb173c0: ldur            x1, [x0, #-1]
    //     0xb173c4: ubfx            x1, x1, #0xc, #0x14
    // 0xb173c8: mov             x16, x0
    // 0xb173cc: mov             x0, x1
    // 0xb173d0: mov             x1, x16
    // 0xb173d4: r0 = GDT[cid_x0 + -0xfea]()
    //     0xb173d4: sub             lr, x0, #0xfea
    //     0xb173d8: ldr             lr, [x21, lr, lsl #3]
    //     0xb173dc: blr             lr
    // 0xb173e0: mov             x2, x0
    // 0xb173e4: ldur            x1, [fp, #-8]
    // 0xb173e8: mov             x0, x2
    // 0xb173ec: StoreField: r1->field_53 = r0
    //     0xb173ec: stur            w0, [x1, #0x53]
    //     0xb173f0: ldurb           w16, [x1, #-1]
    //     0xb173f4: ldurb           w17, [x0, #-1]
    //     0xb173f8: and             x16, x17, x16, lsr #2
    //     0xb173fc: tst             x16, HEAP, lsr #32
    //     0xb17400: b.eq            #0xb17408
    //     0xb17404: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb17408: mov             x0, x2
    // 0xb1740c: LeaveFrame
    //     0xb1740c: mov             SP, fp
    //     0xb17410: ldp             fp, lr, [SP], #0x10
    // 0xb17414: ret
    //     0xb17414: ret             
    // 0xb17418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb17418: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1741c: b               #0xb17384
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb23378, size: 0xbc
    // 0xb23378: EnterFrame
    //     0xb23378: stp             fp, lr, [SP, #-0x10]!
    //     0xb2337c: mov             fp, SP
    // 0xb23380: AllocStack(0x28)
    //     0xb23380: sub             SP, SP, #0x28
    // 0xb23384: SetupParameters(RenderPadding this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb23384: mov             x0, x1
    //     0xb23388: stur            x1, [fp, #-8]
    //     0xb2338c: stur            x2, [fp, #-0x10]
    // 0xb23390: CheckStackOverflow
    //     0xb23390: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23394: cmp             SP, x16
    //     0xb23398: b.ls            #0xb2342c
    // 0xb2339c: mov             x1, x0
    // 0xb233a0: r0 = _resolvedPadding()
    //     0xb233a0: bl              #0xb17364  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolvedPadding
    // 0xb233a4: mov             x2, x0
    // 0xb233a8: ldur            x0, [fp, #-8]
    // 0xb233ac: stur            x2, [fp, #-0x20]
    // 0xb233b0: LoadField: r3 = r0->field_4f
    //     0xb233b0: ldur            w3, [x0, #0x4f]
    // 0xb233b4: DecompressPointer r3
    //     0xb233b4: add             x3, x3, HEAP, lsl #32
    // 0xb233b8: stur            x3, [fp, #-0x18]
    // 0xb233bc: cmp             w3, NULL
    // 0xb233c0: b.eq            #0xb23418
    // 0xb233c4: ldur            x0, [fp, #-0x10]
    // 0xb233c8: mov             x1, x2
    // 0xb233cc: r0 = horizontal()
    //     0xb233cc: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb233d0: ldur            x0, [fp, #-0x10]
    // 0xb233d4: LoadField: d1 = r0->field_7
    //     0xb233d4: ldur            d1, [x0, #7]
    // 0xb233d8: fsub            d2, d1, d0
    // 0xb233dc: d0 = 0.000000
    //     0xb233dc: eor             v0.16b, v0.16b, v0.16b
    // 0xb233e0: fmax            v1.2d, v0.2d, v2.2d
    // 0xb233e4: ldur            x1, [fp, #-0x18]
    // 0xb233e8: mov             v0.16b, v1.16b
    // 0xb233ec: r0 = getMinIntrinsicHeight()
    //     0xb233ec: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb233f0: ldur            x1, [fp, #-0x20]
    // 0xb233f4: stur            d0, [fp, #-0x28]
    // 0xb233f8: r0 = vertical()
    //     0xb233f8: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb233fc: mov             v1.16b, v0.16b
    // 0xb23400: ldur            d0, [fp, #-0x28]
    // 0xb23404: fadd            d2, d0, d1
    // 0xb23408: mov             v0.16b, v2.16b
    // 0xb2340c: LeaveFrame
    //     0xb2340c: mov             SP, fp
    //     0xb23410: ldp             fp, lr, [SP], #0x10
    // 0xb23414: ret
    //     0xb23414: ret             
    // 0xb23418: ldur            x1, [fp, #-0x20]
    // 0xb2341c: r0 = vertical()
    //     0xb2341c: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb23420: LeaveFrame
    //     0xb23420: mov             SP, fp
    //     0xb23424: ldp             fp, lr, [SP], #0x10
    // 0xb23428: ret
    //     0xb23428: ret             
    // 0xb2342c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2342c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23430: b               #0xb2339c
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb23434, size: 0x78
    // 0xb23434: EnterFrame
    //     0xb23434: stp             fp, lr, [SP, #-0x10]!
    //     0xb23438: mov             fp, SP
    // 0xb2343c: ldr             x0, [fp, #0x18]
    // 0xb23440: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb23440: ldur            w1, [x0, #0x17]
    // 0xb23444: DecompressPointer r1
    //     0xb23444: add             x1, x1, HEAP, lsl #32
    // 0xb23448: CheckStackOverflow
    //     0xb23448: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2344c: cmp             SP, x16
    //     0xb23450: b.ls            #0xb23494
    // 0xb23454: ldr             x2, [fp, #0x10]
    // 0xb23458: r0 = computeMinIntrinsicHeight()
    //     0xb23458: bl              #0xb23378  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMinIntrinsicHeight
    // 0xb2345c: r0 = inline_Allocate_Double()
    //     0xb2345c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23460: add             x0, x0, #0x10
    //     0xb23464: cmp             x1, x0
    //     0xb23468: b.ls            #0xb2349c
    //     0xb2346c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23470: sub             x0, x0, #0xf
    //     0xb23474: mov             x1, #0xe19c
    //     0xb23478: movk            x1, #3, lsl #16
    //     0xb2347c: stur            x1, [x0, #-1]
    // 0xb23480: dmb             ishst
    // 0xb23484: StoreField: r0->field_7 = d0
    //     0xb23484: stur            d0, [x0, #7]
    // 0xb23488: LeaveFrame
    //     0xb23488: mov             SP, fp
    //     0xb2348c: ldp             fp, lr, [SP], #0x10
    // 0xb23490: ret
    //     0xb23490: ret             
    // 0xb23494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23494: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23498: b               #0xb23454
    // 0xb2349c: SaveReg d0
    //     0xb2349c: str             q0, [SP, #-0x10]!
    // 0xb234a0: r0 = AllocateDouble()
    //     0xb234a0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb234a4: RestoreReg d0
    //     0xb234a4: ldr             q0, [SP], #0x10
    // 0xb234a8: b               #0xb23484
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb29fa4, size: 0xbc
    // 0xb29fa4: EnterFrame
    //     0xb29fa4: stp             fp, lr, [SP, #-0x10]!
    //     0xb29fa8: mov             fp, SP
    // 0xb29fac: AllocStack(0x28)
    //     0xb29fac: sub             SP, SP, #0x28
    // 0xb29fb0: SetupParameters(RenderPadding this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb29fb0: mov             x0, x1
    //     0xb29fb4: stur            x1, [fp, #-8]
    //     0xb29fb8: stur            x2, [fp, #-0x10]
    // 0xb29fbc: CheckStackOverflow
    //     0xb29fbc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29fc0: cmp             SP, x16
    //     0xb29fc4: b.ls            #0xb2a058
    // 0xb29fc8: mov             x1, x0
    // 0xb29fcc: r0 = _resolvedPadding()
    //     0xb29fcc: bl              #0xb17364  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolvedPadding
    // 0xb29fd0: mov             x2, x0
    // 0xb29fd4: ldur            x0, [fp, #-8]
    // 0xb29fd8: stur            x2, [fp, #-0x20]
    // 0xb29fdc: LoadField: r3 = r0->field_4f
    //     0xb29fdc: ldur            w3, [x0, #0x4f]
    // 0xb29fe0: DecompressPointer r3
    //     0xb29fe0: add             x3, x3, HEAP, lsl #32
    // 0xb29fe4: stur            x3, [fp, #-0x18]
    // 0xb29fe8: cmp             w3, NULL
    // 0xb29fec: b.eq            #0xb2a044
    // 0xb29ff0: ldur            x0, [fp, #-0x10]
    // 0xb29ff4: mov             x1, x2
    // 0xb29ff8: r0 = horizontal()
    //     0xb29ff8: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb29ffc: ldur            x0, [fp, #-0x10]
    // 0xb2a000: LoadField: d1 = r0->field_7
    //     0xb2a000: ldur            d1, [x0, #7]
    // 0xb2a004: fsub            d2, d1, d0
    // 0xb2a008: d0 = 0.000000
    //     0xb2a008: eor             v0.16b, v0.16b, v0.16b
    // 0xb2a00c: fmax            v1.2d, v0.2d, v2.2d
    // 0xb2a010: ldur            x1, [fp, #-0x18]
    // 0xb2a014: mov             v0.16b, v1.16b
    // 0xb2a018: r0 = getMaxIntrinsicHeight()
    //     0xb2a018: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2a01c: ldur            x1, [fp, #-0x20]
    // 0xb2a020: stur            d0, [fp, #-0x28]
    // 0xb2a024: r0 = vertical()
    //     0xb2a024: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb2a028: mov             v1.16b, v0.16b
    // 0xb2a02c: ldur            d0, [fp, #-0x28]
    // 0xb2a030: fadd            d2, d0, d1
    // 0xb2a034: mov             v0.16b, v2.16b
    // 0xb2a038: LeaveFrame
    //     0xb2a038: mov             SP, fp
    //     0xb2a03c: ldp             fp, lr, [SP], #0x10
    // 0xb2a040: ret
    //     0xb2a040: ret             
    // 0xb2a044: ldur            x1, [fp, #-0x20]
    // 0xb2a048: r0 = vertical()
    //     0xb2a048: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb2a04c: LeaveFrame
    //     0xb2a04c: mov             SP, fp
    //     0xb2a050: ldp             fp, lr, [SP], #0x10
    // 0xb2a054: ret
    //     0xb2a054: ret             
    // 0xb2a058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a058: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a05c: b               #0xb29fc8
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2a060, size: 0x78
    // 0xb2a060: EnterFrame
    //     0xb2a060: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a064: mov             fp, SP
    // 0xb2a068: ldr             x0, [fp, #0x18]
    // 0xb2a06c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2a06c: ldur            w1, [x0, #0x17]
    // 0xb2a070: DecompressPointer r1
    //     0xb2a070: add             x1, x1, HEAP, lsl #32
    // 0xb2a074: CheckStackOverflow
    //     0xb2a074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a078: cmp             SP, x16
    //     0xb2a07c: b.ls            #0xb2a0c0
    // 0xb2a080: ldr             x2, [fp, #0x10]
    // 0xb2a084: r0 = computeMaxIntrinsicHeight()
    //     0xb2a084: bl              #0xb29fa4  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMaxIntrinsicHeight
    // 0xb2a088: r0 = inline_Allocate_Double()
    //     0xb2a088: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2a08c: add             x0, x0, #0x10
    //     0xb2a090: cmp             x1, x0
    //     0xb2a094: b.ls            #0xb2a0c8
    //     0xb2a098: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2a09c: sub             x0, x0, #0xf
    //     0xb2a0a0: mov             x1, #0xe19c
    //     0xb2a0a4: movk            x1, #3, lsl #16
    //     0xb2a0a8: stur            x1, [x0, #-1]
    // 0xb2a0ac: dmb             ishst
    // 0xb2a0b0: StoreField: r0->field_7 = d0
    //     0xb2a0b0: stur            d0, [x0, #7]
    // 0xb2a0b4: LeaveFrame
    //     0xb2a0b4: mov             SP, fp
    //     0xb2a0b8: ldp             fp, lr, [SP], #0x10
    // 0xb2a0bc: ret
    //     0xb2a0bc: ret             
    // 0xb2a0c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a0c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a0c4: b               #0xb2a080
    // 0xb2a0c8: SaveReg d0
    //     0xb2a0c8: str             q0, [SP, #-0x10]!
    // 0xb2a0cc: r0 = AllocateDouble()
    //     0xb2a0cc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2a0d0: RestoreReg d0
    //     0xb2a0d0: ldr             q0, [SP], #0x10
    // 0xb2a0d4: b               #0xb2a0b0
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2d3d0, size: 0xbc
    // 0xb2d3d0: EnterFrame
    //     0xb2d3d0: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d3d4: mov             fp, SP
    // 0xb2d3d8: AllocStack(0x28)
    //     0xb2d3d8: sub             SP, SP, #0x28
    // 0xb2d3dc: SetupParameters(RenderPadding this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2d3dc: mov             x0, x1
    //     0xb2d3e0: stur            x1, [fp, #-8]
    //     0xb2d3e4: stur            x2, [fp, #-0x10]
    // 0xb2d3e8: CheckStackOverflow
    //     0xb2d3e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d3ec: cmp             SP, x16
    //     0xb2d3f0: b.ls            #0xb2d484
    // 0xb2d3f4: mov             x1, x0
    // 0xb2d3f8: r0 = _resolvedPadding()
    //     0xb2d3f8: bl              #0xb17364  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolvedPadding
    // 0xb2d3fc: mov             x2, x0
    // 0xb2d400: ldur            x0, [fp, #-8]
    // 0xb2d404: stur            x2, [fp, #-0x20]
    // 0xb2d408: LoadField: r3 = r0->field_4f
    //     0xb2d408: ldur            w3, [x0, #0x4f]
    // 0xb2d40c: DecompressPointer r3
    //     0xb2d40c: add             x3, x3, HEAP, lsl #32
    // 0xb2d410: stur            x3, [fp, #-0x18]
    // 0xb2d414: cmp             w3, NULL
    // 0xb2d418: b.eq            #0xb2d470
    // 0xb2d41c: ldur            x0, [fp, #-0x10]
    // 0xb2d420: mov             x1, x2
    // 0xb2d424: r0 = vertical()
    //     0xb2d424: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb2d428: ldur            x0, [fp, #-0x10]
    // 0xb2d42c: LoadField: d1 = r0->field_7
    //     0xb2d42c: ldur            d1, [x0, #7]
    // 0xb2d430: fsub            d2, d1, d0
    // 0xb2d434: d0 = 0.000000
    //     0xb2d434: eor             v0.16b, v0.16b, v0.16b
    // 0xb2d438: fmax            v1.2d, v0.2d, v2.2d
    // 0xb2d43c: ldur            x1, [fp, #-0x18]
    // 0xb2d440: mov             v0.16b, v1.16b
    // 0xb2d444: r0 = getMaxIntrinsicWidth()
    //     0xb2d444: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2d448: ldur            x1, [fp, #-0x20]
    // 0xb2d44c: stur            d0, [fp, #-0x28]
    // 0xb2d450: r0 = horizontal()
    //     0xb2d450: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb2d454: mov             v1.16b, v0.16b
    // 0xb2d458: ldur            d0, [fp, #-0x28]
    // 0xb2d45c: fadd            d2, d0, d1
    // 0xb2d460: mov             v0.16b, v2.16b
    // 0xb2d464: LeaveFrame
    //     0xb2d464: mov             SP, fp
    //     0xb2d468: ldp             fp, lr, [SP], #0x10
    // 0xb2d46c: ret
    //     0xb2d46c: ret             
    // 0xb2d470: ldur            x1, [fp, #-0x20]
    // 0xb2d474: r0 = horizontal()
    //     0xb2d474: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb2d478: LeaveFrame
    //     0xb2d478: mov             SP, fp
    //     0xb2d47c: ldp             fp, lr, [SP], #0x10
    // 0xb2d480: ret
    //     0xb2d480: ret             
    // 0xb2d484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d484: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d488: b               #0xb2d3f4
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2d48c, size: 0x78
    // 0xb2d48c: EnterFrame
    //     0xb2d48c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d490: mov             fp, SP
    // 0xb2d494: ldr             x0, [fp, #0x18]
    // 0xb2d498: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2d498: ldur            w1, [x0, #0x17]
    // 0xb2d49c: DecompressPointer r1
    //     0xb2d49c: add             x1, x1, HEAP, lsl #32
    // 0xb2d4a0: CheckStackOverflow
    //     0xb2d4a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d4a4: cmp             SP, x16
    //     0xb2d4a8: b.ls            #0xb2d4ec
    // 0xb2d4ac: ldr             x2, [fp, #0x10]
    // 0xb2d4b0: r0 = computeMaxIntrinsicWidth()
    //     0xb2d4b0: bl              #0xb2d3d0  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMaxIntrinsicWidth
    // 0xb2d4b4: r0 = inline_Allocate_Double()
    //     0xb2d4b4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2d4b8: add             x0, x0, #0x10
    //     0xb2d4bc: cmp             x1, x0
    //     0xb2d4c0: b.ls            #0xb2d4f4
    //     0xb2d4c4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2d4c8: sub             x0, x0, #0xf
    //     0xb2d4cc: mov             x1, #0xe19c
    //     0xb2d4d0: movk            x1, #3, lsl #16
    //     0xb2d4d4: stur            x1, [x0, #-1]
    // 0xb2d4d8: dmb             ishst
    // 0xb2d4dc: StoreField: r0->field_7 = d0
    //     0xb2d4dc: stur            d0, [x0, #7]
    // 0xb2d4e0: LeaveFrame
    //     0xb2d4e0: mov             SP, fp
    //     0xb2d4e4: ldp             fp, lr, [SP], #0x10
    // 0xb2d4e8: ret
    //     0xb2d4e8: ret             
    // 0xb2d4ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d4ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d4f0: b               #0xb2d4ac
    // 0xb2d4f4: SaveReg d0
    //     0xb2d4f4: str             q0, [SP, #-0x10]!
    // 0xb2d4f8: r0 = AllocateDouble()
    //     0xb2d4f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d4fc: RestoreReg d0
    //     0xb2d4fc: ldr             q0, [SP], #0x10
    // 0xb2d500: b               #0xb2d4dc
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4d940, size: 0x130
    // 0xb4d940: EnterFrame
    //     0xb4d940: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d944: mov             fp, SP
    // 0xb4d948: AllocStack(0x28)
    //     0xb4d948: sub             SP, SP, #0x28
    // 0xb4d94c: SetupParameters(RenderPadding this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb4d94c: mov             x0, x2
    //     0xb4d950: stur            x2, [fp, #-0x10]
    //     0xb4d954: mov             x2, x1
    //     0xb4d958: stur            x1, [fp, #-8]
    // 0xb4d95c: CheckStackOverflow
    //     0xb4d95c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d960: cmp             SP, x16
    //     0xb4d964: b.ls            #0xb4da64
    // 0xb4d968: mov             x1, x2
    // 0xb4d96c: r0 = _resolvedPadding()
    //     0xb4d96c: bl              #0xb17364  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolvedPadding
    // 0xb4d970: mov             x2, x0
    // 0xb4d974: ldur            x0, [fp, #-8]
    // 0xb4d978: stur            x2, [fp, #-0x18]
    // 0xb4d97c: LoadField: r1 = r0->field_4f
    //     0xb4d97c: ldur            w1, [x0, #0x4f]
    // 0xb4d980: DecompressPointer r1
    //     0xb4d980: add             x1, x1, HEAP, lsl #32
    // 0xb4d984: cmp             w1, NULL
    // 0xb4d988: b.ne            #0xb4d9d0
    // 0xb4d98c: mov             x1, x2
    // 0xb4d990: r0 = horizontal()
    //     0xb4d990: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb4d994: ldur            x1, [fp, #-0x18]
    // 0xb4d998: stur            d0, [fp, #-0x20]
    // 0xb4d99c: r0 = vertical()
    //     0xb4d99c: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb4d9a0: stur            d0, [fp, #-0x28]
    // 0xb4d9a4: r0 = Size()
    //     0xb4d9a4: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4d9a8: ldur            d0, [fp, #-0x20]
    // 0xb4d9ac: StoreField: r0->field_7 = d0
    //     0xb4d9ac: stur            d0, [x0, #7]
    // 0xb4d9b0: ldur            d0, [fp, #-0x28]
    // 0xb4d9b4: StoreField: r0->field_f = d0
    //     0xb4d9b4: stur            d0, [x0, #0xf]
    // 0xb4d9b8: ldur            x1, [fp, #-0x10]
    // 0xb4d9bc: mov             x2, x0
    // 0xb4d9c0: r0 = constrain()
    //     0xb4d9c0: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d9c4: LeaveFrame
    //     0xb4d9c4: mov             SP, fp
    //     0xb4d9c8: ldp             fp, lr, [SP], #0x10
    // 0xb4d9cc: ret
    //     0xb4d9cc: ret             
    // 0xb4d9d0: ldur            x1, [fp, #-0x10]
    // 0xb4d9d4: ldur            x2, [fp, #-0x18]
    // 0xb4d9d8: r0 = deflate()
    //     0xb4d9d8: bl              #0xb4cd58  ; [package:flutter/src/rendering/box.dart] BoxConstraints::deflate
    // 0xb4d9dc: mov             x1, x0
    // 0xb4d9e0: ldur            x0, [fp, #-8]
    // 0xb4d9e4: LoadField: r2 = r0->field_4f
    //     0xb4d9e4: ldur            w2, [x0, #0x4f]
    // 0xb4d9e8: DecompressPointer r2
    //     0xb4d9e8: add             x2, x2, HEAP, lsl #32
    // 0xb4d9ec: cmp             w2, NULL
    // 0xb4d9f0: b.eq            #0xb4da6c
    // 0xb4d9f4: mov             x16, x1
    // 0xb4d9f8: mov             x1, x2
    // 0xb4d9fc: mov             x2, x16
    // 0xb4da00: r0 = getDryLayout()
    //     0xb4da00: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4da04: ldur            x1, [fp, #-0x18]
    // 0xb4da08: stur            x0, [fp, #-8]
    // 0xb4da0c: r0 = horizontal()
    //     0xb4da0c: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xb4da10: ldur            x0, [fp, #-8]
    // 0xb4da14: LoadField: d1 = r0->field_7
    //     0xb4da14: ldur            d1, [x0, #7]
    // 0xb4da18: fadd            d2, d0, d1
    // 0xb4da1c: ldur            x1, [fp, #-0x18]
    // 0xb4da20: stur            d2, [fp, #-0x20]
    // 0xb4da24: r0 = vertical()
    //     0xb4da24: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xb4da28: ldur            x0, [fp, #-8]
    // 0xb4da2c: LoadField: d1 = r0->field_f
    //     0xb4da2c: ldur            d1, [x0, #0xf]
    // 0xb4da30: fadd            d2, d0, d1
    // 0xb4da34: stur            d2, [fp, #-0x28]
    // 0xb4da38: r0 = Size()
    //     0xb4da38: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4da3c: ldur            d0, [fp, #-0x20]
    // 0xb4da40: StoreField: r0->field_7 = d0
    //     0xb4da40: stur            d0, [x0, #7]
    // 0xb4da44: ldur            d0, [fp, #-0x28]
    // 0xb4da48: StoreField: r0->field_f = d0
    //     0xb4da48: stur            d0, [x0, #0xf]
    // 0xb4da4c: ldur            x1, [fp, #-0x10]
    // 0xb4da50: mov             x2, x0
    // 0xb4da54: r0 = constrain()
    //     0xb4da54: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4da58: LeaveFrame
    //     0xb4da58: mov             SP, fp
    //     0xb4da5c: ldp             fp, lr, [SP], #0x10
    // 0xb4da60: ret
    //     0xb4da60: ret             
    // 0xb4da64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4da64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4da68: b               #0xb4d968
    // 0xb4da6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb4da6c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb583c0, size: 0x24
    // 0xb583c0: EnterFrame
    //     0xb583c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb583c4: mov             fp, SP
    // 0xb583c8: ldr             x2, [fp, #0x10]
    // 0xb583cc: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb583cc: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa28d0] AnonymousClosure: (0xb2d48c), in [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMaxIntrinsicWidth (0xb2d3d0)
    //     0xb583d0: ldr             x1, [x1, #0x8d0]
    // 0xb583d4: r0 = AllocateClosure()
    //     0xb583d4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb583d8: LeaveFrame
    //     0xb583d8: mov             SP, fp
    //     0xb583dc: ldp             fp, lr, [SP], #0x10
    // 0xb583e0: ret
    //     0xb583e0: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e548, size: 0x24
    // 0xb5e548: EnterFrame
    //     0xb5e548: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e54c: mov             fp, SP
    // 0xb5e550: ldr             x2, [fp, #0x10]
    // 0xb5e554: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e554: add             x1, PP, #0x98, lsl #12  ; [pp+0x98530] AnonymousClosure: (0xb2a060), in [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMaxIntrinsicHeight (0xb29fa4)
    //     0xb5e558: ldr             x1, [x1, #0x530]
    // 0xb5e55c: r0 = AllocateClosure()
    //     0xb5e55c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e560: LeaveFrame
    //     0xb5e560: mov             SP, fp
    //     0xb5e564: ldp             fp, lr, [SP], #0x10
    // 0xb5e568: ret
    //     0xb5e568: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb60f74, size: 0x128
    // 0xb60f74: EnterFrame
    //     0xb60f74: stp             fp, lr, [SP, #-0x10]!
    //     0xb60f78: mov             fp, SP
    // 0xb60f7c: AllocStack(0x20)
    //     0xb60f7c: sub             SP, SP, #0x20
    // 0xb60f80: SetupParameters(RenderPadding this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb60f80: mov             x5, x1
    //     0xb60f84: mov             x4, x2
    //     0xb60f88: stur            x1, [fp, #-8]
    //     0xb60f8c: stur            x2, [fp, #-0x10]
    //     0xb60f90: stur            x3, [fp, #-0x18]
    // 0xb60f94: CheckStackOverflow
    //     0xb60f94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb60f98: cmp             SP, x16
    //     0xb60f9c: b.ls            #0xb61084
    // 0xb60fa0: mov             x0, x4
    // 0xb60fa4: r2 = Null
    //     0xb60fa4: mov             x2, NULL
    // 0xb60fa8: r1 = Null
    //     0xb60fa8: mov             x1, NULL
    // 0xb60fac: r4 = 60
    //     0xb60fac: mov             x4, #0x3c
    // 0xb60fb0: branchIfSmi(r0, 0xb60fbc)
    //     0xb60fb0: tbz             w0, #0, #0xb60fbc
    // 0xb60fb4: r4 = LoadClassIdInstr(r0)
    //     0xb60fb4: ldur            x4, [x0, #-1]
    //     0xb60fb8: ubfx            x4, x4, #0xc, #0x14
    // 0xb60fbc: sub             x4, x4, #0xb46
    // 0xb60fc0: cmp             x4, #1
    // 0xb60fc4: b.ls            #0xb60fd8
    // 0xb60fc8: r8 = BoxConstraints
    //     0xb60fc8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60fcc: r3 = Null
    //     0xb60fcc: add             x3, PP, #0x98, lsl #12  ; [pp+0x98538] Null
    //     0xb60fd0: ldr             x3, [x3, #0x538]
    // 0xb60fd4: r0 = BoxConstraints()
    //     0xb60fd4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb60fd8: ldur            x1, [fp, #-8]
    // 0xb60fdc: LoadField: r0 = r1->field_4f
    //     0xb60fdc: ldur            w0, [x1, #0x4f]
    // 0xb60fe0: DecompressPointer r0
    //     0xb60fe0: add             x0, x0, HEAP, lsl #32
    // 0xb60fe4: stur            x0, [fp, #-0x20]
    // 0xb60fe8: cmp             w0, NULL
    // 0xb60fec: b.ne            #0xb61000
    // 0xb60ff0: r0 = Null
    //     0xb60ff0: mov             x0, NULL
    // 0xb60ff4: LeaveFrame
    //     0xb60ff4: mov             SP, fp
    //     0xb60ff8: ldp             fp, lr, [SP], #0x10
    // 0xb60ffc: ret
    //     0xb60ffc: ret             
    // 0xb61000: r0 = _resolvedPadding()
    //     0xb61000: bl              #0xb17364  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolvedPadding
    // 0xb61004: ldur            x1, [fp, #-0x10]
    // 0xb61008: mov             x2, x0
    // 0xb6100c: stur            x0, [fp, #-8]
    // 0xb61010: r0 = deflate()
    //     0xb61010: bl              #0xb4cd58  ; [package:flutter/src/rendering/box.dart] BoxConstraints::deflate
    // 0xb61014: ldur            x1, [fp, #-0x20]
    // 0xb61018: mov             x2, x0
    // 0xb6101c: ldur            x3, [fp, #-0x18]
    // 0xb61020: r0 = getDryBaseline()
    //     0xb61020: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb61024: cmp             w0, NULL
    // 0xb61028: b.ne            #0xb6103c
    // 0xb6102c: r0 = Null
    //     0xb6102c: mov             x0, NULL
    // 0xb61030: LeaveFrame
    //     0xb61030: mov             SP, fp
    //     0xb61034: ldp             fp, lr, [SP], #0x10
    // 0xb61038: ret
    //     0xb61038: ret             
    // 0xb6103c: ldur            x1, [fp, #-8]
    // 0xb61040: LoadField: d0 = r1->field_f
    //     0xb61040: ldur            d0, [x1, #0xf]
    // 0xb61044: LoadField: d1 = r0->field_7
    //     0xb61044: ldur            d1, [x0, #7]
    // 0xb61048: fadd            d2, d1, d0
    // 0xb6104c: r0 = inline_Allocate_Double()
    //     0xb6104c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb61050: add             x0, x0, #0x10
    //     0xb61054: cmp             x1, x0
    //     0xb61058: b.ls            #0xb6108c
    //     0xb6105c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb61060: sub             x0, x0, #0xf
    //     0xb61064: mov             x1, #0xe19c
    //     0xb61068: movk            x1, #3, lsl #16
    //     0xb6106c: stur            x1, [x0, #-1]
    // 0xb61070: dmb             ishst
    // 0xb61074: StoreField: r0->field_7 = d2
    //     0xb61074: stur            d2, [x0, #7]
    // 0xb61078: LeaveFrame
    //     0xb61078: mov             SP, fp
    //     0xb6107c: ldp             fp, lr, [SP], #0x10
    // 0xb61080: ret
    //     0xb61080: ret             
    // 0xb61084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb61084: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb61088: b               #0xb60fa0
    // 0xb6108c: SaveReg d2
    //     0xb6108c: str             q2, [SP, #-0x10]!
    // 0xb61090: r0 = AllocateDouble()
    //     0xb61090: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb61094: RestoreReg d2
    //     0xb61094: ldr             q2, [SP], #0x10
    // 0xb61098: b               #0xb61074
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbce40, size: 0x2e4
    // 0xbbce40: EnterFrame
    //     0xbbce40: stp             fp, lr, [SP, #-0x10]!
    //     0xbbce44: mov             fp, SP
    // 0xbbce48: AllocStack(0x40)
    //     0xbbce48: sub             SP, SP, #0x40
    // 0xbbce4c: SetupParameters(RenderPadding this /* r1 => r3, fp-0x10 */)
    //     0xbbce4c: mov             x3, x1
    //     0xbbce50: stur            x1, [fp, #-0x10]
    // 0xbbce54: CheckStackOverflow
    //     0xbbce54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbce58: cmp             SP, x16
    //     0xbbce5c: b.ls            #0xbbd108
    // 0xbbce60: LoadField: r4 = r3->field_27
    //     0xbbce60: ldur            w4, [x3, #0x27]
    // 0xbbce64: DecompressPointer r4
    //     0xbbce64: add             x4, x4, HEAP, lsl #32
    // 0xbbce68: stur            x4, [fp, #-8]
    // 0xbbce6c: cmp             w4, NULL
    // 0xbbce70: b.eq            #0xbbd0ec
    // 0xbbce74: mov             x0, x4
    // 0xbbce78: r2 = Null
    //     0xbbce78: mov             x2, NULL
    // 0xbbce7c: r1 = Null
    //     0xbbce7c: mov             x1, NULL
    // 0xbbce80: r4 = LoadClassIdInstr(r0)
    //     0xbbce80: ldur            x4, [x0, #-1]
    //     0xbbce84: ubfx            x4, x4, #0xc, #0x14
    // 0xbbce88: sub             x4, x4, #0xb46
    // 0xbbce8c: cmp             x4, #1
    // 0xbbce90: b.ls            #0xbbcea4
    // 0xbbce94: r8 = BoxConstraints
    //     0xbbce94: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbce98: r3 = Null
    //     0xbbce98: add             x3, PP, #0x81, lsl #12  ; [pp+0x81ce8] Null
    //     0xbbce9c: ldr             x3, [x3, #0xce8]
    // 0xbbcea0: r0 = BoxConstraints()
    //     0xbbcea0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbcea4: ldur            x1, [fp, #-0x10]
    // 0xbbcea8: r0 = _resolvedPadding()
    //     0xbbcea8: bl              #0xb17364  ; [package:flutter/src/rendering/shifted_box.dart] RenderPadding::_resolvedPadding
    // 0xbbceac: mov             x2, x0
    // 0xbbceb0: ldur            x0, [fp, #-0x10]
    // 0xbbceb4: stur            x2, [fp, #-0x18]
    // 0xbbceb8: LoadField: r1 = r0->field_4f
    //     0xbbceb8: ldur            w1, [x0, #0x4f]
    // 0xbbcebc: DecompressPointer r1
    //     0xbbcebc: add             x1, x1, HEAP, lsl #32
    // 0xbbcec0: cmp             w1, NULL
    // 0xbbcec4: b.ne            #0xbbcf30
    // 0xbbcec8: mov             x1, x2
    // 0xbbcecc: r0 = horizontal()
    //     0xbbcecc: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xbbced0: ldur            x1, [fp, #-0x18]
    // 0xbbced4: stur            d0, [fp, #-0x28]
    // 0xbbced8: r0 = vertical()
    //     0xbbced8: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xbbcedc: stur            d0, [fp, #-0x30]
    // 0xbbcee0: r0 = Size()
    //     0xbbcee0: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbcee4: ldur            d0, [fp, #-0x28]
    // 0xbbcee8: StoreField: r0->field_7 = d0
    //     0xbbcee8: stur            d0, [x0, #7]
    // 0xbbceec: ldur            d0, [fp, #-0x30]
    // 0xbbcef0: StoreField: r0->field_f = d0
    //     0xbbcef0: stur            d0, [x0, #0xf]
    // 0xbbcef4: ldur            x1, [fp, #-8]
    // 0xbbcef8: mov             x2, x0
    // 0xbbcefc: r0 = constrain()
    //     0xbbcefc: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbcf00: ldur            x3, [fp, #-0x10]
    // 0xbbcf04: StoreField: r3->field_4b = r0
    //     0xbbcf04: stur            w0, [x3, #0x4b]
    //     0xbbcf08: ldurb           w16, [x3, #-1]
    //     0xbbcf0c: ldurb           w17, [x0, #-1]
    //     0xbbcf10: and             x16, x17, x16, lsr #2
    //     0xbbcf14: tst             x16, HEAP, lsr #32
    //     0xbbcf18: b.eq            #0xbbcf20
    //     0xbbcf1c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbcf20: r0 = Null
    //     0xbbcf20: mov             x0, NULL
    // 0xbbcf24: LeaveFrame
    //     0xbbcf24: mov             SP, fp
    //     0xbbcf28: ldp             fp, lr, [SP], #0x10
    // 0xbbcf2c: ret
    //     0xbbcf2c: ret             
    // 0xbbcf30: mov             x3, x0
    // 0xbbcf34: mov             x0, x2
    // 0xbbcf38: ldur            x1, [fp, #-8]
    // 0xbbcf3c: mov             x2, x0
    // 0xbbcf40: r0 = deflate()
    //     0xbbcf40: bl              #0xb4cd58  ; [package:flutter/src/rendering/box.dart] BoxConstraints::deflate
    // 0xbbcf44: ldur            x3, [fp, #-0x10]
    // 0xbbcf48: LoadField: r1 = r3->field_4f
    //     0xbbcf48: ldur            w1, [x3, #0x4f]
    // 0xbbcf4c: DecompressPointer r1
    //     0xbbcf4c: add             x1, x1, HEAP, lsl #32
    // 0xbbcf50: cmp             w1, NULL
    // 0xbbcf54: b.eq            #0xbbd110
    // 0xbbcf58: r2 = LoadClassIdInstr(r1)
    //     0xbbcf58: ldur            x2, [x1, #-1]
    //     0xbbcf5c: ubfx            x2, x2, #0xc, #0x14
    // 0xbbcf60: r16 = true
    //     0xbbcf60: add             x16, NULL, #0x20  ; true
    // 0xbbcf64: str             x16, [SP]
    // 0xbbcf68: mov             x16, x0
    // 0xbbcf6c: mov             x0, x2
    // 0xbbcf70: mov             x2, x16
    // 0xbbcf74: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbcf74: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbcf78: ldr             x4, [x4, #0xed0]
    // 0xbbcf7c: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbcf7c: mov             x17, #0xe6b9
    //     0xbbcf80: add             lr, x0, x17
    //     0xbbcf84: ldr             lr, [x21, lr, lsl #3]
    //     0xbbcf88: blr             lr
    // 0xbbcf8c: ldur            x3, [fp, #-0x10]
    // 0xbbcf90: LoadField: r0 = r3->field_4f
    //     0xbbcf90: ldur            w0, [x3, #0x4f]
    // 0xbbcf94: DecompressPointer r0
    //     0xbbcf94: add             x0, x0, HEAP, lsl #32
    // 0xbbcf98: cmp             w0, NULL
    // 0xbbcf9c: b.eq            #0xbbd114
    // 0xbbcfa0: LoadField: r4 = r0->field_7
    //     0xbbcfa0: ldur            w4, [x0, #7]
    // 0xbbcfa4: DecompressPointer r4
    //     0xbbcfa4: add             x4, x4, HEAP, lsl #32
    // 0xbbcfa8: stur            x4, [fp, #-0x20]
    // 0xbbcfac: cmp             w4, NULL
    // 0xbbcfb0: b.eq            #0xbbd118
    // 0xbbcfb4: mov             x0, x4
    // 0xbbcfb8: r2 = Null
    //     0xbbcfb8: mov             x2, NULL
    // 0xbbcfbc: r1 = Null
    //     0xbbcfbc: mov             x1, NULL
    // 0xbbcfc0: r4 = LoadClassIdInstr(r0)
    //     0xbbcfc0: ldur            x4, [x0, #-1]
    //     0xbbcfc4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbcfc8: r17 = -4190
    //     0xbbcfc8: mov             x17, #-0x105e
    // 0xbbcfcc: add             x4, x4, x17
    // 0xbbcfd0: cmp             x4, #0x17
    // 0xbbcfd4: b.ls            #0xbbcfec
    // 0xbbcfd8: r8 = BoxParentData
    //     0xbbcfd8: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbcfdc: ldr             x8, [x8, #0x5e8]
    // 0xbbcfe0: r3 = Null
    //     0xbbcfe0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81cf8] Null
    //     0xbbcfe4: ldr             x3, [x3, #0xcf8]
    // 0xbbcfe8: r0 = DefaultTypeTest()
    //     0xbbcfe8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbcfec: ldur            x1, [fp, #-0x18]
    // 0xbbcff0: LoadField: d0 = r1->field_7
    //     0xbbcff0: ldur            d0, [x1, #7]
    // 0xbbcff4: stur            d0, [fp, #-0x30]
    // 0xbbcff8: LoadField: d1 = r1->field_f
    //     0xbbcff8: ldur            d1, [x1, #0xf]
    // 0xbbcffc: stur            d1, [fp, #-0x28]
    // 0xbbd000: r0 = Offset()
    //     0xbbd000: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbbd004: ldur            d0, [fp, #-0x30]
    // 0xbbd008: StoreField: r0->field_7 = d0
    //     0xbbd008: stur            d0, [x0, #7]
    // 0xbbd00c: ldur            d0, [fp, #-0x28]
    // 0xbbd010: StoreField: r0->field_f = d0
    //     0xbbd010: stur            d0, [x0, #0xf]
    // 0xbbd014: ldur            x1, [fp, #-0x20]
    // 0xbbd018: StoreField: r1->field_7 = r0
    //     0xbbd018: stur            w0, [x1, #7]
    //     0xbbd01c: ldurb           w16, [x1, #-1]
    //     0xbbd020: ldurb           w17, [x0, #-1]
    //     0xbbd024: and             x16, x17, x16, lsr #2
    //     0xbbd028: tst             x16, HEAP, lsr #32
    //     0xbbd02c: b.eq            #0xbbd034
    //     0xbbd030: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbd034: ldur            x1, [fp, #-0x18]
    // 0xbbd038: r0 = horizontal()
    //     0xbbd038: bl              #0xb17264  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::horizontal
    // 0xbbd03c: ldur            x0, [fp, #-0x10]
    // 0xbbd040: stur            d0, [fp, #-0x28]
    // 0xbbd044: LoadField: r1 = r0->field_4f
    //     0xbbd044: ldur            w1, [x0, #0x4f]
    // 0xbbd048: DecompressPointer r1
    //     0xbbd048: add             x1, x1, HEAP, lsl #32
    // 0xbbd04c: cmp             w1, NULL
    // 0xbbd050: b.eq            #0xbbd11c
    // 0xbbd054: r0 = size()
    //     0xbbd054: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbd058: LoadField: d0 = r0->field_7
    //     0xbbd058: ldur            d0, [x0, #7]
    // 0xbbd05c: ldur            d1, [fp, #-0x28]
    // 0xbbd060: fadd            d2, d1, d0
    // 0xbbd064: ldur            x1, [fp, #-0x18]
    // 0xbbd068: stur            d2, [fp, #-0x30]
    // 0xbbd06c: r0 = vertical()
    //     0xbbd06c: bl              #0xb1730c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::vertical
    // 0xbbd070: ldur            x0, [fp, #-0x10]
    // 0xbbd074: stur            d0, [fp, #-0x28]
    // 0xbbd078: LoadField: r1 = r0->field_4f
    //     0xbbd078: ldur            w1, [x0, #0x4f]
    // 0xbbd07c: DecompressPointer r1
    //     0xbbd07c: add             x1, x1, HEAP, lsl #32
    // 0xbbd080: cmp             w1, NULL
    // 0xbbd084: b.eq            #0xbbd120
    // 0xbbd088: r0 = size()
    //     0xbbd088: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbd08c: LoadField: d0 = r0->field_f
    //     0xbbd08c: ldur            d0, [x0, #0xf]
    // 0xbbd090: ldur            d1, [fp, #-0x28]
    // 0xbbd094: fadd            d2, d1, d0
    // 0xbbd098: stur            d2, [fp, #-0x38]
    // 0xbbd09c: r0 = Size()
    //     0xbbd09c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbd0a0: ldur            d0, [fp, #-0x30]
    // 0xbbd0a4: StoreField: r0->field_7 = d0
    //     0xbbd0a4: stur            d0, [x0, #7]
    // 0xbbd0a8: ldur            d0, [fp, #-0x38]
    // 0xbbd0ac: StoreField: r0->field_f = d0
    //     0xbbd0ac: stur            d0, [x0, #0xf]
    // 0xbbd0b0: ldur            x1, [fp, #-8]
    // 0xbbd0b4: mov             x2, x0
    // 0xbbd0b8: r0 = constrain()
    //     0xbbd0b8: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbd0bc: ldur            x1, [fp, #-0x10]
    // 0xbbd0c0: StoreField: r1->field_4b = r0
    //     0xbbd0c0: stur            w0, [x1, #0x4b]
    //     0xbbd0c4: ldurb           w16, [x1, #-1]
    //     0xbbd0c8: ldurb           w17, [x0, #-1]
    //     0xbbd0cc: and             x16, x17, x16, lsr #2
    //     0xbbd0d0: tst             x16, HEAP, lsr #32
    //     0xbbd0d4: b.eq            #0xbbd0dc
    //     0xbbd0d8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbd0dc: r0 = Null
    //     0xbbd0dc: mov             x0, NULL
    // 0xbbd0e0: LeaveFrame
    //     0xbbd0e0: mov             SP, fp
    //     0xbbd0e4: ldp             fp, lr, [SP], #0x10
    // 0xbbd0e8: ret
    //     0xbbd0e8: ret             
    // 0xbbd0ec: r0 = StateError()
    //     0xbbd0ec: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbd0f0: mov             x1, x0
    // 0xbbd0f4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbd0f4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbd0f8: StoreField: r1->field_b = r0
    //     0xbbd0f8: stur            w0, [x1, #0xb]
    // 0xbbd0fc: mov             x0, x1
    // 0xbbd100: r0 = Throw()
    //     0xbbd100: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbd104: brk             #0
    // 0xbbd108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbd108: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbd10c: b               #0xbbce60
    // 0xbbd110: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbd110: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbd114: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbd114: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbd118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbd118: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbd11c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbd11c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbbd120: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbd120: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcf7a94, size: 0x70
    // 0xcf7a94: EnterFrame
    //     0xcf7a94: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7a98: mov             fp, SP
    // 0xcf7a9c: mov             x0, x2
    // 0xcf7aa0: CheckStackOverflow
    //     0xcf7aa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7aa4: cmp             SP, x16
    //     0xcf7aa8: b.ls            #0xcf7afc
    // 0xcf7aac: LoadField: r2 = r1->field_5b
    //     0xcf7aac: ldur            w2, [x1, #0x5b]
    // 0xcf7ab0: DecompressPointer r2
    //     0xcf7ab0: add             x2, x2, HEAP, lsl #32
    // 0xcf7ab4: cmp             w2, w0
    // 0xcf7ab8: b.ne            #0xcf7acc
    // 0xcf7abc: r0 = Null
    //     0xcf7abc: mov             x0, NULL
    // 0xcf7ac0: LeaveFrame
    //     0xcf7ac0: mov             SP, fp
    //     0xcf7ac4: ldp             fp, lr, [SP], #0x10
    // 0xcf7ac8: ret
    //     0xcf7ac8: ret             
    // 0xcf7acc: StoreField: r1->field_5b = r0
    //     0xcf7acc: stur            w0, [x1, #0x5b]
    //     0xcf7ad0: ldurb           w16, [x1, #-1]
    //     0xcf7ad4: ldurb           w17, [x0, #-1]
    //     0xcf7ad8: and             x16, x17, x16, lsr #2
    //     0xcf7adc: tst             x16, HEAP, lsr #32
    //     0xcf7ae0: b.eq            #0xcf7ae8
    //     0xcf7ae4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf7ae8: r0 = _markNeedResolution()
    //     0xcf7ae8: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf7aec: r0 = Null
    //     0xcf7aec: mov             x0, NULL
    // 0xcf7af0: LeaveFrame
    //     0xcf7af0: mov             SP, fp
    //     0xcf7af4: ldp             fp, lr, [SP], #0x10
    // 0xcf7af8: ret
    //     0xcf7af8: ret             
    // 0xcf7afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7afc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7b00: b               #0xcf7aac
  }
  set _ padding=(/* No info */) {
    // ** addr: 0xcf7b04, size: 0x88
    // 0xcf7b04: EnterFrame
    //     0xcf7b04: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7b08: mov             fp, SP
    // 0xcf7b0c: AllocStack(0x20)
    //     0xcf7b0c: sub             SP, SP, #0x20
    // 0xcf7b10: SetupParameters(RenderPadding this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf7b10: mov             x0, x2
    //     0xcf7b14: stur            x1, [fp, #-8]
    //     0xcf7b18: stur            x2, [fp, #-0x10]
    // 0xcf7b1c: CheckStackOverflow
    //     0xcf7b1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7b20: cmp             SP, x16
    //     0xcf7b24: b.ls            #0xcf7b84
    // 0xcf7b28: LoadField: r2 = r1->field_57
    //     0xcf7b28: ldur            w2, [x1, #0x57]
    // 0xcf7b2c: DecompressPointer r2
    //     0xcf7b2c: add             x2, x2, HEAP, lsl #32
    // 0xcf7b30: stp             x0, x2, [SP]
    // 0xcf7b34: r0 = ==()
    //     0xcf7b34: bl              #0x1298c8c  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0xcf7b38: tbnz            w0, #4, #0xcf7b4c
    // 0xcf7b3c: r0 = Null
    //     0xcf7b3c: mov             x0, NULL
    // 0xcf7b40: LeaveFrame
    //     0xcf7b40: mov             SP, fp
    //     0xcf7b44: ldp             fp, lr, [SP], #0x10
    // 0xcf7b48: ret
    //     0xcf7b48: ret             
    // 0xcf7b4c: ldur            x1, [fp, #-8]
    // 0xcf7b50: ldur            x0, [fp, #-0x10]
    // 0xcf7b54: StoreField: r1->field_57 = r0
    //     0xcf7b54: stur            w0, [x1, #0x57]
    //     0xcf7b58: ldurb           w16, [x1, #-1]
    //     0xcf7b5c: ldurb           w17, [x0, #-1]
    //     0xcf7b60: and             x16, x17, x16, lsr #2
    //     0xcf7b64: tst             x16, HEAP, lsr #32
    //     0xcf7b68: b.eq            #0xcf7b70
    //     0xcf7b6c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf7b70: r0 = _markNeedResolution()
    //     0xcf7b70: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf7b74: r0 = Null
    //     0xcf7b74: mov             x0, NULL
    // 0xcf7b78: LeaveFrame
    //     0xcf7b78: mov             SP, fp
    //     0xcf7b7c: ldp             fp, lr, [SP], #0x10
    // 0xcf7b80: ret
    //     0xcf7b80: ret             
    // 0xcf7b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7b84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7b88: b               #0xcf7b28
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efd54, size: 0x24
    // 0x10efd54: EnterFrame
    //     0x10efd54: stp             fp, lr, [SP, #-0x10]!
    //     0x10efd58: mov             fp, SP
    // 0x10efd5c: ldr             x2, [fp, #0x10]
    // 0x10efd60: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efd60: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa28c8] AnonymousClosure: (0xb23434), in [package:flutter/src/rendering/shifted_box.dart] RenderPadding::computeMinIntrinsicHeight (0xb23378)
    //     0x10efd64: ldr             x1, [x1, #0x8c8]
    // 0x10efd68: r0 = AllocateClosure()
    //     0x10efd68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efd6c: LeaveFrame
    //     0x10efd6c: mov             SP, fp
    //     0x10efd70: ldp             fp, lr, [SP], #0x10
    // 0x10efd74: ret
    //     0x10efd74: ret             
  }
}

// class id: 4883, size: 0x60, field offset: 0x54
abstract class RenderAligningShiftedBox extends RenderShiftedBox {

  get _ resolvedAlignment(/* No info */) {
    // ** addr: 0xb5fd7c, size: 0x17c
    // 0xb5fd7c: EnterFrame
    //     0xb5fd7c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5fd80: mov             fp, SP
    // 0xb5fd84: AllocStack(0x18)
    //     0xb5fd84: sub             SP, SP, #0x18
    // 0xb5fd88: SetupParameters(RenderAligningShiftedBox this /* r1 => r1, fp-0x8 */)
    //     0xb5fd88: stur            x1, [fp, #-8]
    // 0xb5fd8c: LoadField: r0 = r1->field_53
    //     0xb5fd8c: ldur            w0, [x1, #0x53]
    // 0xb5fd90: DecompressPointer r0
    //     0xb5fd90: add             x0, x0, HEAP, lsl #32
    // 0xb5fd94: cmp             w0, NULL
    // 0xb5fd98: b.ne            #0xb5fee4
    // 0xb5fd9c: LoadField: r0 = r1->field_57
    //     0xb5fd9c: ldur            w0, [x1, #0x57]
    // 0xb5fda0: DecompressPointer r0
    //     0xb5fda0: add             x0, x0, HEAP, lsl #32
    // 0xb5fda4: LoadField: r2 = r1->field_5b
    //     0xb5fda4: ldur            w2, [x1, #0x5b]
    // 0xb5fda8: DecompressPointer r2
    //     0xb5fda8: add             x2, x2, HEAP, lsl #32
    // 0xb5fdac: r3 = LoadClassIdInstr(r0)
    //     0xb5fdac: ldur            x3, [x0, #-1]
    //     0xb5fdb0: ubfx            x3, x3, #0xc, #0x14
    // 0xb5fdb4: sub             x16, x3, #0xb8e
    // 0xb5fdb8: cmp             x16, #1
    // 0xb5fdbc: b.hi            #0xb5fdc8
    // 0xb5fdc0: mov             x2, x0
    // 0xb5fdc4: b               #0xb5fec0
    // 0xb5fdc8: cmp             x3, #0xb8c
    // 0xb5fdcc: b.ne            #0xb5fe4c
    // 0xb5fdd0: cmp             w2, NULL
    // 0xb5fdd4: b.eq            #0xb5fef0
    // 0xb5fdd8: LoadField: r3 = r2->field_7
    //     0xb5fdd8: ldur            x3, [x2, #7]
    // 0xb5fddc: cmp             x3, #0
    // 0xb5fde0: b.gt            #0xb5fe14
    // 0xb5fde4: LoadField: d0 = r0->field_7
    //     0xb5fde4: ldur            d0, [x0, #7]
    // 0xb5fde8: LoadField: d1 = r0->field_f
    //     0xb5fde8: ldur            d1, [x0, #0xf]
    // 0xb5fdec: fsub            d2, d0, d1
    // 0xb5fdf0: stur            d2, [fp, #-0x18]
    // 0xb5fdf4: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xb5fdf4: ldur            d0, [x0, #0x17]
    // 0xb5fdf8: stur            d0, [fp, #-0x10]
    // 0xb5fdfc: r0 = Alignment()
    //     0xb5fdfc: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xb5fe00: ldur            d0, [fp, #-0x18]
    // 0xb5fe04: StoreField: r0->field_7 = d0
    //     0xb5fe04: stur            d0, [x0, #7]
    // 0xb5fe08: ldur            d0, [fp, #-0x10]
    // 0xb5fe0c: StoreField: r0->field_f = d0
    //     0xb5fe0c: stur            d0, [x0, #0xf]
    // 0xb5fe10: b               #0xb5fe40
    // 0xb5fe14: LoadField: d0 = r0->field_7
    //     0xb5fe14: ldur            d0, [x0, #7]
    // 0xb5fe18: LoadField: d1 = r0->field_f
    //     0xb5fe18: ldur            d1, [x0, #0xf]
    // 0xb5fe1c: fadd            d2, d0, d1
    // 0xb5fe20: stur            d2, [fp, #-0x18]
    // 0xb5fe24: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xb5fe24: ldur            d0, [x0, #0x17]
    // 0xb5fe28: stur            d0, [fp, #-0x10]
    // 0xb5fe2c: r0 = Alignment()
    //     0xb5fe2c: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xb5fe30: ldur            d0, [fp, #-0x18]
    // 0xb5fe34: StoreField: r0->field_7 = d0
    //     0xb5fe34: stur            d0, [x0, #7]
    // 0xb5fe38: ldur            d0, [fp, #-0x10]
    // 0xb5fe3c: StoreField: r0->field_f = d0
    //     0xb5fe3c: stur            d0, [x0, #0xf]
    // 0xb5fe40: mov             x2, x0
    // 0xb5fe44: ldur            x1, [fp, #-8]
    // 0xb5fe48: b               #0xb5fec0
    // 0xb5fe4c: cmp             w2, NULL
    // 0xb5fe50: b.eq            #0xb5fef4
    // 0xb5fe54: LoadField: r1 = r2->field_7
    //     0xb5fe54: ldur            x1, [x2, #7]
    // 0xb5fe58: cmp             x1, #0
    // 0xb5fe5c: b.gt            #0xb5fe90
    // 0xb5fe60: LoadField: d0 = r0->field_7
    //     0xb5fe60: ldur            d0, [x0, #7]
    // 0xb5fe64: fneg            d1, d0
    // 0xb5fe68: stur            d1, [fp, #-0x18]
    // 0xb5fe6c: LoadField: d0 = r0->field_f
    //     0xb5fe6c: ldur            d0, [x0, #0xf]
    // 0xb5fe70: stur            d0, [fp, #-0x10]
    // 0xb5fe74: r0 = Alignment()
    //     0xb5fe74: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xb5fe78: ldur            d0, [fp, #-0x18]
    // 0xb5fe7c: StoreField: r0->field_7 = d0
    //     0xb5fe7c: stur            d0, [x0, #7]
    // 0xb5fe80: ldur            d0, [fp, #-0x10]
    // 0xb5fe84: StoreField: r0->field_f = d0
    //     0xb5fe84: stur            d0, [x0, #0xf]
    // 0xb5fe88: mov             x1, x0
    // 0xb5fe8c: b               #0xb5feb8
    // 0xb5fe90: LoadField: d0 = r0->field_7
    //     0xb5fe90: ldur            d0, [x0, #7]
    // 0xb5fe94: stur            d0, [fp, #-0x18]
    // 0xb5fe98: LoadField: d1 = r0->field_f
    //     0xb5fe98: ldur            d1, [x0, #0xf]
    // 0xb5fe9c: stur            d1, [fp, #-0x10]
    // 0xb5fea0: r0 = Alignment()
    //     0xb5fea0: bl              #0x82f51c  ; AllocateAlignmentStub -> Alignment (size=0x18)
    // 0xb5fea4: ldur            d0, [fp, #-0x18]
    // 0xb5fea8: StoreField: r0->field_7 = d0
    //     0xb5fea8: stur            d0, [x0, #7]
    // 0xb5feac: ldur            d0, [fp, #-0x10]
    // 0xb5feb0: StoreField: r0->field_f = d0
    //     0xb5feb0: stur            d0, [x0, #0xf]
    // 0xb5feb4: mov             x1, x0
    // 0xb5feb8: mov             x2, x1
    // 0xb5febc: ldur            x1, [fp, #-8]
    // 0xb5fec0: mov             x0, x2
    // 0xb5fec4: StoreField: r1->field_53 = r0
    //     0xb5fec4: stur            w0, [x1, #0x53]
    //     0xb5fec8: ldurb           w16, [x1, #-1]
    //     0xb5fecc: ldurb           w17, [x0, #-1]
    //     0xb5fed0: and             x16, x17, x16, lsr #2
    //     0xb5fed4: tst             x16, HEAP, lsr #32
    //     0xb5fed8: b.eq            #0xb5fee0
    //     0xb5fedc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb5fee0: mov             x0, x2
    // 0xb5fee4: LeaveFrame
    //     0xb5fee4: mov             SP, fp
    //     0xb5fee8: ldp             fp, lr, [SP], #0x10
    // 0xb5feec: ret
    //     0xb5feec: ret             
    // 0xb5fef0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5fef0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb5fef4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb5fef4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ alignChild(/* No info */) {
    // ** addr: 0xbbad50, size: 0x10c
    // 0xbbad50: EnterFrame
    //     0xbbad50: stp             fp, lr, [SP, #-0x10]!
    //     0xbbad54: mov             fp, SP
    // 0xbbad58: AllocStack(0x20)
    //     0xbbad58: sub             SP, SP, #0x20
    // 0xbbad5c: SetupParameters(RenderAligningShiftedBox this /* r1 => r3, fp-0x10 */)
    //     0xbbad5c: mov             x3, x1
    //     0xbbad60: stur            x1, [fp, #-0x10]
    // 0xbbad64: CheckStackOverflow
    //     0xbbad64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbad68: cmp             SP, x16
    //     0xbbad6c: b.ls            #0xbbae48
    // 0xbbad70: LoadField: r0 = r3->field_4f
    //     0xbbad70: ldur            w0, [x3, #0x4f]
    // 0xbbad74: DecompressPointer r0
    //     0xbbad74: add             x0, x0, HEAP, lsl #32
    // 0xbbad78: cmp             w0, NULL
    // 0xbbad7c: b.eq            #0xbbae50
    // 0xbbad80: LoadField: r4 = r0->field_7
    //     0xbbad80: ldur            w4, [x0, #7]
    // 0xbbad84: DecompressPointer r4
    //     0xbbad84: add             x4, x4, HEAP, lsl #32
    // 0xbbad88: stur            x4, [fp, #-8]
    // 0xbbad8c: cmp             w4, NULL
    // 0xbbad90: b.eq            #0xbbae54
    // 0xbbad94: mov             x0, x4
    // 0xbbad98: r2 = Null
    //     0xbbad98: mov             x2, NULL
    // 0xbbad9c: r1 = Null
    //     0xbbad9c: mov             x1, NULL
    // 0xbbada0: r4 = LoadClassIdInstr(r0)
    //     0xbbada0: ldur            x4, [x0, #-1]
    //     0xbbada4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbada8: r17 = -4190
    //     0xbbada8: mov             x17, #-0x105e
    // 0xbbadac: add             x4, x4, x17
    // 0xbbadb0: cmp             x4, #0x17
    // 0xbbadb4: b.ls            #0xbbadcc
    // 0xbbadb8: r8 = BoxParentData
    //     0xbbadb8: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbadbc: ldr             x8, [x8, #0x5e8]
    // 0xbbadc0: r3 = Null
    //     0xbbadc0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81cd8] Null
    //     0xbbadc4: ldr             x3, [x3, #0xcd8]
    // 0xbbadc8: r0 = DefaultTypeTest()
    //     0xbbadc8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbadcc: ldur            x1, [fp, #-0x10]
    // 0xbbadd0: r0 = resolvedAlignment()
    //     0xbbadd0: bl              #0xb5fd7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::resolvedAlignment
    // 0xbbadd4: ldur            x1, [fp, #-0x10]
    // 0xbbadd8: stur            x0, [fp, #-0x18]
    // 0xbbaddc: r0 = size()
    //     0xbbaddc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbade0: mov             x2, x0
    // 0xbbade4: ldur            x0, [fp, #-0x10]
    // 0xbbade8: stur            x2, [fp, #-0x20]
    // 0xbbadec: LoadField: r1 = r0->field_4f
    //     0xbbadec: ldur            w1, [x0, #0x4f]
    // 0xbbadf0: DecompressPointer r1
    //     0xbbadf0: add             x1, x1, HEAP, lsl #32
    // 0xbbadf4: cmp             w1, NULL
    // 0xbbadf8: b.eq            #0xbbae58
    // 0xbbadfc: r0 = size()
    //     0xbbadfc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbae00: ldur            x1, [fp, #-0x20]
    // 0xbbae04: mov             x2, x0
    // 0xbbae08: r0 = -()
    //     0xbbae08: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xbbae0c: ldur            x1, [fp, #-0x18]
    // 0xbbae10: mov             x2, x0
    // 0xbbae14: r0 = alongOffset()
    //     0xbbae14: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xbbae18: ldur            x1, [fp, #-8]
    // 0xbbae1c: StoreField: r1->field_7 = r0
    //     0xbbae1c: stur            w0, [x1, #7]
    //     0xbbae20: ldurb           w16, [x1, #-1]
    //     0xbbae24: ldurb           w17, [x0, #-1]
    //     0xbbae28: and             x16, x17, x16, lsr #2
    //     0xbbae2c: tst             x16, HEAP, lsr #32
    //     0xbbae30: b.eq            #0xbbae38
    //     0xbbae34: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbae38: r0 = Null
    //     0xbbae38: mov             x0, NULL
    // 0xbbae3c: LeaveFrame
    //     0xbbae3c: mov             SP, fp
    //     0xbbae40: ldp             fp, lr, [SP], #0x10
    // 0xbbae44: ret
    //     0xbbae44: ret             
    // 0xbbae48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbae48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbae4c: b               #0xbbad70
    // 0xbbae50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbae50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbae54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbae54: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbae58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbae58: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcf45d0, size: 0x70
    // 0xcf45d0: EnterFrame
    //     0xcf45d0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf45d4: mov             fp, SP
    // 0xcf45d8: mov             x0, x2
    // 0xcf45dc: CheckStackOverflow
    //     0xcf45dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf45e0: cmp             SP, x16
    //     0xcf45e4: b.ls            #0xcf4638
    // 0xcf45e8: LoadField: r2 = r1->field_5b
    //     0xcf45e8: ldur            w2, [x1, #0x5b]
    // 0xcf45ec: DecompressPointer r2
    //     0xcf45ec: add             x2, x2, HEAP, lsl #32
    // 0xcf45f0: cmp             w2, w0
    // 0xcf45f4: b.ne            #0xcf4608
    // 0xcf45f8: r0 = Null
    //     0xcf45f8: mov             x0, NULL
    // 0xcf45fc: LeaveFrame
    //     0xcf45fc: mov             SP, fp
    //     0xcf4600: ldp             fp, lr, [SP], #0x10
    // 0xcf4604: ret
    //     0xcf4604: ret             
    // 0xcf4608: StoreField: r1->field_5b = r0
    //     0xcf4608: stur            w0, [x1, #0x5b]
    //     0xcf460c: ldurb           w16, [x1, #-1]
    //     0xcf4610: ldurb           w17, [x0, #-1]
    //     0xcf4614: and             x16, x17, x16, lsr #2
    //     0xcf4618: tst             x16, HEAP, lsr #32
    //     0xcf461c: b.eq            #0xcf4624
    //     0xcf4620: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf4624: r0 = _markNeedResolution()
    //     0xcf4624: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf4628: r0 = Null
    //     0xcf4628: mov             x0, NULL
    // 0xcf462c: LeaveFrame
    //     0xcf462c: mov             SP, fp
    //     0xcf4630: ldp             fp, lr, [SP], #0x10
    // 0xcf4634: ret
    //     0xcf4634: ret             
    // 0xcf4638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4638: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf463c: b               #0xcf45e8
  }
  _ _markNeedResolution(/* No info */) {
    // ** addr: 0xcf4640, size: 0x34
    // 0xcf4640: EnterFrame
    //     0xcf4640: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4644: mov             fp, SP
    // 0xcf4648: CheckStackOverflow
    //     0xcf4648: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf464c: cmp             SP, x16
    //     0xcf4650: b.ls            #0xcf466c
    // 0xcf4654: StoreField: r1->field_53 = rNULL
    //     0xcf4654: stur            NULL, [x1, #0x53]
    // 0xcf4658: r0 = markNeedsLayout()
    //     0xcf4658: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf465c: r0 = Null
    //     0xcf465c: mov             x0, NULL
    // 0xcf4660: LeaveFrame
    //     0xcf4660: mov             SP, fp
    //     0xcf4664: ldp             fp, lr, [SP], #0x10
    // 0xcf4668: ret
    //     0xcf4668: ret             
    // 0xcf466c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf466c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4670: b               #0xcf4654
  }
  set _ alignment=(/* No info */) {
    // ** addr: 0xcf5338, size: 0x88
    // 0xcf5338: EnterFrame
    //     0xcf5338: stp             fp, lr, [SP, #-0x10]!
    //     0xcf533c: mov             fp, SP
    // 0xcf5340: AllocStack(0x20)
    //     0xcf5340: sub             SP, SP, #0x20
    // 0xcf5344: SetupParameters(RenderAligningShiftedBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf5344: mov             x0, x2
    //     0xcf5348: stur            x1, [fp, #-8]
    //     0xcf534c: stur            x2, [fp, #-0x10]
    // 0xcf5350: CheckStackOverflow
    //     0xcf5350: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf5354: cmp             SP, x16
    //     0xcf5358: b.ls            #0xcf53b8
    // 0xcf535c: LoadField: r2 = r1->field_57
    //     0xcf535c: ldur            w2, [x1, #0x57]
    // 0xcf5360: DecompressPointer r2
    //     0xcf5360: add             x2, x2, HEAP, lsl #32
    // 0xcf5364: stp             x0, x2, [SP]
    // 0xcf5368: r0 = ==()
    //     0xcf5368: bl              #0x1297efc  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::==
    // 0xcf536c: tbnz            w0, #4, #0xcf5380
    // 0xcf5370: r0 = Null
    //     0xcf5370: mov             x0, NULL
    // 0xcf5374: LeaveFrame
    //     0xcf5374: mov             SP, fp
    //     0xcf5378: ldp             fp, lr, [SP], #0x10
    // 0xcf537c: ret
    //     0xcf537c: ret             
    // 0xcf5380: ldur            x1, [fp, #-8]
    // 0xcf5384: ldur            x0, [fp, #-0x10]
    // 0xcf5388: StoreField: r1->field_57 = r0
    //     0xcf5388: stur            w0, [x1, #0x57]
    //     0xcf538c: ldurb           w16, [x1, #-1]
    //     0xcf5390: ldurb           w17, [x0, #-1]
    //     0xcf5394: and             x16, x17, x16, lsr #2
    //     0xcf5398: tst             x16, HEAP, lsr #32
    //     0xcf539c: b.eq            #0xcf53a4
    //     0xcf53a0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf53a4: r0 = _markNeedResolution()
    //     0xcf53a4: bl              #0xcf4640  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::_markNeedResolution
    // 0xcf53a8: r0 = Null
    //     0xcf53a8: mov             x0, NULL
    // 0xcf53ac: LeaveFrame
    //     0xcf53ac: mov             SP, fp
    //     0xcf53b0: ldp             fp, lr, [SP], #0x10
    // 0xcf53b4: ret
    //     0xcf53b4: ret             
    // 0xcf53b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf53b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf53bc: b               #0xcf535c
  }
}

// class id: 4884, size: 0x6c, field offset: 0x60
class RenderFractionallySizedOverflowBox extends RenderAligningShiftedBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16e38, size: 0x24
    // 0xb16e38: EnterFrame
    //     0xb16e38: stp             fp, lr, [SP, #-0x10]!
    //     0xb16e3c: mov             fp, SP
    // 0xb16e40: ldr             x2, [fp, #0x10]
    // 0xb16e44: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb16e44: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2808] AnonymousClosure: (0xb16e5c), in [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMinIntrinsicWidth (0xb16ed4)
    //     0xb16e48: ldr             x1, [x1, #0x808]
    // 0xb16e4c: r0 = AllocateClosure()
    //     0xb16e4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16e50: LeaveFrame
    //     0xb16e50: mov             SP, fp
    //     0xb16e54: ldp             fp, lr, [SP], #0x10
    // 0xb16e58: ret
    //     0xb16e58: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16e5c, size: 0x78
    // 0xb16e5c: EnterFrame
    //     0xb16e5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16e60: mov             fp, SP
    // 0xb16e64: ldr             x0, [fp, #0x18]
    // 0xb16e68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb16e68: ldur            w1, [x0, #0x17]
    // 0xb16e6c: DecompressPointer r1
    //     0xb16e6c: add             x1, x1, HEAP, lsl #32
    // 0xb16e70: CheckStackOverflow
    //     0xb16e70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16e74: cmp             SP, x16
    //     0xb16e78: b.ls            #0xb16ebc
    // 0xb16e7c: ldr             x2, [fp, #0x10]
    // 0xb16e80: r0 = computeMinIntrinsicWidth()
    //     0xb16e80: bl              #0xb16ed4  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMinIntrinsicWidth
    // 0xb16e84: r0 = inline_Allocate_Double()
    //     0xb16e84: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16e88: add             x0, x0, #0x10
    //     0xb16e8c: cmp             x1, x0
    //     0xb16e90: b.ls            #0xb16ec4
    //     0xb16e94: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16e98: sub             x0, x0, #0xf
    //     0xb16e9c: mov             x1, #0xe19c
    //     0xb16ea0: movk            x1, #3, lsl #16
    //     0xb16ea4: stur            x1, [x0, #-1]
    // 0xb16ea8: dmb             ishst
    // 0xb16eac: StoreField: r0->field_7 = d0
    //     0xb16eac: stur            d0, [x0, #7]
    // 0xb16eb0: LeaveFrame
    //     0xb16eb0: mov             SP, fp
    //     0xb16eb4: ldp             fp, lr, [SP], #0x10
    // 0xb16eb8: ret
    //     0xb16eb8: ret             
    // 0xb16ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16ebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16ec0: b               #0xb16e7c
    // 0xb16ec4: SaveReg d0
    //     0xb16ec4: str             q0, [SP, #-0x10]!
    // 0xb16ec8: r0 = AllocateDouble()
    //     0xb16ec8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16ecc: RestoreReg d0
    //     0xb16ecc: ldr             q0, [SP], #0x10
    // 0xb16ed0: b               #0xb16eac
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb16ed4, size: 0x68
    // 0xb16ed4: EnterFrame
    //     0xb16ed4: stp             fp, lr, [SP, #-0x10]!
    //     0xb16ed8: mov             fp, SP
    // 0xb16edc: CheckStackOverflow
    //     0xb16edc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16ee0: cmp             SP, x16
    //     0xb16ee4: b.ls            #0xb16f34
    // 0xb16ee8: LoadField: r0 = r1->field_4f
    //     0xb16ee8: ldur            w0, [x1, #0x4f]
    // 0xb16eec: DecompressPointer r0
    //     0xb16eec: add             x0, x0, HEAP, lsl #32
    // 0xb16ef0: cmp             w0, NULL
    // 0xb16ef4: b.ne            #0xb16f04
    // 0xb16ef8: r0 = computeMinIntrinsicWidth()
    //     0xb16ef8: bl              #0xb16174  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0xb16efc: mov             v2.16b, v0.16b
    // 0xb16f00: b               #0xb16f20
    // 0xb16f04: LoadField: d0 = r1->field_63
    //     0xb16f04: ldur            d0, [x1, #0x63]
    // 0xb16f08: LoadField: d1 = r2->field_7
    //     0xb16f08: ldur            d1, [x2, #7]
    // 0xb16f0c: fmul            d2, d1, d0
    // 0xb16f10: mov             x1, x0
    // 0xb16f14: mov             v0.16b, v2.16b
    // 0xb16f18: r0 = getMinIntrinsicWidth()
    //     0xb16f18: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb16f1c: mov             v2.16b, v0.16b
    // 0xb16f20: d1 = 1.000000
    //     0xb16f20: fmov            d1, #1.00000000
    // 0xb16f24: fdiv            d0, d2, d1
    // 0xb16f28: LeaveFrame
    //     0xb16f28: mov             SP, fp
    //     0xb16f2c: ldp             fp, lr, [SP], #0x10
    // 0xb16f30: ret
    //     0xb16f30: ret             
    // 0xb16f34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16f34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16f38: b               #0xb16ee8
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb231a8, size: 0x6c
    // 0xb231a8: EnterFrame
    //     0xb231a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb231ac: mov             fp, SP
    // 0xb231b0: AllocStack(0x8)
    //     0xb231b0: sub             SP, SP, #8
    // 0xb231b4: SetupParameters(RenderFractionallySizedOverflowBox this /* r1 => r0, fp-0x8 */)
    //     0xb231b4: mov             x0, x1
    //     0xb231b8: stur            x1, [fp, #-8]
    // 0xb231bc: CheckStackOverflow
    //     0xb231bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb231c0: cmp             SP, x16
    //     0xb231c4: b.ls            #0xb2320c
    // 0xb231c8: LoadField: r1 = r0->field_4f
    //     0xb231c8: ldur            w1, [x0, #0x4f]
    // 0xb231cc: DecompressPointer r1
    //     0xb231cc: add             x1, x1, HEAP, lsl #32
    // 0xb231d0: cmp             w1, NULL
    // 0xb231d4: b.ne            #0xb231e8
    // 0xb231d8: mov             x1, x0
    // 0xb231dc: r0 = computeMinIntrinsicHeight()
    //     0xb231dc: bl              #0xb23590  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMinIntrinsicHeight
    // 0xb231e0: mov             v1.16b, v0.16b
    // 0xb231e4: b               #0xb231f4
    // 0xb231e8: LoadField: d0 = r2->field_7
    //     0xb231e8: ldur            d0, [x2, #7]
    // 0xb231ec: r0 = getMinIntrinsicHeight()
    //     0xb231ec: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb231f0: mov             v1.16b, v0.16b
    // 0xb231f4: ldur            x0, [fp, #-8]
    // 0xb231f8: LoadField: d2 = r0->field_63
    //     0xb231f8: ldur            d2, [x0, #0x63]
    // 0xb231fc: fdiv            d0, d1, d2
    // 0xb23200: LeaveFrame
    //     0xb23200: mov             SP, fp
    //     0xb23204: ldp             fp, lr, [SP], #0x10
    // 0xb23208: ret
    //     0xb23208: ret             
    // 0xb2320c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2320c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23210: b               #0xb231c8
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb23214, size: 0x78
    // 0xb23214: EnterFrame
    //     0xb23214: stp             fp, lr, [SP, #-0x10]!
    //     0xb23218: mov             fp, SP
    // 0xb2321c: ldr             x0, [fp, #0x18]
    // 0xb23220: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb23220: ldur            w1, [x0, #0x17]
    // 0xb23224: DecompressPointer r1
    //     0xb23224: add             x1, x1, HEAP, lsl #32
    // 0xb23228: CheckStackOverflow
    //     0xb23228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2322c: cmp             SP, x16
    //     0xb23230: b.ls            #0xb23274
    // 0xb23234: ldr             x2, [fp, #0x10]
    // 0xb23238: r0 = computeMinIntrinsicHeight()
    //     0xb23238: bl              #0xb231a8  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMinIntrinsicHeight
    // 0xb2323c: r0 = inline_Allocate_Double()
    //     0xb2323c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23240: add             x0, x0, #0x10
    //     0xb23244: cmp             x1, x0
    //     0xb23248: b.ls            #0xb2327c
    //     0xb2324c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23250: sub             x0, x0, #0xf
    //     0xb23254: mov             x1, #0xe19c
    //     0xb23258: movk            x1, #3, lsl #16
    //     0xb2325c: stur            x1, [x0, #-1]
    // 0xb23260: dmb             ishst
    // 0xb23264: StoreField: r0->field_7 = d0
    //     0xb23264: stur            d0, [x0, #7]
    // 0xb23268: LeaveFrame
    //     0xb23268: mov             SP, fp
    //     0xb2326c: ldp             fp, lr, [SP], #0x10
    // 0xb23270: ret
    //     0xb23270: ret             
    // 0xb23274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23274: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23278: b               #0xb23234
    // 0xb2327c: SaveReg d0
    //     0xb2327c: str             q0, [SP, #-0x10]!
    // 0xb23280: r0 = AllocateDouble()
    //     0xb23280: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb23284: RestoreReg d0
    //     0xb23284: ldr             q0, [SP], #0x10
    // 0xb23288: b               #0xb23264
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb29dd4, size: 0x6c
    // 0xb29dd4: EnterFrame
    //     0xb29dd4: stp             fp, lr, [SP, #-0x10]!
    //     0xb29dd8: mov             fp, SP
    // 0xb29ddc: AllocStack(0x8)
    //     0xb29ddc: sub             SP, SP, #8
    // 0xb29de0: SetupParameters(RenderFractionallySizedOverflowBox this /* r1 => r0, fp-0x8 */)
    //     0xb29de0: mov             x0, x1
    //     0xb29de4: stur            x1, [fp, #-8]
    // 0xb29de8: CheckStackOverflow
    //     0xb29de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29dec: cmp             SP, x16
    //     0xb29df0: b.ls            #0xb29e38
    // 0xb29df4: LoadField: r1 = r0->field_4f
    //     0xb29df4: ldur            w1, [x0, #0x4f]
    // 0xb29df8: DecompressPointer r1
    //     0xb29df8: add             x1, x1, HEAP, lsl #32
    // 0xb29dfc: cmp             w1, NULL
    // 0xb29e00: b.ne            #0xb29e14
    // 0xb29e04: mov             x1, x0
    // 0xb29e08: r0 = computeMaxIntrinsicHeight()
    //     0xb29e08: bl              #0xb2a3e0  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicHeight
    // 0xb29e0c: mov             v1.16b, v0.16b
    // 0xb29e10: b               #0xb29e20
    // 0xb29e14: LoadField: d0 = r2->field_7
    //     0xb29e14: ldur            d0, [x2, #7]
    // 0xb29e18: r0 = getMaxIntrinsicHeight()
    //     0xb29e18: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb29e1c: mov             v1.16b, v0.16b
    // 0xb29e20: ldur            x0, [fp, #-8]
    // 0xb29e24: LoadField: d2 = r0->field_63
    //     0xb29e24: ldur            d2, [x0, #0x63]
    // 0xb29e28: fdiv            d0, d1, d2
    // 0xb29e2c: LeaveFrame
    //     0xb29e2c: mov             SP, fp
    //     0xb29e30: ldp             fp, lr, [SP], #0x10
    // 0xb29e34: ret
    //     0xb29e34: ret             
    // 0xb29e38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29e38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29e3c: b               #0xb29df4
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb29e40, size: 0x78
    // 0xb29e40: EnterFrame
    //     0xb29e40: stp             fp, lr, [SP, #-0x10]!
    //     0xb29e44: mov             fp, SP
    // 0xb29e48: ldr             x0, [fp, #0x18]
    // 0xb29e4c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb29e4c: ldur            w1, [x0, #0x17]
    // 0xb29e50: DecompressPointer r1
    //     0xb29e50: add             x1, x1, HEAP, lsl #32
    // 0xb29e54: CheckStackOverflow
    //     0xb29e54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29e58: cmp             SP, x16
    //     0xb29e5c: b.ls            #0xb29ea0
    // 0xb29e60: ldr             x2, [fp, #0x10]
    // 0xb29e64: r0 = computeMaxIntrinsicHeight()
    //     0xb29e64: bl              #0xb29dd4  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMaxIntrinsicHeight
    // 0xb29e68: r0 = inline_Allocate_Double()
    //     0xb29e68: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb29e6c: add             x0, x0, #0x10
    //     0xb29e70: cmp             x1, x0
    //     0xb29e74: b.ls            #0xb29ea8
    //     0xb29e78: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29e7c: sub             x0, x0, #0xf
    //     0xb29e80: mov             x1, #0xe19c
    //     0xb29e84: movk            x1, #3, lsl #16
    //     0xb29e88: stur            x1, [x0, #-1]
    // 0xb29e8c: dmb             ishst
    // 0xb29e90: StoreField: r0->field_7 = d0
    //     0xb29e90: stur            d0, [x0, #7]
    // 0xb29e94: LeaveFrame
    //     0xb29e94: mov             SP, fp
    //     0xb29e98: ldp             fp, lr, [SP], #0x10
    // 0xb29e9c: ret
    //     0xb29e9c: ret             
    // 0xb29ea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29ea0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29ea4: b               #0xb29e60
    // 0xb29ea8: SaveReg d0
    //     0xb29ea8: str             q0, [SP, #-0x10]!
    // 0xb29eac: r0 = AllocateDouble()
    //     0xb29eac: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29eb0: RestoreReg d0
    //     0xb29eb0: ldr             q0, [SP], #0x10
    // 0xb29eb4: b               #0xb29e90
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2d204, size: 0x68
    // 0xb2d204: EnterFrame
    //     0xb2d204: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d208: mov             fp, SP
    // 0xb2d20c: CheckStackOverflow
    //     0xb2d20c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d210: cmp             SP, x16
    //     0xb2d214: b.ls            #0xb2d264
    // 0xb2d218: LoadField: r0 = r1->field_4f
    //     0xb2d218: ldur            w0, [x1, #0x4f]
    // 0xb2d21c: DecompressPointer r0
    //     0xb2d21c: add             x0, x0, HEAP, lsl #32
    // 0xb2d220: cmp             w0, NULL
    // 0xb2d224: b.ne            #0xb2d234
    // 0xb2d228: r0 = computeMaxIntrinsicWidth()
    //     0xb2d228: bl              #0xb2d828  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicWidth
    // 0xb2d22c: mov             v2.16b, v0.16b
    // 0xb2d230: b               #0xb2d250
    // 0xb2d234: LoadField: d0 = r1->field_63
    //     0xb2d234: ldur            d0, [x1, #0x63]
    // 0xb2d238: LoadField: d1 = r2->field_7
    //     0xb2d238: ldur            d1, [x2, #7]
    // 0xb2d23c: fmul            d2, d1, d0
    // 0xb2d240: mov             x1, x0
    // 0xb2d244: mov             v0.16b, v2.16b
    // 0xb2d248: r0 = getMaxIntrinsicWidth()
    //     0xb2d248: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2d24c: mov             v2.16b, v0.16b
    // 0xb2d250: d1 = 1.000000
    //     0xb2d250: fmov            d1, #1.00000000
    // 0xb2d254: fdiv            d0, d2, d1
    // 0xb2d258: LeaveFrame
    //     0xb2d258: mov             SP, fp
    //     0xb2d25c: ldp             fp, lr, [SP], #0x10
    // 0xb2d260: ret
    //     0xb2d260: ret             
    // 0xb2d264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d264: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d268: b               #0xb2d218
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2d26c, size: 0x78
    // 0xb2d26c: EnterFrame
    //     0xb2d26c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d270: mov             fp, SP
    // 0xb2d274: ldr             x0, [fp, #0x18]
    // 0xb2d278: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2d278: ldur            w1, [x0, #0x17]
    // 0xb2d27c: DecompressPointer r1
    //     0xb2d27c: add             x1, x1, HEAP, lsl #32
    // 0xb2d280: CheckStackOverflow
    //     0xb2d280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d284: cmp             SP, x16
    //     0xb2d288: b.ls            #0xb2d2cc
    // 0xb2d28c: ldr             x2, [fp, #0x10]
    // 0xb2d290: r0 = computeMaxIntrinsicWidth()
    //     0xb2d290: bl              #0xb2d204  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMaxIntrinsicWidth
    // 0xb2d294: r0 = inline_Allocate_Double()
    //     0xb2d294: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2d298: add             x0, x0, #0x10
    //     0xb2d29c: cmp             x1, x0
    //     0xb2d2a0: b.ls            #0xb2d2d4
    //     0xb2d2a4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2d2a8: sub             x0, x0, #0xf
    //     0xb2d2ac: mov             x1, #0xe19c
    //     0xb2d2b0: movk            x1, #3, lsl #16
    //     0xb2d2b4: stur            x1, [x0, #-1]
    // 0xb2d2b8: dmb             ishst
    // 0xb2d2bc: StoreField: r0->field_7 = d0
    //     0xb2d2bc: stur            d0, [x0, #7]
    // 0xb2d2c0: LeaveFrame
    //     0xb2d2c0: mov             SP, fp
    //     0xb2d2c4: ldp             fp, lr, [SP], #0x10
    // 0xb2d2c8: ret
    //     0xb2d2c8: ret             
    // 0xb2d2cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d2cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d2d0: b               #0xb2d28c
    // 0xb2d2d4: SaveReg d0
    //     0xb2d2d4: str             q0, [SP, #-0x10]!
    // 0xb2d2d8: r0 = AllocateDouble()
    //     0xb2d2d8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d2dc: RestoreReg d0
    //     0xb2d2dc: ldr             q0, [SP], #0x10
    // 0xb2d2e0: b               #0xb2d2bc
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4d6c8, size: 0x94
    // 0xb4d6c8: EnterFrame
    //     0xb4d6c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d6cc: mov             fp, SP
    // 0xb4d6d0: AllocStack(0x10)
    //     0xb4d6d0: sub             SP, SP, #0x10
    // 0xb4d6d4: SetupParameters(dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb4d6d4: mov             x0, x2
    //     0xb4d6d8: stur            x2, [fp, #-0x10]
    // 0xb4d6dc: CheckStackOverflow
    //     0xb4d6dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d6e0: cmp             SP, x16
    //     0xb4d6e4: b.ls            #0xb4d754
    // 0xb4d6e8: LoadField: r3 = r1->field_4f
    //     0xb4d6e8: ldur            w3, [x1, #0x4f]
    // 0xb4d6ec: DecompressPointer r3
    //     0xb4d6ec: add             x3, x3, HEAP, lsl #32
    // 0xb4d6f0: stur            x3, [fp, #-8]
    // 0xb4d6f4: cmp             w3, NULL
    // 0xb4d6f8: b.eq            #0xb4d728
    // 0xb4d6fc: mov             x2, x0
    // 0xb4d700: r0 = _getInnerConstraints()
    //     0xb4d700: bl              #0xb4d75c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0xb4d704: ldur            x1, [fp, #-8]
    // 0xb4d708: mov             x2, x0
    // 0xb4d70c: r0 = getDryLayout()
    //     0xb4d70c: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4d710: ldur            x1, [fp, #-0x10]
    // 0xb4d714: mov             x2, x0
    // 0xb4d718: r0 = constrain()
    //     0xb4d718: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d71c: LeaveFrame
    //     0xb4d71c: mov             SP, fp
    //     0xb4d720: ldp             fp, lr, [SP], #0x10
    // 0xb4d724: ret
    //     0xb4d724: ret             
    // 0xb4d728: ldur            x2, [fp, #-0x10]
    // 0xb4d72c: r0 = _getInnerConstraints()
    //     0xb4d72c: bl              #0xb4d75c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0xb4d730: mov             x1, x0
    // 0xb4d734: r2 = Instance_Size
    //     0xb4d734: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xb4d738: r0 = constrain()
    //     0xb4d738: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d73c: ldur            x1, [fp, #-0x10]
    // 0xb4d740: mov             x2, x0
    // 0xb4d744: r0 = constrain()
    //     0xb4d744: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d748: LeaveFrame
    //     0xb4d748: mov             SP, fp
    //     0xb4d74c: ldp             fp, lr, [SP], #0x10
    // 0xb4d750: ret
    //     0xb4d750: ret             
    // 0xb4d754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d754: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d758: b               #0xb4d6e8
  }
  _ _getInnerConstraints(/* No info */) {
    // ** addr: 0xb4d75c, size: 0x58
    // 0xb4d75c: EnterFrame
    //     0xb4d75c: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d760: mov             fp, SP
    // 0xb4d764: AllocStack(0x18)
    //     0xb4d764: sub             SP, SP, #0x18
    // 0xb4d768: LoadField: d0 = r2->field_7
    //     0xb4d768: ldur            d0, [x2, #7]
    // 0xb4d76c: stur            d0, [fp, #-0x18]
    // 0xb4d770: LoadField: d1 = r2->field_f
    //     0xb4d770: ldur            d1, [x2, #0xf]
    // 0xb4d774: stur            d1, [fp, #-0x10]
    // 0xb4d778: LoadField: d2 = r2->field_1f
    //     0xb4d778: ldur            d2, [x2, #0x1f]
    // 0xb4d77c: LoadField: d3 = r1->field_63
    //     0xb4d77c: ldur            d3, [x1, #0x63]
    // 0xb4d780: fmul            d4, d2, d3
    // 0xb4d784: stur            d4, [fp, #-8]
    // 0xb4d788: r0 = BoxConstraints()
    //     0xb4d788: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb4d78c: ldur            d0, [fp, #-0x18]
    // 0xb4d790: StoreField: r0->field_7 = d0
    //     0xb4d790: stur            d0, [x0, #7]
    // 0xb4d794: ldur            d0, [fp, #-0x10]
    // 0xb4d798: StoreField: r0->field_f = d0
    //     0xb4d798: stur            d0, [x0, #0xf]
    // 0xb4d79c: ldur            d0, [fp, #-8]
    // 0xb4d7a0: ArrayStore: r0[0] = d0  ; List_8
    //     0xb4d7a0: stur            d0, [x0, #0x17]
    // 0xb4d7a4: StoreField: r0->field_1f = d0
    //     0xb4d7a4: stur            d0, [x0, #0x1f]
    // 0xb4d7a8: LeaveFrame
    //     0xb4d7a8: mov             SP, fp
    //     0xb4d7ac: ldp             fp, lr, [SP], #0x10
    // 0xb4d7b0: ret
    //     0xb4d7b0: ret             
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb582b8, size: 0x24
    // 0xb582b8: EnterFrame
    //     0xb582b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb582bc: mov             fp, SP
    // 0xb582c0: ldr             x2, [fp, #0x10]
    // 0xb582c4: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb582c4: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2800] AnonymousClosure: (0xb2d26c), in [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMaxIntrinsicWidth (0xb2d204)
    //     0xb582c8: ldr             x1, [x1, #0x800]
    // 0xb582cc: r0 = AllocateClosure()
    //     0xb582cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb582d0: LeaveFrame
    //     0xb582d0: mov             SP, fp
    //     0xb582d4: ldp             fp, lr, [SP], #0x10
    // 0xb582d8: ret
    //     0xb582d8: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e440, size: 0x24
    // 0xb5e440: EnterFrame
    //     0xb5e440: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e444: mov             fp, SP
    // 0xb5e448: ldr             x2, [fp, #0x10]
    // 0xb5e44c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e44c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa27f0] AnonymousClosure: (0xb29e40), in [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMaxIntrinsicHeight (0xb29dd4)
    //     0xb5e450: ldr             x1, [x1, #0x7f0]
    // 0xb5e454: r0 = AllocateClosure()
    //     0xb5e454: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e458: LeaveFrame
    //     0xb5e458: mov             SP, fp
    //     0xb5e45c: ldp             fp, lr, [SP], #0x10
    // 0xb5e460: ret
    //     0xb5e460: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb6063c, size: 0x16c
    // 0xb6063c: EnterFrame
    //     0xb6063c: stp             fp, lr, [SP, #-0x10]!
    //     0xb60640: mov             fp, SP
    // 0xb60644: AllocStack(0x28)
    //     0xb60644: sub             SP, SP, #0x28
    // 0xb60648: SetupParameters(RenderFractionallySizedOverflowBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb60648: mov             x5, x1
    //     0xb6064c: mov             x4, x2
    //     0xb60650: stur            x1, [fp, #-8]
    //     0xb60654: stur            x2, [fp, #-0x10]
    //     0xb60658: stur            x3, [fp, #-0x18]
    // 0xb6065c: CheckStackOverflow
    //     0xb6065c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb60660: cmp             SP, x16
    //     0xb60664: b.ls            #0xb60790
    // 0xb60668: mov             x0, x4
    // 0xb6066c: r2 = Null
    //     0xb6066c: mov             x2, NULL
    // 0xb60670: r1 = Null
    //     0xb60670: mov             x1, NULL
    // 0xb60674: r4 = 60
    //     0xb60674: mov             x4, #0x3c
    // 0xb60678: branchIfSmi(r0, 0xb60684)
    //     0xb60678: tbz             w0, #0, #0xb60684
    // 0xb6067c: r4 = LoadClassIdInstr(r0)
    //     0xb6067c: ldur            x4, [x0, #-1]
    //     0xb60680: ubfx            x4, x4, #0xc, #0x14
    // 0xb60684: sub             x4, x4, #0xb46
    // 0xb60688: cmp             x4, #1
    // 0xb6068c: b.ls            #0xb606a0
    // 0xb60690: r8 = BoxConstraints
    //     0xb60690: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60694: r3 = Null
    //     0xb60694: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2840] Null
    //     0xb60698: ldr             x3, [x3, #0x840]
    // 0xb6069c: r0 = BoxConstraints()
    //     0xb6069c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb606a0: ldur            x0, [fp, #-8]
    // 0xb606a4: LoadField: r3 = r0->field_4f
    //     0xb606a4: ldur            w3, [x0, #0x4f]
    // 0xb606a8: DecompressPointer r3
    //     0xb606a8: add             x3, x3, HEAP, lsl #32
    // 0xb606ac: stur            x3, [fp, #-0x20]
    // 0xb606b0: cmp             w3, NULL
    // 0xb606b4: b.ne            #0xb606c8
    // 0xb606b8: r0 = Null
    //     0xb606b8: mov             x0, NULL
    // 0xb606bc: LeaveFrame
    //     0xb606bc: mov             SP, fp
    //     0xb606c0: ldp             fp, lr, [SP], #0x10
    // 0xb606c4: ret
    //     0xb606c4: ret             
    // 0xb606c8: mov             x1, x0
    // 0xb606cc: ldur            x2, [fp, #-0x10]
    // 0xb606d0: r0 = _getInnerConstraints()
    //     0xb606d0: bl              #0xb4d75c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0xb606d4: ldur            x1, [fp, #-0x20]
    // 0xb606d8: mov             x2, x0
    // 0xb606dc: ldur            x3, [fp, #-0x18]
    // 0xb606e0: stur            x0, [fp, #-0x18]
    // 0xb606e4: r0 = getDryBaseline()
    //     0xb606e4: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb606e8: stur            x0, [fp, #-0x28]
    // 0xb606ec: cmp             w0, NULL
    // 0xb606f0: b.ne            #0xb60704
    // 0xb606f4: r0 = Null
    //     0xb606f4: mov             x0, NULL
    // 0xb606f8: LeaveFrame
    //     0xb606f8: mov             SP, fp
    //     0xb606fc: ldp             fp, lr, [SP], #0x10
    // 0xb60700: ret
    //     0xb60700: ret             
    // 0xb60704: ldur            x1, [fp, #-0x20]
    // 0xb60708: ldur            x2, [fp, #-0x18]
    // 0xb6070c: r0 = getDryLayout()
    //     0xb6070c: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60710: ldur            x1, [fp, #-8]
    // 0xb60714: ldur            x2, [fp, #-0x10]
    // 0xb60718: stur            x0, [fp, #-0x10]
    // 0xb6071c: r0 = getDryLayout()
    //     0xb6071c: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60720: ldur            x1, [fp, #-8]
    // 0xb60724: stur            x0, [fp, #-8]
    // 0xb60728: r0 = resolvedAlignment()
    //     0xb60728: bl              #0xb5fd7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::resolvedAlignment
    // 0xb6072c: ldur            x1, [fp, #-8]
    // 0xb60730: ldur            x2, [fp, #-0x10]
    // 0xb60734: stur            x0, [fp, #-8]
    // 0xb60738: r0 = -()
    //     0xb60738: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb6073c: ldur            x1, [fp, #-8]
    // 0xb60740: mov             x2, x0
    // 0xb60744: r0 = alongOffset()
    //     0xb60744: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb60748: LoadField: d0 = r0->field_f
    //     0xb60748: ldur            d0, [x0, #0xf]
    // 0xb6074c: ldur            x1, [fp, #-0x28]
    // 0xb60750: LoadField: d1 = r1->field_7
    //     0xb60750: ldur            d1, [x1, #7]
    // 0xb60754: fadd            d2, d1, d0
    // 0xb60758: r0 = inline_Allocate_Double()
    //     0xb60758: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb6075c: add             x0, x0, #0x10
    //     0xb60760: cmp             x1, x0
    //     0xb60764: b.ls            #0xb60798
    //     0xb60768: str             x0, [THR, #0x60]  ; THR::top
    //     0xb6076c: sub             x0, x0, #0xf
    //     0xb60770: mov             x1, #0xe19c
    //     0xb60774: movk            x1, #3, lsl #16
    //     0xb60778: stur            x1, [x0, #-1]
    // 0xb6077c: dmb             ishst
    // 0xb60780: StoreField: r0->field_7 = d2
    //     0xb60780: stur            d2, [x0, #7]
    // 0xb60784: LeaveFrame
    //     0xb60784: mov             SP, fp
    //     0xb60788: ldp             fp, lr, [SP], #0x10
    // 0xb6078c: ret
    //     0xb6078c: ret             
    // 0xb60790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60790: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb60794: b               #0xb60668
    // 0xb60798: SaveReg d2
    //     0xb60798: str             q2, [SP, #-0x10]!
    // 0xb6079c: r0 = AllocateDouble()
    //     0xb6079c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb607a0: RestoreReg d2
    //     0xb607a0: ldr             q2, [SP], #0x10
    // 0xb607a4: b               #0xb60780
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbc16c, size: 0x254
    // 0xbbc16c: EnterFrame
    //     0xbbc16c: stp             fp, lr, [SP, #-0x10]!
    //     0xbbc170: mov             fp, SP
    // 0xbbc174: AllocStack(0x20)
    //     0xbbc174: sub             SP, SP, #0x20
    // 0xbbc178: SetupParameters(RenderFractionallySizedOverflowBox this /* r1 => r3, fp-0x18 */)
    //     0xbbc178: mov             x3, x1
    //     0xbbc17c: stur            x1, [fp, #-0x18]
    // 0xbbc180: CheckStackOverflow
    //     0xbbc180: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbc184: cmp             SP, x16
    //     0xbbc188: b.ls            #0xbbc3b4
    // 0xbbc18c: LoadField: r4 = r3->field_4f
    //     0xbbc18c: ldur            w4, [x3, #0x4f]
    // 0xbbc190: DecompressPointer r4
    //     0xbbc190: add             x4, x4, HEAP, lsl #32
    // 0xbbc194: stur            x4, [fp, #-0x10]
    // 0xbbc198: cmp             w4, NULL
    // 0xbbc19c: b.eq            #0xbbc2c0
    // 0xbbc1a0: LoadField: r5 = r3->field_27
    //     0xbbc1a0: ldur            w5, [x3, #0x27]
    // 0xbbc1a4: DecompressPointer r5
    //     0xbbc1a4: add             x5, x5, HEAP, lsl #32
    // 0xbbc1a8: stur            x5, [fp, #-8]
    // 0xbbc1ac: cmp             w5, NULL
    // 0xbbc1b0: b.eq            #0xbbc358
    // 0xbbc1b4: mov             x0, x5
    // 0xbbc1b8: r2 = Null
    //     0xbbc1b8: mov             x2, NULL
    // 0xbbc1bc: r1 = Null
    //     0xbbc1bc: mov             x1, NULL
    // 0xbbc1c0: r4 = LoadClassIdInstr(r0)
    //     0xbbc1c0: ldur            x4, [x0, #-1]
    //     0xbbc1c4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc1c8: sub             x4, x4, #0xb46
    // 0xbbc1cc: cmp             x4, #1
    // 0xbbc1d0: b.ls            #0xbbc1e4
    // 0xbbc1d4: r8 = BoxConstraints
    //     0xbbc1d4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbc1d8: r3 = Null
    //     0xbbc1d8: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2810] Null
    //     0xbbc1dc: ldr             x3, [x3, #0x810]
    // 0xbbc1e0: r0 = BoxConstraints()
    //     0xbbc1e0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbc1e4: ldur            x1, [fp, #-0x18]
    // 0xbbc1e8: ldur            x2, [fp, #-8]
    // 0xbbc1ec: r0 = _getInnerConstraints()
    //     0xbbc1ec: bl              #0xb4d75c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0xbbc1f0: ldur            x1, [fp, #-0x10]
    // 0xbbc1f4: r2 = LoadClassIdInstr(r1)
    //     0xbbc1f4: ldur            x2, [x1, #-1]
    //     0xbbc1f8: ubfx            x2, x2, #0xc, #0x14
    // 0xbbc1fc: r16 = true
    //     0xbbc1fc: add             x16, NULL, #0x20  ; true
    // 0xbbc200: str             x16, [SP]
    // 0xbbc204: mov             x16, x0
    // 0xbbc208: mov             x0, x2
    // 0xbbc20c: mov             x2, x16
    // 0xbbc210: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbc210: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbc214: ldr             x4, [x4, #0xed0]
    // 0xbbc218: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbc218: mov             x17, #0xe6b9
    //     0xbbc21c: add             lr, x0, x17
    //     0xbbc220: ldr             lr, [x21, lr, lsl #3]
    //     0xbbc224: blr             lr
    // 0xbbc228: ldur            x3, [fp, #-0x18]
    // 0xbbc22c: LoadField: r4 = r3->field_27
    //     0xbbc22c: ldur            w4, [x3, #0x27]
    // 0xbbc230: DecompressPointer r4
    //     0xbbc230: add             x4, x4, HEAP, lsl #32
    // 0xbbc234: stur            x4, [fp, #-8]
    // 0xbbc238: cmp             w4, NULL
    // 0xbbc23c: b.eq            #0xbbc374
    // 0xbbc240: mov             x0, x4
    // 0xbbc244: r2 = Null
    //     0xbbc244: mov             x2, NULL
    // 0xbbc248: r1 = Null
    //     0xbbc248: mov             x1, NULL
    // 0xbbc24c: r4 = LoadClassIdInstr(r0)
    //     0xbbc24c: ldur            x4, [x0, #-1]
    //     0xbbc250: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc254: sub             x4, x4, #0xb46
    // 0xbbc258: cmp             x4, #1
    // 0xbbc25c: b.ls            #0xbbc270
    // 0xbbc260: r8 = BoxConstraints
    //     0xbbc260: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbc264: r3 = Null
    //     0xbbc264: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2820] Null
    //     0xbbc268: ldr             x3, [x3, #0x820]
    // 0xbbc26c: r0 = BoxConstraints()
    //     0xbbc26c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbc270: ldur            x0, [fp, #-0x18]
    // 0xbbc274: LoadField: r1 = r0->field_4f
    //     0xbbc274: ldur            w1, [x0, #0x4f]
    // 0xbbc278: DecompressPointer r1
    //     0xbbc278: add             x1, x1, HEAP, lsl #32
    // 0xbbc27c: cmp             w1, NULL
    // 0xbbc280: b.eq            #0xbbc3bc
    // 0xbbc284: r0 = size()
    //     0xbbc284: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbc288: ldur            x1, [fp, #-8]
    // 0xbbc28c: mov             x2, x0
    // 0xbbc290: r0 = constrain()
    //     0xbbc290: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbc294: ldur            x3, [fp, #-0x18]
    // 0xbbc298: StoreField: r3->field_4b = r0
    //     0xbbc298: stur            w0, [x3, #0x4b]
    //     0xbbc29c: ldurb           w16, [x3, #-1]
    //     0xbbc2a0: ldurb           w17, [x0, #-1]
    //     0xbbc2a4: and             x16, x17, x16, lsr #2
    //     0xbbc2a8: tst             x16, HEAP, lsr #32
    //     0xbbc2ac: b.eq            #0xbbc2b4
    //     0xbbc2b0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbc2b4: mov             x1, x3
    // 0xbbc2b8: r0 = alignChild()
    //     0xbbc2b8: bl              #0xbbad50  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0xbbc2bc: b               #0xbbc348
    // 0xbbc2c0: LoadField: r4 = r3->field_27
    //     0xbbc2c0: ldur            w4, [x3, #0x27]
    // 0xbbc2c4: DecompressPointer r4
    //     0xbbc2c4: add             x4, x4, HEAP, lsl #32
    // 0xbbc2c8: stur            x4, [fp, #-8]
    // 0xbbc2cc: cmp             w4, NULL
    // 0xbbc2d0: b.eq            #0xbbc394
    // 0xbbc2d4: mov             x0, x4
    // 0xbbc2d8: r2 = Null
    //     0xbbc2d8: mov             x2, NULL
    // 0xbbc2dc: r1 = Null
    //     0xbbc2dc: mov             x1, NULL
    // 0xbbc2e0: r4 = LoadClassIdInstr(r0)
    //     0xbbc2e0: ldur            x4, [x0, #-1]
    //     0xbbc2e4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc2e8: sub             x4, x4, #0xb46
    // 0xbbc2ec: cmp             x4, #1
    // 0xbbc2f0: b.ls            #0xbbc304
    // 0xbbc2f4: r8 = BoxConstraints
    //     0xbbc2f4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbc2f8: r3 = Null
    //     0xbbc2f8: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2830] Null
    //     0xbbc2fc: ldr             x3, [x3, #0x830]
    // 0xbbc300: r0 = BoxConstraints()
    //     0xbbc300: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbc304: ldur            x1, [fp, #-0x18]
    // 0xbbc308: ldur            x2, [fp, #-8]
    // 0xbbc30c: r0 = _getInnerConstraints()
    //     0xbbc30c: bl              #0xb4d75c  ; [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::_getInnerConstraints
    // 0xbbc310: mov             x1, x0
    // 0xbbc314: r2 = Instance_Size
    //     0xbbc314: ldr             x2, [PP, #0x7f28]  ; [pp+0x7f28] Obj!Size@12a74d1
    // 0xbbc318: r0 = constrain()
    //     0xbbc318: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbc31c: ldur            x1, [fp, #-8]
    // 0xbbc320: mov             x2, x0
    // 0xbbc324: r0 = constrain()
    //     0xbbc324: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbc328: ldur            x1, [fp, #-0x18]
    // 0xbbc32c: StoreField: r1->field_4b = r0
    //     0xbbc32c: stur            w0, [x1, #0x4b]
    //     0xbbc330: ldurb           w16, [x1, #-1]
    //     0xbbc334: ldurb           w17, [x0, #-1]
    //     0xbbc338: and             x16, x17, x16, lsr #2
    //     0xbbc33c: tst             x16, HEAP, lsr #32
    //     0xbbc340: b.eq            #0xbbc348
    //     0xbbc344: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbc348: r0 = Null
    //     0xbbc348: mov             x0, NULL
    // 0xbbc34c: LeaveFrame
    //     0xbbc34c: mov             SP, fp
    //     0xbbc350: ldp             fp, lr, [SP], #0x10
    // 0xbbc354: ret
    //     0xbbc354: ret             
    // 0xbbc358: r0 = StateError()
    //     0xbbc358: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbc35c: mov             x1, x0
    // 0xbbc360: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc360: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc364: StoreField: r1->field_b = r0
    //     0xbbc364: stur            w0, [x1, #0xb]
    // 0xbbc368: mov             x0, x1
    // 0xbbc36c: r0 = Throw()
    //     0xbbc36c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbc370: brk             #0
    // 0xbbc374: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc374: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc378: r0 = StateError()
    //     0xbbc378: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbc37c: mov             x1, x0
    // 0xbbc380: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc380: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc384: StoreField: r1->field_b = r0
    //     0xbbc384: stur            w0, [x1, #0xb]
    // 0xbbc388: mov             x0, x1
    // 0xbbc38c: r0 = Throw()
    //     0xbbc38c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbc390: brk             #0
    // 0xbbc394: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc394: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc398: r0 = StateError()
    //     0xbbc398: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbc39c: mov             x1, x0
    // 0xbbc3a0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc3a0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc3a4: StoreField: r1->field_b = r0
    //     0xbbc3a4: stur            w0, [x1, #0xb]
    // 0xbbc3a8: mov             x0, x1
    // 0xbbc3ac: r0 = Throw()
    //     0xbbc3ac: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbc3b0: brk             #0
    // 0xbbc3b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbc3b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbc3b8: b               #0xbbc18c
    // 0xbbc3bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbc3bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ heightFactor=(/* No info */) {
    // ** addr: 0xcf8538, size: 0x50
    // 0xcf8538: EnterFrame
    //     0xcf8538: stp             fp, lr, [SP, #-0x10]!
    //     0xcf853c: mov             fp, SP
    // 0xcf8540: CheckStackOverflow
    //     0xcf8540: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8544: cmp             SP, x16
    //     0xcf8548: b.ls            #0xcf8580
    // 0xcf854c: LoadField: d1 = r1->field_63
    //     0xcf854c: ldur            d1, [x1, #0x63]
    // 0xcf8550: fcmp            d1, d0
    // 0xcf8554: b.ne            #0xcf8568
    // 0xcf8558: r0 = Null
    //     0xcf8558: mov             x0, NULL
    // 0xcf855c: LeaveFrame
    //     0xcf855c: mov             SP, fp
    //     0xcf8560: ldp             fp, lr, [SP], #0x10
    // 0xcf8564: ret
    //     0xcf8564: ret             
    // 0xcf8568: StoreField: r1->field_63 = d0
    //     0xcf8568: stur            d0, [x1, #0x63]
    // 0xcf856c: r0 = markNeedsLayout()
    //     0xcf856c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf8570: r0 = Null
    //     0xcf8570: mov             x0, NULL
    // 0xcf8574: LeaveFrame
    //     0xcf8574: mov             SP, fp
    //     0xcf8578: ldp             fp, lr, [SP], #0x10
    // 0xcf857c: ret
    //     0xcf857c: ret             
    // 0xcf8580: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf8580: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf8584: b               #0xcf854c
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efc4c, size: 0x24
    // 0x10efc4c: EnterFrame
    //     0x10efc4c: stp             fp, lr, [SP, #-0x10]!
    //     0x10efc50: mov             fp, SP
    // 0x10efc54: ldr             x2, [fp, #0x10]
    // 0x10efc58: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efc58: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa27f8] AnonymousClosure: (0xb23214), in [package:flutter/src/rendering/shifted_box.dart] RenderFractionallySizedOverflowBox::computeMinIntrinsicHeight (0xb231a8)
    //     0x10efc5c: ldr             x1, [x1, #0x7f8]
    // 0x10efc60: r0 = AllocateClosure()
    //     0x10efc60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efc64: LeaveFrame
    //     0x10efc64: mov             SP, fp
    //     0x10efc68: ldp             fp, lr, [SP], #0x10
    // 0x10efc6c: ret
    //     0x10efc6c: ret             
  }
  _ RenderFractionallySizedOverflowBox(/* No info */) {
    // ** addr: 0x11d1970, size: 0xb8
    // 0x11d1970: EnterFrame
    //     0x11d1970: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1974: mov             fp, SP
    // 0x11d1978: AllocStack(0x8)
    //     0x11d1978: sub             SP, SP, #8
    // 0x11d197c: SetupParameters(RenderFractionallySizedOverflowBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r1 */)
    //     0x11d197c: mov             x0, x2
    //     0x11d1980: mov             x2, x1
    //     0x11d1984: stur            x1, [fp, #-8]
    //     0x11d1988: mov             x1, x3
    // 0x11d198c: CheckStackOverflow
    //     0x11d198c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1990: cmp             SP, x16
    //     0x11d1994: b.ls            #0x11d1a20
    // 0x11d1998: StoreField: r2->field_63 = d0
    //     0x11d1998: stur            d0, [x2, #0x63]
    // 0x11d199c: StoreField: r2->field_57 = r0
    //     0x11d199c: stur            w0, [x2, #0x57]
    //     0x11d19a0: ldurb           w16, [x2, #-1]
    //     0x11d19a4: ldurb           w17, [x0, #-1]
    //     0x11d19a8: and             x16, x17, x16, lsr #2
    //     0x11d19ac: tst             x16, HEAP, lsr #32
    //     0x11d19b0: b.eq            #0x11d19b8
    //     0x11d19b4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d19b8: mov             x0, x1
    // 0x11d19bc: StoreField: r2->field_5b = r0
    //     0x11d19bc: stur            w0, [x2, #0x5b]
    //     0x11d19c0: ldurb           w16, [x2, #-1]
    //     0x11d19c4: ldurb           w17, [x0, #-1]
    //     0x11d19c8: and             x16, x17, x16, lsr #2
    //     0x11d19cc: tst             x16, HEAP, lsr #32
    //     0x11d19d0: b.eq            #0x11d19d8
    //     0x11d19d4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d19d8: r0 = _LayoutCacheStorage()
    //     0x11d19d8: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d19dc: ldur            x2, [fp, #-8]
    // 0x11d19e0: StoreField: r2->field_47 = r0
    //     0x11d19e0: stur            w0, [x2, #0x47]
    //     0x11d19e4: ldurb           w16, [x2, #-1]
    //     0x11d19e8: ldurb           w17, [x0, #-1]
    //     0x11d19ec: and             x16, x17, x16, lsr #2
    //     0x11d19f0: tst             x16, HEAP, lsr #32
    //     0x11d19f4: b.eq            #0x11d19fc
    //     0x11d19f8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d19fc: mov             x1, x2
    // 0x11d1a00: r0 = RenderObject()
    //     0x11d1a00: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d1a04: ldur            x1, [fp, #-8]
    // 0x11d1a08: r2 = Null
    //     0x11d1a08: mov             x2, NULL
    // 0x11d1a0c: r0 = child=()
    //     0x11d1a0c: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d1a10: r0 = Null
    //     0x11d1a10: mov             x0, NULL
    // 0x11d1a14: LeaveFrame
    //     0x11d1a14: mov             SP, fp
    //     0x11d1a18: ldp             fp, lr, [SP], #0x10
    // 0x11d1a1c: ret
    //     0x11d1a1c: ret             
    // 0x11d1a20: r0 = StackOverflowSharedWithFPURegs()
    //     0x11d1a20: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11d1a24: b               #0x11d1998
  }
}

// class id: 4885, size: 0x84, field offset: 0x60
class RenderConstrainedOverflowBox extends RenderAligningShiftedBox {

  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb604a8, size: 0x168
    // 0xb604a8: EnterFrame
    //     0xb604a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb604ac: mov             fp, SP
    // 0xb604b0: AllocStack(0x28)
    //     0xb604b0: sub             SP, SP, #0x28
    // 0xb604b4: SetupParameters(RenderConstrainedOverflowBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb604b4: mov             x5, x1
    //     0xb604b8: mov             x4, x2
    //     0xb604bc: stur            x1, [fp, #-8]
    //     0xb604c0: stur            x2, [fp, #-0x10]
    //     0xb604c4: stur            x3, [fp, #-0x18]
    // 0xb604c8: CheckStackOverflow
    //     0xb604c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb604cc: cmp             SP, x16
    //     0xb604d0: b.ls            #0xb605f8
    // 0xb604d4: mov             x0, x4
    // 0xb604d8: r2 = Null
    //     0xb604d8: mov             x2, NULL
    // 0xb604dc: r1 = Null
    //     0xb604dc: mov             x1, NULL
    // 0xb604e0: r4 = 60
    //     0xb604e0: mov             x4, #0x3c
    // 0xb604e4: branchIfSmi(r0, 0xb604f0)
    //     0xb604e4: tbz             w0, #0, #0xb604f0
    // 0xb604e8: r4 = LoadClassIdInstr(r0)
    //     0xb604e8: ldur            x4, [x0, #-1]
    //     0xb604ec: ubfx            x4, x4, #0xc, #0x14
    // 0xb604f0: sub             x4, x4, #0xb46
    // 0xb604f4: cmp             x4, #1
    // 0xb604f8: b.ls            #0xb6050c
    // 0xb604fc: r8 = BoxConstraints
    //     0xb604fc: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60500: r3 = Null
    //     0xb60500: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd41d0] Null
    //     0xb60504: ldr             x3, [x3, #0x1d0]
    // 0xb60508: r0 = BoxConstraints()
    //     0xb60508: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb6050c: ldur            x0, [fp, #-8]
    // 0xb60510: LoadField: r2 = r0->field_4f
    //     0xb60510: ldur            w2, [x0, #0x4f]
    // 0xb60514: DecompressPointer r2
    //     0xb60514: add             x2, x2, HEAP, lsl #32
    // 0xb60518: stur            x2, [fp, #-0x20]
    // 0xb6051c: cmp             w2, NULL
    // 0xb60520: b.ne            #0xb60534
    // 0xb60524: r0 = Null
    //     0xb60524: mov             x0, NULL
    // 0xb60528: LeaveFrame
    //     0xb60528: mov             SP, fp
    //     0xb6052c: ldp             fp, lr, [SP], #0x10
    // 0xb60530: ret
    //     0xb60530: ret             
    // 0xb60534: mov             x1, x0
    // 0xb60538: r0 = _getInnerConstraints()
    //     0xb60538: bl              #0xb60610  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstrainedOverflowBox::_getInnerConstraints
    // 0xb6053c: ldur            x1, [fp, #-0x20]
    // 0xb60540: mov             x2, x0
    // 0xb60544: ldur            x3, [fp, #-0x18]
    // 0xb60548: stur            x0, [fp, #-0x18]
    // 0xb6054c: r0 = getDryBaseline()
    //     0xb6054c: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60550: stur            x0, [fp, #-0x28]
    // 0xb60554: cmp             w0, NULL
    // 0xb60558: b.ne            #0xb6056c
    // 0xb6055c: r0 = Null
    //     0xb6055c: mov             x0, NULL
    // 0xb60560: LeaveFrame
    //     0xb60560: mov             SP, fp
    //     0xb60564: ldp             fp, lr, [SP], #0x10
    // 0xb60568: ret
    //     0xb60568: ret             
    // 0xb6056c: ldur            x1, [fp, #-0x20]
    // 0xb60570: ldur            x2, [fp, #-0x18]
    // 0xb60574: r0 = getDryLayout()
    //     0xb60574: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60578: ldur            x1, [fp, #-8]
    // 0xb6057c: ldur            x2, [fp, #-0x10]
    // 0xb60580: stur            x0, [fp, #-0x10]
    // 0xb60584: r0 = getDryLayout()
    //     0xb60584: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb60588: ldur            x1, [fp, #-8]
    // 0xb6058c: stur            x0, [fp, #-8]
    // 0xb60590: r0 = resolvedAlignment()
    //     0xb60590: bl              #0xb5fd7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::resolvedAlignment
    // 0xb60594: ldur            x1, [fp, #-8]
    // 0xb60598: ldur            x2, [fp, #-0x10]
    // 0xb6059c: stur            x0, [fp, #-8]
    // 0xb605a0: r0 = -()
    //     0xb605a0: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb605a4: ldur            x1, [fp, #-8]
    // 0xb605a8: mov             x2, x0
    // 0xb605ac: r0 = alongOffset()
    //     0xb605ac: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb605b0: LoadField: d0 = r0->field_f
    //     0xb605b0: ldur            d0, [x0, #0xf]
    // 0xb605b4: ldur            x1, [fp, #-0x28]
    // 0xb605b8: LoadField: d1 = r1->field_7
    //     0xb605b8: ldur            d1, [x1, #7]
    // 0xb605bc: fadd            d2, d1, d0
    // 0xb605c0: r0 = inline_Allocate_Double()
    //     0xb605c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb605c4: add             x0, x0, #0x10
    //     0xb605c8: cmp             x1, x0
    //     0xb605cc: b.ls            #0xb60600
    //     0xb605d0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb605d4: sub             x0, x0, #0xf
    //     0xb605d8: mov             x1, #0xe19c
    //     0xb605dc: movk            x1, #3, lsl #16
    //     0xb605e0: stur            x1, [x0, #-1]
    // 0xb605e4: dmb             ishst
    // 0xb605e8: StoreField: r0->field_7 = d2
    //     0xb605e8: stur            d2, [x0, #7]
    // 0xb605ec: LeaveFrame
    //     0xb605ec: mov             SP, fp
    //     0xb605f0: ldp             fp, lr, [SP], #0x10
    // 0xb605f4: ret
    //     0xb605f4: ret             
    // 0xb605f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb605f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb605fc: b               #0xb604d4
    // 0xb60600: SaveReg d2
    //     0xb60600: str             q2, [SP, #-0x10]!
    // 0xb60604: r0 = AllocateDouble()
    //     0xb60604: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb60608: RestoreReg d2
    //     0xb60608: ldr             q2, [SP], #0x10
    // 0xb6060c: b               #0xb605e8
  }
  _ _getInnerConstraints(/* No info */) {
    // ** addr: 0xb60610, size: 0x2c
    // 0xb60610: EnterFrame
    //     0xb60610: stp             fp, lr, [SP, #-0x10]!
    //     0xb60614: mov             fp, SP
    // 0xb60618: r0 = BoxConstraints()
    //     0xb60618: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb6061c: StoreField: r0->field_7 = rZR
    //     0xb6061c: stur            xzr, [x0, #7]
    // 0xb60620: d0 = inf
    //     0xb60620: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb60624: StoreField: r0->field_f = d0
    //     0xb60624: stur            d0, [x0, #0xf]
    // 0xb60628: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb60628: stur            xzr, [x0, #0x17]
    // 0xb6062c: StoreField: r0->field_1f = d0
    //     0xb6062c: stur            d0, [x0, #0x1f]
    // 0xb60630: LeaveFrame
    //     0xb60630: mov             SP, fp
    //     0xb60634: ldp             fp, lr, [SP], #0x10
    // 0xb60638: ret
    //     0xb60638: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbc080, size: 0xec
    // 0xbbc080: EnterFrame
    //     0xbbc080: stp             fp, lr, [SP, #-0x10]!
    //     0xbbc084: mov             fp, SP
    // 0xbbc088: AllocStack(0x18)
    //     0xbbc088: sub             SP, SP, #0x18
    // 0xbbc08c: SetupParameters(RenderConstrainedOverflowBox this /* r1 => r3, fp-0x10 */)
    //     0xbbc08c: mov             x3, x1
    //     0xbbc090: stur            x1, [fp, #-0x10]
    // 0xbbc094: CheckStackOverflow
    //     0xbbc094: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbc098: cmp             SP, x16
    //     0xbbc09c: b.ls            #0xbbc164
    // 0xbbc0a0: LoadField: r4 = r3->field_4f
    //     0xbbc0a0: ldur            w4, [x3, #0x4f]
    // 0xbbc0a4: DecompressPointer r4
    //     0xbbc0a4: add             x4, x4, HEAP, lsl #32
    // 0xbbc0a8: stur            x4, [fp, #-8]
    // 0xbbc0ac: cmp             w4, NULL
    // 0xbbc0b0: b.eq            #0xbbc138
    // 0xbbc0b4: LoadField: r0 = r3->field_27
    //     0xbbc0b4: ldur            w0, [x3, #0x27]
    // 0xbbc0b8: DecompressPointer r0
    //     0xbbc0b8: add             x0, x0, HEAP, lsl #32
    // 0xbbc0bc: cmp             w0, NULL
    // 0xbbc0c0: b.eq            #0xbbc148
    // 0xbbc0c4: r2 = Null
    //     0xbbc0c4: mov             x2, NULL
    // 0xbbc0c8: r1 = Null
    //     0xbbc0c8: mov             x1, NULL
    // 0xbbc0cc: r4 = LoadClassIdInstr(r0)
    //     0xbbc0cc: ldur            x4, [x0, #-1]
    //     0xbbc0d0: ubfx            x4, x4, #0xc, #0x14
    // 0xbbc0d4: sub             x4, x4, #0xb46
    // 0xbbc0d8: cmp             x4, #1
    // 0xbbc0dc: b.ls            #0xbbc0f0
    // 0xbbc0e0: r8 = BoxConstraints
    //     0xbbc0e0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbc0e4: r3 = Null
    //     0xbbc0e4: add             x3, PP, #0xd4, lsl #12  ; [pp+0xd41c0] Null
    //     0xbbc0e8: ldr             x3, [x3, #0x1c0]
    // 0xbbc0ec: r0 = BoxConstraints()
    //     0xbbc0ec: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbc0f0: ldur            x1, [fp, #-0x10]
    // 0xbbc0f4: r0 = _getInnerConstraints()
    //     0xbbc0f4: bl              #0xb60610  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstrainedOverflowBox::_getInnerConstraints
    // 0xbbc0f8: ldur            x1, [fp, #-8]
    // 0xbbc0fc: r2 = LoadClassIdInstr(r1)
    //     0xbbc0fc: ldur            x2, [x1, #-1]
    //     0xbbc100: ubfx            x2, x2, #0xc, #0x14
    // 0xbbc104: r16 = true
    //     0xbbc104: add             x16, NULL, #0x20  ; true
    // 0xbbc108: str             x16, [SP]
    // 0xbbc10c: mov             x16, x0
    // 0xbbc110: mov             x0, x2
    // 0xbbc114: mov             x2, x16
    // 0xbbc118: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbc118: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbc11c: ldr             x4, [x4, #0xed0]
    // 0xbbc120: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbc120: mov             x17, #0xe6b9
    //     0xbbc124: add             lr, x0, x17
    //     0xbbc128: ldr             lr, [x21, lr, lsl #3]
    //     0xbbc12c: blr             lr
    // 0xbbc130: ldur            x1, [fp, #-0x10]
    // 0xbbc134: r0 = alignChild()
    //     0xbbc134: bl              #0xbbad50  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0xbbc138: r0 = Null
    //     0xbbc138: mov             x0, NULL
    // 0xbbc13c: LeaveFrame
    //     0xbbc13c: mov             SP, fp
    //     0xbbc140: ldp             fp, lr, [SP], #0x10
    // 0xbbc144: ret
    //     0xbbc144: ret             
    // 0xbbc148: r0 = StateError()
    //     0xbbc148: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbc14c: mov             x1, x0
    // 0xbbc150: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc150: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc154: StoreField: r1->field_b = r0
    //     0xbbc154: stur            w0, [x1, #0xb]
    // 0xbbc158: mov             x0, x1
    // 0xbbc15c: r0 = Throw()
    //     0xbbc15c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbc160: brk             #0
    // 0xbbc164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbc164: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbc168: b               #0xbbc0a0
  }
  set _ maxHeight=(/* No info */) {
    // ** addr: 0xcf8774, size: 0x50
    // 0xcf8774: EnterFrame
    //     0xcf8774: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8778: mov             fp, SP
    // 0xcf877c: d1 = inf
    //     0xcf877c: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xcf8780: CheckStackOverflow
    //     0xcf8780: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8784: cmp             SP, x16
    //     0xcf8788: b.ls            #0xcf87bc
    // 0xcf878c: fcmp            d1, d1
    // 0xcf8790: b.ne            #0xcf87a4
    // 0xcf8794: r0 = Null
    //     0xcf8794: mov             x0, NULL
    // 0xcf8798: LeaveFrame
    //     0xcf8798: mov             SP, fp
    //     0xcf879c: ldp             fp, lr, [SP], #0x10
    // 0xcf87a0: ret
    //     0xcf87a0: ret             
    // 0xcf87a4: StoreField: r1->field_77 = d1
    //     0xcf87a4: stur            d1, [x1, #0x77]
    // 0xcf87a8: r0 = markNeedsLayout()
    //     0xcf87a8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf87ac: r0 = Null
    //     0xcf87ac: mov             x0, NULL
    // 0xcf87b0: LeaveFrame
    //     0xcf87b0: mov             SP, fp
    //     0xcf87b4: ldp             fp, lr, [SP], #0x10
    // 0xcf87b8: ret
    //     0xcf87b8: ret             
    // 0xcf87bc: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf87bc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf87c0: b               #0xcf878c
  }
  set _ minHeight=(/* No info */) {
    // ** addr: 0xcf87c4, size: 0x50
    // 0xcf87c4: EnterFrame
    //     0xcf87c4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf87c8: mov             fp, SP
    // 0xcf87cc: d1 = 0.000000
    //     0xcf87cc: eor             v1.16b, v1.16b, v1.16b
    // 0xcf87d0: CheckStackOverflow
    //     0xcf87d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf87d4: cmp             SP, x16
    //     0xcf87d8: b.ls            #0xcf880c
    // 0xcf87dc: fcmp            d1, d1
    // 0xcf87e0: b.ne            #0xcf87f4
    // 0xcf87e4: r0 = Null
    //     0xcf87e4: mov             x0, NULL
    // 0xcf87e8: LeaveFrame
    //     0xcf87e8: mov             SP, fp
    //     0xcf87ec: ldp             fp, lr, [SP], #0x10
    // 0xcf87f0: ret
    //     0xcf87f0: ret             
    // 0xcf87f4: StoreField: r1->field_6f = rZR
    //     0xcf87f4: stur            xzr, [x1, #0x6f]
    // 0xcf87f8: r0 = markNeedsLayout()
    //     0xcf87f8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf87fc: r0 = Null
    //     0xcf87fc: mov             x0, NULL
    // 0xcf8800: LeaveFrame
    //     0xcf8800: mov             SP, fp
    //     0xcf8804: ldp             fp, lr, [SP], #0x10
    // 0xcf8808: ret
    //     0xcf8808: ret             
    // 0xcf880c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf880c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf8810: b               #0xcf87dc
  }
  set _ maxWidth=(/* No info */) {
    // ** addr: 0xcf8814, size: 0x50
    // 0xcf8814: EnterFrame
    //     0xcf8814: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8818: mov             fp, SP
    // 0xcf881c: d1 = inf
    //     0xcf881c: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xcf8820: CheckStackOverflow
    //     0xcf8820: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8824: cmp             SP, x16
    //     0xcf8828: b.ls            #0xcf885c
    // 0xcf882c: fcmp            d1, d1
    // 0xcf8830: b.ne            #0xcf8844
    // 0xcf8834: r0 = Null
    //     0xcf8834: mov             x0, NULL
    // 0xcf8838: LeaveFrame
    //     0xcf8838: mov             SP, fp
    //     0xcf883c: ldp             fp, lr, [SP], #0x10
    // 0xcf8840: ret
    //     0xcf8840: ret             
    // 0xcf8844: StoreField: r1->field_67 = d1
    //     0xcf8844: stur            d1, [x1, #0x67]
    // 0xcf8848: r0 = markNeedsLayout()
    //     0xcf8848: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf884c: r0 = Null
    //     0xcf884c: mov             x0, NULL
    // 0xcf8850: LeaveFrame
    //     0xcf8850: mov             SP, fp
    //     0xcf8854: ldp             fp, lr, [SP], #0x10
    // 0xcf8858: ret
    //     0xcf8858: ret             
    // 0xcf885c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf885c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf8860: b               #0xcf882c
  }
  set _ minWidth=(/* No info */) {
    // ** addr: 0xcf8864, size: 0x50
    // 0xcf8864: EnterFrame
    //     0xcf8864: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8868: mov             fp, SP
    // 0xcf886c: d1 = 0.000000
    //     0xcf886c: eor             v1.16b, v1.16b, v1.16b
    // 0xcf8870: CheckStackOverflow
    //     0xcf8870: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8874: cmp             SP, x16
    //     0xcf8878: b.ls            #0xcf88ac
    // 0xcf887c: fcmp            d1, d1
    // 0xcf8880: b.ne            #0xcf8894
    // 0xcf8884: r0 = Null
    //     0xcf8884: mov             x0, NULL
    // 0xcf8888: LeaveFrame
    //     0xcf8888: mov             SP, fp
    //     0xcf888c: ldp             fp, lr, [SP], #0x10
    // 0xcf8890: ret
    //     0xcf8890: ret             
    // 0xcf8894: StoreField: r1->field_5f = rZR
    //     0xcf8894: stur            xzr, [x1, #0x5f]
    // 0xcf8898: r0 = markNeedsLayout()
    //     0xcf8898: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf889c: r0 = Null
    //     0xcf889c: mov             x0, NULL
    // 0xcf88a0: LeaveFrame
    //     0xcf88a0: mov             SP, fp
    //     0xcf88a4: ldp             fp, lr, [SP], #0x10
    // 0xcf88a8: ret
    //     0xcf88a8: ret             
    // 0xcf88ac: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf88ac: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf88b0: b               #0xcf887c
  }
  _ RenderConstrainedOverflowBox(/* No info */) {
    // ** addr: 0x11d1b60, size: 0xc4
    // 0x11d1b60: EnterFrame
    //     0x11d1b60: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1b64: mov             fp, SP
    // 0x11d1b68: AllocStack(0x8)
    //     0x11d1b68: sub             SP, SP, #8
    // 0x11d1b6c: r3 = Instance_OverflowBoxFit
    //     0x11d1b6c: add             x3, PP, #0xd2, lsl #12  ; [pp+0xd2830] Obj!OverflowBoxFit@12c42c1
    //     0x11d1b70: ldr             x3, [x3, #0x830]
    // 0x11d1b74: r0 = Instance_Alignment
    //     0x11d1b74: add             x0, PP, #0x15, lsl #12  ; [pp+0x15510] Obj!Alignment@129e7b1
    //     0x11d1b78: ldr             x0, [x0, #0x510]
    // 0x11d1b7c: d0 = inf
    //     0x11d1b7c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x11d1b80: stur            x1, [fp, #-8]
    // 0x11d1b84: mov             x16, x2
    // 0x11d1b88: mov             x2, x1
    // 0x11d1b8c: mov             x1, x16
    // 0x11d1b90: CheckStackOverflow
    //     0x11d1b90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d1b94: cmp             SP, x16
    //     0x11d1b98: b.ls            #0x11d1c1c
    // 0x11d1b9c: StoreField: r2->field_5f = rZR
    //     0x11d1b9c: stur            xzr, [x2, #0x5f]
    // 0x11d1ba0: StoreField: r2->field_67 = d0
    //     0x11d1ba0: stur            d0, [x2, #0x67]
    // 0x11d1ba4: StoreField: r2->field_6f = rZR
    //     0x11d1ba4: stur            xzr, [x2, #0x6f]
    // 0x11d1ba8: StoreField: r2->field_77 = d0
    //     0x11d1ba8: stur            d0, [x2, #0x77]
    // 0x11d1bac: StoreField: r2->field_7f = r3
    //     0x11d1bac: stur            w3, [x2, #0x7f]
    // 0x11d1bb0: StoreField: r2->field_57 = r0
    //     0x11d1bb0: stur            w0, [x2, #0x57]
    // 0x11d1bb4: mov             x0, x1
    // 0x11d1bb8: StoreField: r2->field_5b = r0
    //     0x11d1bb8: stur            w0, [x2, #0x5b]
    //     0x11d1bbc: ldurb           w16, [x2, #-1]
    //     0x11d1bc0: ldurb           w17, [x0, #-1]
    //     0x11d1bc4: and             x16, x17, x16, lsr #2
    //     0x11d1bc8: tst             x16, HEAP, lsr #32
    //     0x11d1bcc: b.eq            #0x11d1bd4
    //     0x11d1bd0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d1bd4: r0 = _LayoutCacheStorage()
    //     0x11d1bd4: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d1bd8: ldur            x2, [fp, #-8]
    // 0x11d1bdc: StoreField: r2->field_47 = r0
    //     0x11d1bdc: stur            w0, [x2, #0x47]
    //     0x11d1be0: ldurb           w16, [x2, #-1]
    //     0x11d1be4: ldurb           w17, [x0, #-1]
    //     0x11d1be8: and             x16, x17, x16, lsr #2
    //     0x11d1bec: tst             x16, HEAP, lsr #32
    //     0x11d1bf0: b.eq            #0x11d1bf8
    //     0x11d1bf4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d1bf8: mov             x1, x2
    // 0x11d1bfc: r0 = RenderObject()
    //     0x11d1bfc: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d1c00: ldur            x1, [fp, #-8]
    // 0x11d1c04: r2 = Null
    //     0x11d1c04: mov             x2, NULL
    // 0x11d1c08: r0 = child=()
    //     0x11d1c08: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d1c0c: r0 = Null
    //     0x11d1c0c: mov             x0, NULL
    // 0x11d1c10: LeaveFrame
    //     0x11d1c10: mov             SP, fp
    //     0x11d1c14: ldp             fp, lr, [SP], #0x10
    // 0x11d1c18: ret
    //     0x11d1c18: ret             
    // 0x11d1c1c: r0 = StackOverflowSharedWithFPURegs()
    //     0x11d1c1c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x11d1c20: b               #0x11d1b9c
  }
}

// class id: 4886, size: 0x68, field offset: 0x60
class RenderPositionedBox extends RenderAligningShiftedBox {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16cec, size: 0x24
    // 0xb16cec: EnterFrame
    //     0xb16cec: stp             fp, lr, [SP, #-0x10]!
    //     0xb16cf0: mov             fp, SP
    // 0xb16cf4: ldr             x2, [fp, #0x10]
    // 0xb16cf8: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb16cf8: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2860] AnonymousClosure: (0xb16d10), in [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::computeMinIntrinsicWidth (0xb16d88)
    //     0xb16cfc: ldr             x1, [x1, #0x860]
    // 0xb16d00: r0 = AllocateClosure()
    //     0xb16d00: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16d04: LeaveFrame
    //     0xb16d04: mov             SP, fp
    //     0xb16d08: ldp             fp, lr, [SP], #0x10
    // 0xb16d0c: ret
    //     0xb16d0c: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16d10, size: 0x78
    // 0xb16d10: EnterFrame
    //     0xb16d10: stp             fp, lr, [SP, #-0x10]!
    //     0xb16d14: mov             fp, SP
    // 0xb16d18: ldr             x0, [fp, #0x18]
    // 0xb16d1c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb16d1c: ldur            w1, [x0, #0x17]
    // 0xb16d20: DecompressPointer r1
    //     0xb16d20: add             x1, x1, HEAP, lsl #32
    // 0xb16d24: CheckStackOverflow
    //     0xb16d24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16d28: cmp             SP, x16
    //     0xb16d2c: b.ls            #0xb16d70
    // 0xb16d30: ldr             x2, [fp, #0x10]
    // 0xb16d34: r0 = computeMinIntrinsicWidth()
    //     0xb16d34: bl              #0xb16d88  ; [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::computeMinIntrinsicWidth
    // 0xb16d38: r0 = inline_Allocate_Double()
    //     0xb16d38: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16d3c: add             x0, x0, #0x10
    //     0xb16d40: cmp             x1, x0
    //     0xb16d44: b.ls            #0xb16d78
    //     0xb16d48: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16d4c: sub             x0, x0, #0xf
    //     0xb16d50: mov             x1, #0xe19c
    //     0xb16d54: movk            x1, #3, lsl #16
    //     0xb16d58: stur            x1, [x0, #-1]
    // 0xb16d5c: dmb             ishst
    // 0xb16d60: StoreField: r0->field_7 = d0
    //     0xb16d60: stur            d0, [x0, #7]
    // 0xb16d64: LeaveFrame
    //     0xb16d64: mov             SP, fp
    //     0xb16d68: ldp             fp, lr, [SP], #0x10
    // 0xb16d6c: ret
    //     0xb16d6c: ret             
    // 0xb16d70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16d70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16d74: b               #0xb16d30
    // 0xb16d78: SaveReg d0
    //     0xb16d78: str             q0, [SP, #-0x10]!
    // 0xb16d7c: r0 = AllocateDouble()
    //     0xb16d7c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16d80: RestoreReg d0
    //     0xb16d80: ldr             q0, [SP], #0x10
    // 0xb16d84: b               #0xb16d60
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb16d88, size: 0xb0
    // 0xb16d88: EnterFrame
    //     0xb16d88: stp             fp, lr, [SP, #-0x10]!
    //     0xb16d8c: mov             fp, SP
    // 0xb16d90: AllocStack(0x18)
    //     0xb16d90: sub             SP, SP, #0x18
    // 0xb16d94: SetupParameters(RenderPositionedBox this /* r1 => r0, fp-0x8 */)
    //     0xb16d94: mov             x0, x1
    //     0xb16d98: stur            x1, [fp, #-8]
    // 0xb16d9c: CheckStackOverflow
    //     0xb16d9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16da0: cmp             SP, x16
    //     0xb16da4: b.ls            #0xb16e14
    // 0xb16da8: mov             x1, x0
    // 0xb16dac: r0 = computeMinIntrinsicWidth()
    //     0xb16dac: bl              #0xb16174  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0xb16db0: ldur            x0, [fp, #-8]
    // 0xb16db4: LoadField: r1 = r0->field_5f
    //     0xb16db4: ldur            w1, [x0, #0x5f]
    // 0xb16db8: DecompressPointer r1
    //     0xb16db8: add             x1, x1, HEAP, lsl #32
    // 0xb16dbc: cmp             w1, NULL
    // 0xb16dc0: b.ne            #0xb16dcc
    // 0xb16dc4: r0 = 2
    //     0xb16dc4: mov             x0, #2
    // 0xb16dc8: b               #0xb16dd0
    // 0xb16dcc: mov             x0, x1
    // 0xb16dd0: r1 = inline_Allocate_Double()
    //     0xb16dd0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb16dd4: add             x1, x1, #0x10
    //     0xb16dd8: cmp             x2, x1
    //     0xb16ddc: b.ls            #0xb16e1c
    //     0xb16de0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb16de4: sub             x1, x1, #0xf
    //     0xb16de8: mov             x2, #0xe19c
    //     0xb16dec: movk            x2, #3, lsl #16
    //     0xb16df0: stur            x2, [x1, #-1]
    // 0xb16df4: dmb             ishst
    // 0xb16df8: StoreField: r1->field_7 = d0
    //     0xb16df8: stur            d0, [x1, #7]
    // 0xb16dfc: stp             x0, x1, [SP]
    // 0xb16e00: r0 = *()
    //     0xb16e00: bl              #0x13dd2f8  ; [dart:core] _Double::*
    // 0xb16e04: LoadField: d0 = r0->field_7
    //     0xb16e04: ldur            d0, [x0, #7]
    // 0xb16e08: LeaveFrame
    //     0xb16e08: mov             SP, fp
    //     0xb16e0c: ldp             fp, lr, [SP], #0x10
    // 0xb16e10: ret
    //     0xb16e10: ret             
    // 0xb16e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16e14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16e18: b               #0xb16da8
    // 0xb16e1c: SaveReg d0
    //     0xb16e1c: str             q0, [SP, #-0x10]!
    // 0xb16e20: SaveReg r0
    //     0xb16e20: str             x0, [SP, #-8]!
    // 0xb16e24: r0 = AllocateDouble()
    //     0xb16e24: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16e28: mov             x1, x0
    // 0xb16e2c: RestoreReg r0
    //     0xb16e2c: ldr             x0, [SP], #8
    // 0xb16e30: RestoreReg d0
    //     0xb16e30: ldr             q0, [SP], #0x10
    // 0xb16e34: b               #0xb16df8
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb23080, size: 0xb0
    // 0xb23080: EnterFrame
    //     0xb23080: stp             fp, lr, [SP, #-0x10]!
    //     0xb23084: mov             fp, SP
    // 0xb23088: AllocStack(0x18)
    //     0xb23088: sub             SP, SP, #0x18
    // 0xb2308c: SetupParameters(RenderPositionedBox this /* r1 => r0, fp-0x8 */)
    //     0xb2308c: mov             x0, x1
    //     0xb23090: stur            x1, [fp, #-8]
    // 0xb23094: CheckStackOverflow
    //     0xb23094: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23098: cmp             SP, x16
    //     0xb2309c: b.ls            #0xb2310c
    // 0xb230a0: mov             x1, x0
    // 0xb230a4: r0 = computeMinIntrinsicHeight()
    //     0xb230a4: bl              #0xb23590  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMinIntrinsicHeight
    // 0xb230a8: ldur            x0, [fp, #-8]
    // 0xb230ac: LoadField: r1 = r0->field_63
    //     0xb230ac: ldur            w1, [x0, #0x63]
    // 0xb230b0: DecompressPointer r1
    //     0xb230b0: add             x1, x1, HEAP, lsl #32
    // 0xb230b4: cmp             w1, NULL
    // 0xb230b8: b.ne            #0xb230c4
    // 0xb230bc: r0 = 2
    //     0xb230bc: mov             x0, #2
    // 0xb230c0: b               #0xb230c8
    // 0xb230c4: mov             x0, x1
    // 0xb230c8: r1 = inline_Allocate_Double()
    //     0xb230c8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb230cc: add             x1, x1, #0x10
    //     0xb230d0: cmp             x2, x1
    //     0xb230d4: b.ls            #0xb23114
    //     0xb230d8: str             x1, [THR, #0x60]  ; THR::top
    //     0xb230dc: sub             x1, x1, #0xf
    //     0xb230e0: mov             x2, #0xe19c
    //     0xb230e4: movk            x2, #3, lsl #16
    //     0xb230e8: stur            x2, [x1, #-1]
    // 0xb230ec: dmb             ishst
    // 0xb230f0: StoreField: r1->field_7 = d0
    //     0xb230f0: stur            d0, [x1, #7]
    // 0xb230f4: stp             x0, x1, [SP]
    // 0xb230f8: r0 = *()
    //     0xb230f8: bl              #0x13dd2f8  ; [dart:core] _Double::*
    // 0xb230fc: LoadField: d0 = r0->field_7
    //     0xb230fc: ldur            d0, [x0, #7]
    // 0xb23100: LeaveFrame
    //     0xb23100: mov             SP, fp
    //     0xb23104: ldp             fp, lr, [SP], #0x10
    // 0xb23108: ret
    //     0xb23108: ret             
    // 0xb2310c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2310c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23110: b               #0xb230a0
    // 0xb23114: SaveReg d0
    //     0xb23114: str             q0, [SP, #-0x10]!
    // 0xb23118: SaveReg r0
    //     0xb23118: str             x0, [SP, #-8]!
    // 0xb2311c: r0 = AllocateDouble()
    //     0xb2311c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb23120: mov             x1, x0
    // 0xb23124: RestoreReg r0
    //     0xb23124: ldr             x0, [SP], #8
    // 0xb23128: RestoreReg d0
    //     0xb23128: ldr             q0, [SP], #0x10
    // 0xb2312c: b               #0xb230f0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb23130, size: 0x78
    // 0xb23130: EnterFrame
    //     0xb23130: stp             fp, lr, [SP, #-0x10]!
    //     0xb23134: mov             fp, SP
    // 0xb23138: ldr             x0, [fp, #0x18]
    // 0xb2313c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2313c: ldur            w1, [x0, #0x17]
    // 0xb23140: DecompressPointer r1
    //     0xb23140: add             x1, x1, HEAP, lsl #32
    // 0xb23144: CheckStackOverflow
    //     0xb23144: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23148: cmp             SP, x16
    //     0xb2314c: b.ls            #0xb23190
    // 0xb23150: ldr             x2, [fp, #0x10]
    // 0xb23154: r0 = computeMinIntrinsicHeight()
    //     0xb23154: bl              #0xb23080  ; [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::computeMinIntrinsicHeight
    // 0xb23158: r0 = inline_Allocate_Double()
    //     0xb23158: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2315c: add             x0, x0, #0x10
    //     0xb23160: cmp             x1, x0
    //     0xb23164: b.ls            #0xb23198
    //     0xb23168: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2316c: sub             x0, x0, #0xf
    //     0xb23170: mov             x1, #0xe19c
    //     0xb23174: movk            x1, #3, lsl #16
    //     0xb23178: stur            x1, [x0, #-1]
    // 0xb2317c: dmb             ishst
    // 0xb23180: StoreField: r0->field_7 = d0
    //     0xb23180: stur            d0, [x0, #7]
    // 0xb23184: LeaveFrame
    //     0xb23184: mov             SP, fp
    //     0xb23188: ldp             fp, lr, [SP], #0x10
    // 0xb2318c: ret
    //     0xb2318c: ret             
    // 0xb23190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23190: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23194: b               #0xb23150
    // 0xb23198: SaveReg d0
    //     0xb23198: str             q0, [SP, #-0x10]!
    // 0xb2319c: r0 = AllocateDouble()
    //     0xb2319c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb231a0: RestoreReg d0
    //     0xb231a0: ldr             q0, [SP], #0x10
    // 0xb231a4: b               #0xb23180
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb29cac, size: 0xb0
    // 0xb29cac: EnterFrame
    //     0xb29cac: stp             fp, lr, [SP, #-0x10]!
    //     0xb29cb0: mov             fp, SP
    // 0xb29cb4: AllocStack(0x18)
    //     0xb29cb4: sub             SP, SP, #0x18
    // 0xb29cb8: SetupParameters(RenderPositionedBox this /* r1 => r0, fp-0x8 */)
    //     0xb29cb8: mov             x0, x1
    //     0xb29cbc: stur            x1, [fp, #-8]
    // 0xb29cc0: CheckStackOverflow
    //     0xb29cc0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29cc4: cmp             SP, x16
    //     0xb29cc8: b.ls            #0xb29d38
    // 0xb29ccc: mov             x1, x0
    // 0xb29cd0: r0 = computeMaxIntrinsicHeight()
    //     0xb29cd0: bl              #0xb2a3e0  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicHeight
    // 0xb29cd4: ldur            x0, [fp, #-8]
    // 0xb29cd8: LoadField: r1 = r0->field_63
    //     0xb29cd8: ldur            w1, [x0, #0x63]
    // 0xb29cdc: DecompressPointer r1
    //     0xb29cdc: add             x1, x1, HEAP, lsl #32
    // 0xb29ce0: cmp             w1, NULL
    // 0xb29ce4: b.ne            #0xb29cf0
    // 0xb29ce8: r0 = 2
    //     0xb29ce8: mov             x0, #2
    // 0xb29cec: b               #0xb29cf4
    // 0xb29cf0: mov             x0, x1
    // 0xb29cf4: r1 = inline_Allocate_Double()
    //     0xb29cf4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb29cf8: add             x1, x1, #0x10
    //     0xb29cfc: cmp             x2, x1
    //     0xb29d00: b.ls            #0xb29d40
    //     0xb29d04: str             x1, [THR, #0x60]  ; THR::top
    //     0xb29d08: sub             x1, x1, #0xf
    //     0xb29d0c: mov             x2, #0xe19c
    //     0xb29d10: movk            x2, #3, lsl #16
    //     0xb29d14: stur            x2, [x1, #-1]
    // 0xb29d18: dmb             ishst
    // 0xb29d1c: StoreField: r1->field_7 = d0
    //     0xb29d1c: stur            d0, [x1, #7]
    // 0xb29d20: stp             x0, x1, [SP]
    // 0xb29d24: r0 = *()
    //     0xb29d24: bl              #0x13dd2f8  ; [dart:core] _Double::*
    // 0xb29d28: LoadField: d0 = r0->field_7
    //     0xb29d28: ldur            d0, [x0, #7]
    // 0xb29d2c: LeaveFrame
    //     0xb29d2c: mov             SP, fp
    //     0xb29d30: ldp             fp, lr, [SP], #0x10
    // 0xb29d34: ret
    //     0xb29d34: ret             
    // 0xb29d38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29d38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29d3c: b               #0xb29ccc
    // 0xb29d40: SaveReg d0
    //     0xb29d40: str             q0, [SP, #-0x10]!
    // 0xb29d44: SaveReg r0
    //     0xb29d44: str             x0, [SP, #-8]!
    // 0xb29d48: r0 = AllocateDouble()
    //     0xb29d48: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29d4c: mov             x1, x0
    // 0xb29d50: RestoreReg r0
    //     0xb29d50: ldr             x0, [SP], #8
    // 0xb29d54: RestoreReg d0
    //     0xb29d54: ldr             q0, [SP], #0x10
    // 0xb29d58: b               #0xb29d1c
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb29d5c, size: 0x78
    // 0xb29d5c: EnterFrame
    //     0xb29d5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb29d60: mov             fp, SP
    // 0xb29d64: ldr             x0, [fp, #0x18]
    // 0xb29d68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb29d68: ldur            w1, [x0, #0x17]
    // 0xb29d6c: DecompressPointer r1
    //     0xb29d6c: add             x1, x1, HEAP, lsl #32
    // 0xb29d70: CheckStackOverflow
    //     0xb29d70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29d74: cmp             SP, x16
    //     0xb29d78: b.ls            #0xb29dbc
    // 0xb29d7c: ldr             x2, [fp, #0x10]
    // 0xb29d80: r0 = computeMaxIntrinsicHeight()
    //     0xb29d80: bl              #0xb29cac  ; [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::computeMaxIntrinsicHeight
    // 0xb29d84: r0 = inline_Allocate_Double()
    //     0xb29d84: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb29d88: add             x0, x0, #0x10
    //     0xb29d8c: cmp             x1, x0
    //     0xb29d90: b.ls            #0xb29dc4
    //     0xb29d94: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29d98: sub             x0, x0, #0xf
    //     0xb29d9c: mov             x1, #0xe19c
    //     0xb29da0: movk            x1, #3, lsl #16
    //     0xb29da4: stur            x1, [x0, #-1]
    // 0xb29da8: dmb             ishst
    // 0xb29dac: StoreField: r0->field_7 = d0
    //     0xb29dac: stur            d0, [x0, #7]
    // 0xb29db0: LeaveFrame
    //     0xb29db0: mov             SP, fp
    //     0xb29db4: ldp             fp, lr, [SP], #0x10
    // 0xb29db8: ret
    //     0xb29db8: ret             
    // 0xb29dbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29dbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29dc0: b               #0xb29d7c
    // 0xb29dc4: SaveReg d0
    //     0xb29dc4: str             q0, [SP, #-0x10]!
    // 0xb29dc8: r0 = AllocateDouble()
    //     0xb29dc8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29dcc: RestoreReg d0
    //     0xb29dcc: ldr             q0, [SP], #0x10
    // 0xb29dd0: b               #0xb29dac
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2d0dc, size: 0xb0
    // 0xb2d0dc: EnterFrame
    //     0xb2d0dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d0e0: mov             fp, SP
    // 0xb2d0e4: AllocStack(0x18)
    //     0xb2d0e4: sub             SP, SP, #0x18
    // 0xb2d0e8: SetupParameters(RenderPositionedBox this /* r1 => r0, fp-0x8 */)
    //     0xb2d0e8: mov             x0, x1
    //     0xb2d0ec: stur            x1, [fp, #-8]
    // 0xb2d0f0: CheckStackOverflow
    //     0xb2d0f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d0f4: cmp             SP, x16
    //     0xb2d0f8: b.ls            #0xb2d168
    // 0xb2d0fc: mov             x1, x0
    // 0xb2d100: r0 = computeMaxIntrinsicWidth()
    //     0xb2d100: bl              #0xb2d828  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicWidth
    // 0xb2d104: ldur            x0, [fp, #-8]
    // 0xb2d108: LoadField: r1 = r0->field_5f
    //     0xb2d108: ldur            w1, [x0, #0x5f]
    // 0xb2d10c: DecompressPointer r1
    //     0xb2d10c: add             x1, x1, HEAP, lsl #32
    // 0xb2d110: cmp             w1, NULL
    // 0xb2d114: b.ne            #0xb2d120
    // 0xb2d118: r0 = 2
    //     0xb2d118: mov             x0, #2
    // 0xb2d11c: b               #0xb2d124
    // 0xb2d120: mov             x0, x1
    // 0xb2d124: r1 = inline_Allocate_Double()
    //     0xb2d124: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb2d128: add             x1, x1, #0x10
    //     0xb2d12c: cmp             x2, x1
    //     0xb2d130: b.ls            #0xb2d170
    //     0xb2d134: str             x1, [THR, #0x60]  ; THR::top
    //     0xb2d138: sub             x1, x1, #0xf
    //     0xb2d13c: mov             x2, #0xe19c
    //     0xb2d140: movk            x2, #3, lsl #16
    //     0xb2d144: stur            x2, [x1, #-1]
    // 0xb2d148: dmb             ishst
    // 0xb2d14c: StoreField: r1->field_7 = d0
    //     0xb2d14c: stur            d0, [x1, #7]
    // 0xb2d150: stp             x0, x1, [SP]
    // 0xb2d154: r0 = *()
    //     0xb2d154: bl              #0x13dd2f8  ; [dart:core] _Double::*
    // 0xb2d158: LoadField: d0 = r0->field_7
    //     0xb2d158: ldur            d0, [x0, #7]
    // 0xb2d15c: LeaveFrame
    //     0xb2d15c: mov             SP, fp
    //     0xb2d160: ldp             fp, lr, [SP], #0x10
    // 0xb2d164: ret
    //     0xb2d164: ret             
    // 0xb2d168: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d168: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d16c: b               #0xb2d0fc
    // 0xb2d170: SaveReg d0
    //     0xb2d170: str             q0, [SP, #-0x10]!
    // 0xb2d174: SaveReg r0
    //     0xb2d174: str             x0, [SP, #-8]!
    // 0xb2d178: r0 = AllocateDouble()
    //     0xb2d178: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d17c: mov             x1, x0
    // 0xb2d180: RestoreReg r0
    //     0xb2d180: ldr             x0, [SP], #8
    // 0xb2d184: RestoreReg d0
    //     0xb2d184: ldr             q0, [SP], #0x10
    // 0xb2d188: b               #0xb2d14c
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2d18c, size: 0x78
    // 0xb2d18c: EnterFrame
    //     0xb2d18c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d190: mov             fp, SP
    // 0xb2d194: ldr             x0, [fp, #0x18]
    // 0xb2d198: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2d198: ldur            w1, [x0, #0x17]
    // 0xb2d19c: DecompressPointer r1
    //     0xb2d19c: add             x1, x1, HEAP, lsl #32
    // 0xb2d1a0: CheckStackOverflow
    //     0xb2d1a0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d1a4: cmp             SP, x16
    //     0xb2d1a8: b.ls            #0xb2d1ec
    // 0xb2d1ac: ldr             x2, [fp, #0x10]
    // 0xb2d1b0: r0 = computeMaxIntrinsicWidth()
    //     0xb2d1b0: bl              #0xb2d0dc  ; [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::computeMaxIntrinsicWidth
    // 0xb2d1b4: r0 = inline_Allocate_Double()
    //     0xb2d1b4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2d1b8: add             x0, x0, #0x10
    //     0xb2d1bc: cmp             x1, x0
    //     0xb2d1c0: b.ls            #0xb2d1f4
    //     0xb2d1c4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2d1c8: sub             x0, x0, #0xf
    //     0xb2d1cc: mov             x1, #0xe19c
    //     0xb2d1d0: movk            x1, #3, lsl #16
    //     0xb2d1d4: stur            x1, [x0, #-1]
    // 0xb2d1d8: dmb             ishst
    // 0xb2d1dc: StoreField: r0->field_7 = d0
    //     0xb2d1dc: stur            d0, [x0, #7]
    // 0xb2d1e0: LeaveFrame
    //     0xb2d1e0: mov             SP, fp
    //     0xb2d1e4: ldp             fp, lr, [SP], #0x10
    // 0xb2d1e8: ret
    //     0xb2d1e8: ret             
    // 0xb2d1ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d1ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d1f0: b               #0xb2d1ac
    // 0xb2d1f4: SaveReg d0
    //     0xb2d1f4: str             q0, [SP, #-0x10]!
    // 0xb2d1f8: r0 = AllocateDouble()
    //     0xb2d1f8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d1fc: RestoreReg d0
    //     0xb2d1fc: ldr             q0, [SP], #0x10
    // 0xb2d200: b               #0xb2d1dc
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4d4f4, size: 0x1d4
    // 0xb4d4f4: EnterFrame
    //     0xb4d4f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d4f8: mov             fp, SP
    // 0xb4d4fc: AllocStack(0x38)
    //     0xb4d4fc: sub             SP, SP, #0x38
    // 0xb4d500: SetupParameters(RenderPositionedBox this /* r1 => r2, fp-0x20 */, dynamic _ /* r2 => r0, fp-0x28 */)
    //     0xb4d500: mov             x0, x2
    //     0xb4d504: stur            x2, [fp, #-0x28]
    //     0xb4d508: mov             x2, x1
    //     0xb4d50c: stur            x1, [fp, #-0x20]
    // 0xb4d510: CheckStackOverflow
    //     0xb4d510: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d514: cmp             SP, x16
    //     0xb4d518: b.ls            #0xb4d6c0
    // 0xb4d51c: LoadField: r1 = r2->field_5f
    //     0xb4d51c: ldur            w1, [x2, #0x5f]
    // 0xb4d520: DecompressPointer r1
    //     0xb4d520: add             x1, x1, HEAP, lsl #32
    // 0xb4d524: cmp             w1, NULL
    // 0xb4d528: b.eq            #0xb4d538
    // 0xb4d52c: r3 = true
    //     0xb4d52c: add             x3, NULL, #0x20  ; true
    // 0xb4d530: d0 = inf
    //     0xb4d530: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4d534: b               #0xb4d554
    // 0xb4d538: d0 = inf
    //     0xb4d538: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4d53c: LoadField: d1 = r0->field_f
    //     0xb4d53c: ldur            d1, [x0, #0xf]
    // 0xb4d540: fcmp            d1, d0
    // 0xb4d544: r16 = true
    //     0xb4d544: add             x16, NULL, #0x20  ; true
    // 0xb4d548: r17 = false
    //     0xb4d548: add             x17, NULL, #0x30  ; false
    // 0xb4d54c: csel            x1, x16, x17, eq
    // 0xb4d550: mov             x3, x1
    // 0xb4d554: stur            x3, [fp, #-0x18]
    // 0xb4d558: LoadField: r1 = r2->field_63
    //     0xb4d558: ldur            w1, [x2, #0x63]
    // 0xb4d55c: DecompressPointer r1
    //     0xb4d55c: add             x1, x1, HEAP, lsl #32
    // 0xb4d560: cmp             w1, NULL
    // 0xb4d564: b.eq            #0xb4d570
    // 0xb4d568: r4 = true
    //     0xb4d568: add             x4, NULL, #0x20  ; true
    // 0xb4d56c: b               #0xb4d588
    // 0xb4d570: LoadField: d1 = r0->field_1f
    //     0xb4d570: ldur            d1, [x0, #0x1f]
    // 0xb4d574: fcmp            d1, d0
    // 0xb4d578: r16 = true
    //     0xb4d578: add             x16, NULL, #0x20  ; true
    // 0xb4d57c: r17 = false
    //     0xb4d57c: add             x17, NULL, #0x30  ; false
    // 0xb4d580: csel            x1, x16, x17, eq
    // 0xb4d584: mov             x4, x1
    // 0xb4d588: stur            x4, [fp, #-0x10]
    // 0xb4d58c: LoadField: r5 = r2->field_4f
    //     0xb4d58c: ldur            w5, [x2, #0x4f]
    // 0xb4d590: DecompressPointer r5
    //     0xb4d590: add             x5, x5, HEAP, lsl #32
    // 0xb4d594: stur            x5, [fp, #-8]
    // 0xb4d598: cmp             w5, NULL
    // 0xb4d59c: b.eq            #0xb4d664
    // 0xb4d5a0: mov             x1, x0
    // 0xb4d5a4: r0 = loosen()
    //     0xb4d5a4: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xb4d5a8: ldur            x1, [fp, #-8]
    // 0xb4d5ac: mov             x2, x0
    // 0xb4d5b0: r0 = getDryLayout()
    //     0xb4d5b0: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4d5b4: mov             x1, x0
    // 0xb4d5b8: ldur            x0, [fp, #-0x18]
    // 0xb4d5bc: tbnz            w0, #4, #0xb4d5f0
    // 0xb4d5c0: ldur            x0, [fp, #-0x20]
    // 0xb4d5c4: LoadField: d0 = r1->field_7
    //     0xb4d5c4: ldur            d0, [x1, #7]
    // 0xb4d5c8: LoadField: r2 = r0->field_5f
    //     0xb4d5c8: ldur            w2, [x0, #0x5f]
    // 0xb4d5cc: DecompressPointer r2
    //     0xb4d5cc: add             x2, x2, HEAP, lsl #32
    // 0xb4d5d0: cmp             w2, NULL
    // 0xb4d5d4: b.ne            #0xb4d5e0
    // 0xb4d5d8: d1 = 1.000000
    //     0xb4d5d8: fmov            d1, #1.00000000
    // 0xb4d5dc: b               #0xb4d5e4
    // 0xb4d5e0: LoadField: d1 = r2->field_7
    //     0xb4d5e0: ldur            d1, [x2, #7]
    // 0xb4d5e4: fmul            d2, d0, d1
    // 0xb4d5e8: mov             v0.16b, v2.16b
    // 0xb4d5ec: b               #0xb4d5f8
    // 0xb4d5f0: ldur            x0, [fp, #-0x20]
    // 0xb4d5f4: d0 = inf
    //     0xb4d5f4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4d5f8: ldur            x2, [fp, #-0x10]
    // 0xb4d5fc: stur            d0, [fp, #-0x38]
    // 0xb4d600: tbnz            w2, #4, #0xb4d630
    // 0xb4d604: LoadField: d1 = r1->field_f
    //     0xb4d604: ldur            d1, [x1, #0xf]
    // 0xb4d608: LoadField: r1 = r0->field_63
    //     0xb4d608: ldur            w1, [x0, #0x63]
    // 0xb4d60c: DecompressPointer r1
    //     0xb4d60c: add             x1, x1, HEAP, lsl #32
    // 0xb4d610: cmp             w1, NULL
    // 0xb4d614: b.ne            #0xb4d620
    // 0xb4d618: d2 = 1.000000
    //     0xb4d618: fmov            d2, #1.00000000
    // 0xb4d61c: b               #0xb4d624
    // 0xb4d620: LoadField: d2 = r1->field_7
    //     0xb4d620: ldur            d2, [x1, #7]
    // 0xb4d624: fmul            d3, d1, d2
    // 0xb4d628: mov             v1.16b, v3.16b
    // 0xb4d62c: b               #0xb4d634
    // 0xb4d630: d1 = inf
    //     0xb4d630: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4d634: stur            d1, [fp, #-0x30]
    // 0xb4d638: r0 = Size()
    //     0xb4d638: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4d63c: ldur            d0, [fp, #-0x38]
    // 0xb4d640: StoreField: r0->field_7 = d0
    //     0xb4d640: stur            d0, [x0, #7]
    // 0xb4d644: ldur            d0, [fp, #-0x30]
    // 0xb4d648: StoreField: r0->field_f = d0
    //     0xb4d648: stur            d0, [x0, #0xf]
    // 0xb4d64c: ldur            x1, [fp, #-0x28]
    // 0xb4d650: mov             x2, x0
    // 0xb4d654: r0 = constrain()
    //     0xb4d654: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d658: LeaveFrame
    //     0xb4d658: mov             SP, fp
    //     0xb4d65c: ldp             fp, lr, [SP], #0x10
    // 0xb4d660: ret
    //     0xb4d660: ret             
    // 0xb4d664: mov             x0, x3
    // 0xb4d668: mov             x2, x4
    // 0xb4d66c: tbnz            w0, #4, #0xb4d678
    // 0xb4d670: d0 = 0.000000
    //     0xb4d670: eor             v0.16b, v0.16b, v0.16b
    // 0xb4d674: b               #0xb4d67c
    // 0xb4d678: d0 = inf
    //     0xb4d678: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4d67c: stur            d0, [fp, #-0x38]
    // 0xb4d680: tbnz            w2, #4, #0xb4d68c
    // 0xb4d684: d1 = 0.000000
    //     0xb4d684: eor             v1.16b, v1.16b, v1.16b
    // 0xb4d688: b               #0xb4d690
    // 0xb4d68c: d1 = inf
    //     0xb4d68c: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb4d690: stur            d1, [fp, #-0x30]
    // 0xb4d694: r0 = Size()
    //     0xb4d694: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4d698: ldur            d0, [fp, #-0x38]
    // 0xb4d69c: StoreField: r0->field_7 = d0
    //     0xb4d69c: stur            d0, [x0, #7]
    // 0xb4d6a0: ldur            d0, [fp, #-0x30]
    // 0xb4d6a4: StoreField: r0->field_f = d0
    //     0xb4d6a4: stur            d0, [x0, #0xf]
    // 0xb4d6a8: ldur            x1, [fp, #-0x28]
    // 0xb4d6ac: mov             x2, x0
    // 0xb4d6b0: r0 = constrain()
    //     0xb4d6b0: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d6b4: LeaveFrame
    //     0xb4d6b4: mov             SP, fp
    //     0xb4d6b8: ldp             fp, lr, [SP], #0x10
    // 0xb4d6bc: ret
    //     0xb4d6bc: ret             
    // 0xb4d6c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d6c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d6c4: b               #0xb4d51c
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58294, size: 0x24
    // 0xb58294: EnterFrame
    //     0xb58294: stp             fp, lr, [SP, #-0x10]!
    //     0xb58298: mov             fp, SP
    // 0xb5829c: ldr             x2, [fp, #0x10]
    // 0xb582a0: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb582a0: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2858] AnonymousClosure: (0xb2d18c), in [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::computeMaxIntrinsicWidth (0xb2d0dc)
    //     0xb582a4: ldr             x1, [x1, #0x858]
    // 0xb582a8: r0 = AllocateClosure()
    //     0xb582a8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb582ac: LeaveFrame
    //     0xb582ac: mov             SP, fp
    //     0xb582b0: ldp             fp, lr, [SP], #0x10
    // 0xb582b4: ret
    //     0xb582b4: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e41c, size: 0x24
    // 0xb5e41c: EnterFrame
    //     0xb5e41c: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e420: mov             fp, SP
    // 0xb5e424: ldr             x2, [fp, #0x10]
    // 0xb5e428: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e428: add             x1, PP, #0x98, lsl #12  ; [pp+0x98518] AnonymousClosure: (0xb29d5c), in [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::computeMaxIntrinsicHeight (0xb29cac)
    //     0xb5e42c: ldr             x1, [x1, #0x518]
    // 0xb5e430: r0 = AllocateClosure()
    //     0xb5e430: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e434: LeaveFrame
    //     0xb5e434: mov             SP, fp
    //     0xb5e438: ldp             fp, lr, [SP], #0x10
    // 0xb5e43c: ret
    //     0xb5e43c: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb60258, size: 0x250
    // 0xb60258: EnterFrame
    //     0xb60258: stp             fp, lr, [SP, #-0x10]!
    //     0xb6025c: mov             fp, SP
    // 0xb60260: AllocStack(0x38)
    //     0xb60260: sub             SP, SP, #0x38
    // 0xb60264: SetupParameters(RenderPositionedBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb60264: mov             x5, x1
    //     0xb60268: mov             x4, x2
    //     0xb6026c: stur            x1, [fp, #-8]
    //     0xb60270: stur            x2, [fp, #-0x10]
    //     0xb60274: stur            x3, [fp, #-0x18]
    // 0xb60278: CheckStackOverflow
    //     0xb60278: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb6027c: cmp             SP, x16
    //     0xb60280: b.ls            #0xb60490
    // 0xb60284: mov             x0, x4
    // 0xb60288: r2 = Null
    //     0xb60288: mov             x2, NULL
    // 0xb6028c: r1 = Null
    //     0xb6028c: mov             x1, NULL
    // 0xb60290: r4 = 60
    //     0xb60290: mov             x4, #0x3c
    // 0xb60294: branchIfSmi(r0, 0xb602a0)
    //     0xb60294: tbz             w0, #0, #0xb602a0
    // 0xb60298: r4 = LoadClassIdInstr(r0)
    //     0xb60298: ldur            x4, [x0, #-1]
    //     0xb6029c: ubfx            x4, x4, #0xc, #0x14
    // 0xb602a0: sub             x4, x4, #0xb46
    // 0xb602a4: cmp             x4, #1
    // 0xb602a8: b.ls            #0xb602bc
    // 0xb602ac: r8 = BoxConstraints
    //     0xb602ac: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb602b0: r3 = Null
    //     0xb602b0: add             x3, PP, #0x98, lsl #12  ; [pp+0x98520] Null
    //     0xb602b4: ldr             x3, [x3, #0x520]
    // 0xb602b8: r0 = BoxConstraints()
    //     0xb602b8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb602bc: ldur            x0, [fp, #-8]
    // 0xb602c0: LoadField: r2 = r0->field_4f
    //     0xb602c0: ldur            w2, [x0, #0x4f]
    // 0xb602c4: DecompressPointer r2
    //     0xb602c4: add             x2, x2, HEAP, lsl #32
    // 0xb602c8: stur            x2, [fp, #-0x20]
    // 0xb602cc: cmp             w2, NULL
    // 0xb602d0: b.ne            #0xb602e4
    // 0xb602d4: r0 = Null
    //     0xb602d4: mov             x0, NULL
    // 0xb602d8: LeaveFrame
    //     0xb602d8: mov             SP, fp
    //     0xb602dc: ldp             fp, lr, [SP], #0x10
    // 0xb602e0: ret
    //     0xb602e0: ret             
    // 0xb602e4: ldur            x1, [fp, #-0x10]
    // 0xb602e8: r0 = loosen()
    //     0xb602e8: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xb602ec: ldur            x1, [fp, #-0x20]
    // 0xb602f0: mov             x2, x0
    // 0xb602f4: ldur            x3, [fp, #-0x18]
    // 0xb602f8: stur            x0, [fp, #-0x18]
    // 0xb602fc: r0 = getDryBaseline()
    //     0xb602fc: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60300: stur            x0, [fp, #-0x28]
    // 0xb60304: cmp             w0, NULL
    // 0xb60308: b.ne            #0xb6031c
    // 0xb6030c: r0 = Null
    //     0xb6030c: mov             x0, NULL
    // 0xb60310: LeaveFrame
    //     0xb60310: mov             SP, fp
    //     0xb60314: ldp             fp, lr, [SP], #0x10
    // 0xb60318: ret
    //     0xb60318: ret             
    // 0xb6031c: ldur            x3, [fp, #-8]
    // 0xb60320: ldur            x1, [fp, #-0x20]
    // 0xb60324: ldur            x2, [fp, #-0x18]
    // 0xb60328: r0 = getDryLayout()
    //     0xb60328: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb6032c: ldur            x1, [fp, #-8]
    // 0xb60330: stur            x0, [fp, #-0x18]
    // 0xb60334: LoadField: r2 = r1->field_5f
    //     0xb60334: ldur            w2, [x1, #0x5f]
    // 0xb60338: DecompressPointer r2
    //     0xb60338: add             x2, x2, HEAP, lsl #32
    // 0xb6033c: cmp             w2, NULL
    // 0xb60340: b.eq            #0xb60354
    // 0xb60344: ldur            x3, [fp, #-0x10]
    // 0xb60348: r4 = true
    //     0xb60348: add             x4, NULL, #0x20  ; true
    // 0xb6034c: d0 = inf
    //     0xb6034c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb60350: b               #0xb60370
    // 0xb60354: ldur            x3, [fp, #-0x10]
    // 0xb60358: d0 = inf
    //     0xb60358: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb6035c: LoadField: d1 = r3->field_f
    //     0xb6035c: ldur            d1, [x3, #0xf]
    // 0xb60360: fcmp            d1, d0
    // 0xb60364: r16 = true
    //     0xb60364: add             x16, NULL, #0x20  ; true
    // 0xb60368: r17 = false
    //     0xb60368: add             x17, NULL, #0x30  ; false
    // 0xb6036c: csel            x4, x16, x17, eq
    // 0xb60370: LoadField: r5 = r1->field_63
    //     0xb60370: ldur            w5, [x1, #0x63]
    // 0xb60374: DecompressPointer r5
    //     0xb60374: add             x5, x5, HEAP, lsl #32
    // 0xb60378: cmp             w5, NULL
    // 0xb6037c: b.eq            #0xb60388
    // 0xb60380: r6 = true
    //     0xb60380: add             x6, NULL, #0x20  ; true
    // 0xb60384: b               #0xb6039c
    // 0xb60388: LoadField: d1 = r3->field_1f
    //     0xb60388: ldur            d1, [x3, #0x1f]
    // 0xb6038c: fcmp            d1, d0
    // 0xb60390: r16 = true
    //     0xb60390: add             x16, NULL, #0x20  ; true
    // 0xb60394: r17 = false
    //     0xb60394: add             x17, NULL, #0x30  ; false
    // 0xb60398: csel            x6, x16, x17, eq
    // 0xb6039c: tbnz            w4, #4, #0xb603c4
    // 0xb603a0: LoadField: d0 = r0->field_7
    //     0xb603a0: ldur            d0, [x0, #7]
    // 0xb603a4: cmp             w2, NULL
    // 0xb603a8: b.ne            #0xb603b4
    // 0xb603ac: d1 = 1.000000
    //     0xb603ac: fmov            d1, #1.00000000
    // 0xb603b0: b               #0xb603b8
    // 0xb603b4: LoadField: d1 = r2->field_7
    //     0xb603b4: ldur            d1, [x2, #7]
    // 0xb603b8: fmul            d2, d0, d1
    // 0xb603bc: mov             v0.16b, v2.16b
    // 0xb603c0: b               #0xb603c8
    // 0xb603c4: d0 = inf
    //     0xb603c4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb603c8: stur            d0, [fp, #-0x38]
    // 0xb603cc: tbnz            w6, #4, #0xb603f4
    // 0xb603d0: LoadField: d1 = r0->field_f
    //     0xb603d0: ldur            d1, [x0, #0xf]
    // 0xb603d4: cmp             w5, NULL
    // 0xb603d8: b.ne            #0xb603e4
    // 0xb603dc: d2 = 1.000000
    //     0xb603dc: fmov            d2, #1.00000000
    // 0xb603e0: b               #0xb603e8
    // 0xb603e4: LoadField: d2 = r5->field_7
    //     0xb603e4: ldur            d2, [x5, #7]
    // 0xb603e8: fmul            d3, d1, d2
    // 0xb603ec: mov             v1.16b, v3.16b
    // 0xb603f0: b               #0xb603f8
    // 0xb603f4: d1 = inf
    //     0xb603f4: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb603f8: ldur            x2, [fp, #-0x28]
    // 0xb603fc: stur            d1, [fp, #-0x30]
    // 0xb60400: r0 = Size()
    //     0xb60400: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb60404: ldur            d0, [fp, #-0x38]
    // 0xb60408: StoreField: r0->field_7 = d0
    //     0xb60408: stur            d0, [x0, #7]
    // 0xb6040c: ldur            d0, [fp, #-0x30]
    // 0xb60410: StoreField: r0->field_f = d0
    //     0xb60410: stur            d0, [x0, #0xf]
    // 0xb60414: ldur            x1, [fp, #-0x10]
    // 0xb60418: mov             x2, x0
    // 0xb6041c: r0 = constrain()
    //     0xb6041c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb60420: ldur            x1, [fp, #-8]
    // 0xb60424: stur            x0, [fp, #-8]
    // 0xb60428: r0 = resolvedAlignment()
    //     0xb60428: bl              #0xb5fd7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::resolvedAlignment
    // 0xb6042c: ldur            x1, [fp, #-8]
    // 0xb60430: ldur            x2, [fp, #-0x18]
    // 0xb60434: stur            x0, [fp, #-8]
    // 0xb60438: r0 = -()
    //     0xb60438: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb6043c: ldur            x1, [fp, #-8]
    // 0xb60440: mov             x2, x0
    // 0xb60444: r0 = alongOffset()
    //     0xb60444: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb60448: LoadField: d0 = r0->field_f
    //     0xb60448: ldur            d0, [x0, #0xf]
    // 0xb6044c: ldur            x1, [fp, #-0x28]
    // 0xb60450: LoadField: d1 = r1->field_7
    //     0xb60450: ldur            d1, [x1, #7]
    // 0xb60454: fadd            d2, d1, d0
    // 0xb60458: r0 = inline_Allocate_Double()
    //     0xb60458: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb6045c: add             x0, x0, #0x10
    //     0xb60460: cmp             x1, x0
    //     0xb60464: b.ls            #0xb60498
    //     0xb60468: str             x0, [THR, #0x60]  ; THR::top
    //     0xb6046c: sub             x0, x0, #0xf
    //     0xb60470: mov             x1, #0xe19c
    //     0xb60474: movk            x1, #3, lsl #16
    //     0xb60478: stur            x1, [x0, #-1]
    // 0xb6047c: dmb             ishst
    // 0xb60480: StoreField: r0->field_7 = d2
    //     0xb60480: stur            d2, [x0, #7]
    // 0xb60484: LeaveFrame
    //     0xb60484: mov             SP, fp
    //     0xb60488: ldp             fp, lr, [SP], #0x10
    // 0xb6048c: ret
    //     0xb6048c: ret             
    // 0xb60490: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60490: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb60494: b               #0xb60284
    // 0xb60498: SaveReg d2
    //     0xb60498: str             q2, [SP, #-0x10]!
    // 0xb6049c: r0 = AllocateDouble()
    //     0xb6049c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb604a0: RestoreReg d2
    //     0xb604a0: ldr             q2, [SP], #0x10
    // 0xb604a4: b               #0xb60480
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbbd98, size: 0x2e8
    // 0xbbbd98: EnterFrame
    //     0xbbbd98: stp             fp, lr, [SP, #-0x10]!
    //     0xbbbd9c: mov             fp, SP
    // 0xbbbda0: AllocStack(0x40)
    //     0xbbbda0: sub             SP, SP, #0x40
    // 0xbbbda4: SetupParameters(RenderPositionedBox this /* r1 => r3, fp-0x10 */)
    //     0xbbbda4: mov             x3, x1
    //     0xbbbda8: stur            x1, [fp, #-0x10]
    // 0xbbbdac: CheckStackOverflow
    //     0xbbbdac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbbdb0: cmp             SP, x16
    //     0xbbbdb4: b.ls            #0xbbc070
    // 0xbbbdb8: LoadField: r4 = r3->field_27
    //     0xbbbdb8: ldur            w4, [x3, #0x27]
    // 0xbbbdbc: DecompressPointer r4
    //     0xbbbdbc: add             x4, x4, HEAP, lsl #32
    // 0xbbbdc0: stur            x4, [fp, #-8]
    // 0xbbbdc4: cmp             w4, NULL
    // 0xbbbdc8: b.eq            #0xbbc054
    // 0xbbbdcc: mov             x0, x4
    // 0xbbbdd0: r2 = Null
    //     0xbbbdd0: mov             x2, NULL
    // 0xbbbdd4: r1 = Null
    //     0xbbbdd4: mov             x1, NULL
    // 0xbbbdd8: r4 = LoadClassIdInstr(r0)
    //     0xbbbdd8: ldur            x4, [x0, #-1]
    //     0xbbbddc: ubfx            x4, x4, #0xc, #0x14
    // 0xbbbde0: sub             x4, x4, #0xb46
    // 0xbbbde4: cmp             x4, #1
    // 0xbbbde8: b.ls            #0xbbbdfc
    // 0xbbbdec: r8 = BoxConstraints
    //     0xbbbdec: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbbdf0: r3 = Null
    //     0xbbbdf0: add             x3, PP, #0x81, lsl #12  ; [pp+0x81cc8] Null
    //     0xbbbdf4: ldr             x3, [x3, #0xcc8]
    // 0xbbbdf8: r0 = BoxConstraints()
    //     0xbbbdf8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbbdfc: ldur            x0, [fp, #-0x10]
    // 0xbbbe00: LoadField: r1 = r0->field_5f
    //     0xbbbe00: ldur            w1, [x0, #0x5f]
    // 0xbbbe04: DecompressPointer r1
    //     0xbbbe04: add             x1, x1, HEAP, lsl #32
    // 0xbbbe08: cmp             w1, NULL
    // 0xbbbe0c: b.eq            #0xbbbe20
    // 0xbbbe10: ldur            x2, [fp, #-8]
    // 0xbbbe14: r3 = true
    //     0xbbbe14: add             x3, NULL, #0x20  ; true
    // 0xbbbe18: d0 = inf
    //     0xbbbe18: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbbbe1c: b               #0xbbbe40
    // 0xbbbe20: ldur            x2, [fp, #-8]
    // 0xbbbe24: d0 = inf
    //     0xbbbe24: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbbbe28: LoadField: d1 = r2->field_f
    //     0xbbbe28: ldur            d1, [x2, #0xf]
    // 0xbbbe2c: fcmp            d1, d0
    // 0xbbbe30: r16 = true
    //     0xbbbe30: add             x16, NULL, #0x20  ; true
    // 0xbbbe34: r17 = false
    //     0xbbbe34: add             x17, NULL, #0x30  ; false
    // 0xbbbe38: csel            x1, x16, x17, eq
    // 0xbbbe3c: mov             x3, x1
    // 0xbbbe40: stur            x3, [fp, #-0x28]
    // 0xbbbe44: LoadField: r1 = r0->field_63
    //     0xbbbe44: ldur            w1, [x0, #0x63]
    // 0xbbbe48: DecompressPointer r1
    //     0xbbbe48: add             x1, x1, HEAP, lsl #32
    // 0xbbbe4c: cmp             w1, NULL
    // 0xbbbe50: b.eq            #0xbbbe5c
    // 0xbbbe54: r4 = true
    //     0xbbbe54: add             x4, NULL, #0x20  ; true
    // 0xbbbe58: b               #0xbbbe74
    // 0xbbbe5c: LoadField: d1 = r2->field_1f
    //     0xbbbe5c: ldur            d1, [x2, #0x1f]
    // 0xbbbe60: fcmp            d1, d0
    // 0xbbbe64: r16 = true
    //     0xbbbe64: add             x16, NULL, #0x20  ; true
    // 0xbbbe68: r17 = false
    //     0xbbbe68: add             x17, NULL, #0x30  ; false
    // 0xbbbe6c: csel            x1, x16, x17, eq
    // 0xbbbe70: mov             x4, x1
    // 0xbbbe74: stur            x4, [fp, #-0x20]
    // 0xbbbe78: LoadField: r5 = r0->field_4f
    //     0xbbbe78: ldur            w5, [x0, #0x4f]
    // 0xbbbe7c: DecompressPointer r5
    //     0xbbbe7c: add             x5, x5, HEAP, lsl #32
    // 0xbbbe80: stur            x5, [fp, #-0x18]
    // 0xbbbe84: cmp             w5, NULL
    // 0xbbbe88: b.eq            #0xbbbfd0
    // 0xbbbe8c: mov             x1, x2
    // 0xbbbe90: r0 = loosen()
    //     0xbbbe90: bl              #0xb4ae38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0xbbbe94: ldur            x1, [fp, #-0x18]
    // 0xbbbe98: r2 = LoadClassIdInstr(r1)
    //     0xbbbe98: ldur            x2, [x1, #-1]
    //     0xbbbe9c: ubfx            x2, x2, #0xc, #0x14
    // 0xbbbea0: r16 = true
    //     0xbbbea0: add             x16, NULL, #0x20  ; true
    // 0xbbbea4: str             x16, [SP]
    // 0xbbbea8: mov             x16, x0
    // 0xbbbeac: mov             x0, x2
    // 0xbbbeb0: mov             x2, x16
    // 0xbbbeb4: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbbeb4: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbbeb8: ldr             x4, [x4, #0xed0]
    // 0xbbbebc: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbbebc: mov             x17, #0xe6b9
    //     0xbbbec0: add             lr, x0, x17
    //     0xbbbec4: ldr             lr, [x21, lr, lsl #3]
    //     0xbbbec8: blr             lr
    // 0xbbbecc: ldur            x0, [fp, #-0x28]
    // 0xbbbed0: tbnz            w0, #4, #0xbbbf1c
    // 0xbbbed4: ldur            x0, [fp, #-0x10]
    // 0xbbbed8: LoadField: r1 = r0->field_4f
    //     0xbbbed8: ldur            w1, [x0, #0x4f]
    // 0xbbbedc: DecompressPointer r1
    //     0xbbbedc: add             x1, x1, HEAP, lsl #32
    // 0xbbbee0: cmp             w1, NULL
    // 0xbbbee4: b.eq            #0xbbc078
    // 0xbbbee8: r0 = size()
    //     0xbbbee8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbbeec: LoadField: d0 = r0->field_7
    //     0xbbbeec: ldur            d0, [x0, #7]
    // 0xbbbef0: ldur            x0, [fp, #-0x10]
    // 0xbbbef4: LoadField: r1 = r0->field_5f
    //     0xbbbef4: ldur            w1, [x0, #0x5f]
    // 0xbbbef8: DecompressPointer r1
    //     0xbbbef8: add             x1, x1, HEAP, lsl #32
    // 0xbbbefc: cmp             w1, NULL
    // 0xbbbf00: b.ne            #0xbbbf0c
    // 0xbbbf04: d1 = 1.000000
    //     0xbbbf04: fmov            d1, #1.00000000
    // 0xbbbf08: b               #0xbbbf10
    // 0xbbbf0c: LoadField: d1 = r1->field_7
    //     0xbbbf0c: ldur            d1, [x1, #7]
    // 0xbbbf10: fmul            d2, d0, d1
    // 0xbbbf14: mov             v0.16b, v2.16b
    // 0xbbbf18: b               #0xbbbf24
    // 0xbbbf1c: ldur            x0, [fp, #-0x10]
    // 0xbbbf20: d0 = inf
    //     0xbbbf20: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbbbf24: ldur            x1, [fp, #-0x20]
    // 0xbbbf28: stur            d0, [fp, #-0x30]
    // 0xbbbf2c: tbnz            w1, #4, #0xbbbf74
    // 0xbbbf30: LoadField: r1 = r0->field_4f
    //     0xbbbf30: ldur            w1, [x0, #0x4f]
    // 0xbbbf34: DecompressPointer r1
    //     0xbbbf34: add             x1, x1, HEAP, lsl #32
    // 0xbbbf38: cmp             w1, NULL
    // 0xbbbf3c: b.eq            #0xbbc07c
    // 0xbbbf40: r0 = size()
    //     0xbbbf40: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbbf44: LoadField: d0 = r0->field_f
    //     0xbbbf44: ldur            d0, [x0, #0xf]
    // 0xbbbf48: ldur            x1, [fp, #-0x10]
    // 0xbbbf4c: LoadField: r0 = r1->field_63
    //     0xbbbf4c: ldur            w0, [x1, #0x63]
    // 0xbbbf50: DecompressPointer r0
    //     0xbbbf50: add             x0, x0, HEAP, lsl #32
    // 0xbbbf54: cmp             w0, NULL
    // 0xbbbf58: b.ne            #0xbbbf64
    // 0xbbbf5c: d1 = 1.000000
    //     0xbbbf5c: fmov            d1, #1.00000000
    // 0xbbbf60: b               #0xbbbf68
    // 0xbbbf64: LoadField: d1 = r0->field_7
    //     0xbbbf64: ldur            d1, [x0, #7]
    // 0xbbbf68: fmul            d2, d0, d1
    // 0xbbbf6c: mov             v1.16b, v2.16b
    // 0xbbbf70: b               #0xbbbf7c
    // 0xbbbf74: mov             x1, x0
    // 0xbbbf78: d1 = inf
    //     0xbbbf78: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbbbf7c: ldur            d0, [fp, #-0x30]
    // 0xbbbf80: stur            d1, [fp, #-0x38]
    // 0xbbbf84: r0 = Size()
    //     0xbbbf84: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbbf88: ldur            d0, [fp, #-0x30]
    // 0xbbbf8c: StoreField: r0->field_7 = d0
    //     0xbbbf8c: stur            d0, [x0, #7]
    // 0xbbbf90: ldur            d0, [fp, #-0x38]
    // 0xbbbf94: StoreField: r0->field_f = d0
    //     0xbbbf94: stur            d0, [x0, #0xf]
    // 0xbbbf98: ldur            x1, [fp, #-8]
    // 0xbbbf9c: mov             x2, x0
    // 0xbbbfa0: r0 = constrain()
    //     0xbbbfa0: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbbfa4: ldur            x2, [fp, #-0x10]
    // 0xbbbfa8: StoreField: r2->field_4b = r0
    //     0xbbbfa8: stur            w0, [x2, #0x4b]
    //     0xbbbfac: ldurb           w16, [x2, #-1]
    //     0xbbbfb0: ldurb           w17, [x0, #-1]
    //     0xbbbfb4: and             x16, x17, x16, lsr #2
    //     0xbbbfb8: tst             x16, HEAP, lsr #32
    //     0xbbbfbc: b.eq            #0xbbbfc4
    //     0xbbbfc0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbbfc4: mov             x1, x2
    // 0xbbbfc8: r0 = alignChild()
    //     0xbbbfc8: bl              #0xbbad50  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0xbbbfcc: b               #0xbbc044
    // 0xbbbfd0: mov             x2, x0
    // 0xbbbfd4: mov             x0, x3
    // 0xbbbfd8: mov             x1, x4
    // 0xbbbfdc: tbnz            w0, #4, #0xbbbfe8
    // 0xbbbfe0: d0 = 0.000000
    //     0xbbbfe0: eor             v0.16b, v0.16b, v0.16b
    // 0xbbbfe4: b               #0xbbbfec
    // 0xbbbfe8: d0 = inf
    //     0xbbbfe8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbbbfec: stur            d0, [fp, #-0x38]
    // 0xbbbff0: tbnz            w1, #4, #0xbbbffc
    // 0xbbbff4: d1 = 0.000000
    //     0xbbbff4: eor             v1.16b, v1.16b, v1.16b
    // 0xbbbff8: b               #0xbbc000
    // 0xbbbffc: d1 = inf
    //     0xbbbffc: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xbbc000: stur            d1, [fp, #-0x30]
    // 0xbbc004: r0 = Size()
    //     0xbbc004: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbc008: ldur            d0, [fp, #-0x38]
    // 0xbbc00c: StoreField: r0->field_7 = d0
    //     0xbbc00c: stur            d0, [x0, #7]
    // 0xbbc010: ldur            d0, [fp, #-0x30]
    // 0xbbc014: StoreField: r0->field_f = d0
    //     0xbbc014: stur            d0, [x0, #0xf]
    // 0xbbc018: ldur            x1, [fp, #-8]
    // 0xbbc01c: mov             x2, x0
    // 0xbbc020: r0 = constrain()
    //     0xbbc020: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbc024: ldur            x1, [fp, #-0x10]
    // 0xbbc028: StoreField: r1->field_4b = r0
    //     0xbbc028: stur            w0, [x1, #0x4b]
    //     0xbbc02c: ldurb           w16, [x1, #-1]
    //     0xbbc030: ldurb           w17, [x0, #-1]
    //     0xbbc034: and             x16, x17, x16, lsr #2
    //     0xbbc038: tst             x16, HEAP, lsr #32
    //     0xbbc03c: b.eq            #0xbbc044
    //     0xbbc040: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbc044: r0 = Null
    //     0xbbc044: mov             x0, NULL
    // 0xbbc048: LeaveFrame
    //     0xbbc048: mov             SP, fp
    //     0xbbc04c: ldp             fp, lr, [SP], #0x10
    // 0xbbc050: ret
    //     0xbbc050: ret             
    // 0xbbc054: r0 = StateError()
    //     0xbbc054: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbc058: mov             x1, x0
    // 0xbbc05c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbc05c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbc060: StoreField: r1->field_b = r0
    //     0xbbc060: stur            w0, [x1, #0xb]
    // 0xbbc064: mov             x0, x1
    // 0xbbc068: r0 = Throw()
    //     0xbbc068: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbc06c: brk             #0
    // 0xbbc070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbc070: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbc074: b               #0xbbbdb8
    // 0xbbc078: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbc078: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbc07c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbc07c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ heightFactor=(/* No info */) {
    // ** addr: 0xcf7c5c, size: 0xa4
    // 0xcf7c5c: EnterFrame
    //     0xcf7c5c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7c60: mov             fp, SP
    // 0xcf7c64: AllocStack(0x20)
    //     0xcf7c64: sub             SP, SP, #0x20
    // 0xcf7c68: SetupParameters(RenderPositionedBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf7c68: stur            x1, [fp, #-8]
    //     0xcf7c6c: mov             x16, x2
    //     0xcf7c70: mov             x2, x1
    //     0xcf7c74: mov             x1, x16
    //     0xcf7c78: stur            x1, [fp, #-0x10]
    // 0xcf7c7c: CheckStackOverflow
    //     0xcf7c7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7c80: cmp             SP, x16
    //     0xcf7c84: b.ls            #0xcf7cf8
    // 0xcf7c88: LoadField: r0 = r2->field_63
    //     0xcf7c88: ldur            w0, [x2, #0x63]
    // 0xcf7c8c: DecompressPointer r0
    //     0xcf7c8c: add             x0, x0, HEAP, lsl #32
    // 0xcf7c90: r3 = LoadClassIdInstr(r0)
    //     0xcf7c90: ldur            x3, [x0, #-1]
    //     0xcf7c94: ubfx            x3, x3, #0xc, #0x14
    // 0xcf7c98: stp             x1, x0, [SP]
    // 0xcf7c9c: mov             x0, x3
    // 0xcf7ca0: mov             lr, x0
    // 0xcf7ca4: ldr             lr, [x21, lr, lsl #3]
    // 0xcf7ca8: blr             lr
    // 0xcf7cac: tbnz            w0, #4, #0xcf7cc0
    // 0xcf7cb0: r0 = Null
    //     0xcf7cb0: mov             x0, NULL
    // 0xcf7cb4: LeaveFrame
    //     0xcf7cb4: mov             SP, fp
    //     0xcf7cb8: ldp             fp, lr, [SP], #0x10
    // 0xcf7cbc: ret
    //     0xcf7cbc: ret             
    // 0xcf7cc0: ldur            x1, [fp, #-8]
    // 0xcf7cc4: ldur            x0, [fp, #-0x10]
    // 0xcf7cc8: StoreField: r1->field_63 = r0
    //     0xcf7cc8: stur            w0, [x1, #0x63]
    //     0xcf7ccc: ldurb           w16, [x1, #-1]
    //     0xcf7cd0: ldurb           w17, [x0, #-1]
    //     0xcf7cd4: and             x16, x17, x16, lsr #2
    //     0xcf7cd8: tst             x16, HEAP, lsr #32
    //     0xcf7cdc: b.eq            #0xcf7ce4
    //     0xcf7ce0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf7ce4: r0 = markNeedsLayout()
    //     0xcf7ce4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf7ce8: r0 = Null
    //     0xcf7ce8: mov             x0, NULL
    // 0xcf7cec: LeaveFrame
    //     0xcf7cec: mov             SP, fp
    //     0xcf7cf0: ldp             fp, lr, [SP], #0x10
    // 0xcf7cf4: ret
    //     0xcf7cf4: ret             
    // 0xcf7cf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7cf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7cfc: b               #0xcf7c88
  }
  set _ widthFactor=(/* No info */) {
    // ** addr: 0xcf7d00, size: 0xa4
    // 0xcf7d00: EnterFrame
    //     0xcf7d00: stp             fp, lr, [SP, #-0x10]!
    //     0xcf7d04: mov             fp, SP
    // 0xcf7d08: AllocStack(0x20)
    //     0xcf7d08: sub             SP, SP, #0x20
    // 0xcf7d0c: SetupParameters(RenderPositionedBox this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcf7d0c: stur            x1, [fp, #-8]
    //     0xcf7d10: mov             x16, x2
    //     0xcf7d14: mov             x2, x1
    //     0xcf7d18: mov             x1, x16
    //     0xcf7d1c: stur            x1, [fp, #-0x10]
    // 0xcf7d20: CheckStackOverflow
    //     0xcf7d20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf7d24: cmp             SP, x16
    //     0xcf7d28: b.ls            #0xcf7d9c
    // 0xcf7d2c: LoadField: r0 = r2->field_5f
    //     0xcf7d2c: ldur            w0, [x2, #0x5f]
    // 0xcf7d30: DecompressPointer r0
    //     0xcf7d30: add             x0, x0, HEAP, lsl #32
    // 0xcf7d34: r3 = LoadClassIdInstr(r0)
    //     0xcf7d34: ldur            x3, [x0, #-1]
    //     0xcf7d38: ubfx            x3, x3, #0xc, #0x14
    // 0xcf7d3c: stp             x1, x0, [SP]
    // 0xcf7d40: mov             x0, x3
    // 0xcf7d44: mov             lr, x0
    // 0xcf7d48: ldr             lr, [x21, lr, lsl #3]
    // 0xcf7d4c: blr             lr
    // 0xcf7d50: tbnz            w0, #4, #0xcf7d64
    // 0xcf7d54: r0 = Null
    //     0xcf7d54: mov             x0, NULL
    // 0xcf7d58: LeaveFrame
    //     0xcf7d58: mov             SP, fp
    //     0xcf7d5c: ldp             fp, lr, [SP], #0x10
    // 0xcf7d60: ret
    //     0xcf7d60: ret             
    // 0xcf7d64: ldur            x1, [fp, #-8]
    // 0xcf7d68: ldur            x0, [fp, #-0x10]
    // 0xcf7d6c: StoreField: r1->field_5f = r0
    //     0xcf7d6c: stur            w0, [x1, #0x5f]
    //     0xcf7d70: ldurb           w16, [x1, #-1]
    //     0xcf7d74: ldurb           w17, [x0, #-1]
    //     0xcf7d78: and             x16, x17, x16, lsr #2
    //     0xcf7d7c: tst             x16, HEAP, lsr #32
    //     0xcf7d80: b.eq            #0xcf7d88
    //     0xcf7d84: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf7d88: r0 = markNeedsLayout()
    //     0xcf7d88: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf7d8c: r0 = Null
    //     0xcf7d8c: mov             x0, NULL
    // 0xcf7d90: LeaveFrame
    //     0xcf7d90: mov             SP, fp
    //     0xcf7d94: ldp             fp, lr, [SP], #0x10
    // 0xcf7d98: ret
    //     0xcf7d98: ret             
    // 0xcf7d9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf7d9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf7da0: b               #0xcf7d2c
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efc28, size: 0x24
    // 0x10efc28: EnterFrame
    //     0x10efc28: stp             fp, lr, [SP, #-0x10]!
    //     0x10efc2c: mov             fp, SP
    // 0x10efc30: ldr             x2, [fp, #0x10]
    // 0x10efc34: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efc34: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2850] AnonymousClosure: (0xb23130), in [package:flutter/src/rendering/shifted_box.dart] RenderPositionedBox::computeMinIntrinsicHeight (0xb23080)
    //     0x10efc38: ldr             x1, [x1, #0x850]
    // 0x10efc3c: r0 = AllocateClosure()
    //     0x10efc3c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efc40: LeaveFrame
    //     0x10efc40: mov             SP, fp
    //     0x10efc44: ldp             fp, lr, [SP], #0x10
    // 0x10efc48: ret
    //     0x10efc48: ret             
  }
  _ RenderPositionedBox(/* No info */) {
    // ** addr: 0x11d13f0, size: 0x100
    // 0x11d13f0: EnterFrame
    //     0x11d13f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11d13f4: mov             fp, SP
    // 0x11d13f8: AllocStack(0x8)
    //     0x11d13f8: sub             SP, SP, #8
    // 0x11d13fc: SetupParameters(RenderPositionedBox this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3 */, dynamic _ /* r3 => r2 */)
    //     0x11d13fc: mov             x4, x1
    //     0x11d1400: mov             x16, x3
    //     0x11d1404: mov             x3, x2
    //     0x11d1408: mov             x2, x16
    //     0x11d140c: stur            x1, [fp, #-8]
    //     0x11d1410: mov             x1, x5
    //     0x11d1414: mov             x0, x6
    // 0x11d1418: CheckStackOverflow
    //     0x11d1418: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d141c: cmp             SP, x16
    //     0x11d1420: b.ls            #0x11d14e8
    // 0x11d1424: StoreField: r4->field_5f = r0
    //     0x11d1424: stur            w0, [x4, #0x5f]
    //     0x11d1428: ldurb           w16, [x4, #-1]
    //     0x11d142c: ldurb           w17, [x0, #-1]
    //     0x11d1430: and             x16, x17, x16, lsr #2
    //     0x11d1434: tst             x16, HEAP, lsr #32
    //     0x11d1438: b.eq            #0x11d1440
    //     0x11d143c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11d1440: mov             x0, x2
    // 0x11d1444: StoreField: r4->field_63 = r0
    //     0x11d1444: stur            w0, [x4, #0x63]
    //     0x11d1448: ldurb           w16, [x4, #-1]
    //     0x11d144c: ldurb           w17, [x0, #-1]
    //     0x11d1450: and             x16, x17, x16, lsr #2
    //     0x11d1454: tst             x16, HEAP, lsr #32
    //     0x11d1458: b.eq            #0x11d1460
    //     0x11d145c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11d1460: mov             x0, x3
    // 0x11d1464: StoreField: r4->field_57 = r0
    //     0x11d1464: stur            w0, [x4, #0x57]
    //     0x11d1468: ldurb           w16, [x4, #-1]
    //     0x11d146c: ldurb           w17, [x0, #-1]
    //     0x11d1470: and             x16, x17, x16, lsr #2
    //     0x11d1474: tst             x16, HEAP, lsr #32
    //     0x11d1478: b.eq            #0x11d1480
    //     0x11d147c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11d1480: mov             x0, x1
    // 0x11d1484: StoreField: r4->field_5b = r0
    //     0x11d1484: stur            w0, [x4, #0x5b]
    //     0x11d1488: ldurb           w16, [x4, #-1]
    //     0x11d148c: ldurb           w17, [x0, #-1]
    //     0x11d1490: and             x16, x17, x16, lsr #2
    //     0x11d1494: tst             x16, HEAP, lsr #32
    //     0x11d1498: b.eq            #0x11d14a0
    //     0x11d149c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11d14a0: r0 = _LayoutCacheStorage()
    //     0x11d14a0: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d14a4: ldur            x2, [fp, #-8]
    // 0x11d14a8: StoreField: r2->field_47 = r0
    //     0x11d14a8: stur            w0, [x2, #0x47]
    //     0x11d14ac: ldurb           w16, [x2, #-1]
    //     0x11d14b0: ldurb           w17, [x0, #-1]
    //     0x11d14b4: and             x16, x17, x16, lsr #2
    //     0x11d14b8: tst             x16, HEAP, lsr #32
    //     0x11d14bc: b.eq            #0x11d14c4
    //     0x11d14c0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d14c4: mov             x1, x2
    // 0x11d14c8: r0 = RenderObject()
    //     0x11d14c8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d14cc: ldur            x1, [fp, #-8]
    // 0x11d14d0: r2 = Null
    //     0x11d14d0: mov             x2, NULL
    // 0x11d14d4: r0 = child=()
    //     0x11d14d4: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d14d8: r0 = Null
    //     0x11d14d8: mov             x0, NULL
    // 0x11d14dc: LeaveFrame
    //     0x11d14dc: mov             SP, fp
    //     0x11d14e0: ldp             fp, lr, [SP], #0x10
    // 0x11d14e4: ret
    //     0x11d14e4: ret             
    // 0x11d14e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d14e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d14ec: b               #0x11d1424
  }
}

// class id: 4891, size: 0x80, field offset: 0x64
class RenderConstraintsTransformBox extends _MixinApplication445&RenderAligningShiftedBox&DebugOverflowIndicatorMixin {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb16b6c, size: 0x24
    // 0xb16b6c: EnterFrame
    //     0xb16b6c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16b70: mov             fp, SP
    // 0xb16b74: ldr             x2, [fp, #0x10]
    // 0xb16b78: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb16b78: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa28e8] AnonymousClosure: (0xb16b90), in [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMinIntrinsicWidth (0xb16c08)
    //     0xb16b7c: ldr             x1, [x1, #0x8e8]
    // 0xb16b80: r0 = AllocateClosure()
    //     0xb16b80: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb16b84: LeaveFrame
    //     0xb16b84: mov             SP, fp
    //     0xb16b88: ldp             fp, lr, [SP], #0x10
    // 0xb16b8c: ret
    //     0xb16b8c: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb16b90, size: 0x78
    // 0xb16b90: EnterFrame
    //     0xb16b90: stp             fp, lr, [SP, #-0x10]!
    //     0xb16b94: mov             fp, SP
    // 0xb16b98: ldr             x0, [fp, #0x18]
    // 0xb16b9c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb16b9c: ldur            w1, [x0, #0x17]
    // 0xb16ba0: DecompressPointer r1
    //     0xb16ba0: add             x1, x1, HEAP, lsl #32
    // 0xb16ba4: CheckStackOverflow
    //     0xb16ba4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16ba8: cmp             SP, x16
    //     0xb16bac: b.ls            #0xb16bf0
    // 0xb16bb0: ldr             x2, [fp, #0x10]
    // 0xb16bb4: r0 = computeMinIntrinsicWidth()
    //     0xb16bb4: bl              #0xb16c08  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMinIntrinsicWidth
    // 0xb16bb8: r0 = inline_Allocate_Double()
    //     0xb16bb8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb16bbc: add             x0, x0, #0x10
    //     0xb16bc0: cmp             x1, x0
    //     0xb16bc4: b.ls            #0xb16bf8
    //     0xb16bc8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb16bcc: sub             x0, x0, #0xf
    //     0xb16bd0: mov             x1, #0xe19c
    //     0xb16bd4: movk            x1, #3, lsl #16
    //     0xb16bd8: stur            x1, [x0, #-1]
    // 0xb16bdc: dmb             ishst
    // 0xb16be0: StoreField: r0->field_7 = d0
    //     0xb16be0: stur            d0, [x0, #7]
    // 0xb16be4: LeaveFrame
    //     0xb16be4: mov             SP, fp
    //     0xb16be8: ldp             fp, lr, [SP], #0x10
    // 0xb16bec: ret
    //     0xb16bec: ret             
    // 0xb16bf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16bf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16bf4: b               #0xb16bb0
    // 0xb16bf8: SaveReg d0
    //     0xb16bf8: str             q0, [SP, #-0x10]!
    // 0xb16bfc: r0 = AllocateDouble()
    //     0xb16bfc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16c00: RestoreReg d0
    //     0xb16c00: ldr             q0, [SP], #0x10
    // 0xb16c04: b               #0xb16be0
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb16c08, size: 0xc0
    // 0xb16c08: EnterFrame
    //     0xb16c08: stp             fp, lr, [SP, #-0x10]!
    //     0xb16c0c: mov             fp, SP
    // 0xb16c10: AllocStack(0x20)
    //     0xb16c10: sub             SP, SP, #0x20
    // 0xb16c14: SetupParameters(RenderConstraintsTransformBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb16c14: stur            x1, [fp, #-8]
    //     0xb16c18: stur            x2, [fp, #-0x10]
    // 0xb16c1c: CheckStackOverflow
    //     0xb16c1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb16c20: cmp             SP, x16
    //     0xb16c24: b.ls            #0xb16cac
    // 0xb16c28: r0 = BoxConstraints()
    //     0xb16c28: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb16c2c: StoreField: r0->field_7 = rZR
    //     0xb16c2c: stur            xzr, [x0, #7]
    // 0xb16c30: d0 = inf
    //     0xb16c30: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb16c34: StoreField: r0->field_f = d0
    //     0xb16c34: stur            d0, [x0, #0xf]
    // 0xb16c38: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb16c38: stur            xzr, [x0, #0x17]
    // 0xb16c3c: ldur            x1, [fp, #-0x10]
    // 0xb16c40: LoadField: d0 = r1->field_7
    //     0xb16c40: ldur            d0, [x1, #7]
    // 0xb16c44: StoreField: r0->field_1f = d0
    //     0xb16c44: stur            d0, [x0, #0x1f]
    // 0xb16c48: ldur            x1, [fp, #-8]
    // 0xb16c4c: LoadField: r2 = r1->field_63
    //     0xb16c4c: ldur            w2, [x1, #0x63]
    // 0xb16c50: DecompressPointer r2
    //     0xb16c50: add             x2, x2, HEAP, lsl #32
    // 0xb16c54: stp             x0, x2, [SP]
    // 0xb16c58: mov             x0, x2
    // 0xb16c5c: ClosureCall
    //     0xb16c5c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb16c60: ldur            x2, [x0, #0x1f]
    //     0xb16c64: blr             x2
    // 0xb16c68: LoadField: d0 = r0->field_1f
    //     0xb16c68: ldur            d0, [x0, #0x1f]
    // 0xb16c6c: r2 = inline_Allocate_Double()
    //     0xb16c6c: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb16c70: add             x2, x2, #0x10
    //     0xb16c74: cmp             x0, x2
    //     0xb16c78: b.ls            #0xb16cb4
    //     0xb16c7c: str             x2, [THR, #0x60]  ; THR::top
    //     0xb16c80: sub             x2, x2, #0xf
    //     0xb16c84: mov             x0, #0xe19c
    //     0xb16c88: movk            x0, #3, lsl #16
    //     0xb16c8c: stur            x0, [x2, #-1]
    // 0xb16c90: dmb             ishst
    // 0xb16c94: StoreField: r2->field_7 = d0
    //     0xb16c94: stur            d0, [x2, #7]
    // 0xb16c98: ldur            x1, [fp, #-8]
    // 0xb16c9c: r0 = computeMinIntrinsicWidth()
    //     0xb16c9c: bl              #0xb16174  ; [dart:mixin_deduplication] _MixinApplication10&RenderBox&RenderObjectWithChildMixin&RenderProxyBoxMixin::computeMinIntrinsicWidth
    // 0xb16ca0: LeaveFrame
    //     0xb16ca0: mov             SP, fp
    //     0xb16ca4: ldp             fp, lr, [SP], #0x10
    // 0xb16ca8: ret
    //     0xb16ca8: ret             
    // 0xb16cac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16cac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16cb0: b               #0xb16c28
    // 0xb16cb4: SaveReg d0
    //     0xb16cb4: str             q0, [SP, #-0x10]!
    // 0xb16cb8: r0 = AllocateDouble()
    //     0xb16cb8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb16cbc: mov             x2, x0
    // 0xb16cc0: RestoreReg d0
    //     0xb16cc0: ldr             q0, [SP], #0x10
    // 0xb16cc4: b               #0xb16c94
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb22f48, size: 0xc0
    // 0xb22f48: EnterFrame
    //     0xb22f48: stp             fp, lr, [SP, #-0x10]!
    //     0xb22f4c: mov             fp, SP
    // 0xb22f50: AllocStack(0x20)
    //     0xb22f50: sub             SP, SP, #0x20
    // 0xb22f54: SetupParameters(RenderConstraintsTransformBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb22f54: stur            x1, [fp, #-8]
    //     0xb22f58: stur            x2, [fp, #-0x10]
    // 0xb22f5c: CheckStackOverflow
    //     0xb22f5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb22f60: cmp             SP, x16
    //     0xb22f64: b.ls            #0xb22fec
    // 0xb22f68: r0 = BoxConstraints()
    //     0xb22f68: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb22f6c: StoreField: r0->field_7 = rZR
    //     0xb22f6c: stur            xzr, [x0, #7]
    // 0xb22f70: ldur            x1, [fp, #-0x10]
    // 0xb22f74: LoadField: d0 = r1->field_7
    //     0xb22f74: ldur            d0, [x1, #7]
    // 0xb22f78: StoreField: r0->field_f = d0
    //     0xb22f78: stur            d0, [x0, #0xf]
    // 0xb22f7c: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb22f7c: stur            xzr, [x0, #0x17]
    // 0xb22f80: d0 = inf
    //     0xb22f80: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb22f84: StoreField: r0->field_1f = d0
    //     0xb22f84: stur            d0, [x0, #0x1f]
    // 0xb22f88: ldur            x1, [fp, #-8]
    // 0xb22f8c: LoadField: r2 = r1->field_63
    //     0xb22f8c: ldur            w2, [x1, #0x63]
    // 0xb22f90: DecompressPointer r2
    //     0xb22f90: add             x2, x2, HEAP, lsl #32
    // 0xb22f94: stp             x0, x2, [SP]
    // 0xb22f98: mov             x0, x2
    // 0xb22f9c: ClosureCall
    //     0xb22f9c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb22fa0: ldur            x2, [x0, #0x1f]
    //     0xb22fa4: blr             x2
    // 0xb22fa8: LoadField: d0 = r0->field_f
    //     0xb22fa8: ldur            d0, [x0, #0xf]
    // 0xb22fac: r2 = inline_Allocate_Double()
    //     0xb22fac: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb22fb0: add             x2, x2, #0x10
    //     0xb22fb4: cmp             x0, x2
    //     0xb22fb8: b.ls            #0xb22ff4
    //     0xb22fbc: str             x2, [THR, #0x60]  ; THR::top
    //     0xb22fc0: sub             x2, x2, #0xf
    //     0xb22fc4: mov             x0, #0xe19c
    //     0xb22fc8: movk            x0, #3, lsl #16
    //     0xb22fcc: stur            x0, [x2, #-1]
    // 0xb22fd0: dmb             ishst
    // 0xb22fd4: StoreField: r2->field_7 = d0
    //     0xb22fd4: stur            d0, [x2, #7]
    // 0xb22fd8: ldur            x1, [fp, #-8]
    // 0xb22fdc: r0 = computeMinIntrinsicHeight()
    //     0xb22fdc: bl              #0xb23590  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMinIntrinsicHeight
    // 0xb22fe0: LeaveFrame
    //     0xb22fe0: mov             SP, fp
    //     0xb22fe4: ldp             fp, lr, [SP], #0x10
    // 0xb22fe8: ret
    //     0xb22fe8: ret             
    // 0xb22fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22fec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22ff0: b               #0xb22f68
    // 0xb22ff4: SaveReg d0
    //     0xb22ff4: str             q0, [SP, #-0x10]!
    // 0xb22ff8: r0 = AllocateDouble()
    //     0xb22ff8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb22ffc: mov             x2, x0
    // 0xb23000: RestoreReg d0
    //     0xb23000: ldr             q0, [SP], #0x10
    // 0xb23004: b               #0xb22fd4
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb23008, size: 0x78
    // 0xb23008: EnterFrame
    //     0xb23008: stp             fp, lr, [SP, #-0x10]!
    //     0xb2300c: mov             fp, SP
    // 0xb23010: ldr             x0, [fp, #0x18]
    // 0xb23014: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb23014: ldur            w1, [x0, #0x17]
    // 0xb23018: DecompressPointer r1
    //     0xb23018: add             x1, x1, HEAP, lsl #32
    // 0xb2301c: CheckStackOverflow
    //     0xb2301c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23020: cmp             SP, x16
    //     0xb23024: b.ls            #0xb23068
    // 0xb23028: ldr             x2, [fp, #0x10]
    // 0xb2302c: r0 = computeMinIntrinsicHeight()
    //     0xb2302c: bl              #0xb22f48  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMinIntrinsicHeight
    // 0xb23030: r0 = inline_Allocate_Double()
    //     0xb23030: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23034: add             x0, x0, #0x10
    //     0xb23038: cmp             x1, x0
    //     0xb2303c: b.ls            #0xb23070
    //     0xb23040: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23044: sub             x0, x0, #0xf
    //     0xb23048: mov             x1, #0xe19c
    //     0xb2304c: movk            x1, #3, lsl #16
    //     0xb23050: stur            x1, [x0, #-1]
    // 0xb23054: dmb             ishst
    // 0xb23058: StoreField: r0->field_7 = d0
    //     0xb23058: stur            d0, [x0, #7]
    // 0xb2305c: LeaveFrame
    //     0xb2305c: mov             SP, fp
    //     0xb23060: ldp             fp, lr, [SP], #0x10
    // 0xb23064: ret
    //     0xb23064: ret             
    // 0xb23068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23068: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2306c: b               #0xb23028
    // 0xb23070: SaveReg d0
    //     0xb23070: str             q0, [SP, #-0x10]!
    // 0xb23074: r0 = AllocateDouble()
    //     0xb23074: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb23078: RestoreReg d0
    //     0xb23078: ldr             q0, [SP], #0x10
    // 0xb2307c: b               #0xb23058
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb29b74, size: 0xc0
    // 0xb29b74: EnterFrame
    //     0xb29b74: stp             fp, lr, [SP, #-0x10]!
    //     0xb29b78: mov             fp, SP
    // 0xb29b7c: AllocStack(0x20)
    //     0xb29b7c: sub             SP, SP, #0x20
    // 0xb29b80: SetupParameters(RenderConstraintsTransformBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb29b80: stur            x1, [fp, #-8]
    //     0xb29b84: stur            x2, [fp, #-0x10]
    // 0xb29b88: CheckStackOverflow
    //     0xb29b88: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29b8c: cmp             SP, x16
    //     0xb29b90: b.ls            #0xb29c18
    // 0xb29b94: r0 = BoxConstraints()
    //     0xb29b94: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb29b98: StoreField: r0->field_7 = rZR
    //     0xb29b98: stur            xzr, [x0, #7]
    // 0xb29b9c: ldur            x1, [fp, #-0x10]
    // 0xb29ba0: LoadField: d0 = r1->field_7
    //     0xb29ba0: ldur            d0, [x1, #7]
    // 0xb29ba4: StoreField: r0->field_f = d0
    //     0xb29ba4: stur            d0, [x0, #0xf]
    // 0xb29ba8: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb29ba8: stur            xzr, [x0, #0x17]
    // 0xb29bac: d0 = inf
    //     0xb29bac: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb29bb0: StoreField: r0->field_1f = d0
    //     0xb29bb0: stur            d0, [x0, #0x1f]
    // 0xb29bb4: ldur            x1, [fp, #-8]
    // 0xb29bb8: LoadField: r2 = r1->field_63
    //     0xb29bb8: ldur            w2, [x1, #0x63]
    // 0xb29bbc: DecompressPointer r2
    //     0xb29bbc: add             x2, x2, HEAP, lsl #32
    // 0xb29bc0: stp             x0, x2, [SP]
    // 0xb29bc4: mov             x0, x2
    // 0xb29bc8: ClosureCall
    //     0xb29bc8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb29bcc: ldur            x2, [x0, #0x1f]
    //     0xb29bd0: blr             x2
    // 0xb29bd4: LoadField: d0 = r0->field_f
    //     0xb29bd4: ldur            d0, [x0, #0xf]
    // 0xb29bd8: r2 = inline_Allocate_Double()
    //     0xb29bd8: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb29bdc: add             x2, x2, #0x10
    //     0xb29be0: cmp             x0, x2
    //     0xb29be4: b.ls            #0xb29c20
    //     0xb29be8: str             x2, [THR, #0x60]  ; THR::top
    //     0xb29bec: sub             x2, x2, #0xf
    //     0xb29bf0: mov             x0, #0xe19c
    //     0xb29bf4: movk            x0, #3, lsl #16
    //     0xb29bf8: stur            x0, [x2, #-1]
    // 0xb29bfc: dmb             ishst
    // 0xb29c00: StoreField: r2->field_7 = d0
    //     0xb29c00: stur            d0, [x2, #7]
    // 0xb29c04: ldur            x1, [fp, #-8]
    // 0xb29c08: r0 = computeMaxIntrinsicHeight()
    //     0xb29c08: bl              #0xb2a3e0  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicHeight
    // 0xb29c0c: LeaveFrame
    //     0xb29c0c: mov             SP, fp
    //     0xb29c10: ldp             fp, lr, [SP], #0x10
    // 0xb29c14: ret
    //     0xb29c14: ret             
    // 0xb29c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29c18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29c1c: b               #0xb29b94
    // 0xb29c20: SaveReg d0
    //     0xb29c20: str             q0, [SP, #-0x10]!
    // 0xb29c24: r0 = AllocateDouble()
    //     0xb29c24: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29c28: mov             x2, x0
    // 0xb29c2c: RestoreReg d0
    //     0xb29c2c: ldr             q0, [SP], #0x10
    // 0xb29c30: b               #0xb29c00
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb29c34, size: 0x78
    // 0xb29c34: EnterFrame
    //     0xb29c34: stp             fp, lr, [SP, #-0x10]!
    //     0xb29c38: mov             fp, SP
    // 0xb29c3c: ldr             x0, [fp, #0x18]
    // 0xb29c40: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb29c40: ldur            w1, [x0, #0x17]
    // 0xb29c44: DecompressPointer r1
    //     0xb29c44: add             x1, x1, HEAP, lsl #32
    // 0xb29c48: CheckStackOverflow
    //     0xb29c48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb29c4c: cmp             SP, x16
    //     0xb29c50: b.ls            #0xb29c94
    // 0xb29c54: ldr             x2, [fp, #0x10]
    // 0xb29c58: r0 = computeMaxIntrinsicHeight()
    //     0xb29c58: bl              #0xb29b74  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMaxIntrinsicHeight
    // 0xb29c5c: r0 = inline_Allocate_Double()
    //     0xb29c5c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb29c60: add             x0, x0, #0x10
    //     0xb29c64: cmp             x1, x0
    //     0xb29c68: b.ls            #0xb29c9c
    //     0xb29c6c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb29c70: sub             x0, x0, #0xf
    //     0xb29c74: mov             x1, #0xe19c
    //     0xb29c78: movk            x1, #3, lsl #16
    //     0xb29c7c: stur            x1, [x0, #-1]
    // 0xb29c80: dmb             ishst
    // 0xb29c84: StoreField: r0->field_7 = d0
    //     0xb29c84: stur            d0, [x0, #7]
    // 0xb29c88: LeaveFrame
    //     0xb29c88: mov             SP, fp
    //     0xb29c8c: ldp             fp, lr, [SP], #0x10
    // 0xb29c90: ret
    //     0xb29c90: ret             
    // 0xb29c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29c94: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29c98: b               #0xb29c54
    // 0xb29c9c: SaveReg d0
    //     0xb29c9c: str             q0, [SP, #-0x10]!
    // 0xb29ca0: r0 = AllocateDouble()
    //     0xb29ca0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb29ca4: RestoreReg d0
    //     0xb29ca4: ldr             q0, [SP], #0x10
    // 0xb29ca8: b               #0xb29c84
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2cfa4, size: 0xc0
    // 0xb2cfa4: EnterFrame
    //     0xb2cfa4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2cfa8: mov             fp, SP
    // 0xb2cfac: AllocStack(0x20)
    //     0xb2cfac: sub             SP, SP, #0x20
    // 0xb2cfb0: SetupParameters(RenderConstraintsTransformBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2cfb0: stur            x1, [fp, #-8]
    //     0xb2cfb4: stur            x2, [fp, #-0x10]
    // 0xb2cfb8: CheckStackOverflow
    //     0xb2cfb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2cfbc: cmp             SP, x16
    //     0xb2cfc0: b.ls            #0xb2d048
    // 0xb2cfc4: r0 = BoxConstraints()
    //     0xb2cfc4: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2cfc8: StoreField: r0->field_7 = rZR
    //     0xb2cfc8: stur            xzr, [x0, #7]
    // 0xb2cfcc: d0 = inf
    //     0xb2cfcc: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2cfd0: StoreField: r0->field_f = d0
    //     0xb2cfd0: stur            d0, [x0, #0xf]
    // 0xb2cfd4: ArrayStore: r0[0] = rZR  ; List_8
    //     0xb2cfd4: stur            xzr, [x0, #0x17]
    // 0xb2cfd8: ldur            x1, [fp, #-0x10]
    // 0xb2cfdc: LoadField: d0 = r1->field_7
    //     0xb2cfdc: ldur            d0, [x1, #7]
    // 0xb2cfe0: StoreField: r0->field_1f = d0
    //     0xb2cfe0: stur            d0, [x0, #0x1f]
    // 0xb2cfe4: ldur            x1, [fp, #-8]
    // 0xb2cfe8: LoadField: r2 = r1->field_63
    //     0xb2cfe8: ldur            w2, [x1, #0x63]
    // 0xb2cfec: DecompressPointer r2
    //     0xb2cfec: add             x2, x2, HEAP, lsl #32
    // 0xb2cff0: stp             x0, x2, [SP]
    // 0xb2cff4: mov             x0, x2
    // 0xb2cff8: ClosureCall
    //     0xb2cff8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb2cffc: ldur            x2, [x0, #0x1f]
    //     0xb2d000: blr             x2
    // 0xb2d004: LoadField: d0 = r0->field_1f
    //     0xb2d004: ldur            d0, [x0, #0x1f]
    // 0xb2d008: r2 = inline_Allocate_Double()
    //     0xb2d008: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xb2d00c: add             x2, x2, #0x10
    //     0xb2d010: cmp             x0, x2
    //     0xb2d014: b.ls            #0xb2d050
    //     0xb2d018: str             x2, [THR, #0x60]  ; THR::top
    //     0xb2d01c: sub             x2, x2, #0xf
    //     0xb2d020: mov             x0, #0xe19c
    //     0xb2d024: movk            x0, #3, lsl #16
    //     0xb2d028: stur            x0, [x2, #-1]
    // 0xb2d02c: dmb             ishst
    // 0xb2d030: StoreField: r2->field_7 = d0
    //     0xb2d030: stur            d0, [x2, #7]
    // 0xb2d034: ldur            x1, [fp, #-8]
    // 0xb2d038: r0 = computeMaxIntrinsicWidth()
    //     0xb2d038: bl              #0xb2d828  ; [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::computeMaxIntrinsicWidth
    // 0xb2d03c: LeaveFrame
    //     0xb2d03c: mov             SP, fp
    //     0xb2d040: ldp             fp, lr, [SP], #0x10
    // 0xb2d044: ret
    //     0xb2d044: ret             
    // 0xb2d048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d048: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d04c: b               #0xb2cfc4
    // 0xb2d050: SaveReg d0
    //     0xb2d050: str             q0, [SP, #-0x10]!
    // 0xb2d054: r0 = AllocateDouble()
    //     0xb2d054: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d058: mov             x2, x0
    // 0xb2d05c: RestoreReg d0
    //     0xb2d05c: ldr             q0, [SP], #0x10
    // 0xb2d060: b               #0xb2d030
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2d064, size: 0x78
    // 0xb2d064: EnterFrame
    //     0xb2d064: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d068: mov             fp, SP
    // 0xb2d06c: ldr             x0, [fp, #0x18]
    // 0xb2d070: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2d070: ldur            w1, [x0, #0x17]
    // 0xb2d074: DecompressPointer r1
    //     0xb2d074: add             x1, x1, HEAP, lsl #32
    // 0xb2d078: CheckStackOverflow
    //     0xb2d078: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d07c: cmp             SP, x16
    //     0xb2d080: b.ls            #0xb2d0c4
    // 0xb2d084: ldr             x2, [fp, #0x10]
    // 0xb2d088: r0 = computeMaxIntrinsicWidth()
    //     0xb2d088: bl              #0xb2cfa4  ; [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMaxIntrinsicWidth
    // 0xb2d08c: r0 = inline_Allocate_Double()
    //     0xb2d08c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2d090: add             x0, x0, #0x10
    //     0xb2d094: cmp             x1, x0
    //     0xb2d098: b.ls            #0xb2d0cc
    //     0xb2d09c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2d0a0: sub             x0, x0, #0xf
    //     0xb2d0a4: mov             x1, #0xe19c
    //     0xb2d0a8: movk            x1, #3, lsl #16
    //     0xb2d0ac: stur            x1, [x0, #-1]
    // 0xb2d0b0: dmb             ishst
    // 0xb2d0b4: StoreField: r0->field_7 = d0
    //     0xb2d0b4: stur            d0, [x0, #7]
    // 0xb2d0b8: LeaveFrame
    //     0xb2d0b8: mov             SP, fp
    //     0xb2d0bc: ldp             fp, lr, [SP], #0x10
    // 0xb2d0c0: ret
    //     0xb2d0c0: ret             
    // 0xb2d0c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d0c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d0c8: b               #0xb2d084
    // 0xb2d0cc: SaveReg d0
    //     0xb2d0cc: str             q0, [SP, #-0x10]!
    // 0xb2d0d0: r0 = AllocateDouble()
    //     0xb2d0d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d0d4: RestoreReg d0
    //     0xb2d0d4: ldr             q0, [SP], #0x10
    // 0xb2d0d8: b               #0xb2d0b4
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4cebc, size: 0x9c
    // 0xb4cebc: EnterFrame
    //     0xb4cebc: stp             fp, lr, [SP, #-0x10]!
    //     0xb4cec0: mov             fp, SP
    // 0xb4cec4: AllocStack(0x20)
    //     0xb4cec4: sub             SP, SP, #0x20
    // 0xb4cec8: SetupParameters(RenderConstraintsTransformBox this /* r1 => r0 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb4cec8: mov             x0, x1
    //     0xb4cecc: mov             x1, x2
    //     0xb4ced0: stur            x2, [fp, #-0x10]
    // 0xb4ced4: CheckStackOverflow
    //     0xb4ced4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4ced8: cmp             SP, x16
    //     0xb4cedc: b.ls            #0xb4cf50
    // 0xb4cee0: LoadField: r2 = r0->field_4f
    //     0xb4cee0: ldur            w2, [x0, #0x4f]
    // 0xb4cee4: DecompressPointer r2
    //     0xb4cee4: add             x2, x2, HEAP, lsl #32
    // 0xb4cee8: stur            x2, [fp, #-8]
    // 0xb4ceec: cmp             w2, NULL
    // 0xb4cef0: b.ne            #0xb4cefc
    // 0xb4cef4: r2 = Null
    //     0xb4cef4: mov             x2, NULL
    // 0xb4cef8: b               #0xb4cf28
    // 0xb4cefc: LoadField: r3 = r0->field_63
    //     0xb4cefc: ldur            w3, [x0, #0x63]
    // 0xb4cf00: DecompressPointer r3
    //     0xb4cf00: add             x3, x3, HEAP, lsl #32
    // 0xb4cf04: stp             x1, x3, [SP]
    // 0xb4cf08: mov             x0, x3
    // 0xb4cf0c: ClosureCall
    //     0xb4cf0c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb4cf10: ldur            x2, [x0, #0x1f]
    //     0xb4cf14: blr             x2
    // 0xb4cf18: ldur            x1, [fp, #-8]
    // 0xb4cf1c: mov             x2, x0
    // 0xb4cf20: r0 = getDryLayout()
    //     0xb4cf20: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4cf24: mov             x2, x0
    // 0xb4cf28: cmp             w2, NULL
    // 0xb4cf2c: b.ne            #0xb4cf3c
    // 0xb4cf30: ldur            x1, [fp, #-0x10]
    // 0xb4cf34: r0 = smallest()
    //     0xb4cf34: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb4cf38: b               #0xb4cf44
    // 0xb4cf3c: ldur            x1, [fp, #-0x10]
    // 0xb4cf40: r0 = constrain()
    //     0xb4cf40: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4cf44: LeaveFrame
    //     0xb4cf44: mov             SP, fp
    //     0xb4cf48: ldp             fp, lr, [SP], #0x10
    // 0xb4cf4c: ret
    //     0xb4cf4c: ret             
    // 0xb4cf50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4cf50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4cf54: b               #0xb4cee0
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58270, size: 0x24
    // 0xb58270: EnterFrame
    //     0xb58270: stp             fp, lr, [SP, #-0x10]!
    //     0xb58274: mov             fp, SP
    // 0xb58278: ldr             x2, [fp, #0x10]
    // 0xb5827c: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb5827c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa28e0] AnonymousClosure: (0xb2d064), in [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMaxIntrinsicWidth (0xb2cfa4)
    //     0xb58280: ldr             x1, [x1, #0x8e0]
    // 0xb58284: r0 = AllocateClosure()
    //     0xb58284: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58288: LeaveFrame
    //     0xb58288: mov             SP, fp
    //     0xb5828c: ldp             fp, lr, [SP], #0x10
    // 0xb58290: ret
    //     0xb58290: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e3f8, size: 0x24
    // 0xb5e3f8: EnterFrame
    //     0xb5e3f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e3fc: mov             fp, SP
    // 0xb5e400: ldr             x2, [fp, #0x10]
    // 0xb5e404: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e404: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa28f0] AnonymousClosure: (0xb29c34), in [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMaxIntrinsicHeight (0xb29b74)
    //     0xb5e408: ldr             x1, [x1, #0x8f0]
    // 0xb5e40c: r0 = AllocateClosure()
    //     0xb5e40c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e410: LeaveFrame
    //     0xb5e410: mov             SP, fp
    //     0xb5e414: ldp             fp, lr, [SP], #0x10
    // 0xb5e418: ret
    //     0xb5e418: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb5fc00, size: 0x17c
    // 0xb5fc00: EnterFrame
    //     0xb5fc00: stp             fp, lr, [SP, #-0x10]!
    //     0xb5fc04: mov             fp, SP
    // 0xb5fc08: AllocStack(0x38)
    //     0xb5fc08: sub             SP, SP, #0x38
    // 0xb5fc0c: SetupParameters(RenderConstraintsTransformBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb5fc0c: mov             x5, x1
    //     0xb5fc10: mov             x4, x2
    //     0xb5fc14: stur            x1, [fp, #-8]
    //     0xb5fc18: stur            x2, [fp, #-0x10]
    //     0xb5fc1c: stur            x3, [fp, #-0x18]
    // 0xb5fc20: CheckStackOverflow
    //     0xb5fc20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5fc24: cmp             SP, x16
    //     0xb5fc28: b.ls            #0xb5fd64
    // 0xb5fc2c: mov             x0, x4
    // 0xb5fc30: r2 = Null
    //     0xb5fc30: mov             x2, NULL
    // 0xb5fc34: r1 = Null
    //     0xb5fc34: mov             x1, NULL
    // 0xb5fc38: r4 = 60
    //     0xb5fc38: mov             x4, #0x3c
    // 0xb5fc3c: branchIfSmi(r0, 0xb5fc48)
    //     0xb5fc3c: tbz             w0, #0, #0xb5fc48
    // 0xb5fc40: r4 = LoadClassIdInstr(r0)
    //     0xb5fc40: ldur            x4, [x0, #-1]
    //     0xb5fc44: ubfx            x4, x4, #0xc, #0x14
    // 0xb5fc48: sub             x4, x4, #0xb46
    // 0xb5fc4c: cmp             x4, #1
    // 0xb5fc50: b.ls            #0xb5fc64
    // 0xb5fc54: r8 = BoxConstraints
    //     0xb5fc54: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5fc58: r3 = Null
    //     0xb5fc58: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2928] Null
    //     0xb5fc5c: ldr             x3, [x3, #0x928]
    // 0xb5fc60: r0 = BoxConstraints()
    //     0xb5fc60: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5fc64: ldur            x1, [fp, #-8]
    // 0xb5fc68: LoadField: r2 = r1->field_4f
    //     0xb5fc68: ldur            w2, [x1, #0x4f]
    // 0xb5fc6c: DecompressPointer r2
    //     0xb5fc6c: add             x2, x2, HEAP, lsl #32
    // 0xb5fc70: stur            x2, [fp, #-0x20]
    // 0xb5fc74: cmp             w2, NULL
    // 0xb5fc78: b.ne            #0xb5fc8c
    // 0xb5fc7c: r0 = Null
    //     0xb5fc7c: mov             x0, NULL
    // 0xb5fc80: LeaveFrame
    //     0xb5fc80: mov             SP, fp
    //     0xb5fc84: ldp             fp, lr, [SP], #0x10
    // 0xb5fc88: ret
    //     0xb5fc88: ret             
    // 0xb5fc8c: LoadField: r0 = r1->field_63
    //     0xb5fc8c: ldur            w0, [x1, #0x63]
    // 0xb5fc90: DecompressPointer r0
    //     0xb5fc90: add             x0, x0, HEAP, lsl #32
    // 0xb5fc94: ldur            x16, [fp, #-0x10]
    // 0xb5fc98: stp             x16, x0, [SP]
    // 0xb5fc9c: ClosureCall
    //     0xb5fc9c: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb5fca0: ldur            x2, [x0, #0x1f]
    //     0xb5fca4: blr             x2
    // 0xb5fca8: ldur            x1, [fp, #-0x20]
    // 0xb5fcac: mov             x2, x0
    // 0xb5fcb0: ldur            x3, [fp, #-0x18]
    // 0xb5fcb4: stur            x0, [fp, #-0x18]
    // 0xb5fcb8: r0 = getDryBaseline()
    //     0xb5fcb8: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb5fcbc: stur            x0, [fp, #-0x28]
    // 0xb5fcc0: cmp             w0, NULL
    // 0xb5fcc4: b.ne            #0xb5fcd8
    // 0xb5fcc8: r0 = Null
    //     0xb5fcc8: mov             x0, NULL
    // 0xb5fccc: LeaveFrame
    //     0xb5fccc: mov             SP, fp
    //     0xb5fcd0: ldp             fp, lr, [SP], #0x10
    // 0xb5fcd4: ret
    //     0xb5fcd4: ret             
    // 0xb5fcd8: ldur            x1, [fp, #-0x20]
    // 0xb5fcdc: ldur            x2, [fp, #-0x18]
    // 0xb5fce0: r0 = getDryLayout()
    //     0xb5fce0: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb5fce4: ldur            x1, [fp, #-0x10]
    // 0xb5fce8: mov             x2, x0
    // 0xb5fcec: stur            x0, [fp, #-0x10]
    // 0xb5fcf0: r0 = constrain()
    //     0xb5fcf0: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb5fcf4: ldur            x1, [fp, #-8]
    // 0xb5fcf8: stur            x0, [fp, #-8]
    // 0xb5fcfc: r0 = resolvedAlignment()
    //     0xb5fcfc: bl              #0xb5fd7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::resolvedAlignment
    // 0xb5fd00: ldur            x1, [fp, #-8]
    // 0xb5fd04: ldur            x2, [fp, #-0x10]
    // 0xb5fd08: stur            x0, [fp, #-8]
    // 0xb5fd0c: r0 = -()
    //     0xb5fd0c: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb5fd10: ldur            x1, [fp, #-8]
    // 0xb5fd14: mov             x2, x0
    // 0xb5fd18: r0 = alongOffset()
    //     0xb5fd18: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb5fd1c: LoadField: d0 = r0->field_f
    //     0xb5fd1c: ldur            d0, [x0, #0xf]
    // 0xb5fd20: ldur            x1, [fp, #-0x28]
    // 0xb5fd24: LoadField: d1 = r1->field_7
    //     0xb5fd24: ldur            d1, [x1, #7]
    // 0xb5fd28: fadd            d2, d1, d0
    // 0xb5fd2c: r0 = inline_Allocate_Double()
    //     0xb5fd2c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5fd30: add             x0, x0, #0x10
    //     0xb5fd34: cmp             x1, x0
    //     0xb5fd38: b.ls            #0xb5fd6c
    //     0xb5fd3c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5fd40: sub             x0, x0, #0xf
    //     0xb5fd44: mov             x1, #0xe19c
    //     0xb5fd48: movk            x1, #3, lsl #16
    //     0xb5fd4c: stur            x1, [x0, #-1]
    // 0xb5fd50: dmb             ishst
    // 0xb5fd54: StoreField: r0->field_7 = d2
    //     0xb5fd54: stur            d2, [x0, #7]
    // 0xb5fd58: LeaveFrame
    //     0xb5fd58: mov             SP, fp
    //     0xb5fd5c: ldp             fp, lr, [SP], #0x10
    // 0xb5fd60: ret
    //     0xb5fd60: ret             
    // 0xb5fd64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5fd64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5fd68: b               #0xb5fc2c
    // 0xb5fd6c: SaveReg d2
    //     0xb5fd6c: str             q2, [SP, #-0x10]!
    // 0xb5fd70: r0 = AllocateDouble()
    //     0xb5fd70: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5fd74: RestoreReg d2
    //     0xb5fd74: ldr             q2, [SP], #0x10
    // 0xb5fd78: b               #0xb5fd54
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbaa68, size: 0x2e8
    // 0xbbaa68: EnterFrame
    //     0xbbaa68: stp             fp, lr, [SP, #-0x10]!
    //     0xbbaa6c: mov             fp, SP
    // 0xbbaa70: AllocStack(0x38)
    //     0xbbaa70: sub             SP, SP, #0x38
    // 0xbbaa74: SetupParameters(RenderConstraintsTransformBox this /* r1 => r3, fp-0x10 */)
    //     0xbbaa74: mov             x3, x1
    //     0xbbaa78: stur            x1, [fp, #-0x10]
    // 0xbbaa7c: CheckStackOverflow
    //     0xbbaa7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbaa80: cmp             SP, x16
    //     0xbbaa84: b.ls            #0xbbad44
    // 0xbbaa88: LoadField: r4 = r3->field_27
    //     0xbbaa88: ldur            w4, [x3, #0x27]
    // 0xbbaa8c: DecompressPointer r4
    //     0xbbaa8c: add             x4, x4, HEAP, lsl #32
    // 0xbbaa90: stur            x4, [fp, #-8]
    // 0xbbaa94: cmp             w4, NULL
    // 0xbbaa98: b.eq            #0xbbad28
    // 0xbbaa9c: mov             x0, x4
    // 0xbbaaa0: r2 = Null
    //     0xbbaaa0: mov             x2, NULL
    // 0xbbaaa4: r1 = Null
    //     0xbbaaa4: mov             x1, NULL
    // 0xbbaaa8: r4 = LoadClassIdInstr(r0)
    //     0xbbaaa8: ldur            x4, [x0, #-1]
    //     0xbbaaac: ubfx            x4, x4, #0xc, #0x14
    // 0xbbaab0: sub             x4, x4, #0xb46
    // 0xbbaab4: cmp             x4, #1
    // 0xbbaab8: b.ls            #0xbbaacc
    // 0xbbaabc: r8 = BoxConstraints
    //     0xbbaabc: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbaac0: r3 = Null
    //     0xbbaac0: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2908] Null
    //     0xbbaac4: ldr             x3, [x3, #0x908]
    // 0xbbaac8: r0 = BoxConstraints()
    //     0xbbaac8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbaacc: ldur            x1, [fp, #-0x10]
    // 0xbbaad0: LoadField: r2 = r1->field_4f
    //     0xbbaad0: ldur            w2, [x1, #0x4f]
    // 0xbbaad4: DecompressPointer r2
    //     0xbbaad4: add             x2, x2, HEAP, lsl #32
    // 0xbbaad8: stur            x2, [fp, #-0x18]
    // 0xbbaadc: cmp             w2, NULL
    // 0xbbaae0: b.eq            #0xbbac6c
    // 0xbbaae4: LoadField: r0 = r1->field_63
    //     0xbbaae4: ldur            w0, [x1, #0x63]
    // 0xbbaae8: DecompressPointer r0
    //     0xbbaae8: add             x0, x0, HEAP, lsl #32
    // 0xbbaaec: ldur            x16, [fp, #-8]
    // 0xbbaaf0: stp             x16, x0, [SP]
    // 0xbbaaf4: ClosureCall
    //     0xbbaaf4: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbbaaf8: ldur            x2, [x0, #0x1f]
    //     0xbbaafc: blr             x2
    // 0xbbab00: mov             x1, x0
    // 0xbbab04: ldur            x3, [fp, #-0x10]
    // 0xbbab08: StoreField: r3->field_77 = r0
    //     0xbbab08: stur            w0, [x3, #0x77]
    //     0xbbab0c: ldurb           w16, [x3, #-1]
    //     0xbbab10: ldurb           w17, [x0, #-1]
    //     0xbbab14: and             x16, x17, x16, lsr #2
    //     0xbbab18: tst             x16, HEAP, lsr #32
    //     0xbbab1c: b.eq            #0xbbab24
    //     0xbbab20: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbab24: ldur            x4, [fp, #-0x18]
    // 0xbbab28: r0 = LoadClassIdInstr(r4)
    //     0xbbab28: ldur            x0, [x4, #-1]
    //     0xbbab2c: ubfx            x0, x0, #0xc, #0x14
    // 0xbbab30: r16 = true
    //     0xbbab30: add             x16, NULL, #0x20  ; true
    // 0xbbab34: str             x16, [SP]
    // 0xbbab38: mov             x2, x1
    // 0xbbab3c: mov             x1, x4
    // 0xbbab40: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbab40: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbab44: ldr             x4, [x4, #0xed0]
    // 0xbbab48: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbab48: mov             x17, #0xe6b9
    //     0xbbab4c: add             lr, x0, x17
    //     0xbbab50: ldr             lr, [x21, lr, lsl #3]
    //     0xbbab54: blr             lr
    // 0xbbab58: ldur            x1, [fp, #-0x18]
    // 0xbbab5c: r0 = size()
    //     0xbbab5c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbab60: ldur            x1, [fp, #-8]
    // 0xbbab64: mov             x2, x0
    // 0xbbab68: r0 = constrain()
    //     0xbbab68: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbab6c: ldur            x2, [fp, #-0x10]
    // 0xbbab70: StoreField: r2->field_4b = r0
    //     0xbbab70: stur            w0, [x2, #0x4b]
    //     0xbbab74: ldurb           w16, [x2, #-1]
    //     0xbbab78: ldurb           w17, [x0, #-1]
    //     0xbbab7c: and             x16, x17, x16, lsr #2
    //     0xbbab80: tst             x16, HEAP, lsr #32
    //     0xbbab84: b.eq            #0xbbab8c
    //     0xbbab88: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbab8c: mov             x1, x2
    // 0xbbab90: r0 = alignChild()
    //     0xbbab90: bl              #0xbbad50  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0xbbab94: ldur            x3, [fp, #-0x18]
    // 0xbbab98: LoadField: r4 = r3->field_7
    //     0xbbab98: ldur            w4, [x3, #7]
    // 0xbbab9c: DecompressPointer r4
    //     0xbbab9c: add             x4, x4, HEAP, lsl #32
    // 0xbbaba0: stur            x4, [fp, #-0x20]
    // 0xbbaba4: cmp             w4, NULL
    // 0xbbaba8: b.eq            #0xbbad4c
    // 0xbbabac: mov             x0, x4
    // 0xbbabb0: r2 = Null
    //     0xbbabb0: mov             x2, NULL
    // 0xbbabb4: r1 = Null
    //     0xbbabb4: mov             x1, NULL
    // 0xbbabb8: r4 = LoadClassIdInstr(r0)
    //     0xbbabb8: ldur            x4, [x0, #-1]
    //     0xbbabbc: ubfx            x4, x4, #0xc, #0x14
    // 0xbbabc0: r17 = -4190
    //     0xbbabc0: mov             x17, #-0x105e
    // 0xbbabc4: add             x4, x4, x17
    // 0xbbabc8: cmp             x4, #0x17
    // 0xbbabcc: b.ls            #0xbbabe4
    // 0xbbabd0: r8 = BoxParentData
    //     0xbbabd0: add             x8, PP, #0x15, lsl #12  ; [pp+0x155e8] Type: BoxParentData
    //     0xbbabd4: ldr             x8, [x8, #0x5e8]
    // 0xbbabd8: r3 = Null
    //     0xbbabd8: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2918] Null
    //     0xbbabdc: ldr             x3, [x3, #0x918]
    // 0xbbabe0: r0 = DefaultTypeTest()
    //     0xbbabe0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbbabe4: ldur            x1, [fp, #-0x10]
    // 0xbbabe8: r0 = size()
    //     0xbbabe8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbabec: mov             x2, x0
    // 0xbbabf0: r1 = Instance_Offset
    //     0xbbabf0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xbbabf4: r0 = &()
    //     0xbbabf4: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xbbabf8: ldur            x2, [fp, #-0x10]
    // 0xbbabfc: StoreField: r2->field_6b = r0
    //     0xbbabfc: stur            w0, [x2, #0x6b]
    //     0xbbac00: ldurb           w16, [x2, #-1]
    //     0xbbac04: ldurb           w17, [x0, #-1]
    //     0xbbac08: and             x16, x17, x16, lsr #2
    //     0xbbac0c: tst             x16, HEAP, lsr #32
    //     0xbbac10: b.eq            #0xbbac18
    //     0xbbac14: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbac18: ldur            x0, [fp, #-0x20]
    // 0xbbac1c: LoadField: r3 = r0->field_7
    //     0xbbac1c: ldur            w3, [x0, #7]
    // 0xbbac20: DecompressPointer r3
    //     0xbbac20: add             x3, x3, HEAP, lsl #32
    // 0xbbac24: ldur            x1, [fp, #-0x18]
    // 0xbbac28: stur            x3, [fp, #-0x28]
    // 0xbbac2c: r0 = size()
    //     0xbbac2c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbac30: ldur            x1, [fp, #-0x28]
    // 0xbbac34: mov             x2, x0
    // 0xbbac38: r0 = &()
    //     0xbbac38: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xbbac3c: mov             x1, x0
    // 0xbbac40: ldur            x2, [fp, #-0x10]
    // 0xbbac44: StoreField: r2->field_6f = r0
    //     0xbbac44: stur            w0, [x2, #0x6f]
    //     0xbbac48: ldurb           w16, [x2, #-1]
    //     0xbbac4c: ldurb           w17, [x0, #-1]
    //     0xbbac50: and             x16, x17, x16, lsr #2
    //     0xbbac54: tst             x16, HEAP, lsr #32
    //     0xbbac58: b.eq            #0xbbac60
    //     0xbbac5c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbac60: mov             x0, x1
    // 0xbbac64: mov             x1, x2
    // 0xbbac68: b               #0xbbaca8
    // 0xbbac6c: mov             x2, x1
    // 0xbbac70: ldur            x1, [fp, #-8]
    // 0xbbac74: r0 = smallest()
    //     0xbbac74: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbbac78: ldur            x1, [fp, #-0x10]
    // 0xbbac7c: StoreField: r1->field_4b = r0
    //     0xbbac7c: stur            w0, [x1, #0x4b]
    //     0xbbac80: ldurb           w16, [x1, #-1]
    //     0xbbac84: ldurb           w17, [x0, #-1]
    //     0xbbac88: and             x16, x17, x16, lsr #2
    //     0xbbac8c: tst             x16, HEAP, lsr #32
    //     0xbbac90: b.eq            #0xbbac98
    //     0xbbac94: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbac98: r0 = Instance_Rect
    //     0xbbac98: ldr             x0, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0xbbac9c: StoreField: r1->field_6b = r0
    //     0xbbac9c: stur            w0, [x1, #0x6b]
    // 0xbbaca0: StoreField: r1->field_6f = r0
    //     0xbbaca0: stur            w0, [x1, #0x6f]
    // 0xbbaca4: r0 = Instance_Rect
    //     0xbbaca4: ldr             x0, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0xbbaca8: d0 = 0.000000
    //     0xbbaca8: eor             v0.16b, v0.16b, v0.16b
    // 0xbbacac: LoadField: r2 = r1->field_6b
    //     0xbbacac: ldur            w2, [x1, #0x6b]
    // 0xbbacb0: DecompressPointer r2
    //     0xbbacb0: add             x2, x2, HEAP, lsl #32
    // 0xbbacb4: LoadField: d1 = r2->field_7
    //     0xbbacb4: ldur            d1, [x2, #7]
    // 0xbbacb8: LoadField: d2 = r0->field_7
    //     0xbbacb8: ldur            d2, [x0, #7]
    // 0xbbacbc: fsub            d3, d1, d2
    // 0xbbacc0: LoadField: d1 = r2->field_f
    //     0xbbacc0: ldur            d1, [x2, #0xf]
    // 0xbbacc4: LoadField: d2 = r0->field_f
    //     0xbbacc4: ldur            d2, [x0, #0xf]
    // 0xbbacc8: fsub            d4, d1, d2
    // 0xbbaccc: ArrayLoad: d1 = r0[0]  ; List_8
    //     0xbbaccc: ldur            d1, [x0, #0x17]
    // 0xbbacd0: ArrayLoad: d2 = r2[0]  ; List_8
    //     0xbbacd0: ldur            d2, [x2, #0x17]
    // 0xbbacd4: fsub            d5, d1, d2
    // 0xbbacd8: LoadField: d1 = r0->field_1f
    //     0xbbacd8: ldur            d1, [x0, #0x1f]
    // 0xbbacdc: LoadField: d2 = r2->field_1f
    //     0xbbacdc: ldur            d2, [x2, #0x1f]
    // 0xbbace0: fsub            d6, d1, d2
    // 0xbbace4: fcmp            d3, d0
    // 0xbbace8: b.gt            #0xbbacfc
    // 0xbbacec: fcmp            d4, d0
    // 0xbbacf0: b.gt            #0xbbacfc
    // 0xbbacf4: fcmp            d5, d0
    // 0xbbacf8: b.le            #0xbbad04
    // 0xbbacfc: r0 = true
    //     0xbbacfc: add             x0, NULL, #0x20  ; true
    // 0xbbad00: b               #0xbbad14
    // 0xbbad04: fcmp            d6, d0
    // 0xbbad08: r16 = true
    //     0xbbad08: add             x16, NULL, #0x20  ; true
    // 0xbbad0c: r17 = false
    //     0xbbad0c: add             x17, NULL, #0x30  ; false
    // 0xbbad10: csel            x0, x16, x17, gt
    // 0xbbad14: StoreField: r1->field_73 = r0
    //     0xbbad14: stur            w0, [x1, #0x73]
    // 0xbbad18: r0 = Null
    //     0xbbad18: mov             x0, NULL
    // 0xbbad1c: LeaveFrame
    //     0xbbad1c: mov             SP, fp
    //     0xbbad20: ldp             fp, lr, [SP], #0x10
    // 0xbbad24: ret
    //     0xbbad24: ret             
    // 0xbbad28: r0 = StateError()
    //     0xbbad28: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbad2c: mov             x1, x0
    // 0xbbad30: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbad30: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbad34: StoreField: r1->field_b = r0
    //     0xbbad34: stur            w0, [x1, #0xb]
    // 0xbbad38: mov             x0, x1
    // 0xbbad3c: r0 = Throw()
    //     0xbbad3c: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbad40: brk             #0
    // 0xbbad44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbad44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbad48: b               #0xbbaa88
    // 0xbbad4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbad4c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc02fe4, size: 0x50
    // 0xc02fe4: EnterFrame
    //     0xc02fe4: stp             fp, lr, [SP, #-0x10]!
    //     0xc02fe8: mov             fp, SP
    // 0xc02fec: AllocStack(0x8)
    //     0xc02fec: sub             SP, SP, #8
    // 0xc02ff0: SetupParameters(RenderConstraintsTransformBox this /* r1 => r0, fp-0x8 */)
    //     0xc02ff0: mov             x0, x1
    //     0xc02ff4: stur            x1, [fp, #-8]
    // 0xc02ff8: CheckStackOverflow
    //     0xc02ff8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc02ffc: cmp             SP, x16
    //     0xc03000: b.ls            #0xc0302c
    // 0xc03004: LoadField: r1 = r0->field_7b
    //     0xc03004: ldur            w1, [x0, #0x7b]
    // 0xc03008: DecompressPointer r1
    //     0xc03008: add             x1, x1, HEAP, lsl #32
    // 0xc0300c: r2 = Null
    //     0xc0300c: mov             x2, NULL
    // 0xc03010: r0 = layer=()
    //     0xc03010: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc03014: ldur            x1, [fp, #-8]
    // 0xc03018: r0 = dispose()
    //     0xc03018: bl              #0xc03034  ; [dart:mixin_deduplication] _MixinApplication16&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&DebugOverflowIndicatorMixin::dispose
    // 0xc0301c: r0 = Null
    //     0xc0301c: mov             x0, NULL
    // 0xc03020: LeaveFrame
    //     0xc03020: mov             SP, fp
    //     0xc03024: ldp             fp, lr, [SP], #0x10
    // 0xc03028: ret
    //     0xc03028: ret             
    // 0xc0302c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0302c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc03030: b               #0xc03004
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1fb48, size: 0x128
    // 0xc1fb48: EnterFrame
    //     0xc1fb48: stp             fp, lr, [SP, #-0x10]!
    //     0xc1fb4c: mov             fp, SP
    // 0xc1fb50: AllocStack(0x48)
    //     0xc1fb50: sub             SP, SP, #0x48
    // 0xc1fb54: SetupParameters(RenderConstraintsTransformBox this /* r1 => r0, fp-0x18 */, dynamic _ /* r2 => r2, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0xc1fb54: mov             x0, x1
    //     0xc1fb58: stur            x1, [fp, #-0x18]
    //     0xc1fb5c: stur            x2, [fp, #-0x20]
    //     0xc1fb60: stur            x3, [fp, #-0x28]
    // 0xc1fb64: CheckStackOverflow
    //     0xc1fb64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1fb68: cmp             SP, x16
    //     0xc1fb6c: b.ls            #0xc1fc60
    // 0xc1fb70: LoadField: r1 = r0->field_4f
    //     0xc1fb70: ldur            w1, [x0, #0x4f]
    // 0xc1fb74: DecompressPointer r1
    //     0xc1fb74: add             x1, x1, HEAP, lsl #32
    // 0xc1fb78: cmp             w1, NULL
    // 0xc1fb7c: b.ne            #0xc1fb90
    // 0xc1fb80: r0 = Null
    //     0xc1fb80: mov             x0, NULL
    // 0xc1fb84: LeaveFrame
    //     0xc1fb84: mov             SP, fp
    //     0xc1fb88: ldp             fp, lr, [SP], #0x10
    // 0xc1fb8c: ret
    //     0xc1fb8c: ret             
    // 0xc1fb90: LoadField: r1 = r0->field_73
    //     0xc1fb90: ldur            w1, [x0, #0x73]
    // 0xc1fb94: DecompressPointer r1
    //     0xc1fb94: add             x1, x1, HEAP, lsl #32
    // 0xc1fb98: tbz             w1, #4, #0xc1fbb4
    // 0xc1fb9c: mov             x1, x0
    // 0xc1fba0: r0 = paint()
    //     0xc1fba0: bl              #0xc20b90  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint
    // 0xc1fba4: r0 = Null
    //     0xc1fba4: mov             x0, NULL
    // 0xc1fba8: LeaveFrame
    //     0xc1fba8: mov             SP, fp
    //     0xc1fbac: ldp             fp, lr, [SP], #0x10
    // 0xc1fbb0: ret
    //     0xc1fbb0: ret             
    // 0xc1fbb4: LoadField: r4 = r0->field_7b
    //     0xc1fbb4: ldur            w4, [x0, #0x7b]
    // 0xc1fbb8: DecompressPointer r4
    //     0xc1fbb8: add             x4, x4, HEAP, lsl #32
    // 0xc1fbbc: stur            x4, [fp, #-0x10]
    // 0xc1fbc0: LoadField: r5 = r0->field_37
    //     0xc1fbc0: ldur            w5, [x0, #0x37]
    // 0xc1fbc4: DecompressPointer r5
    //     0xc1fbc4: add             x5, x5, HEAP, lsl #32
    // 0xc1fbc8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1fbcc: cmp             w5, w16
    // 0xc1fbd0: b.eq            #0xc1fc68
    // 0xc1fbd4: mov             x1, x0
    // 0xc1fbd8: stur            x5, [fp, #-8]
    // 0xc1fbdc: r0 = size()
    //     0xc1fbdc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1fbe0: mov             x2, x0
    // 0xc1fbe4: r1 = Instance_Offset
    //     0xc1fbe4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1fbe8: r0 = &()
    //     0xc1fbe8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc1fbec: mov             x3, x0
    // 0xc1fbf0: ldur            x0, [fp, #-0x10]
    // 0xc1fbf4: stur            x3, [fp, #-0x38]
    // 0xc1fbf8: LoadField: r4 = r0->field_b
    //     0xc1fbf8: ldur            w4, [x0, #0xb]
    // 0xc1fbfc: DecompressPointer r4
    //     0xc1fbfc: add             x4, x4, HEAP, lsl #32
    // 0xc1fc00: ldur            x2, [fp, #-0x18]
    // 0xc1fc04: stur            x4, [fp, #-0x30]
    // 0xc1fc08: r1 = Function 'paint':.
    //     0xc1fc08: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2900] AnonymousClosure: (0xc1fc70), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint (0xc20b90)
    //     0xc1fc0c: ldr             x1, [x1, #0x900]
    // 0xc1fc10: r0 = AllocateClosure()
    //     0xc1fc10: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1fc14: r16 = Instance_Clip
    //     0xc1fc14: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc1fc18: ldr             x16, [x16, #0x840]
    // 0xc1fc1c: ldur            lr, [fp, #-0x30]
    // 0xc1fc20: stp             lr, x16, [SP]
    // 0xc1fc24: ldur            x1, [fp, #-0x20]
    // 0xc1fc28: ldur            x2, [fp, #-8]
    // 0xc1fc2c: ldur            x3, [fp, #-0x28]
    // 0xc1fc30: ldur            x5, [fp, #-0x38]
    // 0xc1fc34: mov             x6, x0
    // 0xc1fc38: r4 = const [0, 0x7, 0x2, 0x5, clipBehavior, 0x5, oldLayer, 0x6, null]
    //     0xc1fc38: add             x4, PP, #0x90, lsl #12  ; [pp+0x90688] List(9) [0, 0x7, 0x2, 0x5, "clipBehavior", 0x5, "oldLayer", 0x6, Null]
    //     0xc1fc3c: ldr             x4, [x4, #0x688]
    // 0xc1fc40: r0 = pushClipRect()
    //     0xc1fc40: bl              #0xc19194  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0xc1fc44: ldur            x1, [fp, #-0x10]
    // 0xc1fc48: mov             x2, x0
    // 0xc1fc4c: r0 = layer=()
    //     0xc1fc4c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1fc50: r0 = Null
    //     0xc1fc50: mov             x0, NULL
    // 0xc1fc54: LeaveFrame
    //     0xc1fc54: mov             SP, fp
    //     0xc1fc58: ldp             fp, lr, [SP], #0x10
    // 0xc1fc5c: ret
    //     0xc1fc5c: ret             
    // 0xc1fc60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1fc60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1fc64: b               #0xc1fb70
    // 0xc1fc68: r9 = _needsCompositing
    //     0xc1fc68: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1fc6c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1fc6c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ constraintsTransform=(/* No info */) {
    // ** addr: 0xcf8304, size: 0x148
    // 0xcf8304: EnterFrame
    //     0xcf8304: stp             fp, lr, [SP, #-0x10]!
    //     0xcf8308: mov             fp, SP
    // 0xcf830c: AllocStack(0x30)
    //     0xcf830c: sub             SP, SP, #0x30
    // 0xcf8310: SetupParameters(RenderConstraintsTransformBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf8310: mov             x0, x2
    //     0xcf8314: stur            x1, [fp, #-8]
    //     0xcf8318: stur            x2, [fp, #-0x10]
    // 0xcf831c: CheckStackOverflow
    //     0xcf831c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf8320: cmp             SP, x16
    //     0xcf8324: b.ls            #0xcf8444
    // 0xcf8328: LoadField: r2 = r1->field_63
    //     0xcf8328: ldur            w2, [x1, #0x63]
    // 0xcf832c: DecompressPointer r2
    //     0xcf832c: add             x2, x2, HEAP, lsl #32
    // 0xcf8330: stp             x0, x2, [SP]
    // 0xcf8334: r0 = ==()
    //     0xcf8334: bl              #0x12b7e74  ; [dart:core] _Closure::==
    // 0xcf8338: tbnz            w0, #4, #0xcf834c
    // 0xcf833c: r0 = Null
    //     0xcf833c: mov             x0, NULL
    // 0xcf8340: LeaveFrame
    //     0xcf8340: mov             SP, fp
    //     0xcf8344: ldp             fp, lr, [SP], #0x10
    // 0xcf8348: ret
    //     0xcf8348: ret             
    // 0xcf834c: ldur            x3, [fp, #-8]
    // 0xcf8350: ldur            x0, [fp, #-0x10]
    // 0xcf8354: StoreField: r3->field_63 = r0
    //     0xcf8354: stur            w0, [x3, #0x63]
    //     0xcf8358: ldurb           w16, [x3, #-1]
    //     0xcf835c: ldurb           w17, [x0, #-1]
    //     0xcf8360: and             x16, x17, x16, lsr #2
    //     0xcf8364: tst             x16, HEAP, lsr #32
    //     0xcf8368: b.eq            #0xcf8370
    //     0xcf836c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf8370: LoadField: r4 = r3->field_77
    //     0xcf8370: ldur            w4, [x3, #0x77]
    // 0xcf8374: DecompressPointer r4
    //     0xcf8374: add             x4, x4, HEAP, lsl #32
    // 0xcf8378: stur            x4, [fp, #-0x20]
    // 0xcf837c: cmp             w4, NULL
    // 0xcf8380: b.eq            #0xcf8410
    // 0xcf8384: LoadField: r5 = r3->field_27
    //     0xcf8384: ldur            w5, [x3, #0x27]
    // 0xcf8388: DecompressPointer r5
    //     0xcf8388: add             x5, x5, HEAP, lsl #32
    // 0xcf838c: stur            x5, [fp, #-0x18]
    // 0xcf8390: cmp             w5, NULL
    // 0xcf8394: b.eq            #0xcf8428
    // 0xcf8398: mov             x0, x5
    // 0xcf839c: r2 = Null
    //     0xcf839c: mov             x2, NULL
    // 0xcf83a0: r1 = Null
    //     0xcf83a0: mov             x1, NULL
    // 0xcf83a4: r4 = LoadClassIdInstr(r0)
    //     0xcf83a4: ldur            x4, [x0, #-1]
    //     0xcf83a8: ubfx            x4, x4, #0xc, #0x14
    // 0xcf83ac: sub             x4, x4, #0xb46
    // 0xcf83b0: cmp             x4, #1
    // 0xcf83b4: b.ls            #0xcf83c8
    // 0xcf83b8: r8 = BoxConstraints
    //     0xcf83b8: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xcf83bc: r3 = Null
    //     0xcf83bc: add             x3, PP, #0x99, lsl #12  ; [pp+0x99e58] Null
    //     0xcf83c0: ldr             x3, [x3, #0xe58]
    // 0xcf83c4: r0 = BoxConstraints()
    //     0xcf83c4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xcf83c8: ldur            x16, [fp, #-0x10]
    // 0xcf83cc: ldur            lr, [fp, #-0x18]
    // 0xcf83d0: stp             lr, x16, [SP]
    // 0xcf83d4: ldur            x0, [fp, #-0x10]
    // 0xcf83d8: ClosureCall
    //     0xcf83d8: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcf83dc: ldur            x2, [x0, #0x1f]
    //     0xcf83e0: blr             x2
    // 0xcf83e4: mov             x1, x0
    // 0xcf83e8: ldur            x0, [fp, #-0x20]
    // 0xcf83ec: r2 = LoadClassIdInstr(r0)
    //     0xcf83ec: ldur            x2, [x0, #-1]
    //     0xcf83f0: ubfx            x2, x2, #0xc, #0x14
    // 0xcf83f4: stp             x1, x0, [SP]
    // 0xcf83f8: mov             x0, x2
    // 0xcf83fc: mov             lr, x0
    // 0xcf8400: ldr             lr, [x21, lr, lsl #3]
    // 0xcf8404: blr             lr
    // 0xcf8408: eor             x1, x0, #0x10
    // 0xcf840c: tbnz            w1, #4, #0xcf8418
    // 0xcf8410: ldur            x1, [fp, #-8]
    // 0xcf8414: r0 = markNeedsLayout()
    //     0xcf8414: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf8418: r0 = Null
    //     0xcf8418: mov             x0, NULL
    // 0xcf841c: LeaveFrame
    //     0xcf841c: mov             SP, fp
    //     0xcf8420: ldp             fp, lr, [SP], #0x10
    // 0xcf8424: ret
    //     0xcf8424: ret             
    // 0xcf8428: r0 = StateError()
    //     0xcf8428: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xcf842c: mov             x1, x0
    // 0xcf8430: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xcf8430: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xcf8434: StoreField: r1->field_b = r0
    //     0xcf8434: stur            w0, [x1, #0xb]
    // 0xcf8438: mov             x0, x1
    // 0xcf843c: r0 = Throw()
    //     0xcf843c: bl              #0x13ddb2c  ; ThrowStub
    // 0xcf8440: brk             #0
    // 0xcf8444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf8444: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8448: b               #0xcf8328
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efbe0, size: 0x24
    // 0x10efbe0: EnterFrame
    //     0x10efbe0: stp             fp, lr, [SP, #-0x10]!
    //     0x10efbe4: mov             fp, SP
    // 0x10efbe8: ldr             x2, [fp, #0x10]
    // 0x10efbec: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efbec: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa28f8] AnonymousClosure: (0xb23008), in [package:flutter/src/rendering/shifted_box.dart] RenderConstraintsTransformBox::computeMinIntrinsicHeight (0xb22f48)
    //     0x10efbf0: ldr             x1, [x1, #0x8f8]
    // 0x10efbf4: r0 = AllocateClosure()
    //     0x10efbf4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efbf8: LeaveFrame
    //     0x10efbf8: mov             SP, fp
    //     0x10efbfc: ldp             fp, lr, [SP], #0x10
    // 0x10efc00: ret
    //     0x10efc00: ret             
  }
  _ RenderConstraintsTransformBox(/* No info */) {
    // ** addr: 0x11d16a4, size: 0xd4
    // 0x11d16a4: EnterFrame
    //     0x11d16a4: stp             fp, lr, [SP, #-0x10]!
    //     0x11d16a8: mov             fp, SP
    // 0x11d16ac: AllocStack(0x20)
    //     0x11d16ac: sub             SP, SP, #0x20
    // 0x11d16b0: r4 = Instance_Rect
    //     0x11d16b0: ldr             x4, [PP, #0x2a60]  ; [pp+0x2a60] Obj!Rect@12a73c1
    // 0x11d16b4: r0 = false
    //     0x11d16b4: add             x0, NULL, #0x30  ; false
    // 0x11d16b8: mov             x6, x1
    // 0x11d16bc: stur            x2, [fp, #-0x10]
    // 0x11d16c0: mov             x16, x3
    // 0x11d16c4: mov             x3, x2
    // 0x11d16c8: mov             x2, x16
    // 0x11d16cc: mov             x16, x5
    // 0x11d16d0: mov             x5, x3
    // 0x11d16d4: mov             x3, x16
    // 0x11d16d8: stur            x1, [fp, #-8]
    // 0x11d16dc: stur            x2, [fp, #-0x18]
    // 0x11d16e0: stur            x3, [fp, #-0x20]
    // 0x11d16e4: CheckStackOverflow
    //     0x11d16e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d16e8: cmp             SP, x16
    //     0x11d16ec: b.ls            #0x11d1770
    // 0x11d16f0: StoreField: r6->field_6b = r4
    //     0x11d16f0: stur            w4, [x6, #0x6b]
    // 0x11d16f4: StoreField: r6->field_6f = r4
    //     0x11d16f4: stur            w4, [x6, #0x6f]
    // 0x11d16f8: StoreField: r6->field_73 = r0
    //     0x11d16f8: stur            w0, [x6, #0x73]
    // 0x11d16fc: r1 = <ClipRectLayer>
    //     0x11d16fc: add             x1, PP, #0x84, lsl #12  ; [pp+0x84fc8] TypeArguments: <ClipRectLayer>
    //     0x11d1700: ldr             x1, [x1, #0xfc8]
    // 0x11d1704: r0 = LayerHandle()
    //     0x11d1704: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11d1708: ldur            x1, [fp, #-8]
    // 0x11d170c: StoreField: r1->field_7b = r0
    //     0x11d170c: stur            w0, [x1, #0x7b]
    //     0x11d1710: ldurb           w16, [x1, #-1]
    //     0x11d1714: ldurb           w17, [x0, #-1]
    //     0x11d1718: and             x16, x17, x16, lsr #2
    //     0x11d171c: tst             x16, HEAP, lsr #32
    //     0x11d1720: b.eq            #0x11d1728
    //     0x11d1724: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d1728: ldur            x0, [fp, #-0x18]
    // 0x11d172c: StoreField: r1->field_63 = r0
    //     0x11d172c: stur            w0, [x1, #0x63]
    //     0x11d1730: ldurb           w16, [x1, #-1]
    //     0x11d1734: ldurb           w17, [x0, #-1]
    //     0x11d1738: and             x16, x17, x16, lsr #2
    //     0x11d173c: tst             x16, HEAP, lsr #32
    //     0x11d1740: b.eq            #0x11d1748
    //     0x11d1744: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d1748: r0 = Instance_Clip
    //     0x11d1748: add             x0, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0x11d174c: ldr             x0, [x0, #0x840]
    // 0x11d1750: StoreField: r1->field_67 = r0
    //     0x11d1750: stur            w0, [x1, #0x67]
    // 0x11d1754: ldur            x2, [fp, #-0x10]
    // 0x11d1758: ldur            x3, [fp, #-0x20]
    // 0x11d175c: r0 = _MixinApplication445&RenderAligningShiftedBox&DebugOverflowIndicatorMixin()
    //     0x11d175c: bl              #0x11d1778  ; [dart:mixin_deduplication] _MixinApplication445&RenderAligningShiftedBox&DebugOverflowIndicatorMixin::_MixinApplication445&RenderAligningShiftedBox&DebugOverflowIndicatorMixin
    // 0x11d1760: r0 = Null
    //     0x11d1760: mov             x0, NULL
    // 0x11d1764: LeaveFrame
    //     0x11d1764: mov             SP, fp
    //     0x11d1768: ldp             fp, lr, [SP], #0x10
    // 0x11d176c: ret
    //     0x11d176c: ret             
    // 0x11d1770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d1770: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d1774: b               #0x11d16f0
  }
}

// class id: 8222, size: 0x14, field offset: 0x14
enum OverflowBoxFit extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab1c4, size: 0x64
    // 0x11ab1c4: EnterFrame
    //     0x11ab1c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab1c8: mov             fp, SP
    // 0x11ab1cc: AllocStack(0x10)
    //     0x11ab1cc: sub             SP, SP, #0x10
    // 0x11ab1d0: SetupParameters(OverflowBoxFit this /* r1 => r0, fp-0x8 */)
    //     0x11ab1d0: mov             x0, x1
    //     0x11ab1d4: stur            x1, [fp, #-8]
    // 0x11ab1d8: CheckStackOverflow
    //     0x11ab1d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab1dc: cmp             SP, x16
    //     0x11ab1e0: b.ls            #0x11ab220
    // 0x11ab1e4: r1 = Null
    //     0x11ab1e4: mov             x1, NULL
    // 0x11ab1e8: r2 = 4
    //     0x11ab1e8: mov             x2, #4
    // 0x11ab1ec: r0 = AllocateArray()
    //     0x11ab1ec: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab1f0: r16 = "OverflowBoxFit."
    //     0x11ab1f0: add             x16, PP, #0xd3, lsl #12  ; [pp+0xd3378] "OverflowBoxFit."
    //     0x11ab1f4: ldr             x16, [x16, #0x378]
    // 0x11ab1f8: StoreField: r0->field_f = r16
    //     0x11ab1f8: stur            w16, [x0, #0xf]
    // 0x11ab1fc: ldur            x1, [fp, #-8]
    // 0x11ab200: LoadField: r2 = r1->field_f
    //     0x11ab200: ldur            w2, [x1, #0xf]
    // 0x11ab204: DecompressPointer r2
    //     0x11ab204: add             x2, x2, HEAP, lsl #32
    // 0x11ab208: StoreField: r0->field_13 = r2
    //     0x11ab208: stur            w2, [x0, #0x13]
    // 0x11ab20c: str             x0, [SP]
    // 0x11ab210: r0 = _interpolate()
    //     0x11ab210: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab214: LeaveFrame
    //     0x11ab214: mov             SP, fp
    //     0x11ab218: ldp             fp, lr, [SP], #0x10
    // 0x11ab21c: ret
    //     0x11ab21c: ret             
    // 0x11ab220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab220: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab224: b               #0x11ab1e4
  }
}
