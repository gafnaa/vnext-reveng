// lib: , url: package:flutter/src/rendering/custom_layout.dart

// class id: 1049022, size: 0x8
class :: {
}

// class id: 2991, size: 0x10, field offset: 0x8
abstract class MultiChildLayoutDelegate extends Object {

  _ _callPerformLayout(/* No info */) {
    // ** addr: 0xbcaeec, size: 0x240
    // 0xbcaeec: EnterFrame
    //     0xbcaeec: stp             fp, lr, [SP, #-0x10]!
    //     0xbcaef0: mov             fp, SP
    // 0xbcaef4: AllocStack(0xa0)
    //     0xbcaef4: sub             SP, SP, #0xa0
    // 0xbcaef8: SetupParameters(MultiChildLayoutDelegate this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */, dynamic _ /* r3 => r3, fp-0x78 */)
    //     0xbcaef8: stur            x1, [fp, #-0x68]
    //     0xbcaefc: stur            x2, [fp, #-0x70]
    //     0xbcaf00: stur            x3, [fp, #-0x78]
    // 0xbcaf04: CheckStackOverflow
    //     0xbcaf04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcaf08: cmp             SP, x16
    //     0xbcaf0c: b.ls            #0xbcb110
    // 0xbcaf10: LoadField: r0 = r1->field_b
    //     0xbcaf10: ldur            w0, [x1, #0xb]
    // 0xbcaf14: DecompressPointer r0
    //     0xbcaf14: add             x0, x0, HEAP, lsl #32
    // 0xbcaf18: stur            x0, [fp, #-0x60]
    // 0xbcaf1c: r16 = <Object, RenderBox>
    //     0xbcaf1c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98658] TypeArguments: <Object, RenderBox>
    //     0xbcaf20: ldr             x16, [x16, #0x658]
    // 0xbcaf24: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xbcaf28: stp             lr, x16, [SP]
    // 0xbcaf2c: r0 = Map._fromLiteral()
    //     0xbcaf2c: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xbcaf30: ldur            x3, [fp, #-0x68]
    // 0xbcaf34: StoreField: r3->field_b = r0
    //     0xbcaf34: stur            w0, [x3, #0xb]
    //     0xbcaf38: ldurb           w16, [x3, #-1]
    //     0xbcaf3c: ldurb           w17, [x0, #-1]
    //     0xbcaf40: and             x16, x17, x16, lsr #2
    //     0xbcaf44: tst             x16, HEAP, lsr #32
    //     0xbcaf48: b.eq            #0xbcaf50
    //     0xbcaf4c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbcaf50: ldur            x4, [fp, #-0x78]
    // 0xbcaf54: stur            x4, [fp, #-0x80]
    // 0xbcaf58: CheckStackOverflow
    //     0xbcaf58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcaf5c: cmp             SP, x16
    //     0xbcaf60: b.ls            #0xbcb118
    // 0xbcaf64: cmp             w4, NULL
    // 0xbcaf68: b.eq            #0xbcb088
    // 0xbcaf6c: LoadField: r5 = r4->field_7
    //     0xbcaf6c: ldur            w5, [x4, #7]
    // 0xbcaf70: DecompressPointer r5
    //     0xbcaf70: add             x5, x5, HEAP, lsl #32
    // 0xbcaf74: stur            x5, [fp, #-0x78]
    // 0xbcaf78: cmp             w5, NULL
    // 0xbcaf7c: b.eq            #0xbcb120
    // 0xbcaf80: mov             x0, x5
    // 0xbcaf84: r2 = Null
    //     0xbcaf84: mov             x2, NULL
    // 0xbcaf88: r1 = Null
    //     0xbcaf88: mov             x1, NULL
    // 0xbcaf8c: r4 = LoadClassIdInstr(r0)
    //     0xbcaf8c: ldur            x4, [x0, #-1]
    //     0xbcaf90: ubfx            x4, x4, #0xc, #0x14
    // 0xbcaf94: r17 = 4213
    //     0xbcaf94: mov             x17, #0x1075
    // 0xbcaf98: cmp             x4, x17
    // 0xbcaf9c: b.eq            #0xbcafb4
    // 0xbcafa0: r8 = MultiChildLayoutParentData
    //     0xbcafa0: add             x8, PP, #0x90, lsl #12  ; [pp+0x90280] Type: MultiChildLayoutParentData
    //     0xbcafa4: ldr             x8, [x8, #0x280]
    // 0xbcafa8: r3 = Null
    //     0xbcafa8: add             x3, PP, #0x98, lsl #12  ; [pp+0x98660] Null
    //     0xbcafac: ldr             x3, [x3, #0x660]
    // 0xbcafb0: r0 = DefaultTypeTest()
    //     0xbcafb0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbcafb4: ldur            x3, [fp, #-0x68]
    // 0xbcafb8: LoadField: r4 = r3->field_b
    //     0xbcafb8: ldur            w4, [x3, #0xb]
    // 0xbcafbc: DecompressPointer r4
    //     0xbcafbc: add             x4, x4, HEAP, lsl #32
    // 0xbcafc0: stur            x4, [fp, #-0x90]
    // 0xbcafc4: cmp             w4, NULL
    // 0xbcafc8: b.eq            #0xbcb124
    // 0xbcafcc: ldur            x5, [fp, #-0x78]
    // 0xbcafd0: ArrayLoad: r6 = r5[0]  ; List_4
    //     0xbcafd0: ldur            w6, [x5, #0x17]
    // 0xbcafd4: DecompressPointer r6
    //     0xbcafd4: add             x6, x6, HEAP, lsl #32
    // 0xbcafd8: stur            x6, [fp, #-0x88]
    // 0xbcafdc: cmp             w6, NULL
    // 0xbcafe0: b.eq            #0xbcb128
    // 0xbcafe4: mov             x0, x6
    // 0xbcafe8: r2 = Null
    //     0xbcafe8: mov             x2, NULL
    // 0xbcafec: r1 = Null
    //     0xbcafec: mov             x1, NULL
    // 0xbcaff0: cmp             w0, NULL
    // 0xbcaff4: b.ne            #0xbcb008
    // 0xbcaff8: r8 = Object
    //     0xbcaff8: ldr             x8, [PP, #0xd0]  ; [pp+0xd0] Type: Object
    // 0xbcaffc: r3 = Null
    //     0xbcaffc: add             x3, PP, #0x98, lsl #12  ; [pp+0x98670] Null
    //     0xbcb000: ldr             x3, [x3, #0x670]
    // 0xbcb004: r0 = Object()
    //     0xbcb004: bl              #0x13ef428  ; IsType_Object_Stub
    // 0xbcb008: ldur            x0, [fp, #-0x80]
    // 0xbcb00c: r2 = Null
    //     0xbcb00c: mov             x2, NULL
    // 0xbcb010: r1 = Null
    //     0xbcb010: mov             x1, NULL
    // 0xbcb014: r4 = LoadClassIdInstr(r0)
    //     0xbcb014: ldur            x4, [x0, #-1]
    //     0xbcb018: ubfx            x4, x4, #0xc, #0x14
    // 0xbcb01c: r17 = -4710
    //     0xbcb01c: mov             x17, #-0x1266
    // 0xbcb020: add             x4, x4, x17
    // 0xbcb024: cmp             x4, #0x109
    // 0xbcb028: b.ls            #0xbcb03c
    // 0xbcb02c: r8 = RenderBox
    //     0xbcb02c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbcb030: r3 = Null
    //     0xbcb030: add             x3, PP, #0x98, lsl #12  ; [pp+0x98680] Null
    //     0xbcb034: ldr             x3, [x3, #0x680]
    // 0xbcb038: r0 = RenderBox()
    //     0xbcb038: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbcb03c: ldur            x1, [fp, #-0x90]
    // 0xbcb040: ldur            x2, [fp, #-0x88]
    // 0xbcb044: r0 = _hashCode()
    //     0xbcb044: bl              #0x13d8cbc  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode::_hashCode
    // 0xbcb048: mov             x2, x0
    // 0xbcb04c: r0 = BoxInt64Instr(r2)
    //     0xbcb04c: sbfiz           x0, x2, #1, #0x1f
    //     0xbcb050: cmp             x2, x0, asr #1
    //     0xbcb054: b.eq            #0xbcb060
    //     0xbcb058: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbcb05c: stur            x2, [x0, #7]
    // 0xbcb060: ldur            x1, [fp, #-0x90]
    // 0xbcb064: ldur            x2, [fp, #-0x88]
    // 0xbcb068: ldur            x3, [fp, #-0x80]
    // 0xbcb06c: mov             x5, x0
    // 0xbcb070: r0 = _set()
    //     0xbcb070: bl              #0x13d8170  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0xbcb074: ldur            x0, [fp, #-0x78]
    // 0xbcb078: LoadField: r4 = r0->field_13
    //     0xbcb078: ldur            w4, [x0, #0x13]
    // 0xbcb07c: DecompressPointer r4
    //     0xbcb07c: add             x4, x4, HEAP, lsl #32
    // 0xbcb080: ldur            x3, [fp, #-0x68]
    // 0xbcb084: b               #0xbcaf54
    // 0xbcb088: r0 = LoadClassIdInstr(r3)
    //     0xbcb088: ldur            x0, [x3, #-1]
    //     0xbcb08c: ubfx            x0, x0, #0xc, #0x14
    // 0xbcb090: mov             x1, x3
    // 0xbcb094: ldur            x2, [fp, #-0x70]
    // 0xbcb098: r0 = GDT[cid_x0 + -0xf18]()
    //     0xbcb098: sub             lr, x0, #0xf18
    //     0xbcb09c: ldr             lr, [x21, lr, lsl #3]
    //     0xbcb0a0: blr             lr
    // 0xbcb0a4: ldur            x2, [fp, #-0x68]
    // 0xbcb0a8: ldur            x0, [fp, #-0x60]
    // 0xbcb0ac: StoreField: r2->field_b = r0
    //     0xbcb0ac: stur            w0, [x2, #0xb]
    //     0xbcb0b0: ldurb           w16, [x2, #-1]
    //     0xbcb0b4: ldurb           w17, [x0, #-1]
    //     0xbcb0b8: and             x16, x17, x16, lsr #2
    //     0xbcb0bc: tst             x16, HEAP, lsr #32
    //     0xbcb0c0: b.eq            #0xbcb0c8
    //     0xbcb0c4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbcb0c8: r0 = Null
    //     0xbcb0c8: mov             x0, NULL
    // 0xbcb0cc: LeaveFrame
    //     0xbcb0cc: mov             SP, fp
    //     0xbcb0d0: ldp             fp, lr, [SP], #0x10
    // 0xbcb0d4: ret
    //     0xbcb0d4: ret             
    // 0xbcb0d8: sub             SP, fp, #0xa0
    // 0xbcb0dc: ldur            x2, [fp, #-0x68]
    // 0xbcb0e0: mov             x3, x0
    // 0xbcb0e4: ldur            x0, [fp, #-0x60]
    // 0xbcb0e8: StoreField: r2->field_b = r0
    //     0xbcb0e8: stur            w0, [x2, #0xb]
    //     0xbcb0ec: ldurb           w16, [x2, #-1]
    //     0xbcb0f0: ldurb           w17, [x0, #-1]
    //     0xbcb0f4: and             x16, x17, x16, lsr #2
    //     0xbcb0f8: tst             x16, HEAP, lsr #32
    //     0xbcb0fc: b.eq            #0xbcb104
    //     0xbcb100: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbcb104: mov             x0, x3
    // 0xbcb108: r0 = ReThrow()
    //     0xbcb108: bl              #0x13ddb00  ; ReThrowStub
    // 0xbcb10c: brk             #0
    // 0xbcb110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcb110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcb114: b               #0xbcaf10
    // 0xbcb118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcb118: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcb11c: b               #0xbcaf64
    // 0xbcb120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb120: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcb124: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb124: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcb128: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb128: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ positionChild(/* No info */) {
    // ** addr: 0x12fa1f4, size: 0xf8
    // 0x12fa1f4: EnterFrame
    //     0x12fa1f4: stp             fp, lr, [SP, #-0x10]!
    //     0x12fa1f8: mov             fp, SP
    // 0x12fa1fc: AllocStack(0x10)
    //     0x12fa1fc: sub             SP, SP, #0x10
    // 0x12fa200: SetupParameters(dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x12fa200: mov             x0, x3
    //     0x12fa204: stur            x3, [fp, #-0x10]
    // 0x12fa208: CheckStackOverflow
    //     0x12fa208: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fa20c: cmp             SP, x16
    //     0x12fa210: b.ls            #0x12fa2d8
    // 0x12fa214: LoadField: r3 = r1->field_b
    //     0x12fa214: ldur            w3, [x1, #0xb]
    // 0x12fa218: DecompressPointer r3
    //     0x12fa218: add             x3, x3, HEAP, lsl #32
    // 0x12fa21c: stur            x3, [fp, #-8]
    // 0x12fa220: cmp             w3, NULL
    // 0x12fa224: b.eq            #0x12fa2e0
    // 0x12fa228: mov             x1, x3
    // 0x12fa22c: r0 = _getValueOrData()
    //     0x12fa22c: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x12fa230: mov             x1, x0
    // 0x12fa234: ldur            x0, [fp, #-8]
    // 0x12fa238: LoadField: r2 = r0->field_f
    //     0x12fa238: ldur            w2, [x0, #0xf]
    // 0x12fa23c: DecompressPointer r2
    //     0x12fa23c: add             x2, x2, HEAP, lsl #32
    // 0x12fa240: cmp             w2, w1
    // 0x12fa244: b.ne            #0x12fa250
    // 0x12fa248: r0 = Null
    //     0x12fa248: mov             x0, NULL
    // 0x12fa24c: b               #0x12fa254
    // 0x12fa250: mov             x0, x1
    // 0x12fa254: cmp             w0, NULL
    // 0x12fa258: b.eq            #0x12fa2e4
    // 0x12fa25c: LoadField: r3 = r0->field_7
    //     0x12fa25c: ldur            w3, [x0, #7]
    // 0x12fa260: DecompressPointer r3
    //     0x12fa260: add             x3, x3, HEAP, lsl #32
    // 0x12fa264: stur            x3, [fp, #-8]
    // 0x12fa268: cmp             w3, NULL
    // 0x12fa26c: b.eq            #0x12fa2e8
    // 0x12fa270: mov             x0, x3
    // 0x12fa274: r2 = Null
    //     0x12fa274: mov             x2, NULL
    // 0x12fa278: r1 = Null
    //     0x12fa278: mov             x1, NULL
    // 0x12fa27c: r4 = LoadClassIdInstr(r0)
    //     0x12fa27c: ldur            x4, [x0, #-1]
    //     0x12fa280: ubfx            x4, x4, #0xc, #0x14
    // 0x12fa284: r17 = 4213
    //     0x12fa284: mov             x17, #0x1075
    // 0x12fa288: cmp             x4, x17
    // 0x12fa28c: b.eq            #0x12fa2a4
    // 0x12fa290: r8 = MultiChildLayoutParentData
    //     0x12fa290: add             x8, PP, #0x90, lsl #12  ; [pp+0x90280] Type: MultiChildLayoutParentData
    //     0x12fa294: ldr             x8, [x8, #0x280]
    // 0x12fa298: r3 = Null
    //     0x12fa298: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1848] Null
    //     0x12fa29c: ldr             x3, [x3, #0x848]
    // 0x12fa2a0: r0 = DefaultTypeTest()
    //     0x12fa2a0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x12fa2a4: ldur            x0, [fp, #-0x10]
    // 0x12fa2a8: ldur            x1, [fp, #-8]
    // 0x12fa2ac: StoreField: r1->field_7 = r0
    //     0x12fa2ac: stur            w0, [x1, #7]
    //     0x12fa2b0: ldurb           w16, [x1, #-1]
    //     0x12fa2b4: ldurb           w17, [x0, #-1]
    //     0x12fa2b8: and             x16, x17, x16, lsr #2
    //     0x12fa2bc: tst             x16, HEAP, lsr #32
    //     0x12fa2c0: b.eq            #0x12fa2c8
    //     0x12fa2c4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x12fa2c8: r0 = Null
    //     0x12fa2c8: mov             x0, NULL
    // 0x12fa2cc: LeaveFrame
    //     0x12fa2cc: mov             SP, fp
    //     0x12fa2d0: ldp             fp, lr, [SP], #0x10
    // 0x12fa2d4: ret
    //     0x12fa2d4: ret             
    // 0x12fa2d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fa2d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fa2dc: b               #0x12fa214
    // 0x12fa2e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fa2e0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12fa2e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fa2e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12fa2e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fa2e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ layoutChild(/* No info */) {
    // ** addr: 0x12fa2ec, size: 0xc0
    // 0x12fa2ec: EnterFrame
    //     0x12fa2ec: stp             fp, lr, [SP, #-0x10]!
    //     0x12fa2f0: mov             fp, SP
    // 0x12fa2f4: AllocStack(0x18)
    //     0x12fa2f4: sub             SP, SP, #0x18
    // 0x12fa2f8: SetupParameters(dynamic _ /* r3 => r0, fp-0x10 */)
    //     0x12fa2f8: mov             x0, x3
    //     0x12fa2fc: stur            x3, [fp, #-0x10]
    // 0x12fa300: CheckStackOverflow
    //     0x12fa300: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fa304: cmp             SP, x16
    //     0x12fa308: b.ls            #0x12fa39c
    // 0x12fa30c: LoadField: r3 = r1->field_b
    //     0x12fa30c: ldur            w3, [x1, #0xb]
    // 0x12fa310: DecompressPointer r3
    //     0x12fa310: add             x3, x3, HEAP, lsl #32
    // 0x12fa314: stur            x3, [fp, #-8]
    // 0x12fa318: cmp             w3, NULL
    // 0x12fa31c: b.eq            #0x12fa3a4
    // 0x12fa320: mov             x1, x3
    // 0x12fa324: r0 = _getValueOrData()
    //     0x12fa324: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x12fa328: mov             x1, x0
    // 0x12fa32c: ldur            x0, [fp, #-8]
    // 0x12fa330: LoadField: r2 = r0->field_f
    //     0x12fa330: ldur            w2, [x0, #0xf]
    // 0x12fa334: DecompressPointer r2
    //     0x12fa334: add             x2, x2, HEAP, lsl #32
    // 0x12fa338: cmp             w2, w1
    // 0x12fa33c: b.ne            #0x12fa348
    // 0x12fa340: r3 = Null
    //     0x12fa340: mov             x3, NULL
    // 0x12fa344: b               #0x12fa34c
    // 0x12fa348: mov             x3, x1
    // 0x12fa34c: stur            x3, [fp, #-8]
    // 0x12fa350: cmp             w3, NULL
    // 0x12fa354: b.eq            #0x12fa3a8
    // 0x12fa358: r0 = LoadClassIdInstr(r3)
    //     0x12fa358: ldur            x0, [x3, #-1]
    //     0x12fa35c: ubfx            x0, x0, #0xc, #0x14
    // 0x12fa360: r16 = true
    //     0x12fa360: add             x16, NULL, #0x20  ; true
    // 0x12fa364: str             x16, [SP]
    // 0x12fa368: mov             x1, x3
    // 0x12fa36c: ldur            x2, [fp, #-0x10]
    // 0x12fa370: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0x12fa370: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0x12fa374: ldr             x4, [x4, #0xed0]
    // 0x12fa378: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0x12fa378: mov             x17, #0xe6b9
    //     0x12fa37c: add             lr, x0, x17
    //     0x12fa380: ldr             lr, [x21, lr, lsl #3]
    //     0x12fa384: blr             lr
    // 0x12fa388: ldur            x1, [fp, #-8]
    // 0x12fa38c: r0 = size()
    //     0x12fa38c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x12fa390: LeaveFrame
    //     0x12fa390: mov             SP, fp
    //     0x12fa394: ldp             fp, lr, [SP], #0x10
    // 0x12fa398: ret
    //     0x12fa398: ret             
    // 0x12fa39c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fa39c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fa3a0: b               #0x12fa30c
    // 0x12fa3a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fa3a4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x12fa3a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fa3a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hasChild(/* No info */) {
    // ** addr: 0x12fa3ac, size: 0x7c
    // 0x12fa3ac: EnterFrame
    //     0x12fa3ac: stp             fp, lr, [SP, #-0x10]!
    //     0x12fa3b0: mov             fp, SP
    // 0x12fa3b4: AllocStack(0x8)
    //     0x12fa3b4: sub             SP, SP, #8
    // 0x12fa3b8: CheckStackOverflow
    //     0x12fa3b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x12fa3bc: cmp             SP, x16
    //     0x12fa3c0: b.ls            #0x12fa41c
    // 0x12fa3c4: LoadField: r0 = r1->field_b
    //     0x12fa3c4: ldur            w0, [x1, #0xb]
    // 0x12fa3c8: DecompressPointer r0
    //     0x12fa3c8: add             x0, x0, HEAP, lsl #32
    // 0x12fa3cc: stur            x0, [fp, #-8]
    // 0x12fa3d0: cmp             w0, NULL
    // 0x12fa3d4: b.eq            #0x12fa424
    // 0x12fa3d8: mov             x1, x0
    // 0x12fa3dc: r0 = _getValueOrData()
    //     0x12fa3dc: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x12fa3e0: ldur            x1, [fp, #-8]
    // 0x12fa3e4: LoadField: r2 = r1->field_f
    //     0x12fa3e4: ldur            w2, [x1, #0xf]
    // 0x12fa3e8: DecompressPointer r2
    //     0x12fa3e8: add             x2, x2, HEAP, lsl #32
    // 0x12fa3ec: cmp             w2, w0
    // 0x12fa3f0: b.ne            #0x12fa3fc
    // 0x12fa3f4: r1 = Null
    //     0x12fa3f4: mov             x1, NULL
    // 0x12fa3f8: b               #0x12fa400
    // 0x12fa3fc: mov             x1, x0
    // 0x12fa400: cmp             w1, NULL
    // 0x12fa404: r16 = true
    //     0x12fa404: add             x16, NULL, #0x20  ; true
    // 0x12fa408: r17 = false
    //     0x12fa408: add             x17, NULL, #0x30  ; false
    // 0x12fa40c: csel            x0, x16, x17, ne
    // 0x12fa410: LeaveFrame
    //     0x12fa410: mov             SP, fp
    //     0x12fa414: ldp             fp, lr, [SP], #0x10
    // 0x12fa418: ret
    //     0x12fa418: ret             
    // 0x12fa41c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12fa41c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12fa420: b               #0x12fa3c4
    // 0x12fa424: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x12fa424: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4213, size: 0x1c, field offset: 0x18
class MultiChildLayoutParentData extends ContainerBoxParentData<dynamic> {
}

// class id: 4817, size: 0x64, field offset: 0x60
class RenderCustomMultiChildLayoutBox extends _MixinApplication425&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb20080, size: 0x24
    // 0xb20080: EnterFrame
    //     0xb20080: stp             fp, lr, [SP, #-0x10]!
    //     0xb20084: mov             fp, SP
    // 0xb20088: ldr             x2, [fp, #0x10]
    // 0xb2008c: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb2008c: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa29b0] AnonymousClosure: (0xb200a4), in [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMaxIntrinsicWidth (0xb2ea90)
    //     0xb20090: ldr             x1, [x1, #0x9b0]
    // 0xb20094: r0 = AllocateClosure()
    //     0xb20094: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb20098: LeaveFrame
    //     0xb20098: mov             SP, fp
    //     0xb2009c: ldp             fp, lr, [SP], #0x10
    // 0xb200a0: ret
    //     0xb200a0: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb200a4, size: 0x78
    // 0xb200a4: EnterFrame
    //     0xb200a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb200a8: mov             fp, SP
    // 0xb200ac: ldr             x0, [fp, #0x18]
    // 0xb200b0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb200b0: ldur            w1, [x0, #0x17]
    // 0xb200b4: DecompressPointer r1
    //     0xb200b4: add             x1, x1, HEAP, lsl #32
    // 0xb200b8: CheckStackOverflow
    //     0xb200b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb200bc: cmp             SP, x16
    //     0xb200c0: b.ls            #0xb20104
    // 0xb200c4: ldr             x2, [fp, #0x10]
    // 0xb200c8: r0 = computeMaxIntrinsicWidth()
    //     0xb200c8: bl              #0xb2ea90  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMaxIntrinsicWidth
    // 0xb200cc: r0 = inline_Allocate_Double()
    //     0xb200cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb200d0: add             x0, x0, #0x10
    //     0xb200d4: cmp             x1, x0
    //     0xb200d8: b.ls            #0xb2010c
    //     0xb200dc: str             x0, [THR, #0x60]  ; THR::top
    //     0xb200e0: sub             x0, x0, #0xf
    //     0xb200e4: mov             x1, #0xe19c
    //     0xb200e8: movk            x1, #3, lsl #16
    //     0xb200ec: stur            x1, [x0, #-1]
    // 0xb200f0: dmb             ishst
    // 0xb200f4: StoreField: r0->field_7 = d0
    //     0xb200f4: stur            d0, [x0, #7]
    // 0xb200f8: LeaveFrame
    //     0xb200f8: mov             SP, fp
    //     0xb200fc: ldp             fp, lr, [SP], #0x10
    // 0xb20100: ret
    //     0xb20100: ret             
    // 0xb20104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb20104: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb20108: b               #0xb200c4
    // 0xb2010c: SaveReg d0
    //     0xb2010c: str             q0, [SP, #-0x10]!
    // 0xb20110: r0 = AllocateDouble()
    //     0xb20110: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb20114: RestoreReg d0
    //     0xb20114: ldr             q0, [SP], #0x10
    // 0xb20118: b               #0xb200f4
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2b90c, size: 0xd0
    // 0xb2b90c: EnterFrame
    //     0xb2b90c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2b910: mov             fp, SP
    // 0xb2b914: AllocStack(0x18)
    //     0xb2b914: sub             SP, SP, #0x18
    // 0xb2b918: d0 = inf
    //     0xb2b918: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2b91c: stur            x1, [fp, #-8]
    // 0xb2b920: CheckStackOverflow
    //     0xb2b920: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2b924: cmp             SP, x16
    //     0xb2b928: b.ls            #0xb2b9d4
    // 0xb2b92c: LoadField: d1 = r2->field_7
    //     0xb2b92c: ldur            d1, [x2, #7]
    // 0xb2b930: stur            d1, [fp, #-0x18]
    // 0xb2b934: fcmp            d1, d0
    // 0xb2b938: b.eq            #0xb2b944
    // 0xb2b93c: mov             v2.16b, v1.16b
    // 0xb2b940: b               #0xb2b948
    // 0xb2b944: d2 = 0.000000
    //     0xb2b944: eor             v2.16b, v2.16b, v2.16b
    // 0xb2b948: stur            d2, [fp, #-0x10]
    // 0xb2b94c: r0 = BoxConstraints()
    //     0xb2b94c: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2b950: ldur            d0, [fp, #-0x10]
    // 0xb2b954: StoreField: r0->field_7 = d0
    //     0xb2b954: stur            d0, [x0, #7]
    // 0xb2b958: ldur            d1, [fp, #-0x18]
    // 0xb2b95c: d0 = inf
    //     0xb2b95c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2b960: fcmp            d1, d0
    // 0xb2b964: b.ne            #0xb2b96c
    // 0xb2b968: d1 = inf
    //     0xb2b968: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2b96c: StoreField: r0->field_f = d1
    //     0xb2b96c: stur            d1, [x0, #0xf]
    // 0xb2b970: fcmp            d0, d0
    // 0xb2b974: b.eq            #0xb2b980
    // 0xb2b978: d1 = inf
    //     0xb2b978: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2b97c: b               #0xb2b984
    // 0xb2b980: d1 = 0.000000
    //     0xb2b980: eor             v1.16b, v1.16b, v1.16b
    // 0xb2b984: ArrayStore: r0[0] = d1  ; List_8
    //     0xb2b984: stur            d1, [x0, #0x17]
    // 0xb2b988: StoreField: r0->field_1f = d0
    //     0xb2b988: stur            d0, [x0, #0x1f]
    // 0xb2b98c: ldur            x1, [fp, #-8]
    // 0xb2b990: mov             x2, x0
    // 0xb2b994: r0 = _getSize()
    //     0xb2b994: bl              #0xb2ba54  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::_getSize
    // 0xb2b998: LoadField: d0 = r0->field_f
    //     0xb2b998: ldur            d0, [x0, #0xf]
    // 0xb2b99c: mov             x0, v0.d[0]
    // 0xb2b9a0: and             x0, x0, #0x7fffffffffffffff
    // 0xb2b9a4: r17 = 9218868437227405312
    //     0xb2b9a4: mov             x17, #0x7ff0000000000000
    // 0xb2b9a8: cmp             x0, x17
    // 0xb2b9ac: b.eq            #0xb2b9c4
    // 0xb2b9b0: fcmp            d0, d0
    // 0xb2b9b4: b.vs            #0xb2b9c4
    // 0xb2b9b8: LeaveFrame
    //     0xb2b9b8: mov             SP, fp
    //     0xb2b9bc: ldp             fp, lr, [SP], #0x10
    // 0xb2b9c0: ret
    //     0xb2b9c0: ret             
    // 0xb2b9c4: d0 = 0.000000
    //     0xb2b9c4: eor             v0.16b, v0.16b, v0.16b
    // 0xb2b9c8: LeaveFrame
    //     0xb2b9c8: mov             SP, fp
    //     0xb2b9cc: ldp             fp, lr, [SP], #0x10
    // 0xb2b9d0: ret
    //     0xb2b9d0: ret             
    // 0xb2b9d4: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2b9d4: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2b9d8: b               #0xb2b92c
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2b9dc, size: 0x78
    // 0xb2b9dc: EnterFrame
    //     0xb2b9dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb2b9e0: mov             fp, SP
    // 0xb2b9e4: ldr             x0, [fp, #0x18]
    // 0xb2b9e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2b9e8: ldur            w1, [x0, #0x17]
    // 0xb2b9ec: DecompressPointer r1
    //     0xb2b9ec: add             x1, x1, HEAP, lsl #32
    // 0xb2b9f0: CheckStackOverflow
    //     0xb2b9f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2b9f4: cmp             SP, x16
    //     0xb2b9f8: b.ls            #0xb2ba3c
    // 0xb2b9fc: ldr             x2, [fp, #0x10]
    // 0xb2ba00: r0 = computeMaxIntrinsicHeight()
    //     0xb2ba00: bl              #0xb2b90c  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMaxIntrinsicHeight
    // 0xb2ba04: r0 = inline_Allocate_Double()
    //     0xb2ba04: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2ba08: add             x0, x0, #0x10
    //     0xb2ba0c: cmp             x1, x0
    //     0xb2ba10: b.ls            #0xb2ba44
    //     0xb2ba14: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2ba18: sub             x0, x0, #0xf
    //     0xb2ba1c: mov             x1, #0xe19c
    //     0xb2ba20: movk            x1, #3, lsl #16
    //     0xb2ba24: stur            x1, [x0, #-1]
    // 0xb2ba28: dmb             ishst
    // 0xb2ba2c: StoreField: r0->field_7 = d0
    //     0xb2ba2c: stur            d0, [x0, #7]
    // 0xb2ba30: LeaveFrame
    //     0xb2ba30: mov             SP, fp
    //     0xb2ba34: ldp             fp, lr, [SP], #0x10
    // 0xb2ba38: ret
    //     0xb2ba38: ret             
    // 0xb2ba3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ba3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ba40: b               #0xb2b9fc
    // 0xb2ba44: SaveReg d0
    //     0xb2ba44: str             q0, [SP, #-0x10]!
    // 0xb2ba48: r0 = AllocateDouble()
    //     0xb2ba48: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2ba4c: RestoreReg d0
    //     0xb2ba4c: ldr             q0, [SP], #0x10
    // 0xb2ba50: b               #0xb2ba2c
  }
  _ _getSize(/* No info */) {
    // ** addr: 0xb2ba54, size: 0x74
    // 0xb2ba54: EnterFrame
    //     0xb2ba54: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ba58: mov             fp, SP
    // 0xb2ba5c: AllocStack(0x18)
    //     0xb2ba5c: sub             SP, SP, #0x18
    // 0xb2ba60: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xb2ba60: mov             x0, x2
    //     0xb2ba64: stur            x2, [fp, #-8]
    // 0xb2ba68: CheckStackOverflow
    //     0xb2ba68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ba6c: cmp             SP, x16
    //     0xb2ba70: b.ls            #0xb2bac0
    // 0xb2ba74: mov             x1, x0
    // 0xb2ba78: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb2ba78: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb2ba7c: r0 = constrainWidth()
    //     0xb2ba7c: bl              #0x898d38  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainWidth
    // 0xb2ba80: ldur            x1, [fp, #-8]
    // 0xb2ba84: stur            d0, [fp, #-0x10]
    // 0xb2ba88: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb2ba88: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb2ba8c: r0 = constrainHeight()
    //     0xb2ba8c: bl              #0x898cc4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainHeight
    // 0xb2ba90: stur            d0, [fp, #-0x18]
    // 0xb2ba94: r0 = Size()
    //     0xb2ba94: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb2ba98: ldur            d0, [fp, #-0x10]
    // 0xb2ba9c: StoreField: r0->field_7 = d0
    //     0xb2ba9c: stur            d0, [x0, #7]
    // 0xb2baa0: ldur            d0, [fp, #-0x18]
    // 0xb2baa4: StoreField: r0->field_f = d0
    //     0xb2baa4: stur            d0, [x0, #0xf]
    // 0xb2baa8: ldur            x1, [fp, #-8]
    // 0xb2baac: mov             x2, x0
    // 0xb2bab0: r0 = constrain()
    //     0xb2bab0: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb2bab4: LeaveFrame
    //     0xb2bab4: mov             SP, fp
    //     0xb2bab8: ldp             fp, lr, [SP], #0x10
    // 0xb2babc: ret
    //     0xb2babc: ret             
    // 0xb2bac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2bac0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2bac4: b               #0xb2ba74
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2ea90, size: 0xd8
    // 0xb2ea90: EnterFrame
    //     0xb2ea90: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ea94: mov             fp, SP
    // 0xb2ea98: AllocStack(0x18)
    //     0xb2ea98: sub             SP, SP, #0x18
    // 0xb2ea9c: d0 = inf
    //     0xb2ea9c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2eaa0: stur            x1, [fp, #-8]
    // 0xb2eaa4: stur            x2, [fp, #-0x10]
    // 0xb2eaa8: CheckStackOverflow
    //     0xb2eaa8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2eaac: cmp             SP, x16
    //     0xb2eab0: b.ls            #0xb2eb60
    // 0xb2eab4: fcmp            d0, d0
    // 0xb2eab8: b.eq            #0xb2eac4
    // 0xb2eabc: d1 = inf
    //     0xb2eabc: ldr             d1, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2eac0: b               #0xb2eac8
    // 0xb2eac4: d1 = 0.000000
    //     0xb2eac4: eor             v1.16b, v1.16b, v1.16b
    // 0xb2eac8: stur            d1, [fp, #-0x18]
    // 0xb2eacc: r0 = BoxConstraints()
    //     0xb2eacc: bl              #0x89d3a4  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb2ead0: ldur            d0, [fp, #-0x18]
    // 0xb2ead4: StoreField: r0->field_7 = d0
    //     0xb2ead4: stur            d0, [x0, #7]
    // 0xb2ead8: d0 = inf
    //     0xb2ead8: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2eadc: StoreField: r0->field_f = d0
    //     0xb2eadc: stur            d0, [x0, #0xf]
    // 0xb2eae0: ldur            x1, [fp, #-0x10]
    // 0xb2eae4: LoadField: d1 = r1->field_7
    //     0xb2eae4: ldur            d1, [x1, #7]
    // 0xb2eae8: fcmp            d1, d0
    // 0xb2eaec: b.eq            #0xb2eaf8
    // 0xb2eaf0: mov             v2.16b, v1.16b
    // 0xb2eaf4: b               #0xb2eafc
    // 0xb2eaf8: d2 = 0.000000
    //     0xb2eaf8: eor             v2.16b, v2.16b, v2.16b
    // 0xb2eafc: ArrayStore: r0[0] = d2  ; List_8
    //     0xb2eafc: stur            d2, [x0, #0x17]
    // 0xb2eb00: fcmp            d1, d0
    // 0xb2eb04: b.eq            #0xb2eb10
    // 0xb2eb08: mov             v0.16b, v1.16b
    // 0xb2eb0c: b               #0xb2eb14
    // 0xb2eb10: d0 = inf
    //     0xb2eb10: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2eb14: StoreField: r0->field_1f = d0
    //     0xb2eb14: stur            d0, [x0, #0x1f]
    // 0xb2eb18: ldur            x1, [fp, #-8]
    // 0xb2eb1c: mov             x2, x0
    // 0xb2eb20: r0 = _getSize()
    //     0xb2eb20: bl              #0xb2ba54  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::_getSize
    // 0xb2eb24: LoadField: d0 = r0->field_7
    //     0xb2eb24: ldur            d0, [x0, #7]
    // 0xb2eb28: mov             x0, v0.d[0]
    // 0xb2eb2c: and             x0, x0, #0x7fffffffffffffff
    // 0xb2eb30: r17 = 9218868437227405312
    //     0xb2eb30: mov             x17, #0x7ff0000000000000
    // 0xb2eb34: cmp             x0, x17
    // 0xb2eb38: b.eq            #0xb2eb50
    // 0xb2eb3c: fcmp            d0, d0
    // 0xb2eb40: b.vs            #0xb2eb50
    // 0xb2eb44: LeaveFrame
    //     0xb2eb44: mov             SP, fp
    //     0xb2eb48: ldp             fp, lr, [SP], #0x10
    // 0xb2eb4c: ret
    //     0xb2eb4c: ret             
    // 0xb2eb50: d0 = 0.000000
    //     0xb2eb50: eor             v0.16b, v0.16b, v0.16b
    // 0xb2eb54: LeaveFrame
    //     0xb2eb54: mov             SP, fp
    //     0xb2eb58: ldp             fp, lr, [SP], #0x10
    // 0xb2eb5c: ret
    //     0xb2eb5c: ret             
    // 0xb2eb60: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2eb60: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2eb64: b               #0xb2eab4
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2eb68, size: 0x78
    // 0xb2eb68: EnterFrame
    //     0xb2eb68: stp             fp, lr, [SP, #-0x10]!
    //     0xb2eb6c: mov             fp, SP
    // 0xb2eb70: ldr             x0, [fp, #0x18]
    // 0xb2eb74: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2eb74: ldur            w1, [x0, #0x17]
    // 0xb2eb78: DecompressPointer r1
    //     0xb2eb78: add             x1, x1, HEAP, lsl #32
    // 0xb2eb7c: CheckStackOverflow
    //     0xb2eb7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2eb80: cmp             SP, x16
    //     0xb2eb84: b.ls            #0xb2ebc8
    // 0xb2eb88: ldr             x2, [fp, #0x10]
    // 0xb2eb8c: r0 = computeMaxIntrinsicWidth()
    //     0xb2eb8c: bl              #0xb2ea90  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMaxIntrinsicWidth
    // 0xb2eb90: r0 = inline_Allocate_Double()
    //     0xb2eb90: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2eb94: add             x0, x0, #0x10
    //     0xb2eb98: cmp             x1, x0
    //     0xb2eb9c: b.ls            #0xb2ebd0
    //     0xb2eba0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2eba4: sub             x0, x0, #0xf
    //     0xb2eba8: mov             x1, #0xe19c
    //     0xb2ebac: movk            x1, #3, lsl #16
    //     0xb2ebb0: stur            x1, [x0, #-1]
    // 0xb2ebb4: dmb             ishst
    // 0xb2ebb8: StoreField: r0->field_7 = d0
    //     0xb2ebb8: stur            d0, [x0, #7]
    // 0xb2ebbc: LeaveFrame
    //     0xb2ebbc: mov             SP, fp
    //     0xb2ebc0: ldp             fp, lr, [SP], #0x10
    // 0xb2ebc4: ret
    //     0xb2ebc4: ret             
    // 0xb2ebc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ebc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ebcc: b               #0xb2eb88
    // 0xb2ebd0: SaveReg d0
    //     0xb2ebd0: str             q0, [SP, #-0x10]!
    // 0xb2ebd4: r0 = AllocateDouble()
    //     0xb2ebd4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2ebd8: RestoreReg d0
    //     0xb2ebd8: ldr             q0, [SP], #0x10
    // 0xb2ebdc: b               #0xb2ebb8
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb52370, size: 0x2c
    // 0xb52370: EnterFrame
    //     0xb52370: stp             fp, lr, [SP, #-0x10]!
    //     0xb52374: mov             fp, SP
    // 0xb52378: CheckStackOverflow
    //     0xb52378: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5237c: cmp             SP, x16
    //     0xb52380: b.ls            #0xb52394
    // 0xb52384: r0 = _getSize()
    //     0xb52384: bl              #0xb2ba54  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::_getSize
    // 0xb52388: LeaveFrame
    //     0xb52388: mov             SP, fp
    //     0xb5238c: ldp             fp, lr, [SP], #0x10
    // 0xb52390: ret
    //     0xb52390: ret             
    // 0xb52394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb52394: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb52398: b               #0xb52384
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb586e4, size: 0x24
    // 0xb586e4: EnterFrame
    //     0xb586e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb586e8: mov             fp, SP
    // 0xb586ec: ldr             x2, [fp, #0x10]
    // 0xb586f0: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb586f0: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa29a8] AnonymousClosure: (0xb2eb68), in [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMaxIntrinsicWidth (0xb2ea90)
    //     0xb586f4: ldr             x1, [x1, #0x9a8]
    // 0xb586f8: r0 = AllocateClosure()
    //     0xb586f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb586fc: LeaveFrame
    //     0xb586fc: mov             SP, fp
    //     0xb58700: ldp             fp, lr, [SP], #0x10
    // 0xb58704: ret
    //     0xb58704: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e890, size: 0x24
    // 0xb5e890: EnterFrame
    //     0xb5e890: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e894: mov             fp, SP
    // 0xb5e898: ldr             x2, [fp, #0x10]
    // 0xb5e89c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e89c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98620] AnonymousClosure: (0xb2b9dc), in [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMaxIntrinsicHeight (0xb2b90c)
    //     0xb5e8a0: ldr             x1, [x1, #0x620]
    // 0xb5e8a4: r0 = AllocateClosure()
    //     0xb5e8a4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e8a8: LeaveFrame
    //     0xb5e8a8: mov             SP, fp
    //     0xb5e8ac: ldp             fp, lr, [SP], #0x10
    // 0xb5e8b0: ret
    //     0xb5e8b0: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbcadf8, size: 0xf4
    // 0xbcadf8: EnterFrame
    //     0xbcadf8: stp             fp, lr, [SP, #-0x10]!
    //     0xbcadfc: mov             fp, SP
    // 0xbcae00: AllocStack(0x10)
    //     0xbcae00: sub             SP, SP, #0x10
    // 0xbcae04: SetupParameters(RenderCustomMultiChildLayoutBox this /* r1 => r3, fp-0x10 */)
    //     0xbcae04: mov             x3, x1
    //     0xbcae08: stur            x1, [fp, #-0x10]
    // 0xbcae0c: CheckStackOverflow
    //     0xbcae0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcae10: cmp             SP, x16
    //     0xbcae14: b.ls            #0xbcaee4
    // 0xbcae18: LoadField: r4 = r3->field_27
    //     0xbcae18: ldur            w4, [x3, #0x27]
    // 0xbcae1c: DecompressPointer r4
    //     0xbcae1c: add             x4, x4, HEAP, lsl #32
    // 0xbcae20: stur            x4, [fp, #-8]
    // 0xbcae24: cmp             w4, NULL
    // 0xbcae28: b.eq            #0xbcaec8
    // 0xbcae2c: mov             x0, x4
    // 0xbcae30: r2 = Null
    //     0xbcae30: mov             x2, NULL
    // 0xbcae34: r1 = Null
    //     0xbcae34: mov             x1, NULL
    // 0xbcae38: r4 = LoadClassIdInstr(r0)
    //     0xbcae38: ldur            x4, [x0, #-1]
    //     0xbcae3c: ubfx            x4, x4, #0xc, #0x14
    // 0xbcae40: sub             x4, x4, #0xb46
    // 0xbcae44: cmp             x4, #1
    // 0xbcae48: b.ls            #0xbcae5c
    // 0xbcae4c: r8 = BoxConstraints
    //     0xbcae4c: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbcae50: r3 = Null
    //     0xbcae50: add             x3, PP, #0x98, lsl #12  ; [pp+0x98648] Null
    //     0xbcae54: ldr             x3, [x3, #0x648]
    // 0xbcae58: r0 = BoxConstraints()
    //     0xbcae58: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbcae5c: ldur            x1, [fp, #-0x10]
    // 0xbcae60: ldur            x2, [fp, #-8]
    // 0xbcae64: r0 = _getSize()
    //     0xbcae64: bl              #0xb2ba54  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::_getSize
    // 0xbcae68: ldur            x2, [fp, #-0x10]
    // 0xbcae6c: StoreField: r2->field_4b = r0
    //     0xbcae6c: stur            w0, [x2, #0x4b]
    //     0xbcae70: ldurb           w16, [x2, #-1]
    //     0xbcae74: ldurb           w17, [x0, #-1]
    //     0xbcae78: and             x16, x17, x16, lsr #2
    //     0xbcae7c: tst             x16, HEAP, lsr #32
    //     0xbcae80: b.eq            #0xbcae88
    //     0xbcae84: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbcae88: LoadField: r0 = r2->field_5f
    //     0xbcae88: ldur            w0, [x2, #0x5f]
    // 0xbcae8c: DecompressPointer r0
    //     0xbcae8c: add             x0, x0, HEAP, lsl #32
    // 0xbcae90: mov             x1, x2
    // 0xbcae94: stur            x0, [fp, #-8]
    // 0xbcae98: r0 = size()
    //     0xbcae98: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbcae9c: mov             x1, x0
    // 0xbcaea0: ldur            x0, [fp, #-0x10]
    // 0xbcaea4: LoadField: r3 = r0->field_57
    //     0xbcaea4: ldur            w3, [x0, #0x57]
    // 0xbcaea8: DecompressPointer r3
    //     0xbcaea8: add             x3, x3, HEAP, lsl #32
    // 0xbcaeac: mov             x2, x1
    // 0xbcaeb0: ldur            x1, [fp, #-8]
    // 0xbcaeb4: r0 = _callPerformLayout()
    //     0xbcaeb4: bl              #0xbcaeec  ; [package:flutter/src/rendering/custom_layout.dart] MultiChildLayoutDelegate::_callPerformLayout
    // 0xbcaeb8: r0 = Null
    //     0xbcaeb8: mov             x0, NULL
    // 0xbcaebc: LeaveFrame
    //     0xbcaebc: mov             SP, fp
    //     0xbcaec0: ldp             fp, lr, [SP], #0x10
    // 0xbcaec4: ret
    //     0xbcaec4: ret             
    // 0xbcaec8: r0 = StateError()
    //     0xbcaec8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcaecc: mov             x1, x0
    // 0xbcaed0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcaed0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbcaed4: StoreField: r1->field_b = r0
    //     0xbcaed4: stur            w0, [x1, #0xb]
    // 0xbcaed8: mov             x0, x1
    // 0xbcaedc: r0 = Throw()
    //     0xbcaedc: bl              #0x13ddb2c  ; ThrowStub
    // 0xbcaee0: brk             #0
    // 0xbcaee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcaee4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcaee8: b               #0xbcae18
  }
  _ detach(/* No info */) {
    // ** addr: 0xc075d4, size: 0x78
    // 0xc075d4: EnterFrame
    //     0xc075d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc075d8: mov             fp, SP
    // 0xc075dc: AllocStack(0x10)
    //     0xc075dc: sub             SP, SP, #0x10
    // 0xc075e0: SetupParameters(RenderCustomMultiChildLayoutBox this /* r1 => r0, fp-0x10 */)
    //     0xc075e0: mov             x0, x1
    //     0xc075e4: stur            x1, [fp, #-0x10]
    // 0xc075e8: CheckStackOverflow
    //     0xc075e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc075ec: cmp             SP, x16
    //     0xc075f0: b.ls            #0xc07644
    // 0xc075f4: LoadField: r1 = r0->field_5f
    //     0xc075f4: ldur            w1, [x0, #0x5f]
    // 0xc075f8: DecompressPointer r1
    //     0xc075f8: add             x1, x1, HEAP, lsl #32
    // 0xc075fc: LoadField: r3 = r1->field_7
    //     0xc075fc: ldur            w3, [x1, #7]
    // 0xc07600: DecompressPointer r3
    //     0xc07600: add             x3, x3, HEAP, lsl #32
    // 0xc07604: stur            x3, [fp, #-8]
    // 0xc07608: cmp             w3, NULL
    // 0xc0760c: b.eq            #0xc0762c
    // 0xc07610: mov             x2, x0
    // 0xc07614: r1 = Function 'markNeedsLayout':.
    //     0xc07614: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cf38] AnonymousClosure: (0xbfb55c), in [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout (0xbfb4c8)
    //     0xc07618: ldr             x1, [x1, #0xf38]
    // 0xc0761c: r0 = AllocateClosure()
    //     0xc0761c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc07620: ldur            x1, [fp, #-8]
    // 0xc07624: mov             x2, x0
    // 0xc07628: r0 = removeListener()
    //     0xc07628: bl              #0xd00c74  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xc0762c: ldur            x1, [fp, #-0x10]
    // 0xc07630: r0 = detach()
    //     0xc07630: bl              #0xc0764c  ; [dart:mixin_deduplication] _MixinApplication424&RenderBox&ContainerRenderObjectMixin::detach
    // 0xc07634: r0 = Null
    //     0xc07634: mov             x0, NULL
    // 0xc07638: LeaveFrame
    //     0xc07638: mov             SP, fp
    //     0xc0763c: ldp             fp, lr, [SP], #0x10
    // 0xc07640: ret
    //     0xc07640: ret             
    // 0xc07644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07644: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc07648: b               #0xc075f4
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0afa0, size: 0x78
    // 0xc0afa0: EnterFrame
    //     0xc0afa0: stp             fp, lr, [SP, #-0x10]!
    //     0xc0afa4: mov             fp, SP
    // 0xc0afa8: AllocStack(0x10)
    //     0xc0afa8: sub             SP, SP, #0x10
    // 0xc0afac: SetupParameters(RenderCustomMultiChildLayoutBox this /* r1 => r0, fp-0x8 */)
    //     0xc0afac: mov             x0, x1
    //     0xc0afb0: stur            x1, [fp, #-8]
    // 0xc0afb4: CheckStackOverflow
    //     0xc0afb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0afb8: cmp             SP, x16
    //     0xc0afbc: b.ls            #0xc0b010
    // 0xc0afc0: mov             x1, x0
    // 0xc0afc4: r0 = attach()
    //     0xc0afc4: bl              #0xc0b018  ; [dart:mixin_deduplication] _MixinApplication424&RenderBox&ContainerRenderObjectMixin::attach
    // 0xc0afc8: ldur            x2, [fp, #-8]
    // 0xc0afcc: LoadField: r0 = r2->field_5f
    //     0xc0afcc: ldur            w0, [x2, #0x5f]
    // 0xc0afd0: DecompressPointer r0
    //     0xc0afd0: add             x0, x0, HEAP, lsl #32
    // 0xc0afd4: LoadField: r3 = r0->field_7
    //     0xc0afd4: ldur            w3, [x0, #7]
    // 0xc0afd8: DecompressPointer r3
    //     0xc0afd8: add             x3, x3, HEAP, lsl #32
    // 0xc0afdc: stur            x3, [fp, #-0x10]
    // 0xc0afe0: cmp             w3, NULL
    // 0xc0afe4: b.eq            #0xc0b000
    // 0xc0afe8: r1 = Function 'markNeedsLayout':.
    //     0xc0afe8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cf38] AnonymousClosure: (0xbfb55c), in [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout (0xbfb4c8)
    //     0xc0afec: ldr             x1, [x1, #0xf38]
    // 0xc0aff0: r0 = AllocateClosure()
    //     0xc0aff0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0aff4: ldur            x1, [fp, #-0x10]
    // 0xc0aff8: mov             x2, x0
    // 0xc0affc: r0 = addListener()
    //     0xc0affc: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xc0b000: r0 = Null
    //     0xc0b000: mov             x0, NULL
    // 0xc0b004: LeaveFrame
    //     0xc0b004: mov             SP, fp
    //     0xc0b008: ldp             fp, lr, [SP], #0x10
    // 0xc0b00c: ret
    //     0xc0b00c: ret             
    // 0xc0b010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0b010: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0b014: b               #0xc0afc0
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0e128, size: 0xb8
    // 0xc0e128: EnterFrame
    //     0xc0e128: stp             fp, lr, [SP, #-0x10]!
    //     0xc0e12c: mov             fp, SP
    // 0xc0e130: AllocStack(0x8)
    //     0xc0e130: sub             SP, SP, #8
    // 0xc0e134: SetupParameters(RenderCustomMultiChildLayoutBox this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0e134: mov             x0, x2
    //     0xc0e138: mov             x4, x1
    //     0xc0e13c: mov             x3, x2
    //     0xc0e140: stur            x2, [fp, #-8]
    // 0xc0e144: r2 = Null
    //     0xc0e144: mov             x2, NULL
    // 0xc0e148: r1 = Null
    //     0xc0e148: mov             x1, NULL
    // 0xc0e14c: r4 = 60
    //     0xc0e14c: mov             x4, #0x3c
    // 0xc0e150: branchIfSmi(r0, 0xc0e15c)
    //     0xc0e150: tbz             w0, #0, #0xc0e15c
    // 0xc0e154: r4 = LoadClassIdInstr(r0)
    //     0xc0e154: ldur            x4, [x0, #-1]
    //     0xc0e158: ubfx            x4, x4, #0xc, #0x14
    // 0xc0e15c: r17 = -4710
    //     0xc0e15c: mov             x17, #-0x1266
    // 0xc0e160: add             x4, x4, x17
    // 0xc0e164: cmp             x4, #0x109
    // 0xc0e168: b.ls            #0xc0e17c
    // 0xc0e16c: r8 = RenderBox
    //     0xc0e16c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xc0e170: r3 = Null
    //     0xc0e170: add             x3, PP, #0x98, lsl #12  ; [pp+0x98690] Null
    //     0xc0e174: ldr             x3, [x3, #0x690]
    // 0xc0e178: r0 = RenderBox()
    //     0xc0e178: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xc0e17c: ldur            x0, [fp, #-8]
    // 0xc0e180: LoadField: r1 = r0->field_7
    //     0xc0e180: ldur            w1, [x0, #7]
    // 0xc0e184: DecompressPointer r1
    //     0xc0e184: add             x1, x1, HEAP, lsl #32
    // 0xc0e188: r2 = LoadClassIdInstr(r1)
    //     0xc0e188: ldur            x2, [x1, #-1]
    //     0xc0e18c: ubfx            x2, x2, #0xc, #0x14
    // 0xc0e190: r17 = 4213
    //     0xc0e190: mov             x17, #0x1075
    // 0xc0e194: cmp             x2, x17
    // 0xc0e198: b.eq            #0xc0e1d0
    // 0xc0e19c: r1 = <RenderBox>
    //     0xc0e19c: add             x1, PP, #0x15, lsl #12  ; [pp+0x155c8] TypeArguments: <RenderBox>
    //     0xc0e1a0: ldr             x1, [x1, #0x5c8]
    // 0xc0e1a4: r0 = MultiChildLayoutParentData()
    //     0xc0e1a4: bl              #0xc0e1e0  ; AllocateMultiChildLayoutParentDataStub -> MultiChildLayoutParentData (size=0x1c)
    // 0xc0e1a8: r1 = Instance_Offset
    //     0xc0e1a8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0e1ac: StoreField: r0->field_7 = r1
    //     0xc0e1ac: stur            w1, [x0, #7]
    // 0xc0e1b0: ldur            x1, [fp, #-8]
    // 0xc0e1b4: StoreField: r1->field_7 = r0
    //     0xc0e1b4: stur            w0, [x1, #7]
    //     0xc0e1b8: ldurb           w16, [x1, #-1]
    //     0xc0e1bc: ldurb           w17, [x0, #-1]
    //     0xc0e1c0: and             x16, x17, x16, lsr #2
    //     0xc0e1c4: tst             x16, HEAP, lsr #32
    //     0xc0e1c8: b.eq            #0xc0e1d0
    //     0xc0e1cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0e1d0: r0 = Null
    //     0xc0e1d0: mov             x0, NULL
    // 0xc0e1d4: LeaveFrame
    //     0xc0e1d4: mov             SP, fp
    //     0xc0e1d8: ldp             fp, lr, [SP], #0x10
    // 0xc0e1dc: ret
    //     0xc0e1dc: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc28310, size: 0x30
    // 0xc28310: EnterFrame
    //     0xc28310: stp             fp, lr, [SP, #-0x10]!
    //     0xc28314: mov             fp, SP
    // 0xc28318: CheckStackOverflow
    //     0xc28318: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2831c: cmp             SP, x16
    //     0xc28320: b.ls            #0xc28338
    // 0xc28324: r0 = defaultPaint()
    //     0xc28324: bl              #0xc28340  ; [dart:mixin_deduplication] _MixinApplication425&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultPaint
    // 0xc28328: r0 = Null
    //     0xc28328: mov             x0, NULL
    // 0xc2832c: LeaveFrame
    //     0xc2832c: mov             SP, fp
    //     0xc28330: ldp             fp, lr, [SP], #0x10
    // 0xc28334: ret
    //     0xc28334: ret             
    // 0xc28338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc28338: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2833c: b               #0xc28324
  }
  set _ delegate=(/* No info */) {
    // ** addr: 0xceec50, size: 0x1d0
    // 0xceec50: EnterFrame
    //     0xceec50: stp             fp, lr, [SP, #-0x10]!
    //     0xceec54: mov             fp, SP
    // 0xceec58: AllocStack(0x30)
    //     0xceec58: sub             SP, SP, #0x30
    // 0xceec5c: SetupParameters(RenderCustomMultiChildLayoutBox this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1, fp-0x18 */)
    //     0xceec5c: mov             x0, x1
    //     0xceec60: stur            x1, [fp, #-0x10]
    //     0xceec64: mov             x1, x2
    //     0xceec68: stur            x2, [fp, #-0x18]
    // 0xceec6c: CheckStackOverflow
    //     0xceec6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xceec70: cmp             SP, x16
    //     0xceec74: b.ls            #0xceee18
    // 0xceec78: LoadField: r2 = r0->field_5f
    //     0xceec78: ldur            w2, [x0, #0x5f]
    // 0xceec7c: DecompressPointer r2
    //     0xceec7c: add             x2, x2, HEAP, lsl #32
    // 0xceec80: stur            x2, [fp, #-8]
    // 0xceec84: cmp             w2, w1
    // 0xceec88: b.ne            #0xceec9c
    // 0xceec8c: r0 = Null
    //     0xceec8c: mov             x0, NULL
    // 0xceec90: LeaveFrame
    //     0xceec90: mov             SP, fp
    //     0xceec94: ldp             fp, lr, [SP], #0x10
    // 0xceec98: ret
    //     0xceec98: ret             
    // 0xceec9c: stp             x2, x1, [SP]
    // 0xceeca0: r0 = _haveSameRuntimeType()
    //     0xceeca0: bl              #0x88249c  ; [dart:core] Object::_haveSameRuntimeType
    // 0xceeca4: tbnz            w0, #4, #0xceed64
    // 0xceeca8: ldur            x3, [fp, #-0x18]
    // 0xceecac: r0 = LoadClassIdInstr(r3)
    //     0xceecac: ldur            x0, [x3, #-1]
    //     0xceecb0: ubfx            x0, x0, #0xc, #0x14
    // 0xceecb4: cmp             x0, #0xbb0
    // 0xceecb8: b.ne            #0xceed3c
    // 0xceecbc: ldur            x4, [fp, #-8]
    // 0xceecc0: mov             x0, x4
    // 0xceecc4: r2 = Null
    //     0xceecc4: mov             x2, NULL
    // 0xceecc8: r1 = Null
    //     0xceecc8: mov             x1, NULL
    // 0xceeccc: r4 = LoadClassIdInstr(r0)
    //     0xceeccc: ldur            x4, [x0, #-1]
    //     0xceecd0: ubfx            x4, x4, #0xc, #0x14
    // 0xceecd4: cmp             x4, #0xbb0
    // 0xceecd8: b.eq            #0xceecf0
    // 0xceecdc: r8 = _ToolbarLayout
    //     0xceecdc: add             x8, PP, #0x90, lsl #12  ; [pp+0x90268] Type: _ToolbarLayout
    //     0xceece0: ldr             x8, [x8, #0x268]
    // 0xceece4: r3 = Null
    //     0xceece4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90270] Null
    //     0xceece8: ldr             x3, [x3, #0x270]
    // 0xceecec: r0 = DefaultTypeTest()
    //     0xceecec: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xceecf0: ldur            x3, [fp, #-8]
    // 0xceecf4: LoadField: r0 = r3->field_f
    //     0xceecf4: ldur            w0, [x3, #0xf]
    // 0xceecf8: DecompressPointer r0
    //     0xceecf8: add             x0, x0, HEAP, lsl #32
    // 0xceecfc: ldur            x4, [fp, #-0x18]
    // 0xceed00: LoadField: r1 = r4->field_f
    //     0xceed00: ldur            w1, [x4, #0xf]
    // 0xceed04: DecompressPointer r1
    //     0xceed04: add             x1, x1, HEAP, lsl #32
    // 0xceed08: cmp             w0, w1
    // 0xceed0c: b.ne            #0xceed64
    // 0xceed10: LoadField: d0 = r3->field_13
    //     0xceed10: ldur            d0, [x3, #0x13]
    // 0xceed14: LoadField: d1 = r4->field_13
    //     0xceed14: ldur            d1, [x4, #0x13]
    // 0xceed18: fcmp            d0, d1
    // 0xceed1c: b.ne            #0xceed64
    // 0xceed20: LoadField: r0 = r3->field_1b
    //     0xceed20: ldur            w0, [x3, #0x1b]
    // 0xceed24: DecompressPointer r0
    //     0xceed24: add             x0, x0, HEAP, lsl #32
    // 0xceed28: LoadField: r1 = r4->field_1b
    //     0xceed28: ldur            w1, [x4, #0x1b]
    // 0xceed2c: DecompressPointer r1
    //     0xceed2c: add             x1, x1, HEAP, lsl #32
    // 0xceed30: cmp             w0, w1
    // 0xceed34: b.eq            #0xceed6c
    // 0xceed38: b               #0xceed64
    // 0xceed3c: mov             x4, x3
    // 0xceed40: ldur            x3, [fp, #-8]
    // 0xceed44: r0 = LoadClassIdInstr(r4)
    //     0xceed44: ldur            x0, [x4, #-1]
    //     0xceed48: ubfx            x0, x0, #0xc, #0x14
    // 0xceed4c: mov             x1, x4
    // 0xceed50: mov             x2, x3
    // 0xceed54: r0 = GDT[cid_x0 + -0xf1a]()
    //     0xceed54: sub             lr, x0, #0xf1a
    //     0xceed58: ldr             lr, [x21, lr, lsl #3]
    //     0xceed5c: blr             lr
    // 0xceed60: tbnz            w0, #4, #0xceed6c
    // 0xceed64: ldur            x1, [fp, #-0x10]
    // 0xceed68: r0 = markNeedsLayout()
    //     0xceed68: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xceed6c: ldur            x3, [fp, #-0x10]
    // 0xceed70: ldur            x0, [fp, #-0x18]
    // 0xceed74: StoreField: r3->field_5f = r0
    //     0xceed74: stur            w0, [x3, #0x5f]
    //     0xceed78: ldurb           w16, [x3, #-1]
    //     0xceed7c: ldurb           w17, [x0, #-1]
    //     0xceed80: and             x16, x17, x16, lsr #2
    //     0xceed84: tst             x16, HEAP, lsr #32
    //     0xceed88: b.eq            #0xceed90
    //     0xceed8c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xceed90: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xceed90: ldur            w0, [x3, #0x17]
    // 0xceed94: DecompressPointer r0
    //     0xceed94: add             x0, x0, HEAP, lsl #32
    // 0xceed98: cmp             w0, NULL
    // 0xceed9c: b.eq            #0xceee08
    // 0xceeda0: ldur            x0, [fp, #-8]
    // 0xceeda4: LoadField: r4 = r0->field_7
    //     0xceeda4: ldur            w4, [x0, #7]
    // 0xceeda8: DecompressPointer r4
    //     0xceeda8: add             x4, x4, HEAP, lsl #32
    // 0xceedac: stur            x4, [fp, #-0x20]
    // 0xceedb0: cmp             w4, NULL
    // 0xceedb4: b.eq            #0xceedd4
    // 0xceedb8: mov             x2, x3
    // 0xceedbc: r1 = Function 'markNeedsLayout':.
    //     0xceedbc: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cf38] AnonymousClosure: (0xbfb55c), in [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout (0xbfb4c8)
    //     0xceedc0: ldr             x1, [x1, #0xf38]
    // 0xceedc4: r0 = AllocateClosure()
    //     0xceedc4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xceedc8: ldur            x1, [fp, #-0x20]
    // 0xceedcc: mov             x2, x0
    // 0xceedd0: r0 = removeListener()
    //     0xceedd0: bl              #0xd00c74  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xceedd4: ldur            x0, [fp, #-0x18]
    // 0xceedd8: LoadField: r3 = r0->field_7
    //     0xceedd8: ldur            w3, [x0, #7]
    // 0xceeddc: DecompressPointer r3
    //     0xceeddc: add             x3, x3, HEAP, lsl #32
    // 0xceede0: stur            x3, [fp, #-8]
    // 0xceede4: cmp             w3, NULL
    // 0xceede8: b.eq            #0xceee08
    // 0xceedec: ldur            x2, [fp, #-0x10]
    // 0xceedf0: r1 = Function 'markNeedsLayout':.
    //     0xceedf0: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cf38] AnonymousClosure: (0xbfb55c), in [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout (0xbfb4c8)
    //     0xceedf4: ldr             x1, [x1, #0xf38]
    // 0xceedf8: r0 = AllocateClosure()
    //     0xceedf8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xceedfc: ldur            x1, [fp, #-8]
    // 0xceee00: mov             x2, x0
    // 0xceee04: r0 = addListener()
    //     0xceee04: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0xceee08: r0 = Null
    //     0xceee08: mov             x0, NULL
    // 0xceee0c: LeaveFrame
    //     0xceee0c: mov             SP, fp
    //     0xceee10: ldp             fp, lr, [SP], #0x10
    // 0xceee14: ret
    //     0xceee14: ret             
    // 0xceee18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceee18: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceee1c: b               #0xceec78
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ec078, size: 0x2c
    // 0x10ec078: EnterFrame
    //     0x10ec078: stp             fp, lr, [SP, #-0x10]!
    //     0x10ec07c: mov             fp, SP
    // 0x10ec080: CheckStackOverflow
    //     0x10ec080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ec084: cmp             SP, x16
    //     0x10ec088: b.ls            #0x10ec09c
    // 0x10ec08c: r0 = defaultHitTestChildren()
    //     0x10ec08c: bl              #0x10ec0a4  ; [dart:mixin_deduplication] _MixinApplication425&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin::defaultHitTestChildren
    // 0x10ec090: LeaveFrame
    //     0x10ec090: mov             SP, fp
    //     0x10ec094: ldp             fp, lr, [SP], #0x10
    // 0x10ec098: ret
    //     0x10ec098: ret             
    // 0x10ec09c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ec09c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ec0a0: b               #0x10ec08c
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f018c, size: 0x24
    // 0x10f018c: EnterFrame
    //     0x10f018c: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0190: mov             fp, SP
    // 0x10f0194: ldr             x2, [fp, #0x10]
    // 0x10f0198: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0198: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa29a0] AnonymousClosure: (0x10f01b0), in [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMaxIntrinsicHeight (0xb2b90c)
    //     0x10f019c: ldr             x1, [x1, #0x9a0]
    // 0x10f01a0: r0 = AllocateClosure()
    //     0x10f01a0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f01a4: LeaveFrame
    //     0x10f01a4: mov             SP, fp
    //     0x10f01a8: ldp             fp, lr, [SP], #0x10
    // 0x10f01ac: ret
    //     0x10f01ac: ret             
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x10f01b0, size: 0x78
    // 0x10f01b0: EnterFrame
    //     0x10f01b0: stp             fp, lr, [SP, #-0x10]!
    //     0x10f01b4: mov             fp, SP
    // 0x10f01b8: ldr             x0, [fp, #0x18]
    // 0x10f01bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10f01bc: ldur            w1, [x0, #0x17]
    // 0x10f01c0: DecompressPointer r1
    //     0x10f01c0: add             x1, x1, HEAP, lsl #32
    // 0x10f01c4: CheckStackOverflow
    //     0x10f01c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f01c8: cmp             SP, x16
    //     0x10f01cc: b.ls            #0x10f0210
    // 0x10f01d0: ldr             x2, [fp, #0x10]
    // 0x10f01d4: r0 = computeMaxIntrinsicHeight()
    //     0x10f01d4: bl              #0xb2b90c  ; [package:flutter/src/rendering/custom_layout.dart] RenderCustomMultiChildLayoutBox::computeMaxIntrinsicHeight
    // 0x10f01d8: r0 = inline_Allocate_Double()
    //     0x10f01d8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x10f01dc: add             x0, x0, #0x10
    //     0x10f01e0: cmp             x1, x0
    //     0x10f01e4: b.ls            #0x10f0218
    //     0x10f01e8: str             x0, [THR, #0x60]  ; THR::top
    //     0x10f01ec: sub             x0, x0, #0xf
    //     0x10f01f0: mov             x1, #0xe19c
    //     0x10f01f4: movk            x1, #3, lsl #16
    //     0x10f01f8: stur            x1, [x0, #-1]
    // 0x10f01fc: dmb             ishst
    // 0x10f0200: StoreField: r0->field_7 = d0
    //     0x10f0200: stur            d0, [x0, #7]
    // 0x10f0204: LeaveFrame
    //     0x10f0204: mov             SP, fp
    //     0x10f0208: ldp             fp, lr, [SP], #0x10
    // 0x10f020c: ret
    //     0x10f020c: ret             
    // 0x10f0210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f0210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f0214: b               #0x10f01d0
    // 0x10f0218: SaveReg d0
    //     0x10f0218: str             q0, [SP, #-0x10]!
    // 0x10f021c: r0 = AllocateDouble()
    //     0x10f021c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10f0220: RestoreReg d0
    //     0x10f0220: ldr             q0, [SP], #0x10
    // 0x10f0224: b               #0x10f0200
  }
}
