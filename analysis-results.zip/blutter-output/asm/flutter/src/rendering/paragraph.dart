// lib: , url: package:flutter/src/rendering/paragraph.dart

// class id: 1049035, size: 0x8
class :: {
}

// class id: 2859, size: 0x14, field offset: 0xc
//   const constructor, 
class PlaceholderSpanIndexSemanticsTag extends SemanticsTag {

  get _ hashCode(/* No info */) {
    // ** addr: 0x114cae0, size: 0x70
    // 0x114cae0: EnterFrame
    //     0x114cae0: stp             fp, lr, [SP, #-0x10]!
    //     0x114cae4: mov             fp, SP
    // 0x114cae8: CheckStackOverflow
    //     0x114cae8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x114caec: cmp             SP, x16
    //     0x114caf0: b.ls            #0x114cb48
    // 0x114caf4: ldr             x0, [fp, #0x10]
    // 0x114caf8: LoadField: r2 = r0->field_b
    //     0x114caf8: ldur            x2, [x0, #0xb]
    // 0x114cafc: r0 = BoxInt64Instr(r2)
    //     0x114cafc: sbfiz           x0, x2, #1, #0x1f
    //     0x114cb00: cmp             x2, x0, asr #1
    //     0x114cb04: b.eq            #0x114cb10
    //     0x114cb08: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114cb0c: stur            x2, [x0, #7]
    // 0x114cb10: mov             x2, x0
    // 0x114cb14: r1 = PlaceholderSpanIndexSemanticsTag
    //     0x114cb14: add             x1, PP, #0x8e, lsl #12  ; [pp+0x8ee90] Type: PlaceholderSpanIndexSemanticsTag
    //     0x114cb18: ldr             x1, [x1, #0xe90]
    // 0x114cb1c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x114cb1c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x114cb20: r0 = hash()
    //     0x114cb20: bl              #0x8859e8  ; [dart:core] Object::hash
    // 0x114cb24: mov             x2, x0
    // 0x114cb28: r0 = BoxInt64Instr(r2)
    //     0x114cb28: sbfiz           x0, x2, #1, #0x1f
    //     0x114cb2c: cmp             x2, x0, asr #1
    //     0x114cb30: b.eq            #0x114cb3c
    //     0x114cb34: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x114cb38: stur            x2, [x0, #7]
    // 0x114cb3c: LeaveFrame
    //     0x114cb3c: mov             SP, fp
    //     0x114cb40: ldp             fp, lr, [SP], #0x10
    // 0x114cb44: ret
    //     0x114cb44: ret             
    // 0x114cb48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x114cb48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x114cb4c: b               #0x114caf4
  }
  _ ==(/* No info */) {
    // ** addr: 0x129a228, size: 0x58
    // 0x129a228: ldr             x1, [SP]
    // 0x129a22c: cmp             w1, NULL
    // 0x129a230: b.ne            #0x129a23c
    // 0x129a234: r0 = false
    //     0x129a234: add             x0, NULL, #0x30  ; false
    // 0x129a238: ret
    //     0x129a238: ret             
    // 0x129a23c: r2 = 60
    //     0x129a23c: mov             x2, #0x3c
    // 0x129a240: branchIfSmi(r1, 0x129a24c)
    //     0x129a240: tbz             w1, #0, #0x129a24c
    // 0x129a244: r2 = LoadClassIdInstr(r1)
    //     0x129a244: ldur            x2, [x1, #-1]
    //     0x129a248: ubfx            x2, x2, #0xc, #0x14
    // 0x129a24c: cmp             x2, #0xb2b
    // 0x129a250: b.ne            #0x129a278
    // 0x129a254: ldr             x2, [SP, #8]
    // 0x129a258: LoadField: r3 = r1->field_b
    //     0x129a258: ldur            x3, [x1, #0xb]
    // 0x129a25c: LoadField: r1 = r2->field_b
    //     0x129a25c: ldur            x1, [x2, #0xb]
    // 0x129a260: cmp             x3, x1
    // 0x129a264: r16 = true
    //     0x129a264: add             x16, NULL, #0x20  ; true
    // 0x129a268: r17 = false
    //     0x129a268: add             x17, NULL, #0x30  ; false
    // 0x129a26c: csel            x2, x16, x17, eq
    // 0x129a270: mov             x0, x2
    // 0x129a274: b               #0x129a27c
    // 0x129a278: r0 = false
    //     0x129a278: add             x0, NULL, #0x30  ; false
    // 0x129a27c: ret
    //     0x129a27c: ret             
  }
}

// class id: 2899, size: 0x8, field offset: 0x8
//   const constructor, 
class _UnspecifiedTextScaler extends TextScaler {
}

// class id: 4188, size: 0x18, field offset: 0x10
class TextParentData extends _MixinApplication433&ParentData&ContainerParentDataMixin {

  _ detach(/* No info */) {
    // ** addr: 0x10ef838, size: 0x10
    // 0x10ef838: StoreField: r1->field_13 = rNULL
    //     0x10ef838: stur            NULL, [x1, #0x13]
    // 0x10ef83c: StoreField: r1->field_f = rNULL
    //     0x10ef83c: stur            NULL, [x1, #0xf]
    // 0x10ef840: r0 = Null
    //     0x10ef840: mov             x0, NULL
    // 0x10ef844: ret
    //     0x10ef844: ret             
  }
}

// class id: 4219, size: 0x8, field offset: 0x8
abstract class RenderInlineChildrenContainerDefaults extends _MixinApplication427&RenderBox&ContainerRenderObjectMixin {

  static _ _layoutChild(/* No info */) {
    // ** addr: 0xb1d660, size: 0x1f4
    // 0xb1d660: EnterFrame
    //     0xb1d660: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d664: mov             fp, SP
    // 0xb1d668: AllocStack(0x58)
    //     0xb1d668: sub             SP, SP, #0x58
    // 0xb1d66c: SetupParameters(dynamic _ /* r1 => r6, fp-0x10 */, dynamic _ /* r2 => r5, fp-0x18 */, dynamic _ /* r3 => r4, fp-0x20 */, dynamic _ /* r5 => r3, fp-0x28 */)
    //     0xb1d66c: mov             x6, x1
    //     0xb1d670: mov             x4, x3
    //     0xb1d674: stur            x3, [fp, #-0x20]
    //     0xb1d678: mov             x3, x5
    //     0xb1d67c: stur            x5, [fp, #-0x28]
    //     0xb1d680: mov             x5, x2
    //     0xb1d684: stur            x1, [fp, #-0x10]
    //     0xb1d688: stur            x2, [fp, #-0x18]
    // 0xb1d68c: CheckStackOverflow
    //     0xb1d68c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1d690: cmp             SP, x16
    //     0xb1d694: b.ls            #0xb1d844
    // 0xb1d698: LoadField: r7 = r6->field_7
    //     0xb1d698: ldur            w7, [x6, #7]
    // 0xb1d69c: DecompressPointer r7
    //     0xb1d69c: add             x7, x7, HEAP, lsl #32
    // 0xb1d6a0: stur            x7, [fp, #-8]
    // 0xb1d6a4: cmp             w7, NULL
    // 0xb1d6a8: b.eq            #0xb1d84c
    // 0xb1d6ac: mov             x0, x7
    // 0xb1d6b0: r2 = Null
    //     0xb1d6b0: mov             x2, NULL
    // 0xb1d6b4: r1 = Null
    //     0xb1d6b4: mov             x1, NULL
    // 0xb1d6b8: r4 = LoadClassIdInstr(r0)
    //     0xb1d6b8: ldur            x4, [x0, #-1]
    //     0xb1d6bc: ubfx            x4, x4, #0xc, #0x14
    // 0xb1d6c0: r17 = 4188
    //     0xb1d6c0: mov             x17, #0x105c
    // 0xb1d6c4: cmp             x4, x17
    // 0xb1d6c8: b.eq            #0xb1d6e0
    // 0xb1d6cc: r8 = TextParentData
    //     0xb1d6cc: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cee0] Type: TextParentData
    //     0xb1d6d0: ldr             x8, [x8, #0xee0]
    // 0xb1d6d4: r3 = Null
    //     0xb1d6d4: add             x3, PP, #0x98, lsl #12  ; [pp+0x98828] Null
    //     0xb1d6d8: ldr             x3, [x3, #0x828]
    // 0xb1d6dc: r0 = DefaultTypeTest()
    //     0xb1d6dc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xb1d6e0: ldur            x0, [fp, #-8]
    // 0xb1d6e4: LoadField: r1 = r0->field_13
    //     0xb1d6e4: ldur            w1, [x0, #0x13]
    // 0xb1d6e8: DecompressPointer r1
    //     0xb1d6e8: add             x1, x1, HEAP, lsl #32
    // 0xb1d6ec: stur            x1, [fp, #-0x30]
    // 0xb1d6f0: cmp             w1, NULL
    // 0xb1d6f4: b.ne            #0xb1d704
    // 0xb1d6f8: r0 = Instance_PlaceholderDimensions
    //     0xb1d6f8: add             x0, PP, #0x98, lsl #12  ; [pp+0x98838] Obj!PlaceholderDimensions@129c681
    //     0xb1d6fc: ldr             x0, [x0, #0x838]
    // 0xb1d700: b               #0xb1d838
    // 0xb1d704: ldur            x16, [fp, #-0x20]
    // 0xb1d708: ldur            lr, [fp, #-0x10]
    // 0xb1d70c: stp             lr, x16, [SP, #8]
    // 0xb1d710: ldur            x16, [fp, #-0x18]
    // 0xb1d714: str             x16, [SP]
    // 0xb1d718: ldur            x0, [fp, #-0x20]
    // 0xb1d71c: ClosureCall
    //     0xb1d71c: ldr             x4, [PP, #0x458]  ; [pp+0x458] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb1d720: ldur            x2, [x0, #0x1f]
    //     0xb1d724: blr             x2
    // 0xb1d728: mov             x1, x0
    // 0xb1d72c: ldur            x0, [fp, #-0x30]
    // 0xb1d730: stur            x1, [fp, #-0x38]
    // 0xb1d734: LoadField: r2 = r0->field_b
    //     0xb1d734: ldur            w2, [x0, #0xb]
    // 0xb1d738: DecompressPointer r2
    //     0xb1d738: add             x2, x2, HEAP, lsl #32
    // 0xb1d73c: stur            x2, [fp, #-0x20]
    // 0xb1d740: LoadField: r3 = r0->field_f
    //     0xb1d740: ldur            w3, [x0, #0xf]
    // 0xb1d744: DecompressPointer r3
    //     0xb1d744: add             x3, x3, HEAP, lsl #32
    // 0xb1d748: stur            x3, [fp, #-8]
    // 0xb1d74c: r16 = Instance_PlaceholderAlignment
    //     0xb1d74c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98840] Obj!PlaceholderAlignment@12c7221
    //     0xb1d750: ldr             x16, [x16, #0x840]
    // 0xb1d754: cmp             w2, w16
    // 0xb1d758: b.eq            #0xb1d79c
    // 0xb1d75c: r16 = Instance_PlaceholderAlignment
    //     0xb1d75c: add             x16, PP, #0x98, lsl #12  ; [pp+0x98848] Obj!PlaceholderAlignment@12c7201
    //     0xb1d760: ldr             x16, [x16, #0x848]
    // 0xb1d764: cmp             w2, w16
    // 0xb1d768: b.eq            #0xb1d79c
    // 0xb1d76c: r16 = Instance_PlaceholderAlignment
    //     0xb1d76c: add             x16, PP, #0x88, lsl #12  ; [pp+0x88f38] Obj!PlaceholderAlignment@12c72a1
    //     0xb1d770: ldr             x16, [x16, #0xf38]
    // 0xb1d774: cmp             w2, w16
    // 0xb1d778: b.eq            #0xb1d79c
    // 0xb1d77c: r16 = Instance_PlaceholderAlignment
    //     0xb1d77c: add             x16, PP, #0x89, lsl #12  ; [pp+0x89f60] Obj!PlaceholderAlignment@12c7281
    //     0xb1d780: ldr             x16, [x16, #0xf60]
    // 0xb1d784: cmp             w2, w16
    // 0xb1d788: b.eq            #0xb1d79c
    // 0xb1d78c: r16 = Instance_PlaceholderAlignment
    //     0xb1d78c: add             x16, PP, #0x89, lsl #12  ; [pp+0x89f58] Obj!PlaceholderAlignment@12c7261
    //     0xb1d790: ldr             x16, [x16, #0xf58]
    // 0xb1d794: cmp             w2, w16
    // 0xb1d798: b.ne            #0xb1d7b0
    // 0xb1d79c: mov             x0, x1
    // 0xb1d7a0: mov             x1, x2
    // 0xb1d7a4: mov             x2, x3
    // 0xb1d7a8: r3 = Null
    //     0xb1d7a8: mov             x3, NULL
    // 0xb1d7ac: b               #0xb1d810
    // 0xb1d7b0: r16 = Instance_PlaceholderAlignment
    //     0xb1d7b0: add             x16, PP, #0x89, lsl #12  ; [pp+0x89368] Obj!PlaceholderAlignment@12c7241
    //     0xb1d7b4: ldr             x16, [x16, #0x368]
    // 0xb1d7b8: cmp             w2, w16
    // 0xb1d7bc: b.ne            #0xb1d800
    // 0xb1d7c0: cmp             w3, NULL
    // 0xb1d7c4: b.eq            #0xb1d850
    // 0xb1d7c8: ldur            x16, [fp, #-0x28]
    // 0xb1d7cc: ldur            lr, [fp, #-0x10]
    // 0xb1d7d0: stp             lr, x16, [SP, #0x10]
    // 0xb1d7d4: ldur            x16, [fp, #-0x18]
    // 0xb1d7d8: stp             x3, x16, [SP]
    // 0xb1d7dc: ldur            x0, [fp, #-0x28]
    // 0xb1d7e0: ClosureCall
    //     0xb1d7e0: ldr             x4, [PP, #0x9d0]  ; [pp+0x9d0] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xb1d7e4: ldur            x2, [x0, #0x1f]
    //     0xb1d7e8: blr             x2
    // 0xb1d7ec: mov             x3, x0
    // 0xb1d7f0: ldur            x0, [fp, #-0x38]
    // 0xb1d7f4: ldur            x1, [fp, #-0x20]
    // 0xb1d7f8: ldur            x2, [fp, #-8]
    // 0xb1d7fc: b               #0xb1d810
    // 0xb1d800: ldur            x0, [fp, #-0x38]
    // 0xb1d804: ldur            x1, [fp, #-0x20]
    // 0xb1d808: ldur            x2, [fp, #-8]
    // 0xb1d80c: r3 = Null
    //     0xb1d80c: mov             x3, NULL
    // 0xb1d810: stur            x3, [fp, #-0x10]
    // 0xb1d814: r0 = PlaceholderDimensions()
    //     0xb1d814: bl              #0xb1d854  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0xb1d818: ldur            x1, [fp, #-0x38]
    // 0xb1d81c: StoreField: r0->field_7 = r1
    //     0xb1d81c: stur            w1, [x0, #7]
    // 0xb1d820: ldur            x1, [fp, #-0x20]
    // 0xb1d824: StoreField: r0->field_b = r1
    //     0xb1d824: stur            w1, [x0, #0xb]
    // 0xb1d828: ldur            x1, [fp, #-8]
    // 0xb1d82c: StoreField: r0->field_13 = r1
    //     0xb1d82c: stur            w1, [x0, #0x13]
    // 0xb1d830: ldur            x1, [fp, #-0x10]
    // 0xb1d834: StoreField: r0->field_f = r1
    //     0xb1d834: stur            w1, [x0, #0xf]
    // 0xb1d838: LeaveFrame
    //     0xb1d838: mov             SP, fp
    //     0xb1d83c: ldp             fp, lr, [SP], #0x10
    // 0xb1d840: ret
    //     0xb1d840: ret             
    // 0xb1d844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d844: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d848: b               #0xb1d698
    // 0xb1d84c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1d84c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb1d850: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1d850: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4814, size: 0x9c, field offset: 0x64
class RenderParagraph extends _MixinApplication436&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults&RelayoutWhenSystemFontsChangeMixin {

  [closure] Size <anonymous closure>(dynamic, RenderBox, BoxConstraints) {
    // ** addr: 0xb1d860, size: 0x4c
    // 0xb1d860: EnterFrame
    //     0xb1d860: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d864: mov             fp, SP
    // 0xb1d868: AllocStack(0x8)
    //     0xb1d868: sub             SP, SP, #8
    // 0xb1d86c: CheckStackOverflow
    //     0xb1d86c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1d870: cmp             SP, x16
    //     0xb1d874: b.ls            #0xb1d8a4
    // 0xb1d878: ldr             x1, [fp, #0x18]
    // 0xb1d87c: d0 = inf
    //     0xb1d87c: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb1d880: r0 = getMinIntrinsicWidth()
    //     0xb1d880: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb1d884: stur            d0, [fp, #-8]
    // 0xb1d888: r0 = Size()
    //     0xb1d888: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb1d88c: ldur            d0, [fp, #-8]
    // 0xb1d890: StoreField: r0->field_7 = d0
    //     0xb1d890: stur            d0, [x0, #7]
    // 0xb1d894: StoreField: r0->field_f = rZR
    //     0xb1d894: stur            xzr, [x0, #0xf]
    // 0xb1d898: LeaveFrame
    //     0xb1d898: mov             SP, fp
    //     0xb1d89c: ldp             fp, lr, [SP], #0x10
    // 0xb1d8a0: ret
    //     0xb1d8a0: ret             
    // 0xb1d8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d8a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d8a8: b               #0xb1d878
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb1d8ac, size: 0x8c
    // 0xb1d8ac: EnterFrame
    //     0xb1d8ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d8b0: mov             fp, SP
    // 0xb1d8b4: AllocStack(0x8)
    //     0xb1d8b4: sub             SP, SP, #8
    // 0xb1d8b8: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */)
    //     0xb1d8b8: mov             x0, x1
    //     0xb1d8bc: stur            x1, [fp, #-8]
    // 0xb1d8c0: CheckStackOverflow
    //     0xb1d8c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1d8c4: cmp             SP, x16
    //     0xb1d8c8: b.ls            #0xb1d930
    // 0xb1d8cc: r1 = Function '<anonymous closure>':.
    //     0xb1d8cc: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2dd0] AnonymousClosure: (0xb1d860), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMinIntrinsicWidth (0xb1d8ac)
    //     0xb1d8d0: ldr             x1, [x1, #0xdd0]
    // 0xb1d8d4: r2 = Null
    //     0xb1d8d4: mov             x2, NULL
    // 0xb1d8d8: r0 = AllocateClosure()
    //     0xb1d8d8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1d8dc: ldur            x1, [fp, #-8]
    // 0xb1d8e0: mov             x2, x0
    // 0xb1d8e4: d0 = inf
    //     0xb1d8e4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb1d8e8: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb1d8e8: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb1d8ec: ldr             x3, [x3, #0x860]
    // 0xb1d8f0: r0 = layoutInlineChildren()
    //     0xb1d8f0: bl              #0xb1db30  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb1d8f4: ldur            x1, [fp, #-8]
    // 0xb1d8f8: stur            x0, [fp, #-8]
    // 0xb1d8fc: r0 = _textIntrinsics()
    //     0xb1d8fc: bl              #0xb1d938  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_textIntrinsics
    // 0xb1d900: mov             x1, x0
    // 0xb1d904: ldur            x2, [fp, #-8]
    // 0xb1d908: stur            x0, [fp, #-8]
    // 0xb1d90c: r0 = setPlaceholderDimensions()
    //     0xb1d90c: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb1d910: ldur            x1, [fp, #-8]
    // 0xb1d914: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb1d914: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb1d918: r0 = layout()
    //     0xb1d918: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb1d91c: ldur            x1, [fp, #-8]
    // 0xb1d920: r0 = minIntrinsicWidth()
    //     0xb1d920: bl              #0xb1c858  ; [package:flutter/src/painting/text_painter.dart] TextPainter::minIntrinsicWidth
    // 0xb1d924: LeaveFrame
    //     0xb1d924: mov             SP, fp
    //     0xb1d928: ldp             fp, lr, [SP], #0x10
    // 0xb1d92c: ret
    //     0xb1d92c: ret             
    // 0xb1d930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d930: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d934: b               #0xb1d8cc
  }
  get _ _textIntrinsics(/* No info */) {
    // ** addr: 0xb1d938, size: 0x1f8
    // 0xb1d938: EnterFrame
    //     0xb1d938: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d93c: mov             fp, SP
    // 0xb1d940: AllocStack(0x18)
    //     0xb1d940: sub             SP, SP, #0x18
    // 0xb1d944: SetupParameters(RenderParagraph this /* r1 => r1, fp-0x8 */)
    //     0xb1d944: stur            x1, [fp, #-8]
    // 0xb1d948: CheckStackOverflow
    //     0xb1d948: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1d94c: cmp             SP, x16
    //     0xb1d950: b.ls            #0xb1db28
    // 0xb1d954: LoadField: r0 = r1->field_67
    //     0xb1d954: ldur            w0, [x1, #0x67]
    // 0xb1d958: DecompressPointer r0
    //     0xb1d958: add             x0, x0, HEAP, lsl #32
    // 0xb1d95c: cmp             w0, NULL
    // 0xb1d960: b.ne            #0xb1d9a0
    // 0xb1d964: r0 = TextPainter()
    //     0xb1d964: bl              #0xb13a1c  ; AllocateTextPainterStub -> TextPainter (size=0x48)
    // 0xb1d968: mov             x1, x0
    // 0xb1d96c: stur            x0, [fp, #-0x10]
    // 0xb1d970: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb1d970: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb1d974: r0 = TextPainter()
    //     0xb1d974: bl              #0xb135d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::TextPainter
    // 0xb1d978: ldur            x0, [fp, #-0x10]
    // 0xb1d97c: ldur            x1, [fp, #-8]
    // 0xb1d980: StoreField: r1->field_67 = r0
    //     0xb1d980: stur            w0, [x1, #0x67]
    //     0xb1d984: ldurb           w16, [x1, #-1]
    //     0xb1d988: ldurb           w17, [x0, #-1]
    //     0xb1d98c: and             x16, x17, x16, lsr #2
    //     0xb1d990: tst             x16, HEAP, lsr #32
    //     0xb1d994: b.eq            #0xb1d99c
    //     0xb1d998: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb1d99c: ldur            x0, [fp, #-0x10]
    // 0xb1d9a0: stur            x0, [fp, #-0x18]
    // 0xb1d9a4: LoadField: r3 = r1->field_63
    //     0xb1d9a4: ldur            w3, [x1, #0x63]
    // 0xb1d9a8: DecompressPointer r3
    //     0xb1d9a8: add             x3, x3, HEAP, lsl #32
    // 0xb1d9ac: stur            x3, [fp, #-0x10]
    // 0xb1d9b0: LoadField: r2 = r3->field_f
    //     0xb1d9b0: ldur            w2, [x3, #0xf]
    // 0xb1d9b4: DecompressPointer r2
    //     0xb1d9b4: add             x2, x2, HEAP, lsl #32
    // 0xb1d9b8: mov             x1, x0
    // 0xb1d9bc: r0 = text=()
    //     0xb1d9bc: bl              #0xb1d2b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0xb1d9c0: ldur            x2, [fp, #-0x10]
    // 0xb1d9c4: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xb1d9c4: ldur            w0, [x2, #0x17]
    // 0xb1d9c8: DecompressPointer r0
    //     0xb1d9c8: add             x0, x0, HEAP, lsl #32
    // 0xb1d9cc: ldur            x3, [fp, #-0x18]
    // 0xb1d9d0: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xb1d9d0: ldur            w1, [x3, #0x17]
    // 0xb1d9d4: DecompressPointer r1
    //     0xb1d9d4: add             x1, x1, HEAP, lsl #32
    // 0xb1d9d8: cmp             w1, w0
    // 0xb1d9dc: b.ne            #0xb1d9e8
    // 0xb1d9e0: mov             x0, x2
    // 0xb1d9e4: b               #0xb1da14
    // 0xb1d9e8: ArrayStore: r3[0] = r0  ; List_4
    //     0xb1d9e8: stur            w0, [x3, #0x17]
    //     0xb1d9ec: ldurb           w16, [x3, #-1]
    //     0xb1d9f0: ldurb           w17, [x0, #-1]
    //     0xb1d9f4: and             x16, x17, x16, lsr #2
    //     0xb1d9f8: tst             x16, HEAP, lsr #32
    //     0xb1d9fc: b.eq            #0xb1da04
    //     0xb1da00: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb1da04: mov             x1, x3
    // 0xb1da08: r0 = markNeedsLayout()
    //     0xb1da08: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1da0c: ldur            x3, [fp, #-0x18]
    // 0xb1da10: ldur            x0, [fp, #-0x10]
    // 0xb1da14: LoadField: r2 = r0->field_1b
    //     0xb1da14: ldur            w2, [x0, #0x1b]
    // 0xb1da18: DecompressPointer r2
    //     0xb1da18: add             x2, x2, HEAP, lsl #32
    // 0xb1da1c: mov             x1, x3
    // 0xb1da20: r0 = textDirection=()
    //     0xb1da20: bl              #0xb1d1c8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textDirection=
    // 0xb1da24: ldur            x0, [fp, #-0x10]
    // 0xb1da28: LoadField: r2 = r0->field_1f
    //     0xb1da28: ldur            w2, [x0, #0x1f]
    // 0xb1da2c: DecompressPointer r2
    //     0xb1da2c: add             x2, x2, HEAP, lsl #32
    // 0xb1da30: ldur            x1, [fp, #-0x18]
    // 0xb1da34: r0 = textScaler=()
    //     0xb1da34: bl              #0xb1d0b0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textScaler=
    // 0xb1da38: ldur            x2, [fp, #-0x10]
    // 0xb1da3c: LoadField: r0 = r2->field_2b
    //     0xb1da3c: ldur            w0, [x2, #0x2b]
    // 0xb1da40: DecompressPointer r0
    //     0xb1da40: add             x0, x0, HEAP, lsl #32
    // 0xb1da44: ldur            x3, [fp, #-0x18]
    // 0xb1da48: LoadField: r1 = r3->field_2b
    //     0xb1da48: ldur            w1, [x3, #0x2b]
    // 0xb1da4c: DecompressPointer r1
    //     0xb1da4c: add             x1, x1, HEAP, lsl #32
    // 0xb1da50: cmp             w1, w0
    // 0xb1da54: b.eq            #0xb1da90
    // 0xb1da58: and             w16, w1, w0
    // 0xb1da5c: branchIfSmi(r16, 0xb1da98)
    //     0xb1da5c: tbz             w16, #0, #0xb1da98
    // 0xb1da60: r16 = LoadClassIdInstr(r1)
    //     0xb1da60: ldur            x16, [x1, #-1]
    //     0xb1da64: ubfx            x16, x16, #0xc, #0x14
    // 0xb1da68: cmp             x16, #0x3d
    // 0xb1da6c: b.ne            #0xb1da98
    // 0xb1da70: r16 = LoadClassIdInstr(r0)
    //     0xb1da70: ldur            x16, [x0, #-1]
    //     0xb1da74: ubfx            x16, x16, #0xc, #0x14
    // 0xb1da78: cmp             x16, #0x3d
    // 0xb1da7c: b.ne            #0xb1da98
    // 0xb1da80: LoadField: r16 = r1->field_7
    //     0xb1da80: ldur            x16, [x1, #7]
    // 0xb1da84: LoadField: r17 = r0->field_7
    //     0xb1da84: ldur            x17, [x0, #7]
    // 0xb1da88: cmp             x16, x17
    // 0xb1da8c: b.ne            #0xb1da98
    // 0xb1da90: mov             x0, x2
    // 0xb1da94: b               #0xb1dac4
    // 0xb1da98: StoreField: r3->field_2b = r0
    //     0xb1da98: stur            w0, [x3, #0x2b]
    //     0xb1da9c: tbz             w0, #0, #0xb1dab8
    //     0xb1daa0: ldurb           w16, [x3, #-1]
    //     0xb1daa4: ldurb           w17, [x0, #-1]
    //     0xb1daa8: and             x16, x17, x16, lsr #2
    //     0xb1daac: tst             x16, HEAP, lsr #32
    //     0xb1dab0: b.eq            #0xb1dab8
    //     0xb1dab4: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xb1dab8: mov             x1, x3
    // 0xb1dabc: r0 = markNeedsLayout()
    //     0xb1dabc: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0xb1dac0: ldur            x0, [fp, #-0x10]
    // 0xb1dac4: LoadField: r2 = r0->field_23
    //     0xb1dac4: ldur            w2, [x0, #0x23]
    // 0xb1dac8: DecompressPointer r2
    //     0xb1dac8: add             x2, x2, HEAP, lsl #32
    // 0xb1dacc: ldur            x1, [fp, #-0x18]
    // 0xb1dad0: r0 = ellipsis=()
    //     0xb1dad0: bl              #0xb1d00c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::ellipsis=
    // 0xb1dad4: ldur            x0, [fp, #-0x10]
    // 0xb1dad8: LoadField: r2 = r0->field_27
    //     0xb1dad8: ldur            w2, [x0, #0x27]
    // 0xb1dadc: DecompressPointer r2
    //     0xb1dadc: add             x2, x2, HEAP, lsl #32
    // 0xb1dae0: ldur            x1, [fp, #-0x18]
    // 0xb1dae4: r0 = locale=()
    //     0xb1dae4: bl              #0xb1cf68  ; [package:flutter/src/painting/text_painter.dart] TextPainter::locale=
    // 0xb1dae8: ldur            x0, [fp, #-0x10]
    // 0xb1daec: LoadField: r2 = r0->field_2f
    //     0xb1daec: ldur            w2, [x0, #0x2f]
    // 0xb1daf0: DecompressPointer r2
    //     0xb1daf0: add             x2, x2, HEAP, lsl #32
    // 0xb1daf4: ldur            x1, [fp, #-0x18]
    // 0xb1daf8: r0 = strutStyle=()
    //     0xb1daf8: bl              #0xb1cec4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::strutStyle=
    // 0xb1dafc: ldur            x1, [fp, #-0x18]
    // 0xb1db00: r2 = Instance_TextWidthBasis
    //     0xb1db00: add             x2, PP, #0x20, lsl #12  ; [pp+0x20110] Obj!TextWidthBasis@12c4781
    //     0xb1db04: ldr             x2, [x2, #0x110]
    // 0xb1db08: r0 = Shader._()
    //     0xb1db08: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xb1db0c: ldur            x1, [fp, #-0x18]
    // 0xb1db10: r2 = Null
    //     0xb1db10: mov             x2, NULL
    // 0xb1db14: r0 = Shader._()
    //     0xb1db14: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xb1db18: ldur            x0, [fp, #-0x18]
    // 0xb1db1c: LeaveFrame
    //     0xb1db1c: mov             SP, fp
    //     0xb1db20: ldp             fp, lr, [SP], #0x10
    // 0xb1db24: ret
    //     0xb1db24: ret             
    // 0xb1db28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1db28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1db2c: b               #0xb1d954
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb1dcd8, size: 0x78
    // 0xb1dcd8: EnterFrame
    //     0xb1dcd8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1dcdc: mov             fp, SP
    // 0xb1dce0: ldr             x0, [fp, #0x18]
    // 0xb1dce4: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb1dce4: ldur            w1, [x0, #0x17]
    // 0xb1dce8: DecompressPointer r1
    //     0xb1dce8: add             x1, x1, HEAP, lsl #32
    // 0xb1dcec: CheckStackOverflow
    //     0xb1dcec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1dcf0: cmp             SP, x16
    //     0xb1dcf4: b.ls            #0xb1dd38
    // 0xb1dcf8: ldr             x2, [fp, #0x10]
    // 0xb1dcfc: r0 = computeMinIntrinsicWidth()
    //     0xb1dcfc: bl              #0xb1d8ac  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMinIntrinsicWidth
    // 0xb1dd00: r0 = inline_Allocate_Double()
    //     0xb1dd00: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1dd04: add             x0, x0, #0x10
    //     0xb1dd08: cmp             x1, x0
    //     0xb1dd0c: b.ls            #0xb1dd40
    //     0xb1dd10: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1dd14: sub             x0, x0, #0xf
    //     0xb1dd18: mov             x1, #0xe19c
    //     0xb1dd1c: movk            x1, #3, lsl #16
    //     0xb1dd20: stur            x1, [x0, #-1]
    // 0xb1dd24: dmb             ishst
    // 0xb1dd28: StoreField: r0->field_7 = d0
    //     0xb1dd28: stur            d0, [x0, #7]
    // 0xb1dd2c: LeaveFrame
    //     0xb1dd2c: mov             SP, fp
    //     0xb1dd30: ldp             fp, lr, [SP], #0x10
    // 0xb1dd34: ret
    //     0xb1dd34: ret             
    // 0xb1dd38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1dd38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1dd3c: b               #0xb1dcf8
    // 0xb1dd40: SaveReg d0
    //     0xb1dd40: str             q0, [SP, #-0x10]!
    // 0xb1dd44: r0 = AllocateDouble()
    //     0xb1dd44: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb1dd48: RestoreReg d0
    //     0xb1dd48: ldr             q0, [SP], #0x10
    // 0xb1dd4c: b               #0xb1dd28
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb2011c, size: 0x24
    // 0xb2011c: EnterFrame
    //     0xb2011c: stp             fp, lr, [SP, #-0x10]!
    //     0xb20120: mov             fp, SP
    // 0xb20124: ldr             x2, [fp, #0x10]
    // 0xb20128: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb20128: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2dc8] AnonymousClosure: (0xb1dcd8), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMinIntrinsicWidth (0xb1d8ac)
    //     0xb2012c: ldr             x1, [x1, #0xdc8]
    // 0xb20130: r0 = AllocateClosure()
    //     0xb20130: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb20134: LeaveFrame
    //     0xb20134: mov             SP, fp
    //     0xb20138: ldp             fp, lr, [SP], #0x10
    // 0xb2013c: ret
    //     0xb2013c: ret             
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2bac8, size: 0x30
    // 0xb2bac8: EnterFrame
    //     0xb2bac8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2bacc: mov             fp, SP
    // 0xb2bad0: CheckStackOverflow
    //     0xb2bad0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2bad4: cmp             SP, x16
    //     0xb2bad8: b.ls            #0xb2baf0
    // 0xb2badc: LoadField: d0 = r2->field_7
    //     0xb2badc: ldur            d0, [x2, #7]
    // 0xb2bae0: r0 = _computeIntrinsicHeight()
    //     0xb2bae0: bl              #0xb2bb74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_computeIntrinsicHeight
    // 0xb2bae4: LeaveFrame
    //     0xb2bae4: mov             SP, fp
    //     0xb2bae8: ldp             fp, lr, [SP], #0x10
    // 0xb2baec: ret
    //     0xb2baec: ret             
    // 0xb2baf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2baf0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2baf4: b               #0xb2badc
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2baf8, size: 0x7c
    // 0xb2baf8: EnterFrame
    //     0xb2baf8: stp             fp, lr, [SP, #-0x10]!
    //     0xb2bafc: mov             fp, SP
    // 0xb2bb00: ldr             x0, [fp, #0x18]
    // 0xb2bb04: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2bb04: ldur            w1, [x0, #0x17]
    // 0xb2bb08: DecompressPointer r1
    //     0xb2bb08: add             x1, x1, HEAP, lsl #32
    // 0xb2bb0c: CheckStackOverflow
    //     0xb2bb0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2bb10: cmp             SP, x16
    //     0xb2bb14: b.ls            #0xb2bb5c
    // 0xb2bb18: ldr             x0, [fp, #0x10]
    // 0xb2bb1c: LoadField: d0 = r0->field_7
    //     0xb2bb1c: ldur            d0, [x0, #7]
    // 0xb2bb20: r0 = _computeIntrinsicHeight()
    //     0xb2bb20: bl              #0xb2bb74  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_computeIntrinsicHeight
    // 0xb2bb24: r0 = inline_Allocate_Double()
    //     0xb2bb24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2bb28: add             x0, x0, #0x10
    //     0xb2bb2c: cmp             x1, x0
    //     0xb2bb30: b.ls            #0xb2bb64
    //     0xb2bb34: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2bb38: sub             x0, x0, #0xf
    //     0xb2bb3c: mov             x1, #0xe19c
    //     0xb2bb40: movk            x1, #3, lsl #16
    //     0xb2bb44: stur            x1, [x0, #-1]
    // 0xb2bb48: dmb             ishst
    // 0xb2bb4c: StoreField: r0->field_7 = d0
    //     0xb2bb4c: stur            d0, [x0, #7]
    // 0xb2bb50: LeaveFrame
    //     0xb2bb50: mov             SP, fp
    //     0xb2bb54: ldp             fp, lr, [SP], #0x10
    // 0xb2bb58: ret
    //     0xb2bb58: ret             
    // 0xb2bb5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2bb5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2bb60: b               #0xb2bb18
    // 0xb2bb64: SaveReg d0
    //     0xb2bb64: str             q0, [SP, #-0x10]!
    // 0xb2bb68: r0 = AllocateDouble()
    //     0xb2bb68: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2bb6c: RestoreReg d0
    //     0xb2bb6c: ldr             q0, [SP], #0x10
    // 0xb2bb70: b               #0xb2bb4c
  }
  _ _computeIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2bb74, size: 0x11c
    // 0xb2bb74: EnterFrame
    //     0xb2bb74: stp             fp, lr, [SP, #-0x10]!
    //     0xb2bb78: mov             fp, SP
    // 0xb2bb7c: AllocStack(0x28)
    //     0xb2bb7c: sub             SP, SP, #0x28
    // 0xb2bb80: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0xb2bb80: mov             x0, x1
    //     0xb2bb84: stur            x1, [fp, #-8]
    //     0xb2bb88: stur            d0, [fp, #-0x18]
    // 0xb2bb8c: CheckStackOverflow
    //     0xb2bb8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2bb90: cmp             SP, x16
    //     0xb2bb94: b.ls            #0xb2bc5c
    // 0xb2bb98: mov             x1, x0
    // 0xb2bb9c: r0 = _textIntrinsics()
    //     0xb2bb9c: bl              #0xb1d938  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_textIntrinsics
    // 0xb2bba0: ldur            x1, [fp, #-8]
    // 0xb2bba4: ldur            d0, [fp, #-0x18]
    // 0xb2bba8: r2 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb2bba8: add             x2, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb2bbac: ldr             x2, [x2, #0x700]
    // 0xb2bbb0: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb2bbb0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb2bbb4: ldr             x3, [x3, #0x860]
    // 0xb2bbb8: stur            x0, [fp, #-0x10]
    // 0xb2bbbc: r0 = layoutInlineChildren()
    //     0xb2bbbc: bl              #0xb1db30  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb2bbc0: ldur            x1, [fp, #-0x10]
    // 0xb2bbc4: mov             x2, x0
    // 0xb2bbc8: r0 = setPlaceholderDimensions()
    //     0xb2bbc8: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb2bbcc: ldur            x1, [fp, #-8]
    // 0xb2bbd0: ldur            d0, [fp, #-0x18]
    // 0xb2bbd4: r0 = _adjustMaxWidth()
    //     0xb2bbd4: bl              #0xb2bc90  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_adjustMaxWidth
    // 0xb2bbd8: mov             v1.16b, v0.16b
    // 0xb2bbdc: ldur            d0, [fp, #-0x18]
    // 0xb2bbe0: r0 = inline_Allocate_Double()
    //     0xb2bbe0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2bbe4: add             x0, x0, #0x10
    //     0xb2bbe8: cmp             x1, x0
    //     0xb2bbec: b.ls            #0xb2bc64
    //     0xb2bbf0: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2bbf4: sub             x0, x0, #0xf
    //     0xb2bbf8: mov             x1, #0xe19c
    //     0xb2bbfc: movk            x1, #3, lsl #16
    //     0xb2bc00: stur            x1, [x0, #-1]
    // 0xb2bc04: dmb             ishst
    // 0xb2bc08: StoreField: r0->field_7 = d0
    //     0xb2bc08: stur            d0, [x0, #7]
    // 0xb2bc0c: r1 = inline_Allocate_Double()
    //     0xb2bc0c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb2bc10: add             x1, x1, #0x10
    //     0xb2bc14: cmp             x2, x1
    //     0xb2bc18: b.ls            #0xb2bc74
    //     0xb2bc1c: str             x1, [THR, #0x60]  ; THR::top
    //     0xb2bc20: sub             x1, x1, #0xf
    //     0xb2bc24: mov             x2, #0xe19c
    //     0xb2bc28: movk            x2, #3, lsl #16
    //     0xb2bc2c: stur            x2, [x1, #-1]
    // 0xb2bc30: dmb             ishst
    // 0xb2bc34: StoreField: r1->field_7 = d1
    //     0xb2bc34: stur            d1, [x1, #7]
    // 0xb2bc38: stp             x1, x0, [SP]
    // 0xb2bc3c: ldur            x1, [fp, #-0x10]
    // 0xb2bc40: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb2bc40: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb2bc44: r0 = layout()
    //     0xb2bc44: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb2bc48: ldur            x1, [fp, #-0x10]
    // 0xb2bc4c: r0 = height()
    //     0xb2bc4c: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0xb2bc50: LeaveFrame
    //     0xb2bc50: mov             SP, fp
    //     0xb2bc54: ldp             fp, lr, [SP], #0x10
    // 0xb2bc58: ret
    //     0xb2bc58: ret             
    // 0xb2bc5c: r0 = StackOverflowSharedWithFPURegs()
    //     0xb2bc5c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xb2bc60: b               #0xb2bb98
    // 0xb2bc64: stp             q0, q1, [SP, #-0x20]!
    // 0xb2bc68: r0 = AllocateDouble()
    //     0xb2bc68: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2bc6c: ldp             q0, q1, [SP], #0x20
    // 0xb2bc70: b               #0xb2bc08
    // 0xb2bc74: SaveReg d1
    //     0xb2bc74: str             q1, [SP, #-0x10]!
    // 0xb2bc78: SaveReg r0
    //     0xb2bc78: str             x0, [SP, #-8]!
    // 0xb2bc7c: r0 = AllocateDouble()
    //     0xb2bc7c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2bc80: mov             x1, x0
    // 0xb2bc84: RestoreReg r0
    //     0xb2bc84: ldr             x0, [SP], #8
    // 0xb2bc88: RestoreReg d1
    //     0xb2bc88: ldr             q1, [SP], #0x10
    // 0xb2bc8c: b               #0xb2bc34
  }
  _ _adjustMaxWidth(/* No info */) {
    // ** addr: 0xb2bc90, size: 0x2c
    // 0xb2bc90: LoadField: r0 = r1->field_7b
    //     0xb2bc90: ldur            w0, [x1, #0x7b]
    // 0xb2bc94: DecompressPointer r0
    //     0xb2bc94: add             x0, x0, HEAP, lsl #32
    // 0xb2bc98: tbz             w0, #4, #0xb2bcb8
    // 0xb2bc9c: LoadField: r0 = r1->field_7f
    //     0xb2bc9c: ldur            w0, [x1, #0x7f]
    // 0xb2bca0: DecompressPointer r0
    //     0xb2bca0: add             x0, x0, HEAP, lsl #32
    // 0xb2bca4: r16 = Instance_TextOverflow
    //     0xb2bca4: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xb2bca8: ldr             x16, [x16, #0xc18]
    // 0xb2bcac: cmp             w0, w16
    // 0xb2bcb0: b.eq            #0xb2bcb8
    // 0xb2bcb4: d0 = inf
    //     0xb2bcb4: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2bcb8: ret
    //     0xb2bcb8: ret             
  }
  [closure] Size <anonymous closure>(dynamic, RenderBox, BoxConstraints) {
    // ** addr: 0xb2e654, size: 0x4c
    // 0xb2e654: EnterFrame
    //     0xb2e654: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e658: mov             fp, SP
    // 0xb2e65c: AllocStack(0x8)
    //     0xb2e65c: sub             SP, SP, #8
    // 0xb2e660: CheckStackOverflow
    //     0xb2e660: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e664: cmp             SP, x16
    //     0xb2e668: b.ls            #0xb2e698
    // 0xb2e66c: ldr             x1, [fp, #0x18]
    // 0xb2e670: d0 = inf
    //     0xb2e670: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2e674: r0 = getMaxIntrinsicWidth()
    //     0xb2e674: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2e678: stur            d0, [fp, #-8]
    // 0xb2e67c: r0 = Size()
    //     0xb2e67c: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb2e680: ldur            d0, [fp, #-8]
    // 0xb2e684: StoreField: r0->field_7 = d0
    //     0xb2e684: stur            d0, [x0, #7]
    // 0xb2e688: StoreField: r0->field_f = rZR
    //     0xb2e688: stur            xzr, [x0, #0xf]
    // 0xb2e68c: LeaveFrame
    //     0xb2e68c: mov             SP, fp
    //     0xb2e690: ldp             fp, lr, [SP], #0x10
    // 0xb2e694: ret
    //     0xb2e694: ret             
    // 0xb2e698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e698: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e69c: b               #0xb2e66c
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2e6a0, size: 0x78
    // 0xb2e6a0: EnterFrame
    //     0xb2e6a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb2e6a4: mov             fp, SP
    // 0xb2e6a8: ldr             x0, [fp, #0x18]
    // 0xb2e6ac: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2e6ac: ldur            w1, [x0, #0x17]
    // 0xb2e6b0: DecompressPointer r1
    //     0xb2e6b0: add             x1, x1, HEAP, lsl #32
    // 0xb2e6b4: CheckStackOverflow
    //     0xb2e6b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2e6b8: cmp             SP, x16
    //     0xb2e6bc: b.ls            #0xb2e700
    // 0xb2e6c0: ldr             x2, [fp, #0x10]
    // 0xb2e6c4: r0 = computeMaxIntrinsicWidth()
    //     0xb2e6c4: bl              #0xb2ebe0  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMaxIntrinsicWidth
    // 0xb2e6c8: r0 = inline_Allocate_Double()
    //     0xb2e6c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2e6cc: add             x0, x0, #0x10
    //     0xb2e6d0: cmp             x1, x0
    //     0xb2e6d4: b.ls            #0xb2e708
    //     0xb2e6d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2e6dc: sub             x0, x0, #0xf
    //     0xb2e6e0: mov             x1, #0xe19c
    //     0xb2e6e4: movk            x1, #3, lsl #16
    //     0xb2e6e8: stur            x1, [x0, #-1]
    // 0xb2e6ec: dmb             ishst
    // 0xb2e6f0: StoreField: r0->field_7 = d0
    //     0xb2e6f0: stur            d0, [x0, #7]
    // 0xb2e6f4: LeaveFrame
    //     0xb2e6f4: mov             SP, fp
    //     0xb2e6f8: ldp             fp, lr, [SP], #0x10
    // 0xb2e6fc: ret
    //     0xb2e6fc: ret             
    // 0xb2e700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2e700: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2e704: b               #0xb2e6c0
    // 0xb2e708: SaveReg d0
    //     0xb2e708: str             q0, [SP, #-0x10]!
    // 0xb2e70c: r0 = AllocateDouble()
    //     0xb2e70c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2e710: RestoreReg d0
    //     0xb2e710: ldr             q0, [SP], #0x10
    // 0xb2e714: b               #0xb2e6f0
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2ebe0, size: 0x8c
    // 0xb2ebe0: EnterFrame
    //     0xb2ebe0: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ebe4: mov             fp, SP
    // 0xb2ebe8: AllocStack(0x8)
    //     0xb2ebe8: sub             SP, SP, #8
    // 0xb2ebec: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */)
    //     0xb2ebec: mov             x0, x1
    //     0xb2ebf0: stur            x1, [fp, #-8]
    // 0xb2ebf4: CheckStackOverflow
    //     0xb2ebf4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2ebf8: cmp             SP, x16
    //     0xb2ebfc: b.ls            #0xb2ec64
    // 0xb2ec00: r1 = Function '<anonymous closure>':.
    //     0xb2ec00: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2dc0] AnonymousClosure: (0xb2e654), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMaxIntrinsicWidth (0xb2ebe0)
    //     0xb2ec04: ldr             x1, [x1, #0xdc0]
    // 0xb2ec08: r2 = Null
    //     0xb2ec08: mov             x2, NULL
    // 0xb2ec0c: r0 = AllocateClosure()
    //     0xb2ec0c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb2ec10: ldur            x1, [fp, #-8]
    // 0xb2ec14: mov             x2, x0
    // 0xb2ec18: d0 = inf
    //     0xb2ec18: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0xb2ec1c: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb2ec1c: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb2ec20: ldr             x3, [x3, #0x860]
    // 0xb2ec24: r0 = layoutInlineChildren()
    //     0xb2ec24: bl              #0xb1db30  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb2ec28: ldur            x1, [fp, #-8]
    // 0xb2ec2c: stur            x0, [fp, #-8]
    // 0xb2ec30: r0 = _textIntrinsics()
    //     0xb2ec30: bl              #0xb1d938  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_textIntrinsics
    // 0xb2ec34: mov             x1, x0
    // 0xb2ec38: ldur            x2, [fp, #-8]
    // 0xb2ec3c: stur            x0, [fp, #-8]
    // 0xb2ec40: r0 = setPlaceholderDimensions()
    //     0xb2ec40: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb2ec44: ldur            x1, [fp, #-8]
    // 0xb2ec48: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb2ec48: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb2ec4c: r0 = layout()
    //     0xb2ec4c: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb2ec50: ldur            x1, [fp, #-8]
    // 0xb2ec54: r0 = maxIntrinsicWidth()
    //     0xb2ec54: bl              #0xb2e5b0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::maxIntrinsicWidth
    // 0xb2ec58: LeaveFrame
    //     0xb2ec58: mov             SP, fp
    //     0xb2ec5c: ldp             fp, lr, [SP], #0x10
    // 0xb2ec60: ret
    //     0xb2ec60: ret             
    // 0xb2ec64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2ec64: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2ec68: b               #0xb2ec00
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb5239c, size: 0x148
    // 0xb5239c: EnterFrame
    //     0xb5239c: stp             fp, lr, [SP, #-0x10]!
    //     0xb523a0: mov             fp, SP
    // 0xb523a4: AllocStack(0x38)
    //     0xb523a4: sub             SP, SP, #0x38
    // 0xb523a8: SetupParameters(RenderParagraph this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb523a8: mov             x0, x2
    //     0xb523ac: stur            x2, [fp, #-0x10]
    //     0xb523b0: mov             x2, x1
    //     0xb523b4: stur            x1, [fp, #-8]
    // 0xb523b8: CheckStackOverflow
    //     0xb523b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb523bc: cmp             SP, x16
    //     0xb523c0: b.ls            #0xb524b0
    // 0xb523c4: mov             x1, x2
    // 0xb523c8: r0 = _textIntrinsics()
    //     0xb523c8: bl              #0xb1d938  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_textIntrinsics
    // 0xb523cc: mov             x4, x0
    // 0xb523d0: ldur            x0, [fp, #-0x10]
    // 0xb523d4: stur            x4, [fp, #-0x18]
    // 0xb523d8: LoadField: d1 = r0->field_f
    //     0xb523d8: ldur            d1, [x0, #0xf]
    // 0xb523dc: ldur            x1, [fp, #-8]
    // 0xb523e0: mov             v0.16b, v1.16b
    // 0xb523e4: stur            d1, [fp, #-0x20]
    // 0xb523e8: r2 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb523e8: add             x2, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb523ec: ldr             x2, [x2, #0x700]
    // 0xb523f0: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb523f0: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb523f4: ldr             x3, [x3, #0x860]
    // 0xb523f8: r0 = layoutInlineChildren()
    //     0xb523f8: bl              #0xb1db30  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb523fc: ldur            x1, [fp, #-0x18]
    // 0xb52400: mov             x2, x0
    // 0xb52404: r0 = setPlaceholderDimensions()
    //     0xb52404: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb52408: ldur            x0, [fp, #-0x10]
    // 0xb5240c: LoadField: d1 = r0->field_7
    //     0xb5240c: ldur            d1, [x0, #7]
    // 0xb52410: ldur            x1, [fp, #-8]
    // 0xb52414: ldur            d0, [fp, #-0x20]
    // 0xb52418: stur            d1, [fp, #-0x28]
    // 0xb5241c: r0 = _adjustMaxWidth()
    //     0xb5241c: bl              #0xb2bc90  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_adjustMaxWidth
    // 0xb52420: mov             v1.16b, v0.16b
    // 0xb52424: ldur            d0, [fp, #-0x28]
    // 0xb52428: r0 = inline_Allocate_Double()
    //     0xb52428: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5242c: add             x0, x0, #0x10
    //     0xb52430: cmp             x1, x0
    //     0xb52434: b.ls            #0xb524b8
    //     0xb52438: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5243c: sub             x0, x0, #0xf
    //     0xb52440: mov             x1, #0xe19c
    //     0xb52444: movk            x1, #3, lsl #16
    //     0xb52448: stur            x1, [x0, #-1]
    // 0xb5244c: dmb             ishst
    // 0xb52450: StoreField: r0->field_7 = d0
    //     0xb52450: stur            d0, [x0, #7]
    // 0xb52454: r1 = inline_Allocate_Double()
    //     0xb52454: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb52458: add             x1, x1, #0x10
    //     0xb5245c: cmp             x2, x1
    //     0xb52460: b.ls            #0xb524c8
    //     0xb52464: str             x1, [THR, #0x60]  ; THR::top
    //     0xb52468: sub             x1, x1, #0xf
    //     0xb5246c: mov             x2, #0xe19c
    //     0xb52470: movk            x2, #3, lsl #16
    //     0xb52474: stur            x2, [x1, #-1]
    // 0xb52478: dmb             ishst
    // 0xb5247c: StoreField: r1->field_7 = d1
    //     0xb5247c: stur            d1, [x1, #7]
    // 0xb52480: stp             x1, x0, [SP]
    // 0xb52484: ldur            x1, [fp, #-0x18]
    // 0xb52488: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb52488: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb5248c: r0 = layout()
    //     0xb5248c: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb52490: ldur            x1, [fp, #-0x18]
    // 0xb52494: r0 = size()
    //     0xb52494: bl              #0x859c64  ; [package:flutter/src/painting/text_painter.dart] TextPainter::size
    // 0xb52498: ldur            x1, [fp, #-0x10]
    // 0xb5249c: mov             x2, x0
    // 0xb524a0: r0 = constrain()
    //     0xb524a0: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb524a4: LeaveFrame
    //     0xb524a4: mov             SP, fp
    //     0xb524a8: ldp             fp, lr, [SP], #0x10
    // 0xb524ac: ret
    //     0xb524ac: ret             
    // 0xb524b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb524b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb524b4: b               #0xb523c4
    // 0xb524b8: stp             q0, q1, [SP, #-0x20]!
    // 0xb524bc: r0 = AllocateDouble()
    //     0xb524bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb524c0: ldp             q0, q1, [SP], #0x20
    // 0xb524c4: b               #0xb52450
    // 0xb524c8: SaveReg d1
    //     0xb524c8: str             q1, [SP, #-0x10]!
    // 0xb524cc: SaveReg r0
    //     0xb524cc: str             x0, [SP, #-8]!
    // 0xb524d0: r0 = AllocateDouble()
    //     0xb524d0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb524d4: mov             x1, x0
    // 0xb524d8: RestoreReg r0
    //     0xb524d8: ldr             x0, [SP], #8
    // 0xb524dc: RestoreReg d1
    //     0xb524dc: ldr             q1, [SP], #0x10
    // 0xb524e0: b               #0xb5247c
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58708, size: 0x24
    // 0xb58708: EnterFrame
    //     0xb58708: stp             fp, lr, [SP, #-0x10]!
    //     0xb5870c: mov             fp, SP
    // 0xb58710: ldr             x2, [fp, #0x10]
    // 0xb58714: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58714: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2db8] AnonymousClosure: (0xb2e6a0), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMaxIntrinsicWidth (0xb2ebe0)
    //     0xb58718: ldr             x1, [x1, #0xdb8]
    // 0xb5871c: r0 = AllocateClosure()
    //     0xb5871c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58720: LeaveFrame
    //     0xb58720: mov             SP, fp
    //     0xb58724: ldp             fp, lr, [SP], #0x10
    // 0xb58728: ret
    //     0xb58728: ret             
  }
  _ computeDistanceToActualBaseline(/* No info */) {
    // ** addr: 0xb5c0d4, size: 0xf4
    // 0xb5c0d4: EnterFrame
    //     0xb5c0d4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5c0d8: mov             fp, SP
    // 0xb5c0dc: AllocStack(0x10)
    //     0xb5c0dc: sub             SP, SP, #0x10
    // 0xb5c0e0: SetupParameters(RenderParagraph this /* r1 => r3, fp-0x10 */)
    //     0xb5c0e0: mov             x3, x1
    //     0xb5c0e4: stur            x1, [fp, #-0x10]
    // 0xb5c0e8: CheckStackOverflow
    //     0xb5c0e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5c0ec: cmp             SP, x16
    //     0xb5c0f0: b.ls            #0xb5c1b0
    // 0xb5c0f4: LoadField: r4 = r3->field_27
    //     0xb5c0f4: ldur            w4, [x3, #0x27]
    // 0xb5c0f8: DecompressPointer r4
    //     0xb5c0f8: add             x4, x4, HEAP, lsl #32
    // 0xb5c0fc: stur            x4, [fp, #-8]
    // 0xb5c100: cmp             w4, NULL
    // 0xb5c104: b.eq            #0xb5c194
    // 0xb5c108: mov             x0, x4
    // 0xb5c10c: r2 = Null
    //     0xb5c10c: mov             x2, NULL
    // 0xb5c110: r1 = Null
    //     0xb5c110: mov             x1, NULL
    // 0xb5c114: r4 = LoadClassIdInstr(r0)
    //     0xb5c114: ldur            x4, [x0, #-1]
    //     0xb5c118: ubfx            x4, x4, #0xc, #0x14
    // 0xb5c11c: sub             x4, x4, #0xb46
    // 0xb5c120: cmp             x4, #1
    // 0xb5c124: b.ls            #0xb5c138
    // 0xb5c128: r8 = BoxConstraints
    //     0xb5c128: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb5c12c: r3 = Null
    //     0xb5c12c: add             x3, PP, #0x98, lsl #12  ; [pp+0x989e0] Null
    //     0xb5c130: ldr             x3, [x3, #0x9e0]
    // 0xb5c134: r0 = BoxConstraints()
    //     0xb5c134: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb5c138: ldur            x1, [fp, #-0x10]
    // 0xb5c13c: ldur            x2, [fp, #-8]
    // 0xb5c140: r0 = _layoutTextWithConstraints()
    //     0xb5c140: bl              #0xb5c1c8  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0xb5c144: ldur            x0, [fp, #-0x10]
    // 0xb5c148: LoadField: r1 = r0->field_63
    //     0xb5c148: ldur            w1, [x0, #0x63]
    // 0xb5c14c: DecompressPointer r1
    //     0xb5c14c: add             x1, x1, HEAP, lsl #32
    // 0xb5c150: r2 = Instance_TextBaseline
    //     0xb5c150: add             x2, PP, #0x89, lsl #12  ; [pp+0x89378] Obj!TextBaseline@12c74a1
    //     0xb5c154: ldr             x2, [x2, #0x378]
    // 0xb5c158: r0 = computeDistanceToActualBaseline()
    //     0xb5c158: bl              #0xb5b360  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeDistanceToActualBaseline
    // 0xb5c15c: r0 = inline_Allocate_Double()
    //     0xb5c15c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5c160: add             x0, x0, #0x10
    //     0xb5c164: cmp             x1, x0
    //     0xb5c168: b.ls            #0xb5c1b8
    //     0xb5c16c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5c170: sub             x0, x0, #0xf
    //     0xb5c174: mov             x1, #0xe19c
    //     0xb5c178: movk            x1, #3, lsl #16
    //     0xb5c17c: stur            x1, [x0, #-1]
    // 0xb5c180: dmb             ishst
    // 0xb5c184: StoreField: r0->field_7 = d0
    //     0xb5c184: stur            d0, [x0, #7]
    // 0xb5c188: LeaveFrame
    //     0xb5c188: mov             SP, fp
    //     0xb5c18c: ldp             fp, lr, [SP], #0x10
    // 0xb5c190: ret
    //     0xb5c190: ret             
    // 0xb5c194: r0 = StateError()
    //     0xb5c194: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb5c198: mov             x1, x0
    // 0xb5c19c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xb5c19c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xb5c1a0: StoreField: r1->field_b = r0
    //     0xb5c1a0: stur            w0, [x1, #0xb]
    // 0xb5c1a4: mov             x0, x1
    // 0xb5c1a8: r0 = Throw()
    //     0xb5c1a8: bl              #0x13ddb2c  ; ThrowStub
    // 0xb5c1ac: brk             #0
    // 0xb5c1b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5c1b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5c1b4: b               #0xb5c0f4
    // 0xb5c1b8: SaveReg d0
    //     0xb5c1b8: str             q0, [SP, #-0x10]!
    // 0xb5c1bc: r0 = AllocateDouble()
    //     0xb5c1bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5c1c0: RestoreReg d0
    //     0xb5c1c0: ldr             q0, [SP], #0x10
    // 0xb5c1c4: b               #0xb5c184
  }
  _ _layoutTextWithConstraints(/* No info */) {
    // ** addr: 0xb5c1c8, size: 0x110
    // 0xb5c1c8: EnterFrame
    //     0xb5c1c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb5c1cc: mov             fp, SP
    // 0xb5c1d0: AllocStack(0x30)
    //     0xb5c1d0: sub             SP, SP, #0x30
    // 0xb5c1d4: SetupParameters(RenderParagraph this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xb5c1d4: mov             x3, x1
    //     0xb5c1d8: mov             x0, x2
    //     0xb5c1dc: stur            x1, [fp, #-0x10]
    //     0xb5c1e0: stur            x2, [fp, #-0x18]
    // 0xb5c1e4: CheckStackOverflow
    //     0xb5c1e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb5c1e8: cmp             SP, x16
    //     0xb5c1ec: b.ls            #0xb5c2a4
    // 0xb5c1f0: LoadField: r4 = r3->field_63
    //     0xb5c1f0: ldur            w4, [x3, #0x63]
    // 0xb5c1f4: DecompressPointer r4
    //     0xb5c1f4: add             x4, x4, HEAP, lsl #32
    // 0xb5c1f8: stur            x4, [fp, #-8]
    // 0xb5c1fc: LoadField: r2 = r3->field_8f
    //     0xb5c1fc: ldur            w2, [x3, #0x8f]
    // 0xb5c200: DecompressPointer r2
    //     0xb5c200: add             x2, x2, HEAP, lsl #32
    // 0xb5c204: mov             x1, x4
    // 0xb5c208: r0 = setPlaceholderDimensions()
    //     0xb5c208: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb5c20c: ldur            x0, [fp, #-0x18]
    // 0xb5c210: LoadField: d1 = r0->field_7
    //     0xb5c210: ldur            d1, [x0, #7]
    // 0xb5c214: stur            d1, [fp, #-0x20]
    // 0xb5c218: LoadField: d0 = r0->field_f
    //     0xb5c218: ldur            d0, [x0, #0xf]
    // 0xb5c21c: ldur            x1, [fp, #-0x10]
    // 0xb5c220: r0 = _adjustMaxWidth()
    //     0xb5c220: bl              #0xb2bc90  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_adjustMaxWidth
    // 0xb5c224: mov             v1.16b, v0.16b
    // 0xb5c228: ldur            d0, [fp, #-0x20]
    // 0xb5c22c: r0 = inline_Allocate_Double()
    //     0xb5c22c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb5c230: add             x0, x0, #0x10
    //     0xb5c234: cmp             x1, x0
    //     0xb5c238: b.ls            #0xb5c2ac
    //     0xb5c23c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb5c240: sub             x0, x0, #0xf
    //     0xb5c244: mov             x1, #0xe19c
    //     0xb5c248: movk            x1, #3, lsl #16
    //     0xb5c24c: stur            x1, [x0, #-1]
    // 0xb5c250: dmb             ishst
    // 0xb5c254: StoreField: r0->field_7 = d0
    //     0xb5c254: stur            d0, [x0, #7]
    // 0xb5c258: r1 = inline_Allocate_Double()
    //     0xb5c258: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb5c25c: add             x1, x1, #0x10
    //     0xb5c260: cmp             x2, x1
    //     0xb5c264: b.ls            #0xb5c2bc
    //     0xb5c268: str             x1, [THR, #0x60]  ; THR::top
    //     0xb5c26c: sub             x1, x1, #0xf
    //     0xb5c270: mov             x2, #0xe19c
    //     0xb5c274: movk            x2, #3, lsl #16
    //     0xb5c278: stur            x2, [x1, #-1]
    // 0xb5c27c: dmb             ishst
    // 0xb5c280: StoreField: r1->field_7 = d1
    //     0xb5c280: stur            d1, [x1, #7]
    // 0xb5c284: stp             x1, x0, [SP]
    // 0xb5c288: ldur            x1, [fp, #-8]
    // 0xb5c28c: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb5c28c: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb5c290: r0 = layout()
    //     0xb5c290: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb5c294: r0 = Null
    //     0xb5c294: mov             x0, NULL
    // 0xb5c298: LeaveFrame
    //     0xb5c298: mov             SP, fp
    //     0xb5c29c: ldp             fp, lr, [SP], #0x10
    // 0xb5c2a0: ret
    //     0xb5c2a0: ret             
    // 0xb5c2a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5c2a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5c2a8: b               #0xb5c1f0
    // 0xb5c2ac: stp             q0, q1, [SP, #-0x20]!
    // 0xb5c2b0: r0 = AllocateDouble()
    //     0xb5c2b0: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5c2b4: ldp             q0, q1, [SP], #0x20
    // 0xb5c2b8: b               #0xb5c254
    // 0xb5c2bc: SaveReg d1
    //     0xb5c2bc: str             q1, [SP, #-0x10]!
    // 0xb5c2c0: SaveReg r0
    //     0xb5c2c0: str             x0, [SP, #-8]!
    // 0xb5c2c4: r0 = AllocateDouble()
    //     0xb5c2c4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb5c2c8: mov             x1, x0
    // 0xb5c2cc: RestoreReg r0
    //     0xb5c2cc: ldr             x0, [SP], #8
    // 0xb5c2d0: RestoreReg d1
    //     0xb5c2d0: ldr             q1, [SP], #0x10
    // 0xb5c2d4: b               #0xb5c280
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e8b4, size: 0x24
    // 0xb5e8b4: EnterFrame
    //     0xb5e8b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e8b8: mov             fp, SP
    // 0xb5e8bc: ldr             x2, [fp, #0x10]
    // 0xb5e8c0: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e8c0: add             x1, PP, #0x98, lsl #12  ; [pp+0x98810] AnonymousClosure: (0xb2baf8), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMaxIntrinsicHeight (0xb2bac8)
    //     0xb5e8c4: ldr             x1, [x1, #0x810]
    // 0xb5e8c8: r0 = AllocateClosure()
    //     0xb5e8c8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e8cc: LeaveFrame
    //     0xb5e8cc: mov             SP, fp
    //     0xb5e8d0: ldp             fp, lr, [SP], #0x10
    // 0xb5e8d4: ret
    //     0xb5e8d4: ret             
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb65030, size: 0x1c0
    // 0xb65030: EnterFrame
    //     0xb65030: stp             fp, lr, [SP, #-0x10]!
    //     0xb65034: mov             fp, SP
    // 0xb65038: AllocStack(0x38)
    //     0xb65038: sub             SP, SP, #0x38
    // 0xb6503c: SetupParameters(RenderParagraph this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */)
    //     0xb6503c: mov             x5, x1
    //     0xb65040: mov             x4, x2
    //     0xb65044: stur            x1, [fp, #-8]
    //     0xb65048: stur            x2, [fp, #-0x10]
    // 0xb6504c: CheckStackOverflow
    //     0xb6504c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb65050: cmp             SP, x16
    //     0xb65054: b.ls            #0xb651ac
    // 0xb65058: mov             x0, x4
    // 0xb6505c: r2 = Null
    //     0xb6505c: mov             x2, NULL
    // 0xb65060: r1 = Null
    //     0xb65060: mov             x1, NULL
    // 0xb65064: r4 = 60
    //     0xb65064: mov             x4, #0x3c
    // 0xb65068: branchIfSmi(r0, 0xb65074)
    //     0xb65068: tbz             w0, #0, #0xb65074
    // 0xb6506c: r4 = LoadClassIdInstr(r0)
    //     0xb6506c: ldur            x4, [x0, #-1]
    //     0xb65070: ubfx            x4, x4, #0xc, #0x14
    // 0xb65074: sub             x4, x4, #0xb46
    // 0xb65078: cmp             x4, #1
    // 0xb6507c: b.ls            #0xb65090
    // 0xb65080: r8 = BoxConstraints
    //     0xb65080: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb65084: r3 = Null
    //     0xb65084: add             x3, PP, #0x98, lsl #12  ; [pp+0x989c0] Null
    //     0xb65088: ldr             x3, [x3, #0x9c0]
    // 0xb6508c: r0 = BoxConstraints()
    //     0xb6508c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb65090: ldur            x1, [fp, #-8]
    // 0xb65094: r0 = _textIntrinsics()
    //     0xb65094: bl              #0xb1d938  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_textIntrinsics
    // 0xb65098: mov             x4, x0
    // 0xb6509c: ldur            x0, [fp, #-0x10]
    // 0xb650a0: stur            x4, [fp, #-0x18]
    // 0xb650a4: LoadField: d1 = r0->field_f
    //     0xb650a4: ldur            d1, [x0, #0xf]
    // 0xb650a8: ldur            x1, [fp, #-8]
    // 0xb650ac: mov             v0.16b, v1.16b
    // 0xb650b0: stur            d1, [fp, #-0x20]
    // 0xb650b4: r2 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xb650b4: add             x2, PP, #0x90, lsl #12  ; [pp+0x90700] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7f2adaa12214)
    //     0xb650b8: ldr             x2, [x2, #0x700]
    // 0xb650bc: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static.
    //     0xb650bc: add             x3, PP, #0x90, lsl #12  ; [pp+0x90860] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getDryBaseline': static. (0x7f2adaa00640)
    //     0xb650c0: ldr             x3, [x3, #0x860]
    // 0xb650c4: r0 = layoutInlineChildren()
    //     0xb650c4: bl              #0xb1db30  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xb650c8: ldur            x1, [fp, #-0x18]
    // 0xb650cc: mov             x2, x0
    // 0xb650d0: r0 = setPlaceholderDimensions()
    //     0xb650d0: bl              #0xb1c98c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0xb650d4: ldur            x0, [fp, #-0x10]
    // 0xb650d8: LoadField: d1 = r0->field_7
    //     0xb650d8: ldur            d1, [x0, #7]
    // 0xb650dc: ldur            x1, [fp, #-8]
    // 0xb650e0: ldur            d0, [fp, #-0x20]
    // 0xb650e4: stur            d1, [fp, #-0x28]
    // 0xb650e8: r0 = _adjustMaxWidth()
    //     0xb650e8: bl              #0xb2bc90  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_adjustMaxWidth
    // 0xb650ec: mov             v1.16b, v0.16b
    // 0xb650f0: ldur            d0, [fp, #-0x28]
    // 0xb650f4: r0 = inline_Allocate_Double()
    //     0xb650f4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb650f8: add             x0, x0, #0x10
    //     0xb650fc: cmp             x1, x0
    //     0xb65100: b.ls            #0xb651b4
    //     0xb65104: str             x0, [THR, #0x60]  ; THR::top
    //     0xb65108: sub             x0, x0, #0xf
    //     0xb6510c: mov             x1, #0xe19c
    //     0xb65110: movk            x1, #3, lsl #16
    //     0xb65114: stur            x1, [x0, #-1]
    // 0xb65118: dmb             ishst
    // 0xb6511c: StoreField: r0->field_7 = d0
    //     0xb6511c: stur            d0, [x0, #7]
    // 0xb65120: r1 = inline_Allocate_Double()
    //     0xb65120: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb65124: add             x1, x1, #0x10
    //     0xb65128: cmp             x2, x1
    //     0xb6512c: b.ls            #0xb651c4
    //     0xb65130: str             x1, [THR, #0x60]  ; THR::top
    //     0xb65134: sub             x1, x1, #0xf
    //     0xb65138: mov             x2, #0xe19c
    //     0xb6513c: movk            x2, #3, lsl #16
    //     0xb65140: stur            x2, [x1, #-1]
    // 0xb65144: dmb             ishst
    // 0xb65148: StoreField: r1->field_7 = d1
    //     0xb65148: stur            d1, [x1, #7]
    // 0xb6514c: stp             x1, x0, [SP]
    // 0xb65150: ldur            x1, [fp, #-0x18]
    // 0xb65154: r4 = const [0, 0x3, 0x2, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0xb65154: ldr             x4, [PP, #0x4ca8]  ; [pp+0x4ca8] List(9) [0, 0x3, 0x2, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    // 0xb65158: r0 = layout()
    //     0xb65158: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xb6515c: ldur            x1, [fp, #-8]
    // 0xb65160: r0 = _textIntrinsics()
    //     0xb65160: bl              #0xb1d938  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_textIntrinsics
    // 0xb65164: mov             x1, x0
    // 0xb65168: r2 = Instance_TextBaseline
    //     0xb65168: add             x2, PP, #0x89, lsl #12  ; [pp+0x89378] Obj!TextBaseline@12c74a1
    //     0xb6516c: ldr             x2, [x2, #0x378]
    // 0xb65170: r0 = computeDistanceToActualBaseline()
    //     0xb65170: bl              #0xb5b360  ; [package:flutter/src/painting/text_painter.dart] TextPainter::computeDistanceToActualBaseline
    // 0xb65174: r0 = inline_Allocate_Double()
    //     0xb65174: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb65178: add             x0, x0, #0x10
    //     0xb6517c: cmp             x1, x0
    //     0xb65180: b.ls            #0xb651e0
    //     0xb65184: str             x0, [THR, #0x60]  ; THR::top
    //     0xb65188: sub             x0, x0, #0xf
    //     0xb6518c: mov             x1, #0xe19c
    //     0xb65190: movk            x1, #3, lsl #16
    //     0xb65194: stur            x1, [x0, #-1]
    // 0xb65198: dmb             ishst
    // 0xb6519c: StoreField: r0->field_7 = d0
    //     0xb6519c: stur            d0, [x0, #7]
    // 0xb651a0: LeaveFrame
    //     0xb651a0: mov             SP, fp
    //     0xb651a4: ldp             fp, lr, [SP], #0x10
    // 0xb651a8: ret
    //     0xb651a8: ret             
    // 0xb651ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb651ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb651b0: b               #0xb65058
    // 0xb651b4: stp             q0, q1, [SP, #-0x20]!
    // 0xb651b8: r0 = AllocateDouble()
    //     0xb651b8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb651bc: ldp             q0, q1, [SP], #0x20
    // 0xb651c0: b               #0xb6511c
    // 0xb651c4: SaveReg d1
    //     0xb651c4: str             q1, [SP, #-0x10]!
    // 0xb651c8: SaveReg r0
    //     0xb651c8: str             x0, [SP, #-8]!
    // 0xb651cc: r0 = AllocateDouble()
    //     0xb651cc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb651d0: mov             x1, x0
    // 0xb651d4: RestoreReg r0
    //     0xb651d4: ldr             x0, [SP], #8
    // 0xb651d8: RestoreReg d1
    //     0xb651d8: ldr             q1, [SP], #0x10
    // 0xb651dc: b               #0xb65148
    // 0xb651e0: SaveReg d0
    //     0xb651e0: str             q0, [SP, #-0x10]!
    // 0xb651e4: r0 = AllocateDouble()
    //     0xb651e4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb651e8: RestoreReg d0
    //     0xb651e8: ldr             q0, [SP], #0x10
    // 0xb651ec: b               #0xb6519c
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbcb12c, size: 0x62c
    // 0xbcb12c: EnterFrame
    //     0xbcb12c: stp             fp, lr, [SP, #-0x10]!
    //     0xbcb130: mov             fp, SP
    // 0xbcb134: AllocStack(0x70)
    //     0xbcb134: sub             SP, SP, #0x70
    // 0xbcb138: SetupParameters(RenderParagraph this /* r1 => r3, fp-0x10 */)
    //     0xbcb138: mov             x3, x1
    //     0xbcb13c: stur            x1, [fp, #-0x10]
    // 0xbcb140: CheckStackOverflow
    //     0xbcb140: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbcb144: cmp             SP, x16
    //     0xbcb148: b.ls            #0xbcb6ec
    // 0xbcb14c: LoadField: r4 = r3->field_27
    //     0xbcb14c: ldur            w4, [x3, #0x27]
    // 0xbcb150: DecompressPointer r4
    //     0xbcb150: add             x4, x4, HEAP, lsl #32
    // 0xbcb154: stur            x4, [fp, #-8]
    // 0xbcb158: cmp             w4, NULL
    // 0xbcb15c: b.eq            #0xbcb6d0
    // 0xbcb160: mov             x0, x4
    // 0xbcb164: r2 = Null
    //     0xbcb164: mov             x2, NULL
    // 0xbcb168: r1 = Null
    //     0xbcb168: mov             x1, NULL
    // 0xbcb16c: r4 = LoadClassIdInstr(r0)
    //     0xbcb16c: ldur            x4, [x0, #-1]
    //     0xbcb170: ubfx            x4, x4, #0xc, #0x14
    // 0xbcb174: sub             x4, x4, #0xb46
    // 0xbcb178: cmp             x4, #1
    // 0xbcb17c: b.ls            #0xbcb190
    // 0xbcb180: r8 = BoxConstraints
    //     0xbcb180: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbcb184: r3 = Null
    //     0xbcb184: add             x3, PP, #0x98, lsl #12  ; [pp+0x98960] Null
    //     0xbcb188: ldr             x3, [x3, #0x960]
    // 0xbcb18c: r0 = BoxConstraints()
    //     0xbcb18c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbcb190: ldur            x0, [fp, #-8]
    // 0xbcb194: LoadField: d0 = r0->field_f
    //     0xbcb194: ldur            d0, [x0, #0xf]
    // 0xbcb198: ldur            x1, [fp, #-0x10]
    // 0xbcb19c: r2 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0xbcb19c: add             x2, PP, #0x8e, lsl #12  ; [pp+0x8e4f8] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7f2adaa34e18)
    //     0xbcb1a0: ldr             x2, [x2, #0x4f8]
    // 0xbcb1a4: r3 = Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getBaseline': static.
    //     0xbcb1a4: add             x3, PP, #0x90, lsl #12  ; [pp+0x90750] Closure: (RenderBox, BoxConstraints, TextBaseline) => double? from Function 'getBaseline': static. (0x7f2adaaa6ca0)
    //     0xbcb1a8: ldr             x3, [x3, #0x750]
    // 0xbcb1ac: r0 = layoutInlineChildren()
    //     0xbcb1ac: bl              #0xb1db30  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::layoutInlineChildren
    // 0xbcb1b0: ldur            x3, [fp, #-0x10]
    // 0xbcb1b4: StoreField: r3->field_8f = r0
    //     0xbcb1b4: stur            w0, [x3, #0x8f]
    //     0xbcb1b8: ldurb           w16, [x3, #-1]
    //     0xbcb1bc: ldurb           w17, [x0, #-1]
    //     0xbcb1c0: and             x16, x17, x16, lsr #2
    //     0xbcb1c4: tst             x16, HEAP, lsr #32
    //     0xbcb1c8: b.eq            #0xbcb1d0
    //     0xbcb1cc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbcb1d0: mov             x1, x3
    // 0xbcb1d4: ldur            x2, [fp, #-8]
    // 0xbcb1d8: r0 = _layoutTextWithConstraints()
    //     0xbcb1d8: bl              #0xb5c1c8  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0xbcb1dc: ldur            x0, [fp, #-0x10]
    // 0xbcb1e0: LoadField: r2 = r0->field_63
    //     0xbcb1e0: ldur            w2, [x0, #0x63]
    // 0xbcb1e4: DecompressPointer r2
    //     0xbcb1e4: add             x2, x2, HEAP, lsl #32
    // 0xbcb1e8: mov             x1, x2
    // 0xbcb1ec: stur            x2, [fp, #-0x18]
    // 0xbcb1f0: r0 = inlinePlaceholderBoxes()
    //     0xbcb1f0: bl              #0xbc401c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::inlinePlaceholderBoxes
    // 0xbcb1f4: cmp             w0, NULL
    // 0xbcb1f8: b.eq            #0xbcb6f4
    // 0xbcb1fc: ldur            x1, [fp, #-0x10]
    // 0xbcb200: mov             x2, x0
    // 0xbcb204: r0 = positionInlineChildren()
    //     0xbcb204: bl              #0xbcc33c  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::positionInlineChildren
    // 0xbcb208: ldur            x1, [fp, #-0x18]
    // 0xbcb20c: r0 = size()
    //     0xbcb20c: bl              #0x859c64  ; [package:flutter/src/painting/text_painter.dart] TextPainter::size
    // 0xbcb210: ldur            x1, [fp, #-8]
    // 0xbcb214: mov             x2, x0
    // 0xbcb218: stur            x0, [fp, #-8]
    // 0xbcb21c: r0 = constrain()
    //     0xbcb21c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbcb220: ldur            x2, [fp, #-0x10]
    // 0xbcb224: StoreField: r2->field_4b = r0
    //     0xbcb224: stur            w0, [x2, #0x4b]
    //     0xbcb228: ldurb           w16, [x2, #-1]
    //     0xbcb22c: ldurb           w17, [x0, #-1]
    //     0xbcb230: and             x16, x17, x16, lsr #2
    //     0xbcb234: tst             x16, HEAP, lsr #32
    //     0xbcb238: b.eq            #0xbcb240
    //     0xbcb23c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbcb240: mov             x1, x2
    // 0xbcb244: r0 = size()
    //     0xbcb244: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbcb248: LoadField: d0 = r0->field_f
    //     0xbcb248: ldur            d0, [x0, #0xf]
    // 0xbcb24c: ldur            x0, [fp, #-8]
    // 0xbcb250: LoadField: d1 = r0->field_f
    //     0xbcb250: ldur            d1, [x0, #0xf]
    // 0xbcb254: fcmp            d1, d0
    // 0xbcb258: b.le            #0xbcb264
    // 0xbcb25c: r2 = true
    //     0xbcb25c: add             x2, NULL, #0x20  ; true
    // 0xbcb260: b               #0xbcb274
    // 0xbcb264: ldur            x1, [fp, #-0x18]
    // 0xbcb268: r0 = didExceedMaxLines()
    //     0xbcb268: bl              #0xbcc1a4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::didExceedMaxLines
    // 0xbcb26c: mov             x2, x0
    // 0xbcb270: ldur            x0, [fp, #-8]
    // 0xbcb274: ldur            x1, [fp, #-0x10]
    // 0xbcb278: stur            x2, [fp, #-0x20]
    // 0xbcb27c: r0 = size()
    //     0xbcb27c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbcb280: LoadField: d0 = r0->field_7
    //     0xbcb280: ldur            d0, [x0, #7]
    // 0xbcb284: ldur            x0, [fp, #-8]
    // 0xbcb288: LoadField: d1 = r0->field_7
    //     0xbcb288: ldur            d1, [x0, #7]
    // 0xbcb28c: fcmp            d1, d0
    // 0xbcb290: r16 = true
    //     0xbcb290: add             x16, NULL, #0x20  ; true
    // 0xbcb294: r17 = false
    //     0xbcb294: add             x17, NULL, #0x30  ; false
    // 0xbcb298: csel            x0, x16, x17, gt
    // 0xbcb29c: stur            x0, [fp, #-0x28]
    // 0xbcb2a0: tbz             w0, #4, #0xbcb2ac
    // 0xbcb2a4: ldur            x1, [fp, #-0x20]
    // 0xbcb2a8: tbnz            w1, #4, #0xbcb6b0
    // 0xbcb2ac: ldur            x1, [fp, #-0x10]
    // 0xbcb2b0: LoadField: r2 = r1->field_7f
    //     0xbcb2b0: ldur            w2, [x1, #0x7f]
    // 0xbcb2b4: DecompressPointer r2
    //     0xbcb2b4: add             x2, x2, HEAP, lsl #32
    // 0xbcb2b8: LoadField: r3 = r2->field_7
    //     0xbcb2b8: ldur            x3, [x2, #7]
    // 0xbcb2bc: cmp             x3, #1
    // 0xbcb2c0: b.gt            #0xbcb688
    // 0xbcb2c4: cmp             x3, #0
    // 0xbcb2c8: b.gt            #0xbcb2d4
    // 0xbcb2cc: r4 = true
    //     0xbcb2cc: add             x4, NULL, #0x20  ; true
    // 0xbcb2d0: b               #0xbcb694
    // 0xbcb2d4: ldur            x2, [fp, #-0x18]
    // 0xbcb2d8: r4 = true
    //     0xbcb2d8: add             x4, NULL, #0x20  ; true
    // 0xbcb2dc: StoreField: r1->field_87 = r4
    //     0xbcb2dc: stur            w4, [x1, #0x87]
    // 0xbcb2e0: LoadField: r3 = r2->field_f
    //     0xbcb2e0: ldur            w3, [x2, #0xf]
    // 0xbcb2e4: DecompressPointer r3
    //     0xbcb2e4: add             x3, x3, HEAP, lsl #32
    // 0xbcb2e8: cmp             w3, NULL
    // 0xbcb2ec: b.eq            #0xbcb6f8
    // 0xbcb2f0: LoadField: r4 = r3->field_7
    //     0xbcb2f0: ldur            w4, [x3, #7]
    // 0xbcb2f4: DecompressPointer r4
    //     0xbcb2f4: add             x4, x4, HEAP, lsl #32
    // 0xbcb2f8: stur            x4, [fp, #-8]
    // 0xbcb2fc: r0 = TextSpan()
    //     0xbcb2fc: bl              #0xb57880  ; AllocateTextSpanStub -> TextSpan (size=0x34)
    // 0xbcb300: mov             x2, x0
    // 0xbcb304: r0 = "…"
    //     0xbcb304: add             x0, PP, #0x90, lsl #12  ; [pp+0x90330] "…"
    //     0xbcb308: ldr             x0, [x0, #0x330]
    // 0xbcb30c: stur            x2, [fp, #-0x20]
    // 0xbcb310: StoreField: r2->field_b = r0
    //     0xbcb310: stur            w0, [x2, #0xb]
    // 0xbcb314: r0 = Instance__DeferringMouseCursor
    //     0xbcb314: ldr             x0, [PP, #0x2208]  ; [pp+0x2208] Obj!_DeferringMouseCursor@12b3241
    // 0xbcb318: ArrayStore: r2[0] = r0  ; List_4
    //     0xbcb318: stur            w0, [x2, #0x17]
    // 0xbcb31c: ldur            x0, [fp, #-8]
    // 0xbcb320: StoreField: r2->field_7 = r0
    //     0xbcb320: stur            w0, [x2, #7]
    // 0xbcb324: ldur            x0, [fp, #-0x18]
    // 0xbcb328: LoadField: r3 = r0->field_1b
    //     0xbcb328: ldur            w3, [x0, #0x1b]
    // 0xbcb32c: DecompressPointer r3
    //     0xbcb32c: add             x3, x3, HEAP, lsl #32
    // 0xbcb330: stur            x3, [fp, #-8]
    // 0xbcb334: cmp             w3, NULL
    // 0xbcb338: b.eq            #0xbcb6fc
    // 0xbcb33c: ldur            x1, [fp, #-0x10]
    // 0xbcb340: r0 = textScaler()
    //     0xbcb340: bl              #0xbcc190  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::textScaler
    // 0xbcb344: ldur            x1, [fp, #-0x10]
    // 0xbcb348: stur            x0, [fp, #-0x30]
    // 0xbcb34c: r0 = locale()
    //     0xbcb34c: bl              #0xbcc17c  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::locale
    // 0xbcb350: stur            x0, [fp, #-0x38]
    // 0xbcb354: r0 = TextPainter()
    //     0xbcb354: bl              #0xb13a1c  ; AllocateTextPainterStub -> TextPainter (size=0x48)
    // 0xbcb358: stur            x0, [fp, #-0x40]
    // 0xbcb35c: ldur            x16, [fp, #-0x20]
    // 0xbcb360: ldur            lr, [fp, #-8]
    // 0xbcb364: stp             lr, x16, [SP, #0x10]
    // 0xbcb368: ldur            x16, [fp, #-0x30]
    // 0xbcb36c: ldur            lr, [fp, #-0x38]
    // 0xbcb370: stp             lr, x16, [SP]
    // 0xbcb374: mov             x1, x0
    // 0xbcb378: r4 = const [0, 0x5, 0x4, 0x1, locale, 0x4, text, 0x1, textDirection, 0x2, textScaler, 0x3, null]
    //     0xbcb378: add             x4, PP, #0x98, lsl #12  ; [pp+0x98970] List(13) [0, 0x5, 0x4, 0x1, "locale", 0x4, "text", 0x1, "textDirection", 0x2, "textScaler", 0x3, Null]
    //     0xbcb37c: ldr             x4, [x4, #0x970]
    // 0xbcb380: r0 = TextPainter()
    //     0xbcb380: bl              #0xb135d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::TextPainter
    // 0xbcb384: ldur            x1, [fp, #-0x40]
    // 0xbcb388: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbcb388: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbcb38c: r0 = layout()
    //     0xbcb38c: bl              #0x86018c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0xbcb390: ldur            x0, [fp, #-0x28]
    // 0xbcb394: tbnz            w0, #4, #0xbcb58c
    // 0xbcb398: ldur            x0, [fp, #-0x18]
    // 0xbcb39c: LoadField: r1 = r0->field_1b
    //     0xbcb39c: ldur            w1, [x0, #0x1b]
    // 0xbcb3a0: DecompressPointer r1
    //     0xbcb3a0: add             x1, x1, HEAP, lsl #32
    // 0xbcb3a4: cmp             w1, NULL
    // 0xbcb3a8: b.eq            #0xbcb700
    // 0xbcb3ac: LoadField: r0 = r1->field_7
    //     0xbcb3ac: ldur            x0, [x1, #7]
    // 0xbcb3b0: cmp             x0, #0
    // 0xbcb3b4: b.gt            #0xbcb408
    // 0xbcb3b8: ldur            x1, [fp, #-0x40]
    // 0xbcb3bc: LoadField: r0 = r1->field_7
    //     0xbcb3bc: ldur            w0, [x1, #7]
    // 0xbcb3c0: DecompressPointer r0
    //     0xbcb3c0: add             x0, x0, HEAP, lsl #32
    // 0xbcb3c4: cmp             w0, NULL
    // 0xbcb3c8: b.eq            #0xbcb704
    // 0xbcb3cc: LoadField: d0 = r0->field_13
    //     0xbcb3cc: ldur            d0, [x0, #0x13]
    // 0xbcb3d0: r2 = inline_Allocate_Double()
    //     0xbcb3d0: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xbcb3d4: add             x2, x2, #0x10
    //     0xbcb3d8: cmp             x0, x2
    //     0xbcb3dc: b.ls            #0xbcb708
    //     0xbcb3e0: str             x2, [THR, #0x60]  ; THR::top
    //     0xbcb3e4: sub             x2, x2, #0xf
    //     0xbcb3e8: mov             x0, #0xe19c
    //     0xbcb3ec: movk            x0, #3, lsl #16
    //     0xbcb3f0: stur            x0, [x2, #-1]
    // 0xbcb3f4: dmb             ishst
    // 0xbcb3f8: StoreField: r2->field_7 = d0
    //     0xbcb3f8: stur            d0, [x2, #7]
    // 0xbcb3fc: r3 = 0.000000
    //     0xbcb3fc: ldr             x3, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbcb400: r0 = AllocateRecord2()
    //     0xbcb400: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbcb404: b               #0xbcb4a4
    // 0xbcb408: ldur            x0, [fp, #-0x40]
    // 0xbcb40c: ldur            x1, [fp, #-0x10]
    // 0xbcb410: r0 = size()
    //     0xbcb410: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbcb414: LoadField: d0 = r0->field_7
    //     0xbcb414: ldur            d0, [x0, #7]
    // 0xbcb418: ldur            x0, [fp, #-0x40]
    // 0xbcb41c: LoadField: r1 = r0->field_7
    //     0xbcb41c: ldur            w1, [x0, #7]
    // 0xbcb420: DecompressPointer r1
    //     0xbcb420: add             x1, x1, HEAP, lsl #32
    // 0xbcb424: cmp             w1, NULL
    // 0xbcb428: b.eq            #0xbcb724
    // 0xbcb42c: LoadField: d1 = r1->field_13
    //     0xbcb42c: ldur            d1, [x1, #0x13]
    // 0xbcb430: fsub            d2, d0, d1
    // 0xbcb434: ldur            x1, [fp, #-0x10]
    // 0xbcb438: stur            d2, [fp, #-0x48]
    // 0xbcb43c: r0 = size()
    //     0xbcb43c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbcb440: LoadField: d0 = r0->field_7
    //     0xbcb440: ldur            d0, [x0, #7]
    // 0xbcb444: ldur            d1, [fp, #-0x48]
    // 0xbcb448: r2 = inline_Allocate_Double()
    //     0xbcb448: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xbcb44c: add             x2, x2, #0x10
    //     0xbcb450: cmp             x0, x2
    //     0xbcb454: b.ls            #0xbcb728
    //     0xbcb458: str             x2, [THR, #0x60]  ; THR::top
    //     0xbcb45c: sub             x2, x2, #0xf
    //     0xbcb460: mov             x0, #0xe19c
    //     0xbcb464: movk            x0, #3, lsl #16
    //     0xbcb468: stur            x0, [x2, #-1]
    // 0xbcb46c: dmb             ishst
    // 0xbcb470: StoreField: r2->field_7 = d1
    //     0xbcb470: stur            d1, [x2, #7]
    // 0xbcb474: r3 = inline_Allocate_Double()
    //     0xbcb474: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xbcb478: add             x3, x3, #0x10
    //     0xbcb47c: cmp             x0, x3
    //     0xbcb480: b.ls            #0xbcb73c
    //     0xbcb484: str             x3, [THR, #0x60]  ; THR::top
    //     0xbcb488: sub             x3, x3, #0xf
    //     0xbcb48c: mov             x0, #0xe19c
    //     0xbcb490: movk            x0, #3, lsl #16
    //     0xbcb494: stur            x0, [x3, #-1]
    // 0xbcb498: dmb             ishst
    // 0xbcb49c: StoreField: r3->field_7 = d0
    //     0xbcb49c: stur            d0, [x3, #7]
    // 0xbcb4a0: r0 = AllocateRecord2()
    //     0xbcb4a0: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbcb4a4: ldur            x1, [fp, #-0x10]
    // 0xbcb4a8: LoadField: r2 = r0->field_f
    //     0xbcb4a8: ldur            w2, [x0, #0xf]
    // 0xbcb4ac: DecompressPointer r2
    //     0xbcb4ac: add             x2, x2, HEAP, lsl #32
    // 0xbcb4b0: LoadField: r3 = r0->field_13
    //     0xbcb4b0: ldur            w3, [x0, #0x13]
    // 0xbcb4b4: DecompressPointer r3
    //     0xbcb4b4: add             x3, x3, HEAP, lsl #32
    // 0xbcb4b8: stur            x3, [fp, #-8]
    // 0xbcb4bc: LoadField: d0 = r2->field_7
    //     0xbcb4bc: ldur            d0, [x2, #7]
    // 0xbcb4c0: stur            d0, [fp, #-0x48]
    // 0xbcb4c4: r0 = Offset()
    //     0xbcb4c4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbcb4c8: ldur            d0, [fp, #-0x48]
    // 0xbcb4cc: stur            x0, [fp, #-0x18]
    // 0xbcb4d0: StoreField: r0->field_7 = d0
    //     0xbcb4d0: stur            d0, [x0, #7]
    // 0xbcb4d4: StoreField: r0->field_f = rZR
    //     0xbcb4d4: stur            xzr, [x0, #0xf]
    // 0xbcb4d8: ldur            x1, [fp, #-8]
    // 0xbcb4dc: LoadField: d0 = r1->field_7
    //     0xbcb4dc: ldur            d0, [x1, #7]
    // 0xbcb4e0: stur            d0, [fp, #-0x48]
    // 0xbcb4e4: r0 = Offset()
    //     0xbcb4e4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbcb4e8: ldur            d0, [fp, #-0x48]
    // 0xbcb4ec: stur            x0, [fp, #-8]
    // 0xbcb4f0: StoreField: r0->field_7 = d0
    //     0xbcb4f0: stur            d0, [x0, #7]
    // 0xbcb4f4: StoreField: r0->field_f = rZR
    //     0xbcb4f4: stur            xzr, [x0, #0xf]
    // 0xbcb4f8: r1 = Null
    //     0xbcb4f8: mov             x1, NULL
    // 0xbcb4fc: r2 = 4
    //     0xbcb4fc: mov             x2, #4
    // 0xbcb500: r0 = AllocateArray()
    //     0xbcb500: bl              #0x13df928  ; AllocateArrayStub
    // 0xbcb504: stur            x0, [fp, #-0x20]
    // 0xbcb508: r16 = Instance_Color
    //     0xbcb508: add             x16, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xbcb50c: ldr             x16, [x16, #0xc38]
    // 0xbcb510: StoreField: r0->field_f = r16
    //     0xbcb510: stur            w16, [x0, #0xf]
    // 0xbcb514: r16 = Instance_Color
    //     0xbcb514: add             x16, PP, #0x87, lsl #12  ; [pp+0x87f08] Obj!Color@12a2791
    //     0xbcb518: ldr             x16, [x16, #0xf08]
    // 0xbcb51c: StoreField: r0->field_13 = r16
    //     0xbcb51c: stur            w16, [x0, #0x13]
    // 0xbcb520: r1 = <Color>
    //     0xbcb520: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xbcb524: ldr             x1, [x1, #0xa90]
    // 0xbcb528: r0 = AllocateGrowableArray()
    //     0xbcb528: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xbcb52c: mov             x1, x0
    // 0xbcb530: ldur            x0, [fp, #-0x20]
    // 0xbcb534: stur            x1, [fp, #-0x28]
    // 0xbcb538: StoreField: r1->field_f = r0
    //     0xbcb538: stur            w0, [x1, #0xf]
    // 0xbcb53c: r2 = 4
    //     0xbcb53c: mov             x2, #4
    // 0xbcb540: StoreField: r1->field_b = r2
    //     0xbcb540: stur            w2, [x1, #0xb]
    // 0xbcb544: r0 = Gradient()
    //     0xbcb544: bl              #0xbcc170  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0xbcb548: mov             x1, x0
    // 0xbcb54c: ldur            x2, [fp, #-0x18]
    // 0xbcb550: ldur            x3, [fp, #-8]
    // 0xbcb554: ldur            x5, [fp, #-0x28]
    // 0xbcb558: stur            x0, [fp, #-8]
    // 0xbcb55c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xbcb55c: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xbcb560: r0 = Gradient.linear()
    //     0xbcb560: bl              #0xbcb8a4  ; [dart:ui] Gradient::Gradient.linear
    // 0xbcb564: ldur            x0, [fp, #-8]
    // 0xbcb568: ldur            x3, [fp, #-0x10]
    // 0xbcb56c: StoreField: r3->field_8b = r0
    //     0xbcb56c: stur            w0, [x3, #0x8b]
    //     0xbcb570: ldurb           w16, [x3, #-1]
    //     0xbcb574: ldurb           w17, [x0, #-1]
    //     0xbcb578: and             x16, x17, x16, lsr #2
    //     0xbcb57c: tst             x16, HEAP, lsr #32
    //     0xbcb580: b.eq            #0xbcb588
    //     0xbcb584: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbcb588: b               #0xbcb67c
    // 0xbcb58c: ldur            x3, [fp, #-0x10]
    // 0xbcb590: r2 = 4
    //     0xbcb590: mov             x2, #4
    // 0xbcb594: mov             x1, x3
    // 0xbcb598: r0 = size()
    //     0xbcb598: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbcb59c: LoadField: d0 = r0->field_f
    //     0xbcb59c: ldur            d0, [x0, #0xf]
    // 0xbcb5a0: ldur            x1, [fp, #-0x40]
    // 0xbcb5a4: stur            d0, [fp, #-0x48]
    // 0xbcb5a8: r0 = height()
    //     0xbcb5a8: bl              #0x859ce8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::height
    // 0xbcb5ac: mov             v1.16b, v0.16b
    // 0xbcb5b0: d0 = 2.000000
    //     0xbcb5b0: fmov            d0, #2.00000000
    // 0xbcb5b4: fdiv            d2, d1, d0
    // 0xbcb5b8: ldur            d0, [fp, #-0x48]
    // 0xbcb5bc: fsub            d1, d0, d2
    // 0xbcb5c0: stur            d1, [fp, #-0x50]
    // 0xbcb5c4: r0 = Offset()
    //     0xbcb5c4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbcb5c8: stur            x0, [fp, #-8]
    // 0xbcb5cc: StoreField: r0->field_7 = rZR
    //     0xbcb5cc: stur            xzr, [x0, #7]
    // 0xbcb5d0: ldur            d0, [fp, #-0x50]
    // 0xbcb5d4: StoreField: r0->field_f = d0
    //     0xbcb5d4: stur            d0, [x0, #0xf]
    // 0xbcb5d8: r0 = Offset()
    //     0xbcb5d8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbcb5dc: stur            x0, [fp, #-0x18]
    // 0xbcb5e0: StoreField: r0->field_7 = rZR
    //     0xbcb5e0: stur            xzr, [x0, #7]
    // 0xbcb5e4: ldur            d0, [fp, #-0x48]
    // 0xbcb5e8: StoreField: r0->field_f = d0
    //     0xbcb5e8: stur            d0, [x0, #0xf]
    // 0xbcb5ec: r1 = Null
    //     0xbcb5ec: mov             x1, NULL
    // 0xbcb5f0: r2 = 4
    //     0xbcb5f0: mov             x2, #4
    // 0xbcb5f4: r0 = AllocateArray()
    //     0xbcb5f4: bl              #0x13df928  ; AllocateArrayStub
    // 0xbcb5f8: stur            x0, [fp, #-0x20]
    // 0xbcb5fc: r16 = Instance_Color
    //     0xbcb5fc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12c38] Obj!Color@12a2701
    //     0xbcb600: ldr             x16, [x16, #0xc38]
    // 0xbcb604: StoreField: r0->field_f = r16
    //     0xbcb604: stur            w16, [x0, #0xf]
    // 0xbcb608: r16 = Instance_Color
    //     0xbcb608: add             x16, PP, #0x87, lsl #12  ; [pp+0x87f08] Obj!Color@12a2791
    //     0xbcb60c: ldr             x16, [x16, #0xf08]
    // 0xbcb610: StoreField: r0->field_13 = r16
    //     0xbcb610: stur            w16, [x0, #0x13]
    // 0xbcb614: r1 = <Color>
    //     0xbcb614: add             x1, PP, #0x15, lsl #12  ; [pp+0x15a90] TypeArguments: <Color>
    //     0xbcb618: ldr             x1, [x1, #0xa90]
    // 0xbcb61c: r0 = AllocateGrowableArray()
    //     0xbcb61c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xbcb620: mov             x1, x0
    // 0xbcb624: ldur            x0, [fp, #-0x20]
    // 0xbcb628: stur            x1, [fp, #-0x28]
    // 0xbcb62c: StoreField: r1->field_f = r0
    //     0xbcb62c: stur            w0, [x1, #0xf]
    // 0xbcb630: r0 = 4
    //     0xbcb630: mov             x0, #4
    // 0xbcb634: StoreField: r1->field_b = r0
    //     0xbcb634: stur            w0, [x1, #0xb]
    // 0xbcb638: r0 = Gradient()
    //     0xbcb638: bl              #0xbcc170  ; AllocateGradientStub -> Gradient (size=0xc)
    // 0xbcb63c: mov             x1, x0
    // 0xbcb640: ldur            x2, [fp, #-8]
    // 0xbcb644: ldur            x3, [fp, #-0x18]
    // 0xbcb648: ldur            x5, [fp, #-0x28]
    // 0xbcb64c: stur            x0, [fp, #-8]
    // 0xbcb650: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xbcb650: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xbcb654: r0 = Gradient.linear()
    //     0xbcb654: bl              #0xbcb8a4  ; [dart:ui] Gradient::Gradient.linear
    // 0xbcb658: ldur            x0, [fp, #-8]
    // 0xbcb65c: ldur            x1, [fp, #-0x10]
    // 0xbcb660: StoreField: r1->field_8b = r0
    //     0xbcb660: stur            w0, [x1, #0x8b]
    //     0xbcb664: ldurb           w16, [x1, #-1]
    //     0xbcb668: ldurb           w17, [x0, #-1]
    //     0xbcb66c: and             x16, x17, x16, lsr #2
    //     0xbcb670: tst             x16, HEAP, lsr #32
    //     0xbcb674: b.eq            #0xbcb67c
    //     0xbcb678: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbcb67c: ldur            x1, [fp, #-0x40]
    // 0xbcb680: r0 = dispose()
    //     0xbcb680: bl              #0xbcb780  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0xbcb684: b               #0xbcb6c0
    // 0xbcb688: r4 = true
    //     0xbcb688: add             x4, NULL, #0x20  ; true
    // 0xbcb68c: cmp             x3, #2
    // 0xbcb690: b.gt            #0xbcb6a0
    // 0xbcb694: StoreField: r1->field_87 = r4
    //     0xbcb694: stur            w4, [x1, #0x87]
    // 0xbcb698: StoreField: r1->field_8b = rNULL
    //     0xbcb698: stur            NULL, [x1, #0x8b]
    // 0xbcb69c: b               #0xbcb6c0
    // 0xbcb6a0: r0 = false
    //     0xbcb6a0: add             x0, NULL, #0x30  ; false
    // 0xbcb6a4: StoreField: r1->field_87 = r0
    //     0xbcb6a4: stur            w0, [x1, #0x87]
    // 0xbcb6a8: StoreField: r1->field_8b = rNULL
    //     0xbcb6a8: stur            NULL, [x1, #0x8b]
    // 0xbcb6ac: b               #0xbcb6c0
    // 0xbcb6b0: ldur            x1, [fp, #-0x10]
    // 0xbcb6b4: r0 = false
    //     0xbcb6b4: add             x0, NULL, #0x30  ; false
    // 0xbcb6b8: StoreField: r1->field_87 = r0
    //     0xbcb6b8: stur            w0, [x1, #0x87]
    // 0xbcb6bc: StoreField: r1->field_8b = rNULL
    //     0xbcb6bc: stur            NULL, [x1, #0x8b]
    // 0xbcb6c0: r0 = Null
    //     0xbcb6c0: mov             x0, NULL
    // 0xbcb6c4: LeaveFrame
    //     0xbcb6c4: mov             SP, fp
    //     0xbcb6c8: ldp             fp, lr, [SP], #0x10
    // 0xbcb6cc: ret
    //     0xbcb6cc: ret             
    // 0xbcb6d0: r0 = StateError()
    //     0xbcb6d0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbcb6d4: mov             x1, x0
    // 0xbcb6d8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbcb6d8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbcb6dc: StoreField: r1->field_b = r0
    //     0xbcb6dc: stur            w0, [x1, #0xb]
    // 0xbcb6e0: mov             x0, x1
    // 0xbcb6e4: r0 = Throw()
    //     0xbcb6e4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbcb6e8: brk             #0
    // 0xbcb6ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcb6ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcb6f0: b               #0xbcb14c
    // 0xbcb6f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb6f4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcb6f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb6f8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcb6fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb6fc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcb700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb700: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcb704: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb704: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbcb708: SaveReg d0
    //     0xbcb708: str             q0, [SP, #-0x10]!
    // 0xbcb70c: SaveReg r1
    //     0xbcb70c: str             x1, [SP, #-8]!
    // 0xbcb710: r0 = AllocateDouble()
    //     0xbcb710: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbcb714: mov             x2, x0
    // 0xbcb718: RestoreReg r1
    //     0xbcb718: ldr             x1, [SP], #8
    // 0xbcb71c: RestoreReg d0
    //     0xbcb71c: ldr             q0, [SP], #0x10
    // 0xbcb720: b               #0xbcb3f8
    // 0xbcb724: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbcb724: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbcb728: stp             q0, q1, [SP, #-0x20]!
    // 0xbcb72c: r0 = AllocateDouble()
    //     0xbcb72c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbcb730: mov             x2, x0
    // 0xbcb734: ldp             q0, q1, [SP], #0x20
    // 0xbcb738: b               #0xbcb470
    // 0xbcb73c: SaveReg d0
    //     0xbcb73c: str             q0, [SP, #-0x10]!
    // 0xbcb740: SaveReg r2
    //     0xbcb740: str             x2, [SP, #-8]!
    // 0xbcb744: r0 = AllocateDouble()
    //     0xbcb744: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbcb748: mov             x3, x0
    // 0xbcb74c: RestoreReg r2
    //     0xbcb74c: ldr             x2, [SP], #8
    // 0xbcb750: RestoreReg d0
    //     0xbcb750: ldr             q0, [SP], #0x10
    // 0xbcb754: b               #0xbcb49c
  }
  get _ textDirection(/* No info */) {
    // ** addr: 0xbcb758, size: 0x28
    // 0xbcb758: LoadField: r2 = r1->field_63
    //     0xbcb758: ldur            w2, [x1, #0x63]
    // 0xbcb75c: DecompressPointer r2
    //     0xbcb75c: add             x2, x2, HEAP, lsl #32
    // 0xbcb760: LoadField: r0 = r2->field_1b
    //     0xbcb760: ldur            w0, [x2, #0x1b]
    // 0xbcb764: DecompressPointer r0
    //     0xbcb764: add             x0, x0, HEAP, lsl #32
    // 0xbcb768: cmp             w0, NULL
    // 0xbcb76c: b.eq            #0xbcb774
    // 0xbcb770: ret
    //     0xbcb770: ret             
    // 0xbcb774: EnterFrame
    //     0xbcb774: stp             fp, lr, [SP, #-0x10]!
    //     0xbcb778: mov             fp, SP
    // 0xbcb77c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbcb77c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ locale(/* No info */) {
    // ** addr: 0xbcc17c, size: 0x14
    // 0xbcc17c: LoadField: r2 = r1->field_63
    //     0xbcc17c: ldur            w2, [x1, #0x63]
    // 0xbcc180: DecompressPointer r2
    //     0xbcc180: add             x2, x2, HEAP, lsl #32
    // 0xbcc184: LoadField: r0 = r2->field_27
    //     0xbcc184: ldur            w0, [x2, #0x27]
    // 0xbcc188: DecompressPointer r0
    //     0xbcc188: add             x0, x0, HEAP, lsl #32
    // 0xbcc18c: ret
    //     0xbcc18c: ret             
  }
  get _ textScaler(/* No info */) {
    // ** addr: 0xbcc190, size: 0x14
    // 0xbcc190: LoadField: r2 = r1->field_63
    //     0xbcc190: ldur            w2, [x1, #0x63]
    // 0xbcc194: DecompressPointer r2
    //     0xbcc194: add             x2, x2, HEAP, lsl #32
    // 0xbcc198: LoadField: r0 = r2->field_1f
    //     0xbcc198: ldur            w0, [x2, #0x1f]
    // 0xbcc19c: DecompressPointer r0
    //     0xbcc19c: add             x0, x0, HEAP, lsl #32
    // 0xbcc1a0: ret
    //     0xbcc1a0: ret             
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf1ccc, size: 0x90
    // 0xbf1ccc: EnterFrame
    //     0xbf1ccc: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1cd0: mov             fp, SP
    // 0xbf1cd4: AllocStack(0x18)
    //     0xbf1cd4: sub             SP, SP, #0x18
    // 0xbf1cd8: SetupParameters(RenderParagraph this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xbf1cd8: mov             x5, x1
    //     0xbf1cdc: mov             x4, x2
    //     0xbf1ce0: stur            x1, [fp, #-8]
    //     0xbf1ce4: stur            x2, [fp, #-0x10]
    //     0xbf1ce8: stur            x3, [fp, #-0x18]
    // 0xbf1cec: CheckStackOverflow
    //     0xbf1cec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1cf0: cmp             SP, x16
    //     0xbf1cf4: b.ls            #0xbf1d54
    // 0xbf1cf8: mov             x0, x4
    // 0xbf1cfc: r2 = Null
    //     0xbf1cfc: mov             x2, NULL
    // 0xbf1d00: r1 = Null
    //     0xbf1d00: mov             x1, NULL
    // 0xbf1d04: r4 = 60
    //     0xbf1d04: mov             x4, #0x3c
    // 0xbf1d08: branchIfSmi(r0, 0xbf1d14)
    //     0xbf1d08: tbz             w0, #0, #0xbf1d14
    // 0xbf1d0c: r4 = LoadClassIdInstr(r0)
    //     0xbf1d0c: ldur            x4, [x0, #-1]
    //     0xbf1d10: ubfx            x4, x4, #0xc, #0x14
    // 0xbf1d14: r17 = -4710
    //     0xbf1d14: mov             x17, #-0x1266
    // 0xbf1d18: add             x4, x4, x17
    // 0xbf1d1c: cmp             x4, #0x109
    // 0xbf1d20: b.ls            #0xbf1d34
    // 0xbf1d24: r8 = RenderBox
    //     0xbf1d24: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf1d28: r3 = Null
    //     0xbf1d28: add             x3, PP, #0x98, lsl #12  ; [pp+0x98940] Null
    //     0xbf1d2c: ldr             x3, [x3, #0x940]
    // 0xbf1d30: r0 = RenderBox()
    //     0xbf1d30: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf1d34: ldur            x1, [fp, #-8]
    // 0xbf1d38: ldur            x2, [fp, #-0x10]
    // 0xbf1d3c: ldur            x3, [fp, #-0x18]
    // 0xbf1d40: r0 = defaultApplyPaintTransform()
    //     0xbf1d40: bl              #0xbf1d5c  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::defaultApplyPaintTransform
    // 0xbf1d44: r0 = Null
    //     0xbf1d44: mov             x0, NULL
    // 0xbf1d48: LeaveFrame
    //     0xbf1d48: mov             SP, fp
    //     0xbf1d4c: ldp             fp, lr, [SP], #0x10
    // 0xbf1d50: ret
    //     0xbf1d50: ret             
    // 0xbf1d54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf1d54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1d58: b               #0xbf1cf8
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf9c54, size: 0x558
    // 0xbf9c54: EnterFrame
    //     0xbf9c54: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9c58: mov             fp, SP
    // 0xbf9c5c: AllocStack(0x70)
    //     0xbf9c5c: sub             SP, SP, #0x70
    // 0xbf9c60: SetupParameters(RenderParagraph this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbf9c60: mov             x3, x1
    //     0xbf9c64: mov             x0, x2
    //     0xbf9c68: stur            x1, [fp, #-8]
    //     0xbf9c6c: stur            x2, [fp, #-0x10]
    // 0xbf9c70: CheckStackOverflow
    //     0xbf9c70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9c74: cmp             SP, x16
    //     0xbf9c78: b.ls            #0xbfa180
    // 0xbf9c7c: mov             x1, x3
    // 0xbf9c80: mov             x2, x0
    // 0xbf9c84: r0 = Shader._()
    //     0xbf9c84: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xbf9c88: ldur            x1, [fp, #-8]
    // 0xbf9c8c: r0 = text()
    //     0xbf9c8c: bl              #0xbfa1dc  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::text
    // 0xbf9c90: mov             x1, x0
    // 0xbf9c94: r0 = getSemanticsInformation()
    //     0xbf9c94: bl              #0xbf8a84  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::getSemanticsInformation
    // 0xbf9c98: mov             x1, x0
    // 0xbf9c9c: ldur            x2, [fp, #-8]
    // 0xbf9ca0: StoreField: r2->field_93 = r0
    //     0xbf9ca0: stur            w0, [x2, #0x93]
    //     0xbf9ca4: ldurb           w16, [x2, #-1]
    //     0xbf9ca8: ldurb           w17, [x0, #-1]
    //     0xbf9cac: and             x16, x17, x16, lsr #2
    //     0xbf9cb0: tst             x16, HEAP, lsr #32
    //     0xbf9cb4: b.eq            #0xbf9cbc
    //     0xbf9cb8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbf9cbc: LoadField: r0 = r1->field_b
    //     0xbf9cbc: ldur            w0, [x1, #0xb]
    // 0xbf9cc0: r3 = LoadInt32Instr(r0)
    //     0xbf9cc0: sbfx            x3, x0, #1, #0x1f
    // 0xbf9cc4: LoadField: r0 = r1->field_f
    //     0xbf9cc4: ldur            w0, [x1, #0xf]
    // 0xbf9cc8: DecompressPointer r0
    //     0xbf9cc8: add             x0, x0, HEAP, lsl #32
    // 0xbf9ccc: r4 = false
    //     0xbf9ccc: add             x4, NULL, #0x30  ; false
    // 0xbf9cd0: r1 = 0
    //     0xbf9cd0: mov             x1, #0
    // 0xbf9cd4: CheckStackOverflow
    //     0xbf9cd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9cd8: cmp             SP, x16
    //     0xbf9cdc: b.ls            #0xbfa188
    // 0xbf9ce0: cmp             x1, x3
    // 0xbf9ce4: b.ge            #0xbf9d38
    // 0xbf9ce8: ArrayLoad: r5 = r0[r1]  ; Unknown_4
    //     0xbf9ce8: add             x16, x0, x1, lsl #2
    //     0xbf9cec: ldur            w5, [x16, #0xf]
    // 0xbf9cf0: DecompressPointer r5
    //     0xbf9cf0: add             x5, x5, HEAP, lsl #32
    // 0xbf9cf4: add             x6, x1, #1
    // 0xbf9cf8: LoadField: r1 = r5->field_13
    //     0xbf9cf8: ldur            w1, [x5, #0x13]
    // 0xbf9cfc: DecompressPointer r1
    //     0xbf9cfc: add             x1, x1, HEAP, lsl #32
    // 0xbf9d00: cmp             w1, NULL
    // 0xbf9d04: b.ne            #0xbf9d24
    // 0xbf9d08: tbnz            w4, #4, #0xbf9d14
    // 0xbf9d0c: r4 = true
    //     0xbf9d0c: add             x4, NULL, #0x20  ; true
    // 0xbf9d10: b               #0xbf9d1c
    // 0xbf9d14: ArrayLoad: r4 = r5[0]  ; List_4
    //     0xbf9d14: ldur            w4, [x5, #0x17]
    // 0xbf9d18: DecompressPointer r4
    //     0xbf9d18: add             x4, x4, HEAP, lsl #32
    // 0xbf9d1c: mov             x1, x6
    // 0xbf9d20: b               #0xbf9cd4
    // 0xbf9d24: ldur            x0, [fp, #-0x10]
    // 0xbf9d28: r1 = true
    //     0xbf9d28: add             x1, NULL, #0x20  ; true
    // 0xbf9d2c: ArrayStore: r0[0] = r1  ; List_4
    //     0xbf9d2c: stur            w1, [x0, #0x17]
    // 0xbf9d30: StoreField: r0->field_7 = r1
    //     0xbf9d30: stur            w1, [x0, #7]
    // 0xbf9d34: b               #0xbfa150
    // 0xbf9d38: ldur            x0, [fp, #-0x10]
    // 0xbf9d3c: r1 = true
    //     0xbf9d3c: add             x1, NULL, #0x20  ; true
    // 0xbf9d40: tbnz            w4, #4, #0xbf9d60
    // 0xbf9d44: r1 = Function '_childSemanticsConfigurationsDelegate@215149678':.
    //     0xbf9d44: add             x1, PP, #0x98, lsl #12  ; [pp+0x988e0] AnonymousClosure: (0xbfa204), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_childSemanticsConfigurationsDelegate (0xbfa240)
    //     0xbf9d48: ldr             x1, [x1, #0x8e0]
    // 0xbf9d4c: r0 = AllocateClosure()
    //     0xbf9d4c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbf9d50: ldur            x1, [fp, #-0x10]
    // 0xbf9d54: mov             x2, x0
    // 0xbf9d58: r0 = childConfigurationsDelegate=()
    //     0xbf9d58: bl              #0xbfa1ac  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::childConfigurationsDelegate=
    // 0xbf9d5c: b               #0xbfa150
    // 0xbf9d60: LoadField: r0 = r2->field_6b
    //     0xbf9d60: ldur            w0, [x2, #0x6b]
    // 0xbf9d64: DecompressPointer r0
    //     0xbf9d64: add             x0, x0, HEAP, lsl #32
    // 0xbf9d68: cmp             w0, NULL
    // 0xbf9d6c: b.ne            #0xbfa0c0
    // 0xbf9d70: r0 = StringBuffer()
    //     0xbf9d70: bl              #0x7e51d4  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xbf9d74: mov             x1, x0
    // 0xbf9d78: stur            x0, [fp, #-0x18]
    // 0xbf9d7c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbf9d7c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbf9d80: r0 = StringBuffer()
    //     0xbf9d80: bl              #0x7e4a4c  ; [dart:core] StringBuffer::StringBuffer
    // 0xbf9d84: r1 = <StringAttribute>
    //     0xbf9d84: ldr             x1, [PP, #0x2720]  ; [pp+0x2720] TypeArguments: <StringAttribute>
    // 0xbf9d88: r2 = 0
    //     0xbf9d88: mov             x2, #0
    // 0xbf9d8c: r0 = _GrowableList()
    //     0xbf9d8c: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbf9d90: mov             x3, x0
    // 0xbf9d94: ldur            x2, [fp, #-8]
    // 0xbf9d98: stur            x3, [fp, #-0x48]
    // 0xbf9d9c: LoadField: r4 = r2->field_93
    //     0xbf9d9c: ldur            w4, [x2, #0x93]
    // 0xbf9da0: DecompressPointer r4
    //     0xbf9da0: add             x4, x4, HEAP, lsl #32
    // 0xbf9da4: stur            x4, [fp, #-0x40]
    // 0xbf9da8: cmp             w4, NULL
    // 0xbf9dac: b.eq            #0xbfa190
    // 0xbf9db0: LoadField: r0 = r4->field_b
    //     0xbf9db0: ldur            w0, [x4, #0xb]
    // 0xbf9db4: r5 = LoadInt32Instr(r0)
    //     0xbf9db4: sbfx            x5, x0, #1, #0x1f
    // 0xbf9db8: stur            x5, [fp, #-0x38]
    // 0xbf9dbc: r6 = 0
    //     0xbf9dbc: mov             x6, #0
    // 0xbf9dc0: r0 = 0
    //     0xbf9dc0: mov             x0, #0
    // 0xbf9dc4: stur            x6, [fp, #-0x30]
    // 0xbf9dc8: CheckStackOverflow
    //     0xbf9dc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9dcc: cmp             SP, x16
    //     0xbf9dd0: b.ls            #0xbfa194
    // 0xbf9dd4: LoadField: r1 = r4->field_b
    //     0xbf9dd4: ldur            w1, [x4, #0xb]
    // 0xbf9dd8: r7 = LoadInt32Instr(r1)
    //     0xbf9dd8: sbfx            x7, x1, #1, #0x1f
    // 0xbf9ddc: cmp             x5, x7
    // 0xbf9de0: b.ne            #0xbfa160
    // 0xbf9de4: cmp             x0, x7
    // 0xbf9de8: b.ge            #0xbfa024
    // 0xbf9dec: LoadField: r1 = r4->field_f
    //     0xbf9dec: ldur            w1, [x4, #0xf]
    // 0xbf9df0: DecompressPointer r1
    //     0xbf9df0: add             x1, x1, HEAP, lsl #32
    // 0xbf9df4: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0xbf9df4: add             x16, x1, x0, lsl #2
    //     0xbf9df8: ldur            w7, [x16, #0xf]
    // 0xbf9dfc: DecompressPointer r7
    //     0xbf9dfc: add             x7, x7, HEAP, lsl #32
    // 0xbf9e00: add             x8, x0, #1
    // 0xbf9e04: stur            x8, [fp, #-0x28]
    // 0xbf9e08: LoadField: r0 = r7->field_b
    //     0xbf9e08: ldur            w0, [x7, #0xb]
    // 0xbf9e0c: DecompressPointer r0
    //     0xbf9e0c: add             x0, x0, HEAP, lsl #32
    // 0xbf9e10: cmp             w0, NULL
    // 0xbf9e14: b.ne            #0xbf9e28
    // 0xbf9e18: LoadField: r0 = r7->field_7
    //     0xbf9e18: ldur            w0, [x7, #7]
    // 0xbf9e1c: DecompressPointer r0
    //     0xbf9e1c: add             x0, x0, HEAP, lsl #32
    // 0xbf9e20: mov             x9, x0
    // 0xbf9e24: b               #0xbf9e2c
    // 0xbf9e28: mov             x9, x0
    // 0xbf9e2c: stur            x9, [fp, #-0x20]
    // 0xbf9e30: LoadField: r1 = r7->field_1f
    //     0xbf9e30: ldur            w1, [x7, #0x1f]
    // 0xbf9e34: DecompressPointer r1
    //     0xbf9e34: add             x1, x1, HEAP, lsl #32
    // 0xbf9e38: r0 = LoadClassIdInstr(r1)
    //     0xbf9e38: ldur            x0, [x1, #-1]
    //     0xbf9e3c: ubfx            x0, x0, #0xc, #0x14
    // 0xbf9e40: r0 = GDT[cid_x0 + 0x12641]()
    //     0xbf9e40: mov             x17, #0x2641
    //     0xbf9e44: movk            x17, #1, lsl #16
    //     0xbf9e48: add             lr, x0, x17
    //     0xbf9e4c: ldr             lr, [x21, lr, lsl #3]
    //     0xbf9e50: blr             lr
    // 0xbf9e54: mov             x2, x0
    // 0xbf9e58: stur            x2, [fp, #-0x50]
    // 0xbf9e5c: ldur            x3, [fp, #-0x48]
    // 0xbf9e60: ldur            x4, [fp, #-0x30]
    // 0xbf9e64: CheckStackOverflow
    //     0xbf9e64: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9e68: cmp             SP, x16
    //     0xbf9e6c: b.ls            #0xbfa19c
    // 0xbf9e70: r0 = LoadClassIdInstr(r2)
    //     0xbf9e70: ldur            x0, [x2, #-1]
    //     0xbf9e74: ubfx            x0, x0, #0xc, #0x14
    // 0xbf9e78: mov             x1, x2
    // 0xbf9e7c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xbf9e7c: mov             x17, #0x845b
    //     0xbf9e80: movk            x17, #1, lsl #16
    //     0xbf9e84: add             lr, x0, x17
    //     0xbf9e88: ldr             lr, [x21, lr, lsl #3]
    //     0xbf9e8c: blr             lr
    // 0xbf9e90: tbnz            w0, #4, #0xbf9fbc
    // 0xbf9e94: ldur            x3, [fp, #-0x48]
    // 0xbf9e98: ldur            x4, [fp, #-0x30]
    // 0xbf9e9c: ldur            x2, [fp, #-0x50]
    // 0xbf9ea0: r0 = LoadClassIdInstr(r2)
    //     0xbf9ea0: ldur            x0, [x2, #-1]
    //     0xbf9ea4: ubfx            x0, x0, #0xc, #0x14
    // 0xbf9ea8: mov             x1, x2
    // 0xbf9eac: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xbf9eac: mov             x17, #0x7d4c
    //     0xbf9eb0: movk            x17, #1, lsl #16
    //     0xbf9eb4: add             lr, x0, x17
    //     0xbf9eb8: ldr             lr, [x21, lr, lsl #3]
    //     0xbf9ebc: blr             lr
    // 0xbf9ec0: stur            x0, [fp, #-0x68]
    // 0xbf9ec4: LoadField: r1 = r0->field_b
    //     0xbf9ec4: ldur            w1, [x0, #0xb]
    // 0xbf9ec8: DecompressPointer r1
    //     0xbf9ec8: add             x1, x1, HEAP, lsl #32
    // 0xbf9ecc: LoadField: r2 = r1->field_7
    //     0xbf9ecc: ldur            x2, [x1, #7]
    // 0xbf9ed0: ldur            x3, [fp, #-0x30]
    // 0xbf9ed4: add             x4, x3, x2
    // 0xbf9ed8: stur            x4, [fp, #-0x60]
    // 0xbf9edc: LoadField: r2 = r1->field_f
    //     0xbf9edc: ldur            x2, [x1, #0xf]
    // 0xbf9ee0: add             x1, x3, x2
    // 0xbf9ee4: stur            x1, [fp, #-0x58]
    // 0xbf9ee8: r0 = TextRange()
    //     0xbf9ee8: bl              #0x83839c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0xbf9eec: mov             x1, x0
    // 0xbf9ef0: ldur            x0, [fp, #-0x60]
    // 0xbf9ef4: StoreField: r1->field_7 = r0
    //     0xbf9ef4: stur            x0, [x1, #7]
    // 0xbf9ef8: ldur            x0, [fp, #-0x58]
    // 0xbf9efc: StoreField: r1->field_f = r0
    //     0xbf9efc: stur            x0, [x1, #0xf]
    // 0xbf9f00: ldur            x0, [fp, #-0x68]
    // 0xbf9f04: r2 = LoadClassIdInstr(r0)
    //     0xbf9f04: ldur            x2, [x0, #-1]
    //     0xbf9f08: ubfx            x2, x2, #0xc, #0x14
    // 0xbf9f0c: mov             x16, x1
    // 0xbf9f10: mov             x1, x2
    // 0xbf9f14: mov             x2, x16
    // 0xbf9f18: mov             x16, x0
    // 0xbf9f1c: mov             x0, x1
    // 0xbf9f20: mov             x1, x16
    // 0xbf9f24: r0 = GDT[cid_x0 + -0xfec]()
    //     0xbf9f24: sub             lr, x0, #0xfec
    //     0xbf9f28: ldr             lr, [x21, lr, lsl #3]
    //     0xbf9f2c: blr             lr
    // 0xbf9f30: mov             x2, x0
    // 0xbf9f34: ldur            x0, [fp, #-0x48]
    // 0xbf9f38: stur            x2, [fp, #-0x68]
    // 0xbf9f3c: LoadField: r1 = r0->field_b
    //     0xbf9f3c: ldur            w1, [x0, #0xb]
    // 0xbf9f40: LoadField: r3 = r0->field_f
    //     0xbf9f40: ldur            w3, [x0, #0xf]
    // 0xbf9f44: DecompressPointer r3
    //     0xbf9f44: add             x3, x3, HEAP, lsl #32
    // 0xbf9f48: LoadField: r4 = r3->field_b
    //     0xbf9f48: ldur            w4, [x3, #0xb]
    // 0xbf9f4c: r3 = LoadInt32Instr(r1)
    //     0xbf9f4c: sbfx            x3, x1, #1, #0x1f
    // 0xbf9f50: stur            x3, [fp, #-0x58]
    // 0xbf9f54: r1 = LoadInt32Instr(r4)
    //     0xbf9f54: sbfx            x1, x4, #1, #0x1f
    // 0xbf9f58: cmp             x3, x1
    // 0xbf9f5c: b.ne            #0xbf9f68
    // 0xbf9f60: mov             x1, x0
    // 0xbf9f64: r0 = _growToNextCapacity()
    //     0xbf9f64: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbf9f68: ldur            x2, [fp, #-0x48]
    // 0xbf9f6c: ldur            x3, [fp, #-0x58]
    // 0xbf9f70: add             x0, x3, #1
    // 0xbf9f74: lsl             x1, x0, #1
    // 0xbf9f78: StoreField: r2->field_b = r1
    //     0xbf9f78: stur            w1, [x2, #0xb]
    // 0xbf9f7c: LoadField: r1 = r2->field_f
    //     0xbf9f7c: ldur            w1, [x2, #0xf]
    // 0xbf9f80: DecompressPointer r1
    //     0xbf9f80: add             x1, x1, HEAP, lsl #32
    // 0xbf9f84: ldur            x0, [fp, #-0x68]
    // 0xbf9f88: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbf9f88: add             x25, x1, x3, lsl #2
    //     0xbf9f8c: add             x25, x25, #0xf
    //     0xbf9f90: str             w0, [x25]
    //     0xbf9f94: tbz             w0, #0, #0xbf9fb0
    //     0xbf9f98: ldurb           w16, [x1, #-1]
    //     0xbf9f9c: ldurb           w17, [x0, #-1]
    //     0xbf9fa0: and             x16, x17, x16, lsr #2
    //     0xbf9fa4: tst             x16, HEAP, lsr #32
    //     0xbf9fa8: b.eq            #0xbf9fb0
    //     0xbf9fac: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbf9fb0: mov             x3, x2
    // 0xbf9fb4: ldur            x2, [fp, #-0x50]
    // 0xbf9fb8: b               #0xbf9e60
    // 0xbf9fbc: ldur            x2, [fp, #-0x48]
    // 0xbf9fc0: ldur            x1, [fp, #-0x20]
    // 0xbf9fc4: r0 = LoadClassIdInstr(r1)
    //     0xbf9fc4: ldur            x0, [x1, #-1]
    //     0xbf9fc8: ubfx            x0, x0, #0xc, #0x14
    // 0xbf9fcc: str             x1, [SP]
    // 0xbf9fd0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xbf9fd0: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xbf9fd4: r0 = GDT[cid_x0 + 0x91c1]()
    //     0xbf9fd4: mov             x17, #0x91c1
    //     0xbf9fd8: add             lr, x0, x17
    //     0xbf9fdc: ldr             lr, [x21, lr, lsl #3]
    //     0xbf9fe0: blr             lr
    // 0xbf9fe4: LoadField: r1 = r0->field_7
    //     0xbf9fe4: ldur            w1, [x0, #7]
    // 0xbf9fe8: cbz             w1, #0xbf9ff8
    // 0xbf9fec: ldur            x1, [fp, #-0x18]
    // 0xbf9ff0: mov             x2, x0
    // 0xbf9ff4: r0 = _writeString()
    //     0xbf9ff4: bl              #0x7e4c0c  ; [dart:core] StringBuffer::_writeString
    // 0xbf9ff8: ldur            x1, [fp, #-0x30]
    // 0xbf9ffc: ldur            x0, [fp, #-0x20]
    // 0xbfa000: LoadField: r2 = r0->field_7
    //     0xbfa000: ldur            w2, [x0, #7]
    // 0xbfa004: r0 = LoadInt32Instr(r2)
    //     0xbfa004: sbfx            x0, x2, #1, #0x1f
    // 0xbfa008: add             x6, x1, x0
    // 0xbfa00c: ldur            x0, [fp, #-0x28]
    // 0xbfa010: ldur            x2, [fp, #-8]
    // 0xbfa014: ldur            x3, [fp, #-0x48]
    // 0xbfa018: ldur            x4, [fp, #-0x40]
    // 0xbfa01c: ldur            x5, [fp, #-0x38]
    // 0xbfa020: b               #0xbf9dc4
    // 0xbfa024: mov             x1, x2
    // 0xbfa028: mov             x0, x3
    // 0xbfa02c: ldur            x16, [fp, #-0x18]
    // 0xbfa030: str             x16, [SP]
    // 0xbfa034: r0 = toString()
    //     0xbfa034: bl              #0x1101d44  ; [dart:core] StringBuffer::toString
    // 0xbfa038: stur            x0, [fp, #-0x18]
    // 0xbfa03c: r0 = AttributedString()
    //     0xbfa03c: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xbfa040: mov             x3, x0
    // 0xbfa044: ldur            x0, [fp, #-0x18]
    // 0xbfa048: stur            x3, [fp, #-0x20]
    // 0xbfa04c: StoreField: r3->field_7 = r0
    //     0xbfa04c: stur            w0, [x3, #7]
    // 0xbfa050: ldur            x0, [fp, #-0x48]
    // 0xbfa054: StoreField: r3->field_b = r0
    //     0xbfa054: stur            w0, [x3, #0xb]
    // 0xbfa058: r1 = Null
    //     0xbfa058: mov             x1, NULL
    // 0xbfa05c: r2 = 2
    //     0xbfa05c: mov             x2, #2
    // 0xbfa060: r0 = AllocateArray()
    //     0xbfa060: bl              #0x13df928  ; AllocateArrayStub
    // 0xbfa064: mov             x2, x0
    // 0xbfa068: ldur            x0, [fp, #-0x20]
    // 0xbfa06c: stur            x2, [fp, #-0x18]
    // 0xbfa070: StoreField: r2->field_f = r0
    //     0xbfa070: stur            w0, [x2, #0xf]
    // 0xbfa074: r1 = <AttributedString>
    //     0xbfa074: add             x1, PP, #0x98, lsl #12  ; [pp+0x988e8] TypeArguments: <AttributedString>
    //     0xbfa078: ldr             x1, [x1, #0x8e8]
    // 0xbfa07c: r0 = AllocateGrowableArray()
    //     0xbfa07c: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0xbfa080: mov             x1, x0
    // 0xbfa084: ldur            x0, [fp, #-0x18]
    // 0xbfa088: StoreField: r1->field_f = r0
    //     0xbfa088: stur            w0, [x1, #0xf]
    // 0xbfa08c: r0 = 2
    //     0xbfa08c: mov             x0, #2
    // 0xbfa090: StoreField: r1->field_b = r0
    //     0xbfa090: stur            w0, [x1, #0xb]
    // 0xbfa094: mov             x0, x1
    // 0xbfa098: ldur            x2, [fp, #-8]
    // 0xbfa09c: StoreField: r2->field_6b = r0
    //     0xbfa09c: stur            w0, [x2, #0x6b]
    //     0xbfa0a0: ldurb           w16, [x2, #-1]
    //     0xbfa0a4: ldurb           w17, [x0, #-1]
    //     0xbfa0a8: and             x16, x17, x16, lsr #2
    //     0xbfa0ac: tst             x16, HEAP, lsr #32
    //     0xbfa0b0: b.eq            #0xbfa0b8
    //     0xbfa0b4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbfa0b8: mov             x5, x1
    // 0xbfa0bc: b               #0xbfa0c4
    // 0xbfa0c0: mov             x5, x0
    // 0xbfa0c4: ldur            x4, [fp, #-0x10]
    // 0xbfa0c8: r3 = true
    //     0xbfa0c8: add             x3, NULL, #0x20  ; true
    // 0xbfa0cc: LoadField: r0 = r5->field_b
    //     0xbfa0cc: ldur            w0, [x5, #0xb]
    // 0xbfa0d0: r1 = LoadInt32Instr(r0)
    //     0xbfa0d0: sbfx            x1, x0, #1, #0x1f
    // 0xbfa0d4: mov             x0, x1
    // 0xbfa0d8: r1 = 0
    //     0xbfa0d8: mov             x1, #0
    // 0xbfa0dc: cmp             x1, x0
    // 0xbfa0e0: b.hs            #0xbfa1a4
    // 0xbfa0e4: LoadField: r0 = r5->field_f
    //     0xbfa0e4: ldur            w0, [x5, #0xf]
    // 0xbfa0e8: DecompressPointer r0
    //     0xbfa0e8: add             x0, x0, HEAP, lsl #32
    // 0xbfa0ec: LoadField: r1 = r0->field_f
    //     0xbfa0ec: ldur            w1, [x0, #0xf]
    // 0xbfa0f0: DecompressPointer r1
    //     0xbfa0f0: add             x1, x1, HEAP, lsl #32
    // 0xbfa0f4: mov             x0, x1
    // 0xbfa0f8: StoreField: r4->field_67 = r0
    //     0xbfa0f8: stur            w0, [x4, #0x67]
    //     0xbfa0fc: ldurb           w16, [x4, #-1]
    //     0xbfa100: ldurb           w17, [x0, #-1]
    //     0xbfa104: and             x16, x17, x16, lsr #2
    //     0xbfa108: tst             x16, HEAP, lsr #32
    //     0xbfa10c: b.eq            #0xbfa114
    //     0xbfa110: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbfa114: StoreField: r4->field_1f = r3
    //     0xbfa114: stur            w3, [x4, #0x1f]
    // 0xbfa118: LoadField: r0 = r2->field_63
    //     0xbfa118: ldur            w0, [x2, #0x63]
    // 0xbfa11c: DecompressPointer r0
    //     0xbfa11c: add             x0, x0, HEAP, lsl #32
    // 0xbfa120: LoadField: r1 = r0->field_1b
    //     0xbfa120: ldur            w1, [x0, #0x1b]
    // 0xbfa124: DecompressPointer r1
    //     0xbfa124: add             x1, x1, HEAP, lsl #32
    // 0xbfa128: cmp             w1, NULL
    // 0xbfa12c: b.eq            #0xbfa1a8
    // 0xbfa130: mov             x0, x1
    // 0xbfa134: StoreField: r4->field_83 = r0
    //     0xbfa134: stur            w0, [x4, #0x83]
    //     0xbfa138: ldurb           w16, [x4, #-1]
    //     0xbfa13c: ldurb           w17, [x0, #-1]
    //     0xbfa140: and             x16, x17, x16, lsr #2
    //     0xbfa144: tst             x16, HEAP, lsr #32
    //     0xbfa148: b.eq            #0xbfa150
    //     0xbfa14c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbfa150: r0 = Null
    //     0xbfa150: mov             x0, NULL
    // 0xbfa154: LeaveFrame
    //     0xbfa154: mov             SP, fp
    //     0xbfa158: ldp             fp, lr, [SP], #0x10
    // 0xbfa15c: ret
    //     0xbfa15c: ret             
    // 0xbfa160: mov             x0, x4
    // 0xbfa164: r0 = ConcurrentModificationError()
    //     0xbfa164: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbfa168: mov             x1, x0
    // 0xbfa16c: ldur            x0, [fp, #-0x40]
    // 0xbfa170: StoreField: r1->field_b = r0
    //     0xbfa170: stur            w0, [x1, #0xb]
    // 0xbfa174: mov             x0, x1
    // 0xbfa178: r0 = Throw()
    //     0xbfa178: bl              #0x13ddb2c  ; ThrowStub
    // 0xbfa17c: brk             #0
    // 0xbfa180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa180: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa184: b               #0xbf9c7c
    // 0xbfa188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa188: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa18c: b               #0xbf9ce0
    // 0xbfa190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfa190: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbfa194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa194: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa198: b               #0xbf9dd4
    // 0xbfa19c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa19c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa1a0: b               #0xbf9e70
    // 0xbfa1a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbfa1a4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbfa1a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfa1a8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ text(/* No info */) {
    // ** addr: 0xbfa1dc, size: 0x28
    // 0xbfa1dc: LoadField: r2 = r1->field_63
    //     0xbfa1dc: ldur            w2, [x1, #0x63]
    // 0xbfa1e0: DecompressPointer r2
    //     0xbfa1e0: add             x2, x2, HEAP, lsl #32
    // 0xbfa1e4: LoadField: r0 = r2->field_f
    //     0xbfa1e4: ldur            w0, [x2, #0xf]
    // 0xbfa1e8: DecompressPointer r0
    //     0xbfa1e8: add             x0, x0, HEAP, lsl #32
    // 0xbfa1ec: cmp             w0, NULL
    // 0xbfa1f0: b.eq            #0xbfa1f8
    // 0xbfa1f4: ret
    //     0xbfa1f4: ret             
    // 0xbfa1f8: EnterFrame
    //     0xbfa1f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa1fc: mov             fp, SP
    // 0xbfa200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfa200: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ChildSemanticsConfigurationsResult _childSemanticsConfigurationsDelegate(dynamic, List<SemanticsConfiguration>) {
    // ** addr: 0xbfa204, size: 0x3c
    // 0xbfa204: EnterFrame
    //     0xbfa204: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa208: mov             fp, SP
    // 0xbfa20c: ldr             x0, [fp, #0x18]
    // 0xbfa210: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbfa210: ldur            w1, [x0, #0x17]
    // 0xbfa214: DecompressPointer r1
    //     0xbfa214: add             x1, x1, HEAP, lsl #32
    // 0xbfa218: CheckStackOverflow
    //     0xbfa218: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfa21c: cmp             SP, x16
    //     0xbfa220: b.ls            #0xbfa238
    // 0xbfa224: ldr             x2, [fp, #0x10]
    // 0xbfa228: r0 = _childSemanticsConfigurationsDelegate()
    //     0xbfa228: bl              #0xbfa240  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_childSemanticsConfigurationsDelegate
    // 0xbfa22c: LeaveFrame
    //     0xbfa22c: mov             SP, fp
    //     0xbfa230: ldp             fp, lr, [SP], #0x10
    // 0xbfa234: ret
    //     0xbfa234: ret             
    // 0xbfa238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa238: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa23c: b               #0xbfa224
  }
  _ _childSemanticsConfigurationsDelegate(/* No info */) {
    // ** addr: 0xbfa240, size: 0x4bc
    // 0xbfa240: EnterFrame
    //     0xbfa240: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa244: mov             fp, SP
    // 0xbfa248: AllocStack(0xa0)
    //     0xbfa248: sub             SP, SP, #0xa0
    // 0xbfa24c: SetupParameters(RenderParagraph this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xbfa24c: stur            x1, [fp, #-8]
    //     0xbfa250: stur            x2, [fp, #-0x10]
    // 0xbfa254: CheckStackOverflow
    //     0xbfa254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfa258: cmp             SP, x16
    //     0xbfa25c: b.ls            #0xbfa6e0
    // 0xbfa260: r0 = ChildSemanticsConfigurationsResultBuilder()
    //     0xbfa260: bl              #0xbf6f1c  ; AllocateChildSemanticsConfigurationsResultBuilderStub -> ChildSemanticsConfigurationsResultBuilder (size=0x10)
    // 0xbfa264: mov             x1, x0
    // 0xbfa268: stur            x0, [fp, #-0x18]
    // 0xbfa26c: r0 = ChildSemanticsConfigurationsResultBuilder()
    //     0xbfa26c: bl              #0xbf6de4  ; [package:flutter/src/semantics/semantics.dart] ChildSemanticsConfigurationsResultBuilder::ChildSemanticsConfigurationsResultBuilder
    // 0xbfa270: ldur            x0, [fp, #-8]
    // 0xbfa274: LoadField: r1 = r0->field_6f
    //     0xbfa274: ldur            w1, [x0, #0x6f]
    // 0xbfa278: DecompressPointer r1
    //     0xbfa278: add             x1, x1, HEAP, lsl #32
    // 0xbfa27c: cmp             w1, NULL
    // 0xbfa280: b.ne            #0xbfa2c4
    // 0xbfa284: LoadField: r1 = r0->field_93
    //     0xbfa284: ldur            w1, [x0, #0x93]
    // 0xbfa288: DecompressPointer r1
    //     0xbfa288: add             x1, x1, HEAP, lsl #32
    // 0xbfa28c: cmp             w1, NULL
    // 0xbfa290: b.eq            #0xbfa6e8
    // 0xbfa294: r0 = combineSemanticsInfo()
    //     0xbfa294: bl              #0xbfa964  ; [package:flutter/src/painting/inline_span.dart] ::combineSemanticsInfo
    // 0xbfa298: mov             x1, x0
    // 0xbfa29c: ldur            x4, [fp, #-8]
    // 0xbfa2a0: StoreField: r4->field_6f = r0
    //     0xbfa2a0: stur            w0, [x4, #0x6f]
    //     0xbfa2a4: ldurb           w16, [x4, #-1]
    //     0xbfa2a8: ldurb           w17, [x0, #-1]
    //     0xbfa2ac: and             x16, x17, x16, lsr #2
    //     0xbfa2b0: tst             x16, HEAP, lsr #32
    //     0xbfa2b4: b.eq            #0xbfa2bc
    //     0xbfa2b8: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xbfa2bc: mov             x5, x1
    // 0xbfa2c0: b               #0xbfa2cc
    // 0xbfa2c4: mov             x4, x0
    // 0xbfa2c8: mov             x5, x1
    // 0xbfa2cc: ldur            x0, [fp, #-0x18]
    // 0xbfa2d0: stur            x5, [fp, #-0x58]
    // 0xbfa2d4: LoadField: r1 = r5->field_b
    //     0xbfa2d4: ldur            w1, [x5, #0xb]
    // 0xbfa2d8: r6 = LoadInt32Instr(r1)
    //     0xbfa2d8: sbfx            x6, x1, #1, #0x1f
    // 0xbfa2dc: stur            x6, [fp, #-0x50]
    // 0xbfa2e0: LoadField: r7 = r0->field_7
    //     0xbfa2e0: ldur            w7, [x0, #7]
    // 0xbfa2e4: DecompressPointer r7
    //     0xbfa2e4: add             x7, x7, HEAP, lsl #32
    // 0xbfa2e8: stur            x7, [fp, #-0x48]
    // 0xbfa2ec: r12 = 0
    //     0xbfa2ec: mov             x12, #0
    // 0xbfa2f0: r11 = 0
    //     0xbfa2f0: mov             x11, #0
    // 0xbfa2f4: r10 = 0
    //     0xbfa2f4: mov             x10, #0
    // 0xbfa2f8: r9 = Null
    //     0xbfa2f8: mov             x9, NULL
    // 0xbfa2fc: r1 = 0
    //     0xbfa2fc: mov             x1, #0
    // 0xbfa300: ldur            x8, [fp, #-0x10]
    // 0xbfa304: stur            x12, [fp, #-0x28]
    // 0xbfa308: stur            x11, [fp, #-0x30]
    // 0xbfa30c: stur            x10, [fp, #-0x38]
    // 0xbfa310: stur            x9, [fp, #-0x40]
    // 0xbfa314: CheckStackOverflow
    //     0xbfa314: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfa318: cmp             SP, x16
    //     0xbfa31c: b.ls            #0xbfa6ec
    // 0xbfa320: LoadField: r2 = r5->field_b
    //     0xbfa320: ldur            w2, [x5, #0xb]
    // 0xbfa324: r3 = LoadInt32Instr(r2)
    //     0xbfa324: sbfx            x3, x2, #1, #0x1f
    // 0xbfa328: cmp             x6, x3
    // 0xbfa32c: b.ne            #0xbfa6c0
    // 0xbfa330: cmp             x1, x3
    // 0xbfa334: b.ge            #0xbfa684
    // 0xbfa338: LoadField: r2 = r5->field_f
    //     0xbfa338: ldur            w2, [x5, #0xf]
    // 0xbfa33c: DecompressPointer r2
    //     0xbfa33c: add             x2, x2, HEAP, lsl #32
    // 0xbfa340: ArrayLoad: r3 = r2[r1]  ; Unknown_4
    //     0xbfa340: add             x16, x2, x1, lsl #2
    //     0xbfa344: ldur            w3, [x16, #0xf]
    // 0xbfa348: DecompressPointer r3
    //     0xbfa348: add             x3, x3, HEAP, lsl #32
    // 0xbfa34c: add             x13, x1, #1
    // 0xbfa350: stur            x13, [fp, #-0x20]
    // 0xbfa354: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xbfa354: ldur            w1, [x3, #0x17]
    // 0xbfa358: DecompressPointer r1
    //     0xbfa358: add             x1, x1, HEAP, lsl #32
    // 0xbfa35c: tbnz            w1, #4, #0xbfa64c
    // 0xbfa360: cmp             w9, NULL
    // 0xbfa364: b.eq            #0xbfa408
    // 0xbfa368: mov             x1, x4
    // 0xbfa36c: mov             x2, x9
    // 0xbfa370: mov             x3, x10
    // 0xbfa374: r0 = _createSemanticsConfigForTextInfo()
    //     0xbfa374: bl              #0xbfa708  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_createSemanticsConfigForTextInfo
    // 0xbfa378: mov             x2, x0
    // 0xbfa37c: ldur            x0, [fp, #-0x48]
    // 0xbfa380: stur            x2, [fp, #-0x68]
    // 0xbfa384: LoadField: r1 = r0->field_b
    //     0xbfa384: ldur            w1, [x0, #0xb]
    // 0xbfa388: LoadField: r3 = r0->field_f
    //     0xbfa388: ldur            w3, [x0, #0xf]
    // 0xbfa38c: DecompressPointer r3
    //     0xbfa38c: add             x3, x3, HEAP, lsl #32
    // 0xbfa390: LoadField: r4 = r3->field_b
    //     0xbfa390: ldur            w4, [x3, #0xb]
    // 0xbfa394: r3 = LoadInt32Instr(r1)
    //     0xbfa394: sbfx            x3, x1, #1, #0x1f
    // 0xbfa398: stur            x3, [fp, #-0x60]
    // 0xbfa39c: r1 = LoadInt32Instr(r4)
    //     0xbfa39c: sbfx            x1, x4, #1, #0x1f
    // 0xbfa3a0: cmp             x3, x1
    // 0xbfa3a4: b.ne            #0xbfa3b0
    // 0xbfa3a8: mov             x1, x0
    // 0xbfa3ac: r0 = _growToNextCapacity()
    //     0xbfa3ac: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbfa3b0: ldur            x4, [fp, #-0x38]
    // 0xbfa3b4: ldur            x2, [fp, #-0x48]
    // 0xbfa3b8: ldur            x3, [fp, #-0x60]
    // 0xbfa3bc: add             x0, x3, #1
    // 0xbfa3c0: lsl             x1, x0, #1
    // 0xbfa3c4: StoreField: r2->field_b = r1
    //     0xbfa3c4: stur            w1, [x2, #0xb]
    // 0xbfa3c8: LoadField: r1 = r2->field_f
    //     0xbfa3c8: ldur            w1, [x2, #0xf]
    // 0xbfa3cc: DecompressPointer r1
    //     0xbfa3cc: add             x1, x1, HEAP, lsl #32
    // 0xbfa3d0: ldur            x0, [fp, #-0x68]
    // 0xbfa3d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbfa3d4: add             x25, x1, x3, lsl #2
    //     0xbfa3d8: add             x25, x25, #0xf
    //     0xbfa3dc: str             w0, [x25]
    //     0xbfa3e0: tbz             w0, #0, #0xbfa3fc
    //     0xbfa3e4: ldurb           w16, [x1, #-1]
    //     0xbfa3e8: ldurb           w17, [x0, #-1]
    //     0xbfa3ec: and             x16, x17, x16, lsr #2
    //     0xbfa3f0: tst             x16, HEAP, lsr #32
    //     0xbfa3f4: b.eq            #0xbfa3fc
    //     0xbfa3f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbfa3fc: add             x0, x4, #1
    // 0xbfa400: mov             x4, x0
    // 0xbfa404: b               #0xbfa410
    // 0xbfa408: mov             x4, x10
    // 0xbfa40c: mov             x2, x7
    // 0xbfa410: ldur            x3, [fp, #-0x28]
    // 0xbfa414: stur            x4, [fp, #-0x70]
    // 0xbfa418: r0 = BoxInt64Instr(r3)
    //     0xbfa418: sbfiz           x0, x3, #1, #0x1f
    //     0xbfa41c: cmp             x3, x0, asr #1
    //     0xbfa420: b.eq            #0xbfa42c
    //     0xbfa424: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbfa428: stur            x3, [x0, #7]
    // 0xbfa42c: mov             x1, x0
    // 0xbfa430: stur            x1, [fp, #-0x68]
    // 0xbfa434: ldur            x6, [fp, #-0x30]
    // 0xbfa438: ldur            x5, [fp, #-0x10]
    // 0xbfa43c: stur            x6, [fp, #-0x60]
    // 0xbfa440: CheckStackOverflow
    //     0xbfa440: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfa444: cmp             SP, x16
    //     0xbfa448: b.ls            #0xbfa6f4
    // 0xbfa44c: r0 = LoadClassIdInstr(r5)
    //     0xbfa44c: ldur            x0, [x5, #-1]
    //     0xbfa450: ubfx            x0, x0, #0xc, #0x14
    // 0xbfa454: str             x5, [SP]
    // 0xbfa458: r0 = GDT[cid_x0 + 0xf078]()
    //     0xbfa458: mov             x17, #0xf078
    //     0xbfa45c: add             lr, x0, x17
    //     0xbfa460: ldr             lr, [x21, lr, lsl #3]
    //     0xbfa464: blr             lr
    // 0xbfa468: r1 = LoadInt32Instr(r0)
    //     0xbfa468: sbfx            x1, x0, #1, #0x1f
    //     0xbfa46c: tbz             w0, #0, #0xbfa474
    //     0xbfa470: ldur            x1, [x0, #7]
    // 0xbfa474: ldur            x2, [fp, #-0x60]
    // 0xbfa478: cmp             x2, x1
    // 0xbfa47c: b.ge            #0xbfa628
    // 0xbfa480: ldur            x5, [fp, #-0x10]
    // 0xbfa484: ldur            x3, [fp, #-0x28]
    // 0xbfa488: ldur            x4, [fp, #-0x68]
    // 0xbfa48c: r0 = BoxInt64Instr(r2)
    //     0xbfa48c: sbfiz           x0, x2, #1, #0x1f
    //     0xbfa490: cmp             x2, x0, asr #1
    //     0xbfa494: b.eq            #0xbfa4a0
    //     0xbfa498: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbfa49c: stur            x2, [x0, #7]
    // 0xbfa4a0: mov             x1, x0
    // 0xbfa4a4: stur            x1, [fp, #-0x78]
    // 0xbfa4a8: r0 = LoadClassIdInstr(r5)
    //     0xbfa4a8: ldur            x0, [x5, #-1]
    //     0xbfa4ac: ubfx            x0, x0, #0xc, #0x14
    // 0xbfa4b0: stp             x1, x5, [SP]
    // 0xbfa4b4: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xbfa4b4: sub             lr, x0, #0xdfd
    //     0xbfa4b8: ldr             lr, [x21, lr, lsl #3]
    //     0xbfa4bc: blr             lr
    // 0xbfa4c0: stur            x0, [fp, #-0x80]
    // 0xbfa4c4: r0 = PlaceholderSpanIndexSemanticsTag()
    //     0xbfa4c4: bl              #0xbfa6fc  ; AllocatePlaceholderSpanIndexSemanticsTagStub -> PlaceholderSpanIndexSemanticsTag (size=0x14)
    // 0xbfa4c8: mov             x3, x0
    // 0xbfa4cc: ldur            x0, [fp, #-0x28]
    // 0xbfa4d0: stur            x3, [fp, #-0x88]
    // 0xbfa4d4: StoreField: r3->field_b = r0
    //     0xbfa4d4: stur            x0, [x3, #0xb]
    // 0xbfa4d8: r1 = Null
    //     0xbfa4d8: mov             x1, NULL
    // 0xbfa4dc: r2 = 6
    //     0xbfa4dc: mov             x2, #6
    // 0xbfa4e0: r0 = AllocateArray()
    //     0xbfa4e0: bl              #0x13df928  ; AllocateArrayStub
    // 0xbfa4e4: r16 = "PlaceholderSpanIndexSemanticsTag("
    //     0xbfa4e4: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7cf00] "PlaceholderSpanIndexSemanticsTag("
    //     0xbfa4e8: ldr             x16, [x16, #0xf00]
    // 0xbfa4ec: StoreField: r0->field_f = r16
    //     0xbfa4ec: stur            w16, [x0, #0xf]
    // 0xbfa4f0: ldur            x1, [fp, #-0x68]
    // 0xbfa4f4: StoreField: r0->field_13 = r1
    //     0xbfa4f4: stur            w1, [x0, #0x13]
    // 0xbfa4f8: r16 = ")"
    //     0xbfa4f8: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0xbfa4fc: ArrayStore: r0[0] = r16  ; List_4
    //     0xbfa4fc: stur            w16, [x0, #0x17]
    // 0xbfa500: str             x0, [SP]
    // 0xbfa504: r0 = _interpolate()
    //     0xbfa504: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xbfa508: ldur            x2, [fp, #-0x88]
    // 0xbfa50c: StoreField: r2->field_7 = r0
    //     0xbfa50c: stur            w0, [x2, #7]
    //     0xbfa510: ldurb           w16, [x2, #-1]
    //     0xbfa514: ldurb           w17, [x0, #-1]
    //     0xbfa518: and             x16, x17, x16, lsr #2
    //     0xbfa51c: tst             x16, HEAP, lsr #32
    //     0xbfa520: b.eq            #0xbfa528
    //     0xbfa524: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbfa528: ldur            x0, [fp, #-0x80]
    // 0xbfa52c: LoadField: r1 = r0->field_bf
    //     0xbfa52c: ldur            w1, [x0, #0xbf]
    // 0xbfa530: DecompressPointer r1
    //     0xbfa530: add             x1, x1, HEAP, lsl #32
    // 0xbfa534: cmp             w1, NULL
    // 0xbfa538: b.ne            #0xbfa544
    // 0xbfa53c: r0 = Null
    //     0xbfa53c: mov             x0, NULL
    // 0xbfa540: b               #0xbfa548
    // 0xbfa544: r0 = contains()
    //     0xbfa544: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xbfa548: cmp             w0, NULL
    // 0xbfa54c: b.eq            #0xbfa61c
    // 0xbfa550: tbnz            w0, #4, #0xbfa610
    // 0xbfa554: ldur            x1, [fp, #-0x10]
    // 0xbfa558: ldur            x2, [fp, #-0x48]
    // 0xbfa55c: r0 = LoadClassIdInstr(r1)
    //     0xbfa55c: ldur            x0, [x1, #-1]
    //     0xbfa560: ubfx            x0, x0, #0xc, #0x14
    // 0xbfa564: ldur            x16, [fp, #-0x78]
    // 0xbfa568: stp             x16, x1, [SP]
    // 0xbfa56c: r0 = GDT[cid_x0 + -0xdfd]()
    //     0xbfa56c: sub             lr, x0, #0xdfd
    //     0xbfa570: ldr             lr, [x21, lr, lsl #3]
    //     0xbfa574: blr             lr
    // 0xbfa578: mov             x2, x0
    // 0xbfa57c: ldur            x0, [fp, #-0x48]
    // 0xbfa580: stur            x2, [fp, #-0x78]
    // 0xbfa584: LoadField: r1 = r0->field_b
    //     0xbfa584: ldur            w1, [x0, #0xb]
    // 0xbfa588: LoadField: r3 = r0->field_f
    //     0xbfa588: ldur            w3, [x0, #0xf]
    // 0xbfa58c: DecompressPointer r3
    //     0xbfa58c: add             x3, x3, HEAP, lsl #32
    // 0xbfa590: LoadField: r4 = r3->field_b
    //     0xbfa590: ldur            w4, [x3, #0xb]
    // 0xbfa594: r3 = LoadInt32Instr(r1)
    //     0xbfa594: sbfx            x3, x1, #1, #0x1f
    // 0xbfa598: stur            x3, [fp, #-0x90]
    // 0xbfa59c: r1 = LoadInt32Instr(r4)
    //     0xbfa59c: sbfx            x1, x4, #1, #0x1f
    // 0xbfa5a0: cmp             x3, x1
    // 0xbfa5a4: b.ne            #0xbfa5b0
    // 0xbfa5a8: mov             x1, x0
    // 0xbfa5ac: r0 = _growToNextCapacity()
    //     0xbfa5ac: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbfa5b0: ldur            x4, [fp, #-0x60]
    // 0xbfa5b4: ldur            x2, [fp, #-0x48]
    // 0xbfa5b8: ldur            x3, [fp, #-0x90]
    // 0xbfa5bc: add             x0, x3, #1
    // 0xbfa5c0: lsl             x1, x0, #1
    // 0xbfa5c4: StoreField: r2->field_b = r1
    //     0xbfa5c4: stur            w1, [x2, #0xb]
    // 0xbfa5c8: LoadField: r1 = r2->field_f
    //     0xbfa5c8: ldur            w1, [x2, #0xf]
    // 0xbfa5cc: DecompressPointer r1
    //     0xbfa5cc: add             x1, x1, HEAP, lsl #32
    // 0xbfa5d0: ldur            x0, [fp, #-0x78]
    // 0xbfa5d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xbfa5d4: add             x25, x1, x3, lsl #2
    //     0xbfa5d8: add             x25, x25, #0xf
    //     0xbfa5dc: str             w0, [x25]
    //     0xbfa5e0: tbz             w0, #0, #0xbfa5fc
    //     0xbfa5e4: ldurb           w16, [x1, #-1]
    //     0xbfa5e8: ldurb           w17, [x0, #-1]
    //     0xbfa5ec: and             x16, x17, x16, lsr #2
    //     0xbfa5f0: tst             x16, HEAP, lsr #32
    //     0xbfa5f4: b.eq            #0xbfa5fc
    //     0xbfa5f8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbfa5fc: add             x6, x4, #1
    // 0xbfa600: ldur            x3, [fp, #-0x28]
    // 0xbfa604: ldur            x4, [fp, #-0x70]
    // 0xbfa608: ldur            x1, [fp, #-0x68]
    // 0xbfa60c: b               #0xbfa438
    // 0xbfa610: ldur            x4, [fp, #-0x60]
    // 0xbfa614: ldur            x2, [fp, #-0x48]
    // 0xbfa618: b               #0xbfa630
    // 0xbfa61c: ldur            x4, [fp, #-0x60]
    // 0xbfa620: ldur            x2, [fp, #-0x48]
    // 0xbfa624: b               #0xbfa630
    // 0xbfa628: mov             x4, x2
    // 0xbfa62c: ldur            x2, [fp, #-0x48]
    // 0xbfa630: ldur            x0, [fp, #-0x28]
    // 0xbfa634: add             x3, x0, #1
    // 0xbfa638: mov             x12, x3
    // 0xbfa63c: mov             x11, x4
    // 0xbfa640: ldur            x10, [fp, #-0x70]
    // 0xbfa644: ldur            x9, [fp, #-0x40]
    // 0xbfa648: b               #0xbfa668
    // 0xbfa64c: mov             x0, x12
    // 0xbfa650: mov             x4, x10
    // 0xbfa654: mov             x2, x7
    // 0xbfa658: mov             x12, x0
    // 0xbfa65c: ldur            x11, [fp, #-0x30]
    // 0xbfa660: mov             x10, x4
    // 0xbfa664: mov             x9, x3
    // 0xbfa668: ldur            x1, [fp, #-0x20]
    // 0xbfa66c: ldur            x4, [fp, #-8]
    // 0xbfa670: ldur            x0, [fp, #-0x18]
    // 0xbfa674: mov             x7, x2
    // 0xbfa678: ldur            x6, [fp, #-0x50]
    // 0xbfa67c: ldur            x5, [fp, #-0x58]
    // 0xbfa680: b               #0xbfa300
    // 0xbfa684: mov             x4, x10
    // 0xbfa688: mov             x2, x9
    // 0xbfa68c: cmp             w2, NULL
    // 0xbfa690: b.eq            #0xbfa6ac
    // 0xbfa694: ldur            x1, [fp, #-8]
    // 0xbfa698: mov             x3, x4
    // 0xbfa69c: r0 = _createSemanticsConfigForTextInfo()
    //     0xbfa69c: bl              #0xbfa708  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_createSemanticsConfigForTextInfo
    // 0xbfa6a0: ldur            x1, [fp, #-0x18]
    // 0xbfa6a4: mov             x2, x0
    // 0xbfa6a8: r0 = visitDeclaration()
    //     0xbfa6a8: bl              #0x12ea24c  ; [package:flutter_widget_from_html_core/src/external/csslib.dart] _DeclarationsCollector::visitDeclaration
    // 0xbfa6ac: ldur            x1, [fp, #-0x18]
    // 0xbfa6b0: r0 = build()
    //     0xbfa6b0: bl              #0xbf6d34  ; [package:flutter/src/semantics/semantics.dart] ChildSemanticsConfigurationsResultBuilder::build
    // 0xbfa6b4: LeaveFrame
    //     0xbfa6b4: mov             SP, fp
    //     0xbfa6b8: ldp             fp, lr, [SP], #0x10
    // 0xbfa6bc: ret
    //     0xbfa6bc: ret             
    // 0xbfa6c0: mov             x0, x5
    // 0xbfa6c4: r0 = ConcurrentModificationError()
    //     0xbfa6c4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xbfa6c8: mov             x1, x0
    // 0xbfa6cc: ldur            x0, [fp, #-0x58]
    // 0xbfa6d0: StoreField: r1->field_b = r0
    //     0xbfa6d0: stur            w0, [x1, #0xb]
    // 0xbfa6d4: mov             x0, x1
    // 0xbfa6d8: r0 = Throw()
    //     0xbfa6d8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbfa6dc: brk             #0
    // 0xbfa6e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa6e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa6e4: b               #0xbfa260
    // 0xbfa6e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfa6e8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbfa6ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa6ec: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa6f0: b               #0xbfa320
    // 0xbfa6f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa6f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa6f8: b               #0xbfa44c
  }
  _ _createSemanticsConfigForTextInfo(/* No info */) {
    // ** addr: 0xbfa708, size: 0x25c
    // 0xbfa708: EnterFrame
    //     0xbfa708: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa70c: mov             fp, SP
    // 0xbfa710: AllocStack(0x38)
    //     0xbfa710: sub             SP, SP, #0x38
    // 0xbfa714: SetupParameters(RenderParagraph this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xbfa714: mov             x4, x1
    //     0xbfa718: mov             x0, x3
    //     0xbfa71c: stur            x3, [fp, #-0x18]
    //     0xbfa720: mov             x3, x2
    //     0xbfa724: stur            x1, [fp, #-8]
    //     0xbfa728: stur            x2, [fp, #-0x10]
    // 0xbfa72c: CheckStackOverflow
    //     0xbfa72c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfa730: cmp             SP, x16
    //     0xbfa734: b.ls            #0xbfa954
    // 0xbfa738: LoadField: r1 = r4->field_6b
    //     0xbfa738: ldur            w1, [x4, #0x6b]
    // 0xbfa73c: DecompressPointer r1
    //     0xbfa73c: add             x1, x1, HEAP, lsl #32
    // 0xbfa740: cmp             w1, NULL
    // 0xbfa744: b.ne            #0xbfa784
    // 0xbfa748: r1 = <AttributedString>
    //     0xbfa748: add             x1, PP, #0x98, lsl #12  ; [pp+0x988e8] TypeArguments: <AttributedString>
    //     0xbfa74c: ldr             x1, [x1, #0x8e8]
    // 0xbfa750: r2 = 0
    //     0xbfa750: mov             x2, #0
    // 0xbfa754: r0 = _GrowableList()
    //     0xbfa754: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbfa758: mov             x1, x0
    // 0xbfa75c: ldur            x2, [fp, #-8]
    // 0xbfa760: StoreField: r2->field_6b = r0
    //     0xbfa760: stur            w0, [x2, #0x6b]
    //     0xbfa764: ldurb           w16, [x2, #-1]
    //     0xbfa768: ldurb           w17, [x0, #-1]
    //     0xbfa76c: and             x16, x17, x16, lsr #2
    //     0xbfa770: tst             x16, HEAP, lsr #32
    //     0xbfa774: b.eq            #0xbfa77c
    //     0xbfa778: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbfa77c: mov             x4, x1
    // 0xbfa780: b               #0xbfa78c
    // 0xbfa784: mov             x2, x4
    // 0xbfa788: mov             x4, x1
    // 0xbfa78c: ldur            x3, [fp, #-0x18]
    // 0xbfa790: stur            x4, [fp, #-0x38]
    // 0xbfa794: LoadField: r0 = r4->field_b
    //     0xbfa794: ldur            w0, [x4, #0xb]
    // 0xbfa798: r1 = LoadInt32Instr(r0)
    //     0xbfa798: sbfx            x1, x0, #1, #0x1f
    // 0xbfa79c: stur            x1, [fp, #-0x30]
    // 0xbfa7a0: cmp             x3, x1
    // 0xbfa7a4: b.ge            #0xbfa7d4
    // 0xbfa7a8: mov             x0, x1
    // 0xbfa7ac: mov             x1, x3
    // 0xbfa7b0: cmp             x1, x0
    // 0xbfa7b4: b.hs            #0xbfa95c
    // 0xbfa7b8: LoadField: r0 = r4->field_f
    //     0xbfa7b8: ldur            w0, [x4, #0xf]
    // 0xbfa7bc: DecompressPointer r0
    //     0xbfa7bc: add             x0, x0, HEAP, lsl #32
    // 0xbfa7c0: ArrayLoad: r1 = r0[r3]  ; Unknown_4
    //     0xbfa7c0: add             x16, x0, x3, lsl #2
    //     0xbfa7c4: ldur            w1, [x16, #0xf]
    // 0xbfa7c8: DecompressPointer r1
    //     0xbfa7c8: add             x1, x1, HEAP, lsl #32
    // 0xbfa7cc: mov             x0, x2
    // 0xbfa7d0: b               #0xbfa8cc
    // 0xbfa7d4: ldur            x0, [fp, #-0x10]
    // 0xbfa7d8: LoadField: r3 = r0->field_b
    //     0xbfa7d8: ldur            w3, [x0, #0xb]
    // 0xbfa7dc: DecompressPointer r3
    //     0xbfa7dc: add             x3, x3, HEAP, lsl #32
    // 0xbfa7e0: cmp             w3, NULL
    // 0xbfa7e4: b.ne            #0xbfa7f0
    // 0xbfa7e8: LoadField: r3 = r0->field_7
    //     0xbfa7e8: ldur            w3, [x0, #7]
    // 0xbfa7ec: DecompressPointer r3
    //     0xbfa7ec: add             x3, x3, HEAP, lsl #32
    // 0xbfa7f0: stur            x3, [fp, #-0x28]
    // 0xbfa7f4: LoadField: r5 = r0->field_1f
    //     0xbfa7f4: ldur            w5, [x0, #0x1f]
    // 0xbfa7f8: DecompressPointer r5
    //     0xbfa7f8: add             x5, x5, HEAP, lsl #32
    // 0xbfa7fc: stur            x5, [fp, #-0x20]
    // 0xbfa800: r0 = AttributedString()
    //     0xbfa800: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xbfa804: mov             x3, x0
    // 0xbfa808: ldur            x0, [fp, #-0x28]
    // 0xbfa80c: stur            x3, [fp, #-0x10]
    // 0xbfa810: StoreField: r3->field_7 = r0
    //     0xbfa810: stur            w0, [x3, #7]
    // 0xbfa814: ldur            x0, [fp, #-0x20]
    // 0xbfa818: StoreField: r3->field_b = r0
    //     0xbfa818: stur            w0, [x3, #0xb]
    // 0xbfa81c: ldur            x4, [fp, #-0x38]
    // 0xbfa820: LoadField: r2 = r4->field_7
    //     0xbfa820: ldur            w2, [x4, #7]
    // 0xbfa824: DecompressPointer r2
    //     0xbfa824: add             x2, x2, HEAP, lsl #32
    // 0xbfa828: mov             x0, x3
    // 0xbfa82c: r1 = Null
    //     0xbfa82c: mov             x1, NULL
    // 0xbfa830: cmp             w2, NULL
    // 0xbfa834: b.eq            #0xbfa854
    // 0xbfa838: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbfa838: ldur            w4, [x2, #0x17]
    // 0xbfa83c: DecompressPointer r4
    //     0xbfa83c: add             x4, x4, HEAP, lsl #32
    // 0xbfa840: r8 = X0
    //     0xbfa840: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xbfa844: LoadField: r9 = r4->field_7
    //     0xbfa844: ldur            x9, [x4, #7]
    // 0xbfa848: r3 = Null
    //     0xbfa848: add             x3, PP, #0x98, lsl #12  ; [pp+0x988f0] Null
    //     0xbfa84c: ldr             x3, [x3, #0x8f0]
    // 0xbfa850: blr             x9
    // 0xbfa854: ldur            x0, [fp, #-0x38]
    // 0xbfa858: LoadField: r1 = r0->field_f
    //     0xbfa858: ldur            w1, [x0, #0xf]
    // 0xbfa85c: DecompressPointer r1
    //     0xbfa85c: add             x1, x1, HEAP, lsl #32
    // 0xbfa860: LoadField: r2 = r1->field_b
    //     0xbfa860: ldur            w2, [x1, #0xb]
    // 0xbfa864: r1 = LoadInt32Instr(r2)
    //     0xbfa864: sbfx            x1, x2, #1, #0x1f
    // 0xbfa868: ldur            x2, [fp, #-0x30]
    // 0xbfa86c: cmp             x2, x1
    // 0xbfa870: b.ne            #0xbfa87c
    // 0xbfa874: mov             x1, x0
    // 0xbfa878: r0 = _growToNextCapacity()
    //     0xbfa878: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbfa87c: ldur            x0, [fp, #-0x38]
    // 0xbfa880: ldur            x2, [fp, #-0x30]
    // 0xbfa884: add             x1, x2, #1
    // 0xbfa888: lsl             x3, x1, #1
    // 0xbfa88c: StoreField: r0->field_b = r3
    //     0xbfa88c: stur            w3, [x0, #0xb]
    // 0xbfa890: LoadField: r1 = r0->field_f
    //     0xbfa890: ldur            w1, [x0, #0xf]
    // 0xbfa894: DecompressPointer r1
    //     0xbfa894: add             x1, x1, HEAP, lsl #32
    // 0xbfa898: ldur            x0, [fp, #-0x10]
    // 0xbfa89c: ArrayStore: r1[r2] = r0  ; List_4
    //     0xbfa89c: add             x25, x1, x2, lsl #2
    //     0xbfa8a0: add             x25, x25, #0xf
    //     0xbfa8a4: str             w0, [x25]
    //     0xbfa8a8: tbz             w0, #0, #0xbfa8c4
    //     0xbfa8ac: ldurb           w16, [x1, #-1]
    //     0xbfa8b0: ldurb           w17, [x0, #-1]
    //     0xbfa8b4: and             x16, x17, x16, lsr #2
    //     0xbfa8b8: tst             x16, HEAP, lsr #32
    //     0xbfa8bc: b.eq            #0xbfa8c4
    //     0xbfa8c0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbfa8c4: ldur            x1, [fp, #-0x10]
    // 0xbfa8c8: ldur            x0, [fp, #-8]
    // 0xbfa8cc: stur            x1, [fp, #-0x10]
    // 0xbfa8d0: r0 = SemanticsConfiguration()
    //     0xbfa8d0: bl              #0x839284  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0xc8)
    // 0xbfa8d4: mov             x1, x0
    // 0xbfa8d8: stur            x0, [fp, #-0x20]
    // 0xbfa8dc: r0 = SemanticsConfiguration()
    //     0xbfa8dc: bl              #0x837c94  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0xbfa8e0: ldur            x1, [fp, #-8]
    // 0xbfa8e4: LoadField: r2 = r1->field_63
    //     0xbfa8e4: ldur            w2, [x1, #0x63]
    // 0xbfa8e8: DecompressPointer r2
    //     0xbfa8e8: add             x2, x2, HEAP, lsl #32
    // 0xbfa8ec: LoadField: r0 = r2->field_1b
    //     0xbfa8ec: ldur            w0, [x2, #0x1b]
    // 0xbfa8f0: DecompressPointer r0
    //     0xbfa8f0: add             x0, x0, HEAP, lsl #32
    // 0xbfa8f4: cmp             w0, NULL
    // 0xbfa8f8: b.eq            #0xbfa960
    // 0xbfa8fc: ldur            x1, [fp, #-0x20]
    // 0xbfa900: StoreField: r1->field_83 = r0
    //     0xbfa900: stur            w0, [x1, #0x83]
    //     0xbfa904: ldurb           w16, [x1, #-1]
    //     0xbfa908: ldurb           w17, [x0, #-1]
    //     0xbfa90c: and             x16, x17, x16, lsr #2
    //     0xbfa910: tst             x16, HEAP, lsr #32
    //     0xbfa914: b.eq            #0xbfa91c
    //     0xbfa918: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbfa91c: r2 = true
    //     0xbfa91c: add             x2, NULL, #0x20  ; true
    // 0xbfa920: StoreField: r1->field_1f = r2
    //     0xbfa920: stur            w2, [x1, #0x1f]
    // 0xbfa924: ldur            x0, [fp, #-0x10]
    // 0xbfa928: StoreField: r1->field_67 = r0
    //     0xbfa928: stur            w0, [x1, #0x67]
    //     0xbfa92c: ldurb           w16, [x1, #-1]
    //     0xbfa930: ldurb           w17, [x0, #-1]
    //     0xbfa934: and             x16, x17, x16, lsr #2
    //     0xbfa938: tst             x16, HEAP, lsr #32
    //     0xbfa93c: b.eq            #0xbfa944
    //     0xbfa940: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbfa944: mov             x0, x1
    // 0xbfa948: LeaveFrame
    //     0xbfa948: mov             SP, fp
    //     0xbfa94c: ldp             fp, lr, [SP], #0x10
    // 0xbfa950: ret
    //     0xbfa950: ret             
    // 0xbfa954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa954: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa958: b               #0xbfa738
    // 0xbfa95c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbfa95c: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbfa960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfa960: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsLayout(/* No info */) {
    // ** addr: 0xbfb1e8, size: 0x30
    // 0xbfb1e8: EnterFrame
    //     0xbfb1e8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb1ec: mov             fp, SP
    // 0xbfb1f0: CheckStackOverflow
    //     0xbfb1f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfb1f4: cmp             SP, x16
    //     0xbfb1f8: b.ls            #0xbfb210
    // 0xbfb1fc: r0 = markNeedsLayout()
    //     0xbfb1fc: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xbfb200: r0 = Null
    //     0xbfb200: mov             x0, NULL
    // 0xbfb204: LeaveFrame
    //     0xbfb204: mov             SP, fp
    //     0xbfb208: ldp             fp, lr, [SP], #0x10
    // 0xbfb20c: ret
    //     0xbfb20c: ret             
    // 0xbfb210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb210: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb214: b               #0xbfb1fc
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc035d8, size: 0x64
    // 0xc035d8: EnterFrame
    //     0xc035d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc035dc: mov             fp, SP
    // 0xc035e0: AllocStack(0x8)
    //     0xc035e0: sub             SP, SP, #8
    // 0xc035e4: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */)
    //     0xc035e4: mov             x0, x1
    //     0xc035e8: stur            x1, [fp, #-8]
    // 0xc035ec: CheckStackOverflow
    //     0xc035ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc035f0: cmp             SP, x16
    //     0xc035f4: b.ls            #0xc03634
    // 0xc035f8: LoadField: r1 = r0->field_63
    //     0xc035f8: ldur            w1, [x0, #0x63]
    // 0xc035fc: DecompressPointer r1
    //     0xc035fc: add             x1, x1, HEAP, lsl #32
    // 0xc03600: r0 = dispose()
    //     0xc03600: bl              #0xbcb780  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0xc03604: ldur            x0, [fp, #-8]
    // 0xc03608: LoadField: r1 = r0->field_67
    //     0xc03608: ldur            w1, [x0, #0x67]
    // 0xc0360c: DecompressPointer r1
    //     0xc0360c: add             x1, x1, HEAP, lsl #32
    // 0xc03610: cmp             w1, NULL
    // 0xc03614: b.eq            #0xc0361c
    // 0xc03618: r0 = dispose()
    //     0xc03618: bl              #0xbcb780  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0xc0361c: ldur            x1, [fp, #-8]
    // 0xc03620: r0 = dispose()
    //     0xc03620: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc03624: r0 = Null
    //     0xc03624: mov             x0, NULL
    // 0xc03628: LeaveFrame
    //     0xc03628: mov             SP, fp
    //     0xc0362c: ldp             fp, lr, [SP], #0x10
    // 0xc03630: ret
    //     0xc03630: ret             
    // 0xc03634: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc03634: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc03638: b               #0xc035f8
  }
  _ assembleSemanticsNode(/* No info */) {
    // ** addr: 0xc12bd8, size: 0xf64
    // 0xc12bd8: EnterFrame
    //     0xc12bd8: stp             fp, lr, [SP, #-0x10]!
    //     0xc12bdc: mov             fp, SP
    // 0xc12be0: AllocStack(0x110)
    //     0xc12be0: sub             SP, SP, #0x110
    // 0xc12be4: SetupParameters(RenderParagraph this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */, dynamic _ /* r5 => r5, fp-0x20 */)
    //     0xc12be4: mov             x4, x1
    //     0xc12be8: mov             x0, x3
    //     0xc12bec: stur            x3, [fp, #-0x18]
    //     0xc12bf0: mov             x3, x2
    //     0xc12bf4: stur            x1, [fp, #-8]
    //     0xc12bf8: stur            x2, [fp, #-0x10]
    //     0xc12bfc: stur            x5, [fp, #-0x20]
    // 0xc12c00: CheckStackOverflow
    //     0xc12c00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc12c04: cmp             SP, x16
    //     0xc12c08: b.ls            #0xc13af8
    // 0xc12c0c: r1 = <SemanticsNode>
    //     0xc12c0c: ldr             x1, [PP, #0x23b8]  ; [pp+0x23b8] TypeArguments: <SemanticsNode>
    // 0xc12c10: r2 = 0
    //     0xc12c10: mov             x2, #0
    // 0xc12c14: r0 = _GrowableList()
    //     0xc12c14: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xc12c18: ldur            x1, [fp, #-8]
    // 0xc12c1c: stur            x0, [fp, #-0x28]
    // 0xc12c20: r0 = textDirection()
    //     0xc12c20: bl              #0xbcb758  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::textDirection
    // 0xc12c24: ldur            x1, [fp, #-8]
    // 0xc12c28: stur            x0, [fp, #-0x38]
    // 0xc12c2c: LoadField: r2 = r1->field_57
    //     0xc12c2c: ldur            w2, [x1, #0x57]
    // 0xc12c30: DecompressPointer r2
    //     0xc12c30: add             x2, x2, HEAP, lsl #32
    // 0xc12c34: stur            x2, [fp, #-0x30]
    // 0xc12c38: r16 = <Key, SemanticsNode>
    //     0xc12c38: add             x16, PP, #0x98, lsl #12  ; [pp+0x98850] TypeArguments: <Key, SemanticsNode>
    //     0xc12c3c: ldr             x16, [x16, #0x850]
    // 0xc12c40: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xc12c44: stp             lr, x16, [SP]
    // 0xc12c48: r0 = Map._fromLiteral()
    //     0xc12c48: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xc12c4c: mov             x2, x0
    // 0xc12c50: ldur            x0, [fp, #-8]
    // 0xc12c54: stur            x2, [fp, #-0x40]
    // 0xc12c58: LoadField: r1 = r0->field_6f
    //     0xc12c58: ldur            w1, [x0, #0x6f]
    // 0xc12c5c: DecompressPointer r1
    //     0xc12c5c: add             x1, x1, HEAP, lsl #32
    // 0xc12c60: cmp             w1, NULL
    // 0xc12c64: b.ne            #0xc12ca8
    // 0xc12c68: LoadField: r1 = r0->field_93
    //     0xc12c68: ldur            w1, [x0, #0x93]
    // 0xc12c6c: DecompressPointer r1
    //     0xc12c6c: add             x1, x1, HEAP, lsl #32
    // 0xc12c70: cmp             w1, NULL
    // 0xc12c74: b.eq            #0xc13b00
    // 0xc12c78: r0 = combineSemanticsInfo()
    //     0xc12c78: bl              #0xbfa964  ; [package:flutter/src/painting/inline_span.dart] ::combineSemanticsInfo
    // 0xc12c7c: mov             x1, x0
    // 0xc12c80: ldur            x2, [fp, #-8]
    // 0xc12c84: StoreField: r2->field_6f = r0
    //     0xc12c84: stur            w0, [x2, #0x6f]
    //     0xc12c88: ldurb           w16, [x2, #-1]
    //     0xc12c8c: ldurb           w17, [x0, #-1]
    //     0xc12c90: and             x16, x17, x16, lsr #2
    //     0xc12c94: tst             x16, HEAP, lsr #32
    //     0xc12c98: b.eq            #0xc12ca0
    //     0xc12c9c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc12ca0: mov             x0, x1
    // 0xc12ca4: b               #0xc12cb0
    // 0xc12ca8: mov             x2, x0
    // 0xc12cac: mov             x0, x1
    // 0xc12cb0: stur            x0, [fp, #-0x90]
    // 0xc12cb4: LoadField: r1 = r0->field_b
    //     0xc12cb4: ldur            w1, [x0, #0xb]
    // 0xc12cb8: r3 = LoadInt32Instr(r1)
    //     0xc12cb8: sbfx            x3, x1, #1, #0x1f
    // 0xc12cbc: stur            x3, [fp, #-0x88]
    // 0xc12cc0: LoadField: r1 = r2->field_63
    //     0xc12cc0: ldur            w1, [x2, #0x63]
    // 0xc12cc4: DecompressPointer r1
    //     0xc12cc4: add             x1, x1, HEAP, lsl #32
    // 0xc12cc8: stur            x1, [fp, #-0x80]
    // 0xc12ccc: ldur            x13, [fp, #-0x38]
    // 0xc12cd0: ldur            x9, [fp, #-0x30]
    // 0xc12cd4: ldur            x5, [fp, #-0x28]
    // 0xc12cd8: d0 = 0.000000
    //     0xc12cd8: eor             v0.16b, v0.16b, v0.16b
    // 0xc12cdc: r12 = 0
    //     0xc12cdc: mov             x12, #0
    // 0xc12ce0: r11 = 0
    //     0xc12ce0: mov             x11, #0
    // 0xc12ce4: r10 = 0
    //     0xc12ce4: mov             x10, #0
    // 0xc12ce8: r8 = 0
    //     0xc12ce8: mov             x8, #0
    // 0xc12cec: ldur            x7, [fp, #-0x10]
    // 0xc12cf0: ldur            x6, [fp, #-0x20]
    // 0xc12cf4: ldur            x4, [fp, #-0x40]
    // 0xc12cf8: stur            x13, [fp, #-0x58]
    // 0xc12cfc: stur            x12, [fp, #-0x60]
    // 0xc12d00: stur            x11, [fp, #-0x68]
    // 0xc12d04: stur            x10, [fp, #-0x70]
    // 0xc12d08: stur            x9, [fp, #-0x78]
    // 0xc12d0c: stur            d0, [fp, #-0xc8]
    // 0xc12d10: CheckStackOverflow
    //     0xc12d10: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc12d14: cmp             SP, x16
    //     0xc12d18: b.ls            #0xc13b04
    // 0xc12d1c: LoadField: r14 = r0->field_b
    //     0xc12d1c: ldur            w14, [x0, #0xb]
    // 0xc12d20: r19 = LoadInt32Instr(r14)
    //     0xc12d20: sbfx            x19, x14, #1, #0x1f
    // 0xc12d24: cmp             x3, x19
    // 0xc12d28: b.ne            #0xc13adc
    // 0xc12d2c: cmp             x8, x19
    // 0xc12d30: b.ge            #0xc13a28
    // 0xc12d34: LoadField: r14 = r0->field_f
    //     0xc12d34: ldur            w14, [x0, #0xf]
    // 0xc12d38: DecompressPointer r14
    //     0xc12d38: add             x14, x14, HEAP, lsl #32
    // 0xc12d3c: ArrayLoad: r19 = r14[r8]  ; Unknown_4
    //     0xc12d3c: add             x16, x14, x8, lsl #2
    //     0xc12d40: ldur            w19, [x16, #0xf]
    // 0xc12d44: DecompressPointer r19
    //     0xc12d44: add             x19, x19, HEAP, lsl #32
    // 0xc12d48: stur            x19, [fp, #-0x38]
    // 0xc12d4c: add             x14, x8, #1
    // 0xc12d50: stur            x14, [fp, #-0x50]
    // 0xc12d54: LoadField: r8 = r19->field_7
    //     0xc12d54: ldur            w8, [x19, #7]
    // 0xc12d58: DecompressPointer r8
    //     0xc12d58: add             x8, x8, HEAP, lsl #32
    // 0xc12d5c: stur            x8, [fp, #-0x30]
    // 0xc12d60: LoadField: r20 = r8->field_7
    //     0xc12d60: ldur            w20, [x8, #7]
    // 0xc12d64: r23 = LoadInt32Instr(r20)
    //     0xc12d64: sbfx            x23, x20, #1, #0x1f
    // 0xc12d68: add             x20, x12, x23
    // 0xc12d6c: stur            x20, [fp, #-0x48]
    // 0xc12d70: r0 = TextSelection()
    //     0xc12d70: bl              #0x861260  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xc12d74: mov             x3, x0
    // 0xc12d78: ldur            x0, [fp, #-0x60]
    // 0xc12d7c: stur            x3, [fp, #-0xb8]
    // 0xc12d80: ArrayStore: r3[0] = r0  ; List_8
    //     0xc12d80: stur            x0, [x3, #0x17]
    // 0xc12d84: ldur            x2, [fp, #-0x48]
    // 0xc12d88: StoreField: r3->field_1f = r2
    //     0xc12d88: stur            x2, [x3, #0x1f]
    // 0xc12d8c: r4 = Instance_TextAffinity
    //     0xc12d8c: ldr             x4, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xc12d90: StoreField: r3->field_27 = r4
    //     0xc12d90: stur            w4, [x3, #0x27]
    // 0xc12d94: r5 = false
    //     0xc12d94: add             x5, NULL, #0x30  ; false
    // 0xc12d98: StoreField: r3->field_2b = r5
    //     0xc12d98: stur            w5, [x3, #0x2b]
    // 0xc12d9c: cmp             x0, x2
    // 0xc12da0: b.ge            #0xc12dac
    // 0xc12da4: mov             x1, x0
    // 0xc12da8: b               #0xc12db0
    // 0xc12dac: mov             x1, x2
    // 0xc12db0: cmp             x0, x2
    // 0xc12db4: b.ge            #0xc12dbc
    // 0xc12db8: mov             x0, x2
    // 0xc12dbc: ldur            x6, [fp, #-0x38]
    // 0xc12dc0: StoreField: r3->field_7 = r1
    //     0xc12dc0: stur            x1, [x3, #7]
    // 0xc12dc4: StoreField: r3->field_f = r0
    //     0xc12dc4: stur            x0, [x3, #0xf]
    // 0xc12dc8: ArrayLoad: r0 = r6[0]  ; List_4
    //     0xc12dc8: ldur            w0, [x6, #0x17]
    // 0xc12dcc: DecompressPointer r0
    //     0xc12dcc: add             x0, x0, HEAP, lsl #32
    // 0xc12dd0: tbnz            w0, #4, #0xc130a4
    // 0xc12dd4: ldur            x3, [fp, #-0x68]
    // 0xc12dd8: r0 = BoxInt64Instr(r3)
    //     0xc12dd8: sbfiz           x0, x3, #1, #0x1f
    //     0xc12ddc: cmp             x3, x0, asr #1
    //     0xc12de0: b.eq            #0xc12dec
    //     0xc12de4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc12de8: stur            x3, [x0, #7]
    // 0xc12dec: stur            x0, [fp, #-0xa0]
    // 0xc12df0: ldur            x8, [fp, #-0x70]
    // 0xc12df4: ldur            x1, [fp, #-0x28]
    // 0xc12df8: ldur            x6, [fp, #-0x20]
    // 0xc12dfc: ldur            x7, [fp, #-0x78]
    // 0xc12e00: stur            x8, [fp, #-0x60]
    // 0xc12e04: CheckStackOverflow
    //     0xc12e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc12e08: cmp             SP, x16
    //     0xc12e0c: b.ls            #0xc13b0c
    // 0xc12e10: LoadField: r9 = r6->field_b
    //     0xc12e10: ldur            w9, [x6, #0xb]
    // 0xc12e14: r10 = LoadInt32Instr(r9)
    //     0xc12e14: sbfx            x10, x9, #1, #0x1f
    // 0xc12e18: cmp             x10, x8
    // 0xc12e1c: b.le            #0xc13014
    // 0xc12e20: LoadField: r9 = r6->field_f
    //     0xc12e20: ldur            w9, [x6, #0xf]
    // 0xc12e24: DecompressPointer r9
    //     0xc12e24: add             x9, x9, HEAP, lsl #32
    // 0xc12e28: ArrayLoad: r10 = r9[r8]  ; Unknown_4
    //     0xc12e28: add             x16, x9, x8, lsl #2
    //     0xc12e2c: ldur            w10, [x16, #0xf]
    // 0xc12e30: DecompressPointer r10
    //     0xc12e30: add             x10, x10, HEAP, lsl #32
    // 0xc12e34: stur            x10, [fp, #-0x98]
    // 0xc12e38: r0 = PlaceholderSpanIndexSemanticsTag()
    //     0xc12e38: bl              #0xbfa6fc  ; AllocatePlaceholderSpanIndexSemanticsTagStub -> PlaceholderSpanIndexSemanticsTag (size=0x14)
    // 0xc12e3c: mov             x3, x0
    // 0xc12e40: ldur            x0, [fp, #-0x68]
    // 0xc12e44: stur            x3, [fp, #-0xa8]
    // 0xc12e48: StoreField: r3->field_b = r0
    //     0xc12e48: stur            x0, [x3, #0xb]
    // 0xc12e4c: r1 = Null
    //     0xc12e4c: mov             x1, NULL
    // 0xc12e50: r2 = 6
    //     0xc12e50: mov             x2, #6
    // 0xc12e54: r0 = AllocateArray()
    //     0xc12e54: bl              #0x13df928  ; AllocateArrayStub
    // 0xc12e58: r16 = "PlaceholderSpanIndexSemanticsTag("
    //     0xc12e58: add             x16, PP, #0x7c, lsl #12  ; [pp+0x7cf00] "PlaceholderSpanIndexSemanticsTag("
    //     0xc12e5c: ldr             x16, [x16, #0xf00]
    // 0xc12e60: StoreField: r0->field_f = r16
    //     0xc12e60: stur            w16, [x0, #0xf]
    // 0xc12e64: ldur            x1, [fp, #-0xa0]
    // 0xc12e68: StoreField: r0->field_13 = r1
    //     0xc12e68: stur            w1, [x0, #0x13]
    // 0xc12e6c: r16 = ")"
    //     0xc12e6c: ldr             x16, [PP, #0xe60]  ; [pp+0xe60] ")"
    // 0xc12e70: ArrayStore: r0[0] = r16  ; List_4
    //     0xc12e70: stur            w16, [x0, #0x17]
    // 0xc12e74: str             x0, [SP]
    // 0xc12e78: r0 = _interpolate()
    //     0xc12e78: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xc12e7c: ldur            x2, [fp, #-0xa8]
    // 0xc12e80: StoreField: r2->field_7 = r0
    //     0xc12e80: stur            w0, [x2, #7]
    //     0xc12e84: ldurb           w16, [x2, #-1]
    //     0xc12e88: ldurb           w17, [x0, #-1]
    //     0xc12e8c: and             x16, x17, x16, lsr #2
    //     0xc12e90: tst             x16, HEAP, lsr #32
    //     0xc12e94: b.eq            #0xc12e9c
    //     0xc12e98: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc12e9c: ldur            x0, [fp, #-0x98]
    // 0xc12ea0: LoadField: r1 = r0->field_6b
    //     0xc12ea0: ldur            w1, [x0, #0x6b]
    // 0xc12ea4: DecompressPointer r1
    //     0xc12ea4: add             x1, x1, HEAP, lsl #32
    // 0xc12ea8: cmp             w1, NULL
    // 0xc12eac: b.eq            #0xc13008
    // 0xc12eb0: r0 = contains()
    //     0xc12eb0: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xc12eb4: tbnz            w0, #4, #0xc12ffc
    // 0xc12eb8: ldur            x3, [fp, #-0x20]
    // 0xc12ebc: ldur            x4, [fp, #-0x78]
    // 0xc12ec0: ldur            x5, [fp, #-0x60]
    // 0xc12ec4: LoadField: r0 = r3->field_b
    //     0xc12ec4: ldur            w0, [x3, #0xb]
    // 0xc12ec8: r1 = LoadInt32Instr(r0)
    //     0xc12ec8: sbfx            x1, x0, #1, #0x1f
    // 0xc12ecc: mov             x0, x1
    // 0xc12ed0: mov             x1, x5
    // 0xc12ed4: cmp             x1, x0
    // 0xc12ed8: b.hs            #0xc13b14
    // 0xc12edc: LoadField: r0 = r3->field_f
    //     0xc12edc: ldur            w0, [x3, #0xf]
    // 0xc12ee0: DecompressPointer r0
    //     0xc12ee0: add             x0, x0, HEAP, lsl #32
    // 0xc12ee4: ArrayLoad: r6 = r0[r5]  ; Unknown_4
    //     0xc12ee4: add             x16, x0, x5, lsl #2
    //     0xc12ee8: ldur            w6, [x16, #0xf]
    // 0xc12eec: DecompressPointer r6
    //     0xc12eec: add             x6, x6, HEAP, lsl #32
    // 0xc12ef0: stur            x6, [fp, #-0xa8]
    // 0xc12ef4: cmp             w4, NULL
    // 0xc12ef8: b.eq            #0xc13b18
    // 0xc12efc: LoadField: r7 = r4->field_7
    //     0xc12efc: ldur            w7, [x4, #7]
    // 0xc12f00: DecompressPointer r7
    //     0xc12f00: add             x7, x7, HEAP, lsl #32
    // 0xc12f04: stur            x7, [fp, #-0x98]
    // 0xc12f08: cmp             w7, NULL
    // 0xc12f0c: b.eq            #0xc13b1c
    // 0xc12f10: mov             x0, x7
    // 0xc12f14: r2 = Null
    //     0xc12f14: mov             x2, NULL
    // 0xc12f18: r1 = Null
    //     0xc12f18: mov             x1, NULL
    // 0xc12f1c: r4 = LoadClassIdInstr(r0)
    //     0xc12f1c: ldur            x4, [x0, #-1]
    //     0xc12f20: ubfx            x4, x4, #0xc, #0x14
    // 0xc12f24: r17 = 4188
    //     0xc12f24: mov             x17, #0x105c
    // 0xc12f28: cmp             x4, x17
    // 0xc12f2c: b.eq            #0xc12f44
    // 0xc12f30: r8 = TextParentData
    //     0xc12f30: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cee0] Type: TextParentData
    //     0xc12f34: ldr             x8, [x8, #0xee0]
    // 0xc12f38: r3 = Null
    //     0xc12f38: add             x3, PP, #0x98, lsl #12  ; [pp+0x98858] Null
    //     0xc12f3c: ldr             x3, [x3, #0x858]
    // 0xc12f40: r0 = DefaultTypeTest()
    //     0xc12f40: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc12f44: ldur            x0, [fp, #-0x98]
    // 0xc12f48: LoadField: r1 = r0->field_f
    //     0xc12f48: ldur            w1, [x0, #0xf]
    // 0xc12f4c: DecompressPointer r1
    //     0xc12f4c: add             x1, x1, HEAP, lsl #32
    // 0xc12f50: cmp             w1, NULL
    // 0xc12f54: b.eq            #0xc12fd4
    // 0xc12f58: ldur            x0, [fp, #-0x28]
    // 0xc12f5c: LoadField: r1 = r0->field_b
    //     0xc12f5c: ldur            w1, [x0, #0xb]
    // 0xc12f60: LoadField: r2 = r0->field_f
    //     0xc12f60: ldur            w2, [x0, #0xf]
    // 0xc12f64: DecompressPointer r2
    //     0xc12f64: add             x2, x2, HEAP, lsl #32
    // 0xc12f68: LoadField: r3 = r2->field_b
    //     0xc12f68: ldur            w3, [x2, #0xb]
    // 0xc12f6c: r2 = LoadInt32Instr(r1)
    //     0xc12f6c: sbfx            x2, x1, #1, #0x1f
    // 0xc12f70: stur            x2, [fp, #-0xb0]
    // 0xc12f74: r1 = LoadInt32Instr(r3)
    //     0xc12f74: sbfx            x1, x3, #1, #0x1f
    // 0xc12f78: cmp             x2, x1
    // 0xc12f7c: b.ne            #0xc12f88
    // 0xc12f80: mov             x1, x0
    // 0xc12f84: r0 = _growToNextCapacity()
    //     0xc12f84: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc12f88: ldur            x3, [fp, #-0x28]
    // 0xc12f8c: ldur            x2, [fp, #-0xb0]
    // 0xc12f90: add             x0, x2, #1
    // 0xc12f94: lsl             x1, x0, #1
    // 0xc12f98: StoreField: r3->field_b = r1
    //     0xc12f98: stur            w1, [x3, #0xb]
    // 0xc12f9c: LoadField: r1 = r3->field_f
    //     0xc12f9c: ldur            w1, [x3, #0xf]
    // 0xc12fa0: DecompressPointer r1
    //     0xc12fa0: add             x1, x1, HEAP, lsl #32
    // 0xc12fa4: ldur            x0, [fp, #-0xa8]
    // 0xc12fa8: ArrayStore: r1[r2] = r0  ; List_4
    //     0xc12fa8: add             x25, x1, x2, lsl #2
    //     0xc12fac: add             x25, x25, #0xf
    //     0xc12fb0: str             w0, [x25]
    //     0xc12fb4: tbz             w0, #0, #0xc12fd0
    //     0xc12fb8: ldurb           w16, [x1, #-1]
    //     0xc12fbc: ldurb           w17, [x0, #-1]
    //     0xc12fc0: and             x16, x17, x16, lsr #2
    //     0xc12fc4: tst             x16, HEAP, lsr #32
    //     0xc12fc8: b.eq            #0xc12fd0
    //     0xc12fcc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc12fd0: b               #0xc12fd8
    // 0xc12fd4: ldur            x3, [fp, #-0x28]
    // 0xc12fd8: ldur            x4, [fp, #-0x60]
    // 0xc12fdc: add             x8, x4, #1
    // 0xc12fe0: mov             x1, x3
    // 0xc12fe4: ldur            x3, [fp, #-0x68]
    // 0xc12fe8: ldur            x2, [fp, #-0x48]
    // 0xc12fec: ldur            x0, [fp, #-0xa0]
    // 0xc12ff0: r5 = false
    //     0xc12ff0: add             x5, NULL, #0x30  ; false
    // 0xc12ff4: r4 = Instance_TextAffinity
    //     0xc12ff4: ldr             x4, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0xc12ff8: b               #0xc12df8
    // 0xc12ffc: ldur            x3, [fp, #-0x28]
    // 0xc13000: ldur            x4, [fp, #-0x60]
    // 0xc13004: b               #0xc1301c
    // 0xc13008: ldur            x3, [fp, #-0x28]
    // 0xc1300c: ldur            x4, [fp, #-0x60]
    // 0xc13010: b               #0xc1301c
    // 0xc13014: mov             x3, x1
    // 0xc13018: mov             x4, x8
    // 0xc1301c: ldur            x6, [fp, #-0x68]
    // 0xc13020: ldur            x5, [fp, #-0x78]
    // 0xc13024: cmp             w5, NULL
    // 0xc13028: b.eq            #0xc13b20
    // 0xc1302c: LoadField: r7 = r5->field_7
    //     0xc1302c: ldur            w7, [x5, #7]
    // 0xc13030: DecompressPointer r7
    //     0xc13030: add             x7, x7, HEAP, lsl #32
    // 0xc13034: stur            x7, [fp, #-0x98]
    // 0xc13038: cmp             w7, NULL
    // 0xc1303c: b.eq            #0xc13b24
    // 0xc13040: mov             x0, x7
    // 0xc13044: r2 = Null
    //     0xc13044: mov             x2, NULL
    // 0xc13048: r1 = Null
    //     0xc13048: mov             x1, NULL
    // 0xc1304c: r4 = LoadClassIdInstr(r0)
    //     0xc1304c: ldur            x4, [x0, #-1]
    //     0xc13050: ubfx            x4, x4, #0xc, #0x14
    // 0xc13054: r17 = 4188
    //     0xc13054: mov             x17, #0x105c
    // 0xc13058: cmp             x4, x17
    // 0xc1305c: b.eq            #0xc13074
    // 0xc13060: r8 = TextParentData
    //     0xc13060: add             x8, PP, #0x8c, lsl #12  ; [pp+0x8cee0] Type: TextParentData
    //     0xc13064: ldr             x8, [x8, #0xee0]
    // 0xc13068: r3 = Null
    //     0xc13068: add             x3, PP, #0x98, lsl #12  ; [pp+0x98868] Null
    //     0xc1306c: ldr             x3, [x3, #0x868]
    // 0xc13070: r0 = DefaultTypeTest()
    //     0xc13070: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc13074: ldur            x0, [fp, #-0x98]
    // 0xc13078: LoadField: r1 = r0->field_b
    //     0xc13078: ldur            w1, [x0, #0xb]
    // 0xc1307c: DecompressPointer r1
    //     0xc1307c: add             x1, x1, HEAP, lsl #32
    // 0xc13080: ldur            x4, [fp, #-0x68]
    // 0xc13084: add             x0, x4, #1
    // 0xc13088: ldur            x4, [fp, #-0x58]
    // 0xc1308c: ldur            d0, [fp, #-0xc8]
    // 0xc13090: mov             x3, x0
    // 0xc13094: mov             x0, x1
    // 0xc13098: ldur            x1, [fp, #-0x60]
    // 0xc1309c: ldur            x2, [fp, #-0x28]
    // 0xc130a0: b               #0xc139f8
    // 0xc130a4: ldur            x7, [fp, #-8]
    // 0xc130a8: ldur            x4, [fp, #-0x68]
    // 0xc130ac: ldur            x5, [fp, #-0x78]
    // 0xc130b0: LoadField: r8 = r7->field_27
    //     0xc130b0: ldur            w8, [x7, #0x27]
    // 0xc130b4: DecompressPointer r8
    //     0xc130b4: add             x8, x8, HEAP, lsl #32
    // 0xc130b8: stur            x8, [fp, #-0x98]
    // 0xc130bc: cmp             w8, NULL
    // 0xc130c0: b.eq            #0xc13abc
    // 0xc130c4: mov             x0, x8
    // 0xc130c8: r2 = Null
    //     0xc130c8: mov             x2, NULL
    // 0xc130cc: r1 = Null
    //     0xc130cc: mov             x1, NULL
    // 0xc130d0: r4 = LoadClassIdInstr(r0)
    //     0xc130d0: ldur            x4, [x0, #-1]
    //     0xc130d4: ubfx            x4, x4, #0xc, #0x14
    // 0xc130d8: sub             x4, x4, #0xb46
    // 0xc130dc: cmp             x4, #1
    // 0xc130e0: b.ls            #0xc130f4
    // 0xc130e4: r8 = BoxConstraints
    //     0xc130e4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xc130e8: r3 = Null
    //     0xc130e8: add             x3, PP, #0x98, lsl #12  ; [pp+0x98878] Null
    //     0xc130ec: ldr             x3, [x3, #0x878]
    // 0xc130f0: r0 = BoxConstraints()
    //     0xc130f0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xc130f4: ldur            x1, [fp, #-8]
    // 0xc130f8: ldur            x2, [fp, #-0x98]
    // 0xc130fc: r0 = _layoutTextWithConstraints()
    //     0xc130fc: bl              #0xb5c1c8  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0xc13100: r16 = Instance_BoxHeightStyle
    //     0xc13100: ldr             x16, [PP, #0x4d30]  ; [pp+0x4d30] Obj!BoxHeightStyle@12c7301
    // 0xc13104: r30 = Instance_BoxWidthStyle
    //     0xc13104: ldr             lr, [PP, #0x4d40]  ; [pp+0x4d40] Obj!BoxWidthStyle@12c72c1
    // 0xc13108: stp             lr, x16, [SP]
    // 0xc1310c: ldur            x1, [fp, #-0x80]
    // 0xc13110: ldur            x2, [fp, #-0xb8]
    // 0xc13114: r4 = const [0, 0x4, 0x2, 0x2, boxHeightStyle, 0x2, boxWidthStyle, 0x3, null]
    //     0xc13114: ldr             x4, [PP, #0x4d00]  ; [pp+0x4d00] List(9) [0, 0x4, 0x2, 0x2, "boxHeightStyle", 0x2, "boxWidthStyle", 0x3, Null]
    // 0xc13118: r0 = getBoxesForSelection()
    //     0xc13118: bl              #0x85fc0c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0xc1311c: mov             x2, x0
    // 0xc13120: stur            x2, [fp, #-0x98]
    // 0xc13124: r0 = LoadClassIdInstr(r2)
    //     0xc13124: ldur            x0, [x2, #-1]
    //     0xc13128: ubfx            x0, x0, #0xc, #0x14
    // 0xc1312c: mov             x1, x2
    // 0xc13130: r0 = GDT[cid_x0 + 0x12b36]()
    //     0xc13130: mov             x17, #0x2b36
    //     0xc13134: movk            x17, #1, lsl #16
    //     0xc13138: add             lr, x0, x17
    //     0xc1313c: ldr             lr, [x21, lr, lsl #3]
    //     0xc13140: blr             lr
    // 0xc13144: tbnz            w0, #4, #0xc13164
    // 0xc13148: ldur            x13, [fp, #-0x58]
    // 0xc1314c: ldur            d0, [fp, #-0xc8]
    // 0xc13150: ldur            x11, [fp, #-0x68]
    // 0xc13154: ldur            x10, [fp, #-0x70]
    // 0xc13158: ldur            x9, [fp, #-0x78]
    // 0xc1315c: ldur            x2, [fp, #-0x28]
    // 0xc13160: b               #0xc13a08
    // 0xc13164: ldur            x2, [fp, #-0x98]
    // 0xc13168: r0 = LoadClassIdInstr(r2)
    //     0xc13168: ldur            x0, [x2, #-1]
    //     0xc1316c: ubfx            x0, x0, #0xc, #0x14
    // 0xc13170: mov             x1, x2
    // 0xc13174: r0 = GDT[cid_x0 + 0x127b5]()
    //     0xc13174: mov             x17, #0x27b5
    //     0xc13178: movk            x17, #1, lsl #16
    //     0xc1317c: add             lr, x0, x17
    //     0xc13180: ldr             lr, [x21, lr, lsl #3]
    //     0xc13184: blr             lr
    // 0xc13188: LoadField: d0 = r0->field_7
    //     0xc13188: ldur            d0, [x0, #7]
    // 0xc1318c: stur            d0, [fp, #-0xe8]
    // 0xc13190: LoadField: d1 = r0->field_f
    //     0xc13190: ldur            d1, [x0, #0xf]
    // 0xc13194: stur            d1, [fp, #-0xe0]
    // 0xc13198: ArrayLoad: d2 = r0[0]  ; List_8
    //     0xc13198: ldur            d2, [x0, #0x17]
    // 0xc1319c: stur            d2, [fp, #-0xd8]
    // 0xc131a0: LoadField: d3 = r0->field_1f
    //     0xc131a0: ldur            d3, [x0, #0x1f]
    // 0xc131a4: ldur            x2, [fp, #-0x98]
    // 0xc131a8: stur            d3, [fp, #-0xd0]
    // 0xc131ac: r0 = LoadClassIdInstr(r2)
    //     0xc131ac: ldur            x0, [x2, #-1]
    //     0xc131b0: ubfx            x0, x0, #0xc, #0x14
    // 0xc131b4: mov             x1, x2
    // 0xc131b8: r0 = GDT[cid_x0 + 0x127b5]()
    //     0xc131b8: mov             x17, #0x27b5
    //     0xc131bc: movk            x17, #1, lsl #16
    //     0xc131c0: add             lr, x0, x17
    //     0xc131c4: ldr             lr, [x21, lr, lsl #3]
    //     0xc131c8: blr             lr
    // 0xc131cc: LoadField: r2 = r0->field_27
    //     0xc131cc: ldur            w2, [x0, #0x27]
    // 0xc131d0: DecompressPointer r2
    //     0xc131d0: add             x2, x2, HEAP, lsl #32
    // 0xc131d4: ldur            x0, [fp, #-0x98]
    // 0xc131d8: stur            x2, [fp, #-0xa8]
    // 0xc131dc: LoadField: r3 = r0->field_7
    //     0xc131dc: ldur            w3, [x0, #7]
    // 0xc131e0: DecompressPointer r3
    //     0xc131e0: add             x3, x3, HEAP, lsl #32
    // 0xc131e4: mov             x1, x3
    // 0xc131e8: stur            x3, [fp, #-0xa0]
    // 0xc131ec: r0 = SubListIterable()
    //     0xc131ec: bl              #0x82e540  ; AllocateSubListIterableStub -> SubListIterable<X0> (size=0x1c)
    // 0xc131f0: mov             x1, x0
    // 0xc131f4: ldur            x2, [fp, #-0x98]
    // 0xc131f8: r3 = 1
    //     0xc131f8: mov             x3, #1
    // 0xc131fc: r5 = Null
    //     0xc131fc: mov             x5, NULL
    // 0xc13200: stur            x0, [fp, #-0x98]
    // 0xc13204: r0 = SubListIterable()
    //     0xc13204: bl              #0x82e364  ; [dart:_internal] SubListIterable::SubListIterable
    // 0xc13208: ldur            x16, [fp, #-0x98]
    // 0xc1320c: str             x16, [SP]
    // 0xc13210: r0 = length()
    //     0xc13210: bl              #0xbfb9c4  ; [dart:_internal] SubListIterable::length
    // 0xc13214: r1 = LoadInt32Instr(r0)
    //     0xc13214: sbfx            x1, x0, #1, #0x1f
    //     0xc13218: tbz             w0, #0, #0xc13220
    //     0xc1321c: ldur            x1, [x0, #7]
    // 0xc13220: stur            x1, [fp, #-0xb0]
    // 0xc13224: ldur            x0, [fp, #-0xa8]
    // 0xc13228: ldur            d3, [fp, #-0xe8]
    // 0xc1322c: ldur            d2, [fp, #-0xe0]
    // 0xc13230: ldur            d1, [fp, #-0xd8]
    // 0xc13234: ldur            d0, [fp, #-0xd0]
    // 0xc13238: r2 = 0
    //     0xc13238: mov             x2, #0
    // 0xc1323c: stur            x0, [fp, #-0xa8]
    // 0xc13240: stur            x2, [fp, #-0x60]
    // 0xc13244: stur            d3, [fp, #-0xd0]
    // 0xc13248: stur            d2, [fp, #-0xd8]
    // 0xc1324c: stur            d1, [fp, #-0xe0]
    // 0xc13250: stur            d0, [fp, #-0xe8]
    // 0xc13254: CheckStackOverflow
    //     0xc13254: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc13258: cmp             SP, x16
    //     0xc1325c: b.ls            #0xc13b28
    // 0xc13260: ldur            x16, [fp, #-0x98]
    // 0xc13264: str             x16, [SP]
    // 0xc13268: r0 = length()
    //     0xc13268: bl              #0xbfb9c4  ; [dart:_internal] SubListIterable::length
    // 0xc1326c: r1 = LoadInt32Instr(r0)
    //     0xc1326c: sbfx            x1, x0, #1, #0x1f
    //     0xc13270: tbz             w0, #0, #0xc13278
    //     0xc13274: ldur            x1, [x0, #7]
    // 0xc13278: ldur            x0, [fp, #-0xb0]
    // 0xc1327c: cmp             x0, x1
    // 0xc13280: b.ne            #0xc13a9c
    // 0xc13284: ldur            x3, [fp, #-0x60]
    // 0xc13288: cmp             x3, x1
    // 0xc1328c: b.ge            #0xc13344
    // 0xc13290: ldur            x1, [fp, #-0x98]
    // 0xc13294: mov             x2, x3
    // 0xc13298: r0 = elementAt()
    //     0xc13298: bl              #0xafd898  ; [dart:_internal] SubListIterable::elementAt
    // 0xc1329c: mov             x3, x0
    // 0xc132a0: ldur            x0, [fp, #-0x60]
    // 0xc132a4: stur            x3, [fp, #-0xb8]
    // 0xc132a8: add             x4, x0, #1
    // 0xc132ac: stur            x4, [fp, #-0xc0]
    // 0xc132b0: cmp             w3, NULL
    // 0xc132b4: b.ne            #0xc132e8
    // 0xc132b8: mov             x0, x3
    // 0xc132bc: ldur            x2, [fp, #-0xa0]
    // 0xc132c0: r1 = Null
    //     0xc132c0: mov             x1, NULL
    // 0xc132c4: cmp             w2, NULL
    // 0xc132c8: b.eq            #0xc132e8
    // 0xc132cc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xc132cc: ldur            w4, [x2, #0x17]
    // 0xc132d0: DecompressPointer r4
    //     0xc132d0: add             x4, x4, HEAP, lsl #32
    // 0xc132d4: r8 = X0
    //     0xc132d4: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xc132d8: LoadField: r9 = r4->field_7
    //     0xc132d8: ldur            x9, [x4, #7]
    // 0xc132dc: r3 = Null
    //     0xc132dc: add             x3, PP, #0x98, lsl #12  ; [pp+0x98888] Null
    //     0xc132e0: ldr             x3, [x3, #0x888]
    // 0xc132e4: blr             x9
    // 0xc132e8: ldur            x0, [fp, #-0xb8]
    // 0xc132ec: ldur            d3, [fp, #-0xd0]
    // 0xc132f0: ldur            d2, [fp, #-0xd8]
    // 0xc132f4: ldur            d1, [fp, #-0xe0]
    // 0xc132f8: ldur            d0, [fp, #-0xe8]
    // 0xc132fc: LoadField: d4 = r0->field_7
    //     0xc132fc: ldur            d4, [x0, #7]
    // 0xc13300: LoadField: d5 = r0->field_f
    //     0xc13300: ldur            d5, [x0, #0xf]
    // 0xc13304: ArrayLoad: d6 = r0[0]  ; List_8
    //     0xc13304: ldur            d6, [x0, #0x17]
    // 0xc13308: LoadField: d7 = r0->field_1f
    //     0xc13308: ldur            d7, [x0, #0x1f]
    // 0xc1330c: fmin            v8.2d, v3.2d, v4.2d
    // 0xc13310: fmin            v4.2d, v2.2d, v5.2d
    // 0xc13314: fmax            v5.2d, v1.2d, v6.2d
    // 0xc13318: fmax            v6.2d, v0.2d, v7.2d
    // 0xc1331c: LoadField: r1 = r0->field_27
    //     0xc1331c: ldur            w1, [x0, #0x27]
    // 0xc13320: DecompressPointer r1
    //     0xc13320: add             x1, x1, HEAP, lsl #32
    // 0xc13324: mov             x0, x1
    // 0xc13328: ldur            x2, [fp, #-0xc0]
    // 0xc1332c: mov             v3.16b, v8.16b
    // 0xc13330: mov             v2.16b, v4.16b
    // 0xc13334: mov             v1.16b, v5.16b
    // 0xc13338: mov             v0.16b, v6.16b
    // 0xc1333c: ldur            x1, [fp, #-0xb0]
    // 0xc13340: b               #0xc1323c
    // 0xc13344: ldur            x3, [fp, #-8]
    // 0xc13348: ldur            d3, [fp, #-0xd0]
    // 0xc1334c: ldur            d2, [fp, #-0xd8]
    // 0xc13350: ldur            d1, [fp, #-0xe0]
    // 0xc13354: ldur            d0, [fp, #-0xe8]
    // 0xc13358: d4 = 0.000000
    //     0xc13358: eor             v4.16b, v4.16b, v4.16b
    // 0xc1335c: fmax            v5.2d, v4.2d, v3.2d
    // 0xc13360: stur            d5, [fp, #-0x100]
    // 0xc13364: fmax            v6.2d, v4.2d, v2.2d
    // 0xc13368: stur            d6, [fp, #-0xf8]
    // 0xc1336c: fsub            d7, d1, d3
    // 0xc13370: stur            d7, [fp, #-0xf0]
    // 0xc13374: LoadField: r4 = r3->field_27
    //     0xc13374: ldur            w4, [x3, #0x27]
    // 0xc13378: DecompressPointer r4
    //     0xc13378: add             x4, x4, HEAP, lsl #32
    // 0xc1337c: stur            x4, [fp, #-0xa0]
    // 0xc13380: cmp             w4, NULL
    // 0xc13384: b.eq            #0xc13a80
    // 0xc13388: ldur            d1, [fp, #-0xc8]
    // 0xc1338c: ldur            x5, [fp, #-0x38]
    // 0xc13390: mov             x0, x4
    // 0xc13394: r2 = Null
    //     0xc13394: mov             x2, NULL
    // 0xc13398: r1 = Null
    //     0xc13398: mov             x1, NULL
    // 0xc1339c: r4 = LoadClassIdInstr(r0)
    //     0xc1339c: ldur            x4, [x0, #-1]
    //     0xc133a0: ubfx            x4, x4, #0xc, #0x14
    // 0xc133a4: sub             x4, x4, #0xb46
    // 0xc133a8: cmp             x4, #1
    // 0xc133ac: b.ls            #0xc133c0
    // 0xc133b0: r8 = BoxConstraints
    //     0xc133b0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xc133b4: r3 = Null
    //     0xc133b4: add             x3, PP, #0x98, lsl #12  ; [pp+0x98898] Null
    //     0xc133b8: ldr             x3, [x3, #0x898]
    // 0xc133bc: r0 = BoxConstraints()
    //     0xc133bc: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xc133c0: ldur            x0, [fp, #-0xa0]
    // 0xc133c4: LoadField: d0 = r0->field_f
    //     0xc133c4: ldur            d0, [x0, #0xf]
    // 0xc133c8: ldur            d1, [fp, #-0xf0]
    // 0xc133cc: fmin            v2.2d, v1.2d, v0.2d
    // 0xc133d0: ldur            d1, [fp, #-0xd8]
    // 0xc133d4: ldur            d0, [fp, #-0xe8]
    // 0xc133d8: fsub            d3, d0, d1
    // 0xc133dc: LoadField: d0 = r0->field_1f
    //     0xc133dc: ldur            d0, [x0, #0x1f]
    // 0xc133e0: fmin            v1.2d, v3.2d, v0.2d
    // 0xc133e4: ldur            d0, [fp, #-0x100]
    // 0xc133e8: fadd            d3, d0, d2
    // 0xc133ec: ldur            d2, [fp, #-0xf8]
    // 0xc133f0: stur            d3, [fp, #-0xd8]
    // 0xc133f4: fadd            d4, d2, d1
    // 0xc133f8: stur            d4, [fp, #-0xd0]
    // 0xc133fc: stp             fp, lr, [SP, #-0x10]!
    // 0xc13400: mov             fp, SP
    // 0xc13404: CallRuntime_LibcFloor(double) -> double
    //     0xc13404: and             SP, SP, #0xfffffffffffffff0
    //     0xc13408: mov             sp, SP
    //     0xc1340c: ldr             x16, [THR, #0x758]  ; THR::LibcFloor
    //     0xc13410: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc13414: blr             x16
    //     0xc13418: mov             x16, #8
    //     0xc1341c: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc13420: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc13424: sub             sp, x16, #1, lsl #12
    //     0xc13428: mov             SP, fp
    //     0xc1342c: ldp             fp, lr, [SP], #0x10
    // 0xc13430: d1 = 4.000000
    //     0xc13430: fmov            d1, #4.00000000
    // 0xc13434: fsub            d2, d0, d1
    // 0xc13438: ldur            d0, [fp, #-0xf8]
    // 0xc1343c: stur            d2, [fp, #-0xe0]
    // 0xc13440: stp             fp, lr, [SP, #-0x10]!
    // 0xc13444: mov             fp, SP
    // 0xc13448: CallRuntime_LibcFloor(double) -> double
    //     0xc13448: and             SP, SP, #0xfffffffffffffff0
    //     0xc1344c: mov             sp, SP
    //     0xc13450: ldr             x16, [THR, #0x758]  ; THR::LibcFloor
    //     0xc13454: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc13458: blr             x16
    //     0xc1345c: mov             x16, #8
    //     0xc13460: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc13464: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc13468: sub             sp, x16, #1, lsl #12
    //     0xc1346c: mov             SP, fp
    //     0xc13470: ldp             fp, lr, [SP], #0x10
    // 0xc13474: d1 = 4.000000
    //     0xc13474: fmov            d1, #4.00000000
    // 0xc13478: fsub            d2, d0, d1
    // 0xc1347c: ldur            d0, [fp, #-0xd8]
    // 0xc13480: stur            d2, [fp, #-0xe8]
    // 0xc13484: stp             fp, lr, [SP, #-0x10]!
    // 0xc13488: mov             fp, SP
    // 0xc1348c: CallRuntime_LibcCeil(double) -> double
    //     0xc1348c: and             SP, SP, #0xfffffffffffffff0
    //     0xc13490: mov             sp, SP
    //     0xc13494: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xc13498: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc1349c: blr             x16
    //     0xc134a0: mov             x16, #8
    //     0xc134a4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc134a8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc134ac: sub             sp, x16, #1, lsl #12
    //     0xc134b0: mov             SP, fp
    //     0xc134b4: ldp             fp, lr, [SP], #0x10
    // 0xc134b8: d1 = 4.000000
    //     0xc134b8: fmov            d1, #4.00000000
    // 0xc134bc: fadd            d2, d0, d1
    // 0xc134c0: ldur            d0, [fp, #-0xd0]
    // 0xc134c4: stur            d2, [fp, #-0xd8]
    // 0xc134c8: stp             fp, lr, [SP, #-0x10]!
    // 0xc134cc: mov             fp, SP
    // 0xc134d0: CallRuntime_LibcCeil(double) -> double
    //     0xc134d0: and             SP, SP, #0xfffffffffffffff0
    //     0xc134d4: mov             sp, SP
    //     0xc134d8: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xc134dc: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc134e0: blr             x16
    //     0xc134e4: mov             x16, #8
    //     0xc134e8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc134ec: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc134f0: sub             sp, x16, #1, lsl #12
    //     0xc134f4: mov             SP, fp
    //     0xc134f8: ldp             fp, lr, [SP], #0x10
    // 0xc134fc: mov             v1.16b, v0.16b
    // 0xc13500: d0 = 4.000000
    //     0xc13500: fmov            d0, #4.00000000
    // 0xc13504: fadd            d2, d1, d0
    // 0xc13508: stur            d2, [fp, #-0xd0]
    // 0xc1350c: r0 = Rect()
    //     0xc1350c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc13510: ldur            d0, [fp, #-0xe0]
    // 0xc13514: stur            x0, [fp, #-0xa0]
    // 0xc13518: StoreField: r0->field_7 = d0
    //     0xc13518: stur            d0, [x0, #7]
    // 0xc1351c: ldur            d1, [fp, #-0xe8]
    // 0xc13520: StoreField: r0->field_f = d1
    //     0xc13520: stur            d1, [x0, #0xf]
    // 0xc13524: ldur            d2, [fp, #-0xd8]
    // 0xc13528: ArrayStore: r0[0] = d2  ; List_8
    //     0xc13528: stur            d2, [x0, #0x17]
    // 0xc1352c: ldur            d3, [fp, #-0xd0]
    // 0xc13530: StoreField: r0->field_1f = d3
    //     0xc13530: stur            d3, [x0, #0x1f]
    // 0xc13534: r0 = SemanticsConfiguration()
    //     0xc13534: bl              #0x839284  ; AllocateSemanticsConfigurationStub -> SemanticsConfiguration (size=0xc8)
    // 0xc13538: mov             x1, x0
    // 0xc1353c: stur            x0, [fp, #-0xb8]
    // 0xc13540: r0 = SemanticsConfiguration()
    //     0xc13540: bl              #0x837c94  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::SemanticsConfiguration
    // 0xc13544: ldur            d1, [fp, #-0xc8]
    // 0xc13548: d0 = 1.000000
    //     0xc13548: fmov            d0, #1.00000000
    // 0xc1354c: fadd            d2, d1, d0
    // 0xc13550: stur            d2, [fp, #-0xf0]
    // 0xc13554: r0 = OrdinalSortKey()
    //     0xc13554: bl              #0xc121a8  ; AllocateOrdinalSortKeyStub -> OrdinalSortKey (size=0x14)
    // 0xc13558: ldur            d0, [fp, #-0xc8]
    // 0xc1355c: StoreField: r0->field_b = d0
    //     0xc1355c: stur            d0, [x0, #0xb]
    // 0xc13560: ldur            x1, [fp, #-0xb8]
    // 0xc13564: StoreField: r1->field_33 = r0
    //     0xc13564: stur            w0, [x1, #0x33]
    //     0xc13568: ldurb           w16, [x1, #-1]
    //     0xc1356c: ldurb           w17, [x0, #-1]
    //     0xc13570: and             x16, x17, x16, lsr #2
    //     0xc13574: tst             x16, HEAP, lsr #32
    //     0xc13578: b.eq            #0xc13580
    //     0xc1357c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc13580: r2 = true
    //     0xc13580: add             x2, NULL, #0x20  ; true
    // 0xc13584: StoreField: r1->field_1f = r2
    //     0xc13584: stur            w2, [x1, #0x1f]
    // 0xc13588: ldur            x0, [fp, #-0x58]
    // 0xc1358c: StoreField: r1->field_83 = r0
    //     0xc1358c: stur            w0, [x1, #0x83]
    //     0xc13590: ldurb           w16, [x1, #-1]
    //     0xc13594: ldurb           w17, [x0, #-1]
    //     0xc13598: and             x16, x17, x16, lsr #2
    //     0xc1359c: tst             x16, HEAP, lsr #32
    //     0xc135a0: b.eq            #0xc135a8
    //     0xc135a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc135a8: r0 = ""
    //     0xc135a8: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0xc135ac: StoreField: r1->field_57 = r0
    //     0xc135ac: stur            w0, [x1, #0x57]
    // 0xc135b0: ldur            x3, [fp, #-0x38]
    // 0xc135b4: LoadField: r4 = r3->field_b
    //     0xc135b4: ldur            w4, [x3, #0xb]
    // 0xc135b8: DecompressPointer r4
    //     0xc135b8: add             x4, x4, HEAP, lsl #32
    // 0xc135bc: cmp             w4, NULL
    // 0xc135c0: b.ne            #0xc135c8
    // 0xc135c4: ldur            x4, [fp, #-0x30]
    // 0xc135c8: stur            x4, [fp, #-0x58]
    // 0xc135cc: LoadField: r5 = r3->field_1f
    //     0xc135cc: ldur            w5, [x3, #0x1f]
    // 0xc135d0: DecompressPointer r5
    //     0xc135d0: add             x5, x5, HEAP, lsl #32
    // 0xc135d4: stur            x5, [fp, #-0x30]
    // 0xc135d8: r0 = AttributedString()
    //     0xc135d8: bl              #0x837ffc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0xc135dc: mov             x1, x0
    // 0xc135e0: ldur            x0, [fp, #-0x58]
    // 0xc135e4: StoreField: r1->field_7 = r0
    //     0xc135e4: stur            w0, [x1, #7]
    // 0xc135e8: ldur            x0, [fp, #-0x30]
    // 0xc135ec: StoreField: r1->field_b = r0
    //     0xc135ec: stur            w0, [x1, #0xb]
    // 0xc135f0: mov             x0, x1
    // 0xc135f4: ldur            x4, [fp, #-0xb8]
    // 0xc135f8: StoreField: r4->field_67 = r0
    //     0xc135f8: stur            w0, [x4, #0x67]
    //     0xc135fc: ldurb           w16, [x4, #-1]
    //     0xc13600: ldurb           w17, [x0, #-1]
    //     0xc13604: and             x16, x17, x16, lsr #2
    //     0xc13608: tst             x16, HEAP, lsr #32
    //     0xc1360c: b.eq            #0xc13614
    //     0xc13610: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xc13614: r0 = true
    //     0xc13614: add             x0, NULL, #0x20  ; true
    // 0xc13618: StoreField: r4->field_1f = r0
    //     0xc13618: stur            w0, [x4, #0x1f]
    // 0xc1361c: ldur            x1, [fp, #-0x38]
    // 0xc13620: LoadField: r2 = r1->field_13
    //     0xc13620: ldur            w2, [x1, #0x13]
    // 0xc13624: DecompressPointer r2
    //     0xc13624: add             x2, x2, HEAP, lsl #32
    // 0xc13628: r1 = LoadClassIdInstr(r2)
    //     0xc13628: ldur            x1, [x2, #-1]
    //     0xc1362c: ubfx            x1, x1, #0xc, #0x14
    // 0xc13630: r17 = -4437
    //     0xc13630: mov             x17, #-0x1155
    // 0xc13634: add             x16, x1, x17
    // 0xc13638: cmp             x16, #1
    // 0xc1363c: b.hi            #0xc13650
    // 0xc13640: LoadField: r1 = r2->field_5f
    //     0xc13640: ldur            w1, [x2, #0x5f]
    // 0xc13644: DecompressPointer r1
    //     0xc13644: add             x1, x1, HEAP, lsl #32
    // 0xc13648: mov             x3, x1
    // 0xc1364c: b               #0xc13668
    // 0xc13650: r17 = 4429
    //     0xc13650: mov             x17, #0x114d
    // 0xc13654: cmp             x1, x17
    // 0xc13658: b.ne            #0xc136c8
    // 0xc1365c: LoadField: r1 = r2->field_1b
    //     0xc1365c: ldur            w1, [x2, #0x1b]
    // 0xc13660: DecompressPointer r1
    //     0xc13660: add             x1, x1, HEAP, lsl #32
    // 0xc13664: mov             x3, x1
    // 0xc13668: cmp             w3, NULL
    // 0xc1366c: b.eq            #0xc136f4
    // 0xc13670: mov             x1, x4
    // 0xc13674: r2 = Instance_SemanticsAction
    //     0xc13674: ldr             x2, [PP, #0x26b0]  ; [pp+0x26b0] Obj!SemanticsAction@12a0901
    // 0xc13678: r0 = _addArgumentlessAction()
    //     0xc13678: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xc1367c: ldur            x0, [fp, #-0xb8]
    // 0xc13680: LoadField: r1 = r0->field_c3
    //     0xc13680: ldur            w1, [x0, #0xc3]
    // 0xc13684: DecompressPointer r1
    //     0xc13684: add             x1, x1, HEAP, lsl #32
    // 0xc13688: r16 = true
    //     0xc13688: add             x16, NULL, #0x20  ; true
    // 0xc1368c: str             x16, [SP]
    // 0xc13690: r4 = const [0, 0x2, 0x1, 0x1, isLink, 0x1, null]
    //     0xc13690: add             x4, PP, #0x98, lsl #12  ; [pp+0x988a8] List(7) [0, 0x2, 0x1, 0x1, "isLink", 0x1, Null]
    //     0xc13694: ldr             x4, [x4, #0x8a8]
    // 0xc13698: r0 = copyWith()
    //     0xc13698: bl              #0x8905b0  ; [dart:ui] SemanticsFlags::copyWith
    // 0xc1369c: ldur            x4, [fp, #-0xb8]
    // 0xc136a0: StoreField: r4->field_c3 = r0
    //     0xc136a0: stur            w0, [x4, #0xc3]
    //     0xc136a4: ldurb           w16, [x4, #-1]
    //     0xc136a8: ldurb           w17, [x0, #-1]
    //     0xc136ac: and             x16, x17, x16, lsr #2
    //     0xc136b0: tst             x16, HEAP, lsr #32
    //     0xc136b4: b.eq            #0xc136bc
    //     0xc136b8: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xc136bc: r0 = true
    //     0xc136bc: add             x0, NULL, #0x20  ; true
    // 0xc136c0: StoreField: r4->field_1f = r0
    //     0xc136c0: stur            w0, [x4, #0x1f]
    // 0xc136c4: b               #0xc136f4
    // 0xc136c8: r17 = 4439
    //     0xc136c8: mov             x17, #0x1157
    // 0xc136cc: cmp             x1, x17
    // 0xc136d0: b.ne            #0xc136f4
    // 0xc136d4: LoadField: r3 = r2->field_5b
    //     0xc136d4: ldur            w3, [x2, #0x5b]
    // 0xc136d8: DecompressPointer r3
    //     0xc136d8: add             x3, x3, HEAP, lsl #32
    // 0xc136dc: cmp             w3, NULL
    // 0xc136e0: b.eq            #0xc136f4
    // 0xc136e4: mov             x1, x4
    // 0xc136e8: r2 = Instance_SemanticsAction
    //     0xc136e8: add             x2, PP, #0x85, lsl #12  ; [pp+0x85768] Obj!SemanticsAction@12a08e1
    //     0xc136ec: ldr             x2, [x2, #0x768]
    // 0xc136f0: r0 = _addArgumentlessAction()
    //     0xc136f0: bl              #0xbf36cc  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0xc136f4: ldur            x0, [fp, #-0x10]
    // 0xc136f8: LoadField: r1 = r0->field_23
    //     0xc136f8: ldur            w1, [x0, #0x23]
    // 0xc136fc: DecompressPointer r1
    //     0xc136fc: add             x1, x1, HEAP, lsl #32
    // 0xc13700: cmp             w1, NULL
    // 0xc13704: b.eq            #0xc137c0
    // 0xc13708: ldur            d0, [fp, #-0xe0]
    // 0xc1370c: ldur            d1, [fp, #-0xe8]
    // 0xc13710: ldur            d2, [fp, #-0xd8]
    // 0xc13714: ldur            d3, [fp, #-0xd0]
    // 0xc13718: LoadField: d4 = r1->field_7
    //     0xc13718: ldur            d4, [x1, #7]
    // 0xc1371c: fmax            v5.2d, v4.2d, v0.2d
    // 0xc13720: LoadField: d4 = r1->field_f
    //     0xc13720: ldur            d4, [x1, #0xf]
    // 0xc13724: fmax            v6.2d, v4.2d, v1.2d
    // 0xc13728: ArrayLoad: d4 = r1[0]  ; List_8
    //     0xc13728: ldur            d4, [x1, #0x17]
    // 0xc1372c: fmin            v7.2d, v4.2d, v2.2d
    // 0xc13730: LoadField: d4 = r1->field_1f
    //     0xc13730: ldur            d4, [x1, #0x1f]
    // 0xc13734: fmin            v8.2d, v4.2d, v3.2d
    // 0xc13738: fcmp            d5, d7
    // 0xc1373c: b.ge            #0xc13748
    // 0xc13740: fcmp            d6, d8
    // 0xc13744: b.lt            #0xc13774
    // 0xc13748: fcmp            d0, d2
    // 0xc1374c: b.lt            #0xc13758
    // 0xc13750: r1 = true
    //     0xc13750: add             x1, NULL, #0x20  ; true
    // 0xc13754: b               #0xc13768
    // 0xc13758: fcmp            d1, d3
    // 0xc1375c: r16 = true
    //     0xc1375c: add             x16, NULL, #0x20  ; true
    // 0xc13760: r17 = false
    //     0xc13760: add             x17, NULL, #0x30  ; false
    // 0xc13764: csel            x1, x16, x17, ge
    // 0xc13768: eor             x2, x1, #0x10
    // 0xc1376c: mov             x1, x2
    // 0xc13770: b               #0xc13778
    // 0xc13774: r1 = false
    //     0xc13774: add             x1, NULL, #0x30  ; false
    // 0xc13778: ldur            x2, [fp, #-0xb8]
    // 0xc1377c: LoadField: r3 = r2->field_c3
    //     0xc1377c: ldur            w3, [x2, #0xc3]
    // 0xc13780: DecompressPointer r3
    //     0xc13780: add             x3, x3, HEAP, lsl #32
    // 0xc13784: str             x1, [SP]
    // 0xc13788: mov             x1, x3
    // 0xc1378c: r4 = const [0, 0x2, 0x1, 0x1, isHidden, 0x1, null]
    //     0xc1378c: ldr             x4, [PP, #0x28c0]  ; [pp+0x28c0] List(7) [0, 0x2, 0x1, 0x1, "isHidden", 0x1, Null]
    // 0xc13790: r0 = copyWith()
    //     0xc13790: bl              #0x8905b0  ; [dart:ui] SemanticsFlags::copyWith
    // 0xc13794: ldur            x2, [fp, #-0xb8]
    // 0xc13798: StoreField: r2->field_c3 = r0
    //     0xc13798: stur            w0, [x2, #0xc3]
    //     0xc1379c: ldurb           w16, [x2, #-1]
    //     0xc137a0: ldurb           w17, [x0, #-1]
    //     0xc137a4: and             x16, x17, x16, lsr #2
    //     0xc137a8: tst             x16, HEAP, lsr #32
    //     0xc137ac: b.eq            #0xc137b4
    //     0xc137b0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc137b4: r0 = true
    //     0xc137b4: add             x0, NULL, #0x20  ; true
    // 0xc137b8: StoreField: r2->field_1f = r0
    //     0xc137b8: stur            w0, [x2, #0x1f]
    // 0xc137bc: b               #0xc137c8
    // 0xc137c0: ldur            x2, [fp, #-0xb8]
    // 0xc137c4: r0 = true
    //     0xc137c4: add             x0, NULL, #0x20  ; true
    // 0xc137c8: ldur            x3, [fp, #-8]
    // 0xc137cc: LoadField: r4 = r3->field_97
    //     0xc137cc: ldur            w4, [x3, #0x97]
    // 0xc137d0: DecompressPointer r4
    //     0xc137d0: add             x4, x4, HEAP, lsl #32
    // 0xc137d4: stur            x4, [fp, #-0x30]
    // 0xc137d8: cmp             w4, NULL
    // 0xc137dc: b.ne            #0xc137e8
    // 0xc137e0: r1 = Null
    //     0xc137e0: mov             x1, NULL
    // 0xc137e4: b               #0xc13810
    // 0xc137e8: LoadField: r1 = r4->field_13
    //     0xc137e8: ldur            w1, [x4, #0x13]
    // 0xc137ec: r5 = LoadInt32Instr(r1)
    //     0xc137ec: sbfx            x5, x1, #1, #0x1f
    // 0xc137f0: asr             x1, x5, #1
    // 0xc137f4: ArrayLoad: r5 = r4[0]  ; List_4
    //     0xc137f4: ldur            w5, [x4, #0x17]
    // 0xc137f8: r6 = LoadInt32Instr(r5)
    //     0xc137f8: sbfx            x6, x5, #1, #0x1f
    // 0xc137fc: sub             x5, x1, x6
    // 0xc13800: cbnz            x5, #0xc1380c
    // 0xc13804: r1 = false
    //     0xc13804: add             x1, NULL, #0x30  ; false
    // 0xc13808: b               #0xc13810
    // 0xc1380c: r1 = true
    //     0xc1380c: add             x1, NULL, #0x20  ; true
    // 0xc13810: cmp             w1, NULL
    // 0xc13814: b.ne            #0xc13820
    // 0xc13818: mov             x0, x3
    // 0xc1381c: b               #0xc138b4
    // 0xc13820: tbnz            w1, #4, #0xc138b0
    // 0xc13824: cmp             w4, NULL
    // 0xc13828: b.eq            #0xc13b30
    // 0xc1382c: r1 = <Key, SemanticsNode>
    //     0xc1382c: add             x1, PP, #0x98, lsl #12  ; [pp+0x98850] TypeArguments: <Key, SemanticsNode>
    //     0xc13830: ldr             x1, [x1, #0x850]
    // 0xc13834: r0 = _CompactKeysIterable()
    //     0xc13834: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xc13838: mov             x1, x0
    // 0xc1383c: ldur            x0, [fp, #-0x30]
    // 0xc13840: StoreField: r1->field_b = r0
    //     0xc13840: stur            w0, [x1, #0xb]
    // 0xc13844: r0 = iterator()
    //     0xc13844: bl              #0xb09a64  ; [dart:_compact_hash] _CompactKeysIterable::iterator
    // 0xc13848: mov             x2, x0
    // 0xc1384c: stur            x2, [fp, #-0x38]
    // 0xc13850: r0 = LoadClassIdInstr(r2)
    //     0xc13850: ldur            x0, [x2, #-1]
    //     0xc13854: ubfx            x0, x0, #0xc, #0x14
    // 0xc13858: mov             x1, x2
    // 0xc1385c: r0 = GDT[cid_x0 + 0x1845b]()
    //     0xc1385c: mov             x17, #0x845b
    //     0xc13860: movk            x17, #1, lsl #16
    //     0xc13864: add             lr, x0, x17
    //     0xc13868: ldr             lr, [x21, lr, lsl #3]
    //     0xc1386c: blr             lr
    // 0xc13870: tbnz            w0, #4, #0xc13a74
    // 0xc13874: ldur            x1, [fp, #-0x38]
    // 0xc13878: r0 = LoadClassIdInstr(r1)
    //     0xc13878: ldur            x0, [x1, #-1]
    //     0xc1387c: ubfx            x0, x0, #0xc, #0x14
    // 0xc13880: r0 = GDT[cid_x0 + 0x17d4c]()
    //     0xc13880: mov             x17, #0x7d4c
    //     0xc13884: movk            x17, #1, lsl #16
    //     0xc13888: add             lr, x0, x17
    //     0xc1388c: ldr             lr, [x21, lr, lsl #3]
    //     0xc13890: blr             lr
    // 0xc13894: ldur            x1, [fp, #-0x30]
    // 0xc13898: mov             x2, x0
    // 0xc1389c: r0 = remove()
    //     0xc1389c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc138a0: cmp             w0, NULL
    // 0xc138a4: b.eq            #0xc13b34
    // 0xc138a8: mov             x4, x0
    // 0xc138ac: b               #0xc13910
    // 0xc138b0: ldur            x0, [fp, #-8]
    // 0xc138b4: r1 = 2
    //     0xc138b4: mov             x1, #2
    // 0xc138b8: r0 = AllocateContext()
    //     0xc138b8: bl              #0x13de838  ; AllocateContextStub
    // 0xc138bc: mov             x1, x0
    // 0xc138c0: ldur            x0, [fp, #-8]
    // 0xc138c4: stur            x1, [fp, #-0x30]
    // 0xc138c8: StoreField: r1->field_f = r0
    //     0xc138c8: stur            w0, [x1, #0xf]
    // 0xc138cc: r0 = UniqueKey()
    //     0xc138cc: bl              #0xb8f328  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0xc138d0: ldur            x2, [fp, #-0x30]
    // 0xc138d4: stur            x0, [fp, #-0x38]
    // 0xc138d8: StoreField: r2->field_13 = r0
    //     0xc138d8: stur            w0, [x2, #0x13]
    // 0xc138dc: r0 = SemanticsNode()
    //     0xc138dc: bl              #0x894094  ; AllocateSemanticsNodeStub -> SemanticsNode (size=0xf0)
    // 0xc138e0: ldur            x2, [fp, #-0x30]
    // 0xc138e4: r1 = Function '<anonymous closure>':.
    //     0xc138e4: add             x1, PP, #0x98, lsl #12  ; [pp+0x988b0] AnonymousClosure: (0xc13c08), of [package:flutter/src/rendering/paragraph.dart] RenderParagraph
    //     0xc138e8: ldr             x1, [x1, #0x8b0]
    // 0xc138ec: stur            x0, [fp, #-0x30]
    // 0xc138f0: r0 = AllocateClosure()
    //     0xc138f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc138f4: ldur            x16, [fp, #-0x38]
    // 0xc138f8: stp             x0, x16, [SP]
    // 0xc138fc: ldur            x1, [fp, #-0x30]
    // 0xc13900: r4 = const [0, 0x3, 0x2, 0x1, key, 0x1, showOnScreen, 0x2, null]
    //     0xc13900: add             x4, PP, #0x98, lsl #12  ; [pp+0x988b8] List(9) [0, 0x3, 0x2, 0x1, "key", 0x1, "showOnScreen", 0x2, Null]
    //     0xc13904: ldr             x4, [x4, #0x8b8]
    // 0xc13908: r0 = SemanticsNode()
    //     0xc13908: bl              #0x893ce8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::SemanticsNode
    // 0xc1390c: ldur            x4, [fp, #-0x30]
    // 0xc13910: ldur            x0, [fp, #-0x28]
    // 0xc13914: ldur            x3, [fp, #-0x40]
    // 0xc13918: mov             x1, x4
    // 0xc1391c: ldur            x2, [fp, #-0xb8]
    // 0xc13920: stur            x4, [fp, #-0x30]
    // 0xc13924: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc13924: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc13928: r0 = updateWith()
    //     0xc13928: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc1392c: ldur            x1, [fp, #-0x30]
    // 0xc13930: ldur            x2, [fp, #-0xa0]
    // 0xc13934: r0 = rect=()
    //     0xc13934: bl              #0x892bd8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::rect=
    // 0xc13938: ldur            x4, [fp, #-0x30]
    // 0xc1393c: LoadField: r2 = r4->field_7
    //     0xc1393c: ldur            w2, [x4, #7]
    // 0xc13940: DecompressPointer r2
    //     0xc13940: add             x2, x2, HEAP, lsl #32
    // 0xc13944: cmp             w2, NULL
    // 0xc13948: b.eq            #0xc13b38
    // 0xc1394c: ldur            x5, [fp, #-0x40]
    // 0xc13950: r0 = LoadClassIdInstr(r5)
    //     0xc13950: ldur            x0, [x5, #-1]
    //     0xc13954: ubfx            x0, x0, #0xc, #0x14
    // 0xc13958: mov             x1, x5
    // 0xc1395c: mov             x3, x4
    // 0xc13960: r0 = GDT[cid_x0 + -0xd50]()
    //     0xc13960: sub             lr, x0, #0xd50
    //     0xc13964: ldr             lr, [x21, lr, lsl #3]
    //     0xc13968: blr             lr
    // 0xc1396c: ldur            x0, [fp, #-0x28]
    // 0xc13970: LoadField: r1 = r0->field_b
    //     0xc13970: ldur            w1, [x0, #0xb]
    // 0xc13974: LoadField: r2 = r0->field_f
    //     0xc13974: ldur            w2, [x0, #0xf]
    // 0xc13978: DecompressPointer r2
    //     0xc13978: add             x2, x2, HEAP, lsl #32
    // 0xc1397c: LoadField: r3 = r2->field_b
    //     0xc1397c: ldur            w3, [x2, #0xb]
    // 0xc13980: r2 = LoadInt32Instr(r1)
    //     0xc13980: sbfx            x2, x1, #1, #0x1f
    // 0xc13984: stur            x2, [fp, #-0x60]
    // 0xc13988: r1 = LoadInt32Instr(r3)
    //     0xc13988: sbfx            x1, x3, #1, #0x1f
    // 0xc1398c: cmp             x2, x1
    // 0xc13990: b.ne            #0xc1399c
    // 0xc13994: mov             x1, x0
    // 0xc13998: r0 = _growToNextCapacity()
    //     0xc13998: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xc1399c: ldur            x2, [fp, #-0x28]
    // 0xc139a0: ldur            x3, [fp, #-0x60]
    // 0xc139a4: add             x0, x3, #1
    // 0xc139a8: lsl             x1, x0, #1
    // 0xc139ac: StoreField: r2->field_b = r1
    //     0xc139ac: stur            w1, [x2, #0xb]
    // 0xc139b0: LoadField: r1 = r2->field_f
    //     0xc139b0: ldur            w1, [x2, #0xf]
    // 0xc139b4: DecompressPointer r1
    //     0xc139b4: add             x1, x1, HEAP, lsl #32
    // 0xc139b8: ldur            x0, [fp, #-0x30]
    // 0xc139bc: ArrayStore: r1[r3] = r0  ; List_4
    //     0xc139bc: add             x25, x1, x3, lsl #2
    //     0xc139c0: add             x25, x25, #0xf
    //     0xc139c4: str             w0, [x25]
    //     0xc139c8: tbz             w0, #0, #0xc139e4
    //     0xc139cc: ldurb           w16, [x1, #-1]
    //     0xc139d0: ldurb           w17, [x0, #-1]
    //     0xc139d4: and             x16, x17, x16, lsr #2
    //     0xc139d8: tst             x16, HEAP, lsr #32
    //     0xc139dc: b.eq            #0xc139e4
    //     0xc139e0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xc139e4: ldur            x4, [fp, #-0xa8]
    // 0xc139e8: ldur            d0, [fp, #-0xf0]
    // 0xc139ec: ldur            x3, [fp, #-0x68]
    // 0xc139f0: ldur            x1, [fp, #-0x70]
    // 0xc139f4: ldur            x0, [fp, #-0x78]
    // 0xc139f8: mov             x13, x4
    // 0xc139fc: mov             x11, x3
    // 0xc13a00: mov             x10, x1
    // 0xc13a04: mov             x9, x0
    // 0xc13a08: ldur            x12, [fp, #-0x48]
    // 0xc13a0c: ldur            x8, [fp, #-0x50]
    // 0xc13a10: mov             x5, x2
    // 0xc13a14: ldur            x2, [fp, #-8]
    // 0xc13a18: ldur            x1, [fp, #-0x80]
    // 0xc13a1c: ldur            x3, [fp, #-0x88]
    // 0xc13a20: ldur            x0, [fp, #-0x90]
    // 0xc13a24: b               #0xc12cec
    // 0xc13a28: mov             x1, x2
    // 0xc13a2c: mov             x2, x5
    // 0xc13a30: ldur            x0, [fp, #-0x40]
    // 0xc13a34: StoreField: r1->field_97 = r0
    //     0xc13a34: stur            w0, [x1, #0x97]
    //     0xc13a38: ldurb           w16, [x1, #-1]
    //     0xc13a3c: ldurb           w17, [x0, #-1]
    //     0xc13a40: and             x16, x17, x16, lsr #2
    //     0xc13a44: tst             x16, HEAP, lsr #32
    //     0xc13a48: b.eq            #0xc13a50
    //     0xc13a4c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc13a50: str             x2, [SP]
    // 0xc13a54: ldur            x1, [fp, #-0x10]
    // 0xc13a58: ldur            x2, [fp, #-0x18]
    // 0xc13a5c: r4 = const [0, 0x3, 0x1, 0x2, childrenInInversePaintOrder, 0x2, null]
    //     0xc13a5c: ldr             x4, [PP, #0x28b8]  ; [pp+0x28b8] List(7) [0, 0x3, 0x1, 0x2, "childrenInInversePaintOrder", 0x2, Null]
    // 0xc13a60: r0 = updateWith()
    //     0xc13a60: bl              #0x88e2a8  ; [package:flutter/src/semantics/semantics.dart] SemanticsNode::updateWith
    // 0xc13a64: r0 = Null
    //     0xc13a64: mov             x0, NULL
    // 0xc13a68: LeaveFrame
    //     0xc13a68: mov             SP, fp
    //     0xc13a6c: ldp             fp, lr, [SP], #0x10
    // 0xc13a70: ret
    //     0xc13a70: ret             
    // 0xc13a74: r0 = noElement()
    //     0xc13a74: bl              #0x7e3da8  ; [dart:_internal] IterableElementError::noElement
    // 0xc13a78: r0 = Throw()
    //     0xc13a78: bl              #0x13ddb2c  ; ThrowStub
    // 0xc13a7c: brk             #0
    // 0xc13a80: r0 = StateError()
    //     0xc13a80: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc13a84: mov             x1, x0
    // 0xc13a88: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xc13a88: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xc13a8c: StoreField: r1->field_b = r0
    //     0xc13a8c: stur            w0, [x1, #0xb]
    // 0xc13a90: mov             x0, x1
    // 0xc13a94: r0 = Throw()
    //     0xc13a94: bl              #0x13ddb2c  ; ThrowStub
    // 0xc13a98: brk             #0
    // 0xc13a9c: ldur            x0, [fp, #-0x98]
    // 0xc13aa0: r0 = ConcurrentModificationError()
    //     0xc13aa0: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc13aa4: mov             x1, x0
    // 0xc13aa8: ldur            x0, [fp, #-0x98]
    // 0xc13aac: StoreField: r1->field_b = r0
    //     0xc13aac: stur            w0, [x1, #0xb]
    // 0xc13ab0: mov             x0, x1
    // 0xc13ab4: r0 = Throw()
    //     0xc13ab4: bl              #0x13ddb2c  ; ThrowStub
    // 0xc13ab8: brk             #0
    // 0xc13abc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xc13abc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xc13ac0: r0 = StateError()
    //     0xc13ac0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc13ac4: mov             x1, x0
    // 0xc13ac8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xc13ac8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xc13acc: StoreField: r1->field_b = r0
    //     0xc13acc: stur            w0, [x1, #0xb]
    // 0xc13ad0: mov             x0, x1
    // 0xc13ad4: r0 = Throw()
    //     0xc13ad4: bl              #0x13ddb2c  ; ThrowStub
    // 0xc13ad8: brk             #0
    // 0xc13adc: r0 = ConcurrentModificationError()
    //     0xc13adc: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc13ae0: mov             x1, x0
    // 0xc13ae4: ldur            x0, [fp, #-0x90]
    // 0xc13ae8: StoreField: r1->field_b = r0
    //     0xc13ae8: stur            w0, [x1, #0xb]
    // 0xc13aec: mov             x0, x1
    // 0xc13af0: r0 = Throw()
    //     0xc13af0: bl              #0x13ddb2c  ; ThrowStub
    // 0xc13af4: brk             #0
    // 0xc13af8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc13af8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc13afc: b               #0xc12c0c
    // 0xc13b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13b00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc13b04: r0 = StackOverflowSharedWithFPURegs()
    //     0xc13b04: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc13b08: b               #0xc12d1c
    // 0xc13b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc13b0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc13b10: b               #0xc12e10
    // 0xc13b14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xc13b14: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0xc13b18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13b18: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc13b1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13b1c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc13b20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13b20: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc13b24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13b24: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc13b28: r0 = StackOverflowSharedWithFPURegs()
    //     0xc13b28: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc13b2c: b               #0xc13260
    // 0xc13b30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13b30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc13b34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13b34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc13b38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13b38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getBoxesForSelection(/* No info */) {
    // ** addr: 0xc13b3c, size: 0xcc
    // 0xc13b3c: EnterFrame
    //     0xc13b3c: stp             fp, lr, [SP, #-0x10]!
    //     0xc13b40: mov             fp, SP
    // 0xc13b44: AllocStack(0x28)
    //     0xc13b44: sub             SP, SP, #0x28
    // 0xc13b48: SetupParameters(RenderParagraph this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xc13b48: mov             x4, x1
    //     0xc13b4c: mov             x3, x2
    //     0xc13b50: stur            x1, [fp, #-0x10]
    //     0xc13b54: stur            x2, [fp, #-0x18]
    // 0xc13b58: CheckStackOverflow
    //     0xc13b58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc13b5c: cmp             SP, x16
    //     0xc13b60: b.ls            #0xc13c00
    // 0xc13b64: LoadField: r5 = r4->field_27
    //     0xc13b64: ldur            w5, [x4, #0x27]
    // 0xc13b68: DecompressPointer r5
    //     0xc13b68: add             x5, x5, HEAP, lsl #32
    // 0xc13b6c: stur            x5, [fp, #-8]
    // 0xc13b70: cmp             w5, NULL
    // 0xc13b74: b.eq            #0xc13be4
    // 0xc13b78: mov             x0, x5
    // 0xc13b7c: r2 = Null
    //     0xc13b7c: mov             x2, NULL
    // 0xc13b80: r1 = Null
    //     0xc13b80: mov             x1, NULL
    // 0xc13b84: r4 = LoadClassIdInstr(r0)
    //     0xc13b84: ldur            x4, [x0, #-1]
    //     0xc13b88: ubfx            x4, x4, #0xc, #0x14
    // 0xc13b8c: sub             x4, x4, #0xb46
    // 0xc13b90: cmp             x4, #1
    // 0xc13b94: b.ls            #0xc13ba8
    // 0xc13b98: r8 = BoxConstraints
    //     0xc13b98: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xc13b9c: r3 = Null
    //     0xc13b9c: add             x3, PP, #0x97, lsl #12  ; [pp+0x97950] Null
    //     0xc13ba0: ldr             x3, [x3, #0x950]
    // 0xc13ba4: r0 = BoxConstraints()
    //     0xc13ba4: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xc13ba8: ldur            x1, [fp, #-0x10]
    // 0xc13bac: ldur            x2, [fp, #-8]
    // 0xc13bb0: r0 = _layoutTextWithConstraints()
    //     0xc13bb0: bl              #0xb5c1c8  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0xc13bb4: ldur            x0, [fp, #-0x10]
    // 0xc13bb8: LoadField: r1 = r0->field_63
    //     0xc13bb8: ldur            w1, [x0, #0x63]
    // 0xc13bbc: DecompressPointer r1
    //     0xc13bbc: add             x1, x1, HEAP, lsl #32
    // 0xc13bc0: r16 = Instance_BoxHeightStyle
    //     0xc13bc0: ldr             x16, [PP, #0x4d30]  ; [pp+0x4d30] Obj!BoxHeightStyle@12c7301
    // 0xc13bc4: r30 = Instance_BoxWidthStyle
    //     0xc13bc4: ldr             lr, [PP, #0x4d40]  ; [pp+0x4d40] Obj!BoxWidthStyle@12c72c1
    // 0xc13bc8: stp             lr, x16, [SP]
    // 0xc13bcc: ldur            x2, [fp, #-0x18]
    // 0xc13bd0: r4 = const [0, 0x4, 0x2, 0x2, boxHeightStyle, 0x2, boxWidthStyle, 0x3, null]
    //     0xc13bd0: ldr             x4, [PP, #0x4d00]  ; [pp+0x4d00] List(9) [0, 0x4, 0x2, 0x2, "boxHeightStyle", 0x2, "boxWidthStyle", 0x3, Null]
    // 0xc13bd4: r0 = getBoxesForSelection()
    //     0xc13bd4: bl              #0x85fc0c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0xc13bd8: LeaveFrame
    //     0xc13bd8: mov             SP, fp
    //     0xc13bdc: ldp             fp, lr, [SP], #0x10
    // 0xc13be0: ret
    //     0xc13be0: ret             
    // 0xc13be4: r0 = StateError()
    //     0xc13be4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc13be8: mov             x1, x0
    // 0xc13bec: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xc13bec: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xc13bf0: StoreField: r1->field_b = r0
    //     0xc13bf0: stur            w0, [x1, #0xb]
    // 0xc13bf4: mov             x0, x1
    // 0xc13bf8: r0 = Throw()
    //     0xc13bf8: bl              #0x13ddb2c  ; ThrowStub
    // 0xc13bfc: brk             #0
    // 0xc13c00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc13c00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc13c04: b               #0xc13b64
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc13c08, size: 0xc0
    // 0xc13c08: EnterFrame
    //     0xc13c08: stp             fp, lr, [SP, #-0x10]!
    //     0xc13c0c: mov             fp, SP
    // 0xc13c10: AllocStack(0x20)
    //     0xc13c10: sub             SP, SP, #0x20
    // 0xc13c14: SetupParameters([dynamic _ /* r0 */])
    //     0xc13c14: ldr             x0, [fp, #0x10]
    //     0xc13c18: ldur            w3, [x0, #0x17]
    //     0xc13c1c: add             x3, x3, HEAP, lsl #32
    //     0xc13c20: stur            x3, [fp, #-0x10]
    // 0xc13c24: CheckStackOverflow
    //     0xc13c24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc13c28: cmp             SP, x16
    //     0xc13c2c: b.ls            #0xc13cb8
    // 0xc13c30: LoadField: r0 = r3->field_f
    //     0xc13c30: ldur            w0, [x3, #0xf]
    // 0xc13c34: DecompressPointer r0
    //     0xc13c34: add             x0, x0, HEAP, lsl #32
    // 0xc13c38: LoadField: r4 = r0->field_97
    //     0xc13c38: ldur            w4, [x0, #0x97]
    // 0xc13c3c: DecompressPointer r4
    //     0xc13c3c: add             x4, x4, HEAP, lsl #32
    // 0xc13c40: stur            x4, [fp, #-8]
    // 0xc13c44: cmp             w4, NULL
    // 0xc13c48: b.eq            #0xc13cc0
    // 0xc13c4c: LoadField: r2 = r3->field_13
    //     0xc13c4c: ldur            w2, [x3, #0x13]
    // 0xc13c50: DecompressPointer r2
    //     0xc13c50: add             x2, x2, HEAP, lsl #32
    // 0xc13c54: mov             x1, x4
    // 0xc13c58: r0 = _getValueOrData()
    //     0xc13c58: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc13c5c: mov             x1, x0
    // 0xc13c60: ldur            x0, [fp, #-8]
    // 0xc13c64: LoadField: r2 = r0->field_f
    //     0xc13c64: ldur            w2, [x0, #0xf]
    // 0xc13c68: DecompressPointer r2
    //     0xc13c68: add             x2, x2, HEAP, lsl #32
    // 0xc13c6c: cmp             w2, w1
    // 0xc13c70: b.ne            #0xc13c78
    // 0xc13c74: r1 = Null
    //     0xc13c74: mov             x1, NULL
    // 0xc13c78: ldur            x0, [fp, #-0x10]
    // 0xc13c7c: cmp             w1, NULL
    // 0xc13c80: b.eq            #0xc13cc4
    // 0xc13c84: LoadField: r2 = r0->field_f
    //     0xc13c84: ldur            w2, [x0, #0xf]
    // 0xc13c88: DecompressPointer r2
    //     0xc13c88: add             x2, x2, HEAP, lsl #32
    // 0xc13c8c: LoadField: r0 = r1->field_1f
    //     0xc13c8c: ldur            w0, [x1, #0x1f]
    // 0xc13c90: DecompressPointer r0
    //     0xc13c90: add             x0, x0, HEAP, lsl #32
    // 0xc13c94: stp             x0, x2, [SP]
    // 0xc13c98: mov             x1, x2
    // 0xc13c9c: r4 = const [0, 0x3, 0x2, 0x1, descendant, 0x1, rect, 0x2, null]
    //     0xc13c9c: add             x4, PP, #0x98, lsl #12  ; [pp+0x988c0] List(9) [0, 0x3, 0x2, 0x1, "descendant", 0x1, "rect", 0x2, Null]
    //     0xc13ca0: ldr             x4, [x4, #0x8c0]
    // 0xc13ca4: r0 = showOnScreen()
    //     0xc13ca4: bl              #0xbee008  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0xc13ca8: r0 = Null
    //     0xc13ca8: mov             x0, NULL
    // 0xc13cac: LeaveFrame
    //     0xc13cac: mov             SP, fp
    //     0xc13cb0: ldp             fp, lr, [SP], #0x10
    // 0xc13cb4: ret
    //     0xc13cb4: ret             
    // 0xc13cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc13cb8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc13cbc: b               #0xc13c30
    // 0xc13cc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13cc0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc13cc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc13cc4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc2846c, size: 0x3f0
    // 0xc2846c: EnterFrame
    //     0xc2846c: stp             fp, lr, [SP, #-0x10]!
    //     0xc28470: mov             fp, SP
    // 0xc28474: AllocStack(0x70)
    //     0xc28474: sub             SP, SP, #0x70
    // 0xc28478: SetupParameters(RenderParagraph this /* r1 => r5, fp-0x10 */, dynamic _ /* r2 => r4, fp-0x18 */, dynamic _ /* r3 => r3, fp-0x20 */)
    //     0xc28478: mov             x5, x1
    //     0xc2847c: mov             x4, x2
    //     0xc28480: stur            x1, [fp, #-0x10]
    //     0xc28484: stur            x2, [fp, #-0x18]
    //     0xc28488: stur            x3, [fp, #-0x20]
    // 0xc2848c: CheckStackOverflow
    //     0xc2848c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc28490: cmp             SP, x16
    //     0xc28494: b.ls            #0xc28844
    // 0xc28498: LoadField: r6 = r5->field_27
    //     0xc28498: ldur            w6, [x5, #0x27]
    // 0xc2849c: DecompressPointer r6
    //     0xc2849c: add             x6, x6, HEAP, lsl #32
    // 0xc284a0: stur            x6, [fp, #-8]
    // 0xc284a4: cmp             w6, NULL
    // 0xc284a8: b.eq            #0xc287e8
    // 0xc284ac: mov             x0, x6
    // 0xc284b0: r2 = Null
    //     0xc284b0: mov             x2, NULL
    // 0xc284b4: r1 = Null
    //     0xc284b4: mov             x1, NULL
    // 0xc284b8: r4 = LoadClassIdInstr(r0)
    //     0xc284b8: ldur            x4, [x0, #-1]
    //     0xc284bc: ubfx            x4, x4, #0xc, #0x14
    // 0xc284c0: sub             x4, x4, #0xb46
    // 0xc284c4: cmp             x4, #1
    // 0xc284c8: b.ls            #0xc284dc
    // 0xc284cc: r8 = BoxConstraints
    //     0xc284cc: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xc284d0: r3 = Null
    //     0xc284d0: add             x3, PP, #0x98, lsl #12  ; [pp+0x98910] Null
    //     0xc284d4: ldr             x3, [x3, #0x910]
    // 0xc284d8: r0 = BoxConstraints()
    //     0xc284d8: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xc284dc: ldur            x1, [fp, #-0x10]
    // 0xc284e0: ldur            x2, [fp, #-8]
    // 0xc284e4: r0 = _layoutTextWithConstraints()
    //     0xc284e4: bl              #0xb5c1c8  ; [package:flutter/src/rendering/paragraph.dart] RenderParagraph::_layoutTextWithConstraints
    // 0xc284e8: ldur            x0, [fp, #-0x10]
    // 0xc284ec: LoadField: r1 = r0->field_87
    //     0xc284ec: ldur            w1, [x0, #0x87]
    // 0xc284f0: DecompressPointer r1
    //     0xc284f0: add             x1, x1, HEAP, lsl #32
    // 0xc284f4: tbnz            w1, #4, #0xc28624
    // 0xc284f8: mov             x1, x0
    // 0xc284fc: r0 = size()
    //     0xc284fc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc28500: ldur            x1, [fp, #-0x20]
    // 0xc28504: mov             x2, x0
    // 0xc28508: r0 = &()
    //     0xc28508: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc2850c: mov             x2, x0
    // 0xc28510: ldur            x0, [fp, #-0x10]
    // 0xc28514: stur            x2, [fp, #-8]
    // 0xc28518: LoadField: r1 = r0->field_8b
    //     0xc28518: ldur            w1, [x0, #0x8b]
    // 0xc2851c: DecompressPointer r1
    //     0xc2851c: add             x1, x1, HEAP, lsl #32
    // 0xc28520: cmp             w1, NULL
    // 0xc28524: b.eq            #0xc285c4
    // 0xc28528: ldur            x1, [fp, #-0x18]
    // 0xc2852c: r0 = canvas()
    //     0xc2852c: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc28530: stur            x0, [fp, #-0x28]
    // 0xc28534: r16 = 136
    //     0xc28534: mov             x16, #0x88
    // 0xc28538: stp             x16, NULL, [SP]
    // 0xc2853c: r0 = ByteData()
    //     0xc2853c: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc28540: ldur            x2, [fp, #-8]
    // 0xc28544: stur            x0, [fp, #-0x38]
    // 0xc28548: LoadField: d0 = r2->field_7
    //     0xc28548: ldur            d0, [x2, #7]
    // 0xc2854c: stur            d0, [fp, #-0x58]
    // 0xc28550: LoadField: d1 = r2->field_f
    //     0xc28550: ldur            d1, [x2, #0xf]
    // 0xc28554: stur            d1, [fp, #-0x50]
    // 0xc28558: ArrayLoad: d2 = r2[0]  ; List_8
    //     0xc28558: ldur            d2, [x2, #0x17]
    // 0xc2855c: stur            d2, [fp, #-0x48]
    // 0xc28560: LoadField: d3 = r2->field_1f
    //     0xc28560: ldur            d3, [x2, #0x1f]
    // 0xc28564: ldur            x3, [fp, #-0x28]
    // 0xc28568: stur            d3, [fp, #-0x40]
    // 0xc2856c: LoadField: r1 = r3->field_7
    //     0xc2856c: ldur            w1, [x3, #7]
    // 0xc28570: DecompressPointer r1
    //     0xc28570: add             x1, x1, HEAP, lsl #32
    // 0xc28574: cmp             w1, NULL
    // 0xc28578: b.eq            #0xc2884c
    // 0xc2857c: LoadField: r4 = r1->field_7
    //     0xc2857c: ldur            x4, [x1, #7]
    // 0xc28580: ldr             x1, [x4]
    // 0xc28584: cbz             x1, #0xc28804
    // 0xc28588: mov             x4, x1
    // 0xc2858c: stur            x4, [fp, #-0x30]
    // 0xc28590: r1 = <Never>
    //     0xc28590: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc28594: r0 = Pointer()
    //     0xc28594: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc28598: mov             x1, x0
    // 0xc2859c: ldur            x0, [fp, #-0x30]
    // 0xc285a0: StoreField: r1->field_7 = r0
    //     0xc285a0: stur            x0, [x1, #7]
    // 0xc285a4: ldur            d0, [fp, #-0x58]
    // 0xc285a8: ldur            d1, [fp, #-0x50]
    // 0xc285ac: ldur            d2, [fp, #-0x48]
    // 0xc285b0: ldur            d3, [fp, #-0x40]
    // 0xc285b4: ldur            x3, [fp, #-0x38]
    // 0xc285b8: r2 = Null
    //     0xc285b8: mov             x2, NULL
    // 0xc285bc: r0 = __saveLayer$Method$FfiNative()
    //     0xc285bc: bl              #0xc19728  ; [dart:ui] _NativeCanvas::__saveLayer$Method$FfiNative
    // 0xc285c0: b               #0xc2860c
    // 0xc285c4: ldur            x1, [fp, #-0x18]
    // 0xc285c8: r0 = canvas()
    //     0xc285c8: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc285cc: stur            x0, [fp, #-0x28]
    // 0xc285d0: LoadField: r1 = r0->field_7
    //     0xc285d0: ldur            w1, [x0, #7]
    // 0xc285d4: DecompressPointer r1
    //     0xc285d4: add             x1, x1, HEAP, lsl #32
    // 0xc285d8: cmp             w1, NULL
    // 0xc285dc: b.eq            #0xc28850
    // 0xc285e0: LoadField: r2 = r1->field_7
    //     0xc285e0: ldur            x2, [x1, #7]
    // 0xc285e4: ldr             x1, [x2]
    // 0xc285e8: cbz             x1, #0xc28814
    // 0xc285ec: mov             x2, x1
    // 0xc285f0: stur            x2, [fp, #-0x30]
    // 0xc285f4: r1 = <Never>
    //     0xc285f4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc285f8: r0 = Pointer()
    //     0xc285f8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc285fc: mov             x1, x0
    // 0xc28600: ldur            x0, [fp, #-0x30]
    // 0xc28604: StoreField: r1->field_7 = r0
    //     0xc28604: stur            x0, [x1, #7]
    // 0xc28608: r0 = _save$Method$FfiNative()
    //     0xc28608: bl              #0xb74adc  ; [dart:ui] _NativeCanvas::_save$Method$FfiNative
    // 0xc2860c: ldur            x1, [fp, #-0x18]
    // 0xc28610: r0 = canvas()
    //     0xc28610: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc28614: mov             x1, x0
    // 0xc28618: ldur            x2, [fp, #-8]
    // 0xc2861c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc2861c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc28620: r0 = clipRect()
    //     0xc28620: bl              #0xb7b380  ; [dart:ui] _NativeCanvas::clipRect
    // 0xc28624: ldur            x0, [fp, #-0x10]
    // 0xc28628: LoadField: r2 = r0->field_63
    //     0xc28628: ldur            w2, [x0, #0x63]
    // 0xc2862c: DecompressPointer r2
    //     0xc2862c: add             x2, x2, HEAP, lsl #32
    // 0xc28630: ldur            x1, [fp, #-0x18]
    // 0xc28634: stur            x2, [fp, #-8]
    // 0xc28638: r0 = canvas()
    //     0xc28638: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc2863c: ldur            x1, [fp, #-8]
    // 0xc28640: mov             x2, x0
    // 0xc28644: ldur            x3, [fp, #-0x20]
    // 0xc28648: r0 = paint()
    //     0xc28648: bl              #0xc22fac  ; [package:flutter/src/painting/text_painter.dart] TextPainter::paint
    // 0xc2864c: ldur            x1, [fp, #-0x10]
    // 0xc28650: ldur            x2, [fp, #-0x18]
    // 0xc28654: ldur            x3, [fp, #-0x20]
    // 0xc28658: r0 = paintInlineChildren()
    //     0xc28658: bl              #0xc2885c  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::paintInlineChildren
    // 0xc2865c: ldur            x0, [fp, #-0x10]
    // 0xc28660: LoadField: r1 = r0->field_87
    //     0xc28660: ldur            w1, [x0, #0x87]
    // 0xc28664: DecompressPointer r1
    //     0xc28664: add             x1, x1, HEAP, lsl #32
    // 0xc28668: tbnz            w1, #4, #0xc287d8
    // 0xc2866c: LoadField: r1 = r0->field_8b
    //     0xc2866c: ldur            w1, [x0, #0x8b]
    // 0xc28670: DecompressPointer r1
    //     0xc28670: add             x1, x1, HEAP, lsl #32
    // 0xc28674: cmp             w1, NULL
    // 0xc28678: b.eq            #0xc28790
    // 0xc2867c: ldur            x2, [fp, #-0x20]
    // 0xc28680: ldur            x1, [fp, #-0x18]
    // 0xc28684: r0 = canvas()
    //     0xc28684: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc28688: mov             x2, x0
    // 0xc2868c: ldur            x0, [fp, #-0x20]
    // 0xc28690: stur            x2, [fp, #-8]
    // 0xc28694: LoadField: d0 = r0->field_7
    //     0xc28694: ldur            d0, [x0, #7]
    // 0xc28698: stur            d0, [fp, #-0x48]
    // 0xc2869c: LoadField: d1 = r0->field_f
    //     0xc2869c: ldur            d1, [x0, #0xf]
    // 0xc286a0: stur            d1, [fp, #-0x40]
    // 0xc286a4: LoadField: r0 = r2->field_7
    //     0xc286a4: ldur            w0, [x2, #7]
    // 0xc286a8: DecompressPointer r0
    //     0xc286a8: add             x0, x0, HEAP, lsl #32
    // 0xc286ac: cmp             w0, NULL
    // 0xc286b0: b.eq            #0xc28854
    // 0xc286b4: LoadField: r1 = r0->field_7
    //     0xc286b4: ldur            x1, [x0, #7]
    // 0xc286b8: ldr             x0, [x1]
    // 0xc286bc: cbz             x0, #0xc28824
    // 0xc286c0: ldur            x3, [fp, #-0x10]
    // 0xc286c4: stur            x0, [fp, #-0x30]
    // 0xc286c8: r1 = <Never>
    //     0xc286c8: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc286cc: r0 = Pointer()
    //     0xc286cc: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc286d0: mov             x1, x0
    // 0xc286d4: ldur            x0, [fp, #-0x30]
    // 0xc286d8: StoreField: r1->field_7 = r0
    //     0xc286d8: stur            x0, [x1, #7]
    // 0xc286dc: ldur            d0, [fp, #-0x48]
    // 0xc286e0: ldur            d1, [fp, #-0x40]
    // 0xc286e4: r0 = _translate$Method$FfiNative()
    //     0xc286e4: bl              #0xb74a38  ; [dart:ui] _NativeCanvas::_translate$Method$FfiNative
    // 0xc286e8: r16 = 136
    //     0xc286e8: mov             x16, #0x88
    // 0xc286ec: stp             x16, NULL, [SP]
    // 0xc286f0: r0 = ByteData()
    //     0xc286f0: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc286f4: stur            x0, [fp, #-8]
    // 0xc286f8: r0 = Paint()
    //     0xc286f8: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc286fc: mov             x3, x0
    // 0xc28700: ldur            x0, [fp, #-8]
    // 0xc28704: stur            x3, [fp, #-0x20]
    // 0xc28708: StoreField: r3->field_7 = r0
    //     0xc28708: stur            w0, [x3, #7]
    // 0xc2870c: mov             x1, x3
    // 0xc28710: r2 = Instance_BlendMode
    //     0xc28710: add             x2, PP, #0x28, lsl #12  ; [pp+0x287d8] Obj!BlendMode@12c8301
    //     0xc28714: ldr             x2, [x2, #0x7d8]
    // 0xc28718: r0 = blendMode=()
    //     0xc28718: bl              #0xb89d38  ; [dart:ui] Paint::blendMode=
    // 0xc2871c: ldur            x0, [fp, #-0x10]
    // 0xc28720: LoadField: r2 = r0->field_8b
    //     0xc28720: ldur            w2, [x0, #0x8b]
    // 0xc28724: DecompressPointer r2
    //     0xc28724: add             x2, x2, HEAP, lsl #32
    // 0xc28728: ldur            x1, [fp, #-0x20]
    // 0xc2872c: stur            x2, [fp, #-8]
    // 0xc28730: r0 = _ensureObjectsInitialized()
    //     0xc28730: bl              #0xaf5568  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0xc28734: r1 = LoadClassIdInstr(r0)
    //     0xc28734: ldur            x1, [x0, #-1]
    //     0xc28738: ubfx            x1, x1, #0xc, #0x14
    // 0xc2873c: stp             xzr, x0, [SP, #8]
    // 0xc28740: ldur            x16, [fp, #-8]
    // 0xc28744: str             x16, [SP]
    // 0xc28748: mov             x0, x1
    // 0xc2874c: r0 = GDT[cid_x0 + 0x18dc8]()
    //     0xc2874c: mov             x17, #0x8dc8
    //     0xc28750: movk            x17, #1, lsl #16
    //     0xc28754: add             lr, x0, x17
    //     0xc28758: ldr             lr, [x21, lr, lsl #3]
    //     0xc2875c: blr             lr
    // 0xc28760: ldur            x1, [fp, #-0x18]
    // 0xc28764: r0 = canvas()
    //     0xc28764: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc28768: ldur            x1, [fp, #-0x10]
    // 0xc2876c: stur            x0, [fp, #-8]
    // 0xc28770: r0 = size()
    //     0xc28770: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc28774: mov             x2, x0
    // 0xc28778: r1 = Instance_Offset
    //     0xc28778: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc2877c: r0 = &()
    //     0xc2877c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc28780: ldur            x1, [fp, #-8]
    // 0xc28784: mov             x2, x0
    // 0xc28788: ldur            x3, [fp, #-0x20]
    // 0xc2878c: r0 = drawRect()
    //     0xc2878c: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0xc28790: ldur            x1, [fp, #-0x18]
    // 0xc28794: r0 = canvas()
    //     0xc28794: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc28798: stur            x0, [fp, #-8]
    // 0xc2879c: LoadField: r1 = r0->field_7
    //     0xc2879c: ldur            w1, [x0, #7]
    // 0xc287a0: DecompressPointer r1
    //     0xc287a0: add             x1, x1, HEAP, lsl #32
    // 0xc287a4: cmp             w1, NULL
    // 0xc287a8: b.eq            #0xc28858
    // 0xc287ac: LoadField: r2 = r1->field_7
    //     0xc287ac: ldur            x2, [x1, #7]
    // 0xc287b0: ldr             x1, [x2]
    // 0xc287b4: cbz             x1, #0xc28834
    // 0xc287b8: mov             x2, x1
    // 0xc287bc: stur            x2, [fp, #-0x30]
    // 0xc287c0: r1 = <Never>
    //     0xc287c0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc287c4: r0 = Pointer()
    //     0xc287c4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc287c8: mov             x1, x0
    // 0xc287cc: ldur            x0, [fp, #-0x30]
    // 0xc287d0: StoreField: r1->field_7 = r0
    //     0xc287d0: stur            x0, [x1, #7]
    // 0xc287d4: r0 = _restore$Method$FfiNative()
    //     0xc287d4: bl              #0xb74908  ; [dart:ui] _NativeCanvas::_restore$Method$FfiNative
    // 0xc287d8: r0 = Null
    //     0xc287d8: mov             x0, NULL
    // 0xc287dc: LeaveFrame
    //     0xc287dc: mov             SP, fp
    //     0xc287e0: ldp             fp, lr, [SP], #0x10
    // 0xc287e4: ret
    //     0xc287e4: ret             
    // 0xc287e8: r0 = StateError()
    //     0xc287e8: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc287ec: mov             x1, x0
    // 0xc287f0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xc287f0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xc287f4: StoreField: r1->field_b = r0
    //     0xc287f4: stur            w0, [x1, #0xb]
    // 0xc287f8: mov             x0, x1
    // 0xc287fc: r0 = Throw()
    //     0xc287fc: bl              #0x13ddb2c  ; ThrowStub
    // 0xc28800: brk             #0
    // 0xc28804: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc28804: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc28808: str             x16, [SP]
    // 0xc2880c: r0 = _throwNew()
    //     0xc2880c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc28810: brk             #0
    // 0xc28814: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc28814: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc28818: str             x16, [SP]
    // 0xc2881c: r0 = _throwNew()
    //     0xc2881c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc28820: brk             #0
    // 0xc28824: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc28824: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc28828: str             x16, [SP]
    // 0xc2882c: r0 = _throwNew()
    //     0xc2882c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc28830: brk             #0
    // 0xc28834: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc28834: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc28838: str             x16, [SP]
    // 0xc2883c: r0 = _throwNew()
    //     0xc2883c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc28840: brk             #0
    // 0xc28844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc28844: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc28848: b               #0xc28498
    // 0xc2884c: r0 = NullErrorSharedWithFPURegs()
    //     0xc2884c: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc28850: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc28850: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc28854: r0 = NullErrorSharedWithFPURegs()
    //     0xc28854: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc28858: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc28858: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ clearSemantics(/* No info */) {
    // ** addr: 0xcd0540, size: 0x48
    // 0xcd0540: EnterFrame
    //     0xcd0540: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0544: mov             fp, SP
    // 0xcd0548: AllocStack(0x8)
    //     0xcd0548: sub             SP, SP, #8
    // 0xcd054c: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */)
    //     0xcd054c: mov             x0, x1
    //     0xcd0550: stur            x1, [fp, #-8]
    // 0xcd0554: CheckStackOverflow
    //     0xcd0554: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcd0558: cmp             SP, x16
    //     0xcd055c: b.ls            #0xcd0580
    // 0xcd0560: mov             x1, x0
    // 0xcd0564: r0 = clearSemantics()
    //     0xcd0564: bl              #0xcd05e8  ; [package:flutter/src/rendering/object.dart] RenderObject::clearSemantics
    // 0xcd0568: ldur            x1, [fp, #-8]
    // 0xcd056c: StoreField: r1->field_97 = rNULL
    //     0xcd056c: stur            NULL, [x1, #0x97]
    // 0xcd0570: r0 = Null
    //     0xcd0570: mov             x0, NULL
    // 0xcd0574: LeaveFrame
    //     0xcd0574: mov             SP, fp
    //     0xcd0578: ldp             fp, lr, [SP], #0x10
    // 0xcd057c: ret
    //     0xcd057c: ret             
    // 0xcd0580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0580: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd0584: b               #0xcd0560
  }
  set _ selectionColor=(/* No info */) {
    // ** addr: 0xcef750, size: 0xa0
    // 0xcef750: EnterFrame
    //     0xcef750: stp             fp, lr, [SP, #-0x10]!
    //     0xcef754: mov             fp, SP
    // 0xcef758: AllocStack(0x20)
    //     0xcef758: sub             SP, SP, #0x20
    // 0xcef75c: SetupParameters(RenderParagraph this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xcef75c: stur            x1, [fp, #-8]
    //     0xcef760: mov             x16, x2
    //     0xcef764: mov             x2, x1
    //     0xcef768: mov             x1, x16
    //     0xcef76c: stur            x1, [fp, #-0x10]
    // 0xcef770: CheckStackOverflow
    //     0xcef770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef774: cmp             SP, x16
    //     0xcef778: b.ls            #0xcef7e8
    // 0xcef77c: LoadField: r0 = r2->field_83
    //     0xcef77c: ldur            w0, [x2, #0x83]
    // 0xcef780: DecompressPointer r0
    //     0xcef780: add             x0, x0, HEAP, lsl #32
    // 0xcef784: r3 = LoadClassIdInstr(r0)
    //     0xcef784: ldur            x3, [x0, #-1]
    //     0xcef788: ubfx            x3, x3, #0xc, #0x14
    // 0xcef78c: stp             x1, x0, [SP]
    // 0xcef790: mov             x0, x3
    // 0xcef794: mov             lr, x0
    // 0xcef798: ldr             lr, [x21, lr, lsl #3]
    // 0xcef79c: blr             lr
    // 0xcef7a0: tbnz            w0, #4, #0xcef7b4
    // 0xcef7a4: r0 = Null
    //     0xcef7a4: mov             x0, NULL
    // 0xcef7a8: LeaveFrame
    //     0xcef7a8: mov             SP, fp
    //     0xcef7ac: ldp             fp, lr, [SP], #0x10
    // 0xcef7b0: ret
    //     0xcef7b0: ret             
    // 0xcef7b4: ldur            x1, [fp, #-8]
    // 0xcef7b8: ldur            x0, [fp, #-0x10]
    // 0xcef7bc: StoreField: r1->field_83 = r0
    //     0xcef7bc: stur            w0, [x1, #0x83]
    //     0xcef7c0: ldurb           w16, [x1, #-1]
    //     0xcef7c4: ldurb           w17, [x0, #-1]
    //     0xcef7c8: and             x16, x17, x16, lsr #2
    //     0xcef7cc: tst             x16, HEAP, lsr #32
    //     0xcef7d0: b.eq            #0xcef7d8
    //     0xcef7d4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcef7d8: r0 = Null
    //     0xcef7d8: mov             x0, NULL
    // 0xcef7dc: LeaveFrame
    //     0xcef7dc: mov             SP, fp
    //     0xcef7e0: ldp             fp, lr, [SP], #0x10
    // 0xcef7e4: ret
    //     0xcef7e4: ret             
    // 0xcef7e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef7e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef7ec: b               #0xcef77c
  }
  set _ locale=(/* No info */) {
    // ** addr: 0xcef7f0, size: 0x98
    // 0xcef7f0: EnterFrame
    //     0xcef7f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcef7f4: mov             fp, SP
    // 0xcef7f8: AllocStack(0x28)
    //     0xcef7f8: sub             SP, SP, #0x28
    // 0xcef7fc: SetupParameters(RenderParagraph this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xcef7fc: stur            x1, [fp, #-0x10]
    //     0xcef800: stur            x2, [fp, #-0x18]
    // 0xcef804: CheckStackOverflow
    //     0xcef804: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef808: cmp             SP, x16
    //     0xcef80c: b.ls            #0xcef880
    // 0xcef810: LoadField: r3 = r1->field_63
    //     0xcef810: ldur            w3, [x1, #0x63]
    // 0xcef814: DecompressPointer r3
    //     0xcef814: add             x3, x3, HEAP, lsl #32
    // 0xcef818: stur            x3, [fp, #-8]
    // 0xcef81c: LoadField: r0 = r3->field_27
    //     0xcef81c: ldur            w0, [x3, #0x27]
    // 0xcef820: DecompressPointer r0
    //     0xcef820: add             x0, x0, HEAP, lsl #32
    // 0xcef824: r4 = LoadClassIdInstr(r0)
    //     0xcef824: ldur            x4, [x0, #-1]
    //     0xcef828: ubfx            x4, x4, #0xc, #0x14
    // 0xcef82c: stp             x2, x0, [SP]
    // 0xcef830: mov             x0, x4
    // 0xcef834: mov             lr, x0
    // 0xcef838: ldr             lr, [x21, lr, lsl #3]
    // 0xcef83c: blr             lr
    // 0xcef840: tbnz            w0, #4, #0xcef854
    // 0xcef844: r0 = Null
    //     0xcef844: mov             x0, NULL
    // 0xcef848: LeaveFrame
    //     0xcef848: mov             SP, fp
    //     0xcef84c: ldp             fp, lr, [SP], #0x10
    // 0xcef850: ret
    //     0xcef850: ret             
    // 0xcef854: ldur            x0, [fp, #-0x10]
    // 0xcef858: ldur            x1, [fp, #-8]
    // 0xcef85c: ldur            x2, [fp, #-0x18]
    // 0xcef860: r0 = locale=()
    //     0xcef860: bl              #0xb1cf68  ; [package:flutter/src/painting/text_painter.dart] TextPainter::locale=
    // 0xcef864: ldur            x1, [fp, #-0x10]
    // 0xcef868: StoreField: r1->field_8b = rNULL
    //     0xcef868: stur            NULL, [x1, #0x8b]
    // 0xcef86c: r0 = markNeedsLayout()
    //     0xcef86c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcef870: r0 = Null
    //     0xcef870: mov             x0, NULL
    // 0xcef874: LeaveFrame
    //     0xcef874: mov             SP, fp
    //     0xcef878: ldp             fp, lr, [SP], #0x10
    // 0xcef87c: ret
    //     0xcef87c: ret             
    // 0xcef880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef880: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef884: b               #0xcef810
  }
  set _ strutStyle=(/* No info */) {
    // ** addr: 0xcef888, size: 0x94
    // 0xcef888: EnterFrame
    //     0xcef888: stp             fp, lr, [SP, #-0x10]!
    //     0xcef88c: mov             fp, SP
    // 0xcef890: AllocStack(0x20)
    //     0xcef890: sub             SP, SP, #0x20
    // 0xcef894: SetupParameters(RenderParagraph this /* r1 => r1, fp-0x10 */)
    //     0xcef894: stur            x1, [fp, #-0x10]
    // 0xcef898: CheckStackOverflow
    //     0xcef898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef89c: cmp             SP, x16
    //     0xcef8a0: b.ls            #0xcef914
    // 0xcef8a4: LoadField: r2 = r1->field_63
    //     0xcef8a4: ldur            w2, [x1, #0x63]
    // 0xcef8a8: DecompressPointer r2
    //     0xcef8a8: add             x2, x2, HEAP, lsl #32
    // 0xcef8ac: stur            x2, [fp, #-8]
    // 0xcef8b0: LoadField: r0 = r2->field_2f
    //     0xcef8b0: ldur            w0, [x2, #0x2f]
    // 0xcef8b4: DecompressPointer r0
    //     0xcef8b4: add             x0, x0, HEAP, lsl #32
    // 0xcef8b8: r3 = LoadClassIdInstr(r0)
    //     0xcef8b8: ldur            x3, [x0, #-1]
    //     0xcef8bc: ubfx            x3, x3, #0xc, #0x14
    // 0xcef8c0: stp             NULL, x0, [SP]
    // 0xcef8c4: mov             x0, x3
    // 0xcef8c8: mov             lr, x0
    // 0xcef8cc: ldr             lr, [x21, lr, lsl #3]
    // 0xcef8d0: blr             lr
    // 0xcef8d4: tbnz            w0, #4, #0xcef8e8
    // 0xcef8d8: r0 = Null
    //     0xcef8d8: mov             x0, NULL
    // 0xcef8dc: LeaveFrame
    //     0xcef8dc: mov             SP, fp
    //     0xcef8e0: ldp             fp, lr, [SP], #0x10
    // 0xcef8e4: ret
    //     0xcef8e4: ret             
    // 0xcef8e8: ldur            x0, [fp, #-0x10]
    // 0xcef8ec: ldur            x1, [fp, #-8]
    // 0xcef8f0: r2 = Null
    //     0xcef8f0: mov             x2, NULL
    // 0xcef8f4: r0 = strutStyle=()
    //     0xcef8f4: bl              #0xb1cec4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::strutStyle=
    // 0xcef8f8: ldur            x1, [fp, #-0x10]
    // 0xcef8fc: StoreField: r1->field_8b = rNULL
    //     0xcef8fc: stur            NULL, [x1, #0x8b]
    // 0xcef900: r0 = markNeedsLayout()
    //     0xcef900: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcef904: r0 = Null
    //     0xcef904: mov             x0, NULL
    // 0xcef908: LeaveFrame
    //     0xcef908: mov             SP, fp
    //     0xcef90c: ldp             fp, lr, [SP], #0x10
    // 0xcef910: ret
    //     0xcef910: ret             
    // 0xcef914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef918: b               #0xcef8a4
  }
  set _ maxLines=(/* No info */) {
    // ** addr: 0xcef91c, size: 0xa8
    // 0xcef91c: EnterFrame
    //     0xcef91c: stp             fp, lr, [SP, #-0x10]!
    //     0xcef920: mov             fp, SP
    // 0xcef924: AllocStack(0x8)
    //     0xcef924: sub             SP, SP, #8
    // 0xcef928: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */)
    //     0xcef928: mov             x0, x1
    //     0xcef92c: stur            x1, [fp, #-8]
    // 0xcef930: CheckStackOverflow
    //     0xcef930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef934: cmp             SP, x16
    //     0xcef938: b.ls            #0xcef9bc
    // 0xcef93c: LoadField: r1 = r0->field_63
    //     0xcef93c: ldur            w1, [x0, #0x63]
    // 0xcef940: DecompressPointer r1
    //     0xcef940: add             x1, x1, HEAP, lsl #32
    // 0xcef944: LoadField: r3 = r1->field_2b
    //     0xcef944: ldur            w3, [x1, #0x2b]
    // 0xcef948: DecompressPointer r3
    //     0xcef948: add             x3, x3, HEAP, lsl #32
    // 0xcef94c: cmp             w3, w2
    // 0xcef950: b.eq            #0xcef98c
    // 0xcef954: and             w16, w3, w2
    // 0xcef958: branchIfSmi(r16, 0xcef99c)
    //     0xcef958: tbz             w16, #0, #0xcef99c
    // 0xcef95c: r16 = LoadClassIdInstr(r3)
    //     0xcef95c: ldur            x16, [x3, #-1]
    //     0xcef960: ubfx            x16, x16, #0xc, #0x14
    // 0xcef964: cmp             x16, #0x3d
    // 0xcef968: b.ne            #0xcef99c
    // 0xcef96c: r16 = LoadClassIdInstr(r2)
    //     0xcef96c: ldur            x16, [x2, #-1]
    //     0xcef970: ubfx            x16, x16, #0xc, #0x14
    // 0xcef974: cmp             x16, #0x3d
    // 0xcef978: b.ne            #0xcef99c
    // 0xcef97c: LoadField: r16 = r3->field_7
    //     0xcef97c: ldur            x16, [x3, #7]
    // 0xcef980: LoadField: r17 = r2->field_7
    //     0xcef980: ldur            x17, [x2, #7]
    // 0xcef984: cmp             x16, x17
    // 0xcef988: b.ne            #0xcef99c
    // 0xcef98c: r0 = Null
    //     0xcef98c: mov             x0, NULL
    // 0xcef990: LeaveFrame
    //     0xcef990: mov             SP, fp
    //     0xcef994: ldp             fp, lr, [SP], #0x10
    // 0xcef998: ret
    //     0xcef998: ret             
    // 0xcef99c: r0 = maxLines=()
    //     0xcef99c: bl              #0xb1cda8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::maxLines=
    // 0xcef9a0: ldur            x1, [fp, #-8]
    // 0xcef9a4: StoreField: r1->field_8b = rNULL
    //     0xcef9a4: stur            NULL, [x1, #0x8b]
    // 0xcef9a8: r0 = markNeedsLayout()
    //     0xcef9a8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcef9ac: r0 = Null
    //     0xcef9ac: mov             x0, NULL
    // 0xcef9b0: LeaveFrame
    //     0xcef9b0: mov             SP, fp
    //     0xcef9b4: ldp             fp, lr, [SP], #0x10
    // 0xcef9b8: ret
    //     0xcef9b8: ret             
    // 0xcef9bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcef9bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcef9c0: b               #0xcef93c
  }
  set _ textScaler=(/* No info */) {
    // ** addr: 0xcef9c4, size: 0x98
    // 0xcef9c4: EnterFrame
    //     0xcef9c4: stp             fp, lr, [SP, #-0x10]!
    //     0xcef9c8: mov             fp, SP
    // 0xcef9cc: AllocStack(0x28)
    //     0xcef9cc: sub             SP, SP, #0x28
    // 0xcef9d0: SetupParameters(RenderParagraph this /* r1 => r1, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xcef9d0: stur            x1, [fp, #-0x10]
    //     0xcef9d4: stur            x2, [fp, #-0x18]
    // 0xcef9d8: CheckStackOverflow
    //     0xcef9d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcef9dc: cmp             SP, x16
    //     0xcef9e0: b.ls            #0xcefa54
    // 0xcef9e4: LoadField: r3 = r1->field_63
    //     0xcef9e4: ldur            w3, [x1, #0x63]
    // 0xcef9e8: DecompressPointer r3
    //     0xcef9e8: add             x3, x3, HEAP, lsl #32
    // 0xcef9ec: stur            x3, [fp, #-8]
    // 0xcef9f0: LoadField: r0 = r3->field_1f
    //     0xcef9f0: ldur            w0, [x3, #0x1f]
    // 0xcef9f4: DecompressPointer r0
    //     0xcef9f4: add             x0, x0, HEAP, lsl #32
    // 0xcef9f8: r4 = LoadClassIdInstr(r0)
    //     0xcef9f8: ldur            x4, [x0, #-1]
    //     0xcef9fc: ubfx            x4, x4, #0xc, #0x14
    // 0xcefa00: stp             x2, x0, [SP]
    // 0xcefa04: mov             x0, x4
    // 0xcefa08: mov             lr, x0
    // 0xcefa0c: ldr             lr, [x21, lr, lsl #3]
    // 0xcefa10: blr             lr
    // 0xcefa14: tbnz            w0, #4, #0xcefa28
    // 0xcefa18: r0 = Null
    //     0xcefa18: mov             x0, NULL
    // 0xcefa1c: LeaveFrame
    //     0xcefa1c: mov             SP, fp
    //     0xcefa20: ldp             fp, lr, [SP], #0x10
    // 0xcefa24: ret
    //     0xcefa24: ret             
    // 0xcefa28: ldur            x0, [fp, #-0x10]
    // 0xcefa2c: ldur            x1, [fp, #-8]
    // 0xcefa30: ldur            x2, [fp, #-0x18]
    // 0xcefa34: r0 = textScaler=()
    //     0xcefa34: bl              #0xb1d0b0  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textScaler=
    // 0xcefa38: ldur            x1, [fp, #-0x10]
    // 0xcefa3c: StoreField: r1->field_8b = rNULL
    //     0xcefa3c: stur            NULL, [x1, #0x8b]
    // 0xcefa40: r0 = markNeedsLayout()
    //     0xcefa40: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcefa44: r0 = Null
    //     0xcefa44: mov             x0, NULL
    // 0xcefa48: LeaveFrame
    //     0xcefa48: mov             SP, fp
    //     0xcefa4c: ldp             fp, lr, [SP], #0x10
    // 0xcefa50: ret
    //     0xcefa50: ret             
    // 0xcefa54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcefa54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcefa58: b               #0xcef9e4
  }
  set _ overflow=(/* No info */) {
    // ** addr: 0xcefa5c, size: 0xb4
    // 0xcefa5c: EnterFrame
    //     0xcefa5c: stp             fp, lr, [SP, #-0x10]!
    //     0xcefa60: mov             fp, SP
    // 0xcefa64: AllocStack(0x8)
    //     0xcefa64: sub             SP, SP, #8
    // 0xcefa68: SetupParameters(RenderParagraph this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r1 */)
    //     0xcefa68: mov             x3, x1
    //     0xcefa6c: stur            x1, [fp, #-8]
    //     0xcefa70: mov             x1, x2
    // 0xcefa74: CheckStackOverflow
    //     0xcefa74: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcefa78: cmp             SP, x16
    //     0xcefa7c: b.ls            #0xcefb08
    // 0xcefa80: LoadField: r0 = r3->field_7f
    //     0xcefa80: ldur            w0, [x3, #0x7f]
    // 0xcefa84: DecompressPointer r0
    //     0xcefa84: add             x0, x0, HEAP, lsl #32
    // 0xcefa88: cmp             w0, w1
    // 0xcefa8c: b.ne            #0xcefaa0
    // 0xcefa90: r0 = Null
    //     0xcefa90: mov             x0, NULL
    // 0xcefa94: LeaveFrame
    //     0xcefa94: mov             SP, fp
    //     0xcefa98: ldp             fp, lr, [SP], #0x10
    // 0xcefa9c: ret
    //     0xcefa9c: ret             
    // 0xcefaa0: mov             x0, x1
    // 0xcefaa4: StoreField: r3->field_7f = r0
    //     0xcefaa4: stur            w0, [x3, #0x7f]
    //     0xcefaa8: ldurb           w16, [x3, #-1]
    //     0xcefaac: ldurb           w17, [x0, #-1]
    //     0xcefab0: and             x16, x17, x16, lsr #2
    //     0xcefab4: tst             x16, HEAP, lsr #32
    //     0xcefab8: b.eq            #0xcefac0
    //     0xcefabc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcefac0: LoadField: r0 = r3->field_63
    //     0xcefac0: ldur            w0, [x3, #0x63]
    // 0xcefac4: DecompressPointer r0
    //     0xcefac4: add             x0, x0, HEAP, lsl #32
    // 0xcefac8: r16 = Instance_TextOverflow
    //     0xcefac8: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0xcefacc: ldr             x16, [x16, #0xc18]
    // 0xcefad0: cmp             w1, w16
    // 0xcefad4: b.ne            #0xcefae4
    // 0xcefad8: r2 = "…"
    //     0xcefad8: add             x2, PP, #0x90, lsl #12  ; [pp+0x90330] "…"
    //     0xcefadc: ldr             x2, [x2, #0x330]
    // 0xcefae0: b               #0xcefae8
    // 0xcefae4: r2 = Null
    //     0xcefae4: mov             x2, NULL
    // 0xcefae8: mov             x1, x0
    // 0xcefaec: r0 = ellipsis=()
    //     0xcefaec: bl              #0xb1d00c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::ellipsis=
    // 0xcefaf0: ldur            x1, [fp, #-8]
    // 0xcefaf4: r0 = markNeedsLayout()
    //     0xcefaf4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcefaf8: r0 = Null
    //     0xcefaf8: mov             x0, NULL
    // 0xcefafc: LeaveFrame
    //     0xcefafc: mov             SP, fp
    //     0xcefb00: ldp             fp, lr, [SP], #0x10
    // 0xcefb04: ret
    //     0xcefb04: ret             
    // 0xcefb08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcefb08: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcefb0c: b               #0xcefa80
  }
  set _ softWrap=(/* No info */) {
    // ** addr: 0xcefb10, size: 0x54
    // 0xcefb10: EnterFrame
    //     0xcefb10: stp             fp, lr, [SP, #-0x10]!
    //     0xcefb14: mov             fp, SP
    // 0xcefb18: CheckStackOverflow
    //     0xcefb18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcefb1c: cmp             SP, x16
    //     0xcefb20: b.ls            #0xcefb5c
    // 0xcefb24: LoadField: r0 = r1->field_7b
    //     0xcefb24: ldur            w0, [x1, #0x7b]
    // 0xcefb28: DecompressPointer r0
    //     0xcefb28: add             x0, x0, HEAP, lsl #32
    // 0xcefb2c: cmp             w0, w2
    // 0xcefb30: b.ne            #0xcefb44
    // 0xcefb34: r0 = Null
    //     0xcefb34: mov             x0, NULL
    // 0xcefb38: LeaveFrame
    //     0xcefb38: mov             SP, fp
    //     0xcefb3c: ldp             fp, lr, [SP], #0x10
    // 0xcefb40: ret
    //     0xcefb40: ret             
    // 0xcefb44: StoreField: r1->field_7b = r2
    //     0xcefb44: stur            w2, [x1, #0x7b]
    // 0xcefb48: r0 = markNeedsLayout()
    //     0xcefb48: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcefb4c: r0 = Null
    //     0xcefb4c: mov             x0, NULL
    // 0xcefb50: LeaveFrame
    //     0xcefb50: mov             SP, fp
    //     0xcefb54: ldp             fp, lr, [SP], #0x10
    // 0xcefb58: ret
    //     0xcefb58: ret             
    // 0xcefb5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcefb5c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcefb60: b               #0xcefb24
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0xcefb64, size: 0x6c
    // 0xcefb64: EnterFrame
    //     0xcefb64: stp             fp, lr, [SP, #-0x10]!
    //     0xcefb68: mov             fp, SP
    // 0xcefb6c: AllocStack(0x8)
    //     0xcefb6c: sub             SP, SP, #8
    // 0xcefb70: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */)
    //     0xcefb70: mov             x0, x1
    //     0xcefb74: stur            x1, [fp, #-8]
    // 0xcefb78: CheckStackOverflow
    //     0xcefb78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcefb7c: cmp             SP, x16
    //     0xcefb80: b.ls            #0xcefbc8
    // 0xcefb84: LoadField: r1 = r0->field_63
    //     0xcefb84: ldur            w1, [x0, #0x63]
    // 0xcefb88: DecompressPointer r1
    //     0xcefb88: add             x1, x1, HEAP, lsl #32
    // 0xcefb8c: LoadField: r3 = r1->field_1b
    //     0xcefb8c: ldur            w3, [x1, #0x1b]
    // 0xcefb90: DecompressPointer r3
    //     0xcefb90: add             x3, x3, HEAP, lsl #32
    // 0xcefb94: cmp             w3, w2
    // 0xcefb98: b.ne            #0xcefbac
    // 0xcefb9c: r0 = Null
    //     0xcefb9c: mov             x0, NULL
    // 0xcefba0: LeaveFrame
    //     0xcefba0: mov             SP, fp
    //     0xcefba4: ldp             fp, lr, [SP], #0x10
    // 0xcefba8: ret
    //     0xcefba8: ret             
    // 0xcefbac: r0 = textDirection=()
    //     0xcefbac: bl              #0xb1d1c8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textDirection=
    // 0xcefbb0: ldur            x1, [fp, #-8]
    // 0xcefbb4: r0 = markNeedsLayout()
    //     0xcefbb4: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcefbb8: r0 = Null
    //     0xcefbb8: mov             x0, NULL
    // 0xcefbbc: LeaveFrame
    //     0xcefbbc: mov             SP, fp
    //     0xcefbc0: ldp             fp, lr, [SP], #0x10
    // 0xcefbc4: ret
    //     0xcefbc4: ret             
    // 0xcefbc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcefbc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcefbcc: b               #0xcefb84
  }
  set _ textAlign=(/* No info */) {
    // ** addr: 0xcefbd0, size: 0x6c
    // 0xcefbd0: EnterFrame
    //     0xcefbd0: stp             fp, lr, [SP, #-0x10]!
    //     0xcefbd4: mov             fp, SP
    // 0xcefbd8: AllocStack(0x8)
    //     0xcefbd8: sub             SP, SP, #8
    // 0xcefbdc: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */)
    //     0xcefbdc: mov             x0, x1
    //     0xcefbe0: stur            x1, [fp, #-8]
    // 0xcefbe4: CheckStackOverflow
    //     0xcefbe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcefbe8: cmp             SP, x16
    //     0xcefbec: b.ls            #0xcefc34
    // 0xcefbf0: LoadField: r1 = r0->field_63
    //     0xcefbf0: ldur            w1, [x0, #0x63]
    // 0xcefbf4: DecompressPointer r1
    //     0xcefbf4: add             x1, x1, HEAP, lsl #32
    // 0xcefbf8: ArrayLoad: r3 = r1[0]  ; List_4
    //     0xcefbf8: ldur            w3, [x1, #0x17]
    // 0xcefbfc: DecompressPointer r3
    //     0xcefbfc: add             x3, x3, HEAP, lsl #32
    // 0xcefc00: cmp             w3, w2
    // 0xcefc04: b.ne            #0xcefc18
    // 0xcefc08: r0 = Null
    //     0xcefc08: mov             x0, NULL
    // 0xcefc0c: LeaveFrame
    //     0xcefc0c: mov             SP, fp
    //     0xcefc10: ldp             fp, lr, [SP], #0x10
    // 0xcefc14: ret
    //     0xcefc14: ret             
    // 0xcefc18: r0 = textAlign=()
    //     0xcefc18: bl              #0xb1ce54  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textAlign=
    // 0xcefc1c: ldur            x1, [fp, #-8]
    // 0xcefc20: r0 = markNeedsPaint()
    //     0xcefc20: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcefc24: r0 = Null
    //     0xcefc24: mov             x0, NULL
    // 0xcefc28: LeaveFrame
    //     0xcefc28: mov             SP, fp
    //     0xcefc2c: ldp             fp, lr, [SP], #0x10
    // 0xcefc30: ret
    //     0xcefc30: ret             
    // 0xcefc34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcefc34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcefc38: b               #0xcefbf0
  }
  set _ text=(/* No info */) {
    // ** addr: 0xcefc3c, size: 0x118
    // 0xcefc3c: EnterFrame
    //     0xcefc3c: stp             fp, lr, [SP, #-0x10]!
    //     0xcefc40: mov             fp, SP
    // 0xcefc44: AllocStack(0x18)
    //     0xcefc44: sub             SP, SP, #0x18
    // 0xcefc48: SetupParameters(RenderParagraph this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0xcefc48: mov             x4, x1
    //     0xcefc4c: mov             x3, x2
    //     0xcefc50: stur            x1, [fp, #-0x10]
    //     0xcefc54: stur            x2, [fp, #-0x18]
    // 0xcefc58: CheckStackOverflow
    //     0xcefc58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcefc5c: cmp             SP, x16
    //     0xcefc60: b.ls            #0xcefd48
    // 0xcefc64: LoadField: r5 = r4->field_63
    //     0xcefc64: ldur            w5, [x4, #0x63]
    // 0xcefc68: DecompressPointer r5
    //     0xcefc68: add             x5, x5, HEAP, lsl #32
    // 0xcefc6c: stur            x5, [fp, #-8]
    // 0xcefc70: LoadField: r1 = r5->field_f
    //     0xcefc70: ldur            w1, [x5, #0xf]
    // 0xcefc74: DecompressPointer r1
    //     0xcefc74: add             x1, x1, HEAP, lsl #32
    // 0xcefc78: cmp             w1, NULL
    // 0xcefc7c: b.eq            #0xcefd50
    // 0xcefc80: r0 = LoadClassIdInstr(r1)
    //     0xcefc80: ldur            x0, [x1, #-1]
    //     0xcefc84: ubfx            x0, x0, #0xc, #0x14
    // 0xcefc88: mov             x2, x3
    // 0xcefc8c: r0 = GDT[cid_x0 + -0x6b3]()
    //     0xcefc8c: sub             lr, x0, #0x6b3
    //     0xcefc90: ldr             lr, [x21, lr, lsl #3]
    //     0xcefc94: blr             lr
    // 0xcefc98: LoadField: r1 = r0->field_7
    //     0xcefc98: ldur            x1, [x0, #7]
    // 0xcefc9c: cmp             x1, #1
    // 0xcefca0: b.gt            #0xcefce0
    // 0xcefca4: cmp             x1, #0
    // 0xcefca8: b.gt            #0xcefcbc
    // 0xcefcac: r0 = Null
    //     0xcefcac: mov             x0, NULL
    // 0xcefcb0: LeaveFrame
    //     0xcefcb0: mov             SP, fp
    //     0xcefcb4: ldp             fp, lr, [SP], #0x10
    // 0xcefcb8: ret
    //     0xcefcb8: ret             
    // 0xcefcbc: ldur            x0, [fp, #-0x10]
    // 0xcefcc0: ldur            x1, [fp, #-8]
    // 0xcefcc4: ldur            x2, [fp, #-0x18]
    // 0xcefcc8: r0 = text=()
    //     0xcefcc8: bl              #0xb1d2b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0xcefccc: ldur            x0, [fp, #-0x10]
    // 0xcefcd0: StoreField: r0->field_6f = rNULL
    //     0xcefcd0: stur            NULL, [x0, #0x6f]
    // 0xcefcd4: mov             x1, x0
    // 0xcefcd8: r0 = markNeedsSemanticsUpdate()
    //     0xcefcd8: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcefcdc: b               #0xcefd38
    // 0xcefce0: ldur            x0, [fp, #-0x10]
    // 0xcefce4: cmp             x1, #2
    // 0xcefce8: b.gt            #0xcefd18
    // 0xcefcec: ldur            x1, [fp, #-8]
    // 0xcefcf0: ldur            x2, [fp, #-0x18]
    // 0xcefcf4: r0 = text=()
    //     0xcefcf4: bl              #0xb1d2b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0xcefcf8: ldur            x0, [fp, #-0x10]
    // 0xcefcfc: StoreField: r0->field_6b = rNULL
    //     0xcefcfc: stur            NULL, [x0, #0x6b]
    // 0xcefd00: StoreField: r0->field_6f = rNULL
    //     0xcefd00: stur            NULL, [x0, #0x6f]
    // 0xcefd04: mov             x1, x0
    // 0xcefd08: r0 = markNeedsPaint()
    //     0xcefd08: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcefd0c: ldur            x1, [fp, #-0x10]
    // 0xcefd10: r0 = markNeedsSemanticsUpdate()
    //     0xcefd10: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcefd14: b               #0xcefd38
    // 0xcefd18: ldur            x1, [fp, #-8]
    // 0xcefd1c: ldur            x2, [fp, #-0x18]
    // 0xcefd20: r0 = text=()
    //     0xcefd20: bl              #0xb1d2b8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0xcefd24: ldur            x1, [fp, #-0x10]
    // 0xcefd28: StoreField: r1->field_8b = rNULL
    //     0xcefd28: stur            NULL, [x1, #0x8b]
    // 0xcefd2c: StoreField: r1->field_6b = rNULL
    //     0xcefd2c: stur            NULL, [x1, #0x6b]
    // 0xcefd30: StoreField: r1->field_6f = rNULL
    //     0xcefd30: stur            NULL, [x1, #0x6f]
    // 0xcefd34: r0 = markNeedsLayout()
    //     0xcefd34: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcefd38: r0 = Null
    //     0xcefd38: mov             x0, NULL
    // 0xcefd3c: LeaveFrame
    //     0xcefd3c: mov             SP, fp
    //     0xcefd40: ldp             fp, lr, [SP], #0x10
    // 0xcefd44: ret
    //     0xcefd44: ret             
    // 0xcefd48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcefd48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcefd4c: b               #0xcefc64
    // 0xcefd50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcefd50: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10ec1f0, size: 0x1e8
    // 0x10ec1f0: EnterFrame
    //     0x10ec1f0: stp             fp, lr, [SP, #-0x10]!
    //     0x10ec1f4: mov             fp, SP
    // 0x10ec1f8: AllocStack(0x38)
    //     0x10ec1f8: sub             SP, SP, #0x38
    // 0x10ec1fc: SetupParameters(RenderParagraph this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* r3 => r0, fp-0x20 */)
    //     0x10ec1fc: mov             x4, x1
    //     0x10ec200: mov             x0, x3
    //     0x10ec204: stur            x3, [fp, #-0x20]
    //     0x10ec208: mov             x3, x2
    //     0x10ec20c: stur            x1, [fp, #-0x10]
    //     0x10ec210: stur            x2, [fp, #-0x18]
    // 0x10ec214: CheckStackOverflow
    //     0x10ec214: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10ec218: cmp             SP, x16
    //     0x10ec21c: b.ls            #0x10ec3cc
    // 0x10ec220: LoadField: r5 = r4->field_63
    //     0x10ec220: ldur            w5, [x4, #0x63]
    // 0x10ec224: DecompressPointer r5
    //     0x10ec224: add             x5, x5, HEAP, lsl #32
    // 0x10ec228: mov             x1, x5
    // 0x10ec22c: mov             x2, x0
    // 0x10ec230: stur            x5, [fp, #-8]
    // 0x10ec234: r0 = getClosestGlyphForOffset()
    //     0x10ec234: bl              #0x10ea850  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getClosestGlyphForOffset
    // 0x10ec238: stur            x0, [fp, #-0x28]
    // 0x10ec23c: cmp             w0, NULL
    // 0x10ec240: b.eq            #0x10ec320
    // 0x10ec244: LoadField: r1 = r0->field_7
    //     0x10ec244: ldur            w1, [x0, #7]
    // 0x10ec248: DecompressPointer r1
    //     0x10ec248: add             x1, x1, HEAP, lsl #32
    // 0x10ec24c: ldur            x2, [fp, #-0x20]
    // 0x10ec250: r0 = contains()
    //     0x10ec250: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0x10ec254: tbnz            w0, #4, #0x10ec320
    // 0x10ec258: ldur            x1, [fp, #-8]
    // 0x10ec25c: ldur            x0, [fp, #-0x28]
    // 0x10ec260: LoadField: r2 = r1->field_f
    //     0x10ec260: ldur            w2, [x1, #0xf]
    // 0x10ec264: DecompressPointer r2
    //     0x10ec264: add             x2, x2, HEAP, lsl #32
    // 0x10ec268: stur            x2, [fp, #-0x38]
    // 0x10ec26c: cmp             w2, NULL
    // 0x10ec270: b.eq            #0x10ec3d4
    // 0x10ec274: LoadField: r1 = r0->field_b
    //     0x10ec274: ldur            w1, [x0, #0xb]
    // 0x10ec278: DecompressPointer r1
    //     0x10ec278: add             x1, x1, HEAP, lsl #32
    // 0x10ec27c: LoadField: r0 = r1->field_7
    //     0x10ec27c: ldur            x0, [x1, #7]
    // 0x10ec280: stur            x0, [fp, #-0x30]
    // 0x10ec284: r0 = TextPosition()
    //     0x10ec284: bl              #0x85ed74  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x10ec288: mov             x1, x0
    // 0x10ec28c: ldur            x0, [fp, #-0x30]
    // 0x10ec290: stur            x1, [fp, #-8]
    // 0x10ec294: StoreField: r1->field_7 = r0
    //     0x10ec294: stur            x0, [x1, #7]
    // 0x10ec298: r0 = Instance_TextAffinity
    //     0x10ec298: ldr             x0, [PP, #0x4bb0]  ; [pp+0x4bb0] Obj!TextAffinity@12c7361
    // 0x10ec29c: StoreField: r1->field_f = r0
    //     0x10ec29c: stur            w0, [x1, #0xf]
    // 0x10ec2a0: ldur            x0, [fp, #-0x38]
    // 0x10ec2a4: r2 = LoadClassIdInstr(r0)
    //     0x10ec2a4: ldur            x2, [x0, #-1]
    //     0x10ec2a8: ubfx            x2, x2, #0xc, #0x14
    // 0x10ec2ac: r17 = -5790
    //     0x10ec2ac: mov             x17, #-0x169e
    // 0x10ec2b0: add             x16, x2, x17
    // 0x10ec2b4: cmp             x16, #1
    // 0x10ec2b8: b.hi            #0x10ec2c4
    // 0x10ec2bc: r0 = Null
    //     0x10ec2bc: mov             x0, NULL
    // 0x10ec2c0: b               #0x10ec318
    // 0x10ec2c4: r1 = 3
    //     0x10ec2c4: mov             x1, #3
    // 0x10ec2c8: r0 = AllocateContext()
    //     0x10ec2c8: bl              #0x13de838  ; AllocateContextStub
    // 0x10ec2cc: mov             x1, x0
    // 0x10ec2d0: ldur            x0, [fp, #-8]
    // 0x10ec2d4: stur            x1, [fp, #-0x28]
    // 0x10ec2d8: StoreField: r1->field_f = r0
    //     0x10ec2d8: stur            w0, [x1, #0xf]
    // 0x10ec2dc: r0 = Accumulator()
    //     0x10ec2dc: bl              #0xb97ef0  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0x10ec2e0: StoreField: r0->field_7 = rZR
    //     0x10ec2e0: stur            xzr, [x0, #7]
    // 0x10ec2e4: ldur            x3, [fp, #-0x28]
    // 0x10ec2e8: StoreField: r3->field_13 = r0
    //     0x10ec2e8: stur            w0, [x3, #0x13]
    // 0x10ec2ec: mov             x2, x3
    // 0x10ec2f0: r1 = Function '<anonymous closure>':.
    //     0x10ec2f0: add             x1, PP, #0x98, lsl #12  ; [pp+0x989f0] AnonymousClosure: (0x10eac04), of [package:flutter/src/painting/inline_span.dart] InlineSpan
    //     0x10ec2f4: ldr             x1, [x1, #0x9f0]
    // 0x10ec2f8: r0 = AllocateClosure()
    //     0x10ec2f8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10ec2fc: ldur            x1, [fp, #-0x38]
    // 0x10ec300: mov             x2, x0
    // 0x10ec304: r0 = visitChildren()
    //     0x10ec304: bl              #0x125eb34  ; [package:flutter/src/painting/text_span.dart] TextSpan::visitChildren
    // 0x10ec308: ldur            x0, [fp, #-0x28]
    // 0x10ec30c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10ec30c: ldur            w1, [x0, #0x17]
    // 0x10ec310: DecompressPointer r1
    //     0x10ec310: add             x1, x1, HEAP, lsl #32
    // 0x10ec314: mov             x0, x1
    // 0x10ec318: mov             x3, x0
    // 0x10ec31c: b               #0x10ec324
    // 0x10ec320: r3 = Null
    //     0x10ec320: mov             x3, NULL
    // 0x10ec324: mov             x0, x3
    // 0x10ec328: stur            x3, [fp, #-8]
    // 0x10ec32c: r2 = Null
    //     0x10ec32c: mov             x2, NULL
    // 0x10ec330: r1 = Null
    //     0x10ec330: mov             x1, NULL
    // 0x10ec334: cmp             w0, NULL
    // 0x10ec338: b.eq            #0x10ec36c
    // 0x10ec33c: branchIfSmi(r0, 0x10ec36c)
    //     0x10ec33c: tbz             w0, #0, #0x10ec36c
    // 0x10ec340: r3 = LoadClassIdInstr(r0)
    //     0x10ec340: ldur            x3, [x0, #-1]
    //     0x10ec344: ubfx            x3, x3, #0xc, #0x14
    // 0x10ec348: r17 = 4609
    //     0x10ec348: mov             x17, #0x1201
    // 0x10ec34c: cmp             x3, x17
    // 0x10ec350: b.eq            #0x10ec374
    // 0x10ec354: r17 = -4679
    //     0x10ec354: mov             x17, #-0x1247
    // 0x10ec358: add             x3, x3, x17
    // 0x10ec35c: cmp             x3, #0x128
    // 0x10ec360: b.ls            #0x10ec374
    // 0x10ec364: cmp             x3, #0x455
    // 0x10ec368: b.eq            #0x10ec374
    // 0x10ec36c: r0 = false
    //     0x10ec36c: add             x0, NULL, #0x30  ; false
    // 0x10ec370: b               #0x10ec378
    // 0x10ec374: r0 = true
    //     0x10ec374: add             x0, NULL, #0x20  ; true
    // 0x10ec378: tbnz            w0, #4, #0x10ec3b0
    // 0x10ec37c: ldur            x0, [fp, #-8]
    // 0x10ec380: r1 = <HitTestTarget>
    //     0x10ec380: ldr             x1, [PP, #0x2ef0]  ; [pp+0x2ef0] TypeArguments: <HitTestTarget>
    // 0x10ec384: r0 = HitTestEntry()
    //     0x10ec384: bl              #0x836a54  ; AllocateHitTestEntryStub -> HitTestEntry<X0 bound HitTestTarget> (size=0x14)
    // 0x10ec388: mov             x1, x0
    // 0x10ec38c: ldur            x0, [fp, #-8]
    // 0x10ec390: StoreField: r1->field_b = r0
    //     0x10ec390: stur            w0, [x1, #0xb]
    // 0x10ec394: mov             x2, x1
    // 0x10ec398: ldur            x1, [fp, #-0x18]
    // 0x10ec39c: r0 = add()
    //     0x10ec39c: bl              #0x836754  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x10ec3a0: r0 = true
    //     0x10ec3a0: add             x0, NULL, #0x20  ; true
    // 0x10ec3a4: LeaveFrame
    //     0x10ec3a4: mov             SP, fp
    //     0x10ec3a8: ldp             fp, lr, [SP], #0x10
    // 0x10ec3ac: ret
    //     0x10ec3ac: ret             
    // 0x10ec3b0: ldur            x1, [fp, #-0x10]
    // 0x10ec3b4: ldur            x2, [fp, #-0x18]
    // 0x10ec3b8: ldur            x3, [fp, #-0x20]
    // 0x10ec3bc: r0 = hitTestInlineChildren()
    //     0x10ec3bc: bl              #0x10ec3d8  ; [dart:mixin_deduplication] _MixinApplication435&RenderBox&ContainerRenderObjectMixin&RenderInlineChildrenContainerDefaults::hitTestInlineChildren
    // 0x10ec3c0: LeaveFrame
    //     0x10ec3c0: mov             SP, fp
    //     0x10ec3c4: ldp             fp, lr, [SP], #0x10
    // 0x10ec3c8: ret
    //     0x10ec3c8: ret             
    // 0x10ec3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10ec3cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10ec3d0: b               #0x10ec220
    // 0x10ec3d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10ec3d4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f0228, size: 0x24
    // 0x10f0228: EnterFrame
    //     0x10f0228: stp             fp, lr, [SP, #-0x10]!
    //     0x10f022c: mov             fp, SP
    // 0x10f0230: ldr             x2, [fp, #0x10]
    // 0x10f0234: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0234: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2db0] AnonymousClosure: (0xb2baf8), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::computeMaxIntrinsicHeight (0xb2bac8)
    //     0x10f0238: ldr             x1, [x1, #0xdb0]
    // 0x10f023c: r0 = AllocateClosure()
    //     0x10f023c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0240: LeaveFrame
    //     0x10f0240: mov             SP, fp
    //     0x10f0244: ldp             fp, lr, [SP], #0x10
    // 0x10f0248: ret
    //     0x10f0248: ret             
  }
  _ RenderParagraph(/* No info */) {
    // ** addr: 0x11cab20, size: 0x1b8
    // 0x11cab20: EnterFrame
    //     0x11cab20: stp             fp, lr, [SP, #-0x10]!
    //     0x11cab24: mov             fp, SP
    // 0x11cab28: AllocStack(0x78)
    //     0x11cab28: sub             SP, SP, #0x78
    // 0x11cab2c: r4 = false
    //     0x11cab2c: add             x4, NULL, #0x30  ; false
    // 0x11cab30: stur            x1, [fp, #-8]
    // 0x11cab34: mov             x16, x7
    // 0x11cab38: mov             x7, x1
    // 0x11cab3c: mov             x1, x16
    // 0x11cab40: stur            x2, [fp, #-0x10]
    // 0x11cab44: mov             x16, x6
    // 0x11cab48: mov             x6, x2
    // 0x11cab4c: mov             x2, x16
    // 0x11cab50: stur            x3, [fp, #-0x18]
    // 0x11cab54: stur            x5, [fp, #-0x20]
    // 0x11cab58: stur            x2, [fp, #-0x28]
    // 0x11cab5c: CheckStackOverflow
    //     0x11cab5c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cab60: cmp             SP, x16
    //     0x11cab64: b.ls            #0x11cacd0
    // 0x11cab68: StoreField: r7->field_87 = r4
    //     0x11cab68: stur            w4, [x7, #0x87]
    // 0x11cab6c: ldr             x0, [fp, #0x28]
    // 0x11cab70: StoreField: r7->field_7b = r0
    //     0x11cab70: stur            w0, [x7, #0x7b]
    // 0x11cab74: mov             x0, x2
    // 0x11cab78: StoreField: r7->field_7f = r0
    //     0x11cab78: stur            w0, [x7, #0x7f]
    //     0x11cab7c: ldurb           w16, [x7, #-1]
    //     0x11cab80: ldurb           w17, [x0, #-1]
    //     0x11cab84: and             x16, x17, x16, lsr #2
    //     0x11cab88: tst             x16, HEAP, lsr #32
    //     0x11cab8c: b.eq            #0x11cab94
    //     0x11cab90: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x11cab94: mov             x0, x1
    // 0x11cab98: StoreField: r7->field_83 = r0
    //     0x11cab98: stur            w0, [x7, #0x83]
    //     0x11cab9c: ldurb           w16, [x7, #-1]
    //     0x11caba0: ldurb           w17, [x0, #-1]
    //     0x11caba4: and             x16, x17, x16, lsr #2
    //     0x11caba8: tst             x16, HEAP, lsr #32
    //     0x11cabac: b.eq            #0x11cabb4
    //     0x11cabb0: bl              #0x13de054  ; WriteBarrierWrappersStub
    // 0x11cabb4: ldr             x1, [fp, #0x10]
    // 0x11cabb8: r0 = LoadClassIdInstr(r1)
    //     0x11cabb8: ldur            x0, [x1, #-1]
    //     0x11cabbc: ubfx            x0, x0, #0xc, #0x14
    // 0x11cabc0: r16 = Instance__UnspecifiedTextScaler
    //     0x11cabc0: add             x16, PP, #0x90, lsl #12  ; [pp+0x90340] Obj!_UnspecifiedTextScaler@129c661
    //     0x11cabc4: ldr             x16, [x16, #0x340]
    // 0x11cabc8: stp             x16, x1, [SP]
    // 0x11cabcc: mov             lr, x0
    // 0x11cabd0: ldr             lr, [x21, lr, lsl #3]
    // 0x11cabd4: blr             lr
    // 0x11cabd8: tbnz            w0, #4, #0x11cabf0
    // 0x11cabdc: r0 = _LinearTextScaler()
    //     0x11cabdc: bl              #0x8cf878  ; Allocate_LinearTextScalerStub -> _LinearTextScaler (size=0x10)
    // 0x11cabe0: d0 = 1.000000
    //     0x11cabe0: fmov            d0, #1.00000000
    // 0x11cabe4: StoreField: r0->field_7 = d0
    //     0x11cabe4: stur            d0, [x0, #7]
    // 0x11cabe8: mov             x1, x0
    // 0x11cabec: b               #0x11cabf4
    // 0x11cabf0: ldr             x1, [fp, #0x10]
    // 0x11cabf4: ldur            x0, [fp, #-0x28]
    // 0x11cabf8: stur            x1, [fp, #-0x30]
    // 0x11cabfc: r16 = Instance_TextOverflow
    //     0x11cabfc: add             x16, PP, #0x1a, lsl #12  ; [pp+0x1ac18] Obj!TextOverflow@12c47a1
    //     0x11cac00: ldr             x16, [x16, #0xc18]
    // 0x11cac04: cmp             w0, w16
    // 0x11cac08: b.ne            #0x11cac18
    // 0x11cac0c: r2 = "…"
    //     0x11cac0c: add             x2, PP, #0x90, lsl #12  ; [pp+0x90330] "…"
    //     0x11cac10: ldr             x2, [x2, #0x330]
    // 0x11cac14: b               #0x11cac1c
    // 0x11cac18: r2 = Null
    //     0x11cac18: mov             x2, NULL
    // 0x11cac1c: ldur            x0, [fp, #-8]
    // 0x11cac20: stur            x2, [fp, #-0x28]
    // 0x11cac24: r0 = TextPainter()
    //     0x11cac24: bl              #0xb13a1c  ; AllocateTextPainterStub -> TextPainter (size=0x48)
    // 0x11cac28: stur            x0, [fp, #-0x38]
    // 0x11cac2c: ldur            x16, [fp, #-0x10]
    // 0x11cac30: ldr             lr, [fp, #0x20]
    // 0x11cac34: stp             lr, x16, [SP, #0x30]
    // 0x11cac38: ldr             x16, [fp, #0x18]
    // 0x11cac3c: ldur            lr, [fp, #-0x30]
    // 0x11cac40: stp             lr, x16, [SP, #0x20]
    // 0x11cac44: ldur            x16, [fp, #-0x20]
    // 0x11cac48: ldur            lr, [fp, #-0x28]
    // 0x11cac4c: stp             lr, x16, [SP, #0x10]
    // 0x11cac50: ldur            x16, [fp, #-0x18]
    // 0x11cac54: stp             NULL, x16, [SP]
    // 0x11cac58: mov             x1, x0
    // 0x11cac5c: r4 = const [0, 0x9, 0x8, 0x1, ellipsis, 0x6, locale, 0x7, maxLines, 0x5, strutStyle, 0x8, text, 0x1, textAlign, 0x2, textDirection, 0x3, textScaler, 0x4, null]
    //     0x11cac5c: add             x4, PP, #0x90, lsl #12  ; [pp+0x90348] List(21) [0, 0x9, 0x8, 0x1, "ellipsis", 0x6, "locale", 0x7, "maxLines", 0x5, "strutStyle", 0x8, "text", 0x1, "textAlign", 0x2, "textDirection", 0x3, "textScaler", 0x4, Null]
    //     0x11cac60: ldr             x4, [x4, #0x348]
    // 0x11cac64: r0 = TextPainter()
    //     0x11cac64: bl              #0xb135d4  ; [package:flutter/src/painting/text_painter.dart] TextPainter::TextPainter
    // 0x11cac68: ldur            x0, [fp, #-0x38]
    // 0x11cac6c: ldur            x1, [fp, #-8]
    // 0x11cac70: StoreField: r1->field_63 = r0
    //     0x11cac70: stur            w0, [x1, #0x63]
    //     0x11cac74: ldurb           w16, [x1, #-1]
    //     0x11cac78: ldurb           w17, [x0, #-1]
    //     0x11cac7c: and             x16, x17, x16, lsr #2
    //     0x11cac80: tst             x16, HEAP, lsr #32
    //     0x11cac84: b.eq            #0x11cac8c
    //     0x11cac88: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cac8c: r0 = false
    //     0x11cac8c: add             x0, NULL, #0x30  ; false
    // 0x11cac90: StoreField: r1->field_5f = r0
    //     0x11cac90: stur            w0, [x1, #0x5f]
    // 0x11cac94: StoreField: r1->field_4f = rZR
    //     0x11cac94: stur            xzr, [x1, #0x4f]
    // 0x11cac98: r0 = _LayoutCacheStorage()
    //     0x11cac98: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cac9c: ldur            x1, [fp, #-8]
    // 0x11caca0: StoreField: r1->field_47 = r0
    //     0x11caca0: stur            w0, [x1, #0x47]
    //     0x11caca4: ldurb           w16, [x1, #-1]
    //     0x11caca8: ldurb           w17, [x0, #-1]
    //     0x11cacac: and             x16, x17, x16, lsr #2
    //     0x11cacb0: tst             x16, HEAP, lsr #32
    //     0x11cacb4: b.eq            #0x11cacbc
    //     0x11cacb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cacbc: r0 = RenderObject()
    //     0x11cacbc: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cacc0: r0 = Null
    //     0x11cacc0: mov             x0, NULL
    // 0x11cacc4: LeaveFrame
    //     0x11cacc4: mov             SP, fp
    //     0x11cacc8: ldp             fp, lr, [SP], #0x10
    // 0x11caccc: ret
    //     0x11caccc: ret             
    // 0x11cacd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cacd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cacd4: b               #0x11cab68
  }
  _ systemFontsDidChange(/* No info */) {
    // ** addr: 0x1234214, size: 0x50
    // 0x1234214: EnterFrame
    //     0x1234214: stp             fp, lr, [SP, #-0x10]!
    //     0x1234218: mov             fp, SP
    // 0x123421c: AllocStack(0x8)
    //     0x123421c: sub             SP, SP, #8
    // 0x1234220: SetupParameters(RenderParagraph this /* r1 => r0, fp-0x8 */)
    //     0x1234220: mov             x0, x1
    //     0x1234224: stur            x1, [fp, #-8]
    // 0x1234228: CheckStackOverflow
    //     0x1234228: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123422c: cmp             SP, x16
    //     0x1234230: b.ls            #0x123425c
    // 0x1234234: mov             x1, x0
    // 0x1234238: r0 = markNeedsLayout()
    //     0x1234238: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x123423c: ldur            x0, [fp, #-8]
    // 0x1234240: LoadField: r1 = r0->field_63
    //     0x1234240: ldur            w1, [x0, #0x63]
    // 0x1234244: DecompressPointer r1
    //     0x1234244: add             x1, x1, HEAP, lsl #32
    // 0x1234248: r0 = markNeedsLayout()
    //     0x1234248: bl              #0xb1ca34  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x123424c: r0 = Null
    //     0x123424c: mov             x0, NULL
    // 0x1234250: LeaveFrame
    //     0x1234250: mov             SP, fp
    //     0x1234254: ldp             fp, lr, [SP], #0x10
    // 0x1234258: ret
    //     0x1234258: ret             
    // 0x123425c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x123425c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1234260: b               #0x1234234
  }
}
