// lib: , url: package:flutter/src/rendering/platform_view.dart

// class id: 1049037, size: 0x8
class :: {

  static _ _factoryTypesSetEquals(/* No info */) {
    // ** addr: 0xce40d4, size: 0xe4
    // 0xce40d4: EnterFrame
    //     0xce40d4: stp             fp, lr, [SP, #-0x10]!
    //     0xce40d8: mov             fp, SP
    // 0xce40dc: AllocStack(0x28)
    //     0xce40dc: sub             SP, SP, #0x28
    // 0xce40e0: SetupParameters([dynamic _, dynamic _ /* r1 */])
    //     0xce40e0: ldur            w0, [x4, #0xf]
    //     0xce40e4: cbnz            w0, #0xce40f0
    //     0xce40e8: mov             x2, NULL
    //     0xce40ec: b               #0xce4100
    //     0xce40f0: ldur            w0, [x4, #0x17]
    //     0xce40f4: add             x1, fp, w0, sxtw #2
    //     0xce40f8: ldr             x1, [x1, #0x10]
    //     0xce40fc: mov             x2, x1
    //     0xce4100: ldr             x1, [fp, #0x18]
    //     0xce4104: stur            x2, [fp, #-8]
    // 0xce4108: CheckStackOverflow
    //     0xce4108: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce410c: cmp             SP, x16
    //     0xce4110: b.ls            #0xce41b0
    // 0xce4114: r0 = LoadClassIdInstr(r1)
    //     0xce4114: ldur            x0, [x1, #-1]
    //     0xce4118: ubfx            x0, x0, #0xc, #0x14
    // 0xce411c: ldr             x16, [fp, #0x10]
    // 0xce4120: stp             x16, x1, [SP]
    // 0xce4124: mov             lr, x0
    // 0xce4128: ldr             lr, [x21, lr, lsl #3]
    // 0xce412c: blr             lr
    // 0xce4130: tbnz            w0, #4, #0xce4144
    // 0xce4134: r0 = true
    //     0xce4134: add             x0, NULL, #0x20  ; true
    // 0xce4138: LeaveFrame
    //     0xce4138: mov             SP, fp
    //     0xce413c: ldp             fp, lr, [SP], #0x10
    // 0xce4140: ret
    //     0xce4140: ret             
    // 0xce4144: ldr             x0, [fp, #0x10]
    // 0xce4148: cmp             w0, NULL
    // 0xce414c: b.ne            #0xce4160
    // 0xce4150: r0 = false
    //     0xce4150: add             x0, NULL, #0x30  ; false
    // 0xce4154: LeaveFrame
    //     0xce4154: mov             SP, fp
    //     0xce4158: ldp             fp, lr, [SP], #0x10
    // 0xce415c: ret
    //     0xce415c: ret             
    // 0xce4160: ldur            x16, [fp, #-8]
    // 0xce4164: ldr             lr, [fp, #0x18]
    // 0xce4168: stp             lr, x16, [SP]
    // 0xce416c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce416c: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce4170: r0 = _factoriesTypeSet()
    //     0xce4170: bl              #0xce41b8  ; [package:flutter/src/rendering/platform_view.dart] ::_factoriesTypeSet
    // 0xce4174: stur            x0, [fp, #-0x10]
    // 0xce4178: ldur            x16, [fp, #-8]
    // 0xce417c: ldr             lr, [fp, #0x10]
    // 0xce4180: stp             lr, x16, [SP]
    // 0xce4184: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce4184: ldr             x4, [PP, #0xf68]  ; [pp+0xf68] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce4188: r0 = _factoriesTypeSet()
    //     0xce4188: bl              #0xce41b8  ; [package:flutter/src/rendering/platform_view.dart] ::_factoriesTypeSet
    // 0xce418c: r16 = <Type>
    //     0xce418c: ldr             x16, [PP, #0x4f90]  ; [pp+0x4f90] TypeArguments: <Type>
    // 0xce4190: ldur            lr, [fp, #-0x10]
    // 0xce4194: stp             lr, x16, [SP, #8]
    // 0xce4198: str             x0, [SP]
    // 0xce419c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xce419c: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xce41a0: r0 = setEquals()
    //     0xce41a0: bl              #0x86d470  ; [package:flutter/src/foundation/collections.dart] ::setEquals
    // 0xce41a4: LeaveFrame
    //     0xce41a4: mov             SP, fp
    //     0xce41a8: ldp             fp, lr, [SP], #0x10
    // 0xce41ac: ret
    //     0xce41ac: ret             
    // 0xce41b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce41b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce41b4: b               #0xce4114
  }
  static Set<Type> _factoriesTypeSet<Y0>(Set<Factory<Y0>>) {
    // ** addr: 0xce41b8, size: 0xac
    // 0xce41b8: EnterFrame
    //     0xce41b8: stp             fp, lr, [SP, #-0x10]!
    //     0xce41bc: mov             fp, SP
    // 0xce41c0: AllocStack(0x20)
    //     0xce41c0: sub             SP, SP, #0x20
    // 0xce41c4: SetupParameters([dynamic _ /* r0 */])
    //     0xce41c4: ldur            w0, [x4, #0xf]
    //     0xce41c8: cbnz            w0, #0xce41d4
    //     0xce41cc: mov             x3, NULL
    //     0xce41d0: b               #0xce41e4
    //     0xce41d4: ldur            w0, [x4, #0x17]
    //     0xce41d8: add             x1, fp, w0, sxtw #2
    //     0xce41dc: ldr             x1, [x1, #0x10]
    //     0xce41e0: mov             x3, x1
    //     0xce41e4: ldr             x0, [fp, #0x10]
    //     0xce41e8: stur            x3, [fp, #-8]
    // 0xce41ec: CheckStackOverflow
    //     0xce41ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce41f0: cmp             SP, x16
    //     0xce41f4: b.ls            #0xce425c
    // 0xce41f8: r1 = Function '<anonymous closure>': static.
    //     0xce41f8: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa17e0] AnonymousClosure: static (0xce4264), in [package:flutter/src/rendering/platform_view.dart] ::_factoriesTypeSet (0xce41b8)
    //     0xce41fc: ldr             x1, [x1, #0x7e0]
    // 0xce4200: r2 = Null
    //     0xce4200: mov             x2, NULL
    // 0xce4204: r0 = AllocateClosure()
    //     0xce4204: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xce4208: mov             x1, x0
    // 0xce420c: ldur            x0, [fp, #-8]
    // 0xce4210: StoreField: r1->field_b = r0
    //     0xce4210: stur            w0, [x1, #0xb]
    // 0xce4214: ldr             x0, [fp, #0x10]
    // 0xce4218: r2 = LoadClassIdInstr(r0)
    //     0xce4218: ldur            x2, [x0, #-1]
    //     0xce421c: ubfx            x2, x2, #0xc, #0x14
    // 0xce4220: r16 = <Type>
    //     0xce4220: ldr             x16, [PP, #0x4f90]  ; [pp+0x4f90] TypeArguments: <Type>
    // 0xce4224: stp             x0, x16, [SP, #8]
    // 0xce4228: str             x1, [SP]
    // 0xce422c: mov             x0, x2
    // 0xce4230: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xce4230: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xce4234: r0 = GDT[cid_x0 + 0x12caa]()
    //     0xce4234: mov             x17, #0x2caa
    //     0xce4238: movk            x17, #1, lsl #16
    //     0xce423c: add             lr, x0, x17
    //     0xce4240: ldr             lr, [x21, lr, lsl #3]
    //     0xce4244: blr             lr
    // 0xce4248: mov             x1, x0
    // 0xce424c: r0 = toSet()
    //     0xce424c: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0xce4250: LeaveFrame
    //     0xce4250: mov             SP, fp
    //     0xce4254: ldp             fp, lr, [SP], #0x10
    // 0xce4258: ret
    //     0xce4258: ret             
    // 0xce425c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce425c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce4260: b               #0xce41f8
  }
  [closure] static Type <anonymous closure>(dynamic, Factory<Y0>) {
    // ** addr: 0xce4264, size: 0x38
    // 0xce4264: EnterFrame
    //     0xce4264: stp             fp, lr, [SP, #-0x10]!
    //     0xce4268: mov             fp, SP
    // 0xce426c: ldr             x0, [fp, #0x10]
    // 0xce4270: LoadField: r2 = r0->field_7
    //     0xce4270: ldur            w2, [x0, #7]
    // 0xce4274: DecompressPointer r2
    //     0xce4274: add             x2, x2, HEAP, lsl #32
    // 0xce4278: r1 = Null
    //     0xce4278: mov             x1, NULL
    // 0xce427c: r3 = X0
    //     0xce427c: ldr             x3, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xce4280: r30 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0xce4280: add             lr, PP, #0x12, lsl #12  ; [pp+0x12e80] Stub: InstantiateTypeNonNullableClassTypeParameter (0x7c1258)
    //     0xce4284: ldr             lr, [lr, #0xe80]
    // 0xce4288: LoadField: r30 = r30->field_7
    //     0xce4288: ldur            lr, [lr, #7]
    // 0xce428c: blr             lr
    // 0xce4290: LeaveFrame
    //     0xce4290: mov             SP, fp
    //     0xce4294: ldp             fp, lr, [SP], #0x10
    // 0xce4298: ret
    //     0xce4298: ret             
  }
}

// class id: 4432, size: 0x38, field offset: 0x24
class _PlatformViewGestureRecognizer extends OneSequenceGestureRecognizer {

  late (dynamic, PointerEvent) => Future<void> _handlePointerEvent; // offset: 0x24
  late Set<OneSequenceGestureRecognizer> _gestureRecognizers; // offset: 0x34

  _ stopTrackingPointer(/* No info */) {
    // ** addr: 0xb8c04c, size: 0x60
    // 0xb8c04c: EnterFrame
    //     0xb8c04c: stp             fp, lr, [SP, #-0x10]!
    //     0xb8c050: mov             fp, SP
    // 0xb8c054: AllocStack(0x10)
    //     0xb8c054: sub             SP, SP, #0x10
    // 0xb8c058: SetupParameters(_PlatformViewGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb8c058: mov             x3, x1
    //     0xb8c05c: mov             x0, x2
    //     0xb8c060: stur            x1, [fp, #-8]
    //     0xb8c064: stur            x2, [fp, #-0x10]
    // 0xb8c068: CheckStackOverflow
    //     0xb8c068: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8c06c: cmp             SP, x16
    //     0xb8c070: b.ls            #0xb8c0a4
    // 0xb8c074: mov             x1, x3
    // 0xb8c078: mov             x2, x0
    // 0xb8c07c: r0 = stopTrackingPointer()
    //     0xb8c07c: bl              #0xb8be24  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer
    // 0xb8c080: ldur            x0, [fp, #-8]
    // 0xb8c084: LoadField: r1 = r0->field_2b
    //     0xb8c084: ldur            w1, [x0, #0x2b]
    // 0xb8c088: DecompressPointer r1
    //     0xb8c088: add             x1, x1, HEAP, lsl #32
    // 0xb8c08c: ldur            x2, [fp, #-0x10]
    // 0xb8c090: r0 = remove()
    //     0xb8c090: bl              #0x115bfd0  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0xb8c094: r0 = Null
    //     0xb8c094: mov             x0, NULL
    // 0xb8c098: LeaveFrame
    //     0xb8c098: mov             SP, fp
    //     0xb8c09c: ldp             fp, lr, [SP], #0x10
    // 0xb8c0a0: ret
    //     0xb8c0a0: ret             
    // 0xb8c0a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8c0a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8c0a8: b               #0xb8c074
  }
  dynamic handleEvent(dynamic) {
    // ** addr: 0xba30b8, size: 0x24
    // 0xba30b8: EnterFrame
    //     0xba30b8: stp             fp, lr, [SP, #-0x10]!
    //     0xba30bc: mov             fp, SP
    // 0xba30c0: ldr             x2, [fp, #0x10]
    // 0xba30c4: r1 = Function 'handleEvent':.
    //     0xba30c4: add             x1, PP, #0xac, lsl #12  ; [pp+0xacba0] AnonymousClosure: (0xba30dc), in [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::handleEvent (0xba3118)
    //     0xba30c8: ldr             x1, [x1, #0xba0]
    // 0xba30cc: r0 = AllocateClosure()
    //     0xba30cc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xba30d0: LeaveFrame
    //     0xba30d0: mov             SP, fp
    //     0xba30d4: ldp             fp, lr, [SP], #0x10
    // 0xba30d8: ret
    //     0xba30d8: ret             
  }
  [closure] void handleEvent(dynamic, PointerEvent) {
    // ** addr: 0xba30dc, size: 0x3c
    // 0xba30dc: EnterFrame
    //     0xba30dc: stp             fp, lr, [SP, #-0x10]!
    //     0xba30e0: mov             fp, SP
    // 0xba30e4: ldr             x0, [fp, #0x18]
    // 0xba30e8: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xba30e8: ldur            w1, [x0, #0x17]
    // 0xba30ec: DecompressPointer r1
    //     0xba30ec: add             x1, x1, HEAP, lsl #32
    // 0xba30f0: CheckStackOverflow
    //     0xba30f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba30f4: cmp             SP, x16
    //     0xba30f8: b.ls            #0xba3110
    // 0xba30fc: ldr             x2, [fp, #0x10]
    // 0xba3100: r0 = handleEvent()
    //     0xba3100: bl              #0xba3118  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::handleEvent
    // 0xba3104: LeaveFrame
    //     0xba3104: mov             SP, fp
    //     0xba3108: ldp             fp, lr, [SP], #0x10
    // 0xba310c: ret
    //     0xba310c: ret             
    // 0xba3110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba3110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba3114: b               #0xba30fc
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0xba3118, size: 0xdc
    // 0xba3118: EnterFrame
    //     0xba3118: stp             fp, lr, [SP, #-0x10]!
    //     0xba311c: mov             fp, SP
    // 0xba3120: AllocStack(0x18)
    //     0xba3120: sub             SP, SP, #0x18
    // 0xba3124: SetupParameters(_PlatformViewGestureRecognizer this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r2, fp-0x18 */)
    //     0xba3124: mov             x3, x1
    //     0xba3128: stur            x1, [fp, #-0x10]
    //     0xba312c: stur            x2, [fp, #-0x18]
    // 0xba3130: CheckStackOverflow
    //     0xba3130: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba3134: cmp             SP, x16
    //     0xba3138: b.ls            #0xba31e0
    // 0xba313c: LoadField: r4 = r3->field_2b
    //     0xba313c: ldur            w4, [x3, #0x2b]
    // 0xba3140: DecompressPointer r4
    //     0xba3140: add             x4, x4, HEAP, lsl #32
    // 0xba3144: stur            x4, [fp, #-8]
    // 0xba3148: r0 = LoadClassIdInstr(r2)
    //     0xba3148: ldur            x0, [x2, #-1]
    //     0xba314c: ubfx            x0, x0, #0xc, #0x14
    // 0xba3150: mov             x1, x2
    // 0xba3154: r0 = GDT[cid_x0 + -0x1]()
    //     0xba3154: sub             lr, x0, #1
    //     0xba3158: ldr             lr, [x21, lr, lsl #3]
    //     0xba315c: blr             lr
    // 0xba3160: mov             x2, x0
    // 0xba3164: r0 = BoxInt64Instr(r2)
    //     0xba3164: sbfiz           x0, x2, #1, #0x1f
    //     0xba3168: cmp             x2, x0, asr #1
    //     0xba316c: b.eq            #0xba3178
    //     0xba3170: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba3174: stur            x2, [x0, #7]
    // 0xba3178: ldur            x1, [fp, #-8]
    // 0xba317c: mov             x2, x0
    // 0xba3180: r0 = contains()
    //     0xba3180: bl              #0xbafbf4  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xba3184: tbz             w0, #4, #0xba3198
    // 0xba3188: ldur            x1, [fp, #-0x10]
    // 0xba318c: ldur            x2, [fp, #-0x18]
    // 0xba3190: r0 = _cacheEvent()
    //     0xba3190: bl              #0xba5034  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::_cacheEvent
    // 0xba3194: b               #0xba31c4
    // 0xba3198: ldur            x0, [fp, #-0x10]
    // 0xba319c: LoadField: r1 = r0->field_23
    //     0xba319c: ldur            w1, [x0, #0x23]
    // 0xba31a0: DecompressPointer r1
    //     0xba31a0: add             x1, x1, HEAP, lsl #32
    // 0xba31a4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba31a8: cmp             w1, w16
    // 0xba31ac: b.eq            #0xba31e8
    // 0xba31b0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xba31b0: ldur            w2, [x1, #0x17]
    // 0xba31b4: DecompressPointer r2
    //     0xba31b4: add             x2, x2, HEAP, lsl #32
    // 0xba31b8: mov             x1, x2
    // 0xba31bc: ldur            x2, [fp, #-0x18]
    // 0xba31c0: r0 = dispatchPointerEvent()
    //     0xba31c0: bl              #0xba3230  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::dispatchPointerEvent
    // 0xba31c4: ldur            x1, [fp, #-0x10]
    // 0xba31c8: ldur            x2, [fp, #-0x18]
    // 0xba31cc: r0 = stopTrackingIfPointerNoLongerDown()
    //     0xba31cc: bl              #0xb9c294  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingIfPointerNoLongerDown
    // 0xba31d0: r0 = Null
    //     0xba31d0: mov             x0, NULL
    // 0xba31d4: LeaveFrame
    //     0xba31d4: mov             SP, fp
    //     0xba31d8: ldp             fp, lr, [SP], #0x10
    // 0xba31dc: ret
    //     0xba31dc: ret             
    // 0xba31e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba31e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba31e4: b               #0xba313c
    // 0xba31e8: r9 = _handlePointerEvent
    //     0xba31e8: add             x9, PP, #0xac, lsl #12  ; [pp+0xacba8] Field <_PlatformViewGestureRecognizer@300508051._handlePointerEvent@300508051>: late (offset: 0x24)
    //     0xba31ec: ldr             x9, [x9, #0xba8]
    // 0xba31f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba31f0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _cacheEvent(/* No info */) {
    // ** addr: 0xba5034, size: 0x170
    // 0xba5034: EnterFrame
    //     0xba5034: stp             fp, lr, [SP, #-0x10]!
    //     0xba5038: mov             fp, SP
    // 0xba503c: AllocStack(0x28)
    //     0xba503c: sub             SP, SP, #0x28
    // 0xba5040: SetupParameters(dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xba5040: stur            x2, [fp, #-0x10]
    // 0xba5044: CheckStackOverflow
    //     0xba5044: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba5048: cmp             SP, x16
    //     0xba504c: b.ls            #0xba5198
    // 0xba5050: LoadField: r3 = r1->field_27
    //     0xba5050: ldur            w3, [x1, #0x27]
    // 0xba5054: DecompressPointer r3
    //     0xba5054: add             x3, x3, HEAP, lsl #32
    // 0xba5058: stur            x3, [fp, #-8]
    // 0xba505c: r0 = LoadClassIdInstr(r2)
    //     0xba505c: ldur            x0, [x2, #-1]
    //     0xba5060: ubfx            x0, x0, #0xc, #0x14
    // 0xba5064: mov             x1, x2
    // 0xba5068: r0 = GDT[cid_x0 + -0x1]()
    //     0xba5068: sub             lr, x0, #1
    //     0xba506c: ldr             lr, [x21, lr, lsl #3]
    //     0xba5070: blr             lr
    // 0xba5074: mov             x2, x0
    // 0xba5078: r0 = BoxInt64Instr(r2)
    //     0xba5078: sbfiz           x0, x2, #1, #0x1f
    //     0xba507c: cmp             x2, x0, asr #1
    //     0xba5080: b.eq            #0xba508c
    //     0xba5084: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba5088: stur            x2, [x0, #7]
    // 0xba508c: ldur            x1, [fp, #-8]
    // 0xba5090: mov             x2, x0
    // 0xba5094: r0 = containsKey()
    //     0xba5094: bl              #0x12d5a5c  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xba5098: tbz             w0, #4, #0xba50f0
    // 0xba509c: ldur            x2, [fp, #-0x10]
    // 0xba50a0: r0 = LoadClassIdInstr(r2)
    //     0xba50a0: ldur            x0, [x2, #-1]
    //     0xba50a4: ubfx            x0, x0, #0xc, #0x14
    // 0xba50a8: mov             x1, x2
    // 0xba50ac: r0 = GDT[cid_x0 + -0x1]()
    //     0xba50ac: sub             lr, x0, #1
    //     0xba50b0: ldr             lr, [x21, lr, lsl #3]
    //     0xba50b4: blr             lr
    // 0xba50b8: r1 = <PointerEvent>
    //     0xba50b8: ldr             x1, [PP, #0x1848]  ; [pp+0x1848] TypeArguments: <PointerEvent>
    // 0xba50bc: r2 = 0
    //     0xba50bc: mov             x2, #0
    // 0xba50c0: stur            x0, [fp, #-0x18]
    // 0xba50c4: r0 = _GrowableList()
    //     0xba50c4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xba50c8: mov             x3, x0
    // 0xba50cc: ldur            x2, [fp, #-0x18]
    // 0xba50d0: r0 = BoxInt64Instr(r2)
    //     0xba50d0: sbfiz           x0, x2, #1, #0x1f
    //     0xba50d4: cmp             x2, x0, asr #1
    //     0xba50d8: b.eq            #0xba50e4
    //     0xba50dc: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba50e0: stur            x2, [x0, #7]
    // 0xba50e4: ldur            x1, [fp, #-8]
    // 0xba50e8: mov             x2, x0
    // 0xba50ec: r0 = []=()
    //     0xba50ec: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xba50f0: ldur            x2, [fp, #-0x10]
    // 0xba50f4: ldur            x3, [fp, #-8]
    // 0xba50f8: r0 = LoadClassIdInstr(r2)
    //     0xba50f8: ldur            x0, [x2, #-1]
    //     0xba50fc: ubfx            x0, x0, #0xc, #0x14
    // 0xba5100: mov             x1, x2
    // 0xba5104: r0 = GDT[cid_x0 + -0x1]()
    //     0xba5104: sub             lr, x0, #1
    //     0xba5108: ldr             lr, [x21, lr, lsl #3]
    //     0xba510c: blr             lr
    // 0xba5110: mov             x2, x0
    // 0xba5114: r0 = BoxInt64Instr(r2)
    //     0xba5114: sbfiz           x0, x2, #1, #0x1f
    //     0xba5118: cmp             x2, x0, asr #1
    //     0xba511c: b.eq            #0xba5128
    //     0xba5120: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xba5124: stur            x2, [x0, #7]
    // 0xba5128: ldur            x1, [fp, #-8]
    // 0xba512c: mov             x2, x0
    // 0xba5130: r0 = _getValueOrData()
    //     0xba5130: bl              #0x13d8564  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xba5134: mov             x1, x0
    // 0xba5138: ldur            x0, [fp, #-8]
    // 0xba513c: LoadField: r2 = r0->field_f
    //     0xba513c: ldur            w2, [x0, #0xf]
    // 0xba5140: DecompressPointer r2
    //     0xba5140: add             x2, x2, HEAP, lsl #32
    // 0xba5144: cmp             w2, w1
    // 0xba5148: b.ne            #0xba5154
    // 0xba514c: r0 = Null
    //     0xba514c: mov             x0, NULL
    // 0xba5150: b               #0xba5158
    // 0xba5154: mov             x0, x1
    // 0xba5158: cmp             w0, NULL
    // 0xba515c: b.eq            #0xba51a0
    // 0xba5160: r1 = LoadClassIdInstr(r0)
    //     0xba5160: ldur            x1, [x0, #-1]
    //     0xba5164: ubfx            x1, x1, #0xc, #0x14
    // 0xba5168: ldur            x16, [fp, #-0x10]
    // 0xba516c: stp             x16, x0, [SP]
    // 0xba5170: mov             x0, x1
    // 0xba5174: r0 = GDT[cid_x0 + 0x175da]()
    //     0xba5174: mov             x17, #0x75da
    //     0xba5178: movk            x17, #1, lsl #16
    //     0xba517c: add             lr, x0, x17
    //     0xba5180: ldr             lr, [x21, lr, lsl #3]
    //     0xba5184: blr             lr
    // 0xba5188: r0 = Null
    //     0xba5188: mov             x0, NULL
    // 0xba518c: LeaveFrame
    //     0xba518c: mov             SP, fp
    //     0xba5190: ldp             fp, lr, [SP], #0x10
    // 0xba5194: ret
    //     0xba5194: ret             
    // 0xba5198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba5198: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba519c: b               #0xba5050
    // 0xba51a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xba51a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addAllowedPointer(/* No info */) {
    // ** addr: 0xba8710, size: 0x104
    // 0xba8710: EnterFrame
    //     0xba8710: stp             fp, lr, [SP, #-0x10]!
    //     0xba8714: mov             fp, SP
    // 0xba8718: AllocStack(0x20)
    //     0xba8718: sub             SP, SP, #0x20
    // 0xba871c: SetupParameters(_PlatformViewGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xba871c: mov             x3, x1
    //     0xba8720: mov             x0, x2
    //     0xba8724: stur            x1, [fp, #-8]
    //     0xba8728: stur            x2, [fp, #-0x10]
    // 0xba872c: CheckStackOverflow
    //     0xba872c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8730: cmp             SP, x16
    //     0xba8734: b.ls            #0xba87f8
    // 0xba8738: mov             x1, x3
    // 0xba873c: mov             x2, x0
    // 0xba8740: r0 = addAllowedPointer()
    //     0xba8740: bl              #0xba6ac8  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::addAllowedPointer
    // 0xba8744: ldur            x0, [fp, #-8]
    // 0xba8748: LoadField: r1 = r0->field_33
    //     0xba8748: ldur            w1, [x0, #0x33]
    // 0xba874c: DecompressPointer r1
    //     0xba874c: add             x1, x1, HEAP, lsl #32
    // 0xba8750: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xba8754: cmp             w1, w16
    // 0xba8758: b.eq            #0xba8800
    // 0xba875c: r0 = iterator()
    //     0xba875c: bl              #0xbb7c60  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0xba8760: stur            x0, [fp, #-0x18]
    // 0xba8764: LoadField: r2 = r0->field_7
    //     0xba8764: ldur            w2, [x0, #7]
    // 0xba8768: DecompressPointer r2
    //     0xba8768: add             x2, x2, HEAP, lsl #32
    // 0xba876c: stur            x2, [fp, #-8]
    // 0xba8770: CheckStackOverflow
    //     0xba8770: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xba8774: cmp             SP, x16
    //     0xba8778: b.ls            #0xba880c
    // 0xba877c: mov             x1, x0
    // 0xba8780: r0 = moveNext()
    //     0xba8780: bl              #0x8024c0  ; [dart:_compact_hash] _CompactIterator::moveNext
    // 0xba8784: tbnz            w0, #4, #0xba87e8
    // 0xba8788: ldur            x3, [fp, #-0x18]
    // 0xba878c: LoadField: r4 = r3->field_33
    //     0xba878c: ldur            w4, [x3, #0x33]
    // 0xba8790: DecompressPointer r4
    //     0xba8790: add             x4, x4, HEAP, lsl #32
    // 0xba8794: stur            x4, [fp, #-0x20]
    // 0xba8798: cmp             w4, NULL
    // 0xba879c: b.ne            #0xba87d0
    // 0xba87a0: mov             x0, x4
    // 0xba87a4: ldur            x2, [fp, #-8]
    // 0xba87a8: r1 = Null
    //     0xba87a8: mov             x1, NULL
    // 0xba87ac: cmp             w2, NULL
    // 0xba87b0: b.eq            #0xba87d0
    // 0xba87b4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xba87b4: ldur            w4, [x2, #0x17]
    // 0xba87b8: DecompressPointer r4
    //     0xba87b8: add             x4, x4, HEAP, lsl #32
    // 0xba87bc: r8 = X0
    //     0xba87bc: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0xba87c0: LoadField: r9 = r4->field_7
    //     0xba87c0: ldur            x9, [x4, #7]
    // 0xba87c4: r3 = Null
    //     0xba87c4: add             x3, PP, #0xac, lsl #12  ; [pp+0xacbb0] Null
    //     0xba87c8: ldr             x3, [x3, #0xbb0]
    // 0xba87cc: blr             x9
    // 0xba87d0: ldur            x1, [fp, #-0x20]
    // 0xba87d4: ldur            x2, [fp, #-0x10]
    // 0xba87d8: r0 = addPointer()
    //     0xba87d8: bl              #0xd04e70  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0xba87dc: ldur            x0, [fp, #-0x18]
    // 0xba87e0: ldur            x2, [fp, #-8]
    // 0xba87e4: b               #0xba8770
    // 0xba87e8: r0 = Null
    //     0xba87e8: mov             x0, NULL
    // 0xba87ec: LeaveFrame
    //     0xba87ec: mov             SP, fp
    //     0xba87f0: ldp             fp, lr, [SP], #0x10
    // 0xba87f4: ret
    //     0xba87f4: ret             
    // 0xba87f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba87f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba87fc: b               #0xba8738
    // 0xba8800: r9 = _gestureRecognizers
    //     0xba8800: add             x9, PP, #0xac, lsl #12  ; [pp+0xacbc0] Field <_PlatformViewGestureRecognizer@300508051._gestureRecognizers@300508051>: late (offset: 0x34)
    //     0xba8804: ldr             x9, [x9, #0xbc0]
    // 0xba8808: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xba8808: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xba880c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba880c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba8810: b               #0xba877c
  }
  _ reset(/* No info */) {
    // ** addr: 0xc07a30, size: 0xb4
    // 0xc07a30: EnterFrame
    //     0xc07a30: stp             fp, lr, [SP, #-0x10]!
    //     0xc07a34: mov             fp, SP
    // 0xc07a38: AllocStack(0x18)
    //     0xc07a38: sub             SP, SP, #0x18
    // 0xc07a3c: SetupParameters(_PlatformViewGestureRecognizer this /* r1 => r0, fp-0x10 */)
    //     0xc07a3c: mov             x0, x1
    //     0xc07a40: stur            x1, [fp, #-0x10]
    // 0xc07a44: CheckStackOverflow
    //     0xc07a44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc07a48: cmp             SP, x16
    //     0xc07a4c: b.ls            #0xc07adc
    // 0xc07a50: LoadField: r3 = r0->field_2b
    //     0xc07a50: ldur            w3, [x0, #0x2b]
    // 0xc07a54: DecompressPointer r3
    //     0xc07a54: add             x3, x3, HEAP, lsl #32
    // 0xc07a58: mov             x2, x0
    // 0xc07a5c: stur            x3, [fp, #-8]
    // 0xc07a60: r1 = Function 'stopTrackingPointer':.
    //     0xc07a60: add             x1, PP, #0xae, lsl #12  ; [pp+0xae588] AnonymousClosure: (0xb8bf30), in [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::stopTrackingPointer (0xb8be24)
    //     0xc07a64: ldr             x1, [x1, #0x588]
    // 0xc07a68: r0 = AllocateClosure()
    //     0xc07a68: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc07a6c: ldur            x1, [fp, #-8]
    // 0xc07a70: mov             x2, x0
    // 0xc07a74: stur            x0, [fp, #-0x18]
    // 0xc07a78: r0 = forEach()
    //     0xc07a78: bl              #0xb9bccc  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::forEach
    // 0xc07a7c: ldur            x1, [fp, #-8]
    // 0xc07a80: r0 = clear()
    //     0xc07a80: bl              #0x83d960  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::clear
    // 0xc07a84: ldur            x0, [fp, #-0x10]
    // 0xc07a88: LoadField: r2 = r0->field_27
    //     0xc07a88: ldur            w2, [x0, #0x27]
    // 0xc07a8c: DecompressPointer r2
    //     0xc07a8c: add             x2, x2, HEAP, lsl #32
    // 0xc07a90: stur            x2, [fp, #-8]
    // 0xc07a94: r1 = <int, List<PointerEvent>>
    //     0xc07a94: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa17b8] TypeArguments: <int, List<PointerEvent>>
    //     0xc07a98: ldr             x1, [x1, #0x7b8]
    // 0xc07a9c: r0 = _CompactKeysIterable()
    //     0xc07a9c: bl              #0x8353d0  ; Allocate_CompactKeysIterableStub -> _CompactKeysIterable<X0> (size=0x10)
    // 0xc07aa0: mov             x1, x0
    // 0xc07aa4: ldur            x0, [fp, #-8]
    // 0xc07aa8: StoreField: r1->field_b = r0
    //     0xc07aa8: stur            w0, [x1, #0xb]
    // 0xc07aac: ldur            x2, [fp, #-0x18]
    // 0xc07ab0: r0 = forEach()
    //     0xc07ab0: bl              #0xaffee4  ; [dart:core] Iterable::forEach
    // 0xc07ab4: ldur            x1, [fp, #-8]
    // 0xc07ab8: r0 = clear()
    //     0xc07ab8: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0xc07abc: ldur            x1, [fp, #-0x10]
    // 0xc07ac0: r2 = Instance_GestureDisposition
    //     0xc07ac0: add             x2, PP, #0x26, lsl #12  ; [pp+0x26610] Obj!GestureDisposition@12c5de1
    //     0xc07ac4: ldr             x2, [x2, #0x610]
    // 0xc07ac8: r0 = resolve()
    //     0xc07ac8: bl              #0xd01818  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::resolve
    // 0xc07acc: r0 = Null
    //     0xc07acc: mov             x0, NULL
    // 0xc07ad0: LeaveFrame
    //     0xc07ad0: mov             SP, fp
    //     0xc07ad4: ldp             fp, lr, [SP], #0x10
    // 0xc07ad8: ret
    //     0xc07ad8: ret             
    // 0xc07adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07adc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc07ae0: b               #0xc07a50
  }
  _ _PlatformViewGestureRecognizer(/* No info */) {
    // ** addr: 0xce3c9c, size: 0x1fc
    // 0xce3c9c: EnterFrame
    //     0xce3c9c: stp             fp, lr, [SP, #-0x10]!
    //     0xce3ca0: mov             fp, SP
    // 0xce3ca4: AllocStack(0x40)
    //     0xce3ca4: sub             SP, SP, #0x40
    // 0xce3ca8: SetupParameters(_PlatformViewGestureRecognizer this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xce3ca8: stur            x1, [fp, #-8]
    //     0xce3cac: mov             x16, x2
    //     0xce3cb0: mov             x2, x1
    //     0xce3cb4: mov             x1, x16
    //     0xce3cb8: mov             x0, x3
    //     0xce3cbc: stur            x1, [fp, #-0x10]
    //     0xce3cc0: stur            x3, [fp, #-0x18]
    // 0xce3cc4: CheckStackOverflow
    //     0xce3cc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3cc8: cmp             SP, x16
    //     0xce3ccc: b.ls            #0xce3e90
    // 0xce3cd0: r1 = 1
    //     0xce3cd0: mov             x1, #1
    // 0xce3cd4: r0 = AllocateContext()
    //     0xce3cd4: bl              #0x13de838  ; AllocateContextStub
    // 0xce3cd8: ldur            x1, [fp, #-8]
    // 0xce3cdc: stur            x0, [fp, #-0x20]
    // 0xce3ce0: StoreField: r0->field_f = r1
    //     0xce3ce0: stur            w1, [x0, #0xf]
    // 0xce3ce4: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0xce3ce8: StoreField: r1->field_23 = r2
    //     0xce3ce8: stur            w2, [x1, #0x23]
    // 0xce3cec: StoreField: r1->field_33 = r2
    //     0xce3cec: stur            w2, [x1, #0x33]
    // 0xce3cf0: r16 = <int, List<PointerEvent>>
    //     0xce3cf0: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa17b8] TypeArguments: <int, List<PointerEvent>>
    //     0xce3cf4: ldr             x16, [x16, #0x7b8]
    // 0xce3cf8: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xce3cfc: stp             lr, x16, [SP]
    // 0xce3d00: r0 = Map._fromLiteral()
    //     0xce3d00: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xce3d04: ldur            x2, [fp, #-8]
    // 0xce3d08: StoreField: r2->field_27 = r0
    //     0xce3d08: stur            w0, [x2, #0x27]
    //     0xce3d0c: ldurb           w16, [x2, #-1]
    //     0xce3d10: ldurb           w17, [x0, #-1]
    //     0xce3d14: and             x16, x17, x16, lsr #2
    //     0xce3d18: tst             x16, HEAP, lsr #32
    //     0xce3d1c: b.eq            #0xce3d24
    //     0xce3d20: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xce3d24: r1 = <int>
    //     0xce3d24: ldr             x1, [PP, #0x50]  ; [pp+0x50] TypeArguments: <int>
    // 0xce3d28: r0 = _Set()
    //     0xce3d28: bl              #0x81d998  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xce3d2c: mov             x1, x0
    // 0xce3d30: r0 = _Uint32List
    //     0xce3d30: ldr             x0, [PP, #0x17d8]  ; [pp+0x17d8] _Uint32List(1) [0x0]
    // 0xce3d34: StoreField: r1->field_1b = r0
    //     0xce3d34: stur            w0, [x1, #0x1b]
    // 0xce3d38: StoreField: r1->field_b = rZR
    //     0xce3d38: stur            wzr, [x1, #0xb]
    // 0xce3d3c: r0 = const []
    //     0xce3d3c: ldr             x0, [PP, #0x17e0]  ; [pp+0x17e0] List(0) []
    // 0xce3d40: StoreField: r1->field_f = r0
    //     0xce3d40: stur            w0, [x1, #0xf]
    // 0xce3d44: StoreField: r1->field_13 = rZR
    //     0xce3d44: stur            wzr, [x1, #0x13]
    // 0xce3d48: ArrayStore: r1[0] = rZR  ; List_4
    //     0xce3d48: stur            wzr, [x1, #0x17]
    // 0xce3d4c: mov             x0, x1
    // 0xce3d50: ldur            x2, [fp, #-8]
    // 0xce3d54: StoreField: r2->field_2b = r0
    //     0xce3d54: stur            w0, [x2, #0x2b]
    //     0xce3d58: ldurb           w16, [x2, #-1]
    //     0xce3d5c: ldurb           w17, [x0, #-1]
    //     0xce3d60: and             x16, x17, x16, lsr #2
    //     0xce3d64: tst             x16, HEAP, lsr #32
    //     0xce3d68: b.eq            #0xce3d70
    //     0xce3d6c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xce3d70: ldur            x0, [fp, #-0x18]
    // 0xce3d74: StoreField: r2->field_2f = r0
    //     0xce3d74: stur            w0, [x2, #0x2f]
    //     0xce3d78: ldurb           w16, [x2, #-1]
    //     0xce3d7c: ldurb           w17, [x0, #-1]
    //     0xce3d80: and             x16, x17, x16, lsr #2
    //     0xce3d84: tst             x16, HEAP, lsr #32
    //     0xce3d88: b.eq            #0xce3d90
    //     0xce3d8c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xce3d90: mov             x1, x2
    // 0xce3d94: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xce3d94: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xce3d98: r0 = OneSequenceGestureRecognizer()
    //     0xce3d98: bl              #0xb8d484  ; [package:flutter/src/gestures/recognizer.dart] OneSequenceGestureRecognizer::OneSequenceGestureRecognizer
    // 0xce3d9c: r16 = <int, _CombiningGestureArenaMember>
    //     0xce3d9c: add             x16, PP, #0x97, lsl #12  ; [pp+0x97d10] TypeArguments: <int, _CombiningGestureArenaMember>
    //     0xce3da0: ldr             x16, [x16, #0xd10]
    // 0xce3da4: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0xce3da8: stp             lr, x16, [SP]
    // 0xce3dac: r0 = Map._fromLiteral()
    //     0xce3dac: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0xce3db0: stur            x0, [fp, #-0x28]
    // 0xce3db4: r0 = GestureArenaTeam()
    //     0xce3db4: bl              #0xb8d888  ; AllocateGestureArenaTeamStub -> GestureArenaTeam (size=0x10)
    // 0xce3db8: mov             x1, x0
    // 0xce3dbc: ldur            x0, [fp, #-0x28]
    // 0xce3dc0: StoreField: r1->field_7 = r0
    //     0xce3dc0: stur            w0, [x1, #7]
    // 0xce3dc4: ldur            x3, [fp, #-8]
    // 0xce3dc8: StoreField: r1->field_b = r3
    //     0xce3dc8: stur            w3, [x1, #0xb]
    // 0xce3dcc: mov             x0, x1
    // 0xce3dd0: StoreField: r3->field_1f = r0
    //     0xce3dd0: stur            w0, [x3, #0x1f]
    //     0xce3dd4: ldurb           w16, [x3, #-1]
    //     0xce3dd8: ldurb           w17, [x0, #-1]
    //     0xce3ddc: and             x16, x17, x16, lsr #2
    //     0xce3de0: tst             x16, HEAP, lsr #32
    //     0xce3de4: b.eq            #0xce3dec
    //     0xce3de8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce3dec: ldur            x2, [fp, #-0x20]
    // 0xce3df0: r1 = Function '<anonymous closure>':.
    //     0xce3df0: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa17c0] AnonymousClosure: (0xce3e98), in [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::_PlatformViewGestureRecognizer (0xce3c9c)
    //     0xce3df4: ldr             x1, [x1, #0x7c0]
    // 0xce3df8: r0 = AllocateClosure()
    //     0xce3df8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xce3dfc: mov             x1, x0
    // 0xce3e00: ldur            x0, [fp, #-0x18]
    // 0xce3e04: r2 = LoadClassIdInstr(r0)
    //     0xce3e04: ldur            x2, [x0, #-1]
    //     0xce3e08: ubfx            x2, x2, #0xc, #0x14
    // 0xce3e0c: r16 = <OneSequenceGestureRecognizer>
    //     0xce3e0c: add             x16, PP, #0xa1, lsl #12  ; [pp+0xa17b0] TypeArguments: <OneSequenceGestureRecognizer>
    //     0xce3e10: ldr             x16, [x16, #0x7b0]
    // 0xce3e14: stp             x0, x16, [SP, #8]
    // 0xce3e18: str             x1, [SP]
    // 0xce3e1c: mov             x0, x2
    // 0xce3e20: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xce3e20: ldr             x4, [PP, #0x40]  ; [pp+0x40] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xce3e24: r0 = GDT[cid_x0 + 0x12caa]()
    //     0xce3e24: mov             x17, #0x2caa
    //     0xce3e28: movk            x17, #1, lsl #16
    //     0xce3e2c: add             lr, x0, x17
    //     0xce3e30: ldr             lr, [x21, lr, lsl #3]
    //     0xce3e34: blr             lr
    // 0xce3e38: mov             x1, x0
    // 0xce3e3c: r0 = toSet()
    //     0xce3e3c: bl              #0xba60e0  ; [dart:core] _GrowableList::toSet
    // 0xce3e40: ldur            x1, [fp, #-8]
    // 0xce3e44: StoreField: r1->field_33 = r0
    //     0xce3e44: stur            w0, [x1, #0x33]
    //     0xce3e48: ldurb           w16, [x1, #-1]
    //     0xce3e4c: ldurb           w17, [x0, #-1]
    //     0xce3e50: and             x16, x17, x16, lsr #2
    //     0xce3e54: tst             x16, HEAP, lsr #32
    //     0xce3e58: b.eq            #0xce3e60
    //     0xce3e5c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce3e60: ldur            x0, [fp, #-0x10]
    // 0xce3e64: StoreField: r1->field_23 = r0
    //     0xce3e64: stur            w0, [x1, #0x23]
    //     0xce3e68: ldurb           w16, [x1, #-1]
    //     0xce3e6c: ldurb           w17, [x0, #-1]
    //     0xce3e70: and             x16, x17, x16, lsr #2
    //     0xce3e74: tst             x16, HEAP, lsr #32
    //     0xce3e78: b.eq            #0xce3e80
    //     0xce3e7c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce3e80: r0 = Null
    //     0xce3e80: mov             x0, NULL
    // 0xce3e84: LeaveFrame
    //     0xce3e84: mov             SP, fp
    //     0xce3e88: ldp             fp, lr, [SP], #0x10
    // 0xce3e8c: ret
    //     0xce3e8c: ret             
    // 0xce3e90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3e90: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce3e94: b               #0xce3cd0
  }
  [closure] OneSequenceGestureRecognizer <anonymous closure>(dynamic, Factory<OneSequenceGestureRecognizer>) {
    // ** addr: 0xce3e98, size: 0x1b4
    // 0xce3e98: EnterFrame
    //     0xce3e98: stp             fp, lr, [SP, #-0x10]!
    //     0xce3e9c: mov             fp, SP
    // 0xce3ea0: AllocStack(0x18)
    //     0xce3ea0: sub             SP, SP, #0x18
    // 0xce3ea4: SetupParameters([dynamic _ /* r0 */])
    //     0xce3ea4: ldr             x0, [fp, #0x18]
    //     0xce3ea8: ldur            w1, [x0, #0x17]
    //     0xce3eac: add             x1, x1, HEAP, lsl #32
    //     0xce3eb0: stur            x1, [fp, #-8]
    // 0xce3eb4: CheckStackOverflow
    //     0xce3eb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3eb8: cmp             SP, x16
    //     0xce3ebc: b.ls            #0xce4044
    // 0xce3ec0: ldr             x0, [fp, #0x10]
    // 0xce3ec4: LoadField: r2 = r0->field_b
    //     0xce3ec4: ldur            w2, [x0, #0xb]
    // 0xce3ec8: DecompressPointer r2
    //     0xce3ec8: add             x2, x2, HEAP, lsl #32
    // 0xce3ecc: str             x2, [SP]
    // 0xce3ed0: mov             x0, x2
    // 0xce3ed4: ClosureCall
    //     0xce3ed4: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xce3ed8: ldur            x2, [x0, #0x1f]
    //     0xce3edc: blr             x2
    // 0xce3ee0: mov             x3, x0
    // 0xce3ee4: ldur            x0, [fp, #-8]
    // 0xce3ee8: stur            x3, [fp, #-0x10]
    // 0xce3eec: LoadField: r1 = r0->field_f
    //     0xce3eec: ldur            w1, [x0, #0xf]
    // 0xce3ef0: DecompressPointer r1
    //     0xce3ef0: add             x1, x1, HEAP, lsl #32
    // 0xce3ef4: LoadField: r0 = r1->field_1f
    //     0xce3ef4: ldur            w0, [x1, #0x1f]
    // 0xce3ef8: DecompressPointer r0
    //     0xce3ef8: add             x0, x0, HEAP, lsl #32
    // 0xce3efc: StoreField: r3->field_1f = r0
    //     0xce3efc: stur            w0, [x3, #0x1f]
    //     0xce3f00: ldurb           w16, [x3, #-1]
    //     0xce3f04: ldurb           w17, [x0, #-1]
    //     0xce3f08: and             x16, x17, x16, lsr #2
    //     0xce3f0c: tst             x16, HEAP, lsr #32
    //     0xce3f10: b.eq            #0xce3f18
    //     0xce3f14: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce3f18: r0 = 60
    //     0xce3f18: mov             x0, #0x3c
    // 0xce3f1c: branchIfSmi(r3, 0xce3f28)
    //     0xce3f1c: tbz             w3, #0, #0xce3f28
    // 0xce3f20: r0 = LoadClassIdInstr(r3)
    //     0xce3f20: ldur            x0, [x3, #-1]
    //     0xce3f24: ubfx            x0, x0, #0xc, #0x14
    // 0xce3f28: r17 = 4439
    //     0xce3f28: mov             x17, #0x1157
    // 0xce3f2c: cmp             x0, x17
    // 0xce3f30: b.ne            #0xce3f7c
    // 0xce3f34: LoadField: r0 = r3->field_5b
    //     0xce3f34: ldur            w0, [x3, #0x5b]
    // 0xce3f38: DecompressPointer r0
    //     0xce3f38: add             x0, x0, HEAP, lsl #32
    // 0xce3f3c: cmp             w0, NULL
    // 0xce3f40: b.ne            #0xce3f74
    // 0xce3f44: r1 = Function '<anonymous closure>':.
    //     0xce3f44: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa17c8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xce3f48: ldr             x1, [x1, #0x7c8]
    // 0xce3f4c: r2 = Null
    //     0xce3f4c: mov             x2, NULL
    // 0xce3f50: r0 = AllocateClosure()
    //     0xce3f50: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xce3f54: ldur            x3, [fp, #-0x10]
    // 0xce3f58: StoreField: r3->field_5b = r0
    //     0xce3f58: stur            w0, [x3, #0x5b]
    //     0xce3f5c: ldurb           w16, [x3, #-1]
    //     0xce3f60: ldurb           w17, [x0, #-1]
    //     0xce3f64: and             x16, x17, x16, lsr #2
    //     0xce3f68: tst             x16, HEAP, lsr #32
    //     0xce3f6c: b.eq            #0xce3f74
    //     0xce3f70: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce3f74: mov             x1, x3
    // 0xce3f78: b               #0xce4034
    // 0xce3f7c: r17 = -4442
    //     0xce3f7c: mov             x17, #-0x115a
    // 0xce3f80: add             x16, x0, x17
    // 0xce3f84: cmp             x16, #6
    // 0xce3f88: b.hi            #0xce3fd4
    // 0xce3f8c: LoadField: r0 = r3->field_2b
    //     0xce3f8c: ldur            w0, [x3, #0x2b]
    // 0xce3f90: DecompressPointer r0
    //     0xce3f90: add             x0, x0, HEAP, lsl #32
    // 0xce3f94: cmp             w0, NULL
    // 0xce3f98: b.ne            #0xce3fcc
    // 0xce3f9c: r1 = Function '<anonymous closure>':.
    //     0xce3f9c: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa17d0] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xce3fa0: ldr             x1, [x1, #0x7d0]
    // 0xce3fa4: r2 = Null
    //     0xce3fa4: mov             x2, NULL
    // 0xce3fa8: r0 = AllocateClosure()
    //     0xce3fa8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xce3fac: ldur            x3, [fp, #-0x10]
    // 0xce3fb0: StoreField: r3->field_2b = r0
    //     0xce3fb0: stur            w0, [x3, #0x2b]
    //     0xce3fb4: ldurb           w16, [x3, #-1]
    //     0xce3fb8: ldurb           w17, [x0, #-1]
    //     0xce3fbc: and             x16, x17, x16, lsr #2
    //     0xce3fc0: tst             x16, HEAP, lsr #32
    //     0xce3fc4: b.eq            #0xce3fcc
    //     0xce3fc8: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xce3fcc: mov             x1, x3
    // 0xce3fd0: b               #0xce4034
    // 0xce3fd4: r17 = -4437
    //     0xce3fd4: mov             x17, #-0x1155
    // 0xce3fd8: add             x16, x0, x17
    // 0xce3fdc: cmp             x16, #1
    // 0xce3fe0: b.hi            #0xce4030
    // 0xce3fe4: LoadField: r0 = r3->field_57
    //     0xce3fe4: ldur            w0, [x3, #0x57]
    // 0xce3fe8: DecompressPointer r0
    //     0xce3fe8: add             x0, x0, HEAP, lsl #32
    // 0xce3fec: cmp             w0, NULL
    // 0xce3ff0: b.ne            #0xce4028
    // 0xce3ff4: r1 = Function '<anonymous closure>':.
    //     0xce3ff4: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa17d8] Function: [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xce3ff8: ldr             x1, [x1, #0x7d8]
    // 0xce3ffc: r2 = Null
    //     0xce3ffc: mov             x2, NULL
    // 0xce4000: r0 = AllocateClosure()
    //     0xce4000: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xce4004: ldur            x1, [fp, #-0x10]
    // 0xce4008: StoreField: r1->field_57 = r0
    //     0xce4008: stur            w0, [x1, #0x57]
    //     0xce400c: ldurb           w16, [x1, #-1]
    //     0xce4010: ldurb           w17, [x0, #-1]
    //     0xce4014: and             x16, x17, x16, lsr #2
    //     0xce4018: tst             x16, HEAP, lsr #32
    //     0xce401c: b.eq            #0xce4024
    //     0xce4020: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xce4024: b               #0xce4034
    // 0xce4028: mov             x1, x3
    // 0xce402c: b               #0xce4034
    // 0xce4030: mov             x1, x3
    // 0xce4034: mov             x0, x1
    // 0xce4038: LeaveFrame
    //     0xce4038: mov             SP, fp
    //     0xce403c: ldp             fp, lr, [SP], #0x10
    // 0xce4040: ret
    //     0xce4040: ret             
    // 0xce4044: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce4044: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce4048: b               #0xce3ec0
  }
  _ rejectGesture(/* No info */) {
    // ** addr: 0x116d22c, size: 0x70
    // 0x116d22c: EnterFrame
    //     0x116d22c: stp             fp, lr, [SP, #-0x10]!
    //     0x116d230: mov             fp, SP
    // 0x116d234: AllocStack(0x10)
    //     0x116d234: sub             SP, SP, #0x10
    // 0x116d238: SetupParameters(_PlatformViewGestureRecognizer this /* r1 => r3, fp-0x10 */)
    //     0x116d238: mov             x3, x1
    //     0x116d23c: stur            x1, [fp, #-0x10]
    // 0x116d240: CheckStackOverflow
    //     0x116d240: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116d244: cmp             SP, x16
    //     0x116d248: b.ls            #0x116d294
    // 0x116d24c: r0 = BoxInt64Instr(r2)
    //     0x116d24c: sbfiz           x0, x2, #1, #0x1f
    //     0x116d250: cmp             x2, x0, asr #1
    //     0x116d254: b.eq            #0x116d260
    //     0x116d258: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x116d25c: stur            x2, [x0, #7]
    // 0x116d260: mov             x1, x3
    // 0x116d264: mov             x2, x0
    // 0x116d268: stur            x0, [fp, #-8]
    // 0x116d26c: r0 = stopTrackingPointer()
    //     0x116d26c: bl              #0xb8c04c  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::stopTrackingPointer
    // 0x116d270: ldur            x0, [fp, #-0x10]
    // 0x116d274: LoadField: r1 = r0->field_27
    //     0x116d274: ldur            w1, [x0, #0x27]
    // 0x116d278: DecompressPointer r1
    //     0x116d278: add             x1, x1, HEAP, lsl #32
    // 0x116d27c: ldur            x2, [fp, #-8]
    // 0x116d280: r0 = remove()
    //     0x116d280: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x116d284: r0 = Null
    //     0x116d284: mov             x0, NULL
    // 0x116d288: LeaveFrame
    //     0x116d288: mov             SP, fp
    //     0x116d28c: ldp             fp, lr, [SP], #0x10
    // 0x116d290: ret
    //     0x116d290: ret             
    // 0x116d294: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116d294: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116d298: b               #0x116d24c
  }
  _ acceptGesture(/* No info */) {
    // ** addr: 0x119ca44, size: 0x7c
    // 0x119ca44: EnterFrame
    //     0x119ca44: stp             fp, lr, [SP, #-0x10]!
    //     0x119ca48: mov             fp, SP
    // 0x119ca4c: AllocStack(0x10)
    //     0x119ca4c: sub             SP, SP, #0x10
    // 0x119ca50: SetupParameters(_PlatformViewGestureRecognizer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x119ca50: mov             x3, x1
    //     0x119ca54: mov             x0, x2
    //     0x119ca58: stur            x1, [fp, #-8]
    //     0x119ca5c: stur            x2, [fp, #-0x10]
    // 0x119ca60: CheckStackOverflow
    //     0x119ca60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119ca64: cmp             SP, x16
    //     0x119ca68: b.ls            #0x119cab8
    // 0x119ca6c: mov             x1, x3
    // 0x119ca70: mov             x2, x0
    // 0x119ca74: r0 = _flushPointerCache()
    //     0x119ca74: bl              #0x119cac0  ; [package:flutter/src/rendering/platform_view.dart] _PlatformViewGestureRecognizer::_flushPointerCache
    // 0x119ca78: ldur            x0, [fp, #-8]
    // 0x119ca7c: LoadField: r2 = r0->field_2b
    //     0x119ca7c: ldur            w2, [x0, #0x2b]
    // 0x119ca80: DecompressPointer r2
    //     0x119ca80: add             x2, x2, HEAP, lsl #32
    // 0x119ca84: ldur            x3, [fp, #-0x10]
    // 0x119ca88: r0 = BoxInt64Instr(r3)
    //     0x119ca88: sbfiz           x0, x3, #1, #0x1f
    //     0x119ca8c: cmp             x3, x0, asr #1
    //     0x119ca90: b.eq            #0x119ca9c
    //     0x119ca94: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x119ca98: stur            x3, [x0, #7]
    // 0x119ca9c: mov             x1, x2
    // 0x119caa0: mov             x2, x0
    // 0x119caa4: r0 = add()
    //     0x119caa4: bl              #0x12d6178  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x119caa8: r0 = Null
    //     0x119caa8: mov             x0, NULL
    // 0x119caac: LeaveFrame
    //     0x119caac: mov             SP, fp
    //     0x119cab0: ldp             fp, lr, [SP], #0x10
    // 0x119cab4: ret
    //     0x119cab4: ret             
    // 0x119cab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119cab8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119cabc: b               #0x119ca6c
  }
  _ _flushPointerCache(/* No info */) {
    // ** addr: 0x119cac0, size: 0xb4
    // 0x119cac0: EnterFrame
    //     0x119cac0: stp             fp, lr, [SP, #-0x10]!
    //     0x119cac4: mov             fp, SP
    // 0x119cac8: AllocStack(0x8)
    //     0x119cac8: sub             SP, SP, #8
    // 0x119cacc: SetupParameters(_PlatformViewGestureRecognizer this /* r1 => r3, fp-0x8 */)
    //     0x119cacc: mov             x3, x1
    //     0x119cad0: stur            x1, [fp, #-8]
    // 0x119cad4: CheckStackOverflow
    //     0x119cad4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x119cad8: cmp             SP, x16
    //     0x119cadc: b.ls            #0x119cb60
    // 0x119cae0: LoadField: r4 = r3->field_27
    //     0x119cae0: ldur            w4, [x3, #0x27]
    // 0x119cae4: DecompressPointer r4
    //     0x119cae4: add             x4, x4, HEAP, lsl #32
    // 0x119cae8: r0 = BoxInt64Instr(r2)
    //     0x119cae8: sbfiz           x0, x2, #1, #0x1f
    //     0x119caec: cmp             x2, x0, asr #1
    //     0x119caf0: b.eq            #0x119cafc
    //     0x119caf4: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0x119caf8: stur            x2, [x0, #7]
    // 0x119cafc: mov             x1, x4
    // 0x119cb00: mov             x2, x0
    // 0x119cb04: r0 = remove()
    //     0x119cb04: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x119cb08: cmp             w0, NULL
    // 0x119cb0c: b.eq            #0x119cb50
    // 0x119cb10: ldur            x1, [fp, #-8]
    // 0x119cb14: LoadField: r2 = r1->field_23
    //     0x119cb14: ldur            w2, [x1, #0x23]
    // 0x119cb18: DecompressPointer r2
    //     0x119cb18: add             x2, x2, HEAP, lsl #32
    // 0x119cb1c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x119cb20: cmp             w2, w16
    // 0x119cb24: b.eq            #0x119cb68
    // 0x119cb28: r1 = LoadClassIdInstr(r0)
    //     0x119cb28: ldur            x1, [x0, #-1]
    //     0x119cb2c: ubfx            x1, x1, #0xc, #0x14
    // 0x119cb30: mov             x16, x0
    // 0x119cb34: mov             x0, x1
    // 0x119cb38: mov             x1, x16
    // 0x119cb3c: r0 = GDT[cid_x0 + 0x12d45]()
    //     0x119cb3c: mov             x17, #0x2d45
    //     0x119cb40: movk            x17, #1, lsl #16
    //     0x119cb44: add             lr, x0, x17
    //     0x119cb48: ldr             lr, [x21, lr, lsl #3]
    //     0x119cb4c: blr             lr
    // 0x119cb50: r0 = Null
    //     0x119cb50: mov             x0, NULL
    // 0x119cb54: LeaveFrame
    //     0x119cb54: mov             SP, fp
    //     0x119cb58: ldp             fp, lr, [SP], #0x10
    // 0x119cb5c: ret
    //     0x119cb5c: ret             
    // 0x119cb60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x119cb60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x119cb64: b               #0x119cae0
    // 0x119cb68: r9 = _handlePointerEvent
    //     0x119cb68: add             x9, PP, #0xac, lsl #12  ; [pp+0xacba8] Field <_PlatformViewGestureRecognizer@300508051._handlePointerEvent@300508051>: late (offset: 0x24)
    //     0x119cb6c: ldr             x9, [x9, #0xba8]
    // 0x119cb70: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x119cb70: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4808, size: 0x60, field offset: 0x5c
class PlatformViewRenderBox extends _MixinApplication440&RenderBox&_PlatformViewGestureMixin {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbfb068, size: 0x70
    // 0xbfb068: EnterFrame
    //     0xbfb068: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb06c: mov             fp, SP
    // 0xbfb070: AllocStack(0x8)
    //     0xbfb070: sub             SP, SP, #8
    // 0xbfb074: r0 = true
    //     0xbfb074: add             x0, NULL, #0x20  ; true
    // 0xbfb078: mov             x3, x2
    // 0xbfb07c: stur            x2, [fp, #-8]
    // 0xbfb080: CheckStackOverflow
    //     0xbfb080: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbfb084: cmp             SP, x16
    //     0xbfb088: b.ls            #0xbfb0d0
    // 0xbfb08c: StoreField: r3->field_7 = r0
    //     0xbfb08c: stur            w0, [x3, #7]
    // 0xbfb090: LoadField: r2 = r1->field_5b
    //     0xbfb090: ldur            w2, [x1, #0x5b]
    // 0xbfb094: DecompressPointer r2
    //     0xbfb094: add             x2, x2, HEAP, lsl #32
    // 0xbfb098: LoadField: r1 = r2->field_7
    //     0xbfb098: ldur            x1, [x2, #7]
    // 0xbfb09c: mov             x2, x1
    // 0xbfb0a0: mov             x1, x3
    // 0xbfb0a4: r0 = platformViewId=()
    //     0xbfb0a4: bl              #0xbfafb8  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::platformViewId=
    // 0xbfb0a8: ldur            x2, [fp, #-8]
    // 0xbfb0ac: r1 = Instance_SemanticsHitTestBehavior
    //     0xbfb0ac: add             x1, PP, #0xac, lsl #12  ; [pp+0xacbc8] Obj!SemanticsHitTestBehavior@12c7661
    //     0xbfb0b0: ldr             x1, [x1, #0xbc8]
    // 0xbfb0b4: StoreField: r2->field_af = r1
    //     0xbfb0b4: stur            w1, [x2, #0xaf]
    // 0xbfb0b8: r1 = true
    //     0xbfb0b8: add             x1, NULL, #0x20  ; true
    // 0xbfb0bc: StoreField: r2->field_1f = r1
    //     0xbfb0bc: stur            w1, [x2, #0x1f]
    // 0xbfb0c0: r0 = Null
    //     0xbfb0c0: mov             x0, NULL
    // 0xbfb0c4: LeaveFrame
    //     0xbfb0c4: mov             SP, fp
    //     0xbfb0c8: ldp             fp, lr, [SP], #0x10
    // 0xbfb0cc: ret
    //     0xbfb0cc: ret             
    // 0xbfb0d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb0d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb0d4: b               #0xbfb08c
  }
  _ paint(/* No info */) {
    // ** addr: 0xc28e78, size: 0xa4
    // 0xc28e78: EnterFrame
    //     0xc28e78: stp             fp, lr, [SP, #-0x10]!
    //     0xc28e7c: mov             fp, SP
    // 0xc28e80: AllocStack(0x20)
    //     0xc28e80: sub             SP, SP, #0x20
    // 0xc28e84: SetupParameters(PlatformViewRenderBox this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xc28e84: mov             x0, x3
    //     0xc28e88: stur            x3, [fp, #-0x18]
    //     0xc28e8c: mov             x3, x1
    //     0xc28e90: stur            x1, [fp, #-8]
    //     0xc28e94: stur            x2, [fp, #-0x10]
    // 0xc28e98: CheckStackOverflow
    //     0xc28e98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc28e9c: cmp             SP, x16
    //     0xc28ea0: b.ls            #0xc28f14
    // 0xc28ea4: mov             x1, x3
    // 0xc28ea8: r0 = size()
    //     0xc28ea8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc28eac: ldur            x1, [fp, #-0x18]
    // 0xc28eb0: mov             x2, x0
    // 0xc28eb4: r0 = &()
    //     0xc28eb4: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc28eb8: mov             x1, x0
    // 0xc28ebc: ldur            x0, [fp, #-8]
    // 0xc28ec0: stur            x1, [fp, #-0x18]
    // 0xc28ec4: LoadField: r2 = r0->field_5b
    //     0xc28ec4: ldur            w2, [x0, #0x5b]
    // 0xc28ec8: DecompressPointer r2
    //     0xc28ec8: add             x2, x2, HEAP, lsl #32
    // 0xc28ecc: LoadField: r0 = r2->field_7
    //     0xc28ecc: ldur            x0, [x2, #7]
    // 0xc28ed0: stur            x0, [fp, #-0x20]
    // 0xc28ed4: r0 = PlatformViewLayer()
    //     0xc28ed4: bl              #0xc28e2c  ; AllocatePlatformViewLayerStub -> PlatformViewLayer (size=0x4c)
    // 0xc28ed8: mov             x2, x0
    // 0xc28edc: ldur            x0, [fp, #-0x18]
    // 0xc28ee0: stur            x2, [fp, #-8]
    // 0xc28ee4: StoreField: r2->field_3f = r0
    //     0xc28ee4: stur            w0, [x2, #0x3f]
    // 0xc28ee8: ldur            x0, [fp, #-0x20]
    // 0xc28eec: StoreField: r2->field_43 = r0
    //     0xc28eec: stur            x0, [x2, #0x43]
    // 0xc28ef0: mov             x1, x2
    // 0xc28ef4: r0 = Layer()
    //     0xc28ef4: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc28ef8: ldur            x1, [fp, #-0x10]
    // 0xc28efc: ldur            x2, [fp, #-8]
    // 0xc28f00: r0 = addLayer()
    //     0xc28f00: bl              #0xc28ddc  ; [package:flutter/src/rendering/object.dart] PaintingContext::addLayer
    // 0xc28f04: r0 = Null
    //     0xc28f04: mov             x0, NULL
    // 0xc28f08: LeaveFrame
    //     0xc28f08: mov             SP, fp
    //     0xc28f0c: ldp             fp, lr, [SP], #0x10
    // 0xc28f10: ret
    //     0xc28f10: ret             
    // 0xc28f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc28f14: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc28f18: b               #0xc28ea4
  }
  _ updateGestureRecognizers(/* No info */) {
    // ** addr: 0xce3b28, size: 0x64
    // 0xce3b28: EnterFrame
    //     0xce3b28: stp             fp, lr, [SP, #-0x10]!
    //     0xce3b2c: mov             fp, SP
    // 0xce3b30: AllocStack(0x10)
    //     0xce3b30: sub             SP, SP, #0x10
    // 0xce3b34: SetupParameters(PlatformViewRenderBox this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xce3b34: mov             x3, x1
    //     0xce3b38: mov             x0, x2
    //     0xce3b3c: stur            x1, [fp, #-8]
    //     0xce3b40: stur            x2, [fp, #-0x10]
    // 0xce3b44: CheckStackOverflow
    //     0xce3b44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xce3b48: cmp             SP, x16
    //     0xce3b4c: b.ls            #0xce3b84
    // 0xce3b50: LoadField: r2 = r3->field_5b
    //     0xce3b50: ldur            w2, [x3, #0x5b]
    // 0xce3b54: DecompressPointer r2
    //     0xce3b54: add             x2, x2, HEAP, lsl #32
    // 0xce3b58: r1 = Function 'dispatchPointerEvent':.
    //     0xce3b58: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1708] AnonymousClosure: (0xba31f4), in [package:flutter/src/services/platform_views.dart] AndroidViewController::dispatchPointerEvent (0xba3230)
    //     0xce3b5c: ldr             x1, [x1, #0x708]
    // 0xce3b60: r0 = AllocateClosure()
    //     0xce3b60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xce3b64: ldur            x1, [fp, #-8]
    // 0xce3b68: ldur            x2, [fp, #-0x10]
    // 0xce3b6c: mov             x3, x0
    // 0xce3b70: r0 = _updateGestureRecognizersWithCallBack()
    //     0xce3b70: bl              #0xce3b8c  ; [dart:mixin_deduplication] _MixinApplication440&RenderBox&_PlatformViewGestureMixin::_updateGestureRecognizersWithCallBack
    // 0xce3b74: r0 = Null
    //     0xce3b74: mov             x0, NULL
    // 0xce3b78: LeaveFrame
    //     0xce3b78: mov             SP, fp
    //     0xce3b7c: ldp             fp, lr, [SP], #0x10
    // 0xce3b80: ret
    //     0xce3b80: ret             
    // 0xce3b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce3b84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce3b88: b               #0xce3b50
  }
  _ PlatformViewRenderBox(/* No info */) {
    // ** addr: 0x11c143c, size: 0xa4
    // 0x11c143c: EnterFrame
    //     0x11c143c: stp             fp, lr, [SP, #-0x10]!
    //     0x11c1440: mov             fp, SP
    // 0x11c1444: AllocStack(0x10)
    //     0x11c1444: sub             SP, SP, #0x10
    // 0x11c1448: SetupParameters(PlatformViewRenderBox this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0 */, dynamic _ /* r3 => r2, fp-0x10 */)
    //     0x11c1448: mov             x0, x2
    //     0x11c144c: mov             x2, x3
    //     0x11c1450: stur            x1, [fp, #-8]
    //     0x11c1454: stur            x3, [fp, #-0x10]
    // 0x11c1458: CheckStackOverflow
    //     0x11c1458: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c145c: cmp             SP, x16
    //     0x11c1460: b.ls            #0x11c14d8
    // 0x11c1464: StoreField: r1->field_5b = r0
    //     0x11c1464: stur            w0, [x1, #0x5b]
    //     0x11c1468: ldurb           w16, [x1, #-1]
    //     0x11c146c: ldurb           w17, [x0, #-1]
    //     0x11c1470: and             x16, x17, x16, lsr #2
    //     0x11c1474: tst             x16, HEAP, lsr #32
    //     0x11c1478: b.eq            #0x11c1480
    //     0x11c147c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c1480: r0 = _LayoutCacheStorage()
    //     0x11c1480: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11c1484: ldur            x2, [fp, #-8]
    // 0x11c1488: StoreField: r2->field_47 = r0
    //     0x11c1488: stur            w0, [x2, #0x47]
    //     0x11c148c: ldurb           w16, [x2, #-1]
    //     0x11c1490: ldurb           w17, [x0, #-1]
    //     0x11c1494: and             x16, x17, x16, lsr #2
    //     0x11c1498: tst             x16, HEAP, lsr #32
    //     0x11c149c: b.eq            #0x11c14a4
    //     0x11c14a0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11c14a4: mov             x1, x2
    // 0x11c14a8: r0 = RenderObject()
    //     0x11c14a8: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11c14ac: ldur            x1, [fp, #-8]
    // 0x11c14b0: r2 = Instance_PlatformViewHitTestBehavior
    //     0x11c14b0: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d428] Obj!PlatformViewHitTestBehavior@12c4481
    //     0x11c14b4: ldr             x2, [x2, #0x428]
    // 0x11c14b8: r0 = hitTestBehavior=()
    //     0x11c14b8: bl              #0xce429c  ; [dart:mixin_deduplication] _MixinApplication440&RenderBox&_PlatformViewGestureMixin::hitTestBehavior=
    // 0x11c14bc: ldur            x1, [fp, #-8]
    // 0x11c14c0: ldur            x2, [fp, #-0x10]
    // 0x11c14c4: r0 = updateGestureRecognizers()
    //     0x11c14c4: bl              #0xce3b28  ; [package:flutter/src/rendering/platform_view.dart] PlatformViewRenderBox::updateGestureRecognizers
    // 0x11c14c8: r0 = Null
    //     0x11c14c8: mov             x0, NULL
    // 0x11c14cc: LeaveFrame
    //     0x11c14cc: mov             SP, fp
    //     0x11c14d0: ldp             fp, lr, [SP], #0x10
    // 0x11c14d4: ret
    //     0x11c14d4: ret             
    // 0x11c14d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c14d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c14dc: b               #0x11c1464
  }
  set _ controller=(/* No info */) {
    // ** addr: 0x1233624, size: 0xa8
    // 0x1233624: EnterFrame
    //     0x1233624: stp             fp, lr, [SP, #-0x10]!
    //     0x1233628: mov             fp, SP
    // 0x123362c: AllocStack(0x18)
    //     0x123362c: sub             SP, SP, #0x18
    // 0x1233630: SetupParameters(PlatformViewRenderBox this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0 */)
    //     0x1233630: mov             x0, x2
    //     0x1233634: mov             x2, x1
    //     0x1233638: stur            x1, [fp, #-0x18]
    // 0x123363c: CheckStackOverflow
    //     0x123363c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1233640: cmp             SP, x16
    //     0x1233644: b.ls            #0x12336c4
    // 0x1233648: LoadField: r1 = r2->field_5b
    //     0x1233648: ldur            w1, [x2, #0x5b]
    // 0x123364c: DecompressPointer r1
    //     0x123364c: add             x1, x1, HEAP, lsl #32
    // 0x1233650: cmp             w1, w0
    // 0x1233654: b.ne            #0x1233668
    // 0x1233658: r0 = Null
    //     0x1233658: mov             x0, NULL
    // 0x123365c: LeaveFrame
    //     0x123365c: mov             SP, fp
    //     0x1233660: ldp             fp, lr, [SP], #0x10
    // 0x1233664: ret
    //     0x1233664: ret             
    // 0x1233668: LoadField: r3 = r1->field_7
    //     0x1233668: ldur            x3, [x1, #7]
    // 0x123366c: stur            x3, [fp, #-0x10]
    // 0x1233670: LoadField: r4 = r0->field_7
    //     0x1233670: ldur            x4, [x0, #7]
    // 0x1233674: stur            x4, [fp, #-8]
    // 0x1233678: StoreField: r2->field_5b = r0
    //     0x1233678: stur            w0, [x2, #0x5b]
    //     0x123367c: ldurb           w16, [x2, #-1]
    //     0x1233680: ldurb           w17, [x0, #-1]
    //     0x1233684: and             x16, x17, x16, lsr #2
    //     0x1233688: tst             x16, HEAP, lsr #32
    //     0x123368c: b.eq            #0x1233694
    //     0x1233690: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1233694: mov             x1, x2
    // 0x1233698: r0 = markNeedsPaint()
    //     0x1233698: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x123369c: ldur            x0, [fp, #-0x10]
    // 0x12336a0: ldur            x1, [fp, #-8]
    // 0x12336a4: cmp             x0, x1
    // 0x12336a8: b.eq            #0x12336b4
    // 0x12336ac: ldur            x1, [fp, #-0x18]
    // 0x12336b0: r0 = markNeedsSemanticsUpdate()
    //     0x12336b0: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x12336b4: r0 = Null
    //     0x12336b4: mov             x0, NULL
    // 0x12336b8: LeaveFrame
    //     0x12336b8: mov             SP, fp
    //     0x12336bc: ldp             fp, lr, [SP], #0x10
    // 0x12336c0: ret
    //     0x12336c0: ret             
    // 0x12336c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x12336c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x12336c8: b               #0x1233648
  }
}

// class id: 4809, size: 0x78, field offset: 0x60
class RenderAndroidView extends PlatformViewRenderBox {

  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbfaee0, size: 0xd8
    // 0xbfaee0: r3 = true
    //     0xbfaee0: add             x3, NULL, #0x20  ; true
    // 0xbfaee4: StoreField: r2->field_7 = r3
    //     0xbfaee4: stur            w3, [x2, #7]
    // 0xbfaee8: LoadField: r4 = r1->field_6b
    //     0xbfaee8: ldur            w4, [x1, #0x6b]
    // 0xbfaeec: DecompressPointer r4
    //     0xbfaeec: add             x4, x4, HEAP, lsl #32
    // 0xbfaef0: LoadField: r5 = r4->field_1b
    //     0xbfaef0: ldur            w5, [x4, #0x1b]
    // 0xbfaef4: DecompressPointer r5
    //     0xbfaef4: add             x5, x5, HEAP, lsl #32
    // 0xbfaef8: r16 = Instance__AndroidViewState
    //     0xbfaef8: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3a8] Obj!_AndroidViewState@12c3d61
    //     0xbfaefc: ldr             x16, [x16, #0x3a8]
    // 0xbfaf00: cmp             w5, w16
    // 0xbfaf04: b.ne            #0xbfafb0
    // 0xbfaf08: LoadField: r5 = r4->field_7
    //     0xbfaf08: ldur            x5, [x4, #7]
    // 0xbfaf0c: LoadField: r4 = r2->field_43
    //     0xbfaf0c: ldur            w4, [x2, #0x43]
    // 0xbfaf10: DecompressPointer r4
    //     0xbfaf10: add             x4, x4, HEAP, lsl #32
    // 0xbfaf14: r0 = BoxInt64Instr(r5)
    //     0xbfaf14: sbfiz           x0, x5, #1, #0x1f
    //     0xbfaf18: cmp             x5, x0, asr #1
    //     0xbfaf1c: b.eq            #0xbfaf38
    //     0xbfaf20: stp             fp, lr, [SP, #-0x10]!
    //     0xbfaf24: mov             fp, SP
    //     0xbfaf28: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbfaf2c: mov             SP, fp
    //     0xbfaf30: ldp             fp, lr, [SP], #0x10
    //     0xbfaf34: stur            x5, [x0, #7]
    // 0xbfaf38: cmp             w0, w4
    // 0xbfaf3c: b.eq            #0xbfafa0
    // 0xbfaf40: and             w16, w0, w4
    // 0xbfaf44: branchIfSmi(r16, 0xbfaf78)
    //     0xbfaf44: tbz             w16, #0, #0xbfaf78
    // 0xbfaf48: r16 = LoadClassIdInstr(r0)
    //     0xbfaf48: ldur            x16, [x0, #-1]
    //     0xbfaf4c: ubfx            x16, x16, #0xc, #0x14
    // 0xbfaf50: cmp             x16, #0x3d
    // 0xbfaf54: b.ne            #0xbfaf78
    // 0xbfaf58: r16 = LoadClassIdInstr(r4)
    //     0xbfaf58: ldur            x16, [x4, #-1]
    //     0xbfaf5c: ubfx            x16, x16, #0xc, #0x14
    // 0xbfaf60: cmp             x16, #0x3d
    // 0xbfaf64: b.ne            #0xbfaf78
    // 0xbfaf68: LoadField: r16 = r0->field_7
    //     0xbfaf68: ldur            x16, [x0, #7]
    // 0xbfaf6c: LoadField: r17 = r4->field_7
    //     0xbfaf6c: ldur            x17, [x4, #7]
    // 0xbfaf70: cmp             x16, x17
    // 0xbfaf74: b.eq            #0xbfafa0
    // 0xbfaf78: StoreField: r2->field_43 = r0
    //     0xbfaf78: stur            w0, [x2, #0x43]
    //     0xbfaf7c: tbz             w0, #0, #0xbfafa0
    //     0xbfaf80: ldurb           w16, [x2, #-1]
    //     0xbfaf84: ldurb           w17, [x0, #-1]
    //     0xbfaf88: and             x16, x17, x16, lsr #2
    //     0xbfaf8c: tst             x16, HEAP, lsr #32
    //     0xbfaf90: b.eq            #0xbfafa0
    //     0xbfaf94: str             lr, [SP, #-8]!
    //     0xbfaf98: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    //     0xbfaf9c: ldr             lr, [SP], #8
    // 0xbfafa0: r1 = Instance_SemanticsHitTestBehavior
    //     0xbfafa0: add             x1, PP, #0xac, lsl #12  ; [pp+0xacbc8] Obj!SemanticsHitTestBehavior@12c7661
    //     0xbfafa4: ldr             x1, [x1, #0xbc8]
    // 0xbfafa8: StoreField: r2->field_af = r1
    //     0xbfafa8: stur            w1, [x2, #0xaf]
    // 0xbfafac: StoreField: r2->field_1f = r3
    //     0xbfafac: stur            w3, [x2, #0x1f]
    // 0xbfafb0: r0 = Null
    //     0xbfafb0: mov             x0, NULL
    // 0xbfafb4: ret
    //     0xbfafb4: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc0363c, size: 0x84
    // 0xc0363c: EnterFrame
    //     0xc0363c: stp             fp, lr, [SP, #-0x10]!
    //     0xc03640: mov             fp, SP
    // 0xc03644: AllocStack(0x10)
    //     0xc03644: sub             SP, SP, #0x10
    // 0xc03648: r0 = true
    //     0xc03648: add             x0, NULL, #0x20  ; true
    // 0xc0364c: mov             x3, x1
    // 0xc03650: stur            x1, [fp, #-8]
    // 0xc03654: CheckStackOverflow
    //     0xc03654: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc03658: cmp             SP, x16
    //     0xc0365c: b.ls            #0xc036b8
    // 0xc03660: StoreField: r3->field_67 = r0
    //     0xc03660: stur            w0, [x3, #0x67]
    // 0xc03664: LoadField: r1 = r3->field_73
    //     0xc03664: ldur            w1, [x3, #0x73]
    // 0xc03668: DecompressPointer r1
    //     0xc03668: add             x1, x1, HEAP, lsl #32
    // 0xc0366c: r2 = Null
    //     0xc0366c: mov             x2, NULL
    // 0xc03670: r0 = layer=()
    //     0xc03670: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc03674: ldur            x0, [fp, #-8]
    // 0xc03678: LoadField: r3 = r0->field_6b
    //     0xc03678: ldur            w3, [x0, #0x6b]
    // 0xc0367c: DecompressPointer r3
    //     0xc0367c: add             x3, x3, HEAP, lsl #32
    // 0xc03680: mov             x2, x0
    // 0xc03684: stur            x3, [fp, #-0x10]
    // 0xc03688: r1 = Function '_onPlatformViewCreated@300508051':.
    //     0xc03688: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa16d0] AnonymousClosure: (0xc036fc), of [package:flutter/src/rendering/platform_view.dart] RenderAndroidView
    //     0xc0368c: ldr             x1, [x1, #0x6d0]
    // 0xc03690: r0 = AllocateClosure()
    //     0xc03690: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc03694: ldur            x1, [fp, #-0x10]
    // 0xc03698: mov             x2, x0
    // 0xc0369c: r0 = removeOnPlatformViewCreatedListener()
    //     0xc0369c: bl              #0xc036c0  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::removeOnPlatformViewCreatedListener
    // 0xc036a0: ldur            x1, [fp, #-8]
    // 0xc036a4: r0 = dispose()
    //     0xc036a4: bl              #0xc03738  ; [dart:mixin_deduplication] _MixinApplication440&RenderBox&_PlatformViewGestureMixin::dispose
    // 0xc036a8: r0 = Null
    //     0xc036a8: mov             x0, NULL
    // 0xc036ac: LeaveFrame
    //     0xc036ac: mov             SP, fp
    //     0xc036b0: ldp             fp, lr, [SP], #0x10
    // 0xc036b4: ret
    //     0xc036b4: ret             
    // 0xc036b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc036b8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc036bc: b               #0xc03660
  }
  [closure] void _onPlatformViewCreated(dynamic, int) {
    // ** addr: 0xc036fc, size: 0x3c
    // 0xc036fc: EnterFrame
    //     0xc036fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc03700: mov             fp, SP
    // 0xc03704: ldr             x0, [fp, #0x18]
    // 0xc03708: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc03708: ldur            w1, [x0, #0x17]
    // 0xc0370c: DecompressPointer r1
    //     0xc0370c: add             x1, x1, HEAP, lsl #32
    // 0xc03710: CheckStackOverflow
    //     0xc03710: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc03714: cmp             SP, x16
    //     0xc03718: b.ls            #0xc03730
    // 0xc0371c: r0 = markNeedsSemanticsUpdate()
    //     0xc0371c: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xc03720: r0 = Null
    //     0xc03720: mov             x0, NULL
    // 0xc03724: LeaveFrame
    //     0xc03724: mov             SP, fp
    //     0xc03728: ldp             fp, lr, [SP], #0x10
    // 0xc0372c: ret
    //     0xc0372c: ret             
    // 0xc03730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc03730: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc03734: b               #0xc0371c
  }
  _ paint(/* No info */) {
    // ** addr: 0xc289f4, size: 0x200
    // 0xc289f4: EnterFrame
    //     0xc289f4: stp             fp, lr, [SP, #-0x10]!
    //     0xc289f8: mov             fp, SP
    // 0xc289fc: AllocStack(0x48)
    //     0xc289fc: sub             SP, SP, #0x48
    // 0xc28a00: SetupParameters(RenderAndroidView this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0xc28a00: mov             x0, x3
    //     0xc28a04: stur            x3, [fp, #-0x18]
    //     0xc28a08: mov             x3, x1
    //     0xc28a0c: stur            x1, [fp, #-8]
    //     0xc28a10: stur            x2, [fp, #-0x10]
    // 0xc28a14: CheckStackOverflow
    //     0xc28a14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc28a18: cmp             SP, x16
    //     0xc28a1c: b.ls            #0xc28be8
    // 0xc28a20: LoadField: r1 = r3->field_6b
    //     0xc28a20: ldur            w1, [x3, #0x6b]
    // 0xc28a24: DecompressPointer r1
    //     0xc28a24: add             x1, x1, HEAP, lsl #32
    // 0xc28a28: r4 = LoadClassIdInstr(r1)
    //     0xc28a28: ldur            x4, [x1, #-1]
    //     0xc28a2c: ubfx            x4, x4, #0xc, #0x14
    // 0xc28a30: cmp             x4, #0xacc
    // 0xc28a34: b.eq            #0xc28bb0
    // 0xc28a38: LoadField: r5 = r1->field_27
    //     0xc28a38: ldur            w5, [x1, #0x27]
    // 0xc28a3c: DecompressPointer r5
    //     0xc28a3c: add             x5, x5, HEAP, lsl #32
    // 0xc28a40: r1 = LoadClassIdInstr(r5)
    //     0xc28a40: ldur            x1, [x5, #-1]
    //     0xc28a44: ubfx            x1, x1, #0xc, #0x14
    // 0xc28a48: cmp             x1, #0xac8
    // 0xc28a4c: b.eq            #0xc28bbc
    // 0xc28a50: LoadField: r6 = r5->field_b
    //     0xc28a50: ldur            w6, [x5, #0xb]
    // 0xc28a54: DecompressPointer r6
    //     0xc28a54: add             x6, x6, HEAP, lsl #32
    // 0xc28a58: cmp             w6, NULL
    // 0xc28a5c: b.ne            #0xc28a70
    // 0xc28a60: cmp             x4, #0xacc
    // 0xc28a64: b.eq            #0xc28bdc
    // 0xc28a68: cmp             x1, #0xac8
    // 0xc28a6c: b.ne            #0xc28a80
    // 0xc28a70: LoadField: r1 = r3->field_63
    //     0xc28a70: ldur            w1, [x3, #0x63]
    // 0xc28a74: DecompressPointer r1
    //     0xc28a74: add             x1, x1, HEAP, lsl #32
    // 0xc28a78: cmp             w1, NULL
    // 0xc28a7c: b.ne            #0xc28a90
    // 0xc28a80: r0 = Null
    //     0xc28a80: mov             x0, NULL
    // 0xc28a84: LeaveFrame
    //     0xc28a84: mov             SP, fp
    //     0xc28a88: ldp             fp, lr, [SP], #0x10
    // 0xc28a8c: ret
    //     0xc28a8c: ret             
    // 0xc28a90: LoadField: d0 = r1->field_7
    //     0xc28a90: ldur            d0, [x1, #7]
    // 0xc28a94: mov             x1, x3
    // 0xc28a98: stur            d0, [fp, #-0x38]
    // 0xc28a9c: r0 = size()
    //     0xc28a9c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc28aa0: LoadField: d0 = r0->field_7
    //     0xc28aa0: ldur            d0, [x0, #7]
    // 0xc28aa4: ldur            d1, [fp, #-0x38]
    // 0xc28aa8: fcmp            d1, d0
    // 0xc28aac: b.gt            #0xc28ae4
    // 0xc28ab0: ldur            x0, [fp, #-8]
    // 0xc28ab4: LoadField: r1 = r0->field_63
    //     0xc28ab4: ldur            w1, [x0, #0x63]
    // 0xc28ab8: DecompressPointer r1
    //     0xc28ab8: add             x1, x1, HEAP, lsl #32
    // 0xc28abc: cmp             w1, NULL
    // 0xc28ac0: b.eq            #0xc28bf0
    // 0xc28ac4: LoadField: d0 = r1->field_f
    //     0xc28ac4: ldur            d0, [x1, #0xf]
    // 0xc28ac8: mov             x1, x0
    // 0xc28acc: stur            d0, [fp, #-0x38]
    // 0xc28ad0: r0 = size()
    //     0xc28ad0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc28ad4: LoadField: d0 = r0->field_f
    //     0xc28ad4: ldur            d0, [x0, #0xf]
    // 0xc28ad8: ldur            d1, [fp, #-0x38]
    // 0xc28adc: fcmp            d1, d0
    // 0xc28ae0: b.le            #0xc28b7c
    // 0xc28ae4: ldur            x0, [fp, #-8]
    // 0xc28ae8: LoadField: r2 = r0->field_73
    //     0xc28ae8: ldur            w2, [x0, #0x73]
    // 0xc28aec: DecompressPointer r2
    //     0xc28aec: add             x2, x2, HEAP, lsl #32
    // 0xc28af0: mov             x1, x0
    // 0xc28af4: stur            x2, [fp, #-0x20]
    // 0xc28af8: r0 = size()
    //     0xc28af8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc28afc: ldur            x1, [fp, #-0x18]
    // 0xc28b00: mov             x2, x0
    // 0xc28b04: r0 = &()
    //     0xc28b04: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc28b08: mov             x3, x0
    // 0xc28b0c: ldur            x0, [fp, #-0x20]
    // 0xc28b10: stur            x3, [fp, #-0x30]
    // 0xc28b14: LoadField: r4 = r0->field_b
    //     0xc28b14: ldur            w4, [x0, #0xb]
    // 0xc28b18: DecompressPointer r4
    //     0xc28b18: add             x4, x4, HEAP, lsl #32
    // 0xc28b1c: ldur            x2, [fp, #-8]
    // 0xc28b20: stur            x4, [fp, #-0x28]
    // 0xc28b24: r1 = Function '_paintTexture@300508051':.
    //     0xc28b24: add             x1, PP, #0xac, lsl #12  ; [pp+0xacbd0] AnonymousClosure: (0xc28e38), in [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_paintTexture (0xc28bf4)
    //     0xc28b28: ldr             x1, [x1, #0xbd0]
    // 0xc28b2c: r0 = AllocateClosure()
    //     0xc28b2c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc28b30: r16 = Instance_Clip
    //     0xc28b30: add             x16, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xc28b34: ldr             x16, [x16, #0x850]
    // 0xc28b38: ldur            lr, [fp, #-0x28]
    // 0xc28b3c: stp             lr, x16, [SP]
    // 0xc28b40: ldur            x1, [fp, #-0x10]
    // 0xc28b44: ldur            x3, [fp, #-0x18]
    // 0xc28b48: ldur            x5, [fp, #-0x30]
    // 0xc28b4c: mov             x6, x0
    // 0xc28b50: r2 = true
    //     0xc28b50: add             x2, NULL, #0x20  ; true
    // 0xc28b54: r4 = const [0, 0x7, 0x2, 0x5, clipBehavior, 0x5, oldLayer, 0x6, null]
    //     0xc28b54: add             x4, PP, #0x90, lsl #12  ; [pp+0x90688] List(9) [0, 0x7, 0x2, 0x5, "clipBehavior", 0x5, "oldLayer", 0x6, Null]
    //     0xc28b58: ldr             x4, [x4, #0x688]
    // 0xc28b5c: r0 = pushClipRect()
    //     0xc28b5c: bl              #0xc19194  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0xc28b60: ldur            x1, [fp, #-0x20]
    // 0xc28b64: mov             x2, x0
    // 0xc28b68: r0 = layer=()
    //     0xc28b68: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc28b6c: r0 = Null
    //     0xc28b6c: mov             x0, NULL
    // 0xc28b70: LeaveFrame
    //     0xc28b70: mov             SP, fp
    //     0xc28b74: ldp             fp, lr, [SP], #0x10
    // 0xc28b78: ret
    //     0xc28b78: ret             
    // 0xc28b7c: ldur            x0, [fp, #-8]
    // 0xc28b80: LoadField: r1 = r0->field_73
    //     0xc28b80: ldur            w1, [x0, #0x73]
    // 0xc28b84: DecompressPointer r1
    //     0xc28b84: add             x1, x1, HEAP, lsl #32
    // 0xc28b88: r2 = Null
    //     0xc28b88: mov             x2, NULL
    // 0xc28b8c: r0 = layer=()
    //     0xc28b8c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc28b90: ldur            x1, [fp, #-8]
    // 0xc28b94: ldur            x2, [fp, #-0x10]
    // 0xc28b98: ldur            x3, [fp, #-0x18]
    // 0xc28b9c: r0 = _paintTexture()
    //     0xc28b9c: bl              #0xc28bf4  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_paintTexture
    // 0xc28ba0: r0 = Null
    //     0xc28ba0: mov             x0, NULL
    // 0xc28ba4: LeaveFrame
    //     0xc28ba4: mov             SP, fp
    //     0xc28ba8: ldp             fp, lr, [SP], #0x10
    // 0xc28bac: ret
    //     0xc28bac: ret             
    // 0xc28bb0: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xc28bb0: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xc28bb4: r0 = Throw()
    //     0xc28bb4: bl              #0x13ddb2c  ; ThrowStub
    // 0xc28bb8: brk             #0
    // 0xc28bbc: r0 = UnimplementedError()
    //     0xc28bbc: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0xc28bc0: mov             x1, x0
    // 0xc28bc4: r0 = "Not supported for hybrid composition."
    //     0xc28bc4: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa1700] "Not supported for hybrid composition."
    //     0xc28bc8: ldr             x0, [x0, #0x700]
    // 0xc28bcc: StoreField: r1->field_b = r0
    //     0xc28bcc: stur            w0, [x1, #0xb]
    // 0xc28bd0: mov             x0, x1
    // 0xc28bd4: r0 = Throw()
    //     0xc28bd4: bl              #0x13ddb2c  ; ThrowStub
    // 0xc28bd8: brk             #0
    // 0xc28bdc: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xc28bdc: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xc28be0: r0 = Throw()
    //     0xc28be0: bl              #0x13ddb2c  ; ThrowStub
    // 0xc28be4: brk             #0
    // 0xc28be8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc28be8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc28bec: b               #0xc28a20
    // 0xc28bf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc28bf0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintTexture(/* No info */) {
    // ** addr: 0xc28bf4, size: 0x1dc
    // 0xc28bf4: EnterFrame
    //     0xc28bf4: stp             fp, lr, [SP, #-0x10]!
    //     0xc28bf8: mov             fp, SP
    // 0xc28bfc: AllocStack(0x28)
    //     0xc28bfc: sub             SP, SP, #0x28
    // 0xc28c00: SetupParameters(RenderAndroidView this /* r1 => r3, fp-0x10 */, dynamic _ /* r3 => r1 */)
    //     0xc28c00: stur            x1, [fp, #-8]
    //     0xc28c04: mov             x16, x3
    //     0xc28c08: mov             x3, x1
    //     0xc28c0c: mov             x1, x16
    //     0xc28c10: mov             x0, x2
    //     0xc28c14: stur            x2, [fp, #-0x10]
    // 0xc28c18: CheckStackOverflow
    //     0xc28c18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc28c1c: cmp             SP, x16
    //     0xc28c20: b.ls            #0xc28dc4
    // 0xc28c24: LoadField: r2 = r3->field_63
    //     0xc28c24: ldur            w2, [x3, #0x63]
    // 0xc28c28: DecompressPointer r2
    //     0xc28c28: add             x2, x2, HEAP, lsl #32
    // 0xc28c2c: cmp             w2, NULL
    // 0xc28c30: b.ne            #0xc28c44
    // 0xc28c34: r0 = Null
    //     0xc28c34: mov             x0, NULL
    // 0xc28c38: LeaveFrame
    //     0xc28c38: mov             SP, fp
    //     0xc28c3c: ldp             fp, lr, [SP], #0x10
    // 0xc28c40: ret
    //     0xc28c40: ret             
    // 0xc28c44: LoadField: r4 = r3->field_6b
    //     0xc28c44: ldur            w4, [x3, #0x6b]
    // 0xc28c48: DecompressPointer r4
    //     0xc28c48: add             x4, x4, HEAP, lsl #32
    // 0xc28c4c: r5 = LoadClassIdInstr(r4)
    //     0xc28c4c: ldur            x5, [x4, #-1]
    //     0xc28c50: ubfx            x5, x5, #0xc, #0x14
    // 0xc28c54: cmp             x5, #0xacc
    // 0xc28c58: b.eq            #0xc28d8c
    // 0xc28c5c: LoadField: r5 = r4->field_27
    //     0xc28c5c: ldur            w5, [x4, #0x27]
    // 0xc28c60: DecompressPointer r5
    //     0xc28c60: add             x5, x5, HEAP, lsl #32
    // 0xc28c64: r4 = LoadClassIdInstr(r5)
    //     0xc28c64: ldur            x4, [x5, #-1]
    //     0xc28c68: ubfx            x4, x4, #0xc, #0x14
    // 0xc28c6c: cmp             x4, #0xac8
    // 0xc28c70: b.ne            #0xc28cd4
    // 0xc28c74: r0 = &()
    //     0xc28c74: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc28c78: mov             x1, x0
    // 0xc28c7c: ldur            x0, [fp, #-8]
    // 0xc28c80: stur            x1, [fp, #-0x20]
    // 0xc28c84: LoadField: r2 = r0->field_6b
    //     0xc28c84: ldur            w2, [x0, #0x6b]
    // 0xc28c88: DecompressPointer r2
    //     0xc28c88: add             x2, x2, HEAP, lsl #32
    // 0xc28c8c: LoadField: r0 = r2->field_7
    //     0xc28c8c: ldur            x0, [x2, #7]
    // 0xc28c90: stur            x0, [fp, #-0x18]
    // 0xc28c94: r0 = PlatformViewLayer()
    //     0xc28c94: bl              #0xc28e2c  ; AllocatePlatformViewLayerStub -> PlatformViewLayer (size=0x4c)
    // 0xc28c98: mov             x2, x0
    // 0xc28c9c: ldur            x0, [fp, #-0x20]
    // 0xc28ca0: stur            x2, [fp, #-0x28]
    // 0xc28ca4: StoreField: r2->field_3f = r0
    //     0xc28ca4: stur            w0, [x2, #0x3f]
    // 0xc28ca8: ldur            x0, [fp, #-0x18]
    // 0xc28cac: StoreField: r2->field_43 = r0
    //     0xc28cac: stur            x0, [x2, #0x43]
    // 0xc28cb0: mov             x1, x2
    // 0xc28cb4: r0 = Layer()
    //     0xc28cb4: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc28cb8: ldur            x1, [fp, #-0x10]
    // 0xc28cbc: ldur            x2, [fp, #-0x28]
    // 0xc28cc0: r0 = addLayer()
    //     0xc28cc0: bl              #0xc28ddc  ; [package:flutter/src/rendering/object.dart] PaintingContext::addLayer
    // 0xc28cc4: r0 = Null
    //     0xc28cc4: mov             x0, NULL
    // 0xc28cc8: LeaveFrame
    //     0xc28cc8: mov             SP, fp
    //     0xc28ccc: ldp             fp, lr, [SP], #0x10
    // 0xc28cd0: ret
    //     0xc28cd0: ret             
    // 0xc28cd4: mov             x0, x3
    // 0xc28cd8: r0 = &()
    //     0xc28cd8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc28cdc: mov             x1, x0
    // 0xc28ce0: ldur            x0, [fp, #-8]
    // 0xc28ce4: stur            x1, [fp, #-0x20]
    // 0xc28ce8: LoadField: r2 = r0->field_6b
    //     0xc28ce8: ldur            w2, [x0, #0x6b]
    // 0xc28cec: DecompressPointer r2
    //     0xc28cec: add             x2, x2, HEAP, lsl #32
    // 0xc28cf0: r0 = LoadClassIdInstr(r2)
    //     0xc28cf0: ldur            x0, [x2, #-1]
    //     0xc28cf4: ubfx            x0, x0, #0xc, #0x14
    // 0xc28cf8: cmp             x0, #0xacc
    // 0xc28cfc: b.eq            #0xc28d98
    // 0xc28d00: LoadField: r0 = r2->field_27
    //     0xc28d00: ldur            w0, [x2, #0x27]
    // 0xc28d04: DecompressPointer r0
    //     0xc28d04: add             x0, x0, HEAP, lsl #32
    // 0xc28d08: r2 = LoadClassIdInstr(r0)
    //     0xc28d08: ldur            x2, [x0, #-1]
    //     0xc28d0c: ubfx            x2, x2, #0xc, #0x14
    // 0xc28d10: cmp             x2, #0xac8
    // 0xc28d14: b.eq            #0xc28da4
    // 0xc28d18: LoadField: r2 = r0->field_b
    //     0xc28d18: ldur            w2, [x0, #0xb]
    // 0xc28d1c: DecompressPointer r2
    //     0xc28d1c: add             x2, x2, HEAP, lsl #32
    // 0xc28d20: stur            x2, [fp, #-8]
    // 0xc28d24: cmp             w2, NULL
    // 0xc28d28: b.eq            #0xc28dcc
    // 0xc28d2c: r0 = TextureLayer()
    //     0xc28d2c: bl              #0xc28dd0  ; AllocateTextureLayerStub -> TextureLayer (size=0x54)
    // 0xc28d30: mov             x2, x0
    // 0xc28d34: ldur            x0, [fp, #-0x20]
    // 0xc28d38: stur            x2, [fp, #-0x28]
    // 0xc28d3c: StoreField: r2->field_3f = r0
    //     0xc28d3c: stur            w0, [x2, #0x3f]
    // 0xc28d40: ldur            x0, [fp, #-8]
    // 0xc28d44: r1 = LoadInt32Instr(r0)
    //     0xc28d44: sbfx            x1, x0, #1, #0x1f
    //     0xc28d48: tbz             w0, #0, #0xc28d50
    //     0xc28d4c: ldur            x1, [x0, #7]
    // 0xc28d50: StoreField: r2->field_43 = r1
    //     0xc28d50: stur            x1, [x2, #0x43]
    // 0xc28d54: r0 = false
    //     0xc28d54: add             x0, NULL, #0x30  ; false
    // 0xc28d58: StoreField: r2->field_4b = r0
    //     0xc28d58: stur            w0, [x2, #0x4b]
    // 0xc28d5c: r0 = Instance_FilterQuality
    //     0xc28d5c: add             x0, PP, #0x1e, lsl #12  ; [pp+0x1e990] Obj!FilterQuality@12c8281
    //     0xc28d60: ldr             x0, [x0, #0x990]
    // 0xc28d64: StoreField: r2->field_4f = r0
    //     0xc28d64: stur            w0, [x2, #0x4f]
    // 0xc28d68: mov             x1, x2
    // 0xc28d6c: r0 = Layer()
    //     0xc28d6c: bl              #0x89d078  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0xc28d70: ldur            x1, [fp, #-0x10]
    // 0xc28d74: ldur            x2, [fp, #-0x28]
    // 0xc28d78: r0 = addLayer()
    //     0xc28d78: bl              #0xc28ddc  ; [package:flutter/src/rendering/object.dart] PaintingContext::addLayer
    // 0xc28d7c: r0 = Null
    //     0xc28d7c: mov             x0, NULL
    // 0xc28d80: LeaveFrame
    //     0xc28d80: mov             SP, fp
    //     0xc28d84: ldp             fp, lr, [SP], #0x10
    // 0xc28d88: ret
    //     0xc28d88: ret             
    // 0xc28d8c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xc28d8c: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xc28d90: r0 = Throw()
    //     0xc28d90: bl              #0x13ddb2c  ; ThrowStub
    // 0xc28d94: brk             #0
    // 0xc28d98: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xc28d98: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xc28d9c: r0 = Throw()
    //     0xc28d9c: bl              #0x13ddb2c  ; ThrowStub
    // 0xc28da0: brk             #0
    // 0xc28da4: r0 = UnimplementedError()
    //     0xc28da4: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0xc28da8: mov             x1, x0
    // 0xc28dac: r0 = "Not supported for hybrid composition."
    //     0xc28dac: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa1700] "Not supported for hybrid composition."
    //     0xc28db0: ldr             x0, [x0, #0x700]
    // 0xc28db4: StoreField: r1->field_b = r0
    //     0xc28db4: stur            w0, [x1, #0xb]
    // 0xc28db8: mov             x0, x1
    // 0xc28dbc: r0 = Throw()
    //     0xc28dbc: bl              #0x13ddb2c  ; ThrowStub
    // 0xc28dc0: brk             #0
    // 0xc28dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc28dc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc28dc8: b               #0xc28c24
    // 0xc28dcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc28dcc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _paintTexture(dynamic, PaintingContext, Offset) {
    // ** addr: 0xc28e38, size: 0x40
    // 0xc28e38: EnterFrame
    //     0xc28e38: stp             fp, lr, [SP, #-0x10]!
    //     0xc28e3c: mov             fp, SP
    // 0xc28e40: ldr             x0, [fp, #0x20]
    // 0xc28e44: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc28e44: ldur            w1, [x0, #0x17]
    // 0xc28e48: DecompressPointer r1
    //     0xc28e48: add             x1, x1, HEAP, lsl #32
    // 0xc28e4c: CheckStackOverflow
    //     0xc28e4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc28e50: cmp             SP, x16
    //     0xc28e54: b.ls            #0xc28e70
    // 0xc28e58: ldr             x2, [fp, #0x18]
    // 0xc28e5c: ldr             x3, [fp, #0x10]
    // 0xc28e60: r0 = _paintTexture()
    //     0xc28e60: bl              #0xc28bf4  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_paintTexture
    // 0xc28e64: LeaveFrame
    //     0xc28e64: mov             SP, fp
    //     0xc28e68: ldp             fp, lr, [SP], #0x10
    // 0xc28e6c: ret
    //     0xc28e6c: ret             
    // 0xc28e70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc28e70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc28e74: b               #0xc28e58
  }
  _ performResize(/* No info */) {
    // ** addr: 0xccf0e0, size: 0x48
    // 0xccf0e0: EnterFrame
    //     0xccf0e0: stp             fp, lr, [SP, #-0x10]!
    //     0xccf0e4: mov             fp, SP
    // 0xccf0e8: AllocStack(0x8)
    //     0xccf0e8: sub             SP, SP, #8
    // 0xccf0ec: SetupParameters(RenderAndroidView this /* r1 => r0, fp-0x8 */)
    //     0xccf0ec: mov             x0, x1
    //     0xccf0f0: stur            x1, [fp, #-8]
    // 0xccf0f4: CheckStackOverflow
    //     0xccf0f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccf0f8: cmp             SP, x16
    //     0xccf0fc: b.ls            #0xccf120
    // 0xccf100: mov             x1, x0
    // 0xccf104: r0 = performResize()
    //     0xccf104: bl              #0xccfb6c  ; [package:flutter/src/rendering/box.dart] RenderBox::performResize
    // 0xccf108: ldur            x1, [fp, #-8]
    // 0xccf10c: r0 = _sizePlatformView()
    //     0xccf10c: bl              #0xccf128  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_sizePlatformView
    // 0xccf110: r0 = Null
    //     0xccf110: mov             x0, NULL
    // 0xccf114: LeaveFrame
    //     0xccf114: mov             SP, fp
    //     0xccf118: ldp             fp, lr, [SP], #0x10
    // 0xccf11c: ret
    //     0xccf11c: ret             
    // 0xccf120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf120: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf124: b               #0xccf100
  }
  _ _sizePlatformView(/* No info */) async {
    // ** addr: 0xccf128, size: 0x288
    // 0xccf128: EnterFrame
    //     0xccf128: stp             fp, lr, [SP, #-0x10]!
    //     0xccf12c: mov             fp, SP
    // 0xccf130: AllocStack(0x28)
    //     0xccf130: sub             SP, SP, #0x28
    // 0xccf134: SetupParameters(RenderAndroidView this /* r1 => r1, fp-0x10 */)
    //     0xccf134: stur            NULL, [fp, #-8]
    //     0xccf138: stur            x1, [fp, #-0x10]
    // 0xccf13c: CheckStackOverflow
    //     0xccf13c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccf140: cmp             SP, x16
    //     0xccf144: b.ls            #0xccf3a0
    // 0xccf148: InitAsync() -> Future<void?>
    //     0xccf148: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0xccf14c: bl              #0x7f5e44  ; InitAsyncStub
    // 0xccf150: ldur            x0, [fp, #-0x10]
    // 0xccf154: LoadField: r1 = r0->field_5f
    //     0xccf154: ldur            w1, [x0, #0x5f]
    // 0xccf158: DecompressPointer r1
    //     0xccf158: add             x1, x1, HEAP, lsl #32
    // 0xccf15c: r16 = Instance__PlatformViewState
    //     0xccf15c: add             x16, PP, #0xac, lsl #12  ; [pp+0xacbd8] Obj!_PlatformViewState@12c4421
    //     0xccf160: ldr             x16, [x16, #0xbd8]
    // 0xccf164: cmp             w1, w16
    // 0xccf168: b.eq            #0xccf190
    // 0xccf16c: mov             x1, x0
    // 0xccf170: r0 = size()
    //     0xccf170: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xccf174: LoadField: d0 = r0->field_7
    //     0xccf174: ldur            d0, [x0, #7]
    // 0xccf178: d1 = 0.000000
    //     0xccf178: eor             v1.16b, v1.16b, v1.16b
    // 0xccf17c: fcmp            d1, d0
    // 0xccf180: b.ge            #0xccf190
    // 0xccf184: LoadField: d0 = r0->field_f
    //     0xccf184: ldur            d0, [x0, #0xf]
    // 0xccf188: fcmp            d1, d0
    // 0xccf18c: b.lt            #0xccf198
    // 0xccf190: r0 = Null
    //     0xccf190: mov             x0, NULL
    // 0xccf194: r0 = ReturnAsyncNotFuture()
    //     0xccf194: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xccf198: ldur            x0, [fp, #-0x10]
    // 0xccf19c: r1 = Instance__PlatformViewState
    //     0xccf19c: add             x1, PP, #0xac, lsl #12  ; [pp+0xacbd8] Obj!_PlatformViewState@12c4421
    //     0xccf1a0: ldr             x1, [x1, #0xbd8]
    // 0xccf1a4: StoreField: r0->field_5f = r1
    //     0xccf1a4: stur            w1, [x0, #0x5f]
    // 0xccf1a8: mov             x1, x0
    // 0xccf1ac: r0 = markNeedsPaint()
    //     0xccf1ac: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xccf1b0: ldur            x0, [fp, #-0x10]
    // 0xccf1b4: CheckStackOverflow
    //     0xccf1b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xccf1b8: cmp             SP, x16
    //     0xccf1bc: b.ls            #0xccf3a8
    // 0xccf1c0: LoadField: r3 = r0->field_4b
    //     0xccf1c0: ldur            w3, [x0, #0x4b]
    // 0xccf1c4: DecompressPointer r3
    //     0xccf1c4: add             x3, x3, HEAP, lsl #32
    // 0xccf1c8: stur            x3, [fp, #-0x18]
    // 0xccf1cc: cmp             w3, NULL
    // 0xccf1d0: b.eq            #0xccf318
    // 0xccf1d4: LoadField: r1 = r0->field_6b
    //     0xccf1d4: ldur            w1, [x0, #0x6b]
    // 0xccf1d8: DecompressPointer r1
    //     0xccf1d8: add             x1, x1, HEAP, lsl #32
    // 0xccf1dc: mov             x2, x3
    // 0xccf1e0: r0 = setSize()
    //     0xccf1e0: bl              #0xccf3b0  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::setSize
    // 0xccf1e4: mov             x1, x0
    // 0xccf1e8: stur            x1, [fp, #-0x20]
    // 0xccf1ec: r0 = Await()
    //     0xccf1ec: bl              #0x7f5c00  ; AwaitStub
    // 0xccf1f0: ldur            x3, [fp, #-0x10]
    // 0xccf1f4: StoreField: r3->field_63 = r0
    //     0xccf1f4: stur            w0, [x3, #0x63]
    //     0xccf1f8: ldurb           w16, [x3, #-1]
    //     0xccf1fc: ldurb           w17, [x0, #-1]
    //     0xccf200: and             x16, x17, x16, lsr #2
    //     0xccf204: tst             x16, HEAP, lsr #32
    //     0xccf208: b.eq            #0xccf210
    //     0xccf20c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xccf210: LoadField: r0 = r3->field_67
    //     0xccf210: ldur            w0, [x3, #0x67]
    // 0xccf214: DecompressPointer r0
    //     0xccf214: add             x0, x0, HEAP, lsl #32
    // 0xccf218: tbz             w0, #4, #0xccf288
    // 0xccf21c: LoadField: r0 = r3->field_4b
    //     0xccf21c: ldur            w0, [x3, #0x4b]
    // 0xccf220: DecompressPointer r0
    //     0xccf220: add             x0, x0, HEAP, lsl #32
    // 0xccf224: cmp             w0, NULL
    // 0xccf228: b.eq            #0xccf290
    // 0xccf22c: ldur            x1, [fp, #-0x18]
    // 0xccf230: LoadField: d0 = r1->field_7
    //     0xccf230: ldur            d0, [x1, #7]
    // 0xccf234: LoadField: d1 = r0->field_7
    //     0xccf234: ldur            d1, [x0, #7]
    // 0xccf238: fcmp            d0, d1
    // 0xccf23c: b.ne            #0xccf278
    // 0xccf240: LoadField: d0 = r1->field_f
    //     0xccf240: ldur            d0, [x1, #0xf]
    // 0xccf244: LoadField: d1 = r0->field_f
    //     0xccf244: ldur            d1, [x0, #0xf]
    // 0xccf248: fcmp            d0, d1
    // 0xccf24c: b.eq            #0xccf25c
    // 0xccf250: r0 = Instance__PlatformViewState
    //     0xccf250: add             x0, PP, #0xac, lsl #12  ; [pp+0xacbe0] Obj!_PlatformViewState@12c4401
    //     0xccf254: ldr             x0, [x0, #0xbe0]
    // 0xccf258: b               #0xccf280
    // 0xccf25c: r0 = Instance__PlatformViewState
    //     0xccf25c: add             x0, PP, #0xac, lsl #12  ; [pp+0xacbe0] Obj!_PlatformViewState@12c4401
    //     0xccf260: ldr             x0, [x0, #0xbe0]
    // 0xccf264: StoreField: r3->field_5f = r0
    //     0xccf264: stur            w0, [x3, #0x5f]
    // 0xccf268: mov             x1, x3
    // 0xccf26c: r0 = markNeedsPaint()
    //     0xccf26c: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xccf270: r0 = Null
    //     0xccf270: mov             x0, NULL
    // 0xccf274: r0 = ReturnAsyncNotFuture()
    //     0xccf274: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xccf278: r0 = Instance__PlatformViewState
    //     0xccf278: add             x0, PP, #0xac, lsl #12  ; [pp+0xacbe0] Obj!_PlatformViewState@12c4401
    //     0xccf27c: ldr             x0, [x0, #0xbe0]
    // 0xccf280: mov             x0, x3
    // 0xccf284: b               #0xccf1b4
    // 0xccf288: r0 = Null
    //     0xccf288: mov             x0, NULL
    // 0xccf28c: r0 = ReturnAsyncNotFuture()
    //     0xccf28c: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0xccf290: r1 = Null
    //     0xccf290: mov             x1, NULL
    // 0xccf294: r2 = 8
    //     0xccf294: mov             x2, #8
    // 0xccf298: r0 = AllocateArray()
    //     0xccf298: bl              #0x13df928  ; AllocateArrayStub
    // 0xccf29c: stur            x0, [fp, #-0x18]
    // 0xccf2a0: r16 = "RenderBox was not laid out: "
    //     0xccf2a0: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xccf2a4: StoreField: r0->field_f = r16
    //     0xccf2a4: stur            w16, [x0, #0xf]
    // 0xccf2a8: r16 = RenderAndroidView
    //     0xccf2a8: add             x16, PP, #0xac, lsl #12  ; [pp+0xacbe8] Type: RenderAndroidView
    //     0xccf2ac: ldr             x16, [x16, #0xbe8]
    // 0xccf2b0: StoreField: r0->field_13 = r16
    //     0xccf2b0: stur            w16, [x0, #0x13]
    // 0xccf2b4: r16 = "#"
    //     0xccf2b4: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xccf2b8: ArrayStore: r0[0] = r16  ; List_4
    //     0xccf2b8: stur            w16, [x0, #0x17]
    // 0xccf2bc: ldur            x1, [fp, #-0x10]
    // 0xccf2c0: r0 = shortHash()
    //     0xccf2c0: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xccf2c4: ldur            x1, [fp, #-0x18]
    // 0xccf2c8: ArrayStore: r1[3] = r0  ; List_4
    //     0xccf2c8: add             x25, x1, #0x1b
    //     0xccf2cc: str             w0, [x25]
    //     0xccf2d0: tbz             w0, #0, #0xccf2ec
    //     0xccf2d4: ldurb           w16, [x1, #-1]
    //     0xccf2d8: ldurb           w17, [x0, #-1]
    //     0xccf2dc: and             x16, x17, x16, lsr #2
    //     0xccf2e0: tst             x16, HEAP, lsr #32
    //     0xccf2e4: b.eq            #0xccf2ec
    //     0xccf2e8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xccf2ec: ldur            x16, [fp, #-0x18]
    // 0xccf2f0: str             x16, [SP]
    // 0xccf2f4: r0 = _interpolate()
    //     0xccf2f4: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xccf2f8: stur            x0, [fp, #-0x18]
    // 0xccf2fc: r0 = StateError()
    //     0xccf2fc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccf300: mov             x1, x0
    // 0xccf304: ldur            x0, [fp, #-0x18]
    // 0xccf308: StoreField: r1->field_b = r0
    //     0xccf308: stur            w0, [x1, #0xb]
    // 0xccf30c: mov             x0, x1
    // 0xccf310: r0 = Throw()
    //     0xccf310: bl              #0x13ddb2c  ; ThrowStub
    // 0xccf314: brk             #0
    // 0xccf318: r1 = Null
    //     0xccf318: mov             x1, NULL
    // 0xccf31c: r2 = 8
    //     0xccf31c: mov             x2, #8
    // 0xccf320: r0 = AllocateArray()
    //     0xccf320: bl              #0x13df928  ; AllocateArrayStub
    // 0xccf324: stur            x0, [fp, #-0x18]
    // 0xccf328: r16 = "RenderBox was not laid out: "
    //     0xccf328: ldr             x16, [PP, #0x47e0]  ; [pp+0x47e0] "RenderBox was not laid out: "
    // 0xccf32c: StoreField: r0->field_f = r16
    //     0xccf32c: stur            w16, [x0, #0xf]
    // 0xccf330: r16 = RenderAndroidView
    //     0xccf330: add             x16, PP, #0xac, lsl #12  ; [pp+0xacbe8] Type: RenderAndroidView
    //     0xccf334: ldr             x16, [x16, #0xbe8]
    // 0xccf338: StoreField: r0->field_13 = r16
    //     0xccf338: stur            w16, [x0, #0x13]
    // 0xccf33c: r16 = "#"
    //     0xccf33c: ldr             x16, [PP, #0x8e8]  ; [pp+0x8e8] "#"
    // 0xccf340: ArrayStore: r0[0] = r16  ; List_4
    //     0xccf340: stur            w16, [x0, #0x17]
    // 0xccf344: ldur            x1, [fp, #-0x10]
    // 0xccf348: r0 = shortHash()
    //     0xccf348: bl              #0x858904  ; [package:flutter/src/foundation/diagnostics.dart] ::shortHash
    // 0xccf34c: ldur            x1, [fp, #-0x18]
    // 0xccf350: ArrayStore: r1[3] = r0  ; List_4
    //     0xccf350: add             x25, x1, #0x1b
    //     0xccf354: str             w0, [x25]
    //     0xccf358: tbz             w0, #0, #0xccf374
    //     0xccf35c: ldurb           w16, [x1, #-1]
    //     0xccf360: ldurb           w17, [x0, #-1]
    //     0xccf364: and             x16, x17, x16, lsr #2
    //     0xccf368: tst             x16, HEAP, lsr #32
    //     0xccf36c: b.eq            #0xccf374
    //     0xccf370: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xccf374: ldur            x16, [fp, #-0x18]
    // 0xccf378: str             x16, [SP]
    // 0xccf37c: r0 = _interpolate()
    //     0xccf37c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0xccf380: stur            x0, [fp, #-0x10]
    // 0xccf384: r0 = StateError()
    //     0xccf384: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xccf388: mov             x1, x0
    // 0xccf38c: ldur            x0, [fp, #-0x10]
    // 0xccf390: StoreField: r1->field_b = r0
    //     0xccf390: stur            w0, [x1, #0xb]
    // 0xccf394: mov             x0, x1
    // 0xccf398: r0 = Throw()
    //     0xccf398: bl              #0x13ddb2c  ; ThrowStub
    // 0xccf39c: brk             #0
    // 0xccf3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf3a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf3a4: b               #0xccf148
    // 0xccf3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf3a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf3ac: b               #0xccf1c0
  }
  _ RenderAndroidView(/* No info */) {
    // ** addr: 0x11c0fb8, size: 0x224
    // 0x11c0fb8: EnterFrame
    //     0x11c0fb8: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0fbc: mov             fp, SP
    // 0x11c0fc0: AllocStack(0x28)
    //     0x11c0fc0: sub             SP, SP, #0x28
    // 0x11c0fc4: SetupParameters(RenderAndroidView this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* r3 => r0, fp-0x18 */)
    //     0x11c0fc4: mov             x0, x3
    //     0x11c0fc8: stur            x3, [fp, #-0x18]
    //     0x11c0fcc: mov             x3, x2
    //     0x11c0fd0: stur            x1, [fp, #-8]
    //     0x11c0fd4: stur            x2, [fp, #-0x10]
    // 0x11c0fd8: CheckStackOverflow
    //     0x11c0fd8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0fdc: cmp             SP, x16
    //     0x11c0fe0: b.ls            #0x11c11d4
    // 0x11c0fe4: r1 = 1
    //     0x11c0fe4: mov             x1, #1
    // 0x11c0fe8: r0 = AllocateContext()
    //     0x11c0fe8: bl              #0x13de838  ; AllocateContextStub
    // 0x11c0fec: mov             x2, x0
    // 0x11c0ff0: ldur            x0, [fp, #-8]
    // 0x11c0ff4: stur            x2, [fp, #-0x20]
    // 0x11c0ff8: StoreField: r2->field_f = r0
    //     0x11c0ff8: stur            w0, [x2, #0xf]
    // 0x11c0ffc: r1 = Instance__PlatformViewState
    //     0x11c0ffc: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa16c0] Obj!_PlatformViewState@12c4441
    //     0x11c1000: ldr             x1, [x1, #0x6c0]
    // 0x11c1004: StoreField: r0->field_5f = r1
    //     0x11c1004: stur            w1, [x0, #0x5f]
    // 0x11c1008: r1 = false
    //     0x11c1008: add             x1, NULL, #0x30  ; false
    // 0x11c100c: StoreField: r0->field_67 = r1
    //     0x11c100c: stur            w1, [x0, #0x67]
    // 0x11c1010: r1 = <ClipRectLayer>
    //     0x11c1010: add             x1, PP, #0x84, lsl #12  ; [pp+0x84fc8] TypeArguments: <ClipRectLayer>
    //     0x11c1014: ldr             x1, [x1, #0xfc8]
    // 0x11c1018: r0 = LayerHandle()
    //     0x11c1018: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11c101c: ldur            x4, [fp, #-8]
    // 0x11c1020: StoreField: r4->field_73 = r0
    //     0x11c1020: stur            w0, [x4, #0x73]
    //     0x11c1024: ldurb           w16, [x4, #-1]
    //     0x11c1028: ldurb           w17, [x0, #-1]
    //     0x11c102c: and             x16, x17, x16, lsr #2
    //     0x11c1030: tst             x16, HEAP, lsr #32
    //     0x11c1034: b.eq            #0x11c103c
    //     0x11c1038: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11c103c: ldur            x0, [fp, #-0x18]
    // 0x11c1040: StoreField: r4->field_6b = r0
    //     0x11c1040: stur            w0, [x4, #0x6b]
    //     0x11c1044: ldurb           w16, [x4, #-1]
    //     0x11c1048: ldurb           w17, [x0, #-1]
    //     0x11c104c: and             x16, x17, x16, lsr #2
    //     0x11c1050: tst             x16, HEAP, lsr #32
    //     0x11c1054: b.eq            #0x11c105c
    //     0x11c1058: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0x11c105c: r0 = Instance_Clip
    //     0x11c105c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0x11c1060: ldr             x0, [x0, #0x850]
    // 0x11c1064: StoreField: r4->field_6f = r0
    //     0x11c1064: stur            w0, [x4, #0x6f]
    // 0x11c1068: mov             x1, x4
    // 0x11c106c: ldur            x2, [fp, #-0x18]
    // 0x11c1070: ldur            x3, [fp, #-0x10]
    // 0x11c1074: r0 = PlatformViewRenderBox()
    //     0x11c1074: bl              #0x11c143c  ; [package:flutter/src/rendering/platform_view.dart] PlatformViewRenderBox::PlatformViewRenderBox
    // 0x11c1078: ldur            x0, [fp, #-8]
    // 0x11c107c: LoadField: r1 = r0->field_6b
    //     0x11c107c: ldur            w1, [x0, #0x6b]
    // 0x11c1080: DecompressPointer r1
    //     0x11c1080: add             x1, x1, HEAP, lsl #32
    // 0x11c1084: LoadField: r3 = r1->field_13
    //     0x11c1084: ldur            w3, [x1, #0x13]
    // 0x11c1088: DecompressPointer r3
    //     0x11c1088: add             x3, x3, HEAP, lsl #32
    // 0x11c108c: ldur            x2, [fp, #-0x20]
    // 0x11c1090: stur            x3, [fp, #-0x18]
    // 0x11c1094: r1 = Function '<anonymous closure>':.
    //     0x11c1094: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa16c8] AnonymousClosure: (0x11c14e0), in [package:flutter/src/widgets/platform_view.dart] _TextureBasedAndroidViewSurface::createRenderObject (0x11c0f04)
    //     0x11c1098: ldr             x1, [x1, #0x6c8]
    // 0x11c109c: r0 = AllocateClosure()
    //     0x11c109c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11c10a0: ldur            x1, [fp, #-0x18]
    // 0x11c10a4: StoreField: r1->field_13 = r0
    //     0x11c10a4: stur            w0, [x1, #0x13]
    //     0x11c10a8: ldurb           w16, [x1, #-1]
    //     0x11c10ac: ldurb           w17, [x0, #-1]
    //     0x11c10b0: and             x16, x17, x16, lsr #2
    //     0x11c10b4: tst             x16, HEAP, lsr #32
    //     0x11c10b8: b.eq            #0x11c10c0
    //     0x11c10bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11c10c0: ldur            x1, [fp, #-8]
    // 0x11c10c4: ldur            x2, [fp, #-0x10]
    // 0x11c10c8: r0 = updateGestureRecognizers()
    //     0x11c10c8: bl              #0xce3b28  ; [package:flutter/src/rendering/platform_view.dart] PlatformViewRenderBox::updateGestureRecognizers
    // 0x11c10cc: ldur            x0, [fp, #-8]
    // 0x11c10d0: LoadField: r1 = r0->field_6b
    //     0x11c10d0: ldur            w1, [x0, #0x6b]
    // 0x11c10d4: DecompressPointer r1
    //     0x11c10d4: add             x1, x1, HEAP, lsl #32
    // 0x11c10d8: LoadField: r3 = r1->field_23
    //     0x11c10d8: ldur            w3, [x1, #0x23]
    // 0x11c10dc: DecompressPointer r3
    //     0x11c10dc: add             x3, x3, HEAP, lsl #32
    // 0x11c10e0: stur            x3, [fp, #-0x18]
    // 0x11c10e4: LoadField: r4 = r3->field_7
    //     0x11c10e4: ldur            w4, [x3, #7]
    // 0x11c10e8: DecompressPointer r4
    //     0x11c10e8: add             x4, x4, HEAP, lsl #32
    // 0x11c10ec: mov             x2, x0
    // 0x11c10f0: stur            x4, [fp, #-0x10]
    // 0x11c10f4: r1 = Function '_onPlatformViewCreated@300508051':.
    //     0x11c10f4: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa16d0] AnonymousClosure: (0xc036fc), of [package:flutter/src/rendering/platform_view.dart] RenderAndroidView
    //     0x11c10f8: ldr             x1, [x1, #0x6d0]
    // 0x11c10fc: r0 = AllocateClosure()
    //     0x11c10fc: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11c1100: ldur            x2, [fp, #-0x10]
    // 0x11c1104: mov             x3, x0
    // 0x11c1108: r1 = Null
    //     0x11c1108: mov             x1, NULL
    // 0x11c110c: stur            x3, [fp, #-0x10]
    // 0x11c1110: cmp             w2, NULL
    // 0x11c1114: b.eq            #0x11c1134
    // 0x11c1118: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x11c1118: ldur            w4, [x2, #0x17]
    // 0x11c111c: DecompressPointer r4
    //     0x11c111c: add             x4, x4, HEAP, lsl #32
    // 0x11c1120: r8 = X0
    //     0x11c1120: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x11c1124: LoadField: r9 = r4->field_7
    //     0x11c1124: ldur            x9, [x4, #7]
    // 0x11c1128: r3 = Null
    //     0x11c1128: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa16d8] Null
    //     0x11c112c: ldr             x3, [x3, #0x6d8]
    // 0x11c1130: blr             x9
    // 0x11c1134: ldur            x0, [fp, #-0x18]
    // 0x11c1138: LoadField: r1 = r0->field_b
    //     0x11c1138: ldur            w1, [x0, #0xb]
    // 0x11c113c: LoadField: r2 = r0->field_f
    //     0x11c113c: ldur            w2, [x0, #0xf]
    // 0x11c1140: DecompressPointer r2
    //     0x11c1140: add             x2, x2, HEAP, lsl #32
    // 0x11c1144: LoadField: r3 = r2->field_b
    //     0x11c1144: ldur            w3, [x2, #0xb]
    // 0x11c1148: r2 = LoadInt32Instr(r1)
    //     0x11c1148: sbfx            x2, x1, #1, #0x1f
    // 0x11c114c: stur            x2, [fp, #-0x28]
    // 0x11c1150: r1 = LoadInt32Instr(r3)
    //     0x11c1150: sbfx            x1, x3, #1, #0x1f
    // 0x11c1154: cmp             x2, x1
    // 0x11c1158: b.ne            #0x11c1164
    // 0x11c115c: mov             x1, x0
    // 0x11c1160: r0 = _growToNextCapacity()
    //     0x11c1160: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11c1164: ldur            x0, [fp, #-0x18]
    // 0x11c1168: ldur            x2, [fp, #-0x28]
    // 0x11c116c: add             x1, x2, #1
    // 0x11c1170: lsl             x3, x1, #1
    // 0x11c1174: StoreField: r0->field_b = r3
    //     0x11c1174: stur            w3, [x0, #0xb]
    // 0x11c1178: LoadField: r1 = r0->field_f
    //     0x11c1178: ldur            w1, [x0, #0xf]
    // 0x11c117c: DecompressPointer r1
    //     0x11c117c: add             x1, x1, HEAP, lsl #32
    // 0x11c1180: ldur            x0, [fp, #-0x10]
    // 0x11c1184: ArrayStore: r1[r2] = r0  ; List_4
    //     0x11c1184: add             x25, x1, x2, lsl #2
    //     0x11c1188: add             x25, x25, #0xf
    //     0x11c118c: str             w0, [x25]
    //     0x11c1190: tbz             w0, #0, #0x11c11ac
    //     0x11c1194: ldurb           w16, [x1, #-1]
    //     0x11c1198: ldurb           w17, [x0, #-1]
    //     0x11c119c: and             x16, x17, x16, lsr #2
    //     0x11c11a0: tst             x16, HEAP, lsr #32
    //     0x11c11a4: b.eq            #0x11c11ac
    //     0x11c11a8: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11c11ac: ldur            x1, [fp, #-8]
    // 0x11c11b0: r2 = Instance_PlatformViewHitTestBehavior
    //     0x11c11b0: add             x2, PP, #0x7d, lsl #12  ; [pp+0x7d428] Obj!PlatformViewHitTestBehavior@12c4481
    //     0x11c11b4: ldr             x2, [x2, #0x428]
    // 0x11c11b8: r0 = hitTestBehavior=()
    //     0x11c11b8: bl              #0xce429c  ; [dart:mixin_deduplication] _MixinApplication440&RenderBox&_PlatformViewGestureMixin::hitTestBehavior=
    // 0x11c11bc: ldur            x1, [fp, #-8]
    // 0x11c11c0: r0 = _setOffset()
    //     0x11c11c0: bl              #0x11c11dc  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_setOffset
    // 0x11c11c4: r0 = Null
    //     0x11c11c4: mov             x0, NULL
    // 0x11c11c8: LeaveFrame
    //     0x11c11c8: mov             SP, fp
    //     0x11c11cc: ldp             fp, lr, [SP], #0x10
    // 0x11c11d0: ret
    //     0x11c11d0: ret             
    // 0x11c11d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c11d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c11d8: b               #0x11c0fe4
  }
  _ _setOffset(/* No info */) {
    // ** addr: 0x11c11dc, size: 0x130
    // 0x11c11dc: EnterFrame
    //     0x11c11dc: stp             fp, lr, [SP, #-0x10]!
    //     0x11c11e0: mov             fp, SP
    // 0x11c11e4: AllocStack(0x18)
    //     0x11c11e4: sub             SP, SP, #0x18
    // 0x11c11e8: SetupParameters(RenderAndroidView this /* r1 => r1, fp-0x8 */)
    //     0x11c11e8: stur            x1, [fp, #-8]
    // 0x11c11ec: CheckStackOverflow
    //     0x11c11ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c11f0: cmp             SP, x16
    //     0x11c11f4: b.ls            #0x11c1300
    // 0x11c11f8: r1 = 1
    //     0x11c11f8: mov             x1, #1
    // 0x11c11fc: r0 = AllocateContext()
    //     0x11c11fc: bl              #0x13de838  ; AllocateContextStub
    // 0x11c1200: mov             x1, x0
    // 0x11c1204: ldur            x0, [fp, #-8]
    // 0x11c1208: StoreField: r1->field_f = r0
    //     0x11c1208: stur            w0, [x1, #0xf]
    // 0x11c120c: r0 = LoadStaticField(0x5e4)
    //     0x11c120c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0x11c1210: ldr             x0, [x0, #0xbc8]
    // 0x11c1214: cmp             w0, NULL
    // 0x11c1218: b.eq            #0x11c1308
    // 0x11c121c: LoadField: r3 = r0->field_53
    //     0x11c121c: ldur            w3, [x0, #0x53]
    // 0x11c1220: DecompressPointer r3
    //     0x11c1220: add             x3, x3, HEAP, lsl #32
    // 0x11c1224: stur            x3, [fp, #-0x10]
    // 0x11c1228: LoadField: r0 = r3->field_7
    //     0x11c1228: ldur            w0, [x3, #7]
    // 0x11c122c: DecompressPointer r0
    //     0x11c122c: add             x0, x0, HEAP, lsl #32
    // 0x11c1230: mov             x2, x1
    // 0x11c1234: stur            x0, [fp, #-8]
    // 0x11c1238: r1 = Function '<anonymous closure>':.
    //     0x11c1238: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa16e8] AnonymousClosure: (0x11c130c), in [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_setOffset (0x11c11dc)
    //     0x11c123c: ldr             x1, [x1, #0x6e8]
    // 0x11c1240: r0 = AllocateClosure()
    //     0x11c1240: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11c1244: ldur            x2, [fp, #-8]
    // 0x11c1248: mov             x3, x0
    // 0x11c124c: r1 = Null
    //     0x11c124c: mov             x1, NULL
    // 0x11c1250: stur            x3, [fp, #-8]
    // 0x11c1254: cmp             w2, NULL
    // 0x11c1258: b.eq            #0x11c1278
    // 0x11c125c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x11c125c: ldur            w4, [x2, #0x17]
    // 0x11c1260: DecompressPointer r4
    //     0x11c1260: add             x4, x4, HEAP, lsl #32
    // 0x11c1264: r8 = X0
    //     0x11c1264: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x11c1268: LoadField: r9 = r4->field_7
    //     0x11c1268: ldur            x9, [x4, #7]
    // 0x11c126c: r3 = Null
    //     0x11c126c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa16f0] Null
    //     0x11c1270: ldr             x3, [x3, #0x6f0]
    // 0x11c1274: blr             x9
    // 0x11c1278: ldur            x0, [fp, #-0x10]
    // 0x11c127c: LoadField: r1 = r0->field_b
    //     0x11c127c: ldur            w1, [x0, #0xb]
    // 0x11c1280: LoadField: r2 = r0->field_f
    //     0x11c1280: ldur            w2, [x0, #0xf]
    // 0x11c1284: DecompressPointer r2
    //     0x11c1284: add             x2, x2, HEAP, lsl #32
    // 0x11c1288: LoadField: r3 = r2->field_b
    //     0x11c1288: ldur            w3, [x2, #0xb]
    // 0x11c128c: r2 = LoadInt32Instr(r1)
    //     0x11c128c: sbfx            x2, x1, #1, #0x1f
    // 0x11c1290: stur            x2, [fp, #-0x18]
    // 0x11c1294: r1 = LoadInt32Instr(r3)
    //     0x11c1294: sbfx            x1, x3, #1, #0x1f
    // 0x11c1298: cmp             x2, x1
    // 0x11c129c: b.ne            #0x11c12a8
    // 0x11c12a0: mov             x1, x0
    // 0x11c12a4: r0 = _growToNextCapacity()
    //     0x11c12a4: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x11c12a8: ldur            x2, [fp, #-0x10]
    // 0x11c12ac: ldur            x3, [fp, #-0x18]
    // 0x11c12b0: add             x4, x3, #1
    // 0x11c12b4: lsl             x5, x4, #1
    // 0x11c12b8: StoreField: r2->field_b = r5
    //     0x11c12b8: stur            w5, [x2, #0xb]
    // 0x11c12bc: LoadField: r1 = r2->field_f
    //     0x11c12bc: ldur            w1, [x2, #0xf]
    // 0x11c12c0: DecompressPointer r1
    //     0x11c12c0: add             x1, x1, HEAP, lsl #32
    // 0x11c12c4: ldur            x0, [fp, #-8]
    // 0x11c12c8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x11c12c8: add             x25, x1, x3, lsl #2
    //     0x11c12cc: add             x25, x25, #0xf
    //     0x11c12d0: str             w0, [x25]
    //     0x11c12d4: tbz             w0, #0, #0x11c12f0
    //     0x11c12d8: ldurb           w16, [x1, #-1]
    //     0x11c12dc: ldurb           w17, [x0, #-1]
    //     0x11c12e0: and             x16, x17, x16, lsr #2
    //     0x11c12e4: tst             x16, HEAP, lsr #32
    //     0x11c12e8: b.eq            #0x11c12f0
    //     0x11c12ec: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11c12f0: r0 = Null
    //     0x11c12f0: mov             x0, NULL
    // 0x11c12f4: LeaveFrame
    //     0x11c12f4: mov             SP, fp
    //     0x11c12f8: ldp             fp, lr, [SP], #0x10
    // 0x11c12fc: ret
    //     0x11c12fc: ret             
    // 0x11c1300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c1300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c1304: b               #0x11c11f8
    // 0x11c1308: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11c1308: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, Duration) async {
    // ** addr: 0x11c130c, size: 0x130
    // 0x11c130c: EnterFrame
    //     0x11c130c: stp             fp, lr, [SP, #-0x10]!
    //     0x11c1310: mov             fp, SP
    // 0x11c1314: AllocStack(0x18)
    //     0x11c1314: sub             SP, SP, #0x18
    // 0x11c1318: SetupParameters(RenderAndroidView this /* r1 */)
    //     0x11c1318: stur            NULL, [fp, #-8]
    //     0x11c131c: mov             x0, #0
    //     0x11c1320: add             x1, fp, w0, sxtw #2
    //     0x11c1324: ldr             x1, [x1, #0x18]
    //     0x11c1328: ldur            w2, [x1, #0x17]
    //     0x11c132c: add             x2, x2, HEAP, lsl #32
    //     0x11c1330: stur            x2, [fp, #-0x10]
    // 0x11c1334: CheckStackOverflow
    //     0x11c1334: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c1338: cmp             SP, x16
    //     0x11c133c: b.ls            #0x11c1434
    // 0x11c1340: InitAsync() -> Future<void?>
    //     0x11c1340: ldr             x0, [PP, #0x2b8]  ; [pp+0x2b8] TypeArguments: <void?>
    //     0x11c1344: bl              #0x7f5e44  ; InitAsyncStub
    // 0x11c1348: ldur            x0, [fp, #-0x10]
    // 0x11c134c: LoadField: r1 = r0->field_f
    //     0x11c134c: ldur            w1, [x0, #0xf]
    // 0x11c1350: DecompressPointer r1
    //     0x11c1350: add             x1, x1, HEAP, lsl #32
    // 0x11c1354: LoadField: r2 = r1->field_67
    //     0x11c1354: ldur            w2, [x1, #0x67]
    // 0x11c1358: DecompressPointer r2
    //     0x11c1358: add             x2, x2, HEAP, lsl #32
    // 0x11c135c: tbz             w2, #4, #0x11c1400
    // 0x11c1360: ArrayLoad: r2 = r1[0]  ; List_4
    //     0x11c1360: ldur            w2, [x1, #0x17]
    // 0x11c1364: DecompressPointer r2
    //     0x11c1364: add             x2, x2, HEAP, lsl #32
    // 0x11c1368: cmp             w2, NULL
    // 0x11c136c: b.eq            #0x11c13f0
    // 0x11c1370: LoadField: r3 = r1->field_6b
    //     0x11c1370: ldur            w3, [x1, #0x6b]
    // 0x11c1374: DecompressPointer r3
    //     0x11c1374: add             x3, x3, HEAP, lsl #32
    // 0x11c1378: stur            x3, [fp, #-0x18]
    // 0x11c137c: r2 = Instance_Offset
    //     0x11c137c: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11c1380: r4 = const [0, 0x2, 0, 0x2, null]
    //     0x11c1380: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0x11c1384: r0 = localToGlobal()
    //     0x11c1384: bl              #0x856eb0  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x11c1388: mov             x1, x0
    // 0x11c138c: ldur            x0, [fp, #-0x18]
    // 0x11c1390: r2 = LoadClassIdInstr(r0)
    //     0x11c1390: ldur            x2, [x0, #-1]
    //     0x11c1394: ubfx            x2, x2, #0xc, #0x14
    // 0x11c1398: cmp             x2, #0xacc
    // 0x11c139c: b.eq            #0x11c1408
    // 0x11c13a0: LoadField: r2 = r0->field_27
    //     0x11c13a0: ldur            w2, [x0, #0x27]
    // 0x11c13a4: DecompressPointer r2
    //     0x11c13a4: add             x2, x2, HEAP, lsl #32
    // 0x11c13a8: LoadField: r3 = r0->field_7
    //     0x11c13a8: ldur            x3, [x0, #7]
    // 0x11c13ac: LoadField: r5 = r0->field_1b
    //     0x11c13ac: ldur            w5, [x0, #0x1b]
    // 0x11c13b0: DecompressPointer r5
    //     0x11c13b0: add             x5, x5, HEAP, lsl #32
    // 0x11c13b4: r0 = LoadClassIdInstr(r2)
    //     0x11c13b4: ldur            x0, [x2, #-1]
    //     0x11c13b8: ubfx            x0, x0, #0xc, #0x14
    // 0x11c13bc: cmp             x0, #0xac8
    // 0x11c13c0: b.eq            #0x11c1414
    // 0x11c13c4: r0 = LoadClassIdInstr(r2)
    //     0x11c13c4: ldur            x0, [x2, #-1]
    //     0x11c13c8: ubfx            x0, x0, #0xc, #0x14
    // 0x11c13cc: mov             x16, x1
    // 0x11c13d0: mov             x1, x2
    // 0x11c13d4: mov             x2, x16
    // 0x11c13d8: r0 = GDT[cid_x0 + -0xffe]()
    //     0x11c13d8: sub             lr, x0, #0xffe
    //     0x11c13dc: ldr             lr, [x21, lr, lsl #3]
    //     0x11c13e0: blr             lr
    // 0x11c13e4: mov             x1, x0
    // 0x11c13e8: stur            x1, [fp, #-0x18]
    // 0x11c13ec: r0 = Await()
    //     0x11c13ec: bl              #0x7f5c00  ; AwaitStub
    // 0x11c13f0: ldur            x0, [fp, #-0x10]
    // 0x11c13f4: LoadField: r1 = r0->field_f
    //     0x11c13f4: ldur            w1, [x0, #0xf]
    // 0x11c13f8: DecompressPointer r1
    //     0x11c13f8: add             x1, x1, HEAP, lsl #32
    // 0x11c13fc: r0 = _setOffset()
    //     0x11c13fc: bl              #0x11c11dc  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_setOffset
    // 0x11c1400: r0 = Null
    //     0x11c1400: mov             x0, NULL
    // 0x11c1404: r0 = ReturnAsyncNotFuture()
    //     0x11c1404: b               #0x7f592c  ; ReturnAsyncNotFutureStub
    // 0x11c1408: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x11c1408: ldr             x0, [PP, #0x158]  ; [pp+0x158] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x11c140c: r0 = Throw()
    //     0x11c140c: bl              #0x13ddb2c  ; ThrowStub
    // 0x11c1410: brk             #0
    // 0x11c1414: r0 = UnimplementedError()
    //     0x11c1414: bl              #0x7dd7c4  ; AllocateUnimplementedErrorStub -> UnimplementedError (size=0x10)
    // 0x11c1418: mov             x1, x0
    // 0x11c141c: r0 = "Not supported for hybrid composition."
    //     0x11c141c: add             x0, PP, #0xa1, lsl #12  ; [pp+0xa1700] "Not supported for hybrid composition."
    //     0x11c1420: ldr             x0, [x0, #0x700]
    // 0x11c1424: StoreField: r1->field_b = r0
    //     0x11c1424: stur            w0, [x1, #0xb]
    // 0x11c1428: mov             x0, x1
    // 0x11c142c: r0 = Throw()
    //     0x11c142c: bl              #0x13ddb2c  ; ThrowStub
    // 0x11c1430: brk             #0
    // 0x11c1434: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c1434: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c1438: b               #0x11c1340
  }
  set _ controller=(/* No info */) {
    // ** addr: 0x1233420, size: 0x204
    // 0x1233420: EnterFrame
    //     0x1233420: stp             fp, lr, [SP, #-0x10]!
    //     0x1233424: mov             fp, SP
    // 0x1233428: AllocStack(0x30)
    //     0x1233428: sub             SP, SP, #0x30
    // 0x123342c: SetupParameters(RenderAndroidView this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x123342c: mov             x0, x1
    //     0x1233430: stur            x1, [fp, #-8]
    //     0x1233434: stur            x2, [fp, #-0x10]
    // 0x1233438: CheckStackOverflow
    //     0x1233438: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x123343c: cmp             SP, x16
    //     0x1233440: b.ls            #0x123361c
    // 0x1233444: r1 = 1
    //     0x1233444: mov             x1, #1
    // 0x1233448: r0 = AllocateContext()
    //     0x1233448: bl              #0x13de838  ; AllocateContextStub
    // 0x123344c: mov             x3, x0
    // 0x1233450: ldur            x0, [fp, #-8]
    // 0x1233454: stur            x3, [fp, #-0x20]
    // 0x1233458: StoreField: r3->field_f = r0
    //     0x1233458: stur            w0, [x3, #0xf]
    // 0x123345c: LoadField: r4 = r0->field_6b
    //     0x123345c: ldur            w4, [x0, #0x6b]
    // 0x1233460: DecompressPointer r4
    //     0x1233460: add             x4, x4, HEAP, lsl #32
    // 0x1233464: ldur            x5, [fp, #-0x10]
    // 0x1233468: stur            x4, [fp, #-0x18]
    // 0x123346c: cmp             w4, w5
    // 0x1233470: b.ne            #0x1233484
    // 0x1233474: r0 = Null
    //     0x1233474: mov             x0, NULL
    // 0x1233478: LeaveFrame
    //     0x1233478: mov             SP, fp
    //     0x123347c: ldp             fp, lr, [SP], #0x10
    // 0x1233480: ret
    //     0x1233480: ret             
    // 0x1233484: mov             x2, x0
    // 0x1233488: r1 = Function '_onPlatformViewCreated@300508051':.
    //     0x1233488: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa16d0] AnonymousClosure: (0xc036fc), of [package:flutter/src/rendering/platform_view.dart] RenderAndroidView
    //     0x123348c: ldr             x1, [x1, #0x6d0]
    // 0x1233490: r0 = AllocateClosure()
    //     0x1233490: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x1233494: ldur            x1, [fp, #-0x18]
    // 0x1233498: mov             x2, x0
    // 0x123349c: stur            x0, [fp, #-0x18]
    // 0x12334a0: r0 = removeOnPlatformViewCreatedListener()
    //     0x12334a0: bl              #0xc036c0  ; [package:flutter/src/services/platform_views.dart] AndroidViewController::removeOnPlatformViewCreatedListener
    // 0x12334a4: ldur            x1, [fp, #-8]
    // 0x12334a8: ldur            x2, [fp, #-0x10]
    // 0x12334ac: r0 = controller=()
    //     0x12334ac: bl              #0x1233624  ; [package:flutter/src/rendering/platform_view.dart] PlatformViewRenderBox::controller=
    // 0x12334b0: ldur            x0, [fp, #-0x10]
    // 0x12334b4: ldur            x3, [fp, #-8]
    // 0x12334b8: StoreField: r3->field_6b = r0
    //     0x12334b8: stur            w0, [x3, #0x6b]
    //     0x12334bc: ldurb           w16, [x3, #-1]
    //     0x12334c0: ldurb           w17, [x0, #-1]
    //     0x12334c4: and             x16, x17, x16, lsr #2
    //     0x12334c8: tst             x16, HEAP, lsr #32
    //     0x12334cc: b.eq            #0x12334d4
    //     0x12334d0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x12334d4: ldur            x0, [fp, #-0x10]
    // 0x12334d8: LoadField: r4 = r0->field_13
    //     0x12334d8: ldur            w4, [x0, #0x13]
    // 0x12334dc: DecompressPointer r4
    //     0x12334dc: add             x4, x4, HEAP, lsl #32
    // 0x12334e0: ldur            x2, [fp, #-0x20]
    // 0x12334e4: stur            x4, [fp, #-0x28]
    // 0x12334e8: r1 = Function '<anonymous closure>':.
    //     0x12334e8: add             x1, PP, #0xac, lsl #12  ; [pp+0xacbf0] AnonymousClosure: (0x11c14e0), in [package:flutter/src/widgets/platform_view.dart] _TextureBasedAndroidViewSurface::createRenderObject (0x11c0f04)
    //     0x12334ec: ldr             x1, [x1, #0xbf0]
    // 0x12334f0: r0 = AllocateClosure()
    //     0x12334f0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x12334f4: ldur            x1, [fp, #-0x28]
    // 0x12334f8: StoreField: r1->field_13 = r0
    //     0x12334f8: stur            w0, [x1, #0x13]
    //     0x12334fc: ldurb           w16, [x1, #-1]
    //     0x1233500: ldurb           w17, [x0, #-1]
    //     0x1233504: and             x16, x17, x16, lsr #2
    //     0x1233508: tst             x16, HEAP, lsr #32
    //     0x123350c: b.eq            #0x1233514
    //     0x1233510: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1233514: ldur            x1, [fp, #-8]
    // 0x1233518: r0 = _sizePlatformView()
    //     0x1233518: bl              #0xccf128  ; [package:flutter/src/rendering/platform_view.dart] RenderAndroidView::_sizePlatformView
    // 0x123351c: ldur            x0, [fp, #-8]
    // 0x1233520: LoadField: r1 = r0->field_6b
    //     0x1233520: ldur            w1, [x0, #0x6b]
    // 0x1233524: DecompressPointer r1
    //     0x1233524: add             x1, x1, HEAP, lsl #32
    // 0x1233528: LoadField: r2 = r1->field_1b
    //     0x1233528: ldur            w2, [x1, #0x1b]
    // 0x123352c: DecompressPointer r2
    //     0x123352c: add             x2, x2, HEAP, lsl #32
    // 0x1233530: r16 = Instance__AndroidViewState
    //     0x1233530: add             x16, PP, #0x7d, lsl #12  ; [pp+0x7d3a8] Obj!_AndroidViewState@12c3d61
    //     0x1233534: ldr             x16, [x16, #0x3a8]
    // 0x1233538: cmp             w2, w16
    // 0x123353c: b.ne            #0x1233548
    // 0x1233540: mov             x1, x0
    // 0x1233544: r0 = markNeedsSemanticsUpdate()
    //     0x1233544: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x1233548: ldur            x0, [fp, #-8]
    // 0x123354c: LoadField: r1 = r0->field_6b
    //     0x123354c: ldur            w1, [x0, #0x6b]
    // 0x1233550: DecompressPointer r1
    //     0x1233550: add             x1, x1, HEAP, lsl #32
    // 0x1233554: LoadField: r3 = r1->field_23
    //     0x1233554: ldur            w3, [x1, #0x23]
    // 0x1233558: DecompressPointer r3
    //     0x1233558: add             x3, x3, HEAP, lsl #32
    // 0x123355c: stur            x3, [fp, #-8]
    // 0x1233560: LoadField: r2 = r3->field_7
    //     0x1233560: ldur            w2, [x3, #7]
    // 0x1233564: DecompressPointer r2
    //     0x1233564: add             x2, x2, HEAP, lsl #32
    // 0x1233568: ldur            x0, [fp, #-0x18]
    // 0x123356c: r1 = Null
    //     0x123356c: mov             x1, NULL
    // 0x1233570: cmp             w2, NULL
    // 0x1233574: b.eq            #0x1233594
    // 0x1233578: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1233578: ldur            w4, [x2, #0x17]
    // 0x123357c: DecompressPointer r4
    //     0x123357c: add             x4, x4, HEAP, lsl #32
    // 0x1233580: r8 = X0
    //     0x1233580: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1233584: LoadField: r9 = r4->field_7
    //     0x1233584: ldur            x9, [x4, #7]
    // 0x1233588: r3 = Null
    //     0x1233588: add             x3, PP, #0xac, lsl #12  ; [pp+0xacbf8] Null
    //     0x123358c: ldr             x3, [x3, #0xbf8]
    // 0x1233590: blr             x9
    // 0x1233594: ldur            x0, [fp, #-8]
    // 0x1233598: LoadField: r1 = r0->field_b
    //     0x1233598: ldur            w1, [x0, #0xb]
    // 0x123359c: LoadField: r2 = r0->field_f
    //     0x123359c: ldur            w2, [x0, #0xf]
    // 0x12335a0: DecompressPointer r2
    //     0x12335a0: add             x2, x2, HEAP, lsl #32
    // 0x12335a4: LoadField: r3 = r2->field_b
    //     0x12335a4: ldur            w3, [x2, #0xb]
    // 0x12335a8: r2 = LoadInt32Instr(r1)
    //     0x12335a8: sbfx            x2, x1, #1, #0x1f
    // 0x12335ac: stur            x2, [fp, #-0x30]
    // 0x12335b0: r1 = LoadInt32Instr(r3)
    //     0x12335b0: sbfx            x1, x3, #1, #0x1f
    // 0x12335b4: cmp             x2, x1
    // 0x12335b8: b.ne            #0x12335c4
    // 0x12335bc: mov             x1, x0
    // 0x12335c0: r0 = _growToNextCapacity()
    //     0x12335c0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x12335c4: ldur            x2, [fp, #-8]
    // 0x12335c8: ldur            x3, [fp, #-0x30]
    // 0x12335cc: add             x4, x3, #1
    // 0x12335d0: lsl             x5, x4, #1
    // 0x12335d4: StoreField: r2->field_b = r5
    //     0x12335d4: stur            w5, [x2, #0xb]
    // 0x12335d8: LoadField: r1 = r2->field_f
    //     0x12335d8: ldur            w1, [x2, #0xf]
    // 0x12335dc: DecompressPointer r1
    //     0x12335dc: add             x1, x1, HEAP, lsl #32
    // 0x12335e0: ldur            x0, [fp, #-0x18]
    // 0x12335e4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x12335e4: add             x25, x1, x3, lsl #2
    //     0x12335e8: add             x25, x25, #0xf
    //     0x12335ec: str             w0, [x25]
    //     0x12335f0: tbz             w0, #0, #0x123360c
    //     0x12335f4: ldurb           w16, [x1, #-1]
    //     0x12335f8: ldurb           w17, [x0, #-1]
    //     0x12335fc: and             x16, x17, x16, lsr #2
    //     0x1233600: tst             x16, HEAP, lsr #32
    //     0x1233604: b.eq            #0x123360c
    //     0x1233608: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x123360c: r0 = Null
    //     0x123360c: mov             x0, NULL
    // 0x1233610: LeaveFrame
    //     0x1233610: mov             SP, fp
    //     0x1233614: ldp             fp, lr, [SP], #0x10
    // 0x1233618: ret
    //     0x1233618: ret             
    // 0x123361c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x123361c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1233620: b               #0x1233444
  }
}

// class id: 4810, size: 0x50, field offset: 0x50
abstract class _PlatformViewGestureMixin extends RenderBox
    implements MouseTrackerAnnotation {
}

// class id: 8231, size: 0x14, field offset: 0x14
enum _PlatformViewState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aafd0, size: 0x64
    // 0x11aafd0: EnterFrame
    //     0x11aafd0: stp             fp, lr, [SP, #-0x10]!
    //     0x11aafd4: mov             fp, SP
    // 0x11aafd8: AllocStack(0x10)
    //     0x11aafd8: sub             SP, SP, #0x10
    // 0x11aafdc: SetupParameters(_PlatformViewState this /* r1 => r0, fp-0x8 */)
    //     0x11aafdc: mov             x0, x1
    //     0x11aafe0: stur            x1, [fp, #-8]
    // 0x11aafe4: CheckStackOverflow
    //     0x11aafe4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aafe8: cmp             SP, x16
    //     0x11aafec: b.ls            #0x11ab02c
    // 0x11aaff0: r1 = Null
    //     0x11aaff0: mov             x1, NULL
    // 0x11aaff4: r2 = 4
    //     0x11aaff4: mov             x2, #4
    // 0x11aaff8: r0 = AllocateArray()
    //     0x11aaff8: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aaffc: r16 = "_PlatformViewState."
    //     0x11aaffc: add             x16, PP, #0xac, lsl #12  ; [pp+0xacc08] "_PlatformViewState."
    //     0x11ab000: ldr             x16, [x16, #0xc08]
    // 0x11ab004: StoreField: r0->field_f = r16
    //     0x11ab004: stur            w16, [x0, #0xf]
    // 0x11ab008: ldur            x1, [fp, #-8]
    // 0x11ab00c: LoadField: r2 = r1->field_f
    //     0x11ab00c: ldur            w2, [x1, #0xf]
    // 0x11ab010: DecompressPointer r2
    //     0x11ab010: add             x2, x2, HEAP, lsl #32
    // 0x11ab014: StoreField: r0->field_13 = r2
    //     0x11ab014: stur            w2, [x0, #0x13]
    // 0x11ab018: str             x0, [SP]
    // 0x11ab01c: r0 = _interpolate()
    //     0x11ab01c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab020: LeaveFrame
    //     0x11ab020: mov             SP, fp
    //     0x11ab024: ldp             fp, lr, [SP], #0x10
    // 0x11ab028: ret
    //     0x11ab028: ret             
    // 0x11ab02c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab02c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab030: b               #0x11aaff0
  }
}

// class id: 8232, size: 0x14, field offset: 0x14
enum PlatformViewHitTestBehavior extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aaf6c, size: 0x64
    // 0x11aaf6c: EnterFrame
    //     0x11aaf6c: stp             fp, lr, [SP, #-0x10]!
    //     0x11aaf70: mov             fp, SP
    // 0x11aaf74: AllocStack(0x10)
    //     0x11aaf74: sub             SP, SP, #0x10
    // 0x11aaf78: SetupParameters(PlatformViewHitTestBehavior this /* r1 => r0, fp-0x8 */)
    //     0x11aaf78: mov             x0, x1
    //     0x11aaf7c: stur            x1, [fp, #-8]
    // 0x11aaf80: CheckStackOverflow
    //     0x11aaf80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aaf84: cmp             SP, x16
    //     0x11aaf88: b.ls            #0x11aafc8
    // 0x11aaf8c: r1 = Null
    //     0x11aaf8c: mov             x1, NULL
    // 0x11aaf90: r2 = 4
    //     0x11aaf90: mov             x2, #4
    // 0x11aaf94: r0 = AllocateArray()
    //     0x11aaf94: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aaf98: r16 = "PlatformViewHitTestBehavior."
    //     0x11aaf98: add             x16, PP, #0x8e, lsl #12  ; [pp+0x8e710] "PlatformViewHitTestBehavior."
    //     0x11aaf9c: ldr             x16, [x16, #0x710]
    // 0x11aafa0: StoreField: r0->field_f = r16
    //     0x11aafa0: stur            w16, [x0, #0xf]
    // 0x11aafa4: ldur            x1, [fp, #-8]
    // 0x11aafa8: LoadField: r2 = r1->field_f
    //     0x11aafa8: ldur            w2, [x1, #0xf]
    // 0x11aafac: DecompressPointer r2
    //     0x11aafac: add             x2, x2, HEAP, lsl #32
    // 0x11aafb0: StoreField: r0->field_13 = r2
    //     0x11aafb0: stur            w2, [x0, #0x13]
    // 0x11aafb4: str             x0, [SP]
    // 0x11aafb8: r0 = _interpolate()
    //     0x11aafb8: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aafbc: LeaveFrame
    //     0x11aafbc: mov             SP, fp
    //     0x11aafc0: ldp             fp, lr, [SP], #0x10
    // 0x11aafc4: ret
    //     0x11aafc4: ret             
    // 0x11aafc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aafc8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aafcc: b               #0x11aaf8c
  }
}
