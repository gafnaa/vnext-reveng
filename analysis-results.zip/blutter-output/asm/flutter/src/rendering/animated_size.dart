// lib: , url: package:flutter/src/rendering/animated_size.dart

// class id: 1049019, size: 0x8
class :: {
}

// class id: 4887, size: 0x8c, field offset: 0x60
class RenderAnimatedSize extends RenderAligningShiftedBox {

  late final AnimationController _controller; // offset: 0x60
  late final CurvedAnimation _animation; // offset: 0x64
  late bool _hasVisualOverflow; // offset: 0x6c
  late Size _currentSize; // offset: 0x84

  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4d2a4, size: 0x1f8
    // 0xb4d2a4: EnterFrame
    //     0xb4d2a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d2a8: mov             fp, SP
    // 0xb4d2ac: AllocStack(0x28)
    //     0xb4d2ac: sub             SP, SP, #0x28
    // 0xb4d2b0: SetupParameters(RenderAnimatedSize this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xb4d2b0: mov             x3, x1
    //     0xb4d2b4: mov             x0, x2
    //     0xb4d2b8: stur            x1, [fp, #-8]
    //     0xb4d2bc: stur            x2, [fp, #-0x10]
    // 0xb4d2c0: CheckStackOverflow
    //     0xb4d2c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d2c4: cmp             SP, x16
    //     0xb4d2c8: b.ls            #0xb4d470
    // 0xb4d2cc: LoadField: r1 = r3->field_4f
    //     0xb4d2cc: ldur            w1, [x3, #0x4f]
    // 0xb4d2d0: DecompressPointer r1
    //     0xb4d2d0: add             x1, x1, HEAP, lsl #32
    // 0xb4d2d4: cmp             w1, NULL
    // 0xb4d2d8: b.eq            #0xb4d2fc
    // 0xb4d2dc: LoadField: d0 = r0->field_7
    //     0xb4d2dc: ldur            d0, [x0, #7]
    // 0xb4d2e0: LoadField: d1 = r0->field_f
    //     0xb4d2e0: ldur            d1, [x0, #0xf]
    // 0xb4d2e4: fcmp            d0, d1
    // 0xb4d2e8: b.lt            #0xb4d310
    // 0xb4d2ec: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xb4d2ec: ldur            d0, [x0, #0x17]
    // 0xb4d2f0: LoadField: d1 = r0->field_1f
    //     0xb4d2f0: ldur            d1, [x0, #0x1f]
    // 0xb4d2f4: fcmp            d0, d1
    // 0xb4d2f8: b.lt            #0xb4d310
    // 0xb4d2fc: mov             x1, x0
    // 0xb4d300: r0 = smallest()
    //     0xb4d300: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb4d304: LeaveFrame
    //     0xb4d304: mov             SP, fp
    //     0xb4d308: ldp             fp, lr, [SP], #0x10
    // 0xb4d30c: ret
    //     0xb4d30c: ret             
    // 0xb4d310: mov             x2, x0
    // 0xb4d314: r0 = getDryLayout()
    //     0xb4d314: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4d318: mov             x2, x0
    // 0xb4d31c: ldur            x1, [fp, #-8]
    // 0xb4d320: stur            x2, [fp, #-0x18]
    // 0xb4d324: LoadField: r0 = r1->field_73
    //     0xb4d324: ldur            w0, [x1, #0x73]
    // 0xb4d328: DecompressPointer r0
    //     0xb4d328: add             x0, x0, HEAP, lsl #32
    // 0xb4d32c: LoadField: r3 = r0->field_7
    //     0xb4d32c: ldur            x3, [x0, #7]
    // 0xb4d330: cmp             x3, #1
    // 0xb4d334: b.gt            #0xb4d400
    // 0xb4d338: cmp             x3, #0
    // 0xb4d33c: b.gt            #0xb4d354
    // 0xb4d340: ldur            x1, [fp, #-0x10]
    // 0xb4d344: r0 = constrain()
    //     0xb4d344: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d348: LeaveFrame
    //     0xb4d348: mov             SP, fp
    //     0xb4d34c: ldp             fp, lr, [SP], #0x10
    // 0xb4d350: ret
    //     0xb4d350: ret             
    // 0xb4d354: LoadField: r0 = r1->field_67
    //     0xb4d354: ldur            w0, [x1, #0x67]
    // 0xb4d358: DecompressPointer r0
    //     0xb4d358: add             x0, x0, HEAP, lsl #32
    // 0xb4d35c: LoadField: r3 = r0->field_f
    //     0xb4d35c: ldur            w3, [x0, #0xf]
    // 0xb4d360: DecompressPointer r3
    //     0xb4d360: add             x3, x3, HEAP, lsl #32
    // 0xb4d364: r0 = LoadClassIdInstr(r3)
    //     0xb4d364: ldur            x0, [x3, #-1]
    //     0xb4d368: ubfx            x0, x0, #0xc, #0x14
    // 0xb4d36c: stp             x2, x3, [SP]
    // 0xb4d370: mov             lr, x0
    // 0xb4d374: ldr             lr, [x21, lr, lsl #3]
    // 0xb4d378: blr             lr
    // 0xb4d37c: tbz             w0, #4, #0xb4d3ac
    // 0xb4d380: ldur            x1, [fp, #-8]
    // 0xb4d384: LoadField: r2 = r1->field_83
    //     0xb4d384: ldur            w2, [x1, #0x83]
    // 0xb4d388: DecompressPointer r2
    //     0xb4d388: add             x2, x2, HEAP, lsl #32
    // 0xb4d38c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb4d390: cmp             w2, w16
    // 0xb4d394: b.eq            #0xb4d478
    // 0xb4d398: ldur            x1, [fp, #-0x10]
    // 0xb4d39c: r0 = constrain()
    //     0xb4d39c: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d3a0: LeaveFrame
    //     0xb4d3a0: mov             SP, fp
    //     0xb4d3a4: ldp             fp, lr, [SP], #0x10
    // 0xb4d3a8: ret
    //     0xb4d3a8: ret             
    // 0xb4d3ac: ldur            x1, [fp, #-8]
    // 0xb4d3b0: LoadField: r0 = r1->field_5f
    //     0xb4d3b0: ldur            w0, [x1, #0x5f]
    // 0xb4d3b4: DecompressPointer r0
    //     0xb4d3b4: add             x0, x0, HEAP, lsl #32
    // 0xb4d3b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb4d3bc: cmp             w0, w16
    // 0xb4d3c0: b.eq            #0xb4d484
    // 0xb4d3c4: LoadField: r2 = r0->field_37
    //     0xb4d3c4: ldur            w2, [x0, #0x37]
    // 0xb4d3c8: DecompressPointer r2
    //     0xb4d3c8: add             x2, x2, HEAP, lsl #32
    // 0xb4d3cc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb4d3d0: cmp             w2, w16
    // 0xb4d3d4: b.eq            #0xb4d490
    // 0xb4d3d8: LoadField: d0 = r0->field_1b
    //     0xb4d3d8: ldur            d0, [x0, #0x1b]
    // 0xb4d3dc: LoadField: d1 = r2->field_7
    //     0xb4d3dc: ldur            d1, [x2, #7]
    // 0xb4d3e0: fcmp            d1, d0
    // 0xb4d3e4: b.ne            #0xb4d448
    // 0xb4d3e8: ldur            x1, [fp, #-0x10]
    // 0xb4d3ec: ldur            x2, [fp, #-0x18]
    // 0xb4d3f0: r0 = constrain()
    //     0xb4d3f0: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d3f4: LeaveFrame
    //     0xb4d3f4: mov             SP, fp
    //     0xb4d3f8: ldp             fp, lr, [SP], #0x10
    // 0xb4d3fc: ret
    //     0xb4d3fc: ret             
    // 0xb4d400: LoadField: r0 = r1->field_67
    //     0xb4d400: ldur            w0, [x1, #0x67]
    // 0xb4d404: DecompressPointer r0
    //     0xb4d404: add             x0, x0, HEAP, lsl #32
    // 0xb4d408: LoadField: r2 = r0->field_f
    //     0xb4d408: ldur            w2, [x0, #0xf]
    // 0xb4d40c: DecompressPointer r2
    //     0xb4d40c: add             x2, x2, HEAP, lsl #32
    // 0xb4d410: r0 = LoadClassIdInstr(r2)
    //     0xb4d410: ldur            x0, [x2, #-1]
    //     0xb4d414: ubfx            x0, x0, #0xc, #0x14
    // 0xb4d418: ldur            x16, [fp, #-0x18]
    // 0xb4d41c: stp             x16, x2, [SP]
    // 0xb4d420: mov             lr, x0
    // 0xb4d424: ldr             lr, [x21, lr, lsl #3]
    // 0xb4d428: blr             lr
    // 0xb4d42c: tbz             w0, #4, #0xb4d448
    // 0xb4d430: ldur            x1, [fp, #-0x10]
    // 0xb4d434: ldur            x2, [fp, #-0x18]
    // 0xb4d438: r0 = constrain()
    //     0xb4d438: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d43c: LeaveFrame
    //     0xb4d43c: mov             SP, fp
    //     0xb4d440: ldp             fp, lr, [SP], #0x10
    // 0xb4d444: ret
    //     0xb4d444: ret             
    // 0xb4d448: ldur            x1, [fp, #-8]
    // 0xb4d44c: r0 = _animatedSize()
    //     0xb4d44c: bl              #0xb4d49c  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_animatedSize
    // 0xb4d450: cmp             w0, NULL
    // 0xb4d454: b.eq            #0xb4d498
    // 0xb4d458: ldur            x1, [fp, #-0x10]
    // 0xb4d45c: mov             x2, x0
    // 0xb4d460: r0 = constrain()
    //     0xb4d460: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb4d464: LeaveFrame
    //     0xb4d464: mov             SP, fp
    //     0xb4d468: ldp             fp, lr, [SP], #0x10
    // 0xb4d46c: ret
    //     0xb4d46c: ret             
    // 0xb4d470: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d470: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d474: b               #0xb4d2cc
    // 0xb4d478: r9 = _currentSize
    //     0xb4d478: add             x9, PP, #0xab, lsl #12  ; [pp+0xab760] Field <RenderAnimatedSize._currentSize@600160358>: late (offset: 0x84)
    //     0xb4d47c: ldr             x9, [x9, #0x760]
    // 0xb4d480: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb4d480: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb4d484: r9 = _controller
    //     0xb4d484: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xb4d488: ldr             x9, [x9, #0x4a8]
    // 0xb4d48c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb4d48c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb4d490: r9 = _value
    //     0xb4d490: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xb4d494: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb4d494: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xb4d498: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb4d498: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _animatedSize(/* No info */) {
    // ** addr: 0xb4d49c, size: 0x58
    // 0xb4d49c: EnterFrame
    //     0xb4d49c: stp             fp, lr, [SP, #-0x10]!
    //     0xb4d4a0: mov             fp, SP
    // 0xb4d4a4: CheckStackOverflow
    //     0xb4d4a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4d4a8: cmp             SP, x16
    //     0xb4d4ac: b.ls            #0xb4d4e0
    // 0xb4d4b0: LoadField: r0 = r1->field_67
    //     0xb4d4b0: ldur            w0, [x1, #0x67]
    // 0xb4d4b4: DecompressPointer r0
    //     0xb4d4b4: add             x0, x0, HEAP, lsl #32
    // 0xb4d4b8: LoadField: r2 = r1->field_63
    //     0xb4d4b8: ldur            w2, [x1, #0x63]
    // 0xb4d4bc: DecompressPointer r2
    //     0xb4d4bc: add             x2, x2, HEAP, lsl #32
    // 0xb4d4c0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xb4d4c4: cmp             w2, w16
    // 0xb4d4c8: b.eq            #0xb4d4e8
    // 0xb4d4cc: mov             x1, x0
    // 0xb4d4d0: r0 = evaluate()
    //     0xb4d4d0: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xb4d4d4: LeaveFrame
    //     0xb4d4d4: mov             SP, fp
    //     0xb4d4d8: ldp             fp, lr, [SP], #0x10
    // 0xb4d4dc: ret
    //     0xb4d4dc: ret             
    // 0xb4d4e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4d4e0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4d4e4: b               #0xb4d4b0
    // 0xb4d4e8: r9 = _animation
    //     0xb4d4e8: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34b0] Field <RenderAnimatedSize._animation@600160358>: late final (offset: 0x64)
    //     0xb4d4ec: ldr             x9, [x9, #0x4b0]
    // 0xb4d4f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb4d4f0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ computeDryBaseline(/* No info */) {
    // ** addr: 0xb600fc, size: 0x15c
    // 0xb600fc: EnterFrame
    //     0xb600fc: stp             fp, lr, [SP, #-0x10]!
    //     0xb60100: mov             fp, SP
    // 0xb60104: AllocStack(0x20)
    //     0xb60104: sub             SP, SP, #0x20
    // 0xb60108: SetupParameters(RenderAnimatedSize this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xb60108: mov             x5, x1
    //     0xb6010c: mov             x4, x2
    //     0xb60110: stur            x1, [fp, #-8]
    //     0xb60114: stur            x2, [fp, #-0x10]
    //     0xb60118: stur            x3, [fp, #-0x18]
    // 0xb6011c: CheckStackOverflow
    //     0xb6011c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb60120: cmp             SP, x16
    //     0xb60124: b.ls            #0xb60240
    // 0xb60128: mov             x0, x4
    // 0xb6012c: r2 = Null
    //     0xb6012c: mov             x2, NULL
    // 0xb60130: r1 = Null
    //     0xb60130: mov             x1, NULL
    // 0xb60134: r4 = 60
    //     0xb60134: mov             x4, #0x3c
    // 0xb60138: branchIfSmi(r0, 0xb60144)
    //     0xb60138: tbz             w0, #0, #0xb60144
    // 0xb6013c: r4 = LoadClassIdInstr(r0)
    //     0xb6013c: ldur            x4, [x0, #-1]
    //     0xb60140: ubfx            x4, x4, #0xc, #0x14
    // 0xb60144: sub             x4, x4, #0xb46
    // 0xb60148: cmp             x4, #1
    // 0xb6014c: b.ls            #0xb60160
    // 0xb60150: r8 = BoxConstraints
    //     0xb60150: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xb60154: r3 = Null
    //     0xb60154: add             x3, PP, #0xab, lsl #12  ; [pp+0xab748] Null
    //     0xb60158: ldr             x3, [x3, #0x748]
    // 0xb6015c: r0 = BoxConstraints()
    //     0xb6015c: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xb60160: ldur            x0, [fp, #-8]
    // 0xb60164: LoadField: r4 = r0->field_4f
    //     0xb60164: ldur            w4, [x0, #0x4f]
    // 0xb60168: DecompressPointer r4
    //     0xb60168: add             x4, x4, HEAP, lsl #32
    // 0xb6016c: stur            x4, [fp, #-0x20]
    // 0xb60170: cmp             w4, NULL
    // 0xb60174: b.ne            #0xb60188
    // 0xb60178: r0 = Null
    //     0xb60178: mov             x0, NULL
    // 0xb6017c: LeaveFrame
    //     0xb6017c: mov             SP, fp
    //     0xb60180: ldp             fp, lr, [SP], #0x10
    // 0xb60184: ret
    //     0xb60184: ret             
    // 0xb60188: mov             x1, x4
    // 0xb6018c: ldur            x2, [fp, #-0x10]
    // 0xb60190: ldur            x3, [fp, #-0x18]
    // 0xb60194: r0 = getDryBaseline()
    //     0xb60194: bl              #0xb19678  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryBaseline
    // 0xb60198: stur            x0, [fp, #-0x18]
    // 0xb6019c: cmp             w0, NULL
    // 0xb601a0: b.ne            #0xb601b4
    // 0xb601a4: r0 = Null
    //     0xb601a4: mov             x0, NULL
    // 0xb601a8: LeaveFrame
    //     0xb601a8: mov             SP, fp
    //     0xb601ac: ldp             fp, lr, [SP], #0x10
    // 0xb601b0: ret
    //     0xb601b0: ret             
    // 0xb601b4: ldur            x1, [fp, #-0x20]
    // 0xb601b8: ldur            x2, [fp, #-0x10]
    // 0xb601bc: r0 = getDryLayout()
    //     0xb601bc: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb601c0: ldur            x1, [fp, #-8]
    // 0xb601c4: ldur            x2, [fp, #-0x10]
    // 0xb601c8: stur            x0, [fp, #-0x10]
    // 0xb601cc: r0 = getDryLayout()
    //     0xb601cc: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb601d0: ldur            x1, [fp, #-8]
    // 0xb601d4: stur            x0, [fp, #-8]
    // 0xb601d8: r0 = resolvedAlignment()
    //     0xb601d8: bl              #0xb5fd7c  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::resolvedAlignment
    // 0xb601dc: ldur            x1, [fp, #-8]
    // 0xb601e0: ldur            x2, [fp, #-0x10]
    // 0xb601e4: stur            x0, [fp, #-8]
    // 0xb601e8: r0 = -()
    //     0xb601e8: bl              #0x81d2c0  ; [dart:ui] Size::-
    // 0xb601ec: ldur            x1, [fp, #-8]
    // 0xb601f0: mov             x2, x0
    // 0xb601f4: r0 = alongOffset()
    //     0xb601f4: bl              #0xb5f054  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0xb601f8: LoadField: d0 = r0->field_f
    //     0xb601f8: ldur            d0, [x0, #0xf]
    // 0xb601fc: ldur            x1, [fp, #-0x18]
    // 0xb60200: LoadField: d1 = r1->field_7
    //     0xb60200: ldur            d1, [x1, #7]
    // 0xb60204: fadd            d2, d1, d0
    // 0xb60208: r0 = inline_Allocate_Double()
    //     0xb60208: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb6020c: add             x0, x0, #0x10
    //     0xb60210: cmp             x1, x0
    //     0xb60214: b.ls            #0xb60248
    //     0xb60218: str             x0, [THR, #0x60]  ; THR::top
    //     0xb6021c: sub             x0, x0, #0xf
    //     0xb60220: mov             x1, #0xe19c
    //     0xb60224: movk            x1, #3, lsl #16
    //     0xb60228: stur            x1, [x0, #-1]
    // 0xb6022c: dmb             ishst
    // 0xb60230: StoreField: r0->field_7 = d2
    //     0xb60230: stur            d2, [x0, #7]
    // 0xb60234: LeaveFrame
    //     0xb60234: mov             SP, fp
    //     0xb60238: ldp             fp, lr, [SP], #0x10
    // 0xb6023c: ret
    //     0xb6023c: ret             
    // 0xb60240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60240: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb60244: b               #0xb60128
    // 0xb60248: SaveReg d2
    //     0xb60248: str             q2, [SP, #-0x10]!
    // 0xb6024c: r0 = AllocateDouble()
    //     0xb6024c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb60250: RestoreReg d2
    //     0xb60250: ldr             q2, [SP], #0x10
    // 0xb60254: b               #0xb60230
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbb21c, size: 0x410
    // 0xbbb21c: EnterFrame
    //     0xbbb21c: stp             fp, lr, [SP, #-0x10]!
    //     0xbbb220: mov             fp, SP
    // 0xbbb224: AllocStack(0x28)
    //     0xbbb224: sub             SP, SP, #0x28
    // 0xbbb228: r2 = false
    //     0xbbb228: add             x2, NULL, #0x30  ; false
    // 0xbbb22c: mov             x3, x1
    // 0xbbb230: stur            x1, [fp, #-0x18]
    // 0xbbb234: CheckStackOverflow
    //     0xbbb234: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbb238: cmp             SP, x16
    //     0xbbb23c: b.ls            #0xbbb5f8
    // 0xbbb240: LoadField: r4 = r3->field_5f
    //     0xbbb240: ldur            w4, [x3, #0x5f]
    // 0xbbb244: DecompressPointer r4
    //     0xbbb244: add             x4, x4, HEAP, lsl #32
    // 0xbbb248: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbbb24c: cmp             w4, w16
    // 0xbbb250: b.eq            #0xbbb600
    // 0xbbb254: stur            x4, [fp, #-0x10]
    // 0xbbb258: LoadField: r0 = r4->field_37
    //     0xbbb258: ldur            w0, [x4, #0x37]
    // 0xbbb25c: DecompressPointer r0
    //     0xbbb25c: add             x0, x0, HEAP, lsl #32
    // 0xbbb260: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbbb264: cmp             w0, w16
    // 0xbbb268: b.eq            #0xbbb60c
    // 0xbbb26c: StoreField: r3->field_6f = r0
    //     0xbbb26c: stur            w0, [x3, #0x6f]
    //     0xbbb270: ldurb           w16, [x3, #-1]
    //     0xbbb274: ldurb           w17, [x0, #-1]
    //     0xbbb278: and             x16, x17, x16, lsr #2
    //     0xbbb27c: tst             x16, HEAP, lsr #32
    //     0xbbb280: b.eq            #0xbbb288
    //     0xbbb284: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbb288: StoreField: r3->field_6b = r2
    //     0xbbb288: stur            w2, [x3, #0x6b]
    // 0xbbb28c: LoadField: r5 = r3->field_27
    //     0xbbb28c: ldur            w5, [x3, #0x27]
    // 0xbbb290: DecompressPointer r5
    //     0xbbb290: add             x5, x5, HEAP, lsl #32
    // 0xbbb294: stur            x5, [fp, #-8]
    // 0xbbb298: cmp             w5, NULL
    // 0xbbb29c: b.eq            #0xbbb5dc
    // 0xbbb2a0: mov             x0, x5
    // 0xbbb2a4: r2 = Null
    //     0xbbb2a4: mov             x2, NULL
    // 0xbbb2a8: r1 = Null
    //     0xbbb2a8: mov             x1, NULL
    // 0xbbb2ac: r4 = LoadClassIdInstr(r0)
    //     0xbbb2ac: ldur            x4, [x0, #-1]
    //     0xbbb2b0: ubfx            x4, x4, #0xc, #0x14
    // 0xbbb2b4: sub             x4, x4, #0xb46
    // 0xbbb2b8: cmp             x4, #1
    // 0xbbb2bc: b.ls            #0xbbb2d0
    // 0xbbb2c0: r8 = BoxConstraints
    //     0xbbb2c0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbb2c4: r3 = Null
    //     0xbbb2c4: add             x3, PP, #0xab, lsl #12  ; [pp+0xab768] Null
    //     0xbbb2c8: ldr             x3, [x3, #0x768]
    // 0xbbb2cc: r0 = BoxConstraints()
    //     0xbbb2cc: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbb2d0: ldur            x0, [fp, #-0x18]
    // 0xbbb2d4: LoadField: r1 = r0->field_4f
    //     0xbbb2d4: ldur            w1, [x0, #0x4f]
    // 0xbbb2d8: DecompressPointer r1
    //     0xbbb2d8: add             x1, x1, HEAP, lsl #32
    // 0xbbb2dc: cmp             w1, NULL
    // 0xbbb2e0: b.ne            #0xbbb2ec
    // 0xbbb2e4: ldur            x2, [fp, #-8]
    // 0xbbb2e8: b               #0xbbb310
    // 0xbbb2ec: ldur            x2, [fp, #-8]
    // 0xbbb2f0: LoadField: d0 = r2->field_7
    //     0xbbb2f0: ldur            d0, [x2, #7]
    // 0xbbb2f4: LoadField: d1 = r2->field_f
    //     0xbbb2f4: ldur            d1, [x2, #0xf]
    // 0xbbb2f8: fcmp            d0, d1
    // 0xbbb2fc: b.lt            #0xbbb458
    // 0xbbb300: ArrayLoad: d0 = r2[0]  ; List_8
    //     0xbbb300: ldur            d0, [x2, #0x17]
    // 0xbbb304: LoadField: d1 = r2->field_1f
    //     0xbbb304: ldur            d1, [x2, #0x1f]
    // 0xbbb308: fcmp            d0, d1
    // 0xbbb30c: b.lt            #0xbbb450
    // 0xbbb310: ldur            x1, [fp, #-0x10]
    // 0xbbb314: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbb314: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbb318: r0 = stop()
    //     0xbbb318: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xbbb31c: ldur            x0, [fp, #-0x18]
    // 0xbbb320: LoadField: r2 = r0->field_67
    //     0xbbb320: ldur            w2, [x0, #0x67]
    // 0xbbb324: DecompressPointer r2
    //     0xbbb324: add             x2, x2, HEAP, lsl #32
    // 0xbbb328: ldur            x1, [fp, #-8]
    // 0xbbb32c: stur            x2, [fp, #-0x10]
    // 0xbbb330: r0 = smallest()
    //     0xbbb330: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbbb334: mov             x4, x0
    // 0xbbb338: ldur            x3, [fp, #-0x10]
    // 0xbbb33c: stur            x4, [fp, #-0x20]
    // 0xbbb340: LoadField: r2 = r3->field_7
    //     0xbbb340: ldur            w2, [x3, #7]
    // 0xbbb344: DecompressPointer r2
    //     0xbbb344: add             x2, x2, HEAP, lsl #32
    // 0xbbb348: mov             x0, x4
    // 0xbbb34c: r1 = Null
    //     0xbbb34c: mov             x1, NULL
    // 0xbbb350: cmp             w0, NULL
    // 0xbbb354: b.eq            #0xbbb37c
    // 0xbbb358: cmp             w2, NULL
    // 0xbbb35c: b.eq            #0xbbb37c
    // 0xbbb360: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbbb360: ldur            w4, [x2, #0x17]
    // 0xbbb364: DecompressPointer r4
    //     0xbbb364: add             x4, x4, HEAP, lsl #32
    // 0xbbb368: r8 = X0?
    //     0xbbb368: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xbbb36c: LoadField: r9 = r4->field_7
    //     0xbbb36c: ldur            x9, [x4, #7]
    // 0xbbb370: r3 = Null
    //     0xbbb370: add             x3, PP, #0xab, lsl #12  ; [pp+0xab778] Null
    //     0xbbb374: ldr             x3, [x3, #0x778]
    // 0xbbb378: blr             x9
    // 0xbbb37c: ldur            x0, [fp, #-0x20]
    // 0xbbb380: ldur            x1, [fp, #-0x10]
    // 0xbbb384: StoreField: r1->field_f = r0
    //     0xbbb384: stur            w0, [x1, #0xf]
    //     0xbbb388: ldurb           w16, [x1, #-1]
    //     0xbbb38c: ldurb           w17, [x0, #-1]
    //     0xbbb390: and             x16, x17, x16, lsr #2
    //     0xbbb394: tst             x16, HEAP, lsr #32
    //     0xbbb398: b.eq            #0xbbb3a0
    //     0xbbb39c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbb3a0: ldur            x0, [fp, #-0x20]
    // 0xbbb3a4: StoreField: r1->field_b = r0
    //     0xbbb3a4: stur            w0, [x1, #0xb]
    //     0xbbb3a8: ldurb           w16, [x1, #-1]
    //     0xbbb3ac: ldurb           w17, [x0, #-1]
    //     0xbbb3b0: and             x16, x17, x16, lsr #2
    //     0xbbb3b4: tst             x16, HEAP, lsr #32
    //     0xbbb3b8: b.eq            #0xbbb3c0
    //     0xbbb3bc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbb3c0: ldur            x0, [fp, #-0x20]
    // 0xbbb3c4: ldur            x3, [fp, #-0x18]
    // 0xbbb3c8: StoreField: r3->field_83 = r0
    //     0xbbb3c8: stur            w0, [x3, #0x83]
    //     0xbbb3cc: ldurb           w16, [x3, #-1]
    //     0xbbb3d0: ldurb           w17, [x0, #-1]
    //     0xbbb3d4: and             x16, x17, x16, lsr #2
    //     0xbbb3d8: tst             x16, HEAP, lsr #32
    //     0xbbb3dc: b.eq            #0xbbb3e4
    //     0xbbb3e0: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbb3e4: ldur            x0, [fp, #-0x20]
    // 0xbbb3e8: StoreField: r3->field_4b = r0
    //     0xbbb3e8: stur            w0, [x3, #0x4b]
    //     0xbbb3ec: ldurb           w16, [x3, #-1]
    //     0xbbb3f0: ldurb           w17, [x0, #-1]
    //     0xbbb3f4: and             x16, x17, x16, lsr #2
    //     0xbbb3f8: tst             x16, HEAP, lsr #32
    //     0xbbb3fc: b.eq            #0xbbb404
    //     0xbbb400: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbb404: r0 = Instance_RenderAnimatedSizeState
    //     0xbbb404: add             x0, PP, #0xa3, lsl #12  ; [pp+0xa34b8] Obj!RenderAnimatedSizeState@12c4761
    //     0xbbb408: ldr             x0, [x0, #0x4b8]
    // 0xbbb40c: StoreField: r3->field_73 = r0
    //     0xbbb40c: stur            w0, [x3, #0x73]
    // 0xbbb410: LoadField: r1 = r3->field_4f
    //     0xbbb410: ldur            w1, [x3, #0x4f]
    // 0xbbb414: DecompressPointer r1
    //     0xbbb414: add             x1, x1, HEAP, lsl #32
    // 0xbbb418: cmp             w1, NULL
    // 0xbbb41c: b.eq            #0xbbb440
    // 0xbbb420: r0 = LoadClassIdInstr(r1)
    //     0xbbb420: ldur            x0, [x1, #-1]
    //     0xbbb424: ubfx            x0, x0, #0xc, #0x14
    // 0xbbb428: ldur            x2, [fp, #-8]
    // 0xbbb42c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbbb42c: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbbb430: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbb430: mov             x17, #0xe6b9
    //     0xbbb434: add             lr, x0, x17
    //     0xbbb438: ldr             lr, [x21, lr, lsl #3]
    //     0xbbb43c: blr             lr
    // 0xbbb440: r0 = Null
    //     0xbbb440: mov             x0, NULL
    // 0xbbb444: LeaveFrame
    //     0xbbb444: mov             SP, fp
    //     0xbbb448: ldp             fp, lr, [SP], #0x10
    // 0xbbb44c: ret
    //     0xbbb44c: ret             
    // 0xbbb450: mov             x3, x0
    // 0xbbb454: b               #0xbbb45c
    // 0xbbb458: mov             x3, x0
    // 0xbbb45c: r0 = LoadClassIdInstr(r1)
    //     0xbbb45c: ldur            x0, [x1, #-1]
    //     0xbbb460: ubfx            x0, x0, #0xc, #0x14
    // 0xbbb464: r16 = true
    //     0xbbb464: add             x16, NULL, #0x20  ; true
    // 0xbbb468: str             x16, [SP]
    // 0xbbb46c: ldur            x2, [fp, #-8]
    // 0xbbb470: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbb470: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbb474: ldr             x4, [x4, #0xed0]
    // 0xbbb478: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbb478: mov             x17, #0xe6b9
    //     0xbbb47c: add             lr, x0, x17
    //     0xbbb480: ldr             lr, [x21, lr, lsl #3]
    //     0xbbb484: blr             lr
    // 0xbbb488: ldur            x0, [fp, #-0x18]
    // 0xbbb48c: LoadField: r1 = r0->field_73
    //     0xbbb48c: ldur            w1, [x0, #0x73]
    // 0xbbb490: DecompressPointer r1
    //     0xbbb490: add             x1, x1, HEAP, lsl #32
    // 0xbbb494: LoadField: r2 = r1->field_7
    //     0xbbb494: ldur            x2, [x1, #7]
    // 0xbbb498: cmp             x2, #1
    // 0xbbb49c: b.gt            #0xbbb4c0
    // 0xbbb4a0: cmp             x2, #0
    // 0xbbb4a4: b.gt            #0xbbb4b4
    // 0xbbb4a8: mov             x1, x0
    // 0xbbb4ac: r0 = _layoutStart()
    //     0xbbb4ac: bl              #0xbbbca0  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_layoutStart
    // 0xbbb4b0: b               #0xbbb4dc
    // 0xbbb4b4: ldur            x1, [fp, #-0x18]
    // 0xbbb4b8: r0 = _layoutStable()
    //     0xbbb4b8: bl              #0xbbb9d0  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_layoutStable
    // 0xbbb4bc: b               #0xbbb4dc
    // 0xbbb4c0: cmp             x2, #2
    // 0xbbb4c4: b.gt            #0xbbb4d4
    // 0xbbb4c8: ldur            x1, [fp, #-0x18]
    // 0xbbb4cc: r0 = _layoutChanged()
    //     0xbbb4cc: bl              #0xbbb820  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_layoutChanged
    // 0xbbb4d0: b               #0xbbb4dc
    // 0xbbb4d4: ldur            x1, [fp, #-0x18]
    // 0xbbb4d8: r0 = _layoutUnstable()
    //     0xbbb4d8: bl              #0xbbb62c  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_layoutUnstable
    // 0xbbb4dc: ldur            x0, [fp, #-0x18]
    // 0xbbb4e0: LoadField: r3 = r0->field_67
    //     0xbbb4e0: ldur            w3, [x0, #0x67]
    // 0xbbb4e4: DecompressPointer r3
    //     0xbbb4e4: add             x3, x3, HEAP, lsl #32
    // 0xbbb4e8: stur            x3, [fp, #-0x10]
    // 0xbbb4ec: LoadField: r2 = r0->field_63
    //     0xbbb4ec: ldur            w2, [x0, #0x63]
    // 0xbbb4f0: DecompressPointer r2
    //     0xbbb4f0: add             x2, x2, HEAP, lsl #32
    // 0xbbb4f4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbbb4f8: cmp             w2, w16
    // 0xbbb4fc: b.eq            #0xbbb614
    // 0xbbb500: mov             x1, x3
    // 0xbbb504: r0 = evaluate()
    //     0xbbb504: bl              #0x112be60  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbbb508: cmp             w0, NULL
    // 0xbbb50c: b.eq            #0xbbb620
    // 0xbbb510: ldur            x1, [fp, #-8]
    // 0xbbb514: mov             x2, x0
    // 0xbbb518: r0 = constrain()
    //     0xbbb518: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xbbb51c: mov             x1, x0
    // 0xbbb520: ldur            x2, [fp, #-0x18]
    // 0xbbb524: StoreField: r2->field_83 = r0
    //     0xbbb524: stur            w0, [x2, #0x83]
    //     0xbbb528: ldurb           w16, [x2, #-1]
    //     0xbbb52c: ldurb           w17, [x0, #-1]
    //     0xbbb530: and             x16, x17, x16, lsr #2
    //     0xbbb534: tst             x16, HEAP, lsr #32
    //     0xbbb538: b.eq            #0xbbb540
    //     0xbbb53c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbb540: mov             x0, x1
    // 0xbbb544: StoreField: r2->field_4b = r0
    //     0xbbb544: stur            w0, [x2, #0x4b]
    //     0xbbb548: ldurb           w16, [x2, #-1]
    //     0xbbb54c: ldurb           w17, [x0, #-1]
    //     0xbbb550: and             x16, x17, x16, lsr #2
    //     0xbbb554: tst             x16, HEAP, lsr #32
    //     0xbbb558: b.eq            #0xbbb560
    //     0xbbb55c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbb560: mov             x1, x2
    // 0xbbb564: r0 = alignChild()
    //     0xbbb564: bl              #0xbbad50  ; [package:flutter/src/rendering/shifted_box.dart] RenderAligningShiftedBox::alignChild
    // 0xbbb568: ldur            x1, [fp, #-0x18]
    // 0xbbb56c: r0 = size()
    //     0xbbb56c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbb570: LoadField: d0 = r0->field_7
    //     0xbbb570: ldur            d0, [x0, #7]
    // 0xbbb574: ldur            x0, [fp, #-0x10]
    // 0xbbb578: LoadField: r1 = r0->field_f
    //     0xbbb578: ldur            w1, [x0, #0xf]
    // 0xbbb57c: DecompressPointer r1
    //     0xbbb57c: add             x1, x1, HEAP, lsl #32
    // 0xbbb580: cmp             w1, NULL
    // 0xbbb584: b.eq            #0xbbb624
    // 0xbbb588: LoadField: d1 = r1->field_7
    //     0xbbb588: ldur            d1, [x1, #7]
    // 0xbbb58c: fcmp            d1, d0
    // 0xbbb590: b.gt            #0xbbb5c0
    // 0xbbb594: ldur            x1, [fp, #-0x18]
    // 0xbbb598: r0 = size()
    //     0xbbb598: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbb59c: LoadField: d0 = r0->field_f
    //     0xbbb59c: ldur            d0, [x0, #0xf]
    // 0xbbb5a0: ldur            x0, [fp, #-0x10]
    // 0xbbb5a4: LoadField: r1 = r0->field_f
    //     0xbbb5a4: ldur            w1, [x0, #0xf]
    // 0xbbb5a8: DecompressPointer r1
    //     0xbbb5a8: add             x1, x1, HEAP, lsl #32
    // 0xbbb5ac: cmp             w1, NULL
    // 0xbbb5b0: b.eq            #0xbbb628
    // 0xbbb5b4: LoadField: d1 = r1->field_f
    //     0xbbb5b4: ldur            d1, [x1, #0xf]
    // 0xbbb5b8: fcmp            d1, d0
    // 0xbbb5bc: b.le            #0xbbb5cc
    // 0xbbb5c0: ldur            x0, [fp, #-0x18]
    // 0xbbb5c4: r1 = true
    //     0xbbb5c4: add             x1, NULL, #0x20  ; true
    // 0xbbb5c8: StoreField: r0->field_6b = r1
    //     0xbbb5c8: stur            w1, [x0, #0x6b]
    // 0xbbb5cc: r0 = Null
    //     0xbbb5cc: mov             x0, NULL
    // 0xbbb5d0: LeaveFrame
    //     0xbbb5d0: mov             SP, fp
    //     0xbbb5d4: ldp             fp, lr, [SP], #0x10
    // 0xbbb5d8: ret
    //     0xbbb5d8: ret             
    // 0xbbb5dc: r0 = StateError()
    //     0xbbb5dc: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbb5e0: mov             x1, x0
    // 0xbbb5e4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbb5e4: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbb5e8: StoreField: r1->field_b = r0
    //     0xbbb5e8: stur            w0, [x1, #0xb]
    // 0xbbb5ec: mov             x0, x1
    // 0xbbb5f0: r0 = Throw()
    //     0xbbb5f0: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbb5f4: brk             #0
    // 0xbbb5f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbb5f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbb5fc: b               #0xbbb240
    // 0xbbb600: r9 = _controller
    //     0xbbb600: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xbbb604: ldr             x9, [x9, #0x4a8]
    // 0xbbb608: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbbb608: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbbb60c: r9 = _value
    //     0xbbb60c: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xbbb610: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbbb610: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbbb614: r9 = _animation
    //     0xbbb614: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34b0] Field <RenderAnimatedSize._animation@600160358>: late final (offset: 0x64)
    //     0xbbb618: ldr             x9, [x9, #0x4b0]
    // 0xbbb61c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbbb61c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbbb620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbb620: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbb624: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbb624: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbbb628: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbb628: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _layoutUnstable(/* No info */) {
    // ** addr: 0xbbb62c, size: 0x184
    // 0xbbb62c: EnterFrame
    //     0xbbb62c: stp             fp, lr, [SP, #-0x10]!
    //     0xbbb630: mov             fp, SP
    // 0xbbb634: AllocStack(0x28)
    //     0xbbb634: sub             SP, SP, #0x28
    // 0xbbb638: SetupParameters(RenderAnimatedSize this /* r1 => r0, fp-0x18 */)
    //     0xbbb638: mov             x0, x1
    //     0xbbb63c: stur            x1, [fp, #-0x18]
    // 0xbbb640: CheckStackOverflow
    //     0xbbb640: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbb644: cmp             SP, x16
    //     0xbbb648: b.ls            #0xbbb794
    // 0xbbb64c: LoadField: r2 = r0->field_67
    //     0xbbb64c: ldur            w2, [x0, #0x67]
    // 0xbbb650: DecompressPointer r2
    //     0xbbb650: add             x2, x2, HEAP, lsl #32
    // 0xbbb654: stur            x2, [fp, #-0x10]
    // 0xbbb658: LoadField: r3 = r2->field_f
    //     0xbbb658: ldur            w3, [x2, #0xf]
    // 0xbbb65c: DecompressPointer r3
    //     0xbbb65c: add             x3, x3, HEAP, lsl #32
    // 0xbbb660: stur            x3, [fp, #-8]
    // 0xbbb664: LoadField: r1 = r0->field_4f
    //     0xbbb664: ldur            w1, [x0, #0x4f]
    // 0xbbb668: DecompressPointer r1
    //     0xbbb668: add             x1, x1, HEAP, lsl #32
    // 0xbbb66c: cmp             w1, NULL
    // 0xbbb670: b.eq            #0xbbb79c
    // 0xbbb674: r0 = size()
    //     0xbbb674: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbb678: mov             x1, x0
    // 0xbbb67c: ldur            x0, [fp, #-8]
    // 0xbbb680: r2 = LoadClassIdInstr(r0)
    //     0xbbb680: ldur            x2, [x0, #-1]
    //     0xbbb684: ubfx            x2, x2, #0xc, #0x14
    // 0xbbb688: stp             x1, x0, [SP]
    // 0xbbb68c: mov             x0, x2
    // 0xbbb690: mov             lr, x0
    // 0xbbb694: ldr             lr, [x21, lr, lsl #3]
    // 0xbbb698: blr             lr
    // 0xbbb69c: tbz             w0, #4, #0xbbb754
    // 0xbbb6a0: ldur            x0, [fp, #-0x18]
    // 0xbbb6a4: ldur            x2, [fp, #-0x10]
    // 0xbbb6a8: LoadField: r1 = r0->field_4f
    //     0xbbb6a8: ldur            w1, [x0, #0x4f]
    // 0xbbb6ac: DecompressPointer r1
    //     0xbbb6ac: add             x1, x1, HEAP, lsl #32
    // 0xbbb6b0: cmp             w1, NULL
    // 0xbbb6b4: b.eq            #0xbbb7a0
    // 0xbbb6b8: r0 = size()
    //     0xbbb6b8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbb6bc: mov             x4, x0
    // 0xbbb6c0: ldur            x3, [fp, #-0x10]
    // 0xbbb6c4: stur            x4, [fp, #-8]
    // 0xbbb6c8: LoadField: r2 = r3->field_7
    //     0xbbb6c8: ldur            w2, [x3, #7]
    // 0xbbb6cc: DecompressPointer r2
    //     0xbbb6cc: add             x2, x2, HEAP, lsl #32
    // 0xbbb6d0: mov             x0, x4
    // 0xbbb6d4: r1 = Null
    //     0xbbb6d4: mov             x1, NULL
    // 0xbbb6d8: cmp             w0, NULL
    // 0xbbb6dc: b.eq            #0xbbb704
    // 0xbbb6e0: cmp             w2, NULL
    // 0xbbb6e4: b.eq            #0xbbb704
    // 0xbbb6e8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbbb6e8: ldur            w4, [x2, #0x17]
    // 0xbbb6ec: DecompressPointer r4
    //     0xbbb6ec: add             x4, x4, HEAP, lsl #32
    // 0xbbb6f0: r8 = X0?
    //     0xbbb6f0: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xbbb6f4: LoadField: r9 = r4->field_7
    //     0xbbb6f4: ldur            x9, [x4, #7]
    // 0xbbb6f8: r3 = Null
    //     0xbbb6f8: add             x3, PP, #0xab, lsl #12  ; [pp+0xab788] Null
    //     0xbbb6fc: ldr             x3, [x3, #0x788]
    // 0xbbb700: blr             x9
    // 0xbbb704: ldur            x0, [fp, #-8]
    // 0xbbb708: ldur            x1, [fp, #-0x10]
    // 0xbbb70c: StoreField: r1->field_f = r0
    //     0xbbb70c: stur            w0, [x1, #0xf]
    //     0xbbb710: ldurb           w16, [x1, #-1]
    //     0xbbb714: ldurb           w17, [x0, #-1]
    //     0xbbb718: and             x16, x17, x16, lsr #2
    //     0xbbb71c: tst             x16, HEAP, lsr #32
    //     0xbbb720: b.eq            #0xbbb728
    //     0xbbb724: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbb728: ldur            x0, [fp, #-8]
    // 0xbbb72c: StoreField: r1->field_b = r0
    //     0xbbb72c: stur            w0, [x1, #0xb]
    //     0xbbb730: ldurb           w16, [x1, #-1]
    //     0xbbb734: ldurb           w17, [x0, #-1]
    //     0xbbb738: and             x16, x17, x16, lsr #2
    //     0xbbb73c: tst             x16, HEAP, lsr #32
    //     0xbbb740: b.eq            #0xbbb748
    //     0xbbb744: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbb748: ldur            x1, [fp, #-0x18]
    // 0xbbb74c: r0 = _restartAnimation()
    //     0xbbb74c: bl              #0xbbb7b0  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_restartAnimation
    // 0xbbb750: b               #0xbbb784
    // 0xbbb754: ldur            x0, [fp, #-0x18]
    // 0xbbb758: LoadField: r1 = r0->field_5f
    //     0xbbb758: ldur            w1, [x0, #0x5f]
    // 0xbbb75c: DecompressPointer r1
    //     0xbbb75c: add             x1, x1, HEAP, lsl #32
    // 0xbbb760: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbbb764: cmp             w1, w16
    // 0xbbb768: b.eq            #0xbbb7a4
    // 0xbbb76c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbb76c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbb770: r0 = stop()
    //     0xbbb770: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xbbb774: ldur            x1, [fp, #-0x18]
    // 0xbbb778: r2 = Instance_RenderAnimatedSizeState
    //     0xbbb778: add             x2, PP, #0xab, lsl #12  ; [pp+0xab798] Obj!RenderAnimatedSizeState@12c4701
    //     0xbbb77c: ldr             x2, [x2, #0x798]
    // 0xbbb780: StoreField: r1->field_73 = r2
    //     0xbbb780: stur            w2, [x1, #0x73]
    // 0xbbb784: r0 = Null
    //     0xbbb784: mov             x0, NULL
    // 0xbbb788: LeaveFrame
    //     0xbbb788: mov             SP, fp
    //     0xbbb78c: ldp             fp, lr, [SP], #0x10
    // 0xbbb790: ret
    //     0xbbb790: ret             
    // 0xbbb794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbb794: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbb798: b               #0xbbb64c
    // 0xbbb79c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbb79c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbb7a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbb7a0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbb7a4: r9 = _controller
    //     0xbbb7a4: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xbbb7a8: ldr             x9, [x9, #0x4a8]
    // 0xbbb7ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbbb7ac: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _restartAnimation(/* No info */) {
    // ** addr: 0xbbb7b0, size: 0x70
    // 0xbbb7b0: EnterFrame
    //     0xbbb7b0: stp             fp, lr, [SP, #-0x10]!
    //     0xbbb7b4: mov             fp, SP
    // 0xbbb7b8: AllocStack(0x8)
    //     0xbbb7b8: sub             SP, SP, #8
    // 0xbbb7bc: r0 = 0.000000
    //     0xbbb7bc: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbbb7c0: CheckStackOverflow
    //     0xbbb7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbb7c4: cmp             SP, x16
    //     0xbbb7c8: b.ls            #0xbbb80c
    // 0xbbb7cc: StoreField: r1->field_6f = r0
    //     0xbbb7cc: stur            w0, [x1, #0x6f]
    // 0xbbb7d0: LoadField: r0 = r1->field_5f
    //     0xbbb7d0: ldur            w0, [x1, #0x5f]
    // 0xbbb7d4: DecompressPointer r0
    //     0xbbb7d4: add             x0, x0, HEAP, lsl #32
    // 0xbbb7d8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbbb7dc: cmp             w0, w16
    // 0xbbb7e0: b.eq            #0xbbb814
    // 0xbbb7e4: r16 = 0.000000
    //     0xbbb7e4: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbbb7e8: str             x16, [SP]
    // 0xbbb7ec: mov             x1, x0
    // 0xbbb7f0: r4 = const [0, 0x2, 0x1, 0x1, from, 0x1, null]
    //     0xbbb7f0: add             x4, PP, #0x27, lsl #12  ; [pp+0x27420] List(7) [0, 0x2, 0x1, 0x1, "from", 0x1, Null]
    //     0xbbb7f4: ldr             x4, [x4, #0x420]
    // 0xbbb7f8: r0 = forward()
    //     0xbbb7f8: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xbbb7fc: r0 = Null
    //     0xbbb7fc: mov             x0, NULL
    // 0xbbb800: LeaveFrame
    //     0xbbb800: mov             SP, fp
    //     0xbbb804: ldp             fp, lr, [SP], #0x10
    // 0xbbb808: ret
    //     0xbbb808: ret             
    // 0xbbb80c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbb80c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbb810: b               #0xbbb7cc
    // 0xbbb814: r9 = _controller
    //     0xbbb814: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xbbb818: ldr             x9, [x9, #0x4a8]
    // 0xbbb81c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbbb81c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _layoutChanged(/* No info */) {
    // ** addr: 0xbbb820, size: 0x1b0
    // 0xbbb820: EnterFrame
    //     0xbbb820: stp             fp, lr, [SP, #-0x10]!
    //     0xbbb824: mov             fp, SP
    // 0xbbb828: AllocStack(0x28)
    //     0xbbb828: sub             SP, SP, #0x28
    // 0xbbb82c: SetupParameters(RenderAnimatedSize this /* r1 => r0, fp-0x18 */)
    //     0xbbb82c: mov             x0, x1
    //     0xbbb830: stur            x1, [fp, #-0x18]
    // 0xbbb834: CheckStackOverflow
    //     0xbbb834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbb838: cmp             SP, x16
    //     0xbbb83c: b.ls            #0xbbb9b4
    // 0xbbb840: LoadField: r2 = r0->field_67
    //     0xbbb840: ldur            w2, [x0, #0x67]
    // 0xbbb844: DecompressPointer r2
    //     0xbbb844: add             x2, x2, HEAP, lsl #32
    // 0xbbb848: stur            x2, [fp, #-0x10]
    // 0xbbb84c: LoadField: r3 = r2->field_f
    //     0xbbb84c: ldur            w3, [x2, #0xf]
    // 0xbbb850: DecompressPointer r3
    //     0xbbb850: add             x3, x3, HEAP, lsl #32
    // 0xbbb854: stur            x3, [fp, #-8]
    // 0xbbb858: LoadField: r1 = r0->field_4f
    //     0xbbb858: ldur            w1, [x0, #0x4f]
    // 0xbbb85c: DecompressPointer r1
    //     0xbbb85c: add             x1, x1, HEAP, lsl #32
    // 0xbbb860: cmp             w1, NULL
    // 0xbbb864: b.eq            #0xbbb9bc
    // 0xbbb868: r0 = size()
    //     0xbbb868: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbb86c: mov             x1, x0
    // 0xbbb870: ldur            x0, [fp, #-8]
    // 0xbbb874: r2 = LoadClassIdInstr(r0)
    //     0xbbb874: ldur            x2, [x0, #-1]
    //     0xbbb878: ubfx            x2, x2, #0xc, #0x14
    // 0xbbb87c: stp             x1, x0, [SP]
    // 0xbbb880: mov             x0, x2
    // 0xbbb884: mov             lr, x0
    // 0xbbb888: ldr             lr, [x21, lr, lsl #3]
    // 0xbbb88c: blr             lr
    // 0xbbb890: tbz             w0, #4, #0xbbb958
    // 0xbbb894: ldur            x0, [fp, #-0x18]
    // 0xbbb898: ldur            x2, [fp, #-0x10]
    // 0xbbb89c: LoadField: r1 = r0->field_4f
    //     0xbbb89c: ldur            w1, [x0, #0x4f]
    // 0xbbb8a0: DecompressPointer r1
    //     0xbbb8a0: add             x1, x1, HEAP, lsl #32
    // 0xbbb8a4: cmp             w1, NULL
    // 0xbbb8a8: b.eq            #0xbbb9c0
    // 0xbbb8ac: r0 = size()
    //     0xbbb8ac: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbb8b0: mov             x4, x0
    // 0xbbb8b4: ldur            x3, [fp, #-0x10]
    // 0xbbb8b8: stur            x4, [fp, #-8]
    // 0xbbb8bc: LoadField: r2 = r3->field_7
    //     0xbbb8bc: ldur            w2, [x3, #7]
    // 0xbbb8c0: DecompressPointer r2
    //     0xbbb8c0: add             x2, x2, HEAP, lsl #32
    // 0xbbb8c4: mov             x0, x4
    // 0xbbb8c8: r1 = Null
    //     0xbbb8c8: mov             x1, NULL
    // 0xbbb8cc: cmp             w0, NULL
    // 0xbbb8d0: b.eq            #0xbbb8f8
    // 0xbbb8d4: cmp             w2, NULL
    // 0xbbb8d8: b.eq            #0xbbb8f8
    // 0xbbb8dc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbbb8dc: ldur            w4, [x2, #0x17]
    // 0xbbb8e0: DecompressPointer r4
    //     0xbbb8e0: add             x4, x4, HEAP, lsl #32
    // 0xbbb8e4: r8 = X0?
    //     0xbbb8e4: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xbbb8e8: LoadField: r9 = r4->field_7
    //     0xbbb8e8: ldur            x9, [x4, #7]
    // 0xbbb8ec: r3 = Null
    //     0xbbb8ec: add             x3, PP, #0xab, lsl #12  ; [pp+0xab7a0] Null
    //     0xbbb8f0: ldr             x3, [x3, #0x7a0]
    // 0xbbb8f4: blr             x9
    // 0xbbb8f8: ldur            x0, [fp, #-8]
    // 0xbbb8fc: ldur            x1, [fp, #-0x10]
    // 0xbbb900: StoreField: r1->field_f = r0
    //     0xbbb900: stur            w0, [x1, #0xf]
    //     0xbbb904: ldurb           w16, [x1, #-1]
    //     0xbbb908: ldurb           w17, [x0, #-1]
    //     0xbbb90c: and             x16, x17, x16, lsr #2
    //     0xbbb910: tst             x16, HEAP, lsr #32
    //     0xbbb914: b.eq            #0xbbb91c
    //     0xbbb918: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbb91c: ldur            x0, [fp, #-8]
    // 0xbbb920: StoreField: r1->field_b = r0
    //     0xbbb920: stur            w0, [x1, #0xb]
    //     0xbbb924: ldurb           w16, [x1, #-1]
    //     0xbbb928: ldurb           w17, [x0, #-1]
    //     0xbbb92c: and             x16, x17, x16, lsr #2
    //     0xbbb930: tst             x16, HEAP, lsr #32
    //     0xbbb934: b.eq            #0xbbb93c
    //     0xbbb938: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbb93c: ldur            x1, [fp, #-0x18]
    // 0xbbb940: r0 = _restartAnimation()
    //     0xbbb940: bl              #0xbbb7b0  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_restartAnimation
    // 0xbbb944: ldur            x0, [fp, #-0x18]
    // 0xbbb948: r1 = Instance_RenderAnimatedSizeState
    //     0xbbb948: add             x1, PP, #0xab, lsl #12  ; [pp+0xab7b0] Obj!RenderAnimatedSizeState@12c4721
    //     0xbbb94c: ldr             x1, [x1, #0x7b0]
    // 0xbbb950: StoreField: r0->field_73 = r1
    //     0xbbb950: stur            w1, [x0, #0x73]
    // 0xbbb954: b               #0xbbb9a4
    // 0xbbb958: ldur            x0, [fp, #-0x18]
    // 0xbbb95c: r1 = Instance_RenderAnimatedSizeState
    //     0xbbb95c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab798] Obj!RenderAnimatedSizeState@12c4701
    //     0xbbb960: ldr             x1, [x1, #0x798]
    // 0xbbb964: StoreField: r0->field_73 = r1
    //     0xbbb964: stur            w1, [x0, #0x73]
    // 0xbbb968: LoadField: r1 = r0->field_5f
    //     0xbbb968: ldur            w1, [x0, #0x5f]
    // 0xbbb96c: DecompressPointer r1
    //     0xbbb96c: add             x1, x1, HEAP, lsl #32
    // 0xbbb970: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbbb974: cmp             w1, w16
    // 0xbbb978: b.eq            #0xbbb9c4
    // 0xbbb97c: LoadField: r0 = r1->field_2f
    //     0xbbb97c: ldur            w0, [x1, #0x2f]
    // 0xbbb980: DecompressPointer r0
    //     0xbbb980: add             x0, x0, HEAP, lsl #32
    // 0xbbb984: cmp             w0, NULL
    // 0xbbb988: b.eq            #0xbbb99c
    // 0xbbb98c: LoadField: r2 = r0->field_7
    //     0xbbb98c: ldur            w2, [x0, #7]
    // 0xbbb990: DecompressPointer r2
    //     0xbbb990: add             x2, x2, HEAP, lsl #32
    // 0xbbb994: cmp             w2, NULL
    // 0xbbb998: b.ne            #0xbbb9a4
    // 0xbbb99c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbb99c: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbb9a0: r0 = forward()
    //     0xbbb9a0: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xbbb9a4: r0 = Null
    //     0xbbb9a4: mov             x0, NULL
    // 0xbbb9a8: LeaveFrame
    //     0xbbb9a8: mov             SP, fp
    //     0xbbb9ac: ldp             fp, lr, [SP], #0x10
    // 0xbbb9b0: ret
    //     0xbbb9b0: ret             
    // 0xbbb9b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbb9b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbb9b8: b               #0xbbb840
    // 0xbbb9bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbb9bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbb9c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbb9c0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbb9c4: r9 = _controller
    //     0xbbb9c4: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xbbb9c8: ldr             x9, [x9, #0x4a8]
    // 0xbbb9cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbbb9cc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _layoutStable(/* No info */) {
    // ** addr: 0xbbb9d0, size: 0x2d0
    // 0xbbb9d0: EnterFrame
    //     0xbbb9d0: stp             fp, lr, [SP, #-0x10]!
    //     0xbbb9d4: mov             fp, SP
    // 0xbbb9d8: AllocStack(0x30)
    //     0xbbb9d8: sub             SP, SP, #0x30
    // 0xbbb9dc: SetupParameters(RenderAnimatedSize this /* r1 => r0, fp-0x18 */)
    //     0xbbb9dc: mov             x0, x1
    //     0xbbb9e0: stur            x1, [fp, #-0x18]
    // 0xbbb9e4: CheckStackOverflow
    //     0xbbb9e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbb9e8: cmp             SP, x16
    //     0xbbb9ec: b.ls            #0xbbbc78
    // 0xbbb9f0: LoadField: r2 = r0->field_67
    //     0xbbb9f0: ldur            w2, [x0, #0x67]
    // 0xbbb9f4: DecompressPointer r2
    //     0xbbb9f4: add             x2, x2, HEAP, lsl #32
    // 0xbbb9f8: stur            x2, [fp, #-0x10]
    // 0xbbb9fc: LoadField: r3 = r2->field_f
    //     0xbbb9fc: ldur            w3, [x2, #0xf]
    // 0xbbba00: DecompressPointer r3
    //     0xbbba00: add             x3, x3, HEAP, lsl #32
    // 0xbbba04: stur            x3, [fp, #-8]
    // 0xbbba08: LoadField: r1 = r0->field_4f
    //     0xbbba08: ldur            w1, [x0, #0x4f]
    // 0xbbba0c: DecompressPointer r1
    //     0xbbba0c: add             x1, x1, HEAP, lsl #32
    // 0xbbba10: cmp             w1, NULL
    // 0xbbba14: b.eq            #0xbbbc80
    // 0xbbba18: r0 = size()
    //     0xbbba18: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbba1c: mov             x1, x0
    // 0xbbba20: ldur            x0, [fp, #-8]
    // 0xbbba24: r2 = LoadClassIdInstr(r0)
    //     0xbbba24: ldur            x2, [x0, #-1]
    //     0xbbba28: ubfx            x2, x2, #0xc, #0x14
    // 0xbbba2c: stp             x1, x0, [SP]
    // 0xbbba30: mov             x0, x2
    // 0xbbba34: mov             lr, x0
    // 0xbbba38: ldr             lr, [x21, lr, lsl #3]
    // 0xbbba3c: blr             lr
    // 0xbbba40: tbz             w0, #4, #0xbbbb5c
    // 0xbbba44: ldur            x0, [fp, #-0x18]
    // 0xbbba48: ldur            x2, [fp, #-0x10]
    // 0xbbba4c: mov             x1, x0
    // 0xbbba50: r0 = size()
    //     0xbbba50: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbba54: mov             x4, x0
    // 0xbbba58: ldur            x3, [fp, #-0x10]
    // 0xbbba5c: stur            x4, [fp, #-0x20]
    // 0xbbba60: LoadField: r5 = r3->field_7
    //     0xbbba60: ldur            w5, [x3, #7]
    // 0xbbba64: DecompressPointer r5
    //     0xbbba64: add             x5, x5, HEAP, lsl #32
    // 0xbbba68: mov             x0, x4
    // 0xbbba6c: mov             x2, x5
    // 0xbbba70: stur            x5, [fp, #-8]
    // 0xbbba74: r1 = Null
    //     0xbbba74: mov             x1, NULL
    // 0xbbba78: cmp             w0, NULL
    // 0xbbba7c: b.eq            #0xbbbaa4
    // 0xbbba80: cmp             w2, NULL
    // 0xbbba84: b.eq            #0xbbbaa4
    // 0xbbba88: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbbba88: ldur            w4, [x2, #0x17]
    // 0xbbba8c: DecompressPointer r4
    //     0xbbba8c: add             x4, x4, HEAP, lsl #32
    // 0xbbba90: r8 = X0?
    //     0xbbba90: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xbbba94: LoadField: r9 = r4->field_7
    //     0xbbba94: ldur            x9, [x4, #7]
    // 0xbbba98: r3 = Null
    //     0xbbba98: add             x3, PP, #0xab, lsl #12  ; [pp+0xab7b8] Null
    //     0xbbba9c: ldr             x3, [x3, #0x7b8]
    // 0xbbbaa0: blr             x9
    // 0xbbbaa4: ldur            x0, [fp, #-0x20]
    // 0xbbbaa8: ldur            x2, [fp, #-0x10]
    // 0xbbbaac: StoreField: r2->field_b = r0
    //     0xbbbaac: stur            w0, [x2, #0xb]
    //     0xbbbab0: ldurb           w16, [x2, #-1]
    //     0xbbbab4: ldurb           w17, [x0, #-1]
    //     0xbbbab8: and             x16, x17, x16, lsr #2
    //     0xbbbabc: tst             x16, HEAP, lsr #32
    //     0xbbbac0: b.eq            #0xbbbac8
    //     0xbbbac4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbbac8: ldur            x0, [fp, #-0x18]
    // 0xbbbacc: LoadField: r1 = r0->field_4f
    //     0xbbbacc: ldur            w1, [x0, #0x4f]
    // 0xbbbad0: DecompressPointer r1
    //     0xbbbad0: add             x1, x1, HEAP, lsl #32
    // 0xbbbad4: cmp             w1, NULL
    // 0xbbbad8: b.eq            #0xbbbc84
    // 0xbbbadc: r0 = size()
    //     0xbbbadc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbbae0: ldur            x2, [fp, #-8]
    // 0xbbbae4: mov             x3, x0
    // 0xbbbae8: r1 = Null
    //     0xbbbae8: mov             x1, NULL
    // 0xbbbaec: stur            x3, [fp, #-8]
    // 0xbbbaf0: cmp             w0, NULL
    // 0xbbbaf4: b.eq            #0xbbbb1c
    // 0xbbbaf8: cmp             w2, NULL
    // 0xbbbafc: b.eq            #0xbbbb1c
    // 0xbbbb00: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbbbb00: ldur            w4, [x2, #0x17]
    // 0xbbbb04: DecompressPointer r4
    //     0xbbbb04: add             x4, x4, HEAP, lsl #32
    // 0xbbbb08: r8 = X0?
    //     0xbbbb08: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xbbbb0c: LoadField: r9 = r4->field_7
    //     0xbbbb0c: ldur            x9, [x4, #7]
    // 0xbbbb10: r3 = Null
    //     0xbbbb10: add             x3, PP, #0xab, lsl #12  ; [pp+0xab7c8] Null
    //     0xbbbb14: ldr             x3, [x3, #0x7c8]
    // 0xbbbb18: blr             x9
    // 0xbbbb1c: ldur            x0, [fp, #-8]
    // 0xbbbb20: ldur            x2, [fp, #-0x10]
    // 0xbbbb24: StoreField: r2->field_f = r0
    //     0xbbbb24: stur            w0, [x2, #0xf]
    //     0xbbbb28: ldurb           w16, [x2, #-1]
    //     0xbbbb2c: ldurb           w17, [x0, #-1]
    //     0xbbbb30: and             x16, x17, x16, lsr #2
    //     0xbbbb34: tst             x16, HEAP, lsr #32
    //     0xbbbb38: b.eq            #0xbbbb40
    //     0xbbbb3c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbbbb40: ldur            x1, [fp, #-0x18]
    // 0xbbbb44: r0 = _restartAnimation()
    //     0xbbbb44: bl              #0xbbb7b0  ; [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::_restartAnimation
    // 0xbbbb48: ldur            x0, [fp, #-0x18]
    // 0xbbbb4c: r1 = Instance_RenderAnimatedSizeState
    //     0xbbbb4c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab7d8] Obj!RenderAnimatedSizeState@12c4741
    //     0xbbbb50: ldr             x1, [x1, #0x7d8]
    // 0xbbbb54: StoreField: r0->field_73 = r1
    //     0xbbbb54: stur            w1, [x0, #0x73]
    // 0xbbbb58: b               #0xbbbc68
    // 0xbbbb5c: ldur            x0, [fp, #-0x18]
    // 0xbbbb60: ldur            x2, [fp, #-0x10]
    // 0xbbbb64: LoadField: r1 = r0->field_5f
    //     0xbbbb64: ldur            w1, [x0, #0x5f]
    // 0xbbbb68: DecompressPointer r1
    //     0xbbbb68: add             x1, x1, HEAP, lsl #32
    // 0xbbbb6c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbbbb70: cmp             w1, w16
    // 0xbbbb74: b.eq            #0xbbbc88
    // 0xbbbb78: LoadField: r3 = r1->field_37
    //     0xbbbb78: ldur            w3, [x1, #0x37]
    // 0xbbbb7c: DecompressPointer r3
    //     0xbbbb7c: add             x3, x3, HEAP, lsl #32
    // 0xbbbb80: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbbbb84: cmp             w3, w16
    // 0xbbbb88: b.eq            #0xbbbc94
    // 0xbbbb8c: LoadField: d0 = r1->field_1b
    //     0xbbbb8c: ldur            d0, [x1, #0x1b]
    // 0xbbbb90: LoadField: d1 = r3->field_7
    //     0xbbbb90: ldur            d1, [x3, #7]
    // 0xbbbb94: fcmp            d1, d0
    // 0xbbbb98: b.ne            #0xbbbc40
    // 0xbbbb9c: LoadField: r1 = r0->field_4f
    //     0xbbbb9c: ldur            w1, [x0, #0x4f]
    // 0xbbbba0: DecompressPointer r1
    //     0xbbbba0: add             x1, x1, HEAP, lsl #32
    // 0xbbbba4: cmp             w1, NULL
    // 0xbbbba8: b.eq            #0xbbbc9c
    // 0xbbbbac: r0 = size()
    //     0xbbbbac: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbbbb0: mov             x4, x0
    // 0xbbbbb4: ldur            x3, [fp, #-0x10]
    // 0xbbbbb8: stur            x4, [fp, #-8]
    // 0xbbbbbc: LoadField: r2 = r3->field_7
    //     0xbbbbbc: ldur            w2, [x3, #7]
    // 0xbbbbc0: DecompressPointer r2
    //     0xbbbbc0: add             x2, x2, HEAP, lsl #32
    // 0xbbbbc4: mov             x0, x4
    // 0xbbbbc8: r1 = Null
    //     0xbbbbc8: mov             x1, NULL
    // 0xbbbbcc: cmp             w0, NULL
    // 0xbbbbd0: b.eq            #0xbbbbf8
    // 0xbbbbd4: cmp             w2, NULL
    // 0xbbbbd8: b.eq            #0xbbbbf8
    // 0xbbbbdc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbbbbdc: ldur            w4, [x2, #0x17]
    // 0xbbbbe0: DecompressPointer r4
    //     0xbbbbe0: add             x4, x4, HEAP, lsl #32
    // 0xbbbbe4: r8 = X0?
    //     0xbbbbe4: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xbbbbe8: LoadField: r9 = r4->field_7
    //     0xbbbbe8: ldur            x9, [x4, #7]
    // 0xbbbbec: r3 = Null
    //     0xbbbbec: add             x3, PP, #0xab, lsl #12  ; [pp+0xab7e0] Null
    //     0xbbbbf0: ldr             x3, [x3, #0x7e0]
    // 0xbbbbf4: blr             x9
    // 0xbbbbf8: ldur            x0, [fp, #-8]
    // 0xbbbbfc: ldur            x1, [fp, #-0x10]
    // 0xbbbc00: StoreField: r1->field_f = r0
    //     0xbbbc00: stur            w0, [x1, #0xf]
    //     0xbbbc04: ldurb           w16, [x1, #-1]
    //     0xbbbc08: ldurb           w17, [x0, #-1]
    //     0xbbbc0c: and             x16, x17, x16, lsr #2
    //     0xbbbc10: tst             x16, HEAP, lsr #32
    //     0xbbbc14: b.eq            #0xbbbc1c
    //     0xbbbc18: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbbc1c: ldur            x0, [fp, #-8]
    // 0xbbbc20: StoreField: r1->field_b = r0
    //     0xbbbc20: stur            w0, [x1, #0xb]
    //     0xbbbc24: ldurb           w16, [x1, #-1]
    //     0xbbbc28: ldurb           w17, [x0, #-1]
    //     0xbbbc2c: and             x16, x17, x16, lsr #2
    //     0xbbbc30: tst             x16, HEAP, lsr #32
    //     0xbbbc34: b.eq            #0xbbbc3c
    //     0xbbbc38: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbbc3c: b               #0xbbbc68
    // 0xbbbc40: LoadField: r0 = r1->field_2f
    //     0xbbbc40: ldur            w0, [x1, #0x2f]
    // 0xbbbc44: DecompressPointer r0
    //     0xbbbc44: add             x0, x0, HEAP, lsl #32
    // 0xbbbc48: cmp             w0, NULL
    // 0xbbbc4c: b.eq            #0xbbbc60
    // 0xbbbc50: LoadField: r2 = r0->field_7
    //     0xbbbc50: ldur            w2, [x0, #7]
    // 0xbbbc54: DecompressPointer r2
    //     0xbbbc54: add             x2, x2, HEAP, lsl #32
    // 0xbbbc58: cmp             w2, NULL
    // 0xbbbc5c: b.ne            #0xbbbc68
    // 0xbbbc60: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbbc60: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbbc64: r0 = forward()
    //     0xbbbc64: bl              #0x8cd83c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xbbbc68: r0 = Null
    //     0xbbbc68: mov             x0, NULL
    // 0xbbbc6c: LeaveFrame
    //     0xbbbc6c: mov             SP, fp
    //     0xbbbc70: ldp             fp, lr, [SP], #0x10
    // 0xbbbc74: ret
    //     0xbbbc74: ret             
    // 0xbbbc78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbbc78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbbc7c: b               #0xbbb9f0
    // 0xbbbc80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbbc80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbbc84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbbc84: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbbc88: r9 = _controller
    //     0xbbbc88: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xbbbc8c: ldr             x9, [x9, #0x4a8]
    // 0xbbbc90: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbbbc90: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbbbc94: r9 = _value
    //     0xbbbc94: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0xbbbc98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbbbc98: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbbbc9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbbc9c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _layoutStart(/* No info */) {
    // ** addr: 0xbbbca0, size: 0xf8
    // 0xbbbca0: EnterFrame
    //     0xbbbca0: stp             fp, lr, [SP, #-0x10]!
    //     0xbbbca4: mov             fp, SP
    // 0xbbbca8: AllocStack(0x18)
    //     0xbbbca8: sub             SP, SP, #0x18
    // 0xbbbcac: SetupParameters(RenderAnimatedSize this /* r1 => r0, fp-0x10 */)
    //     0xbbbcac: mov             x0, x1
    //     0xbbbcb0: stur            x1, [fp, #-0x10]
    // 0xbbbcb4: CheckStackOverflow
    //     0xbbbcb4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbbcb8: cmp             SP, x16
    //     0xbbbcbc: b.ls            #0xbbbd8c
    // 0xbbbcc0: LoadField: r2 = r0->field_67
    //     0xbbbcc0: ldur            w2, [x0, #0x67]
    // 0xbbbcc4: DecompressPointer r2
    //     0xbbbcc4: add             x2, x2, HEAP, lsl #32
    // 0xbbbcc8: stur            x2, [fp, #-8]
    // 0xbbbccc: LoadField: r1 = r0->field_4f
    //     0xbbbccc: ldur            w1, [x0, #0x4f]
    // 0xbbbcd0: DecompressPointer r1
    //     0xbbbcd0: add             x1, x1, HEAP, lsl #32
    // 0xbbbcd4: cmp             w1, NULL
    // 0xbbbcd8: b.eq            #0xbbbd94
    // 0xbbbcdc: r0 = size()
    //     0xbbbcdc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbbce0: mov             x4, x0
    // 0xbbbce4: ldur            x3, [fp, #-8]
    // 0xbbbce8: stur            x4, [fp, #-0x18]
    // 0xbbbcec: LoadField: r2 = r3->field_7
    //     0xbbbcec: ldur            w2, [x3, #7]
    // 0xbbbcf0: DecompressPointer r2
    //     0xbbbcf0: add             x2, x2, HEAP, lsl #32
    // 0xbbbcf4: mov             x0, x4
    // 0xbbbcf8: r1 = Null
    //     0xbbbcf8: mov             x1, NULL
    // 0xbbbcfc: cmp             w0, NULL
    // 0xbbbd00: b.eq            #0xbbbd28
    // 0xbbbd04: cmp             w2, NULL
    // 0xbbbd08: b.eq            #0xbbbd28
    // 0xbbbd0c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbbbd0c: ldur            w4, [x2, #0x17]
    // 0xbbbd10: DecompressPointer r4
    //     0xbbbd10: add             x4, x4, HEAP, lsl #32
    // 0xbbbd14: r8 = X0?
    //     0xbbbd14: ldr             x8, [PP, #0x75c8]  ; [pp+0x75c8] TypeParameter: X0?
    // 0xbbbd18: LoadField: r9 = r4->field_7
    //     0xbbbd18: ldur            x9, [x4, #7]
    // 0xbbbd1c: r3 = Null
    //     0xbbbd1c: add             x3, PP, #0xab, lsl #12  ; [pp+0xab7f0] Null
    //     0xbbbd20: ldr             x3, [x3, #0x7f0]
    // 0xbbbd24: blr             x9
    // 0xbbbd28: ldur            x0, [fp, #-0x18]
    // 0xbbbd2c: ldur            x1, [fp, #-8]
    // 0xbbbd30: StoreField: r1->field_f = r0
    //     0xbbbd30: stur            w0, [x1, #0xf]
    //     0xbbbd34: ldurb           w16, [x1, #-1]
    //     0xbbbd38: ldurb           w17, [x0, #-1]
    //     0xbbbd3c: and             x16, x17, x16, lsr #2
    //     0xbbbd40: tst             x16, HEAP, lsr #32
    //     0xbbbd44: b.eq            #0xbbbd4c
    //     0xbbbd48: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbbd4c: ldur            x0, [fp, #-0x18]
    // 0xbbbd50: StoreField: r1->field_b = r0
    //     0xbbbd50: stur            w0, [x1, #0xb]
    //     0xbbbd54: ldurb           w16, [x1, #-1]
    //     0xbbbd58: ldurb           w17, [x0, #-1]
    //     0xbbbd5c: and             x16, x17, x16, lsr #2
    //     0xbbbd60: tst             x16, HEAP, lsr #32
    //     0xbbbd64: b.eq            #0xbbbd6c
    //     0xbbbd68: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbbd6c: ldur            x2, [fp, #-0x10]
    // 0xbbbd70: r1 = Instance_RenderAnimatedSizeState
    //     0xbbbd70: add             x1, PP, #0xab, lsl #12  ; [pp+0xab798] Obj!RenderAnimatedSizeState@12c4701
    //     0xbbbd74: ldr             x1, [x1, #0x798]
    // 0xbbbd78: StoreField: r2->field_73 = r1
    //     0xbbbd78: stur            w1, [x2, #0x73]
    // 0xbbbd7c: r0 = Null
    //     0xbbbd7c: mov             x0, NULL
    // 0xbbbd80: LeaveFrame
    //     0xbbbd80: mov             SP, fp
    //     0xbbbd84: ldp             fp, lr, [SP], #0x10
    // 0xbbbd88: ret
    //     0xbbbd88: ret             
    // 0xbbbd8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbbd8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbbd90: b               #0xbbbcc0
    // 0xbbbd94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbbd94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xc030dc, size: 0xa0
    // 0xc030dc: EnterFrame
    //     0xc030dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc030e0: mov             fp, SP
    // 0xc030e4: AllocStack(0x8)
    //     0xc030e4: sub             SP, SP, #8
    // 0xc030e8: SetupParameters(RenderAnimatedSize this /* r1 => r0, fp-0x8 */)
    //     0xc030e8: mov             x0, x1
    //     0xc030ec: stur            x1, [fp, #-8]
    // 0xc030f0: CheckStackOverflow
    //     0xc030f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc030f4: cmp             SP, x16
    //     0xc030f8: b.ls            #0xc0315c
    // 0xc030fc: LoadField: r1 = r0->field_87
    //     0xc030fc: ldur            w1, [x0, #0x87]
    // 0xc03100: DecompressPointer r1
    //     0xc03100: add             x1, x1, HEAP, lsl #32
    // 0xc03104: r2 = Null
    //     0xc03104: mov             x2, NULL
    // 0xc03108: r0 = layer=()
    //     0xc03108: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc0310c: ldur            x0, [fp, #-8]
    // 0xc03110: LoadField: r1 = r0->field_5f
    //     0xc03110: ldur            w1, [x0, #0x5f]
    // 0xc03114: DecompressPointer r1
    //     0xc03114: add             x1, x1, HEAP, lsl #32
    // 0xc03118: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0311c: cmp             w1, w16
    // 0xc03120: b.eq            #0xc03164
    // 0xc03124: r0 = dispose()
    //     0xc03124: bl              #0x9164f4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xc03128: ldur            x0, [fp, #-8]
    // 0xc0312c: LoadField: r1 = r0->field_63
    //     0xc0312c: ldur            w1, [x0, #0x63]
    // 0xc03130: DecompressPointer r1
    //     0xc03130: add             x1, x1, HEAP, lsl #32
    // 0xc03134: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc03138: cmp             w1, w16
    // 0xc0313c: b.eq            #0xc03170
    // 0xc03140: r0 = dispose()
    //     0xc03140: bl              #0xb29014  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::dispose
    // 0xc03144: ldur            x1, [fp, #-8]
    // 0xc03148: r0 = dispose()
    //     0xc03148: bl              #0xc04c8c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0xc0314c: r0 = Null
    //     0xc0314c: mov             x0, NULL
    // 0xc03150: LeaveFrame
    //     0xc03150: mov             SP, fp
    //     0xc03154: ldp             fp, lr, [SP], #0x10
    // 0xc03158: ret
    //     0xc03158: ret             
    // 0xc0315c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0315c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc03160: b               #0xc030fc
    // 0xc03164: r9 = _controller
    //     0xc03164: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xc03168: ldr             x9, [x9, #0x4a8]
    // 0xc0316c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc0316c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc03170: r9 = _animation
    //     0xc03170: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34b0] Field <RenderAnimatedSize._animation@600160358>: late final (offset: 0x64)
    //     0xc03174: ldr             x9, [x9, #0x4b0]
    // 0xc03178: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc03178: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xc05fe0, size: 0x94
    // 0xc05fe0: EnterFrame
    //     0xc05fe0: stp             fp, lr, [SP, #-0x10]!
    //     0xc05fe4: mov             fp, SP
    // 0xc05fe8: AllocStack(0x10)
    //     0xc05fe8: sub             SP, SP, #0x10
    // 0xc05fec: SetupParameters(RenderAnimatedSize this /* r1 => r2, fp-0x8 */)
    //     0xc05fec: mov             x2, x1
    //     0xc05ff0: stur            x1, [fp, #-8]
    // 0xc05ff4: CheckStackOverflow
    //     0xc05ff4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc05ff8: cmp             SP, x16
    //     0xc05ffc: b.ls            #0xc06060
    // 0xc06000: LoadField: r1 = r2->field_5f
    //     0xc06000: ldur            w1, [x2, #0x5f]
    // 0xc06004: DecompressPointer r1
    //     0xc06004: add             x1, x1, HEAP, lsl #32
    // 0xc06008: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc0600c: cmp             w1, w16
    // 0xc06010: b.eq            #0xc06068
    // 0xc06014: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc06014: ldr             x4, [PP, #0xe8]  ; [pp+0xe8] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc06018: r0 = stop()
    //     0xc06018: bl              #0x82eb24  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xc0601c: ldur            x0, [fp, #-8]
    // 0xc06020: LoadField: r3 = r0->field_5f
    //     0xc06020: ldur            w3, [x0, #0x5f]
    // 0xc06024: DecompressPointer r3
    //     0xc06024: add             x3, x3, HEAP, lsl #32
    // 0xc06028: mov             x2, x0
    // 0xc0602c: stur            x3, [fp, #-0x10]
    // 0xc06030: r1 = Function '_animationStatusListener@600160358':.
    //     0xc06030: add             x1, PP, #0xab, lsl #12  ; [pp+0xab800] AnonymousClosure: (0xc06074), in [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xc06034: ldr             x1, [x1, #0x800]
    // 0xc06038: r0 = AllocateClosure()
    //     0xc06038: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0603c: ldur            x1, [fp, #-0x10]
    // 0xc06040: mov             x2, x0
    // 0xc06044: r0 = removeStatusListener()
    //     0xc06044: bl              #0x12599f4  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0xc06048: ldur            x1, [fp, #-8]
    // 0xc0604c: r0 = detach()
    //     0xc0604c: bl              #0xc061c8  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::detach
    // 0xc06050: r0 = Null
    //     0xc06050: mov             x0, NULL
    // 0xc06054: LeaveFrame
    //     0xc06054: mov             SP, fp
    //     0xc06058: ldp             fp, lr, [SP], #0x10
    // 0xc0605c: ret
    //     0xc0605c: ret             
    // 0xc06060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc06060: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc06064: b               #0xc06000
    // 0xc06068: r9 = _controller
    //     0xc06068: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xc0606c: ldr             x9, [x9, #0x4a8]
    // 0xc06070: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc06070: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _animationStatusListener(dynamic, AnimationStatus) {
    // ** addr: 0xc06074, size: 0x3c
    // 0xc06074: EnterFrame
    //     0xc06074: stp             fp, lr, [SP, #-0x10]!
    //     0xc06078: mov             fp, SP
    // 0xc0607c: ldr             x0, [fp, #0x18]
    // 0xc06080: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc06080: ldur            w1, [x0, #0x17]
    // 0xc06084: DecompressPointer r1
    //     0xc06084: add             x1, x1, HEAP, lsl #32
    // 0xc06088: CheckStackOverflow
    //     0xc06088: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0608c: cmp             SP, x16
    //     0xc06090: b.ls            #0xc060a8
    // 0xc06094: ldr             x2, [fp, #0x10]
    // 0xc06098: r0 = Shader._()
    //     0xc06098: bl              #0x13cf838  ; [dart:ui] Shader::Shader._
    // 0xc0609c: LeaveFrame
    //     0xc0609c: mov             SP, fp
    //     0xc060a0: ldp             fp, lr, [SP], #0x10
    // 0xc060a4: ret
    //     0xc060a4: ret             
    // 0xc060a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc060a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc060ac: b               #0xc06094
  }
  _ attach(/* No info */) {
    // ** addr: 0xc09920, size: 0xa8
    // 0xc09920: EnterFrame
    //     0xc09920: stp             fp, lr, [SP, #-0x10]!
    //     0xc09924: mov             fp, SP
    // 0xc09928: AllocStack(0x10)
    //     0xc09928: sub             SP, SP, #0x10
    // 0xc0992c: SetupParameters(RenderAnimatedSize this /* r1 => r0, fp-0x8 */)
    //     0xc0992c: mov             x0, x1
    //     0xc09930: stur            x1, [fp, #-8]
    // 0xc09934: CheckStackOverflow
    //     0xc09934: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc09938: cmp             SP, x16
    //     0xc0993c: b.ls            #0xc099b4
    // 0xc09940: mov             x1, x0
    // 0xc09944: r0 = attach()
    //     0xc09944: bl              #0xc09a60  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::attach
    // 0xc09948: ldur            x0, [fp, #-8]
    // 0xc0994c: LoadField: r1 = r0->field_73
    //     0xc0994c: ldur            w1, [x0, #0x73]
    // 0xc09950: DecompressPointer r1
    //     0xc09950: add             x1, x1, HEAP, lsl #32
    // 0xc09954: LoadField: r2 = r1->field_7
    //     0xc09954: ldur            x2, [x1, #7]
    // 0xc09958: cmp             x2, #1
    // 0xc0995c: b.gt            #0xc09968
    // 0xc09960: mov             x2, x0
    // 0xc09964: b               #0xc09974
    // 0xc09968: mov             x1, x0
    // 0xc0996c: r0 = markNeedsLayout()
    //     0xc0996c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xc09970: ldur            x2, [fp, #-8]
    // 0xc09974: LoadField: r0 = r2->field_5f
    //     0xc09974: ldur            w0, [x2, #0x5f]
    // 0xc09978: DecompressPointer r0
    //     0xc09978: add             x0, x0, HEAP, lsl #32
    // 0xc0997c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc09980: cmp             w0, w16
    // 0xc09984: b.eq            #0xc099bc
    // 0xc09988: stur            x0, [fp, #-0x10]
    // 0xc0998c: r1 = Function '_animationStatusListener@600160358':.
    //     0xc0998c: add             x1, PP, #0xab, lsl #12  ; [pp+0xab800] AnonymousClosure: (0xc06074), in [dart:ui] Shader::Shader._ (0x13cf838)
    //     0xc09990: ldr             x1, [x1, #0x800]
    // 0xc09994: r0 = AllocateClosure()
    //     0xc09994: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc09998: ldur            x1, [fp, #-0x10]
    // 0xc0999c: mov             x2, x0
    // 0xc099a0: r0 = addStatusListener()
    //     0xc099a0: bl              #0x1254cc0  ; [dart:mixin_deduplication] _MixinApplication456&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0xc099a4: r0 = Null
    //     0xc099a4: mov             x0, NULL
    // 0xc099a8: LeaveFrame
    //     0xc099a8: mov             SP, fp
    //     0xc099ac: ldp             fp, lr, [SP], #0x10
    // 0xc099b0: ret
    //     0xc099b0: ret             
    // 0xc099b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc099b4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc099b8: b               #0xc09940
    // 0xc099bc: r9 = _controller
    //     0xc099bc: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xc099c0: ldr             x9, [x9, #0x4a8]
    // 0xc099c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc099c4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc1fcb0, size: 0x14c
    // 0xc1fcb0: EnterFrame
    //     0xc1fcb0: stp             fp, lr, [SP, #-0x10]!
    //     0xc1fcb4: mov             fp, SP
    // 0xc1fcb8: AllocStack(0x48)
    //     0xc1fcb8: sub             SP, SP, #0x48
    // 0xc1fcbc: SetupParameters(RenderAnimatedSize this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc1fcbc: mov             x0, x2
    //     0xc1fcc0: stur            x2, [fp, #-0x10]
    //     0xc1fcc4: mov             x2, x1
    //     0xc1fcc8: stur            x1, [fp, #-8]
    //     0xc1fccc: stur            x3, [fp, #-0x18]
    // 0xc1fcd0: CheckStackOverflow
    //     0xc1fcd0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1fcd4: cmp             SP, x16
    //     0xc1fcd8: b.ls            #0xc1fde0
    // 0xc1fcdc: LoadField: r1 = r2->field_4f
    //     0xc1fcdc: ldur            w1, [x2, #0x4f]
    // 0xc1fce0: DecompressPointer r1
    //     0xc1fce0: add             x1, x1, HEAP, lsl #32
    // 0xc1fce4: cmp             w1, NULL
    // 0xc1fce8: b.eq            #0xc1fdac
    // 0xc1fcec: LoadField: r1 = r2->field_6b
    //     0xc1fcec: ldur            w1, [x2, #0x6b]
    // 0xc1fcf0: DecompressPointer r1
    //     0xc1fcf0: add             x1, x1, HEAP, lsl #32
    // 0xc1fcf4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1fcf8: cmp             w1, w16
    // 0xc1fcfc: b.eq            #0xc1fde8
    // 0xc1fd00: tbnz            w1, #4, #0xc1fda4
    // 0xc1fd04: mov             x1, x2
    // 0xc1fd08: r0 = size()
    //     0xc1fd08: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc1fd0c: mov             x2, x0
    // 0xc1fd10: r1 = Instance_Offset
    //     0xc1fd10: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc1fd14: r0 = &()
    //     0xc1fd14: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc1fd18: mov             x3, x0
    // 0xc1fd1c: ldur            x0, [fp, #-8]
    // 0xc1fd20: stur            x3, [fp, #-0x38]
    // 0xc1fd24: LoadField: r4 = r0->field_87
    //     0xc1fd24: ldur            w4, [x0, #0x87]
    // 0xc1fd28: DecompressPointer r4
    //     0xc1fd28: add             x4, x4, HEAP, lsl #32
    // 0xc1fd2c: stur            x4, [fp, #-0x30]
    // 0xc1fd30: LoadField: r5 = r0->field_37
    //     0xc1fd30: ldur            w5, [x0, #0x37]
    // 0xc1fd34: DecompressPointer r5
    //     0xc1fd34: add             x5, x5, HEAP, lsl #32
    // 0xc1fd38: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc1fd3c: cmp             w5, w16
    // 0xc1fd40: b.eq            #0xc1fdf4
    // 0xc1fd44: stur            x5, [fp, #-0x28]
    // 0xc1fd48: LoadField: r6 = r4->field_b
    //     0xc1fd48: ldur            w6, [x4, #0xb]
    // 0xc1fd4c: DecompressPointer r6
    //     0xc1fd4c: add             x6, x6, HEAP, lsl #32
    // 0xc1fd50: mov             x2, x0
    // 0xc1fd54: stur            x6, [fp, #-0x20]
    // 0xc1fd58: r1 = Function 'paint':.
    //     0xc1fd58: add             x1, PP, #0xa2, lsl #12  ; [pp+0xa2900] AnonymousClosure: (0xc1fc70), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint (0xc20b90)
    //     0xc1fd5c: ldr             x1, [x1, #0x900]
    // 0xc1fd60: r0 = AllocateClosure()
    //     0xc1fd60: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1fd64: r16 = Instance_Clip
    //     0xc1fd64: add             x16, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0xc1fd68: ldr             x16, [x16, #0x850]
    // 0xc1fd6c: ldur            lr, [fp, #-0x20]
    // 0xc1fd70: stp             lr, x16, [SP]
    // 0xc1fd74: ldur            x1, [fp, #-0x10]
    // 0xc1fd78: ldur            x2, [fp, #-0x28]
    // 0xc1fd7c: ldur            x3, [fp, #-0x18]
    // 0xc1fd80: ldur            x5, [fp, #-0x38]
    // 0xc1fd84: mov             x6, x0
    // 0xc1fd88: r4 = const [0, 0x7, 0x2, 0x5, clipBehavior, 0x5, oldLayer, 0x6, null]
    //     0xc1fd88: add             x4, PP, #0x90, lsl #12  ; [pp+0x90688] List(9) [0, 0x7, 0x2, 0x5, "clipBehavior", 0x5, "oldLayer", 0x6, Null]
    //     0xc1fd8c: ldr             x4, [x4, #0x688]
    // 0xc1fd90: r0 = pushClipRect()
    //     0xc1fd90: bl              #0xc19194  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0xc1fd94: ldur            x1, [fp, #-0x30]
    // 0xc1fd98: mov             x2, x0
    // 0xc1fd9c: r0 = layer=()
    //     0xc1fd9c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1fda0: b               #0xc1fdd0
    // 0xc1fda4: mov             x0, x2
    // 0xc1fda8: b               #0xc1fdb0
    // 0xc1fdac: mov             x0, x2
    // 0xc1fdb0: LoadField: r1 = r0->field_87
    //     0xc1fdb0: ldur            w1, [x0, #0x87]
    // 0xc1fdb4: DecompressPointer r1
    //     0xc1fdb4: add             x1, x1, HEAP, lsl #32
    // 0xc1fdb8: r2 = Null
    //     0xc1fdb8: mov             x2, NULL
    // 0xc1fdbc: r0 = layer=()
    //     0xc1fdbc: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc1fdc0: ldur            x1, [fp, #-8]
    // 0xc1fdc4: ldur            x2, [fp, #-0x10]
    // 0xc1fdc8: ldur            x3, [fp, #-0x18]
    // 0xc1fdcc: r0 = paint()
    //     0xc1fdcc: bl              #0xc20b90  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::paint
    // 0xc1fdd0: r0 = Null
    //     0xc1fdd0: mov             x0, NULL
    // 0xc1fdd4: LeaveFrame
    //     0xc1fdd4: mov             SP, fp
    //     0xc1fdd8: ldp             fp, lr, [SP], #0x10
    // 0xc1fddc: ret
    //     0xc1fddc: ret             
    // 0xc1fde0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1fde0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1fde4: b               #0xc1fcdc
    // 0xc1fde8: r9 = _hasVisualOverflow
    //     0xc1fde8: add             x9, PP, #0xab, lsl #12  ; [pp+0xab758] Field <RenderAnimatedSize._hasVisualOverflow@600160358>: late (offset: 0x6c)
    //     0xc1fdec: ldr             x9, [x9, #0x758]
    // 0xc1fdf0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1fdf0: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc1fdf4: r9 = _needsCompositing
    //     0xc1fdf4: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc1fdf8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc1fdf8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ vsync=(/* No info */) {
    // ** addr: 0xcf4f64, size: 0xa4
    // 0xcf4f64: EnterFrame
    //     0xcf4f64: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4f68: mov             fp, SP
    // 0xcf4f6c: mov             x16, x2
    // 0xcf4f70: mov             x2, x1
    // 0xcf4f74: mov             x1, x16
    // 0xcf4f78: CheckStackOverflow
    //     0xcf4f78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf4f7c: cmp             SP, x16
    //     0xcf4f80: b.ls            #0xcf4ff4
    // 0xcf4f84: LoadField: r0 = r2->field_7b
    //     0xcf4f84: ldur            w0, [x2, #0x7b]
    // 0xcf4f88: DecompressPointer r0
    //     0xcf4f88: add             x0, x0, HEAP, lsl #32
    // 0xcf4f8c: cmp             w1, w0
    // 0xcf4f90: b.ne            #0xcf4fa4
    // 0xcf4f94: r0 = Null
    //     0xcf4f94: mov             x0, NULL
    // 0xcf4f98: LeaveFrame
    //     0xcf4f98: mov             SP, fp
    //     0xcf4f9c: ldp             fp, lr, [SP], #0x10
    // 0xcf4fa0: ret
    //     0xcf4fa0: ret             
    // 0xcf4fa4: mov             x0, x1
    // 0xcf4fa8: StoreField: r2->field_7b = r0
    //     0xcf4fa8: stur            w0, [x2, #0x7b]
    //     0xcf4fac: ldurb           w16, [x2, #-1]
    //     0xcf4fb0: ldurb           w17, [x0, #-1]
    //     0xcf4fb4: and             x16, x17, x16, lsr #2
    //     0xcf4fb8: tst             x16, HEAP, lsr #32
    //     0xcf4fbc: b.eq            #0xcf4fc4
    //     0xcf4fc0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf4fc4: LoadField: r0 = r2->field_5f
    //     0xcf4fc4: ldur            w0, [x2, #0x5f]
    // 0xcf4fc8: DecompressPointer r0
    //     0xcf4fc8: add             x0, x0, HEAP, lsl #32
    // 0xcf4fcc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf4fd0: cmp             w0, w16
    // 0xcf4fd4: b.eq            #0xcf4ffc
    // 0xcf4fd8: mov             x2, x1
    // 0xcf4fdc: mov             x1, x0
    // 0xcf4fe0: r0 = resync()
    //     0xcf4fe0: bl              #0xcf5008  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::resync
    // 0xcf4fe4: r0 = Null
    //     0xcf4fe4: mov             x0, NULL
    // 0xcf4fe8: LeaveFrame
    //     0xcf4fe8: mov             SP, fp
    //     0xcf4fec: ldp             fp, lr, [SP], #0x10
    // 0xcf4ff0: ret
    //     0xcf4ff0: ret             
    // 0xcf4ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4ff4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4ff8: b               #0xcf4f84
    // 0xcf4ffc: r9 = _controller
    //     0xcf4ffc: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xcf5000: ldr             x9, [x9, #0x4a8]
    // 0xcf5004: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcf5004: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ curve=(/* No info */) {
    // ** addr: 0xcf51d0, size: 0x70
    // 0xcf51d0: mov             x0, x2
    // 0xcf51d4: LoadField: r2 = r1->field_63
    //     0xcf51d4: ldur            w2, [x1, #0x63]
    // 0xcf51d8: DecompressPointer r2
    //     0xcf51d8: add             x2, x2, HEAP, lsl #32
    // 0xcf51dc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf51e0: cmp             w2, w16
    // 0xcf51e4: b.eq            #0xcf522c
    // 0xcf51e8: LoadField: r1 = r2->field_f
    //     0xcf51e8: ldur            w1, [x2, #0xf]
    // 0xcf51ec: DecompressPointer r1
    //     0xcf51ec: add             x1, x1, HEAP, lsl #32
    // 0xcf51f0: cmp             w0, w1
    // 0xcf51f4: b.ne            #0xcf5200
    // 0xcf51f8: r0 = Null
    //     0xcf51f8: mov             x0, NULL
    // 0xcf51fc: ret
    //     0xcf51fc: ret             
    // 0xcf5200: StoreField: r2->field_f = r0
    //     0xcf5200: stur            w0, [x2, #0xf]
    //     0xcf5204: ldurb           w16, [x2, #-1]
    //     0xcf5208: ldurb           w17, [x0, #-1]
    //     0xcf520c: and             x16, x17, x16, lsr #2
    //     0xcf5210: tst             x16, HEAP, lsr #32
    //     0xcf5214: b.eq            #0xcf5224
    //     0xcf5218: str             lr, [SP, #-8]!
    //     0xcf521c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    //     0xcf5220: ldr             lr, [SP], #8
    // 0xcf5224: r0 = Null
    //     0xcf5224: mov             x0, NULL
    // 0xcf5228: ret
    //     0xcf5228: ret             
    // 0xcf522c: EnterFrame
    //     0xcf522c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5230: mov             fp, SP
    // 0xcf5234: r9 = _animation
    //     0xcf5234: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34b0] Field <RenderAnimatedSize._animation@600160358>: late final (offset: 0x64)
    //     0xcf5238: ldr             x9, [x9, #0x4b0]
    // 0xcf523c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcf523c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ reverseDuration=(/* No info */) {
    // ** addr: 0xcf5240, size: 0x4c
    // 0xcf5240: LoadField: r2 = r1->field_5f
    //     0xcf5240: ldur            w2, [x1, #0x5f]
    // 0xcf5244: DecompressPointer r2
    //     0xcf5244: add             x2, x2, HEAP, lsl #32
    // 0xcf5248: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf524c: cmp             w2, w16
    // 0xcf5250: b.eq            #0xcf5278
    // 0xcf5254: LoadField: r1 = r2->field_2b
    //     0xcf5254: ldur            w1, [x2, #0x2b]
    // 0xcf5258: DecompressPointer r1
    //     0xcf5258: add             x1, x1, HEAP, lsl #32
    // 0xcf525c: cmp             w1, NULL
    // 0xcf5260: b.ne            #0xcf526c
    // 0xcf5264: r0 = Null
    //     0xcf5264: mov             x0, NULL
    // 0xcf5268: ret
    //     0xcf5268: ret             
    // 0xcf526c: StoreField: r2->field_2b = rNULL
    //     0xcf526c: stur            NULL, [x2, #0x2b]
    // 0xcf5270: r0 = Null
    //     0xcf5270: mov             x0, NULL
    // 0xcf5274: ret
    //     0xcf5274: ret             
    // 0xcf5278: EnterFrame
    //     0xcf5278: stp             fp, lr, [SP, #-0x10]!
    //     0xcf527c: mov             fp, SP
    // 0xcf5280: r9 = _controller
    //     0xcf5280: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xcf5284: ldr             x9, [x9, #0x4a8]
    // 0xcf5288: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcf5288: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ duration=(/* No info */) {
    // ** addr: 0xcf528c, size: 0xac
    // 0xcf528c: EnterFrame
    //     0xcf528c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf5290: mov             fp, SP
    // 0xcf5294: AllocStack(0x20)
    //     0xcf5294: sub             SP, SP, #0x20
    // 0xcf5298: SetupParameters(RenderAnimatedSize this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xcf5298: mov             x0, x2
    //     0xcf529c: stur            x1, [fp, #-8]
    //     0xcf52a0: stur            x2, [fp, #-0x10]
    // 0xcf52a4: CheckStackOverflow
    //     0xcf52a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf52a8: cmp             SP, x16
    //     0xcf52ac: b.ls            #0xcf5324
    // 0xcf52b0: LoadField: r2 = r1->field_5f
    //     0xcf52b0: ldur            w2, [x1, #0x5f]
    // 0xcf52b4: DecompressPointer r2
    //     0xcf52b4: add             x2, x2, HEAP, lsl #32
    // 0xcf52b8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xcf52bc: cmp             w2, w16
    // 0xcf52c0: b.eq            #0xcf532c
    // 0xcf52c4: LoadField: r3 = r2->field_27
    //     0xcf52c4: ldur            w3, [x2, #0x27]
    // 0xcf52c8: DecompressPointer r3
    //     0xcf52c8: add             x3, x3, HEAP, lsl #32
    // 0xcf52cc: stp             x3, x0, [SP]
    // 0xcf52d0: r0 = ==()
    //     0xcf52d0: bl              #0x124ef40  ; [dart:core] Duration::==
    // 0xcf52d4: tbnz            w0, #4, #0xcf52e8
    // 0xcf52d8: r0 = Null
    //     0xcf52d8: mov             x0, NULL
    // 0xcf52dc: LeaveFrame
    //     0xcf52dc: mov             SP, fp
    //     0xcf52e0: ldp             fp, lr, [SP], #0x10
    // 0xcf52e4: ret
    //     0xcf52e4: ret             
    // 0xcf52e8: ldur            x1, [fp, #-8]
    // 0xcf52ec: LoadField: r2 = r1->field_5f
    //     0xcf52ec: ldur            w2, [x1, #0x5f]
    // 0xcf52f0: DecompressPointer r2
    //     0xcf52f0: add             x2, x2, HEAP, lsl #32
    // 0xcf52f4: ldur            x0, [fp, #-0x10]
    // 0xcf52f8: StoreField: r2->field_27 = r0
    //     0xcf52f8: stur            w0, [x2, #0x27]
    //     0xcf52fc: ldurb           w16, [x2, #-1]
    //     0xcf5300: ldurb           w17, [x0, #-1]
    //     0xcf5304: and             x16, x17, x16, lsr #2
    //     0xcf5308: tst             x16, HEAP, lsr #32
    //     0xcf530c: b.eq            #0xcf5314
    //     0xcf5310: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf5314: r0 = Null
    //     0xcf5314: mov             x0, NULL
    // 0xcf5318: LeaveFrame
    //     0xcf5318: mov             SP, fp
    //     0xcf531c: ldp             fp, lr, [SP], #0x10
    // 0xcf5320: ret
    //     0xcf5320: ret             
    // 0xcf5324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5324: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5328: b               #0xcf52b0
    // 0xcf532c: r9 = _controller
    //     0xcf532c: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0xcf5330: ldr             x9, [x9, #0x4a8]
    // 0xcf5334: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcf5334: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ RenderAnimatedSize(/* No info */) {
    // ** addr: 0x11cfd98, size: 0x294
    // 0x11cfd98: EnterFrame
    //     0x11cfd98: stp             fp, lr, [SP, #-0x10]!
    //     0x11cfd9c: mov             fp, SP
    // 0x11cfda0: AllocStack(0x48)
    //     0x11cfda0: sub             SP, SP, #0x48
    // 0x11cfda4: SetupParameters(RenderAnimatedSize this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x28 */, dynamic _ /* r3 => r2, fp-0x30 */, [dynamic _ /* fp-0x20 */])
    //     0x11cfda4: mov             x4, x1
    //     0x11cfda8: stur            x2, [fp, #-0x10]
    //     0x11cfdac: mov             x16, x3
    //     0x11cfdb0: mov             x3, x2
    //     0x11cfdb4: mov             x2, x16
    //     0x11cfdb8: stur            x1, [fp, #-8]
    //     0x11cfdbc: mov             x1, x6
    //     0x11cfdc0: mov             x0, x7
    //     0x11cfdc4: stur            x2, [fp, #-0x18]
    //     0x11cfdc8: stur            x5, [fp, #-0x20]
    //     0x11cfdcc: stur            x6, [fp, #-0x28]
    //     0x11cfdd0: stur            x7, [fp, #-0x30]
    // 0x11cfdd4: CheckStackOverflow
    //     0x11cfdd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cfdd8: cmp             SP, x16
    //     0x11cfddc: b.ls            #0x11d0024
    // 0x11cfde0: r1 = 1
    //     0x11cfde0: mov             x1, #1
    // 0x11cfde4: r0 = AllocateContext()
    //     0x11cfde4: bl              #0x13de838  ; AllocateContextStub
    // 0x11cfde8: mov             x2, x0
    // 0x11cfdec: ldur            x0, [fp, #-8]
    // 0x11cfdf0: stur            x2, [fp, #-0x38]
    // 0x11cfdf4: StoreField: r2->field_f = r0
    //     0x11cfdf4: stur            w0, [x2, #0xf]
    // 0x11cfdf8: ldr             x1, [THR, #0x90]  ; THR::object_sentinel
    // 0x11cfdfc: StoreField: r0->field_5f = r1
    //     0x11cfdfc: stur            w1, [x0, #0x5f]
    // 0x11cfe00: StoreField: r0->field_63 = r1
    //     0x11cfe00: stur            w1, [x0, #0x63]
    // 0x11cfe04: StoreField: r0->field_6b = r1
    //     0x11cfe04: stur            w1, [x0, #0x6b]
    // 0x11cfe08: r3 = Instance_RenderAnimatedSizeState
    //     0x11cfe08: add             x3, PP, #0xa3, lsl #12  ; [pp+0xa34b8] Obj!RenderAnimatedSizeState@12c4761
    //     0x11cfe0c: ldr             x3, [x3, #0x4b8]
    // 0x11cfe10: StoreField: r0->field_73 = r3
    //     0x11cfe10: stur            w3, [x0, #0x73]
    // 0x11cfe14: StoreField: r0->field_83 = r1
    //     0x11cfe14: stur            w1, [x0, #0x83]
    // 0x11cfe18: r1 = <Size?>
    //     0x11cfe18: add             x1, PP, #0x26, lsl #12  ; [pp+0x26aa8] TypeArguments: <Size?>
    //     0x11cfe1c: ldr             x1, [x1, #0xaa8]
    // 0x11cfe20: r0 = SizeTween()
    //     0x11cfe20: bl              #0x11d002c  ; AllocateSizeTweenStub -> SizeTween (size=0x14)
    // 0x11cfe24: ldur            x2, [fp, #-8]
    // 0x11cfe28: StoreField: r2->field_67 = r0
    //     0x11cfe28: stur            w0, [x2, #0x67]
    //     0x11cfe2c: ldurb           w16, [x2, #-1]
    //     0x11cfe30: ldurb           w17, [x0, #-1]
    //     0x11cfe34: and             x16, x17, x16, lsr #2
    //     0x11cfe38: tst             x16, HEAP, lsr #32
    //     0x11cfe3c: b.eq            #0x11cfe44
    //     0x11cfe40: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cfe44: r1 = <ClipRectLayer>
    //     0x11cfe44: add             x1, PP, #0x84, lsl #12  ; [pp+0x84fc8] TypeArguments: <ClipRectLayer>
    //     0x11cfe48: ldr             x1, [x1, #0xfc8]
    // 0x11cfe4c: r0 = LayerHandle()
    //     0x11cfe4c: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11cfe50: ldur            x1, [fp, #-8]
    // 0x11cfe54: StoreField: r1->field_87 = r0
    //     0x11cfe54: stur            w0, [x1, #0x87]
    //     0x11cfe58: ldurb           w16, [x1, #-1]
    //     0x11cfe5c: ldurb           w17, [x0, #-1]
    //     0x11cfe60: and             x16, x17, x16, lsr #2
    //     0x11cfe64: tst             x16, HEAP, lsr #32
    //     0x11cfe68: b.eq            #0x11cfe70
    //     0x11cfe6c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cfe70: ldur            x0, [fp, #-0x30]
    // 0x11cfe74: StoreField: r1->field_7b = r0
    //     0x11cfe74: stur            w0, [x1, #0x7b]
    //     0x11cfe78: ldurb           w16, [x1, #-1]
    //     0x11cfe7c: ldurb           w17, [x0, #-1]
    //     0x11cfe80: and             x16, x17, x16, lsr #2
    //     0x11cfe84: tst             x16, HEAP, lsr #32
    //     0x11cfe88: b.eq            #0x11cfe90
    //     0x11cfe8c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cfe90: r0 = Instance_Clip
    //     0x11cfe90: add             x0, PP, #0x15, lsl #12  ; [pp+0x15850] Obj!Clip@12c80e1
    //     0x11cfe94: ldr             x0, [x0, #0x850]
    // 0x11cfe98: StoreField: r1->field_77 = r0
    //     0x11cfe98: stur            w0, [x1, #0x77]
    // 0x11cfe9c: ldur            x0, [fp, #-0x10]
    // 0x11cfea0: StoreField: r1->field_57 = r0
    //     0x11cfea0: stur            w0, [x1, #0x57]
    //     0x11cfea4: ldurb           w16, [x1, #-1]
    //     0x11cfea8: ldurb           w17, [x0, #-1]
    //     0x11cfeac: and             x16, x17, x16, lsr #2
    //     0x11cfeb0: tst             x16, HEAP, lsr #32
    //     0x11cfeb4: b.eq            #0x11cfebc
    //     0x11cfeb8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cfebc: ldur            x0, [fp, #-0x28]
    // 0x11cfec0: StoreField: r1->field_5b = r0
    //     0x11cfec0: stur            w0, [x1, #0x5b]
    //     0x11cfec4: ldurb           w16, [x1, #-1]
    //     0x11cfec8: ldurb           w17, [x0, #-1]
    //     0x11cfecc: and             x16, x17, x16, lsr #2
    //     0x11cfed0: tst             x16, HEAP, lsr #32
    //     0x11cfed4: b.eq            #0x11cfedc
    //     0x11cfed8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cfedc: r0 = _LayoutCacheStorage()
    //     0x11cfedc: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cfee0: ldur            x2, [fp, #-8]
    // 0x11cfee4: StoreField: r2->field_47 = r0
    //     0x11cfee4: stur            w0, [x2, #0x47]
    //     0x11cfee8: ldurb           w16, [x2, #-1]
    //     0x11cfeec: ldurb           w17, [x0, #-1]
    //     0x11cfef0: and             x16, x17, x16, lsr #2
    //     0x11cfef4: tst             x16, HEAP, lsr #32
    //     0x11cfef8: b.eq            #0x11cff00
    //     0x11cfefc: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cff00: mov             x1, x2
    // 0x11cff04: r0 = RenderObject()
    //     0x11cff04: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cff08: ldur            x1, [fp, #-8]
    // 0x11cff0c: r2 = Null
    //     0x11cff0c: mov             x2, NULL
    // 0x11cff10: r0 = child=()
    //     0x11cff10: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11cff14: r1 = <double>
    //     0x11cff14: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11cff18: r0 = AnimationController()
    //     0x11cff18: bl              #0x87522c  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x11cff1c: stur            x0, [fp, #-0x10]
    // 0x11cff20: ldur            x16, [fp, #-0x20]
    // 0x11cff24: stp             NULL, x16, [SP]
    // 0x11cff28: mov             x1, x0
    // 0x11cff2c: ldur            x2, [fp, #-0x30]
    // 0x11cff30: r4 = const [0, 0x4, 0x2, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0x11cff30: add             x4, PP, #0x1e, lsl #12  ; [pp+0x1e860] List(9) [0, 0x4, 0x2, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0x11cff34: ldr             x4, [x4, #0x860]
    // 0x11cff38: r0 = AnimationController()
    //     0x11cff38: bl              #0x874ea4  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x11cff3c: ldur            x2, [fp, #-0x38]
    // 0x11cff40: r1 = Function '<anonymous closure>':.
    //     0x11cff40: add             x1, PP, #0xa3, lsl #12  ; [pp+0xa34c0] AnonymousClosure: (0x11d0038), in [package:flutter/src/rendering/animated_size.dart] RenderAnimatedSize::RenderAnimatedSize (0x11cfd98)
    //     0x11cff44: ldr             x1, [x1, #0x4c0]
    // 0x11cff48: r0 = AllocateClosure()
    //     0x11cff48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x11cff4c: ldur            x1, [fp, #-0x10]
    // 0x11cff50: mov             x2, x0
    // 0x11cff54: r0 = addListener()
    //     0x11cff54: bl              #0xd0440c  ; [dart:mixin_deduplication] _MixinApplication455&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::addListener
    // 0x11cff58: ldur            x2, [fp, #-8]
    // 0x11cff5c: LoadField: r0 = r2->field_5f
    //     0x11cff5c: ldur            w0, [x2, #0x5f]
    // 0x11cff60: DecompressPointer r0
    //     0x11cff60: add             x0, x0, HEAP, lsl #32
    // 0x11cff64: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11cff68: cmp             w0, w16
    // 0x11cff6c: b.ne            #0x11d0010
    // 0x11cff70: ldur            x0, [fp, #-0x10]
    // 0x11cff74: StoreField: r2->field_5f = r0
    //     0x11cff74: stur            w0, [x2, #0x5f]
    //     0x11cff78: ldurb           w16, [x2, #-1]
    //     0x11cff7c: ldurb           w17, [x0, #-1]
    //     0x11cff80: and             x16, x17, x16, lsr #2
    //     0x11cff84: tst             x16, HEAP, lsr #32
    //     0x11cff88: b.eq            #0x11cff90
    //     0x11cff8c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11cff90: r1 = <double>
    //     0x11cff90: ldr             x1, [PP, #0x4440]  ; [pp+0x4440] TypeArguments: <double>
    // 0x11cff94: r0 = CurvedAnimation()
    //     0x11cff94: bl              #0x915e4c  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x11cff98: mov             x1, x0
    // 0x11cff9c: ldur            x2, [fp, #-0x18]
    // 0x11cffa0: ldur            x3, [fp, #-0x10]
    // 0x11cffa4: stur            x0, [fp, #-0x10]
    // 0x11cffa8: r4 = const [0, 0x3, 0, 0x3, null]
    //     0x11cffa8: ldr             x4, [PP, #0x920]  ; [pp+0x920] List(5) [0, 0x3, 0, 0x3, Null]
    // 0x11cffac: r0 = CurvedAnimation()
    //     0x11cffac: bl              #0x915be4  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x11cffb0: ldur            x1, [fp, #-8]
    // 0x11cffb4: LoadField: r0 = r1->field_63
    //     0x11cffb4: ldur            w0, [x1, #0x63]
    // 0x11cffb8: DecompressPointer r0
    //     0x11cffb8: add             x0, x0, HEAP, lsl #32
    // 0x11cffbc: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11cffc0: cmp             w0, w16
    // 0x11cffc4: b.ne            #0x11cfffc
    // 0x11cffc8: ldur            x0, [fp, #-0x10]
    // 0x11cffcc: StoreField: r1->field_63 = r0
    //     0x11cffcc: stur            w0, [x1, #0x63]
    //     0x11cffd0: ldurb           w16, [x1, #-1]
    //     0x11cffd4: ldurb           w17, [x0, #-1]
    //     0x11cffd8: and             x16, x17, x16, lsr #2
    //     0x11cffdc: tst             x16, HEAP, lsr #32
    //     0x11cffe0: b.eq            #0x11cffe8
    //     0x11cffe4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cffe8: StoreField: r1->field_7f = rNULL
    //     0x11cffe8: stur            NULL, [x1, #0x7f]
    // 0x11cffec: r0 = Null
    //     0x11cffec: mov             x0, NULL
    // 0x11cfff0: LeaveFrame
    //     0x11cfff0: mov             SP, fp
    //     0x11cfff4: ldp             fp, lr, [SP], #0x10
    // 0x11cfff8: ret
    //     0x11cfff8: ret             
    // 0x11cfffc: r16 = "_animation@600160358"
    //     0x11cfffc: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa34c8] "_animation@600160358"
    //     0x11d0000: ldr             x16, [x16, #0x4c8]
    // 0x11d0004: str             x16, [SP]
    // 0x11d0008: r0 = _throwFieldAlreadyInitialized()
    //     0x11d0008: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x11d000c: brk             #0
    // 0x11d0010: r16 = "_controller@600160358"
    //     0x11d0010: add             x16, PP, #0xa3, lsl #12  ; [pp+0xa34d0] "_controller@600160358"
    //     0x11d0014: ldr             x16, [x16, #0x4d0]
    // 0x11d0018: str             x16, [SP]
    // 0x11d001c: r0 = _throwFieldAlreadyInitialized()
    //     0x11d001c: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x11d0020: brk             #0
    // 0x11d0024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d0024: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d0028: b               #0x11cfde0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x11d0038, size: 0xa8
    // 0x11d0038: EnterFrame
    //     0x11d0038: stp             fp, lr, [SP, #-0x10]!
    //     0x11d003c: mov             fp, SP
    // 0x11d0040: AllocStack(0x18)
    //     0x11d0040: sub             SP, SP, #0x18
    // 0x11d0044: SetupParameters([dynamic _ /* r0 */])
    //     0x11d0044: ldr             x0, [fp, #0x10]
    //     0x11d0048: ldur            w1, [x0, #0x17]
    //     0x11d004c: add             x1, x1, HEAP, lsl #32
    //     0x11d0050: stur            x1, [fp, #-8]
    // 0x11d0054: CheckStackOverflow
    //     0x11d0054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d0058: cmp             SP, x16
    //     0x11d005c: b.ls            #0x11d00c4
    // 0x11d0060: LoadField: r0 = r1->field_f
    //     0x11d0060: ldur            w0, [x1, #0xf]
    // 0x11d0064: DecompressPointer r0
    //     0x11d0064: add             x0, x0, HEAP, lsl #32
    // 0x11d0068: LoadField: r2 = r0->field_5f
    //     0x11d0068: ldur            w2, [x0, #0x5f]
    // 0x11d006c: DecompressPointer r2
    //     0x11d006c: add             x2, x2, HEAP, lsl #32
    // 0x11d0070: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11d0074: cmp             w2, w16
    // 0x11d0078: b.eq            #0x11d00cc
    // 0x11d007c: LoadField: r3 = r2->field_37
    //     0x11d007c: ldur            w3, [x2, #0x37]
    // 0x11d0080: DecompressPointer r3
    //     0x11d0080: add             x3, x3, HEAP, lsl #32
    // 0x11d0084: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11d0088: cmp             w3, w16
    // 0x11d008c: b.eq            #0x11d00d8
    // 0x11d0090: LoadField: r2 = r0->field_6f
    //     0x11d0090: ldur            w2, [x0, #0x6f]
    // 0x11d0094: DecompressPointer r2
    //     0x11d0094: add             x2, x2, HEAP, lsl #32
    // 0x11d0098: stp             x2, x3, [SP]
    // 0x11d009c: r0 = ==()
    //     0x11d009c: bl              #0x12b7c00  ; [dart:core] _Double::==
    // 0x11d00a0: tbz             w0, #4, #0x11d00b4
    // 0x11d00a4: ldur            x0, [fp, #-8]
    // 0x11d00a8: LoadField: r1 = r0->field_f
    //     0x11d00a8: ldur            w1, [x0, #0xf]
    // 0x11d00ac: DecompressPointer r1
    //     0x11d00ac: add             x1, x1, HEAP, lsl #32
    // 0x11d00b0: r0 = markNeedsLayout()
    //     0x11d00b0: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x11d00b4: r0 = Null
    //     0x11d00b4: mov             x0, NULL
    // 0x11d00b8: LeaveFrame
    //     0x11d00b8: mov             SP, fp
    //     0x11d00bc: ldp             fp, lr, [SP], #0x10
    // 0x11d00c0: ret
    //     0x11d00c0: ret             
    // 0x11d00c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d00c4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d00c8: b               #0x11d0060
    // 0x11d00cc: r9 = _controller
    //     0x11d00cc: add             x9, PP, #0xa3, lsl #12  ; [pp+0xa34a8] Field <RenderAnimatedSize._controller@600160358>: late final (offset: 0x60)
    //     0x11d00d0: ldr             x9, [x9, #0x4a8]
    // 0x11d00d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11d00d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x11d00d8: r9 = _value
    //     0x11d00d8: ldr             x9, [PP, #0x51b0]  ; [pp+0x51b0] Field <AnimationController._value@62066280>: late (offset: 0x38)
    // 0x11d00dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x11d00dc: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 8240, size: 0x14, field offset: 0x14
enum RenderAnimatedSizeState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11aaea4, size: 0x64
    // 0x11aaea4: EnterFrame
    //     0x11aaea4: stp             fp, lr, [SP, #-0x10]!
    //     0x11aaea8: mov             fp, SP
    // 0x11aaeac: AllocStack(0x10)
    //     0x11aaeac: sub             SP, SP, #0x10
    // 0x11aaeb0: SetupParameters(RenderAnimatedSizeState this /* r1 => r0, fp-0x8 */)
    //     0x11aaeb0: mov             x0, x1
    //     0x11aaeb4: stur            x1, [fp, #-8]
    // 0x11aaeb8: CheckStackOverflow
    //     0x11aaeb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11aaebc: cmp             SP, x16
    //     0x11aaec0: b.ls            #0x11aaf00
    // 0x11aaec4: r1 = Null
    //     0x11aaec4: mov             x1, NULL
    // 0x11aaec8: r2 = 4
    //     0x11aaec8: mov             x2, #4
    // 0x11aaecc: r0 = AllocateArray()
    //     0x11aaecc: bl              #0x13df928  ; AllocateArrayStub
    // 0x11aaed0: r16 = "RenderAnimatedSizeState."
    //     0x11aaed0: add             x16, PP, #0xab, lsl #12  ; [pp+0xab740] "RenderAnimatedSizeState."
    //     0x11aaed4: ldr             x16, [x16, #0x740]
    // 0x11aaed8: StoreField: r0->field_f = r16
    //     0x11aaed8: stur            w16, [x0, #0xf]
    // 0x11aaedc: ldur            x1, [fp, #-8]
    // 0x11aaee0: LoadField: r2 = r1->field_f
    //     0x11aaee0: ldur            w2, [x1, #0xf]
    // 0x11aaee4: DecompressPointer r2
    //     0x11aaee4: add             x2, x2, HEAP, lsl #32
    // 0x11aaee8: StoreField: r0->field_13 = r2
    //     0x11aaee8: stur            w2, [x0, #0x13]
    // 0x11aaeec: str             x0, [SP]
    // 0x11aaef0: r0 = _interpolate()
    //     0x11aaef0: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11aaef4: LeaveFrame
    //     0x11aaef4: mov             SP, fp
    //     0x11aaef8: ldp             fp, lr, [SP], #0x10
    // 0x11aaefc: ret
    //     0x11aaefc: ret             
    // 0x11aaf00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11aaf00: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11aaf04: b               #0x11aaec4
  }
}
