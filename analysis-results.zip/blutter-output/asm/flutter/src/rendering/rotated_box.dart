// lib: , url: package:flutter/src/rendering/rotated_box.dart

// class id: 1049039, size: 0x8
class :: {
}

// class id: 4868, size: 0x64, field offset: 0x54
class RenderRotatedBox extends _MixinApplication6&RenderBox&RenderObjectWithChildMixin {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb176d0, size: 0x24
    // 0xb176d0: EnterFrame
    //     0xb176d0: stp             fp, lr, [SP, #-0x10]!
    //     0xb176d4: mov             fp, SP
    // 0xb176d8: ldr             x2, [fp, #0x10]
    // 0xb176dc: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb176dc: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1348] AnonymousClosure: (0xb176f4), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMinIntrinsicWidth (0xb1776c)
    //     0xb176e0: ldr             x1, [x1, #0x348]
    // 0xb176e4: r0 = AllocateClosure()
    //     0xb176e4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb176e8: LeaveFrame
    //     0xb176e8: mov             SP, fp
    //     0xb176ec: ldp             fp, lr, [SP], #0x10
    // 0xb176f0: ret
    //     0xb176f0: ret             
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb176f4, size: 0x78
    // 0xb176f4: EnterFrame
    //     0xb176f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb176f8: mov             fp, SP
    // 0xb176fc: ldr             x0, [fp, #0x18]
    // 0xb17700: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb17700: ldur            w1, [x0, #0x17]
    // 0xb17704: DecompressPointer r1
    //     0xb17704: add             x1, x1, HEAP, lsl #32
    // 0xb17708: CheckStackOverflow
    //     0xb17708: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb1770c: cmp             SP, x16
    //     0xb17710: b.ls            #0xb17754
    // 0xb17714: ldr             x2, [fp, #0x10]
    // 0xb17718: r0 = computeMinIntrinsicWidth()
    //     0xb17718: bl              #0xb1776c  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMinIntrinsicWidth
    // 0xb1771c: r0 = inline_Allocate_Double()
    //     0xb1771c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb17720: add             x0, x0, #0x10
    //     0xb17724: cmp             x1, x0
    //     0xb17728: b.ls            #0xb1775c
    //     0xb1772c: str             x0, [THR, #0x60]  ; THR::top
    //     0xb17730: sub             x0, x0, #0xf
    //     0xb17734: mov             x1, #0xe19c
    //     0xb17738: movk            x1, #3, lsl #16
    //     0xb1773c: stur            x1, [x0, #-1]
    // 0xb17740: dmb             ishst
    // 0xb17744: StoreField: r0->field_7 = d0
    //     0xb17744: stur            d0, [x0, #7]
    // 0xb17748: LeaveFrame
    //     0xb17748: mov             SP, fp
    //     0xb1774c: ldp             fp, lr, [SP], #0x10
    // 0xb17750: ret
    //     0xb17750: ret             
    // 0xb17754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb17754: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb17758: b               #0xb17714
    // 0xb1775c: SaveReg d0
    //     0xb1775c: str             q0, [SP, #-0x10]!
    // 0xb17760: r0 = AllocateDouble()
    //     0xb17760: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb17764: RestoreReg d0
    //     0xb17764: ldr             q0, [SP], #0x10
    // 0xb17768: b               #0xb17744
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0xb1776c, size: 0x6c
    // 0xb1776c: EnterFrame
    //     0xb1776c: stp             fp, lr, [SP, #-0x10]!
    //     0xb17770: mov             fp, SP
    // 0xb17774: CheckStackOverflow
    //     0xb17774: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb17778: cmp             SP, x16
    //     0xb1777c: b.ls            #0xb177d0
    // 0xb17780: LoadField: r0 = r1->field_4f
    //     0xb17780: ldur            w0, [x1, #0x4f]
    // 0xb17784: DecompressPointer r0
    //     0xb17784: add             x0, x0, HEAP, lsl #32
    // 0xb17788: cmp             w0, NULL
    // 0xb1778c: b.ne            #0xb177a0
    // 0xb17790: d0 = 0.000000
    //     0xb17790: eor             v0.16b, v0.16b, v0.16b
    // 0xb17794: LeaveFrame
    //     0xb17794: mov             SP, fp
    //     0xb17798: ldp             fp, lr, [SP], #0x10
    // 0xb1779c: ret
    //     0xb1779c: ret             
    // 0xb177a0: LoadField: r3 = r1->field_53
    //     0xb177a0: ldur            x3, [x1, #0x53]
    // 0xb177a4: branchIfSmi(r3, 0xb177b8)
    //     0xb177a4: tbz             w3, #0, #0xb177b8
    // 0xb177a8: LoadField: d0 = r2->field_7
    //     0xb177a8: ldur            d0, [x2, #7]
    // 0xb177ac: mov             x1, x0
    // 0xb177b0: r0 = getMinIntrinsicHeight()
    //     0xb177b0: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb177b4: b               #0xb177c4
    // 0xb177b8: LoadField: d0 = r2->field_7
    //     0xb177b8: ldur            d0, [x2, #7]
    // 0xb177bc: mov             x1, x0
    // 0xb177c0: r0 = getMinIntrinsicWidth()
    //     0xb177c0: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb177c4: LeaveFrame
    //     0xb177c4: mov             SP, fp
    //     0xb177c8: ldp             fp, lr, [SP], #0x10
    // 0xb177cc: ret
    //     0xb177cc: ret             
    // 0xb177d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb177d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb177d4: b               #0xb17780
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0xb234ac, size: 0x6c
    // 0xb234ac: EnterFrame
    //     0xb234ac: stp             fp, lr, [SP, #-0x10]!
    //     0xb234b0: mov             fp, SP
    // 0xb234b4: CheckStackOverflow
    //     0xb234b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb234b8: cmp             SP, x16
    //     0xb234bc: b.ls            #0xb23510
    // 0xb234c0: LoadField: r0 = r1->field_4f
    //     0xb234c0: ldur            w0, [x1, #0x4f]
    // 0xb234c4: DecompressPointer r0
    //     0xb234c4: add             x0, x0, HEAP, lsl #32
    // 0xb234c8: cmp             w0, NULL
    // 0xb234cc: b.ne            #0xb234e0
    // 0xb234d0: d0 = 0.000000
    //     0xb234d0: eor             v0.16b, v0.16b, v0.16b
    // 0xb234d4: LeaveFrame
    //     0xb234d4: mov             SP, fp
    //     0xb234d8: ldp             fp, lr, [SP], #0x10
    // 0xb234dc: ret
    //     0xb234dc: ret             
    // 0xb234e0: LoadField: r3 = r1->field_53
    //     0xb234e0: ldur            x3, [x1, #0x53]
    // 0xb234e4: branchIfSmi(r3, 0xb234f8)
    //     0xb234e4: tbz             w3, #0, #0xb234f8
    // 0xb234e8: LoadField: d0 = r2->field_7
    //     0xb234e8: ldur            d0, [x2, #7]
    // 0xb234ec: mov             x1, x0
    // 0xb234f0: r0 = getMinIntrinsicWidth()
    //     0xb234f0: bl              #0xb1628c  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0xb234f4: b               #0xb23504
    // 0xb234f8: LoadField: d0 = r2->field_7
    //     0xb234f8: ldur            d0, [x2, #7]
    // 0xb234fc: mov             x1, x0
    // 0xb23500: r0 = getMinIntrinsicHeight()
    //     0xb23500: bl              #0xb177d8  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0xb23504: LeaveFrame
    //     0xb23504: mov             SP, fp
    //     0xb23508: ldp             fp, lr, [SP], #0x10
    // 0xb2350c: ret
    //     0xb2350c: ret             
    // 0xb23510: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23510: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23514: b               #0xb234c0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb23518, size: 0x78
    // 0xb23518: EnterFrame
    //     0xb23518: stp             fp, lr, [SP, #-0x10]!
    //     0xb2351c: mov             fp, SP
    // 0xb23520: ldr             x0, [fp, #0x18]
    // 0xb23524: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb23524: ldur            w1, [x0, #0x17]
    // 0xb23528: DecompressPointer r1
    //     0xb23528: add             x1, x1, HEAP, lsl #32
    // 0xb2352c: CheckStackOverflow
    //     0xb2352c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb23530: cmp             SP, x16
    //     0xb23534: b.ls            #0xb23578
    // 0xb23538: ldr             x2, [fp, #0x10]
    // 0xb2353c: r0 = computeMinIntrinsicHeight()
    //     0xb2353c: bl              #0xb234ac  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMinIntrinsicHeight
    // 0xb23540: r0 = inline_Allocate_Double()
    //     0xb23540: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb23544: add             x0, x0, #0x10
    //     0xb23548: cmp             x1, x0
    //     0xb2354c: b.ls            #0xb23580
    //     0xb23550: str             x0, [THR, #0x60]  ; THR::top
    //     0xb23554: sub             x0, x0, #0xf
    //     0xb23558: mov             x1, #0xe19c
    //     0xb2355c: movk            x1, #3, lsl #16
    //     0xb23560: stur            x1, [x0, #-1]
    // 0xb23564: dmb             ishst
    // 0xb23568: StoreField: r0->field_7 = d0
    //     0xb23568: stur            d0, [x0, #7]
    // 0xb2356c: LeaveFrame
    //     0xb2356c: mov             SP, fp
    //     0xb23570: ldp             fp, lr, [SP], #0x10
    // 0xb23574: ret
    //     0xb23574: ret             
    // 0xb23578: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23578: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2357c: b               #0xb23538
    // 0xb23580: SaveReg d0
    //     0xb23580: str             q0, [SP, #-0x10]!
    // 0xb23584: r0 = AllocateDouble()
    //     0xb23584: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb23588: RestoreReg d0
    //     0xb23588: ldr             q0, [SP], #0x10
    // 0xb2358c: b               #0xb23568
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0xb2a290, size: 0xb8
    // 0xb2a290: EnterFrame
    //     0xb2a290: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a294: mov             fp, SP
    // 0xb2a298: AllocStack(0x10)
    //     0xb2a298: sub             SP, SP, #0x10
    // 0xb2a29c: SetupParameters(RenderRotatedBox this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xb2a29c: mov             x0, x1
    //     0xb2a2a0: stur            x1, [fp, #-8]
    //     0xb2a2a4: stur            x2, [fp, #-0x10]
    // 0xb2a2a8: CheckStackOverflow
    //     0xb2a2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a2ac: cmp             SP, x16
    //     0xb2a2b0: b.ls            #0xb2a338
    // 0xb2a2b4: LoadField: r1 = r0->field_4f
    //     0xb2a2b4: ldur            w1, [x0, #0x4f]
    // 0xb2a2b8: DecompressPointer r1
    //     0xb2a2b8: add             x1, x1, HEAP, lsl #32
    // 0xb2a2bc: cmp             w1, NULL
    // 0xb2a2c0: b.ne            #0xb2a2d4
    // 0xb2a2c4: d0 = 0.000000
    //     0xb2a2c4: eor             v0.16b, v0.16b, v0.16b
    // 0xb2a2c8: LeaveFrame
    //     0xb2a2c8: mov             SP, fp
    //     0xb2a2cc: ldp             fp, lr, [SP], #0x10
    // 0xb2a2d0: ret
    //     0xb2a2d0: ret             
    // 0xb2a2d4: mov             x1, x0
    // 0xb2a2d8: r0 = _isVertical()
    //     0xb2a2d8: bl              #0xb2a3c0  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::_isVertical
    // 0xb2a2dc: tbnz            w0, #4, #0xb2a308
    // 0xb2a2e0: ldur            x1, [fp, #-8]
    // 0xb2a2e4: ldur            x0, [fp, #-0x10]
    // 0xb2a2e8: LoadField: r2 = r1->field_4f
    //     0xb2a2e8: ldur            w2, [x1, #0x4f]
    // 0xb2a2ec: DecompressPointer r2
    //     0xb2a2ec: add             x2, x2, HEAP, lsl #32
    // 0xb2a2f0: cmp             w2, NULL
    // 0xb2a2f4: b.eq            #0xb2a340
    // 0xb2a2f8: LoadField: d0 = r0->field_7
    //     0xb2a2f8: ldur            d0, [x0, #7]
    // 0xb2a2fc: mov             x1, x2
    // 0xb2a300: r0 = getMaxIntrinsicWidth()
    //     0xb2a300: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2a304: b               #0xb2a32c
    // 0xb2a308: ldur            x1, [fp, #-8]
    // 0xb2a30c: ldur            x0, [fp, #-0x10]
    // 0xb2a310: LoadField: r2 = r1->field_4f
    //     0xb2a310: ldur            w2, [x1, #0x4f]
    // 0xb2a314: DecompressPointer r2
    //     0xb2a314: add             x2, x2, HEAP, lsl #32
    // 0xb2a318: cmp             w2, NULL
    // 0xb2a31c: b.eq            #0xb2a344
    // 0xb2a320: LoadField: d0 = r0->field_7
    //     0xb2a320: ldur            d0, [x0, #7]
    // 0xb2a324: mov             x1, x2
    // 0xb2a328: r0 = getMaxIntrinsicHeight()
    //     0xb2a328: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2a32c: LeaveFrame
    //     0xb2a32c: mov             SP, fp
    //     0xb2a330: ldp             fp, lr, [SP], #0x10
    // 0xb2a334: ret
    //     0xb2a334: ret             
    // 0xb2a338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a338: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a33c: b               #0xb2a2b4
    // 0xb2a340: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2a340: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb2a344: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2a344: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2a348, size: 0x78
    // 0xb2a348: EnterFrame
    //     0xb2a348: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a34c: mov             fp, SP
    // 0xb2a350: ldr             x0, [fp, #0x18]
    // 0xb2a354: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2a354: ldur            w1, [x0, #0x17]
    // 0xb2a358: DecompressPointer r1
    //     0xb2a358: add             x1, x1, HEAP, lsl #32
    // 0xb2a35c: CheckStackOverflow
    //     0xb2a35c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2a360: cmp             SP, x16
    //     0xb2a364: b.ls            #0xb2a3a8
    // 0xb2a368: ldr             x2, [fp, #0x10]
    // 0xb2a36c: r0 = computeMaxIntrinsicHeight()
    //     0xb2a36c: bl              #0xb2a290  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMaxIntrinsicHeight
    // 0xb2a370: r0 = inline_Allocate_Double()
    //     0xb2a370: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2a374: add             x0, x0, #0x10
    //     0xb2a378: cmp             x1, x0
    //     0xb2a37c: b.ls            #0xb2a3b0
    //     0xb2a380: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2a384: sub             x0, x0, #0xf
    //     0xb2a388: mov             x1, #0xe19c
    //     0xb2a38c: movk            x1, #3, lsl #16
    //     0xb2a390: stur            x1, [x0, #-1]
    // 0xb2a394: dmb             ishst
    // 0xb2a398: StoreField: r0->field_7 = d0
    //     0xb2a398: stur            d0, [x0, #7]
    // 0xb2a39c: LeaveFrame
    //     0xb2a39c: mov             SP, fp
    //     0xb2a3a0: ldp             fp, lr, [SP], #0x10
    // 0xb2a3a4: ret
    //     0xb2a3a4: ret             
    // 0xb2a3a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a3a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a3ac: b               #0xb2a368
    // 0xb2a3b0: SaveReg d0
    //     0xb2a3b0: str             q0, [SP, #-0x10]!
    // 0xb2a3b4: r0 = AllocateDouble()
    //     0xb2a3b4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2a3b8: RestoreReg d0
    //     0xb2a3b8: ldr             q0, [SP], #0x10
    // 0xb2a3bc: b               #0xb2a398
  }
  get _ _isVertical(/* No info */) {
    // ** addr: 0xb2a3c0, size: 0x20
    // 0xb2a3c0: LoadField: r2 = r1->field_53
    //     0xb2a3c0: ldur            x2, [x1, #0x53]
    // 0xb2a3c4: ubfx            x2, x2, #0, #0x20
    // 0xb2a3c8: and             w1, w2, #1
    // 0xb2a3cc: cbnz            w1, #0xb2a3d8
    // 0xb2a3d0: r0 = false
    //     0xb2a3d0: add             x0, NULL, #0x30  ; false
    // 0xb2a3d4: b               #0xb2a3dc
    // 0xb2a3d8: r0 = true
    //     0xb2a3d8: add             x0, NULL, #0x20  ; true
    // 0xb2a3dc: ret
    //     0xb2a3dc: ret             
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2d744, size: 0x6c
    // 0xb2d744: EnterFrame
    //     0xb2d744: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d748: mov             fp, SP
    // 0xb2d74c: CheckStackOverflow
    //     0xb2d74c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d750: cmp             SP, x16
    //     0xb2d754: b.ls            #0xb2d7a8
    // 0xb2d758: LoadField: r0 = r1->field_4f
    //     0xb2d758: ldur            w0, [x1, #0x4f]
    // 0xb2d75c: DecompressPointer r0
    //     0xb2d75c: add             x0, x0, HEAP, lsl #32
    // 0xb2d760: cmp             w0, NULL
    // 0xb2d764: b.ne            #0xb2d778
    // 0xb2d768: d0 = 0.000000
    //     0xb2d768: eor             v0.16b, v0.16b, v0.16b
    // 0xb2d76c: LeaveFrame
    //     0xb2d76c: mov             SP, fp
    //     0xb2d770: ldp             fp, lr, [SP], #0x10
    // 0xb2d774: ret
    //     0xb2d774: ret             
    // 0xb2d778: LoadField: r3 = r1->field_53
    //     0xb2d778: ldur            x3, [x1, #0x53]
    // 0xb2d77c: branchIfSmi(r3, 0xb2d790)
    //     0xb2d77c: tbz             w3, #0, #0xb2d790
    // 0xb2d780: LoadField: d0 = r2->field_7
    //     0xb2d780: ldur            d0, [x2, #7]
    // 0xb2d784: mov             x1, x0
    // 0xb2d788: r0 = getMaxIntrinsicHeight()
    //     0xb2d788: bl              #0xb16950  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0xb2d78c: b               #0xb2d79c
    // 0xb2d790: LoadField: d0 = r2->field_7
    //     0xb2d790: ldur            d0, [x2, #7]
    // 0xb2d794: mov             x1, x0
    // 0xb2d798: r0 = getMaxIntrinsicWidth()
    //     0xb2d798: bl              #0xb16750  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0xb2d79c: LeaveFrame
    //     0xb2d79c: mov             SP, fp
    //     0xb2d7a0: ldp             fp, lr, [SP], #0x10
    // 0xb2d7a4: ret
    //     0xb2d7a4: ret             
    // 0xb2d7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d7a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d7ac: b               #0xb2d758
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0xb2d7b0, size: 0x78
    // 0xb2d7b0: EnterFrame
    //     0xb2d7b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d7b4: mov             fp, SP
    // 0xb2d7b8: ldr             x0, [fp, #0x18]
    // 0xb2d7bc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb2d7bc: ldur            w1, [x0, #0x17]
    // 0xb2d7c0: DecompressPointer r1
    //     0xb2d7c0: add             x1, x1, HEAP, lsl #32
    // 0xb2d7c4: CheckStackOverflow
    //     0xb2d7c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb2d7c8: cmp             SP, x16
    //     0xb2d7cc: b.ls            #0xb2d810
    // 0xb2d7d0: ldr             x2, [fp, #0x10]
    // 0xb2d7d4: r0 = computeMaxIntrinsicWidth()
    //     0xb2d7d4: bl              #0xb2d744  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMaxIntrinsicWidth
    // 0xb2d7d8: r0 = inline_Allocate_Double()
    //     0xb2d7d8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb2d7dc: add             x0, x0, #0x10
    //     0xb2d7e0: cmp             x1, x0
    //     0xb2d7e4: b.ls            #0xb2d818
    //     0xb2d7e8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb2d7ec: sub             x0, x0, #0xf
    //     0xb2d7f0: mov             x1, #0xe19c
    //     0xb2d7f4: movk            x1, #3, lsl #16
    //     0xb2d7f8: stur            x1, [x0, #-1]
    // 0xb2d7fc: dmb             ishst
    // 0xb2d800: StoreField: r0->field_7 = d0
    //     0xb2d800: stur            d0, [x0, #7]
    // 0xb2d804: LeaveFrame
    //     0xb2d804: mov             SP, fp
    //     0xb2d808: ldp             fp, lr, [SP], #0x10
    // 0xb2d80c: ret
    //     0xb2d80c: ret             
    // 0xb2d810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d810: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d814: b               #0xb2d7d0
    // 0xb2d818: SaveReg d0
    //     0xb2d818: str             q0, [SP, #-0x10]!
    // 0xb2d81c: r0 = AllocateDouble()
    //     0xb2d81c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xb2d820: RestoreReg d0
    //     0xb2d820: ldr             q0, [SP], #0x10
    // 0xb2d824: b               #0xb2d800
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb4deb4, size: 0xbc
    // 0xb4deb4: EnterFrame
    //     0xb4deb4: stp             fp, lr, [SP, #-0x10]!
    //     0xb4deb8: mov             fp, SP
    // 0xb4debc: AllocStack(0x20)
    //     0xb4debc: sub             SP, SP, #0x20
    // 0xb4dec0: SetupParameters(RenderRotatedBox this /* r1 => r0, fp-0x10 */, dynamic _ /* r2 => r1 */)
    //     0xb4dec0: mov             x0, x1
    //     0xb4dec4: stur            x1, [fp, #-0x10]
    //     0xb4dec8: mov             x1, x2
    // 0xb4decc: CheckStackOverflow
    //     0xb4decc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb4ded0: cmp             SP, x16
    //     0xb4ded4: b.ls            #0xb4df68
    // 0xb4ded8: LoadField: r2 = r0->field_4f
    //     0xb4ded8: ldur            w2, [x0, #0x4f]
    // 0xb4dedc: DecompressPointer r2
    //     0xb4dedc: add             x2, x2, HEAP, lsl #32
    // 0xb4dee0: stur            x2, [fp, #-8]
    // 0xb4dee4: cmp             w2, NULL
    // 0xb4dee8: b.ne            #0xb4defc
    // 0xb4deec: r0 = smallest()
    //     0xb4deec: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xb4def0: LeaveFrame
    //     0xb4def0: mov             SP, fp
    //     0xb4def4: ldp             fp, lr, [SP], #0x10
    // 0xb4def8: ret
    //     0xb4def8: ret             
    // 0xb4defc: LoadField: r3 = r0->field_53
    //     0xb4defc: ldur            x3, [x0, #0x53]
    // 0xb4df00: branchIfSmi(r3, 0xb4df10)
    //     0xb4df00: tbz             w3, #0, #0xb4df10
    // 0xb4df04: r0 = flipped()
    //     0xb4df04: bl              #0xb18b2c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::flipped
    // 0xb4df08: mov             x2, x0
    // 0xb4df0c: b               #0xb4df14
    // 0xb4df10: mov             x2, x1
    // 0xb4df14: ldur            x0, [fp, #-0x10]
    // 0xb4df18: ldur            x1, [fp, #-8]
    // 0xb4df1c: r0 = getDryLayout()
    //     0xb4df1c: bl              #0xb20410  ; [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout
    // 0xb4df20: mov             x1, x0
    // 0xb4df24: ldur            x0, [fp, #-0x10]
    // 0xb4df28: LoadField: r2 = r0->field_53
    //     0xb4df28: ldur            x2, [x0, #0x53]
    // 0xb4df2c: branchIfSmi(r2, 0xb4df58)
    //     0xb4df2c: tbz             w2, #0, #0xb4df58
    // 0xb4df30: LoadField: d0 = r1->field_f
    //     0xb4df30: ldur            d0, [x1, #0xf]
    // 0xb4df34: stur            d0, [fp, #-0x20]
    // 0xb4df38: LoadField: d1 = r1->field_7
    //     0xb4df38: ldur            d1, [x1, #7]
    // 0xb4df3c: stur            d1, [fp, #-0x18]
    // 0xb4df40: r0 = Size()
    //     0xb4df40: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb4df44: ldur            d0, [fp, #-0x20]
    // 0xb4df48: StoreField: r0->field_7 = d0
    //     0xb4df48: stur            d0, [x0, #7]
    // 0xb4df4c: ldur            d0, [fp, #-0x18]
    // 0xb4df50: StoreField: r0->field_f = d0
    //     0xb4df50: stur            d0, [x0, #0xf]
    // 0xb4df54: b               #0xb4df5c
    // 0xb4df58: mov             x0, x1
    // 0xb4df5c: LeaveFrame
    //     0xb4df5c: mov             SP, fp
    //     0xb4df60: ldp             fp, lr, [SP], #0x10
    // 0xb4df64: ret
    //     0xb4df64: ret             
    // 0xb4df68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4df68: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4df6c: b               #0xb4ded8
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb584ec, size: 0x24
    // 0xb584ec: EnterFrame
    //     0xb584ec: stp             fp, lr, [SP, #-0x10]!
    //     0xb584f0: mov             fp, SP
    // 0xb584f4: ldr             x2, [fp, #0x10]
    // 0xb584f8: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb584f8: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1340] AnonymousClosure: (0xb2d7b0), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMaxIntrinsicWidth (0xb2d744)
    //     0xb584fc: ldr             x1, [x1, #0x340]
    // 0xb58500: r0 = AllocateClosure()
    //     0xb58500: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58504: LeaveFrame
    //     0xb58504: mov             SP, fp
    //     0xb58508: ldp             fp, lr, [SP], #0x10
    // 0xb5850c: ret
    //     0xb5850c: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e650, size: 0x24
    // 0xb5e650: EnterFrame
    //     0xb5e650: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e654: mov             fp, SP
    // 0xb5e658: ldr             x2, [fp, #0x10]
    // 0xb5e65c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e65c: add             x1, PP, #0x96, lsl #12  ; [pp+0x969d0] AnonymousClosure: (0xb2a348), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMaxIntrinsicHeight (0xb2a290)
    //     0xb5e660: ldr             x1, [x1, #0x9d0]
    // 0xb5e664: r0 = AllocateClosure()
    //     0xb5e664: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e668: LeaveFrame
    //     0xb5e668: mov             SP, fp
    //     0xb5e66c: ldp             fp, lr, [SP], #0x10
    // 0xb5e670: ret
    //     0xb5e670: ret             
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbbdb2c, size: 0x3ac
    // 0xbbdb2c: EnterFrame
    //     0xbbdb2c: stp             fp, lr, [SP, #-0x10]!
    //     0xbbdb30: mov             fp, SP
    // 0xbbdb34: AllocStack(0x30)
    //     0xbbdb34: sub             SP, SP, #0x30
    // 0xbbdb38: SetupParameters(RenderRotatedBox this /* r1 => r3, fp-0x18 */)
    //     0xbbdb38: mov             x3, x1
    //     0xbbdb3c: stur            x1, [fp, #-0x18]
    // 0xbbdb40: CheckStackOverflow
    //     0xbbdb40: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbbdb44: cmp             SP, x16
    //     0xbbdb48: b.ls            #0xbbdebc
    // 0xbbdb4c: StoreField: r3->field_5b = rNULL
    //     0xbbdb4c: stur            NULL, [x3, #0x5b]
    // 0xbbdb50: LoadField: r4 = r3->field_4f
    //     0xbbdb50: ldur            w4, [x3, #0x4f]
    // 0xbbdb54: DecompressPointer r4
    //     0xbbdb54: add             x4, x4, HEAP, lsl #32
    // 0xbbdb58: stur            x4, [fp, #-0x10]
    // 0xbbdb5c: cmp             w4, NULL
    // 0xbbdb60: b.eq            #0xbbdde4
    // 0xbbdb64: LoadField: r0 = r3->field_53
    //     0xbbdb64: ldur            x0, [x3, #0x53]
    // 0xbbdb68: branchIfSmi(r0, 0xbbdbc0)
    //     0xbbdb68: tbz             w0, #0, #0xbbdbc0
    // 0xbbdb6c: LoadField: r5 = r3->field_27
    //     0xbbdb6c: ldur            w5, [x3, #0x27]
    // 0xbbdb70: DecompressPointer r5
    //     0xbbdb70: add             x5, x5, HEAP, lsl #32
    // 0xbbdb74: stur            x5, [fp, #-8]
    // 0xbbdb78: cmp             w5, NULL
    // 0xbbdb7c: b.eq            #0xbbde60
    // 0xbbdb80: mov             x0, x5
    // 0xbbdb84: r2 = Null
    //     0xbbdb84: mov             x2, NULL
    // 0xbbdb88: r1 = Null
    //     0xbbdb88: mov             x1, NULL
    // 0xbbdb8c: r4 = LoadClassIdInstr(r0)
    //     0xbbdb8c: ldur            x4, [x0, #-1]
    //     0xbbdb90: ubfx            x4, x4, #0xc, #0x14
    // 0xbbdb94: sub             x4, x4, #0xb46
    // 0xbbdb98: cmp             x4, #1
    // 0xbbdb9c: b.ls            #0xbbdbb0
    // 0xbbdba0: r8 = BoxConstraints
    //     0xbbdba0: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbdba4: r3 = Null
    //     0xbbdba4: add             x3, PP, #0x96, lsl #12  ; [pp+0x96a00] Null
    //     0xbbdba8: ldr             x3, [x3, #0xa00]
    // 0xbbdbac: r0 = BoxConstraints()
    //     0xbbdbac: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbdbb0: ldur            x1, [fp, #-8]
    // 0xbbdbb4: r0 = flipped()
    //     0xbbdbb4: bl              #0xb18b2c  ; [package:flutter/src/rendering/box.dart] BoxConstraints::flipped
    // 0xbbdbb8: mov             x2, x0
    // 0xbbdbbc: b               #0xbbdc08
    // 0xbbdbc0: LoadField: r4 = r3->field_27
    //     0xbbdbc0: ldur            w4, [x3, #0x27]
    // 0xbbdbc4: DecompressPointer r4
    //     0xbbdbc4: add             x4, x4, HEAP, lsl #32
    // 0xbbdbc8: stur            x4, [fp, #-8]
    // 0xbbdbcc: cmp             w4, NULL
    // 0xbbdbd0: b.eq            #0xbbde7c
    // 0xbbdbd4: mov             x0, x4
    // 0xbbdbd8: r2 = Null
    //     0xbbdbd8: mov             x2, NULL
    // 0xbbdbdc: r1 = Null
    //     0xbbdbdc: mov             x1, NULL
    // 0xbbdbe0: r4 = LoadClassIdInstr(r0)
    //     0xbbdbe0: ldur            x4, [x0, #-1]
    //     0xbbdbe4: ubfx            x4, x4, #0xc, #0x14
    // 0xbbdbe8: sub             x4, x4, #0xb46
    // 0xbbdbec: cmp             x4, #1
    // 0xbbdbf0: b.ls            #0xbbdc04
    // 0xbbdbf4: r8 = BoxConstraints
    //     0xbbdbf4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbdbf8: r3 = Null
    //     0xbbdbf8: add             x3, PP, #0x96, lsl #12  ; [pp+0x96a10] Null
    //     0xbbdbfc: ldr             x3, [x3, #0xa10]
    // 0xbbdc00: r0 = BoxConstraints()
    //     0xbbdc00: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbdc04: ldur            x2, [fp, #-8]
    // 0xbbdc08: ldur            x3, [fp, #-0x18]
    // 0xbbdc0c: ldur            x1, [fp, #-0x10]
    // 0xbbdc10: r0 = LoadClassIdInstr(r1)
    //     0xbbdc10: ldur            x0, [x1, #-1]
    //     0xbbdc14: ubfx            x0, x0, #0xc, #0x14
    // 0xbbdc18: r16 = true
    //     0xbbdc18: add             x16, NULL, #0x20  ; true
    // 0xbbdc1c: str             x16, [SP]
    // 0xbbdc20: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbbdc20: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbbdc24: ldr             x4, [x4, #0xed0]
    // 0xbbdc28: r0 = GDT[cid_x0 + 0xe6b9]()
    //     0xbbdc28: mov             x17, #0xe6b9
    //     0xbbdc2c: add             lr, x0, x17
    //     0xbbdc30: ldr             lr, [x21, lr, lsl #3]
    //     0xbbdc34: blr             lr
    // 0xbbdc38: ldur            x0, [fp, #-0x18]
    // 0xbbdc3c: LoadField: r1 = r0->field_53
    //     0xbbdc3c: ldur            x1, [x0, #0x53]
    // 0xbbdc40: branchIfSmi(r1, 0xbbdc98)
    //     0xbbdc40: tbz             w1, #0, #0xbbdc98
    // 0xbbdc44: LoadField: r1 = r0->field_4f
    //     0xbbdc44: ldur            w1, [x0, #0x4f]
    // 0xbbdc48: DecompressPointer r1
    //     0xbbdc48: add             x1, x1, HEAP, lsl #32
    // 0xbbdc4c: cmp             w1, NULL
    // 0xbbdc50: b.eq            #0xbbdec4
    // 0xbbdc54: r0 = size()
    //     0xbbdc54: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbdc58: LoadField: d0 = r0->field_f
    //     0xbbdc58: ldur            d0, [x0, #0xf]
    // 0xbbdc5c: ldur            x0, [fp, #-0x18]
    // 0xbbdc60: stur            d0, [fp, #-0x20]
    // 0xbbdc64: LoadField: r1 = r0->field_4f
    //     0xbbdc64: ldur            w1, [x0, #0x4f]
    // 0xbbdc68: DecompressPointer r1
    //     0xbbdc68: add             x1, x1, HEAP, lsl #32
    // 0xbbdc6c: cmp             w1, NULL
    // 0xbbdc70: b.eq            #0xbbdec8
    // 0xbbdc74: r0 = size()
    //     0xbbdc74: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbdc78: LoadField: d0 = r0->field_7
    //     0xbbdc78: ldur            d0, [x0, #7]
    // 0xbbdc7c: stur            d0, [fp, #-0x28]
    // 0xbbdc80: r0 = Size()
    //     0xbbdc80: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbbdc84: ldur            d0, [fp, #-0x20]
    // 0xbbdc88: StoreField: r0->field_7 = d0
    //     0xbbdc88: stur            d0, [x0, #7]
    // 0xbbdc8c: ldur            d0, [fp, #-0x28]
    // 0xbbdc90: StoreField: r0->field_f = d0
    //     0xbbdc90: stur            d0, [x0, #0xf]
    // 0xbbdc94: b               #0xbbdcac
    // 0xbbdc98: LoadField: r1 = r0->field_4f
    //     0xbbdc98: ldur            w1, [x0, #0x4f]
    // 0xbbdc9c: DecompressPointer r1
    //     0xbbdc9c: add             x1, x1, HEAP, lsl #32
    // 0xbbdca0: cmp             w1, NULL
    // 0xbbdca4: b.eq            #0xbbdecc
    // 0xbbdca8: r0 = size()
    //     0xbbdca8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbdcac: ldur            x1, [fp, #-0x18]
    // 0xbbdcb0: StoreField: r1->field_4b = r0
    //     0xbbdcb0: stur            w0, [x1, #0x4b]
    //     0xbbdcb4: ldurb           w16, [x1, #-1]
    //     0xbbdcb8: ldurb           w17, [x0, #-1]
    //     0xbbdcbc: and             x16, x17, x16, lsr #2
    //     0xbbdcc0: tst             x16, HEAP, lsr #32
    //     0xbbdcc4: b.eq            #0xbbdccc
    //     0xbbdcc8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbdccc: r0 = Matrix4()
    //     0xbbdccc: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xbbdcd0: r4 = 32
    //     0xbbdcd0: mov             x4, #0x20
    // 0xbbdcd4: stur            x0, [fp, #-8]
    // 0xbbdcd8: r0 = AllocateFloat64Array()
    //     0xbbdcd8: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xbbdcdc: mov             x1, x0
    // 0xbbdce0: ldur            x0, [fp, #-8]
    // 0xbbdce4: StoreField: r0->field_7 = r1
    //     0xbbdce4: stur            w1, [x0, #7]
    // 0xbbdce8: mov             x1, x0
    // 0xbbdcec: r0 = setIdentity()
    //     0xbbdcec: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xbbdcf0: ldur            x1, [fp, #-0x18]
    // 0xbbdcf4: r0 = size()
    //     0xbbdcf4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbdcf8: LoadField: d0 = r0->field_7
    //     0xbbdcf8: ldur            d0, [x0, #7]
    // 0xbbdcfc: d1 = 2.000000
    //     0xbbdcfc: fmov            d1, #2.00000000
    // 0xbbdd00: fdiv            d2, d0, d1
    // 0xbbdd04: ldur            x1, [fp, #-0x18]
    // 0xbbdd08: stur            d2, [fp, #-0x20]
    // 0xbbdd0c: r0 = size()
    //     0xbbdd0c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbdd10: LoadField: d0 = r0->field_f
    //     0xbbdd10: ldur            d0, [x0, #0xf]
    // 0xbbdd14: d2 = 2.000000
    //     0xbbdd14: fmov            d2, #2.00000000
    // 0xbbdd18: fdiv            d1, d0, d2
    // 0xbbdd1c: ldur            x1, [fp, #-8]
    // 0xbbdd20: ldur            d0, [fp, #-0x20]
    // 0xbbdd24: r0 = translateByDouble()
    //     0xbbdd24: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbbdd28: ldur            x0, [fp, #-0x18]
    // 0xbbdd2c: LoadField: r1 = r0->field_53
    //     0xbbdd2c: ldur            x1, [x0, #0x53]
    // 0xbbdd30: ubfx            x1, x1, #0, #0x20
    // 0xbbdd34: and             w2, w1, #3
    // 0xbbdd38: ubfx            x2, x2, #0, #0x20
    // 0xbbdd3c: scvtf           d0, x2
    // 0xbbdd40: d1 = 1.570796
    //     0xbbdd40: add             x17, PP, #0x95, lsl #12  ; [pp+0x95ed8] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0xbbdd44: ldr             d1, [x17, #0xed8]
    // 0xbbdd48: fmul            d2, d0, d1
    // 0xbbdd4c: ldur            x1, [fp, #-8]
    // 0xbbdd50: mov             v0.16b, v2.16b
    // 0xbbdd54: r0 = rotateZ()
    //     0xbbdd54: bl              #0xb75838  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateZ
    // 0xbbdd58: ldur            x0, [fp, #-0x18]
    // 0xbbdd5c: LoadField: r1 = r0->field_4f
    //     0xbbdd5c: ldur            w1, [x0, #0x4f]
    // 0xbbdd60: DecompressPointer r1
    //     0xbbdd60: add             x1, x1, HEAP, lsl #32
    // 0xbbdd64: cmp             w1, NULL
    // 0xbbdd68: b.eq            #0xbbded0
    // 0xbbdd6c: r0 = size()
    //     0xbbdd6c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbdd70: LoadField: d0 = r0->field_7
    //     0xbbdd70: ldur            d0, [x0, #7]
    // 0xbbdd74: fneg            d1, d0
    // 0xbbdd78: d0 = 2.000000
    //     0xbbdd78: fmov            d0, #2.00000000
    // 0xbbdd7c: fdiv            d2, d1, d0
    // 0xbbdd80: ldur            x0, [fp, #-0x18]
    // 0xbbdd84: stur            d2, [fp, #-0x20]
    // 0xbbdd88: LoadField: r1 = r0->field_4f
    //     0xbbdd88: ldur            w1, [x0, #0x4f]
    // 0xbbdd8c: DecompressPointer r1
    //     0xbbdd8c: add             x1, x1, HEAP, lsl #32
    // 0xbbdd90: cmp             w1, NULL
    // 0xbbdd94: b.eq            #0xbbded4
    // 0xbbdd98: r0 = size()
    //     0xbbdd98: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbbdd9c: LoadField: d0 = r0->field_f
    //     0xbbdd9c: ldur            d0, [x0, #0xf]
    // 0xbbdda0: fneg            d1, d0
    // 0xbbdda4: d0 = 2.000000
    //     0xbbdda4: fmov            d0, #2.00000000
    // 0xbbdda8: fdiv            d2, d1, d0
    // 0xbbddac: ldur            x1, [fp, #-8]
    // 0xbbddb0: ldur            d0, [fp, #-0x20]
    // 0xbbddb4: mov             v1.16b, v2.16b
    // 0xbbddb8: r0 = translateByDouble()
    //     0xbbddb8: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbbddbc: ldur            x0, [fp, #-8]
    // 0xbbddc0: ldur            x3, [fp, #-0x18]
    // 0xbbddc4: StoreField: r3->field_5b = r0
    //     0xbbddc4: stur            w0, [x3, #0x5b]
    //     0xbbddc8: ldurb           w16, [x3, #-1]
    //     0xbbddcc: ldurb           w17, [x0, #-1]
    //     0xbbddd0: and             x16, x17, x16, lsr #2
    //     0xbbddd4: tst             x16, HEAP, lsr #32
    //     0xbbddd8: b.eq            #0xbbdde0
    //     0xbbdddc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbbdde0: b               #0xbbde50
    // 0xbbdde4: LoadField: r4 = r3->field_27
    //     0xbbdde4: ldur            w4, [x3, #0x27]
    // 0xbbdde8: DecompressPointer r4
    //     0xbbdde8: add             x4, x4, HEAP, lsl #32
    // 0xbbddec: stur            x4, [fp, #-8]
    // 0xbbddf0: cmp             w4, NULL
    // 0xbbddf4: b.eq            #0xbbde9c
    // 0xbbddf8: mov             x0, x4
    // 0xbbddfc: r2 = Null
    //     0xbbddfc: mov             x2, NULL
    // 0xbbde00: r1 = Null
    //     0xbbde00: mov             x1, NULL
    // 0xbbde04: r4 = LoadClassIdInstr(r0)
    //     0xbbde04: ldur            x4, [x0, #-1]
    //     0xbbde08: ubfx            x4, x4, #0xc, #0x14
    // 0xbbde0c: sub             x4, x4, #0xb46
    // 0xbbde10: cmp             x4, #1
    // 0xbbde14: b.ls            #0xbbde28
    // 0xbbde18: r8 = BoxConstraints
    //     0xbbde18: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbbde1c: r3 = Null
    //     0xbbde1c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96a20] Null
    //     0xbbde20: ldr             x3, [x3, #0xa20]
    // 0xbbde24: r0 = BoxConstraints()
    //     0xbbde24: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbbde28: ldur            x1, [fp, #-8]
    // 0xbbde2c: r0 = smallest()
    //     0xbbde2c: bl              #0xb214d4  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0xbbde30: ldur            x1, [fp, #-0x18]
    // 0xbbde34: StoreField: r1->field_4b = r0
    //     0xbbde34: stur            w0, [x1, #0x4b]
    //     0xbbde38: ldurb           w16, [x1, #-1]
    //     0xbbde3c: ldurb           w17, [x0, #-1]
    //     0xbbde40: and             x16, x17, x16, lsr #2
    //     0xbbde44: tst             x16, HEAP, lsr #32
    //     0xbbde48: b.eq            #0xbbde50
    //     0xbbde4c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbbde50: r0 = Null
    //     0xbbde50: mov             x0, NULL
    // 0xbbde54: LeaveFrame
    //     0xbbde54: mov             SP, fp
    //     0xbbde58: ldp             fp, lr, [SP], #0x10
    // 0xbbde5c: ret
    //     0xbbde5c: ret             
    // 0xbbde60: r0 = StateError()
    //     0xbbde60: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbde64: mov             x1, x0
    // 0xbbde68: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbde68: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbde6c: StoreField: r1->field_b = r0
    //     0xbbde6c: stur            w0, [x1, #0xb]
    // 0xbbde70: mov             x0, x1
    // 0xbbde74: r0 = Throw()
    //     0xbbde74: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbde78: brk             #0
    // 0xbbde7c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbde7c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbde80: r0 = StateError()
    //     0xbbde80: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbde84: mov             x1, x0
    // 0xbbde88: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbde88: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbde8c: StoreField: r1->field_b = r0
    //     0xbbde8c: stur            w0, [x1, #0xb]
    // 0xbbde90: mov             x0, x1
    // 0xbbde94: r0 = Throw()
    //     0xbbde94: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbde98: brk             #0
    // 0xbbde9c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbde9c: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbdea0: r0 = StateError()
    //     0xbbdea0: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbbdea4: mov             x1, x0
    // 0xbbdea8: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbbdea8: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbbdeac: StoreField: r1->field_b = r0
    //     0xbbdeac: stur            w0, [x1, #0xb]
    // 0xbbdeb0: mov             x0, x1
    // 0xbbdeb4: r0 = Throw()
    //     0xbbdeb4: bl              #0x13ddb2c  ; ThrowStub
    // 0xbbdeb8: brk             #0
    // 0xbbdebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbdebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbdec0: b               #0xbbdb4c
    // 0xbbdec4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbdec4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbdec8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbdec8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbbdecc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbdecc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbded0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbded0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbded4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbbded4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf1524, size: 0xac
    // 0xbf1524: EnterFrame
    //     0xbf1524: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1528: mov             fp, SP
    // 0xbf152c: AllocStack(0x18)
    //     0xbf152c: sub             SP, SP, #0x18
    // 0xbf1530: SetupParameters(RenderRotatedBox this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xbf1530: mov             x5, x1
    //     0xbf1534: mov             x4, x2
    //     0xbf1538: stur            x1, [fp, #-8]
    //     0xbf153c: stur            x2, [fp, #-0x10]
    //     0xbf1540: stur            x3, [fp, #-0x18]
    // 0xbf1544: CheckStackOverflow
    //     0xbf1544: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1548: cmp             SP, x16
    //     0xbf154c: b.ls            #0xbf15c8
    // 0xbf1550: mov             x0, x4
    // 0xbf1554: r2 = Null
    //     0xbf1554: mov             x2, NULL
    // 0xbf1558: r1 = Null
    //     0xbf1558: mov             x1, NULL
    // 0xbf155c: r4 = 60
    //     0xbf155c: mov             x4, #0x3c
    // 0xbf1560: branchIfSmi(r0, 0xbf156c)
    //     0xbf1560: tbz             w0, #0, #0xbf156c
    // 0xbf1564: r4 = LoadClassIdInstr(r0)
    //     0xbf1564: ldur            x4, [x0, #-1]
    //     0xbf1568: ubfx            x4, x4, #0xc, #0x14
    // 0xbf156c: r17 = -4710
    //     0xbf156c: mov             x17, #-0x1266
    // 0xbf1570: add             x4, x4, x17
    // 0xbf1574: cmp             x4, #0x109
    // 0xbf1578: b.ls            #0xbf158c
    // 0xbf157c: r8 = RenderBox
    //     0xbf157c: ldr             x8, [PP, #0x4f38]  ; [pp+0x4f38] Type: RenderBox
    // 0xbf1580: r3 = Null
    //     0xbf1580: add             x3, PP, #0x96, lsl #12  ; [pp+0x969e0] Null
    //     0xbf1584: ldr             x3, [x3, #0x9e0]
    // 0xbf1588: r0 = RenderBox()
    //     0xbf1588: bl              #0x836b78  ; IsType_RenderBox_Stub
    // 0xbf158c: ldur            x0, [fp, #-8]
    // 0xbf1590: LoadField: r2 = r0->field_5b
    //     0xbf1590: ldur            w2, [x0, #0x5b]
    // 0xbf1594: DecompressPointer r2
    //     0xbf1594: add             x2, x2, HEAP, lsl #32
    // 0xbf1598: cmp             w2, NULL
    // 0xbf159c: b.eq            #0xbf15a8
    // 0xbf15a0: ldur            x1, [fp, #-0x18]
    // 0xbf15a4: r0 = multiply()
    //     0xbf15a4: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbf15a8: ldur            x1, [fp, #-8]
    // 0xbf15ac: ldur            x2, [fp, #-0x10]
    // 0xbf15b0: ldur            x3, [fp, #-0x18]
    // 0xbf15b4: r0 = applyPaintTransform()
    //     0xbf15b4: bl              #0xbf1f9c  ; [package:flutter/src/rendering/box.dart] RenderBox::applyPaintTransform
    // 0xbf15b8: r0 = Null
    //     0xbf15b8: mov             x0, NULL
    // 0xbf15bc: LeaveFrame
    //     0xbf15bc: mov             SP, fp
    //     0xbf15c0: ldp             fp, lr, [SP], #0x10
    // 0xbf15c4: ret
    //     0xbf15c4: ret             
    // 0xbf15c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf15c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf15cc: b               #0xbf1550
  }
  _ paint(/* No info */) {
    // ** addr: 0xc20c9c, size: 0xe8
    // 0xc20c9c: EnterFrame
    //     0xc20c9c: stp             fp, lr, [SP, #-0x10]!
    //     0xc20ca0: mov             fp, SP
    // 0xc20ca4: AllocStack(0x30)
    //     0xc20ca4: sub             SP, SP, #0x30
    // 0xc20ca8: SetupParameters(RenderRotatedBox this /* r1 => r2 */, dynamic _ /* r2 => r0, fp-0x28 */, dynamic _ /* r3 => r3, fp-0x30 */)
    //     0xc20ca8: mov             x0, x2
    //     0xc20cac: stur            x2, [fp, #-0x28]
    //     0xc20cb0: mov             x2, x1
    //     0xc20cb4: stur            x3, [fp, #-0x30]
    // 0xc20cb8: CheckStackOverflow
    //     0xc20cb8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc20cbc: cmp             SP, x16
    //     0xc20cc0: b.ls            #0xc20d70
    // 0xc20cc4: LoadField: r1 = r2->field_4f
    //     0xc20cc4: ldur            w1, [x2, #0x4f]
    // 0xc20cc8: DecompressPointer r1
    //     0xc20cc8: add             x1, x1, HEAP, lsl #32
    // 0xc20ccc: cmp             w1, NULL
    // 0xc20cd0: b.eq            #0xc20d50
    // 0xc20cd4: LoadField: r4 = r2->field_5f
    //     0xc20cd4: ldur            w4, [x2, #0x5f]
    // 0xc20cd8: DecompressPointer r4
    //     0xc20cd8: add             x4, x4, HEAP, lsl #32
    // 0xc20cdc: stur            x4, [fp, #-0x20]
    // 0xc20ce0: LoadField: r5 = r2->field_37
    //     0xc20ce0: ldur            w5, [x2, #0x37]
    // 0xc20ce4: DecompressPointer r5
    //     0xc20ce4: add             x5, x5, HEAP, lsl #32
    // 0xc20ce8: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc20cec: cmp             w5, w16
    // 0xc20cf0: b.eq            #0xc20d78
    // 0xc20cf4: stur            x5, [fp, #-0x18]
    // 0xc20cf8: LoadField: r6 = r2->field_5b
    //     0xc20cf8: ldur            w6, [x2, #0x5b]
    // 0xc20cfc: DecompressPointer r6
    //     0xc20cfc: add             x6, x6, HEAP, lsl #32
    // 0xc20d00: stur            x6, [fp, #-0x10]
    // 0xc20d04: cmp             w6, NULL
    // 0xc20d08: b.eq            #0xc20d80
    // 0xc20d0c: LoadField: r7 = r4->field_b
    //     0xc20d0c: ldur            w7, [x4, #0xb]
    // 0xc20d10: DecompressPointer r7
    //     0xc20d10: add             x7, x7, HEAP, lsl #32
    // 0xc20d14: stur            x7, [fp, #-8]
    // 0xc20d18: r1 = Function '_paintChild@606134774':.
    //     0xc20d18: add             x1, PP, #0x96, lsl #12  ; [pp+0x969f0] AnonymousClosure: (0xc20d84), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::_paintChild (0xc20dc4)
    //     0xc20d1c: ldr             x1, [x1, #0x9f0]
    // 0xc20d20: r0 = AllocateClosure()
    //     0xc20d20: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc20d24: ldur            x1, [fp, #-0x28]
    // 0xc20d28: ldur            x2, [fp, #-0x18]
    // 0xc20d2c: ldur            x3, [fp, #-0x30]
    // 0xc20d30: ldur            x5, [fp, #-0x10]
    // 0xc20d34: mov             x6, x0
    // 0xc20d38: ldur            x7, [fp, #-8]
    // 0xc20d3c: r0 = pushTransform()
    //     0xc20d3c: bl              #0xc1c818  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0xc20d40: ldur            x1, [fp, #-0x20]
    // 0xc20d44: mov             x2, x0
    // 0xc20d48: r0 = layer=()
    //     0xc20d48: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc20d4c: b               #0xc20d60
    // 0xc20d50: LoadField: r1 = r2->field_5f
    //     0xc20d50: ldur            w1, [x2, #0x5f]
    // 0xc20d54: DecompressPointer r1
    //     0xc20d54: add             x1, x1, HEAP, lsl #32
    // 0xc20d58: r2 = Null
    //     0xc20d58: mov             x2, NULL
    // 0xc20d5c: r0 = layer=()
    //     0xc20d5c: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc20d60: r0 = Null
    //     0xc20d60: mov             x0, NULL
    // 0xc20d64: LeaveFrame
    //     0xc20d64: mov             SP, fp
    //     0xc20d68: ldp             fp, lr, [SP], #0x10
    // 0xc20d6c: ret
    //     0xc20d6c: ret             
    // 0xc20d70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20d70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20d74: b               #0xc20cc4
    // 0xc20d78: r9 = _needsCompositing
    //     0xc20d78: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc20d7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc20d7c: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc20d80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc20d80: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _paintChild(dynamic, PaintingContext, Offset) {
    // ** addr: 0xc20d84, size: 0x40
    // 0xc20d84: EnterFrame
    //     0xc20d84: stp             fp, lr, [SP, #-0x10]!
    //     0xc20d88: mov             fp, SP
    // 0xc20d8c: ldr             x0, [fp, #0x20]
    // 0xc20d90: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc20d90: ldur            w1, [x0, #0x17]
    // 0xc20d94: DecompressPointer r1
    //     0xc20d94: add             x1, x1, HEAP, lsl #32
    // 0xc20d98: CheckStackOverflow
    //     0xc20d98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc20d9c: cmp             SP, x16
    //     0xc20da0: b.ls            #0xc20dbc
    // 0xc20da4: ldr             x2, [fp, #0x18]
    // 0xc20da8: ldr             x3, [fp, #0x10]
    // 0xc20dac: r0 = _paintChild()
    //     0xc20dac: bl              #0xc20dc4  ; [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::_paintChild
    // 0xc20db0: LeaveFrame
    //     0xc20db0: mov             SP, fp
    //     0xc20db4: ldp             fp, lr, [SP], #0x10
    // 0xc20db8: ret
    //     0xc20db8: ret             
    // 0xc20dbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20dbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20dc0: b               #0xc20da4
  }
  _ _paintChild(/* No info */) {
    // ** addr: 0xc20dc4, size: 0x4c
    // 0xc20dc4: EnterFrame
    //     0xc20dc4: stp             fp, lr, [SP, #-0x10]!
    //     0xc20dc8: mov             fp, SP
    // 0xc20dcc: mov             x0, x1
    // 0xc20dd0: mov             x1, x2
    // 0xc20dd4: CheckStackOverflow
    //     0xc20dd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc20dd8: cmp             SP, x16
    //     0xc20ddc: b.ls            #0xc20e04
    // 0xc20de0: LoadField: r2 = r0->field_4f
    //     0xc20de0: ldur            w2, [x0, #0x4f]
    // 0xc20de4: DecompressPointer r2
    //     0xc20de4: add             x2, x2, HEAP, lsl #32
    // 0xc20de8: cmp             w2, NULL
    // 0xc20dec: b.eq            #0xc20e0c
    // 0xc20df0: r0 = paintChild()
    //     0xc20df0: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc20df4: r0 = Null
    //     0xc20df4: mov             x0, NULL
    // 0xc20df8: LeaveFrame
    //     0xc20df8: mov             SP, fp
    //     0xc20dfc: ldp             fp, lr, [SP], #0x10
    // 0xc20e00: ret
    //     0xc20e00: ret             
    // 0xc20e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc20e04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc20e08: b               #0xc20de0
    // 0xc20e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc20e0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ quarterTurns=(/* No info */) {
    // ** addr: 0xcf799c, size: 0x50
    // 0xcf799c: EnterFrame
    //     0xcf799c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf79a0: mov             fp, SP
    // 0xcf79a4: CheckStackOverflow
    //     0xcf79a4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf79a8: cmp             SP, x16
    //     0xcf79ac: b.ls            #0xcf79e4
    // 0xcf79b0: LoadField: r0 = r1->field_53
    //     0xcf79b0: ldur            x0, [x1, #0x53]
    // 0xcf79b4: cmp             x0, x2
    // 0xcf79b8: b.ne            #0xcf79cc
    // 0xcf79bc: r0 = Null
    //     0xcf79bc: mov             x0, NULL
    // 0xcf79c0: LeaveFrame
    //     0xcf79c0: mov             SP, fp
    //     0xcf79c4: ldp             fp, lr, [SP], #0x10
    // 0xcf79c8: ret
    //     0xcf79c8: ret             
    // 0xcf79cc: StoreField: r1->field_53 = r2
    //     0xcf79cc: stur            x2, [x1, #0x53]
    // 0xcf79d0: r0 = markNeedsLayout()
    //     0xcf79d0: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf79d4: r0 = Null
    //     0xcf79d4: mov             x0, NULL
    // 0xcf79d8: LeaveFrame
    //     0xcf79d8: mov             SP, fp
    //     0xcf79dc: ldp             fp, lr, [SP], #0x10
    // 0xcf79e0: ret
    //     0xcf79e0: ret             
    // 0xcf79e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf79e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf79e8: b               #0xcf79b0
  }
  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult, Offset) {
    // ** addr: 0x10e8b08, size: 0x74
    // 0x10e8b08: EnterFrame
    //     0x10e8b08: stp             fp, lr, [SP, #-0x10]!
    //     0x10e8b0c: mov             fp, SP
    // 0x10e8b10: ldr             x0, [fp, #0x20]
    // 0x10e8b14: ArrayLoad: r1 = r0[0]  ; List_4
    //     0x10e8b14: ldur            w1, [x0, #0x17]
    // 0x10e8b18: DecompressPointer r1
    //     0x10e8b18: add             x1, x1, HEAP, lsl #32
    // 0x10e8b1c: CheckStackOverflow
    //     0x10e8b1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e8b20: cmp             SP, x16
    //     0x10e8b24: b.ls            #0x10e8b70
    // 0x10e8b28: LoadField: r0 = r1->field_f
    //     0x10e8b28: ldur            w0, [x1, #0xf]
    // 0x10e8b2c: DecompressPointer r0
    //     0x10e8b2c: add             x0, x0, HEAP, lsl #32
    // 0x10e8b30: LoadField: r1 = r0->field_4f
    //     0x10e8b30: ldur            w1, [x0, #0x4f]
    // 0x10e8b34: DecompressPointer r1
    //     0x10e8b34: add             x1, x1, HEAP, lsl #32
    // 0x10e8b38: cmp             w1, NULL
    // 0x10e8b3c: b.eq            #0x10e8b78
    // 0x10e8b40: r0 = LoadClassIdInstr(r1)
    //     0x10e8b40: ldur            x0, [x1, #-1]
    //     0x10e8b44: ubfx            x0, x0, #0xc, #0x14
    // 0x10e8b48: ldr             x2, [fp, #0x18]
    // 0x10e8b4c: ldr             x3, [fp, #0x10]
    // 0x10e8b50: r0 = GDT[cid_x0 + 0x13d77]()
    //     0x10e8b50: mov             x17, #0x3d77
    //     0x10e8b54: movk            x17, #1, lsl #16
    //     0x10e8b58: add             lr, x0, x17
    //     0x10e8b5c: ldr             lr, [x21, lr, lsl #3]
    //     0x10e8b60: blr             lr
    // 0x10e8b64: LeaveFrame
    //     0x10e8b64: mov             SP, fp
    //     0x10e8b68: ldp             fp, lr, [SP], #0x10
    // 0x10e8b6c: ret
    //     0x10e8b6c: ret             
    // 0x10e8b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e8b70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e8b74: b               #0x10e8b28
    // 0x10e8b78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10e8b78: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10e9c2c, size: 0xac
    // 0x10e9c2c: EnterFrame
    //     0x10e9c2c: stp             fp, lr, [SP, #-0x10]!
    //     0x10e9c30: mov             fp, SP
    // 0x10e9c34: AllocStack(0x20)
    //     0x10e9c34: sub             SP, SP, #0x20
    // 0x10e9c38: SetupParameters(RenderRotatedBox this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x10e9c38: mov             x0, x1
    //     0x10e9c3c: stur            x1, [fp, #-8]
    //     0x10e9c40: mov             x1, x2
    //     0x10e9c44: stur            x2, [fp, #-0x10]
    //     0x10e9c48: stur            x3, [fp, #-0x18]
    // 0x10e9c4c: CheckStackOverflow
    //     0x10e9c4c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10e9c50: cmp             SP, x16
    //     0x10e9c54: b.ls            #0x10e9cd0
    // 0x10e9c58: r1 = 1
    //     0x10e9c58: mov             x1, #1
    // 0x10e9c5c: r0 = AllocateContext()
    //     0x10e9c5c: bl              #0x13de838  ; AllocateContextStub
    // 0x10e9c60: mov             x1, x0
    // 0x10e9c64: ldur            x0, [fp, #-8]
    // 0x10e9c68: StoreField: r1->field_f = r0
    //     0x10e9c68: stur            w0, [x1, #0xf]
    // 0x10e9c6c: LoadField: r2 = r0->field_4f
    //     0x10e9c6c: ldur            w2, [x0, #0x4f]
    // 0x10e9c70: DecompressPointer r2
    //     0x10e9c70: add             x2, x2, HEAP, lsl #32
    // 0x10e9c74: cmp             w2, NULL
    // 0x10e9c78: b.eq            #0x10e9c90
    // 0x10e9c7c: LoadField: r5 = r0->field_5b
    //     0x10e9c7c: ldur            w5, [x0, #0x5b]
    // 0x10e9c80: DecompressPointer r5
    //     0x10e9c80: add             x5, x5, HEAP, lsl #32
    // 0x10e9c84: stur            x5, [fp, #-0x20]
    // 0x10e9c88: cmp             w5, NULL
    // 0x10e9c8c: b.ne            #0x10e9ca0
    // 0x10e9c90: r0 = false
    //     0x10e9c90: add             x0, NULL, #0x30  ; false
    // 0x10e9c94: LeaveFrame
    //     0x10e9c94: mov             SP, fp
    //     0x10e9c98: ldp             fp, lr, [SP], #0x10
    // 0x10e9c9c: ret
    //     0x10e9c9c: ret             
    // 0x10e9ca0: mov             x2, x1
    // 0x10e9ca4: r1 = Function '<anonymous closure>':.
    //     0x10e9ca4: add             x1, PP, #0x96, lsl #12  ; [pp+0x969f8] AnonymousClosure: (0x10e8b08), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::hitTestChildren (0x10e9c2c)
    //     0x10e9ca8: ldr             x1, [x1, #0x9f8]
    // 0x10e9cac: r0 = AllocateClosure()
    //     0x10e9cac: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10e9cb0: ldur            x1, [fp, #-0x10]
    // 0x10e9cb4: mov             x2, x0
    // 0x10e9cb8: ldur            x3, [fp, #-0x18]
    // 0x10e9cbc: ldur            x5, [fp, #-0x20]
    // 0x10e9cc0: r0 = addWithPaintTransform()
    //     0x10e9cc0: bl              #0x10e8cac  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x10e9cc4: LeaveFrame
    //     0x10e9cc4: mov             SP, fp
    //     0x10e9cc8: ldp             fp, lr, [SP], #0x10
    // 0x10e9ccc: ret
    //     0x10e9ccc: ret             
    // 0x10e9cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10e9cd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10e9cd4: b               #0x10e9c58
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10efed4, size: 0x24
    // 0x10efed4: EnterFrame
    //     0x10efed4: stp             fp, lr, [SP, #-0x10]!
    //     0x10efed8: mov             fp, SP
    // 0x10efedc: ldr             x2, [fp, #0x10]
    // 0x10efee0: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10efee0: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa1338] AnonymousClosure: (0xb23518), in [package:flutter/src/rendering/rotated_box.dart] RenderRotatedBox::computeMinIntrinsicHeight (0xb234ac)
    //     0x10efee4: ldr             x1, [x1, #0x338]
    // 0x10efee8: r0 = AllocateClosure()
    //     0x10efee8: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10efeec: LeaveFrame
    //     0x10efeec: mov             SP, fp
    //     0x10efef0: ldp             fp, lr, [SP], #0x10
    // 0x10efef4: ret
    //     0x10efef4: ret             
  }
  _ RenderRotatedBox(/* No info */) {
    // ** addr: 0x11d1220, size: 0xa8
    // 0x11d1220: EnterFrame
    //     0x11d1220: stp             fp, lr, [SP, #-0x10]!
    //     0x11d1224: mov             fp, SP
    // 0x11d1228: AllocStack(0x10)
    //     0x11d1228: sub             SP, SP, #0x10
    // 0x11d122c: SetupParameters(RenderRotatedBox this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x11d122c: mov             x0, x1
    //     0x11d1230: stur            x1, [fp, #-8]
    //     0x11d1234: stur            x2, [fp, #-0x10]
    // 0x11d1238: CheckStackOverflow
    //     0x11d1238: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11d123c: cmp             SP, x16
    //     0x11d1240: b.ls            #0x11d12c0
    // 0x11d1244: r1 = <TransformLayer>
    //     0x11d1244: add             x1, PP, #0x90, lsl #12  ; [pp+0x901b8] TypeArguments: <TransformLayer>
    //     0x11d1248: ldr             x1, [x1, #0x1b8]
    // 0x11d124c: r0 = LayerHandle()
    //     0x11d124c: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11d1250: ldur            x1, [fp, #-8]
    // 0x11d1254: StoreField: r1->field_5f = r0
    //     0x11d1254: stur            w0, [x1, #0x5f]
    //     0x11d1258: ldurb           w16, [x1, #-1]
    //     0x11d125c: ldurb           w17, [x0, #-1]
    //     0x11d1260: and             x16, x17, x16, lsr #2
    //     0x11d1264: tst             x16, HEAP, lsr #32
    //     0x11d1268: b.eq            #0x11d1270
    //     0x11d126c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11d1270: ldur            x0, [fp, #-0x10]
    // 0x11d1274: StoreField: r1->field_53 = r0
    //     0x11d1274: stur            x0, [x1, #0x53]
    // 0x11d1278: r0 = _LayoutCacheStorage()
    //     0x11d1278: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11d127c: ldur            x2, [fp, #-8]
    // 0x11d1280: StoreField: r2->field_47 = r0
    //     0x11d1280: stur            w0, [x2, #0x47]
    //     0x11d1284: ldurb           w16, [x2, #-1]
    //     0x11d1288: ldurb           w17, [x0, #-1]
    //     0x11d128c: and             x16, x17, x16, lsr #2
    //     0x11d1290: tst             x16, HEAP, lsr #32
    //     0x11d1294: b.eq            #0x11d129c
    //     0x11d1298: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11d129c: mov             x1, x2
    // 0x11d12a0: r0 = RenderObject()
    //     0x11d12a0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11d12a4: ldur            x1, [fp, #-8]
    // 0x11d12a8: r2 = Null
    //     0x11d12a8: mov             x2, NULL
    // 0x11d12ac: r0 = child=()
    //     0x11d12ac: bl              #0xaef33c  ; [dart:mixin_deduplication] _MixinApplication6&RenderBox&RenderObjectWithChildMixin::child=
    // 0x11d12b0: r0 = Null
    //     0x11d12b0: mov             x0, NULL
    // 0x11d12b4: LeaveFrame
    //     0x11d12b4: mov             SP, fp
    //     0x11d12b8: ldp             fp, lr, [SP], #0x10
    // 0x11d12bc: ret
    //     0x11d12bc: ret             
    // 0x11d12c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11d12c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11d12c4: b               #0x11d1244
  }
}
