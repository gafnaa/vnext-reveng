// lib: , url: package:flutter/src/rendering/error.dart

// class id: 1049026, size: 0x8
class :: {
}

// class id: 4726, size: 0x58, field offset: 0x50
class RenderErrorBox extends RenderBox {

  static late Color backgroundColor; // offset: 0xbf8
  static late EdgeInsets padding; // offset: 0xbf0
  late final Paragraph? _paragraph; // offset: 0x54

  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0xb2f500, size: 0xc
    // 0xb2f500: d0 = 100000.000000
    //     0xb2f500: add             x17, PP, #0x7c, lsl #12  ; [pp+0x7c330] IMM: double(1e+05) from 0x40f86a0000000000
    //     0xb2f504: ldr             d0, [x17, #0x330]
    // 0xb2f508: ret
    //     0xb2f508: ret             
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0xb2f50c, size: 0xc
    // 0xb2f50c: r0 = 100000.000000
    //     0xb2f50c: add             x0, PP, #0x96, lsl #12  ; [pp+0x96a38] 1e+05
    //     0xb2f510: ldr             x0, [x0, #0xa38]
    // 0xb2f514: ret
    //     0xb2f514: ret             
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xb573a0, size: 0x3c
    // 0xb573a0: EnterFrame
    //     0xb573a0: stp             fp, lr, [SP, #-0x10]!
    //     0xb573a4: mov             fp, SP
    // 0xb573a8: mov             x0, x1
    // 0xb573ac: mov             x1, x2
    // 0xb573b0: CheckStackOverflow
    //     0xb573b0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb573b4: cmp             SP, x16
    //     0xb573b8: b.ls            #0xb573d4
    // 0xb573bc: r2 = Instance_Size
    //     0xb573bc: add             x2, PP, #0x26, lsl #12  ; [pp+0x266a0] Obj!Size@12a7511
    //     0xb573c0: ldr             x2, [x2, #0x6a0]
    // 0xb573c4: r0 = constrain()
    //     0xb573c4: bl              #0x898bc0  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0xb573c8: LeaveFrame
    //     0xb573c8: mov             SP, fp
    //     0xb573cc: ldp             fp, lr, [SP], #0x10
    // 0xb573d0: ret
    //     0xb573d0: ret             
    // 0xb573d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb573d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb573d8: b               #0xb573bc
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58b34, size: 0x24
    // 0xb58b34: EnterFrame
    //     0xb58b34: stp             fp, lr, [SP, #-0x10]!
    //     0xb58b38: mov             fp, SP
    // 0xb58b3c: ldr             x2, [fp, #0x10]
    // 0xb58b40: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58b40: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa13a8] AnonymousClosure: (0xb2f50c), in [package:flutter/src/rendering/error.dart] RenderErrorBox::computeMaxIntrinsicWidth (0xb2f500)
    //     0xb58b44: ldr             x1, [x1, #0x3a8]
    // 0xb58b48: r0 = AllocateClosure()
    //     0xb58b48: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb58b4c: LeaveFrame
    //     0xb58b4c: mov             SP, fp
    //     0xb58b50: ldp             fp, lr, [SP], #0x10
    // 0xb58b54: ret
    //     0xb58b54: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5ec74, size: 0x24
    // 0xb5ec74: EnterFrame
    //     0xb5ec74: stp             fp, lr, [SP, #-0x10]!
    //     0xb5ec78: mov             fp, SP
    // 0xb5ec7c: ldr             x2, [fp, #0x10]
    // 0xb5ec80: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5ec80: add             x1, PP, #0x96, lsl #12  ; [pp+0x96a30] AnonymousClosure: (0xb2f50c), in [package:flutter/src/rendering/error.dart] RenderErrorBox::computeMaxIntrinsicWidth (0xb2f500)
    //     0xb5ec84: ldr             x1, [x1, #0xa30]
    // 0xb5ec88: r0 = AllocateClosure()
    //     0xb5ec88: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5ec8c: LeaveFrame
    //     0xb5ec8c: mov             SP, fp
    //     0xb5ec90: ldp             fp, lr, [SP], #0x10
    // 0xb5ec94: ret
    //     0xb5ec94: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xc2e7a0, size: 0x330
    // 0xc2e7a0: EnterFrame
    //     0xc2e7a0: stp             fp, lr, [SP, #-0x10]!
    //     0xc2e7a4: mov             fp, SP
    // 0xc2e7a8: AllocStack(0xd8)
    //     0xc2e7a8: sub             SP, SP, #0xd8
    // 0xc2e7ac: SetupParameters(RenderErrorBox this /* r1 => r3, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */, dynamic _ /* r3 => r0, fp-0x78 */)
    //     0xc2e7ac: mov             x0, x3
    //     0xc2e7b0: stur            x3, [fp, #-0x78]
    //     0xc2e7b4: mov             x3, x1
    //     0xc2e7b8: stur            x1, [fp, #-0x68]
    //     0xc2e7bc: stur            x2, [fp, #-0x70]
    // 0xc2e7c0: CheckStackOverflow
    //     0xc2e7c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc2e7c4: cmp             SP, x16
    //     0xc2e7c8: b.ls            #0xc2eab0
    // 0xc2e7cc: ArrayLoad: r1 = r2[0]  ; List_4
    //     0xc2e7cc: ldur            w1, [x2, #0x17]
    // 0xc2e7d0: DecompressPointer r1
    //     0xc2e7d0: add             x1, x1, HEAP, lsl #32
    // 0xc2e7d4: cmp             w1, NULL
    // 0xc2e7d8: b.ne            #0xc2e7e4
    // 0xc2e7dc: mov             x1, x2
    // 0xc2e7e0: r0 = _startRecording()
    //     0xc2e7e0: bl              #0xc176f8  ; [package:flutter/src/rendering/object.dart] PaintingContext::_startRecording
    // 0xc2e7e4: ldur            x2, [fp, #-0x68]
    // 0xc2e7e8: ldur            x0, [fp, #-0x70]
    // 0xc2e7ec: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xc2e7ec: ldur            w3, [x0, #0x17]
    // 0xc2e7f0: DecompressPointer r3
    //     0xc2e7f0: add             x3, x3, HEAP, lsl #32
    // 0xc2e7f4: stur            x3, [fp, #-0x80]
    // 0xc2e7f8: cmp             w3, NULL
    // 0xc2e7fc: b.eq            #0xc2eab8
    // 0xc2e800: mov             x1, x2
    // 0xc2e804: r0 = size()
    //     0xc2e804: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2e808: ldur            x1, [fp, #-0x78]
    // 0xc2e80c: mov             x2, x0
    // 0xc2e810: r0 = &()
    //     0xc2e810: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc2e814: stur            x0, [fp, #-0x88]
    // 0xc2e818: r0 = Paint()
    //     0xc2e818: bl              #0x85c688  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc2e81c: stur            x0, [fp, #-0x90]
    // 0xc2e820: r16 = 136
    //     0xc2e820: mov             x16, #0x88
    // 0xc2e824: stp             x16, NULL, [SP]
    // 0xc2e828: r0 = ByteData()
    //     0xc2e828: bl              #0x81de08  ; [dart:typed_data] ByteData::ByteData
    // 0xc2e82c: ldur            x1, [fp, #-0x90]
    // 0xc2e830: StoreField: r1->field_7 = r0
    //     0xc2e830: stur            w0, [x1, #7]
    //     0xc2e834: ldurb           w16, [x1, #-1]
    //     0xc2e838: ldurb           w17, [x0, #-1]
    //     0xc2e83c: and             x16, x17, x16, lsr #2
    //     0xc2e840: tst             x16, HEAP, lsr #32
    //     0xc2e844: b.eq            #0xc2e84c
    //     0xc2e848: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc2e84c: r0 = LoadStaticField(0xbf8)
    //     0xc2e84c: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xc2e850: ldr             x0, [x0, #0x17f0]
    // 0xc2e854: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc2e858: cmp             w0, w16
    // 0xc2e85c: b.ne            #0xc2e86c
    // 0xc2e860: r2 = backgroundColor
    //     0xc2e860: add             x2, PP, #0x15, lsl #12  ; [pp+0x15438] Field <RenderErrorBox.backgroundColor>: static late (offset: 0xbf8)
    //     0xc2e864: ldr             x2, [x2, #0x438]
    // 0xc2e868: r0 = InitLateStaticField()
    //     0xc2e868: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xc2e86c: ldur            x1, [fp, #-0x90]
    // 0xc2e870: r2 = Instance_Color
    //     0xc2e870: add             x2, PP, #0x15, lsl #12  ; [pp+0x15440] Obj!Color@12a28b1
    //     0xc2e874: ldr             x2, [x2, #0x440]
    // 0xc2e878: r0 = color=()
    //     0xc2e878: bl              #0x85c494  ; [dart:ui] Paint::color=
    // 0xc2e87c: ldur            x1, [fp, #-0x80]
    // 0xc2e880: ldur            x2, [fp, #-0x88]
    // 0xc2e884: ldur            x3, [fp, #-0x90]
    // 0xc2e888: r0 = drawRect()
    //     0xc2e888: bl              #0xb704c8  ; [dart:ui] _NativeCanvas::drawRect
    // 0xc2e88c: ldur            x0, [fp, #-0x68]
    // 0xc2e890: LoadField: r1 = r0->field_53
    //     0xc2e890: ldur            w1, [x0, #0x53]
    // 0xc2e894: DecompressPointer r1
    //     0xc2e894: add             x1, x1, HEAP, lsl #32
    // 0xc2e898: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc2e89c: cmp             w1, w16
    // 0xc2e8a0: b.eq            #0xc2eabc
    // 0xc2e8a4: cmp             w1, NULL
    // 0xc2e8a8: b.eq            #0xc2ea7c
    // 0xc2e8ac: mov             x1, x0
    // 0xc2e8b0: r0 = size()
    //     0xc2e8b0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2e8b4: LoadField: d0 = r0->field_7
    //     0xc2e8b4: ldur            d0, [x0, #7]
    // 0xc2e8b8: stur            d0, [fp, #-0xa8]
    // 0xc2e8bc: r0 = LoadStaticField(0xbf0)
    //     0xc2e8bc: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xc2e8c0: ldr             x0, [x0, #0x17e0]
    // 0xc2e8c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc2e8c8: cmp             w0, w16
    // 0xc2e8cc: b.ne            #0xc2e8dc
    // 0xc2e8d0: r2 = padding
    //     0xc2e8d0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15448] Field <RenderErrorBox.padding>: static late (offset: 0xbf0)
    //     0xc2e8d4: ldr             x2, [x2, #0x448]
    // 0xc2e8d8: r0 = InitLateStaticField()
    //     0xc2e8d8: bl              #0x13dda54  ; InitLateStaticFieldStub
    // 0xc2e8dc: ldur            d0, [fp, #-0xa8]
    // 0xc2e8e0: d1 = 328.000000
    //     0xc2e8e0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15450] IMM: double(328) from 0x4074800000000000
    //     0xc2e8e4: ldr             d1, [x17, #0x450]
    // 0xc2e8e8: fcmp            d0, d1
    // 0xc2e8ec: b.le            #0xc2e90c
    // 0xc2e8f0: d1 = 128.000000
    //     0xc2e8f0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15458] IMM: double(128) from 0x4060000000000000
    //     0xc2e8f4: ldr             d1, [x17, #0x458]
    // 0xc2e8f8: fsub            d2, d0, d1
    // 0xc2e8fc: mov             v1.16b, v2.16b
    // 0xc2e900: d0 = 64.000000
    //     0xc2e900: add             x17, PP, #0x13, lsl #12  ; [pp+0x13a68] IMM: double(64) from 0x4050000000000000
    //     0xc2e904: ldr             d0, [x17, #0xa68]
    // 0xc2e908: b               #0xc2e914
    // 0xc2e90c: mov             v1.16b, v0.16b
    // 0xc2e910: d0 = 0.000000
    //     0xc2e910: eor             v0.16b, v0.16b, v0.16b
    // 0xc2e914: ldur            x1, [fp, #-0x68]
    // 0xc2e918: stur            d1, [fp, #-0xa8]
    // 0xc2e91c: stur            d0, [fp, #-0xb0]
    // 0xc2e920: LoadField: r0 = r1->field_53
    //     0xc2e920: ldur            w0, [x1, #0x53]
    // 0xc2e924: DecompressPointer r0
    //     0xc2e924: add             x0, x0, HEAP, lsl #32
    // 0xc2e928: stur            x0, [fp, #-0x80]
    // 0xc2e92c: r0 = ParagraphConstraints()
    //     0xc2e92c: bl              #0xc2ead0  ; AllocateParagraphConstraintsStub -> ParagraphConstraints (size=0x10)
    // 0xc2e930: ldur            d0, [fp, #-0xa8]
    // 0xc2e934: StoreField: r0->field_7 = d0
    //     0xc2e934: stur            d0, [x0, #7]
    // 0xc2e938: ldur            x0, [fp, #-0x80]
    // 0xc2e93c: LoadField: r1 = r0->field_7
    //     0xc2e93c: ldur            w1, [x0, #7]
    // 0xc2e940: DecompressPointer r1
    //     0xc2e940: add             x1, x1, HEAP, lsl #32
    // 0xc2e944: cmp             w1, NULL
    // 0xc2e948: b.eq            #0xc2eac8
    // 0xc2e94c: LoadField: r2 = r1->field_7
    //     0xc2e94c: ldur            x2, [x1, #7]
    // 0xc2e950: ldr             x3, [x2]
    // 0xc2e954: stur            x3, [fp, #-0x98]
    // 0xc2e958: cbz             x3, #0xc2ea8c
    // 0xc2e95c: ldur            x2, [fp, #-0x68]
    // 0xc2e960: r1 = <Never>
    //     0xc2e960: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc2e964: r0 = Pointer()
    //     0xc2e964: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc2e968: ldur            x1, [fp, #-0x98]
    // 0xc2e96c: StoreField: r0->field_7 = r1
    //     0xc2e96c: stur            x1, [x0, #7]
    // 0xc2e970: mov             x1, x0
    // 0xc2e974: ldur            d0, [fp, #-0xa8]
    // 0xc2e978: r0 = __layout$Method$FfiNative()
    //     0xc2e978: bl              #0x85a058  ; [dart:ui] _NativeParagraph::__layout$Method$FfiNative
    // 0xc2e97c: ldur            x1, [fp, #-0x68]
    // 0xc2e980: r0 = size()
    //     0xc2e980: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc2e984: LoadField: d0 = r0->field_f
    //     0xc2e984: ldur            d0, [x0, #0xf]
    // 0xc2e988: stur            d0, [fp, #-0xc0]
    // 0xc2e98c: r0 = Instance_EdgeInsets
    //     0xc2e98c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15460] Obj!EdgeInsets@129ccf1
    //     0xc2e990: ldr             x0, [x0, #0x460]
    // 0xc2e994: LoadField: d1 = r0->field_f
    //     0xc2e994: ldur            d1, [x0, #0xf]
    // 0xc2e998: ldur            x2, [fp, #-0x68]
    // 0xc2e99c: stur            d1, [fp, #-0xb8]
    // 0xc2e9a0: LoadField: r3 = r2->field_53
    //     0xc2e9a0: ldur            w3, [x2, #0x53]
    // 0xc2e9a4: DecompressPointer r3
    //     0xc2e9a4: add             x3, x3, HEAP, lsl #32
    // 0xc2e9a8: stur            x3, [fp, #-0x88]
    // 0xc2e9ac: LoadField: r1 = r3->field_7
    //     0xc2e9ac: ldur            w1, [x3, #7]
    // 0xc2e9b0: DecompressPointer r1
    //     0xc2e9b0: add             x1, x1, HEAP, lsl #32
    // 0xc2e9b4: cmp             w1, NULL
    // 0xc2e9b8: b.eq            #0xc2eacc
    // 0xc2e9bc: LoadField: r4 = r1->field_7
    //     0xc2e9bc: ldur            x4, [x1, #7]
    // 0xc2e9c0: ldr             x5, [x4]
    // 0xc2e9c4: stur            x5, [fp, #-0x98]
    // 0xc2e9c8: cbz             x5, #0xc2eaa0
    // 0xc2e9cc: r1 = <Never>
    //     0xc2e9cc: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc2e9d0: r0 = Pointer()
    //     0xc2e9d0: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc2e9d4: ldur            x1, [fp, #-0x98]
    // 0xc2e9d8: StoreField: r0->field_7 = r1
    //     0xc2e9d8: stur            x1, [x0, #7]
    // 0xc2e9dc: mov             x1, x0
    // 0xc2e9e0: r0 = _height$Getter$FfiNative()
    //     0xc2e9e0: bl              #0x859d8c  ; [dart:ui] _NativeParagraph::_height$Getter$FfiNative
    // 0xc2e9e4: ldur            d1, [fp, #-0xb8]
    // 0xc2e9e8: fadd            d2, d1, d0
    // 0xc2e9ec: r0 = Instance_EdgeInsets
    //     0xc2e9ec: add             x0, PP, #0x15, lsl #12  ; [pp+0x15460] Obj!EdgeInsets@129ccf1
    //     0xc2e9f0: ldr             x0, [x0, #0x460]
    // 0xc2e9f4: LoadField: d0 = r0->field_1f
    //     0xc2e9f4: ldur            d0, [x0, #0x1f]
    // 0xc2e9f8: fadd            d1, d2, d0
    // 0xc2e9fc: ldur            d0, [fp, #-0xc0]
    // 0xc2ea00: fcmp            d0, d1
    // 0xc2ea04: b.le            #0xc2ea14
    // 0xc2ea08: d1 = 96.000000
    //     0xc2ea08: add             x17, PP, #0x13, lsl #12  ; [pp+0x13580] IMM: double(96) from 0x4058000000000000
    //     0xc2ea0c: ldr             d1, [x17, #0x580]
    // 0xc2ea10: b               #0xc2ea18
    // 0xc2ea14: d1 = 0.000000
    //     0xc2ea14: eor             v1.16b, v1.16b, v1.16b
    // 0xc2ea18: ldur            x0, [fp, #-0x68]
    // 0xc2ea1c: ldur            d0, [fp, #-0xb0]
    // 0xc2ea20: ldur            x1, [fp, #-0x70]
    // 0xc2ea24: stur            d1, [fp, #-0xc8]
    // 0xc2ea28: r0 = canvas()
    //     0xc2ea28: bl              #0xc17694  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xc2ea2c: mov             x1, x0
    // 0xc2ea30: ldur            x0, [fp, #-0x68]
    // 0xc2ea34: stur            x1, [fp, #-0xa0]
    // 0xc2ea38: LoadField: r2 = r0->field_53
    //     0xc2ea38: ldur            w2, [x0, #0x53]
    // 0xc2ea3c: DecompressPointer r2
    //     0xc2ea3c: add             x2, x2, HEAP, lsl #32
    // 0xc2ea40: stur            x2, [fp, #-0x90]
    // 0xc2ea44: r0 = Offset()
    //     0xc2ea44: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc2ea48: ldur            d0, [fp, #-0xb0]
    // 0xc2ea4c: StoreField: r0->field_7 = d0
    //     0xc2ea4c: stur            d0, [x0, #7]
    // 0xc2ea50: ldur            d1, [fp, #-0xc8]
    // 0xc2ea54: StoreField: r0->field_f = d1
    //     0xc2ea54: stur            d1, [x0, #0xf]
    // 0xc2ea58: ldur            x1, [fp, #-0x78]
    // 0xc2ea5c: mov             x2, x0
    // 0xc2ea60: r0 = +()
    //     0xc2ea60: bl              #0x81cdb4  ; [dart:ui] Offset::+
    // 0xc2ea64: ldur            x1, [fp, #-0xa0]
    // 0xc2ea68: ldur            x2, [fp, #-0x90]
    // 0xc2ea6c: mov             x3, x0
    // 0xc2ea70: r0 = drawParagraph()
    //     0xc2ea70: bl              #0xc231e8  ; [dart:ui] _NativeCanvas::drawParagraph
    // 0xc2ea74: b               #0xc2ea7c
    // 0xc2ea78: sub             SP, fp, #0xd8
    // 0xc2ea7c: r0 = Null
    //     0xc2ea7c: mov             x0, NULL
    // 0xc2ea80: LeaveFrame
    //     0xc2ea80: mov             SP, fp
    //     0xc2ea84: ldp             fp, lr, [SP], #0x10
    // 0xc2ea88: ret
    //     0xc2ea88: ret             
    // 0xc2ea8c: ldur            x0, [fp, #-0x68]
    // 0xc2ea90: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc2ea90: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc2ea94: str             x16, [SP]
    // 0xc2ea98: r0 = _throwNew()
    //     0xc2ea98: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc2ea9c: brk             #0
    // 0xc2eaa0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc2eaa0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc2eaa4: str             x16, [SP]
    // 0xc2eaa8: r0 = _throwNew()
    //     0xc2eaa8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc2eaac: brk             #0
    // 0xc2eab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2eab0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2eab4: b               #0xc2e7cc
    // 0xc2eab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc2eab8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc2eabc: r9 = _paragraph
    //     0xc2eabc: add             x9, PP, #0x15, lsl #12  ; [pp+0x15468] Field <RenderErrorBox._paragraph@601451017>: late final (offset: 0x54)
    //     0xc2eac0: ldr             x9, [x9, #0x468]
    // 0xc2eac4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc2eac4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xc2eac8: r0 = NullErrorSharedWithFPURegs()
    //     0xc2eac8: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
    // 0xc2eacc: r0 = NullErrorSharedWithFPURegs()
    //     0xc2eacc: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  static EdgeInsets padding() {
    // ** addr: 0xc2eadc, size: 0xc
    // 0xc2eadc: r0 = Instance_EdgeInsets
    //     0xc2eadc: add             x0, PP, #0x15, lsl #12  ; [pp+0x15460] Obj!EdgeInsets@129ccf1
    //     0xc2eae0: ldr             x0, [x0, #0x460]
    // 0xc2eae4: ret
    //     0xc2eae4: ret             
  }
  static Color backgroundColor() {
    // ** addr: 0xc2eae8, size: 0xc
    // 0xc2eae8: r0 = Instance_Color
    //     0xc2eae8: add             x0, PP, #0x15, lsl #12  ; [pp+0x15440] Obj!Color@12a28b1
    //     0xc2eaec: ldr             x0, [x0, #0x440]
    // 0xc2eaf0: ret
    //     0xc2eaf0: ret             
  }
  _ RenderErrorBox(/* No info */) {
    // ** addr: 0x11c0e50, size: 0xa8
    // 0x11c0e50: EnterFrame
    //     0x11c0e50: stp             fp, lr, [SP, #-0x10]!
    //     0x11c0e54: mov             fp, SP
    // 0x11c0e58: AllocStack(0x48)
    //     0x11c0e58: sub             SP, SP, #0x48
    // 0x11c0e5c: ldr             x2, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0e60: r0 = ""
    //     0x11c0e60: ldr             x0, [PP, #0x900]  ; [pp+0x900] ""
    // 0x11c0e64: stur            x1, [fp, #-0x40]
    // 0x11c0e68: CheckStackOverflow
    //     0x11c0e68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11c0e6c: cmp             SP, x16
    //     0x11c0e70: b.ls            #0x11c0ef0
    // 0x11c0e74: StoreField: r1->field_53 = r2
    //     0x11c0e74: stur            w2, [x1, #0x53]
    // 0x11c0e78: StoreField: r1->field_4f = r0
    //     0x11c0e78: stur            w0, [x1, #0x4f]
    // 0x11c0e7c: r0 = _LayoutCacheStorage()
    //     0x11c0e7c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11c0e80: ldur            x2, [fp, #-0x40]
    // 0x11c0e84: StoreField: r2->field_47 = r0
    //     0x11c0e84: stur            w0, [x2, #0x47]
    //     0x11c0e88: ldurb           w16, [x2, #-1]
    //     0x11c0e8c: ldurb           w17, [x0, #-1]
    //     0x11c0e90: and             x16, x17, x16, lsr #2
    //     0x11c0e94: tst             x16, HEAP, lsr #32
    //     0x11c0e98: b.eq            #0x11c0ea0
    //     0x11c0e9c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x11c0ea0: mov             x1, x2
    // 0x11c0ea4: r0 = RenderObject()
    //     0x11c0ea4: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11c0ea8: ldur            x0, [fp, #-0x40]
    // 0x11c0eac: LoadField: r1 = r0->field_53
    //     0x11c0eac: ldur            w1, [x0, #0x53]
    // 0x11c0eb0: DecompressPointer r1
    //     0x11c0eb0: add             x1, x1, HEAP, lsl #32
    // 0x11c0eb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x11c0eb8: cmp             w1, w16
    // 0x11c0ebc: b.ne            #0x11c0edc
    // 0x11c0ec0: StoreField: r0->field_53 = rNULL
    //     0x11c0ec0: stur            NULL, [x0, #0x53]
    // 0x11c0ec4: b               #0x11c0ecc
    // 0x11c0ec8: sub             SP, fp, #0x48
    // 0x11c0ecc: r0 = Null
    //     0x11c0ecc: mov             x0, NULL
    // 0x11c0ed0: LeaveFrame
    //     0x11c0ed0: mov             SP, fp
    //     0x11c0ed4: ldp             fp, lr, [SP], #0x10
    // 0x11c0ed8: ret
    //     0x11c0ed8: ret             
    // 0x11c0edc: r16 = "_paragraph@601451017"
    //     0x11c0edc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12590] "_paragraph@601451017"
    //     0x11c0ee0: ldr             x16, [x16, #0x590]
    // 0x11c0ee4: str             x16, [SP]
    // 0x11c0ee8: r0 = _throwFieldAlreadyInitialized()
    //     0x11c0ee8: bl              #0x82b720  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x11c0eec: brk             #0
    // 0x11c0ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11c0ef0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11c0ef4: b               #0x11c0e74
  }
}
