// lib: , url: package:flutter/src/rendering/layer.dart

// class id: 1049030, size: 0x8
class :: {
}

// class id: 2865, size: 0x10, field offset: 0x8
class LayerLink extends Object {

  _ _unregisterLeader(/* No info */) {
    // ** addr: 0xc1d548, size: 0x1c
    // 0xc1d548: LoadField: r3 = r1->field_7
    //     0xc1d548: ldur            w3, [x1, #7]
    // 0xc1d54c: DecompressPointer r3
    //     0xc1d54c: add             x3, x3, HEAP, lsl #32
    // 0xc1d550: cmp             w3, w2
    // 0xc1d554: b.ne            #0xc1d55c
    // 0xc1d558: StoreField: r1->field_7 = rNULL
    //     0xc1d558: stur            NULL, [x1, #7]
    // 0xc1d55c: r0 = Null
    //     0xc1d55c: mov             x0, NULL
    // 0xc1d560: ret
    //     0xc1d560: ret             
  }
}

// class id: 2867, size: 0x10, field offset: 0x8
class LayerHandle<X0 bound Layer> extends Object {

  set _ layer=(/* No info */) {
    // ** addr: 0x89af68, size: 0x104
    // 0x89af68: EnterFrame
    //     0x89af68: stp             fp, lr, [SP, #-0x10]!
    //     0x89af6c: mov             fp, SP
    // 0x89af70: AllocStack(0x18)
    //     0x89af70: sub             SP, SP, #0x18
    // 0x89af74: SetupParameters(LayerHandle<X0 bound Layer> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x89af74: mov             x4, x1
    //     0x89af78: mov             x3, x2
    //     0x89af7c: stur            x1, [fp, #-8]
    //     0x89af80: stur            x2, [fp, #-0x10]
    // 0x89af84: CheckStackOverflow
    //     0x89af84: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89af88: cmp             SP, x16
    //     0x89af8c: b.ls            #0x89b064
    // 0x89af90: LoadField: r2 = r4->field_7
    //     0x89af90: ldur            w2, [x4, #7]
    // 0x89af94: DecompressPointer r2
    //     0x89af94: add             x2, x2, HEAP, lsl #32
    // 0x89af98: mov             x0, x3
    // 0x89af9c: r1 = Null
    //     0x89af9c: mov             x1, NULL
    // 0x89afa0: cmp             w0, NULL
    // 0x89afa4: b.eq            #0x89afc8
    // 0x89afa8: cmp             w2, NULL
    // 0x89afac: b.eq            #0x89afc8
    // 0x89afb0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x89afb0: ldur            w4, [x2, #0x17]
    // 0x89afb4: DecompressPointer r4
    //     0x89afb4: add             x4, x4, HEAP, lsl #32
    // 0x89afb8: r8 = X0? bound Layer
    //     0x89afb8: ldr             x8, [PP, #0x2d90]  ; [pp+0x2d90] TypeParameter: X0? bound Layer
    // 0x89afbc: LoadField: r9 = r4->field_7
    //     0x89afbc: ldur            x9, [x4, #7]
    // 0x89afc0: r3 = Null
    //     0x89afc0: ldr             x3, [PP, #0x2d98]  ; [pp+0x2d98] Null
    // 0x89afc4: blr             x9
    // 0x89afc8: ldur            x2, [fp, #-8]
    // 0x89afcc: LoadField: r3 = r2->field_b
    //     0x89afcc: ldur            w3, [x2, #0xb]
    // 0x89afd0: DecompressPointer r3
    //     0x89afd0: add             x3, x3, HEAP, lsl #32
    // 0x89afd4: ldur            x0, [fp, #-0x10]
    // 0x89afd8: mov             x1, x3
    // 0x89afdc: stur            x3, [fp, #-0x18]
    // 0x89afe0: stp             x1, x0, [SP, #-0x10]!
    // 0x89afe4: r30 = OptimizedIdenticalWithNumberCheckStub
    //     0x89afe4: ldr             lr, [PP, #0x428]  ; [pp+0x428] Stub: OptimizedIdenticalWithNumberCheck (0x7d32ac)
    // 0x89afe8: LoadField: r30 = r30->field_7
    //     0x89afe8: ldur            lr, [lr, #7]
    // 0x89afec: blr             lr
    // 0x89aff0: ldp             x1, x0, [SP], #0x10
    // 0x89aff4: b.ne            #0x89b008
    // 0x89aff8: r0 = Null
    //     0x89aff8: mov             x0, NULL
    // 0x89affc: LeaveFrame
    //     0x89affc: mov             SP, fp
    //     0x89b000: ldp             fp, lr, [SP], #0x10
    // 0x89b004: ret
    //     0x89b004: ret             
    // 0x89b008: ldur            x1, [fp, #-0x18]
    // 0x89b00c: cmp             w1, NULL
    // 0x89b010: b.eq            #0x89b018
    // 0x89b014: r0 = _unref()
    //     0x89b014: bl              #0x89ae14  ; [package:flutter/src/rendering/layer.dart] Layer::_unref
    // 0x89b018: ldur            x1, [fp, #-8]
    // 0x89b01c: ldur            x2, [fp, #-0x10]
    // 0x89b020: mov             x0, x2
    // 0x89b024: StoreField: r1->field_b = r0
    //     0x89b024: stur            w0, [x1, #0xb]
    //     0x89b028: ldurb           w16, [x1, #-1]
    //     0x89b02c: ldurb           w17, [x0, #-1]
    //     0x89b030: and             x16, x17, x16, lsr #2
    //     0x89b034: tst             x16, HEAP, lsr #32
    //     0x89b038: b.eq            #0x89b040
    //     0x89b03c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x89b040: cmp             w2, NULL
    // 0x89b044: b.eq            #0x89b054
    // 0x89b048: ArrayLoad: r1 = r2[0]  ; List_8
    //     0x89b048: ldur            x1, [x2, #0x17]
    // 0x89b04c: add             x3, x1, #1
    // 0x89b050: ArrayStore: r2[0] = r3  ; List_8
    //     0x89b050: stur            x3, [x2, #0x17]
    // 0x89b054: r0 = Null
    //     0x89b054: mov             x0, NULL
    // 0x89b058: LeaveFrame
    //     0x89b058: mov             SP, fp
    //     0x89b05c: ldp             fp, lr, [SP], #0x10
    // 0x89b060: ret
    //     0x89b060: ret             
    // 0x89b064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89b064: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89b068: b               #0x89af90
  }
}

// class id: 2868, size: 0x10, field offset: 0x8
class AnnotationResult<X0> extends Object {
}

// class id: 2869, size: 0x10, field offset: 0x8
//   const constructor, 
class AnnotationEntry<X0> extends Object {
}

// class id: 4648, size: 0x40, field offset: 0x8
abstract class Layer extends _MixinApplication5&Object&DiagnosticableTreeMixin {

  _ find(/* No info */) {
    // ** addr: 0x899760, size: 0xf4
    // 0x899760: EnterFrame
    //     0x899760: stp             fp, lr, [SP, #-0x10]!
    //     0x899764: mov             fp, SP
    // 0x899768: AllocStack(0x30)
    //     0x899768: sub             SP, SP, #0x30
    // 0x89976c: SetupParameters()
    //     0x89976c: ldur            w0, [x4, #0xf]
    //     0x899770: cbnz            w0, #0x89977c
    //     0x899774: mov             x1, NULL
    //     0x899778: b               #0x89978c
    //     0x89977c: ldur            w1, [x4, #0x17]
    //     0x899780: add             x2, fp, w1, sxtw #2
    //     0x899784: ldr             x2, [x2, #0x10]
    //     0x899788: mov             x1, x2
    // 0x89978c: CheckStackOverflow
    //     0x89978c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x899790: cmp             SP, x16
    //     0x899794: b.ls            #0x89984c
    // 0x899798: cbnz            w0, #0x8997a4
    // 0x89979c: r4 = <Object>
    //     0x89979c: ldr             x4, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x8997a0: b               #0x8997a8
    // 0x8997a4: mov             x4, x1
    // 0x8997a8: ldr             x0, [fp, #0x18]
    // 0x8997ac: mov             x2, x4
    // 0x8997b0: stur            x4, [fp, #-8]
    // 0x8997b4: r1 = Null
    //     0x8997b4: mov             x1, NULL
    // 0x8997b8: r3 = <AnnotationEntry<X0>>
    //     0x8997b8: ldr             x3, [PP, #0x2c90]  ; [pp+0x2c90] TypeArguments: <AnnotationEntry<X0>>
    // 0x8997bc: r30 = InstantiateTypeArgumentsStub
    //     0x8997bc: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x8997c0: LoadField: r30 = r30->field_7
    //     0x8997c0: ldur            lr, [lr, #7]
    // 0x8997c4: blr             lr
    // 0x8997c8: mov             x1, x0
    // 0x8997cc: r2 = 0
    //     0x8997cc: mov             x2, #0
    // 0x8997d0: r0 = _GrowableList()
    //     0x8997d0: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x8997d4: ldur            x1, [fp, #-8]
    // 0x8997d8: stur            x0, [fp, #-0x10]
    // 0x8997dc: r0 = AnnotationResult()
    //     0x8997dc: bl              #0x899854  ; AllocateAnnotationResultStub -> AnnotationResult<X0> (size=0x10)
    // 0x8997e0: ldur            x1, [fp, #-0x10]
    // 0x8997e4: StoreField: r0->field_b = r1
    //     0x8997e4: stur            w1, [x0, #0xb]
    // 0x8997e8: ldr             x2, [fp, #0x18]
    // 0x8997ec: r3 = LoadClassIdInstr(r2)
    //     0x8997ec: ldur            x3, [x2, #-1]
    //     0x8997f0: ubfx            x3, x3, #0xc, #0x14
    // 0x8997f4: ldur            x16, [fp, #-8]
    // 0x8997f8: stp             x2, x16, [SP, #0x10]
    // 0x8997fc: ldr             x16, [fp, #0x10]
    // 0x899800: stp             x16, x0, [SP]
    // 0x899804: mov             x0, x3
    // 0x899808: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x899808: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x89980c: r0 = GDT[cid_x0 + 0x7ae1]()
    //     0x89980c: mov             x17, #0x7ae1
    //     0x899810: add             lr, x0, x17
    //     0x899814: ldr             lr, [x21, lr, lsl #3]
    //     0x899818: blr             lr
    // 0x89981c: ldur            x1, [fp, #-0x10]
    // 0x899820: LoadField: r0 = r1->field_b
    //     0x899820: ldur            w0, [x1, #0xb]
    // 0x899824: cbnz            w0, #0x899830
    // 0x899828: r0 = Null
    //     0x899828: mov             x0, NULL
    // 0x89982c: b               #0x899840
    // 0x899830: r0 = first()
    //     0x899830: bl              #0xbb5720  ; [dart:core] _GrowableList::first
    // 0x899834: LoadField: r1 = r0->field_b
    //     0x899834: ldur            w1, [x0, #0xb]
    // 0x899838: DecompressPointer r1
    //     0x899838: add             x1, x1, HEAP, lsl #32
    // 0x89983c: mov             x0, x1
    // 0x899840: LeaveFrame
    //     0x899840: mov             SP, fp
    //     0x899844: ldp             fp, lr, [SP], #0x10
    // 0x899848: ret
    //     0x899848: ret             
    // 0x89984c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89984c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x899850: b               #0x899798
  }
  _ markNeedsAddToScene(/* No info */) {
    // ** addr: 0x89a714, size: 0x24
    // 0x89a714: LoadField: r2 = r1->field_23
    //     0x89a714: ldur            w2, [x1, #0x23]
    // 0x89a718: DecompressPointer r2
    //     0x89a718: add             x2, x2, HEAP, lsl #32
    // 0x89a71c: tbnz            w2, #4, #0x89a728
    // 0x89a720: r0 = Null
    //     0x89a720: mov             x0, NULL
    // 0x89a724: ret
    //     0x89a724: ret             
    // 0x89a728: r2 = true
    //     0x89a728: add             x2, NULL, #0x20  ; true
    // 0x89a72c: StoreField: r1->field_23 = r2
    //     0x89a72c: stur            w2, [x1, #0x23]
    // 0x89a730: r0 = Null
    //     0x89a730: mov             x0, NULL
    // 0x89a734: ret
    //     0x89a734: ret             
  }
  _ _unref(/* No info */) {
    // ** addr: 0x89ae14, size: 0x54
    // 0x89ae14: EnterFrame
    //     0x89ae14: stp             fp, lr, [SP, #-0x10]!
    //     0x89ae18: mov             fp, SP
    // 0x89ae1c: CheckStackOverflow
    //     0x89ae1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89ae20: cmp             SP, x16
    //     0x89ae24: b.ls            #0x89ae60
    // 0x89ae28: ArrayLoad: r0 = r1[0]  ; List_8
    //     0x89ae28: ldur            x0, [x1, #0x17]
    // 0x89ae2c: sub             x2, x0, #1
    // 0x89ae30: ArrayStore: r1[0] = r2  ; List_8
    //     0x89ae30: stur            x2, [x1, #0x17]
    // 0x89ae34: cbnz            x2, #0x89ae50
    // 0x89ae38: r0 = LoadClassIdInstr(r1)
    //     0x89ae38: ldur            x0, [x1, #-1]
    //     0x89ae3c: ubfx            x0, x0, #0xc, #0x14
    // 0x89ae40: r0 = GDT[cid_x0 + 0xafe8]()
    //     0x89ae40: mov             x17, #0xafe8
    //     0x89ae44: add             lr, x0, x17
    //     0x89ae48: ldr             lr, [x21, lr, lsl #3]
    //     0x89ae4c: blr             lr
    // 0x89ae50: r0 = Null
    //     0x89ae50: mov             x0, NULL
    // 0x89ae54: LeaveFrame
    //     0x89ae54: mov             SP, fp
    //     0x89ae58: ldp             fp, lr, [SP], #0x10
    // 0x89ae5c: ret
    //     0x89ae5c: ret             
    // 0x89ae60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89ae60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89ae64: b               #0x89ae28
  }
  _ _updateSubtreeCompositionObserverCount(/* No info */) {
    // ** addr: 0x89af18, size: 0x50
    // 0x89af18: EnterFrame
    //     0x89af18: stp             fp, lr, [SP, #-0x10]!
    //     0x89af1c: mov             fp, SP
    // 0x89af20: CheckStackOverflow
    //     0x89af20: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89af24: cmp             SP, x16
    //     0x89af28: b.ls            #0x89af60
    // 0x89af2c: LoadField: r0 = r1->field_b
    //     0x89af2c: ldur            x0, [x1, #0xb]
    // 0x89af30: add             x3, x0, x2
    // 0x89af34: StoreField: r1->field_b = r3
    //     0x89af34: stur            x3, [x1, #0xb]
    // 0x89af38: LoadField: r0 = r1->field_1f
    //     0x89af38: ldur            w0, [x1, #0x1f]
    // 0x89af3c: DecompressPointer r0
    //     0x89af3c: add             x0, x0, HEAP, lsl #32
    // 0x89af40: cmp             w0, NULL
    // 0x89af44: b.eq            #0x89af50
    // 0x89af48: mov             x1, x0
    // 0x89af4c: r0 = _updateSubtreeCompositionObserverCount()
    //     0x89af4c: bl              #0x89af18  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0x89af50: r0 = Null
    //     0x89af50: mov             x0, NULL
    // 0x89af54: LeaveFrame
    //     0x89af54: mov             SP, fp
    //     0x89af58: ldp             fp, lr, [SP], #0x10
    // 0x89af5c: ret
    //     0x89af5c: ret             
    // 0x89af60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89af60: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89af64: b               #0x89af2c
  }
  _ Layer(/* No info */) {
    // ** addr: 0x89d078, size: 0xa0
    // 0x89d078: EnterFrame
    //     0x89d078: stp             fp, lr, [SP, #-0x10]!
    //     0x89d07c: mov             fp, SP
    // 0x89d080: AllocStack(0x18)
    //     0x89d080: sub             SP, SP, #0x18
    // 0x89d084: r0 = true
    //     0x89d084: add             x0, NULL, #0x20  ; true
    // 0x89d088: stur            x1, [fp, #-8]
    // 0x89d08c: CheckStackOverflow
    //     0x89d08c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89d090: cmp             SP, x16
    //     0x89d094: b.ls            #0x89d110
    // 0x89d098: StoreField: r1->field_b = rZR
    //     0x89d098: stur            xzr, [x1, #0xb]
    // 0x89d09c: ArrayStore: r1[0] = rZR  ; List_8
    //     0x89d09c: stur            xzr, [x1, #0x17]
    // 0x89d0a0: StoreField: r1->field_23 = r0
    //     0x89d0a0: stur            w0, [x1, #0x23]
    // 0x89d0a4: StoreField: r1->field_2f = rZR
    //     0x89d0a4: stur            xzr, [x1, #0x2f]
    // 0x89d0a8: r16 = <int, (dynamic this) => void?>
    //     0x89d0a8: ldr             x16, [PP, #0x2eb0]  ; [pp+0x2eb0] TypeArguments: <int, (dynamic this) => void?>
    // 0x89d0ac: ldr             lr, [THR, #0xa8]  ; THR::empty_array
    // 0x89d0b0: stp             lr, x16, [SP]
    // 0x89d0b4: r0 = Map._fromLiteral()
    //     0x89d0b4: bl              #0x7efee0  ; [dart:core] Map::Map._fromLiteral
    // 0x89d0b8: ldur            x2, [fp, #-8]
    // 0x89d0bc: StoreField: r2->field_7 = r0
    //     0x89d0bc: stur            w0, [x2, #7]
    //     0x89d0c0: ldurb           w16, [x2, #-1]
    //     0x89d0c4: ldurb           w17, [x0, #-1]
    //     0x89d0c8: and             x16, x17, x16, lsr #2
    //     0x89d0cc: tst             x16, HEAP, lsr #32
    //     0x89d0d0: b.eq            #0x89d0d8
    //     0x89d0d4: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x89d0d8: r1 = <Layer>
    //     0x89d0d8: ldr             x1, [PP, #0x2eb8]  ; [pp+0x2eb8] TypeArguments: <Layer>
    // 0x89d0dc: r0 = LayerHandle()
    //     0x89d0dc: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x89d0e0: ldur            x1, [fp, #-8]
    // 0x89d0e4: StoreField: r1->field_13 = r0
    //     0x89d0e4: stur            w0, [x1, #0x13]
    //     0x89d0e8: ldurb           w16, [x1, #-1]
    //     0x89d0ec: ldurb           w17, [x0, #-1]
    //     0x89d0f0: and             x16, x17, x16, lsr #2
    //     0x89d0f4: tst             x16, HEAP, lsr #32
    //     0x89d0f8: b.eq            #0x89d100
    //     0x89d0fc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x89d100: r0 = Null
    //     0x89d100: mov             x0, NULL
    // 0x89d104: LeaveFrame
    //     0x89d104: mov             SP, fp
    //     0x89d108: ldp             fp, lr, [SP], #0x10
    // 0x89d10c: ret
    //     0x89d10c: ret             
    // 0x89d110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89d110: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89d114: b               #0x89d098
  }
  set _ engineLayer=(/* No info */) {
    // ** addr: 0xbecfac, size: 0x13c
    // 0xbecfac: EnterFrame
    //     0xbecfac: stp             fp, lr, [SP, #-0x10]!
    //     0xbecfb0: mov             fp, SP
    // 0xbecfb4: AllocStack(0x28)
    //     0xbecfb4: sub             SP, SP, #0x28
    // 0xbecfb8: SetupParameters(Layer this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */)
    //     0xbecfb8: mov             x0, x2
    //     0xbecfbc: stur            x2, [fp, #-0x20]
    //     0xbecfc0: mov             x2, x1
    //     0xbecfc4: stur            x1, [fp, #-0x18]
    // 0xbecfc8: CheckStackOverflow
    //     0xbecfc8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbecfcc: cmp             SP, x16
    //     0xbecfd0: b.ls            #0xbed0d8
    // 0xbecfd4: LoadField: r1 = r2->field_27
    //     0xbecfd4: ldur            w1, [x2, #0x27]
    // 0xbecfd8: DecompressPointer r1
    //     0xbecfd8: add             x1, x1, HEAP, lsl #32
    // 0xbecfdc: cmp             w1, NULL
    // 0xbecfe0: b.eq            #0xbed030
    // 0xbecfe4: LoadField: r3 = r1->field_7
    //     0xbecfe4: ldur            w3, [x1, #7]
    // 0xbecfe8: DecompressPointer r3
    //     0xbecfe8: add             x3, x3, HEAP, lsl #32
    // 0xbecfec: stur            x3, [fp, #-0x10]
    // 0xbecff0: LoadField: r1 = r3->field_7
    //     0xbecff0: ldur            w1, [x3, #7]
    // 0xbecff4: DecompressPointer r1
    //     0xbecff4: add             x1, x1, HEAP, lsl #32
    // 0xbecff8: cmp             w1, NULL
    // 0xbecffc: b.eq            #0xbed0e0
    // 0xbed000: LoadField: r4 = r1->field_7
    //     0xbed000: ldur            x4, [x1, #7]
    // 0xbed004: ldr             x1, [x4]
    // 0xbed008: cbz             x1, #0xbed0c8
    // 0xbed00c: mov             x4, x1
    // 0xbed010: stur            x4, [fp, #-8]
    // 0xbed014: r1 = <Never>
    //     0xbed014: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xbed018: r0 = Pointer()
    //     0xbed018: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xbed01c: mov             x1, x0
    // 0xbed020: ldur            x0, [fp, #-8]
    // 0xbed024: StoreField: r1->field_7 = r0
    //     0xbed024: stur            x0, [x1, #7]
    // 0xbed028: r0 = _dispose$Method$FfiNative()
    //     0xbed028: bl              #0xbed0e8  ; [dart:ui] _NativeEngineLayer::_dispose$Method$FfiNative
    // 0xbed02c: ldur            x2, [fp, #-0x18]
    // 0xbed030: ldur            x0, [fp, #-0x20]
    // 0xbed034: StoreField: r2->field_27 = r0
    //     0xbed034: stur            w0, [x2, #0x27]
    //     0xbed038: ldurb           w16, [x2, #-1]
    //     0xbed03c: ldurb           w17, [x0, #-1]
    //     0xbed040: and             x16, x17, x16, lsr #2
    //     0xbed044: tst             x16, HEAP, lsr #32
    //     0xbed048: b.eq            #0xbed050
    //     0xbed04c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xbed050: r0 = LoadClassIdInstr(r2)
    //     0xbed050: ldur            x0, [x2, #-1]
    //     0xbed054: ubfx            x0, x0, #0xc, #0x14
    // 0xbed058: mov             x1, x2
    // 0xbed05c: r0 = GDT[cid_x0 + 0x9044]()
    //     0xbed05c: mov             x17, #0x9044
    //     0xbed060: add             lr, x0, x17
    //     0xbed064: ldr             lr, [x21, lr, lsl #3]
    //     0xbed068: blr             lr
    // 0xbed06c: tbz             w0, #4, #0xbed0b8
    // 0xbed070: ldur            x2, [fp, #-0x18]
    // 0xbed074: LoadField: r1 = r2->field_1f
    //     0xbed074: ldur            w1, [x2, #0x1f]
    // 0xbed078: DecompressPointer r1
    //     0xbed078: add             x1, x1, HEAP, lsl #32
    // 0xbed07c: cmp             w1, NULL
    // 0xbed080: b.eq            #0xbed0b8
    // 0xbed084: r0 = LoadClassIdInstr(r1)
    //     0xbed084: ldur            x0, [x1, #-1]
    //     0xbed088: ubfx            x0, x0, #0xc, #0x14
    // 0xbed08c: r0 = GDT[cid_x0 + 0x9044]()
    //     0xbed08c: mov             x17, #0x9044
    //     0xbed090: add             lr, x0, x17
    //     0xbed094: ldr             lr, [x21, lr, lsl #3]
    //     0xbed098: blr             lr
    // 0xbed09c: tbz             w0, #4, #0xbed0b8
    // 0xbed0a0: ldur            x0, [fp, #-0x18]
    // 0xbed0a4: LoadField: r1 = r0->field_1f
    //     0xbed0a4: ldur            w1, [x0, #0x1f]
    // 0xbed0a8: DecompressPointer r1
    //     0xbed0a8: add             x1, x1, HEAP, lsl #32
    // 0xbed0ac: cmp             w1, NULL
    // 0xbed0b0: b.eq            #0xbed0e4
    // 0xbed0b4: r0 = markNeedsAddToScene()
    //     0xbed0b4: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xbed0b8: r0 = Null
    //     0xbed0b8: mov             x0, NULL
    // 0xbed0bc: LeaveFrame
    //     0xbed0bc: mov             SP, fp
    //     0xbed0c0: ldp             fp, lr, [SP], #0x10
    // 0xbed0c4: ret
    //     0xbed0c4: ret             
    // 0xbed0c8: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xbed0c8: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xbed0cc: str             x16, [SP]
    // 0xbed0d0: r0 = _throwNew()
    //     0xbed0d0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xbed0d4: brk             #0
    // 0xbed0d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbed0d8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbed0dc: b               #0xbecfd4
    // 0xbed0e0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbed0e0: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xbed0e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbed0e4: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0xc16e3c, size: 0x44
    // 0xc16e3c: EnterFrame
    //     0xc16e3c: stp             fp, lr, [SP, #-0x10]!
    //     0xc16e40: mov             fp, SP
    // 0xc16e44: mov             x2, x1
    // 0xc16e48: CheckStackOverflow
    //     0xc16e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16e4c: cmp             SP, x16
    //     0xc16e50: b.ls            #0xc16e78
    // 0xc16e54: LoadField: r1 = r2->field_1f
    //     0xc16e54: ldur            w1, [x2, #0x1f]
    // 0xc16e58: DecompressPointer r1
    //     0xc16e58: add             x1, x1, HEAP, lsl #32
    // 0xc16e5c: cmp             w1, NULL
    // 0xc16e60: b.eq            #0xc16e68
    // 0xc16e64: r0 = _removeChild()
    //     0xc16e64: bl              #0xc16e80  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::_removeChild
    // 0xc16e68: r0 = Null
    //     0xc16e68: mov             x0, NULL
    // 0xc16e6c: LeaveFrame
    //     0xc16e6c: mov             SP, fp
    //     0xc16e70: ldp             fp, lr, [SP], #0x10
    // 0xc16e74: ret
    //     0xc16e74: ret             
    // 0xc16e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16e78: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16e7c: b               #0xc16e54
  }
  _ addCompositionCallback(/* No info */) {
    // ** addr: 0xc1d9e4, size: 0x108
    // 0xc1d9e4: EnterFrame
    //     0xc1d9e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d9e8: mov             fp, SP
    // 0xc1d9ec: AllocStack(0x20)
    //     0xc1d9ec: sub             SP, SP, #0x20
    // 0xc1d9f0: SetupParameters(Layer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xc1d9f0: stur            x1, [fp, #-8]
    //     0xc1d9f4: stur            x2, [fp, #-0x10]
    // 0xc1d9f8: CheckStackOverflow
    //     0xc1d9f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d9fc: cmp             SP, x16
    //     0xc1da00: b.ls            #0xc1dae4
    // 0xc1da04: r1 = 3
    //     0xc1da04: mov             x1, #3
    // 0xc1da08: r0 = AllocateContext()
    //     0xc1da08: bl              #0x13de838  ; AllocateContextStub
    // 0xc1da0c: mov             x3, x0
    // 0xc1da10: ldur            x0, [fp, #-8]
    // 0xc1da14: stur            x3, [fp, #-0x18]
    // 0xc1da18: StoreField: r3->field_f = r0
    //     0xc1da18: stur            w0, [x3, #0xf]
    // 0xc1da1c: ldur            x1, [fp, #-0x10]
    // 0xc1da20: StoreField: r3->field_13 = r1
    //     0xc1da20: stur            w1, [x3, #0x13]
    // 0xc1da24: mov             x1, x0
    // 0xc1da28: r2 = 1
    //     0xc1da28: mov             x2, #1
    // 0xc1da2c: r0 = _updateSubtreeCompositionObserverCount()
    //     0xc1da2c: bl              #0x89af18  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0xc1da30: r0 = LoadStaticField(0x9d8)
    //     0xc1da30: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xc1da34: ldr             x0, [x0, #0x13b0]
    // 0xc1da38: r1 = LoadInt32Instr(r0)
    //     0xc1da38: sbfx            x1, x0, #1, #0x1f
    //     0xc1da3c: tbz             w0, #0, #0xc1da44
    //     0xc1da40: ldur            x1, [x0, #7]
    // 0xc1da44: add             x2, x1, #1
    // 0xc1da48: r0 = BoxInt64Instr(r2)
    //     0xc1da48: sbfiz           x0, x2, #1, #0x1f
    //     0xc1da4c: cmp             x2, x0, asr #1
    //     0xc1da50: b.eq            #0xc1da5c
    //     0xc1da54: bl              #0x13dfbb4  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc1da58: stur            x2, [x0, #7]
    // 0xc1da5c: mov             x2, x0
    // 0xc1da60: mov             x3, x0
    // 0xc1da64: stur            x3, [fp, #-0x20]
    // 0xc1da68: StoreStaticField(0x9d8, r2)
    //     0xc1da68: ldr             x0, [THR, #0x78]  ; THR::field_table_values
    //     0xc1da6c: str             x2, [x0, #0x13b0]
    // 0xc1da70: mov             x0, x3
    // 0xc1da74: ldur            x4, [fp, #-0x18]
    // 0xc1da78: ArrayStore: r4[0] = r0  ; List_4
    //     0xc1da78: stur            w0, [x4, #0x17]
    //     0xc1da7c: tbz             w0, #0, #0xc1da98
    //     0xc1da80: ldurb           w16, [x4, #-1]
    //     0xc1da84: ldurb           w17, [x0, #-1]
    //     0xc1da88: and             x16, x17, x16, lsr #2
    //     0xc1da8c: tst             x16, HEAP, lsr #32
    //     0xc1da90: b.eq            #0xc1da98
    //     0xc1da94: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xc1da98: ldur            x0, [fp, #-8]
    // 0xc1da9c: LoadField: r5 = r0->field_7
    //     0xc1da9c: ldur            w5, [x0, #7]
    // 0xc1daa0: DecompressPointer r5
    //     0xc1daa0: add             x5, x5, HEAP, lsl #32
    // 0xc1daa4: mov             x2, x4
    // 0xc1daa8: stur            x5, [fp, #-0x10]
    // 0xc1daac: r1 = Function '<anonymous closure>':.
    //     0xc1daac: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccc50] AnonymousClosure: (0xc1db5c), in [package:flutter/src/rendering/layer.dart] Layer::addCompositionCallback (0xc1d9e4)
    //     0xc1dab0: ldr             x1, [x1, #0xc50]
    // 0xc1dab4: r0 = AllocateClosure()
    //     0xc1dab4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1dab8: ldur            x1, [fp, #-0x10]
    // 0xc1dabc: ldur            x2, [fp, #-0x20]
    // 0xc1dac0: mov             x3, x0
    // 0xc1dac4: r0 = []=()
    //     0xc1dac4: bl              #0x13cd868  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xc1dac8: ldur            x2, [fp, #-0x18]
    // 0xc1dacc: r1 = Function '<anonymous closure>':.
    //     0xc1dacc: add             x1, PP, #0xcc, lsl #12  ; [pp+0xccc58] AnonymousClosure: (0xc1daec), in [package:flutter/src/rendering/layer.dart] Layer::addCompositionCallback (0xc1d9e4)
    //     0xc1dad0: ldr             x1, [x1, #0xc58]
    // 0xc1dad4: r0 = AllocateClosure()
    //     0xc1dad4: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc1dad8: LeaveFrame
    //     0xc1dad8: mov             SP, fp
    //     0xc1dadc: ldp             fp, lr, [SP], #0x10
    // 0xc1dae0: ret
    //     0xc1dae0: ret             
    // 0xc1dae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1dae4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1dae8: b               #0xc1da04
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc1daec, size: 0x70
    // 0xc1daec: EnterFrame
    //     0xc1daec: stp             fp, lr, [SP, #-0x10]!
    //     0xc1daf0: mov             fp, SP
    // 0xc1daf4: AllocStack(0x8)
    //     0xc1daf4: sub             SP, SP, #8
    // 0xc1daf8: SetupParameters([dynamic _ /* r0 */])
    //     0xc1daf8: ldr             x0, [fp, #0x10]
    //     0xc1dafc: ldur            w3, [x0, #0x17]
    //     0xc1db00: add             x3, x3, HEAP, lsl #32
    //     0xc1db04: stur            x3, [fp, #-8]
    // 0xc1db08: CheckStackOverflow
    //     0xc1db08: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1db0c: cmp             SP, x16
    //     0xc1db10: b.ls            #0xc1db54
    // 0xc1db14: LoadField: r0 = r3->field_f
    //     0xc1db14: ldur            w0, [x3, #0xf]
    // 0xc1db18: DecompressPointer r0
    //     0xc1db18: add             x0, x0, HEAP, lsl #32
    // 0xc1db1c: LoadField: r1 = r0->field_7
    //     0xc1db1c: ldur            w1, [x0, #7]
    // 0xc1db20: DecompressPointer r1
    //     0xc1db20: add             x1, x1, HEAP, lsl #32
    // 0xc1db24: ArrayLoad: r2 = r3[0]  ; List_4
    //     0xc1db24: ldur            w2, [x3, #0x17]
    // 0xc1db28: DecompressPointer r2
    //     0xc1db28: add             x2, x2, HEAP, lsl #32
    // 0xc1db2c: r0 = remove()
    //     0xc1db2c: bl              #0xbad240  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc1db30: ldur            x0, [fp, #-8]
    // 0xc1db34: LoadField: r1 = r0->field_f
    //     0xc1db34: ldur            w1, [x0, #0xf]
    // 0xc1db38: DecompressPointer r1
    //     0xc1db38: add             x1, x1, HEAP, lsl #32
    // 0xc1db3c: r2 = -1
    //     0xc1db3c: mov             x2, #-1
    // 0xc1db40: r0 = _updateSubtreeCompositionObserverCount()
    //     0xc1db40: bl              #0x89af18  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0xc1db44: r0 = Null
    //     0xc1db44: mov             x0, NULL
    // 0xc1db48: LeaveFrame
    //     0xc1db48: mov             SP, fp
    //     0xc1db4c: ldp             fp, lr, [SP], #0x10
    // 0xc1db50: ret
    //     0xc1db50: ret             
    // 0xc1db54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1db54: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1db58: b               #0xc1db14
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc1db5c, size: 0x54
    // 0xc1db5c: EnterFrame
    //     0xc1db5c: stp             fp, lr, [SP, #-0x10]!
    //     0xc1db60: mov             fp, SP
    // 0xc1db64: ldr             x0, [fp, #0x10]
    // 0xc1db68: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc1db68: ldur            w1, [x0, #0x17]
    // 0xc1db6c: DecompressPointer r1
    //     0xc1db6c: add             x1, x1, HEAP, lsl #32
    // 0xc1db70: CheckStackOverflow
    //     0xc1db70: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1db74: cmp             SP, x16
    //     0xc1db78: b.ls            #0xc1dba8
    // 0xc1db7c: LoadField: r0 = r1->field_13
    //     0xc1db7c: ldur            w0, [x1, #0x13]
    // 0xc1db80: DecompressPointer r0
    //     0xc1db80: add             x0, x0, HEAP, lsl #32
    // 0xc1db84: LoadField: r2 = r1->field_f
    //     0xc1db84: ldur            w2, [x1, #0xf]
    // 0xc1db88: DecompressPointer r2
    //     0xc1db88: add             x2, x2, HEAP, lsl #32
    // 0xc1db8c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc1db8c: ldur            w1, [x0, #0x17]
    // 0xc1db90: DecompressPointer r1
    //     0xc1db90: add             x1, x1, HEAP, lsl #32
    // 0xc1db94: r0 = _compositeCallback()
    //     0xc1db94: bl              #0xc1dbec  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::_compositeCallback
    // 0xc1db98: r0 = Null
    //     0xc1db98: mov             x0, NULL
    // 0xc1db9c: LeaveFrame
    //     0xc1db9c: mov             SP, fp
    //     0xc1dba0: ldp             fp, lr, [SP], #0x10
    // 0xc1dba4: ret
    //     0xc1dba4: ret             
    // 0xc1dba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1dba8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1dbac: b               #0xc1db7c
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10fc2a8, size: 0xac
    // 0x10fc2a8: EnterFrame
    //     0x10fc2a8: stp             fp, lr, [SP, #-0x10]!
    //     0x10fc2ac: mov             fp, SP
    // 0x10fc2b0: AllocStack(0x20)
    //     0x10fc2b0: sub             SP, SP, #0x20
    // 0x10fc2b4: SetupParameters(Layer this /* r1 => r0, fp-0x18 */)
    //     0x10fc2b4: mov             x0, x1
    //     0x10fc2b8: stur            x1, [fp, #-0x18]
    // 0x10fc2bc: CheckStackOverflow
    //     0x10fc2bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10fc2c0: cmp             SP, x16
    //     0x10fc2c4: b.ls            #0x10fc348
    // 0x10fc2c8: LoadField: r1 = r0->field_27
    //     0x10fc2c8: ldur            w1, [x0, #0x27]
    // 0x10fc2cc: DecompressPointer r1
    //     0x10fc2cc: add             x1, x1, HEAP, lsl #32
    // 0x10fc2d0: cmp             w1, NULL
    // 0x10fc2d4: b.eq            #0x10fc324
    // 0x10fc2d8: LoadField: r2 = r1->field_7
    //     0x10fc2d8: ldur            w2, [x1, #7]
    // 0x10fc2dc: DecompressPointer r2
    //     0x10fc2dc: add             x2, x2, HEAP, lsl #32
    // 0x10fc2e0: stur            x2, [fp, #-0x10]
    // 0x10fc2e4: LoadField: r1 = r2->field_7
    //     0x10fc2e4: ldur            w1, [x2, #7]
    // 0x10fc2e8: DecompressPointer r1
    //     0x10fc2e8: add             x1, x1, HEAP, lsl #32
    // 0x10fc2ec: cmp             w1, NULL
    // 0x10fc2f0: b.eq            #0x10fc350
    // 0x10fc2f4: LoadField: r3 = r1->field_7
    //     0x10fc2f4: ldur            x3, [x1, #7]
    // 0x10fc2f8: ldr             x1, [x3]
    // 0x10fc2fc: cbz             x1, #0x10fc338
    // 0x10fc300: mov             x3, x1
    // 0x10fc304: stur            x3, [fp, #-8]
    // 0x10fc308: r1 = <Never>
    //     0x10fc308: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x10fc30c: r0 = Pointer()
    //     0x10fc30c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x10fc310: mov             x1, x0
    // 0x10fc314: ldur            x0, [fp, #-8]
    // 0x10fc318: StoreField: r1->field_7 = r0
    //     0x10fc318: stur            x0, [x1, #7]
    // 0x10fc31c: r0 = _dispose$Method$FfiNative()
    //     0x10fc31c: bl              #0xbed0e8  ; [dart:ui] _NativeEngineLayer::_dispose$Method$FfiNative
    // 0x10fc320: ldur            x0, [fp, #-0x18]
    // 0x10fc324: StoreField: r0->field_27 = rNULL
    //     0x10fc324: stur            NULL, [x0, #0x27]
    // 0x10fc328: r0 = Null
    //     0x10fc328: mov             x0, NULL
    // 0x10fc32c: LeaveFrame
    //     0x10fc32c: mov             SP, fp
    //     0x10fc330: ldp             fp, lr, [SP], #0x10
    // 0x10fc334: ret
    //     0x10fc334: ret             
    // 0x10fc338: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x10fc338: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x10fc33c: str             x16, [SP]
    // 0x10fc340: r0 = _throwNew()
    //     0x10fc340: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x10fc344: brk             #0
    // 0x10fc348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10fc348: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10fc34c: b               #0x10fc2c8
    // 0x10fc350: r0 = NullErrorSharedWithoutFPURegs()
    //     0x10fc350: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _fireCompositionCallbacks(/* No info */) {
    // ** addr: 0x11040bc, size: 0x1a0
    // 0x11040bc: EnterFrame
    //     0x11040bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11040c0: mov             fp, SP
    // 0x11040c4: AllocStack(0x30)
    //     0x11040c4: sub             SP, SP, #0x30
    // 0x11040c8: CheckStackOverflow
    //     0x11040c8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11040cc: cmp             SP, x16
    //     0x11040d0: b.ls            #0x110424c
    // 0x11040d4: LoadField: r0 = r1->field_7
    //     0x11040d4: ldur            w0, [x1, #7]
    // 0x11040d8: DecompressPointer r0
    //     0x11040d8: add             x0, x0, HEAP, lsl #32
    // 0x11040dc: stur            x0, [fp, #-8]
    // 0x11040e0: LoadField: r1 = r0->field_13
    //     0x11040e0: ldur            w1, [x0, #0x13]
    // 0x11040e4: r2 = LoadInt32Instr(r1)
    //     0x11040e4: sbfx            x2, x1, #1, #0x1f
    // 0x11040e8: asr             x1, x2, #1
    // 0x11040ec: ArrayLoad: r2 = r0[0]  ; List_4
    //     0x11040ec: ldur            w2, [x0, #0x17]
    // 0x11040f0: r3 = LoadInt32Instr(r2)
    //     0x11040f0: sbfx            x3, x2, #1, #0x1f
    // 0x11040f4: sub             x2, x1, x3
    // 0x11040f8: cbnz            x2, #0x110410c
    // 0x11040fc: r0 = Null
    //     0x11040fc: mov             x0, NULL
    // 0x1104100: LeaveFrame
    //     0x1104100: mov             SP, fp
    //     0x1104104: ldp             fp, lr, [SP], #0x10
    // 0x1104108: ret
    //     0x1104108: ret             
    // 0x110410c: LoadField: r2 = r0->field_7
    //     0x110410c: ldur            w2, [x0, #7]
    // 0x1104110: DecompressPointer r2
    //     0x1104110: add             x2, x2, HEAP, lsl #32
    // 0x1104114: r1 = Null
    //     0x1104114: mov             x1, NULL
    // 0x1104118: r3 = <X1>
    //     0x1104118: ldr             x3, [PP, #0x2cb0]  ; [pp+0x2cb0] TypeArguments: <X1>
    // 0x110411c: r0 = Null
    //     0x110411c: mov             x0, NULL
    // 0x1104120: cmp             x2, x0
    // 0x1104124: b.eq            #0x1104134
    // 0x1104128: r30 = InstantiateTypeArgumentsStub
    //     0x1104128: ldr             lr, [PP, #0x1c0]  ; [pp+0x1c0] Stub: InstantiateTypeArguments (0x7c0fc4)
    // 0x110412c: LoadField: r30 = r30->field_7
    //     0x110412c: ldur            lr, [lr, #7]
    // 0x1104130: blr             lr
    // 0x1104134: mov             x1, x0
    // 0x1104138: r0 = _CompactValuesIterable()
    //     0x1104138: bl              #0x7f3fb4  ; Allocate_CompactValuesIterableStub -> _CompactValuesIterable<X0> (size=0x10)
    // 0x110413c: mov             x1, x0
    // 0x1104140: ldur            x0, [fp, #-8]
    // 0x1104144: StoreField: r1->field_b = r0
    //     0x1104144: stur            w0, [x1, #0xb]
    // 0x1104148: mov             x2, x1
    // 0x110414c: r1 = <(dynamic this) => void?>
    //     0x110414c: ldr             x1, [PP, #0x17d0]  ; [pp+0x17d0] TypeArguments: <(dynamic this) => void?>
    // 0x1104150: r0 = _GrowableList._ofEfficientLengthIterable()
    //     0x1104150: bl              #0x7d732c  ; [dart:core] _GrowableList::_GrowableList._ofEfficientLengthIterable
    // 0x1104154: mov             x3, x0
    // 0x1104158: stur            x3, [fp, #-0x28]
    // 0x110415c: LoadField: r4 = r3->field_7
    //     0x110415c: ldur            w4, [x3, #7]
    // 0x1104160: DecompressPointer r4
    //     0x1104160: add             x4, x4, HEAP, lsl #32
    // 0x1104164: stur            x4, [fp, #-0x20]
    // 0x1104168: LoadField: r0 = r3->field_b
    //     0x1104168: ldur            w0, [x3, #0xb]
    // 0x110416c: r5 = LoadInt32Instr(r0)
    //     0x110416c: sbfx            x5, x0, #1, #0x1f
    // 0x1104170: stur            x5, [fp, #-0x18]
    // 0x1104174: r0 = 0
    //     0x1104174: mov             x0, #0
    // 0x1104178: CheckStackOverflow
    //     0x1104178: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110417c: cmp             SP, x16
    //     0x1104180: b.ls            #0x1104254
    // 0x1104184: LoadField: r1 = r3->field_b
    //     0x1104184: ldur            w1, [x3, #0xb]
    // 0x1104188: r2 = LoadInt32Instr(r1)
    //     0x1104188: sbfx            x2, x1, #1, #0x1f
    // 0x110418c: cmp             x5, x2
    // 0x1104190: b.ne            #0x110422c
    // 0x1104194: cmp             x0, x2
    // 0x1104198: b.ge            #0x110421c
    // 0x110419c: LoadField: r1 = r3->field_f
    //     0x110419c: ldur            w1, [x3, #0xf]
    // 0x11041a0: DecompressPointer r1
    //     0x11041a0: add             x1, x1, HEAP, lsl #32
    // 0x11041a4: ArrayLoad: r6 = r1[r0]  ; Unknown_4
    //     0x11041a4: add             x16, x1, x0, lsl #2
    //     0x11041a8: ldur            w6, [x16, #0xf]
    // 0x11041ac: DecompressPointer r6
    //     0x11041ac: add             x6, x6, HEAP, lsl #32
    // 0x11041b0: stur            x6, [fp, #-8]
    // 0x11041b4: add             x7, x0, #1
    // 0x11041b8: stur            x7, [fp, #-0x10]
    // 0x11041bc: cmp             w6, NULL
    // 0x11041c0: b.ne            #0x11041f0
    // 0x11041c4: mov             x0, x6
    // 0x11041c8: mov             x2, x4
    // 0x11041cc: r1 = Null
    //     0x11041cc: mov             x1, NULL
    // 0x11041d0: cmp             w2, NULL
    // 0x11041d4: b.eq            #0x11041f0
    // 0x11041d8: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x11041d8: ldur            w4, [x2, #0x17]
    // 0x11041dc: DecompressPointer r4
    //     0x11041dc: add             x4, x4, HEAP, lsl #32
    // 0x11041e0: r8 = X0
    //     0x11041e0: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x11041e4: LoadField: r9 = r4->field_7
    //     0x11041e4: ldur            x9, [x4, #7]
    // 0x11041e8: r3 = Null
    //     0x11041e8: ldr             x3, [PP, #0x2cb8]  ; [pp+0x2cb8] Null
    // 0x11041ec: blr             x9
    // 0x11041f0: ldur            x16, [fp, #-8]
    // 0x11041f4: str             x16, [SP]
    // 0x11041f8: ldur            x0, [fp, #-8]
    // 0x11041fc: ClosureCall
    //     0x11041fc: ldr             x4, [PP, #0x290]  ; [pp+0x290] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x1104200: ldur            x2, [x0, #0x1f]
    //     0x1104204: blr             x2
    // 0x1104208: ldur            x0, [fp, #-0x10]
    // 0x110420c: ldur            x4, [fp, #-0x20]
    // 0x1104210: ldur            x3, [fp, #-0x28]
    // 0x1104214: ldur            x5, [fp, #-0x18]
    // 0x1104218: b               #0x1104178
    // 0x110421c: r0 = Null
    //     0x110421c: mov             x0, NULL
    // 0x1104220: LeaveFrame
    //     0x1104220: mov             SP, fp
    //     0x1104224: ldp             fp, lr, [SP], #0x10
    // 0x1104228: ret
    //     0x1104228: ret             
    // 0x110422c: mov             x0, x3
    // 0x1104230: r0 = ConcurrentModificationError()
    //     0x1104230: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x1104234: mov             x1, x0
    // 0x1104238: ldur            x0, [fp, #-0x28]
    // 0x110423c: StoreField: r1->field_b = r0
    //     0x110423c: stur            w0, [x1, #0xb]
    // 0x1104240: mov             x0, x1
    // 0x1104244: r0 = Throw()
    //     0x1104244: bl              #0x13ddb2c  ; ThrowStub
    // 0x1104248: brk             #0
    // 0x110424c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110424c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1104250: b               #0x11040d4
    // 0x1104254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1104254: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1104258: b               #0x1104184
  }
  _ detach(/* No info */) {
    // ** addr: 0x110a6a4, size: 0xc
    // 0x110a6a4: StoreField: r1->field_2b = rNULL
    //     0x110a6a4: stur            NULL, [x1, #0x2b]
    // 0x110a6a8: r0 = Null
    //     0x110a6a8: mov             x0, NULL
    // 0x110a6ac: ret
    //     0x110a6ac: ret             
  }
  _ attach(/* No info */) {
    // ** addr: 0x1146de0, size: 0x34
    // 0x1146de0: mov             x0, x2
    // 0x1146de4: StoreField: r1->field_2b = r0
    //     0x1146de4: stur            w0, [x1, #0x2b]
    //     0x1146de8: tbz             w0, #0, #0x1146e0c
    //     0x1146dec: ldurb           w16, [x1, #-1]
    //     0x1146df0: ldurb           w17, [x0, #-1]
    //     0x1146df4: and             x16, x17, x16, lsr #2
    //     0x1146df8: tst             x16, HEAP, lsr #32
    //     0x1146dfc: b.eq            #0x1146e0c
    //     0x1146e00: str             lr, [SP, #-8]!
    //     0x1146e04: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    //     0x1146e08: ldr             lr, [SP], #8
    // 0x1146e0c: r0 = Null
    //     0x1146e0c: mov             x0, NULL
    // 0x1146e10: ret
    //     0x1146e10: ret             
  }
  _ updateSubtreeNeedsAddToScene(/* No info */) {
    // ** addr: 0x1159e4c, size: 0x78
    // 0x1159e4c: EnterFrame
    //     0x1159e4c: stp             fp, lr, [SP, #-0x10]!
    //     0x1159e50: mov             fp, SP
    // 0x1159e54: AllocStack(0x8)
    //     0x1159e54: sub             SP, SP, #8
    // 0x1159e58: SetupParameters(Layer this /* r1 => r2, fp-0x8 */)
    //     0x1159e58: mov             x2, x1
    //     0x1159e5c: stur            x1, [fp, #-8]
    // 0x1159e60: CheckStackOverflow
    //     0x1159e60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1159e64: cmp             SP, x16
    //     0x1159e68: b.ls            #0x1159ebc
    // 0x1159e6c: LoadField: r0 = r2->field_23
    //     0x1159e6c: ldur            w0, [x2, #0x23]
    // 0x1159e70: DecompressPointer r0
    //     0x1159e70: add             x0, x0, HEAP, lsl #32
    // 0x1159e74: tbnz            w0, #4, #0x1159e84
    // 0x1159e78: mov             x1, x2
    // 0x1159e7c: r2 = true
    //     0x1159e7c: add             x2, NULL, #0x20  ; true
    // 0x1159e80: b               #0x1159ea8
    // 0x1159e84: r0 = LoadClassIdInstr(r2)
    //     0x1159e84: ldur            x0, [x2, #-1]
    //     0x1159e88: ubfx            x0, x0, #0xc, #0x14
    // 0x1159e8c: mov             x1, x2
    // 0x1159e90: r0 = GDT[cid_x0 + 0x9044]()
    //     0x1159e90: mov             x17, #0x9044
    //     0x1159e94: add             lr, x0, x17
    //     0x1159e98: ldr             lr, [x21, lr, lsl #3]
    //     0x1159e9c: blr             lr
    // 0x1159ea0: mov             x2, x0
    // 0x1159ea4: ldur            x1, [fp, #-8]
    // 0x1159ea8: StoreField: r1->field_23 = r2
    //     0x1159ea8: stur            w2, [x1, #0x23]
    // 0x1159eac: r0 = Null
    //     0x1159eac: mov             x0, NULL
    // 0x1159eb0: LeaveFrame
    //     0x1159eb0: mov             SP, fp
    //     0x1159eb4: ldp             fp, lr, [SP], #0x10
    // 0x1159eb8: ret
    //     0x1159eb8: ret             
    // 0x1159ebc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1159ebc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1159ec0: b               #0x1159e6c
  }
}

// class id: 4649, size: 0x48, field offset: 0x40
abstract class ContainerLayer extends Layer {

  _ buildScene(/* No info */) {
    // ** addr: 0x899940, size: 0x94
    // 0x899940: EnterFrame
    //     0x899940: stp             fp, lr, [SP, #-0x10]!
    //     0x899944: mov             fp, SP
    // 0x899948: AllocStack(0x10)
    //     0x899948: sub             SP, SP, #0x10
    // 0x89994c: SetupParameters(ContainerLayer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x89994c: mov             x0, x1
    //     0x899950: stur            x1, [fp, #-8]
    //     0x899954: stur            x2, [fp, #-0x10]
    // 0x899958: CheckStackOverflow
    //     0x899958: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89995c: cmp             SP, x16
    //     0x899960: b.ls            #0x8999cc
    // 0x899964: mov             x1, x0
    // 0x899968: r0 = updateSubtreeNeedsAddToScene()
    //     0x899968: bl              #0x1159ec4  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::updateSubtreeNeedsAddToScene
    // 0x89996c: ldur            x3, [fp, #-8]
    // 0x899970: r0 = LoadClassIdInstr(r3)
    //     0x899970: ldur            x0, [x3, #-1]
    //     0x899974: ubfx            x0, x0, #0xc, #0x14
    // 0x899978: mov             x1, x3
    // 0x89997c: ldur            x2, [fp, #-0x10]
    // 0x899980: r0 = GDT[cid_x0 + 0x391b]()
    //     0x899980: mov             x17, #0x391b
    //     0x899984: add             lr, x0, x17
    //     0x899988: ldr             lr, [x21, lr, lsl #3]
    //     0x89998c: blr             lr
    // 0x899990: ldur            x0, [fp, #-8]
    // 0x899994: LoadField: r1 = r0->field_b
    //     0x899994: ldur            x1, [x0, #0xb]
    // 0x899998: cmp             x1, #0
    // 0x89999c: b.le            #0x8999ac
    // 0x8999a0: mov             x1, x0
    // 0x8999a4: r2 = true
    //     0x8999a4: add             x2, NULL, #0x20  ; true
    // 0x8999a8: r0 = _fireCompositionCallbacks()
    //     0x8999a8: bl              #0x110425c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::_fireCompositionCallbacks
    // 0x8999ac: ldur            x0, [fp, #-8]
    // 0x8999b0: r1 = false
    //     0x8999b0: add             x1, NULL, #0x30  ; false
    // 0x8999b4: StoreField: r0->field_23 = r1
    //     0x8999b4: stur            w1, [x0, #0x23]
    // 0x8999b8: ldur            x1, [fp, #-0x10]
    // 0x8999bc: r0 = build()
    //     0x8999bc: bl              #0x8999fc  ; [dart:ui] _NativeSceneBuilder::build
    // 0x8999c0: LeaveFrame
    //     0x8999c0: mov             SP, fp
    //     0x8999c4: ldp             fp, lr, [SP], #0x10
    // 0x8999c8: ret
    //     0x8999c8: ret             
    // 0x8999cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8999cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8999d0: b               #0x899964
  }
  _ removeAllChildren(/* No info */) {
    // ** addr: 0x89ad4c, size: 0xc8
    // 0x89ad4c: EnterFrame
    //     0x89ad4c: stp             fp, lr, [SP, #-0x10]!
    //     0x89ad50: mov             fp, SP
    // 0x89ad54: AllocStack(0x20)
    //     0x89ad54: sub             SP, SP, #0x20
    // 0x89ad58: SetupParameters(ContainerLayer this /* r1 => r0, fp-0x18 */)
    //     0x89ad58: mov             x0, x1
    //     0x89ad5c: stur            x1, [fp, #-0x18]
    // 0x89ad60: CheckStackOverflow
    //     0x89ad60: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89ad64: cmp             SP, x16
    //     0x89ad68: b.ls            #0x89ae04
    // 0x89ad6c: LoadField: r1 = r0->field_3f
    //     0x89ad6c: ldur            w1, [x0, #0x3f]
    // 0x89ad70: DecompressPointer r1
    //     0x89ad70: add             x1, x1, HEAP, lsl #32
    // 0x89ad74: mov             x3, x1
    // 0x89ad78: stur            x3, [fp, #-0x10]
    // 0x89ad7c: CheckStackOverflow
    //     0x89ad7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89ad80: cmp             SP, x16
    //     0x89ad84: b.ls            #0x89ae0c
    // 0x89ad88: cmp             w3, NULL
    // 0x89ad8c: b.eq            #0x89ade8
    // 0x89ad90: LoadField: r4 = r3->field_37
    //     0x89ad90: ldur            w4, [x3, #0x37]
    // 0x89ad94: DecompressPointer r4
    //     0x89ad94: add             x4, x4, HEAP, lsl #32
    // 0x89ad98: stur            x4, [fp, #-8]
    // 0x89ad9c: StoreField: r3->field_3b = rNULL
    //     0x89ad9c: stur            NULL, [x3, #0x3b]
    // 0x89ada0: StoreField: r3->field_37 = rNULL
    //     0x89ada0: stur            NULL, [x3, #0x37]
    // 0x89ada4: mov             x1, x0
    // 0x89ada8: mov             x2, x3
    // 0x89adac: r0 = _dropChild()
    //     0x89adac: bl              #0x89ae68  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::_dropChild
    // 0x89adb0: ldur            x0, [fp, #-0x10]
    // 0x89adb4: LoadField: r2 = r0->field_13
    //     0x89adb4: ldur            w2, [x0, #0x13]
    // 0x89adb8: DecompressPointer r2
    //     0x89adb8: add             x2, x2, HEAP, lsl #32
    // 0x89adbc: stur            x2, [fp, #-0x20]
    // 0x89adc0: LoadField: r1 = r2->field_b
    //     0x89adc0: ldur            w1, [x2, #0xb]
    // 0x89adc4: DecompressPointer r1
    //     0x89adc4: add             x1, x1, HEAP, lsl #32
    // 0x89adc8: cmp             w1, NULL
    // 0x89adcc: b.eq            #0x89addc
    // 0x89add0: r0 = _unref()
    //     0x89add0: bl              #0x89ae14  ; [package:flutter/src/rendering/layer.dart] Layer::_unref
    // 0x89add4: ldur            x1, [fp, #-0x20]
    // 0x89add8: StoreField: r1->field_b = rNULL
    //     0x89add8: stur            NULL, [x1, #0xb]
    // 0x89addc: ldur            x3, [fp, #-8]
    // 0x89ade0: ldur            x0, [fp, #-0x18]
    // 0x89ade4: b               #0x89ad78
    // 0x89ade8: mov             x1, x0
    // 0x89adec: StoreField: r1->field_3f = rNULL
    //     0x89adec: stur            NULL, [x1, #0x3f]
    // 0x89adf0: StoreField: r1->field_43 = rNULL
    //     0x89adf0: stur            NULL, [x1, #0x43]
    // 0x89adf4: r0 = Null
    //     0x89adf4: mov             x0, NULL
    // 0x89adf8: LeaveFrame
    //     0x89adf8: mov             SP, fp
    //     0x89adfc: ldp             fp, lr, [SP], #0x10
    // 0x89ae00: ret
    //     0x89ae00: ret             
    // 0x89ae04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89ae04: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89ae08: b               #0x89ad6c
    // 0x89ae0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89ae0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89ae10: b               #0x89ad88
  }
  _ _dropChild(/* No info */) {
    // ** addr: 0x89ae68, size: 0xb0
    // 0x89ae68: EnterFrame
    //     0x89ae68: stp             fp, lr, [SP, #-0x10]!
    //     0x89ae6c: mov             fp, SP
    // 0x89ae70: AllocStack(0x10)
    //     0x89ae70: sub             SP, SP, #0x10
    // 0x89ae74: SetupParameters(ContainerLayer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x89ae74: mov             x3, x1
    //     0x89ae78: stur            x1, [fp, #-8]
    //     0x89ae7c: stur            x2, [fp, #-0x10]
    // 0x89ae80: CheckStackOverflow
    //     0x89ae80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89ae84: cmp             SP, x16
    //     0x89ae88: b.ls            #0x89af10
    // 0x89ae8c: r0 = LoadClassIdInstr(r3)
    //     0x89ae8c: ldur            x0, [x3, #-1]
    //     0x89ae90: ubfx            x0, x0, #0xc, #0x14
    // 0x89ae94: mov             x1, x3
    // 0x89ae98: r0 = GDT[cid_x0 + 0x9044]()
    //     0x89ae98: mov             x17, #0x9044
    //     0x89ae9c: add             lr, x0, x17
    //     0x89aea0: ldr             lr, [x21, lr, lsl #3]
    //     0x89aea4: blr             lr
    // 0x89aea8: tbz             w0, #4, #0x89aeb4
    // 0x89aeac: ldur            x1, [fp, #-8]
    // 0x89aeb0: r0 = markNeedsAddToScene()
    //     0x89aeb0: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x89aeb4: ldur            x0, [fp, #-0x10]
    // 0x89aeb8: LoadField: r1 = r0->field_b
    //     0x89aeb8: ldur            x1, [x0, #0xb]
    // 0x89aebc: cbz             x1, #0x89aecc
    // 0x89aec0: neg             x2, x1
    // 0x89aec4: ldur            x1, [fp, #-8]
    // 0x89aec8: r0 = _updateSubtreeCompositionObserverCount()
    //     0x89aec8: bl              #0x89af18  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0x89aecc: ldur            x0, [fp, #-8]
    // 0x89aed0: ldur            x1, [fp, #-0x10]
    // 0x89aed4: StoreField: r1->field_1f = rNULL
    //     0x89aed4: stur            NULL, [x1, #0x1f]
    // 0x89aed8: LoadField: r2 = r0->field_2b
    //     0x89aed8: ldur            w2, [x0, #0x2b]
    // 0x89aedc: DecompressPointer r2
    //     0x89aedc: add             x2, x2, HEAP, lsl #32
    // 0x89aee0: cmp             w2, NULL
    // 0x89aee4: b.eq            #0x89af00
    // 0x89aee8: r0 = LoadClassIdInstr(r1)
    //     0x89aee8: ldur            x0, [x1, #-1]
    //     0x89aeec: ubfx            x0, x0, #0xc, #0x14
    // 0x89aef0: r0 = GDT[cid_x0 + 0x8ed7]()
    //     0x89aef0: mov             x17, #0x8ed7
    //     0x89aef4: add             lr, x0, x17
    //     0x89aef8: ldr             lr, [x21, lr, lsl #3]
    //     0x89aefc: blr             lr
    // 0x89af00: r0 = Null
    //     0x89af00: mov             x0, NULL
    // 0x89af04: LeaveFrame
    //     0x89af04: mov             SP, fp
    //     0x89af08: ldp             fp, lr, [SP], #0x10
    // 0x89af0c: ret
    //     0x89af0c: ret             
    // 0x89af10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89af10: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89af14: b               #0x89ae8c
  }
  _ append(/* No info */) {
    // ** addr: 0xc16bfc, size: 0x104
    // 0xc16bfc: EnterFrame
    //     0xc16bfc: stp             fp, lr, [SP, #-0x10]!
    //     0xc16c00: mov             fp, SP
    // 0xc16c04: AllocStack(0x10)
    //     0xc16c04: sub             SP, SP, #0x10
    // 0xc16c08: SetupParameters(ContainerLayer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc16c08: mov             x3, x1
    //     0xc16c0c: mov             x0, x2
    //     0xc16c10: stur            x1, [fp, #-8]
    //     0xc16c14: stur            x2, [fp, #-0x10]
    // 0xc16c18: CheckStackOverflow
    //     0xc16c18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16c1c: cmp             SP, x16
    //     0xc16c20: b.ls            #0xc16cf8
    // 0xc16c24: mov             x1, x3
    // 0xc16c28: mov             x2, x0
    // 0xc16c2c: r0 = _adoptChild()
    //     0xc16c2c: bl              #0xc16d00  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::_adoptChild
    // 0xc16c30: ldur            x1, [fp, #-8]
    // 0xc16c34: LoadField: r2 = r1->field_43
    //     0xc16c34: ldur            w2, [x1, #0x43]
    // 0xc16c38: DecompressPointer r2
    //     0xc16c38: add             x2, x2, HEAP, lsl #32
    // 0xc16c3c: mov             x0, x2
    // 0xc16c40: ldur            x3, [fp, #-0x10]
    // 0xc16c44: StoreField: r3->field_3b = r0
    //     0xc16c44: stur            w0, [x3, #0x3b]
    //     0xc16c48: ldurb           w16, [x3, #-1]
    //     0xc16c4c: ldurb           w17, [x0, #-1]
    //     0xc16c50: and             x16, x17, x16, lsr #2
    //     0xc16c54: tst             x16, HEAP, lsr #32
    //     0xc16c58: b.eq            #0xc16c60
    //     0xc16c5c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc16c60: cmp             w2, NULL
    // 0xc16c64: b.eq            #0xc16c88
    // 0xc16c68: mov             x0, x3
    // 0xc16c6c: StoreField: r2->field_37 = r0
    //     0xc16c6c: stur            w0, [x2, #0x37]
    //     0xc16c70: ldurb           w16, [x2, #-1]
    //     0xc16c74: ldurb           w17, [x0, #-1]
    //     0xc16c78: and             x16, x17, x16, lsr #2
    //     0xc16c7c: tst             x16, HEAP, lsr #32
    //     0xc16c80: b.eq            #0xc16c88
    //     0xc16c84: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc16c88: mov             x0, x3
    // 0xc16c8c: StoreField: r1->field_43 = r0
    //     0xc16c8c: stur            w0, [x1, #0x43]
    //     0xc16c90: ldurb           w16, [x1, #-1]
    //     0xc16c94: ldurb           w17, [x0, #-1]
    //     0xc16c98: and             x16, x17, x16, lsr #2
    //     0xc16c9c: tst             x16, HEAP, lsr #32
    //     0xc16ca0: b.eq            #0xc16ca8
    //     0xc16ca4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc16ca8: LoadField: r0 = r1->field_3f
    //     0xc16ca8: ldur            w0, [x1, #0x3f]
    // 0xc16cac: DecompressPointer r0
    //     0xc16cac: add             x0, x0, HEAP, lsl #32
    // 0xc16cb0: cmp             w0, NULL
    // 0xc16cb4: b.ne            #0xc16cd8
    // 0xc16cb8: mov             x0, x3
    // 0xc16cbc: StoreField: r1->field_3f = r0
    //     0xc16cbc: stur            w0, [x1, #0x3f]
    //     0xc16cc0: ldurb           w16, [x1, #-1]
    //     0xc16cc4: ldurb           w17, [x0, #-1]
    //     0xc16cc8: and             x16, x17, x16, lsr #2
    //     0xc16ccc: tst             x16, HEAP, lsr #32
    //     0xc16cd0: b.eq            #0xc16cd8
    //     0xc16cd4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc16cd8: LoadField: r1 = r3->field_13
    //     0xc16cd8: ldur            w1, [x3, #0x13]
    // 0xc16cdc: DecompressPointer r1
    //     0xc16cdc: add             x1, x1, HEAP, lsl #32
    // 0xc16ce0: mov             x2, x3
    // 0xc16ce4: r0 = layer=()
    //     0xc16ce4: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc16ce8: r0 = Null
    //     0xc16ce8: mov             x0, NULL
    // 0xc16cec: LeaveFrame
    //     0xc16cec: mov             SP, fp
    //     0xc16cf0: ldp             fp, lr, [SP], #0x10
    // 0xc16cf4: ret
    //     0xc16cf4: ret             
    // 0xc16cf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16cf8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16cfc: b               #0xc16c24
  }
  _ _adoptChild(/* No info */) {
    // ** addr: 0xc16d00, size: 0xd8
    // 0xc16d00: EnterFrame
    //     0xc16d00: stp             fp, lr, [SP, #-0x10]!
    //     0xc16d04: mov             fp, SP
    // 0xc16d08: AllocStack(0x10)
    //     0xc16d08: sub             SP, SP, #0x10
    // 0xc16d0c: SetupParameters(ContainerLayer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0xc16d0c: mov             x3, x1
    //     0xc16d10: stur            x1, [fp, #-8]
    //     0xc16d14: stur            x2, [fp, #-0x10]
    // 0xc16d18: CheckStackOverflow
    //     0xc16d18: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16d1c: cmp             SP, x16
    //     0xc16d20: b.ls            #0xc16dd0
    // 0xc16d24: r0 = LoadClassIdInstr(r3)
    //     0xc16d24: ldur            x0, [x3, #-1]
    //     0xc16d28: ubfx            x0, x0, #0xc, #0x14
    // 0xc16d2c: mov             x1, x3
    // 0xc16d30: r0 = GDT[cid_x0 + 0x9044]()
    //     0xc16d30: mov             x17, #0x9044
    //     0xc16d34: add             lr, x0, x17
    //     0xc16d38: ldr             lr, [x21, lr, lsl #3]
    //     0xc16d3c: blr             lr
    // 0xc16d40: tbz             w0, #4, #0xc16d4c
    // 0xc16d44: ldur            x1, [fp, #-8]
    // 0xc16d48: r0 = markNeedsAddToScene()
    //     0xc16d48: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc16d4c: ldur            x0, [fp, #-0x10]
    // 0xc16d50: LoadField: r2 = r0->field_b
    //     0xc16d50: ldur            x2, [x0, #0xb]
    // 0xc16d54: cbz             x2, #0xc16d60
    // 0xc16d58: ldur            x1, [fp, #-8]
    // 0xc16d5c: r0 = _updateSubtreeCompositionObserverCount()
    //     0xc16d5c: bl              #0x89af18  ; [package:flutter/src/rendering/layer.dart] Layer::_updateSubtreeCompositionObserverCount
    // 0xc16d60: ldur            x4, [fp, #-8]
    // 0xc16d64: ldur            x3, [fp, #-0x10]
    // 0xc16d68: mov             x0, x4
    // 0xc16d6c: StoreField: r3->field_1f = r0
    //     0xc16d6c: stur            w0, [x3, #0x1f]
    //     0xc16d70: ldurb           w16, [x3, #-1]
    //     0xc16d74: ldurb           w17, [x0, #-1]
    //     0xc16d78: and             x16, x17, x16, lsr #2
    //     0xc16d7c: tst             x16, HEAP, lsr #32
    //     0xc16d80: b.eq            #0xc16d88
    //     0xc16d84: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xc16d88: LoadField: r2 = r4->field_2b
    //     0xc16d88: ldur            w2, [x4, #0x2b]
    // 0xc16d8c: DecompressPointer r2
    //     0xc16d8c: add             x2, x2, HEAP, lsl #32
    // 0xc16d90: cmp             w2, NULL
    // 0xc16d94: b.eq            #0xc16db4
    // 0xc16d98: r0 = LoadClassIdInstr(r3)
    //     0xc16d98: ldur            x0, [x3, #-1]
    //     0xc16d9c: ubfx            x0, x0, #0xc, #0x14
    // 0xc16da0: mov             x1, x3
    // 0xc16da4: r0 = GDT[cid_x0 + 0x6df4]()
    //     0xc16da4: mov             x17, #0x6df4
    //     0xc16da8: add             lr, x0, x17
    //     0xc16dac: ldr             lr, [x21, lr, lsl #3]
    //     0xc16db0: blr             lr
    // 0xc16db4: ldur            x1, [fp, #-8]
    // 0xc16db8: ldur            x2, [fp, #-0x10]
    // 0xc16dbc: r0 = redepthChild()
    //     0xc16dbc: bl              #0xc16dd8  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::redepthChild
    // 0xc16dc0: r0 = Null
    //     0xc16dc0: mov             x0, NULL
    // 0xc16dc4: LeaveFrame
    //     0xc16dc4: mov             SP, fp
    //     0xc16dc8: ldp             fp, lr, [SP], #0x10
    // 0xc16dcc: ret
    //     0xc16dcc: ret             
    // 0xc16dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16dd4: b               #0xc16d24
  }
  _ redepthChild(/* No info */) {
    // ** addr: 0xc16dd8, size: 0x64
    // 0xc16dd8: EnterFrame
    //     0xc16dd8: stp             fp, lr, [SP, #-0x10]!
    //     0xc16ddc: mov             fp, SP
    // 0xc16de0: mov             x0, x1
    // 0xc16de4: mov             x1, x2
    // 0xc16de8: CheckStackOverflow
    //     0xc16de8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16dec: cmp             SP, x16
    //     0xc16df0: b.ls            #0xc16e34
    // 0xc16df4: LoadField: r2 = r1->field_2f
    //     0xc16df4: ldur            x2, [x1, #0x2f]
    // 0xc16df8: LoadField: r3 = r0->field_2f
    //     0xc16df8: ldur            x3, [x0, #0x2f]
    // 0xc16dfc: cmp             x2, x3
    // 0xc16e00: b.gt            #0xc16e24
    // 0xc16e04: add             x0, x3, #1
    // 0xc16e08: StoreField: r1->field_2f = r0
    //     0xc16e08: stur            x0, [x1, #0x2f]
    // 0xc16e0c: r0 = LoadClassIdInstr(r1)
    //     0xc16e0c: ldur            x0, [x1, #-1]
    //     0xc16e10: ubfx            x0, x0, #0xc, #0x14
    // 0xc16e14: r0 = GDT[cid_x0 + 0xb127]()
    //     0xc16e14: mov             x17, #0xb127
    //     0xc16e18: add             lr, x0, x17
    //     0xc16e1c: ldr             lr, [x21, lr, lsl #3]
    //     0xc16e20: blr             lr
    // 0xc16e24: r0 = Null
    //     0xc16e24: mov             x0, NULL
    // 0xc16e28: LeaveFrame
    //     0xc16e28: mov             SP, fp
    //     0xc16e2c: ldp             fp, lr, [SP], #0x10
    // 0xc16e30: ret
    //     0xc16e30: ret             
    // 0xc16e34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16e34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16e38: b               #0xc16df4
  }
  _ _removeChild(/* No info */) {
    // ** addr: 0xc16e80, size: 0x10c
    // 0xc16e80: EnterFrame
    //     0xc16e80: stp             fp, lr, [SP, #-0x10]!
    //     0xc16e84: mov             fp, SP
    // 0xc16e88: AllocStack(0x8)
    //     0xc16e88: sub             SP, SP, #8
    // 0xc16e8c: SetupParameters(dynamic _ /* r2 => r3, fp-0x8 */)
    //     0xc16e8c: mov             x3, x2
    //     0xc16e90: stur            x2, [fp, #-8]
    // 0xc16e94: CheckStackOverflow
    //     0xc16e94: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16e98: cmp             SP, x16
    //     0xc16e9c: b.ls            #0xc16f84
    // 0xc16ea0: LoadField: r2 = r3->field_3b
    //     0xc16ea0: ldur            w2, [x3, #0x3b]
    // 0xc16ea4: DecompressPointer r2
    //     0xc16ea4: add             x2, x2, HEAP, lsl #32
    // 0xc16ea8: cmp             w2, NULL
    // 0xc16eac: b.ne            #0xc16ed8
    // 0xc16eb0: LoadField: r0 = r3->field_37
    //     0xc16eb0: ldur            w0, [x3, #0x37]
    // 0xc16eb4: DecompressPointer r0
    //     0xc16eb4: add             x0, x0, HEAP, lsl #32
    // 0xc16eb8: StoreField: r1->field_3f = r0
    //     0xc16eb8: stur            w0, [x1, #0x3f]
    //     0xc16ebc: ldurb           w16, [x1, #-1]
    //     0xc16ec0: ldurb           w17, [x0, #-1]
    //     0xc16ec4: and             x16, x17, x16, lsr #2
    //     0xc16ec8: tst             x16, HEAP, lsr #32
    //     0xc16ecc: b.eq            #0xc16ed4
    //     0xc16ed0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc16ed4: b               #0xc16efc
    // 0xc16ed8: LoadField: r0 = r3->field_37
    //     0xc16ed8: ldur            w0, [x3, #0x37]
    // 0xc16edc: DecompressPointer r0
    //     0xc16edc: add             x0, x0, HEAP, lsl #32
    // 0xc16ee0: StoreField: r2->field_37 = r0
    //     0xc16ee0: stur            w0, [x2, #0x37]
    //     0xc16ee4: ldurb           w16, [x2, #-1]
    //     0xc16ee8: ldurb           w17, [x0, #-1]
    //     0xc16eec: and             x16, x17, x16, lsr #2
    //     0xc16ef0: tst             x16, HEAP, lsr #32
    //     0xc16ef4: b.eq            #0xc16efc
    //     0xc16ef8: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc16efc: LoadField: r4 = r3->field_37
    //     0xc16efc: ldur            w4, [x3, #0x37]
    // 0xc16f00: DecompressPointer r4
    //     0xc16f00: add             x4, x4, HEAP, lsl #32
    // 0xc16f04: cmp             w4, NULL
    // 0xc16f08: b.ne            #0xc16f30
    // 0xc16f0c: mov             x0, x2
    // 0xc16f10: StoreField: r1->field_43 = r0
    //     0xc16f10: stur            w0, [x1, #0x43]
    //     0xc16f14: ldurb           w16, [x1, #-1]
    //     0xc16f18: ldurb           w17, [x0, #-1]
    //     0xc16f1c: and             x16, x17, x16, lsr #2
    //     0xc16f20: tst             x16, HEAP, lsr #32
    //     0xc16f24: b.eq            #0xc16f2c
    //     0xc16f28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc16f2c: b               #0xc16f50
    // 0xc16f30: mov             x0, x2
    // 0xc16f34: StoreField: r4->field_3b = r0
    //     0xc16f34: stur            w0, [x4, #0x3b]
    //     0xc16f38: ldurb           w16, [x4, #-1]
    //     0xc16f3c: ldurb           w17, [x0, #-1]
    //     0xc16f40: and             x16, x17, x16, lsr #2
    //     0xc16f44: tst             x16, HEAP, lsr #32
    //     0xc16f48: b.eq            #0xc16f50
    //     0xc16f4c: bl              #0x13ddff4  ; WriteBarrierWrappersStub
    // 0xc16f50: StoreField: r3->field_3b = rNULL
    //     0xc16f50: stur            NULL, [x3, #0x3b]
    // 0xc16f54: StoreField: r3->field_37 = rNULL
    //     0xc16f54: stur            NULL, [x3, #0x37]
    // 0xc16f58: mov             x2, x3
    // 0xc16f5c: r0 = _dropChild()
    //     0xc16f5c: bl              #0x89ae68  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::_dropChild
    // 0xc16f60: ldur            x0, [fp, #-8]
    // 0xc16f64: LoadField: r1 = r0->field_13
    //     0xc16f64: ldur            w1, [x0, #0x13]
    // 0xc16f68: DecompressPointer r1
    //     0xc16f68: add             x1, x1, HEAP, lsl #32
    // 0xc16f6c: r2 = Null
    //     0xc16f6c: mov             x2, NULL
    // 0xc16f70: r0 = layer=()
    //     0xc16f70: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc16f74: r0 = Null
    //     0xc16f74: mov             x0, NULL
    // 0xc16f78: LeaveFrame
    //     0xc16f78: mov             SP, fp
    //     0xc16f7c: ldp             fp, lr, [SP], #0x10
    // 0xc16f80: ret
    //     0xc16f80: ret             
    // 0xc16f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc16f84: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc16f88: b               #0xc16ea0
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x10f4804, size: 0xac
    // 0x10f4804: EnterFrame
    //     0x10f4804: stp             fp, lr, [SP, #-0x10]!
    //     0x10f4808: mov             fp, SP
    // 0x10f480c: AllocStack(0x10)
    //     0x10f480c: sub             SP, SP, #0x10
    // 0x10f4810: SetupParameters(ContainerLayer this /* r1 => r2, fp-0x10 */)
    //     0x10f4810: mov             x2, x1
    //     0x10f4814: stur            x1, [fp, #-0x10]
    // 0x10f4818: CheckStackOverflow
    //     0x10f4818: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f481c: cmp             SP, x16
    //     0x10f4820: b.ls            #0x10f48a0
    // 0x10f4824: LoadField: r0 = r2->field_3f
    //     0x10f4824: ldur            w0, [x2, #0x3f]
    // 0x10f4828: DecompressPointer r0
    //     0x10f4828: add             x0, x0, HEAP, lsl #32
    // 0x10f482c: mov             x3, x0
    // 0x10f4830: stur            x3, [fp, #-8]
    // 0x10f4834: CheckStackOverflow
    //     0x10f4834: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10f4838: cmp             SP, x16
    //     0x10f483c: b.ls            #0x10f48a8
    // 0x10f4840: cmp             w3, NULL
    // 0x10f4844: b.eq            #0x10f4890
    // 0x10f4848: LoadField: r0 = r3->field_2f
    //     0x10f4848: ldur            x0, [x3, #0x2f]
    // 0x10f484c: LoadField: r1 = r2->field_2f
    //     0x10f484c: ldur            x1, [x2, #0x2f]
    // 0x10f4850: cmp             x0, x1
    // 0x10f4854: b.gt            #0x10f487c
    // 0x10f4858: add             x0, x1, #1
    // 0x10f485c: StoreField: r3->field_2f = r0
    //     0x10f485c: stur            x0, [x3, #0x2f]
    // 0x10f4860: r0 = LoadClassIdInstr(r3)
    //     0x10f4860: ldur            x0, [x3, #-1]
    //     0x10f4864: ubfx            x0, x0, #0xc, #0x14
    // 0x10f4868: mov             x1, x3
    // 0x10f486c: r0 = GDT[cid_x0 + 0xb127]()
    //     0x10f486c: mov             x17, #0xb127
    //     0x10f4870: add             lr, x0, x17
    //     0x10f4874: ldr             lr, [x21, lr, lsl #3]
    //     0x10f4878: blr             lr
    // 0x10f487c: ldur            x1, [fp, #-8]
    // 0x10f4880: LoadField: r3 = r1->field_37
    //     0x10f4880: ldur            w3, [x1, #0x37]
    // 0x10f4884: DecompressPointer r3
    //     0x10f4884: add             x3, x3, HEAP, lsl #32
    // 0x10f4888: ldur            x2, [fp, #-0x10]
    // 0x10f488c: b               #0x10f4830
    // 0x10f4890: r0 = Null
    //     0x10f4890: mov             x0, NULL
    // 0x10f4894: LeaveFrame
    //     0x10f4894: mov             SP, fp
    //     0x10f4898: ldp             fp, lr, [SP], #0x10
    // 0x10f489c: ret
    //     0x10f489c: ret             
    // 0x10f48a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f48a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f48a4: b               #0x10f4824
    // 0x10f48a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10f48a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10f48ac: b               #0x10f4840
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10fc354, size: 0x58
    // 0x10fc354: EnterFrame
    //     0x10fc354: stp             fp, lr, [SP, #-0x10]!
    //     0x10fc358: mov             fp, SP
    // 0x10fc35c: AllocStack(0x8)
    //     0x10fc35c: sub             SP, SP, #8
    // 0x10fc360: SetupParameters(ContainerLayer this /* r1 => r0, fp-0x8 */)
    //     0x10fc360: mov             x0, x1
    //     0x10fc364: stur            x1, [fp, #-8]
    // 0x10fc368: CheckStackOverflow
    //     0x10fc368: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10fc36c: cmp             SP, x16
    //     0x10fc370: b.ls            #0x10fc3a4
    // 0x10fc374: mov             x1, x0
    // 0x10fc378: r0 = removeAllChildren()
    //     0x10fc378: bl              #0x89ad4c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::removeAllChildren
    // 0x10fc37c: ldur            x0, [fp, #-8]
    // 0x10fc380: LoadField: r1 = r0->field_7
    //     0x10fc380: ldur            w1, [x0, #7]
    // 0x10fc384: DecompressPointer r1
    //     0x10fc384: add             x1, x1, HEAP, lsl #32
    // 0x10fc388: r0 = clear()
    //     0x10fc388: bl              #0xa11274  ; [dart:_compact_hash] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::clear
    // 0x10fc38c: ldur            x1, [fp, #-8]
    // 0x10fc390: r0 = dispose()
    //     0x10fc390: bl              #0x10fc2a8  ; [package:flutter/src/rendering/layer.dart] Layer::dispose
    // 0x10fc394: r0 = Null
    //     0x10fc394: mov             x0, NULL
    // 0x10fc398: LeaveFrame
    //     0x10fc398: mov             SP, fp
    //     0x10fc39c: ldp             fp, lr, [SP], #0x10
    // 0x10fc3a0: ret
    //     0x10fc3a0: ret             
    // 0x10fc3a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10fc3a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10fc3a8: b               #0x10fc374
  }
  _ supportsRasterization(/* No info */) {
    // ** addr: 0x10fc3ac, size: 0x9c
    // 0x10fc3ac: EnterFrame
    //     0x10fc3ac: stp             fp, lr, [SP, #-0x10]!
    //     0x10fc3b0: mov             fp, SP
    // 0x10fc3b4: AllocStack(0x8)
    //     0x10fc3b4: sub             SP, SP, #8
    // 0x10fc3b8: CheckStackOverflow
    //     0x10fc3b8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10fc3bc: cmp             SP, x16
    //     0x10fc3c0: b.ls            #0x10fc438
    // 0x10fc3c4: LoadField: r0 = r1->field_43
    //     0x10fc3c4: ldur            w0, [x1, #0x43]
    // 0x10fc3c8: DecompressPointer r0
    //     0x10fc3c8: add             x0, x0, HEAP, lsl #32
    // 0x10fc3cc: mov             x2, x0
    // 0x10fc3d0: stur            x2, [fp, #-8]
    // 0x10fc3d4: CheckStackOverflow
    //     0x10fc3d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10fc3d8: cmp             SP, x16
    //     0x10fc3dc: b.ls            #0x10fc440
    // 0x10fc3e0: cmp             w2, NULL
    // 0x10fc3e4: b.eq            #0x10fc428
    // 0x10fc3e8: r0 = LoadClassIdInstr(r2)
    //     0x10fc3e8: ldur            x0, [x2, #-1]
    //     0x10fc3ec: ubfx            x0, x0, #0xc, #0x14
    // 0x10fc3f0: mov             x1, x2
    // 0x10fc3f4: r0 = GDT[cid_x0 + 0xafba]()
    //     0x10fc3f4: mov             x17, #0xafba
    //     0x10fc3f8: add             lr, x0, x17
    //     0x10fc3fc: ldr             lr, [x21, lr, lsl #3]
    //     0x10fc400: blr             lr
    // 0x10fc404: tbnz            w0, #4, #0x10fc418
    // 0x10fc408: ldur            x1, [fp, #-8]
    // 0x10fc40c: LoadField: r2 = r1->field_3b
    //     0x10fc40c: ldur            w2, [x1, #0x3b]
    // 0x10fc410: DecompressPointer r2
    //     0x10fc410: add             x2, x2, HEAP, lsl #32
    // 0x10fc414: b               #0x10fc3d0
    // 0x10fc418: r0 = false
    //     0x10fc418: add             x0, NULL, #0x30  ; false
    // 0x10fc41c: LeaveFrame
    //     0x10fc41c: mov             SP, fp
    //     0x10fc420: ldp             fp, lr, [SP], #0x10
    // 0x10fc424: ret
    //     0x10fc424: ret             
    // 0x10fc428: r0 = true
    //     0x10fc428: add             x0, NULL, #0x20  ; true
    // 0x10fc42c: LeaveFrame
    //     0x10fc42c: mov             SP, fp
    //     0x10fc430: ldp             fp, lr, [SP], #0x10
    // 0x10fc434: ret
    //     0x10fc434: ret             
    // 0x10fc438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10fc438: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10fc43c: b               #0x10fc3c4
    // 0x10fc440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10fc440: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10fc444: b               #0x10fc3e0
  }
  _ _fireCompositionCallbacks(/* No info */) {
    // ** addr: 0x110425c, size: 0xc8
    // 0x110425c: EnterFrame
    //     0x110425c: stp             fp, lr, [SP, #-0x10]!
    //     0x1104260: mov             fp, SP
    // 0x1104264: AllocStack(0x10)
    //     0x1104264: sub             SP, SP, #0x10
    // 0x1104268: SetupParameters(ContainerLayer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x1104268: mov             x3, x1
    //     0x110426c: mov             x0, x2
    //     0x1104270: stur            x1, [fp, #-8]
    //     0x1104274: stur            x2, [fp, #-0x10]
    // 0x1104278: CheckStackOverflow
    //     0x1104278: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110427c: cmp             SP, x16
    //     0x1104280: b.ls            #0x1104314
    // 0x1104284: mov             x1, x3
    // 0x1104288: mov             x2, x0
    // 0x110428c: r0 = _fireCompositionCallbacks()
    //     0x110428c: bl              #0x11040bc  ; [package:flutter/src/rendering/layer.dart] Layer::_fireCompositionCallbacks
    // 0x1104290: ldur            x3, [fp, #-0x10]
    // 0x1104294: tbz             w3, #4, #0x11042a8
    // 0x1104298: r0 = Null
    //     0x1104298: mov             x0, NULL
    // 0x110429c: LeaveFrame
    //     0x110429c: mov             SP, fp
    //     0x11042a0: ldp             fp, lr, [SP], #0x10
    // 0x11042a4: ret
    //     0x11042a4: ret             
    // 0x11042a8: ldur            x0, [fp, #-8]
    // 0x11042ac: LoadField: r1 = r0->field_3f
    //     0x11042ac: ldur            w1, [x0, #0x3f]
    // 0x11042b0: DecompressPointer r1
    //     0x11042b0: add             x1, x1, HEAP, lsl #32
    // 0x11042b4: mov             x4, x1
    // 0x11042b8: stur            x4, [fp, #-8]
    // 0x11042bc: CheckStackOverflow
    //     0x11042bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11042c0: cmp             SP, x16
    //     0x11042c4: b.ls            #0x110431c
    // 0x11042c8: cmp             w4, NULL
    // 0x11042cc: b.eq            #0x1104304
    // 0x11042d0: r0 = LoadClassIdInstr(r4)
    //     0x11042d0: ldur            x0, [x4, #-1]
    //     0x11042d4: ubfx            x0, x0, #0xc, #0x14
    // 0x11042d8: mov             x1, x4
    // 0x11042dc: mov             x2, x3
    // 0x11042e0: r0 = GDT[cid_x0 + 0x9bc4]()
    //     0x11042e0: mov             x17, #0x9bc4
    //     0x11042e4: add             lr, x0, x17
    //     0x11042e8: ldr             lr, [x21, lr, lsl #3]
    //     0x11042ec: blr             lr
    // 0x11042f0: ldur            x1, [fp, #-8]
    // 0x11042f4: LoadField: r4 = r1->field_37
    //     0x11042f4: ldur            w4, [x1, #0x37]
    // 0x11042f8: DecompressPointer r4
    //     0x11042f8: add             x4, x4, HEAP, lsl #32
    // 0x11042fc: ldur            x3, [fp, #-0x10]
    // 0x1104300: b               #0x11042b8
    // 0x1104304: r0 = Null
    //     0x1104304: mov             x0, NULL
    // 0x1104308: LeaveFrame
    //     0x1104308: mov             SP, fp
    //     0x110430c: ldp             fp, lr, [SP], #0x10
    // 0x1104310: ret
    //     0x1104310: ret             
    // 0x1104314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1104314: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1104318: b               #0x1104284
    // 0x110431c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110431c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1104320: b               #0x11042c8
  }
  _ detach(/* No info */) {
    // ** addr: 0x110a700, size: 0xac
    // 0x110a700: EnterFrame
    //     0x110a700: stp             fp, lr, [SP, #-0x10]!
    //     0x110a704: mov             fp, SP
    // 0x110a708: AllocStack(0x10)
    //     0x110a708: sub             SP, SP, #0x10
    // 0x110a70c: SetupParameters(ContainerLayer this /* r1 => r0, fp-0x8 */)
    //     0x110a70c: mov             x0, x1
    //     0x110a710: stur            x1, [fp, #-8]
    // 0x110a714: CheckStackOverflow
    //     0x110a714: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110a718: cmp             SP, x16
    //     0x110a71c: b.ls            #0x110a79c
    // 0x110a720: mov             x1, x0
    // 0x110a724: r0 = detach()
    //     0x110a724: bl              #0x110a6a4  ; [package:flutter/src/rendering/layer.dart] Layer::detach
    // 0x110a728: ldur            x2, [fp, #-8]
    // 0x110a72c: LoadField: r0 = r2->field_3f
    //     0x110a72c: ldur            w0, [x2, #0x3f]
    // 0x110a730: DecompressPointer r0
    //     0x110a730: add             x0, x0, HEAP, lsl #32
    // 0x110a734: mov             x3, x0
    // 0x110a738: stur            x3, [fp, #-0x10]
    // 0x110a73c: CheckStackOverflow
    //     0x110a73c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110a740: cmp             SP, x16
    //     0x110a744: b.ls            #0x110a7a4
    // 0x110a748: cmp             w3, NULL
    // 0x110a74c: b.eq            #0x110a780
    // 0x110a750: r0 = LoadClassIdInstr(r3)
    //     0x110a750: ldur            x0, [x3, #-1]
    //     0x110a754: ubfx            x0, x0, #0xc, #0x14
    // 0x110a758: mov             x1, x3
    // 0x110a75c: r0 = GDT[cid_x0 + 0x8ed7]()
    //     0x110a75c: mov             x17, #0x8ed7
    //     0x110a760: add             lr, x0, x17
    //     0x110a764: ldr             lr, [x21, lr, lsl #3]
    //     0x110a768: blr             lr
    // 0x110a76c: ldur            x0, [fp, #-0x10]
    // 0x110a770: LoadField: r3 = r0->field_37
    //     0x110a770: ldur            w3, [x0, #0x37]
    // 0x110a774: DecompressPointer r3
    //     0x110a774: add             x3, x3, HEAP, lsl #32
    // 0x110a778: ldur            x2, [fp, #-8]
    // 0x110a77c: b               #0x110a738
    // 0x110a780: ldur            x1, [fp, #-8]
    // 0x110a784: r2 = false
    //     0x110a784: add             x2, NULL, #0x30  ; false
    // 0x110a788: r0 = _fireCompositionCallbacks()
    //     0x110a788: bl              #0x11040bc  ; [package:flutter/src/rendering/layer.dart] Layer::_fireCompositionCallbacks
    // 0x110a78c: r0 = Null
    //     0x110a78c: mov             x0, NULL
    // 0x110a790: LeaveFrame
    //     0x110a790: mov             SP, fp
    //     0x110a794: ldp             fp, lr, [SP], #0x10
    // 0x110a798: ret
    //     0x110a798: ret             
    // 0x110a79c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110a79c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110a7a0: b               #0x110a720
    // 0x110a7a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110a7a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110a7a8: b               #0x110a748
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0x112c43c, size: 0x110
    // 0x112c43c: EnterFrame
    //     0x112c43c: stp             fp, lr, [SP, #-0x10]!
    //     0x112c440: mov             fp, SP
    // 0x112c444: AllocStack(0x38)
    //     0x112c444: sub             SP, SP, #0x38
    // 0x112c448: SetupParameters()
    //     0x112c448: ldur            w0, [x4, #0xf]
    //     0x112c44c: cbnz            w0, #0x112c458
    //     0x112c450: mov             x1, NULL
    //     0x112c454: b               #0x112c468
    //     0x112c458: ldur            w1, [x4, #0x17]
    //     0x112c45c: add             x2, fp, w1, sxtw #2
    //     0x112c460: ldr             x2, [x2, #0x10]
    //     0x112c464: mov             x1, x2
    // 0x112c468: CheckStackOverflow
    //     0x112c468: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c46c: cmp             SP, x16
    //     0x112c470: b.ls            #0x112c53c
    // 0x112c474: cbnz            w0, #0x112c480
    // 0x112c478: r2 = <Object>
    //     0x112c478: ldr             x2, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112c47c: b               #0x112c484
    // 0x112c480: mov             x2, x1
    // 0x112c484: ldr             x0, [fp, #0x20]
    // 0x112c488: ldr             x1, [fp, #0x18]
    // 0x112c48c: stur            x2, [fp, #-0x18]
    // 0x112c490: LoadField: r3 = r0->field_43
    //     0x112c490: ldur            w3, [x0, #0x43]
    // 0x112c494: DecompressPointer r3
    //     0x112c494: add             x3, x3, HEAP, lsl #32
    // 0x112c498: LoadField: r4 = r1->field_b
    //     0x112c498: ldur            w4, [x1, #0xb]
    // 0x112c49c: DecompressPointer r4
    //     0x112c49c: add             x4, x4, HEAP, lsl #32
    // 0x112c4a0: stur            x4, [fp, #-0x10]
    // 0x112c4a4: stur            x3, [fp, #-8]
    // 0x112c4a8: CheckStackOverflow
    //     0x112c4a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c4ac: cmp             SP, x16
    //     0x112c4b0: b.ls            #0x112c544
    // 0x112c4b4: cmp             w3, NULL
    // 0x112c4b8: b.eq            #0x112c52c
    // 0x112c4bc: r0 = LoadClassIdInstr(r3)
    //     0x112c4bc: ldur            x0, [x3, #-1]
    //     0x112c4c0: ubfx            x0, x0, #0xc, #0x14
    // 0x112c4c4: stp             x3, x2, [SP, #0x10]
    // 0x112c4c8: ldr             x16, [fp, #0x10]
    // 0x112c4cc: stp             x16, x1, [SP]
    // 0x112c4d0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c4d0: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c4d4: r0 = GDT[cid_x0 + 0x7ae1]()
    //     0x112c4d4: mov             x17, #0x7ae1
    //     0x112c4d8: add             lr, x0, x17
    //     0x112c4dc: ldr             lr, [x21, lr, lsl #3]
    //     0x112c4e0: blr             lr
    // 0x112c4e4: tbz             w0, #4, #0x112c51c
    // 0x112c4e8: ldur            x1, [fp, #-0x10]
    // 0x112c4ec: LoadField: r2 = r1->field_b
    //     0x112c4ec: ldur            w2, [x1, #0xb]
    // 0x112c4f0: cbnz            w2, #0x112c510
    // 0x112c4f4: ldur            x2, [fp, #-8]
    // 0x112c4f8: LoadField: r3 = r2->field_3b
    //     0x112c4f8: ldur            w3, [x2, #0x3b]
    // 0x112c4fc: DecompressPointer r3
    //     0x112c4fc: add             x3, x3, HEAP, lsl #32
    // 0x112c500: mov             x4, x1
    // 0x112c504: ldr             x1, [fp, #0x18]
    // 0x112c508: ldur            x2, [fp, #-0x18]
    // 0x112c50c: b               #0x112c4a4
    // 0x112c510: LeaveFrame
    //     0x112c510: mov             SP, fp
    //     0x112c514: ldp             fp, lr, [SP], #0x10
    // 0x112c518: ret
    //     0x112c518: ret             
    // 0x112c51c: r0 = true
    //     0x112c51c: add             x0, NULL, #0x20  ; true
    // 0x112c520: LeaveFrame
    //     0x112c520: mov             SP, fp
    //     0x112c524: ldp             fp, lr, [SP], #0x10
    // 0x112c528: ret
    //     0x112c528: ret             
    // 0x112c52c: r0 = false
    //     0x112c52c: add             x0, NULL, #0x30  ; false
    // 0x112c530: LeaveFrame
    //     0x112c530: mov             SP, fp
    //     0x112c534: ldp             fp, lr, [SP], #0x10
    // 0x112c538: ret
    //     0x112c538: ret             
    // 0x112c53c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c53c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c540: b               #0x112c474
    // 0x112c544: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c544: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c548: b               #0x112c4b4
  }
  _ attach(/* No info */) {
    // ** addr: 0x1146e7c, size: 0xbc
    // 0x1146e7c: EnterFrame
    //     0x1146e7c: stp             fp, lr, [SP, #-0x10]!
    //     0x1146e80: mov             fp, SP
    // 0x1146e84: AllocStack(0x10)
    //     0x1146e84: sub             SP, SP, #0x10
    // 0x1146e88: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */)
    //     0x1146e88: mov             x3, x2
    //     0x1146e8c: stur            x2, [fp, #-0x10]
    // 0x1146e90: CheckStackOverflow
    //     0x1146e90: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1146e94: cmp             SP, x16
    //     0x1146e98: b.ls            #0x1146f28
    // 0x1146e9c: mov             x0, x3
    // 0x1146ea0: StoreField: r1->field_2b = r0
    //     0x1146ea0: stur            w0, [x1, #0x2b]
    //     0x1146ea4: tbz             w0, #0, #0x1146ec0
    //     0x1146ea8: ldurb           w16, [x1, #-1]
    //     0x1146eac: ldurb           w17, [x0, #-1]
    //     0x1146eb0: and             x16, x17, x16, lsr #2
    //     0x1146eb4: tst             x16, HEAP, lsr #32
    //     0x1146eb8: b.eq            #0x1146ec0
    //     0x1146ebc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1146ec0: LoadField: r0 = r1->field_3f
    //     0x1146ec0: ldur            w0, [x1, #0x3f]
    // 0x1146ec4: DecompressPointer r0
    //     0x1146ec4: add             x0, x0, HEAP, lsl #32
    // 0x1146ec8: mov             x4, x0
    // 0x1146ecc: stur            x4, [fp, #-8]
    // 0x1146ed0: CheckStackOverflow
    //     0x1146ed0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1146ed4: cmp             SP, x16
    //     0x1146ed8: b.ls            #0x1146f30
    // 0x1146edc: cmp             w4, NULL
    // 0x1146ee0: b.eq            #0x1146f18
    // 0x1146ee4: r0 = LoadClassIdInstr(r4)
    //     0x1146ee4: ldur            x0, [x4, #-1]
    //     0x1146ee8: ubfx            x0, x0, #0xc, #0x14
    // 0x1146eec: mov             x1, x4
    // 0x1146ef0: mov             x2, x3
    // 0x1146ef4: r0 = GDT[cid_x0 + 0x6df4]()
    //     0x1146ef4: mov             x17, #0x6df4
    //     0x1146ef8: add             lr, x0, x17
    //     0x1146efc: ldr             lr, [x21, lr, lsl #3]
    //     0x1146f00: blr             lr
    // 0x1146f04: ldur            x1, [fp, #-8]
    // 0x1146f08: LoadField: r4 = r1->field_37
    //     0x1146f08: ldur            w4, [x1, #0x37]
    // 0x1146f0c: DecompressPointer r4
    //     0x1146f0c: add             x4, x4, HEAP, lsl #32
    // 0x1146f10: ldur            x3, [fp, #-0x10]
    // 0x1146f14: b               #0x1146ecc
    // 0x1146f18: r0 = Null
    //     0x1146f18: mov             x0, NULL
    // 0x1146f1c: LeaveFrame
    //     0x1146f1c: mov             SP, fp
    //     0x1146f20: ldp             fp, lr, [SP], #0x10
    // 0x1146f24: ret
    //     0x1146f24: ret             
    // 0x1146f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1146f28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1146f2c: b               #0x1146e9c
    // 0x1146f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1146f30: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1146f34: b               #0x1146edc
  }
  _ updateSubtreeNeedsAddToScene(/* No info */) {
    // ** addr: 0x1159ec4, size: 0xcc
    // 0x1159ec4: EnterFrame
    //     0x1159ec4: stp             fp, lr, [SP, #-0x10]!
    //     0x1159ec8: mov             fp, SP
    // 0x1159ecc: AllocStack(0x10)
    //     0x1159ecc: sub             SP, SP, #0x10
    // 0x1159ed0: SetupParameters(ContainerLayer this /* r1 => r0, fp-0x8 */)
    //     0x1159ed0: mov             x0, x1
    //     0x1159ed4: stur            x1, [fp, #-8]
    // 0x1159ed8: CheckStackOverflow
    //     0x1159ed8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1159edc: cmp             SP, x16
    //     0x1159ee0: b.ls            #0x1159f80
    // 0x1159ee4: mov             x1, x0
    // 0x1159ee8: r0 = updateSubtreeNeedsAddToScene()
    //     0x1159ee8: bl              #0x1159e4c  ; [package:flutter/src/rendering/layer.dart] Layer::updateSubtreeNeedsAddToScene
    // 0x1159eec: ldur            x2, [fp, #-8]
    // 0x1159ef0: LoadField: r0 = r2->field_3f
    //     0x1159ef0: ldur            w0, [x2, #0x3f]
    // 0x1159ef4: DecompressPointer r0
    //     0x1159ef4: add             x0, x0, HEAP, lsl #32
    // 0x1159ef8: mov             x3, x0
    // 0x1159efc: stur            x3, [fp, #-0x10]
    // 0x1159f00: CheckStackOverflow
    //     0x1159f00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1159f04: cmp             SP, x16
    //     0x1159f08: b.ls            #0x1159f88
    // 0x1159f0c: cmp             w3, NULL
    // 0x1159f10: b.eq            #0x1159f70
    // 0x1159f14: r0 = LoadClassIdInstr(r3)
    //     0x1159f14: ldur            x0, [x3, #-1]
    //     0x1159f18: ubfx            x0, x0, #0xc, #0x14
    // 0x1159f1c: mov             x1, x3
    // 0x1159f20: r0 = GDT[cid_x0 + 0x59fe]()
    //     0x1159f20: mov             x17, #0x59fe
    //     0x1159f24: add             lr, x0, x17
    //     0x1159f28: ldr             lr, [x21, lr, lsl #3]
    //     0x1159f2c: blr             lr
    // 0x1159f30: ldur            x1, [fp, #-8]
    // 0x1159f34: LoadField: r2 = r1->field_23
    //     0x1159f34: ldur            w2, [x1, #0x23]
    // 0x1159f38: DecompressPointer r2
    //     0x1159f38: add             x2, x2, HEAP, lsl #32
    // 0x1159f3c: tbnz            w2, #4, #0x1159f4c
    // 0x1159f40: ldur            x2, [fp, #-0x10]
    // 0x1159f44: r3 = true
    //     0x1159f44: add             x3, NULL, #0x20  ; true
    // 0x1159f48: b               #0x1159f5c
    // 0x1159f4c: ldur            x2, [fp, #-0x10]
    // 0x1159f50: LoadField: r0 = r2->field_23
    //     0x1159f50: ldur            w0, [x2, #0x23]
    // 0x1159f54: DecompressPointer r0
    //     0x1159f54: add             x0, x0, HEAP, lsl #32
    // 0x1159f58: mov             x3, x0
    // 0x1159f5c: StoreField: r1->field_23 = r3
    //     0x1159f5c: stur            w3, [x1, #0x23]
    // 0x1159f60: LoadField: r3 = r2->field_37
    //     0x1159f60: ldur            w3, [x2, #0x37]
    // 0x1159f64: DecompressPointer r3
    //     0x1159f64: add             x3, x3, HEAP, lsl #32
    // 0x1159f68: mov             x2, x1
    // 0x1159f6c: b               #0x1159efc
    // 0x1159f70: r0 = Null
    //     0x1159f70: mov             x0, NULL
    // 0x1159f74: LeaveFrame
    //     0x1159f74: mov             SP, fp
    //     0x1159f78: ldp             fp, lr, [SP], #0x10
    // 0x1159f7c: ret
    //     0x1159f7c: ret             
    // 0x1159f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1159f80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1159f84: b               #0x1159ee4
    // 0x1159f88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1159f88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1159f8c: b               #0x1159f0c
  }
  _ addChildrenToScene(/* No info */) {
    // ** addr: 0x116fe88, size: 0x128
    // 0x116fe88: EnterFrame
    //     0x116fe88: stp             fp, lr, [SP, #-0x10]!
    //     0x116fe8c: mov             fp, SP
    // 0x116fe90: AllocStack(0x28)
    //     0x116fe90: sub             SP, SP, #0x28
    // 0x116fe94: SetupParameters(dynamic _ /* r2 => r2, fp-0x20 */)
    //     0x116fe94: stur            x2, [fp, #-0x20]
    // 0x116fe98: CheckStackOverflow
    //     0x116fe98: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116fe9c: cmp             SP, x16
    //     0x116fea0: b.ls            #0x116ff9c
    // 0x116fea4: LoadField: r0 = r1->field_3f
    //     0x116fea4: ldur            w0, [x1, #0x3f]
    // 0x116fea8: DecompressPointer r0
    //     0x116fea8: add             x0, x0, HEAP, lsl #32
    // 0x116feac: stur            x0, [fp, #-0x18]
    // 0x116feb0: CheckStackOverflow
    //     0x116feb0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116feb4: cmp             SP, x16
    //     0x116feb8: b.ls            #0x116ffa4
    // 0x116febc: cmp             w0, NULL
    // 0x116fec0: b.eq            #0x116ff7c
    // 0x116fec4: LoadField: r1 = r0->field_23
    //     0x116fec4: ldur            w1, [x0, #0x23]
    // 0x116fec8: DecompressPointer r1
    //     0x116fec8: add             x1, x1, HEAP, lsl #32
    // 0x116fecc: tbz             w1, #4, #0x116ff38
    // 0x116fed0: LoadField: r1 = r0->field_27
    //     0x116fed0: ldur            w1, [x0, #0x27]
    // 0x116fed4: DecompressPointer r1
    //     0x116fed4: add             x1, x1, HEAP, lsl #32
    // 0x116fed8: cmp             w1, NULL
    // 0x116fedc: b.eq            #0x116ff38
    // 0x116fee0: LoadField: r3 = r1->field_7
    //     0x116fee0: ldur            w3, [x1, #7]
    // 0x116fee4: DecompressPointer r3
    //     0x116fee4: add             x3, x3, HEAP, lsl #32
    // 0x116fee8: stur            x3, [fp, #-0x10]
    // 0x116feec: LoadField: r1 = r2->field_7
    //     0x116feec: ldur            w1, [x2, #7]
    // 0x116fef0: DecompressPointer r1
    //     0x116fef0: add             x1, x1, HEAP, lsl #32
    // 0x116fef4: cmp             w1, NULL
    // 0x116fef8: b.eq            #0x116ffac
    // 0x116fefc: LoadField: r4 = r1->field_7
    //     0x116fefc: ldur            x4, [x1, #7]
    // 0x116ff00: ldr             x1, [x4]
    // 0x116ff04: cbz             x1, #0x116ff8c
    // 0x116ff08: mov             x4, x1
    // 0x116ff0c: stur            x4, [fp, #-8]
    // 0x116ff10: r1 = <Never>
    //     0x116ff10: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x116ff14: r0 = Pointer()
    //     0x116ff14: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x116ff18: mov             x1, x0
    // 0x116ff1c: ldur            x0, [fp, #-8]
    // 0x116ff20: StoreField: r1->field_7 = r0
    //     0x116ff20: stur            x0, [x1, #7]
    // 0x116ff24: ldur            x2, [fp, #-0x10]
    // 0x116ff28: r0 = __addRetained$Method$FfiNative()
    //     0x116ff28: bl              #0x116ffb0  ; [dart:ui] _NativeSceneBuilder::__addRetained$Method$FfiNative
    // 0x116ff2c: ldur            x0, [fp, #-0x18]
    // 0x116ff30: r1 = false
    //     0x116ff30: add             x1, NULL, #0x30  ; false
    // 0x116ff34: b               #0x116ff68
    // 0x116ff38: ldur            x3, [fp, #-0x18]
    // 0x116ff3c: r0 = LoadClassIdInstr(r3)
    //     0x116ff3c: ldur            x0, [x3, #-1]
    //     0x116ff40: ubfx            x0, x0, #0xc, #0x14
    // 0x116ff44: mov             x1, x3
    // 0x116ff48: ldur            x2, [fp, #-0x20]
    // 0x116ff4c: r0 = GDT[cid_x0 + 0x391b]()
    //     0x116ff4c: mov             x17, #0x391b
    //     0x116ff50: add             lr, x0, x17
    //     0x116ff54: ldr             lr, [x21, lr, lsl #3]
    //     0x116ff58: blr             lr
    // 0x116ff5c: ldur            x0, [fp, #-0x18]
    // 0x116ff60: r1 = false
    //     0x116ff60: add             x1, NULL, #0x30  ; false
    // 0x116ff64: StoreField: r0->field_23 = r1
    //     0x116ff64: stur            w1, [x0, #0x23]
    // 0x116ff68: LoadField: r2 = r0->field_37
    //     0x116ff68: ldur            w2, [x0, #0x37]
    // 0x116ff6c: DecompressPointer r2
    //     0x116ff6c: add             x2, x2, HEAP, lsl #32
    // 0x116ff70: mov             x0, x2
    // 0x116ff74: ldur            x2, [fp, #-0x20]
    // 0x116ff78: b               #0x116feac
    // 0x116ff7c: r0 = Null
    //     0x116ff7c: mov             x0, NULL
    // 0x116ff80: LeaveFrame
    //     0x116ff80: mov             SP, fp
    //     0x116ff84: ldp             fp, lr, [SP], #0x10
    // 0x116ff88: ret
    //     0x116ff88: ret             
    // 0x116ff8c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x116ff8c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x116ff90: str             x16, [SP]
    // 0x116ff94: r0 = _throwNew()
    //     0x116ff94: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x116ff98: brk             #0
    // 0x116ff9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116ff9c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116ffa0: b               #0x116fea4
    // 0x116ffa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116ffa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116ffa8: b               #0x116febc
    // 0x116ffac: r0 = NullErrorSharedWithoutFPURegs()
    //     0x116ffac: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x11730d4, size: 0x30
    // 0x11730d4: EnterFrame
    //     0x11730d4: stp             fp, lr, [SP, #-0x10]!
    //     0x11730d8: mov             fp, SP
    // 0x11730dc: CheckStackOverflow
    //     0x11730dc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11730e0: cmp             SP, x16
    //     0x11730e4: b.ls            #0x11730fc
    // 0x11730e8: r0 = addChildrenToScene()
    //     0x11730e8: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x11730ec: r0 = Null
    //     0x11730ec: mov             x0, NULL
    // 0x11730f0: LeaveFrame
    //     0x11730f0: mov             SP, fp
    //     0x11730f4: ldp             fp, lr, [SP], #0x10
    // 0x11730f8: ret
    //     0x11730f8: ret             
    // 0x11730fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11730fc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1173100: b               #0x11730e8
  }
}

// class id: 4650, size: 0x5c, field offset: 0x48
class AnnotatedRegionLayer<X0> extends ContainerLayer {

  const X0 dyn:get:value(AnnotatedRegionLayer<X0>) {
    // ** addr: 0xa6860c, size: 0x28
    // 0xa6860c: ldr             x1, [SP]
    // 0xa68610: LoadField: r0 = r1->field_4b
    //     0xa68610: ldur            w0, [x1, #0x4b]
    // 0xa68614: DecompressPointer r0
    //     0xa68614: add             x0, x0, HEAP, lsl #32
    // 0xa68618: ret
    //     0xa68618: ret             
  }
  bool findAnnotations<Y0 extends Object>(AnnotatedRegionLayer<X0>, AnnotationResult<Y0>, Offset) {
    // ** addr: 0x112ca4c, size: 0x2c8
    // 0x112ca4c: EnterFrame
    //     0x112ca4c: stp             fp, lr, [SP, #-0x10]!
    //     0x112ca50: mov             fp, SP
    // 0x112ca54: AllocStack(0x58)
    //     0x112ca54: sub             SP, SP, #0x58
    // 0x112ca58: SetupParameters()
    //     0x112ca58: ldur            w0, [x4, #0xf]
    //     0x112ca5c: cbnz            w0, #0x112ca68
    //     0x112ca60: mov             x1, NULL
    //     0x112ca64: b               #0x112ca78
    //     0x112ca68: ldur            w1, [x4, #0x17]
    //     0x112ca6c: add             x2, fp, w1, sxtw #2
    //     0x112ca70: ldr             x2, [x2, #0x10]
    //     0x112ca74: mov             x1, x2
    // 0x112ca78: CheckStackOverflow
    //     0x112ca78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112ca7c: cmp             SP, x16
    //     0x112ca80: b.ls            #0x112cd0c
    // 0x112ca84: cbnz            w0, #0x112ca8c
    // 0x112ca88: r1 = <Object>
    //     0x112ca88: ldr             x1, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112ca8c: ldr             x0, [fp, #0x18]
    // 0x112ca90: stur            x1, [fp, #-8]
    // 0x112ca94: ldr             x16, [fp, #0x20]
    // 0x112ca98: stp             x16, x1, [SP, #0x10]
    // 0x112ca9c: ldr             x16, [fp, #0x10]
    // 0x112caa0: stp             x16, x0, [SP]
    // 0x112caa4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112caa4: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112caa8: r0 = findAnnotations()
    //     0x112caa8: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112caac: mov             x3, x0
    // 0x112cab0: ldr             x0, [fp, #0x18]
    // 0x112cab4: stur            x3, [fp, #-0x20]
    // 0x112cab8: LoadField: r4 = r0->field_b
    //     0x112cab8: ldur            w4, [x0, #0xb]
    // 0x112cabc: DecompressPointer r4
    //     0x112cabc: add             x4, x4, HEAP, lsl #32
    // 0x112cac0: stur            x4, [fp, #-0x18]
    // 0x112cac4: LoadField: r1 = r4->field_b
    //     0x112cac4: ldur            w1, [x4, #0xb]
    // 0x112cac8: cbz             w1, #0x112cadc
    // 0x112cacc: mov             x0, x3
    // 0x112cad0: LeaveFrame
    //     0x112cad0: mov             SP, fp
    //     0x112cad4: ldp             fp, lr, [SP], #0x10
    // 0x112cad8: ret
    //     0x112cad8: ret             
    // 0x112cadc: ldr             x5, [fp, #0x20]
    // 0x112cae0: LoadField: r6 = r5->field_53
    //     0x112cae0: ldur            w6, [x5, #0x53]
    // 0x112cae4: DecompressPointer r6
    //     0x112cae4: add             x6, x6, HEAP, lsl #32
    // 0x112cae8: stur            x6, [fp, #-0x10]
    // 0x112caec: LoadField: r2 = r5->field_4f
    //     0x112caec: ldur            w2, [x5, #0x4f]
    // 0x112caf0: DecompressPointer r2
    //     0x112caf0: add             x2, x2, HEAP, lsl #32
    // 0x112caf4: mov             x1, x6
    // 0x112caf8: r0 = &()
    //     0x112caf8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0x112cafc: mov             x1, x0
    // 0x112cb00: ldr             x2, [fp, #0x10]
    // 0x112cb04: r0 = contains()
    //     0x112cb04: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0x112cb08: eor             x1, x0, #0x10
    // 0x112cb0c: tbnz            w1, #4, #0x112cb20
    // 0x112cb10: ldur            x0, [fp, #-0x20]
    // 0x112cb14: LeaveFrame
    //     0x112cb14: mov             SP, fp
    //     0x112cb18: ldp             fp, lr, [SP], #0x10
    // 0x112cb1c: ret
    //     0x112cb1c: ret             
    // 0x112cb20: ldr             x0, [fp, #0x20]
    // 0x112cb24: LoadField: r2 = r0->field_47
    //     0x112cb24: ldur            w2, [x0, #0x47]
    // 0x112cb28: DecompressPointer r2
    //     0x112cb28: add             x2, x2, HEAP, lsl #32
    // 0x112cb2c: r1 = Null
    //     0x112cb2c: mov             x1, NULL
    // 0x112cb30: r3 = X0
    //     0x112cb30: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e628] TypeParameter: X0
    //     0x112cb34: ldr             x3, [x3, #0x628]
    // 0x112cb38: r30 = InstantiateTypeNonNullableClassTypeParameterStub
    //     0x112cb38: add             lr, PP, #0x12, lsl #12  ; [pp+0x12e80] Stub: InstantiateTypeNonNullableClassTypeParameter (0x7c1258)
    //     0x112cb3c: ldr             lr, [lr, #0xe80]
    // 0x112cb40: LoadField: r30 = r30->field_7
    //     0x112cb40: ldur            lr, [lr, #7]
    // 0x112cb44: blr             lr
    // 0x112cb48: ldur            x1, [fp, #-8]
    // 0x112cb4c: r2 = Null
    //     0x112cb4c: mov             x2, NULL
    // 0x112cb50: stur            x0, [fp, #-0x28]
    // 0x112cb54: r3 = Y0
    //     0x112cb54: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e630] TypeParameter: Y0
    //     0x112cb58: ldr             x3, [x3, #0x630]
    // 0x112cb5c: r30 = InstantiateTypeNonNullableFunctionTypeParameterStub
    //     0x112cb5c: ldr             lr, [PP, #0x1fe8]  ; [pp+0x1fe8] Stub: InstantiateTypeNonNullableFunctionTypeParameter (0x7c1180)
    // 0x112cb60: LoadField: r30 = r30->field_7
    //     0x112cb60: ldur            lr, [lr, #7]
    // 0x112cb64: blr             lr
    // 0x112cb68: mov             x1, x0
    // 0x112cb6c: ldur            x0, [fp, #-0x28]
    // 0x112cb70: r2 = LoadClassIdInstr(r0)
    //     0x112cb70: ldur            x2, [x0, #-1]
    //     0x112cb74: ubfx            x2, x2, #0xc, #0x14
    // 0x112cb78: stp             x1, x0, [SP]
    // 0x112cb7c: mov             x0, x2
    // 0x112cb80: mov             lr, x0
    // 0x112cb84: ldr             lr, [x21, lr, lsl #3]
    // 0x112cb88: blr             lr
    // 0x112cb8c: tbnz            w0, #4, #0x112ccfc
    // 0x112cb90: ldur            x0, [fp, #-0x20]
    // 0x112cb94: tbnz            w0, #4, #0x112cba0
    // 0x112cb98: r5 = true
    //     0x112cb98: add             x5, NULL, #0x20  ; true
    // 0x112cb9c: b               #0x112cba4
    // 0x112cba0: r5 = false
    //     0x112cba0: add             x5, NULL, #0x30  ; false
    // 0x112cba4: ldr             x0, [fp, #0x20]
    // 0x112cba8: ldr             x3, [fp, #0x18]
    // 0x112cbac: ldur            x4, [fp, #-0x18]
    // 0x112cbb0: stur            x5, [fp, #-0x30]
    // 0x112cbb4: LoadField: r6 = r0->field_4b
    //     0x112cbb4: ldur            w6, [x0, #0x4b]
    // 0x112cbb8: DecompressPointer r6
    //     0x112cbb8: add             x6, x6, HEAP, lsl #32
    // 0x112cbbc: mov             x0, x6
    // 0x112cbc0: ldur            x1, [fp, #-8]
    // 0x112cbc4: stur            x6, [fp, #-0x28]
    // 0x112cbc8: r2 = Null
    //     0x112cbc8: mov             x2, NULL
    // 0x112cbcc: cmp             w1, NULL
    // 0x112cbd0: b.eq            #0x112cbf4
    // 0x112cbd4: ArrayLoad: r4 = r1[0]  ; List_4
    //     0x112cbd4: ldur            w4, [x1, #0x17]
    // 0x112cbd8: DecompressPointer r4
    //     0x112cbd8: add             x4, x4, HEAP, lsl #32
    // 0x112cbdc: r8 = Y0
    //     0x112cbdc: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e630] TypeParameter: Y0
    //     0x112cbe0: ldr             x8, [x8, #0x630]
    // 0x112cbe4: LoadField: r9 = r4->field_7
    //     0x112cbe4: ldur            x9, [x4, #7]
    // 0x112cbe8: r3 = Null
    //     0x112cbe8: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e638] Null
    //     0x112cbec: ldr             x3, [x3, #0x638]
    // 0x112cbf0: blr             x9
    // 0x112cbf4: ldr             x1, [fp, #0x10]
    // 0x112cbf8: ldur            x2, [fp, #-0x10]
    // 0x112cbfc: r0 = -()
    //     0x112cbfc: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x112cc00: ldur            x1, [fp, #-8]
    // 0x112cc04: r0 = AnnotationEntry()
    //     0x112cc04: bl              #0x112cd14  ; AllocateAnnotationEntryStub -> AnnotationEntry<X0> (size=0x10)
    // 0x112cc08: mov             x3, x0
    // 0x112cc0c: ldur            x0, [fp, #-0x28]
    // 0x112cc10: stur            x3, [fp, #-8]
    // 0x112cc14: StoreField: r3->field_b = r0
    //     0x112cc14: stur            w0, [x3, #0xb]
    // 0x112cc18: ldr             x0, [fp, #0x18]
    // 0x112cc1c: LoadField: r2 = r0->field_7
    //     0x112cc1c: ldur            w2, [x0, #7]
    // 0x112cc20: DecompressPointer r2
    //     0x112cc20: add             x2, x2, HEAP, lsl #32
    // 0x112cc24: mov             x0, x3
    // 0x112cc28: r1 = Null
    //     0x112cc28: mov             x1, NULL
    // 0x112cc2c: r8 = AnnotationEntry<X0>
    //     0x112cc2c: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e648] Type: AnnotationEntry<X0>
    //     0x112cc30: ldr             x8, [x8, #0x648]
    // 0x112cc34: LoadField: r9 = r8->field_7
    //     0x112cc34: ldur            x9, [x8, #7]
    // 0x112cc38: r3 = Null
    //     0x112cc38: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e650] Null
    //     0x112cc3c: ldr             x3, [x3, #0x650]
    // 0x112cc40: blr             x9
    // 0x112cc44: ldur            x3, [fp, #-0x18]
    // 0x112cc48: LoadField: r2 = r3->field_7
    //     0x112cc48: ldur            w2, [x3, #7]
    // 0x112cc4c: DecompressPointer r2
    //     0x112cc4c: add             x2, x2, HEAP, lsl #32
    // 0x112cc50: ldur            x0, [fp, #-8]
    // 0x112cc54: r1 = Null
    //     0x112cc54: mov             x1, NULL
    // 0x112cc58: cmp             w2, NULL
    // 0x112cc5c: b.eq            #0x112cc7c
    // 0x112cc60: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x112cc60: ldur            w4, [x2, #0x17]
    // 0x112cc64: DecompressPointer r4
    //     0x112cc64: add             x4, x4, HEAP, lsl #32
    // 0x112cc68: r8 = X0
    //     0x112cc68: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x112cc6c: LoadField: r9 = r4->field_7
    //     0x112cc6c: ldur            x9, [x4, #7]
    // 0x112cc70: r3 = Null
    //     0x112cc70: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e660] Null
    //     0x112cc74: ldr             x3, [x3, #0x660]
    // 0x112cc78: blr             x9
    // 0x112cc7c: ldur            x0, [fp, #-0x18]
    // 0x112cc80: LoadField: r1 = r0->field_b
    //     0x112cc80: ldur            w1, [x0, #0xb]
    // 0x112cc84: LoadField: r2 = r0->field_f
    //     0x112cc84: ldur            w2, [x0, #0xf]
    // 0x112cc88: DecompressPointer r2
    //     0x112cc88: add             x2, x2, HEAP, lsl #32
    // 0x112cc8c: LoadField: r3 = r2->field_b
    //     0x112cc8c: ldur            w3, [x2, #0xb]
    // 0x112cc90: r2 = LoadInt32Instr(r1)
    //     0x112cc90: sbfx            x2, x1, #1, #0x1f
    // 0x112cc94: stur            x2, [fp, #-0x38]
    // 0x112cc98: r1 = LoadInt32Instr(r3)
    //     0x112cc98: sbfx            x1, x3, #1, #0x1f
    // 0x112cc9c: cmp             x2, x1
    // 0x112cca0: b.ne            #0x112ccac
    // 0x112cca4: mov             x1, x0
    // 0x112cca8: r0 = _growToNextCapacity()
    //     0x112cca8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x112ccac: ldur            x2, [fp, #-0x18]
    // 0x112ccb0: ldur            x3, [fp, #-0x38]
    // 0x112ccb4: add             x4, x3, #1
    // 0x112ccb8: lsl             x5, x4, #1
    // 0x112ccbc: StoreField: r2->field_b = r5
    //     0x112ccbc: stur            w5, [x2, #0xb]
    // 0x112ccc0: LoadField: r1 = r2->field_f
    //     0x112ccc0: ldur            w1, [x2, #0xf]
    // 0x112ccc4: DecompressPointer r1
    //     0x112ccc4: add             x1, x1, HEAP, lsl #32
    // 0x112ccc8: ldur            x0, [fp, #-8]
    // 0x112cccc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x112cccc: add             x25, x1, x3, lsl #2
    //     0x112ccd0: add             x25, x25, #0xf
    //     0x112ccd4: str             w0, [x25]
    //     0x112ccd8: tbz             w0, #0, #0x112ccf4
    //     0x112ccdc: ldurb           w16, [x1, #-1]
    //     0x112cce0: ldurb           w17, [x0, #-1]
    //     0x112cce4: and             x16, x17, x16, lsr #2
    //     0x112cce8: tst             x16, HEAP, lsr #32
    //     0x112ccec: b.eq            #0x112ccf4
    //     0x112ccf0: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x112ccf4: ldur            x0, [fp, #-0x30]
    // 0x112ccf8: b               #0x112cd00
    // 0x112ccfc: ldur            x0, [fp, #-0x20]
    // 0x112cd00: LeaveFrame
    //     0x112cd00: mov             SP, fp
    //     0x112cd04: ldp             fp, lr, [SP], #0x10
    // 0x112cd08: ret
    //     0x112cd08: ret             
    // 0x112cd0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112cd0c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112cd10: b               #0x112ca84
  }
}

// class id: 4651, size: 0x68, field offset: 0x48
class FollowerLayer extends ContainerLayer {

  _ getLastTransform(/* No info */) {
    // ** addr: 0xbf140c, size: 0xb4
    // 0xbf140c: EnterFrame
    //     0xbf140c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1410: mov             fp, SP
    // 0xbf1414: AllocStack(0x10)
    //     0xbf1414: sub             SP, SP, #0x10
    // 0xbf1418: SetupParameters(FollowerLayer this /* r1 => r0, fp-0x8 */)
    //     0xbf1418: mov             x0, x1
    //     0xbf141c: stur            x1, [fp, #-8]
    // 0xbf1420: CheckStackOverflow
    //     0xbf1420: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1424: cmp             SP, x16
    //     0xbf1428: b.ls            #0xbf14b0
    // 0xbf142c: LoadField: r1 = r0->field_5b
    //     0xbf142c: ldur            w1, [x0, #0x5b]
    // 0xbf1430: DecompressPointer r1
    //     0xbf1430: add             x1, x1, HEAP, lsl #32
    // 0xbf1434: cmp             w1, NULL
    // 0xbf1438: b.ne            #0xbf144c
    // 0xbf143c: r0 = Null
    //     0xbf143c: mov             x0, NULL
    // 0xbf1440: LeaveFrame
    //     0xbf1440: mov             SP, fp
    //     0xbf1444: ldp             fp, lr, [SP], #0x10
    // 0xbf1448: ret
    //     0xbf1448: ret             
    // 0xbf144c: LoadField: r1 = r0->field_57
    //     0xbf144c: ldur            w1, [x0, #0x57]
    // 0xbf1450: DecompressPointer r1
    //     0xbf1450: add             x1, x1, HEAP, lsl #32
    // 0xbf1454: cmp             w1, NULL
    // 0xbf1458: b.eq            #0xbf14b8
    // 0xbf145c: LoadField: d0 = r1->field_7
    //     0xbf145c: ldur            d0, [x1, #7]
    // 0xbf1460: fneg            d1, d0
    // 0xbf1464: LoadField: d0 = r1->field_f
    //     0xbf1464: ldur            d0, [x1, #0xf]
    // 0xbf1468: fneg            d2, d0
    // 0xbf146c: mov             v0.16b, v1.16b
    // 0xbf1470: mov             v1.16b, v2.16b
    // 0xbf1474: r1 = Null
    //     0xbf1474: mov             x1, NULL
    // 0xbf1478: r0 = Matrix4.translationValues()
    //     0xbf1478: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0xbf147c: mov             x3, x0
    // 0xbf1480: ldur            x0, [fp, #-8]
    // 0xbf1484: stur            x3, [fp, #-0x10]
    // 0xbf1488: LoadField: r2 = r0->field_5b
    //     0xbf1488: ldur            w2, [x0, #0x5b]
    // 0xbf148c: DecompressPointer r2
    //     0xbf148c: add             x2, x2, HEAP, lsl #32
    // 0xbf1490: cmp             w2, NULL
    // 0xbf1494: b.eq            #0xbf14bc
    // 0xbf1498: mov             x1, x3
    // 0xbf149c: r0 = multiply()
    //     0xbf149c: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0xbf14a0: ldur            x0, [fp, #-0x10]
    // 0xbf14a4: LeaveFrame
    //     0xbf14a4: mov             SP, fp
    //     0xbf14a8: ldp             fp, lr, [SP], #0x10
    // 0xbf14ac: ret
    //     0xbf14ac: ret             
    // 0xbf14b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf14b0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf14b4: b               #0xbf142c
    // 0xbf14b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf14b8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf14bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf14bc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0x112c5dc, size: 0x110
    // 0x112c5dc: EnterFrame
    //     0x112c5dc: stp             fp, lr, [SP, #-0x10]!
    //     0x112c5e0: mov             fp, SP
    // 0x112c5e4: AllocStack(0x28)
    //     0x112c5e4: sub             SP, SP, #0x28
    // 0x112c5e8: SetupParameters()
    //     0x112c5e8: ldur            w0, [x4, #0xf]
    //     0x112c5ec: cbnz            w0, #0x112c5f8
    //     0x112c5f0: mov             x1, NULL
    //     0x112c5f4: b               #0x112c608
    //     0x112c5f8: ldur            w1, [x4, #0x17]
    //     0x112c5fc: add             x2, fp, w1, sxtw #2
    //     0x112c600: ldr             x2, [x2, #0x10]
    //     0x112c604: mov             x1, x2
    // 0x112c608: CheckStackOverflow
    //     0x112c608: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c60c: cmp             SP, x16
    //     0x112c610: b.ls            #0x112c6e4
    // 0x112c614: cbnz            w0, #0x112c620
    // 0x112c618: r3 = <Object>
    //     0x112c618: ldr             x3, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112c61c: b               #0x112c624
    // 0x112c620: mov             x3, x1
    // 0x112c624: ldr             x0, [fp, #0x20]
    // 0x112c628: stur            x3, [fp, #-8]
    // 0x112c62c: LoadField: r1 = r0->field_47
    //     0x112c62c: ldur            w1, [x0, #0x47]
    // 0x112c630: DecompressPointer r1
    //     0x112c630: add             x1, x1, HEAP, lsl #32
    // 0x112c634: LoadField: r2 = r1->field_7
    //     0x112c634: ldur            w2, [x1, #7]
    // 0x112c638: DecompressPointer r2
    //     0x112c638: add             x2, x2, HEAP, lsl #32
    // 0x112c63c: cmp             w2, NULL
    // 0x112c640: b.ne            #0x112c698
    // 0x112c644: LoadField: r1 = r0->field_4b
    //     0x112c644: ldur            w1, [x0, #0x4b]
    // 0x112c648: DecompressPointer r1
    //     0x112c648: add             x1, x1, HEAP, lsl #32
    // 0x112c64c: tbnz            w1, #4, #0x112c688
    // 0x112c650: LoadField: r2 = r0->field_4f
    //     0x112c650: ldur            w2, [x0, #0x4f]
    // 0x112c654: DecompressPointer r2
    //     0x112c654: add             x2, x2, HEAP, lsl #32
    // 0x112c658: ldr             x1, [fp, #0x10]
    // 0x112c65c: r0 = -()
    //     0x112c65c: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x112c660: ldur            x16, [fp, #-8]
    // 0x112c664: ldr             lr, [fp, #0x20]
    // 0x112c668: stp             lr, x16, [SP, #0x10]
    // 0x112c66c: ldr             x16, [fp, #0x18]
    // 0x112c670: stp             x0, x16, [SP]
    // 0x112c674: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c674: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c678: r0 = findAnnotations()
    //     0x112c678: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112c67c: LeaveFrame
    //     0x112c67c: mov             SP, fp
    //     0x112c680: ldp             fp, lr, [SP], #0x10
    // 0x112c684: ret
    //     0x112c684: ret             
    // 0x112c688: r0 = false
    //     0x112c688: add             x0, NULL, #0x30  ; false
    // 0x112c68c: LeaveFrame
    //     0x112c68c: mov             SP, fp
    //     0x112c690: ldp             fp, lr, [SP], #0x10
    // 0x112c694: ret
    //     0x112c694: ret             
    // 0x112c698: ldr             x1, [fp, #0x20]
    // 0x112c69c: ldr             x2, [fp, #0x10]
    // 0x112c6a0: r0 = _transformOffset()
    //     0x112c6a0: bl              #0x112c6ec  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_transformOffset
    // 0x112c6a4: cmp             w0, NULL
    // 0x112c6a8: b.ne            #0x112c6bc
    // 0x112c6ac: r0 = false
    //     0x112c6ac: add             x0, NULL, #0x30  ; false
    // 0x112c6b0: LeaveFrame
    //     0x112c6b0: mov             SP, fp
    //     0x112c6b4: ldp             fp, lr, [SP], #0x10
    // 0x112c6b8: ret
    //     0x112c6b8: ret             
    // 0x112c6bc: ldur            x16, [fp, #-8]
    // 0x112c6c0: ldr             lr, [fp, #0x20]
    // 0x112c6c4: stp             lr, x16, [SP, #0x10]
    // 0x112c6c8: ldr             x16, [fp, #0x18]
    // 0x112c6cc: stp             x0, x16, [SP]
    // 0x112c6d0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c6d0: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c6d4: r0 = findAnnotations()
    //     0x112c6d4: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112c6d8: LeaveFrame
    //     0x112c6d8: mov             SP, fp
    //     0x112c6dc: ldp             fp, lr, [SP], #0x10
    // 0x112c6e0: ret
    //     0x112c6e0: ret             
    // 0x112c6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c6e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c6e8: b               #0x112c614
  }
  _ _transformOffset(/* No info */) {
    // ** addr: 0x112c6ec, size: 0x17c
    // 0x112c6ec: EnterFrame
    //     0x112c6ec: stp             fp, lr, [SP, #-0x10]!
    //     0x112c6f0: mov             fp, SP
    // 0x112c6f4: AllocStack(0x28)
    //     0x112c6f4: sub             SP, SP, #0x28
    // 0x112c6f8: SetupParameters(FollowerLayer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x112c6f8: mov             x0, x1
    //     0x112c6fc: stur            x1, [fp, #-8]
    //     0x112c700: stur            x2, [fp, #-0x10]
    // 0x112c704: CheckStackOverflow
    //     0x112c704: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c708: cmp             SP, x16
    //     0x112c70c: b.ls            #0x112c854
    // 0x112c710: LoadField: r1 = r0->field_63
    //     0x112c710: ldur            w1, [x0, #0x63]
    // 0x112c714: DecompressPointer r1
    //     0x112c714: add             x1, x1, HEAP, lsl #32
    // 0x112c718: tbnz            w1, #4, #0x112c760
    // 0x112c71c: mov             x1, x0
    // 0x112c720: r0 = getLastTransform()
    //     0x112c720: bl              #0xbf140c  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::getLastTransform
    // 0x112c724: cmp             w0, NULL
    // 0x112c728: b.eq            #0x112c85c
    // 0x112c72c: mov             x1, x0
    // 0x112c730: r0 = tryInvert()
    //     0x112c730: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x112c734: ldur            x1, [fp, #-8]
    // 0x112c738: StoreField: r1->field_5f = r0
    //     0x112c738: stur            w0, [x1, #0x5f]
    //     0x112c73c: ldurb           w16, [x1, #-1]
    //     0x112c740: ldurb           w17, [x0, #-1]
    //     0x112c744: and             x16, x17, x16, lsr #2
    //     0x112c748: tst             x16, HEAP, lsr #32
    //     0x112c74c: b.eq            #0x112c754
    //     0x112c750: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x112c754: r0 = false
    //     0x112c754: add             x0, NULL, #0x30  ; false
    // 0x112c758: StoreField: r1->field_63 = r0
    //     0x112c758: stur            w0, [x1, #0x63]
    // 0x112c75c: b               #0x112c764
    // 0x112c760: mov             x1, x0
    // 0x112c764: LoadField: r0 = r1->field_5f
    //     0x112c764: ldur            w0, [x1, #0x5f]
    // 0x112c768: DecompressPointer r0
    //     0x112c768: add             x0, x0, HEAP, lsl #32
    // 0x112c76c: stur            x0, [fp, #-0x18]
    // 0x112c770: cmp             w0, NULL
    // 0x112c774: b.ne            #0x112c788
    // 0x112c778: r0 = Null
    //     0x112c778: mov             x0, NULL
    // 0x112c77c: LeaveFrame
    //     0x112c77c: mov             SP, fp
    //     0x112c780: ldp             fp, lr, [SP], #0x10
    // 0x112c784: ret
    //     0x112c784: ret             
    // 0x112c788: ldur            x2, [fp, #-0x10]
    // 0x112c78c: LoadField: d0 = r2->field_7
    //     0x112c78c: ldur            d0, [x2, #7]
    // 0x112c790: stur            d0, [fp, #-0x28]
    // 0x112c794: LoadField: d1 = r2->field_f
    //     0x112c794: ldur            d1, [x2, #0xf]
    // 0x112c798: stur            d1, [fp, #-0x20]
    // 0x112c79c: r0 = Vector4()
    //     0x112c79c: bl              #0x10e95d0  ; AllocateVector4Stub -> Vector4 (size=0xc)
    // 0x112c7a0: r4 = 8
    //     0x112c7a0: mov             x4, #8
    // 0x112c7a4: stur            x0, [fp, #-0x10]
    // 0x112c7a8: r0 = AllocateFloat64Array()
    //     0x112c7a8: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x112c7ac: ldur            x2, [fp, #-0x10]
    // 0x112c7b0: StoreField: r2->field_7 = r0
    //     0x112c7b0: stur            w0, [x2, #7]
    // 0x112c7b4: d0 = 1.000000
    //     0x112c7b4: fmov            d0, #1.00000000
    // 0x112c7b8: StoreField: r0->field_2f = d0
    //     0x112c7b8: stur            d0, [x0, #0x2f]
    // 0x112c7bc: StoreField: r0->field_27 = rZR
    //     0x112c7bc: stur            xzr, [x0, #0x27]
    // 0x112c7c0: ldur            d0, [fp, #-0x20]
    // 0x112c7c4: StoreField: r0->field_1f = d0
    //     0x112c7c4: stur            d0, [x0, #0x1f]
    // 0x112c7c8: ldur            d0, [fp, #-0x28]
    // 0x112c7cc: ArrayStore: r0[0] = d0  ; List_8
    //     0x112c7cc: stur            d0, [x0, #0x17]
    // 0x112c7d0: ldur            x1, [fp, #-0x18]
    // 0x112c7d4: r0 = transform()
    //     0x112c7d4: bl              #0x112c868  ; [package:vector_math/vector_math_64.dart] Matrix4::transform
    // 0x112c7d8: LoadField: r2 = r0->field_7
    //     0x112c7d8: ldur            w2, [x0, #7]
    // 0x112c7dc: DecompressPointer r2
    //     0x112c7dc: add             x2, x2, HEAP, lsl #32
    // 0x112c7e0: LoadField: r0 = r2->field_13
    //     0x112c7e0: ldur            w0, [x2, #0x13]
    // 0x112c7e4: r3 = LoadInt32Instr(r0)
    //     0x112c7e4: sbfx            x3, x0, #1, #0x1f
    // 0x112c7e8: mov             x0, x3
    // 0x112c7ec: r1 = 0
    //     0x112c7ec: mov             x1, #0
    // 0x112c7f0: cmp             x1, x0
    // 0x112c7f4: b.hs            #0x112c860
    // 0x112c7f8: ArrayLoad: d0 = r2[0]  ; List_8
    //     0x112c7f8: ldur            d0, [x2, #0x17]
    // 0x112c7fc: ldur            x0, [fp, #-8]
    // 0x112c800: LoadField: r4 = r0->field_53
    //     0x112c800: ldur            w4, [x0, #0x53]
    // 0x112c804: DecompressPointer r4
    //     0x112c804: add             x4, x4, HEAP, lsl #32
    // 0x112c808: LoadField: d1 = r4->field_7
    //     0x112c808: ldur            d1, [x4, #7]
    // 0x112c80c: fsub            d2, d0, d1
    // 0x112c810: mov             x0, x3
    // 0x112c814: stur            d2, [fp, #-0x28]
    // 0x112c818: r1 = 1
    //     0x112c818: mov             x1, #1
    // 0x112c81c: cmp             x1, x0
    // 0x112c820: b.hs            #0x112c864
    // 0x112c824: LoadField: d0 = r2->field_1f
    //     0x112c824: ldur            d0, [x2, #0x1f]
    // 0x112c828: LoadField: d1 = r4->field_f
    //     0x112c828: ldur            d1, [x4, #0xf]
    // 0x112c82c: fsub            d3, d0, d1
    // 0x112c830: stur            d3, [fp, #-0x20]
    // 0x112c834: r0 = Offset()
    //     0x112c834: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x112c838: ldur            d0, [fp, #-0x28]
    // 0x112c83c: StoreField: r0->field_7 = d0
    //     0x112c83c: stur            d0, [x0, #7]
    // 0x112c840: ldur            d0, [fp, #-0x20]
    // 0x112c844: StoreField: r0->field_f = d0
    //     0x112c844: stur            d0, [x0, #0xf]
    // 0x112c848: LeaveFrame
    //     0x112c848: mov             SP, fp
    //     0x112c84c: ldp             fp, lr, [SP], #0x10
    // 0x112c850: ret
    //     0x112c850: ret             
    // 0x112c854: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c854: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c858: b               #0x112c710
    // 0x112c85c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x112c85c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x112c860: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x112c860: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x112c864: r0 = RangeErrorSharedWithFPURegs()
    //     0x112c864: bl              #0x13dfff4  ; RangeErrorSharedWithFPURegsStub
  }
  _ applyTransform(/* No info */) {
    // ** addr: 0x115c7d0, size: 0x78
    // 0x115c7d0: EnterFrame
    //     0x115c7d0: stp             fp, lr, [SP, #-0x10]!
    //     0x115c7d4: mov             fp, SP
    // 0x115c7d8: AllocStack(0x8)
    //     0x115c7d8: sub             SP, SP, #8
    // 0x115c7dc: SetupParameters(dynamic _ /* r2 => r0, fp-0x8 */)
    //     0x115c7dc: mov             x0, x2
    //     0x115c7e0: stur            x2, [fp, #-8]
    // 0x115c7e4: CheckStackOverflow
    //     0x115c7e4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115c7e8: cmp             SP, x16
    //     0x115c7ec: b.ls            #0x115c840
    // 0x115c7f0: LoadField: r2 = r1->field_5b
    //     0x115c7f0: ldur            w2, [x1, #0x5b]
    // 0x115c7f4: DecompressPointer r2
    //     0x115c7f4: add             x2, x2, HEAP, lsl #32
    // 0x115c7f8: cmp             w2, NULL
    // 0x115c7fc: b.eq            #0x115c80c
    // 0x115c800: mov             x1, x0
    // 0x115c804: r0 = multiply()
    //     0x115c804: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x115c808: b               #0x115c830
    // 0x115c80c: LoadField: r2 = r1->field_4f
    //     0x115c80c: ldur            w2, [x1, #0x4f]
    // 0x115c810: DecompressPointer r2
    //     0x115c810: add             x2, x2, HEAP, lsl #32
    // 0x115c814: LoadField: d0 = r2->field_7
    //     0x115c814: ldur            d0, [x2, #7]
    // 0x115c818: LoadField: d1 = r2->field_f
    //     0x115c818: ldur            d1, [x2, #0xf]
    // 0x115c81c: r1 = Null
    //     0x115c81c: mov             x1, NULL
    // 0x115c820: r0 = Matrix4.translationValues()
    //     0x115c820: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0x115c824: ldur            x1, [fp, #-8]
    // 0x115c828: mov             x2, x0
    // 0x115c82c: r0 = multiply()
    //     0x115c82c: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x115c830: r0 = Null
    //     0x115c830: mov             x0, NULL
    // 0x115c834: LeaveFrame
    //     0x115c834: mov             SP, fp
    //     0x115c838: ldp             fp, lr, [SP], #0x10
    // 0x115c83c: ret
    //     0x115c83c: ret             
    // 0x115c840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115c840: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115c844: b               #0x115c7f0
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x117280c, size: 0x218
    // 0x117280c: EnterFrame
    //     0x117280c: stp             fp, lr, [SP, #-0x10]!
    //     0x1172810: mov             fp, SP
    // 0x1172814: AllocStack(0x28)
    //     0x1172814: sub             SP, SP, #0x28
    // 0x1172818: SetupParameters(FollowerLayer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x1172818: mov             x0, x2
    //     0x117281c: stur            x2, [fp, #-0x10]
    //     0x1172820: mov             x2, x1
    //     0x1172824: stur            x1, [fp, #-8]
    // 0x1172828: CheckStackOverflow
    //     0x1172828: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x117282c: cmp             SP, x16
    //     0x1172830: b.ls            #0x1172a1c
    // 0x1172834: LoadField: r1 = r2->field_47
    //     0x1172834: ldur            w1, [x2, #0x47]
    // 0x1172838: DecompressPointer r1
    //     0x1172838: add             x1, x1, HEAP, lsl #32
    // 0x117283c: LoadField: r3 = r1->field_7
    //     0x117283c: ldur            w3, [x1, #7]
    // 0x1172840: DecompressPointer r3
    //     0x1172840: add             x3, x3, HEAP, lsl #32
    // 0x1172844: cmp             w3, NULL
    // 0x1172848: b.ne            #0x117288c
    // 0x117284c: LoadField: r1 = r2->field_4b
    //     0x117284c: ldur            w1, [x2, #0x4b]
    // 0x1172850: DecompressPointer r1
    //     0x1172850: add             x1, x1, HEAP, lsl #32
    // 0x1172854: tbz             w1, #4, #0x1172884
    // 0x1172858: r3 = true
    //     0x1172858: add             x3, NULL, #0x20  ; true
    // 0x117285c: StoreField: r2->field_5b = rNULL
    //     0x117285c: stur            NULL, [x2, #0x5b]
    // 0x1172860: StoreField: r2->field_57 = rNULL
    //     0x1172860: stur            NULL, [x2, #0x57]
    // 0x1172864: StoreField: r2->field_63 = r3
    //     0x1172864: stur            w3, [x2, #0x63]
    // 0x1172868: mov             x1, x2
    // 0x117286c: r2 = Null
    //     0x117286c: mov             x2, NULL
    // 0x1172870: r0 = engineLayer=()
    //     0x1172870: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1172874: r0 = Null
    //     0x1172874: mov             x0, NULL
    // 0x1172878: LeaveFrame
    //     0x1172878: mov             SP, fp
    //     0x117287c: ldp             fp, lr, [SP], #0x10
    // 0x1172880: ret
    //     0x1172880: ret             
    // 0x1172884: r3 = true
    //     0x1172884: add             x3, NULL, #0x20  ; true
    // 0x1172888: b               #0x1172890
    // 0x117288c: r3 = true
    //     0x117288c: add             x3, NULL, #0x20  ; true
    // 0x1172890: mov             x1, x2
    // 0x1172894: r0 = _establishTransform()
    //     0x1172894: bl              #0x1172a24  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_establishTransform
    // 0x1172898: ldur            x3, [fp, #-8]
    // 0x117289c: LoadField: r1 = r3->field_5b
    //     0x117289c: ldur            w1, [x3, #0x5b]
    // 0x11728a0: DecompressPointer r1
    //     0x11728a0: add             x1, x1, HEAP, lsl #32
    // 0x11728a4: cmp             w1, NULL
    // 0x11728a8: b.eq            #0x1172958
    // 0x11728ac: LoadField: r0 = r3->field_4f
    //     0x11728ac: ldur            w0, [x3, #0x4f]
    // 0x11728b0: DecompressPointer r0
    //     0x11728b0: add             x0, x0, HEAP, lsl #32
    // 0x11728b4: StoreField: r3->field_57 = r0
    //     0x11728b4: stur            w0, [x3, #0x57]
    //     0x11728b8: ldurb           w16, [x3, #-1]
    //     0x11728bc: ldurb           w17, [x0, #-1]
    //     0x11728c0: and             x16, x17, x16, lsr #2
    //     0x11728c4: tst             x16, HEAP, lsr #32
    //     0x11728c8: b.eq            #0x11728d0
    //     0x11728cc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x11728d0: LoadField: r4 = r1->field_7
    //     0x11728d0: ldur            w4, [x1, #7]
    // 0x11728d4: DecompressPointer r4
    //     0x11728d4: add             x4, x4, HEAP, lsl #32
    // 0x11728d8: stur            x4, [fp, #-0x20]
    // 0x11728dc: LoadField: r5 = r3->field_27
    //     0x11728dc: ldur            w5, [x3, #0x27]
    // 0x11728e0: DecompressPointer r5
    //     0x11728e0: add             x5, x5, HEAP, lsl #32
    // 0x11728e4: mov             x0, x5
    // 0x11728e8: stur            x5, [fp, #-0x18]
    // 0x11728ec: r2 = Null
    //     0x11728ec: mov             x2, NULL
    // 0x11728f0: r1 = Null
    //     0x11728f0: mov             x1, NULL
    // 0x11728f4: r4 = LoadClassIdInstr(r0)
    //     0x11728f4: ldur            x4, [x0, #-1]
    //     0x11728f8: ubfx            x4, x4, #0xc, #0x14
    // 0x11728fc: cmp             x4, #0xeea
    // 0x1172900: b.eq            #0x1172918
    // 0x1172904: r8 = TransformEngineLayer?
    //     0x1172904: add             x8, PP, #0xd, lsl #12  ; [pp+0xde08] Type: TransformEngineLayer?
    //     0x1172908: ldr             x8, [x8, #0xe08]
    // 0x117290c: r3 = Null
    //     0x117290c: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e670] Null
    //     0x1172910: ldr             x3, [x3, #0x670]
    // 0x1172914: r0 = DefaultNullableTypeTest()
    //     0x1172914: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1172918: ldur            x16, [fp, #-0x18]
    // 0x117291c: str             x16, [SP]
    // 0x1172920: ldur            x1, [fp, #-0x10]
    // 0x1172924: ldur            x2, [fp, #-0x20]
    // 0x1172928: r4 = const [0, 0x3, 0x1, 0x2, oldLayer, 0x2, null]
    //     0x1172928: add             x4, PP, #0xd, lsl #12  ; [pp+0xde20] List(7) [0, 0x3, 0x1, 0x2, "oldLayer", 0x2, Null]
    //     0x117292c: ldr             x4, [x4, #0xe20]
    // 0x1172930: r0 = pushTransform()
    //     0x1172930: bl              #0xc1ea80  ; [dart:ui] _NativeSceneBuilder::pushTransform
    // 0x1172934: ldur            x1, [fp, #-8]
    // 0x1172938: mov             x2, x0
    // 0x117293c: r0 = engineLayer=()
    //     0x117293c: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1172940: ldur            x1, [fp, #-8]
    // 0x1172944: ldur            x2, [fp, #-0x10]
    // 0x1172948: r0 = addChildrenToScene()
    //     0x1172948: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x117294c: ldur            x1, [fp, #-0x10]
    // 0x1172950: r0 = pop()
    //     0x1172950: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x1172954: b               #0x1172a00
    // 0x1172958: mov             x0, x3
    // 0x117295c: StoreField: r0->field_57 = rNULL
    //     0x117295c: stur            NULL, [x0, #0x57]
    // 0x1172960: LoadField: r1 = r0->field_4f
    //     0x1172960: ldur            w1, [x0, #0x4f]
    // 0x1172964: DecompressPointer r1
    //     0x1172964: add             x1, x1, HEAP, lsl #32
    // 0x1172968: LoadField: d0 = r1->field_7
    //     0x1172968: ldur            d0, [x1, #7]
    // 0x117296c: LoadField: d1 = r1->field_f
    //     0x117296c: ldur            d1, [x1, #0xf]
    // 0x1172970: r1 = Null
    //     0x1172970: mov             x1, NULL
    // 0x1172974: r0 = Matrix4.translationValues()
    //     0x1172974: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0x1172978: LoadField: r3 = r0->field_7
    //     0x1172978: ldur            w3, [x0, #7]
    // 0x117297c: DecompressPointer r3
    //     0x117297c: add             x3, x3, HEAP, lsl #32
    // 0x1172980: ldur            x4, [fp, #-8]
    // 0x1172984: stur            x3, [fp, #-0x20]
    // 0x1172988: LoadField: r5 = r4->field_27
    //     0x1172988: ldur            w5, [x4, #0x27]
    // 0x117298c: DecompressPointer r5
    //     0x117298c: add             x5, x5, HEAP, lsl #32
    // 0x1172990: mov             x0, x5
    // 0x1172994: stur            x5, [fp, #-0x18]
    // 0x1172998: r2 = Null
    //     0x1172998: mov             x2, NULL
    // 0x117299c: r1 = Null
    //     0x117299c: mov             x1, NULL
    // 0x11729a0: r4 = LoadClassIdInstr(r0)
    //     0x11729a0: ldur            x4, [x0, #-1]
    //     0x11729a4: ubfx            x4, x4, #0xc, #0x14
    // 0x11729a8: cmp             x4, #0xeea
    // 0x11729ac: b.eq            #0x11729c4
    // 0x11729b0: r8 = TransformEngineLayer?
    //     0x11729b0: add             x8, PP, #0xd, lsl #12  ; [pp+0xde08] Type: TransformEngineLayer?
    //     0x11729b4: ldr             x8, [x8, #0xe08]
    // 0x11729b8: r3 = Null
    //     0x11729b8: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e680] Null
    //     0x11729bc: ldr             x3, [x3, #0x680]
    // 0x11729c0: r0 = DefaultNullableTypeTest()
    //     0x11729c0: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x11729c4: ldur            x16, [fp, #-0x18]
    // 0x11729c8: str             x16, [SP]
    // 0x11729cc: ldur            x1, [fp, #-0x10]
    // 0x11729d0: ldur            x2, [fp, #-0x20]
    // 0x11729d4: r4 = const [0, 0x3, 0x1, 0x2, oldLayer, 0x2, null]
    //     0x11729d4: add             x4, PP, #0xd, lsl #12  ; [pp+0xde20] List(7) [0, 0x3, 0x1, 0x2, "oldLayer", 0x2, Null]
    //     0x11729d8: ldr             x4, [x4, #0xe20]
    // 0x11729dc: r0 = pushTransform()
    //     0x11729dc: bl              #0xc1ea80  ; [dart:ui] _NativeSceneBuilder::pushTransform
    // 0x11729e0: ldur            x1, [fp, #-8]
    // 0x11729e4: mov             x2, x0
    // 0x11729e8: r0 = engineLayer=()
    //     0x11729e8: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x11729ec: ldur            x1, [fp, #-8]
    // 0x11729f0: ldur            x2, [fp, #-0x10]
    // 0x11729f4: r0 = addChildrenToScene()
    //     0x11729f4: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x11729f8: ldur            x1, [fp, #-0x10]
    // 0x11729fc: r0 = pop()
    //     0x11729fc: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x1172a00: ldur            x1, [fp, #-8]
    // 0x1172a04: r2 = true
    //     0x1172a04: add             x2, NULL, #0x20  ; true
    // 0x1172a08: StoreField: r1->field_63 = r2
    //     0x1172a08: stur            w2, [x1, #0x63]
    // 0x1172a0c: r0 = Null
    //     0x1172a0c: mov             x0, NULL
    // 0x1172a10: LeaveFrame
    //     0x1172a10: mov             SP, fp
    //     0x1172a14: ldp             fp, lr, [SP], #0x10
    // 0x1172a18: ret
    //     0x1172a18: ret             
    // 0x1172a1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1172a1c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1172a20: b               #0x1172834
  }
  _ _establishTransform(/* No info */) {
    // ** addr: 0x1172a24, size: 0x198
    // 0x1172a24: EnterFrame
    //     0x1172a24: stp             fp, lr, [SP, #-0x10]!
    //     0x1172a28: mov             fp, SP
    // 0x1172a2c: AllocStack(0x28)
    //     0x1172a2c: sub             SP, SP, #0x28
    // 0x1172a30: SetupParameters(FollowerLayer this /* r1 => r0, fp-0x10 */)
    //     0x1172a30: mov             x0, x1
    //     0x1172a34: stur            x1, [fp, #-0x10]
    // 0x1172a38: CheckStackOverflow
    //     0x1172a38: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1172a3c: cmp             SP, x16
    //     0x1172a40: b.ls            #0x1172bb4
    // 0x1172a44: StoreField: r0->field_5b = rNULL
    //     0x1172a44: stur            NULL, [x0, #0x5b]
    // 0x1172a48: LoadField: r1 = r0->field_47
    //     0x1172a48: ldur            w1, [x0, #0x47]
    // 0x1172a4c: DecompressPointer r1
    //     0x1172a4c: add             x1, x1, HEAP, lsl #32
    // 0x1172a50: LoadField: r3 = r1->field_7
    //     0x1172a50: ldur            w3, [x1, #7]
    // 0x1172a54: DecompressPointer r3
    //     0x1172a54: add             x3, x3, HEAP, lsl #32
    // 0x1172a58: stur            x3, [fp, #-8]
    // 0x1172a5c: cmp             w3, NULL
    // 0x1172a60: b.ne            #0x1172a74
    // 0x1172a64: r0 = Null
    //     0x1172a64: mov             x0, NULL
    // 0x1172a68: LeaveFrame
    //     0x1172a68: mov             SP, fp
    //     0x1172a6c: ldp             fp, lr, [SP], #0x10
    // 0x1172a70: ret
    //     0x1172a70: ret             
    // 0x1172a74: r4 = 2
    //     0x1172a74: mov             x4, #2
    // 0x1172a78: mov             x2, x4
    // 0x1172a7c: r1 = Null
    //     0x1172a7c: mov             x1, NULL
    // 0x1172a80: r0 = AllocateArray()
    //     0x1172a80: bl              #0x13df928  ; AllocateArrayStub
    // 0x1172a84: mov             x2, x0
    // 0x1172a88: ldur            x0, [fp, #-8]
    // 0x1172a8c: stur            x2, [fp, #-0x18]
    // 0x1172a90: StoreField: r2->field_f = r0
    //     0x1172a90: stur            w0, [x2, #0xf]
    // 0x1172a94: r1 = <ContainerLayer>
    //     0x1172a94: ldr             x1, [PP, #0x7f40]  ; [pp+0x7f40] TypeArguments: <ContainerLayer>
    // 0x1172a98: r0 = AllocateGrowableArray()
    //     0x1172a98: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1172a9c: mov             x3, x0
    // 0x1172aa0: ldur            x0, [fp, #-0x18]
    // 0x1172aa4: stur            x3, [fp, #-0x20]
    // 0x1172aa8: StoreField: r3->field_f = r0
    //     0x1172aa8: stur            w0, [x3, #0xf]
    // 0x1172aac: r0 = 2
    //     0x1172aac: mov             x0, #2
    // 0x1172ab0: StoreField: r3->field_b = r0
    //     0x1172ab0: stur            w0, [x3, #0xb]
    // 0x1172ab4: mov             x2, x0
    // 0x1172ab8: r1 = Null
    //     0x1172ab8: mov             x1, NULL
    // 0x1172abc: r0 = AllocateArray()
    //     0x1172abc: bl              #0x13df928  ; AllocateArrayStub
    // 0x1172ac0: ldur            x2, [fp, #-0x10]
    // 0x1172ac4: stur            x0, [fp, #-0x18]
    // 0x1172ac8: StoreField: r0->field_f = r2
    //     0x1172ac8: stur            w2, [x0, #0xf]
    // 0x1172acc: r1 = <ContainerLayer>
    //     0x1172acc: ldr             x1, [PP, #0x7f40]  ; [pp+0x7f40] TypeArguments: <ContainerLayer>
    // 0x1172ad0: r0 = AllocateGrowableArray()
    //     0x1172ad0: bl              #0x13de7f8  ; AllocateGrowableArrayStub
    // 0x1172ad4: mov             x4, x0
    // 0x1172ad8: ldur            x0, [fp, #-0x18]
    // 0x1172adc: stur            x4, [fp, #-0x28]
    // 0x1172ae0: StoreField: r4->field_f = r0
    //     0x1172ae0: stur            w0, [x4, #0xf]
    // 0x1172ae4: r0 = 2
    //     0x1172ae4: mov             x0, #2
    // 0x1172ae8: StoreField: r4->field_b = r0
    //     0x1172ae8: stur            w0, [x4, #0xb]
    // 0x1172aec: ldur            x1, [fp, #-8]
    // 0x1172af0: ldur            x2, [fp, #-0x10]
    // 0x1172af4: ldur            x3, [fp, #-0x20]
    // 0x1172af8: mov             x5, x4
    // 0x1172afc: r0 = _pathsToCommonAncestor()
    //     0x1172afc: bl              #0x1172ccc  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_pathsToCommonAncestor
    // 0x1172b00: ldur            x1, [fp, #-0x20]
    // 0x1172b04: r0 = _collectTransformForLayerChain()
    //     0x1172b04: bl              #0x1172bbc  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_collectTransformForLayerChain
    // 0x1172b08: ldur            x1, [fp, #-8]
    // 0x1172b0c: mov             x2, x0
    // 0x1172b10: stur            x0, [fp, #-8]
    // 0x1172b14: r0 = applyTransform()
    //     0x1172b14: bl              #0x115c75c  ; [package:flutter/src/rendering/layer.dart] LeaderLayer::applyTransform
    // 0x1172b18: ldur            x0, [fp, #-0x10]
    // 0x1172b1c: LoadField: r1 = r0->field_53
    //     0x1172b1c: ldur            w1, [x0, #0x53]
    // 0x1172b20: DecompressPointer r1
    //     0x1172b20: add             x1, x1, HEAP, lsl #32
    // 0x1172b24: LoadField: d0 = r1->field_7
    //     0x1172b24: ldur            d0, [x1, #7]
    // 0x1172b28: LoadField: d1 = r1->field_f
    //     0x1172b28: ldur            d1, [x1, #0xf]
    // 0x1172b2c: ldur            x1, [fp, #-8]
    // 0x1172b30: r0 = translateByDouble()
    //     0x1172b30: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0x1172b34: ldur            x1, [fp, #-0x28]
    // 0x1172b38: r0 = _collectTransformForLayerChain()
    //     0x1172b38: bl              #0x1172bbc  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_collectTransformForLayerChain
    // 0x1172b3c: mov             x1, x0
    // 0x1172b40: stur            x0, [fp, #-0x18]
    // 0x1172b44: r0 = invert()
    //     0x1172b44: bl              #0x857b2c  ; [package:vector_math/vector_math_64.dart] Matrix4::invert
    // 0x1172b48: mov             v1.16b, v0.16b
    // 0x1172b4c: d0 = 0.000000
    //     0x1172b4c: eor             v0.16b, v0.16b, v0.16b
    // 0x1172b50: fcmp            d1, d0
    // 0x1172b54: b.ne            #0x1172b68
    // 0x1172b58: r0 = Null
    //     0x1172b58: mov             x0, NULL
    // 0x1172b5c: LeaveFrame
    //     0x1172b5c: mov             SP, fp
    //     0x1172b60: ldp             fp, lr, [SP], #0x10
    // 0x1172b64: ret
    //     0x1172b64: ret             
    // 0x1172b68: ldur            x0, [fp, #-0x10]
    // 0x1172b6c: ldur            x1, [fp, #-0x18]
    // 0x1172b70: ldur            x2, [fp, #-8]
    // 0x1172b74: r0 = multiply()
    //     0x1172b74: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x1172b78: ldur            x0, [fp, #-0x18]
    // 0x1172b7c: ldur            x1, [fp, #-0x10]
    // 0x1172b80: StoreField: r1->field_5b = r0
    //     0x1172b80: stur            w0, [x1, #0x5b]
    //     0x1172b84: ldurb           w16, [x1, #-1]
    //     0x1172b88: ldurb           w17, [x0, #-1]
    //     0x1172b8c: and             x16, x17, x16, lsr #2
    //     0x1172b90: tst             x16, HEAP, lsr #32
    //     0x1172b94: b.eq            #0x1172b9c
    //     0x1172b98: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1172b9c: r2 = true
    //     0x1172b9c: add             x2, NULL, #0x20  ; true
    // 0x1172ba0: StoreField: r1->field_63 = r2
    //     0x1172ba0: stur            w2, [x1, #0x63]
    // 0x1172ba4: r0 = Null
    //     0x1172ba4: mov             x0, NULL
    // 0x1172ba8: LeaveFrame
    //     0x1172ba8: mov             SP, fp
    //     0x1172bac: ldp             fp, lr, [SP], #0x10
    // 0x1172bb0: ret
    //     0x1172bb0: ret             
    // 0x1172bb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1172bb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1172bb8: b               #0x1172a44
  }
  static _ _collectTransformForLayerChain(/* No info */) {
    // ** addr: 0x1172bbc, size: 0x110
    // 0x1172bbc: EnterFrame
    //     0x1172bbc: stp             fp, lr, [SP, #-0x10]!
    //     0x1172bc0: mov             fp, SP
    // 0x1172bc4: AllocStack(0x18)
    //     0x1172bc4: sub             SP, SP, #0x18
    // 0x1172bc8: SetupParameters(dynamic _ /* r1 => r1, fp-0x8 */)
    //     0x1172bc8: stur            x1, [fp, #-8]
    // 0x1172bcc: CheckStackOverflow
    //     0x1172bcc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1172bd0: cmp             SP, x16
    //     0x1172bd4: b.ls            #0x1172cb4
    // 0x1172bd8: r0 = Matrix4()
    //     0x1172bd8: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x1172bdc: r4 = 32
    //     0x1172bdc: mov             x4, #0x20
    // 0x1172be0: stur            x0, [fp, #-0x10]
    // 0x1172be4: r0 = AllocateFloat64Array()
    //     0x1172be4: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x1172be8: mov             x1, x0
    // 0x1172bec: ldur            x0, [fp, #-0x10]
    // 0x1172bf0: StoreField: r0->field_7 = r1
    //     0x1172bf0: stur            w1, [x0, #7]
    // 0x1172bf4: mov             x1, x0
    // 0x1172bf8: r0 = setIdentity()
    //     0x1172bf8: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x1172bfc: ldur            x3, [fp, #-8]
    // 0x1172c00: LoadField: r0 = r3->field_b
    //     0x1172c00: ldur            w0, [x3, #0xb]
    // 0x1172c04: r1 = LoadInt32Instr(r0)
    //     0x1172c04: sbfx            x1, x0, #1, #0x1f
    // 0x1172c08: sub             x0, x1, #1
    // 0x1172c0c: mov             x4, x0
    // 0x1172c10: stur            x4, [fp, #-0x18]
    // 0x1172c14: CheckStackOverflow
    //     0x1172c14: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1172c18: cmp             SP, x16
    //     0x1172c1c: b.ls            #0x1172cbc
    // 0x1172c20: cmp             x4, #0
    // 0x1172c24: b.le            #0x1172ca4
    // 0x1172c28: LoadField: r0 = r3->field_b
    //     0x1172c28: ldur            w0, [x3, #0xb]
    // 0x1172c2c: r2 = LoadInt32Instr(r0)
    //     0x1172c2c: sbfx            x2, x0, #1, #0x1f
    // 0x1172c30: mov             x0, x2
    // 0x1172c34: mov             x1, x4
    // 0x1172c38: cmp             x1, x0
    // 0x1172c3c: b.hs            #0x1172cc4
    // 0x1172c40: LoadField: r0 = r3->field_f
    //     0x1172c40: ldur            w0, [x3, #0xf]
    // 0x1172c44: DecompressPointer r0
    //     0x1172c44: add             x0, x0, HEAP, lsl #32
    // 0x1172c48: ArrayLoad: r5 = r0[r4]  ; Unknown_4
    //     0x1172c48: add             x16, x0, x4, lsl #2
    //     0x1172c4c: ldur            w5, [x16, #0xf]
    // 0x1172c50: DecompressPointer r5
    //     0x1172c50: add             x5, x5, HEAP, lsl #32
    // 0x1172c54: cmp             w5, NULL
    // 0x1172c58: b.ne            #0x1172c64
    // 0x1172c5c: mov             x1, x4
    // 0x1172c60: b               #0x1172c98
    // 0x1172c64: sub             x1, x4, #1
    // 0x1172c68: mov             x0, x2
    // 0x1172c6c: cmp             x1, x0
    // 0x1172c70: b.hs            #0x1172cc8
    // 0x1172c74: r0 = LoadClassIdInstr(r5)
    //     0x1172c74: ldur            x0, [x5, #-1]
    //     0x1172c78: ubfx            x0, x0, #0xc, #0x14
    // 0x1172c7c: mov             x1, x5
    // 0x1172c80: ldur            x2, [fp, #-0x10]
    // 0x1172c84: r0 = GDT[cid_x0 + 0x4fa3]()
    //     0x1172c84: mov             x17, #0x4fa3
    //     0x1172c88: add             lr, x0, x17
    //     0x1172c8c: ldr             lr, [x21, lr, lsl #3]
    //     0x1172c90: blr             lr
    // 0x1172c94: ldur            x1, [fp, #-0x18]
    // 0x1172c98: sub             x4, x1, #1
    // 0x1172c9c: ldur            x3, [fp, #-8]
    // 0x1172ca0: b               #0x1172c10
    // 0x1172ca4: ldur            x0, [fp, #-0x10]
    // 0x1172ca8: LeaveFrame
    //     0x1172ca8: mov             SP, fp
    //     0x1172cac: ldp             fp, lr, [SP], #0x10
    // 0x1172cb0: ret
    //     0x1172cb0: ret             
    // 0x1172cb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1172cb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1172cb8: b               #0x1172bd8
    // 0x1172cbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1172cbc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1172cc0: b               #0x1172c20
    // 0x1172cc4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1172cc4: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
    // 0x1172cc8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x1172cc8: bl              #0x13dff64  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ _pathsToCommonAncestor(/* No info */) {
    // ** addr: 0x1172ccc, size: 0x408
    // 0x1172ccc: EnterFrame
    //     0x1172ccc: stp             fp, lr, [SP, #-0x10]!
    //     0x1172cd0: mov             fp, SP
    // 0x1172cd4: AllocStack(0x30)
    //     0x1172cd4: sub             SP, SP, #0x30
    // 0x1172cd8: SetupParameters(dynamic _ /* r1 => r6, fp-0x10 */, dynamic _ /* r2 => r5, fp-0x18 */, dynamic _ /* r3 => r4, fp-0x20 */, dynamic _ /* r5 => r3, fp-0x28 */)
    //     0x1172cd8: mov             x6, x1
    //     0x1172cdc: mov             x4, x3
    //     0x1172ce0: stur            x3, [fp, #-0x20]
    //     0x1172ce4: mov             x3, x5
    //     0x1172ce8: stur            x5, [fp, #-0x28]
    //     0x1172cec: mov             x5, x2
    //     0x1172cf0: stur            x1, [fp, #-0x10]
    //     0x1172cf4: stur            x2, [fp, #-0x18]
    // 0x1172cf8: CheckStackOverflow
    //     0x1172cf8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1172cfc: cmp             SP, x16
    //     0x1172d00: b.ls            #0x11730cc
    // 0x1172d04: cmp             w6, NULL
    // 0x1172d08: b.eq            #0x1172d14
    // 0x1172d0c: cmp             w5, NULL
    // 0x1172d10: b.ne            #0x1172d24
    // 0x1172d14: r0 = Null
    //     0x1172d14: mov             x0, NULL
    // 0x1172d18: LeaveFrame
    //     0x1172d18: mov             SP, fp
    //     0x1172d1c: ldp             fp, lr, [SP], #0x10
    // 0x1172d20: ret
    //     0x1172d20: ret             
    // 0x1172d24: cmp             w6, w5
    // 0x1172d28: b.ne            #0x1172d3c
    // 0x1172d2c: mov             x0, x6
    // 0x1172d30: LeaveFrame
    //     0x1172d30: mov             SP, fp
    //     0x1172d34: ldp             fp, lr, [SP], #0x10
    // 0x1172d38: ret
    //     0x1172d38: ret             
    // 0x1172d3c: LoadField: r0 = r6->field_2f
    //     0x1172d3c: ldur            x0, [x6, #0x2f]
    // 0x1172d40: LoadField: r1 = r5->field_2f
    //     0x1172d40: ldur            x1, [x5, #0x2f]
    // 0x1172d44: cmp             x0, x1
    // 0x1172d48: b.ge            #0x1172e28
    // 0x1172d4c: LoadField: r7 = r5->field_1f
    //     0x1172d4c: ldur            w7, [x5, #0x1f]
    // 0x1172d50: DecompressPointer r7
    //     0x1172d50: add             x7, x7, HEAP, lsl #32
    // 0x1172d54: stur            x7, [fp, #-8]
    // 0x1172d58: LoadField: r2 = r3->field_7
    //     0x1172d58: ldur            w2, [x3, #7]
    // 0x1172d5c: DecompressPointer r2
    //     0x1172d5c: add             x2, x2, HEAP, lsl #32
    // 0x1172d60: mov             x0, x7
    // 0x1172d64: r1 = Null
    //     0x1172d64: mov             x1, NULL
    // 0x1172d68: cmp             w2, NULL
    // 0x1172d6c: b.eq            #0x1172d8c
    // 0x1172d70: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1172d70: ldur            w4, [x2, #0x17]
    // 0x1172d74: DecompressPointer r4
    //     0x1172d74: add             x4, x4, HEAP, lsl #32
    // 0x1172d78: r8 = X0
    //     0x1172d78: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1172d7c: LoadField: r9 = r4->field_7
    //     0x1172d7c: ldur            x9, [x4, #7]
    // 0x1172d80: r3 = Null
    //     0x1172d80: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e690] Null
    //     0x1172d84: ldr             x3, [x3, #0x690]
    // 0x1172d88: blr             x9
    // 0x1172d8c: ldur            x0, [fp, #-0x28]
    // 0x1172d90: LoadField: r1 = r0->field_b
    //     0x1172d90: ldur            w1, [x0, #0xb]
    // 0x1172d94: LoadField: r2 = r0->field_f
    //     0x1172d94: ldur            w2, [x0, #0xf]
    // 0x1172d98: DecompressPointer r2
    //     0x1172d98: add             x2, x2, HEAP, lsl #32
    // 0x1172d9c: LoadField: r3 = r2->field_b
    //     0x1172d9c: ldur            w3, [x2, #0xb]
    // 0x1172da0: r2 = LoadInt32Instr(r1)
    //     0x1172da0: sbfx            x2, x1, #1, #0x1f
    // 0x1172da4: stur            x2, [fp, #-0x30]
    // 0x1172da8: r1 = LoadInt32Instr(r3)
    //     0x1172da8: sbfx            x1, x3, #1, #0x1f
    // 0x1172dac: cmp             x2, x1
    // 0x1172db0: b.ne            #0x1172dbc
    // 0x1172db4: mov             x1, x0
    // 0x1172db8: r0 = _growToNextCapacity()
    //     0x1172db8: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1172dbc: ldur            x3, [fp, #-0x18]
    // 0x1172dc0: ldur            x5, [fp, #-0x28]
    // 0x1172dc4: ldur            x2, [fp, #-0x30]
    // 0x1172dc8: add             x0, x2, #1
    // 0x1172dcc: lsl             x1, x0, #1
    // 0x1172dd0: StoreField: r5->field_b = r1
    //     0x1172dd0: stur            w1, [x5, #0xb]
    // 0x1172dd4: LoadField: r1 = r5->field_f
    //     0x1172dd4: ldur            w1, [x5, #0xf]
    // 0x1172dd8: DecompressPointer r1
    //     0x1172dd8: add             x1, x1, HEAP, lsl #32
    // 0x1172ddc: ldur            x0, [fp, #-8]
    // 0x1172de0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x1172de0: add             x25, x1, x2, lsl #2
    //     0x1172de4: add             x25, x25, #0xf
    //     0x1172de8: str             w0, [x25]
    //     0x1172dec: tbz             w0, #0, #0x1172e08
    //     0x1172df0: ldurb           w16, [x1, #-1]
    //     0x1172df4: ldurb           w17, [x0, #-1]
    //     0x1172df8: and             x16, x17, x16, lsr #2
    //     0x1172dfc: tst             x16, HEAP, lsr #32
    //     0x1172e00: b.eq            #0x1172e08
    //     0x1172e04: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1172e08: LoadField: r2 = r3->field_1f
    //     0x1172e08: ldur            w2, [x3, #0x1f]
    // 0x1172e0c: DecompressPointer r2
    //     0x1172e0c: add             x2, x2, HEAP, lsl #32
    // 0x1172e10: ldur            x1, [fp, #-0x10]
    // 0x1172e14: ldur            x3, [fp, #-0x20]
    // 0x1172e18: r0 = _pathsToCommonAncestor()
    //     0x1172e18: bl              #0x1172ccc  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_pathsToCommonAncestor
    // 0x1172e1c: LeaveFrame
    //     0x1172e1c: mov             SP, fp
    //     0x1172e20: ldp             fp, lr, [SP], #0x10
    // 0x1172e24: ret
    //     0x1172e24: ret             
    // 0x1172e28: mov             x16, x3
    // 0x1172e2c: mov             x3, x5
    // 0x1172e30: mov             x5, x16
    // 0x1172e34: cmp             x0, x1
    // 0x1172e38: b.le            #0x1172f20
    // 0x1172e3c: ldur            x6, [fp, #-0x10]
    // 0x1172e40: ldur            x4, [fp, #-0x20]
    // 0x1172e44: LoadField: r7 = r6->field_1f
    //     0x1172e44: ldur            w7, [x6, #0x1f]
    // 0x1172e48: DecompressPointer r7
    //     0x1172e48: add             x7, x7, HEAP, lsl #32
    // 0x1172e4c: stur            x7, [fp, #-8]
    // 0x1172e50: LoadField: r2 = r4->field_7
    //     0x1172e50: ldur            w2, [x4, #7]
    // 0x1172e54: DecompressPointer r2
    //     0x1172e54: add             x2, x2, HEAP, lsl #32
    // 0x1172e58: mov             x0, x7
    // 0x1172e5c: r1 = Null
    //     0x1172e5c: mov             x1, NULL
    // 0x1172e60: cmp             w2, NULL
    // 0x1172e64: b.eq            #0x1172e84
    // 0x1172e68: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1172e68: ldur            w4, [x2, #0x17]
    // 0x1172e6c: DecompressPointer r4
    //     0x1172e6c: add             x4, x4, HEAP, lsl #32
    // 0x1172e70: r8 = X0
    //     0x1172e70: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1172e74: LoadField: r9 = r4->field_7
    //     0x1172e74: ldur            x9, [x4, #7]
    // 0x1172e78: r3 = Null
    //     0x1172e78: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e6a0] Null
    //     0x1172e7c: ldr             x3, [x3, #0x6a0]
    // 0x1172e80: blr             x9
    // 0x1172e84: ldur            x0, [fp, #-0x20]
    // 0x1172e88: LoadField: r1 = r0->field_b
    //     0x1172e88: ldur            w1, [x0, #0xb]
    // 0x1172e8c: LoadField: r2 = r0->field_f
    //     0x1172e8c: ldur            w2, [x0, #0xf]
    // 0x1172e90: DecompressPointer r2
    //     0x1172e90: add             x2, x2, HEAP, lsl #32
    // 0x1172e94: LoadField: r3 = r2->field_b
    //     0x1172e94: ldur            w3, [x2, #0xb]
    // 0x1172e98: r2 = LoadInt32Instr(r1)
    //     0x1172e98: sbfx            x2, x1, #1, #0x1f
    // 0x1172e9c: stur            x2, [fp, #-0x30]
    // 0x1172ea0: r1 = LoadInt32Instr(r3)
    //     0x1172ea0: sbfx            x1, x3, #1, #0x1f
    // 0x1172ea4: cmp             x2, x1
    // 0x1172ea8: b.ne            #0x1172eb4
    // 0x1172eac: mov             x1, x0
    // 0x1172eb0: r0 = _growToNextCapacity()
    //     0x1172eb0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1172eb4: ldur            x4, [fp, #-0x10]
    // 0x1172eb8: ldur            x3, [fp, #-0x20]
    // 0x1172ebc: ldur            x2, [fp, #-0x30]
    // 0x1172ec0: add             x0, x2, #1
    // 0x1172ec4: lsl             x1, x0, #1
    // 0x1172ec8: StoreField: r3->field_b = r1
    //     0x1172ec8: stur            w1, [x3, #0xb]
    // 0x1172ecc: LoadField: r1 = r3->field_f
    //     0x1172ecc: ldur            w1, [x3, #0xf]
    // 0x1172ed0: DecompressPointer r1
    //     0x1172ed0: add             x1, x1, HEAP, lsl #32
    // 0x1172ed4: ldur            x0, [fp, #-8]
    // 0x1172ed8: ArrayStore: r1[r2] = r0  ; List_4
    //     0x1172ed8: add             x25, x1, x2, lsl #2
    //     0x1172edc: add             x25, x25, #0xf
    //     0x1172ee0: str             w0, [x25]
    //     0x1172ee4: tbz             w0, #0, #0x1172f00
    //     0x1172ee8: ldurb           w16, [x1, #-1]
    //     0x1172eec: ldurb           w17, [x0, #-1]
    //     0x1172ef0: and             x16, x17, x16, lsr #2
    //     0x1172ef4: tst             x16, HEAP, lsr #32
    //     0x1172ef8: b.eq            #0x1172f00
    //     0x1172efc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1172f00: LoadField: r1 = r4->field_1f
    //     0x1172f00: ldur            w1, [x4, #0x1f]
    // 0x1172f04: DecompressPointer r1
    //     0x1172f04: add             x1, x1, HEAP, lsl #32
    // 0x1172f08: ldur            x2, [fp, #-0x18]
    // 0x1172f0c: ldur            x5, [fp, #-0x28]
    // 0x1172f10: r0 = _pathsToCommonAncestor()
    //     0x1172f10: bl              #0x1172ccc  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_pathsToCommonAncestor
    // 0x1172f14: LeaveFrame
    //     0x1172f14: mov             SP, fp
    //     0x1172f18: ldp             fp, lr, [SP], #0x10
    // 0x1172f1c: ret
    //     0x1172f1c: ret             
    // 0x1172f20: ldur            x4, [fp, #-0x10]
    // 0x1172f24: ldur            x3, [fp, #-0x20]
    // 0x1172f28: LoadField: r5 = r4->field_1f
    //     0x1172f28: ldur            w5, [x4, #0x1f]
    // 0x1172f2c: DecompressPointer r5
    //     0x1172f2c: add             x5, x5, HEAP, lsl #32
    // 0x1172f30: stur            x5, [fp, #-8]
    // 0x1172f34: LoadField: r2 = r3->field_7
    //     0x1172f34: ldur            w2, [x3, #7]
    // 0x1172f38: DecompressPointer r2
    //     0x1172f38: add             x2, x2, HEAP, lsl #32
    // 0x1172f3c: mov             x0, x5
    // 0x1172f40: r1 = Null
    //     0x1172f40: mov             x1, NULL
    // 0x1172f44: cmp             w2, NULL
    // 0x1172f48: b.eq            #0x1172f68
    // 0x1172f4c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x1172f4c: ldur            w4, [x2, #0x17]
    // 0x1172f50: DecompressPointer r4
    //     0x1172f50: add             x4, x4, HEAP, lsl #32
    // 0x1172f54: r8 = X0
    //     0x1172f54: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1172f58: LoadField: r9 = r4->field_7
    //     0x1172f58: ldur            x9, [x4, #7]
    // 0x1172f5c: r3 = Null
    //     0x1172f5c: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e6b0] Null
    //     0x1172f60: ldr             x3, [x3, #0x6b0]
    // 0x1172f64: blr             x9
    // 0x1172f68: ldur            x0, [fp, #-0x20]
    // 0x1172f6c: LoadField: r1 = r0->field_b
    //     0x1172f6c: ldur            w1, [x0, #0xb]
    // 0x1172f70: LoadField: r2 = r0->field_f
    //     0x1172f70: ldur            w2, [x0, #0xf]
    // 0x1172f74: DecompressPointer r2
    //     0x1172f74: add             x2, x2, HEAP, lsl #32
    // 0x1172f78: LoadField: r3 = r2->field_b
    //     0x1172f78: ldur            w3, [x2, #0xb]
    // 0x1172f7c: r2 = LoadInt32Instr(r1)
    //     0x1172f7c: sbfx            x2, x1, #1, #0x1f
    // 0x1172f80: stur            x2, [fp, #-0x30]
    // 0x1172f84: r1 = LoadInt32Instr(r3)
    //     0x1172f84: sbfx            x1, x3, #1, #0x1f
    // 0x1172f88: cmp             x2, x1
    // 0x1172f8c: b.ne            #0x1172f98
    // 0x1172f90: mov             x1, x0
    // 0x1172f94: r0 = _growToNextCapacity()
    //     0x1172f94: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1172f98: ldur            x5, [fp, #-0x18]
    // 0x1172f9c: ldur            x3, [fp, #-0x20]
    // 0x1172fa0: ldur            x4, [fp, #-0x28]
    // 0x1172fa4: ldur            x2, [fp, #-0x30]
    // 0x1172fa8: add             x0, x2, #1
    // 0x1172fac: lsl             x1, x0, #1
    // 0x1172fb0: StoreField: r3->field_b = r1
    //     0x1172fb0: stur            w1, [x3, #0xb]
    // 0x1172fb4: LoadField: r1 = r3->field_f
    //     0x1172fb4: ldur            w1, [x3, #0xf]
    // 0x1172fb8: DecompressPointer r1
    //     0x1172fb8: add             x1, x1, HEAP, lsl #32
    // 0x1172fbc: ldur            x0, [fp, #-8]
    // 0x1172fc0: ArrayStore: r1[r2] = r0  ; List_4
    //     0x1172fc0: add             x25, x1, x2, lsl #2
    //     0x1172fc4: add             x25, x25, #0xf
    //     0x1172fc8: str             w0, [x25]
    //     0x1172fcc: tbz             w0, #0, #0x1172fe8
    //     0x1172fd0: ldurb           w16, [x1, #-1]
    //     0x1172fd4: ldurb           w17, [x0, #-1]
    //     0x1172fd8: and             x16, x17, x16, lsr #2
    //     0x1172fdc: tst             x16, HEAP, lsr #32
    //     0x1172fe0: b.eq            #0x1172fe8
    //     0x1172fe4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x1172fe8: LoadField: r6 = r5->field_1f
    //     0x1172fe8: ldur            w6, [x5, #0x1f]
    // 0x1172fec: DecompressPointer r6
    //     0x1172fec: add             x6, x6, HEAP, lsl #32
    // 0x1172ff0: stur            x6, [fp, #-8]
    // 0x1172ff4: LoadField: r2 = r4->field_7
    //     0x1172ff4: ldur            w2, [x4, #7]
    // 0x1172ff8: DecompressPointer r2
    //     0x1172ff8: add             x2, x2, HEAP, lsl #32
    // 0x1172ffc: mov             x0, x6
    // 0x1173000: r1 = Null
    //     0x1173000: mov             x1, NULL
    // 0x1173004: cmp             w2, NULL
    // 0x1173008: b.eq            #0x1173028
    // 0x117300c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x117300c: ldur            w4, [x2, #0x17]
    // 0x1173010: DecompressPointer r4
    //     0x1173010: add             x4, x4, HEAP, lsl #32
    // 0x1173014: r8 = X0
    //     0x1173014: ldr             x8, [PP, #0x300]  ; [pp+0x300] TypeParameter: X0
    // 0x1173018: LoadField: r9 = r4->field_7
    //     0x1173018: ldur            x9, [x4, #7]
    // 0x117301c: r3 = Null
    //     0x117301c: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e6c0] Null
    //     0x1173020: ldr             x3, [x3, #0x6c0]
    // 0x1173024: blr             x9
    // 0x1173028: ldur            x0, [fp, #-0x28]
    // 0x117302c: LoadField: r1 = r0->field_b
    //     0x117302c: ldur            w1, [x0, #0xb]
    // 0x1173030: LoadField: r2 = r0->field_f
    //     0x1173030: ldur            w2, [x0, #0xf]
    // 0x1173034: DecompressPointer r2
    //     0x1173034: add             x2, x2, HEAP, lsl #32
    // 0x1173038: LoadField: r3 = r2->field_b
    //     0x1173038: ldur            w3, [x2, #0xb]
    // 0x117303c: r2 = LoadInt32Instr(r1)
    //     0x117303c: sbfx            x2, x1, #1, #0x1f
    // 0x1173040: stur            x2, [fp, #-0x30]
    // 0x1173044: r1 = LoadInt32Instr(r3)
    //     0x1173044: sbfx            x1, x3, #1, #0x1f
    // 0x1173048: cmp             x2, x1
    // 0x117304c: b.ne            #0x1173058
    // 0x1173050: mov             x1, x0
    // 0x1173054: r0 = _growToNextCapacity()
    //     0x1173054: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x1173058: ldur            x4, [fp, #-0x10]
    // 0x117305c: ldur            x3, [fp, #-0x18]
    // 0x1173060: ldur            x5, [fp, #-0x28]
    // 0x1173064: ldur            x2, [fp, #-0x30]
    // 0x1173068: add             x0, x2, #1
    // 0x117306c: lsl             x1, x0, #1
    // 0x1173070: StoreField: r5->field_b = r1
    //     0x1173070: stur            w1, [x5, #0xb]
    // 0x1173074: LoadField: r1 = r5->field_f
    //     0x1173074: ldur            w1, [x5, #0xf]
    // 0x1173078: DecompressPointer r1
    //     0x1173078: add             x1, x1, HEAP, lsl #32
    // 0x117307c: ldur            x0, [fp, #-8]
    // 0x1173080: ArrayStore: r1[r2] = r0  ; List_4
    //     0x1173080: add             x25, x1, x2, lsl #2
    //     0x1173084: add             x25, x25, #0xf
    //     0x1173088: str             w0, [x25]
    //     0x117308c: tbz             w0, #0, #0x11730a8
    //     0x1173090: ldurb           w16, [x1, #-1]
    //     0x1173094: ldurb           w17, [x0, #-1]
    //     0x1173098: and             x16, x17, x16, lsr #2
    //     0x117309c: tst             x16, HEAP, lsr #32
    //     0x11730a0: b.eq            #0x11730a8
    //     0x11730a4: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x11730a8: LoadField: r1 = r4->field_1f
    //     0x11730a8: ldur            w1, [x4, #0x1f]
    // 0x11730ac: DecompressPointer r1
    //     0x11730ac: add             x1, x1, HEAP, lsl #32
    // 0x11730b0: LoadField: r2 = r3->field_1f
    //     0x11730b0: ldur            w2, [x3, #0x1f]
    // 0x11730b4: DecompressPointer r2
    //     0x11730b4: add             x2, x2, HEAP, lsl #32
    // 0x11730b8: ldur            x3, [fp, #-0x20]
    // 0x11730bc: r0 = _pathsToCommonAncestor()
    //     0x11730bc: bl              #0x1172ccc  ; [package:flutter/src/rendering/layer.dart] FollowerLayer::_pathsToCommonAncestor
    // 0x11730c0: LeaveFrame
    //     0x11730c0: mov             SP, fp
    //     0x11730c4: ldp             fp, lr, [SP], #0x10
    // 0x11730c8: ret
    //     0x11730c8: ret             
    // 0x11730cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11730cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11730d0: b               #0x1172d04
  }
}

// class id: 4652, size: 0x50, field offset: 0x48
class LeaderLayer extends ContainerLayer {

  set _ offset=(/* No info */) {
    // ** addr: 0xc1d3f8, size: 0x88
    // 0xc1d3f8: EnterFrame
    //     0xc1d3f8: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d3fc: mov             fp, SP
    // 0xc1d400: AllocStack(0x20)
    //     0xc1d400: sub             SP, SP, #0x20
    // 0xc1d404: SetupParameters(LeaderLayer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc1d404: mov             x0, x2
    //     0xc1d408: stur            x1, [fp, #-8]
    //     0xc1d40c: stur            x2, [fp, #-0x10]
    // 0xc1d410: CheckStackOverflow
    //     0xc1d410: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d414: cmp             SP, x16
    //     0xc1d418: b.ls            #0xc1d478
    // 0xc1d41c: LoadField: r2 = r1->field_4b
    //     0xc1d41c: ldur            w2, [x1, #0x4b]
    // 0xc1d420: DecompressPointer r2
    //     0xc1d420: add             x2, x2, HEAP, lsl #32
    // 0xc1d424: stp             x2, x0, [SP]
    // 0xc1d428: r0 = ==()
    //     0xc1d428: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xc1d42c: tbnz            w0, #4, #0xc1d440
    // 0xc1d430: r0 = Null
    //     0xc1d430: mov             x0, NULL
    // 0xc1d434: LeaveFrame
    //     0xc1d434: mov             SP, fp
    //     0xc1d438: ldp             fp, lr, [SP], #0x10
    // 0xc1d43c: ret
    //     0xc1d43c: ret             
    // 0xc1d440: ldur            x1, [fp, #-8]
    // 0xc1d444: ldur            x0, [fp, #-0x10]
    // 0xc1d448: StoreField: r1->field_4b = r0
    //     0xc1d448: stur            w0, [x1, #0x4b]
    //     0xc1d44c: ldurb           w16, [x1, #-1]
    //     0xc1d450: ldurb           w17, [x0, #-1]
    //     0xc1d454: and             x16, x17, x16, lsr #2
    //     0xc1d458: tst             x16, HEAP, lsr #32
    //     0xc1d45c: b.eq            #0xc1d464
    //     0xc1d460: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1d464: r0 = markNeedsAddToScene()
    //     0xc1d464: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc1d468: r0 = Null
    //     0xc1d468: mov             x0, NULL
    // 0xc1d46c: LeaveFrame
    //     0xc1d46c: mov             SP, fp
    //     0xc1d470: ldp             fp, lr, [SP], #0x10
    // 0xc1d474: ret
    //     0xc1d474: ret             
    // 0xc1d478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d478: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d47c: b               #0xc1d41c
  }
  set _ link=(/* No info */) {
    // ** addr: 0xc1d480, size: 0xc8
    // 0xc1d480: EnterFrame
    //     0xc1d480: stp             fp, lr, [SP, #-0x10]!
    //     0xc1d484: mov             fp, SP
    // 0xc1d488: AllocStack(0x10)
    //     0xc1d488: sub             SP, SP, #0x10
    // 0xc1d48c: SetupParameters(LeaderLayer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc1d48c: mov             x3, x1
    //     0xc1d490: mov             x0, x2
    //     0xc1d494: stur            x1, [fp, #-8]
    //     0xc1d498: stur            x2, [fp, #-0x10]
    // 0xc1d49c: CheckStackOverflow
    //     0xc1d49c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1d4a0: cmp             SP, x16
    //     0xc1d4a4: b.ls            #0xc1d540
    // 0xc1d4a8: LoadField: r1 = r3->field_47
    //     0xc1d4a8: ldur            w1, [x3, #0x47]
    // 0xc1d4ac: DecompressPointer r1
    //     0xc1d4ac: add             x1, x1, HEAP, lsl #32
    // 0xc1d4b0: cmp             w1, w0
    // 0xc1d4b4: b.ne            #0xc1d4c8
    // 0xc1d4b8: r0 = Null
    //     0xc1d4b8: mov             x0, NULL
    // 0xc1d4bc: LeaveFrame
    //     0xc1d4bc: mov             SP, fp
    //     0xc1d4c0: ldp             fp, lr, [SP], #0x10
    // 0xc1d4c4: ret
    //     0xc1d4c4: ret             
    // 0xc1d4c8: LoadField: r2 = r3->field_2b
    //     0xc1d4c8: ldur            w2, [x3, #0x2b]
    // 0xc1d4cc: DecompressPointer r2
    //     0xc1d4cc: add             x2, x2, HEAP, lsl #32
    // 0xc1d4d0: cmp             w2, NULL
    // 0xc1d4d4: b.eq            #0xc1d508
    // 0xc1d4d8: mov             x2, x3
    // 0xc1d4dc: r0 = _unregisterLeader()
    //     0xc1d4dc: bl              #0xc1d548  ; [package:flutter/src/rendering/layer.dart] LayerLink::_unregisterLeader
    // 0xc1d4e0: ldur            x0, [fp, #-8]
    // 0xc1d4e4: ldur            x1, [fp, #-0x10]
    // 0xc1d4e8: StoreField: r1->field_7 = r0
    //     0xc1d4e8: stur            w0, [x1, #7]
    //     0xc1d4ec: ldurb           w16, [x1, #-1]
    //     0xc1d4f0: ldurb           w17, [x0, #-1]
    //     0xc1d4f4: and             x16, x17, x16, lsr #2
    //     0xc1d4f8: tst             x16, HEAP, lsr #32
    //     0xc1d4fc: b.eq            #0xc1d504
    //     0xc1d500: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1d504: b               #0xc1d50c
    // 0xc1d508: mov             x1, x0
    // 0xc1d50c: ldur            x2, [fp, #-8]
    // 0xc1d510: mov             x0, x1
    // 0xc1d514: StoreField: r2->field_47 = r0
    //     0xc1d514: stur            w0, [x2, #0x47]
    //     0xc1d518: ldurb           w16, [x2, #-1]
    //     0xc1d51c: ldurb           w17, [x0, #-1]
    //     0xc1d520: and             x16, x17, x16, lsr #2
    //     0xc1d524: tst             x16, HEAP, lsr #32
    //     0xc1d528: b.eq            #0xc1d530
    //     0xc1d52c: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xc1d530: r0 = Null
    //     0xc1d530: mov             x0, NULL
    // 0xc1d534: LeaveFrame
    //     0xc1d534: mov             SP, fp
    //     0xc1d538: ldp             fp, lr, [SP], #0x10
    // 0xc1d53c: ret
    //     0xc1d53c: ret             
    // 0xc1d540: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1d540: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1d544: b               #0xc1d4a8
  }
  _ detach(/* No info */) {
    // ** addr: 0x110a6b0, size: 0x50
    // 0x110a6b0: EnterFrame
    //     0x110a6b0: stp             fp, lr, [SP, #-0x10]!
    //     0x110a6b4: mov             fp, SP
    // 0x110a6b8: AllocStack(0x8)
    //     0x110a6b8: sub             SP, SP, #8
    // 0x110a6bc: SetupParameters(LeaderLayer this /* r1 => r0, fp-0x8 */)
    //     0x110a6bc: mov             x0, x1
    //     0x110a6c0: stur            x1, [fp, #-8]
    // 0x110a6c4: CheckStackOverflow
    //     0x110a6c4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x110a6c8: cmp             SP, x16
    //     0x110a6cc: b.ls            #0x110a6f8
    // 0x110a6d0: LoadField: r1 = r0->field_47
    //     0x110a6d0: ldur            w1, [x0, #0x47]
    // 0x110a6d4: DecompressPointer r1
    //     0x110a6d4: add             x1, x1, HEAP, lsl #32
    // 0x110a6d8: mov             x2, x0
    // 0x110a6dc: r0 = _unregisterLeader()
    //     0x110a6dc: bl              #0xc1d548  ; [package:flutter/src/rendering/layer.dart] LayerLink::_unregisterLeader
    // 0x110a6e0: ldur            x1, [fp, #-8]
    // 0x110a6e4: r0 = detach()
    //     0x110a6e4: bl              #0x110a700  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::detach
    // 0x110a6e8: r0 = Null
    //     0x110a6e8: mov             x0, NULL
    // 0x110a6ec: LeaveFrame
    //     0x110a6ec: mov             SP, fp
    //     0x110a6f0: ldp             fp, lr, [SP], #0x10
    // 0x110a6f4: ret
    //     0x110a6f4: ret             
    // 0x110a6f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x110a6f8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x110a6fc: b               #0x110a6d0
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0x112c54c, size: 0x90
    // 0x112c54c: EnterFrame
    //     0x112c54c: stp             fp, lr, [SP, #-0x10]!
    //     0x112c550: mov             fp, SP
    // 0x112c554: AllocStack(0x28)
    //     0x112c554: sub             SP, SP, #0x28
    // 0x112c558: SetupParameters()
    //     0x112c558: ldur            w0, [x4, #0xf]
    //     0x112c55c: cbnz            w0, #0x112c568
    //     0x112c560: mov             x1, NULL
    //     0x112c564: b               #0x112c578
    //     0x112c568: ldur            w1, [x4, #0x17]
    //     0x112c56c: add             x2, fp, w1, sxtw #2
    //     0x112c570: ldr             x2, [x2, #0x10]
    //     0x112c574: mov             x1, x2
    // 0x112c578: CheckStackOverflow
    //     0x112c578: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c57c: cmp             SP, x16
    //     0x112c580: b.ls            #0x112c5d4
    // 0x112c584: cbnz            w0, #0x112c590
    // 0x112c588: r3 = <Object>
    //     0x112c588: ldr             x3, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112c58c: b               #0x112c594
    // 0x112c590: mov             x3, x1
    // 0x112c594: ldr             x0, [fp, #0x20]
    // 0x112c598: stur            x3, [fp, #-8]
    // 0x112c59c: LoadField: r2 = r0->field_4b
    //     0x112c59c: ldur            w2, [x0, #0x4b]
    // 0x112c5a0: DecompressPointer r2
    //     0x112c5a0: add             x2, x2, HEAP, lsl #32
    // 0x112c5a4: ldr             x1, [fp, #0x10]
    // 0x112c5a8: r0 = -()
    //     0x112c5a8: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x112c5ac: ldur            x16, [fp, #-8]
    // 0x112c5b0: ldr             lr, [fp, #0x20]
    // 0x112c5b4: stp             lr, x16, [SP, #0x10]
    // 0x112c5b8: ldr             x16, [fp, #0x18]
    // 0x112c5bc: stp             x0, x16, [SP]
    // 0x112c5c0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c5c0: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c5c4: r0 = findAnnotations()
    //     0x112c5c4: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112c5c8: LeaveFrame
    //     0x112c5c8: mov             SP, fp
    //     0x112c5cc: ldp             fp, lr, [SP], #0x10
    // 0x112c5d0: ret
    //     0x112c5d0: ret             
    // 0x112c5d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c5d4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c5d8: b               #0x112c584
  }
  _ attach(/* No info */) {
    // ** addr: 0x1146e14, size: 0x68
    // 0x1146e14: EnterFrame
    //     0x1146e14: stp             fp, lr, [SP, #-0x10]!
    //     0x1146e18: mov             fp, SP
    // 0x1146e1c: AllocStack(0x8)
    //     0x1146e1c: sub             SP, SP, #8
    // 0x1146e20: SetupParameters(LeaderLayer this /* r1 => r0, fp-0x8 */)
    //     0x1146e20: mov             x0, x1
    //     0x1146e24: stur            x1, [fp, #-8]
    // 0x1146e28: CheckStackOverflow
    //     0x1146e28: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1146e2c: cmp             SP, x16
    //     0x1146e30: b.ls            #0x1146e74
    // 0x1146e34: mov             x1, x0
    // 0x1146e38: r0 = attach()
    //     0x1146e38: bl              #0x1146e7c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::attach
    // 0x1146e3c: ldur            x0, [fp, #-8]
    // 0x1146e40: LoadField: r1 = r0->field_47
    //     0x1146e40: ldur            w1, [x0, #0x47]
    // 0x1146e44: DecompressPointer r1
    //     0x1146e44: add             x1, x1, HEAP, lsl #32
    // 0x1146e48: StoreField: r1->field_7 = r0
    //     0x1146e48: stur            w0, [x1, #7]
    //     0x1146e4c: ldurb           w16, [x1, #-1]
    //     0x1146e50: ldurb           w17, [x0, #-1]
    //     0x1146e54: and             x16, x17, x16, lsr #2
    //     0x1146e58: tst             x16, HEAP, lsr #32
    //     0x1146e5c: b.eq            #0x1146e64
    //     0x1146e60: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x1146e64: r0 = Null
    //     0x1146e64: mov             x0, NULL
    // 0x1146e68: LeaveFrame
    //     0x1146e68: mov             SP, fp
    //     0x1146e6c: ldp             fp, lr, [SP], #0x10
    // 0x1146e70: ret
    //     0x1146e70: ret             
    // 0x1146e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1146e74: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1146e78: b               #0x1146e34
  }
  _ applyTransform(/* No info */) {
    // ** addr: 0x115c75c, size: 0x74
    // 0x115c75c: EnterFrame
    //     0x115c75c: stp             fp, lr, [SP, #-0x10]!
    //     0x115c760: mov             fp, SP
    // 0x115c764: AllocStack(0x20)
    //     0x115c764: sub             SP, SP, #0x20
    // 0x115c768: SetupParameters(LeaderLayer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x115c768: mov             x0, x1
    //     0x115c76c: stur            x1, [fp, #-8]
    //     0x115c770: mov             x1, x2
    //     0x115c774: stur            x2, [fp, #-0x10]
    // 0x115c778: CheckStackOverflow
    //     0x115c778: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115c77c: cmp             SP, x16
    //     0x115c780: b.ls            #0x115c7c8
    // 0x115c784: LoadField: r2 = r0->field_4b
    //     0x115c784: ldur            w2, [x0, #0x4b]
    // 0x115c788: DecompressPointer r2
    //     0x115c788: add             x2, x2, HEAP, lsl #32
    // 0x115c78c: r16 = Instance_Offset
    //     0x115c78c: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x115c790: stp             x16, x2, [SP]
    // 0x115c794: r0 = ==()
    //     0x115c794: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x115c798: tbz             w0, #4, #0x115c7b8
    // 0x115c79c: ldur            x0, [fp, #-8]
    // 0x115c7a0: LoadField: r1 = r0->field_4b
    //     0x115c7a0: ldur            w1, [x0, #0x4b]
    // 0x115c7a4: DecompressPointer r1
    //     0x115c7a4: add             x1, x1, HEAP, lsl #32
    // 0x115c7a8: LoadField: d0 = r1->field_7
    //     0x115c7a8: ldur            d0, [x1, #7]
    // 0x115c7ac: LoadField: d1 = r1->field_f
    //     0x115c7ac: ldur            d1, [x1, #0xf]
    // 0x115c7b0: ldur            x1, [fp, #-0x10]
    // 0x115c7b4: r0 = translateByDouble()
    //     0x115c7b4: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0x115c7b8: r0 = Null
    //     0x115c7b8: mov             x0, NULL
    // 0x115c7bc: LeaveFrame
    //     0x115c7bc: mov             SP, fp
    //     0x115c7c0: ldp             fp, lr, [SP], #0x10
    // 0x115c7c4: ret
    //     0x115c7c4: ret             
    // 0x115c7c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115c7c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115c7cc: b               #0x115c784
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x11726e0, size: 0x12c
    // 0x11726e0: EnterFrame
    //     0x11726e0: stp             fp, lr, [SP, #-0x10]!
    //     0x11726e4: mov             fp, SP
    // 0x11726e8: AllocStack(0x30)
    //     0x11726e8: sub             SP, SP, #0x30
    // 0x11726ec: SetupParameters(LeaderLayer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x11726ec: mov             x0, x1
    //     0x11726f0: stur            x1, [fp, #-8]
    //     0x11726f4: mov             x1, x2
    //     0x11726f8: stur            x2, [fp, #-0x10]
    // 0x11726fc: CheckStackOverflow
    //     0x11726fc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1172700: cmp             SP, x16
    //     0x1172704: b.ls            #0x1172804
    // 0x1172708: LoadField: r2 = r0->field_4b
    //     0x1172708: ldur            w2, [x0, #0x4b]
    // 0x117270c: DecompressPointer r2
    //     0x117270c: add             x2, x2, HEAP, lsl #32
    // 0x1172710: r16 = Instance_Offset
    //     0x1172710: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x1172714: stp             x16, x2, [SP]
    // 0x1172718: r0 = ==()
    //     0x1172718: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x117271c: tbz             w0, #4, #0x11727b4
    // 0x1172720: ldur            x0, [fp, #-8]
    // 0x1172724: LoadField: r1 = r0->field_4b
    //     0x1172724: ldur            w1, [x0, #0x4b]
    // 0x1172728: DecompressPointer r1
    //     0x1172728: add             x1, x1, HEAP, lsl #32
    // 0x117272c: LoadField: d0 = r1->field_7
    //     0x117272c: ldur            d0, [x1, #7]
    // 0x1172730: LoadField: d1 = r1->field_f
    //     0x1172730: ldur            d1, [x1, #0xf]
    // 0x1172734: r1 = Null
    //     0x1172734: mov             x1, NULL
    // 0x1172738: r0 = Matrix4.translationValues()
    //     0x1172738: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0x117273c: LoadField: r3 = r0->field_7
    //     0x117273c: ldur            w3, [x0, #7]
    // 0x1172740: DecompressPointer r3
    //     0x1172740: add             x3, x3, HEAP, lsl #32
    // 0x1172744: ldur            x4, [fp, #-8]
    // 0x1172748: stur            x3, [fp, #-0x20]
    // 0x117274c: LoadField: r5 = r4->field_27
    //     0x117274c: ldur            w5, [x4, #0x27]
    // 0x1172750: DecompressPointer r5
    //     0x1172750: add             x5, x5, HEAP, lsl #32
    // 0x1172754: mov             x0, x5
    // 0x1172758: stur            x5, [fp, #-0x18]
    // 0x117275c: r2 = Null
    //     0x117275c: mov             x2, NULL
    // 0x1172760: r1 = Null
    //     0x1172760: mov             x1, NULL
    // 0x1172764: r4 = LoadClassIdInstr(r0)
    //     0x1172764: ldur            x4, [x0, #-1]
    //     0x1172768: ubfx            x4, x4, #0xc, #0x14
    // 0x117276c: cmp             x4, #0xeea
    // 0x1172770: b.eq            #0x1172788
    // 0x1172774: r8 = TransformEngineLayer?
    //     0x1172774: add             x8, PP, #0xd, lsl #12  ; [pp+0xde08] Type: TransformEngineLayer?
    //     0x1172778: ldr             x8, [x8, #0xe08]
    // 0x117277c: r3 = Null
    //     0x117277c: add             x3, PP, #0xcc, lsl #12  ; [pp+0xcc550] Null
    //     0x1172780: ldr             x3, [x3, #0x550]
    // 0x1172784: r0 = DefaultNullableTypeTest()
    //     0x1172784: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1172788: ldur            x16, [fp, #-0x18]
    // 0x117278c: str             x16, [SP]
    // 0x1172790: ldur            x1, [fp, #-0x10]
    // 0x1172794: ldur            x2, [fp, #-0x20]
    // 0x1172798: r4 = const [0, 0x3, 0x1, 0x2, oldLayer, 0x2, null]
    //     0x1172798: add             x4, PP, #0xd, lsl #12  ; [pp+0xde20] List(7) [0, 0x3, 0x1, 0x2, "oldLayer", 0x2, Null]
    //     0x117279c: ldr             x4, [x4, #0xe20]
    // 0x11727a0: r0 = pushTransform()
    //     0x11727a0: bl              #0xc1ea80  ; [dart:ui] _NativeSceneBuilder::pushTransform
    // 0x11727a4: ldur            x1, [fp, #-8]
    // 0x11727a8: mov             x2, x0
    // 0x11727ac: r0 = engineLayer=()
    //     0x11727ac: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x11727b0: b               #0x11727c0
    // 0x11727b4: ldur            x1, [fp, #-8]
    // 0x11727b8: r2 = Null
    //     0x11727b8: mov             x2, NULL
    // 0x11727bc: r0 = engineLayer=()
    //     0x11727bc: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x11727c0: ldur            x0, [fp, #-8]
    // 0x11727c4: mov             x1, x0
    // 0x11727c8: ldur            x2, [fp, #-0x10]
    // 0x11727cc: r0 = addChildrenToScene()
    //     0x11727cc: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x11727d0: ldur            x0, [fp, #-8]
    // 0x11727d4: LoadField: r1 = r0->field_4b
    //     0x11727d4: ldur            w1, [x0, #0x4b]
    // 0x11727d8: DecompressPointer r1
    //     0x11727d8: add             x1, x1, HEAP, lsl #32
    // 0x11727dc: r16 = Instance_Offset
    //     0x11727dc: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x11727e0: stp             x16, x1, [SP]
    // 0x11727e4: r0 = ==()
    //     0x11727e4: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x11727e8: tbz             w0, #4, #0x11727f4
    // 0x11727ec: ldur            x1, [fp, #-0x10]
    // 0x11727f0: r0 = pop()
    //     0x11727f0: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x11727f4: r0 = Null
    //     0x11727f4: mov             x0, NULL
    // 0x11727f8: LeaveFrame
    //     0x11727f8: mov             SP, fp
    //     0x11727fc: ldp             fp, lr, [SP], #0x10
    // 0x1172800: ret
    //     0x1172800: ret             
    // 0x1172804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1172804: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1172808: b               #0x1172708
  }
}

// class id: 4653, size: 0x54, field offset: 0x48
class BackdropFilterLayer extends ContainerLayer {

  set _ filter=(/* No info */) {
    // ** addr: 0xc18ee4, size: 0x94
    // 0xc18ee4: EnterFrame
    //     0xc18ee4: stp             fp, lr, [SP, #-0x10]!
    //     0xc18ee8: mov             fp, SP
    // 0xc18eec: AllocStack(0x20)
    //     0xc18eec: sub             SP, SP, #0x20
    // 0xc18ef0: SetupParameters(BackdropFilterLayer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xc18ef0: stur            x1, [fp, #-8]
    //     0xc18ef4: mov             x16, x2
    //     0xc18ef8: mov             x2, x1
    //     0xc18efc: mov             x1, x16
    //     0xc18f00: stur            x1, [fp, #-0x10]
    // 0xc18f04: CheckStackOverflow
    //     0xc18f04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18f08: cmp             SP, x16
    //     0xc18f0c: b.ls            #0xc18f70
    // 0xc18f10: LoadField: r0 = r2->field_47
    //     0xc18f10: ldur            w0, [x2, #0x47]
    // 0xc18f14: DecompressPointer r0
    //     0xc18f14: add             x0, x0, HEAP, lsl #32
    // 0xc18f18: r3 = LoadClassIdInstr(r1)
    //     0xc18f18: ldur            x3, [x1, #-1]
    //     0xc18f1c: ubfx            x3, x3, #0xc, #0x14
    // 0xc18f20: stp             x0, x1, [SP]
    // 0xc18f24: mov             x0, x3
    // 0xc18f28: mov             lr, x0
    // 0xc18f2c: ldr             lr, [x21, lr, lsl #3]
    // 0xc18f30: blr             lr
    // 0xc18f34: tbz             w0, #4, #0xc18f60
    // 0xc18f38: ldur            x1, [fp, #-8]
    // 0xc18f3c: ldur            x0, [fp, #-0x10]
    // 0xc18f40: StoreField: r1->field_47 = r0
    //     0xc18f40: stur            w0, [x1, #0x47]
    //     0xc18f44: ldurb           w16, [x1, #-1]
    //     0xc18f48: ldurb           w17, [x0, #-1]
    //     0xc18f4c: and             x16, x17, x16, lsr #2
    //     0xc18f50: tst             x16, HEAP, lsr #32
    //     0xc18f54: b.eq            #0xc18f5c
    //     0xc18f58: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc18f5c: r0 = markNeedsAddToScene()
    //     0xc18f5c: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc18f60: r0 = Null
    //     0xc18f60: mov             x0, NULL
    // 0xc18f64: LeaveFrame
    //     0xc18f64: mov             SP, fp
    //     0xc18f68: ldp             fp, lr, [SP], #0x10
    // 0xc18f6c: ret
    //     0xc18f6c: ret             
    // 0xc18f70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc18f70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18f74: b               #0xc18f10
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x11722c4, size: 0xd0
    // 0x11722c4: EnterFrame
    //     0x11722c4: stp             fp, lr, [SP, #-0x10]!
    //     0x11722c8: mov             fp, SP
    // 0x11722cc: AllocStack(0x20)
    //     0x11722cc: sub             SP, SP, #0x20
    // 0x11722d0: SetupParameters(BackdropFilterLayer this /* r1 => r4, fp-0x18 */, dynamic _ /* r2 => r3, fp-0x20 */)
    //     0x11722d0: mov             x4, x1
    //     0x11722d4: mov             x3, x2
    //     0x11722d8: stur            x1, [fp, #-0x18]
    //     0x11722dc: stur            x2, [fp, #-0x20]
    // 0x11722e0: CheckStackOverflow
    //     0x11722e0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11722e4: cmp             SP, x16
    //     0x11722e8: b.ls            #0x1172388
    // 0x11722ec: LoadField: r5 = r4->field_47
    //     0x11722ec: ldur            w5, [x4, #0x47]
    // 0x11722f0: DecompressPointer r5
    //     0x11722f0: add             x5, x5, HEAP, lsl #32
    // 0x11722f4: stur            x5, [fp, #-0x10]
    // 0x11722f8: cmp             w5, NULL
    // 0x11722fc: b.eq            #0x1172390
    // 0x1172300: LoadField: r6 = r4->field_27
    //     0x1172300: ldur            w6, [x4, #0x27]
    // 0x1172304: DecompressPointer r6
    //     0x1172304: add             x6, x6, HEAP, lsl #32
    // 0x1172308: mov             x0, x6
    // 0x117230c: stur            x6, [fp, #-8]
    // 0x1172310: r2 = Null
    //     0x1172310: mov             x2, NULL
    // 0x1172314: r1 = Null
    //     0x1172314: mov             x1, NULL
    // 0x1172318: r4 = LoadClassIdInstr(r0)
    //     0x1172318: ldur            x4, [x0, #-1]
    //     0x117231c: ubfx            x4, x4, #0xc, #0x14
    // 0x1172320: cmp             x4, #0xee1
    // 0x1172324: b.eq            #0x117233c
    // 0x1172328: r8 = BackdropFilterEngineLayer?
    //     0x1172328: add             x8, PP, #0x98, lsl #12  ; [pp+0x98598] Type: BackdropFilterEngineLayer?
    //     0x117232c: ldr             x8, [x8, #0x598]
    // 0x1172330: r3 = Null
    //     0x1172330: add             x3, PP, #0x98, lsl #12  ; [pp+0x985a0] Null
    //     0x1172334: ldr             x3, [x3, #0x5a0]
    // 0x1172338: r0 = DefaultNullableTypeTest()
    //     0x1172338: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x117233c: ldur            x1, [fp, #-0x20]
    // 0x1172340: ldur            x2, [fp, #-0x10]
    // 0x1172344: ldur            x6, [fp, #-8]
    // 0x1172348: r3 = Null
    //     0x1172348: mov             x3, NULL
    // 0x117234c: r5 = Instance_BlendMode
    //     0x117234c: add             x5, PP, #0x16, lsl #12  ; [pp+0x16eb8] Obj!BlendMode@12c82e1
    //     0x1172350: ldr             x5, [x5, #0xeb8]
    // 0x1172354: r0 = pushBackdropFilter()
    //     0x1172354: bl              #0x1172394  ; [dart:ui] _NativeSceneBuilder::pushBackdropFilter
    // 0x1172358: ldur            x1, [fp, #-0x18]
    // 0x117235c: mov             x2, x0
    // 0x1172360: r0 = engineLayer=()
    //     0x1172360: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1172364: ldur            x1, [fp, #-0x18]
    // 0x1172368: ldur            x2, [fp, #-0x20]
    // 0x117236c: r0 = addChildrenToScene()
    //     0x117236c: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x1172370: ldur            x1, [fp, #-0x20]
    // 0x1172374: r0 = pop()
    //     0x1172374: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x1172378: r0 = Null
    //     0x1172378: mov             x0, NULL
    // 0x117237c: LeaveFrame
    //     0x117237c: mov             SP, fp
    //     0x1172380: ldp             fp, lr, [SP], #0x10
    // 0x1172384: ret
    //     0x1172384: ret             
    // 0x1172388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1172388: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x117238c: b               #0x11722ec
    // 0x1172390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1172390: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4654, size: 0x54, field offset: 0x48
class ShaderMaskLayer extends ContainerLayer {

  set _ blendMode=(/* No info */) {
    // ** addr: 0xc1888c, size: 0x60
    // 0xc1888c: EnterFrame
    //     0xc1888c: stp             fp, lr, [SP, #-0x10]!
    //     0xc18890: mov             fp, SP
    // 0xc18894: mov             x0, x2
    // 0xc18898: CheckStackOverflow
    //     0xc18898: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1889c: cmp             SP, x16
    //     0xc188a0: b.ls            #0xc188e4
    // 0xc188a4: LoadField: r2 = r1->field_4f
    //     0xc188a4: ldur            w2, [x1, #0x4f]
    // 0xc188a8: DecompressPointer r2
    //     0xc188a8: add             x2, x2, HEAP, lsl #32
    // 0xc188ac: cmp             w0, w2
    // 0xc188b0: b.eq            #0xc188d4
    // 0xc188b4: StoreField: r1->field_4f = r0
    //     0xc188b4: stur            w0, [x1, #0x4f]
    //     0xc188b8: ldurb           w16, [x1, #-1]
    //     0xc188bc: ldurb           w17, [x0, #-1]
    //     0xc188c0: and             x16, x17, x16, lsr #2
    //     0xc188c4: tst             x16, HEAP, lsr #32
    //     0xc188c8: b.eq            #0xc188d0
    //     0xc188cc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc188d0: r0 = markNeedsAddToScene()
    //     0xc188d0: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc188d4: r0 = Null
    //     0xc188d4: mov             x0, NULL
    // 0xc188d8: LeaveFrame
    //     0xc188d8: mov             SP, fp
    //     0xc188dc: ldp             fp, lr, [SP], #0x10
    // 0xc188e0: ret
    //     0xc188e0: ret             
    // 0xc188e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc188e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc188e8: b               #0xc188a4
  }
  set _ maskRect=(/* No info */) {
    // ** addr: 0xc188ec, size: 0x78
    // 0xc188ec: EnterFrame
    //     0xc188ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc188f0: mov             fp, SP
    // 0xc188f4: AllocStack(0x20)
    //     0xc188f4: sub             SP, SP, #0x20
    // 0xc188f8: SetupParameters(ShaderMaskLayer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc188f8: mov             x0, x2
    //     0xc188fc: stur            x1, [fp, #-8]
    //     0xc18900: stur            x2, [fp, #-0x10]
    // 0xc18904: CheckStackOverflow
    //     0xc18904: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18908: cmp             SP, x16
    //     0xc1890c: b.ls            #0xc1895c
    // 0xc18910: LoadField: r2 = r1->field_4b
    //     0xc18910: ldur            w2, [x1, #0x4b]
    // 0xc18914: DecompressPointer r2
    //     0xc18914: add             x2, x2, HEAP, lsl #32
    // 0xc18918: stp             x2, x0, [SP]
    // 0xc1891c: r0 = ==()
    //     0xc1891c: bl              #0x128bdfc  ; [dart:ui] Rect::==
    // 0xc18920: tbz             w0, #4, #0xc1894c
    // 0xc18924: ldur            x1, [fp, #-8]
    // 0xc18928: ldur            x0, [fp, #-0x10]
    // 0xc1892c: StoreField: r1->field_4b = r0
    //     0xc1892c: stur            w0, [x1, #0x4b]
    //     0xc18930: ldurb           w16, [x1, #-1]
    //     0xc18934: ldurb           w17, [x0, #-1]
    //     0xc18938: and             x16, x17, x16, lsr #2
    //     0xc1893c: tst             x16, HEAP, lsr #32
    //     0xc18940: b.eq            #0xc18948
    //     0xc18944: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc18948: r0 = markNeedsAddToScene()
    //     0xc18948: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc1894c: r0 = Null
    //     0xc1894c: mov             x0, NULL
    // 0xc18950: LeaveFrame
    //     0xc18950: mov             SP, fp
    //     0xc18954: ldp             fp, lr, [SP], #0x10
    // 0xc18958: ret
    //     0xc18958: ret             
    // 0xc1895c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1895c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc18960: b               #0xc18910
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x1171e4c, size: 0xfc
    // 0x1171e4c: EnterFrame
    //     0x1171e4c: stp             fp, lr, [SP, #-0x10]!
    //     0x1171e50: mov             fp, SP
    // 0x1171e54: AllocStack(0x30)
    //     0x1171e54: sub             SP, SP, #0x30
    // 0x1171e58: SetupParameters(ShaderMaskLayer this /* r1 => r4, fp-0x28 */, dynamic _ /* r2 => r3, fp-0x30 */)
    //     0x1171e58: mov             x4, x1
    //     0x1171e5c: mov             x3, x2
    //     0x1171e60: stur            x1, [fp, #-0x28]
    //     0x1171e64: stur            x2, [fp, #-0x30]
    // 0x1171e68: CheckStackOverflow
    //     0x1171e68: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1171e6c: cmp             SP, x16
    //     0x1171e70: b.ls            #0x1171f34
    // 0x1171e74: LoadField: r5 = r4->field_47
    //     0x1171e74: ldur            w5, [x4, #0x47]
    // 0x1171e78: DecompressPointer r5
    //     0x1171e78: add             x5, x5, HEAP, lsl #32
    // 0x1171e7c: stur            x5, [fp, #-0x20]
    // 0x1171e80: cmp             w5, NULL
    // 0x1171e84: b.eq            #0x1171f3c
    // 0x1171e88: LoadField: r6 = r4->field_4b
    //     0x1171e88: ldur            w6, [x4, #0x4b]
    // 0x1171e8c: DecompressPointer r6
    //     0x1171e8c: add             x6, x6, HEAP, lsl #32
    // 0x1171e90: stur            x6, [fp, #-0x18]
    // 0x1171e94: cmp             w6, NULL
    // 0x1171e98: b.eq            #0x1171f40
    // 0x1171e9c: LoadField: r7 = r4->field_4f
    //     0x1171e9c: ldur            w7, [x4, #0x4f]
    // 0x1171ea0: DecompressPointer r7
    //     0x1171ea0: add             x7, x7, HEAP, lsl #32
    // 0x1171ea4: stur            x7, [fp, #-0x10]
    // 0x1171ea8: cmp             w7, NULL
    // 0x1171eac: b.eq            #0x1171f44
    // 0x1171eb0: LoadField: r8 = r4->field_27
    //     0x1171eb0: ldur            w8, [x4, #0x27]
    // 0x1171eb4: DecompressPointer r8
    //     0x1171eb4: add             x8, x8, HEAP, lsl #32
    // 0x1171eb8: mov             x0, x8
    // 0x1171ebc: stur            x8, [fp, #-8]
    // 0x1171ec0: r2 = Null
    //     0x1171ec0: mov             x2, NULL
    // 0x1171ec4: r1 = Null
    //     0x1171ec4: mov             x1, NULL
    // 0x1171ec8: r4 = LoadClassIdInstr(r0)
    //     0x1171ec8: ldur            x4, [x0, #-1]
    //     0x1171ecc: ubfx            x4, x4, #0xc, #0x14
    // 0x1171ed0: cmp             x4, #0xee0
    // 0x1171ed4: b.eq            #0x1171eec
    // 0x1171ed8: r8 = ShaderMaskEngineLayer?
    //     0x1171ed8: add             x8, PP, #0xa2, lsl #12  ; [pp+0xa2978] Type: ShaderMaskEngineLayer?
    //     0x1171edc: ldr             x8, [x8, #0x978]
    // 0x1171ee0: r3 = Null
    //     0x1171ee0: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2980] Null
    //     0x1171ee4: ldr             x3, [x3, #0x980]
    // 0x1171ee8: r0 = DefaultNullableTypeTest()
    //     0x1171ee8: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1171eec: ldur            x1, [fp, #-0x30]
    // 0x1171ef0: ldur            x2, [fp, #-0x20]
    // 0x1171ef4: ldur            x3, [fp, #-0x18]
    // 0x1171ef8: ldur            x5, [fp, #-0x10]
    // 0x1171efc: ldur            x6, [fp, #-8]
    // 0x1171f00: r0 = pushShaderMask()
    //     0x1171f00: bl              #0x1171f48  ; [dart:ui] _NativeSceneBuilder::pushShaderMask
    // 0x1171f04: ldur            x1, [fp, #-0x28]
    // 0x1171f08: mov             x2, x0
    // 0x1171f0c: r0 = engineLayer=()
    //     0x1171f0c: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1171f10: ldur            x1, [fp, #-0x28]
    // 0x1171f14: ldur            x2, [fp, #-0x30]
    // 0x1171f18: r0 = addChildrenToScene()
    //     0x1171f18: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x1171f1c: ldur            x1, [fp, #-0x30]
    // 0x1171f20: r0 = pop()
    //     0x1171f20: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x1171f24: r0 = Null
    //     0x1171f24: mov             x0, NULL
    // 0x1171f28: LeaveFrame
    //     0x1171f28: mov             SP, fp
    //     0x1171f2c: ldp             fp, lr, [SP], #0x10
    // 0x1171f30: ret
    //     0x1171f30: ret             
    // 0x1171f34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1171f34: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1171f38: b               #0x1171e74
    // 0x1171f3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1171f3c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1171f40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1171f40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1171f44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1171f44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4656, size: 0x50, field offset: 0x48
class ClipPathLayer extends ContainerLayer {

  set _ clipPath=(/* No info */) {
    // ** addr: 0xc18964, size: 0x60
    // 0xc18964: EnterFrame
    //     0xc18964: stp             fp, lr, [SP, #-0x10]!
    //     0xc18968: mov             fp, SP
    // 0xc1896c: mov             x0, x2
    // 0xc18970: CheckStackOverflow
    //     0xc18970: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc18974: cmp             SP, x16
    //     0xc18978: b.ls            #0xc189bc
    // 0xc1897c: LoadField: r2 = r1->field_47
    //     0xc1897c: ldur            w2, [x1, #0x47]
    // 0xc18980: DecompressPointer r2
    //     0xc18980: add             x2, x2, HEAP, lsl #32
    // 0xc18984: cmp             w0, w2
    // 0xc18988: b.eq            #0xc189ac
    // 0xc1898c: StoreField: r1->field_47 = r0
    //     0xc1898c: stur            w0, [x1, #0x47]
    //     0xc18990: ldurb           w16, [x1, #-1]
    //     0xc18994: ldurb           w17, [x0, #-1]
    //     0xc18998: and             x16, x17, x16, lsr #2
    //     0xc1899c: tst             x16, HEAP, lsr #32
    //     0xc189a0: b.eq            #0xc189a8
    //     0xc189a4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc189a8: r0 = markNeedsAddToScene()
    //     0xc189a8: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc189ac: r0 = Null
    //     0xc189ac: mov             x0, NULL
    // 0xc189b0: LeaveFrame
    //     0xc189b0: mov             SP, fp
    //     0xc189b4: ldp             fp, lr, [SP], #0x10
    // 0xc189b8: ret
    //     0xc189b8: ret             
    // 0xc189bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc189bc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc189c0: b               #0xc1897c
  }
  set _ clipBehavior=(/* No info */) {
    // ** addr: 0xc19974, size: 0x60
    // 0xc19974: EnterFrame
    //     0xc19974: stp             fp, lr, [SP, #-0x10]!
    //     0xc19978: mov             fp, SP
    // 0xc1997c: mov             x0, x2
    // 0xc19980: CheckStackOverflow
    //     0xc19980: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc19984: cmp             SP, x16
    //     0xc19988: b.ls            #0xc199cc
    // 0xc1998c: LoadField: r2 = r1->field_4b
    //     0xc1998c: ldur            w2, [x1, #0x4b]
    // 0xc19990: DecompressPointer r2
    //     0xc19990: add             x2, x2, HEAP, lsl #32
    // 0xc19994: cmp             w0, w2
    // 0xc19998: b.eq            #0xc199bc
    // 0xc1999c: StoreField: r1->field_4b = r0
    //     0xc1999c: stur            w0, [x1, #0x4b]
    //     0xc199a0: ldurb           w16, [x1, #-1]
    //     0xc199a4: ldurb           w17, [x0, #-1]
    //     0xc199a8: and             x16, x17, x16, lsr #2
    //     0xc199ac: tst             x16, HEAP, lsr #32
    //     0xc199b0: b.eq            #0xc199b8
    //     0xc199b4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc199b8: r0 = markNeedsAddToScene()
    //     0xc199b8: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc199bc: r0 = Null
    //     0xc199bc: mov             x0, NULL
    // 0xc199c0: LeaveFrame
    //     0xc199c0: mov             SP, fp
    //     0xc199c4: ldp             fp, lr, [SP], #0x10
    // 0xc199c8: ret
    //     0xc199c8: ret             
    // 0xc199cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc199cc: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc199d0: b               #0xc1998c
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0x112c388, size: 0xb4
    // 0x112c388: EnterFrame
    //     0x112c388: stp             fp, lr, [SP, #-0x10]!
    //     0x112c38c: mov             fp, SP
    // 0x112c390: AllocStack(0x28)
    //     0x112c390: sub             SP, SP, #0x28
    // 0x112c394: SetupParameters()
    //     0x112c394: ldur            w0, [x4, #0xf]
    //     0x112c398: cbnz            w0, #0x112c3a4
    //     0x112c39c: mov             x1, NULL
    //     0x112c3a0: b               #0x112c3b4
    //     0x112c3a4: ldur            w1, [x4, #0x17]
    //     0x112c3a8: add             x2, fp, w1, sxtw #2
    //     0x112c3ac: ldr             x2, [x2, #0x10]
    //     0x112c3b0: mov             x1, x2
    // 0x112c3b4: CheckStackOverflow
    //     0x112c3b4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c3b8: cmp             SP, x16
    //     0x112c3bc: b.ls            #0x112c430
    // 0x112c3c0: cbnz            w0, #0x112c3cc
    // 0x112c3c4: r3 = <Object>
    //     0x112c3c4: ldr             x3, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112c3c8: b               #0x112c3d0
    // 0x112c3cc: mov             x3, x1
    // 0x112c3d0: ldr             x0, [fp, #0x20]
    // 0x112c3d4: stur            x3, [fp, #-8]
    // 0x112c3d8: LoadField: r1 = r0->field_47
    //     0x112c3d8: ldur            w1, [x0, #0x47]
    // 0x112c3dc: DecompressPointer r1
    //     0x112c3dc: add             x1, x1, HEAP, lsl #32
    // 0x112c3e0: cmp             w1, NULL
    // 0x112c3e4: b.eq            #0x112c438
    // 0x112c3e8: ldr             x2, [fp, #0x10]
    // 0x112c3ec: r0 = contains()
    //     0x112c3ec: bl              #0xaf9104  ; [dart:ui] _NativePath::contains
    // 0x112c3f0: tbz             w0, #4, #0x112c404
    // 0x112c3f4: r0 = false
    //     0x112c3f4: add             x0, NULL, #0x30  ; false
    // 0x112c3f8: LeaveFrame
    //     0x112c3f8: mov             SP, fp
    //     0x112c3fc: ldp             fp, lr, [SP], #0x10
    // 0x112c400: ret
    //     0x112c400: ret             
    // 0x112c404: ldur            x16, [fp, #-8]
    // 0x112c408: ldr             lr, [fp, #0x20]
    // 0x112c40c: stp             lr, x16, [SP, #0x10]
    // 0x112c410: ldr             x16, [fp, #0x18]
    // 0x112c414: ldr             lr, [fp, #0x10]
    // 0x112c418: stp             lr, x16, [SP]
    // 0x112c41c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c41c: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c420: r0 = findAnnotations()
    //     0x112c420: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112c424: LeaveFrame
    //     0x112c424: mov             SP, fp
    //     0x112c428: ldp             fp, lr, [SP], #0x10
    // 0x112c42c: ret
    //     0x112c42c: ret             
    // 0x112c430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c430: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c434: b               #0x112c3c0
    // 0x112c438: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x112c438: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x1171a64, size: 0xd4
    // 0x1171a64: EnterFrame
    //     0x1171a64: stp             fp, lr, [SP, #-0x10]!
    //     0x1171a68: mov             fp, SP
    // 0x1171a6c: AllocStack(0x28)
    //     0x1171a6c: sub             SP, SP, #0x28
    // 0x1171a70: SetupParameters(ClipPathLayer this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x28 */)
    //     0x1171a70: mov             x4, x1
    //     0x1171a74: mov             x3, x2
    //     0x1171a78: stur            x1, [fp, #-0x20]
    //     0x1171a7c: stur            x2, [fp, #-0x28]
    // 0x1171a80: CheckStackOverflow
    //     0x1171a80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1171a84: cmp             SP, x16
    //     0x1171a88: b.ls            #0x1171b2c
    // 0x1171a8c: LoadField: r5 = r4->field_47
    //     0x1171a8c: ldur            w5, [x4, #0x47]
    // 0x1171a90: DecompressPointer r5
    //     0x1171a90: add             x5, x5, HEAP, lsl #32
    // 0x1171a94: stur            x5, [fp, #-0x18]
    // 0x1171a98: cmp             w5, NULL
    // 0x1171a9c: b.eq            #0x1171b34
    // 0x1171aa0: LoadField: r6 = r4->field_4b
    //     0x1171aa0: ldur            w6, [x4, #0x4b]
    // 0x1171aa4: DecompressPointer r6
    //     0x1171aa4: add             x6, x6, HEAP, lsl #32
    // 0x1171aa8: stur            x6, [fp, #-0x10]
    // 0x1171aac: LoadField: r7 = r4->field_27
    //     0x1171aac: ldur            w7, [x4, #0x27]
    // 0x1171ab0: DecompressPointer r7
    //     0x1171ab0: add             x7, x7, HEAP, lsl #32
    // 0x1171ab4: mov             x0, x7
    // 0x1171ab8: stur            x7, [fp, #-8]
    // 0x1171abc: r2 = Null
    //     0x1171abc: mov             x2, NULL
    // 0x1171ac0: r1 = Null
    //     0x1171ac0: mov             x1, NULL
    // 0x1171ac4: r4 = LoadClassIdInstr(r0)
    //     0x1171ac4: ldur            x4, [x0, #-1]
    //     0x1171ac8: ubfx            x4, x4, #0xc, #0x14
    // 0x1171acc: cmp             x4, #0xee5
    // 0x1171ad0: b.eq            #0x1171ae8
    // 0x1171ad4: r8 = ClipPathEngineLayer?
    //     0x1171ad4: add             x8, PP, #0x98, lsl #12  ; [pp+0x98570] Type: ClipPathEngineLayer?
    //     0x1171ad8: ldr             x8, [x8, #0x570]
    // 0x1171adc: r3 = Null
    //     0x1171adc: add             x3, PP, #0x98, lsl #12  ; [pp+0x98578] Null
    //     0x1171ae0: ldr             x3, [x3, #0x578]
    // 0x1171ae4: r0 = DefaultNullableTypeTest()
    //     0x1171ae4: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1171ae8: ldur            x1, [fp, #-0x28]
    // 0x1171aec: ldur            x2, [fp, #-0x18]
    // 0x1171af0: ldur            x3, [fp, #-0x10]
    // 0x1171af4: ldur            x5, [fp, #-8]
    // 0x1171af8: r0 = pushClipPath()
    //     0x1171af8: bl              #0x1171b38  ; [dart:ui] _NativeSceneBuilder::pushClipPath
    // 0x1171afc: ldur            x1, [fp, #-0x20]
    // 0x1171b00: mov             x2, x0
    // 0x1171b04: r0 = engineLayer=()
    //     0x1171b04: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1171b08: ldur            x1, [fp, #-0x20]
    // 0x1171b0c: ldur            x2, [fp, #-0x28]
    // 0x1171b10: r0 = addChildrenToScene()
    //     0x1171b10: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x1171b14: ldur            x1, [fp, #-0x28]
    // 0x1171b18: r0 = pop()
    //     0x1171b18: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x1171b1c: r0 = Null
    //     0x1171b1c: mov             x0, NULL
    // 0x1171b20: LeaveFrame
    //     0x1171b20: mov             SP, fp
    //     0x1171b24: ldp             fp, lr, [SP], #0x10
    // 0x1171b28: ret
    //     0x1171b28: ret             
    // 0x1171b2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1171b2c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1171b30: b               #0x1171a8c
    // 0x1171b34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1171b34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4657, size: 0x50, field offset: 0x48
class ClipRSuperellipseLayer extends ContainerLayer {

  set _ clipRSuperellipse=(/* No info */) {
    // ** addr: 0xc1a018, size: 0x78
    // 0xc1a018: EnterFrame
    //     0xc1a018: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a01c: mov             fp, SP
    // 0xc1a020: AllocStack(0x20)
    //     0xc1a020: sub             SP, SP, #0x20
    // 0xc1a024: SetupParameters(ClipRSuperellipseLayer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc1a024: mov             x0, x2
    //     0xc1a028: stur            x1, [fp, #-8]
    //     0xc1a02c: stur            x2, [fp, #-0x10]
    // 0xc1a030: CheckStackOverflow
    //     0xc1a030: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1a034: cmp             SP, x16
    //     0xc1a038: b.ls            #0xc1a088
    // 0xc1a03c: LoadField: r2 = r1->field_47
    //     0xc1a03c: ldur            w2, [x1, #0x47]
    // 0xc1a040: DecompressPointer r2
    //     0xc1a040: add             x2, x2, HEAP, lsl #32
    // 0xc1a044: stp             x2, x0, [SP]
    // 0xc1a048: r0 = ==()
    //     0xc1a048: bl              #0x128bfe0  ; [dart:ui] _RRectLike::==
    // 0xc1a04c: tbz             w0, #4, #0xc1a078
    // 0xc1a050: ldur            x1, [fp, #-8]
    // 0xc1a054: ldur            x0, [fp, #-0x10]
    // 0xc1a058: StoreField: r1->field_47 = r0
    //     0xc1a058: stur            w0, [x1, #0x47]
    //     0xc1a05c: ldurb           w16, [x1, #-1]
    //     0xc1a060: ldurb           w17, [x0, #-1]
    //     0xc1a064: and             x16, x17, x16, lsr #2
    //     0xc1a068: tst             x16, HEAP, lsr #32
    //     0xc1a06c: b.eq            #0xc1a074
    //     0xc1a070: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1a074: r0 = markNeedsAddToScene()
    //     0xc1a074: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc1a078: r0 = Null
    //     0xc1a078: mov             x0, NULL
    // 0xc1a07c: LeaveFrame
    //     0xc1a07c: mov             SP, fp
    //     0xc1a080: ldp             fp, lr, [SP], #0x10
    // 0xc1a084: ret
    //     0xc1a084: ret             
    // 0xc1a088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a088: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a08c: b               #0xc1a03c
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0x112c2cc, size: 0xbc
    // 0x112c2cc: EnterFrame
    //     0x112c2cc: stp             fp, lr, [SP, #-0x10]!
    //     0x112c2d0: mov             fp, SP
    // 0x112c2d4: AllocStack(0x28)
    //     0x112c2d4: sub             SP, SP, #0x28
    // 0x112c2d8: SetupParameters()
    //     0x112c2d8: ldur            w0, [x4, #0xf]
    //     0x112c2dc: cbnz            w0, #0x112c2e8
    //     0x112c2e0: mov             x1, NULL
    //     0x112c2e4: b               #0x112c2f8
    //     0x112c2e8: ldur            w1, [x4, #0x17]
    //     0x112c2ec: add             x2, fp, w1, sxtw #2
    //     0x112c2f0: ldr             x2, [x2, #0x10]
    //     0x112c2f4: mov             x1, x2
    // 0x112c2f8: CheckStackOverflow
    //     0x112c2f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c2fc: cmp             SP, x16
    //     0x112c300: b.ls            #0x112c37c
    // 0x112c304: cbnz            w0, #0x112c310
    // 0x112c308: r2 = <Object>
    //     0x112c308: ldr             x2, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112c30c: b               #0x112c314
    // 0x112c310: mov             x2, x1
    // 0x112c314: ldr             x0, [fp, #0x20]
    // 0x112c318: stur            x2, [fp, #-8]
    // 0x112c31c: LoadField: r1 = r0->field_47
    //     0x112c31c: ldur            w1, [x0, #0x47]
    // 0x112c320: DecompressPointer r1
    //     0x112c320: add             x1, x1, HEAP, lsl #32
    // 0x112c324: cmp             w1, NULL
    // 0x112c328: b.eq            #0x112c384
    // 0x112c32c: r0 = outerRect()
    //     0x112c32c: bl              #0xaf8a18  ; [dart:ui] _RRectLike::outerRect
    // 0x112c330: mov             x1, x0
    // 0x112c334: ldr             x2, [fp, #0x10]
    // 0x112c338: r0 = contains()
    //     0x112c338: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0x112c33c: tbz             w0, #4, #0x112c350
    // 0x112c340: r0 = false
    //     0x112c340: add             x0, NULL, #0x30  ; false
    // 0x112c344: LeaveFrame
    //     0x112c344: mov             SP, fp
    //     0x112c348: ldp             fp, lr, [SP], #0x10
    // 0x112c34c: ret
    //     0x112c34c: ret             
    // 0x112c350: ldur            x16, [fp, #-8]
    // 0x112c354: ldr             lr, [fp, #0x20]
    // 0x112c358: stp             lr, x16, [SP, #0x10]
    // 0x112c35c: ldr             x16, [fp, #0x18]
    // 0x112c360: ldr             lr, [fp, #0x10]
    // 0x112c364: stp             lr, x16, [SP]
    // 0x112c368: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c368: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c36c: r0 = findAnnotations()
    //     0x112c36c: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112c370: LeaveFrame
    //     0x112c370: mov             SP, fp
    //     0x112c374: ldp             fp, lr, [SP], #0x10
    // 0x112c378: ret
    //     0x112c378: ret             
    // 0x112c37c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c37c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c380: b               #0x112c304
    // 0x112c384: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x112c384: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x117165c, size: 0xd4
    // 0x117165c: EnterFrame
    //     0x117165c: stp             fp, lr, [SP, #-0x10]!
    //     0x1171660: mov             fp, SP
    // 0x1171664: AllocStack(0x28)
    //     0x1171664: sub             SP, SP, #0x28
    // 0x1171668: SetupParameters(ClipRSuperellipseLayer this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x28 */)
    //     0x1171668: mov             x4, x1
    //     0x117166c: mov             x3, x2
    //     0x1171670: stur            x1, [fp, #-0x20]
    //     0x1171674: stur            x2, [fp, #-0x28]
    // 0x1171678: CheckStackOverflow
    //     0x1171678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x117167c: cmp             SP, x16
    //     0x1171680: b.ls            #0x1171724
    // 0x1171684: LoadField: r5 = r4->field_47
    //     0x1171684: ldur            w5, [x4, #0x47]
    // 0x1171688: DecompressPointer r5
    //     0x1171688: add             x5, x5, HEAP, lsl #32
    // 0x117168c: stur            x5, [fp, #-0x18]
    // 0x1171690: cmp             w5, NULL
    // 0x1171694: b.eq            #0x117172c
    // 0x1171698: LoadField: r6 = r4->field_4b
    //     0x1171698: ldur            w6, [x4, #0x4b]
    // 0x117169c: DecompressPointer r6
    //     0x117169c: add             x6, x6, HEAP, lsl #32
    // 0x11716a0: stur            x6, [fp, #-0x10]
    // 0x11716a4: LoadField: r7 = r4->field_27
    //     0x11716a4: ldur            w7, [x4, #0x27]
    // 0x11716a8: DecompressPointer r7
    //     0x11716a8: add             x7, x7, HEAP, lsl #32
    // 0x11716ac: mov             x0, x7
    // 0x11716b0: stur            x7, [fp, #-8]
    // 0x11716b4: r2 = Null
    //     0x11716b4: mov             x2, NULL
    // 0x11716b8: r1 = Null
    //     0x11716b8: mov             x1, NULL
    // 0x11716bc: r4 = LoadClassIdInstr(r0)
    //     0x11716bc: ldur            x4, [x0, #-1]
    //     0x11716c0: ubfx            x4, x4, #0xc, #0x14
    // 0x11716c4: cmp             x4, #0xee6
    // 0x11716c8: b.eq            #0x11716e0
    // 0x11716cc: r8 = ClipRSuperellipseEngineLayer?
    //     0x11716cc: add             x8, PP, #0xd2, lsl #12  ; [pp+0xd2800] Type: ClipRSuperellipseEngineLayer?
    //     0x11716d0: ldr             x8, [x8, #0x800]
    // 0x11716d4: r3 = Null
    //     0x11716d4: add             x3, PP, #0xd2, lsl #12  ; [pp+0xd2808] Null
    //     0x11716d8: ldr             x3, [x3, #0x808]
    // 0x11716dc: r0 = DefaultNullableTypeTest()
    //     0x11716dc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x11716e0: ldur            x1, [fp, #-0x28]
    // 0x11716e4: ldur            x2, [fp, #-0x18]
    // 0x11716e8: ldur            x3, [fp, #-0x10]
    // 0x11716ec: ldur            x5, [fp, #-8]
    // 0x11716f0: r0 = pushClipRSuperellipse()
    //     0x11716f0: bl              #0x1171730  ; [dart:ui] _NativeSceneBuilder::pushClipRSuperellipse
    // 0x11716f4: ldur            x1, [fp, #-0x20]
    // 0x11716f8: mov             x2, x0
    // 0x11716fc: r0 = engineLayer=()
    //     0x11716fc: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1171700: ldur            x1, [fp, #-0x20]
    // 0x1171704: ldur            x2, [fp, #-0x28]
    // 0x1171708: r0 = addChildrenToScene()
    //     0x1171708: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x117170c: ldur            x1, [fp, #-0x28]
    // 0x1171710: r0 = pop()
    //     0x1171710: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x1171714: r0 = Null
    //     0x1171714: mov             x0, NULL
    // 0x1171718: LeaveFrame
    //     0x1171718: mov             SP, fp
    //     0x117171c: ldp             fp, lr, [SP], #0x10
    // 0x1171720: ret
    //     0x1171720: ret             
    // 0x1171724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1171724: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1171728: b               #0x1171684
    // 0x117172c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x117172c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4658, size: 0x50, field offset: 0x48
class ClipRRectLayer extends ContainerLayer {

  _ findAnnotations(/* No info */) {
    // ** addr: 0x112c218, size: 0xb4
    // 0x112c218: EnterFrame
    //     0x112c218: stp             fp, lr, [SP, #-0x10]!
    //     0x112c21c: mov             fp, SP
    // 0x112c220: AllocStack(0x28)
    //     0x112c220: sub             SP, SP, #0x28
    // 0x112c224: SetupParameters()
    //     0x112c224: ldur            w0, [x4, #0xf]
    //     0x112c228: cbnz            w0, #0x112c234
    //     0x112c22c: mov             x1, NULL
    //     0x112c230: b               #0x112c244
    //     0x112c234: ldur            w1, [x4, #0x17]
    //     0x112c238: add             x2, fp, w1, sxtw #2
    //     0x112c23c: ldr             x2, [x2, #0x10]
    //     0x112c240: mov             x1, x2
    // 0x112c244: CheckStackOverflow
    //     0x112c244: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c248: cmp             SP, x16
    //     0x112c24c: b.ls            #0x112c2c0
    // 0x112c250: cbnz            w0, #0x112c25c
    // 0x112c254: r3 = <Object>
    //     0x112c254: ldr             x3, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112c258: b               #0x112c260
    // 0x112c25c: mov             x3, x1
    // 0x112c260: ldr             x0, [fp, #0x20]
    // 0x112c264: stur            x3, [fp, #-8]
    // 0x112c268: LoadField: r1 = r0->field_47
    //     0x112c268: ldur            w1, [x0, #0x47]
    // 0x112c26c: DecompressPointer r1
    //     0x112c26c: add             x1, x1, HEAP, lsl #32
    // 0x112c270: cmp             w1, NULL
    // 0x112c274: b.eq            #0x112c2c8
    // 0x112c278: ldr             x2, [fp, #0x10]
    // 0x112c27c: r0 = contains()
    //     0x112c27c: bl              #0xaf8c9c  ; [dart:ui] RRect::contains
    // 0x112c280: tbz             w0, #4, #0x112c294
    // 0x112c284: r0 = false
    //     0x112c284: add             x0, NULL, #0x30  ; false
    // 0x112c288: LeaveFrame
    //     0x112c288: mov             SP, fp
    //     0x112c28c: ldp             fp, lr, [SP], #0x10
    // 0x112c290: ret
    //     0x112c290: ret             
    // 0x112c294: ldur            x16, [fp, #-8]
    // 0x112c298: ldr             lr, [fp, #0x20]
    // 0x112c29c: stp             lr, x16, [SP, #0x10]
    // 0x112c2a0: ldr             x16, [fp, #0x18]
    // 0x112c2a4: ldr             lr, [fp, #0x10]
    // 0x112c2a8: stp             lr, x16, [SP]
    // 0x112c2ac: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c2ac: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c2b0: r0 = findAnnotations()
    //     0x112c2b0: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112c2b4: LeaveFrame
    //     0x112c2b4: mov             SP, fp
    //     0x112c2b8: ldp             fp, lr, [SP], #0x10
    // 0x112c2bc: ret
    //     0x112c2bc: ret             
    // 0x112c2c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c2c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c2c4: b               #0x112c250
    // 0x112c2c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x112c2c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x1171208, size: 0xd4
    // 0x1171208: EnterFrame
    //     0x1171208: stp             fp, lr, [SP, #-0x10]!
    //     0x117120c: mov             fp, SP
    // 0x1171210: AllocStack(0x28)
    //     0x1171210: sub             SP, SP, #0x28
    // 0x1171214: SetupParameters(ClipRRectLayer this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x28 */)
    //     0x1171214: mov             x4, x1
    //     0x1171218: mov             x3, x2
    //     0x117121c: stur            x1, [fp, #-0x20]
    //     0x1171220: stur            x2, [fp, #-0x28]
    // 0x1171224: CheckStackOverflow
    //     0x1171224: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1171228: cmp             SP, x16
    //     0x117122c: b.ls            #0x11712d0
    // 0x1171230: LoadField: r5 = r4->field_47
    //     0x1171230: ldur            w5, [x4, #0x47]
    // 0x1171234: DecompressPointer r5
    //     0x1171234: add             x5, x5, HEAP, lsl #32
    // 0x1171238: stur            x5, [fp, #-0x18]
    // 0x117123c: cmp             w5, NULL
    // 0x1171240: b.eq            #0x11712d8
    // 0x1171244: LoadField: r6 = r4->field_4b
    //     0x1171244: ldur            w6, [x4, #0x4b]
    // 0x1171248: DecompressPointer r6
    //     0x1171248: add             x6, x6, HEAP, lsl #32
    // 0x117124c: stur            x6, [fp, #-0x10]
    // 0x1171250: LoadField: r7 = r4->field_27
    //     0x1171250: ldur            w7, [x4, #0x27]
    // 0x1171254: DecompressPointer r7
    //     0x1171254: add             x7, x7, HEAP, lsl #32
    // 0x1171258: mov             x0, x7
    // 0x117125c: stur            x7, [fp, #-8]
    // 0x1171260: r2 = Null
    //     0x1171260: mov             x2, NULL
    // 0x1171264: r1 = Null
    //     0x1171264: mov             x1, NULL
    // 0x1171268: r4 = LoadClassIdInstr(r0)
    //     0x1171268: ldur            x4, [x0, #-1]
    //     0x117126c: ubfx            x4, x4, #0xc, #0x14
    // 0x1171270: cmp             x4, #0xee7
    // 0x1171274: b.eq            #0x117128c
    // 0x1171278: r8 = ClipRRectEngineLayer?
    //     0x1171278: add             x8, PP, #0x98, lsl #12  ; [pp+0x985c0] Type: ClipRRectEngineLayer?
    //     0x117127c: ldr             x8, [x8, #0x5c0]
    // 0x1171280: r3 = Null
    //     0x1171280: add             x3, PP, #0x98, lsl #12  ; [pp+0x985c8] Null
    //     0x1171284: ldr             x3, [x3, #0x5c8]
    // 0x1171288: r0 = DefaultNullableTypeTest()
    //     0x1171288: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x117128c: ldur            x1, [fp, #-0x28]
    // 0x1171290: ldur            x2, [fp, #-0x18]
    // 0x1171294: ldur            x3, [fp, #-0x10]
    // 0x1171298: ldur            x5, [fp, #-8]
    // 0x117129c: r0 = pushClipRRect()
    //     0x117129c: bl              #0x11712dc  ; [dart:ui] _NativeSceneBuilder::pushClipRRect
    // 0x11712a0: ldur            x1, [fp, #-0x20]
    // 0x11712a4: mov             x2, x0
    // 0x11712a8: r0 = engineLayer=()
    //     0x11712a8: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x11712ac: ldur            x1, [fp, #-0x20]
    // 0x11712b0: ldur            x2, [fp, #-0x28]
    // 0x11712b4: r0 = addChildrenToScene()
    //     0x11712b4: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x11712b8: ldur            x1, [fp, #-0x28]
    // 0x11712bc: r0 = pop()
    //     0x11712bc: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x11712c0: r0 = Null
    //     0x11712c0: mov             x0, NULL
    // 0x11712c4: LeaveFrame
    //     0x11712c4: mov             SP, fp
    //     0x11712c8: ldp             fp, lr, [SP], #0x10
    // 0x11712cc: ret
    //     0x11712cc: ret             
    // 0x11712d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11712d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11712d4: b               #0x1171230
    // 0x11712d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11712d8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4659, size: 0x50, field offset: 0x48
class ClipRectLayer extends ContainerLayer {

  set _ clipRect=(/* No info */) {
    // ** addr: 0xc199d4, size: 0x78
    // 0xc199d4: EnterFrame
    //     0xc199d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc199d8: mov             fp, SP
    // 0xc199dc: AllocStack(0x20)
    //     0xc199dc: sub             SP, SP, #0x20
    // 0xc199e0: SetupParameters(ClipRectLayer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc199e0: mov             x0, x2
    //     0xc199e4: stur            x1, [fp, #-8]
    //     0xc199e8: stur            x2, [fp, #-0x10]
    // 0xc199ec: CheckStackOverflow
    //     0xc199ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc199f0: cmp             SP, x16
    //     0xc199f4: b.ls            #0xc19a44
    // 0xc199f8: LoadField: r2 = r1->field_47
    //     0xc199f8: ldur            w2, [x1, #0x47]
    // 0xc199fc: DecompressPointer r2
    //     0xc199fc: add             x2, x2, HEAP, lsl #32
    // 0xc19a00: stp             x2, x0, [SP]
    // 0xc19a04: r0 = ==()
    //     0xc19a04: bl              #0x128bdfc  ; [dart:ui] Rect::==
    // 0xc19a08: tbz             w0, #4, #0xc19a34
    // 0xc19a0c: ldur            x1, [fp, #-8]
    // 0xc19a10: ldur            x0, [fp, #-0x10]
    // 0xc19a14: StoreField: r1->field_47 = r0
    //     0xc19a14: stur            w0, [x1, #0x47]
    //     0xc19a18: ldurb           w16, [x1, #-1]
    //     0xc19a1c: ldurb           w17, [x0, #-1]
    //     0xc19a20: and             x16, x17, x16, lsr #2
    //     0xc19a24: tst             x16, HEAP, lsr #32
    //     0xc19a28: b.eq            #0xc19a30
    //     0xc19a2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc19a30: r0 = markNeedsAddToScene()
    //     0xc19a30: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc19a34: r0 = Null
    //     0xc19a34: mov             x0, NULL
    // 0xc19a38: LeaveFrame
    //     0xc19a38: mov             SP, fp
    //     0xc19a3c: ldp             fp, lr, [SP], #0x10
    // 0xc19a40: ret
    //     0xc19a40: ret             
    // 0xc19a44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc19a44: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc19a48: b               #0xc199f8
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0x112c164, size: 0xb4
    // 0x112c164: EnterFrame
    //     0x112c164: stp             fp, lr, [SP, #-0x10]!
    //     0x112c168: mov             fp, SP
    // 0x112c16c: AllocStack(0x28)
    //     0x112c16c: sub             SP, SP, #0x28
    // 0x112c170: SetupParameters()
    //     0x112c170: ldur            w0, [x4, #0xf]
    //     0x112c174: cbnz            w0, #0x112c180
    //     0x112c178: mov             x1, NULL
    //     0x112c17c: b               #0x112c190
    //     0x112c180: ldur            w1, [x4, #0x17]
    //     0x112c184: add             x2, fp, w1, sxtw #2
    //     0x112c188: ldr             x2, [x2, #0x10]
    //     0x112c18c: mov             x1, x2
    // 0x112c190: CheckStackOverflow
    //     0x112c190: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c194: cmp             SP, x16
    //     0x112c198: b.ls            #0x112c20c
    // 0x112c19c: cbnz            w0, #0x112c1a8
    // 0x112c1a0: r3 = <Object>
    //     0x112c1a0: ldr             x3, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112c1a4: b               #0x112c1ac
    // 0x112c1a8: mov             x3, x1
    // 0x112c1ac: ldr             x0, [fp, #0x20]
    // 0x112c1b0: stur            x3, [fp, #-8]
    // 0x112c1b4: LoadField: r1 = r0->field_47
    //     0x112c1b4: ldur            w1, [x0, #0x47]
    // 0x112c1b8: DecompressPointer r1
    //     0x112c1b8: add             x1, x1, HEAP, lsl #32
    // 0x112c1bc: cmp             w1, NULL
    // 0x112c1c0: b.eq            #0x112c214
    // 0x112c1c4: ldr             x2, [fp, #0x10]
    // 0x112c1c8: r0 = contains()
    //     0x112c1c8: bl              #0x81cce0  ; [dart:ui] Rect::contains
    // 0x112c1cc: tbz             w0, #4, #0x112c1e0
    // 0x112c1d0: r0 = false
    //     0x112c1d0: add             x0, NULL, #0x30  ; false
    // 0x112c1d4: LeaveFrame
    //     0x112c1d4: mov             SP, fp
    //     0x112c1d8: ldp             fp, lr, [SP], #0x10
    // 0x112c1dc: ret
    //     0x112c1dc: ret             
    // 0x112c1e0: ldur            x16, [fp, #-8]
    // 0x112c1e4: ldr             lr, [fp, #0x20]
    // 0x112c1e8: stp             lr, x16, [SP, #0x10]
    // 0x112c1ec: ldr             x16, [fp, #0x18]
    // 0x112c1f0: ldr             lr, [fp, #0x10]
    // 0x112c1f4: stp             lr, x16, [SP]
    // 0x112c1f8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c1f8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c1fc: r0 = findAnnotations()
    //     0x112c1fc: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112c200: LeaveFrame
    //     0x112c200: mov             SP, fp
    //     0x112c204: ldp             fp, lr, [SP], #0x10
    // 0x112c208: ret
    //     0x112c208: ret             
    // 0x112c20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c20c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c210: b               #0x112c19c
    // 0x112c214: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x112c214: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x1170e2c, size: 0xd4
    // 0x1170e2c: EnterFrame
    //     0x1170e2c: stp             fp, lr, [SP, #-0x10]!
    //     0x1170e30: mov             fp, SP
    // 0x1170e34: AllocStack(0x28)
    //     0x1170e34: sub             SP, SP, #0x28
    // 0x1170e38: SetupParameters(ClipRectLayer this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x28 */)
    //     0x1170e38: mov             x4, x1
    //     0x1170e3c: mov             x3, x2
    //     0x1170e40: stur            x1, [fp, #-0x20]
    //     0x1170e44: stur            x2, [fp, #-0x28]
    // 0x1170e48: CheckStackOverflow
    //     0x1170e48: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1170e4c: cmp             SP, x16
    //     0x1170e50: b.ls            #0x1170ef4
    // 0x1170e54: LoadField: r5 = r4->field_47
    //     0x1170e54: ldur            w5, [x4, #0x47]
    // 0x1170e58: DecompressPointer r5
    //     0x1170e58: add             x5, x5, HEAP, lsl #32
    // 0x1170e5c: stur            x5, [fp, #-0x18]
    // 0x1170e60: cmp             w5, NULL
    // 0x1170e64: b.eq            #0x1170efc
    // 0x1170e68: LoadField: r6 = r4->field_4b
    //     0x1170e68: ldur            w6, [x4, #0x4b]
    // 0x1170e6c: DecompressPointer r6
    //     0x1170e6c: add             x6, x6, HEAP, lsl #32
    // 0x1170e70: stur            x6, [fp, #-0x10]
    // 0x1170e74: LoadField: r7 = r4->field_27
    //     0x1170e74: ldur            w7, [x4, #0x27]
    // 0x1170e78: DecompressPointer r7
    //     0x1170e78: add             x7, x7, HEAP, lsl #32
    // 0x1170e7c: mov             x0, x7
    // 0x1170e80: stur            x7, [fp, #-8]
    // 0x1170e84: r2 = Null
    //     0x1170e84: mov             x2, NULL
    // 0x1170e88: r1 = Null
    //     0x1170e88: mov             x1, NULL
    // 0x1170e8c: r4 = LoadClassIdInstr(r0)
    //     0x1170e8c: ldur            x4, [x0, #-1]
    //     0x1170e90: ubfx            x4, x4, #0xc, #0x14
    // 0x1170e94: cmp             x4, #0xee8
    // 0x1170e98: b.eq            #0x1170eb0
    // 0x1170e9c: r8 = ClipRectEngineLayer?
    //     0x1170e9c: add             x8, PP, #0x98, lsl #12  ; [pp+0x985e8] Type: ClipRectEngineLayer?
    //     0x1170ea0: ldr             x8, [x8, #0x5e8]
    // 0x1170ea4: r3 = Null
    //     0x1170ea4: add             x3, PP, #0x98, lsl #12  ; [pp+0x985f0] Null
    //     0x1170ea8: ldr             x3, [x3, #0x5f0]
    // 0x1170eac: r0 = DefaultNullableTypeTest()
    //     0x1170eac: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1170eb0: ldur            x1, [fp, #-0x28]
    // 0x1170eb4: ldur            x2, [fp, #-0x18]
    // 0x1170eb8: ldur            x3, [fp, #-0x10]
    // 0x1170ebc: ldur            x5, [fp, #-8]
    // 0x1170ec0: r0 = pushClipRect()
    //     0x1170ec0: bl              #0x1170f00  ; [dart:ui] _NativeSceneBuilder::pushClipRect
    // 0x1170ec4: ldur            x1, [fp, #-0x20]
    // 0x1170ec8: mov             x2, x0
    // 0x1170ecc: r0 = engineLayer=()
    //     0x1170ecc: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1170ed0: ldur            x1, [fp, #-0x20]
    // 0x1170ed4: ldur            x2, [fp, #-0x28]
    // 0x1170ed8: r0 = addChildrenToScene()
    //     0x1170ed8: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x1170edc: ldur            x1, [fp, #-0x28]
    // 0x1170ee0: r0 = pop()
    //     0x1170ee0: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x1170ee4: r0 = Null
    //     0x1170ee4: mov             x0, NULL
    // 0x1170ee8: LeaveFrame
    //     0x1170ee8: mov             SP, fp
    //     0x1170eec: ldp             fp, lr, [SP], #0x10
    // 0x1170ef0: ret
    //     0x1170ef0: ret             
    // 0x1170ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1170ef4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1170ef8: b               #0x1170e54
    // 0x1170efc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1170efc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4660, size: 0x4c, field offset: 0x48
class OffsetLayer extends ContainerLayer {

  set _ offset=(/* No info */) {
    // ** addr: 0xc16f8c, size: 0x7c
    // 0xc16f8c: EnterFrame
    //     0xc16f8c: stp             fp, lr, [SP, #-0x10]!
    //     0xc16f90: mov             fp, SP
    // 0xc16f94: AllocStack(0x20)
    //     0xc16f94: sub             SP, SP, #0x20
    // 0xc16f98: SetupParameters(OffsetLayer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc16f98: mov             x0, x2
    //     0xc16f9c: stur            x1, [fp, #-8]
    //     0xc16fa0: stur            x2, [fp, #-0x10]
    // 0xc16fa4: CheckStackOverflow
    //     0xc16fa4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc16fa8: cmp             SP, x16
    //     0xc16fac: b.ls            #0xc17000
    // 0xc16fb0: LoadField: r2 = r1->field_47
    //     0xc16fb0: ldur            w2, [x1, #0x47]
    // 0xc16fb4: DecompressPointer r2
    //     0xc16fb4: add             x2, x2, HEAP, lsl #32
    // 0xc16fb8: stp             x2, x0, [SP]
    // 0xc16fbc: r0 = ==()
    //     0xc16fbc: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0xc16fc0: tbz             w0, #4, #0xc16fcc
    // 0xc16fc4: ldur            x1, [fp, #-8]
    // 0xc16fc8: r0 = markNeedsAddToScene()
    //     0xc16fc8: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc16fcc: ldur            x1, [fp, #-8]
    // 0xc16fd0: ldur            x0, [fp, #-0x10]
    // 0xc16fd4: StoreField: r1->field_47 = r0
    //     0xc16fd4: stur            w0, [x1, #0x47]
    //     0xc16fd8: ldurb           w16, [x1, #-1]
    //     0xc16fdc: ldurb           w17, [x0, #-1]
    //     0xc16fe0: and             x16, x17, x16, lsr #2
    //     0xc16fe4: tst             x16, HEAP, lsr #32
    //     0xc16fe8: b.eq            #0xc16ff0
    //     0xc16fec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc16ff0: r0 = Null
    //     0xc16ff0: mov             x0, NULL
    // 0xc16ff4: LeaveFrame
    //     0xc16ff4: mov             SP, fp
    //     0xc16ff8: ldp             fp, lr, [SP], #0x10
    // 0xc16ffc: ret
    //     0xc16ffc: ret             
    // 0xc17000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc17000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc17004: b               #0xc16fb0
  }
  _ toImageSync(/* No info */) {
    // ** addr: 0xc1e314, size: 0x284
    // 0xc1e314: EnterFrame
    //     0xc1e314: stp             fp, lr, [SP, #-0x10]!
    //     0xc1e318: mov             fp, SP
    // 0xc1e31c: AllocStack(0x80)
    //     0xc1e31c: sub             SP, SP, #0x80
    // 0xc1e320: SetupParameters(dynamic _ /* r2 => r0, fp-0x50 */, dynamic _ /* d0 => d1, fp-0x70 */)
    //     0xc1e320: mov             x0, x2
    //     0xc1e324: mov             v1.16b, v0.16b
    //     0xc1e328: stur            x2, [fp, #-0x50]
    //     0xc1e32c: stur            d0, [fp, #-0x70]
    // 0xc1e330: CheckStackOverflow
    //     0xc1e330: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1e334: cmp             SP, x16
    //     0xc1e338: b.ls            #0xc1e534
    // 0xc1e33c: mov             x2, x0
    // 0xc1e340: mov             v0.16b, v1.16b
    // 0xc1e344: r0 = _createSceneForImage()
    //     0xc1e344: bl              #0xc1e9b4  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::_createSceneForImage
    // 0xc1e348: mov             x19, x0
    // 0xc1e34c: stur            x19, [fp, #-0x58]
    // 0xc1e350: ldur            x20, [fp, #-0x50]
    // 0xc1e354: ldur            d1, [fp, #-0x70]
    // 0xc1e358: ArrayLoad: d0 = r20[0]  ; List_8
    //     0xc1e358: ldur            d0, [x20, #0x17]
    // 0xc1e35c: LoadField: d2 = r20->field_7
    //     0xc1e35c: ldur            d2, [x20, #7]
    // 0xc1e360: fsub            d3, d0, d2
    // 0xc1e364: fmul            d2, d1, d3
    // 0xc1e368: mov             v0.16b, v2.16b
    // 0xc1e36c: stur            d2, [fp, #-0x78]
    // 0xc1e370: stp             fp, lr, [SP, #-0x10]!
    // 0xc1e374: mov             fp, SP
    // 0xc1e378: CallRuntime_LibcCeil(double) -> double
    //     0xc1e378: and             SP, SP, #0xfffffffffffffff0
    //     0xc1e37c: mov             sp, SP
    //     0xc1e380: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xc1e384: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc1e388: blr             x16
    //     0xc1e38c: mov             x16, #8
    //     0xc1e390: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc1e394: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc1e398: sub             sp, x16, #1, lsl #12
    //     0xc1e39c: mov             SP, fp
    //     0xc1e3a0: ldp             fp, lr, [SP], #0x10
    // 0xc1e3a4: mov             v1.16b, v0.16b
    // 0xc1e3a8: ldur            d0, [fp, #-0x78]
    // 0xc1e3ac: fcmp            d0, d0
    // 0xc1e3b0: b.vs            #0xc1e53c
    // 0xc1e3b4: fcvtps          x23, d0
    // 0xc1e3b8: asr             x16, x23, #0x1e
    // 0xc1e3bc: cmp             x16, x23, asr #63
    // 0xc1e3c0: b.ne            #0xc1e53c
    // 0xc1e3c4: lsl             x23, x23, #1
    // 0xc1e3c8: LoadField: d0 = r20->field_1f
    //     0xc1e3c8: ldur            d0, [x20, #0x1f]
    // 0xc1e3cc: LoadField: d1 = r20->field_f
    //     0xc1e3cc: ldur            d1, [x20, #0xf]
    // 0xc1e3d0: fsub            d2, d0, d1
    // 0xc1e3d4: ldur            d1, [fp, #-0x70]
    // 0xc1e3d8: fmul            d3, d1, d2
    // 0xc1e3dc: mov             v0.16b, v3.16b
    // 0xc1e3e0: stur            d3, [fp, #-0x78]
    // 0xc1e3e4: stp             fp, lr, [SP, #-0x10]!
    // 0xc1e3e8: mov             fp, SP
    // 0xc1e3ec: CallRuntime_LibcCeil(double) -> double
    //     0xc1e3ec: and             SP, SP, #0xfffffffffffffff0
    //     0xc1e3f0: mov             sp, SP
    //     0xc1e3f4: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xc1e3f8: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc1e3fc: blr             x16
    //     0xc1e400: mov             x16, #8
    //     0xc1e404: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xc1e408: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xc1e40c: sub             sp, x16, #1, lsl #12
    //     0xc1e410: mov             SP, fp
    //     0xc1e414: ldp             fp, lr, [SP], #0x10
    // 0xc1e418: mov             v1.16b, v0.16b
    // 0xc1e41c: ldur            d0, [fp, #-0x78]
    // 0xc1e420: fcmp            d0, d0
    // 0xc1e424: b.vs            #0xc1e564
    // 0xc1e428: fcvtps          x0, d0
    // 0xc1e42c: asr             x16, x0, #0x1e
    // 0xc1e430: cmp             x16, x0, asr #63
    // 0xc1e434: b.ne            #0xc1e564
    // 0xc1e438: lsl             x0, x0, #1
    // 0xc1e43c: r2 = LoadInt32Instr(r23)
    //     0xc1e43c: sbfx            x2, x23, #1, #0x1f
    //     0xc1e440: tbz             w23, #0, #0xc1e448
    //     0xc1e444: ldur            x2, [x23, #7]
    // 0xc1e448: r3 = LoadInt32Instr(r0)
    //     0xc1e448: sbfx            x3, x0, #1, #0x1f
    //     0xc1e44c: tbz             w0, #0, #0xc1e454
    //     0xc1e450: ldur            x3, [x0, #7]
    // 0xc1e454: mov             x1, x19
    // 0xc1e458: r0 = toImageSync()
    //     0xc1e458: bl              #0xc1e598  ; [dart:ui] _NativeScene::toImageSync
    // 0xc1e45c: stur            x0, [fp, #-0x50]
    // 0xc1e460: ldur            x2, [fp, #-0x58]
    // 0xc1e464: LoadField: r1 = r2->field_7
    //     0xc1e464: ldur            w1, [x2, #7]
    // 0xc1e468: DecompressPointer r1
    //     0xc1e468: add             x1, x1, HEAP, lsl #32
    // 0xc1e46c: cmp             w1, NULL
    // 0xc1e470: b.eq            #0xc1e590
    // 0xc1e474: LoadField: r3 = r1->field_7
    //     0xc1e474: ldur            x3, [x1, #7]
    // 0xc1e478: ldr             x1, [x3]
    // 0xc1e47c: cbz             x1, #0xc1e4b0
    // 0xc1e480: mov             x3, x1
    // 0xc1e484: stur            x3, [fp, #-0x60]
    // 0xc1e488: r1 = <Never>
    //     0xc1e488: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1e48c: r0 = Pointer()
    //     0xc1e48c: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1e490: mov             x1, x0
    // 0xc1e494: ldur            x0, [fp, #-0x60]
    // 0xc1e498: StoreField: r1->field_7 = r0
    //     0xc1e498: stur            x0, [x1, #7]
    // 0xc1e49c: r0 = _dispose$Method$FfiNative()
    //     0xc1e49c: bl              #0x898948  ; [dart:ui] _NativeScene::_dispose$Method$FfiNative
    // 0xc1e4a0: ldur            x0, [fp, #-0x50]
    // 0xc1e4a4: LeaveFrame
    //     0xc1e4a4: mov             SP, fp
    //     0xc1e4a8: ldp             fp, lr, [SP], #0x10
    // 0xc1e4ac: ret
    //     0xc1e4ac: ret             
    // 0xc1e4b0: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1e4b0: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1e4b4: str             x16, [SP]
    // 0xc1e4b8: r0 = _throwNew()
    //     0xc1e4b8: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1e4bc: brk             #0
    // 0xc1e4c0: sub             SP, fp, #0x80
    // 0xc1e4c4: ldur            x2, [fp, #-0x58]
    // 0xc1e4c8: mov             x3, x0
    // 0xc1e4cc: stur            x0, [fp, #-0x50]
    // 0xc1e4d0: mov             x0, x1
    // 0xc1e4d4: stur            x1, [fp, #-0x68]
    // 0xc1e4d8: LoadField: r1 = r2->field_7
    //     0xc1e4d8: ldur            w1, [x2, #7]
    // 0xc1e4dc: DecompressPointer r1
    //     0xc1e4dc: add             x1, x1, HEAP, lsl #32
    // 0xc1e4e0: cmp             w1, NULL
    // 0xc1e4e4: b.eq            #0xc1e594
    // 0xc1e4e8: LoadField: r4 = r1->field_7
    //     0xc1e4e8: ldur            x4, [x1, #7]
    // 0xc1e4ec: ldr             x1, [x4]
    // 0xc1e4f0: cbnz            x1, #0xc1e504
    // 0xc1e4f4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xc1e4f4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xc1e4f8: str             x16, [SP]
    // 0xc1e4fc: r0 = _throwNew()
    //     0xc1e4fc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xc1e500: brk             #0
    // 0xc1e504: mov             x4, x1
    // 0xc1e508: stur            x4, [fp, #-0x60]
    // 0xc1e50c: r1 = <Never>
    //     0xc1e50c: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xc1e510: r0 = Pointer()
    //     0xc1e510: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xc1e514: mov             x1, x0
    // 0xc1e518: ldur            x0, [fp, #-0x60]
    // 0xc1e51c: StoreField: r1->field_7 = r0
    //     0xc1e51c: stur            x0, [x1, #7]
    // 0xc1e520: r0 = _dispose$Method$FfiNative()
    //     0xc1e520: bl              #0x898948  ; [dart:ui] _NativeScene::_dispose$Method$FfiNative
    // 0xc1e524: ldur            x0, [fp, #-0x50]
    // 0xc1e528: ldur            x1, [fp, #-0x68]
    // 0xc1e52c: r0 = ReThrow()
    //     0xc1e52c: bl              #0x13ddb00  ; ReThrowStub
    // 0xc1e530: brk             #0
    // 0xc1e534: r0 = StackOverflowSharedWithFPURegs()
    //     0xc1e534: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc1e538: b               #0xc1e33c
    // 0xc1e53c: stp             q0, q1, [SP, #-0x20]!
    // 0xc1e540: stp             x19, x20, [SP, #-0x10]!
    // 0xc1e544: r0 = 66
    //     0xc1e544: mov             x0, #0x42
    // 0xc1e548: r30 = DoubleToIntegerStub
    //     0xc1e548: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xc1e54c: LoadField: r30 = r30->field_7
    //     0xc1e54c: ldur            lr, [lr, #7]
    // 0xc1e550: blr             lr
    // 0xc1e554: mov             x23, x0
    // 0xc1e558: ldp             x19, x20, [SP], #0x10
    // 0xc1e55c: ldp             q0, q1, [SP], #0x20
    // 0xc1e560: b               #0xc1e3c8
    // 0xc1e564: stp             q0, q1, [SP, #-0x20]!
    // 0xc1e568: stp             x20, x23, [SP, #-0x10]!
    // 0xc1e56c: SaveReg r19
    //     0xc1e56c: str             x19, [SP, #-8]!
    // 0xc1e570: r0 = 66
    //     0xc1e570: mov             x0, #0x42
    // 0xc1e574: r30 = DoubleToIntegerStub
    //     0xc1e574: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xc1e578: LoadField: r30 = r30->field_7
    //     0xc1e578: ldur            lr, [lr, #7]
    // 0xc1e57c: blr             lr
    // 0xc1e580: RestoreReg r19
    //     0xc1e580: ldr             x19, [SP], #8
    // 0xc1e584: ldp             x20, x23, [SP], #0x10
    // 0xc1e588: ldp             q0, q1, [SP], #0x20
    // 0xc1e58c: b               #0xc1e43c
    // 0xc1e590: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1e590: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xc1e594: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc1e594: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ _createSceneForImage(/* No info */) {
    // ** addr: 0xc1e9b4, size: 0xcc
    // 0xc1e9b4: EnterFrame
    //     0xc1e9b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc1e9b8: mov             fp, SP
    // 0xc1e9bc: AllocStack(0x30)
    //     0xc1e9bc: sub             SP, SP, #0x30
    // 0xc1e9c0: SetupParameters(OffsetLayer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0xc1e9c0: stur            x1, [fp, #-8]
    //     0xc1e9c4: stur            x2, [fp, #-0x10]
    //     0xc1e9c8: stur            d0, [fp, #-0x30]
    // 0xc1e9cc: CheckStackOverflow
    //     0xc1e9cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1e9d0: cmp             SP, x16
    //     0xc1e9d4: b.ls            #0xc1ea78
    // 0xc1e9d8: r0 = _NativeSceneBuilder()
    //     0xc1e9d8: bl              #0x899ef8  ; Allocate_NativeSceneBuilderStub -> _NativeSceneBuilder (size=0x10)
    // 0xc1e9dc: mov             x1, x0
    // 0xc1e9e0: stur            x0, [fp, #-0x18]
    // 0xc1e9e4: r0 = _NativeSceneBuilder()
    //     0xc1e9e4: bl              #0x899ca0  ; [dart:ui] _NativeSceneBuilder::_NativeSceneBuilder
    // 0xc1e9e8: r0 = Matrix4()
    //     0xc1e9e8: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xc1e9ec: r4 = 32
    //     0xc1e9ec: mov             x4, #0x20
    // 0xc1e9f0: stur            x0, [fp, #-0x20]
    // 0xc1e9f4: r0 = AllocateFloat64Array()
    //     0xc1e9f4: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0xc1e9f8: ldur            x1, [fp, #-0x20]
    // 0xc1e9fc: stur            x0, [fp, #-0x28]
    // 0xc1ea00: StoreField: r1->field_7 = r0
    //     0xc1ea00: stur            w0, [x1, #7]
    // 0xc1ea04: d0 = 1.000000
    //     0xc1ea04: fmov            d0, #1.00000000
    // 0xc1ea08: StoreField: r0->field_8f = d0
    //     0xc1ea08: stur            d0, [x0, #0x8f]
    // 0xc1ea0c: StoreField: r0->field_67 = d0
    //     0xc1ea0c: stur            d0, [x0, #0x67]
    // 0xc1ea10: ldur            d0, [fp, #-0x30]
    // 0xc1ea14: StoreField: r0->field_3f = d0
    //     0xc1ea14: stur            d0, [x0, #0x3f]
    // 0xc1ea18: ArrayStore: r0[0] = d0  ; List_8
    //     0xc1ea18: stur            d0, [x0, #0x17]
    // 0xc1ea1c: ldur            x2, [fp, #-0x10]
    // 0xc1ea20: LoadField: d0 = r2->field_7
    //     0xc1ea20: ldur            d0, [x2, #7]
    // 0xc1ea24: ldur            x3, [fp, #-8]
    // 0xc1ea28: LoadField: r4 = r3->field_47
    //     0xc1ea28: ldur            w4, [x3, #0x47]
    // 0xc1ea2c: DecompressPointer r4
    //     0xc1ea2c: add             x4, x4, HEAP, lsl #32
    // 0xc1ea30: LoadField: d1 = r4->field_7
    //     0xc1ea30: ldur            d1, [x4, #7]
    // 0xc1ea34: fadd            d2, d0, d1
    // 0xc1ea38: fneg            d0, d2
    // 0xc1ea3c: LoadField: d1 = r2->field_f
    //     0xc1ea3c: ldur            d1, [x2, #0xf]
    // 0xc1ea40: LoadField: d2 = r4->field_f
    //     0xc1ea40: ldur            d2, [x4, #0xf]
    // 0xc1ea44: fadd            d3, d1, d2
    // 0xc1ea48: fneg            d1, d3
    // 0xc1ea4c: r0 = translateByDouble()
    //     0xc1ea4c: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xc1ea50: ldur            x1, [fp, #-0x18]
    // 0xc1ea54: ldur            x2, [fp, #-0x28]
    // 0xc1ea58: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1ea58: ldr             x4, [PP, #0xc0]  ; [pp+0xc0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1ea5c: r0 = pushTransform()
    //     0xc1ea5c: bl              #0xc1ea80  ; [dart:ui] _NativeSceneBuilder::pushTransform
    // 0xc1ea60: ldur            x1, [fp, #-8]
    // 0xc1ea64: ldur            x2, [fp, #-0x18]
    // 0xc1ea68: r0 = buildScene()
    //     0xc1ea68: bl              #0x899940  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::buildScene
    // 0xc1ea6c: LeaveFrame
    //     0xc1ea6c: mov             SP, fp
    //     0xc1ea70: ldp             fp, lr, [SP], #0x10
    // 0xc1ea74: ret
    //     0xc1ea74: ret             
    // 0xc1ea78: r0 = StackOverflowSharedWithFPURegs()
    //     0xc1ea78: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc1ea7c: b               #0xc1e9d8
  }
  _ toImage(/* No info */) async {
    // ** addr: 0xeccaac, size: 0x290
    // 0xeccaac: EnterFrame
    //     0xeccaac: stp             fp, lr, [SP, #-0x10]!
    //     0xeccab0: mov             fp, SP
    // 0xeccab4: AllocStack(0x90)
    //     0xeccab4: sub             SP, SP, #0x90
    // 0xeccab8: SetupParameters(OffsetLayer this /* r1 => r1, fp-0x68 */, dynamic _ /* r2 => r2, fp-0x70 */)
    //     0xeccab8: stur            NULL, [fp, #-8]
    //     0xeccabc: stur            x1, [fp, #-0x68]
    //     0xeccac0: stur            x2, [fp, #-0x70]
    // 0xeccac4: CheckStackOverflow
    //     0xeccac4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xeccac8: cmp             SP, x16
    //     0xeccacc: b.ls            #0xecccd8
    // 0xeccad0: InitAsync() -> Future<Image>
    //     0xeccad0: ldr             x0, [PP, #0x6fc8]  ; [pp+0x6fc8] TypeArguments: <Image>
    //     0xeccad4: bl              #0x7f5e44  ; InitAsyncStub
    // 0xeccad8: ldur            x1, [fp, #-0x68]
    // 0xeccadc: ldur            x2, [fp, #-0x70]
    // 0xeccae0: d0 = 3.000000
    //     0xeccae0: fmov            d0, #3.00000000
    // 0xeccae4: r0 = _createSceneForImage()
    //     0xeccae4: bl              #0xc1e9b4  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::_createSceneForImage
    // 0xeccae8: mov             x19, x0
    // 0xeccaec: stur            x19, [fp, #-0x68]
    // 0xeccaf0: ldur            x20, [fp, #-0x70]
    // 0xeccaf4: d1 = 3.000000
    //     0xeccaf4: fmov            d1, #3.00000000
    // 0xeccaf8: ArrayLoad: d0 = r20[0]  ; List_8
    //     0xeccaf8: ldur            d0, [x20, #0x17]
    // 0xeccafc: LoadField: d2 = r20->field_7
    //     0xeccafc: ldur            d2, [x20, #7]
    // 0xeccb00: fsub            d3, d0, d2
    // 0xeccb04: fmul            d2, d3, d1
    // 0xeccb08: mov             v0.16b, v2.16b
    // 0xeccb0c: stur            d2, [fp, #-0x88]
    // 0xeccb10: stp             fp, lr, [SP, #-0x10]!
    // 0xeccb14: mov             fp, SP
    // 0xeccb18: CallRuntime_LibcCeil(double) -> double
    //     0xeccb18: and             SP, SP, #0xfffffffffffffff0
    //     0xeccb1c: mov             sp, SP
    //     0xeccb20: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xeccb24: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xeccb28: blr             x16
    //     0xeccb2c: mov             x16, #8
    //     0xeccb30: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xeccb34: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xeccb38: sub             sp, x16, #1, lsl #12
    //     0xeccb3c: mov             SP, fp
    //     0xeccb40: ldp             fp, lr, [SP], #0x10
    // 0xeccb44: mov             v1.16b, v0.16b
    // 0xeccb48: ldur            d0, [fp, #-0x88]
    // 0xeccb4c: fcmp            d0, d0
    // 0xeccb50: b.vs            #0xeccce0
    // 0xeccb54: fcvtps          x23, d0
    // 0xeccb58: asr             x16, x23, #0x1e
    // 0xeccb5c: cmp             x16, x23, asr #63
    // 0xeccb60: b.ne            #0xeccce0
    // 0xeccb64: lsl             x23, x23, #1
    // 0xeccb68: LoadField: d0 = r20->field_1f
    //     0xeccb68: ldur            d0, [x20, #0x1f]
    // 0xeccb6c: LoadField: d1 = r20->field_f
    //     0xeccb6c: ldur            d1, [x20, #0xf]
    // 0xeccb70: fsub            d2, d0, d1
    // 0xeccb74: d0 = 3.000000
    //     0xeccb74: fmov            d0, #3.00000000
    // 0xeccb78: fmul            d1, d2, d0
    // 0xeccb7c: mov             v0.16b, v1.16b
    // 0xeccb80: stur            d1, [fp, #-0x88]
    // 0xeccb84: stp             fp, lr, [SP, #-0x10]!
    // 0xeccb88: mov             fp, SP
    // 0xeccb8c: CallRuntime_LibcCeil(double) -> double
    //     0xeccb8c: and             SP, SP, #0xfffffffffffffff0
    //     0xeccb90: mov             sp, SP
    //     0xeccb94: ldr             x16, [THR, #0x760]  ; THR::LibcCeil
    //     0xeccb98: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xeccb9c: blr             x16
    //     0xeccba0: mov             x16, #8
    //     0xeccba4: str             x16, [THR, #0x6c8]  ; THR::vm_tag
    //     0xeccba8: ldr             x16, [THR, #0x690]  ; THR::saved_stack_limit
    //     0xeccbac: sub             sp, x16, #1, lsl #12
    //     0xeccbb0: mov             SP, fp
    //     0xeccbb4: ldp             fp, lr, [SP], #0x10
    // 0xeccbb8: mov             v1.16b, v0.16b
    // 0xeccbbc: ldur            d0, [fp, #-0x88]
    // 0xeccbc0: fcmp            d0, d0
    // 0xeccbc4: b.vs            #0xeccd08
    // 0xeccbc8: fcvtps          x0, d0
    // 0xeccbcc: asr             x16, x0, #0x1e
    // 0xeccbd0: cmp             x16, x0, asr #63
    // 0xeccbd4: b.ne            #0xeccd08
    // 0xeccbd8: lsl             x0, x0, #1
    // 0xeccbdc: r2 = LoadInt32Instr(r23)
    //     0xeccbdc: sbfx            x2, x23, #1, #0x1f
    //     0xeccbe0: tbz             w23, #0, #0xeccbe8
    //     0xeccbe4: ldur            x2, [x23, #7]
    // 0xeccbe8: r3 = LoadInt32Instr(r0)
    //     0xeccbe8: sbfx            x3, x0, #1, #0x1f
    //     0xeccbec: tbz             w0, #0, #0xeccbf4
    //     0xeccbf0: ldur            x3, [x0, #7]
    // 0xeccbf4: mov             x1, x19
    // 0xeccbf8: r0 = toImage()
    //     0xeccbf8: bl              #0xeccd3c  ; [dart:ui] _NativeScene::toImage
    // 0xeccbfc: mov             x1, x0
    // 0xeccc00: stur            x1, [fp, #-0x78]
    // 0xeccc04: r0 = Await()
    //     0xeccc04: bl              #0x7f5c00  ; AwaitStub
    // 0xeccc08: stur            x0, [fp, #-0x70]
    // 0xeccc0c: ldur            x2, [fp, #-0x68]
    // 0xeccc10: LoadField: r1 = r2->field_7
    //     0xeccc10: ldur            w1, [x2, #7]
    // 0xeccc14: DecompressPointer r1
    //     0xeccc14: add             x1, x1, HEAP, lsl #32
    // 0xeccc18: cmp             w1, NULL
    // 0xeccc1c: b.eq            #0xeccd34
    // 0xeccc20: LoadField: r3 = r1->field_7
    //     0xeccc20: ldur            x3, [x1, #7]
    // 0xeccc24: ldr             x1, [x3]
    // 0xeccc28: cbz             x1, #0xeccc54
    // 0xeccc2c: mov             x3, x1
    // 0xeccc30: stur            x3, [fp, #-0x80]
    // 0xeccc34: r1 = <Never>
    //     0xeccc34: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xeccc38: r0 = Pointer()
    //     0xeccc38: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xeccc3c: mov             x1, x0
    // 0xeccc40: ldur            x0, [fp, #-0x80]
    // 0xeccc44: StoreField: r1->field_7 = r0
    //     0xeccc44: stur            x0, [x1, #7]
    // 0xeccc48: r0 = _dispose$Method$FfiNative()
    //     0xeccc48: bl              #0x898948  ; [dart:ui] _NativeScene::_dispose$Method$FfiNative
    // 0xeccc4c: ldur            x0, [fp, #-0x70]
    // 0xeccc50: r0 = ReturnAsync()
    //     0xeccc50: b               #0x82fdf0  ; ReturnAsyncStub
    // 0xeccc54: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xeccc54: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xeccc58: str             x16, [SP]
    // 0xeccc5c: r0 = _throwNew()
    //     0xeccc5c: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xeccc60: brk             #0
    // 0xeccc64: sub             SP, fp, #0x90
    // 0xeccc68: ldur            x2, [fp, #-0x68]
    // 0xeccc6c: mov             x3, x0
    // 0xeccc70: stur            x0, [fp, #-0x70]
    // 0xeccc74: mov             x0, x1
    // 0xeccc78: stur            x1, [fp, #-0x78]
    // 0xeccc7c: LoadField: r1 = r2->field_7
    //     0xeccc7c: ldur            w1, [x2, #7]
    // 0xeccc80: DecompressPointer r1
    //     0xeccc80: add             x1, x1, HEAP, lsl #32
    // 0xeccc84: cmp             w1, NULL
    // 0xeccc88: b.eq            #0xeccd38
    // 0xeccc8c: LoadField: r4 = r1->field_7
    //     0xeccc8c: ldur            x4, [x1, #7]
    // 0xeccc90: ldr             x1, [x4]
    // 0xeccc94: cbnz            x1, #0xeccca8
    // 0xeccc98: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xeccc98: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xeccc9c: str             x16, [SP]
    // 0xeccca0: r0 = _throwNew()
    //     0xeccca0: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0xeccca4: brk             #0
    // 0xeccca8: mov             x4, x1
    // 0xecccac: stur            x4, [fp, #-0x80]
    // 0xecccb0: r1 = <Never>
    //     0xecccb0: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0xecccb4: r0 = Pointer()
    //     0xecccb4: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xecccb8: mov             x1, x0
    // 0xecccbc: ldur            x0, [fp, #-0x80]
    // 0xecccc0: StoreField: r1->field_7 = r0
    //     0xecccc0: stur            x0, [x1, #7]
    // 0xecccc4: r0 = _dispose$Method$FfiNative()
    //     0xecccc4: bl              #0x898948  ; [dart:ui] _NativeScene::_dispose$Method$FfiNative
    // 0xecccc8: ldur            x0, [fp, #-0x70]
    // 0xeccccc: ldur            x1, [fp, #-0x78]
    // 0xecccd0: r0 = ReThrow()
    //     0xecccd0: bl              #0x13ddb00  ; ReThrowStub
    // 0xecccd4: brk             #0
    // 0xecccd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xecccd8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xecccdc: b               #0xeccad0
    // 0xeccce0: stp             q0, q1, [SP, #-0x20]!
    // 0xeccce4: stp             x19, x20, [SP, #-0x10]!
    // 0xeccce8: r0 = 66
    //     0xeccce8: mov             x0, #0x42
    // 0xecccec: r30 = DoubleToIntegerStub
    //     0xecccec: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xecccf0: LoadField: r30 = r30->field_7
    //     0xecccf0: ldur            lr, [lr, #7]
    // 0xecccf4: blr             lr
    // 0xecccf8: mov             x23, x0
    // 0xecccfc: ldp             x19, x20, [SP], #0x10
    // 0xeccd00: ldp             q0, q1, [SP], #0x20
    // 0xeccd04: b               #0xeccb68
    // 0xeccd08: stp             q0, q1, [SP, #-0x20]!
    // 0xeccd0c: stp             x20, x23, [SP, #-0x10]!
    // 0xeccd10: SaveReg r19
    //     0xeccd10: str             x19, [SP, #-8]!
    // 0xeccd14: r0 = 66
    //     0xeccd14: mov             x0, #0x42
    // 0xeccd18: r30 = DoubleToIntegerStub
    //     0xeccd18: ldr             lr, [PP, #0x1b70]  ; [pp+0x1b70] Stub: DoubleToInteger (0x7d18e4)
    // 0xeccd1c: LoadField: r30 = r30->field_7
    //     0xeccd1c: ldur            lr, [lr, #7]
    // 0xeccd20: blr             lr
    // 0xeccd24: RestoreReg r19
    //     0xeccd24: ldr             x19, [SP], #8
    // 0xeccd28: ldp             x20, x23, [SP], #0x10
    // 0xeccd2c: ldp             q0, q1, [SP], #0x20
    // 0xeccd30: b               #0xeccbdc
    // 0xeccd34: r0 = NullErrorSharedWithoutFPURegs()
    //     0xeccd34: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xeccd38: r0 = NullErrorSharedWithoutFPURegs()
    //     0xeccd38: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0x112c0d4, size: 0x90
    // 0x112c0d4: EnterFrame
    //     0x112c0d4: stp             fp, lr, [SP, #-0x10]!
    //     0x112c0d8: mov             fp, SP
    // 0x112c0dc: AllocStack(0x28)
    //     0x112c0dc: sub             SP, SP, #0x28
    // 0x112c0e0: SetupParameters()
    //     0x112c0e0: ldur            w0, [x4, #0xf]
    //     0x112c0e4: cbnz            w0, #0x112c0f0
    //     0x112c0e8: mov             x1, NULL
    //     0x112c0ec: b               #0x112c100
    //     0x112c0f0: ldur            w1, [x4, #0x17]
    //     0x112c0f4: add             x2, fp, w1, sxtw #2
    //     0x112c0f8: ldr             x2, [x2, #0x10]
    //     0x112c0fc: mov             x1, x2
    // 0x112c100: CheckStackOverflow
    //     0x112c100: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c104: cmp             SP, x16
    //     0x112c108: b.ls            #0x112c15c
    // 0x112c10c: cbnz            w0, #0x112c118
    // 0x112c110: r3 = <Object>
    //     0x112c110: ldr             x3, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112c114: b               #0x112c11c
    // 0x112c118: mov             x3, x1
    // 0x112c11c: ldr             x0, [fp, #0x20]
    // 0x112c120: stur            x3, [fp, #-8]
    // 0x112c124: LoadField: r2 = r0->field_47
    //     0x112c124: ldur            w2, [x0, #0x47]
    // 0x112c128: DecompressPointer r2
    //     0x112c128: add             x2, x2, HEAP, lsl #32
    // 0x112c12c: ldr             x1, [fp, #0x10]
    // 0x112c130: r0 = -()
    //     0x112c130: bl              #0x81d024  ; [dart:ui] Offset::-
    // 0x112c134: ldur            x16, [fp, #-8]
    // 0x112c138: ldr             lr, [fp, #0x20]
    // 0x112c13c: stp             lr, x16, [SP, #0x10]
    // 0x112c140: ldr             x16, [fp, #0x18]
    // 0x112c144: stp             x0, x16, [SP]
    // 0x112c148: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112c148: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112c14c: r0 = findAnnotations()
    //     0x112c14c: bl              #0x112c43c  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::findAnnotations
    // 0x112c150: LeaveFrame
    //     0x112c150: mov             SP, fp
    //     0x112c154: ldp             fp, lr, [SP], #0x10
    // 0x112c158: ret
    //     0x112c158: ret             
    // 0x112c15c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c15c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c160: b               #0x112c10c
  }
  _ applyTransform(/* No info */) {
    // ** addr: 0x115c714, size: 0x48
    // 0x115c714: EnterFrame
    //     0x115c714: stp             fp, lr, [SP, #-0x10]!
    //     0x115c718: mov             fp, SP
    // 0x115c71c: mov             x0, x1
    // 0x115c720: mov             x1, x2
    // 0x115c724: CheckStackOverflow
    //     0x115c724: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115c728: cmp             SP, x16
    //     0x115c72c: b.ls            #0x115c754
    // 0x115c730: LoadField: r2 = r0->field_47
    //     0x115c730: ldur            w2, [x0, #0x47]
    // 0x115c734: DecompressPointer r2
    //     0x115c734: add             x2, x2, HEAP, lsl #32
    // 0x115c738: LoadField: d0 = r2->field_7
    //     0x115c738: ldur            d0, [x2, #7]
    // 0x115c73c: LoadField: d1 = r2->field_f
    //     0x115c73c: ldur            d1, [x2, #0xf]
    // 0x115c740: r0 = translateByDouble()
    //     0x115c740: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0x115c744: r0 = Null
    //     0x115c744: mov             x0, NULL
    // 0x115c748: LeaveFrame
    //     0x115c748: mov             SP, fp
    //     0x115c74c: ldp             fp, lr, [SP], #0x10
    // 0x115c750: ret
    //     0x115c750: ret             
    // 0x115c754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115c754: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115c758: b               #0x115c730
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x1170d64, size: 0xc8
    // 0x1170d64: EnterFrame
    //     0x1170d64: stp             fp, lr, [SP, #-0x10]!
    //     0x1170d68: mov             fp, SP
    // 0x1170d6c: AllocStack(0x28)
    //     0x1170d6c: sub             SP, SP, #0x28
    // 0x1170d70: SetupParameters(OffsetLayer this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x1170d70: mov             x4, x1
    //     0x1170d74: mov             x3, x2
    //     0x1170d78: stur            x1, [fp, #-0x10]
    //     0x1170d7c: stur            x2, [fp, #-0x18]
    // 0x1170d80: CheckStackOverflow
    //     0x1170d80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x1170d84: cmp             SP, x16
    //     0x1170d88: b.ls            #0x1170e24
    // 0x1170d8c: LoadField: r0 = r4->field_47
    //     0x1170d8c: ldur            w0, [x4, #0x47]
    // 0x1170d90: DecompressPointer r0
    //     0x1170d90: add             x0, x0, HEAP, lsl #32
    // 0x1170d94: LoadField: d0 = r0->field_7
    //     0x1170d94: ldur            d0, [x0, #7]
    // 0x1170d98: stur            d0, [fp, #-0x28]
    // 0x1170d9c: LoadField: d1 = r0->field_f
    //     0x1170d9c: ldur            d1, [x0, #0xf]
    // 0x1170da0: stur            d1, [fp, #-0x20]
    // 0x1170da4: LoadField: r5 = r4->field_27
    //     0x1170da4: ldur            w5, [x4, #0x27]
    // 0x1170da8: DecompressPointer r5
    //     0x1170da8: add             x5, x5, HEAP, lsl #32
    // 0x1170dac: mov             x0, x5
    // 0x1170db0: stur            x5, [fp, #-8]
    // 0x1170db4: r2 = Null
    //     0x1170db4: mov             x2, NULL
    // 0x1170db8: r1 = Null
    //     0x1170db8: mov             x1, NULL
    // 0x1170dbc: r4 = LoadClassIdInstr(r0)
    //     0x1170dbc: ldur            x4, [x0, #-1]
    //     0x1170dc0: ubfx            x4, x4, #0xc, #0x14
    // 0x1170dc4: cmp             x4, #0xee9
    // 0x1170dc8: b.eq            #0x1170de0
    // 0x1170dcc: r8 = OffsetEngineLayer?
    //     0x1170dcc: add             x8, PP, #0xd, lsl #12  ; [pp+0xde70] Type: OffsetEngineLayer?
    //     0x1170dd0: ldr             x8, [x8, #0xe70]
    // 0x1170dd4: r3 = Null
    //     0x1170dd4: add             x3, PP, #0xd, lsl #12  ; [pp+0xde78] Null
    //     0x1170dd8: ldr             x3, [x3, #0xe78]
    // 0x1170ddc: r0 = DefaultNullableTypeTest()
    //     0x1170ddc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1170de0: ldur            x1, [fp, #-0x18]
    // 0x1170de4: ldur            d0, [fp, #-0x28]
    // 0x1170de8: ldur            d1, [fp, #-0x20]
    // 0x1170dec: ldur            x2, [fp, #-8]
    // 0x1170df0: r0 = pushOffset()
    //     0x1170df0: bl              #0x11707cc  ; [dart:ui] _NativeSceneBuilder::pushOffset
    // 0x1170df4: ldur            x1, [fp, #-0x10]
    // 0x1170df8: mov             x2, x0
    // 0x1170dfc: r0 = engineLayer=()
    //     0x1170dfc: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1170e00: ldur            x1, [fp, #-0x10]
    // 0x1170e04: ldur            x2, [fp, #-0x18]
    // 0x1170e08: r0 = addChildrenToScene()
    //     0x1170e08: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x1170e0c: ldur            x1, [fp, #-0x18]
    // 0x1170e10: r0 = pop()
    //     0x1170e10: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x1170e14: r0 = Null
    //     0x1170e14: mov             x0, NULL
    // 0x1170e18: LeaveFrame
    //     0x1170e18: mov             SP, fp
    //     0x1170e1c: ldp             fp, lr, [SP], #0x10
    // 0x1170e20: ret
    //     0x1170e20: ret             
    // 0x1170e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x1170e24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1170e28: b               #0x1170d8c
  }
}

// class id: 4661, size: 0x50, field offset: 0x4c
class OpacityLayer extends OffsetLayer {

  set _ alpha=(/* No info */) {
    // ** addr: 0xbecedc, size: 0xd0
    // 0xbecedc: EnterFrame
    //     0xbecedc: stp             fp, lr, [SP, #-0x10]!
    //     0xbecee0: mov             fp, SP
    // 0xbecee4: AllocStack(0x10)
    //     0xbecee4: sub             SP, SP, #0x10
    // 0xbecee8: SetupParameters(OpacityLayer this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xbecee8: mov             x3, x1
    //     0xbeceec: mov             x0, x2
    //     0xbecef0: stur            x1, [fp, #-8]
    //     0xbecef4: stur            x2, [fp, #-0x10]
    // 0xbecef8: CheckStackOverflow
    //     0xbecef8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbecefc: cmp             SP, x16
    //     0xbecf00: b.ls            #0xbecfa4
    // 0xbecf04: LoadField: r1 = r3->field_4b
    //     0xbecf04: ldur            w1, [x3, #0x4b]
    // 0xbecf08: DecompressPointer r1
    //     0xbecf08: add             x1, x1, HEAP, lsl #32
    // 0xbecf0c: cmp             w0, w1
    // 0xbecf10: b.eq            #0xbecf94
    // 0xbecf14: and             w16, w0, w1
    // 0xbecf18: branchIfSmi(r16, 0xbecf4c)
    //     0xbecf18: tbz             w16, #0, #0xbecf4c
    // 0xbecf1c: r16 = LoadClassIdInstr(r0)
    //     0xbecf1c: ldur            x16, [x0, #-1]
    //     0xbecf20: ubfx            x16, x16, #0xc, #0x14
    // 0xbecf24: cmp             x16, #0x3d
    // 0xbecf28: b.ne            #0xbecf4c
    // 0xbecf2c: r16 = LoadClassIdInstr(r1)
    //     0xbecf2c: ldur            x16, [x1, #-1]
    //     0xbecf30: ubfx            x16, x16, #0xc, #0x14
    // 0xbecf34: cmp             x16, #0x3d
    // 0xbecf38: b.ne            #0xbecf4c
    // 0xbecf3c: LoadField: r16 = r0->field_7
    //     0xbecf3c: ldur            x16, [x0, #7]
    // 0xbecf40: LoadField: r17 = r1->field_7
    //     0xbecf40: ldur            x17, [x1, #7]
    // 0xbecf44: cmp             x16, x17
    // 0xbecf48: b.eq            #0xbecf94
    // 0xbecf4c: cmp             w0, #0x1fe
    // 0xbecf50: b.eq            #0xbecf5c
    // 0xbecf54: cmp             w1, #0x1fe
    // 0xbecf58: b.ne            #0xbecf68
    // 0xbecf5c: mov             x1, x3
    // 0xbecf60: r2 = Null
    //     0xbecf60: mov             x2, NULL
    // 0xbecf64: r0 = engineLayer=()
    //     0xbecf64: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0xbecf68: ldur            x1, [fp, #-8]
    // 0xbecf6c: ldur            x0, [fp, #-0x10]
    // 0xbecf70: StoreField: r1->field_4b = r0
    //     0xbecf70: stur            w0, [x1, #0x4b]
    //     0xbecf74: tbz             w0, #0, #0xbecf90
    //     0xbecf78: ldurb           w16, [x1, #-1]
    //     0xbecf7c: ldurb           w17, [x0, #-1]
    //     0xbecf80: and             x16, x17, x16, lsr #2
    //     0xbecf84: tst             x16, HEAP, lsr #32
    //     0xbecf88: b.eq            #0xbecf90
    //     0xbecf8c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbecf90: r0 = markNeedsAddToScene()
    //     0xbecf90: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xbecf94: r0 = Null
    //     0xbecf94: mov             x0, NULL
    // 0xbecf98: LeaveFrame
    //     0xbecf98: mov             SP, fp
    //     0xbecf9c: ldp             fp, lr, [SP], #0x10
    // 0xbecfa0: ret
    //     0xbecfa0: ret             
    // 0xbecfa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbecfa4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbecfa8: b               #0xbecf04
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x117063c, size: 0x190
    // 0x117063c: EnterFrame
    //     0x117063c: stp             fp, lr, [SP, #-0x10]!
    //     0x1170640: mov             fp, SP
    // 0x1170644: AllocStack(0x38)
    //     0x1170644: sub             SP, SP, #0x38
    // 0x1170648: SetupParameters(OpacityLayer this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x28 */)
    //     0x1170648: mov             x4, x1
    //     0x117064c: mov             x3, x2
    //     0x1170650: stur            x1, [fp, #-0x20]
    //     0x1170654: stur            x2, [fp, #-0x28]
    // 0x1170658: CheckStackOverflow
    //     0x1170658: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x117065c: cmp             SP, x16
    //     0x1170660: b.ls            #0x11707c0
    // 0x1170664: LoadField: r0 = r4->field_3f
    //     0x1170664: ldur            w0, [x4, #0x3f]
    // 0x1170668: DecompressPointer r0
    //     0x1170668: add             x0, x0, HEAP, lsl #32
    // 0x117066c: cmp             w0, NULL
    // 0x1170670: b.ne            #0x1170690
    // 0x1170674: mov             x1, x4
    // 0x1170678: r2 = Null
    //     0x1170678: mov             x2, NULL
    // 0x117067c: r0 = engineLayer=()
    //     0x117067c: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1170680: r0 = Null
    //     0x1170680: mov             x0, NULL
    // 0x1170684: LeaveFrame
    //     0x1170684: mov             SP, fp
    //     0x1170688: ldp             fp, lr, [SP], #0x10
    // 0x117068c: ret
    //     0x117068c: ret             
    // 0x1170690: LoadField: r0 = r4->field_4b
    //     0x1170690: ldur            w0, [x4, #0x4b]
    // 0x1170694: DecompressPointer r0
    //     0x1170694: add             x0, x0, HEAP, lsl #32
    // 0x1170698: cmp             w0, NULL
    // 0x117069c: b.eq            #0x11707c8
    // 0x11706a0: r5 = LoadInt32Instr(r0)
    //     0x11706a0: sbfx            x5, x0, #1, #0x1f
    //     0x11706a4: tbz             w0, #0, #0x11706ac
    //     0x11706a8: ldur            x5, [x0, #7]
    // 0x11706ac: stur            x5, [fp, #-0x18]
    // 0x11706b0: cmp             x5, #0xff
    // 0x11706b4: b.ge            #0x1170724
    // 0x11706b8: LoadField: r6 = r4->field_47
    //     0x11706b8: ldur            w6, [x4, #0x47]
    // 0x11706bc: DecompressPointer r6
    //     0x11706bc: add             x6, x6, HEAP, lsl #32
    // 0x11706c0: stur            x6, [fp, #-0x10]
    // 0x11706c4: LoadField: r7 = r4->field_27
    //     0x11706c4: ldur            w7, [x4, #0x27]
    // 0x11706c8: DecompressPointer r7
    //     0x11706c8: add             x7, x7, HEAP, lsl #32
    // 0x11706cc: mov             x0, x7
    // 0x11706d0: stur            x7, [fp, #-8]
    // 0x11706d4: r2 = Null
    //     0x11706d4: mov             x2, NULL
    // 0x11706d8: r1 = Null
    //     0x11706d8: mov             x1, NULL
    // 0x11706dc: r4 = LoadClassIdInstr(r0)
    //     0x11706dc: ldur            x4, [x0, #-1]
    //     0x11706e0: ubfx            x4, x4, #0xc, #0x14
    // 0x11706e4: cmp             x4, #0xee4
    // 0x11706e8: b.eq            #0x1170700
    // 0x11706ec: r8 = OpacityEngineLayer?
    //     0x11706ec: add             x8, PP, #0x8e, lsl #12  ; [pp+0x8e5f0] Type: OpacityEngineLayer?
    //     0x11706f0: ldr             x8, [x8, #0x5f0]
    // 0x11706f4: r3 = Null
    //     0x11706f4: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e5f8] Null
    //     0x11706f8: ldr             x3, [x3, #0x5f8]
    // 0x11706fc: r0 = DefaultNullableTypeTest()
    //     0x11706fc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x1170700: ldur            x1, [fp, #-0x28]
    // 0x1170704: ldur            x2, [fp, #-0x18]
    // 0x1170708: ldur            x3, [fp, #-0x10]
    // 0x117070c: ldur            x5, [fp, #-8]
    // 0x1170710: r0 = pushOpacity()
    //     0x1170710: bl              #0x1170a84  ; [dart:ui] _NativeSceneBuilder::pushOpacity
    // 0x1170714: ldur            x1, [fp, #-0x20]
    // 0x1170718: mov             x2, x0
    // 0x117071c: r0 = engineLayer=()
    //     0x117071c: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1170720: b               #0x117079c
    // 0x1170724: mov             x3, x4
    // 0x1170728: LoadField: r0 = r3->field_47
    //     0x1170728: ldur            w0, [x3, #0x47]
    // 0x117072c: DecompressPointer r0
    //     0x117072c: add             x0, x0, HEAP, lsl #32
    // 0x1170730: LoadField: d0 = r0->field_7
    //     0x1170730: ldur            d0, [x0, #7]
    // 0x1170734: stur            d0, [fp, #-0x38]
    // 0x1170738: LoadField: d1 = r0->field_f
    //     0x1170738: ldur            d1, [x0, #0xf]
    // 0x117073c: stur            d1, [fp, #-0x30]
    // 0x1170740: LoadField: r4 = r3->field_27
    //     0x1170740: ldur            w4, [x3, #0x27]
    // 0x1170744: DecompressPointer r4
    //     0x1170744: add             x4, x4, HEAP, lsl #32
    // 0x1170748: mov             x0, x4
    // 0x117074c: stur            x4, [fp, #-8]
    // 0x1170750: r2 = Null
    //     0x1170750: mov             x2, NULL
    // 0x1170754: r1 = Null
    //     0x1170754: mov             x1, NULL
    // 0x1170758: r4 = LoadClassIdInstr(r0)
    //     0x1170758: ldur            x4, [x0, #-1]
    //     0x117075c: ubfx            x4, x4, #0xc, #0x14
    // 0x1170760: cmp             x4, #0xee9
    // 0x1170764: b.eq            #0x117077c
    // 0x1170768: r8 = OffsetEngineLayer?
    //     0x1170768: add             x8, PP, #0xd, lsl #12  ; [pp+0xde70] Type: OffsetEngineLayer?
    //     0x117076c: ldr             x8, [x8, #0xe70]
    // 0x1170770: r3 = Null
    //     0x1170770: add             x3, PP, #0x8e, lsl #12  ; [pp+0x8e608] Null
    //     0x1170774: ldr             x3, [x3, #0x608]
    // 0x1170778: r0 = DefaultNullableTypeTest()
    //     0x1170778: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x117077c: ldur            x1, [fp, #-0x28]
    // 0x1170780: ldur            d0, [fp, #-0x38]
    // 0x1170784: ldur            d1, [fp, #-0x30]
    // 0x1170788: ldur            x2, [fp, #-8]
    // 0x117078c: r0 = pushOffset()
    //     0x117078c: bl              #0x11707cc  ; [dart:ui] _NativeSceneBuilder::pushOffset
    // 0x1170790: ldur            x1, [fp, #-0x20]
    // 0x1170794: mov             x2, x0
    // 0x1170798: r0 = engineLayer=()
    //     0x1170798: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x117079c: ldur            x1, [fp, #-0x20]
    // 0x11707a0: ldur            x2, [fp, #-0x28]
    // 0x11707a4: r0 = addChildrenToScene()
    //     0x11707a4: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x11707a8: ldur            x1, [fp, #-0x28]
    // 0x11707ac: r0 = pop()
    //     0x11707ac: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x11707b0: r0 = Null
    //     0x11707b0: mov             x0, NULL
    // 0x11707b4: LeaveFrame
    //     0x11707b4: mov             SP, fp
    //     0x11707b8: ldp             fp, lr, [SP], #0x10
    // 0x11707bc: ret
    //     0x11707bc: ret             
    // 0x11707c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11707c0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11707c4: b               #0x1170664
    // 0x11707c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x11707c8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4662, size: 0x5c, field offset: 0x4c
class TransformLayer extends OffsetLayer {

  set _ transform=(/* No info */) {
    // ** addr: 0xc1cae8, size: 0x90
    // 0xc1cae8: EnterFrame
    //     0xc1cae8: stp             fp, lr, [SP, #-0x10]!
    //     0xc1caec: mov             fp, SP
    // 0xc1caf0: AllocStack(0x20)
    //     0xc1caf0: sub             SP, SP, #0x20
    // 0xc1caf4: SetupParameters(TransformLayer this /* r1 => r1, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0xc1caf4: mov             x0, x2
    //     0xc1caf8: stur            x1, [fp, #-8]
    //     0xc1cafc: stur            x2, [fp, #-0x10]
    // 0xc1cb00: CheckStackOverflow
    //     0xc1cb00: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1cb04: cmp             SP, x16
    //     0xc1cb08: b.ls            #0xc1cb70
    // 0xc1cb0c: LoadField: r2 = r1->field_4b
    //     0xc1cb0c: ldur            w2, [x1, #0x4b]
    // 0xc1cb10: DecompressPointer r2
    //     0xc1cb10: add             x2, x2, HEAP, lsl #32
    // 0xc1cb14: stp             x2, x0, [SP]
    // 0xc1cb18: r0 = ==()
    //     0xc1cb18: bl              #0x12842b8  ; [package:vector_math/vector_math_64.dart] Matrix4::==
    // 0xc1cb1c: tbnz            w0, #4, #0xc1cb30
    // 0xc1cb20: r0 = Null
    //     0xc1cb20: mov             x0, NULL
    // 0xc1cb24: LeaveFrame
    //     0xc1cb24: mov             SP, fp
    //     0xc1cb28: ldp             fp, lr, [SP], #0x10
    // 0xc1cb2c: ret
    //     0xc1cb2c: ret             
    // 0xc1cb30: ldur            x1, [fp, #-8]
    // 0xc1cb34: r2 = true
    //     0xc1cb34: add             x2, NULL, #0x20  ; true
    // 0xc1cb38: ldur            x0, [fp, #-0x10]
    // 0xc1cb3c: StoreField: r1->field_4b = r0
    //     0xc1cb3c: stur            w0, [x1, #0x4b]
    //     0xc1cb40: ldurb           w16, [x1, #-1]
    //     0xc1cb44: ldurb           w17, [x0, #-1]
    //     0xc1cb48: and             x16, x17, x16, lsr #2
    //     0xc1cb4c: tst             x16, HEAP, lsr #32
    //     0xc1cb50: b.eq            #0xc1cb58
    //     0xc1cb54: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc1cb58: StoreField: r1->field_57 = r2
    //     0xc1cb58: stur            w2, [x1, #0x57]
    // 0xc1cb5c: r0 = markNeedsAddToScene()
    //     0xc1cb5c: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc1cb60: r0 = Null
    //     0xc1cb60: mov             x0, NULL
    // 0xc1cb64: LeaveFrame
    //     0xc1cb64: mov             SP, fp
    //     0xc1cb68: ldp             fp, lr, [SP], #0x10
    // 0xc1cb6c: ret
    //     0xc1cb6c: ret             
    // 0xc1cb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1cb70: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1cb74: b               #0xc1cb0c
  }
  _ findAnnotations(/* No info */) {
    // ** addr: 0x112bf74, size: 0xa0
    // 0x112bf74: EnterFrame
    //     0x112bf74: stp             fp, lr, [SP, #-0x10]!
    //     0x112bf78: mov             fp, SP
    // 0x112bf7c: AllocStack(0x28)
    //     0x112bf7c: sub             SP, SP, #0x28
    // 0x112bf80: SetupParameters()
    //     0x112bf80: ldur            w0, [x4, #0xf]
    //     0x112bf84: cbnz            w0, #0x112bf90
    //     0x112bf88: mov             x1, NULL
    //     0x112bf8c: b               #0x112bfa0
    //     0x112bf90: ldur            w1, [x4, #0x17]
    //     0x112bf94: add             x2, fp, w1, sxtw #2
    //     0x112bf98: ldr             x2, [x2, #0x10]
    //     0x112bf9c: mov             x1, x2
    // 0x112bfa0: CheckStackOverflow
    //     0x112bfa0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112bfa4: cmp             SP, x16
    //     0x112bfa8: b.ls            #0x112c00c
    // 0x112bfac: cbnz            w0, #0x112bfb8
    // 0x112bfb0: r0 = <Object>
    //     0x112bfb0: ldr             x0, [PP, #0x720]  ; [pp+0x720] TypeArguments: <Object>
    // 0x112bfb4: b               #0x112bfbc
    // 0x112bfb8: mov             x0, x1
    // 0x112bfbc: ldr             x1, [fp, #0x20]
    // 0x112bfc0: ldr             x2, [fp, #0x10]
    // 0x112bfc4: stur            x0, [fp, #-8]
    // 0x112bfc8: r0 = _transformOffset()
    //     0x112bfc8: bl              #0x112c014  ; [package:flutter/src/rendering/layer.dart] TransformLayer::_transformOffset
    // 0x112bfcc: cmp             w0, NULL
    // 0x112bfd0: b.ne            #0x112bfe4
    // 0x112bfd4: r0 = false
    //     0x112bfd4: add             x0, NULL, #0x30  ; false
    // 0x112bfd8: LeaveFrame
    //     0x112bfd8: mov             SP, fp
    //     0x112bfdc: ldp             fp, lr, [SP], #0x10
    // 0x112bfe0: ret
    //     0x112bfe0: ret             
    // 0x112bfe4: ldur            x16, [fp, #-8]
    // 0x112bfe8: ldr             lr, [fp, #0x20]
    // 0x112bfec: stp             lr, x16, [SP, #0x10]
    // 0x112bff0: ldr             x16, [fp, #0x18]
    // 0x112bff4: stp             x0, x16, [SP]
    // 0x112bff8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x112bff8: ldr             x4, [PP, #0x728]  ; [pp+0x728] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x112bffc: r0 = findAnnotations()
    //     0x112bffc: bl              #0x112c0d4  ; [package:flutter/src/rendering/layer.dart] OffsetLayer::findAnnotations
    // 0x112c000: LeaveFrame
    //     0x112c000: mov             SP, fp
    //     0x112c004: ldp             fp, lr, [SP], #0x10
    // 0x112c008: ret
    //     0x112c008: ret             
    // 0x112c00c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c00c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c010: b               #0x112bfac
  }
  _ _transformOffset(/* No info */) {
    // ** addr: 0x112c014, size: 0xc0
    // 0x112c014: EnterFrame
    //     0x112c014: stp             fp, lr, [SP, #-0x10]!
    //     0x112c018: mov             fp, SP
    // 0x112c01c: AllocStack(0x10)
    //     0x112c01c: sub             SP, SP, #0x10
    // 0x112c020: SetupParameters(TransformLayer this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */)
    //     0x112c020: mov             x0, x1
    //     0x112c024: stur            x1, [fp, #-8]
    //     0x112c028: stur            x2, [fp, #-0x10]
    // 0x112c02c: CheckStackOverflow
    //     0x112c02c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x112c030: cmp             SP, x16
    //     0x112c034: b.ls            #0x112c0c8
    // 0x112c038: LoadField: r1 = r0->field_57
    //     0x112c038: ldur            w1, [x0, #0x57]
    // 0x112c03c: DecompressPointer r1
    //     0x112c03c: add             x1, x1, HEAP, lsl #32
    // 0x112c040: tbnz            w1, #4, #0x112c08c
    // 0x112c044: LoadField: r1 = r0->field_4b
    //     0x112c044: ldur            w1, [x0, #0x4b]
    // 0x112c048: DecompressPointer r1
    //     0x112c048: add             x1, x1, HEAP, lsl #32
    // 0x112c04c: cmp             w1, NULL
    // 0x112c050: b.eq            #0x112c0d0
    // 0x112c054: r0 = removePerspectiveTransform()
    //     0x112c054: bl              #0x10e8d34  ; [package:flutter/src/gestures/events.dart] PointerEvent::removePerspectiveTransform
    // 0x112c058: mov             x1, x0
    // 0x112c05c: r0 = tryInvert()
    //     0x112c05c: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x112c060: ldur            x1, [fp, #-8]
    // 0x112c064: StoreField: r1->field_53 = r0
    //     0x112c064: stur            w0, [x1, #0x53]
    //     0x112c068: ldurb           w16, [x1, #-1]
    //     0x112c06c: ldurb           w17, [x0, #-1]
    //     0x112c070: and             x16, x17, x16, lsr #2
    //     0x112c074: tst             x16, HEAP, lsr #32
    //     0x112c078: b.eq            #0x112c080
    //     0x112c07c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x112c080: r0 = false
    //     0x112c080: add             x0, NULL, #0x30  ; false
    // 0x112c084: StoreField: r1->field_57 = r0
    //     0x112c084: stur            w0, [x1, #0x57]
    // 0x112c088: b               #0x112c090
    // 0x112c08c: mov             x1, x0
    // 0x112c090: LoadField: r0 = r1->field_53
    //     0x112c090: ldur            w0, [x1, #0x53]
    // 0x112c094: DecompressPointer r0
    //     0x112c094: add             x0, x0, HEAP, lsl #32
    // 0x112c098: cmp             w0, NULL
    // 0x112c09c: b.ne            #0x112c0b0
    // 0x112c0a0: r0 = Null
    //     0x112c0a0: mov             x0, NULL
    // 0x112c0a4: LeaveFrame
    //     0x112c0a4: mov             SP, fp
    //     0x112c0a8: ldp             fp, lr, [SP], #0x10
    // 0x112c0ac: ret
    //     0x112c0ac: ret             
    // 0x112c0b0: mov             x1, x0
    // 0x112c0b4: ldur            x2, [fp, #-0x10]
    // 0x112c0b8: r0 = transformPoint()
    //     0x112c0b8: bl              #0x856f28  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformPoint
    // 0x112c0bc: LeaveFrame
    //     0x112c0bc: mov             SP, fp
    //     0x112c0c0: ldp             fp, lr, [SP], #0x10
    // 0x112c0c4: ret
    //     0x112c0c4: ret             
    // 0x112c0c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x112c0c8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x112c0cc: b               #0x112c038
    // 0x112c0d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x112c0d0: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ applyTransform(/* No info */) {
    // ** addr: 0x115c6b0, size: 0x64
    // 0x115c6b0: EnterFrame
    //     0x115c6b0: stp             fp, lr, [SP, #-0x10]!
    //     0x115c6b4: mov             fp, SP
    // 0x115c6b8: mov             x0, x1
    // 0x115c6bc: mov             x1, x2
    // 0x115c6c0: CheckStackOverflow
    //     0x115c6c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x115c6c4: cmp             SP, x16
    //     0x115c6c8: b.ls            #0x115c708
    // 0x115c6cc: LoadField: r2 = r0->field_4f
    //     0x115c6cc: ldur            w2, [x0, #0x4f]
    // 0x115c6d0: DecompressPointer r2
    //     0x115c6d0: add             x2, x2, HEAP, lsl #32
    // 0x115c6d4: cmp             w2, NULL
    // 0x115c6d8: b.ne            #0x115c6f4
    // 0x115c6dc: LoadField: r2 = r0->field_4b
    //     0x115c6dc: ldur            w2, [x0, #0x4b]
    // 0x115c6e0: DecompressPointer r2
    //     0x115c6e0: add             x2, x2, HEAP, lsl #32
    // 0x115c6e4: cmp             w2, NULL
    // 0x115c6e8: b.eq            #0x115c710
    // 0x115c6ec: r0 = multiply()
    //     0x115c6ec: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x115c6f0: b               #0x115c6f8
    // 0x115c6f4: r0 = multiply()
    //     0x115c6f4: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x115c6f8: r0 = Null
    //     0x115c6f8: mov             x0, NULL
    // 0x115c6fc: LeaveFrame
    //     0x115c6fc: mov             SP, fp
    //     0x115c700: ldp             fp, lr, [SP], #0x10
    // 0x115c704: ret
    //     0x115c704: ret             
    // 0x115c708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x115c708: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x115c70c: b               #0x115c6cc
    // 0x115c710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x115c710: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x11704b4, size: 0x188
    // 0x11704b4: EnterFrame
    //     0x11704b4: stp             fp, lr, [SP, #-0x10]!
    //     0x11704b8: mov             fp, SP
    // 0x11704bc: AllocStack(0x30)
    //     0x11704bc: sub             SP, SP, #0x30
    // 0x11704c0: SetupParameters(TransformLayer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0x11704c0: stur            x1, [fp, #-8]
    //     0x11704c4: mov             x16, x2
    //     0x11704c8: mov             x2, x1
    //     0x11704cc: mov             x1, x16
    //     0x11704d0: stur            x1, [fp, #-0x10]
    // 0x11704d4: CheckStackOverflow
    //     0x11704d4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11704d8: cmp             SP, x16
    //     0x11704dc: b.ls            #0x117062c
    // 0x11704e0: LoadField: r0 = r2->field_4b
    //     0x11704e0: ldur            w0, [x2, #0x4b]
    // 0x11704e4: DecompressPointer r0
    //     0x11704e4: add             x0, x0, HEAP, lsl #32
    // 0x11704e8: StoreField: r2->field_4f = r0
    //     0x11704e8: stur            w0, [x2, #0x4f]
    //     0x11704ec: ldurb           w16, [x2, #-1]
    //     0x11704f0: ldurb           w17, [x0, #-1]
    //     0x11704f4: and             x16, x17, x16, lsr #2
    //     0x11704f8: tst             x16, HEAP, lsr #32
    //     0x11704fc: b.eq            #0x1170504
    //     0x1170500: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0x1170504: LoadField: r0 = r2->field_47
    //     0x1170504: ldur            w0, [x2, #0x47]
    // 0x1170508: DecompressPointer r0
    //     0x1170508: add             x0, x0, HEAP, lsl #32
    // 0x117050c: r16 = Instance_Offset
    //     0x117050c: ldr             x16, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x1170510: stp             x16, x0, [SP]
    // 0x1170514: r0 = ==()
    //     0x1170514: bl              #0x128bd28  ; [dart:ui] Offset::==
    // 0x1170518: tbz             w0, #4, #0x1170584
    // 0x117051c: ldur            x0, [fp, #-8]
    // 0x1170520: LoadField: r1 = r0->field_47
    //     0x1170520: ldur            w1, [x0, #0x47]
    // 0x1170524: DecompressPointer r1
    //     0x1170524: add             x1, x1, HEAP, lsl #32
    // 0x1170528: LoadField: d0 = r1->field_7
    //     0x1170528: ldur            d0, [x1, #7]
    // 0x117052c: LoadField: d1 = r1->field_f
    //     0x117052c: ldur            d1, [x1, #0xf]
    // 0x1170530: r1 = Null
    //     0x1170530: mov             x1, NULL
    // 0x1170534: r0 = Matrix4.translationValues()
    //     0x1170534: bl              #0xbf1188  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0x1170538: mov             x3, x0
    // 0x117053c: ldur            x0, [fp, #-8]
    // 0x1170540: stur            x3, [fp, #-0x18]
    // 0x1170544: LoadField: r2 = r0->field_4f
    //     0x1170544: ldur            w2, [x0, #0x4f]
    // 0x1170548: DecompressPointer r2
    //     0x1170548: add             x2, x2, HEAP, lsl #32
    // 0x117054c: cmp             w2, NULL
    // 0x1170550: b.eq            #0x1170634
    // 0x1170554: mov             x1, x3
    // 0x1170558: r0 = multiply()
    //     0x1170558: bl              #0x857738  ; [package:vector_math/vector_math_64.dart] Matrix4::multiply
    // 0x117055c: ldur            x0, [fp, #-0x18]
    // 0x1170560: ldur            x3, [fp, #-8]
    // 0x1170564: StoreField: r3->field_4f = r0
    //     0x1170564: stur            w0, [x3, #0x4f]
    //     0x1170568: ldurb           w16, [x3, #-1]
    //     0x117056c: ldurb           w17, [x0, #-1]
    //     0x1170570: and             x16, x17, x16, lsr #2
    //     0x1170574: tst             x16, HEAP, lsr #32
    //     0x1170578: b.eq            #0x1170580
    //     0x117057c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0x1170580: b               #0x1170588
    // 0x1170584: ldur            x3, [fp, #-8]
    // 0x1170588: LoadField: r0 = r3->field_4f
    //     0x1170588: ldur            w0, [x3, #0x4f]
    // 0x117058c: DecompressPointer r0
    //     0x117058c: add             x0, x0, HEAP, lsl #32
    // 0x1170590: cmp             w0, NULL
    // 0x1170594: b.eq            #0x1170638
    // 0x1170598: LoadField: r4 = r0->field_7
    //     0x1170598: ldur            w4, [x0, #7]
    // 0x117059c: DecompressPointer r4
    //     0x117059c: add             x4, x4, HEAP, lsl #32
    // 0x11705a0: stur            x4, [fp, #-0x20]
    // 0x11705a4: LoadField: r5 = r3->field_27
    //     0x11705a4: ldur            w5, [x3, #0x27]
    // 0x11705a8: DecompressPointer r5
    //     0x11705a8: add             x5, x5, HEAP, lsl #32
    // 0x11705ac: mov             x0, x5
    // 0x11705b0: stur            x5, [fp, #-0x18]
    // 0x11705b4: r2 = Null
    //     0x11705b4: mov             x2, NULL
    // 0x11705b8: r1 = Null
    //     0x11705b8: mov             x1, NULL
    // 0x11705bc: r4 = LoadClassIdInstr(r0)
    //     0x11705bc: ldur            x4, [x0, #-1]
    //     0x11705c0: ubfx            x4, x4, #0xc, #0x14
    // 0x11705c4: cmp             x4, #0xeea
    // 0x11705c8: b.eq            #0x11705e0
    // 0x11705cc: r8 = TransformEngineLayer?
    //     0x11705cc: add             x8, PP, #0xd, lsl #12  ; [pp+0xde08] Type: TransformEngineLayer?
    //     0x11705d0: ldr             x8, [x8, #0xe08]
    // 0x11705d4: r3 = Null
    //     0x11705d4: add             x3, PP, #0xd, lsl #12  ; [pp+0xde10] Null
    //     0x11705d8: ldr             x3, [x3, #0xe10]
    // 0x11705dc: r0 = DefaultNullableTypeTest()
    //     0x11705dc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x11705e0: ldur            x16, [fp, #-0x18]
    // 0x11705e4: str             x16, [SP]
    // 0x11705e8: ldur            x1, [fp, #-0x10]
    // 0x11705ec: ldur            x2, [fp, #-0x20]
    // 0x11705f0: r4 = const [0, 0x3, 0x1, 0x2, oldLayer, 0x2, null]
    //     0x11705f0: add             x4, PP, #0xd, lsl #12  ; [pp+0xde20] List(7) [0, 0x3, 0x1, 0x2, "oldLayer", 0x2, Null]
    //     0x11705f4: ldr             x4, [x4, #0xe20]
    // 0x11705f8: r0 = pushTransform()
    //     0x11705f8: bl              #0xc1ea80  ; [dart:ui] _NativeSceneBuilder::pushTransform
    // 0x11705fc: ldur            x1, [fp, #-8]
    // 0x1170600: mov             x2, x0
    // 0x1170604: r0 = engineLayer=()
    //     0x1170604: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x1170608: ldur            x1, [fp, #-8]
    // 0x117060c: ldur            x2, [fp, #-0x10]
    // 0x1170610: r0 = addChildrenToScene()
    //     0x1170610: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x1170614: ldur            x1, [fp, #-0x10]
    // 0x1170618: r0 = pop()
    //     0x1170618: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x117061c: r0 = Null
    //     0x117061c: mov             x0, NULL
    // 0x1170620: LeaveFrame
    //     0x1170620: mov             SP, fp
    //     0x1170624: ldp             fp, lr, [SP], #0x10
    // 0x1170628: ret
    //     0x1170628: ret             
    // 0x117062c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x117062c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x1170630: b               #0x11704e0
    // 0x1170634: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1170634: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x1170638: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x1170638: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4663, size: 0x50, field offset: 0x4c
class ImageFilterLayer extends OffsetLayer {

  set _ imageFilter=(/* No info */) {
    // ** addr: 0xbed35c, size: 0x94
    // 0xbed35c: EnterFrame
    //     0xbed35c: stp             fp, lr, [SP, #-0x10]!
    //     0xbed360: mov             fp, SP
    // 0xbed364: AllocStack(0x20)
    //     0xbed364: sub             SP, SP, #0x20
    // 0xbed368: SetupParameters(ImageFilterLayer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xbed368: stur            x1, [fp, #-8]
    //     0xbed36c: mov             x16, x2
    //     0xbed370: mov             x2, x1
    //     0xbed374: mov             x1, x16
    //     0xbed378: stur            x1, [fp, #-0x10]
    // 0xbed37c: CheckStackOverflow
    //     0xbed37c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbed380: cmp             SP, x16
    //     0xbed384: b.ls            #0xbed3e8
    // 0xbed388: LoadField: r0 = r2->field_4b
    //     0xbed388: ldur            w0, [x2, #0x4b]
    // 0xbed38c: DecompressPointer r0
    //     0xbed38c: add             x0, x0, HEAP, lsl #32
    // 0xbed390: r3 = LoadClassIdInstr(r1)
    //     0xbed390: ldur            x3, [x1, #-1]
    //     0xbed394: ubfx            x3, x3, #0xc, #0x14
    // 0xbed398: stp             x0, x1, [SP]
    // 0xbed39c: mov             x0, x3
    // 0xbed3a0: mov             lr, x0
    // 0xbed3a4: ldr             lr, [x21, lr, lsl #3]
    // 0xbed3a8: blr             lr
    // 0xbed3ac: tbz             w0, #4, #0xbed3d8
    // 0xbed3b0: ldur            x1, [fp, #-8]
    // 0xbed3b4: ldur            x0, [fp, #-0x10]
    // 0xbed3b8: StoreField: r1->field_4b = r0
    //     0xbed3b8: stur            w0, [x1, #0x4b]
    //     0xbed3bc: ldurb           w16, [x1, #-1]
    //     0xbed3c0: ldurb           w17, [x0, #-1]
    //     0xbed3c4: and             x16, x17, x16, lsr #2
    //     0xbed3c8: tst             x16, HEAP, lsr #32
    //     0xbed3cc: b.eq            #0xbed3d4
    //     0xbed3d0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbed3d4: r0 = markNeedsAddToScene()
    //     0xbed3d4: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xbed3d8: r0 = Null
    //     0xbed3d8: mov             x0, NULL
    // 0xbed3dc: LeaveFrame
    //     0xbed3dc: mov             SP, fp
    //     0xbed3e0: ldp             fp, lr, [SP], #0x10
    // 0xbed3e4: ret
    //     0xbed3e4: ret             
    // 0xbed3e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbed3e8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbed3ec: b               #0xbed388
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x116fc5c, size: 0xd4
    // 0x116fc5c: EnterFrame
    //     0x116fc5c: stp             fp, lr, [SP, #-0x10]!
    //     0x116fc60: mov             fp, SP
    // 0x116fc64: AllocStack(0x28)
    //     0x116fc64: sub             SP, SP, #0x28
    // 0x116fc68: SetupParameters(ImageFilterLayer this /* r1 => r4, fp-0x20 */, dynamic _ /* r2 => r3, fp-0x28 */)
    //     0x116fc68: mov             x4, x1
    //     0x116fc6c: mov             x3, x2
    //     0x116fc70: stur            x1, [fp, #-0x20]
    //     0x116fc74: stur            x2, [fp, #-0x28]
    // 0x116fc78: CheckStackOverflow
    //     0x116fc78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116fc7c: cmp             SP, x16
    //     0x116fc80: b.ls            #0x116fd24
    // 0x116fc84: LoadField: r5 = r4->field_4b
    //     0x116fc84: ldur            w5, [x4, #0x4b]
    // 0x116fc88: DecompressPointer r5
    //     0x116fc88: add             x5, x5, HEAP, lsl #32
    // 0x116fc8c: stur            x5, [fp, #-0x18]
    // 0x116fc90: cmp             w5, NULL
    // 0x116fc94: b.eq            #0x116fd2c
    // 0x116fc98: LoadField: r6 = r4->field_47
    //     0x116fc98: ldur            w6, [x4, #0x47]
    // 0x116fc9c: DecompressPointer r6
    //     0x116fc9c: add             x6, x6, HEAP, lsl #32
    // 0x116fca0: stur            x6, [fp, #-0x10]
    // 0x116fca4: LoadField: r7 = r4->field_27
    //     0x116fca4: ldur            w7, [x4, #0x27]
    // 0x116fca8: DecompressPointer r7
    //     0x116fca8: add             x7, x7, HEAP, lsl #32
    // 0x116fcac: mov             x0, x7
    // 0x116fcb0: stur            x7, [fp, #-8]
    // 0x116fcb4: r2 = Null
    //     0x116fcb4: mov             x2, NULL
    // 0x116fcb8: r1 = Null
    //     0x116fcb8: mov             x1, NULL
    // 0x116fcbc: r4 = LoadClassIdInstr(r0)
    //     0x116fcbc: ldur            x4, [x0, #-1]
    //     0x116fcc0: ubfx            x4, x4, #0xc, #0x14
    // 0x116fcc4: cmp             x4, #0xee2
    // 0x116fcc8: b.eq            #0x116fce0
    // 0x116fccc: r8 = ImageFilterEngineLayer?
    //     0x116fccc: add             x8, PP, #0xa2, lsl #12  ; [pp+0xa2950] Type: ImageFilterEngineLayer?
    //     0x116fcd0: ldr             x8, [x8, #0x950]
    // 0x116fcd4: r3 = Null
    //     0x116fcd4: add             x3, PP, #0xa2, lsl #12  ; [pp+0xa2958] Null
    //     0x116fcd8: ldr             x3, [x3, #0x958]
    // 0x116fcdc: r0 = DefaultNullableTypeTest()
    //     0x116fcdc: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0x116fce0: ldur            x1, [fp, #-0x28]
    // 0x116fce4: ldur            x2, [fp, #-0x18]
    // 0x116fce8: ldur            x3, [fp, #-0x10]
    // 0x116fcec: ldur            x5, [fp, #-8]
    // 0x116fcf0: r0 = pushImageFilter()
    //     0x116fcf0: bl              #0x1170164  ; [dart:ui] _NativeSceneBuilder::pushImageFilter
    // 0x116fcf4: ldur            x1, [fp, #-0x20]
    // 0x116fcf8: mov             x2, x0
    // 0x116fcfc: r0 = engineLayer=()
    //     0x116fcfc: bl              #0xbecfac  ; [package:flutter/src/rendering/layer.dart] Layer::engineLayer=
    // 0x116fd00: ldur            x1, [fp, #-0x20]
    // 0x116fd04: ldur            x2, [fp, #-0x28]
    // 0x116fd08: r0 = addChildrenToScene()
    //     0x116fd08: bl              #0x116fe88  ; [package:flutter/src/rendering/layer.dart] ContainerLayer::addChildrenToScene
    // 0x116fd0c: ldur            x1, [fp, #-0x28]
    // 0x116fd10: r0 = pop()
    //     0x116fd10: bl              #0x116fd30  ; [dart:ui] _NativeSceneBuilder::pop
    // 0x116fd14: r0 = Null
    //     0x116fd14: mov             x0, NULL
    // 0x116fd18: LeaveFrame
    //     0x116fd18: mov             SP, fp
    //     0x116fd1c: ldp             fp, lr, [SP], #0x10
    // 0x116fd20: ret
    //     0x116fd20: ret             
    // 0x116fd24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116fd24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116fd28: b               #0x116fc84
    // 0x116fd2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x116fd2c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4665, size: 0x4c, field offset: 0x40
class PlatformViewLayer extends Layer {

  _ addToScene(/* No info */) {
    // ** addr: 0x116fac8, size: 0xd0
    // 0x116fac8: EnterFrame
    //     0x116fac8: stp             fp, lr, [SP, #-0x10]!
    //     0x116facc: mov             fp, SP
    // 0x116fad0: AllocStack(0x40)
    //     0x116fad0: sub             SP, SP, #0x40
    // 0x116fad4: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x116fad4: stur            x2, [fp, #-0x18]
    // 0x116fad8: CheckStackOverflow
    //     0x116fad8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116fadc: cmp             SP, x16
    //     0x116fae0: b.ls            #0x116fb8c
    // 0x116fae4: LoadField: r0 = r1->field_43
    //     0x116fae4: ldur            x0, [x1, #0x43]
    // 0x116fae8: stur            x0, [fp, #-0x10]
    // 0x116faec: LoadField: r3 = r1->field_3f
    //     0x116faec: ldur            w3, [x1, #0x3f]
    // 0x116faf0: DecompressPointer r3
    //     0x116faf0: add             x3, x3, HEAP, lsl #32
    // 0x116faf4: LoadField: d0 = r3->field_7
    //     0x116faf4: ldur            d0, [x3, #7]
    // 0x116faf8: stur            d0, [fp, #-0x38]
    // 0x116fafc: LoadField: d1 = r3->field_f
    //     0x116fafc: ldur            d1, [x3, #0xf]
    // 0x116fb00: stur            d1, [fp, #-0x30]
    // 0x116fb04: ArrayLoad: d2 = r3[0]  ; List_8
    //     0x116fb04: ldur            d2, [x3, #0x17]
    // 0x116fb08: fsub            d3, d2, d0
    // 0x116fb0c: stur            d3, [fp, #-0x28]
    // 0x116fb10: LoadField: d2 = r3->field_1f
    //     0x116fb10: ldur            d2, [x3, #0x1f]
    // 0x116fb14: fsub            d4, d2, d1
    // 0x116fb18: stur            d4, [fp, #-0x20]
    // 0x116fb1c: LoadField: r1 = r2->field_7
    //     0x116fb1c: ldur            w1, [x2, #7]
    // 0x116fb20: DecompressPointer r1
    //     0x116fb20: add             x1, x1, HEAP, lsl #32
    // 0x116fb24: cmp             w1, NULL
    // 0x116fb28: b.eq            #0x116fb94
    // 0x116fb2c: LoadField: r3 = r1->field_7
    //     0x116fb2c: ldur            x3, [x1, #7]
    // 0x116fb30: ldr             x1, [x3]
    // 0x116fb34: cbz             x1, #0x116fb7c
    // 0x116fb38: mov             x3, x1
    // 0x116fb3c: stur            x3, [fp, #-8]
    // 0x116fb40: r1 = <Never>
    //     0x116fb40: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x116fb44: r0 = Pointer()
    //     0x116fb44: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x116fb48: mov             x1, x0
    // 0x116fb4c: ldur            x0, [fp, #-8]
    // 0x116fb50: StoreField: r1->field_7 = r0
    //     0x116fb50: stur            x0, [x1, #7]
    // 0x116fb54: ldur            d0, [fp, #-0x38]
    // 0x116fb58: ldur            d1, [fp, #-0x30]
    // 0x116fb5c: ldur            d2, [fp, #-0x28]
    // 0x116fb60: ldur            d3, [fp, #-0x20]
    // 0x116fb64: ldur            x2, [fp, #-0x10]
    // 0x116fb68: r0 = __addPlatformView$Method$FfiNative()
    //     0x116fb68: bl              #0x116fb98  ; [dart:ui] _NativeSceneBuilder::__addPlatformView$Method$FfiNative
    // 0x116fb6c: r0 = Null
    //     0x116fb6c: mov             x0, NULL
    // 0x116fb70: LeaveFrame
    //     0x116fb70: mov             SP, fp
    //     0x116fb74: ldp             fp, lr, [SP], #0x10
    // 0x116fb78: ret
    //     0x116fb78: ret             
    // 0x116fb7c: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x116fb7c: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x116fb80: str             x16, [SP]
    // 0x116fb84: r0 = _throwNew()
    //     0x116fb84: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x116fb88: brk             #0
    // 0x116fb8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116fb8c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116fb90: b               #0x116fae4
    // 0x116fb94: r0 = NullErrorSharedWithFPURegs()
    //     0x116fb94: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 4666, size: 0x54, field offset: 0x40
class TextureLayer extends Layer {

  _ addToScene(/* No info */) {
    // ** addr: 0x116f918, size: 0xd8
    // 0x116f918: EnterFrame
    //     0x116f918: stp             fp, lr, [SP, #-0x10]!
    //     0x116f91c: mov             fp, SP
    // 0x116f920: AllocStack(0x40)
    //     0x116f920: sub             SP, SP, #0x40
    // 0x116f924: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x116f924: stur            x2, [fp, #-0x18]
    // 0x116f928: CheckStackOverflow
    //     0x116f928: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116f92c: cmp             SP, x16
    //     0x116f930: b.ls            #0x116f9e4
    // 0x116f934: LoadField: r0 = r1->field_43
    //     0x116f934: ldur            x0, [x1, #0x43]
    // 0x116f938: stur            x0, [fp, #-0x10]
    // 0x116f93c: LoadField: r3 = r1->field_3f
    //     0x116f93c: ldur            w3, [x1, #0x3f]
    // 0x116f940: DecompressPointer r3
    //     0x116f940: add             x3, x3, HEAP, lsl #32
    // 0x116f944: LoadField: d0 = r3->field_7
    //     0x116f944: ldur            d0, [x3, #7]
    // 0x116f948: stur            d0, [fp, #-0x38]
    // 0x116f94c: LoadField: d1 = r3->field_f
    //     0x116f94c: ldur            d1, [x3, #0xf]
    // 0x116f950: stur            d1, [fp, #-0x30]
    // 0x116f954: ArrayLoad: d2 = r3[0]  ; List_8
    //     0x116f954: ldur            d2, [x3, #0x17]
    // 0x116f958: fsub            d3, d2, d0
    // 0x116f95c: stur            d3, [fp, #-0x28]
    // 0x116f960: LoadField: d2 = r3->field_1f
    //     0x116f960: ldur            d2, [x3, #0x1f]
    // 0x116f964: fsub            d4, d2, d1
    // 0x116f968: stur            d4, [fp, #-0x20]
    // 0x116f96c: LoadField: r1 = r2->field_7
    //     0x116f96c: ldur            w1, [x2, #7]
    // 0x116f970: DecompressPointer r1
    //     0x116f970: add             x1, x1, HEAP, lsl #32
    // 0x116f974: cmp             w1, NULL
    // 0x116f978: b.eq            #0x116f9ec
    // 0x116f97c: LoadField: r3 = r1->field_7
    //     0x116f97c: ldur            x3, [x1, #7]
    // 0x116f980: ldr             x1, [x3]
    // 0x116f984: cbz             x1, #0x116f9d4
    // 0x116f988: mov             x3, x1
    // 0x116f98c: stur            x3, [fp, #-8]
    // 0x116f990: r1 = <Never>
    //     0x116f990: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x116f994: r0 = Pointer()
    //     0x116f994: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x116f998: mov             x1, x0
    // 0x116f99c: ldur            x0, [fp, #-8]
    // 0x116f9a0: StoreField: r1->field_7 = r0
    //     0x116f9a0: stur            x0, [x1, #7]
    // 0x116f9a4: ldur            d0, [fp, #-0x38]
    // 0x116f9a8: ldur            d1, [fp, #-0x30]
    // 0x116f9ac: ldur            d2, [fp, #-0x28]
    // 0x116f9b0: ldur            d3, [fp, #-0x20]
    // 0x116f9b4: ldur            x2, [fp, #-0x10]
    // 0x116f9b8: r3 = false
    //     0x116f9b8: add             x3, NULL, #0x30  ; false
    // 0x116f9bc: r5 = 1
    //     0x116f9bc: mov             x5, #1
    // 0x116f9c0: r0 = __addTexture$Method$FfiNative()
    //     0x116f9c0: bl              #0x116f9f0  ; [dart:ui] _NativeSceneBuilder::__addTexture$Method$FfiNative
    // 0x116f9c4: r0 = Null
    //     0x116f9c4: mov             x0, NULL
    // 0x116f9c8: LeaveFrame
    //     0x116f9c8: mov             SP, fp
    //     0x116f9cc: ldp             fp, lr, [SP], #0x10
    // 0x116f9d0: ret
    //     0x116f9d0: ret             
    // 0x116f9d4: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x116f9d4: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x116f9d8: str             x16, [SP]
    // 0x116f9dc: r0 = _throwNew()
    //     0x116f9dc: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x116f9e0: brk             #0
    // 0x116f9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116f9e4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116f9e8: b               #0x116f934
    // 0x116f9ec: r0 = NullErrorSharedWithFPURegs()
    //     0x116f9ec: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
}

// class id: 4667, size: 0x4c, field offset: 0x40
class PictureLayer extends Layer {

  set _ picture=(/* No info */) {
    // ** addr: 0x89a580, size: 0xdc
    // 0x89a580: EnterFrame
    //     0x89a580: stp             fp, lr, [SP, #-0x10]!
    //     0x89a584: mov             fp, SP
    // 0x89a588: AllocStack(0x28)
    //     0x89a588: sub             SP, SP, #0x28
    // 0x89a58c: SetupParameters(PictureLayer this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */)
    //     0x89a58c: mov             x0, x2
    //     0x89a590: stur            x2, [fp, #-0x10]
    //     0x89a594: mov             x2, x1
    //     0x89a598: stur            x1, [fp, #-8]
    // 0x89a59c: CheckStackOverflow
    //     0x89a59c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x89a5a0: cmp             SP, x16
    //     0x89a5a4: b.ls            #0x89a650
    // 0x89a5a8: mov             x1, x2
    // 0x89a5ac: r0 = markNeedsAddToScene()
    //     0x89a5ac: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0x89a5b0: ldur            x0, [fp, #-8]
    // 0x89a5b4: LoadField: r2 = r0->field_3f
    //     0x89a5b4: ldur            w2, [x0, #0x3f]
    // 0x89a5b8: DecompressPointer r2
    //     0x89a5b8: add             x2, x2, HEAP, lsl #32
    // 0x89a5bc: stur            x2, [fp, #-0x20]
    // 0x89a5c0: cmp             w2, NULL
    // 0x89a5c4: b.ne            #0x89a5d0
    // 0x89a5c8: mov             x1, x0
    // 0x89a5cc: b               #0x89a610
    // 0x89a5d0: LoadField: r1 = r2->field_7
    //     0x89a5d0: ldur            w1, [x2, #7]
    // 0x89a5d4: DecompressPointer r1
    //     0x89a5d4: add             x1, x1, HEAP, lsl #32
    // 0x89a5d8: cmp             w1, NULL
    // 0x89a5dc: b.eq            #0x89a658
    // 0x89a5e0: LoadField: r3 = r1->field_7
    //     0x89a5e0: ldur            x3, [x1, #7]
    // 0x89a5e4: ldr             x1, [x3]
    // 0x89a5e8: cbz             x1, #0x89a640
    // 0x89a5ec: mov             x3, x1
    // 0x89a5f0: stur            x3, [fp, #-0x18]
    // 0x89a5f4: r1 = <Never>
    //     0x89a5f4: ldr             x1, [PP, #0x2470]  ; [pp+0x2470] TypeArguments: <Never>
    // 0x89a5f8: r0 = Pointer()
    //     0x89a5f8: bl              #0x81b9fc  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0x89a5fc: mov             x1, x0
    // 0x89a600: ldur            x0, [fp, #-0x18]
    // 0x89a604: StoreField: r1->field_7 = r0
    //     0x89a604: stur            x0, [x1, #7]
    // 0x89a608: r0 = __dispose$Method$FfiNative()
    //     0x89a608: bl              #0x89a65c  ; [dart:ui] _NativePicture::__dispose$Method$FfiNative
    // 0x89a60c: ldur            x1, [fp, #-8]
    // 0x89a610: ldur            x0, [fp, #-0x10]
    // 0x89a614: StoreField: r1->field_3f = r0
    //     0x89a614: stur            w0, [x1, #0x3f]
    //     0x89a618: ldurb           w16, [x1, #-1]
    //     0x89a61c: ldurb           w17, [x0, #-1]
    //     0x89a620: and             x16, x17, x16, lsr #2
    //     0x89a624: tst             x16, HEAP, lsr #32
    //     0x89a628: b.eq            #0x89a630
    //     0x89a62c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x89a630: r0 = Null
    //     0x89a630: mov             x0, NULL
    // 0x89a634: LeaveFrame
    //     0x89a634: mov             SP, fp
    //     0x89a638: ldp             fp, lr, [SP], #0x10
    // 0x89a63c: ret
    //     0x89a63c: ret             
    // 0x89a640: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0x89a640: ldr             x16, [PP, #0x2478]  ; [pp+0x2478] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0x89a644: str             x16, [SP]
    // 0x89a648: r0 = _throwNew()
    //     0x89a648: bl              #0x7d927c  ; [dart:core] StateError::_throwNew
    // 0x89a64c: brk             #0
    // 0x89a650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x89a650: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x89a654: b               #0x89a5a8
    // 0x89a658: r0 = NullErrorSharedWithoutFPURegs()
    //     0x89a658: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
  }
  set _ isComplexHint=(/* No info */) {
    // ** addr: 0xc1c06c, size: 0x44
    // 0xc1c06c: EnterFrame
    //     0xc1c06c: stp             fp, lr, [SP, #-0x10]!
    //     0xc1c070: mov             fp, SP
    // 0xc1c074: CheckStackOverflow
    //     0xc1c074: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc1c078: cmp             SP, x16
    //     0xc1c07c: b.ls            #0xc1c0a8
    // 0xc1c080: LoadField: r0 = r1->field_43
    //     0xc1c080: ldur            w0, [x1, #0x43]
    // 0xc1c084: DecompressPointer r0
    //     0xc1c084: add             x0, x0, HEAP, lsl #32
    // 0xc1c088: tbz             w0, #4, #0xc1c098
    // 0xc1c08c: r0 = true
    //     0xc1c08c: add             x0, NULL, #0x20  ; true
    // 0xc1c090: StoreField: r1->field_43 = r0
    //     0xc1c090: stur            w0, [x1, #0x43]
    // 0xc1c094: r0 = markNeedsAddToScene()
    //     0xc1c094: bl              #0x89a714  ; [package:flutter/src/rendering/layer.dart] Layer::markNeedsAddToScene
    // 0xc1c098: r0 = Null
    //     0xc1c098: mov             x0, NULL
    // 0xc1c09c: LeaveFrame
    //     0xc1c09c: mov             SP, fp
    //     0xc1c0a0: ldp             fp, lr, [SP], #0x10
    // 0xc1c0a4: ret
    //     0xc1c0a4: ret             
    // 0xc1c0a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1c0a8: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1c0ac: b               #0xc1c080
  }
  _ dispose(/* No info */) {
    // ** addr: 0x10fc25c, size: 0x4c
    // 0x10fc25c: EnterFrame
    //     0x10fc25c: stp             fp, lr, [SP, #-0x10]!
    //     0x10fc260: mov             fp, SP
    // 0x10fc264: AllocStack(0x8)
    //     0x10fc264: sub             SP, SP, #8
    // 0x10fc268: SetupParameters(PictureLayer this /* r1 => r0, fp-0x8 */)
    //     0x10fc268: mov             x0, x1
    //     0x10fc26c: stur            x1, [fp, #-8]
    // 0x10fc270: CheckStackOverflow
    //     0x10fc270: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10fc274: cmp             SP, x16
    //     0x10fc278: b.ls            #0x10fc2a0
    // 0x10fc27c: mov             x1, x0
    // 0x10fc280: r2 = Null
    //     0x10fc280: mov             x2, NULL
    // 0x10fc284: r0 = picture=()
    //     0x10fc284: bl              #0x89a580  ; [package:flutter/src/rendering/layer.dart] PictureLayer::picture=
    // 0x10fc288: ldur            x1, [fp, #-8]
    // 0x10fc28c: r0 = dispose()
    //     0x10fc28c: bl              #0x10fc2a8  ; [package:flutter/src/rendering/layer.dart] Layer::dispose
    // 0x10fc290: r0 = Null
    //     0x10fc290: mov             x0, NULL
    // 0x10fc294: LeaveFrame
    //     0x10fc294: mov             SP, fp
    //     0x10fc298: ldp             fp, lr, [SP], #0x10
    // 0x10fc29c: ret
    //     0x10fc29c: ret             
    // 0x10fc2a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10fc2a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10fc2a4: b               #0x10fc27c
  }
  _ addToScene(/* No info */) {
    // ** addr: 0x116f6c0, size: 0x5c
    // 0x116f6c0: EnterFrame
    //     0x116f6c0: stp             fp, lr, [SP, #-0x10]!
    //     0x116f6c4: mov             fp, SP
    // 0x116f6c8: mov             x0, x1
    // 0x116f6cc: mov             x1, x2
    // 0x116f6d0: CheckStackOverflow
    //     0x116f6d0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x116f6d4: cmp             SP, x16
    //     0x116f6d8: b.ls            #0x116f710
    // 0x116f6dc: LoadField: r3 = r0->field_3f
    //     0x116f6dc: ldur            w3, [x0, #0x3f]
    // 0x116f6e0: DecompressPointer r3
    //     0x116f6e0: add             x3, x3, HEAP, lsl #32
    // 0x116f6e4: cmp             w3, NULL
    // 0x116f6e8: b.eq            #0x116f718
    // 0x116f6ec: LoadField: r5 = r0->field_43
    //     0x116f6ec: ldur            w5, [x0, #0x43]
    // 0x116f6f0: DecompressPointer r5
    //     0x116f6f0: add             x5, x5, HEAP, lsl #32
    // 0x116f6f4: r2 = Instance_Offset
    //     0x116f6f4: ldr             x2, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0x116f6f8: r6 = false
    //     0x116f6f8: add             x6, NULL, #0x30  ; false
    // 0x116f6fc: r0 = addPicture()
    //     0x116f6fc: bl              #0x116f71c  ; [dart:ui] _NativeSceneBuilder::addPicture
    // 0x116f700: r0 = Null
    //     0x116f700: mov             x0, NULL
    // 0x116f704: LeaveFrame
    //     0x116f704: mov             SP, fp
    //     0x116f708: ldp             fp, lr, [SP], #0x10
    // 0x116f70c: ret
    //     0x116f70c: ret             
    // 0x116f710: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x116f710: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x116f714: b               #0x116f6dc
    // 0x116f718: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x116f718: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}
