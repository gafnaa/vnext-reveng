// lib: , url: package:flutter/src/rendering/viewport.dart

// class id: 1049055, size: 0x8
class :: {
}

// class id: 2839, size: 0x14, field offset: 0x8
//   const constructor, 
class RevealedOffset extends Object {
}

// class id: 2840, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class ScrollCacheExtent extends Object {
}

// class id: 2841, size: 0x10, field offset: 0x8
//   const constructor, 
class _ViewportScrollCacheExtent extends ScrollCacheExtent {

  get _ hashCode(/* No info */) {
    // ** addr: 0x114cc58, size: 0x58
    // 0x114cc58: d0 = 0.000000
    //     0x114cc58: eor             v0.16b, v0.16b, v0.16b
    // 0x114cc5c: mov             x16, v0.d[0]
    // 0x114cc60: and             x16, x16, #0x7ff0000000000000
    // 0x114cc64: r17 = 9218868437227405312
    //     0x114cc64: mov             x17, #0x7ff0000000000000
    // 0x114cc68: cmp             x16, x17
    // 0x114cc6c: b.eq            #0x114cc9c
    // 0x114cc70: fcvtzs          x16, d0
    // 0x114cc74: scvtf           d1, x16
    // 0x114cc78: fcmp            d1, d0
    // 0x114cc7c: b.ne            #0x114cc9c
    // 0x114cc80: r17 = 11601
    //     0x114cc80: mov             x17, #0x2d51
    // 0x114cc84: mul             x1, x16, x17
    // 0x114cc88: umulh           x16, x16, x17
    // 0x114cc8c: eor             x1, x1, x16
    // 0x114cc90: r1 = 0
    //     0x114cc90: eor             x1, x1, x1, lsr #32
    // 0x114cc94: and             x1, x1, #0x3fffffff
    // 0x114cc98: b               #0x114cca8
    // 0x114cc9c: r1 = 0.000000
    //     0x114cc9c: fmov            x1, d0
    // 0x114cca0: r1 = 0
    //     0x114cca0: eor             x1, x1, x1, lsr #32
    // 0x114cca4: and             x1, x1, #0x3fffffff
    // 0x114cca8: lsl             x0, x1, #1
    // 0x114ccac: ret
    //     0x114ccac: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x129a680, size: 0x64
    // 0x129a680: ldr             x1, [SP]
    // 0x129a684: cmp             w1, NULL
    // 0x129a688: b.ne            #0x129a694
    // 0x129a68c: r0 = false
    //     0x129a68c: add             x0, NULL, #0x30  ; false
    // 0x129a690: ret
    //     0x129a690: ret             
    // 0x129a694: ldr             x2, [SP, #8]
    // 0x129a698: cmp             w2, w1
    // 0x129a69c: b.ne            #0x129a6a8
    // 0x129a6a0: r0 = true
    //     0x129a6a0: add             x0, NULL, #0x20  ; true
    // 0x129a6a4: ret
    //     0x129a6a4: ret             
    // 0x129a6a8: r2 = 60
    //     0x129a6a8: mov             x2, #0x3c
    // 0x129a6ac: branchIfSmi(r1, 0x129a6b8)
    //     0x129a6ac: tbz             w1, #0, #0x129a6b8
    // 0x129a6b0: r2 = LoadClassIdInstr(r1)
    //     0x129a6b0: ldur            x2, [x1, #-1]
    //     0x129a6b4: ubfx            x2, x2, #0xc, #0x14
    // 0x129a6b8: cmp             x2, #0xb19
    // 0x129a6bc: b.ne            #0x129a6dc
    // 0x129a6c0: d0 = 0.000000
    //     0x129a6c0: eor             v0.16b, v0.16b, v0.16b
    // 0x129a6c4: fcmp            d0, d0
    // 0x129a6c8: r16 = true
    //     0x129a6c8: add             x16, NULL, #0x20  ; true
    // 0x129a6cc: r17 = false
    //     0x129a6cc: add             x17, NULL, #0x30  ; false
    // 0x129a6d0: csel            x1, x16, x17, eq
    // 0x129a6d4: mov             x0, x1
    // 0x129a6d8: b               #0x129a6e0
    // 0x129a6dc: r0 = false
    //     0x129a6dc: add             x0, NULL, #0x30  ; false
    // 0x129a6e0: ret
    //     0x129a6e0: ret             
  }
}

// class id: 2842, size: 0x10, field offset: 0x8
//   const constructor, 
class _PixelScrollCacheExtent extends ScrollCacheExtent {

  _Double field_8;

  double dyn:get:value(_PixelScrollCacheExtent) {
    // ** addr: 0xcf20c0, size: 0x24
    // 0xcf20c0: r0 = 250.000000
    //     0xcf20c0: add             x0, PP, #0x22, lsl #12  ; [pp+0x222e0] 250
    //     0xcf20c4: ldr             x0, [x0, #0x2e0]
    // 0xcf20c8: ret
    //     0xcf20c8: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0x114cbfc, size: 0x5c
    // 0x114cbfc: d0 = 250.000000
    //     0x114cbfc: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cf30] IMM: double(250) from 0x406f400000000000
    //     0x114cc00: ldr             d0, [x17, #0xf30]
    // 0x114cc04: mov             x16, v0.d[0]
    // 0x114cc08: and             x16, x16, #0x7ff0000000000000
    // 0x114cc0c: r17 = 9218868437227405312
    //     0x114cc0c: mov             x17, #0x7ff0000000000000
    // 0x114cc10: cmp             x16, x17
    // 0x114cc14: b.eq            #0x114cc44
    // 0x114cc18: fcvtzs          x16, d0
    // 0x114cc1c: scvtf           d1, x16
    // 0x114cc20: fcmp            d1, d0
    // 0x114cc24: b.ne            #0x114cc44
    // 0x114cc28: r17 = 11601
    //     0x114cc28: mov             x17, #0x2d51
    // 0x114cc2c: mul             x1, x16, x17
    // 0x114cc30: umulh           x16, x16, x17
    // 0x114cc34: eor             x1, x1, x16
    // 0x114cc38: r1 = 0
    //     0x114cc38: eor             x1, x1, x1, lsr #32
    // 0x114cc3c: and             x1, x1, #0x3fffffff
    // 0x114cc40: b               #0x114cc50
    // 0x114cc44: r1 = 0.000000
    //     0x114cc44: fmov            x1, d0
    // 0x114cc48: r1 = 0
    //     0x114cc48: eor             x1, x1, x1, lsr #32
    // 0x114cc4c: and             x1, x1, #0x3fffffff
    // 0x114cc50: lsl             x0, x1, #1
    // 0x114cc54: ret
    //     0x114cc54: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0x129a618, size: 0x68
    // 0x129a618: ldr             x1, [SP]
    // 0x129a61c: cmp             w1, NULL
    // 0x129a620: b.ne            #0x129a62c
    // 0x129a624: r0 = false
    //     0x129a624: add             x0, NULL, #0x30  ; false
    // 0x129a628: ret
    //     0x129a628: ret             
    // 0x129a62c: ldr             x2, [SP, #8]
    // 0x129a630: cmp             w2, w1
    // 0x129a634: b.ne            #0x129a640
    // 0x129a638: r0 = true
    //     0x129a638: add             x0, NULL, #0x20  ; true
    // 0x129a63c: ret
    //     0x129a63c: ret             
    // 0x129a640: r2 = 60
    //     0x129a640: mov             x2, #0x3c
    // 0x129a644: branchIfSmi(r1, 0x129a650)
    //     0x129a644: tbz             w1, #0, #0x129a650
    // 0x129a648: r2 = LoadClassIdInstr(r1)
    //     0x129a648: ldur            x2, [x1, #-1]
    //     0x129a64c: ubfx            x2, x2, #0xc, #0x14
    // 0x129a650: cmp             x2, #0xb1a
    // 0x129a654: b.ne            #0x129a678
    // 0x129a658: d0 = 250.000000
    //     0x129a658: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cf30] IMM: double(250) from 0x406f400000000000
    //     0x129a65c: ldr             d0, [x17, #0xf30]
    // 0x129a660: fcmp            d0, d0
    // 0x129a664: r16 = true
    //     0x129a664: add             x16, NULL, #0x20  ; true
    // 0x129a668: r17 = false
    //     0x129a668: add             x17, NULL, #0x30  ; false
    // 0x129a66c: csel            x1, x16, x17, eq
    // 0x129a670: mov             x0, x1
    // 0x129a674: b               #0x129a67c
    // 0x129a678: r0 = false
    //     0x129a678: add             x0, NULL, #0x30  ; false
    // 0x129a67c: ret
    //     0x129a67c: ret             
  }
}

// class id: 4676, size: 0x48, field offset: 0x48
abstract class RenderAbstractViewport extends RenderObject {

  static _ maybeOf(/* No info */) {
    // ** addr: 0x863d80, size: 0xd8
    // 0x863d80: EnterFrame
    //     0x863d80: stp             fp, lr, [SP, #-0x10]!
    //     0x863d84: mov             fp, SP
    // 0x863d88: AllocStack(0x8)
    //     0x863d88: sub             SP, SP, #8
    // 0x863d8c: CheckStackOverflow
    //     0x863d8c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x863d90: cmp             SP, x16
    //     0x863d94: b.ls            #0x863e48
    // 0x863d98: mov             x3, x1
    // 0x863d9c: stur            x3, [fp, #-8]
    // 0x863da0: CheckStackOverflow
    //     0x863da0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x863da4: cmp             SP, x16
    //     0x863da8: b.ls            #0x863e50
    // 0x863dac: cmp             w3, NULL
    // 0x863db0: b.eq            #0x863e38
    // 0x863db4: mov             x0, x3
    // 0x863db8: r2 = Null
    //     0x863db8: mov             x2, NULL
    // 0x863dbc: r1 = Null
    //     0x863dbc: mov             x1, NULL
    // 0x863dc0: cmp             w0, NULL
    // 0x863dc4: b.eq            #0x863dec
    // 0x863dc8: branchIfSmi(r0, 0x863dec)
    //     0x863dc8: tbz             w0, #0, #0x863dec
    // 0x863dcc: r3 = LoadClassIdInstr(r0)
    //     0x863dcc: ldur            x3, [x0, #-1]
    //     0x863dd0: ubfx            x3, x3, #0xc, #0x14
    // 0x863dd4: r17 = -4838
    //     0x863dd4: mov             x17, #-0x12e6
    // 0x863dd8: add             x3, x3, x17
    // 0x863ddc: cmp             x3, #1
    // 0x863de0: b.ls            #0x863df4
    // 0x863de4: cmp             x3, #0x1d
    // 0x863de8: b.eq            #0x863df4
    // 0x863dec: r0 = false
    //     0x863dec: add             x0, NULL, #0x30  ; false
    // 0x863df0: b               #0x863df8
    // 0x863df4: r0 = true
    //     0x863df4: add             x0, NULL, #0x20  ; true
    // 0x863df8: tbz             w0, #4, #0x863e24
    // 0x863dfc: ldur            x1, [fp, #-8]
    // 0x863e00: r0 = LoadClassIdInstr(r1)
    //     0x863e00: ldur            x0, [x1, #-1]
    //     0x863e04: ubfx            x0, x0, #0xc, #0x14
    // 0x863e08: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x863e08: mov             x17, #0xfc0
    //     0x863e0c: movk            x17, #1, lsl #16
    //     0x863e10: add             lr, x0, x17
    //     0x863e14: ldr             lr, [x21, lr, lsl #3]
    //     0x863e18: blr             lr
    // 0x863e1c: mov             x3, x0
    // 0x863e20: b               #0x863d9c
    // 0x863e24: ldur            x1, [fp, #-8]
    // 0x863e28: mov             x0, x1
    // 0x863e2c: LeaveFrame
    //     0x863e2c: mov             SP, fp
    //     0x863e30: ldp             fp, lr, [SP], #0x10
    // 0x863e34: ret
    //     0x863e34: ret             
    // 0x863e38: r0 = Null
    //     0x863e38: mov             x0, NULL
    // 0x863e3c: LeaveFrame
    //     0x863e3c: mov             SP, fp
    //     0x863e40: ldp             fp, lr, [SP], #0x10
    // 0x863e44: ret
    //     0x863e44: ret             
    // 0x863e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863e48: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863e4c: b               #0x863d98
    // 0x863e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863e50: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863e54: b               #0x863dac
  }
}

// class id: 4837, size: 0x84, field offset: 0x64
abstract class RenderViewportBase<X0 bound ContainerParentDataMixin> extends _MixinApplication236&RenderBox&ContainerRenderObjectMixin<X0 bound ContainerParentDataMixin>
    implements RenderAbstractViewport {

  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0xb1fb9c, size: 0x24
    // 0xb1fb9c: EnterFrame
    //     0xb1fb9c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1fba0: mov             fp, SP
    // 0xb1fba4: ldr             x2, [fp, #0x10]
    // 0xb1fba8: r1 = Function 'computeMinIntrinsicWidth':.
    //     0xb1fba8: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa11d8] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb1fbac: ldr             x1, [x1, #0x1d8]
    // 0xb1fbb0: r0 = AllocateClosure()
    //     0xb1fbb0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb1fbb4: LeaveFrame
    //     0xb1fbb4: mov             SP, fp
    //     0xb1fbb8: ldp             fp, lr, [SP], #0x10
    // 0xb1fbbc: ret
    //     0xb1fbbc: ret             
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0xb58654, size: 0x24
    // 0xb58654: EnterFrame
    //     0xb58654: stp             fp, lr, [SP, #-0x10]!
    //     0xb58658: mov             fp, SP
    // 0xb5865c: ldr             x2, [fp, #0x10]
    // 0xb58660: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0xb58660: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa11d0] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb58664: ldr             x1, [x1, #0x1d0]
    // 0xb58668: r0 = AllocateClosure()
    //     0xb58668: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5866c: LeaveFrame
    //     0xb5866c: mov             SP, fp
    //     0xb58670: ldp             fp, lr, [SP], #0x10
    // 0xb58674: ret
    //     0xb58674: ret             
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0xb5e800, size: 0x24
    // 0xb5e800: EnterFrame
    //     0xb5e800: stp             fp, lr, [SP, #-0x10]!
    //     0xb5e804: mov             fp, SP
    // 0xb5e808: ldr             x2, [fp, #0x10]
    // 0xb5e80c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0xb5e80c: add             x1, PP, #0x96, lsl #12  ; [pp+0x963a0] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0xb5e810: ldr             x1, [x1, #0x3a0]
    // 0xb5e814: r0 = AllocateClosure()
    //     0xb5e814: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xb5e818: LeaveFrame
    //     0xb5e818: mov             SP, fp
    //     0xb5e81c: ldp             fp, lr, [SP], #0x10
    // 0xb5e820: ret
    //     0xb5e820: ret             
  }
  _ layoutChildSequence(/* No info */) {
    // ** addr: 0xbc7638, size: 0x7c4
    // 0xbc7638: EnterFrame
    //     0xbc7638: stp             fp, lr, [SP, #-0x10]!
    //     0xbc763c: mov             fp, SP
    // 0xbc7640: AllocStack(0xe0)
    //     0xbc7640: sub             SP, SP, #0xe0
    // 0xbc7644: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r0, fp-0x20 */, dynamic _ /* d0 => d0, fp-0x58 */, dynamic _ /* d1 => d1, fp-0x60 */, dynamic _ /* d2 => d2, fp-0x68 */, dynamic _ /* d3 => d3, fp-0x70 */, dynamic _ /* d4 => d4, fp-0x78 */, dynamic _ /* d5 => d5, fp-0x80 */)
    //     0xbc7644: mov             x0, x5
    //     0xbc7648: stur            x5, [fp, #-0x20]
    //     0xbc764c: mov             x5, x1
    //     0xbc7650: mov             x4, x2
    //     0xbc7654: stur            x1, [fp, #-8]
    //     0xbc7658: stur            x2, [fp, #-0x10]
    //     0xbc765c: stur            x3, [fp, #-0x18]
    //     0xbc7660: stur            d0, [fp, #-0x58]
    //     0xbc7664: stur            d1, [fp, #-0x60]
    //     0xbc7668: stur            d2, [fp, #-0x68]
    //     0xbc766c: stur            d3, [fp, #-0x70]
    //     0xbc7670: stur            d4, [fp, #-0x78]
    //     0xbc7674: stur            d5, [fp, #-0x80]
    // 0xbc7678: CheckStackOverflow
    //     0xbc7678: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc767c: cmp             SP, x16
    //     0xbc7680: b.ls            #0xbc7d30
    // 0xbc7684: LoadField: r1 = r5->field_6b
    //     0xbc7684: ldur            w1, [x5, #0x6b]
    // 0xbc7688: DecompressPointer r1
    //     0xbc7688: add             x1, x1, HEAP, lsl #32
    // 0xbc768c: LoadField: r2 = r1->field_73
    //     0xbc768c: ldur            w2, [x1, #0x73]
    // 0xbc7690: DecompressPointer r2
    //     0xbc7690: add             x2, x2, HEAP, lsl #32
    // 0xbc7694: mov             x1, x2
    // 0xbc7698: mov             x2, x0
    // 0xbc769c: r0 = applyGrowthDirectionToScrollDirection()
    //     0xbc769c: bl              #0xbc7f68  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToScrollDirection
    // 0xbc76a0: ldur            d1, [fp, #-0x68]
    // 0xbc76a4: ldur            d0, [fp, #-0x78]
    // 0xbc76a8: stur            x0, [fp, #-0x50]
    // 0xbc76ac: fadd            d2, d1, d0
    // 0xbc76b0: ldur            x1, [fp, #-8]
    // 0xbc76b4: r2 = LoadClassIdInstr(r1)
    //     0xbc76b4: ldur            x2, [x1, #-1]
    //     0xbc76b8: ubfx            x2, x2, #0xc, #0x14
    // 0xbc76bc: stur            x2, [fp, #-0x48]
    // 0xbc76c0: r3 = LoadClassIdInstr(r1)
    //     0xbc76c0: ldur            x3, [x1, #-1]
    //     0xbc76c4: ubfx            x3, x3, #0xc, #0x14
    // 0xbc76c8: stur            x3, [fp, #-0x40]
    // 0xbc76cc: r4 = LoadClassIdInstr(r1)
    //     0xbc76cc: ldur            x4, [x1, #-1]
    //     0xbc76d0: ubfx            x4, x4, #0xc, #0x14
    // 0xbc76d4: ldr             d0, [fp, #0x10]
    // 0xbc76d8: stur            x4, [fp, #-0x38]
    // 0xbc76dc: ldur            d10, [fp, #-0x58]
    // 0xbc76e0: ldur            x6, [fp, #-0x18]
    // 0xbc76e4: mov             v9.16b, v1.16b
    // 0xbc76e8: ldur            d8, [fp, #-0x80]
    // 0xbc76ec: mov             v7.16b, v0.16b
    // 0xbc76f0: mov             v6.16b, v2.16b
    // 0xbc76f4: d5 = 0.000000
    //     0xbc76f4: eor             v5.16b, v5.16b, v5.16b
    // 0xbc76f8: ldur            d2, [fp, #-0x60]
    // 0xbc76fc: ldur            x5, [fp, #-0x20]
    // 0xbc7700: ldur            d0, [fp, #-0x70]
    // 0xbc7704: ldr             d4, [fp, #0x18]
    // 0xbc7708: d3 = 0.000000
    //     0xbc7708: eor             v3.16b, v3.16b, v3.16b
    // 0xbc770c: stur            x6, [fp, #-0x30]
    // 0xbc7710: stur            d10, [fp, #-0xa0]
    // 0xbc7714: stur            d9, [fp, #-0xa8]
    // 0xbc7718: stur            d8, [fp, #-0xb0]
    // 0xbc771c: stur            d7, [fp, #-0xb8]
    // 0xbc7720: stur            d6, [fp, #-0xc0]
    // 0xbc7724: stur            d5, [fp, #-0xc8]
    // 0xbc7728: CheckStackOverflow
    //     0xbc7728: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc772c: cmp             SP, x16
    //     0xbc7730: b.ls            #0xbc7d38
    // 0xbc7734: cmp             w6, NULL
    // 0xbc7738: b.eq            #0xbc7d20
    // 0xbc773c: fcmp            d3, d7
    // 0xbc7740: b.lt            #0xbc774c
    // 0xbc7744: d11 = 0.000000
    //     0xbc7744: eor             v11.16b, v11.16b, v11.16b
    // 0xbc7748: b               #0xbc7750
    // 0xbc774c: mov             v11.16b, v7.16b
    // 0xbc7750: stur            d11, [fp, #-0x98]
    // 0xbc7754: fneg            d12, d11
    // 0xbc7758: fmax            v13.2d, v10.2d, v12.2d
    // 0xbc775c: stur            d13, [fp, #-0x90]
    // 0xbc7760: fsub            d12, d10, d13
    // 0xbc7764: stur            d12, [fp, #-0x88]
    // 0xbc7768: LoadField: r7 = r1->field_63
    //     0xbc7768: ldur            w7, [x1, #0x63]
    // 0xbc776c: DecompressPointer r7
    //     0xbc776c: add             x7, x7, HEAP, lsl #32
    // 0xbc7770: stur            x7, [fp, #-0x28]
    // 0xbc7774: fsub            d14, d6, d9
    // 0xbc7778: stur            d14, [fp, #-0x80]
    // 0xbc777c: fsub            d15, d4, d9
    // 0xbc7780: fadd            d16, d15, d1
    // 0xbc7784: fmax            v15.2d, v3.2d, v16.2d
    // 0xbc7788: stur            d15, [fp, #-0x78]
    // 0xbc778c: LoadField: r8 = r1->field_67
    //     0xbc778c: ldur            w8, [x1, #0x67]
    // 0xbc7790: DecompressPointer r8
    //     0xbc7790: add             x8, x8, HEAP, lsl #32
    // 0xbc7794: stur            x8, [fp, #-0x18]
    // 0xbc7798: fadd            d16, d8, d12
    // 0xbc779c: fmax            v17.2d, v3.2d, v16.2d
    // 0xbc77a0: stur            d17, [fp, #-0x58]
    // 0xbc77a4: r0 = SliverConstraints()
    //     0xbc77a4: bl              #0xbc7f5c  ; AllocateSliverConstraintsStub -> SliverConstraints (size=0x58)
    // 0xbc77a8: mov             x1, x0
    // 0xbc77ac: ldur            x0, [fp, #-0x28]
    // 0xbc77b0: StoreField: r1->field_7 = r0
    //     0xbc77b0: stur            w0, [x1, #7]
    // 0xbc77b4: ldur            x3, [fp, #-0x20]
    // 0xbc77b8: StoreField: r1->field_b = r3
    //     0xbc77b8: stur            w3, [x1, #0xb]
    // 0xbc77bc: ldur            x0, [fp, #-0x50]
    // 0xbc77c0: StoreField: r1->field_f = r0
    //     0xbc77c0: stur            w0, [x1, #0xf]
    // 0xbc77c4: ldur            d0, [fp, #-0x98]
    // 0xbc77c8: StoreField: r1->field_13 = d0
    //     0xbc77c8: stur            d0, [x1, #0x13]
    // 0xbc77cc: ldur            d0, [fp, #-0xc8]
    // 0xbc77d0: StoreField: r1->field_1b = d0
    //     0xbc77d0: stur            d0, [x1, #0x1b]
    // 0xbc77d4: ldur            d1, [fp, #-0x80]
    // 0xbc77d8: StoreField: r1->field_23 = d1
    //     0xbc77d8: stur            d1, [x1, #0x23]
    // 0xbc77dc: ldur            d1, [fp, #-0x78]
    // 0xbc77e0: StoreField: r1->field_2b = d1
    //     0xbc77e0: stur            d1, [x1, #0x2b]
    // 0xbc77e4: ldur            d1, [fp, #-0x60]
    // 0xbc77e8: StoreField: r1->field_33 = d1
    //     0xbc77e8: stur            d1, [x1, #0x33]
    // 0xbc77ec: ldur            x2, [fp, #-0x18]
    // 0xbc77f0: StoreField: r1->field_3b = r2
    //     0xbc77f0: stur            w2, [x1, #0x3b]
    // 0xbc77f4: ldur            d2, [fp, #-0x70]
    // 0xbc77f8: StoreField: r1->field_3f = d2
    //     0xbc77f8: stur            d2, [x1, #0x3f]
    // 0xbc77fc: ldur            d3, [fp, #-0x58]
    // 0xbc7800: StoreField: r1->field_4f = d3
    //     0xbc7800: stur            d3, [x1, #0x4f]
    // 0xbc7804: ldur            d3, [fp, #-0x90]
    // 0xbc7808: StoreField: r1->field_47 = d3
    //     0xbc7808: stur            d3, [x1, #0x47]
    // 0xbc780c: r16 = true
    //     0xbc780c: add             x16, NULL, #0x20  ; true
    // 0xbc7810: str             x16, [SP]
    // 0xbc7814: mov             x2, x1
    // 0xbc7818: ldur            x1, [fp, #-0x30]
    // 0xbc781c: r4 = const [0, 0x3, 0x1, 0x2, parentUsesSize, 0x2, null]
    //     0xbc781c: add             x4, PP, #0xd, lsl #12  ; [pp+0xded0] List(7) [0, 0x3, 0x1, 0x2, "parentUsesSize", 0x2, Null]
    //     0xbc7820: ldr             x4, [x4, #0xed0]
    // 0xbc7824: r0 = layout()
    //     0xbc7824: bl              #0xcd00ac  ; [package:flutter/src/rendering/object.dart] RenderObject::layout
    // 0xbc7828: ldur            x3, [fp, #-0x30]
    // 0xbc782c: LoadField: r4 = r3->field_47
    //     0xbc782c: ldur            w4, [x3, #0x47]
    // 0xbc7830: DecompressPointer r4
    //     0xbc7830: add             x4, x4, HEAP, lsl #32
    // 0xbc7834: stur            x4, [fp, #-0x28]
    // 0xbc7838: cmp             w4, NULL
    // 0xbc783c: b.eq            #0xbc7d40
    // 0xbc7840: LoadField: r0 = r4->field_47
    //     0xbc7840: ldur            w0, [x4, #0x47]
    // 0xbc7844: DecompressPointer r0
    //     0xbc7844: add             x0, x0, HEAP, lsl #32
    // 0xbc7848: cmp             w0, NULL
    // 0xbc784c: b.ne            #0xbc7d10
    // 0xbc7850: ldur            d1, [fp, #-0xa8]
    // 0xbc7854: d0 = 0.000000
    //     0xbc7854: eor             v0.16b, v0.16b, v0.16b
    // 0xbc7858: fadd            d2, d1, d0
    // 0xbc785c: stur            d2, [fp, #-0x58]
    // 0xbc7860: LoadField: r0 = r4->field_3f
    //     0xbc7860: ldur            w0, [x4, #0x3f]
    // 0xbc7864: DecompressPointer r0
    //     0xbc7864: add             x0, x0, HEAP, lsl #32
    // 0xbc7868: tbnz            w0, #4, #0xbc7874
    // 0xbc786c: ldur            d3, [fp, #-0xb8]
    // 0xbc7870: b               #0xbc7880
    // 0xbc7874: ldur            d3, [fp, #-0xb8]
    // 0xbc7878: fcmp            d3, d0
    // 0xbc787c: b.le            #0xbc79b8
    // 0xbc7880: ldur            x5, [fp, #-0x38]
    // 0xbc7884: r17 = 4838
    //     0xbc7884: mov             x17, #0x12e6
    // 0xbc7888: cmp             x5, x17
    // 0xbc788c: b.ne            #0xbc7930
    // 0xbc7890: LoadField: r6 = r3->field_7
    //     0xbc7890: ldur            w6, [x3, #7]
    // 0xbc7894: DecompressPointer r6
    //     0xbc7894: add             x6, x6, HEAP, lsl #32
    // 0xbc7898: stur            x6, [fp, #-0x18]
    // 0xbc789c: cmp             w6, NULL
    // 0xbc78a0: b.eq            #0xbc7d44
    // 0xbc78a4: mov             x0, x6
    // 0xbc78a8: r2 = Null
    //     0xbc78a8: mov             x2, NULL
    // 0xbc78ac: r1 = Null
    //     0xbc78ac: mov             x1, NULL
    // 0xbc78b0: r4 = LoadClassIdInstr(r0)
    //     0xbc78b0: ldur            x4, [x0, #-1]
    //     0xbc78b4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc78b8: r17 = -4183
    //     0xbc78b8: mov             x17, #-0x1057
    // 0xbc78bc: add             x4, x4, x17
    // 0xbc78c0: cmp             x4, #3
    // 0xbc78c4: b.ls            #0xbc78dc
    // 0xbc78c8: r8 = SliverLogicalParentData
    //     0xbc78c8: add             x8, PP, #0x96, lsl #12  ; [pp+0x961c0] Type: SliverLogicalParentData
    //     0xbc78cc: ldr             x8, [x8, #0x1c0]
    // 0xbc78d0: r3 = Null
    //     0xbc78d0: add             x3, PP, #0x96, lsl #12  ; [pp+0x96230] Null
    //     0xbc78d4: ldr             x3, [x3, #0x230]
    // 0xbc78d8: r0 = DefaultTypeTest()
    //     0xbc78d8: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc78dc: ldur            d0, [fp, #-0x58]
    // 0xbc78e0: r0 = inline_Allocate_Double()
    //     0xbc78e0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc78e4: add             x0, x0, #0x10
    //     0xbc78e8: cmp             x1, x0
    //     0xbc78ec: b.ls            #0xbc7d48
    //     0xbc78f0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc78f4: sub             x0, x0, #0xf
    //     0xbc78f8: mov             x1, #0xe19c
    //     0xbc78fc: movk            x1, #3, lsl #16
    //     0xbc7900: stur            x1, [x0, #-1]
    // 0xbc7904: dmb             ishst
    // 0xbc7908: StoreField: r0->field_7 = d0
    //     0xbc7908: stur            d0, [x0, #7]
    // 0xbc790c: ldur            x1, [fp, #-0x18]
    // 0xbc7910: StoreField: r1->field_7 = r0
    //     0xbc7910: stur            w0, [x1, #7]
    //     0xbc7914: ldurb           w16, [x1, #-1]
    //     0xbc7918: ldurb           w17, [x0, #-1]
    //     0xbc791c: and             x16, x17, x16, lsr #2
    //     0xbc7920: tst             x16, HEAP, lsr #32
    //     0xbc7924: b.eq            #0xbc792c
    //     0xbc7928: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc792c: b               #0xbc7b08
    // 0xbc7930: mov             v0.16b, v2.16b
    // 0xbc7934: LoadField: r4 = r3->field_7
    //     0xbc7934: ldur            w4, [x3, #7]
    // 0xbc7938: DecompressPointer r4
    //     0xbc7938: add             x4, x4, HEAP, lsl #32
    // 0xbc793c: stur            x4, [fp, #-0x18]
    // 0xbc7940: cmp             w4, NULL
    // 0xbc7944: b.eq            #0xbc7d58
    // 0xbc7948: mov             x0, x4
    // 0xbc794c: r2 = Null
    //     0xbc794c: mov             x2, NULL
    // 0xbc7950: r1 = Null
    //     0xbc7950: mov             x1, NULL
    // 0xbc7954: r4 = LoadClassIdInstr(r0)
    //     0xbc7954: ldur            x4, [x0, #-1]
    //     0xbc7958: ubfx            x4, x4, #0xc, #0x14
    // 0xbc795c: r17 = -4177
    //     0xbc795c: mov             x17, #-0x1051
    // 0xbc7960: add             x4, x4, x17
    // 0xbc7964: cmp             x4, #2
    // 0xbc7968: b.ls            #0xbc7980
    // 0xbc796c: r8 = SliverPhysicalParentData
    //     0xbc796c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0xbc7970: ldr             x8, [x8, #0x240]
    // 0xbc7974: r3 = Null
    //     0xbc7974: add             x3, PP, #0x96, lsl #12  ; [pp+0x96248] Null
    //     0xbc7978: ldr             x3, [x3, #0x248]
    // 0xbc797c: r0 = DefaultTypeTest()
    //     0xbc797c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc7980: ldur            x1, [fp, #-8]
    // 0xbc7984: ldur            x2, [fp, #-0x30]
    // 0xbc7988: ldur            d0, [fp, #-0x58]
    // 0xbc798c: ldur            x3, [fp, #-0x20]
    // 0xbc7990: r0 = computeAbsolutePaintOffset()
    //     0xbc7990: bl              #0xbc7e20  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::computeAbsolutePaintOffset
    // 0xbc7994: ldur            x1, [fp, #-0x18]
    // 0xbc7998: StoreField: r1->field_7 = r0
    //     0xbc7998: stur            w0, [x1, #7]
    //     0xbc799c: ldurb           w16, [x1, #-1]
    //     0xbc79a0: ldurb           w17, [x0, #-1]
    //     0xbc79a4: and             x16, x17, x16, lsr #2
    //     0xbc79a8: tst             x16, HEAP, lsr #32
    //     0xbc79ac: b.eq            #0xbc79b4
    //     0xbc79b0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc79b4: b               #0xbc7b08
    // 0xbc79b8: ldur            d1, [fp, #-0x68]
    // 0xbc79bc: mov             v0.16b, v3.16b
    // 0xbc79c0: ldur            x3, [fp, #-0x48]
    // 0xbc79c4: fneg            d2, d0
    // 0xbc79c8: fadd            d3, d2, d1
    // 0xbc79cc: stur            d3, [fp, #-0x78]
    // 0xbc79d0: r17 = 4838
    //     0xbc79d0: mov             x17, #0x12e6
    // 0xbc79d4: cmp             x3, x17
    // 0xbc79d8: b.ne            #0xbc7a80
    // 0xbc79dc: ldur            x4, [fp, #-0x30]
    // 0xbc79e0: LoadField: r5 = r4->field_7
    //     0xbc79e0: ldur            w5, [x4, #7]
    // 0xbc79e4: DecompressPointer r5
    //     0xbc79e4: add             x5, x5, HEAP, lsl #32
    // 0xbc79e8: stur            x5, [fp, #-0x18]
    // 0xbc79ec: cmp             w5, NULL
    // 0xbc79f0: b.eq            #0xbc7d5c
    // 0xbc79f4: mov             x0, x5
    // 0xbc79f8: r2 = Null
    //     0xbc79f8: mov             x2, NULL
    // 0xbc79fc: r1 = Null
    //     0xbc79fc: mov             x1, NULL
    // 0xbc7a00: r4 = LoadClassIdInstr(r0)
    //     0xbc7a00: ldur            x4, [x0, #-1]
    //     0xbc7a04: ubfx            x4, x4, #0xc, #0x14
    // 0xbc7a08: r17 = -4183
    //     0xbc7a08: mov             x17, #-0x1057
    // 0xbc7a0c: add             x4, x4, x17
    // 0xbc7a10: cmp             x4, #3
    // 0xbc7a14: b.ls            #0xbc7a2c
    // 0xbc7a18: r8 = SliverLogicalParentData
    //     0xbc7a18: add             x8, PP, #0x96, lsl #12  ; [pp+0x961c0] Type: SliverLogicalParentData
    //     0xbc7a1c: ldr             x8, [x8, #0x1c0]
    // 0xbc7a20: r3 = Null
    //     0xbc7a20: add             x3, PP, #0x96, lsl #12  ; [pp+0x96258] Null
    //     0xbc7a24: ldr             x3, [x3, #0x258]
    // 0xbc7a28: r0 = DefaultTypeTest()
    //     0xbc7a28: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc7a2c: ldur            d0, [fp, #-0x78]
    // 0xbc7a30: r0 = inline_Allocate_Double()
    //     0xbc7a30: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc7a34: add             x0, x0, #0x10
    //     0xbc7a38: cmp             x1, x0
    //     0xbc7a3c: b.ls            #0xbc7d60
    //     0xbc7a40: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc7a44: sub             x0, x0, #0xf
    //     0xbc7a48: mov             x1, #0xe19c
    //     0xbc7a4c: movk            x1, #3, lsl #16
    //     0xbc7a50: stur            x1, [x0, #-1]
    // 0xbc7a54: dmb             ishst
    // 0xbc7a58: StoreField: r0->field_7 = d0
    //     0xbc7a58: stur            d0, [x0, #7]
    // 0xbc7a5c: ldur            x1, [fp, #-0x18]
    // 0xbc7a60: StoreField: r1->field_7 = r0
    //     0xbc7a60: stur            w0, [x1, #7]
    //     0xbc7a64: ldurb           w16, [x1, #-1]
    //     0xbc7a68: ldurb           w17, [x0, #-1]
    //     0xbc7a6c: and             x16, x17, x16, lsr #2
    //     0xbc7a70: tst             x16, HEAP, lsr #32
    //     0xbc7a74: b.eq            #0xbc7a7c
    //     0xbc7a78: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc7a7c: b               #0xbc7b08
    // 0xbc7a80: ldur            x3, [fp, #-0x30]
    // 0xbc7a84: mov             v0.16b, v3.16b
    // 0xbc7a88: LoadField: r4 = r3->field_7
    //     0xbc7a88: ldur            w4, [x3, #7]
    // 0xbc7a8c: DecompressPointer r4
    //     0xbc7a8c: add             x4, x4, HEAP, lsl #32
    // 0xbc7a90: stur            x4, [fp, #-0x18]
    // 0xbc7a94: cmp             w4, NULL
    // 0xbc7a98: b.eq            #0xbc7d70
    // 0xbc7a9c: mov             x0, x4
    // 0xbc7aa0: r2 = Null
    //     0xbc7aa0: mov             x2, NULL
    // 0xbc7aa4: r1 = Null
    //     0xbc7aa4: mov             x1, NULL
    // 0xbc7aa8: r4 = LoadClassIdInstr(r0)
    //     0xbc7aa8: ldur            x4, [x0, #-1]
    //     0xbc7aac: ubfx            x4, x4, #0xc, #0x14
    // 0xbc7ab0: r17 = -4177
    //     0xbc7ab0: mov             x17, #-0x1051
    // 0xbc7ab4: add             x4, x4, x17
    // 0xbc7ab8: cmp             x4, #2
    // 0xbc7abc: b.ls            #0xbc7ad4
    // 0xbc7ac0: r8 = SliverPhysicalParentData
    //     0xbc7ac0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0xbc7ac4: ldr             x8, [x8, #0x240]
    // 0xbc7ac8: r3 = Null
    //     0xbc7ac8: add             x3, PP, #0x96, lsl #12  ; [pp+0x96268] Null
    //     0xbc7acc: ldr             x3, [x3, #0x268]
    // 0xbc7ad0: r0 = DefaultTypeTest()
    //     0xbc7ad0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbc7ad4: ldur            x1, [fp, #-8]
    // 0xbc7ad8: ldur            x2, [fp, #-0x30]
    // 0xbc7adc: ldur            d0, [fp, #-0x78]
    // 0xbc7ae0: ldur            x3, [fp, #-0x20]
    // 0xbc7ae4: r0 = computeAbsolutePaintOffset()
    //     0xbc7ae4: bl              #0xbc7e20  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::computeAbsolutePaintOffset
    // 0xbc7ae8: ldur            x1, [fp, #-0x18]
    // 0xbc7aec: StoreField: r1->field_7 = r0
    //     0xbc7aec: stur            w0, [x1, #7]
    //     0xbc7af0: ldurb           w16, [x1, #-1]
    //     0xbc7af4: ldurb           w17, [x0, #-1]
    //     0xbc7af8: and             x16, x17, x16, lsr #2
    //     0xbc7afc: tst             x16, HEAP, lsr #32
    //     0xbc7b00: b.eq            #0xbc7b08
    //     0xbc7b04: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc7b08: ldur            d3, [fp, #-0xa8]
    // 0xbc7b0c: ldur            d0, [fp, #-0xb8]
    // 0xbc7b10: ldur            d5, [fp, #-0xc0]
    // 0xbc7b14: ldur            d4, [fp, #-0xc8]
    // 0xbc7b18: ldur            d1, [fp, #-0x58]
    // 0xbc7b1c: ldur            x3, [fp, #-0x28]
    // 0xbc7b20: d2 = 0.000000
    //     0xbc7b20: eor             v2.16b, v2.16b, v2.16b
    // 0xbc7b24: ArrayLoad: d6 = r3[0]  ; List_8
    //     0xbc7b24: ldur            d6, [x3, #0x17]
    // 0xbc7b28: fadd            d7, d1, d6
    // 0xbc7b2c: fmax            v6.2d, v7.2d, v5.2d
    // 0xbc7b30: stur            d6, [fp, #-0xd0]
    // 0xbc7b34: LoadField: d1 = r3->field_7
    //     0xbc7b34: ldur            d1, [x3, #7]
    // 0xbc7b38: fsub            d7, d0, d1
    // 0xbc7b3c: stur            d7, [fp, #-0xc0]
    // 0xbc7b40: fadd            d5, d4, d1
    // 0xbc7b44: stur            d5, [fp, #-0x98]
    // 0xbc7b48: LoadField: d0 = r3->field_1f
    //     0xbc7b48: ldur            d0, [x3, #0x1f]
    // 0xbc7b4c: fadd            d9, d3, d0
    // 0xbc7b50: stur            d9, [fp, #-0x80]
    // 0xbc7b54: LoadField: d0 = r3->field_4b
    //     0xbc7b54: ldur            d0, [x3, #0x4b]
    // 0xbc7b58: fcmp            d0, d2
    // 0xbc7b5c: b.eq            #0xbc7b84
    // 0xbc7b60: ldur            d4, [fp, #-0xb0]
    // 0xbc7b64: ldur            d8, [fp, #-0x88]
    // 0xbc7b68: ldur            d3, [fp, #-0x90]
    // 0xbc7b6c: fsub            d10, d0, d8
    // 0xbc7b70: fsub            d8, d4, d10
    // 0xbc7b74: fadd            d4, d3, d0
    // 0xbc7b78: fmin            v0.2d, v4.2d, v2.2d
    // 0xbc7b7c: mov             v10.16b, v0.16b
    // 0xbc7b80: b               #0xbc7b90
    // 0xbc7b84: ldur            d4, [fp, #-0xb0]
    // 0xbc7b88: ldur            d10, [fp, #-0xa0]
    // 0xbc7b8c: mov             v8.16b, v4.16b
    // 0xbc7b90: ldur            x4, [fp, #-0x40]
    // 0xbc7b94: stur            d10, [fp, #-0x58]
    // 0xbc7b98: stur            d8, [fp, #-0x78]
    // 0xbc7b9c: r17 = 4838
    //     0xbc7b9c: mov             x17, #0x12e6
    // 0xbc7ba0: cmp             x4, x17
    // 0xbc7ba4: b.ne            #0xbc7c98
    // 0xbc7ba8: ldur            x5, [fp, #-8]
    // 0xbc7bac: LoadField: r0 = r5->field_83
    //     0xbc7bac: ldur            w0, [x5, #0x83]
    // 0xbc7bb0: DecompressPointer r0
    //     0xbc7bb0: add             x0, x0, HEAP, lsl #32
    // 0xbc7bb4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc7bb8: cmp             w0, w16
    // 0xbc7bbc: b.eq            #0xbc7d74
    // 0xbc7bc0: LoadField: d0 = r0->field_7
    //     0xbc7bc0: ldur            d0, [x0, #7]
    // 0xbc7bc4: fadd            d3, d0, d1
    // 0xbc7bc8: r0 = inline_Allocate_Double()
    //     0xbc7bc8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc7bcc: add             x0, x0, #0x10
    //     0xbc7bd0: cmp             x1, x0
    //     0xbc7bd4: b.ls            #0xbc7d80
    //     0xbc7bd8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc7bdc: sub             x0, x0, #0xf
    //     0xbc7be0: mov             x1, #0xe19c
    //     0xbc7be4: movk            x1, #3, lsl #16
    //     0xbc7be8: stur            x1, [x0, #-1]
    // 0xbc7bec: dmb             ishst
    // 0xbc7bf0: StoreField: r0->field_7 = d3
    //     0xbc7bf0: stur            d3, [x0, #7]
    // 0xbc7bf4: StoreField: r5->field_83 = r0
    //     0xbc7bf4: stur            w0, [x5, #0x83]
    //     0xbc7bf8: ldurb           w16, [x5, #-1]
    //     0xbc7bfc: ldurb           w17, [x0, #-1]
    //     0xbc7c00: and             x16, x17, x16, lsr #2
    //     0xbc7c04: tst             x16, HEAP, lsr #32
    //     0xbc7c08: b.eq            #0xbc7c10
    //     0xbc7c0c: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbc7c10: LoadField: r0 = r3->field_43
    //     0xbc7c10: ldur            w0, [x3, #0x43]
    // 0xbc7c14: DecompressPointer r0
    //     0xbc7c14: add             x0, x0, HEAP, lsl #32
    // 0xbc7c18: tbnz            w0, #4, #0xbc7c28
    // 0xbc7c1c: r6 = true
    //     0xbc7c1c: add             x6, NULL, #0x20  ; true
    // 0xbc7c20: StoreField: r5->field_8b = r6
    //     0xbc7c20: stur            w6, [x5, #0x8b]
    // 0xbc7c24: b               #0xbc7c2c
    // 0xbc7c28: r6 = true
    //     0xbc7c28: add             x6, NULL, #0x20  ; true
    // 0xbc7c2c: LoadField: r0 = r5->field_87
    //     0xbc7c2c: ldur            w0, [x5, #0x87]
    // 0xbc7c30: DecompressPointer r0
    //     0xbc7c30: add             x0, x0, HEAP, lsl #32
    // 0xbc7c34: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc7c38: cmp             w0, w16
    // 0xbc7c3c: b.eq            #0xbc7db8
    // 0xbc7c40: LoadField: d0 = r3->field_27
    //     0xbc7c40: ldur            d0, [x3, #0x27]
    // 0xbc7c44: LoadField: d1 = r0->field_7
    //     0xbc7c44: ldur            d1, [x0, #7]
    // 0xbc7c48: fadd            d3, d1, d0
    // 0xbc7c4c: r0 = inline_Allocate_Double()
    //     0xbc7c4c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc7c50: add             x0, x0, #0x10
    //     0xbc7c54: cmp             x1, x0
    //     0xbc7c58: b.ls            #0xbc7dc4
    //     0xbc7c5c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc7c60: sub             x0, x0, #0xf
    //     0xbc7c64: mov             x1, #0xe19c
    //     0xbc7c68: movk            x1, #3, lsl #16
    //     0xbc7c6c: stur            x1, [x0, #-1]
    // 0xbc7c70: dmb             ishst
    // 0xbc7c74: StoreField: r0->field_7 = d3
    //     0xbc7c74: stur            d3, [x0, #7]
    // 0xbc7c78: StoreField: r5->field_87 = r0
    //     0xbc7c78: stur            w0, [x5, #0x87]
    //     0xbc7c7c: ldurb           w16, [x5, #-1]
    //     0xbc7c80: ldurb           w17, [x0, #-1]
    //     0xbc7c84: and             x16, x17, x16, lsr #2
    //     0xbc7c88: tst             x16, HEAP, lsr #32
    //     0xbc7c8c: b.eq            #0xbc7c94
    //     0xbc7c90: bl              #0x13de014  ; WriteBarrierWrappersStub
    // 0xbc7c94: b               #0xbc7cbc
    // 0xbc7c98: ldur            x5, [fp, #-8]
    // 0xbc7c9c: r6 = true
    //     0xbc7c9c: add             x6, NULL, #0x20  ; true
    // 0xbc7ca0: r0 = LoadClassIdInstr(r5)
    //     0xbc7ca0: ldur            x0, [x5, #-1]
    //     0xbc7ca4: ubfx            x0, x0, #0xc, #0x14
    // 0xbc7ca8: mov             x1, x5
    // 0xbc7cac: ldur            x2, [fp, #-0x20]
    // 0xbc7cb0: r0 = GDT[cid_x0 + 0xebf]()
    //     0xbc7cb0: add             lr, x0, #0xebf
    //     0xbc7cb4: ldr             lr, [x21, lr, lsl #3]
    //     0xbc7cb8: blr             lr
    // 0xbc7cbc: ldur            x16, [fp, #-0x10]
    // 0xbc7cc0: ldur            lr, [fp, #-0x30]
    // 0xbc7cc4: stp             lr, x16, [SP]
    // 0xbc7cc8: ldur            x0, [fp, #-0x10]
    // 0xbc7ccc: ClosureCall
    //     0xbc7ccc: ldr             x4, [PP, #0x148]  ; [pp+0x148] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xbc7cd0: ldur            x2, [x0, #0x1f]
    //     0xbc7cd4: blr             x2
    // 0xbc7cd8: ldur            d10, [fp, #-0x58]
    // 0xbc7cdc: mov             x6, x0
    // 0xbc7ce0: ldur            d9, [fp, #-0x80]
    // 0xbc7ce4: ldur            d8, [fp, #-0x78]
    // 0xbc7ce8: ldur            d7, [fp, #-0xc0]
    // 0xbc7cec: ldur            d6, [fp, #-0xd0]
    // 0xbc7cf0: ldur            d5, [fp, #-0x98]
    // 0xbc7cf4: ldur            x1, [fp, #-8]
    // 0xbc7cf8: ldur            d1, [fp, #-0x68]
    // 0xbc7cfc: ldur            x0, [fp, #-0x50]
    // 0xbc7d00: ldur            x3, [fp, #-0x40]
    // 0xbc7d04: ldur            x2, [fp, #-0x48]
    // 0xbc7d08: ldur            x4, [fp, #-0x38]
    // 0xbc7d0c: b               #0xbc76f8
    // 0xbc7d10: LoadField: d0 = r0->field_7
    //     0xbc7d10: ldur            d0, [x0, #7]
    // 0xbc7d14: LeaveFrame
    //     0xbc7d14: mov             SP, fp
    //     0xbc7d18: ldp             fp, lr, [SP], #0x10
    // 0xbc7d1c: ret
    //     0xbc7d1c: ret             
    // 0xbc7d20: d0 = 0.000000
    //     0xbc7d20: eor             v0.16b, v0.16b, v0.16b
    // 0xbc7d24: LeaveFrame
    //     0xbc7d24: mov             SP, fp
    //     0xbc7d28: ldp             fp, lr, [SP], #0x10
    // 0xbc7d2c: ret
    //     0xbc7d2c: ret             
    // 0xbc7d30: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc7d30: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc7d34: b               #0xbc7684
    // 0xbc7d38: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc7d38: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc7d3c: b               #0xbc7734
    // 0xbc7d40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc7d40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbc7d44: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7d44: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc7d48: SaveReg d0
    //     0xbc7d48: str             q0, [SP, #-0x10]!
    // 0xbc7d4c: r0 = AllocateDouble()
    //     0xbc7d4c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc7d50: RestoreReg d0
    //     0xbc7d50: ldr             q0, [SP], #0x10
    // 0xbc7d54: b               #0xbc7908
    // 0xbc7d58: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7d58: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc7d5c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7d5c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc7d60: SaveReg d0
    //     0xbc7d60: str             q0, [SP, #-0x10]!
    // 0xbc7d64: r0 = AllocateDouble()
    //     0xbc7d64: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc7d68: RestoreReg d0
    //     0xbc7d68: ldr             q0, [SP], #0x10
    // 0xbc7d6c: b               #0xbc7a58
    // 0xbc7d70: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7d70: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc7d74: r9 = _maxScrollExtent
    //     0xbc7d74: add             x9, PP, #0x96, lsl #12  ; [pp+0x961f8] Field <RenderShrinkWrappingViewport._maxScrollExtent@616057554>: late (offset: 0x84)
    //     0xbc7d78: ldr             x9, [x9, #0x1f8]
    // 0xbc7d7c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbc7d7c: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbc7d80: stp             q9, q10, [SP, #-0x20]!
    // 0xbc7d84: stp             q7, q8, [SP, #-0x20]!
    // 0xbc7d88: stp             q5, q6, [SP, #-0x20]!
    // 0xbc7d8c: stp             q2, q3, [SP, #-0x20]!
    // 0xbc7d90: stp             x4, x5, [SP, #-0x10]!
    // 0xbc7d94: SaveReg r3
    //     0xbc7d94: str             x3, [SP, #-8]!
    // 0xbc7d98: r0 = AllocateDouble()
    //     0xbc7d98: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc7d9c: RestoreReg r3
    //     0xbc7d9c: ldr             x3, [SP], #8
    // 0xbc7da0: ldp             x4, x5, [SP], #0x10
    // 0xbc7da4: ldp             q2, q3, [SP], #0x20
    // 0xbc7da8: ldp             q5, q6, [SP], #0x20
    // 0xbc7dac: ldp             q7, q8, [SP], #0x20
    // 0xbc7db0: ldp             q9, q10, [SP], #0x20
    // 0xbc7db4: b               #0xbc7bf0
    // 0xbc7db8: r9 = _shrinkWrapExtent
    //     0xbc7db8: add             x9, PP, #0x96, lsl #12  ; [pp+0x961f0] Field <RenderShrinkWrappingViewport._shrinkWrapExtent@616057554>: late (offset: 0x88)
    //     0xbc7dbc: ldr             x9, [x9, #0x1f0]
    // 0xbc7dc0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbc7dc0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbc7dc4: stp             q9, q10, [SP, #-0x20]!
    // 0xbc7dc8: stp             q7, q8, [SP, #-0x20]!
    // 0xbc7dcc: stp             q5, q6, [SP, #-0x20]!
    // 0xbc7dd0: stp             q2, q3, [SP, #-0x20]!
    // 0xbc7dd4: stp             x5, x6, [SP, #-0x10]!
    // 0xbc7dd8: SaveReg r4
    //     0xbc7dd8: str             x4, [SP, #-8]!
    // 0xbc7ddc: r0 = AllocateDouble()
    //     0xbc7ddc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc7de0: RestoreReg r4
    //     0xbc7de0: ldr             x4, [SP], #8
    // 0xbc7de4: ldp             x5, x6, [SP], #0x10
    // 0xbc7de8: ldp             q2, q3, [SP], #0x20
    // 0xbc7dec: ldp             q5, q6, [SP], #0x20
    // 0xbc7df0: ldp             q7, q8, [SP], #0x20
    // 0xbc7df4: ldp             q9, q10, [SP], #0x20
    // 0xbc7df8: b               #0xbc7c74
  }
  _ computeAbsolutePaintOffset(/* No info */) {
    // ** addr: 0xbc7e20, size: 0x13c
    // 0xbc7e20: EnterFrame
    //     0xbc7e20: stp             fp, lr, [SP, #-0x10]!
    //     0xbc7e24: mov             fp, SP
    // 0xbc7e28: AllocStack(0x20)
    //     0xbc7e28: sub             SP, SP, #0x20
    // 0xbc7e2c: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r2 */, dynamic _ /* d0 => d0, fp-0x18 */)
    //     0xbc7e2c: mov             x0, x2
    //     0xbc7e30: stur            x2, [fp, #-0x10]
    //     0xbc7e34: mov             x2, x3
    //     0xbc7e38: mov             x3, x1
    //     0xbc7e3c: stur            x1, [fp, #-8]
    //     0xbc7e40: stur            d0, [fp, #-0x18]
    // 0xbc7e44: CheckStackOverflow
    //     0xbc7e44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc7e48: cmp             SP, x16
    //     0xbc7e4c: b.ls            #0xbc7f4c
    // 0xbc7e50: LoadField: r1 = r3->field_63
    //     0xbc7e50: ldur            w1, [x3, #0x63]
    // 0xbc7e54: DecompressPointer r1
    //     0xbc7e54: add             x1, x1, HEAP, lsl #32
    // 0xbc7e58: r0 = applyGrowthDirectionToAxisDirection()
    //     0xbc7e58: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0xbc7e5c: LoadField: r1 = r0->field_7
    //     0xbc7e5c: ldur            x1, [x0, #7]
    // 0xbc7e60: cmp             x1, #1
    // 0xbc7e64: b.gt            #0xbc7ed8
    // 0xbc7e68: cmp             x1, #0
    // 0xbc7e6c: b.gt            #0xbc7ec0
    // 0xbc7e70: ldur            x0, [fp, #-0x10]
    // 0xbc7e74: ldur            d0, [fp, #-0x18]
    // 0xbc7e78: ldur            x1, [fp, #-8]
    // 0xbc7e7c: r0 = size()
    //     0xbc7e7c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc7e80: LoadField: d0 = r0->field_f
    //     0xbc7e80: ldur            d0, [x0, #0xf]
    // 0xbc7e84: ldur            d1, [fp, #-0x18]
    // 0xbc7e88: fsub            d2, d0, d1
    // 0xbc7e8c: ldur            x0, [fp, #-0x10]
    // 0xbc7e90: LoadField: r1 = r0->field_47
    //     0xbc7e90: ldur            w1, [x0, #0x47]
    // 0xbc7e94: DecompressPointer r1
    //     0xbc7e94: add             x1, x1, HEAP, lsl #32
    // 0xbc7e98: cmp             w1, NULL
    // 0xbc7e9c: b.eq            #0xbc7f54
    // 0xbc7ea0: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xbc7ea0: ldur            d0, [x1, #0x17]
    // 0xbc7ea4: fsub            d1, d2, d0
    // 0xbc7ea8: stur            d1, [fp, #-0x20]
    // 0xbc7eac: r0 = Offset()
    //     0xbc7eac: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc7eb0: StoreField: r0->field_7 = rZR
    //     0xbc7eb0: stur            xzr, [x0, #7]
    // 0xbc7eb4: ldur            d0, [fp, #-0x20]
    // 0xbc7eb8: StoreField: r0->field_f = d0
    //     0xbc7eb8: stur            d0, [x0, #0xf]
    // 0xbc7ebc: b               #0xbc7f40
    // 0xbc7ec0: ldur            d1, [fp, #-0x18]
    // 0xbc7ec4: r0 = Offset()
    //     0xbc7ec4: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc7ec8: ldur            d0, [fp, #-0x18]
    // 0xbc7ecc: StoreField: r0->field_7 = d0
    //     0xbc7ecc: stur            d0, [x0, #7]
    // 0xbc7ed0: StoreField: r0->field_f = rZR
    //     0xbc7ed0: stur            xzr, [x0, #0xf]
    // 0xbc7ed4: b               #0xbc7f40
    // 0xbc7ed8: ldur            x0, [fp, #-0x10]
    // 0xbc7edc: ldur            d0, [fp, #-0x18]
    // 0xbc7ee0: cmp             x1, #2
    // 0xbc7ee4: b.gt            #0xbc7efc
    // 0xbc7ee8: r0 = Offset()
    //     0xbc7ee8: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc7eec: StoreField: r0->field_7 = rZR
    //     0xbc7eec: stur            xzr, [x0, #7]
    // 0xbc7ef0: ldur            d0, [fp, #-0x18]
    // 0xbc7ef4: StoreField: r0->field_f = d0
    //     0xbc7ef4: stur            d0, [x0, #0xf]
    // 0xbc7ef8: b               #0xbc7f40
    // 0xbc7efc: ldur            x1, [fp, #-8]
    // 0xbc7f00: r0 = size()
    //     0xbc7f00: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc7f04: LoadField: d0 = r0->field_7
    //     0xbc7f04: ldur            d0, [x0, #7]
    // 0xbc7f08: ldur            d1, [fp, #-0x18]
    // 0xbc7f0c: fsub            d2, d0, d1
    // 0xbc7f10: ldur            x0, [fp, #-0x10]
    // 0xbc7f14: LoadField: r1 = r0->field_47
    //     0xbc7f14: ldur            w1, [x0, #0x47]
    // 0xbc7f18: DecompressPointer r1
    //     0xbc7f18: add             x1, x1, HEAP, lsl #32
    // 0xbc7f1c: cmp             w1, NULL
    // 0xbc7f20: b.eq            #0xbc7f58
    // 0xbc7f24: ArrayLoad: d0 = r1[0]  ; List_8
    //     0xbc7f24: ldur            d0, [x1, #0x17]
    // 0xbc7f28: fsub            d1, d2, d0
    // 0xbc7f2c: stur            d1, [fp, #-0x18]
    // 0xbc7f30: r0 = Offset()
    //     0xbc7f30: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbc7f34: ldur            d0, [fp, #-0x18]
    // 0xbc7f38: StoreField: r0->field_7 = d0
    //     0xbc7f38: stur            d0, [x0, #7]
    // 0xbc7f3c: StoreField: r0->field_f = rZR
    //     0xbc7f3c: stur            xzr, [x0, #0xf]
    // 0xbc7f40: LeaveFrame
    //     0xbc7f40: mov             SP, fp
    //     0xbc7f44: ldp             fp, lr, [SP], #0x10
    // 0xbc7f48: ret
    //     0xbc7f48: ret             
    // 0xbc7f4c: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc7f4c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc7f50: b               #0xbc7e50
    // 0xbc7f54: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7f54: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc7f58: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7f58: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ axis(/* No info */) {
    // ** addr: 0xbc8210, size: 0x50
    // 0xbc8210: LoadField: r2 = r1->field_63
    //     0xbc8210: ldur            w2, [x1, #0x63]
    // 0xbc8214: DecompressPointer r2
    //     0xbc8214: add             x2, x2, HEAP, lsl #32
    // 0xbc8218: r16 = Instance_AxisDirection
    //     0xbc8218: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xbc821c: cmp             w2, w16
    // 0xbc8220: b.eq            #0xbc8230
    // 0xbc8224: r16 = Instance_AxisDirection
    //     0xbc8224: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xbc8228: cmp             w2, w16
    // 0xbc822c: b.ne            #0xbc8238
    // 0xbc8230: r0 = Instance_Axis
    //     0xbc8230: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbc8234: b               #0xbc825c
    // 0xbc8238: r16 = Instance_AxisDirection
    //     0xbc8238: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xbc823c: cmp             w2, w16
    // 0xbc8240: b.eq            #0xbc8250
    // 0xbc8244: r16 = Instance_AxisDirection
    //     0xbc8244: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xbc8248: cmp             w2, w16
    // 0xbc824c: b.ne            #0xbc8258
    // 0xbc8250: r0 = Instance_Axis
    //     0xbc8250: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xbc8254: b               #0xbc825c
    // 0xbc8258: r0 = Null
    //     0xbc8258: mov             x0, NULL
    // 0xbc825c: ret
    //     0xbc825c: ret             
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0xbec108, size: 0x64
    // 0xbec108: EnterFrame
    //     0xbec108: stp             fp, lr, [SP, #-0x10]!
    //     0xbec10c: mov             fp, SP
    // 0xbec110: AllocStack(0x10)
    //     0xbec110: sub             SP, SP, #0x10
    // 0xbec114: SetupParameters(dynamic _ /* r2 => r2, fp-0x8 */)
    //     0xbec114: stur            x2, [fp, #-8]
    // 0xbec118: CheckStackOverflow
    //     0xbec118: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec11c: cmp             SP, x16
    //     0xbec120: b.ls            #0xbec164
    // 0xbec124: r0 = _childrenLastToFirst()
    //     0xbec124: bl              #0xbec198  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::_childrenLastToFirst
    // 0xbec128: r1 = Function '<anonymous closure>':.
    //     0xbec128: add             x1, PP, #0x96, lsl #12  ; [pp+0x964d0] AnonymousClosure: (0xbec314), in [package:flutter/src/rendering/viewport.dart] RenderViewportBase::visitChildrenForSemantics (0xbec108)
    //     0xbec12c: ldr             x1, [x1, #0x4d0]
    // 0xbec130: r2 = Null
    //     0xbec130: mov             x2, NULL
    // 0xbec134: stur            x0, [fp, #-0x10]
    // 0xbec138: r0 = AllocateClosure()
    //     0xbec138: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbec13c: ldur            x1, [fp, #-0x10]
    // 0xbec140: mov             x2, x0
    // 0xbec144: r0 = where()
    //     0xbec144: bl              #0xb92e4c  ; [dart:_compact_hash] __Set&_HashVMBase&SetMixin::where
    // 0xbec148: mov             x1, x0
    // 0xbec14c: ldur            x2, [fp, #-8]
    // 0xbec150: r0 = forEach()
    //     0xbec150: bl              #0xaffee4  ; [dart:core] Iterable::forEach
    // 0xbec154: r0 = Null
    //     0xbec154: mov             x0, NULL
    // 0xbec158: LeaveFrame
    //     0xbec158: mov             SP, fp
    //     0xbec15c: ldp             fp, lr, [SP], #0x10
    // 0xbec160: ret
    //     0xbec160: ret             
    // 0xbec164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec164: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec168: b               #0xbec124
  }
  get _ childrenInPaintOrder(/* No info */) {
    // ** addr: 0xbec16c, size: 0x2c
    // 0xbec16c: EnterFrame
    //     0xbec16c: stp             fp, lr, [SP, #-0x10]!
    //     0xbec170: mov             fp, SP
    // 0xbec174: CheckStackOverflow
    //     0xbec174: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec178: cmp             SP, x16
    //     0xbec17c: b.ls            #0xbec190
    // 0xbec180: r0 = _childrenLastToFirst()
    //     0xbec180: bl              #0xbec198  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::_childrenLastToFirst
    // 0xbec184: LeaveFrame
    //     0xbec184: mov             SP, fp
    //     0xbec188: ldp             fp, lr, [SP], #0x10
    // 0xbec18c: ret
    //     0xbec18c: ret             
    // 0xbec190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec190: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec194: b               #0xbec180
  }
  get _ _childrenLastToFirst(/* No info */) {
    // ** addr: 0xbec198, size: 0x17c
    // 0xbec198: EnterFrame
    //     0xbec198: stp             fp, lr, [SP, #-0x10]!
    //     0xbec19c: mov             fp, SP
    // 0xbec1a0: AllocStack(0x28)
    //     0xbec1a0: sub             SP, SP, #0x28
    // 0xbec1a4: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r0, fp-0x8 */)
    //     0xbec1a4: mov             x0, x1
    //     0xbec1a8: stur            x1, [fp, #-8]
    // 0xbec1ac: CheckStackOverflow
    //     0xbec1ac: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec1b0: cmp             SP, x16
    //     0xbec1b4: b.ls            #0xbec300
    // 0xbec1b8: r1 = <RenderSliver>
    //     0xbec1b8: add             x1, PP, #0x96, lsl #12  ; [pp+0x96450] TypeArguments: <RenderSliver>
    //     0xbec1bc: ldr             x1, [x1, #0x450]
    // 0xbec1c0: r2 = 0
    //     0xbec1c0: mov             x2, #0
    // 0xbec1c4: r0 = _GrowableList()
    //     0xbec1c4: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0xbec1c8: mov             x2, x0
    // 0xbec1cc: ldur            x0, [fp, #-8]
    // 0xbec1d0: stur            x2, [fp, #-0x20]
    // 0xbec1d4: LoadField: r1 = r0->field_5f
    //     0xbec1d4: ldur            w1, [x0, #0x5f]
    // 0xbec1d8: DecompressPointer r1
    //     0xbec1d8: add             x1, x1, HEAP, lsl #32
    // 0xbec1dc: LoadField: r3 = r0->field_4f
    //     0xbec1dc: ldur            w3, [x0, #0x4f]
    // 0xbec1e0: DecompressPointer r3
    //     0xbec1e0: add             x3, x3, HEAP, lsl #32
    // 0xbec1e4: stur            x3, [fp, #-0x18]
    // 0xbec1e8: mov             x0, x1
    // 0xbec1ec: stur            x0, [fp, #-8]
    // 0xbec1f0: CheckStackOverflow
    //     0xbec1f0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbec1f4: cmp             SP, x16
    //     0xbec1f8: b.ls            #0xbec308
    // 0xbec1fc: cmp             w0, NULL
    // 0xbec200: b.eq            #0xbec2f0
    // 0xbec204: LoadField: r1 = r2->field_b
    //     0xbec204: ldur            w1, [x2, #0xb]
    // 0xbec208: LoadField: r4 = r2->field_f
    //     0xbec208: ldur            w4, [x2, #0xf]
    // 0xbec20c: DecompressPointer r4
    //     0xbec20c: add             x4, x4, HEAP, lsl #32
    // 0xbec210: LoadField: r5 = r4->field_b
    //     0xbec210: ldur            w5, [x4, #0xb]
    // 0xbec214: r4 = LoadInt32Instr(r1)
    //     0xbec214: sbfx            x4, x1, #1, #0x1f
    // 0xbec218: stur            x4, [fp, #-0x10]
    // 0xbec21c: r1 = LoadInt32Instr(r5)
    //     0xbec21c: sbfx            x1, x5, #1, #0x1f
    // 0xbec220: cmp             x4, x1
    // 0xbec224: b.ne            #0xbec230
    // 0xbec228: mov             x1, x2
    // 0xbec22c: r0 = _growToNextCapacity()
    //     0xbec22c: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xbec230: ldur            x3, [fp, #-0x20]
    // 0xbec234: ldur            x2, [fp, #-8]
    // 0xbec238: ldur            x4, [fp, #-0x10]
    // 0xbec23c: add             x0, x4, #1
    // 0xbec240: lsl             x1, x0, #1
    // 0xbec244: StoreField: r3->field_b = r1
    //     0xbec244: stur            w1, [x3, #0xb]
    // 0xbec248: LoadField: r1 = r3->field_f
    //     0xbec248: ldur            w1, [x3, #0xf]
    // 0xbec24c: DecompressPointer r1
    //     0xbec24c: add             x1, x1, HEAP, lsl #32
    // 0xbec250: mov             x0, x2
    // 0xbec254: ArrayStore: r1[r4] = r0  ; List_4
    //     0xbec254: add             x25, x1, x4, lsl #2
    //     0xbec258: add             x25, x25, #0xf
    //     0xbec25c: str             w0, [x25]
    //     0xbec260: tbz             w0, #0, #0xbec27c
    //     0xbec264: ldurb           w16, [x1, #-1]
    //     0xbec268: ldurb           w17, [x0, #-1]
    //     0xbec26c: and             x16, x17, x16, lsr #2
    //     0xbec270: tst             x16, HEAP, lsr #32
    //     0xbec274: b.eq            #0xbec27c
    //     0xbec278: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0xbec27c: LoadField: r4 = r2->field_7
    //     0xbec27c: ldur            w4, [x2, #7]
    // 0xbec280: DecompressPointer r4
    //     0xbec280: add             x4, x4, HEAP, lsl #32
    // 0xbec284: stur            x4, [fp, #-0x28]
    // 0xbec288: cmp             w4, NULL
    // 0xbec28c: b.eq            #0xbec310
    // 0xbec290: mov             x0, x4
    // 0xbec294: ldur            x2, [fp, #-0x18]
    // 0xbec298: r1 = Null
    //     0xbec298: mov             x1, NULL
    // 0xbec29c: cmp             w2, NULL
    // 0xbec2a0: b.eq            #0xbec2c4
    // 0xbec2a4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbec2a4: ldur            w4, [x2, #0x17]
    // 0xbec2a8: DecompressPointer r4
    //     0xbec2a8: add             x4, x4, HEAP, lsl #32
    // 0xbec2ac: r8 = X0 bound ContainerParentDataMixin
    //     0xbec2ac: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0xbec2b0: ldr             x8, [x8, #0x218]
    // 0xbec2b4: LoadField: r9 = r4->field_7
    //     0xbec2b4: ldur            x9, [x4, #7]
    // 0xbec2b8: r3 = Null
    //     0xbec2b8: add             x3, PP, #0x96, lsl #12  ; [pp+0x96490] Null
    //     0xbec2bc: ldr             x3, [x3, #0x490]
    // 0xbec2c0: blr             x9
    // 0xbec2c4: ldur            x1, [fp, #-0x28]
    // 0xbec2c8: r0 = LoadClassIdInstr(r1)
    //     0xbec2c8: ldur            x0, [x1, #-1]
    //     0xbec2cc: ubfx            x0, x0, #0xc, #0x14
    // 0xbec2d0: r0 = GDT[cid_x0 + 0x11a98]()
    //     0xbec2d0: mov             x17, #0x1a98
    //     0xbec2d4: movk            x17, #1, lsl #16
    //     0xbec2d8: add             lr, x0, x17
    //     0xbec2dc: ldr             lr, [x21, lr, lsl #3]
    //     0xbec2e0: blr             lr
    // 0xbec2e4: ldur            x2, [fp, #-0x20]
    // 0xbec2e8: ldur            x3, [fp, #-0x18]
    // 0xbec2ec: b               #0xbec1ec
    // 0xbec2f0: ldur            x0, [fp, #-0x20]
    // 0xbec2f4: LeaveFrame
    //     0xbec2f4: mov             SP, fp
    //     0xbec2f8: ldp             fp, lr, [SP], #0x10
    // 0xbec2fc: ret
    //     0xbec2fc: ret             
    // 0xbec300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec300: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec304: b               #0xbec1b8
    // 0xbec308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec308: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec30c: b               #0xbec1fc
    // 0xbec310: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbec310: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, RenderSliver) {
    // ** addr: 0xbec314, size: 0x4c
    // 0xbec314: ldr             x1, [SP]
    // 0xbec318: LoadField: r2 = r1->field_47
    //     0xbec318: ldur            w2, [x1, #0x47]
    // 0xbec31c: DecompressPointer r2
    //     0xbec31c: add             x2, x2, HEAP, lsl #32
    // 0xbec320: cmp             w2, NULL
    // 0xbec324: b.eq            #0xbec354
    // 0xbec328: LoadField: r1 = r2->field_3f
    //     0xbec328: ldur            w1, [x2, #0x3f]
    // 0xbec32c: DecompressPointer r1
    //     0xbec32c: add             x1, x1, HEAP, lsl #32
    // 0xbec330: tbz             w1, #4, #0xbec344
    // 0xbec334: d0 = 0.000000
    //     0xbec334: eor             v0.16b, v0.16b, v0.16b
    // 0xbec338: LoadField: d1 = r2->field_4b
    //     0xbec338: ldur            d1, [x2, #0x4b]
    // 0xbec33c: fcmp            d1, d0
    // 0xbec340: b.le            #0xbec34c
    // 0xbec344: r0 = true
    //     0xbec344: add             x0, NULL, #0x20  ; true
    // 0xbec348: b               #0xbec350
    // 0xbec34c: r0 = false
    //     0xbec34c: add             x0, NULL, #0x30  ; false
    // 0xbec350: ret
    //     0xbec350: ret             
    // 0xbec354: EnterFrame
    //     0xbec354: stp             fp, lr, [SP, #-0x10]!
    //     0xbec358: mov             fp, SP
    // 0xbec35c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbec35c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic showOnScreen(dynamic) {
    // ** addr: 0xbed650, size: 0x24
    // 0xbed650: EnterFrame
    //     0xbed650: stp             fp, lr, [SP, #-0x10]!
    //     0xbed654: mov             fp, SP
    // 0xbed658: ldr             x2, [fp, #0x10]
    // 0xbed65c: r1 = Function 'showOnScreen':.
    //     0xbed65c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96398] AnonymousClosure: (0xbed674), in [package:flutter/src/rendering/viewport.dart] RenderViewportBase::showOnScreen (0xbedde4)
    //     0xbed660: ldr             x1, [x1, #0x398]
    // 0xbed664: r0 = AllocateClosure()
    //     0xbed664: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbed668: LeaveFrame
    //     0xbed668: mov             SP, fp
    //     0xbed66c: ldp             fp, lr, [SP], #0x10
    // 0xbed670: ret
    //     0xbed670: ret             
  }
  [closure] void showOnScreen(dynamic, {RenderObject? descendant, Rect? rect, Duration duration, Curve curve}) {
    // ** addr: 0xbed674, size: 0x188
    // 0xbed674: EnterFrame
    //     0xbed674: stp             fp, lr, [SP, #-0x10]!
    //     0xbed678: mov             fp, SP
    // 0xbed67c: AllocStack(0x20)
    //     0xbed67c: sub             SP, SP, #0x20
    // 0xbed680: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r2 */, {dynamic curve = Instance_Cubic /* r3 */, dynamic descendant = Null /* r5 */, dynamic duration = Instance_Duration /* r6 */, dynamic rect = Null /* r0 */})
    //     0xbed680: ldur            w0, [x4, #0x13]
    //     0xbed684: sub             x1, x0, #2
    //     0xbed688: add             x2, fp, w1, sxtw #2
    //     0xbed68c: ldr             x2, [x2, #0x10]
    //     0xbed690: ldur            w1, [x4, #0x1f]
    //     0xbed694: add             x1, x1, HEAP, lsl #32
    //     0xbed698: ldr             x16, [PP, #0x5160]  ; [pp+0x5160] "curve"
    //     0xbed69c: cmp             w1, w16
    //     0xbed6a0: b.ne            #0xbed6c4
    //     0xbed6a4: ldur            w1, [x4, #0x23]
    //     0xbed6a8: add             x1, x1, HEAP, lsl #32
    //     0xbed6ac: sub             w3, w0, w1
    //     0xbed6b0: add             x1, fp, w3, sxtw #2
    //     0xbed6b4: ldr             x1, [x1, #8]
    //     0xbed6b8: mov             x3, x1
    //     0xbed6bc: mov             x1, #1
    //     0xbed6c0: b               #0xbed6cc
    //     0xbed6c4: ldr             x3, [PP, #0x53e8]  ; [pp+0x53e8] Obj!Cubic@129f421
    //     0xbed6c8: mov             x1, #0
    //     0xbed6cc: lsl             x5, x1, #1
    //     0xbed6d0: lsl             w6, w5, #1
    //     0xbed6d4: add             w7, w6, #8
    //     0xbed6d8: add             x16, x4, w7, sxtw #1
    //     0xbed6dc: ldur            w8, [x16, #0xf]
    //     0xbed6e0: add             x8, x8, HEAP, lsl #32
    //     0xbed6e4: ldr             x16, [PP, #0x53f0]  ; [pp+0x53f0] "descendant"
    //     0xbed6e8: cmp             w8, w16
    //     0xbed6ec: b.ne            #0xbed720
    //     0xbed6f0: add             w1, w6, #0xa
    //     0xbed6f4: add             x16, x4, w1, sxtw #1
    //     0xbed6f8: ldur            w6, [x16, #0xf]
    //     0xbed6fc: add             x6, x6, HEAP, lsl #32
    //     0xbed700: sub             w1, w0, w6
    //     0xbed704: add             x6, fp, w1, sxtw #2
    //     0xbed708: ldr             x6, [x6, #8]
    //     0xbed70c: add             w1, w5, #2
    //     0xbed710: sbfx            x5, x1, #1, #0x1f
    //     0xbed714: mov             x1, x5
    //     0xbed718: mov             x5, x6
    //     0xbed71c: b               #0xbed724
    //     0xbed720: mov             x5, NULL
    //     0xbed724: lsl             x6, x1, #1
    //     0xbed728: lsl             w7, w6, #1
    //     0xbed72c: add             w8, w7, #8
    //     0xbed730: add             x16, x4, w8, sxtw #1
    //     0xbed734: ldur            w9, [x16, #0xf]
    //     0xbed738: add             x9, x9, HEAP, lsl #32
    //     0xbed73c: ldr             x16, [PP, #0x5170]  ; [pp+0x5170] "duration"
    //     0xbed740: cmp             w9, w16
    //     0xbed744: b.ne            #0xbed778
    //     0xbed748: add             w1, w7, #0xa
    //     0xbed74c: add             x16, x4, w1, sxtw #1
    //     0xbed750: ldur            w7, [x16, #0xf]
    //     0xbed754: add             x7, x7, HEAP, lsl #32
    //     0xbed758: sub             w1, w0, w7
    //     0xbed75c: add             x7, fp, w1, sxtw #2
    //     0xbed760: ldr             x7, [x7, #8]
    //     0xbed764: add             w1, w6, #2
    //     0xbed768: sbfx            x6, x1, #1, #0x1f
    //     0xbed76c: mov             x1, x6
    //     0xbed770: mov             x6, x7
    //     0xbed774: b               #0xbed77c
    //     0xbed778: ldr             x6, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    //     0xbed77c: lsl             x7, x1, #1
    //     0xbed780: lsl             w1, w7, #1
    //     0xbed784: add             w7, w1, #8
    //     0xbed788: add             x16, x4, w7, sxtw #1
    //     0xbed78c: ldur            w8, [x16, #0xf]
    //     0xbed790: add             x8, x8, HEAP, lsl #32
    //     0xbed794: ldr             x16, [PP, #0x53f8]  ; [pp+0x53f8] "rect"
    //     0xbed798: cmp             w8, w16
    //     0xbed79c: b.ne            #0xbed7c0
    //     0xbed7a0: add             w7, w1, #0xa
    //     0xbed7a4: add             x16, x4, w7, sxtw #1
    //     0xbed7a8: ldur            w1, [x16, #0xf]
    //     0xbed7ac: add             x1, x1, HEAP, lsl #32
    //     0xbed7b0: sub             w4, w0, w1
    //     0xbed7b4: add             x0, fp, w4, sxtw #2
    //     0xbed7b8: ldr             x0, [x0, #8]
    //     0xbed7bc: b               #0xbed7c4
    //     0xbed7c0: mov             x0, NULL
    //     0xbed7c4: ldur            w1, [x2, #0x17]
    //     0xbed7c8: add             x1, x1, HEAP, lsl #32
    // 0xbed7cc: CheckStackOverflow
    //     0xbed7cc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbed7d0: cmp             SP, x16
    //     0xbed7d4: b.ls            #0xbed7f4
    // 0xbed7d8: stp             x0, x5, [SP, #0x10]
    // 0xbed7dc: stp             x3, x6, [SP]
    // 0xbed7e0: r4 = const [0, 0x5, 0x4, 0x1, curve, 0x4, descendant, 0x1, duration, 0x3, rect, 0x2, null]
    //     0xbed7e0: ldr             x4, [PP, #0x5400]  ; [pp+0x5400] List(13) [0, 0x5, 0x4, 0x1, "curve", 0x4, "descendant", 0x1, "duration", 0x3, "rect", 0x2, Null]
    // 0xbed7e4: r0 = showOnScreen()
    //     0xbed7e4: bl              #0xbedde4  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::showOnScreen
    // 0xbed7e8: LeaveFrame
    //     0xbed7e8: mov             SP, fp
    //     0xbed7ec: ldp             fp, lr, [SP], #0x10
    // 0xbed7f0: ret
    //     0xbed7f0: ret             
    // 0xbed7f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbed7f4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbed7f8: b               #0xbed7d8
  }
  static _ showInViewport(/* No info */) {
    // ** addr: 0xbedbcc, size: 0x218
    // 0xbedbcc: EnterFrame
    //     0xbedbcc: stp             fp, lr, [SP, #-0x10]!
    //     0xbedbd0: mov             fp, SP
    // 0xbedbd4: AllocStack(0x40)
    //     0xbedbd4: sub             SP, SP, #0x40
    // 0xbedbd8: SetupParameters(dynamic _ /* r1 => r9, fp-0x8 */, dynamic _ /* r2 => r8, fp-0x10 */, dynamic _ /* r3 => r7, fp-0x18 */, dynamic _ /* r5 => r6, fp-0x20 */, dynamic _ /* r6 => r5, fp-0x28 */, dynamic _ /* r7 => r4, fp-0x30 */)
    //     0xbedbd8: mov             x9, x1
    //     0xbedbdc: mov             x8, x2
    //     0xbedbe0: mov             x4, x7
    //     0xbedbe4: stur            x7, [fp, #-0x30]
    //     0xbedbe8: mov             x7, x3
    //     0xbedbec: stur            x5, [fp, #-0x20]
    //     0xbedbf0: mov             x16, x6
    //     0xbedbf4: mov             x6, x5
    //     0xbedbf8: mov             x5, x16
    //     0xbedbfc: stur            x1, [fp, #-8]
    //     0xbedc00: stur            x2, [fp, #-0x10]
    //     0xbedc04: stur            x3, [fp, #-0x18]
    //     0xbedc08: stur            x5, [fp, #-0x28]
    // 0xbedc0c: CheckStackOverflow
    //     0xbedc0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbedc10: cmp             SP, x16
    //     0xbedc14: b.ls            #0xbeddd0
    // 0xbedc18: cmp             w8, NULL
    // 0xbedc1c: b.ne            #0xbedc30
    // 0xbedc20: mov             x0, x5
    // 0xbedc24: LeaveFrame
    //     0xbedc24: mov             SP, fp
    //     0xbedc28: ldp             fp, lr, [SP], #0x10
    // 0xbedc2c: ret
    //     0xbedc2c: ret             
    // 0xbedc30: r0 = LoadClassIdInstr(r4)
    //     0xbedc30: ldur            x0, [x4, #-1]
    //     0xbedc34: ubfx            x0, x0, #0xc, #0x14
    // 0xbedc38: mov             x1, x4
    // 0xbedc3c: mov             x2, x8
    // 0xbedc40: mov             x3, x5
    // 0xbedc44: d0 = 0.000000
    //     0xbedc44: eor             v0.16b, v0.16b, v0.16b
    // 0xbedc48: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xbedc48: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xbedc4c: r0 = GDT[cid_x0 + -0x923]()
    //     0xbedc4c: sub             lr, x0, #0x923
    //     0xbedc50: ldr             lr, [x21, lr, lsl #3]
    //     0xbedc54: blr             lr
    // 0xbedc58: mov             x5, x0
    // 0xbedc5c: ldur            x4, [fp, #-0x30]
    // 0xbedc60: stur            x5, [fp, #-0x38]
    // 0xbedc64: r0 = LoadClassIdInstr(r4)
    //     0xbedc64: ldur            x0, [x4, #-1]
    //     0xbedc68: ubfx            x0, x0, #0xc, #0x14
    // 0xbedc6c: mov             x1, x4
    // 0xbedc70: ldur            x2, [fp, #-0x10]
    // 0xbedc74: ldur            x3, [fp, #-0x28]
    // 0xbedc78: d0 = 1.000000
    //     0xbedc78: fmov            d0, #1.00000000
    // 0xbedc7c: r4 = const [0, 0x4, 0, 0x4, null]
    //     0xbedc7c: ldr             x4, [PP, #0xff0]  ; [pp+0xff0] List(5) [0, 0x4, 0, 0x4, Null]
    // 0xbedc80: r0 = GDT[cid_x0 + -0x923]()
    //     0xbedc80: sub             lr, x0, #0x923
    //     0xbedc84: ldr             lr, [x21, lr, lsl #3]
    //     0xbedc88: blr             lr
    // 0xbedc8c: ldur            x1, [fp, #-0x20]
    // 0xbedc90: LoadField: r4 = r1->field_3f
    //     0xbedc90: ldur            w4, [x1, #0x3f]
    // 0xbedc94: DecompressPointer r4
    //     0xbedc94: add             x4, x4, HEAP, lsl #32
    // 0xbedc98: stur            x4, [fp, #-0x40]
    // 0xbedc9c: cmp             w4, NULL
    // 0xbedca0: b.eq            #0xbeddd8
    // 0xbedca4: ldur            x2, [fp, #-0x38]
    // 0xbedca8: LoadField: d0 = r2->field_7
    //     0xbedca8: ldur            d0, [x2, #7]
    // 0xbedcac: LoadField: d1 = r0->field_7
    //     0xbedcac: ldur            d1, [x0, #7]
    // 0xbedcb0: fcmp            d1, d0
    // 0xbedcb4: b.le            #0xbedcc8
    // 0xbedcb8: mov             x3, x0
    // 0xbedcbc: r0 = AllocateRecord2()
    //     0xbedcbc: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbedcc0: mov             x1, x0
    // 0xbedcc4: b               #0xbedcd8
    // 0xbedcc8: mov             x3, x2
    // 0xbedccc: mov             x2, x0
    // 0xbedcd0: r0 = AllocateRecord2()
    //     0xbedcd0: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbedcd4: mov             x1, x0
    // 0xbedcd8: ldur            x0, [fp, #-0x40]
    // 0xbedcdc: LoadField: r2 = r1->field_f
    //     0xbedcdc: ldur            w2, [x1, #0xf]
    // 0xbedce0: DecompressPointer r2
    //     0xbedce0: add             x2, x2, HEAP, lsl #32
    // 0xbedce4: LoadField: r3 = r1->field_13
    //     0xbedce4: ldur            w3, [x1, #0x13]
    // 0xbedce8: DecompressPointer r3
    //     0xbedce8: add             x3, x3, HEAP, lsl #32
    // 0xbedcec: cmp             w3, NULL
    // 0xbedcf0: b.eq            #0xbedddc
    // 0xbedcf4: LoadField: d0 = r3->field_7
    //     0xbedcf4: ldur            d0, [x3, #7]
    // 0xbedcf8: LoadField: d1 = r0->field_7
    //     0xbedcf8: ldur            d1, [x0, #7]
    // 0xbedcfc: fcmp            d1, d0
    // 0xbedd00: b.le            #0xbedd0c
    // 0xbedd04: mov             x0, x3
    // 0xbedd08: b               #0xbedd2c
    // 0xbedd0c: cmp             w2, NULL
    // 0xbedd10: b.eq            #0xbedde0
    // 0xbedd14: LoadField: d0 = r2->field_7
    //     0xbedd14: ldur            d0, [x2, #7]
    // 0xbedd18: fcmp            d0, d1
    // 0xbedd1c: b.le            #0xbedd28
    // 0xbedd20: mov             x0, x2
    // 0xbedd24: b               #0xbedd2c
    // 0xbedd28: r0 = Null
    //     0xbedd28: mov             x0, NULL
    // 0xbedd2c: stur            x0, [fp, #-0x38]
    // 0xbedd30: cmp             w0, NULL
    // 0xbedd34: b.ne            #0xbedda4
    // 0xbedd38: ldur            x3, [fp, #-0x28]
    // 0xbedd3c: ldur            x0, [fp, #-0x30]
    // 0xbedd40: LoadField: r2 = r0->field_13
    //     0xbedd40: ldur            w2, [x0, #0x13]
    // 0xbedd44: DecompressPointer r2
    //     0xbedd44: add             x2, x2, HEAP, lsl #32
    // 0xbedd48: ldur            x1, [fp, #-0x10]
    // 0xbedd4c: r0 = getTransformTo()
    //     0xbedd4c: bl              #0x857070  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0xbedd50: mov             x2, x0
    // 0xbedd54: ldur            x0, [fp, #-0x28]
    // 0xbedd58: stur            x2, [fp, #-0x30]
    // 0xbedd5c: cmp             w0, NULL
    // 0xbedd60: b.ne            #0xbedd8c
    // 0xbedd64: ldur            x1, [fp, #-0x10]
    // 0xbedd68: r0 = LoadClassIdInstr(r1)
    //     0xbedd68: ldur            x0, [x1, #-1]
    //     0xbedd6c: ubfx            x0, x0, #0xc, #0x14
    // 0xbedd70: r0 = GDT[cid_x0 + 0x107cb]()
    //     0xbedd70: mov             x17, #0x7cb
    //     0xbedd74: movk            x17, #1, lsl #16
    //     0xbedd78: add             lr, x0, x17
    //     0xbedd7c: ldr             lr, [x21, lr, lsl #3]
    //     0xbedd80: blr             lr
    // 0xbedd84: mov             x2, x0
    // 0xbedd88: b               #0xbedd90
    // 0xbedd8c: mov             x2, x0
    // 0xbedd90: ldur            x1, [fp, #-0x30]
    // 0xbedd94: r0 = transformRect()
    //     0xbedd94: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0xbedd98: LeaveFrame
    //     0xbedd98: mov             SP, fp
    //     0xbedd9c: ldp             fp, lr, [SP], #0x10
    // 0xbedda0: ret
    //     0xbedda0: ret             
    // 0xbedda4: LoadField: d0 = r0->field_7
    //     0xbedda4: ldur            d0, [x0, #7]
    // 0xbedda8: ldur            x1, [fp, #-0x20]
    // 0xbeddac: ldur            x2, [fp, #-8]
    // 0xbeddb0: ldur            x3, [fp, #-0x18]
    // 0xbeddb4: r0 = moveTo()
    //     0xbeddb4: bl              #0xb34704  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::moveTo
    // 0xbeddb8: ldur            x1, [fp, #-0x38]
    // 0xbeddbc: LoadField: r0 = r1->field_f
    //     0xbeddbc: ldur            w0, [x1, #0xf]
    // 0xbeddc0: DecompressPointer r0
    //     0xbeddc0: add             x0, x0, HEAP, lsl #32
    // 0xbeddc4: LeaveFrame
    //     0xbeddc4: mov             SP, fp
    //     0xbeddc8: ldp             fp, lr, [SP], #0x10
    // 0xbeddcc: ret
    //     0xbeddcc: ret             
    // 0xbeddd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeddd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeddd4: b               #0xbedc18
    // 0xbeddd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbeddd8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbedddc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xbedddc: bl              #0x13e0274  ; NullErrorSharedWithoutFPURegsStub
    // 0xbedde0: r0 = NullErrorSharedWithFPURegs()
    //     0xbedde0: bl              #0x13e02c0  ; NullErrorSharedWithFPURegsStub
  }
  _ showOnScreen(/* No info */) {
    // ** addr: 0xbedde4, size: 0x224
    // 0xbedde4: EnterFrame
    //     0xbedde4: stp             fp, lr, [SP, #-0x10]!
    //     0xbedde8: mov             fp, SP
    // 0xbeddec: AllocStack(0x48)
    //     0xbeddec: sub             SP, SP, #0x48
    // 0xbeddf0: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r2, fp-0x28 */, {dynamic curve = Instance_Cubic /* r3, fp-0x20 */, dynamic descendant = Null /* r5, fp-0x18 */, dynamic duration = Instance_Duration /* r6, fp-0x10 */, dynamic rect = Null /* r4, fp-0x8 */})
    //     0xbeddf0: mov             x2, x1
    //     0xbeddf4: stur            x1, [fp, #-0x28]
    //     0xbeddf8: ldur            w0, [x4, #0x13]
    //     0xbeddfc: ldur            w1, [x4, #0x1f]
    //     0xbede00: add             x1, x1, HEAP, lsl #32
    //     0xbede04: ldr             x16, [PP, #0x5160]  ; [pp+0x5160] "curve"
    //     0xbede08: cmp             w1, w16
    //     0xbede0c: b.ne            #0xbede30
    //     0xbede10: ldur            w1, [x4, #0x23]
    //     0xbede14: add             x1, x1, HEAP, lsl #32
    //     0xbede18: sub             w3, w0, w1
    //     0xbede1c: add             x1, fp, w3, sxtw #2
    //     0xbede20: ldr             x1, [x1, #8]
    //     0xbede24: mov             x3, x1
    //     0xbede28: mov             x1, #1
    //     0xbede2c: b               #0xbede38
    //     0xbede30: ldr             x3, [PP, #0x53e8]  ; [pp+0x53e8] Obj!Cubic@129f421
    //     0xbede34: mov             x1, #0
    //     0xbede38: stur            x3, [fp, #-0x20]
    //     0xbede3c: lsl             x5, x1, #1
    //     0xbede40: lsl             w6, w5, #1
    //     0xbede44: add             w7, w6, #8
    //     0xbede48: add             x16, x4, w7, sxtw #1
    //     0xbede4c: ldur            w8, [x16, #0xf]
    //     0xbede50: add             x8, x8, HEAP, lsl #32
    //     0xbede54: ldr             x16, [PP, #0x53f0]  ; [pp+0x53f0] "descendant"
    //     0xbede58: cmp             w8, w16
    //     0xbede5c: b.ne            #0xbede90
    //     0xbede60: add             w1, w6, #0xa
    //     0xbede64: add             x16, x4, w1, sxtw #1
    //     0xbede68: ldur            w6, [x16, #0xf]
    //     0xbede6c: add             x6, x6, HEAP, lsl #32
    //     0xbede70: sub             w1, w0, w6
    //     0xbede74: add             x6, fp, w1, sxtw #2
    //     0xbede78: ldr             x6, [x6, #8]
    //     0xbede7c: add             w1, w5, #2
    //     0xbede80: sbfx            x5, x1, #1, #0x1f
    //     0xbede84: mov             x1, x5
    //     0xbede88: mov             x5, x6
    //     0xbede8c: b               #0xbede94
    //     0xbede90: mov             x5, NULL
    //     0xbede94: stur            x5, [fp, #-0x18]
    //     0xbede98: lsl             x6, x1, #1
    //     0xbede9c: lsl             w7, w6, #1
    //     0xbedea0: add             w8, w7, #8
    //     0xbedea4: add             x16, x4, w8, sxtw #1
    //     0xbedea8: ldur            w9, [x16, #0xf]
    //     0xbedeac: add             x9, x9, HEAP, lsl #32
    //     0xbedeb0: ldr             x16, [PP, #0x5170]  ; [pp+0x5170] "duration"
    //     0xbedeb4: cmp             w9, w16
    //     0xbedeb8: b.ne            #0xbedeec
    //     0xbedebc: add             w1, w7, #0xa
    //     0xbedec0: add             x16, x4, w1, sxtw #1
    //     0xbedec4: ldur            w7, [x16, #0xf]
    //     0xbedec8: add             x7, x7, HEAP, lsl #32
    //     0xbedecc: sub             w1, w0, w7
    //     0xbeded0: add             x7, fp, w1, sxtw #2
    //     0xbeded4: ldr             x7, [x7, #8]
    //     0xbeded8: add             w1, w6, #2
    //     0xbededc: sbfx            x6, x1, #1, #0x1f
    //     0xbedee0: mov             x1, x6
    //     0xbedee4: mov             x6, x7
    //     0xbedee8: b               #0xbedef0
    //     0xbedeec: ldr             x6, [PP, #0x1808]  ; [pp+0x1808] Obj!Duration@12c8901
    //     0xbedef0: stur            x6, [fp, #-0x10]
    //     0xbedef4: lsl             x7, x1, #1
    //     0xbedef8: lsl             w1, w7, #1
    //     0xbedefc: add             w7, w1, #8
    //     0xbedf00: add             x16, x4, w7, sxtw #1
    //     0xbedf04: ldur            w8, [x16, #0xf]
    //     0xbedf08: add             x8, x8, HEAP, lsl #32
    //     0xbedf0c: ldr             x16, [PP, #0x53f8]  ; [pp+0x53f8] "rect"
    //     0xbedf10: cmp             w8, w16
    //     0xbedf14: b.ne            #0xbedf3c
    //     0xbedf18: add             w7, w1, #0xa
    //     0xbedf1c: add             x16, x4, w7, sxtw #1
    //     0xbedf20: ldur            w1, [x16, #0xf]
    //     0xbedf24: add             x1, x1, HEAP, lsl #32
    //     0xbedf28: sub             w4, w0, w1
    //     0xbedf2c: add             x0, fp, w4, sxtw #2
    //     0xbedf30: ldr             x0, [x0, #8]
    //     0xbedf34: mov             x4, x0
    //     0xbedf38: b               #0xbedf40
    //     0xbedf3c: mov             x4, NULL
    //     0xbedf40: stur            x4, [fp, #-8]
    // 0xbedf44: CheckStackOverflow
    //     0xbedf44: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbedf48: cmp             SP, x16
    //     0xbedf4c: b.ls            #0xbee000
    // 0xbedf50: LoadField: r0 = r2->field_6b
    //     0xbedf50: ldur            w0, [x2, #0x6b]
    // 0xbedf54: DecompressPointer r0
    //     0xbedf54: add             x0, x0, HEAP, lsl #32
    // 0xbedf58: LoadField: r1 = r0->field_23
    //     0xbedf58: ldur            w1, [x0, #0x23]
    // 0xbedf5c: DecompressPointer r1
    //     0xbedf5c: add             x1, x1, HEAP, lsl #32
    // 0xbedf60: r0 = LoadClassIdInstr(r1)
    //     0xbedf60: ldur            x0, [x1, #-1]
    //     0xbedf64: ubfx            x0, x0, #0xc, #0x14
    // 0xbedf68: r0 = GDT[cid_x0 + 0x28dd]()
    //     0xbedf68: mov             x17, #0x28dd
    //     0xbedf6c: add             lr, x0, x17
    //     0xbedf70: ldr             lr, [x21, lr, lsl #3]
    //     0xbedf74: blr             lr
    // 0xbedf78: tbz             w0, #4, #0xbedfb0
    // 0xbedf7c: ldur            x16, [fp, #-0x18]
    // 0xbedf80: ldur            lr, [fp, #-8]
    // 0xbedf84: stp             lr, x16, [SP, #0x10]
    // 0xbedf88: ldur            x16, [fp, #-0x10]
    // 0xbedf8c: ldur            lr, [fp, #-0x20]
    // 0xbedf90: stp             lr, x16, [SP]
    // 0xbedf94: ldur            x1, [fp, #-0x28]
    // 0xbedf98: r4 = const [0, 0x5, 0x4, 0x1, curve, 0x4, descendant, 0x1, duration, 0x3, rect, 0x2, null]
    //     0xbedf98: ldr             x4, [PP, #0x5400]  ; [pp+0x5400] List(13) [0, 0x5, 0x4, 0x1, "curve", 0x4, "descendant", 0x1, "duration", 0x3, "rect", 0x2, Null]
    // 0xbedf9c: r0 = showOnScreen()
    //     0xbedf9c: bl              #0xbee008  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0xbedfa0: r0 = Null
    //     0xbedfa0: mov             x0, NULL
    // 0xbedfa4: LeaveFrame
    //     0xbedfa4: mov             SP, fp
    //     0xbedfa8: ldp             fp, lr, [SP], #0x10
    // 0xbedfac: ret
    //     0xbedfac: ret             
    // 0xbedfb0: ldur            x0, [fp, #-0x28]
    // 0xbedfb4: LoadField: r5 = r0->field_6b
    //     0xbedfb4: ldur            w5, [x0, #0x6b]
    // 0xbedfb8: DecompressPointer r5
    //     0xbedfb8: add             x5, x5, HEAP, lsl #32
    // 0xbedfbc: ldur            x1, [fp, #-0x20]
    // 0xbedfc0: ldur            x2, [fp, #-0x18]
    // 0xbedfc4: ldur            x3, [fp, #-0x10]
    // 0xbedfc8: ldur            x6, [fp, #-8]
    // 0xbedfcc: mov             x7, x0
    // 0xbedfd0: r0 = showInViewport()
    //     0xbedfd0: bl              #0xbedbcc  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::showInViewport
    // 0xbedfd4: ldur            x16, [fp, #-0x10]
    // 0xbedfd8: stp             x16, x0, [SP, #8]
    // 0xbedfdc: ldur            x16, [fp, #-0x20]
    // 0xbedfe0: str             x16, [SP]
    // 0xbedfe4: ldur            x1, [fp, #-0x28]
    // 0xbedfe8: r4 = const [0, 0x4, 0x3, 0x1, curve, 0x3, duration, 0x2, rect, 0x1, null]
    //     0xbedfe8: ldr             x4, [PP, #0x5670]  ; [pp+0x5670] List(11) [0, 0x4, 0x3, 0x1, "curve", 0x3, "duration", 0x2, "rect", 0x1, Null]
    // 0xbedfec: r0 = showOnScreen()
    //     0xbedfec: bl              #0xbee008  ; [package:flutter/src/rendering/object.dart] RenderObject::showOnScreen
    // 0xbedff0: r0 = Null
    //     0xbedff0: mov             x0, NULL
    // 0xbedff4: LeaveFrame
    //     0xbedff4: mov             SP, fp
    //     0xbedff8: ldp             fp, lr, [SP], #0x10
    // 0xbedffc: ret
    //     0xbedffc: ret             
    // 0xbee000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbee000: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbee004: b               #0xbedf50
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0xbf9c14, size: 0x40
    // 0xbf9c14: EnterFrame
    //     0xbf9c14: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9c18: mov             fp, SP
    // 0xbf9c1c: mov             x0, x1
    // 0xbf9c20: mov             x1, x2
    // 0xbf9c24: CheckStackOverflow
    //     0xbf9c24: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf9c28: cmp             SP, x16
    //     0xbf9c2c: b.ls            #0xbf9c4c
    // 0xbf9c30: r2 = Instance_SemanticsTag
    //     0xbf9c30: add             x2, PP, #0x96, lsl #12  ; [pp+0x964d8] Obj!SemanticsTag@129c161
    //     0xbf9c34: ldr             x2, [x2, #0x4d8]
    // 0xbf9c38: r0 = addTagForChildren()
    //     0xbf9c38: bl              #0x898530  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::addTagForChildren
    // 0xbf9c3c: r0 = Null
    //     0xbf9c3c: mov             x0, NULL
    // 0xbf9c40: LeaveFrame
    //     0xbf9c40: mov             SP, fp
    //     0xbf9c44: ldp             fp, lr, [SP], #0x10
    // 0xbf9c48: ret
    //     0xbf9c48: ret             
    // 0xbf9c4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf9c4c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9c50: b               #0xbf9c30
  }
  _ detach(/* No info */) {
    // ** addr: 0xc07040, size: 0x68
    // 0xc07040: EnterFrame
    //     0xc07040: stp             fp, lr, [SP, #-0x10]!
    //     0xc07044: mov             fp, SP
    // 0xc07048: AllocStack(0x10)
    //     0xc07048: sub             SP, SP, #0x10
    // 0xc0704c: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r0, fp-0x10 */)
    //     0xc0704c: mov             x0, x1
    //     0xc07050: stur            x1, [fp, #-0x10]
    // 0xc07054: CheckStackOverflow
    //     0xc07054: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc07058: cmp             SP, x16
    //     0xc0705c: b.ls            #0xc070a0
    // 0xc07060: LoadField: r3 = r0->field_6b
    //     0xc07060: ldur            w3, [x0, #0x6b]
    // 0xc07064: DecompressPointer r3
    //     0xc07064: add             x3, x3, HEAP, lsl #32
    // 0xc07068: mov             x2, x0
    // 0xc0706c: stur            x3, [fp, #-8]
    // 0xc07070: r1 = Function 'markNeedsLayout':.
    //     0xc07070: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cf38] AnonymousClosure: (0xbfb55c), in [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout (0xbfb4c8)
    //     0xc07074: ldr             x1, [x1, #0xf38]
    // 0xc07078: r0 = AllocateClosure()
    //     0xc07078: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0707c: ldur            x1, [fp, #-8]
    // 0xc07080: mov             x2, x0
    // 0xc07084: r0 = removeListener()
    //     0xc07084: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xc07088: ldur            x1, [fp, #-0x10]
    // 0xc0708c: r0 = detach()
    //     0xc0708c: bl              #0xc070a8  ; [dart:mixin_deduplication] _MixinApplication236&RenderBox&ContainerRenderObjectMixin::detach
    // 0xc07090: r0 = Null
    //     0xc07090: mov             x0, NULL
    // 0xc07094: LeaveFrame
    //     0xc07094: mov             SP, fp
    //     0xc07098: ldp             fp, lr, [SP], #0x10
    // 0xc0709c: ret
    //     0xc0709c: ret             
    // 0xc070a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc070a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc070a4: b               #0xc07060
  }
  _ attach(/* No info */) {
    // ** addr: 0xc0a970, size: 0x68
    // 0xc0a970: EnterFrame
    //     0xc0a970: stp             fp, lr, [SP, #-0x10]!
    //     0xc0a974: mov             fp, SP
    // 0xc0a978: AllocStack(0x10)
    //     0xc0a978: sub             SP, SP, #0x10
    // 0xc0a97c: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r0, fp-0x8 */)
    //     0xc0a97c: mov             x0, x1
    //     0xc0a980: stur            x1, [fp, #-8]
    // 0xc0a984: CheckStackOverflow
    //     0xc0a984: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc0a988: cmp             SP, x16
    //     0xc0a98c: b.ls            #0xc0a9d0
    // 0xc0a990: mov             x1, x0
    // 0xc0a994: r0 = attach()
    //     0xc0a994: bl              #0xc0a9d8  ; [dart:mixin_deduplication] _MixinApplication236&RenderBox&ContainerRenderObjectMixin::attach
    // 0xc0a998: ldur            x2, [fp, #-8]
    // 0xc0a99c: LoadField: r0 = r2->field_6b
    //     0xc0a99c: ldur            w0, [x2, #0x6b]
    // 0xc0a9a0: DecompressPointer r0
    //     0xc0a9a0: add             x0, x0, HEAP, lsl #32
    // 0xc0a9a4: stur            x0, [fp, #-0x10]
    // 0xc0a9a8: r1 = Function 'markNeedsLayout':.
    //     0xc0a9a8: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cf38] AnonymousClosure: (0xbfb55c), in [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout (0xbfb4c8)
    //     0xc0a9ac: ldr             x1, [x1, #0xf38]
    // 0xc0a9b0: r0 = AllocateClosure()
    //     0xc0a9b0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc0a9b4: ldur            x1, [fp, #-0x10]
    // 0xc0a9b8: mov             x2, x0
    // 0xc0a9bc: r0 = addListener()
    //     0xc0a9bc: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xc0a9c0: r0 = Null
    //     0xc0a9c0: mov             x0, NULL
    // 0xc0a9c4: LeaveFrame
    //     0xc0a9c4: mov             SP, fp
    //     0xc0a9c8: ldp             fp, lr, [SP], #0x10
    // 0xc0a9cc: ret
    //     0xc0a9cc: ret             
    // 0xc0a9d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0a9d0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0a9d4: b               #0xc0a990
  }
  _ describeSemanticsClip(/* No info */) {
    // ** addr: 0xc15cd8, size: 0x278
    // 0xc15cd8: EnterFrame
    //     0xc15cd8: stp             fp, lr, [SP, #-0x10]!
    //     0xc15cdc: mov             fp, SP
    // 0xc15ce0: AllocStack(0x28)
    //     0xc15ce0: sub             SP, SP, #0x28
    // 0xc15ce4: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r3, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xc15ce4: mov             x3, x1
    //     0xc15ce8: mov             x0, x2
    //     0xc15cec: stur            x1, [fp, #-8]
    // 0xc15cf0: CheckStackOverflow
    //     0xc15cf0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc15cf4: cmp             SP, x16
    //     0xc15cf8: b.ls            #0xc15f38
    // 0xc15cfc: r2 = Null
    //     0xc15cfc: mov             x2, NULL
    // 0xc15d00: r1 = Null
    //     0xc15d00: mov             x1, NULL
    // 0xc15d04: r4 = 60
    //     0xc15d04: mov             x4, #0x3c
    // 0xc15d08: branchIfSmi(r0, 0xc15d14)
    //     0xc15d08: tbz             w0, #0, #0xc15d14
    // 0xc15d0c: r4 = LoadClassIdInstr(r0)
    //     0xc15d0c: ldur            x4, [x0, #-1]
    //     0xc15d10: ubfx            x4, x4, #0xc, #0x14
    // 0xc15d14: r17 = -4688
    //     0xc15d14: mov             x17, #-0x1250
    // 0xc15d18: add             x4, x4, x17
    // 0xc15d1c: cmp             x4, #0xf
    // 0xc15d20: b.ls            #0xc15d38
    // 0xc15d24: r8 = RenderSliver?
    //     0xc15d24: add             x8, PP, #0x90, lsl #12  ; [pp+0x902e8] Type: RenderSliver?
    //     0xc15d28: ldr             x8, [x8, #0x2e8]
    // 0xc15d2c: r3 = Null
    //     0xc15d2c: add             x3, PP, #0x96, lsl #12  ; [pp+0x964a0] Null
    //     0xc15d30: ldr             x3, [x3, #0x4a0]
    // 0xc15d34: r0 = DefaultNullableTypeTest()
    //     0xc15d34: bl              #0x13dd78c  ; DefaultNullableTypeTestStub
    // 0xc15d38: ldur            x0, [fp, #-8]
    // 0xc15d3c: LoadField: r1 = r0->field_73
    //     0xc15d3c: ldur            w1, [x0, #0x73]
    // 0xc15d40: DecompressPointer r1
    //     0xc15d40: add             x1, x1, HEAP, lsl #32
    // 0xc15d44: cmp             w1, NULL
    // 0xc15d48: b.ne            #0xc15d6c
    // 0xc15d4c: mov             x1, x0
    // 0xc15d50: r0 = size()
    //     0xc15d50: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15d54: mov             x2, x0
    // 0xc15d58: r1 = Instance_Offset
    //     0xc15d58: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15d5c: r0 = &()
    //     0xc15d5c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15d60: LeaveFrame
    //     0xc15d60: mov             SP, fp
    //     0xc15d64: ldp             fp, lr, [SP], #0x10
    // 0xc15d68: ret
    //     0xc15d68: ret             
    // 0xc15d6c: mov             x1, x0
    // 0xc15d70: r0 = axis()
    //     0xc15d70: bl              #0xbc8210  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::axis
    // 0xc15d74: LoadField: r1 = r0->field_7
    //     0xc15d74: ldur            x1, [x0, #7]
    // 0xc15d78: cmp             x1, #0
    // 0xc15d7c: b.gt            #0xc15e5c
    // 0xc15d80: ldur            x0, [fp, #-8]
    // 0xc15d84: mov             x1, x0
    // 0xc15d88: r0 = size()
    //     0xc15d88: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15d8c: mov             x2, x0
    // 0xc15d90: r1 = Instance_Offset
    //     0xc15d90: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15d94: r0 = &()
    //     0xc15d94: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15d98: LoadField: d0 = r0->field_7
    //     0xc15d98: ldur            d0, [x0, #7]
    // 0xc15d9c: ldur            x0, [fp, #-8]
    // 0xc15da0: LoadField: r1 = r0->field_73
    //     0xc15da0: ldur            w1, [x0, #0x73]
    // 0xc15da4: DecompressPointer r1
    //     0xc15da4: add             x1, x1, HEAP, lsl #32
    // 0xc15da8: cmp             w1, NULL
    // 0xc15dac: b.eq            #0xc15f40
    // 0xc15db0: LoadField: d1 = r1->field_7
    //     0xc15db0: ldur            d1, [x1, #7]
    // 0xc15db4: fsub            d2, d0, d1
    // 0xc15db8: mov             x1, x0
    // 0xc15dbc: stur            d2, [fp, #-0x10]
    // 0xc15dc0: r0 = size()
    //     0xc15dc0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15dc4: mov             x2, x0
    // 0xc15dc8: r1 = Instance_Offset
    //     0xc15dc8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15dcc: r0 = &()
    //     0xc15dcc: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15dd0: LoadField: d0 = r0->field_f
    //     0xc15dd0: ldur            d0, [x0, #0xf]
    // 0xc15dd4: ldur            x1, [fp, #-8]
    // 0xc15dd8: stur            d0, [fp, #-0x18]
    // 0xc15ddc: r0 = size()
    //     0xc15ddc: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15de0: mov             x2, x0
    // 0xc15de4: r1 = Instance_Offset
    //     0xc15de4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15de8: r0 = &()
    //     0xc15de8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15dec: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xc15dec: ldur            d0, [x0, #0x17]
    // 0xc15df0: ldur            x0, [fp, #-8]
    // 0xc15df4: LoadField: r1 = r0->field_73
    //     0xc15df4: ldur            w1, [x0, #0x73]
    // 0xc15df8: DecompressPointer r1
    //     0xc15df8: add             x1, x1, HEAP, lsl #32
    // 0xc15dfc: cmp             w1, NULL
    // 0xc15e00: b.eq            #0xc15f44
    // 0xc15e04: LoadField: d1 = r1->field_7
    //     0xc15e04: ldur            d1, [x1, #7]
    // 0xc15e08: fadd            d2, d0, d1
    // 0xc15e0c: mov             x1, x0
    // 0xc15e10: stur            d2, [fp, #-0x20]
    // 0xc15e14: r0 = size()
    //     0xc15e14: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15e18: mov             x2, x0
    // 0xc15e1c: r1 = Instance_Offset
    //     0xc15e1c: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15e20: r0 = &()
    //     0xc15e20: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15e24: LoadField: d0 = r0->field_1f
    //     0xc15e24: ldur            d0, [x0, #0x1f]
    // 0xc15e28: stur            d0, [fp, #-0x28]
    // 0xc15e2c: r0 = Rect()
    //     0xc15e2c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc15e30: ldur            d0, [fp, #-0x10]
    // 0xc15e34: StoreField: r0->field_7 = d0
    //     0xc15e34: stur            d0, [x0, #7]
    // 0xc15e38: ldur            d0, [fp, #-0x18]
    // 0xc15e3c: StoreField: r0->field_f = d0
    //     0xc15e3c: stur            d0, [x0, #0xf]
    // 0xc15e40: ldur            d0, [fp, #-0x20]
    // 0xc15e44: ArrayStore: r0[0] = d0  ; List_8
    //     0xc15e44: stur            d0, [x0, #0x17]
    // 0xc15e48: ldur            d0, [fp, #-0x28]
    // 0xc15e4c: StoreField: r0->field_1f = d0
    //     0xc15e4c: stur            d0, [x0, #0x1f]
    // 0xc15e50: LeaveFrame
    //     0xc15e50: mov             SP, fp
    //     0xc15e54: ldp             fp, lr, [SP], #0x10
    // 0xc15e58: ret
    //     0xc15e58: ret             
    // 0xc15e5c: ldur            x0, [fp, #-8]
    // 0xc15e60: mov             x1, x0
    // 0xc15e64: r0 = size()
    //     0xc15e64: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15e68: mov             x2, x0
    // 0xc15e6c: r1 = Instance_Offset
    //     0xc15e6c: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15e70: r0 = &()
    //     0xc15e70: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15e74: LoadField: d0 = r0->field_7
    //     0xc15e74: ldur            d0, [x0, #7]
    // 0xc15e78: ldur            x1, [fp, #-8]
    // 0xc15e7c: stur            d0, [fp, #-0x10]
    // 0xc15e80: r0 = size()
    //     0xc15e80: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15e84: mov             x2, x0
    // 0xc15e88: r1 = Instance_Offset
    //     0xc15e88: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15e8c: r0 = &()
    //     0xc15e8c: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15e90: LoadField: d0 = r0->field_f
    //     0xc15e90: ldur            d0, [x0, #0xf]
    // 0xc15e94: ldur            x0, [fp, #-8]
    // 0xc15e98: LoadField: r1 = r0->field_73
    //     0xc15e98: ldur            w1, [x0, #0x73]
    // 0xc15e9c: DecompressPointer r1
    //     0xc15e9c: add             x1, x1, HEAP, lsl #32
    // 0xc15ea0: cmp             w1, NULL
    // 0xc15ea4: b.eq            #0xc15f48
    // 0xc15ea8: LoadField: d1 = r1->field_7
    //     0xc15ea8: ldur            d1, [x1, #7]
    // 0xc15eac: fsub            d2, d0, d1
    // 0xc15eb0: mov             x1, x0
    // 0xc15eb4: stur            d2, [fp, #-0x18]
    // 0xc15eb8: r0 = size()
    //     0xc15eb8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15ebc: mov             x2, x0
    // 0xc15ec0: r1 = Instance_Offset
    //     0xc15ec0: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15ec4: r0 = &()
    //     0xc15ec4: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15ec8: ArrayLoad: d0 = r0[0]  ; List_8
    //     0xc15ec8: ldur            d0, [x0, #0x17]
    // 0xc15ecc: ldur            x1, [fp, #-8]
    // 0xc15ed0: stur            d0, [fp, #-0x20]
    // 0xc15ed4: r0 = size()
    //     0xc15ed4: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc15ed8: mov             x2, x0
    // 0xc15edc: r1 = Instance_Offset
    //     0xc15edc: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc15ee0: r0 = &()
    //     0xc15ee0: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc15ee4: LoadField: d0 = r0->field_1f
    //     0xc15ee4: ldur            d0, [x0, #0x1f]
    // 0xc15ee8: ldur            x0, [fp, #-8]
    // 0xc15eec: LoadField: r1 = r0->field_73
    //     0xc15eec: ldur            w1, [x0, #0x73]
    // 0xc15ef0: DecompressPointer r1
    //     0xc15ef0: add             x1, x1, HEAP, lsl #32
    // 0xc15ef4: cmp             w1, NULL
    // 0xc15ef8: b.eq            #0xc15f4c
    // 0xc15efc: LoadField: d1 = r1->field_7
    //     0xc15efc: ldur            d1, [x1, #7]
    // 0xc15f00: fadd            d2, d0, d1
    // 0xc15f04: stur            d2, [fp, #-0x28]
    // 0xc15f08: r0 = Rect()
    //     0xc15f08: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc15f0c: ldur            d0, [fp, #-0x10]
    // 0xc15f10: StoreField: r0->field_7 = d0
    //     0xc15f10: stur            d0, [x0, #7]
    // 0xc15f14: ldur            d0, [fp, #-0x18]
    // 0xc15f18: StoreField: r0->field_f = d0
    //     0xc15f18: stur            d0, [x0, #0xf]
    // 0xc15f1c: ldur            d0, [fp, #-0x20]
    // 0xc15f20: ArrayStore: r0[0] = d0  ; List_8
    //     0xc15f20: stur            d0, [x0, #0x17]
    // 0xc15f24: ldur            d0, [fp, #-0x28]
    // 0xc15f28: StoreField: r0->field_1f = d0
    //     0xc15f28: stur            d0, [x0, #0x1f]
    // 0xc15f2c: LeaveFrame
    //     0xc15f2c: mov             SP, fp
    //     0xc15f30: ldp             fp, lr, [SP], #0x10
    // 0xc15f34: ret
    //     0xc15f34: ret             
    // 0xc15f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc15f38: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc15f3c: b               #0xc15cfc
    // 0xc15f40: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15f40: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc15f44: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15f44: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc15f48: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15f48: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc15f4c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc15f4c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xc259ec, size: 0x190
    // 0xc259ec: EnterFrame
    //     0xc259ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc259f0: mov             fp, SP
    // 0xc259f4: AllocStack(0x50)
    //     0xc259f4: sub             SP, SP, #0x50
    // 0xc259f8: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r2, fp-0x18 */, dynamic _ /* r2 => r0, fp-0x20 */, dynamic _ /* r3 => r3, fp-0x28 */)
    //     0xc259f8: mov             x0, x2
    //     0xc259fc: stur            x2, [fp, #-0x20]
    //     0xc25a00: mov             x2, x1
    //     0xc25a04: stur            x1, [fp, #-0x18]
    //     0xc25a08: stur            x3, [fp, #-0x28]
    // 0xc25a0c: CheckStackOverflow
    //     0xc25a0c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc25a10: cmp             SP, x16
    //     0xc25a14: b.ls            #0xc25b6c
    // 0xc25a18: LoadField: r1 = r2->field_5b
    //     0xc25a18: ldur            w1, [x2, #0x5b]
    // 0xc25a1c: DecompressPointer r1
    //     0xc25a1c: add             x1, x1, HEAP, lsl #32
    // 0xc25a20: cmp             w1, NULL
    // 0xc25a24: b.ne            #0xc25a38
    // 0xc25a28: r0 = Null
    //     0xc25a28: mov             x0, NULL
    // 0xc25a2c: LeaveFrame
    //     0xc25a2c: mov             SP, fp
    //     0xc25a30: ldp             fp, lr, [SP], #0x10
    // 0xc25a34: ret
    //     0xc25a34: ret             
    // 0xc25a38: r1 = LoadClassIdInstr(r2)
    //     0xc25a38: ldur            x1, [x2, #-1]
    //     0xc25a3c: ubfx            x1, x1, #0xc, #0x14
    // 0xc25a40: r17 = 4838
    //     0xc25a40: mov             x17, #0x12e6
    // 0xc25a44: cmp             x1, x17
    // 0xc25a48: b.ne            #0xc25a60
    // 0xc25a4c: LoadField: r1 = r2->field_8b
    //     0xc25a4c: ldur            w1, [x2, #0x8b]
    // 0xc25a50: DecompressPointer r1
    //     0xc25a50: add             x1, x1, HEAP, lsl #32
    // 0xc25a54: tbz             w1, #4, #0xc25a6c
    // 0xc25a58: mov             x0, x2
    // 0xc25a5c: b               #0xc25b3c
    // 0xc25a60: LoadField: r1 = r2->field_97
    //     0xc25a60: ldur            w1, [x2, #0x97]
    // 0xc25a64: DecompressPointer r1
    //     0xc25a64: add             x1, x1, HEAP, lsl #32
    // 0xc25a68: tbnz            w1, #4, #0xc25b38
    // 0xc25a6c: LoadField: r1 = r2->field_7b
    //     0xc25a6c: ldur            w1, [x2, #0x7b]
    // 0xc25a70: DecompressPointer r1
    //     0xc25a70: add             x1, x1, HEAP, lsl #32
    // 0xc25a74: r16 = Instance_Clip
    //     0xc25a74: add             x16, PP, #0x15, lsl #12  ; [pp+0x15840] Obj!Clip@12c80c1
    //     0xc25a78: ldr             x16, [x16, #0x840]
    // 0xc25a7c: cmp             w1, w16
    // 0xc25a80: b.eq            #0xc25b30
    // 0xc25a84: LoadField: r4 = r2->field_7f
    //     0xc25a84: ldur            w4, [x2, #0x7f]
    // 0xc25a88: DecompressPointer r4
    //     0xc25a88: add             x4, x4, HEAP, lsl #32
    // 0xc25a8c: stur            x4, [fp, #-0x10]
    // 0xc25a90: LoadField: r5 = r2->field_37
    //     0xc25a90: ldur            w5, [x2, #0x37]
    // 0xc25a94: DecompressPointer r5
    //     0xc25a94: add             x5, x5, HEAP, lsl #32
    // 0xc25a98: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xc25a9c: cmp             w5, w16
    // 0xc25aa0: b.eq            #0xc25b74
    // 0xc25aa4: mov             x1, x2
    // 0xc25aa8: stur            x5, [fp, #-8]
    // 0xc25aac: r0 = size()
    //     0xc25aac: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xc25ab0: mov             x2, x0
    // 0xc25ab4: r1 = Instance_Offset
    //     0xc25ab4: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc25ab8: r0 = &()
    //     0xc25ab8: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xc25abc: mov             x3, x0
    // 0xc25ac0: ldur            x0, [fp, #-0x18]
    // 0xc25ac4: stur            x3, [fp, #-0x40]
    // 0xc25ac8: LoadField: r4 = r0->field_7b
    //     0xc25ac8: ldur            w4, [x0, #0x7b]
    // 0xc25acc: DecompressPointer r4
    //     0xc25acc: add             x4, x4, HEAP, lsl #32
    // 0xc25ad0: ldur            x5, [fp, #-0x10]
    // 0xc25ad4: stur            x4, [fp, #-0x38]
    // 0xc25ad8: LoadField: r6 = r5->field_b
    //     0xc25ad8: ldur            w6, [x5, #0xb]
    // 0xc25adc: DecompressPointer r6
    //     0xc25adc: add             x6, x6, HEAP, lsl #32
    // 0xc25ae0: mov             x2, x0
    // 0xc25ae4: stur            x6, [fp, #-0x30]
    // 0xc25ae8: r1 = Function '_paintContents@616057554':.
    //     0xc25ae8: add             x1, PP, #0x96, lsl #12  ; [pp+0x96468] AnonymousClosure: (0xc25df0), in [package:flutter/src/rendering/viewport.dart] RenderViewportBase::_paintContents (0xc25b7c)
    //     0xc25aec: ldr             x1, [x1, #0x468]
    // 0xc25af0: r0 = AllocateClosure()
    //     0xc25af0: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xc25af4: ldur            x16, [fp, #-0x38]
    // 0xc25af8: ldur            lr, [fp, #-0x30]
    // 0xc25afc: stp             lr, x16, [SP]
    // 0xc25b00: ldur            x1, [fp, #-0x20]
    // 0xc25b04: ldur            x2, [fp, #-8]
    // 0xc25b08: ldur            x3, [fp, #-0x28]
    // 0xc25b0c: ldur            x5, [fp, #-0x40]
    // 0xc25b10: mov             x6, x0
    // 0xc25b14: r4 = const [0, 0x7, 0x2, 0x5, clipBehavior, 0x5, oldLayer, 0x6, null]
    //     0xc25b14: add             x4, PP, #0x90, lsl #12  ; [pp+0x90688] List(9) [0, 0x7, 0x2, 0x5, "clipBehavior", 0x5, "oldLayer", 0x6, Null]
    //     0xc25b18: ldr             x4, [x4, #0x688]
    // 0xc25b1c: r0 = pushClipRect()
    //     0xc25b1c: bl              #0xc19194  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipRect
    // 0xc25b20: ldur            x1, [fp, #-0x10]
    // 0xc25b24: mov             x2, x0
    // 0xc25b28: r0 = layer=()
    //     0xc25b28: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc25b2c: b               #0xc25b5c
    // 0xc25b30: mov             x0, x2
    // 0xc25b34: b               #0xc25b3c
    // 0xc25b38: mov             x0, x2
    // 0xc25b3c: LoadField: r1 = r0->field_7f
    //     0xc25b3c: ldur            w1, [x0, #0x7f]
    // 0xc25b40: DecompressPointer r1
    //     0xc25b40: add             x1, x1, HEAP, lsl #32
    // 0xc25b44: r2 = Null
    //     0xc25b44: mov             x2, NULL
    // 0xc25b48: r0 = layer=()
    //     0xc25b48: bl              #0x89af68  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xc25b4c: ldur            x1, [fp, #-0x18]
    // 0xc25b50: ldur            x2, [fp, #-0x20]
    // 0xc25b54: ldur            x3, [fp, #-0x28]
    // 0xc25b58: r0 = _paintContents()
    //     0xc25b58: bl              #0xc25b7c  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::_paintContents
    // 0xc25b5c: r0 = Null
    //     0xc25b5c: mov             x0, NULL
    // 0xc25b60: LeaveFrame
    //     0xc25b60: mov             SP, fp
    //     0xc25b64: ldp             fp, lr, [SP], #0x10
    // 0xc25b68: ret
    //     0xc25b68: ret             
    // 0xc25b6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc25b6c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc25b70: b               #0xc25a18
    // 0xc25b74: r9 = _needsCompositing
    //     0xc25b74: ldr             x9, [PP, #0x2dd0]  ; [pp+0x2dd0] Field <RenderObject._needsCompositing@30266271>: late (offset: 0x38)
    // 0xc25b78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc25b78: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _paintContents(/* No info */) {
    // ** addr: 0xc25b7c, size: 0x274
    // 0xc25b7c: EnterFrame
    //     0xc25b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xc25b80: mov             fp, SP
    // 0xc25b84: AllocStack(0x60)
    //     0xc25b84: sub             SP, SP, #0x60
    // 0xc25b88: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xc25b88: mov             x0, x2
    //     0xc25b8c: stur            x2, [fp, #-0x10]
    //     0xc25b90: mov             x2, x1
    //     0xc25b94: stur            x1, [fp, #-8]
    //     0xc25b98: stur            x3, [fp, #-0x18]
    // 0xc25b9c: CheckStackOverflow
    //     0xc25b9c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc25ba0: cmp             SP, x16
    //     0xc25ba4: b.ls            #0xc25dd0
    // 0xc25ba8: mov             x1, x2
    // 0xc25bac: r0 = childrenInPaintOrder()
    //     0xc25bac: bl              #0xbec16c  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::childrenInPaintOrder
    // 0xc25bb0: mov             x3, x0
    // 0xc25bb4: stur            x3, [fp, #-0x40]
    // 0xc25bb8: LoadField: r0 = r3->field_b
    //     0xc25bb8: ldur            w0, [x3, #0xb]
    // 0xc25bbc: r4 = LoadInt32Instr(r0)
    //     0xc25bbc: sbfx            x4, x0, #1, #0x1f
    // 0xc25bc0: ldur            x5, [fp, #-8]
    // 0xc25bc4: stur            x4, [fp, #-0x38]
    // 0xc25bc8: r6 = LoadClassIdInstr(r5)
    //     0xc25bc8: ldur            x6, [x5, #-1]
    //     0xc25bcc: ubfx            x6, x6, #0xc, #0x14
    // 0xc25bd0: ldur            x0, [fp, #-0x18]
    // 0xc25bd4: stur            x6, [fp, #-0x30]
    // 0xc25bd8: LoadField: d0 = r0->field_7
    //     0xc25bd8: ldur            d0, [x0, #7]
    // 0xc25bdc: stur            d0, [fp, #-0x50]
    // 0xc25be0: LoadField: d1 = r0->field_f
    //     0xc25be0: ldur            d1, [x0, #0xf]
    // 0xc25be4: stur            d1, [fp, #-0x48]
    // 0xc25be8: r0 = 0
    //     0xc25be8: mov             x0, #0
    // 0xc25bec: CheckStackOverflow
    //     0xc25bec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc25bf0: cmp             SP, x16
    //     0xc25bf4: b.ls            #0xc25dd8
    // 0xc25bf8: LoadField: r1 = r3->field_b
    //     0xc25bf8: ldur            w1, [x3, #0xb]
    // 0xc25bfc: r2 = LoadInt32Instr(r1)
    //     0xc25bfc: sbfx            x2, x1, #1, #0x1f
    // 0xc25c00: cmp             x4, x2
    // 0xc25c04: b.ne            #0xc25db0
    // 0xc25c08: cmp             x0, x2
    // 0xc25c0c: b.ge            #0xc25da0
    // 0xc25c10: LoadField: r1 = r3->field_f
    //     0xc25c10: ldur            w1, [x3, #0xf]
    // 0xc25c14: DecompressPointer r1
    //     0xc25c14: add             x1, x1, HEAP, lsl #32
    // 0xc25c18: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0xc25c18: add             x16, x1, x0, lsl #2
    //     0xc25c1c: ldur            w7, [x16, #0xf]
    // 0xc25c20: DecompressPointer r7
    //     0xc25c20: add             x7, x7, HEAP, lsl #32
    // 0xc25c24: stur            x7, [fp, #-0x28]
    // 0xc25c28: add             x8, x0, #1
    // 0xc25c2c: stur            x8, [fp, #-0x20]
    // 0xc25c30: LoadField: r0 = r7->field_47
    //     0xc25c30: ldur            w0, [x7, #0x47]
    // 0xc25c34: DecompressPointer r0
    //     0xc25c34: add             x0, x0, HEAP, lsl #32
    // 0xc25c38: cmp             w0, NULL
    // 0xc25c3c: b.eq            #0xc25de0
    // 0xc25c40: LoadField: r1 = r0->field_3f
    //     0xc25c40: ldur            w1, [x0, #0x3f]
    // 0xc25c44: DecompressPointer r1
    //     0xc25c44: add             x1, x1, HEAP, lsl #32
    // 0xc25c48: tbnz            w1, #4, #0xc25d80
    // 0xc25c4c: r17 = 4838
    //     0xc25c4c: mov             x17, #0x12e6
    // 0xc25c50: cmp             x6, x17
    // 0xc25c54: b.ne            #0xc25cdc
    // 0xc25c58: LoadField: r9 = r7->field_7
    //     0xc25c58: ldur            w9, [x7, #7]
    // 0xc25c5c: DecompressPointer r9
    //     0xc25c5c: add             x9, x9, HEAP, lsl #32
    // 0xc25c60: stur            x9, [fp, #-0x18]
    // 0xc25c64: cmp             w9, NULL
    // 0xc25c68: b.eq            #0xc25de4
    // 0xc25c6c: mov             x0, x9
    // 0xc25c70: r2 = Null
    //     0xc25c70: mov             x2, NULL
    // 0xc25c74: r1 = Null
    //     0xc25c74: mov             x1, NULL
    // 0xc25c78: r4 = LoadClassIdInstr(r0)
    //     0xc25c78: ldur            x4, [x0, #-1]
    //     0xc25c7c: ubfx            x4, x4, #0xc, #0x14
    // 0xc25c80: r17 = -4183
    //     0xc25c80: mov             x17, #-0x1057
    // 0xc25c84: add             x4, x4, x17
    // 0xc25c88: cmp             x4, #3
    // 0xc25c8c: b.ls            #0xc25ca4
    // 0xc25c90: r8 = SliverLogicalParentData
    //     0xc25c90: add             x8, PP, #0x96, lsl #12  ; [pp+0x961c0] Type: SliverLogicalParentData
    //     0xc25c94: ldr             x8, [x8, #0x1c0]
    // 0xc25c98: r3 = Null
    //     0xc25c98: add             x3, PP, #0x96, lsl #12  ; [pp+0x96470] Null
    //     0xc25c9c: ldr             x3, [x3, #0x470]
    // 0xc25ca0: r0 = DefaultTypeTest()
    //     0xc25ca0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc25ca4: ldur            x0, [fp, #-0x18]
    // 0xc25ca8: LoadField: r1 = r0->field_7
    //     0xc25ca8: ldur            w1, [x0, #7]
    // 0xc25cac: DecompressPointer r1
    //     0xc25cac: add             x1, x1, HEAP, lsl #32
    // 0xc25cb0: cmp             w1, NULL
    // 0xc25cb4: b.eq            #0xc25de8
    // 0xc25cb8: LoadField: d0 = r1->field_7
    //     0xc25cb8: ldur            d0, [x1, #7]
    // 0xc25cbc: ldur            x1, [fp, #-8]
    // 0xc25cc0: ldur            x2, [fp, #-0x28]
    // 0xc25cc4: r3 = Instance_GrowthDirection
    //     0xc25cc4: add             x3, PP, #0x96, lsl #12  ; [pp+0x961d8] Obj!GrowthDirection@12c4281
    //     0xc25cc8: ldr             x3, [x3, #0x1d8]
    // 0xc25ccc: r0 = computeAbsolutePaintOffset()
    //     0xc25ccc: bl              #0xbc7e20  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::computeAbsolutePaintOffset
    // 0xc25cd0: mov             x1, x0
    // 0xc25cd4: mov             x0, x1
    // 0xc25cd8: b               #0xc25d3c
    // 0xc25cdc: mov             x3, x7
    // 0xc25ce0: LoadField: r4 = r3->field_7
    //     0xc25ce0: ldur            w4, [x3, #7]
    // 0xc25ce4: DecompressPointer r4
    //     0xc25ce4: add             x4, x4, HEAP, lsl #32
    // 0xc25ce8: stur            x4, [fp, #-0x18]
    // 0xc25cec: cmp             w4, NULL
    // 0xc25cf0: b.eq            #0xc25dec
    // 0xc25cf4: mov             x0, x4
    // 0xc25cf8: r2 = Null
    //     0xc25cf8: mov             x2, NULL
    // 0xc25cfc: r1 = Null
    //     0xc25cfc: mov             x1, NULL
    // 0xc25d00: r4 = LoadClassIdInstr(r0)
    //     0xc25d00: ldur            x4, [x0, #-1]
    //     0xc25d04: ubfx            x4, x4, #0xc, #0x14
    // 0xc25d08: r17 = -4177
    //     0xc25d08: mov             x17, #-0x1051
    // 0xc25d0c: add             x4, x4, x17
    // 0xc25d10: cmp             x4, #2
    // 0xc25d14: b.ls            #0xc25d2c
    // 0xc25d18: r8 = SliverPhysicalParentData
    //     0xc25d18: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0xc25d1c: ldr             x8, [x8, #0x240]
    // 0xc25d20: r3 = Null
    //     0xc25d20: add             x3, PP, #0x96, lsl #12  ; [pp+0x96480] Null
    //     0xc25d24: ldr             x3, [x3, #0x480]
    // 0xc25d28: r0 = DefaultTypeTest()
    //     0xc25d28: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xc25d2c: ldur            x0, [fp, #-0x18]
    // 0xc25d30: LoadField: r1 = r0->field_7
    //     0xc25d30: ldur            w1, [x0, #7]
    // 0xc25d34: DecompressPointer r1
    //     0xc25d34: add             x1, x1, HEAP, lsl #32
    // 0xc25d38: mov             x0, x1
    // 0xc25d3c: ldur            d0, [fp, #-0x50]
    // 0xc25d40: ldur            d1, [fp, #-0x48]
    // 0xc25d44: LoadField: d2 = r0->field_7
    //     0xc25d44: ldur            d2, [x0, #7]
    // 0xc25d48: fadd            d3, d0, d2
    // 0xc25d4c: stur            d3, [fp, #-0x60]
    // 0xc25d50: LoadField: d2 = r0->field_f
    //     0xc25d50: ldur            d2, [x0, #0xf]
    // 0xc25d54: fadd            d4, d1, d2
    // 0xc25d58: stur            d4, [fp, #-0x58]
    // 0xc25d5c: r0 = Offset()
    //     0xc25d5c: bl              #0x81ce00  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc25d60: ldur            d0, [fp, #-0x60]
    // 0xc25d64: StoreField: r0->field_7 = d0
    //     0xc25d64: stur            d0, [x0, #7]
    // 0xc25d68: ldur            d0, [fp, #-0x58]
    // 0xc25d6c: StoreField: r0->field_f = d0
    //     0xc25d6c: stur            d0, [x0, #0xf]
    // 0xc25d70: ldur            x1, [fp, #-0x10]
    // 0xc25d74: ldur            x2, [fp, #-0x28]
    // 0xc25d78: mov             x3, x0
    // 0xc25d7c: r0 = paintChild()
    //     0xc25d7c: bl              #0xc169c4  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0xc25d80: ldur            x0, [fp, #-0x20]
    // 0xc25d84: ldur            x5, [fp, #-8]
    // 0xc25d88: ldur            x3, [fp, #-0x40]
    // 0xc25d8c: ldur            x6, [fp, #-0x30]
    // 0xc25d90: ldur            d0, [fp, #-0x50]
    // 0xc25d94: ldur            d1, [fp, #-0x48]
    // 0xc25d98: ldur            x4, [fp, #-0x38]
    // 0xc25d9c: b               #0xc25bec
    // 0xc25da0: r0 = Null
    //     0xc25da0: mov             x0, NULL
    // 0xc25da4: LeaveFrame
    //     0xc25da4: mov             SP, fp
    //     0xc25da8: ldp             fp, lr, [SP], #0x10
    // 0xc25dac: ret
    //     0xc25dac: ret             
    // 0xc25db0: mov             x0, x3
    // 0xc25db4: r0 = ConcurrentModificationError()
    //     0xc25db4: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc25db8: mov             x1, x0
    // 0xc25dbc: ldur            x0, [fp, #-0x40]
    // 0xc25dc0: StoreField: r1->field_b = r0
    //     0xc25dc0: stur            w0, [x1, #0xb]
    // 0xc25dc4: mov             x0, x1
    // 0xc25dc8: r0 = Throw()
    //     0xc25dc8: bl              #0x13ddb2c  ; ThrowStub
    // 0xc25dcc: brk             #0
    // 0xc25dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc25dd0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc25dd4: b               #0xc25ba8
    // 0xc25dd8: r0 = StackOverflowSharedWithFPURegs()
    //     0xc25dd8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xc25ddc: b               #0xc25bf8
    // 0xc25de0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc25de0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc25de4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc25de4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xc25de8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc25de8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc25dec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc25dec: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _paintContents(dynamic, PaintingContext, Offset) {
    // ** addr: 0xc25df0, size: 0x40
    // 0xc25df0: EnterFrame
    //     0xc25df0: stp             fp, lr, [SP, #-0x10]!
    //     0xc25df4: mov             fp, SP
    // 0xc25df8: ldr             x0, [fp, #0x20]
    // 0xc25dfc: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xc25dfc: ldur            w1, [x0, #0x17]
    // 0xc25e00: DecompressPointer r1
    //     0xc25e00: add             x1, x1, HEAP, lsl #32
    // 0xc25e04: CheckStackOverflow
    //     0xc25e04: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xc25e08: cmp             SP, x16
    //     0xc25e0c: b.ls            #0xc25e28
    // 0xc25e10: ldr             x2, [fp, #0x18]
    // 0xc25e14: ldr             x3, [fp, #0x10]
    // 0xc25e18: r0 = _paintContents()
    //     0xc25e18: bl              #0xc25b7c  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::_paintContents
    // 0xc25e1c: LeaveFrame
    //     0xc25e1c: mov             SP, fp
    //     0xc25e20: ldp             fp, lr, [SP], #0x10
    // 0xc25e24: ret
    //     0xc25e24: ret             
    // 0xc25e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc25e28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc25e2c: b               #0xc25e10
  }
  _ describeApproximatePaintClip(/* No info */) {
    // ** addr: 0xcce010, size: 0x29c
    // 0xcce010: EnterFrame
    //     0xcce010: stp             fp, lr, [SP, #-0x10]!
    //     0xcce014: mov             fp, SP
    // 0xcce018: AllocStack(0x48)
    //     0xcce018: sub             SP, SP, #0x48
    // 0xcce01c: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r4, fp-0x8 */, dynamic _ /* r2 => r3, fp-0x10 */)
    //     0xcce01c: mov             x4, x1
    //     0xcce020: mov             x3, x2
    //     0xcce024: stur            x1, [fp, #-8]
    //     0xcce028: stur            x2, [fp, #-0x10]
    // 0xcce02c: CheckStackOverflow
    //     0xcce02c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcce030: cmp             SP, x16
    //     0xcce034: b.ls            #0xcce2a4
    // 0xcce038: mov             x0, x3
    // 0xcce03c: r2 = Null
    //     0xcce03c: mov             x2, NULL
    // 0xcce040: r1 = Null
    //     0xcce040: mov             x1, NULL
    // 0xcce044: r4 = 60
    //     0xcce044: mov             x4, #0x3c
    // 0xcce048: branchIfSmi(r0, 0xcce054)
    //     0xcce048: tbz             w0, #0, #0xcce054
    // 0xcce04c: r4 = LoadClassIdInstr(r0)
    //     0xcce04c: ldur            x4, [x0, #-1]
    //     0xcce050: ubfx            x4, x4, #0xc, #0x14
    // 0xcce054: r17 = -4688
    //     0xcce054: mov             x17, #-0x1250
    // 0xcce058: add             x4, x4, x17
    // 0xcce05c: cmp             x4, #0xf
    // 0xcce060: b.ls            #0xcce078
    // 0xcce064: r8 = RenderSliver
    //     0xcce064: add             x8, PP, #0x96, lsl #12  ; [pp+0x961a8] Type: RenderSliver
    //     0xcce068: ldr             x8, [x8, #0x1a8]
    // 0xcce06c: r3 = Null
    //     0xcce06c: add             x3, PP, #0x96, lsl #12  ; [pp+0x964b0] Null
    //     0xcce070: ldr             x3, [x3, #0x4b0]
    // 0xcce074: r0 = RenderSliver()
    //     0xcce074: bl              #0xa16a30  ; IsType_RenderSliver_Stub
    // 0xcce078: ldur            x0, [fp, #-8]
    // 0xcce07c: LoadField: r1 = r0->field_7b
    //     0xcce07c: ldur            w1, [x0, #0x7b]
    // 0xcce080: DecompressPointer r1
    //     0xcce080: add             x1, x1, HEAP, lsl #32
    // 0xcce084: LoadField: r2 = r1->field_7
    //     0xcce084: ldur            x2, [x1, #7]
    // 0xcce088: cmp             x2, #1
    // 0xcce08c: b.gt            #0xcce0a8
    // 0xcce090: cmp             x2, #0
    // 0xcce094: b.gt            #0xcce0a8
    // 0xcce098: r0 = Null
    //     0xcce098: mov             x0, NULL
    // 0xcce09c: LeaveFrame
    //     0xcce09c: mov             SP, fp
    //     0xcce0a0: ldp             fp, lr, [SP], #0x10
    // 0xcce0a4: ret
    //     0xcce0a4: ret             
    // 0xcce0a8: ldur            x2, [fp, #-0x10]
    // 0xcce0ac: mov             x1, x0
    // 0xcce0b0: r0 = size()
    //     0xcce0b0: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xcce0b4: mov             x2, x0
    // 0xcce0b8: r1 = Instance_Offset
    //     0xcce0b8: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xcce0bc: r0 = &()
    //     0xcce0bc: bl              #0x86326c  ; [dart:ui] Offset::&
    // 0xcce0c0: mov             x3, x0
    // 0xcce0c4: ldur            x0, [fp, #-0x10]
    // 0xcce0c8: stur            x3, [fp, #-0x20]
    // 0xcce0cc: LoadField: r4 = r0->field_27
    //     0xcce0cc: ldur            w4, [x0, #0x27]
    // 0xcce0d0: DecompressPointer r4
    //     0xcce0d0: add             x4, x4, HEAP, lsl #32
    // 0xcce0d4: stur            x4, [fp, #-0x18]
    // 0xcce0d8: cmp             w4, NULL
    // 0xcce0dc: b.eq            #0xcce288
    // 0xcce0e0: mov             x0, x4
    // 0xcce0e4: r2 = Null
    //     0xcce0e4: mov             x2, NULL
    // 0xcce0e8: r1 = Null
    //     0xcce0e8: mov             x1, NULL
    // 0xcce0ec: r4 = LoadClassIdInstr(r0)
    //     0xcce0ec: ldur            x4, [x0, #-1]
    //     0xcce0f0: ubfx            x4, x4, #0xc, #0x14
    // 0xcce0f4: cmp             x4, #0xb45
    // 0xcce0f8: b.eq            #0xcce110
    // 0xcce0fc: r8 = SliverConstraints
    //     0xcce0fc: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0xcce100: ldr             x8, [x8, #0x3c0]
    // 0xcce104: r3 = Null
    //     0xcce104: add             x3, PP, #0x96, lsl #12  ; [pp+0x964c0] Null
    //     0xcce108: ldr             x3, [x3, #0x4c0]
    // 0xcce10c: r0 = DefaultTypeTest()
    //     0xcce10c: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xcce110: ldur            x0, [fp, #-0x18]
    // 0xcce114: LoadField: d0 = r0->field_23
    //     0xcce114: ldur            d0, [x0, #0x23]
    // 0xcce118: d1 = 0.000000
    //     0xcce118: eor             v1.16b, v1.16b, v1.16b
    // 0xcce11c: fcmp            d0, d1
    // 0xcce120: b.ne            #0xcce12c
    // 0xcce124: ldur            x1, [fp, #-0x20]
    // 0xcce128: b               #0xcce278
    // 0xcce12c: LoadField: d1 = r0->field_3f
    //     0xcce12c: ldur            d1, [x0, #0x3f]
    // 0xcce130: mov             x1, v1.d[0]
    // 0xcce134: and             x1, x1, #0x7fffffffffffffff
    // 0xcce138: r17 = 9218868437227405312
    //     0xcce138: mov             x17, #0x7ff0000000000000
    // 0xcce13c: cmp             x1, x17
    // 0xcce140: b.eq            #0xcce274
    // 0xcce144: fcmp            d1, d1
    // 0xcce148: b.vc            #0xcce154
    // 0xcce14c: ldur            x1, [fp, #-0x20]
    // 0xcce150: b               #0xcce278
    // 0xcce154: ldur            x2, [fp, #-8]
    // 0xcce158: ldur            x1, [fp, #-0x20]
    // 0xcce15c: LoadField: d2 = r1->field_7
    //     0xcce15c: ldur            d2, [x1, #7]
    // 0xcce160: stur            d2, [fp, #-0x48]
    // 0xcce164: ArrayLoad: d3 = r1[0]  ; List_8
    //     0xcce164: ldur            d3, [x1, #0x17]
    // 0xcce168: stur            d3, [fp, #-0x40]
    // 0xcce16c: LoadField: d4 = r1->field_f
    //     0xcce16c: ldur            d4, [x1, #0xf]
    // 0xcce170: stur            d4, [fp, #-0x38]
    // 0xcce174: LoadField: d5 = r1->field_1f
    //     0xcce174: ldur            d5, [x1, #0x1f]
    // 0xcce178: stur            d5, [fp, #-0x30]
    // 0xcce17c: LoadField: d6 = r0->field_2b
    //     0xcce17c: ldur            d6, [x0, #0x2b]
    // 0xcce180: fsub            d7, d1, d6
    // 0xcce184: fadd            d1, d7, d0
    // 0xcce188: stur            d1, [fp, #-0x28]
    // 0xcce18c: LoadField: r1 = r2->field_63
    //     0xcce18c: ldur            w1, [x2, #0x63]
    // 0xcce190: DecompressPointer r1
    //     0xcce190: add             x1, x1, HEAP, lsl #32
    // 0xcce194: LoadField: r2 = r0->field_b
    //     0xcce194: ldur            w2, [x0, #0xb]
    // 0xcce198: DecompressPointer r2
    //     0xcce198: add             x2, x2, HEAP, lsl #32
    // 0xcce19c: r0 = applyGrowthDirectionToAxisDirection()
    //     0xcce19c: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0xcce1a0: LoadField: r1 = r0->field_7
    //     0xcce1a0: ldur            x1, [x0, #7]
    // 0xcce1a4: cmp             x1, #1
    // 0xcce1a8: b.gt            #0xcce1f0
    // 0xcce1ac: cmp             x1, #0
    // 0xcce1b0: b.gt            #0xcce1d4
    // 0xcce1b4: ldur            d0, [fp, #-0x30]
    // 0xcce1b8: ldur            d1, [fp, #-0x28]
    // 0xcce1bc: fsub            d2, d0, d1
    // 0xcce1c0: ldur            d3, [fp, #-0x48]
    // 0xcce1c4: mov             v0.16b, v2.16b
    // 0xcce1c8: ldur            d2, [fp, #-0x40]
    // 0xcce1cc: ldur            d1, [fp, #-0x38]
    // 0xcce1d0: b               #0xcce234
    // 0xcce1d4: ldur            d2, [fp, #-0x48]
    // 0xcce1d8: ldur            d0, [fp, #-0x30]
    // 0xcce1dc: ldur            d1, [fp, #-0x28]
    // 0xcce1e0: fadd            d3, d2, d1
    // 0xcce1e4: ldur            d2, [fp, #-0x40]
    // 0xcce1e8: ldur            d1, [fp, #-0x38]
    // 0xcce1ec: b               #0xcce234
    // 0xcce1f0: ldur            d2, [fp, #-0x48]
    // 0xcce1f4: ldur            d0, [fp, #-0x30]
    // 0xcce1f8: ldur            d1, [fp, #-0x28]
    // 0xcce1fc: cmp             x1, #2
    // 0xcce200: b.gt            #0xcce21c
    // 0xcce204: ldur            d3, [fp, #-0x38]
    // 0xcce208: fadd            d4, d3, d1
    // 0xcce20c: mov             v3.16b, v2.16b
    // 0xcce210: ldur            d2, [fp, #-0x40]
    // 0xcce214: mov             v1.16b, v4.16b
    // 0xcce218: b               #0xcce234
    // 0xcce21c: ldur            d4, [fp, #-0x40]
    // 0xcce220: ldur            d3, [fp, #-0x38]
    // 0xcce224: fsub            d5, d4, d1
    // 0xcce228: mov             v1.16b, v3.16b
    // 0xcce22c: mov             v3.16b, v2.16b
    // 0xcce230: mov             v2.16b, v5.16b
    // 0xcce234: stur            d3, [fp, #-0x28]
    // 0xcce238: stur            d2, [fp, #-0x30]
    // 0xcce23c: stur            d1, [fp, #-0x38]
    // 0xcce240: stur            d0, [fp, #-0x40]
    // 0xcce244: r0 = Rect()
    //     0xcce244: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0xcce248: ldur            d0, [fp, #-0x28]
    // 0xcce24c: StoreField: r0->field_7 = d0
    //     0xcce24c: stur            d0, [x0, #7]
    // 0xcce250: ldur            d0, [fp, #-0x38]
    // 0xcce254: StoreField: r0->field_f = d0
    //     0xcce254: stur            d0, [x0, #0xf]
    // 0xcce258: ldur            d0, [fp, #-0x30]
    // 0xcce25c: ArrayStore: r0[0] = d0  ; List_8
    //     0xcce25c: stur            d0, [x0, #0x17]
    // 0xcce260: ldur            d0, [fp, #-0x40]
    // 0xcce264: StoreField: r0->field_1f = d0
    //     0xcce264: stur            d0, [x0, #0x1f]
    // 0xcce268: LeaveFrame
    //     0xcce268: mov             SP, fp
    //     0xcce26c: ldp             fp, lr, [SP], #0x10
    // 0xcce270: ret
    //     0xcce270: ret             
    // 0xcce274: ldur            x1, [fp, #-0x20]
    // 0xcce278: mov             x0, x1
    // 0xcce27c: LeaveFrame
    //     0xcce27c: mov             SP, fp
    //     0xcce280: ldp             fp, lr, [SP], #0x10
    // 0xcce284: ret
    //     0xcce284: ret             
    // 0xcce288: r0 = StateError()
    //     0xcce288: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xcce28c: mov             x1, x0
    // 0xcce290: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xcce290: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xcce294: StoreField: r1->field_b = r0
    //     0xcce294: stur            w0, [x1, #0xb]
    // 0xcce298: mov             x0, x1
    // 0xcce29c: r0 = Throw()
    //     0xcce29c: bl              #0x13ddb2c  ; ThrowStub
    // 0xcce2a0: brk             #0
    // 0xcce2a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcce2a4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcce2a8: b               #0xcce038
  }
  set _ clipBehavior=(/* No info */) {
    // ** addr: 0xcf1f54, size: 0x78
    // 0xcf1f54: EnterFrame
    //     0xcf1f54: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1f58: mov             fp, SP
    // 0xcf1f5c: AllocStack(0x8)
    //     0xcf1f5c: sub             SP, SP, #8
    // 0xcf1f60: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0 */)
    //     0xcf1f60: mov             x0, x2
    //     0xcf1f64: mov             x2, x1
    //     0xcf1f68: stur            x1, [fp, #-8]
    // 0xcf1f6c: CheckStackOverflow
    //     0xcf1f6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1f70: cmp             SP, x16
    //     0xcf1f74: b.ls            #0xcf1fc4
    // 0xcf1f78: LoadField: r1 = r2->field_7b
    //     0xcf1f78: ldur            w1, [x2, #0x7b]
    // 0xcf1f7c: DecompressPointer r1
    //     0xcf1f7c: add             x1, x1, HEAP, lsl #32
    // 0xcf1f80: cmp             w0, w1
    // 0xcf1f84: b.eq            #0xcf1fb4
    // 0xcf1f88: StoreField: r2->field_7b = r0
    //     0xcf1f88: stur            w0, [x2, #0x7b]
    //     0xcf1f8c: ldurb           w16, [x2, #-1]
    //     0xcf1f90: ldurb           w17, [x0, #-1]
    //     0xcf1f94: and             x16, x17, x16, lsr #2
    //     0xcf1f98: tst             x16, HEAP, lsr #32
    //     0xcf1f9c: b.eq            #0xcf1fa4
    //     0xcf1fa0: bl              #0x13ddfb4  ; WriteBarrierWrappersStub
    // 0xcf1fa4: mov             x1, x2
    // 0xcf1fa8: r0 = markNeedsPaint()
    //     0xcf1fa8: bl              #0xbf0858  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0xcf1fac: ldur            x1, [fp, #-8]
    // 0xcf1fb0: r0 = markNeedsSemanticsUpdate()
    //     0xcf1fb0: bl              #0x8373c8  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0xcf1fb4: r0 = Null
    //     0xcf1fb4: mov             x0, NULL
    // 0xcf1fb8: LeaveFrame
    //     0xcf1fb8: mov             SP, fp
    //     0xcf1fbc: ldp             fp, lr, [SP], #0x10
    // 0xcf1fc0: ret
    //     0xcf1fc0: ret             
    // 0xcf1fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf1fc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf1fc8: b               #0xcf1f78
  }
  set _ scrollCacheExtent=(/* No info */) {
    // ** addr: 0xcf1fcc, size: 0xdc
    // 0xcf1fcc: EnterFrame
    //     0xcf1fcc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf1fd0: mov             fp, SP
    // 0xcf1fd4: CheckStackOverflow
    //     0xcf1fd4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf1fd8: cmp             SP, x16
    //     0xcf1fdc: b.ls            #0xcf20a0
    // 0xcf1fe0: cmp             w2, NULL
    // 0xcf1fe4: b.ne            #0xcf1ff4
    // 0xcf1fe8: r0 = Instance__PixelScrollCacheExtent
    //     0xcf1fe8: add             x0, PP, #0x8c, lsl #12  ; [pp+0x8cf28] Obj!_PixelScrollCacheExtent@129c0e1
    //     0xcf1fec: ldr             x0, [x0, #0xf28]
    // 0xcf1ff0: b               #0xcf1ff8
    // 0xcf1ff4: mov             x0, x2
    // 0xcf1ff8: LoadField: r2 = r1->field_6f
    //     0xcf1ff8: ldur            w2, [x1, #0x6f]
    // 0xcf1ffc: DecompressPointer r2
    //     0xcf1ffc: add             x2, x2, HEAP, lsl #32
    // 0xcf2000: r3 = LoadClassIdInstr(r0)
    //     0xcf2000: ldur            x3, [x0, #-1]
    //     0xcf2004: ubfx            x3, x3, #0xc, #0x14
    // 0xcf2008: cmp             x3, #0xb19
    // 0xcf200c: b.ne            #0xcf2038
    // 0xcf2010: cmp             w0, w2
    // 0xcf2014: b.eq            #0xcf2060
    // 0xcf2018: r3 = LoadClassIdInstr(r2)
    //     0xcf2018: ldur            x3, [x2, #-1]
    //     0xcf201c: ubfx            x3, x3, #0xc, #0x14
    // 0xcf2020: cmp             x3, #0xb19
    // 0xcf2024: b.ne            #0xcf2070
    // 0xcf2028: d0 = 0.000000
    //     0xcf2028: eor             v0.16b, v0.16b, v0.16b
    // 0xcf202c: fcmp            d0, d0
    // 0xcf2030: b.ne            #0xcf2070
    // 0xcf2034: b               #0xcf2060
    // 0xcf2038: cmp             w0, w2
    // 0xcf203c: b.eq            #0xcf2060
    // 0xcf2040: r3 = LoadClassIdInstr(r2)
    //     0xcf2040: ldur            x3, [x2, #-1]
    //     0xcf2044: ubfx            x3, x3, #0xc, #0x14
    // 0xcf2048: cmp             x3, #0xb1a
    // 0xcf204c: b.ne            #0xcf2070
    // 0xcf2050: d0 = 250.000000
    //     0xcf2050: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cf30] IMM: double(250) from 0x406f400000000000
    //     0xcf2054: ldr             d0, [x17, #0xf30]
    // 0xcf2058: fcmp            d0, d0
    // 0xcf205c: b.ne            #0xcf2070
    // 0xcf2060: r0 = Null
    //     0xcf2060: mov             x0, NULL
    // 0xcf2064: LeaveFrame
    //     0xcf2064: mov             SP, fp
    //     0xcf2068: ldp             fp, lr, [SP], #0x10
    // 0xcf206c: ret
    //     0xcf206c: ret             
    // 0xcf2070: StoreField: r1->field_6f = r0
    //     0xcf2070: stur            w0, [x1, #0x6f]
    //     0xcf2074: ldurb           w16, [x1, #-1]
    //     0xcf2078: ldurb           w17, [x0, #-1]
    //     0xcf207c: and             x16, x17, x16, lsr #2
    //     0xcf2080: tst             x16, HEAP, lsr #32
    //     0xcf2084: b.eq            #0xcf208c
    //     0xcf2088: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf208c: r0 = markNeedsLayout()
    //     0xcf208c: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf2090: r0 = Null
    //     0xcf2090: mov             x0, NULL
    // 0xcf2094: LeaveFrame
    //     0xcf2094: mov             SP, fp
    //     0xcf2098: ldp             fp, lr, [SP], #0x10
    // 0xcf209c: ret
    //     0xcf209c: ret             
    // 0xcf20a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf20a0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf20a4: b               #0xcf1fe0
  }
  set _ offset=(/* No info */) {
    // ** addr: 0xcf20cc, size: 0xe8
    // 0xcf20cc: EnterFrame
    //     0xcf20cc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf20d0: mov             fp, SP
    // 0xcf20d4: AllocStack(0x18)
    //     0xcf20d4: sub             SP, SP, #0x18
    // 0xcf20d8: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r3, fp-0x10 */, dynamic _ /* r2 => r0, fp-0x18 */)
    //     0xcf20d8: mov             x3, x1
    //     0xcf20dc: mov             x0, x2
    //     0xcf20e0: stur            x1, [fp, #-0x10]
    //     0xcf20e4: stur            x2, [fp, #-0x18]
    // 0xcf20e8: CheckStackOverflow
    //     0xcf20e8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf20ec: cmp             SP, x16
    //     0xcf20f0: b.ls            #0xcf21ac
    // 0xcf20f4: LoadField: r4 = r3->field_6b
    //     0xcf20f4: ldur            w4, [x3, #0x6b]
    // 0xcf20f8: DecompressPointer r4
    //     0xcf20f8: add             x4, x4, HEAP, lsl #32
    // 0xcf20fc: stur            x4, [fp, #-8]
    // 0xcf2100: cmp             w0, w4
    // 0xcf2104: b.ne            #0xcf2118
    // 0xcf2108: r0 = Null
    //     0xcf2108: mov             x0, NULL
    // 0xcf210c: LeaveFrame
    //     0xcf210c: mov             SP, fp
    //     0xcf2110: ldp             fp, lr, [SP], #0x10
    // 0xcf2114: ret
    //     0xcf2114: ret             
    // 0xcf2118: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xcf2118: ldur            w1, [x3, #0x17]
    // 0xcf211c: DecompressPointer r1
    //     0xcf211c: add             x1, x1, HEAP, lsl #32
    // 0xcf2120: cmp             w1, NULL
    // 0xcf2124: b.eq            #0xcf2144
    // 0xcf2128: mov             x2, x3
    // 0xcf212c: r1 = Function 'markNeedsLayout':.
    //     0xcf212c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cf38] AnonymousClosure: (0xbfb55c), in [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout (0xbfb4c8)
    //     0xcf2130: ldr             x1, [x1, #0xf38]
    // 0xcf2134: r0 = AllocateClosure()
    //     0xcf2134: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf2138: ldur            x1, [fp, #-8]
    // 0xcf213c: mov             x2, x0
    // 0xcf2140: r0 = removeListener()
    //     0xcf2140: bl              #0xcff968  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xcf2144: ldur            x3, [fp, #-0x10]
    // 0xcf2148: ldur            x0, [fp, #-0x18]
    // 0xcf214c: StoreField: r3->field_6b = r0
    //     0xcf214c: stur            w0, [x3, #0x6b]
    //     0xcf2150: ldurb           w16, [x3, #-1]
    //     0xcf2154: ldurb           w17, [x0, #-1]
    //     0xcf2158: and             x16, x17, x16, lsr #2
    //     0xcf215c: tst             x16, HEAP, lsr #32
    //     0xcf2160: b.eq            #0xcf2168
    //     0xcf2164: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xcf2168: ArrayLoad: r0 = r3[0]  ; List_4
    //     0xcf2168: ldur            w0, [x3, #0x17]
    // 0xcf216c: DecompressPointer r0
    //     0xcf216c: add             x0, x0, HEAP, lsl #32
    // 0xcf2170: cmp             w0, NULL
    // 0xcf2174: b.eq            #0xcf2194
    // 0xcf2178: mov             x2, x3
    // 0xcf217c: r1 = Function 'markNeedsLayout':.
    //     0xcf217c: add             x1, PP, #0x8c, lsl #12  ; [pp+0x8cf38] AnonymousClosure: (0xbfb55c), in [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout (0xbfb4c8)
    //     0xcf2180: ldr             x1, [x1, #0xf38]
    // 0xcf2184: r0 = AllocateClosure()
    //     0xcf2184: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xcf2188: ldur            x1, [fp, #-0x18]
    // 0xcf218c: mov             x2, x0
    // 0xcf2190: r0 = addListener()
    //     0xcf2190: bl              #0xd038e0  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xcf2194: ldur            x1, [fp, #-0x10]
    // 0xcf2198: r0 = markNeedsLayout()
    //     0xcf2198: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf219c: r0 = Null
    //     0xcf219c: mov             x0, NULL
    // 0xcf21a0: LeaveFrame
    //     0xcf21a0: mov             SP, fp
    //     0xcf21a4: ldp             fp, lr, [SP], #0x10
    // 0xcf21a8: ret
    //     0xcf21a8: ret             
    // 0xcf21ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf21ac: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf21b0: b               #0xcf20f4
  }
  set _ crossAxisDirection=(/* No info */) {
    // ** addr: 0xcf2204, size: 0x70
    // 0xcf2204: EnterFrame
    //     0xcf2204: stp             fp, lr, [SP, #-0x10]!
    //     0xcf2208: mov             fp, SP
    // 0xcf220c: mov             x0, x2
    // 0xcf2210: CheckStackOverflow
    //     0xcf2210: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf2214: cmp             SP, x16
    //     0xcf2218: b.ls            #0xcf226c
    // 0xcf221c: LoadField: r2 = r1->field_67
    //     0xcf221c: ldur            w2, [x1, #0x67]
    // 0xcf2220: DecompressPointer r2
    //     0xcf2220: add             x2, x2, HEAP, lsl #32
    // 0xcf2224: cmp             w0, w2
    // 0xcf2228: b.ne            #0xcf223c
    // 0xcf222c: r0 = Null
    //     0xcf222c: mov             x0, NULL
    // 0xcf2230: LeaveFrame
    //     0xcf2230: mov             SP, fp
    //     0xcf2234: ldp             fp, lr, [SP], #0x10
    // 0xcf2238: ret
    //     0xcf2238: ret             
    // 0xcf223c: StoreField: r1->field_67 = r0
    //     0xcf223c: stur            w0, [x1, #0x67]
    //     0xcf2240: ldurb           w16, [x1, #-1]
    //     0xcf2244: ldurb           w17, [x0, #-1]
    //     0xcf2248: and             x16, x17, x16, lsr #2
    //     0xcf224c: tst             x16, HEAP, lsr #32
    //     0xcf2250: b.eq            #0xcf2258
    //     0xcf2254: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf2258: r0 = markNeedsLayout()
    //     0xcf2258: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf225c: r0 = Null
    //     0xcf225c: mov             x0, NULL
    // 0xcf2260: LeaveFrame
    //     0xcf2260: mov             SP, fp
    //     0xcf2264: ldp             fp, lr, [SP], #0x10
    // 0xcf2268: ret
    //     0xcf2268: ret             
    // 0xcf226c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf226c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf2270: b               #0xcf221c
  }
  set _ axisDirection=(/* No info */) {
    // ** addr: 0xcf231c, size: 0x70
    // 0xcf231c: EnterFrame
    //     0xcf231c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf2320: mov             fp, SP
    // 0xcf2324: mov             x0, x2
    // 0xcf2328: CheckStackOverflow
    //     0xcf2328: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf232c: cmp             SP, x16
    //     0xcf2330: b.ls            #0xcf2384
    // 0xcf2334: LoadField: r2 = r1->field_63
    //     0xcf2334: ldur            w2, [x1, #0x63]
    // 0xcf2338: DecompressPointer r2
    //     0xcf2338: add             x2, x2, HEAP, lsl #32
    // 0xcf233c: cmp             w0, w2
    // 0xcf2340: b.ne            #0xcf2354
    // 0xcf2344: r0 = Null
    //     0xcf2344: mov             x0, NULL
    // 0xcf2348: LeaveFrame
    //     0xcf2348: mov             SP, fp
    //     0xcf234c: ldp             fp, lr, [SP], #0x10
    // 0xcf2350: ret
    //     0xcf2350: ret             
    // 0xcf2354: StoreField: r1->field_63 = r0
    //     0xcf2354: stur            w0, [x1, #0x63]
    //     0xcf2358: ldurb           w16, [x1, #-1]
    //     0xcf235c: ldurb           w17, [x0, #-1]
    //     0xcf2360: and             x16, x17, x16, lsr #2
    //     0xcf2364: tst             x16, HEAP, lsr #32
    //     0xcf2368: b.eq            #0xcf2370
    //     0xcf236c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xcf2370: r0 = markNeedsLayout()
    //     0xcf2370: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf2374: r0 = Null
    //     0xcf2374: mov             x0, NULL
    // 0xcf2378: LeaveFrame
    //     0xcf2378: mov             SP, fp
    //     0xcf237c: ldp             fp, lr, [SP], #0x10
    // 0xcf2380: ret
    //     0xcf2380: ret             
    // 0xcf2384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf2384: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf2388: b               #0xcf2334
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x10eb144, size: 0x44c
    // 0x10eb144: EnterFrame
    //     0x10eb144: stp             fp, lr, [SP, #-0x10]!
    //     0x10eb148: mov             fp, SP
    // 0x10eb14c: AllocStack(0x70)
    //     0x10eb14c: sub             SP, SP, #0x70
    // 0x10eb150: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r0, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0x10eb150: mov             x0, x2
    //     0x10eb154: stur            x2, [fp, #-0x10]
    //     0x10eb158: mov             x2, x1
    //     0x10eb15c: stur            x1, [fp, #-8]
    //     0x10eb160: stur            x3, [fp, #-0x18]
    // 0x10eb164: CheckStackOverflow
    //     0x10eb164: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb168: cmp             SP, x16
    //     0x10eb16c: b.ls            #0x10eb504
    // 0x10eb170: mov             x1, x2
    // 0x10eb174: r0 = axis()
    //     0x10eb174: bl              #0xbc8210  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::axis
    // 0x10eb178: LoadField: r1 = r0->field_7
    //     0x10eb178: ldur            x1, [x0, #7]
    // 0x10eb17c: cmp             x1, #0
    // 0x10eb180: b.gt            #0x10eb1f4
    // 0x10eb184: ldur            x0, [fp, #-0x18]
    // 0x10eb188: LoadField: d0 = r0->field_7
    //     0x10eb188: ldur            d0, [x0, #7]
    // 0x10eb18c: LoadField: d1 = r0->field_f
    //     0x10eb18c: ldur            d1, [x0, #0xf]
    // 0x10eb190: r2 = inline_Allocate_Double()
    //     0x10eb190: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x10eb194: add             x2, x2, #0x10
    //     0x10eb198: cmp             x0, x2
    //     0x10eb19c: b.ls            #0x10eb50c
    //     0x10eb1a0: str             x2, [THR, #0x60]  ; THR::top
    //     0x10eb1a4: sub             x2, x2, #0xf
    //     0x10eb1a8: mov             x0, #0xe19c
    //     0x10eb1ac: movk            x0, #3, lsl #16
    //     0x10eb1b0: stur            x0, [x2, #-1]
    // 0x10eb1b4: dmb             ishst
    // 0x10eb1b8: StoreField: r2->field_7 = d0
    //     0x10eb1b8: stur            d0, [x2, #7]
    // 0x10eb1bc: r3 = inline_Allocate_Double()
    //     0x10eb1bc: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x10eb1c0: add             x3, x3, #0x10
    //     0x10eb1c4: cmp             x0, x3
    //     0x10eb1c8: b.ls            #0x10eb520
    //     0x10eb1cc: str             x3, [THR, #0x60]  ; THR::top
    //     0x10eb1d0: sub             x3, x3, #0xf
    //     0x10eb1d4: mov             x0, #0xe19c
    //     0x10eb1d8: movk            x0, #3, lsl #16
    //     0x10eb1dc: stur            x0, [x3, #-1]
    // 0x10eb1e0: dmb             ishst
    // 0x10eb1e4: StoreField: r3->field_7 = d1
    //     0x10eb1e4: stur            d1, [x3, #7]
    // 0x10eb1e8: r0 = AllocateRecord2()
    //     0x10eb1e8: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x10eb1ec: mov             x2, x0
    // 0x10eb1f0: b               #0x10eb260
    // 0x10eb1f4: ldur            x0, [fp, #-0x18]
    // 0x10eb1f8: LoadField: d0 = r0->field_f
    //     0x10eb1f8: ldur            d0, [x0, #0xf]
    // 0x10eb1fc: LoadField: d1 = r0->field_7
    //     0x10eb1fc: ldur            d1, [x0, #7]
    // 0x10eb200: r2 = inline_Allocate_Double()
    //     0x10eb200: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0x10eb204: add             x2, x2, #0x10
    //     0x10eb208: cmp             x0, x2
    //     0x10eb20c: b.ls            #0x10eb53c
    //     0x10eb210: str             x2, [THR, #0x60]  ; THR::top
    //     0x10eb214: sub             x2, x2, #0xf
    //     0x10eb218: mov             x0, #0xe19c
    //     0x10eb21c: movk            x0, #3, lsl #16
    //     0x10eb220: stur            x0, [x2, #-1]
    // 0x10eb224: dmb             ishst
    // 0x10eb228: StoreField: r2->field_7 = d0
    //     0x10eb228: stur            d0, [x2, #7]
    // 0x10eb22c: r3 = inline_Allocate_Double()
    //     0x10eb22c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0x10eb230: add             x3, x3, #0x10
    //     0x10eb234: cmp             x0, x3
    //     0x10eb238: b.ls            #0x10eb550
    //     0x10eb23c: str             x3, [THR, #0x60]  ; THR::top
    //     0x10eb240: sub             x3, x3, #0xf
    //     0x10eb244: mov             x0, #0xe19c
    //     0x10eb248: movk            x0, #3, lsl #16
    //     0x10eb24c: stur            x0, [x3, #-1]
    // 0x10eb250: dmb             ishst
    // 0x10eb254: StoreField: r3->field_7 = d1
    //     0x10eb254: stur            d1, [x3, #7]
    // 0x10eb258: r0 = AllocateRecord2()
    //     0x10eb258: bl              #0x13de578  ; AllocateRecord2Stub
    // 0x10eb25c: mov             x2, x0
    // 0x10eb260: ldur            x0, [fp, #-8]
    // 0x10eb264: ldur            x1, [fp, #-0x10]
    // 0x10eb268: LoadField: r3 = r2->field_f
    //     0x10eb268: ldur            w3, [x2, #0xf]
    // 0x10eb26c: DecompressPointer r3
    //     0x10eb26c: add             x3, x3, HEAP, lsl #32
    // 0x10eb270: stur            x3, [fp, #-0x28]
    // 0x10eb274: LoadField: r4 = r2->field_13
    //     0x10eb274: ldur            w4, [x2, #0x13]
    // 0x10eb278: DecompressPointer r4
    //     0x10eb278: add             x4, x4, HEAP, lsl #32
    // 0x10eb27c: stur            x4, [fp, #-0x20]
    // 0x10eb280: LoadField: r2 = r1->field_7
    //     0x10eb280: ldur            w2, [x1, #7]
    // 0x10eb284: DecompressPointer r2
    //     0x10eb284: add             x2, x2, HEAP, lsl #32
    // 0x10eb288: stur            x2, [fp, #-0x18]
    // 0x10eb28c: r0 = SliverHitTestResult()
    //     0x10eb28c: bl              #0x10eba94  ; AllocateSliverHitTestResultStub -> SliverHitTestResult (size=0x14)
    // 0x10eb290: mov             x2, x0
    // 0x10eb294: ldur            x0, [fp, #-0x18]
    // 0x10eb298: stur            x2, [fp, #-0x30]
    // 0x10eb29c: StoreField: r2->field_7 = r0
    //     0x10eb29c: stur            w0, [x2, #7]
    // 0x10eb2a0: ldur            x0, [fp, #-0x10]
    // 0x10eb2a4: LoadField: r1 = r0->field_b
    //     0x10eb2a4: ldur            w1, [x0, #0xb]
    // 0x10eb2a8: DecompressPointer r1
    //     0x10eb2a8: add             x1, x1, HEAP, lsl #32
    // 0x10eb2ac: StoreField: r2->field_b = r1
    //     0x10eb2ac: stur            w1, [x2, #0xb]
    // 0x10eb2b0: LoadField: r1 = r0->field_f
    //     0x10eb2b0: ldur            w1, [x0, #0xf]
    // 0x10eb2b4: DecompressPointer r1
    //     0x10eb2b4: add             x1, x1, HEAP, lsl #32
    // 0x10eb2b8: StoreField: r2->field_f = r1
    //     0x10eb2b8: stur            w1, [x2, #0xf]
    // 0x10eb2bc: ldur            x1, [fp, #-8]
    // 0x10eb2c0: r0 = childrenInHitTestOrder()
    //     0x10eb2c0: bl              #0x10eb8f0  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::childrenInHitTestOrder
    // 0x10eb2c4: stur            x0, [fp, #-0x50]
    // 0x10eb2c8: LoadField: r1 = r0->field_b
    //     0x10eb2c8: ldur            w1, [x0, #0xb]
    // 0x10eb2cc: r2 = LoadInt32Instr(r1)
    //     0x10eb2cc: sbfx            x2, x1, #1, #0x1f
    // 0x10eb2d0: ldur            x1, [fp, #-8]
    // 0x10eb2d4: stur            x2, [fp, #-0x48]
    // 0x10eb2d8: r3 = LoadClassIdInstr(r1)
    //     0x10eb2d8: ldur            x3, [x1, #-1]
    //     0x10eb2dc: ubfx            x3, x3, #0xc, #0x14
    // 0x10eb2e0: ldur            x4, [fp, #-0x28]
    // 0x10eb2e4: stur            x3, [fp, #-0x40]
    // 0x10eb2e8: LoadField: d0 = r4->field_7
    //     0x10eb2e8: ldur            d0, [x4, #7]
    // 0x10eb2ec: stur            d0, [fp, #-0x60]
    // 0x10eb2f0: r4 = 0
    //     0x10eb2f0: mov             x4, #0
    // 0x10eb2f4: CheckStackOverflow
    //     0x10eb2f4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb2f8: cmp             SP, x16
    //     0x10eb2fc: b.ls            #0x10eb56c
    // 0x10eb300: LoadField: r5 = r0->field_b
    //     0x10eb300: ldur            w5, [x0, #0xb]
    // 0x10eb304: r6 = LoadInt32Instr(r5)
    //     0x10eb304: sbfx            x6, x5, #1, #0x1f
    // 0x10eb308: cmp             x2, x6
    // 0x10eb30c: b.ne            #0x10eb4e8
    // 0x10eb310: cmp             x4, x6
    // 0x10eb314: b.ge            #0x10eb4d8
    // 0x10eb318: LoadField: r5 = r0->field_f
    //     0x10eb318: ldur            w5, [x0, #0xf]
    // 0x10eb31c: DecompressPointer r5
    //     0x10eb31c: add             x5, x5, HEAP, lsl #32
    // 0x10eb320: ArrayLoad: r6 = r5[r4]  ; Unknown_4
    //     0x10eb320: add             x16, x5, x4, lsl #2
    //     0x10eb324: ldur            w6, [x16, #0xf]
    // 0x10eb328: DecompressPointer r6
    //     0x10eb328: add             x6, x6, HEAP, lsl #32
    // 0x10eb32c: stur            x6, [fp, #-0x18]
    // 0x10eb330: add             x5, x4, #1
    // 0x10eb334: stur            x5, [fp, #-0x38]
    // 0x10eb338: LoadField: r4 = r6->field_47
    //     0x10eb338: ldur            w4, [x6, #0x47]
    // 0x10eb33c: DecompressPointer r4
    //     0x10eb33c: add             x4, x4, HEAP, lsl #32
    // 0x10eb340: cmp             w4, NULL
    // 0x10eb344: b.eq            #0x10eb574
    // 0x10eb348: LoadField: r7 = r4->field_3f
    //     0x10eb348: ldur            w7, [x4, #0x3f]
    // 0x10eb34c: DecompressPointer r7
    //     0x10eb34c: add             x7, x7, HEAP, lsl #32
    // 0x10eb350: tbnz            w7, #4, #0x10eb4ac
    // 0x10eb354: r0 = Matrix4()
    //     0x10eb354: bl              #0x832c64  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x10eb358: r4 = 32
    //     0x10eb358: mov             x4, #0x20
    // 0x10eb35c: stur            x0, [fp, #-0x28]
    // 0x10eb360: r0 = AllocateFloat64Array()
    //     0x10eb360: bl              #0x13def28  ; AllocateFloat64ArrayStub
    // 0x10eb364: mov             x1, x0
    // 0x10eb368: ldur            x0, [fp, #-0x28]
    // 0x10eb36c: StoreField: r0->field_7 = r1
    //     0x10eb36c: stur            w1, [x0, #7]
    // 0x10eb370: mov             x1, x0
    // 0x10eb374: r0 = setIdentity()
    //     0x10eb374: bl              #0x836d10  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x10eb378: ldur            x0, [fp, #-0x40]
    // 0x10eb37c: r17 = 4838
    //     0x10eb37c: mov             x17, #0x12e6
    // 0x10eb380: cmp             x0, x17
    // 0x10eb384: b.ne            #0x10eb3a8
    // 0x10eb388: ldur            x1, [fp, #-8]
    // 0x10eb38c: ldur            x2, [fp, #-0x18]
    // 0x10eb390: r0 = paintOffsetOf()
    //     0x10eb390: bl              #0x124ba14  ; [package:flutter/src/rendering/viewport.dart] RenderShrinkWrappingViewport::paintOffsetOf
    // 0x10eb394: LoadField: d0 = r0->field_7
    //     0x10eb394: ldur            d0, [x0, #7]
    // 0x10eb398: LoadField: d1 = r0->field_f
    //     0x10eb398: ldur            d1, [x0, #0xf]
    // 0x10eb39c: ldur            x1, [fp, #-0x28]
    // 0x10eb3a0: r0 = translateByDouble()
    //     0x10eb3a0: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0x10eb3a4: b               #0x10eb404
    // 0x10eb3a8: ldur            x3, [fp, #-0x18]
    // 0x10eb3ac: LoadField: r4 = r3->field_7
    //     0x10eb3ac: ldur            w4, [x3, #7]
    // 0x10eb3b0: DecompressPointer r4
    //     0x10eb3b0: add             x4, x4, HEAP, lsl #32
    // 0x10eb3b4: stur            x4, [fp, #-0x58]
    // 0x10eb3b8: cmp             w4, NULL
    // 0x10eb3bc: b.eq            #0x10eb578
    // 0x10eb3c0: mov             x0, x4
    // 0x10eb3c4: r2 = Null
    //     0x10eb3c4: mov             x2, NULL
    // 0x10eb3c8: r1 = Null
    //     0x10eb3c8: mov             x1, NULL
    // 0x10eb3cc: r4 = LoadClassIdInstr(r0)
    //     0x10eb3cc: ldur            x4, [x0, #-1]
    //     0x10eb3d0: ubfx            x4, x4, #0xc, #0x14
    // 0x10eb3d4: r17 = -4177
    //     0x10eb3d4: mov             x17, #-0x1051
    // 0x10eb3d8: add             x4, x4, x17
    // 0x10eb3dc: cmp             x4, #2
    // 0x10eb3e0: b.ls            #0x10eb3f8
    // 0x10eb3e4: r8 = SliverPhysicalParentData
    //     0x10eb3e4: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0x10eb3e8: ldr             x8, [x8, #0x240]
    // 0x10eb3ec: r3 = Null
    //     0x10eb3ec: add             x3, PP, #0x96, lsl #12  ; [pp+0x96428] Null
    //     0x10eb3f0: ldr             x3, [x3, #0x428]
    // 0x10eb3f4: r0 = DefaultTypeTest()
    //     0x10eb3f4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x10eb3f8: ldur            x1, [fp, #-0x58]
    // 0x10eb3fc: ldur            x2, [fp, #-0x28]
    // 0x10eb400: r0 = applyPaintTransform()
    //     0x10eb400: bl              #0xbf1bec  ; [package:flutter/src/rendering/sliver.dart] SliverPhysicalParentData::applyPaintTransform
    // 0x10eb404: ldur            x0, [fp, #-8]
    // 0x10eb408: ldur            x1, [fp, #-0x28]
    // 0x10eb40c: r0 = removePerspectiveTransform()
    //     0x10eb40c: bl              #0x10e8d34  ; [package:flutter/src/gestures/events.dart] PointerEvent::removePerspectiveTransform
    // 0x10eb410: mov             x1, x0
    // 0x10eb414: r0 = tryInvert()
    //     0x10eb414: bl              #0xb986b0  ; [package:vector_math/vector_math_64.dart] Matrix4::tryInvert
    // 0x10eb418: cmp             w0, NULL
    // 0x10eb41c: b.eq            #0x10eb57c
    // 0x10eb420: ldur            x1, [fp, #-0x10]
    // 0x10eb424: mov             x2, x0
    // 0x10eb428: r0 = pushTransform()
    //     0x10eb428: bl              #0xaf98ec  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushTransform
    // 0x10eb42c: ldur            x3, [fp, #-8]
    // 0x10eb430: r0 = LoadClassIdInstr(r3)
    //     0x10eb430: ldur            x0, [x3, #-1]
    //     0x10eb434: ubfx            x0, x0, #0xc, #0x14
    // 0x10eb438: mov             x1, x3
    // 0x10eb43c: ldur            x2, [fp, #-0x18]
    // 0x10eb440: ldur            d0, [fp, #-0x60]
    // 0x10eb444: r0 = GDT[cid_x0 + 0xe31]()
    //     0x10eb444: add             lr, x0, #0xe31
    //     0x10eb448: ldr             lr, [x21, lr, lsl #3]
    //     0x10eb44c: blr             lr
    // 0x10eb450: r0 = inline_Allocate_Double()
    //     0x10eb450: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x10eb454: add             x0, x0, #0x10
    //     0x10eb458: cmp             x1, x0
    //     0x10eb45c: b.ls            #0x10eb580
    //     0x10eb460: str             x0, [THR, #0x60]  ; THR::top
    //     0x10eb464: sub             x0, x0, #0xf
    //     0x10eb468: mov             x1, #0xe19c
    //     0x10eb46c: movk            x1, #3, lsl #16
    //     0x10eb470: stur            x1, [x0, #-1]
    // 0x10eb474: dmb             ishst
    // 0x10eb478: StoreField: r0->field_7 = d0
    //     0x10eb478: stur            d0, [x0, #7]
    // 0x10eb47c: ldur            x16, [fp, #-0x20]
    // 0x10eb480: stp             x16, x0, [SP]
    // 0x10eb484: ldur            x1, [fp, #-0x18]
    // 0x10eb488: ldur            x2, [fp, #-0x30]
    // 0x10eb48c: r4 = const [0, 0x4, 0x2, 0x2, crossAxisPosition, 0x3, mainAxisPosition, 0x2, null]
    //     0x10eb48c: add             x4, PP, #0x96, lsl #12  ; [pp+0x96438] List(9) [0, 0x4, 0x2, 0x2, "crossAxisPosition", 0x3, "mainAxisPosition", 0x2, Null]
    //     0x10eb490: ldr             x4, [x4, #0x438]
    // 0x10eb494: r0 = hitTest()
    //     0x10eb494: bl              #0x10eb6cc  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::hitTest
    // 0x10eb498: ldur            x1, [fp, #-0x10]
    // 0x10eb49c: stur            x0, [fp, #-0x18]
    // 0x10eb4a0: r0 = popTransform()
    //     0x10eb4a0: bl              #0xaf9850  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x10eb4a4: ldur            x0, [fp, #-0x18]
    // 0x10eb4a8: tbz             w0, #4, #0x10eb4c8
    // 0x10eb4ac: ldur            x4, [fp, #-0x38]
    // 0x10eb4b0: ldur            x1, [fp, #-8]
    // 0x10eb4b4: ldur            x0, [fp, #-0x50]
    // 0x10eb4b8: ldur            x3, [fp, #-0x40]
    // 0x10eb4bc: ldur            x2, [fp, #-0x48]
    // 0x10eb4c0: ldur            d0, [fp, #-0x60]
    // 0x10eb4c4: b               #0x10eb2f4
    // 0x10eb4c8: r0 = true
    //     0x10eb4c8: add             x0, NULL, #0x20  ; true
    // 0x10eb4cc: LeaveFrame
    //     0x10eb4cc: mov             SP, fp
    //     0x10eb4d0: ldp             fp, lr, [SP], #0x10
    // 0x10eb4d4: ret
    //     0x10eb4d4: ret             
    // 0x10eb4d8: r0 = false
    //     0x10eb4d8: add             x0, NULL, #0x30  ; false
    // 0x10eb4dc: LeaveFrame
    //     0x10eb4dc: mov             SP, fp
    //     0x10eb4e0: ldp             fp, lr, [SP], #0x10
    // 0x10eb4e4: ret
    //     0x10eb4e4: ret             
    // 0x10eb4e8: r0 = ConcurrentModificationError()
    //     0x10eb4e8: bl              #0x7d754c  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x10eb4ec: mov             x1, x0
    // 0x10eb4f0: ldur            x0, [fp, #-0x50]
    // 0x10eb4f4: StoreField: r1->field_b = r0
    //     0x10eb4f4: stur            w0, [x1, #0xb]
    // 0x10eb4f8: mov             x0, x1
    // 0x10eb4fc: r0 = Throw()
    //     0x10eb4fc: bl              #0x13ddb2c  ; ThrowStub
    // 0x10eb500: brk             #0
    // 0x10eb504: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eb504: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eb508: b               #0x10eb170
    // 0x10eb50c: stp             q0, q1, [SP, #-0x20]!
    // 0x10eb510: r0 = AllocateDouble()
    //     0x10eb510: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10eb514: mov             x2, x0
    // 0x10eb518: ldp             q0, q1, [SP], #0x20
    // 0x10eb51c: b               #0x10eb1b8
    // 0x10eb520: SaveReg d1
    //     0x10eb520: str             q1, [SP, #-0x10]!
    // 0x10eb524: SaveReg r2
    //     0x10eb524: str             x2, [SP, #-8]!
    // 0x10eb528: r0 = AllocateDouble()
    //     0x10eb528: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10eb52c: mov             x3, x0
    // 0x10eb530: RestoreReg r2
    //     0x10eb530: ldr             x2, [SP], #8
    // 0x10eb534: RestoreReg d1
    //     0x10eb534: ldr             q1, [SP], #0x10
    // 0x10eb538: b               #0x10eb1e4
    // 0x10eb53c: stp             q0, q1, [SP, #-0x20]!
    // 0x10eb540: r0 = AllocateDouble()
    //     0x10eb540: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10eb544: mov             x2, x0
    // 0x10eb548: ldp             q0, q1, [SP], #0x20
    // 0x10eb54c: b               #0x10eb228
    // 0x10eb550: SaveReg d1
    //     0x10eb550: str             q1, [SP, #-0x10]!
    // 0x10eb554: SaveReg r2
    //     0x10eb554: str             x2, [SP, #-8]!
    // 0x10eb558: r0 = AllocateDouble()
    //     0x10eb558: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10eb55c: mov             x3, x0
    // 0x10eb560: RestoreReg r2
    //     0x10eb560: ldr             x2, [SP], #8
    // 0x10eb564: RestoreReg d1
    //     0x10eb564: ldr             q1, [SP], #0x10
    // 0x10eb568: b               #0x10eb254
    // 0x10eb56c: r0 = StackOverflowSharedWithFPURegs()
    //     0x10eb56c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x10eb570: b               #0x10eb300
    // 0x10eb574: r0 = NullCastErrorSharedWithFPURegs()
    //     0x10eb574: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x10eb578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10eb578: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10eb57c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10eb57c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x10eb580: SaveReg d0
    //     0x10eb580: str             q0, [SP, #-0x10]!
    // 0x10eb584: r0 = AllocateDouble()
    //     0x10eb584: bl              #0x13df878  ; AllocateDoubleStub
    // 0x10eb588: RestoreReg d0
    //     0x10eb588: ldr             q0, [SP], #0x10
    // 0x10eb58c: b               #0x10eb478
  }
  get _ childrenInHitTestOrder(/* No info */) {
    // ** addr: 0x10eb8f0, size: 0x2c
    // 0x10eb8f0: EnterFrame
    //     0x10eb8f0: stp             fp, lr, [SP, #-0x10]!
    //     0x10eb8f4: mov             fp, SP
    // 0x10eb8f8: CheckStackOverflow
    //     0x10eb8f8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb8fc: cmp             SP, x16
    //     0x10eb900: b.ls            #0x10eb914
    // 0x10eb904: r0 = _childrenFirstToLast()
    //     0x10eb904: bl              #0x10eb91c  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::_childrenFirstToLast
    // 0x10eb908: LeaveFrame
    //     0x10eb908: mov             SP, fp
    //     0x10eb90c: ldp             fp, lr, [SP], #0x10
    // 0x10eb910: ret
    //     0x10eb910: ret             
    // 0x10eb914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eb914: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eb918: b               #0x10eb904
  }
  get _ _childrenFirstToLast(/* No info */) {
    // ** addr: 0x10eb91c, size: 0x178
    // 0x10eb91c: EnterFrame
    //     0x10eb91c: stp             fp, lr, [SP, #-0x10]!
    //     0x10eb920: mov             fp, SP
    // 0x10eb924: AllocStack(0x28)
    //     0x10eb924: sub             SP, SP, #0x28
    // 0x10eb928: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r0, fp-0x8 */)
    //     0x10eb928: mov             x0, x1
    //     0x10eb92c: stur            x1, [fp, #-8]
    // 0x10eb930: CheckStackOverflow
    //     0x10eb930: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb934: cmp             SP, x16
    //     0x10eb938: b.ls            #0x10eba80
    // 0x10eb93c: r1 = <RenderSliver>
    //     0x10eb93c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96450] TypeArguments: <RenderSliver>
    //     0x10eb940: ldr             x1, [x1, #0x450]
    // 0x10eb944: r2 = 0
    //     0x10eb944: mov             x2, #0
    // 0x10eb948: r0 = _GrowableList()
    //     0x10eb948: bl              #0x7d9940  ; [dart:core] _GrowableList::_GrowableList
    // 0x10eb94c: mov             x2, x0
    // 0x10eb950: ldur            x0, [fp, #-8]
    // 0x10eb954: stur            x2, [fp, #-0x20]
    // 0x10eb958: LoadField: r1 = r0->field_5b
    //     0x10eb958: ldur            w1, [x0, #0x5b]
    // 0x10eb95c: DecompressPointer r1
    //     0x10eb95c: add             x1, x1, HEAP, lsl #32
    // 0x10eb960: LoadField: r3 = r0->field_4f
    //     0x10eb960: ldur            w3, [x0, #0x4f]
    // 0x10eb964: DecompressPointer r3
    //     0x10eb964: add             x3, x3, HEAP, lsl #32
    // 0x10eb968: stur            x3, [fp, #-0x18]
    // 0x10eb96c: mov             x0, x1
    // 0x10eb970: stur            x0, [fp, #-8]
    // 0x10eb974: CheckStackOverflow
    //     0x10eb974: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x10eb978: cmp             SP, x16
    //     0x10eb97c: b.ls            #0x10eba88
    // 0x10eb980: cmp             w0, NULL
    // 0x10eb984: b.eq            #0x10eba70
    // 0x10eb988: LoadField: r1 = r2->field_b
    //     0x10eb988: ldur            w1, [x2, #0xb]
    // 0x10eb98c: LoadField: r4 = r2->field_f
    //     0x10eb98c: ldur            w4, [x2, #0xf]
    // 0x10eb990: DecompressPointer r4
    //     0x10eb990: add             x4, x4, HEAP, lsl #32
    // 0x10eb994: LoadField: r5 = r4->field_b
    //     0x10eb994: ldur            w5, [x4, #0xb]
    // 0x10eb998: r4 = LoadInt32Instr(r1)
    //     0x10eb998: sbfx            x4, x1, #1, #0x1f
    // 0x10eb99c: stur            x4, [fp, #-0x10]
    // 0x10eb9a0: r1 = LoadInt32Instr(r5)
    //     0x10eb9a0: sbfx            x1, x5, #1, #0x1f
    // 0x10eb9a4: cmp             x4, x1
    // 0x10eb9a8: b.ne            #0x10eb9b4
    // 0x10eb9ac: mov             x1, x2
    // 0x10eb9b0: r0 = _growToNextCapacity()
    //     0x10eb9b0: bl              #0x7d9738  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x10eb9b4: ldur            x3, [fp, #-0x20]
    // 0x10eb9b8: ldur            x2, [fp, #-8]
    // 0x10eb9bc: ldur            x4, [fp, #-0x10]
    // 0x10eb9c0: add             x0, x4, #1
    // 0x10eb9c4: lsl             x1, x0, #1
    // 0x10eb9c8: StoreField: r3->field_b = r1
    //     0x10eb9c8: stur            w1, [x3, #0xb]
    // 0x10eb9cc: LoadField: r1 = r3->field_f
    //     0x10eb9cc: ldur            w1, [x3, #0xf]
    // 0x10eb9d0: DecompressPointer r1
    //     0x10eb9d0: add             x1, x1, HEAP, lsl #32
    // 0x10eb9d4: mov             x0, x2
    // 0x10eb9d8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x10eb9d8: add             x25, x1, x4, lsl #2
    //     0x10eb9dc: add             x25, x25, #0xf
    //     0x10eb9e0: str             w0, [x25]
    //     0x10eb9e4: tbz             w0, #0, #0x10eba00
    //     0x10eb9e8: ldurb           w16, [x1, #-1]
    //     0x10eb9ec: ldurb           w17, [x0, #-1]
    //     0x10eb9f0: and             x16, x17, x16, lsr #2
    //     0x10eb9f4: tst             x16, HEAP, lsr #32
    //     0x10eb9f8: b.eq            #0x10eba00
    //     0x10eb9fc: bl              #0x13ddb50  ; ArrayWriteBarrierStub
    // 0x10eba00: LoadField: r4 = r2->field_7
    //     0x10eba00: ldur            w4, [x2, #7]
    // 0x10eba04: DecompressPointer r4
    //     0x10eba04: add             x4, x4, HEAP, lsl #32
    // 0x10eba08: stur            x4, [fp, #-0x28]
    // 0x10eba0c: cmp             w4, NULL
    // 0x10eba10: b.eq            #0x10eba90
    // 0x10eba14: mov             x0, x4
    // 0x10eba18: ldur            x2, [fp, #-0x18]
    // 0x10eba1c: r1 = Null
    //     0x10eba1c: mov             x1, NULL
    // 0x10eba20: cmp             w2, NULL
    // 0x10eba24: b.eq            #0x10eba48
    // 0x10eba28: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x10eba28: ldur            w4, [x2, #0x17]
    // 0x10eba2c: DecompressPointer r4
    //     0x10eba2c: add             x4, x4, HEAP, lsl #32
    // 0x10eba30: r8 = X0 bound ContainerParentDataMixin
    //     0x10eba30: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x10eba34: ldr             x8, [x8, #0x218]
    // 0x10eba38: LoadField: r9 = r4->field_7
    //     0x10eba38: ldur            x9, [x4, #7]
    // 0x10eba3c: r3 = Null
    //     0x10eba3c: add             x3, PP, #0x96, lsl #12  ; [pp+0x96458] Null
    //     0x10eba40: ldr             x3, [x3, #0x458]
    // 0x10eba44: blr             x9
    // 0x10eba48: ldur            x1, [fp, #-0x28]
    // 0x10eba4c: r0 = LoadClassIdInstr(r1)
    //     0x10eba4c: ldur            x0, [x1, #-1]
    //     0x10eba50: ubfx            x0, x0, #0xc, #0x14
    // 0x10eba54: r0 = GDT[cid_x0 + 0xbf3a]()
    //     0x10eba54: mov             x17, #0xbf3a
    //     0x10eba58: add             lr, x0, x17
    //     0x10eba5c: ldr             lr, [x21, lr, lsl #3]
    //     0x10eba60: blr             lr
    // 0x10eba64: ldur            x2, [fp, #-0x20]
    // 0x10eba68: ldur            x3, [fp, #-0x18]
    // 0x10eba6c: b               #0x10eb970
    // 0x10eba70: ldur            x0, [fp, #-0x20]
    // 0x10eba74: LeaveFrame
    //     0x10eba74: mov             SP, fp
    //     0x10eba78: ldp             fp, lr, [SP], #0x10
    // 0x10eba7c: ret
    //     0x10eba7c: ret             
    // 0x10eba80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eba80: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eba84: b               #0x10eb93c
    // 0x10eba88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x10eba88: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x10eba8c: b               #0x10eb980
    // 0x10eba90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x10eba90: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x10f00fc, size: 0x24
    // 0x10f00fc: EnterFrame
    //     0x10f00fc: stp             fp, lr, [SP, #-0x10]!
    //     0x10f0100: mov             fp, SP
    // 0x10f0104: ldr             x2, [fp, #0x10]
    // 0x10f0108: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x10f0108: add             x1, PP, #0xa1, lsl #12  ; [pp+0xa11c8] AnonymousClosure: static (0x12ffab4), in [package:material_color_utilities/dynamiccolor/material_dynamic_colors.dart] MaterialDynamicColors::scrim (0x8b98ec)
    //     0x10f010c: ldr             x1, [x1, #0x1c8]
    // 0x10f0110: r0 = AllocateClosure()
    //     0x10f0110: bl              #0x13dec0c  ; AllocateClosureStub
    // 0x10f0114: LeaveFrame
    //     0x10f0114: mov             SP, fp
    //     0x10f0118: ldp             fp, lr, [SP], #0x10
    // 0x10f011c: ret
    //     0x10f011c: ret             
  }
  _ RenderViewportBase(/* No info */) {
    // ** addr: 0x11cba44, size: 0x178
    // 0x11cba44: EnterFrame
    //     0x11cba44: stp             fp, lr, [SP, #-0x10]!
    //     0x11cba48: mov             fp, SP
    // 0x11cba4c: AllocStack(0x30)
    //     0x11cba4c: sub             SP, SP, #0x30
    // 0x11cba50: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* r5 => r2, fp-0x20 */, dynamic _ /* r6 => r0, fp-0x28 */, dynamic _ /* r7 => r7, fp-0x30 */)
    //     0x11cba50: mov             x4, x2
    //     0x11cba54: stur            x2, [fp, #-0x10]
    //     0x11cba58: mov             x2, x5
    //     0x11cba5c: stur            x5, [fp, #-0x20]
    //     0x11cba60: mov             x5, x1
    //     0x11cba64: mov             x0, x6
    //     0x11cba68: stur            x1, [fp, #-8]
    //     0x11cba6c: stur            x3, [fp, #-0x18]
    //     0x11cba70: stur            x6, [fp, #-0x28]
    //     0x11cba74: stur            x7, [fp, #-0x30]
    // 0x11cba78: CheckStackOverflow
    //     0x11cba78: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cba7c: cmp             SP, x16
    //     0x11cba80: b.ls            #0x11cbbb4
    // 0x11cba84: r1 = <ClipRectLayer>
    //     0x11cba84: add             x1, PP, #0x84, lsl #12  ; [pp+0x84fc8] TypeArguments: <ClipRectLayer>
    //     0x11cba88: ldr             x1, [x1, #0xfc8]
    // 0x11cba8c: r0 = LayerHandle()
    //     0x11cba8c: bl              #0x89d118  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x11cba90: ldur            x1, [fp, #-8]
    // 0x11cba94: StoreField: r1->field_7f = r0
    //     0x11cba94: stur            w0, [x1, #0x7f]
    //     0x11cba98: ldurb           w16, [x1, #-1]
    //     0x11cba9c: ldurb           w17, [x0, #-1]
    //     0x11cbaa0: and             x16, x17, x16, lsr #2
    //     0x11cbaa4: tst             x16, HEAP, lsr #32
    //     0x11cbaa8: b.eq            #0x11cbab0
    //     0x11cbaac: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cbab0: ldur            x0, [fp, #-0x10]
    // 0x11cbab4: StoreField: r1->field_63 = r0
    //     0x11cbab4: stur            w0, [x1, #0x63]
    //     0x11cbab8: ldurb           w16, [x1, #-1]
    //     0x11cbabc: ldurb           w17, [x0, #-1]
    //     0x11cbac0: and             x16, x17, x16, lsr #2
    //     0x11cbac4: tst             x16, HEAP, lsr #32
    //     0x11cbac8: b.eq            #0x11cbad0
    //     0x11cbacc: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cbad0: ldur            x0, [fp, #-0x20]
    // 0x11cbad4: StoreField: r1->field_67 = r0
    //     0x11cbad4: stur            w0, [x1, #0x67]
    //     0x11cbad8: ldurb           w16, [x1, #-1]
    //     0x11cbadc: ldurb           w17, [x0, #-1]
    //     0x11cbae0: and             x16, x17, x16, lsr #2
    //     0x11cbae4: tst             x16, HEAP, lsr #32
    //     0x11cbae8: b.eq            #0x11cbaf0
    //     0x11cbaec: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cbaf0: ldur            x0, [fp, #-0x28]
    // 0x11cbaf4: StoreField: r1->field_6b = r0
    //     0x11cbaf4: stur            w0, [x1, #0x6b]
    //     0x11cbaf8: ldurb           w16, [x1, #-1]
    //     0x11cbafc: ldurb           w17, [x0, #-1]
    //     0x11cbb00: and             x16, x17, x16, lsr #2
    //     0x11cbb04: tst             x16, HEAP, lsr #32
    //     0x11cbb08: b.eq            #0x11cbb10
    //     0x11cbb0c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cbb10: ldur            x0, [fp, #-0x30]
    // 0x11cbb14: cmp             w0, NULL
    // 0x11cbb18: b.ne            #0x11cbb2c
    // 0x11cbb1c: r0 = _PixelScrollCacheExtent()
    //     0x11cbb1c: bl              #0x11cbbbc  ; Allocate_PixelScrollCacheExtentStub -> _PixelScrollCacheExtent (size=0x10)
    // 0x11cbb20: d0 = 250.000000
    //     0x11cbb20: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cf30] IMM: double(250) from 0x406f400000000000
    //     0x11cbb24: ldr             d0, [x17, #0xf30]
    // 0x11cbb28: StoreField: r0->field_7 = d0
    //     0x11cbb28: stur            d0, [x0, #7]
    // 0x11cbb2c: ldur            x1, [fp, #-8]
    // 0x11cbb30: r2 = Instance_SliverPaintOrder
    //     0x11cbb30: add             x2, PP, #0x15, lsl #12  ; [pp+0x15c00] Obj!SliverPaintOrder@12c4141
    //     0x11cbb34: ldr             x2, [x2, #0xc00]
    // 0x11cbb38: StoreField: r1->field_6f = r0
    //     0x11cbb38: stur            w0, [x1, #0x6f]
    //     0x11cbb3c: ldurb           w16, [x1, #-1]
    //     0x11cbb40: ldurb           w17, [x0, #-1]
    //     0x11cbb44: and             x16, x17, x16, lsr #2
    //     0x11cbb48: tst             x16, HEAP, lsr #32
    //     0x11cbb4c: b.eq            #0x11cbb54
    //     0x11cbb50: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cbb54: StoreField: r1->field_77 = r2
    //     0x11cbb54: stur            w2, [x1, #0x77]
    // 0x11cbb58: ldur            x0, [fp, #-0x18]
    // 0x11cbb5c: StoreField: r1->field_7b = r0
    //     0x11cbb5c: stur            w0, [x1, #0x7b]
    //     0x11cbb60: ldurb           w16, [x1, #-1]
    //     0x11cbb64: ldurb           w17, [x0, #-1]
    //     0x11cbb68: and             x16, x17, x16, lsr #2
    //     0x11cbb6c: tst             x16, HEAP, lsr #32
    //     0x11cbb70: b.eq            #0x11cbb78
    //     0x11cbb74: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cbb78: StoreField: r1->field_53 = rZR
    //     0x11cbb78: stur            xzr, [x1, #0x53]
    // 0x11cbb7c: r0 = _LayoutCacheStorage()
    //     0x11cbb7c: bl              #0xcf05b4  ; Allocate_LayoutCacheStorageStub -> _LayoutCacheStorage (size=0x18)
    // 0x11cbb80: ldur            x1, [fp, #-8]
    // 0x11cbb84: StoreField: r1->field_47 = r0
    //     0x11cbb84: stur            w0, [x1, #0x47]
    //     0x11cbb88: ldurb           w16, [x1, #-1]
    //     0x11cbb8c: ldurb           w17, [x0, #-1]
    //     0x11cbb90: and             x16, x17, x16, lsr #2
    //     0x11cbb94: tst             x16, HEAP, lsr #32
    //     0x11cbb98: b.eq            #0x11cbba0
    //     0x11cbb9c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cbba0: r0 = RenderObject()
    //     0x11cbba0: bl              #0xcf04b0  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x11cbba4: r0 = Null
    //     0x11cbba4: mov             x0, NULL
    // 0x11cbba8: LeaveFrame
    //     0x11cbba8: mov             SP, fp
    //     0x11cbbac: ldp             fp, lr, [SP], #0x10
    // 0x11cbbb0: ret
    //     0x11cbbb0: ret             
    // 0x11cbbb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cbbb4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cbbb8: b               #0x11cba84
  }
  _ getOffsetToReveal(/* No info */) {
    // ** addr: 0x129e1ec, size: 0xb5c
    // 0x129e1ec: EnterFrame
    //     0x129e1ec: stp             fp, lr, [SP, #-0x10]!
    //     0x129e1f0: mov             fp, SP
    // 0x129e1f4: AllocStack(0x98)
    //     0x129e1f4: sub             SP, SP, #0x98
    // 0x129e1f8: SetupParameters(RenderViewportBase<X0 bound ContainerParentDataMixin> this /* r1 => r0, fp-0x8 */, dynamic _ /* r2 => r2, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x68 */)
    //     0x129e1f8: mov             x0, x1
    //     0x129e1fc: stur            x1, [fp, #-8]
    //     0x129e200: stur            x2, [fp, #-0x10]
    //     0x129e204: stur            x3, [fp, #-0x18]
    //     0x129e208: stur            d0, [fp, #-0x68]
    // 0x129e20c: CheckStackOverflow
    //     0x129e20c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129e210: cmp             SP, x16
    //     0x129e214: b.ls            #0x129ecf0
    // 0x129e218: mov             x1, x0
    // 0x129e21c: r0 = axis()
    //     0x129e21c: bl              #0xbc8210  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::axis
    // 0x129e220: mov             x3, x0
    // 0x129e224: ldur            x2, [fp, #-0x10]
    // 0x129e228: stur            x3, [fp, #-0x38]
    // 0x129e22c: r0 = LoadClassIdInstr(r2)
    //     0x129e22c: ldur            x0, [x2, #-1]
    //     0x129e230: ubfx            x0, x0, #0xc, #0x14
    // 0x129e234: r17 = -4688
    //     0x129e234: mov             x17, #-0x1250
    // 0x129e238: add             x16, x0, x17
    // 0x129e23c: cmp             x16, #0xf
    // 0x129e240: r16 = true
    //     0x129e240: add             x16, NULL, #0x20  ; true
    // 0x129e244: r17 = false
    //     0x129e244: add             x17, NULL, #0x30  ; false
    // 0x129e248: csel            x1, x16, x17, ls
    // 0x129e24c: mov             x6, x2
    // 0x129e250: mov             x4, x1
    // 0x129e254: d0 = 0.000000
    //     0x129e254: eor             v0.16b, v0.16b, v0.16b
    // 0x129e258: r5 = Null
    //     0x129e258: mov             x5, NULL
    // 0x129e25c: stur            x6, [fp, #-0x20]
    // 0x129e260: stur            x5, [fp, #-0x28]
    // 0x129e264: stur            x4, [fp, #-0x30]
    // 0x129e268: stur            d0, [fp, #-0x70]
    // 0x129e26c: CheckStackOverflow
    //     0x129e26c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129e270: cmp             SP, x16
    //     0x129e274: b.ls            #0x129ecf8
    // 0x129e278: r0 = LoadClassIdInstr(r6)
    //     0x129e278: ldur            x0, [x6, #-1]
    //     0x129e27c: ubfx            x0, x0, #0xc, #0x14
    // 0x129e280: mov             x1, x6
    // 0x129e284: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x129e284: mov             x17, #0xfc0
    //     0x129e288: movk            x17, #1, lsl #16
    //     0x129e28c: add             lr, x0, x17
    //     0x129e290: ldr             lr, [x21, lr, lsl #3]
    //     0x129e294: blr             lr
    // 0x129e298: r1 = LoadClassIdInstr(r0)
    //     0x129e298: ldur            x1, [x0, #-1]
    //     0x129e29c: ubfx            x1, x1, #0xc, #0x14
    // 0x129e2a0: ldur            x16, [fp, #-8]
    // 0x129e2a4: stp             x16, x0, [SP]
    // 0x129e2a8: mov             x0, x1
    // 0x129e2ac: mov             lr, x0
    // 0x129e2b0: ldr             lr, [x21, lr, lsl #3]
    // 0x129e2b4: blr             lr
    // 0x129e2b8: tbz             w0, #4, #0x129e390
    // 0x129e2bc: ldur            x2, [fp, #-0x20]
    // 0x129e2c0: r0 = LoadClassIdInstr(r2)
    //     0x129e2c0: ldur            x0, [x2, #-1]
    //     0x129e2c4: ubfx            x0, x0, #0xc, #0x14
    // 0x129e2c8: mov             x1, x2
    // 0x129e2cc: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x129e2cc: mov             x17, #0xfc0
    //     0x129e2d0: movk            x17, #1, lsl #16
    //     0x129e2d4: add             lr, x0, x17
    //     0x129e2d8: ldr             lr, [x21, lr, lsl #3]
    //     0x129e2dc: blr             lr
    // 0x129e2e0: mov             x3, x0
    // 0x129e2e4: stur            x3, [fp, #-0x48]
    // 0x129e2e8: cmp             w3, NULL
    // 0x129e2ec: b.eq            #0x129ed00
    // 0x129e2f0: ldur            x2, [fp, #-0x20]
    // 0x129e2f4: r0 = LoadClassIdInstr(r2)
    //     0x129e2f4: ldur            x0, [x2, #-1]
    //     0x129e2f8: ubfx            x0, x0, #0xc, #0x14
    // 0x129e2fc: r17 = -4710
    //     0x129e2fc: mov             x17, #-0x1266
    // 0x129e300: add             x16, x0, x17
    // 0x129e304: cmp             x16, #0x109
    // 0x129e308: b.hi            #0x129e314
    // 0x129e30c: mov             x5, x2
    // 0x129e310: b               #0x129e318
    // 0x129e314: ldur            x5, [fp, #-0x28]
    // 0x129e318: stur            x5, [fp, #-0x40]
    // 0x129e31c: r0 = LoadClassIdInstr(r3)
    //     0x129e31c: ldur            x0, [x3, #-1]
    //     0x129e320: ubfx            x0, x0, #0xc, #0x14
    // 0x129e324: r17 = -4688
    //     0x129e324: mov             x17, #-0x1250
    // 0x129e328: add             x16, x0, x17
    // 0x129e32c: cmp             x16, #0xf
    // 0x129e330: b.hi            #0x129e374
    // 0x129e334: ldur            d0, [fp, #-0x70]
    // 0x129e338: r0 = LoadClassIdInstr(r3)
    //     0x129e338: ldur            x0, [x3, #-1]
    //     0x129e33c: ubfx            x0, x0, #0xc, #0x14
    // 0x129e340: mov             x1, x3
    // 0x129e344: r0 = GDT[cid_x0 + 0x586f]()
    //     0x129e344: mov             x17, #0x586f
    //     0x129e348: add             lr, x0, x17
    //     0x129e34c: ldr             lr, [x21, lr, lsl #3]
    //     0x129e350: blr             lr
    // 0x129e354: cmp             w0, NULL
    // 0x129e358: b.eq            #0x129ed04
    // 0x129e35c: LoadField: d0 = r0->field_7
    //     0x129e35c: ldur            d0, [x0, #7]
    // 0x129e360: ldur            d1, [fp, #-0x70]
    // 0x129e364: fadd            d2, d1, d0
    // 0x129e368: mov             v0.16b, v2.16b
    // 0x129e36c: ldur            x4, [fp, #-0x30]
    // 0x129e370: b               #0x129e37c
    // 0x129e374: d0 = 0.000000
    //     0x129e374: eor             v0.16b, v0.16b, v0.16b
    // 0x129e378: r4 = false
    //     0x129e378: add             x4, NULL, #0x30  ; false
    // 0x129e37c: ldur            x6, [fp, #-0x48]
    // 0x129e380: ldur            x5, [fp, #-0x40]
    // 0x129e384: ldur            x2, [fp, #-0x10]
    // 0x129e388: ldur            x3, [fp, #-0x38]
    // 0x129e38c: b               #0x129e25c
    // 0x129e390: ldur            d1, [fp, #-0x70]
    // 0x129e394: ldur            x2, [fp, #-0x20]
    // 0x129e398: ldur            x3, [fp, #-0x28]
    // 0x129e39c: cmp             w3, NULL
    // 0x129e3a0: b.eq            #0x129e500
    // 0x129e3a4: r0 = LoadClassIdInstr(r3)
    //     0x129e3a4: ldur            x0, [x3, #-1]
    //     0x129e3a8: ubfx            x0, x0, #0xc, #0x14
    // 0x129e3ac: mov             x1, x3
    // 0x129e3b0: r0 = GDT[cid_x0 + 0x10fc0]()
    //     0x129e3b0: mov             x17, #0xfc0
    //     0x129e3b4: movk            x17, #1, lsl #16
    //     0x129e3b8: add             lr, x0, x17
    //     0x129e3bc: ldr             lr, [x21, lr, lsl #3]
    //     0x129e3c0: blr             lr
    // 0x129e3c4: mov             x3, x0
    // 0x129e3c8: stur            x3, [fp, #-0x40]
    // 0x129e3cc: cmp             w3, NULL
    // 0x129e3d0: b.eq            #0x129ed08
    // 0x129e3d4: mov             x0, x3
    // 0x129e3d8: r2 = Null
    //     0x129e3d8: mov             x2, NULL
    // 0x129e3dc: r1 = Null
    //     0x129e3dc: mov             x1, NULL
    // 0x129e3e0: r4 = LoadClassIdInstr(r0)
    //     0x129e3e0: ldur            x4, [x0, #-1]
    //     0x129e3e4: ubfx            x4, x4, #0xc, #0x14
    // 0x129e3e8: r17 = -4688
    //     0x129e3e8: mov             x17, #-0x1250
    // 0x129e3ec: add             x4, x4, x17
    // 0x129e3f0: cmp             x4, #0xf
    // 0x129e3f4: b.ls            #0x129e40c
    // 0x129e3f8: r8 = RenderSliver
    //     0x129e3f8: add             x8, PP, #0x96, lsl #12  ; [pp+0x961a8] Type: RenderSliver
    //     0x129e3fc: ldr             x8, [x8, #0x1a8]
    // 0x129e400: r3 = Null
    //     0x129e400: add             x3, PP, #0x96, lsl #12  ; [pp+0x963b0] Null
    //     0x129e404: ldr             x3, [x3, #0x3b0]
    // 0x129e408: r0 = RenderSliver()
    //     0x129e408: bl              #0xa16a30  ; IsType_RenderSliver_Stub
    // 0x129e40c: ldur            x0, [fp, #-0x40]
    // 0x129e410: LoadField: r3 = r0->field_27
    //     0x129e410: ldur            w3, [x0, #0x27]
    // 0x129e414: DecompressPointer r3
    //     0x129e414: add             x3, x3, HEAP, lsl #32
    // 0x129e418: stur            x3, [fp, #-0x48]
    // 0x129e41c: cmp             w3, NULL
    // 0x129e420: b.eq            #0x129ecb4
    // 0x129e424: ldur            x4, [fp, #-0x38]
    // 0x129e428: mov             x0, x3
    // 0x129e42c: r2 = Null
    //     0x129e42c: mov             x2, NULL
    // 0x129e430: r1 = Null
    //     0x129e430: mov             x1, NULL
    // 0x129e434: r4 = LoadClassIdInstr(r0)
    //     0x129e434: ldur            x4, [x0, #-1]
    //     0x129e438: ubfx            x4, x4, #0xc, #0x14
    // 0x129e43c: cmp             x4, #0xb45
    // 0x129e440: b.eq            #0x129e458
    // 0x129e444: r8 = SliverConstraints
    //     0x129e444: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x129e448: ldr             x8, [x8, #0x3c0]
    // 0x129e44c: r3 = Null
    //     0x129e44c: add             x3, PP, #0x96, lsl #12  ; [pp+0x963c8] Null
    //     0x129e450: ldr             x3, [x3, #0x3c8]
    // 0x129e454: r0 = DefaultTypeTest()
    //     0x129e454: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x129e458: ldur            x0, [fp, #-0x48]
    // 0x129e45c: LoadField: r2 = r0->field_b
    //     0x129e45c: ldur            w2, [x0, #0xb]
    // 0x129e460: DecompressPointer r2
    //     0x129e460: add             x2, x2, HEAP, lsl #32
    // 0x129e464: ldur            x0, [fp, #-0x38]
    // 0x129e468: stur            x2, [fp, #-0x40]
    // 0x129e46c: LoadField: r1 = r0->field_7
    //     0x129e46c: ldur            x1, [x0, #7]
    // 0x129e470: cmp             x1, #0
    // 0x129e474: b.gt            #0x129e488
    // 0x129e478: ldur            x1, [fp, #-0x28]
    // 0x129e47c: r0 = size()
    //     0x129e47c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x129e480: LoadField: d0 = r0->field_7
    //     0x129e480: ldur            d0, [x0, #7]
    // 0x129e484: b               #0x129e494
    // 0x129e488: ldur            x1, [fp, #-0x28]
    // 0x129e48c: r0 = size()
    //     0x129e48c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x129e490: LoadField: d0 = r0->field_f
    //     0x129e490: ldur            d0, [x0, #0xf]
    // 0x129e494: ldur            x3, [fp, #-0x18]
    // 0x129e498: stur            d0, [fp, #-0x78]
    // 0x129e49c: cmp             w3, NULL
    // 0x129e4a0: b.ne            #0x129e4cc
    // 0x129e4a4: ldur            x2, [fp, #-0x10]
    // 0x129e4a8: r0 = LoadClassIdInstr(r2)
    //     0x129e4a8: ldur            x0, [x2, #-1]
    //     0x129e4ac: ubfx            x0, x0, #0xc, #0x14
    // 0x129e4b0: mov             x1, x2
    // 0x129e4b4: r0 = GDT[cid_x0 + 0x107cb]()
    //     0x129e4b4: mov             x17, #0x7cb
    //     0x129e4b8: movk            x17, #1, lsl #16
    //     0x129e4bc: add             lr, x0, x17
    //     0x129e4c0: ldr             lr, [x21, lr, lsl #3]
    //     0x129e4c4: blr             lr
    // 0x129e4c8: b               #0x129e4d0
    // 0x129e4cc: mov             x0, x3
    // 0x129e4d0: ldur            x1, [fp, #-0x10]
    // 0x129e4d4: ldur            x2, [fp, #-0x28]
    // 0x129e4d8: stur            x0, [fp, #-0x48]
    // 0x129e4dc: r0 = getTransformTo()
    //     0x129e4dc: bl              #0x857070  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0x129e4e0: mov             x1, x0
    // 0x129e4e4: ldur            x2, [fp, #-0x48]
    // 0x129e4e8: r0 = transformRect()
    //     0x129e4e8: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x129e4ec: ldur            x6, [fp, #-0x48]
    // 0x129e4f0: mov             x5, x0
    // 0x129e4f4: ldur            d0, [fp, #-0x78]
    // 0x129e4f8: ldur            x4, [fp, #-0x40]
    // 0x129e4fc: b               #0x129e660
    // 0x129e500: ldur            x3, [fp, #-0x18]
    // 0x129e504: ldur            x0, [fp, #-0x30]
    // 0x129e508: tbnz            w0, #4, #0x129ec68
    // 0x129e50c: ldur            x4, [fp, #-0x10]
    // 0x129e510: mov             x0, x4
    // 0x129e514: r2 = Null
    //     0x129e514: mov             x2, NULL
    // 0x129e518: r1 = Null
    //     0x129e518: mov             x1, NULL
    // 0x129e51c: r4 = LoadClassIdInstr(r0)
    //     0x129e51c: ldur            x4, [x0, #-1]
    //     0x129e520: ubfx            x4, x4, #0xc, #0x14
    // 0x129e524: r17 = -4688
    //     0x129e524: mov             x17, #-0x1250
    // 0x129e528: add             x4, x4, x17
    // 0x129e52c: cmp             x4, #0xf
    // 0x129e530: b.ls            #0x129e548
    // 0x129e534: r8 = RenderSliver
    //     0x129e534: add             x8, PP, #0x96, lsl #12  ; [pp+0x961a8] Type: RenderSliver
    //     0x129e538: ldr             x8, [x8, #0x1a8]
    // 0x129e53c: r3 = Null
    //     0x129e53c: add             x3, PP, #0x96, lsl #12  ; [pp+0x963d8] Null
    //     0x129e540: ldr             x3, [x3, #0x3d8]
    // 0x129e544: r0 = RenderSliver()
    //     0x129e544: bl              #0xa16a30  ; IsType_RenderSliver_Stub
    // 0x129e548: ldur            x3, [fp, #-0x10]
    // 0x129e54c: LoadField: r4 = r3->field_27
    //     0x129e54c: ldur            w4, [x3, #0x27]
    // 0x129e550: DecompressPointer r4
    //     0x129e550: add             x4, x4, HEAP, lsl #32
    // 0x129e554: stur            x4, [fp, #-0x28]
    // 0x129e558: cmp             w4, NULL
    // 0x129e55c: b.eq            #0x129ecd0
    // 0x129e560: ldur            x5, [fp, #-0x18]
    // 0x129e564: mov             x0, x4
    // 0x129e568: r2 = Null
    //     0x129e568: mov             x2, NULL
    // 0x129e56c: r1 = Null
    //     0x129e56c: mov             x1, NULL
    // 0x129e570: r4 = LoadClassIdInstr(r0)
    //     0x129e570: ldur            x4, [x0, #-1]
    //     0x129e574: ubfx            x4, x4, #0xc, #0x14
    // 0x129e578: cmp             x4, #0xb45
    // 0x129e57c: b.eq            #0x129e594
    // 0x129e580: r8 = SliverConstraints
    //     0x129e580: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x129e584: ldr             x8, [x8, #0x3c0]
    // 0x129e588: r3 = Null
    //     0x129e588: add             x3, PP, #0x96, lsl #12  ; [pp+0x963e8] Null
    //     0x129e58c: ldr             x3, [x3, #0x3e8]
    // 0x129e590: r0 = DefaultTypeTest()
    //     0x129e590: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x129e594: ldur            x0, [fp, #-0x28]
    // 0x129e598: LoadField: r1 = r0->field_b
    //     0x129e598: ldur            w1, [x0, #0xb]
    // 0x129e59c: DecompressPointer r1
    //     0x129e59c: add             x1, x1, HEAP, lsl #32
    // 0x129e5a0: ldur            x2, [fp, #-0x10]
    // 0x129e5a4: stur            x1, [fp, #-0x30]
    // 0x129e5a8: LoadField: r3 = r2->field_47
    //     0x129e5a8: ldur            w3, [x2, #0x47]
    // 0x129e5ac: DecompressPointer r3
    //     0x129e5ac: add             x3, x3, HEAP, lsl #32
    // 0x129e5b0: cmp             w3, NULL
    // 0x129e5b4: b.eq            #0x129ed0c
    // 0x129e5b8: LoadField: d0 = r3->field_7
    //     0x129e5b8: ldur            d0, [x3, #7]
    // 0x129e5bc: ldur            x3, [fp, #-0x18]
    // 0x129e5c0: stur            d0, [fp, #-0x88]
    // 0x129e5c4: cmp             w3, NULL
    // 0x129e5c8: b.ne            #0x129e64c
    // 0x129e5cc: ldur            x3, [fp, #-0x38]
    // 0x129e5d0: LoadField: r4 = r3->field_7
    //     0x129e5d0: ldur            x4, [x3, #7]
    // 0x129e5d4: cmp             x4, #0
    // 0x129e5d8: b.gt            #0x129e614
    // 0x129e5dc: d1 = 0.000000
    //     0x129e5dc: eor             v1.16b, v1.16b, v1.16b
    // 0x129e5e0: LoadField: d2 = r0->field_33
    //     0x129e5e0: ldur            d2, [x0, #0x33]
    // 0x129e5e4: fadd            d3, d0, d1
    // 0x129e5e8: stur            d3, [fp, #-0x80]
    // 0x129e5ec: fadd            d4, d2, d1
    // 0x129e5f0: stur            d4, [fp, #-0x78]
    // 0x129e5f4: r0 = Rect()
    //     0x129e5f4: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x129e5f8: StoreField: r0->field_7 = rZR
    //     0x129e5f8: stur            xzr, [x0, #7]
    // 0x129e5fc: StoreField: r0->field_f = rZR
    //     0x129e5fc: stur            xzr, [x0, #0xf]
    // 0x129e600: ldur            d0, [fp, #-0x80]
    // 0x129e604: ArrayStore: r0[0] = d0  ; List_8
    //     0x129e604: stur            d0, [x0, #0x17]
    // 0x129e608: ldur            d0, [fp, #-0x78]
    // 0x129e60c: StoreField: r0->field_1f = d0
    //     0x129e60c: stur            d0, [x0, #0x1f]
    // 0x129e610: b               #0x129e650
    // 0x129e614: d1 = 0.000000
    //     0x129e614: eor             v1.16b, v1.16b, v1.16b
    // 0x129e618: LoadField: d2 = r0->field_33
    //     0x129e618: ldur            d2, [x0, #0x33]
    // 0x129e61c: fadd            d3, d2, d1
    // 0x129e620: stur            d3, [fp, #-0x80]
    // 0x129e624: fadd            d2, d0, d1
    // 0x129e628: stur            d2, [fp, #-0x78]
    // 0x129e62c: r0 = Rect()
    //     0x129e62c: bl              #0x81cbfc  ; AllocateRectStub -> Rect (size=0x28)
    // 0x129e630: StoreField: r0->field_7 = rZR
    //     0x129e630: stur            xzr, [x0, #7]
    // 0x129e634: StoreField: r0->field_f = rZR
    //     0x129e634: stur            xzr, [x0, #0xf]
    // 0x129e638: ldur            d0, [fp, #-0x80]
    // 0x129e63c: ArrayStore: r0[0] = d0  ; List_8
    //     0x129e63c: stur            d0, [x0, #0x17]
    // 0x129e640: ldur            d0, [fp, #-0x78]
    // 0x129e644: StoreField: r0->field_1f = d0
    //     0x129e644: stur            d0, [x0, #0x1f]
    // 0x129e648: b               #0x129e650
    // 0x129e64c: mov             x0, x3
    // 0x129e650: mov             x6, x0
    // 0x129e654: mov             x5, x0
    // 0x129e658: ldur            d0, [fp, #-0x88]
    // 0x129e65c: ldur            x4, [fp, #-0x30]
    // 0x129e660: ldur            x3, [fp, #-8]
    // 0x129e664: ldur            x0, [fp, #-0x20]
    // 0x129e668: stur            x6, [fp, #-0x28]
    // 0x129e66c: stur            x5, [fp, #-0x30]
    // 0x129e670: stur            x4, [fp, #-0x40]
    // 0x129e674: stur            d0, [fp, #-0x78]
    // 0x129e678: r2 = Null
    //     0x129e678: mov             x2, NULL
    // 0x129e67c: r1 = Null
    //     0x129e67c: mov             x1, NULL
    // 0x129e680: r4 = LoadClassIdInstr(r0)
    //     0x129e680: ldur            x4, [x0, #-1]
    //     0x129e684: ubfx            x4, x4, #0xc, #0x14
    // 0x129e688: r17 = -4688
    //     0x129e688: mov             x17, #-0x1250
    // 0x129e68c: add             x4, x4, x17
    // 0x129e690: cmp             x4, #0xf
    // 0x129e694: b.ls            #0x129e6ac
    // 0x129e698: r8 = RenderSliver
    //     0x129e698: add             x8, PP, #0x96, lsl #12  ; [pp+0x961a8] Type: RenderSliver
    //     0x129e69c: ldr             x8, [x8, #0x1a8]
    // 0x129e6a0: r3 = Null
    //     0x129e6a0: add             x3, PP, #0x96, lsl #12  ; [pp+0x963f8] Null
    //     0x129e6a4: ldr             x3, [x3, #0x3f8]
    // 0x129e6a8: r0 = RenderSliver()
    //     0x129e6a8: bl              #0xa16a30  ; IsType_RenderSliver_Stub
    // 0x129e6ac: ldur            x0, [fp, #-8]
    // 0x129e6b0: LoadField: r1 = r0->field_63
    //     0x129e6b0: ldur            w1, [x0, #0x63]
    // 0x129e6b4: DecompressPointer r1
    //     0x129e6b4: add             x1, x1, HEAP, lsl #32
    // 0x129e6b8: ldur            x2, [fp, #-0x40]
    // 0x129e6bc: r0 = applyGrowthDirectionToAxisDirection()
    //     0x129e6bc: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x129e6c0: LoadField: r1 = r0->field_7
    //     0x129e6c0: ldur            x1, [x0, #7]
    // 0x129e6c4: cmp             x1, #1
    // 0x129e6c8: b.gt            #0x129e6f8
    // 0x129e6cc: cmp             x1, #0
    // 0x129e6d0: b.gt            #0x129e6e8
    // 0x129e6d4: ldur            x2, [fp, #-0x30]
    // 0x129e6d8: ldur            d0, [fp, #-0x78]
    // 0x129e6dc: LoadField: d1 = r2->field_1f
    //     0x129e6dc: ldur            d1, [x2, #0x1f]
    // 0x129e6e0: fsub            d2, d0, d1
    // 0x129e6e4: b               #0x129e71c
    // 0x129e6e8: ldur            x2, [fp, #-0x30]
    // 0x129e6ec: LoadField: d0 = r2->field_7
    //     0x129e6ec: ldur            d0, [x2, #7]
    // 0x129e6f0: mov             v2.16b, v0.16b
    // 0x129e6f4: b               #0x129e71c
    // 0x129e6f8: ldur            x2, [fp, #-0x30]
    // 0x129e6fc: ldur            d0, [fp, #-0x78]
    // 0x129e700: cmp             x1, #2
    // 0x129e704: b.gt            #0x129e714
    // 0x129e708: LoadField: d0 = r2->field_f
    //     0x129e708: ldur            d0, [x2, #0xf]
    // 0x129e70c: mov             v2.16b, v0.16b
    // 0x129e710: b               #0x129e71c
    // 0x129e714: ArrayLoad: d1 = r2[0]  ; List_8
    //     0x129e714: ldur            d1, [x2, #0x17]
    // 0x129e718: fsub            d2, d0, d1
    // 0x129e71c: ldur            d1, [fp, #-0x70]
    // 0x129e720: ldur            x1, [fp, #-0x20]
    // 0x129e724: d0 = 0.000000
    //     0x129e724: eor             v0.16b, v0.16b, v0.16b
    // 0x129e728: fadd            d3, d1, d2
    // 0x129e72c: stur            d3, [fp, #-0x78]
    // 0x129e730: LoadField: r0 = r1->field_47
    //     0x129e730: ldur            w0, [x1, #0x47]
    // 0x129e734: DecompressPointer r0
    //     0x129e734: add             x0, x0, HEAP, lsl #32
    // 0x129e738: cmp             w0, NULL
    // 0x129e73c: b.eq            #0x129ed10
    // 0x129e740: fcmp            d0, d0
    // 0x129e744: b.le            #0x129e760
    // 0x129e748: fcmp            d3, d0
    // 0x129e74c: r16 = true
    //     0x129e74c: add             x16, NULL, #0x20  ; true
    // 0x129e750: r17 = false
    //     0x129e750: add             x17, NULL, #0x30  ; false
    // 0x129e754: csel            x0, x16, x17, ge
    // 0x129e758: mov             x4, x0
    // 0x129e75c: b               #0x129e764
    // 0x129e760: r4 = false
    //     0x129e760: add             x4, NULL, #0x30  ; false
    // 0x129e764: ldur            x3, [fp, #-8]
    // 0x129e768: stur            x4, [fp, #-0x58]
    // 0x129e76c: r5 = LoadClassIdInstr(r3)
    //     0x129e76c: ldur            x5, [x3, #-1]
    //     0x129e770: ubfx            x5, x5, #0xc, #0x14
    // 0x129e774: stur            x5, [fp, #-0x50]
    // 0x129e778: r17 = 4838
    //     0x129e778: mov             x17, #0x12e6
    // 0x129e77c: cmp             x5, x17
    // 0x129e780: b.ne            #0x129e8a0
    // 0x129e784: LoadField: r0 = r3->field_5b
    //     0x129e784: ldur            w0, [x3, #0x5b]
    // 0x129e788: DecompressPointer r0
    //     0x129e788: add             x0, x0, HEAP, lsl #32
    // 0x129e78c: LoadField: r6 = r3->field_4f
    //     0x129e78c: ldur            w6, [x3, #0x4f]
    // 0x129e790: DecompressPointer r6
    //     0x129e790: add             x6, x6, HEAP, lsl #32
    // 0x129e794: stur            x6, [fp, #-0x48]
    // 0x129e798: mov             x7, x0
    // 0x129e79c: d1 = 0.000000
    //     0x129e79c: eor             v1.16b, v1.16b, v1.16b
    // 0x129e7a0: stur            x7, [fp, #-0x40]
    // 0x129e7a4: stur            d1, [fp, #-0x70]
    // 0x129e7a8: CheckStackOverflow
    //     0x129e7a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129e7ac: cmp             SP, x16
    //     0x129e7b0: b.ls            #0x129ed14
    // 0x129e7b4: r0 = LoadClassIdInstr(r7)
    //     0x129e7b4: ldur            x0, [x7, #-1]
    //     0x129e7b8: ubfx            x0, x0, #0xc, #0x14
    // 0x129e7bc: stp             x1, x7, [SP]
    // 0x129e7c0: mov             lr, x0
    // 0x129e7c4: ldr             lr, [x21, lr, lsl #3]
    // 0x129e7c8: blr             lr
    // 0x129e7cc: tbz             w0, #4, #0x129e88c
    // 0x129e7d0: ldur            d0, [fp, #-0x70]
    // 0x129e7d4: ldur            x0, [fp, #-0x40]
    // 0x129e7d8: cmp             w0, NULL
    // 0x129e7dc: b.eq            #0x129ed1c
    // 0x129e7e0: LoadField: r1 = r0->field_47
    //     0x129e7e0: ldur            w1, [x0, #0x47]
    // 0x129e7e4: DecompressPointer r1
    //     0x129e7e4: add             x1, x1, HEAP, lsl #32
    // 0x129e7e8: cmp             w1, NULL
    // 0x129e7ec: b.eq            #0x129ed20
    // 0x129e7f0: LoadField: d1 = r1->field_7
    //     0x129e7f0: ldur            d1, [x1, #7]
    // 0x129e7f4: fadd            d2, d0, d1
    // 0x129e7f8: stur            d2, [fp, #-0x80]
    // 0x129e7fc: LoadField: r3 = r0->field_7
    //     0x129e7fc: ldur            w3, [x0, #7]
    // 0x129e800: DecompressPointer r3
    //     0x129e800: add             x3, x3, HEAP, lsl #32
    // 0x129e804: stur            x3, [fp, #-0x60]
    // 0x129e808: cmp             w3, NULL
    // 0x129e80c: b.eq            #0x129ed24
    // 0x129e810: mov             x0, x3
    // 0x129e814: ldur            x2, [fp, #-0x48]
    // 0x129e818: r1 = Null
    //     0x129e818: mov             x1, NULL
    // 0x129e81c: cmp             w2, NULL
    // 0x129e820: b.eq            #0x129e844
    // 0x129e824: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x129e824: ldur            w4, [x2, #0x17]
    // 0x129e828: DecompressPointer r4
    //     0x129e828: add             x4, x4, HEAP, lsl #32
    // 0x129e82c: r8 = X0 bound ContainerParentDataMixin
    //     0x129e82c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x129e830: ldr             x8, [x8, #0x218]
    // 0x129e834: LoadField: r9 = r4->field_7
    //     0x129e834: ldur            x9, [x4, #7]
    // 0x129e838: r3 = Null
    //     0x129e838: add             x3, PP, #0x96, lsl #12  ; [pp+0x96408] Null
    //     0x129e83c: ldr             x3, [x3, #0x408]
    // 0x129e840: blr             x9
    // 0x129e844: ldur            x1, [fp, #-0x60]
    // 0x129e848: r0 = LoadClassIdInstr(r1)
    //     0x129e848: ldur            x0, [x1, #-1]
    //     0x129e84c: ubfx            x0, x0, #0xc, #0x14
    // 0x129e850: r0 = GDT[cid_x0 + 0xbf3a]()
    //     0x129e850: mov             x17, #0xbf3a
    //     0x129e854: add             lr, x0, x17
    //     0x129e858: ldr             lr, [x21, lr, lsl #3]
    //     0x129e85c: blr             lr
    // 0x129e860: ldur            d1, [fp, #-0x80]
    // 0x129e864: mov             x7, x0
    // 0x129e868: ldur            x3, [fp, #-8]
    // 0x129e86c: ldur            x1, [fp, #-0x20]
    // 0x129e870: ldur            x2, [fp, #-0x30]
    // 0x129e874: ldur            d3, [fp, #-0x78]
    // 0x129e878: ldur            x4, [fp, #-0x58]
    // 0x129e87c: ldur            x5, [fp, #-0x50]
    // 0x129e880: ldur            x6, [fp, #-0x48]
    // 0x129e884: d0 = 0.000000
    //     0x129e884: eor             v0.16b, v0.16b, v0.16b
    // 0x129e888: b               #0x129e7a0
    // 0x129e88c: ldur            d1, [fp, #-0x78]
    // 0x129e890: ldur            d0, [fp, #-0x70]
    // 0x129e894: fadd            d2, d0, d1
    // 0x129e898: mov             v0.16b, v2.16b
    // 0x129e89c: b               #0x129e8c4
    // 0x129e8a0: mov             v1.16b, v3.16b
    // 0x129e8a4: r0 = LoadClassIdInstr(r3)
    //     0x129e8a4: ldur            x0, [x3, #-1]
    //     0x129e8a8: ubfx            x0, x0, #0xc, #0x14
    // 0x129e8ac: mov             x1, x3
    // 0x129e8b0: ldur            x2, [fp, #-0x20]
    // 0x129e8b4: mov             v0.16b, v1.16b
    // 0x129e8b8: r0 = GDT[cid_x0 + 0xe8d]()
    //     0x129e8b8: add             lr, x0, #0xe8d
    //     0x129e8bc: ldr             lr, [x21, lr, lsl #3]
    //     0x129e8c0: blr             lr
    // 0x129e8c4: ldur            x0, [fp, #-0x50]
    // 0x129e8c8: ldur            x1, [fp, #-0x10]
    // 0x129e8cc: ldur            x2, [fp, #-8]
    // 0x129e8d0: stur            d0, [fp, #-0x70]
    // 0x129e8d4: r0 = getTransformTo()
    //     0x129e8d4: bl              #0x857070  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0x129e8d8: mov             x1, x0
    // 0x129e8dc: ldur            x2, [fp, #-0x28]
    // 0x129e8e0: r0 = transformRect()
    //     0x129e8e0: bl              #0x863e58  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0x129e8e4: mov             x1, x0
    // 0x129e8e8: ldur            x0, [fp, #-0x50]
    // 0x129e8ec: stur            x1, [fp, #-0x40]
    // 0x129e8f0: r17 = 4838
    //     0x129e8f0: mov             x17, #0x12e6
    // 0x129e8f4: cmp             x0, x17
    // 0x129e8f8: b.ne            #0x129e9e4
    // 0x129e8fc: ldur            x2, [fp, #-8]
    // 0x129e900: LoadField: r0 = r2->field_5b
    //     0x129e900: ldur            w0, [x2, #0x5b]
    // 0x129e904: DecompressPointer r0
    //     0x129e904: add             x0, x0, HEAP, lsl #32
    // 0x129e908: LoadField: r3 = r2->field_4f
    //     0x129e908: ldur            w3, [x2, #0x4f]
    // 0x129e90c: DecompressPointer r3
    //     0x129e90c: add             x3, x3, HEAP, lsl #32
    // 0x129e910: stur            x3, [fp, #-0x28]
    // 0x129e914: mov             x4, x0
    // 0x129e918: stur            x4, [fp, #-0x10]
    // 0x129e91c: CheckStackOverflow
    //     0x129e91c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x129e920: cmp             SP, x16
    //     0x129e924: b.ls            #0x129ed28
    // 0x129e928: r0 = LoadClassIdInstr(r4)
    //     0x129e928: ldur            x0, [x4, #-1]
    //     0x129e92c: ubfx            x0, x0, #0xc, #0x14
    // 0x129e930: ldur            x16, [fp, #-0x20]
    // 0x129e934: stp             x16, x4, [SP]
    // 0x129e938: mov             lr, x0
    // 0x129e93c: ldr             lr, [x21, lr, lsl #3]
    // 0x129e940: blr             lr
    // 0x129e944: tbz             w0, #4, #0x129e9dc
    // 0x129e948: ldur            x0, [fp, #-0x10]
    // 0x129e94c: cmp             w0, NULL
    // 0x129e950: b.eq            #0x129ed30
    // 0x129e954: LoadField: r1 = r0->field_47
    //     0x129e954: ldur            w1, [x0, #0x47]
    // 0x129e958: DecompressPointer r1
    //     0x129e958: add             x1, x1, HEAP, lsl #32
    // 0x129e95c: cmp             w1, NULL
    // 0x129e960: b.eq            #0x129ed34
    // 0x129e964: LoadField: r3 = r0->field_7
    //     0x129e964: ldur            w3, [x0, #7]
    // 0x129e968: DecompressPointer r3
    //     0x129e968: add             x3, x3, HEAP, lsl #32
    // 0x129e96c: stur            x3, [fp, #-0x48]
    // 0x129e970: cmp             w3, NULL
    // 0x129e974: b.eq            #0x129ed38
    // 0x129e978: mov             x0, x3
    // 0x129e97c: ldur            x2, [fp, #-0x28]
    // 0x129e980: r1 = Null
    //     0x129e980: mov             x1, NULL
    // 0x129e984: cmp             w2, NULL
    // 0x129e988: b.eq            #0x129e9ac
    // 0x129e98c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x129e98c: ldur            w4, [x2, #0x17]
    // 0x129e990: DecompressPointer r4
    //     0x129e990: add             x4, x4, HEAP, lsl #32
    // 0x129e994: r8 = X0 bound ContainerParentDataMixin
    //     0x129e994: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x129e998: ldr             x8, [x8, #0x218]
    // 0x129e99c: LoadField: r9 = r4->field_7
    //     0x129e99c: ldur            x9, [x4, #7]
    // 0x129e9a0: r3 = Null
    //     0x129e9a0: add             x3, PP, #0x96, lsl #12  ; [pp+0x96418] Null
    //     0x129e9a4: ldr             x3, [x3, #0x418]
    // 0x129e9a8: blr             x9
    // 0x129e9ac: ldur            x1, [fp, #-0x48]
    // 0x129e9b0: r0 = LoadClassIdInstr(r1)
    //     0x129e9b0: ldur            x0, [x1, #-1]
    //     0x129e9b4: ubfx            x0, x0, #0xc, #0x14
    // 0x129e9b8: r0 = GDT[cid_x0 + 0xbf3a]()
    //     0x129e9b8: mov             x17, #0xbf3a
    //     0x129e9bc: add             lr, x0, x17
    //     0x129e9c0: ldr             lr, [x21, lr, lsl #3]
    //     0x129e9c4: blr             lr
    // 0x129e9c8: mov             x4, x0
    // 0x129e9cc: ldur            x2, [fp, #-8]
    // 0x129e9d0: ldur            x1, [fp, #-0x40]
    // 0x129e9d4: ldur            x3, [fp, #-0x28]
    // 0x129e9d8: b               #0x129e918
    // 0x129e9dc: d0 = 0.000000
    //     0x129e9dc: eor             v0.16b, v0.16b, v0.16b
    // 0x129e9e0: b               #0x129ea04
    // 0x129e9e4: ldur            x3, [fp, #-8]
    // 0x129e9e8: r0 = LoadClassIdInstr(r3)
    //     0x129e9e8: ldur            x0, [x3, #-1]
    //     0x129e9ec: ubfx            x0, x0, #0xc, #0x14
    // 0x129e9f0: mov             x1, x3
    // 0x129e9f4: ldur            x2, [fp, #-0x20]
    // 0x129e9f8: r0 = GDT[cid_x0 + 0xe46]()
    //     0x129e9f8: add             lr, x0, #0xe46
    //     0x129e9fc: ldr             lr, [x21, lr, lsl #3]
    //     0x129ea00: blr             lr
    // 0x129ea04: ldur            x1, [fp, #-0x20]
    // 0x129ea08: stur            d0, [fp, #-0x78]
    // 0x129ea0c: r0 = constraints()
    //     0x129ea0c: bl              #0xccea28  ; [package:flutter/src/rendering/sliver.dart] RenderSliver::constraints
    // 0x129ea10: LoadField: r1 = r0->field_b
    //     0x129ea10: ldur            w1, [x0, #0xb]
    // 0x129ea14: DecompressPointer r1
    //     0x129ea14: add             x1, x1, HEAP, lsl #32
    // 0x129ea18: LoadField: r0 = r1->field_7
    //     0x129ea18: ldur            x0, [x1, #7]
    // 0x129ea1c: cmp             x0, #0
    // 0x129ea20: b.gt            #0x129ea90
    // 0x129ea24: ldur            x0, [fp, #-0x58]
    // 0x129ea28: tbnz            w0, #4, #0x129ea68
    // 0x129ea2c: ldur            d1, [fp, #-0x68]
    // 0x129ea30: d0 = 0.000000
    //     0x129ea30: eor             v0.16b, v0.16b, v0.16b
    // 0x129ea34: fcmp            d0, d1
    // 0x129ea38: b.lt            #0x129ea60
    // 0x129ea3c: ldur            x1, [fp, #-0x40]
    // 0x129ea40: r0 = RevealedOffset()
    //     0x129ea40: bl              #0x86de3c  ; AllocateRevealedOffsetStub -> RevealedOffset (size=0x14)
    // 0x129ea44: d0 = inf
    //     0x129ea44: ldr             d0, [PP, #0x2c00]  ; [pp+0x2c00] IMM: double(inf) from 0x7ff0000000000000
    // 0x129ea48: StoreField: r0->field_7 = d0
    //     0x129ea48: stur            d0, [x0, #7]
    // 0x129ea4c: ldur            x1, [fp, #-0x40]
    // 0x129ea50: StoreField: r0->field_f = r1
    //     0x129ea50: stur            w1, [x0, #0xf]
    // 0x129ea54: LeaveFrame
    //     0x129ea54: mov             SP, fp
    //     0x129ea58: ldp             fp, lr, [SP], #0x10
    // 0x129ea5c: ret
    //     0x129ea5c: ret             
    // 0x129ea60: ldur            x1, [fp, #-0x40]
    // 0x129ea64: b               #0x129ea74
    // 0x129ea68: ldur            d1, [fp, #-0x68]
    // 0x129ea6c: ldur            x1, [fp, #-0x40]
    // 0x129ea70: d0 = 0.000000
    //     0x129ea70: eor             v0.16b, v0.16b, v0.16b
    // 0x129ea74: ldur            d3, [fp, #-0x70]
    // 0x129ea78: ldur            d2, [fp, #-0x78]
    // 0x129ea7c: fsub            d4, d3, d2
    // 0x129ea80: mov             v3.16b, v4.16b
    // 0x129ea84: ldur            x0, [fp, #-0x38]
    // 0x129ea88: mov             x2, x1
    // 0x129ea8c: b               #0x129eb20
    // 0x129ea90: ldur            d1, [fp, #-0x68]
    // 0x129ea94: ldur            x0, [fp, #-0x58]
    // 0x129ea98: ldur            x1, [fp, #-0x40]
    // 0x129ea9c: ldur            d3, [fp, #-0x70]
    // 0x129eaa0: ldur            d2, [fp, #-0x78]
    // 0x129eaa4: d0 = 0.000000
    //     0x129eaa4: eor             v0.16b, v0.16b, v0.16b
    // 0x129eaa8: tbnz            w0, #4, #0x129eae0
    // 0x129eaac: d4 = 1.000000
    //     0x129eaac: fmov            d4, #1.00000000
    // 0x129eab0: fcmp            d1, d4
    // 0x129eab4: b.lt            #0x129ead8
    // 0x129eab8: r0 = RevealedOffset()
    //     0x129eab8: bl              #0x86de3c  ; AllocateRevealedOffsetStub -> RevealedOffset (size=0x14)
    // 0x129eabc: d0 = -inf
    //     0x129eabc: ldr             d0, [PP, #0x5780]  ; [pp+0x5780] IMM: double(-inf) from 0xfff0000000000000
    // 0x129eac0: StoreField: r0->field_7 = d0
    //     0x129eac0: stur            d0, [x0, #7]
    // 0x129eac4: ldur            x2, [fp, #-0x40]
    // 0x129eac8: StoreField: r0->field_f = r2
    //     0x129eac8: stur            w2, [x0, #0xf]
    // 0x129eacc: LeaveFrame
    //     0x129eacc: mov             SP, fp
    //     0x129ead0: ldp             fp, lr, [SP], #0x10
    // 0x129ead4: ret
    //     0x129ead4: ret             
    // 0x129ead8: mov             x2, x1
    // 0x129eadc: b               #0x129eae4
    // 0x129eae0: mov             x2, x1
    // 0x129eae4: ldur            x0, [fp, #-0x38]
    // 0x129eae8: LoadField: r1 = r0->field_7
    //     0x129eae8: ldur            x1, [x0, #7]
    // 0x129eaec: cmp             x1, #0
    // 0x129eaf0: b.gt            #0x129eb08
    // 0x129eaf4: ArrayLoad: d4 = r2[0]  ; List_8
    //     0x129eaf4: ldur            d4, [x2, #0x17]
    // 0x129eaf8: LoadField: d5 = r2->field_7
    //     0x129eaf8: ldur            d5, [x2, #7]
    // 0x129eafc: fsub            d6, d4, d5
    // 0x129eb00: mov             v4.16b, v6.16b
    // 0x129eb04: b               #0x129eb18
    // 0x129eb08: LoadField: d4 = r2->field_1f
    //     0x129eb08: ldur            d4, [x2, #0x1f]
    // 0x129eb0c: LoadField: d5 = r2->field_f
    //     0x129eb0c: ldur            d5, [x2, #0xf]
    // 0x129eb10: fsub            d6, d4, d5
    // 0x129eb14: mov             v4.16b, v6.16b
    // 0x129eb18: fsub            d5, d3, d4
    // 0x129eb1c: mov             v3.16b, v5.16b
    // 0x129eb20: stur            d3, [fp, #-0x70]
    // 0x129eb24: LoadField: r1 = r0->field_7
    //     0x129eb24: ldur            x1, [x0, #7]
    // 0x129eb28: cmp             x1, #0
    // 0x129eb2c: b.gt            #0x129eb64
    // 0x129eb30: ldur            x0, [fp, #-0x30]
    // 0x129eb34: ldur            x1, [fp, #-8]
    // 0x129eb38: r0 = size()
    //     0x129eb38: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x129eb3c: LoadField: d0 = r0->field_7
    //     0x129eb3c: ldur            d0, [x0, #7]
    // 0x129eb40: ldur            d1, [fp, #-0x78]
    // 0x129eb44: fsub            d2, d0, d1
    // 0x129eb48: ldur            x0, [fp, #-0x30]
    // 0x129eb4c: ArrayLoad: d0 = r0[0]  ; List_8
    //     0x129eb4c: ldur            d0, [x0, #0x17]
    // 0x129eb50: LoadField: d1 = r0->field_7
    //     0x129eb50: ldur            d1, [x0, #7]
    // 0x129eb54: fsub            d3, d0, d1
    // 0x129eb58: fsub            d0, d2, d3
    // 0x129eb5c: mov             v2.16b, v0.16b
    // 0x129eb60: b               #0x129eb98
    // 0x129eb64: ldur            x0, [fp, #-0x30]
    // 0x129eb68: mov             v1.16b, v2.16b
    // 0x129eb6c: ldur            x1, [fp, #-8]
    // 0x129eb70: r0 = size()
    //     0x129eb70: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x129eb74: LoadField: d0 = r0->field_f
    //     0x129eb74: ldur            d0, [x0, #0xf]
    // 0x129eb78: ldur            d1, [fp, #-0x78]
    // 0x129eb7c: fsub            d2, d0, d1
    // 0x129eb80: ldur            x0, [fp, #-0x30]
    // 0x129eb84: LoadField: d0 = r0->field_1f
    //     0x129eb84: ldur            d0, [x0, #0x1f]
    // 0x129eb88: LoadField: d1 = r0->field_f
    //     0x129eb88: ldur            d1, [x0, #0xf]
    // 0x129eb8c: fsub            d3, d0, d1
    // 0x129eb90: fsub            d0, d2, d3
    // 0x129eb94: mov             v2.16b, v0.16b
    // 0x129eb98: ldur            x0, [fp, #-8]
    // 0x129eb9c: ldur            d0, [fp, #-0x68]
    // 0x129eba0: ldur            d1, [fp, #-0x70]
    // 0x129eba4: fmul            d3, d2, d0
    // 0x129eba8: fsub            d2, d1, d3
    // 0x129ebac: stur            d2, [fp, #-0x68]
    // 0x129ebb0: LoadField: r1 = r0->field_6b
    //     0x129ebb0: ldur            w1, [x0, #0x6b]
    // 0x129ebb4: DecompressPointer r1
    //     0x129ebb4: add             x1, x1, HEAP, lsl #32
    // 0x129ebb8: LoadField: r2 = r1->field_3f
    //     0x129ebb8: ldur            w2, [x1, #0x3f]
    // 0x129ebbc: DecompressPointer r2
    //     0x129ebbc: add             x2, x2, HEAP, lsl #32
    // 0x129ebc0: cmp             w2, NULL
    // 0x129ebc4: b.eq            #0x129ed3c
    // 0x129ebc8: LoadField: d0 = r2->field_7
    //     0x129ebc8: ldur            d0, [x2, #7]
    // 0x129ebcc: fsub            d1, d0, d2
    // 0x129ebd0: LoadField: r1 = r0->field_63
    //     0x129ebd0: ldur            w1, [x0, #0x63]
    // 0x129ebd4: DecompressPointer r1
    //     0x129ebd4: add             x1, x1, HEAP, lsl #32
    // 0x129ebd8: LoadField: r0 = r1->field_7
    //     0x129ebd8: ldur            x0, [x1, #7]
    // 0x129ebdc: cmp             x0, #1
    // 0x129ebe0: b.gt            #0x129ec18
    // 0x129ebe4: cmp             x0, #0
    // 0x129ebe8: b.gt            #0x129ec04
    // 0x129ebec: fneg            d0, d1
    // 0x129ebf0: ldur            x1, [fp, #-0x40]
    // 0x129ebf4: mov             v1.16b, v0.16b
    // 0x129ebf8: d0 = 0.000000
    //     0x129ebf8: eor             v0.16b, v0.16b, v0.16b
    // 0x129ebfc: r0 = translate()
    //     0x129ebfc: bl              #0xb6c7ac  ; [dart:ui] Rect::translate
    // 0x129ec00: b               #0x129ec40
    // 0x129ec04: ldur            x1, [fp, #-0x40]
    // 0x129ec08: mov             v0.16b, v1.16b
    // 0x129ec0c: d1 = 0.000000
    //     0x129ec0c: eor             v1.16b, v1.16b, v1.16b
    // 0x129ec10: r0 = translate()
    //     0x129ec10: bl              #0xb6c7ac  ; [dart:ui] Rect::translate
    // 0x129ec14: b               #0x129ec40
    // 0x129ec18: cmp             x0, #2
    // 0x129ec1c: b.gt            #0x129ec30
    // 0x129ec20: ldur            x1, [fp, #-0x40]
    // 0x129ec24: d0 = 0.000000
    //     0x129ec24: eor             v0.16b, v0.16b, v0.16b
    // 0x129ec28: r0 = translate()
    //     0x129ec28: bl              #0xb6c7ac  ; [dart:ui] Rect::translate
    // 0x129ec2c: b               #0x129ec40
    // 0x129ec30: fneg            d0, d1
    // 0x129ec34: ldur            x1, [fp, #-0x40]
    // 0x129ec38: d1 = 0.000000
    //     0x129ec38: eor             v1.16b, v1.16b, v1.16b
    // 0x129ec3c: r0 = translate()
    //     0x129ec3c: bl              #0xb6c7ac  ; [dart:ui] Rect::translate
    // 0x129ec40: ldur            d0, [fp, #-0x68]
    // 0x129ec44: stur            x0, [fp, #-0x10]
    // 0x129ec48: r0 = RevealedOffset()
    //     0x129ec48: bl              #0x86de3c  ; AllocateRevealedOffsetStub -> RevealedOffset (size=0x14)
    // 0x129ec4c: ldur            d0, [fp, #-0x68]
    // 0x129ec50: StoreField: r0->field_7 = d0
    //     0x129ec50: stur            d0, [x0, #7]
    // 0x129ec54: ldur            x1, [fp, #-0x10]
    // 0x129ec58: StoreField: r0->field_f = r1
    //     0x129ec58: stur            w1, [x0, #0xf]
    // 0x129ec5c: LeaveFrame
    //     0x129ec5c: mov             SP, fp
    //     0x129ec60: ldp             fp, lr, [SP], #0x10
    // 0x129ec64: ret
    //     0x129ec64: ret             
    // 0x129ec68: ldur            x0, [fp, #-8]
    // 0x129ec6c: LoadField: r1 = r0->field_6b
    //     0x129ec6c: ldur            w1, [x0, #0x6b]
    // 0x129ec70: DecompressPointer r1
    //     0x129ec70: add             x1, x1, HEAP, lsl #32
    // 0x129ec74: LoadField: r0 = r1->field_3f
    //     0x129ec74: ldur            w0, [x1, #0x3f]
    // 0x129ec78: DecompressPointer r0
    //     0x129ec78: add             x0, x0, HEAP, lsl #32
    // 0x129ec7c: cmp             w0, NULL
    // 0x129ec80: b.eq            #0x129ed40
    // 0x129ec84: cmp             w3, NULL
    // 0x129ec88: b.eq            #0x129ed44
    // 0x129ec8c: LoadField: d0 = r0->field_7
    //     0x129ec8c: ldur            d0, [x0, #7]
    // 0x129ec90: stur            d0, [fp, #-0x68]
    // 0x129ec94: r0 = RevealedOffset()
    //     0x129ec94: bl              #0x86de3c  ; AllocateRevealedOffsetStub -> RevealedOffset (size=0x14)
    // 0x129ec98: ldur            d0, [fp, #-0x68]
    // 0x129ec9c: StoreField: r0->field_7 = d0
    //     0x129ec9c: stur            d0, [x0, #7]
    // 0x129eca0: ldur            x1, [fp, #-0x18]
    // 0x129eca4: StoreField: r0->field_f = r1
    //     0x129eca4: stur            w1, [x0, #0xf]
    // 0x129eca8: LeaveFrame
    //     0x129eca8: mov             SP, fp
    //     0x129ecac: ldp             fp, lr, [SP], #0x10
    // 0x129ecb0: ret
    //     0x129ecb0: ret             
    // 0x129ecb4: r0 = StateError()
    //     0x129ecb4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x129ecb8: mov             x1, x0
    // 0x129ecbc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x129ecbc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x129ecc0: StoreField: r1->field_b = r0
    //     0x129ecc0: stur            w0, [x1, #0xb]
    // 0x129ecc4: mov             x0, x1
    // 0x129ecc8: r0 = Throw()
    //     0x129ecc8: bl              #0x13ddb2c  ; ThrowStub
    // 0x129eccc: brk             #0
    // 0x129ecd0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x129ecd0: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x129ecd4: r0 = StateError()
    //     0x129ecd4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x129ecd8: mov             x1, x0
    // 0x129ecdc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x129ecdc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x129ece0: StoreField: r1->field_b = r0
    //     0x129ece0: stur            w0, [x1, #0xb]
    // 0x129ece4: mov             x0, x1
    // 0x129ece8: r0 = Throw()
    //     0x129ece8: bl              #0x13ddb2c  ; ThrowStub
    // 0x129ecec: brk             #0
    // 0x129ecf0: r0 = StackOverflowSharedWithFPURegs()
    //     0x129ecf0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x129ecf4: b               #0x129e218
    // 0x129ecf8: r0 = StackOverflowSharedWithFPURegs()
    //     0x129ecf8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x129ecfc: b               #0x129e278
    // 0x129ed00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed00: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x129ed04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed04: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x129ed08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed08: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x129ed0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed0c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x129ed10: r0 = NullCastErrorSharedWithFPURegs()
    //     0x129ed10: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x129ed14: r0 = StackOverflowSharedWithFPURegs()
    //     0x129ed14: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x129ed18: b               #0x129e7b4
    // 0x129ed1c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x129ed1c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x129ed20: r0 = NullCastErrorSharedWithFPURegs()
    //     0x129ed20: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x129ed24: r0 = NullCastErrorSharedWithFPURegs()
    //     0x129ed24: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x129ed28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x129ed28: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x129ed2c: b               #0x129e928
    // 0x129ed30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed30: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x129ed34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed34: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x129ed38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed38: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x129ed3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x129ed3c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x129ed40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed40: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x129ed44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x129ed44: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4838, size: 0x90, field offset: 0x84
class RenderShrinkWrappingViewport extends RenderViewportBase<dynamic> {

  late double _shrinkWrapExtent; // offset: 0x88
  late double _maxScrollExtent; // offset: 0x84

  _ performLayout(/* No info */) {
    // ** addr: 0xbc8260, size: 0x998
    // 0xbc8260: EnterFrame
    //     0xbc8260: stp             fp, lr, [SP, #-0x10]!
    //     0xbc8264: mov             fp, SP
    // 0xbc8268: AllocStack(0x68)
    //     0xbc8268: sub             SP, SP, #0x68
    // 0xbc826c: SetupParameters(RenderShrinkWrappingViewport this /* r1 => r3, fp-0x10 */)
    //     0xbc826c: mov             x3, x1
    //     0xbc8270: stur            x1, [fp, #-0x10]
    // 0xbc8274: CheckStackOverflow
    //     0xbc8274: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc8278: cmp             SP, x16
    //     0xbc827c: b.ls            #0xbc8ad0
    // 0xbc8280: LoadField: r4 = r3->field_27
    //     0xbc8280: ldur            w4, [x3, #0x27]
    // 0xbc8284: DecompressPointer r4
    //     0xbc8284: add             x4, x4, HEAP, lsl #32
    // 0xbc8288: stur            x4, [fp, #-8]
    // 0xbc828c: cmp             w4, NULL
    // 0xbc8290: b.eq            #0xbc8ab4
    // 0xbc8294: mov             x0, x4
    // 0xbc8298: r2 = Null
    //     0xbc8298: mov             x2, NULL
    // 0xbc829c: r1 = Null
    //     0xbc829c: mov             x1, NULL
    // 0xbc82a0: r4 = LoadClassIdInstr(r0)
    //     0xbc82a0: ldur            x4, [x0, #-1]
    //     0xbc82a4: ubfx            x4, x4, #0xc, #0x14
    // 0xbc82a8: sub             x4, x4, #0xb46
    // 0xbc82ac: cmp             x4, #1
    // 0xbc82b0: b.ls            #0xbc82c4
    // 0xbc82b4: r8 = BoxConstraints
    //     0xbc82b4: ldr             x8, [PP, #0x4c90]  ; [pp+0x4c90] Type: BoxConstraints
    // 0xbc82b8: r3 = Null
    //     0xbc82b8: add             x3, PP, #0x96, lsl #12  ; [pp+0x961e0] Null
    //     0xbc82bc: ldr             x3, [x3, #0x1e0]
    // 0xbc82c0: r0 = BoxConstraints()
    //     0xbc82c0: bl              #0x860d24  ; IsType_BoxConstraints_Stub
    // 0xbc82c4: ldur            x1, [fp, #-0x10]
    // 0xbc82c8: LoadField: r0 = r1->field_5b
    //     0xbc82c8: ldur            w0, [x1, #0x5b]
    // 0xbc82cc: DecompressPointer r0
    //     0xbc82cc: add             x0, x0, HEAP, lsl #32
    // 0xbc82d0: cmp             w0, NULL
    // 0xbc82d4: b.ne            #0xbc84f4
    // 0xbc82d8: LoadField: r0 = r1->field_63
    //     0xbc82d8: ldur            w0, [x1, #0x63]
    // 0xbc82dc: DecompressPointer r0
    //     0xbc82dc: add             x0, x0, HEAP, lsl #32
    // 0xbc82e0: r16 = Instance_AxisDirection
    //     0xbc82e0: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xbc82e4: cmp             w0, w16
    // 0xbc82e8: b.eq            #0xbc82f8
    // 0xbc82ec: r16 = Instance_AxisDirection
    //     0xbc82ec: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xbc82f0: cmp             w0, w16
    // 0xbc82f4: b.ne            #0xbc8300
    // 0xbc82f8: r0 = Instance_Axis
    //     0xbc82f8: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbc82fc: b               #0xbc8324
    // 0xbc8300: r16 = Instance_AxisDirection
    //     0xbc8300: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xbc8304: cmp             w0, w16
    // 0xbc8308: b.eq            #0xbc8318
    // 0xbc830c: r16 = Instance_AxisDirection
    //     0xbc830c: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xbc8310: cmp             w0, w16
    // 0xbc8314: b.ne            #0xbc8320
    // 0xbc8318: r0 = Instance_Axis
    //     0xbc8318: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xbc831c: b               #0xbc8324
    // 0xbc8320: r0 = Null
    //     0xbc8320: mov             x0, NULL
    // 0xbc8324: LoadField: r2 = r0->field_7
    //     0xbc8324: ldur            x2, [x0, #7]
    // 0xbc8328: cmp             x2, #0
    // 0xbc832c: b.gt            #0xbc835c
    // 0xbc8330: ldur            x0, [fp, #-8]
    // 0xbc8334: LoadField: d0 = r0->field_7
    //     0xbc8334: ldur            d0, [x0, #7]
    // 0xbc8338: stur            d0, [fp, #-0x30]
    // 0xbc833c: LoadField: d1 = r0->field_1f
    //     0xbc833c: ldur            d1, [x0, #0x1f]
    // 0xbc8340: stur            d1, [fp, #-0x28]
    // 0xbc8344: r0 = Size()
    //     0xbc8344: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc8348: ldur            d0, [fp, #-0x30]
    // 0xbc834c: StoreField: r0->field_7 = d0
    //     0xbc834c: stur            d0, [x0, #7]
    // 0xbc8350: ldur            d0, [fp, #-0x28]
    // 0xbc8354: StoreField: r0->field_f = d0
    //     0xbc8354: stur            d0, [x0, #0xf]
    // 0xbc8358: b               #0xbc8384
    // 0xbc835c: ldur            x0, [fp, #-8]
    // 0xbc8360: LoadField: d0 = r0->field_f
    //     0xbc8360: ldur            d0, [x0, #0xf]
    // 0xbc8364: stur            d0, [fp, #-0x30]
    // 0xbc8368: ArrayLoad: d1 = r0[0]  ; List_8
    //     0xbc8368: ldur            d1, [x0, #0x17]
    // 0xbc836c: stur            d1, [fp, #-0x28]
    // 0xbc8370: r0 = Size()
    //     0xbc8370: bl              #0x81d0c8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xbc8374: ldur            d0, [fp, #-0x30]
    // 0xbc8378: StoreField: r0->field_7 = d0
    //     0xbc8378: stur            d0, [x0, #7]
    // 0xbc837c: ldur            d0, [fp, #-0x28]
    // 0xbc8380: StoreField: r0->field_f = d0
    //     0xbc8380: stur            d0, [x0, #0xf]
    // 0xbc8384: ldur            x1, [fp, #-0x10]
    // 0xbc8388: StoreField: r1->field_4b = r0
    //     0xbc8388: stur            w0, [x1, #0x4b]
    //     0xbc838c: ldurb           w16, [x1, #-1]
    //     0xbc8390: ldurb           w17, [x0, #-1]
    //     0xbc8394: and             x16, x17, x16, lsr #2
    //     0xbc8398: tst             x16, HEAP, lsr #32
    //     0xbc839c: b.eq            #0xbc83a4
    //     0xbc83a0: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc83a4: LoadField: r2 = r1->field_6b
    //     0xbc83a4: ldur            w2, [x1, #0x6b]
    // 0xbc83a8: DecompressPointer r2
    //     0xbc83a8: add             x2, x2, HEAP, lsl #32
    // 0xbc83ac: stur            x2, [fp, #-0x18]
    // 0xbc83b0: r0 = LoadClassIdInstr(r2)
    //     0xbc83b0: ldur            x0, [x2, #-1]
    //     0xbc83b4: ubfx            x0, x0, #0xc, #0x14
    // 0xbc83b8: r17 = -4542
    //     0xbc83b8: mov             x17, #-0x11be
    // 0xbc83bc: add             x16, x0, x17
    // 0xbc83c0: cmp             x16, #1
    // 0xbc83c4: b.ls            #0xbc83d4
    // 0xbc83c8: r17 = 4540
    //     0xbc83c8: mov             x17, #0x11bc
    // 0xbc83cc: cmp             x0, x17
    // 0xbc83d0: b.ne            #0xbc8424
    // 0xbc83d4: LoadField: r0 = r2->field_43
    //     0xbc83d4: ldur            w0, [x2, #0x43]
    // 0xbc83d8: DecompressPointer r0
    //     0xbc83d8: add             x0, x0, HEAP, lsl #32
    // 0xbc83dc: r3 = LoadClassIdInstr(r0)
    //     0xbc83dc: ldur            x3, [x0, #-1]
    //     0xbc83e0: ubfx            x3, x3, #0xc, #0x14
    // 0xbc83e4: r16 = 0.000000
    //     0xbc83e4: ldr             x16, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc83e8: stp             x16, x0, [SP]
    // 0xbc83ec: mov             x0, x3
    // 0xbc83f0: mov             lr, x0
    // 0xbc83f4: ldr             lr, [x21, lr, lsl #3]
    // 0xbc83f8: blr             lr
    // 0xbc83fc: tbz             w0, #4, #0xbc8418
    // 0xbc8400: ldur            x1, [fp, #-0x18]
    // 0xbc8404: r4 = true
    //     0xbc8404: add             x4, NULL, #0x20  ; true
    // 0xbc8408: r2 = 0.000000
    //     0xbc8408: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc840c: StoreField: r1->field_43 = r2
    //     0xbc840c: stur            w2, [x1, #0x43]
    // 0xbc8410: StoreField: r1->field_4b = r4
    //     0xbc8410: stur            w4, [x1, #0x4b]
    // 0xbc8414: b               #0xbc841c
    // 0xbc8418: r2 = 0.000000
    //     0xbc8418: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc841c: mov             x0, x2
    // 0xbc8420: b               #0xbc8448
    // 0xbc8424: mov             x1, x2
    // 0xbc8428: r2 = 0.000000
    //     0xbc8428: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc842c: r0 = LoadClassIdInstr(r1)
    //     0xbc842c: ldur            x0, [x1, #-1]
    //     0xbc8430: ubfx            x0, x0, #0xc, #0x14
    // 0xbc8434: d0 = 0.000000
    //     0xbc8434: eor             v0.16b, v0.16b, v0.16b
    // 0xbc8438: r0 = GDT[cid_x0 + -0x1b0]()
    //     0xbc8438: sub             lr, x0, #0x1b0
    //     0xbc843c: ldr             lr, [x21, lr, lsl #3]
    //     0xbc8440: blr             lr
    // 0xbc8444: r0 = 0.000000
    //     0xbc8444: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc8448: ldur            x1, [fp, #-0x10]
    // 0xbc844c: r2 = false
    //     0xbc844c: add             x2, NULL, #0x30  ; false
    // 0xbc8450: StoreField: r1->field_83 = r0
    //     0xbc8450: stur            w0, [x1, #0x83]
    // 0xbc8454: StoreField: r1->field_87 = r0
    //     0xbc8454: stur            w0, [x1, #0x87]
    // 0xbc8458: StoreField: r1->field_8b = r2
    //     0xbc8458: stur            w2, [x1, #0x8b]
    // 0xbc845c: LoadField: r0 = r1->field_6b
    //     0xbc845c: ldur            w0, [x1, #0x6b]
    // 0xbc8460: DecompressPointer r0
    //     0xbc8460: add             x0, x0, HEAP, lsl #32
    // 0xbc8464: r1 = LoadClassIdInstr(r0)
    //     0xbc8464: ldur            x1, [x0, #-1]
    //     0xbc8468: ubfx            x1, x1, #0xc, #0x14
    // 0xbc846c: r17 = 4541
    //     0xbc846c: mov             x17, #0x11bd
    // 0xbc8470: cmp             x1, x17
    // 0xbc8474: b.ne            #0xbc84bc
    // 0xbc8478: d1 = 0.000000
    //     0xbc8478: eor             v1.16b, v1.16b, v1.16b
    // 0xbc847c: d0 = 2.000000
    //     0xbc847c: fmov            d0, #2.00000000
    // 0xbc8480: LoadField: r1 = r0->field_43
    //     0xbc8480: ldur            w1, [x0, #0x43]
    // 0xbc8484: DecompressPointer r1
    //     0xbc8484: add             x1, x1, HEAP, lsl #32
    // 0xbc8488: cmp             w1, NULL
    // 0xbc848c: b.eq            #0xbc8ad8
    // 0xbc8490: LoadField: d2 = r1->field_7
    //     0xbc8490: ldur            d2, [x1, #7]
    // 0xbc8494: fmul            d3, d2, d1
    // 0xbc8498: fdiv            d2, d3, d0
    // 0xbc849c: fmax            v0.2d, v1.2d, v2.2d
    // 0xbc84a0: fadd            d2, d0, d1
    // 0xbc84a4: fsub            d3, d1, d0
    // 0xbc84a8: fmax            v1.2d, v2.2d, v3.2d
    // 0xbc84ac: mov             x1, x0
    // 0xbc84b0: mov             v0.16b, v2.16b
    // 0xbc84b4: r0 = applyContentDimensions()
    //     0xbc84b4: bl              #0x12859f8  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xbc84b8: b               #0xbc84e4
    // 0xbc84bc: d1 = 0.000000
    //     0xbc84bc: eor             v1.16b, v1.16b, v1.16b
    // 0xbc84c0: r1 = LoadClassIdInstr(r0)
    //     0xbc84c0: ldur            x1, [x0, #-1]
    //     0xbc84c4: ubfx            x1, x1, #0xc, #0x14
    // 0xbc84c8: mov             x16, x0
    // 0xbc84cc: mov             x0, x1
    // 0xbc84d0: mov             x1, x16
    // 0xbc84d4: mov             v0.16b, v1.16b
    // 0xbc84d8: r0 = GDT[cid_x0 + -0x1cd]()
    //     0xbc84d8: sub             lr, x0, #0x1cd
    //     0xbc84dc: ldr             lr, [x21, lr, lsl #3]
    //     0xbc84e0: blr             lr
    // 0xbc84e4: r0 = Null
    //     0xbc84e4: mov             x0, NULL
    // 0xbc84e8: LeaveFrame
    //     0xbc84e8: mov             SP, fp
    //     0xbc84ec: ldp             fp, lr, [SP], #0x10
    // 0xbc84f0: ret
    //     0xbc84f0: ret             
    // 0xbc84f4: ldur            x0, [fp, #-8]
    // 0xbc84f8: r4 = true
    //     0xbc84f8: add             x4, NULL, #0x20  ; true
    // 0xbc84fc: d1 = 0.000000
    //     0xbc84fc: eor             v1.16b, v1.16b, v1.16b
    // 0xbc8500: d0 = 2.000000
    //     0xbc8500: fmov            d0, #2.00000000
    // 0xbc8504: LoadField: r2 = r1->field_63
    //     0xbc8504: ldur            w2, [x1, #0x63]
    // 0xbc8508: DecompressPointer r2
    //     0xbc8508: add             x2, x2, HEAP, lsl #32
    // 0xbc850c: r16 = Instance_AxisDirection
    //     0xbc850c: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xbc8510: cmp             w2, w16
    // 0xbc8514: b.eq            #0xbc8524
    // 0xbc8518: r16 = Instance_AxisDirection
    //     0xbc8518: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xbc851c: cmp             w2, w16
    // 0xbc8520: b.ne            #0xbc852c
    // 0xbc8524: r2 = Instance_Axis
    //     0xbc8524: ldr             x2, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbc8528: b               #0xbc8550
    // 0xbc852c: r16 = Instance_AxisDirection
    //     0xbc852c: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xbc8530: cmp             w2, w16
    // 0xbc8534: b.eq            #0xbc8544
    // 0xbc8538: r16 = Instance_AxisDirection
    //     0xbc8538: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xbc853c: cmp             w2, w16
    // 0xbc8540: b.ne            #0xbc854c
    // 0xbc8544: r2 = Instance_Axis
    //     0xbc8544: ldr             x2, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xbc8548: b               #0xbc8550
    // 0xbc854c: r2 = Null
    //     0xbc854c: mov             x2, NULL
    // 0xbc8550: LoadField: r3 = r2->field_7
    //     0xbc8550: ldur            x3, [x2, #7]
    // 0xbc8554: cmp             x3, #0
    // 0xbc8558: b.gt            #0xbc85d8
    // 0xbc855c: LoadField: d2 = r0->field_f
    //     0xbc855c: ldur            d2, [x0, #0xf]
    // 0xbc8560: stur            d2, [fp, #-0x30]
    // 0xbc8564: LoadField: d3 = r0->field_1f
    //     0xbc8564: ldur            d3, [x0, #0x1f]
    // 0xbc8568: stur            d3, [fp, #-0x28]
    // 0xbc856c: r2 = inline_Allocate_Double()
    //     0xbc856c: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbc8570: add             x2, x2, #0x10
    //     0xbc8574: cmp             x3, x2
    //     0xbc8578: b.ls            #0xbc8adc
    //     0xbc857c: str             x2, [THR, #0x60]  ; THR::top
    //     0xbc8580: sub             x2, x2, #0xf
    //     0xbc8584: mov             x3, #0xe19c
    //     0xbc8588: movk            x3, #3, lsl #16
    //     0xbc858c: stur            x3, [x2, #-1]
    // 0xbc8590: dmb             ishst
    // 0xbc8594: StoreField: r2->field_7 = d2
    //     0xbc8594: stur            d2, [x2, #7]
    // 0xbc8598: r3 = inline_Allocate_Double()
    //     0xbc8598: ldp             x3, x5, [THR, #0x60]  ; THR::top
    //     0xbc859c: add             x3, x3, #0x10
    //     0xbc85a0: cmp             x5, x3
    //     0xbc85a4: b.ls            #0xbc8b08
    //     0xbc85a8: str             x3, [THR, #0x60]  ; THR::top
    //     0xbc85ac: sub             x3, x3, #0xf
    //     0xbc85b0: mov             x5, #0xe19c
    //     0xbc85b4: movk            x5, #3, lsl #16
    //     0xbc85b8: stur            x5, [x3, #-1]
    // 0xbc85bc: dmb             ishst
    // 0xbc85c0: StoreField: r3->field_7 = d3
    //     0xbc85c0: stur            d3, [x3, #7]
    // 0xbc85c4: r0 = AllocateRecord2()
    //     0xbc85c4: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbc85c8: mov             x1, x0
    // 0xbc85cc: ldur            d4, [fp, #-0x28]
    // 0xbc85d0: ldur            d3, [fp, #-0x30]
    // 0xbc85d4: b               #0xbc8654
    // 0xbc85d8: mov             x1, x0
    // 0xbc85dc: LoadField: d0 = r1->field_1f
    //     0xbc85dc: ldur            d0, [x1, #0x1f]
    // 0xbc85e0: stur            d0, [fp, #-0x30]
    // 0xbc85e4: LoadField: d1 = r1->field_f
    //     0xbc85e4: ldur            d1, [x1, #0xf]
    // 0xbc85e8: stur            d1, [fp, #-0x28]
    // 0xbc85ec: r2 = inline_Allocate_Double()
    //     0xbc85ec: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xbc85f0: add             x2, x2, #0x10
    //     0xbc85f4: cmp             x0, x2
    //     0xbc85f8: b.ls            #0xbc8b34
    //     0xbc85fc: str             x2, [THR, #0x60]  ; THR::top
    //     0xbc8600: sub             x2, x2, #0xf
    //     0xbc8604: mov             x0, #0xe19c
    //     0xbc8608: movk            x0, #3, lsl #16
    //     0xbc860c: stur            x0, [x2, #-1]
    // 0xbc8610: dmb             ishst
    // 0xbc8614: StoreField: r2->field_7 = d0
    //     0xbc8614: stur            d0, [x2, #7]
    // 0xbc8618: r3 = inline_Allocate_Double()
    //     0xbc8618: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xbc861c: add             x3, x3, #0x10
    //     0xbc8620: cmp             x0, x3
    //     0xbc8624: b.ls            #0xbc8b50
    //     0xbc8628: str             x3, [THR, #0x60]  ; THR::top
    //     0xbc862c: sub             x3, x3, #0xf
    //     0xbc8630: mov             x0, #0xe19c
    //     0xbc8634: movk            x0, #3, lsl #16
    //     0xbc8638: stur            x0, [x3, #-1]
    // 0xbc863c: dmb             ishst
    // 0xbc8640: StoreField: r3->field_7 = d1
    //     0xbc8640: stur            d1, [x3, #7]
    // 0xbc8644: r0 = AllocateRecord2()
    //     0xbc8644: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbc8648: mov             x1, x0
    // 0xbc864c: ldur            d4, [fp, #-0x30]
    // 0xbc8650: ldur            d3, [fp, #-0x28]
    // 0xbc8654: ldur            x0, [fp, #-8]
    // 0xbc8658: stur            d4, [fp, #-0x48]
    // 0xbc865c: stur            d3, [fp, #-0x50]
    // 0xbc8660: LoadField: r2 = r1->field_f
    //     0xbc8660: ldur            w2, [x1, #0xf]
    // 0xbc8664: DecompressPointer r2
    //     0xbc8664: add             x2, x2, HEAP, lsl #32
    // 0xbc8668: LoadField: r3 = r1->field_13
    //     0xbc8668: ldur            w3, [x1, #0x13]
    // 0xbc866c: DecompressPointer r3
    //     0xbc866c: add             x3, x3, HEAP, lsl #32
    // 0xbc8670: LoadField: d5 = r2->field_7
    //     0xbc8670: ldur            d5, [x2, #7]
    // 0xbc8674: stur            d5, [fp, #-0x40]
    // 0xbc8678: LoadField: d6 = r3->field_7
    //     0xbc8678: ldur            d6, [x3, #7]
    // 0xbc867c: stur            d6, [fp, #-0x38]
    // 0xbc8680: ArrayLoad: d7 = r0[0]  ; List_8
    //     0xbc8680: ldur            d7, [x0, #0x17]
    // 0xbc8684: stur            d7, [fp, #-0x30]
    // 0xbc8688: LoadField: d8 = r0->field_7
    //     0xbc8688: ldur            d8, [x0, #7]
    // 0xbc868c: stur            d8, [fp, #-0x28]
    // 0xbc8690: ldur            x2, [fp, #-0x10]
    // 0xbc8694: CheckStackOverflow
    //     0xbc8694: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc8698: cmp             SP, x16
    //     0xbc869c: b.ls            #0xbc8b6c
    // 0xbc86a0: LoadField: r1 = r2->field_6b
    //     0xbc86a0: ldur            w1, [x2, #0x6b]
    // 0xbc86a4: DecompressPointer r1
    //     0xbc86a4: add             x1, x1, HEAP, lsl #32
    // 0xbc86a8: LoadField: r3 = r1->field_3f
    //     0xbc86a8: ldur            w3, [x1, #0x3f]
    // 0xbc86ac: DecompressPointer r3
    //     0xbc86ac: add             x3, x3, HEAP, lsl #32
    // 0xbc86b0: cmp             w3, NULL
    // 0xbc86b4: b.eq            #0xbc8b74
    // 0xbc86b8: LoadField: d2 = r3->field_7
    //     0xbc86b8: ldur            d2, [x3, #7]
    // 0xbc86bc: mov             x1, x2
    // 0xbc86c0: mov             v0.16b, v5.16b
    // 0xbc86c4: mov             v1.16b, v6.16b
    // 0xbc86c8: r0 = _attemptLayout()
    //     0xbc86c8: bl              #0xbc8cf8  ; [package:flutter/src/rendering/viewport.dart] RenderShrinkWrappingViewport::_attemptLayout
    // 0xbc86cc: mov             v1.16b, v0.16b
    // 0xbc86d0: d0 = 0.000000
    //     0xbc86d0: eor             v0.16b, v0.16b, v0.16b
    // 0xbc86d4: fcmp            d1, d0
    // 0xbc86d8: b.eq            #0xbc8758
    // 0xbc86dc: ldur            x2, [fp, #-0x10]
    // 0xbc86e0: r1 = true
    //     0xbc86e0: add             x1, NULL, #0x20  ; true
    // 0xbc86e4: LoadField: r3 = r2->field_6b
    //     0xbc86e4: ldur            w3, [x2, #0x6b]
    // 0xbc86e8: DecompressPointer r3
    //     0xbc86e8: add             x3, x3, HEAP, lsl #32
    // 0xbc86ec: LoadField: r0 = r3->field_3f
    //     0xbc86ec: ldur            w0, [x3, #0x3f]
    // 0xbc86f0: DecompressPointer r0
    //     0xbc86f0: add             x0, x0, HEAP, lsl #32
    // 0xbc86f4: cmp             w0, NULL
    // 0xbc86f8: b.eq            #0xbc8b78
    // 0xbc86fc: LoadField: d2 = r0->field_7
    //     0xbc86fc: ldur            d2, [x0, #7]
    // 0xbc8700: fadd            d3, d2, d1
    // 0xbc8704: r0 = inline_Allocate_Double()
    //     0xbc8704: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbc8708: add             x0, x0, #0x10
    //     0xbc870c: cmp             x4, x0
    //     0xbc8710: b.ls            #0xbc8b7c
    //     0xbc8714: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc8718: sub             x0, x0, #0xf
    //     0xbc871c: mov             x4, #0xe19c
    //     0xbc8720: movk            x4, #3, lsl #16
    //     0xbc8724: stur            x4, [x0, #-1]
    // 0xbc8728: dmb             ishst
    // 0xbc872c: StoreField: r0->field_7 = d3
    //     0xbc872c: stur            d3, [x0, #7]
    // 0xbc8730: StoreField: r3->field_3f = r0
    //     0xbc8730: stur            w0, [x3, #0x3f]
    //     0xbc8734: ldurb           w16, [x3, #-1]
    //     0xbc8738: ldurb           w17, [x0, #-1]
    //     0xbc873c: and             x16, x17, x16, lsr #2
    //     0xbc8740: tst             x16, HEAP, lsr #32
    //     0xbc8744: b.eq            #0xbc874c
    //     0xbc8748: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc874c: StoreField: r3->field_4b = r1
    //     0xbc874c: stur            w1, [x3, #0x4b]
    // 0xbc8750: mov             x1, x2
    // 0xbc8754: b               #0xbc8a90
    // 0xbc8758: ldur            x2, [fp, #-0x10]
    // 0xbc875c: r1 = true
    //     0xbc875c: add             x1, NULL, #0x20  ; true
    // 0xbc8760: LoadField: r0 = r2->field_63
    //     0xbc8760: ldur            w0, [x2, #0x63]
    // 0xbc8764: DecompressPointer r0
    //     0xbc8764: add             x0, x0, HEAP, lsl #32
    // 0xbc8768: r16 = Instance_AxisDirection
    //     0xbc8768: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0xbc876c: cmp             w0, w16
    // 0xbc8770: b.eq            #0xbc8780
    // 0xbc8774: r16 = Instance_AxisDirection
    //     0xbc8774: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0xbc8778: cmp             w0, w16
    // 0xbc877c: b.ne            #0xbc8788
    // 0xbc8780: r0 = Instance_Axis
    //     0xbc8780: ldr             x0, [PP, #0x49c0]  ; [pp+0x49c0] Obj!Axis@12c4a81
    // 0xbc8784: b               #0xbc87ac
    // 0xbc8788: r16 = Instance_AxisDirection
    //     0xbc8788: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0xbc878c: cmp             w0, w16
    // 0xbc8790: b.eq            #0xbc87a0
    // 0xbc8794: r16 = Instance_AxisDirection
    //     0xbc8794: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0xbc8798: cmp             w0, w16
    // 0xbc879c: b.ne            #0xbc87a8
    // 0xbc87a0: r0 = Instance_Axis
    //     0xbc87a0: ldr             x0, [PP, #0x49c8]  ; [pp+0x49c8] Obj!Axis@12c4a61
    // 0xbc87a4: b               #0xbc87ac
    // 0xbc87a8: r0 = Null
    //     0xbc87a8: mov             x0, NULL
    // 0xbc87ac: LoadField: r3 = r0->field_7
    //     0xbc87ac: ldur            x3, [x0, #7]
    // 0xbc87b0: cmp             x3, #0
    // 0xbc87b4: b.gt            #0xbc8818
    // 0xbc87b8: ldur            d1, [fp, #-0x28]
    // 0xbc87bc: LoadField: r0 = r2->field_87
    //     0xbc87bc: ldur            w0, [x2, #0x87]
    // 0xbc87c0: DecompressPointer r0
    //     0xbc87c0: add             x0, x0, HEAP, lsl #32
    // 0xbc87c4: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc87c8: cmp             w0, w16
    // 0xbc87cc: b.eq            #0xbc8b9c
    // 0xbc87d0: LoadField: d2 = r0->field_7
    //     0xbc87d0: ldur            d2, [x0, #7]
    // 0xbc87d4: fcmp            d1, d2
    // 0xbc87d8: b.le            #0xbc87e8
    // 0xbc87dc: mov             v2.16b, v1.16b
    // 0xbc87e0: ldur            d3, [fp, #-0x50]
    // 0xbc87e4: b               #0xbc8808
    // 0xbc87e8: ldur            d3, [fp, #-0x50]
    // 0xbc87ec: fcmp            d2, d3
    // 0xbc87f0: b.le            #0xbc87fc
    // 0xbc87f4: mov             v2.16b, v3.16b
    // 0xbc87f8: b               #0xbc8808
    // 0xbc87fc: fcmp            d2, d2
    // 0xbc8800: b.vc            #0xbc8808
    // 0xbc8804: mov             v2.16b, v3.16b
    // 0xbc8808: mov             v4.16b, v2.16b
    // 0xbc880c: ldur            d2, [fp, #-0x30]
    // 0xbc8810: ldur            d5, [fp, #-0x48]
    // 0xbc8814: b               #0xbc8870
    // 0xbc8818: ldur            d2, [fp, #-0x30]
    // 0xbc881c: ldur            d1, [fp, #-0x28]
    // 0xbc8820: ldur            d3, [fp, #-0x50]
    // 0xbc8824: LoadField: r0 = r2->field_87
    //     0xbc8824: ldur            w0, [x2, #0x87]
    // 0xbc8828: DecompressPointer r0
    //     0xbc8828: add             x0, x0, HEAP, lsl #32
    // 0xbc882c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc8830: cmp             w0, w16
    // 0xbc8834: b.eq            #0xbc8ba8
    // 0xbc8838: LoadField: d4 = r0->field_7
    //     0xbc8838: ldur            d4, [x0, #7]
    // 0xbc883c: fcmp            d2, d4
    // 0xbc8840: b.le            #0xbc8850
    // 0xbc8844: mov             v4.16b, v2.16b
    // 0xbc8848: ldur            d5, [fp, #-0x48]
    // 0xbc884c: b               #0xbc8870
    // 0xbc8850: ldur            d5, [fp, #-0x48]
    // 0xbc8854: fcmp            d4, d5
    // 0xbc8858: b.le            #0xbc8864
    // 0xbc885c: mov             v4.16b, v5.16b
    // 0xbc8860: b               #0xbc8870
    // 0xbc8864: fcmp            d4, d4
    // 0xbc8868: b.vc            #0xbc8870
    // 0xbc886c: mov             v4.16b, v5.16b
    // 0xbc8870: stur            d4, [fp, #-0x58]
    // 0xbc8874: LoadField: r3 = r2->field_6b
    //     0xbc8874: ldur            w3, [x2, #0x6b]
    // 0xbc8878: DecompressPointer r3
    //     0xbc8878: add             x3, x3, HEAP, lsl #32
    // 0xbc887c: stur            x3, [fp, #-0x20]
    // 0xbc8880: r0 = LoadClassIdInstr(r3)
    //     0xbc8880: ldur            x0, [x3, #-1]
    //     0xbc8884: ubfx            x0, x0, #0xc, #0x14
    // 0xbc8888: r17 = -4542
    //     0xbc8888: mov             x17, #-0x11be
    // 0xbc888c: add             x16, x0, x17
    // 0xbc8890: cmp             x16, #1
    // 0xbc8894: b.ls            #0xbc88a4
    // 0xbc8898: r17 = 4540
    //     0xbc8898: mov             x17, #0x11bc
    // 0xbc889c: cmp             x0, x17
    // 0xbc88a0: b.ne            #0xbc8938
    // 0xbc88a4: LoadField: r0 = r3->field_43
    //     0xbc88a4: ldur            w0, [x3, #0x43]
    // 0xbc88a8: DecompressPointer r0
    //     0xbc88a8: add             x0, x0, HEAP, lsl #32
    // 0xbc88ac: r4 = inline_Allocate_Double()
    //     0xbc88ac: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbc88b0: add             x4, x4, #0x10
    //     0xbc88b4: cmp             x5, x4
    //     0xbc88b8: b.ls            #0xbc8bb4
    //     0xbc88bc: str             x4, [THR, #0x60]  ; THR::top
    //     0xbc88c0: sub             x4, x4, #0xf
    //     0xbc88c4: mov             x5, #0xe19c
    //     0xbc88c8: movk            x5, #3, lsl #16
    //     0xbc88cc: stur            x5, [x4, #-1]
    // 0xbc88d0: dmb             ishst
    // 0xbc88d4: StoreField: r4->field_7 = d4
    //     0xbc88d4: stur            d4, [x4, #7]
    // 0xbc88d8: stur            x4, [fp, #-0x18]
    // 0xbc88dc: r5 = LoadClassIdInstr(r0)
    //     0xbc88dc: ldur            x5, [x0, #-1]
    //     0xbc88e0: ubfx            x5, x5, #0xc, #0x14
    // 0xbc88e4: stp             x4, x0, [SP]
    // 0xbc88e8: mov             x0, x5
    // 0xbc88ec: mov             lr, x0
    // 0xbc88f0: ldr             lr, [x21, lr, lsl #3]
    // 0xbc88f4: blr             lr
    // 0xbc88f8: tbz             w0, #4, #0xbc892c
    // 0xbc88fc: ldur            x1, [fp, #-0x20]
    // 0xbc8900: r2 = true
    //     0xbc8900: add             x2, NULL, #0x20  ; true
    // 0xbc8904: ldur            x0, [fp, #-0x18]
    // 0xbc8908: StoreField: r1->field_43 = r0
    //     0xbc8908: stur            w0, [x1, #0x43]
    //     0xbc890c: ldurb           w16, [x1, #-1]
    //     0xbc8910: ldurb           w17, [x0, #-1]
    //     0xbc8914: and             x16, x17, x16, lsr #2
    //     0xbc8918: tst             x16, HEAP, lsr #32
    //     0xbc891c: b.eq            #0xbc8924
    //     0xbc8920: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc8924: StoreField: r1->field_4b = r2
    //     0xbc8924: stur            w2, [x1, #0x4b]
    // 0xbc8928: b               #0xbc8930
    // 0xbc892c: r2 = true
    //     0xbc892c: add             x2, NULL, #0x20  ; true
    // 0xbc8930: r2 = true
    //     0xbc8930: add             x2, NULL, #0x20  ; true
    // 0xbc8934: b               #0xbc895c
    // 0xbc8938: mov             x2, x1
    // 0xbc893c: mov             x1, x3
    // 0xbc8940: r0 = LoadClassIdInstr(r1)
    //     0xbc8940: ldur            x0, [x1, #-1]
    //     0xbc8944: ubfx            x0, x0, #0xc, #0x14
    // 0xbc8948: ldur            d0, [fp, #-0x58]
    // 0xbc894c: r0 = GDT[cid_x0 + -0x1b0]()
    //     0xbc894c: sub             lr, x0, #0x1b0
    //     0xbc8950: ldr             lr, [x21, lr, lsl #3]
    //     0xbc8954: blr             lr
    // 0xbc8958: mov             x2, x0
    // 0xbc895c: ldur            x0, [fp, #-0x10]
    // 0xbc8960: ldur            d3, [fp, #-0x58]
    // 0xbc8964: d2 = 0.000000
    //     0xbc8964: eor             v2.16b, v2.16b, v2.16b
    // 0xbc8968: stur            x2, [fp, #-0x18]
    // 0xbc896c: LoadField: r1 = r0->field_6b
    //     0xbc896c: ldur            w1, [x0, #0x6b]
    // 0xbc8970: DecompressPointer r1
    //     0xbc8970: add             x1, x1, HEAP, lsl #32
    // 0xbc8974: LoadField: r3 = r0->field_83
    //     0xbc8974: ldur            w3, [x0, #0x83]
    // 0xbc8978: DecompressPointer r3
    //     0xbc8978: add             x3, x3, HEAP, lsl #32
    // 0xbc897c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc8980: cmp             w3, w16
    // 0xbc8984: b.eq            #0xbc8be8
    // 0xbc8988: LoadField: d0 = r3->field_7
    //     0xbc8988: ldur            d0, [x3, #7]
    // 0xbc898c: fsub            d1, d0, d3
    // 0xbc8990: fmax            v0.2d, v2.2d, v1.2d
    // 0xbc8994: r3 = LoadClassIdInstr(r1)
    //     0xbc8994: ldur            x3, [x1, #-1]
    //     0xbc8998: ubfx            x3, x3, #0xc, #0x14
    // 0xbc899c: r17 = 4541
    //     0xbc899c: mov             x17, #0x11bd
    // 0xbc89a0: cmp             x3, x17
    // 0xbc89a4: b.ne            #0xbc89f0
    // 0xbc89a8: d4 = 2.000000
    //     0xbc89a8: fmov            d4, #2.00000000
    // 0xbc89ac: LoadField: r3 = r1->field_43
    //     0xbc89ac: ldur            w3, [x1, #0x43]
    // 0xbc89b0: DecompressPointer r3
    //     0xbc89b0: add             x3, x3, HEAP, lsl #32
    // 0xbc89b4: cmp             w3, NULL
    // 0xbc89b8: b.eq            #0xbc8bf4
    // 0xbc89bc: LoadField: d1 = r3->field_7
    //     0xbc89bc: ldur            d1, [x3, #7]
    // 0xbc89c0: fmul            d5, d1, d2
    // 0xbc89c4: fdiv            d1, d5, d4
    // 0xbc89c8: fmax            v5.2d, v2.2d, v1.2d
    // 0xbc89cc: fadd            d1, d5, d2
    // 0xbc89d0: fsub            d6, d0, d5
    // 0xbc89d4: fmax            v0.2d, v1.2d, v6.2d
    // 0xbc89d8: mov             v31.16b, v0.16b
    // 0xbc89dc: mov             v0.16b, v1.16b
    // 0xbc89e0: mov             v1.16b, v31.16b
    // 0xbc89e4: r0 = applyContentDimensions()
    //     0xbc89e4: bl              #0x12859f8  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xbc89e8: mov             x1, x0
    // 0xbc89ec: b               #0xbc8a10
    // 0xbc89f0: r0 = LoadClassIdInstr(r1)
    //     0xbc89f0: ldur            x0, [x1, #-1]
    //     0xbc89f4: ubfx            x0, x0, #0xc, #0x14
    // 0xbc89f8: mov             v1.16b, v0.16b
    // 0xbc89fc: d0 = 0.000000
    //     0xbc89fc: eor             v0.16b, v0.16b, v0.16b
    // 0xbc8a00: r0 = GDT[cid_x0 + -0x1cd]()
    //     0xbc8a00: sub             lr, x0, #0x1cd
    //     0xbc8a04: ldr             lr, [x21, lr, lsl #3]
    //     0xbc8a08: blr             lr
    // 0xbc8a0c: mov             x1, x0
    // 0xbc8a10: ldur            x0, [fp, #-0x18]
    // 0xbc8a14: tbnz            w0, #4, #0xbc8a8c
    // 0xbc8a18: tbz             w1, #4, #0xbc8a24
    // 0xbc8a1c: ldur            x1, [fp, #-0x10]
    // 0xbc8a20: b               #0xbc8a90
    // 0xbc8a24: ldur            x1, [fp, #-0x10]
    // 0xbc8a28: r0 = axis()
    //     0xbc8a28: bl              #0xbc8210  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::axis
    // 0xbc8a2c: LoadField: r1 = r0->field_7
    //     0xbc8a2c: ldur            x1, [x0, #7]
    // 0xbc8a30: cmp             x1, #0
    // 0xbc8a34: b.gt            #0xbc8a4c
    // 0xbc8a38: ldur            x1, [fp, #-8]
    // 0xbc8a3c: ldur            d0, [fp, #-0x58]
    // 0xbc8a40: ldur            d1, [fp, #-0x38]
    // 0xbc8a44: r0 = constrainDimensions()
    //     0xbc8a44: bl              #0xbc8bf8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainDimensions
    // 0xbc8a48: b               #0xbc8a5c
    // 0xbc8a4c: ldur            x1, [fp, #-8]
    // 0xbc8a50: ldur            d0, [fp, #-0x38]
    // 0xbc8a54: ldur            d1, [fp, #-0x58]
    // 0xbc8a58: r0 = constrainDimensions()
    //     0xbc8a58: bl              #0xbc8bf8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrainDimensions
    // 0xbc8a5c: ldur            x1, [fp, #-0x10]
    // 0xbc8a60: StoreField: r1->field_4b = r0
    //     0xbc8a60: stur            w0, [x1, #0x4b]
    //     0xbc8a64: ldurb           w16, [x1, #-1]
    //     0xbc8a68: ldurb           w17, [x0, #-1]
    //     0xbc8a6c: and             x16, x17, x16, lsr #2
    //     0xbc8a70: tst             x16, HEAP, lsr #32
    //     0xbc8a74: b.eq            #0xbc8a7c
    //     0xbc8a78: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc8a7c: r0 = Null
    //     0xbc8a7c: mov             x0, NULL
    // 0xbc8a80: LeaveFrame
    //     0xbc8a80: mov             SP, fp
    //     0xbc8a84: ldp             fp, lr, [SP], #0x10
    // 0xbc8a88: ret
    //     0xbc8a88: ret             
    // 0xbc8a8c: ldur            x1, [fp, #-0x10]
    // 0xbc8a90: mov             x2, x1
    // 0xbc8a94: ldur            d7, [fp, #-0x30]
    // 0xbc8a98: ldur            d8, [fp, #-0x28]
    // 0xbc8a9c: ldur            x0, [fp, #-8]
    // 0xbc8aa0: ldur            d5, [fp, #-0x40]
    // 0xbc8aa4: ldur            d6, [fp, #-0x38]
    // 0xbc8aa8: ldur            d4, [fp, #-0x48]
    // 0xbc8aac: ldur            d3, [fp, #-0x50]
    // 0xbc8ab0: b               #0xbc8694
    // 0xbc8ab4: r0 = StateError()
    //     0xbc8ab4: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xbc8ab8: mov             x1, x0
    // 0xbc8abc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0xbc8abc: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0xbc8ac0: StoreField: r1->field_b = r0
    //     0xbc8ac0: stur            w0, [x1, #0xb]
    // 0xbc8ac4: mov             x0, x1
    // 0xbc8ac8: r0 = Throw()
    //     0xbc8ac8: bl              #0x13ddb2c  ; ThrowStub
    // 0xbc8acc: brk             #0
    // 0xbc8ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc8ad0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc8ad4: b               #0xbc8280
    // 0xbc8ad8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc8ad8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc8adc: stp             q2, q3, [SP, #-0x20]!
    // 0xbc8ae0: stp             q0, q1, [SP, #-0x20]!
    // 0xbc8ae4: stp             x1, x4, [SP, #-0x10]!
    // 0xbc8ae8: SaveReg r0
    //     0xbc8ae8: str             x0, [SP, #-8]!
    // 0xbc8aec: r0 = AllocateDouble()
    //     0xbc8aec: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8af0: mov             x2, x0
    // 0xbc8af4: RestoreReg r0
    //     0xbc8af4: ldr             x0, [SP], #8
    // 0xbc8af8: ldp             x1, x4, [SP], #0x10
    // 0xbc8afc: ldp             q0, q1, [SP], #0x20
    // 0xbc8b00: ldp             q2, q3, [SP], #0x20
    // 0xbc8b04: b               #0xbc8594
    // 0xbc8b08: stp             q2, q3, [SP, #-0x20]!
    // 0xbc8b0c: stp             q0, q1, [SP, #-0x20]!
    // 0xbc8b10: stp             x2, x4, [SP, #-0x10]!
    // 0xbc8b14: stp             x0, x1, [SP, #-0x10]!
    // 0xbc8b18: r0 = AllocateDouble()
    //     0xbc8b18: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8b1c: mov             x3, x0
    // 0xbc8b20: ldp             x0, x1, [SP], #0x10
    // 0xbc8b24: ldp             x2, x4, [SP], #0x10
    // 0xbc8b28: ldp             q0, q1, [SP], #0x20
    // 0xbc8b2c: ldp             q2, q3, [SP], #0x20
    // 0xbc8b30: b               #0xbc85c0
    // 0xbc8b34: stp             q0, q1, [SP, #-0x20]!
    // 0xbc8b38: SaveReg r1
    //     0xbc8b38: str             x1, [SP, #-8]!
    // 0xbc8b3c: r0 = AllocateDouble()
    //     0xbc8b3c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8b40: mov             x2, x0
    // 0xbc8b44: RestoreReg r1
    //     0xbc8b44: ldr             x1, [SP], #8
    // 0xbc8b48: ldp             q0, q1, [SP], #0x20
    // 0xbc8b4c: b               #0xbc8614
    // 0xbc8b50: stp             q0, q1, [SP, #-0x20]!
    // 0xbc8b54: stp             x1, x2, [SP, #-0x10]!
    // 0xbc8b58: r0 = AllocateDouble()
    //     0xbc8b58: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8b5c: mov             x3, x0
    // 0xbc8b60: ldp             x1, x2, [SP], #0x10
    // 0xbc8b64: ldp             q0, q1, [SP], #0x20
    // 0xbc8b68: b               #0xbc8640
    // 0xbc8b6c: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc8b6c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc8b70: b               #0xbc86a0
    // 0xbc8b74: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc8b74: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc8b78: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc8b78: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc8b7c: stp             q0, q3, [SP, #-0x20]!
    // 0xbc8b80: stp             x2, x3, [SP, #-0x10]!
    // 0xbc8b84: SaveReg r1
    //     0xbc8b84: str             x1, [SP, #-8]!
    // 0xbc8b88: r0 = AllocateDouble()
    //     0xbc8b88: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8b8c: RestoreReg r1
    //     0xbc8b8c: ldr             x1, [SP], #8
    // 0xbc8b90: ldp             x2, x3, [SP], #0x10
    // 0xbc8b94: ldp             q0, q3, [SP], #0x20
    // 0xbc8b98: b               #0xbc872c
    // 0xbc8b9c: r9 = _shrinkWrapExtent
    //     0xbc8b9c: add             x9, PP, #0x96, lsl #12  ; [pp+0x961f0] Field <RenderShrinkWrappingViewport._shrinkWrapExtent@616057554>: late (offset: 0x88)
    //     0xbc8ba0: ldr             x9, [x9, #0x1f0]
    // 0xbc8ba4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbc8ba4: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbc8ba8: r9 = _shrinkWrapExtent
    //     0xbc8ba8: add             x9, PP, #0x96, lsl #12  ; [pp+0x961f0] Field <RenderShrinkWrappingViewport._shrinkWrapExtent@616057554>: late (offset: 0x88)
    //     0xbc8bac: ldr             x9, [x9, #0x1f0]
    // 0xbc8bb0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbc8bb0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbc8bb4: stp             q4, q5, [SP, #-0x20]!
    // 0xbc8bb8: stp             q2, q3, [SP, #-0x20]!
    // 0xbc8bbc: stp             q0, q1, [SP, #-0x20]!
    // 0xbc8bc0: stp             x2, x3, [SP, #-0x10]!
    // 0xbc8bc4: stp             x0, x1, [SP, #-0x10]!
    // 0xbc8bc8: r0 = AllocateDouble()
    //     0xbc8bc8: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8bcc: mov             x4, x0
    // 0xbc8bd0: ldp             x0, x1, [SP], #0x10
    // 0xbc8bd4: ldp             x2, x3, [SP], #0x10
    // 0xbc8bd8: ldp             q0, q1, [SP], #0x20
    // 0xbc8bdc: ldp             q2, q3, [SP], #0x20
    // 0xbc8be0: ldp             q4, q5, [SP], #0x20
    // 0xbc8be4: b               #0xbc88d4
    // 0xbc8be8: r9 = _maxScrollExtent
    //     0xbc8be8: add             x9, PP, #0x96, lsl #12  ; [pp+0x961f8] Field <RenderShrinkWrappingViewport._maxScrollExtent@616057554>: late (offset: 0x84)
    //     0xbc8bec: ldr             x9, [x9, #0x1f8]
    // 0xbc8bf0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbc8bf0: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbc8bf4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc8bf4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _attemptLayout(/* No info */) {
    // ** addr: 0xbc8cf8, size: 0x1bc
    // 0xbc8cf8: EnterFrame
    //     0xbc8cf8: stp             fp, lr, [SP, #-0x10]!
    //     0xbc8cfc: mov             fp, SP
    // 0xbc8d00: AllocStack(0x60)
    //     0xbc8d00: sub             SP, SP, #0x60
    // 0xbc8d04: r0 = 0.000000
    //     0xbc8d04: ldr             x0, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc8d08: d3 = 0.000000
    //     0xbc8d08: eor             v3.16b, v3.16b, v3.16b
    // 0xbc8d0c: mov             x3, x1
    // 0xbc8d10: stur            x1, [fp, #-0x10]
    // 0xbc8d14: stur            d0, [fp, #-0x48]
    // 0xbc8d18: stur            d1, [fp, #-0x50]
    // 0xbc8d1c: CheckStackOverflow
    //     0xbc8d1c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc8d20: cmp             SP, x16
    //     0xbc8d24: b.ls            #0xbc8e84
    // 0xbc8d28: StoreField: r3->field_83 = r0
    //     0xbc8d28: stur            w0, [x3, #0x83]
    // 0xbc8d2c: StoreField: r3->field_87 = r0
    //     0xbc8d2c: stur            w0, [x3, #0x87]
    // 0xbc8d30: fcmp            d3, d2
    // 0xbc8d34: r16 = true
    //     0xbc8d34: add             x16, NULL, #0x20  ; true
    // 0xbc8d38: r17 = false
    //     0xbc8d38: add             x17, NULL, #0x30  ; false
    // 0xbc8d3c: csel            x1, x16, x17, gt
    // 0xbc8d40: StoreField: r3->field_8b = r1
    //     0xbc8d40: stur            w1, [x3, #0x8b]
    // 0xbc8d44: mov             x1, v0.d[0]
    // 0xbc8d48: and             x1, x1, #0x7fffffffffffffff
    // 0xbc8d4c: r17 = 9218868437227405312
    //     0xbc8d4c: mov             x17, #0x7ff0000000000000
    // 0xbc8d50: cmp             x1, x17
    // 0xbc8d54: b.eq            #0xbc8dd8
    // 0xbc8d58: fcmp            d0, d0
    // 0xbc8d5c: b.vs            #0xbc8dd8
    // 0xbc8d60: LoadField: r0 = r3->field_6f
    //     0xbc8d60: ldur            w0, [x3, #0x6f]
    // 0xbc8d64: DecompressPointer r0
    //     0xbc8d64: add             x0, x0, HEAP, lsl #32
    // 0xbc8d68: r1 = LoadClassIdInstr(r0)
    //     0xbc8d68: ldur            x1, [x0, #-1]
    //     0xbc8d6c: ubfx            x1, x1, #0xc, #0x14
    // 0xbc8d70: cmp             x1, #0xb19
    // 0xbc8d74: b.ne            #0xbc8d80
    // 0xbc8d78: fmul            d4, d0, d3
    // 0xbc8d7c: b               #0xbc8d88
    // 0xbc8d80: d4 = 250.000000
    //     0xbc8d80: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cf30] IMM: double(250) from 0x406f400000000000
    //     0xbc8d84: ldr             d4, [x17, #0xf30]
    // 0xbc8d88: r0 = inline_Allocate_Double()
    //     0xbc8d88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc8d8c: add             x0, x0, #0x10
    //     0xbc8d90: cmp             x1, x0
    //     0xbc8d94: b.ls            #0xbc8e8c
    //     0xbc8d98: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc8d9c: sub             x0, x0, #0xf
    //     0xbc8da0: mov             x1, #0xe19c
    //     0xbc8da4: movk            x1, #3, lsl #16
    //     0xbc8da8: stur            x1, [x0, #-1]
    // 0xbc8dac: dmb             ishst
    // 0xbc8db0: StoreField: r0->field_7 = d4
    //     0xbc8db0: stur            d4, [x0, #7]
    // 0xbc8db4: StoreField: r3->field_73 = r0
    //     0xbc8db4: stur            w0, [x3, #0x73]
    //     0xbc8db8: ldurb           w16, [x3, #-1]
    //     0xbc8dbc: ldurb           w17, [x0, #-1]
    //     0xbc8dc0: and             x16, x17, x16, lsr #2
    //     0xbc8dc4: tst             x16, HEAP, lsr #32
    //     0xbc8dc8: b.eq            #0xbc8dd0
    //     0xbc8dcc: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc8dd0: mov             v5.16b, v4.16b
    // 0xbc8dd4: b               #0xbc8de0
    // 0xbc8dd8: StoreField: r3->field_73 = r0
    //     0xbc8dd8: stur            w0, [x3, #0x73]
    // 0xbc8ddc: d5 = 0.000000
    //     0xbc8ddc: eor             v5.16b, v5.16b, v5.16b
    // 0xbc8de0: d4 = 2.000000
    //     0xbc8de0: fmov            d4, #2.00000000
    // 0xbc8de4: LoadField: r0 = r3->field_5b
    //     0xbc8de4: ldur            w0, [x3, #0x5b]
    // 0xbc8de8: DecompressPointer r0
    //     0xbc8de8: add             x0, x0, HEAP, lsl #32
    // 0xbc8dec: stur            x0, [fp, #-8]
    // 0xbc8df0: fmax            v6.2d, v3.2d, v2.2d
    // 0xbc8df4: stur            d6, [fp, #-0x40]
    // 0xbc8df8: fmin            v7.2d, v3.2d, v2.2d
    // 0xbc8dfc: stur            d7, [fp, #-0x38]
    // 0xbc8e00: fneg            d8, d2
    // 0xbc8e04: fmax            v2.2d, v3.2d, v8.2d
    // 0xbc8e08: stur            d2, [fp, #-0x30]
    // 0xbc8e0c: fadd            d3, d0, d7
    // 0xbc8e10: stur            d3, [fp, #-0x28]
    // 0xbc8e14: fmul            d8, d5, d4
    // 0xbc8e18: fadd            d4, d0, d8
    // 0xbc8e1c: stur            d4, [fp, #-0x20]
    // 0xbc8e20: fneg            d8, d5
    // 0xbc8e24: mov             x2, x3
    // 0xbc8e28: stur            d8, [fp, #-0x18]
    // 0xbc8e2c: r1 = Function 'childAfter':.
    //     0xbc8e2c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96200] AnonymousClosure: (0xbc80e4), in [dart:mixin_deduplication] _MixinApplication236&RenderBox&ContainerRenderObjectMixin::childAfter (0xbc8120)
    //     0xbc8e30: ldr             x1, [x1, #0x200]
    // 0xbc8e34: r0 = AllocateClosure()
    //     0xbc8e34: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc8e38: ldur            d0, [fp, #-0x28]
    // 0xbc8e3c: str             d0, [SP, #8]
    // 0xbc8e40: ldur            d0, [fp, #-0x40]
    // 0xbc8e44: str             d0, [SP]
    // 0xbc8e48: ldur            x1, [fp, #-0x10]
    // 0xbc8e4c: mov             x2, x0
    // 0xbc8e50: ldur            d0, [fp, #-0x18]
    // 0xbc8e54: ldur            x3, [fp, #-8]
    // 0xbc8e58: ldur            d1, [fp, #-0x50]
    // 0xbc8e5c: ldur            d2, [fp, #-0x30]
    // 0xbc8e60: ldur            d3, [fp, #-0x48]
    // 0xbc8e64: ldur            d4, [fp, #-0x38]
    // 0xbc8e68: ldur            d5, [fp, #-0x20]
    // 0xbc8e6c: r5 = Instance_GrowthDirection
    //     0xbc8e6c: add             x5, PP, #0x96, lsl #12  ; [pp+0x961d8] Obj!GrowthDirection@12c4281
    //     0xbc8e70: ldr             x5, [x5, #0x1d8]
    // 0xbc8e74: r0 = layoutChildSequence()
    //     0xbc8e74: bl              #0xbc7638  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::layoutChildSequence
    // 0xbc8e78: LeaveFrame
    //     0xbc8e78: mov             SP, fp
    //     0xbc8e7c: ldp             fp, lr, [SP], #0x10
    // 0xbc8e80: ret
    //     0xbc8e80: ret             
    // 0xbc8e84: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc8e84: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc8e88: b               #0xbc8d28
    // 0xbc8e8c: stp             q3, q4, [SP, #-0x20]!
    // 0xbc8e90: stp             q1, q2, [SP, #-0x20]!
    // 0xbc8e94: SaveReg d0
    //     0xbc8e94: str             q0, [SP, #-0x10]!
    // 0xbc8e98: SaveReg r3
    //     0xbc8e98: str             x3, [SP, #-8]!
    // 0xbc8e9c: r0 = AllocateDouble()
    //     0xbc8e9c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc8ea0: RestoreReg r3
    //     0xbc8ea0: ldr             x3, [SP], #8
    // 0xbc8ea4: RestoreReg d0
    //     0xbc8ea4: ldr             q0, [SP], #0x10
    // 0xbc8ea8: ldp             q1, q2, [SP], #0x20
    // 0xbc8eac: ldp             q3, q4, [SP], #0x20
    // 0xbc8eb0: b               #0xbc8db0
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf1c34, size: 0x98
    // 0xbf1c34: EnterFrame
    //     0xbf1c34: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1c38: mov             fp, SP
    // 0xbf1c3c: AllocStack(0x18)
    //     0xbf1c3c: sub             SP, SP, #0x18
    // 0xbf1c40: SetupParameters(RenderShrinkWrappingViewport this /* r1 => r5, fp-0x8 */, dynamic _ /* r2 => r4, fp-0x10 */, dynamic _ /* r3 => r3, fp-0x18 */)
    //     0xbf1c40: mov             x5, x1
    //     0xbf1c44: mov             x4, x2
    //     0xbf1c48: stur            x1, [fp, #-8]
    //     0xbf1c4c: stur            x2, [fp, #-0x10]
    //     0xbf1c50: stur            x3, [fp, #-0x18]
    // 0xbf1c54: CheckStackOverflow
    //     0xbf1c54: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1c58: cmp             SP, x16
    //     0xbf1c5c: b.ls            #0xbf1cc4
    // 0xbf1c60: mov             x0, x4
    // 0xbf1c64: r2 = Null
    //     0xbf1c64: mov             x2, NULL
    // 0xbf1c68: r1 = Null
    //     0xbf1c68: mov             x1, NULL
    // 0xbf1c6c: r4 = LoadClassIdInstr(r0)
    //     0xbf1c6c: ldur            x4, [x0, #-1]
    //     0xbf1c70: ubfx            x4, x4, #0xc, #0x14
    // 0xbf1c74: r17 = -4688
    //     0xbf1c74: mov             x17, #-0x1250
    // 0xbf1c78: add             x4, x4, x17
    // 0xbf1c7c: cmp             x4, #0xf
    // 0xbf1c80: b.ls            #0xbf1c98
    // 0xbf1c84: r8 = RenderSliver
    //     0xbf1c84: add             x8, PP, #0x96, lsl #12  ; [pp+0x961a8] Type: RenderSliver
    //     0xbf1c88: ldr             x8, [x8, #0x1a8]
    // 0xbf1c8c: r3 = Null
    //     0xbf1c8c: add             x3, PP, #0x96, lsl #12  ; [pp+0x961b0] Null
    //     0xbf1c90: ldr             x3, [x3, #0x1b0]
    // 0xbf1c94: r0 = RenderSliver()
    //     0xbf1c94: bl              #0xa16a30  ; IsType_RenderSliver_Stub
    // 0xbf1c98: ldur            x1, [fp, #-8]
    // 0xbf1c9c: ldur            x2, [fp, #-0x10]
    // 0xbf1ca0: r0 = paintOffsetOf()
    //     0xbf1ca0: bl              #0x124ba14  ; [package:flutter/src/rendering/viewport.dart] RenderShrinkWrappingViewport::paintOffsetOf
    // 0xbf1ca4: LoadField: d0 = r0->field_7
    //     0xbf1ca4: ldur            d0, [x0, #7]
    // 0xbf1ca8: LoadField: d1 = r0->field_f
    //     0xbf1ca8: ldur            d1, [x0, #0xf]
    // 0xbf1cac: ldur            x1, [fp, #-0x18]
    // 0xbf1cb0: r0 = translateByDouble()
    //     0xbf1cb0: bl              #0xbbded8  ; [package:vector_math/vector_math_64.dart] Matrix4::translateByDouble
    // 0xbf1cb4: r0 = Null
    //     0xbf1cb4: mov             x0, NULL
    // 0xbf1cb8: LeaveFrame
    //     0xbf1cb8: mov             SP, fp
    //     0xbf1cbc: ldp             fp, lr, [SP], #0x10
    // 0xbf1cc0: ret
    //     0xbf1cc0: ret             
    // 0xbf1cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf1cc4: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1cc8: b               #0xbf1c60
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0dd98, size: 0xa8
    // 0xc0dd98: EnterFrame
    //     0xc0dd98: stp             fp, lr, [SP, #-0x10]!
    //     0xc0dd9c: mov             fp, SP
    // 0xc0dda0: AllocStack(0x8)
    //     0xc0dda0: sub             SP, SP, #8
    // 0xc0dda4: SetupParameters(RenderShrinkWrappingViewport this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0dda4: mov             x0, x2
    //     0xc0dda8: mov             x4, x1
    //     0xc0ddac: mov             x3, x2
    //     0xc0ddb0: stur            x2, [fp, #-8]
    // 0xc0ddb4: r2 = Null
    //     0xc0ddb4: mov             x2, NULL
    // 0xc0ddb8: r1 = Null
    //     0xc0ddb8: mov             x1, NULL
    // 0xc0ddbc: r4 = 60
    //     0xc0ddbc: mov             x4, #0x3c
    // 0xc0ddc0: branchIfSmi(r0, 0xc0ddcc)
    //     0xc0ddc0: tbz             w0, #0, #0xc0ddcc
    // 0xc0ddc4: r4 = LoadClassIdInstr(r0)
    //     0xc0ddc4: ldur            x4, [x0, #-1]
    //     0xc0ddc8: ubfx            x4, x4, #0xc, #0x14
    // 0xc0ddcc: r17 = -4679
    //     0xc0ddcc: mov             x17, #-0x1247
    // 0xc0ddd0: add             x4, x4, x17
    // 0xc0ddd4: cmp             x4, #0x128
    // 0xc0ddd8: b.ls            #0xc0ddec
    // 0xc0dddc: r8 = RenderObject
    //     0xc0dddc: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0xc0dde0: r3 = Null
    //     0xc0dde0: add             x3, PP, #0x96, lsl #12  ; [pp+0x96328] Null
    //     0xc0dde4: ldr             x3, [x3, #0x328]
    // 0xc0dde8: r0 = RenderObject()
    //     0xc0dde8: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0xc0ddec: ldur            x0, [fp, #-8]
    // 0xc0ddf0: LoadField: r1 = r0->field_7
    //     0xc0ddf0: ldur            w1, [x0, #7]
    // 0xc0ddf4: DecompressPointer r1
    //     0xc0ddf4: add             x1, x1, HEAP, lsl #32
    // 0xc0ddf8: r2 = LoadClassIdInstr(r1)
    //     0xc0ddf8: ldur            x2, [x1, #-1]
    //     0xc0ddfc: ubfx            x2, x2, #0xc, #0x14
    // 0xc0de00: r17 = 4186
    //     0xc0de00: mov             x17, #0x105a
    // 0xc0de04: cmp             x2, x17
    // 0xc0de08: b.eq            #0xc0de30
    // 0xc0de0c: r0 = SliverLogicalContainerParentData()
    //     0xc0de0c: bl              #0xc0de40  ; AllocateSliverLogicalContainerParentDataStub -> SliverLogicalContainerParentData (size=0x14)
    // 0xc0de10: ldur            x1, [fp, #-8]
    // 0xc0de14: StoreField: r1->field_7 = r0
    //     0xc0de14: stur            w0, [x1, #7]
    //     0xc0de18: ldurb           w16, [x1, #-1]
    //     0xc0de1c: ldurb           w17, [x0, #-1]
    //     0xc0de20: and             x16, x17, x16, lsr #2
    //     0xc0de24: tst             x16, HEAP, lsr #32
    //     0xc0de28: b.eq            #0xc0de30
    //     0xc0de2c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0de30: r0 = Null
    //     0xc0de30: mov             x0, NULL
    // 0xc0de34: LeaveFrame
    //     0xc0de34: mov             SP, fp
    //     0xc0de38: ldp             fp, lr, [SP], #0x10
    // 0xc0de3c: ret
    //     0xc0de3c: ret             
  }
  _ RenderShrinkWrappingViewport(/* No info */) {
    // ** addr: 0x11cbc70, size: 0x48
    // 0x11cbc70: EnterFrame
    //     0x11cbc70: stp             fp, lr, [SP, #-0x10]!
    //     0x11cbc74: mov             fp, SP
    // 0x11cbc78: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0x11cbc7c: r0 = false
    //     0x11cbc7c: add             x0, NULL, #0x30  ; false
    // 0x11cbc80: CheckStackOverflow
    //     0x11cbc80: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cbc84: cmp             SP, x16
    //     0x11cbc88: b.ls            #0x11cbcb0
    // 0x11cbc8c: StoreField: r1->field_83 = r4
    //     0x11cbc8c: stur            w4, [x1, #0x83]
    // 0x11cbc90: StoreField: r1->field_87 = r4
    //     0x11cbc90: stur            w4, [x1, #0x87]
    // 0x11cbc94: StoreField: r1->field_8b = r0
    //     0x11cbc94: stur            w0, [x1, #0x8b]
    // 0x11cbc98: r7 = Null
    //     0x11cbc98: mov             x7, NULL
    // 0x11cbc9c: r0 = RenderViewportBase()
    //     0x11cbc9c: bl              #0x11cba44  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::RenderViewportBase
    // 0x11cbca0: r0 = Null
    //     0x11cbca0: mov             x0, NULL
    // 0x11cbca4: LeaveFrame
    //     0x11cbca4: mov             SP, fp
    //     0x11cbca8: ldp             fp, lr, [SP], #0x10
    // 0x11cbcac: ret
    //     0x11cbcac: ret             
    // 0x11cbcb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cbcb0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cbcb4: b               #0x11cbc8c
  }
  _ updateOutOfBandData(/* No info */) {
    // ** addr: 0x124b8d0, size: 0x144
    // 0x124b8d0: EnterFrame
    //     0x124b8d0: stp             fp, lr, [SP, #-0x10]!
    //     0x124b8d4: mov             fp, SP
    // 0x124b8d8: LoadField: r2 = r1->field_83
    //     0x124b8d8: ldur            w2, [x1, #0x83]
    // 0x124b8dc: DecompressPointer r2
    //     0x124b8dc: add             x2, x2, HEAP, lsl #32
    // 0x124b8e0: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124b8e4: cmp             w2, w16
    // 0x124b8e8: b.eq            #0x124b9cc
    // 0x124b8ec: LoadField: d0 = r3->field_7
    //     0x124b8ec: ldur            d0, [x3, #7]
    // 0x124b8f0: LoadField: d1 = r2->field_7
    //     0x124b8f0: ldur            d1, [x2, #7]
    // 0x124b8f4: fadd            d2, d1, d0
    // 0x124b8f8: r0 = inline_Allocate_Double()
    //     0x124b8f8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x124b8fc: add             x0, x0, #0x10
    //     0x124b900: cmp             x2, x0
    //     0x124b904: b.ls            #0x124b9d8
    //     0x124b908: str             x0, [THR, #0x60]  ; THR::top
    //     0x124b90c: sub             x0, x0, #0xf
    //     0x124b910: mov             x2, #0xe19c
    //     0x124b914: movk            x2, #3, lsl #16
    //     0x124b918: stur            x2, [x0, #-1]
    // 0x124b91c: dmb             ishst
    // 0x124b920: StoreField: r0->field_7 = d2
    //     0x124b920: stur            d2, [x0, #7]
    // 0x124b924: StoreField: r1->field_83 = r0
    //     0x124b924: stur            w0, [x1, #0x83]
    //     0x124b928: ldurb           w16, [x1, #-1]
    //     0x124b92c: ldurb           w17, [x0, #-1]
    //     0x124b930: and             x16, x17, x16, lsr #2
    //     0x124b934: tst             x16, HEAP, lsr #32
    //     0x124b938: b.eq            #0x124b940
    //     0x124b93c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x124b940: LoadField: r2 = r3->field_43
    //     0x124b940: ldur            w2, [x3, #0x43]
    // 0x124b944: DecompressPointer r2
    //     0x124b944: add             x2, x2, HEAP, lsl #32
    // 0x124b948: tbnz            w2, #4, #0x124b954
    // 0x124b94c: r2 = true
    //     0x124b94c: add             x2, NULL, #0x20  ; true
    // 0x124b950: StoreField: r1->field_8b = r2
    //     0x124b950: stur            w2, [x1, #0x8b]
    // 0x124b954: LoadField: r2 = r1->field_87
    //     0x124b954: ldur            w2, [x1, #0x87]
    // 0x124b958: DecompressPointer r2
    //     0x124b958: add             x2, x2, HEAP, lsl #32
    // 0x124b95c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124b960: cmp             w2, w16
    // 0x124b964: b.eq            #0x124b9f0
    // 0x124b968: LoadField: d0 = r3->field_27
    //     0x124b968: ldur            d0, [x3, #0x27]
    // 0x124b96c: LoadField: d1 = r2->field_7
    //     0x124b96c: ldur            d1, [x2, #7]
    // 0x124b970: fadd            d2, d1, d0
    // 0x124b974: r0 = inline_Allocate_Double()
    //     0x124b974: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x124b978: add             x0, x0, #0x10
    //     0x124b97c: cmp             x2, x0
    //     0x124b980: b.ls            #0x124b9fc
    //     0x124b984: str             x0, [THR, #0x60]  ; THR::top
    //     0x124b988: sub             x0, x0, #0xf
    //     0x124b98c: mov             x2, #0xe19c
    //     0x124b990: movk            x2, #3, lsl #16
    //     0x124b994: stur            x2, [x0, #-1]
    // 0x124b998: dmb             ishst
    // 0x124b99c: StoreField: r0->field_7 = d2
    //     0x124b99c: stur            d2, [x0, #7]
    // 0x124b9a0: StoreField: r1->field_87 = r0
    //     0x124b9a0: stur            w0, [x1, #0x87]
    //     0x124b9a4: ldurb           w16, [x1, #-1]
    //     0x124b9a8: ldurb           w17, [x0, #-1]
    //     0x124b9ac: and             x16, x17, x16, lsr #2
    //     0x124b9b0: tst             x16, HEAP, lsr #32
    //     0x124b9b4: b.eq            #0x124b9bc
    //     0x124b9b8: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x124b9bc: r0 = Null
    //     0x124b9bc: mov             x0, NULL
    // 0x124b9c0: LeaveFrame
    //     0x124b9c0: mov             SP, fp
    //     0x124b9c4: ldp             fp, lr, [SP], #0x10
    // 0x124b9c8: ret
    //     0x124b9c8: ret             
    // 0x124b9cc: r9 = _maxScrollExtent
    //     0x124b9cc: add             x9, PP, #0x96, lsl #12  ; [pp+0x961f8] Field <RenderShrinkWrappingViewport._maxScrollExtent@616057554>: late (offset: 0x84)
    //     0x124b9d0: ldr             x9, [x9, #0x1f8]
    // 0x124b9d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x124b9d4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x124b9d8: SaveReg d2
    //     0x124b9d8: str             q2, [SP, #-0x10]!
    // 0x124b9dc: stp             x1, x3, [SP, #-0x10]!
    // 0x124b9e0: r0 = AllocateDouble()
    //     0x124b9e0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x124b9e4: ldp             x1, x3, [SP], #0x10
    // 0x124b9e8: RestoreReg d2
    //     0x124b9e8: ldr             q2, [SP], #0x10
    // 0x124b9ec: b               #0x124b920
    // 0x124b9f0: r9 = _shrinkWrapExtent
    //     0x124b9f0: add             x9, PP, #0x96, lsl #12  ; [pp+0x961f0] Field <RenderShrinkWrappingViewport._shrinkWrapExtent@616057554>: late (offset: 0x88)
    //     0x124b9f4: ldr             x9, [x9, #0x1f0]
    // 0x124b9f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x124b9f8: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x124b9fc: SaveReg d2
    //     0x124b9fc: str             q2, [SP, #-0x10]!
    // 0x124ba00: SaveReg r1
    //     0x124ba00: str             x1, [SP, #-8]!
    // 0x124ba04: r0 = AllocateDouble()
    //     0x124ba04: bl              #0x13df878  ; AllocateDoubleStub
    // 0x124ba08: RestoreReg r1
    //     0x124ba08: ldr             x1, [SP], #8
    // 0x124ba0c: RestoreReg d2
    //     0x124ba0c: ldr             q2, [SP], #0x10
    // 0x124ba10: b               #0x124b99c
  }
  _ paintOffsetOf(/* No info */) {
    // ** addr: 0x124ba14, size: 0xbc
    // 0x124ba14: EnterFrame
    //     0x124ba14: stp             fp, lr, [SP, #-0x10]!
    //     0x124ba18: mov             fp, SP
    // 0x124ba1c: AllocStack(0x18)
    //     0x124ba1c: sub             SP, SP, #0x18
    // 0x124ba20: SetupParameters(RenderShrinkWrappingViewport this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x124ba20: mov             x4, x1
    //     0x124ba24: mov             x3, x2
    //     0x124ba28: stur            x1, [fp, #-0x10]
    //     0x124ba2c: stur            x2, [fp, #-0x18]
    // 0x124ba30: CheckStackOverflow
    //     0x124ba30: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124ba34: cmp             SP, x16
    //     0x124ba38: b.ls            #0x124bac0
    // 0x124ba3c: LoadField: r5 = r3->field_7
    //     0x124ba3c: ldur            w5, [x3, #7]
    // 0x124ba40: DecompressPointer r5
    //     0x124ba40: add             x5, x5, HEAP, lsl #32
    // 0x124ba44: stur            x5, [fp, #-8]
    // 0x124ba48: cmp             w5, NULL
    // 0x124ba4c: b.eq            #0x124bac8
    // 0x124ba50: mov             x0, x5
    // 0x124ba54: r2 = Null
    //     0x124ba54: mov             x2, NULL
    // 0x124ba58: r1 = Null
    //     0x124ba58: mov             x1, NULL
    // 0x124ba5c: r4 = LoadClassIdInstr(r0)
    //     0x124ba5c: ldur            x4, [x0, #-1]
    //     0x124ba60: ubfx            x4, x4, #0xc, #0x14
    // 0x124ba64: r17 = -4183
    //     0x124ba64: mov             x17, #-0x1057
    // 0x124ba68: add             x4, x4, x17
    // 0x124ba6c: cmp             x4, #3
    // 0x124ba70: b.ls            #0x124ba88
    // 0x124ba74: r8 = SliverLogicalParentData
    //     0x124ba74: add             x8, PP, #0x96, lsl #12  ; [pp+0x961c0] Type: SliverLogicalParentData
    //     0x124ba78: ldr             x8, [x8, #0x1c0]
    // 0x124ba7c: r3 = Null
    //     0x124ba7c: add             x3, PP, #0x96, lsl #12  ; [pp+0x961c8] Null
    //     0x124ba80: ldr             x3, [x3, #0x1c8]
    // 0x124ba84: r0 = DefaultTypeTest()
    //     0x124ba84: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x124ba88: ldur            x0, [fp, #-8]
    // 0x124ba8c: LoadField: r1 = r0->field_7
    //     0x124ba8c: ldur            w1, [x0, #7]
    // 0x124ba90: DecompressPointer r1
    //     0x124ba90: add             x1, x1, HEAP, lsl #32
    // 0x124ba94: cmp             w1, NULL
    // 0x124ba98: b.eq            #0x124bacc
    // 0x124ba9c: LoadField: d0 = r1->field_7
    //     0x124ba9c: ldur            d0, [x1, #7]
    // 0x124baa0: ldur            x1, [fp, #-0x10]
    // 0x124baa4: ldur            x2, [fp, #-0x18]
    // 0x124baa8: r3 = Instance_GrowthDirection
    //     0x124baa8: add             x3, PP, #0x96, lsl #12  ; [pp+0x961d8] Obj!GrowthDirection@12c4281
    //     0x124baac: ldr             x3, [x3, #0x1d8]
    // 0x124bab0: r0 = computeAbsolutePaintOffset()
    //     0x124bab0: bl              #0xbc7e20  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::computeAbsolutePaintOffset
    // 0x124bab4: LeaveFrame
    //     0x124bab4: mov             SP, fp
    //     0x124bab8: ldp             fp, lr, [SP], #0x10
    // 0x124babc: ret
    //     0x124babc: ret             
    // 0x124bac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124bac0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124bac4: b               #0x124ba3c
    // 0x124bac8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124bac8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124bacc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124bacc: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ scrollOffsetOf(/* No info */) {
    // ** addr: 0x124c1a8, size: 0x14c
    // 0x124c1a8: EnterFrame
    //     0x124c1a8: stp             fp, lr, [SP, #-0x10]!
    //     0x124c1ac: mov             fp, SP
    // 0x124c1b0: AllocStack(0x48)
    //     0x124c1b0: sub             SP, SP, #0x48
    // 0x124c1b4: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x124c1b4: stur            x2, [fp, #-0x18]
    //     0x124c1b8: stur            d0, [fp, #-0x30]
    // 0x124c1bc: CheckStackOverflow
    //     0x124c1bc: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124c1c0: cmp             SP, x16
    //     0x124c1c4: b.ls            #0x124c2d8
    // 0x124c1c8: LoadField: r0 = r1->field_5b
    //     0x124c1c8: ldur            w0, [x1, #0x5b]
    // 0x124c1cc: DecompressPointer r0
    //     0x124c1cc: add             x0, x0, HEAP, lsl #32
    // 0x124c1d0: LoadField: r3 = r1->field_4f
    //     0x124c1d0: ldur            w3, [x1, #0x4f]
    // 0x124c1d4: DecompressPointer r3
    //     0x124c1d4: add             x3, x3, HEAP, lsl #32
    // 0x124c1d8: stur            x3, [fp, #-0x10]
    // 0x124c1dc: mov             x1, x0
    // 0x124c1e0: d1 = 0.000000
    //     0x124c1e0: eor             v1.16b, v1.16b, v1.16b
    // 0x124c1e4: stur            x1, [fp, #-8]
    // 0x124c1e8: stur            d1, [fp, #-0x28]
    // 0x124c1ec: CheckStackOverflow
    //     0x124c1ec: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124c1f0: cmp             SP, x16
    //     0x124c1f4: b.ls            #0x124c2e0
    // 0x124c1f8: r0 = LoadClassIdInstr(r1)
    //     0x124c1f8: ldur            x0, [x1, #-1]
    //     0x124c1fc: ubfx            x0, x0, #0xc, #0x14
    // 0x124c200: stp             x2, x1, [SP]
    // 0x124c204: mov             lr, x0
    // 0x124c208: ldr             lr, [x21, lr, lsl #3]
    // 0x124c20c: blr             lr
    // 0x124c210: tbz             w0, #4, #0x124c2bc
    // 0x124c214: ldur            d0, [fp, #-0x28]
    // 0x124c218: ldur            x0, [fp, #-8]
    // 0x124c21c: cmp             w0, NULL
    // 0x124c220: b.eq            #0x124c2e8
    // 0x124c224: LoadField: r1 = r0->field_47
    //     0x124c224: ldur            w1, [x0, #0x47]
    // 0x124c228: DecompressPointer r1
    //     0x124c228: add             x1, x1, HEAP, lsl #32
    // 0x124c22c: cmp             w1, NULL
    // 0x124c230: b.eq            #0x124c2ec
    // 0x124c234: LoadField: d1 = r1->field_7
    //     0x124c234: ldur            d1, [x1, #7]
    // 0x124c238: fadd            d2, d0, d1
    // 0x124c23c: stur            d2, [fp, #-0x38]
    // 0x124c240: LoadField: r3 = r0->field_7
    //     0x124c240: ldur            w3, [x0, #7]
    // 0x124c244: DecompressPointer r3
    //     0x124c244: add             x3, x3, HEAP, lsl #32
    // 0x124c248: stur            x3, [fp, #-0x20]
    // 0x124c24c: cmp             w3, NULL
    // 0x124c250: b.eq            #0x124c2f0
    // 0x124c254: mov             x0, x3
    // 0x124c258: ldur            x2, [fp, #-0x10]
    // 0x124c25c: r1 = Null
    //     0x124c25c: mov             x1, NULL
    // 0x124c260: cmp             w2, NULL
    // 0x124c264: b.eq            #0x124c288
    // 0x124c268: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x124c268: ldur            w4, [x2, #0x17]
    // 0x124c26c: DecompressPointer r4
    //     0x124c26c: add             x4, x4, HEAP, lsl #32
    // 0x124c270: r8 = X0 bound ContainerParentDataMixin
    //     0x124c270: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x124c274: ldr             x8, [x8, #0x218]
    // 0x124c278: LoadField: r9 = r4->field_7
    //     0x124c278: ldur            x9, [x4, #7]
    // 0x124c27c: r3 = Null
    //     0x124c27c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1138] Null
    //     0x124c280: ldr             x3, [x3, #0x138]
    // 0x124c284: blr             x9
    // 0x124c288: ldur            x1, [fp, #-0x20]
    // 0x124c28c: r0 = LoadClassIdInstr(r1)
    //     0x124c28c: ldur            x0, [x1, #-1]
    //     0x124c290: ubfx            x0, x0, #0xc, #0x14
    // 0x124c294: r0 = GDT[cid_x0 + 0xbf3a]()
    //     0x124c294: mov             x17, #0xbf3a
    //     0x124c298: add             lr, x0, x17
    //     0x124c29c: ldr             lr, [x21, lr, lsl #3]
    //     0x124c2a0: blr             lr
    // 0x124c2a4: ldur            d1, [fp, #-0x38]
    // 0x124c2a8: mov             x1, x0
    // 0x124c2ac: ldur            x2, [fp, #-0x18]
    // 0x124c2b0: ldur            d0, [fp, #-0x30]
    // 0x124c2b4: ldur            x3, [fp, #-0x10]
    // 0x124c2b8: b               #0x124c1e4
    // 0x124c2bc: ldur            d1, [fp, #-0x30]
    // 0x124c2c0: ldur            d0, [fp, #-0x28]
    // 0x124c2c4: fadd            d2, d0, d1
    // 0x124c2c8: mov             v0.16b, v2.16b
    // 0x124c2cc: LeaveFrame
    //     0x124c2cc: mov             SP, fp
    //     0x124c2d0: ldp             fp, lr, [SP], #0x10
    // 0x124c2d4: ret
    //     0x124c2d4: ret             
    // 0x124c2d8: r0 = StackOverflowSharedWithFPURegs()
    //     0x124c2d8: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x124c2dc: b               #0x124c1c8
    // 0x124c2e0: r0 = StackOverflowSharedWithFPURegs()
    //     0x124c2e0: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x124c2e4: b               #0x124c1f8
    // 0x124c2e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c2e8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124c2ec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c2ec: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124c2f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c2f0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ maxScrollObstructionExtentBefore(/* No info */) {
    // ** addr: 0x124e270, size: 0x11c
    // 0x124e270: EnterFrame
    //     0x124e270: stp             fp, lr, [SP, #-0x10]!
    //     0x124e274: mov             fp, SP
    // 0x124e278: AllocStack(0x30)
    //     0x124e278: sub             SP, SP, #0x30
    // 0x124e27c: SetupParameters(dynamic _ /* r2 => r2, fp-0x18 */)
    //     0x124e27c: stur            x2, [fp, #-0x18]
    // 0x124e280: CheckStackOverflow
    //     0x124e280: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124e284: cmp             SP, x16
    //     0x124e288: b.ls            #0x124e370
    // 0x124e28c: LoadField: r0 = r1->field_5b
    //     0x124e28c: ldur            w0, [x1, #0x5b]
    // 0x124e290: DecompressPointer r0
    //     0x124e290: add             x0, x0, HEAP, lsl #32
    // 0x124e294: LoadField: r3 = r1->field_4f
    //     0x124e294: ldur            w3, [x1, #0x4f]
    // 0x124e298: DecompressPointer r3
    //     0x124e298: add             x3, x3, HEAP, lsl #32
    // 0x124e29c: stur            x3, [fp, #-0x10]
    // 0x124e2a0: mov             x1, x0
    // 0x124e2a4: stur            x1, [fp, #-8]
    // 0x124e2a8: CheckStackOverflow
    //     0x124e2a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124e2ac: cmp             SP, x16
    //     0x124e2b0: b.ls            #0x124e378
    // 0x124e2b4: r0 = LoadClassIdInstr(r1)
    //     0x124e2b4: ldur            x0, [x1, #-1]
    //     0x124e2b8: ubfx            x0, x0, #0xc, #0x14
    // 0x124e2bc: stp             x2, x1, [SP]
    // 0x124e2c0: mov             lr, x0
    // 0x124e2c4: ldr             lr, [x21, lr, lsl #3]
    // 0x124e2c8: blr             lr
    // 0x124e2cc: tbz             w0, #4, #0x124e360
    // 0x124e2d0: ldur            x0, [fp, #-8]
    // 0x124e2d4: cmp             w0, NULL
    // 0x124e2d8: b.eq            #0x124e380
    // 0x124e2dc: LoadField: r1 = r0->field_47
    //     0x124e2dc: ldur            w1, [x0, #0x47]
    // 0x124e2e0: DecompressPointer r1
    //     0x124e2e0: add             x1, x1, HEAP, lsl #32
    // 0x124e2e4: cmp             w1, NULL
    // 0x124e2e8: b.eq            #0x124e384
    // 0x124e2ec: LoadField: r3 = r0->field_7
    //     0x124e2ec: ldur            w3, [x0, #7]
    // 0x124e2f0: DecompressPointer r3
    //     0x124e2f0: add             x3, x3, HEAP, lsl #32
    // 0x124e2f4: stur            x3, [fp, #-0x20]
    // 0x124e2f8: cmp             w3, NULL
    // 0x124e2fc: b.eq            #0x124e388
    // 0x124e300: mov             x0, x3
    // 0x124e304: ldur            x2, [fp, #-0x10]
    // 0x124e308: r1 = Null
    //     0x124e308: mov             x1, NULL
    // 0x124e30c: cmp             w2, NULL
    // 0x124e310: b.eq            #0x124e334
    // 0x124e314: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x124e314: ldur            w4, [x2, #0x17]
    // 0x124e318: DecompressPointer r4
    //     0x124e318: add             x4, x4, HEAP, lsl #32
    // 0x124e31c: r8 = X0 bound ContainerParentDataMixin
    //     0x124e31c: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x124e320: ldr             x8, [x8, #0x218]
    // 0x124e324: LoadField: r9 = r4->field_7
    //     0x124e324: ldur            x9, [x4, #7]
    // 0x124e328: r3 = Null
    //     0x124e328: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1128] Null
    //     0x124e32c: ldr             x3, [x3, #0x128]
    // 0x124e330: blr             x9
    // 0x124e334: ldur            x1, [fp, #-0x20]
    // 0x124e338: r0 = LoadClassIdInstr(r1)
    //     0x124e338: ldur            x0, [x1, #-1]
    //     0x124e33c: ubfx            x0, x0, #0xc, #0x14
    // 0x124e340: r0 = GDT[cid_x0 + 0xbf3a]()
    //     0x124e340: mov             x17, #0xbf3a
    //     0x124e344: add             lr, x0, x17
    //     0x124e348: ldr             lr, [x21, lr, lsl #3]
    //     0x124e34c: blr             lr
    // 0x124e350: mov             x1, x0
    // 0x124e354: ldur            x2, [fp, #-0x18]
    // 0x124e358: ldur            x3, [fp, #-0x10]
    // 0x124e35c: b               #0x124e2a4
    // 0x124e360: d0 = 0.000000
    //     0x124e360: eor             v0.16b, v0.16b, v0.16b
    // 0x124e364: LeaveFrame
    //     0x124e364: mov             SP, fp
    //     0x124e368: ldp             fp, lr, [SP], #0x10
    // 0x124e36c: ret
    //     0x124e36c: ret             
    // 0x124e370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124e370: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124e374: b               #0x124e28c
    // 0x124e378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124e378: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124e37c: b               #0x124e2b4
    // 0x124e380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e380: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124e384: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e384: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124e388: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e388: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeChildMainAxisPosition(/* No info */) {
    // ** addr: 0x124e94c, size: 0x27c
    // 0x124e94c: EnterFrame
    //     0x124e94c: stp             fp, lr, [SP, #-0x10]!
    //     0x124e950: mov             fp, SP
    // 0x124e954: AllocStack(0x28)
    //     0x124e954: sub             SP, SP, #0x28
    // 0x124e958: SetupParameters(RenderShrinkWrappingViewport this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x28 */)
    //     0x124e958: mov             x4, x1
    //     0x124e95c: mov             x3, x2
    //     0x124e960: stur            x1, [fp, #-0x10]
    //     0x124e964: stur            x2, [fp, #-0x18]
    //     0x124e968: stur            d0, [fp, #-0x28]
    // 0x124e96c: CheckStackOverflow
    //     0x124e96c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124e970: cmp             SP, x16
    //     0x124e974: b.ls            #0x124eb88
    // 0x124e978: LoadField: r5 = r3->field_7
    //     0x124e978: ldur            w5, [x3, #7]
    // 0x124e97c: DecompressPointer r5
    //     0x124e97c: add             x5, x5, HEAP, lsl #32
    // 0x124e980: stur            x5, [fp, #-8]
    // 0x124e984: cmp             w5, NULL
    // 0x124e988: b.eq            #0x124eb90
    // 0x124e98c: mov             x0, x5
    // 0x124e990: r2 = Null
    //     0x124e990: mov             x2, NULL
    // 0x124e994: r1 = Null
    //     0x124e994: mov             x1, NULL
    // 0x124e998: r4 = LoadClassIdInstr(r0)
    //     0x124e998: ldur            x4, [x0, #-1]
    //     0x124e99c: ubfx            x4, x4, #0xc, #0x14
    // 0x124e9a0: r17 = -4183
    //     0x124e9a0: mov             x17, #-0x1057
    // 0x124e9a4: add             x4, x4, x17
    // 0x124e9a8: cmp             x4, #3
    // 0x124e9ac: b.ls            #0x124e9c4
    // 0x124e9b0: r8 = SliverLogicalParentData
    //     0x124e9b0: add             x8, PP, #0x96, lsl #12  ; [pp+0x961c0] Type: SliverLogicalParentData
    //     0x124e9b4: ldr             x8, [x8, #0x1c0]
    // 0x124e9b8: r3 = Null
    //     0x124e9b8: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1108] Null
    //     0x124e9bc: ldr             x3, [x3, #0x108]
    // 0x124e9c0: r0 = DefaultTypeTest()
    //     0x124e9c0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x124e9c4: ldur            x0, [fp, #-8]
    // 0x124e9c8: LoadField: r3 = r0->field_7
    //     0x124e9c8: ldur            w3, [x0, #7]
    // 0x124e9cc: DecompressPointer r3
    //     0x124e9cc: add             x3, x3, HEAP, lsl #32
    // 0x124e9d0: stur            x3, [fp, #-0x20]
    // 0x124e9d4: cmp             w3, NULL
    // 0x124e9d8: b.eq            #0x124eb94
    // 0x124e9dc: ldur            x0, [fp, #-0x18]
    // 0x124e9e0: LoadField: r4 = r0->field_27
    //     0x124e9e0: ldur            w4, [x0, #0x27]
    // 0x124e9e4: DecompressPointer r4
    //     0x124e9e4: add             x4, x4, HEAP, lsl #32
    // 0x124e9e8: stur            x4, [fp, #-8]
    // 0x124e9ec: cmp             w4, NULL
    // 0x124e9f0: b.eq            #0x124eb6c
    // 0x124e9f4: mov             x0, x4
    // 0x124e9f8: r2 = Null
    //     0x124e9f8: mov             x2, NULL
    // 0x124e9fc: r1 = Null
    //     0x124e9fc: mov             x1, NULL
    // 0x124ea00: r4 = LoadClassIdInstr(r0)
    //     0x124ea00: ldur            x4, [x0, #-1]
    //     0x124ea04: ubfx            x4, x4, #0xc, #0x14
    // 0x124ea08: cmp             x4, #0xb45
    // 0x124ea0c: b.eq            #0x124ea24
    // 0x124ea10: r8 = SliverConstraints
    //     0x124ea10: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x124ea14: ldr             x8, [x8, #0x3c0]
    // 0x124ea18: r3 = Null
    //     0x124ea18: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1118] Null
    //     0x124ea1c: ldr             x3, [x3, #0x118]
    // 0x124ea20: r0 = DefaultTypeTest()
    //     0x124ea20: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x124ea24: ldur            x0, [fp, #-8]
    // 0x124ea28: LoadField: r1 = r0->field_7
    //     0x124ea28: ldur            w1, [x0, #7]
    // 0x124ea2c: DecompressPointer r1
    //     0x124ea2c: add             x1, x1, HEAP, lsl #32
    // 0x124ea30: LoadField: r2 = r0->field_b
    //     0x124ea30: ldur            w2, [x0, #0xb]
    // 0x124ea34: DecompressPointer r2
    //     0x124ea34: add             x2, x2, HEAP, lsl #32
    // 0x124ea38: r0 = applyGrowthDirectionToAxisDirection()
    //     0x124ea38: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x124ea3c: r16 = Instance_AxisDirection
    //     0x124ea3c: ldr             x16, [PP, #0x5cf0]  ; [pp+0x5cf0] Obj!AxisDirection@12c49e1
    // 0x124ea40: cmp             w0, w16
    // 0x124ea44: b.eq            #0x124ea54
    // 0x124ea48: r16 = Instance_AxisDirection
    //     0x124ea48: ldr             x16, [PP, #0x5d00]  ; [pp+0x5d00] Obj!AxisDirection@12c49a1
    // 0x124ea4c: cmp             w0, w16
    // 0x124ea50: b.ne            #0x124ea94
    // 0x124ea54: ldur            d0, [fp, #-0x28]
    // 0x124ea58: ldur            x2, [fp, #-0x20]
    // 0x124ea5c: LoadField: d1 = r2->field_7
    //     0x124ea5c: ldur            d1, [x2, #7]
    // 0x124ea60: fsub            d2, d0, d1
    // 0x124ea64: r0 = inline_Allocate_Double()
    //     0x124ea64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x124ea68: add             x0, x0, #0x10
    //     0x124ea6c: cmp             x1, x0
    //     0x124ea70: b.ls            #0x124eb98
    //     0x124ea74: str             x0, [THR, #0x60]  ; THR::top
    //     0x124ea78: sub             x0, x0, #0xf
    //     0x124ea7c: mov             x1, #0xe19c
    //     0x124ea80: movk            x1, #3, lsl #16
    //     0x124ea84: stur            x1, [x0, #-1]
    // 0x124ea88: dmb             ishst
    // 0x124ea8c: StoreField: r0->field_7 = d2
    //     0x124ea8c: stur            d2, [x0, #7]
    // 0x124ea90: b               #0x124eb5c
    // 0x124ea94: ldur            d0, [fp, #-0x28]
    // 0x124ea98: ldur            x2, [fp, #-0x20]
    // 0x124ea9c: r16 = Instance_AxisDirection
    //     0x124ea9c: ldr             x16, [PP, #0x5ce8]  ; [pp+0x5ce8] Obj!AxisDirection@12c4a01
    // 0x124eaa0: cmp             w0, w16
    // 0x124eaa4: b.ne            #0x124eaf8
    // 0x124eaa8: ldur            x1, [fp, #-0x10]
    // 0x124eaac: r0 = size()
    //     0x124eaac: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x124eab0: LoadField: d0 = r0->field_f
    //     0x124eab0: ldur            d0, [x0, #0xf]
    // 0x124eab4: ldur            d1, [fp, #-0x28]
    // 0x124eab8: fsub            d2, d0, d1
    // 0x124eabc: ldur            x2, [fp, #-0x20]
    // 0x124eac0: LoadField: d0 = r2->field_7
    //     0x124eac0: ldur            d0, [x2, #7]
    // 0x124eac4: fsub            d1, d2, d0
    // 0x124eac8: r0 = inline_Allocate_Double()
    //     0x124eac8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x124eacc: add             x0, x0, #0x10
    //     0x124ead0: cmp             x1, x0
    //     0x124ead4: b.ls            #0x124eba8
    //     0x124ead8: str             x0, [THR, #0x60]  ; THR::top
    //     0x124eadc: sub             x0, x0, #0xf
    //     0x124eae0: mov             x1, #0xe19c
    //     0x124eae4: movk            x1, #3, lsl #16
    //     0x124eae8: stur            x1, [x0, #-1]
    // 0x124eaec: dmb             ishst
    // 0x124eaf0: StoreField: r0->field_7 = d1
    //     0x124eaf0: stur            d1, [x0, #7]
    // 0x124eaf4: b               #0x124eb5c
    // 0x124eaf8: mov             v1.16b, v0.16b
    // 0x124eafc: r16 = Instance_AxisDirection
    //     0x124eafc: ldr             x16, [PP, #0x5cf8]  ; [pp+0x5cf8] Obj!AxisDirection@12c49c1
    // 0x124eb00: cmp             w0, w16
    // 0x124eb04: b.ne            #0x124eb58
    // 0x124eb08: ldur            x1, [fp, #-0x10]
    // 0x124eb0c: r0 = size()
    //     0x124eb0c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0x124eb10: LoadField: d0 = r0->field_7
    //     0x124eb10: ldur            d0, [x0, #7]
    // 0x124eb14: ldur            d1, [fp, #-0x28]
    // 0x124eb18: fsub            d2, d0, d1
    // 0x124eb1c: ldur            x0, [fp, #-0x20]
    // 0x124eb20: LoadField: d0 = r0->field_7
    //     0x124eb20: ldur            d0, [x0, #7]
    // 0x124eb24: fsub            d1, d2, d0
    // 0x124eb28: r0 = inline_Allocate_Double()
    //     0x124eb28: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x124eb2c: add             x0, x0, #0x10
    //     0x124eb30: cmp             x1, x0
    //     0x124eb34: b.ls            #0x124ebb8
    //     0x124eb38: str             x0, [THR, #0x60]  ; THR::top
    //     0x124eb3c: sub             x0, x0, #0xf
    //     0x124eb40: mov             x1, #0xe19c
    //     0x124eb44: movk            x1, #3, lsl #16
    //     0x124eb48: stur            x1, [x0, #-1]
    // 0x124eb4c: dmb             ishst
    // 0x124eb50: StoreField: r0->field_7 = d1
    //     0x124eb50: stur            d1, [x0, #7]
    // 0x124eb54: b               #0x124eb5c
    // 0x124eb58: r0 = Null
    //     0x124eb58: mov             x0, NULL
    // 0x124eb5c: LoadField: d0 = r0->field_7
    //     0x124eb5c: ldur            d0, [x0, #7]
    // 0x124eb60: LeaveFrame
    //     0x124eb60: mov             SP, fp
    //     0x124eb64: ldp             fp, lr, [SP], #0x10
    // 0x124eb68: ret
    //     0x124eb68: ret             
    // 0x124eb6c: r0 = StateError()
    //     0x124eb6c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x124eb70: mov             x1, x0
    // 0x124eb74: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x124eb74: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x124eb78: StoreField: r1->field_b = r0
    //     0x124eb78: stur            w0, [x1, #0xb]
    // 0x124eb7c: mov             x0, x1
    // 0x124eb80: r0 = Throw()
    //     0x124eb80: bl              #0x13ddb2c  ; ThrowStub
    // 0x124eb84: brk             #0
    // 0x124eb88: r0 = StackOverflowSharedWithFPURegs()
    //     0x124eb88: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x124eb8c: b               #0x124e978
    // 0x124eb90: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124eb90: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124eb94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124eb94: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124eb98: SaveReg d2
    //     0x124eb98: str             q2, [SP, #-0x10]!
    // 0x124eb9c: r0 = AllocateDouble()
    //     0x124eb9c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x124eba0: RestoreReg d2
    //     0x124eba0: ldr             q2, [SP], #0x10
    // 0x124eba4: b               #0x124ea8c
    // 0x124eba8: SaveReg d1
    //     0x124eba8: str             q1, [SP, #-0x10]!
    // 0x124ebac: r0 = AllocateDouble()
    //     0x124ebac: bl              #0x13df878  ; AllocateDoubleStub
    // 0x124ebb0: RestoreReg d1
    //     0x124ebb0: ldr             q1, [SP], #0x10
    // 0x124ebb4: b               #0x124eaf0
    // 0x124ebb8: SaveReg d1
    //     0x124ebb8: str             q1, [SP, #-0x10]!
    // 0x124ebbc: r0 = AllocateDouble()
    //     0x124ebbc: bl              #0x13df878  ; AllocateDoubleStub
    // 0x124ebc0: RestoreReg d1
    //     0x124ebc0: ldr             q1, [SP], #0x10
    // 0x124ebc4: b               #0x124eb50
  }
}

// class id: 4839, size: 0x9c, field offset: 0x84
class RenderViewport extends RenderViewportBase<dynamic> {

  late double _minScrollExtent; // offset: 0x90
  late double _maxScrollExtent; // offset: 0x94

  set _ center=(/* No info */) {
    // ** addr: 0xb8cb88, size: 0xa4
    // 0xb8cb88: EnterFrame
    //     0xb8cb88: stp             fp, lr, [SP, #-0x10]!
    //     0xb8cb8c: mov             fp, SP
    // 0xb8cb90: AllocStack(0x20)
    //     0xb8cb90: sub             SP, SP, #0x20
    // 0xb8cb94: SetupParameters(RenderViewport this /* r1 => r2, fp-0x8 */, dynamic _ /* r2 => r1, fp-0x10 */)
    //     0xb8cb94: stur            x1, [fp, #-8]
    //     0xb8cb98: mov             x16, x2
    //     0xb8cb9c: mov             x2, x1
    //     0xb8cba0: mov             x1, x16
    //     0xb8cba4: stur            x1, [fp, #-0x10]
    // 0xb8cba8: CheckStackOverflow
    //     0xb8cba8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xb8cbac: cmp             SP, x16
    //     0xb8cbb0: b.ls            #0xb8cc24
    // 0xb8cbb4: LoadField: r0 = r2->field_8b
    //     0xb8cbb4: ldur            w0, [x2, #0x8b]
    // 0xb8cbb8: DecompressPointer r0
    //     0xb8cbb8: add             x0, x0, HEAP, lsl #32
    // 0xb8cbbc: r3 = LoadClassIdInstr(r1)
    //     0xb8cbbc: ldur            x3, [x1, #-1]
    //     0xb8cbc0: ubfx            x3, x3, #0xc, #0x14
    // 0xb8cbc4: stp             x0, x1, [SP]
    // 0xb8cbc8: mov             x0, x3
    // 0xb8cbcc: mov             lr, x0
    // 0xb8cbd0: ldr             lr, [x21, lr, lsl #3]
    // 0xb8cbd4: blr             lr
    // 0xb8cbd8: tbnz            w0, #4, #0xb8cbec
    // 0xb8cbdc: r0 = Null
    //     0xb8cbdc: mov             x0, NULL
    // 0xb8cbe0: LeaveFrame
    //     0xb8cbe0: mov             SP, fp
    //     0xb8cbe4: ldp             fp, lr, [SP], #0x10
    // 0xb8cbe8: ret
    //     0xb8cbe8: ret             
    // 0xb8cbec: ldur            x1, [fp, #-8]
    // 0xb8cbf0: ldur            x0, [fp, #-0x10]
    // 0xb8cbf4: StoreField: r1->field_8b = r0
    //     0xb8cbf4: stur            w0, [x1, #0x8b]
    //     0xb8cbf8: ldurb           w16, [x1, #-1]
    //     0xb8cbfc: ldurb           w17, [x0, #-1]
    //     0xb8cc00: and             x16, x17, x16, lsr #2
    //     0xb8cc04: tst             x16, HEAP, lsr #32
    //     0xb8cc08: b.eq            #0xb8cc10
    //     0xb8cc0c: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xb8cc10: r0 = markNeedsLayout()
    //     0xb8cc10: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xb8cc14: r0 = Null
    //     0xb8cc14: mov             x0, NULL
    // 0xb8cc18: LeaveFrame
    //     0xb8cc18: mov             SP, fp
    //     0xb8cc1c: ldp             fp, lr, [SP], #0x10
    // 0xb8cc20: ret
    //     0xb8cc20: ret             
    // 0xb8cc24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb8cc24: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb8cc28: b               #0xb8cbb4
  }
  _ performLayout(/* No info */) {
    // ** addr: 0xbc6b44, size: 0x6f4
    // 0xbc6b44: EnterFrame
    //     0xbc6b44: stp             fp, lr, [SP, #-0x10]!
    //     0xbc6b48: mov             fp, SP
    // 0xbc6b4c: AllocStack(0x50)
    //     0xbc6b4c: sub             SP, SP, #0x50
    // 0xbc6b50: SetupParameters(RenderViewport this /* r1 => r0, fp-0x8 */)
    //     0xbc6b50: mov             x0, x1
    //     0xbc6b54: stur            x1, [fp, #-8]
    // 0xbc6b58: CheckStackOverflow
    //     0xbc6b58: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc6b5c: cmp             SP, x16
    //     0xbc6b60: b.ls            #0xbc7144
    // 0xbc6b64: mov             x1, x0
    // 0xbc6b68: r0 = axis()
    //     0xbc6b68: bl              #0xbc8210  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::axis
    // 0xbc6b6c: LoadField: r1 = r0->field_7
    //     0xbc6b6c: ldur            x1, [x0, #7]
    // 0xbc6b70: cmp             x1, #0
    // 0xbc6b74: b.gt            #0xbc6c68
    // 0xbc6b78: ldur            x0, [fp, #-8]
    // 0xbc6b7c: LoadField: r2 = r0->field_6b
    //     0xbc6b7c: ldur            w2, [x0, #0x6b]
    // 0xbc6b80: DecompressPointer r2
    //     0xbc6b80: add             x2, x2, HEAP, lsl #32
    // 0xbc6b84: mov             x1, x0
    // 0xbc6b88: stur            x2, [fp, #-0x10]
    // 0xbc6b8c: r0 = size()
    //     0xbc6b8c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6b90: LoadField: d0 = r0->field_7
    //     0xbc6b90: ldur            d0, [x0, #7]
    // 0xbc6b94: ldur            x1, [fp, #-0x10]
    // 0xbc6b98: r0 = LoadClassIdInstr(r1)
    //     0xbc6b98: ldur            x0, [x1, #-1]
    //     0xbc6b9c: ubfx            x0, x0, #0xc, #0x14
    // 0xbc6ba0: r17 = -4542
    //     0xbc6ba0: mov             x17, #-0x11be
    // 0xbc6ba4: add             x16, x0, x17
    // 0xbc6ba8: cmp             x16, #1
    // 0xbc6bac: b.ls            #0xbc6bbc
    // 0xbc6bb0: r17 = 4540
    //     0xbc6bb0: mov             x17, #0x11bc
    // 0xbc6bb4: cmp             x0, x17
    // 0xbc6bb8: b.ne            #0xbc6c4c
    // 0xbc6bbc: LoadField: r0 = r1->field_43
    //     0xbc6bbc: ldur            w0, [x1, #0x43]
    // 0xbc6bc0: DecompressPointer r0
    //     0xbc6bc0: add             x0, x0, HEAP, lsl #32
    // 0xbc6bc4: r2 = inline_Allocate_Double()
    //     0xbc6bc4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbc6bc8: add             x2, x2, #0x10
    //     0xbc6bcc: cmp             x3, x2
    //     0xbc6bd0: b.ls            #0xbc714c
    //     0xbc6bd4: str             x2, [THR, #0x60]  ; THR::top
    //     0xbc6bd8: sub             x2, x2, #0xf
    //     0xbc6bdc: mov             x3, #0xe19c
    //     0xbc6be0: movk            x3, #3, lsl #16
    //     0xbc6be4: stur            x3, [x2, #-1]
    // 0xbc6be8: dmb             ishst
    // 0xbc6bec: StoreField: r2->field_7 = d0
    //     0xbc6bec: stur            d0, [x2, #7]
    // 0xbc6bf0: stur            x2, [fp, #-0x18]
    // 0xbc6bf4: r3 = LoadClassIdInstr(r0)
    //     0xbc6bf4: ldur            x3, [x0, #-1]
    //     0xbc6bf8: ubfx            x3, x3, #0xc, #0x14
    // 0xbc6bfc: stp             x2, x0, [SP]
    // 0xbc6c00: mov             x0, x3
    // 0xbc6c04: mov             lr, x0
    // 0xbc6c08: ldr             lr, [x21, lr, lsl #3]
    // 0xbc6c0c: blr             lr
    // 0xbc6c10: tbz             w0, #4, #0xbc6c44
    // 0xbc6c14: ldur            x1, [fp, #-0x10]
    // 0xbc6c18: r2 = true
    //     0xbc6c18: add             x2, NULL, #0x20  ; true
    // 0xbc6c1c: ldur            x0, [fp, #-0x18]
    // 0xbc6c20: StoreField: r1->field_43 = r0
    //     0xbc6c20: stur            w0, [x1, #0x43]
    //     0xbc6c24: ldurb           w16, [x1, #-1]
    //     0xbc6c28: ldurb           w17, [x0, #-1]
    //     0xbc6c2c: and             x16, x17, x16, lsr #2
    //     0xbc6c30: tst             x16, HEAP, lsr #32
    //     0xbc6c34: b.eq            #0xbc6c3c
    //     0xbc6c38: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc6c3c: StoreField: r1->field_4b = r2
    //     0xbc6c3c: stur            w2, [x1, #0x4b]
    // 0xbc6c40: b               #0xbc6d54
    // 0xbc6c44: r2 = true
    //     0xbc6c44: add             x2, NULL, #0x20  ; true
    // 0xbc6c48: b               #0xbc6d54
    // 0xbc6c4c: r2 = true
    //     0xbc6c4c: add             x2, NULL, #0x20  ; true
    // 0xbc6c50: r0 = LoadClassIdInstr(r1)
    //     0xbc6c50: ldur            x0, [x1, #-1]
    //     0xbc6c54: ubfx            x0, x0, #0xc, #0x14
    // 0xbc6c58: r0 = GDT[cid_x0 + -0x1b0]()
    //     0xbc6c58: sub             lr, x0, #0x1b0
    //     0xbc6c5c: ldr             lr, [x21, lr, lsl #3]
    //     0xbc6c60: blr             lr
    // 0xbc6c64: b               #0xbc6d54
    // 0xbc6c68: ldur            x0, [fp, #-8]
    // 0xbc6c6c: LoadField: r2 = r0->field_6b
    //     0xbc6c6c: ldur            w2, [x0, #0x6b]
    // 0xbc6c70: DecompressPointer r2
    //     0xbc6c70: add             x2, x2, HEAP, lsl #32
    // 0xbc6c74: mov             x1, x0
    // 0xbc6c78: stur            x2, [fp, #-0x10]
    // 0xbc6c7c: r0 = size()
    //     0xbc6c7c: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6c80: LoadField: d0 = r0->field_f
    //     0xbc6c80: ldur            d0, [x0, #0xf]
    // 0xbc6c84: ldur            x1, [fp, #-0x10]
    // 0xbc6c88: r0 = LoadClassIdInstr(r1)
    //     0xbc6c88: ldur            x0, [x1, #-1]
    //     0xbc6c8c: ubfx            x0, x0, #0xc, #0x14
    // 0xbc6c90: r17 = -4542
    //     0xbc6c90: mov             x17, #-0x11be
    // 0xbc6c94: add             x16, x0, x17
    // 0xbc6c98: cmp             x16, #1
    // 0xbc6c9c: b.ls            #0xbc6cac
    // 0xbc6ca0: r17 = 4540
    //     0xbc6ca0: mov             x17, #0x11bc
    // 0xbc6ca4: cmp             x0, x17
    // 0xbc6ca8: b.ne            #0xbc6d3c
    // 0xbc6cac: LoadField: r0 = r1->field_43
    //     0xbc6cac: ldur            w0, [x1, #0x43]
    // 0xbc6cb0: DecompressPointer r0
    //     0xbc6cb0: add             x0, x0, HEAP, lsl #32
    // 0xbc6cb4: r2 = inline_Allocate_Double()
    //     0xbc6cb4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xbc6cb8: add             x2, x2, #0x10
    //     0xbc6cbc: cmp             x3, x2
    //     0xbc6cc0: b.ls            #0xbc7168
    //     0xbc6cc4: str             x2, [THR, #0x60]  ; THR::top
    //     0xbc6cc8: sub             x2, x2, #0xf
    //     0xbc6ccc: mov             x3, #0xe19c
    //     0xbc6cd0: movk            x3, #3, lsl #16
    //     0xbc6cd4: stur            x3, [x2, #-1]
    // 0xbc6cd8: dmb             ishst
    // 0xbc6cdc: StoreField: r2->field_7 = d0
    //     0xbc6cdc: stur            d0, [x2, #7]
    // 0xbc6ce0: stur            x2, [fp, #-0x18]
    // 0xbc6ce4: r3 = LoadClassIdInstr(r0)
    //     0xbc6ce4: ldur            x3, [x0, #-1]
    //     0xbc6ce8: ubfx            x3, x3, #0xc, #0x14
    // 0xbc6cec: stp             x2, x0, [SP]
    // 0xbc6cf0: mov             x0, x3
    // 0xbc6cf4: mov             lr, x0
    // 0xbc6cf8: ldr             lr, [x21, lr, lsl #3]
    // 0xbc6cfc: blr             lr
    // 0xbc6d00: tbz             w0, #4, #0xbc6d34
    // 0xbc6d04: ldur            x1, [fp, #-0x10]
    // 0xbc6d08: r2 = true
    //     0xbc6d08: add             x2, NULL, #0x20  ; true
    // 0xbc6d0c: ldur            x0, [fp, #-0x18]
    // 0xbc6d10: StoreField: r1->field_43 = r0
    //     0xbc6d10: stur            w0, [x1, #0x43]
    //     0xbc6d14: ldurb           w16, [x1, #-1]
    //     0xbc6d18: ldurb           w17, [x0, #-1]
    //     0xbc6d1c: and             x16, x17, x16, lsr #2
    //     0xbc6d20: tst             x16, HEAP, lsr #32
    //     0xbc6d24: b.eq            #0xbc6d2c
    //     0xbc6d28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc6d2c: StoreField: r1->field_4b = r2
    //     0xbc6d2c: stur            w2, [x1, #0x4b]
    // 0xbc6d30: b               #0xbc6d54
    // 0xbc6d34: r2 = true
    //     0xbc6d34: add             x2, NULL, #0x20  ; true
    // 0xbc6d38: b               #0xbc6d54
    // 0xbc6d3c: r2 = true
    //     0xbc6d3c: add             x2, NULL, #0x20  ; true
    // 0xbc6d40: r0 = LoadClassIdInstr(r1)
    //     0xbc6d40: ldur            x0, [x1, #-1]
    //     0xbc6d44: ubfx            x0, x0, #0xc, #0x14
    // 0xbc6d48: r0 = GDT[cid_x0 + -0x1b0]()
    //     0xbc6d48: sub             lr, x0, #0x1b0
    //     0xbc6d4c: ldr             lr, [x21, lr, lsl #3]
    //     0xbc6d50: blr             lr
    // 0xbc6d54: ldur            x0, [fp, #-8]
    // 0xbc6d58: LoadField: r1 = r0->field_8b
    //     0xbc6d58: ldur            w1, [x0, #0x8b]
    // 0xbc6d5c: DecompressPointer r1
    //     0xbc6d5c: add             x1, x1, HEAP, lsl #32
    // 0xbc6d60: cmp             w1, NULL
    // 0xbc6d64: b.ne            #0xbc6e04
    // 0xbc6d68: r2 = false
    //     0xbc6d68: add             x2, NULL, #0x30  ; false
    // 0xbc6d6c: r1 = 0.000000
    //     0xbc6d6c: ldr             x1, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc6d70: StoreField: r0->field_8f = r1
    //     0xbc6d70: stur            w1, [x0, #0x8f]
    // 0xbc6d74: StoreField: r0->field_93 = r1
    //     0xbc6d74: stur            w1, [x0, #0x93]
    // 0xbc6d78: StoreField: r0->field_97 = r2
    //     0xbc6d78: stur            w2, [x0, #0x97]
    // 0xbc6d7c: LoadField: r1 = r0->field_6b
    //     0xbc6d7c: ldur            w1, [x0, #0x6b]
    // 0xbc6d80: DecompressPointer r1
    //     0xbc6d80: add             x1, x1, HEAP, lsl #32
    // 0xbc6d84: r0 = LoadClassIdInstr(r1)
    //     0xbc6d84: ldur            x0, [x1, #-1]
    //     0xbc6d88: ubfx            x0, x0, #0xc, #0x14
    // 0xbc6d8c: r17 = 4541
    //     0xbc6d8c: mov             x17, #0x11bd
    // 0xbc6d90: cmp             x0, x17
    // 0xbc6d94: b.ne            #0xbc6dd8
    // 0xbc6d98: d1 = 0.000000
    //     0xbc6d98: eor             v1.16b, v1.16b, v1.16b
    // 0xbc6d9c: d0 = 2.000000
    //     0xbc6d9c: fmov            d0, #2.00000000
    // 0xbc6da0: LoadField: r0 = r1->field_43
    //     0xbc6da0: ldur            w0, [x1, #0x43]
    // 0xbc6da4: DecompressPointer r0
    //     0xbc6da4: add             x0, x0, HEAP, lsl #32
    // 0xbc6da8: cmp             w0, NULL
    // 0xbc6dac: b.eq            #0xbc7184
    // 0xbc6db0: LoadField: d2 = r0->field_7
    //     0xbc6db0: ldur            d2, [x0, #7]
    // 0xbc6db4: fmul            d3, d2, d1
    // 0xbc6db8: fdiv            d2, d3, d0
    // 0xbc6dbc: fmax            v0.2d, v1.2d, v2.2d
    // 0xbc6dc0: fadd            d2, d0, d1
    // 0xbc6dc4: fsub            d3, d1, d0
    // 0xbc6dc8: fmax            v1.2d, v2.2d, v3.2d
    // 0xbc6dcc: mov             v0.16b, v2.16b
    // 0xbc6dd0: r0 = applyContentDimensions()
    //     0xbc6dd0: bl              #0x12859f8  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xbc6dd4: b               #0xbc6df4
    // 0xbc6dd8: d1 = 0.000000
    //     0xbc6dd8: eor             v1.16b, v1.16b, v1.16b
    // 0xbc6ddc: r0 = LoadClassIdInstr(r1)
    //     0xbc6ddc: ldur            x0, [x1, #-1]
    //     0xbc6de0: ubfx            x0, x0, #0xc, #0x14
    // 0xbc6de4: mov             v0.16b, v1.16b
    // 0xbc6de8: r0 = GDT[cid_x0 + -0x1cd]()
    //     0xbc6de8: sub             lr, x0, #0x1cd
    //     0xbc6dec: ldr             lr, [x21, lr, lsl #3]
    //     0xbc6df0: blr             lr
    // 0xbc6df4: r0 = Null
    //     0xbc6df4: mov             x0, NULL
    // 0xbc6df8: LeaveFrame
    //     0xbc6df8: mov             SP, fp
    //     0xbc6dfc: ldp             fp, lr, [SP], #0x10
    // 0xbc6e00: ret
    //     0xbc6e00: ret             
    // 0xbc6e04: d1 = 0.000000
    //     0xbc6e04: eor             v1.16b, v1.16b, v1.16b
    // 0xbc6e08: d0 = 2.000000
    //     0xbc6e08: fmov            d0, #2.00000000
    // 0xbc6e0c: mov             x1, x0
    // 0xbc6e10: r0 = axis()
    //     0xbc6e10: bl              #0xbc8210  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::axis
    // 0xbc6e14: LoadField: r1 = r0->field_7
    //     0xbc6e14: ldur            x1, [x0, #7]
    // 0xbc6e18: cmp             x1, #0
    // 0xbc6e1c: b.gt            #0xbc6ea4
    // 0xbc6e20: ldur            x1, [fp, #-8]
    // 0xbc6e24: r0 = size()
    //     0xbc6e24: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6e28: LoadField: d0 = r0->field_7
    //     0xbc6e28: ldur            d0, [x0, #7]
    // 0xbc6e2c: ldur            x1, [fp, #-8]
    // 0xbc6e30: stur            d0, [fp, #-0x30]
    // 0xbc6e34: r0 = size()
    //     0xbc6e34: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6e38: LoadField: d0 = r0->field_f
    //     0xbc6e38: ldur            d0, [x0, #0xf]
    // 0xbc6e3c: ldur            d1, [fp, #-0x30]
    // 0xbc6e40: r2 = inline_Allocate_Double()
    //     0xbc6e40: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xbc6e44: add             x2, x2, #0x10
    //     0xbc6e48: cmp             x0, x2
    //     0xbc6e4c: b.ls            #0xbc7188
    //     0xbc6e50: str             x2, [THR, #0x60]  ; THR::top
    //     0xbc6e54: sub             x2, x2, #0xf
    //     0xbc6e58: mov             x0, #0xe19c
    //     0xbc6e5c: movk            x0, #3, lsl #16
    //     0xbc6e60: stur            x0, [x2, #-1]
    // 0xbc6e64: dmb             ishst
    // 0xbc6e68: StoreField: r2->field_7 = d1
    //     0xbc6e68: stur            d1, [x2, #7]
    // 0xbc6e6c: r3 = inline_Allocate_Double()
    //     0xbc6e6c: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xbc6e70: add             x3, x3, #0x10
    //     0xbc6e74: cmp             x0, x3
    //     0xbc6e78: b.ls            #0xbc719c
    //     0xbc6e7c: str             x3, [THR, #0x60]  ; THR::top
    //     0xbc6e80: sub             x3, x3, #0xf
    //     0xbc6e84: mov             x0, #0xe19c
    //     0xbc6e88: movk            x0, #3, lsl #16
    //     0xbc6e8c: stur            x0, [x3, #-1]
    // 0xbc6e90: dmb             ishst
    // 0xbc6e94: StoreField: r3->field_7 = d0
    //     0xbc6e94: stur            d0, [x3, #7]
    // 0xbc6e98: r0 = AllocateRecord2()
    //     0xbc6e98: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbc6e9c: mov             x1, x0
    // 0xbc6ea0: b               #0xbc6f24
    // 0xbc6ea4: ldur            x1, [fp, #-8]
    // 0xbc6ea8: r0 = size()
    //     0xbc6ea8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6eac: LoadField: d0 = r0->field_f
    //     0xbc6eac: ldur            d0, [x0, #0xf]
    // 0xbc6eb0: ldur            x1, [fp, #-8]
    // 0xbc6eb4: stur            d0, [fp, #-0x30]
    // 0xbc6eb8: r0 = size()
    //     0xbc6eb8: bl              #0x858808  ; [package:flutter/src/rendering/box.dart] RenderBox::size
    // 0xbc6ebc: LoadField: d0 = r0->field_7
    //     0xbc6ebc: ldur            d0, [x0, #7]
    // 0xbc6ec0: ldur            d1, [fp, #-0x30]
    // 0xbc6ec4: r2 = inline_Allocate_Double()
    //     0xbc6ec4: ldp             x2, x0, [THR, #0x60]  ; THR::top
    //     0xbc6ec8: add             x2, x2, #0x10
    //     0xbc6ecc: cmp             x0, x2
    //     0xbc6ed0: b.ls            #0xbc71b8
    //     0xbc6ed4: str             x2, [THR, #0x60]  ; THR::top
    //     0xbc6ed8: sub             x2, x2, #0xf
    //     0xbc6edc: mov             x0, #0xe19c
    //     0xbc6ee0: movk            x0, #3, lsl #16
    //     0xbc6ee4: stur            x0, [x2, #-1]
    // 0xbc6ee8: dmb             ishst
    // 0xbc6eec: StoreField: r2->field_7 = d1
    //     0xbc6eec: stur            d1, [x2, #7]
    // 0xbc6ef0: r3 = inline_Allocate_Double()
    //     0xbc6ef0: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xbc6ef4: add             x3, x3, #0x10
    //     0xbc6ef8: cmp             x0, x3
    //     0xbc6efc: b.ls            #0xbc71cc
    //     0xbc6f00: str             x3, [THR, #0x60]  ; THR::top
    //     0xbc6f04: sub             x3, x3, #0xf
    //     0xbc6f08: mov             x0, #0xe19c
    //     0xbc6f0c: movk            x0, #3, lsl #16
    //     0xbc6f10: stur            x0, [x3, #-1]
    // 0xbc6f14: dmb             ishst
    // 0xbc6f18: StoreField: r3->field_7 = d0
    //     0xbc6f18: stur            d0, [x3, #7]
    // 0xbc6f1c: r0 = AllocateRecord2()
    //     0xbc6f1c: bl              #0x13de578  ; AllocateRecord2Stub
    // 0xbc6f20: mov             x1, x0
    // 0xbc6f24: ldur            x0, [fp, #-8]
    // 0xbc6f28: d3 = 0.000000
    //     0xbc6f28: eor             v3.16b, v3.16b, v3.16b
    // 0xbc6f2c: LoadField: r2 = r1->field_f
    //     0xbc6f2c: ldur            w2, [x1, #0xf]
    // 0xbc6f30: DecompressPointer r2
    //     0xbc6f30: add             x2, x2, HEAP, lsl #32
    // 0xbc6f34: LoadField: r3 = r1->field_13
    //     0xbc6f34: ldur            w3, [x1, #0x13]
    // 0xbc6f38: DecompressPointer r3
    //     0xbc6f38: add             x3, x3, HEAP, lsl #32
    // 0xbc6f3c: LoadField: r1 = r0->field_8b
    //     0xbc6f3c: ldur            w1, [x0, #0x8b]
    // 0xbc6f40: DecompressPointer r1
    //     0xbc6f40: add             x1, x1, HEAP, lsl #32
    // 0xbc6f44: cmp             w1, NULL
    // 0xbc6f48: b.eq            #0xbc71e8
    // 0xbc6f4c: LoadField: r1 = r0->field_53
    //     0xbc6f4c: ldur            x1, [x0, #0x53]
    // 0xbc6f50: r16 = 10
    //     0xbc6f50: mov             x16, #0xa
    // 0xbc6f54: mul             x4, x1, x16
    // 0xbc6f58: stur            x4, [fp, #-0x28]
    // 0xbc6f5c: LoadField: d4 = r2->field_7
    //     0xbc6f5c: ldur            d4, [x2, #7]
    // 0xbc6f60: stur            d4, [fp, #-0x40]
    // 0xbc6f64: LoadField: d5 = r3->field_7
    //     0xbc6f64: ldur            d5, [x3, #7]
    // 0xbc6f68: stur            d5, [fp, #-0x38]
    // 0xbc6f6c: fmul            d6, d4, d3
    // 0xbc6f70: stur            d6, [fp, #-0x30]
    // 0xbc6f74: r2 = 0
    //     0xbc6f74: mov             x2, #0
    // 0xbc6f78: stur            x2, [fp, #-0x20]
    // 0xbc6f7c: CheckStackOverflow
    //     0xbc6f7c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc6f80: cmp             SP, x16
    //     0xbc6f84: b.ls            #0xbc71ec
    // 0xbc6f88: LoadField: r1 = r0->field_6b
    //     0xbc6f88: ldur            w1, [x0, #0x6b]
    // 0xbc6f8c: DecompressPointer r1
    //     0xbc6f8c: add             x1, x1, HEAP, lsl #32
    // 0xbc6f90: LoadField: r3 = r1->field_3f
    //     0xbc6f90: ldur            w3, [x1, #0x3f]
    // 0xbc6f94: DecompressPointer r3
    //     0xbc6f94: add             x3, x3, HEAP, lsl #32
    // 0xbc6f98: cmp             w3, NULL
    // 0xbc6f9c: b.eq            #0xbc71f4
    // 0xbc6fa0: LoadField: d0 = r3->field_7
    //     0xbc6fa0: ldur            d0, [x3, #7]
    // 0xbc6fa4: fadd            d2, d0, d3
    // 0xbc6fa8: mov             x1, x0
    // 0xbc6fac: mov             v0.16b, v4.16b
    // 0xbc6fb0: mov             v1.16b, v5.16b
    // 0xbc6fb4: r0 = _attemptLayout()
    //     0xbc6fb4: bl              #0xbc7238  ; [package:flutter/src/rendering/viewport.dart] RenderViewport::_attemptLayout
    // 0xbc6fb8: d2 = 0.000000
    //     0xbc6fb8: eor             v2.16b, v2.16b, v2.16b
    // 0xbc6fbc: fcmp            d0, d2
    // 0xbc6fc0: b.eq            #0xbc703c
    // 0xbc6fc4: ldur            x2, [fp, #-8]
    // 0xbc6fc8: r3 = true
    //     0xbc6fc8: add             x3, NULL, #0x20  ; true
    // 0xbc6fcc: LoadField: r1 = r2->field_6b
    //     0xbc6fcc: ldur            w1, [x2, #0x6b]
    // 0xbc6fd0: DecompressPointer r1
    //     0xbc6fd0: add             x1, x1, HEAP, lsl #32
    // 0xbc6fd4: LoadField: r0 = r1->field_3f
    //     0xbc6fd4: ldur            w0, [x1, #0x3f]
    // 0xbc6fd8: DecompressPointer r0
    //     0xbc6fd8: add             x0, x0, HEAP, lsl #32
    // 0xbc6fdc: cmp             w0, NULL
    // 0xbc6fe0: b.eq            #0xbc71f8
    // 0xbc6fe4: LoadField: d1 = r0->field_7
    //     0xbc6fe4: ldur            d1, [x0, #7]
    // 0xbc6fe8: fadd            d3, d1, d0
    // 0xbc6fec: r0 = inline_Allocate_Double()
    //     0xbc6fec: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xbc6ff0: add             x0, x0, #0x10
    //     0xbc6ff4: cmp             x4, x0
    //     0xbc6ff8: b.ls            #0xbc71fc
    //     0xbc6ffc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc7000: sub             x0, x0, #0xf
    //     0xbc7004: mov             x4, #0xe19c
    //     0xbc7008: movk            x4, #3, lsl #16
    //     0xbc700c: stur            x4, [x0, #-1]
    // 0xbc7010: dmb             ishst
    // 0xbc7014: StoreField: r0->field_7 = d3
    //     0xbc7014: stur            d3, [x0, #7]
    // 0xbc7018: StoreField: r1->field_3f = r0
    //     0xbc7018: stur            w0, [x1, #0x3f]
    //     0xbc701c: ldurb           w16, [x1, #-1]
    //     0xbc7020: ldurb           w17, [x0, #-1]
    //     0xbc7024: and             x16, x17, x16, lsr #2
    //     0xbc7028: tst             x16, HEAP, lsr #32
    //     0xbc702c: b.eq            #0xbc7034
    //     0xbc7030: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xbc7034: StoreField: r1->field_4b = r3
    //     0xbc7034: stur            w3, [x1, #0x4b]
    // 0xbc7038: b               #0xbc7100
    // 0xbc703c: ldur            x2, [fp, #-8]
    // 0xbc7040: ldur            d4, [fp, #-0x30]
    // 0xbc7044: ldur            d3, [fp, #-0x40]
    // 0xbc7048: r3 = true
    //     0xbc7048: add             x3, NULL, #0x20  ; true
    // 0xbc704c: LoadField: r1 = r2->field_6b
    //     0xbc704c: ldur            w1, [x2, #0x6b]
    // 0xbc7050: DecompressPointer r1
    //     0xbc7050: add             x1, x1, HEAP, lsl #32
    // 0xbc7054: LoadField: r0 = r2->field_8f
    //     0xbc7054: ldur            w0, [x2, #0x8f]
    // 0xbc7058: DecompressPointer r0
    //     0xbc7058: add             x0, x0, HEAP, lsl #32
    // 0xbc705c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc7060: cmp             w0, w16
    // 0xbc7064: b.eq            #0xbc721c
    // 0xbc7068: LoadField: d0 = r0->field_7
    //     0xbc7068: ldur            d0, [x0, #7]
    // 0xbc706c: fadd            d1, d0, d4
    // 0xbc7070: fmin            v0.2d, v2.2d, v1.2d
    // 0xbc7074: LoadField: r0 = r2->field_93
    //     0xbc7074: ldur            w0, [x2, #0x93]
    // 0xbc7078: DecompressPointer r0
    //     0xbc7078: add             x0, x0, HEAP, lsl #32
    // 0xbc707c: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0xbc7080: cmp             w0, w16
    // 0xbc7084: b.eq            #0xbc7228
    // 0xbc7088: LoadField: d1 = r0->field_7
    //     0xbc7088: ldur            d1, [x0, #7]
    // 0xbc708c: fsub            d5, d1, d3
    // 0xbc7090: fmax            v1.2d, v2.2d, v5.2d
    // 0xbc7094: r0 = LoadClassIdInstr(r1)
    //     0xbc7094: ldur            x0, [x1, #-1]
    //     0xbc7098: ubfx            x0, x0, #0xc, #0x14
    // 0xbc709c: r17 = 4541
    //     0xbc709c: mov             x17, #0x11bd
    // 0xbc70a0: cmp             x0, x17
    // 0xbc70a4: b.ne            #0xbc70e8
    // 0xbc70a8: d5 = 2.000000
    //     0xbc70a8: fmov            d5, #2.00000000
    // 0xbc70ac: LoadField: r0 = r1->field_43
    //     0xbc70ac: ldur            w0, [x1, #0x43]
    // 0xbc70b0: DecompressPointer r0
    //     0xbc70b0: add             x0, x0, HEAP, lsl #32
    // 0xbc70b4: cmp             w0, NULL
    // 0xbc70b8: b.eq            #0xbc7234
    // 0xbc70bc: LoadField: d6 = r0->field_7
    //     0xbc70bc: ldur            d6, [x0, #7]
    // 0xbc70c0: fmul            d7, d6, d2
    // 0xbc70c4: fdiv            d6, d7, d5
    // 0xbc70c8: fmax            v7.2d, v2.2d, v6.2d
    // 0xbc70cc: fadd            d6, d0, d7
    // 0xbc70d0: fsub            d0, d1, d7
    // 0xbc70d4: fmax            v1.2d, v6.2d, v0.2d
    // 0xbc70d8: mov             v0.16b, v6.16b
    // 0xbc70dc: r0 = applyContentDimensions()
    //     0xbc70dc: bl              #0x12859f8  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xbc70e0: tbnz            w0, #4, #0xbc7100
    // 0xbc70e4: b               #0xbc7134
    // 0xbc70e8: r0 = LoadClassIdInstr(r1)
    //     0xbc70e8: ldur            x0, [x1, #-1]
    //     0xbc70ec: ubfx            x0, x0, #0xc, #0x14
    // 0xbc70f0: r0 = GDT[cid_x0 + -0x1cd]()
    //     0xbc70f0: sub             lr, x0, #0x1cd
    //     0xbc70f4: ldr             lr, [x21, lr, lsl #3]
    //     0xbc70f8: blr             lr
    // 0xbc70fc: tbz             w0, #4, #0xbc7134
    // 0xbc7100: ldur            x1, [fp, #-0x28]
    // 0xbc7104: ldur            x2, [fp, #-0x20]
    // 0xbc7108: add             x0, x2, #1
    // 0xbc710c: cmp             x0, x1
    // 0xbc7110: b.ge            #0xbc7134
    // 0xbc7114: mov             x2, x0
    // 0xbc7118: ldur            x0, [fp, #-8]
    // 0xbc711c: mov             x4, x1
    // 0xbc7120: ldur            d6, [fp, #-0x30]
    // 0xbc7124: ldur            d4, [fp, #-0x40]
    // 0xbc7128: ldur            d5, [fp, #-0x38]
    // 0xbc712c: d3 = 0.000000
    //     0xbc712c: eor             v3.16b, v3.16b, v3.16b
    // 0xbc7130: b               #0xbc6f78
    // 0xbc7134: r0 = Null
    //     0xbc7134: mov             x0, NULL
    // 0xbc7138: LeaveFrame
    //     0xbc7138: mov             SP, fp
    //     0xbc713c: ldp             fp, lr, [SP], #0x10
    // 0xbc7140: ret
    //     0xbc7140: ret             
    // 0xbc7144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc7144: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc7148: b               #0xbc6b64
    // 0xbc714c: SaveReg d0
    //     0xbc714c: str             q0, [SP, #-0x10]!
    // 0xbc7150: stp             x0, x1, [SP, #-0x10]!
    // 0xbc7154: r0 = AllocateDouble()
    //     0xbc7154: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc7158: mov             x2, x0
    // 0xbc715c: ldp             x0, x1, [SP], #0x10
    // 0xbc7160: RestoreReg d0
    //     0xbc7160: ldr             q0, [SP], #0x10
    // 0xbc7164: b               #0xbc6bec
    // 0xbc7168: SaveReg d0
    //     0xbc7168: str             q0, [SP, #-0x10]!
    // 0xbc716c: stp             x0, x1, [SP, #-0x10]!
    // 0xbc7170: r0 = AllocateDouble()
    //     0xbc7170: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc7174: mov             x2, x0
    // 0xbc7178: ldp             x0, x1, [SP], #0x10
    // 0xbc717c: RestoreReg d0
    //     0xbc717c: ldr             q0, [SP], #0x10
    // 0xbc7180: b               #0xbc6cdc
    // 0xbc7184: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7184: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc7188: stp             q0, q1, [SP, #-0x20]!
    // 0xbc718c: r0 = AllocateDouble()
    //     0xbc718c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc7190: mov             x2, x0
    // 0xbc7194: ldp             q0, q1, [SP], #0x20
    // 0xbc7198: b               #0xbc6e68
    // 0xbc719c: SaveReg d0
    //     0xbc719c: str             q0, [SP, #-0x10]!
    // 0xbc71a0: SaveReg r2
    //     0xbc71a0: str             x2, [SP, #-8]!
    // 0xbc71a4: r0 = AllocateDouble()
    //     0xbc71a4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc71a8: mov             x3, x0
    // 0xbc71ac: RestoreReg r2
    //     0xbc71ac: ldr             x2, [SP], #8
    // 0xbc71b0: RestoreReg d0
    //     0xbc71b0: ldr             q0, [SP], #0x10
    // 0xbc71b4: b               #0xbc6e94
    // 0xbc71b8: stp             q0, q1, [SP, #-0x20]!
    // 0xbc71bc: r0 = AllocateDouble()
    //     0xbc71bc: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc71c0: mov             x2, x0
    // 0xbc71c4: ldp             q0, q1, [SP], #0x20
    // 0xbc71c8: b               #0xbc6eec
    // 0xbc71cc: SaveReg d0
    //     0xbc71cc: str             q0, [SP, #-0x10]!
    // 0xbc71d0: SaveReg r2
    //     0xbc71d0: str             x2, [SP, #-8]!
    // 0xbc71d4: r0 = AllocateDouble()
    //     0xbc71d4: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc71d8: mov             x3, x0
    // 0xbc71dc: RestoreReg r2
    //     0xbc71dc: ldr             x2, [SP], #8
    // 0xbc71e0: RestoreReg d0
    //     0xbc71e0: ldr             q0, [SP], #0x10
    // 0xbc71e4: b               #0xbc6f18
    // 0xbc71e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc71e8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc71ec: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc71ec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc71f0: b               #0xbc6f88
    // 0xbc71f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc71f4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc71f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc71f8: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc71fc: stp             q2, q3, [SP, #-0x20]!
    // 0xbc7200: stp             x2, x3, [SP, #-0x10]!
    // 0xbc7204: SaveReg r1
    //     0xbc7204: str             x1, [SP, #-8]!
    // 0xbc7208: r0 = AllocateDouble()
    //     0xbc7208: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc720c: RestoreReg r1
    //     0xbc720c: ldr             x1, [SP], #8
    // 0xbc7210: ldp             x2, x3, [SP], #0x10
    // 0xbc7214: ldp             q2, q3, [SP], #0x20
    // 0xbc7218: b               #0xbc7014
    // 0xbc721c: r9 = _minScrollExtent
    //     0xbc721c: add             x9, PP, #0x96, lsl #12  ; [pp+0x96348] Field <RenderViewport._minScrollExtent@616057554>: late (offset: 0x90)
    //     0xbc7220: ldr             x9, [x9, #0x348]
    // 0xbc7224: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbc7224: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbc7228: r9 = _maxScrollExtent
    //     0xbc7228: add             x9, PP, #0x96, lsl #12  ; [pp+0x96350] Field <RenderViewport._maxScrollExtent@616057554>: late (offset: 0x94)
    //     0xbc722c: ldr             x9, [x9, #0x350]
    // 0xbc7230: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbc7230: bl              #0x13e039c  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbc7234: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7234: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _attemptLayout(/* No info */) {
    // ** addr: 0xbc7238, size: 0x400
    // 0xbc7238: EnterFrame
    //     0xbc7238: stp             fp, lr, [SP, #-0x10]!
    //     0xbc723c: mov             fp, SP
    // 0xbc7240: AllocStack(0x78)
    //     0xbc7240: sub             SP, SP, #0x78
    // 0xbc7244: r2 = 0.000000
    //     0xbc7244: ldr             x2, [PP, #0x4c28]  ; [pp+0x4c28] 0
    // 0xbc7248: r0 = false
    //     0xbc7248: add             x0, NULL, #0x30  ; false
    // 0xbc724c: d4 = 0.000000
    //     0xbc724c: eor             v4.16b, v4.16b, v4.16b
    // 0xbc7250: mov             x3, x1
    // 0xbc7254: stur            x1, [fp, #-8]
    // 0xbc7258: stur            d0, [fp, #-0x50]
    // 0xbc725c: stur            d1, [fp, #-0x58]
    // 0xbc7260: CheckStackOverflow
    //     0xbc7260: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbc7264: cmp             SP, x16
    //     0xbc7268: b.ls            #0xbc75ec
    // 0xbc726c: StoreField: r3->field_8f = r2
    //     0xbc726c: stur            w2, [x3, #0x8f]
    // 0xbc7270: StoreField: r3->field_93 = r2
    //     0xbc7270: stur            w2, [x3, #0x93]
    // 0xbc7274: StoreField: r3->field_97 = r0
    //     0xbc7274: stur            w0, [x3, #0x97]
    // 0xbc7278: fmul            d3, d0, d4
    // 0xbc727c: fsub            d5, d3, d2
    // 0xbc7280: stur            d5, [fp, #-0x48]
    // 0xbc7284: fcmp            d4, d5
    // 0xbc7288: b.le            #0xbc7294
    // 0xbc728c: d2 = 0.000000
    //     0xbc728c: eor             v2.16b, v2.16b, v2.16b
    // 0xbc7290: b               #0xbc72b8
    // 0xbc7294: fcmp            d5, d0
    // 0xbc7298: b.le            #0xbc72a4
    // 0xbc729c: mov             v2.16b, v0.16b
    // 0xbc72a0: b               #0xbc72b8
    // 0xbc72a4: fcmp            d5, d5
    // 0xbc72a8: b.vc            #0xbc72b4
    // 0xbc72ac: mov             v2.16b, v0.16b
    // 0xbc72b0: b               #0xbc72b8
    // 0xbc72b4: mov             v2.16b, v5.16b
    // 0xbc72b8: stur            d2, [fp, #-0x40]
    // 0xbc72bc: fsub            d6, d0, d5
    // 0xbc72c0: stur            d6, [fp, #-0x38]
    // 0xbc72c4: fcmp            d4, d6
    // 0xbc72c8: b.le            #0xbc72d4
    // 0xbc72cc: d7 = 0.000000
    //     0xbc72cc: eor             v7.16b, v7.16b, v7.16b
    // 0xbc72d0: b               #0xbc72f8
    // 0xbc72d4: fcmp            d6, d0
    // 0xbc72d8: b.le            #0xbc72e4
    // 0xbc72dc: mov             v7.16b, v0.16b
    // 0xbc72e0: b               #0xbc72f8
    // 0xbc72e4: fcmp            d6, d6
    // 0xbc72e8: b.vc            #0xbc72f4
    // 0xbc72ec: mov             v7.16b, v0.16b
    // 0xbc72f0: b               #0xbc72f8
    // 0xbc72f4: mov             v7.16b, v6.16b
    // 0xbc72f8: stur            d7, [fp, #-0x30]
    // 0xbc72fc: LoadField: r0 = r3->field_6f
    //     0xbc72fc: ldur            w0, [x3, #0x6f]
    // 0xbc7300: DecompressPointer r0
    //     0xbc7300: add             x0, x0, HEAP, lsl #32
    // 0xbc7304: r1 = LoadClassIdInstr(r0)
    //     0xbc7304: ldur            x1, [x0, #-1]
    //     0xbc7308: ubfx            x1, x1, #0xc, #0x14
    // 0xbc730c: cmp             x1, #0xb19
    // 0xbc7310: b.ne            #0xbc731c
    // 0xbc7314: mov             v8.16b, v3.16b
    // 0xbc7318: b               #0xbc7324
    // 0xbc731c: d8 = 250.000000
    //     0xbc731c: add             x17, PP, #0x8c, lsl #12  ; [pp+0x8cf30] IMM: double(250) from 0x406f400000000000
    //     0xbc7320: ldr             d8, [x17, #0xf30]
    // 0xbc7324: d3 = 2.000000
    //     0xbc7324: fmov            d3, #2.00000000
    // 0xbc7328: r0 = inline_Allocate_Double()
    //     0xbc7328: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbc732c: add             x0, x0, #0x10
    //     0xbc7330: cmp             x1, x0
    //     0xbc7334: b.ls            #0xbc75f4
    //     0xbc7338: str             x0, [THR, #0x60]  ; THR::top
    //     0xbc733c: sub             x0, x0, #0xf
    //     0xbc7340: mov             x1, #0xe19c
    //     0xbc7344: movk            x1, #3, lsl #16
    //     0xbc7348: stur            x1, [x0, #-1]
    // 0xbc734c: dmb             ishst
    // 0xbc7350: StoreField: r0->field_7 = d8
    //     0xbc7350: stur            d8, [x0, #7]
    // 0xbc7354: StoreField: r3->field_73 = r0
    //     0xbc7354: stur            w0, [x3, #0x73]
    //     0xbc7358: ldurb           w16, [x3, #-1]
    //     0xbc735c: ldurb           w17, [x0, #-1]
    //     0xbc7360: and             x16, x17, x16, lsr #2
    //     0xbc7364: tst             x16, HEAP, lsr #32
    //     0xbc7368: b.eq            #0xbc7370
    //     0xbc736c: bl              #0x13ddfd4  ; WriteBarrierWrappersStub
    // 0xbc7370: fmul            d9, d8, d3
    // 0xbc7374: fadd            d3, d0, d9
    // 0xbc7378: fadd            d9, d5, d8
    // 0xbc737c: fcmp            d4, d9
    // 0xbc7380: b.le            #0xbc738c
    // 0xbc7384: d8 = 0.000000
    //     0xbc7384: eor             v8.16b, v8.16b, v8.16b
    // 0xbc7388: b               #0xbc73b0
    // 0xbc738c: fcmp            d9, d3
    // 0xbc7390: b.le            #0xbc739c
    // 0xbc7394: mov             v8.16b, v3.16b
    // 0xbc7398: b               #0xbc73b0
    // 0xbc739c: fcmp            d9, d9
    // 0xbc73a0: b.vc            #0xbc73ac
    // 0xbc73a4: mov             v8.16b, v3.16b
    // 0xbc73a8: b               #0xbc73b0
    // 0xbc73ac: mov             v8.16b, v9.16b
    // 0xbc73b0: stur            d8, [fp, #-0x28]
    // 0xbc73b4: fsub            d10, d3, d9
    // 0xbc73b8: fcmp            d4, d10
    // 0xbc73bc: b.le            #0xbc73c8
    // 0xbc73c0: d3 = 0.000000
    //     0xbc73c0: eor             v3.16b, v3.16b, v3.16b
    // 0xbc73c4: b               #0xbc73dc
    // 0xbc73c8: fcmp            d10, d3
    // 0xbc73cc: b.gt            #0xbc73dc
    // 0xbc73d0: fcmp            d10, d10
    // 0xbc73d4: b.vs            #0xbc73dc
    // 0xbc73d8: mov             v3.16b, v10.16b
    // 0xbc73dc: stur            d3, [fp, #-0x20]
    // 0xbc73e0: LoadField: r2 = r3->field_8b
    //     0xbc73e0: ldur            w2, [x3, #0x8b]
    // 0xbc73e4: DecompressPointer r2
    //     0xbc73e4: add             x2, x2, HEAP, lsl #32
    // 0xbc73e8: cmp             w2, NULL
    // 0xbc73ec: b.eq            #0xbc762c
    // 0xbc73f0: mov             x1, x3
    // 0xbc73f4: r0 = childBefore()
    //     0xbc73f4: bl              #0xbc7fb4  ; [dart:mixin_deduplication] _MixinApplication236&RenderBox&ContainerRenderObjectMixin::childBefore
    // 0xbc73f8: stur            x0, [fp, #-0x10]
    // 0xbc73fc: cmp             w0, NULL
    // 0xbc7400: b.eq            #0xbc74e8
    // 0xbc7404: ldur            x3, [fp, #-8]
    // 0xbc7408: ldur            d3, [fp, #-0x50]
    // 0xbc740c: ldur            d0, [fp, #-0x48]
    // 0xbc7410: ldur            d1, [fp, #-0x38]
    // 0xbc7414: fmax            v2.2d, v3.2d, v0.2d
    // 0xbc7418: fsub            d4, d2, d3
    // 0xbc741c: stur            d4, [fp, #-0x60]
    // 0xbc7420: LoadField: r1 = r3->field_73
    //     0xbc7420: ldur            w1, [x3, #0x73]
    // 0xbc7424: DecompressPointer r1
    //     0xbc7424: add             x1, x1, HEAP, lsl #32
    // 0xbc7428: cmp             w1, NULL
    // 0xbc742c: b.eq            #0xbc7630
    // 0xbc7430: LoadField: d2 = r1->field_7
    //     0xbc7430: ldur            d2, [x1, #7]
    // 0xbc7434: fneg            d5, d2
    // 0xbc7438: fcmp            d5, d1
    // 0xbc743c: b.le            #0xbc7448
    // 0xbc7440: d2 = 0.000000
    //     0xbc7440: eor             v2.16b, v2.16b, v2.16b
    // 0xbc7444: b               #0xbc7470
    // 0xbc7448: d2 = 0.000000
    //     0xbc7448: eor             v2.16b, v2.16b, v2.16b
    // 0xbc744c: fcmp            d1, d2
    // 0xbc7450: b.le            #0xbc745c
    // 0xbc7454: d5 = 0.000000
    //     0xbc7454: eor             v5.16b, v5.16b, v5.16b
    // 0xbc7458: b               #0xbc7470
    // 0xbc745c: fcmp            d1, d1
    // 0xbc7460: b.vc            #0xbc746c
    // 0xbc7464: d5 = 0.000000
    //     0xbc7464: eor             v5.16b, v5.16b, v5.16b
    // 0xbc7468: b               #0xbc7470
    // 0xbc746c: mov             v5.16b, v1.16b
    // 0xbc7470: ldur            d1, [fp, #-0x40]
    // 0xbc7474: mov             x2, x3
    // 0xbc7478: stur            d5, [fp, #-0x38]
    // 0xbc747c: r1 = Function 'childBefore':.
    //     0xbc747c: add             x1, PP, #0x96, lsl #12  ; [pp+0x96358] AnonymousClosure: (0xbc80a8), in [dart:mixin_deduplication] _MixinApplication236&RenderBox&ContainerRenderObjectMixin::childBefore (0xbc7fb4)
    //     0xbc7480: ldr             x1, [x1, #0x358]
    // 0xbc7484: r0 = AllocateClosure()
    //     0xbc7484: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc7488: ldur            d6, [fp, #-0x40]
    // 0xbc748c: str             d6, [SP, #8]
    // 0xbc7490: ldur            d0, [fp, #-0x60]
    // 0xbc7494: str             d0, [SP]
    // 0xbc7498: ldur            x1, [fp, #-8]
    // 0xbc749c: mov             x2, x0
    // 0xbc74a0: ldur            d0, [fp, #-0x38]
    // 0xbc74a4: ldur            x3, [fp, #-0x10]
    // 0xbc74a8: ldur            d1, [fp, #-0x58]
    // 0xbc74ac: ldur            d2, [fp, #-0x30]
    // 0xbc74b0: ldur            d3, [fp, #-0x50]
    // 0xbc74b4: ldur            d5, [fp, #-0x28]
    // 0xbc74b8: r5 = Instance_GrowthDirection
    //     0xbc74b8: add             x5, PP, #0x96, lsl #12  ; [pp+0x96360] Obj!GrowthDirection@12c42a1
    //     0xbc74bc: ldr             x5, [x5, #0x360]
    // 0xbc74c0: d4 = 0.000000
    //     0xbc74c0: eor             v4.16b, v4.16b, v4.16b
    // 0xbc74c4: r0 = layoutChildSequence()
    //     0xbc74c4: bl              #0xbc7638  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::layoutChildSequence
    // 0xbc74c8: mov             v1.16b, v0.16b
    // 0xbc74cc: d0 = 0.000000
    //     0xbc74cc: eor             v0.16b, v0.16b, v0.16b
    // 0xbc74d0: fcmp            d1, d0
    // 0xbc74d4: b.eq            #0xbc74ec
    // 0xbc74d8: fneg            d0, d1
    // 0xbc74dc: LeaveFrame
    //     0xbc74dc: mov             SP, fp
    //     0xbc74e0: ldp             fp, lr, [SP], #0x10
    // 0xbc74e4: ret
    //     0xbc74e4: ret             
    // 0xbc74e8: d0 = 0.000000
    //     0xbc74e8: eor             v0.16b, v0.16b, v0.16b
    // 0xbc74ec: ldur            x3, [fp, #-8]
    // 0xbc74f0: ldur            d1, [fp, #-0x48]
    // 0xbc74f4: ldur            x0, [fp, #-0x10]
    // 0xbc74f8: LoadField: r4 = r3->field_8b
    //     0xbc74f8: ldur            w4, [x3, #0x8b]
    // 0xbc74fc: DecompressPointer r4
    //     0xbc74fc: add             x4, x4, HEAP, lsl #32
    // 0xbc7500: stur            x4, [fp, #-0x18]
    // 0xbc7504: fneg            d2, d1
    // 0xbc7508: fmax            v3.2d, v0.2d, v2.2d
    // 0xbc750c: stur            d3, [fp, #-0x68]
    // 0xbc7510: cmp             w0, NULL
    // 0xbc7514: b.ne            #0xbc7520
    // 0xbc7518: fmin            v4.2d, v0.2d, v2.2d
    // 0xbc751c: b               #0xbc7524
    // 0xbc7520: d4 = 0.000000
    //     0xbc7520: eor             v4.16b, v4.16b, v4.16b
    // 0xbc7524: ldur            d2, [fp, #-0x50]
    // 0xbc7528: stur            d4, [fp, #-0x60]
    // 0xbc752c: fcmp            d1, d2
    // 0xbc7530: b.lt            #0xbc753c
    // 0xbc7534: mov             v5.16b, v1.16b
    // 0xbc7538: b               #0xbc7540
    // 0xbc753c: ldur            d5, [fp, #-0x40]
    // 0xbc7540: stur            d5, [fp, #-0x38]
    // 0xbc7544: LoadField: r0 = r3->field_73
    //     0xbc7544: ldur            w0, [x3, #0x73]
    // 0xbc7548: DecompressPointer r0
    //     0xbc7548: add             x0, x0, HEAP, lsl #32
    // 0xbc754c: cmp             w0, NULL
    // 0xbc7550: b.eq            #0xbc7634
    // 0xbc7554: LoadField: d6 = r0->field_7
    //     0xbc7554: ldur            d6, [x0, #7]
    // 0xbc7558: fneg            d7, d6
    // 0xbc755c: fcmp            d7, d1
    // 0xbc7560: b.le            #0xbc756c
    // 0xbc7564: mov             v1.16b, v7.16b
    // 0xbc7568: b               #0xbc7588
    // 0xbc756c: fcmp            d1, d0
    // 0xbc7570: b.le            #0xbc757c
    // 0xbc7574: d1 = 0.000000
    //     0xbc7574: eor             v1.16b, v1.16b, v1.16b
    // 0xbc7578: b               #0xbc7588
    // 0xbc757c: fcmp            d1, d1
    // 0xbc7580: b.vc            #0xbc7588
    // 0xbc7584: d1 = 0.000000
    //     0xbc7584: eor             v1.16b, v1.16b, v1.16b
    // 0xbc7588: ldur            d0, [fp, #-0x30]
    // 0xbc758c: mov             x2, x3
    // 0xbc7590: stur            d1, [fp, #-0x28]
    // 0xbc7594: r1 = Function 'childAfter':.
    //     0xbc7594: add             x1, PP, #0x96, lsl #12  ; [pp+0x96200] AnonymousClosure: (0xbc80e4), in [dart:mixin_deduplication] _MixinApplication236&RenderBox&ContainerRenderObjectMixin::childAfter (0xbc8120)
    //     0xbc7598: ldr             x1, [x1, #0x200]
    // 0xbc759c: r0 = AllocateClosure()
    //     0xbc759c: bl              #0x13dec0c  ; AllocateClosureStub
    // 0xbc75a0: ldur            d0, [fp, #-0x30]
    // 0xbc75a4: str             d0, [SP, #8]
    // 0xbc75a8: ldur            d0, [fp, #-0x68]
    // 0xbc75ac: str             d0, [SP]
    // 0xbc75b0: ldur            x1, [fp, #-8]
    // 0xbc75b4: mov             x2, x0
    // 0xbc75b8: ldur            d0, [fp, #-0x28]
    // 0xbc75bc: ldur            x3, [fp, #-0x18]
    // 0xbc75c0: ldur            d1, [fp, #-0x58]
    // 0xbc75c4: ldur            d2, [fp, #-0x38]
    // 0xbc75c8: ldur            d3, [fp, #-0x50]
    // 0xbc75cc: ldur            d4, [fp, #-0x60]
    // 0xbc75d0: ldur            d5, [fp, #-0x20]
    // 0xbc75d4: r5 = Instance_GrowthDirection
    //     0xbc75d4: add             x5, PP, #0x96, lsl #12  ; [pp+0x961d8] Obj!GrowthDirection@12c4281
    //     0xbc75d8: ldr             x5, [x5, #0x1d8]
    // 0xbc75dc: r0 = layoutChildSequence()
    //     0xbc75dc: bl              #0xbc7638  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::layoutChildSequence
    // 0xbc75e0: LeaveFrame
    //     0xbc75e0: mov             SP, fp
    //     0xbc75e4: ldp             fp, lr, [SP], #0x10
    // 0xbc75e8: ret
    //     0xbc75e8: ret             
    // 0xbc75ec: r0 = StackOverflowSharedWithFPURegs()
    //     0xbc75ec: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xbc75f0: b               #0xbc726c
    // 0xbc75f4: stp             q7, q8, [SP, #-0x20]!
    // 0xbc75f8: stp             q5, q6, [SP, #-0x20]!
    // 0xbc75fc: stp             q3, q4, [SP, #-0x20]!
    // 0xbc7600: stp             q1, q2, [SP, #-0x20]!
    // 0xbc7604: SaveReg d0
    //     0xbc7604: str             q0, [SP, #-0x10]!
    // 0xbc7608: SaveReg r3
    //     0xbc7608: str             x3, [SP, #-8]!
    // 0xbc760c: r0 = AllocateDouble()
    //     0xbc760c: bl              #0x13df878  ; AllocateDoubleStub
    // 0xbc7610: RestoreReg r3
    //     0xbc7610: ldr             x3, [SP], #8
    // 0xbc7614: RestoreReg d0
    //     0xbc7614: ldr             q0, [SP], #0x10
    // 0xbc7618: ldp             q1, q2, [SP], #0x20
    // 0xbc761c: ldp             q3, q4, [SP], #0x20
    // 0xbc7620: ldp             q5, q6, [SP], #0x20
    // 0xbc7624: ldp             q7, q8, [SP], #0x20
    // 0xbc7628: b               #0xbc7350
    // 0xbc762c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc762c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc7630: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7630: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0xbc7634: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbc7634: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0xbf1b5c, size: 0x90
    // 0xbf1b5c: EnterFrame
    //     0xbf1b5c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf1b60: mov             fp, SP
    // 0xbf1b64: AllocStack(0x10)
    //     0xbf1b64: sub             SP, SP, #0x10
    // 0xbf1b68: SetupParameters(dynamic _ /* r3 => r3, fp-0x10 */)
    //     0xbf1b68: stur            x3, [fp, #-0x10]
    // 0xbf1b6c: CheckStackOverflow
    //     0xbf1b6c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xbf1b70: cmp             SP, x16
    //     0xbf1b74: b.ls            #0xbf1be0
    // 0xbf1b78: LoadField: r4 = r2->field_7
    //     0xbf1b78: ldur            w4, [x2, #7]
    // 0xbf1b7c: DecompressPointer r4
    //     0xbf1b7c: add             x4, x4, HEAP, lsl #32
    // 0xbf1b80: stur            x4, [fp, #-8]
    // 0xbf1b84: cmp             w4, NULL
    // 0xbf1b88: b.eq            #0xbf1be8
    // 0xbf1b8c: mov             x0, x4
    // 0xbf1b90: r2 = Null
    //     0xbf1b90: mov             x2, NULL
    // 0xbf1b94: r1 = Null
    //     0xbf1b94: mov             x1, NULL
    // 0xbf1b98: r4 = LoadClassIdInstr(r0)
    //     0xbf1b98: ldur            x4, [x0, #-1]
    //     0xbf1b9c: ubfx            x4, x4, #0xc, #0x14
    // 0xbf1ba0: r17 = -4177
    //     0xbf1ba0: mov             x17, #-0x1051
    // 0xbf1ba4: add             x4, x4, x17
    // 0xbf1ba8: cmp             x4, #2
    // 0xbf1bac: b.ls            #0xbf1bc4
    // 0xbf1bb0: r8 = SliverPhysicalParentData
    //     0xbf1bb0: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0xbf1bb4: ldr             x8, [x8, #0x240]
    // 0xbf1bb8: r3 = Null
    //     0xbf1bb8: add             x3, PP, #0x96, lsl #12  ; [pp+0x96338] Null
    //     0xbf1bbc: ldr             x3, [x3, #0x338]
    // 0xbf1bc0: r0 = DefaultTypeTest()
    //     0xbf1bc0: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0xbf1bc4: ldur            x1, [fp, #-8]
    // 0xbf1bc8: ldur            x2, [fp, #-0x10]
    // 0xbf1bcc: r0 = applyPaintTransform()
    //     0xbf1bcc: bl              #0xbf1bec  ; [package:flutter/src/rendering/sliver.dart] SliverPhysicalParentData::applyPaintTransform
    // 0xbf1bd0: r0 = Null
    //     0xbf1bd0: mov             x0, NULL
    // 0xbf1bd4: LeaveFrame
    //     0xbf1bd4: mov             SP, fp
    //     0xbf1bd8: ldp             fp, lr, [SP], #0x10
    // 0xbf1bdc: ret
    //     0xbf1bdc: ret             
    // 0xbf1be0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf1be0: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf1be4: b               #0xbf1b78
    // 0xbf1be8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf1be8: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0xc0dcdc, size: 0xb0
    // 0xc0dcdc: EnterFrame
    //     0xc0dcdc: stp             fp, lr, [SP, #-0x10]!
    //     0xc0dce0: mov             fp, SP
    // 0xc0dce4: AllocStack(0x8)
    //     0xc0dce4: sub             SP, SP, #8
    // 0xc0dce8: SetupParameters(RenderViewport this /* r1 => r4 */, dynamic _ /* r2 => r0, fp-0x8 */)
    //     0xc0dce8: mov             x0, x2
    //     0xc0dcec: mov             x4, x1
    //     0xc0dcf0: mov             x3, x2
    //     0xc0dcf4: stur            x2, [fp, #-8]
    // 0xc0dcf8: r2 = Null
    //     0xc0dcf8: mov             x2, NULL
    // 0xc0dcfc: r1 = Null
    //     0xc0dcfc: mov             x1, NULL
    // 0xc0dd00: r4 = 60
    //     0xc0dd00: mov             x4, #0x3c
    // 0xc0dd04: branchIfSmi(r0, 0xc0dd10)
    //     0xc0dd04: tbz             w0, #0, #0xc0dd10
    // 0xc0dd08: r4 = LoadClassIdInstr(r0)
    //     0xc0dd08: ldur            x4, [x0, #-1]
    //     0xc0dd0c: ubfx            x4, x4, #0xc, #0x14
    // 0xc0dd10: r17 = -4679
    //     0xc0dd10: mov             x17, #-0x1247
    // 0xc0dd14: add             x4, x4, x17
    // 0xc0dd18: cmp             x4, #0x128
    // 0xc0dd1c: b.ls            #0xc0dd30
    // 0xc0dd20: r8 = RenderObject
    //     0xc0dd20: ldr             x8, [PP, #0x2a48]  ; [pp+0x2a48] Type: RenderObject
    // 0xc0dd24: r3 = Null
    //     0xc0dd24: add             x3, PP, #0x96, lsl #12  ; [pp+0x96388] Null
    //     0xc0dd28: ldr             x3, [x3, #0x388]
    // 0xc0dd2c: r0 = RenderObject()
    //     0xc0dd2c: bl              #0x830448  ; IsType_RenderObject_Stub
    // 0xc0dd30: ldur            x0, [fp, #-8]
    // 0xc0dd34: LoadField: r1 = r0->field_7
    //     0xc0dd34: ldur            w1, [x0, #7]
    // 0xc0dd38: DecompressPointer r1
    //     0xc0dd38: add             x1, x1, HEAP, lsl #32
    // 0xc0dd3c: r2 = LoadClassIdInstr(r1)
    //     0xc0dd3c: ldur            x2, [x1, #-1]
    //     0xc0dd40: ubfx            x2, x2, #0xc, #0x14
    // 0xc0dd44: r17 = 4179
    //     0xc0dd44: mov             x17, #0x1053
    // 0xc0dd48: cmp             x2, x17
    // 0xc0dd4c: b.eq            #0xc0dd7c
    // 0xc0dd50: r0 = SliverPhysicalContainerParentData()
    //     0xc0dd50: bl              #0xc0dd8c  ; AllocateSliverPhysicalContainerParentDataStub -> SliverPhysicalContainerParentData (size=0x14)
    // 0xc0dd54: r1 = Instance_Offset
    //     0xc0dd54: ldr             x1, [PP, #0x2c98]  ; [pp+0x2c98] Obj!Offset@12a7a91
    // 0xc0dd58: StoreField: r0->field_7 = r1
    //     0xc0dd58: stur            w1, [x0, #7]
    // 0xc0dd5c: ldur            x1, [fp, #-8]
    // 0xc0dd60: StoreField: r1->field_7 = r0
    //     0xc0dd60: stur            w0, [x1, #7]
    //     0xc0dd64: ldurb           w16, [x1, #-1]
    //     0xc0dd68: ldurb           w17, [x0, #-1]
    //     0xc0dd6c: and             x16, x17, x16, lsr #2
    //     0xc0dd70: tst             x16, HEAP, lsr #32
    //     0xc0dd74: b.eq            #0xc0dd7c
    //     0xc0dd78: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0xc0dd7c: r0 = Null
    //     0xc0dd7c: mov             x0, NULL
    // 0xc0dd80: LeaveFrame
    //     0xc0dd80: mov             SP, fp
    //     0xc0dd84: ldp             fp, lr, [SP], #0x10
    // 0xc0dd88: ret
    //     0xc0dd88: ret             
  }
  set _ anchor=(/* No info */) {
    // ** addr: 0xcf21b4, size: 0x50
    // 0xcf21b4: EnterFrame
    //     0xcf21b4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf21b8: mov             fp, SP
    // 0xcf21bc: d1 = 0.000000
    //     0xcf21bc: eor             v1.16b, v1.16b, v1.16b
    // 0xcf21c0: CheckStackOverflow
    //     0xcf21c0: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0xcf21c4: cmp             SP, x16
    //     0xcf21c8: b.ls            #0xcf21fc
    // 0xcf21cc: fcmp            d1, d1
    // 0xcf21d0: b.ne            #0xcf21e4
    // 0xcf21d4: r0 = Null
    //     0xcf21d4: mov             x0, NULL
    // 0xcf21d8: LeaveFrame
    //     0xcf21d8: mov             SP, fp
    //     0xcf21dc: ldp             fp, lr, [SP], #0x10
    // 0xcf21e0: ret
    //     0xcf21e0: ret             
    // 0xcf21e4: StoreField: r1->field_83 = rZR
    //     0xcf21e4: stur            xzr, [x1, #0x83]
    // 0xcf21e8: r0 = markNeedsLayout()
    //     0xcf21e8: bl              #0xbfb4c8  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0xcf21ec: r0 = Null
    //     0xcf21ec: mov             x0, NULL
    // 0xcf21f0: LeaveFrame
    //     0xcf21f0: mov             SP, fp
    //     0xcf21f4: ldp             fp, lr, [SP], #0x10
    // 0xcf21f8: ret
    //     0xcf21f8: ret             
    // 0xcf21fc: r0 = StackOverflowSharedWithFPURegs()
    //     0xcf21fc: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0xcf2200: b               #0xcf21cc
  }
  _ RenderViewport(/* No info */) {
    // ** addr: 0x11cb9bc, size: 0x88
    // 0x11cb9bc: EnterFrame
    //     0x11cb9bc: stp             fp, lr, [SP, #-0x10]!
    //     0x11cb9c0: mov             fp, SP
    // 0x11cb9c4: AllocStack(0x8)
    //     0x11cb9c4: sub             SP, SP, #8
    // 0x11cb9c8: ldr             x4, [THR, #0x90]  ; THR::object_sentinel
    // 0x11cb9cc: r0 = false
    //     0x11cb9cc: add             x0, NULL, #0x30  ; false
    // 0x11cb9d0: mov             x8, x1
    // 0x11cb9d4: stur            x1, [fp, #-8]
    // 0x11cb9d8: CheckStackOverflow
    //     0x11cb9d8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11cb9dc: cmp             SP, x16
    //     0x11cb9e0: b.ls            #0x11cba3c
    // 0x11cb9e4: StoreField: r8->field_8f = r4
    //     0x11cb9e4: stur            w4, [x8, #0x8f]
    // 0x11cb9e8: StoreField: r8->field_93 = r4
    //     0x11cb9e8: stur            w4, [x8, #0x93]
    // 0x11cb9ec: StoreField: r8->field_97 = r0
    //     0x11cb9ec: stur            w0, [x8, #0x97]
    // 0x11cb9f0: StoreField: r8->field_83 = rZR
    //     0x11cb9f0: stur            xzr, [x8, #0x83]
    // 0x11cb9f4: mov             x1, x8
    // 0x11cb9f8: r0 = RenderViewportBase()
    //     0x11cb9f8: bl              #0x11cba44  ; [package:flutter/src/rendering/viewport.dart] RenderViewportBase::RenderViewportBase
    // 0x11cb9fc: ldur            x1, [fp, #-8]
    // 0x11cba00: LoadField: r0 = r1->field_5b
    //     0x11cba00: ldur            w0, [x1, #0x5b]
    // 0x11cba04: DecompressPointer r0
    //     0x11cba04: add             x0, x0, HEAP, lsl #32
    // 0x11cba08: cmp             w0, NULL
    // 0x11cba0c: b.eq            #0x11cba2c
    // 0x11cba10: StoreField: r1->field_8b = r0
    //     0x11cba10: stur            w0, [x1, #0x8b]
    //     0x11cba14: ldurb           w16, [x1, #-1]
    //     0x11cba18: ldurb           w17, [x0, #-1]
    //     0x11cba1c: and             x16, x17, x16, lsr #2
    //     0x11cba20: tst             x16, HEAP, lsr #32
    //     0x11cba24: b.eq            #0x11cba2c
    //     0x11cba28: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x11cba2c: r0 = Null
    //     0x11cba2c: mov             x0, NULL
    // 0x11cba30: LeaveFrame
    //     0x11cba30: mov             SP, fp
    //     0x11cba34: ldp             fp, lr, [SP], #0x10
    // 0x11cba38: ret
    //     0x11cba38: ret             
    // 0x11cba3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11cba3c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11cba40: b               #0x11cb9e4
  }
  _ updateOutOfBandData(/* No info */) {
    // ** addr: 0x124b77c, size: 0x154
    // 0x124b77c: EnterFrame
    //     0x124b77c: stp             fp, lr, [SP, #-0x10]!
    //     0x124b780: mov             fp, SP
    // 0x124b784: LoadField: r4 = r2->field_7
    //     0x124b784: ldur            x4, [x2, #7]
    // 0x124b788: cmp             x4, #0
    // 0x124b78c: b.gt            #0x124b7fc
    // 0x124b790: LoadField: r2 = r1->field_93
    //     0x124b790: ldur            w2, [x1, #0x93]
    // 0x124b794: DecompressPointer r2
    //     0x124b794: add             x2, x2, HEAP, lsl #32
    // 0x124b798: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124b79c: cmp             w2, w16
    // 0x124b7a0: b.eq            #0x124b888
    // 0x124b7a4: LoadField: d0 = r3->field_7
    //     0x124b7a4: ldur            d0, [x3, #7]
    // 0x124b7a8: LoadField: d1 = r2->field_7
    //     0x124b7a8: ldur            d1, [x2, #7]
    // 0x124b7ac: fadd            d2, d1, d0
    // 0x124b7b0: r0 = inline_Allocate_Double()
    //     0x124b7b0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x124b7b4: add             x0, x0, #0x10
    //     0x124b7b8: cmp             x2, x0
    //     0x124b7bc: b.ls            #0x124b894
    //     0x124b7c0: str             x0, [THR, #0x60]  ; THR::top
    //     0x124b7c4: sub             x0, x0, #0xf
    //     0x124b7c8: mov             x2, #0xe19c
    //     0x124b7cc: movk            x2, #3, lsl #16
    //     0x124b7d0: stur            x2, [x0, #-1]
    // 0x124b7d4: dmb             ishst
    // 0x124b7d8: StoreField: r0->field_7 = d2
    //     0x124b7d8: stur            d2, [x0, #7]
    // 0x124b7dc: StoreField: r1->field_93 = r0
    //     0x124b7dc: stur            w0, [x1, #0x93]
    //     0x124b7e0: ldurb           w16, [x1, #-1]
    //     0x124b7e4: ldurb           w17, [x0, #-1]
    //     0x124b7e8: and             x16, x17, x16, lsr #2
    //     0x124b7ec: tst             x16, HEAP, lsr #32
    //     0x124b7f0: b.eq            #0x124b7f8
    //     0x124b7f4: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x124b7f8: b               #0x124b864
    // 0x124b7fc: LoadField: r2 = r1->field_8f
    //     0x124b7fc: ldur            w2, [x1, #0x8f]
    // 0x124b800: DecompressPointer r2
    //     0x124b800: add             x2, x2, HEAP, lsl #32
    // 0x124b804: ldr             x16, [THR, #0x90]  ; THR::object_sentinel
    // 0x124b808: cmp             w2, w16
    // 0x124b80c: b.eq            #0x124b8ac
    // 0x124b810: LoadField: d0 = r3->field_7
    //     0x124b810: ldur            d0, [x3, #7]
    // 0x124b814: LoadField: d1 = r2->field_7
    //     0x124b814: ldur            d1, [x2, #7]
    // 0x124b818: fsub            d2, d1, d0
    // 0x124b81c: r0 = inline_Allocate_Double()
    //     0x124b81c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x124b820: add             x0, x0, #0x10
    //     0x124b824: cmp             x2, x0
    //     0x124b828: b.ls            #0x124b8b8
    //     0x124b82c: str             x0, [THR, #0x60]  ; THR::top
    //     0x124b830: sub             x0, x0, #0xf
    //     0x124b834: mov             x2, #0xe19c
    //     0x124b838: movk            x2, #3, lsl #16
    //     0x124b83c: stur            x2, [x0, #-1]
    // 0x124b840: dmb             ishst
    // 0x124b844: StoreField: r0->field_7 = d2
    //     0x124b844: stur            d2, [x0, #7]
    // 0x124b848: StoreField: r1->field_8f = r0
    //     0x124b848: stur            w0, [x1, #0x8f]
    //     0x124b84c: ldurb           w16, [x1, #-1]
    //     0x124b850: ldurb           w17, [x0, #-1]
    //     0x124b854: and             x16, x17, x16, lsr #2
    //     0x124b858: tst             x16, HEAP, lsr #32
    //     0x124b85c: b.eq            #0x124b864
    //     0x124b860: bl              #0x13ddf94  ; WriteBarrierWrappersStub
    // 0x124b864: LoadField: r2 = r3->field_43
    //     0x124b864: ldur            w2, [x3, #0x43]
    // 0x124b868: DecompressPointer r2
    //     0x124b868: add             x2, x2, HEAP, lsl #32
    // 0x124b86c: tbnz            w2, #4, #0x124b878
    // 0x124b870: r2 = true
    //     0x124b870: add             x2, NULL, #0x20  ; true
    // 0x124b874: StoreField: r1->field_97 = r2
    //     0x124b874: stur            w2, [x1, #0x97]
    // 0x124b878: r0 = Null
    //     0x124b878: mov             x0, NULL
    // 0x124b87c: LeaveFrame
    //     0x124b87c: mov             SP, fp
    //     0x124b880: ldp             fp, lr, [SP], #0x10
    // 0x124b884: ret
    //     0x124b884: ret             
    // 0x124b888: r9 = _maxScrollExtent
    //     0x124b888: add             x9, PP, #0x96, lsl #12  ; [pp+0x96350] Field <RenderViewport._maxScrollExtent@616057554>: late (offset: 0x94)
    //     0x124b88c: ldr             x9, [x9, #0x350]
    // 0x124b890: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x124b890: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x124b894: SaveReg d2
    //     0x124b894: str             q2, [SP, #-0x10]!
    // 0x124b898: stp             x1, x3, [SP, #-0x10]!
    // 0x124b89c: r0 = AllocateDouble()
    //     0x124b89c: bl              #0x13df878  ; AllocateDoubleStub
    // 0x124b8a0: ldp             x1, x3, [SP], #0x10
    // 0x124b8a4: RestoreReg d2
    //     0x124b8a4: ldr             q2, [SP], #0x10
    // 0x124b8a8: b               #0x124b7d8
    // 0x124b8ac: r9 = _minScrollExtent
    //     0x124b8ac: add             x9, PP, #0x96, lsl #12  ; [pp+0x96348] Field <RenderViewport._minScrollExtent@616057554>: late (offset: 0x90)
    //     0x124b8b0: ldr             x9, [x9, #0x348]
    // 0x124b8b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x124b8b4: bl              #0x13e034c  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x124b8b8: SaveReg d2
    //     0x124b8b8: str             q2, [SP, #-0x10]!
    // 0x124b8bc: stp             x1, x3, [SP, #-0x10]!
    // 0x124b8c0: r0 = AllocateDouble()
    //     0x124b8c0: bl              #0x13df878  ; AllocateDoubleStub
    // 0x124b8c4: ldp             x1, x3, [SP], #0x10
    // 0x124b8c8: RestoreReg d2
    //     0x124b8c8: ldr             q2, [SP], #0x10
    // 0x124b8cc: b               #0x124b844
  }
  _ scrollOffsetOf(/* No info */) {
    // ** addr: 0x124be88, size: 0x320
    // 0x124be88: EnterFrame
    //     0x124be88: stp             fp, lr, [SP, #-0x10]!
    //     0x124be8c: mov             fp, SP
    // 0x124be90: AllocStack(0x50)
    //     0x124be90: sub             SP, SP, #0x50
    // 0x124be94: SetupParameters(RenderViewport this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */, dynamic _ /* d0 => d0, fp-0x30 */)
    //     0x124be94: mov             x4, x1
    //     0x124be98: mov             x3, x2
    //     0x124be9c: stur            x1, [fp, #-0x10]
    //     0x124bea0: stur            x2, [fp, #-0x18]
    //     0x124bea4: stur            d0, [fp, #-0x30]
    // 0x124bea8: CheckStackOverflow
    //     0x124bea8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124beac: cmp             SP, x16
    //     0x124beb0: b.ls            #0x124c174
    // 0x124beb4: LoadField: r5 = r3->field_27
    //     0x124beb4: ldur            w5, [x3, #0x27]
    // 0x124beb8: DecompressPointer r5
    //     0x124beb8: add             x5, x5, HEAP, lsl #32
    // 0x124bebc: stur            x5, [fp, #-8]
    // 0x124bec0: cmp             w5, NULL
    // 0x124bec4: b.eq            #0x124c158
    // 0x124bec8: mov             x0, x5
    // 0x124becc: r2 = Null
    //     0x124becc: mov             x2, NULL
    // 0x124bed0: r1 = Null
    //     0x124bed0: mov             x1, NULL
    // 0x124bed4: r4 = LoadClassIdInstr(r0)
    //     0x124bed4: ldur            x4, [x0, #-1]
    //     0x124bed8: ubfx            x4, x4, #0xc, #0x14
    // 0x124bedc: cmp             x4, #0xb45
    // 0x124bee0: b.eq            #0x124bef8
    // 0x124bee4: r8 = SliverConstraints
    //     0x124bee4: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x124bee8: ldr             x8, [x8, #0x3c0]
    // 0x124beec: r3 = Null
    //     0x124beec: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1198] Null
    //     0x124bef0: ldr             x3, [x3, #0x198]
    // 0x124bef4: r0 = DefaultTypeTest()
    //     0x124bef4: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x124bef8: ldur            x0, [fp, #-8]
    // 0x124befc: LoadField: r1 = r0->field_b
    //     0x124befc: ldur            w1, [x0, #0xb]
    // 0x124bf00: DecompressPointer r1
    //     0x124bf00: add             x1, x1, HEAP, lsl #32
    // 0x124bf04: LoadField: r0 = r1->field_7
    //     0x124bf04: ldur            x0, [x1, #7]
    // 0x124bf08: cmp             x0, #0
    // 0x124bf0c: b.gt            #0x124c024
    // 0x124bf10: ldur            x0, [fp, #-0x10]
    // 0x124bf14: LoadField: r1 = r0->field_8b
    //     0x124bf14: ldur            w1, [x0, #0x8b]
    // 0x124bf18: DecompressPointer r1
    //     0x124bf18: add             x1, x1, HEAP, lsl #32
    // 0x124bf1c: LoadField: r2 = r0->field_4f
    //     0x124bf1c: ldur            w2, [x0, #0x4f]
    // 0x124bf20: DecompressPointer r2
    //     0x124bf20: add             x2, x2, HEAP, lsl #32
    // 0x124bf24: stur            x2, [fp, #-0x20]
    // 0x124bf28: d0 = 0.000000
    //     0x124bf28: eor             v0.16b, v0.16b, v0.16b
    // 0x124bf2c: stur            x1, [fp, #-8]
    // 0x124bf30: stur            d0, [fp, #-0x38]
    // 0x124bf34: CheckStackOverflow
    //     0x124bf34: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124bf38: cmp             SP, x16
    //     0x124bf3c: b.ls            #0x124c17c
    // 0x124bf40: r0 = 60
    //     0x124bf40: mov             x0, #0x3c
    // 0x124bf44: branchIfSmi(r1, 0x124bf50)
    //     0x124bf44: tbz             w1, #0, #0x124bf50
    // 0x124bf48: r0 = LoadClassIdInstr(r1)
    //     0x124bf48: ldur            x0, [x1, #-1]
    //     0x124bf4c: ubfx            x0, x0, #0xc, #0x14
    // 0x124bf50: ldur            x16, [fp, #-0x18]
    // 0x124bf54: stp             x16, x1, [SP]
    // 0x124bf58: mov             lr, x0
    // 0x124bf5c: ldr             lr, [x21, lr, lsl #3]
    // 0x124bf60: blr             lr
    // 0x124bf64: tbz             w0, #4, #0x124c008
    // 0x124bf68: ldur            d0, [fp, #-0x38]
    // 0x124bf6c: ldur            x0, [fp, #-8]
    // 0x124bf70: cmp             w0, NULL
    // 0x124bf74: b.eq            #0x124c184
    // 0x124bf78: LoadField: r1 = r0->field_47
    //     0x124bf78: ldur            w1, [x0, #0x47]
    // 0x124bf7c: DecompressPointer r1
    //     0x124bf7c: add             x1, x1, HEAP, lsl #32
    // 0x124bf80: cmp             w1, NULL
    // 0x124bf84: b.eq            #0x124c188
    // 0x124bf88: LoadField: d1 = r1->field_7
    //     0x124bf88: ldur            d1, [x1, #7]
    // 0x124bf8c: fadd            d2, d0, d1
    // 0x124bf90: stur            d2, [fp, #-0x40]
    // 0x124bf94: LoadField: r3 = r0->field_7
    //     0x124bf94: ldur            w3, [x0, #7]
    // 0x124bf98: DecompressPointer r3
    //     0x124bf98: add             x3, x3, HEAP, lsl #32
    // 0x124bf9c: stur            x3, [fp, #-0x28]
    // 0x124bfa0: cmp             w3, NULL
    // 0x124bfa4: b.eq            #0x124c18c
    // 0x124bfa8: mov             x0, x3
    // 0x124bfac: ldur            x2, [fp, #-0x20]
    // 0x124bfb0: r1 = Null
    //     0x124bfb0: mov             x1, NULL
    // 0x124bfb4: cmp             w2, NULL
    // 0x124bfb8: b.eq            #0x124bfdc
    // 0x124bfbc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x124bfbc: ldur            w4, [x2, #0x17]
    // 0x124bfc0: DecompressPointer r4
    //     0x124bfc0: add             x4, x4, HEAP, lsl #32
    // 0x124bfc4: r8 = X0 bound ContainerParentDataMixin
    //     0x124bfc4: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x124bfc8: ldr             x8, [x8, #0x218]
    // 0x124bfcc: LoadField: r9 = r4->field_7
    //     0x124bfcc: ldur            x9, [x4, #7]
    // 0x124bfd0: r3 = Null
    //     0x124bfd0: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa11a8] Null
    //     0x124bfd4: ldr             x3, [x3, #0x1a8]
    // 0x124bfd8: blr             x9
    // 0x124bfdc: ldur            x1, [fp, #-0x28]
    // 0x124bfe0: r0 = LoadClassIdInstr(r1)
    //     0x124bfe0: ldur            x0, [x1, #-1]
    //     0x124bfe4: ubfx            x0, x0, #0xc, #0x14
    // 0x124bfe8: r0 = GDT[cid_x0 + 0xbf3a]()
    //     0x124bfe8: mov             x17, #0xbf3a
    //     0x124bfec: add             lr, x0, x17
    //     0x124bff0: ldr             lr, [x21, lr, lsl #3]
    //     0x124bff4: blr             lr
    // 0x124bff8: ldur            d0, [fp, #-0x40]
    // 0x124bffc: mov             x1, x0
    // 0x124c000: ldur            x2, [fp, #-0x20]
    // 0x124c004: b               #0x124bf2c
    // 0x124c008: ldur            d1, [fp, #-0x30]
    // 0x124c00c: ldur            d0, [fp, #-0x38]
    // 0x124c010: fadd            d2, d0, d1
    // 0x124c014: mov             v0.16b, v2.16b
    // 0x124c018: LeaveFrame
    //     0x124c018: mov             SP, fp
    //     0x124c01c: ldp             fp, lr, [SP], #0x10
    // 0x124c020: ret
    //     0x124c020: ret             
    // 0x124c024: ldur            x0, [fp, #-0x10]
    // 0x124c028: ldur            d1, [fp, #-0x30]
    // 0x124c02c: LoadField: r2 = r0->field_8b
    //     0x124c02c: ldur            w2, [x0, #0x8b]
    // 0x124c030: DecompressPointer r2
    //     0x124c030: add             x2, x2, HEAP, lsl #32
    // 0x124c034: cmp             w2, NULL
    // 0x124c038: b.eq            #0x124c190
    // 0x124c03c: mov             x1, x0
    // 0x124c040: r0 = childBefore()
    //     0x124c040: bl              #0xbc7fb4  ; [dart:mixin_deduplication] _MixinApplication236&RenderBox&ContainerRenderObjectMixin::childBefore
    // 0x124c044: mov             x1, x0
    // 0x124c048: ldur            x0, [fp, #-0x10]
    // 0x124c04c: LoadField: r2 = r0->field_4f
    //     0x124c04c: ldur            w2, [x0, #0x4f]
    // 0x124c050: DecompressPointer r2
    //     0x124c050: add             x2, x2, HEAP, lsl #32
    // 0x124c054: stur            x2, [fp, #-0x20]
    // 0x124c058: d0 = 0.000000
    //     0x124c058: eor             v0.16b, v0.16b, v0.16b
    // 0x124c05c: stur            x1, [fp, #-8]
    // 0x124c060: stur            d0, [fp, #-0x38]
    // 0x124c064: CheckStackOverflow
    //     0x124c064: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124c068: cmp             SP, x16
    //     0x124c06c: b.ls            #0x124c194
    // 0x124c070: r0 = 60
    //     0x124c070: mov             x0, #0x3c
    // 0x124c074: branchIfSmi(r1, 0x124c080)
    //     0x124c074: tbz             w1, #0, #0x124c080
    // 0x124c078: r0 = LoadClassIdInstr(r1)
    //     0x124c078: ldur            x0, [x1, #-1]
    //     0x124c07c: ubfx            x0, x0, #0xc, #0x14
    // 0x124c080: ldur            x16, [fp, #-0x18]
    // 0x124c084: stp             x16, x1, [SP]
    // 0x124c088: mov             lr, x0
    // 0x124c08c: ldr             lr, [x21, lr, lsl #3]
    // 0x124c090: blr             lr
    // 0x124c094: tbz             w0, #4, #0x124c13c
    // 0x124c098: ldur            d0, [fp, #-0x38]
    // 0x124c09c: ldur            x0, [fp, #-8]
    // 0x124c0a0: cmp             w0, NULL
    // 0x124c0a4: b.eq            #0x124c19c
    // 0x124c0a8: LoadField: r1 = r0->field_47
    //     0x124c0a8: ldur            w1, [x0, #0x47]
    // 0x124c0ac: DecompressPointer r1
    //     0x124c0ac: add             x1, x1, HEAP, lsl #32
    // 0x124c0b0: cmp             w1, NULL
    // 0x124c0b4: b.eq            #0x124c1a0
    // 0x124c0b8: LoadField: d1 = r1->field_7
    //     0x124c0b8: ldur            d1, [x1, #7]
    // 0x124c0bc: fsub            d2, d0, d1
    // 0x124c0c0: stur            d2, [fp, #-0x40]
    // 0x124c0c4: LoadField: r3 = r0->field_7
    //     0x124c0c4: ldur            w3, [x0, #7]
    // 0x124c0c8: DecompressPointer r3
    //     0x124c0c8: add             x3, x3, HEAP, lsl #32
    // 0x124c0cc: stur            x3, [fp, #-0x10]
    // 0x124c0d0: cmp             w3, NULL
    // 0x124c0d4: b.eq            #0x124c1a4
    // 0x124c0d8: mov             x0, x3
    // 0x124c0dc: ldur            x2, [fp, #-0x20]
    // 0x124c0e0: r1 = Null
    //     0x124c0e0: mov             x1, NULL
    // 0x124c0e4: cmp             w2, NULL
    // 0x124c0e8: b.eq            #0x124c10c
    // 0x124c0ec: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x124c0ec: ldur            w4, [x2, #0x17]
    // 0x124c0f0: DecompressPointer r4
    //     0x124c0f0: add             x4, x4, HEAP, lsl #32
    // 0x124c0f4: r8 = X0 bound ContainerParentDataMixin
    //     0x124c0f4: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x124c0f8: ldr             x8, [x8, #0x218]
    // 0x124c0fc: LoadField: r9 = r4->field_7
    //     0x124c0fc: ldur            x9, [x4, #7]
    // 0x124c100: r3 = Null
    //     0x124c100: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa11b8] Null
    //     0x124c104: ldr             x3, [x3, #0x1b8]
    // 0x124c108: blr             x9
    // 0x124c10c: ldur            x1, [fp, #-0x10]
    // 0x124c110: r0 = LoadClassIdInstr(r1)
    //     0x124c110: ldur            x0, [x1, #-1]
    //     0x124c114: ubfx            x0, x0, #0xc, #0x14
    // 0x124c118: r0 = GDT[cid_x0 + 0x11a98]()
    //     0x124c118: mov             x17, #0x1a98
    //     0x124c11c: movk            x17, #1, lsl #16
    //     0x124c120: add             lr, x0, x17
    //     0x124c124: ldr             lr, [x21, lr, lsl #3]
    //     0x124c128: blr             lr
    // 0x124c12c: ldur            d0, [fp, #-0x40]
    // 0x124c130: mov             x1, x0
    // 0x124c134: ldur            x2, [fp, #-0x20]
    // 0x124c138: b               #0x124c05c
    // 0x124c13c: ldur            d1, [fp, #-0x30]
    // 0x124c140: ldur            d0, [fp, #-0x38]
    // 0x124c144: fsub            d2, d0, d1
    // 0x124c148: mov             v0.16b, v2.16b
    // 0x124c14c: LeaveFrame
    //     0x124c14c: mov             SP, fp
    //     0x124c150: ldp             fp, lr, [SP], #0x10
    // 0x124c154: ret
    //     0x124c154: ret             
    // 0x124c158: r0 = StateError()
    //     0x124c158: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x124c15c: mov             x1, x0
    // 0x124c160: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x124c160: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x124c164: StoreField: r1->field_b = r0
    //     0x124c164: stur            w0, [x1, #0xb]
    // 0x124c168: mov             x0, x1
    // 0x124c16c: r0 = Throw()
    //     0x124c16c: bl              #0x13ddb2c  ; ThrowStub
    // 0x124c170: brk             #0
    // 0x124c174: r0 = StackOverflowSharedWithFPURegs()
    //     0x124c174: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x124c178: b               #0x124beb4
    // 0x124c17c: r0 = StackOverflowSharedWithFPURegs()
    //     0x124c17c: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x124c180: b               #0x124bf40
    // 0x124c184: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c184: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124c188: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c188: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124c18c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c18c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124c190: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c190: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124c194: r0 = StackOverflowSharedWithFPURegs()
    //     0x124c194: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x124c198: b               #0x124c070
    // 0x124c19c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c19c: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124c1a0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c1a0: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124c1a4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124c1a4: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
  _ maxScrollObstructionExtentBefore(/* No info */) {
    // ** addr: 0x124dfa8, size: 0x2c8
    // 0x124dfa8: EnterFrame
    //     0x124dfa8: stp             fp, lr, [SP, #-0x10]!
    //     0x124dfac: mov             fp, SP
    // 0x124dfb0: AllocStack(0x38)
    //     0x124dfb0: sub             SP, SP, #0x38
    // 0x124dfb4: SetupParameters(RenderViewport this /* r1 => r4, fp-0x10 */, dynamic _ /* r2 => r3, fp-0x18 */)
    //     0x124dfb4: mov             x4, x1
    //     0x124dfb8: mov             x3, x2
    //     0x124dfbc: stur            x1, [fp, #-0x10]
    //     0x124dfc0: stur            x2, [fp, #-0x18]
    // 0x124dfc4: CheckStackOverflow
    //     0x124dfc4: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124dfc8: cmp             SP, x16
    //     0x124dfcc: b.ls            #0x124e23c
    // 0x124dfd0: LoadField: r5 = r3->field_27
    //     0x124dfd0: ldur            w5, [x3, #0x27]
    // 0x124dfd4: DecompressPointer r5
    //     0x124dfd4: add             x5, x5, HEAP, lsl #32
    // 0x124dfd8: stur            x5, [fp, #-8]
    // 0x124dfdc: cmp             w5, NULL
    // 0x124dfe0: b.eq            #0x124e220
    // 0x124dfe4: mov             x0, x5
    // 0x124dfe8: r2 = Null
    //     0x124dfe8: mov             x2, NULL
    // 0x124dfec: r1 = Null
    //     0x124dfec: mov             x1, NULL
    // 0x124dff0: r4 = LoadClassIdInstr(r0)
    //     0x124dff0: ldur            x4, [x0, #-1]
    //     0x124dff4: ubfx            x4, x4, #0xc, #0x14
    // 0x124dff8: cmp             x4, #0xb45
    // 0x124dffc: b.eq            #0x124e014
    // 0x124e000: r8 = SliverConstraints
    //     0x124e000: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x124e004: ldr             x8, [x8, #0x3c0]
    // 0x124e008: r3 = Null
    //     0x124e008: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1168] Null
    //     0x124e00c: ldr             x3, [x3, #0x168]
    // 0x124e010: r0 = DefaultTypeTest()
    //     0x124e010: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x124e014: ldur            x0, [fp, #-8]
    // 0x124e018: LoadField: r1 = r0->field_b
    //     0x124e018: ldur            w1, [x0, #0xb]
    // 0x124e01c: DecompressPointer r1
    //     0x124e01c: add             x1, x1, HEAP, lsl #32
    // 0x124e020: LoadField: r0 = r1->field_7
    //     0x124e020: ldur            x0, [x1, #7]
    // 0x124e024: cmp             x0, #0
    // 0x124e028: b.gt            #0x124e118
    // 0x124e02c: ldur            x0, [fp, #-0x10]
    // 0x124e030: LoadField: r1 = r0->field_8b
    //     0x124e030: ldur            w1, [x0, #0x8b]
    // 0x124e034: DecompressPointer r1
    //     0x124e034: add             x1, x1, HEAP, lsl #32
    // 0x124e038: LoadField: r2 = r0->field_4f
    //     0x124e038: ldur            w2, [x0, #0x4f]
    // 0x124e03c: DecompressPointer r2
    //     0x124e03c: add             x2, x2, HEAP, lsl #32
    // 0x124e040: stur            x2, [fp, #-0x20]
    // 0x124e044: stur            x1, [fp, #-8]
    // 0x124e048: CheckStackOverflow
    //     0x124e048: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124e04c: cmp             SP, x16
    //     0x124e050: b.ls            #0x124e244
    // 0x124e054: r0 = 60
    //     0x124e054: mov             x0, #0x3c
    // 0x124e058: branchIfSmi(r1, 0x124e064)
    //     0x124e058: tbz             w1, #0, #0x124e064
    // 0x124e05c: r0 = LoadClassIdInstr(r1)
    //     0x124e05c: ldur            x0, [x1, #-1]
    //     0x124e060: ubfx            x0, x0, #0xc, #0x14
    // 0x124e064: ldur            x16, [fp, #-0x18]
    // 0x124e068: stp             x16, x1, [SP]
    // 0x124e06c: mov             lr, x0
    // 0x124e070: ldr             lr, [x21, lr, lsl #3]
    // 0x124e074: blr             lr
    // 0x124e078: tbz             w0, #4, #0x124e108
    // 0x124e07c: ldur            x0, [fp, #-8]
    // 0x124e080: cmp             w0, NULL
    // 0x124e084: b.eq            #0x124e24c
    // 0x124e088: LoadField: r1 = r0->field_47
    //     0x124e088: ldur            w1, [x0, #0x47]
    // 0x124e08c: DecompressPointer r1
    //     0x124e08c: add             x1, x1, HEAP, lsl #32
    // 0x124e090: cmp             w1, NULL
    // 0x124e094: b.eq            #0x124e250
    // 0x124e098: LoadField: r3 = r0->field_7
    //     0x124e098: ldur            w3, [x0, #7]
    // 0x124e09c: DecompressPointer r3
    //     0x124e09c: add             x3, x3, HEAP, lsl #32
    // 0x124e0a0: stur            x3, [fp, #-0x28]
    // 0x124e0a4: cmp             w3, NULL
    // 0x124e0a8: b.eq            #0x124e254
    // 0x124e0ac: mov             x0, x3
    // 0x124e0b0: ldur            x2, [fp, #-0x20]
    // 0x124e0b4: r1 = Null
    //     0x124e0b4: mov             x1, NULL
    // 0x124e0b8: cmp             w2, NULL
    // 0x124e0bc: b.eq            #0x124e0e0
    // 0x124e0c0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x124e0c0: ldur            w4, [x2, #0x17]
    // 0x124e0c4: DecompressPointer r4
    //     0x124e0c4: add             x4, x4, HEAP, lsl #32
    // 0x124e0c8: r8 = X0 bound ContainerParentDataMixin
    //     0x124e0c8: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x124e0cc: ldr             x8, [x8, #0x218]
    // 0x124e0d0: LoadField: r9 = r4->field_7
    //     0x124e0d0: ldur            x9, [x4, #7]
    // 0x124e0d4: r3 = Null
    //     0x124e0d4: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1178] Null
    //     0x124e0d8: ldr             x3, [x3, #0x178]
    // 0x124e0dc: blr             x9
    // 0x124e0e0: ldur            x1, [fp, #-0x28]
    // 0x124e0e4: r0 = LoadClassIdInstr(r1)
    //     0x124e0e4: ldur            x0, [x1, #-1]
    //     0x124e0e8: ubfx            x0, x0, #0xc, #0x14
    // 0x124e0ec: r0 = GDT[cid_x0 + 0xbf3a]()
    //     0x124e0ec: mov             x17, #0xbf3a
    //     0x124e0f0: add             lr, x0, x17
    //     0x124e0f4: ldr             lr, [x21, lr, lsl #3]
    //     0x124e0f8: blr             lr
    // 0x124e0fc: mov             x1, x0
    // 0x124e100: ldur            x2, [fp, #-0x20]
    // 0x124e104: b               #0x124e044
    // 0x124e108: d0 = 0.000000
    //     0x124e108: eor             v0.16b, v0.16b, v0.16b
    // 0x124e10c: LeaveFrame
    //     0x124e10c: mov             SP, fp
    //     0x124e110: ldp             fp, lr, [SP], #0x10
    // 0x124e114: ret
    //     0x124e114: ret             
    // 0x124e118: ldur            x0, [fp, #-0x10]
    // 0x124e11c: LoadField: r2 = r0->field_8b
    //     0x124e11c: ldur            w2, [x0, #0x8b]
    // 0x124e120: DecompressPointer r2
    //     0x124e120: add             x2, x2, HEAP, lsl #32
    // 0x124e124: cmp             w2, NULL
    // 0x124e128: b.eq            #0x124e258
    // 0x124e12c: mov             x1, x0
    // 0x124e130: r0 = childBefore()
    //     0x124e130: bl              #0xbc7fb4  ; [dart:mixin_deduplication] _MixinApplication236&RenderBox&ContainerRenderObjectMixin::childBefore
    // 0x124e134: mov             x1, x0
    // 0x124e138: ldur            x0, [fp, #-0x10]
    // 0x124e13c: LoadField: r2 = r0->field_4f
    //     0x124e13c: ldur            w2, [x0, #0x4f]
    // 0x124e140: DecompressPointer r2
    //     0x124e140: add             x2, x2, HEAP, lsl #32
    // 0x124e144: stur            x2, [fp, #-0x20]
    // 0x124e148: stur            x1, [fp, #-8]
    // 0x124e14c: CheckStackOverflow
    //     0x124e14c: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124e150: cmp             SP, x16
    //     0x124e154: b.ls            #0x124e25c
    // 0x124e158: r0 = 60
    //     0x124e158: mov             x0, #0x3c
    // 0x124e15c: branchIfSmi(r1, 0x124e168)
    //     0x124e15c: tbz             w1, #0, #0x124e168
    // 0x124e160: r0 = LoadClassIdInstr(r1)
    //     0x124e160: ldur            x0, [x1, #-1]
    //     0x124e164: ubfx            x0, x0, #0xc, #0x14
    // 0x124e168: ldur            x16, [fp, #-0x18]
    // 0x124e16c: stp             x16, x1, [SP]
    // 0x124e170: mov             lr, x0
    // 0x124e174: ldr             lr, [x21, lr, lsl #3]
    // 0x124e178: blr             lr
    // 0x124e17c: tbz             w0, #4, #0x124e210
    // 0x124e180: ldur            x0, [fp, #-8]
    // 0x124e184: cmp             w0, NULL
    // 0x124e188: b.eq            #0x124e264
    // 0x124e18c: LoadField: r1 = r0->field_47
    //     0x124e18c: ldur            w1, [x0, #0x47]
    // 0x124e190: DecompressPointer r1
    //     0x124e190: add             x1, x1, HEAP, lsl #32
    // 0x124e194: cmp             w1, NULL
    // 0x124e198: b.eq            #0x124e268
    // 0x124e19c: LoadField: r3 = r0->field_7
    //     0x124e19c: ldur            w3, [x0, #7]
    // 0x124e1a0: DecompressPointer r3
    //     0x124e1a0: add             x3, x3, HEAP, lsl #32
    // 0x124e1a4: stur            x3, [fp, #-0x10]
    // 0x124e1a8: cmp             w3, NULL
    // 0x124e1ac: b.eq            #0x124e26c
    // 0x124e1b0: mov             x0, x3
    // 0x124e1b4: ldur            x2, [fp, #-0x20]
    // 0x124e1b8: r1 = Null
    //     0x124e1b8: mov             x1, NULL
    // 0x124e1bc: cmp             w2, NULL
    // 0x124e1c0: b.eq            #0x124e1e4
    // 0x124e1c4: ArrayLoad: r4 = r2[0]  ; List_4
    //     0x124e1c4: ldur            w4, [x2, #0x17]
    // 0x124e1c8: DecompressPointer r4
    //     0x124e1c8: add             x4, x4, HEAP, lsl #32
    // 0x124e1cc: r8 = X0 bound ContainerParentDataMixin
    //     0x124e1cc: add             x8, PP, #0x96, lsl #12  ; [pp+0x96218] TypeParameter: X0 bound ContainerParentDataMixin
    //     0x124e1d0: ldr             x8, [x8, #0x218]
    // 0x124e1d4: LoadField: r9 = r4->field_7
    //     0x124e1d4: ldur            x9, [x4, #7]
    // 0x124e1d8: r3 = Null
    //     0x124e1d8: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1188] Null
    //     0x124e1dc: ldr             x3, [x3, #0x188]
    // 0x124e1e0: blr             x9
    // 0x124e1e4: ldur            x1, [fp, #-0x10]
    // 0x124e1e8: r0 = LoadClassIdInstr(r1)
    //     0x124e1e8: ldur            x0, [x1, #-1]
    //     0x124e1ec: ubfx            x0, x0, #0xc, #0x14
    // 0x124e1f0: r0 = GDT[cid_x0 + 0x11a98]()
    //     0x124e1f0: mov             x17, #0x1a98
    //     0x124e1f4: movk            x17, #1, lsl #16
    //     0x124e1f8: add             lr, x0, x17
    //     0x124e1fc: ldr             lr, [x21, lr, lsl #3]
    //     0x124e200: blr             lr
    // 0x124e204: mov             x1, x0
    // 0x124e208: ldur            x2, [fp, #-0x20]
    // 0x124e20c: b               #0x124e148
    // 0x124e210: d0 = 0.000000
    //     0x124e210: eor             v0.16b, v0.16b, v0.16b
    // 0x124e214: LeaveFrame
    //     0x124e214: mov             SP, fp
    //     0x124e218: ldp             fp, lr, [SP], #0x10
    // 0x124e21c: ret
    //     0x124e21c: ret             
    // 0x124e220: r0 = StateError()
    //     0x124e220: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x124e224: mov             x1, x0
    // 0x124e228: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x124e228: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x124e22c: StoreField: r1->field_b = r0
    //     0x124e22c: stur            w0, [x1, #0xb]
    // 0x124e230: mov             x0, x1
    // 0x124e234: r0 = Throw()
    //     0x124e234: bl              #0x13ddb2c  ; ThrowStub
    // 0x124e238: brk             #0
    // 0x124e23c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124e23c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124e240: b               #0x124dfd0
    // 0x124e244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124e244: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124e248: b               #0x124e054
    // 0x124e24c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e24c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124e250: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e250: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124e254: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e254: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124e258: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e258: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124e25c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x124e25c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x124e260: b               #0x124e158
    // 0x124e264: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e264: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124e268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e268: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x124e26c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x124e26c: bl              #0x13e00c4  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeChildMainAxisPosition(/* No info */) {
    // ** addr: 0x124e790, size: 0x1bc
    // 0x124e790: EnterFrame
    //     0x124e790: stp             fp, lr, [SP, #-0x10]!
    //     0x124e794: mov             fp, SP
    // 0x124e798: AllocStack(0x20)
    //     0x124e798: sub             SP, SP, #0x20
    // 0x124e79c: SetupParameters(dynamic _ /* r2 => r3, fp-0x10 */, dynamic _ /* d0 => d0, fp-0x20 */)
    //     0x124e79c: mov             x3, x2
    //     0x124e7a0: stur            x2, [fp, #-0x10]
    //     0x124e7a4: stur            d0, [fp, #-0x20]
    // 0x124e7a8: CheckStackOverflow
    //     0x124e7a8: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x124e7ac: cmp             SP, x16
    //     0x124e7b0: b.ls            #0x124e938
    // 0x124e7b4: LoadField: r4 = r3->field_7
    //     0x124e7b4: ldur            w4, [x3, #7]
    // 0x124e7b8: DecompressPointer r4
    //     0x124e7b8: add             x4, x4, HEAP, lsl #32
    // 0x124e7bc: stur            x4, [fp, #-8]
    // 0x124e7c0: cmp             w4, NULL
    // 0x124e7c4: b.eq            #0x124e940
    // 0x124e7c8: mov             x0, x4
    // 0x124e7cc: r2 = Null
    //     0x124e7cc: mov             x2, NULL
    // 0x124e7d0: r1 = Null
    //     0x124e7d0: mov             x1, NULL
    // 0x124e7d4: r4 = LoadClassIdInstr(r0)
    //     0x124e7d4: ldur            x4, [x0, #-1]
    //     0x124e7d8: ubfx            x4, x4, #0xc, #0x14
    // 0x124e7dc: r17 = -4177
    //     0x124e7dc: mov             x17, #-0x1051
    // 0x124e7e0: add             x4, x4, x17
    // 0x124e7e4: cmp             x4, #2
    // 0x124e7e8: b.ls            #0x124e800
    // 0x124e7ec: r8 = SliverPhysicalParentData
    //     0x124e7ec: add             x8, PP, #0x96, lsl #12  ; [pp+0x96240] Type: SliverPhysicalParentData
    //     0x124e7f0: ldr             x8, [x8, #0x240]
    // 0x124e7f4: r3 = Null
    //     0x124e7f4: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1148] Null
    //     0x124e7f8: ldr             x3, [x3, #0x148]
    // 0x124e7fc: r0 = DefaultTypeTest()
    //     0x124e7fc: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x124e800: ldur            x0, [fp, #-8]
    // 0x124e804: LoadField: r3 = r0->field_7
    //     0x124e804: ldur            w3, [x0, #7]
    // 0x124e808: DecompressPointer r3
    //     0x124e808: add             x3, x3, HEAP, lsl #32
    // 0x124e80c: ldur            x4, [fp, #-0x10]
    // 0x124e810: stur            x3, [fp, #-0x18]
    // 0x124e814: LoadField: r5 = r4->field_27
    //     0x124e814: ldur            w5, [x4, #0x27]
    // 0x124e818: DecompressPointer r5
    //     0x124e818: add             x5, x5, HEAP, lsl #32
    // 0x124e81c: stur            x5, [fp, #-8]
    // 0x124e820: cmp             w5, NULL
    // 0x124e824: b.eq            #0x124e91c
    // 0x124e828: mov             x0, x5
    // 0x124e82c: r2 = Null
    //     0x124e82c: mov             x2, NULL
    // 0x124e830: r1 = Null
    //     0x124e830: mov             x1, NULL
    // 0x124e834: r4 = LoadClassIdInstr(r0)
    //     0x124e834: ldur            x4, [x0, #-1]
    //     0x124e838: ubfx            x4, x4, #0xc, #0x14
    // 0x124e83c: cmp             x4, #0xb45
    // 0x124e840: b.eq            #0x124e858
    // 0x124e844: r8 = SliverConstraints
    //     0x124e844: add             x8, PP, #0x96, lsl #12  ; [pp+0x963c0] Type: SliverConstraints
    //     0x124e848: ldr             x8, [x8, #0x3c0]
    // 0x124e84c: r3 = Null
    //     0x124e84c: add             x3, PP, #0xa1, lsl #12  ; [pp+0xa1158] Null
    //     0x124e850: ldr             x3, [x3, #0x158]
    // 0x124e854: r0 = DefaultTypeTest()
    //     0x124e854: bl              #0x13dd7a4  ; DefaultTypeTestStub
    // 0x124e858: ldur            x0, [fp, #-8]
    // 0x124e85c: LoadField: r1 = r0->field_7
    //     0x124e85c: ldur            w1, [x0, #7]
    // 0x124e860: DecompressPointer r1
    //     0x124e860: add             x1, x1, HEAP, lsl #32
    // 0x124e864: LoadField: r2 = r0->field_b
    //     0x124e864: ldur            w2, [x0, #0xb]
    // 0x124e868: DecompressPointer r2
    //     0x124e868: add             x2, x2, HEAP, lsl #32
    // 0x124e86c: r0 = applyGrowthDirectionToAxisDirection()
    //     0x124e86c: bl              #0xb7b568  ; [package:flutter/src/rendering/sliver.dart] ::applyGrowthDirectionToAxisDirection
    // 0x124e870: LoadField: r1 = r0->field_7
    //     0x124e870: ldur            x1, [x0, #7]
    // 0x124e874: cmp             x1, #1
    // 0x124e878: b.gt            #0x124e8cc
    // 0x124e87c: cmp             x1, #0
    // 0x124e880: b.gt            #0x124e8b4
    // 0x124e884: ldur            x2, [fp, #-0x10]
    // 0x124e888: ldur            d0, [fp, #-0x20]
    // 0x124e88c: ldur            x0, [fp, #-0x18]
    // 0x124e890: LoadField: r1 = r2->field_47
    //     0x124e890: ldur            w1, [x2, #0x47]
    // 0x124e894: DecompressPointer r1
    //     0x124e894: add             x1, x1, HEAP, lsl #32
    // 0x124e898: cmp             w1, NULL
    // 0x124e89c: b.eq            #0x124e944
    // 0x124e8a0: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x124e8a0: ldur            d1, [x1, #0x17]
    // 0x124e8a4: LoadField: d2 = r0->field_f
    //     0x124e8a4: ldur            d2, [x0, #0xf]
    // 0x124e8a8: fsub            d3, d0, d2
    // 0x124e8ac: fsub            d0, d1, d3
    // 0x124e8b0: b               #0x124e910
    // 0x124e8b4: ldur            d0, [fp, #-0x20]
    // 0x124e8b8: ldur            x0, [fp, #-0x18]
    // 0x124e8bc: LoadField: d1 = r0->field_7
    //     0x124e8bc: ldur            d1, [x0, #7]
    // 0x124e8c0: fsub            d2, d0, d1
    // 0x124e8c4: mov             v0.16b, v2.16b
    // 0x124e8c8: b               #0x124e910
    // 0x124e8cc: ldur            x2, [fp, #-0x10]
    // 0x124e8d0: ldur            d0, [fp, #-0x20]
    // 0x124e8d4: ldur            x0, [fp, #-0x18]
    // 0x124e8d8: cmp             x1, #2
    // 0x124e8dc: b.gt            #0x124e8f0
    // 0x124e8e0: LoadField: d1 = r0->field_f
    //     0x124e8e0: ldur            d1, [x0, #0xf]
    // 0x124e8e4: fsub            d2, d0, d1
    // 0x124e8e8: mov             v0.16b, v2.16b
    // 0x124e8ec: b               #0x124e910
    // 0x124e8f0: LoadField: r1 = r2->field_47
    //     0x124e8f0: ldur            w1, [x2, #0x47]
    // 0x124e8f4: DecompressPointer r1
    //     0x124e8f4: add             x1, x1, HEAP, lsl #32
    // 0x124e8f8: cmp             w1, NULL
    // 0x124e8fc: b.eq            #0x124e948
    // 0x124e900: ArrayLoad: d1 = r1[0]  ; List_8
    //     0x124e900: ldur            d1, [x1, #0x17]
    // 0x124e904: LoadField: d2 = r0->field_7
    //     0x124e904: ldur            d2, [x0, #7]
    // 0x124e908: fsub            d3, d0, d2
    // 0x124e90c: fsub            d0, d1, d3
    // 0x124e910: LeaveFrame
    //     0x124e910: mov             SP, fp
    //     0x124e914: ldp             fp, lr, [SP], #0x10
    // 0x124e918: ret
    //     0x124e918: ret             
    // 0x124e91c: r0 = StateError()
    //     0x124e91c: bl              #0x7d92a0  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x124e920: mov             x1, x0
    // 0x124e924: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x124e924: ldr             x0, [PP, #0x4ce8]  ; [pp+0x4ce8] "A RenderObject does not have any constraints before it has been laid out."
    // 0x124e928: StoreField: r1->field_b = r0
    //     0x124e928: stur            w0, [x1, #0xb]
    // 0x124e92c: mov             x0, x1
    // 0x124e930: r0 = Throw()
    //     0x124e930: bl              #0x13ddb2c  ; ThrowStub
    // 0x124e934: brk             #0
    // 0x124e938: r0 = StackOverflowSharedWithFPURegs()
    //     0x124e938: bl              #0x13dfab4  ; StackOverflowSharedWithFPURegsStub
    // 0x124e93c: b               #0x124e7b4
    // 0x124e940: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124e940: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124e944: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124e944: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
    // 0x124e948: r0 = NullCastErrorSharedWithFPURegs()
    //     0x124e948: bl              #0x13e0110  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 8217, size: 0x14, field offset: 0x14
enum SliverPaintOrder extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0x11ab2f0, size: 0x64
    // 0x11ab2f0: EnterFrame
    //     0x11ab2f0: stp             fp, lr, [SP, #-0x10]!
    //     0x11ab2f4: mov             fp, SP
    // 0x11ab2f8: AllocStack(0x10)
    //     0x11ab2f8: sub             SP, SP, #0x10
    // 0x11ab2fc: SetupParameters(SliverPaintOrder this /* r1 => r0, fp-0x8 */)
    //     0x11ab2fc: mov             x0, x1
    //     0x11ab300: stur            x1, [fp, #-8]
    // 0x11ab304: CheckStackOverflow
    //     0x11ab304: ldr             x16, [THR, #0x48]  ; THR::stack_limit
    //     0x11ab308: cmp             SP, x16
    //     0x11ab30c: b.ls            #0x11ab34c
    // 0x11ab310: r1 = Null
    //     0x11ab310: mov             x1, NULL
    // 0x11ab314: r2 = 4
    //     0x11ab314: mov             x2, #4
    // 0x11ab318: r0 = AllocateArray()
    //     0x11ab318: bl              #0x13df928  ; AllocateArrayStub
    // 0x11ab31c: r16 = "SliverPaintOrder."
    //     0x11ab31c: add             x16, PP, #0x80, lsl #12  ; [pp+0x80ca0] "SliverPaintOrder."
    //     0x11ab320: ldr             x16, [x16, #0xca0]
    // 0x11ab324: StoreField: r0->field_f = r16
    //     0x11ab324: stur            w16, [x0, #0xf]
    // 0x11ab328: ldur            x1, [fp, #-8]
    // 0x11ab32c: LoadField: r2 = r1->field_f
    //     0x11ab32c: ldur            w2, [x1, #0xf]
    // 0x11ab330: DecompressPointer r2
    //     0x11ab330: add             x2, x2, HEAP, lsl #32
    // 0x11ab334: StoreField: r0->field_13 = r2
    //     0x11ab334: stur            w2, [x0, #0x13]
    // 0x11ab338: str             x0, [SP]
    // 0x11ab33c: r0 = _interpolate()
    //     0x11ab33c: bl              #0x7e1b8c  ; [dart:core] _StringBase::_interpolate
    // 0x11ab340: LeaveFrame
    //     0x11ab340: mov             SP, fp
    //     0x11ab344: ldp             fp, lr, [SP], #0x10
    // 0x11ab348: ret
    //     0x11ab348: ret             
    // 0x11ab34c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x11ab34c: bl              #0x13dfa34  ; StackOverflowSharedWithoutFPURegsStub
    // 0x11ab350: b               #0x11ab310
  }
}
